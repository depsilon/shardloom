# Pinned Vortex survivor batching provider inventory (r2)

Pinned checkout: `/Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree`  
Commit: `236dbccd590a301ede8f34cce09715be92f025e5`  
Vortex version: `0.93.0`, from Cargo.lock package `vortex` (citation C1).

## Inventory

- **Construction:** Chunked construction validates child dtypes, then stores each input `ArrayRef` in a child slot. It does not concatenate child values in this path (C2).
- **Slicing:** Chunked slice creates views for edge chunks, clones complete middle chunks, and constructs another chunked array (C3).
- **Filtering/take:** The chunked filter path chooses slice runs or indices. Whole selected chunks are cloned; index selection uses each child's `take`, and results remain chunked (C4–C6).
- **Canonical consumer requests:** A one-child chunked array delegates canonicalization to that child (C7). For multiple chunks, the generic dtype branch appends into a canonical builder (C8); this branch covers Primitive and Utf8. Specialized branches exist for struct/list/fixed-list/variant in the cited source around this branch.
- **Size and retained backing:** `nbytes` sums the lengths of buffers exposed by arrays in depth-first traversal (C9), so it reports view bytes rather than the full retained parent allocation. `Buffer::as_ptr` exposes the current data pointer (C10); slice construction clones the private backing owner while changing pointer/length (C11). No public backing-allocation capacity or stable allocation-identity accessor was found in the inspected source paths.
- **String compaction:** VarBinView's `compact_buffers` may copy outlined strings; its heuristic compares referenced bytes to the sum of data buffer view lengths (C12–C13).
- **Existing ShardLoom paths:** Spill sizing uses `nbytes` (C14), and partial block output is detached because a sliced byte view can retain the gathered payload (C15). Numeric validation requests `PrimitiveArray` (C16); typed Utf8 validation directly reads VarBinView views (C17).

## Unknowns

- Exact retained allocation size for every `BufferHandle` backend.
- Whether pointer equality identifies shared backing in every buffer/view representation.
- Allocation/copy behavior of take for every child encoding.
- Whether another Vortex module exposes allocation capacity or stable backing identity.

## Exact evidence

The JSON companion [provider-inventory-r2.json](./provider-inventory-r2.json) contains all 17 citations with full-file SHA256, numeric start/end lines, and literal contiguous excerpts. The `excerpt_policy` field specifies equality to `"\\n".join(source.splitlines()[start-1:end])`; the excerpt excludes a trailing LF after its final indicated source line. I validated each citation's hash and exact excerpt equality against the pinned checkout.

No design, acceptance, or performance conclusion is made here.
