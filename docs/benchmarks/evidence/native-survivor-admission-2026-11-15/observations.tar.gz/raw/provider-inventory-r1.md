# Pinned Vortex survivor batching provider inventory

Pinned checkout: `/Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree`, commit `236dbccd590a301ede8f34cce09715be92f025e5` (vendor Vortex 0.93).

## Source observations

1. `ChunkedArray::try_new` stores each input chunk as a child slot, recording cumulative row offsets; its visible validation checks dtype. It does not concatenate child values during construction. [Source](#c1)
2. Chunked slicing slices only the boundary chunks, clones whole interior chunks, and returns a new unchecked `ChunkedArray`. Thus independently encoded source slices can be composed as chunks without a constructor copy. [Source](#c2)
3. Filtering follows the same chunk-preserving shape: slice-selective filtering preserves complete chunks and filters local slices, while index selection calls `take` within each chunk; results are wrapped as a chunked array. [Source](#c3)
4. Canonicalizing a chunked array with one chunk canonicalizes that child. With multiple chunks, struct/list/fixed-list/variant have specialized packing paths; other types append into a canonical builder sized by logical row count. Primitive and UTF8 are in this latter group, so the consumer request materializes a canonical representation rather than keeping the chunked wrapper. [Source](#c4)
5. `ArrayRef::nbytes()` sums `buffer.len()` over depth-first arrays. It is view/logical buffer bytes; it does not measure the full retained parent allocation. [Source](#c5)
6. `Buffer::len()` and `as_ptr()` are public, and slicing clones the backing owner while narrowing the pointer/length. The public API offers view identity evidence via data pointers, but no public backing-allocation capacity/identity accessor was found in this path. Internal buffer backing/allocation details are not public API. [Source](#c6)
7. VarBinView has an explicit `compact_buffers` API. It estimates referenced bytes against summed data-buffer lengths and can copy visible outlined values into compact storage; the source explicitly warns this can copy all string data. [Source](#c7)
8. Current ShardLoom spill block sizing uses `nbytes()` for bytes-per-row and output maximum. When a partial slice or joined chunk block is produced, ShardLoom detaches it before retaining the output; code comments explain the sliced byte view can still own the full gathered payload. [Source](#c8)
9. Existing native payload validation requests `PrimitiveArray` for numeric storage; its typed validator directly handles host VarBinView (including UTF8 validity/value checks) rather than requesting canonical form. [Source](#c9)

## Unknowns

- This source inventory does not establish exact physical allocation size for every `BufferHandle` backend or whether pointer equality is sufficient to identify shared backing across every buffer/view representation.
- The inventory does not establish all `take`-kernel allocation/copy details for every child encoding; the dispatch evidence above shows chunked take routes into child `take`, not the per-encoding implementation.
- It does not establish whether another Vortex API outside the inspected buffer path exposes allocation capacity or stable backing identity.
- It does not make performance, acceptance, or design conclusions.

## Citations

Each excerpt is literal source text at the pinned commit; SHA256 covers the complete file bytes.

### C1 — Chunked construction retains child arrays

File: `vendor/vortex-array/src/arrays/chunked/array.rs`  
SHA256: `8ceef75f9cfe9155119720327ccee60fd29f83d98a6636aa840b230fae6f4c50`  
Lines 181–190:

```rust
        for chunk in chunks {
            if VALIDATE {
                Self::validate_chunk_dtype(&chunk, &dtype)?;
            }
            len += chunk.len();
            chunk_offsets.push(len);
            slots.push(Some(chunk));
        }

        Ok(Self::parts_from_slots(dtype, len, chunk_offsets, slots))
```

### C2 — Chunked slice composes boundary views and interior child refs

File: `vendor/vortex-array/src/arrays/chunked/compute/slice.rs`  
SHA256: `08ac91501a912674b2db1b99b68e0524bd704544a888ec6b8b290c1b7da1d66a`  
Lines 49–63:

```rust
        let first = array.chunk(offset_chunk);
        let first = first.slice(offset_in_first_chunk..first.len())?;
        let middle = (offset_chunk + 1..length_chunk).map(|i| array.chunk(i).clone());
        let last = if length_in_last_chunk == 0 {
            None
        } else {
            Some(array.chunk(length_chunk).slice(0..length_in_last_chunk)?)
        };
        let chunks = std::iter::once(first).chain(middle).chain(last);

        // SAFETY: chunks are slices of the original valid chunks, preserving their dtype.
        // All chunks maintain the same dtype as the original array.
        Ok(Some(unsafe {
            ChunkedArray::new_unchecked(chunks, array.dtype().clone()).into_array()
        }))
```

### C3 — Chunked filter selects local chunks/slices/takes

File: `vendor/vortex-array/src/arrays/chunked/compute/filter.rs`  
SHA256: `f876543a56314f38c09c194571e68cf6ebf0af22e0c37d0b2a585c0c944bcb50`  
Lines 36–49 and 73–80:

```rust
        // Based on filter selectivity, we take the values between a range of slices, or
        // we take individual indices.
        let chunks = match mask_values.threshold_iter(FILTER_SLICES_SELECTIVITY_THRESHOLD) {
            MaskIter::Indices(indices) => filter_indices(array, indices.iter().copied()),
            MaskIter::Slices(slices) => filter_slices(array, slices.iter().copied()),
        }?;

        // SAFETY: Filter operation preserves the dtype of each chunk.
        // All filtered chunks maintain the same dtype as the original array.
        unsafe {
            Ok(Some(
                ChunkedArray::new_unchecked(chunks, array.dtype().clone()).into_array(),
            ))
        }
```

### C4 — Canonical form behavior for multiple chunks

File: `vendor/vortex-array/src/arrays/chunked/vtable/canonical.rs`  
SHA256: `739be151b422fa3e305fc7197b56dd6a7e07bb0c10ddd648acf3fe8ecd736203`  
Lines 46–75:

```rust
    if array.nchunks() == 1 {
        return array.chunk(0).clone().execute::<Canonical>(ctx);
    }

    let owned_chunks: Vec<ArrayRef> = array.iter_chunks().cloned().collect();
    Ok(match array.dtype() {
        DType::Struct(..) => {
            let struct_array = pack_struct_chunks(owned_chunks, ctx)?;
            Canonical::Struct(struct_array)
        }
        DType::List(elem_dtype, _) => Canonical::List(swizzle_list_chunks(
            &owned_chunks,
            array.array().validity()?,
            elem_dtype,
            ctx,
        )?),
        DType::FixedSizeList(elem_dtype, list_size, _) => {
            Canonical::FixedSizeList(swizzle_fixed_size_list_chunks(
                &owned_chunks,
                array.array().validity()?,
                elem_dtype,
                *list_size,
                ctx,
            )?)
        }
        DType::Variant(_) => Canonical::Variant(pack_variant_chunks(owned_chunks, ctx)?),
        _ => {
            let mut builder = builder_with_capacity_in(array.dtype(), array.len(), ctx.allocator());
            array.array().append_to_builder(builder.as_mut(), ctx)?;
            builder.finish_into_canonical(ctx)
```

### C5 — nbytes sums buffer view lengths

File: `vendor/vortex-array/src/array/erased.rs`  
SHA256: `50b8f3f8717bc263630c1bcdb2857aeab2e0bcdc11c39d47525e87894c87f96f`  
Lines 512–520:

```rust
    /// Total size of the array in bytes, including all children and buffers.
    pub fn nbytes(&self) -> u64 {
        let mut nbytes = 0;
        for array in self.depth_first_traversal() {
            for buffer in array.buffers() {
                nbytes += buffer.len() as u64;
            }
        }
        nbytes
    }
```

### C6 — Buffer view pointer and backing sharing on slice

File: `vendor/vortex-buffer/src/buffer.rs`  
SHA256: `3f470511a20b8828de0e8369d998c191ca25cc6c9f5c36ace43feb5b6e22b719`  
Lines 381–385 and 527–542:

```rust
    /// Returns a raw pointer to the buffer's data.
    #[allow(clippy::inline_always)]
    #[inline(always)]
    pub fn as_ptr(&self) -> *const T {
        self.ptr.as_ptr()
```

```rust
        let start = self.as_ptr().addr();
        let end = start + size_of_val(self.as_slice());
        let subset_start = subset.as_ptr().addr();
        let subset_end = subset_start
            .checked_add(size_of_val(subset))
            .vortex_expect("slice_ref address overflow");
        if subset_start < start || subset_end > end {
            vortex_panic!("slice_ref subset must be contained in the buffer");
        }

        Self {
            ptr: NonNull::new(subset.as_ptr().cast_mut()).vortex_expect("slice pointer is null"),
            length: subset.len(),
            alignment,
            backing: self.backing.clone(),
        }
```

### C7 — VarBinView compaction behavior and accounting

File: `vendor/vortex-array/src/arrays/varbinview/compact.rs`  
SHA256: `bcb52faad222fb9b86f7091d07b20b86cbb6be946e731fca246787c962c7a38d`  
Lines 22–36 and 52–63:

```rust
    /// Returns a compacted copy of the input array, where all wasted space has been cleaned up. This
    /// operation can be very expensive, in the worst case copying all existing string data into a
    /// new allocation.
    ///
    /// After slicing/taking operations `VarBinViewArray`s can continue to hold references to buffers
    /// that are no longer visible. We detect when there is wasted space in any of the buffers, and if
    /// so, will aggressively compact all visible outlined string data into new buffers while keeping
    /// well-utilized buffers unchanged.
```

```rust
        let buffer_total_bytes: u64 = self.buffers.iter().map(|buf| buf.len() as u64).sum();
        if buffer_total_bytes == 0 {
            return Ok(true);
        }

        let len = u64::try_from(self.len()).unwrap_or(u64::MAX);
        if len > 0 && buffer_total_bytes / len <= MIN_RETAINED_BYTES_PER_ROW_TO_CHECK_COMPACTION {
            return Ok(false);
        }

        let bytes_referenced = self.count_referenced_bytes(ctx)?;
        Ok((bytes_referenced as f64 / buffer_total_bytes as f64) < DEFAULT_COMPACTION_THRESHOLD)
```

### C8 — ShardLoom spill sizing and detachment

File: `shardloom-vortex/src/local_primitives/native_relational_spill_sizing.rs`  
SHA256: `34f7eb2b12cbf0271079017640452e879d72f0dba91e90fc316b016d32400d70`  
Lines 185–210 and 233–249:

```rust
            self.payload_bytes_per_row.set(
                self.payload_bytes_per_row
                    .get()
                    .max(array.nbytes().div_ceil(array.len() as u64)),
            );
```

```rust
        let output = if compact {
            // A sliced byte view still owns its entire gathered payload. Store
            // only this block's selected values, or small physical blocks would
            // repeat that backing buffer and amplify the next merge's reads.
            // The original gather already applied its validation policy; this
            // storage-only copy preserves unobserved values and floating bits.
            super::super::native_payload::detach_with_policy(
                &output,
                super::super::native_payload::CopyPolicy::PreserveUnobserved,
                self.context,
            )?
```

### C9 — Current ShardLoom primitive and variable validation consumers

File: `shardloom-vortex/src/local_primitives/native_payload_validation.rs`  
SHA256: `d6e43aac13a00fdab3347b04d059337c8ac293c46c885302f6374495c574db2f`  
Lines 57–63:

```rust
        let numeric = if matches!(dtype, DType::Primitive(..))
            || crate::native_payload_schema::temporal_storage(dtype).is_some()
        {
            let storage = result_batch::scalar_storage(&column, &mut execution)?
                .execute::<PrimitiveArray>(&mut execution)
                .map_err(vortex_error)?;
            Some(NativeNumericOwner::new(storage, &mut execution)?)
```

File: `shardloom-vortex/src/local_primitives/native_payload_validation_typed.rs`  
SHA256: `ca7a86bf7465f4ea40c5bff645e14bccee78c4d5d6ab673d2356c2d18b339343`  
Lines 15–42:

```rust
    if !column.is_host() || !(column.is::<Bool>() || column.is::<VarBinView>()) {
        return Ok(false);
    }
    let valid = column
        .validity()
        .map_err(vortex_error)?
        .execute_mask(column.len(), execution)
        .map_err(vortex_error)?;
```

```rust
    if let Some(values) = column.as_opt::<VarBinView>() {
        let text = matches!(column.dtype(), DType::Utf8(_));
        let mut bytes = 0;
        for (row, view) in values.views().iter().enumerate() {
            check(row, context)?;
            if valid.value(row) {
                let len = if text {
                    values.utf8_slice_at(row).map_err(vortex_error)?.len()
                } else {
                    // Native construction admitted these immutable views against
                    // their buffers. Binary bytes have no additional value domain.
                    view.len() as usize
```
