# Source owner inventory: I survivor batching and read consumers

**Status: COMPLETE.** Pinned accepted source: `0e6d15a658c060bd11e9a1001a71515f69f2064e`.

All quoted content was extracted with `git show <commit>:<path>`. The worktree has unrelated untracked benchmark evidence; no worktree files were changed.

## Findings

### I-01 — post-filter survivor delivery

run_pipeline applies Project/Filter/Limit/Observe to each input ArrayRef then invokes consume(array); filter_array obtains one LocalSelection and asks for at most array.len().max(1) selected rows in a single emitted selection batch, rejecting a second emission. No cross-input callback accumulation is shown at this boundary.

**E05:** `shardloom-vortex/src/local_primitive_relational_transform.rs:131-138` — `PreparedVortexRelational::run_pipeline batch_rows cap`

```text
        let mut ranges = ReservedVec::new(context.memory())?;
        let batch_rows = stages
            .iter()
            .fold(batch_rows, |rows, stage| match &stage.kind {
                PipelineKind::ApplicationBatch(spec) => rows.min(spec.max_batch_rows()),
                _ => rows,
            });
        ranges.reserve(stages.len())?;
```

**E06:** `shardloom-vortex/src/local_primitive_relational_transform.rs:164-213` — `PreparedVortexRelational::run_pipeline stage loop and terminal consume`

```text
            &mut |mut array| {
                let mut observation_index = 0;
                for (index, stage) in stages.iter().enumerate() {
                    context.check_cancelled()?;
                    array = match &stage.kind {
                        PipelineKind::ApplicationBatch(spec) => {
                            spec.execute(&array, &self.session, context, metrics)?
                        }
                        PipelineKind::Project(expressions) => {
                            project_array(&stage.fields, expressions, &array, context)?
                        }
                        PipelineKind::Filter(predicate) => {
                            let Some(selected) =
                                filter_array(predicate, &stage.fields, &array, context)?
                            else {
                                return Ok(());
                            };
                            selected
                        }
                        PipelineKind::Limit { .. } => {
                            let (skip, remaining) = &mut ranges.values[index];
                            let start = (*skip).min(array.len());
                            *skip -= start;
                            let count = (*remaining).min(array.len() - start);
                            *remaining -= count;
                            if count == 0 {
                                return Ok(());
                            }
                            array.slice(start..start + count).map_err(vortex_error)?
                        }
                        PipelineKind::Observe(observation) => {
                            let projected = observation
                                .projection
                                .as_ref()
                                .map(|(fields, expressions)| {
                                    project_array(fields, expressions, &array, context)
                                })
                                .transpose()?;
                            observations.values[observation_index].1.consume(
                                projected.as_ref().unwrap_or(&array),
                                context,
                                batch_rows,
                            )?;
                            observation_index += 1;
                            array
                        }
                    };
                }
                consume(array)
            },
```

**E07:** `shardloom-vortex/src/local_primitive_relational_transform.rs:340-356` — `filter_array`

```text
fn filter_array(
    predicate: &native_relational_expression::Expression,
    fields: &[(String, super::DType)],
    array: &ArrayRef,
    context: &NativeExecutionContext<'_>,
) -> Result<Option<ArrayRef>> {
    let rows = filter_rows(predicate, predicate.filter_recipe(), array, context)?;
    let mut selected = None;
    // Selection cannot produce more rows than this input. Use one native
    // selection batch, preserving its ownership.
    rows.for_each_batch(array, fields, array.len().max(1), context, &mut |batch| {
        if selected.replace(batch).is_some() {
            return Err(failed("streaming selection exceeded its input batch"));
        }
        Ok(())
    })?;
    Ok(selected)
```

**E08:** `shardloom-vortex/src/local_primitive_relational_selection.rs:14-42` — `LocalSelection storage owner and full-source index reservation`

```text
enum Indices {
    Compact(ReservedVec<u16>),
    Wide(ReservedVec<usize>),
}

/// Width is fixed by the complete local source extent, never selected density.
/// All positions remain explicit, ordered and checked before insertion.
pub(super) struct LocalSelection {
    rows: Indices,
    source_rows: usize,
}

impl LocalSelection {
    pub(super) fn new(source_rows: usize, context: &NativeExecutionContext<'_>) -> Result<Self> {
        context.check_cancelled()?;
        let rows = if source_rows <= usize::from(u16::MAX) + 1 {
            let mut rows = ReservedVec::new(context.memory())?;
            rows.reserve(source_rows)?;
            #[cfg(all(test, feature = "vortex-write"))]
            if source_rows != 0 {
                super::selection_observation::owner(source_rows);
            }
            Indices::Compact(rows)
        } else {
            let mut rows = ReservedVec::new(context.memory())?;
            rows.reserve(source_rows)?;
            Indices::Wide(rows)
        };
        Ok(Self { rows, source_rows })
```

### I-02 — join flush and current row batch size

Public for_each_batch uses BATCH_ROWS = 2,048. Join::consume prepares one left Batch and creates Pairs with the supplied batch_rows; push_pair flushes at Pairs.limit, and consume flushes the remainder before returning for that input array. Join Pairs reserves two row-index vectors to that limit.

**E10:** `shardloom-vortex/src/local_primitive_prepared_relational.rs:130-160` — `BATCH_ROWS and ExecutedVortexRelational row/batch fields`

```text
const BATCH_ROWS: usize = 2048;

/// The report and certificate describe the same execution as delivered batches.
pub struct ExecutedVortexRelational {
    /// Actual action-local retention and recursive frontier work.
    pub composition: crate::relational_query::VortexRelationalCompositionReport,
    /// Caller-selected maximum recursive-term evaluations per relation.
    pub recursion_limit: shardloom_core::RecursionLimit,
    /// Complete metrics from this execution. A writer exposes them only after
    /// successful publication; failed actions never return a completed report.
    pub observations: Vec<CompletedVortexRelationalObservation>,
    _observation_metadata: Option<MemoryLease>,
    _pipeline_metadata: [Option<MemoryLease>; 4],
    _file_scan_metadata: Option<MemoryLease>,
    /// A primitive report only when one file kernel produced the entire result.
    /// Composed plans, projections, memory and streaming inputs use the complete
    /// pipeline certificate; nested kernels contribute their own evidence there.
    pub primitive_execution: Option<super::VortexLocalPrimitiveExecutionReport>,
    /// Legacy field retained for report compatibility. Identifies the unified
    /// native operator pipeline; it is not a performance attribution.
    pub provider_selection_reason: &'static str,
    pub resources: shardloom_core::ExecutionResources,
    /// Immutable semantics selected by the owner of this execution.
    pub float_policy: shardloom_core::FloatPolicy,
    pub output_rows: u64,
    pub output_batches: u64,
    pub max_output_batch_rows: usize,
    pub output_buffer_bytes: u64,
    pub scan_rows_delivered: u64,
    pub scan_batches: u64,
    pub prepared_sources: usize,
```

**E11:** `shardloom-vortex/src/local_primitive_prepared_relational.rs:1302-1314` — `PreparedVortexRelational::for_each_batch default batch limit`

```text
    pub fn for_each_batch(
        &self,
        cancellation: &CancellationToken,
        consume: impl FnMut(ArrayRef, &NativeExecutionContext<'_>) -> Result<()>,
    ) -> Result<ExecutedVortexRelational> {
        self.for_each_batch_with_input(
            cancellation,
            BATCH_ROWS,
            FileScanBatching::Native,
            None,
            consume,
        )
    }
```

**E13:** `shardloom-vortex/src/local_primitives/native_relational_join.rs:160-175` — `Join::consume creates Batch and Pairs(limit=batch_rows)`

```text
    pub(super) fn consume(
        &mut self,
        array: ArrayRef,
        context: &NativeExecutionContext<'_>,
        batch_rows: usize,
        consume: &mut dyn FnMut(ArrayRef) -> Result<()>,
    ) -> Result<u64> {
        if batch_rows == 0 {
            return Err(failed("output batch rows must be positive"));
        }
        self.finish_build(context)?;
        let left = Batch::new(array, &self.spec.left_keys, context)?;
        if self.spec.condition.is_some() {
            return self.consume_condition(&left, context, batch_rows, consume);
        }
        let mut pairs = Pairs::new(batch_rows, context.memory())?;
```

**E14:** `shardloom-vortex/src/local_primitives/native_relational_join.rs:253-261` — `Join::consume flushes remainder at end of its input array`

```text
        self.flush(
            Some(&left.array),
            &mut pairs,
            &mut written,
            context,
            consume,
        )?;
        context.check_cancelled()?;
        Ok(written)
```

**E15:** `shardloom-vortex/src/local_primitives/native_relational_join.rs:295-324` — `Join::push_pair capacity flush and flush dispatch`

```text
    #[allow(clippy::too_many_arguments)]
    fn push_pair(
        &self,
        left: Option<&ArrayRef>,
        left_row: Option<usize>,
        right_row: Option<usize>,
        pairs: &mut Pairs,
        written: &mut u64,
        context: &NativeExecutionContext<'_>,
        consume: &mut dyn FnMut(ArrayRef) -> Result<()>,
    ) -> Result<()> {
        pairs.left.values.push(left_row);
        pairs.right.values.push(right_row);
        if pairs.left.values.len() == pairs.limit {
            self.flush(left, pairs, written, context, consume)?;
        }
        Ok(())
    }

    fn flush(
        &self,
        left: Option<&ArrayRef>,
        pairs: &mut Pairs,
        written: &mut u64,
        context: &NativeExecutionContext<'_>,
        consume: &mut dyn FnMut(ArrayRef) -> Result<()>,
    ) -> Result<()> {
        self.spec
            .flush(&self.right, left, pairs, written, context, consume)
    }
```

**E16:** `shardloom-vortex/src/local_primitives/native_relational_join.rs:487-503` — `Pairs::new reserve of left/right row vectors to limit`

```text
struct Pairs {
    left: ReservedVec<Option<usize>>,
    right: ReservedVec<Option<usize>>,
    limit: usize,
}
impl Pairs {
    fn new(limit: usize, memory: &LiveMemoryPool) -> Result<Self> {
        if limit == 0 {
            return Err(failed("output batch rows must be positive"));
        }
        let mut left = ReservedVec::new(memory)?;
        let mut right = ReservedVec::new(memory)?;
        left.reserve(limit)?;
        right.reserve(limit)?;
        Ok(Self { left, right, limit })
    }
}
```

### I-03 — downstream consumer preparation

native_relational_batch::Batch::new chooses Preparation::Hash. from_names obtains each named logical field and constructs a KeyColumn with the active memory pool, cancellation token and float policy. In the join, Batch::new is called for each consume array.

**E13:** `shardloom-vortex/src/local_primitives/native_relational_join.rs:160-175` — `Join::consume creates Batch and Pairs(limit=batch_rows)`

```text
    pub(super) fn consume(
        &mut self,
        array: ArrayRef,
        context: &NativeExecutionContext<'_>,
        batch_rows: usize,
        consume: &mut dyn FnMut(ArrayRef) -> Result<()>,
    ) -> Result<u64> {
        if batch_rows == 0 {
            return Err(failed("output batch rows must be positive"));
        }
        self.finish_build(context)?;
        let left = Batch::new(array, &self.spec.left_keys, context)?;
        if self.spec.condition.is_some() {
            return self.consume_condition(&left, context, batch_rows, consume);
        }
        let mut pairs = Pairs::new(batch_rows, context.memory())?;
```

**E17:** `shardloom-vortex/src/local_primitives/native_relational_batch.rs:33-53` — `Batch::new uses hash preparation`

```text
pub(super) struct Batch {
    pub(super) array: ArrayRef,
    keys: ReservedVec<KeyColumn>,
}

impl Batch {
    pub(super) fn from_prepared_keys(array: ArrayRef, keys: ReservedVec<KeyColumn>) -> Self {
        Self { array, keys }
    }

    pub(super) fn new(
        array: ArrayRef,
        key_names: &[String],
        context: &NativeExecutionContext<'_>,
    ) -> Result<Self> {
        Self::from_names(
            array,
            key_names.iter().map(String::as_str),
            context,
            Preparation::Hash,
        )
```

**E18:** `shardloom-vortex/src/local_primitives/native_relational_batch.rs:90-129` — `Batch::from_names builds prepared KeyColumn owners`

```text
    fn from_names<'a>(
        array: ArrayRef,
        key_names: impl ExactSizeIterator<Item = &'a str>,
        context: &NativeExecutionContext<'_>,
        purpose: Preparation,
    ) -> Result<Self> {
        let mut keys = ReservedVec::new(context.memory())?;
        keys.reserve(key_names.len())?;
        let mut execution = context.native_session().create_execution_ctx();
        for name in key_names {
            context.check_cancelled()?;
            let column = logical_field_from_native_array(&array, name)?;
            let prepare = match purpose {
                Preparation::Values => KeyColumn::values_with_float_policy,
                Preparation::Hash => KeyColumn::new_with_float_policy,
                Preparation::HashOnDemand => KeyColumn::for_membership_with_float_policy,
            };
            keys.values.push(prepare(
                &column,
                &mut execution,
                context.memory(),
                context.cancellation(),
                context.float_policy(),
            )?);
            #[cfg(all(test, debug_assertions))]
            if matches!(purpose, Preparation::HashOnDemand) {
                super::native_relational_observation::record(|counts| {
                    counts.membership_key_preparations.push(
                        super::native_relational_observation::MembershipKeyPreparation {
                            name: name.into(),
                            rows: column.len(),
                            input_encoding: column.encoding_id().to_string(),
                            dtype: column.dtype().to_string(),
                            numeric: matches!(keys.values.last(), Some(KeyColumn::Numeric(_))),
                        },
                    );
                });
            }
        }
        Ok(Self { array, keys })
```

### I-04 — dictionary and FSST representation ownership

VariableColumn resolves Dict to its values domain and codes, executes/prepares the domain as VarBinViewArray and codes as PrimitiveArray owner, and exposes dictionary_parts(). Dictionary expression output can transform referenced domain representatives, copy codes into separately credited output, and construct a new DictArray. The FSST contains helper borrows an FSST view from the input and passes it to Vortex LikeKernel; the FSST fixture tests count and selected row indices.

**E19:** `shardloom-vortex/src/local_primitives/native_relational_keys.rs:851-905` — `VariableColumn::new retains dictionary domain and prepared code owner`

```text
impl VariableColumn {
    fn new(
        array: &ArrayRef,
        context: &mut ExecutionCtx,
        memory: &LiveMemoryPool,
        cancellation: &CancellationToken,
        purpose: Preparation,
    ) -> Result<Self> {
        let binary = matches!(array.dtype(), DType::Binary(_));
        let dictionary = array.as_opt::<Dict>();
        let domain = dictionary
            .as_ref()
            .map_or_else(|| array.clone(), |dict| dict.values().clone());
        let mut hashes = if purpose == Preparation::Hash {
            Some(VariableHashes::new(domain.len(), memory)?)
        } else {
            None
        };
        #[cfg(all(test, debug_assertions))]
        super::native_relational_observation::record(|counts| {
            counts.variable_domains += 1;
            counts.variable_domain_values += domain.len() as u64;
        });
        let values = domain
            .clone()
            .execute::<VarBinViewArray>(context)
            .map_err(vortex_error)?;
        if values.dtype() != domain.dtype() || values.len() != domain.len() {
            return Err(failed(
                "text execution changed dtype or value-domain length",
            ));
        }
        let valid = values
            .varbinview_validity()
            .execute_mask(values.len(), context)
            .map_err(vortex_error)?;
        let codes = dictionary
            .map(|dict| {
                let source = dict.codes();
                let codes = source
                    .clone()
                    .execute::<PrimitiveArray>(context)
                    .map_err(vortex_error)?;
                if codes.dtype() != source.dtype() || codes.len() != array.len() {
                    return Err(failed(
                        "dictionary code execution changed dtype or row count",
                    ));
                }
                let owner = NativeNumericOwner::new(codes, context)?;
                if !owner.is_integer() {
                    return Err(failed("dictionary codes must be integers"));
                }
                Ok(owner)
            })
            .transpose()?;
```

**E20:** `shardloom-vortex/src/local_primitives/native_relational_keys.rs:979-992` — `VariableColumn::dictionary_parts and borrowed UTF8 access`

```text
    /// The existing prepared codes and value-domain length; no row expansion.
    pub(super) fn dictionary_parts(&self) -> Option<(&NativeNumericOwner, usize)> {
        self.codes.as_ref().map(|codes| (codes, self.values.len()))
    }

    /// Borrow only within the prepared native owner. The expression result
    /// builder copies any returned text into its independently credited output.
    pub(super) fn utf8_at(&self, row: usize) -> Result<Option<&str>> {
        if self.binary || row >= self.rows {
            return Err(failed("UTF8 value access exceeds its prepared text domain"));
        }
        self.index(row)?
            .map(|index| self.values.utf8_slice_at(index).map_err(vortex_error))
            .transpose()
```

**E21:** `shardloom-vortex/src/local_primitives/native_relational_dictionary_expression.rs:38-91` — `dictionary expression Output::prepare`

```text
    pub(super) fn prepare(
        values: &'a VariableColumn,
        rows: usize,
        context: &NativeExecutionContext<'_>,
    ) -> Result<Self> {
        let mut output = Self {
            dictionary: None,
            rows,
            work: Work {
                batches: 1,
                logical_rows: rows as u64,
                ..Work::default()
            },
        };
        let Some((codes, domain)) = values.dictionary_parts() else {
            output.work.no_dictionary_batches = 1;
            return Ok(output);
        };
        if domain >= rows {
            output.work.no_reduction_batches = 1;
            return Ok(output);
        }
        let Some(metadata) = context.memory().try_reserve(DICTIONARY_METADATA_BYTES)? else {
            output.work.capacity_declines = 1;
            return Ok(output);
        };
        let Some(mut representatives) = ReservedVec::try_with_capacity(context.memory(), domain)?
        else {
            output.work.capacity_declines = 1;
            return Ok(output);
        };
        representatives.values.resize(domain, UNREFERENCED);
        for row in 0..rows {
            if row.is_multiple_of(1024) {
                context.check_cancelled()?;
            }
            // Use the same observed-code and null-value admission as the row
            // kernel. Invalid codes are errors, never optional strategy refusals.
            if let Some(index) = values.index(row)?
                && representatives.values[index] == UNREFERENCED
            {
                representatives.values[index] = row;
                output.work.referenced_values += 1;
            }
        }
        output.work.dictionary_batches = 1;
        output.work.domain_slots = domain as u64;
        output.work.code_rows_inspected = rows as u64;
        output.dictionary = Some(Dictionary {
            codes,
            representatives,
            metadata,
        });
        Ok(output)
```

**E22:** `shardloom-vortex/src/local_primitives/native_relational_dictionary_expression.rs:94-149` — `dictionary expression Output::build copies codes and creates derived DictArray`

```text
    pub(super) fn build<'v>(
        mut self,
        expression: &Expression,
        context: &NativeExecutionContext<'_>,
        mut value: impl FnMut(usize) -> Result<Value<'v>>,
    ) -> Result<ArrayRef> {
        let result = if let Some(dictionary) = self.dictionary {
            let allocator = crate::owned_buffers::with_credit(
                context.native_session().host_allocator(),
                dictionary.metadata,
            );
            let transformed = result_batch::build_expression_column(
                &expression.dtype,
                dictionary.representatives.values.len(),
                &allocator,
                context.float_policy(),
                |index| {
                    if index.is_multiple_of(1024) {
                        context.check_cancelled()?;
                    }
                    let row = dictionary.representatives.values[index];
                    if row == UNREFERENCED {
                        return placeholder(&expression.dtype);
                    }
                    let result = value(row)?;
                    self.work.dictionary_kernel_calls += u64::from(!matches!(result, Value::Null));
                    Ok(result)
                },
            )?;
            // Reuse the existing original-width copier. No source allocation or
            // private provider child slot is retained by the derived dictionary.
            let codes = result_batch::copy_numeric_column(
                dictionary.codes.primitive().dtype(),
                dictionary.codes.primitive(),
                dictionary.codes.validity(),
                &allocator,
                context.float_policy(),
                || context.check_cancelled(),
            )?;
            self.work.code_rows_copied = self.rows as u64;
            self.work.retained_dictionary_rows = self.rows as u64;
            DictArray::try_new(codes, transformed)
                .map_err(vortex_error)?
                .into_array()
        } else {
            let result = expression.build(self.rows, context, |row| {
                let result = value(row)?;
                self.work.row_kernel_calls += u64::from(!matches!(result, Value::Null));
                Ok(result)
            })?;
            self.work.row_output_rows = self.rows as u64;
            result
        };
        context.check_cancelled()?;
        context.record_dictionary_expression(&self.work)?;
        Ok(result)
```

**E24:** `shardloom-vortex/src/native_dictionary_expression.rs:53-89` — `native dictionary expression certificate key emission`

```text
    pub(crate) fn append(&self, certificate: &mut NativeIoCertificate) {
        use std::fmt::Write as _;
        if self.batches == 0 {
            return;
        }
        let proof = &mut certificate.source_pushdown_report.proof_basis;
        macro_rules! append {
            ($($field:ident),+ $(,)?) => {$(
                write!(proof, " dictionary_text_{}={}", stringify!($field), self.$field)
                    .expect("String writes cannot fail");
            )+};
        }
        append!(
            batches,
            logical_rows,
            dictionary_batches,
            domain_slots,
            referenced_values,
            dictionary_kernel_calls,
            code_rows_inspected,
            code_rows_copied,
            retained_dictionary_rows,
            row_output_rows,
            row_kernel_calls,
            no_dictionary_batches,
            no_reduction_batches,
            capacity_declines
        );
        proof.push_str(
            " dictionary_text_contract=v1;vortex_0.93.0_DictArray;strict_prepared_utf8_kernels;complete_domain_validation;referenced_values_only;independent_code_and_value_ownership;exact_consumer_value_equality;counts_are_owner_invocations_not_unique_query_rows;decoder_bytes_and_process_rss_unobserved;no_external_engine",
        );
        if self.dictionary_batches > 0 {
            certificate
                .source_pushdown_report
                .accepted_operations
                .push("native_dictionary_text_expression".into());
        }
```

**E25:** `shardloom-vortex/src/local_primitives.rs:13395-13433` — `fast_utf8_contains_fsst_matches`

```text
fn fast_utf8_contains_fsst_matches(
    array: &vortex::array::ArrayRef,
    needle: &str,
    negated: bool,
    ctx: &mut vortex::array::ExecutionCtx,
) -> Result<Option<Vec<bool>>> {
    use vortex::array::IntoArray as _;
    use vortex::array::arrays::ConstantArray;
    use vortex::array::arrays::bool::BoolArrayExt as _;
    use vortex::array::scalar_fn::fns::like::{LikeKernel, LikeOptions};
    use vortex::array::validity::Validity;

    let Some(fsst) = array.as_opt::<vortex::encodings::fsst::FSST>() else {
        return Ok(None);
    };
    let pattern = contains_literal_like_pattern(needle);
    let pattern = ConstantArray::new(pattern.as_str(), array.len()).into_array();
    let Some(result) = <vortex::encodings::fsst::FSST as LikeKernel>::like(
        fsst,
        &pattern,
        LikeOptions {
            negated,
            case_insensitive: false,
        },
        ctx,
    )
    .map_err(vortex_error)?
    else {
        return Ok(None);
    };
    let Some(mask) = result.as_opt::<vortex::array::arrays::Bool>() else {
        return Ok(None);
    };
    match mask.validity().map_err(vortex_error)? {
        Validity::NonNullable | Validity::AllValid => {}
        Validity::AllInvalid | Validity::Array(_) => return Ok(None),
    }
    Ok(Some(mask.to_bit_buffer().iter().take(mask.len()).collect()))
}
```

**E26:** `shardloom-vortex/src/local_primitives.rs:67012-67065` — `fsst_string_contains_uses_vortex_like_kernel_without_materialized_rows test`

```text
    #[test]
    fn fsst_string_contains_uses_vortex_like_kernel_without_materialized_rows() {
        use vortex::array::IntoArray as _;
        use vortex::array::VortexSessionExecute as _;

        use vortex::array::arrays::varbin::builder::VarBinBuilder;
        use vortex::array::dtype::{DType, Nullability};
        use vortex::encodings::fsst::{fsst_compress, fsst_train_compressor};
        use vortex::mask::Mask;

        let mut input = VarBinBuilder::<i32>::with_capacity_in(
            DType::Utf8(Nullability::NonNullable),
            5,
            &vortex::buffer::BufferAllocatorRef::statically_allocated(),
        );
        input.append_value(b"https://google.example/a");
        input.append_value(b"https://maps.example/b");
        input.append_value(b"https://mail.google.example/c");
        input.append_value(b"https://example.test/d");
        input.append_value(b"https://google.example/e");
        let input = input.finish_into_varbin().into_array();
        let mut ctx = vortex::session::VortexSession::empty().create_execution_ctx();
        let compressor = fsst_train_compressor(&input, &mut ctx).expect("train FSST compressor");
        let compressed = fsst_compress(&input, &compressor, &mut ctx)
            .expect("compress FSST array")
            .into_array();

        assert!(compressed.is::<vortex::encodings::fsst::FSST>());
        assert_eq!(
            fast_utf8_contains_count_from_array(
                &compressed,
                "google",
                false,
                &mut vortex::array::VortexSessionExecute::create_execution_ctx(
                    &vortex::session::VortexSession::empty(),
                ),
            )
            .expect("contains count"),
            Some(3)
        );
        assert_eq!(
            fast_utf8_contains_row_indices_from_array(
                &compressed,
                "google",
                false,
                0,
                &mut vortex::array::VortexSessionExecute::create_execution_ctx(
                    &vortex::session::VortexSession::empty(),
                ),
            )
            .expect("contains row indices"),
            Some(vec![0, 2, 4])
        );
        assert_eq!(
```

### I-05 — memory admission and backpressure owners

LocalSelection stores indices in ReservedVec and reserves for the full source extent, choosing u16 ordinals through 65,536 rows and usize above. Pairs reserves left/right vectors to the batch limit. Dictionary expression preparation uses optional memory reservations and can record capacity declines; ReservedVec itself reserves lease bytes before vector growth. The cited filter boundary does not retain a cross-callback queue or report pinned source backing bytes.

**E08:** `shardloom-vortex/src/local_primitive_relational_selection.rs:14-42` — `LocalSelection storage owner and full-source index reservation`

```text
enum Indices {
    Compact(ReservedVec<u16>),
    Wide(ReservedVec<usize>),
}

/// Width is fixed by the complete local source extent, never selected density.
/// All positions remain explicit, ordered and checked before insertion.
pub(super) struct LocalSelection {
    rows: Indices,
    source_rows: usize,
}

impl LocalSelection {
    pub(super) fn new(source_rows: usize, context: &NativeExecutionContext<'_>) -> Result<Self> {
        context.check_cancelled()?;
        let rows = if source_rows <= usize::from(u16::MAX) + 1 {
            let mut rows = ReservedVec::new(context.memory())?;
            rows.reserve(source_rows)?;
            #[cfg(all(test, feature = "vortex-write"))]
            if source_rows != 0 {
                super::selection_observation::owner(source_rows);
            }
            Indices::Compact(rows)
        } else {
            let mut rows = ReservedVec::new(context.memory())?;
            rows.reserve(source_rows)?;
            Indices::Wide(rows)
        };
        Ok(Self { rows, source_rows })
```

**E16:** `shardloom-vortex/src/local_primitives/native_relational_join.rs:487-503` — `Pairs::new reserve of left/right row vectors to limit`

```text
struct Pairs {
    left: ReservedVec<Option<usize>>,
    right: ReservedVec<Option<usize>>,
    limit: usize,
}
impl Pairs {
    fn new(limit: usize, memory: &LiveMemoryPool) -> Result<Self> {
        if limit == 0 {
            return Err(failed("output batch rows must be positive"));
        }
        let mut left = ReservedVec::new(memory)?;
        let mut right = ReservedVec::new(memory)?;
        left.reserve(limit)?;
        right.reserve(limit)?;
        Ok(Self { left, right, limit })
    }
}
```

**E22:** `shardloom-vortex/src/local_primitives/native_relational_dictionary_expression.rs:94-149` — `dictionary expression Output::build copies codes and creates derived DictArray`

```text
    pub(super) fn build<'v>(
        mut self,
        expression: &Expression,
        context: &NativeExecutionContext<'_>,
        mut value: impl FnMut(usize) -> Result<Value<'v>>,
    ) -> Result<ArrayRef> {
        let result = if let Some(dictionary) = self.dictionary {
            let allocator = crate::owned_buffers::with_credit(
                context.native_session().host_allocator(),
                dictionary.metadata,
            );
            let transformed = result_batch::build_expression_column(
                &expression.dtype,
                dictionary.representatives.values.len(),
                &allocator,
                context.float_policy(),
                |index| {
                    if index.is_multiple_of(1024) {
                        context.check_cancelled()?;
                    }
                    let row = dictionary.representatives.values[index];
                    if row == UNREFERENCED {
                        return placeholder(&expression.dtype);
                    }
                    let result = value(row)?;
                    self.work.dictionary_kernel_calls += u64::from(!matches!(result, Value::Null));
                    Ok(result)
                },
            )?;
            // Reuse the existing original-width copier. No source allocation or
            // private provider child slot is retained by the derived dictionary.
            let codes = result_batch::copy_numeric_column(
                dictionary.codes.primitive().dtype(),
                dictionary.codes.primitive(),
                dictionary.codes.validity(),
                &allocator,
                context.float_policy(),
                || context.check_cancelled(),
            )?;
            self.work.code_rows_copied = self.rows as u64;
            self.work.retained_dictionary_rows = self.rows as u64;
            DictArray::try_new(codes, transformed)
                .map_err(vortex_error)?
                .into_array()
        } else {
            let result = expression.build(self.rows, context, |row| {
                let result = value(row)?;
                self.work.row_kernel_calls += u64::from(!matches!(result, Value::Null));
                Ok(result)
            })?;
            self.work.row_output_rows = self.rows as u64;
            result
        };
        context.check_cancelled()?;
        context.record_dictionary_expression(&self.work)?;
        Ok(result)
```

**E27:** `shardloom-vortex/src/local_primitives/native_capacity.rs:20-49` — `ReservedVec credit-bearing container and optional capacity admission`

```text
/// Values drop before the container credit; contained payloads own their credits.
pub(crate) struct ReservedVec<T> {
    pub(crate) values: Vec<T>,
    lease: MemoryLease,
}

impl<T> ReservedVec<T> {
    pub(crate) fn new(memory: &LiveMemoryPool) -> Result<Self> {
        Ok(Self {
            values: Vec::new(),
            lease: memory.reserve(0)?,
        })
    }

    /// Admit a fresh optional container atomically, without treating allocator
    /// or arithmetic errors as an optional memory-budget decision.
    pub(crate) fn try_with_capacity(
        memory: &LiveMemoryPool,
        capacity: usize,
    ) -> Result<Option<Self>> {
        let Some(lease) = memory.try_reserve(bytes::<T>(capacity)?)? else {
            return Ok(None);
        };
        let mut values = Vec::new();
        values.try_reserve_exact(capacity).map_err(vortex_error)?;
        if values.capacity() > capacity {
            return Err(failed());
        }
        Ok(Some(Self { values, lease }))
    }
```

**E28:** `shardloom-vortex/src/local_primitives/native_capacity.rs:55-89` — `ReservedVec growth reservation before allocation and credited push`

```text
    pub(crate) fn reserve(&mut self, additional: usize) -> Result<()> {
        let needed = self
            .values
            .len()
            .checked_add(additional)
            .ok_or_else(failed)?;
        if needed <= self.values.capacity() {
            return Ok(());
        }
        let capacity = self
            .values
            .capacity()
            .max(4)
            .checked_mul(2)
            .ok_or_else(failed)?
            .max(needed);
        let new_bytes = bytes::<T>(capacity)?;
        self.lease.resize(
            self.lease
                .bytes()
                .checked_add(new_bytes)
                .ok_or_else(failed)?,
        )?;
        self.values
            .try_reserve_exact(capacity - self.values.len())
            .map_err(vortex_error)?;
        if self.values.capacity() > capacity {
            return Err(failed());
        }
        self.lease.resize(new_bytes)
    }

    pub(crate) fn push(&mut self, value: T) -> Result<()> {
        self.reserve_one()?;
        self.values.push(value);
```

### I-06 — existing separable counters

ExecutedVortexRelational exposes output_rows, output_batches, max_output_batch_rows, output_buffer_bytes, scan_rows_delivered and scan_batches. NativeFileSourceObservation separately reports segment_requests, successful completed_read_requests and completed_read_bytes (including coalescing gaps/repeats, not unique/decode/device bytes). The text IO layout inventory separately reports layout rows, zone_rows and zone_count. Native dictionary expression Work separately carries batches, logical_rows, dictionary-domain and code-work fields.

**E10:** `shardloom-vortex/src/local_primitive_prepared_relational.rs:130-160` — `BATCH_ROWS and ExecutedVortexRelational row/batch fields`

```text
const BATCH_ROWS: usize = 2048;

/// The report and certificate describe the same execution as delivered batches.
pub struct ExecutedVortexRelational {
    /// Actual action-local retention and recursive frontier work.
    pub composition: crate::relational_query::VortexRelationalCompositionReport,
    /// Caller-selected maximum recursive-term evaluations per relation.
    pub recursion_limit: shardloom_core::RecursionLimit,
    /// Complete metrics from this execution. A writer exposes them only after
    /// successful publication; failed actions never return a completed report.
    pub observations: Vec<CompletedVortexRelationalObservation>,
    _observation_metadata: Option<MemoryLease>,
    _pipeline_metadata: [Option<MemoryLease>; 4],
    _file_scan_metadata: Option<MemoryLease>,
    /// A primitive report only when one file kernel produced the entire result.
    /// Composed plans, projections, memory and streaming inputs use the complete
    /// pipeline certificate; nested kernels contribute their own evidence there.
    pub primitive_execution: Option<super::VortexLocalPrimitiveExecutionReport>,
    /// Legacy field retained for report compatibility. Identifies the unified
    /// native operator pipeline; it is not a performance attribution.
    pub provider_selection_reason: &'static str,
    pub resources: shardloom_core::ExecutionResources,
    /// Immutable semantics selected by the owner of this execution.
    pub float_policy: shardloom_core::FloatPolicy,
    pub output_rows: u64,
    pub output_batches: u64,
    pub max_output_batch_rows: usize,
    pub output_buffer_bytes: u64,
    pub scan_rows_delivered: u64,
    pub scan_batches: u64,
    pub prepared_sources: usize,
```

**E12:** `shardloom-vortex/src/local_primitive_prepared_relational.rs:1516-1545` — `consume_bound emit closure counting output rows/batches/bytes`

```text
        let mut emit = |array: ArrayRef| {
            context.check_cancelled()?;
            if array.dtype() != &dtype || array.len() > batch_rows {
                return Err(failed("producer changed its bound schema or batch size"));
            }
            let array = if nested || !self.batch_sources.is_empty() {
                super::native_payload::detach_with_unobserved_fields(
                    &array,
                    &unobserved_fields.values,
                    context,
                )?
            } else {
                array
            };
            rows = rows
                .checked_add(array.len() as u64)
                .ok_or_else(|| failed("output row count overflow"))?;
            batches = batches
                .checked_add(1)
                .ok_or_else(|| failed("output batch count overflow"))?;
            bytes = bytes
                .checked_add(array.nbytes())
                .ok_or_else(|| failed("output byte count overflow"))?;
            max_rows = max_rows.max(array.len());
            emitted.set(true);
            consume(array)?;
            context.check_cancelled()
        };
        self.run(root, context, metrics, batch_rows, None, &mut emit)?;
        let provider = metrics.pipeline.take_root_execution(root);
```

**E23:** `shardloom-vortex/src/native_dictionary_expression.rs:5-21` — `native dictionary expression Work counters`

```text
#[derive(Default)]
pub(crate) struct Work {
    pub(crate) batches: u64,
    pub(crate) logical_rows: u64,
    pub(crate) dictionary_batches: u64,
    pub(crate) domain_slots: u64,
    pub(crate) referenced_values: u64,
    pub(crate) dictionary_kernel_calls: u64,
    pub(crate) code_rows_inspected: u64,
    pub(crate) code_rows_copied: u64,
    pub(crate) retained_dictionary_rows: u64,
    pub(crate) row_output_rows: u64,
    pub(crate) row_kernel_calls: u64,
    pub(crate) no_dictionary_batches: u64,
    pub(crate) no_reduction_batches: u64,
    pub(crate) capacity_declines: u64,
}
```

**E29:** `shardloom-core/src/native_file_scan.rs:112-126` — `NativeFileSourceObservation completed positional reads`

```text
/// Reads completed under one held file generation during the current operation.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NativeFileSourceObservation {
    pub source_uri: String,
    /// Descriptor/path metadata identity, not a content checksum or snapshot.
    pub generation_fingerprint: String,
    pub segment_requests: u64,
    /// Successful positional read calls; includes repeated and coalesced reads.
    pub completed_read_requests: u64,
    /// Successful requested-range bytes, including coalescing gaps and repeats.
    /// This does not measure unique bytes, decoded bytes, or storage-device I/O.
    pub completed_read_bytes: u64,
    /// Actual current-operation immutable segment reuse, separate from reads.
    pub segment_reuse: NativeSourceSegmentReuseWork,
}
```

**E30:** `shardloom-vortex/src/vortex_ingest_text_io_tests.rs:487-495` — `Persisted layout-node logical rows and Zoned zone_rows/zone_count`

```text
        let flat_id = visit.layout.as_opt::<Flat>().map(|flat| *flat.segment_id());
        let zoned = visit.layout.as_opt::<Zoned>();
        nodes.push(json!({
            "path": visit.path, "column": visit.column, "auxiliary": visit.auxiliary,
            "row_offset": visit.row_offset, "rows": visit.layout.row_count(),
            "flat_segment_id": flat_id,
            "zone_rows": zoned.map(vortex::layout::Layout::<Zoned>::zone_len),
            "zone_count": zoned.map(vortex::layout::Layout::<Zoned>::nzones),
        }));
```

## Unobserved

- **cross-callback survivor batching:** No owner that retains filter/join survivor selections across separate input callbacks was identified in the cited transform/join path; the inspected path forwards selected arrays in callback scope and join Pairs are local to one Join::consume call.
- **pinned backing bytes at survivor boundary:** No counter or byte estimator for backing allocations retained by a queued cross-callback survivor selection appears in the cited source path. Existing `output_buffer_bytes` measures emitted arrays; it is not identified as pinned input backing bytes.
- **consumer preparation invocations:** The public relational report exposes output batch counts, not an explicit downstream Batch::new/key-preparation invocation count. Dictionary-expression Work has separate domain/code counters; it is a different owner and is documented as owner-invocation counts rather than unique query rows.
- **logical zones tied to the same scan execution:** The cited text IO inventory reports per-layout `zone_rows` and `zone_count`; the cited sources do not join those values to the same operation’s completed read and downstream preparation counters.
- **FSST lifetime across consumer batches:** The FSST helper invokes Vortex LikeKernel on an FSST view and returns Boolean match results; cross-batch matcher/table reuse or pinned FSST backing-byte ownership is not observed in the cited code.

## Source blob SHA-256

SHA-256 is computed over the exact UTF-8 bytes emitted by `git show` for the pinned commit.

- `docs/architecture/native-metadata-encoded-consumer-investigations-2026-11-13.md` — `f25887d73435011022748a165cc8900fc34b5da30dc3b60b8fdfc259df19a5a7`
- `docs/architecture/native-shared-pipeline-investigations-2026-11-10.md` — `822c9c81188cf59a52224d7d9b11570304988692aa275090c382f4a4bfca6cb4`
- `docs/architecture/phased-execution-plan.md` — `314ed19db02eee2a6641457e8fced66748cfaed4e60a714059c743f40f454ca8`
- `shardloom-vortex/src/local_primitive_relational_transform.rs` — `f46925cbb9c02037bc331842a0d482564d87f1a15506bcb7fc56ea0f2e1716eb`
- `shardloom-vortex/src/local_primitive_relational_selection.rs` — `66be86d336f88a6a3da3233a4f94d0d7a9156f976d5be2781949b536f98cbbf9`
- `shardloom-vortex/src/local_primitive_prepared_relational.rs` — `1b61554aee847006db5fdfe757c3021801ff9ad99b0382d95b592c9b05c41ed6`
- `shardloom-vortex/src/local_primitives/native_relational_join.rs` — `041c6e8977833bb69d487fe91348a03baee2ec2172991e8c82f81298e8cdde06`
- `shardloom-vortex/src/local_primitives/native_relational_batch.rs` — `efcbd18061f459ca9557f728aadf931cc2bba5199650eb1dc59fb23c701ab910`
- `shardloom-vortex/src/local_primitives/native_relational_keys.rs` — `53227a870142ca47b32f4dbfddf16ab5654f48c69035408656aecaaefc8e608b`
- `shardloom-vortex/src/local_primitives/native_relational_dictionary_expression.rs` — `dcf89c38c39e568187627f968bf15779ffb7a62a16612439074a27bb4368e80d`
- `shardloom-vortex/src/native_dictionary_expression.rs` — `7e2865374f927cf0c798375c537359900be0268f049083bc7b961bcacca22a65`
- `shardloom-vortex/src/local_primitives.rs` — `5bea5b46deb2c58dc3632c42d8ab9b1ff59984899a5b42824b1d07f108c2e718`
- `shardloom-vortex/src/local_primitives/native_capacity.rs` — `2d6b9db318b761fe7975dfdcb8f301db8e0fe800e48b31b2e33c378e1dc5a63a`
- `shardloom-core/src/native_file_scan.rs` — `0ca6aec00974aa5ade5197dc74a1b5365235108fe79397aace53492fdf465344`
- `shardloom-vortex/src/vortex_ingest_text_io_tests.rs` — `ea2cb6b8aafa1de81dbacc4ae20afb5ea8bc28a2fff107b4c27477f3b036e9d0`

## Limits

- 15 source/documentation files and 30 literal excerpts.
- No runtime, timing, code-change, or performance claim.
