//! Duplicate-preserving native joins with a retained build side and bounded output.

use super::{
    logical_field_from_native_array,
    native_capacity::ReservedVec,
    native_relational_batch::{Batch, Table, failed, index_array, take_column},
    native_relational_expression::Expression,
    native_relational_index::RowIndex,
    native_relational_set::RowSet,
    result_batch, vortex_error,
};
use crate::{
    relational_query::{VortexRelationalJoinKind as Kind, VortexRelationalSide as Side},
    resident_session::NativeExecutionContext,
};
use shardloom_core::Result;
use shardloom_exec::live_memory::LiveMemoryPool;
use vortex::array::{
    ArrayRef, IntoArray as _,
    arrays::StructArray,
    dtype::{DType, FieldNames},
    memory::HostMemorySessionExt as _,
    validity::Validity,
};

pub(super) struct Spec {
    pub(super) kind: Kind,
    /// When present, the last key is ordered and preceding keys partition it.
    pub(super) asof: Option<crate::relational_query::VortexRelationalAsOfOptions>,
    pub(super) left_keys: Vec<String>,
    pub(super) right_keys: Vec<String>,
    pub(super) right_key_fields: Vec<(String, DType)>,
    pub(super) fields: Vec<(String, DType)>,
    pub(super) columns: Vec<(Side, String)>,
    /// Prepared inputs preserve checks for every declared selected column.
    /// This mask controls only which checked payloads reach the consumer.
    pub(super) retained: Option<Vec<bool>>,
    pub(super) condition: Option<Condition>,
}

pub(super) struct Condition {
    pub(super) expression: Expression,
    pub(super) fields: Vec<(String, DType)>,
    pub(super) columns: Vec<(Side, String)>,
}

#[path = "native_relational_asof_join.rs"]
pub(super) mod asof;
#[path = "native_relational_join_condition.rs"]
mod condition;
#[cfg(feature = "vortex-write")]
#[path = "native_relational_join_spill.rs"]
pub(super) mod spill;

pub(super) struct Join<'a> {
    spec: &'a Spec,
    right: Table,
    index: RowIndex,
    matched: ReservedVec<bool>,
    membership: Option<RowSet<'a>>,
    build_finished: bool,
}

impl<'a> Join<'a> {
    pub(super) fn new(spec: &'a Spec, memory: &LiveMemoryPool) -> Result<Self> {
        Ok(Self {
            spec,
            right: Table::new(memory)?,
            index: RowIndex::new(memory)?,
            matched: ReservedVec::new(memory)?,
            build_finished: false,
            membership: (spec.short_circuit()
                && spec.condition.is_none()
                && !spec.right_keys.is_empty())
            .then(|| {
                RowSet::with_nulls_equal(&spec.right_key_fields, &spec.right_keys, false, memory)
            })
            .transpose()?,
        })
    }

    pub(super) fn build(
        &mut self,
        array: ArrayRef,
        context: &NativeExecutionContext<'_>,
        batch_rows: usize,
    ) -> Result<()> {
        context.check_cancelled()?;
        if self.build_finished {
            return Err(failed(
                "native join build is sealed; no further rows may be inserted",
            ));
        }
        if let Some(membership) = &mut self.membership {
            let retained = membership.insert_batch(array, None, context, batch_rows, None)?;
            #[cfg(all(test, debug_assertions))]
            super::native_relational_observation::record(|counts| {
                counts.join_retained_right_rows += retained;
            });
            let _ = retained;
            return context.check_cancelled();
        }
        let batch = Batch::new(array, &self.spec.right_keys, context)?;
        let keep_matches = matches!(self.spec.kind, Kind::Right | Kind::Full);
        if keep_matches {
            self.matched.reserve(batch.array.len())?;
        }
        let rows = self.right.push(batch)?;
        #[cfg(all(test, debug_assertions))]
        super::native_relational_observation::record(|counts| {
            counts.join_retained_right_rows += (rows.end - rows.start) as u64;
        });
        if keep_matches {
            self.matched.values.resize(rows.end, false);
        }
        if !self.spec.right_keys.is_empty() && !rows.is_empty() {
            let (batch, _) = self.right.locate_batch(rows.start)?;
            for row in rows.clone() {
                if row.is_multiple_of(1024) {
                    context.check_cancelled()?;
                }
                let local = row - rows.start;
                if let Some(hash) = batch.hash(local, false)? {
                    self.index
                        .insert(hash, row, context.cancellation(), |old| {
                            if old >= rows.start {
                                batch.equal(local, batch, old - rows.start, false)
                            } else {
                                let (old_batch, old_local) = self.right.locate_batch(old)?;
                                batch.equal(local, old_batch, old_local, false)
                            }
                        })?;
                }
            }
        }
        context.check_cancelled()
    }

    pub(super) fn finish_build(&mut self, context: &NativeExecutionContext<'_>) -> Result<()> {
        context.check_cancelled()?;
        if self.build_finished {
            return Ok(());
        }
        if let Some(membership) = &mut self.membership {
            membership.seal_join(context)?;
        } else if !self.spec.right_keys.is_empty() {
            self.index.seal_join(true, context.cancellation())?;
        }
        self.build_finished = true;
        Ok(())
    }

    pub(super) fn join_work(&self) -> Result<shardloom_core::native_join_work::NativeJoinWork> {
        match &self.membership {
            Some(membership) => membership.join_work(),
            None => self.index.join_work(),
        }
    }

    pub(super) fn consume(
        &mut self,
        array: ArrayRef,
        context: &NativeExecutionContext<'_>,
        batch_rows: usize,
        consume: &mut dyn FnMut(ArrayRef) -> Result<()>,
    ) -> Result<u64> {
        if batch_rows == 0 {
            return Err(failed("output batch rows must be positive"));
        }
        self.finish_build(context)?;
        let left = Batch::new(array, &self.spec.left_keys, context)?;
        if self.spec.condition.is_some() {
            return self.consume_condition(&left, context, batch_rows, consume);
        }
        let mut pairs = Pairs::new(batch_rows, context.memory())?;
        let mut written = 0u64;
        for row in 0..left.array.len() {
            if row.is_multiple_of(1024) {
                context.check_cancelled()?;
            }
            let entry = if self.membership.is_none() {
                left.hash(row, false)?
                    .map(|hash| {
                        self.index.find(hash, context.cancellation(), |right| {
                            self.right.equal_batch(right, &left, row, false)
                        })
                    })
                    .transpose()?
                    .flatten()
            } else {
                None
            };
            let has_match = if let Some(membership) = &self.membership {
                membership.contains(&left, row, context)?
            } else if self.spec.kind == Kind::Cross {
                self.right.rows() > 0
            } else {
                entry.is_some()
            };
            if matches!(self.spec.kind, Kind::LeftSemi | Kind::LeftAnti) {
                if has_match == (self.spec.kind == Kind::LeftSemi) {
                    self.push_pair(
                        Some(&left.array),
                        Some(row),
                        None,
                        &mut pairs,
                        &mut written,
                        context,
                        consume,
                    )?;
                }
                continue;
            }
            if self.spec.kind == Kind::Cross {
                for right in 0..self.right.rows() {
                    self.push_pair(
                        Some(&left.array),
                        Some(row),
                        Some(right),
                        &mut pairs,
                        &mut written,
                        context,
                        consume,
                    )?;
                }
            } else if let Some(entry) = entry {
                for right in self.index.rows(entry)? {
                    if !self.matched.values.is_empty() {
                        self.matched.values[right] = true;
                    }
                    self.push_pair(
                        Some(&left.array),
                        Some(row),
                        Some(right),
                        &mut pairs,
                        &mut written,
                        context,
                        consume,
                    )?;
                }
            } else if matches!(self.spec.kind, Kind::Left | Kind::Full) {
                self.push_pair(
                    Some(&left.array),
                    Some(row),
                    None,
                    &mut pairs,
                    &mut written,
                    context,
                    consume,
                )?;
            }
        }
        self.flush(
            Some(&left.array),
            &mut pairs,
            &mut written,
            context,
            consume,
        )?;
        context.check_cancelled()?;
        Ok(written)
    }

    pub(super) fn finish(
        &self,
        context: &NativeExecutionContext<'_>,
        batch_rows: usize,
        consume: &mut dyn FnMut(ArrayRef) -> Result<()>,
    ) -> Result<u64> {
        if !matches!(self.spec.kind, Kind::Right | Kind::Full) {
            return Ok(0);
        }
        let mut pairs = Pairs::new(batch_rows, context.memory())?;
        let mut written = 0;
        for (row, matched) in self.matched.values.iter().enumerate() {
            if row.is_multiple_of(1024) {
                context.check_cancelled()?;
            }
            if !matched {
                self.push_pair(
                    None,
                    None,
                    Some(row),
                    &mut pairs,
                    &mut written,
                    context,
                    consume,
                )?;
            }
        }
        self.flush(None, &mut pairs, &mut written, context, consume)?;
        Ok(written)
    }

    #[allow(clippy::too_many_arguments)]
    fn push_pair(
        &self,
        left: Option<&ArrayRef>,
        left_row: Option<usize>,
        right_row: Option<usize>,
        pairs: &mut Pairs,
        written: &mut u64,
        context: &NativeExecutionContext<'_>,
        consume: &mut dyn FnMut(ArrayRef) -> Result<()>,
    ) -> Result<()> {
        pairs.left.values.push(left_row);
        pairs.right.values.push(right_row);
        if pairs.left.values.len() == pairs.limit {
            self.flush(left, pairs, written, context, consume)?;
        }
        Ok(())
    }

    fn flush(
        &self,
        left: Option<&ArrayRef>,
        pairs: &mut Pairs,
        written: &mut u64,
        context: &NativeExecutionContext<'_>,
        consume: &mut dyn FnMut(ArrayRef) -> Result<()>,
    ) -> Result<()> {
        self.spec
            .flush(&self.right, left, pairs, written, context, consume)
    }
}

impl Spec {
    pub(super) fn retains(&self, index: usize) -> bool {
        self.retained
            .as_ref()
            .is_none_or(|retained| retained[index])
    }

    fn keep_unpaired_left(&self, matched: bool) -> bool {
        match self.kind {
            Kind::LeftSemi => matched,
            Kind::LeftAnti | Kind::Left | Kind::Full => !matched,
            _ => false,
        }
    }

    fn short_circuit(&self) -> bool {
        matches!(self.kind, Kind::LeftSemi | Kind::LeftAnti)
    }

    #[allow(clippy::too_many_arguments)] // Both join strategies share the exact payload builder.
    fn flush(
        &self,
        right_table: &Table,
        left: Option<&ArrayRef>,
        pairs: &mut Pairs,
        written: &mut u64,
        context: &NativeExecutionContext<'_>,
        consume: &mut dyn FnMut(ArrayRef) -> Result<()>,
    ) -> Result<()> {
        let rows = pairs.left.values.len();
        if rows == 0 {
            return Ok(());
        }
        context.check_cancelled()?;
        let right = self
            .columns
            .iter()
            .any(|(side, _)| *side == Side::Right)
            .then(|| {
                right_table.gather(
                    &pairs.right.values,
                    matches!(self.kind, Kind::Left | Kind::Full),
                    context,
                )
            })
            .transpose()?;
        self.flush_with_right(
            left,
            pairs,
            written,
            context,
            consume,
            |name, dtype, _, retained| {
                let gather = right
                    .as_ref()
                    .ok_or_else(|| failed("right gather is absent"))?;
                if retained {
                    gather.column(name, dtype, context).map(Some)
                } else {
                    gather.validate_column(name, dtype, context)?;
                    Ok(None)
                }
            },
        )
    }

    /// Resident tables and stored native orders share output ownership and null extension.
    fn flush_with_right(
        &self,
        left: Option<&ArrayRef>,
        pairs: &mut Pairs,
        written: &mut u64,
        context: &NativeExecutionContext<'_>,
        consume: &mut dyn FnMut(ArrayRef) -> Result<()>,
        mut right_column: impl FnMut(&str, &DType, &[Option<usize>], bool) -> Result<Option<ArrayRef>>,
    ) -> Result<()> {
        let rows = pairs.left.values.len();
        if rows == 0 {
            return Ok(());
        }
        context.check_cancelled()?;
        let next = written
            .checked_add(rows as u64)
            .ok_or_else(|| failed("join cardinality overflow"))?;
        let left_indices = left
            .map(|_| {
                index_array(
                    rows,
                    matches!(self.kind, Kind::Right | Kind::Full),
                    context,
                    |row| Ok(pairs.left.values[row]),
                )
            })
            .transpose()?;
        let mut columns = ReservedVec::new(context.memory())?;
        columns.reserve(self.fields.len())?;
        for (index, ((side, name), (_, dtype))) in self.columns.iter().zip(&self.fields).enumerate()
        {
            let retained = self.retains(index);
            let array = match side {
                Side::Left => match (left, &left_indices) {
                    (Some(left), Some(indices)) => {
                        let source = logical_field_from_native_array(left, name)?;
                        if retained {
                            Some(take_column(&source, indices, dtype, context)?)
                        } else {
                            super::native_payload::validate_selection(
                                &source, indices, dtype, context,
                            )?;
                            None
                        }
                    }
                    _ if super::native_payload::is_nested(dtype) => {
                        retained.then_some(super::native_payload::defaults(dtype, rows, context)?)
                    }
                    _ => retained.then_some(result_batch::build_column_with_float_policy(
                        dtype,
                        rows,
                        &context.native_session().host_allocator(),
                        context.float_policy(),
                        |_| Ok(result_batch::Value::Null),
                    )?),
                },
                Side::Right => right_column(name, dtype, &pairs.right.values, retained)?,
            };
            if let Some(array) = array {
                columns.values.push(array);
            }
        }
        let output_width = columns.values.len();
        let (columns, _ownership) = columns.into_parts();
        let array = StructArray::try_new(
            self.fields
                .iter()
                .enumerate()
                .filter_map(|(index, (name, _))| self.retains(index).then_some(name.as_str()))
                .collect::<FieldNames>(),
            columns,
            rows,
            Validity::NonNullable,
        )
        .map_err(vortex_error)?
        .into_array();
        #[cfg(all(test, debug_assertions))]
        super::native_relational_observation::record(|counts| {
            counts.join_output_rows += rows as u64;
            counts.join_output_cells += (rows * output_width) as u64;
            counts.join_payload_validation_only_cells +=
                (rows * (self.fields.len() - output_width)) as u64;
        });
        let _ = output_width;
        consume(array)?;
        context.check_cancelled()?;
        *written = next;
        pairs.left.values.clear();
        pairs.right.values.clear();
        Ok(())
    }
}

struct Pairs {
    left: ReservedVec<Option<usize>>,
    right: ReservedVec<Option<usize>>,
    limit: usize,
}
impl Pairs {
    fn new(limit: usize, memory: &LiveMemoryPool) -> Result<Self> {
        if limit == 0 {
            return Err(failed("output batch rows must be positive"));
        }
        let mut left = ReservedVec::new(memory)?;
        let mut right = ReservedVec::new(memory)?;
        left.reserve(limit)?;
        right.reserve(limit)?;
        Ok(Self { left, right, limit })
    }
}

#[cfg(test)]
#[path = "native_relational_join_tests.rs"]
mod tests;
