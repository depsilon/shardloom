"""Record finite unary membership acceptance only after all frozen gates pass."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PRIOR = Path('/Users/dylan/LocalData/shardloom/native-unary-membership-20261018')
from reuse_unary_acceptance import verify_reuse


def read(path):
    return json.loads(Path(path).read_text())


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}


def check(ref):
    assert identity(ref['path']) == ref, ref['path']


acceptance = read(OUT / 'acceptance-final-verified.json')
assert acceptance['status'] == 'passed' and acceptance['finite_family_acceptance_complete']
assert not acceptance['broader_membership_population_owner_complete']
assert not acceptance['broader_recovery_owner_complete'] and not acceptance['performance_claim']
source = read(OUT / 'acceptance-source.json')
bridge = verify_reuse()
assert acceptance['source_commit'] == source['source_commit']
assert acceptance['compiled_source_commit'] == bridge['compiled_source_commit']
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head == source['source_commit']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True) == ''
for name, digest in source['source_hashes'].items():
    assert identity(ROOT / name)['sha256'] == digest, name
for group in ('gates', 'development_evidence'):
    for record in acceptance[group].values():
        check(record['receipt'])
        check(record['log'])
for ref in acceptance['phase_reports'].values():
    check(ref)

native_log = (PRIOR / 'unary-native-vortex-tests-731.log').read_text()
required = []
for path in sorted((ROOT / 'shardloom-vortex/src').glob('local_primitive_relational*tests.rs')):
    for name in re.findall(r'^fn ((?:unary_membership|streaming_unary_membership|streaming_future_duplicate|native_relational_spill_large)\w+)\(', path.read_text(), re.MULTILINE):
        assert len(re.findall(r'^test .*::' + re.escape(name) + r' \.\.\. ok$', native_log, re.MULTILINE)) == 1, name
        required.append(name)
assert len(required) == 17
binding_selector = 'test_native_unary_membership_spill_preserves_exact_rows_across_terminals'
binding_log = (OUT / 'unary-direct-binding-tests-733.log').read_text()
assert re.search(r'^' + binding_selector + r' .* \.\.\. ok$', binding_log, re.MULTILINE)
public = read(OUT / 'acceptance-public-verified.json')
assert public['unary_membership_public_cases'] == 210
assert public['unary_pressure_public_cases'] == 51
assert len(public['unary_complete_value_archives']) == 274
assert len(public['unary_publication_failure_cases']) == 63

record = {
    'schema_version': 'shardloom.native_unary_membership_acceptance.v1',
    'status': 'accepted_finite_local_scope',
    'source_commit': source['source_commit'], 'base_commit': source['base_commit'],
    'compiled_source_commit': acceptance['compiled_source_commit'],
    'scope': source['scope'],
    'sources': ['native_files', 'resident_native_memory', 'finite_streaming_batches'],
    'source_manifest': identity(OUT / 'acceptance-source.json'),
    'build': identity(OUT / 'acceptance-build.json'), 'plan': identity(OUT / 'acceptance-plan.json'),
    'runtime_acceptance': identity(OUT / 'acceptance-final-verified.json'),
    'test_counts': acceptance['test_counts'], 'required_native_selectors': required,
    'direct_binding_selector': binding_selector, 'direct_binding_subcases': 56,
    'public_families': 37, 'public_cases': 5126,
    'unary_membership_public_cases': 210, 'unary_pressure_public_cases': 51,
    'net_new_public_cases': 215, 'unary_complete_value_archives': 274,
    'unary_publication_failure_cases': 63,
    'unary_complete_rows_reopened': public['complete_rows_independently_reopened'],
    'full43': {'queries': 43, 'executions_per_query': 1, 'complete_result_rows': 381,
               'engine_execution_seconds': acceptance['engine_execution_seconds'],
               'reference_kind': 'retained_native_regression', 'performance_claim': False},
    'modular_cohorts': 18, 'native_workflows': 704, 'fresh_independent_pandas_oracle_workflows': 704,
    'completed_substeps': [],
    'accepted_finite_scope_within': ['PERF-06.membership', 'PERF-06.recovery', 'PERF-06.strategy'],
    'broader_owners_closed': [],
    'cross_cutting_owners': ['PERF-01', 'PERF-03', 'PERF-07', 'PERF-11', 'PERF-12'],
    'all_cg_1_through_cg_23_requirements_preserved': True,
    'crash_recovery': 'exact_owned_cleanup_followed_by_fresh_execution',
    'interrupted_execution_resume': False,
    'strategy': 'exact_online_membership_with_native_chronological_replacement_runs',
    'future_dedup_output': 'surviving_payloads_ordered_by_selected_source_ordinal',
    'future_masks': 'bounded_prefix_identities_and_final_exact_membership_lookup',
    'internal_run_block_maximum_rows': 256,
    'original_key_pressure_grant_bytes': 16 << 20,
    'original_future_mask_identity_grant_bytes': 8 << 20,
    'direct_binding_grant_bytes': 32 << 20,
    'public_wide_destination_grant_bytes': 32 << 20,
    'independent_direct_file_readback_grant_bytes': 128 << 20,
    'source_reuse_bridge': identity(OUT / 'acceptance-source-bridge.json'),
    'python_delivery_batch_rows_is_native_scan_bound': False,
    'whole_process_memory_ceiling': False, 'fallback_attempted': False,
    'external_engine_invoked_as_runtime': False, 'release_version_changed': False,
    'publication_attempted': False,
    'platform_scope': 'local macOS Unix; release-user-surfaces feature build',
    'claim_gate_status': 'not_claim_grade',
    'unresolved': [
        'Sampling populations and subquery indexes retain their existing resident pressure boundaries.',
        'Legacy standalone PreparedVortexUnary retains its resident-only contract.',
        'This family restarts after owned cleanup; general interrupted-execution resume is not established.',
        'Existing destinations remain rejected before input demand; generation-conditional replacement remains PERF-07 work.',
        'Hosted installed-wheel, other-platform, release and competitive claims retain their independent gates.',
        'Python delivery batch_rows slices an admitted native batch; it does not bound file-reader or Arrow admission.',
        'Managed reservations do not impose a whole-process RSS ceiling.',
    ],
    'generator': identity(__file__),
}
with (OUT / 'perf-06-acceptance.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps({'status': record['status'], 'public_cases': record['public_cases'],
                  'engine_execution_seconds': record['full43']['engine_execution_seconds']}))
