from pathlib import Path
import datetime, hashlib, json, subprocess, urllib.request

ROOT = Path('{SOURCE_ROOT}')
OUT = Path('{EVIDENCE_ROOT}')
HEAD = 'be564ab81bacffb33fa42367874522a5dc55362a'
MERGE = '249657ede5a3dafc6f59f9922e97457edd12a83f'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])

def main():
    assert git('rev-parse', 'HEAD').decode().strip() == MERGE
    checked_tree = git('rev-parse', HEAD + '^{tree}').decode().strip()
    merged_tree = git('rev-parse', MERGE + '^{tree}').decode().strip()
    assert checked_tree == merged_tree
    source_map = OUT / 'native-release-source-343.json'
    source = json.loads(source_map.read_bytes())['source_sha256']
    for path, expected in source.items():
        assert sha((ROOT / path).read_bytes()) == expected, path
    pages = []
    for page in ('runtime-and-io', 'limitations'):
        relative = f'website/field-guide/{page}/index.html'
        url = f'https://shardloom.io/field-guide/{page}/'
        request = urllib.request.Request(url, headers={'User-Agent': 'ShardLoom-owned-site-verification'})
        with urllib.request.urlopen(request, timeout=30) as response:
            body = response.read(2 * 1024 * 1024 + 1)
            assert len(body) <= 2 * 1024 * 1024
            status, final_url = response.status, response.url
        expected = git('show', MERGE + ':' + relative)
        assert status == 200, (relative, status)
        dest = OUT / f'persisted-production-{page}-352.html'
        dest.write_bytes(body)
        pages.append(dict(source=relative, url=url, final_url=final_url,
                          http_status=status, bytes=len(body), sha256=sha(body),
                          byte_identical_to_merge=body == expected,
                          expected_bytes=len(expected), expected_sha256=sha(expected),
                          capture=dest.name))
    result = dict(schema_version=1, status='captured_pending_comparison',
                  observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  checked_head=HEAD, merge_commit=MERGE, checked_tree=checked_tree,
                  merged_tree=merged_tree, trees_equal=True,
                  source_map_sha256=sha(source_map.read_bytes()),
                  accepted_source_files_verified=len(source), pages=pages,
                  prior_attempt='Default Python HTTP user agent received 403 before any page capture; retried with the existing explicit site-verification user agent.',
                  scope='Exact merged HTML and frozen source identities; no new runtime measurements')
    target = OUT / 'persisted-production-http-352.json'
    target.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
