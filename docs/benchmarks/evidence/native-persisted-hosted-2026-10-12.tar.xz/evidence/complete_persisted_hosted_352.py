from pathlib import Path
import hashlib, json, re

OUT = Path('{EVIDENCE_ROOT}')
ROOT = Path('{SOURCE_ROOT}')

def read(name):
    return json.loads((OUT / name).read_bytes())

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    http = read('persisted-production-http-352.json')
    for page in http['pages']:
        expected = (ROOT / page['source']).read_bytes()
        actual = (OUT / page['capture']).read_bytes()
        assert sha(actual) == page['sha256']
        assert sha(expected) == page['expected_sha256']
        prefix = 0
        while prefix < min(len(actual), len(expected)) and actual[prefix] == expected[prefix]:
            prefix += 1
        extra = len(actual) - len(expected)
        assert extra == 1305 and actual[prefix + extra:] == expected[prefix:]
        insertion = actual[prefix:prefix + extra]
        assert b'/cdn-cgi/challenge-platform/scripts/jsd/main.js' in insertion
        assert b'https://static.cloudflareinsights.com/beacon.min.js/' in insertion
        page['comparison'] = dict(source_preserved=True, raw_byte_identical=False,
                                  insertion_bytes=extra, insertion_offset=prefix,
                                  insertion_sha256=sha(insertion),
                                  insertion_kind='Cloudflare challenge and analytics scripts')
    http['status'] = 'passed'
    http['scope'] = 'Merged page content preserved with one recorded Cloudflare script insertion per page; frozen runtime source identity remains unchanged.'
    http['prior_attempts'] = [http.pop('prior_attempt'), 'Raw byte comparison refused to pass because Cloudflare inserted 1,305 bytes per page; retained captures were compared as one exact insertion without changing source.']
    (OUT / 'persisted-production-http-352.json').write_text(json.dumps(http, indent=2) + '\n')
    pre = read('persisted-hosted-final-premerge-351.json')
    merge = read('persisted-merge-351.json')
    wheels = read('hosted-wheel-proof-350/report-complete.json')
    production = read('persisted-production-check-352.json')['check_runs'][0]
    browser = read('persisted-production-browser-352.json')
    checks = pre['checks']['checks']
    assert len(checks) == 44 and all(c['status'] == 'completed' and c['conclusion'] == 'success' for c in checks)
    assert pre['head'] == pre['checks']['headRevision'] == merge['expected_head'] == http['checked_head']
    assert merge['merged'] and merge['sha'] == production['head_sha'] == http['merge_commit']
    assert not [t for t in pre['review_threads'] if not t['is_resolved']]
    assert not [r for r in pre['reviews'] if r['state'] == 'CHANGES_REQUESTED']
    assert len(wheels['lanes']) == 3
    names = []
    for lane in wheels['lanes']:
        assert lane['head_sha'] == pre['head'] and lane['workflow_run_id'] == 38205566492
        for info in lane['proof_files'].values():
            data = Path(info['path']).read_bytes()
            assert len(data) == info['bytes'] and sha(data) == info['sha256']
        log = Path(lane['proof_files']['integration.log']['path']).read_text()
        tests = re.findall(r'^(test_[^ ]+) .* \.\.\. ok$', log, flags=re.M)
        assert len(tests) == len(set(tests)) == 76, lane['id']
        assert set(tests) == set(lane['test_names'])
        assert lane['integration']['failures'] == lane['integration']['errors'] == lane['integration']['skipped'] == 0
        assert lane['hosted_load_step']['returncode'] == 0 and lane['installed_load']['isolated_install']
        assert lane['integrity_load_verified'] is False
        names.append(set(tests))
    assert names[0] == names[1] == names[2]
    assert browser['viewport_width'] == browser['document_width'] == 1280 and not browser['console']
    review_comment = next(c for c in pre['comments'] if c['id'] == 6117982101)
    assert 'Completed' in review_comment['body'] and 'be564ab' in review_comment['body']
    receipt = dict(schema_version=1,
        scope='PR #1544 hosted integration and actual production verification; original local timing and UAT identities remain separate',
        checked_head=pre['head'], merge_commit=merge['sha'],
        checked_tree=http['checked_tree'], merged_tree=http['merged_tree'], trees_equal=http['trees_equal'],
        pull_request='https://github.com/depsilon/shardloom/pull/1544',
        checks=[dict(id=c['id'], name=c['name'], status=c['status'], conclusion=c['conclusion'],url=c['details_url']) for c in checks],
        check_count=len(checks), all_checks_passed=True,
        review=dict(unresolved_threads=0, submitted_changes_requested=0,
                    codex_review=dict(status='completed',head=pre['head'],url=review_comment['url']),
                    codeql_false_positives=dict(alert_numbers=[181,182],count=2,
                        cause='Static source and SARIF triage found only synthetic test fixtures; the trusted(?!_iter) name heuristic matches the iterator-length contract try_from_trusted_len_iter.',
                        rule_remains_enabled=True,
                        source_revision='ec7868b6e78456d7b28ad04ebed9ca7085e1e024',
                        relevant_source_byte_identity_verified=True,
                        original_sarif_sha256='d39c95079e9409a4c7c1713d201cb0200e4ecf08684395d2c311959978c17935',
                        public_triage='https://github.com/depsilon/shardloom/pull/1544#issuecomment-6118178314')),
        wheel_proof=dict(source_head=pre['head'],github_run=38205566492,
                    summary_sha256=sha((OUT/'hosted-wheel-proof-350/report-complete.json').read_bytes()),
                    lanes=[x['id'] for x in wheels['lanes']],tests_per_lane=76,failures=0,errors=0,skipped=0,
                    individual_test_names_recounted=True,exact_test_name_sets_equal=True,proof_files_per_lane=4,
                    isolated_load_verified=True,static_integrity_load_verified=False),
        frozen_source=dict(source_map_sha256=http['source_map_sha256'],accepted_source_files_verified=http['accepted_source_files_verified']),
        preview=dict(receipt_sha256=sha((OUT/'persisted-preview-349.json').read_bytes()),
                     source_byte_identity_verified=True, widths_without_horizontal_overflow=[1280,390],
                     mobile_screenshot_scope='Layout width verification; the complete new paragraph is pictured in the desktop capture.'),
        production=dict(head=merge['sha'],check_id=production['id'],conclusion=production['conclusion'],
                    url=production['details_url'],build_id=production['external_id'],
                    version_id='b4be8a44-821e-4e2c-87a6-e229a562a718',browser=browser,
                    page_comparisons=http['pages'],raw_html_byte_identity=False),
        boundaries=dict(version='0.5.1',packages_republished=False,persisted_output_runtime_implemented=True,
                        cross_owner_encoded_transfer_implemented=False,independent_encoded_interchange_implemented=False,
                        whole_roadmap_complete=False,main_branch_ci_not_recounted=True))
    target = OUT / 'native-persisted-hosted-2026-10-12.json'
    target.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(dict(status='passed',receipt=str(target),sha256=sha(target.read_bytes()),checks=len(checks),wheel_lanes=3,tests_per_lane=76,source_files=http['accepted_source_files_verified'])))

if __name__ == '__main__':
    main()
