"""Primary independent raw-stream, clock decision and source/receipt verification."""
import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import sys

OUT=Path(__file__).resolve().parent
ROOT=Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
DATA=OUT/'predicate-exclusion-767-a1'
LABEL='predicate-attribution-767-a2'
PROTOCOL_SHA='153892a4e056c9adf769dd65ba758ec304f70a2f8d62111d3b96197842d9a5e3'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())
def item(path):
    path=Path(path);return dict(path=str(path.relative_to(OUT)),bytes=path.stat().st_size,sha256=sha(path))

assert sha(OUT/'predicate-exclusion-attribution-protocol-766.json')==PROTOCOL_SHA
sequence=read(OUT/'predicate-exclusion-sequence-767-a1.json')
assert sequence['status']=='passed' and len(sequence['steps'])==9
for step in sequence['steps']:
    assert step['status']=='passed' and step['returncode']==0
    assert sha(step['log'])==step['log_sha256']
subprocess.run([sys.executable,'-B',str(OUT/'predicate_exclusion_driver_767.py'),'verify','--label',LABEL],cwd=ROOT,check=True)
freeze_path=OUT/f'{LABEL}-source-freeze.json'; freeze=read(freeze_path)
artifact=read(OUT/f'{LABEL}-artifact.json')
assert artifact['source_freeze_sha256']==sha(freeze_path)
build=read(OUT/'predicate-attribution-build-767-a2.json')
assert build['status']=='passed' and build['returncode']==0 and build['process_group_drained']
assert sha(OUT/'predicate-attribution-build-767-a2.log')==build['log_sha256']
assert not artifact['compiler_artifact']['fresh']
decision=read(OUT/'predicate-exclusion-decision-767-a1.json')
preflight=read(OUT/'predicate-exclusion-preflight-767-a1.json')
assert decision['protocol_sha256']==preflight['protocol_sha256']==PROTOCOL_SHA
assert decision['validator_sha256']==preflight['validator_sha256']==sha(OUT/'analyze_predicate_exclusion_766.py')
references=set(); streams={}; jobs=[]; workflows=operations=warmups=0
for mode,cohort,role in [('preflight','preflight','off'),('preflight','preflight','on'),('measure','A','off'),('measure','A','on'),('measure','B','on'),('measure','B','off')]:
    name=f'predicate-preflight-{role}-767-a1' if mode=='preflight' else f'predicate-measure-{cohort}-{role}-767-a1'
    receipt=read(OUT/f'{name}.json'); link=read(OUT/f'{name}-link.json')
    path=DATA/f'{mode}-{cohort}-{role}.jsonl'
    assert receipt['status']=='passed' and receipt['returncode']==0 and receipt['process_group_drained']
    assert sha(OUT/f'{name}.log')==receipt['log_sha256']
    assert link['sources_and_artifact_unchanged'] and link['returncode']==0
    assert link['output_sha256']==sha(path) and link['output_bytes']==path.stat().st_size
    assert link['artifact_sha256']==artifact['artifact_sha256'] and link['source_freeze_sha256']==sha(freeze_path)
    summary=preflight['streams'][role] if mode=='preflight' else decision['streams'][f'{cohort}-{role}']
    assert summary['sha256']==sha(path) and summary['bytes']==path.stat().st_size
    records=[json.loads(line) for line in path.read_text().splitlines()]
    assert len(records)==summary['workflows']==(156 if mode=='preflight' else 235)
    count=sum(len(r['operations']) for r in records)
    assert count==summary['operations']==(364 if mode=='preflight' else 547)
    for r in records:
        workflows+=1;operations+=len(r['operations']);warmups+=r['warmup']
        assert r['complete_workflow_ns']==r['preparation_ns']+r['destruction_ns']+sum(o['execution_and_consumption_ns']+o['output_release_ns'] for o in r['operations'])
        assert (r['completed_executions'],r['prepared_source_opens'],r['admitted_max_parallelism'],r['provider_background_workers'],r['reserved_after_cleanup'],r['denied_reservations'])==(r['calls'],0,1,0,0,0)
        for key in ['source_rows_witness','source_schema_witness']:references.add(r[key])
        cumulative_engine=0
        for i,op in enumerate(r['operations']):
            assert op['completed_executions']==i+1
            assert op['native_io_certificate']['certified'] and op['native_io_certificate']['fallback_attempted'] is False
            assert op['engine_execution_ns']+op['result_serialization_ns']<=op['execution_and_consumption_ns']
            cumulative_engine+=op['engine_execution_ns']
            assert op['observation']['evaluation_ns']+op['observation']['mask_ns']<=cumulative_engine
            for key in ['expected_rows_witness','expected_schema_witness','actual_rows_witness','actual_schema_witness']:references.add(op[key])
    if mode=='measure':streams[cohort,role]=records
    jobs.append(dict(name=name,receipt=item(OUT/f'{name}.json'),link=item(OUT/f'{name}-link.json'),stream=item(path)))
assert (workflows,operations,warmups)==(1252,2916,4)
assert references=={p.stem for p in (DATA/'witnesses').glob('*.json')}
for ref in references:
    assert len(ref)==64 and sha(DATA/'witnesses'/f'{ref}.json')==ref

def median(records,field):
    if field=='engine':return statistics.median(sum(o['engine_execution_ns'] for o in r['operations']) for r in records)
    if field=='complete':return statistics.median(r['complete_workflow_ns'] for r in records)
    return statistics.median(sum(r['operations'][-1]['observation'][k]-r['operations'][0]['observation'][k] for k in ['evaluation_ns','mask_ns']) for r in records)

recomputed=[];common=[]
for family in ['correlated','membership','contains']:
    cid=f'65536-{family}-no_true-4'; target=next(r for r in decision['targets'] if r['cell_id']==cid)
    cohorts={}
    for cohort in ['A','B']:
        rec={role:[r for r in streams[cohort,role] if r['cell_id']==cid and not r['warmup']] for role in ['off','on']}
        assert all({r['sample'] for r in rs}=={0,1,2} and len(rs)==3 for rs in rec.values())
        e0,e1=median(rec['off'],'engine'),median(rec['on'],'engine')
        c0,c1=median(rec['off'],'complete'),median(rec['on'],'complete')
        stage=median(rec['on'],'stage')
        excluded=(e1-e0>250000 and (e1-e0)*20>e0) or (c1-c0>250000 and (c1-c0)*20>c0)
        qualifies=not excluded and stage>=1000000 and stage*4>=e1
        actual=dict(observer_eligible=not excluded,median_enabled_engine_ns=e1,median_disabled_engine_ns=e0,
                    median_enabled_complete_ns=c1,median_disabled_complete_ns=c0,median_enabled_target_stage_ns=stage,target_qualifies=qualifies)
        assert actual==target['cohorts'][cohort]
        cohorts[cohort]=actual
    both=all(r['target_qualifies'] for r in cohorts.values())
    assert both==target['qualifies_both_cohorts']
    if both:common.append(family)
    recomputed.append(dict(cell_id=cid,cohorts=cohorts,qualifies_both_cohorts=both))
assert len(common)==decision['qualified_target_count']
assert decision['scope_result']==('attribution_positive' if len(common)>=2 else 'no_signal')
assert decision['production_accepted'] is False
report=dict(status='passed',protocol_sha256=PROTOCOL_SHA,workflows=workflows,operations=operations,
            retained_excluded_warmups=warmups,full_content_witnesses=len(references),runtime_inputs=len(freeze['sources']),
            production_head=freeze['head'],production_accepted=False,source_binding=item(freeze_path),
            build_receipt=item(OUT/'predicate-attribution-build-767-a2.json'),artifact=item(OUT/f'{LABEL}-artifact.json'),
            jobs=jobs,preflight=item(OUT/'predicate-exclusion-preflight-767-a1.json'),
            decision=item(OUT/'predicate-exclusion-decision-767-a1.json'),
            independently_recomputed_targets=recomputed,common_qualifying_families=common,
            scope_result=decision['scope_result'],verifier_sha256=sha(__file__))
with (OUT/'predicate-exclusion-verification-767.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps({k:report[k] for k in ['status','scope_result','workflows','operations','full_content_witnesses','common_qualifying_families']}))
