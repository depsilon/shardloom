"""Freeze and supervise one native executable for observer-off/on attribution."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PROTOCOL = OUT / 'predicate-exclusion-attribution-protocol-766.json'
PROTOCOL_SHA = '153892a4e056c9adf769dd65ba758ec304f70a2f8d62111d3b96197842d9a5e3'
GUARD = OUT / 'run_guarded_observed_757.py'
SELECTOR = 'local_primitives::prepared_relational::tests::predicate_cost_tests::native_predicate_exclusion_attribution'
HELPERS = [PROTOCOL, GUARD, Path(__file__), OUT/'analyze_predicate_exclusion_766.py', OUT/'test_predicate_oracle_766.py']

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
def source_paths():
    names = subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=REPO,text=True).splitlines()
    return sorted(p for p in set(names) if p.endswith('.rs') or Path(p).name in ('Cargo.toml','Cargo.toml.orig','Cargo.lock'))
def verify_sources(freeze):
    assert sha(PROTOCOL) == PROTOCOL_SHA
    assert source_paths() == [r['path'] for r in freeze['sources']]
    for row in freeze['sources']:
        p = REPO/row['path']
        assert p.stat().st_size == row['bytes'] and sha(p) == row['sha256'], row['path']
    for row in freeze['helpers']:
        assert sha(row['path']) == row['sha256'], row['path']
def historical_sources(label, freeze):
    assert sha(OUT/f'{label}-tracked.patch') == freeze['patch_sha256']
    sources = {r['path']:r for r in freeze['sources']}
    for path in freeze['extra_sources']:
        original = OUT/f'{label}-extra-sources'/path
        assert original.stat().st_size == sources[path]['bytes'] and sha(original) == sources[path]['sha256']

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['freeze','bind','verify','run'])
    parser.add_argument('--label',required=True)
    parser.add_argument('--build')
    parser.add_argument('--name')
    parser.add_argument('--mode',choices=['preflight','measure'])
    parser.add_argument('--role',choices=['off','on'])
    parser.add_argument('--cohort',default='preflight',choices=['preflight','A','B'])
    parser.add_argument('--data',default='predicate-exclusion-767-a1')
    args=parser.parse_args()
    assert args.label.replace('-','').isalnum() and sha(PROTOCOL)==PROTOCOL_SHA
    freeze_path=OUT/f'{args.label}-source-freeze.json'; artifact_path=OUT/f'{args.label}-artifact.json'
    if args.action=='freeze':
        paths = source_paths()
        sources=[dict(path=p,bytes=(REPO/p).stat().st_size,sha256=sha(REPO/p)) for p in paths]
        patch=OUT/f'{args.label}-tracked.patch'
        with patch.open('xb') as stream: stream.write(subprocess.check_output(['git','diff','--binary'],cwd=REPO))
        extras=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=REPO,text=True).splitlines()
        extras=[p for p in extras if p in paths]
        for path in extras:
            target=OUT/f'{args.label}-extra-sources'/path; target.parent.mkdir(parents=True,exist_ok=True)
            assert not target.exists(); shutil.copyfile(REPO/path,target)
        save(freeze_path,dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
            sources=sources,extra_sources=extras,patch_sha256=sha(patch),protocol_sha256=PROTOCOL_SHA,
            helpers=[dict(path=str(p),sha256=sha(p)) for p in HELPERS]))
        print(json.dumps(dict(source_freeze=str(freeze_path),sha256=sha(freeze_path),runtime_inputs=len(sources)))); return
    freeze=json.loads(freeze_path.read_text()); historical_sources(args.label,freeze); verify_sources(freeze)
    if args.action=='bind':
        assert args.build
        build_path=OUT/f'{args.build}.json'; build=json.loads(build_path.read_text())
        assert build['status']=='passed' and build['process_group_drained'] and build['returncode']==0
        assert sha(OUT/f'{args.build}.log') == build['log_sha256']
        artifacts=[]
        for line in (OUT/f'{args.build}.log').read_text().splitlines():
            if not line.startswith('{'): continue
            item=json.loads(line)
            if item.get('reason')=='compiler-artifact' and item.get('target',{}).get('name')=='shardloom_vortex' and item.get('profile',{}).get('test'): artifacts.append(item)
        assert len(artifacts)==1 and artifacts[0]['executable'] and not artifacts[0]['fresh']
        source=Path(artifacts[0]['executable']); binary=OUT/f'{args.label}-test'; assert not binary.exists()
        shutil.copy2(source,binary); assert sha(binary)==sha(source)
        inventory=subprocess.check_output([str(binary),'--list'],text=True)
        assert f'{SELECTOR}: test' in inventory
        (OUT/f'{args.label}-test-inventory.txt').write_text(inventory)
        save(artifact_path,dict(artifact=str(binary),artifact_sha256=sha(binary),bytes=binary.stat().st_size,
            source_freeze_sha256=sha(freeze_path),build=args.build,build_receipt_sha256=sha(build_path),compiler_artifact=artifacts[0]))
        print(json.dumps(dict(artifact=str(binary),sha256=sha(binary)))); return
    artifact=json.loads(artifact_path.read_text()); binary=Path(artifact['artifact'])
    assert sha(binary)==artifact['artifact_sha256'] and sha(freeze_path)==artifact['source_freeze_sha256']
    if args.action=='verify':
        print(json.dumps(dict(workspace_sources_unchanged=True,artifact_and_historical_source_binding_unchanged=True))); return
    assert args.name and args.mode and args.role
    assert (args.mode=='preflight') == (args.cohort=='preflight')
    data=OUT/args.data
    assert data.parent==OUT and data.name.startswith('predicate-exclusion-')
    data.mkdir(exist_ok=True)
    command=[sys.executable,str(GUARD),'--name',args.name,'--timeout','1800','--','/usr/bin/env',
        f'SHARDLOOM_PREDICATE_ROOT={data}',f'SHARDLOOM_PREDICATE_MODE={args.mode}',
        f'SHARDLOOM_PREDICATE_ROLE={args.role}',f'SHARDLOOM_PREDICATE_COHORT={args.cohort}',
        str(binary),SELECTOR,'--exact','--ignored','--nocapture','--test-threads=1']
    record=dict(command=command,role=args.role,mode=args.mode,cohort=args.cohort,
        artifact_sha256=sha(binary),source_freeze_sha256=sha(freeze_path),protocol_sha256=PROTOCOL_SHA,
        driver_sha256=sha(__file__),guard_sha256=sha(GUARD))
    try:
        code=subprocess.call(command,cwd=REPO); record['returncode']=code
        verify_sources(freeze); historical_sources(args.label,freeze)
        assert sha(binary)==artifact['artifact_sha256']; record['sources_and_artifact_unchanged']=True
        output=data/f'{args.mode}-{args.cohort}-{args.role}.jsonl'
        if output.exists(): record.update(output=str(output),output_sha256=sha(output),output_bytes=output.stat().st_size)
    finally: save(OUT/f'{args.name}-link.json',record)
    raise SystemExit(code)
if __name__=='__main__': main()
