#!/usr/bin/env python3
"""Independent validator and decision oracle for frozen protocol 766."""
from __future__ import annotations

import argparse
import hashlib
import json
import statistics
from pathlib import Path
from typing import Any

PROTOCOL = Path(__file__).with_name("predicate-exclusion-attribution-protocol-766.json")
PROTOCOL_SHA256 = "153892a4e056c9adf769dd65ba758ec304f70a2f8d62111d3b96197842d9a5e3"
PROTOCOL_ID = "predicate-exclusion-attribution-766-v1"
FAMILIES = ("correlated", "membership", "contains")
SCENARIOS = ("no_true", "positive", "all_null", "changed_parameters")
CALLS = (1, 2, 4)
ROWS = (8192, 65536)
SAMPLES = (0, 1, 2)
MEMORY_LIMIT = 33554432
COUNT_SCHEMA = {"Struct": [{"names": ["rows"], "dtypes": [{"Primitive": ["u64", False]}]}, False]}
GROUP_SCHEMA = {"Struct": [{"names": ["g", "total"], "dtypes": [{"Primitive": ["i64", False]}, {"Primitive": ["f64", True]}]}, False]}
SOURCE_SCHEMA = {"Struct": [{"names": ["x", "y", "text", "g", "v"], "dtypes": [{"Primitive": ["i64", True]}, {"Primitive": ["i64", True]}, {"Utf8": True}, {"Primitive": ["i64", False]}, {"Primitive": ["i64", False]}]}, False]}


class Invalid(ValueError):
    pass


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _need(ok: bool, message: str) -> None:
    if not ok:
        raise Invalid(message)


def _typed_equal(actual: Any, expected: Any) -> bool:
    if type(actual) is not type(expected): return False
    if isinstance(expected, dict):
        return actual.keys() == expected.keys() and all(_typed_equal(actual[k], expected[k]) for k in expected)
    if isinstance(expected, list):
        return len(actual) == len(expected) and all(_typed_equal(a, b) for a, b in zip(actual, expected))
    return actual == expected


def _integer(value: Any, label: str, minimum: int = 0) -> int:
    _need(type(value) is int and value >= minimum, f"{label} must be an integer >= {minimum}")
    return value


def cells() -> list[tuple[int, str, str, int]]:
    out = []
    for n in ROWS:
        for f in FAMILIES:
            for s in SCENARIOS:
                for c in CALLS:
                    out.append((n, f, s, c))
        for c in CALLS:
            out.append((n, "unfiltered", "unfiltered", c))
    return out


def _source(n: int, scenario: str, family: str) -> list[dict[str, Any]]:
    result = []
    for r in range(n):
        present = r % 17 != 0 and scenario != "all_null"
        base = 2 * (r % 2048)
        x: Any = base if present else None
        y: Any = base if present else None
        t: Any = f"item/{r % 97}/part-{r % 11}" if present else None
        if scenario == "positive" and present:
            if family == "correlated": y = base - 4096
            elif family == "membership": x = base + 1
            elif family == "contains": t += "::absent::"
        result.append({"x": x, "y": y, "text": t, "g": r % 8, "v": (r % 101) - 50})
    return result


def _selected(row: dict[str, Any], family: str, scenario: str, call: int) -> bool:
    if family == "unfiltered": return True
    k = call if scenario == "changed_parameters" else 0
    if family == "correlated":
        return row["x"] is not None and row["y"] is not None and row["x"] > 2047 + 2*k and row["y"] < 2048 + 2*k
    if family == "membership":
        return row["x"] is not None and row["x"] in {1 + 32*k + 2*i for i in range(16)}
    needle = "::absent::" + (str(k) if k else "")
    return row["text"] is not None and needle in row["text"]


def _witness(data_dir: Path, ref: Any, expected: Any, label: str) -> Any:
    _need(isinstance(ref, str) and len(ref) == 64 and all(ch in "0123456789abcdef" for ch in ref), f"malformed witness identity: {label}")
    p = data_dir / "witnesses" / f"{ref}.json"
    _need(p.is_file(), f"missing witness {label}: {ref}")
    raw = p.read_bytes()
    _need(digest(raw) == ref, f"witness content hash mismatch: {label}")
    try: value = json.loads(raw)
    except Exception as e: raise Invalid(f"invalid witness JSON {label}: {e}") from e
    _need(_typed_equal(value, expected), f"witness value or JSON type mismatch: {label}")
    return value


def _validate_record(data: Path, rec: dict[str, Any], mode: str, role: str, cohort: str, sample: int, cell: tuple[int, str, str, int], warm: bool) -> None:
    n, family, scenario, calls = cell
    expected_id = f"{n}-{family}-{scenario}-{calls}"
    for key, value in {"protocol_id": PROTOCOL_ID, "cell_id": expected_id, "rows": n, "family": family, "scenario": scenario, "calls": calls, "mode": mode, "role": role, "cohort": cohort, "sample": sample, "warmup": warm}.items():
        _need(rec.get(key) == value and type(rec.get(key)) is type(value), f"{expected_id}: incorrect {key}")
    source = _source(n, scenario, family)
    _witness(data, rec.get("source_rows_witness"), source, "source rows")
    _witness(data, rec.get("source_schema_witness"), SOURCE_SCHEMA, "source schema")
    prep = _integer(rec.get("preparation_ns"), "preparation_ns")
    destroy = _integer(rec.get("destruction_ns"), "destruction_ns")
    engine_total = 0
    obs_prev = {k: 0 for k in ("evaluation_calls", "input_rows", "mask_calls", "mask_input_rows", "selected_rows", "evaluation_ns", "mask_ns")}
    ops = rec.get("operations")
    _need(isinstance(ops, list) and len(ops) == calls, f"{expected_id}: wrong operations count")
    for i, op in enumerate(ops):
        consumer = "count" if i % 2 == 0 else "grouped_sum"
        selected = [row for row in source if _selected(row, family, scenario, i)]
        exp_rows = [{"rows": len(selected)}] if consumer == "count" else _groups(selected)
        schema = COUNT_SCHEMA if consumer == "count" else GROUP_SCHEMA
        for k, v in {"call": i, "consumer": consumer, "rows": len(exp_rows)}.items(): _need(op.get(k) == v, f"{expected_id} op{i}: incorrect {k}")
        _witness(data, op.get("expected_rows_witness"), exp_rows, f"expected rows op{i}")
        _witness(data, op.get("expected_schema_witness"), schema, f"expected schema op{i}")
        _witness(data, op.get("actual_rows_witness"), exp_rows, f"actual rows op{i}")
        _witness(data, op.get("actual_schema_witness"), schema, f"actual schema op{i}")
        for key in ("engine_execution_ns", "result_serialization_ns", "execution_and_consumption_ns", "output_release_ns"):
            _integer(op.get(key), f"{expected_id} op{i} {key}")
        _need(op["completed_executions"] == 1, f"{expected_id} op{i}: incomplete execution")
        engine_total += op["engine_execution_ns"]
        cert = op.get("native_io_certificate")
        _need(isinstance(cert, dict) and cert.get("certified") is True and cert.get("fallback_attempted") is False and isinstance(cert.get("complete_debug"), str) and cert["complete_debug"].strip(), f"{expected_id} op{i}: invalid certificate")
        obs = op.get("observation")
        _need(isinstance(obs, dict), f"{expected_id} op{i}: missing observation")
        for key in obs_prev:
            _integer(obs.get(key), f"{expected_id} op{i} observation.{key}")
            _need(obs[key] >= obs_prev[key], f"{expected_id} op{i}: decreasing observation {key}")
        obs_prev = obs
        if role == "off": _need(all(obs[k] == 0 for k in obs), f"{expected_id}: disabled observer nonzero")
        else:
            filtered = family != "unfiltered" and n > 0
            eval_calls = ((n + 8191)//8192) * (i+1) if filtered else 0
            must = {"evaluation_calls": eval_calls, "input_rows": n*(i+1) if filtered else 0, "mask_calls": eval_calls, "mask_input_rows": n*(i+1) if filtered else 0, "selected_rows": sum(len([r for r in source if _selected(r, family, scenario, j)]) for j in range(i+1)) if filtered else 0}
            for key, val in must.items(): _need(obs[key] == val, f"{expected_id} op{i}: wrong observer {key}")
        _need(obs["evaluation_ns"] + obs["mask_ns"] <= sum(x["engine_execution_ns"] for x in ops[:i+1]), f"{expected_id} op{i}: stage time exceeds engine time")
    _need(rec.get("completed_executions") == calls, f"{expected_id}: workflow completion mismatch")
    for key, expected in {"prepared_source_opens": 0, "admitted_max_parallelism": 1, "provider_background_workers": 0, "reserved_after_cleanup": 0, "denied_reservations": 0}.items(): _need(rec.get(key) == expected, f"{expected_id}: invalid {key}")
    peak = _integer(rec.get("peak_reserved_bytes"), "peak_reserved_bytes")
    _need(peak <= MEMORY_LIMIT, f"{expected_id}: memory limit exceeded")
    expected_workflow = prep + destroy + sum(o["execution_and_consumption_ns"] + o["output_release_ns"] for o in ops)
    _need(rec.get("complete_workflow_ns") == expected_workflow, f"{expected_id}: complete workflow clock mismatch")


def _groups(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    sums: dict[int, int] = {}
    for r in rows: sums[r["g"]] = sums.get(r["g"], 0) + r["v"]
    return [{"g": g, "total": float(sums[g])} for g in sorted(sums)]


def _stream_path(data: Path, mode: str, role: str, cohort: str) -> Path:
    stem = f"preflight-preflight-{role}" if mode == "preflight" else f"measure-{cohort}-{role}"
    return data / f"{stem}.jsonl"


def read(data: Path | str, mode: str, role: str, cohort: str) -> dict[str, Any]:
    data = Path(data)
    _need(mode in ("preflight", "decision") and role in ("off", "on") and cohort in ("preflight", "A", "B"), "invalid stream selector")
    _need((mode == "preflight") == (cohort == "preflight"), "cohort/mode mismatch")
    path = _stream_path(data, mode, role, cohort)
    _need(path.is_file(), f"missing stream: {path.name}")
    raw = path.read_bytes()
    records = []
    for line_no, line in enumerate(raw.splitlines(), 1):
        try: item = json.loads(line)
        except Exception as e: raise Invalid(f"{path.name}:{line_no}: invalid JSON: {e}") from e
        _need(isinstance(item, dict), f"{path.name}:{line_no}: record is not object")
        records.append(item)
    expected_cells = [(n, f, s, c) for n in (0, 17, 8192, 65536) for f in FAMILIES for s in SCENARIOS for c in CALLS]
    expected_cells += [(n, "unfiltered", "unfiltered", c) for n in (0, 17, 8192, 65536) for c in CALLS]
    if mode == "decision": expected_cells = cells()
    warmcell = (8192, "unfiltered", "unfiltered", 1)
    ordered_cells = list(reversed(expected_cells)) if cohort == "B" else expected_cells
    sequence = [(cell, 0, False) for cell in ordered_cells] if mode == "preflight" else [(warmcell, 0, True)]
    if mode == "decision": sequence += [(cell, sample, False) for cell in ordered_cells for sample in SAMPLES]
    _need(len(records) == len(sequence), f"{path.name}: expected {len(sequence)} records, got {len(records)}")
    for rec, (cell, sample, warm) in zip(records, sequence):
        _validate_record(data, rec, mode, role, cohort, sample, cell, warm)
    ops = sum(len(r["operations"]) for r in records)
    expect_ops = 364 if mode == "preflight" else 547
    _need(ops == expect_ops, f"{path.name}: expected {expect_ops} operations, got {ops}")
    return {"records": records, "summary": {"stream": path.name, "sha256": digest(raw), "bytes": len(raw), "workflows": len(records), "operations": ops}}


def analyze(data: Path | str) -> dict[str, Any]:
    data = Path(data)
    loaded = {(cohort, role): read(data, "decision", role, cohort) for cohort in ("A", "B") for role in ("off", "on")}
    # Map records by explicit identity and sample, excluding retained warmup.
    by = {}
    for (cohort, role), bundle in loaded.items():
        rows = [r for r in bundle["records"] if not r["warmup"]]
        by[(cohort, role)] = {(r["cell_id"], r["sample"]): r for r in rows}
        _need(len(by[(cohort, role)]) == 234, f"{cohort}/{role}: duplicate or missing measured identity")
    targets = [(65536, f, "no_true", 4) for f in FAMILIES]
    out = []
    for n, fam, scen, calls in targets:
        cid = f"{n}-{fam}-{scen}-{calls}"
        cohort_data = {}
        cohort_eligible = True
        target_pass = True
        for cohort in ("A", "B"):
            off = [by[(cohort,"off")][(cid,s)] for s in SAMPLES]
            on = [by[(cohort,"on")][(cid,s)] for s in SAMPLES]
            mo = statistics.median(r["complete_workflow_ns"] for r in off)
            mn = statistics.median(r["complete_workflow_ns"] for r in on)
            eo = statistics.median(sum(o["engine_execution_ns"] for o in r["operations"]) for r in off)
            en = statistics.median(sum(o["engine_execution_ns"] for o in r["operations"]) for r in on)
            eligible = not ((en > eo*1.05 and en-eo > 250000) and (mn > mo*1.05 and mn-mo > 250000))
            stage = statistics.median(r["operations"][-1]["observation"]["evaluation_ns"] + r["operations"][-1]["observation"]["mask_ns"] - r["operations"][0]["observation"]["evaluation_ns"] - r["operations"][0]["observation"]["mask_ns"] for r in on)
            qualifies = eligible and stage >= 1000000 and stage >= 0.25*en
            cohort_eligible &= eligible
            target_pass &= qualifies
            cohort_data[cohort] = {"observer_eligible": eligible, "median_enabled_engine_ns": en, "median_disabled_engine_ns": eo, "median_enabled_complete_ns": mn, "median_disabled_complete_ns": mo, "median_enabled_target_stage_ns": stage, "target_qualifies": qualifies}
        out.append({"cell_id": cid, "cohorts": cohort_data, "qualifies_both_cohorts": target_pass})
    qualified = sum(x["qualifies_both_cohorts"] for x in out)
    all_ok = qualified >= 2
    return {"protocol_id": PROTOCOL_ID, "protocol_sha256": digest(PROTOCOL.read_bytes()), "validator_sha256": digest(Path(__file__).read_bytes()), "streams": {f"{c}-{r}": v["summary"] for (c,r),v in loaded.items()}, "targets": out, "qualified_target_count": qualified, "scope_result": "attribution_positive" if all_ok else "no_signal", "production_accepted": False}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=("preflight", "decision"))
    ap.add_argument("--data", type=Path, required=True)
    ap.add_argument("--output", type=Path)
    args = ap.parse_args()
    if args.mode == "preflight":
        report = {"protocol_id": PROTOCOL_ID, "protocol_sha256": digest(PROTOCOL.read_bytes()), "validator_sha256": digest(Path(__file__).read_bytes()), "streams": {r: read(args.data, "preflight", r, "preflight")["summary"] for r in ("off", "on")}, "production_accepted": False}
    else: report = analyze(args.data)
    payload = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with args.output.open("x", encoding="utf-8") as f: f.write(payload)
    else: print(payload, end="")


if __name__ == "__main__": main()
