import importlib.util
import tempfile
import unittest
from pathlib import Path

SPEC = importlib.util.spec_from_file_location("oracle", Path(__file__).with_name("analyze_predicate_exclusion_766.py"))
oracle = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(oracle)


class PredicateOracleTests(unittest.TestCase):
    def test_frozen_matrix_and_counts(self):
        self.assertEqual(len(oracle.cells()), 78)
        self.assertEqual(sum(c[3] for c in oracle.cells()), 182)
        self.assertEqual(oracle._stream_path(Path("/x"), "preflight", "off", "preflight").name, "preflight-preflight-off.jsonl")
        self.assertEqual(oracle._stream_path(Path("/x"), "measure", "on", "B").name, "measure-B-on.jsonl")
        self.assertEqual(oracle.cells((0, 17))[36], (0, "unfiltered", "unfiltered", 1))
        self.assertEqual(oracle.cells((0, 17))[39], (17, "correlated", "no_true", 1))

    def test_independent_predicates_and_source_edges(self):
        src = oracle._source(17, "all_null", "correlated")
        self.assertTrue(all(r["x"] is None and r["y"] is None and r["text"] is None for r in src))
        self.assertFalse(any(oracle._selected(r, "correlated", "all_null", 0) for r in src))
        pos = oracle._source(128, "positive", "contains")
        self.assertTrue(all(oracle._selected(r, "contains", "positive", 0) for r in pos if r["text"] is not None))
        parameter_row = {"x": 1, "y": 0, "text": "item", "g": 0, "v": 0}
        self.assertTrue(oracle._selected(parameter_row, "membership", "changed_parameters", 0))
        self.assertFalse(oracle._selected(parameter_row, "membership", "changed_parameters", 1))

    def test_typed_witness_and_bad_identity_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            d = Path(td)
            (d / "witnesses").mkdir()
            raw = b"[{\"total\": 1}]"
            h = oracle.digest(raw)
            (d / "witnesses" / f"{h}.json").write_bytes(raw)
            with self.assertRaises(oracle.Invalid): oracle._witness(d, h, [{"total": 1.0}], "float")
            with self.assertRaises(oracle.Invalid): oracle._witness(d, "not-a-hash", [], "identity")

    def test_missing_stream_and_output_overwrite_boundary(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(oracle.Invalid): oracle.read(td, "measure", "off", "A")

    def test_either_clock_can_exclude_observation(self):
        self.assertFalse(oracle.observer_eligible(1_000_000, 1_300_000, 4_000_000, 4_000_000))
        self.assertFalse(oracle.observer_eligible(1_000_000, 1_000_000, 4_000_000, 4_300_000))
        self.assertTrue(oracle.observer_eligible(1_000_000, 1_250_000, 4_000_000, 4_250_000))
        self.assertTrue(oracle.observer_eligible(10_000_000, 10_500_000, 20_000_000, 21_000_000))
        self.assertTrue(oracle.observer_eligible(10_000_000, 10_490_000, 20_000_000, 20_900_000))

    def test_same_targets_must_qualify_in_both_cohorts(self):
        from copy import deepcopy
        loaded = {}
        for cohort in ("A", "B"):
            for role in ("off", "on"):
                records = []
                for n, family, scenario, calls in oracle.cells():
                    for sample in oracle.SAMPLES:
                        ops = [{"engine_execution_ns": 1_000_000, "observation": {
                            "evaluation_ns": (i+1)*500_000 if role == "on" else 0,
                            "mask_ns": 0,
                        }} for i in range(calls)]
                        records.append({"cell_id": f"{n}-{family}-{scenario}-{calls}", "sample": sample,
                                        "warmup": False, "complete_workflow_ns": calls*2_000_000,
                                        "operations": ops})
                loaded[cohort,role] = {"records": records, "summary": {}}
        self.assertEqual(oracle.decide(loaded)["qualified_target_count"], 3)
        changed = deepcopy(loaded)
        for cohort, excluded in (("A", "correlated"), ("B", "membership")):
            for r in changed[cohort,"on"]["records"]:
                if r["cell_id"] == f"65536-{excluded}-no_true-4":
                    r["operations"][-1]["engine_execution_ns"] += 300_000
        result = oracle.decide(changed)
        self.assertEqual(result["qualified_target_count"], 1)
        self.assertEqual(result["scope_result"], "no_signal")

    def test_exact_observation_clock_and_completion_fields(self):
        from unittest.mock import patch
        from copy import deepcopy
        obs = {k:0 for k in ("evaluation_calls","input_rows","mask_calls","mask_input_rows","selected_rows","evaluation_ns","mask_ns")}
        rec = {"protocol_id":oracle.PROTOCOL_ID,"cell_id":"0-correlated-no_true-2","rows":0,
               "family":"correlated","scenario":"no_true","calls":2,"mode":"preflight","role":"on",
               "cohort":"preflight","sample":0,"warmup":False,"preparation_ns":10,"destruction_ns":10,
               "completed_executions":2,"prepared_source_opens":0,"admitted_max_parallelism":1,
               "provider_background_workers":0,"reserved_after_cleanup":0,"denied_reservations":0,
               "peak_reserved_bytes":10,"complete_workflow_ns":44,"operations":[]}
        for i in range(2):
            rec["operations"].append({"call":i,"consumer":"count" if i==0 else "grouped_sum",
                "rows":1 if i==0 else 0,"engine_execution_ns":8,"result_serialization_ns":2,
                "execution_and_consumption_ns":11,"output_release_ns":1,"completed_executions":i+1,
                "observation":dict(obs),"native_io_certificate":{"certified":True,"fallback_attempted":False,"complete_debug":"native"}})
        def check(r): oracle._validate_record(Path("/unused"),r,"preflight","on","preflight",0,(0,"correlated","no_true",2),False)
        with patch.object(oracle,"_witness"):
            check(rec)
            for where,field,value in ((1,"completed_executions",1),(0,"engine_execution_ns",10),(0,"rows",True)):
                changed=deepcopy(rec); changed["operations"][where][field]=value
                with self.assertRaises(oracle.Invalid): check(changed)
            changed=deepcopy(rec); changed["operations"][0]["observation"]["evaluation_ns"]=1
            with self.assertRaises(oracle.Invalid): check(changed)


if __name__ == "__main__":
    unittest.main()
