"""Create a portable packet for completed predicate-exclusion attribution evidence.

This is a packaging-only script. It does not run ShardLoom, build or test the
repository, or modify repository files. It requires the accepted row-6 verifier
receipt before packaging and refuses to overwrite an existing packet.
"""

from __future__ import annotations

import hashlib
import io
import json
import lzma
import os
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019')
REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
LOCALDATA = Path('/Users/dylan/LocalData/shardloom')
DEST = ROOT / 'predicate-attribution-portable-767'
NAME = 'predicate-attribution-portable-767'
PROTOCOL_PATH = ROOT / 'predicate-exclusion-attribution-protocol-766.json'
VERIFICATION_PATH = ROOT / 'predicate-exclusion-verification-767.json'
SOURCE_A1_PATH = ROOT / 'predicate-attribution-767-a1-source-freeze.json'
SOURCE_A2_PATH = ROOT / 'predicate-attribution-767-a2-source-freeze.json'
ARTIFACT_A2_PATH = ROOT / 'predicate-attribution-767-a2-artifact.json'
SEQUENCE_PATH = ROOT / 'predicate-exclusion-sequence-767-a1.json'
TEST_ARTIFACT_PATH = ROOT / 'predicate-attribution-767-a2-test'
EXPECTED_HEAD = '896c71793a8859a6b4770bbc8a9fe0b85d755cf8'
EXPECTED_PROTOCOL_SHA256 = '153892a4e056c9adf769dd65ba758ec304f70a2f8d62111d3b96197842d9a5e3'
EXPECTED_TARGETS = {'correlated', 'membership', 'contains'}

sys.path.insert(0, str(REPO / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


# Deliberately fixed to the completed a1/a2 attribution run. Newly created
# candidate artifacts or mutable packaging/reopen logs are not picked up.
TOP_LEVEL_EVIDENCE = (
    'predicate-attribution-767-a1-source-freeze.json',
    'predicate-attribution-767-a1-tracked.patch',
    'predicate-attribution-767-a2-artifact.json',
    'predicate-attribution-767-a2-source-freeze.json',
    'predicate-attribution-767-a2-test-inventory.txt',
    'predicate-attribution-767-a2-tracked.patch',
    'predicate-attribution-build-767-a1.json',
    'predicate-attribution-build-767-a1.log',
    'predicate-attribution-build-767-a2.json',
    'predicate-attribution-build-767-a2.log',
    'predicate-attribution-build-driver-767-a1.log',
    'predicate-attribution-build-driver-767-a2.log',
    'predicate-attribution-harness-review-767.json',
    'predicate-decision-767-a1-sequence.log',
    'predicate-exclusion-attribution-protocol-766.json',
    'predicate-exclusion-cargo-metadata-766.json',
    'predicate-exclusion-decision-767-a1.json',
    'predicate-exclusion-preflight-767-a1.json',
    'predicate-exclusion-sequence-767-a1.json',
    'predicate-exclusion-sequence-driver-767-a1.log',
    'predicate-exclusion-verification-767.json',
    'predicate-exclusion-verification-driver-767.log',
    'predicate-final-source-verify-767-a1-sequence.log',
    'predicate-measure-A-off-767-a1-link.json',
    'predicate-measure-A-off-767-a1-sequence.log',
    'predicate-measure-A-off-767-a1.json',
    'predicate-measure-A-off-767-a1.log',
    'predicate-measure-A-on-767-a1-link.json',
    'predicate-measure-A-on-767-a1-sequence.log',
    'predicate-measure-A-on-767-a1.json',
    'predicate-measure-A-on-767-a1.log',
    'predicate-measure-B-off-767-a1-link.json',
    'predicate-measure-B-off-767-a1-sequence.log',
    'predicate-measure-B-off-767-a1.json',
    'predicate-measure-B-off-767-a1.log',
    'predicate-measure-B-on-767-a1-link.json',
    'predicate-measure-B-on-767-a1-sequence.log',
    'predicate-measure-B-on-767-a1.json',
    'predicate-measure-B-on-767-a1.log',
    'predicate-oracle-before-primary-review-767.py',
    'predicate-preflight-off-767-a1-link.json',
    'predicate-preflight-off-767-a1-sequence.log',
    'predicate-preflight-off-767-a1.json',
    'predicate-preflight-off-767-a1.log',
    'predicate-preflight-on-767-a1-link.json',
    'predicate-preflight-on-767-a1-sequence.log',
    'predicate-preflight-on-767-a1.json',
    'predicate-preflight-on-767-a1.log',
    'predicate-preflight-verify-767-a1-sequence.log',
    'predicate_exclusion_driver_767.py',
)

ROOT_TOOLS = (
    'analyze_predicate_exclusion_766.py',
    'test_predicate_oracle_766.py',
    'run_predicate_exclusion_767.py',
    'verify_predicate_exclusion_767.py',
    'run_guarded_observed_757.py',
    'package_predicate_attribution_767.py',
    'attribution-packager-before-primary-review-768.py',
)

# run_guarded_observed_757.py imports the storage and workload guards, obtains
# a host snapshot through the paired-query runner, and loads the shared bounded
# process supervisor by path. The runner's local import closure is included too.
GUARD_DEPENDENCY_SOURCES = (
    ('repo', 'scripts/local_uat_storage.py'),
    ('repo', 'scripts/run_clickbench_paired_query_uat.py'),
    ('repo', 'scripts/native_workflow_protocol.py'),
    ('repo', 'scripts/query_timing_report.py'),
    ('repo', 'scripts/clickbench_reference_packet.py'),
    ('repo', 'scripts/run_clickbench_query_uat.py'),
    ('repo', 'python/src/shardloom/__init__.py'),
    ('repo', 'python/src/shardloom/_exports.py'),
    ('repo', 'python/src/shardloom/_result_schema.py'),
    ('repo', 'python/src/shardloom/errors.py'),
    ('repo', 'python/src/shardloom/_compat.py'),
    ('repo', 'python/src/shardloom/models.py'),
    ('local', 'release-0.3.3-20260930/release_validation_guard.py'),
    ('local', 'perf-all-20260906/bounded_build_process_resume_20260912.py'),
)


def sha256_file(path: Path) -> str:
    hasher = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            hasher.update(chunk)
    return hasher.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def encode_json(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def identity(path: Path) -> dict[str, object]:
    path = Path(path)
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': sha256_file(path)}


def read_json(path: Path) -> dict:
    return json.loads(Path(path).read_text())


def add_file(members: dict[str, Path], member_name: str, source: Path) -> None:
    source = Path(source)
    assert source.is_file() and not source.is_symlink(), f'not a regular file: {source}'
    assert member_name and not member_name.startswith('/')
    assert '..' not in Path(member_name).parts, member_name
    old = members.get(member_name)
    assert old is None or old.resolve() == source.resolve(), f'duplicate member: {member_name}'
    members[member_name] = source


def archive_path(path: Path) -> str:
    path = Path(path).resolve(strict=True)
    if path.is_relative_to(ROOT):
        return 'evidence/' + path.relative_to(ROOT).as_posix()
    if path.is_relative_to(REPO):
        return 'repo/' + path.relative_to(REPO).as_posix()
    if path.is_relative_to(LOCALDATA):
        return 'local/' + path.relative_to(LOCALDATA).as_posix()
    raise AssertionError(f'input outside approved local roots: {path}')


def add_regular_tree(members: dict[str, Path], source_root: Path,
                     member_root: str) -> list[Path]:
    source_root = Path(source_root)
    assert source_root.is_dir() and not source_root.is_symlink(), source_root
    paths = []
    for path in sorted(source_root.rglob('*')):
        if path.is_dir():
            assert not path.is_symlink(), path
            continue
        assert path.is_file() and not path.is_symlink(), path
        relative = path.relative_to(source_root).as_posix()
        add_file(members, member_root.rstrip('/') + '/' + relative, path)
        paths.append(path)
    return paths


def validate_receipt_logs() -> None:
    """Bind every allowlisted supervised proof receipt to its retained log."""
    for name in TOP_LEVEL_EVIDENCE:
        path = ROOT / name
        if path.suffix != '.json':
            continue
        try:
            receipt = read_json(path)
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
        expected = receipt.get('log_sha256')
        if not expected:
            continue
        log_path = path.with_suffix('.log')
        assert log_path.is_file() and not log_path.is_symlink(), log_path
        assert sha256_file(log_path) == expected, log_path


def validate_completed_evidence() -> tuple[dict, dict, dict, dict, dict]:
    protocol = read_json(PROTOCOL_PATH)
    verification = read_json(VERIFICATION_PATH)
    freeze_a1 = read_json(SOURCE_A1_PATH)
    freeze_a2 = read_json(SOURCE_A2_PATH)
    artifact_a2 = read_json(ARTIFACT_A2_PATH)
    sequence = read_json(SEQUENCE_PATH)

    assert protocol.get('schema_version') == 'shardloom.predicate_exclusion_attribution_protocol.v1'
    assert protocol.get('protocol_id') == 'predicate-exclusion-attribution-766-v1'
    assert protocol.get('owner') == 'PERF-10.predicate_exclusion'
    assert protocol.get('status') == 'frozen_before_observer_harness_and_measurement'
    assert sha256_file(PROTOCOL_PATH) == EXPECTED_PROTOCOL_SHA256
    assert verification.get('status') == 'passed'
    assert verification.get('protocol_sha256') == EXPECTED_PROTOCOL_SHA256
    assert verification.get('workflows') == 1252
    assert verification.get('operations') == 2916
    assert verification.get('full_content_witnesses') == 42
    assert verification.get('production_head') == EXPECTED_HEAD
    assert verification.get('production_accepted') is False
    assert verification.get('scope_result') == 'attribution_positive'
    assert set(verification.get('common_qualifying_families', [])) == EXPECTED_TARGETS
    assert len(verification.get('independently_recomputed_targets', [])) == 3
    assert sequence.get('status') == 'passed' and len(sequence.get('steps', [])) == 9
    for step in sequence['steps']:
        assert step.get('status') == 'passed' and step.get('returncode') == 0
        log = Path(step['log'])
        assert log.is_file() and sha256_file(log) == step['log_sha256'], log

    assert freeze_a1.get('head') == freeze_a2.get('head') == EXPECTED_HEAD
    assert freeze_a1.get('protocol_sha256') == freeze_a2.get('protocol_sha256') == EXPECTED_PROTOCOL_SHA256
    assert freeze_a1.get('patch_sha256') == freeze_a2.get('patch_sha256')
    for freeze_path, freeze in ((SOURCE_A1_PATH, freeze_a1), (SOURCE_A2_PATH, freeze_a2)):
        patch_path = ROOT / freeze_path.name.replace('source-freeze.json', 'tracked.patch')
        assert sha256_file(patch_path) == freeze['patch_sha256'], patch_path
        for helper in freeze.get('helpers', []):
            helper_path = Path(helper['path'])
            assert helper_path.is_file() and not helper_path.is_symlink(), helper_path
            assert sha256_file(helper_path) == helper['sha256'], helper_path
        extra_root = ROOT / freeze_path.name.replace('source-freeze.json', 'extra-sources')
        declared = set(freeze.get('extra_sources', []))
        actual = {path.relative_to(extra_root).as_posix()
                  for path in extra_root.rglob('*') if path.is_file()}
        assert actual == declared, (extra_root, actual, declared)
        frozen_sources = {row['path']: row for row in freeze['sources']}
        for relative in sorted(declared):
            frozen_copy = extra_root / relative
            expected = frozen_sources[relative]
            assert frozen_copy.stat().st_size == expected['bytes'], relative
            assert sha256_file(frozen_copy) == expected['sha256'], relative
            if freeze_path == SOURCE_A2_PATH:
                working_source = REPO / relative
                assert working_source.is_file() and not working_source.is_symlink(), working_source
                assert sha256_file(frozen_copy) == sha256_file(working_source), relative

    build_a1_path = ROOT / 'predicate-attribution-build-767-a1.json'
    build_a2_path = ROOT / 'predicate-attribution-build-767-a2.json'
    build_a1 = read_json(build_a1_path)
    build_a2 = read_json(build_a2_path)
    assert build_a1.get('status') == 'failed' and build_a1.get('returncode') != 0
    assert build_a2.get('status') == 'passed' and build_a2.get('returncode') == 0
    assert build_a2.get('process_group_drained') is True
    assert sha256_file(build_a1_path.with_suffix('.log')) == build_a1['log_sha256']
    assert sha256_file(build_a2_path.with_suffix('.log')) == build_a2['log_sha256']
    assert artifact_a2.get('build_receipt_sha256') == sha256_file(build_a2_path)
    assert artifact_a2.get('source_freeze_sha256') == sha256_file(SOURCE_A2_PATH)
    assert artifact_a2.get('artifact') == str(TEST_ARTIFACT_PATH)
    assert artifact_a2.get('bytes') == TEST_ARTIFACT_PATH.stat().st_size
    assert artifact_a2.get('artifact_sha256') == sha256_file(TEST_ARTIFACT_PATH)
    source_binding = verification.get('source_binding', {})
    artifact_binding = verification.get('artifact', {})
    assert source_binding == {
        'path': SOURCE_A2_PATH.name,
        'bytes': SOURCE_A2_PATH.stat().st_size,
        'sha256': sha256_file(SOURCE_A2_PATH),
    }
    assert artifact_binding == {
        'path': ARTIFACT_A2_PATH.name,
        'bytes': ARTIFACT_A2_PATH.stat().st_size,
        'sha256': sha256_file(ARTIFACT_A2_PATH),
    }
    validate_receipt_logs()
    return protocol, verification, freeze_a1, freeze_a2, artifact_a2


def main() -> None:
    assert ROOT == Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019')
    assert not DEST.exists(), f'refusing to overwrite an existing packet: {DEST}'
    require_local_path(ROOT, Path.home(), sys.platform)
    require_local_path(DEST, Path.home(), sys.platform)

    protocol, verification, freeze_a1, freeze_a2, artifact_a2 = validate_completed_evidence()
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    assert head == EXPECTED_HEAD, f'expected production HEAD {EXPECTED_HEAD}, got {head}'
    build_a2 = read_json(ROOT / 'predicate-attribution-build-767-a2.json')

    members: dict[str, Path] = {}
    for name in TOP_LEVEL_EVIDENCE:
        path = ROOT / name
        assert path.is_file() and not path.is_symlink(), path
        add_file(members, archive_path(path), path)
    for name in ROOT_TOOLS:
        path = ROOT / name
        assert path.is_file() and not path.is_symlink(), path
        add_file(members, archive_path(path), path)

    # Archive both source snapshots, including a1's failed-build sources, and
    # the full immutable measurement tree with all six raw streams/witnesses.
    source_dirs = {}
    for label in ('a1', 'a2'):
        freeze = freeze_a1 if label == 'a1' else freeze_a2
        source_root = ROOT / f'predicate-attribution-767-{label}-extra-sources'
        paths = add_regular_tree(members, source_root, f'sources/{label}-extra')
        source_dirs[label] = paths
        assert len(paths) == len(freeze['extra_sources'])
    data_paths = add_regular_tree(members, ROOT / 'predicate-exclusion-767-a1', 'comparison')
    data_root = ROOT / 'predicate-exclusion-767-a1'
    stream_paths = sorted(data_root.glob('*.jsonl'))
    witness_paths = sorted((data_root / 'witnesses').glob('*.json'))
    assert len(stream_paths) == 6 and len(witness_paths) == 42
    assert set(data_paths) == set(stream_paths + witness_paths)

    # Preserve the exact shared guard/dependency sources used by the guarded
    # worker; archive members retain repository/local origin and relative paths.
    for origin, relative in GUARD_DEPENDENCY_SOURCES:
        base = REPO if origin == 'repo' else LOCALDATA
        path = base / relative
        assert path.is_file() and not path.is_symlink(), path
        add_file(members, archive_path(path), path)

    assert TEST_ARTIFACT_PATH.is_file() and not TEST_ARTIFACT_PATH.is_symlink()
    omitted_binary = {
        'path': str(TEST_ARTIFACT_PATH),
        'bytes': artifact_a2['bytes'],
        'sha256': artifact_a2['artifact_sha256'],
        'copied': False,
        'reason': 'large compiled test executable intentionally excluded',
        'reproduction': {
            'artifact_receipt': 'evidence/predicate-attribution-767-a2-artifact.json',
            'build_receipt': 'evidence/predicate-attribution-build-767-a2.json',
            'build_log': 'evidence/predicate-attribution-build-767-a2.log',
            'source_freeze': 'evidence/predicate-attribution-767-a2-source-freeze.json',
            'tracked_patch': 'evidence/predicate-attribution-767-a2-tracked.patch',
            'extra_sources': 'sources/a2-extra/',
            'build_command': build_a2['command'],
            'cargo_target_cache': '/Users/dylan/.cache/shardloom/cargo-target',
        },
    }

    # Freeze and hash the allowlisted input set before creating the packet.
    inventory = []
    frozen_members = {}
    for member_name, source in sorted(members.items()):
        data = source.read_bytes()
        row = {'path': member_name, 'original_path': str(source),
               'bytes': len(data), 'sha256': sha256_bytes(data)}
        inventory.append(row)
        frozen_members[member_name] = (row['bytes'], row['sha256'])
    assert inventory
    assert all(not row['path'].startswith('comparison/predicate-attribution-767-a2-test')
               for row in inventory)

    require_local_path(DEST, Path.home(), sys.platform)
    storage_before = check_budgets(
        ROOT, DEST, ROOT,
        min_free_bytes=12 * GIB,
        reserve_bytes=128 * MIB,
        max_workspace_bytes=100 * GIB,
        max_log_bytes=192 * MIB,
    )
    assert not DEST.exists(), f'refusing to overwrite an existing packet: {DEST}'
    DEST.mkdir()
    archive_file = DEST / f'{NAME}.tar.xz'
    with tarfile.open(archive_file, mode='x:xz', format=tarfile.PAX_FORMAT, preset=6) as archive:
        for row in inventory:
            source = members[row['path']]
            data = source.read_bytes()
            assert (len(data), sha256_bytes(data)) == (row['bytes'], row['sha256']), source
            info = tarfile.TarInfo(row['path'])
            info.size = len(data)
            info.mode = 0o644
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            info.mtime = 0
            archive.addfile(info, io.BytesIO(data))

    with tarfile.open(archive_file, mode='r:xz') as archive:
        assert archive.getnames() == [row['path'] for row in inventory]
        for row in inventory:
            member = archive.extractfile(row['path'])
            assert member is not None
            data = member.read()
            assert (len(data), sha256_bytes(data)) == (row['bytes'], row['sha256']), row['path']
    for name, source in members.items():
        assert (source.stat().st_size, sha256_file(source)) == frozen_members[name], source

    manifest = {
        'schema_version': 'shardloom.evidence_member_manifest.v1',
        'all_members_reopened': True,
        'members': inventory,
    }
    manifest_file = DEST / f'{NAME}.manifest.json.xz'
    manifest_data = lzma.compress(encode_json(manifest), preset=6)
    with manifest_file.open('xb') as stream:
        stream.write(manifest_data)
    assert json.loads(lzma.decompress(manifest_file.read_bytes())) == manifest

    index = {
        'schema_version': 'shardloom.predicate_attribution_portable_packet.v1',
        'status': 'verified_positive_attribution_evidence',
        'production_accepted': False,
        'scope_result': verification['scope_result'],
        'claim_boundary': 'Attribution evidence only; no production optimization or performance claim.',
        'protocol': identity(PROTOCOL_PATH),
        'verification': identity(VERIFICATION_PATH),
        'source_freezes': {
            'failed_build_a1': identity(SOURCE_A1_PATH),
            'successful_build_a2': identity(SOURCE_A2_PATH),
            'a1_tracked_patch': identity(ROOT / 'predicate-attribution-767-a1-tracked.patch'),
            'a2_tracked_patch': identity(ROOT / 'predicate-attribution-767-a2-tracked.patch'),
            'a1_extra_sources': [str(path) for path in source_dirs['a1']],
            'a2_extra_sources': [str(path) for path in source_dirs['a2']],
            'a1_failed_build_receipt': identity(ROOT / 'predicate-attribution-build-767-a1.json'),
            'a2_passed_build_receipt': identity(ROOT / 'predicate-attribution-build-767-a2.json'),
            'a1_failed_build_preserved': True,
        },
        'measured_scope': {
            'workflows': verification['workflows'],
            'operations': verification['operations'],
            'full_content_witnesses': verification['full_content_witnesses'],
            'common_qualifying_families': verification['common_qualifying_families'],
            'all_three_targets_qualify': set(verification['common_qualifying_families']) == EXPECTED_TARGETS,
            'production_accepted': False,
        },
        'preserved_review_context': {
            'harness_review': identity(ROOT / 'predicate-attribution-harness-review-767.json'),
            'original_worker_oracle_before_primary_review': identity(ROOT / 'predicate-oracle-before-primary-review-767.py'),
            'reviewed_worker_oracle': identity(ROOT / 'analyze_predicate_exclusion_766.py'),
            'packager_primary_review': 'Historical a1 extra sources are verified against their own frozen identities; only a2 must equal the working source. Corrected the reviewed-oracle pointer before first packaging run; preserved the original script.',
        },
        'inclusions': {
            'allowlisted_current_predicate_evidence_files': list(TOP_LEVEL_EVIDENCE),
            'drivers_and_packager': list(ROOT_TOOLS),
            'raw_streams': [str(path) for path in stream_paths],
            'witness_count': len(witness_paths),
            'extra_source_files': {label: [str(path) for path in paths]
                                   for label, paths in source_dirs.items()},
            'guard_dependency_sources': [str((REPO if origin == 'repo' else LOCALDATA) / relative)
                                         for origin, relative in GUARD_DEPENDENCY_SOURCES],
            'cargo_cache_included': False,
            'native_input_dataset_included': False,
            'package_environment_included': False,
        },
        'omitted_compiled_test_executable': omitted_binary,
        'excluded_future_or_mutable_artifacts': {
            'later_candidate_work': 'not in the fixed allowlist or named source trees',
            'packaging_or_reopen_logs': 'not in the fixed allowlist',
        },
        'storage_check': {
            'guard': 'local_uat_storage.require_local_path and check_budgets',
            'before_write': storage_before,
            'limits': {'minimum_free_bytes': 12 * GIB,
                       'candidate_reserve_bytes': 128 * MIB,
                       'maximum_workspace_bytes': 100 * GIB,
                       'maximum_log_bytes': 192 * MIB},
        },
        'member_count': len(inventory),
        'uncompressed_bytes': sum(row['bytes'] for row in inventory),
        'all_members_reopened': True,
        'archive': {'file': archive_file.name, 'bytes': archive_file.stat().st_size,
                    'sha256': sha256_file(archive_file)},
        'manifest': {'file': manifest_file.name, 'bytes': manifest_file.stat().st_size,
                     'sha256': sha256_file(manifest_file)},
    }
    index_file = DEST / f'{NAME}.json'
    with index_file.open('xb') as stream:
        stream.write(encode_json(index))
    check_budgets(
        ROOT, DEST, ROOT,
        min_free_bytes=12 * GIB,
        reserve_bytes=0,
        max_workspace_bytes=100 * GIB,
        max_log_bytes=192 * MIB,
    )
    print(json.dumps({'status': 'passed', 'members': len(inventory),
                      'uncompressed_bytes': index['uncompressed_bytes'],
                      'archive': index['archive'], 'manifest': index['manifest'],
                      'index': str(index_file), 'all_members_reopened': True}))


if __name__ == '__main__':
    main()
