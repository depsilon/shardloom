"""Sequential correctness preflight, two frozen cohorts, then comparative analysis."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
LABEL = 'predicate-attribution-767-a2'
DATA = OUT/'predicate-exclusion-767-a1'
DRIVER = OUT/'predicate_exclusion_driver_767.py'
ANALYZER = OUT/'analyze_predicate_exclusion_766.py'
RECEIPT = OUT/'predicate-exclusion-sequence-767-a1.json'
assert not RECEIPT.exists()
record = dict(status='running', driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), steps=[])

def save(): RECEIPT.write_text(json.dumps(record, indent=2)+'\n')
def run(name, command):
    step = dict(name=name, command=command, status='running')
    record['steps'].append(step); save()
    print(name, flush=True)
    log=OUT/f'{name}-sequence.log'
    started=time.monotonic()
    with log.open('xb') as stream:
        code=subprocess.call(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    step.update(returncode=code, status='passed' if code==0 else 'failed',
                diagnostic_seconds=time.monotonic()-started, log=str(log),
                log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    save()
    if code: raise RuntimeError(f'{name}: exited {code}')

try:
    for role in ('off','on'):
        name=f'predicate-preflight-{role}-767-a1'
        run(name,[sys.executable,'-B',str(DRIVER),'run','--label',LABEL,'--data',DATA.name,
                  '--name',name,'--mode','preflight','--role',role,'--cohort','preflight'])
    run('predicate-preflight-verify-767-a1',[sys.executable,'-B',str(ANALYZER),'preflight',
        '--data',str(DATA),'--output',str(OUT/'predicate-exclusion-preflight-767-a1.json')])
    for cohort,roles in (('A',('off','on')),('B',('on','off'))):
        for role in roles:
            name=f'predicate-measure-{cohort}-{role}-767-a1'
            run(name,[sys.executable,'-B',str(DRIVER),'run','--label',LABEL,'--data',DATA.name,
                      '--name',name,'--mode','measure','--role',role,'--cohort',cohort])
    run('predicate-decision-767-a1',[sys.executable,'-B',str(ANALYZER),'decision',
        '--data',str(DATA),'--output',str(OUT/'predicate-exclusion-decision-767-a1.json')])
    run('predicate-final-source-verify-767-a1',[sys.executable,'-B',str(DRIVER),'verify','--label',LABEL])
    record['status']='passed'
except BaseException as error:
    record.update(status='failed',error=type(error).__name__+': '+str(error)); raise
finally: save()
