//! Serial test-only attribution of the existing native memory predicate path.

use std::{
    sync::atomic::{AtomicBool, AtomicU64, Ordering},
    time::Instant,
};

static ACTIVE: AtomicBool = AtomicBool::new(false);
static ENABLED: AtomicBool = AtomicBool::new(false);
static EVALUATION_CALLS: AtomicU64 = AtomicU64::new(0);
static INPUT_ROWS: AtomicU64 = AtomicU64::new(0);
static MASK_CALLS: AtomicU64 = AtomicU64::new(0);
static MASK_INPUT_ROWS: AtomicU64 = AtomicU64::new(0);
static SELECTED_ROWS: AtomicU64 = AtomicU64::new(0);
static EVALUATION_NS: AtomicU64 = AtomicU64::new(0);
static MASK_NS: AtomicU64 = AtomicU64::new(0);

pub(super) fn begin() -> Option<Instant> {
    ENABLED.load(Ordering::Relaxed).then(Instant::now)
}

pub(super) fn evaluation(started: Option<Instant>, rows: usize) {
    if let Some(started) = started {
        EVALUATION_NS.fetch_add(
            u64::try_from(started.elapsed().as_nanos()).unwrap(),
            Ordering::Relaxed,
        );
        EVALUATION_CALLS.fetch_add(1, Ordering::Relaxed);
        INPUT_ROWS.fetch_add(rows as u64, Ordering::Relaxed);
    }
}

pub(super) fn mask(started: Option<Instant>, input: usize, selected: usize) {
    if let Some(started) = started {
        MASK_NS.fetch_add(
            u64::try_from(started.elapsed().as_nanos()).unwrap(),
            Ordering::Relaxed,
        );
        MASK_CALLS.fetch_add(1, Ordering::Relaxed);
        MASK_INPUT_ROWS.fetch_add(input as u64, Ordering::Relaxed);
        SELECTED_ROWS.fetch_add(selected as u64, Ordering::Relaxed);
    }
}

pub(crate) struct Session;

impl Session {
    pub(crate) fn start(enabled: bool) -> Self {
        assert!(
            !ACTIVE.swap(true, Ordering::SeqCst),
            "predicate attribution requires serial execution"
        );
        ENABLED.store(false, Ordering::SeqCst);
        for counter in [
            &EVALUATION_CALLS,
            &INPUT_ROWS,
            &MASK_CALLS,
            &MASK_INPUT_ROWS,
            &SELECTED_ROWS,
            &EVALUATION_NS,
            &MASK_NS,
        ] {
            counter.store(0, Ordering::Relaxed);
        }
        ENABLED.store(enabled, Ordering::SeqCst);
        Self
    }

    pub(crate) fn snapshot(&self) -> serde_json::Value {
        serde_json::json!({
            "evaluation_calls": EVALUATION_CALLS.load(Ordering::Relaxed),
            "input_rows": INPUT_ROWS.load(Ordering::Relaxed),
            "mask_calls": MASK_CALLS.load(Ordering::Relaxed),
            "mask_input_rows": MASK_INPUT_ROWS.load(Ordering::Relaxed),
            "selected_rows": SELECTED_ROWS.load(Ordering::Relaxed),
            "evaluation_ns": EVALUATION_NS.load(Ordering::Relaxed),
            "mask_ns": MASK_NS.load(Ordering::Relaxed),
        })
    }
}

impl Drop for Session {
    fn drop(&mut self) {
        ENABLED.store(false, Ordering::SeqCst);
        ACTIVE.store(false, Ordering::SeqCst);
    }
}
