"""Immutable identities for the finite native builder ownership unit."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PYTHON = '/opt/homebrew/opt/python@3.13/libexec/bin/python3'
RUSTUP = '/Users/dylan/.cargo/bin/rustup'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def source_hashes():
    names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
    return {name: sha(ROOT / name) for name in sorted(set(names)) if name and (
        name.endswith(('.rs', '.py')) or Path(name).name in ('Cargo.toml', 'Cargo.lock')
        or name.startswith('vendor/'))}


def frozen(attempt=1):
    source = read(OUT / f'builder-source-{attempt}.json')
    assert source_hashes() == source['source_hashes']
    assert git('rev-parse', 'HEAD') == source['head']
    assert sha(OUT / 'builder-cost-contract.json') == source['contract_sha256']
    assert all(sha(OUT / name) == digest for name, digest in source['helpers'].items())
    return source
