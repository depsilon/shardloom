"""Verify the builder documentation and website surfaces against frozen source."""
import json
import subprocess
import time

import builder_common as c


DOCUMENTATION_PATHS = [
    'docs/architecture/native-builder-resources-2026-10-07.md',
    'docs/architecture/native-state-structure-campaign-2026-10-07.md',
    'docs/benchmarks/native-builder-resources-2026-10-07.md',
    'docs/architecture/phased-execution-plan.md',
    'docs/release/v1-inclusion-scope-matrix.md',
    'docs/release/public-status-matrix.md',
    'docs/architecture/v1-local-resource-safety.md',
    'docs/architecture/local-development-storage.md',
    'docs/dependencies/vortex-upstream-review.md',
    'docs/architecture/universal-workflow-completion-2026-10-01.md',
    'website-src/scripts/sync-content.mjs',
    'website-src/src/content/docs/field-guide/runtime-and-io.mdx',
    'website-src/src/content/docs/field-guide/limitations.mdx',
]


def main():
    source = c.read(c.OUT / 'builder-source-1.json')
    assert c.source_hashes() == source['source_hashes']
    build = c.read(c.OUT / 'builder-build-1.json')
    assert c.sha(build['binary']) == build['binary_sha256']
    out = c.OUT / 'builder-documentation-checks-2'
    out.mkdir(exist_ok=False)
    checks = []
    commands = [
        ('user-surface-index', [c.PYTHON, '-B', 'scripts/check_user_surface_reference.py'], c.ROOT),
        ('public-status', [c.PYTHON, '-B', 'scripts/check_public_status_docs.py', '--output', str(out / 'public-status-report.json')], c.ROOT),
        ('use-case-backlinks', [c.PYTHON, '-B', 'scripts/check_use_case_backlinks.py'], c.ROOT),
        ('website-check', ['npm', 'run', 'check'], c.ROOT / 'website-src'),
        ('website-build', ['npm', 'run', 'build'], c.ROOT / 'website-src'),
        ('website-readiness', [c.PYTHON, '-B', 'scripts/check_website_readiness.py', '--output', str(out / 'website-readiness-report.json')], c.ROOT),
        ('diff-whitespace', ['git', 'diff', '--check'], c.ROOT),
    ]
    for name, command, cwd in commands:
        assert c.source_hashes() == source['source_hashes'], f'source changed before {name}'
        path = out / f'{name}.log'
        start = time.monotonic()
        with path.open('xb') as stream:
            result = subprocess.run(command, cwd=cwd, stdout=stream,
                                    stderr=subprocess.STDOUT, timeout=300, check=False)
        item = {'name': name, 'command': command, 'cwd': str(cwd),
                'returncode': result.returncode, 'seconds': time.monotonic() - start,
                'log': str(path), 'log_sha256': c.sha(path)}
        checks.append(item)
        print(json.dumps(item), flush=True)
        c.write(out / f'{name}-receipt.json', item)
        assert c.source_hashes() == source['source_hashes'], f'source changed after {name}'
        assert result.returncode == 0, name

    documentation_source_hashes = {
        name: c.sha(c.ROOT / name) for name in DOCUMENTATION_PATHS
    }
    result = {
        'status': 'passed',
        'checks': checks,
        'source_identity_sha256': source['source_identity_sha256'],
        'runtime_source_assets_verified': len(source['source_hashes']),
        'binary_sha256': build['binary_sha256'],
        'documentation_source_hashes': documentation_source_hashes,
        'driver_sha256': c.sha(__file__),
        'examples_changed': False,
        'new_runtime_execution_required': False,
        'browser_visual_qa': 'pending',
        'hosted_integration': 'pending',
    }
    c.write(out / 'summary.json', result)
    print(json.dumps({'status': 'passed', 'checks': len(checks)}), flush=True)


if __name__ == '__main__':
    main()
