"""Archive exact builder documentation source and observed browser evidence."""
import hashlib
import io
import json
import tarfile
from pathlib import Path

import builder_common as c


RUNTIME_COMMIT = '53cd1582a5975ac4e206a21e45415c919c5b6b4f'


def main():
    source = c.read(c.OUT / 'builder-source-1.json')
    assert c.source_hashes() == source['source_hashes']
    assert c.git('rev-parse', 'HEAD') == RUNTIME_COMMIT
    checks = c.read(c.OUT / 'builder-documentation-checks-2/summary.json')
    assert checks['status'] == 'passed' and len(checks['checks']) == 7
    for row in checks['checks']:
        assert row['returncode'] == 0 and c.sha(row['log']) == row['log_sha256']
    for name in ('builder-documentation-checks-1', 'builder-documentation-checks-2',
                 'builder-documentation-preview-1'):
        receipt = c.read(c.OUT / f'{name}.json')
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert c.sha(c.OUT / f'{name}.log') == receipt['log_sha256']
    assert (c.OUT / 'builder-documentation-preview-stop-1').is_file()
    browser = c.read(c.OUT / 'builder-documentation-browser-1.json')
    assert browser['status'] == 'passed_manual_browser_review'

    paths = {}
    for prefix in ('builder-documentation-', 'builder-docs-'):
        for path in sorted(c.OUT.glob(prefix + '*')):
            for item in sorted(path.rglob('*')) if path.is_dir() else [path]:
                if item.is_file():
                    paths['proof/' + str(item.relative_to(c.OUT))] = item
    for name in ('verify_builder_documentation.py', 'verify_builder_documentation_2.py',
                 'preview_builder_documentation.py', 'builder_common.py',
                 'run_guarded.py', Path(__file__).name):
        paths['drivers/' + name] = c.OUT / name
    names = c.git('diff', '--name-only', 'HEAD').splitlines()
    names += c.git('ls-files', '--others', '--exclude-standard').splitlines()
    for name in sorted(set(names)):
        path = c.ROOT / name
        if path.is_file() and not name.startswith('docs/benchmarks/evidence/'):
            assert name.startswith(('docs/', 'website-src/', 'website/')), name
            paths['source/' + name] = path

    assert sum(path.stat().st_size for path in paths.values()) < 32 * 1024 * 1024
    manifest = {name: {'bytes': path.stat().st_size, 'sha256': c.sha(path)}
                for name, path in sorted(paths.items())}
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    browser_bytes = (json.dumps(browser, indent=2, sort_keys=True) + '\n').encode()
    target = c.ROOT / 'docs/benchmarks/evidence/native-builder-documentation-2026-10-07.tar.xz'
    with tarfile.open(target, 'x:xz', preset=6) as archive:
        for name, path in sorted(paths.items()):
            info = tarfile.TarInfo(name)
            info.size = path.stat().st_size
            info.mode = 0o644
            with path.open('rb') as stream:
                archive.addfile(info, stream)
        for name, raw in (('manifest.json', manifest_bytes), ('browser.json', browser_bytes)):
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(raw))
    with tarfile.open(target, 'r:xz') as archive:
        members = archive.getmembers()
        assert len(members) == len(manifest) + 2
        assert {item.name for item in members} == set(manifest) | {'manifest.json', 'browser.json'}
        assert archive.extractfile('manifest.json').read() == manifest_bytes
        assert archive.extractfile('browser.json').read() == browser_bytes
        for name, expected in manifest.items():
            with archive.extractfile(name) as stream:
                assert hashlib.file_digest(stream, 'sha256').hexdigest() == expected['sha256']
            assert archive.getmember(name).size == expected['bytes']
    assert c.source_hashes() == source['source_hashes']

    report = {
        'schema_version': 'shardloom.native_builder_documentation_acceptance.v1',
        'status': 'passed_local_documentation_acceptance',
        'runtime_commit': RUNTIME_COMMIT,
        'source_identity_sha256': source['source_identity_sha256'],
        'runtime_source_assets_verified': len(source['source_hashes']),
        'documentation_checks': checks['checks'],
        'browser': browser,
        'examples_changed': False,
        'runtime_rerun_required': False,
        'archive': {'path': str(target.relative_to(c.ROOT)),
                    'bytes': target.stat().st_size, 'sha256': c.sha(target),
                    'file_members': len(manifest), 'total_members': len(manifest) + 2,
                    'manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
                    'all_members_reopened_and_hash_checked': True},
        'source_files': {name.removeprefix('source/'): item
                         for name, item in manifest.items()
                         if name.startswith('source/')},
        'temporary_server_drained': True,
        'hosted_integration': 'pending',
        'claim_boundary': 'Documentation acceptance for the exact recorded pages and source. No new engine, performance, RSS or package claim.',
        'driver_sha256': c.sha(__file__),
    }
    portable = json.dumps(report, indent=2, allow_nan=False)
    for path, replacement in ((c.ROOT, '<repo>'), (c.OUT, '<builder-uat>'),
                              (Path.home(), '<home>')):
        portable = portable.replace(str(path), replacement)
    result_path = target.with_name('native-builder-documentation-2026-10-07.json')
    with result_path.open('x') as stream:
        stream.write(portable + '\n')
    print(json.dumps({'status': 'passed', 'members': len(manifest) + 2,
                      'bytes': target.stat().st_size, 'sha256': c.sha(target)}), flush=True)


if __name__ == '__main__':
    main()
