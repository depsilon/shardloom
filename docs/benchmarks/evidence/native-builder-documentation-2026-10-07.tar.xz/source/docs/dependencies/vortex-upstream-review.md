# Vortex Upstream Dependency Review

## October 7, 2026 native builder review

`NATIVE-BUILDER-RESOURCES` retains Vortex 0.85.0 and extends the existing session
provider around primitive, Boolean and decimal Chunked output builders. It keeps
upstream append strategies and native buffer ownership; the allocator argument
alone is insufficient because this pinned builder factory ignores it. The
existing Apache-2.0 `vortex-zstd` patch also routes primitive append through its
already-admitted native decoder, then native primitive append. The
[provenance manifest](../../vendor/vortex-zstd/upstream-provenance.json) records
that additional method-level change. No dependency, feature, codec implementation
or unsafe code is added.

The [contract](../architecture/native-builder-resources-2026-10-07.md) and
[acceptance](../benchmarks/native-builder-resources-2026-10-07.md) record the
capacity/lifetime boundary, 13 pinned upstream source checks, 14 new ownership
tests, the complete cost screen and source/public/Full43 regression proof.
Local packet inspection passes; hosted integration is pending. Child decoder
scratch and structural metadata remain outside the new byte-buffer claim.

## October 7, 2026 pinned decoder workspace review

The merged `NATIVE-CODEC-WORKSPACES` unit retains Vortex 0.85.0 and the same
native encoding patch. It adds an exact direct `zstd-sys` 2.0.16 dependency only
inside that excluded provider crate, using its experimental static-API bindings.
The lockfile already contains `zstd-sys` 2.0.16+zstd.1.5.7 through `zstd` 0.13.3
and `zstd-safe` 7.2.4. No provider upgrade or external query engine is involved.
The binding crate declares MIT/Apache-2.0; Zstandard 1.5.7 is used under its
BSD-3-Clause license option. Existing license/provenance records remain intact.

The [workspace contract](../architecture/native-zstd-workspaces-2026-10-07.md)
records exact source surfaces, feature isolation, linked-version rejection,
private unsafe lifetime/alignment requirements and the legacy-format boundary.
RFC 0044 permits this scoped binding inside `vendor/vortex-zstd`; workspace
crates retain `unsafe_code = "forbid"`. The
[acceptance report](../benchmarks/native-codec-workspaces-2026-10-07.md) records
24 ownership tests, 17 source gates and complete public/Full43 regression proof.
PR #1528 merged after all 39 hosted checks passed with the accepted runtime
source unchanged. Package publication remains separate. Dependency
availability alone does not expand support.

## October 6, 2026 retained allocator patch

The accepted local provider resource unit retains Vortex 0.85.0 and an
Apache-2.0 patch of the published `vortex-zstd` crate. Reviewed payload, view
and nullable scatter allocations use the existing fallible session allocator;
concrete encoding, VTable and serialization identities remain unchanged.
The [resource contract](../architecture/native-provider-resources-2026-10-06.md)
defines the finite scope and remaining C decoder/dictionary scratch exclusions.
The [provenance manifest](../../vendor/vortex-zstd/upstream-provenance.json)
records the authoritative registry-archive hash, original file hashes and
license. Its dirty upstream VCS marker means a Git revision alone is not the
source archive identity. Local and combined regression acceptance passed;
hosted integration and publication remain separate. Earlier “no vendored code”
statements below describe their historical intake scope.

## October 3, 2026 release review

Released, non-yanked Vortex 0.87.0 is the latest provider inspected. The workspace
retains 0.85.0 because exact published source still sends buffer allocation
refusal to the allocation-error handler instead of the typed, recoverable error
required by ShardLoom's memory budget. The
[Rust/Vortex review](rust-vortex-refresh-2026-10-03.md) records live release
metadata, source hashes, the global Rust 1.99.0 update, retained-provider tests
and the feature adoption map. No 0.87 build or speedup is claimed.

## September 27, 2026 provider admission

Vortex 0.86.0/0.86.1 are released and have been reviewed under C1. The workspace
retains 0.85.0: the new buffer allocator no longer returns typed recoverable
budget denial through the current provider boundary. See the
[exact API/resource admission decision](../architecture/vortex-086-upgrade-admission-2026-09-27.md).
No upgraded build or performance result is claimed. Earlier references to
0.86.0 as a draft describe the historical intake, not current release status.

## Purpose

This document is a historical dependency-review ledger for ShardLoom's upstream
Vortex dependency. It does not define the current executable Vortex surface.

Current runtime support is summarized in
`docs/architecture/phased-execution-plan.md` and
`docs/architecture/vortex-public-api-inventory.md`. Do not infer current
executable support from older PR-specific sections that say "this PR" or
"actual IO implemented."

## Current support snapshot

- Upstream Vortex remains optional and isolated in `shardloom-vortex`.
- The tracked workspace dependency is `vortex = 0.85`; `shardloom-vortex` inherits it while keeping
  the dependency optional and feature-gated.
- Vortex `0.85.0` is the current optional dependency family after the provider-capability
  update recorded in `docs/architecture/vortex-public-api-inventory.md` and
  `docs/dependencies/vortex-dependency-footprint.md`.
- Vortex `0.75.0` remains historical intake material in this review and
  `docs/architecture/vortex-public-api-inventory.md`.
- Vortex `0.74.0` remains historical intake material in this review and
  `docs/architecture/vortex-public-api-inventory.md`.
- Vortex `0.73.0` remains historical intake material in this review and
  `docs/architecture/vortex-public-api-inventory.md`.
- Vortex `0.72.0` remains historical intake material in this review and
  `docs/architecture/vortex-public-api-inventory.md`.
- Vortex `0.71.0` remains historical intake material in
  `docs/dependencies/vortex-0.71-upstream-intake.md`.
- Approved historical metadata/footer fixture IO and approved local primitive
  scan paths are recorded in `docs/architecture/phased-execution-plan.md`.
- Vortex-native array, compute, scan, source, and sink APIs may be future native
  providers only when feature-gated, version-recorded, policy-admitted, and
  certificate-backed.
- Future upstream release intake is governed by
  `docs/dependencies/vortex-upstream-release-intake-runbook.md`.
- Vortex DataFusion, DuckDB, Spark, Trino, and similar integrations remain
  baseline/reference/oracle surfaces only; they must not execute unsupported
  ShardLoom residual work.
- Fallback execution remains disabled.

## Vortex 0.76 Dependabot Closeout And 0.85 Intake Direction

- Dependabot PR <https://github.com/depsilon/shardloom/pull/1379> was closed without merging.
- Crates.io reports `vortex 0.76.0` and `vortex-zstd 0.76.0` as yanked. They must not be used as
  ShardLoom's next pinned provider line.
- Crates.io reports current released upstream `vortex 0.85.0` and `vortex-zstd 0.85.0` with
  license `Apache-2.0`, Rust version `1.95`, documentation at
  <https://docs.rs/vortex/0.85.0>, and repository <https://github.com/spiraldb/vortex>.
- Upstream Vortex changelog docs on 2026-08-29 also list `0.86.0` as draft. Treat draft changes as
  migration surveillance only; do not pin or publish against an unreleased Vortex crate line.
- The retained Vortex update is a provider/capability intake, not a blind lockfile bump. It records
  `0.76.0` as a yanked hazard, reviews each intervening non-yanked release from 0.77 through the
  current released latest 0.85, migrates only the ShardLoom-native provider APIs needed for current
  feature-gated builds, and rejects Vortex query-engine integrations as runtime helpers.
- The direct Arrow/Parquet bridge stays on Arrow/Parquet `58.3.0` in this dependency hygiene pass
  because current Vortex `0.85.0` still declares `arrow-array ^58.3` and `parquet ^58.3`; upgrading
  only ShardLoom's direct Arrow bridge to `59.x` would create duplicate Arrow provider types.
- Vortex query-engine integrations remain prohibited as ShardLoom runtime helpers.

## Vortex 0.85 provider-capability update

- Dependabot PR <https://github.com/depsilon/shardloom/pull/1379> and the follow-on Vortex bump
  signal were reviewed as one upstream provider intake instead of merged directly.
- `cargo info vortex@0.85.0` reports license `Apache-2.0`, Rust version `1.95`, documentation
  at <https://docs.rs/vortex/0.85.0>, repository <https://github.com/spiraldb/vortex>, and crates.io
  version <https://crates.io/crates/vortex/0.85.0>.
- `cargo info vortex-zstd@0.85.0` reports license `Apache-2.0`, Rust version `1.95`,
  documentation at <https://docs.rs/vortex-zstd/0.85.0>, repository
  <https://github.com/spiraldb/vortex>, and crates.io version
  <https://crates.io/crates/vortex-zstd/0.85.0>.
- Root `Cargo.toml` now records workspace dependencies `vortex = 0.85` and
  `vortex-zstd = 0.85`; `shardloom-vortex` inherits both as optional feature-gated dependencies.
- `Cargo.lock` records the upstream Vortex crate family at `0.85.0`.
- Active provider-version evidence remains centralized through
  `shardloom_vortex::UPSTREAM_VORTEX_PROVIDER_VERSION`.
- Active provider-disposition reports now use `vortex_upstream_*` field/schema labels, so future
  provider-line updates do not leave current report keys hard-coded to an older release number.

Release-family review retained:

- `0.76.0` / `vortex-zstd 0.76.0`: yanked; recorded as a dependency hazard and skipped as a pinned
  provider line.
- `0.77.0`-`0.79.0`: reviewed as intermediate scan/expression/encoding compatibility releases; no
  separate ShardLoom runtime provider adoption was retained beyond the current 0.85 compile
  migration.
- `0.80.0`: `VortexSource` improvements, layout adapter error posture, piecewise sequence/index
  work, struct-layout reader allocation improvements, footer parse validation, and Vortex edition
  docs were mapped as provider-alignment pressure.
- `0.81.0`: file-level user metadata, serialization-context registry filtering, partition-expression
  locking, and `UnionArray` were mapped; ShardLoom now treats new union scalar/dtype shapes as
  explicit unsupported metadata/encoded-stat boundaries unless a later runtime item admits them.
- `0.82.0`-`0.84.0`: grouped aggregate kernels, scan statistics, layout-reader/file-cache work,
  JSON/Arrow import/export changes, interleave encoding, row encoder, byte-length/string
  transforms, zstd/binary scheme changes, mask/zip/layout performance, and dictionary/FSST LIKE
  behavior were mapped into the current upstream-provider disposition reports.
- `0.85.0`: retained code migrations cover `BoundExpression` scan pushdown, ArrowSession-only
  RecordBatch import/export, Vortex session/edition encoding selection, `DynLayout`, strict sorted
  row-index selection, run-end slot access, `Map`/`Union` unsupported-boundary handling, updated
  VarBin/FSST helper APIs, and writer strategy API changes.
- `0.86.0` draft: surveyed only as future pressure around `VortexWrite`/`OutputSink`, `RowFn`,
  fixed-width filtering, grouped-state behavior, sequence casts, and DataFusion/DuckDB integration
  changes. It is not a retained dependency line.

Claim boundary:

- The update proves feature-gated Vortex 0.85 build compatibility, provider-version freshness, and
  refreshed source-linked provider-disposition evidence.
- It does not admit Vortex query-engine integrations, hidden fallback execution, object-store/table
  runtime, GPU/device support, broad JSON/geospatial runtime support, package publication,
  performance superiority, or broad SQL/DataFrame support by dependency availability alone.

## Vortex 0.75 compatibility update

Historical note; superseded by the Vortex 0.85 provider-capability update above for current
dependency status.

- Dependabot PR: <https://github.com/depsilon/shardloom/pull/1223>.
- `cargo info vortex@0.75.0` reports license `Apache-2.0`, Rust version `1.91.0`, documentation
  at <https://docs.rs/vortex/0.75.0>, repository <https://github.com/spiraldb/vortex>, and crates.io
  version <https://crates.io/crates/vortex/0.75.0>.
- Root `Cargo.toml` now records workspace dependency `vortex = 0.75`; `shardloom-vortex` inherits
  it as optional through the `upstream-vortex` feature.
- `Cargo.lock` records the upstream Vortex crate family at `0.75.0`.
- ShardLoom provider-version evidence is centralized through
  `shardloom_vortex::UPSTREAM_VORTEX_PROVIDER_VERSION` so certificates, capability rows,
  scan/source admission rows, capillary/preparation spine evidence, benchmark route evidence, and
  compatibility reports do not claim a stale provider line.
- Upstream runtime-relevant release-note items mapped for later ShardLoom provider-gated work:
  grouped `sum`/`count` aggregate kernels, explicit validity/mask execution-context APIs, layout
  reader context/caching, JSON and WKB/geospatial extension import/export, Interleave array
  encoding, `byte_length()`, binary zstd schemes, row-oriented byte encoding, branchless zip
  kernels, mask `AllTrue`/`AllFalse` fast paths, dictionary validation/slice optimization, FSST
  state sharing, and layout child caches.
- GPU/device, JNI, cuDF, and DataFusion 54 items remain blocked or baseline/oracle-only until a
  separate ShardLoom provider gate adds device residency, external-boundary, certificate, and
  no-fallback evidence.
- The update is a dependency/build compatibility admission only. It does not by itself admit new
  Vortex runtime behavior, object-store/table support, SQL/DataFrame production support,
  performance claims, package publication, or fallback execution.
- Vortex query-engine integrations remain prohibited as ShardLoom runtime helpers.

## Vortex 0.74 compatibility update

Historical note; superseded by the Vortex 0.85 provider-capability update above for current
dependency status.

- Dependabot PR: <https://github.com/depsilon/shardloom/pull/1150>.
- `cargo info vortex@0.74.0` reports license `Apache-2.0`, Rust version `1.91.0`, documentation
  at <https://docs.rs/vortex/0.74.0>, repository <https://github.com/spiraldb/vortex>, and crates.io
  version <https://crates.io/crates/vortex/0.74.0>.
- `shardloom-vortex` now requests optional `vortex = 0.74`.
- `Cargo.lock` records the upstream Vortex crate family at `0.74.0`.
- Existing ShardLoom provider-version evidence was refreshed to `0.74` so certificates, capability
  rows, scan/source admission rows, capillary/preparation spine evidence, and compatibility reports
  do not claim the stale `0.73` provider line.
- The upstream release note calls out removal of an FFI `vx_file` scan surface; ShardLoom does not
  use that FFI surface in its approved runtime boundary.
- The update is a dependency/build compatibility admission only. It does not by itself admit new
  Vortex runtime behavior, object-store/table support, SQL/DataFrame production support,
  performance claims, package publication, or fallback execution.
- Vortex query-engine integrations remain prohibited as ShardLoom runtime helpers.

## Vortex 0.73 compatibility update

Historical note; superseded by the Vortex 0.85 provider-capability update above for current
dependency status.

- Dependabot PR: <https://github.com/depsilon/shardloom/pull/979>.
- `cargo info vortex@0.73.0` reports license `Apache-2.0`, Rust version `1.91.0`, documentation
  at <https://docs.rs/vortex/0.73.0>, repository <https://github.com/spiraldb/vortex>, and crates.io
  version <https://crates.io/crates/vortex/0.73.0>.
- `shardloom-vortex` now requests optional `vortex = 0.73`.
- `Cargo.lock` records the upstream Vortex crate family at `0.73.0`.
- Existing ShardLoom provider-version evidence was refreshed to `0.73` so certificates, capability
  rows, scan/source admission rows, capillary/preparation spine evidence, and compatibility reports
  do not claim the stale `0.72` provider line.
- The update is a dependency/build compatibility admission only. It does not by itself admit new
  Vortex runtime behavior, object-store/table support, SQL/DataFrame production support,
  performance claims, package publication, or fallback execution.
- Vortex query-engine integrations remain prohibited as ShardLoom runtime helpers.

## Vortex 0.72 compatibility update

Historical note; superseded by the Vortex 0.85 provider-capability update above for current
dependency status.

- `shardloom-vortex` now requests optional `vortex = 0.72`.
- `Cargo.lock` records Vortex `0.72.0` crate family versions.
- The update is a dependency/build compatibility admission only. It does not by itself admit new
  Vortex runtime behavior, object-store/table support, SQL/DataFrame production support,
  performance claims, package publication, or fallback execution.
- TurboQuant remains blocked capability metadata only (`vortex_turboquant_vector_encoding`) until
  ShardLoom has an admitted vector dtype contract, feature-gated compile/runtime proof, correctness
  tests, no-fallback policy evidence, and workload-scoped benchmark evidence.

## Vortex 0.71 bump update

Historical note; superseded by the Vortex 0.85 provider-capability update above for current
dependency status.

- `shardloom-vortex` now requests optional `vortex = 0.71`.
- `Cargo.lock` records Vortex `0.71.0` crate family versions.
- The bump required one ShardLoom source compatibility update: local primitive dtype mapping now
  rejects upstream `DType::Union` deterministically instead of relying on a non-exhaustive match.
- Feature-gated compile proof covered `upstream-vortex`, `vortex-file-io`, `vortex-write`,
  `vortex-local-primitives`, and `vortex-traditional-analytics-benchmark`.
- No new Vortex runtime support claim, fallback engine, object-store/table claim, SQL/DataFrame
  claim, performance claim, or package publication claim is introduced by the bump.

## Current status

- Upstream Vortex dependency has been added to `shardloom-vortex`.
- Historical scope in the original dependency PR was compile/readiness only.
- Current executable Vortex support is tracked in the phase plan rather than in
  this historical review section.
- Fallback execution remains disabled.

## Historical dependency review

- Crate name: `vortex`
- Version requested: `0.70`
- Repository: upstream Vortex repository
- License: Apache-2.0
- Purpose: native Vortex format/toolkit integration inside `shardloom-vortex`
- Original PR scope: dependency compile/readiness only
- Public APIs used in the original PR: none (compile marker only)
- Internal APIs used: none
- Actual IO implemented by the original PR: no
- Fallback engines introduced: no
- Copied upstream code: no
- Vendored upstream code: no

## License/provenance checklist

- Upstream license identified as Apache-2.0.
- License is compatible with Apache-2.0 project policy.
- No GPL/AGPL/SSPL/BUSL/proprietary code introduced.
- No copied upstream implementation code.
- No vendored upstream code.
- Dependency usage is isolated to `shardloom-vortex`.
- No fallback execution dependency was directly added.

## Historical dependency addition status

- Upstream Vortex dependency has been added to `shardloom-vortex`.
- The original dependency PR did not implement actual Vortex IO.
- The original dependency PR did not add fallback execution.
- The original dependency PR did not add DataFusion/Spark/DuckDB/Polars/Velox.

## Follow-up required

- Identify minimal metadata inspection API.
- Identify DType mapping API.
- Identify encoding/layout mapping API.
- Add adapter tests.
- Add unsupported diagnostics.
- Avoid decode-to-Arrow default path.


## API discovery update

- Added `docs/architecture/vortex-public-api-inventory.md` to track inspected upstream public API
  areas and adapter boundaries.
- Current adapter work remains mapping/readiness only.
- No actual Vortex IO is implemented in this phase.
- No fallback execution was introduced.


## Typed DType mapping update

- Typed DType mapping is deferred in this PR because a compile-safe public typed API could not be
  confirmed in this environment.
- Public upstream typed API used: none.
- Name-based DType mapping remains available as a temporary adapter utility.
- No actual Vortex IO was implemented.
- No fallback execution was introduced.

## Typed encoding/layout mapping update

- Typed encoding mapping: deferred pending confirmed stable public upstream non-IO API surface.
- Typed layout mapping: deferred pending confirmed stable public upstream non-IO API surface.
- Public upstream API used for typed mapping: none in this PR (deferred).
- Name-based mapping remains available for planning/reporting utility.
- No actual Vortex IO implemented.
- No fallback execution introduced.

## Typed statistics mapping update

- Typed statistics mapping: deferred in this PR (`deferred_api_unclear`) because a compile-safe,
  unambiguous public upstream API surface for typed statistics mapping was not confirmed in this
  environment.
- Public upstream statistics API used: none.
- `ShardLoom` `SegmentStats` placeholder mapping remains available for planning/reporting utility.
- No actual Vortex IO implemented.
- No fallback execution introduced.

## Metadata-only IO update

- Metadata-only local `Vortex` inspection: deferred to report-only mode in this PR.
- Public upstream API used for implemented runtime metadata inspection: none (deferred).
- Scan execution implemented: no.
- Data materialization implemented: no.
- Write implemented: no.
- Object-store IO implemented: no.
- Fallback execution introduced: no.

## Dependency footprint gating update

- Upstream `vortex` dependency is now feature-gated in `shardloom-vortex` (`upstream-vortex`).
- Default workspace builds do not enable the broad upstream Vortex graph by default.
- `vortex-file-io`, `vortex-object-store`, and `vortex-write` are declared as staged feature gates
  only.
- File IO and object-store IO remain disabled by default and unimplemented.
- No DataFusion/Spark/DuckDB/Polars/Velox/vortex-datafusion direct dependencies were introduced.
- No fallback execution behavior was introduced.

## Universal-format local benchmark bridge dependencies

- `shardloom-vortex` gates local structured-file bridge support behind
  `universal-format-io`, which is pulled by the existing
  `vortex-traditional-analytics-benchmark` feature and by the scoped
  `shardloom-cli --features universal-format-io` local Parquet source/output smoke.
- Rust crates added under that gate:
  - `parquet 58.3.0` for local Parquet record-batch reads/writes.
  - `arrow-ipc 58.3.0` for Arrow IPC reads/writes.
  - `arrow-avro 58.3.0` for Avro reads/writes.
  - `orc-rust 0.8.0` for ORC reads/writes.
  - `arrow-array 58.3.0` and `arrow-schema 58.3.0` for Arrow boundary arrays and schemas.
  - `arrow-json 58.2.0` is reserved under the same gate for JSON/NDJSON boundary work; the current
    deterministic JSONL fixture parser remains local and narrow.
- Dependabot Arrow/Parquet 59 PRs #1224, #1225, #1227, #1228, and #1229 were reviewed and
  deferred because Vortex 0.85 and `orc-rust 0.8.0` still expose Arrow 58-compatible provider
  boundaries in the feature-complete structured-format lane.
- License/provenance:
  - Apache Arrow Rust crates are Apache-2.0.
  - `orc-rust` is Apache-2.0.
  - Benchmark fixture generation uses Python `fastavro 1.12.2` in
    `benchmarks/traditional_analytics/requirements.txt`; `pip show fastavro` reports MIT license.
- Scope:
  - Default workspace builds remain lightweight and do not enable these dependencies.
  - These dependencies do not introduce Spark, DataFusion, DuckDB, Polars, Velox, Trino, Dask, Ray,
    Calcite, or `vortex-datafusion`.
  - They are file-format boundary readers/writers for local benchmark smoke, troubleshooting, and
    the feature-gated flat scalar local Parquet SQL source/output smoke, not execution engines or
    fallback paths.
  - Compatibility-format input is imported into native local Vortex output before the temporary
    benchmark operator runs.
  - Production adapter certification, object-store IO, catalog/table metadata IO, distributed
    execution, SQL/DataFrame/UDF runtime, and performance/superiority claims remain separate future
    work.
