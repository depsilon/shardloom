"""Validate the count-evidence and constant-group correction before its comparison."""
import os
from pathlib import Path
import subprocess
import sys

N = Path(__file__).resolve().parent
W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
commands = [
    ('parity-r4-workspace-native-lint-reviewed', ['cargo', 'clippy', '--workspace', '--all-targets', '--features', 'release-user-surfaces', '--', '-D', 'warnings']),
    ('parity-r4-workspace-native-tests', ['cargo', 'test', '--workspace', '--all-targets', '--features', 'release-user-surfaces']),
    ('parity-r4-format', ['cargo', 'fmt', '--all', '--', '--check']),
    ('parity-r4-default-lint', ['cargo', 'clippy', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('parity-r4-default-tests', ['cargo', 'test', '--workspace', '--all-targets']),
    ('parity-r4-matched-release-build', ['cargo', 'build', '--release', '-p', 'shardloom-cli', '-p', 'shardloom-python', '--features', 'release-user-surfaces']),
]

for label, command in commands:
    print(label, flush=True)
    environment = dict(os.environ)
    if command[1] == 'build':
        environment.update(PYO3_BUILD_EXTENSION_MODULE='1', PYO3_PYTHON='/opt/homebrew/bin/python3.13')
    result = subprocess.run([sys.executable, '-B', str(N / 'run_validation.py'), label, *command], cwd=W, env=environment)
    if result.returncode:
        raise SystemExit(result.returncode)
subprocess.run(['/opt/homebrew/bin/python3.13', '-B', str(N / 'surfaces-r4/freeze_build.py'), 'parity-r4-matched-release-build', 'release', 'artifacts'], cwd=W, check=True)
