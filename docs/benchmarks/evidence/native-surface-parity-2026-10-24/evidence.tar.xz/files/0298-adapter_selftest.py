"""Small independent fixture checks for comparison delivery and query clocks."""
import json
import os
import subprocess
import sys
import time

import query_paths
from query_paths import ROOT, N, load_native
from native_workflow_protocol import extract_result, public_workflow_command, report_fields
from query_timing_report import query_phase_timings

query_paths.LIBRARY = ROOT / 'artifacts/_native.abi3.so'


def run():
    native = load_native()
    fixture = ROOT / 'adapter-count-fixture.vortex'
    session = native.Session(native.ExecutionResources(64 << 20, 1))
    try:
        source = session.from_range('WatchID', 0, 1, 3)
        plan = session.plan(native.Relation.scan('memory://adapter'), sources=[('memory://adapter', source)])
        if not fixture.exists():
            plan.write(fixture, 'write_vortex')
    finally:
        session.close()
    observations = []
    for role in ('cli_sql', 'embedded_workflow', 'python_sql', 'dataframe', 'native_expression'):
        executable = ROOT / 'artifacts/shardloom' if role == 'cli_sql' else ROOT / role
        if role != 'cli_sql':
            executable.chmod(0o755)
        command = public_workflow_command(executable, 'SELECT COUNT(*) FROM hits', input_path=fixture,
                                         input_format='vortex', memory_gb=1, max_parallelism=1)
        started = time.perf_counter()
        process = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                 env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), timeout=20)
        elapsed = time.perf_counter() - started
        (ROOT / f'adapter2-{role}.stdout.json').write_bytes(process.stdout)
        (ROOT / f'adapter2-{role}.stderr.txt').write_bytes(process.stderr)
        if process.returncode:
            raise RuntimeError(f'{role}: {process.stderr.decode()}')
        envelope = json.loads(process.stdout)
        fields = report_fields(envelope)
        assert extract_result(envelope) == [{'count_all': 3}]
        timing = query_phase_timings(fields, elapsed)
        assert timing['engine_timing_reported']
        if role != 'cli_sql':
            assert fields['comparison_role'] == role
            assert fields['comparison_query_id'] == '1'
        observations.append(dict(role=role, passed=True, complete_values=True, engine_clock_present=True))
    # The standard extractor must still reject incomplete and unsafe delivery.
    original = json.loads((ROOT / 'adapter2-native_expression.stdout.json').read_text())
    rejected = []
    for key, replacement in [('result_payload_complete', 'false'),
                              ('public_workflow_external_engine_invoked', 'true'),
                              ('output_row_count', '2')]:
        envelope = json.loads(json.dumps(original))
        next(field for field in envelope['fields'] if field['key'] == key)['value'] = replacement
        try:
            extract_result(envelope)
        except ValueError:
            rejected.append(key)
        else:
            raise AssertionError(f'unsafe delivery accepted: {key}')
    result = dict(status='passed', fixture_rows=3, real_dataset_queries_executed=0,
                  observations=observations, rejected_corruptions=rejected)
    (ROOT / 'adapter-selftest.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    run()

