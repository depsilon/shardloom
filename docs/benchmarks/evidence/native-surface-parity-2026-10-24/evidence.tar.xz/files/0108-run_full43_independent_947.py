"""One isolated standard Full43 pass against the frozen independent reference."""
import gzip
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
N = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022')
sys.path.insert(0, str(W / 'scripts'))
from clickbench_reference_packet import load_reference_packet
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
from native_workflow_protocol import extract_result, strict_json
from run_clickbench_query_uat import equivalent

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

SUPERVISOR = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
GUARD = Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/native_workload_guard_816.py')
bounded = load('bounded', SUPERVISOR)
guards = load('guards', GUARD)

def identity(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())

def read(path):
    return strict_json(Path(path).read_text())

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

def generation(path):
    stat = Path(path).stat()
    return dict(device=stat.st_dev, inode=stat.st_ino, size_bytes=stat.st_size,
                mtime_ns=stat.st_mtime_ns, ctime_ns=stat.st_ctime_ns)

def storage_snapshot():
    values = {}
    for label, path in [('task', N), ('cargo', Path('/Users/dylan/.cache/shardloom/cargo-target'))]:
        require_local_path(path, Path.home(), sys.platform)
        values[label] = check_budgets(path, path / 'reserved-artifact', path / 'logs',
            min_free_bytes=12 * GIB, reserve_bytes=128 * MIB,
            max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    return values

run_root = N / 'full43-native-947'
plan_path = N / 'full43-plan-947.json'
receipt = N / 'full43-run-947.json'
log = N / 'full43-run-947.log'
assert not any(path.exists() for path in (run_root, plan_path, receipt, log))
runtime_path = N / 'native-runtime-947.json'
runtime = read(runtime_path)
assert runtime['status'] == 'passed' and len(runtime['cases']) == 3
assert all(case['passed'] and case['process_group_drained'] for case in runtime['cases'])
build = read(runtime['build']['path'])
assert identity(runtime['build']['path']) == runtime['build']
assert build['status'] == 'passed' and build['process_group_drained']
assert build['source_before'] == build['source_after']
binary = runtime['executable']
assert identity(binary['path']) == binary

def verify_runtime_sources():
    for relative, expected in build['source_after'].items():
        assert identity(W / relative)['sha256'] == expected, relative
    assert identity(binary['path']) == binary

verify_runtime_sources()
reference_path = N / 'independent-full43-945/reference.json'
reference = identity(reference_path)
assert reference['sha256'] == '7fc4541e739925ac10bcb5360a1caf2ac93cdf0dd2cdb64d9ff406faf620fc1a'
oracle_acceptance_path = N / 'independent-full43-945/acceptance.json'
oracle_acceptance = read(oracle_acceptance_path)
assert oracle_acceptance['status'] == 'passed' and oracle_acceptance['calls'] == 43
assert oracle_acceptance['independent_correctness_oracle'] is True
assert oracle_acceptance['native_runtime_invoked'] is False
assert oracle_acceptance['reference'] == reference
queries = W / 'benchmarks/clickbench/queries.sql'
expected = load_reference_packet(reference_path, queries)
input_path = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat/vortex/fresh-roadmap-663-a1.vortex')
input_generation = generation(input_path)
input_identity = identity(input_path)
assert input_identity['sha256'] == '06f70eb6f118d11e4a5226eb641225d708fdb4ac1b3f45942872d5ef5df4fc22'
assert generation(input_path) == input_generation
assert identity(SUPERVISOR)['sha256'] == '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97'
assert identity(GUARD)['sha256'] == 'ce56dd25bd4e55c8c7b8929140c2f2228f27f42d79ceea5645d50db320407b76'
command = ['/opt/homebrew/opt/python@3.13/bin/python3.13', '-B', 'scripts/run_clickbench_query_uat.py',
    '--binary', binary['path'], '--input', str(input_path), '--uat-root', str(run_root),
    '--reference-packet', str(reference_path), '--build-commit', runtime['source_commit'],
    '--memory-gb', '24', '--max-parallelism', '12', '--repeats', '1', '--compress-logs',
    '--max-log-mib', '1024', '--max-run-log-mib', '256']
workload = guards.WorkloadGuard()
workload.check()
record = dict(status='preparing', command=command, cwd=str(W), runtime=identity(runtime_path),
    binary=binary, input=input_identity, input_generation=input_generation, reference=reference,
    pre_input_hash_verified=True, source_commit=runtime['source_commit'],
    host=dict(platform=platform.platform(), logical_cpus=os.cpu_count(),
              physical_ram_bytes=int(subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.memsize'], text=True))),
    host_samples=[], storage_before=storage_snapshot())
save(plan_path, dict(schema='shardloom.single_full43_plan.v1', status='predeclared',
    helper=identity(__file__), supervisor=identity(SUPERVISOR), workload_guard=identity(GUARD),
    runtime=identity(runtime_path), source_commit=runtime['source_commit'], source_tree=runtime['source_tree'],
    build=runtime['build'], input=input_identity, input_generation=input_generation,
    reference=reference, oracle_acceptance=identity(oracle_acceptance_path), queries=identity(queries),
    query_ids=list(range(1, 44)), repeats=1, expected_calls=43, command=command,
    parallel_work=False, extra_profiling=False, artificial_pacing=False,
    request='One isolated Full43 acceptance after the independent-reference correctness correction.',
    input_hashing='Full Vortex input hash before and after queries; cache state uncontrolled.',
    methodology='Unchanged standard runner, storage limits, deadlines, complete values, process cleanup and lightweight workload guard. No builds, tests, agents, packaging, recursive inventories or input hashes during queries.',
    interpretation='One observation against independent expected values; no repeated comparison or speedup claim. Earlier failed and successful observations remain unchanged.'))
last_sample = 0.0

def guard():
    global last_sample
    workload.check(record.get('pid'))
    if time.monotonic() - last_sample < 2:
        return
    rows = subprocess.check_output(['ps', '-axo', 'pid=,ppid=,pgid=,pcpu=,rss=,comm='], text=True, timeout=10)
    samples = []
    for line in rows.splitlines():
        fields = line.strip().split(None, 5)
        if len(fields) == 6 and (int(fields[0]) in workload.owned or float(fields[3]) >= 1):
            samples.append(dict(pid=int(fields[0]), parent=int(fields[1]), group=int(fields[2]),
                cpu_percent=float(fields[3]), rss_bytes=int(fields[4]) * 1024,
                executable=Path(fields[5]).name))
    record['host_samples'].append(dict(load_average=list(os.getloadavg()), processes=samples))
    last_sample = time.monotonic()

try:
    print('Preparation complete; starting one isolated standard Full43 pass.', flush=True)
    record['status'] = 'running'
    with log.open('xb') as output:
        status = bounded.run(command, cwd=W,
            env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONPATH='python/src:scripts'),
            output=output, timeout=900, evidence=record, guard=guard, max_output_bytes=8 << 20)
    assert status == 0
    print('Query execution finished; verifying complete results and frozen identities.', flush=True)
    summaries = list(run_root.glob('logs/*/summary.json'))
    assert len(summaries) == 1
    summary = read(summaries[0])
    assert summary['complete'] and summary['full_result_validation']
    assert summary['completed_identity_check'] and summary['reference_packet_identity_verified'] and summary['harness_identity_verified']
    assert summary['reference_kind'] == 'independent_reference'
    assert summary['reference_packet']['sha256'] == reference['sha256']
    assert summary['repeats'] == 1 and summary['score_scope'] == 'full_43'
    assert summary['selected_query_ids'] == list(range(1, 44))
    assert [(row['query'], row['run']) for row in summary['records']] == [(q, 1) for q in range(1, 44)]
    total_rows = 0
    for row in summary['records']:
        assert row['passed'] and row['returncode'] == 0 and row['validation'] == 'complete_values'
        assert row['engine_timing_reported'] and math.isfinite(row['engine_execution_seconds']) and row['engine_execution_seconds'] >= 0
        output = summaries[0].parent / f"q{row['query']:02d}_run1.stdout.json.gz"
        values = extract_result(strict_json(gzip.decompress(output.read_bytes()).decode()))
        assert equivalent(values, expected['values'][row['query']])
        total_rows += len(values)
    engine_seconds = sum(row['engine_execution_seconds'] for row in summary['records'])
    assert engine_seconds == summary['timing_totals']['totals']['engine_execution_seconds']
    assert total_rows == oracle_acceptance['rows'] == 381
    record['summary'] = identity(summaries[0])
    record['result_rows'] = total_rows
    record['engine_execution_seconds'] = engine_seconds
    record['storage_after'] = storage_snapshot()
    assert generation(input_path) == input_generation and identity(input_path) == input_identity
    assert generation(input_path) == input_generation
    record['post_input_hash_verified'] = True
    assert identity(reference_path) == reference
    verify_runtime_sources()
    record['source_unchanged'] = True
    workload.check()
    assert not (run_root / '.ingest-uat.lock').exists()
    record.update(status='passed', uat_lock_released=True)
except BaseException as error:
    record.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    if log.exists():
        record['log'] = identity(log)
    record['plan'] = identity(plan_path)
    save(receipt, record)
print(json.dumps(dict(status='passed', queries=43, executions_per_query=1,
                      result_rows=381, engine_execution_seconds=engine_seconds)), flush=True)
