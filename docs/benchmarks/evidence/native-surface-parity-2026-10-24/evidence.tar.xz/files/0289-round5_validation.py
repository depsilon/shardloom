"""Validate shared SQL aggregate reuse, then freeze matched public artifacts."""
import os
from pathlib import Path
import subprocess
import sys

N = Path(__file__).resolve().parent
W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
commands = [
    ('parity-r5-format-corrected', ['cargo', 'fmt', '--all', '--', '--check']),
    ('parity-r5-native-cli-lint-corrected', ['cargo', 'clippy', '-p', 'shardloom-cli', '--all-targets', '--features', 'release-user-surfaces', '--', '-D', 'warnings']),
    ('parity-r5-native-cli-tests', ['cargo', 'test', '-p', 'shardloom-cli', '--all-targets', '--features', 'release-user-surfaces']),
    ('parity-r5-default-lint', ['cargo', 'clippy', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('parity-r5-default-tests', ['cargo', 'test', '--workspace', '--all-targets']),
    ('parity-r5-matched-release-build', ['cargo', 'build', '--release', '-p', 'shardloom-cli', '-p', 'shardloom-python', '--features', 'release-user-surfaces']),
]

for label, command in commands:
    print(label, flush=True)
    environment = dict(os.environ)
    if command[1] == 'build':
        environment.update(PYO3_BUILD_EXTENSION_MODULE='1', PYO3_PYTHON='/opt/homebrew/bin/python3.13')
    result = subprocess.run([sys.executable, '-B', str(N / 'run_validation.py'), label, *command], cwd=W, env=environment)
    if result.returncode:
        raise SystemExit(result.returncode)
subprocess.run(['/opt/homebrew/bin/python3.13', '-B', str(N / 'surfaces-r5/freeze_build.py'), 'parity-r5-matched-release-build', 'release', 'artifacts'], cwd=W, check=True)
