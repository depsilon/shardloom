"""Freeze matched CLI/binding outputs immediately after a supervised build."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

N = Path('/Users/dylan/LocalData/shardloom/native-surface-parity-20261024')
W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
ROOT = Path(__file__).parent


def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def main(label, profile, destination):
    assert profile in ('debug', 'release')
    receipt = N / (label + '.json')
    build = json.loads(receipt.read_text())
    assert build['status'] == 'passed' and build['process_group_drained']
    assert build['source_before'] == build['source_after']
    command = build['command']
    assert command[:2] == ['cargo', 'build']
    assert all(package in command for package in ('shardloom-cli', 'shardloom-python'))
    assert command[command.index('--features') + 1] == 'release-user-surfaces'
    assert ('--release' in command) == (profile == 'release')
    for relative, digest in build['source_after'].items():
        assert identity(W / relative)['sha256'] == digest, relative
    target = ROOT / destination
    assert target.parent == ROOT and not target.exists()
    target.mkdir()
    artifacts = {}
    for role, original, output in [('cli', 'shardloom', 'shardloom'),
                                   ('library', 'lib_native.dylib', '_native.abi3.so')]:
        source = Path(build['target']) / profile / original
        path = target / output
        shutil.copy2(source, path)
        assert identity(path)['sha256'] == identity(source)['sha256']
        artifacts[role] = identity(path)
    links = subprocess.check_output(['otool', '-L', artifacts['library']['path']], text=True)
    assert 'Python.framework' not in links and 'libpython' not in links
    python = {str(path.relative_to(W)): identity(path)['sha256']
              for path in sorted((W / 'python/src').rglob('*.py'))}
    summary = dict(status='passed', build=identity(receipt), profile=profile,
                   package_feature_union='release-user-surfaces', artifacts=artifacts,
                   source_before=build['source_before'], source_after=build['source_after'],
                   runtime_python_sources=python, library_links=links,
                   freezer=identity(Path(__file__)))
    (target / 'build-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(artifacts, indent=2))


if __name__ == '__main__':
    main(*sys.argv[1:])

