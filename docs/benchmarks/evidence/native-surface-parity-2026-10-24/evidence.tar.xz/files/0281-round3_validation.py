"""Verify count routing and its exact affected consumers before comparison."""
import os
from pathlib import Path
import subprocess
import sys

N = Path(__file__).resolve().parent
W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
commands = [
    ('parity-r3-format', ['cargo', 'fmt', '--all', '--', '--check']),
    ('parity-r3-workspace-native-lint', ['cargo', 'clippy', '--workspace', '--all-targets', '--features', 'release-user-surfaces', '--', '-D', 'warnings']),
    ('parity-r3-native-cli-tests', ['cargo', 'test', '-p', 'shardloom-cli', '--all-targets', '--features', 'release-user-surfaces']),
    ('parity-r3-triple-worker-tests', ['cargo', 'test', '-p', 'shardloom-vortex', '--lib', '--features', 'release-user-surfaces', 'triple_count_tests']),
    ('parity-r3-default-lint', ['cargo', 'clippy', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('parity-r3-default-tests', ['cargo', 'test', '--workspace', '--all-targets']),
    ('parity-r3-matched-release-build', ['cargo', 'build', '--release', '-p', 'shardloom-cli', '-p', 'shardloom-python', '--features', 'release-user-surfaces']),
]
for label, command in commands:
    print(label, flush=True)
    environment = dict(os.environ)
    if command[1] == 'build':
        environment.update(PYO3_BUILD_EXTENSION_MODULE='1', PYO3_PYTHON='/opt/homebrew/bin/python3.13')
    result = subprocess.run([sys.executable, '-B', str(N / 'run_validation.py'), label, *command], cwd=W, env=environment)
    if result.returncode:
        raise SystemExit(result.returncode)
subprocess.run([sys.executable, '-B', str(N / 'surfaces-r3/freeze_build.py'), 'parity-r3-matched-release-build', 'release', 'artifacts'], cwd=W, check=True)
