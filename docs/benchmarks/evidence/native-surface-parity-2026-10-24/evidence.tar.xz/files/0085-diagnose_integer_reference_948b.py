"""One bounded source-only arithmetic adjudication; no native query execution."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

N = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022')
W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
R = N / 'integer-reference-adjudication-948b'
S = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat/sources/hits.parquet')
LOCK = S.parent.parent / '.ingest-uat.lock'
SQL = '''SELECT COUNT(UserID) AS count,
    MIN(UserID) AS minimum, MAX(UserID) AS maximum,
    SUM(CAST(UserID AS HUGEINT)) AS exact_integer_sum,
    SUM(CAST(CAST(UserID AS DOUBLE) AS HUGEINT)) AS exact_converted_sum,
    FSUM(CAST(UserID AS DOUBLE)) AS compensated_sum,
    FAVG(CAST(UserID AS DOUBLE)) AS compensated_average
    FROM input'''

def identity(path):
    p = Path(path)
    with p.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(p), bytes=p.stat().st_size, sha256=digest)

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def worker():
    import duckdb
    owner = json.loads((LOCK / 'owner.json').read_text())
    assert owner['pid'] == os.getppid() and owner['kind'] == 'integer_reference_adjudication'
    with duckdb.connect(config=dict(threads=4, memory_limit='6GiB',
            temp_directory=str(R / 'scratch'), max_temp_directory_size='32GiB',
            autoinstall_known_extensions=False, autoload_known_extensions=False)) as connection:
        connection.from_parquet(str(S)).create_view('input')
        cursor = connection.execute(SQL)
        names = [field[0] for field in cursor.description]
        values = dict(zip(names, cursor.fetchone(), strict=True))
        print(json.dumps(dict(sql=SQL, oracle_version=duckdb.__version__,
            columns=[(field[0], str(field[1])) for field in cursor.description],
            values=values, native_runtime_invoked=False), allow_nan=False))

def main():
    sys.path.insert(0, str(W / 'scripts'))
    from local_uat_storage import GIB, MIB, check_budgets, require_local_path
    base = load('reference_supervisor', N / 'run_independent_reference_945.py')
    guard = base.workload.WorkloadGuard()
    guard.check()
    require_local_path(R, Path.home(), sys.platform)
    R.mkdir()
    (R / 'logs').mkdir()
    initial = base.generation(S)
    source = identity(S)
    prior_protocol = json.loads((N / 'independent-full43-945/protocol.json').read_text())
    assert source == prior_protocol['source']
    def environment():
        return json.loads(subprocess.check_output([str(base.PYTHON), '-B', '-c',
            "import importlib.metadata as m,json,hashlib,pathlib,sys; d=m.distribution('duckdb'); "
            "print(json.dumps({'python':sys.version,'duckdb':d.version,'files':[{'path':str(p),"
            "'sha256':hashlib.sha256(pathlib.Path(d.locate_file(p)).read_bytes()).hexdigest()} for p in d.files "
            "if pathlib.Path(d.locate_file(p)).is_file()]}))"], text=True))
    assert environment() == prior_protocol['dependency']
    assert base.generation(S) == initial
    native_run = json.loads((N / 'full43-run-947.json').read_text())
    assert identity(native_run['input']['path']) == native_run['input']
    assert base.generation(Path(native_run['input']['path'])) == native_run['input_generation']
    assert native_run['process_group_drained'] and not LOCK.exists()
    programs = [identity(p) for p in (Path(__file__), N / 'run_independent_reference_945.py', base.SUPERVISOR, base.WORKLOAD)]
    def storage():
        return check_budgets(R, R / 'scratch', R / 'logs', min_free_bytes=12 * GIB,
            reserve_bytes=32 * GIB, max_workspace_bytes=100 * GIB,
            max_log_bytes=1024 * MIB, max_run_log_bytes=256 * MIB)
    plan = dict(schema='shardloom.integer_reference_adjudication.v1', status='predeclared',
        source=source, generation=initial, programs=programs, sql=SQL,
        dependency=prior_protocol['dependency'],
        input_to_double='Preserve the primitive per-input F64 conversion.',
        exact_method='Sum integral DOUBLE values after exact conversion to 128-bit HUGEINT; '
            'the observed count and extrema must prove the total fits. Python integer division '
            'provides the independently rounded average. Keep original integer sum separately.',
        cross_check='DuckDB FSUM/FAVG use compensated accumulation independently of native code.',
        native_runtime_invoked=False, calls=1, deadline_seconds=300,
        prior_native_failure=identity(N / 'full43-run-947.json'),
        prior_native_post_input_hash_verified=True, storage_before=storage())
    save(R / 'protocol.json', plan)
    owner = dict(pid=os.getpid(), kind='integer_reference_adjudication', protocol=identity(R / 'protocol.json'))
    LOCK.mkdir()
    save(LOCK / 'owner.json', owner)
    record = dict(status='running', protocol=identity(R / 'protocol.json'))
    last_check = 0.0
    def check():
        nonlocal last_check
        if time.monotonic() - last_check < 1:
            return
        last_check = time.monotonic()
        assert json.loads((LOCK / 'owner.json').read_text()) == owner
        assert base.generation(S) == initial
        storage()
        rows = subprocess.check_output(['ps', '-axo', 'pid=,pgid=,rss=,comm='], text=True)
        for row in rows.splitlines():
            fields = row.split(None, 3)
            pid, group, rss = map(int, fields[:3])
            if pid == record.get('pid') or group == record.get('pid'):
                assert rss * 1024 <= 10 * GIB
            else:
                assert not base.workload.native_name(fields[3]), 'another native job is active'
    try:
        command = [str(base.PYTHON), '-B', __file__, '--worker']
        record['command'] = command
        with (R / 'logs/stdout.json').open('x') as out, (R / 'logs/stderr.txt').open('x') as err:
            code = base.supervisor.run(command, cwd=W, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
                output=out, error_output=err, timeout=300, evidence=record, guard=check, max_output_bytes=8 << 20)
        assert code == 0 and record['process_group_drained']
        actual = json.loads((R / 'logs/stdout.json').read_text())
        assert actual['sql'] == SQL and actual['oracle_version'] == '2.0.0'
        v = actual['values']
        assert v['count'] * max(abs(v['minimum']), abs(v['maximum'])) < 2**127
        record['arithmetic'] = dict(exact_source_average=v['exact_integer_sum'] / v['count'],
            exact_converted_average=v['exact_converted_sum'] / v['count'],
            rounded_converted_total_average=float(v['exact_converted_sum']) / v['count'],
            compensated_average=v['compensated_average'], compensated_sum=v['compensated_sum'])
        record['source_hash_unchanged'] = identity(S) == source and base.generation(S) == initial
        assert record['source_hash_unchanged']
        assert [identity(p['path']) for p in programs] == programs
        assert environment() == prior_protocol['dependency']
        record['dependency_hashes_unchanged'] = True
        remaining = list((R / 'scratch').rglob('*'))
        assert not any(p.is_file() for p in remaining)
        record['temporary_payloads_remaining'] = 0
        record.update(status='passed', output=identity(R / 'logs/stdout.json'), storage_after=storage())
    except BaseException as error:
        record.update(status='failed', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        assert json.loads((LOCK / 'owner.json').read_text()) == owner
        (LOCK / 'owner.json').unlink()
        LOCK.rmdir()
        record['shared_lock_released'] = not LOCK.exists()
        save(R / 'receipt.json', record)
    print(json.dumps(record['arithmetic']), flush=True)

if __name__ == '__main__':
    if sys.argv[1:] == ['--worker']:
        worker()
    else:
        main()
