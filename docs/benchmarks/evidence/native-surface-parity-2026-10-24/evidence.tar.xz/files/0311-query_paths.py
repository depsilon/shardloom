"""Explicit ClickBench declarations for a sequential public-path comparison.

This is a diagnostic fixture, not a new engine API. SQL identifies a query at
the standard runner boundary; expression roles execute the declarations below.
No SQL parser, data evaluation, result cache, or alternate engine is used here.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
N = Path('/Users/dylan/LocalData/shardloom/native-surface-parity-20261024')
ROOT = Path(__file__).resolve().parent
LIBRARY = ROOT / 'artifacts/_native.abi3.so'
sys.path[:0] = [str(W / 'python/src'), str(W / 'scripts')]


def load_native():
    import shardloom
    if 'shardloom._native' not in sys.modules:
        spec = importlib.util.spec_from_file_location('shardloom._native', LIBRARY)
        if spec is None or spec.loader is None:
            raise RuntimeError('native library cannot be loaded')
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
    return sys.modules['shardloom._native']


def submitted_statements():
    """Use the standard runner's explicit byte-length dialect for the pinned fixture."""
    from clickbench_reference_packet import query_statements
    from clickbench_native_sql import native_query_statements
    raw, statements = query_statements(W / 'benchmarks/clickbench/queries.sql')
    submitted, _ = native_query_statements(statements, hashlib.sha256(raw).hexdigest())
    return submitted


def dataframe(query: int, source: str, client):
    """Use the existing public LazyFrame builder, including its SQL fragments.

    Aggregates are expression strings because this API has no general .sum()
    expression method. Filters/arithmetic use its public column expressions.
    No .sql() escape hatch supplies missing operations.
    """
    import shardloom as sl
    c = sl.col
    frame = sl.read_vortex(source, client=client)
    nonempty = lambda name: c(name) != ''
    text = nonempty('SearchPhrase')

    def top(value, key, count=10):
        return value.sort(key, descending=True).limit(count)

    if query == 1:
        return frame.agg('COUNT(*) AS count_all')
    if query == 2:
        return frame.filter(c('AdvEngineID') != 0).agg('COUNT(*) AS count_all')
    if query == 3:
        return frame.agg('SUM(AdvEngineID) AS sum_AdvEngineID_0',
                         'COUNT(*) AS count_all_1', 'AVG(ResolutionWidth) AS avg_ResolutionWidth_2')
    if query == 4:
        return frame.agg('AVG(UserID) AS avg_UserID_0')
    if query in (5, 6):
        name = 'UserID' if query == 5 else 'SearchPhrase'
        return frame.agg(**{f'count_distinct_{name}_0': sl.count_distinct(c(name))})
    if query == 7:
        return frame.agg('MIN(EventDate) AS min_EventDate_0', 'MAX(EventDate) AS max_EventDate_1')
    if query == 8:
        return frame.filter(c('AdvEngineID') != 0).group_by('AdvEngineID').agg(
            count_all_1='COUNT(*)').sort('count_all_1', descending=True)
    if query == 9:
        return top(frame.group_by('RegionID').agg(u=sl.count_distinct(c('UserID'))), 'u')
    if query == 10:
        return top(frame.group_by('RegionID').agg(
            'SUM(AdvEngineID) AS sum_AdvEngineID_1', 'COUNT(*) AS c',
            'AVG(ResolutionWidth) AS avg_ResolutionWidth_3',
            'COUNT(DISTINCT UserID) AS count_distinct_UserID_4'), 'c')
    if query in (11, 12):
        keys = ['MobilePhoneModel'] if query == 11 else ['MobilePhone', 'MobilePhoneModel']
        return top(frame.filter(nonempty('MobilePhoneModel')).group_by(*keys).agg(
            u=sl.count_distinct(c('UserID'))), 'u')
    if query in (13, 14, 15):
        keys = ['SearchEngineID', 'SearchPhrase'] if query == 15 else ['SearchPhrase']
        if query == 14:
            return top(frame.filter(text).group_by(*keys).agg(u=sl.count_distinct(c('UserID'))), 'u')
        return top(frame.filter(text).group_by(*keys).agg(c='COUNT(*)'), 'c')
    if query in (16, 17, 18):
        keys = ['UserID'] if query == 16 else ['UserID', 'SearchPhrase']
        alias = f'count_all_{len(keys)}'
        grouped = frame.group_by(*keys).agg(**{alias: 'COUNT(*)'})
        return grouped.limit(10) if query == 18 else top(grouped, alias)
    if query == 19:
        return top(frame.select('UserID', 'EXTRACT_MINUTE(EventTime) AS m', 'SearchPhrase')
                   .group_by('UserID', 'm', 'SearchPhrase').agg(count_all_3='COUNT(*)'), 'count_all_3')
    if query == 20:
        return frame.filter(c('UserID') == 435090932899640449).select('UserID')
    if query == 21:
        return frame.filter(c('URL').contains('google')).agg('COUNT(*) AS count_all')
    if query == 22:
        return top(frame.filter(c('URL').contains('google') & text).group_by('SearchPhrase').agg(
            'MIN(URL) AS min_URL_1', 'COUNT(*) AS c'), 'c')
    if query == 23:
        return top(frame.filter(c('Title').contains('Google') & c('URL').not_contains('.google.') & text)
                   .group_by('SearchPhrase').agg('MIN(URL) AS min_URL_1', 'MIN(Title) AS min_Title_2',
                                                'COUNT(*) AS c', 'COUNT(DISTINCT UserID) AS count_distinct_UserID_4'), 'c')
    if query == 24:
        return frame.filter(c('URL').contains('google')).select('*').sort('EventTime').limit(10)
    if query in (25, 26, 27):
        keys = ['SearchPhrase'] if query == 26 else ['EventTime']
        if query == 27:
            keys.append('SearchPhrase')
        return frame.filter(text).select('SearchPhrase').sort(*keys).limit(10)
    if query == 28:
        return top(frame.filter(nonempty('URL')).group_by('CounterID').agg(
            'AVG(octet_length(URL)) AS l', 'COUNT(*) AS c').having(c('c') > 100000), 'l', 25)
    if query == 29:
        key = 'REGEX_DOMAIN(Referer) AS k'
        return top(frame.filter(nonempty('Referer')).select('Referer', key).group_by('k').agg(
            'AVG(octet_length(Referer)) AS l', 'COUNT(*) AS c', 'MIN(Referer) AS min_Referer_3')
                   .having(c('c') > 100000), 'l', 25)
    if query == 30:
        return frame.agg(*[
            f'SUM({c("ResolutionWidth") if index == 0 else c("ResolutionWidth") + index}) AS sum_ResolutionWidth_{index}'
            for index in range(90)])
    if query in (31, 32, 33):
        keys = ['SearchEngineID', 'ClientIP'] if query == 31 else ['WatchID', 'ClientIP']
        base = frame if query == 33 else frame.filter(text)
        return top(base.group_by(*keys).agg('COUNT(*) AS c', 'SUM(IsRefresh) AS sum_IsRefresh_3',
                                          'AVG(ResolutionWidth) AS avg_ResolutionWidth_4'), 'c')
    if query == 34:
        return top(frame.group_by('URL').agg(c='COUNT(*)'), 'c')
    if query == 35:
        return top(frame.select('1 AS literal_1', 'URL').group_by('literal_1', 'URL').agg(c='COUNT(*)'), 'c')
    if query == 36:
        return top(frame.select('ClientIP', 'ClientIP - 1 AS ClientIP_minus1',
                                 'ClientIP - 2 AS ClientIP_minus2', 'ClientIP - 3 AS ClientIP_minus3')
                   .group_by('ClientIP', 'ClientIP_minus1', 'ClientIP_minus2', 'ClientIP_minus3').agg(c='COUNT(*)'), 'c')
    if query in (37, 38):
        name = 'URL' if query == 37 else 'Title'
        from datetime import date
        days = lambda value: (date.fromisoformat(value) - date(1970, 1, 1)).days
        # EventDate is stored as UInt16 days since the epoch, not Date32.
        predicate = ((c('CounterID') == 62) & (c('EventDate') >= days('2013-07-01'))
                     & (c('EventDate') <= days('2013-07-31')) & (c('DontCountHits') == 0)
                     & (c('IsRefresh') == 0) & nonempty(name))
        return top(frame.filter(predicate).group_by(name).agg(PageViews='COUNT(*)'), 'PageViews')
    if query in (39, 40, 41, 42, 43):
        from datetime import date
        days = lambda value: (date.fromisoformat(value) - date(1970, 1, 1)).days
        start, end = ('2013-07-14', '2013-07-15') if query == 43 else ('2013-07-01', '2013-07-31')
        predicate = ((c('CounterID') == 62) & (c('EventDate') >= days(start))
                     & (c('EventDate') <= days(end)) & (c('IsRefresh') == 0))
        offset = {39: 1000, 40: 1000, 41: 100, 42: 10000, 43: 1000}[query]
        if query == 39:
            predicate = predicate & (c('IsLink') != 0) & (c('IsDownload') == 0)
            return (frame.filter(predicate).select('URL').group_by('URL').agg(PageViews='COUNT(*)')
                    .sort('PageViews', descending=True).limit(10, offset=offset))
        if query == 40:
            return (frame.filter(predicate)
                    .select('TraficSourceID', 'SearchEngineID', 'AdvEngineID',
                            "CASE WHEN SearchEngineID = 0 AND AdvEngineID = 0 THEN Referer ELSE '' END AS Src",
                            'URL AS Dst')
                    .group_by('TraficSourceID', 'SearchEngineID', 'AdvEngineID', 'Src', 'Dst')
                    .agg(PageViews='COUNT(*)').sort('PageViews', descending=True)
                    .limit(10, offset=offset))
        if query == 41:
            predicate = (predicate & ((c('TraficSourceID') == -1) | (c('TraficSourceID') == 6))
                         & (c('RefererHash') == 3594120000172545465))
            return (frame.filter(predicate).select('URLHash', 'EventDate').group_by('URLHash', 'EventDate')
                    .agg(PageViews='COUNT(*)')
                    .sort('PageViews', descending=True).limit(10, offset=offset))
        if query == 42:
            predicate = predicate & (c('DontCountHits') == 0) & (c('URLHash') == 2868770270353813622)
            return (frame.filter(predicate).select('WindowClientWidth', 'WindowClientHeight')
                    .group_by('WindowClientWidth', 'WindowClientHeight')
                    .agg(PageViews='COUNT(*)').sort('PageViews', descending=True)
                    .limit(10, offset=offset))
        predicate = predicate & (c('DontCountHits') == 0)
        return (frame.filter(predicate).select('DATE_TRUNC_MINUTE(EventTime) AS M')
                .group_by('M').agg(PageViews='COUNT(*)').sort('M').limit(10, offset=offset))
    raise ValueError(f'unknown query {query}')


def native_expression(query: int, source: str):
    """Construct typed native relations directly; no SQL statement is submitted."""
    native = load_native()
    E = native.Expression
    c, lit = E.column, E.literal

    def call(name, *args):
        return E.call(name, list(args))

    def scan(names, predicate=None):
        relation = native.Relation.scan(source)
        if names is not None:
            relation = relation.project([(name, c(name)) for name in dict.fromkeys(names)])
        return relation if predicate is None else relation.filter(predicate)

    def agg(relation, keys, measures, order=None, limit=None, offset=0):
        result = relation.aggregate(keys, measures)
        if order is not None:
            result = result.sort([(order, True, None)])
        if limit is not None:
            result = result.limit(limit, offset=offset)
        return result

    text = c('SearchPhrase') != lit('')
    if query == 1:
        return agg(scan(['WatchID']), [], [('count', None, 'count_all')])
    if query == 2:
        return agg(scan(['AdvEngineID'], c('AdvEngineID') != lit(0)), [], [('count', None, 'count_all')])
    if query == 3:
        return agg(scan(['AdvEngineID', 'ResolutionWidth']), [], [
            ('sum', 'AdvEngineID', 'sum_AdvEngineID_0'), ('count', None, 'count_all_1'),
            ('avg', 'ResolutionWidth', 'avg_ResolutionWidth_2')])
    if query in (4, 5, 6):
        name = 'SearchPhrase' if query == 6 else 'UserID'
        function = 'avg' if query == 4 else 'count_distinct'
        return agg(scan([name]), [], [(function, name, f'{function}_{name}_0')])
    if query == 7:
        return agg(scan(['EventDate']), [], [('min', 'EventDate', 'min_EventDate_0'),
                                           ('max', 'EventDate', 'max_EventDate_1')])
    if query == 8:
        return agg(scan(['AdvEngineID'], c('AdvEngineID') != lit(0)), ['AdvEngineID'],
                   [('count', None, 'count_all_1')], 'count_all_1')
    if query == 9:
        return agg(scan(['RegionID', 'UserID']), ['RegionID'], [('count_distinct', 'UserID', 'u')], 'u', 10)
    if query == 10:
        return agg(scan(['RegionID', 'UserID', 'AdvEngineID', 'ResolutionWidth']), ['RegionID'], [
            ('sum', 'AdvEngineID', 'sum_AdvEngineID_1'), ('count', None, 'c'),
            ('avg', 'ResolutionWidth', 'avg_ResolutionWidth_3'),
            ('count_distinct', 'UserID', 'count_distinct_UserID_4')], 'c', 10)
    if query in (11, 12):
        keys = ['MobilePhoneModel'] if query == 11 else ['MobilePhone', 'MobilePhoneModel']
        return agg(scan(keys + ['UserID'], c('MobilePhoneModel') != lit('')), keys,
                   [('count_distinct', 'UserID', 'u')], 'u', 10)
    if query in (13, 14, 15):
        keys = ['SearchEngineID', 'SearchPhrase'] if query == 15 else ['SearchPhrase']
        measures = [('count_distinct', 'UserID', 'u')] if query == 14 else [('count', None, 'c')]
        columns = keys + (['UserID'] if query == 14 else [])
        return agg(scan(columns, text), keys, measures, measures[0][2], 10)
    if query in (16, 17, 18):
        keys = ['UserID'] if query == 16 else ['UserID', 'SearchPhrase']
        alias = f'count_all_{len(keys)}'
        return agg(scan(keys), keys, [('count', None, alias)], None if query == 18 else alias, 10)
    if query == 19:
        minute = call('extract_minute', c('EventTime'))
        relation = scan(['UserID', 'EventTime', 'SearchPhrase']).project([
            ('UserID', c('UserID')), ('m', minute), ('SearchPhrase', c('SearchPhrase'))])
        return agg(relation, ['UserID', 'm', 'SearchPhrase'], [('count', None, 'count_all_3')], 'count_all_3', 10)
    if query == 20:
        return scan(['UserID'], c('UserID') == lit(435090932899640449))
    if query == 21:
        return agg(scan(['URL'], call('contains', c('URL'), lit('google'))), [], [('count', None, 'count_all')])
    if query == 22:
        return agg(scan(['SearchPhrase', 'URL'], call('contains', c('URL'), lit('google')) & text),
                   ['SearchPhrase'], [('min', 'URL', 'min_URL_1'), ('count', None, 'c')], 'c', 10)
    if query == 23:
        predicate = call('contains', c('Title'), lit('Google')) & ~call('contains', c('URL'), lit('.google.')) & text
        return agg(scan(['SearchPhrase', 'URL', 'Title', 'UserID'], predicate), ['SearchPhrase'], [
            ('min', 'URL', 'min_URL_1'), ('min', 'Title', 'min_Title_2'), ('count', None, 'c'),
            ('count_distinct', 'UserID', 'count_distinct_UserID_4')], 'c', 10)
    if query == 24:
        return scan(None, call('contains', c('URL'), lit('google'))).sort([('EventTime', False, None)]).limit(10)
    if query in (25, 26, 27):
        keys = ['SearchPhrase'] if query == 26 else ['EventTime']
        if query == 27:
            keys.append('SearchPhrase')
        return scan(['SearchPhrase', *keys], text).sort([(key, False, None) for key in keys]).limit(10).project([
            ('SearchPhrase', c('SearchPhrase'))])
    if query == 28:
        # Canonical ClickBench LENGTH is byte length, not Unicode character count.
        relation = scan(['CounterID', 'URL'], c('URL') != lit('')).project([
            ('CounterID', c('CounterID')), ('url_bytes', call('octet_length', c('URL')))])
        return agg(relation, ['CounterID'], [('avg', 'url_bytes', 'l'), ('count', None, 'c')]).filter(
            c('c') > lit(100000)).sort([('l', True, None)]).limit(25)
    if query == 29:
        referer = c('Referer')
        relation = scan(['Referer'], referer != lit('')).project([
            ('Referer', referer), ('k', call('regex_domain', referer)),
            ('referer_bytes', call('octet_length', referer))])
        return agg(relation, ['k'], [('avg', 'referer_bytes', 'l'), ('count', None, 'c'),
                                    ('min', 'Referer', 'min_Referer_3')]).filter(
            c('c') > lit(100000)).sort([('l', True, None)]).limit(25)
    if query == 30:
        relation = scan(['ResolutionWidth']).project([
            (f'width_{index}', c('ResolutionWidth') if index == 0 else c('ResolutionWidth') + lit(index))
            for index in range(90)])
        return agg(relation, [], [('sum', f'width_{index}', f'sum_ResolutionWidth_{index}') for index in range(90)])
    if query in (31, 32, 33):
        keys = ['SearchEngineID', 'ClientIP'] if query == 31 else ['WatchID', 'ClientIP']
        cols = keys + ['IsRefresh', 'ResolutionWidth'] + ([] if query == 33 else ['SearchPhrase'])
        return agg(scan(cols, None if query == 33 else text), keys, [
            ('count', None, 'c'), ('sum', 'IsRefresh', 'sum_IsRefresh_3'),
            ('avg', 'ResolutionWidth', 'avg_ResolutionWidth_4')], 'c', 10)
    if query == 34:
        return agg(scan(['URL']), ['URL'], [('count', None, 'c')], 'c', 10)
    if query == 35:
        relation = scan(['URL']).project([('literal_1', lit(1)), ('URL', c('URL'))])
        return agg(relation, ['literal_1', 'URL'], [('count', None, 'c')], 'c', 10)
    if query == 36:
        names = ['ClientIP', 'ClientIP_minus1', 'ClientIP_minus2', 'ClientIP_minus3']
        relation = scan(['ClientIP']).project([(name, c('ClientIP') if index == 0 else c('ClientIP') - lit(index))
                                              for index, name in enumerate(names)])
        return agg(relation, names, [('count', None, 'c')], 'c', 10)
    if query in (37, 38, 39, 40, 41, 42, 43):
        from datetime import date
        days = lambda value: (date.fromisoformat(value) - date(1970, 1, 1)).days
        start, end = ('2013-07-14', '2013-07-15') if query == 43 else ('2013-07-01', '2013-07-31')
        predicate = ((c('CounterID') == lit(62)) & (c('EventDate') >= lit(days(start)))
                     & (c('EventDate') <= lit(days(end))) & (c('IsRefresh') == lit(0)))
        columns = ['CounterID', 'EventDate', 'IsRefresh']
        offset = {39: 1000, 40: 1000, 41: 100, 42: 10000, 43: 1000}.get(query, 0)
        if query in (37, 38):
            key = 'URL' if query == 37 else 'Title'
            predicate = predicate & (c('DontCountHits') == lit(0)) & (c(key) != lit(''))
            columns += ['DontCountHits', key]
            keys = [key]
        elif query == 39:
            predicate = predicate & (c('IsLink') != lit(0)) & (c('IsDownload') == lit(0))
            columns += ['IsLink', 'IsDownload', 'URL']
            keys = ['URL']
        elif query == 40:
            columns += ['TraficSourceID', 'SearchEngineID', 'AdvEngineID', 'Referer', 'URL']
            keys = ['TraficSourceID', 'SearchEngineID', 'AdvEngineID', 'Src', 'Dst']
        elif query == 41:
            predicate = predicate & ((c('TraficSourceID') == lit(-1)) | (c('TraficSourceID') == lit(6))) & (c('RefererHash') == lit(3594120000172545465))
            columns += ['TraficSourceID', 'RefererHash', 'URLHash']
            keys = ['URLHash', 'EventDate']
        elif query == 42:
            predicate = predicate & (c('DontCountHits') == lit(0)) & (c('URLHash') == lit(2868770270353813622))
            columns += ['DontCountHits', 'URLHash', 'WindowClientWidth', 'WindowClientHeight']
            keys = ['WindowClientWidth', 'WindowClientHeight']
        else:
            predicate = predicate & (c('DontCountHits') == lit(0))
            columns += ['DontCountHits', 'EventTime']
            keys = ['M']
        relation = scan(columns, predicate)
        if query == 40:
            conditional = call('case_when', (c('SearchEngineID') == lit(0)) & (c('AdvEngineID') == lit(0)), c('Referer'), lit(''))
            relation = relation.project([(key, c(key)) for key in keys[:3]] + [('Src', conditional), ('Dst', c('URL'))])
        if query == 43:
            relation = relation.project([('M', call('date_trunc_minute', c('EventTime')))])
            return agg(relation, keys, [('count', None, 'PageViews')]).sort([('M', False, None)]).limit(10, offset=offset)
        return agg(relation, keys, [('count', None, 'PageViews')], 'PageViews', 10, offset)
    raise ValueError(f'unknown query {query}')


def result_envelope(result, role, query, declaration):
    """Adapt native result delivery only, preserving engine-owned clocks/evidence."""
    from shardloom.models import OutputEnvelope
    owner = getattr(result, 'native_result', result)
    if owner is None:
        raise RuntimeError('embedded role did not retain a native result')
    fields = dict(owner.report)
    for key in ('fallback_attempted', 'external_engine_invoked'):
        if fields.get(key) not in ('false', False):
            raise RuntimeError(f'native report does not prove {key}=false')
        public = f'public_workflow_{key}'
        if public in fields and fields[public] not in ('false', False):
            raise RuntimeError(f'inconsistent {public}')
        fields[public] = fields[key]
    rows, export = owner.row_export(temporal_objects=False, wire_values=True)
    if not export.get('complete') or export.get('fallback_attempted') is not False:
        raise RuntimeError('native row export is incomplete or attempted fallback')
    if len(rows) != owner.row_count:
        raise RuntimeError('incomplete native rows')
    if 'result_jsonl' in fields or 'result_values_json' in fields:
        raise RuntimeError('native result unexpectedly already contains a serialized payload')
    fields.update(
        result_values_json=json.dumps(rows, ensure_ascii=False, allow_nan=False),
        result_payload_complete='true', output_row_count=str(owner.row_count),
        result_schema_json=owner.schema_json, result_schema_format='vortex.dtype.serde.v1',
        comparison_role=role, comparison_query_id=str(query),
        comparison_declaration=declaration,
        comparison_row_export='explicit_after_engine_clock;complete_wire_values',
    )
    envelope = dict(OutputEnvelope.from_field_mapping(fields, command='run', summary='native comparison query completed',
                                                     human_text='native comparison query completed').raw)
    # The standard CLI runner reads its existing flat compatibility mirror.
    # Mirror the exact typed fields, without changing evidence values.
    envelope['fields'] = list(envelope['result']['fields'])
    return envelope


def main(role):
    if not __debug__:
        raise RuntimeError('optimized Python is unsupported for this diagnostic adapter')
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['run'])
    parser.add_argument('surface', choices=['sql'])
    parser.add_argument('--sql', required=True)
    parser.add_argument('--request', choices=['collect'], required=True)
    parser.add_argument('--bounded', choices=['true'], required=True)
    parser.add_argument('--memory-gb', type=int, required=True)
    parser.add_argument('--max-parallelism', type=int, required=True)
    parser.add_argument('--format', choices=['json'], required=True)
    parser.add_argument('--input', required=True)
    parser.add_argument('--input-format', choices=['vortex'], required=True)
    args = parser.parse_args()
    statements = submitted_statements()
    if statements.count(args.sql) != 1:
        raise ValueError('runner statement does not identify exactly one canonical query')
    query = statements.index(args.sql) + 1
    native = load_native()
    if role in ('python_sql', 'dataframe'):
        import shardloom as sl
        client = sl.ShardLoomClient(transport='native', memory_gb=args.memory_gb,
                                  max_parallelism=args.max_parallelism, timeout=115)
        try:
            sql = bind_sql_source(args.sql, args.input)
            workflow = (sl.sql(sql, input=args.input, input_format='vortex', client=client)
                        if role == 'python_sql' else dataframe(query, args.input, client))
            declaration = workflow._relation_statement()
            result = workflow.collect()
            envelope = result_envelope(result, role, query, declaration)
        finally:
            client.close()
    elif role in ('native_expression', 'embedded_workflow'):
        session = native.Session(native.ExecutionResources(args.memory_gb << 30, args.max_parallelism))
        try:
            if role == 'native_expression':
                relation = native_expression(query, args.input)
                plan = session.plan(relation, files=[(args.input, 'vortex', None)])
                declaration = 'typed NativeRelationDeclaration; no SQL submitted'
            else:
                from native_workflow_protocol import public_workflow_command
                arguments = public_workflow_command('unused', args.sql, input_path=args.input,
                    input_format='vortex', memory_gb=args.memory_gb, max_parallelism=args.max_parallelism)[2:]
                # Session.workflow returns the retained native operation. JSON is
                # a delivery option of the CLI, not an argument of this API.
                at = arguments.index('--format')
                del arguments[at:at + 2]
                plan = session.workflow(arguments)
                declaration = args.sql
            result = plan.collect(timeout=115)
            envelope = result_envelope(result, role, query, declaration)
        finally:
            session.close()
    else:
        raise ValueError(f'unsupported role {role}')
    print(json.dumps(envelope, ensure_ascii=False, allow_nan=False), flush=True)


def bind_sql_source(statement, source):
    if statement.count(' FROM hits') != 1:
        raise ValueError('expected exactly one canonical ClickBench source')
    quoted = "'" + source.replace("'", "''") + "'"
    return statement.replace(' FROM hits', ' FROM ' + quoted, 1)

