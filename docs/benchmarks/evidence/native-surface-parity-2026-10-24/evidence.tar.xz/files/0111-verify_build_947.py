"""Freeze the fresh executable and check its distinguishing public behavior."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
N = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022')
sys.path.insert(0, str(W / 'scripts'))
from native_workflow_protocol import extract_result, public_workflow_command, strict_json
from run_clickbench_query_uat import equivalent

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

bounded = load('bounded', '/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
guards = load('guards', '/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/native_workload_guard_816.py')

def identity(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

plan_path = N / 'fresh-release-plan-947.json'
build_path = N / 'release-build-947.json'
plan = strict_json(plan_path.read_text())
build = strict_json(build_path.read_text())
assert build['status'] == 'passed' and build['returncode'] == 0 and build['process_group_drained']
assert build['source_before'] == build['source_after']
assert plan['source_commit'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
assert plan['source_tree'] == subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=W, text=True).strip()
assert build['command'] == plan['command'] and build['target'] == plan['target']
assert plan['target_did_not_exist'] is True
for relative, expected in build['source_after'].items():
    assert identity(W / relative)['sha256'] == expected, relative
log = N / 'release-build-947.log'
assert identity(log)['sha256'] == build['log_sha256']
for package in ('shardloom-cli', 'shardloom-vortex'):
    assert f'Compiling {package} v0.7.0 ({W / package})' in log.read_text()

root = N / 'role-checks-947'
root.mkdir()
artifact = N / 'artifacts' / 'native-correctness-947'
artifact.mkdir(parents=True)
binary = artifact / 'shardloom'
shutil.copy2(Path(plan['target']) / 'release/shardloom', binary)
binary_identity = identity(binary)
assert binary_identity['sha256'] != 'eb1af7ec23426f58c3cb0f748adfa379e14ae8d788492a790811de8aca12275d'
source = root / 'rows.jsonl'
source.write_text(''.join(json.dumps(row) + '\n' for row in [
    dict(UserID=10**18, Referer='http://example.test'),
    dict(UserID=None, Referer='http://example.test/'),
    dict(UserID=1, Referer='http://example.test/a'),
    dict(UserID=-(10**18), Referer=''),
]))
cases = [
    ('integer_average', 'SELECT AVG(UserID) FROM hits', [{'avg_UserID_0': 1.0 / 3.0}]),
    ('fused_integer_totals', 'SELECT SUM(UserID), AVG(UserID) FROM hits',
     [{'sum_UserID_0': 1.0, 'avg_UserID_1': 1.0 / 3.0}]),
    ('regex_grouping', r"SELECT REGEXP_REPLACE(Referer, '^https?://(?:www\.)?([^/]+)/.*$', '\1') AS k, AVG(length(Referer)) AS l, COUNT(*) AS c, MIN(Referer) FROM hits WHERE Referer <> '' GROUP BY k HAVING c > 0 ORDER BY k",
     [dict(k='example.test', l=20.5, c=2, min_Referer_3='http://example.test/'),
      dict(k='http://example.test', l=19.0, c=1, min_Referer_3='http://example.test')]),
]
workload = guards.WorkloadGuard()
workload.check()
result = dict(status='running', source_commit=plan['source_commit'], source_tree=plan['source_tree'],
              build=identity(build_path), build_plan=identity(plan_path), executable=binary_identity,
              source=identity(source), script=identity(__file__), cases=[],
              scope='Three tiny functional role checks; no benchmark or Full43 observation.')
try:
    for name, sql, expected in cases:
        command = public_workflow_command(binary, sql, input_path=source, input_format='jsonl',
                                          memory_gb=1, max_parallelism=2)
        record = dict(name=name, sql=sql, command=command, expected=expected)
        output, error = root / (name + '.stdout.json'), root / (name + '.stderr.txt')
        with output.open('xb') as stdout, error.open('xb') as stderr:
            status = bounded.run(command, cwd=W, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
                output=stdout, error_output=stderr, timeout=120, evidence=record,
                guard=lambda: workload.check(record.get('pid')), max_output_bytes=8 << 20)
        record['stdout'] = identity(output)
        record['stderr'] = identity(error)
        result['cases'].append(record)
        assert status == 0
        record['actual'] = extract_result(strict_json(output.read_text()))
        assert equivalent(record['actual'], expected), name
        record['passed'] = True
    assert identity(binary) == binary_identity
    for relative, expected in build['source_after'].items():
        assert identity(W / relative)['sha256'] == expected, relative
    result['status'] = 'passed'
except BaseException as error:
    result.update(status='failed', failure=type(error).__name__ + ': ' + str(error))
    raise
finally:
    save(N / 'native-runtime-947.json', result)
print('Fresh runtime identity and all three functional role checks passed.', flush=True)
