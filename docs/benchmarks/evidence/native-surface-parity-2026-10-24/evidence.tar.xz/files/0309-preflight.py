"""Prepare every declared path sequentially, without executing the dataset."""
import hashlib
import json
from pathlib import Path
import sys

import query_paths
from query_paths import ROOT, W, bind_sql_source, dataframe, load_native, native_expression
from clickbench_reference_packet import query_statements

query_paths.LIBRARY = ROOT / 'artifacts/_native.abi3.so'

SOURCE = '/Users/dylan/LocalData/shardloom/clickbench-100m-uat/vortex/fresh-roadmap-663-a1.vortex'


def run():
    if not __debug__:
        raise RuntimeError('optimized Python is unsupported')
    import shardloom as sl
    native = load_native()
    statements = query_paths.submitted_statements()
    records = []
    for role in ('python_sql', 'dataframe', 'native_expression', 'embedded_workflow'):
        for query, sql in enumerate(statements, 1):
            session = native.Session(native.ExecutionResources(24 << 30, 12))
            client = sl.ShardLoomClient(transport='native', memory_gb=24, max_parallelism=12)
            record = dict(role=role, query=query, engine_executed=False)
            try:
                if role == 'embedded_workflow':
                    from native_workflow_protocol import public_workflow_command
                    arguments = public_workflow_command('unused', sql, input_path=SOURCE, input_format='vortex',
                                                        memory_gb=24, max_parallelism=12)[2:]
                    at = arguments.index('--format')
                    del arguments[at:at + 2]
                    plan = session.workflow(arguments)
                    record['declaration'] = sql
                elif role == 'native_expression':
                    declaration = native_expression(query, SOURCE)
                    record['declaration'] = 'typed NativeRelationDeclaration; no SQL submitted'
                    plan = session.plan(declaration, files=[(SOURCE, 'vortex', None)])
                else:
                    workflow = (sl.sql(bind_sql_source(sql, SOURCE), input=SOURCE, input_format='vortex', client=client)
                                if role == 'python_sql' else dataframe(query, SOURCE, client))
                    statement = workflow._relation_statement()
                    if not statement:
                        raise ValueError('public workflow has no complete relational declaration')
                    record['declaration'] = statement
                    record['operation_summary'] = workflow.operation_summary
                    plan = session.sql(statement, files=[(SOURCE, 'vortex', None)])
                plan.prepare(timeout=30)
                plan.release_prepared()
                record['status'] = 'prepared'
            except Exception as error:
                record.update(status='unsupported', error_type=type(error).__name__, error=str(error))
                diagnostic = getattr(error, 'diagnostic', None)
                if diagnostic is not None:
                    record['diagnostic'] = diagnostic
            finally:
                client.close()
                session.close()
            records.append(record)
            print(json.dumps({k: v for k, v in record.items() if k not in ('declaration', 'operation_summary')},
                             allow_nan=False), flush=True)
    result = dict(schema='shardloom.query_path_preflight.v1', source=SOURCE,
                  native_queries_executed=0, resources=dict(memory_gb=24, max_parallelism=12),
                  source_file=str(ROOT / 'query_paths.py'),
                  source_sha256=hashlib.sha256((ROOT / 'query_paths.py').read_bytes()).hexdigest(),
                  records=records)
    path = ROOT / 'preflight-final.json'
    with path.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')


if __name__ == '__main__':
    run()

