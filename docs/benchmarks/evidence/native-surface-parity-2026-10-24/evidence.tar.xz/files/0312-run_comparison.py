"""One sequential, guarded observation of each existing native query entry point."""
from __future__ import annotations

import gzip
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

from query_paths import ROOT, W, N
from clickbench_reference_packet import load_reference_packet
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
from native_workflow_protocol import extract_result, report_fields, strict_json
from run_clickbench_query_uat import equivalent

SUPERVISOR = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
GUARD = Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/native_workload_guard_816.py')
INPUT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat/vortex/fresh-roadmap-663-a1.vortex')
REFERENCE = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022/independent-full43-948/reference.json')
PYTHON = '/opt/homebrew/opt/python@3.13/bin/python3.13'
PYTHON_SITE = N / 'duckdb-reference-env/lib/python3.13/site-packages'
LIBRARY = ROOT / 'artifacts/_native.abi3.so'
BUILD = ROOT / 'artifacts/build-summary.json'
FIXTURE = ROOT / 'fixture-release/report.json'
PAIR_NAMES = (
    'embedded_workflow_vs_python_sql',
    'embedded_workflow_vs_dataframe',
    'embedded_workflow_vs_native_expression',
    'cli_sql_vs_embedded_workflow',
    'accepted_cli_vs_candidate_cli',
)
PAIRS_PLAN = ROOT / 'pairs-plan.json'
PAIRS_RECEIPT = ROOT / 'pairs-receipt.json'
ROLES = ('cli_sql', 'embedded_workflow', 'python_sql', 'dataframe', 'native_expression')


def identity(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def generation(path):
    stat = path.stat()
    return dict(device=stat.st_dev, inode=stat.st_ino, size_bytes=stat.st_size,
                mtime_ns=stat.st_mtime_ns, ctime_ns=stat.st_ctime_ns)


def read(path):
    return strict_json(Path(path).read_text())


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def storage_snapshot():
    require_local_path(N, Path.home(), sys.platform)
    return check_budgets(N, INPUT, ROOT / 'runs',
        min_free_bytes=12 * GIB, reserve_bytes=128 * MIB,
        max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)


def git_bytes(*args):
    return subprocess.check_output(['git', *args], cwd=W)


def working_tree_identity():
    return dict(
        head_commit=git_bytes('rev-parse', 'HEAD').decode().strip(),
        head_tree=git_bytes('rev-parse', 'HEAD^{tree}').decode().strip(),
        status_porcelain=git_bytes('status', '--porcelain', '--untracked-files=all').decode(),
        diff_sha256=hashlib.sha256(git_bytes('diff', '--binary', 'HEAD')).hexdigest(),
    )


def main():
    if not __debug__:
        raise RuntimeError('optimized Python is unsupported')
    receipt_path = ROOT / 'full43-receipt.json'
    plan_path = ROOT / 'full43-plan.json'
    assert not receipt_path.exists() and not plan_path.exists()
    bounded, guards = load('bounded', SUPERVISOR), load('guards', GUARD)
    assert identity(SUPERVISOR)['sha256'] == '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97'
    assert identity(GUARD)['sha256'] == 'ce56dd25bd4e55c8c7b8929140c2f2228f27f42d79ceea5645d50db320407b76'
    build = read(BUILD)
    assert build['status'] == 'passed' and build['package_feature_union']
    assert build['source_before'] == build['source_after']
    binary = Path(build['artifacts']['cli']['path'])
    assert Path(build['artifacts']['library']['path']) == LIBRARY
    artifacts = [build['artifacts'][name] for name in ('cli', 'library')]
    fixture = read(FIXTURE)
    assert fixture['status'] == 'passed' and fixture['oracle_only']
    assert fixture['real_dataset_queries_executed'] == 0
    assert fixture['binary'] == build['artifacts']['cli']
    assert fixture['library'] == build['artifacts']['library']
    assert fixture['declarations'] == identity(ROOT / 'query_paths.py')
    assert len(fixture['observations']) == 43 * len(ROLES)
    assert all(row['status'] == 'passed' for row in fixture['observations'])
    for role in ROLES:
        assert [row['query'] for row in fixture['observations'] if row['role'] == role] == list(range(1, 44))
    for query in range(1, 44):
        schemas = [strict_json(row['schema']) for row in fixture['observations'] if row['query'] == query]
        assert all(schema == schemas[0] for schema in schemas), f'cross-surface fixture schema mismatch at query {query}'

    pair_plan = read(PAIRS_PLAN)
    pair_receipt = read(PAIRS_RECEIPT)
    assert pair_plan['status'] == 'predeclared'
    assert pair_receipt['status'] == 'passed'
    assert [row['name'] for row in pair_receipt['comparisons']] == list(PAIR_NAMES)
    assert all(row['status'] == 'passed' and row['tolerance_screen']['all_within_allowance']
               for row in pair_receipt['comparisons'])

    def verify_sources():
        frozen_sources = {**build['source_after'], **build['runtime_python_sources']}
        for relative, digest in frozen_sources.items():
            assert identity(W / relative)['sha256'] == digest, relative
        current_python = sorted((W / 'python/src').rglob('*.py'))
        assert {str(path.relative_to(W)) for path in current_python} == set(build['runtime_python_sources'])
        for artifact in artifacts:
            assert identity(artifact['path']) == artifact

    print('Preparing frozen source, input, reference, and guard identities.', flush=True)
    verify_sources()
    worktree = working_tree_identity()
    source_commit = worktree['head_commit']
    reference_identity = identity(REFERENCE)
    assert reference_identity['sha256'] == 'fc5780da415dc33bd06ed0879db07fc040db5dd419e3c37ecde7cd40a315696b'
    expected = load_reference_packet(REFERENCE, W / 'benchmarks/clickbench/queries.sql')
    input_generation = generation(INPUT)
    input_identity = identity(INPUT)
    assert input_identity['sha256'] == '06f70eb6f118d11e4a5226eb641225d708fdb4ac1b3f45942872d5ef5df4fc22'
    assert generation(INPUT) == input_generation
    preflight = read(ROOT / 'preflight-final.json')
    assert preflight['native_queries_executed'] == 0
    assert all(row['engine_executed'] is False for row in preflight['records'])
    assert read(ROOT / 'adapter-selftest.json')['status'] == 'passed'
    selected = {role: ([*range(1, 44)] if role == 'cli_sql' else [
        row['query'] for row in preflight['records']
        if row['role'] == role and row['status'] == 'prepared']) for role in ROLES}
    assert all(selected[role] == list(range(1, 44)) for role in ROLES), 'all five surfaces must prepare every query before execution'
    helper_paths = [Path(__file__), ROOT / 'query_paths.py', ROOT / 'preflight.py',
                    ROOT / 'adapter_selftest.py', ROOT / 'freeze_build.py', ROOT / 'run_pairs.py',
                    ROOT / 'fixture_check.py', FIXTURE, ROOT / 'fixture-release/oracle.json',
                    ROOT / 'preflight-final.json', ROOT / 'adapter-selftest.json',
                    PAIRS_PLAN, PAIRS_RECEIPT,
                    *(ROOT / f'{name}.json' for name in PAIR_NAMES),
                    *(ROOT / role for role in ROLES if role != 'cli_sql')]
    helpers = [identity(path) for path in helper_paths]
    storage_before = storage_snapshot()
    workload = guards.WorkloadGuard()
    workload.check()
    plan = dict(schema='shardloom.sequential_query_surface_comparison.v1', status='predeclared',
        source_commit=source_commit, source_worktree=worktree,
        source_manifest_sha256=hashlib.sha256(json.dumps(
            {**build['source_after'], **build['runtime_python_sources']},
            sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
        build=identity(BUILD), artifacts=artifacts,
        focused_pairs=dict(plan=identity(PAIRS_PLAN), receipt=identity(PAIRS_RECEIPT)),
        independent_small_fixture=identity(FIXTURE),
        matched_cli_and_library_build=True, sources_verified=len(build['source_after']),
        input=input_identity, input_generation=input_generation, reference=reference_identity,
        helpers=helpers, supervisor=identity(SUPERVISOR), workload_guard=identity(GUARD),
        role_order=list(ROLES), selected_query_ids=selected,
        unsupported_preflight=[row for row in preflight['records'] if row['status'] != 'prepared'],
        resources=dict(memory_gb=24, max_parallelism=12, query_deadline_seconds=120,
                       native_deadline_seconds=115, per_role_deadline_seconds=900),
        executions_per_query_per_role=1, repeat_failed_queries=False,
        stop_role_on_first_execution_failure=True,
        interpretation='Each role is one observation, not a statistical speedup claim. Every role must prepare all 43 queries before any pass begins. Only a fully validated 43-query role has a Full43 total. A failed role retains its validated prefix and failure; later roles start only after process cleanup. Sequential order and uncontrolled OS cache state are recorded.',
        adapter_boundary='Standard unmodified UAT runner invokes a small adapter for each embedded role. SQL identifies canonical fixture IDs only; DataFrame and native-expression roles construct their own declared plans. Native row export occurs after the engine clock. The adapter mirrors typed output fields for the standard CLI result validator; it performs no evaluation.',
        input_hashing='Full input hash before and after the complete sequential cohort, outside queries.',
        preflight_source_note='The updated public declarations are checked against an independent small-fixture reference before real-input preparation. The adapter also checks five native deliveries and rejects corrupted evidence. No real-input query executes during preparation.',
        no_parallel_task_work=True, no_profiling=True, no_cache_manipulation=True,
        no_artificial_pacing=True, storage_before=storage_before,
        host=dict(platform=platform.platform(), logical_cpus=os.cpu_count()))
    save(plan_path, plan)
    record = dict(schema=plan['schema'], status='running', plan=identity(plan_path), roles=[])
    lock = ROOT / '.full43.lock'
    lock.mkdir()
    try:
        for role in ROLES:
            workload.check()
            run_root = ROOT / 'runs' / role
            assert not run_root.exists()
            executable = binary if role == 'cli_sql' else ROOT / role
            command = [PYTHON, '-B', 'scripts/run_clickbench_query_uat.py',
                '--binary', str(executable), '--input', str(INPUT), '--uat-root', str(run_root),
                '--reference-packet', str(REFERENCE), '--build-commit', source_commit,
                '--memory-gb', '24', '--max-parallelism', '12', '--repeats', '1', '--compress-logs',
                '--max-log-mib', '1024', '--max-run-log-mib', '256']
            observation = dict(role=role, selected_query_ids=selected[role], command=command,
                               status='running', host_samples=[])
            record['roles'].append(observation)
            last_sample = 0.0

            def guard():
                nonlocal last_sample
                workload.check(observation.get('pid'))
                if time.monotonic() - last_sample < 2:
                    return
                output = subprocess.check_output(['ps', '-axo', 'pid=,ppid=,pgid=,pcpu=,rss=,comm='], text=True, timeout=10)
                samples = []
                for line in output.splitlines():
                    fields = line.strip().split(None, 5)
                    if len(fields) == 6 and (int(fields[0]) in workload.owned or float(fields[3]) >= 1):
                        samples.append(dict(pid=int(fields[0]), parent=int(fields[1]), group=int(fields[2]),
                            cpu_percent=float(fields[3]), rss_bytes=int(fields[4]) * 1024,
                            executable=Path(fields[5]).name))
                observation['host_samples'].append(dict(load_average=list(os.getloadavg()), processes=samples))
                last_sample = time.monotonic()

            log = ROOT / (role + '-full43.log')
            print(f'Starting {role}: one execution of each of {len(selected[role])} prepared queries.', flush=True)
            with log.open('xb') as stream:
                code = bounded.run(command, cwd=W, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1',
                    PYTHONPATH=str(PYTHON_SITE) + ':' + str(W / 'python/src') + ':' + str(W / 'scripts')),
                    output=stream, timeout=900, evidence=observation, guard=guard, max_output_bytes=8 << 20)
            assert observation['process_group_drained'] and observation['direct_child_reaped']
            assert not (run_root / '.ingest-uat.lock').exists()
            summaries = list(run_root.glob('logs/*/summary.json'))
            assert len(summaries) == 1
            summary = read(summaries[0])
            calls = summary['records']
            assert [(row['query'], row['run']) for row in calls] == [(q, 1) for q in selected[role][:len(calls)]]
            passed = []
            for row in calls:
                if not row['passed']:
                    continue
                assert row['returncode'] == 0 and row['validation'] == 'complete_values'
                assert row['engine_timing_reported'] and math.isfinite(row['engine_execution_seconds'])
                assert row['engine_execution_seconds'] >= 0
                output = summaries[0].parent / f"q{row['query']:02d}_run1.stdout.json.gz"
                envelope = strict_json(gzip.decompress(output.read_bytes()).decode())
                values = extract_result(envelope)
                assert equivalent(values, expected['values'][row['query']])
                fields = report_fields(envelope)
                if row['query'] in (28, 29):
                    assert fields.get('local_primitive_report_present') == 'true', 'grouped ordering missed the shared aggregate provider'
                if role == 'native_expression' and row['query'] == 20:
                    assert int(fields['relational_scan_rows_delivered']) == len(values), 'typed predicate missed native scan pushdown'
                schema = strict_json(fields['result_schema_json'])
                passed.append(dict(query=row['query'], engine_execution_seconds=row['engine_execution_seconds'],
                                   result_rows=len(values), complete_values=True, result_schema=schema))
            complete = code == 0 and summary['complete'] and len(passed) == len(selected[role])
            if complete:
                assert summary['completed_identity_check'] and summary['reference_packet_identity_verified']
                assert summary['harness_identity_verified']
            full = complete and selected[role] == list(range(1, 44))
            if full:
                assert summary['full_result_validation'] and sum(row['result_rows'] for row in passed) == 381
            observation.update(status='passed' if complete else 'failed', summary=identity(summaries[0]),
                log=identity(log), passed_queries=passed, attempted_query_count=len(calls),
                full43_complete=full, full43_engine_seconds=sum(row['engine_execution_seconds'] for row in passed) if full else None,
                failures=[row for row in calls if not row['passed']], uat_lock_released=True)
            save(ROOT / (role + '-full43-receipt.json'), observation)
            print(json.dumps(dict(role=role, status=observation['status'], passed=len(passed), attempted=len(calls),
                                  full43_engine_seconds=observation['full43_engine_seconds'])), flush=True)
            workload.check()
            assert generation(INPUT) == input_generation
        print('All query attempts finished; checking frozen identities and complete result evidence.', flush=True)
        verify_sources()
        final_worktree = working_tree_identity()
        assert final_worktree == worktree
        assert identity(INPUT) == input_identity and generation(INPUT) == input_generation
        assert identity(REFERENCE) == reference_identity
        assert [identity(path) for path in helper_paths] == helpers
        assert identity(BUILD) == plan['build']
        record.update(status='passed' if all(role['full43_complete'] for role in record['roles']) else 'completed_with_failures',
                      source_unchanged=True, source_worktree_before=worktree,
                      source_worktree_after=final_worktree,
                      input_full_hash_verified_before_and_after=True, storage_after=storage_snapshot())
        common = sorted(set.intersection(*[set(row['query'] for row in role['passed_queries']) for role in record['roles']]))
        record['common_validated_query_ids'] = common
        for query in common:
            schemas = [next(row['result_schema'] for row in role['passed_queries'] if row['query'] == query)
                       for role in record['roles']]
            assert all(schema == schemas[0] for schema in schemas), f'cross-surface full-input schema mismatch at query {query}'
        record['common_query_schemas_match'] = True
        record['common_subset_engine_seconds'] = {
            role['role']: sum(row['engine_execution_seconds'] for row in role['passed_queries'] if row['query'] in common)
            for role in record['roles']}
    except BaseException as error:
        record.update(status='failed', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        lock.rmdir()
        record['cohort_lock_released'] = True
        save(receipt_path, record)
    print(json.dumps(dict(status=record['status'], roles=len(record['roles']), receipt=str(receipt_path))), flush=True)


if __name__ == '__main__':
    main()

