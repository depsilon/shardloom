"""Preserve every parity cohort and final Full43 with exact byte readback."""
from __future__ import annotations

import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import tempfile

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
N = Path('/Users/dylan/LocalData/shardloom/native-surface-parity-20261024')
R = W / 'docs/benchmarks/evidence/native-surface-parity-2026-10-24'
BASE = '16ff752d94b399eebc02645d38e58ddbd7ce840a'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def identity(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=sha(raw))


entries = {}
omitted = {}
missing = {}


def add(ref, raw=None, origin='local_file'):
    path = Path(ref['path'])
    raw = path.read_bytes() if raw is None else raw
    assert sha(raw) == ref['sha256'], ('evidence changed', path)
    assert 'bytes' not in ref or len(raw) == ref['bytes'], ('evidence size', path)
    entries[(str(path), sha(raw))] = dict(raw=raw, origin=origin)


def payload(path):
    named = (path.suffix in {'.vortex', '.parquet', '.so', '.dylib', '.whl'}
            or path.name == 'shardloom' or 'site-packages' in path.parts
            or 'duckdb-reference-env' in path.parts or not path.is_absolute())
    if named:
        return True
    if path.is_file():
        with path.open('rb') as source:
            magic = source.read(4)
        return magic in {b'\x7fELF', b'\xfe\xed\xfa\xce', b'\xce\xfa\xed\xfe',
                         b'\xfe\xed\xfa\xcf', b'\xcf\xfa\xed\xfe', b'\xca\xfe\xba\xbe'}
    return False


def resolve(ref):
    key = ref['path'], ref['sha256']
    if key in entries or key in omitted or key in missing:
        return
    path = Path(ref['path'])
    if payload(path):
        omitted[key] = ref
        return
    if path.is_file() and not path.is_symlink():
        raw = path.read_bytes()
        if sha(raw) == ref['sha256']:
            add(ref, raw)
            return
    if path.is_relative_to(W):
        rel = path.relative_to(W).as_posix()
        raw = subprocess.run(['git', 'show', f'{BASE}:{rel}'], cwd=W, capture_output=True).stdout
        if sha(raw) == ref['sha256']:
            add(ref, raw, origin={'git_commit': BASE, 'path': rel})
            return
        # Each frozen source patch is a complete diff from BASE, including new files.
        for patch in sorted(N.glob('*source.patch')):
            with tempfile.TemporaryDirectory(prefix='parity-history-', dir=N) as temp:
                target = Path(temp) / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                if raw:
                    target.write_bytes(raw)
                completed = subprocess.run(['git', 'apply', '--include=' + rel, str(patch)],
                                           cwd=temp, capture_output=True)
                if completed.returncode == 0 and target.is_file():
                    historical = target.read_bytes()
                    if sha(historical) == ref['sha256']:
                        add(ref, historical, origin={'base_commit': BASE, 'source_patch': identity(patch), 'path': rel})
                        return
    # Full43's finite progression edit followed the focused plan freeze. The
    # prior round contains the identical pre-decision helper with its round path.
    if path == N / 'surfaces-r5/run_comparison.py':
        previous = (N / 'surfaces-r4/run_comparison.py').read_bytes()
        for historical in [previous.replace(b'surfaces-r4', b'surfaces-r5'), previous]:
            if sha(historical) == ref['sha256']:
                add(ref, historical, origin={'exact_reconstruction_from': identity(N / 'surfaces-r4/run_comparison.py')})
                return
    missing[key] = ref


def references(value):
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and isinstance(value.get('sha256'), str):
            yield value
        for nested in value.values():
            yield from references(nested)
    elif isinstance(value, list):
        for nested in value:
            yield from references(nested)


inventory = read(N / 'parity-packet-file-inventory.json')
for ref in inventory['files']:
    assert not payload(Path(ref['path'])), ref['path']
    add(ref)
for name in ['parity-pr-runner-tests', 'parity-pr-user-reference', 'parity-pr-contribution']:
    for ext in ('.json', '.log'):
        add(identity(N / (name + ext)))
for name in ['parity-packet-file-inventory.json', 'package_parity.py']:
    add(identity(N / name))

processed = set()
# Recover only exact recorded identities from previously accepted evidence.
# Their transitive historical cohorts remain in the linked original packets.
historical = read(N / 'parity-packet-reference-inventory.json')['external_missing_identity_resolution']['verified_targets']
archive_cache = {}
for item in historical:
    if item['resolution'] == 'verified_historical_git_blob':
        raw = subprocess.check_output(['git', 'show', f"{item['commit']}:{item['repo_relative_path']}"], cwd=W)
    else:
        archive_path = Path(item['archive'])
        if str(archive_path) not in archive_cache:
            packed = archive_path.read_bytes()
            assert sha(packed) == item['archive_sha256'], archive_path
            with tarfile.open(fileobj=io.BytesIO(packed), mode='r:xz') as archive:
                archive_cache[str(archive_path)] = {member.name: archive.extractfile(member).read()
                    for member in archive.getmembers() if member.isfile()}
        assert sha(Path(item['index']['path']).read_bytes()) == item['index']['sha256']
        raw = archive_cache[str(archive_path)][item['member']]
    ref = dict(path=item['expected_path'], sha256=item['sha256'], bytes=item['bytes'])
    add(ref, raw, origin=item)
    processed.add((ref['path'], ref['sha256']))
assert len(historical) == 34
while True:
    pending = [(key, entry) for key, entry in entries.items() if key not in processed]
    if not pending:
        break
    for key, entry in pending:
        processed.add(key)
        if key[0].endswith('.json'):
            try:
                obj = json.loads(entry['raw'])
            except (ValueError, UnicodeDecodeError):
                continue
            for ref in references(obj):
                resolve(ref)

# Runtime helper maps store path-to-digest entries rather than reference objects.
for key, entry in list(entries.items()):
    if key[0].endswith('/summary.json'):
        summary = json.loads(entry['raw'])
        for path, digest in summary.get('harness_sha256', {}).items():
            resolve(dict(path=path, sha256=digest))

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

save(N / 'parity-packaging-unresolved.json', dict(missing=list(missing.values()), omitted=list(omitted.values())))
assert not missing, f'{len(missing)} unresolved identities; inspect parity-packaging-unresolved.json'

S = N / 'surfaces-r5'
full = read(S / 'full43-receipt.json')
plan = read(S / 'full43-plan.json')
assert full['status'] == 'passed' and full['paired_timing_screen_passed'] is False
gate_names = ['parity-r4-workspace-native-tests', 'parity-r4-workspace-native-lint-reviewed',
              'parity-r5-format-corrected', 'parity-r5-native-cli-lint-corrected',
              'parity-r5-native-cli-tests', 'parity-r5-default-lint', 'parity-r5-default-tests',
              'parity-r5-matched-release-build', 'parity-r5-public-provider-tests',
              'parity-r5-small-fixtures', 'parity-r5-preparation-preflight', 'parity-r5-adapter-selftest',
              'parity-r5-scope-execution', 'parity-pr-runner-tests', 'parity-pr-user-reference', 'parity-pr-contribution']
outputs = {}
for role in full['roles']:
    folder = Path(role['summary']['path']).parent
    outputs[role['role']] = [identity(folder / f'q{q:02d}_run1.stdout.json.gz') for q in range(1, 44)]
for evidence in read(S / 'paired-attribution-decision.json')['source_evidence']:
    resolve(evidence['file'])
assert not missing

files = []
for index, ((path, digest), entry) in enumerate(sorted(entries.items())):
    files.append(dict(path=path, sha256=digest, bytes=len(entry['raw']),
                      member=f'files/{index:04d}-{Path(path).name}', origin=entry['origin']))
raw_bytes = sum(row['bytes'] for row in files)
save(N / 'parity-package-selection.json', dict(files=len(files), bytes=raw_bytes,
    largest=sorted(files, key=lambda row: row['bytes'], reverse=True)[:20],
    outside_current_campaign=[row for row in files if not Path(row['path']).is_relative_to(N)]))
assert raw_bytes <= 192 * (1 << 20), raw_bytes
archive_path = R / 'evidence.tar.xz'
with tempfile.NamedTemporaryFile(prefix='parity-evidence-', suffix='.tar.xz', dir=N, delete=False) as output:
    temporary = Path(output.name)
    with tarfile.open(fileobj=output, mode='w:xz', preset=6) as archive:
        for row in files:
            item = tarfile.TarInfo(row['member'])
            item.size, item.mtime, item.mode = row['bytes'], 0, 0o644
            archive.addfile(item, io.BytesIO(entries[(row['path'], row['sha256'])]['raw']))
with tarfile.open(temporary, 'r:xz') as archive:
    assert archive.getnames() == [r['member'] for r in files]
    for row in files:
        assert archive.extractfile(row['member']).read() == entries[(row['path'], row['sha256'])]['raw']
assert not archive_path.exists(), 'do not overwrite an accepted packet'
temporary.rename(archive_path)
manifest = dict(schema='shardloom.native_surface_parity.packet.v1',
    source_base_commit=BASE, source_patch=identity(N / 'fifth-correction-source.patch'),
    archive=archive_path.name, archive_bytes=archive_path.stat().st_size, archive_sha256=sha(archive_path.read_bytes()),
    verifier_sha256=sha((R / 'verify_packet.py').read_bytes()), complete_byte_readback=True,
    files=files, uncompressed_bytes=raw_bytes, build=plan['build'], reference=plan['reference'],
    queries=read(S / 'pairs-plan.json')['queries'], fixture=plan['independent_small_fixture'],
    preflight=identity(S / 'preflight-final.json'), adapter_selftest=identity(S / 'adapter-selftest.json'),
    gates=[dict(receipt=identity(N / (name + '.json')), log=identity(N / (name + '.log'))) for name in gate_names],
    native_runtime_gate=identity(N / 'parity-r4-workspace-native-tests.json'),
    native_runtime_scope_difference=read(N / 'round5-validation-scope.json')['changed_rust_or_cargo'],
    paired_cohorts=[dict(id=name, plan=identity(N / name / 'pairs-plan.json'), receipt=identity(N / name / 'pairs-receipt.json'))
                    for name in ['surfaces', 'surfaces-r3', 'surfaces-r4', 'surfaces-r5']],
    attribution=identity(S / 'paired-attribution-decision.json'), full43_plan=identity(S / 'full43-plan.json'),
    full43_receipt=identity(S / 'full43-receipt.json'), full43_outputs=outputs,
    omitted_payload_identities=list(omitted.values()),
    omission_reason='Bulk inputs, generated fixture data and executables are regenerable. Exact identities, source patches, build receipts, validation, every result and failed observation are retained.')
save(R / 'manifest.json', manifest)
save(N / 'parity-packaging-receipt.json', dict(status='passed', manifest=identity(R / 'manifest.json'),
    archive=identity(archive_path), verifier=identity(R / 'verify_packet.py'), files=len(files),
    uncompressed_bytes=raw_bytes, complete_byte_readback=True))
print(json.dumps(dict(status='passed', files=len(files), archive_bytes=archive_path.stat().st_size,
                      uncompressed_bytes=raw_bytes)))
