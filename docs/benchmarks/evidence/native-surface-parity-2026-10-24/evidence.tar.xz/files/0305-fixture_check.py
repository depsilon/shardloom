"""Small deterministic five-surface correctness fixture, never a performance run."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch

import query_paths as paths
from query_paths import ROOT, W, N
from clickbench_reference_packet import query_statements
from native_workflow_protocol import extract_result, public_workflow_command, report_fields
from run_clickbench_query_uat import equivalent


def identity(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return dict(path=str(path), sha256=h.hexdigest(), bytes=Path(path).stat().st_size)


def source_table():
    import pyarrow as pa
    count = 256
    columns = {
        'WatchID': (pa.uint64(), lambda i: i % 37),
        'AdvEngineID': (pa.uint8(), lambda i: i % 4),
        'ResolutionWidth': (pa.uint16(), lambda i: 800 + i % 9),
        'UserID': (pa.uint64(), lambda i: [435090932899640449, 2**63 + 1, 17, 19, 23][i % 5]),
        'SearchPhrase': (pa.string(), lambda i: ['', 'α', 'search', '港', 'google'][i % 5]),
        'EventDate': (pa.uint16(), lambda i: 15900 + i % 4),
        'RegionID': (pa.uint32(), lambda i: i % 11),
        'MobilePhoneModel': (pa.string(), lambda i: ['', 'phone-a', 'phone-β'][i % 3]),
        'MobilePhone': (pa.uint8(), lambda i: i % 2),
        'SearchEngineID': (pa.uint8(), lambda i: i % 3),
        'EventTime': (pa.uint32(), lambda i: 1373760000 + i * 61),
        'URL': (pa.string(), lambda i: ['', 'https://www.google.test/a', 'https://other.test/α', 'https://x.google.test/q'][i % 4]),
        'Title': (pa.string(), lambda i: ['', 'Google title', 'Other', 'Google α'][i % 4]),
        'CounterID': (pa.uint32(), lambda i: 62 if i % 5 else 7),
        'Referer': (pa.string(), lambda i: ['', 'https://www.example.test/α', 'http://other.test/path', 'plain'][i % 4]),
        'ClientIP': (pa.uint32(), lambda i: [0, 1, 2, 3, 17, 2**32 - 1][i % 6]),
        'IsRefresh': (pa.uint8(), lambda i: int(i % 17 == 0)),
        'TraficSourceID': (pa.int8(), lambda i: [-1, 6, 1][i % 3]),
        'URLHash': (pa.uint64(), lambda i: 2868770270353813622 if i % 3 else i),
        'RefererHash': (pa.uint64(), lambda i: 3594120000172545465),
        'WindowClientWidth': (pa.uint16(), lambda i: 800 + i % 31),
        'WindowClientHeight': (pa.uint16(), lambda i: 600 + i % 31),
        'DontCountHits': (pa.uint8(), lambda i: int(i % 19 == 0)),
        'IsLink': (pa.uint8(), lambda i: i % 2),
        'IsDownload': (pa.uint8(), lambda i: int(i % 23 == 0)),
    }
    schema = pa.schema([pa.field(name, dtype, nullable=False) for name, (dtype, _) in columns.items()])
    return pa.Table.from_arrays([pa.array([value(i) for i in range(count)], type=dtype)
                                for dtype, value in columns.values()], schema=schema)


def main(label):
    import pyarrow.parquet as pq
    import shardloom as sl
    artifacts = Path(os.environ.get('SHARDLOOM_FIXTURE_ARTIFACTS', ROOT / 'artifacts'))
    paths.LIBRARY = artifacts / '_native.abi3.so'
    native = paths.load_native()
    directory = ROOT / label
    directory.mkdir(exist_ok=False)
    table = source_table()
    parquet = directory / 'fixture.parquet'
    vortex = directory / 'fixture.vortex'
    pq.write_table(table, parquet)
    session = native.Session(native.ExecutionResources(256 << 20, 2))
    try:
        source = session.from_arrow(table)
        session.plan(native.Relation.scan('memory://fixture'), sources=[('memory://fixture', source)]).write(vortex, 'write_vortex')
    finally:
        session.close()
    oracle = '''
import json,sys,duckdb
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from clickbench_independent_reference import query_plan,execute_plan,ORDINAL
c=duckdb.connect()
c.execute('SET threads=1')
c.execute('CREATE TABLE hits AS SELECT *, row_number() OVER () - 1 AS '+ORDINAL+' FROM read_parquet(?)',[sys.argv[2]])
rows=[execute_plan(c,p) for p in query_plan(Path(sys.argv[3]))]
print(json.dumps(dict(oracle_only=True,engine='DuckDB',version=duckdb.__version__,records=rows),allow_nan=False))
'''
    process = subprocess.run([str(N / 'duckdb-reference-env/bin/python'), '-I', '-c', oracle,
                              str(W / 'scripts'), str(parquet), str(W / 'benchmarks/clickbench/queries.sql')],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60, check=False)
    (directory / 'oracle.stderr').write_bytes(process.stderr)
    (directory / 'oracle.json').write_bytes(process.stdout)
    if process.returncode:
        raise RuntimeError(process.stderr.decode())
    reference = json.loads(process.stdout)['records']
    statements = paths.submitted_statements()
    observations = []
    for role in ('cli_sql', 'embedded_workflow', 'python_sql', 'dataframe', 'native_expression'):
        session = native.Session(native.ExecutionResources(256 << 20, 2))
        client = sl.ShardLoomClient(transport='native', memory_bytes=256 << 20, max_parallelism=2)
        try:
            for query, sql in enumerate(statements, 1):
                record = dict(role=role, query=query, status='started')
                try:
                    if role == 'cli_sql':
                        command = public_workflow_command(artifacts / 'shardloom', sql, input_path=vortex,
                                                          input_format='vortex', memory_gb=1, max_parallelism=2)
                        result = subprocess.run(command, capture_output=True, timeout=30, check=False)
                        if result.returncode:
                            raise RuntimeError(result.stderr.decode() + result.stdout.decode())
                        envelope = json.loads(result.stdout)
                    else:
                        with patch('subprocess.Popen', side_effect=AssertionError('native path launched a process')):
                            if role == 'embedded_workflow':
                                args = public_workflow_command('unused', sql, input_path=vortex,
                                    input_format='vortex', memory_gb=1, max_parallelism=2)[2:]
                                at = args.index('--format')
                                del args[at:at+2]
                                result = session.workflow(args).collect()
                            elif role == 'native_expression':
                                result = session.plan(paths.native_expression(query, str(vortex))).collect()
                            else:
                                flow = (sl.sql(paths.bind_sql_source(sql, str(vortex)), client=client)
                                        if role == 'python_sql' else paths.dataframe(query, str(vortex), client))
                                result = flow.collect(check=True)
                            envelope = paths.result_envelope(result, role, query, 'small fixture declaration')
                    actual = extract_result(envelope)
                    fields = report_fields(envelope)
                    expected = reference[query-1]['values']
                    record.update(actual=actual, expected=expected,
                                  schema=fields.get('result_schema_json'),
                                  evidence={key: value for key,value in fields.items() if
                                            key in ('fallback_attempted','external_engine_invoked',
                                                'local_primitive_report_present','local_primitive_mode',
                                                'local_primitive_native_io_certificate_path_id',
                                                'local_primitive_aggregate_update_strategy',
                                                'relational_scan_rows_delivered')})
                    assert equivalent(actual, expected), f'complete value mismatch: {actual!r} != {expected!r}'
                    if query in (28, 29):
                        assert fields.get('local_primitive_report_present') == 'true', 'grouped ordering did not select the shared aggregate provider'
                    if role == 'native_expression' and query == 20:
                        assert int(fields['relational_scan_rows_delivered']) == len(actual), 'typed filter did not reach the native scan'
                    record['status'] = 'passed'
                except Exception as error:
                    record.update(status='failed', error_type=type(error).__name__, error=str(error))
                observations.append(record)
                print(json.dumps({key:value for key,value in record.items() if key in ('role','query','status','error_type','error')}), flush=True)
        finally:
            client.close()
            session.close()
    report = dict(status='passed' if all(row['status']=='passed' for row in observations) else 'failed',
                  fixture_rows=table.num_rows, real_dataset_queries_executed=0, oracle_only=True,
                  input=[identity(parquet),identity(vortex)], library=identity(paths.LIBRARY),
                  binary=identity(artifacts / 'shardloom'), declarations=identity(ROOT / 'query_paths.py'),
                  observations=observations)
    (directory / 'report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    raise SystemExit(0 if report['status']=='passed' else 1)


if __name__=='__main__':
    main(sys.argv[1])

