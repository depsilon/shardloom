"""Run the predeclared focused parity comparisons with the standard paired UAT runner."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

from query_paths import N, ROOT, W
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

PYTHON = '/opt/homebrew/opt/python@3.13/bin/python3.13'
PYTHON_SITE = N / 'duckdb-reference-env/lib/python3.13/site-packages'
INPUT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat/vortex/fresh-roadmap-663-a1.vortex')
REFERENCE = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022/independent-full43-948/reference.json')
QUERIES = W / 'benchmarks/clickbench/queries.sql'
ACCEPTED_CLI = Path('/Users/dylan/LocalData/shardloom/native-grouped-preparation-20261024/shardloom-g2')
ACCEPTED_CLI_SHA256 = 'c403e17a8cabdceefe0e98627a2c4816dcf5d02b70652b813afa43f69ee43371'
ACCEPTED_CLI_BYTES = 76_720_096
ACCEPTED_CLI_COMMIT = '911923c17e3cb6d304c7f05e2c65a1ac98faa714'
BUILD = ROOT / 'artifacts/build-summary.json'
FIXTURE = ROOT / 'fixture-release/report.json'
PREFLIGHT = ROOT / 'preflight-final.json'
SELFTEST = ROOT / 'adapter-selftest.json'
FOCUSED_QUERIES = (1, 17, 19, 20, 23, 28, 29, 34, 35)
REPEATS = 3
ROLES = ('cli_sql', 'embedded_workflow', 'python_sql', 'dataframe', 'native_expression')
COMPARISONS = (
    ('embedded_workflow_vs_python_sql', 'embedded_workflow', 'python_sql'),
    ('embedded_workflow_vs_dataframe', 'embedded_workflow', 'dataframe'),
    ('embedded_workflow_vs_native_expression', 'embedded_workflow', 'native_expression'),
    ('cli_sql_vs_embedded_workflow', 'cli_sql', 'embedded_workflow'),
    ('accepted_cli_vs_candidate_cli', 'accepted_cli', 'cli_sql'),
)
SUPERVISOR = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
GUARD = Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/native_workload_guard_816.py')


def identity(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def git_bytes(*args):
    return subprocess.check_output(['git', *args], cwd=W)


def worktree_identity():
    return dict(
        head_commit=git_bytes('rev-parse', 'HEAD').decode().strip(),
        head_tree=git_bytes('rev-parse', 'HEAD^{tree}').decode().strip(),
        status_porcelain=git_bytes('status', '--porcelain', '--untracked-files=all').decode(),
        diff_sha256=hashlib.sha256(git_bytes('diff', '--binary', 'HEAD')).hexdigest(),
    )


def source_manifest(build):
    return {**build['source_after'], **build['runtime_python_sources']}


def verify_sources(build, worktree):
    current = worktree_identity()
    if current != worktree:
        raise ValueError('worktree head, status or git diff changed during the cohort')
    expected = source_manifest(build)
    for relative, digest in expected.items():
        if identity(W / relative)['sha256'] != digest:
            raise ValueError(f'frozen source changed: {relative}')
    python_paths = {str(path.relative_to(W)) for path in (W / 'python/src').rglob('*.py')}
    if python_paths != set(build['runtime_python_sources']):
        raise ValueError('Python source inventory changed after build')


def role_binary(role, candidate_cli):
    if role == 'accepted_cli':
        return ACCEPTED_CLI
    if role == 'cli_sql':
        return candidate_cli
    if role in ('embedded_workflow', 'python_sql', 'dataframe', 'native_expression'):
        return ROOT / role
    raise ValueError(f'unknown role {role}')


def expected_order(query, run):
    return ('control', 'candidate') if (query + run) % 2 == 0 else ('candidate', 'control')


def ordered_calls():
    calls = []
    for query in FOCUSED_QUERIES:
        for run in range(1, REPEATS + 1):
            for position, role in enumerate(expected_order(query, run), 1):
                calls.append((query, run, role, position))
    return calls


def tolerance_screen(summary, *, frontend_parity):
    scores = summary.get('scores', {})
    per_query = scores.get('per_query') or []
    rows = []
    for item in per_query:
        medians = item['median_seconds']
        control = medians['control']
        candidate = medians['candidate']
        allowance = max((min(control, candidate) if frontend_parity else control) * 0.10, 0.0001)
        difference = abs(candidate - control) if frontend_parity else candidate - control
        rows.append(dict(
            query=item['query'], control_median_seconds=control,
            candidate_median_seconds=candidate,
            candidate_minus_control_seconds=candidate - control,
            allowance_seconds=allowance,
            within_control_allowance=difference <= allowance,
        ))
    available = scores.get('timing_available') is True and len(rows) == len(FOCUSED_QUERIES)
    return dict(
        available=available,
        rule=('absolute median difference <= max(10% of faster median, 100 microseconds)'
              if frontend_parity else 'candidate median <= control median + max(10% of control median, 100 microseconds)'),
        per_query=rows,
        all_within_allowance=available and all(row['within_control_allowance'] for row in rows),
    )


def storage_snapshot():
    return check_budgets(
        N, INPUT, ROOT / 'paired-runs', min_free_bytes=12 * GIB,
        reserve_bytes=128 * MIB, max_workspace_bytes=100 * GIB,
        max_log_bytes=1024 * MIB, max_run_log_bytes=256 * MIB,
    )


def main():
    if not __debug__:
        raise RuntimeError('optimized Python is unsupported')
    if tuple(FOCUSED_QUERIES) != (1, 17, 19, 20, 23, 28, 29, 34, 35):
        raise ValueError('focused query declaration changed')
    if REPEATS != 3 or len(ordered_calls()) != len(FOCUSED_QUERIES) * REPEATS * 2:
        raise ValueError('paired cohort must contain exactly three pairs per selected query')

    plan_path = ROOT / 'pairs-plan.json'
    receipt_path = ROOT / 'pairs-receipt.json'
    lock = ROOT / '.pairs.lock'
    if plan_path.exists() or receipt_path.exists() or lock.exists():
        raise FileExistsError('preserving prior pair cohort state')

    require_local_path(N, Path.home(), sys.platform)
    require_local_path(INPUT, Path.home(), sys.platform)
    accepted = identity(ACCEPTED_CLI)
    if accepted['sha256'] != ACCEPTED_CLI_SHA256 or accepted['bytes'] != ACCEPTED_CLI_BYTES:
        raise ValueError('accepted CLI artifact identity differs from the frozen G2 binary')
    reference = identity(REFERENCE)
    if reference['sha256'] != 'fc5780da415dc33bd06ed0879db07fc040db5dd419e3c37ecde7cd40a315696b':
        raise ValueError('independent reference packet differs from its frozen identity')
    input_identity = identity(INPUT)
    if input_identity['sha256'] != '06f70eb6f118d11e4a5226eb641225d708fdb4ac1b3f45942872d5ef5df4fc22':
        raise ValueError('input differs from its frozen identity')
    input_generation = dict(
        device=INPUT.stat().st_dev, inode=INPUT.stat().st_ino,
        size_bytes=INPUT.stat().st_size, mtime_ns=INPUT.stat().st_mtime_ns,
        ctime_ns=INPUT.stat().st_ctime_ns,
    )

    build = read(BUILD)
    if build.get('status') != 'passed' or build.get('package_feature_union') != 'release-user-surfaces':
        raise ValueError('candidate build is not the matched release-user-surfaces build')
    candidate_cli = Path(build['artifacts']['cli']['path']).resolve()
    candidate_library = Path(build['artifacts']['library']['path']).resolve()
    if candidate_cli != (ROOT / 'artifacts/shardloom').resolve():
        raise ValueError('candidate CLI is outside the matched artifacts directory')
    if candidate_library != (ROOT / 'artifacts/_native.abi3.so').resolve():
        raise ValueError('candidate native extension is outside the matched artifacts directory')
    binaries = {role: identity(role_binary(role, candidate_cli))
                for role in ('cli_sql', 'embedded_workflow', 'python_sql',
                             'dataframe', 'native_expression')}
    binaries['accepted_cli'] = accepted
    binaries['candidate_cli'] = identity(candidate_cli)
    binaries['candidate_library'] = identity(candidate_library)
    for role in ('embedded_workflow', 'python_sql', 'dataframe', 'native_expression'):
        binaries[role] = identity(ROOT / role)
    if binaries['candidate_cli'] != build['artifacts']['cli']:
        raise ValueError('candidate CLI identity differs from the build receipt')
    if binaries['candidate_library'] != build['artifacts']['library']:
        raise ValueError('candidate native extension identity differs from the build receipt')

    fixture = read(FIXTURE)
    if fixture.get('status') != 'passed' or fixture.get('real_dataset_queries_executed') != 0:
        raise ValueError('five-surface fixture conformance is not complete')
    if fixture.get('binary') != build['artifacts']['cli'] or fixture.get('library') != build['artifacts']['library']:
        raise ValueError('fixture did not use the matched candidate artifacts')
    if len(fixture.get('observations', [])) != 43 * len(ROLES):
        raise ValueError('fixture did not validate all 43 declarations on all five surfaces')
    if any(row.get('status') != 'passed' for row in fixture['observations']):
        raise ValueError('fixture has an unpassed surface observation')
    for role in ROLES:
        if [row['query'] for row in fixture['observations'] if row['role'] == role] != list(range(1, 44)):
            raise ValueError(f'fixture declaration coverage is incomplete for {role}')
    for query in range(1, 44):
        schemas = [json.loads(row['schema']) for row in fixture['observations'] if row['query'] == query]
        if not schemas or any(schema != schemas[0] for schema in schemas):
            raise ValueError(f'cross-surface fixture schema mismatch at query {query}')
    preflight = read(PREFLIGHT)
    if preflight.get('native_queries_executed') != 0 or any(row.get('engine_executed') is not False for row in preflight.get('records', [])):
        raise ValueError('preflight performed execution or has malformed records')
    for role in ROLES[1:]:
        selected = [row['query'] for row in preflight['records']
                    if row.get('role') == role and row.get('status') == 'prepared']
        if selected != list(range(1, 44)):
            raise ValueError(f'preflight did not prepare all 43 declarations for {role}')
    if not read(SELFTEST).get('status') == 'passed':
        raise ValueError('adapter selftest has not passed')

    worktree = worktree_identity()
    verify_sources(build, worktree)
    accepted_plan = read(ACCEPTED_CLI.parent / 'final-full43-plan.json')
    accepted_receipt = read(ACCEPTED_CLI.parent / 'final-full43-receipt.json')
    if accepted_plan.get('status') != 'predeclared' or accepted_receipt.get('status') != 'passed':
        raise ValueError('accepted G2 Full43 plan and receipt are not complete')
    if accepted_plan.get('binary') != accepted or accepted_plan.get('source_commit') != ACCEPTED_CLI_COMMIT:
        raise ValueError('accepted G2 evidence does not identify the frozen CLI/source')

    helper_paths = [Path(__file__), ROOT / 'run_comparison.py', ROOT / 'preflight.py',
                    ROOT / 'adapter_selftest.py', ROOT / 'fixture_check.py',
                    ROOT / 'freeze_build.py', ROOT / 'query_paths.py', FIXTURE,
                    ROOT / 'fixture-release/oracle.json', PREFLIGHT, SELFTEST,
                    *(ROOT / role for role in ROLES if role != 'cli_sql')]
    helpers = [identity(path) for path in helper_paths]
    workload_module = importlib.util.spec_from_file_location('bounded_workload', SUPERVISOR)
    if workload_module is None or workload_module.loader is None:
        raise RuntimeError('standard workload supervisor could not be loaded')
    bounded = importlib.util.module_from_spec(workload_module)
    workload_module.loader.exec_module(bounded)
    guard_spec = importlib.util.spec_from_file_location('native_workload_guard', GUARD)
    if guard_spec is None or guard_spec.loader is None:
        raise RuntimeError('native workload guard could not be loaded')
    guards = importlib.util.module_from_spec(guard_spec)
    guard_spec.loader.exec_module(guards)
    if identity(SUPERVISOR)['sha256'] != '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97':
        raise ValueError('standard supervisor identity changed')
    if identity(GUARD)['sha256'] != 'ce56dd25bd4e55c8c7b8929140c2f2228f27f42d79ceea5645d50db320407b76':
        raise ValueError('standard workload guard identity changed')

    accepted_commit = ACCEPTED_CLI_COMMIT
    candidate_commit = worktree['head_commit']
    command_rows = []
    for name, control_role, candidate_role in COMPARISONS:
        control_binary = role_binary(control_role, candidate_cli)
        candidate_binary = role_binary(candidate_role, candidate_cli)
        control_commit = accepted_commit if control_role == 'accepted_cli' else candidate_commit
        comparison_candidate_commit = accepted_commit if candidate_role == 'accepted_cli' else candidate_commit
        run_root = ROOT / 'paired-runs' / name
        command = [PYTHON, '-B', str(W / 'scripts/run_clickbench_paired_query_uat.py'),
            '--control-binary', str(control_binary), '--candidate-binary', str(candidate_binary),
            '--control-commit', control_commit, '--candidate-commit', comparison_candidate_commit,
            '--input', str(INPUT), '--uat-root', str(run_root), '--reference-packet', str(REFERENCE),
            '--queries', str(QUERIES), '--query-ids', ','.join(map(str, FOCUSED_QUERIES)),
            '--repeats', str(REPEATS), '--memory-gb', '24', '--max-parallelism', '12',
            '--timeout', '120', '--max-workspace-gib', '100',
            '--max-log-mib', '1024', '--max-run-log-mib', '256']
        command_rows.append(dict(
            name=name, control_role=control_role, candidate_role=candidate_role,
            control_binary=identity(control_binary), candidate_binary=identity(candidate_binary),
            control_commit=control_commit, candidate_commit=comparison_candidate_commit,
            uat_root=str(run_root), command=command,
        ))
        if run_root.exists():
            raise FileExistsError(f'preserving prior paired run root: {run_root}')

    storage_before = storage_snapshot()
    plan = dict(
        schema='shardloom.native_surface_focused_parity_pairs.v1', status='predeclared',
        source_commit=worktree['head_commit'], source_worktree=worktree,
        source_manifest_sha256=hashlib.sha256(json.dumps(
            source_manifest(build), sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
        build=identity(BUILD), artifacts=build['artifacts'],
        accepted_cli=accepted, accepted_source_commit=ACCEPTED_CLI_COMMIT,
        accepted_full43_plan=identity(ACCEPTED_CLI.parent / 'final-full43-plan.json'),
        accepted_full43_receipt=identity(ACCEPTED_CLI.parent / 'final-full43-receipt.json'),
        input=input_identity, input_generation=input_generation,
        reference=reference, queries=identity(QUERIES), fixture=identity(FIXTURE),
        preflight=identity(PREFLIGHT), adapter_selftest=identity(SELFTEST),
        helpers=helpers, supervisor=identity(SUPERVISOR), workload_guard=identity(GUARD),
        python=PYTHON, python_site_packages=str(PYTHON_SITE),
        comparisons=command_rows, focused_query_ids=list(FOCUSED_QUERIES), repeats=REPEATS,
        expected_calls_per_comparison=len(FOCUSED_QUERIES) * REPEATS * 2,
        expected_calls_total=len(COMPARISONS) * len(FOCUSED_QUERIES) * REPEATS * 2,
        resources=dict(memory_gb=24, max_parallelism=12, query_deadline_seconds=120,
                       per_comparison_supervisor_deadline_seconds=1800),
        tolerance_rule='frontend pairs: absolute median difference <= max(10% of faster median, 100 microseconds); accepted CLI control: candidate median <= control median + max(10% of control median, 100 microseconds)',
        order_rule='three paired observations per query; standard runner alternates control/candidate order for each query and repeat',
        result_contract='standard paired UAT complete-value checks against the frozen independent reference; native collect paths and fresh per-call results',
        timing_boundary='standard engine_execution_seconds; process and supervisor clocks remain secondary diagnostics',
        isolation='one comparison at a time; no task build, fixture, test, profiler, or other task work during query execution; no artificial pacing or cache manipulation',
        storage_before=storage_before,
        host=dict(platform=platform.platform(), logical_cpus=os.cpu_count()),
    )
    lock.mkdir()
    save(plan_path, plan)
    record = dict(schema=plan['schema'], status='running', plan=identity(plan_path), comparisons=[])
    workload = guards.WorkloadGuard()
    try:
        for row in command_rows:
            workload.check()
            name = row['name']
            log_path = ROOT / f'{name}.log'
            comparison_receipt_path = ROOT / f'{name}.json'
            if log_path.exists() or comparison_receipt_path.exists():
                raise FileExistsError(f'preserving prior comparison result: {name}')
            observation = dict(name=name, status='running', command=row['command'],
                               selected_query_ids=list(FOCUSED_QUERIES), repeats=REPEATS)
            record['comparisons'].append(observation)
            last_sample = [0.0]

            def guard():
                workload.check(observation.get('pid'))
                if shutil.disk_usage(N).free < 12 * GIB:
                    raise RuntimeError('minimum free storage reached')
                if time.monotonic() - last_sample[0] < 2:
                    return
                process_rows = subprocess.check_output(
                    ['ps', '-axo', 'pid=,ppid=,pgid=,pcpu=,rss=,comm='],
                    text=True, timeout=10)
                samples = []
                for line in process_rows.splitlines():
                    fields = line.strip().split(None, 5)
                    if len(fields) == 6 and (int(fields[0]) in workload.owned or float(fields[3]) >= 1):
                        samples.append(dict(pid=int(fields[0]), parent=int(fields[1]),
                            group=int(fields[2]), cpu_percent=float(fields[3]),
                            rss_bytes=int(fields[4]) * 1024, executable=Path(fields[5]).name))
                observation.setdefault('host_samples', []).append(
                    dict(load_average=list(os.getloadavg()), processes=samples))
                last_sample[0] = time.monotonic()

            environment = dict(
                os.environ, PYTHONDONTWRITEBYTECODE='1',
                PYTHONPATH=str(PYTHON_SITE) + ':' + str(W / 'python/src') + ':' + str(W / 'scripts'),
            )
            print(f"Starting {name}: {len(FOCUSED_QUERIES)} queries × {REPEATS} pairs.", flush=True)
            with log_path.open('xb') as output:
                code = bounded.run(row['command'], cwd=W, env=environment, output=output,
                    timeout=1800, evidence=observation, guard=guard, max_output_bytes=8 << 20)
            if not observation.get('process_group_drained') or not observation.get('direct_child_reaped'):
                raise RuntimeError(f'{name} supervisor did not prove process cleanup')
            run_root = Path(row['uat_root'])
            if (run_root / '.ingest-uat.lock').exists():
                raise RuntimeError(f'{name} left its UAT lock behind')
            summaries = list(run_root.glob('logs/*/summary.json'))
            if len(summaries) != 1:
                raise RuntimeError(f'{name} did not produce exactly one paired summary')
            summary_path = summaries[0]
            summary = read(summary_path)
            observed = summary.get('records', [])
            expected_prefix = ordered_calls()
            expected_observed = [(row['query'], row['run'], row['role'], row['pair_position'])
                                 for row in observed]
            exact_schedule = expected_observed == expected_prefix[:len(observed)]
            complete = (
                code == 0 and len(observed) == len(expected_prefix) and exact_schedule
                and summary.get('complete_result_validation') is True
                and summary.get('completed_identity_check') is True
                and summary.get('reference_packet_identity_verified') is True
                and all(item.get('passed') is True and item.get('validation') == 'complete_values'
                        and item.get('engine_timing_reported') is True for item in observed)
                and all(item.get('execution_report') is not None for item in observed)
            )
            screen = tolerance_screen(summary, frontend_parity=row['control_role'] != 'accepted_cli')
            observation.update(
                status='passed' if complete else 'failed',
                command_returncode=code,
                summary=identity(summary_path), log=identity(log_path),
                observed_calls=len(observed), expected_calls=len(expected_prefix),
                exact_alternating_schedule=exact_schedule,
                complete_result_validation=summary.get('complete_result_validation'),
                completed_identity_check=summary.get('completed_identity_check'),
                reference_packet_identity_verified=summary.get('reference_packet_identity_verified'),
                tolerance_screen=screen,
                failure=summary.get('failure'),
                uat_lock_released=True,
            )
            save(comparison_receipt_path, observation)
            print(json.dumps({key: observation.get(key) for key in
                ('name', 'status', 'observed_calls', 'expected_calls', 'tolerance_screen')},
                allow_nan=False), flush=True)
            workload.check()
            if (INPUT.stat().st_dev, INPUT.stat().st_ino, INPUT.stat().st_size,
                INPUT.stat().st_mtime_ns, INPUT.stat().st_ctime_ns) != (
                input_generation['device'], input_generation['inode'], input_generation['size_bytes'],
                input_generation['mtime_ns'], input_generation['ctime_ns']):
                raise RuntimeError('input generation changed during pair comparisons')
            record['completed_comparisons'] = len(record['comparisons'])
            save(ROOT / ('pairs-progress-' + name + '.json'), observation)

        verify_sources(build, worktree)
        if identity(INPUT) != input_identity or identity(REFERENCE) != reference:
            raise RuntimeError('frozen input or reference changed during pair comparisons')
        if identity(QUERIES) != plan['queries']:
            raise RuntimeError('query declaration file changed during pair comparisons')
        if [identity(path) for path in helper_paths] != helpers:
            raise RuntimeError('surface helper changed during pair comparisons')
        if identity(BUILD) != plan['build']:
            raise RuntimeError('candidate build receipt changed during pair comparisons')
        statuses_passed = all(row.get('status') == 'passed' and
                               row['tolerance_screen']['available'] and
                               row['tolerance_screen']['all_within_allowance']
                               for row in record['comparisons'])
        record.update(
            status='passed' if statuses_passed else 'completed_with_failures',
            source_worktree_after=worktree_identity(),
            source_unchanged=True,
            input_hash_verified_before_and_after=True,
            reference_unchanged=True,
            helper_identities_unchanged=True,
            storage_after=storage_snapshot(),
        )
    except BaseException as error:
        record.update(status='failed', failure=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        lock.rmdir()
        record['cohort_lock_released'] = True
        save(receipt_path, record)
    print(json.dumps(dict(status=record['status'], comparisons=len(record['comparisons']),
                          receipt=str(receipt_path))), flush=True)
    return 0 if record['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
