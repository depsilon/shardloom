import hashlib, json, os, glob, tarfile, re
BASE='/Users/dylan/LocalData/shardloom/native-surface-parity-20261024/surfaces-r3'
OUT='/Users/dylan/LocalData/shardloom/native-surface-parity-20261024/r3-report-diff-extraction.json'
PAIRS=[('embedded_workflow_vs_dataframe',[1,35]),('embedded_workflow_vs_native_expression',[1,35]),('cli_sql_vs_embedded_workflow',[35])]
GROUP_RE=re.compile(r'(actual|work|worker|strategy|kernel|operator|route|provider|execution_kind)',re.I)
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
def archive_data(p,qid):
 with tarfile.open(p,'r:xz') as t:
  ms=t.getmembers(); names=[m.name for m in ms]
  stdout_names=[f'q{qid:02d}_run{run}_{role}.stdout.json' for run in range(1,4) for role in ('control','candidate')]
  missing=[n for n in stdout_names if n not in names]
  if missing: raise ValueError(f'{p}: missing stdout members {missing}')
  envelopes={}
  for n in stdout_names:
   raw=t.extractfile(n).read()
   envelopes[n]={'sha256':hashlib.sha256(raw).hexdigest(),'json':json.loads(raw)}
 return {'path':p,'sha256':sha(p),'member_count':len(ms),'members':names,'stdout_members':{n:{'sha256':envelopes[n]['sha256']} for n in stdout_names},'_envelopes':{n:v['json'] for n,v in envelopes.items()}}
def report_fields(envelope):
 if envelope.get('status')!='success' or not isinstance(envelope.get('fields'),list): raise ValueError('invalid archived stdout envelope')
 fields={}
 for f in envelope['fields']:
  if not isinstance(f,dict) or not isinstance(f.get('key'),str) or f['key'] in fields: raise ValueError('invalid/duplicate archived report field')
  fields[f['key']]=f.get('value')
 return fields
def report_from_envelope(envelope):
 fields=report_fields(envelope)
 prefixes=('local_primitive_','resident_','relational_')
 exact={'fallback_attempted','external_engine_invoked','public_workflow_fallback_attempted','public_workflow_external_engine_invoked','execution_backend','execution_mode'}
 report={k:v for k,v in fields.items() if k.startswith(prefixes) or k in exact}
 if fields.get('native_query_timing_reported')!='true': return report,None
 nanos=fields.get('native_query_execution_nanos')
 if not isinstance(nanos,str) or not nanos.isdecimal(): raise ValueError('invalid archived native query timing')
 return report,int(nanos)/1_000_000_000
receipt=json.load(open(BASE+'/pairs-receipt.json'))
receipt_by={x['name']:x for x in receipt['comparisons']}
result={'schema':'shardloom.native_surface_r3_report_diff_extraction.v1','receipt':{'path':BASE+'/pairs-receipt.json','bytes':os.path.getsize(BASE+'/pairs-receipt.json'),'sha256':sha(BASE+'/pairs-receipt.json')},'runs_per_role':3,'ignored_execution_report_fields':[],'coverage':{'expected_comparison_query_observations':5,'expected_run_role_samples':30,'observed_comparison_query_observations':0,'observed_run_role_samples':0,'unavailable_fields':[]},'comparisons':[]}
for name,qids in PAIRS:
 meta=receipt_by[name]
 sums=glob.glob(f'{BASE}/paired-runs/{name}/logs/paired43*/summary.json')
 if len(sums)!=1: raise ValueError(f'{name}: expected one summary, got {sums}')
 sp=sums[0]; s=json.load(open(sp))
 entry={'name':name,'receipt_status':meta['status'],'summary':{'path':sp,'bytes':os.path.getsize(sp),'sha256':sha(sp)},'summary_record_count':len(s['records']),'queries':[]}
 for qid in qids:
  rr=[r for r in s['records'] if int(r['query'])==qid]
  by={role:sorted([x for x in rr if x['role']==role],key=lambda x:x['run']) for role in ('control','candidate')}
  if any(len(by[z])!=3 for z in by): raise ValueError(f'{name} Q{qid}: expected 3 per side')
  diffs={}; equal_group={}; differing_run_ids={}; verified=[]
  archive_paths=glob.glob(f'{BASE}/paired-runs/{name}/logs/paired43*/q{qid:02d}_completed.tar.xz')
  if len(archive_paths)!=1: raise ValueError(f'{name} Q{qid}: expected one archive')
  qa=archive_data(archive_paths[0],qid); envelopes=qa.pop('_envelopes')
  for i in range(3):
   a,b=by['control'][i]['execution_report'],by['candidate'][i]['execution_report']
   run=by['control'][i]['run']
   for role,record in (('control',by['control'][i]),('candidate',by['candidate'][i])):
    member=f'q{qid:02d}_run{record["run"]}_{role}.stdout.json'
    env_report,env_engine=report_from_envelope(envelopes[member])
    summary_engine=record.get('engine_execution_seconds')
    matched=(env_report==record.get('execution_report') and env_engine==summary_engine)
    verified.append({'run':record['run'],'role':role,'member':member,'summary_match':matched})
   for k in sorted(set(a)|set(b)):
    av=a.get(k,'__ABSENT__'); bv=b.get(k,'__ABSENT__')
    if av!=bv:
     differing_run_ids.setdefault(k,[]).append(run)
    elif GROUP_RE.search(k): equal_group.setdefault(k,[]).append(av)
  for k,run_ids in differing_run_ids.items():
   diffs[k]={'control_by_run':[by['control'][i]['execution_report'].get(k,'__ABSENT__') for i in range(3)],'candidate_by_run':[by['candidate'][i]['execution_report'].get(k,'__ABSENT__') for i in range(3)],'differing_run_ids':run_ids}
  missing=[]
  for role in by:
   for i,r in enumerate(by[role]):
    for key in ('engine_timing_reported','engine_execution_seconds','result_sha256'):
     if key not in r or r[key] is None: missing.append({'role':role,'run':r['run'],'field':key})
  entry['queries'].append({'query_id':qid,'roles':{role:{'surface':by[role][0].get('surface',by[role][0]['role']),'engine_execution_seconds':[r.get('engine_execution_seconds') for r in by[role]],'timing_available':[r.get('engine_timing_reported') for r in by[role]]} for role in by},'execution_report_field_differences':diffs,'equal_grouping_fields':{k:v[:3] for k,v in equal_group.items() if len(v)==3 and len(set(v))==1},'archive':qa,'summary_archive_verification':{'matched_member_count':sum(x['summary_match'] for x in verified),'expected_member_count':6,'members':verified},'unavailable_fields':missing,'validation':{'all_passed':all(r.get('passed') is True for r in rr),'result_sha256_by_run':{role:[r.get('result_sha256') for r in by[role]] for role in by}}})
 result['coverage']['observed_comparison_query_observations']+=len(entry['queries'])
 result['coverage']['observed_run_role_samples']+=sum(len(q['roles'])*3 for q in entry['queries'])
 result['comparisons'].append(entry)
with open(OUT,'w') as f: json.dump(result,f,separators=(',',':'),sort_keys=True)
print(OUT)
print(json.dumps({'comparison_count':len(result['comparisons']),'query_count':sum(len(x['queries']) for x in result['comparisons']),'verified_member_summary_matches':sum(q['summary_archive_verification']['matched_member_count'] for c in result['comparisons'] for q in c['queries']),'expected_member_summary_matches':30,'source_summaries':[(x['name'],x['summary']['sha256']) for x in result['comparisons']]},indent=2))
