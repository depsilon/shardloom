"""Complete public conformance and prepare the second frozen comparison."""
import json
import os
from pathlib import Path
import subprocess
import sys

N = Path(__file__).resolve().parent
S = N / 'surfaces-r2'
W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
PYTHON = N / 'duckdb-reference-env/bin/python'
build = json.loads((S / 'artifacts/build-summary.json').read_text())
assert build['status'] == 'passed' and build['profile'] == 'release'
env = dict(
    os.environ, PYTHONDONTWRITEBYTECODE='1',
    PYTHONPATH=':'.join(map(str, [W / 'python/src', W / 'scripts',
                                N / 'duckdb-reference-env/lib/python3.13/site-packages'])),
    SHARDLOOM_REQUIRE_NATIVE_PYTHON='1',
    SHARDLOOM_NATIVE_TEST_LIBRARY=str(S / 'artifacts/_native.abi3.so'),
    SHARDLOOM_SURFACE_TEST_BINARY=str(S / 'artifacts/shardloom'),
)
commands = [
    ('parity-r2-public-provider-tests', [str(PYTHON), '-B', '-m', 'unittest', 'discover', '-s', 'python/tests', '-p', 'test_native_shared_provider_binding.py', '-v']),
    ('parity-r2-small-fixtures', [str(PYTHON), '-B', str(S / 'fixture_check.py'), 'fixture-release']),
    ('parity-r2-preparation-preflight', [str(PYTHON), '-B', str(S / 'preflight.py')]),
    ('parity-r2-adapter-selftest', [str(PYTHON), '-B', str(S / 'adapter_selftest.py')]),
]
for label, command in commands:
    print(label, flush=True)
    result = subprocess.run([sys.executable, '-B', str(N / 'run_validation.py'), label, *command], cwd=W, env=env)
    if result.returncode:
        raise SystemExit(result.returncode)
