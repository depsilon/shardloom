import glob, hashlib, json, os, re, sys, tarfile

N='/Users/dylan/LocalData/shardloom/native-surface-parity-20261024'
S=N+'/surfaces-r4'
W='/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo'
OUT=N+'/r4-report-diff-extraction.json'
sys.path.insert(0,W+'/scripts')
from native_workflow_protocol import report_fields, extract_result

TARGETS={
 'embedded_workflow_vs_dataframe':[28,34,35],
 'embedded_workflow_vs_native_expression':[28,34,35],
 'cli_sql_vs_embedded_workflow':[28,34],
 'embedded_workflow_vs_python_sql':[28,34],
 'accepted_cli_vs_candidate_cli':[28,34],
}
RELEVANT=re.compile(r'(source|read|scan|actual|physical|strategy|policy|worker|memory|runtime|parallel|concurr|thread|timing|elapsed|nanos|micros|rows_scanned|arrays_read|byte|decode|operator|kernel)',re.I)
STRAT=re.compile(r'(source|strategy|physical|policy|route|operator|kernel)',re.I)
def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
def archived_envelopes(path,qid):
 with tarfile.open(path,'r:xz') as t:
  names=[m.name for m in t.getmembers()]
  out={}
  for run in range(1,4):
   for role in ('control','candidate'):
    name=f'q{qid:02d}_run{run}_{role}.stdout.json'
    if name not in names: raise ValueError(f'missing archive member: {name}')
    raw=t.extractfile(name).read()
    out[(run,role)]={'sha256':sha_bytes(raw),'envelope':json.loads(raw)}
 return {'path':path,'sha256':sha_file(path),'member_count':len(names),'members':{f'{run}:{role}':{'name':f'q{qid:02d}_run{run}_{role}.stdout.json','sha256':out[(run,role)]['sha256']} for run in range(1,4) for role in ('control','candidate')}},out
receipt_path=S+'/pairs-receipt.json'
receipt=json.load(open(receipt_path)); receipt_by={x['name']:x for x in receipt['comparisons']}
result={'schema':'shardloom.native_surface_r4_report_diff_extraction.v1','receipt':{'path':receipt_path,'bytes':os.path.getsize(receipt_path),'sha256':sha_file(receipt_path)},'scope':{'comparison_query_observations':[],'runs_per_role':3},'comparisons':[],'coverage':{'expected_observations':12,'observed_observations':0,'expected_archived_stdout_members':72,'verified_archived_stdout_members':0,'unavailable_fields':[]}}
for comp,qids in TARGETS.items():
 summaries=glob.glob(f'{S}/paired-runs/{comp}/logs/paired43*/summary.json')
 if len(summaries)!=1: raise ValueError(f'{comp}: expected one summary, found {len(summaries)}')
 sp=summaries[0]; summary=json.load(open(sp)); cr={'name':comp,'receipt_status':receipt_by[comp]['status'],'summary':{'path':sp,'bytes':os.path.getsize(sp),'sha256':sha_file(sp)},'summary_record_count':len(summary['records']),'queries':[]}
 for qid in qids:
  records=[r for r in summary['records'] if int(r['query'])==qid]
  by={role:sorted([r for r in records if r['role']==role],key=lambda r:r['run']) for role in ('control','candidate')}
  if any(len(by[role])!=3 for role in by): raise ValueError(f'{comp} Q{qid}: not 3 records per role')
  archives=glob.glob(f'{S}/paired-runs/{comp}/logs/paired43*/q{qid:02d}_completed.tar.xz')
  if len(archives)!=1: raise ValueError(f'{comp} Q{qid}: expected one archive, found {len(archives)}')
  archive,envs=archived_envelopes(archives[0],qid)
  report_arrays={role:[r.get('execution_report') for r in by[role]] for role in by}
  keys=sorted(set().union(*(set(rep or {}) for arr in report_arrays.values() for rep in arr)))
  diffs={}; all_field_values={}
  for key in keys:
   cvals=[rep.get(key,'__ABSENT__') for rep in report_arrays['control']]
   vvals=[rep.get(key,'__ABSENT__') for rep in report_arrays['candidate']]
   run_ids=[i+1 for i,(cv,vv) in enumerate(zip(cvals,vvals)) if cv!=vv]
   if run_ids: diffs[key]={'control_by_run':cvals,'candidate_by_run':vvals,'differing_run_ids':run_ids}
   if RELEVANT.search(key): all_field_values[key]={'control_by_run':cvals,'candidate_by_run':vvals}
  verifications=[]; member_hashes={}
  for run in range(1,4):
   for role in ('control','candidate'):
    env=envs[(run,role)]['envelope']; fields=report_fields(env)
    archived_report={k:v for k,v in fields.items() if k.startswith(('local_primitive_','resident_','relational_')) or k in {'fallback_attempted','external_engine_invoked','public_workflow_fallback_attempted','public_workflow_external_engine_invoked','execution_backend','execution_mode'}}
    timing=None
    if fields.get('native_query_timing_reported')=='true': timing=int(fields['native_query_execution_nanos'])/1_000_000_000
    rec=by[role][run-1]
    report_match=archived_report==rec.get('execution_report')
    timing_match=timing==rec.get('engine_execution_seconds')
    actual=extract_result(env)
    result_hash=hashlib.sha256(json.dumps(actual,sort_keys=True,allow_nan=False).encode()).hexdigest()
    output_match=result_hash==rec.get('result_sha256')
    member=f'q{qid:02d}_run{run}_{role}.stdout.json'
    member_hashes[f'{run}:{role}']=envs[(run,role)]['sha256']
    verifications.append({'run':run,'role':role,'member':member,'execution_report_match':report_match,'engine_timing_match':timing_match,'output_hash_match':output_match,'archived_output_sha256':result_hash,'summary_output_sha256':rec.get('result_sha256')})
    if not (report_match and timing_match and output_match): raise ValueError(f'{comp} Q{qid} {run} {role}: archived evidence mismatch')
  unavailable=[]
  for role in by:
   for r in by[role]:
    for key in ('engine_timing_reported','engine_execution_seconds','result_sha256'):
     if r.get(key) is None: unavailable.append({'role':role,'run':r.get('run'),'field':key})
  result['coverage']['unavailable_fields'].extend([{'comparison':comp,'query_id':qid,**x} for x in unavailable])
  q={'query_id':qid,'roles':{role:{'engine_execution_seconds':[r.get('engine_execution_seconds') for r in by[role]],'engine_timing_reported':[r.get('engine_timing_reported') for r in by[role]],'result_sha256':[r.get('result_sha256') for r in by[role]],'passed':[r.get('passed') for r in by[role]]} for role in by},'differing_execution_report_fields':diffs,'selected_source_strategy_worker_memory_runtime_timing_fields':all_field_values,'archive':archive,'verification':{'verified_members':sum(v['execution_report_match'] and v['engine_timing_match'] and v['output_hash_match'] for v in verifications),'expected_members':6,'members':verifications},'unavailable_fields':unavailable}
  cr['queries'].append(q); result['coverage']['observed_observations']+=1; result['coverage']['verified_archived_stdout_members']+=q['verification']['verified_members']
  result['scope']['comparison_query_observations'].append({'comparison':comp,'query_id':qid})
 cr['queries'].sort(key=lambda q:q['query_id']); result['comparisons'].append(cr)
with open(OUT,'w') as f: json.dump(result,f,separators=(',',':'),sort_keys=True)
print(OUT)
print(json.dumps({'receipt_sha256':result['receipt']['sha256'],'observations':result['coverage']['observed_observations'],'verified_stdout_members':result['coverage']['verified_archived_stdout_members'],'expected_stdout_members':result['coverage']['expected_archived_stdout_members'],'unavailable_fields':len(result['coverage']['unavailable_fields'])},indent=2))
