"""Frozen independent reference cohort with bounded storage/process ownership."""
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022')
RUN = OUT / 'independent-full43-945'
SOURCE = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat/sources/hits.parquet')
LOCK = SOURCE.parent.parent / '.ingest-uat.lock'
PYTHON = OUT / 'duckdb-reference-env/bin/python'
WORKER = ROOT / 'scripts/clickbench_independent_reference.py'
QUERIES = ROOT / 'benchmarks/clickbench/queries.sql'
SUPERVISOR = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
WORKLOAD = Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/native_workload_guard_816.py')
sys.path.insert(0, str(ROOT / 'scripts'))
from clickbench_independent_reference import query_plan
from clickbench_reference_packet import SCHEMA_VERSION, canonical_values_sha256, load_reference_packet
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


supervisor = load_module('bounded_reference_process', SUPERVISOR)
workload = load_module('reference_workload_guard', WORKLOAD)


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)


def generation(path):
    value = path.stat()
    return dict(device=value.st_dev, inode=value.st_ino, size_bytes=value.st_size,
                mtime_ns=value.st_mtime_ns, ctime_ns=value.st_ctime_ns)


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def storage(reserve=0):
    return check_budgets(RUN, RUN / 'scratch', RUN / 'logs', min_free_bytes=12 * GIB,
        reserve_bytes=reserve, max_workspace_bytes=100 * GIB, max_log_bytes=1024 * MIB,
        max_run_log_bytes=256 * MIB)


def main():
    assert not RUN.exists(), 'a prior observation must never be overwritten'
    for path in (RUN, SOURCE):
        require_local_path(path, Path.home(), sys.platform)
    workload.WorkloadGuard().check()
    RUN.mkdir()
    (RUN / 'logs').mkdir()
    (RUN / 'scratch').mkdir()
    before = generation(SOURCE)
    source = identity(SOURCE)
    assert generation(SOURCE) == before
    plans = query_plan(QUERIES)
    tracked = [WORKER, ROOT / 'scripts/clickbench_reference_packet.py',
               ROOT / 'scripts/native_workflow_protocol.py', ROOT / 'scripts/local_uat_storage.py',
               ROOT / 'scripts/test_clickbench_independent_reference.py', SUPERVISOR, WORKLOAD, Path(__file__)]
    program = [identity(path) for path in tracked]
    package_inventory = subprocess.check_output([str(PYTHON), '-B', '-c',
        "import importlib.metadata as m,json,hashlib,pathlib,sys; d=m.distribution('duckdb'); "
        "print(json.dumps({'python':sys.version,'duckdb':d.version,'files':[{'path':str(p),"
        "'sha256':hashlib.sha256(pathlib.Path(d.locate_file(p)).read_bytes()).hexdigest()} for p in d.files "
        "if pathlib.Path(d.locate_file(p)).is_file()]}))"], text=True)
    package = json.loads(package_inventory)
    assert package['duckdb'] == '2.0.0'
    protocol = dict(schema='shardloom.independent_clickbench_protocol.v1', status='frozen_before_execution',
        frozen_at=dt.datetime.now(dt.timezone.utc).isoformat(),
        source=source, source_generation=before, queries=identity(QUERIES), programs=program,
        dependency=package, install_receipt=identity(OUT / 'duckdb-reference-install.json'),
        plans=plans, query_ids=list(range(1, 44)), executions_per_query=1, total_calls=43,
        resources=dict(threads=4, memory_gib=6, temp_gib=32, observed_process_rss_ceiling_gib=10,
                       per_call_deadline_seconds=300, minimum_free_gib=12, maximum_workspace_gib=100,
                       maximum_retained_log_mib=1024, maximum_run_log_mib=256, maximum_output_mib=8),
        result_contract=dict(length='UTF-8 bytes', epoch_date='integer days since 1970-01-01',
            epoch_time='integer seconds; exact integer floor-to-minute', aggregates='existing primitive F64 SUM and AVG; exact integer counts',
            group_ties='declared complete group keys in ascending native comparison order',
            raw_ties='absolute row ordinal in the single Parquet input',
            unordered_group_limit='first groups by minimum source ordinal; count all matching rows',
            floats='no rounding; later native runner retains its existing rel_tol=1e-12 and abs_tol=1e-12',
            rows='all complete returned rows and baseline output types'),
        independence=dict(native_binary_input=False, native_values_input=False,
            native_runtime_invoked=False, baseline_only=True,
            output_labels='source-reviewed public primitive naming, not reference values'),
        methodology='One sequential call per independent equivalent; no native queries, builds, profiling or agents. '
            'Original Parquet is fully hashed before and after. No cache manipulation. '
            'Shared UAT lock, bounded process-group drain, storage limits and process checks are enforced. '
            'Process clocks are diagnostic only; this is not a speed comparison or a native Full43 result.',
        host=dict(platform=platform.platform(), logical_cpus=os.cpu_count()), storage_before=storage(32 * GIB))
    protocol_path = RUN / 'protocol.json'
    save(protocol_path, protocol)
    owner = dict(pid=os.getpid(), kind='independent_clickbench_reference', protocol=identity(protocol_path))
    LOCK.mkdir()
    save(LOCK / 'owner.json', owner)
    acceptance = dict(status='running', protocol=identity(protocol_path), records=[],
                      native_runtime_invoked=False, independent_correctness_oracle=True,
                      performance_comparison=False)
    last_check = 0.0
    active_pid = None

    def guard():
        nonlocal last_check
        if time.monotonic() - last_check < 1:
            return
        last_check = time.monotonic()
        assert json.loads((LOCK / 'owner.json').read_text()) == owner, 'shared lock ownership changed'
        assert generation(SOURCE) == before, 'source generation changed'
        storage()
        output = subprocess.check_output(['ps', '-axo', 'pid=,ppid=,pgid=,rss=,comm='], text=True, timeout=10)
        conflicts = []
        for line in output.splitlines():
            fields = line.strip().split(None, 4)
            if len(fields) != 5:
                continue
            pid, parent, group, rss = map(int, fields[:4])
            name = fields[4]
            if active_pid is not None and (pid == active_pid or group == active_pid):
                assert rss * 1024 <= 10 * GIB, 'independent process exceeded its observed RSS ceiling'
            elif workload.native_name(name):
                conflicts.append(dict(pid=pid, executable=name))
        assert not conflicts, 'another native job is active: ' + str(conflicts)

    try:
        print('Independent reference protocol frozen; starting 43 sequential oracle queries.', flush=True)
        for plan in plans:
            q = plan['query_id']
            prefix = RUN / 'logs' / f'q{q:02d}'
            scratch = RUN / 'scratch' / f'q{q:02d}'
            assert not scratch.exists()
            receipt = dict(query_id=q, status='running')
            command = [str(PYTHON), '-B', str(WORKER), '--queries', str(QUERIES), '--parquet', str(SOURCE),
                '--query-id', str(q), '--temp-directory', str(scratch), '--threads', '4',
                '--memory-gib', '6', '--temp-gib', '32', '--supervisor-pid', str(os.getpid()),
                '--lock-directory', str(LOCK)]
            receipt['command'] = command
            try:
                storage(32 * GIB)
                with prefix.with_suffix('.stdout.json').open('x') as output, prefix.with_suffix('.stderr.txt').open('x') as error:
                    def callback():
                        nonlocal active_pid
                        active_pid = receipt.get('pid')
                        guard()
                    code = supervisor.run(command, cwd=ROOT, env=os.environ.copy(), output=output,
                        error_output=error, timeout=300, evidence=receipt, guard=callback)
                assert code == 0 and receipt['process_group_drained'] and receipt['direct_child_reaped']
                record = json.loads(prefix.with_suffix('.stdout.json').read_text())
                assert record['query_id'] == q and record['statement'] == plan['statement']
                assert record['equivalent_sql'] == plan['equivalent_sql']
                assert record['oracle_version'] == '2.0.0' and record['engine_version'] == 'v2.0.0'
                assert record['baseline_only'] and not record['native_runtime_invoked']
                record['values_sha256'] = canonical_values_sha256(record['values'])
                receipt.update(status='passed', rows=len(record['values']), values_sha256=record['values_sha256'])
                acceptance['records'].append(record)
                # DuckDB removes its completed spill files on connection close.
                remaining = list(scratch.rglob('*')) if scratch.exists() else []
                assert not any(p.is_file() for p in remaining), 'owned spill files survived closed connection'
                if scratch.exists():
                    for path in sorted(remaining, key=lambda p: len(p.parts), reverse=True):
                        path.rmdir()
                    scratch.rmdir()
                receipt['temporary_payloads_remaining'] = 0
                print(f'Independent Q{q:02d} complete: {len(record["values"])} rows.', flush=True)
            except BaseException as error:
                receipt.update(status='failed', failure=type(error).__name__ + ': ' + str(error))
                raise
            finally:
                receipt['outputs'] = [identity(p) for p in sorted((RUN / 'logs').glob(prefix.name + '.*'))]
                save(prefix.with_suffix('.receipt.json'), receipt)
                active_pid = None
        assert generation(SOURCE) == before and identity(SOURCE) == source and generation(SOURCE) == before
        assert [identity(path) for path in tracked] == program
        assert json.loads(subprocess.check_output([str(PYTHON), '-B', '-c',
            "import importlib.metadata as m,json,hashlib,pathlib,sys; d=m.distribution('duckdb'); "
            "print(json.dumps({'python':sys.version,'duckdb':d.version,'files':[{'path':str(p),"
            "'sha256':hashlib.sha256(pathlib.Path(d.locate_file(p)).read_bytes()).hexdigest()} for p in d.files "
            "if pathlib.Path(d.locate_file(p)).is_file()]}))"],text=True)) == package
        packet = dict(schema_version=SCHEMA_VERSION, reference_kind='independent_reference',
            queries_sha256=protocol['queries']['sha256'], independent_correctness_oracle=True,
            oracle='DuckDB 2.0.0 reading original Parquet', protocol=identity(protocol_path),
            source=source, result_contract=protocol['result_contract'], records=acceptance['records'])
        packet_path = RUN / 'reference.json'
        save(packet_path, packet)
        loaded = load_reference_packet(packet_path, QUERIES)
        assert len(loaded['values']) == 43
        acceptance.update(status='passed', calls=43, rows=sum(len(x['values']) for x in acceptance['records']),
            source_hash_before_after=True, program_and_package_unchanged=True, reference=identity(packet_path),
            storage_after=storage())
    except BaseException as error:
        acceptance.update(status='failed', failure=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        assert json.loads((LOCK / 'owner.json').read_text()) == owner
        (LOCK / 'owner.json').unlink()
        LOCK.rmdir()
        acceptance['shared_lock_released'] = not LOCK.exists()
        save(RUN / 'acceptance.json', acceptance)
    print('Complete independent reference saved; no native execution or performance comparison claimed.', flush=True)


if __name__ == '__main__':
    main()
