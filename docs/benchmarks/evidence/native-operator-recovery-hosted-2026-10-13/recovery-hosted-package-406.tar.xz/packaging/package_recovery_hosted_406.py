#!/usr/bin/env python3
"""Create and verify the portable hosted evidence package for recovery PR #1549."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import tarfile

O = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
R = Path("/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo")
LIMIT = 4 * 1024 * 1024
ARCHIVE = OUT / "recovery-hosted-package-406.tar.xz"
MANIFEST = OUT / "recovery-hosted-package-406.manifest.json"
REPORT = OUT / "recovery-hosted-package-406.verification.json"
INDEX = OUT / "recovery-hosted-package-406.index.json"
HELPER_MEMBER = "packaging/package_recovery_hosted_406.py"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def selected_inputs() -> list[tuple[str, Path]]:
    selections: list[tuple[str, Path]] = []
    for folder in ("recovery-ci-406", "recovery-wheel-hosted-406", "recovery-production-406"):
        root = O / folder
        if not root.is_dir():
            raise FileNotFoundError(root)
        for current, dirs, files in os.walk(root, followlinks=False):
            base = Path(current)
            if any((base / name).is_symlink() for name in dirs):
                raise ValueError(f"symlink directory in input tree: {base}")
            for name in files:
                path = base / name
                if path.is_symlink() or not path.is_file():
                    raise ValueError(f"non-regular input: {path}")
                selections.append((path.relative_to(O).as_posix(), path))
    selections.extend([
        ("primary-helpers/capture_recovery_ci_406.py", O / "capture_recovery_ci_406.py"),
        ("primary-helpers/check_recovery_production_406.py", O / "check_recovery_production_406.py"),
        ("repo-evidence/native-operator-recovery-2026-10-13.json",
         R / "docs/benchmarks/evidence/native-operator-recovery-2026-10-13.json"),
        ("repo-evidence/native-operator-recovery-2026-10-13.provenance.json",
         R / "docs/benchmarks/evidence/native-operator-recovery-2026-10-13.provenance.json"),
        (HELPER_MEMBER, Path(__file__).resolve()),
    ])
    names = [name for name, _ in selections]
    if len(names) != len(set(names)):
        raise ValueError("duplicate archive member name")
    for name, path in selections:
        pure = PurePosixPath(name)
        if pure.is_absolute() or ".." in pure.parts or not name or "\\" in name:
            raise ValueError(f"unsafe archive member: {name}")
        if path.is_symlink() or not path.is_file():
            raise FileNotFoundError(f"missing or non-regular input: {path}")
    return sorted(selections)


def make_index() -> dict:
    return {
        "schema_version": "shardloom.operator_recovery_hosted_evidence.v1",
        "status": "hosted_evidence_packet_complete",
        "pull_request": 1549,
        "head_sha": "528aa23ed7f09442b664bc07ca44b5c48a8d5c0f",
        "synthetic_merge_sha": "9d0c3d3ee76d4afd90e2581f77c72e2103d687dc",
        "merged_commit_sha": "483cbaa982dd300dec45bb50066cdbf452686b36",
        "premerge_ci": {
            "checks": 44, "all_passed": True, "inline_findings": 0,
            "review_submissions": 0, "accepted_git_blobs": 2240,
            "full_tree_identity": "head and synthetic merge trees matched; see recovery-ci-406/summary.json and primary-helpers/capture_recovery_ci_406.py"
        },
        "wheel_jobs": {
            "count": 3, "native_binding_tests_reported": 240,
            "reported_per_job": 80,
            "historical_index_note": "recovery-wheel-hosted-406/index.json preserves its original pending-tree statement; primary CI summary later proves head/synthetic full-tree identity.",
            "tree_proof_member": "recovery-ci-406/summary.json"
        },
        "production": {
            "deployment_id": 115670309419,
            "deployment_head_sha": "483cbaa982dd300dec45bb50066cdbf452686b36",
            "responses": 4, "all_http_200": True,
            "html_cloudflare_insertion_bytes_each": 1305,
            "pagefind_response_raw_identical": True,
            "guide_scope": "website and website-src are unchanged from the previously reviewed guide proof; prior desktop/mobile/search review applies. This packet makes no new UI-behavior claim."
        },
        "limitations": [
            "The hosted binding-test counts are aggregate reports; individual test names are absent.",
            "Wheel artifacts were not downloaded; uninstall coverage is not claimed.",
            "No process-RSS limit or RSS result is claimed.",
            "This packet does not claim broader release readiness, performance superiority, or completion of competitive gates."
        ],
        "archive": ARCHIVE.name,
        "manifest": MANIFEST.name
    }


def main() -> None:
    inputs = selected_inputs()
    source_bytes = sum(path.stat().st_size for _, path in inputs)
    if source_bytes > LIMIT:
        raise SystemExit(f"selected inputs exceed 4 MiB: {source_bytes} bytes")
    for output in (ARCHIVE, MANIFEST, REPORT, INDEX):
        if output.exists():
            raise FileExistsError(f"refusing to replace existing output: {output}")

    members = [{"path": name, "bytes": path.stat().st_size, "sha256": sha256(path)}
               for name, path in inputs]
    with tarfile.open(ARCHIVE, mode="w:xz", preset=6) as archive:
        for (name, path), record in zip(inputs, members, strict=True):
            info = tarfile.TarInfo(name)
            info.size = record["bytes"]
            info.mtime = 0
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            info.mode = 0o644
            with path.open("rb") as stream:
                archive.addfile(info, stream)

    archive_record = {"path": ARCHIVE.name, "bytes": ARCHIVE.stat().st_size,
                      "sha256": sha256(ARCHIVE), "members": len(members),
                      "uncompressed_bytes": source_bytes}
    manifest = {"schema_version": "shardloom.operator_recovery_hosted_archive.v1",
                "archive": archive_record, "members": members}
    write_json(MANIFEST, manifest)

    seen: list[str] = []
    checked: dict[str, dict] = {}
    with tarfile.open(ARCHIVE, mode="r:xz") as archive:
        for info in archive:
            name = info.name
            pure = PurePosixPath(name)
            if pure.is_absolute() or ".." in pure.parts or not name or "\\" in name:
                raise ValueError(f"unsafe archived path: {name}")
            if name in checked:
                raise ValueError(f"duplicate archived member: {name}")
            if not info.isfile():
                raise ValueError(f"non-regular archived member: {name}")
            stream = archive.extractfile(info)
            if stream is None:
                raise ValueError(f"unreadable archived member: {name}")
            h = hashlib.sha256()
            size = 0
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                size += len(block)
                h.update(block)
            checked[name] = {"bytes": size, "sha256": h.hexdigest()}
            seen.append(name)
    expected = {item["path"]: {"bytes": item["bytes"], "sha256": item["sha256"]}
                for item in members}
    verification = {
        "schema_version": "shardloom.operator_recovery_hosted_package_verification.v1",
        "status": "passed" if checked == expected and len(seen) == len(set(seen)) else "failed",
        "selected_source_files": len(inputs), "selected_source_bytes_preflight": source_bytes,
        "cap_bytes": LIMIT, "archive_member_count": len(seen),
        "archive_uncompressed_bytes_verified": sum(x["bytes"] for x in checked.values()),
        "all_archive_members_reopened_and_hash_verified": checked == expected,
        "no_duplicate_absolute_traversal_or_extraneous_members": (
            len(seen) == len(set(seen)) and set(checked) == set(expected)),
        "archive_bytes": ARCHIVE.stat().st_size, "archive_sha256": sha256(ARCHIVE),
        "manifest_sha256": sha256(MANIFEST),
        "checks": {name: checked.get(name) == value for name, value in expected.items()}
    }
    if verification["status"] != "passed":
        raise SystemExit("archive verification failed; inspect the partial output")
    write_json(REPORT, verification)
    index = make_index()
    index["archive_bytes"] = ARCHIVE.stat().st_size
    index["archive_sha256"] = sha256(ARCHIVE)
    index["manifest_sha256"] = sha256(MANIFEST)
    write_json(INDEX, index)
    print(json.dumps({"archive": archive_record, "manifest_sha256": sha256(MANIFEST),
                      "verification": verification, "index": INDEX.name}, indent=2))


if __name__ == "__main__":
    main()
