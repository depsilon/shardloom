"""Save exact recovery review, hosted checks and immutable Git source before merge."""
from datetime import datetime, timezone
import hashlib
import json
import subprocess

from freeze_native_release_298 import ROOT, OUT, save, sources, sha

HEAD = '528aa23ed7f09442b664bc07ca44b5c48a8d5c0f'
BASE = '5b5cd6a7cb3c88d20046079c46900d9b323b1274'
SYNTHETIC = '9d0c3d3ee76d4afd90e2581f77c72e2103d687dc'
DEST = OUT / 'recovery-ci-406'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def main():
    active = json.loads((OUT / 'selection-check-source-406.json').read_text())['source_sha256']
    assert sources() == active
    DEST.mkdir()
    records = {}
    endpoints = dict(pr='pulls/1549', checks=f'commits/{HEAD}/check-runs?per_page=100',
                     statuses=f'commits/{HEAD}/status', reviews='pulls/1549/reviews?per_page=100',
                     inline_comments='pulls/1549/comments?per_page=100',
                     comments='issues/1549/comments?per_page=100')
    for name, endpoint in endpoints.items():
        raw = subprocess.check_output(['/opt/homebrew/bin/gh', 'api', 'repos/depsilon/shardloom/' + endpoint], timeout=45)
        with (DEST / (name + '.json')).open('xb') as output:
            output.write(raw)
        records[name] = json.loads(raw)
    pr = records['pr']
    assert pr['state'] == 'open' and not pr['merged'] and not pr['draft']
    assert pr['head']['sha'] == HEAD and pr['base']['sha'] == BASE
    assert pr['mergeable'] and pr['merge_commit_sha'] == SYNTHETIC
    checks = records['checks']
    assert checks['total_count'] == len(checks['check_runs']) == 44
    assert all(row['status'] == 'completed' and row['conclusion'] == 'success' and row['head_sha'] == HEAD for row in checks['check_runs'])
    assert all(row['state'] == 'success' for row in records['statuses']['statuses'])
    assert not records['reviews'] and not records['inline_comments']
    review = [row for row in records['comments'] if '<!-- codex-pull-request-review-summary -->' in row['body']]
    assert len(review) == 1 and '**Completed**' in review[0]['body'] and '`528aa23`' in review[0]['body']
    subprocess.run(['git', 'fetch', 'origin', 'refs/pull/1549/merge'], cwd=ROOT, check=True, timeout=60)
    assert git('rev-parse', 'FETCH_HEAD') == SYNTHETIC
    tree = git('rev-parse', HEAD + '^{tree}')
    assert git('rev-parse', SYNTHETIC + '^{tree}') == tree
    accepted = json.loads((OUT / 'operator-recovery-source-402-2.json').read_text())['source_sha256']
    requests = ''.join(HEAD + ':' + name + '\n' for name in accepted).encode()
    content = subprocess.check_output(['git', 'cat-file', '--batch'], cwd=ROOT, input=requests)
    cursor, total = 0, 0
    for name, expected in accepted.items():
        stop = content.index(b'\n', cursor)
        _, kind, size = content[cursor:stop].split()
        assert kind == b'blob'
        size = int(size)
        cursor = stop + 1
        data = content[cursor:cursor + size]
        assert hashlib.sha256(data).hexdigest() == expected, name
        cursor += size
        assert content[cursor:cursor + 1] == b'\n'
        cursor += 1
        total += size
    assert cursor == len(content)
    wheels = OUT / 'recovery-wheel-hosted-406'
    wheel_index = json.loads((wheels / 'index.json').read_text())
    for name, item in wheel_index['files'].items():
        path = wheels / name
        assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256']
    for name, remote in [('ci.yml', '.github/workflows/ci.yml'),
                         ('prove_native_python_wheel.py', 'scripts/prove_native_python_wheel.py')]:
        assert (wheels / name).read_bytes() == subprocess.check_output(['git', 'show', HEAD + ':' + remote], cwd=ROOT)
    for job in wheel_index['hosted_workflow']['jobs']:
        text = (wheels / job['log_file']).read_text()
        assert f'"tests": 80' in text and '"failures": 0' in text and '"errors": 0' in text
        assert '"skipped": 0' in text and '"isolated_install": true' in text
        assert job['status'] == 'completed' and job['conclusion'] == 'success'
        check = next(row for row in checks['check_runs'] if row['id'] == job['job_id'])
        assert check['conclusion'] == 'success'
    assert sources() == active
    result = dict(schema_version='shardloom.operator_recovery_premerge.v1', status='passed',
                  observed_at=datetime.now(timezone.utc).isoformat(), pull_request=1549,
                  head=HEAD, base=BASE, synthetic_merge=SYNTHETIC, tree=tree,
                  synthetic_merge_tree_identical=True, check_count=44, all_checks_passed=True,
                  review_completed=True, inline_findings=0, review_submissions=0,
                  raw_records=list(endpoints), active_selection_source_unchanged=True,
                  accepted_source_files=len(accepted), accepted_git_blob_bytes=total,
                  all_accepted_git_blob_sha256_verified=True, wheel_job_count=3,
                  wheel_reported_native_tests=240, wheel_files_and_exact_source_verified=True,
                  wheel_limitations=wheel_index['limitations'][1:])
    save(DEST / 'summary.json', result)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main()
