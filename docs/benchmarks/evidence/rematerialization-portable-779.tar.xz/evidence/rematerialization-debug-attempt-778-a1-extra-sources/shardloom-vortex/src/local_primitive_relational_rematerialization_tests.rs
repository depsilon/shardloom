//! Composition, admission, last-owner release and bounded failure tests.

use super::super::{rematerialization, rematerialization_observation as observation};
use super::{rematerialization_fixture::*, *};
use shardloom_core::BinaryOp;
use std::{cell::RefCell, rc::Rc};

fn prepared(data: &Data) -> PreparedVortexRelational {
    data.prepare(
        plan(
            data.spec,
            DatasetUri::new("memory://rematerialization").unwrap(),
        ),
        64 << 20,
    )
}

fn execute(data: &Data, prepared: &PreparedVortexRelational) {
    let fields = data.output_fields();
    let mut bytes = Vec::new();
    let result = prepared
        .for_each_batch(&CancellationToken::default(), |array, context| {
            consume_bytes(&array, &fields, context, &mut bytes)
        })
        .unwrap();
    assert_eq!(bytes, data.expected_bytes());
    assert_eq!(result.output_rows, data.spec.rows as u64);
    assert!(result.native_io_certificate.is_certified());
}

#[test]
fn rematerialization_admission_boundaries_preserve_complete_outputs() {
    let base = matrix()[0];
    let specs = [
        Spec {
            rows: 32767,
            ..base
        },
        base,
        Spec {
            rows: 65536,
            ..base
        },
        Spec {
            rows: 65537,
            ..base
        },
        Spec { width: 7, ..base },
        Spec { width: 64, ..base },
        Spec { width: 65, ..base },
    ];
    for spec in specs {
        let observer = observation::Session::start(true);
        let data = Data::new(spec);
        let prepared = prepared(&data);
        let memory = prepared.session.memory().clone();
        let admitted = (32768..=65536).contains(&spec.rows) && (8..=64).contains(&spec.width);
        assert_eq!(
            rematerialization::admitted_shape_for_test(&prepared),
            admitted
        );
        execute(&data, &prepared);
        drop(prepared);
        assert_eq!(memory.snapshot().reserved_bytes, 0);
        let observed = observer.finish();
        assert_eq!(observed["admissions"], usize::from(admitted));
        assert_eq!(
            observed["projection_rows"],
            spec.rows * if admitted { 2 } else { 1 }
        );
    }
}

#[test]
fn rematerialization_grammar_and_source_nonadmission_keep_native_results() {
    let data = Data::new(matrix()[0]);
    for deep in [false, true] {
        let mut query = plan(
            data.spec,
            DatasetUri::new("memory://rematerialization").unwrap(),
        );
        let VortexRelationalPlan::Sort(sort) = &mut query else {
            panic!()
        };
        let VortexRelationalPlan::Project(project) = &mut sort.input else {
            panic!()
        };
        project.expressions[2].1 = if deep {
            binary(
                binary(
                    binary(col("x"), BinaryOp::Multiply, lit(1)),
                    BinaryOp::Add,
                    col("y"),
                ),
                BinaryOp::Add,
                lit(0),
            )
        } else {
            binary(
                binary(col("x"), BinaryOp::Divide, lit(1)),
                BinaryOp::Add,
                col("y"),
            )
        };
        let observer = observation::Session::start(true);
        let prepared = data.prepare(query, 64 << 20);
        assert!(!rematerialization::admitted_shape_for_test(&prepared));
        execute(&data, &prepared);
        let memory = prepared.session.memory().clone();
        drop(prepared);
        assert_eq!(memory.snapshot().reserved_bytes, 0);
        assert_eq!(observer.finish()["admissions"], 0);
    }
    // The shape recognizer must refuse non-memory and dynamic declarations
    // before any source dispatch; these nodes are never executed.
    let mut prepared = prepared(&data);
    let PreparedRoot::Bound(root) = &mut prepared.root else {
        panic!()
    };
    let NodeKind::Sort { input, .. } = &mut root.kind else {
        panic!()
    };
    let NodeKind::Project { input, .. } = &mut input.kind else {
        panic!()
    };
    let NodeKind::Scan { source, .. } = &mut input.kind else {
        panic!()
    };
    let original = std::mem::replace(source, ScanSource::File(0));
    assert!(!rematerialization::admitted_shape_for_test(&prepared));
    let ScanSource::Memory(projection) = original else {
        panic!()
    };
    let PreparedRoot::Bound(root) = &mut prepared.root else {
        panic!()
    };
    let NodeKind::Sort { input, .. } = &mut root.kind else {
        panic!()
    };
    let NodeKind::Project { input, .. } = &mut input.kind else {
        panic!()
    };
    let NodeKind::Scan { source, .. } = &mut input.kind else {
        panic!()
    };
    *source = ScanSource::Batch {
        index: 0,
        projection,
    };
    assert!(!rematerialization::admitted_shape_for_test(&prepared));
    prepared.root = PreparedRoot::Dynamic(Box::new(|_| Err(failed("unexecuted declaration"))));
    assert!(!rematerialization::admitted_shape_for_test(&prepared));
}

#[test]
fn rematerialization_zero_reclaim_controls_and_whole_dependency_values() {
    for spec in matrix().into_iter().skip(4) {
        let observer = observation::Session::start(true);
        let data = Data::new(spec);
        let prepared = prepared(&data);
        let memory = prepared.session.memory().clone();
        execute(&data, &prepared);
        drop(prepared);
        assert_eq!(memory.snapshot().reserved_bytes, 0);
        let observed = observer.finish();
        let admitted = matches!(
            spec.profile,
            "wide_unused" | "wide_dependencies" | "all_null"
        );
        assert_eq!(observed["admissions"], usize::from(admitted));
        if !admitted {
            assert_eq!(observed["reclaimed_bytes"], 0);
        }
        if spec.profile == "wide_dependencies" {
            assert_eq!(observed["dependencies"], 67);
        }
        if spec.profile == "wide_unused" {
            assert_eq!(observed["dependencies"], 4);
        }
    }
}

#[test]
fn rematerialization_late_overflow_precedes_any_sorted_delivery() {
    let mut messages = Vec::new();
    for enabled in [false, true] {
        let observer = observation::Session::start(enabled);
        let mut data = Data::new(matrix()[0]);
        let last = data.spec.rows - 1;
        data.x[last] = Some(i64::MAX);
        data.y[last] = Some(1);
        let prepared = prepared(&data);
        let memory = prepared.session.memory().clone();
        let mut delivered = 0;
        let failure = prepared.for_each_batch(&CancellationToken::default(), |_, _| {
            delivered += 1;
            Ok(())
        });
        let Err(error) = failure else {
            panic!("overflow unexpectedly completed")
        };
        messages.push(error.to_string());
        assert_eq!(delivered, 0);
        assert_eq!(prepared.snapshot().completed_executions, 0);
        drop(prepared);
        assert_eq!(memory.snapshot().reserved_bytes, 0);
        let observed = observer.finish();
        assert!(observed["projection_rows"].as_u64().unwrap() > 0);
        assert_eq!(observed["regenerated_rows"], 0);
    }
    assert_eq!(messages[0], messages[1]);
    assert!(messages[0].contains("overflow"));
}

#[test]
fn rematerialization_admission_and_rebuild_denials_release_private_owners() {
    let data = Data::new(matrix()[0]);
    for available in [1_u64, 100_000] {
        let observer = observation::Session::start(true);
        let prepared = prepared(&data);
        let memory = prepared.session.memory().clone();
        let snapshot = memory.snapshot();
        let pressure = memory
            .reserve(snapshot.limit_bytes - snapshot.reserved_bytes - available)
            .unwrap();
        assert!(
            prepared
                .for_each_batch(&CancellationToken::default(), |_, _| Ok(()))
                .is_err()
        );
        assert_eq!(prepared.snapshot().completed_executions, 0);
        assert!(memory.snapshot().denied_reservations > 0);
        drop(pressure);
        let observed = observer.finish();
        assert_eq!(observed["projection_rows"], 0);
        let retry = observation::Session::start(true);
        execute(&data, &prepared);
        assert_eq!(retry.finish()["admissions"], 1);
        drop(prepared);
        assert_eq!(memory.snapshot().reserved_bytes, 0);
    }
    let observer = observation::Session::start(true);
    let prepared = prepared(&data);
    let memory = prepared.session.memory().clone();
    let held = Rc::new(RefCell::new(None));
    let hook_held = Rc::clone(&held);
    observer.before_rebuild(move |context| {
        let snapshot = context.memory().snapshot();
        *hook_held.borrow_mut() = Some(
            context
                .memory()
                .reserve(snapshot.limit_bytes - snapshot.reserved_bytes)?,
        );
        Ok(())
    });
    assert!(
        prepared
            .for_each_batch(&CancellationToken::default(), |_, _| Ok(()))
            .is_err()
    );
    assert_eq!(prepared.snapshot().completed_executions, 0);
    held.borrow_mut().take();
    let observed = observer.finish();
    assert_eq!(observed["validated_rows"], data.spec.rows);
    assert_eq!(observed["regenerated_rows"], 0);
    drop(prepared);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    assert!(memory.snapshot().denied_reservations > 0);
}

#[test]
fn rematerialization_cancellation_and_consumer_failure_never_complete() {
    let data = Data::new(matrix()[0]);
    for failure in [
        "pre_cancel",
        "rebuild_first",
        "rebuild_second",
        "consumer_first",
        "consumer_second",
    ] {
        let observer = observation::Session::start(true);
        let prepared = prepared(&data);
        let memory = prepared.session.memory().clone();
        let cancel = CancellationToken::default();
        if failure == "pre_cancel" {
            cancel.cancel();
        }
        if failure.starts_with("rebuild") {
            let at = if failure == "rebuild_first" { 1 } else { 2 };
            let mut calls = 0;
            observer.before_rebuild(move |context| {
                calls += 1;
                if calls == at {
                    context.cancellation().cancel();
                }
                Ok(())
            });
        }
        let mut delivered = 0;
        let result = prepared.for_each_batch(&cancel, |_, _| {
            delivered += 1;
            if failure == "consumer_first" || (failure == "consumer_second" && delivered == 2) {
                return Err(failed("injected native consumer failure"));
            }
            Ok(())
        });
        assert!(result.is_err(), "{failure}");
        assert_eq!(prepared.snapshot().completed_executions, 0);
        if failure == "pre_cancel" || failure == "rebuild_first" {
            assert_eq!(delivered, 0);
        }
        if failure == "rebuild_second" {
            assert_eq!(delivered, 1);
        }
        observer.finish();
        let retry = observation::Session::start(true);
        execute(&data, &prepared);
        assert_eq!(retry.finish()["admissions"], 1);
        drop(prepared);
        assert_eq!(memory.snapshot().reserved_bytes, 0);
    }
}

#[test]
fn rematerialization_published_alias_and_slice_keep_credit_until_last_drop() {
    let observer = observation::Session::start(true);
    let data = Data::new(matrix()[0]);
    let prepared = prepared(&data);
    let memory = prepared.session.memory().clone();
    let mut child = None;
    let mut slice = None;
    let mut execution = None;
    let result = prepared
        .for_each_batch(&CancellationToken::default(), |array, context| {
            if child.is_none() {
                let value =
                    crate::local_primitives::logical_field_from_native_array(&array, "d000")?;
                slice = Some(value.slice(0..3).map_err(vortex_error)?);
                child = Some(value);
                execution = Some(context.native_session().create_execution_ctx());
            }
            Ok(())
        })
        .unwrap();
    assert_eq!(result.output_rows, data.spec.rows as u64);
    drop((result, prepared));
    let before = memory.snapshot().reserved_bytes;
    assert!(before > 0);
    drop(child);
    assert_eq!(memory.snapshot().reserved_bytes, before);
    let values = slice
        .as_ref()
        .unwrap()
        .clone()
        .execute::<PrimitiveArray>(execution.as_mut().unwrap())
        .unwrap();
    assert_eq!(values.len(), 3);
    drop((values, slice, execution));
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    let observed = observer.finish();
    assert_eq!(observed["regenerated_rows"], data.spec.rows);
    assert!(observed["reclaimed_bytes"].as_u64().unwrap() > 0);
}
