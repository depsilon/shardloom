# Project/Sort derived-payload rematerialization — design draft

Status: primary source-grounded design only. No experiment protocol, candidate
implementation, measurement, retention decision or phase closure follows from
this draft. It prepares conditional row 8 while row 7 attribution builds.

## Concrete current caller and retained dependency

`local_primitive_relational_transform.rs:20-45` evaluates every projected
expression into native arrays before passing the struct to its consumer.
`run_sort` at lines 107-146 feeds that struct into the existing resident Sort or
explicitly permitted native Ordering. `native_relational_sort.rs:67-88` retains
the array in a native Batch/Table while its keys have their own descriptors.
The resulting Project -> Sort path therefore retains non-key derived payloads
until sorted output gathering. This is a real operator lifetime, beyond the
historical 25-case Batch/Table owner screen.

The first finite mechanism should restrict itself to a statically bound
Sort(Project(ScanSource::Memory)) tree. The same prepared resident source already
holds immutable dependencies for the duration of execution. One-shot batch
sources, file regeneration, filters, joins, dynamic roots, outer parameters,
effectful producers and arbitrary dependency-graph replay are excluded. This
does not make the broader rematerialization owner complete.

## Candidate mechanics to freeze before implementation

1. Admit only projected scalar Int64 expressions with a small explicit recursive
   grammar: Int64 columns/literals and selected checked Int64 arithmetic using
   the existing bound expression evaluator. Each admitted sort key must be a
   direct same-name input column, so releasing non-key derived arrays cannot
   change comparison, NULL order or stable source ordinal semantics. Aliases,
   constants and derived sort keys are separate zero-reclaim/nonadmission
   controls. The exact grammar, depth and minimum useful shape still need a
   frozen protocol; no post-measurement admission tuning is allowed.
2. Use existing `Expression::visit_columns` to identify the whole input closure,
   including direct output columns and keys. Retain its native source arrays
   under the original grant. The original bound expressions stay borrowed from
   the prepared tree; there is no independently mutable cache or recipe store.
   Charge all additional field/key metadata and container capacities before
   allocation. A temporary Sort spec may gather only required dependency fields,
   preventing unrelated source columns from becoming extra copy work.
3. For each original input batch, evaluate the full original projection in the
   original expression order, before any output is delivered. Record actual
   native credits, then drop the temporary projected struct and every derived
   alias before retaining the original dependency batch in Sort. This preserves
   eager expression errors and measures real reclamation; it cannot treat an
   aliased buffer's logical size as freed memory.
4. Sort only unchanged keys with the existing ordinal/table implementation.
   On each ordered native dependency batch, evaluate the same projection exactly
   once and synchronously consume it. Rebuild is bounded by the ordinary output
   batch size and original native grant. No recursive retry, regeneration loop,
   extra source open, new execution grant or source replay is permitted.
5. Keep the recipe and dependencies within one operation. No derived array is
   published before its original owner is released. Completed or escaped result
   aliases are never revoked. Cancellation/consumer errors end the operation,
   drop recipe/container/dependency owners and preserve existing certification
   and cleanup rules. A later operation starts from its own original prepared
   source admission, rather than reusing evicted state.

This is rematerialization of a private non-key projection at a sort boundary,
not a general cache, source refresh, output revocation or spill replacement.
The provider classification remains existing Vortex-native arrays, existing
expression evaluation and the shared native sort/gather. No dependency or
external execution provider is required.

## Required comparison and adversarial proof

Freeze complete ordinary-retain, existing-native-spill and regenerate roles.
All roles use the same source, projection, sort, public synchronous batch
consumer, original native grant, complete output/schema witnesses and source
completion count. Existing spill permission uses its admitted 1-MiB minimum,
actual disk quota and cleanup. The ordinary role must fit its declared
comparison grant; a separate pressure case may prove deterministic refusal
versus admitted completion without counting refusal as a timing win.

Candidate-relevant shapes should reuse the historical one/eight/64-column
dimensions and small/large row counts, with nullable inputs, duplicate sort
keys and stable ordinal witnesses. Freeze matched controls for source aliases,
constants, derived keys, small inputs, non-Int64 expressions and wide unused
source fields. A native batch consumer avoids the complete JSON collector cap;
every batch and the entire result remain independently checked. Any secondary
retained-result consumer needs its own full dependency/result overlap accounting.

The record must distinguish initial projection allocation, credits genuinely
released after the last owner, pinned input/key/recipe bytes, reconstruction
headroom, regenerated rows/columns and final zero credits. A cumulative native
pool peak is not a reconstruction high-water mark; sample the transition or use
an existing scoped owner counter without inventing a process-RSS guarantee.
Alias/slice controls must show zero reclaim until the final real owner drops.

Complete-workflow engine cost must include initial projection validation,
admission, dependency retention/gather, sorting, reconstruction and final native
certification. Preparation, synchronous sink work, result release and all owner
destruction stay in their corresponding complete-workflow clocks. Compare the
same engine clock in all roles and retain every sample/cohort. Thresholds,
repeatability, memory/control gates and retain-versus-spill policy are unresolved
design decisions that must be fixed before implementation or observations.

Negative tests must cover late checked arithmetic failure before output,
nullable/all-null inputs, unchanged stable ties, unsupported recipe admission,
denied recipe/rebuild capacity, cancellation before and during reconstruction,
failing consumers and final cleanup. The existing sort/spill and result-alias
tests remain necessary but do not substitute for these new composition tests.

## Source references

- `shardloom-vortex/src/local_primitive_relational_transform.rs`
- `shardloom-vortex/src/local_primitive_relational_transform_bind.rs`
- `shardloom-vortex/src/local_primitive_prepared_relational.rs` (Node/ScanSource,
  `detach_ordering_input`, public native/JSON batch consumers)
- `shardloom-vortex/src/local_primitives/native_relational_sort.rs`
- `shardloom-vortex/src/local_primitives/native_relational_batch.rs`
- `shardloom-vortex/src/local_primitives/native_relational_expression.rs`
- `shardloom-vortex/src/local_primitives/native_capacity.rs`
- `docs/benchmarks/native-rematerialization-owners-2026-10-07.md`
- `docs/architecture/native-roadmap-reconciliation-2026-10-18.md`
- `docs/architecture/native-roadmap-verification-contracts-2026-10-18.md`

No listed source establishes the proposed candidate's benefit. Full dependency
and retain/spill/regenerate evidence remains work for this investigation.
