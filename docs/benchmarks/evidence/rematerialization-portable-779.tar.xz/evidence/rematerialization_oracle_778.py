"""Independent full-value fixture and oracle for frozen rematerialization protocol 778."""

from __future__ import annotations

import hashlib
import struct
from pathlib import Path
from typing import Iterator


MAX_ROWS = 65_536
MAX_FIELDS = 128
PROTOCOL_PATH = Path(__file__).with_name("rematerialization-protocol-778.json")
PROFILES = frozenset(("mixed", "aliases", "constants", "derived_key", "boolean",
                      "wide_unused", "wide_dependencies", "all_null"))


def _check(cell: dict, rows_override: int | None = None) -> int:
    rows = cell["rows"] if rows_override is None else rows_override
    if not isinstance(rows, int) or isinstance(rows, bool) or not 0 <= rows <= MAX_ROWS:
        raise ValueError(f"rows must be an integer in 0..={MAX_ROWS}")
    fields = source_fields(cell)
    if len(fields) > MAX_FIELDS:
        raise ValueError(f"fixture has more than {MAX_FIELDS} source fields")
    return rows


def source_fields(cell: dict) -> list[tuple[str, str, bool]]:
    """Return (name, scalar type, nullable) in the frozen source schema order."""
    if cell["profile"] not in PROFILES:
        raise ValueError("unknown fixture profile")
    fields: list[tuple[str, str, bool]] = [
        ("k", "i64", True),
        ("ordinal", "i64", False),
        ("x", "i64", True),
        ("y", "i64", True),
    ]
    profile = cell["profile"]
    if profile == "boolean":
        fields.append(("flag", "bool", False))
    elif profile == "wide_unused":
        fields.extend((f"u{j:03}", "i64", False) for j in range(64))
    elif profile == "wide_dependencies":
        fields.extend((f"x{j:03}", "i64", True) for j in range(64))
    return fields


def output_fields(cell: dict) -> list[tuple[str, str, bool]]:
    if cell["profile"] not in PROFILES:
        raise ValueError("unknown fixture profile")
    fields: list[tuple[str, str, bool]] = [("k", "i64", True), ("ordinal", "i64", False)]
    width = cell["derived"]
    if not isinstance(width, int) or isinstance(width, bool) or width < 0:
        raise ValueError("derived must be a nonnegative integer")
    profile = cell["profile"]
    derived_nullable = profile != "constants"
    fields.extend((f"d{j:03}", "i64", derived_nullable) for j in range(width))
    if profile == "boolean":
        fields.append(("flag", "bool", False))
    if len(fields) > MAX_FIELDS:
        raise ValueError(f"fixture has more than {MAX_FIELDS} output fields")
    return fields


def source_row(cell: dict, r: int) -> dict[str, int | bool | None]:
    _check(cell)
    if not isinstance(r, int) or isinstance(r, bool) or not 0 <= r < cell["rows"]:
        raise ValueError("row index outside declared source")
    return _source_row(cell, r)


def _source_row(cell: dict, r: int) -> dict[str, int | bool | None]:
    profile = cell["profile"]
    x = None if r % 11 == 0 or profile == "all_null" else (r * 13 % 100_003) - 50_001
    row: dict[str, int | bool | None] = {
        "k": None if r % 31 == 0 else (r * 17 % 257) - 128,
        "ordinal": r,
        "x": x,
        "y": None if r % 17 == 0 else (r * 7 % 10_007) - 5_003,
    }
    if profile == "boolean":
        row["flag"] = r % 3 == 0
    elif profile == "wide_unused":
        row.update((f"u{j:03}", r * 3 + j) for j in range(64))
    elif profile == "wide_dependencies":
        row.update((f"x{j:03}", None if x is None else x + j * 5) for j in range(64))
    return row


def output_row(cell: dict, r: int) -> dict[str, int | bool | None]:
    if cell["profile"] not in PROFILES:
        raise ValueError("unknown fixture profile")
    if not isinstance(r, int) or isinstance(r, bool) or not 0 <= r < MAX_ROWS:
        raise ValueError("row index outside fixture limits")
    source = _source_row(cell, r)
    profile = cell["profile"]
    row: dict[str, int | bool | None] = {"k": source["k"], "ordinal": r}
    for j in range(cell["derived"]):
        if profile == "constants":
            value: int | None = j + 1
        elif profile == "aliases":
            value = source["x"]  # type: ignore[assignment]
        else:
            x_name = f"x{j:03}" if profile == "wide_dependencies" else "x"
            x_value, y_value = source[x_name], source["y"]
            if x_value is None or y_value is None:
                value = None
            else:
                value = x_value * (j + 1) + y_value  # type: ignore[operator]
        row[f"d{j:03}"] = value
    if profile == "boolean":
        row["flag"] = source["flag"]
    return row


def ordered_indices(cell: dict, rows_override: int | None = None) -> list[int]:
    rows = _check(cell, rows_override)
    key_name = "d000" if cell["profile"] == "derived_key" else "k"
    values = [output_row(cell, r).get(key_name) for r in range(rows)]
    return sorted(range(rows), key=lambda r: (values[r] is None, values[r] if values[r] is not None else 0))


def _pack(value: int | bool | None, type_name: str) -> bytes:
    if value is None:
        return b"\x00" + bytes(8)
    if type_name == "bool":
        if not isinstance(value, bool):
            raise ValueError("Boolean field has a non-Boolean value")
        return b"\x01" + struct.pack("<Q", int(value))
    if type_name != "i64" or not isinstance(value, int) or isinstance(value, bool):
        raise ValueError("Int64 field has a non-Int64 value")
    if not -(1 << 63) <= value < (1 << 63):
        raise ValueError("Int64 value is out of range")
    return b"\x01" + struct.pack("<q", value)


def _encode_row(row: dict, fields: list[tuple[str, str, bool]]) -> bytes:
    return b"".join(_pack(row[name], type_name) for name, type_name, _nullable in fields)


def source_bytes(cell: dict, rows_override: int | None = None) -> bytes:
    rows = _check(cell, rows_override)
    fields = source_fields(cell)
    return b"".join(_encode_row(_source_row(cell, r), fields) for r in range(rows))


def iter_expected_records(cell: dict, rows_override: int | None = None) -> Iterator[bytes]:
    """Yield ordered, encoded output records one at a time."""
    rows = _check(cell, rows_override)
    fields = output_fields(cell)
    for index in ordered_indices(cell, rows):
        yield _encode_row(output_row(cell, index), fields)


def expected_bytes(cell: dict, rows_override: int | None = None) -> bytes:
    return b"".join(iter_expected_records(cell, rows_override))


def verify_witness(path: str | Path, expected_bytes_value: bytes, sha256: str) -> bool:
    """Require an exact byte-for-byte witness and its expected SHA-256 digest."""
    try:
        raw = Path(path).read_bytes()
    except (OSError, ValueError):
        return False
    return (
        len(raw) == len(expected_bytes_value)
        and raw == expected_bytes_value
        and hashlib.sha256(raw).hexdigest() == sha256
        and hashlib.sha256(expected_bytes_value).hexdigest() == sha256
    )
