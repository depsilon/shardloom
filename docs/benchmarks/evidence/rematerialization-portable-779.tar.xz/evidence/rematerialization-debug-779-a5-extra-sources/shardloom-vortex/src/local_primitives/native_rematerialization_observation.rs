//! Bounded test evidence and fault injection; absent from production builds.

use super::NativeExecutionContext;
use shardloom_core::Result;
use std::cell::RefCell;

#[derive(Default)]
struct State {
    active: bool,
    enabled: bool,
    projection_rows: usize,
    projection_batches: usize,
    admissions: usize,
    source_rows: usize,
    derived: usize,
    dependencies: usize,
    depth: usize,
    metadata_bytes: u64,
    headroom_bytes: u64,
    validated_rows: usize,
    regenerated_rows: usize,
    reclaimed_bytes: u64,
    rebuild_batches: usize,
    transitions: Vec<serde_json::Value>,
    before_rebuild: Option<Box<dyn FnMut(&NativeExecutionContext<'_>) -> Result<()>>>,
}

thread_local! {
    static STATE: RefCell<State> = RefCell::new(State { enabled: true, ..State::default() });
}

pub(super) struct Session;

impl Session {
    pub(super) fn start(enabled: bool) -> Self {
        STATE.with(|state| {
            assert!(!state.borrow().active);
            *state.borrow_mut() = State {
                active: true,
                enabled,
                ..State::default()
            };
        });
        Self
    }

    pub(super) fn before_rebuild(
        &self,
        hook: impl FnMut(&NativeExecutionContext<'_>) -> Result<()> + 'static,
    ) {
        STATE.with(|state| state.borrow_mut().before_rebuild = Some(Box::new(hook)));
    }

    pub(super) fn finish(self) -> serde_json::Value {
        STATE.with(|state| {
            let state = state.borrow();
            serde_json::json!({
                "enabled":state.enabled,"projection_rows":state.projection_rows,
                "projection_batches":state.projection_batches,"admissions":state.admissions,
                "source_rows":state.source_rows,"derived":state.derived,
                "dependencies":state.dependencies,"depth":state.depth,
                "metadata_bytes":state.metadata_bytes,"headroom_bytes":state.headroom_bytes,
                "validated_rows":state.validated_rows,"regenerated_rows":state.regenerated_rows,
                "reclaimed_bytes":state.reclaimed_bytes,"rebuild_batches":state.rebuild_batches,
                "transitions":state.transitions
            })
        })
    }
}

impl Drop for Session {
    fn drop(&mut self) {
        STATE.with(|state| {
            *state.borrow_mut() = State {
                enabled: true,
                ..State::default()
            }
        });
    }
}

pub(super) fn enabled() -> bool {
    STATE.with(|state| state.borrow().enabled)
}

pub(super) fn projection(rows: usize) {
    STATE.with(|state| {
        let mut state = state.borrow_mut();
        if state.active {
            state.projection_rows += rows;
            state.projection_batches += 1;
        }
    });
}

pub(super) fn admitted(
    rows: usize,
    derived: usize,
    dependencies: usize,
    depth: usize,
    metadata: u64,
    headroom: u64,
) {
    STATE.with(|state| {
        let mut state = state.borrow_mut();
        if state.active {
            state.admissions += 1;
            state.source_rows = rows;
            state.derived = derived;
            state.dependencies = dependencies;
            state.depth = depth;
            state.metadata_bytes = metadata;
            state.headroom_bytes = headroom;
        }
    });
}

pub(super) fn reclaimed(rows: usize, before: u64, held: u64, released: u64) {
    STATE.with(|state| {
        let mut state = state.borrow_mut();
        if state.active {
            assert!(held >= released && state.transitions.len() < 512);
            state.validated_rows += rows;
            state.reclaimed_bytes += held - released;
            state
                .transitions
                .push(serde_json::json!({"kind":"private_release","rows":rows,
                "before":before,"held":held,"after":released,"released":held-released}));
        }
    });
}

pub(super) fn before_rebuild(context: &NativeExecutionContext<'_>) -> Result<()> {
    let mut hook = STATE.with(|state| state.borrow_mut().before_rebuild.take());
    if let Some(hook) = &mut hook {
        hook(context)?;
    }
    STATE.with(|state| state.borrow_mut().before_rebuild = hook);
    context.check_cancelled()
}

pub(super) fn rebuilt(rows: usize, live: u64) {
    STATE.with(|state| {
        let mut state = state.borrow_mut();
        if state.active {
            assert!(state.transitions.len() < 512);
            state.regenerated_rows += rows;
            state.rebuild_batches += 1;
            state
                .transitions
                .push(serde_json::json!({"kind":"rebuilt","rows":rows,"live":live}));
        }
    });
}
