//! Private projection owners may be regenerated once after stable resident sort.
//!
//! The original projection is evaluated in order before any private owner is
//! released. The immutable source, complete dependency closure and recipe stay
//! within this operation's existing grant; published arrays are never revoked.

use super::{
    ArrayRef, DType, MemoryLease, Metrics, NativeExecutionContext, Node, NodeKind, PreparedRoot,
    PreparedVortexRelational, Result, ScanSource, failed,
    native_relational_expression::{Expression, Kind},
    native_relational_sort::{Sort, Spec},
    project_selected_batch, transform,
};
use shardloom_core::BinaryOp;
use vortex::array::dtype::PType;

const MAX_FIELDS: usize = 128;

struct Shape<'a> {
    scan: &'a Node,
    project: &'a Node,
    expressions: &'a [Expression],
    spec: &'a Spec,
    dependencies: [bool; MAX_FIELDS],
    rows: usize,
    derived: usize,
    depth: usize,
}

struct Recipe<'a> {
    shape: Shape<'a>,
    spec: Spec,
    _metadata: MemoryLease,
    headroom: MemoryLease,
}

impl PreparedVortexRelational {
    pub(super) fn run_rematerialized_sort(
        &self,
        node: &Node,
        context: &NativeExecutionContext<'_>,
        metrics: &Metrics<'_>,
        batch_rows: usize,
        parameter: Option<&ArrayRef>,
        consume: &mut dyn FnMut(ArrayRef) -> Result<()>,
    ) -> Result<bool> {
        #[cfg(all(test, feature = "vortex-write"))]
        if !super::rematerialization_observation::enabled() {
            return Ok(false);
        }
        if parameter.is_some()
            || metrics.input.is_some()
            || batch_rows == 0
            || batch_rows > super::BATCH_ROWS
            || !matches!(&self.root, PreparedRoot::Bound(root) if std::ptr::eq(root.as_ref(), node))
        {
            return Ok(false);
        }
        #[cfg(feature = "vortex-write")]
        if metrics.spill.is_some() {
            return Ok(false);
        }
        let Some(shape) = Shape::admit(node)? else {
            return Ok(false);
        };
        let recipe = Recipe::new(shape, batch_rows, context)?;
        let mut sort = Sort::new(&recipe.spec, context.memory())?;
        let mut validated = 0usize;
        self.run(
            recipe.shape.scan,
            context,
            metrics,
            batch_rows,
            None,
            &mut |array| {
                context.check_cancelled()?;
                #[cfg(all(test, feature = "vortex-write"))]
                let before = context.memory().snapshot().reserved_bytes;
                let projected = transform::project(
                    &array,
                    &recipe.shape.project.fields,
                    recipe.shape.expressions,
                    context,
                )?;
                #[cfg(all(test, feature = "vortex-write"))]
                let held = context.memory().snapshot().reserved_bytes;
                drop(projected);
                #[cfg(all(test, feature = "vortex-write"))]
                super::rematerialization_observation::reclaimed(
                    array.len(),
                    before,
                    held,
                    context.memory().snapshot().reserved_bytes,
                );
                validated = validated
                    .checked_add(array.len())
                    .filter(|rows| *rows <= recipe.shape.rows)
                    .ok_or_else(|| failed("projection validation exceeded its immutable source"))?;
                let dependencies = project_selected_batch(&array, &recipe.spec.fields, context)?;
                sort.build(dependencies, context)
            },
        )?;
        if validated != recipe.shape.rows {
            return Err(failed(
                "projection validation did not cover its immutable source",
            ));
        }
        drop(recipe.headroom);
        let mut regenerated = 0usize;
        sort.finish(context, batch_rows, &mut |array| {
            context.check_cancelled()?;
            regenerated = regenerated
                .checked_add(array.len())
                .filter(|rows| *rows <= validated)
                .ok_or_else(|| failed("projection regeneration exceeded validated cardinality"))?;
            #[cfg(all(test, feature = "vortex-write"))]
            super::rematerialization_observation::before_rebuild(context)?;
            let output = transform::project(
                &array,
                &recipe.shape.project.fields,
                recipe.shape.expressions,
                context,
            )?;
            #[cfg(all(test, feature = "vortex-write"))]
            super::rematerialization_observation::rebuilt(
                array.len(),
                context.memory().snapshot().reserved_bytes,
            );
            context.check_cancelled()?;
            consume(output)?;
            context.check_cancelled()
        })?;
        if regenerated != validated {
            return Err(failed(
                "projection regeneration did not cover its validated input",
            ));
        }
        Ok(true)
    }
}

impl<'a> Shape<'a> {
    fn admit(node: &'a Node) -> Result<Option<Self>> {
        let NodeKind::Sort {
            input: project,
            spec,
        } = &node.kind
        else {
            return Ok(None);
        };
        let NodeKind::Project {
            input: scan,
            expressions,
        } = &project.kind
        else {
            return Ok(None);
        };
        let NodeKind::Scan {
            source: ScanSource::Memory(source),
            plan,
            residual,
            ..
        } = &scan.kind
        else {
            return Ok(None);
        };
        if !(32768..=65536).contains(&source.source_rows())
            || plan.filter.is_some()
            || residual.is_some()
            || plan.residual_predicate.is_some()
            || scan.fields.len() > MAX_FIELDS
            || project.fields.len() > MAX_FIELDS
            || expressions.len() != project.fields.len()
            || !(1..=4).contains(&spec.keys.len())
            || scan
                .fields
                .iter()
                .chain(&project.fields)
                .any(|(name, _)| name.len() > 256)
        {
            return Ok(None);
        }
        let mut shape = Self {
            scan,
            project,
            expressions,
            spec,
            dependencies: [false; MAX_FIELDS],
            rows: source.source_rows(),
            derived: 0,
            depth: 0,
        };
        for ((name, dtype), expression) in project.fields.iter().zip(expressions) {
            if !matches!(dtype, DType::Primitive(PType::I64, _)) {
                return Ok(None);
            }
            let Some((depth, has_column)) = grammar(expression, 0) else {
                return Ok(None);
            };
            match &expression.kind {
                Kind::Column(column) if column == name => {}
                Kind::Binary(..) if has_column => shape.derived += 1,
                _ => return Ok(None),
            }
            shape.depth = shape.depth.max(depth);
            expression.visit_columns(&mut |column| {
                let index = scan
                    .fields
                    .iter()
                    .position(|(name, _)| name == column)
                    .ok_or_else(|| failed("bound projection dependency is absent from input"))?;
                shape.dependencies[index] = true;
                Ok(())
            })?;
        }
        if !(8..=64).contains(&shape.derived) {
            return Ok(None);
        }
        for key in &spec.keys {
            let Some(index) = project
                .fields
                .iter()
                .position(|(name, _)| name == key.column.as_str())
            else {
                return Err(failed("bound sort key is absent from its projection"));
            };
            if !matches!(&expressions[index].kind, Kind::Column(name) if name == key.column.as_str())
            {
                return Ok(None);
            }
        }
        Ok(Some(shape))
    }
}

fn grammar(expression: &Expression, depth: usize) -> Option<(usize, bool)> {
    if !matches!(expression.dtype, DType::Primitive(PType::I64, _)) {
        return None;
    }
    match &expression.kind {
        Kind::Column(_) => Some((depth, true)),
        Kind::Literal(_) => Some((depth, false)),
        Kind::Binary(left, BinaryOp::Add | BinaryOp::Subtract | BinaryOp::Multiply, right)
            if depth < 2 =>
        {
            let (left_depth, left_column) = grammar(left, depth + 1)?;
            let (right_depth, right_column) = grammar(right, depth + 1)?;
            Some((left_depth.max(right_depth), left_column || right_column))
        }
        _ => None,
    }
}

impl<'a> Recipe<'a> {
    fn new(
        shape: Shape<'a>,
        batch_rows: usize,
        context: &NativeExecutionContext<'_>,
    ) -> Result<Self> {
        let dependencies = shape.dependencies.iter().filter(|used| **used).count();
        let metadata_bytes = 1024_u64
            .checked_add(4096 * (dependencies + shape.spec.keys.len()) as u64)
            .ok_or_else(|| failed("projection recipe metadata capacity overflow"))?;
        let metadata = context.memory().reserve(metadata_bytes)?;
        let fields = shape
            .scan
            .fields
            .iter()
            .enumerate()
            .filter(|(index, _)| shape.dependencies[*index])
            .map(|(_, field)| field.clone())
            .collect();
        let spec = Spec {
            fields,
            keys: shape.spec.keys.clone(),
            names: shape.spec.names.clone(),
            copy_policy: shape.spec.copy_policy,
        };
        let headroom_bytes = reconstruction_headroom(
            batch_rows,
            shape.project.fields.len(),
            dependencies,
            spec.keys.len(),
            shape.depth,
        )?;
        let headroom = context.memory().reserve(headroom_bytes)?;
        #[cfg(all(test, feature = "vortex-write"))]
        super::rematerialization_observation::admitted(
            shape.rows,
            shape.derived,
            dependencies,
            shape.depth,
            metadata_bytes,
            headroom_bytes,
        );
        Ok(Self {
            shape,
            spec,
            _metadata: metadata,
            headroom,
        })
    }
}

fn reconstruction_headroom(
    batch: usize,
    output: usize,
    dependencies: usize,
    keys: usize,
    depth: usize,
) -> Result<u64> {
    let fields = (output as u64).checked_add(dependencies as u64);
    let schema = fields
        .and_then(|fields| fields.checked_add(keys as u64))
        .and_then(|fields| fields.checked_mul(4096));
    let per_row = fields
        .and_then(|fields| fields.checked_mul(16))
        .and_then(|bytes| {
            (depth as u64)
                .checked_add(1)
                .and_then(|depth| depth.checked_mul(128))
                .and_then(|scratch| bytes.checked_add(scratch))
        });
    schema
        .and_then(|schema| schema.checked_add(65536))
        .and_then(|fixed| {
            per_row
                .and_then(|bytes| bytes.checked_mul(batch as u64))
                .and_then(|batches| fixed.checked_add(batches))
        })
        .ok_or_else(|| failed("projection reconstruction headroom overflow"))
}

#[cfg(all(test, feature = "vortex-write"))]
pub(super) fn admitted_shape_for_test(prepared: &PreparedVortexRelational) -> bool {
    matches!(&prepared.root,PreparedRoot::Bound(root) if Shape::admit(root).unwrap().is_some())
}
