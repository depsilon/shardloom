//! Formula-defined fixtures and complete native consumer for protocol 778.

use super::*;
use crate::{
    relational_query::{
        VortexRelationalNullOrder, VortexRelationalOrderKey, VortexRelationalProject,
        VortexRelationalSort,
    },
    resident_memory_source::{MemoryColumn, MemoryColumnValues, MemorySourceBounds},
};
use shardloom_core::{BinaryOp, ExprId, Expression, ExpressionKind, ScalarValue};

#[derive(Clone, Copy)]
pub(super) struct Spec {
    pub(super) id: &'static str,
    pub(super) rows: usize,
    pub(super) width: usize,
    pub(super) profile: &'static str,
    pub(super) target: bool,
}

pub(super) fn matrix() -> Vec<Spec> {
    [
        ("mixed-32768-8", 32768, 8, "mixed", true),
        ("mixed-32768-64", 32768, 64, "mixed", true),
        ("mixed-65536-8", 65536, 8, "mixed", true),
        ("mixed-65536-64", 65536, 64, "mixed", true),
        ("small-256-64", 256, 64, "mixed", false),
        ("one-32768-1", 32768, 1, "mixed", false),
        ("aliases-32768-64", 32768, 64, "aliases", false),
        ("constants-32768-64", 32768, 64, "constants", false),
        ("derived-key-32768-8", 32768, 8, "derived_key", false),
        ("boolean-32768-8", 32768, 8, "boolean", false),
        ("wide-unused-32768-64", 32768, 64, "wide_unused", false),
        (
            "wide-dependencies-32768-64",
            32768,
            64,
            "wide_dependencies",
            false,
        ),
        ("all-null-32768-8", 32768, 8, "all_null", false),
    ]
    .into_iter()
    .map(|(id, rows, width, profile, target)| Spec {
        id,
        rows,
        width,
        profile,
        target,
    })
    .collect()
}

pub(super) fn col(name: &str) -> Expression {
    Expression::column(ExprId::new(name).unwrap(), ColumnRef::new(name).unwrap())
}

pub(super) fn lit(value: i64) -> Expression {
    Expression::literal(ExprId::new("literal").unwrap(), ScalarValue::Int64(value))
}

pub(super) fn binary(left: Expression, op: BinaryOp, right: Expression) -> Expression {
    Expression::new(
        ExprId::new("arithmetic").unwrap(),
        ExpressionKind::Binary {
            left: Box::new(left),
            op,
            right: Box::new(right),
        },
    )
}

pub(super) fn plan(spec: Spec, uri: DatasetUri) -> VortexRelationalPlan {
    let mut expressions = vec![("k".into(), col("k")), ("ordinal".into(), col("ordinal"))];
    for j in 0..spec.width {
        let expression = match spec.profile {
            "aliases" => col("x"),
            "constants" => lit(i64::try_from(j + 1).unwrap()),
            _ => {
                let source = if spec.profile == "wide_dependencies" {
                    format!("x{j:03}")
                } else {
                    "x".into()
                };
                binary(
                    binary(
                        col(&source),
                        BinaryOp::Multiply,
                        lit(i64::try_from(j + 1).unwrap()),
                    ),
                    BinaryOp::Add,
                    col("y"),
                )
            }
        };
        expressions.push((format!("d{j:03}"), expression));
    }
    if spec.profile == "boolean" {
        expressions.push(("flag".into(), col("flag")));
    }
    VortexRelationalPlan::Sort(Box::new(VortexRelationalSort {
        input: VortexRelationalPlan::Project(Box::new(VortexRelationalProject {
            input: VortexRelationalPlan::Scan(VortexRelationalScan {
                source_uri: uri,
                projection: shardloom_plan::ProjectionRequest::All,
                predicate: None,
            }),
            expressions,
        })),
        keys: vec![VortexRelationalOrderKey {
            column: ColumnRef::new(if spec.profile == "derived_key" {
                "d000"
            } else {
                "k"
            })
            .unwrap(),
            descending: false,
            nulls: Some(VortexRelationalNullOrder::Last),
        }],
    }))
}

pub(super) struct Data {
    pub(super) spec: Spec,
    pub(super) keys: Vec<Option<i64>>,
    pub(super) ordinals: Vec<i64>,
    pub(super) x: Vec<Option<i64>>,
    pub(super) y: Vec<Option<i64>>,
    extra_names: Vec<String>,
    unused: Vec<Vec<i64>>,
    dependencies: Vec<Vec<Option<i64>>>,
    flag: Vec<Option<&'static str>>,
    flag_dtype: String,
}

impl Data {
    pub(super) fn new(spec: Spec) -> Self {
        let keys = (0..spec.rows)
            .map(|r| (!r.is_multiple_of(31)).then_some((r * 17 % 257) as i64 - 128))
            .collect();
        let ordinals = (0..spec.rows).map(|r| i64::try_from(r).unwrap()).collect();
        let x = (0..spec.rows)
            .map(|r| {
                (!r.is_multiple_of(11) && spec.profile != "all_null")
                    .then_some((r * 13 % 100003) as i64 - 50001)
            })
            .collect::<Vec<_>>();
        let y = (0..spec.rows)
            .map(|r| (!r.is_multiple_of(17)).then_some((r * 7 % 10007) as i64 - 5003))
            .collect();
        let extra_names = if spec.profile == "wide_unused" {
            (0..64).map(|j| format!("u{j:03}")).collect()
        } else if spec.profile == "wide_dependencies" {
            (0..64).map(|j| format!("x{j:03}")).collect()
        } else {
            Vec::new()
        };
        let unused = if spec.profile == "wide_unused" {
            (0..64)
                .map(|j| (0..spec.rows).map(|r| (r * 3 + j) as i64).collect())
                .collect()
        } else {
            Vec::new()
        };
        let dependencies = if spec.profile == "wide_dependencies" {
            (0..64)
                .map(|j| x.iter().map(|value| value.map(|v| v + j * 5)).collect())
                .collect()
        } else {
            Vec::new()
        };
        let flag = if spec.profile == "boolean" {
            (0..spec.rows)
                .map(|r| Some(if r.is_multiple_of(3) { "true" } else { "false" }))
                .collect()
        } else {
            Vec::new()
        };
        Self {
            spec,
            keys,
            ordinals,
            x,
            y,
            extra_names,
            unused,
            dependencies,
            flag,
            flag_dtype: serde_json::to_string(&DType::Bool(Nullability::NonNullable)).unwrap(),
        }
    }

    pub(super) fn columns(&self) -> Vec<MemoryColumn<'_>> {
        let mut columns = vec![
            MemoryColumn {
                name: "k",
                values: MemoryColumnValues::Int64(&self.keys),
            },
            MemoryColumn {
                name: "ordinal",
                values: MemoryColumnValues::Int64NonNullable(&self.ordinals),
            },
            MemoryColumn {
                name: "x",
                values: MemoryColumnValues::Int64(&self.x),
            },
            MemoryColumn {
                name: "y",
                values: MemoryColumnValues::Int64(&self.y),
            },
        ];
        for (name, values) in self.extra_names.iter().zip(&self.unused) {
            columns.push(MemoryColumn {
                name,
                values: MemoryColumnValues::Int64NonNullable(values),
            });
        }
        for (name, values) in self.extra_names.iter().zip(&self.dependencies) {
            columns.push(MemoryColumn {
                name,
                values: MemoryColumnValues::Int64(values),
            });
        }
        if self.spec.profile == "boolean" {
            columns.push(MemoryColumn {
                name: "flag",
                values: MemoryColumnValues::TypedJson {
                    dtype_json: &self.flag_dtype,
                    values: &self.flag,
                },
            });
        }
        columns
    }

    pub(super) fn source_dtype(&self) -> DType {
        let mut fields = vec![
            ("k".into(), i64_dtype(true)),
            ("ordinal".into(), i64_dtype(false)),
            ("x".into(), i64_dtype(true)),
            ("y".into(), i64_dtype(true)),
        ];
        fields.extend(self.extra_names.iter().map(|name| {
            (
                name.clone(),
                i64_dtype(self.spec.profile == "wide_dependencies"),
            )
        }));
        if self.spec.profile == "boolean" {
            fields.push(("flag".into(), DType::Bool(Nullability::NonNullable)));
        }
        DType::struct_(fields, Nullability::NonNullable)
    }

    pub(super) fn output_fields(&self) -> Vec<(String, DType)> {
        let mut fields = vec![
            ("k".into(), i64_dtype(true)),
            ("ordinal".into(), i64_dtype(false)),
        ];
        fields.extend((0..self.spec.width).map(|j| {
            (
                format!("d{j:03}"),
                i64_dtype(self.spec.profile != "constants"),
            )
        }));
        if self.spec.profile == "boolean" {
            fields.push(("flag".into(), DType::Bool(Nullability::NonNullable)));
        }
        fields
    }

    pub(super) fn output_dtype(&self) -> DType {
        DType::struct_(self.output_fields(), Nullability::NonNullable)
    }

    pub(super) fn source_bytes(&self) -> Vec<u8> {
        let mut bytes = Vec::with_capacity(
            self.spec.rows
                * (4 + self.extra_names.len() + usize::from(self.spec.profile == "boolean"))
                * 9,
        );
        for r in 0..self.spec.rows {
            for value in [self.keys[r], Some(self.ordinals[r]), self.x[r], self.y[r]] {
                push_value(&mut bytes, value);
            }
            for values in &self.unused {
                push_value(&mut bytes, Some(values[r]));
            }
            for values in &self.dependencies {
                push_value(&mut bytes, values[r]);
            }
            if self.spec.profile == "boolean" {
                push_value(&mut bytes, Some(i64::from(r.is_multiple_of(3))));
            }
        }
        bytes
    }

    fn derived(&self, r: usize, j: usize) -> Option<i64> {
        match self.spec.profile {
            "aliases" => self.x[r],
            "constants" => Some((j + 1) as i64),
            _ => {
                let x = if self.spec.profile == "wide_dependencies" {
                    self.dependencies[j][r]
                } else {
                    self.x[r]
                };
                x.zip(self.y[r]).map(|(x, y)| x * (j + 1) as i64 + y)
            }
        }
    }

    pub(super) fn expected_bytes(&self) -> Vec<u8> {
        let mut indices = (0..self.spec.rows).collect::<Vec<_>>();
        indices.sort_by_key(|&r| {
            let key = if self.spec.profile == "derived_key" {
                self.derived(r, 0)
            } else {
                self.keys[r]
            };
            (key.is_none(), key.unwrap_or(0))
        });
        let mut bytes = Vec::with_capacity(self.spec.rows * self.output_fields().len() * 9);
        for r in indices {
            push_value(&mut bytes, self.keys[r]);
            push_value(&mut bytes, Some(self.ordinals[r]));
            for j in 0..self.spec.width {
                push_value(&mut bytes, self.derived(r, j));
            }
            if self.spec.profile == "boolean" {
                push_value(&mut bytes, Some(i64::from(r.is_multiple_of(3))));
            }
        }
        bytes
    }

    pub(super) fn prepare(
        &self,
        query: VortexRelationalPlan,
        memory_bytes: u64,
    ) -> PreparedVortexRelational {
        self.prepare_counted(query, memory_bytes).0
    }

    pub(super) fn prepare_counted(
        &self,
        query: VortexRelationalPlan,
        memory_bytes: u64,
    ) -> (PreparedVortexRelational, usize) {
        let mut allocation = policy();
        allocation.resource_envelope.memory_budget_bytes = memory_bytes;
        let mut constructions = 0;
        let prepared = prepare_relational_with_schema(allocation, |schemas| {
            schemas.register_memory_source(
                DatasetUri::new("memory://rematerialization").unwrap(),
                |session| {
                    let source = ResidentMemorySource::from_columns(
                        session,
                        &self.columns(),
                        MemorySourceBounds {
                            max_input_rows: self.spec.rows.max(65536),
                            max_output_rows: self.spec.rows.max(65536),
                            ..MemorySourceBounds::default()
                        },
                    )?;
                    assert_eq!(source.dtype(), &self.source_dtype());
                    constructions += 1;
                    Ok(source)
                },
            )?;
            Ok(query)
        })
        .unwrap();
        assert_eq!(constructions, 1);
        (prepared, constructions)
    }
}

fn i64_dtype(nullable: bool) -> DType {
    DType::Primitive(
        PType::I64,
        if nullable {
            Nullability::Nullable
        } else {
            Nullability::NonNullable
        },
    )
}

fn push_value(bytes: &mut Vec<u8>, value: Option<i64>) {
    bytes.push(u8::from(value.is_some()));
    bytes.extend_from_slice(&value.unwrap_or(0).to_le_bytes());
}

pub(super) fn consume_bytes(
    array: &ArrayRef,
    fields: &[(String, DType)],
    context: &NativeExecutionContext<'_>,
    bytes: &mut Vec<u8>,
) -> Result<()> {
    use crate::local_primitives::native_relational_keys::Cell;
    let mut columns = ReservedVec::new(context.memory())?;
    columns.reserve(fields.len())?;
    for (name, dtype) in fields {
        let array = crate::local_primitives::logical_field_from_native_array(array, name)?;
        assert_eq!(array.dtype(), dtype);
        columns
            .values
            .push(native_relational_expression::keys(&array, context)?);
    }
    for row in 0..array.len() {
        for (column, (_, dtype)) in columns.values.iter().zip(fields) {
            let value = match column.cell(row)? {
                Cell::Null => None,
                Cell::NegativeInteger(v) => Some(v),
                Cell::NonnegativeInteger(v) => Some(i64::try_from(v).unwrap()),
                Cell::Boolean(v) if matches!(dtype, DType::Bool(_)) => Some(i64::from(v)),
                _ => panic!("native output changed its frozen scalar domain"),
            };
            push_value(bytes, value);
        }
    }
    Ok(())
}
