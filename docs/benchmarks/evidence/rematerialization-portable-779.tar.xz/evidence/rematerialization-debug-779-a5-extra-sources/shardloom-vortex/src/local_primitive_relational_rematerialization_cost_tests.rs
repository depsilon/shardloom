//! Guarded full public workflow; every value and every private owner is observed.

use super::super::rematerialization_observation as observation;
use super::{rematerialization_fixture::*, *};
use crate::relational_query::VortexRelationalSpillPolicy;
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{
    io::Write as _,
    path::Path,
    time::{Duration, Instant},
};

fn witness(root: &Path, bytes: &[u8], extension: &str) -> Value {
    let sha256 = Sha256::digest(bytes)
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect::<String>();
    let relative = format!("witnesses/{sha256}.{extension}");
    let path = root.join(&relative);
    if path.exists() {
        assert_eq!(fs::read(&path).unwrap(), bytes);
    } else {
        fs::write(&path, bytes).unwrap();
    }
    json!({"path":relative,"sha256":sha256,"bytes":bytes.len()})
}

#[allow(clippy::too_many_lines)] // The complete compared workflow includes all owners and consumption.
fn workflow(
    root: &Path,
    spec: Spec,
    role: &str,
    mode: &str,
    cohort: &str,
    sample: usize,
    warmup: bool,
) -> Value {
    let data = Data::new(spec);
    let fields = data.output_fields();
    let dtype = data.output_dtype();
    let source_witness = witness(root, &data.source_bytes(), "bin");
    let source_schema = witness(
        root,
        &serde_json::to_vec(&data.source_dtype()).unwrap(),
        "json",
    );
    let expected_schema = witness(root, &serde_json::to_vec(&dtype).unwrap(), "json");
    let capacity = spec.rows * fields.len() * 9;
    assert!(capacity <= 128 << 20);
    let mut actual = Vec::with_capacity(capacity);
    let workspace = root.join(format!(
        "spill-{}-{}-{role}-{mode}-{cohort}-{sample}-{warmup}",
        spec.id, spec.rows
    ));
    fs::create_dir(&workspace).unwrap();
    let observer = observation::Session::start(role == "regenerate");
    let started = Instant::now();
    let query = plan(spec, DatasetUri::new("memory://rematerialization").unwrap());
    let (prepared, resident_source_preparations) = data.prepare_counted(query, 64 << 20);
    let prepared = if role == "spill" {
        prepared
            .with_spill(VortexRelationalSpillPolicy::new(&workspace, 128 << 20, 1 << 20).unwrap())
            .unwrap()
    } else {
        prepared
    };
    let preparation_ns = started.elapsed().as_nanos();
    assert_eq!(prepared.output_dtype().as_ref(), Some(&dtype));
    let memory = prepared.session.memory().clone();
    let mut sink_time = Duration::ZERO;
    let mut batches = Vec::new();
    let mut actual_dtype = None;
    let started = Instant::now();
    let result = prepared
        .for_each_batch(&CancellationToken::default(), |array, context| {
            let sink_start = Instant::now();
            assert_eq!(array.dtype(), &dtype);
            if actual_dtype.is_none() {
                actual_dtype = Some(array.dtype().clone());
            }
            assert!(array.len() <= 2048);
            consume_bytes(&array, &fields, context, &mut actual)?;
            assert!(actual.len() <= capacity);
            batches.push(array.len());
            drop(array);
            sink_time += sink_start.elapsed();
            Ok(())
        })
        .unwrap();
    let consumed = started.elapsed();
    let timing =
        crate::local_primitives::query_timing::QueryTiming::from_elapsed(consumed, sink_time);
    assert_eq!(actual.len(), capacity);
    assert_eq!(result.output_rows, spec.rows as u64);
    assert_eq!(result.prepared_sources, 1);
    assert_eq!(result.prepared_file_sources, 0);
    let prepared_sources = result.prepared_sources;
    let prepared_file_sources = result.prepared_file_sources;
    assert_eq!(result.scan_rows_delivered, spec.rows as u64);
    assert!(result.native_io_certificate.is_certified());
    assert!(!result.native_io_certificate.side_effects.fallback_attempted);
    let certificate = json!({"certified":result.native_io_certificate.is_certified(),
        "fallback_attempted":result.native_io_certificate.side_effects.fallback_attempted,
        "spill_io_performed":result.native_io_certificate.side_effects.spill_io_performed,
        "complete_debug":format!("{:#?}",result.native_io_certificate)});
    let spill = result.spill.as_ref().map(|report| {
        assert!(report.owned_cleanup_completed && report.peak_disk_bytes <= report.quota_bytes && report.max_open_runs<=2);
        json!({"workspace":report.workspace,"quota_bytes":report.quota_bytes,"buffer_bytes":report.buffer_bytes,
            "peak_disk_bytes":report.peak_disk_bytes,"runs_written":report.runs_written,
            "runs_validated":report.runs_validated,"merge_passes":report.merge_passes,
            "max_open_runs":report.max_open_runs,"run_block_rows":report.run_block_rows,
            "owned_cleanup_completed":report.owned_cleanup_completed})
    });
    assert_eq!(spill.is_some(), role == "spill");
    let started = Instant::now();
    drop(result);
    let output_release_ns = started.elapsed().as_nanos();
    let snapshot = prepared.snapshot();
    assert_eq!(snapshot.completed_executions, 1);
    assert_eq!(snapshot.prepared_source_opens, 0);
    assert_eq!(snapshot.admitted_max_parallelism, 1);
    assert_eq!(snapshot.provider_background_workers, 0);
    let started = Instant::now();
    drop(prepared);
    let destruction_ns = started.elapsed().as_nanos();
    let final_memory = memory.snapshot();
    assert_eq!(final_memory.reserved_bytes, 0);
    assert_eq!(final_memory.denied_reservations, 0);
    assert_eq!(fs::read_dir(&workspace).unwrap().count(), 0);
    fs::remove_dir(&workspace).unwrap();
    let expected = data.expected_bytes();
    assert_eq!(actual, expected, "{} {} {role}", spec.id, spec.rows);
    let actual_witness = witness(root, &actual, "bin");
    let expected_witness = witness(root, &expected, "bin");
    let actual_schema = witness(
        root,
        &serde_json::to_vec(&actual_dtype.unwrap()).unwrap(),
        "json",
    );
    let observed = observer.finish();
    let active = role == "regenerate"
        && spec.rows >= 32768
        && spec.width >= 8
        && matches!(
            spec.profile,
            "mixed" | "wide_unused" | "wide_dependencies" | "all_null"
        );
    assert_eq!(observed["admissions"], usize::from(active));
    assert_eq!(
        observed["projection_rows"],
        spec.rows * if active { 2 } else { 1 }
    );
    if active {
        assert_eq!(observed["validated_rows"], spec.rows);
        assert_eq!(observed["regenerated_rows"], spec.rows);
        assert_eq!(observed["rebuild_batches"], spec.rows.div_ceil(2048));
        if spec.target {
            assert!(
                observed["reclaimed_bytes"].as_u64().unwrap()
                    >= (spec.rows * spec.width * 8) as u64
            );
        }
    }
    json!({"cell_id":spec.id,"rows":spec.rows,"width":spec.width,"profile":spec.profile,"target":spec.target,
        "role":role,"mode":mode,"cohort":cohort,"sample":sample,"warmup":warmup,
        "source_rows_witness":source_witness,"source_schema_witness":source_schema,
        "actual_rows_witness":actual_witness,"expected_rows_witness":expected_witness,
        "actual_schema_witness":actual_schema,"expected_schema_witness":expected_schema,
        "preparation_ns":preparation_ns,"engine_execution_ns":timing.execution.as_nanos(),
        "sink_consumption_ns":sink_time.as_nanos(),"execution_and_consumption_ns":consumed.as_nanos(),
        "output_release_ns":output_release_ns,"destruction_ns":destruction_ns,
        "complete_workflow_ns":preparation_ns+consumed.as_nanos()+output_release_ns+destruction_ns,
        "result_delivery":{"api":"for_each_batch","batch_rows_limit":2048,"batches":batches,
            "caller_witness_capacity_bytes":capacity,"caller_witness_native_credit":false,"complete_bytes":actual.len()},
        "native_io_certificate":certificate,"spill_report":spill,
        "resident_source_preparations":resident_source_preparations,"prepared_sources":prepared_sources,"prepared_file_sources":prepared_file_sources,
        "completed_executions":snapshot.completed_executions,"prepared_source_opens":snapshot.prepared_source_opens,
        "admitted_max_parallelism":snapshot.admitted_max_parallelism,"provider_background_workers":snapshot.provider_background_workers,
        "peak_reserved_bytes":final_memory.peak_reserved_bytes,"memory_limit_bytes":final_memory.limit_bytes,
        "reserved_after_cleanup":final_memory.reserved_bytes,"denied_reservations":final_memory.denied_reservations,
        "owned_spill_directory_empty":true,"observation":observed})
}

#[test]
#[ignore = "frozen rematerialization comparison; guarded serial execution only"]
fn native_rematerialization_complete_workflow() {
    let root = PathBuf::from(std::env::var("SHARDLOOM_REMATERIAL_ROOT").unwrap());
    let mode = std::env::var("SHARDLOOM_REMATERIAL_MODE").unwrap();
    let role = std::env::var("SHARDLOOM_REMATERIAL_ROLE").unwrap();
    let cohort = std::env::var("SHARDLOOM_REMATERIAL_COHORT").unwrap();
    assert!(root.is_absolute() && matches!(mode.as_str(), "smoke" | "preflight" | "measure"));
    assert!(matches!(role.as_str(), "retain" | "spill" | "regenerate"));
    fs::create_dir_all(root.join("witnesses")).unwrap();
    let mut output = fs::OpenOptions::new()
        .create_new(true)
        .write(true)
        .open(root.join(format!("{mode}-{role}-{cohort}.jsonl")))
        .unwrap();
    let mut run = |spec, sample, warmup| {
        let record = workflow(&root, spec, &role, &mode, &cohort, sample, warmup);
        writeln!(output, "{record}").unwrap();
        output.flush().unwrap();
    };
    let mut cells = matrix();
    if mode == "measure" {
        run(cells[0], 0, true);
        if cohort == "B" {
            cells.reverse();
        }
        for spec in cells {
            for sample in 0..3 {
                run(spec, sample, false);
            }
        }
    } else {
        for spec in &cells {
            for rows in [0, 17] {
                run(Spec { rows, ..*spec }, 0, false);
            }
        }
        if mode == "smoke" {
            run(cells[0], 0, false);
        } else {
            for spec in cells {
                run(spec, 0, false);
            }
        }
    }
}
