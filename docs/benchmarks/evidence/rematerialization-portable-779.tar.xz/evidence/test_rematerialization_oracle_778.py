import hashlib
import tempfile
import unittest
from pathlib import Path

import rematerialization_oracle_778 as oracle


def cell(profile="mixed", rows=64, derived=2):
    return {"id": "test", "rows": rows, "derived": derived, "profile": profile}


class RematerializationOracleTests(unittest.TestCase):
    def test_literal_source_and_output_rows(self):
        c = cell(rows=40, derived=2)
        self.assertEqual(oracle.source_row(c, 0), {"k": None, "ordinal": 0, "x": None, "y": None})
        self.assertEqual(oracle.output_row(c, 0), {"k": None, "ordinal": 0, "d000": None, "d001": None})
        self.assertEqual(oracle.source_row(c, 1), {"k": -111, "ordinal": 1, "x": -49988, "y": -4996})
        self.assertEqual(oracle.output_row(c, 1), {"k": -111, "ordinal": 1, "d000": -54984, "d001": -104972})
        self.assertIsNone(oracle.source_row(c, 11)["x"])
        self.assertIsNone(oracle.output_row(c, 11)["d000"])
        self.assertEqual(oracle.source_row(c, 12)["x"], -49_845)
        self.assertEqual(oracle.output_row(c, 12)["d000"], -54_764)
        self.assertIsNone(oracle.source_row(c, 17)["y"])
        self.assertIsNone(oracle.output_row(c, 17)["d000"])
        self.assertIsNone(oracle.source_row(c, 31)["k"])
        self.assertEqual(oracle.output_row(c, 31)["ordinal"], 31)

    def test_profile_specific_fixture_and_projection_formulas(self):
        boolean = cell("boolean", rows=4, derived=1)
        self.assertEqual(oracle.source_fields(boolean)[-1], ("flag", "bool", False))
        self.assertEqual(oracle.output_fields(boolean)[-1], ("flag", "bool", False))
        self.assertIs(oracle.source_row(boolean, 0)["flag"], True)
        self.assertIs(oracle.source_row(boolean, 1)["flag"], False)

        unused = cell("wide_unused", rows=2, derived=1)
        self.assertEqual(oracle.source_fields(unused)[-1], ("u063", "i64", False))
        self.assertEqual(oracle.source_row(unused, 1)["u063"], 66)

        wide = cell("wide_dependencies", rows=2, derived=2)
        self.assertEqual(oracle.source_fields(wide)[-1], ("x063", "i64", True))
        self.assertEqual(oracle.source_row(wide, 1)["x001"], -49983)
        self.assertEqual(oracle.output_row(wide, 1)["d001"], -49983 * 2 - 4996)

        all_null = cell("all_null", rows=3, derived=1)
        self.assertIsNone(oracle.source_row(all_null, 1)["x"])
        self.assertIsNone(oracle.output_row(all_null, 1)["d000"])
        aliases = cell("aliases", rows=3, derived=1)
        self.assertEqual(oracle.output_row(aliases, 1)["d000"], oracle.source_row(aliases, 1)["x"])
        constants = cell("constants", rows=3, derived=2)
        self.assertEqual(oracle.output_row(constants, 1)["d001"], 2)
        self.assertEqual(oracle.output_fields(constants)[2], ("d000", "i64", False))

    def test_stable_nulls_last_sort_and_derived_key(self):
        c = cell(rows=600, derived=2)
        ordered = oracle.ordered_indices(c)
        keys = [oracle.source_row(c, r)["k"] for r in ordered]
        self.assertEqual(keys, sorted(keys, key=lambda v: (v is None, v if v is not None else 0)))
        self.assertTrue(all(r < s for r, s in zip(ordered, ordered[1:]) if oracle.source_row(c, r)["k"] == oracle.source_row(c, s)["k"]))
        self.assertEqual([r for r in ordered if oracle.source_row(c, r)["k"] == -111], [1, 258, 515])
        derived = cell("derived_key", rows=40, derived=1)
        ordered = oracle.ordered_indices(derived)
        values = [oracle.output_row(derived, r)["d000"] for r in ordered]
        self.assertEqual(values, sorted(values, key=lambda v: (v is None, v if v is not None else 0)))

    def test_override_controls_cardinality_only(self):
        c = cell(rows=0, derived=1)
        self.assertEqual(len(oracle.source_bytes(c, 17)), 17 * len(oracle.source_fields(c)) * 9)
        records = list(oracle.iter_expected_records(c, 17))
        self.assertEqual(len(records), 17)
        expected_order = [16, *range(1, 16), 0]
        self.assertEqual(oracle.ordered_indices(c, 17), expected_order)
        self.assertEqual(records, [oracle._encode_row(oracle.output_row(c, r), oracle.output_fields(c))
                                   for r in expected_order])

    def test_binary_null_canonicalization_and_bool_encoding(self):
        c = cell("boolean", rows=2, derived=0)
        raw = oracle.source_bytes(c)
        fields = oracle.source_fields(c)
        self.assertEqual(len(raw), 2 * len(fields) * 9)
        # Row zero begins with NULL k and canonical zero payload bytes.
        self.assertEqual(raw[:9], b"\x00" + bytes(8))
        # Boolean and Int64 payload bits may coincide; the full schema distinguishes them.
        self.assertEqual(raw[4 * 9:5 * 9], b"\x01" + (1).to_bytes(8, "little"))
        with self.assertRaises(ValueError):
            oracle._pack(1, "bool")

    def test_row_limits_and_field_limit(self):
        with self.assertRaises(ValueError):
            oracle.source_bytes(cell(rows=65_537))
        with self.assertRaises(ValueError):
            oracle.output_fields(cell("wide_unused", rows=1, derived=127))
        with self.assertRaises(ValueError):
            oracle.source_bytes(cell("unknown", rows=1))

    def test_witness_requires_exact_content_length_and_digest(self):
        expected = b"oracle bytes"
        digest = hashlib.sha256(expected).hexdigest()
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "witness.bin"
            path.write_bytes(expected)
            self.assertTrue(oracle.verify_witness(path, expected, digest))
            path.write_bytes(expected[:-1])
            self.assertFalse(oracle.verify_witness(path, expected, digest))
            path.write_bytes(expected + b"x")
            self.assertFalse(oracle.verify_witness(path, expected, digest))
            path.write_bytes(bytes([expected[0] ^ 1]) + expected[1:])
            self.assertFalse(oracle.verify_witness(path, expected, digest))
            path.unlink()
            self.assertFalse(oracle.verify_witness(path, expected, digest))


if __name__ == "__main__":
    unittest.main()
