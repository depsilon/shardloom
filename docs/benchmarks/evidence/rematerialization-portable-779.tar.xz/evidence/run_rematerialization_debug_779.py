"""Sequential bounded debug smoke after focused tests, using frozen driver bindings."""

import argparse
import json
from pathlib import Path
import subprocess
import sys

import rematerialization_driver_779 as driver


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--label', required=True)
    args = parser.parse_args()
    label = args.label
    driver.validate_label(label)
    out = driver.OUT
    data = out / f'{label}-data'
    assert not data.exists()
    focused_path = out / f'{label}-focused.json'
    focused = json.loads(focused_path.read_text())
    focused_log = out / f'{label}-focused.log'
    assert focused['status'] == 'passed' and focused['process_group_drained'] is True
    assert focused['log_sha256'] == driver.sha(focused_log)
    assert 'test result: ok. 12 passed; 0 failed; 1 ignored;' in focused_log.read_text()
    artifact_path = out / f'{label}-artifact.json'
    artifact = json.loads(artifact_path.read_text())
    assert artifact['profile'] == 'debug'
    assert focused['command'] == [artifact['artifact'], '::rematerialization_', '--nocapture', '--test-threads=1']
    source_path = out / f'{label}-source-freeze.json'
    freeze = json.loads(source_path.read_text())
    driver.verify_sources(freeze)
    driver.verify_historical_sources(label, freeze)
    steps = []
    status = 'failed'
    try:
        for role in ('retain','spill','regenerate'):
            name = f'{label}-smoke-{role}'
            command = [sys.executable, str(Path(driver.__file__)), 'run', '--label', label,
                       '--name', name, '--mode', 'smoke', '--role', role, '--cohort', 'smoke',
                       '--data', data.name]
            code = subprocess.call(command, cwd=driver.REPO)
            steps.append(dict(name=name,returncode=code))
            assert code == 0, name
            receipt = json.loads((out/f'{name}.json').read_text())
            assert receipt['status']=='passed' and receipt['process_group_drained'] is True
        name = f'{label}-independent'
        command = [sys.executable,str(driver.GUARD),'--name',name,'--timeout','1800','--',
                   sys.executable,str(driver.ANALYZER),'--mode','smoke','--data',str(data),
                   '--output',str(out/f'{label}-analysis.json')]
        code = subprocess.call(command,cwd=driver.REPO)
        steps.append(dict(name=name,returncode=code))
        driver.verify_sources(freeze)
        driver.verify_historical_sources(label, freeze)
        assert code == 0
        status = 'passed'
    finally:
        driver.save(out/f'{label}-sequence.json',dict(status=status,steps=steps,
                    source_sha256=driver.sha(source_path),artifact_sha256=driver.sha(artifact_path),
                    focused_receipt_sha256=driver.sha(focused_path)))
    print(json.dumps(dict(status=status,debug_workflows=81,focused_tests=12)))


if __name__ == '__main__':
    main()
