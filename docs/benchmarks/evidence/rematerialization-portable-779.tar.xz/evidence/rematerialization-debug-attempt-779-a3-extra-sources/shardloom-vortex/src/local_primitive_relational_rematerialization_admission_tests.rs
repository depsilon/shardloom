//! Excluded public sources and compositions remain ordinary native execution.

use super::super::rematerialization_observation as observation;
use super::{rematerialization_fixture::*, *};
use crate::{
    relational_query::{
        VortexRelationalLimit, VortexRelationalSubquery, VortexRelationalSubqueryKind,
    },
    resident_memory_source::MemorySourceBounds,
};

fn ordinary(data: &Data, prepared: PreparedVortexRelational, observer: observation::Session) {
    let memory = prepared.session.memory().clone();
    let mut actual = Vec::new();
    let result = prepared
        .for_each_batch(&CancellationToken::default(), |array, context| {
            consume_bytes(&array, &data.output_fields(), context, &mut actual)
        })
        .unwrap();
    assert_eq!(actual, data.expected_bytes());
    assert_eq!(result.output_rows, data.spec.rows as u64);
    assert!(result.native_io_certificate.is_certified());
    assert!(!result.native_io_certificate.side_effects.fallback_attempted);
    drop((result, prepared));
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    let observed = observer.finish();
    assert_eq!(observed["admissions"], 0);
    assert_eq!(observed["projection_rows"], data.spec.rows);
    assert_eq!(observed["reclaimed_bytes"], 0);
}

#[test]
fn rematerialization_above_memory_source_bound_fails_before_execution() {
    let data = Data::new(Spec {
        rows: 65537,
        ..matrix()[0]
    });
    let observer = observation::Session::start(true);
    let result = prepare_relational_with_schema(policy(), |schemas| {
        schemas.register_memory_source(
            DatasetUri::new("memory://rematerialization")?,
            |session| {
                ResidentMemorySource::from_columns(
                    session,
                    &data.columns(),
                    MemorySourceBounds::default(),
                )
            },
        )?;
        Ok(plan(
            data.spec,
            DatasetUri::new("memory://rematerialization")?,
        ))
    });
    let error = result
        .err()
        .expect("oversized public memory source must be refused");
    assert!(error.to_string().contains("bound"));
    let observed = observer.finish();
    assert_eq!(observed["admissions"], 0);
    assert_eq!(observed["projection_rows"], 0);
}

#[test]
fn rematerialization_file_source_keeps_ordinary_complete_results() {
    let data = Data::new(matrix()[0]);
    let array = StructArray::try_new(
        FieldNames::from(["k", "ordinal", "x", "y"]),
        vec![
            PrimitiveArray::from_option_iter(data.keys.iter().copied()).into_array(),
            PrimitiveArray::from_iter(data.ordinals.iter().copied()).into_array(),
            PrimitiveArray::from_option_iter(data.x.iter().copied()).into_array(),
            PrimitiveArray::from_option_iter(data.y.iter().copied()).into_array(),
        ],
        data.spec.rows,
        Validity::NonNullable,
    )
    .unwrap()
    .into_array();
    let fixture = Fixture::new(array, 8192);
    let observer = observation::Session::start(true);
    let query = plan(
        data.spec,
        DatasetUri::new(fixture.path().display().to_string()).unwrap(),
    );
    ordinary(
        &data,
        prepare_relational(&query, policy()).unwrap(),
        observer,
    );
}

#[test]
fn rematerialization_dynamic_and_nested_roots_keep_ordinary_results() {
    let data = Data::new(matrix()[0]);
    let uri = DatasetUri::new("memory://rematerialization").unwrap();
    let query = plan(data.spec, uri.clone());
    let observer = observation::Session::start(true);
    let dynamic = prepare_relational_with_dynamic_inputs(
        std::slice::from_ref(&uri),
        policy(),
        65536,
        |schemas| {
            schemas.register_memory_source(uri.clone(), |session| {
                ResidentMemorySource::from_columns(
                    session,
                    &data.columns(),
                    MemorySourceBounds::default(),
                )
            })
        },
        move |_| Ok(query.clone()),
    )
    .unwrap();
    assert!(dynamic.output_dtype().is_none());
    ordinary(&data, dynamic, observer);
    let observer = observation::Session::start(true);
    let nested = VortexRelationalPlan::Limit(Box::new(VortexRelationalLimit {
        input: plan(data.spec, uri),
        offset: 0,
        count: data.spec.rows,
    }));
    ordinary(&data, data.prepare(nested, 64 << 20), observer);
}

#[test]
fn rematerialization_one_shot_input_keeps_ordinary_complete_results() {
    let data = Data::new(matrix()[0]);
    let empty = Data::new(Spec {
        rows: 0,
        ..data.spec
    });
    let uri = DatasetUri::new("memory://rematerialization").unwrap();
    let observer = observation::Session::start(true);
    let prepared = prepare_relational_with_schema(policy(), |schemas| {
        schemas.register_batch_source(uri.clone(), |session| {
            ResidentMemorySource::from_batch_columns(session, &empty.columns())
        })?;
        Ok(plan(data.spec, uri))
    })
    .unwrap();
    let memory = prepared.session.memory().clone();
    let mut calls = 0;
    let mut producer = |session: &ResidentVortexSession| {
        calls += 1;
        if calls == 1 {
            ResidentMemorySource::from_batch_columns(session, &data.columns()).map(Some)
        } else {
            Ok(None)
        }
    };
    let mut actual = Vec::new();
    let result = prepared
        .with_batch_input(&mut producer)
        .unwrap()
        .for_each_batch(&CancellationToken::default(), |array, context| {
            consume_bytes(&array, &data.output_fields(), context, &mut actual)
        })
        .unwrap();
    assert_eq!(calls, 2);
    assert_eq!(actual, data.expected_bytes());
    assert_eq!(result.output_rows, data.spec.rows as u64);
    assert!(result.native_io_certificate.is_certified());
    drop((result, prepared));
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    let observed = observer.finish();
    assert_eq!(observed["admissions"], 0);
    assert_eq!(observed["projection_rows"], data.spec.rows);
    assert_eq!(observed["reclaimed_bytes"], 0);
}

#[test]
fn rematerialization_parameterized_relation_does_not_admit_nested_sort() {
    let data = Data::new(matrix()[0]);
    let uri = DatasetUri::new("memory://rematerialization").unwrap();
    let query = VortexRelationalPlan::CorrelatedSubquery(Box::new(VortexRelationalSubquery {
        input: VortexRelationalPlan::Limit(Box::new(VortexRelationalLimit {
            input: VortexRelationalPlan::Scan(VortexRelationalScan {
                source_uri: uri.clone(),
                projection: shardloom_plan::ProjectionRequest::All,
                predicate: None,
            }),
            offset: 0,
            count: 1,
        })),
        relation: plan(data.spec, uri),
        kind: VortexRelationalSubqueryKind::Exists,
        evaluation_guard: None,
        correlation: vec![],
        output_column: "present".into(),
        negated: false,
    }));
    let observer = observation::Session::start(true);
    let prepared = data.prepare(query, 64 << 20);
    let memory = prepared.session.memory().clone();
    let collected = prepared
        .collect_jsonl(&CancellationToken::default())
        .unwrap();
    assert_eq!(
        json_rows(&collected),
        vec![serde_json::json!({
            "k":null,"ordinal":0,"x":null,"y":null,"present":true
        })]
    );
    drop((collected, prepared));
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    let observed = observer.finish();
    assert_eq!(observed["admissions"], 0);
    assert_eq!(observed["projection_rows"], data.spec.rows);
}
