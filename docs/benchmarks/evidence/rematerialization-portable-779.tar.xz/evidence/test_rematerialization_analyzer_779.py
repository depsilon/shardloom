"""Boundary and corruption tests for the frozen evidence acceptance rules."""

import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

import analyze_rematerialization_779 as check


class AcceptanceTests(unittest.TestCase):
    def test_clock_gate_requires_both_strict_thresholds(self):
        self.assertFalse(check.throughput_regression(21_000_000, 20_000_000))
        self.assertTrue(check.throughput_regression(21_000_001, 20_000_000))
        self.assertFalse(check.throughput_regression(9_500_000, 9_000_000))
        self.assertFalse(check.throughput_regression(102_000_000, 100_000_000))

    def records(self):
        cells = [{'id':'target', 'target':True}, {'id':'control', 'target':False}]
        rows = [dict(cohort=cohort, cell_id=cell['id'], role=role, sample=sample, warmup=False,
                     engine_execution_ns=20_000_000, complete_workflow_ns=30_000_000,
                     peak_reserved_bytes=800_000 if role == 'regenerate' else 1_000_000)
                for cohort in ('A','B') for cell in cells for role in check.ROLES for sample in range(3)]
        return cells, rows

    def test_peak_requires_both_percent_and_absolute_saving_in_both_cohorts(self):
        cells, rows = self.records()
        self.assertFalse(check.decide(rows, cells)['failures'])
        for row in rows:
            if row['cohort'] == 'B' and row['cell_id'] == 'target' and row['role'] == 'regenerate':
                row['peak_reserved_bytes'] = 800_001
        self.assertEqual(check.decide(rows, cells)['failures'],
                         [dict(cohort='B',cell='target',gate='target_native_peak')])
        cells, rows = self.records()
        for row in rows:
            if row['cell_id'] == 'target':
                row['peak_reserved_bytes'] = 512_000 if row['role'] == 'regenerate' else 640_000
        self.assertEqual(len(check.decide(rows, cells)['failures']), 2)

    def test_controls_and_spill_clock_are_mandatory(self):
        cells, rows = self.records()
        for row in rows:
            if row['cell_id'] == 'control' and row['role'] == 'regenerate':
                row['peak_reserved_bytes'] = 1_065_536
        self.assertFalse(check.decide(rows, cells)['failures'])
        for row in rows:
            if row['cell_id'] == 'control' and row['role'] == 'regenerate':
                row['peak_reserved_bytes'] += 1
            if row['cell_id'] == 'target' and row['role'] == 'spill':
                row['engine_execution_ns'] = 18_000_000
        failures = check.decide(rows, cells)['failures']
        self.assertEqual(len(failures), 4)
        self.assertEqual(sum(r.get('comparison') == 'spill' for r in failures), 2)

    def test_all_cells_and_samples_required_and_warmups_excluded(self):
        cells, rows = self.records()
        warmup = dict(rows[0], warmup=True, peak_reserved_bytes=0, engine_execution_ns=0)
        self.assertEqual(check.decide(rows, cells), check.decide(rows + [warmup], cells))
        with self.assertRaises(check.Invalid):
            check.decide(rows[:-1], cells)

    def test_full_witness_rejects_corruption_substitution_and_path_escape(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            (root/'witnesses').mkdir()
            raw = b'\x01' + (17).to_bytes(8, 'little')
            digest = hashlib.sha256(raw).hexdigest()
            ref = dict(path=f'witnesses/{digest}.bin', sha256=digest, bytes=len(raw))
            path = root / ref['path']
            path.write_bytes(raw)
            check.read_witness(root, ref, raw, 'bin', set())
            for broken in (raw[:-1], raw+b'x', b'\x00'+raw[1:]):
                path.write_bytes(broken)
                with self.assertRaises(check.Invalid):
                    check.read_witness(root, ref, raw, 'bin', set())
            path.write_bytes(raw)
            with self.assertRaises(check.Invalid):
                check.read_witness(root, dict(ref, path='../escape'), raw, 'bin', set())
            with self.assertRaises(check.Invalid):
                check.read_witness(root, ref, b'\x01'+bytes(8), 'bin', set())

    def test_schema_preserves_types_nullability_and_field_order(self):
        fields = [('a','i64',True), ('b','bool',False)]
        expected = {'Struct':[{'names':['a','b'], 'dtypes':[{'Primitive':['i64',True]},{'Bool':False}]},False]}
        self.assertTrue(check.typed_equal(check.schema(fields), expected))
        broken = copy.deepcopy(expected)
        broken['Struct'][0]['dtypes'][0]['Primitive'][1] = 1
        self.assertFalse(check.typed_equal(broken, expected))
        self.assertFalse(check.typed_equal(check.schema(fields[::-1]), expected))

    def test_stream_orders_include_every_cell_control_and_warmup(self):
        cells = check.protocol()['workload']['cells']
        self.assertEqual(len(check.expected_order(cells,'smoke','smoke')), 27)
        self.assertEqual(len(check.expected_order(cells,'preflight','preflight')), 39)
        forward = check.expected_order(cells,'measure','A')
        reverse = check.expected_order(cells,'measure','B')
        self.assertEqual(len(forward), 40)
        self.assertEqual(forward[0], reverse[0])
        self.assertIs(forward[0][3], True)
        self.assertEqual(forward[1][0], cells[0])
        self.assertEqual(reverse[1][0], cells[-1])
        self.assertEqual([r[2] for r in reverse[1:4]], [0,1,2])


if __name__ == '__main__':
    unittest.main()
