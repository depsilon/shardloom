"""Reopen full witnesses and apply the unchanged private-projection protocol."""

from __future__ import annotations

import argparse
import functools
import hashlib
import json
from pathlib import Path
import statistics

import rematerialization_oracle_778 as oracle

ROOT = Path(__file__).resolve().parent
PROTOCOL = ROOT / 'rematerialization-protocol-778.json'
PROTOCOL_SHA = 'dbce5d1135a89704463f7b54c6557a58902c1aa41f6b4ad89778a1241e390442'
ROLES = ('retain', 'spill', 'regenerate')
CLOCKS = ('engine_execution_ns', 'complete_workflow_ns')
NS_PARTS = ('preparation_ns', 'engine_execution_ns', 'sink_consumption_ns',
            'execution_and_consumption_ns', 'output_release_ns', 'destruction_ns',
            'complete_workflow_ns')


class Invalid(ValueError):
    pass


def need(condition, message):
    if not condition:
        raise Invalid(message)


def integer(value, name, minimum=0):
    need(type(value) is int and value >= minimum, f'{name}: invalid integer')
    return value


def typed_equal(left, right):
    if type(left) is not type(right):
        return False
    if isinstance(right, dict):
        return left.keys() == right.keys() and all(typed_equal(left[k], right[k]) for k in right)
    if isinstance(right, list):
        return len(left) == len(right) and all(typed_equal(a, b) for a, b in zip(left, right))
    return left == right


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def protocol():
    raw = PROTOCOL.read_bytes()
    need(digest(raw) == PROTOCOL_SHA, 'protocol bytes changed')
    return json.loads(raw)


def schema(fields):
    return {'Struct': [{'names': [name for name, _, _ in fields],
                        'dtypes': [({'Bool': nullable} if kind == 'bool' else
                                    {'Primitive': ['i64', nullable]})
                                   for _, kind, nullable in fields]}, False]}


@functools.lru_cache(maxsize=128)
def expected_bytes(cell_json, rows, source):
    cell = json.loads(cell_json)
    return oracle.source_bytes(cell, rows) if source else oracle.expected_bytes(cell, rows)


def read_witness(data, reference, expected, extension, used):
    need(type(reference) is dict and reference.keys() == {'path', 'sha256', 'bytes'},
         'malformed witness reference')
    identity = reference['sha256']
    need(type(identity) is str and len(identity) == 64 and
         all(c in '0123456789abcdef' for c in identity), 'invalid witness digest')
    relative = f'witnesses/{identity}.{extension}'
    need(reference['path'] == relative, 'witness is not its canonical content-addressed path')
    path = data / relative
    need(path.is_file() and not path.is_symlink() and not path.parent.is_symlink(),
         'missing or linked witness')
    raw = path.read_bytes()
    need(integer(reference['bytes'], 'witness.bytes') == len(raw), 'witness length mismatch')
    need(digest(raw) == identity, 'witness digest mismatch')
    if extension == 'bin':
        need(raw == expected, f'complete binary values differ: {relative}')
    else:
        need(typed_equal(json.loads(raw), expected), f'complete schema differs: {relative}')
    used.add(relative)


def expected_order(cells, mode, cohort):
    if mode == 'measure':
        body = cells[::-1] if cohort == 'B' else cells
        return [(cells[0], cells[0]['rows'], 0, True)] + [
            (cell, cell['rows'], sample, False) for cell in body for sample in range(3)]
    head = [(cell, rows, 0, False) for cell in cells for rows in (0, 17)]
    tail = [cells[0]] if mode == 'smoke' else cells
    return head + [(cell, cell['rows'], 0, False) for cell in tail]


def validate_record(row, cell, rows, sample, warmup, role, mode, cohort, data, used):
    expected_identity = dict(cell_id=cell['id'], rows=rows, width=cell['derived'],
                             profile=cell['profile'], target=cell['target'], role=role,
                             mode=mode, cohort=cohort, sample=sample, warmup=warmup)
    for key, expected in expected_identity.items():
        need(key in row and typed_equal(row[key], expected), f'{cell["id"]}: identity {key}')
    cell_json = json.dumps(cell, sort_keys=True)
    source = expected_bytes(cell_json, rows, True)
    expected = expected_bytes(cell_json, rows, False)
    read_witness(data, row['source_rows_witness'], source, 'bin', used)
    read_witness(data, row['source_schema_witness'], schema(oracle.source_fields(cell)), 'json', used)
    for name in ('actual_rows_witness', 'expected_rows_witness'):
        read_witness(data, row[name], expected, 'bin', used)
    for name in ('actual_schema_witness', 'expected_schema_witness'):
        read_witness(data, row[name], schema(oracle.output_fields(cell)), 'json', used)
    for key in NS_PARTS:
        integer(row[key], key)
    need(row['engine_execution_ns'] + row['sink_consumption_ns'] == row['execution_and_consumption_ns'],
         'engine/consumer clock decomposition differs')
    need(row['complete_workflow_ns'] == sum(row[k] for k in (
        'preparation_ns', 'execution_and_consumption_ns', 'output_release_ns', 'destruction_ns')),
        'complete workflow decomposition differs')
    for key, expected_value in dict(resident_source_preparations=1, prepared_sources=1,
                                    prepared_file_sources=0, completed_executions=1,
                                    prepared_source_opens=0, admitted_max_parallelism=1,
                                    provider_background_workers=0, reserved_after_cleanup=0,
                                    denied_reservations=0, memory_limit_bytes=67108864).items():
        need(typed_equal(row[key], expected_value), f'{key} violates original source/grant/cleanup')
    peak = integer(row['peak_reserved_bytes'], 'pool peak', 1)
    need(peak <= row['memory_limit_bytes'], 'native pool exceeded original grant')
    need(row['owned_spill_directory_empty'] is True, 'owned spill cleanup incomplete')
    delivery = row['result_delivery']
    need(delivery['api'] == 'for_each_batch' and delivery['batch_rows_limit'] == 2048,
         'native public consumer boundary changed')
    batches = delivery['batches']
    need(type(batches) is list and bool(batches), 'missing typed native batches')
    need(all(type(n) is int and 0 <= n <= 2048 for n in batches) and sum(batches) == rows,
         'native batch cardinalities changed')
    need(all(n > 0 for n in batches) if rows else batches == [0],
         'unexpected empty native output batch')
    need(delivery['caller_witness_native_credit'] is False, 'caller witness credit misrepresented')
    for key in ('caller_witness_capacity_bytes', 'complete_bytes'):
        need(typed_equal(delivery[key], len(expected)) and len(expected) <= 128 << 20,
             'incomplete or oversized caller witness')
    certificate = row['native_io_certificate']
    need(certificate['certified'] is True and certificate['fallback_attempted'] is False,
         'missing native no-fallback certificate')
    need(type(certificate['complete_debug']) is str and len(certificate['complete_debug']) > 50,
         'missing actual complete certificate')
    spill = row['spill_report']
    if role == 'spill':
        need(type(spill) is dict, 'authorized spill report missing')
        for key, value in dict(quota_bytes=134217728, buffer_bytes=1048576,
                               owned_cleanup_completed=True).items():
            need(typed_equal(spill[key], value), 'spill grant or owned cleanup changed')
        for key in ('peak_disk_bytes', 'runs_written', 'runs_validated', 'merge_passes',
                    'max_open_runs', 'run_block_rows'):
            integer(spill[key], key)
        need(spill['peak_disk_bytes'] <= spill['quota_bytes'] and spill['max_open_runs'] <= 2,
             'spill exceeded original disk/reader grant')
        workspace = data / f'spill-{cell["id"]}-{rows}-{role}-{mode}-{cohort}-{sample}-{str(warmup).lower()}'
        # The report names a private operation directory under this caller directory.
        need(Path(spill['workspace']).is_relative_to(workspace), 'spill workspace escaped its owner')
        need(not workspace.exists(), 'owned spill parent remains after complete workflow')
        if cell['target'] and rows == cell['rows']:
            need(spill['runs_written'] > 0 and spill['peak_disk_bytes'] > 0 and
                 certificate['spill_io_performed'] is True, 'target spill comparison wrote no runs')
    else:
        need(spill is None and certificate['spill_io_performed'] is False,
             'ordinary resident role unexpectedly spilled')
    observed = row['observation']
    active = (role == 'regenerate' and rows >= 32768 and cell['derived'] >= 8 and
              cell['profile'] in ('mixed', 'wide_unused', 'wide_dependencies', 'all_null'))
    batch_count = (rows + 2047) // 2048
    need(observed['enabled'] is (role == 'regenerate'), 'candidate switch differs from role')
    for key, value in dict(admissions=int(active), projection_rows=rows * (2 if active else 1),
                           projection_batches=batch_count * (2 if active else 1),
                           source_rows=rows if active else 0, derived=cell['derived'] if active else 0,
                           validated_rows=rows if active else 0,
                           regenerated_rows=rows if active else 0,
                           rebuild_batches=batch_count if active else 0).items():
        need(typed_equal(observed[key], value), f'candidate {key} differs from frozen activation')
    dependencies = 67 if cell['profile'] == 'wide_dependencies' else 4
    outputs = len(oracle.output_fields(cell))
    metadata = 1024 + 4096 * (dependencies + 1)
    headroom = 65536 + 4096 * (outputs + dependencies + 1) + 2048 * (16 * (outputs + dependencies) + 128 * 3)
    for key, value in dict(dependencies=dependencies, depth=2, metadata_bytes=metadata,
                           headroom_bytes=headroom).items():
        need(typed_equal(observed[key], value if active else 0), f'candidate {key} changed')
    transitions = observed['transitions']
    need(type(transitions) is list and len(transitions) == (2 * batch_count if active else 0),
         'incomplete or unexpected private owner transitions')
    reclaimed = 0
    for index, transition in enumerate(transitions):
        need(typed_equal(transition['rows'], 2048), 'unbounded or incomplete reconstruction batch')
        if index < batch_count:
            need(transition['kind'] == 'private_release', 'rebuild preceded complete eager validation')
            for key in ('before', 'held', 'after', 'released'):
                integer(transition[key], key)
            need(transition['held'] >= transition['after'] and
                 transition['released'] == transition['held'] - transition['after'],
                 'private credit release is not an observed final-owner delta')
            need(max(transition['before'], transition['held'], transition['after']) <= peak,
                 'transition exceeds full native lifetime peak')
            reclaimed += transition['released']
        else:
            need(transition['kind'] == 'rebuilt', 'invalid reconstruction transition')
            need(integer(transition['live'], 'rebuild live') <= peak,
                 'reconstruction exceeds recorded lifetime peak')
    need(typed_equal(observed['reclaimed_bytes'], reclaimed), 'reclamation aggregate differs')
    if active and cell['target']:
        need(reclaimed >= rows * cell['derived'] * 8, 'target private payload was not reclaimed')


def throughput_regression(candidate, baseline):
    return candidate - baseline > 1_000_000 and candidate * 100 > baseline * 105


def decide(records, cells):
    summaries, failures = [], []
    for cohort in ('A', 'B'):
        for cell in cells:
            medians = {}
            for role in ROLES:
                selected = [r for r in records if r['cohort'] == cohort and r['cell_id'] == cell['id']
                            and r['role'] == role and r['warmup'] is False]
                need(len(selected) == 3, 'incomplete decision cell')
                medians[role] = {key: statistics.median(r[key] for r in selected)
                                 for key in (*CLOCKS, 'peak_reserved_bytes')}
            candidate, baseline = medians['regenerate'], medians['retain']
            if cell['target']:
                before, after = baseline['peak_reserved_bytes'], candidate['peak_reserved_bytes']
                if before - after < 131072 or after * 100 > before * 80:
                    failures.append(dict(cohort=cohort, cell=cell['id'], gate='target_native_peak'))
            if candidate['peak_reserved_bytes'] > baseline['peak_reserved_bytes'] + 65536:
                failures.append(dict(cohort=cohort, cell=cell['id'], gate='control_native_peak'))
            for clock in CLOCKS:
                for comparison in (('retain', 'spill') if cell['target'] else ('retain',)):
                    if throughput_regression(candidate[clock], medians[comparison][clock]):
                        failures.append(dict(cohort=cohort, cell=cell['id'],
                                             gate=clock, comparison=comparison))
            summaries.append(dict(cohort=cohort, cell=cell['id'], target=cell['target'], medians=medians))
    return dict(decision='reject' if failures else 'pass_finite_comparison_requires_full_acceptance',
                failures=failures, cells=summaries)


def analyze(data, mode):
    cells = protocol()['workload']['cells']
    need(data.is_dir() and not data.is_symlink(), 'missing/linked data directory')
    cohorts = ('A', 'B') if mode == 'measure' else (mode,)
    expected_paths = {f'{mode}-{role}-{cohort}.jsonl' for role in ROLES for cohort in cohorts}
    actual_paths = {p.name for p in data.glob(f'{mode}-*.jsonl')}
    need(actual_paths == expected_paths, 'missing or extra workflow streams')
    all_rows, streams, used = [], [], set()
    for cohort in cohorts:
        for role in ROLES:
            path = data / f'{mode}-{role}-{cohort}.jsonl'
            need(path.is_file() and not path.is_symlink(), 'linked workflow stream')
            raw = path.read_bytes()
            need(raw.endswith(b'\n'), 'incomplete workflow stream terminator')
            records = [json.loads(line) for line in raw.splitlines()]
            expected = expected_order(cells, mode, cohort)
            need(len(records) == len(expected), 'incomplete workflow stream cardinality')
            for record, (cell, rows, sample, warmup) in zip(records, expected):
                validate_record(record, cell, rows, sample, warmup, role, mode, cohort, data, used)
            all_rows.extend(records)
            streams.append(dict(path=path.name, sha256=digest(raw), bytes=len(raw), workflows=len(records)))
    need(len(all_rows) == {'smoke':81, 'preflight':117, 'measure':240}[mode],
         'incomplete complete-workflow count')
    result = dict(status='passed', mode=mode, protocol_sha256=PROTOCOL_SHA,
                  workflows=len(all_rows), streams=streams, witnesses_verified=len(used),
                  source_output_schema_values_order_activation_grants_and_cleanup=True)
    if mode == 'measure':
        result.update(decide(all_rows, cells))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', type=Path, required=True)
    parser.add_argument('--mode', choices=('smoke', 'preflight', 'measure'), required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = analyze(args.data, args.mode)
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('streams', 'cells', 'failures')}))


if __name__ == '__main__':
    main()
