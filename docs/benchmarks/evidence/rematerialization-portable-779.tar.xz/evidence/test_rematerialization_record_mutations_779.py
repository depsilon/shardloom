"""The verifier must reject corrupted evidence from a real successful native workflow."""

import copy
import json
from pathlib import Path
import unittest

import analyze_rematerialization_779 as check

DATA = Path(__file__).resolve().parent / 'rematerialization-debug-779-a5-data'


class NativeRecordMutations(unittest.TestCase):
    def test_real_active_record_and_contract_corruptions(self):
        record = json.loads((DATA/'smoke-regenerate-smoke.jsonl').read_text().splitlines()[-1])
        cell = check.protocol()['workload']['cells'][0]

        def verify(value):
            check.validate_record(value,cell,32768,0,False,'regenerate','smoke','smoke',DATA,set())

        verify(record)
        changes = [
            ('second execution', lambda r:r.update(completed_executions=2)),
            ('reopened source', lambda r:r.update(prepared_source_opens=1)),
            ('unreleased owner', lambda r:r.update(reserved_after_cleanup=1)),
            ('changed grant', lambda r:r.update(memory_limit_bytes=134217728)),
            ('missing certificate', lambda r:r['native_io_certificate'].update(certified=False)),
            ('fallback', lambda r:r['native_io_certificate'].update(fallback_attempted=True)),
            ('partial consumption', lambda r:r['result_delivery'].update(complete_bytes=9)),
            ('caller storage counted native', lambda r:r['result_delivery'].update(caller_witness_native_credit=True)),
            ('second regeneration', lambda r:r['observation'].update(regenerated_rows=65536)),
            ('dropped dependency', lambda r:r['observation'].update(dependencies=3)),
            ('missing credit', lambda r:r['observation'].update(metadata_bytes=0)),
            ('invented reclamation', lambda r:r['observation'].update(reclaimed_bytes=r['observation']['reclaimed_bytes']+1)),
            ('extra transition', lambda r:r['observation']['transitions'].append(copy.deepcopy(r['observation']['transitions'][-1]))),
            ('rebuild before validation', lambda r:r['observation']['transitions'].reverse()),
            ('partial projection', lambda r:r['observation'].update(projection_rows=32768)),
            ('altered clock', lambda r:r.update(engine_execution_ns=r['engine_execution_ns']+1)),
            ('schema substitution', lambda r:r.update(actual_schema_witness=r['source_schema_witness'])),
            ('source substituted for output', lambda r:r.update(actual_rows_witness=r['source_rows_witness'])),
            ('boolean identity typed integer', lambda r:r.update(target=1)),
        ]
        for name, change in changes:
            with self.subTest(name=name):
                corrupted = copy.deepcopy(record)
                change(corrupted)
                with self.assertRaises(check.Invalid):
                    verify(corrupted)


if __name__ == '__main__':
    unittest.main()
