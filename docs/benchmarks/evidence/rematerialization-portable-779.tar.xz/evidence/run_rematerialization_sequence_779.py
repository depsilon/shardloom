"""Run every frozen release gate in order, with no comparative inspection mid-cohort."""

import json
from pathlib import Path
import subprocess
import sys

import rematerialization_driver_779 as driver

OUT, REPO = driver.OUT, driver.REPO
LABEL = 'rematerialization-release-779-a1'
BUILD = 'rematerialization-release-build-779-a1'
DEBUG = 'rematerialization-debug-779-a5'
DATA = OUT / f'{LABEL}-data'
SOURCE = OUT / f'{LABEL}-source-freeze.json'
PYTHON = sys.executable


def guarded(name, command):
    return [PYTHON, str(driver.GUARD), '--name', name, '--timeout', '1800', '--', *command]


def run_step(name, command):
    output = OUT / f'{name}-sequence-output.log'
    record = dict(name=name, command=command, protocol_sha256=driver.PROTOCOL_SHA,
                  source_freeze_sha256=driver.sha(SOURCE))
    print(f'START {name}', flush=True)
    try:
        with output.open('x') as stream:
            code = subprocess.call(command, cwd=REPO, stdout=stream, stderr=subprocess.STDOUT)
        record.update(returncode=code, output_sha256=driver.sha(output))
        if code:
            raise RuntimeError(f'{name} failed; original evidence remains in {output}')
        guard_path = OUT / f'{name}.json'
        if guard_path.exists():
            guard = json.loads(guard_path.read_text())
            assert guard['status'] == 'passed' and guard['returncode'] == 0
            assert guard['process_group_drained'] is True
            assert guard['log_sha256'] == driver.sha(OUT / f'{name}.log')
            record['guard_receipt_sha256'] = driver.sha(guard_path)
    finally:
        driver.save(OUT / f'{name}-sequence-step.json', record)
    print(f'PASS {name}', flush=True)
    return record


def main():
    debug_sequence = OUT / f'{DEBUG}-sequence.json'
    debug_analysis = OUT / f'{DEBUG}-analysis.json'
    sequence = json.loads(debug_sequence.read_text())
    analysis = json.loads(debug_analysis.read_text())
    assert sequence['status'] == 'passed'
    assert analysis['status'] == 'passed' and analysis['workflows'] == 81
    assert analysis['protocol_sha256'] == driver.PROTOCOL_SHA
    freeze = json.loads(SOURCE.read_text())
    debug_sources = json.loads((OUT / f'{DEBUG}-source-freeze.json').read_text())
    assert freeze['sources'] == debug_sources['sources']
    driver.verify_sources(freeze)
    driver.verify_historical_sources(LABEL, freeze)
    assert not DATA.exists() and not (OUT/f'{LABEL}-artifact.json').exists()
    identity = dict(label=LABEL, source_freeze_sha256=driver.sha(SOURCE),
                    protocol_sha256=driver.PROTOCOL_SHA, sequence_sha256=driver.sha(__file__),
                    debug_sequence_sha256=driver.sha(debug_sequence),
                    debug_analysis_sha256=driver.sha(debug_analysis),
                    measured_cohort_order=[['A',['retain','spill','regenerate']],
                                           ['B',['regenerate','spill','retain']]],
                    samples_per_cell=3, full_preflight_before_measurements=True)
    driver.save(OUT / f'{LABEL}-sequence-identity.json', identity)
    steps, status = [], 'failed'
    decision_path = OUT / f'{LABEL}-decision.json'
    try:
        name = f'{LABEL}-bind'
        steps.append(run_step(name, [PYTHON,str(Path(driver.__file__)),'bind','--label',LABEL,
                                     '--profile','release','--build',BUILD]))
        name = f'{LABEL}-focused'
        steps.append(run_step(name,guarded(name,[str(OUT/f'{LABEL}-test'),'::rematerialization_',
                                                 '--nocapture','--test-threads=1'])))
        assert 'test result: ok. 12 passed; 0 failed; 1 ignored;' in (OUT/f'{name}.log').read_text()
        for role in ('retain','spill','regenerate'):
            name = f'{LABEL}-preflight-{role}'
            steps.append(run_step(name,[PYTHON,str(Path(driver.__file__)),'run','--label',LABEL,
                       '--name',name,'--data',DATA.name,'--mode','preflight','--role',role,
                       '--cohort','preflight']))
        name = f'{LABEL}-preflight-check'
        preflight_path = OUT / f'{LABEL}-preflight-analysis.json'
        steps.append(run_step(name,guarded(name,[PYTHON,str(driver.ANALYZER),'--mode','preflight',
                                    '--data',str(DATA),'--output',str(preflight_path)])))
        preflight = json.loads(preflight_path.read_text())
        assert preflight['status']=='passed' and preflight['workflows']==117
        assert preflight['protocol_sha256']==driver.PROTOCOL_SHA
        for cohort,roles in (('A',('retain','spill','regenerate')),('B',('regenerate','spill','retain'))):
            for role in roles:
                name = f'{LABEL}-measure-{cohort}-{role}'
                steps.append(run_step(name,[PYTHON,str(Path(driver.__file__)),'run','--label',LABEL,
                           '--name',name,'--data',DATA.name,'--mode','measure','--role',role,'--cohort',cohort]))
        name = f'{LABEL}-decision-check'
        steps.append(run_step(name,guarded(name,[PYTHON,str(driver.ANALYZER),'--mode','measure',
                                   '--data',str(DATA),'--output',str(decision_path)])))
        decision = json.loads(decision_path.read_text())
        assert decision['status']=='passed' and decision['workflows']==240
        assert decision['decision'] in ('reject','pass_finite_comparison_requires_full_acceptance')
        name = f'{LABEL}-final-binding'
        steps.append(run_step(name,[PYTHON,str(Path(driver.__file__)),'verify','--label',LABEL]))
        assert identity['sequence_sha256'] == driver.sha(__file__)
        status = 'passed'
    finally:
        driver.save(OUT/f'{LABEL}-sequence-completion.json',dict(status=status,steps=steps,
                    identity=identity,decision_sha256=driver.sha(decision_path) if decision_path.exists() else None))
    print(json.dumps(dict(status=status,preflight_workflows=117,comparative_workflows=240)),flush=True)


if __name__ == '__main__':
    main()
