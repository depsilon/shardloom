"""Preserve complete finite-comparison evidence and every earlier validation attempt."""

import hashlib
import io
import json
import lzma
from pathlib import Path
import subprocess
import sys
import tarfile

import analyze_rematerialization_779 as analysis
import rematerialization_driver_779 as driver

OUT, REPO = driver.OUT, driver.REPO
LABEL = 'rematerialization-release-779-a1'
DEBUG = 'rematerialization-debug-779-a5'
PACK = OUT / 'rematerialization-portable-779'
ACCEPTED = OUT / 'compact-index-acceptance-source-764.json'
sys.path.insert(0, str(REPO / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    require_local_path(OUT, Path.home(), sys.platform)
    check_budgets(OUT, PACK, OUT, min_free_bytes=12*GIB, reserve_bytes=512*MIB,
                  max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
    assert not PACK.exists()
    completion = json.loads((OUT/f'{LABEL}-sequence-completion.json').read_text())
    assert completion['status'] == 'passed'
    freeze = json.loads((OUT/f'{LABEL}-source-freeze.json').read_text())
    driver.verify_sources(freeze)
    driver.verify_historical_sources(LABEL, freeze)
    for label, mode, suffix in ((DEBUG,'smoke','analysis'), (LABEL,'preflight','preflight-analysis'),
                                (LABEL,'measure','decision')):
        actual = analysis.analyze(OUT/f'{label}-data', mode)
        saved = json.loads((OUT/f'{label}-{suffix}.json').read_text())
        assert actual == saved, (label, mode)
    decision = json.loads((OUT/f'{LABEL}-decision.json').read_text())
    accepted = json.loads(ACCEPTED.read_text())['source_hashes']
    assert len(accepted) == 2217
    modified = subprocess.check_output(['git','diff','--name-only'],cwd=REPO,text=True).splitlines()
    assert set(modified) == {
        'shardloom-vortex/src/local_primitive_prepared_relational.rs',
        'shardloom-vortex/src/local_primitive_relational_tests.rs',
        'shardloom-vortex/src/local_primitive_relational_transform.rs'}
    extras = set(freeze['extra_sources'])
    baseline, members, seen, omitted = [], {}, set(), []

    def add(name, original, raw=None):
        assert name not in members and not Path(name).is_absolute() and '..' not in Path(name).parts
        if raw is None:
            path = Path(original)
            assert path.is_file() and not path.is_symlink(), path
            raw = path.read_bytes()
            seen.add(str(path))
        members[name] = (dict(path=name, original_path=str(original), bytes=len(raw), sha256=sha(raw)), raw)

    for row in freeze['sources']:
        relative = row['path']
        if relative in extras:
            continue
        raw = (subprocess.check_output(['git','show',f'{driver.PRODUCTION_HEAD}:{relative}'],cwd=REPO)
               if relative in modified else (REPO/relative).read_bytes())
        assert sha(raw) == accepted[relative], relative
        baseline.append(dict(path=relative,bytes=len(raw),sha256=sha(raw)))
        add(f'sources/accepted-base/{relative}', f'git:{driver.PRODUCTION_HEAD}:{relative}', raw)
    assert len(baseline) == 1899
    base_manifest = dict(head=driver.PRODUCTION_HEAD,sources=baseline,
                         accepted_manifest_sha256=driver.sha(ACCEPTED))
    add('sources/accepted-base.json','generated:accepted-base',
        (json.dumps(base_manifest,indent=2)+'\n').encode())
    family = []
    for path in sorted(OUT.iterdir()):
        if 'rematerialization' not in path.name or path == PACK:
            continue
        if path.name.startswith(('rematerialization-package-779', 'rematerialization-packet-verification-779')):
            continue  # A running packager/verifier cannot embed its own future receipt.
        if path.is_file() and path.name.endswith('-test'):
            artifact = json.loads(path.with_name(path.name.removesuffix('-test')+'-artifact.json').read_text())
            identity = artifact.get('artifact_sha256', artifact.get('sha256'))
            assert driver.sha(path)==identity and path.stat().st_size==artifact['bytes']
            omitted.append(dict(path=str(path),bytes=path.stat().st_size,sha256=identity,
                                reason='compiled executable; exact source/build/artifact identity retained'))
        elif path.is_dir():
            assert not path.is_symlink()
            family.extend(p for p in path.rglob('*') if p.is_file())
        elif path.is_file():
            family.append(path)
    for path in sorted(family):
        add(f'evidence/{path.relative_to(OUT).as_posix()}',path)
    helper_paths = {str(ACCEPTED), *[r['path'] for r in freeze['helpers']]}
    for old in ('rematerialization-debug-779-a5-source-freeze.json',):
        helper_paths.update(r['path'] for r in json.loads((OUT/old).read_text())['helpers'])
    for original in sorted(helper_paths):
        if original in seen:
            continue
        path = Path(original)
        if path.is_relative_to(REPO):
            name = f'helpers/repo/{path.relative_to(REPO).as_posix()}'
        elif path.is_relative_to(OUT):
            name = f'evidence/{path.relative_to(OUT).as_posix()}'
        else:
            name = f'helpers/local/{path.relative_to(Path("/Users/dylan/LocalData/shardloom")).as_posix()}'
        add(name,path)
    paths = sorted(members)
    assert len({members[p][0]['original_path'] for p in paths}) == len(paths)
    assert len(omitted)==4
    PACK.mkdir()
    archive_path = PACK/'rematerialization-portable-779.tar.xz'
    with tarfile.open(archive_path,'w:xz',preset=6) as archive:
        for name in paths:
            row, raw = members[name]
            info = tarfile.TarInfo(name)
            info.size=len(raw); info.mode=0o644; info.mtime=0
            archive.addfile(info,io.BytesIO(raw))
    with tarfile.open(archive_path,'r:xz') as archive:
        assert [m.name for m in archive.getmembers()] == paths
        for member in archive:
            row, raw = members[member.name]
            assert member.isfile() and member.size==row['bytes']
            reopened = archive.extractfile(member).read()
            assert reopened==raw and sha(reopened)==row['sha256']
    manifest = dict(status='passed',all_members_reopened=True,
                    production_head=driver.PRODUCTION_HEAD,protocol_sha256=driver.PROTOCOL_SHA,
                    members=[members[p][0] for p in paths],omitted_executables=omitted,
                    decision=decision['decision'],release_workflows=357,debug_workflows=81)
    manifest_path = PACK/'rematerialization-portable-779-manifest.json.xz'
    raw = (json.dumps(manifest,indent=2)+'\n').encode()
    with manifest_path.open('xb') as stream:stream.write(lzma.compress(raw))
    assert lzma.decompress(manifest_path.read_bytes())==raw
    index = dict(status='passed',production_head=driver.PRODUCTION_HEAD,
                 protocol_sha256=driver.PROTOCOL_SHA,decision=decision['decision'],
                 member_count=len(paths),omitted_executables=omitted,
                 release_workflows=357,debug_workflows=81,all_members_reopened=True,
                 archive=dict(file=archive_path.name,bytes=archive_path.stat().st_size,sha256=driver.sha(archive_path)),
                 manifest=dict(file=manifest_path.name,bytes=manifest_path.stat().st_size,sha256=driver.sha(manifest_path)))
    driver.verify_sources(freeze)
    driver.save(PACK/'rematerialization-portable-779.json',index)
    print(json.dumps({k:v for k,v in index.items() if k not in ('omitted_executables',)}))


if __name__=='__main__':
    main()
