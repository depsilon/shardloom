"""Verify immutable dynamic-subquery source and configured hosted coverage."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess

import verify_stream_destination_integrated_sources_482 as immutable
from verify_stream_subquery_integrated_sources_513 import selector_check
from freeze_native_release_298 import ROOT, OUT, sha

HEAD = '18b61c23d1f68bedc8bf70e06a54fb9d7f00f1c6'
BASE = 'c30846afb0ab5abfff6fdb5d95ed20f1c10a9477'
SYNTHETIC = '7892decfc6d45fccd3c3868055f74474f6e11a62'
TREE = 'aac3c4b035752ebfabf72e336762c1b6eb138662'
DEST = OUT / 'stream-dynamic-subquery-hosted-527'


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--merged')
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    selector_check()
    destination = Path(args.output)
    assert not destination.exists() and destination.parent == DEST
    synthetic_path = DEST / 'synthetic-merge-527.json'
    if not synthetic_path.exists():
        command = ['/opt/homebrew/bin/gh', 'api', 'repos/depsilon/shardloom/git/commits/' + SYNTHETIC]
        result = subprocess.run(command, capture_output=True, timeout=60, check=True)
        assert len(result.stdout) < 1 << 20
        synthetic_path.open('xb').write(result.stdout)
    synthetic = json.loads(synthetic_path.read_text())
    assert synthetic['sha'] == SYNTHETIC and synthetic['tree']['sha'] == TREE
    assert [p['sha'] for p in synthetic['parents']] == [BASE, HEAD]
    revisions = dict(pr_head=HEAD, ci_merge=SYNTHETIC)
    if args.merged:
        assert re.fullmatch(r'[a-f0-9]{40}', args.merged)
        revisions['merged'] = args.merged
    trees = {key: (synthetic['tree']['sha'] if key == 'ci_merge' else
             subprocess.check_output(['git', 'rev-parse', rev + '^{tree}'], cwd=ROOT, text=True).strip())
             for key, rev in revisions.items()}
    assert set(trees.values()) == {TREE}
    source, records = immutable.immutable_source_map(HEAD)
    final_path = OUT / 'stream-dynamic-subquery-final-source-525.json'
    accepted = json.loads(final_path.read_text())['source_sha256']
    assert len(source) == len(accepted) == 2303
    assert {name: value['sha256'] for name, value in source.items()} == accepted
    assert all(mode in ('100644', '100755') for _, _, mode in records)
    inventory_path = OUT / 'dynamic-subquery-hosted-coverage-inventory-528.json'
    inventory = json.loads(inventory_path.read_text())
    assert inventory['status'] == 'COMPLETE' and len(inventory['source_sha256']) == 32
    for path, digest in inventory['source_sha256'].items():
        data = subprocess.check_output(['git', 'show', HEAD + ':' + path], cwd=ROOT)
        assert hashlib.sha256(data).hexdigest() == digest, path
    for excerpt in inventory['source_excerpts']:
        path = ROOT / excerpt['file']
        lines = path.read_text().splitlines()
        chunks = []
        for span in excerpt['lines'].split(';'):
            low, high = map(int, span.split('-'))
            assert 1 <= low <= high <= len(lines)
            chunks.append('\n'.join(lines[low - 1:high]))
        actual = '\n'.join(chunks)
        offset = 0
        for block in excerpt['text'].split('\n...\n'):
            position = actual.find(block, offset)
            assert position >= offset, (excerpt['file'], excerpt['lines'], block)
            offset = position + len(block)
    prior = json.loads((OUT / 'dynamic-subquery-hosted-coverage-inventory-527.json').read_text())
    for key in ('target_modules', 'native_binding_pattern', 'python_collection_summary', 'counts'):
        assert prior[key] == inventory[key]
    for old, new in zip(prior['lanes'], inventory['lanes'], strict=True):
        if old['job'] != 'rust-feature-matrix':
            assert old == new
    methods = {}
    for path in sorted((ROOT / 'python/tests').glob('test_native*binding.py')):
        names = [node.name for node in ast.walk(ast.parse(path.read_text()))
                 if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')]
        methods[str(path.relative_to(ROOT))] = names
    assert sum(map(len, methods.values())) == 100
    assert len(methods['python/tests/test_native_dynamic_subquery_binding.py']) == 4
    assert {name: len(values) for name, values in methods.items()} == inventory['native_binding_pattern']['source_level_test_method_counts']
    declarations = inventory['rust_test_gates']['native_vortex_tests']['test_module_chain']['deferred_test_declarations']
    native = []
    for row in [declarations['parent_file'], *declarations['children']]:
        text = (ROOT / row['path']).read_text()
        lines = text.splitlines()
        indices = [i + 1 for i, line in enumerate(lines) if line.strip() == '#[test]']
        assert indices == row['lines'] and len(indices) == row['test_declarations']
        for index in indices:
            name = re.fullmatch(r'fn (\w+)\(\) \{', lines[index].strip())
            assert name, (row['path'], index)
            native.append(dict(path=row['path'], line=index + 1, name=name.group(1)))
    assert len(native) == len({row['name'] for row in native}) == 19
    protocol = json.loads((OUT / 'stream-dynamic-subquery-acceptance-protocol-521.json').read_text())
    assert {row['name'] for row in native} <= set(protocol['native_required_tests'])
    built_path = OUT / 'native-release-artifacts-streamdynamic518.json'
    built = json.loads(built_path.read_text())
    binaries = {}
    for key in ('cli', 'binding'):
        binaries[key] = identity(built[key]['path'])
        assert binaries[key] == {name: built[key][name] for name in ('path', 'bytes', 'sha256')}
    report = dict(status='passed', revisions=revisions, trees=trees, source_files=2303,
        immutable_source=source, accepted=identity(final_path), artifact_manifest=identity(built_path), binaries=binaries,
        synthetic_metadata=identity(synthetic_path), selector_ast_matches=True,
        coverage=dict(inventory=identity(inventory_path), source_files=32, excerpts=38,
            native_tests=native, direct_methods=methods, expected_wheel_lanes=3,
            selection_verified=True, hosted_results_claimed=False),
        excerpt_validation='Verbatim blocks appear in order within cited line ranges; explicit ellipses denote omitted lines.',
        checker_correction=identity(DEST / 'source-checker-correction-527.json'),
        helpers=[identity(__file__), identity(immutable.__file__), identity(OUT / 'verify_stream_subquery_integrated_sources_513.py'),
                 identity(OUT / 'freeze_native_release_298.py')],
        scope='Immutable source, retained binary identity and configured coverage only; execution and final hosted acceptance are separate.')
    destination.open('x').write(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(status='passed', source_files=2303, revisions=revisions, trees=trees,
        coverage_files=32, excerpts=38, native_test_declarations=19, direct_methods=100, output=identity(destination))))


if __name__ == '__main__':
    main()
