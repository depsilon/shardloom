"""Package completed nullable-layout acceptance and reopen every archived member.

No tests or benchmarks are executed. Existing failed attempts are preserved.
"""
import ast
import gzip
import hashlib
import json
import lzma
from pathlib import Path
import sys
import tarfile

import nullable_layout_acceptance_650 as acceptance
from freeze_native_release_298 import ROOT as R, OUT as O, save, sha
from package_selection_acceptance_409 import Members, verify, sha_stream

sys.path[:0] = [str(R / 'scripts'), str(R / 'benchmarks/traditional_analytics')]
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
from metadata_public_verifier_534 import verify_public
from native_workflow_protocol import extract_result, report_fields, strict_json
from query_timing_report import query_phase_timings, timing_totals
from run_clickbench_query_uat import equivalent, score

STEM = 'native-nullable-layout-2026-10-18'
LOCAL = O / 'nullable-layout-evidence-652'
DEST = R / 'docs/benchmarks/evidence'
read = lambda path: json.loads(Path(path).read_text())
acceptance.prerequisites()
protocol = acceptance.protocol()
source, build = acceptance.unchanged(), acceptance.load()
assert len(source['source_sha256']) == 2416
direct = read(acceptance.DIRECT)
assert direct['status'] == 'passed' and direct['tests'] == 100
assert direct['failures'] == direct['errors'] == direct['skipped'] == 0
assert direct['test_names'] == protocol['expected_direct_names']
public_review = read(O / 'nullable-layout-public-inspection-report-650.json')
assert public_review['status'] == 'passed' and public_review['cases'] == 4827
assert public_review['families'] == 36
full43 = read(O / 'nullable-layout-full43-review-650.json')
assert full43['status'] == 'passed' and full43['queries'] == full43['calls'] == 43
assert full43['accepted_source'] == acceptance.identity(acceptance.SOURCE)
assert full43['all_values_schemas_and_clocks_reopened'] and not full43['performance_claim_allowed']
modular = read(O / 'nullable-layout-modular-review-651.json')
assert modular['status'] == 'passed' and modular['records'] == 1408
assert modular['native_records'] == modular['oracle_records'] == 704
assert modular['complete_results_reopened'] and len(modular['cohorts']) == 18
assert modular['source'] == acceptance.identity(acceptance.SOURCE)
assert not modular['complete_cartesian_input_output_coverage_claimed']
inventory = read(O / 'nullable-layout-test-inventory-652.json')
assert inventory['counts']['current_total'] == {'passed': 8810, 'failed': 0, 'ignored': 28}
assert inventory['ignored_native_selectors']['reason_maps_equal']
assert inventory['verification']['all_current_and_comparison_receipts_verified']
assert inventory['verification']['all_gate_result_files_verified']
for item in [inventory['created_by'], *inventory['inputs'].values()]:
    assert acceptance.identity(item['path']) == item
for name in ('nullable-layout-direct-650', 'nullable-layout-public-650',
             'nullable-layout-full43-650', 'nullable-layout-modular-651'):
    acceptance.receipt(O / (name + '.json'))
assert not LOCAL.exists() and not any(DEST.glob(STEM + '*'))
require_local_path(LOCAL, Path.home(), sys.platform)
check_budgets(O, LOCAL, O / 'logs', min_free_bytes=12*GIB, reserve_bytes=512*MIB,
              max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
LOCAL.mkdir()
members, aliases, exclusions, helpers = Members(), {}, [], []


def add(path, name, role, digest=None):
    path = Path(path)
    root = R if path.is_relative_to(R) else O if path.is_relative_to(O) else path.parent
    item = members.add(path, name, root.name, root, role, digest)
    if item.name != name:
        aliases[name] = item.name
    return item


def bound(item, prefix, role):
    current = acceptance.identity(item['path'])
    assert all(current[key] == value for key, value in item.items() if key in current)
    path = Path(item['path']).resolve()
    relative = ('repo/' + path.relative_to(R).as_posix() if path.is_relative_to(R)
                else 'local/' + path.relative_to(O).as_posix() if path.is_relative_to(O)
                else 'external/' + path.as_posix().lstrip('/'))
    return add(path, prefix + '/' + relative, role, item['sha256'])


for name, digest in source['source_sha256'].items():
    add(R / name, 'runtime-source/' + name, 'complete accepted source', digest)
for name in ('docs/architecture/native-nullable-layout-2026-10-18.md',
             'docs/architecture/native-drop-review-2026-10-18.md',
             'docs/benchmarks/native-nullable-layout-2026-10-18.md',
             'docs/rfcs/0044-resident-runtime-resource-ownership.md',
             '.github/workflows/ci.yml', 'docs/release/ci-gate-matrix.md'):
    add(R / name, 'contracts/' + name, 'implementation and CI contract at packaging')
for item in protocol['helpers'] + protocol['checks'] + [protocol[key] for key in
        ('source', 'artifacts', 'prior_protocol', 'baseline', 'contract')]:
    bound(item, 'protocol-inputs', 'predeclared immutable acceptance identity')
    if Path(item['path']).suffix in ('.py', '.sh'):
        helpers.append(Path(item['path']))
for item in inventory['inputs'].values():
    bound(item, 'test-inputs', 'complete test inventory and historical ignore comparison')
add(O / 'native-file-nullable-root-default-scan-572.rs',
    'original-failure/native-file-nullable-root-default-scan-572.rs',
    'original failing provider fixture snapshot; not the final source')
hosted_inventory = read(O / 'nullable-layout-hosted-test-inventory-652.json')
for key in ('created_by', 'source_manifest', 'hosted_launch_input'):
    bound(hosted_inventory[key], 'test-inputs', 'exact-source hosted test inventory input')
for path, name in [
    (O / 'stream-unary-candidate-declarations-493b/logs/unary-predeclared-values.json',
     'predeclared-reference/unary-predeclared-values.json'),
    (O / 'stream-subquery-candidate-declarations-509/subqueries/logs/subquery-predeclared-results.json',
     'predeclared-reference/subquery-predeclared-results.json'),
    (O / 'stream-dynamic-subquery-candidate-declarations-521/dynamic-subqueries/logs/dynamic-subquery-predeclared-results.json',
     'declarations-521/dynamic-subqueries/logs/dynamic-subquery-predeclared-results.json'),
    (O / 'stream-dynamic-subquery-candidate-declarations-521/dynamic-subqueries-pressure/logs/dynamic-subquery-pressure-fixtures.json',
     'declarations-521/dynamic-subqueries-pressure/logs/dynamic-subquery-pressure-fixtures.json'),
    (Path(protocol['baseline']['path']), 'baseline/summary.json'),
]:
    add(path, name, 'complete immutable public reference')
members.tree(acceptance.PUBLIC, 'public', 'public',
             'all complete public values, envelopes and pressure fixtures', exclusions, omit_outputs=True)
admission = read(full43['admission']['path'])
for key in ('reference', 'queries', 'driver', 'reused_helper'):
    bound(admission[key], 'full43-inputs', 'single-pass regression input')
for item in admission['harness'] + admission['schema_sources']:
    bound(item, 'full43-inputs', 'single-pass harness and exact schema reference')
full43_root = Path(full43['summary']['path']).parent
members.tree(full43_root, 'full43', 'full43', 'all 43 complete values, schemas and clocks', exclusions)
mod_root = O / 'fresh-timed-uat-461'
members.tree(mod_root / 'nullable-layout-matrix-651', 'modular', 'modular',
             'all 18 finite format/workflow cohorts and independent oracle records', exclusions)
for path in sorted(mod_root.glob('nullable-layout-matrix-651-*')):
    if path.is_file():
        add(path, 'modular-receipts/' + path.name, 'complete format/workflow acceptance')
prefixes = ('nullable-layout-', 'native-release-source-nullable',
            'native-release-artifacts-nullable', 'native-final-source-gate-results-nullable',
            'native-final-cli-release-build-nullable', 'native-final-python-release-build-nullable')
for path in sorted(O.iterdir()):
    if path.is_file() and path.name.startswith(prefixes) and path.suffix in ('.json', '.log', '.py', '.md', '.patch'):
        if path.name.startswith('nullable-layout-archive-652'):
            continue  # The active packaging guard log is still being written.
        add(path, 'receipts/' + path.name, 'original acceptance, build and failure evidence')
for item in [build['cli'], build['binding'], admission['input']]:
    exclusions.append(dict(original_absolute_path=item['path'], byte_count=item['bytes'],
                           sha256=item['sha256'], reason='bulk input or executable; exact identity retained'))
helpers += [Path(__file__), O / 'inventory_nullable_tests_652.py',
            O / 'inventory_nullable_hosted_tests_652.py',
            O / 'run_nullable_layout_full43_650.py', O / 'run_nullable_modular_651.py',
            O / 'nullable_layout_acceptance_650.py', O / 'run_nullable_layout_validation_649.py',
            O / 'run_nullable_layout_validation_649_before_native_env_fix.py',
            O / 'validate_nullable_ci_bridge_650.py',
            O / 'validate_nullable_ci_bridge_650_before_marker_scope_fix.py',
            mod_root / 'run_modular_acceptance.py', O / 'metadata_public_verifier_534.py',
            O / 'package_selection_acceptance_409.py', O / 'run_guarded.py',
            Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')]
roots = (O, R / 'scripts', R / 'python/src',
         Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930'))
visited = set()
while helpers:
    path = helpers.pop().resolve()
    if path in visited:
        continue
    visited.add(path)
    relative = ('local/' + path.relative_to(O).as_posix() if path.is_relative_to(O)
                else 'repo/' + path.relative_to(R).as_posix() if path.is_relative_to(R)
                else 'external/' + path.parent.name + '/' + path.name)
    add(path, 'dependencies/' + relative, 'reproduction helper and local import closure')
    if path.suffix != '.py':
        continue
    for node in ast.walk(ast.parse(path.read_text())):
        names = ([item.name for item in node.names] if isinstance(node, ast.Import)
                 else [node.module] if isinstance(node, ast.ImportFrom) and node.module and node.level == 0 else [])
        for name in names:
            for root in roots:
                candidate = root.joinpath(*name.split('.')).with_suffix('.py')
                if not candidate.is_file():
                    candidate = root.joinpath(*name.split('.')) / '__init__.py'
                if candidate.is_file():
                    helpers.append(candidate)
                    break
ordered = sorted(members.paths.values(), key=lambda item: item.name)
raw_bytes = sum(item.size for item in ordered)
assert raw_bytes < 768*MIB
assert {item.name.removeprefix('runtime-source/') for item in ordered
        if item.name.startswith('runtime-source/')} == set(source['source_sha256'])
storage = check_budgets(O, LOCAL, O / 'logs', min_free_bytes=12*GIB,
                       reserve_bytes=raw_bytes+64*MIB, max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
save(LOCAL / 'selection.json', dict(members=[dict(path=str(item.path), archive_path=item.name,
     bytes=item.size, sha256=item.digest, roles=item.roles) for item in ordered],
     aliases=aliases, exclusions=exclusions, raw_bytes=raw_bytes))
parts, group, size = [], [], 0
for item in ordered:
    assert item.size <= 80*MIB
    if group and size + item.size > 80*MIB:
        parts.append(group)
        group, size = [], 0
    group.append(item)
    size += item.size
if group:
    parts.append(group)
archives, archive_for, portable, seen = {}, {}, {}, set()
keep = ('public/', 'full43/', 'full43-inputs/', 'predeclared-reference/', 'declarations-521/', 'baseline/')
keep_targets = {target for alias, target in aliases.items() if alias.startswith(keep)}
for number, group in enumerate(parts, 1):
    name = STEM + ('.tar.xz' if number == 1 else f'.part-{number}.tar.xz')
    path = LOCAL / name
    with path.open('xb') as output:
        with tarfile.open(fileobj=output, mode='w:xz', preset=6, format=tarfile.PAX_FORMAT) as tar:
            for item in group:
                verify(item.path, item.digest, item.size)
                info = tarfile.TarInfo(item.name)
                info.size, info.mode, info.mtime = item.size, 0o644, 0
                with item.path.open('rb') as stream:
                    tar.addfile(info, stream)
                archive_for[item.name] = name
    with tarfile.open(path, 'r|xz') as tar:
        for entry in tar:
            assert entry.isfile() and entry.name in members.names and entry.name not in seen
            item = members.paths[members.names[entry.name]]
            assert archive_for[entry.name] == name
            with tar.extractfile(entry) as stream:
                if entry.name.startswith(keep) or entry.name in keep_targets:
                    data = stream.read()
                    assert (len(data), hashlib.sha256(data).hexdigest()) == (item.size, item.digest)
                    portable[entry.name] = data
                else:
                    assert sha_stream(stream) == (item.size, item.digest)
            seen.add(entry.name)
    archives[name] = dict(file=name, bytes=path.stat().st_size, sha256=sha(path),
                         raw_bytes=sum(item.size for item in group), member_count=len(group))
    assert path.stat().st_size < 100*MIB
    print(json.dumps(dict(stage='archive_verified', part=number, members=len(group))), flush=True)
assert seen == set(members.names)
for alias, target in aliases.items():
    if target in portable:
        portable[alias] = portable[target]
public = verify_public(portable, (O / 'nullable-layout-public-650.log').read_bytes(), protocol)
assert public['pressure_rows'] == public_review['pressure_rows']


def packed(path):
    return portable[members.paths[Path(path).resolve()].name]


summary = strict_json(packed(full43['summary']['path']))
reference = strict_json(packed(admission['reference']['path']))
expected = {row['query_id']: row['values'] for row in reference['records']}
schema_protocol = strict_json(packed(admission['schema_sources'][0]['path']))
assert summary['complete'] and len(summary['records']) == 43 and summary['repeats'] == 1
assert {(row['query'], row['run']) for row in summary['records']} == {(q, 1) for q in range(1, 44)}
for row in summary['records']:
    assert row['passed'] and row['returncode'] == 0 and not row['guard_failures']
    envelope = None
    for item in row['completed_log_archives']:
        encoded = packed(item['path'])
        assert len(encoded) == item['gzip_bytes'] and hashlib.sha256(encoded).hexdigest() == item['gzip_sha256']
        data = gzip.decompress(encoded)
        assert len(data) == item['raw_bytes'] and hashlib.sha256(data).hexdigest() == item['raw_sha256']
        if item['path'].endswith('.stdout.json.gz'):
            assert envelope is None
            envelope = strict_json(data)
    assert envelope is not None
    actual, fields = extract_result(envelope), report_fields(envelope)
    assert equivalent(actual, expected[row['query']])
    assert hashlib.sha256(json.dumps(actual, sort_keys=True, allow_nan=False).encode()).hexdigest() == row['result_sha256']
    assert [fields['result_schema_format'], strict_json(fields['result_schema_json'])] == schema_protocol['expected_schemas'][str(row['query'])]
    timing_path = full43_root / f"q{row['query']:02d}_run1.timing.json"
    timing = strict_json(packed(timing_path))
    assert timing['returncode'] == 0
    assert all(timing[key] == row[key] for key in ('seconds', 'user_cpu_seconds', 'system_cpu_seconds'))
    for key, value in query_phase_timings(fields, timing['seconds']).items():
        assert row[key] == value
    assert fields['execution_resource_declared_memory_bytes'] == str(24*GIB)
    assert fields['execution_resource_declared_max_parallelism'] == '12'
    assert fields['execution_resource_whole_process_memory_limit_enforced'] == 'false'
    assert any(item['kind'] == 'native_io_certificate' and item['status'] == 'available'
               for item in envelope['certificates'])
    for key, value in fields.items():
        if key.endswith(('fallback_attempted', 'fallback_execution_allowed', 'external_engine_invoked')):
            assert value in (False, 'false')
for key, value in score(summary['records'], 43, repeats=1, timing_key='engine_execution_seconds').items():
    assert summary[key] == value
assert timing_totals(summary['records']) == full43['timing_totals']
for item in ordered:
    verify(item.path, item.digest, item.size)
assert acceptance.unchanged() == source and acceptance.load() == build
acceptance.protocol()
manifest = dict(schema_version='shardloom.native_nullable_layout_evidence.v1',
    status='passed_local_evidence_packaged', base_commit=source['head'], source_files=2416,
    source_manifest=acceptance.identity(acceptance.SOURCE), artifact_manifest=acceptance.identity(acceptance.MANIFEST),
    frozen_contract_copy=protocol['contract'],
    members=[dict(path=str(item.path), archive_path=item.name, archive_file=archive_for[item.name],
        bytes=item.size, sha256=item.digest, roles=item.roles) for item in ordered],
    member_count=len(ordered), raw_bytes=raw_bytes, archives=archives, archive_aliases=aliases,
    all_members_reopened=True, exclusions=exclusions, storage=storage,
    test_inventory=acceptance.identity(O / 'nullable-layout-test-inventory-652.json'),
    acceptance=dict(rust_test_executions=8810, rust_ignored=28, direct_tests=100,
        public_cases=4827, public_families=36, full43_calls=43,
        modular_cohorts=18, native_workflows=704, independent_oracle_records=704),
    public_reopened=public, full43_review=acceptance.identity(O / 'nullable-layout-full43-review-650.json'),
    full43_engine_seconds=sum(row['engine_execution_seconds'] for row in summary['records']),
    modular_review=acceptance.identity(O / 'nullable-layout-modular-review-651.json'),
    limitations=[
        'Scoped nullable structural-layout correctness and private native-run readback; broader PERF and CG gates remain open.',
        'Full43 is one retained-native regression pass with uncontrolled OS cache state, not a comparative performance claim.',
        'Format/workflow coverage is a finite eight-input/eight-output star, not the full input-output Cartesian product.',
        'Memory admission is not a whole-process RSS ceiling; private run-store fixtures admit no new public spill family.',
        'Bulk inputs, binaries and public output files are excluded with exact identities; complete result evidence is retained.',
        'Hosted integration, installed-wheel lanes and final-head checks are recorded separately.'],
    source_identity_preserved=True, publication_attempted=False, performance_claim=False,
    hosted_integration_complete=False)
raw = (json.dumps(manifest, sort_keys=True, indent=2) + '\n').encode()
encoded = lzma.compress(raw, preset=6)
assert lzma.decompress(encoded) == raw
manifest_path = LOCAL / (STEM + '.manifest.json.xz')
manifest_path.open('xb').write(encoded)
index = {key: value for key, value in manifest.items()
         if key not in ('members', 'exclusions', 'storage', 'archive_aliases')}
index['manifest'] = dict(file=manifest_path.name, bytes=len(encoded), sha256=sha(manifest_path),
                         raw_sha256=hashlib.sha256(raw).hexdigest())
for path in [*(LOCAL / name for name in archives), manifest_path]:
    target = DEST / path.name
    target.open('xb').write(path.read_bytes())
    assert sha(target) == sha(path)
save(DEST / (STEM + '.json'), index)
save(LOCAL / 'verification.json', dict(status='all_members_reopened', member_count=len(ordered),
    archives=archives, public_reopened=public, full43_calls=43,
    manifest=acceptance.identity(manifest_path), index=acceptance.identity(DEST / (STEM + '.json'))))
print(json.dumps(dict(status='passed_local_evidence_packaged', members=len(ordered),
                     archives=len(archives), full43_calls=43)), flush=True)
