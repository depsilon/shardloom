#!/usr/bin/env python3
"""Build a receipt-backed nullable-layout native test inventory."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

OUT = Path("/Users/dylan/LocalData/shardloom/native-python-surface-20261010")
INPUT_NAMES = [
    "nullable-layout-workspace-gates-649.log",
    "nullable-layout-native-gates-649-a1.log",
    "nullable-layout-provider-gates-649.log",
    "nullable-layout-file-provider-tests-649.log",
    "native-text-scan-native-gates-644.log",
    "nullable-layout-workspace-gates-649.json",
    "native-final-source-gate-results-nullable649.json",
    "nullable-layout-native-gates-649-a1.json",
    "nullable-layout-native-results-649-a1.json",
    "nullable-layout-provider-gates-649.json",
    "nullable-layout-provider-results-649.json",
    "nullable-layout-file-provider-tests-649.json",
    "native-text-scan-native-gates-644.json",
    "native-final-source-gate-results-textscan644.json",
    "native-final-feature-gate-results-textscan644.json",
]


def file_record(name: str) -> dict:
    path = OUT / name
    data = path.read_bytes()
    return {
        "path": str(path),
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
    }


def read_json(name: str) -> dict:
    return json.loads((OUT / name).read_text())


def parse_test_results(lines: list[str]) -> tuple[list[dict], dict]:
    results = []
    current_gate = None
    totals = {"passed": 0, "failed": 0, "ignored": 0}
    for line_no, line in enumerate(lines, 1):
        try:
            marker = json.loads(line)
        except (json.JSONDecodeError, TypeError):
            marker = None
        if isinstance(marker, dict) and "gate" in marker:
            current_gate = marker["gate"]
        if "test result:" not in line:
            continue
        match = re.search(
            r"test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; "
            r"(\d+) ignored; (\d+) measured; (\d+) filtered out; finished in (.+)",
            line,
        )
        if not match:
            raise ValueError(f"unparsed test-result line {line_no}: {line}")
        passed, failed, ignored, measured, filtered = map(int, match.groups()[:5])
        totals["passed"] += passed
        totals["failed"] += failed
        totals["ignored"] += ignored
        results.append(
            {
                "line_number": line_no,
                "gate": current_gate,
                "literal": line,
                "passed": passed,
                "failed": failed,
                "ignored": ignored,
                "measured": measured,
                "filtered_out": filtered,
            }
        )
    return results, totals


def ignored_selectors(lines: list[str]) -> dict[str, str]:
    found = {}
    for line in lines:
        match = re.match(r"test (.*?) \.\.\. ignored, (.*)$", line)
        if match:
            selector, reason = match.groups()
            if selector in found:
                raise ValueError(f"duplicate ignored selector {selector}")
            found[selector] = reason
    return found


def passed_lines(lines: list[str], selectors: set[str]) -> list[dict]:
    result = []
    for line_no, line in enumerate(lines, 1):
        match = re.match(r"test (.*?) \.\.\. ok$", line)
        if match and match.group(1) in selectors:
            result.append({"line_number": line_no, "literal": line})
    return result


def check_guard(log_name: str, receipt_name: str) -> dict:
    receipt = read_json(receipt_name)
    record = file_record(log_name)
    checks = {
        "status_passed": receipt.get("status") == "passed",
        "returncode_zero": receipt.get("returncode") == 0,
        "output_bytes_match": receipt.get("output_bytes") == record["bytes"],
        "log_sha256_match": receipt.get("log_sha256") == record["sha256"],
        "process_group_drained": receipt.get("process_group_drained") is True,
        "direct_child_reaped": receipt.get("direct_child_reaped") is True,
        "not_timed_out": receipt.get("timed_out") is False,
        "group_absence_proved": receipt.get("group_absence_unproved_at_cleanup") is False,
    }
    return {
        "log": log_name,
        "receipt": receipt_name,
        "checks": checks,
        "verified": all(checks.values()),
        "receipt_status": receipt.get("status"),
        "returncode": receipt.get("returncode"),
        "log_sha256": receipt.get("log_sha256"),
        "output_bytes": receipt.get("output_bytes"),
        "process_group_drained": receipt.get("process_group_drained"),
        "direct_child_reaped": receipt.get("direct_child_reaped"),
        "group_absence_unproved_at_cleanup": receipt.get("group_absence_unproved_at_cleanup"),
    }


def check_result_file(name: str) -> dict:
    data = read_json(name)
    gates = data.get("gates", [])
    gate_checks = [
        {
            "name": gate.get("name"),
            "returncode": gate.get("returncode"),
            "verified": gate.get("returncode") == 0,
            "command": gate.get("command"),
        }
        for gate in gates
    ]
    return {
        "file": name,
        "status": data.get("status"),
        "verified": data.get("status") == "passed" and all(g["verified"] for g in gate_checks),
        "gates": gate_checks,
    }


def main() -> None:
    input_records = {name: file_record(name) for name in INPUT_NAMES}
    logs = {
        name: (OUT / name).read_text(errors="replace").splitlines()
        for name in INPUT_NAMES
        if name.endswith(".log")
    }
    current_logs = [
        "nullable-layout-workspace-gates-649.log",
        "nullable-layout-native-gates-649-a1.log",
        "nullable-layout-provider-gates-649.log",
        "nullable-layout-file-provider-tests-649.log",
    ]
    result_lines = {}
    totals = {"passed": 0, "failed": 0, "ignored": 0}
    for name in current_logs:
        result_lines[name], local = parse_test_results(logs[name])
        for key in totals:
            totals[key] += local[key]

    current_ignored = ignored_selectors(logs["nullable-layout-native-gates-649-a1.log"])
    previous_ignored = ignored_selectors(logs["native-text-scan-native-gates-644.log"])
    previous_result_lines, previous_totals = parse_test_results(
        logs["native-text-scan-native-gates-644.log"]
    )

    structural_names = {
        "layouts::struct_::reader::tests::nullable::empty_nullable_record_schema_and_root_validity_survive",
        "layouts::struct_::reader::tests::nullable::nullable_projection_reads_only_its_field_and_validity",
        "layouts::struct_::reader::tests::nullable::nullable_filters_and_pruning_preserve_parent_null_semantics",
        "layouts::struct_::reader::tests::nullable::nullable_projections_match_native_expressions_for_all_masks",
    }
    file_names = {
        "tests::write_empty_nullable_top_level_struct",
        "tests::write_nullable_nested_struct",
        "tests::write_nullable_top_level_struct",
    }
    writer_name = "local_primitives::native_writer::tests::persisted_nullable_root_keeps_schema_and_omits_unmasked_statistics"
    run_store_name = "local_primitives::query_run_store::tests::nullable_root_native_runs_preserve_schema_values_retention_and_cleanup"

    passed_evidence = {
        "structural_reader_tests": passed_lines(
            logs["nullable-layout-provider-gates-649.log"], structural_names
        ),
        "nullable_file_fixtures": passed_lines(
            logs["nullable-layout-file-provider-tests-649.log"], file_names
        ),
        "persisted_native_writer_fixture": {
            "current": passed_lines(
                logs["nullable-layout-native-gates-649-a1.log"], {writer_name}
            ),
            "previous": passed_lines(logs["native-text-scan-native-gates-644.log"], {writer_name}),
        },
        "nullable_query_run_store_regression": passed_lines(
            logs["nullable-layout-native-gates-649-a1.log"], {run_store_name}
        ),
    }

    guards = [
        check_guard("nullable-layout-workspace-gates-649.log", "nullable-layout-workspace-gates-649.json"),
        check_guard("nullable-layout-native-gates-649-a1.log", "nullable-layout-native-gates-649-a1.json"),
        check_guard("nullable-layout-provider-gates-649.log", "nullable-layout-provider-gates-649.json"),
        check_guard("nullable-layout-file-provider-tests-649.log", "nullable-layout-file-provider-tests-649.json"),
        check_guard("native-text-scan-native-gates-644.log", "native-text-scan-native-gates-644.json"),
    ]
    gate_results = [
        check_result_file("native-final-source-gate-results-nullable649.json"),
        check_result_file("nullable-layout-native-results-649-a1.json"),
        check_result_file("nullable-layout-provider-results-649.json"),
        check_result_file("native-final-source-gate-results-textscan644.json"),
        check_result_file("native-final-feature-gate-results-textscan644.json"),
    ]

    # File-provider result JSON is also its execution receipt and contains its exact command.
    file_receipt = read_json("nullable-layout-file-provider-tests-649.json")
    file_command_result = {
        "file": "nullable-layout-file-provider-tests-649.json",
        "status": file_receipt.get("status"),
        "verified": file_receipt.get("status") == "passed" and file_receipt.get("returncode") == 0,
        "command": file_receipt.get("command"),
        "returncode": file_receipt.get("returncode"),
    }
    gate_results.append(file_command_result)

    test_commands = {
        "workspace": {
            "result_json": "native-final-source-gate-results-nullable649.json",
            "attribution": "per-command exact attribution from gate marker JSON lines in log",
            "command_counts": {},
        },
        "native": {
            "result_json": "nullable-layout-native-results-649-a1.json",
            "attribution": "per-command exact attribution from gate marker JSON lines in log",
            "command_counts": {},
        },
        "provider": {
            "result_json": "nullable-layout-provider-results-649.json",
            "attribution": "layout-tests marker; clippy gates have no test-result lines",
            "command_counts": {},
        },
        "file_provider": {
            "result_json": "nullable-layout-file-provider-tests-649.json",
            "attribution": "single recorded cargo test command",
            "command_counts": {},
        },
    }
    for name in current_logs:
        key = (
            "workspace" if "workspace" in name else
            "native" if "native-gates" in name else
            "provider" if "provider-gates" in name else "file_provider"
        )
        for row in result_lines[name]:
            gate = row["gate"] or "aggregate_log_counts"
            bucket = test_commands[key]["command_counts"].setdefault(
                gate, {"passed": 0, "failed": 0, "ignored": 0, "literal_result_lines": []}
            )
            for field in ("passed", "failed", "ignored"):
                bucket[field] += row[field]
            bucket["literal_result_lines"].append(row["literal"])

    result = {
        "schema_version": "shardloom.nullable_test_inventory.v1",
        "created_by": {
            "path": str(OUT / "inventory_nullable_tests_652.py"),
            "sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "bytes": Path(__file__).stat().st_size,
        },
        "inputs": input_records,
        "scope": {
            "current_logs": current_logs,
            "previous_ignored_comparison_log": "native-text-scan-native-gates-644.log",
            "guard_receipts_and_gate_results_read": True,
            "caveats": [
                "Current aggregate totals sum every test-result line across the four current logs; overlapping test binaries across separate commands remain separate invocations.",
                "Workspace log is attributed by its literal gate markers; where no marker is available, the result is labeled aggregate_log_counts.",
                "Clippy and formatting commands are retained in gate evidence but excluded from test totals.",
                "Ignored selectors and reasons are taken verbatim from the two captured native cargo test logs and compared directly.",
                "The previous native text-scan log is used only for ignored-selector equality and persisted writer fixture comparison; it is excluded from current totals.",
            ],
        },
        "verification": {
            "guard_receipts": guards,
            "all_current_and_comparison_receipts_verified": all(g["verified"] for g in guards),
            "gate_result_files": gate_results,
            "all_gate_result_files_verified": all(g["verified"] for g in gate_results),
        },
        "counts": {
            "current_total": totals,
            "current_logs": {
                name: {
                    "totals": parse_test_results(logs[name])[1],
                    "literal_test_result_lines": result_lines[name],
                }
                for name in current_logs
            },
            "previous_native_text_scan_comparison": {
                "totals": previous_totals,
                "literal_test_result_lines": previous_result_lines,
            },
            "test_command_attribution": test_commands,
        },
        "ignored_native_selectors": {
            "current_log": "nullable-layout-native-gates-649-a1.log",
            "previous_log": "native-text-scan-native-gates-644.log",
            "current_count": len(current_ignored),
            "previous_count": len(previous_ignored),
            "selector_sets_equal": set(current_ignored) == set(previous_ignored),
            "reason_maps_equal": current_ignored == previous_ignored,
            "current_only": sorted(set(current_ignored) - set(previous_ignored)),
            "previous_only": sorted(set(previous_ignored) - set(current_ignored)),
            "reason_changes": [
                {"selector": name, "current": current_ignored[name], "previous": previous_ignored[name]}
                for name in sorted(set(current_ignored) & set(previous_ignored))
                if current_ignored[name] != previous_ignored[name]
            ],
            "selectors": [
                {"selector": name, "reason": current_ignored[name]}
                for name in sorted(current_ignored)
            ],
        },
        "passed_test_evidence": passed_evidence,
    }

    if not result["verification"]["all_current_and_comparison_receipts_verified"]:
        raise SystemExit("one or more run guard receipts did not verify")
    if not result["verification"]["all_gate_result_files_verified"]:
        raise SystemExit("one or more gate result JSON files did not verify")
    if len(current_ignored) != 28 or len(previous_ignored) != 28:
        raise SystemExit("expected 28 ignored selectors in both native logs")
    if set(current_ignored) != set(previous_ignored) or current_ignored != previous_ignored:
        raise SystemExit("ignored selector sets or reason maps differ")
    if totals != {"passed": 8810, "failed": 0, "ignored": 28}:
        raise SystemExit(f"unexpected current test totals: {totals}")
    if any(len(passed_evidence[key]) != count for key, count in [
        ("structural_reader_tests", 4), ("nullable_file_fixtures", 3),
        ("nullable_query_run_store_regression", 1),
    ]):
        raise SystemExit("one or more requested passed-test lines were absent")
    if len(passed_evidence["persisted_native_writer_fixture"]["current"]) != 1:
        raise SystemExit("current native-writer fixture pass line was absent")
    if len(passed_evidence["persisted_native_writer_fixture"]["previous"]) != 1:
        raise SystemExit("previous native-writer fixture pass line was absent")

    output = OUT / "nullable-layout-test-inventory-652.json"
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "output": str(output),
        "passed": totals["passed"],
        "failed": totals["failed"],
        "ignored": totals["ignored"],
        "ignored_selectors_equal": result["ignored_native_selectors"]["reason_maps_equal"],
        "all_receipts_verified": result["verification"]["all_current_and_comparison_receipts_verified"],
        "all_gate_results_verified": result["verification"]["all_gate_result_files_verified"],
    }, indent=2))


if __name__ == "__main__":
    main()
