"""Run and reopen the established finite format/workflow matrix for nullable scans."""
import json
from pathlib import Path
import subprocess
import sys

import nullable_layout_acceptance_650 as acceptance
from freeze_native_release_298 import ROOT, OUT, save

identity = acceptance.identity
wrapper_identity = identity(Path(__file__))
manifest = acceptance.load()
acceptance.prerequisites()
acceptance.protocol()
full43_path = OUT / 'nullable-layout-full43-review-650.json'
full43 = json.loads(full43_path.read_text())
assert full43['status'] == 'passed' and full43['queries'] == full43['calls'] == 43
assert full43['accepted_source'] == identity(acceptance.SOURCE)
source = acceptance.unchanged()
driver = OUT / 'fresh-timed-uat-461/run_modular_acceptance.py'
driver_identity = identity(driver)
working_tree = subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip()
build_path = OUT / 'nullable-layout-modular-build-651.json'
save(build_path, dict(binary=manifest['cli']['path'], binary_sha256=manifest['cli']['sha256'],
    source_commit=source['head'], accepted_source_commit=source['head'],
    working_tree=working_tree, features=['release-user-surfaces'], profile='release',
    source_hashes=source['source_sha256'], source_manifest=identity(acceptance.SOURCE),
    artifact_manifest=identity(acceptance.MANIFEST)))
paths = [ROOT / 'python/src', ROOT / 'scripts',
         Path('/Users/dylan/LocalData/shardloom/native-typed-reductions-20261004/python-deps')]
command = [sys.executable, '-B', str(OUT / 'run_guarded_nullable_layout_648.py'),
    '--name', 'nullable-layout-modular-651', '--timeout', '2400', '--',
    '/usr/bin/env', 'PYTHONPATH=' + ':'.join(map(str, paths)), sys.executable, '-B', str(driver),
    '--repo', str(ROOT), '--build-manifest', str(build_path), '--prefix', 'nullable-layout', '--attempt', '651']
subprocess.run(command, cwd=ROOT, check=True)
acceptance.receipt(OUT / 'nullable-layout-modular-651.json')
report_path = OUT / 'fresh-timed-uat-461/nullable-layout-matrix-651-report.json'
report = json.loads(report_path.read_text())
assert report['status'] == 'passed' and report['records'] == 1408 and report['native_records'] == 704
assert len(report['cohorts']) == 18
assert not report['performance_claim'] and not report['complete_cartesian_input_output_coverage_claimed']
assert report['binary'] == manifest['cli']['path'] and report['binary_sha256'] == manifest['cli']['sha256']
assert report['build_manifest_sha256'] == identity(build_path)['sha256']
assert report['driver_sha256'] == driver_identity['sha256']
sys.path[:0] = [str(ROOT / 'scripts'), str(ROOT / 'benchmarks/traditional_analytics')]
from check_benchmark_artifact_completeness import validate_manifest
cohorts = []
for item in report['cohorts']:
    assert item['receipt']['returncode'] == 0 and not item['receipt']['guard_failures']
    assert item['independently_reopened']
    path = Path(item['report'])
    assert identity(path)['sha256'] == item['report_sha256']
    assert identity(item['stdout'])['sha256'] == item['stdout_sha256']
    stdout_path = Path(item['stdout'])
    stderr_path = stdout_path.with_name(stdout_path.name.replace('.stdout.json', '.stderr.txt'))
    assert identity(stderr_path)['sha256'] == item['stderr_sha256']
    blockers, observed = validate_manifest(path)
    assert not blockers, blockers
    assert len(observed['records']) == item['observed_records']
    assert sum(row['engine'] == 'shardloom' for row in observed['records']) == item['native_records']
    cohorts.append(dict(report=identity(path), records=len(observed['records']),
        native_records=item['native_records'], input_state=item['input_state'],
        inputs=item['formats'], output=item['output_format']))
assert acceptance.load() == manifest and acceptance.unchanged() == source
assert identity(driver) == driver_identity
assert identity(Path(__file__)) == wrapper_identity
acceptance.protocol()
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip() == working_tree
save(OUT / 'nullable-layout-modular-review-651.json', dict(status='passed',
    source=identity(acceptance.SOURCE), artifacts=identity(acceptance.MANIFEST),
    build_manifest=identity(build_path), report=identity(report_path), driver=driver_identity,
    wrapper=wrapper_identity, full43=identity(full43_path),
    receipt=identity(OUT / 'nullable-layout-modular-651.json'), cohorts=cohorts,
    records=1408, native_records=704, oracle_records=704, complete_results_reopened=True,
    scope='eight inputs with collect and CSV input to eight outputs, raw/prepared, 22 workflows',
    complete_cartesian_input_output_coverage_claimed=False, performance_claim=False))
print(json.dumps(dict(status='passed', cohorts=18, records=1408, native_records=704)), flush=True)
