"""Retain immutable I/O transport and source-only replay acceptance in the repo."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-docs-refresh/shardloom-local-repo')
ISOLATED = Path('/Users/dylan/LocalData/shardloom/local-io-portable-isolation-2026-11-03-r2')
DEST = ROOT / 'docs/benchmarks/evidence/native-local-io-portable-2026-11-03'
assert not DEST.exists()
result = json.loads((OUT / 'local-io-portable-replay-r3.json').read_text())
isolation = json.loads((ISOLATED / 'acceptance.json').read_text())
assert result['status'] == isolation['status'] == 'passed' and isolation['replay'] == result
assert isolation['replay_original_reads'] == isolation['replay_external_effect_attempts'] == 0
names = ('io779-local-io-portable-replay', 'io780-local-io-portable-replay',
         'io781-local-io-portable-replay', 'io782-local-io-replay-controls',
         'io783-local-io-isolated-replay', 'io784-local-io-isolated-replay')
files, observations = {}, []
for name in names:
    receipt = json.loads((OUT / (name + '.json')).read_text())
    log = (OUT / (name + '.log')).read_bytes()
    assert hashlib.sha256(log).hexdigest() == receipt['log_sha256']
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    for suffix in ('.json', '.log'):
        files[name + suffix] = (OUT / (name + suffix)).read_bytes()
    observations.append(dict(name=name, status=receipt['status'], returncode=receipt['returncode'],
                             command=receipt['command']))
assert [x['status'] for x in observations] == ['failed', 'failed', 'passed', 'passed', 'failed', 'passed']
files['replay.json'] = (OUT / 'local-io-portable-replay-r3.json').read_bytes()
files['isolation.json'] = (ISOLATED / 'acceptance.json').read_bytes()
for name in ('isolate_local_io_replay.py', 'record_local_io_replay.py'):
    files['helpers/' + name] = (OUT / 'tools' / name).read_bytes()
paths = list((ROOT / 'scripts').glob('*local_io*.py'))
paths += [ROOT / 'scripts' / name for name in ('native_workflow_protocol.py',
          'parquet_demand_completion_replay.py', 'query_timing_report.py', 'shared_performance_bundle.py')]
paths += list((ROOT / 'benchmarks/traditional_analytics/query_surface').glob('*.py'))
sources = {}
for path in sorted(set(paths)):
    data = path.read_bytes()
    name = str(path.relative_to(ROOT))
    sources[name] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    files['maintained-source/' + name] = data
shutil.copytree(OUT / 'portable-local-io-r1', DEST)
copied = {}
for path in sorted(DEST.rglob('*')):
    if path.is_file():
        relative = path.relative_to(DEST)
        data = path.read_bytes()
        assert data == (OUT / 'portable-local-io-r1' / relative).read_bytes()
        copied[str(relative)] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
archive_path = DEST.parent / 'native-local-io-replay-acceptance-2026-11-03.tar.xz'
assert not archive_path.exists()
with tarfile.open(archive_path, 'w:xz', preset=6) as archive:
    for name, data in sorted(files.items()):
        member = tarfile.TarInfo(name)
        member.size, member.mode, member.mtime = len(data), 0o644, 0
        archive.addfile(member, io.BytesIO(data))
with tarfile.open(archive_path, 'r:xz') as archive:
    members = archive.getmembers()
    assert len(members) == len(files)
    for member in members:
        assert member.isfile() and archive.extractfile(member).read() == files[member.name]
archive_bytes = archive_path.read_bytes()
acceptance = dict(schema_version='shardloom.local_io_portable_acceptance.v1', status='passed',
    replay=result, isolation={k: v for k, v in isolation.items() if k not in {'replay', 'source_files'}},
    controls=dict(tests=16, failures=0, errors=0, skipped=0), source_files=sources,
    observations=observations, collection_files=copied,
    acceptance_archive=dict(path=str(archive_path.relative_to(ROOT)), bytes=len(archive_bytes),
        sha256=hashlib.sha256(archive_bytes).hexdigest(), members=len(files),
        complete_member_readback=True),
    failed_attempts=[
        'io779: external identities carried descriptive metadata in addition to path/size/hash; verifier comparison corrected.',
        'io780: installed-package log paths are relative to their report directory; verifier lookup corrected.',
        'io783: PyArrow compute loaded lazily after original-path reads were denied; reader import moved before the guard.',
    ], new_engine_queries=0, publication_attempted=False)
(DEST / 'acceptance.json').write_text(json.dumps(acceptance, indent=2, allow_nan=False) + '\n')
print(json.dumps(dict(status='passed', observations=result['observations'],
    portable_files=len(copied), portable_bytes=sum(x['bytes'] for x in copied.values()),
    archive_members=len(files), archive_sha256=acceptance['acceptance_archive']['sha256']), indent=2))
