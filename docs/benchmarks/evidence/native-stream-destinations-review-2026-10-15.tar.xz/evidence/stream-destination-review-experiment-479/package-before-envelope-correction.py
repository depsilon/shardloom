"""Retain review adjudication, complete paired results and final test evidence."""
import hashlib
import json
import lzma
from pathlib import Path
import re
import subprocess
import tarfile

from freeze_native_release_298 import ROOT, OUT, sha, sources, save
from package_selection_acceptance_409 import Members, verify, sha_stream
from local_uat_storage import GIB, MIB, check_budgets

PREFIX = 'native-stream-destinations-review-2026-10-15'
LOCAL = OUT / 'stream-destination-review-packet-479'
DEST = ROOT / 'docs/benchmarks/evidence'
SOURCE = OUT / 'native-release-source-streamreview479accepted.json'


def bound(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def read(name):
    return json.loads((OUT / name).read_text())


def main():
    frozen = read(SOURCE.name)
    original = read('native-release-source-stream477.json')['source_sha256']
    current = frozen['source_sha256']
    assert sources() == current
    changed = sorted(name for name in set(original) | set(current) if original.get(name) != current.get(name))
    assert changed == ['shardloom-cli/tests/public_workflow_route.rs',
                       'shardloom-cli/tests/support/public_batch_writes.rs']
    checks = read('stream-destination-review-checks-479b.json')
    assert checks['status'] == 'passed' and checks['source_identity_preserved']
    assert len(checks['completed']) == 6
    counts = {}
    for entry in checks['completed']:
        assert bound(entry['receipt'])['sha256'] == entry['receipt_sha256']
        receipt = json.loads(Path(entry['receipt']).read_text())
        log = Path(entry['log'])
        assert sha(log) == entry['log_sha256'] == receipt['log_sha256']
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        if 'tests' in entry:
            groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', log.read_text())
            assert all(int(row[1]) == int(row[3]) == int(row[4]) == 0 for row in groups)
            total = sum(int(row[0]) for row in groups)
            assert total == entry['tests']['passed']
            counts[entry['stage']] = total
    assert counts == {'workspace-tests': 3219, 'native-tests': 4232}
    pair = read('stream-destination-review-paired-479.json')
    assert pair['status'] == 'passed' and len(pair['cohorts']) == 2
    paired_root = OUT / 'stream-destination-review-paired-479'
    values, envelopes = [], []
    for cohort in pair['cohorts']:
        assert len(cohort['cases']) == 16 and all(row['status'] == 'passed' for row in cohort['cases'])
        assert sum(row['outcome'] == 'rejected_existing_target' for row in cohort['cases']) == 8
        assert sum(row['outcome'] == 'created_absent_target' for row in cohort['cases']) == 8
        for row in cohort['cases']:
            assert bound(row['destination']['path']) == row['destination']
            if row['outcome'] == 'rejected_existing_target':
                assert row['unchanged_destination']
                assert row['producer_events'] == (['opened', 'ended', 'closed'] if cohort['cohort'] == 'prior' else [])
            else:
                assert row['complete_values_equal'] and row['producer_events'] == ['opened', 'ended', 'closed']
        for key in ('binary', 'manifest'):
            assert bound(cohort[key]['path']) == cohort[key]
    for path in sorted(paired_root.rglob('*-values.json')):
        value = json.loads(path.read_text())
        assert value['actual'] == value['expected'] and len(value['actual']) == 3
        values.append(bound(path))
    for path in sorted(paired_root.rglob('*-envelope.json')):
        value = json.loads(path.read_text())
        assert value['fallback']['attempted'] is value['fallback']['allowed'] is False
        fields = value.get('fields', []) + value.get('result', {}).get('fields', [])
        assert len(fields) == len({entry['key'] for entry in fields})
        if value['status'] == 'success':
            assert {entry['key']: entry['value'] for entry in fields}['public_workflow_external_engine_invoked'] == 'false'
        else:
            assert value['status'] == 'error'
            assert 'atomic generation-conditional replacement is unavailable for an existing destination' in json.dumps(value)
        envelopes.append(bound(path))
    assert len(values) == 16 and len(envelopes) == 60
    for name in ('stream-destination-review-policy-tests-479b', 'stream-destination-review-paired-run-479'):
        receipt = read(name + '.json')
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert sha(OUT / (name + '.log')) == receipt['log_sha256']
    for name in ('stream-destination-review-reproduction-479', 'stream-destination-review-focused-479',
                 'stream-destination-review-policy-tests-479'):
        receipt = read(name + '.json')
        assert receipt['status'] == 'failed' and receipt['returncode'] == 101
        assert receipt['process_group_drained'] and sha(OUT / (name + '.log')) == receipt['log_sha256']
    # The pre-PR and current native/binary writer publication owner is identical.
    prior = read('selected-views-467-source.json')['source_sha256']
    same_sinks = ['shardloom-vortex/src/local_primitive_native_sink.rs',
                  'shardloom-vortex/src/local_primitive_columnar_compat_sink.rs']
    assert all(prior[name] == original[name] == current[name] for name in same_sinks)
    members = Members()
    def add(path, prefix='evidence'):
        path = Path(path)
        root = ROOT if path.is_relative_to(ROOT) else OUT
        members.add(path, prefix + '/' + path.relative_to(root).as_posix(), prefix, root,
                    'review evidence, exact source, helper, or preserved failed experiment')
    for path in sorted(OUT.glob('stream-destination-review-*')):
        if path.is_file() and path.suffix in ('.json', '.log'):
            add(path)
    for directory in ('stream-destination-review-paired-479', 'stream-destination-review-experiment-479'):
        for path in sorted((OUT / directory).rglob('*')):
            if path.is_file():
                add(path)
    for name in ('verify_batch_publication_policy_479.py', 'run_stream_destination_review_checks_479.py',
                 'verify_stream_destination_review_checks_479.py', 'query-timing-manual-tests-inventory-462.json',
                 'verify_native_inventories_479.py', 'package_stream_destination_review_479.py',
                 'freeze_native_release_298.py', 'run_guarded.py', 'package_selection_acceptance_409.py',
                 'native-inventory-audit-479.json', 'native-batch-overwrite-inventory-479.json', 'native-set-streaming-inventory-478.json',
                 'native-release-source-stream477.json', 'selected-views-467-source.json',
                 'selected-view-native-artifacts-468.json', 'stream-destination-native-artifacts-477.json',
                 'stream-destination-hosted-478/review-comments-479.json'):
        add(OUT / name)
    for path in sorted(OUT.glob('native-release-source-streamreview479*.json')):
        add(path)
    for name in changed:
        add(ROOT / name, 'source-overlay')
    ordered = sorted(members.paths.values(), key=lambda item: item.name)
    raw_bytes = sum(item.size for item in ordered)
    assert raw_bytes < 64 * MIB
    storage = check_budgets(OUT, LOCAL, OUT / 'logs', min_free_bytes=12 * GIB,
        reserve_bytes=raw_bytes + 64 * MIB, max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    LOCAL.mkdir()
    archive_path = LOCAL / (PREFIX + '.tar.xz')
    with archive_path.open('xb') as stream:
        with tarfile.open(fileobj=stream, mode='w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
            for item in ordered:
                verify(item.path, item.digest, item.size)
                info = tarfile.TarInfo(item.name)
                info.size, info.mode, info.mtime = item.size, 0o644, 0
                with item.path.open('rb') as source:
                    archive.addfile(info, source)
    seen = set()
    with tarfile.open(archive_path, mode='r|xz') as archive:
        for entry in archive:
            assert entry.isfile() and entry.name not in seen and entry.name in members.names
            item = members.paths[members.names[entry.name]]
            with archive.extractfile(entry) as stream:
                assert sha_stream(stream) == (item.size, item.digest)
            verify(item.path, item.digest, item.size)
            seen.add(entry.name)
    assert seen == set(members.names) and sources() == current
    adjudication = dict(review_comment_id=4286139155, outcome='not_reproduced_review_premise_disproved',
        reason='All eight underlying writers reject existing destinations. The preflight moves that denial before resident input demand; it removes no supported replacement.',
        original_runtime_restored_byte_identical=True, changed_source_files=changed,
        pair_cases=32, compared_value_files=16, compared_rows=48, inspected_envelopes=60,
        new_rust_tests=3, new_rust_scenarios=50, workspace_tests=3219, native_tests=4232,
        native_manual_platform_exclusions=29, final_required_gates=6,
        no_new_release_build_required='Only CLI integration tests changed; every original runtime/package source hash is unchanged.',
        prior_acceptance_retained='84 direct, 777 public and Full43 remain bound to their original immutable artifacts and sources; these runs were not relabeled as new runs.',
        preserved_failures=['Initial positive-overwrite test reproduced rejection.',
            'Narrowed-preflight experiment still failed at the unchanged OwnedOutput replacement restriction; runtime experiment was reverted.',
            'First policy test passed all writes but its reopen omitted bounded=true; corrected test passes.',
            'All six broad commands passed; their final verifier used the old manual-exclusion inventory. Revalidated the same complete logs against the existing current inventory and all 29 literal declarations without rerunning native commands.'])
    manifest = dict(status='passed', source_manifest=bound(SOURCE), storage=storage,
        archive=bound(archive_path), member_count=len(ordered), raw_bytes=raw_bytes,
        members=[dict(path=str(item.path), archive_path=item.name, bytes=item.size, sha256=item.digest) for item in ordered],
        adjudication=adjudication, source_identity_preserved=True, all_members_reopened=True,
        values=values, envelopes=envelopes, paired_cli_identities=[row['binary'] for row in pair['cohorts']])
    raw_manifest = (json.dumps(manifest, indent=2) + '\n').encode()
    packed = lzma.compress(raw_manifest)
    assert lzma.decompress(packed) == raw_manifest
    manifest_path = LOCAL / (PREFIX + '.manifest.json.xz')
    with manifest_path.open('xb') as stream:
        stream.write(packed)
    index = dict(schema_version='shardloom.stream_destination_review.v1', status='passed_local',
        reviewed_head=frozen['head'], adjudication=adjudication, member_count=len(ordered), raw_bytes=raw_bytes,
        archive=dict(file=archive_path.name, bytes=archive_path.stat().st_size, sha256=sha(archive_path)),
        manifest=dict(file=manifest_path.name, bytes=manifest_path.stat().st_size, sha256=sha(manifest_path),
                      raw_sha256=hashlib.sha256(raw_manifest).hexdigest()), all_members_reopened=True,
        hosted_acceptance_pending=True, original_acceptance_packet_unchanged=True)
    for path in (archive_path, manifest_path):
        with (DEST / path.name).open('xb') as stream:
            stream.write(path.read_bytes())
        assert sha(DEST / path.name) == sha(path)
    save(DEST / (PREFIX + '.json'), index)
    save(LOCAL / 'verification.json', dict(status='passed', members=len(ordered),
         archive=bound(archive_path), manifest=bound(manifest_path), index=bound(DEST / (PREFIX + '.json'))))
    print(json.dumps(dict(status='passed', members=len(ordered), raw_bytes=raw_bytes,
                         archive_bytes=archive_path.stat().st_size)))


if __name__ == '__main__':
    main()
