"""Primary verification of the two bounded source inventories."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
HEAD = 'c7726047b6d9d01f4fed878cb5c16bb8203d0830'
SPECS = [
    ('native-set-streaming-inventory-478.json', 'docs_consulted', 'literal_source_evidence', 8, 30),
    ('native-batch-overwrite-inventory-479.json', 'source_identities', 'literal_excerpts', 23, 40),
]
results = []
for filename, identity_key, excerpt_key, identities, excerpts in SPECS:
    path = OUT / filename
    inventory = json.loads(path.read_text())
    assert inventory['status'] == 'COMPLETE' and inventory['head'] == HEAD
    assert len(inventory[identity_key]) == identities and len(inventory[excerpt_key]) == excerpts
    checked_paths = set()
    for item in inventory[identity_key] + inventory[excerpt_key]:
        source = Path(item['path'])
        relative = str(source.relative_to(ROOT))
        raw = subprocess.check_output(['git', 'show', HEAD + ':' + relative], cwd=ROOT)
        assert hashlib.sha256(raw).hexdigest() == item['sha256'], relative
        checked_paths.add(relative)
        if 'excerpt' in item:
            expected = '\n'.join(raw.decode().splitlines()[item['line_start'] - 1:item['line_end']])
            assert expected == item['excerpt'], (relative, item['line_start'])
    results.append(dict(inventory=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                        identities=identities, excerpts=excerpts, unique_paths=len(checked_paths)))
result = dict(status='passed', head=HEAD, inventories=results,
              scope='Complete declared source identities and literal excerpts. Search coverage and conclusions remain subject to primary source review.')
destination = OUT / 'native-inventory-audit-479.json'
with destination.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result))
