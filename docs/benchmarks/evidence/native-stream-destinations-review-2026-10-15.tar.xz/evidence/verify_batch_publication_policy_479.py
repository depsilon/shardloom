"""Compare prior/current frozen CLIs against the review's overwrite premise."""
import json
from pathlib import Path

from freeze_native_release_298 import ROOT, OUT, sources, sha, save
from run_native_streaming_input_uat import Harness
from native_workflow_outputs import LOCAL_FORMATS, verify_output
from shardloom.errors import ShardLoomCommandError

DEST = OUT / 'stream-destination-review-paired-479'
FROZEN = OUT / 'native-release-source-streamreview479accepted.json'
EXPECTED = [{'id': 1, 'label': '港'}, {'id': None, 'label': None}, {'id': -3, 'label': 'next'}]
COHORTS = [
    ('prior', OUT / 'selected-view-native-artifacts-468.json', 1),
    ('current', OUT / 'stream-destination-native-artifacts-477.json', 0),
]


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def main():
    frozen = json.loads(FROZEN.read_text())
    assert sources() == frozen['source_sha256']
    assert not DEST.exists()
    DEST.mkdir()
    results = []
    status = 'failed'
    try:
        for label, manifest_path, rejected_opens in COHORTS:
            manifest = json.loads(manifest_path.read_text())
            assert manifest['status'] == 'passed'
            binary = Path(manifest['cli']['path'])
            assert sha(binary) == manifest['cli']['sha256']
            harness = Harness(binary, DEST / label, 60)
            harness.guard()
            harness.logs.mkdir(parents=True)
            harness.output.mkdir()
            try:
                for existing in (True, False):
                    for format in LOCAL_FORMATS:
                        name = f'{label}-existing-{existing}-{format}'

                        def case(name=name, format=format, existing=existing):
                            events = []

                            def producer():
                                events.append('opened')
                                try:
                                    yield EXPECTED[:2]
                                    yield EXPECTED[2:]
                                    events.append('ended')
                                finally:
                                    events.append('closed')

                            frame = harness.context.from_batches(
                                producer, schema={'id': 'int64', 'label': 'utf8'}, streaming=False)
                            path = harness.output / f'{name}.{format}'
                            original = b'preserve the original destination'
                            if existing:
                                path.write_bytes(original)
                            before = set(harness.output.iterdir())
                            try:
                                report = frame.write(path, output_format=format, allow_overwrite=True,
                                                     memory_bytes=32 << 20, max_parallelism=1, check=True)
                            except ShardLoomCommandError as error:
                                assert existing, error.envelope.raw
                                harness.envelope(name, error.envelope, success=False)
                                raw = json.dumps(error.envelope.raw)
                                assert 'atomic generation-conditional replacement is unavailable for an existing destination' in raw
                                assert path.read_bytes() == original
                                assert set(harness.output.iterdir()) == before
                                assert events == (['opened', 'ended', 'closed'] if rejected_opens else [])
                                result = dict(outcome='rejected_existing_target', producer_events=events,
                                              destination=identity(path), unchanged_destination=True)
                            else:
                                assert not existing, report.envelope.raw
                                harness.envelope(name, report.envelope)
                                assert report.envelope.field_int('output_row_count') == len(EXPECTED)
                                assert events == ['opened', 'ended', 'closed']

                                def accepted(check_name, checked):
                                    harness.envelope(check_name, checked.envelope)
                                    return checked.envelope

                                verify_output(harness.context, path, format, EXPECTED, ('id', 'label'),
                                    name=name, accepted=accepted,
                                    complete=lambda check_name, actual, expected, _: harness.values(check_name, actual, expected))
                                result = dict(outcome='created_absent_target', producer_events=events,
                                              destination=identity(path), complete_values_equal=True)
                            assert not list(harness.output.glob('.shardloom-fanout-*'))
                            return result
                        harness.case(name, case)
                assert len(harness.results) == 16 and all(row['status'] == 'passed' for row in harness.results)
                results.append(dict(cohort=label, manifest=identity(manifest_path), binary=identity(binary),
                                    cases=harness.results))
            finally:
                harness.client.close()
                harness.json(harness.root / 'summary.json', dict(cases=harness.results,
                             all_passed=len(harness.results) == 16 and all(row['status'] == 'passed' for row in harness.results)))
        assert sources() == frozen['source_sha256']
        status = 'passed'
    finally:
        save(OUT / 'stream-destination-review-paired-479.json', dict(status=status,
             frozen=identity(FROZEN), helper=identity(__file__), cohorts=results,
             claim='Both frozen CLIs reject existing resident single-output destinations for all eight formats even with overwrite permission. The current preflight avoids input consumption.',
             runtime_source_changed=False, performance_claim=False))
    print(json.dumps(dict(status=status, cohorts=len(results), cases=sum(len(row['cases']) for row in results))))


if __name__ == '__main__':
    main()
