"""Accept completed gates after correcting a stale manual-test inventory reference."""
import json
from pathlib import Path
import re

from freeze_native_release_298 import ROOT, OUT, sha, sources, save


def main():
    source_path = OUT / 'native-release-source-streamreview479accepted.json'
    source = json.loads(source_path.read_text())
    assert sources() == source['source_sha256']
    failed_path = OUT / 'stream-destination-review-checks-479.json'
    original = json.loads(failed_path.read_text())
    assert original['status'] == 'failed' and original['source_identity_preserved']
    assert original['failure'] == 'AssertionError: '
    assert original['protocol']['source_manifest_sha256'] == sha(source_path)
    inventory_path = OUT / 'query-timing-manual-tests-inventory-462.json'
    inventory = json.loads(inventory_path.read_text())
    assert inventory['status'] == 'passed' and inventory['declarations_identical']
    assert len(inventory['tests']) == 29
    for row in inventory['tests']:
        path = ROOT / row['source']
        assert sha(path) == row['source_sha256'] == source['source_sha256'][row['source']]
        lines = path.read_text().splitlines()
        declaration = row['declaration']
        assert sum(lines[i:i+len(declaration)] == declaration for i in range(len(lines))) == 1
        assert 'ignore = ' in '\n'.join(declaration) and row['reason'] in '\n'.join(declaration)
    records = []
    for label, _, expected in original['protocol']['checks']:
        path = OUT / ('stream-destination-review-' + label + '-479.json')
        receipt = json.loads(path.read_text())
        log = path.with_suffix('.log')
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['command'] == expected
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup']
        assert receipt['head'] == source['head'] and sha(log) == receipt['log_sha256']
        record = dict(stage=label, receipt=str(path), receipt_sha256=sha(path),
            log=str(log), log_sha256=sha(log), seconds=receipt['seconds'])
        if label.endswith('tests'):
            raw = log.read_text()
            groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', raw)
            assert groups and all(int(row[1]) == int(row[3]) == int(row[4]) == 0 for row in groups)
            ignored = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', raw, re.M)
            assert sum(int(row[2]) for row in groups) == len(ignored)
            passed = sum(int(row[0]) for row in groups)
            if label == 'native-tests':
                assert passed == 4232 and len(ignored) == 29
                assert sorted(ignored) == sorted((r['test'], r['reason']) for r in inventory['tests'])
                for name in (
                    'completion_input_all_writers_preserve_values_and_require_source_end',
                    'completion_input_fanout_executes_once_for_all_writers_and_typed_empty_output',
                    'completion_input_fanout_failures_leave_no_published_prefix_or_owners',
                    'completion_input_fanout_target_admission_and_cancellation_precede_demand',
                    'completion_input_fanout_pressure_denies_resident_and_replays_native_runs_under_same_grant',
                    'completion_input_fanout_spill_faults_do_not_publish_and_preserve_unknown_files',
                    'streaming_window_compatibility_writers_require_complete_input_and_refund_owners',
                    'resident_batch_writes_create_new_destinations_with_either_overwrite_setting',
                    'single_batch_write_rejections_preserve_existing_files_before_input_demand',
                    'batch_fanout_keeps_existing_target_rejection_for_resident_and_streaming_input',
                ):
                    assert re.search(r'^test .*::' + name + r' \.\.\. ok$', raw, re.M), name
            else:
                assert passed == 3219 and not ignored
            record['tests'] = dict(passed=passed, failed=0, ignored=len(ignored), groups=len(groups),
                ignored_declarations=ignored)
        records.append(record)
    assert len(records) == 6 and sources() == source['source_sha256']
    target = OUT / 'stream-destination-review-checks-479b.json'
    save(target, dict(status='passed', failure=None, protocol=original['protocol'], completed=records,
        source_files=len(source['source_sha256']), source_identity_preserved=True,
        original_failed_postcheck=dict(path=str(failed_path), sha256=sha(failed_path)),
        current_manual_inventory=dict(path=str(inventory_path), sha256=sha(inventory_path)),
        verification_helper=dict(path=str(Path(__file__).resolve()), sha256=sha(__file__)),
        correction='Use the already-verified current inventory. The runner referenced its predecessor, whose local_primitives.rs hash predates query timing. All 29 literal exclusion declarations and all commands remain unchanged.',
        native_commands_rerun=False))
    print(json.dumps(dict(status='passed', workspace_tests=3219, native_tests=4232,
        manual_exclusions=29, source_files=len(source['source_sha256']))))


if __name__ == '__main__':
    main()
