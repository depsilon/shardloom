"""Retain the reporting correction without rewriting accepted runtime evidence."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import time

from freeze_native_release_298 import ROOT, OUT, sha, sources

BASE = 'fc734eeba45db9fd6bc79c82eadce9030664bdb4'
STEM = 'native-query-timing-scoring-2026-10-15'
EVIDENCE = ROOT / 'docs/benchmarks/evidence'
DEST = OUT / 'timing-scoring-validation-465'
CHANGED = {
    'scripts/run_clickbench_query_uat.py', 'scripts/run_clickbench_paired_query_uat.py',
    'scripts/test_clickbench_query_uat.py', 'scripts/test_clickbench_paired_query_uat.py',
}


def main():
    frozen_path = OUT / 'native-release-source-timing460.json'
    frozen = json.loads(frozen_path.read_text())['source_sha256']
    current = sources()
    assert current.keys() == frozen.keys()
    assert {p for p in frozen if frozen[p] != current[p]} == CHANGED
    artifact_path = OUT / 'query-timing-native-artifacts-461.json'
    artifacts = json.loads(artifact_path.read_text())
    for kind in ('cli', 'binding'):
        assert sha(artifacts[kind]['path']) == artifacts[kind]['sha256']
    unchanged_evidence = []
    for prefix in ('native-query-timing-uat-2026-10-15.', 'native-query-timing-acceptance-2026-10-15.'):
        for path in sorted(EVIDENCE.glob(prefix + '*')):
            original = subprocess.check_output(['git', 'show', f'{BASE}:{path.relative_to(ROOT)}'], cwd=ROOT)
            assert original == path.read_bytes()
            unchanged_evidence.append(dict(path=str(path.relative_to(ROOT)), bytes=len(original), sha256=sha(path)))
    assert len(unchanged_evidence) == 10

    raw = {}
    for name in sorted(CHANGED):
        raw['source/' + name] = (ROOT / name).read_bytes()
        raw['before/' + name] = subprocess.check_output(['git', 'show', f'{BASE}:{name}'], cwd=ROOT)
    for name in ('timing-scoring-red-465', 'timing-scoring-green-465', 'timing-scoring-green-465b'):
        record = json.loads((OUT / f'{name}.json').read_text())
        assert record['process_group_drained']
        assert record['log_sha256'] == sha(OUT / f'{name}.log')
        assert record['status'] == ('passed' if name.endswith('465b') else 'failed')
        for suffix in ('.json', '.log'):
            raw['checks/' + name + suffix] = (OUT / (name + suffix)).read_bytes()
    assert b'Ran 46 tests' in raw['checks/timing-scoring-green-465b.log']
    assert b'\nOK\n' in raw['checks/timing-scoring-green-465b.log']
    for path in (frozen_path, artifact_path, Path(__file__), OUT / 'run_guarded.py',
                 OUT / 'timing-score-consumers-465.json'):
        raw['provenance/' + path.name] = path.read_bytes()

    inventory = json.loads(raw['provenance/timing-score-consumers-465.json'])
    inventory_checks = 0
    def inventory_source(path, expected):
        choices = [raw.get('before/' + path), (ROOT / path).read_bytes()]
        return next(data for data in choices if data is not None and hashlib.sha256(data).hexdigest() == expected)
    for section in inventory.values():
        if isinstance(section, list):
            for item in section:
                if isinstance(item, dict) and all(k in item for k in ('path', 'line_start', 'line_end', 'excerpt', 'sha256')):
                    lines = inventory_source(item['path'], item['sha256']).decode().splitlines()
                    assert '\n'.join(lines[item['line_start']-1:item['line_end']]) == item['excerpt']
                    inventory_checks += 1
        elif isinstance(section, dict):
            for path, item in section.items():
                if isinstance(item, dict) and 'sha256' in item and (ROOT / path).is_file():
                    lines = inventory_source(path, item['sha256']).decode().splitlines()
                    for match in item.get('matches', []):
                        assert lines[match['line']-1] == match['excerpt']
                        inventory_checks += 1
    assert inventory_checks == 297

    archive_path = EVIDENCE / (STEM + '.tar.xz')
    assert not archive_path.exists()
    with archive_path.open('xb') as output, tarfile.open(fileobj=output, mode='w:xz') as archive:
        for name, data in sorted(raw.items()):
            member = tarfile.TarInfo(name)
            member.size = len(data)
            archive.addfile(member, io.BytesIO(data))
    with tarfile.open(archive_path, 'r:xz') as archive:
        assert archive.getnames() == sorted(raw)
        for member in archive:
            assert archive.extractfile(member).read() == raw[member.name]

    index_path = EVIDENCE / (STEM + '.json')
    assert not index_path.exists()
    index = dict(
        schema_version='shardloom.native_query_timing_scoring_followup.v1',
        status='passed', original_pr_head=BASE,
        review='https://github.com/depsilon/shardloom/pull/1555#discussion_r4281877356',
        primary_metric='engine_execution_seconds', secondary_metric='process_wall_seconds',
        summary_schemas=['shardloom.clickbench.public_result_regression.v2',
                         'shardloom.clickbench.counterbalanced_pairs.v2'],
        missing_clock_policy='complete results may pass; missing engine samples leave engine scores unavailable; process time is never substituted',
        tests=dict(passed=46, skipped=0,
                   command=json.loads(raw['checks/timing-scoring-green-465b.json'])['command'],
                   regression_reproduced=True,
                   initial_followup_failure='All 41 runner tests passed; the third module name was incorrect. The corrected 46-test command passes.'),
        source_comparison=dict(frozen_files=len(frozen), unchanged_files=len(frozen)-len(CHANGED),
                               changed=[dict(path=p, before_sha256=frozen[p], after_sha256=current[p]) for p in sorted(CHANGED)],
                               native_execution_sources_unchanged=True),
        accepted_binaries={kind: {key: artifacts[kind][key] for key in ('path', 'sha256', 'bytes')} for kind in ('cli', 'binding')},
        native_workloads_rerun=False,
        native_validation='Existing source-bound Rust, vendor, direct binding, public workflows and full UAT retained because native sources/binaries are identical.',
        original_evidence_unchanged=unchanged_evidence,
        consumer_inventory_verified_excerpts=inventory_checks,
        archive=dict(path=archive_path.name, bytes=archive_path.stat().st_size, sha256=sha(archive_path),
                     members=[dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in sorted(raw.items())]),
    )
    index_path.write_text(json.dumps(index, indent=2) + '\n')

    DEST.mkdir()
    python = lambda *args: [sys.executable, '-B', *map(str, args)]
    node = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
    commands = [
        ('public-status', python('scripts/check_public_status_docs.py', '--output', DEST / 'public-status.json')),
        ('website-links', python('-m', 'unittest', 'discover', '-s', 'scripts', '-p', 'test_website_links.py')),
        ('website-readiness', python('scripts/check_website_readiness.py', '--output', DEST / 'website-readiness.json')),
        ('static-assets', [node, 'scripts/validate_static_assets.cjs']),
        ('user-surface', python('scripts/check_user_surface_reference.py')),
        ('use-case-backlinks', python('scripts/check_use_case_backlinks.py')),
        ('contribution-governance', python('scripts/check_contribution_governance.py', '--output', DEST / 'contribution-governance.json')),
        ('ci-gate-matrix', python('scripts/check_ci_gate_matrix.py', '--output', DEST / 'ci-gate-matrix.json')),
        ('diff-check', ['git', 'diff', '--check']),
    ]
    checks = []
    for name, command in commands:
        log = DEST / (name + '.log')
        started = time.monotonic()
        with log.open('xb') as output:
            result = subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT, timeout=120)
        checks.append(dict(name=name, command=command, returncode=result.returncode,
                           seconds=time.monotonic()-started, log=str(log), log_sha256=sha(log),
                           output=log.read_text()))
        print(json.dumps({key: checks[-1][key] for key in ('name', 'returncode', 'seconds')}), flush=True)
        result.check_returncode()
    links = []
    for name in subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT, text=True).splitlines():
        path = ROOT / name
        if path.suffix != '.md':
            continue
        for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^\s)]+)\)', path.read_text()):
            if target.startswith(('https:', 'http:', 'mailto:', '#')):
                continue
            assert (path.parent / target.split('#', 1)[0]).resolve().exists(), (name, target)
            links.append(dict(document=name, target=target))
    assert sources() == current
    index['documentation_validation'] = dict(checks=checks, verified_local_links=links)
    index_path.write_text(json.dumps(index, indent=2) + '\n')
    print(json.dumps(dict(status='passed', tests=46, source_files=len(frozen), unchanged_files=len(frozen)-len(CHANGED),
                         archive_members=len(raw), archive_sha256=sha(archive_path), checks=len(checks), links=len(links))), flush=True)


if __name__ == '__main__':
    main()
