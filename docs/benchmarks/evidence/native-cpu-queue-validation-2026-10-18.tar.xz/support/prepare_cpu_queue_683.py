"""Prepare the six-package queue update only after PR 1575 is merged."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
D=O/'cpu-queue-prepared-683'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
pr=json.loads(subprocess.check_output(['/opt/homebrew/bin/gh','api','repos/depsilon/shardloom/pulls/1575']))
assert len(sys.argv)==2 and re.fullmatch(r'[a-f0-9]{40}',sys.argv[1])
assert pr['merged'] and pr['head']['sha']==sys.argv[1]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head==pr['merge_commit_sha']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R).strip()
assert not D.exists();D.mkdir()
manifest=[]
def put(rel,text):
 p=R/rel;q=D/rel;q.parent.mkdir(parents=True,exist_ok=True)
 q.write_text(text)
 manifest.append(dict(path=rel,original_sha256=sha(p) if p.exists() else None,prepared_sha256=sha(q),bytes=q.stat().st_size))
def replace_once(text,old,new):
 assert text.count(old)==1,old
 return text.replace(old,new)

brief=Path('/Users/dylan/.codex/attachments/3bddcbd0-bcf1-4a9d-a568-9f2044c56ca1/Pasted text.txt')
intake='native-cpu-investigations-2026-10-18'
original=json.loads((R/'docs/architecture/native-roadmap-reconciliation-2026-10-18.json').read_text())
new_steps=[
 dict(id='PERF-03.codec_preparation',parent='PERF-03',kind='conditional',package='B',label='Conditional investigation: measure repeated codec setup, then reuse immutable preparation or exclusively leased mutable workspaces through the existing shared owner. Separate recipe identity from data-derived generation identity; include reset, concurrency, reclaim, first-use/later-use costs and portable fresh-process decoding. Follow [CPU package B](native-cpu-investigations-2026-10-18.md#b--reusable-codec-preparation); cross-operation admission belongs with PERF-02.physical_cache.'),
 dict(id='PERF-10.compact_selections',parent='PERF-10',kind='conditional',package='A',label='Conditional investigation: find a production selection/descriptor expansion cost, then preserve compact membership or ordered-gather representations through real count and projection consumers. Preserve duplicate/order semantics, checked wide global positions, sliced bases, validity and retained owners; charge construction/conversion/iteration and complete-operation cost. Follow [CPU package A](native-cpu-investigations-2026-10-18.md#a--compact-selections-and-execution-descriptors).'),
 dict(id='PERF-10.predicate_exclusion',parent='PERF-10',kind='conditional',package='D',label='Conditional investigation: reuse exact whole-region evidence that a fully identified predicate has no TRUE result across related operations. Bind complete coverage, immutable region/source, expression/type/NULL/collation/timezone/deletion/access semantics; reject partial/cancelled/failed observations and unsafe negation. Measure construction, use and invalidation separately from first-use summaries under [CPU package D](native-cpu-investigations-2026-10-18.md#d--first-use-summaries-and-exact-predicate-exclusion-reuse).'),
 dict(id='PERF-09.structural_payload',parent='PERF-09',kind='conditional',package='C',label='Conditional investigation: test a small deterministic reversible representation for original payload structure, with literal residuals/exceptions and exact validity. Preserve logical types and bytes, useful native consumers and producer-close/move/fresh-process-reopen/write/reopen behavior; include complete artifact and workflow costs. Follow [CPU package C](native-cpu-investigations-2026-10-18.md#c--reversible-structural-payload-encoding), distinct from derived columns and rejected codec-profile sweeps.'),
]
extensions={
 'PERF-06.membership':' Apply [CPU package E](native-cpu-investigations-2026-10-18.md#e--partition-major-external-memory-state): partition-major finalization/release, full ordinals and multiplicity, original-position masks, exact population/sampling semantics and skew progress through native runs. Capability completion is independent of a Full43 speed threshold.',
 'PERF-07.publication':' Apply [CPU package F](native-cpu-investigations-2026-10-18.md#f--changed-generation-reuse-and-safe-publication): real writer coordination and one authoritative managed-generation transition, stable readers, ambiguous-commit retry, separate visibility/durability and reader-safe cleanup. Safe replacement remains required if reuse is dropped.',
 'PERF-10.summaries':' Apply [CPU package D](native-cpu-investigations-2026-10-18.md#d--first-use-summaries-and-exact-predicate-exclusion-reuse): earn creation/storage/read cost on first use and describe the actual transformed output; recurring exclusion facts have a separate conditional step.',
 'PERF-02.changed_source':' Apply [CPU package F](native-cpu-investigations-2026-10-18.md#f--changed-generation-reuse-and-safe-publication): trustworthy immutable file/region identity, schema/transform/recipe/dictionary/deletion compatibility and complete refresh-versus-rebuild validation/copy/metadata costs; path/length/mtime alone are insufficient.',
}
packages=[
 dict(id='A',title='Compact selections and execution descriptors',disposition='new_conditional_investigation',steps=['PERF-10.compact_selections'],related=['PERF-07.remaining_arrays','PERF-03.providers']),
 dict(id='B',title='Reusable codec preparation',disposition='new_conditional_investigation',steps=['PERF-03.codec_preparation'],related=['PERF-02.physical_cache','PERF-03.providers']),
 dict(id='C',title='Reversible structural payload encoding',disposition='new_conditional_investigation',steps=['PERF-09.structural_payload'],related=['PERF-08.duplication','PERF-09.lifecycle']),
 dict(id='D',title='Better summaries and exact predicate-exclusion reuse',disposition='existing_required_summaries_plus_new_conditional_exclusion',steps=['PERF-10.summaries','PERF-10.metadata_consumers','PERF-10.predicate_exclusion'],related=[]),
 dict(id='E',title='Partition-major external-memory state',disposition='extend_existing_required_capability',steps=['PERF-06.membership','PERF-06.recovery','PERF-06.strategy'],related=[]),
 dict(id='F',title='Changed-generation preparation reuse and safe publication',disposition='extend_existing_conditional_reuse_and_required_publication',steps=['PERF-02.changed_source','PERF-07.publication','PERF-09.lifecycle'],related=[]),
]
plan=(R/'docs/architecture/phased-execution-plan.md').read_text()
old_order=plan.split('Current autonomous execution order:\n\n',1)[1].split('\n\nThe current implementation',1)[0]
new_order='''1. The nullable-layout integration, cleanup, ship/drop readiness audit and fresh UAT are complete in the [October 18 packet](../benchmarks/native-roadmap-fresh-uat-2026-10-18.md). PR #1575 integrates the reconciled queue. Keep the next version bump held for a separate maintainer decision.
2. Begin the [six-package CPU intake](native-cpu-investigations-2026-10-18.md) with a short production-cost assessment of compact selections/descriptors (A, PERF-10) and reusable codec preparation (B, PERF-03). Select the stronger actual signal before implementing a candidate; no timing or benefit is assumed by queue intake.
3. Continue required breadth through the existing owners: remaining PERF-03 resources, PERF-06 membership/population pressure and recovery, PERF-07 generation-conditional publication, and PERF-02/10/11 source/type/operator compositions. E and F extend these owners; required capabilities do not depend on a Full43 speed gain. PERF-01 attribution and PERF-12 acceptance accompany each coherent unit.
4. Treat original-payload structural encoding (C) and first-use summaries/exact exclusion (D) as independent scoped work with their actual provider/resource prerequisites. Extend PERF-04 reductions within accepted jobs when justified; new region/topology work first passes PERF-03 admission. None of A–F requires all the others to finish first.
5. Preserve recorded drops and paused large format/text experiments. The twelve named investigations retain distinct prerequisites and frozen gates; no unchanged sweep or unimplemented candidate is waiting only for a final timing run. C investigates a different original-payload mechanism rather than repeating rejected codec profiles.
6. Queue native encoded transport after the current optimization/breadth contract. Continuous, distributed and shared-service outcomes retain the roadmap dependencies below.'''
plan=replace_once(plan,old_order,new_order)
old_counts='Ten stale unchecked rows are completed; unresolved scope remains explicit in 54 current substeps: 37 required and 17 conditional, including the eight previously prose-only investigations. The completed pre-bump packet is in the ledger. These are obligations, not a forecast of PR count.'
new_counts='Ten stale unchecked rows are completed. That immutable reconciliation contains 54 substeps; the subsequent [CPU intake](native-cpu-investigations-2026-10-18.md) adds four conditional steps and extends existing scope. The current queue has 58 substeps under the same 14 owners: 37 required and 21 conditional, including twelve named investigations. The completed pre-bump packet is in the ledger. These are obligations, not a forecast of PR count.'
plan=replace_once(plan,old_counts,new_counts)
for step_id,extra in extensions.items():
 pattern=r'^(    - \[ \] `'+re.escape(step_id)+r'` .*)$'
 assert len(re.findall(pattern,plan,re.M))==1
 plan=re.sub(pattern,lambda m:m[1]+extra,plan,flags=re.M)
for step in new_steps:
 start=plan.index('- [ ] `'+step['parent']+'`')
 end=plan.index('  - Next outcome:',start)
 plan=plan[:end]+'    - [ ] `'+step['id']+'` **Conditional.** '+step['label']+'\n'+plan[end:]
old_named='The eight conditional investigations are explicit above: rematerialization, multiway joins, nested identities, spill-merge costs, learned indexes, physical-state cache admission, byte-credit output windows and changed-source preparation reuse. Their prerequisites and original experiment contracts remain unchanged. They are not eight unfinished timed runs.'
new_named='The twelve named investigations are explicit above: the original rematerialization, multiway joins, nested identities, spill-merge costs, learned indexes, physical-state cache admission, byte-credit output windows and changed-source reuse, plus compact selections/descriptors, reusable codec preparation, reversible structural payloads and exact predicate-exclusion reuse. Their prerequisites and original experiment contracts remain intact. The six CPU packages also extend required first-use summaries, external-memory membership and safe publication; they do not add duplicate parent projects or imply twelve unfinished timing runs.'
plan=replace_once(plan,old_named,new_named)
put('docs/architecture/phased-execution-plan.md',plan)
put('docs/architecture/'+intake+'.md',(O/'native-cpu-investigations-2026-10-18.draft.md').read_text())
ids=re.findall(r'^- \[ \] `([^`]+)`',plan,re.M)
steps=re.findall(r'^    - \[ \] `([^`]+)` (.*)$',plan,re.M)
assert ids==[x['id'] for x in original['parents']] and len(steps)==58
assert sum(text.startswith('**Conditional.** ') for _,text in steps)==21
record=dict(schema_version='shardloom.native_cpu_investigation_intake.v1',status='queued_not_implemented',
 date='2026-10-18',basis='Supplied six-package text brief; no inaccessible linked sandbox document is inferred.',
 source_brief_sha256=sha(brief),base_commit=head,preceding_pr='https://github.com/depsilon/shardloom/pull/1575',
 predecessor_reconciliation=dict(file='native-roadmap-reconciliation-2026-10-18.json',sha256=sha(R/'docs/architecture/native-roadmap-reconciliation-2026-10-18.json'),parents=14,steps=54,required=37,conditional=17),
 current_counts=dict(parents=14,steps=58,required=37,conditional=21,named_investigations=12),
 packages=packages,new_steps=new_steps,extended_step_suffixes=extensions,
 new_parent_ids=[],preserved_parent_ids=ids,preserved_step_ids=[x['id'] for x in original['steps']],
 version_bump='held',runtime_implemented=False,benchmark_run=False,performance_claim_allowed=False,
 execution_sequence='Short A/B production-cost assessment, then strongest actual opportunity; actual dependencies only. E and safe publication in F remain required capability work.',
 prior_drops_preserved=True,all_cg_1_through_23_preserved=True)
put('docs/architecture/'+intake+'.json',json.dumps(record,indent=2)+'\n')
rel='docs/architecture/native-local-completion-scope-2026-10-07.md';s=(R/rel).read_text()
old='The [October 18 reconciliation](native-roadmap-reconciliation-2026-10-18.md) maps completed portions and remaining obligations into 14 canonical parents and 54 active substeps. It records five remaining breadth areas and eight conditional investigations; these overlap the checklist, rather than adding separate tasks. The historical assessments and original experiment contracts below remain intact.'
new='The [October 18 reconciliation](native-roadmap-reconciliation-2026-10-18.md) records a 14-owner, 54-step snapshot. The subsequent [CPU investigation intake](native-cpu-investigations-2026-10-18.md) adds four conditional investigations and extends existing summary, membership and publication obligations under those same owners. The [phase plan](phased-execution-plan.md) owns current counts and ordering; historical assessments and experiment contracts below remain intact.'
s=replace_once(s,old,new)
s=replace_once(s,'## Eight investigations, with current evidence prerequisites\n','## Eight investigations, with current evidence prerequisites\n\nThis dated section preserves the original eight investigations. The [October 18 CPU intake](native-cpu-investigations-2026-10-18.md) records four additions and the extensions to existing owners; neither list is a second execution queue.\n')
put(rel,s)
rel='docs/release/v1-inclusion-scope-matrix.md';s=(R/rel).read_text()
s=replace_once(s,'Historical rows and six-area wording retain their original scope; the current queue has five remaining breadth areas and eight conditional investigations.',
 'Historical rows and six-area wording retain their original scope. The subsequent [CPU intake](../architecture/native-cpu-investigations-2026-10-18.md) adds four conditional investigations under existing owners and extends required summary, membership and publication work. The phase plan owns current counts and ordering; classifications and release gates are unchanged.')
s=replace_once(s,'including the five remaining breadth areas and eight conditional investigations in the reconciled plan.',
 'including the existing breadth obligations and the twelve named investigations in the current plan.')
updates={
 'PERF-02':'CPU package F refines verified changed-region reuse; package B uses the existing physical-state admission owner only if cross-operation reuse is justified.',
 'PERF-03':'CPU package B adds conditional codec-preparation reuse inside the same resource owner.',
 'PERF-06':'CPU package E extends required membership/population spill with partition-major finalization, exact ordinals/multiplicity and skew progress.',
 'PERF-07':'CPU package F extends required publication with real writer coordination, coherent generations, stable readers and ambiguous-commit recovery.',
 'PERF-09':'CPU package C adds conditional reversible original-payload structure with full artifact/query lifecycle proof.',
 'PERF-10':'CPU packages A and D add conditional compact selections and exact predicate-exclusion reuse; first-use summaries remain required existing work.',
}
for owner,extra in updates.items():
 rows=s.splitlines();matches=[i for i,line in enumerate(rows) if line.startswith('| `'+owner+'` |')]
 assert len(matches)==1;i=matches[0]
 marker='[Current owners and reconciliation](../architecture/native-roadmap-reconciliation-2026-10-18.md).'
 assert marker in rows[i]
 rows[i]=rows[i].replace(marker,marker+' '+extra+' [Intake](../architecture/native-cpu-investigations-2026-10-18.md).')
 s='\n'.join(rows)+'\n'
put(rel,s)
rel='docs/architecture/phased-execution-completed-ledger.md';s=(R/rel).read_text()
anchor='### Recent Completed Session Ledger\n\n'
addition='The October 18 [CPU investigation intake](native-cpu-investigations-2026-10-18.md) follows merged [PR #1575](https://github.com/depsilon/shardloom/pull/1575). It adds four conditional steps under existing owners and refines the six supplied packages without completing any runtime capability. The 54-step reconciliation below remains its original snapshot; the phase plan owns subsequent queue state. The version bump stays held.\n\n'
s=replace_once(s,anchor,anchor+addition)
put(rel,s)
(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(status='prepared',files=len(manifest),base=head,parents=14,steps=58,required=37,conditional=21)))
