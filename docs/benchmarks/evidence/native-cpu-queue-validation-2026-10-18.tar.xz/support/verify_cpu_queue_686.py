"""Verify the six-package intake against the unchanged reconciliation and active queue."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import unquote

R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
D=O/'cpu-queue-validation-686'
N='/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
sys.path[:0]=[str(O),str(R/'scripts')]
from freeze_native_release_298 import sources,save,sha
read=lambda p:json.loads(Path(p).read_text())
assert not D.exists();D.mkdir()
manifest=read(O/'cpu-queue-prepared-683/manifest.json')
assert len(manifest)==6
for ref in manifest:assert sha(R/ref['path'])==ref['prepared_sha256']
data=read(R/'docs/architecture/native-cpu-investigations-2026-10-18.json')
prior=read(R/'docs/architecture/native-roadmap-reconciliation-2026-10-18.json')
assert sha(R/'docs/architecture/native-roadmap-reconciliation-2026-10-18.json')==data['predecessor_reconciliation']['sha256']
assert len(prior['reconciliation'])==149 and len(prior['steps'])==54
assert data['status']=='queued_not_implemented' and data['version_bump']=='held'
assert not data['runtime_implemented'] and not data['benchmark_run'] and not data['performance_claim_allowed']
assert data['source_brief_sha256']==sha('/Users/dylan/.codex/attachments/3bddcbd0-bcf1-4a9d-a568-9f2044c56ca1/Pasted text.txt')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head==data['base_commit']
plan=(R/'docs/architecture/phased-execution-plan.md').read_text()
parents=re.findall(r'^- \[ \] `([^`]+)`',plan,re.M)
rows=re.findall(r'^    - \[ \] `([^`]+)` (.*)$',plan,re.M);steps=dict(rows)
assert parents==data['preserved_parent_ids']==[x['id'] for x in prior['parents']]
assert len(parents)==len(set(parents))==14 and len(rows)==len(steps)==58
assert Counter('conditional' if label.startswith('**Conditional.** ') else 'required' for label in steps.values())==dict(required=37,conditional=21)
new={x['id']:x for x in data['new_steps']}
assert set(new)=={'PERF-03.codec_preparation','PERF-10.compact_selections','PERF-10.predicate_exclusion','PERF-09.structural_payload'}
assert set(steps)==set(new)|{x['id'] for x in prior['steps']}
for old in prior['steps']:
 prefix='**Conditional.** ' if old['kind']=='conditional' else ''
 expected=prefix+old['label']+data['extended_step_suffixes'].get(old['id'],'')
 assert steps[old['id']]==expected,old['id']
for key,row in new.items():
 assert row['parent'] in parents and row['kind']=='conditional'
 assert steps[key]=='**Conditional.** '+row['label']
 start=plan.index('- [ ] `'+row['parent']+'`')
 assert '- [ ] `'+key+'`' in plan[start:plan.index('  - Next outcome:',start)]
assert [x['id'] for x in data['packages']]==list('ABCDEF')
for package in data['packages']:
 assert set(package['steps']+package['related'])<=set(steps)
assert not data['new_parent_ids']
assert all(re.search(r'\bCG-'+str(i)+r'\b',plan) for i in range(1,24))
assert plan.count('GLOBAL-RUNTIME-GAP-CARRY-FORWARD-1')==1
assert 'version bump held' in plan and 'None of A–F requires all the others' in plan
assert '58 substeps' in plan and '37 required and 21 conditional' in plan
assert 'twelve named investigations' in plan
frozen=read(O/'native-release-source-pressure692.json')
assert sources()==frozen['source_sha256']

checks=[]
def run(name,command):
 p=D/(name+'.log')
 with p.open('xb') as stream:result=subprocess.run(command,cwd=R,stdout=stream,stderr=subprocess.STDOUT)
 checks.append(dict(name=name,command=command,returncode=result.returncode,log=dict(file=p.name,bytes=p.stat().st_size,sha256=sha(p))))
 assert result.returncode==0,(name,p.read_text()[-3500:])
 print(json.dumps(dict(check=name,status='passed')),flush=True)
run('whitespace',['git','diff','--check'])
run('roadmap-regressions',[sys.executable,'-m','unittest','python.tests.test_runtime_gap_family_burn_down','python.tests.test_compute_engine_completion_gate']+[
 'python.tests.test_release_scripts.ReleaseScriptTests.'+name for name in [
 'test_architecture_tracker_missing_inputs_fail_even_when_blocked_allowed','test_architecture_tracker_accepts_mapped_global_review_burn_down',
 'test_architecture_tracker_rejects_stale_global_review_burn_down','test_v1_inclusion_scope_accepts_required_and_candidate_rows',
 'test_v1_inclusion_scope_blocks_missing_phase_classification','test_v1_inclusion_scope_blocks_required_report_only_posture',
 'test_v1_inclusion_scope_blocks_deferred_without_diagnostics','test_v1_inclusion_scope_blocks_missing_production_diagnostic_row']])
for name,script,flags in [
 ('v1-scope','check_v1_inclusion_scope.py',[]),('runtime-gaps','check_runtime_gap_family_burn_down.py',[]),
 ('completion','check_compute_engine_completion_gate.py',['--allow-incomplete']),
 ('release','check_release_architecture_tracker.py',['--allow-blocked']),
 ('public-status','check_public_status_docs.py',[]),('website-readiness','check_website_readiness.py',[]),
 ('contribution','check_contribution_governance.py',[])]:
 run(name,[sys.executable,'scripts/'+script,*flags,'--output',str(D/(name+'.json'))])
assert read(D/'completion.json')['status']==read(D/'release.json')['status']=='blocked'
assert read(D/'completion.json')['phase_plan_unchecked_count']==72

links=[];headings={}
for ref in manifest:
 p=R/ref['path']
 if p.suffix!='.md':continue
 content=p.read_text()
 if p.name=='phased-execution-completed-ledger.md':
  content=content.split('### Recent Completed Session Ledger\n\n',1)[1].split('- [x] `PERF-12.prebump`',1)[0]
 for match in re.finditer(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',content):
  value=match[1].strip().strip('<>')
  if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:',value):continue
  base,_,anchor=value.partition('#');target=(p.parent/unquote(base)).resolve() if base else p
  assert target.is_file(),(str(p),value)
  links.append(dict(source=str(p.relative_to(R)),target=value,resolved=str(target),anchor=unquote(anchor)))
  if anchor and str(target) not in headings:
   hs=[]
   for heading in re.finditer(r'^#{1,6}\s+(.+?)\s*#*$',target.read_text(),re.M):
    label=re.sub(r'\[([^\]]+)\]\([^)]+\)',r'\1',heading[1])
    hs.append(re.sub(r'<[^>]+>','',label).replace('`','').replace('**','').replace('*',''))
   headings[str(target)]=hs
code="""import GithubSlugger from './website-src/node_modules/github-slugger/index.js';let input='';for await(const p of process.stdin)input+=p;const out={};for(const [p,hs] of Object.entries(JSON.parse(input))){const s=new GithubSlugger();out[p]=hs.map(h=>s.slug(h));}process.stdout.write(JSON.stringify(out));"""
got=subprocess.run([N,'--input-type=module','-e',code],cwd=R,input=json.dumps(headings),text=True,capture_output=True,check=True)
slugs=json.loads(got.stdout)
for link in links:
 if link['anchor']:assert link['anchor'] in slugs[link['resolved']],link
assert sources()==frozen['source_sha256']
record=dict(schema_version='shardloom.native_cpu_queue_validation.v1',status='passed',base_commit=head,
 packages=6,parents=14,steps=58,required=37,conditional=21,named_investigations=12,
 historical_reconciliation_rows_unchanged=149,original_steps_preserved=54,new_steps=sorted(new),extended_steps=sorted(data['extended_step_suffixes']),
 checks=checks,local_links_verified=len(links),anchors_verified=sum(bool(x['anchor']) for x in links),links=links,
 runtime_source_files=2416,runtime_source_unchanged=True,version_changed=False,version_bump='held',
 completion_and_release_remain_blocked=True,benchmark_run=False,
 source_identities=[dict(file=x['path'],bytes=(R/x['path']).stat().st_size,sha256=sha(R/x['path'])) for x in manifest],
 primary_semantic_review='All six packages retain their distinct contracts. A/B begin with measured-cost assessment; C is a different original-payload experiment; D separates first-use summaries from exact complete-coverage facts; E and safe publication in F remain required. No duplicate owner, dependency chain across all packages, relaxed historic drop gate, fallback execution or runtime/benefit claim is introduced.',
 validation_scope='Documentation and existing roadmap regression checks. No native rebuild, candidate execution or benchmark rerun is justified by this queue-only edit; hosted CI validates the final commit.',
 helper=dict(path=__file__,sha256=sha(__file__)))
save(D/'validation.json',record)
print(json.dumps(dict(status='passed',checks=len(checks),packages=6,parents=14,steps=58,links=len(links))),flush=True)
