# CPU intake literal coverage inventory

Scope: compare the six packages and concrete contracts visible in the supplied pasted text with the draft queue document. Source references below use line numbers in `Pasted text.txt`; draft references use line numbers in `native-cpu-investigations-2026-10-18.draft.md`. The linked 4,600-word sandbox handoff itself was inaccessible and is not treated as reviewed. This is therefore complete for the supplied pasted text, not certification against the linked handoff.

## Cross-package directions and constraints

| Source request | Draft coverage | Assessment |
|---|---|---|
| Six CPU-only packages, no different hardware/GPU/hosted model/other engine (src 1, 13–20) | Draft 22 | Covered literally. |
| Nullable-record correction after #1574 is foundation; do not repeat; review conditional investigations before version bump (src 9) | Draft 3–5, 20, 98 | Covered; bump explicitly held. |
| Assess A and B against callers, then select stronger measured cost; C separate; D components independent; E/F extend existing owners; no unnecessary dependency ordering (src 22–24) | Draft 18 | Covered. |
| Keep existing owners, no duplicate project (src 22; per-package contracts below) | Draft 9–18 and package sections | Covered by explicit owner mapping and descriptions. |
| Avoid replacing optimization framework; establish real repeated cost, smallest shared fix, current process; drop bad strategies without excluding workloads (src 283–300) | Draft 20, 96–98 and package-specific acceptance | Substantively covered; some wording is in general acceptance rather than repeated per package. |

## A — Compact selections and execution descriptors

| Concrete contract/deliverable in source | Draft coverage | Assessment |
|---|---|---|
| Find an actual costly representation boundary, e.g. mask expansion or repeated reconstruction (src 38) | Draft 26 | Covered. |
| Extend existing selection representation, no competing system (src 40) | Draft 28 | Covered. |
| Preserve ordered gathers, including order and duplicates; membership bitmap alone insufficient (src 42–48) | Draft 28, 32 | Covered. |
| Membership may use local sparse/dense regions and compact offsets/bits; global positions checked and sufficiently wide; local width is not dataset cap (src 50) | Draft 28 | Covered. |
| Integrate into multiple real consumers, e.g. filtered count and projected gather; avoid immediate expansion to `Vec<u64>` (src 52) | Draft 30 | Covered. |
| Evaluate complete-operation cost or accepted memory benefit without material throughput regression; include construction/conversion/iteration/ownership (src 56) | Draft 30, 32 | Covered; exact retain threshold remains described as “predeclared useful” and is not numeric. |
| Tests for repeated/reordered gather, sparse/dense, sliced bases, large positions, null validity, cancellation, retained owners (src 58) | Draft 32 | Covered; draft additionally names all/none/empty and selection composition/last-owner release. |

## B — Reusable codec preparation

| Concrete contract/deliverable in source | Draft coverage | Assessment |
|---|---|---|
| Reuse compatible preparation, not claim research speedups; preserve current independent concurrent Zstd contexts and temporary-workspace release lifecycle (src 66–68) | Draft 36, 40–46 | Covered. |
| Distinguish immutable preparation, exclusive mutable workspace leases/reset/failure, and data-derived state tied to source generation/schema/fields/expressions (src 72–80) | Draft 38–43 | Covered; draft also names applicable deletion identity. |
| Start operation/context-local; cross-operation reuse only if expensive reconstruction is observed (src 82) | Draft 44 | Covered. |
| No hidden global cache or separate budget; reclaim idle retained state before blocking allocations (src 84) | Draft 44 | Covered. |
| Persist portable recipes/tables, no process pointers or opaque decoder memory; artifact decodes after producer process exits (src 86) | Draft 46 | Covered. |
| Measure setup plus first use and later-use sequence including lookup/synchronization/retention/eviction/cleanup (src 90) | Draft 46 | Covered; reset is added. |
| Do not re-run rejected stronger-Zstd/dictionary experiment under new name (src 92) | Draft 46 | Covered. |

## C — Reversible structural payload encoding

| Concrete contract/deliverable in source | Draft coverage | Assessment |
|---|---|---|
| Small deterministic exact structural encoding with literal residuals; not synthesis or semantic normalization; target original text, distinct from derived domain/length data (src 100–102) | Draft 50–52 | Covered. |
| Reversible components include exact structure, variable spans, literal exceptions, reconstruction metadata, original validity (src 106–114) | Draft 52 | Covered. |
| Candidate examples exact prefix/suffix/template; choose from data/cost, not URL/Referer/query recognition (src 116) | Draft 52 | Covered. |
| Keep logical type; prove exact reconstruction before specialized consumers (src 118) | Draft 52 | Covered. |
| Useful native operations include exact length, equality, selection, projection; ordering/substring/regex semantics must remain exact; existing native path until equivalence (src 120–122) | Draft 54 | Covered. |
| Lifecycle: prepare/compute, write native artifact, close, move/reopen fresh process, different operations, write/reopen again; ingest-only not enough (src 126–137) | Draft 56, 58 | Covered. |
| Preserve capitalization, percent encoding, delimiters, Unicode, embedded NULs, nulls, irregular values; raw JSON whitespace, duplicate-key and number spelling (src 139) | Draft 56 | Covered. |
| Whole-artifact/workflow accounting for templates/tables/residuals/offsets/exceptions/reconstruction/finalization; no small sample or isolated fast expression that makes ordinary decoding costly (src 143–145) | Draft 58 | Covered; draft additionally includes validity. |

## D — Summaries and predicate-exclusion reuse

| Concrete contract/deliverable in source | Draft coverage | Assessment |
|---|---|---|
| Keep first-use summaries and reusable exact exclusion as distinct implementations/measurements (src 153) | Draft 62–66 | Covered. |
| Find genuine first-use pruning gap; least-cost useful summary examples; do not enlarge all footers/recluster; summary describes transformed output (src 157–161) | Draft 64 | Covered. |
| Reusable fact means no covered row in immutable region makes exact predicate TRUE; useful across separate operations, not cached answer (src 165–169) | Draft 66 | Covered. |
| Bind to source/region, full coverage, field types, expression params and null/collation/timezone, deletion and access context (src 171) | Draft 68 | Covered. |
| Partial mask/sample/limit/cancel/failure cannot prove whole-region exclusion; `NOT P` needs three-valued semantics (src 173–175) | Draft 68 | Covered. |
| First-use summary must improve first-use pruning; reusable fact tested across complete related-query sequence with invalidation, changed params/source, nulls, eviction, controls (src 179–181) | Draft 64, 70 | Covered; draft explicitly adds deletions and unrelated workloads. |
| No warm-up prerequisite; without valid fact use ordinary exact execution (src 183) | Draft 70 | Covered. |

## E — Partition-major external-memory state

| Concrete contract/deliverable in source | Draft coverage | Assessment |
|---|---|---|
| Extend membership/population backlog: route complete keys/ordinals, process partition, finalize, release state, reconcile output (src 195–203) | Draft 74, 76 | Covered. |
| Use native partitioning, runs, ordering, exact comparisons, disk quotas, cleanup (src 205) | Draft 74 | Covered. |
| First/last dedup requires ordinals; remove-all complete multiplicity (src 209) | Draft 76 | Covered. |
| Duplicate-mask results map to original row positions (src 211) | Draft 76 | Covered. |
| Membership/quantified predicates preserve empty-set/null behavior (src 213) | Draft 76 | Covered. |
| Sampling/future-dependent operations preserve actual algorithm (src 215) | Draft 76 | Covered; draft makes seeded/weighted/ordering explicit. |
| Skew repartition makes progress; exact sorted-run strategy if needed; no fixed retry count as dataset limit (src 217) | Draft 78 | Covered. |
| Required exact capability when logical state exceeds memory grant; cancellation/failure/corruption/cleanup (src 221–225) | Draft 80 | Covered; draft adds authorized temp storage, quota exhaustion, truncated runs, restart-vs-resume, spill-disabled refusal. |
| Do not gate on Full43 2% reduction; use workload-appropriate controls (src 225) | Draft 80 | Covered. |

## F — Changed-generation reuse and safe publication

| Concrete contract/deliverable in source | Draft coverage | Assessment |
|---|---|---|
| Reuse keyed by trustworthy source identity and compatible schema/transforms/recipes/dictionaries/deletion; begin with identifiable immutable units (src 237–239) | Draft 86 | Covered. |
| Path/length/mtime insufficient; include expensive validation in lifecycle timing (src 241) | Draft 86, 88, 96 | Covered. |
| Handle new region, unchanged compatible region, deletion change, recipe change, rewritten monolithic source distinctly (src 243–251) | Draft 88 | Covered. |
| Reused bytes in a new single-file artifact can incur copy/I/O; do not call it zero-I/O (src 253) | Draft 88 | Covered (“still counts as I/O”). |
| Stage/validate then publish; multi-output needs one authoritative transition; reject check-then-rename race; real provider-appropriate coordination and writer set (src 257–269) | Draft 90 | Covered. |
| Separate atomic visibility from crash durability; stable old readers; resolve ambiguous commit retries; safe cleanup wrt external inputs/readers (src 271) | Draft 92 | Covered. |
| Compare full refresh to correct rebuild; test competing writers, old/new readers, cancellation around commit, crashes, ambiguous acknowledgements, retries, GC (src 275–279) | Draft 88, 92 | Covered. |
| Safe replacement required even if reuse unprofitable (src 279) | Draft 92 | Covered. |

## Literal omissions, limitations, and ambiguities

1. The source says the complete 4,600-word handoff is available via two `sandbox:/mnt/data/...` links (source 3–7), but that linked content was inaccessible. The audit can only establish coverage of the pasted 299-line summary; requirements that appear only in the linked handoff cannot be checked.
2. The source's A retain criterion is qualitative (“reduced complete-operation cost or an accepted memory improvement without a material throughput regression,” source 56). Draft 32 calls for a “predeclared useful execution or memory improvement” but gives no numeric threshold in this draft. This is consistent in kind; whether the owner contract supplies an adequate threshold requires checking that referenced contract.
3. Source 22 says the preferred starting point is a short assessment of A and B. Draft 18 preserves that direction, but does not state a distinct artifact name for the assessment. The source does not name such an artifact either.
4. The source supplies supporting research references in package idea sections (source 34, 66, 100, 153, 191, 233). Draft largely omits those citations and the explanations of transferable lessons. These are rationale/research pointers, while the visible concrete engineering contracts are preserved; whether the citations themselves are required deliverables is ambiguous in the pasted text.
5. The source says C is “higher-upside” and recommends pursuing it as a substantial compression experiment (source 22, 300). Draft labels it a separate original-payload compression experiment (18, 48–58) but does not repeat the “higher-upside” prioritization. This looks like recommendation language rather than a technical acceptance contract; confirm only if that prioritization was intended to be normative.
6. No source-visible package contract is otherwise literally omitted from the draft. The draft adds specificity in several areas (all/none selections, allocation denial/corruption, validity costs, false-negative safety, recovery modes and commit tests), which does not conflict with the pasted text.

## Result

**NEEDS_REASONING** only for the unavailable linked full handoff and the noted interpretation/threshold questions. Against the supplied pasted text itself, all six package deliverables and concrete semantic/resource/lifecycle acceptance contracts have matching draft coverage. No source-visible omission requiring a new owner or architecture was found.
