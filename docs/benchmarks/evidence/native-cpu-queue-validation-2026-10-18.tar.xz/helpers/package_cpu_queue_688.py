"""Package queue-only validation with all logs and exact edited-source identities."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
D=O/'cpu-queue-validation-686'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
read=lambda path:json.loads(Path(path).read_text())
result=read(D/'validation.json')
receipt=read(O/'cpu-queue-docs-686a2.json')
assert result['status']==receipt['status']=='passed'
assert receipt['process_group_drained'] and receipt['direct_child_reaped']
assert receipt['head']==result['base_commit']
assert sha((O/'cpu-queue-docs-686a2.log').read_bytes())==receipt['log_sha256']
assert len(result['checks'])==9 and all(c['returncode']==0 for c in result['checks'])
assert result['runtime_source_files']==2416 and result['runtime_source_unchanged']
assert result['version_bump']=='held' and not result['benchmark_run']
assert result['base_commit']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
files={}
def add(name,path):
    assert name not in files and path.is_file() and not path.is_symlink()
    files[name]=path.read_bytes()
for path in sorted(D.rglob('*')):
    if path.is_file():add('validation/'+path.relative_to(D).as_posix(),path)
for name in ['verify_cpu_queue_686.py','prepare_cpu_queue_683.py','cpu-queue-docs-686.json',
    'cpu-queue-docs-686.log','cpu-queue-docs-686a2.json','cpu-queue-docs-686a2.log',
    'cpu-intake-coverage-687.md','run_guarded.py']:
    add('support/'+name,O/name)
for name in ['freeze_native_release_298.py','native-release-source-pressure692.json']:
    add('support/'+name,O/name)
add('support/release_validation_guard.py',Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'))
add('support/bounded_build_process_resume_20260912.py',Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py'))
assert sha(files['support/bounded_build_process_resume_20260912.py'])==receipt['supervisor_sha256']
add('support/local_uat_storage.py',R/'scripts/local_uat_storage.py')
frozen=read(O/'native-release-source-pressure692.json')
assert len(frozen['source_sha256'])==result['runtime_source_files']
assert sha(files['support/local_uat_storage.py'])==frozen['source_sha256']['scripts/local_uat_storage.py']
add('support/prepared-manifest.json',O/'cpu-queue-prepared-683/manifest.json')
add('helpers/'+Path(__file__).name,Path(__file__))
for ref in result['source_identities']:
    raw=(R/ref['file']).read_bytes()
    assert len(raw)==ref['bytes'] and sha(raw)==ref['sha256']
    files['source/'+ref['file']]=raw
for check in result['checks']:
    raw=(D/check['log']['file']).read_bytes()
    assert len(raw)==check['log']['bytes'] and sha(raw)==check['log']['sha256']
assert sum(map(len,files.values()))<8*1024*1024
evidence=R/'docs/benchmarks/evidence'
archive=evidence/'native-cpu-queue-validation-2026-10-18.tar.xz'
index=archive.with_suffix('').with_suffix('.json')
assert not archive.exists() and not index.exists()
members=[]
with tarfile.open(archive,'x:xz') as bundle:
    for name,raw in sorted(files.items()):
        entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mode=0o644
        bundle.addfile(entry,io.BytesIO(raw))
        members.append(dict(name=name,bytes=len(raw),sha256=sha(raw)))
with tarfile.open(archive,'r:xz') as bundle:
    assert len(bundle.getmembers())==len(files)==len({m.name for m in bundle.getmembers()})
    for item in members:
        entry=bundle.getmember(item['name']);assert entry.isfile()
        assert bundle.extractfile(entry).read()==files[item['name']]
report={key:value for key,value in result.items() if key not in ('links','checks','helper')}
report.update(schema_version='shardloom.native_cpu_queue_validation_packet.v1',
    checks=[dict(name=c['name'],returncode=c['returncode'],log='validation/'+c['log']['file']) for c in result['checks']],
    archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes())),
    members=members,member_count=len(members),all_members_reopened=True,
    hosted_status='Local queue validation only; final PR checks are recorded separately.',
    launch_correction='The initial guarded launch used a relative script path after the supervisor changed directory; Python exited before validation. The corrected absolute-path launch and both observations are preserved.',
    coverage_audit_disposition='Primary compared all six supplied package contracts with the draft and accepted coverage. Numeric retain/drop criteria are frozen per candidate before measurement. Unavailable linked sandbox content and external research speed claims were not inferred.')
index.open('x').write(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(status='passed',index=str(index),members=len(members),archive_bytes=archive.stat().st_size)))
