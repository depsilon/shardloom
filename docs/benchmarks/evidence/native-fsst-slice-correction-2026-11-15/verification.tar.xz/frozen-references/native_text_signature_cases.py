# SPDX-License-Identifier: Apache-2.0
"""Independent logical populations for necessary text-summary consumers."""

from collections import Counter
import gc
from pathlib import Path
import shutil
import tempfile

FIXTURES = Path(__file__).parent / "data" / "text-signatures-v1"
PROFILES = ("selective", "unclustered", "dense", "absent", "saturated", "all-null",
            "short", "empty", "missing")
ENCODINGS = ("flat", "dictionary", "fsst")
KINDS = ("selective", "unicode", "escaped", "short_needle", "empty_needle", "negated",
         "folded", "count", "group", "materialize", "shared", "barrier", "unfiltered")
PROOF = "local_primitive_native_io_pushdown_proof_basis"


def population(size, profile):
    """Complete cells; no signature bit mapping or native writer is consulted."""
    assert size in ("public", "work") and profile in PROFILES
    zone = 8 if size == "public" else 1024
    for row_id in range(0 if profile == "empty" else zone * 8 + 3):
        if profile == "all-null" or row_id % 17 == 0:
            value = None
        elif profile == "short":
            value = ("", "a", "ab", "é", "☃")[row_id % 5]
        elif profile == "saturated":
            state, chars, mask = row_id + 1, [], (1 << 64) - 1
            for _ in range(1024):
                state ^= (state << 13) & mask
                state ^= state >> 7
                state ^= (state << 17) & mask
                chars.append(chr(33 + state % 90))
            value = "".join(chars)
        else:
            selected = (profile == "dense" or
                        profile in ("selective", "missing") and row_id // zone == 3 and row_id % 4 == 0 or
                        profile == "unclustered" and row_id % 13 == 0)
            value = (f"the needle / 🧶☃ / 100%_ / row {row_id % 23} / Ω" if selected else
                     f"ordinary cedar / row {row_id % 23} / Ω")
        yield dict(row_id=row_id, value=value, bucket=row_id % 7)


def needle(kind):
    assert kind in KINDS
    return {"unicode": "🧶☃", "escaped": "100%_", "short_needle": "ab", "empty_needle": ""}.get(kind, "needle")


def oracle(size, profile, kind):
    values = list(population(size, profile))
    if kind == "barrier":
        values = values[:31]
    if kind != "unfiltered":
        target = needle(kind)
        values = [row for row in values if row["value"] is not None and
                  ((target in (row["value"].lower() if kind == "folded" else row["value"]))
                   != (kind == "negated"))]
    if kind == "count":
        return [dict(rows=len(values))]
    if kind == "group":
        counts = Counter(row["bucket"] for row in values)
        return [dict(bucket=value, rows=counts[value]) for value in sorted(counts)]
    if kind == "shared":
        values *= 2
    values.sort(key=lambda row: row["row_id"])
    if kind == "materialize":
        return values
    return [dict(row_id=row["row_id"]) for row in values]


def observations(proof):
    result = {}
    for token in (proof or "").split():
        name, sep, value = token.partition("=")
        if sep and name.startswith("native_text_signature_v1_"):
            assert name not in result, name
            value = value.split(";", 1)[0]
            result[name.removeprefix("native_text_signature_v1_")] = int(value) if value.isdecimal() else value
    return result


def check_report(test, profile, kind, get):
    observed = observations(get(PROOF))
    test.assertEqual(observed.get("scope"), "exclusive_operation", (profile, kind, observed))
    test.assertLessEqual(observed["excluded"] + observed["unknown"], observed["zone_tests"])
    if profile in ("missing", "empty") or kind in ("short_needle", "empty_needle", "negated", "folded", "barrier", "unfiltered"):
        test.assertEqual(observed["calls"], 0, (profile, kind, observed))
    elif profile in ("selective", "absent", "all-null"):
        test.assertGreater(observed["calls"], 0, (profile, kind, observed))
        test.assertGreater(observed["excluded"], 0, (profile, kind, observed))


def queries(test, client, path, kind):
    import shardloom as sl

    expr = test.native.Expression
    frame, relation = sl.read_vortex(path, client=client), test.native.Relation.scan(str(path))
    source = f"'{path}'"
    if kind == "barrier":
        frame, relation = frame.sort("row_id").limit(31), relation.sort([("row_id", False, "last")]).limit(31)
        source = f"(SELECT * FROM {source} ORDER BY row_id LIMIT 31) AS bounded"
    if kind != "unfiltered":
        target = needle(kind)
        text = expr.column("value")
        sql = "value"
        if kind == "folded":
            text, sql = expr.call("lower", [text]), "lower(value)"
        predicate = expr.call("contains", [text, expr.literal(target)])
        condition = f"contains({sql},'{target}')"
        if kind == "negated":
            predicate, condition = ~predicate, f"NOT ({condition})"
        frame, relation = frame.where(condition), relation.filter(predicate)
        source = f"(SELECT * FROM {source} WHERE {condition}) AS filtered"
    if kind == "count":
        return frame.agg("COUNT(*) AS rows"), relation.aggregate([], [("count", None, "rows")]), f"SELECT COUNT(*) AS rows FROM {source}"
    if kind == "group":
        return (frame.group_by("bucket").agg("COUNT(*) AS rows").sort("bucket"),
                relation.aggregate(["bucket"], [("count", None, "rows")]).sort([("bucket", False, "last")]),
                f"SELECT bucket,COUNT(*) AS rows FROM {source} GROUP BY bucket ORDER BY bucket")
    if kind == "shared":
        frame, relation = frame.union_all(frame), relation.set_operation(relation, kind="union_all")
        source = f"(SELECT * FROM {source} UNION ALL SELECT * FROM {source}) AS shared"
    columns = ("row_id", "value", "bucket") if kind == "materialize" else ("row_id",)
    return (frame.select(*columns).sort("row_id"),
            relation.project([(name, expr.column(name)) for name in columns]).sort([("row_id", False, "last")]),
            f"SELECT {','.join(columns)} FROM {source} ORDER BY row_id")


def check_surfaces(test):
    import shardloom as sl

    client = sl.ShardLoomClient(transport="native", memory_bytes=128 << 20, max_parallelism=2)
    test.addCleanup(client.close)
    for profile in PROFILES:
        kinds = KINDS if profile == "selective" else ("selective", "count", "materialize", "unfiltered")
        for encoding in ENCODINGS:
            for kind in kinds:
                with test.subTest(profile=profile, encoding=encoding, kind=kind):
                    frame, relation, statement = queries(test, client, FIXTURES / f"{profile}-{encoding}.vortex", kind)
                    for table in test.all_surfaces(frame, relation, statement,
                            report_check=lambda get: check_report(test, profile, kind, get)):
                        test.assertEqual(table.to_pylist(), oracle("public", profile, kind))
                        for field in table.schema:
                            test.assertEqual(field.type, test.pa.string() if field.name == "value" else
                                             test.pa.uint64() if field.name == "rows" else test.pa.int64())
                            test.assertEqual(field.nullable, field.name == "value")


def check_owned_and_changed_source(test):
    with tempfile.TemporaryDirectory(prefix="shardloom-text-summary-owned-") as directory:
        path = Path(directory) / "source.vortex"
        shutil.copyfile(FIXTURES / "selective-fsst.vortex", path)
        session = test.native.Session(test.native.ExecutionResources(128 << 20, 2))
        statement = f"SELECT row_id,value,bucket FROM '{path}' WHERE contains(value,'needle') ORDER BY row_id"
        plan = session.sql(statement)
        first, second = plan.collect(), plan.collect()
        first_work = observations(first.report.get(PROOF))
        test.assertGreater(first_work["excluded"], 0)
        test.assertEqual(first_work, observations(second.report.get(PROOF)))
        shutil.copyfile(FIXTURES / "missing-fsst.vortex", path)
        with test.assertRaisesRegex(Exception, "prepared source changed"):
            plan.collect()
        plan.release_prepared()
        retry = session.sql(statement)
        retried = retry.collect()
        expected = oracle("public", "selective", "materialize")
        test.assertEqual(test.table(retried).to_pylist(), expected)
        test.assertEqual(observations(retried.report.get(PROOF))["calls"], 0)
        retry.release_prepared()
        del retry, retried, plan, second
        session.close()
        path.unlink()
        test.assertGreater(session.snapshot()["reserved_bytes"], 0)
        table = test.table(first)
        test.assertEqual(table.to_pylist(), expected)
        retained = test.session.sql("SELECT * FROM 'memory://text-summary-result'",
                                   sources=[("memory://text-summary-result", first.as_source())])
        for name in ("vortex", "parquet", "arrow-ipc"):
            target = Path(directory) / f"result.{name}"
            report = retained.write(target, "write_" + name.replace("-", "_"))
            test.assertEqual(report["fallback_attempted"], "false")
            test.assertEqual(report["external_engine_invoked"], "false")
            reopened = test.table(test.session.sql(f"SELECT * FROM '{target}'",
                files=[(str(target), name, None)]).collect())
            test.assertEqual(reopened.to_pylist(), expected)
        retained.release_prepared()
        del first, table, retained, reopened
        gc.collect()
        test.assertEqual(session.snapshot()["reserved_bytes"], 0)
