#!/usr/bin/env python3
"""Offline validation of an FSST existing-input diagnostic and frozen references."""

from __future__ import annotations

import argparse
import ast
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
from collections import Counter, defaultdict


EXPECTED_PATTERNS = {
    "needle": "needle",
    "unicode_yarn_snow": "🧶☃",
    "escaped_literal": "100%_",
    "short_ab": "ab",
    "empty": "",
    "x253": "x" * 253,
    "x254": "x" * 254,
    "x255": "x" * 255,
}
EXPECTED_OPERATIONS = ("contains", "startswith")
ENCODINGS = ("flat", "dictionary", "fsst")
CONSUMERS_BY_FILTER = {
    ("contains", "needle"): ("project", "filter", "count", "legacy_scan"),
    ("startswith", "short_ab"): ("project", "filter", "count"),
}


class ValidationError(Exception):
    pass


def fail(message: str) -> None:
    raise ValidationError(message)


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def generation(path: Path) -> dict[str, int]:
    info = path.stat()
    return {
        "device": info.st_dev,
        "inode": info.st_ino,
        "bytes": info.st_size,
        "mtime_ns": info.st_mtime_ns,
        "ctime_ns": info.st_ctime_ns,
    }


def bit_string(values: list) -> str:
    return "".join("n" if value is None else "t" if value is True else "f" for value in values)


def same_json_exact(left, right) -> bool:
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return set(left) == set(right) and all(same_json_exact(left[key], right[key]) for key in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(same_json_exact(a, b) for a, b in zip(left, right))
    return left == right


def is_int(value) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_population_oracle(path: Path, expected_sha: str, expected_commit: str):
    actual_sha = sha256_file(path)
    if actual_sha != expected_sha:
        fail(f"population oracle SHA-256 mismatch: {path}")
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    imported_modules = []
    for node in tree.body:
        if isinstance(node, ast.Import):
            imported_modules.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            imported_modules.append(node.module)
    if any(name == "shardloom" or name.startswith("shardloom.") for name in imported_modules):
        fail("population oracle source unexpectedly imports ShardLoom")
    nonstandard = sorted({name.split(".", 1)[0] for name in imported_modules
                          if name.split(".", 1)[0] not in sys.stdlib_module_names})
    if nonstandard:
        fail(f"population oracle has non-standard top-level imports: {nonstandard}")
    spec = importlib.util.spec_from_file_location("fsst_validation_population_oracle", path)
    if spec is None or spec.loader is None:
        fail("could not load population oracle")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if "shardloom" in sys.modules:
        fail("ShardLoom module was imported during offline validation")
    return module


def load_jsonl_gzip(path: Path) -> list[dict]:
    records = []
    with gzip.open(path, "rt", encoding="utf-8", newline="") as stream:
        for line_number, line in enumerate(stream, 1):
            if not line.endswith("\n"):
                fail(f"record file line lacks newline: {line_number}")
            value = json.loads(line)
            if not isinstance(value, dict):
                fail(f"record line is not a JSON object: {line_number}")
            records.append(value)
    return records


def validate(args) -> dict:
    freeze_path = args.freeze_manifest
    reference_path = args.reference_gzip
    record_path = args.records_gzip
    guard_path = args.guard_json
    output_path = args.output
    if output_path.exists():
        fail(f"refusing to overwrite output: {output_path}")

    freeze = load_json(freeze_path)
    guard = load_json(guard_path)
    if freeze.get("status") != "passed":
        fail("input-freeze manifest is not passed")
    if freeze.get("schema") != "shardloom.native-fsst-consumer.input-freeze.v1":
        fail("unexpected input-freeze manifest schema")
    reference_meta = freeze["boolean_references"]
    compressed = reference_path.read_bytes()
    if sha256_bytes(compressed) != reference_meta["gzip_sha256"]:
        fail("boolean reference gzip SHA-256 mismatch")
    if len(compressed) < 10 or int.from_bytes(compressed[4:8], "little") != 0:
        fail("boolean reference gzip mtime is not zero")
    reference_bytes = gzip.decompress(compressed)
    if sha256_bytes(reference_bytes) != reference_meta["uncompressed_json_sha256"]:
        fail("uncompressed boolean reference SHA-256 mismatch")
    reference_document = json.loads(reference_bytes)
    if reference_document.get("schema") != "shardloom.native-fsst-consumer.boolean-reference.v1":
        fail("unexpected boolean-reference schema")
    if reference_document.get("patterns") != [
        {"id": key, "value": value} for key, value in EXPECTED_PATTERNS.items()
    ]:
        fail("boolean reference pattern inventory differs from the frozen contract")
    if reference_document.get("operations") != list(EXPECTED_OPERATIONS):
        fail("boolean reference operations differ from the frozen contract")
    oracle_meta = freeze["pinned_oracle"]
    if reference_document["oracle"]["git_commit"] != oracle_meta["git_commit"]:
        fail("reference oracle commit differs from freeze manifest")
    oracle = load_population_oracle(args.population_oracle, oracle_meta["sha256"], oracle_meta["git_commit"])

    inputs = freeze["inputs"]
    if len(inputs) != 54:
        fail(f"expected 54 frozen baseline inputs, got {len(inputs)}")
    input_by_sha = defaultdict(list)
    input_by_identity = {}
    populations = {}
    for item in inputs:
        if item.get("role") != "baseline":
            fail("non-baseline entry found in frozen input list")
        digest = item["input"]["sha256"]
        identity = (item["size"], item["profile"], item["encoding"])
        if identity in input_by_identity:
            fail(f"duplicate frozen input identity: {identity}")
        input_by_identity[identity] = item
        input_by_sha[digest].append(item)
        source_path = Path(item["input"]["path"])
        if generation(source_path) != item["input"]["generation"]:
            fail(f"frozen input generation changed: {source_path}")
        if sha256_file(source_path) != digest:
            fail(f"frozen input hash changed: {source_path}")
        pair = (item["size"], item["profile"])
        if pair not in populations:
            populations[pair] = list(oracle.population(*pair))
        if len(populations[pair]) != item["rows"]:
            fail(f"population row count differs from frozen input: {pair}")

    references = reference_document["vectors"]
    expected_reference_keys = {
        (size, profile, operation, pattern_id)
        for size, profile in populations
        for operation in EXPECTED_OPERATIONS
        for pattern_id in EXPECTED_PATTERNS
    }
    reference_by_key = {}
    ref_counts = []
    for ref in references:
        key = (ref["size"], ref["profile"], ref["operation"], ref["pattern_id"])
        if key in reference_by_key:
            fail(f"duplicate Boolean reference key: {key}")
        reference_by_key[key] = ref
    if set(reference_by_key) != expected_reference_keys or len(references) != 288:
        fail("Boolean references do not form the complete 18 x 2 x 8 grid")

    vector_cell_count = 0
    null_cell_count = 0
    true_cell_count = 0
    false_cell_count = 0
    row_ids_by_pair = {}
    for key in sorted(expected_reference_keys):
        size, profile, operation, pattern_id = key
        ref = reference_by_key[key]
        values = ref["values"]
        rows = populations[(size, profile)]
        if any(value is not None and not isinstance(value, bool) for value in values):
            fail(f"reference contains a non-Boolean, non-null cell: {key}")
        if ref["pattern"] != EXPECTED_PATTERNS[pattern_id] or ref["shared_encodings"] != list(ENCODINGS):
            fail(f"reference metadata mismatch: {key}")
        if ref["rows"] != len(rows) or len(values) != len(rows):
            fail(f"reference row count mismatch: {key}")
        expected_values = []
        for row in rows:
            value = row["value"]
            pattern = EXPECTED_PATTERNS[pattern_id]
            if value is None:
                expected_values.append(None)
            elif operation == "contains":
                expected_values.append(pattern in value)
            else:
                expected_values.append(value.startswith(pattern))
        if values != expected_values:
            fail(f"Boolean reference does not match independent population semantics: {key}")
        counts = Counter("null" if value is None else "true" if value else "false" for value in values)
        vector_cell_count += len(values)
        null_cell_count += counts["null"]
        true_cell_count += counts["true"]
        false_cell_count += counts["false"]
        ref_counts.append({
            "size": size,
            "profile": profile,
            "operation": operation,
            "pattern_id": pattern_id,
            "rows": len(values),
            "null": counts["null"],
            "true": counts["true"],
            "false": counts["false"],
        })
    for pair, rows in populations.items():
        row_ids = [row["row_id"] for row in rows]
        if len(set(row_ids)) != len(row_ids):
            fail(f"population row IDs are not unique: {pair}")
        row_ids_by_pair[pair] = row_ids

    records = load_jsonl_gzip(record_path)
    counts = Counter(record.get("case") for record in records)
    expected_case_counts = {
        "physical_file_consumer": 864,
        "complete_file_request": 378,
        "complete_request_refund": 378,
        "existing_input_completion": 1,
    }
    if args.expect_dispatch:
        expected_case_counts["upstream_like_dispatch"] = 378
    if counts != Counter(expected_case_counts):
        fail(f"unexpected record cases/counts: {dict(counts)}")

    physical_records = [r for r in records if r["case"] == "physical_file_consumer"]
    complete_records = [r for r in records if r["case"] == "complete_file_request"]
    refund_records = [r for r in records if r["case"] == "complete_request_refund"]
    completion_records = [r for r in records if r["case"] == "existing_input_completion"]
    expected_fields = {
        "physical_file_consumer": {
            "all_owners_dropped_reserved_bytes", "case", "complete_equal", "complete_shared_values",
            "direct_kernel_calls", "direct_kernel_parts", "encoding", "engine_timing", "input",
            "native_reservations_refunded", "operation", "pattern", "physical_input_batches",
            "prepared_reserved_after_observation", "prepared_reserved_before", "profile", "size",
        },
        "complete_file_request": {
            "actual", "actual_schema", "case", "complete_equal", "consumer", "encoding",
            "fallback_attempted", "input", "legacy_fsst_like_calls", "legacy_fsst_like_rows",
            "native_io_certificate", "operation", "output_rows", "pattern", "physical_reads",
            "profile", "provider", "scan_batches", "scan_rows", "size", "variable_domain_values",
            "variable_domains", "variable_fsst_domain_values", "variable_fsst_domains",
        },
        "complete_request_refund": {
            "all_owners_dropped_reserved_bytes", "case", "consumer", "input", "operation", "pattern",
            "prepared_reserved_after_result_drop", "prepared_reserved_before",
        },
        "existing_input_completion": {
            "case", "complete_public_core_requests", "engine_timing", "inputs",
            "physical_shared_declarations",
        },
        "upstream_like_dispatch": {
            "case", "input", "size", "profile", "encoding", "operation", "pattern", "consumer",
            "successful_calls", "logical_operand_rows", "eligible_contains_calls", "prefilter_calls",
            "prefilter_rows", "rejected_rows", "exact_rows", "matcher_constructions", "block_rejections",
            "overflowed", "engine_timing",
        },
    }
    for record in records:
        case = record.get("case")
        if case not in expected_fields or set(record) != expected_fields[case]:
            fail(f"unexpected record fields for case {case}: {sorted(set(record) ^ expected_fields.get(case, set()))}")
    expected_physical = {
        (item["size"], item["profile"], item["encoding"], digest, operation, pattern_id)
        for digest, matches in input_by_sha.items()
        for item in matches
        for operation in EXPECTED_OPERATIONS
        for pattern_id in EXPECTED_PATTERNS
    }
    seen_physical = set()
    physical_maps_by_input = {}
    physical_encoding_counts = Counter()
    direct_summary = defaultdict(lambda: {
        "records": 0, "records_with_calls": 0, "direct_kernel_calls": 0,
        "covered_rows": 0, "uncovered_rows": 0, "overlap_rows": 0,
    })
    all_owners_zero_records = 0
    direct_calls_total = 0
    direct_covered_rows_total = 0

    for record in physical_records:
        digest = record["input"]
        identity = (record.get("size"), record.get("profile"), record.get("encoding"))
        if identity not in input_by_identity or input_by_identity[identity]["input"]["sha256"] != digest:
            fail(f"physical record references an unknown input digest: {digest}")
        item = input_by_identity[identity]
        key = identity + (digest, record["operation"], record["pattern"])
        if key not in expected_physical or key in seen_physical:
            fail(f"unexpected or duplicate physical record key: {key}")
        seen_physical.add(key)
        ref_key = (item["size"], item["profile"], record["operation"], record["pattern"])
        ref = reference_by_key[ref_key]
        expected_bits = bit_string(ref["values"])
        if record["complete_shared_values"] != expected_bits:
            fail(f"physical shared bitstring mismatch: {key}")
        if record.get("complete_equal") is not True:
            fail(f"physical record does not mark shared comparison complete: {key}")
        if record.get("native_reservations_refunded") is not True:
            fail(f"physical record misses native reservation refund flag: {key}")
        if record.get("engine_timing") is not None:
            fail(f"physical record contains an engine timing observation: {key}")
        if not is_int(record.get("all_owners_dropped_reserved_bytes")) or record["all_owners_dropped_reserved_bytes"] != 0:
            fail(f"physical record has nonzero/invalid owner-drop reservation bytes: {key}")
        all_owners_zero_records += 1

        parts = record.get("direct_kernel_parts")
        calls = record.get("direct_kernel_calls")
        if not isinstance(parts, list) or not is_int(calls) or calls < 0 or calls != len(parts):
            fail(f"direct kernel call/part count mismatch: {key}")
        covered = [0] * len(expected_bits)
        for part in parts:
            start = part.get("start")
            bits = part.get("values")
            if not is_int(start) or start < 0 or not isinstance(bits, str):
                fail(f"invalid direct-kernel span metadata: {key}")
            if any(value not in "tfn" for value in bits):
                fail(f"invalid direct-kernel bitstring: {key}")
            end = start + len(bits)
            if end > len(expected_bits):
                fail(f"direct-kernel span exceeds reference length: {key}")
            if bits != expected_bits[start:end]:
                fail(f"direct-kernel span differs from matching reference slice: {key} [{start}:{end}]")
            for index in range(start, end):
                covered[index] += 1
        overlaps = sum(value > 1 for value in covered)
        if overlaps:
            fail(f"direct-kernel spans overlap at {overlaps} rows: {key}")
        covered_rows = sum(value == 1 for value in covered)
        uncovered_rows = len(covered) - covered_rows
        group_key = (item["encoding"], record["operation"], record["pattern"])
        group = direct_summary[group_key]
        group["records"] += 1
        group["records_with_calls"] += int(calls > 0)
        group["direct_kernel_calls"] += calls
        group["covered_rows"] += covered_rows
        group["uncovered_rows"] += uncovered_rows
        group["overlap_rows"] += overlaps
        direct_calls_total += calls
        direct_covered_rows_total += covered_rows

        physical_map = record.get("physical_input_batches")
        if not isinstance(physical_map, dict) or any(
            not isinstance(name, str) or not is_int(batch_count) or batch_count <= 0
            for name, batch_count in physical_map.items()
        ):
            fail(f"invalid physical_input_batches map: {key}")
        if identity in physical_maps_by_input and physical_maps_by_input[identity] != physical_map:
            fail(f"physical encoding/batch map changed across references for input {digest}")
        physical_maps_by_input[identity] = physical_map
        physical_encoding_counts[item["encoding"]] += 1
    if seen_physical != expected_physical:
        fail(f"physical record keyset incomplete: missing {len(expected_physical - seen_physical)}")

    expected_complete = set()
    for identity, item in input_by_identity.items():
        digest = item["input"]["sha256"]
        for (operation, pattern_id), consumers in CONSUMERS_BY_FILTER.items():
            for consumer in consumers:
                expected_complete.add(identity + (digest, operation, pattern_id, consumer))
    seen_complete = set()
    complete_summary = defaultdict(lambda: {
        "records": 0, "shared_variable_domains": 0, "shared_variable_domain_values": 0,
        "shared_variable_fsst_domains": 0, "shared_variable_fsst_domain_values": 0,
        "legacy_fsst_like_calls": 0, "legacy_fsst_like_rows": 0,
        "legacy_call_records": 0,
    })
    schema_variants = defaultdict(Counter)
    provider_variants = Counter()
    certificate_variants = defaultdict(Counter)
    complete_output_rows = 0
    complete_reference_equalities = 0
    expected_schemas = {
        "project": {"Struct": [{"names": ["matched"], "dtypes": [{"Bool": True}]}, False]},
        "filter": {"Struct": [{"names": ["row_id"], "dtypes": [{"Primitive": ["i64", False]}]}, False]},
        "legacy_scan": {"Struct": [{"names": ["row_id"], "dtypes": [{"Primitive": ["i64", False]}]}, False]},
        "count": {"Struct": [{"names": ["rows"], "dtypes": [{"Primitive": ["u64", False]}]}, False]},
    }

    for record in complete_records:
        digest = record["input"]
        identity = (record.get("size"), record.get("profile"), record.get("encoding"))
        if identity not in input_by_identity or input_by_identity[identity]["input"]["sha256"] != digest:
            fail(f"complete route record references an unknown input digest: {digest}")
        item = input_by_identity[identity]
        key = identity + (digest, record["operation"], record["pattern"], record["consumer"])
        if key not in expected_complete or key in seen_complete:
            fail(f"unexpected or duplicate complete route key: {key}")
        seen_complete.add(key)
        if record.get("complete_equal") is not True:
            fail(f"complete route record does not mark equality: {key}")
        if record.get("provider") != "native_operator_pipeline" or record.get("fallback_attempted") is not False:
            fail(f"complete route provider/fallback fields mismatch: {key}")
        certificate = record.get("native_io_certificate")
        if not isinstance(certificate, dict) or certificate.get("fallback_attempted") is not False:
            fail(f"native I/O certificate fallback flag mismatch: {key}")
        scalar_count = record["consumer"] == "count" and record["operation"] == "contains"
        for name, expected in (
            ("schema_version", "shardloom.native_io_certificate.v1"),
            ("certificate_id", "cg19.local_primitive.count_where.native_io" if scalar_count else "native_relational.execution.v1"),
            ("path_id", "native_vortex_source_to_scalar_count_result" if scalar_count else "native_vortex_sources_to_relational_batches"),
        ):
            if certificate.get(name) != expected:
                fail(f"native I/O certificate identity mismatch: {key}: {name}")
        if not same_json_exact(json.loads(record["actual_schema"]), expected_schemas[record["consumer"]]):
            fail(f"complete route schema differs from declared schema: {key}")
        schema_variants[record["consumer"]][record["actual_schema"]] += 1
        provider_variants[record["provider"]] += 1
        for field in ("schema_version", "certificate_id", "path_id"):
            certificate_variants[field][certificate.get(field)] += 1

        ref_key = (item["size"], item["profile"], record["operation"], record["pattern"])
        ref = reference_by_key[ref_key]
        values = ref["values"]
        rows = populations[(item["size"], item["profile"])]
        actual = record.get("actual")
        if not isinstance(actual, dict):
            fail(f"complete route actual payload is not an object: {key}")
        if record["consumer"] == "project":
            expected_actual = {"boolean_cells": bit_string(values)}
            expected_output_rows = len(values)
        elif record["consumer"] == "count":
            expected_count = sum(value is True for value in values)
            expected_actual = {"rows": [{"rows": expected_count}]}
            expected_output_rows = 1
        else:
            expected_ids = [row["row_id"] for row, value in zip(rows, values) if value is True]
            expected_actual = {"rows": [{"row_id": row_id} for row_id in expected_ids]}
            expected_output_rows = len(expected_ids)
        if not same_json_exact(actual, expected_actual):
            fail(f"complete route output differs from frozen reference: {key}")
        if record.get("output_rows") != expected_output_rows:
            fail(f"complete route output_rows mismatch: {key}")
        complete_output_rows += expected_output_rows
        complete_reference_equalities += 1

        group = complete_summary[item["encoding"]]
        group["records"] += 1
        for field, target in (
            ("variable_domains", "shared_variable_domains"),
            ("variable_domain_values", "shared_variable_domain_values"),
            ("variable_fsst_domains", "shared_variable_fsst_domains"),
            ("variable_fsst_domain_values", "shared_variable_fsst_domain_values"),
            ("legacy_fsst_like_calls", "legacy_fsst_like_calls"),
            ("legacy_fsst_like_rows", "legacy_fsst_like_rows"),
        ):
            value = record.get(field)
            if not is_int(value) or value < 0:
                fail(f"invalid observed metric {field}: {key}")
            group[target] += value
        group["legacy_call_records"] += int(record["legacy_fsst_like_calls"] > 0)

    if seen_complete != expected_complete:
        fail(f"complete route keyset incomplete: missing {len(expected_complete - seen_complete)}")

    dispatch_totals = defaultdict(Counter)
    dispatch_seen = set()
    dispatch_fields = ("successful_calls", "logical_operand_rows", "eligible_contains_calls", "prefilter_calls",
                       "prefilter_rows", "rejected_rows", "exact_rows", "matcher_constructions", "block_rejections")
    for index, record in enumerate(records):
        if record["case"] != "upstream_like_dispatch":
            continue
        key = tuple(record[field] for field in ("size", "profile", "encoding", "input", "operation", "pattern", "consumer"))
        if not args.expect_dispatch or key not in expected_complete or key in dispatch_seen:
            fail(f"unexpected or duplicate dispatch key: {key}")
        dispatch_seen.add(key)
        if index < 2 or records[index-1]["case"] != "complete_request_refund" or records[index-2]["case"] != "complete_file_request":
            fail(f"dispatch record lacks its adjacent completed request: {key}")
        if key != tuple(records[index-2][field] for field in ("size", "profile", "encoding", "input", "operation", "pattern", "consumer")):
            fail(f"dispatch key differs from adjacent request: {key}")
        if record["overflowed"] is not False or record["engine_timing"] is not None:
            fail(f"invalid dispatch scope or clock: {key}")
        if any(not is_int(record[field]) or record[field] < 0 for field in dispatch_fields):
            fail(f"invalid dispatch counter: {key}")
        calls, rows = record["successful_calls"], record["logical_operand_rows"]
        if not 0 <= record["prefilter_calls"] <= record["eligible_contains_calls"] <= calls:
            fail(f"invalid dispatch admission counts: {key}")
        if not 0 <= record["rejected_rows"] <= record["prefilter_rows"] <= rows:
            fail(f"invalid dispatch row counts: {key}")
        if record["exact_rows"] + record["rejected_rows"] != rows:
            fail(f"exact/rejected rows do not partition the selected nonempty patterns: {key}")
        if record["matcher_constructions"] + record["block_rejections"] != calls or record["block_rejections"] > record["prefilter_calls"]:
            fail(f"construction/rejection counts do not partition selected calls: {key}")
        if record["encoding"] != "fsst" or record["consumer"] == "project" or record["operation"] == "startswith":
            if calls or rows:
                fail(f"unexpected FSST activation in a route control: {key}")
        elif record["eligible_contains_calls"] != calls:
            fail(f"positive contains call absent from eligibility count: {key}")
        group = (record["size"], record["profile"], record["encoding"], record["operation"], record["consumer"])
        dispatch_totals[group].update({field: record[field] for field in dispatch_fields})
    if args.expect_dispatch and dispatch_seen != expected_complete:
        fail("upstream dispatch keyset incomplete")

    expected_refunds = Counter(
        (item["input"]["sha256"], operation, pattern_id, consumer)
        for item in input_by_identity.values()
        for (operation, pattern_id), consumers in CONSUMERS_BY_FILTER.items()
        for consumer in consumers
    )
    seen_refunds = Counter()
    for record in refund_records:
        key = (record.get("input"), record.get("operation"), record.get("pattern"), record.get("consumer"))
        if key not in expected_refunds or seen_refunds[key] >= expected_refunds[key]:
            fail(f"unexpected or duplicate refund record key: {key}")
        seen_refunds[key] += 1
        if not is_int(record.get("all_owners_dropped_reserved_bytes")) or record["all_owners_dropped_reserved_bytes"] != 0:
            fail(f"refund record has nonzero/invalid all-owner reserved bytes: {key}")
        for field in ("prepared_reserved_before", "prepared_reserved_after_result_drop"):
            if not is_int(record.get(field)) or record[field] < 0:
                fail(f"invalid refund observation {field}: {key}")
        all_owners_zero_records += 1
    if seen_refunds != expected_refunds:
        fail("refund key multiset incomplete")
    # Original records carry only the content digest on refunds. Equal-content
    # inputs can share it, so bind every refund to its adjacent full request.
    for index, record in enumerate(records):
        if record["case"] != "complete_file_request":
            continue
        if index + 1 == len(records) or records[index + 1]["case"] != "complete_request_refund":
            fail("complete request lacks its adjacent refund record")
        refund = records[index + 1]
        for field in ("input", "operation", "pattern", "consumer"):
            if record[field] != refund[field]:
                fail(f"adjacent request/refund identity mismatch: {field}")

    completion = completion_records[0]
    expected_completion = {
        "case": "existing_input_completion",
        "inputs": 54,
        "physical_shared_declarations": 864,
        "complete_public_core_requests": 378,
        "engine_timing": None,
    }
    if completion != expected_completion:
        fail(f"completion record differs from expected counters: {completion}")

    guard_checks = {
        "status_passed": guard.get("status") == "passed",
        "returncode_zero": guard.get("returncode") == 0,
        "sources_unchanged": guard.get("sources_unchanged") is True,
        "process_group_drained": guard.get("process_group_drained") is True,
        "direct_child_reaped": guard.get("direct_child_reaped") is True,
        "not_timed_out": guard.get("timed_out") is False,
        "no_interrupted_signal": guard.get("interrupted_signal") is None,
        "group_absence_proved": guard.get("group_absence_unproved_at_cleanup") is False,
        "stdout_within_limit": is_int(guard.get("output_bytes")) and is_int(guard.get("output_limit_bytes")) and guard["output_bytes"] <= guard["output_limit_bytes"],
    }
    if not all(guard_checks.values()):
        fail(f"diagnostic execution guard did not pass all checks: {guard_checks}")
    if guard.get("cwd") != str(args.source_root.resolve()):
        fail("guard working directory differs from explicit source root")
    if guard.get("head") != args.expected_head:
        fail("guard HEAD differs from explicitly expected source revision")

    checked_sources = []
    source_files = guard.get("source_files", {})
    for source_arg in args.rust_source:
        relative = Path(source_arg)
        if relative.is_absolute() or ".." in relative.parts:
            fail(f"Rust source must be a safe relative path: {source_arg}")
        key = relative.as_posix()
        if key not in source_files:
            fail(f"execution guard lacks source identity for Rust file: {key}")
        actual_path = args.source_root / relative
        expected_identity = source_files[key]
        if not actual_path.is_file() or actual_path.stat().st_size != expected_identity.get("bytes"):
            fail(f"current Rust source size/presence differs from execution guard: {key}")
        actual_hash = sha256_file(actual_path)
        if actual_hash != expected_identity.get("sha256"):
            fail(f"current Rust source SHA-256 differs from execution guard: {key}")
        checked_sources.append({"path": key, "bytes": actual_path.stat().st_size, "sha256": actual_hash})
    if not checked_sources:
        fail("no Rust source files were supplied for execution-guard source verification")

    physical_batch_maps = defaultdict(Counter)
    for identity, physical_map in physical_maps_by_input.items():
        item = input_by_identity[identity]
        physical_batch_maps[item["encoding"]][json.dumps(physical_map, sort_keys=True)] += 1
    direct_admission_summary = []
    for (encoding, operation, pattern_id), summary in sorted(direct_summary.items()):
        direct_admission_summary.append({
            "input_encoding": encoding,
            "operation": operation,
            "pattern_id": pattern_id,
            "input_pattern_records": summary["records"],
            "records_with_observed_direct_calls": summary["records_with_calls"],
            "observed_direct_kernel_calls": summary["direct_kernel_calls"],
            "verified_direct_covered_rows": summary["covered_rows"],
            "uncovered_rows_without_direct_result": summary["uncovered_rows"],
            "overlap_rows": summary["overlap_rows"],
        })

    variable_by_encoding = []
    for encoding in ENCODINGS:
        variable_by_encoding.append({
            "input_encoding": encoding,
            **complete_summary[encoding],
        })
    report = {
        "schema": "shardloom.native-fsst-consumer.existing-input-validation.v1",
        "status": "passed",
        "inputs": {
            "freeze_manifest": str(freeze_path),
            "freeze_manifest_sha256": sha256_file(freeze_path),
            "reference_gzip": str(reference_path),
            "reference_gzip_sha256": sha256_bytes(compressed),
            "reference_json_sha256": sha256_bytes(reference_bytes),
            "diagnostic_jsonl_gzip": str(record_path),
            "diagnostic_jsonl_gzip_sha256": sha256_file(record_path),
            "execution_guard": str(guard_path),
            "execution_guard_sha256": sha256_file(guard_path),
            "population_oracle_sha256": oracle_meta["sha256"],
        },
        "prior_attempts_preserved": [
            {
                "path": str(path),
                "sha256": sha256_file(path),
                "status": load_json(path).get("status"),
                "error": load_json(path).get("error"),
            }
            for path in args.prior_attempt
        ],
        "execution_guard": {
            "head": guard["head"],
            "source_tree": guard["source_tree"],
            "status": guard["status"],
            "returncode": guard["returncode"],
            "sources_unchanged": guard["sources_unchanged"],
            "process_group_drained": guard["process_group_drained"],
            "direct_child_reaped": guard["direct_child_reaped"],
            "timed_out": guard["timed_out"],
            "guard_sha256": guard["guard_sha256"],
            "relevant_rust_sources": checked_sources,
            "checks": guard_checks,
        },
        "record_counts": {
            "total": len(records),
            **dict(counts),
        },
        "keyset_validation": {
            "physical_expected": len(expected_physical),
            "physical_observed_unique": len(seen_physical),
            "complete_expected": len(expected_complete),
            "complete_observed_unique": len(seen_complete),
            "refund_expected_records": sum(expected_refunds.values()),
            "refund_observed_records": sum(seen_refunds.values()),
            "refund_distinct_sha_key_count": len(expected_refunds),
            "unexpected_cases": [],
            "unexpected_records": 0,
        },
        "frozen_references": {
            "vectors": len(references),
            "rows_across_vectors": vector_cell_count,
            "null_cells": null_cell_count,
            "true_cells": true_cell_count,
            "false_cells": false_cell_count,
            "null_counts_by_vector": ref_counts,
            "population_count": len(populations),
            "independent_population_semantics_rechecked": True,
        },
        "physical_file_consumer_observations": {
            "raw_physical_records": len(physical_records),
            "input_encodings": dict(sorted(physical_encoding_counts.items())),
            "physical_input_batch_maps_by_input_encoding": {
                encoding: [
                    {"observed_map": json.loads(map_text), "distinct_inputs": n}
                    for map_text, n in sorted(counters.items())
                ]
                for encoding, counters in sorted(physical_batch_maps.items())
            },
            "direct_kernel_calls_total": direct_calls_total,
            "verified_direct_covered_rows_total": direct_covered_rows_total,
            "direct_call_admission_by_input_encoding_operation_pattern": direct_admission_summary,
            "direct_span_overlap_rows": 0,
            "span_gaps_reported_per_group_as_uncovered_rows": True,
            "complete_shared_bitstrings_independently_equal_reference": True,
        },
        "complete_public_route_observations": {
            "complete_file_request_records": len(complete_records),
            "independent_complete_output_equalities": complete_reference_equalities,
            "checked_output_rows_sum_across_requests": complete_output_rows,
            "all_owner_drop_zero_records": all_owners_zero_records,
            "provider_variants": dict(provider_variants),
            "schema_variants_by_consumer_exact_observed_strings": {
                consumer: dict(schema_counts) for consumer, schema_counts in sorted(schema_variants.items())
            },
            "schema_strings_parsed_and_checked_against_declared_types": True,
            "certificate_variants_exact_observed_strings": {
                field: dict(values) for field, values in sorted(certificate_variants.items())
            },
            "shared_variable_domain_and_legacy_metrics_by_input_encoding": variable_by_encoding,
            "no_fallback_flags_verified_false": True,
            "route_observations_kept_separate_from_raw_physical_observations": True,
        },
        "completion_record": completion,
        "upstream_dispatch": {
            "records": len(dispatch_seen),
            "scope": "debug_only_untimed_logical_work_not_release_performance_counters",
            "groups": [{"key": list(key), **dict(value)} for key, value in sorted(dispatch_totals.items())],
            "totals": dict(sum(dispatch_totals.values(), Counter())),
        },
    }
    return report


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--freeze-manifest", required=True, type=Path)
    parser.add_argument("--reference-gzip", required=True, type=Path)
    parser.add_argument("--records-gzip", required=True, type=Path)
    parser.add_argument("--guard-json", required=True, type=Path)
    parser.add_argument("--population-oracle", required=True, type=Path)
    parser.add_argument("--source-root", required=True, type=Path)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--rust-source", required=True, action="append",
                        help="Relevant Rust path relative to --source-root; repeat as needed")
    parser.add_argument("--prior-attempt", action="append", type=Path, default=[],
                        help="Previously preserved validation outcome; read-only")
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--expect-dispatch", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.output.exists():
        print(f"ERROR: refusing to overwrite {args.output}", file=sys.stderr)
        return 2
    try:
        report = validate(args)
    except Exception as error:
        report = {
            "schema": "shardloom.native-fsst-consumer.existing-input-validation.v1",
            "status": "needs_reasoning",
            "error_type": type(error).__name__,
            "error": str(error),
        }
        try:
            with args.output.open("x", encoding="utf-8") as stream:
                json.dump(report, stream, ensure_ascii=False, sort_keys=True, indent=2)
                stream.write("\n")
                stream.flush()
                os.fsync(stream.fileno())
        except FileExistsError:
            print(f"ERROR: refusing to overwrite {args.output}", file=sys.stderr)
            return 2
        print(json.dumps(report, ensure_ascii=False, sort_keys=True), file=sys.stderr)
        return 1
    try:
        with args.output.open("x", encoding="utf-8") as stream:
            json.dump(report, stream, ensure_ascii=False, sort_keys=True, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
    except FileExistsError:
        print(f"ERROR: refusing to overwrite {args.output}", file=sys.stderr)
        return 2
    print(json.dumps({
        "status": report["status"],
        "record_counts": report["record_counts"],
        "reference_vectors": report["frozen_references"]["vectors"],
        "direct_calls": report["physical_file_consumer_observations"]["direct_kernel_calls_total"],
        "result": str(args.output),
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
