"""Replace verified duplicate checkout evidence with independent APFS clones."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess

OUT = Path(__file__).resolve().parent
SOURCE = Path('/Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree')
TARGET = Path('/Users/dylan/LocalData/shardloom/native-fsst-prefilter-slice-worktree')
PREFIXES = ('docs/benchmarks/evidence/', 'docs/release/evidence/', 'docs/dependencies/evidence/')

def generation(path):
    value = path.lstat()
    assert stat.S_ISREG(value.st_mode) and value.st_nlink == 1, path
    return [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns,
            value.st_ctime_ns, value.st_mode, value.st_nlink]

def identity(path):
    before = generation(path)
    sha = hashlib.sha256()
    blob = hashlib.sha1(f'blob {before[2]}\0'.encode())
    with path.open('rb') as source:
        while data := source.read(4 << 20):
            sha.update(data)
            blob.update(data)
    assert generation(path) == before
    return dict(generation=before, bytes=before[2], sha256=sha.hexdigest(), blob=blob.hexdigest())

def idle():
    for root in (SOURCE, TARGET):
        for prefix in PREFIXES:
            result = subprocess.run(['/usr/sbin/lsof', '-nP', '+D', str(root / prefix)],
                                    capture_output=True, text=True, timeout=60)
            assert result.returncode == 1 and not result.stdout and not result.stderr, result

def main():
    receipt = OUT / 'checkout-evidence-clones-r1.json'
    assert __debug__ and not receipt.exists()
    assert SOURCE.resolve() == SOURCE and TARGET.resolve() == TARGET
    stage = subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=TARGET).decode()
    tracked = {}
    for item in stage.split('\0'):
        if item:
            meta, name = item.split('\t', 1)
            mode, blob, stage_number = meta.split()
            assert stage_number == '0'
            if name.startswith(PREFIXES) and (TARGET / name).stat().st_size >= 4 << 20:
                assert mode == '100644'
                tracked[name] = blob
    assert tracked
    idle()
    records = []
    for name, blob in sorted(tracked.items()):
        source, target = identity(SOURCE / name), identity(TARGET / name)
        assert source['blob'] == target['blob'] == blob, name
        assert source['sha256'] == target['sha256'] and source['bytes'] == target['bytes']
        records.append(dict(path=name, source=source, target=target))
    (OUT / 'checkout-evidence-clone-inventory-r1.json').write_text(json.dumps(records, indent=2) + '\n')
    idle()
    for row in records:
        assert identity(SOURCE / row['path']) == row['source']
        assert identity(TARGET / row['path']) == row['target']
    idle()
    library = ctypes.CDLL(None, use_errno=True)
    clone = library.clonefile
    clone.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_int]
    clone.restype = ctypes.c_int
    before_free = shutil.disk_usage(OUT).free
    completed = []
    journal = OUT / 'checkout-evidence-clones-r1.jsonl'
    with journal.open('x') as log:
        for row in records:
            source, target = SOURCE / row['path'], TARGET / row['path']
            assert generation(source) == row['source']['generation']
            assert generation(target) == row['target']['generation']
            temporary = target.with_name(target.name + '.codex-clone-tmp')
            assert not temporary.exists()
            if clone(os.fsencode(source), os.fsencode(temporary), 0) != 0:
                raise OSError(ctypes.get_errno(), str(target))
            copied = identity(temporary)
            assert copied['sha256'] == row['source']['sha256']
            assert copied['blob'] == row['source']['blob']
            assert generation(source) == row['source']['generation']
            assert generation(target) == row['target']['generation']
            os.replace(temporary, target)
            saved = dict(path=row['path'], clone=identity(target))
            assert saved['clone']['sha256'] == row['source']['sha256']
            log.write(json.dumps(saved) + '\n')
            log.flush()
            completed.append(saved)
    for row in records:
        assert identity(SOURCE / row['path']) == row['source']
    result = dict(status='passed', operation='replace_duplicate_tracked_evidence_with_apfs_clones',
        source=str(SOURCE), target=str(TARGET), files=len(records),
        logical_bytes=sum(row['source']['bytes'] for row in records),
        repeated_source_and_target_inventory=True, closed_handle_checks=3,
        source_files_unchanged=True, independent_file_inodes=True,
        copied_bytes_match_git_blobs=True, before_free_bytes=before_free,
        after_free_bytes=shutil.disk_usage(OUT).free, storage_floor_bytes=12 << 30,
        benchmark_inputs_touched=False, runtime_artifacts_touched=False,
        query_executions=0, completed=completed,
        helper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    receipt.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ('status', 'files', 'logical_bytes', 'source_files_unchanged')}))

if __name__ == '__main__':
    main()
