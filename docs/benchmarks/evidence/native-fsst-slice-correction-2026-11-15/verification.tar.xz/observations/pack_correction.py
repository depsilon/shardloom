"""Preserve source-bound correction checks without revising historical timings."""
import hashlib
import inspect
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

import guard_checks as guard

ROOT, OUT = guard.ROOT, guard.OUT
BASE = '7c34815a0d99eb53afff7e11432682c096ad12cf'
PACKET = ROOT / 'docs/benchmarks/evidence/native-fsst-slice-correction-2026-11-15'
FREEZE = Path('/Users/dylan/LocalData/shardloom/native-fsst-consumer-2026-11-15/input-freeze-r1')
CHECKS = [
    'slice-provider-lint-r2', 'slice-provider-tests-r3', 'slice-format-r1',
    'slice-default-lint-r1', 'slice-default-tests-r1',
    'slice-native-lint-r1', 'slice-native-tests-r1', 'slice-existing-r1',
    'slice-existing-validation-r1',
]
RUST_SOURCES = [
    'vendor/vortex-fsst/src/compute/like.rs',
    'vendor/vortex-fsst/src/compute/like_slice_tests.rs',
    'vendor/vortex-fsst/src/dfa/mod.rs',
    'vendor/vortex-fsst/src/dfa/prefilter.rs',
    'vendor/vortex-fsst/src/like_observation.rs',
]

def identity(data):
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def load(name):
    return json.loads((OUT / name).read_bytes())

def test_totals(log):
    matches = re.findall(
        r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; '
        r'(\d+) measured; (\d+) filtered out;', log, flags=re.M)
    assert matches
    totals = [sum(int(row[i]) for row in matches) for i in range(5)]
    assert totals[1] == totals[3] == 0
    return dict(zip(('passed', 'failed', 'ignored', 'measured', 'filtered'), totals))

def main():
    assert __debug__ and not PACKET.exists()
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
    sources = guard.sources()
    guard_identity = identity(Path(guard.__file__).read_bytes())
    checks = {}
    for name in CHECKS:
        receipt = load(name + '.json')
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0, name
        assert receipt['sources_unchanged'] and receipt['process_group_drained'] and receipt['direct_child_reaped'], name
        assert not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup'], name
        assert receipt['source_files'] == sources and receipt['head'] == BASE, name
        assert receipt['guard_sha256'] == guard_identity['sha256'], name
        log = (OUT / 'logs' / (name + '.log')).read_text()
        entry = dict(command=receipt['command'], receipt=identity((OUT / (name + '.json')).read_bytes()),
                     log=identity((OUT / 'logs' / (name + '.log')).read_bytes()))
        if ' test ' in ' ' + ' '.join(receipt['command']) + ' ':
            entry['tests'] = test_totals(log)
        checks[name] = entry
    assert checks['slice-provider-tests-r3']['tests'] == dict(passed=115, failed=0, ignored=1, measured=0, filtered=0)
    assert checks['slice-default-tests-r1']['tests']['passed'] == 3344
    assert checks['slice-default-tests-r1']['tests']['ignored'] == 0
    assert checks['slice-native-tests-r1']['tests']['passed'] == 7266
    assert checks['slice-native-tests-r1']['tests']['ignored'] == 41
    assert checks['slice-existing-r1']['tests']['passed'] == 1
    validation = load('validate-slice-existing-r1.json')
    assert validation['status'] == 'passed'
    assert validation['record_counts']['total'] == 1999
    assert validation['frozen_references']['vectors'] == 288
    assert validation['keyset_validation']['complete_observed_unique'] == 378
    assert validation['keyset_validation']['physical_observed_unique'] == 864
    assert validation['frozen_references']['independent_population_semantics_rechecked']
    assert validation['inputs']['execution_guard_sha256'] == checks['slice-existing-r1']['receipt']['sha256']
    before = load('slice-regression-before-r4.json')
    log = (OUT / 'logs/slice-regression-before-r4.log').read_text()
    assert before['status'] == 'failed' and before['returncode'] == 101
    assert before['sources_unchanged'] and before['process_group_drained'] and before['direct_child_reaped']
    assert '0 passed; 1 failed; 0 ignored' in log and 'left: 0\n right: 1' in log
    original = OUT / 'before-fix-source-r1'
    for name in ('vendor/vortex-fsst/src/compute/like.rs', 'vendor/vortex-fsst/src/dfa/mod.rs'):
        captured = (original / name).read_bytes()
        assert identity(captured) == before['source_files'][name]
        base_bytes = subprocess.check_output(['git', 'show', BASE + ':' + name], cwd=ROOT)
        if name.endswith('/like.rs'):
            captured = captured.split(b'\n#[cfg(all(test, debug_assertions))]')[0].rstrip() + b'\n'
        assert captured == base_bytes, name
    clone = load('checkout-evidence-clones-r1.json')
    assert clone['status'] == 'passed' and clone['source_files_unchanged']
    assert clone['copied_bytes_match_git_blobs'] and clone['independent_file_inodes']

    original_packets = {}
    for name in ('native-fsst-consumer-2026-11-15', 'native-fsst-publication-2026-11-15'):
        prefix = 'docs/benchmarks/evidence/' + name
        subprocess.run(['git', 'diff', '--exit-code', BASE, '--', prefix], cwd=ROOT, check=True)
        original_packets[name] = identity((ROOT / prefix / 'manifest.json').read_bytes())

    members = {}
    for path in sorted(OUT.rglob('*')):
        if path.is_file():
            assert not path.is_symlink()
            name = path.relative_to(OUT).as_posix()
            assert path.stat().st_size < 32 << 20
            members['observations/' + name] = path.read_bytes()
    changed = subprocess.check_output(['git', 'diff', '--name-only', '-z'], cwd=ROOT).decode().split('\0')
    changed += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=ROOT).decode().split('\0')
    changed = sorted(set(changed) - {''})
    assert set(RUST_SOURCES).issubset(changed)
    for name in changed + ['vendor/vortex-fsst/Cargo.lock']:
        members['corrected-source/' + name] = (ROOT / name).read_bytes()
    for name in ('manifest.json', 'boolean-references-v1.json.gz', 'native_text_signature_cases.py'):
        members['frozen-references/' + name] = (FREEZE / name).read_bytes()
    for name, path in {
        'bounded-supervisor.py': Path(guard.supervisor.__file__),
        'local_uat_storage.py': ROOT / 'scripts/local_uat_storage.py',
        'release_validation_guard.py': Path(inspect.getfile(guard.WorkloadGuard)),
    }.items():
        members['guard-dependencies/' + name] = path.read_bytes()
    assert sum(map(len, members.values())) < 100 << 20

    record = dict(schema='shardloom.native_fsst_slice_correction.v1', status='passed',
        base_revision=BASE, review_comment='https://github.com/depsilon/shardloom/pull/1692#discussion_r4579321661',
        original_defect_reproduced=True, original_defect_test='slice-regression-before-r4',
        source_files={name: sources[name] for name in changed},
        source_fingerprint_sha256=hashlib.sha256(json.dumps(sources, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
        all_passing_checks_share_source_inventory=True, checks=checks,
        diagnostic_record_counts=validation['record_counts'],
        diagnostic_keysets=validation['keyset_validation'],
        independent_nullable_reference_vectors=288, existing_inputs=54,
        diagnostic_dispatch=validation['upstream_dispatch']['totals'],
        added_scored_performance_observations=0, historical_runtime_remeasured=False,
        original_performance_packet_manifests=original_packets,
        original_performance_packets_unchanged=True,
        storage_copy_verification=dict(files=clone['files'], logical_bytes=clone['logical_bytes'],
            source_files_unchanged=True, independent_file_inodes=True, floor_changed=False),
        preserved_failed_attempts=[p.stem for p in sorted(OUT.glob('slice-*.json'))
            if json.loads(p.read_bytes()).get('status') not in ('passed',)],
        archive_members={name: identity(data) for name, data in sorted(members.items())})
    guard.check_budgets(OUT, OUT / 'reserved-artifact', OUT / 'logs',
        min_free_bytes=12 * guard.GIB, reserve_bytes=128 * guard.MIB,
        max_workspace_bytes=100 * guard.GIB, max_log_bytes=192 * guard.MIB)
    PACKET.mkdir()
    archive = PACKET / 'verification.tar.xz'
    with tarfile.open(archive, 'w:xz', preset=6) as bundle:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mtime, info.mode = len(data), 0, 0o644
            bundle.addfile(info, io.BytesIO(data))
    with tarfile.open(archive, 'r:xz') as bundle:
        actual = {}
        for member in bundle:
            assert member.isfile() and member.name not in actual
            actual[member.name] = identity(bundle.extractfile(member).read())
        assert actual == record['archive_members']
    record['archive'] = dict(path=archive.name, **identity(archive.read_bytes()))
    (PACKET / 'verification.json').write_text(json.dumps(record, indent=2) + '\n')
    assert guard.sources() == sources
    print(json.dumps(dict(status='passed', source_files=len(changed), archived_files=len(members),
        provider_tests=115, default_tests=3344, native_tests=7266,
        diagnostic_records=1999, added_scored_performance_observations=0)))

if __name__ == '__main__':
    main()
