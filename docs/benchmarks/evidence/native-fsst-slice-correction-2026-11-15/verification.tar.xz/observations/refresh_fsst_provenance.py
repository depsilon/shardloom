"""Refresh exact local FSST patch identities without changing original provenance."""
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path('/Users/dylan/LocalData/shardloom/native-fsst-prefilter-slice-worktree')
provider = ROOT / 'vendor/vortex-fsst'
path = provider / 'upstream-provenance.json'
record = json.loads(path.read_text())
original = dict(record['original_files_sha256'])
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
modified = {}
for name, expected in original.items():
    if name in record['omitted_files']:
        continue
    actual = sha(provider / name)
    if actual != expected:
        modified[name] = actual
record['modified_files_sha256'] = modified
for name in sorted(set(record['added_files_sha256']) | {
    'src/like_observation.rs', 'src/dfa/prefilter.rs',
    'src/compute/like_slice_tests.rs',
}):
    record['added_files_sha256'][name] = sha(provider / name)
record['local_changes_documentation']['sha256'] = sha(provider / 'README.shardloom.md')
assert record['original_files_sha256'] == original
path.write_text(json.dumps(record, indent=2) + '\n')

spec = importlib.util.spec_from_file_location('license_bundle', ROOT / 'scripts/check_python_license_bundle.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
bundle = ROOT / 'python/THIRD_PARTY_LICENSES/manifest.json'
manifest = json.loads(bundle.read_text())
updated = module.vendored_components(ROOT)
before = {item['name']: item for item in manifest['vendored_components']}
assert all(item == before[item['name']] for item in updated if item['name'] != 'vortex-fsst')
manifest['vendored_components'] = updated
bundle.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')
print(json.dumps(module.verify(ROOT), sort_keys=True))
