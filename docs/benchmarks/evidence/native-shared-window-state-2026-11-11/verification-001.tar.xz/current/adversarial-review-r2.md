# Compatible-window review after the fixed candidate result

November 11, 2026. This supplements the historical pre-release r1 review; r1 is
unchanged. The runtime source fingerprint remains
`51e9a408564dd45e5507782727348da0204a05142a6cc1d28647abb83ea9285a`.
The only repository changes after full validation and scoring are the five
named architecture/status documents admitted by the portable verifier.

The three principal review questions remain compatibility, observable failure
order, and ownership/cancellation. Direct review of the final dispatcher,
identity predicate, State methods and moments wrapper agrees with r1: only
contiguous admitted functions share; the primary keeps its ordinary numerical
updates; companions borrow finalizers; an error retains only its earliest
member index; the shared owner drops before the ordinary suffix is evaluated.
No numerical algorithm, input/output owner, dependency or external executor is
added. All initial output allocation and stored/spilled scheduling remain.
There is no unresolved source objection in this bounded implementation.

The final source passes format, both strict workspace lint configurations,
3,323 default and 7,092 native tests, 183 focused window tests and the separate
33-request attribution test. The frozen diagnostic comparator checks 16 calendar
and 18 error controls and rejects all 20 corruptions. The actual release-feature
test executable inventory binds 4,134 names, 35 opt-in ignores and four complete,
disjoint partitions. The fresh release runtime, library alias and fixed candidate
protocol are bound to those exact sources. All passed guards drain/reap their
children and preserve source, input and protected evidence identities.

The fixed candidate executes all 1,212 requests once with other task work idle.
Independent replay verifies every complete result, schema, native certificate,
submitted request and finite engine clock. Its engine sum is 299.797880547
against the explicit reused/new baseline sum 340.599417211; the frozen rule
retains it. All three family totals are lower. One observation per case does
not supply statistical confidence, CPU attribution or a causal gain for the
unchanged original controls. The original failed full10k observation remains
invalid. No new Full43/full10k claim or query repeat follows.

The portable collector/verifier now passes a full collection and semantic
preflight: 1,212 baseline plus 1,212 candidate saved results, including 188
reused raw observations with their original non-contiguous source ordinals.
The original 65-file harness, three separately admitted support imports,
composition declarations and frozen result comparator are copied unchanged
into a relocated temporary tree. No native library or query is started. The
source closure preserves failed-check snapshots as well as passing ones.
An initially omitted cohort-planning source was found through its explicit
recorded path and admitted only after exact byte/hash equality; the failed
preflight receipt, log and earlier helper remain preserved. Documentation
checks and all documentation contract tests pass after the status updates.

The remaining acceptance operations are compressed-archive readback, both
positive portable controls, all 22 named corruption controls, hosted review/
checks, exact merge/main acceptance and verified final retirement. This review
does not claim those pending results. Archive/control receipts and subsequent
closeout evidence must establish them. Runtime/input payloads stay protected
through integration and are not duplicated as rollback archives. Recommendation
10 retains its independent allocated-storage objective.
