# Shared-window candidate: primary source review

November 11, 2026, before release construction or any candidate scored query.
The active checkout is `native-vector-representations/shardloom-local-repo`,
branch `codex/native-shared-window-state`, accepted base
`a640475ae66bc36cefcae42088dc23da6776e8ed`. The candidate build-input fingerprint is
`51e9a408564dd45e5507782727348da0204a05142a6cc1d28647abb83ea9285a`.
This review establishes no performance acceptance or hosted completion.

## Compatibility and numerical semantics

The dispatcher only extends the contiguous slice of the existing group's
function list. An incompatible frame or non-frame declaration ends the slice.
The caller preserves partition/group order, ranking/offset evaluation, later
fills and allocation of every requested output. The identity predicate requires
the same bound key and column, filter, complete frame, order/null direction,
exact offset variant/value and calendar kernel semantics. Only arithmetic-first
SUM/AVG with SUM/AVG/COUNT(value), or single-input moments, are eligible.
COUNT-first/star, DISTINCT, paired moments, quantiles and collections retain
their ordinary paths. Five private identity tests include deliberately close
matches that must remain separate.

Shared arithmetic calls the existing primary State::advance and existing pure
SUM/AVG finalizers. COUNT reads the primary float/decimal input owner's count;
its intentionally absent decimal output domain cannot select a different count
source. Moments expose the summary already constructed locally by the existing
cover traversal. The ordinary wrapper and cover merge/observation order remain
unchanged. State gains no retained field; diagnostics confirm unchanged state
and moment-owner sizes. Stored/spilled evaluation is unchanged.

## Failure precedence and ownership

Every row finalizes and writes the primary first. A companion failure retains
only its member index and immediately drops the diagnostic. Earlier companions
continue, so an earlier declaration's later failure supersedes a later one.
A primary failure returns first. After primary success, the shared state is
dropped before the original evaluator reprocesses the complete suffix from the
earliest failed member. If the anticipated error does not recur, that suffix
still completes rather than exposing partial values. Numeric outputs occupy
their existing fixed slots. Failure, cancellation and retry tests check that
publication does not occur and all credits are refunded.

Cancellation retains primary polling, adds a poll before shared work and checks
at most every 1,024 companion writes. The 2,049-output control cancels after the
first write and bounds extra writes before cancellation; it then verifies a
successful independent retry. No list of group members or retained error object
is allocated. Existing input, output and owner reservations remain authoritative.

## Proof and admission review

The final focused checks passed 183 tests and one separately executed attribution
test covering 33 complete requests. The frozen work comparator verifies those
requests plus 16 calendar and 18 resident/stored error observations; all 20
evidence corruptions are rejected. The three independent baseline result/error
test files remain byte-identical. These counters are debug-test-only and make no
timing or query-peak-memory claim.

Candidate release admission is separate from clean accepted-baseline admission.
It checks seven exact source-check commands, their full build-input identities,
the diagnostics report, actual release-feature CI test discovery, the fresh
release build, runtime copy and source/library bindings. The fixed protocol
retains all 1,212 cases, saved/new baseline provenance, original worker/reference
semantics, clock checks, limits and strict-lower-total decision. The replayer
checks ordered ledger cardinality, full requests/results, independent reference
identities, no fallback and finite engine clocks before deciding retain/drop.

The previous index packager inventory was verified against all five cited helper
hashes. Its source was checked directly: packet collection closes build/tool
source bytes; raw saved results are replayed; runtime payloads are identities
rather than duplicate rollback archives. Window packaging still needs its own
composition-reference and saved-index-reuse binding; an index packet must not
be relabeled as window proof.

## Remaining obligations at this review

The full native suite is in progress. Fresh release provenance, one isolated
fixed candidate pass, independent replay, portable source-bound evidence and
corruption controls remain. Final source review, documentation, hosted checks,
merge/main acceptance and verified artifact retirement remain separate. No
fixable source objection was found in the reviewed compatibility, error-order
or ownership paths. Recommendation 10 remains an independent storage objective.
