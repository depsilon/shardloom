# Pinned provider review for compatible window state

Preparation only, November 11, against PR #1678 head
`9aa5ded02f3b8205ccf4da04714e7ea252c77a59`. No runtime change or provider
admission has been made. The active workspace pins Vortex `=0.93.0`.

Subject: remove repeated resident frame movement and state updates across
compatible outputs while preserving the current ShardLoom numeric algorithms.

The pinned vendored `vortex-array/src/aggregate_fn` exposes native array
aggregation. `fns/sum_v2/mod.rs:64` provides `sum_v2`; its documented partial
tracks sum/overflow/empty, returning null on overflow and using configurable
NaN behavior. `fns/mean/mod.rs:41` provides `mean` through combined Sum/Count.
`accumulator.rs` exposes accumulation, partial merging and mutable finalization.
These are real Vortex-native providers; their existence must not be described
as an absence of upstream aggregation.

Those inspected interfaces do not establish equivalent ROWS/GROUPS/RANGE
movement, exclusions, calendar retreat, exact error order or the current
ShardLoom exact floating/decimal totals and aligned moments covers. In
particular, null-on-overflow and skipped-NaN defaults are not interchangeable
with ShardLoom's declared failure/observation policy. Replacing the numerical
algorithm or rescanning each moving frame would be a different experiment.

Decision for this proposed work: `implement_shardloom_kernel`, by sharing
existing ShardLoom frame owners. No new source, accumulator framework, encoding
or external executor is needed. Continue using the current Vortex-native
input/result owners and their validity, key, resource and certificate boundaries.
The candidate can share already-admitted observations; metadata alone cannot
produce every requested changing-frame output. Any existing source decoding or
materialization boundaries remain visible and unchanged.

The provider inventory searched `shardloom-vortex/src/**/*.rs` for direct
Vortex aggregate API imports/calls and inspected the vendored aggregate
interfaces above. This is a bounded source inspection, not a claim that every
upstream Vortex crate or future API lacks window-related facilities. The
primary verified the concrete SumV2, Mean, accumulator and current local State/
Ranges implementations before this classification; no upstream code is copied.

ShardLoom execution provider and Native I/O certificates remain authoritative.
Residual execution stays ShardLoom-native; `fallback_attempted=false` and
`external_engine_invoked=false`. Required evidence remains: exact compatibility
and ordered-error controls, unchanged one-output behavior and numerical
algorithms, actual removed frame/observation work, credited state/refunds,
independent complete-query baseline/candidate results and the complete engine
time decision. Paired moments, quantiles, spill-writer fusion, rolling DISTINCT,
item 19/item 20/RFC 0044 and CG-1 through CG-23 remain separate obligations.
