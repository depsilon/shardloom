# Compatible-window contract review and concrete regression packet

Preparation only, November 11, against index PR #1678 head
`9aa5ded02f3b8205ccf4da04714e7ea252c77a59`. The index PR is still awaiting hosted
acceptance. No window implementation, frozen scoring cohort, or query execution
is represented by this document. This supplements the error-suffix proposal;
it does not replace the original request or either earlier proposal.

Expert comparator: the maintainer responsible for deterministic numeric
semantics, credited state lifetimes and complete-query evidence. Required
scope is resident ordinary SUM/AVG with eligible COUNT companions and
single-input variance/standard deviation. Numerical algorithms, one-output
behavior, input/output owners and stored-function scheduling remain intact.

## Concrete source findings

- `native_relational_window.rs:349-359` evaluates frames in declaration order
  within each existing group and partition. The outer group/partition ordering
  must not change. `evaluate_frame` at 385-430 keeps each state's admission,
  cursor movement, observation, finalization and output write together.
- `Values::set_frame` at 648-674 performs fixed-size numeric writes. The
  collection branch allocates through another owner and is excluded. Successful
  numeric finalization has no external effects or persistent mutation:
  `native_float_total::Total::finish`, `native_decimal_reduce::Total::finish_with`
  and `shardloom-core/src/decimal_output.rs::DecimalOutput::total/finish` use
  local fixed-size arithmetic; errors allocate diagnostics but those must not
  be retained by sharing. Moments `Summary::finish` consumes a local Copy value.
- `native_relational_window_frame_bind.rs:70-84` intentionally sets the
  COUNT companion's `decimal` field to None even for a decimal input. Therefore
  literal equality of every Spec field is wrong. Identity comes from the same
  already-bound key in the same table/domain, matching filter and complete
  frame policy. Decimal COUNT must read the primary arithmetic owner's decimal
  observation count, not choose the unused floating totals from its own Spec.
- `native_float_total.rs:116` already maintains an exact count (currently
  test-only accessor); decimal Total has `count` at line 59. Neither allows
  COUNT-first numeric observation. COUNT(*) and standalone COUNT retain their
  original nullness/membership path. Arithmetic-first companions may share
  only after proving they cannot introduce eager validation or change errors.
- Calendar identity needs no new kernel abstraction. The existing
  `shardloom-core/src/temporal_operations.rs:240` `Kernel::same_semantics`
  compares bound operation, source, other and output metadata in the pinned
  timezone build. A frame comparison must also compare amount, bound variant,
  unit, exclusion, order key/direction/null ordering and exact offset domain.
  Float offsets should use a deliberate identity rule (bit identity is a safe
  conservative choice), never formatting/debug strings or approximate equality.
- Moments must reuse the existing aligned cover's merge/observation order.
  `Ranges::advance` currently constructs one local summary and immediately
  finalizes it. A shared path can expose that local value to several pure
  finalizers without storing another summary in State or changing State size.

## New required deterministic controls

The following are concrete fixtures to run on the accepted baseline first,
before candidate code. Record exact complete diagnostics, no emitted output,
completed-execution count and refund to the prepared baseline. Repeat through
the confirmed stored route where supported as a scheduling control, without
changing stored execution. Baseline observations must establish the actual
messages; descriptions below are semantic expectations, not captured results.

1. Growing ROWS frame, ordered ids, Float64 values `[MAX, MAX, NaN]`:
   declarations AVG then SUM. AVG can finish the first two values, SUM cannot;
   AVG's later selected nonfinite input must remain the returned error.
   Reverse declarations and require SUM's earlier result-overflow error.
   Also run finite `[MAX, MAX]` with AVG then SUM: after primary success,
   ordinary suffix evaluation must return SUM's error with all credits released.
2. Three decimal outputs over coefficients `[5,5,6]`, input decimal(2,0),
   growing ROWS frame: AVG output decimal(38,0)/half-even; AVG
   decimal(38,0)/exact; SUM decimal(1,0)/exact. The third output exceeds its
   precision at row 1, while the earlier second output becomes inexact at row
   2. Its exact-rounding error must replace the later member's earlier-row
   precision error. Reverse the second and third outputs as a distinct control.
   This uses the existing Aggregate Measure `with_decimal_output` surface;
   `local_primitive_relational_decimal_policy_tests.rs:128-197` demonstrates
   that surface on windows. No new public API is needed.
3. Single-input standard deviation before variance with large finite values
   whose standard deviation fits but variance does not; include a later selected
   nonfinite and reversed declarations. Establish exact fixture magnitudes and
   expected errors from the baseline, not candidate output. Preserve all
   observations if a proposed fixture does not distinguish the errors.
4. Successful nullable/all-null/empty and exclusion matrix with arithmetic
   first, compatible COUNT(value), COUNT(*) control and COUNT-first control.
   Include decimal counts and extended nonfinites. Assert every output dtype,
   null and value, plus independent membership-based expectations.
5. Near matches: different key, filter, ROWS bound, exclusion, order/null policy,
   and calendar policy. Interleave an incompatible framed function between
   otherwise matching outputs. A contiguous group cannot skip that function.
   Include non-frame ranking/fill boundaries and one-output paths.
6. Tight admission, cancellation, retry and actual spill: add shared-family
   coverage rather than treating the existing DISTINCT/correlation resource
   tests as proof of shared-family lifetimes. Require bounded cancellation in
   wide companion lists, zero published rows on evaluation error and unchanged
   stored scheduling/cleanup. Do not assert deterministic ordering of genuinely
   asynchronous cancellation arrivals relative to numeric errors.

The error-suffix proof obligation is an invariant: after each row, the cutoff
is the earliest declaration index among secondary members observed to fail;
only members before it need further shared finalization. A later failure in an
earlier member lowers the cutoff. Primary failure always wins. After primary
success, dropping shared state before reevaluating the suffix restores original
state admission and first-failure order. The unchanged native evaluator must
compute the entire suffix if an anticipated error does not recur. Test the
actual public/operator paths; a toy scheduler that mirrors the proposed loop
does not establish the engine contract.

## Existing coverage verified by primary

- `local_primitive_relational_window_frame_tests.rs:162` independent membership
  matrix includes COUNT(*), COUNT(value), DISTINCT, SUM and AVG; lines 811-870
  ensure count/exclusions do not validate unobserved invalid numbers. Its
  cancellation/denial test at 684 exercises COUNT DISTINCT, not shared totals.
- `local_primitive_relational_window_spill_semantics_tests.rs:318-384` already
  proves group/partition/function error ordering for multiple SUM inputs and
  selected values. Its `error` helper at 288-316 checks resident/stored exact
  diagnostic parity, zero output and released credits. It does not cover an
  earlier secondary member failing at a later row after another member failed.
- `local_primitive_relational_statistical_window_tests.rs:88` independently
  checks seven statistical outputs. Its pressure/cancellation test at 326
  currently uses correlation, outside the proposed single-input family.
- The existing stored-window membership tests assert actual ordered spill;
  setting a spill policy alone is insufficient proof of spill activation.

The delegated initial inventory searched too narrowly and missed top-level
relational test modules. Its corrected inventory was verified against these
sources; no coverage claim relies on the initial absence claims.

## Cohort boundary to freeze separately

The original 776 single-OVER window cases stay unchanged. The accepted index
candidate includes 188 of them; reuse requires exact request, source, runtime,
complete result, certificate and engine-clock identity. The other 588 and a
separately versioned multi-output composition cohort need baseline observations.
Select the composition matrix by semantics, work exposure, shape and size before
timing; do not choose cases or eligibility by favorable times. Expected-error
controls are correctness evidence, not successful timed-query substitutes.
All retained timing comparisons use complete engine time and the frozen binary
retain/drop rule. #10 remains a separate allocated-storage objective. No Full43,
full-10k, paired-moment, quantile or spill-fusion claim follows from this work.

## Prepared test source (not executed)

`window-tests-draft/local_primitive_relational_window_shared_tests.rs` contains
five formatted Rust regression tests for controls 1-4 above. It is deliberately
outside the accepted worktree while index hosted acceptance and retirement are
pending. It has not been compiled or run and is not evidence that the numerical
fixtures pass. After index closeout, add it as a child of the existing
`local_primitive_relational_window_spill_tests.rs` module, using that module's
`ordered` and `complete` helpers. The successful decimal control checks actual
ordered-window activation; error controls compare exact resident/stored
diagnostics, zero emitted output and refunds. Run these on the unmodified
accepted runtime source before implementing sharing. Additional identity,
resource and work-counter controls are still required.

`window-original-cohort-inventory-r1.json` and its script under `tools/`
verify all 776 original declarations, the exact 188 saved-candidate overlap and
588 missing observations from immutable design and case bytes. This is metadata
preparation with zero queries; it does not admit reuse, freeze the new composed
cohort or establish a window performance result.

## Attribution boundary to implement with the baseline controls

Use the existing `native_relational_observation` debug-test session. Add exact
counts at real frame-bound evaluations, state construction/admission, additive
add/remove observations, moments input observations, finalizations and exceptional
suffix evaluations. Distinguish attempted construction from successful admission,
and declared outputs from successful output writes. All instrumentation must
remain absent from ordinary release measurements. Record existing pool peak
credits and terminal refunds separately: cumulative state-admission bytes are
not peak retained bytes. Original single-OVER cases can establish unchanged
behavior and overhead controls, but cannot prove eliminated multi-output work.

Do not cache a new persistent merged arithmetic/moments summary in State. A
temporary local summary is only admissible if its merge order and each
finalization remain exactly those of the existing owners. Identity discovery
must stay within the existing group and preserve its function sequence; reject
incompatible intervening framed functions rather than searching past them.
The first implementation should keep COUNT-first, COUNT(*), DISTINCT, paired
moments, quantiles, collection values and spill writers on their current paths.
