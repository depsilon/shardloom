# Resident compatible-window error path proposal

Preparation, November 11. Source is index PR #1678 head
`9aa5ded02f3b8205ccf4da04714e7ea252c77a59`; hosted index acceptance remains
pending. No window code, frozen protocol, query execution or timing result exists.

The previous proposal retained one secondary error while the first output
completed. A narrower alternative avoids extending any diagnostic allocation's
lifetime: retain only the earliest failed secondary member's position, then
evaluate that member through the original native function-major path after
the shared primary traversal completes and its state has been dropped.

## Proposed algorithm

1. Admit a contiguous compatible resident frame family, with at least two
   outputs. Preserve existing partition/order/peer, non-frame and fill order.
   The primary member keeps its original update and finalization sequence.
2. At each completed row, finalize secondary members in declaration order.
   Stop at the earliest member already known to fail. On a secondary error,
   drop the error immediately, remember that member's position and continue
   only earlier members on following rows. The first member's later error
   still returns directly and therefore has the original precedence.
3. An error found later in row order for an earlier member replaces the saved
   cutoff. No error string, source value or per-row summary is retained.
4. If the primary succeeds, release its state before returning to ordinary
   evaluation. Starting at the cutoff, evaluate every remaining member with
   the unchanged `evaluate_frame` path in declaration order. Its first error
   is returned normally. Evaluating the remaining suffix also remains correct
   if an expected diagnostic unexpectedly does not recur: no skipped output
   is published without being computed.
5. With no secondary failure, all outputs have already been fully finalized.
   Every output vector was allocated before partition evaluation, and numeric
   writes reserve no additional capacity. The original delivery boundary still
   prevents any partial result from escaping a failed query.

This is reuse within the existing ShardLoom operator, with ordinary native
evaluation on an exceptional path. It introduces no executor or runtime fallback.
The proposal still requires proof before implementation or candidate freezing.

## Preconditions that must be established

- Secondary finalization is read-only and has no external effects, input
  mutation, application callback or provider I/O. The initial SUM/AVG and
  single-input moments finalizers satisfy the visible source shape; verify all
  called decimal-output and numeric helpers as well.
- Reusing one state preserves successful outputs byte-for-byte and does not
  hide input/domain errors. Arithmetic-first COUNT companions derive counts
  from the arithmetic totals; COUNT-first and COUNT(*) remain ordinary.
- Original primary and secondary state owners have equivalent admission for
  each selected family. Preserve the current State size on the one-output
  path. Do not add a persistent per-row summary, member vector or pending-error
  owner. Sharing may reduce repeated construction but is not a claim of lower
  query peak memory: input and all output columns remain independent owners.
- Numeric `Values::set_frame` operations are fixed-size writes. A failure there
  must be handled in the same declaration-order model; no collection or
  selected-payload output is admitted into the first families.
- Original cancellation points remain, and companion loops need bounded
  cancellation responsiveness for wide output lists. Cancellation ordering is
  tested without asserting equivalence of asynchronous wall-clock arrivals.
- Resident frame state and key owners are immutable inputs to finalization.
  Bound key identity, identical filters, complete frame/exclusion/order policy,
  null behavior, float policy and decimal output semantics must be checked.
- Moments reuse the existing aligned-cover advance/merge order. Expose its
  existing local Copy summary to multiple finalizers only on the shared path;
  retain no new persistent summary and do not introduce subtractive moments.
- Spill writers remain function-major. Their I/O, admission and publication
  contracts are separate; resident proof does not authorize interleaving them.

## Controls before acceptance

Compare baseline and candidate complete outputs and exact diagnostics for
AVG/SUM overflow followed by a later selected NaN, the reversed declaration
order, three outputs whose later-row error belongs to the earlier member,
decimal precision versus rounding, and standard-deviation/variance overflow.
Include strict/extended nonfinites, all-null/empty/excluded frames, filter
differences, null ordering, calendar rewind, different decimal output policies,
one-output and interrupted-compatible-group controls, tight admission,
cancellation, retry and actual spill controls. Count the exceptional replay
explicitly in debug-only work evidence; do not claim it removes error-path work.

Relevant existing seams: `native_relational_window.rs::evaluate_partition` and
`evaluate_frame`; `native_relational_window_frame_state.rs::advance` and `finish`;
`native_relational_window_moments.rs::Ranges::advance` and `Summary::finish`;
`native_float_total.rs::finish`; `native_decimal_reduce.rs::finish_with`;
`native_statistical_moments.rs::Moments::finish`.

The current index cohort contains 188 of the 776 historical single-OVER window
cases. It does not replace a frozen window baseline. Select the independent
window cohort by semantics and exposure before measuring; version new multi-output
cases separately and preserve all original cases and observations.
