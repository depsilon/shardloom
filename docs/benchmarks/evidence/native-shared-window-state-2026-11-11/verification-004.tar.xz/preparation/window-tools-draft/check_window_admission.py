"""Check the prospective input binding and unchanged supervisor without queries."""
import ast
import copy
import json
from pathlib import Path

import window_admission as admission
import window_replay as proof
from window_replay import D, E, N, S, content
from query_surface.evidence import identity

DEST = S / 'window-admission-preflight-r1.json'


def checked_supervision():
    old_path = N / 'tools/guard_shared_index.py'
    new_path = Path(__file__).with_name('guard_shared_window.py')
    old, new = old_path.read_text(), new_path.read_text()
    trees = [ast.parse(source) for source in (old, new)]
    names = ['generation', 'included_build_input', 'capture_build_sources',
        'inventory_fingerprint', 'verify_build_sources', 'guard']
    for name in names:
        nodes = [next(node for node in tree.body if isinstance(node, ast.FunctionDef)
            and node.name == name) for tree in trees]
        assert ast.dump(nodes[0], include_attributes=False) == ast.dump(nodes[1], include_attributes=False), name
    before = old[old.index('parser = argparse.ArgumentParser'):old.index('prior_raw = PRIOR_CLOSEOUT.read_bytes()')]
    after = new[new.index('parser = argparse.ArgumentParser'):new.index('prior_raw = PRIOR_CLOSEOUT.read_bytes()')]
    assert before == after
    assert old[old.index('try:\n    verify_build_sources'):] == new[new.index('try:\n    verify_build_sources'):]
    assert "OUT / 'tools/guard_shared_window.py'" in new
    return dict(original=content(old_path), versioned=content(new_path),
        unchanged_functions=names, unchanged_parser_resources_environment_supervisor=True,
        unchanged_final_hash_drain_reap_receipts=True,
        changed_boundary='accepted index closeout, current runtime, retained packets and fixed window selection',
        activated=False)


def main():
    assert __debug__ and not DEST.exists()
    paths = [Path(__file__), Path(admission.__file__), Path(proof.__file__),
        Path(__file__).with_name('guard_shared_window.py'),
        S / 'tools/frozen_generation_binding.py', S / 'baseline-generation-binding-r1.json']
    sources = {str(path): content(path) for path in paths}
    result = dict(status='failed', native_query_executions=0, build_executions=0,
        sources=sources, hosted_acceptance_still_required=True, scoring_protocol_frozen=False)
    try:
        supervision = checked_supervision()
        design, inputs, prepared, frozen, binding = admission.inputs_and_client()
        selection, preflight, reused, missing = admission.selected_cases(design)
        assert len(reused) == 188 and len(missing) == 1024
        original = copy.deepcopy(binding.mapping[str(E / 'design.json')])
        controls = []
        for key in ('device', 'inode', 'bytes', 'mtime_ns', 'ctime_ns'):
            changed = copy.deepcopy(original)
            changed['current']['generation'][key] += 1
            binding.mapping[str(E / 'design.json')] = changed
            try:
                binding.current(original['historical'])
            except AssertionError:
                controls.append('generation.' + key)
            else:
                raise AssertionError('changed generation admitted: ' + key)
        for key, changed_value in (('sha256', '0'*64), ('path', '/changed-path')):
            changed = copy.deepcopy(original)
            changed['current'][key] = changed_value
            binding.mapping[str(E / 'design.json')] = changed
            try:
                binding.current(original['historical'])
            except AssertionError:
                controls.append(key)
            else:
                raise AssertionError('changed content binding admitted: ' + key)
        binding.mapping[str(E / 'design.json')] = original
        assert binding.current(original['historical']) == identity(E / 'design.json')
        assert len(controls) == 7
        assert all(content(Path(path)) == value for path, value in sources.items())
        result.update(status='passed_input_and_supervisor_preflight', selected_requests=1212,
            saved_requests=188, missing_requests=1024, validated_frozen_files=len(frozen),
            frozen_files=frozen, input_binding_source=identity(S / 'baseline-generation-binding-r1.json'),
            rejected_binding_corruptions=controls, supervision=supervision,
            historical_runtime_identity_checked_only=True,
            current_index_runtime_admission='not called before completed hosted closeout')
    except BaseException as error:
        result['error'] = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        with DEST.open('x') as output:
            json.dump(result, output, indent=2, allow_nan=False)
            output.write('\n')
    print(json.dumps({key: result[key] for key in ('status', 'selected_requests',
        'validated_frozen_files', 'native_query_executions', 'scoring_protocol_frozen')}))


if __name__ == '__main__':
    main()
