"""Accepted-runtime and historical-input admission for the fixed window cohort.

Historical inputs are checked only when requested. Retired unrelated runtimes
and ledgers are not prerequisites; each requested path retains its exact content,
inode, length, timestamps and explicitly recorded device binding.
"""
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import window_replay as proof
from window_replay import CLIENT, D, E, FROZEN, N, S, W, content, read

OUT = S.parent / 'shared-window-state-2026-11-11'
HEAD = '9aa5ded02f3b8205ccf4da04714e7ea252c77a59'
TREE = 'c239675c12a25c04aa07a6dc45b8854d6b4718d2'
CLOSEOUT = N / 'shared-index-closeout-r1.json'
PACKET = W / 'docs/benchmarks/evidence/native-shared-index-metadata-2026-11-10'
SELECTION = S / 'window-cohort-selection-r1.json'
PREFLIGHT = S / 'window-protocol-preflight-r1/complete.json'
sys.path[:0] = [str(S / 'tools'), str(E / 'tools')]
import frozen_generation_binding as historical
import run_investigation_cohort_r2 as original
from query_surface.evidence import identity
from query_surface.expanded_run import closing_db, verify


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=W, text=True, timeout=90).strip()


class HistoricalSubset:
    def __init__(self):
        assert __debug__
        assert content(historical.BINDING) == dict(bytes=578120,
            sha256='6be6d1429fd5d0e25a5eea151dbd77925082740e09350b0bf625fae36dc824d5')
        assert content(Path(historical.__file__)) == dict(bytes=7874,
            sha256='77cb4dac41abdcee2856e54a84dee2dd355a1584fcaf0ab7aeb9f4e0965fc7af')
        self.record = read(historical.BINDING)
        assert self.record['status'] == 'all_contents_and_non_device_generation_fields_equal'
        assert self.record['permitted_device_change'] == [16777233, 16777234]
        assert self.record['observer'] == identity(Path(historical.__file__))
        self.mapping = {row['historical']['path']: row for row in self.record['files']}
        assert len(self.mapping) == self.record['unique_files'] == len(self.record['files'])

    def current(self, item):
        row = self.mapping[item['path']]
        assert row['historical'] == item, 'unbound historical declaration: ' + item['path']
        historical.device_only(row['historical'], row['current'])
        path = Path(item['path'])
        assert row['symlink_target'] == (str(path.readlink()) if path.is_symlink() else None)
        assert identity(path) == row['current'], 'changed historical file: ' + str(path)
        return row['current']

    def files(self, items):
        return [self.current(item) for item in items]

    def verify(self, items):
        verify(self.files(items))

    @contextmanager
    def admission_verifier(self):
        previous = original.verify
        original.verify = self.verify
        try:
            yield
        finally:
            original.verify = previous

    def stage_complete(self, root, stage, expected):
        assert root == E and stage == 'polars'
        record = read(root / ('observe-' + stage) / 'complete.json')
        assert record['status'] == 'complete_observation'
        assert record['total'] == record['attempt_slots'] == expected and record['posthash_verified']
        assert record['frozen']['path'] == str(root / 'frozen.json')
        assert record['ledger']['path'] == str(root / ('observe-' + stage) / 'attempts.sqlite')
        self.verify([record['ledger'], record['binding'], record['frozen']])
        with closing_db(Path(record['ledger']['path']), readonly=True) as ledger:
            counts = dict(ledger.execute('SELECT status, COUNT(*) FROM attempt GROUP BY status'))
        assert counts == record['outcomes'] == {'passed': expected}
        return record


def accepted_runtime():
    """Require final hosted integration and verified retirement, not a pending PR."""
    assert __debug__
    closeout = read(CLOSEOUT)
    assert closeout['schema'] == 'shardloom.shared_index_closeout.v1'
    assert closeout['status'] == 'complete' and closeout['pr_head'] == HEAD
    assert closeout['source_tree'] == TREE
    assert closeout['pr_checks_passed'] == 58 and closeout['main_checks_passed'] == 55
    assert closeout['review_findings'] is False and closeout['working_tree_clean']
    assert closeout['runtime_sources_match_build'] and closeout['source_bound_replay'] == 'passed'
    assert closeout['portable_replay_after_retirement'] == 'passed'
    assert closeout['current_inputs_unchanged'] and closeout['current_input_files'] == 220
    assert closeout['disposition'] == 'retain_candidate'
    assert not closeout['complete_10k_performance_claim']
    assert git('rev-parse', 'HEAD') == closeout['merge_commit']
    assert git('rev-parse', 'HEAD^{tree}') == TREE and not git('status', '--porcelain')
    sources = [CLOSEOUT]
    for root, key in ((N, 'receipts'), (W, 'committed_evidence')):
        for relative, expected in closeout[key].items():
            path = root / relative
            assert not Path(relative).is_absolute() and path.resolve().is_relative_to(root)
            assert content(path) == expected
            sources.append(path)
    accepted = read(PACKET / 'acceptance.json')
    assert accepted['status'] == 'local_candidate_decision_recorded'
    assert accepted['candidate_source_fingerprint_sha256'] == closeout['source_fingerprint_sha256']
    assert accepted['disposition'] == closeout['disposition'] == 'retain_candidate'
    protocol = read(N / 'candidate-protocol-r1.json')
    assert content(N / 'candidate-protocol-r1.json') == next(
        {key: row[key] for key in ('bytes', 'sha256')} for row in accepted['members']
        if row['path'] == 'current/candidate-protocol-r1.json')
    assert protocol['runtime_binding']['source_fingerprint_sha256'] == closeout['source_fingerprint_sha256']
    runtime = protocol['runtime_binding']['runtime']
    assert set(runtime) == {'binary', 'library'}
    assert runtime['binary']['path'] == str(N / 'runtime-r1/shardloom')
    assert runtime['library']['path'] == str(N / 'runtime-r1/_native.abi3.so')
    for path, expected in closeout['retained_runtime'].items():
        assert Path(path).parent == N / 'runtime-r1' and content(Path(path)) == expected
        sources.append(Path(path))
    verify(list(runtime.values()))
    sources.extend([N / 'candidate-protocol-r1.json', N / 'release-build-r1.json'])
    return runtime, closeout, sources


def inputs_and_client():
    """Keep the original client, environment, references and input checks intact."""
    bound = HistoricalSubset()
    with bound.admission_verifier():
        design, inputs, frozen, relocated, archive, metadata = original.checked_admission(original.ROOT_DEFAULT, E)
    assert len(relocated) == 65
    prepared = read(E / 'native-preparation/complete.json')
    assert prepared['status'] == 'passed'
    prepared_files = [item for profile in prepared['profiles'].values()
        for item in [profile['manifest'], *profile['inputs'], *profile['receipts']]]
    frozen = [*bound.files(frozen), *bound.files(prepared_files), *archive]
    for relative in ('scripts/native_workflow_protocol.py', 'scripts/clickbench_reference_packet.py',
            'scripts/clickbench_native_sql.py'):
        path = FROZEN / relative
        assert content(path) == read(N / 'release-build-r1.json')['build_sources'][relative]
        frozen.append(identity(path))
    assert metadata['design.json'] == 'fd0a2604c9abc888a7a24ba75078569fc33e354b16cc98372977c15306a39216'
    verify(frozen)
    return design, inputs, prepared, frozen, bound


def selected_cases(design):
    assert content(SELECTION) == dict(bytes=2454802,
        sha256='78491c156869c70743753d129583ff15ae3378cac13ae0125fcd304bf276921a')
    selection = read(SELECTION)
    assert not selection['selection_uses_timing'] and selection['query_executions'] == 0
    assert selection['selected_requests'] == len(selection['cases']) == 1212
    assert selection['original_requests'] == 776 and selection['new_compositions'] == 436
    assert content(PREFLIGHT) == dict(bytes=1141739,
        sha256='30860e2a247b2374fb1053f57a8b6ad342e838adb2571adf76e984746f6dad09')
    checked = read(PREFLIGHT)
    assert checked['status'] == 'passed_request_and_saved_replay_preflight'
    assert checked['complete_requests'] == 1212 and checked['saved_observations_verified'] == 188
    assert checked['new_observations_required'] == 1024 and checked['query_executions'] == 0
    assert not checked['native_runtime_loaded'] and not checked['scoring_protocol_frozen']
    verify([checked['retained_saved_attempts']])
    reused, missing = [], []
    for ordinal, (row, request) in enumerate(zip(selection['cases'], checked['requests'], strict=True)):
        case = row['case']
        assert row['cohort_ordinal'] == request['cohort_ordinal'] == ordinal
        assert row['original_seq'] == request['original_seq']
        assert row['kind'] == request['kind']
        assert case['id'] == request['id'] and case['case_identity'] == request['case_identity']
        if row['kind'] == 'original':
            assert case == design['cases'][row['original_seq']]
        else:
            assert row['kind'] == 'composition' and case['window_composition_version'] == 1
            proof.worker.validate(case)
        (missing if row['saved_candidate_ordinal'] is None else reused).append(row)
    assert len(reused) == 188 and len(missing) == 1024
    return selection, checked, reused, missing
