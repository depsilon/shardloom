"""Exact diagnostic-only source transformations and reviewable apply/restore patches."""
import difflib
import hashlib
import json
import os
from pathlib import Path
import subprocess

S = Path('/Users/dylan/LocalData/shardloom/shared-operator-state-2026-11-10')
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
HEAD = '9aa5ded02f3b8205ccf4da04714e7ea252c77a59'
TREE = 'c239675c12a25c04aa07a6dc45b8854d6b4718d2'
SOURCE = 'shardloom-vortex/src/'
NATIVE = SOURCE + 'local_primitives/'
PARENTS = {
    SOURCE + 'local_primitive_relational_window_spill_tests.rs': (
        'mod semantics_tests;\n',
        '\n#[path = "local_primitive_relational_window_shared_tests.rs"]\nmod shared_tests;\n'),
    SOURCE + 'local_primitive_relational_calendar_window_tests.rs': (
        'mod pressure_tests;\n',
        '\n#[path = "local_primitive_relational_calendar_shared_tests.rs"]\nmod shared_tests;\n'),
}
NEW_TESTS = [
    'local_primitive_relational_window_shared_tests.rs',
    'local_primitive_relational_window_shared_attribution_tests.rs',
    'local_primitive_relational_calendar_shared_tests.rs',
]


def git(*args):
    return subprocess.check_output(['git', *args], cwd=W, timeout=90)


def info(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def expected():
    assert git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE
    specification = json.loads((S / 'window-attribution-draft/transformations.json').read_bytes())
    assert specification['source_head'] == HEAD
    assert not specification['applied_to_repository'] and not specification['compiled']
    assert specification['query_executions'] == 0
    changes = {}
    for name, replacements in specification['changes']:
        relative = NATIVE + name
        before = git('show', 'HEAD:' + relative)
        assert before == git('show', HEAD + ':' + relative)
        after = before.decode()
        for old, new in replacements:
            assert after.count(old) == 1, (name, old)
            after = after.replace(old, new)
        after = after.encode()
        assert after == (S / 'window-attribution-draft' / name).read_bytes()
        changes[relative] = (before, after)
    assert len(changes) == 5
    for relative, (anchor, insertion) in PARENTS.items():
        before = git('show', 'HEAD:' + relative)
        assert before.decode().count(anchor) == 1
        changes[relative] = (before, before.decode().replace(anchor, anchor + insertion).encode())
    tracked = set(git('ls-tree', '-r', '--name-only', 'HEAD').decode().splitlines())
    for name in NEW_TESTS:
        relative = SOURCE + name
        assert relative not in tracked
        changes[relative] = (None, (S / 'window-tests-draft' / name).read_bytes())
    assert len(changes) == 10
    return changes


def verify_current(changes, *, applied):
    modified = set(git('diff', '--name-only', 'HEAD').decode().splitlines())
    untracked = set(git('ls-files', '--others', '--exclude-standard').decode().splitlines())
    assert modified | untracked == (set(changes) if applied else set())
    for relative, versions in changes.items():
        raw = versions[1 if applied else 0]
        path = W / relative
        if raw is None:
            assert not path.exists() and not path.is_symlink(), relative
        else:
            assert path.is_file() and not path.is_symlink() and path.read_bytes() == raw, relative


def patch(changes, *, reverse=False):
    lines = ['*** Begin Patch\n']
    for relative, (before, after) in sorted(changes.items()):
        if reverse:
            before, after = after, before
        name = str(W / relative)
        if before is None:
            lines.append('*** Add File: ' + name + '\n')
            lines.extend('+' + line for line in after.decode().splitlines(keepends=True))
        elif after is None:
            lines.append('*** Delete File: ' + name + '\n')
        else:
            lines.append('*** Update File: ' + name + '\n')
            diff = list(difflib.unified_diff(before.decode().splitlines(keepends=True),
                after.decode().splitlines(keepends=True), n=3))
            assert diff and all(raw.endswith(b'\n') for raw in (before, after))
            lines.extend('@@\n' if line.startswith('@@') else line for line in diff[2:])
    lines.append('*** End Patch\n')
    return ''.join(lines)


def summary(changes):
    return {relative: dict(before=info(before) if before is not None else None, after=info(after))
        for relative, (before, after) in changes.items()}


def diagnostic_inventory_from_restored_tree(changes):
    """Reconstruct every checked build input after restoring the accepted tree."""
    verify_current(changes, applied=False)
    exclusions = ('docs/benchmarks/evidence/', 'docs/release/evidence/',
        'docs/dependencies/evidence/')
    paths = set(git('ls-files', '--cached', '-z').decode().split('\0')) | set(changes)
    result = {}
    for relative in sorted(paths):
        if not relative or relative.startswith(('.git/', *exclusions)) or '.git' in Path(relative).parts:
            continue
        path = W / relative
        if relative in changes:
            result[relative] = info(changes[relative][1])
        elif path.is_symlink():
            target = os.readlink(path)
            result[relative] = dict(symlink=target,
                sha256=hashlib.sha256(os.fsencode(target)).hexdigest())
        else:
            assert path.is_file(), relative
            result[relative] = info(path.read_bytes())
    verify_current(changes, applied=False)
    return result
