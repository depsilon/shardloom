"""Pure request and saved-result checks for the versioned window cohort."""
from contextlib import contextmanager
import ast
import hashlib
import json
import math
from pathlib import Path
import sqlite3
import sys
from types import SimpleNamespace

S = Path(__file__).resolve().parents[1]
N = S.parent / 'shared-index-metadata-2026-11-10'
D = S.parent / 'dictionary-execution-repair-2026-11-10'
E = S.parent / 'expanded-query-2026-11-03'
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
FROZEN = E / 'investigation-original-harness-r1'
CLIENT = S / 'window-client-draft'
sys.path[:0] = [str(CLIENT), str(FROZEN / 'scripts'), str(FROZEN / 'python/src'),
    str(FROZEN / 'benchmarks/traditional_analytics')]
import shared_window_worker as worker
from query_surface.corpus import corpus
from query_surface.expanded_catalog import build, spaces
from query_surface.expanded_freeze import unpack
from query_surface.expanded_report import raw_files, replay
from query_timing_report import query_phase_timings


def read(path):
    return json.loads(path.read_bytes())


def content(path):
    assert path.is_file() and not path.is_symlink(), path
    before = path.stat()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    after = path.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (
        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns), path
    return dict(bytes=after.st_size, sha256=digest)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


@contextmanager
def database(path):
    connection = sqlite3.connect('file:' + str(path.resolve()) + '?mode=ro', uri=True)
    try:
        connection.execute('PRAGMA query_only=ON')
        yield connection
    finally:
        connection.close()


class Cases:
    def __init__(self):
        self.originals = {item.id: item for item in corpus(interactions='all', include_pending=False)}
        self.definitions = {spec.name: spec for spec in spaces()}

    def item(self, case):
        if 'window_composition_version' in case:
            worker.validate(case)
            return SimpleNamespace(identity=case['case_identity'], contract=worker.declarations.contract(case))
        return build(case, self.definitions) if 'cell' in case else self.originals[case['id']]


def verify_clock(entry, record):
    response = json.loads(raw_files(unpack(entry[3]))['one.stdout.json'])
    report = response['observation']
    fields = query_phase_timings(report['fields'], report['clocks']['complete_workflow_seconds'])
    value = fields['engine_execution_seconds']
    assert type(value) in (int, float) and math.isfinite(value) and value >= 0
    assert report['clocks']['engine_timing_reported'] is True
    assert value == record['engine_seconds'] == report['clocks']['engine_execution_seconds']
    assert fields['result_serialization_seconds'] == report['clocks']['result_serialization_seconds']


def replay_case(entry, case, expected, item, inputs, prepared, policy):
    result = replay(entry, case, 'native', expected, item, inputs, prepared, policy)
    if result['status'] == 'passed' or result['engine_seconds'] is not None:
        verify_clock(entry, result)
    if 'window_composition_version' in case and result['status'] in {
            'passed', 'incorrect', 'comparison_inconclusive'} and not result.get('delivered_invalid_result'):
        raw = raw_files(unpack(entry[3]))
        job = json.loads(raw['one.job.json'])
        report = json.loads(raw['one.stdout.json'])['observation']
        assert report['sql_declaration'] == worker.declarations.sql(case, job['sources'])
        assert report['sql_declaration_submitted'] == (case['surface'] in {
            'cli_sql', 'embedded_workflow', 'python_sql'})
        assert report['execution_mode'] == 'first_query_fresh_session'
    return result


def verify_capture():
    """The capture differs only in worker/reference injection and its label."""
    original = D / 'tools/capture_correctness_cohort_r1.py'
    assert content(original)['sha256'] == '95179abcb9ef8cb287b98bdb38a1fe30ebf7d0dd40dd5dea336640b5e91753b2'
    source = original.read_text()
    source = source[source.index('from __future__'):]
    replacements = [
        ('TARGET_NAME = "shared-mechanisms-10k-r1"', 'TARGET_NAME = "window-baseline-missing-r1"'),
        ('WORKER = common.HARNESS_DEFAULT / "benchmarks/traditional_analytics/query_surface/expanded_worker.py"\n', ''),
        ('def observe(root, resume, admission, historical, selection):',
            'def observe(root, resume, admission, historical, selection, *, worker, composition_reference):'),
        ('        ledger = target / "attempts.sqlite"',
            '        if any("window_composition_version" in row for row in selected):\n'
            '            references["composition"] = stack.enter_context(closing_db(composition_reference, readonly=True))\n'
            '        ledger = target / "attempts.sqlite"'),
        ('                references[row["profile"]]',
            '                references["composition" if "window_composition_version" in row else row["profile"]]'),
        ('                str(WORKER),', '                str(worker),'),
    ]
    for before, after in replacements:
        assert source.count(before) == 1, before
        source = source.replace(before, after)
    capture_path = Path(__file__).with_name('capture_window_cohort.py')
    actual = capture_path.read_text()
    assert actual[actual.index('from __future__'):] == source
    ast.parse(actual)
    # Keep engine-clock attribution exactly equivalent to the established check.
    old_source = (S / 'tools/replay_current_10k.py').read_text()
    old_tree, new_tree = ast.parse(old_source), ast.parse(Path(__file__).read_text())
    nodes = [next(node for node in tree.body if isinstance(node, ast.FunctionDef)
        and node.name == 'verify_clock') for tree in (old_tree, new_tree)]
    assert ast.dump(nodes[0], include_attributes=False) == ast.dump(nodes[1], include_attributes=False)
    return dict(original=content(original), versioned=content(capture_path),
        capture_changes=['versioned target label', 'explicit public worker argument',
            'separate independent composition reference database'],
        per_query_supervision_unchanged=True, request_builder_unchanged=True,
        engine_clock_check_unchanged=True, cleanup_and_result_retention_unchanged=True)
