"""Prospective work-count obligations for complete compatible-window diagnostics.

These are counts of operations and admitted ownership, never elapsed time or a
claim about a fraction of CPU use. Layouts follow declared outputs, not timings.
"""
from fractions import Fraction
import json
from pathlib import Path

# (ordinary framed outputs, moment outputs, COUNT(*) outputs,
#  candidate states, candidate moment states, shared groups, shared outputs,
#  additive traversal fraction, additive-value fraction, moment-value fraction)
LAYOUTS = {
    'single_sum': (1, 0, 0, 1, 0, 0, 0, (1, 1), (1, 1), (1, 1)),
    'single_variance': (0, 1, 0, 1, 1, 0, 0, (1, 1), (1, 1), (1, 1)),
    'arithmetic': (3, 0, 0, 1, 0, 1, 3, (1, 3), (1, 2), (1, 1)),
    'arithmetic_count_first': (3, 0, 0, 2, 0, 1, 2, (2, 3), (1, 2), (1, 1)),
    'arithmetic_count_star_interrupted': (2, 0, 1, 3, 0, 0, 0, (1, 1), (1, 1), (1, 1)),
    'arithmetic_key_interrupted': (3, 0, 0, 3, 0, 0, 0, (1, 1), (1, 1), (1, 1)),
    'arithmetic_filter_interrupted': (3, 0, 0, 3, 0, 0, 0, (1, 1), (1, 1), (1, 1)),
    'arithmetic_frame_interrupted': (3, 0, 0, 3, 0, 0, 0, (1, 1), (1, 1), (1, 1)),
    'arithmetic_rank_interrupted': (2, 0, 0, 2, 0, 0, 0, (1, 1), (1, 1), (1, 1)),
    'arithmetic_filtered': (3, 0, 0, 1, 0, 1, 3, (1, 3), (1, 2), (1, 1)),
    'arithmetic_excluded': (3, 0, 0, 1, 0, 1, 3, (1, 3), (1, 2), (1, 1)),
    'arithmetic_all_null': (3, 0, 0, 1, 0, 1, 3, (1, 3), (1, 2), (1, 1)),
    'moments': (0, 4, 0, 1, 1, 1, 4, (1, 1), (1, 1), (1, 4)),
    'moments_key_interrupted': (0, 4, 0, 3, 3, 1, 2, (1, 1), (1, 1), (3, 4)),
    'moments_excluded': (0, 4, 0, 1, 1, 1, 4, (1, 1), (1, 1), (1, 4)),
    'moments_all_null': (0, 4, 0, 1, 1, 1, 4, (1, 1), (1, 1), (1, 4)),
    'wide_arithmetic': (1041, 0, 0, 1, 0, 1, 1041, (1, 1041), (1, 1041), (1, 1)),
}
WINDOW_FIELDS = (
    'frame_bound_evaluations', 'state_construction_attempts', 'state_admissions',
    'state_admitted_bytes', 'moment_state_construction_attempts', 'moment_state_admissions',
    'moment_state_admitted_bytes', 'add_observation_attempts', 'remove_observation_attempts',
    'additive_value_observations', 'moment_value_observations', 'state_finalizers',
    'moment_finalizers', 'resident_frame_writes', 'shared_groups', 'shared_outputs',
    'exceptional_suffix_functions', 'companion_cancellation_checks',
)
ERROR_CASES = {
    # (outputs in compatible family, ordinary suffix functions after primary success, diagnostic)
    'later_primary_avg': (2, 0, 'nonfinite'),
    'later_primary_sum': (2, 0, 'final result is not finite'),
    'secondary_sum': (2, 1, 'final result is not finite'),
    'decimal_earlier_exact': (3, 1, 'nonzero fractional digits'),
    'decimal_earlier_precision': (3, 1, 'precision overflow'),
    'moment_stddev_pop_false': (2, 1, 'statistical result is outside its finite domain'),
    'moment_var_pop_false': (2, 0, 'statistical result is outside its finite domain'),
    'moment_stddev_pop_true': (2, 0, 'nonfinite'),
    'moment_var_pop_true': (2, 0, 'statistical result is outside its finite domain'),
}


def count(row, field):
    value = row['observations']['window_' + field]
    assert type(value) is int and value >= 0, field
    return value


def exact_ratio(candidate, baseline, ratio, label):
    assert Fraction(candidate) == Fraction(baseline) * Fraction(*ratio), label


def normal_rows(report):
    assert report['schema'] == 'shardloom.compatible_window_attribution.v1'
    rows = report['observations']
    keys = {(row['case'], row['input_rows']) for row in rows}
    expected = {(name, size) for size in (17, 4097) for name in LAYOUTS if name != 'wide_arithmetic'}
    expected.add(('wide_arithmetic', 17))
    assert len(rows) == len(keys) == 33 and keys == expected
    return {(row['case'], row['input_rows']): row for row in rows}


def calendar_rows(log):
    prefix = 'WINDOW_SHARED_CALENDAR_WORK '
    rows = [json.loads(line[line.index(prefix) + len(prefix):])
        for line in log.splitlines() if prefix in line]
    keyed = {(row['descending'], row['nulls_first'], row['exclusion']): row for row in rows}
    assert len(rows) == len(keyed) == 16
    assert {key[:2] for key in keyed} == {(a, b) for a in (False, True) for b in (False, True)}
    assert {key[2] for key in keyed} == {'NoOthers', 'CurrentRow', 'Group', 'Ties'}
    for row in rows:
        assert row['complete_values_and_schema_match'] and row['credits_refunded']
        assert not row['engine_timing_claimed']
        assert type(row['input_rows']) is int and row['input_rows'] > 0
        for field in WINDOW_FIELDS:
            count(row, field)
    return keyed


def error_rows(log):
    prefix = 'WINDOW_SHARED_ERROR_WORK '
    rows = [json.loads(line[line.index(prefix) + len(prefix):])
        for line in log.splitlines() if prefix in line]
    keyed = {(row['case'], row['stored']): row for row in rows}
    assert len(rows) == len(keyed) == 18
    assert set(keyed) == {(case, stored) for case in ERROR_CASES for stored in (False, True)}
    for (case, stored), row in keyed.items():
        assert type(stored) is bool
        assert row['credits_refunded'] and not row['engine_timing_claimed']
        assert row['emitted_batches'] == row['completed_executions'] == 0
        assert ERROR_CASES[case][2] in row['error']
        assert row['error'] == keyed[case, not stored]['error']
        for field in WINDOW_FIELDS:
            count(row, field)
        assert count(row, 'state_construction_attempts') > 0
        assert count(row, 'state_construction_attempts') == count(row, 'state_admissions')
    return keyed


def baseline(report, calendar_log):
    rows, calendars = normal_rows(report), calendar_rows(calendar_log)
    errors = error_rows(calendar_log)
    state_size = count(rows['single_sum', 17], 'state_admitted_bytes')
    moment_size = count(rows['single_variance', 17], 'moment_state_admitted_bytes')
    assert state_size > 0 and moment_size > 0
    for (name, size), row in rows.items():
        ordinary, moments, stars, *_ = LAYOUTS[name]
        frames = ordinary + moments + stars
        assert row['complete_values_and_schema_match'] and row['source_exhausted']
        assert row['output_rows'] == size and row['no_fallback']
        assert row['final_charged_bytes'] == 0 and row['peak_charged_bytes'] <= 64 << 20
        assert not row['engine_timing_claimed']
        for field in WINDOW_FIELDS:
            count(row, field)
        for field in ('state_construction_attempts', 'state_admissions'):
            assert count(row, field) == frames, (name, field)
        assert count(row, 'state_admitted_bytes') == frames * state_size
        for field in ('moment_state_construction_attempts', 'moment_state_admissions'):
            assert count(row, field) == moments, (name, field)
        assert count(row, 'moment_state_admitted_bytes') == moments * moment_size
        assert count(row, 'frame_bound_evaluations') == frames * size
        assert count(row, 'resident_frame_writes') == frames * size
        assert count(row, 'state_finalizers') == ordinary * size
        assert count(row, 'moment_finalizers') == moments * size
        for field in ('shared_groups', 'shared_outputs', 'exceptional_suffix_functions', 'companion_cancellation_checks'):
            assert count(row, field) == 0, (name, field)
    for row in calendars.values():
        size = row['input_rows']
        assert count(row, 'state_admissions') == count(row, 'state_construction_attempts') == 14
        assert count(row, 'moment_state_admissions') == count(row, 'moment_state_construction_attempts') == 8
        assert count(row, 'state_admitted_bytes') == 14 * state_size
        assert count(row, 'moment_state_admitted_bytes') == 8 * moment_size
        assert count(row, 'frame_bound_evaluations') == count(row, 'resident_frame_writes') == 7 * size
        assert count(row, 'state_finalizers') == 3 * size and count(row, 'moment_finalizers') == 4 * size
        assert all(count(row, field) == 0 for field in ('shared_groups', 'shared_outputs',
            'exceptional_suffix_functions', 'companion_cancellation_checks'))
    for row in errors.values():
        assert all(count(row, field) == 0 for field in ('shared_groups', 'shared_outputs',
            'exceptional_suffix_functions', 'companion_cancellation_checks'))
    return dict(status='passed_baseline_work_contract', diagnostic_requests=33,
        calendar_controls=16, error_controls=18,
        state_size_bytes=state_size, moment_state_size_bytes=moment_size,
        engine_timing_claimed=False, cpu_share_claimed=False)


def compare(baseline_report, candidate_report, baseline_calendar_log, candidate_calendar_log):
    original = baseline(baseline_report, baseline_calendar_log)
    before, after = normal_rows(baseline_report), normal_rows(candidate_report)
    deltas = []
    for key, old in before.items():
        new = after[key]
        name, size = key
        ordinary, moments, stars, states, moment_states, groups, outputs, moves, additive, moment = LAYOUTS[name]
        for field in ('case', 'input_rows', 'output_rows', 'output_columns', 'expected_sha256',
                'actual_sha256', 'complete_values_and_schema_match', 'source_exhausted',
                'final_charged_bytes', 'observation_scope', 'moments_comparison', 'no_fallback', 'engine_timing_claimed'):
            assert new[field] == old[field], (name, field)
        assert new['peak_charged_bytes'] <= 64 << 20
        for field in WINDOW_FIELDS:
            count(new, field)
        for field in ('state_construction_attempts', 'state_admissions'):
            assert count(new, field) == states, (name, field)
        assert count(new, 'state_admitted_bytes') == states * original['state_size_bytes']
        for field in ('moment_state_construction_attempts', 'moment_state_admissions'):
            assert count(new, field) == moment_states, (name, field)
        assert count(new, 'moment_state_admitted_bytes') == moment_states * original['moment_state_size_bytes']
        assert count(new, 'frame_bound_evaluations') == states * size
        for field in ('state_finalizers', 'moment_finalizers', 'resident_frame_writes'):
            assert count(new, field) == count(old, field), (name, field)
        for field, ratio in (('add_observation_attempts', moves), ('remove_observation_attempts', moves),
                ('additive_value_observations', additive), ('moment_value_observations', moment)):
            exact_ratio(count(new, field), count(old, field), ratio, (name, field))
        assert count(new, 'shared_groups') == groups
        assert count(new, 'shared_outputs') == outputs
        assert count(new, 'exceptional_suffix_functions') == 0
        if groups:
            assert count(new, 'companion_cancellation_checks') > 0
        else:
            assert new['observations'] == old['observations'], name
            assert new['peak_charged_bytes'] == old['peak_charged_bytes'], name
        deltas.append(dict(case=name, input_rows=size,
            before={field:count(old,field) for field in WINDOW_FIELDS},
            after={field:count(new,field) for field in WINDOW_FIELDS},
            peak_charged_bytes=dict(before=old['peak_charged_bytes'], after=new['peak_charged_bytes'])))
    old_calendar, new_calendar = calendar_rows(baseline_calendar_log), calendar_rows(candidate_calendar_log)
    for key, old in old_calendar.items():
        new = new_calendar[key]
        assert new['input_rows'] == old['input_rows']
        size = old['input_rows']
        assert count(new, 'state_admissions') == count(new, 'state_construction_attempts') == 4
        assert count(new, 'moment_state_admissions') == count(new, 'moment_state_construction_attempts') == 2
        assert count(new, 'state_admitted_bytes') == 4 * original['state_size_bytes']
        assert count(new, 'moment_state_admitted_bytes') == 2 * original['moment_state_size_bytes']
        assert count(new, 'frame_bound_evaluations') == 2 * size
        assert count(new, 'shared_groups') == 4 and count(new, 'shared_outputs') == 14
        assert count(new, 'exceptional_suffix_functions') == 0
        assert count(new, 'companion_cancellation_checks') > 0
        for field in ('state_finalizers', 'moment_finalizers', 'resident_frame_writes'):
            assert count(new, field) == count(old, field)
        for field, ratio in (('add_observation_attempts', (1, 3)), ('remove_observation_attempts', (1, 3)),
                ('additive_value_observations', (1, 2)), ('moment_value_observations', (1, 4))):
            exact_ratio(count(new, field), count(old, field), ratio, (key, field))
    old_errors, new_errors = error_rows(baseline_calendar_log), error_rows(candidate_calendar_log)
    for (case, stored), old in old_errors.items():
        new = new_errors[case, stored]
        assert {key:value for key,value in new.items() if key != 'observations'} == {
            key:value for key,value in old.items() if key != 'observations'}, case
        if stored:
            assert new['observations'] == old['observations'], case
        else:
            outputs, suffix, _ = ERROR_CASES[case]
            assert count(new, 'shared_groups') == 1, case
            assert count(new, 'shared_outputs') == outputs, case
            assert count(new, 'exceptional_suffix_functions') == suffix, case
            assert count(new, 'state_admissions') == 1 + suffix, case
            assert count(new, 'state_admitted_bytes') == (1 + suffix) * original['state_size_bytes'], case
    return dict(status='passed_candidate_work_contract', diagnostic_requests=33,
        calendar_controls=16, error_controls=18,
        baseline_contract=original, complete_request_deltas=deltas,
        state_size_unchanged=True, engine_timing_claimed=False, cpu_share_claimed=False)


def read(path):
    return json.loads(Path(path).read_bytes())
