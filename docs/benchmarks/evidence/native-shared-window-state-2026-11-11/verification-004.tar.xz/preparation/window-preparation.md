# Compatible window state investigation — preparation only

Status: primary source review, November 10, 2026. No implementation, frozen
protocol, new engine execution or acceptance exists. Finish the active Variant
expression integration before changing engine code. Keep this experiment's
decision independent of shared-index metadata and rolling DISTINCT recycling.

## Verified work and owner boundaries

Paths below are relative to the active Variant expression checkout. Reconcile
source identities to its accepted merge before freezing a protocol.

- `shardloom-vortex/src/local_primitives/native_relational_window.rs:292-433`
  discovers partition peers once, then evaluates each framed function with a
  new cursor, state, input view and complete partition traversal. It publishes
  results into each function's existing output column.
- `native_relational_window_frame_state.rs:54-249` owns three interval ranges,
  per-interval counts, exact floating totals, decimal totals and optional
  DISTINCT/extrema/moments/quantile/collection owners. General movement removes
  all departed observations before admitting arrivals. Calendar frames may
  retreat. Preserve interval validation and union/exclusion semantics.
- In that file, `observe` and `observe_additive` at lines 312-436 apply filters,
  nullness, input access and numeric policy. SUM and AVG share the same kind of
  total maintenance; their finalizers choose sum/average and decimal output
  metadata. COUNT observes nullness only. COUNT(*) without a filter can answer
  from interval lengths without reading values.
- `native_relational_window_moments.rs:1-218` already avoids rescanning each
  whole frame. It retains aligned power-of-two covers, reuses only complete
  old blocks, observes uncovered fragments and merges in a defined order.
  Variance and standard-deviation finalizers consume the same single-input
  summary kind; covariance/correlation use a paired kind. Sharing must preserve
  this algorithm and order. Do not introduce a subtractive moving-moments
  algorithm under the name of traversal sharing.
- `native_relational_window_partition.rs:98-219` is the spill partition owner.
  It preserves per-function scheduling and stored results. DISTINCT/extrema
  have separate bounds/event paths; ordinary fixed frames use the existing
  shared frame machinery. Resident membership recycling is not a change to
  these spill event algorithms.

## Candidate eligibility to resolve

The resident output allocation boundary is already shared: `Window::finish`
allocates every `Values` column in declaration order before evaluating any
group (`native_relational_window.rs:150-160`). Keep that order. The candidate
numeric/count outputs use pre-sized native vectors; `Values::set_frame` writes
their elements without reserving more storage (lines 648-670). Collection
outputs do reserve through a different owner and are outside the first families.
This removes one hypothetical output-allocation reordering concern for a
resident numeric candidate, but does not settle state allocation or failure
precedence. In the baseline, frame states are created and dropped one function
at a time, so sharing mainly removes repeated state construction and updates;
it does not by itself prove a reduction in peak live state bytes. All output
columns and the input table remain retained separately.

Begin with ordinary SUM/AVG and single-input variance/standard-deviation
families. A compatible group requires the same bound input/key and source
generation, partition/order including peer/null ordering, complete frame,
exclusion, filter, null treatment, numeric observation policy and input domain.
Keep final output dtype/decimal policy explicit per output. Aliases alone do
not establish expression identity. Near-matching groups remain separate.

COUNT sharing is conditional. `native_float_total::Total` has an observation
count but currently exposes it only to tests; decimal totals expose a count.
Neither fact makes arithmetic observation equivalent to nullness observation.
For example strict floating policy can reject a nonfinite SUM input that COUNT
does not numerically inspect. The candidate must not read or validate values
merely because a cheap count is present. Prove compatible observation and
diagnostic behavior before admitting COUNT into an arithmetic family.

The other major question is failure order. Today one framed function finishes
its partition before the next begins. Interleaving output finalizers can expose
a later function's early error before an earlier function's later error.
`native_statistical_moments.rs:296-318` and decimal/floating total finalizers
have fallible domain/precision checks, so matching inputs is insufficient.
Resolve this with an explicit supported eligibility/error-order contract before
implementation; a representative function or unchecked error suppression is
not proof. Account for state/output allocation denial, cancellation and spill
I/O errors as well as numeric errors. No completed result may escape failure.

A concrete future failure-order fixture is AVG(x), SUM(x) over a growing frame
with two largest finite F64 values followed by a selected NaN under strict
policy. The current exact total can finalize the first two values as a finite
average, while their sum exceeds the finite result domain. AVG's later NaN
observation must still take precedence over the later-declared SUM's earlier
finalization error. This expected order comes from the current function-major
loop and `native_float_total.rs`, not candidate output. Include the reversed
declaration order and analogous standard-deviation/variance finalizer controls.

One possible bounded design is contiguous compatible output families with one
maintenance owner and separately finalized outputs, preserving the existing
function order when delivering any error. Secondary finalizer errors could be
retained until earlier functions have completed; this is an option to prove,
not an accepted error-suppression policy. Prove output reservation, spill and
cleanup behavior before admitting it. Matching-state construction by itself is
not enough. `window-test-inventory.md` records existing multi-output, null,
exclusion, pressure, cancellation, numerical and error-order controls verified
by the primary; they do not yet test a fused implementation.

The existing ShardLoom window and Vortex input/result owners should remain the
semantic boundary. Complete the targeted pinned-provider check before freezing
any new private abstraction; no additional executor, Arrow row substrate,
dependency or encoding change is implied by this preparation.

## Exposure and complete acceptance

The independently checked saved cohort has 776 window declarations, each with
one textual OVER clause: 120 row-number, 219 lag, 219 lead and 218 rolling-SUM
cases. This does not expose multi-output state reuse. Preserve that original
cohort and add a separately versioned complete-query composition cohort; never
attribute its whole window-family engine time to removable state maintenance.

Before measuring, freeze exact baseline/candidate source and runtime identities,
case/input identities, independently expected complete outputs, eligibility,
clock, isolation, resource limits and retain/drop rules. Include one-output and
near-match controls, mixed output declaration orders, empty/all-null frames,
exclusions/peers, precision boundaries, nonfinite policy, rewind, skewed
partitions, low-memory denial, cancellation and confirmed spill where admitted.
The original resident/spilled numerical algorithms and output ownership remain
authoritative. Verify all requested columns and public-route parity.

Measure frame-bound evaluations, actual observation updates, state bytes and
complete engine time. Counters establish activation and removed work; they do
not replace complete-request acceptance. If attribution instrumentation changes
execution, keep it separate from ordinary-runtime timing and disclose that
boundary. Preserve construction/output/publication diagnostics separately from
routine engine-clock reporting. Lower complete-cohort engine time ships; equal
or higher drops after correctness, resources and no-fallback checks. Do not add
individual experiment savings or test combined candidates before independent
acceptance.
