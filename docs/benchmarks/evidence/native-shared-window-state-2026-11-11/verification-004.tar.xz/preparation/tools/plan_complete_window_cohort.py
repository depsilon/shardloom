"""Fix the complete window denominator and missing/reused partition before timing."""
from collections import Counter
import hashlib
import json
from pathlib import Path

S = Path(__file__).resolve().parents[1]
DEST = S / 'window-cohort-selection-r1.json'


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


assert not DEST.exists()
old_path = S / 'window-original-cohort-inventory-r1.json'
new_path = S / 'window-composition-design-r1.json'
refs_path = S / 'window-reference-r2/complete.json'
old, new, refs = map(read, (old_path, new_path, refs_path))
assert old['query_executions'] == new['query_executions'] == refs['native_query_executions'] == 0
assert not old['selection_uses_timing'] and not new['selection_uses_timing']
assert old['original_cases'] == len(old['cases']) == 776
assert new['composed_cases'] == refs['cases'] == len(new['cases']) == 436
assert refs['status'] == 'passed_independent_references'
assert refs['design']['sha256'] == identity(new_path)['sha256']
assert refs['input_and_client_hashes_unchanged'] and not refs['native_runtime_loaded']
assert not any(row['case'].get('window_composition_version') for row in old['cases'])
cases = []
for entry in old['cases']:
    cases.append(dict(cohort_ordinal=len(cases), kind='original', original_seq=entry['original_seq'],
        case=entry['case'], saved_candidate_ordinal=entry['saved_candidate_ordinal'],
        independent_reference='original_frozen_profile_expectations'))
for ordinal, (case, reference) in enumerate(zip(new['cases'], refs['rows'], strict=True)):
    assert reference['ordinal'] == ordinal and reference['id'] == case['id']
    assert reference['identity'] == case['case_identity'] == digest(case['declaration'])
    d, original = case['declaration'], case['original_case']
    normalized = dict(case, window_composition_version=1, family='compatible_windows_' + d['family'],
        archetype='compatible_windows_' + d['family'], profile=d['profile'], surface=d['surface'],
        native_format=d['native_format'], polars_format=original['polars_format'],
        partition=original['partition'], surrogate=None)
    cases.append(dict(cohort_ordinal=len(cases), kind='composition', original_seq=d['original_seq'],
        composition_ordinal=ordinal, case=normalized, saved_candidate_ordinal=None,
        independent_reference=dict(path=refs['expected']['path'], blob_sha256=reference['blob_sha256'])))
assert len(cases) == len({row['case']['id'] for row in cases}) == 1212
assert len({row['case']['case_identity'] for row in cases}) == 1212
reused = [row['cohort_ordinal'] for row in cases if row['saved_candidate_ordinal'] is not None]
missing = [row['cohort_ordinal'] for row in cases if row['saved_candidate_ordinal'] is None]
assert len(reused) == 188 and len(missing) == 1024
result = dict(schema='shardloom.compatible_window_complete_cohort.v1',
    status='fixed_declarations_not_runtime_admission', query_executions=0, selection_uses_timing=False,
    selected_requests=1212, original_requests=776, new_compositions=436,
    baseline_saved_reuse_proposed=188, baseline_missing_observations=1024,
    cases=cases, proposed_saved_ordinals=reused, new_observation_ordinals=missing,
    ordered_identities_sha256=digest([(row['cohort_ordinal'], row['case']['id'],
        row['case']['case_identity']) for row in cases]),
    profiles=dict(Counter(row['case']['profile'] for row in cases)),
    surfaces=dict(Counter(row['case']['surface'] for row in cases)),
    source_formats=dict(Counter(row['case']['native_format'] for row in cases)),
    families=dict(Counter(row['case']['family'] for row in cases)),
    sources=[identity(path) for path in (old_path, new_path, refs_path, Path(__file__))],
    ordering='all original windows in original corpus order, then both families for every original rolling-SUM shape',
    worker='versioned wrapper delegates original controls unchanged; new compositions use existing native public surfaces',
    engine_clock='engine_execution_seconds', attempts_per_missing_baseline_case=1, candidate_attempts_per_case=1,
    warmups=0, requested_repeats=0, complete_10k_performance_claim=False,
    acceptance='strictly lower complete 1212-case engine sum retains after correctness, resource, ownership and no-fallback checks; equal or higher drops',
    freeze_status='cohort and independent reference declarations fixed; accepted merge, runtime, all inputs, worker, diagnostics, guards and complete scoring protocol still required')
with DEST.open('x') as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps({key: result[key] for key in ('status', 'selected_requests', 'original_requests',
    'new_compositions', 'baseline_saved_reuse_proposed', 'baseline_missing_observations', 'query_executions')}))
