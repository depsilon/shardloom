"""Explicit, read-only rebinding of preserved historical files after a device-ID change.

Only the enumerated 16777233 -> 16777234 device change is eligible. Paths,
contents, lengths, inodes and both timestamps must match exactly. Historical
documents are never rewritten and all new verification uses actual identities.
"""
from __future__ import annotations

from collections import Counter
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import stat

S = Path(__file__).resolve().parents[1]
E = S.parent / 'expanded-query-2026-11-03'
BINDING = S / 'baseline-generation-binding-r1.json'
SOURCES = ('frozen.json', 'inputs.json', 'native-preparation/complete.json',
           'observe-native/complete.json', 'observe-polars/complete.json',
           'updated-native-10k-r1/complete.json', 'shared-mechanisms-10k-r1/complete.json')
GENERATION_KEYS = {'device', 'inode', 'bytes', 'mtime_ns', 'ctime_ns'}


def read(path):
    return json.loads(path.read_bytes())


def generation(path):
    value = path.stat()
    return dict(device=value.st_dev, inode=value.st_ino, bytes=value.st_size,
                mtime_ns=value.st_mtime_ns, ctime_ns=value.st_ctime_ns)


def identity(path):
    before = generation(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    assert generation(path) == before, f'file changed while hashing: {path}'
    return dict(path=str(path), generation=before, sha256=digest)


def device_only(expected, actual):
    """Reject every difference except the explicitly observed device mapping."""
    assert set(expected) == set(actual) == {'path', 'generation', 'sha256'}
    assert set(expected['generation']) == set(actual['generation']) == GENERATION_KEYS
    assert expected['path'] == actual['path'] and expected['sha256'] == actual['sha256']
    old, new = expected['generation'], actual['generation']
    assert all(type(value) is int for value in (*old.values(), *new.values()))
    assert all(old[key] == new[key] for key in GENERATION_KEYS - {'device'}), expected['path']
    assert old['device'] == new['device'] or (old['device'], new['device']) == (16777233, 16777234)


def declarations():
    documents = {name: read(E / name) for name in SOURCES}
    frozen, inputs, prepared = (documents[name] for name in SOURCES[:3])
    rows = [frozen['design'], frozen['inputs'], *frozen['references'],
            *frozen['environment_files'], *inputs['files'], *inputs['runtime'].values(),
            prepared['frozen'], prepared['polars_complete']]
    for profile in prepared['profiles'].values():
        rows.extend([profile['manifest'], *profile['inputs'], *profile['receipts']])
    for name in SOURCES[3:]:
        record = documents[name]
        rows.extend([record['ledger'], record['binding'], record['frozen'],
                     *record['prerequisites'].values()])
    unique = {}
    for row in rows:
        if row['path'] in unique:
            assert unique[row['path']] == row, f'conflicting historical identities: {row["path"]}'
        unique[row['path']] = row
    return unique, len(rows)


def freeze():
    assert __debug__ and not BINDING.exists()
    sources = [identity(E / name) for name in SOURCES]
    expected, declared = declarations()
    observations, counts = [], Counter()
    for name, old in sorted(expected.items()):
        path = Path(name)
        # The old identity follows symlinks. Keep that contract and record the
        # link itself when present; a regular target is still mandatory.
        assert stat.S_ISREG(path.stat().st_mode)
        actual = identity(path)
        device_only(old, actual)
        counts[f'{old["generation"]["device"]}->{actual["generation"]["device"]}'] += 1
        observations.append(dict(historical=old, current=actual,
                                 symlink_target=str(path.readlink()) if path.is_symlink() else None))
    assert [identity(E / name) for name in SOURCES] == sources
    result = dict(schema='shardloom.historical_generation_rebinding.v1',
        status='all_contents_and_non_device_generation_fields_equal',
        original_documents_unchanged=True, changed_field='generation.device',
        cause='not established; this record attests equality, not a cause',
        permitted_device_change=[16777233, 16777234], declarations=declared,
        unique_files=len(observations), bytes_hashed=sum(row['current']['generation']['bytes'] for row in observations),
        device_mappings=dict(counts), source_documents=sources,
        observer=identity(Path(__file__)), files=observations)
    with BINDING.open('x') as output:
        json.dump(result, output, indent=2)
        output.write('\n')
    print(json.dumps({key: result[key] for key in ('status', 'unique_files', 'device_mappings')}))


class HistoricalBinding:
    def __init__(self):
        assert __debug__
        self.record = read(BINDING)
        assert self.record['schema'] == 'shardloom.historical_generation_rebinding.v1'
        assert self.record['status'] == 'all_contents_and_non_device_generation_fields_equal'
        assert self.record['permitted_device_change'] == [16777233, 16777234]
        assert self.record['observer'] == identity(Path(__file__))
        assert self.record['source_documents'] == [identity(E / name) for name in SOURCES]
        expected, count = declarations()
        rows = self.record['files']
        assert self.record['declarations'] == count
        assert self.record['unique_files'] == len(rows) == len(expected)
        self.mapping = {row['historical']['path']: row for row in rows}
        assert len(self.mapping) == len(rows) and set(self.mapping) == set(expected)
        for name, row in self.mapping.items():
            assert row['historical'] == expected[name]
            device_only(row['historical'], row['current'])
            path = Path(name)
            assert row['symlink_target'] == (str(path.readlink()) if path.is_symlink() else None)
            assert identity(path) == row['current'], f'file changed after explicit rebinding: {name}'

    def current(self, historical):
        row = self.mapping[historical['path']]
        assert historical == row['historical'], f'unbound historical identity: {historical["path"]}'
        return row['current']

    def files(self, historical):
        return [self.current(item) for item in historical]

    def verify(self, historical):
        from query_surface.expanded_run import verify
        verify(self.files(historical))

    @contextmanager
    def admission_verifier(self, module):
        # Only this explicitly named caller receives historical rebinding.
        # The actual identity function and all active-file checks stay strict.
        original = module.verify
        module.verify = self.verify
        try:
            yield
        finally:
            module.verify = original

    def stage_complete(self, root, stage, expected):
        from query_surface.expanded_run import closing_db
        assert root == E
        record = read(root / ('observe-' + stage) / 'complete.json')
        assert record['status'] == 'complete_observation'
        assert record['total'] == record['attempt_slots'] == expected and record['posthash_verified']
        assert record['frozen']['path'] == str(root / 'frozen.json')
        assert record['ledger']['path'] == str(root / ('observe-' + stage) / 'attempts.sqlite')
        self.verify([record['ledger'], record['binding'], record['frozen']])
        with closing_db(Path(record['ledger']['path']), readonly=True) as ledger:
            counts = dict(ledger.execute('SELECT status, COUNT(*) FROM attempt GROUP BY status'))
        assert counts == record['outcomes'] and sum(counts.values()) == expected and 'started' not in counts
        return record


if __name__ == '__main__':
    freeze()
