"""Construct every composed declaration through real APIs, without preparing or collecting."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

S = Path(__file__).resolve().parents[1]
N = S.parent / 'shared-index-metadata-2026-11-10'
FROZEN = S.parent / 'expanded-query-2026-11-03/investigation-original-harness-r1'
CLIENT = S / 'window-client-draft'
DEST = S / 'window-public-declaration-check-r1.json'
sys.path[:0] = [str(CLIENT), str(FROZEN / 'scripts'), str(FROZEN / 'python/src'),
    str(FROZEN / 'benchmarks/traditional_analytics')]
import shared_window_worker as worker
from query_surface.evidence import identity
from query_surface.expanded_freeze import read
from query_surface.worker import load_native


def content(path):
    with path.open('rb') as stream:
        return dict(bytes=path.stat().st_size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest())


def main():
    assert __debug__ and not DEST.exists()
    selection_path = S / 'window-cohort-selection-r1.json'
    selection = read(selection_path)
    assert selection['selected_requests'] == 1212 and not selection['selection_uses_timing']
    cases = [entry['case'] for entry in selection['cases'] if entry['kind'] == 'composition']
    assert len(cases) == 436
    library = N / 'runtime-r1/_native.abi3.so'
    copied = read(N / 'runtime-library-copy-r1.json')
    assert copied['status'] == 'passed' and copied['byte_identical']
    assert copied['destination']['path'] == str(library)
    assert content(library) == dict(bytes=copied['destination']['generation']['bytes'],
        sha256=copied['destination']['sha256'])
    before = identity(library)
    proof = {str(path): content(path) for path in (Path(__file__), selection_path,
        CLIENT / 'shared_window_cases.py', CLIENT / 'shared_window_worker.py',
        N / 'runtime-library-copy-r1.json')}
    result = dict(status='failed', query_executions=0, preparation_calls=0, collect_calls=0,
        sources=proof, library=before, native_library_loaded=True,
        purpose='API construction only; no session, source open, plan preparation or execution')
    try:
        for path in CLIENT.glob('*.py'):
            ast.parse(path.read_text())
        native = load_native(library)
        import shardloom as sl
        client = sl.ShardLoomClient(binary=str(N / 'runtime-r1/shardloom'), transport='native',
            use_persistent_worker=False, memory_bytes=1 << 30, max_parallelism=1, timeout=60)
        try:
            for case in cases:
                worker.validate(case)
                suffix = {'parquet': 'parquet', 'vortex': 'vortex', 'arrow-ipc': 'arrow'}[case['native_format']]
                sources = {'fact': [f'/declared-only/fact.{suffix}']}
                sql = worker.declarations.sql(case, sources)
                assert sql.count(' OVER (') == len(case['declaration']['functions'])
                relation = worker.declarations.native_plan(case, sources, native)
                assert type(relation) is native.Relation
                frame = worker.declarations.dataframe(case, sources, sl, client)
                assert frame.client is client
                assert frame.operations[-1].kind == 'limit'
                assert client._native_backend is None
                assert client._worker_process is None and not client._active_processes
            controls = []
            for label, change in (
                ('changed identity', lambda c: c.update(case_identity='0'*64)),
                ('changed id', lambda c: c.update(id='unknown')),
                ('changed surface', lambda c: c.update(surface='unknown')),
                ('changed frame', lambda c: c['declaration']['frame'].update(preceding=99)),
                ('changed original', lambda c: c['original_case'].update(case_identity='0'*64)),
            ):
                changed = copy.deepcopy(cases[0])
                change(changed)
                try:
                    worker.validate(changed)
                except ValueError:
                    controls.append(label)
                else:
                    raise AssertionError('invalid declaration admitted: ' + label)
            assert len(controls) == 5
        finally:
            client.close()
        assert identity(library) == before
        assert all(content(Path(path)) == item for path, item in proof.items())
        result.update(status='passed_public_declaration_construction', composed_cases=436,
            sql_declarations=436, typed_declarations=436, dataframe_declarations=436,
            rejected_corruptions=controls, native_execution_and_result_validation='not_executed')
    except BaseException as error:
        result['error'] = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        with DEST.open('x') as stream:
            json.dump(result, stream, indent=2)
            stream.write('\n')
    print(json.dumps({key: result[key] for key in ('status', 'composed_cases', 'query_executions',
        'preparation_calls', 'collect_calls')}))


if __name__ == '__main__':
    main()
