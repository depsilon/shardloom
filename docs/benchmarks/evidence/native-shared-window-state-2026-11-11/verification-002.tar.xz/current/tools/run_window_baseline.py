"""Admit the fixed window baseline after hosted index closeout and diagnostics.

The draft cannot execute until explicitly placed in the new task's tools folder.
The accepted release runtime is reused; only 1024 missing observations execute.
"""
from contextlib import ExitStack
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys

S = Path('/Users/dylan/LocalData/shardloom/shared-operator-state-2026-11-10')
sys.path.insert(0, str(S / 'window-tools-draft'))
import window_admission as admission_proof
import window_replay as proof
from window_replay import CLIENT, D, E, FROZEN, N, W, content, database, digest, read
from window_admission import OUT, SELECTION, PREFLIGHT, CLOSEOUT, TREE
import capture_window_cohort as capture
from query_surface.evidence import identity
from query_surface.expanded_freeze import unpack
from query_surface.expanded_report import raw_files
from query_surface.expanded_run import request, verify

TARGET = OUT / 'baseline-missing-r1'
PROTOCOL = OUT / 'baseline-protocol-r1.json'
REUSE = OUT / 'baseline-reuse-r1.json'
REFERENCE = S / 'window-reference-r2/expectations.sqlite'
WORKER = CLIENT / 'shared_window_worker.py'
DIAGNOSTICS = OUT / 'baseline-diagnostics-r1.json'
TOOLS = S / 'window-tools-draft'


def prospective_contract():
    return dict(schema='shardloom.compatible_window_candidate_contract.v1',
        stage='fixed_before_candidate_implementation_and_scored_observation',
        boundary='resident evaluator; existing group and partition order',
        groups="contiguous frames in the existing group's declared function sequence; never skip an incompatible or non-frame member; preserve existing group order",
        families=['ordinary SUM/AVG with arithmetic-first compatible COUNT(value)',
            'single-input variance and standard-deviation variants'],
        identity=['same bound input key, column and domain', 'same filter key',
            'same complete frame unit/bounds/exclusion/order/direction/null ordering',
            'exact offset variants and values; floating offsets compare bits',
            'calendar amount and existing Kernel::same_semantics',
            'same primary numeric input semantics; member-specific pure decimal output policy'],
        state='reuse the existing admitted owner; preserve State size, numerical algorithm and observation order',
        moments='reuse the existing aligned cover and one local Copy summary; no retained extra summary',
        output='all declared output columns still materialize; fixed-size pure numeric finalizers',
        errors='remember only earliest failing secondary index, discard its diagnostic, continue earlier members; primary error wins; after primary success drop shared state and evaluate the ordinary suffix in declaration order',
        cancellation='poll before shared work and at most every 1024 companion outputs; retain final cancellation checks',
        excluded=['COUNT-first observation sharing', 'COUNT(*)', 'DISTINCT',
            'paired moments', 'quantiles', 'collections', 'stored/spilled function fusion'],
        diagnostics=dict(configuration='debug-test only; absent from ordinary release execution',
            complete_requests=33, calendar_controls=16, error_controls=18,
            input_sizes=[17, 4097], wide_outputs=1041,
            counters=['frame bounds', 'state admission attempts and admitted bytes',
                'moment-state admission attempts and admitted bytes', 'add/remove attempts',
                'additive and moment value observations', 'state and moment finalizers',
                'resident frame writes', 'shared groups and outputs',
                'exceptional suffix functions', 'companion cancellation checks'],
            controls=['one-output paths', 'COUNT-first and COUNT(*) boundaries',
                'key/filter/frame/ranking interruptions', 'filters/exclusions/all-null',
                'decimal output error ordering', 'calendar retreat',
                'strict and extended nonfinites, native result bits and finite recovery',
                'actual stored scheduling', 'denial/cancellation/refund/retry',
                '2049-output cancellation before publication'],
            comparison='independent complete values/schema/certificates and exact count reductions; no CPU-share claim',
            state_bytes='cumulative admitted ownership and actual peak credits reported separately'),
        candidate_count=1, tuning='no cases, eligibility or constants changed after scored observations',
        acceptance='all 1212 fixed cases correct and resource/ownership/no-fallback checks pass; strictly lower total engine time retains; equal or higher drops',
        separate_work=['rolling-DISTINCT reclamation', 'paired/quantile/stored sharing'],
        complete_10k_performance_claim=False, full43_claim=False)


def diagnostics_sources():
    """Require the independently replayed baseline diagnostic report and bindings."""
    report = read(DIAGNOSTICS)
    assert report['schema'] == 'shardloom.compatible_window_baseline_diagnostics.v1'
    assert report['status'] == 'passed_baseline_diagnostics'
    assert report['accepted_head'] == admission_proof.HEAD
    assert report['accepted_tree'] == TREE
    assert report['diagnostic_requests'] == 33
    assert report['calendar_controls'] == 16
    assert report['error_controls'] == 18
    assert report['complete_values_and_schema_match'] and report['all_credit_refunds_passed']
    assert report['ordinary_algorithm_unchanged'] and report['release_runtime_unchanged']
    assert report['regressions_passed'] and report['wide_cancellation_passed']
    assert not report['performance_claim']
    assert report['native_query_executions_during_verification'] == 0
    assert report['all_build_inputs_reconstructed_from_restored_accepted_tree']
    assert len(report['rejected_corruptions']) == 13
    sources = [DIAGNOSTICS]
    for name, expected in report['files'].items():
        path = Path(name)
        assert path.is_absolute() and (path.is_relative_to(OUT) or path.is_relative_to(S)
            or path == CLOSEOUT or path == N / 'tools/guard_shared_index.py'
            or path == D / 'dictionary-repair-closeout-r1.json'
            or (path.parent == N and path.name.startswith('window-baseline-')))
        assert content(path) == expected
        sources.append(path)
    assert len(sources) > 10
    import window_work_contract as work
    verify([report['attribution_observations'], report['regression_log']])
    observations = Path(report['attribution_observations']['path'])
    regression_log = Path(report['regression_log']['path'])
    assert str(observations) in report['files'] and str(regression_log) in report['files']
    assert work.baseline(read(observations), regression_log.read_text()) == report['work_contract']
    return sources


def reference_sources(checked):
    path = S / 'window-reference-r2/complete.json'
    assert content(path) == checked['source_files'][str(path)]
    report = read(path)
    assert report['status'] == 'passed_independent_references'
    assert report['native_query_executions'] == 0 and not report['native_runtime_loaded']
    assert report['cases'] == 436 and report['profiles_count'] == 4
    assert report['input_and_client_hashes_unchanged']
    assert report['expected']['path'] == str(REFERENCE)
    assert report['client'] == identity(CLIENT / 'shared_window_cases.py')
    verify([report['expected']])
    for source in [REFERENCE, WORKER, CLIENT / 'shared_window_cases.py',
            TOOLS / 'window_replay.py', TOOLS / 'capture_window_cohort.py']:
        assert content(source) == checked['source_files'][str(source)]
    return [path, REFERENCE, CLIENT / 'shared_window_cases.py', WORKER]


def preflight_sources():
    sources = []
    for relative, expected_status, count_field, count in (
        ('window-public-declaration-check-r1.json', 'passed_public_declaration_construction',
            'composed_cases', 436),
        ('window-admission-preflight-r1.json', 'passed_input_and_supervisor_preflight',
            'selected_requests', 1212),
    ):
        path = S / relative
        report = read(path)
        assert report['status'] == expected_status and report[count_field] == count
        assert report.get('query_executions', report.get('native_query_executions')) == 0
        sources.append(path)
        for name, expected in report['sources'].items():
            assert content(Path(name)) == expected
            sources.append(Path(name))
    declarations = read(S / 'window-public-declaration-check-r1.json')
    assert declarations['sql_declarations'] == declarations['typed_declarations'] == declarations['dataframe_declarations'] == 436
    assert len(declarations['rejected_corruptions']) == 5
    inputs = read(S / 'window-admission-preflight-r1.json')
    assert len(inputs['rejected_binding_corruptions']) == 7
    assert inputs['supervision']['unchanged_parser_resources_environment_supervisor']
    assert inputs['supervision']['unchanged_final_hash_drain_reap_receipts']
    assert content(OUT / 'tools/guard_shared_window.py') == inputs['supervision']['versioned']
    return sources


def context():
    proof.verify_capture()
    runtime, closeout, sources = admission_proof.accepted_runtime()
    design, original_inputs, prepared, frozen, historical = admission_proof.inputs_and_client()
    selection, checked, reused, missing = admission_proof.selected_cases(design)
    assert checked['runtime'] == runtime
    sources += diagnostics_sources() + reference_sources(checked) + preflight_sources()
    sources += [SELECTION, PREFLIGHT, Path(checked['retained_saved_attempts']['path']),
        Path(__file__), OUT / 'tools/guard_shared_window.py', OUT / 'tools/replay_window_baseline.py',
        TOOLS / 'capture_window_cohort.py', TOOLS / 'window_replay.py',
        TOOLS / 'window_admission.py', TOOLS / 'window_work_contract.py',
        TOOLS / 'window_baseline_sources.py',
        D / 'tools/capture_correctness_cohort_r1.py',
        E / 'tools/run_investigation_cohort_r2.py',
        E / 'native-preparation/complete.json', S / 'window-composition-design-r1.json',
        S / 'window-public-declaration-check-r1.json', S / 'window-admission-preflight-r1.json',
        S / 'tools/frozen_generation_binding.py', S / 'baseline-generation-binding-r1.json']
    sources += [S / name for name in ('window-preparation.md', 'window-provider-review-r1.md',
        'window-contract-review-r2.md', 'window-error-replay-proposal-r1.md')]
    sources.append(S / 'window-candidate-tests-draft/native_relational_window_shared_identity_tests.rs')
    proof_files = [identity(path) for path in sorted(set(sources))]
    unique = {}
    for item in [*frozen, *proof_files, *runtime.values()]:
        if item['path'] in unique:
            assert item == unique[item['path']], item['path']
        unique[item['path']] = item
    frozen = list(unique.values())
    verify(frozen)
    return dict(design=design, inputs=dict(original_inputs, runtime=runtime), prepared=prepared,
        runtime=runtime, closeout=closeout, selection=selection, checked=checked,
        reused=reused, missing=missing, frozen=frozen, proof_files=proof_files,
        historical=historical)


def references(stack, selection):
    result = {profile: stack.enter_context(database(E / ('reference-' + profile) / 'expectations.sqlite'))
        for profile in {row['case']['profile'] for row in selection['cases']}}
    result['composition'] = stack.enter_context(database(REFERENCE))
    return result


def case_reference(refs, selected, cases):
    case = selected['case']
    item = cases.item(case)
    reference = refs['composition' if selected['kind'] == 'composition' else case['profile']].execute(
        'SELECT identity,value FROM expected WHERE id=?', (case['id'],)).fetchone()
    assert reference and reference[0] == case['case_identity'] == item.identity
    return item, reference, unpack(reference[1])


def verify_saved_reuse(ctx):
    checked = ctx['checked']
    original = {row['cohort_ordinal']: row for row in checked['reused']}
    assert len(original) == 188
    rows, requests = [], []
    with ExitStack() as stack:
        saved = stack.enter_context(database(Path(checked['retained_saved_attempts']['path'])))
        assert dict(saved.execute('SELECT status,count(*) FROM attempt GROUP BY status')) == {'passed': 188}
        refs, cases = references(stack, ctx['selection']), proof.Cases()
        for selected, declared in zip(ctx['selection']['cases'], checked['requests'], strict=True):
            case = selected['case']
            item, reference, expected = case_reference(refs, selected, cases)
            job = request(case, 'native', ctx['inputs'], ctx['prepared'], expected, ctx['design']['execution'])
            assert digest(job) == declared['request_sha256']
            assert hashlib.sha256(reference[1]).hexdigest() == declared['reference_blob_sha256']
            requests.append(declared)
            if selected['saved_candidate_ordinal'] is None:
                continue
            old = original[selected['cohort_ordinal']]
            source_seq = selected['saved_candidate_ordinal']
            assert old['source_candidate_ordinal'] == source_seq
            entry = saved.execute('SELECT seq,id,status,packet FROM attempt WHERE seq=?', (source_seq,)).fetchone()
            assert entry and entry[:3] == (source_seq, case['id'], 'passed')
            assert old['packet'] == dict(bytes=len(entry[3]), sha256=hashlib.sha256(entry[3]).hexdigest())
            raw = raw_files(unpack(entry[3]))
            assert json.loads(raw['one.job.json']) == job
            assert hashlib.sha256(raw['one.job.json']).hexdigest() == old['raw_job_sha256']
            observed = proof.replay_case(entry, case, expected, item, ctx['inputs'], ctx['prepared'], ctx['design']['execution'])
            assert observed == old['result'] and observed['status'] == 'passed'
            rows.append(dict(old, result=observed))
    assert len(rows) == 188 and len(requests) == 1212
    verify(ctx['frozen'])
    return dict(schema='shardloom.compatible_window_saved_reuse.v1',
        status='verified_saved_observations', query_executions=0,
        selected_reused_cases=188, complete_requests_verified=1212,
        accepted_merge=ctx['closeout']['merge_commit'], accepted_tree=TREE,
        runtime=ctx['runtime'], selection=identity(SELECTION), preflight=identity(PREFLIGHT),
        retained_saved_attempts=checked['retained_saved_attempts'],
        original_ledger_member=checked['original_ledger_member'], rows=rows,
        all_complete_results_correct=True, all_engine_clocks_valid=True,
        no_external_fallback=True, exact_requests_and_expected_results=True,
        original_inputs_and_client_unchanged=True, complete_10k_performance_claim=False)


def admission(root, require_protocol=True):
    assert root == E and __debug__
    ctx = context()
    if require_protocol:
        reused = read(REUSE)
    else:
        assert not any(path.exists() for path in (PROTOCOL, REUSE, TARGET))
        reused = verify_saved_reuse(ctx)
        with REUSE.open('x') as stream:
            json.dump(reused, stream, indent=2, allow_nan=False); stream.write('\n')
    assert reused['status'] == 'verified_saved_observations'
    assert reused['selection'] == identity(SELECTION) and reused['runtime'] == ctx['runtime']
    assert reused['rows'] == ctx['checked']['reused']
    assert reused['retained_saved_attempts'] == ctx['checked']['retained_saved_attempts']
    updated = dict(schema='shardloom.compatible_window_baseline_runtime.v1',
        role='accepted_baseline_missing_cases', accepted_merge=ctx['closeout']['merge_commit'],
        accepted_tree=TREE, source_root=str(W),
        source_fingerprint_sha256=ctx['closeout']['source_fingerprint_sha256'],
        source_binding_note='Original release build identity; the exact accepted tree also includes its verified documentation and diagnostic CI inventory follow-up.',
        accepted_closeout=identity(CLOSEOUT), runtime=ctx['runtime'], proof_files=ctx['proof_files'],
        selection=identity(SELECTION), saved_reuse=identity(REUSE), target=str(TARGET),
        original_worker=identity(FROZEN / 'benchmarks/traditional_analytics/query_surface/expanded_worker.py'),
        versioned_worker=identity(WORKER), composition_reference=identity(REFERENCE),
        frozen_harness_files=65, attempts_per_case=1, warmups=0, requested_repeats=0,
        fallback_allowed=False)
    protocol = dict(schema='shardloom.compatible_window_baseline_protocol.v1',
        status='frozen_before_new_queries', selected_count=1212, original_count=776,
        composed_count=436, reused_count=188, missing_count=1024,
        candidate_contract=prospective_contract(), selection=identity(SELECTION),
        design=identity(E / 'design.json'), inputs=identity(E / 'inputs.json'),
        frozen=identity(E / 'frozen.json'), execution=ctx['design']['execution'],
        runtime_binding=updated, missing_cases=ctx['missing'], reuse=identity(REUSE),
        primary_clock='engine_execution_seconds', attempts_per_case=1, warmups=0,
        requested_repeats=0, selection_uses_timing=False, complete_10k_performance_claim=False,
        baseline_observations='188 exact saved index-candidate observations plus one observation for each of 1024 missing cases; separate sessions, not a new full10k',
        capture_changes=proof.verify_capture(),
        supervision_change='Accepted index closeout/current runtime and retained saved packets replace retired prior runtime/ledgers; existing bounded supervisor, deadlines, workload/storage guards and before/after-only query inventories are preserved.',
        isolation='All other task work and agents idle; no profiling, warmup, cache manipulation or pacing.',
        performance_decision='All 1212 fixed cases; lower complete engine total retains, equal or higher drops after correctness/resource/ownership/no-fallback checks.')
    if require_protocol:
        assert read(PROTOCOL) == protocol
    else:
        with PROTOCOL.open('x') as stream:
            json.dump(protocol, stream, indent=2, allow_nan=False); stream.write('\n')
    frozen = [*ctx['frozen'], identity(REUSE), identity(PROTOCOL)]
    verify(frozen)
    return ctx['design'], ctx['inputs'], frozen, updated


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', action='store_true')
    args = parser.parse_args()
    assert Path(__file__).resolve() == OUT / 'tools/run_window_baseline.py', 'unactivated draft cannot execute'
    os.environ['POLARS_MAX_THREADS'] = '2'
    for path in (OUT, E):
        capture.require_local_path(path, Path.home(), sys.platform)
    if args.plan:
        admission(E, require_protocol=False)
        print(json.dumps(dict(status='frozen_before_new_queries', selected=1212,
            reused=188, missing=1024, query_executions=0)))
    else:
        protocol = read(PROTOCOL)
        capture.TARGET_NAME = str(TARGET)
        capture.observe(E, False, admission, admission_proof.HistoricalSubset(),
            [row['case'] for row in protocol['missing_cases']], worker=WORKER,
            composition_reference=REFERENCE)


if __name__ == '__main__':
    main()
