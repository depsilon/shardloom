"""Collect compact, portable evidence for the single fixed compatible-window candidate."""
from __future__ import annotations

import argparse
import importlib.util
import io
import json
from pathlib import Path
import re
import shutil
import tarfile
import tempfile

from verify_window_packet import (BASE, CHECKS, DOC_CHECKS, REPLAY_SUPPORT, digest, fingerprint, identity,
    replay_saved, rust_counts, verify, verify_ci, verify_diagnostics, verify_sources)

T = Path(__file__).resolve().parents[1]
N = T.parent / 'shared-index-metadata-2026-11-10'
S = N.parent / 'shared-operator-state-2026-11-10'
D = N.parent / 'dictionary-execution-repair-2026-11-10'
K = N.parent / 'variant-expressions-2026-11-10'
E = N.parent / 'expanded-query-2026-11-03'
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')


def read(path):
    return json.loads(path.read_bytes())


def collect(execution_name):
    result = read(T / 'candidate-verified-r1.json')
    assert result['selected_cases'] == 1212 and result['new_attempts'] == 1212
    protocol = read(T / 'candidate-protocol-r1.json')
    baseline = read(T / 'baseline-protocol-r1.json')
    data, locations, external = {}, {}, {}

    def mapped(path):
        if path.parent.name == 'source-blobs' and re.fullmatch(r'[0-9a-f]{64}', path.name):
            return 'source-blobs/' + path.name
        if path.is_relative_to(E / 'investigation-original-harness-r1'):
            relative = path.relative_to(E / 'investigation-original-harness-r1').as_posix()
            if relative in REPLAY_SUPPORT:
                return 'protocol-support/' + relative
        for root, prefix in ((T, 'current'), (N, 'index'), (S, 'preparation'), (D, 'repair'), (K, 'prior'),
                (E / 'investigation-original-harness-r1', 'harness'), (E, 'frozen'),
                (W / 'docs/benchmarks/evidence', 'prior-benchmark-packets'),
                (W / 'docs/release/evidence', 'prior-release-packets'), (W, 'source-imports')):
            if path.is_relative_to(root):
                return prefix + '/' + path.relative_to(root).as_posix()
        raise AssertionError('unclassified proof path: ' + str(path))

    def add(path, name=None):
        name = name or mapped(path)
        assert path.is_file() and not path.is_symlink(), path
        raw = path.read_bytes()
        assert name not in data or data[name] == raw
        assert str(path) not in locations or locations[str(path)] == name
        data[name], locations[str(path)] = raw, name
        return raw

    for path in sorted([*T.glob('*.json'), *T.glob('*.log'), *T.glob('tools/*.py')]):
        if path.name not in (execution_name + '.json', execution_name + '.log'):
            add(path)
    for path in sorted(T.glob('adversarial-review-*.md')):
        add(path)
    add(T / 'window-packet-helper-inventory-r1.md')
    for path in sorted((T / 'debug-retirement-r1').iterdir()):
        add(path)
    for previous in sorted(T.glob('packet-r[0-9]*')):
        if previous.is_dir():
            for name in ('acceptance.json', 'verify.py'):
                path = previous / name
                if path.is_file():
                    add(path)
    for prefix in ('baseline-missing-r1', 'candidate-r1'):
        for name in ('complete.json', 'binding.json', 'attempts.sqlite'):
            add(T / prefix / name)
    for path in sorted(T.glob('*-cases-r1.jsonl.gz')):
        add(path)
    for row in protocol['runtime_binding']['proof_files']:
        path = Path(row['path'])
        wanted = dict(bytes=row['generation']['bytes'], sha256=row['sha256'])
        if path.parent == N / 'runtime-r1':
            assert path.name in ('shardloom', 'lib_native.dylib', '_native.abi3.so')
            role = 'accepted_runtime_identity'
        elif (path.is_relative_to(W / 'docs/release/evidence') or path.is_relative_to(W / 'docs/benchmarks/evidence')) and path.name.endswith('.tar.xz'):
            role = 'historical_committed_archive_identity'
        else:
            assert identity(add(path)) == wanted
            continue
        import hashlib
        with path.open('rb') as stream:
            assert dict(bytes=path.stat().st_size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest()) == wanted
        external[str(path)] = dict(role=role, identity=wanted)
    for path in sorted([*N.glob('window-baseline-*.json'), *N.glob('window-baseline-*.log')]):
        add(path)
    failure_history = read(S / 'window-baseline-failure-dispositions-r1.json')
    add(S / 'window-baseline-failure-dispositions-r1.json')
    for item in failure_history['observations']:
        assert identity(add(Path(item['receipt']['path']))) == {key:item['receipt'][key] for key in ('bytes', 'sha256')}
        assert identity(add(Path(item['log']['path']))) == {key:item['log'][key] for key in ('bytes', 'sha256')}
    for path in sorted((S / 'window-baseline-precloseout-r1').iterdir()):
        if path.is_file():
            add(path)
    for name in ('design.json', 'inputs.json', 'frozen.json', 'native-preparation/complete.json',
                 'investigation-original-harness-source-r1.json'):
        add(E / name)
    frozen = read(E / 'frozen.json')
    for row in frozen['references']:
        assert identity(add(Path(row['path']))) == dict(bytes=row['generation']['bytes'], sha256=row['sha256'])
    manifest = read(E / 'investigation-original-harness-source-r1.json')
    for relative, sha256 in manifest['harness_sha256'].items():
        path = E / 'investigation-original-harness-r1' / relative
        assert digest(add(path)) == sha256
        original = [row for row in frozen['harness'] if row['path'].endswith('/' + relative)]
        assert len(original) == 1 and original[0]['sha256'] == sha256
        locations[original[0]['path']] = 'harness/' + relative
    add(S / 'current-baseline-10k-r1/failed-observation-replay-r1.json')
    wanted = {}
    for name, raw in list(data.items()):
        if not name.endswith('.json'):
            continue
        try:
            record = json.loads(raw)
        except (json.JSONDecodeError, UnicodeDecodeError):
            continue
        if not isinstance(record, dict):
            continue
        for key in ('build_sources', 'tool_source_inventory'):
            for item in record.get(key, {}).values():
                if 'sha256' in item and 'symlink' not in item:
                    assert item['sha256'] not in wanted or wanted[item['sha256']] == item
                    wanted[item['sha256']] = item
        for key in ('source', 'sources'):
            items = record.get(key, [])
            if not isinstance(items, list):
                continue
            for item in items:
                if isinstance(item, dict) and Path(item.get('path', '')).suffix in ('.py', '.rs', '.sh') and 'sha256' in item:
                    size = item.get('bytes', item.get('generation', {}).get('bytes'))
                    assert type(size) is int
                    wanted[item['sha256']] = dict(bytes=size, sha256=item['sha256'])
                    path = Path(item['path'])
                    if path.is_file():
                        assert identity(add(path)) == wanted[item['sha256']]
    existing_bytes = {digest(raw):raw for raw in data.values()}
    predecessor = None
    for sha256, item in sorted(wanted.items()):
        roots = (T, N, S, S / 'window-baseline-precloseout-r1', D, K)
        found = [root / 'source-blobs' / sha256 for root in roots if (root / 'source-blobs' / sha256).is_file()]
        if found:
            raw = add(found[0], 'source-blobs/' + sha256)
        elif sha256 in existing_bytes:
            raw = existing_bytes[sha256]
            data['source-blobs/' + sha256] = raw
        else:
            if predecessor is None:
                root = W / 'docs/benchmarks/evidence/native-shared-index-metadata-2026-11-10'
                spec = importlib.util.spec_from_file_location('accepted_index_packet', root / 'verify.py')
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                _, previous = module.read_archive(root)
                predecessor = {digest(value):value for value in previous.values()}
            raw = predecessor[sha256]
            data['source-blobs/' + sha256] = raw
        assert identity(raw) == item
    build = read(T / 'candidate-release-build-r1.json')
    checks = {name:dict(command=command, status='passed', rust_tests=rust_counts(data['current/' + name + '.log']))
        for name, command in CHECKS.items()}
    dispositions = read(T / 'candidate-failure-dispositions-r1.json')
    failures = []
    for name, raw in sorted(data.items()):
        if not name.startswith('current/') or name.count('/') != 1 or not name.endswith('.json'):
            continue
        record = json.loads(raw)
        if isinstance(record, dict) and (str(record.get('status')).startswith('failed') or record.get('status') == 'interrupted'):
            key = name.removeprefix('current/')
            assert dispositions[key]
            failures.append(dict(receipt=name, identity=identity(raw), disposition=dispositions[key]))
    assert set(dispositions) == {row['receipt'].removeprefix('current/') for row in failures}
    report = dict(schema='shardloom.compatible_window_acceptance.v1', status='local_candidate_decision_recorded',
        source_base=BASE, candidate_source_snapshot=build['build_sources'],
        candidate_source_fingerprint_sha256=fingerprint(build['build_sources']), checks=checks,
        documentation_checks={name:dict(command=command, status='passed',
            rust_tests=rust_counts(data['current/' + name + '.log'])) for name, command in DOC_CHECKS.items()},
        ci_inventory=dict(tests=4134, ignored=35, partitions=4),
        disposition=result['frozen_rule_disposition'], original_failed_checks=failures,
        baseline_failure_history=dict(observations=4, source=identity(data['preparation/window-baseline-failure-dispositions-r1.json'])),
        baseline=dict(cases=1212, reused_saved_cases=188, new_attempts=1024, engine_execution_seconds=340.599417211),
        candidate={key:result[key] for key in ('selected_cases', 'outcomes', 'engine_execution_seconds',
            'engine_seconds_saved', 'observed_engine_reduction_percent', 'complete_performance_result_valid')},
        complete_10k_performance_claim=False, full43_claim=False,
        whole_item_19_complete=False, whole_item_20_complete=False, publication_attempted=False,
        hosted_integration='pending',
        source_policy='Exact validated candidate source; only the named architecture/status prose may advance. A dropped candidate restores accepted baseline source.',
        limitations=[
            'One fixed 1212-case cohort, not a new full10k or Full43 observation or a broad superiority claim.',
            'The baseline explicitly combines 188 saved index cases and 1024 newly measured cases from separate isolated sessions.',
            'The 436 composed arithmetic/moments requests have independent frozen references and distinct identities from the 776 original window controls.',
            'One candidate execution per case; no repeats, warmup, cache manipulation or statistical confidence claim.',
            'Work counters are separate debug-only correctness observations, not scored release CPU-time attribution or a query-peak-memory reduction.',
            'Runtime/input payloads and prior committed archives have exact identities; this packet does not duplicate them for rollback.',
            'The original failed 10000-case observation remains invalid; its original bytes remain in the identified predecessor collection.',
            'Hosted integration, final retention, recommendation10, remaining item19/item20/RFC0044 and CG1through23 remain separate.',
        ], identity_only_proof=dict(sorted(external.items())), locations=dict(sorted(locations.items())),
        members=[dict(path=name, **identity(raw)) for name, raw in sorted(data.items())])
    assert sum(len(raw) for raw in data.values()) < 512 << 20
    return report, data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destination', type=Path, required=True)
    parser.add_argument('--execution-name', required=True)
    parser.add_argument('--preflight-only', action='store_true')
    parser.add_argument('--replay-preflight', action='store_true')
    args = parser.parse_args()
    assert args.destination.resolve().is_relative_to(T) and not args.destination.exists()
    assert re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', args.execution_name)
    assert not args.replay_preflight or args.preflight_only
    report, data = collect(args.execution_name)
    packet = verify_sources(report, data, W)
    if args.preflight_only:
        replay = None
        if args.replay_preflight:
            verify_diagnostics(packet)
            with tempfile.TemporaryDirectory(prefix='window-replay-preflight-', dir=T) as temporary:
                replay = replay_saved(report, data, Path(temporary))
        print(json.dumps(dict(status='passed_collection_preflight', query_executions=0,
            logical_files=len(data), logical_bytes=sum(len(raw) for raw in data.values()),
            archives_written=0, replay=replay)))
        return
    stored, assemblies = {}, []
    for name, raw in sorted(data.items()):
        if len(raw) <= 24 << 20:
            stored[name] = raw
        else:
            parts = []
            for ordinal, offset in enumerate(range(0, len(raw), 24 << 20)):
                part = 'parts/' + digest(name.encode()) + '/' + str(ordinal).zfill(4)
                assert part not in stored
                stored[part] = raw[offset:offset + (24 << 20)]
                parts.append(part)
            assemblies.append(dict(path=name, parts=parts, **identity(raw)))
    report['assemblies'] = assemblies
    report['stored_members'] = [dict(path=name, **identity(raw)) for name, raw in sorted(stored.items())]
    groups, group, total = [], [], 0
    for row in report['stored_members']:
        if group and total + row['bytes'] > 48 << 20:
            groups.append(group)
            group, total = [], 0
        group.append(row)
        total += row['bytes']
    if group:
        groups.append(group)
    args.destination.mkdir()
    report['archives'] = []
    for ordinal, group in enumerate(groups):
        path = args.destination / f'verification-{ordinal + 1:03d}.tar.xz'
        with tarfile.open(path, 'w:xz', preset=6) as archive:
            for row in group:
                entry = tarfile.TarInfo(row['path'])
                entry.size, entry.mode, entry.mtime = row['bytes'], 0o644, 0
                archive.addfile(entry, io.BytesIO(stored[row['path']]))
        raw = path.read_bytes()
        assert len(raw) < 64 << 20
        report['archives'].append(dict(path=path.name, members=[row['path'] for row in group], **identity(raw)))
    (args.destination / 'acceptance.json').write_text(json.dumps(report, indent=2) + '\n')
    shutil.copyfile(T / 'tools/verify_window_packet.py', args.destination / 'verify.py')
    del data, stored
    print(json.dumps(verify(args.destination, W), sort_keys=True))


if __name__ == '__main__':
    main()

