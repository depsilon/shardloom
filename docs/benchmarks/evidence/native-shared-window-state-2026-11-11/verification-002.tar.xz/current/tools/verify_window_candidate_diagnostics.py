"""Verify candidate work reduction against the frozen preimplementation contract.

This checks retained diagnostic observations and successful fixed-source checks;
it neither executes queries nor uses the clean accepted-tree baseline admission.
"""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

OUT = Path('/Users/dylan/LocalData/shardloom/shared-window-state-2026-11-11')
STATE = OUT.parent / 'shared-operator-state-2026-11-10'
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
sys.path.insert(0, str(STATE / 'window-tools-draft'))
import window_work_contract as work
from window_replay import content, digest, read

PROTOCOL_SHA256 = 'b033be339cf37f9d1b8d04059933dc9420829a5173eb59b7a8589448b242b7ab'
MERGE = 'a640475ae66bc36cefcae42088dc23da6776e8ed'
FEATURES = 'shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment'
REGRESSIONS = ['cargo', 'test', '--offline', '--locked', '--workspace', '--lib', '--features',
    FEATURES, 'window', '--', '--show-output', '--test-threads=4']
ATTRIBUTION = ['cargo', 'test', '--offline', '--locked', '--workspace', '--lib', '--features',
    FEATURES, 'native_compatible_window_complete_request_attribution', '--', '--ignored',
    '--show-output', '--test-threads=1']
CLIPPY = ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets',
    '--features', FEATURES, '--', '-D', 'warnings']
FORMAT = ['cargo', 'fmt', '--all', '--', '--check']
IDENTITY_TESTS = [
    'shared_window_identity_admits_only_the_declared_arithmetic_and_single_moment_families',
    'shared_window_identity_keeps_input_filter_frame_and_order_domains_distinct',
    'shared_window_identity_compares_offset_variants_and_exact_numeric_domains',
    'shared_window_identity_uses_exact_calendar_kernel_semantics',
    'shared_window_decimal_finalizer_policy_is_separate_from_observation_identity',
]


def source_inventory():
    paths = set()
    for command in (['git', 'ls-files', '--cached', '-z'],
            ['git', 'ls-files', '--others', '--exclude-standard', '-z']):
        paths.update(value for value in subprocess.check_output(command, cwd=ROOT).decode().split('\0')
            if value and not value.startswith(('.git/', 'docs/benchmarks/evidence/',
                'docs/release/evidence/', 'docs/dependencies/evidence/')) and '.git' not in Path(value).parts)
    result = {}
    for relative in sorted(paths):
        path = ROOT / relative
        if path.is_symlink():
            target = os.readlink(path)
            result[relative] = dict(symlink=target, sha256=hashlib.sha256(os.fsencode(target)).hexdigest())
        elif path.is_file():
            result[relative] = content(path)
        else:
            assert not path.exists(), relative
            result[relative] = dict(absent=True)
    return result


def guarded(path, command, sources):
    assert path.parent == OUT and path.name.startswith('candidate-')
    record = read(path)
    assert record['status'] == 'passed' and record['returncode'] == 0
    assert record['command'] == command and record['cwd'] == str(ROOT)
    assert record['head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    assert record['base'] == record['accepted_baseline_merge'] == MERGE
    assert record['fixed_source_validation'] and not record['allow_lockfile_update']
    assert record['process_group_drained'] and record['direct_child_reaped']
    assert not record['query_workload']
    assert record['build_sources'] == sources
    assert record['build_source_fingerprint_sha256'] == digest(sources)
    for stage in ('pre_execution', 'post_execution'):
        item = record['build_source_verification'][stage]
        assert item['head_matches'] and item['path_set_matches'] and not item['changed_paths']
        assert item['fingerprint_sha256'] == digest(sources)
    driver = OUT / 'tools/guard_shared_window.py'
    assert record['driver_sha256'] == content(driver)['sha256']
    assert record['tool_source_inventory'][str(driver)] == content(driver)
    assert record['log_sha256'] == content(path.with_suffix('.log'))['sha256']
    return record, path.with_suffix('.log').read_text()


def passed_tests(log):
    names = re.findall(r'^test (\S+) \.\.\. ok$', log, re.MULTILINE)
    assert names and len(names) == len(set(names))
    assert not re.search(r'^test .* \.\.\. FAILED$|^test result: FAILED\.', log, re.MULTILINE)
    return names


def rejected_corruptions(old, new, old_log, new_log):
    rejected = []
    mutations = [
        ('omitted request', lambda rows: rows.pop()),
        ('duplicate request', lambda rows: rows.append(copy.deepcopy(rows[0]))),
        ('changed output', lambda rows: rows[0].__setitem__('actual_sha256', '0' * 64)),
        ('unreleased credits', lambda rows: rows[0].__setitem__('final_charged_bytes', 1)),
        ('incomplete source', lambda rows: rows[0].__setitem__('source_exhausted', False)),
        ('fallback', lambda rows: rows[0].__setitem__('no_fallback', False)),
        ('claimed timing', lambda rows: rows[0].__setitem__('engine_timing_claimed', True)),
        ('inflated query peak', lambda rows: rows[0].__setitem__('peak_charged_bytes', (64 << 20) + 1)),
    ]
    for field in ('state_admitted_bytes', 'frame_bound_evaluations', 'state_finalizers',
            'resident_frame_writes', 'shared_groups', 'exceptional_suffix_functions'):
        def change(rows, field=field):
            counts = rows[0]['observations']
            counts['window_' + field] += 1
        mutations.append(('wrong ' + field, change))
    for label, mutate in mutations:
        altered = copy.deepcopy(new)
        mutate(altered['observations'])
        try:
            work.compare(old, altered, old_log, new_log)
        except (AssertionError, KeyError, ValueError):
            rejected.append(label)
        else:
            raise AssertionError('corrupt candidate evidence admitted: ' + label)
    calendar = [line for line in new_log.splitlines() if 'WINDOW_SHARED_CALENDAR_WORK ' in line]
    errors = [line for line in new_log.splitlines() if 'WINDOW_SHARED_ERROR_WORK ' in line]
    variants = [
        ('omitted calendar', [*calendar[1:], *errors]),
        ('duplicate calendar', [*calendar, calendar[0], *errors]),
        ('omitted error', [*calendar, *errors[1:]]),
        ('duplicate error', [*calendar, *errors, errors[0]]),
    ]
    for stored in (False, True):
        prefix = 'WINDOW_SHARED_ERROR_WORK '
        line = next(value for value in errors if json.loads(value[value.index(prefix) + len(prefix):])['stored'] is stored)
        row = json.loads(line[line.index(prefix) + len(prefix):])
        row['observations']['window_exceptional_suffix_functions'] += 1
        variants.append(('wrong stored error work' if stored else 'wrong resident error suffix',
            [*calendar, *(prefix + json.dumps(row) if value == line else value for value in errors)]))
    for label, lines in variants:
        try:
            work.compare(old, new, old_log, '\n'.join(lines))
        except (AssertionError, KeyError, ValueError):
            rejected.append(label)
        else:
            raise AssertionError('corrupt candidate evidence admitted: ' + label)
    assert len(rejected) == 20
    return rejected


def main():
    assert __debug__
    assert Path(__file__).resolve() == OUT / 'tools/verify_window_candidate_diagnostics.py'
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('format', 'clippy', 'regression', 'attribution', 'observations', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    paths = {name: getattr(args, name).resolve() for name in (
        'format', 'clippy', 'regression', 'attribution', 'observations', 'output')}
    assert all(path.parent == OUT and path.name.startswith('candidate-') for path in paths.values())
    assert not paths['output'].exists()
    protocol_path = OUT / 'baseline-protocol-r1.json'
    assert content(protocol_path)['sha256'] == PROTOCOL_SHA256
    protocol = read(protocol_path)
    baseline_path = OUT / 'baseline-diagnostics-r1.json'
    bindings = {item['path']:dict(bytes=item['generation']['bytes'], sha256=item['sha256'])
        for item in protocol['runtime_binding']['proof_files']}
    assert content(baseline_path) == bindings[str(baseline_path)]
    assert content(Path(work.__file__)) == bindings[str(Path(work.__file__))]
    baseline = read(baseline_path)
    assert baseline['status'] == 'passed_baseline_diagnostics'
    assert all(content(Path(name)) == expected for name, expected in baseline['files'].items())
    old_report_path = Path(baseline['attribution_observations']['path'])
    old_log_path = Path(baseline['regression_log']['path'])
    sources = source_inventory()
    # The independent complete-result and failure tests are byte-identical to
    # those run on the accepted baseline. Candidate identity tests are additional.
    for relative, item in baseline['diagnostic_source_changes'].items():
        if relative.endswith(('local_primitive_relational_window_shared_tests.rs',
                'local_primitive_relational_window_shared_attribution_tests.rs',
                'local_primitive_relational_calendar_shared_tests.rs')):
            assert sources[relative] == item['after'], relative
    commands = dict(format=FORMAT, clippy=CLIPPY, regression=REGRESSIONS,
        attribution=['env', 'SHARDLOOM_WINDOW_ATTRIBUTION_OUTPUT=' + str(paths['observations']), *ATTRIBUTION])
    guards, logs = {}, {}
    for name, command in commands.items():
        guards[name], logs[name] = guarded(paths[name], command, sources)
    actual = passed_tests(logs['regression'])
    required = [*baseline['required_tests'], *IDENTITY_TESTS]
    assert len(required) == 29
    for name in required:
        assert sum(item.endswith('::' + name) for item in actual) == 1, name
    diagnostic = passed_tests(logs['attribution'])
    assert len(diagnostic) == 1 and diagnostic[0].endswith('::native_compatible_window_complete_request_attribution')
    inventory = read(ROOT / '.github/ci-native-baseline.json')['ignored_tests']
    assert inventory == sorted(set(inventory)) and inventory.count(diagnostic[0]) == 1
    report = read(paths['observations'])
    prefix = 'WINDOW_SHARED_WORK '
    logged = [json.loads(line[line.index(prefix) + len(prefix):])
        for line in logs['attribution'].splitlines() if prefix in line]
    assert logged == report['observations'] and len(logged) == 33
    old, old_log = read(old_report_path), old_log_path.read_text()
    contract = work.compare(old, report, old_log, logs['regression'])
    controls = rejected_corruptions(old, report, old_log, logs['regression'])
    files = [Path(__file__), Path(work.__file__), protocol_path, baseline_path, old_report_path,
        old_log_path, *[path for name, path in paths.items() if name != 'output'],
        *[paths[name].with_suffix('.log') for name in commands]]
    files.extend(Path(name) for name in baseline['files'])
    proof = {str(path):content(path) for path in sorted(set(files))}
    assert source_inventory() == sources
    assert all(content(Path(name)) == expected for name, expected in proof.items())
    assert not any(name == 'shardloom._native' or name.startswith('shardloom._native.') for name in sys.modules)
    result = dict(schema='shardloom.compatible_window_candidate_diagnostics.v1',
        status='passed_candidate_diagnostics', accepted_merge=MERGE,
        diagnostic_requests=33, calendar_controls=16, error_controls=18,
        work_contract=contract, rejected_corruptions=controls, required_tests=required,
        actual_passed_tests=actual, attribution_test=diagnostic[0], ignored_ci_registered=True,
        diagnostic_source_fingerprint_sha256=digest(sources), files=proof,
        native_query_executions_during_verification=0, engine_timing_claimed=False,
        candidate_acceptance_claimed=False)
    with paths['output'].open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps({key:result[key] for key in ('status', 'diagnostic_requests', 'calendar_controls',
        'error_controls', 'rejected_corruptions', 'native_query_executions_during_verification')}))


if __name__ == '__main__':
    main()
