"""Admit one ordinary release candidate for the immutable 1212-case window cohort.

The baseline, capture loop, workers, references and per-query guards are reused
unchanged. Candidate source/build admission is independent of clean-baseline
admission. Planning and library preparation execute no queries.
"""
from __future__ import annotations
import argparse
import gzip
import json
import math
import os
from pathlib import Path
import shutil
import sys

import run_window_baseline as baseline
import verify_window_candidate_diagnostics as diagnostics
from window_replay import content, digest, read
from query_surface.evidence import identity
from query_surface.expanded_run import verify

OUT, S, N, E, W = baseline.OUT, baseline.S, baseline.N, baseline.E, baseline.W
TARGET = OUT / 'candidate-r1'
PROTOCOL = OUT / 'candidate-protocol-r1.json'
BASELINE_RESULT = OUT / 'baseline-verified-r1.json'
RUNTIME = OUT / 'runtime-r1'
LIBRARY = RUNTIME / '_native.abi3.so'
BUILD = OUT / 'candidate-release-build-r1.json'
CHECKS = OUT / 'candidate-source-checks-r1.json'
DIAGNOSTICS = OUT / 'candidate-diagnostics-r1.json'
BASELINE_RESULT_SHA256 = 'eda8443b6f68b9c19a3499088d55c625043846650071990a1a8e7264fe799884'
BUILD_COMMAND = ['env', 'PYO3_PYTHON=/opt/homebrew/opt/python@3.13/libexec/bin/python3',
    'cargo', 'build', '--offline', '--locked', '--release', '--features', 'release-user-surfaces',
    '-p', 'shardloom-cli', '-p', 'shardloom-python']
CHECK_COMMANDS = {
    'format': diagnostics.FORMAT,
    'default_clippy': ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings'],
    'default_tests': ['env', 'RUST_TEST_THREADS=4', 'cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets'],
    'native_clippy': diagnostics.CLIPPY,
    'native_tests': ['env', 'RUST_TEST_THREADS=4', 'cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets',
        '--features', diagnostics.FEATURES],
    'regression': diagnostics.REGRESSIONS,
    'attribution': ['env', 'SHARDLOOM_WINDOW_ATTRIBUTION_OUTPUT=' + str(OUT / 'candidate-attribution-observations-r1.json'),
        *diagnostics.ATTRIBUTION],
}


def baseline_proof():
    assert content(baseline.PROTOCOL)['sha256'] == diagnostics.PROTOCOL_SHA256
    assert content(BASELINE_RESULT)['sha256'] == BASELINE_RESULT_SHA256
    protocol, result = read(baseline.PROTOCOL), read(BASELINE_RESULT)
    assert result['status'] == 'passed_complete_baseline_cohort'
    assert result['selected_cases'] == 1212 and result['original_controls'] == 776 and result['new_compositions'] == 436
    assert result['reused_saved_cases'] == 188 and result['new_attempts'] == 1024
    assert result['outcomes'] == {'passed': 1212} and result['complete_performance_result_valid']
    assert result['all_selected_results_correct'] and result['all_engine_clocks_valid'] and result['native_no_fallback']
    assert result['primary_clock'] == 'engine_execution_seconds'
    assert not result['complete_10k_performance_claim'] and not result['full43_claim']
    assert result['protocol'] == identity(baseline.PROTOCOL)
    assert result['runtime_binding'] == protocol['runtime_binding']
    assert result['selection'] == protocol['selection'] == identity(baseline.SELECTION)
    verify([result[key] for key in ('case_rows', 'guard', 'complete', 'ledger', 'reuse')])
    selected = read(baseline.SELECTION)['cases']
    with gzip.open(result['case_rows']['path'], 'rt') as stream:
        rows = [json.loads(line) for line in stream]
    assert len(rows) == len(selected) == 1212
    for ordinal, (row, case) in enumerate(zip(rows, selected, strict=True)):
        assert row['cohort_ordinal'] == ordinal and row['original_seq'] == case['original_seq']
        assert row['id'] == case['case']['id'] and row['case_identity'] == case['case']['case_identity']
        assert row['result']['status'] == 'passed'
        seconds = row['result']['engine_seconds']
        assert type(seconds) in (int, float) and math.isfinite(seconds) and seconds >= 0
    assert math.fsum(row['result']['engine_seconds'] for row in rows) == result['engine_execution_seconds']
    assert result['engine_execution_seconds'] == 340.599417211
    guard = read(OUT / 'baseline-missing-r1.json')
    assert guard['status'] == 'passed' and guard['returncode'] == 0
    assert guard['head'] == guard['base'] == diagnostics.MERGE and not guard['working_tree']
    assert guard['query_workload'] and guard['process_group_drained'] and guard['direct_child_reaped']
    assert guard['build_inventory_policy'] == guard['evidence_inventory_policy'] == 'before_and_after_only'
    assert guard['log_sha256'] == content(OUT / 'baseline-missing-r1.log')['sha256']
    files = [baseline.PROTOCOL, BASELINE_RESULT, baseline.REUSE, OUT / 'baseline-cases-r1.jsonl.gz',
        OUT / 'baseline-missing-r1.json', OUT / 'baseline-missing-r1.log',
        OUT / 'baseline-missing-r1/complete.json', OUT / 'baseline-missing-r1/binding.json',
        OUT / 'baseline-missing-r1/attempts.sqlite', OUT / 'baseline-replay-r1.json', OUT / 'baseline-replay-r1.log']
    for item in protocol['runtime_binding']['proof_files']:
        assert identity(Path(item['path'])) == item
        files.append(Path(item['path']))
    return protocol, result, files


def runtime_proof():
    assert __debug__
    sources = diagnostics.source_inventory()
    build, _ = diagnostics.guarded(BUILD, BUILD_COMMAND, sources)
    checked = read(CHECKS)
    assert checked['schema'] == 'shardloom.compatible_window_candidate_checks.v1'
    assert set(checked['checks']) == set(CHECK_COMMANDS)
    assert checked['source_head'] == build['head']
    assert checked['source_fingerprint_sha256'] == digest(sources)
    files = [BUILD, BUILD.with_suffix('.log'), CHECKS, DIAGNOSTICS]
    for name, command in CHECK_COMMANDS.items():
        path = Path(checked['checks'][name])
        diagnostics.guarded(path, command, sources)
        files.extend((path, path.with_suffix('.log')))
    report = read(DIAGNOSTICS)
    assert report['status'] == 'passed_candidate_diagnostics'
    assert report['diagnostic_source_fingerprint_sha256'] == digest(sources)
    assert report['native_query_executions_during_verification'] == 0
    assert report['ignored_ci_registered'] and not report['candidate_acceptance_claimed']
    for name, expected in report['files'].items():
        assert content(Path(name)) == expected
        files.append(Path(name))
    old = read(baseline.DIAGNOSTICS)
    old_rows = read(Path(old['attribution_observations']['path']))
    old_log = Path(old['regression_log']['path']).read_text()
    new_rows = read(OUT / 'candidate-attribution-observations-r1.json')
    new_log = Path(checked['checks']['regression']).with_suffix('.log').read_text()
    assert diagnostics.work.compare(old_rows, new_rows, old_log, new_log) == report['work_contract']
    assert diagnostics.rejected_corruptions(old_rows, new_rows, old_log, new_log) == report['rejected_corruptions']
    native_tests = diagnostics.passed_tests(Path(checked['checks']['native_tests']).with_suffix('.log').read_text())
    for name in report['required_tests']:
        assert sum(value.endswith('::' + name) for value in native_tests) == 1, name
    ci_path = OUT / 'candidate-ci-inventory-r1.json'
    ci = read(ci_path)
    assert ci['status'] == 'passed_actual_native_inventory' and ci['exact_ignored_ownership']
    assert ci['query_executions'] == 0 and ci['source_fingerprint_sha256'] == digest(sources)
    assert len(ci['ignored']) == 35 and ci['ignored'] == read(W / '.github/ci-native-baseline.json')['ignored_tests']
    for name, expected in ci['files'].items():
        assert content(Path(name)) == expected
        files.append(Path(name))
    ci_guard = OUT / 'candidate-ci-verification-r3.json'
    diagnostics.guarded(ci_guard, ['/opt/homebrew/opt/python@3.13/libexec/bin/python3', '-B',
        str(OUT / 'tools/verify_window_ci_inventory.py'), '--build', str(OUT / 'candidate-ci-build-r1.json'),
        '--output', str(ci_path)], sources)
    files.extend((ci_path, ci_guard, ci_guard.with_suffix('.log')))
    record_path = OUT / 'runtime-r1-identity.json'
    record = read(record_path)
    assert record['status'] == 'passed' and record['profile'] == 'release'
    assert record['build_receipt'] == BUILD.name and record['build_receipt_identity'] == content(BUILD)
    assert record['build_source_fingerprint_sha256'] == digest(sources)
    runtime = {Path(item['path']).name:item for item in record['files']}
    assert set(runtime) == {'shardloom', 'lib_native.dylib'}
    for name, item in runtime.items():
        assert Path(item['path']) == RUNTIME / name
        assert content(Path(item['path'])) == {key:item[key] for key in ('bytes', 'sha256')}
    freeze_guard = OUT / 'candidate-freeze-runtime-r1.json'
    freeze_command = ['/opt/homebrew/opt/python@3.13/libexec/bin/python3', '-B',
        str(OUT / 'tools/freeze_runtime.py'), '--build', BUILD.name, '--name', 'runtime-r1', '--profile', 'release']
    diagnostics.guarded(freeze_guard, freeze_command, sources)
    files.extend((record_path, freeze_guard, freeze_guard.with_suffix('.log'), OUT / 'tools/freeze_runtime.py'))
    return build, files


def prepare_library():
    runtime_proof()
    source = RUNTIME / 'lib_native.dylib'
    receipt = OUT / 'runtime-library-copy-r1.json'
    assert not LIBRARY.exists() and not receipt.exists()
    expected = content(source)
    shutil.copy2(source, LIBRARY)
    assert content(source) == content(LIBRARY) == expected
    with receipt.open('x') as stream:
        json.dump(dict(status='passed', source=identity(source), destination=identity(LIBRARY),
            byte_identical=True, queries_executed=0), stream, indent=2); stream.write('\n')


def context():
    baseline.proof.verify_capture()
    original_protocol, original_result, files = baseline_proof()
    build, runtime_files = runtime_proof()
    files.extend(runtime_files)
    copied_path = OUT / 'runtime-library-copy-r1.json'
    copied = read(copied_path)
    assert copied['status'] == 'passed' and copied['byte_identical'] and copied['queries_executed'] == 0
    assert copied['source'] == identity(RUNTIME / 'lib_native.dylib')
    assert copied['destination'] == identity(LIBRARY)
    assert content(LIBRARY) == content(RUNTIME / 'lib_native.dylib')
    library_guard = OUT / 'candidate-library-r1.json'
    diagnostics.guarded(library_guard, ['/Users/dylan/.cache/shardloom/query-surface-polars-2.1.0/bin/python',
        '-B', str(Path(__file__)), '--prepare-library'], build['build_sources'])
    runtime = dict(binary=identity(RUNTIME / 'shardloom'), library=identity(LIBRARY))
    design, inputs, prepared, frozen, historical = baseline.admission_proof.inputs_and_client()
    selection, checked, reused, missing = baseline.admission_proof.selected_cases(design)
    assert len(reused) == 188 and len(missing) == 1024
    assert original_protocol['execution'] == design['execution']
    for name in ('design', 'inputs', 'frozen'):
        assert original_protocol[name] == identity(E / (name + '.json'))
    assert original_protocol['runtime_binding']['versioned_worker'] == identity(baseline.WORKER)
    assert original_protocol['runtime_binding']['composition_reference'] == identity(baseline.REFERENCE)
    files.extend(baseline.reference_sources(checked) + baseline.preflight_sources() + baseline.diagnostics_sources())
    files.extend([copied_path, library_guard, library_guard.with_suffix('.log'),
        Path(__file__), OUT / 'tools/replay_window_candidate.py',
        OUT / 'tools/guard_shared_window.py', Path(diagnostics.__file__),
        baseline.SELECTION, baseline.PREFLIGHT, Path(checked['retained_saved_attempts']['path'])])
    proof_files = [identity(path) for path in sorted(set(files))]
    unique = {}
    for item in [*frozen, *proof_files, *runtime.values()]:
        if item['path'] in unique:
            assert unique[item['path']] == item
        unique[item['path']] = item
    frozen = list(unique.values())
    verify(frozen)
    return dict(design=design, inputs=dict(inputs, runtime=runtime), prepared=prepared,
        selected=selection, runtime=runtime, build=build, frozen=frozen,
        proof_files=proof_files, baseline_protocol=original_protocol, baseline_result=original_result,
        historical=historical)


def admission(root, require_protocol=True):
    assert root == E and __debug__
    ctx = context()
    updated = dict(schema='shardloom.compatible_window_candidate_runtime.v1',
        role='single_fixed_cohort_candidate', accepted_base=diagnostics.MERGE,
        source_root=str(W), source_head=ctx['build']['head'],
        source_fingerprint_sha256=ctx['build']['build_source_fingerprint_sha256'],
        runtime=ctx['runtime'], proof_files=ctx['proof_files'], selection=identity(baseline.SELECTION),
        baseline_protocol=identity(baseline.PROTOCOL), target=str(TARGET),
        original_worker=ctx['baseline_protocol']['runtime_binding']['original_worker'],
        versioned_worker=identity(baseline.WORKER), composition_reference=identity(baseline.REFERENCE),
        frozen_harness_files=65, attempts_per_case=1, warmups=0, requested_repeats=0, fallback_allowed=False)
    protocol = dict(schema='shardloom.compatible_window_candidate_protocol.v1',
        status='frozen_before_candidate_queries', selected_count=1212, original_count=776, composed_count=436,
        candidate_contract=ctx['baseline_protocol']['candidate_contract'],
        baseline_protocol=identity(baseline.PROTOCOL), baseline_result=identity(BASELINE_RESULT),
        selection=identity(baseline.SELECTION), design=identity(E / 'design.json'),
        inputs=identity(E / 'inputs.json'), frozen=identity(E / 'frozen.json'),
        execution=ctx['design']['execution'], runtime_binding=updated, cases=ctx['selected']['cases'],
        primary_clock='engine_execution_seconds', attempts_per_case=1, warmups=0, requested_repeats=0,
        selection_uses_timing=False, complete_10k_performance_claim=False, full43_claim=False,
        baseline_observations=ctx['baseline_protocol']['baseline_observations'],
        capture_changes='Unchanged window capture loop, workers, requests, references, clocks, per-query guards and cleanup; all 1212 fixed cases execute once.',
        supervision_change='Same activated window guard, limits and before/after-only full query inventories; independent candidate source/build/check admission.',
        isolation=ctx['baseline_protocol']['isolation'], performance_decision=ctx['baseline_protocol']['performance_decision'])
    if require_protocol:
        assert read(PROTOCOL) == protocol
    else:
        assert not PROTOCOL.exists() and not TARGET.exists()
        with PROTOCOL.open('x') as stream:
            json.dump(protocol, stream, indent=2, allow_nan=False); stream.write('\n')
    frozen = [*ctx['frozen'], identity(PROTOCOL)]
    verify(frozen)
    return ctx['design'], ctx['inputs'], frozen, updated


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--plan', action='store_true')
    mode.add_argument('--prepare-library', action='store_true')
    args = parser.parse_args()
    assert Path(__file__).resolve() == OUT / 'tools/run_window_candidate.py'
    os.environ['POLARS_MAX_THREADS'] = '2'
    for path in (OUT, E):
        baseline.capture.require_local_path(path, Path.home(), sys.platform)
    if args.prepare_library:
        prepare_library()
        print(json.dumps(dict(status='byte_identical_library_copy', query_executions=0)))
    elif args.plan:
        admission(E, require_protocol=False)
        print(json.dumps(dict(status='frozen_before_candidate_queries', selected=1212, query_executions=0)))
    else:
        protocol = read(PROTOCOL)
        baseline.capture.TARGET_NAME = str(TARGET)
        baseline.capture.observe(E, False, admission, baseline.admission_proof.HistoricalSubset(),
            [row['case'] for row in protocol['cases']], worker=baseline.WORKER,
            composition_reference=baseline.REFERENCE)


if __name__ == '__main__':
    main()
