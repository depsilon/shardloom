"""Freeze a guarded build in a new task-owned runtime directory."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--build', required=True)
parser.add_argument('--name', required=True)
parser.add_argument('--profile', choices=('debug', 'release'), required=True)
args = parser.parse_args()
out = Path(__file__).resolve().parents[1]
assert args.name.replace('-', '').isalnum()
assert Path(args.build).name == args.build
build_path = out / args.build
build = json.loads(build_path.read_bytes())
assert build['status'] == 'passed' and build['returncode'] == 0 and build['process_group_drained']
assert ('--release' in build['command']) == (args.profile == 'release')
assert build['build_source_verification']['post_execution']['head_matches']
assert not build['build_source_verification']['post_execution']['changed_paths']
source = Path(build['environment']['CARGO_TARGET_DIR']) / args.profile
destination = out / args.name
assert not destination.exists()
destination.mkdir()

def identity(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        return {'bytes': path.stat().st_size, 'sha256': hashlib.file_digest(stream, 'sha256').hexdigest()}

record = {'status': 'passed', 'profile': args.profile, 'build_receipt': args.build,
    'build_receipt_identity': identity(build_path),
    'build_source_fingerprint_sha256': build['build_source_fingerprint_sha256'], 'files': []}
for name in ('shardloom', 'lib_native.dylib'):
    original, copied = source / name, destination / name
    expected = identity(original)
    shutil.copy2(original, copied)
    assert identity(copied) == expected == identity(original)
    record['files'].append({'path': str(copied), **expected})
with (out / (args.name + '-identity.json')).open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
