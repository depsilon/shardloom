"""Independently replay every saved and newly captured fixed window baseline result."""
from collections import Counter, defaultdict
from contextlib import ExitStack
import gzip
import hashlib
import json
import math
from pathlib import Path

import run_window_baseline as current
from window_replay import content, database, read
from query_surface.evidence import identity
from query_surface.expanded_freeze import unpack
from query_surface.expanded_report import raw_files
from query_surface.expanded_run import verify


def verify_capture_receipts(admitted):
    target = current.TARGET
    done, binding = read(target / 'complete.json'), read(target / 'binding.json')
    assert done['status'] == 'complete_observation' and done['stage'] == 'native'
    assert done['total'] == done['attempt_slots'] == 1024
    assert done['posthash_verified'] and done['attempts_per_case'] == 1 and done['requested_repeats'] == 0
    assert done['updated'] == admitted
    assert binding['contract'] == {key: done[key] for key in ('frozen', 'stage', 'prerequisites', 'updated')}
    assert done['ledger']['path'] == str(target / 'attempts.sqlite')
    assert done['binding']['path'] == str(target / 'binding.json')
    verify([done['ledger'], done['binding'], done['frozen']])
    guard_path = current.OUT / 'baseline-missing-r1.json'
    guard = read(guard_path)
    assert guard['status'] == 'passed' and guard['returncode'] == 0
    assert guard['process_group_drained'] and guard['direct_child_reaped'] and guard['query_workload']
    assert guard['head'] == guard['base'] == admitted['accepted_merge'] and not guard['working_tree']
    assert guard['active_output'] == str(target)
    assert guard['fixed_source_validation'] and not guard['allow_lockfile_update']
    assert guard['build_inventory_policy'] == guard['evidence_inventory_policy'] == 'before_and_after_only'
    assert guard['accepted_baseline_merge'] == admitted['accepted_merge']
    assert guard['accepted_index_closeout']['sha256'] == identity(current.CLOSEOUT)['sha256']
    # The accepted tree includes the already-verified documentation and CI
    # inventory follow-up to the release build. Exact clean HEAD/tree plus the
    # accepted closeout bind that source; their whole-tree digests need not equal.
    assert guard['accepted_baseline_source_fingerprint_sha256'] == admitted['source_fingerprint_sha256']
    assert guard['command'] == ['/Users/dylan/.cache/shardloom/query-surface-polars-2.1.0/bin/python',
        '-B', str(current.OUT / 'tools/run_window_baseline.py')]
    assert guard['log_sha256'] == content(guard_path.with_suffix('.log'))['sha256']
    return done, guard_path


def main():
    assert __debug__
    assert Path(__file__).resolve() == current.OUT / 'tools/replay_window_baseline.py', 'unactivated draft cannot execute'
    destination = current.OUT / 'baseline-verified-r1.json'
    cases_path = current.OUT / 'baseline-cases-r1.jsonl.gz'
    partial = current.OUT / 'baseline-cases-r1.partial.jsonl.gz'
    lock = current.OUT / '.baseline-replay-r1.lock'
    assert not any(path.exists() for path in (destination, cases_path, partial, lock))
    design, inputs, frozen, admitted = current.admission(current.E)
    protocol = read(current.PROTOCOL)
    selection, checked, reuse = (read(path) for path in (current.SELECTION, current.PREFLIGHT, current.REUSE))
    done, guard_path = verify_capture_receipts(admitted)
    reused = {row['cohort_ordinal']: row for row in reuse['rows']}
    missing = {row['cohort_ordinal']: (ordinal, row) for ordinal, row in enumerate(protocol['missing_cases'])}
    assert len(reused) == 188 and len(missing) == 1024 and not set(reused).intersection(missing)
    assert set(reused) | set(missing) == set(range(1212))
    assert reuse['all_complete_results_correct'] and reuse['all_engine_clocks_valid']
    assert reuse['no_external_fallback'] and reuse['exact_requests_and_expected_results']
    prepared = read(current.E / 'native-preparation/complete.json')
    outcomes, new_outcomes = Counter(), Counter()
    families, values, failures = defaultdict(list), [], []
    with lock.open('x'):
        pass
    with ExitStack() as stack:
        db = stack.enter_context(database(current.TARGET / 'attempts.sqlite'))
        saved = stack.enter_context(database(Path(reuse['retained_saved_attempts']['path'])))
        entries = iter(db.execute('SELECT seq,id,status,packet FROM attempt ORDER BY seq'))
        assert dict(saved.execute('SELECT status,count(*) FROM attempt GROUP BY status')) == {'passed': 188}
        refs, cases = current.references(stack, selection), current.proof.Cases()
        output = stack.enter_context(gzip.open(partial, 'wt', encoding='utf-8'))
        for ordinal, (selected, declaration) in enumerate(zip(selection['cases'], checked['requests'], strict=True)):
            case = selected['case']
            assert selected['cohort_ordinal'] == declaration['cohort_ordinal'] == ordinal
            item, reference, expected = current.case_reference(refs, selected, cases)
            assert hashlib.sha256(reference[1]).hexdigest() == declaration['reference_blob_sha256']
            if ordinal in reused:
                previous = reused[ordinal]
                assert previous['original_seq'] == selected['original_seq']
                assert previous['id'] == case['id'] and previous['case_identity'] == case['case_identity']
                source_seq = previous['source_candidate_ordinal']
                assert source_seq == selected['saved_candidate_ordinal']
                entry = saved.execute('SELECT seq,id,status,packet FROM attempt WHERE seq=?', (source_seq,)).fetchone()
                ledger_path = reuse['retained_saved_attempts']['path']
                origin = 'saved_index_candidate'
            else:
                source_seq, wanted = missing[ordinal]
                assert wanted == selected
                entry = next(entries, None)
                ledger_path = done['ledger']['path']
                origin = 'new_missing_baseline'
            assert entry and entry[:2] == (source_seq, case['id'])
            observed = current.proof.replay_case(entry, case, expected, item, inputs, prepared, design['execution'])
            assert observed['status'] == entry[2]
            files = raw_files(unpack(entry[3])) if entry[3] is not None else {}
            packet_identity = (dict(bytes=len(entry[3]), sha256=hashlib.sha256(entry[3]).hexdigest())
                if entry[3] is not None else None)
            job_sha = hashlib.sha256(files['one.job.json']).hexdigest() if files else None
            if files:
                assert current.digest(json.loads(files['one.job.json'])) == declaration['request_sha256']
            if ordinal in reused:
                assert observed == previous['result'] and observed['status'] == 'passed'
                assert packet_identity == previous['packet'] and job_sha == previous['raw_job_sha256']
            else:
                new_outcomes[observed['status']] += 1
            provenance = dict(source=origin, ledger=ledger_path, source_seq=source_seq,
                packet=packet_identity, job_sha256=job_sha,
                independent_expected_blob_sha256=hashlib.sha256(reference[1]).hexdigest())
            outcomes[observed['status']] += 1
            if observed['status'] == 'passed':
                elapsed = observed['engine_seconds']
                assert type(elapsed) in (int, float) and math.isfinite(elapsed) and elapsed >= 0
                values.append(elapsed)
                families[case['family']].append(elapsed)
            else:
                failures.append(dict(cohort_ordinal=ordinal, original_seq=selected['original_seq'],
                    id=case['id'], status=observed['status'], detail=observed.get('failure_detail')))
            output.write(json.dumps(dict(cohort_ordinal=ordinal, original_seq=selected['original_seq'],
                kind=selected['kind'], id=case['id'], case_identity=case['case_identity'],
                family=case['family'], profile=case['profile'], surface=case['surface'],
                native_format=case['native_format'], provenance=provenance, result=observed),
                separators=(',', ':'), allow_nan=False) + '\n')
        assert next(entries, None) is None
    assert dict(new_outcomes) == done['outcomes'] and sum(new_outcomes.values()) == 1024
    assert sum(outcomes.values()) == 1212
    verify([*frozen, done['ledger'], done['binding'], done['frozen'], reuse['retained_saved_attempts']])
    partial.rename(cases_path)
    passed = outcomes == {'passed': 1212}
    result = dict(schema='shardloom.compatible_window_baseline_cohort.v1',
        status='passed_complete_baseline_cohort' if passed else 'failed_baseline_cohort',
        query_executions_during_replay=0, accepted_merge=admitted['accepted_merge'], accepted_tree=current.TREE,
        selected_cases=1212, original_controls=776, new_compositions=436,
        reused_saved_cases=188, new_attempts=1024, outcomes=dict(outcomes), new_outcomes=dict(new_outcomes),
        attempts_per_case=1, warmups=0, requested_repeats=0, primary_clock='engine_execution_seconds',
        engine_execution_seconds=math.fsum(values) if passed else None,
        complete_performance_result_valid=passed, all_selected_results_correct=passed,
        all_engine_clocks_valid=passed, native_no_fallback=passed, failures=failures,
        families={name: dict(cases=len(rows), engine_execution_seconds=math.fsum(rows))
            for name, rows in sorted(families.items())},
        protocol=identity(current.PROTOCOL), selection=identity(current.SELECTION), reuse=identity(current.REUSE),
        complete=identity(current.TARGET / 'complete.json'), ledger=done['ledger'], guard=identity(guard_path),
        case_rows=identity(cases_path), verifier=identity(Path(__file__)), runtime_binding=admitted,
        performance_claim=False, complete_10k_performance_claim=False, full43_claim=False,
        limitations=['Fixed 1212-case cohort; original controls and new compositions retain separate identities.',
            '188 saved and 1024 newly captured observations are explicitly separate sessions.',
            'Original failed 10k observation is preserved and has no valid complete performance total.'])
    with destination.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False); stream.write('\n')
    lock.unlink()
    print(json.dumps({key: result[key] for key in ('status', 'selected_cases', 'reused_saved_cases',
        'new_attempts', 'outcomes', 'engine_execution_seconds', 'complete_10k_performance_claim')}))
    assert passed, 'complete baseline failed; every observation remains retained'


if __name__ == '__main__':
    main()
