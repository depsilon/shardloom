"""Bind baseline work counts to actual successful tests and diagnostic-only source."""
import argparse
import copy
import json
from pathlib import Path
import re
import sys

S = Path('/Users/dylan/LocalData/shardloom/shared-operator-state-2026-11-10')
sys.path.insert(0, str(S / 'window-tools-draft'))
import window_admission as admission
import window_baseline_sources as source
import window_work_contract as work
from window_replay import D, N, W, content, read
from query_surface.evidence import identity
from query_surface.expanded_run import verify

OUT = admission.OUT
FEATURES = 'shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment'
REGRESSIONS = ['cargo', 'test', '--offline', '--locked', '--workspace', '--lib', '--features',
    FEATURES, 'window', '--', '--show-output', '--test-threads=4']
ATTRIBUTION = ['cargo', 'test', '--offline', '--locked', '--workspace', '--lib', '--features',
    FEATURES, 'native_compatible_window_complete_request_attribution', '--', '--ignored',
    '--show-output', '--test-threads=1']
CLIPPY = ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets',
    '--features', FEATURES, '--', '-D', 'warnings']
FORMAT = ['cargo', 'fmt', '--all', '--', '--check']
OLD_CONTROLS = [
    'native_window_frames_match_independent_membership_with_peers_exclusions_and_chunks',
    'native_window_frames_defaults_empty_intervals_and_extreme_offsets',
    'native_window_frames_float_removal_oversized_means_and_range_rounding',
    'native_window_frames_cancellation_denied_grants_and_retry_release_state',
    'native_window_frames_count_and_excluded_values_do_not_eagerly_validate_observations',
    'native_window_frames_selected_output_retains_native_ownership_after_plan_drop',
    'ordered_window_error_order_follows_groups_partitions_functions_and_final_selection',
    'native_statistical_windows_match_independent_rows_groups_range_and_exclusion_membership',
    'native_statistical_windows_preserve_scaled_tiny_and_large_finite_results',
    'native_statistical_windows_observe_only_selected_values_and_clean_up_failure',
    'native_statistical_windows_pressure_cancellation_and_retry_release_state',
    'statistical_window_cover_has_bounded_state_and_avoids_reobserving_each_full_frame',
]


def guarded(path, command, closeout):
    assert path.parent == N and path.name.startswith('window-baseline-') and path.is_file()
    result = read(path)
    assert result['status'] == 'passed' and result['returncode'] == 0
    assert result['fixed_source_validation'] and not result['allow_lockfile_update']
    assert result['process_group_drained'] and result['direct_child_reaped']
    assert not result['query_workload']
    assert result['head'] == closeout['merge_commit']
    # Correctness checks ran before index retirement, using the unchanged prior
    # resource supervisor. Its accepted anchor is explicitly the dictionary merge;
    # it never establishes index main acceptance. The completed index closeout and
    # complete build-input reconstruction below supply that separate proof.
    assert result['base'] == result['accepted_baseline_merge'] == '037b6801320aa0bfe939ba10aed9304198b77a5a'
    assert result['accepted_dictionary_closeout'] == dict(path=str(D / 'dictionary-repair-closeout-r1.json'),
        **content(D / 'dictionary-repair-closeout-r1.json'))
    assert result['driver_sha256'] == content(N / 'tools/guard_shared_index.py')['sha256']
    declared = read(S / 'window-baseline-precloseout-r1/declaration.json')
    assert declared['source_head'] == closeout['merge_commit']
    assert declared['source_tree'] == source.TREE
    assert declared['guard'] == content(N / 'tools/guard_shared_index.py')
    assert result['tool_source_inventory'][str(N / 'tools/guard_shared_index.py')] == declared['guard']
    assert result['command'] == command
    log = path.with_suffix('.log')
    assert result['log_sha256'] == content(log)['sha256']
    return result, log.read_text()


def passed_tests(log):
    values = re.findall(r'^test (\S+) \.\.\. ok$', log, re.MULTILINE)
    assert values and len(values) == len(set(values))
    assert not re.search(r'^test .* \.\.\. FAILED$', log, re.MULTILINE)
    assert not re.search(r'^test result: FAILED\.', log, re.MULTILINE)
    return values


def required_tests(changes):
    names = []
    for filename in source.NEW_TESTS:
        raw = changes[source.SOURCE + filename][1].decode()
        for attributes, name in re.findall(r'^#\[test\]\s*((?:#\[[^\n]+\]\s*)*)fn (\w+)\(', raw, re.MULTILINE):
            if 'ignore' not in attributes:
                names.append(name)
    assert len(names) == len(set(names)) == 12
    return [*names, *OLD_CONTROLS]


def verify_named_tests(actual, required):
    for name in required:
        assert sum(value.endswith('::' + name) for value in actual) == 1, name


def corruption_controls(report, calendar_log):
    rejected = []
    for label, mutate in (
        ('omitted complete request', lambda rows: rows.pop()),
        ('duplicate complete request', lambda rows: rows.append(copy.deepcopy(rows[0]))),
        ('wrong frame work', lambda rows: rows[0]['observations'].__setitem__('window_frame_bound_evaluations', 0)),
        ('wrong admitted bytes', lambda rows: rows[0]['observations'].__setitem__('window_state_admitted_bytes', 0)),
        ('unreleased credits', lambda rows: rows[0].__setitem__('final_charged_bytes', 1)),
        ('claimed sharing on baseline', lambda rows: rows[0]['observations'].__setitem__('window_shared_groups', 1)),
        ('incomplete source', lambda rows: rows[0].__setitem__('source_exhausted', False)),
        ('fallback', lambda rows: rows[0].__setitem__('no_fallback', False)),
    ):
        altered = copy.deepcopy(report)
        mutate(altered['observations'])
        try:
            work.baseline(altered, calendar_log)
        except (AssertionError, KeyError, ValueError):
            rejected.append(label)
        else:
            raise AssertionError('corrupt work evidence admitted: ' + label)
    calendar_lines = [line for line in calendar_log.splitlines() if 'WINDOW_SHARED_CALENDAR_WORK ' in line]
    error_lines = [line for line in calendar_log.splitlines() if 'WINDOW_SHARED_ERROR_WORK ' in line]
    for label, lines in (('omitted calendar control', [*calendar_lines[1:], *error_lines]),
            ('duplicate calendar control', [*calendar_lines, calendar_lines[0], *error_lines]),
            ('omitted error control', [*calendar_lines, *error_lines[1:]]),
            ('duplicate error control', [*calendar_lines, *error_lines, error_lines[0]])):
        try:
            work.baseline(report, '\n'.join(lines))
        except (AssertionError, KeyError, ValueError):
            rejected.append(label)
        else:
            raise AssertionError('corrupt calendar evidence admitted: ' + label)
    altered = work.error_rows(calendar_log)
    changed = copy.deepcopy(next(iter(altered.values())))
    changed['observations']['window_shared_groups'] = 1
    prefix = 'WINDOW_SHARED_ERROR_WORK '
    original = next(line for line in error_lines
        if json.loads(line[line.index(prefix) + len(prefix):])['case'] == changed['case']
        and json.loads(line[line.index(prefix) + len(prefix):])['stored'] == changed['stored'])
    altered_log = calendar_log.replace(original, prefix + json.dumps(changed))
    try:
        work.baseline(report, altered_log)
    except (AssertionError, KeyError, ValueError):
        rejected.append('claimed error sharing on baseline')
    else:
        raise AssertionError('corrupt error evidence admitted')
    assert len(rejected) == 13
    return rejected


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('format', 'clippy', 'regression', 'attribution', 'observations'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert __debug__
    assert Path(__file__).resolve() == OUT / 'tools/verify_window_baseline_diagnostics.py', 'unactivated draft cannot execute'
    paths = {name: getattr(args, name).resolve() for name in (
        'format', 'clippy', 'regression', 'attribution', 'observations', 'output')}
    assert paths['output'].is_relative_to(OUT)
    assert all(path.parent == N and path.name.startswith('window-baseline-')
        for name,path in paths.items() if name != 'output')
    assert not paths['output'].exists()
    closeout = read(admission.CLOSEOUT)
    assert closeout['status'] == 'complete' and closeout['pr_checks_passed'] == 58 and closeout['main_checks_passed'] == 55
    assert closeout['pr_head'] == admission.HEAD and closeout['source_tree'] == source.TREE
    assert closeout['portable_replay_after_retirement'] == 'passed' and closeout['current_inputs_unchanged']
    assert source.git('rev-parse', 'HEAD').decode().strip() == closeout['merge_commit']
    for name, expected in closeout['retained_runtime'].items():
        assert Path(name).parent == N / 'runtime-r1' and content(Path(name)) == expected
    changes = source.expected()
    source.verify_current(changes, applied=False)
    commands = dict(format=FORMAT, clippy=CLIPPY, regression=REGRESSIONS,
        attribution=['env', 'SHARDLOOM_WINDOW_ATTRIBUTION_OUTPUT=' + str(paths['observations']), *ATTRIBUTION])
    guards, logs = {}, {}
    for name, command in commands.items():
        guards[name], logs[name] = guarded(paths[name], command, closeout)
    inventory = guards['regression']['build_sources']
    assert inventory == source.diagnostic_inventory_from_restored_tree(changes)
    assert all(row['build_sources'] == inventory for row in guards.values())
    assert all(row['build_source_fingerprint_sha256'] == guards['regression']['build_source_fingerprint_sha256']
        for row in guards.values())
    files = [Path(__file__), Path(source.__file__), Path(work.__file__),
        S / 'window-attribution-draft/transformations.json', admission.CLOSEOUT,
        S / 'window-baseline-precloseout-r1/declaration.json', N / 'tools/guard_shared_index.py',
        D / 'dictionary-repair-closeout-r1.json',
        *[path for name,path in paths.items() if name != 'output'],
        *[paths[name].with_suffix('.log') for name in commands]]
    sources = source.summary(changes)
    for relative, (_, after) in changes.items():
        expected = source.info(after)
        assert inventory[relative] == expected
        stored = S / 'window-baseline-precloseout-r1/source-blobs' / expected['sha256']
        assert content(stored) == expected
        files.append(stored)
    actual_tests = passed_tests(logs['regression'])
    required = required_tests(changes)
    verify_named_tests(actual_tests, required)
    diagnostic_tests = passed_tests(logs['attribution'])
    assert len(diagnostic_tests) == 1
    verify_named_tests(diagnostic_tests, ['native_compatible_window_complete_request_attribution'])
    observations = read(paths['observations'])
    prefix = 'WINDOW_SHARED_WORK '
    logged = [json.loads(line[line.index(prefix) + len(prefix):])
        for line in logs['attribution'].splitlines() if prefix in line]
    assert logged == observations['observations'] and len(logged) == 33
    contract = work.baseline(observations, logs['regression'])
    controls = corruption_controls(observations, logs['regression'])
    bindings = {str(path):content(path) for path in sorted(set(files))}
    assert not any(name == 'shardloom._native' or name.startswith('shardloom._native.') for name in sys.modules)
    source.verify_current(changes, applied=False)
    assert all(content(Path(name)) == expected for name,expected in bindings.items())
    for name, expected in closeout['retained_runtime'].items():
        assert content(Path(name)) == expected
    result = dict(schema='shardloom.compatible_window_baseline_diagnostics.v1',
        status='passed_baseline_diagnostics', accepted_head=admission.HEAD,
        accepted_merge=closeout['merge_commit'], accepted_tree=source.TREE,
        diagnostic_requests=33, calendar_controls=16, error_controls=18, work_contract=contract,
        complete_values_and_schema_match=True, all_credit_refunds_passed=True,
        ordinary_algorithm_unchanged=True, release_runtime_unchanged=True,
        regressions_passed=True, wide_cancellation_passed=True,
        native_query_executions_during_verification=0, performance_claim=False,
        diagnostic_source_changes=sources, actual_passed_tests=actual_tests,
        required_tests=required, attribution_test=diagnostic_tests[0],
        rejected_corruptions=controls, attribution_observations=identity(paths['observations']),
        regression_log=identity(paths['regression'].with_suffix('.log')),
        diagnostic_source_fingerprint_sha256=guards['regression']['build_source_fingerprint_sha256'],
        diagnostic_supervision='unchanged shared-index guard; exact merged source, before index retirement',
        accepted_runtime_admission='separate completed index closeout; prior guard is not current main acceptance',
        all_build_inputs_reconstructed_from_restored_accepted_tree=True,
        files=bindings, restored_source_before_scoring='verified clean; baseline admission checks again')
    with paths['output'].open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps({key:result[key] for key in ('status', 'diagnostic_requests', 'calendar_controls', 'error_controls',
        'native_query_executions_during_verification', 'rejected_corruptions')}))


if __name__ == '__main__':
    main()
