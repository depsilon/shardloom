# Window packet helper inventory (r1)

Read-only inventory of the prior shared-index packet helpers/record and the current shared-window runner/replayer. This records observed inputs, outputs, constraints, and relocation behavior; it does not specify replacement semantics.

## Scope, identity, and provenance

The active checkout used for context was `/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo`, branch `codex/native-shared-window-state`, HEAD `a640475ae66bc36cefcae42088dc23da6776e8ed`. The requested files were read directly at their specified `LocalData/shardloom/...` locations. No repository files or test/build/query processes were changed or run.

SHA-256 identities:

| Helper/record | SHA-256 |
|---|---|
| `shared-index-metadata-2026-11-10/tools/package_index_packet.py` | `3b168b21fee77fd29a5c6610db20cd066472980cef127224f3ef25a336c4cc64` |
| `shared-index-metadata-2026-11-10/tools/verify_index_packet.py` | `a4d1d0a35abe7124dbfcc0a6edd9b056ebbb9506c9df6c3eab609448ebddde4f` |
| `shared-index-metadata-2026-11-10/tools/check_index_packet_controls.py` | `924239422990fc3b1b689c6296c16674199e63fcfcd1538815b6911af9ebe010` |
| `shared-window-state-2026-11-11/tools/run_window_candidate.py` | `866a69a9f2125553ffa82ccf526745abd1fccc8c0520c7d7ceafefeda24fbc50` |
| `shared-window-state-2026-11-11/tools/replay_window_candidate.py` | `97000cf743c010bbc58bca7b7950509c93bcf188ba6e10eb3220708c2ced6acd` |

Prior closeout record `shared-index-closeout-r1.json` has schema `shardloom.shared_index_closeout.v1`, status complete, merge commit matching this checkout, and tree `c239675c12a25c04aa07a6dc45b8854d6b4718d2` (lines 2–8). It records retain-candidate disposition, nine preserved original failed result records, invalid original 10k status, and no complete 10k claim (lines 227–247, 890); its next queue unit names compatible window traversal and accumulator state (line 897). Its score summary is available in lines 211–227 and 283–299. This is accepted/closeout context, not a file consumed directly by the old packager code shown below.

## Prior packager: `package_index_packet.py`

### Roots and literal/dynamic path rules

The packager imports verification constants/functions from sibling `verify_index_packet.py` (lines 14–15). `N` is computed from the helper's parent; `S`, `D`, `K`, and `E` are sibling dated LocalData directories; `W` is a literal absolute checkout path (17–22). It requires a destination under resolved `N` and absent before creation, plus an execution name matching lowercase alphanumerics separated by single hyphens (219–228). The only excluded top-level execution records are dynamically named `<execution-name>.json` and `.log` (57–59).

Archive member path mapping is dynamic and root-relative for `N/current`, `S/preparation`, `D/repair`, `K/prior`, the frozen harness, `E/frozen`, repository release evidence, and repository source imports; three replay support scripts receive `protocol-support/` names (36–46). Unclassified paths fail. `add` rejects missing files and symlinks and rejects conflicting bytes/name or source-location mappings (48–55).

### Explicit archive input inventory

The package collector includes:

* All `N/*.json`, `N/*.log`, and `N/tools/*.py`, except the named execution JSON/log (57–59).
* `adversarial-review-r1.md`, `adversarial-review-r2.md`; every direct child in `hosted-failure-r1`; `packet-final-r1/{acceptance.json,verify.py,corruption-controls.json}` and every direct child of its `control-observations` (60–67).
* For each matching `packet-r[0-9]*` directory, only `acceptance.json` and `verify.py`, deliberately excluding its archive payloads (68–75).
* For `baseline-missing-r1` and `candidate-r1`: `complete.json`, `binding.json`, `attempts.sqlite`; every `N/*-cases-r1.jsonl.gz` (76–80).
* Every protocol `runtime_binding.proof_files` path, identity-checked against declared byte count/hash. Accepted repair runtime payload names are exactly `shardloom`, `lib_native.dylib`, `_native.abi3.so`; prior committed repository `.tar.xz` archives are identity-only. Those two classes are recorded under `identity_only_proof`, not copied (81–97).
* Every baseline protocol candidate-contract source, identity-checked and included (98–99).
* Explicit repair files: `correctness-cohort-r1/{binding.json,complete.json,attempts.sqlite}`, `correctness-cohort-r1.json`, `.log`, `release-build-r1.json`, `dictionary-repair-closeout-r1.json` (103–106).
* Explicit frozen roots: `design.json`, `inputs.json`, `frozen.json`, `native-preparation/complete.json`, `investigation-original-harness-source-r1.json`; all references enumerated by `frozen.json`; each harness file enumerated in the source manifest, hash-checked and matched uniquely to frozen harness provenance (107–119).
* The preserved failed observation receipt `S/current-baseline-10k-r1/failed-observation-replay-r1.json` (120–122).
* Content-addressed source blobs discovered by inspecting collected JSON records: hashes from `build_sources`/`tool_source_inventory`, plus `.py`, `.rs`, `.sh` entries in `source`/`sources`. Blob lookup order is `N`, `D`, `S`, `K` `source-blobs/<sha>`; then already collected bytes; finally a dynamically loaded predecessor release packet archive whose member bytes are indexed by digest (124–173). This is source/provenance closure, not a fixed source file list.

The collector reads `candidate-verified-r1.json`, `candidate-protocol-r1.json`, and `baseline-protocol-r1.json`; the result hard-checks `selected_cases == new_attempts == 2452` (29–34). It constructs `shardloom.shared_index_acceptance.v1`, status `local_candidate_decision_recorded`, with a source snapshot/fingerprint, check summaries, CI policy correction, baseline/candidate performance records, explicit non-claims/limitations, external identity-only proofs, source path locations, and member byte/hash identities (174–215). Baseline counts are literal 2452 cases, 433 reused, 2019 new; candidate values are selected from the verified result (198–201).

### Packaging outputs

Preflight-only mode prints a summary and writes no archive; optional replay preflight verifies diagnostics and replays saved evidence in an auto-cleaned temporary directory rooted under `N` (219–239). Normal mode splits any member larger than 24 MiB into digest-named `parts/<sha256(member-name)>/<four-digit-ordinal>` chunks; individual logical members are reassembled via report metadata. Stored members are grouped in order under 48 MiB per group (241–263). It creates the destination, emits `verification-NNN.tar.xz` (one-based ordinal), normalized tar metadata (mode 0644, mtime 0), requires each archive under 64 MiB, then writes `acceptance.json` and copies the verifier to `verify.py`; finally verifies the packet (264–279). Exact archive count is data-dependent.

## Prior verifier: `verify_index_packet.py`

### Core records, names, and relocation

The verifier hardcodes the accepted base commit/tree, hashes for baseline protocol/result/selection/frozen records, original LocalData root, check commands, source support list, CI path and diagnostic, status-prose set, and a fixed set of control names (24–75; individual constants/functions shown at 77 onward). `safe_name`, `read_archive`, `Packet`, and `verify_sources` implement member safety, archive loading, and path/source claim checks (94–105, 142–206, 246 onward). `verify_sources` accepts an optional repo root; CLI exposes `--repo-root` and `--require-controls` (644–661). Portable evidence therefore retains literal machine paths in records but validates/rewrites their relationship through packet mapping and an optional checkout root. The controls helper separately tests copying the packet and running its verifier with no explicit repo root (221–226), establishing packet relocation for that tested case.

### Accepted/result and source snapshots

The saved-result replay revalidates candidate and prior baseline observations rather than invoking query execution. It fixes the 2452 selected case count, protocol/selection equality, candidate and baseline result bindings, input/frozen references, per-case order/identity, all passed baseline and candidate outcomes, and recomputed engine totals/disposition (427–620; key literal count assertions at 440–444, 470, 500, 595–608). The source verifier checks the candidate source snapshot/runtime binding and CI-policy correction (246–357); frozen harness provenance is fixed at 65 source files and matches manifest/frozen hashes, with reference files also hash-checked (358–381). Diagnostic validation fixes the expected diagnostic record contract/counts, including `complete_requests == 22` and `cyclic_calls == 8` (383–426). These counts and schemas are index-specific literals, not generic cohort handling.

## Prior negative controls: `check_index_packet_controls.py`

This helper imports the prior verifier, sets dynamic `N` from its location, but uses literal checkout `W`; its five raw replay controls are literal names (16–21). Mutations cover native test failure, undrained process, mutable-source/lockfile policy, changed index source/root lock, missing consumer or metadata tests with rebound log hashes, runtime library mismatch, diagnostic entry count corruption, candidate total corruption, omitted candidate case, baseline reuse corruption, fallback denial, disposition corruption, omitted original failed result, false full-10k claim, and three CI policy corruptions with rebound source/guard fingerprints (44–149). The `CONTROL_NAMES` source of truth is imported from verifier.

`--child` runs one corruption check; archive-byte corruption is handled by cloning and mutating the archive; raw controls trigger saved replay, the diagnostic control triggers diagnostic verification, other controls trigger source/runtime binding verification (152–183). Parent mode requires packet within `N`, execution-name grammar and absent log directory; it verifies the packet helper bytes are actually members, invokes packet verifier, executes every named child, performs relocated-copy positive control, preserves stdout/stderr logs, then writes `corruption-controls.json` and `control-observations/` (186–242). Thus direct generated files are dynamic `<N>/<execution-name>/{name.stdout.log,name.stderr.log}`, `packet/control-observations/` copies, and `packet/corruption-controls.json`; temporary cloned packets are removed by temporary-directory contexts (152–180, 186–242). Positive controls: source-bound and relocated-source-only. Counts are not intrinsic to generic cases; number of corruption controls follows verifier's literal control-name set.

## Current window candidate runner: `run_window_candidate.py`

### Roots, accepted records, and source proof

Window roots/target filenames are imported or derived from `run_window_baseline` (`OUT,S,N,E,W`), with literal candidate protocol/result, runtime, build/check/diagnostic filenames and a literal baseline result SHA (23–35). `baseline_proof` checks fixed protocol/result identities, accepted status, 1212 selected cases, 776 original controls, 436 new compositions, 188 reused saved cases, 1024 new attempts, all-pass/valid clocks/no-fallback, nonclaims, and exact engine total `340.599417211`; it validates case rows one-to-one against selection and adds explicitly named baseline guard, ledger, reuse and protocol evidence (49–89).

`runtime_proof` inventories current sources and admits guarded build/check/diagnostic receipts, tests, source fingerprint and native CI inventory; exact ignored test inventory count is 35. It validates runtime identity names `shardloom` and `lib_native.dylib`, candidate library copy and guard (92–150). `context` joins baseline proofs, source/build/check records, prior/candidate attribution observations, CI inventory, freeze records, source imports and selection/preflight/retained attempts; then deduplicates frozen/proof/runtime records by path while requiring identical identities on collisions (168–207). Some filenames are explicit while lists like report files and proof files are data-driven.

### Candidate protocol and generated records

`admission` requires root equal to `E`; it creates runtime schema `shardloom.compatible_window_candidate_runtime.v1` and protocol schema `shardloom.compatible_window_candidate_protocol.v1`, with literal selected/original/composed counts 1212/776/436, 65 frozen harness files, one attempt per case, zero warmups/repeats, false fallback permission and no timing-based selection (210–234). `--plan` requires protocol/target absent and writes `candidate-protocol-r1.json`; prepare-library mode copies the dynamic runtime library and writes a copy receipt; default mode calls the imported baseline capture runner for the fixed protocol case list (235–267). The runner itself does not emit the independent candidate result; the replayer does.

## Current window independent replayer: `replay_window_candidate.py`

### Inputs and accepted/result records

This requires the exact helper path and absence of output/result/case/partial/lock paths, then recomputes admission, reads protocol/selection/baseline, candidate completion and binding, and validates candidate ledger/binding/frozen identities and guard record/log (18–55). It requires protocol cases equal selection, count 1212, candidate baseline result identity, and valid passed baseline results (56–59). For each fixed selected case in order it reads the attempt SQLite ledger, baseline case-row gzip stream, frozen reference DBs, unpacks stored packets, replays result semantics, verifies embedded `one.job.json` requests when present, hashes independent expected output provenance and validates finite nonnegative engine time (61–110). It requires no extra/missing ledger or baseline rows, then summarizes result counts and engine time; disposition is retain only if all pass and candidate total is strictly lower than baseline total (109–145).

### Generated outputs and literal assumptions

Writes `candidate-cases-r1.partial.jsonl.gz` under exclusive lock, renames it to `candidate-cases-r1.jsonl.gz`, writes exclusive `candidate-verified-r1.json`, then removes `.candidate-replay-r1.lock`; output schema is `shardloom.compatible_window_candidate_cohort.v1`, and counts 1212/776/436/1212 are literal (22–26, 61–69, 102–145). The record includes per-family counts and engine totals, exact protocol/selection/baseline/complete/ledger/guard/case-row/verifier identities, runtime binding, explicit false 10k and Full43 claims, and limitations. This helper validates/records; it does not execute candidate query work. A failed cohort still writes the result and then raises assertion.

## Literal adaptation assumptions visible in these files (no replacement design)

1. Cohort cardinalities differ: index packet assumes 2452 selected/new candidate cases and a 433/2019 reused/new baseline split; window assumes 1212 total, 776 original + 436 compositions, with baseline 188 reused + 1024 new. See packager 29–34, 198–201; verifier 440–444, 595–608; window runner 49–75, 183–185, 222–230; window replayer 32–39, 56, 109, 116–120.
2. Roots differ and contain literal user/machine-specific absolute checkout/cache/Python paths. Old helper paths bind to the native-vector-representations checkout and dated index LocalData roots; window paths inherit `OUT/S/N/E/W` from its baseline helper, but still assert a literal Python executable command and import baseline modules. Old packet relocation only demonstrates verifier relocation for an already built packet; it does not make source collection roots dynamic. See old packager 17–22, 36–46, verifier 24–75, controls 18–19, 221–226; window runner 17–35, 180–181, 252–267.
3. Schemas and filenames are experiment-specific: index acceptance `shardloom.shared_index_acceptance.v1`; window runtime/protocol/cohort schemas differ. Their source lists/proof structures, record names, result fields, checks, diagnostics, and per-query packet formats are not interchangeable (old packager 188–214; window runner 213–234; replayer 116–139).
4. Index source/harness closure explicitly handles 65 frozen harness files and named Vortex/index support/source patterns; window runner also records a 65-file frozen harness but obtains its support closure through imported baseline helpers, and uses window-specific runtime/check/attribution files. The shared number does not imply same source manifest or content.
5. Old packet archives may split large members, group them by size, omit payload bytes for identity-only retained runtimes/prior committed archives, and recover source bytes from predecessor packets. Window replayer has no packet/archive creation path; it emits one gzip case ledger and one JSON result. Existing retention and archive representation are therefore distinct.
6. Window no-fallback and timing semantics are encoded in its own protocol/result and validation fields (`fallback_allowed=False`, `native_no_fallback`, `engine_execution_seconds`); old verifier enforces its own candidate/result contracts and literal index diagnostic/control names. Their count and name assumptions must be treated as observed inputs to adaptation, not silently carried over.

## Explicit unknowns / boundaries

* This inventory does not enumerate every dynamically populated `proof_files`, `frozen.references`, `manifest.harness_sha256`, `report.files`, or predecessor archive member; those are runtime/data enumerations enforced by the code, not fixed names in the helper source.
* It does not inspect contents of all external records, databases, archive payloads, imported baseline helpers, or the actual output packet. It records the named closeout and helper contracts only.
* It does not infer replacement acceptance semantics, decide which old controls remain appropriate, or assert that prior index retention/closeout records should be copied into a window packet.
* The five-helper hashes above identify the exact inspected helper bytes. The closeout JSON hash was recorded during inspection as `4937b11f491d08eac27807e8d501fa0f5ec42cead8a12657c3309932997cc17c`.
