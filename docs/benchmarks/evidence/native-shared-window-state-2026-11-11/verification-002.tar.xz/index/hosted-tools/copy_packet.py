"""Copy verified shared-index evidence without replacing existing repository files."""
import hashlib
import json
from pathlib import Path
import shutil

N = Path(__file__).resolve().parents[1]
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
source = N / 'packet-final-r1'
target = W / 'docs/benchmarks/evidence/native-shared-index-metadata-2026-11-10'
assert target.is_dir() and {path.name for path in target.iterdir()} == {'README.md'}


def identity(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        return dict(bytes=path.stat().st_size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest())


def copy(path, destination):
    expected = identity(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with path.open('rb') as src, destination.open('xb') as dst:
        shutil.copyfileobj(src, dst, 1 << 20)
    assert identity(path) == identity(destination) == expected
    return expected


extras = {}
for name, prefix in (('portable-final-r1', 'packaging-execution'), ('packet-controls-r1', 'controls-execution')):
    receipt = json.loads((N / (name + '.json')).read_bytes())
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert receipt['fixed_source_validation'] and not receipt['allow_lockfile_update']
    assert receipt['log_sha256'] == identity(N / (name + '.log'))['sha256']
    for suffix in ('.json', '.log'):
        extras[prefix + suffix] = N / (name + suffix)
controls = json.loads((source / 'corruption-controls.json').read_bytes())
assert controls['status'] == 'passed' and controls['positive_controls'] == 2
assert controls['rejected_corruptions'] == 17 and controls['query_executions'] == 0
assert controls['acceptance_manifest'] == identity(source / 'acceptance.json')
assert not any((source / name).exists() for name in extras)
required = sum(path.stat().st_size for path in source.rglob('*') if path.is_file())
required += 2 * sum(path.stat().st_size for path in extras.values())
assert shutil.disk_usage(source).free >= (12 << 30) + required + (128 << 20)
for name, path in extras.items():
    copy(path, source / name)
copied = {path.relative_to(source).as_posix(): copy(path, target / path.relative_to(source))
    for path in sorted(source.rglob('*')) if path.is_file()}
result = dict(status='passed', source=str(source), destination=str(target), files=copied,
    query_executions=0, source_and_destination_byte_identical=True)
with (N / 'repository-packet-copy-proof-r1.json').open('x') as output:
    json.dump(result, output, indent=2)
    output.write('\n')
print(json.dumps(dict(status='passed', files=len(copied), query_executions=0)))
