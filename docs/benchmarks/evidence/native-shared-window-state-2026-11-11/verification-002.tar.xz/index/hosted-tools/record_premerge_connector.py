"""Bind shared-index acceptance to exact PR checks, review and the merge tree."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess

D = Path(__file__).resolve().parents[1]
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
PACKET = W/'docs/benchmarks/evidence/native-shared-index-metadata-2026-11-10'
EXPECTED = D.parent/'dictionary-execution-repair-2026-11-10/pr1677-premerge-r1.json'
CONTRACT = D/'hosted-contract-r2.json'
contract = json.loads(CONTRACT.read_bytes())
PR,HEAD,BASE = (contract[key] for key in ('pr','head','base'))
assert isinstance(PR,int) and PR > 0 and re.fullmatch(r'[0-9a-f]{40}',HEAD)
assert BASE == '037b6801320aa0bfe939ba10aed9304198b77a5a'
assert contract['branch'] == 'codex/native-shared-index-metadata'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--snapshots',type=Path,required=True)
parser.add_argument('--name',required=True)
args = parser.parse_args()
assert re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*',args.name)
snapshots = args.snapshots.resolve()
assert snapshots.is_relative_to(D)
destination = D/(args.name+'.json')
assert not destination.exists()

def read(path):
    return json.loads(path.read_bytes())

def identity(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        return dict(bytes=path.stat().st_size,sha256=hashlib.file_digest(stream,'sha256').hexdigest())

def git(*args):
    return subprocess.check_output(['git',*args],cwd=W,text=True,timeout=120).strip()

def connector(name):
    result = read(snapshots/(name+'.json'))
    assert not result.get('isError')
    return result['structuredContent']

def api(name,endpoint):
    response = connector(name+'-connector')
    assert response['url'] == 'https://api.github.com/repos/depsilon/shardloom/'+endpoint
    raw = response['content'].encode()
    assert len(raw) < 8 << 20
    (snapshots/(name+'.json')).write_bytes(raw)
    return json.loads(raw)

result = dict(status='needs_attention',pr=PR,head=HEAD,base=BASE,
    observed_at=datetime.now(timezone.utc).isoformat(),observer=identity(Path(__file__)),
    hosted_contract=identity(CONTRACT))
try:
    assert git('rev-parse','HEAD') == HEAD and not git('status','--porcelain')
    assert git('branch','--show-current') == contract['branch']
    original = read(D/'hosted-contract-r1.json')['head']
    assert original == 'c935ed5036c9dce061bcf91724a6423a069004f4'
    assert git('show','-s','--format=%P',HEAD).split() == [original]
    assert git('show','-s','--format=%P',original).split() == [BASE]
    assert not git('diff','--name-only',BASE,HEAD,'--','.github/workflows')
    tree = git('rev-parse',HEAD+'^{tree}')
    assert tree == contract['tree']
    spec = importlib.util.spec_from_file_location('dictionary_verifier',PACKET/'verify.py')
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    report,data = verifier.read_archive(PACKET)
    verifier.verify_sources(report,data,W)
    verifier.verify_controls(PACKET,report,data)
    del data
    replay_path = D/'committed-source-replay-r2.json'
    replay = read(replay_path)
    assert replay['status'] == 'passed' and replay['returncode'] == 0
    assert replay['fixed_source_validation'] and not replay['allow_lockfile_update']
    assert replay['process_group_drained'] and replay['direct_child_reaped']
    assert replay['command'] == ['/opt/homebrew/opt/python@3.13/libexec/bin/python3','-B',str(PACKET/'verify.py'),'--repo-root',str(W),'--require-controls']
    assert replay['log_sha256'] == identity(replay_path.with_suffix('.log'))['sha256']
    outcome = read(replay_path.with_suffix('.log'))
    assert outcome['status'] == 'passed_source_bound_replay' and outcome['query_executions'] == 0
    assert outcome['disposition'] == report['disposition'] == 'retain_candidate'
    assert outcome['baseline_cases'] == outcome['candidate_cases'] == 2452
    assert outcome['engine_execution_seconds'] == dict(baseline=320.508980218, candidate=319.977114074)
    for path in PACKET.rglob('*'):
        if path.is_file() and path.name != 'README.md':
            assert identity(path) == identity(D/'packet-final-r2'/path.relative_to(PACKET))
    pr = api('metadata',f'pulls/{PR}')
    assert pr['number'] == PR and pr['head']['sha'] == HEAD and pr['base']['sha'] == BASE
    assert pr['head']['ref'] == contract['branch'] and pr['head']['repo']['full_name'] == 'depsilon/shardloom'
    assert pr['base']['ref'] == 'main' and pr['state'] == 'open' and not pr['draft'] and not pr['merged']
    assert pr['mergeable'] is True
    required = set(read(EXPECTED)['required_check_names'])
    assert len(required) == 58
    checks = api('checks',f'commits/{HEAD}/check-runs?per_page=100&filter=latest')
    rows = checks['check_runs']
    assert len(rows) == checks['total_count'] == len(required)
    assert {row['name'] for row in rows} == required
    assert all(row['head_sha'] == HEAD and row['status'] == 'completed' and row['conclusion'] == 'success' for row in rows)
    workflows = api('workflows',f'actions/runs?head_sha={HEAD}&per_page=100')
    runs = workflows['workflow_runs']
    assert len(runs) == workflows['total_count'] == 2
    assert {(row['name'],row['path']) for row in runs} == {('CI','.github/workflows/ci.yml'),('CodeQL Analysis','.github/workflows/codeql-analysis.yml')}
    assert all(row['event'] == 'pull_request' and row['head_sha'] == HEAD and row['status'] == 'completed' and row['conclusion'] == 'success' for row in runs)
    comments = connector('comments')['comments']
    states = [(json.loads(match.group(1))['code_review'],row['url']) for row in comments
        if row['user']['login'] == 'chatgpt-codex-connector[bot]'
        and (match := re.search(r'<!-- codex-review-state:v1 (.*?) -->',row['body']))]
    current = [(state,url) for state,url in states if state.get('commit_sha') == HEAD]
    assert len(current) == 1
    review,review_url = current[0]
    assert review['status'] == 'completed' and review['has_any_findings'] is review['has_unresolved_findings'] is False
    threads = connector('threads')['review_threads']
    assert all(row['isResolved'] for row in threads)
    reviews = connector('reviews')['reviews']
    assert not any(row['state'] == 'CHANGES_REQUESTED' for row in reviews)
    subprocess.run(['git','fetch','--no-tags','origin',f'refs/pull/{PR}/merge'],cwd=W,check=True,timeout=120)
    assert git('rev-parse','FETCH_HEAD') == pr['merge_commit_sha']
    assert git('rev-parse','FETCH_HEAD^{tree}') == tree
    assert git('show','-s','--format=%P','FETCH_HEAD').split() == [BASE,HEAD]
    assert git('rev-parse','HEAD') == HEAD and not git('status','--porcelain')
    result.update(status='passed_premerge',base_branch='main',source_tree=tree,
        synthetic=pr['merge_commit_sha'],tree_matches_synthetic=True,mergeable=True,
        successful_hosted_checks=len(rows),required_check_names=sorted(required),
        checks=[{k:row[k] for k in ('id','name','head_sha','status','conclusion','html_url')} for row in rows],
        review=review,review_url=review_url,unresolved_threads=0,review_submissions=reviews,
        workflow_runs=[{k:row[k] for k in ('id','name','path','event','status','conclusion','head_sha')} for row in runs],
        runtime_sources_match_build=True,source_bound_replay='passed',completed_source_replay=identity(replay_path),
        source_fingerprint_sha256=report['candidate_source_fingerprint_sha256'],
        packet_files={path.relative_to(PACKET).as_posix():identity(path) for path in sorted(PACKET.rglob('*')) if path.is_file()},
        expected_check_names_source=identity(EXPECTED),complete_10k_performance_claim=False,
        scoped_performance_decision='retain_candidate',publication_attempted=False)
except BaseException as error:
    result['error'] = type(error).__name__+': '+str(error)
    raise
finally:
    result['raw_sources'] = {path.relative_to(D).as_posix():identity(path) for path in sorted(snapshots.iterdir())}
    with destination.open('x') as output:
        json.dump(result,output,indent=2);output.write('\n')
print(json.dumps({key:result[key] for key in ('status','head','source_tree','successful_hosted_checks')}))
