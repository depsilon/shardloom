"""Retire exact shared-index intermediates after accepted review, merge and main checks."""
import argparse
import hashlib
import importlib.util
import json
import lzma
from pathlib import Path
import shutil
import subprocess

N = Path(__file__).resolve().parents[1]
D = N.parent / 'dictionary-execution-repair-2026-11-10'
S = N.parent / 'shared-operator-state-2026-11-10'
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
PACKET = W / 'docs/benchmarks/evidence/native-shared-index-metadata-2026-11-10'
PREVIOUS = W / 'docs/release/evidence/native-dictionary-execution-repair-2026-11-10'
PACKETS = (PACKET, PREVIOUS)
TARGET = N / 'shared-index-retirement-r1'
CONTRACT = N / 'hosted-contract-r2.json'
contract = json.loads(CONTRACT.read_bytes())
PR, HEAD = contract['pr'], contract['head']
PRE, MAIN = N / f'pr{PR}-premerge-r1.json', N / 'shared-index-main-r1.json'
HELPER = N.parent / 'expanded-query-2026-11-03/tools/retire_shared_intermediates_r2.py'
assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == '19082efec1eaf8df1f894f5047f9efa3c58f1aed206424be3d04c28899b4482e'
spec = importlib.util.spec_from_file_location('retention_primitives', HELPER)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.E = N.parent


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    assert path.is_file() and not path.is_symlink(), path
    return dict(bytes=path.stat().st_size, sha256=base.sha(path))


def git(*args):
    return subprocess.check_output(['git', *args], cwd=W, text=True, timeout=120).strip()


def gate():
    pre, main = read(PRE), read(MAIN)
    assert pre['status'] == 'passed_premerge' and main['status'] == 'passed'
    assert pre['pr'] == main['pr'] == PR and pre['head'] == main['pr_head'] == HEAD
    assert pre['base'] == main['pr_base'] == contract['base']
    assert pre['hosted_contract'] == identity(CONTRACT)
    assert pre['successful_hosted_checks'] == 58 and main['successful_hosted_checks'] == 55
    assert main['premerge_sha256'] == base.sha(PRE)
    assert pre['source_tree'] == main['source_tree'] == contract['tree'] and pre['tree_matches_synthetic']
    assert pre['review']['commit_sha'] == HEAD and pre['review']['status'] == 'completed'
    assert pre['review']['has_any_findings'] is pre['review']['has_unresolved_findings'] is False
    assert pre['unresolved_threads'] == 0 and not any(row['state'] == 'CHANGES_REQUESTED' for row in pre['review_submissions'])
    assert main['commit_verification']['verified'] and not main['failed'] and not main['pending'] and not main['missing']
    assert not main['duplicate_expected_checks'] and not main['unexpected_workflows']
    assert set(main['required_hosted_check_names']) == set(pre['required_check_names']) - {'CodeQL', 'CodeQL rust', 'CodeQL python'}
    for report in (pre, main):
        for name, expected in report['raw_sources'].items():
            actual = identity(N / name)
            assert actual == expected if isinstance(expected, dict) else actual['sha256'] == expected
    assert git('rev-parse', 'HEAD') == main['source_commit'] and not git('status', '--porcelain')
    assert git('rev-parse', 'HEAD^{tree}') == pre['source_tree']
    assert git('show', '-s', '--format=%P', 'HEAD').split() == [pre['base'], HEAD]
    return dict(premerge=identity(PRE), main=identity(MAIN), merge_commit=main['source_commit'])


def inputs():
    prior = read(D / 'dictionary-repair-closeout-r1.json')
    path = D / 'dictionary-retirement-r1/manifest.json.xz'
    assert identity(path) == prior['receipts']['dictionary-retirement-r1/manifest.json.xz']
    expected = json.loads(lzma.decompress(path.read_bytes()))['input_generations']
    assert len(expected) == prior['current_input_files'] == 220
    actual = {name: base.generation(Path(name)) for name in expected}
    assert actual == expected
    return actual


def retained():
    result = {}
    runtime = read(N / 'runtime-r1-identity.json')
    assert runtime['status'] == 'passed' and runtime['profile'] == 'release'
    assert runtime['build_receipt_identity'] == identity(N / runtime['build_receipt'])
    assert runtime['build_source_fingerprint_sha256'] == read(PRE)['source_fingerprint_sha256']
    assert {path.name for path in (N / 'runtime-r1').iterdir()} == {'shardloom', 'lib_native.dylib', '_native.abi3.so'}
    for row in runtime['files']:
        path = Path(row['path'])
        assert path.parent == N / 'runtime-r1'
        assert identity(path) == {key: row[key] for key in ('bytes', 'sha256')}
        result[str(path)] = identity(path)
    copied = read(N / 'runtime-library-copy-r1.json')
    assert copied['status'] == 'passed' and copied['byte_identical'] and copied['queries_executed'] == 0
    for name in ('source', 'destination'):
        row = copied[name]
        path = Path(row['path'])
        assert path.parent == N / 'runtime-r1'
        assert identity(path) == dict(bytes=row['generation']['bytes'], sha256=row['sha256'])
        assert row['sha256'] == copied['source']['sha256']
        result[str(path)] = identity(path)
    for directory in PACKETS:
        for path in sorted(directory.rglob('*')):
            if path.is_file():
                result[str(path)] = identity(path)
    for name, info in read(PRE)['packet_files'].items():
        assert result[str(PACKET / name)] == info
    # Compact results, original failures, future investigation preparation and
    # helper sources remain. Only specifically verified redundant payloads retire.
    for root in (N, D, S):
        for pattern in ('*.json', '*.log', '*.md', '*.jsonl.gz', 'tools/*.py', 'hosted-tools/*.py'):
            for path in sorted(root.glob(pattern)):
                result[str(path)] = identity(path)
    for root in sorted(S.glob('window-*')):
        if root.is_dir():
            for path in sorted(root.rglob('*')):
                if path.is_file():
                    result[str(path)] = identity(path)
    for report in (read(PRE), read(MAIN)):
        for name in report['raw_sources']:
            result[str(N / name)] = identity(N / name)
    for root in (N / 'baseline-missing-r1', N / 'candidate-r1',
                 D / 'correctness-cohort-r1', S / 'current-baseline-10k-r1'):
        for path in sorted(root.iterdir()):
            if path.is_file() and path.name != 'attempts.sqlite':
                result[str(path)] = identity(path)
    for path in sorted(N.glob('draft-packet-retention-r*/*')):
        result[str(path)] = identity(path)
    compact = read(N / 'draft-packet-retention-r2/summary.json')
    manifest_path = N / 'draft-packet-retention-r2/manifest.json.xz'
    assert identity(manifest_path) == compact['manifest']
    manifest = json.loads(lzma.decompress(manifest_path.read_bytes()))
    for draft in manifest['drafts'].values():
        for name, item in draft['metadata'].items():
            assert identity(Path(name)) == item
            result[name] = item
    for path in sorted((N / 'hosted-failure-r1').iterdir()):
        result[str(path)] = identity(path)
    for path in sorted((N / 'retirement-preserved-sources').iterdir()):
        item = identity(path)
        assert item['sha256'] == path.name
        result[str(path)] = item
    return result


def replacement_index(kept):
    known = {}
    for directory in PACKETS:
        report = read(directory / 'acceptance.json')
        for archive in report['archives']:
            assert identity(directory / archive['path']) == {key: archive[key] for key in ('bytes', 'sha256')}
        for row in report['members']:
            known.setdefault((row['bytes'], row['sha256']),
                'committed_member:' + str(directory.relative_to(W)) + ':' + row['path'])
    for path, item in kept.items():
        known.setdefault((item['bytes'], item['sha256']), 'retained_file:' + path)
    return known


def selected_roots(kept):
    selected, replacements = {}, []
    known = replacement_index(kept)
    compact = N / 'draft-packet-retention-r2'
    summary = read(compact / 'summary.json')
    assert summary['status'] == 'passed' and summary['deletions'] == summary['query_executions'] == 0
    assert identity(compact / 'manifest.json.xz') == summary['manifest']
    manifest = json.loads(lzma.decompress((compact / 'manifest.json.xz').read_bytes()))
    assert manifest['status'] == 'passed' and manifest['script'] == identity(N / 'hosted-tools/compact_draft_evidence_r2.py')
    assert not manifest['payload_backup_created']
    for name, item in manifest['committed_packet_files'].items():
        assert identity(Path(name)) == item
    for sha, item in manifest['retained_draft_members'].items():
        assert identity(compact / sha) == item
    for draft_name, draft in manifest['drafts'].items():
        assert draft['all_logical_members_byte_identical_after_reconstruction']
        for name, item in draft['metadata'].items():
            assert identity(Path(name)) == item
        for name, item in draft['archives'].items():
            assert identity(Path(name)) == item
            assert draft['compressed_archives_reconstructed_byte_exact'][Path(name).name] == item
            known.setdefault((item['bytes'], item['sha256']),
                'byte_exact_archive_reconstruction:draft-packet-retention-r2:' + draft_name + ':' + Path(name).name)

    def add(path, reason):
        assert path.exists() and not path.is_symlink() and path.resolve() == path
        assert path.is_relative_to(N.parent) and path != N.parent
        assert str(path) not in selected
        selected[str(path)] = reason

    old = read(D / 'dictionary-repair-closeout-r1.json')
    assert old['status'] == 'complete' and old['merge_commit'] == contract['base']
    assert old['pr_checks_passed'] == 58 and old['main_checks_passed'] == 55
    assert {str(path) for path in (D / 'runtime-r1').iterdir()} == set(old['retained_runtime'])
    for name, item in old['retained_runtime'].items():
        assert identity(Path(name)) == item
    add(D / 'runtime-r1', 'superseded dictionary baseline runtime; accepted index runtime retained with exact provenance')
    for path in sorted((N / 'source-blobs').iterdir()):
        item = identity(path)
        assert item['sha256'] == path.name
        replacements.append(dict(path=str(path), identity=item,
            replacement=known[(item['bytes'], item['sha256'])]))
    add(N / 'source-blobs', 'source snapshots retained byte-exact in committed evidence or explicit current helper files')
    for root in (N / 'baseline-missing-r1', N / 'candidate-r1',
                 D / 'correctness-cohort-r1', S / 'current-baseline-10k-r1'):
        path = root / 'attempts.sqlite'
        item = identity(path)
        replacements.append(dict(path=str(path), identity=item,
            replacement=known[(item['bytes'], item['sha256'])]))
        add(path, 'complete raw result ledger retained byte-exact in a committed packet; compact outcomes stay local')
    final = N / 'packet-final-r2'
    local = {path.relative_to(final).as_posix(): identity(path) for path in sorted(final.rglob('*')) if path.is_file()}
    committed = {path.relative_to(PACKET).as_posix(): identity(path) for path in sorted(PACKET.rglob('*'))
        if path.is_file() and path.name != 'README.md'}
    assert local == committed
    add(final, 'byte-identical committed final index evidence')
    for draft in manifest['drafts'].values():
        assert draft['all_logical_members_byte_identical_after_reconstruction']
        for name, item in draft['metadata'].items():
            assert identity(Path(name)) == item
        for name, item in draft['archives'].items():
            assert identity(Path(name)) == item
            add(Path(name), 'draft archives reconstruct byte-exact from final archive and retained unique text; original metadata remains')
    paths = [Path(name) for name in selected]
    assert not any(a != b and a.is_relative_to(b) for a in paths for b in paths)
    return selected, replacements


def replay():
    results = []
    for directory in PACKETS:
        command = ['/opt/homebrew/opt/python@3.13/libexec/bin/python3', '-I', '-B', str(directory / 'verify.py'), '--require-controls']
        if directory == PACKET:
            command += ['--repo-root', str(W)]
        observed = subprocess.run(command, cwd=W, capture_output=True, text=True, timeout=600)
        name = directory.name
        (TARGET / (name + '.stdout.json')).write_text(observed.stdout)
        (TARGET / (name + '.stderr.log')).write_text(observed.stderr)
        assert observed.returncode == 0, observed.stderr
        result = json.loads(observed.stdout)
        assert result['status'] == ('passed_source_bound_replay' if directory == PACKET else 'passed')
        assert result['query_executions'] == 0
        results.append(dict(packet=name, command=command, returncode=0, result=result,
            stdout=identity(TARGET / (name + '.stdout.json')), stderr=identity(TARGET / (name + '.stderr.log'))))
    return results


def plan():
    assert not TARGET.exists() and shutil.disk_usage(N).free >= (12 << 30) + (8 << 20)
    hosted, kept, current = gate(), retained(), inputs()
    roots, replacements = selected_roots(kept)
    rows = [row for name in sorted(roots) for row in base.inventory(Path(name))]
    assert len(rows) == len({row['path'] for row in rows})
    assert not (set(kept) | set(current)).intersection(row['path'] for row in rows)
    base.closed(roots)
    for row in rows:
        base.unchanged(row)
    manifest = dict(head=HEAD, roots=roots, entries=rows, retained=kept,
        input_generations=current, hosted=hosted, source_snapshot_replacements=replacements)
    raw = lzma.compress(json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode(), preset=6)
    assert len(raw) < 8 << 20 and json.loads(lzma.decompress(raw)) == manifest
    TARGET.mkdir()
    (TARGET / 'manifest.json.xz').write_bytes(raw)
    summary = dict(status='planned_no_deletion', head=HEAD, roots=len(roots), entries=len(rows),
        regular_files=sum(row['kind'] == 'regular' for row in rows), symlinks=sum(row['kind'] == 'symlink' for row in rows),
        regular_bytes=sum(row['generation'][3] for row in rows if row['kind'] == 'regular'),
        manifest_sha256=base.sha(TARGET / 'manifest.json.xz'), script_sha256=base.sha(Path(__file__)),
        helper_sha256=base.sha(HELPER), current_input_files=len(current), retained_files=len(kept),
        payload_backup_created=False, compiler_cache='retained for next active window experiment')
    (TARGET / 'plan.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary), flush=True)


def apply():
    assert gate() and shutil.disk_usage(N).free >= 12 << 30
    summary = read(TARGET / 'plan.json')
    assert summary['script_sha256'] == base.sha(Path(__file__)) and summary['helper_sha256'] == base.sha(HELPER)
    assert summary['manifest_sha256'] == base.sha(TARGET / 'manifest.json.xz')
    manifest = json.loads(lzma.decompress((TARGET / 'manifest.json.xz').read_bytes()))
    assert manifest['head'] == HEAD and manifest['hosted'] == gate()
    kept = retained()
    roots, replacements = selected_roots(kept)
    assert roots == manifest['roots'] and replacements == manifest['source_snapshot_replacements']
    assert kept == manifest['retained'] and inputs() == manifest['input_generations']
    rows = manifest['entries']
    for _ in range(2):
        assert [row for name in sorted(roots) for row in base.inventory(Path(name))] == rows
        base.closed(roots)
    assert not (TARGET / 'receipt.json').exists()
    receipt = dict(status='running', head=HEAD, removed=0, manifest_sha256=summary['manifest_sha256'],
        hosted=manifest['hosted'], merged=True)
    try:
        for row in sorted(rows, key=lambda value: len(Path(value['path']).parts), reverse=True):
            path = Path(row['path'])
            base.unchanged(row, removing_children=row['kind'] == 'directory')
            path.rmdir() if row['kind'] == 'directory' else path.unlink()
            receipt['removed'] += 1
        assert all(not Path(name).exists() and not Path(name).is_symlink() for name in roots)
        assert retained() == manifest['retained'] and inputs() == manifest['input_generations']
        assert gate() == manifest['hosted']
        checked = replay()
        receipt.update(status='passed', retained_files_unchanged=True, input_generations_unchanged=True,
            portable_replay_after_retirement='passed', post_retirement_replays=checked,
            storage_limits_changed=False, payload_backup_created=False, historical_member_identities_preserved=True,
            original_failed_observations_preserved=True, regular_files=summary['regular_files'],
            symlinks=summary['symlinks'], regular_bytes=summary['regular_bytes'])
    except BaseException as error:
        receipt.update(status='failed', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        with (TARGET / 'receipt.json').open('x') as output:
            json.dump(receipt, output, indent=2)
            output.write('\n')
    print(json.dumps({key: receipt[key] for key in ('status', 'removed', 'regular_files', 'symlinks',
        'portable_replay_after_retirement', 'input_generations_unchanged')}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('plan', 'apply'))
    args = parser.parse_args()
    plan() if args.action == 'plan' else apply()
