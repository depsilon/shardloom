"""Record accepted shared-index integration and verified intermediate retirement."""
from datetime import datetime, timezone
import importlib.util
import json
import lzma
from pathlib import Path

N = Path(__file__).resolve().parents[1]
DEST = N / 'shared-index-closeout-r1.json'
assert not DEST.exists()
spec = importlib.util.spec_from_file_location('index_retirement', N / 'hosted-tools/retire_index_intermediates.py')
retire = importlib.util.module_from_spec(spec)
spec.loader.exec_module(retire)
read, identity, git = retire.read, retire.identity, retire.git
hosted = retire.gate()
pre, main = read(retire.PRE), read(retire.MAIN)
accepted = read(retire.PACKET / 'acceptance.json')
assert accepted['status'] == 'local_candidate_decision_recorded'
assert accepted['source_base'] == pre['base']
assert accepted['candidate_source_fingerprint_sha256'] == pre['source_fingerprint_sha256']
assert all(row['status'] == 'passed' for row in accepted['checks'].values())
assert all(row['status'] == 'passed' for row in accepted['documentation_checks'].values())
assert accepted['baseline'] == dict(cases=2452, reused_saved_cases=433, new_attempts=2019,
    engine_execution_seconds=320.508980218)
assert accepted['candidate']['selected_cases'] == 2452
assert accepted['candidate']['outcomes'] == {'passed': 2452}
assert accepted['candidate']['engine_execution_seconds'] == 319.977114074
assert accepted['candidate']['complete_performance_result_valid']
assert accepted['disposition'] == 'retain_candidate'
assert not accepted['complete_10k_performance_claim'] and not accepted['publication_attempted']
assert len(accepted['original_failed_checks']) == 9
controls = read(retire.PACKET / 'corruption-controls.json')
assert controls['status'] == 'passed' and controls['query_executions'] == 0
assert controls['positive_controls'] == 2 and controls['rejected_corruptions'] == 20
assert len(controls['controls']) == 22
assert controls['acceptance_manifest'] == identity(retire.PACKET / 'acceptance.json')

directory = retire.TARGET
retirement, plan = read(directory / 'receipt.json'), read(directory / 'plan.json')
assert retirement['status'] == 'passed' and retirement['head'] == pre['head']
assert retirement['removed'] == plan['entries']
assert retirement['retained_files_unchanged'] and retirement['input_generations_unchanged']
assert retirement['portable_replay_after_retirement'] == 'passed'
assert retirement['historical_member_identities_preserved'] and retirement['original_failed_observations_preserved']
assert not retirement['storage_limits_changed'] and not retirement['payload_backup_created']
assert retirement['manifest_sha256'] == plan['manifest_sha256'] == identity(directory / 'manifest.json.xz')['sha256']
assert plan['script_sha256'] == identity(N / 'hosted-tools/retire_index_intermediates.py')['sha256']
assert plan['helper_sha256'] == identity(retire.HELPER)['sha256']
manifest = json.loads(lzma.decompress((directory / 'manifest.json.xz').read_bytes()))
assert manifest['hosted'] == retirement['hosted'] == hosted
assert all(not Path(path).exists() and not Path(path).is_symlink() for path in manifest['roots'])
assert retire.retained() == manifest['retained']
assert retire.inputs() == manifest['input_generations']
assert len(manifest['input_generations']) == 220
replays = retirement['post_retirement_replays']
assert {row['packet'] for row in replays} == {folder.name for folder in retire.PACKETS}
for row in replays:
    assert row['returncode'] == 0 and row['result']['query_executions'] == 0
    assert identity(directory / (row['packet'] + '.stdout.json')) == row['stdout']
    assert identity(directory / (row['packet'] + '.stderr.log')) == row['stderr']
    assert read(directory / (row['packet'] + '.stdout.json')) == row['result']
index_replay = next(row['result'] for row in replays if row['packet'] == retire.PACKET.name)
assert index_replay['status'] == 'passed_source_bound_replay'
assert index_replay['baseline_cases'] == index_replay['candidate_cases'] == 2452
assert index_replay['outcomes'] == dict(baseline={'passed': 2452}, candidate={'passed': 2452})
assert index_replay['engine_execution_seconds'] == dict(baseline=320.508980218, candidate=319.977114074)
assert index_replay['disposition'] == 'retain_candidate' and not index_replay['complete_10k_performance_claim']
dictionary_replay = next(row['result'] for row in replays if row['packet'] == retire.PREVIOUS.name)
assert dictionary_replay['status'] == 'passed'
assert dictionary_replay['original_outcomes'] == dict(passed=9904, crashed=76, harness_error=20)
assert dictionary_replay['candidate_outcomes'] == dict(passed=517)
assert not dictionary_replay['complete_10k_performance_claim']
checkout_path = N / 'shared-index-main-checkout-r1.json'
checkout = read(checkout_path)
assert checkout['status'] == 'passed' and checkout['merge_commit'] == main['source_commit']
assert checkout['all_local_branches_unchanged'] and checkout['other_worktrees_unchanged']
assert checkout['accepted_source_tree_unchanged'] and checkout['working_tree_clean']

workflow_attempts = []
for report in (pre, main):
    names = [name for name in report['raw_sources'] if name.endswith('/workflows.json')]
    assert len(names) == 1
    for row in read(N / names[0])['workflow_runs']:
        assert isinstance(row['run_attempt'], int) and row['run_attempt'] >= 1
        workflow_attempts.append(dict(id=row['id'], head_sha=row['head_sha'],
            run_attempt=row['run_attempt'], source=str(N / names[0])))
kept = {str(path): identity(path) for path in sorted((N / 'runtime-r1').iterdir())}
assert {Path(path).name for path in kept} == {'shardloom', 'lib_native.dylib', '_native.abi3.so'}
receipts = {retire.PRE, retire.MAIN, retire.CONTRACT, checkout_path, N / f'pr{retire.PR}-merge-r1.json',
    N / 'merge-commit-connector-r1.json', N / 'runtime-r1-identity.json', N / 'runtime-library-copy-r1.json',
    N / 'committed-source-replay-r2.json', N / 'committed-source-replay-r2.log',
    N / 'hosted-contract-r1.json'}
receipts.update(directory.iterdir())
receipts.update(N / 'draft-packet-retention-r2' / name for name in ('summary.json', 'manifest.json.xz'))
receipts.update((N / 'hosted-failure-r1').iterdir())
receipts.update(N / name for report in (pre, main) for name in report['raw_sources'])
receipts.update((N / 'hosted-tools').glob('*.py'))
receipts.update((N / 'retirement-command-logs').glob('*'))
assert not git('status', '--porcelain')
result = dict(schema='shardloom.shared_index_closeout.v1', status='complete',
    observed_at=datetime.now(timezone.utc).isoformat(), pr_url=f'https://github.com/depsilon/shardloom/pull/{retire.PR}',
    pr_head=pre['head'], merge_commit=main['source_commit'], source_tree=pre['source_tree'],
    pr_checks_passed=58, main_checks_passed=55, review_findings=False, review_url=pre['review_url'],
    main_ci_url=main['ci_run_url'], validation=accepted['checks'], documentation_checks=accepted['documentation_checks'],
    source_fingerprint_sha256=accepted['candidate_source_fingerprint_sha256'],
    runtime_sources_match_build=True, source_bound_replay='passed', retained_runtime=kept,
    installed_index_wheel_claim=False, baseline=accepted['baseline'], candidate=accepted['candidate'],
    disposition='retain_candidate', original_failed_result_records_preserved=9,
    ci_policy_correction=accepted['ci_policy_correction'],
    initial_hosted_head='c935ed5036c9dce061bcf91724a6423a069004f4',
    initial_hosted_inventory_failure='preserved; exact new diagnostic registration corrected',
    original_control_observations_preserved=True, original_10k_remains_invalid=True,
    retired_regular_files=retirement['regular_files'], retired_symlinks=retirement['symlinks'],
    retired_regular_bytes=retirement['regular_bytes'], current_inputs_unchanged=True, current_input_files=220,
    portable_replay_after_retirement='passed', post_retirement_replays=replays,
    superseded_dictionary_runtime='retired after accepted index integration; original result and runtime identities remain',
    committed_evidence={str(path.relative_to(retire.W)): identity(path)
        for folder in retire.PACKETS for path in sorted(folder.rglob('*')) if path.is_file()},
    hosted_jobs_restarted=any(row['run_attempt'] > 1 for row in workflow_attempts), workflow_attempts=workflow_attempts,
    receipts={str(path.relative_to(N)): identity(path) for path in sorted(receipts)},
    working_tree_clean=True, complete_10k_performance_claim=False, statistical_confidence_claim=False,
    publication_attempted=False, storage_limits_changed=False, payload_backup_created=False,
    whole_item_19_complete=False, whole_item_20_complete=False,
    next_queue_unit='Investigate compatible window traversal and accumulator state independently; rolling DISTINCT follows with a separate storage objective.',
    original_limitations=accepted['limitations'],
    limitation_update='Hosted index integration and verified retirement complete; single-cohort and separate-baseline limitations remain.')
with DEST.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: result[key] for key in ('status', 'merge_commit', 'pr_checks_passed', 'main_checks_passed',
    'retired_regular_files', 'retired_symlinks', 'complete_10k_performance_claim')}))
