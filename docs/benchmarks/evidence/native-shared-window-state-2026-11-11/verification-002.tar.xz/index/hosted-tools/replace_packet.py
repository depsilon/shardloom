"""Replace only the verified previous task packet with its CI-policy correction."""
import hashlib
import json
from pathlib import Path
import shutil

N = Path(__file__).resolve().parents[1]
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
source, previous = N / 'packet-final-r2', N / 'packet-final-r1'
target = W / 'docs/benchmarks/evidence/native-shared-index-metadata-2026-11-10'


def identity(path):
    assert path.is_file() and not path.is_symlink(), path
    with path.open('rb') as stream:
        return dict(bytes=path.stat().st_size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest())


def inventory(root):
    return {path.relative_to(root).as_posix(): identity(path) for path in sorted(root.rglob('*'))
        if path.is_file() and path.name != 'README.md'}


old = inventory(previous)
assert inventory(target) == old
extras = {}
for name, prefix in (('portable-final-r2', 'packaging-execution'), ('packet-controls-r2', 'controls-execution')):
    receipt = json.loads((N / (name + '.json')).read_bytes())
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert receipt['fixed_source_validation'] and not receipt['allow_lockfile_update']
    assert receipt['log_sha256'] == identity(N / (name + '.log'))['sha256']
    for suffix in ('.json', '.log'):
        extras[prefix + suffix] = N / (name + suffix)
controls = json.loads((source / 'corruption-controls.json').read_bytes())
assert controls['status'] == 'passed' and controls['positive_controls'] == 2
assert controls['rejected_corruptions'] == 20 and controls['query_executions'] == 0
assert controls['acceptance_manifest'] == identity(source / 'acceptance.json')
required = sum(path.stat().st_size for path in source.rglob('*') if path.is_file())
assert shutil.disk_usage(source).free >= (12 << 30) + required + (128 << 20)
for name, path in extras.items():
    destination = source / name
    assert not destination.exists()
    with path.open('rb') as src, destination.open('xb') as dst:
        shutil.copyfileobj(src, dst, 1 << 20)
    assert identity(destination) == identity(path)
new = inventory(source)
assert inventory(target) == old
for name, expected in new.items():
    path, destination = source / name, target / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    assert identity(path) == expected
    if name in old:
        assert identity(destination) == old[name]
    else:
        assert not destination.exists() and not destination.is_symlink()
    shutil.copyfile(path, destination)
    assert identity(destination) == expected
for name in old.keys() - new.keys():
    path = target / name
    assert identity(path) == old[name]
    path.unlink()
assert inventory(target) == inventory(source) == new
result = dict(status='passed', source=str(source), destination=str(target), files=new,
    prior_files=old, query_executions=0, previous_local_packet_retained=True,
    source_and_destination_byte_identical=True)
with (N / 'repository-packet-copy-proof-r2.json').open('x') as output:
    json.dump(result, output, indent=2); output.write('\n')
print(json.dumps(dict(status='passed', files=len(new), query_executions=0)))
