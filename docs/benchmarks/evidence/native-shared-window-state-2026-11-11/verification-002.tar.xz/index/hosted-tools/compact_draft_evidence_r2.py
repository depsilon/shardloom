"""Preserve draft-only source/receipt bytes before retiring duplicate archive payloads."""
import hashlib
import importlib.util
import io
import json
import lzma
from pathlib import Path
import shutil
import tarfile

D = Path(__file__).resolve().parents[1]
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
PACKET = W/'docs/benchmarks/evidence/native-shared-index-metadata-2026-11-10'
TARGET = D/'draft-packet-retention-r2'
assert not TARGET.exists() and shutil.disk_usage(D).free >= (12 << 30)+(64 << 20)

def identity(raw):
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def file_identity(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as source:
        return dict(bytes=path.stat().st_size,sha256=hashlib.file_digest(source,'sha256').hexdigest())

def verifier(directory,name):
    spec = importlib.util.spec_from_file_location(name,directory/'verify.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class DigestWriter:
    def __init__(self):
        self.digest = hashlib.sha256()
        self.size = 0

    def write(self, raw):
        self.digest.update(raw)
        self.size += len(raw)
        return len(raw)

    def flush(self):
        pass


def reconstruct_archive_identities(report, data):
    stored = {row['path']: row for row in report['stored_members']}
    parts = {}
    for assembly in report['assemblies']:
        offset = 0
        raw = data[assembly['path']]
        for name in assembly['parts']:
            size = stored[name]['bytes']
            parts[name] = raw[offset:offset + size]
            offset += size
        assert offset == len(raw)
    result = {}
    for row in report['archives']:
        output = DigestWriter()
        with tarfile.open(fileobj=output, mode='w:xz', preset=6) as archive:
            for name in row['members']:
                raw = parts[name] if name in parts else data[name]
                assert identity(raw) == {key: stored[name][key] for key in ('bytes', 'sha256')}
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode, entry.mtime = len(raw), 0o644, 0
                archive.addfile(entry, io.BytesIO(raw))
        expected = {key: row[key] for key in ('bytes', 'sha256')}
        assert dict(bytes=output.size, sha256=output.digest.hexdigest()) == expected
        result[row['path']] = expected
    return result

current = verifier(PACKET,'final_packet')
accepted,final_data = current.read_archive(PACKET)
current.verify_sources(accepted,final_data,W)
current.verify_controls(PACKET,accepted,final_data)
known = {(row['bytes'],row['sha256']):row['path'] for row in accepted['members']}
final_files = {str(path):file_identity(path) for path in sorted(PACKET.rglob('*')) if path.is_file()}
unique,drafts = {},{}
for name in ('packet-r1','packet-r2','packet-r3','packet-final-r1'):
    directory = D/name
    assert directory.is_dir() and directory.resolve() == directory
    report,data = verifier(directory,'draft_'+name.replace('-','_')).read_archive(directory)
    archive_names = {row['path'] for row in report['archives']}
    ordinary = {path.relative_to(directory).as_posix(): file_identity(path)
        for path in sorted(directory.rglob('*')) if path.is_file() and path.name not in archive_names}
    assert {'acceptance.json', 'verify.py'} <= set(ordinary)
    references = {}
    for member,raw in data.items():
        item = identity(raw)
        key = (item['bytes'],item['sha256'])
        if key in known:
            retained = known[key]
            assert final_data[retained] == raw
            references[member] = dict(kind='committed_member',path=retained,**item)
        else:
            # Only small textual source, receipt or diagnostic changes may be
            # unique. Large datasets, ledgers and runtime payloads must already
            # have an exact committed replacement or stop this preparation.
            assert len(raw) < 2 << 20,member
            raw.decode('utf-8')
            assert item['sha256'] not in unique or unique[item['sha256']] == raw
            unique[item['sha256']] = raw
            references[member] = dict(kind='retained_draft_member',path=item['sha256'],**item)
    assert sum(map(len,unique.values())) < 16 << 20
    for member,reference in references.items():
        restored = (final_data[reference['path']] if reference['kind'] == 'committed_member'
            else unique[reference['path']])
        assert restored == data[member]
    reconstructed = reconstruct_archive_identities(report, data)
    drafts[name] = dict(members=references,
        metadata={str(directory/file): item for file,item in ordinary.items()},
        archives={str(directory/row['path']):file_identity(directory/row['path']) for row in report['archives']},
        all_logical_members_byte_identical_after_reconstruction=True,
        compressed_archives_reconstructed_byte_exact=reconstructed)
    del data
assert {name:file_identity(Path(name)) for name in final_files} == final_files
TARGET.mkdir()
for sha,raw in unique.items():
    with (TARGET/sha).open('xb') as destination:
        destination.write(raw)
    assert file_identity(TARGET/sha) == identity(raw)
manifest = dict(schema='shardloom.shared_index_draft_retention.v1',status='passed',
    query_executions=0,deletions=0,payload_backup_created=False,
    committed_packet_files=final_files,drafts=drafts,
    retained_draft_members={sha:identity(raw) for sha,raw in unique.items()},
    retained_unique_bytes=sum(map(len,unique.values())),
    original_metadata_remains_at_original_paths=True,script=file_identity(Path(__file__)))
encoded = json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()
compressed = lzma.compress(encoded,preset=6)
assert len(compressed) < 8 << 20 and lzma.decompress(compressed) == encoded
with (TARGET/'manifest.json.xz').open('xb') as output:
    output.write(compressed)
summary = dict(status='passed',drafts=len(drafts),
    retained_unique_members=len(unique),retained_unique_bytes=manifest['retained_unique_bytes'],
    original_archive_bytes=sum(row['bytes'] for draft in drafts.values() for row in draft['archives'].values()),
    manifest=file_identity(TARGET/'manifest.json.xz'),query_executions=0,deletions=0)
with (TARGET/'summary.json').open('x') as output:
    json.dump(summary,output,indent=2);output.write('\n')
print(json.dumps(summary))
