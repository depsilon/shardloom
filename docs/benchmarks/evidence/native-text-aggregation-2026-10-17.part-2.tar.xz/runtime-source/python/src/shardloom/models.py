"""Typed models for ShardLoom CLI JSON envelopes."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import field
from typing import Any

from ._compat import dataclass

OUTPUT_ENVELOPE_SCHEMA_VERSION = "shardloom.output.v2"
RUNTIME_EXECUTION_ENVELOPE_VALIDATION_SCHEMA_VERSION = (
    "shardloom.runtime_execution_envelope_validation.v1"
)
RUNTIME_ACTIVATION_SUMMARY_SCHEMA_VERSION = "shardloom.runtime_activation_summary.v1"
RUNTIME_ROUTE_STATE_REF_FIELDS = (
    "source_state_id",
    "source_state_digest",
    "prepared_state_id",
    "prepared_state_digest",
    "output_plan_digest",
    "generated_source_plan_digest",
    "vortex_artifact_digest",
    "plan_id",
)
RUNTIME_MATERIALIZATION_OR_DECODE_FIELDS = (
    "materialization_boundary",
    "source_state_materialization_layout",
    "source_state_runtime_consumption_layout",
    "source_state_scalar_runtime_materialization_required",
    "operator_temporary_materialization_used",
    "representation_transitions",
    "data_decoded",
    "data_materialized",
    "materialization_boundary_report_emitted",
    "prepared_native_vortex_lifecycle_materialization_decode_status",
    "prepared_native_vortex_lifecycle_data_decoded",
    "prepared_native_vortex_lifecycle_data_materialized",
)
RUNTIME_EXECUTION_CERTIFICATE_REF_FIELDS = (
    "execution_certificate_ref",
    "execution_certificate_refs",
    "execution_certificate_id",
    "runtime_execution_certificate_ref",
    "runtime_execution_certificate_refs",
    "runtime_execution_certificate_id",
    "prepared_vortex_scale_split_execution_certificate_id",
    "prepared_vortex_scale_split_operator_execution_certificate_id",
)
RUNTIME_FALLBACK_ALIAS_FIELDS = (
    "fallback_attempted",
    "runtime_fallback_attempted",
    "evidence_level_fallback_attempted",
    "prepared_native_vortex_lifecycle_fallback_attempted",
    "prepare_batch_lifecycle_fallback_attempted",
    "pulseweave_fallback_attempted",
)
RUNTIME_EXTERNAL_ENGINE_ALIAS_FIELDS = (
    "external_engine_invoked",
    "runtime_external_query_engine_invoked",
    "evidence_level_external_engine_invoked",
    "prepared_native_vortex_lifecycle_external_engine_invoked",
    "prepare_batch_lifecycle_external_engine_invoked",
    "pulseweave_external_engine_invoked",
)
REQUIRED_OUTPUT_ENVELOPE_FIELDS = frozenset(
    {
        "schema_version",
        "command",
        "status",
        "summary",
        "human_text",
        "fallback",
        "diagnostics",
        "fields",
    }
)
TYPED_OUTPUT_PAYLOAD_FIELDS = frozenset(
    {
        "result",
        "result_refs",
        "artifacts",
        "artifact_refs",
        "certificates",
        "policy",
        "lifecycle",
        "capability_snapshot",
    }
)
RUNTIME_ENVELOPE_FIELD_ALIASES: Mapping[str, tuple[str, ...]] = {
    "fallback_attempted": (
        "runtime_fallback_attempted",
        "runtime_fallback_execution_attempted",
        "prepared_native_vortex_lifecycle_fallback_attempted",
        "prepare_batch_lifecycle_fallback_attempted",
        "pulseweave_fallback_attempted",
    ),
    "external_engine_invoked": (
        "runtime_external_engine_invoked",
        "runtime_external_query_engine_invoked",
        "external_query_engine_invoked",
        "prepared_native_vortex_lifecycle_external_engine_invoked",
        "prepare_batch_lifecycle_external_engine_invoked",
        "pulseweave_external_engine_invoked",
    ),
    "claim_gate_status": (
        "runtime_claim_gate_status",
        "evidence_level_claim_gate_status",
        "prepared_native_vortex_lifecycle_claim_gate_status",
        "prepare_batch_lifecycle_claim_gate_status",
    ),
    "source_state_id": ("source_artifact_ref", "source_ref", "source_location"),
    "source_state_digest": ("source_artifact_digest", "source_digest"),
    "prepared_state_id": (
        "prepared_artifact_ref",
        "vortex_artifact_ref",
        "fact_vortex_path",
    ),
    "prepared_state_digest": (
        "prepared_artifact_digest",
        "vortex_artifact_digest",
        "fact_vortex_digest",
    ),
    "output_plan_digest": (
        "output_digest",
        "sink_artifact_digest",
        "computed_result_vortex_digest",
    ),
    "plan_id": ("output_plan_id", "sink_artifact_ref", "computed_result_vortex_path"),
    "materialization_boundary": (
        "materialization_boundary_reported",
        "materialization_boundary_report_emitted",
        "source_state_materialization_decode_boundary_ref",
        "prepared_state_materialization_decode_boundary_ref",
    ),
    "representation_transitions": (
        "native_io_representation_transitions",
        "representation_transition_summary",
    ),
    "data_decoded": (
        "decode_required",
        "scan_data_decoded",
        "fused_pipeline_data_decoded",
        "prepared_native_vortex_lifecycle_data_decoded",
    ),
    "data_materialized": (
        "materialization_required",
        "scan_data_materialized",
        "fused_pipeline_data_materialized",
        "prepared_native_vortex_lifecycle_data_materialized",
    ),
    "preparation_included": (
        "compatibility_import_included",
        "preparation_included_in_timing",
    ),
}
EXECUTION_CERTIFICATE_REF_FIELDS = RUNTIME_EXECUTION_CERTIFICATE_REF_FIELDS + (
    "native_vortex_admission_execution_certificate_refs",
)
EXECUTION_CERTIFICATE_STATUS_FIELDS = (
    "runtime_execution_certificate_status",
    "execution_certificate_status",
    "execution_certificate_emitted",
    "local_primitive_execution_certificate_emitted",
    "prepared_vortex_scale_split_execution_certificate_status",
    "prepared_vortex_scale_split_operator_execution_certificate_status",
)
RUNTIME_RESULT_REPLAY_VERIFIED_FIELDS = (
    "evidence_level_result_sink_replay_verified",
    "computed_result_sink_replay_verified",
    "result_sink_replay_verified",
    "prepared_vortex_scale_split_operator_output_commit_proof_status",
)
RUNTIME_RESULT_REPLAY_REF_FIELDS = (
    "evidence_level_result_sink_replay_refs",
    "computed_result_vortex_digest",
    "computed_result_vortex_path",
    "output_plan_digest",
    "sink_artifact_digest",
)
PREPARED_VORTEX_SPLIT_OPERATOR_REQUIRED_FIELDS = (
    "prepared_vortex_scale_split_operator_family",
    "prepared_vortex_scale_split_operator_stateful",
    "prepared_vortex_scale_split_operator_shuffle_required",
    "prepared_vortex_scale_split_operator_local_combine_used",
    "prepared_vortex_scale_split_operator_global_merge_used",
    "prepared_vortex_scale_split_operator_retry_replay_status",
    "prepared_vortex_scale_split_operator_source_replay_status",
    "prepared_vortex_scale_split_operator_memory_envelope_status",
    "prepared_vortex_scale_split_operator_backpressure_status",
    "prepared_vortex_scale_split_operator_spill_policy_status",
    "prepared_vortex_scale_split_operator_output_commit_proof_status",
    "prepared_vortex_scale_split_operator_execution_certificate_status",
    "prepared_vortex_scale_split_operator_execution_certificate_id",
    "prepared_vortex_scale_split_operator_claim_gate_status",
    "prepared_vortex_scale_split_operator_fallback_attempted",
    "prepared_vortex_scale_split_operator_external_engine_invoked",
)
PREPARED_VORTEX_SPLIT_OPERATOR_BOOLEAN_FIELDS = (
    "prepared_vortex_scale_split_operator_stateful",
    "prepared_vortex_scale_split_operator_shuffle_required",
    "prepared_vortex_scale_split_operator_local_combine_used",
    "prepared_vortex_scale_split_operator_global_merge_used",
    "prepared_vortex_scale_split_operator_fallback_attempted",
    "prepared_vortex_scale_split_operator_external_engine_invoked",
)
PULSEWEAVE_REQUIRED_FIELDS = (
    "pulseweave_schema_version",
    "pulseweave_status",
    "pulseweave_application_scope",
    "pulseweave_runtime_decision_applied",
    "pulseweave_policy_mutated",
    "pulseweave_decision_digest",
    "pulseweave_blocker",
    "pulseweave_claim_gate_status",
    "pulseweave_fallback_attempted",
    "pulseweave_external_engine_invoked",
    "native_io_certificate_status",
    "flow_inventory_schema_version",
    "flow_inventory_wip_limit",
    "flow_inventory_peak_in_flight",
    "flow_inventory_ready_task_count",
    "flow_inventory_held_for_memory_count",
    "flow_inventory_held_for_downstream_count",
    "flow_inventory_completed_task_count",
    "flow_inventory_failed_task_count",
    "flow_inventory_backpressure_event_count",
    "flow_inventory_existing_scheduler_preserved",
    "scarcity_ledger_schema_version",
    "scarcity_ledger_memory_price_bps",
    "scarcity_ledger_queue_price_bps",
    "scarcity_ledger_decode_price_bps",
    "scarcity_ledger_sink_price_bps",
    "scarcity_ledger_spill_price_bps",
    "scarcity_ledger_total_price_bps",
    "scarcity_ledger_selected_action",
    "scarcity_ledger_decision_reason",
    "scarcity_ledger_decision_digest",
    "endopulse_schema_version",
    "endopulse_signal_set",
    "endopulse_previous_target_task_bytes",
    "endopulse_next_target_task_bytes",
    "endopulse_previous_wip_limit",
    "endopulse_next_wip_limit",
    "endopulse_adjustment_applied",
    "endopulse_hysteresis_state",
    "endopulse_persistent_state_used",
    "proofbound_schema_version",
    "proofbound_pre_application_status",
    "proofbound_post_application_status",
    "proofbound_required_evidence",
    "proofbound_missing_evidence",
    "proofbound_certificate_status",
    "proofbound_no_fallback_status",
    "proofbound_claim_allowed",
)
PULSEWEAVE_BOOLEAN_FIELDS = (
    "pulseweave_runtime_decision_applied",
    "pulseweave_policy_mutated",
    "pulseweave_fallback_attempted",
    "pulseweave_external_engine_invoked",
    "flow_inventory_existing_scheduler_preserved",
    "endopulse_adjustment_applied",
    "endopulse_persistent_state_used",
    "proofbound_claim_allowed",
)
PULSEWEAVE_INTEGER_FIELDS = (
    "flow_inventory_wip_limit",
    "flow_inventory_peak_in_flight",
    "flow_inventory_ready_task_count",
    "flow_inventory_held_for_memory_count",
    "flow_inventory_held_for_downstream_count",
    "flow_inventory_completed_task_count",
    "flow_inventory_failed_task_count",
    "flow_inventory_backpressure_event_count",
    "scarcity_ledger_memory_price_bps",
    "scarcity_ledger_queue_price_bps",
    "scarcity_ledger_decode_price_bps",
    "scarcity_ledger_sink_price_bps",
    "scarcity_ledger_spill_price_bps",
    "scarcity_ledger_total_price_bps",
    "endopulse_previous_target_task_bytes",
    "endopulse_next_target_task_bytes",
    "endopulse_previous_wip_limit",
    "endopulse_next_wip_limit",
)
PULSEWEAVE_CORRECTNESS_OUTPUT_FIELDS = (
    "prepared_vortex_scale_correctness_digest",
    "prepared_vortex_scale_split_operator_correctness_digest",
    "correctness_digest",
    "computed_result_vortex_digest",
    "output_plan_digest",
    "sink_artifact_digest",
)
PULSEWEAVE_NONE_LITERAL_FIELDS = (
    "pulseweave_blocker",
    "proofbound_missing_evidence",
)


@dataclass(frozen=True, slots=True)
class FallbackStatus:
    """Fallback status copied from a ShardLoom output envelope."""

    attempted: bool
    allowed: bool
    engine: str | None
    reason: str

    @classmethod
    def from_json(cls, payload: Mapping[str, Any] | None) -> "FallbackStatus":
        data = payload or {}
        return cls(
            attempted=bool(data.get("attempted", False)),
            allowed=bool(data.get("allowed", False)),
            engine=_optional_str(data.get("engine")),
            reason=str(data.get("reason", "")),
        )


@dataclass(frozen=True, slots=True)
class Diagnostic:
    """Diagnostic entry copied from a ShardLoom output envelope."""

    code: str
    severity: str
    category: str
    message: str
    feature: str | None
    reason: str | None
    suggested_next_step: str | None
    fallback: FallbackStatus

    @classmethod
    def from_json(cls, payload: Mapping[str, Any]) -> "Diagnostic":
        return cls(
            code=str(payload.get("code", "")),
            severity=str(payload.get("severity", "")),
            category=str(payload.get("category", "")),
            message=str(payload.get("message", "")),
            feature=_optional_str(payload.get("feature")),
            reason=_optional_str(payload.get("reason")),
            suggested_next_step=_optional_str(payload.get("suggested_next_step")),
            fallback=FallbackStatus.from_json(_mapping_or_none(payload.get("fallback"))),
        )


@dataclass(frozen=True, slots=True)
class FieldEntry:
    """Key/value field entry copied from a ShardLoom output envelope."""

    key: str
    value: str

    @classmethod
    def from_json(cls, payload: Mapping[str, Any]) -> "FieldEntry":
        return cls(key=str(payload.get("key", "")), value=str(payload.get("value", "")))


@dataclass(frozen=True, slots=True)
class EvidenceSummary:
    """Compact user-facing summary of what a ShardLoom command proved."""

    command: str
    status: str
    execution_mode: str | None
    engine_mode: str | None
    source_format: str | None
    output_path: str | None
    output_row_count: int | None
    source_io_performed: bool | None
    output_io_performed: bool | None
    generated_source_kind: str | None
    generated_source_row_count: int | None
    output_native_io_certificate_status: str | None
    materialization_boundary: str | None
    fallback_attempted: bool
    external_engine_invoked: bool
    claim_gate_status: str | None

    def as_dict(self) -> dict[str, Any]:
        """Return this summary as a plain mapping for simple printing/JSON encoding."""

        return {
            "command": self.command,
            "status": self.status,
            "execution_mode": self.execution_mode,
            "engine_mode": self.engine_mode,
            "source_format": self.source_format,
            "output_path": self.output_path,
            "output_row_count": self.output_row_count,
            "source_io_performed": self.source_io_performed,
            "output_io_performed": self.output_io_performed,
            "generated_source_kind": self.generated_source_kind,
            "generated_source_row_count": self.generated_source_row_count,
            "output_native_io_certificate_status": self.output_native_io_certificate_status,
            "materialization_boundary": self.materialization_boundary,
            "fallback_attempted": self.fallback_attempted,
            "external_engine_invoked": self.external_engine_invoked,
            "claim_gate_status": self.claim_gate_status,
        }


@dataclass(frozen=True, slots=True)
class RuntimeActivationSummary:
    """Compact user-facing summary of which runtime features were active."""

    schema_version: str
    command: str
    status: str
    runtime_execution: bool
    route_id: str | None
    route_runtime_status: str | None
    route_support_status: str | None
    execution_mode: str | None
    native_vortex_status: str
    native_vortex_enabled: bool
    native_vortex_required_feature_gate: str | None
    source_format: str | None
    vortex_read_path: str | None
    upstream_vortex_scan_called: bool | None
    filter_pushdown: bool | None
    projection_pushdown: bool | None
    limit_pushdown: bool | None
    pushdown_status: str | None
    source_state_reuse_allowed: bool | None
    source_state_reuse_hit: bool | None
    source_state_reuse_reason: str | None
    requested_parallelism: str | None
    detected_parallelism: int | None
    applied_parallelism: int | None
    data_decoded: bool | None
    data_materialized: bool | None
    write_io: bool | None
    sink_status: str | None
    fallback_attempted: bool
    external_engine_invoked: bool
    claim_gate_status: str | None
    blocker_id: str | None
    blocker_reason: str | None
    unsupported_diagnostics: tuple[Mapping[str, str | None], ...]

    def as_dict(self) -> dict[str, Any]:
        """Return this summary as a JSON-serializable mapping."""

        return {
            "schema_version": self.schema_version,
            "command": self.command,
            "status": self.status,
            "runtime_execution": self.runtime_execution,
            "route_id": self.route_id,
            "route_runtime_status": self.route_runtime_status,
            "route_support_status": self.route_support_status,
            "execution_mode": self.execution_mode,
            "native_vortex_status": self.native_vortex_status,
            "native_vortex_enabled": self.native_vortex_enabled,
            "native_vortex_required_feature_gate": self.native_vortex_required_feature_gate,
            "source_format": self.source_format,
            "vortex_read_path": self.vortex_read_path,
            "upstream_vortex_scan_called": self.upstream_vortex_scan_called,
            "filter_pushdown": self.filter_pushdown,
            "projection_pushdown": self.projection_pushdown,
            "limit_pushdown": self.limit_pushdown,
            "pushdown_status": self.pushdown_status,
            "source_state_reuse_allowed": self.source_state_reuse_allowed,
            "source_state_reuse_hit": self.source_state_reuse_hit,
            "source_state_reuse_reason": self.source_state_reuse_reason,
            "requested_parallelism": self.requested_parallelism,
            "detected_parallelism": self.detected_parallelism,
            "applied_parallelism": self.applied_parallelism,
            "data_decoded": self.data_decoded,
            "data_materialized": self.data_materialized,
            "write_io": self.write_io,
            "sink_status": self.sink_status,
            "fallback_attempted": self.fallback_attempted,
            "external_engine_invoked": self.external_engine_invoked,
            "claim_gate_status": self.claim_gate_status,
            "blocker_id": self.blocker_id,
            "blocker_reason": self.blocker_reason,
            "unsupported_diagnostics": [dict(item) for item in self.unsupported_diagnostics],
        }


@dataclass(frozen=True, slots=True)
class ClaimSummary:
    """Compact user-facing summary of what may and may not be claimed."""

    status: str
    claim_gate_status: str | None
    support_status: str | None
    blocker_id: str | None
    fallback_attempted: bool
    external_engine_invoked: bool
    public_performance_claim_allowed: bool

    def as_dict(self) -> dict[str, Any]:
        """Return this summary as a plain mapping for simple printing/JSON encoding."""

        return {
            "status": self.status,
            "claim_gate_status": self.claim_gate_status,
            "support_status": self.support_status,
            "blocker_id": self.blocker_id,
            "fallback_attempted": self.fallback_attempted,
            "external_engine_invoked": self.external_engine_invoked,
            "public_performance_claim_allowed": self.public_performance_claim_allowed,
        }


@dataclass(frozen=True, slots=True)
class RuntimeEnvelopeValidationIssue:
    """One runtime-envelope validation blocker."""

    code: str
    field: str
    message: str

    def as_dict(self) -> dict[str, str]:
        """Return this issue as a plain JSON-serializable mapping."""

        return {
            "code": self.code,
            "field": self.field,
            "message": self.message,
        }


@dataclass(frozen=True, slots=True)
class RuntimeEnvelopeValidationReport:
    """Versioned validation result for a runtime-claim envelope."""

    schema_version: str
    surface_id: str
    command: str
    status: str
    runtime_expected: bool
    execution_mode: str | None
    claim_gate_status: str | None
    fallback_attempted: bool
    external_engine_invoked: bool
    issues: tuple[RuntimeEnvelopeValidationIssue, ...]

    @property
    def passed(self) -> bool:
        """Whether the runtime envelope satisfied the required evidence contract."""

        return self.status == "passed"

    @property
    def blockers(self) -> tuple[str, ...]:
        """Return human-readable blockers for release gates and tests."""

        return tuple(issue.message for issue in self.issues)

    @property
    def missing_fields(self) -> tuple[str, ...]:
        """Return required fields or field groups that were missing."""

        return tuple(
            issue.field for issue in self.issues if issue.code == "missing_required_field"
        )

    @property
    def invalid_fields(self) -> tuple[str, ...]:
        """Return fields present with invalid or unsafe values."""

        return tuple(
            issue.field for issue in self.issues if issue.code != "missing_required_field"
        )

    @property
    def runtime_claim_allowed(self) -> bool:
        """Whether this envelope can support a production runtime claim."""

        return self.passed and self.claim_gate_status == "claim_grade"

    def as_dict(self) -> dict[str, Any]:
        """Return this validation report as a plain mapping."""

        return {
            "schema_version": self.schema_version,
            "surface_id": self.surface_id,
            "command": self.command,
            "status": self.status,
            "runtime_expected": self.runtime_expected,
            "execution_mode": self.execution_mode,
            "claim_gate_status": self.claim_gate_status,
            "fallback_attempted": self.fallback_attempted,
            "external_engine_invoked": self.external_engine_invoked,
            "runtime_claim_allowed": self.runtime_claim_allowed,
            "missing_fields": self.missing_fields,
            "invalid_fields": self.invalid_fields,
            "blockers": self.blockers,
            "issues": [issue.as_dict() for issue in self.issues],
        }


@dataclass(frozen=True, slots=True)
class OutputEnvelope:
    """Parsed ShardLoom `OutputEnvelope` JSON payload."""

    schema_version: str
    command: str
    status: str
    summary: str
    human_text: str
    fallback: FallbackStatus
    diagnostics: tuple[Diagnostic, ...]
    result: Mapping[str, Any]
    result_refs: tuple[Mapping[str, Any], ...]
    artifacts: tuple[Mapping[str, Any], ...]
    artifact_refs: tuple[Mapping[str, Any], ...]
    certificates: tuple[Mapping[str, Any], ...]
    policy: Mapping[str, Any]
    lifecycle: Mapping[str, Any]
    capability_snapshot: Mapping[str, Any]
    fields: tuple[FieldEntry, ...]
    raw: Mapping[str, Any]
    _field_map_cache: dict[str, str] | None = field(
        default=None, init=False, repr=False, compare=False
    )
    # In-process execution retains its data owner outside the serialized report.
    # Ordinary CLI envelopes never populate this field.
    _native_result: Any | None = field(
        default=None, init=False, repr=False, compare=False
    )

    @classmethod
    def from_json(cls, payload: Mapping[str, Any]) -> "OutputEnvelope":
        missing = sorted(
            (REQUIRED_OUTPUT_ENVELOPE_FIELDS | TYPED_OUTPUT_PAYLOAD_FIELDS).difference(
                payload.keys()
            )
        )
        if missing:
            raise ValueError(f"ShardLoom output envelope missing required fields: {missing}")
        schema_version = str(payload.get("schema_version", ""))
        if schema_version != OUTPUT_ENVELOPE_SCHEMA_VERSION:
            raise ValueError(
                "unsupported ShardLoom output envelope schema_version: "
                f"{schema_version}"
            )
        diagnostics = tuple(
            Diagnostic.from_json(item)
            for item in _sequence(payload.get("diagnostics"))
            if isinstance(item, Mapping)
        )
        fields = tuple(
            FieldEntry.from_json(item)
            for item in _sequence(payload.get("fields"))
            if isinstance(item, Mapping)
        )
        return cls(
            schema_version=schema_version,
            command=str(payload.get("command", "")),
            status=str(payload.get("status", "")),
            summary=str(payload.get("summary", "")),
            human_text=str(payload.get("human_text", "")),
            fallback=FallbackStatus.from_json(_mapping_or_none(payload.get("fallback"))),
            diagnostics=diagnostics,
            result=dict(_mapping_or_none(payload.get("result")) or {}),
            result_refs=_mapping_sequence(payload.get("result_refs")),
            artifacts=_mapping_sequence(payload.get("artifacts")),
            artifact_refs=_mapping_sequence(payload.get("artifact_refs")),
            certificates=_mapping_sequence(payload.get("certificates")),
            policy=dict(_mapping_or_none(payload.get("policy")) or {}),
            lifecycle=dict(_mapping_or_none(payload.get("lifecycle")) or {}),
            capability_snapshot=dict(
                _mapping_or_none(payload.get("capability_snapshot")) or {}
            ),
            fields=fields,
            raw=dict(payload),
        )

    @classmethod
    def from_field_mapping(
        cls,
        fields: Mapping[str, Any],
        *,
        command: str = "runtime-field-mapping",
        status: str = "success",
        summary: str = "runtime field mapping",
        human_text: str = "runtime field mapping",
        fallback_attempted: bool = False,
    ) -> "OutputEnvelope":
        """Create an output envelope from a flat evidence mapping.

        This is used by report and benchmark tooling that already has the
        command evidence as key/value fields but not the full CLI envelope.
        """

        result_fields = [
            {"key": str(key), "value": _field_value_to_str(value)}
            for key, value in fields.items()
            if value is not None
        ]
        return cls.from_json(
            {
                "schema_version": OUTPUT_ENVELOPE_SCHEMA_VERSION,
                "command": command,
                "status": status,
                "summary": summary,
                "human_text": human_text,
                "fallback": {
                    "attempted": fallback_attempted,
                    "allowed": False,
                    "engine": None,
                    "reason": "disabled",
                },
                "diagnostics": [],
                "result": {"fields": result_fields},
                "result_refs": [],
                "artifacts": [],
                "artifact_refs": [],
                "certificates": [],
                "policy": {"fields": []},
                "lifecycle": {"fields": []},
                "capability_snapshot": {"fields": []},
                "fields": [],
            }
        )

    @property
    def is_error(self) -> bool:
        """Whether the command status represents an error or unsupported result."""

        return self.status in {"error", "unsupported"}

    @property
    def has_error_diagnostics(self) -> bool:
        """Whether the report includes error/fatal diagnostics for inspection."""

        return any(
            diagnostic.severity in {"error", "fatal"} for diagnostic in self.diagnostics
        )

    @property
    def field_map(self) -> dict[str, str]:
        """Return typed payload fields plus the temporary legacy mirror.

        The typed `result`, `policy`, `lifecycle`, and `capability_snapshot`
        payloads are the primary machine-readable surface. The flat `fields`
        mirror remains a compatibility fallback while CLI command families
        migrate.
        """

        if self._field_map_cache is not None:
            return self._field_map_cache

        merged = {entry.key: entry.value for entry in self.fields}
        for payload in (
            self.result,
            self.policy,
            self.lifecycle,
            self.capability_snapshot,
        ):
            merged.update(_typed_payload_field_map(payload))
        object.__setattr__(self, "_field_map_cache", merged)
        return merged

    @property
    def legacy_field_map(self) -> dict[str, str]:
        """Return only the temporary flat `fields` mirror."""

        return {entry.key: entry.value for entry in self.fields}

    def field(self, key: str, default: str | None = None) -> str | None:
        """Return a field value by key, preserving the CLI string value."""

        return self.field_map.get(key, default)

    def field_bool(self, key: str, default: bool | None = None) -> bool | None:
        """Return a boolean field parsed from ShardLoom's stable string values."""

        value = self.field(key)
        if value is None:
            return default
        normalized = value.strip().lower()
        if normalized == "true":
            return True
        if normalized == "false":
            return False
        raise ValueError(f"field {key!r} is not a boolean value: {value!r}")

    def field_int(self, key: str, default: int | None = None) -> int | None:
        """Return an integer field parsed from ShardLoom's stable string values."""

        value = self.field(key)
        if value is None:
            return default
        try:
            return int(value)
        except ValueError as exc:
            raise ValueError(f"field {key!r} is not an integer value: {value!r}") from exc

    @property
    def evidence_summary(self) -> EvidenceSummary:
        """Return a compact summary of runtime, I/O, certificate, and claim fields."""

        return EvidenceSummary(
            command=self.command,
            status=self.status,
            execution_mode=self.field("execution_mode"),
            engine_mode=self.field("engine_mode"),
            source_format=self.field("source_format"),
            output_path=self.field("output_path"),
            output_row_count=self.field_int("output_row_count"),
            source_io_performed=_field_bool_or_none(self, "source_io_performed"),
            output_io_performed=_field_bool_or_none(self, "output_io_performed"),
            generated_source_kind=self.field("generated_source_kind"),
            generated_source_row_count=self.field_int("generated_source_row_count"),
            output_native_io_certificate_status=self.field(
                "output_native_io_certificate_status"
            ),
            materialization_boundary=self.field("materialization_boundary"),
            fallback_attempted=self.fallback.attempted
            or self.field_bool("fallback_attempted", False) is True,
            external_engine_invoked=self.field_bool("external_engine_invoked", False)
            is True,
            claim_gate_status=self.field("claim_gate_status"),
        )

    @property
    def claim_summary(self) -> ClaimSummary:
        """Return a compact claim-boundary summary."""

        claim_gate_status = self.field("claim_gate_status")
        return ClaimSummary(
            status=self.status,
            claim_gate_status=claim_gate_status,
            support_status=self.field("support_status"),
            blocker_id=self.field("blocker_id"),
            fallback_attempted=self.fallback.attempted
            or self.field_bool("fallback_attempted", False) is True,
            external_engine_invoked=self.field_bool("external_engine_invoked", False)
            is True,
            public_performance_claim_allowed=claim_gate_status == "claim_grade",
        )

    @property
    def activation_summary(self) -> RuntimeActivationSummary:
        """Return compact runtime-feature activation evidence for this envelope."""

        return runtime_activation_summary(self)

    def runtime_execution_validation(
        self,
        *,
        surface_id: str = "runtime",
        runtime_expected: bool = True,
        execution_mode: str | None = None,
    ) -> RuntimeEnvelopeValidationReport:
        """Validate this envelope before treating it as runtime evidence."""

        return validate_runtime_execution_envelope(
            self,
            surface_id=surface_id,
            runtime_expected=runtime_expected,
            execution_mode=execution_mode,
        )


def validate_runtime_execution_envelope(
    envelope: OutputEnvelope,
    *,
    surface_id: str = "runtime",
    runtime_expected: bool = True,
    execution_mode: str | None = None,
) -> RuntimeEnvelopeValidationReport:
    """Return a versioned no-fallback runtime evidence validation report."""

    issues: list[RuntimeEnvelopeValidationIssue] = []
    selected_execution_mode = (
        execution_mode
        or _runtime_field(envelope, "selected_execution_mode")
        or _runtime_field(envelope, "execution_mode")
    )
    if runtime_expected and envelope.status != "success":
        issues.append(
            RuntimeEnvelopeValidationIssue(
                code="invalid_runtime_status",
                field="status",
                message=(
                    "runtime validation expected a successful execution envelope, "
                    f"got status={envelope.status}"
                ),
            )
        )

    for field in ("fallback_attempted", "external_engine_invoked", "claim_gate_status"):
        if not _field_present(envelope, field):
            issues.append(
                RuntimeEnvelopeValidationIssue(
                    code="missing_required_field",
                    field=field,
                    message=f"runtime envelope is missing required field {field}",
                )
            )
    for field in ("fallback_attempted", "external_engine_invoked"):
        if _field_present(envelope, field) and _safe_field_bool(envelope, field) is None:
            issues.append(
                RuntimeEnvelopeValidationIssue(
                    code="invalid_runtime_field",
                    field=field,
                    message=f"runtime envelope field {field} must be true or false",
                )
            )

    fallback_attempted = envelope.fallback.attempted or (
        _safe_field_bool(envelope, "fallback_attempted") is True
    )
    external_engine_invoked = (
        _safe_field_bool(envelope, "external_engine_invoked") is True
    )
    if fallback_attempted:
        issues.append(
            RuntimeEnvelopeValidationIssue(
                code="unsafe_runtime_field",
                field="fallback_attempted",
                message="runtime envelope attempted fallback execution",
            )
        )
    if external_engine_invoked:
        issues.append(
            RuntimeEnvelopeValidationIssue(
                code="unsafe_runtime_field",
                field="external_engine_invoked",
                message="runtime envelope invoked an external execution engine",
            )
        )

    runtime_execution = (
        parse_field_bool_value(_runtime_field(envelope, "runtime_execution"), default=False)
        is True
    )
    support_classification = (
        _runtime_field(envelope, "support_state")
        or _runtime_field(envelope, "support_status")
        or _runtime_field(envelope, "row_classification")
    )
    if runtime_execution and support_classification in {
        "report_only",
        "diagnostic_only",
        "external_baseline_only",
    }:
        issues.append(
            RuntimeEnvelopeValidationIssue(
                code="invalid_runtime_field",
                field="runtime_execution",
                message="report-only or diagnostic row cannot masquerade as runtime support",
            )
        )

    evidence_level = (
        _runtime_field(envelope, "selected_evidence_level")
        or _runtime_field(envelope, "evidence_level")
        or _runtime_field(envelope, "ingress_certification_level")
    )
    claim_gate_status = _runtime_field(envelope, "claim_gate_status")
    if evidence_level == "minimal_runtime" and claim_gate_status == "claim_grade":
        issues.append(
            RuntimeEnvelopeValidationIssue(
                code="invalid_runtime_field",
                field="evidence_level",
                message="minimal_runtime evidence cannot be promoted to claim_grade",
            )
        )
    if claim_gate_status == "claim_grade":
        if _safe_field_bool(envelope, "claim_grade_requirements_met") is not True:
            issues.append(
                RuntimeEnvelopeValidationIssue(
                    code="invalid_runtime_field",
                    field="claim_grade_requirements_met",
                    message=(
                        "claim_grade runtime evidence requires "
                        "claim_grade_requirements_met=true"
                    ),
                )
            )
        if not _execution_certificate_status_certified(envelope):
            issues.append(
                RuntimeEnvelopeValidationIssue(
                    code="invalid_runtime_field",
                    field="execution_certificate_status",
                    message=(
                        "claim_grade runtime evidence requires a certified "
                        "execution certificate status"
                    ),
                )
            )

    if evidence_level in {"certified", "full_replay"} and not (
        _execution_certificate_status_certified(envelope)
    ):
        issues.append(
            RuntimeEnvelopeValidationIssue(
                code="invalid_runtime_field",
                field="execution_certificate_status",
                message=(
                    "certified and full_replay evidence levels require "
                    "execution_certificate_status=certified"
                ),
            )
        )
    if evidence_level == "full_replay":
        if not _result_replay_verified(envelope):
            issues.append(
                RuntimeEnvelopeValidationIssue(
                    code="invalid_runtime_field",
                    field="result_sink_replay_verified",
                    message="full_replay evidence requires result-sink replay proof",
                )
            )
        _require_any_field(
            envelope,
            issues,
            field_group="result_sink_replay_ref",
            fields=RUNTIME_RESULT_REPLAY_REF_FIELDS,
        )

    if (
        envelope.field("prepared_vortex_scale_split_operator_runtime_status")
        == "local_split_operator_runtime_certified"
    ):
        _validate_prepared_vortex_split_operator_runtime(envelope, issues)

    if _field_present(envelope, "pulseweave_status"):
        _validate_pulseweave_runtime(envelope, issues)

    if runtime_expected and envelope.status == "success":
        _require_any_field(
            envelope,
            issues,
            field_group="route_state_ref",
            fields=RUNTIME_ROUTE_STATE_REF_FIELDS,
        )
        _require_any_field(
            envelope,
            issues,
            field_group="materialization_or_decode_evidence",
            fields=RUNTIME_MATERIALIZATION_OR_DECODE_FIELDS,
        )
        if not _execution_certificate_present(envelope):
            issues.append(
                RuntimeEnvelopeValidationIssue(
                    code="missing_required_field",
                    field="execution_certificate",
                    message=(
                        "runtime envelope is missing execution_certificate_ref, "
                        "execution_certificate_refs, or a typed execution_certificate"
                    ),
                )
            )

    if selected_execution_mode == "prepared_vortex":
        for field in ("prepared_state_id", "prepared_state_digest"):
            if not _field_present(envelope, field):
                issues.append(
                    RuntimeEnvelopeValidationIssue(
                        code="missing_required_field",
                        field=field,
                        message=f"prepared_vortex envelope is missing {field}",
                    )
                )

    if selected_execution_mode == "compatibility_import_certified":
        if _runtime_field(envelope, "timing_scope") != "cold_certified_end_to_end":
            issues.append(
                RuntimeEnvelopeValidationIssue(
                    code="invalid_runtime_field",
                    field="timing_scope",
                    message=(
                        "compatibility_import_certified envelope must disclose "
                        "timing_scope=cold_certified_end_to_end"
                    ),
                )
            )
        if _safe_field_bool(envelope, "preparation_included") is not True:
            issues.append(
                RuntimeEnvelopeValidationIssue(
                    code="invalid_runtime_field",
                    field="preparation_included",
                    message=(
                        "compatibility_import_certified envelope must disclose "
                        "preparation_included=true"
                    ),
                )
            )

    status = "passed" if not issues else "blocked"
    return RuntimeEnvelopeValidationReport(
        schema_version=RUNTIME_EXECUTION_ENVELOPE_VALIDATION_SCHEMA_VERSION,
        surface_id=surface_id,
        command=envelope.command,
        status=status,
        runtime_expected=runtime_expected,
        execution_mode=selected_execution_mode,
        claim_gate_status=_runtime_field(envelope, "claim_gate_status"),
        fallback_attempted=fallback_attempted,
        external_engine_invoked=external_engine_invoked,
        issues=tuple(issues),
    )


def validate_runtime_execution_fields(
    fields: Mapping[str, Any],
    *,
    command: str = "runtime-field-mapping",
    status: str = "success",
    surface_id: str = "runtime",
    runtime_expected: bool = True,
    execution_mode: str | None = None,
) -> RuntimeEnvelopeValidationReport:
    """Validate a flat runtime evidence mapping with the versioned envelope rules."""

    envelope = OutputEnvelope.from_field_mapping(
        fields,
        command=command,
        status=status,
        fallback_attempted=parse_field_bool_value(
            fields.get("fallback_attempted"), default=False
        )
        is True,
    )
    return validate_runtime_execution_envelope(
        envelope,
        surface_id=surface_id,
        runtime_expected=runtime_expected,
        execution_mode=execution_mode,
    )


def runtime_activation_summary(envelope: OutputEnvelope) -> RuntimeActivationSummary:
    """Return compact runtime activation evidence derived from stable envelope fields."""

    route_id = _first_runtime_field(
        envelope, "public_workflow_route_id", "route_id", "route_lane_id"
    )
    route_runtime_status = _first_runtime_field(
        envelope, "public_workflow_route_runtime_status", "route_runtime_status"
    )
    route_support_status = _first_runtime_field(
        envelope,
        "public_workflow_route_support_status",
        "route_support_status",
        "support_status",
    )
    vortex_middle_status = _first_runtime_field(
        envelope, "public_workflow_vortex_middle_status", "vortex_middle_status"
    )
    blocker_id = _first_runtime_field(
        envelope, "public_workflow_blocker_id", "blocker_id"
    )
    blocker_reason = _first_runtime_field(
        envelope, "public_workflow_blocker_reason", "blocker_reason"
    )
    native_vortex_required_feature_gate = _native_vortex_required_feature_gate(
        envelope, route_id
    )
    native_vortex_status = _native_vortex_activation_status(
        route_id=route_id,
        vortex_middle_status=vortex_middle_status,
        blocker_id=blocker_id,
    )
    return RuntimeActivationSummary(
        schema_version=RUNTIME_ACTIVATION_SUMMARY_SCHEMA_VERSION,
        command=envelope.command,
        status=envelope.status,
        runtime_execution=_first_runtime_bool(envelope, "runtime_execution") is True,
        route_id=route_id,
        route_runtime_status=route_runtime_status,
        route_support_status=route_support_status,
        execution_mode=_first_runtime_field(
            envelope,
            "public_workflow_execution_mode",
            "selected_execution_mode",
            "execution_mode",
            "engine_mode",
        ),
        native_vortex_status=native_vortex_status,
        native_vortex_enabled=native_vortex_status == "active",
        native_vortex_required_feature_gate=native_vortex_required_feature_gate,
        source_format=_first_runtime_field(
            envelope, "public_workflow_source_format", "source_format", "input_format"
        ),
        vortex_read_path=_first_runtime_field(
            envelope,
            "public_workflow_vortex_normalization_point",
            "vortex_normalization_point",
            "prepared_vortex_scan_path",
            "vortex_scan_path",
            "start_state",
            "public_workflow_start_state",
        ),
        upstream_vortex_scan_called=_first_runtime_bool(
            envelope,
            "upstream_vortex_scan_called",
            "local_primitive_upstream_scan_called",
            "prepared_vortex_scan_called",
        ),
        filter_pushdown=_first_runtime_bool(
            envelope,
            "filter_pushdown_applied",
            "local_primitive_filter_pushdown_applied",
            "scan_filter_pushed_down",
            "filter_pushed_down",
        ),
        projection_pushdown=_first_runtime_bool(
            envelope,
            "projection_pushdown_applied",
            "local_primitive_projection_pushdown_applied",
            "scan_projection_pushed_down",
            "projection_pushed_down",
            "source_state_column_pruning_applied",
        ),
        limit_pushdown=_first_runtime_bool(
            envelope, "limit_pushdown_applied", "scan_limit_pushed_down", "limit_pushed_down"
        ),
        pushdown_status=_first_runtime_field(
            envelope,
            "pushdown_status",
            "scan_pushdown_status",
            "source_state_projection_pushdown_status",
            "prepared_vortex_scan_pushdown_status",
        ),
        source_state_reuse_allowed=_first_runtime_bool(
            envelope, "source_state_reuse_allowed"
        ),
        source_state_reuse_hit=_first_runtime_bool(
            envelope, "source_state_reuse_hit", "source_state_reused"
        ),
        source_state_reuse_reason=_first_runtime_field(
            envelope, "source_state_reuse_reason", "source_state_reuse_status"
        ),
        requested_parallelism=_first_runtime_field(
            envelope,
            "requested_max_parallelism",
            "local_primitive_max_parallelism_requested",
            "public_workflow_max_parallelism",
            "max_parallelism",
        ),
        detected_parallelism=_first_runtime_int(
            envelope, "detected_parallelism", "detected_max_parallelism"
        ),
        applied_parallelism=_first_runtime_int(
            envelope,
            "applied_max_parallelism",
            "runtime_max_parallelism",
            "local_primitive_max_parallelism_requested",
            "public_workflow_max_parallelism",
            "max_parallelism",
        ),
        data_decoded=_first_runtime_bool(envelope, "data_decoded"),
        data_materialized=_first_runtime_bool(envelope, "data_materialized"),
        write_io=_first_runtime_bool(
            envelope, "write_io", "output_io_performed", "sink_io_performed"
        ),
        sink_status=_first_runtime_field(
            envelope,
            "output_plan_status",
            "output_route",
            "typed_sink_contract",
            "public_workflow_typed_sink_contract",
            "output_format",
        ),
        fallback_attempted=envelope.fallback.attempted
        or _first_runtime_bool(envelope, "fallback_attempted") is True,
        external_engine_invoked=_first_runtime_bool(envelope, "external_engine_invoked")
        is True,
        claim_gate_status=_first_runtime_field(envelope, "claim_gate_status"),
        blocker_id=blocker_id,
        blocker_reason=blocker_reason,
        unsupported_diagnostics=_unsupported_diagnostics(envelope),
    )


def parse_field_bool_value(value: Any, *, default: bool | None = None) -> bool | None:
    if value is None:
        return default
    normalized = str(value).strip().lower()
    if normalized == "true":
        return True
    if normalized == "false":
        return False
    return default


def _field_present(envelope: OutputEnvelope, key: str) -> bool:
    value = _runtime_field(envelope, key)
    if value is None:
        return False
    return value.strip().lower() not in {
        "",
        "none",
        "not_applicable",
        "missing",
        "[]",
        "{}",
        "()",
    }


def _safe_field_bool(envelope: OutputEnvelope, key: str) -> bool | None:
    value = _runtime_field(envelope, key)
    if value is None:
        return None
    return parse_field_bool_value(value)


def _first_runtime_field(envelope: OutputEnvelope, *keys: str) -> str | None:
    for key in keys:
        value = _runtime_field(envelope, key)
        if _usable_field_value(value):
            return value
    return None


def _first_runtime_bool(envelope: OutputEnvelope, *keys: str) -> bool | None:
    for key in keys:
        value = _runtime_field(envelope, key)
        parsed = parse_field_bool_value(value)
        if parsed is not None:
            return parsed
    return None


def _first_runtime_int(envelope: OutputEnvelope, *keys: str) -> int | None:
    for key in keys:
        value = _runtime_field(envelope, key)
        if not _usable_field_value(value):
            continue
        try:
            return int(value)
        except ValueError:
            continue
    return None


def _usable_field_value(value: str | None) -> bool:
    if value is None:
        return False
    return value.strip().lower() not in {
        "",
        "none",
        "not_applicable",
        "missing",
        "[]",
        "{}",
        "()",
    }


def _native_vortex_required_feature_gate(
    envelope: OutputEnvelope,
    route_id: str | None,
) -> str | None:
    explicit = _first_runtime_field(
        envelope,
        "public_workflow_native_vortex_required_feature_gate",
        "native_vortex_required_feature_gate",
        "required_feature_gate",
        "feature_gate",
    )
    if explicit is not None:
        return explicit
    for diagnostic in envelope.diagnostics:
        reason = diagnostic.reason or diagnostic.message
        if reason and "compiled_without=" in reason:
            return reason.split("compiled_without=", 1)[1].split()[0].strip(".,;")
    if route_id and route_id.startswith("native_vortex_"):
        return "default"
    return None


def _native_vortex_activation_status(
    *,
    route_id: str | None,
    vortex_middle_status: str | None,
    blocker_id: str | None,
) -> str:
    if blocker_id and blocker_id.endswith("_feature_gated"):
        return "feature_gated"
    if blocker_id and blocker_id.startswith("py-vortex-route-unify-1.native_vortex"):
        return "blocked"
    if vortex_middle_status in {
        "native_vortex_boundary",
        "native_vortex_primitive",
    }:
        return "active"
    if vortex_middle_status == "pending_native_vortex_middle_unification":
        return "pending_middle_unification"
    if route_id and route_id.startswith("native_vortex_"):
        return "active"
    return "not_applicable"


def _unsupported_diagnostics(
    envelope: OutputEnvelope,
) -> tuple[Mapping[str, str | None], ...]:
    rows: list[Mapping[str, str | None]] = []
    for diagnostic in envelope.diagnostics:
        if diagnostic.severity not in {"error", "fatal", "warning"}:
            continue
        rows.append(
            {
                "code": diagnostic.code,
                "feature": diagnostic.feature,
                "reason": diagnostic.reason or diagnostic.message,
                "suggested_next_step": diagnostic.suggested_next_step,
            }
        )
    return tuple(rows)


def _require_any_field(
    envelope: OutputEnvelope,
    issues: list[RuntimeEnvelopeValidationIssue],
    *,
    field_group: str,
    fields: tuple[str, ...],
) -> None:
    if any(_field_present(envelope, field) for field in fields):
        return
    issues.append(
        RuntimeEnvelopeValidationIssue(
            code="missing_required_field",
            field=field_group,
            message=(
                "runtime envelope is missing required evidence group "
                f"{field_group}: one of {','.join(fields)}"
            ),
        )
    )


def _execution_certificate_present(envelope: OutputEnvelope) -> bool:
    for field in EXECUTION_CERTIFICATE_REF_FIELDS:
        if _field_present(envelope, field):
            return True
    return any(_is_execution_certificate(certificate) for certificate in envelope.certificates)


def _is_execution_certificate(certificate: Mapping[str, Any]) -> bool:
    certificate_id = str(certificate.get("id", ""))
    return (
        str(certificate.get("kind", "")) == "execution_certificate"
        or certificate_id.startswith("execution.")
        or ".execution." in certificate_id
    )


def _execution_certificate_status_certified(envelope: OutputEnvelope) -> bool:
    for field in EXECUTION_CERTIFICATE_STATUS_FIELDS:
        value = envelope.field(field)
        if value is not None and value.strip().lower() == "certified":
            return True
    return any(
        _is_execution_certificate(certificate)
        and str(certificate.get("status", "")).strip().lower() == "certified"
        for certificate in envelope.certificates
    )


def _result_replay_verified(envelope: OutputEnvelope) -> bool:
    for field in RUNTIME_RESULT_REPLAY_VERIFIED_FIELDS:
        value = envelope.field(field)
        if value is None:
            continue
        normalized = value.strip().lower()
        if normalized == "true" or "replay_verified" in normalized:
            return True
    return False


def _evidence_tier_requires_result_sink_replay(envelope: OutputEnvelope) -> bool:
    explicit = _safe_field_bool(envelope, "evidence_tier_result_sink_replay_required")
    if explicit is not None:
        return explicit
    tier = (
        envelope.field("actual_evidence_tier")
        or envelope.field("selected_evidence_tier")
        or envelope.field("sink_tier")
    )
    normalized_tier = "" if tier is None else tier.strip().lower()
    if normalized_tier in {"runtime_minimal", "metadata_sink"}:
        return False
    if normalized_tier in {"full_vortex_replay", "publication_full"}:
        return True
    evidence_level = envelope.field("evidence_level")
    if evidence_level is not None:
        return evidence_level.strip().lower() == "full_replay"
    return True


def _add_invalid_issue(
    issues: list[RuntimeEnvelopeValidationIssue],
    field: str,
    message: str,
) -> None:
    issues.append(
        RuntimeEnvelopeValidationIssue(
            code="invalid_runtime_field",
            field=field,
            message=message,
        )
    )


def _validate_prepared_vortex_split_operator_runtime(
    envelope: OutputEnvelope,
    issues: list[RuntimeEnvelopeValidationIssue],
) -> None:
    for field in PREPARED_VORTEX_SPLIT_OPERATOR_REQUIRED_FIELDS:
        if not _field_present(envelope, field):
            issues.append(
                RuntimeEnvelopeValidationIssue(
                    code="missing_required_field",
                    field=field,
                    message=(
                        "certified prepared Vortex split-operator runtime is "
                        f"missing {field}"
                    ),
                )
            )
    for field in PREPARED_VORTEX_SPLIT_OPERATOR_BOOLEAN_FIELDS:
        if _field_present(envelope, field) and _safe_field_bool(envelope, field) is None:
            _add_invalid_issue(
                issues,
                field,
                f"prepared Vortex split-operator field {field} must be true or false",
            )

    required_values = {
        "prepared_vortex_scale_split_operator_execution_certificate_status": "certified",
        "prepared_vortex_scale_split_operator_claim_gate_status": (
            "local_split_operator_runtime_certified"
        ),
        "prepared_vortex_scale_split_operator_source_replay_status": (
            "prepared_vortex_source_replay_verified"
        ),
        "prepared_vortex_scale_split_operator_memory_envelope_status": (
            "declared_local_memory_envelope_admitted"
        ),
        "prepared_vortex_scale_split_operator_backpressure_status": (
            "bounded_by_reader_chunk_scheduler_and_declared_parallelism"
        ),
    }
    for field, expected in required_values.items():
        value = envelope.field(field)
        if value is not None and value != expected:
            _add_invalid_issue(
                issues,
                field,
                f"certified prepared Vortex split-operator runtime requires {field}={expected}",
            )

    if _evidence_tier_requires_result_sink_replay(envelope):
        expected = "result_sink_replay_verified_for_split_operator"
        field = "prepared_vortex_scale_split_operator_output_commit_proof_status"
        value = envelope.field(field)
        if value is not None and value != expected:
            _add_invalid_issue(
                issues,
                field,
                f"certified prepared Vortex split-operator runtime requires {field}={expected}",
            )

    retry_replay_status = envelope.field(
        "prepared_vortex_scale_split_operator_retry_replay_status"
    )
    if retry_replay_status is not None and not retry_replay_status.startswith(
        "verified_idempotent"
    ):
        _add_invalid_issue(
            issues,
            "prepared_vortex_scale_split_operator_retry_replay_status",
            "certified prepared Vortex split-operator runtime requires idempotent replay proof",
        )
    if (
        _safe_field_bool(
            envelope, "prepared_vortex_scale_split_operator_fallback_attempted"
        )
        is True
    ):
        _add_invalid_issue(
            issues,
            "prepared_vortex_scale_split_operator_fallback_attempted",
            "certified prepared Vortex split-operator runtime cannot attempt fallback",
        )
    if (
        _safe_field_bool(
            envelope, "prepared_vortex_scale_split_operator_external_engine_invoked"
        )
        is True
    ):
        _add_invalid_issue(
            issues,
            "prepared_vortex_scale_split_operator_external_engine_invoked",
            "certified prepared Vortex split-operator runtime cannot invoke an external engine",
        )


def _validate_pulseweave_runtime(
    envelope: OutputEnvelope,
    issues: list[RuntimeEnvelopeValidationIssue],
) -> None:
    for field in PULSEWEAVE_REQUIRED_FIELDS:
        present = (
            _runtime_field(envelope, field) is not None
            if field in PULSEWEAVE_NONE_LITERAL_FIELDS
            else _field_present(envelope, field)
        )
        if not present:
            issues.append(
                RuntimeEnvelopeValidationIssue(
                    code="missing_required_field",
                    field=field,
                    message=f"PulseWeave runtime evidence is missing {field}",
                )
            )
    for field in PULSEWEAVE_BOOLEAN_FIELDS:
        if _field_present(envelope, field) and _safe_field_bool(envelope, field) is None:
            _add_invalid_issue(
                issues,
                field,
                f"PulseWeave runtime field {field} must be true or false",
            )
    for field in PULSEWEAVE_INTEGER_FIELDS:
        value = envelope.field(field)
        if value is None or not _field_present(envelope, field):
            continue
        try:
            parsed = int(value)
        except ValueError:
            _add_invalid_issue(
                issues,
                field,
                f"PulseWeave runtime field {field} must be an integer",
            )
            continue
        if parsed < 0:
            _add_invalid_issue(
                issues,
                field,
                f"PulseWeave runtime field {field} must be non-negative",
            )

    if _safe_field_bool(envelope, "pulseweave_fallback_attempted") is True:
        _add_invalid_issue(
            issues,
            "pulseweave_fallback_attempted",
            "PulseWeave runtime cannot attempt fallback execution",
        )
    if _safe_field_bool(envelope, "pulseweave_external_engine_invoked") is True:
        _add_invalid_issue(
            issues,
            "pulseweave_external_engine_invoked",
            "PulseWeave runtime cannot invoke an external engine",
        )
    if _safe_field_bool(envelope, "endopulse_persistent_state_used") is True:
        _add_invalid_issue(
            issues,
            "endopulse_persistent_state_used",
            "PulseWeave first-slice EndoPulse evidence cannot use persistent state",
        )

    applied = _safe_field_bool(envelope, "pulseweave_runtime_decision_applied")
    if applied is True:
        expected_values = {
            "pulseweave_status": "applied",
            "pulseweave_blocker": "none",
            "pulseweave_claim_gate_status": "pulseweave_runtime_certified",
            "proofbound_pre_application_status": "admitted",
            "proofbound_post_application_status": "certified",
            "proofbound_certificate_status": "certified",
            "proofbound_no_fallback_status": "verified",
            "native_io_certificate_status": "certified",
        }
        for field, expected in expected_values.items():
            value = envelope.field(field)
            if value is not None and value != expected:
                _add_invalid_issue(
                    issues,
                    field,
                    f"PulseWeave applied runtime requires {field}={expected}",
                )
        if _safe_field_bool(envelope, "proofbound_claim_allowed") is not True:
            _add_invalid_issue(
                issues,
                "proofbound_claim_allowed",
                "PulseWeave applied runtime requires proofbound_claim_allowed=true",
            )
        if not _execution_certificate_status_certified(envelope):
            _add_invalid_issue(
                issues,
                "execution_certificate_status",
                "PulseWeave applied runtime requires a certified execution certificate",
            )
        _require_any_field(
            envelope,
            issues,
            field_group="pulseweave_correctness_output_digest",
            fields=PULSEWEAVE_CORRECTNESS_OUTPUT_FIELDS,
        )
    elif applied is False and envelope.field("pulseweave_status") == "applied":
        _add_invalid_issue(
            issues,
            "pulseweave_status",
            "PulseWeave status cannot be applied when runtime_decision_applied=false",
        )


def _runtime_field(envelope: OutputEnvelope, key: str) -> str | None:
    for field in (key, *RUNTIME_ENVELOPE_FIELD_ALIASES.get(key, ())):
        value = envelope.field(field)
        if value is not None:
            return value
    return None


def _optional_str(value: Any) -> str | None:
    if value is None:
        return None
    return str(value)


def _field_bool_or_none(envelope: OutputEnvelope, key: str) -> bool | None:
    value = envelope.field(key)
    if value is None:
        return None
    return envelope.field_bool(key)


def _mapping_or_none(value: Any) -> Mapping[str, Any] | None:
    if isinstance(value, Mapping):
        return value
    return None


def _sequence(value: Any) -> tuple[Any, ...]:
    if isinstance(value, list):
        return tuple(value)
    return ()


def _mapping_sequence(value: Any) -> tuple[Mapping[str, Any], ...]:
    return tuple(item for item in _sequence(value) if isinstance(item, Mapping))


def _field_value_to_str(value: Any) -> str:
    if isinstance(value, bool):
        return str(value).lower()
    if value is None:
        return "none"
    return str(value)


def _typed_payload_field_map(payload: Mapping[str, Any]) -> dict[str, str]:
    return {
        str(item.get("key", "")): str(item.get("value", ""))
        for item in _sequence(payload.get("fields"))
        if isinstance(item, Mapping)
    }
