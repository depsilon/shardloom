"""Setuptools command hooks for ShardLoom Python wheels."""

from __future__ import annotations

import os
from pathlib import Path
import platform
import re

from setuptools import Distribution, setup


def _has_native_library() -> bool:
    return (Path(__file__).resolve().parent / "src/shardloom/_native.abi3.so").is_file()


class ShardLoomDistribution(Distribution):
    """Install the staged native binding into the platform-library root."""

    def has_ext_modules(self) -> bool:
        # The binding is built before staging. The distribution must agree with
        # the wheel's Root-Is-Purelib flag so install_lib chooses platlib.
        return _has_native_library() or super().has_ext_modules()


try:
    from wheel.bdist_wheel import bdist_wheel as _bdist_wheel
except ImportError:  # pragma: no cover - setuptools sdist path without wheel
    setup(distclass=ShardLoomDistribution)
else:
    _ARCH_ALIASES = {
        "amd64": "x86_64",
        "x64": "x86_64",
        "arm64": "aarch64",
    }

    def _normalized_arch() -> str:
        arch = platform.machine().strip().lower() or "unknown"
        return _ARCH_ALIASES.get(arch, arch).replace("-", "_")

    def _normalized_macos_arch() -> str:
        arch = platform.machine().strip().lower() or "unknown"
        if arch in {"amd64", "x64"}:
            return "x86_64"
        if arch in {"aarch64", "arm64"}:
            return "arm64"
        return arch.replace("-", "_")

    def _manylinux_platform_tag() -> str | None:
        if platform.system().strip().lower() != "linux":
            return None
        libc_name, libc_version = platform.libc_ver()
        if libc_name != "glibc" or not libc_version:
            return None
        match = re.match(r"^(\d+)\.(\d+)", libc_version)
        if match is None:
            return None
        major, minor = match.groups()
        return f"manylinux_{major}_{minor}_{_normalized_arch()}"

    def _macos_platform_tag() -> str | None:
        if platform.system().strip().lower() != "darwin":
            return None
        version = os.environ.get("MACOSX_DEPLOYMENT_TARGET") or platform.mac_ver()[0]
        match = re.match(r"^(\d+)(?:\.(\d+))?", version or "")
        if match is None:
            return None
        major, minor = match.group(1), match.group(2) or "0"
        return f"macosx_{major}_{minor}_{_normalized_macos_arch()}"

    class bdist_wheel(_bdist_wheel):
        """Preserve platform tags and identify the optional stable-ABI extension."""

        def finalize_options(self) -> None:
            super().finalize_options()
            self.root_is_pure = False
            explicit_plat_name = os.environ.get("SHARDLOOM_WHEEL_PLAT_NAME")
            if explicit_plat_name:
                self.plat_name = explicit_plat_name
                return
            manylinux_tag = _manylinux_platform_tag()
            if manylinux_tag is not None:
                self.plat_name = manylinux_tag
                return
            macos_tag = _macos_platform_tag()
            if macos_tag is not None:
                self.plat_name = macos_tag

        def get_tag(self) -> tuple[str, str, str]:
            interpreter, abi, platform_tag = super().get_tag()
            if _has_native_library():
                # The optional PyO3 crate is built with abi3-py310. Ordinary
                # CLI-only wheels retain their existing py3/none tag.
                # A host glibc version does not establish manylinux compliance
                # for an extension's linked libraries. Keep this a native host
                # wheel until a separate repair/audit proves a portable tag.
                if platform.system().strip().lower() == "linux":
                    platform_tag = f"linux_{_normalized_arch()}"
                return "cp310", "abi3", platform_tag
            return interpreter, abi, platform_tag

    setup(cmdclass={"bdist_wheel": bdist_wheel}, distclass=ShardLoomDistribution)
