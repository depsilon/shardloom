"""Archive native subquery-membership evidence and source; reopen every member."""
import hashlib
import json
import lzma
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
NAME = 'native-subquery-membership-spill-2026-10-19'
DEST = OUT / 'packet-742'
DEST.mkdir(exist_ok=False)

def read(path):
    return json.loads(Path(path).read_text())

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def identity(path):
    path = Path(path)
    return {'file': path.name, 'bytes': path.stat().st_size, 'sha256': digest(path)}

accepted = read(OUT / 'perf-06-acceptance.json')
source = read(OUT / 'acceptance-source.json')
bridge = read(OUT / 'subquery-closeout-source-bridge.json')
assert accepted['status'] == 'accepted_finite_local_scope'
assert accepted['completed_substeps'] == accepted['broader_owners_closed'] == []
assert read(OUT / 'closeout-checks-742/report.json')['status'] == 'passed'
assert bridge['status'] == 'passed' and bridge['accepted_source_commit'] == source['source_commit']
assert accepted['compiled_source_commit'] == source['source_commit'] == bridge['compiled_source_commit']
for name, frozen in source['source_hashes'].items():
    expected = bridge['only_frozen_source_change'].get(name, {}).get('closeout_sha256', frozen)
    assert digest(ROOT / name) == expected, name
for name, expected in bridge['documents'].items():
    assert digest(ROOT / name) == expected, name
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head == source['source_commit']
base = source['base_commit']
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
with (OUT / 'subquery-implementation.patch').open('xb') as stream:
    stream.write(subprocess.check_output(['git', 'diff', '--binary', base, head], cwd=ROOT))
with (OUT / 'subquery-closeout-documents.patch').open('xb') as stream:
    stream.write(subprocess.check_output(['git', 'diff', '--binary'], cwd=ROOT))

members, omitted = {}, []
for evidence_root, prefix in ((OUT, 'evidence/'),):
    for path in sorted(evidence_root.rglob('*')):
        if not path.is_file():
            continue
        relative = path.relative_to(evidence_root)
        if (relative.parts[0].startswith('packet-') or '__pycache__' in relative.parts
                or (evidence_root == OUT and relative.as_posix() in ('subquery-package-742.log', 'subquery-package-742.json'))):
            continue
        assert not path.is_symlink(), path
        bulk = (relative.parts[0] in ('artifacts', 'preflight-artifacts', 'preflight-artifacts-fixed')
                or (len(relative.parts) > 1 and relative.parts[1] == 'outputs'))
        if bulk:
            omitted.append({'path': prefix + str(relative), **identity(path),
                            'scope': 'native build or generated output retained locally; complete values and regeneration sources archived'})
            continue
        assert path.stat().st_size < 128 << 20, (path, path.stat().st_size)
        members[prefix + str(relative)] = path
changed = subprocess.check_output(['git', 'diff', '--name-only', '--diff-filter=ACMR', base, head], cwd=ROOT, text=True).splitlines()
for name in sorted(set(changed) | set(bridge['documents']) | set(bridge['only_frozen_source_change'])):
    path = ROOT / name
    assert path.is_file() and not path.is_symlink()
    members['source/' + name] = path
plan = read(OUT / 'acceptance-plan.json')
for ref in plan['verification_helpers']:
    assert digest(ref['path']) == ref['sha256'] and Path(ref['path']).stat().st_size == ref['bytes']
support = [
    Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py'),
    Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'),
]
support += [Path(ref['path']) for ref in plan['query_harness']]
support += [Path(plan[key]['path']) for key in ('query_source', 'public_runner', 'reference')]
support += [Path(ref['path']) for ref in plan['schema_sources']]
for path in support:
    label = str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else path.name
    name = 'support/' + label
    assert name not in members or digest(members[name]) == digest(path)
    members[name] = path
manifest = [{'name': name, 'bytes': path.stat().st_size, 'sha256': digest(path)}
            for name, path in sorted(members.items())]
raw_bytes = sum(item['bytes'] for item in manifest)
assert raw_bytes < 1 << 30, raw_bytes
archive_paths, verified = [], []
attempt = 0

def archive_members(items):
    global attempt
    attempt += 1
    candidate = DEST / f'pending-{attempt:02d}.tar.xz'
    assert not candidate.exists()
    with tarfile.open(candidate, 'w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
        for item in items:
            info = tarfile.TarInfo(item['name'])
            info.size, info.mode, info.mtime = item['bytes'], 0o644, 0
            with members[item['name']].open('rb') as stream:
                archive.addfile(info, stream)
    if candidate.stat().st_size >= 24 << 20:
        assert len(items) > 1, 'One evidence member exceeds the unchanged archive limit'
        # Sources remain untouched. Split only our unaccepted temporary container.
        candidate.unlink()
        halfway = sum(item['bytes'] for item in items) // 2
        accumulated, cut = 0, 1
        for cut, item in enumerate(items, 1):
            accumulated += item['bytes']
            if accumulated >= halfway:
                break
        cut = max(1, min(cut, len(items) - 1))
        archive_members(items[:cut])
        archive_members(items[cut:])
        return
    archive_path = DEST / f'{NAME}.part{len(archive_paths) + 1:02d}.tar.xz'
    assert not archive_path.exists()
    candidate.rename(archive_path)
    by_name = {item['name']: item for item in items}
    part_verified = []
    with tarfile.open(archive_path, 'r:xz') as archive:
        for member in archive:
            assert member.isfile() and member.name in by_name
            expected = by_name[member.name]
            payload = archive.extractfile(member).read()
            assert len(payload) == expected['bytes']
            assert hashlib.sha256(payload).hexdigest() == expected['sha256']
            assert digest(members[member.name]) == expected['sha256']
            part_verified.append(member.name)
    assert len(part_verified) == len(set(part_verified)) == len(items)
    for item in items:
        item['archive'] = archive_path.name
    verified.extend(part_verified)
    archive_paths.append(archive_path)

archive_members(manifest)
assert len(verified) == len(set(verified)) == len(manifest)
manifest_path = DEST / (NAME + '.manifest.json.xz')
manifest_path.write_bytes(lzma.compress((json.dumps(manifest, indent=2) + '\n').encode()))
assert json.loads(lzma.decompress(manifest_path.read_bytes())) == manifest
assert read(OUT / 'perf-06-acceptance.json') == accepted
index = {
    'schema_version': 'shardloom.native_subquery_membership_evidence.v1',
    'status': 'accepted_finite_local_scope', 'scope': accepted['scope'],
    'completed_substeps': [], 'broader_owners_closed': [],
    'base_commit': base, 'source_commit': head,
    'compiled_source_commit': accepted['compiled_source_commit'],
    'acceptance': '../native-subquery-membership-spill-2026-10-19.md',
    'architecture': '../../architecture/native-subquery-membership-spill-2026-10-19.md',
    'archives': [identity(path) for path in archive_paths], 'manifest': identity(manifest_path),
    'member_count': len(manifest), 'uncompressed_bytes': raw_bytes, 'all_members_reopened': True,
    'owner_acceptance': 'evidence/perf-06-acceptance.json',
    'runtime_acceptance': 'evidence/acceptance-final-verified.json',
    'closeout_source_bridge': 'evidence/subquery-closeout-source-bridge.json',
    'compiled_source_manifest': 'evidence/acceptance-source.json',
    'failed_and_superseded_observations_retained': True,
    'public_cases': accepted['public_cases'], 'public_families': accepted['public_families'],
    'subquery_membership_public_cases': accepted['subquery_membership_public_cases'],
    'subquery_original_pressure_cases': accepted['subquery_original_pressure_cases'],
    'net_new_public_cases': accepted['net_new_public_cases'],
    'subquery_complete_value_archives': accepted['subquery_complete_value_archives'],
    'subquery_publication_failure_cases': accepted['subquery_publication_failure_cases'],
    'subquery_existing_destination_denials': accepted['subquery_existing_destination_denials'],
    'subquery_incomplete_execution_failures': accepted['subquery_incomplete_execution_failures'],
    'subquery_complete_rows_reopened': accepted['subquery_complete_rows_reopened'],
    'required_native_selectors': accepted['required_native_selectors'],
    'all_subquery_regression_selectors': accepted['all_subquery_regression_selectors'],
    'direct_binding_subcases': accepted['direct_binding_subcases'],
    'full43': accepted['full43'], 'modular_cohorts': accepted['modular_cohorts'],
    'native_workflows': accepted['native_workflows'],
    'fresh_independent_pandas_oracle_workflows': accepted['fresh_independent_pandas_oracle_workflows'],
    'remaining_owners': 14, 'remaining_substeps': 58,
    'required_substeps': 37, 'conditional_substeps': 21,
    'platform_scope': accepted['platform_scope'], 'omitted_bulk_artifacts': omitted,
    'external_input': plan['input'], 'claim_gate_status': 'not_claim_grade',
    'performance_claim': False, 'release_version_changed': False, 'publication_attempted': False,
    'limitations': accepted['unresolved'],
    'replay_note': 'Bind recorded local paths to resident inputs and a fresh evidence directory; historical output paths are immutable.',
}
index_path = DEST / (NAME + '.json')
index_path.write_text(json.dumps(index, indent=2) + '\n')
for path in (*archive_paths, manifest_path, index_path):
    assert path.stat().st_size < 24 << 20
    destination = ROOT / 'docs/benchmarks/evidence' / path.name
    assert not destination.exists()
    shutil.copyfile(path, destination)
    assert digest(path) == digest(destination)
print(json.dumps({'status': 'passed', 'members': len(manifest), 'all_members_reopened': True,
                  'archive_parts': len(archive_paths),
                  'archive_bytes': sum(path.stat().st_size for path in archive_paths)}))
