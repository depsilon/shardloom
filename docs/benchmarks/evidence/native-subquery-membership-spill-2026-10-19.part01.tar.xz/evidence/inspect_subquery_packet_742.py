"""Independently reopen the delivered subquery packet and source bindings."""
import hashlib
import json
import lzma
from pathlib import Path
import re
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
DEST = ROOT / 'docs/benchmarks/evidence'
NAME = 'native-subquery-membership-spill-2026-10-19'


def digest(payload):
    return hashlib.sha256(payload).hexdigest()


def load(ref):
    path = DEST / ref['file']
    assert path.is_file() and not path.is_symlink()
    payload = path.read_bytes()
    assert len(payload) == ref['bytes'] and digest(payload) == ref['sha256']
    assert len(payload) < 24 << 20
    return path, payload


index_path = DEST / (NAME + '.json')
index = json.loads(index_path.read_text())
assert index['schema_version'] == 'shardloom.native_subquery_membership_evidence.v1'
assert index['status'] == 'accepted_finite_local_scope' and index['all_members_reopened']
assert index['completed_substeps'] == index['broader_owners_closed'] == []
assert (index['public_families'], index['public_cases'], index['net_new_public_cases']) == (39, 5930, 438)
assert (index['subquery_membership_public_cases'], index['subquery_original_pressure_cases']) == (438, 2)
assert (index['subquery_complete_value_archives'], index['subquery_publication_failure_cases']) == (483, 24)
assert (index['subquery_existing_destination_denials'], index['subquery_incomplete_execution_failures']) == (6, 18)
assert index['subquery_complete_rows_reopened'] == 1701
assert len(index['required_native_selectors']) == 14
assert len(index['all_subquery_regression_selectors']) == 60
assert index['direct_binding_subcases'] == 48
assert (index['modular_cohorts'], index['native_workflows'], index['fresh_independent_pandas_oracle_workflows']) == (18, 704, 704)
assert (index['remaining_owners'], index['remaining_substeps'], index['required_substeps'], index['conditional_substeps']) == (14, 58, 37, 21)
assert index['source_commit'] == index['compiled_source_commit']
assert index['claim_gate_status'] == 'not_claim_grade'
for key in ('performance_claim', 'release_version_changed', 'publication_attempted'):
    assert index[key] is False
_, packed = load(index['manifest'])
manifest = json.loads(lzma.decompress(packed))
expected = {member['name']: member for member in manifest}
assert len(expected) == len(manifest) == index['member_count']
assert sum(member['bytes'] for member in manifest) == index['uncompressed_bytes'] < 1 << 30
assert {member['archive'] for member in manifest} == {part['file'] for part in index['archives']}
selected = {
    'evidence/perf-06-acceptance.json', 'evidence/acceptance-source.json',
    'evidence/acceptance-final-verified.json', 'evidence/acceptance-public-verified.json',
    'evidence/acceptance-full43-verified.json', 'evidence/acceptance-modular-verified.json',
    'evidence/subquery-closeout-source-bridge.json', 'evidence/closeout-checks-742/queue.json',
    'evidence/subquery-first-tests-738.json', 'evidence/subquery-focused-740.json',
    'evidence/subquery-direct-binding-preflight-741.json',
    'evidence/subquery-direct-binding-preflight-fixed-741.json',
    'evidence/subquery-public-preflight-fixed-741.json',
    'evidence/subquery-public-preflight-deferred-fixed-742.json',
    'evidence/subquery-public-preflight-diagnostic-fixed-742.json',
    'evidence/subquery-deferred-grant-probe-742.json',
    'evidence/subquery-preflight-values-verify-742.json',
    'evidence/subquery-preflight-values-verify-fixed-742.json',
}
records, seen = {}, set()
for part in index['archives']:
    path, _ = load(part)
    with tarfile.open(path, 'r:xz') as archive:
        for member in archive:
            assert member.isfile() and member.name in expected and member.name not in seen
            assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            wanted = expected[member.name]
            assert wanted['archive'] == part['file'] and wanted['bytes'] == member.size
            payload = archive.extractfile(member).read()
            assert len(payload) == wanted['bytes'] and digest(payload) == wanted['sha256']
            if member.name in selected:
                records[member.name] = json.loads(payload)
            if member.name.startswith('source/'):
                current = ROOT / member.name.removeprefix('source/')
                assert current.is_file() and digest(current.read_bytes()) == wanted['sha256']
            seen.add(member.name)
assert seen == set(expected) and set(records) == selected
accepted = records['evidence/perf-06-acceptance.json']
source = records['evidence/acceptance-source.json']
final = records['evidence/acceptance-final-verified.json']
public = records['evidence/acceptance-public-verified.json']
full43 = records['evidence/acceptance-full43-verified.json']
modular = records['evidence/acceptance-modular-verified.json']
bridge = records['evidence/subquery-closeout-source-bridge.json']
queue = records['evidence/closeout-checks-742/queue.json']
assert accepted['source_commit'] == source['source_commit'] == final['source_commit'] == index['source_commit']
assert accepted['scope'] == index['scope']
assert len(accepted['required_native_selectors']) == 14
assert len(accepted['all_subquery_regression_selectors']) == 60
assert accepted['required_native_selectors'] == index['required_native_selectors']
assert accepted['all_subquery_regression_selectors'] == index['all_subquery_regression_selectors']
assert accepted['direct_binding_subcases'] == 48
assert (accepted['public_families'], accepted['public_cases'], accepted['net_new_public_cases']) == (39, 5930, 438)
assert (accepted['subquery_membership_public_cases'], accepted['subquery_original_pressure_cases']) == (438, 2)
assert (accepted['subquery_complete_value_archives'], accepted['subquery_publication_failure_cases']) == (483, 24)
assert (accepted['subquery_existing_destination_denials'], accepted['subquery_incomplete_execution_failures']) == (6, 18)
assert accepted['subquery_complete_rows_reopened'] == 1701
assert (accepted['modular_cohorts'], accepted['native_workflows'], accepted['fresh_independent_pandas_oracle_workflows']) == (18, 704, 704)
assert not accepted['interrupted_execution_resume'] and not accepted['whole_process_memory_ceiling']
assert public['status'] == full43['status'] == modular['status'] == final['status'] == 'passed'
assert (public['cases'], public['families']) == (5930, 39)
assert public['subquery_membership_public_cases'] == 438 and public['subquery_original_pressure_cases'] == 2
assert len(public['subquery_complete_value_archives']) == 483
assert len(public['subquery_publication_failure_cases']) == 24
assert public['subquery_existing_destination_denials'] == 6
assert public['subquery_incomplete_execution_failures'] == 18
assert accepted['subquery_complete_rows_reopened'] == public['subquery_rows_independently_reopened'] == 1701
assert accepted['full43'] == index['full43']
assert full43['queries'] == full43['calls'] == 43 and full43['complete_rows'] == 381
assert full43['engine_execution_seconds'] == accepted['full43']['engine_execution_seconds']
assert accepted['full43']['reference_kind'] == 'retained_native_regression'
assert modular['native_workflows'] == modular['independent_pandas_oracle_workflows'] == 704
assert len(modular['cohort_reports']) == 18
assert queue['remaining'] == 58 and queue['required'] == 37 and queue['conditional'] == 21
assert len(queue['owners']) == 14 and queue['completed_substeps'] == []
assert index['broader_owners_closed'] == []
expected_development_statuses = {
    'evidence/subquery-first-tests-738.json': 'passed',
    'evidence/subquery-focused-740.json': 'passed',
    'evidence/subquery-direct-binding-preflight-741.json': 'failed',
    'evidence/subquery-direct-binding-preflight-fixed-741.json': 'passed',
    'evidence/subquery-public-preflight-fixed-741.json': 'failed',
    'evidence/subquery-public-preflight-deferred-fixed-742.json': 'failed',
    'evidence/subquery-public-preflight-diagnostic-fixed-742.json': 'passed',
    'evidence/subquery-deferred-grant-probe-742.json': 'passed',
    'evidence/subquery-preflight-values-verify-742.json': 'failed',
    'evidence/subquery-preflight-values-verify-fixed-742.json': 'passed',
}
for name, status in expected_development_statuses.items():
    assert records[name]['status'] == status, name
assert set(bridge['only_frozen_source_change']) == {'scripts/check_user_surface_reference.py'}
for name, frozen in source['source_hashes'].items():
    wanted = bridge['only_frozen_source_change'].get(name, {}).get('closeout_sha256', frozen)
    assert digest((ROOT / name).read_bytes()) == wanted
for name, wanted in bridge['documents'].items():
    assert digest((ROOT / name).read_bytes()) == wanted
report = ROOT / 'docs/benchmarks' / (NAME + '.md')
for target in re.findall(r'\]\(([^)]+)\)', report.read_text()):
    if '://' not in target and not target.startswith('#'):
        assert (report.parent / target.split('#', 1)[0]).resolve().is_file(), target
result = {
    'schema_version': 'shardloom.native_subquery_membership_packet_inspection.v1',
    'status': 'passed', 'source_commit': source['source_commit'],
    'index': {'file': index_path.name, 'bytes': index_path.stat().st_size, 'sha256': digest(index_path.read_bytes())},
    'archive_parts': len(index['archives']), 'members_independently_reopened': len(seen),
    'source_and_document_identities_verified': True, 'failure_history_preserved': True,
    'public_cases': 5930, 'public_families': 39,
    'subquery_complete_rows_reopened': 1701,
    'engine_execution_seconds': full43['engine_execution_seconds'],
    'remaining_owners': 14, 'remaining_substeps': 58, 'broader_owners_closed': [],
    'claim_gate_status': 'not_claim_grade', 'publication_attempted': False,
}
with (DEST / (NAME + '.inspection.json')).open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result))
