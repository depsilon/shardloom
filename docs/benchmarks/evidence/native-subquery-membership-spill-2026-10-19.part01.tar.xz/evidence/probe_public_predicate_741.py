"""Capture actual public lowering counters before correcting coverage expectations."""
import json
from pathlib import Path
import shardloom as sl
from native_streaming_subquery_membership_cases import KINDS, POLICY, SCHEMA, wide_rows, wide_query, wide_expected
from native_streaming_unary_cases import frame

OUT = Path(__file__).resolve().parent
root = OUT / 'lowering-probe'
root.mkdir()
workspace = root / 'spill'
workspace.mkdir()
client = sl.ShardLoomClient(binary=OUT / 'preflight-artifacts/shardloom', timeout=600)

class Sources:
    context = sl.ShardLoomContext(client)

records = []
try:
    for kind in KINDS:
        for surface in ('dataframe', 'sql'):
            left_rows, right_rows = wide_rows(kind)
            left, a = frame(Sources, left_rows, SCHEMA, width=2)
            right, b = frame(Sources, right_rows, SCHEMA, width=31)
            query = wide_query(left, right, kind, surface=surface)
            result = query.collect(check=True, **POLICY, spill=dict(
                workspace=str(workspace), quota_bytes=128 << 20, buffer_bytes=1 << 20))
            assert list(result.result_rows) == wide_expected(kind, left_rows, right_rows)
            assert not list(workspace.iterdir())
            selected = {entry.key: entry.value for entry in result.envelope.fields
                        if 'subquery' in entry.key or 'replay' in entry.key or 'spill' in entry.key}
            records.append(dict(kind=kind, surface=surface, fields=selected, traces=[a, b]))
finally:
    client.close()
    with (OUT / 'lowering-probe-741.json').open('x') as stream:
        json.dump(records, stream, indent=2)
for record in records:
    print(json.dumps(dict(kind=record['kind'], surface=record['surface'], fields={
        key: value for key, value in record['fields'].items() if key in (
            'native_input_replay_sources', 'native_input_replay_spilled_sources',
            'relational_spillable_subquery_stages', 'relational_spillable_subquery_input_rows',
            'relational_spillable_subquery_indexed_rows', 'relational_spillable_subquery_probe_rows',
            'relational_spillable_subquery_lookup_blocks', 'relational_spill_runs_written')})))
