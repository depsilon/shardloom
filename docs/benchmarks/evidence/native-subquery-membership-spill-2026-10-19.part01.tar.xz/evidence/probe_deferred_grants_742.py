"""Compare the established deferred-pivot grant with the new predicate fixture."""
import json
from pathlib import Path
from types import SimpleNamespace

import shardloom as sl
from shardloom.errors import ShardLoomCommandError
from native_streaming_dynamic_subquery_cases import declaration

OUT = Path(__file__).resolve().parent
directory = OUT / 'deferred-grant-probe-742'
directory.mkdir(exist_ok=False)
records = []
for label, binary in (
    ('sampling-baseline', OUT.parent / 'native-sampling-population-20261019/artifacts/shardloom'),
    ('predicate-current', OUT / 'preflight-artifacts-fixed/shardloom'),
):
    for grant in (8 << 20, 32 << 20):
        workspace = directory / f'{label}-{grant}'
        workspace.mkdir()
        harness = SimpleNamespace(context=sl.ShardLoomContext(sl.ShardLoomClient(binary=binary, timeout=600)))
        query, expected, traces, _ = declaration(harness, 'in', 'mixed')
        record = dict(label=label, grant=grant, expected=expected)
        try:
            result = query.collect(check=True, memory_bytes=grant, max_parallelism=1,
                spill=dict(workspace=str(workspace), quota_bytes=128 << 20, buffer_bytes=1 << 20))
            assert list(result.result_rows) == expected
            record.update(status='passed', envelope=result.envelope.raw)
        except ShardLoomCommandError as error:
            record.update(status='denied', envelope=error.envelope.raw)
            assert 'memory reservation denied' in json.dumps(error.envelope.raw)
        assert not list(workspace.iterdir())
        assert record['status'] == ('denied' if grant == 8 << 20 else 'passed'), record
        records.append(record)
        print(json.dumps({key: record[key] for key in ('label', 'grant', 'status')}), flush=True)
with (directory / 'results.json').open('x') as stream:
    json.dump(records, stream, indent=2)
