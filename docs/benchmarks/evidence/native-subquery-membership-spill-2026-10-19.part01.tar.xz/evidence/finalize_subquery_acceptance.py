"""Record finite predicate-state acceptance only after every frozen gate passes."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent


def read(path):
    return json.loads(Path(path).read_text())


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}


def check(ref):
    assert identity(ref['path']) == ref, ref['path']


acceptance = read(OUT / 'acceptance-final-verified.json')
assert acceptance['status'] == 'passed' and acceptance['finite_family_acceptance_complete']
assert not acceptance['broader_membership_population_owner_complete']
assert not acceptance['broader_recovery_owner_complete'] and not acceptance['performance_claim']
source = read(OUT / 'acceptance-source.json')
assert acceptance['source_commit'] == acceptance['compiled_source_commit'] == source['source_commit']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == source['source_commit']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True) == ''
for name, digest in source['source_hashes'].items():
    assert identity(ROOT / name)['sha256'] == digest, name
for group in ('gates', 'development_evidence'):
    for record in acceptance[group].values():
        check(record['receipt'])
        check(record['log'])
for ref in acceptance['phase_reports'].values():
    check(ref)

native_log = (OUT / 'subquery-native-vortex-tests-742.log').read_text()
required = []
for path in sorted((ROOT / 'shardloom-vortex/src').rglob('*.rs')):
    for name in re.findall(r'^fn ((?:subquery_membership|streaming_subquery_membership|streaming_subqueries_membership|streaming_dynamic_subqueries_membership)\w+)\(', path.read_text(), re.MULTILINE):
        assert len(re.findall(r'^test .*::' + re.escape(name) + r' \.\.\. ok$', native_log, re.MULTILINE)) == 1, name
        required.append(name)
assert len(required) == len(set(required)) == 14, required
all_subquery = re.findall(r'^test (\S*subquer\S*) \.\.\. ok$', native_log, re.MULTILINE)
assert len(all_subquery) == len(set(all_subquery)) == 60
for selector in (
    'streaming_subqueries_predicates_preserve_nulls_negation_correlations_and_batch_ownership',
    'streaming_dynamic_subqueries_preserve_predicates_parameter_schemas_replay_and_owner_release',
    'streaming_subqueries_shared_replay_supports_nested_resident_and_spilled_readers',
):
    assert len(re.findall(r'^test .*::' + selector + r' \.\.\. ok$', native_log, re.MULTILINE)) == 1
binding_selector = 'test_spilled_predicates_rows_arrow_collect_batches_and_publication'
binding_log = (OUT / 'subquery-direct-binding-tests-742.log').read_text()
assert re.search(r'^' + binding_selector + r' .* \.\.\. ok$', binding_log, re.MULTILINE)
public = read(OUT / 'acceptance-public-verified.json')
assert public['subquery_membership_public_cases'] == 438 and public['subquery_original_pressure_cases'] == 2
assert len(public['subquery_complete_value_archives']) == 483
assert len(public['subquery_publication_failure_cases']) == 24
assert public['subquery_existing_destination_denials'] == 6
assert public['subquery_incomplete_execution_failures'] == 18
assert public['sampling_population_public_cases'] == 358 and public['sampling_pressure_cases'] == 12
assert public['unary_membership_public_cases'] == 210 and public['unary_pressure_public_cases'] == 59

record = {
    'schema_version': 'shardloom.native_subquery_membership_acceptance.v1',
    'status': 'accepted_finite_local_scope',
    'source_commit': source['source_commit'], 'base_commit': source['base_commit'],
    'compiled_source_commit': acceptance['compiled_source_commit'],
    'scope': source['scope'],
    'sources': ['native_files', 'resident_native_memory', 'finite_streaming_batches'],
    'source_manifest': identity(OUT / 'acceptance-source.json'),
    'build': identity(OUT / 'acceptance-build.json'), 'plan': identity(OUT / 'acceptance-plan.json'),
    'runtime_acceptance': identity(OUT / 'acceptance-final-verified.json'),
    'test_counts': acceptance['test_counts'], 'required_native_selectors': required,
    'all_subquery_regression_selectors': all_subquery,
    'direct_binding_selector': binding_selector, 'direct_binding_subcases': 48,
    'public_families': 39, 'public_cases': 5930,
    'subquery_membership_public_cases': 438, 'subquery_original_pressure_cases': 2,
    'net_new_public_cases': 438, 'subquery_complete_value_archives': 483,
    'subquery_publication_failure_cases': 24,
    'subquery_existing_destination_denials': 6,
    'subquery_incomplete_execution_failures': 18,
    'subquery_complete_rows_reopened': public['subquery_rows_independently_reopened'],
    'full43': {'queries': 43, 'executions_per_query': 1, 'complete_result_rows': 381,
               'engine_execution_seconds': acceptance['engine_execution_seconds'],
               'reference_kind': 'retained_native_regression', 'performance_claim': False},
    'modular_cohorts': 18, 'native_workflows': 704, 'fresh_independent_pandas_oracle_workflows': 704,
    'completed_substeps': [],
    'accepted_finite_scope_within': ['PERF-06.membership', 'PERF-06.recovery', 'PERF-06.strategy'],
    'broader_owners_closed': [],
    'cross_cutting_owners': ['PERF-01', 'PERF-03', 'PERF-07', 'PERF-11', 'PERF-12'],
    'all_cg_1_through_cg_23_requirements_preserved': True,
    'predicate_kinds': ['in', 'exists', 'quantified-any', 'quantified-all'],
    'negation_and_three_valued_row_comparison': True,
    'inner_scope': ['ordinary', 'native_indexed_correlation', 'parameterized', 'declared_parameter_schema'],
    'public_outer_reference_strategy': 'parameterized_inner_with_separate_source_replay',
    'native_indexed_correlation_strategy': 'one_complete_projected_key_population',
    'public_actual_predicate_spill_counter': 'relational_spilled_subquery_stages',
    'public_cardinality_only_exists_fixture': 'resident_predicate_state_with_spilled_source_replay',
    'crash_recovery': 'exact_owned_cleanup_followed_by_fresh_execution',
    'interrupted_execution_resume': False,
    'strategy': 'native_ordered_projected_keys_with_exact_collision_safe_lookup',
    'source_replay_is_separate_from_predicate_population': True,
    'generation_checked_on_cache_hits': True,
    'internal_predicate_block_maximum_rows': 64,
    'source_replay_spill_copy_rows': 64,
    'retained_threshold': 'min(authorized_spill_buffer,shared_memory_grant/8)',
    'original_native_pressure_grant_bytes': 4 << 20,
    'original_public_pressure_grant_bytes': 8 << 20,
    'direct_binding_and_publication_grant_bytes': 8 << 20,
    'deferred_pivot_public_grant_bytes': 32 << 20,
    'direct_binding_readback_grant_bytes': 128 << 20,
    'whole_process_memory_ceiling': False, 'fallback_attempted': False,
    'external_engine_invoked_as_runtime': False, 'release_version_changed': False,
    'publication_attempted': False,
    'platform_scope': 'local macOS Unix; release-user-surfaces feature build',
    'claim_gate_status': 'not_claim_grade',
    'unresolved': [
        'Scalar subqueries retain their zero/one-row resident contract and cardinality error.',
        'Opaque undeclared inner sources and dynamic scalar schema inference remain unsupported.',
        'Other sampling strategies and legacy standalone unary state retain their existing pressure boundaries.',
        'This family restarts after owned cleanup; general interrupted-execution resume is not established.',
        'Existing targets remain rejected before demand; generation-conditional replacement remains PERF-07 work.',
        'Hosted installed-wheel, other-platform, release and competitive claims retain independent gates.',
        'Managed reservations do not impose a whole-process RSS ceiling or guarantee arbitrary row widths fit.',
    ],
    'generator': identity(__file__),
}
with (OUT / 'perf-06-acceptance.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps({'status': record['status'], 'public_cases': record['public_cases'],
                  'engine_execution_seconds': record['full43']['engine_execution_seconds']}))
