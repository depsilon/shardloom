"""Run named native predicates and reject empty test selections."""
import json
import re
import subprocess
from pathlib import Path

selectors = [
    'native_relational_subquery_in_not_in_any_all_and_exists_preserve_null_and_empty_set_rules',
    'native_relational_row_subquery_distinguishes_unknown_from_a_definite_mismatching_tuple',
    'native_relational_correlated_membership_and_exists_treat_null_correlation_as_empty',
    'streaming_subqueries_membership_original_pressure_completes_only_with_native_strategy',
    'streaming_subquery_membership_wide_keys_spill_at_original_grant_with_complete_predicates',
    'streaming_subquery_membership_cache_hit_revalidates_generation_then_fresh_run_completes',
]
results = []
for selector in selectors:
    command = ['cargo', 'test', '-p', 'shardloom-vortex', '--lib', '--features',
               'release-user-surfaces', selector, '--', '--test-threads=1']
    run = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    print(run.stdout, flush=True)
    summaries = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', run.stdout)
    result = {'selector': selector, 'returncode': run.returncode, 'summaries': summaries}
    results.append(result)
    Path(__file__).with_suffix('.json').write_text(json.dumps(results, indent=2) + '\n')
    assert run.returncode == 0 and summaries == [('ok', '1', '0', '0')], result
