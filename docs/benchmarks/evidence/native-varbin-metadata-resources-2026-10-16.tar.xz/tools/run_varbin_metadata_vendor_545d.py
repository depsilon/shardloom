"""Run complete standalone provider tests and library lints under the outer guard."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent / 'varbin-metadata-vendor-545d'
PROVIDERS = ('vortex-array', 'vortex-fsst', 'vortex-runend', 'vortex-zstd')


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


assert not OUT.exists()
source_files = {}
for provider in PROVIDERS:
    source = ROOT / 'vendor' / provider
    entries = sorted(source.rglob('*'))
    assert all(not path.is_symlink() and (path.is_file() or path.is_dir()) for path in entries)
    paths = [path for path in entries if path.is_file() and path.name != 'Cargo.lock']
    assert sum(path.stat().st_size for path in paths) < 32 << 20
    source_files[provider] = {path.relative_to(source).as_posix(): sha(path) for path in paths}
    for path in paths:
        destination = OUT / provider / path.relative_to(source)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, destination)
    shutil.copy2(ROOT / 'Cargo.lock', OUT / provider / 'Cargo.lock')
lock_sha256 = sha(ROOT / 'Cargo.lock')
shutil.copy2(ROOT / 'vendor/vortex-array/clippy.toml', OUT / 'clippy.toml')
clippy_sha256 = sha(OUT / 'clippy.toml')


def unchanged():
    return sha(OUT / 'clippy.toml') == clippy_sha256 and sha(ROOT / 'Cargo.lock') == lock_sha256 and all(
        sha(ROOT / 'vendor' / provider / name) == digest
        and sha(OUT / provider / name) == digest
        for provider, files in source_files.items() for name, digest in files.items()
    )


commands = []
for provider in PROVIDERS:
    if provider != 'vortex-zstd':
        continue
    args = ['--offline', '--manifest-path', str(OUT / provider / 'Cargo.toml')]
    if provider == 'vortex-array':
        args += ['--features', '_test-harness,table-display']
    else:
        args += ['--config', 'patch.crates-io.vortex-array.path=' + json.dumps(str(OUT / 'vortex-array')),
                 '--features', 'vortex-array/table-display']
    commands += [
        ['cargo', 'test', *args, '--lib', '--', '--test-threads=2'],
        ['cargo', 'clippy', *args, '--lib', '--', '-D', 'warnings'],
    ]
previous = OUT.parent / 'varbin-metadata-vendor-545c'
prior = json.loads((previous / 'protocol.json').read_text())
summary = json.loads((previous / 'summary.json').read_text())
assert summary['sources_unchanged'] and summary['completed'] == prior['commands'][:6]
assert summary['protocol_sha256'] == sha(previous / 'protocol.json')
for provider in PROVIDERS[:3]:
    assert prior['source_files'][provider] == source_files[provider]
assert prior['root_lock_sha256'] == lock_sha256
assert prior['clippy_config_sha256'] == clippy_sha256
save(OUT / 'protocol.json', dict(root=str(ROOT), source_files=source_files,
    root_lock_sha256=lock_sha256, commands=commands, helper_sha256=sha(__file__),
    clippy_config_sha256=clippy_sha256, environment={'CLIPPY_CONF_DIR': str(OUT)},
    prior_verified_providers=list(PROVIDERS[:3]),
    prior_protocol={'path': str(previous / 'protocol.json'), 'sha256': sha(previous / 'protocol.json')},
    prior_summary={'path': str(previous / 'summary.json'), 'sha256': sha(previous / 'summary.json')}))
completed, failure = [], None
try:
    for command in commands:
        assert unchanged()
        print(json.dumps({'command': command}), flush=True)
        subprocess.run(command, cwd=ROOT, check=True, env=dict(os.environ, CLIPPY_CONF_DIR=str(OUT)))
        completed.append(command)
    assert unchanged()
except BaseException as error:
    failure = type(error).__name__ + ': ' + str(error)
    raise
finally:
    same = unchanged()
    save(OUT / 'summary.json', dict(status='passed' if failure is None and same else 'failed',
        completed=completed, failure=failure, sources_unchanged=same,
        protocol_sha256=sha(OUT / 'protocol.json'),
        standalone_lock_sha256={provider: sha(OUT / provider / 'Cargo.lock') for provider in PROVIDERS}))
    assert same
