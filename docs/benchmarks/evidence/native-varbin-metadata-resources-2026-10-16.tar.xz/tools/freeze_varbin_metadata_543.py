"""Freeze the unchanged-production VarBinView lifecycle baseline and its build."""
import hashlib
import itertools
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
DEST = OUT / 'varbin-metadata-cost-543'
TEST = 'resident_memory_source::encoded_transfer::tests::varbin_metadata_cost_tests::native_varbin_metadata_complete_lifecycle_cost_screen'
CONTRACT = 'docs/architecture/native-varbin-metadata-resources-2026-10-16.md'
HARNESS = 'shardloom-vortex/src/resident_memory_varbin_metadata_cost_tests.rs'
BASE = 'c00269355fc645596095a1719820832da58e3f8b'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def sources():
    names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
    return {name: sha(ROOT / name) for name in sorted(set(names))
            if name and (name.endswith(('.rs', '.py', 'Cargo.toml'))
                         or name == 'Cargo.lock' or name.startswith('.cargo/'))
            and (ROOT / name).is_file()}


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def save(name, value):
    with (DEST / name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def passed(name):
    path = OUT / (name + '.json')
    record = json.loads(path.read_text())
    assert record['status'] == 'passed' and record['returncode'] == 0
    assert record['process_group_drained'] and record['direct_child_reaped']
    assert not record['timed_out'] and record['interrupted_signal'] is None
    assert sha(path.with_suffix('.log')) == record['log_sha256']
    return record


def check_harness():
    name = 'varbin-metadata-baseline-harness-check-543'
    record = passed(name)
    assert TEST in record['command']
    log = (OUT / (name + '.log')).read_text()
    rows = [json.loads(line.split('VARBIN_METADATA_COST ', 1)[1])
            for line in log.splitlines() if 'VARBIN_METADATA_COST ' in line]
    keys = list(itertools.product(['utf8', 'binary'], [32, 65536],
                                 ['canonical', 'fsst', 'zstd', 'runend'], [2, 16]))
    assert len(rows) == 128
    assert {(r['kind'], r['rows'], r['encoding'], r['chunks']) for r in rows} == set(keys)
    for key in keys:
        cells = [r for r in rows if (r['kind'], r['rows'], r['encoding'], r['chunks']) == key]
        assert [r['phase'] for r in cells] == ['warmup', 'measured', 'measured', 'measured']
        assert [r['sample'] for r in cells[1:]] == [0, 1, 2]
        assert [len(r['nanoseconds']) for r in cells] == [1, 25, 25, 25]
        assert all(r['observation'] == cells[0]['observation'] for r in cells)
        assert all(r['input_sha256'] == cells[0]['input_sha256'] for r in cells)
        assert all(n > 0 for r in cells for n in r['nanoseconds'])
    complete, = [json.loads(line.split('VARBIN_METADATA_COST_COMPLETE ', 1)[1])
                 for line in log.splitlines() if 'VARBIN_METADATA_COST_COMPLETE ' in line]
    assert complete == dict(cells=32, samples_per_cell=3, operations_per_sample=25,
                           recorded_warmups_per_cell=1, all_complete_values_equal=True,
                           all_source_and_receiving_credits_released=True)
    assert 'test result: ok. 1 passed; 0 failed;' in log
    return dict(receipt=identity(OUT / (name + '.json')),
                log=identity(OUT / (name + '.log')), cells=32, operations=2432,
                acceptance='harness validation only; paired overhead screen remains pending')


def freeze_source():
    assert not git('status', '--porcelain')
    expected = {CONTRACT, HARNESS, 'docs/architecture/phased-execution-plan.md',
                'docs/rfcs/0044-resident-runtime-resource-ownership.md',
                'shardloom-vortex/src/resident_memory_encoded_transfer_tests.rs'}
    assert set(git('diff', '--name-only', BASE, 'HEAD').splitlines()) == expected
    assert git('diff', BASE, 'HEAD', '--', 'shardloom-vortex/src/resident_memory_encoded_transfer_tests.rs').count('+#[path') == 1
    check = check_harness()
    DEST.mkdir(exist_ok=False)
    record = dict(root=str(ROOT), head=git('rev-parse', 'HEAD'), status='',
                  production_baseline=BASE, source_sha256=sources(),
                  contract_sha256=sha(ROOT / CONTRACT), harness_sha256=sha(ROOT / HARNESS),
                  compiler=subprocess.check_output(['/Users/dylan/.cargo/bin/rustup', 'run',
                    '1.99.0', 'rustc', '-Vv'], text=True), harness_validation=check)
    save('baseline-source.json', record)
    print(json.dumps(dict(status='source_frozen', head=record['head'],
                         files=len(record['source_sha256']), cells=check['cells'])))


def freeze_build():
    source = json.loads((DEST / 'baseline-source.json').read_text())
    assert not git('status', '--porcelain') and git('rev-parse', 'HEAD') == source['head']
    assert sources() == source['source_sha256']
    assert sha(ROOT / CONTRACT) == source['contract_sha256']
    name = 'varbin-metadata-baseline-bound-build-543'
    record = passed(name)
    assert record['head'] == source['head'] and not record['working_tree']
    assert all(flag in record['command'] for flag in ('--release', '--no-run', 'release-user-surfaces'))
    original, = re.findall(r'Executable unittests src/lib.rs \(([^)]+)\)', (OUT / (name + '.log')).read_text())
    target = DEST / 'shardloom-varbin-metadata-baseline'
    assert not target.exists()
    before = sha(original)
    shutil.copy2(original, target)
    assert sha(original) == sha(target) == before
    listing = subprocess.check_output([str(target), '--list'], text=True)
    assert TEST + ': test' in listing
    inventory = DEST / 'baseline-test-list.txt'
    with inventory.open('x') as stream:
        stream.write(listing)
    save('baseline-build.json', dict(status='passed', role='baseline', root=str(ROOT),
         source=identity(DEST / 'baseline-source.json'), binary=identity(target),
         build_receipt=identity(OUT / (name + '.json')), build_log=identity(OUT / (name + '.log')),
         test_inventory=identity(inventory), test_name=TEST, command=record['command'],
         environment=record['environment'], freezer=identity(__file__)))
    print(json.dumps(dict(status='binary_frozen', binary_sha256=before,
                         files=len(source['source_sha256']))))


if __name__ == '__main__':
    {'source': freeze_source, 'build': freeze_build}[sys.argv[1]]()
