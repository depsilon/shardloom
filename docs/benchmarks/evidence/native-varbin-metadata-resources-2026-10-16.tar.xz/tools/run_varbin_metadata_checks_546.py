"""Serial source-bound workspace and native gates for variable-binary ownership."""
import json
from pathlib import Path
import re
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, save, sha, sources
from run_stream_destination_review_checks_479 import CHECKS

SOURCE = OUT / 'native-release-source-varbinmetadata546.json'


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def main():
    frozen = json.loads(SOURCE.read_text())
    assert sources() == frozen['source_sha256']
    prior_path = OUT / 'zstd-metadata-checks-532.json'
    prior = json.loads(prior_path.read_text())
    assert prior['status'] == 'passed'
    ignored = sorted(tuple(row) for row in next(
        row for row in prior['completed'] if row['stage'] == 'native-tests')['tests']['ignored_declarations'])
    assert len(ignored) == 29
    ignored.append((
        'resident_memory_source::encoded_transfer::tests::varbin_metadata_cost_tests::native_varbin_metadata_complete_lifecycle_cost_screen',
        'frozen complete buffer-table lifecycle screen; guarded serial release execution only'))
    ignored.sort()
    required = set()
    for name in ('native_provider_varbin_metadata_tests.rs',
                 'native_provider_varbin_construction_tests.rs',
                 'native_provider_varbin_deserialize_tests.rs',
                 'resident_memory_varbin_transfer_tests.rs'):
        required.update(re.findall(r'^fn ((?:native_varbin_|encoded_transfer_varbin_)\w+)\(',
            (ROOT / 'shardloom-vortex/src' / name).read_text(), re.M))
    assert len(required) == 21, sorted(required)
    protocol = dict(source=identity(SOURCE), helper=identity(__file__), checks=CHECKS,
        guard=identity(OUT / 'run_guarded.py'),
        previous_ignored_inventory=identity(prior_path), expected_ignored=ignored,
        required_tests=sorted(required),
        vendor_prior_summary=identity(OUT / 'varbin-metadata-vendor-545c/summary.json'),
        vendor_continuation_summary=identity(OUT / 'varbin-metadata-vendor-545e/summary.json'))
    protocol_path = OUT / 'varbin-metadata-check-protocol-546.json'
    save(protocol_path, protocol)
    completed, failure = [], None
    try:
        for label, timeout, command in CHECKS:
            assert sources() == frozen['source_sha256']
            name = 'varbin-metadata-' + label + '-546'
            print(json.dumps(dict(stage=label, status='starting')), flush=True)
            subprocess.run([sys.executable, '-B', str(OUT / 'run_guarded.py'),
                '--name', name, '--timeout', str(timeout), '--', *command], cwd=ROOT, check=True)
            path = OUT / (name + '.json')
            value, log = json.loads(path.read_text()), path.with_suffix('.log')
            assert value['status'] == 'passed' and value['returncode'] == 0
            assert value['process_group_drained'] and value['direct_child_reaped']
            assert not value['timed_out'] and not value['group_absence_unproved_at_cleanup']
            assert value['head'] == frozen['head'] and sha(log) == value['log_sha256']
            row = dict(stage=label, receipt=identity(path), log=identity(log))
            if label.endswith('tests'):
                raw = log.read_text()
                groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', raw)
                assert groups and all(int(g[1]) == int(g[3]) == int(g[4]) == 0 for g in groups)
                observed = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', raw, re.M)
                assert sum(int(g[2]) for g in groups) == len(observed)
                if label == 'native-tests':
                    assert sorted(observed) == ignored
                    for test in required:
                        assert re.search(r'^test .*::' + re.escape(test) + r' \.\.\. ok$', raw, re.M), test
                else:
                    assert not observed
                row['tests'] = dict(passed=sum(int(g[0]) for g in groups), failed=0,
                    ignored=len(observed), groups=len(groups), ignored_declarations=observed)
            completed.append(row)
            print(json.dumps(dict(stage=label, status='passed', passed=row.get('tests', {}).get('passed'))), flush=True)
        assert sources() == frozen['source_sha256']
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        save(OUT / 'varbin-metadata-checks-546.json', dict(status='passed' if failure is None else 'failed',
            failure=failure, source=identity(SOURCE), protocol=identity(protocol_path),
            completed=completed, source_identity_preserved=sources() == frozen['source_sha256']))


if __name__ == '__main__':
    main()
