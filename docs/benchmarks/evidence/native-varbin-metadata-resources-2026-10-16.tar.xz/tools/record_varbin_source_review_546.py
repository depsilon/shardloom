"""Record the primary's bounded ownership review against exact source identities."""
import json
from pathlib import Path

from freeze_native_release_298 import ROOT, OUT, sources, save
from run_varbin_metadata_checks_546 import identity

source = OUT/'native-release-source-varbinmetadata546c.json'
assert sources() == json.loads(source.read_text())['source_sha256']
anchors = {
    'vendor/vortex-array/src/arrays/varbinview/metadata.rs': ['pub(crate) struct MetadataReservation', 'pub(crate) fn grow_vec', 'pub(crate) fn into_arc'],
    'vendor/vortex-array/src/arrays/varbinview/array.rs': ['pub struct VarBinViewData', 'fn with_views_and_validity', 'pub fn into_data_parts'],
    'vendor/vortex-array/src/builders/varbinview.rs': ['pub struct AdmittedVarBinViewBuilder', 'pub fn append_array', 'pub fn finish(mut self)'],
    'vendor/vortex-array/src/arrays/varbinview/vtable/mod.rs': ['let allocator = session.allocator();'],
    'shardloom-vortex/src/resident_memory_encoded_transfer.rs': ['self.provider_metadata_bytes = add(self.provider_metadata_bytes, provider_bytes)?;'],
    'shardloom-vortex/src/native_provider_chunked.rs': ['VarBinViewBuilder::with_admitted_buffers(', 'output.with_views_and_validity('],
    'shardloom-vortex/src/native_provider_memory.rs': ['VarBinViewArray::try_new_handle_in('],
}
bound = []
for name, markers in anchors.items():
    lines = (ROOT/name).read_text().splitlines()
    found = {marker: [i+1 for i, line in enumerate(lines) if marker in line] for marker in markers}
    assert all(found.values()), name
    bound.append(dict(source=identity(ROOT/name), anchors=found))
review = dict(status='passed', scope='Primary static expert review of the named variable-binary ownership contract; local/hosted acceptance is recorded separately.',
    source_snapshot=identity(source), helper=identity(__file__), sources=bound,
    objections=[
        dict(question='Can shared table storage outlive its credit, or can an individual payload pin unrelated table credit?',
             disposition='Managed array data retains the table before its shared reservation field; scoped view transformations share both. Raw Arc export remains an explicit caller boundary. Payload owners remain independent. Exact-grant, clone/selection, raw-payload and raw-parts tests cover the distinction.'),
        dict(question='Can table growth or finalization allocate before admission or publish partially appended output after denial?',
             disposition='The restricted builder admits exact requested capacity and old/new overlap before growth; row/type/host/index limits precede append. Final table conversion retains vector and slice charges concurrently. Finalization consumes the builder and refunds on error. Tests cover reusable growth denial and terminal finalization denial.'),
        dict(question='Can cross-session transfer retain source credit or double-charge replaced outer table accounting?',
             disposition='Receiving deserialization selects its own session allocator. Transfer reports provider-owned VarBinView table bytes while removing only superseded generic table charges. Existing schema/slot/scratch and payload ownership remain separate. Source closure and receiver-denial tests check cleanup and exact accounting.'),
    ],
    preserved_boundaries=['Vortex-native providers and serialization; no external-engine route or query integration added.',
        'Requested element capacity only: fixed headers, allocator slack and whole-process RSS are excluded.',
        'Legacy raw builders, deduplication, selective compaction and zip scratch remain outside this finite ownership claim.',
        'Device handles retain layout-only construction behavior; no device execution claim.',
        'The frozen lifecycle harness is byte-identical to the baseline; its consuming verifier is documented by a parent-module lint expectation.'],
    unresolved_in_scope_findings=[], full_acceptance_pending=True)
save(OUT/'varbin-metadata-source-review-546.json', review)
print(json.dumps(dict(status='passed', reviewed_source_files=len(bound), full_acceptance_pending=True)))
