"""Independently check the final metadata helper inventory without executing its helpers."""
import ast
import hashlib
import json
from pathlib import Path

O = Path(__file__).resolve().parent
R = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
E = Path('/Users/dylan/LocalData/shardloom')
OUTPUT = O / 'varbin-metadata-helper-primary-check-548.json'


def path(key):
    if key.startswith('local/'):
        return O / key.removeprefix('local/')
    if key.startswith('repository/'):
        return R / key.removeprefix('repository/')
    assert key.startswith('external/')
    return E / key.removeprefix('external/')


def key(value):
    if value.is_relative_to(O):
        return 'local/' + value.relative_to(O).as_posix()
    if value.is_relative_to(R):
        return 'repository/' + value.relative_to(R).as_posix()
    return 'external/' + value.relative_to(E).as_posix()


def identity(value):
    raw = value.read_bytes()
    return dict(path=key(value), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    assert not OUTPUT.exists()
    inventory_path = O / 'varbin-metadata-helper-inventory-548.json'
    inventory = json.loads(inventory_path.read_text())
    original = {row['path']: row for row in inventory['closure']}
    assert len(original) == 99
    assert all(identity(path(name)) == item for name, item in original.items())
    selected = {key(p) for p in O.iterdir() if p.is_file() and p.suffix == '.py' and 'varbin' in p.name}
    assert selected == set(inventory['scope']['selected_python_seeds']) | {key(Path(__file__))}
    roots = [Path(value) for value in inventory['roots']]
    assert roots == [O, R / 'scripts', R / 'python/src', E / 'release-0.3.3-20260930']
    pending = [path(name) for name in selected | set(inventory['explicit_packager_seeds'])]
    closure, edges, trees = {}, [], {}
    while pending:
        source = pending.pop().resolve()
        source_key = key(source)
        if source_key in closure:
            continue
        assert source.is_file() and not source.is_symlink()
        closure[source_key] = identity(source)
        tree = ast.parse(source.read_text())
        trees[source_key] = tree
        for node in ast.walk(tree):
            modules = ([item.name for item in node.names] if isinstance(node, ast.Import) else
                       [node.module] if isinstance(node, ast.ImportFrom) and node.module and node.level == 0 else [])
            for module in modules:
                for root in roots:
                    candidate = root.joinpath(*module.split('.')).with_suffix('.py')
                    if not candidate.is_file():
                        candidate = root.joinpath(*module.split('.')) / '__init__.py'
                    if candidate.is_file():
                        edges.append(dict(source=source_key, line=node.lineno, module=module, target=key(candidate)))
                        pending.append(candidate)
                        break
    assert set(closure) == set(original) | {key(Path(__file__))}
    order = lambda row: (row['source'], row['line'], row['module'], row['target'])
    assert sorted(edges, key=order) == sorted(inventory['local_import_edges'], key=order)
    assert len(edges) == 298 and len(inventory['launcher_sites']) == 76
    for row in inventory['launcher_sites']:
        matches = [node for node in ast.walk(trees[row['source']]) if isinstance(node, ast.Call)
                   and node.lineno == row['line'] and
                   (node.func.attr if isinstance(node.func, ast.Attribute) else
                    node.func.id if isinstance(node.func, ast.Name) else None) == row['call']]
        assert any((ast.unparse(node.args[0]) if node.args else '<no positional command>') ==
                   row['expression'] for node in matches), row
        assert all(target in closure for target in row['local_py_targets'])
    dynamic = inventory['unresolved_dynamic_launches']
    assert len(dynamic) == 19
    classifications = {}
    for row in dynamic:
        source = row['source']
        text = path(source).read_text()
        if row['expression'] == 'suite':
            assert 'unittest.TextTestRunner' in text
            category = 'in-process unittest execution, not a subprocess or missing helper'
        elif source.startswith('local/run_varbin_metadata_vendor_'):
            assert "['cargo', 'test'" in text and "['cargo', 'clippy'" in text
            category = 'Cargo command vectors bound by the archived vendor protocols and raw guard logs'
        elif source == 'repository/scripts/build_native_python.py':
            assert row['expression'] in ('command', 'metadata_command')
            assert '[cargo, "metadata"' in text and '[cargo, "build"' in text
            category = 'Cargo metadata/build vectors bound by the archived native build recipe'
        elif source in ('local/run_varbin_metadata_full43_546.py', 'local/run_compression_full43_457.py'):
            assert 'run_guarded.py' in text and 'run_clickbench_query_uat.py' in text
            assert 'local/run_guarded.py' in closure and 'repository/scripts/run_clickbench_query_uat.py' in closure
            category = 'guarded Full43 command with both local Python targets in the archive closure'
        elif source in ('local/compression_cost_456c.py', 'local/varbin_metadata_cost_546.py'):
            assert 'timed_native_command.py' in text
            assert 'repository/scripts/timed_native_command.py' in closure
            category = 'timed native executable command bound by the archived lifecycle raw command records'
        else:
            assert source in {
                'external/perf-all-20260906/bounded_build_process_resume_20260912.py',
                'local/run_guarded.py', 'repository/scripts/run_clickbench_query_uat.py',
                'repository/scripts/timed_native_command.py'}
            assert row['expression'] == 'command'
            category = 'generic supervisor command argument; concrete current commands are retained in raw receipts'
        classifications[f"{source}:{row['line']}"] = category
    assert len(classifications) == 19
    result = dict(status='passed', inventory=identity(inventory_path), helper=identity(Path(__file__)),
        original_sources_verified=len(original), final_sources_verified=len(closure),
        local_import_edges_verified=len(edges), launcher_sites_verified=76,
        all_literal_launch_targets_present=True, dynamic_launch_classification=classifications,
        final_import_closure=sorted(closure.values(), key=lambda row: row['path']),
        executed_native_commands=False, imported_reviewed_helpers=False)
    assert all(identity(path(name)) == item for name, item in closure.items())
    with OUTPUT.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(dict(status='passed', sources=len(closure), imports=len(edges), launch_sites=76)))


if __name__ == '__main__':
    main()
