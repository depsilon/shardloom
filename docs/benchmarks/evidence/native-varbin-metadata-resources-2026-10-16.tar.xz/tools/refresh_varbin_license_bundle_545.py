"""Refresh reviewed provider notices, preserving all other locked license data."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tomllib

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
from check_python_license_bundle import BUNDLE, digest, identity, locked_packages, vendored_components, verify

receipt = OUT / 'varbin-metadata-license-refresh-545.json'
assert not receipt.exists()
original_lock = tomllib.loads(subprocess.check_output(['git', 'show', 'HEAD:Cargo.lock'], cwd=ROOT, text=True))
current_lock = tomllib.loads((ROOT / 'Cargo.lock').read_text())
assert len(original_lock['package']) == len(current_lock['package'])
patch_names = {'vortex-fsst', 'vortex-runend'}
for old, new in zip(original_lock['package'], current_lock['package']):
    expected = dict(old)
    if old['name'] in patch_names:
        assert old['version'] == '0.85.0'
        expected.pop('source')
        expected.pop('checksum')
    assert new == expected, old['name']
target = ROOT / BUNDLE / 'manifest.json'
original = target.read_bytes()
manifest = json.loads(original)
expected = locked_packages(ROOT)
previous = {identity(item): item for item in manifest['components']}
removed = set(previous) - set(expected)
assert set(expected) <= set(previous)
assert removed == {(name, '0.85.0', 'registry+https://github.com/rust-lang/crates.io-index') for name in patch_names}
texts_before = {p.name: digest(p.read_bytes()) for p in (ROOT / BUNDLE / 'texts').iterdir()}
for key, checksum in expected.items():
    assert previous[key]['crate_checksum_sha256'] == checksum
    for item in previous[key]['files']:
        data = (ROOT / BUNDLE / item['text']).read_bytes()
        assert len(data) == item['bytes'] and digest(data) == item['sha256']
manifest['components'] = [item for item in manifest['components'] if identity(item) in expected]
manifest['vendored_components'] = vendored_components(ROOT)
assert [item['name'] for item in manifest['vendored_components']] == [
    'arrow-pyarrow', 'vortex-array', 'vortex-datetime-parts', 'vortex-fsst',
    'vortex-layout', 'vortex-runend', 'vortex-zstd']
for component in manifest['vendored_components']:
    for item in component['files']:
        assert (ROOT / BUNDLE / item['text']).read_bytes() == (ROOT / component['path'] / item['crate_path']).read_bytes()
target.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')
result = verify(ROOT)
assert {p.name: digest(p.read_bytes()) for p in (ROOT / BUNDLE / 'texts').iterdir()} == texts_before
result.update(original_manifest_sha256=digest(original),
              refreshed_manifest_sha256=digest(target.read_bytes()),
              helper_sha256=digest(Path(__file__).read_bytes()),
              lockfile_sha256=digest((ROOT / 'Cargo.lock').read_bytes()),
              all_lock_entries_preserved_except_two_local_sources=True,
              all_license_texts_unchanged=True,
              removed_registry_entries=[list(key) for key in sorted(removed)])
with receipt.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result))
