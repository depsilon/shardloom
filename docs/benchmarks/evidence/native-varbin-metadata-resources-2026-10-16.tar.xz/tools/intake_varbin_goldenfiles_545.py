"""Recover exact pinned upstream test fixtures omitted from registry archives."""
import base64
import hashlib
import json
from pathlib import Path
import urllib.request

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent / 'varbin-goldenfile-intake-545'
REVISION = 'afb005379dd9a1b7dc7ae2cb49f4f465d91cc2b3'
SOURCES = [
    ('vortex-array', 'vortex-array', 'goldenfiles/dict.metadata', 'src/arrays/dict/array.rs'),
    ('vortex-fsst', 'encodings/fsst', 'goldenfiles/fsst.metadata', 'src/array.rs'),
    ('vortex-runend', 'encodings/runend', 'goldenfiles/runend.metadata', 'src/lib.rs'),
]


def fetch(path):
    url = f'https://api.github.com/repos/vortex-data/vortex/contents/{path}?ref={REVISION}'
    request = urllib.request.Request(url, headers={'Accept': 'application/vnd.github+json',
                                                  'User-Agent': 'ShardLoom-provenance-review'})
    with urllib.request.urlopen(request, timeout=30) as response:
        encoded = response.read((1 << 20) + 1)
    assert len(encoded) <= 1 << 20
    value = json.loads(encoded)
    assert value['path'] == path and value['type'] == 'file' and value['encoding'] == 'base64'
    data = base64.b64decode(''.join(value['content'].split()), validate=True)
    assert len(data) == value['size']
    git_sha = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    assert git_sha == value['sha']
    return data, {'url': value['html_url'], 'api_url': url, 'git_blob_sha1': git_sha,
                  'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}


assert not OUT.exists()
OUT.mkdir()
records = []
for provider, upstream, fixture, test_source in SOURCES:
    original_test, test_identity = fetch(f'{upstream}/{test_source}')
    local_test = ROOT / 'vendor' / provider / test_source
    assert original_test == local_test.read_bytes(), (provider, 'test source differs from pinned commit')
    data, identity = fetch(f'{upstream}/{fixture}')
    if provider == 'vortex-array':
        assert identity['git_blob_sha1'] == 'f5f444ac9685169f3590dacec84b69c5a4d91566'
    destination = OUT / provider / fixture
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    records.append({'provider': provider, 'path': fixture, **identity,
                    'matching_test_source': {'path': test_source, **test_identity}})
    print(json.dumps(records[-1]), flush=True)
with (OUT / 'receipt.json').open('x') as stream:
    json.dump({'status': 'passed', 'revision': REVISION, 'files': records,
               'test_sources_identical_to_published_crates': True,
               'scope': 'Supplemental upstream test fixtures only; registry archives remain authoritative for production sources.'}, stream, indent=2)
    stream.write('\n')
