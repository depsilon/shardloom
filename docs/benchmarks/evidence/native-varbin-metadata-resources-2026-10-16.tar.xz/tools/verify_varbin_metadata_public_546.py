"""Inspect every compressed public envelope against the unchanged complete matrix."""
import verify_stream_dynamic_subquery_public_522 as review
import run_varbin_metadata_acceptance_546 as acceptance

review.PUBLIC = acceptance.PUBLIC
review.RUNTIME_PATH = acceptance.PUBLIC_ACCEPTANCE
review.RECEIPT_PATH = acceptance.OUT/'varbin-metadata-public-546.json'
review.BASELINE_PATH = acceptance.PROTOCOL
review.OUTPUT = acceptance.OUT/'varbin-metadata-public-inspection-report-546.json'
review.ACCEPTED_SOURCE = acceptance.SOURCE
review.load = acceptance.load
review.unchanged = acceptance.unchanged

if __name__ == '__main__':
    acceptance.protocol()
    review.main()
    acceptance.protocol()
