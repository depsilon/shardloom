"""Run the frozen lifecycle comparison and full native public acceptance serially."""
import json
from pathlib import Path
import subprocess
import sys

from freeze_native_release_298 import OUT, ROOT
from run_query_timing_runtime_461 import guarded
from run_varbin_metadata_acceptance_546 import unchanged

PYTHON = Path('/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3')
COST = OUT/'varbin_metadata_cost_546.py'
DEST = OUT/'varbin-metadata-cost-543'
ACCEPTANCE = OUT/'run_varbin_metadata_acceptance_546.py'


def stage(name, timeout, command):
    unchanged()
    print(json.dumps(dict(stage=name, status='starting')), flush=True)
    guarded(name, timeout, command)
    unchanged()
    print(json.dumps(dict(stage=name, status='passed')), flush=True)


def main():
    assert Path(sys.executable) == PYTHON
    checks = json.loads((OUT/'varbin-metadata-checks-546c.json').read_text())
    assert checks['status'] == 'passed' and checks['source_identity_preserved']
    assert len(checks['completed']) == 6
    command = ['/Users/dylan/.cargo/bin/rustup', 'run', '1.99.0', 'cargo', 'test',
        '--offline', '--locked', '--release', '-p', 'shardloom-vortex',
        '--features', 'release-user-surfaces', '--lib', '--no-run']
    assert command == json.loads((DEST/'baseline-build.json').read_text())['command']
    stage('varbin-metadata-candidate-build-546', 2100, command)
    stage('varbin-metadata-freeze-build-546', 180,
        [PYTHON, '-B', COST, 'freeze-build', '--receipt', OUT/'varbin-metadata-candidate-build-546.json'])
    stage('varbin-metadata-freeze-cost-546', 180, [PYTHON, '-B', COST, 'freeze-protocol'])
    stage('varbin-metadata-cost-forward-546', 2100, [PYTHON, '-B', COST, 'run', '--order', 'forward'])
    forward = json.loads((DEST/'forward/summary.json').read_text())
    assert forward['status'] == 'passed'
    if forward['breaches']:
        stage('varbin-metadata-cost-reverse-546', 2100, [PYTHON, '-B', COST, 'run', '--order', 'reverse'])
    stage('varbin-metadata-cost-decision-546', 180, [PYTHON, '-B', COST, 'decide'])
    stage('varbin-metadata-cost-inspection-546', 180,
        [PYTHON, '-B', OUT/'verify_varbin_metadata_cost_546.py'])
    decision = json.loads((DEST/'decision.json').read_text())
    assert decision['status'] == 'retained_pending_broad_acceptance', decision
    stage('native-final-cli-release-build-varbinmetadata546c', 2100,
        ['cargo', 'build', '--offline', '--locked', '--release', '-p', 'shardloom-cli',
         '--features', 'release-user-surfaces', '--message-format=json-render-diagnostics'])
    stage('native-final-python-release-build-varbinmetadata546c', 2100,
        [PYTHON, '-B', ROOT/'scripts/build_native_python.py', '--release', '--offline',
         '--output-dir', OUT/'varbin-metadata-native-binding-546'])
    stage('varbin-metadata-freeze-native-546', 180,
        [PYTHON, '-B', OUT/'freeze_native_release_298.py', '--run-id', 'varbinmetadata546c'])
    stage('varbin-metadata-declarations-546', 180, [PYTHON, '-B', ACCEPTANCE, 'declare'])
    stage('varbin-metadata-direct-546', 1800,
        [OUT/'selected-view-python-468/bin/python', '-B', ACCEPTANCE, 'direct'])
    print(json.dumps(dict(stage='public', status='starting')), flush=True)
    subprocess.run([str(PYTHON), '-B', str(ACCEPTANCE), 'public'], cwd=ROOT, check=True)
    unchanged()
    stage('varbin-metadata-public-inspection-546', 600,
        [PYTHON, '-B', OUT/'verify_varbin_metadata_public_546.py'])
    print(json.dumps(dict(status='passed', full43_pending=True)), flush=True)


if __name__ == '__main__':
    main()
