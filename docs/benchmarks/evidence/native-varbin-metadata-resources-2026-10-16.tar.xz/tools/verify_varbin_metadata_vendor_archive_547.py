"""Verify archived, selected VarBin metadata vendor-test evidence without I/O."""
import ast
import hashlib
import json
from pathlib import Path
import re

O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
AGGREGATE = O / 'varbin-metadata-vendor-acceptance-546.json'
PRIMARY = O / 'varbin-metadata-vendor-primary-verification-546.json'
PROVIDERS = ('vortex-array', 'vortex-fsst', 'vortex-runend', 'vortex-zstd')
SELECTED = {
    '545c': ('vortex-array', 'vortex-fsst', 'vortex-runend'),
    '545e': ('vortex-zstd',),
}
EXPECTED_TESTS = {
    ('545c', 'vortex-array'): (3357, 0, 1, 0, 0),
    ('545c', 'vortex-fsst'): (90, 0, 1, 0, 0),
    ('545c', 'vortex-runend'): (73, 0, 0, 0, 0),
    ('545e', 'vortex-zstd'): (67, 0, 0, 0, 0),
}


def _digest(data):
    return hashlib.sha256(data).hexdigest()


def _bytes(by_path, path):
    data = by_path(str(Path(path)))
    assert isinstance(data, bytes), f'archive lookup did not return bytes: {path}'
    return data


def _json(by_path, path):
    return json.loads(_bytes(by_path, path))


def _identity(by_path, item):
    assert set(item) in ({'path', 'sha256'}, {'path', 'bytes', 'sha256'})
    data = _bytes(by_path, item['path'])
    assert _digest(data) == item['sha256'], item['path']
    if 'bytes' in item:
        assert len(data) == item['bytes'], item['path']
    return data


def _command_run_is_success_gated(runner_bytes):
    tree = ast.parse(runner_bytes.decode('utf-8'))
    loops = [node for node in ast.walk(tree)
             if isinstance(node, ast.For) and isinstance(node.target, ast.Name)
             and node.target.id == 'command' and isinstance(node.iter, ast.Name)
             and node.iter.id == 'commands']
    assert len(loops) == 1
    body = loops[0].body
    run_positions, append_positions = [], []
    for index, statement in enumerate(body):
        for node in ast.walk(statement):
            if not isinstance(node, ast.Call):
                continue
            if (isinstance(node.func, ast.Attribute) and node.func.attr == 'run'
                    and isinstance(node.func.value, ast.Name) and node.func.value.id == 'subprocess'):
                assert node.args and isinstance(node.args[0], ast.Name) and node.args[0].id == 'command'
                assert any(keyword.arg == 'check' and isinstance(keyword.value, ast.Constant)
                           and keyword.value.value is True for keyword in node.keywords)
                run_positions.append(index)
            if (isinstance(node.func, ast.Attribute) and node.func.attr == 'append'
                    and isinstance(node.func.value, ast.Name) and node.func.value.id == 'completed'):
                assert node.args and isinstance(node.args[0], ast.Name) and node.args[0].id == 'command'
                append_positions.append(index)
    assert len(run_positions) == len(append_positions) == 1
    assert run_positions[0] < append_positions[0]


def verify_vendor(by_path, source_map):
    """Verify the selected 545c/545e provider evidence using archived bytes only."""
    assert len(source_map) == 2371
    aggregate_bytes = _bytes(by_path, AGGREGATE)
    aggregate = json.loads(aggregate_bytes)
    primary_bytes = _bytes(by_path, PRIMARY)
    primary = json.loads(primary_bytes)
    aggregate_id = dict(path=str(AGGREGATE), bytes=len(aggregate_bytes), sha256=_digest(aggregate_bytes))
    primary_id = dict(path=str(PRIMARY), bytes=len(primary_bytes), sha256=_digest(primary_bytes))
    assert aggregate['artifact_id'] == 'varbin-metadata-vendor-acceptance-546'
    assert primary['status'] == 'passed' and primary['selected_sources_match_current']
    assert primary['historical_failure_preserved']
    assert primary['aggregate'] == {'path': str(AGGREGATE), 'sha256': aggregate_id['sha256']}
    assert primary['source_files_verified'] == 841 and primary['commands_verified'] == 8
    assert aggregate['check_count'] == len(aggregate['checks']) == 8
    assert aggregate['overall_status'] == 'selected_checks_passed'
    assert set(aggregate['artifacts']) == {'545c', '545e'}
    assert aggregate['historical_run_status']['545c_overall_status'] == 'failed'
    assert aggregate['historical_run_status']['545e_overall_status'] == 'passed'
    assert 'excluded' in aggregate['historical_run_status']['interpretation']

    protocols, summaries, run_artifacts, receipts, logs = {}, {}, {}, {}, {}
    verified_artifact_identities = {}
    for tag in ('545c', '545e'):
        artifacts = aggregate['artifacts'][tag]
        assert set(artifacts) == {'runner', 'protocol', 'summary', 'supervised_receipt', 'log'}
        raw = {name: _identity(by_path, item) for name, item in artifacts.items()}
        verified_artifact_identities[tag] = {
            name: dict(path=item['path'], bytes=len(raw[name]), sha256=item['sha256'])
            for name, item in artifacts.items()
        }
        runner_path = O / f'run_varbin_metadata_vendor_{tag}.py'
        assert artifacts['runner']['path'] == str(runner_path)
        protocol = json.loads(raw['protocol'])
        summary = json.loads(raw['summary'])
        receipt = json.loads(raw['supervised_receipt'])
        log = raw['log'].decode('utf-8')
        assert protocol['root'] == str(ROOT)
        assert protocol['helper_sha256'] == artifacts['runner']['sha256']
        assert summary['protocol_sha256'] == artifacts['protocol']['sha256']
        assert summary['sources_unchanged'] is True
        _command_run_is_success_gated(raw['runner'])

        assert receipt['command'][-1] == str(runner_path)
        assert receipt['log_sha256'] == artifacts['log']['sha256']
        assert receipt['output_bytes'] == len(raw['log'])
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup']
        assert receipt['supervisor_sha256']
        if tag == '545c':
            assert summary['status'] == receipt['status'] == 'failed'
            assert receipt['returncode'] == 1
            assert summary['completed'] == protocol['commands'][:6]
            assert len(summary['completed']) == 6 and summary['failure']
        else:
            assert summary['status'] == receipt['status'] == 'passed'
            assert receipt['returncode'] == 0 and summary['failure'] is None
            assert summary['completed'] == protocol['commands'] and len(summary['completed']) == 2

        assert protocol['root_lock_sha256'] == source_map['Cargo.lock']
        root_lock = _bytes(by_path, ROOT / 'Cargo.lock')
        assert _digest(root_lock) == protocol['root_lock_sha256']
        assert aggregate['lockfile_digests']['root_cargo_lock_sha256'] == _digest(root_lock)

        assert aggregate['source_snapshot_manifests'][tag] == protocol['source_files']
        protocols[tag], summaries[tag], run_artifacts[tag] = protocol, summary, artifacts
        receipts[tag], logs[tag] = receipt, log

        # Every staged standalone provider lock is checked independently; it may
        # legitimately differ from the root lock for an isolated workspace.
        standalone = summary['standalone_lock_sha256']
        recorded = aggregate['lockfile_digests'][f'{tag}_standalone_provider_lock_sha256']
        assert standalone == recorded
        assert set(standalone) == set(PROVIDERS)
        for provider, expected_sha in standalone.items():
            lock_path = O / f'varbin-metadata-vendor-{tag}' / provider / 'Cargo.lock'
            lock_data = _bytes(by_path, lock_path)
            assert _digest(lock_data) == expected_sha, str(lock_path)

    prior = protocols['545c']
    later = protocols['545e']
    later_summary = summaries['545e']
    assert later['prior_verified_providers'] == list(PROVIDERS[:3])
    assert later['prior_protocol'] == {
        'path': run_artifacts['545c']['protocol']['path'],
        'sha256': run_artifacts['545c']['protocol']['sha256'],
    }
    assert later['prior_summary'] == {
        'path': run_artifacts['545c']['summary']['path'],
        'sha256': run_artifacts['545c']['summary']['sha256'],
    }
    assert summaries['545c']['completed'] == prior['commands'][:6]
    assert later_summary['completed'] == later['commands']
    for provider in PROVIDERS[:3]:
        assert prior['source_files'][provider] == later['source_files'][provider]

    aggregate_checks = aggregate['checks']
    expected_checks = []
    for tag in ('545c', '545e'):
        for index, command in enumerate(summaries[tag]['completed']):
            if tag == '545c' and index >= 6:
                continue
            expected_checks.append((tag, command))
    assert len(expected_checks) == len(aggregate_checks) == 8
    for check, (tag, command) in zip(aggregate_checks, expected_checks, strict=True):
        assert check['run'] == tag and check['command'] == command and check['completed'] is True
        assert check['exit_status'] == 0
        assert command in protocols[tag]['commands'] and command in summaries[tag]['completed']
        assert command[0] == 'cargo' and '--offline' in command and '--lib' in command
        if command[1] == 'clippy':
            assert '-D' in command and 'warnings' in command
        else:
            assert command[1] == 'test' and '--test-threads=2' in command

    # Check protocol, aggregate and archived staged bytes against the accepted
    # source map for each provider whose checks are selected by this receipt.
    source_files_verified = 0
    provider_rows = []
    for tag, providers in SELECTED.items():
        protocol = protocols[tag]
        for provider in providers:
            files = protocol['source_files'][provider]
            expected_count = {'vortex-array': 765, 'vortex-fsst': 28,
                              'vortex-runend': 28, 'vortex-zstd': 20}[provider]
            assert len(files) == expected_count
            assert aggregate['source_snapshot_manifests'][tag][provider] == files
            for relative, expected_sha in files.items():
                source_key = f'vendor/{provider}/{relative}'
                assert source_map[source_key] == expected_sha, source_key
                staged_path = O / f'varbin-metadata-vendor-{tag}' / provider / relative
                staged = _bytes(by_path, staged_path)
                assert _digest(staged) == expected_sha, str(staged_path)
                source_files_verified += 1
            provider_rows.append(dict(run=tag, provider=provider, source_files=len(files)))
    assert source_files_verified == 841
    assert primary['source_files_verified'] == source_files_verified

    # The failed 545c Zstd source snapshot is retained as excluded historical
    # evidence. Its staged bytes match that old snapshot; accepted source bytes
    # instead match the 545e snapshot/current source map.
    old_relative = 'src/array.rs'
    old_sha = prior['source_files']['vortex-zstd'][old_relative]
    current_sha = source_map['vendor/vortex-zstd/' + old_relative]
    old_staged = _bytes(by_path, O / 'varbin-metadata-vendor-545c/vortex-zstd' / old_relative)
    current_bytes = _bytes(by_path, ROOT / 'vendor/vortex-zstd' / old_relative)
    assert _digest(old_staged) == old_sha and old_sha != current_sha
    assert _digest(current_bytes) == current_sha
    assert later['source_files']['vortex-zstd'][old_relative] == current_sha
    historical = aggregate['current_source_comparisons']['historical_excluded_mismatch']
    assert historical['run'] == '545c' and historical['provider'] == 'vortex-zstd'
    assert historical['path'] == old_relative
    assert historical['snapshot_sha256'] == old_sha and historical['current_sha256'] == current_sha
    assert 'vortex-zstd' in summaries['545c']['failure']
    failed_zstd_command = prior['commands'][6]
    assert failed_zstd_command[1] == 'test'
    assert any(value.endswith('/vortex-zstd/Cargo.toml') for value in failed_zstd_command)
    assert repr(failed_zstd_command) in summaries['545c']['failure']
    assert 'error: could not compile `vortex-zstd` (lib test)' in logs['545c']

    test_groups = {}
    for tag, providers in SELECTED.items():
        log = logs[tag]
        actual = [tuple(map(int, row)) for row in re.findall(
            r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', log)]
        running = [int(value) for value in re.findall(r'^running (\d+) tests$', log, re.M)]
        assert len(actual) == len(providers) and len(running) == len(providers)
        for index, provider in enumerate(providers):
            expected = EXPECTED_TESTS[(tag, provider)]
            assert actual[index] == expected
            assert running[index] == expected[0] + expected[2]
            test_groups[provider] = dict(run=tag, running=running[index], passed=expected[0],
                failed=expected[1], ignored=expected[2], measured=expected[3], filtered_out=expected[4])
            check = next(row for row in aggregate_checks
                         if row['run'] == tag and row['provider'] == provider and row['check'] == 'unit_tests')
            recorded = check['test_counts']
            assert tuple(recorded[key] for key in ('passed', 'failed', 'ignored', 'measured', 'filtered_out')) == expected
        if tag == '545e':
            assert 'error: could not compile `vortex-zstd` (lib test)' not in log
    assert aggregate['test_totals'] == dict(passed=3587, failed=0, ignored=2, running=3589)
    assert primary['test_counts'] == [list(EXPECTED_TESTS[key]) for key in EXPECTED_TESTS]

    return dict(status='passed', aggregate=aggregate_id, primary_verification=primary_id,
        artifact_identities=verified_artifact_identities, source_files_verified=source_files_verified,
        commands_verified=len(aggregate_checks), selected_providers=provider_rows,
        test_groups=test_groups, test_totals=dict(passed=3587, failed=0, ignored=2, running=3589),
        root_lock_sha256=aggregate['lockfile_digests']['root_cargo_lock_sha256'],
        standalone_lock_sha256={
            tag: summaries[tag]['standalone_lock_sha256'] for tag in ('545c', '545e')},
        historical_failure_preserved=True,
        historical_excluded_zstd_mismatch=dict(run='545c', provider='vortex-zstd',
            path=old_relative, snapshot_sha256=old_sha, accepted_source_sha256=current_sha))
