"""Preserve exact baseline provenance, lockfile and acceptance text for portable review."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
BASE = '0f8de6a913ca3bb8a170ddeb3c175c24eb521e64'
DEST = OUT / 'varbin-metadata-baseline-provider-provenance-547.json'


def blob(name):
    value = subprocess.check_output(['git', 'cat-file', 'blob', BASE + ':' + name], cwd=ROOT)
    return dict(path=name, bytes=len(value), sha256=hashlib.sha256(value).hexdigest(),
        git_blob_oid=subprocess.check_output(['git', 'rev-parse', BASE + ':' + name],
            cwd=ROOT, text=True).strip(), utf8=value.decode())


def main():
    assert not DEST.exists()
    baseline = json.loads((OUT / 'varbin-metadata-cost-543/baseline-source.json').read_text())
    assert baseline['head'] == BASE
    providers = {}
    for name in ('vortex-array', 'vortex-zstd'):
        record = blob('vendor/' + name + '/upstream-provenance.json')
        record['value'] = json.loads(record['utf8'])
        providers[name] = record
    lock = blob('Cargo.lock')
    assert lock['sha256'] == baseline['source_sha256']['Cargo.lock']
    contract = blob('docs/architecture/native-varbin-metadata-resources-2026-10-16.md')
    assert contract['sha256'] == baseline['contract_sha256']
    result = dict(status='passed', commit=BASE, providers=providers,
        cargo_lock=lock, original_contract=contract)
    with DEST.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    assert json.loads(DEST.read_text()) == result
    print(json.dumps(dict(status='passed', providers=len(providers),
        path=str(DEST), bytes=DEST.stat().st_size,
        sha256=hashlib.sha256(DEST.read_bytes()).hexdigest())))


if __name__ == '__main__':
    main()
