"""Record primary local acceptance after complete VarBin metadata archive inspection."""
import csv
from decimal import Decimal
import hashlib
import io
import json
import lzma
import math
from pathlib import Path

from run_varbin_metadata_acceptance_546 import OUT, ROOT, identity, unchanged

STEM = 'native-varbin-metadata-resources-2026-10-16'
DEST = ROOT / 'docs/benchmarks/evidence'


def main():
    unchanged()
    index_path = DEST / (STEM + '.json')
    original = index_path.read_bytes()
    index = json.loads(original)
    audit_path = OUT / 'varbin-metadata-packet-audit-547.json'
    audit = json.loads(audit_path.read_text())
    assert index['status'] == 'packaged_local_pending_acceptance_decision'
    assert audit['status'] == 'passed' and audit['index'] == identity(index_path)
    assert audit['member_count'] == index['member_count'] and index['member_count'] > 13000
    assert audit['raw_bytes'] == index['raw_bytes'] and 0 < index['raw_bytes'] <= 256 * 1024 ** 2
    assert audit['complete_archive_identity_and_membership_verified']
    assert audit['current_source_map_unchanged'] and audit['source_overlay_verified']
    assert audit['public']['cases'] == 4827 and audit['public']['families'] == 36
    assert audit['full43']['calls'] == audit['full43']['queries'] == 43
    assert audit['full43']['repeats'] == 1 and audit['full43']['complete_rows'] == 381
    for order in ('forward', 'reverse'):
        observed = audit['lifecycle'][order]
        if observed is not None:
            assert observed['all_input_hashes_equal'] and observed['all_serialized_outputs_equal']
            assert observed['distinct_cases'] == 32 and observed['complete_operations'] == 4864
    assert not audit['lifecycle']['forward']['breaches']
    assert audit['lifecycle']['reverse'] is None
    assert audit['vendor']['source_files_verified'] == 841 and audit['vendor']['commands_verified'] == 8
    assert audit['registry_members_verified'] == 50 and audit['release_script_tests'] == 164
    assert audit['no_speedup_claim'] and not audit['hosted_integration_complete']
    assert not audit['installed_wheel_proof']
    records = {}
    for name in ('varbin-metadata-package-547', 'varbin-metadata-portable-inspection-547'):
        path = OUT / (name + '.json')
        receipt = json.loads(path.read_text())
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup']
        log = path.with_suffix('.log')
        assert identity(log)['sha256'] == receipt['log_sha256']
        records[name] = dict(receipt=receipt, receipt_identity=identity(path),
                            log=log.read_text(), log_identity=identity(log))
    for key in ('archive', 'manifest'):
        item = index[key]
        current = identity(DEST / item['file'])
        assert current['sha256'] == item['sha256'] and current['bytes'] == item['bytes']
    supplement = dict(status='passed_primary_local_acceptance', original_index_utf8=original.decode(),
        original_index_identity=audit['index'], independent_audit=audit,
        independent_audit_identity=identity(audit_path), supervision=records, helper=identity(__file__))
    raw = (json.dumps(supplement, indent=2, sort_keys=True) + '\n').encode()
    packed = lzma.compress(raw)
    assert lzma.decompress(packed) == raw
    supplement_path = DEST / (STEM + '.audit.json.xz')
    timing_path = DEST / (STEM + '.engine-times.csv')
    table_path = OUT / 'varbin-metadata-engine-table-547.md'
    assert not any(path.exists() for path in (supplement_path, timing_path, table_path))
    review = json.loads((OUT / 'varbin-metadata-full43-review-546.json').read_text())
    assert review['status'] == 'passed' and review['all_values_schemas_and_clocks_reopened']
    assert review['resources_no_fallback_native_certificates'] and review['native_children_absent']
    assert review['original_input_and_sources_unchanged'] and not review['performance_claim_allowed']
    full_csv = Path(review['timing_csv']['path'])
    assert identity(full_csv) == review['timing_csv']
    with full_csv.open(newline='') as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == 43 and [int(row['query']) for row in rows] == list(range(1, 44))
    assert all(row['run'] == '1' and row['passed'] == 'True' and row['engine_timing_reported'] == 'True' for row in rows)
    total = sum(Decimal(row['engine_execution_seconds']) for row in rows)
    assert math.isclose(float(total), audit['engine_execution_seconds'], rel_tol=0, abs_tol=1e-9)
    output = io.StringIO(newline='')
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(['query', 'run', 'engine_execution_seconds'])
    writer.writerows([row['query'], row['run'], f"{Decimal(row['engine_execution_seconds']):.9f}"] for row in rows)
    table = '| Query | Engine seconds |\n| --- | ---: |\n' + ''.join(
        f"| Q{int(row['query']):02} | {Decimal(row['engine_execution_seconds']):.9f} |\n" for row in rows)
    unchanged()
    assert index_path.read_bytes() == original
    with supplement_path.open('xb') as stream:
        stream.write(packed)
    with timing_path.open('x') as stream:
        stream.write(output.getvalue())
    with table_path.open('x') as stream:
        stream.write(table)
    index.update(status='passed_local', independent_packet_audit_passed=True,
        source_overlay_verified=True, installed_wheel_proof=False,
        audit=dict(file=supplement_path.name, bytes=len(packed), sha256=hashlib.sha256(packed).hexdigest()),
        engine_execution_seconds=float(total), engine_execution_seconds_decimal=str(total), engine_timings=dict(file=timing_path.name,
            bytes=timing_path.stat().st_size, sha256=identity(timing_path)['sha256']))
    index_path.write_text(json.dumps(index, indent=2) + '\n')
    assert json.loads(index_path.read_text()) == index
    print(json.dumps(dict(status='passed_local', members=index['member_count'], engine_execution_seconds=float(total))))


if __name__ == '__main__':
    main()
