"""Freeze and compare the unchanged complete 32-cell buffer-table lifecycle."""
import argparse
import base64
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import platform
import re
import shutil
import statistics
import subprocess
import sys
import time

import compression_cost_456c as c

BASE = '0f8de6a913ca3bb8a170ddeb3c175c24eb521e64'
c.BASE = BASE
c.DEST = c.OUT / 'varbin-metadata-cost-543'
c.HARNESS = 'shardloom-vortex/src/resident_memory_varbin_metadata_cost_tests.rs'
c.TEST = 'resident_memory_source::encoded_transfer::tests::varbin_metadata_cost_tests::native_varbin_metadata_complete_lifecycle_cost_screen'
CONTRACT = c.ROOT / 'docs/architecture/native-varbin-metadata-resources-2026-10-16.md'
PROOF = c.DEST / 'baseline-git-verification-546.json'
SOURCE = c.DEST / 'candidate-source-546.json'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=c.ROOT, text=True).strip()


def required_tests():
    result = set()
    for name in ('native_provider_varbin_metadata_tests.rs',
                 'native_provider_varbin_construction_tests.rs',
                 'native_provider_varbin_deserialize_tests.rs',
                 'resident_memory_varbin_transfer_tests.rs'):
        result.update(re.findall(r'^fn ((?:native_varbin_|encoded_transfer_varbin_)\w+)\(',
            (c.ROOT / 'shardloom-vortex/src' / name).read_text(), re.M))
    assert len(result) == 21
    return result


def verify_build(value):
    assert value['status'] == 'passed'
    for key in ('source', 'build_receipt', 'build_log', 'binary', 'test_inventory'):
        assert c.bound(value[key]['path']) == value[key], key
    receipt = c.read(value['build_receipt']['path'])
    source = c.read(value['source']['path'])
    baseline = c.read(c.DEST / 'baseline-build.json')
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup']
    assert receipt['head'] == source['head'] and not receipt['working_tree']
    assert receipt['log_sha256'] == value['build_log']['sha256']
    assert receipt['command'] == value['command'] == baseline['command']
    assert receipt['environment'] == value['environment'] == baseline['environment']
    assert all(flag in receipt['command'] for flag in ('--release', '--no-run', 'release-user-surfaces'))


def verify_baseline_git():
    source = c.read(c.DEST / 'baseline-source.json')
    assert source['head'] == BASE
    names = sorted(source['source_sha256'])
    tracked = git('ls-tree', '-r', '--name-only', BASE).splitlines()
    expected = {name for name in tracked if name.endswith(('.rs', '.py', 'Cargo.toml'))
                or name == 'Cargo.lock' or name.startswith('.cargo/')}
    assert set(names) == expected
    objects = subprocess.run(['git', 'cat-file', '--batch'], cwd=c.ROOT,
        input=''.join(BASE + ':' + name + '\n' for name in names).encode(),
        stdout=subprocess.PIPE, check=True).stdout
    stream = io.BytesIO(objects)
    for name in names:
        _, kind, size = stream.readline().decode().strip().split()
        assert kind == 'blob'
        payload = stream.read(int(size))
        assert stream.read(1) == b'\n'
        assert hashlib.sha256(payload).hexdigest() == source['source_sha256'][name], name
    assert stream.read() == b''
    proof = dict(status='passed', commit=BASE, source=c.bound(c.DEST / 'baseline-source.json'),
        files=len(names), all_runtime_blobs_match_frozen_build_source=True,
        baseline_freezer=c.bound(c.OUT / 'freeze_varbin_metadata_543.py'))
    c.save(PROOF, proof)
    return proof


def prepare():
    assert not git('status', '--porcelain')
    baseline = c.read(c.DEST / 'baseline-source.json')
    compiler = subprocess.check_output(['/Users/dylan/.cargo/bin/rustup', 'run', '1.99.0', 'rustc', '-Vv'], text=True)
    assert compiler == baseline['compiler']
    assert c.sha(c.ROOT / c.HARNESS) == baseline['harness_sha256']
    c.save(SOURCE, dict(root=str(c.ROOT), head=git('rev-parse', 'HEAD'), base=BASE,
        source_sha256=c.sources(c.ROOT), status='', compiler=compiler,
        diff_base64=base64.b64encode(subprocess.check_output(
            ['git', 'diff', '--binary', BASE, 'HEAD'], cwd=c.ROOT)).decode('ascii'),
        broad_source=c.bound(c.OUT / 'native-release-source-varbinmetadata546c.json'),
        prepared_at=time.time()))
    print(json.dumps(dict(status='prepared', role='candidate')))


def freeze_build(receipt_path):
    source = c.read(SOURCE)
    assert c.sources(c.ROOT) == source['source_sha256']
    assert git('rev-parse', 'HEAD') == source['head'] and not git('status', '--porcelain')
    receipt = c.read(receipt_path)
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['head'] == source['head'] and not receipt['working_tree']
    log = Path(receipt_path).with_suffix('.log')
    assert c.sha(log) == receipt['log_sha256']
    original, = re.findall(r'Executable unittests src/lib.rs \(([^)]+)\)', log.read_text())
    original = Path(receipt['cwd']) / original
    target = c.DEST / 'shardloom-varbin-metadata-candidate'
    c.storage(c.DEST, original.stat().st_size + 128 * c.MIB)
    assert not target.exists()
    before = c.sha(original)
    shutil.copy2(original, target)
    assert c.sha(original) == c.sha(target) == before
    listing = subprocess.check_output([str(target), '--list'], text=True)
    assert c.TEST + ': test' in listing
    assert all(name + ': test' in listing for name in required_tests())
    inventory = c.DEST / 'candidate-test-list.txt'
    with inventory.open('x') as stream:
        stream.write(listing)
    value = dict(status='passed', role='candidate', root=str(c.ROOT), source=c.bound(SOURCE),
        binary=c.bound(target), build_receipt=c.bound(receipt_path), build_log=c.bound(log),
        test_inventory=c.bound(inventory), test_name=c.TEST,
        command=receipt['command'], environment=receipt['environment'])
    verify_build(value)
    c.save(c.DEST / 'candidate-build.json', value)
    print(json.dumps(dict(status='frozen', role='candidate', binary_sha256=before)))


def freeze_protocol():
    proof = verify_baseline_git()
    identities = {}
    for role in ('baseline', 'candidate'):
        path = c.DEST / (role + '-build.json')
        value = c.read(path)
        verify_build(value)
        identities[role] = dict(manifest=c.bound(path), **value)
    baseline = c.read(identities['baseline']['source']['path'])
    old_contract = subprocess.check_output(['git', 'show', BASE + ':' + str(CONTRACT.relative_to(c.ROOT))], cwd=c.ROOT)
    assert hashlib.sha256(old_contract).hexdigest() == baseline['contract_sha256']
    acceptance = lambda text: text.split('## Acceptance protocol\n', 1)[1].split('Required verification:', 1)[0]
    assert acceptance(old_contract.decode()) == acceptance(CONTRACT.read_text())
    assert baseline['harness_sha256'] == c.sha(c.ROOT / c.HARNESS)
    assert identities['baseline']['binary']['sha256'] != identities['candidate']['binary']['sha256']
    names = {role: {line.removesuffix(': test') for line in Path(value['test_inventory']['path']).read_text().splitlines()
                   if line.endswith(': test')} for role, value in identities.items()}
    assert not names['baseline'] - names['candidate']
    added = names['candidate'] - names['baseline']
    assert len(added) == 21 and {name.split('::')[-1] for name in added} == required_tests()
    helpers = [Path(__file__), Path(c.__file__), c.SUPERVISOR, c.OUT / 'run_guarded.py',
        c.OUT / 'freeze_varbin_metadata_543.py', c.OUT / 'verify_varbin_metadata_cost_546.py',
        Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py')]
    helpers += [c.ROOT / 'scripts' / name for name in ('timed_native_command.py',
        'run_clickbench_query_uat.py', 'run_clickbench_paired_query_uat.py', 'local_uat_storage.py')]
    assert c.sha(c.SUPERVISOR) == '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97'
    protocol = dict(schema='shardloom.varbin_metadata_lifecycle_cost.v1', frozen_at=time.time(),
        identities=identities, helpers=[c.bound(path) for path in helpers],
        baseline_git_proof=c.bound(PROOF), baseline_source_files=proof['files'],
        contract=c.bound(CONTRACT), original_contract_sha256=baseline['contract_sha256'],
        contract_amendment='Clarify unchanged empty-slice reduction: discarded tables need no owner; explicit reconstructed empty views retain shared ownership. Status/checklist wording updated. Acceptance grid, clocks and thresholds unchanged.',
        acceptance_protocol_text_sha256=hashlib.sha256(acceptance(old_contract.decode()).encode()).hexdigest(),
        test_harness=c.bound(c.ROOT / c.HARNESS), test_name=c.TEST,
        binary_inventory_delta=dict(retained_tests=len(names['baseline']), added_candidate_tests=sorted(added)),
        cases=[dict(kind=kind, rows=rows, encoding=encoding, chunks=chunks, grant_bytes=64*c.MIB)
               for kind in ('utf8', 'binary') for rows in (32, 65536)
               for encoding in ('canonical', 'fsst', 'zstd', 'runend') for chunks in (2, 16)],
        samples_per_case=3, operations_per_sample=25, recorded_warmups_per_case=1,
        elapsed_gate=dict(relative=.10, absolute_seconds_per_operation=.0001),
        process_cpu_gate=dict(relative=.10, absolute_seconds=1),
        process_rss_gate=dict(relative=.25, absolute_bytes=64*c.MIB),
        repeat_rule='Any forward breach triggers the complete reverse order. Repeated same-cell/metric breaches require diagnosis before retention.',
        operation_clock='Producer session creation, native reopen/decode, filter/take/slice, native concatenation, fresh receiving-session copy, native serialization/hash, producer close, every output value/null check, and complete owner/session release. Fixtures/references are outside.',
        process_clock='Native test executable creation through exit, including fixtures, warmups, samples and output; separate from supervised workflow.',
        cache='Generated in-memory inputs, uncontrolled ordinary allocator/OS caches; no pacing, cache flush or battery/thermal admission.',
        performance_claim_allowed=False, platform=platform.platform(), logical_cpus=os.cpu_count(),
        physical_memory_bytes=os.sysconf('SC_PAGE_SIZE')*os.sysconf('SC_PHYS_PAGES'),
        rust=baseline['compiler'])
    verify(protocol)
    c.save(c.DEST / 'protocol.json', protocol)
    print(json.dumps(dict(status='frozen_protocol', cells=32, operations_per_executable=2432, added_tests=21)))


def verify(protocol):
    for item in protocol['helpers'] + [protocol[key] for key in ('contract', 'test_harness', 'baseline_git_proof')]:
        assert c.bound(item['path']) == item
    for role, value in protocol['identities'].items():
        assert c.bound(value['manifest']['path']) == value['manifest']
        verify_build(value)
        source = c.read(value['source']['path'])
        if role == 'candidate':
            assert c.sources(c.ROOT) == source['source_sha256']
            assert c.bound(source['broad_source']['path']) == source['broad_source']
        else:
            proof = c.read(protocol['baseline_git_proof']['path'])
            assert source['head'] == BASE == proof['commit'] and proof['status'] == 'passed'
            assert proof['source'] == value['source'] and proof['files'] == len(source['source_sha256'])


def extract(path, protocol):
    text = Path(path).read_text()
    records = [json.loads(line.split('VARBIN_METADATA_COST ', 1)[1])
               for line in text.splitlines() if 'VARBIN_METADATA_COST ' in line]
    assert len(records) == 128
    complete, = [json.loads(line.split('VARBIN_METADATA_COST_COMPLETE ', 1)[1])
                 for line in text.splitlines() if 'VARBIN_METADATA_COST_COMPLETE ' in line]
    assert complete == dict(cells=32, samples_per_cell=3, operations_per_sample=25,
        recorded_warmups_per_cell=1, all_complete_values_equal=True,
        all_source_and_receiving_credits_released=True)
    assert 'test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured;' in text
    cells = []
    for index, case in enumerate(protocol['cases']):
        rows = records[index*4:index*4+4]
        assert all(all(row[key] == value for key, value in case.items()) for row in rows)
        assert [row['phase'] for row in rows] == ['warmup'] + ['measured']*3
        assert [row['sample'] for row in rows[1:]] == [0, 1, 2]
        assert [len(row['nanoseconds']) for row in rows] == [1, 25, 25, 25]
        assert all(type(ns) is int and ns > 0 for row in rows for ns in row['nanoseconds'])
        assert all(row['observation'] == rows[0]['observation'] for row in rows)
        assert all(row['input_sha256'] == rows[0]['input_sha256'] for row in rows)
        cells.append(dict(**case, records=rows, input_sha256=rows[0]['input_sha256'],
            observation=rows[0]['observation'],
            median_sample_ns=statistics.median(sum(row['nanoseconds']) for row in rows[1:])))
    return cells


def run(order):
    protocol = c.read(c.DEST / 'protocol.json')
    verify(protocol)
    logs = c.DEST / order
    assert not logs.exists()
    c.storage(logs)
    workload = c.WorkloadGuard()
    workload.check()
    lock = c.UAT / '.ingest-uat.lock'
    spec = importlib.util.spec_from_file_location('varbin_supervisor', c.SUPERVISOR)
    supervisor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(supervisor)
    report = dict(status='running', order=order, protocol=c.bound(c.DEST/'protocol.json'), runs={})
    logs.mkdir()
    lock.mkdir()
    started = time.perf_counter()
    try:
        roles = ('baseline', 'candidate') if order == 'forward' else ('candidate', 'baseline')
        for role in roles:
            verify(protocol)
            prefix = logs/role
            record = dict(status='running', role=role, host_before=c.host_snapshot(), observations=[])
            timing, pid_file = prefix.with_suffix('.timing.json'), prefix.with_suffix('.pid')
            command = [sys.executable, '-B', str(c.ROOT/'scripts/timed_native_command.py'),
                '--timing', str(timing), '--pid-file', str(pid_file), '--shared-process-group', '--',
                protocol['identities'][role]['binary']['path'], c.TEST, '--exact', '--ignored',
                '--nocapture', '--test-threads=1']
            record['command'] = command
            last = 0.0
            def guard():
                nonlocal last
                workload.check(record.get('pid'))
                if time.monotonic()-last < 2:
                    return
                record['storage'] = c.storage(logs)
                observation = c.host_snapshot()
                if pid_file.exists():
                    native_pid = int(pid_file.read_text())
                    sampled = subprocess.run(['ps', '-p', str(native_pid), '-o', 'pid=,ppid=,rss=,%cpu=,time='],
                        capture_output=True, text=True, timeout=10)
                    observation['native_process_sample'] = sampled.stdout.strip()
                record['observations'].append(observation)
                last = time.monotonic()
            print(json.dumps(dict(order=order, role=role, status='starting')), flush=True)
            try:
                with prefix.with_suffix('.stdout.txt').open('xb') as stdout, prefix.with_suffix('.stderr.txt').open('xb') as stderr:
                    code = supervisor.run(command, cwd=c.ROOT,
                        env=dict(os.environ, SHARDLOOM_VARBIN_METADATA_COST='frozen-v1', PYTHONDONTWRITEBYTECODE='1'),
                        output=stdout, error_output=stderr, timeout=900, evidence=record, guard=guard, max_output_bytes=8*c.MIB)
                assert code == 0 and record['process_group_drained'] and record['direct_child_reaped']
                assert not record['timed_out'] and not record['group_absence_unproved_at_cleanup']
                record['timing'] = c.read(timing)
                assert record['timing']['returncode'] == 0
                record['cells'] = extract(prefix.with_suffix('.stdout.txt'), protocol)
                record['status'] = 'passed'
            except BaseException as error:
                record.update(status='failed', error=f'{type(error).__name__}: {error}')
                raise
            finally:
                record['host_after'] = c.host_snapshot()
                record['files'] = [c.bound(prefix.with_suffix(suffix)) for suffix in
                    ('.stdout.txt', '.stderr.txt', '.timing.json', '.pid') if prefix.with_suffix(suffix).exists()]
                report['runs'][role] = record
                c.save(prefix.with_suffix('.json'), record)
            print(json.dumps(dict(order=order, role=role, status='passed')), flush=True)
        verify(protocol)
        breaches, cells = [], []
        for baseline, candidate in zip(report['runs']['baseline']['cells'], report['runs']['candidate']['cells'], strict=True):
            identity = {key: baseline[key] for key in ('kind', 'rows', 'encoding', 'chunks')}
            assert baseline['input_sha256'] == candidate['input_sha256'], identity
            for key in ('serialized_bytes', 'serialized_sha256', 'output_rows'):
                assert baseline['observation'][key] == candidate['observation'][key], (identity, key)
            a, b = baseline['median_sample_ns'], candidate['median_sample_ns']
            breach = b > a+max(.10*a, 25*100_000)
            if breach:
                breaches.append(dict(**identity, metric='elapsed'))
            cells.append(dict(**identity, baseline_ns_per_operation=a/25, candidate_ns_per_operation=b/25,
                relative_change=b/a-1, breach=breach, input_sha256=baseline['input_sha256'],
                baseline_observation=baseline['observation'], candidate_observation=candidate['observation']))
        a, b = (report['runs'][role]['timing'] for role in ('baseline', 'candidate'))
        acpu, bcpu = (value['user_cpu_seconds']+value['system_cpu_seconds'] for value in (a, b))
        if bcpu > acpu+max(.10*acpu, 1):
            breaches.append(dict(metric='process_cpu'))
        if b['peak_rss_bytes'] > a['peak_rss_bytes']+max(.25*a['peak_rss_bytes'], 64*c.MIB):
            breaches.append(dict(metric='process_rss'))
        report.update(status='passed', cells=cells, breaches=breaches,
            decision='needs_reverse_order' if breaches else 'within_declared_cost_bounds')
    except BaseException as error:
        report.update(status='failed', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        lock.rmdir()
        report.update(lock_released=True, supervised_workflow_seconds=time.perf_counter()-started)
        c.save(logs/'summary.json', report)
    print(json.dumps(dict(status=report['status'], order=order, decision=report['decision'], breaches=report['breaches'])), flush=True)


c.verify = verify
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('prepare', 'freeze-build', 'freeze-protocol', 'run', 'decide'))
    parser.add_argument('--receipt', type=Path)
    parser.add_argument('--order', choices=('forward', 'reverse'))
    args = parser.parse_args()
    if args.operation == 'prepare': prepare()
    elif args.operation == 'freeze-build': freeze_build(args.receipt)
    elif args.operation == 'freeze-protocol': freeze_protocol()
    elif args.operation == 'run': run(args.order)
    else: c.decide()
