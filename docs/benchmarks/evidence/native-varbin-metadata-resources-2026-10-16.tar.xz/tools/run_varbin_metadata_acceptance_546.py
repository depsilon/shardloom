"""Reuse the complete native public matrix with the frozen buffer-table candidate."""
import argparse
import json
from pathlib import Path
import sys

import run_zstd_metadata_acceptance_533 as common
from freeze_native_release_298 import ROOT, OUT, save
from run_query_timing_runtime_461 import guarded

common.SOURCE = OUT/'native-release-source-varbinmetadata546c.json'
common.MANIFEST = OUT/'native-release-artifacts-varbinmetadata546c.json'
common.PROTOCOL = OUT/'varbin-metadata-acceptance-protocol-546.json'
common.PRIOR = OUT/'zstd-metadata-acceptance-protocol-533.json'
common.PRIOR_DIRECT = OUT/'zstd-metadata-direct-tests-533.json'
common.CHECKS = OUT/'varbin-metadata-checks-546c.json'
common.COST = OUT/'varbin-metadata-cost-543/decision.json'
common.PUBLIC = OUT/'varbin-metadata-public-546'
common.DIRECT = OUT/'varbin-metadata-direct-tests-546.json'
common.PUBLIC_ACCEPTANCE = OUT/'varbin-metadata-public-acceptance-546.json'

SOURCE, MANIFEST, PROTOCOL = common.SOURCE, common.MANIFEST, common.PROTOCOL
PUBLIC, PUBLIC_ACCEPTANCE = common.PUBLIC, common.PUBLIC_ACCEPTANCE
identity, unchanged, receipt, load, protocol = (common.identity, common.unchanged,
    common.receipt, common.load, common.protocol)


def prerequisites():
    frozen = unchanged()
    checks = json.loads(common.CHECKS.read_text())
    assert checks['status'] == 'passed' and checks['source_identity_preserved']
    assert checks['source'] == identity(SOURCE)
    assert sorted(row['stage'] for row in checks['completed']) == sorted([
        'fmt', 'workspace-clippy', 'workspace-tests', 'read-clippy', 'release-clippy', 'native-tests'])
    assert identity(checks['protocol']['path']) == checks['protocol']
    for row in checks['completed']:
        assert identity(row['receipt']['path']) == row['receipt']
        assert identity(row['log']['path']) == row['log']
        record = json.loads(Path(row['receipt']['path']).read_text())
        assert record['status'] == 'passed' and record['returncode'] == 0
        assert record['process_group_drained'] and record['direct_child_reaped']
        assert not record['timed_out'] and not record['group_absence_unproved_at_cleanup']
        assert record['log_sha256'] == row['log']['sha256']
        if record['head'] != frozen['head']:
            source = row.get('reused_source', row.get('continuation_source'))
            assert source and identity(source['path']) == source
            old = json.loads(Path(source['path']).read_text())
            assert record['head'] == old['head']
            assert set(old['source_sha256']) == set(frozen['source_sha256'])
            changed = {name for name in old['source_sha256']
                       if old['source_sha256'][name] != frozen['source_sha256'][name]}
            expected = {'shardloom-vortex/src/resident_memory_encoded_transfer_tests.rs'}
            if row['stage'] in ('workspace-clippy', 'workspace-tests'):
                expected |= {'shardloom-vortex/src/native_provider_varbin_metadata_tests.rs',
                             'shardloom-vortex/src/native_provider_varbin_construction_tests.rs'}
            else:
                assert row['stage'] == 'read-clippy'
            assert changed == expected
    cost = json.loads(common.COST.read_text())
    assert cost['status'] == 'retained_pending_broad_acceptance' and not cost['repeated_breaches']
    assert not cost['performance_claim_allowed']
    import varbin_metadata_cost_546 as lifecycle
    lifecycle.verify(json.loads(Path(cost['protocol']['path']).read_text()))
    for key in ('protocol', 'forward', 'reverse'):
        if cost[key] is not None:
            assert identity(cost[key]['path']) == cost[key]
    vendor = json.loads((OUT/'varbin-metadata-vendor-primary-verification-546.json').read_text())
    assert vendor['status'] == 'passed' and vendor['selected_sources_match_current']
    assert identity(vendor['aggregate']['path'])['sha256'] == vendor['aggregate']['sha256']
    assert unchanged() == frozen


def declare():
    prerequisites()
    manifest = load()
    prior = json.loads(common.PRIOR.read_text())
    direct = json.loads(common.PRIOR_DIRECT.read_text())
    assert prior['status'] == 'predeclared'
    assert direct['status'] == 'passed' and direct['tests'] == 100
    assert len(direct['test_names']) == len(set(direct['test_names'])) == 100
    sys.path[:0] = [str(ROOT/'python/src'), str(ROOT/'scripts')]
    from run_native_streaming_input_uat import FAMILIES
    families, names = prior['expected_public_families'], prior['expected_public_names']
    assert list(FAMILIES) == families and len(families) == 36
    assert len(names) == len(set(names)) == 4827
    assert identity(prior['baseline']['path']) == prior['baseline']
    helpers = [Path(__file__), Path(common.__file__), OUT/'freeze_native_release_298.py',
        OUT/'run_query_timing_runtime_461.py', OUT/'run_guarded.py',
        OUT/'run_varbin_metadata_remaining_546.py', OUT/'verify_varbin_metadata_public_546.py',
        OUT/'verify_stream_dynamic_subquery_public_522.py']
    save(PROTOCOL, dict(status='predeclared', native_engine_executions=0,
        source=identity(SOURCE), artifacts=identity(MANIFEST), helpers=[identity(p) for p in helpers],
        prior_protocol=identity(common.PRIOR), prior_direct=identity(common.PRIOR_DIRECT),
        expected_direct_tests=100, expected_direct_names=direct['test_names'],
        expected_public_names=names, expected_public_families=families,
        baseline=prior['baseline'], checks=identity(common.CHECKS), cost=identity(common.COST),
        vendor=identity(OUT/'varbin-metadata-vendor-acceptance-546.json'),
        vendor_primary_verification=identity(OUT/'varbin-metadata-vendor-primary-verification-546.json'),
        contract=identity(ROOT/'docs/architecture/native-varbin-metadata-resources-2026-10-16.md'),
        performance_claim=False, whole_process_memory_ceiling=False, installed_wheel_proof=False))
    assert load() == manifest
    print(json.dumps(dict(status='predeclared', direct_tests=100, public_cases=4827, families=36)))


def public():
    prerequisites()
    manifest, frozen = load(), protocol()
    direct = json.loads(common.DIRECT.read_text())
    assert direct['status'] == 'passed' and direct['tests'] == 100
    receipt(OUT/'varbin-metadata-direct-546.json')
    assert not PUBLIC.exists()
    families = frozen['expected_public_families']
    guarded('varbin-metadata-public-546', 7200,
        [sys.executable, '-B', ROOT/'scripts/run_native_streaming_input_uat.py',
         '--binary', manifest['cli']['path'], '--uat-root', PUBLIC, '--operation-timeout', '600',
         '--compress-logs', '--families', *families])
    receipt(OUT/'varbin-metadata-public-546.json')
    summary = json.loads((PUBLIC/'summary.json').read_text())
    assert summary['status'] == 'passed' and summary['families'] == families and summary['compress_logs']
    assert [row['name'] for row in summary['cases']] == frozen['expected_public_names']
    assert all(row['status'] == 'passed' for row in summary['cases'])
    assert load() == manifest and protocol() == frozen
    save(PUBLIC_ACCEPTANCE, dict(status='passed', cases=4827, families=families,
        manifest=identity(MANIFEST), source=identity(SOURCE), protocol=identity(PROTOCOL),
        summary=identity(PUBLIC/'summary.json'), direct=identity(common.DIRECT),
        source_identity_preserved=True, full43_pending=True))
    print(json.dumps(dict(status='passed', public_cases=4827, families=36)))


common.prerequisites = prerequisites
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('declare', 'direct', 'public'))
    args = parser.parse_args()
    {'declare': declare, 'direct': common.direct, 'public': public}[args.operation]()
