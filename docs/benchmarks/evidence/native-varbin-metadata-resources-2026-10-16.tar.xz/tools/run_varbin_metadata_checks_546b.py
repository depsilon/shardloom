"""Continue gates after native-only fixture lint corrections; retain prior default proof."""
import json
import re
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, save, sha, sources
from run_stream_destination_review_checks_479 import CHECKS
from run_varbin_metadata_checks_546 import identity


def main():
    source_path = OUT / 'native-release-source-varbinmetadata546b.json'
    frozen = json.loads(source_path.read_text())
    prior_path = OUT / 'varbin-metadata-checks-546.json'
    prior = json.loads(prior_path.read_text())
    old = json.loads((OUT / 'native-release-source-varbinmetadata546.json').read_text())
    assert set(old['source_sha256']) == set(frozen['source_sha256'])
    changed = {name for name in old['source_sha256']
               if old['source_sha256'][name] != frozen['source_sha256'][name]}
    assert changed == {'shardloom-vortex/src/native_provider_varbin_metadata_tests.rs',
                       'shardloom-vortex/src/native_provider_varbin_construction_tests.rs'}
    assert '#[cfg(feature = "vortex-local-primitives")]\nmod native_provider_memory;' in (ROOT/'shardloom-vortex/src/lib.rs').read_text()
    prior_protocol_path = OUT / 'varbin-metadata-check-protocol-546.json'
    prior_protocol = json.loads(prior_protocol_path.read_text())
    assert prior['protocol'] == identity(prior_protocol_path)
    completed = [row for row in prior['completed'] if row['stage'] in ('workspace-clippy', 'workspace-tests')]
    assert len(completed) == 2
    for row in completed:
        assert identity(row['receipt']['path']) == row['receipt']
        assert identity(row['log']['path']) == row['log']
        receipt = json.loads(open(row['receipt']['path']).read())
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['head'] == old['head'] and receipt['process_group_drained']
        row['reused_source'] = prior['source']
        row['reuse_reason'] = 'Only two tests beneath the unchanged vortex-local-primitives feature gate changed; default workspace compilation excludes that module.'
    checks = [row for row in CHECKS if row[0] not in ('workspace-clippy', 'workspace-tests')]
    protocol_path = OUT/'varbin-metadata-check-protocol-546b.json'
    save(protocol_path, dict(source=identity(source_path), helper=identity(__file__),
        original_helper=identity(OUT/'run_varbin_metadata_checks_546.py'), checks=checks,
        predecessor=identity(prior_path), predecessor_protocol=identity(prior_protocol_path),
        changed_native_test_sources=sorted(changed), expected_ignored=prior_protocol['expected_ignored'],
        required_tests=prior_protocol['required_tests']))
    failure = None
    try:
        for label, timeout, command in checks:
            assert sources() == frozen['source_sha256']
            name = 'varbin-metadata-' + label + '-546b'
            print(json.dumps(dict(stage=label, status='starting')), flush=True)
            subprocess.run([sys.executable, '-B', str(OUT/'run_guarded.py'),
                '--name', name, '--timeout', str(timeout), '--', *command], cwd=ROOT, check=True)
            path = OUT/(name+'.json')
            value, log = json.loads(path.read_text()), path.with_suffix('.log')
            assert value['status'] == 'passed' and value['returncode'] == 0
            assert value['process_group_drained'] and value['direct_child_reaped']
            assert not value['timed_out'] and not value['group_absence_unproved_at_cleanup']
            assert value['head'] == frozen['head'] and sha(log) == value['log_sha256']
            row = dict(stage=label, receipt=identity(path), log=identity(log))
            if label == 'native-tests':
                raw = log.read_text()
                groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', raw)
                assert groups and all(int(g[1]) == int(g[3]) == int(g[4]) == 0 for g in groups)
                ignored = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', raw, re.M)
                assert sum(int(g[2]) for g in groups) == len(ignored)
                assert sorted(ignored) == sorted(tuple(x) for x in prior_protocol['expected_ignored'])
                for test in prior_protocol['required_tests']:
                    assert re.search(r'^test .*::'+re.escape(test)+r' \.\.\. ok$', raw, re.M), test
                row['tests'] = dict(passed=sum(int(g[0]) for g in groups), failed=0,
                    ignored=len(ignored), groups=len(groups), ignored_declarations=ignored)
            completed.append(row)
            print(json.dumps(dict(stage=label, status='passed', passed=row.get('tests', {}).get('passed'))), flush=True)
        assert sources() == frozen['source_sha256']
        assert sorted(row['stage'] for row in completed) == sorted(row[0] for row in CHECKS)
    except BaseException as error:
        failure = type(error).__name__+': '+str(error)
        raise
    finally:
        save(OUT/'varbin-metadata-checks-546b.json', dict(status='passed' if failure is None else 'failed',
            failure=failure, source=identity(source_path), protocol=identity(protocol_path),
            completed=completed, source_identity_preserved=sources() == frozen['source_sha256']))


if __name__ == '__main__':
    main()
