//! Bounded typed intake into immutable, caller-owned native Vortex memory.
//!
//! Borrowed input is caller-owned. Native value/offset/validity buffers are
//! allocated through the session's reservation owner before publication. This
//! does not claim to account for caller storage, array metadata, all upstream
//! operator scratch, or process RSS. No file, answer cache, or external engine
//! participates in this source.

use std::sync::Arc;

use shardloom_core::{Result, ShardLoomError};
use shardloom_exec::live_memory::MemoryLease;
use vortex::{
    array::{
        ArrayRef, IntoArray as _, VortexSessionExecute as _,
        arrays::{BoolArray, PrimitiveArray, StructArray, VarBinArray},
        dtype::{DType, FieldNames, Nullability},
        memory::HostAllocatorRef,
        validity::Validity,
    },
    buffer::{Alignment, BitBuffer, Buffer, ByteBuffer},
    expr::{BoundExpression, Expression, root, select},
    mask::Mask,
};

use crate::local_primitives::collect::{
    CollectedVortexRows, memory_certificate, render_owned_json,
};
use crate::resident_session::{OwnedVortexResultBatch, ResidentVortexSession};

#[path = "resident_memory_owned_intake.rs"]
mod owned_intake;
pub use owned_intake::OwnedMemoryColumn;

#[path = "resident_memory_batches.rs"]
mod batches;
pub(crate) use batches::MAX_BATCH_ROWS;
pub use batches::MemoryBatchSourceBuilder;

#[path = "resident_memory_range.rs"]
mod generated_range;

#[path = "resident_memory_transfer_report.rs"]
mod transfer_report;
pub use transfer_report::NativeTransferReport;

#[cfg(feature = "vortex-write")]
#[path = "resident_memory_transfer.rs"]
mod transfer;

#[cfg(feature = "vortex-write")]
#[path = "resident_memory_encoded_transfer.rs"]
mod encoded_transfer;

#[cfg(feature = "vortex-write")]
#[path = "resident_memory_ipc.rs"]
mod ipc_intake;

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
#[path = "resident_memory_arrow.rs"]
mod arrow_intake;

/// Explicit typed input. Slices are borrowed only for intake;
/// published Vortex buffers retain no references into caller memory.
#[derive(Clone, Copy)]
pub enum MemoryColumnValues<'a> {
    Int64(&'a [Option<i64>]),
    /// Nonnullable native Int64 values, with no validity bitmap or Option input.
    Int64NonNullable(&'a [i64]),
    Float64(&'a [Option<f64>]),
    Bool(&'a [Option<bool>]),
    Utf8(&'a [Option<&'a str>]),
    /// Exact scalar or nested values in the pinned native DType/JSON transport.
    /// This closed conversion boundary validates and copies into owned buffers;
    /// it never accepts an arbitrary externally allocated native array.
    TypedJson {
        dtype_json: &'a str,
        values: &'a [Option<&'a str>],
    },
}

/// A named typed column in one immutable snapshot.
#[derive(Clone, Copy)]
pub struct MemoryColumn<'a> {
    pub name: &'a str,
    pub values: MemoryColumnValues<'a>,
}

/// Hard input and result bounds for this admitted native source.
#[derive(Debug, Clone, Copy)]
pub struct MemorySourceBounds {
    pub max_input_rows: usize,
    pub max_input_bytes: usize,
    pub max_output_rows: usize,
    pub max_output_bytes: usize,
}

impl Default for MemorySourceBounds {
    fn default() -> Self {
        Self {
            max_input_rows: 65_536,
            max_input_bytes: 32 * 1024 * 1024,
            max_output_rows: 65_536,
            max_output_bytes: 32 * 1024 * 1024,
        }
    }
}

struct MemorySourceOwner {
    array: ArrayRef,
    session: ResidentVortexSession,
    bounds: MemorySourceBounds,
    input_logical_bytes: usize,
    intake_payload_bytes_copied: u64,
    intake_columnar_buffer_bytes_copied: u64,
    transfer_report: NativeTransferReport,
    // Every copied/transferred payload buffer also holds this credit, including
    // cloned/sliced child buffers. Generated ranges have their own compact owner.
    metadata: Option<Arc<MemoryLease>>,
    is_batch: bool,
    generated_range: Option<generated_range::GeneratedInt64Range>,
}

/// Validated immutable native memory, visible without durable publication.
#[derive(Clone)]
pub struct ResidentMemorySource(Arc<MemorySourceOwner>);

impl ResidentMemorySource {
    /// Retain a completed native result as input to further native operations.
    /// Its buffers and session grant remain shared; no rows, JSON or temporary
    /// file are constructed. Growing composition metadata uses that same grant.
    /// # Errors
    /// Rejects inconsistent completed results, cancellation and memory denial.
    #[cfg(feature = "vortex-write")]
    pub fn from_completed_result(
        result: &OwnedVortexResultBatch,
        cancellation: &shardloom_exec::compute_pool::CancellationToken,
    ) -> Result<Self> {
        let mut builder =
            MemoryBatchSourceBuilder::new(&result.retained_session(), cancellation.clone())?;
        builder.push_native_result(result)?;
        builder.finish()
    }

    /// Construct compact native signed-range input under the session's grant.
    /// The relational engine generates only each admitted scan interval; whole
    /// array projection remains an explicitly materializing operation.
    /// # Errors
    /// Rejects invalid names, zero steps, endpoint/logical-byte overflow and
    /// shared-memory admission failures before publishing the source.
    pub fn from_int64_range(
        session: &ResidentVortexSession,
        name: &str,
        start: i64,
        step: i64,
        rows: usize,
    ) -> Result<Self> {
        generated_range::source(session, name, start, step, rows)
    }

    pub(crate) fn belongs_to_session(&self, session: &ResidentVortexSession) -> bool {
        self.0.session.same_owner(session)
    }

    /// Transfer private, capacity-admitted native columns into one immutable
    /// source. Payload buffers remain shared with their original allocation
    /// credits; this never accepts arbitrary externally allocated `ArrayRef` values.
    ///
    /// # Errors
    /// Rejects foreign budgets, invalid names/lengths and source bounds.
    pub fn from_owned_columns(
        session: &ResidentVortexSession,
        columns: Vec<OwnedMemoryColumn>,
        bounds: MemorySourceBounds,
    ) -> Result<Self> {
        if columns.is_empty()
            || bounds.max_input_rows == 0
            || bounds.max_input_rows > 65_536
            || bounds.max_output_rows == 0
            || bounds.max_output_rows > 65_536
            || bounds.max_input_bytes == 0
            || bounds.max_output_bytes == 0
        {
            return Err(memory_error(
                "owned memory intake requires columns and positive bounds up to 65,536 rows",
            ));
        }
        let rows = columns[0].array.len();
        let mut input_logical_bytes = 0usize;
        for column in &columns {
            if !session.memory().owns(&column.identity) {
                return Err(memory_error(
                    "owned column belongs to a different shared memory budget",
                ));
            }
            if column.array.len() != rows || rows > bounds.max_input_rows {
                return Err(memory_error(
                    "owned column lengths disagree or exceed the input row bound",
                ));
            }
            input_logical_bytes = input_logical_bytes
                .checked_add(usize::try_from(column.array.nbytes()).map_err(native_error)?)
                .and_then(|bytes| bytes.checked_add(column.name.len()))
                .filter(|bytes| *bytes <= bounds.max_input_bytes)
                .ok_or_else(|| memory_error("owned input byte bound exceeded"))?;
        }
        let metadata = Arc::new(crate::native_payload_schema::reserve_names(
            session.memory(),
            columns.len(),
            |index| columns[index].name.as_str(),
        )?);
        let names = FieldNames::from(
            columns
                .iter()
                .map(|column| column.name.as_str())
                .collect::<Vec<_>>(),
        );
        let fields = columns
            .into_iter()
            .map(|column| owned_intake::retain_metadata(&column.array, &metadata))
            .collect::<Result<Vec<_>>>()?;
        let array = StructArray::try_new(names, fields, rows, Validity::NonNullable)
            .map_err(native_error)?
            .into_array();
        Ok(Self(Arc::new(MemorySourceOwner {
            array,
            session: session.clone(),
            bounds,
            input_logical_bytes,
            intake_payload_bytes_copied: 0,
            intake_columnar_buffer_bytes_copied: 0,
            transfer_report: NativeTransferReport::default(),
            metadata: Some(metadata),
            is_batch: false,
            generated_range: None,
        })))
    }

    /// Validate all input sizes and values before allocating native buffers.
    /// Caller-owned input bytes are copied once into session-owned native arrays.
    ///
    /// # Errors
    /// Rejects duplicate/empty names, mismatched column lengths, nonfinite
    /// floats and input/shared-memory bound violations. Schema width consumes
    /// the same shared grant as the native payload buffers.
    pub fn from_columns(
        session: &ResidentVortexSession,
        columns: &[MemoryColumn<'_>],
        bounds: MemorySourceBounds,
    ) -> Result<Self> {
        Self::copy_columns(session, columns, bounds, false)
    }

    fn copy_columns(
        session: &ResidentVortexSession,
        columns: &[MemoryColumn<'_>],
        bounds: MemorySourceBounds,
        is_batch: bool,
    ) -> Result<Self> {
        let (_, input_logical_bytes) = validate_columns(columns, bounds)?;
        let metadata = Arc::new(crate::native_payload_schema::reserve_names(
            session.memory(),
            columns.len(),
            |index| columns[index].name,
        )?);
        let allocator = crate::owned_buffers::with_shared_credit(
            session.native_allocator(),
            Arc::clone(&metadata),
        );
        Self::build_columns(
            session,
            columns,
            bounds,
            input_logical_bytes,
            &allocator,
            metadata,
            is_batch,
        )
    }

    /// Copy one private, finite batch for completion-aware native input. The
    /// structural reservation follows every buffer alias until it is released.
    /// A typed empty batch may declare the schema before opening a producer.
    /// # Errors
    /// Rejects more than 2,048 rows or 32 MiB of logical input,
    /// invalid scalar values and shared-memory admission failures.
    pub fn from_batch_columns(
        session: &ResidentVortexSession,
        columns: &[MemoryColumn<'_>],
    ) -> Result<Self> {
        let bounds = MemorySourceBounds {
            max_input_rows: MAX_BATCH_ROWS,
            ..MemorySourceBounds::default()
        };
        Self::copy_columns(session, columns, bounds, true)
    }

    fn build_columns(
        session: &ResidentVortexSession,
        columns: &[MemoryColumn<'_>],
        bounds: MemorySourceBounds,
        mut input_logical_bytes: usize,
        allocator: &HostAllocatorRef,
        metadata: Arc<MemoryLease>,
        is_batch: bool,
    ) -> Result<Self> {
        let rows = columns[0].values.len();
        let mut intake_payload_bytes_copied = 0_u64;
        let fields = columns
            .iter()
            .map(|column| {
                if let MemoryColumnValues::TypedJson { dtype_json, values } = column.values {
                    let built = crate::local_primitives::native_typed_input::build(
                        dtype_json,
                        values,
                        session.memory(),
                        allocator,
                        bounds.max_input_bytes - input_logical_bytes,
                    )?;
                    input_logical_bytes = input_logical_bytes
                        .checked_add(built.logical_bytes)
                        .ok_or_else(|| memory_error("typed input byte count overflow"))?;
                    intake_payload_bytes_copied = intake_payload_bytes_copied
                        .checked_add(built.copied_payload_bytes)
                        .ok_or_else(|| memory_error("typed input copy count overflow"))?;
                    Ok(built.array)
                } else {
                    build_column(column.values, allocator, &mut intake_payload_bytes_copied)
                }
            })
            .collect::<Result<Vec<_>>>()?;
        let names = FieldNames::from(columns.iter().map(|column| column.name).collect::<Vec<_>>());
        let array = StructArray::try_new(names, fields, rows, Validity::NonNullable)
            .map_err(native_error)?
            .into_array();
        Ok(Self(Arc::new(MemorySourceOwner {
            array,
            session: session.clone(),
            bounds,
            input_logical_bytes,
            intake_payload_bytes_copied,
            intake_columnar_buffer_bytes_copied: 0,
            transfer_report: NativeTransferReport::default(),
            metadata: Some(metadata),
            is_batch,
            generated_range: None,
        })))
    }

    pub(crate) fn is_batch_source(&self) -> bool {
        self.0.is_batch
    }

    pub(crate) fn batch_array(
        &self,
        context: &crate::resident_session::NativeExecutionContext<'_>,
    ) -> Result<&ArrayRef> {
        self.0.session.validate_execution_context(context)?;
        if !self.0.is_batch {
            return Err(memory_error(
                "SL-NATIVE-BATCH: input requires a private batch source",
            ));
        }
        context.check_cancelled()?;
        Ok(&self.0.array)
    }

    pub(crate) fn batch_release_witness(&self) -> Result<std::sync::Weak<MemoryLease>> {
        if !self.0.is_batch || Arc::strong_count(&self.0) != 1 {
            return Err(memory_error(
                "SL-NATIVE-BATCH: input batch must transfer private ownership",
            ));
        }
        self.0.metadata.as_ref().map(Arc::downgrade).ok_or_else(|| {
            memory_error("SL-NATIVE-BATCH: streaming input requires from_batch_columns ownership")
        })
    }

    #[must_use]
    pub fn row_count(&self) -> usize {
        self.0.array.len()
    }

    #[must_use]
    pub fn dtype(&self) -> &DType {
        self.0.array.dtype()
    }

    /// Return authoritative schema metadata without traversing input values.
    /// The returned text retains a reservation on this source's memory owner.
    /// # Errors
    /// Rejects unsupported metadata or shared-memory admission failure.
    pub fn schema_json(&self) -> Result<shardloom_exec::live_memory::Budgeted<String>> {
        crate::local_primitives::collect::serialize_result_schema(
            self.dtype(),
            &self.0.session.shared_memory_pool(),
        )
    }

    #[must_use]
    pub fn input_logical_bytes(&self) -> usize {
        self.0.input_logical_bytes
    }

    /// Numeric value and UTF8 payload bytes copied by typed intake. Bitmap,
    /// offset and field-name construction are excluded from this counter.
    #[must_use]
    pub fn intake_payload_bytes_copied(&self) -> u64 {
        self.0.intake_payload_bytes_copied
    }

    /// Columnar bytes copied by direct Arrow intake or native owner transfer,
    /// including validity, offsets and referenced child buffers. Original
    /// producer capacity and allocation alignment headroom are excluded.
    /// Same-owner native-result composition copies none.
    #[must_use]
    pub fn intake_columnar_buffer_bytes_copied(&self) -> u64 {
        self.0.intake_columnar_buffer_bytes_copied
    }

    /// Immutable evidence from this source's successful intake. Later execution
    /// has its own certificate and does not update this receipt.
    #[must_use]
    pub fn intake_transfer_report(&self) -> NativeTransferReport {
        self.0.transfer_report
    }

    /// Build an immutable native file layout over owned memory segments. This
    /// explicitly serializes the native arrays once; ordinary tiny queries need
    /// not choose this boundary. Durable publication reuses these exact segments.
    ///
    /// # Errors
    /// Rejects serialized byte/metadata or shared-memory bounds before exposing
    /// a generation, and reports unsupported provider representations explicitly.
    #[cfg(feature = "vortex-write")]
    pub fn file_generation(
        &self,
        bounds: crate::memory_file_generation::MemoryFileGenerationBounds,
    ) -> Result<crate::memory_file_generation::MemoryFileGeneration> {
        let array = self.generation_array(None)?;
        crate::memory_file_generation::MemoryFileGeneration::build(
            &self.0.session,
            &array,
            self.0.input_logical_bytes,
            self.0.intake_payload_bytes_copied,
            bounds,
        )
    }

    /// Explicitly choose native column/row-group geometry. Cancellation is
    /// checked before intake serialization, between each leaf, and before
    /// publication in memory; an in-progress leaf completes synchronously.
    /// Ordinary array queries do not pass through this boundary.
    ///
    /// # Errors
    /// Rejects geometry/byte limits, cancellation and native serialization errors.
    #[cfg(feature = "vortex-write")]
    pub fn file_generation_with_layout(
        &self,
        bounds: crate::memory_file_generation::MemoryFileGenerationBounds,
        layout: crate::memory_file_generation::MemoryFileGenerationLayout,
        cancelled: Option<&std::sync::atomic::AtomicBool>,
    ) -> Result<crate::memory_file_generation::MemoryFileGeneration> {
        let array = self.generation_array(cancelled)?;
        crate::memory_file_generation::MemoryFileGeneration::build_with_layout(
            &self.0.session,
            &array,
            self.0.input_logical_bytes,
            self.0.intake_payload_bytes_copied,
            bounds,
            layout,
            cancelled,
        )
    }

    fn array_range(
        &self,
        range: std::ops::Range<usize>,
        check: &dyn Fn() -> Result<()>,
    ) -> Result<ArrayRef> {
        check()?;
        match &self.0.generated_range {
            Some(generated) => generated.materialize(&self.0, range, check),
            None => self.0.array.slice(range).map_err(native_error),
        }
    }

    #[cfg(feature = "vortex-write")]
    fn generation_array(
        &self,
        cancelled: Option<&std::sync::atomic::AtomicBool>,
    ) -> Result<ArrayRef> {
        if self.0.generated_range.is_none() {
            return Ok(self.0.array.clone());
        }
        // This separate whole-memory generation API has an explicit intake
        // bound. Public relational writers consume the bounded range scanner.
        if self.row_count() > crate::memory_file_generation::GENERATION_INPUT_ROWS {
            return Err(memory_error(
                "memory file generation exceeds its admitted input rows",
            ));
        }
        self.array_range(0..self.row_count(), &|| {
            if cancelled.is_some_and(|flag| flag.load(std::sync::atomic::Ordering::Acquire)) {
                Err(memory_error("memory range generation cancelled"))
            } else {
                Ok(())
            }
        })
    }

    /// Bind a native projection and optional exact Vortex expression. This is
    /// an internal Rust provider boundary; public adapters lower their admitted
    /// predicates before reaching it. A limit preserves input order after filtering.
    ///
    /// # Errors
    /// Rejects missing/duplicate fields, invalid/nonboolean filters, and limits
    /// beyond the source's admitted result bound.
    pub fn prepare_projection(
        &self,
        columns: &[&str],
        filter: Option<Expression>,
        limit: Option<usize>,
    ) -> Result<PreparedMemoryProjection> {
        let metadata = crate::native_payload_schema::reserve_names(
            self.0.session.memory(),
            columns.len(),
            |index| columns[index],
        )?;
        if limit.is_some_and(|limit| limit > self.0.bounds.max_output_rows) {
            return Err(memory_error(
                "requested row limit exceeds admitted output bound",
            ));
        }
        let projection = select(columns.to_vec(), root())
            .bind(self.dtype())
            .map_err(native_error)?;
        let filter = filter
            .map(|filter| {
                filter
                    .optimize_recursive(self.dtype())
                    .and_then(|filter| filter.bind(self.dtype()))
                    .map_err(native_error)
            })
            .transpose()?;
        if filter
            .as_ref()
            .is_some_and(|filter| !matches!(filter.dtype(), DType::Bool(_)))
        {
            return Err(memory_error("memory filter must return a boolean value"));
        }
        Ok(PreparedMemoryProjection {
            source: self.clone(),
            projection,
            filter,
            limit,
            columns: columns.iter().map(|name| (*name).to_owned()).collect(),
            _metadata: metadata,
        })
    }
}

/// Bound exact native operations over one immutable memory snapshot.
pub struct PreparedMemoryProjection {
    source: ResidentMemorySource,
    projection: BoundExpression,
    filter: Option<BoundExpression>,
    limit: Option<usize>,
    columns: Vec<String>,
    _metadata: MemoryLease,
}

impl PreparedMemoryProjection {
    pub(crate) fn source_rows(&self) -> usize {
        self.source.row_count()
    }

    /// Borrow the caller's existing admission; never reenter session execution.
    pub(crate) fn execute_range(
        &self,
        range: std::ops::Range<usize>,
        context: &crate::resident_session::NativeExecutionContext<'_>,
    ) -> Result<ArrayRef> {
        self.source.0.session.validate_execution_context(context)?;
        let array = self
            .source
            .array_range(range, &|| context.check_cancelled())?;
        let result = self.execute_array(array, context.native_session())?;
        context.check_cancelled()?;
        Ok(result)
    }

    /// Reuse the schema-bound projection over a bounded range of the current
    /// input or replay array. The caller holds its credited native owner until
    /// consumption ends; the schema source verifies the execution's grant.
    pub(crate) fn execute_batch_array(
        &self,
        source: &ArrayRef,
        range: std::ops::Range<usize>,
        context: &crate::resident_session::NativeExecutionContext<'_>,
    ) -> Result<ArrayRef> {
        self.source.0.session.validate_execution_context(context)?;
        if source.dtype() != self.source.dtype() {
            return Err(memory_error(
                "SL-NATIVE-BATCH: input changed its declared schema or resource owner",
            ));
        }
        context.check_cancelled()?;
        let array = source.slice(range).map_err(native_error)?;
        let result = self.execute_array(array, context.native_session())?;
        context.check_cancelled()?;
        Ok(result)
    }

    #[must_use]
    pub fn projected_columns(&self) -> &[String] {
        &self.columns
    }

    /// Complete native filter/project/limit execution and retain owned arrays.
    ///
    /// # Errors
    /// Rejects native provider errors and result/shared-memory bound violations.
    pub fn execute_arrays(&self) -> Result<OwnedVortexResultBatch> {
        let source = &self.source.0;
        source.session.execute_owned_array(
            source.bounds.max_output_rows as u64,
            source.bounds.max_output_bytes as u64,
            |session| {
                let rows = if self.filter.is_none() {
                    self.limit
                        .unwrap_or(self.source.row_count())
                        .min(self.source.row_count())
                } else {
                    self.source.row_count()
                };
                let array = self.source.array_range(0..rows, &|| Ok(()))?;
                self.execute_array(array, session)
            },
        )
    }

    fn execute_array(
        &self,
        mut array: ArrayRef,
        session: &vortex::session::VortexSession,
    ) -> Result<ArrayRef> {
        let source = &self.source.0;
        let metadata = Arc::new(crate::native_payload_schema::reserve_names(
            source.session.memory(),
            self.columns.len(),
            |index| self.columns[index].as_str(),
        )?);
        let mut context = session.create_execution_ctx();
        if let Some(filter) = &self.filter {
            let predicate = array
                .clone()
                .apply_bound(filter)
                .map_err(native_error)?
                .execute::<BoolArray>(&mut context)
                .map_err(native_error)?;
            let allocator = source.session.native_allocator();
            // The final mask has a session-owned buffer. Null predicate
            // values are false, matching WHERE semantics. Evaluation is
            // still the provider's bound expression, not a row evaluator.
            let mut bits = allocator
                .allocate(array.len().div_ceil(8), Alignment::none())
                .map_err(native_error)?;
            bits.as_mut_slice().fill(0);
            for row in 0..array.len() {
                if predicate
                    .execute_scalar(row, &mut context)
                    .map_err(native_error)?
                    .as_bool()
                    .value()
                    .unwrap_or(false)
                {
                    bits.as_mut_slice()[row / 8] |= 1 << (row % 8);
                }
            }
            array = array
                .filter(Mask::from_buffer(BitBuffer::new(
                    bits.freeze(),
                    array.len(),
                )))
                .map_err(native_error)?;
        }
        if let Some(limit) = self.limit {
            array = array
                .slice(0..limit.min(array.len()))
                .map_err(native_error)?;
        }
        let result = array
            .apply_bound(&self.projection)
            .and_then(|array| array.execute::<StructArray>(&mut context))
            .map_err(native_error)?;
        // One native chunk per selected field anchors the new record metadata
        // without copying or traversing a retained multi-batch payload tree.
        let fields = result.dtype().as_struct_fields();
        let columns = result
            .slots()
            .iter()
            .skip(1)
            .map(|column| {
                let column = column
                    .as_ref()
                    .ok_or_else(|| memory_error("projection omitted a native field"))?;
                batches::owned_chunks(
                    [column.clone()].into_iter(),
                    column.dtype().clone(),
                    &metadata,
                )
            })
            .collect::<Result<Vec<_>>>()?;
        StructArray::try_new(
            fields.names().clone(),
            columns,
            result.len(),
            Validity::NonNullable,
        )
        .map(vortex::array::IntoArray::into_array)
        .map_err(native_error)
    }

    /// Complete the bounded native operation and its explicitly requested JSON
    /// materialization. The result retains its output reservation independently
    /// of the source. This publishes no durable file and caches no answer.
    ///
    /// # Errors
    /// Rejects provider, row, native-byte, JSON-byte, and shared-memory violations.
    pub fn execute(&self) -> Result<CollectedVortexRows> {
        let result = self.execute_arrays()?;
        let source = &self.source.0;
        let values_json = render_owned_json(
            &result,
            &self.columns,
            source.session.memory(),
            source.bounds.max_output_bytes,
        )?;
        let rows = result.row_count();
        let result_schema_json = crate::local_primitives::collect::serialize_result_schema(
            result.dtype(),
            source.session.memory(),
        )?;
        let native_io_certificate = memory_certificate(rows, self.filter.is_some())?;
        drop(result);
        Ok(CollectedVortexRows {
            timing: None,
            rows,
            projected_columns: self.columns.clone(),
            source_order_limit: self.limit,
            values_json,
            result_schema_json,
            runtime: source.session.snapshot(),
            native_io_certificate,
        })
    }
}

impl MemoryColumnValues<'_> {
    fn len(self) -> usize {
        match self {
            Self::Int64(values) => values.len(),
            Self::Int64NonNullable(values) => values.len(),
            Self::Float64(values) => values.len(),
            Self::Bool(values) => values.len(),
            Self::Utf8(values) | Self::TypedJson { values, .. } => values.len(),
        }
    }

    fn present(self, row: usize) -> bool {
        match self {
            Self::Int64(values) => values[row].is_some(),
            Self::Int64NonNullable(_) => true,
            Self::Float64(values) => values[row].is_some(),
            Self::Bool(values) => values[row].is_some(),
            Self::Utf8(values) | Self::TypedJson { values, .. } => values[row].is_some(),
        }
    }
}

fn validate_columns(
    columns: &[MemoryColumn<'_>],
    bounds: MemorySourceBounds,
) -> Result<(usize, usize)> {
    if columns.is_empty()
        || bounds.max_input_rows > 65_536
        || bounds.max_output_rows > 65_536
        || bounds.max_input_rows == 0
        || bounds.max_output_rows == 0
        || bounds.max_input_bytes == 0
        || bounds.max_output_bytes == 0
    {
        return Err(memory_error(
            "memory intake requires columns and positive bounds up to 65,536 rows",
        ));
    }
    let rows = columns[0].values.len();
    if rows > bounds.max_input_rows {
        return Err(memory_error("input row bound exceeded"));
    }
    let mut bytes = 0_usize;
    let mut typed_json_bytes = 0_usize;
    for column in columns {
        if column.name.is_empty() || column.name.len() > 256 {
            return Err(memory_error(
                "column names must be distinct and contain 1..=256 UTF8 bytes",
            ));
        }
        if column.values.len() != rows {
            return Err(memory_error("typed memory column lengths disagree"));
        }
        let value_bytes = match column.values {
            MemoryColumnValues::Int64(_) | MemoryColumnValues::Int64NonNullable(_) => {
                rows.checked_mul(8)
            }
            MemoryColumnValues::Float64(values) => {
                if values.iter().flatten().any(|value| !value.is_finite()) {
                    return Err(memory_error(
                        "nonfinite float64 is not admitted by bounded JSON output",
                    ));
                }
                rows.checked_mul(8)
            }
            MemoryColumnValues::Bool(_) => Some(rows.div_ceil(8)),
            MemoryColumnValues::Utf8(values) => values.iter().flatten().fold(
                rows.checked_add(1).and_then(|rows| rows.checked_mul(8)),
                |total, value| total.and_then(|total| total.checked_add(value.len())),
            ),
            MemoryColumnValues::TypedJson { dtype_json, values } => {
                if dtype_json.len() > 8 * 1024 * 1024 {
                    return Err(memory_error("typed input schema exceeds 8 MiB"));
                }
                for value in values {
                    typed_json_bytes = typed_json_bytes
                        .checked_add(value.map_or(4, str::len))
                        .filter(|bytes| *bytes <= bounds.max_input_bytes)
                        .ok_or_else(|| memory_error("typed input JSON byte bound exceeded"))?;
                }
                // Exact native bytes are preflighted after admitted JSON parsing,
                // before any native payload construction.
                Some(0)
            }
        }
        .ok_or_else(|| memory_error("typed memory byte count overflow"))?;
        let validity_bytes = if matches!(
            column.values,
            MemoryColumnValues::Int64NonNullable(_) | MemoryColumnValues::TypedJson { .. }
        ) {
            0
        } else {
            rows.div_ceil(8)
        };
        bytes = bytes
            .checked_add(value_bytes)
            .and_then(|bytes| bytes.checked_add(validity_bytes))
            .and_then(|bytes| bytes.checked_add(column.name.len()))
            .ok_or_else(|| memory_error("typed memory byte count overflow"))?;
        if bytes > bounds.max_input_bytes {
            return Err(memory_error("input byte bound exceeded"));
        }
    }
    Ok((rows, bytes))
}

fn packed_bits(
    allocator: &HostAllocatorRef,
    len: usize,
    value: impl Fn(usize) -> bool,
) -> Result<BitBuffer> {
    let mut bytes = allocator
        .allocate(len.div_ceil(8), Alignment::none())
        .map_err(native_error)?;
    bytes.as_mut_slice().fill(0);
    for row in 0..len {
        if value(row) {
            bytes.as_mut_slice()[row / 8] |= 1 << (row % 8);
        }
    }
    Ok(BitBuffer::new(bytes.freeze(), len))
}

fn fixed_bytes(
    allocator: &HostAllocatorRef,
    len: usize,
    value: impl Fn(usize) -> Result<[u8; 8]>,
) -> Result<ByteBuffer> {
    let bytes = len
        .checked_mul(8)
        .ok_or_else(|| memory_error("native buffer length overflow"))?;
    let mut bytes = allocator
        .allocate(bytes, Alignment::new(8))
        .map_err(native_error)?;
    for row in 0..len {
        bytes.as_mut_slice()[row * 8..row * 8 + 8].copy_from_slice(&value(row)?);
    }
    Ok(bytes.freeze())
}

fn column_validity(
    values: MemoryColumnValues<'_>,
    allocator: &HostAllocatorRef,
) -> Result<Validity> {
    let rows = values.len();
    Ok(
        if matches!(values, MemoryColumnValues::Int64NonNullable(_)) {
            Validity::NonNullable
        } else if (0..rows).all(|row| values.present(row)) {
            Validity::AllValid
        } else if (0..rows).all(|row| !values.present(row)) {
            Validity::AllInvalid
        } else {
            Validity::Array(
                crate::owned_buffers::bool_array_with_retained_buffer(
                    packed_bits(allocator, rows, |row| values.present(row))?,
                    Validity::NonNullable,
                )
                .map_err(native_error)?
                .into_array(),
            )
        },
    )
}

fn build_column(
    values: MemoryColumnValues<'_>,
    allocator: &HostAllocatorRef,
    payload_bytes_copied: &mut u64,
) -> Result<ArrayRef> {
    let rows = values.len();
    // Count actual payload copy_from_slice bytes below. Bitmap and offset
    // construction, names, and provider-internal work are distinct exclusions.
    *payload_bytes_copied += match values {
        MemoryColumnValues::Int64(_)
        | MemoryColumnValues::Int64NonNullable(_)
        | MemoryColumnValues::Float64(_) => (rows * 8) as u64,
        MemoryColumnValues::Utf8(values) => values
            .iter()
            .flatten()
            .map(|value| value.len() as u64)
            .sum(),
        MemoryColumnValues::Bool(_) => 0,
        MemoryColumnValues::TypedJson { .. } => {
            return Err(memory_error(
                "typed JSON input requires its admitted conversion builder",
            ));
        }
    };
    let validity = column_validity(values, allocator)?;
    match values {
        MemoryColumnValues::Int64NonNullable(values) => Ok(PrimitiveArray::new(
            Buffer::<i64>::from_byte_buffer(fixed_bytes(allocator, rows, |row| {
                Ok(values[row].to_ne_bytes())
            })?),
            validity,
        )
        .into_array()),
        MemoryColumnValues::Int64(values) => Ok(PrimitiveArray::new(
            Buffer::<i64>::from_byte_buffer(fixed_bytes(allocator, rows, |row| {
                Ok(values[row].unwrap_or_default().to_ne_bytes())
            })?),
            validity,
        )
        .into_array()),
        MemoryColumnValues::Float64(values) => Ok(PrimitiveArray::new(
            Buffer::<f64>::from_byte_buffer(fixed_bytes(allocator, rows, |row| {
                Ok(values[row].unwrap_or_default().to_ne_bytes())
            })?),
            validity,
        )
        .into_array()),
        MemoryColumnValues::Bool(values) => {
            Ok(crate::owned_buffers::bool_array_with_retained_buffer(
                packed_bits(allocator, rows, |row| values[row].unwrap_or_default())?,
                validity,
            )
            .map_err(native_error)?
            .into_array())
        }
        MemoryColumnValues::Utf8(values) => {
            let total = values.iter().flatten().map(|value| value.len()).sum();
            let mut bytes = allocator
                .allocate(total, Alignment::none())
                .map_err(native_error)?;
            let mut offsets = allocator
                .allocate((rows + 1) * 8, Alignment::new(8))
                .map_err(native_error)?;
            offsets.as_mut_slice()[..8].copy_from_slice(&0_u64.to_ne_bytes());
            let mut offset = 0;
            for (row, value) in values.iter().enumerate() {
                let value = value.unwrap_or_default().as_bytes();
                bytes.as_mut_slice()[offset..offset + value.len()].copy_from_slice(value);
                offset += value.len();
                offsets.as_mut_slice()[(row + 1) * 8..(row + 2) * 8]
                    .copy_from_slice(&(offset as u64).to_ne_bytes());
            }
            let offsets = PrimitiveArray::new(
                Buffer::<u64>::from_byte_buffer(offsets.freeze()),
                Validity::NonNullable,
            )
            .into_array();
            VarBinArray::try_new(
                offsets,
                bytes.freeze(),
                DType::Utf8(Nullability::Nullable),
                validity,
            )
            .map(vortex::array::IntoArray::into_array)
            .map_err(native_error)
        }
        MemoryColumnValues::TypedJson { .. } => Err(memory_error(
            "typed JSON input requires its admitted conversion builder",
        )),
    }
}

fn memory_error(message: &str) -> ShardLoomError {
    ShardLoomError::InvalidOperation(format!("{message}; no fallback execution was attempted"))
}

fn native_error(error: impl std::fmt::Display) -> ShardLoomError {
    memory_error(&error.to_string())
}

#[cfg(test)]
#[path = "resident_memory_source_tests.rs"]
mod tests;

#[cfg(test)]
#[path = "resident_memory_typed_tests.rs"]
mod typed_tests;
