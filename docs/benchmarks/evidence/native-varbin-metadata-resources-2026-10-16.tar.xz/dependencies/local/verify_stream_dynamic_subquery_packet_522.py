"""Independent complete-member and semantic audit of finite subquery acceptance."""
from __future__ import annotations

import gzip
import hashlib
import json
import lzma
from pathlib import Path
import re
import tarfile

from verify_stream_unary_packet_497 import (
    NeedsReasoning, need, digest, strict_json, safe_member, canonical_hash, report_fields,
    verify_compressed_tree, verify_full43,
)

REPO = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
DEST = REPO / 'docs/benchmarks/evidence'
STEM = 'native-stream-dynamic-subqueries-2026-10-16'
BASE = 'c30846afb0ab5abfff6fdb5d95ed20f1c10a9477'
EXPECTED_PUBLIC_CASES = 4827
EXPECTED_PUBLIC_FAMILIES = 36
EXPECTED_DECLARED_VALUES_SHA256 = 'd6f5b2fa6f66f69731bfebae38ac6dce6bbbd119f7607feb975676b143f0db4a'
OUTPUT = OUT / 'stream-dynamic-subquery-packet-audit-523.json'

def verify_public(members: dict[str, bytes], receipt_log: bytes,
                  expected_case_protocol: dict) -> dict:
    summary = strict_json(members['public/summary.json'])
    need(summary.get('status') == 'passed' and summary.get('compress_logs') is True,
         'public summary must pass and declare compressed logs')
    cases = summary.get('cases')
    need(isinstance(cases, list) and len(cases) == EXPECTED_PUBLIC_CASES,
         'public summary must contain exactly 4,827 cases')
    names = [case.get('name') for case in cases]
    need(len(set(names)) == EXPECTED_PUBLIC_CASES and
         names == expected_case_protocol.get('expected_public_names'),
         'ordered public names differ from the full predeclared case protocol')
    families = summary.get('families')
    need(len(families) == EXPECTED_PUBLIC_FAMILIES and
         families == expected_case_protocol.get('expected_public_families') and
         all(case.get('status') == 'passed' for case in cases),
         'public families or case outcomes differ from the accepted protocol')
    logged = [strict_json(line) for line in receipt_log.decode('utf-8').splitlines()
              if line.startswith('{')]
    need([row for row in logged if 'name' in row] == cases,
         'public process log does not contain the complete ordered case records')

    metadata = summary.get('compressed_json_files')
    need(isinstance(metadata, list), 'public compressed JSON metadata is missing')
    declared, logical, compressed_meta = set(), {}, {}
    for row in metadata:
        need(isinstance(row, dict), 'invalid compressed JSON metadata row')
        rel, raw_rel = row.get('path'), row.get('raw_path')
        need(isinstance(rel, str) and rel.startswith('logs/') and
             rel.endswith('.json.gz') and not rel.endswith('.jsonl.gz'),
             f'wrong compressed JSON path: {rel!r}')
        safe_member(rel)
        need(rel not in declared and raw_rel == rel[:-3] and raw_rel.endswith('.json'),
             f'duplicate or mismatched compressed JSON path: {rel}')
        declared.add(rel)
        packed_key = 'public/' + rel
        need(packed_key in members, f'compressed public JSON log is absent: {packed_key}')
        packed = members[packed_key]
        need(len(packed) == row.get('bytes') and digest(packed) == row.get('sha256'),
             f'compressed public JSON identity mismatch: {rel}')
        try:
            raw = gzip.decompress(packed)
        except (OSError, EOFError) as exc:
            raise NeedsReasoning(f'invalid compressed public JSON {rel}: {exc}') from exc
        need(len(raw) == row.get('raw_bytes') and digest(raw) == row.get('raw_sha256'),
             f'decompressed public JSON identity mismatch: {rel}')
        value = strict_json(raw.decode('utf-8'))
        need(raw_rel not in logical, f'duplicate logical JSON path: {raw_rel}')
        logical[raw_rel] = value
        compressed_meta[raw_rel] = row
    actual_gzip = {name.removeprefix('public/') for name in members
                   if name.startswith('public/logs/') and name.endswith('.json.gz')}
    need(actual_gzip == declared,
         'compressed JSON metadata does not equal archived public logs/*.json.gz')
    for name, data in members.items():
        if name.startswith('public/logs/') and name.endswith('.json'):
            rel = name.removeprefix('public/')
            need(rel not in logical, f'both compressed and raw JSON exist: {rel}')
            logical[rel] = strict_json(data)

    for rel, value in logical.items():
        if rel != 'logs/unary-predeclared-values.json' and Path(rel).name.endswith('-values.json'):
            need(isinstance(value, dict) and value.get('actual') == value.get('expected'),
                 f'public actual/expected JSON values differ: {rel}')
        if Path(rel).name.endswith('-envelope.json'):
            fallback = value.get('fallback', {})
            need(fallback.get('attempted') is False,
                 f'public result envelope attempted fallback: {rel}')
            fields = value.get('fields', [])
            if value.get('status') == 'success':
                report_fields(value)
                need(any(f.get('key') == 'public_workflow_external_engine_invoked' and
                         f.get('value') in (False, 'false') for f in fields),
                     f'public successful envelope lacks no-external-engine evidence: {rel}')
            else:
                field_map = {row['key']: row['value'] for row in fields}
                need(len(field_map) == len(fields) and value.get('diagnostics') and
                     field_map.get('result_payload_complete') != 'true',
                     f'failed public envelope lacks incomplete-result diagnostics: {rel}')

    # Preserve and compare the exact predeclared 39-entry literal matrix.
    raw_rel = 'logs/unary-predeclared-values.json'
    need(raw_rel in logical and isinstance(logical[raw_rel], list) and
         len(logical[raw_rel]) == 39,
         'public unary predeclared-values list must remain exactly 39 elements')
    need(canonical_hash(logical[raw_rel]) == EXPECTED_DECLARED_VALUES_SHA256,
         'public unary predeclared-values list differs from the exact frozen list')
    prior_key = 'predeclared-reference/unary-predeclared-values.json'
    need(prior_key in members and strict_json(members[prior_key]) == logical[raw_rel],
         '39-entry public predeclared-values list differs from archived preimplementation values')
    need(len({(row['kind'], row['shape']) for row in logical[raw_rel]}) == 39,
         'predeclared unary kind/shape combinations are duplicated')

    subquery_ref = 'logs/subquery-predeclared-results.json'
    need(subquery_ref in logical and isinstance(logical[subquery_ref], dict) and
         len(logical[subquery_ref]) == 27 and
         all(set(shapes) == {'mixed', 'empty-outer', 'empty-inner', 'all-null'}
             for shapes in logical[subquery_ref].values()),
         'subquery reference must retain all 27 kinds and four input shapes')
    prior_subquery = 'predeclared-reference/subquery-predeclared-results.json'
    need(prior_subquery in members and strict_json(members[prior_subquery]) == logical[subquery_ref],
         'subquery expected values changed after pre-execution declaration')
    dynamic_ref = 'logs/dynamic-subquery-predeclared-results.json'
    prior_dynamic = 'declarations-521/dynamic-subqueries/logs/dynamic-subquery-predeclared-results.json'
    need(dynamic_ref in logical and len(logical[dynamic_ref]) == 18 and
         all(set(shapes) == {'mixed', 'empty-outer', 'empty-inner', 'all-null'}
             for shapes in logical[dynamic_ref].values()) and
         strict_json(members[prior_dynamic]) == logical[dynamic_ref],
         'dynamic reference must retain all eighteen kinds and four predeclared shapes')
    baseline = strict_json(members['baseline/summary.json'])
    old_cases = {row['name']: row for row in baseline['cases']}
    controls = []
    for case in cases:
        name = case['name']
        if not name.startswith('dynamic-subquery-baseline-'):
            continue
        key, streaming = name.removeprefix('dynamic-subquery-baseline-').rsplit('-streaming-', 1)
        expected = baseline['expected'][key]
        values = logical['logs/' + name + '-values.json']
        declared_value = logical['logs/' + name + '-declaration.json']
        need(values['actual'] == values['expected'] == declared_value['expected'] == expected,
             'complete original baseline values differ: ' + name)
        old_case = old_cases[name.replace('dynamic-subquery-baseline-', 'dynamic-inner-baseline-', 1)]
        if streaming == 'True':
            need(old_case['outcome'] == 'dynamic_inner_streaming_refusal' and
                 old_case['producer_events'] == [] and case['outcome'] == 'streaming_success',
                 'baseline streaming refusal did not become exact native success')
        else:
            need(streaming == 'False' and old_case['outcome'] == case['outcome'] == 'resident_control_passed',
                 'resident baseline changed')
        controls.append(name)
    need(len(controls) == 32, 'original baseline case coverage differs')

    pressure_files = pressure_rows = 0
    for case in cases:
        artifact = case.get('values') or case.get('complete_rows')
        if not isinstance(artifact, dict) or not str(artifact.get('path', '')).endswith('.jsonl.gz'):
            continue
        rel = artifact['path']
        safe_member(rel)
        key = 'public/' + rel
        need(key in members, f'public pressure JSONL evidence is absent: {key}')
        packed = members[key]
        need(len(packed) == artifact.get('bytes') and digest(packed) == artifact.get('sha256'),
             f'public pressure JSONL compressed identity mismatch: {rel}')
        try:
            decoded = gzip.decompress(packed)
        except (OSError, EOFError) as exc:
            raise NeedsReasoning(f'invalid public pressure JSONL {rel}: {exc}') from exc
        rows = [strict_json(line) for line in decoded.splitlines()]
        expected_count = case.get('rows_verified', case.get('complete_output_rows',
                                                            case.get('complete_rows')))
        expected_digest = case.get('expected_sha256', case.get('all_output_rows_sha256'))
        need(len(rows) == expected_count and digest(decoded) == expected_digest,
             f'public pressure row count/hash mismatch: {case.get("name")}')
        pressure_files += 1
        pressure_rows += len(rows)
    comparisons = [value for rel, value in logical.items()
                   if rel != 'logs/unary-predeclared-values.json' and Path(rel).name.endswith('-values.json')]
    envelope_count = sum(Path(rel).name.endswith('-envelope.json') for rel in logical)
    need(pressure_files == 45 and pressure_rows == 1578741 and len(comparisons) == 4495 and
         sum(len(value['expected']) for value in comparisons) == 39979 and envelope_count == 6330 and
         len(declared) == 13004 and sum(row['bytes'] for row in metadata) == 45911348 and
         sum(row['raw_bytes'] for row in metadata) == 422554758,
         'reopened public evidence counts differ from the complete accepted inspection')
    return {'cases': len(cases), 'families': len(families),
            'compressed_json_files': len(declared), 'value_files': len(comparisons),
            'expected_rows': 39979, 'envelopes': envelope_count,
            'pressure_files': pressure_files, 'pressure_rows': pressure_rows,
            'predeclared_value_entries': 39, 'subquery_predeclared_kind_shapes': 108,
            'dynamic_predeclared_kind_shapes': 72, 'baseline_controls': 32}


def main():
    need(not OUTPUT.exists(), 'preserve any earlier audit')
    index_path = DEST / (STEM + '.json')
    index = strict_json(index_path.read_bytes())
    need(index['schema_version'] == 'shardloom.native_stream_dynamic_subqueries_evidence.v1' and
         index['status'] == 'packaged_local_pending_acceptance_decision' and
         index['base_commit'] == BASE and not index['publication_attempted'], 'unexpected evidence index')
    for key in ('archive', 'manifest'):
        path = DEST / index[key]['file']
        need(path.name == STEM + ('.tar.xz' if key == 'archive' else '.manifest.json.xz') and
             path.is_file() and not path.is_symlink(), 'unsafe or missing evidence container')
        raw = path.read_bytes()
        need(len(raw) == index[key]['bytes'] and digest(raw) == index[key]['sha256'], 'container identity mismatch')
    manifest_raw = lzma.decompress((DEST / index['manifest']['file']).read_bytes())
    need(digest(manifest_raw) == index['manifest']['raw_sha256'], 'manifest decoded identity mismatch')
    manifest = strict_json(manifest_raw)
    need(manifest['base_commit'] == BASE and manifest['status'] == 'passed_local_evidence_packaged', 'wrong manifest scope')
    for key in ('member_count', 'raw_bytes', 'source_files', 'acceptance', 'source_overlay'):
        need(manifest[key] == index[key], f'index/manifest mismatch: {key}')
    need(index['source_files'] == 2303 and index['raw_bytes'] <= 256 * 1024**2 and
         index['all_members_reopened'] is True and manifest['all_members_reopened'] is True, 'invalid archive bounds or proof')
    expected, originals = {}, {}
    for row in manifest['members']:
        key = row['archive_path']
        safe_member(key)
        need(key not in expected and row['path'] not in originals, 'duplicate member identity')
        expected[key] = row
        originals[row['path']] = key
    need(len(expected) == index['member_count'], 'member inventory length mismatch')
    members, raw_bytes = {}, 0
    with tarfile.open(DEST / index['archive']['file'], mode='r|xz') as archive:
        for entry in archive:
            need(entry.isfile() and entry.name in expected and entry.name not in members, 'unexpected/duplicate/non-file tar member')
            safe_member(entry.name)
            with archive.extractfile(entry) as stream:
                data = stream.read()
            row = expected[entry.name]
            need(len(data) == row['bytes'] == entry.size and digest(data) == row['sha256'], entry.name)
            members[entry.name] = data
            raw_bytes += len(data)
    need(set(members) == set(expected) and raw_bytes == index['raw_bytes'], 'archive membership/byte coverage mismatch')

    def reference(row):
        need(row['path'] in originals, f'bound artifact is absent: {row["path"]}')
        key = originals[row['path']]
        data = members[key]
        need(len(data) == row['bytes'] and digest(data) == row['sha256'], f'bound artifact differs: {key}')
        return data

    build = strict_json(reference(manifest['source_manifest']))
    artifacts = strict_json(reference(manifest['artifact_manifest']))
    execution = strict_json(reference(manifest['accepted_execution_source']))
    accepted = strict_json(reference(manifest['accepted_verification_source']))
    need(build['head'] == artifacts['head'] == execution['head'] == accepted['head'] == BASE and artifacts['status'] == 'passed', 'source/build revision mismatch')
    need(build['source_sha256'] == artifacts['source_sha256'], 'compiled artifact source map mismatch')
    before_map, execution_map, after_map = build['source_sha256'], execution['source_sha256'], accepted['source_sha256']
    need(len(before_map) == len(execution_map) == len(after_map) == 2303 and
         set(before_map) == set(execution_map) == set(after_map), 'selected source membership drift')
    need({name for name in before_map if before_map[name] != execution_map[name]} == {
        'scripts/native_streaming_dynamic_subquery_cases.py',
        'scripts/native_streaming_dynamic_subquery_composition_cases.py',
        'python/src/shardloom/query.py', 'python/tests/test_scalar_subquery_declarations.py'},
        'unexpected source changes after the native build')
    transition = strict_json(reference(manifest['source_transition']))
    need(transition['status'] == 'passed_exact_native_feature_and_test_corrections' and
         transition['before_source'] == manifest['accepted_execution_source'] and
         transition['after_source'] == manifest['accepted_verification_source'] and
         transition['native_artifacts'] == manifest['artifact_manifest'], 'verification transition is not bound')
    changed, test_changed = transition['changed_path'], transition['test_changed_path']
    need(changed == 'shardloom-vortex/src/relational_query.rs' and
         test_changed == 'shardloom-cli/src/sql_scalar_expression.rs' and
         {name for name in execution_map if execution_map[name] != after_map[name]} == {changed, test_changed},
         'unexpected verification source drift')
    before, after = reference(transition['before']), reference(transition['after'])
    old = b'    pub(crate) sources: Option<std::sync::Arc<[DatasetUri]>>,\n'
    new = b'    #[cfg(all(feature = "vortex-local-primitives", unix))]\n' + old
    need(before.count(old) == 1 and after == before.replace(old, new) and
         digest(before) == execution_map[changed] == before_map[changed] and digest(after) == after_map[changed],
         'conditional-field correction changed native enabled code')
    test_before, test_after = reference(transition['test_before']), reference(transition['test_after'])
    test_old = b'            assert!(parse(raw, "ordinary.value").unwrap().bindings.is_empty());'
    test_new = b'\n'.join([b'            assert_eq!(', b'                parse(raw, "ordinary.value").unwrap().bindings,',
                           b'                [] as [(ExprId, RelationalBinding); 0]', b'            );'])
    marker = b'#[cfg(test)]\nmod tests {'
    need(test_before.count(test_old) == 1 and test_after == test_before.replace(test_old, test_new) and
         test_before.index(test_old) > test_before.index(marker) and
         test_before.split(marker)[0] == test_after.split(marker)[0] and
         digest(test_before) == execution_map[test_changed] == before_map[test_changed] and
         digest(test_after) == after_map[test_changed], 'assertion correction changed production code')
    for field in ('retained_failed_gate', 'retained_failed_test_gate'):
        failed_gate = strict_json(reference(transition[field]))
        need(failed_gate['status'] == 'failed' and failed_gate['returncode'] == 101 and
             failed_gate['process_group_drained'], 'failed lint evidence missing')
        failed_log = reference(transition[field.replace('_gate', '_log')])
        need(digest(failed_log) == failed_gate['log_sha256'], 'failed lint log differs')
    for name in manifest['source_overlay']:
        key = 'source-overlay/' + name
        need(key in members and digest(members[key]) == after_map[name], f'selected source overlay mismatch: {name}')
    for name, expected_digest in after_map.items():
        path = REPO / name
        need(path.is_file() and not path.is_symlink() and digest(path.read_bytes()) == expected_digest, f'current selected source changed: {name}')
    contract = reference(manifest['original_contract'])
    protocol = strict_json(members['receipts/stream-dynamic-subquery-acceptance-protocol-521.json'])
    declaration = strict_json(reference(protocol['declarations']))
    need(digest(contract) == protocol['contract']['sha256'] and declaration['native_engine_executions'] == 0 and
         declaration['status'] == 'declared_before_candidate_execution' and
         [row['cases'] for row in declaration['families']] == [716, 32, 153, 195, 7], 'preimplementation declaration mismatch')
    for row in manifest['final_receipts']:
        receipt = strict_json(reference(row))
        need(receipt['status'] == 'passed' and receipt['returncode'] == 0 and receipt['head'] == BASE and
             receipt['process_group_drained'] and receipt['direct_child_reaped'] and
             not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup'], 'incomplete final process receipt')
        log_path = str(Path(row['path']).with_suffix('.log'))
        need(log_path in originals and digest(members[originals[log_path]]) == receipt['log_sha256'], 'process log hash mismatch')
    checks = strict_json(members['receipts/stream-dynamic-subquery-checks-524.json'])
    need(checks['status'] == 'passed' and checks['source_identity_preserved'] and
         checks['source'] == manifest['accepted_verification_source'], 'broad validation source mismatch')
    need([row['stage'] for row in checks['completed']] ==
         ['fmt', 'workspace-clippy', 'workspace-tests', 'read-clippy', 'release-clippy', 'native-tests'], 'six validation gates missing')
    counts = {}
    for row in checks['completed']:
        log = reference(row['log']).decode()
        reference(row['receipt'])
        if row['stage'].endswith('tests'):
            groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', log)
            need(groups and all(int(item[1]) == int(item[3]) == int(item[4]) == 0 for item in groups), 'test failure/filter in gate log')
            counts[row['stage']] = (sum(int(item[0]) for item in groups), sum(int(item[2]) for item in groups))
        if row['stage'] == 'native-tests':
            for name in protocol['native_required_tests']:
                need(re.search(r'^test .*::' + re.escape(name) + r' \.\.\. ok$', log, re.M), name)
    need(counts == {'workspace-tests': (manifest['acceptance']['workspace_tests'], 0),
                    'native-tests': (4285, 29)} and counts['workspace-tests'][0] >= 3221,
         'broad test counts differ')
    previous_checks = strict_json(members['prior-identities/stream-subquery-checks-510.json'])
    previous_ignored = next(row['tests']['ignored_declarations'] for row in previous_checks['completed'] if row['stage'] == 'native-tests')
    current_ignored = next(row['tests']['ignored_declarations'] for row in checks['completed'] if row['stage'] == 'native-tests')
    need(sorted(current_ignored) == sorted(previous_ignored), 'manual/platform exclusions changed')
    direct = strict_json(members['receipts/stream-dynamic-subquery-direct-tests-521.json'])
    need(direct['status'] == 'passed' and direct['tests'] == 100 and
         direct['failures'] == direct['errors'] == direct['skipped'] == 0, 'direct binding gate incomplete')
    prior_direct = strict_json(reference(protocol['original_direct']))
    added = {'test_native_dynamic_subquery_binding.NativeDynamicSubqueryBindingTests.' + name for name in protocol['new_direct_methods']}
    need(set(direct['test_names']) == set(prior_direct['test_names']) | added and len(added) == 4, 'direct method inventory mismatch')
    public = verify_public(members, members['receipts/stream-dynamic-subquery-public-521.log'], protocol)
    focused = verify_compressed_tree(members, 'focused-public')
    need(focused['status'] == 'passed' and focused['cases'] == 1103, 'focused case evidence is incomplete')
    failed = {}
    for attempt, successes, failed_name in [
        (518, 727, 'dynamic-subquery-composition-in-inner-sort'),
        (519, 824, 'dynamic-subquery-nested-shared-in'),
        (520, 842, 'dynamic-subquery-dynamic-outer-in-shared-False')]:
        prefix = f'failed-focused-{attempt}'
        failed[attempt] = verify_compressed_tree(members, prefix)
        failures = strict_json(members[prefix + '/summary.json'])['cases']
        need(failed[attempt]['status'] == 'failed' and failed[attempt]['cases'] == successes + 1 and
             sum(row['status'] == 'passed' for row in failures) == successes and failures[-1]['name'] == failed_name,
             'original failed focused evidence changed')
    failed_direct = strict_json(reference(protocol['initial_direct_counterevidence']))
    need(failed_direct['status'] == 'failed' and failed_direct['tests'] == 4 and
         failed_direct['failures'] == 1 and failed_direct['errors'] == 21, 'original direct failures missing')
    diagnosis = strict_json(reference(protocol['remaining_case_diagnosis']))
    need(diagnosis['status'] == 'diagnostic_complete' and len(diagnosis['cases']) == 229 and
         len(diagnosis['failures']) == 94 and sum(row['status'] == 'passed' for row in diagnosis['cases']) == 135,
         'complete remaining-case diagnosis changed')
    metadata = strict_json(reference(protocol['nested_metadata_two_grant_diagnosis']))
    need(metadata['status'] == 'passed' and len(metadata['cases']) == 12 and
         sum(row['outcome'] == 'reservation_denied' for row in metadata['cases']) == 6,
         'two-grant metadata diagnosis changed')
    sdk_before = members['receipts/stream-dynamic-subquery-python-predicate-before-521b.log'].decode()
    sdk_after = members['receipts/stream-dynamic-subquery-python-predicate-after-521.log'].decode()
    need(re.search(r'Ran 2 tests .*\n\nFAILED \(errors=9\)', sdk_before) and
         re.search(r'Ran 74 tests .*\n\nOK\s*$', sdk_after), 'SDK regression before/after evidence differs')
    for name in protocol['python_required_tests']:
        need(re.search(r'^' + re.escape(name) + r' .* \.\.\. ok$', sdk_after, re.M), name)
    parser_before = members['receipts/stream-dynamic-subquery-predicate-values-before-517.log'].decode()
    parser_after = members['receipts/stream-dynamic-subquery-predicate-values-after-518.log'].decode()
    need('test result: FAILED. 0 passed; 2 failed;' in parser_before and
         'test result: ok. 2 passed; 0 failed;' in parser_after, 'parser regression before/after evidence differs')
    baseline = strict_json(members['baseline/summary.json'])
    original_contract = reference(manifest['baseline_contract'])
    need(digest(original_contract) == baseline['contract_sha256'], 'original baseline contract changed')
    need(baseline['status'] == 'passed' and len(baseline['cases']) == 32 and
         all(row['status'] == 'passed' for row in baseline['cases']), 'baseline controls incomplete')
    denied = [row for row in baseline['cases'] if row['outcome'] == 'dynamic_inner_streaming_refusal']
    resident = [row for row in baseline['cases'] if row['outcome'] == 'resident_control_passed']
    need(len(denied) == len(resident) == 16 and all(row['producer_events'] == [] for row in denied), 'baseline producer refusal boundary changed')
    full_review = strict_json(reference(manifest['full43_review']))
    admission = strict_json(reference(full_review['admission']))
    full = verify_full43(members, full_review, admission)
    summary = strict_json(members['full43/summary.json'])
    result = dict(status='passed', member_count=len(members), raw_bytes=raw_bytes, source_files=2303,
        complete_archive_identity_and_membership_verified=True, exact_feature_and_test_source_transition_verified=True,
        public=public, focused=focused, original_failed_focused=failed, direct_methods=100, direct_skips=0,
        required_test_counts=counts, baseline_refusals=16, baseline_resident_controls=16, full43=full,
        engine_execution_seconds=sum(row['engine_execution_seconds'] for row in summary['records']),
        current_source_map_unchanged=True, complete_values_and_schemas_reopened=True,
        index=dict(path=str(index_path), bytes=index_path.stat().st_size, sha256=digest(index_path.read_bytes())),
        helper=dict(path=__file__, sha256=digest(Path(__file__).read_bytes())),
        reused_auditor=dict(path=str(OUT / 'verify_stream_unary_packet_497.py'),
                            sha256=digest((OUT / 'verify_stream_unary_packet_497.py').read_bytes())),
        no_speedup_claim=True, hosted_integration_complete=False, installed_wheel_proof=False)
    with OUTPUT.open('x') as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(dict(status='passed', members=len(members), public_cases=public['cases'],
                         full43_calls=full['calls'], engine_execution_seconds=result['engine_execution_seconds'])))


if __name__ == '__main__':
    main()


