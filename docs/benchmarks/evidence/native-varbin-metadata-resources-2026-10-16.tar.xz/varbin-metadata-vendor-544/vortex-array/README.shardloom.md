# Vortex timestamp, statistics and ownership patches

This is the Apache-2.0 `vortex-array` 0.85.0 published source with a focused
correction for timezone-free microsecond timestamp scalars. Vortex's timestamp
extension uses Int64 storage, but the original scalar validator constructs a
calendar span that can panic on valid storage values. Its display path repeats
the conversion. This prevents safe extrema statistics and compression for the
full storage domain already admitted by ShardLoom.

The timestamp changes are confined to `src/extension/datetime/timestamp.rs`:

- `Timestamp::unpack_native` retains every Int64 value for microseconds without
  a timezone after the existing storage type validation.
- `TimestampValue::fmt` uses Jiff's checked direct microsecond conversion for
  that case. In-calendar display stays unchanged; other values render exactly
  as `<integer>us since Unix epoch`.

The persisted-output work also changes count and byte-size merges in
`src/stats/stats_set.rs` to checked `u64` addition. Overflow invalidates the
statistic instead of panicking or wrapping, and the representation is independent
of host pointer width. This is used by the bounded `vortex-layout` file collector.

The encoded-transfer work adds an optional opaque lifetime owner to typed array
data, construction parts and structural rewrites in `src/array`. New owners can
only attach to unique, previously unowned arrays. Array data drops before the
owner; clones, typed-parts round trips and owned child references retain it.
Owned slices retain a native parent view until execution, including empty and
repeated slices, instead of eagerly rebuilding metadata without its owner.
Arrays without an owner keep the previous slice path. Buffer extraction still
requires independently retained buffer ownership; raw dtype/data clones are not
covered. This adds no unsafe code, serialized field or encoding identity.
`src/arrays/slice/vtable.rs` reduces the retained view at explicit execution,
preventing repeated slice reconstruction when its child is already canonical.
Owned filters also retain their native parent until explicit execution.
`src/arrays/filter/vtable.rs` then applies the deferred reductions while keeping
the original view alive through canonical execution, preserving sparse-frame
skipping and metadata ownership together.
Structural buffer reconstruction preserves an owner supplied by its provider
and rejects conflicting owners. On the tested 64-bit target, the hook adds
16 bytes to each common array allocation; `ArrayRef` remains 16 bytes.
The [transfer contract](../../docs/architecture/native-encoded-interchange-2026-10-12.md)
requires lifetime, allocation, footprint and complete-lifecycle regression proof.

Other temporal units and timezone policy are unchanged. The extension identity,
metadata serialization, comparison rules, native arrays and file format are
unchanged. There is no Arrow intermediate, new query engine, unchecked scalar
construction or dependency-version change. Ordinary calendar operations can
retain their own narrower domains; scalar storage admission is not a claim
that all calendar functions support every Int64 timestamp.

`upstream-provenance.json` records the reviewed archive, all original member
hashes, VCS metadata and verified Apache license. The archive is authoritative
because its recorded VCS state is dirty. `Cargo.toml.orig` remains unchanged;
the normalized manifest adds `publish = false`. The original crate-local lockfile
is recorded but not copied because the workspace owns dependency resolution.
Upstream copyright headers remain in every source file and each modified source
file has an explicit change notice. Two original trailing-whitespace lines are
also normalized: a blank documentation line in `src/arrays/patched/mod.rs`, and a
snapshot literal in `src/scalar_fn/fns/zip/mod.rs`. The latter uses an explicit
space escape in an ordinary string to preserve exactly the original expected
snapshot bytes. Neither normalization changes provider behavior.

The adapter regressions live in `shardloom-vortex/src/native_temporal.rs` and
the existing writer tests. The full acceptance contract is
[`native-timestamp-provider-2026-10-11.md`](../../docs/architecture/native-timestamp-provider-2026-10-11.md).
External readers built with the unpatched provider can still inherit its calendar
restriction; this patch does not certify them.

Remove this patch when an approved upstream release preserves the full storage
domain and passes scalar, compression, statistics, pruning, writer, resource,
package and complete-workflow checks. Keep the existing feature gates and shared
resource owners when changing the provider.

## External memory reservations

`HostAllocator::reserve_external(len)` admits a provider's requested external
heap bytes and returns an opaque lifetime owner. The provider must release the
covered allocations before dropping that owner. Custom allocators refuse this
request by default; `DefaultHostAllocator` explicitly retains an unbounded
policy. ShardLoom's allocator adapter connects the owner to the existing shared
`LiveMemoryPool` grant. This reservation does not duplicate the provider's
payload in a Vortex buffer.
The provider supplies the bound; allocator bookkeeping, C call stacks, process
RSS and providers without reviewed bounds are outside this reservation claim.

## Variable-binary tables

`VarBinViewData` owns one shared reservation for its immutable data-buffer table.
Context-aware construction and deserialization admit temporary vectors and the
final slice before allocation, including conversion overlap. Changing views,
validity or nullability retains that owner while the same table remains live.
Empty canonical reductions discard unused storage. Raw table exports remain
caller-owned; raw payload buffers do not carry unrelated table credit.

The existing length/offset view-building loops also create admitted tables.
The restricted non-compacting builder admits old/new capacity overlap and its
final table; payload views and validity retain their separate caller admission.
Its all-kept append path avoids intermediate per-leaf tables. Legacy generic
builders, deduplication and compaction scratch retain their separate boundary.
The [ownership contract](../../docs/architecture/native-varbin-metadata-resources-2026-10-16.md)
defines the exact scope and verification requirements.
