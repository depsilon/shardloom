"""Verify the filtered-count sink-report review correction on one clean source."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

import accept_format_strategy_907 as prior

ROOT, OUT = prior.ROOT, prior.OUT
SOURCE = OUT / 'format-strategy-review-source-910.json'
REPORT = OUT / 'format-strategy-review-acceptance-910.json'
ARTIFACTS = OUT / 'artifacts/format-strategy-review-910'
CARGO = prior.CARGO
PYTHON = prior.PYTHON
BUILD_PYTHON = prior.BUILD_PYTHON
TEST_PYTHON = OUT / 'format-strategy-wheel-907/venv/bin/python'
GUARD = prior.GUARD


def verify(source):
    assert prior.git('rev-parse', 'HEAD') == source['head']
    assert not prior.git('status', '--porcelain')
    assert prior.source_hashes() == source['source_hashes']
    assert prior.identity(__file__) == source['helper']
    assert prior.identity(GUARD) == source['guard']


assert not SOURCE.exists() and not REPORT.exists() and not ARTIFACTS.exists()
assert not prior.git('status', '--porcelain')
source = dict(schema='shardloom.format_strategy_review_source.v1',
    head=prior.git('rev-parse', 'HEAD'), tree=prior.git('rev-parse', 'HEAD^{tree}'),
    source_hashes=prior.source_hashes(), helper=prior.identity(__file__),
    inventory_helper=prior.identity(prior.__file__), guard=prior.identity(GUARD))
prior.save(SOURCE, source)
result = dict(status='running', source=prior.identity(SOURCE), steps=[],
    review_url='https://github.com/depsilon/shardloom/pull/1583#discussion_r4343835241',
    purpose='Preserve the writer policy while copying only count-producer execution evidence.',
    full43_rerun=False,
    full43_boundary='The correction only changes the report of scalar writes. The recorded collect-only Full43 observation keeps its original source and binary identities.',
    earlier_attempts={})
for stem in ('format-strategy-review-red-909', 'format-strategy-review-red-909b',
             'format-strategy-review-green-910'):
    receipt = prior.read(OUT / (stem + '.json'))
    log = prior.identity(OUT / (stem + '.log'))
    assert receipt['log_sha256'] == log['sha256']
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    result['earlier_attempts'][stem] = dict(receipt=prior.identity(OUT / (stem + '.json')), log=log,
        status=receipt['status'], returncode=receipt['returncode'])
assert result['earlier_attempts']['format-strategy-review-red-909b']['returncode'] == 101
assert 'assertion failed: report.physical_policy.writer_coalescing_enabled' in (OUT / 'format-strategy-review-red-909b.log').read_text()
assert result['earlier_attempts']['format-strategy-review-green-910']['returncode'] == 0
steps = [
    ('fmt', [*CARGO, 'fmt', '--all', '--', '--check']),
    ('native-clippy', [*CARGO, 'clippy', '--offline', '--locked', '-p', 'shardloom-cli',
        '-p', 'shardloom-vortex', '--all-targets', '--features', 'release-user-surfaces', '--', '-D', 'warnings']),
    ('extension', [BUILD_PYTHON, '-B', 'scripts/build_native_python.py', '--release', '--offline',
        '--output-dir', str(ARTIFACTS / 'native')]),
    ('python-native', ['/usr/bin/env', 'PYTHONPATH=python/src:python/tests',
        'SHARDLOOM_REQUIRE_NATIVE_PYTHON=1',
        'SHARDLOOM_NATIVE_TEST_LIBRARY=' + str(ARTIFACTS / 'native/_native.abi3.so'),
        str(TEST_PYTHON), '-B', '-m', 'unittest', '-v', 'test_native_primitive_binding']),
    ('workspace-clippy', [*CARGO, 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('workspace-tests', [*CARGO, 'test', '--offline', '--locked', '--workspace', '--all-targets']),
    ('native-tests', [*CARGO, 'test', '--offline', '--locked', '-p', 'shardloom-vortex',
        '--lib', '--features', 'release-user-surfaces']),
]
try:
    for name, command in steps:
        verify(source)
        stem = 'format-strategy-review-' + name + '-910'
        complete = subprocess.run([PYTHON, '-B', str(GUARD), '--name', stem,
            '--timeout', '3600', '--', *command], cwd=ROOT, check=False)
        verify(source)
        path, log = OUT / (stem + '.json'), OUT / (stem + '.log')
        receipt = prior.read(path)
        assert receipt['command'] == command and receipt['head'] == source['head']
        assert receipt['working_tree'] == '' and receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert receipt['log_sha256'] == prior.identity(log)['sha256']
        assert complete.returncode == receipt['returncode'] == 0 and receipt['status'] == 'passed', name
        step = dict(name=name, receipt=prior.identity(path), log=prior.identity(log))
        if name.endswith('tests'):
            step['summaries'] = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log.read_text())
            assert step['summaries'] and all(failed == '0' for _, failed, _ in step['summaries'])
        elif name == 'extension':
            step['library'] = prior.identity(ARTIFACTS / 'native/_native.abi3.so')
        elif name == 'python-native':
            text = log.read_text()
            assert re.search(r'Ran \d+ tests', text) and text.rstrip().endswith('OK'), text[-2500:]
            step['tests'] = int(re.search(r'Ran (\d+) tests', text).group(1))
        result['steps'].append(step)
    result['status'] = 'passed'
except BaseException as error:
    result.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    prior.save(REPORT, result)
    print(json.dumps({'status': result['status'], 'report': str(REPORT)}), flush=True)
