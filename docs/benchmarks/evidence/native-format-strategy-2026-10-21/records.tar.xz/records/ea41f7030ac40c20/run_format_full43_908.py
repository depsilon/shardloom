"""Isolated Full43 acceptance; correct the copied supervisor path before any queries."""
import importlib.util
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
from accept_format_strategy_907 import BUILD, OUT, ROOT, SOURCE, identity, read, save, verify

def full43():
    from native_workload_guard_816 import WorkloadGuard
    sys.path.insert(0, str(ROOT / 'scripts'))
    from local_uat_storage import GIB, MIB, check_budgets, require_local_path

    run_root = OUT / 'format-strategy-full43-908'
    plan_path = OUT / 'format-strategy-full43-plan-908.json'
    receipt = OUT / 'format-strategy-full43-run-908.json'
    log = OUT / 'format-strategy-full43-run-908.log'
    assert not any(path.exists() for path in (run_root, plan_path, receipt, log))
    frozen = verify()
    original = read(OUT / 'structural-single-full43-plan-887.json')
    built = read(BUILD)
    assert built['source'] == identity(SOURCE)
    assert identity(built['binary']['path']) == built['binary']

    def generation(path):
        s = Path(path).stat()
        return dict(device=s.st_dev, inode=s.st_ino, size_bytes=s.st_size,
                    mtime_ns=s.st_mtime_ns, ctime_ns=s.st_ctime_ns)

    expected_input = original['input']
    assert generation(expected_input['path']) == expected_input['generation']
    assert identity(expected_input['path'])['sha256'] == expected_input['sha256']
    assert generation(expected_input['path']) == expected_input['generation']
    assert identity(original['reference']['path']) == original['reference']
    for source in original['schema_sources']:
        assert identity(source['path']) == source
    command = original['command'].copy()
    command[command.index('--uat-root') + 1] = str(run_root)
    command[command.index('--binary') + 1] = built['binary']['path']
    command[command.index('--build-commit') + 1] = frozen['head']
    assert command[command.index('--repeats') + 1] == '1' and '--query-ids' not in command
    helper = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
    assert identity(helper)['sha256'] == '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97'
    spec = importlib.util.spec_from_file_location('format_full43_supervisor', helper)
    supervisor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(supervisor)
    workload = WorkloadGuard()
    workload.check()

    def storage_snapshot():
        values = {}
        for label, path in (('evidence', OUT), ('cargo', Path('/Users/dylan/.cache/shardloom/cargo-target'))):
            require_local_path(path, Path.home(), sys.platform)
            values[label] = check_budgets(path, path / 'reserved-artifact', path / 'logs',
                min_free_bytes=12 * GIB, reserve_bytes=128 * MIB,
                max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
        return values

    record = dict(status='preparing', command=command, cwd=str(ROOT), source=identity(SOURCE),
        binary=built['binary'], build=identity(BUILD), input=expected_input, pre_input_hash_verified=True,
        source_commit=frozen['head'], host=dict(platform=platform.platform(), logical_cpus=os.cpu_count(),
            physical_ram_bytes=int(subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.memsize'], text=True))),
        host_samples=[], storage_before=storage_snapshot())
    save(plan_path, dict(schema='shardloom.single_full43_plan.v1', status='predeclared',
        helper=identity(__file__), supervisor=identity(helper), workload_guard=identity(OUT / 'native_workload_guard_816.py'),
        source=identity(SOURCE), build=identity(BUILD), input=expected_input, reference=original['reference'],
        schema_sources=original['schema_sources'], query_ids=list(range(1, 44)), repeats=1, expected_calls=43,
        command=command, parallel_work=False, extra_profiling=False, artificial_pacing=False,
        request='Final isolated acceptance of shared format strategy correction using the existing native Full43 reference.',
        input_hashing='Full input hash before and after queries; cache state uncontrolled.',
        methodology='Unchanged standard runner with storage limits, deadlines, complete results and cleanup. Outer workload guard and small host observations only during queries. No builds, tests, agents, packaging, recursive inventories or input hashes during execution.',
        interpretation='One observation; no repeated comparison or speedup claim. Prior observations remain unchanged.'))
    last_sample = 0.0

    def guard():
        nonlocal last_sample
        workload.check(record.get('pid'))
        if time.monotonic() - last_sample < 2:
            return
        rows = subprocess.check_output(['ps', '-axo', 'pid=,ppid=,pgid=,pcpu=,rss=,comm='], text=True, timeout=10)
        samples = []
        for line in rows.splitlines():
            fields = line.strip().split(None, 5)
            if len(fields) == 6 and (int(fields[0]) in workload.owned or float(fields[3]) >= 1):
                samples.append(dict(pid=int(fields[0]), parent=int(fields[1]), group=int(fields[2]),
                    cpu_percent=float(fields[3]), rss_bytes=int(fields[4]) * 1024,
                    executable=Path(fields[5]).name))
        record['host_samples'].append(dict(load_average=list(os.getloadavg()), processes=samples))
        last_sample = time.monotonic()

    try:
        print('Preparation complete; starting one standard Full43 pass.', flush=True)
        record['status'] = 'running'
        with log.open('xb') as stream:
            code = supervisor.run(command, cwd=ROOT,
                env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONPATH='python/src:scripts'),
                output=stream, timeout=900, evidence=record, guard=guard, max_output_bytes=8 << 20)
        assert code == 0
        print('Query pass finished; verifying retained results and identities.', flush=True)
        record['storage_after'] = storage_snapshot()
        assert generation(expected_input['path']) == expected_input['generation']
        assert identity(expected_input['path'])['sha256'] == expected_input['sha256']
        assert generation(expected_input['path']) == expected_input['generation']
        record['post_input_hash_verified'] = True
        assert verify() == frozen
        record['source_unchanged'] = True
        workload.check()
        assert not (run_root / '.ingest-uat.lock').exists()
        record['uat_lock_released'] = True
        record['status'] = 'passed'
    except BaseException as error:
        record.update(status='failed', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        if log.exists():
            record['log'] = identity(log)
        record['plan'] = identity(plan_path)
        save(receipt, record)
    return dict(receipt=identity(receipt), plan=identity(plan_path))


if __name__ == '__main__':
    result = full43()
    save(OUT / 'format-strategy-full43-verified-908.json',
         dict(status='passed', phase='full43', source=identity(SOURCE), result=result))
    print('Full43 execution and post-run identity checks passed.', flush=True)
