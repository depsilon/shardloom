"""Verify the exact preserved Parquet/ORC wildcard failures against independent readers."""
import json
from pathlib import Path
import subprocess
import sys

import pyarrow
import pyarrow.orc as orc
import pyarrow.parquet as parquet

from accept_format_strategy_907 import BUILD, OUT, ROOT, identity, read, save, verify


def main():
    frozen = verify()
    built = read(BUILD)
    assert identity(built['binary']['path']) == built['binary']
    previous_path = OUT / 'full43-file-route-results-898.json'
    previous = read(previous_path)
    fixtures = previous['native_reopen_regression_fixtures']
    assert len(fixtures) == 2
    destination = OUT / 'format-original-readback-907'
    destination.mkdir()
    result = dict(status='running', source_commit=frozen['head'],
                  binary=built['binary'], original=identity(previous_path),
                  helper=identity(__file__), independent_reader='PyArrow ' + pyarrow.__version__,
                  cases=[])
    try:
        for fixture in fixtures:
            path = Path(fixture['path'])
            before = identity(path)
            assert before['sha256'] == fixture['sha256']
            kind = path.suffix[1:]
            assert kind in ('parquet', 'orc')
            table = parquet.read_table(path) if kind == 'parquet' else orc.ORCFile(path).read()
            expected = table.to_pylist()
            sql = "SELECT * FROM '" + str(path).replace("'", "''") + "'"
            command = [built['binary']['path'], 'run', 'sql', '--input', str(path),
                       '--input-format', kind, '--sql', sql, '--request', 'collect',
                       '--bounded', 'true', '--memory-gb', '1', '--max-parallelism', '2',
                       '--format', 'json']
            run = subprocess.run(command, cwd=ROOT, capture_output=True, timeout=90, check=False)
            stdout, stderr = destination / (kind + '.json'), destination / (kind + '.stderr')
            stdout.write_bytes(run.stdout)
            stderr.write_bytes(run.stderr)
            case = dict(input=before, original_input=fixture, command=command,
                        returncode=run.returncode, output=identity(stdout), stderr=identity(stderr),
                        expected=expected, columns=table.schema.names,
                        logical_schema=str(table.schema), status='checking')
            result['cases'].append(case)
            assert run.returncode == 0, (kind, run.stderr.decode(errors='replace'))
            report = json.loads(run.stdout)
            fields = {field['key']: field['value'] for field in report['fields']}
            assert report['status'] == 'success'
            assert fields['result_payload_complete'] == 'true'
            if 'result_jsonl' in fields:
                actual = [json.loads(line) for line in fields['result_jsonl'].splitlines()]
            else:
                actual = json.loads(fields['result_values_json'])
            assert actual == expected, kind
            assert all(set(row) == set(table.schema.names) for row in actual), kind
            for name in ('public_workflow_fallback_attempted', 'public_workflow_external_engine_invoked'):
                assert fields[name] == 'false', (kind, name)
            assert identity(path) == before
            case.update(status='passed', actual=actual, rows=len(actual),
                        route=fields['public_workflow_route_id'],
                        result_payload_complete=True, fallback_attempted=False,
                        external_engine_invoked=False, input_unchanged=True)
        assert verify() == frozen
        result['status'] = 'passed'
    except BaseException as error:
        result.update(status='failed', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        save(OUT / 'format-original-readback-907.json', result)
    print(json.dumps(dict(status=result['status'], cases=len(result['cases']),
                          rows=sum(case['rows'] for case in result['cases']))))


if __name__ == '__main__':
    main()
