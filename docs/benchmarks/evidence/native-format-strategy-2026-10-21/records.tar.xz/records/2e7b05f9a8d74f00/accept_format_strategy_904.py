"""Source-bound acceptance of the shared native format strategy correction."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import time

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PYTHON = '/opt/homebrew/opt/python@3.13/bin/python3.13'
BUILD_PYTHON = '/Users/dylan/LocalData/shardloom/native-python-surface-20261010/release-v0.6.0/build-env/bin/python'
CARGO = ['/Users/dylan/.cargo/bin/rustup', 'run', '1.99.0', 'cargo']
GUARD = OUT / 'run_native_breadth_guard_871.py'
SOURCE = OUT / 'format-strategy-source-904.json'
BUILD = OUT / 'format-strategy-build-904.json'
ARTIFACTS = OUT / 'artifacts/format-strategy-904'
WHEEL = OUT / 'format-strategy-wheel-904'
INPUT_PREFIXES = ('shardloom-', 'vendor/', 'python/', 'scripts/', 'benchmarks/', '.github/', '.cargo/')
INPUT_NAMES = {'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)


def read(path):
    return json.loads(Path(path).read_bytes())


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def source_hashes():
    names = set(git('ls-files', '-z').split('\0'))
    names.update(git('ls-files', '--others', '--exclude-standard', '-z').split('\0'))
    names = sorted(name for name in names if name and
                   (name.startswith(INPUT_PREFIXES) or name in INPUT_NAMES))
    return {name: identity(ROOT / name)['sha256'] for name in names}


def verify():
    source = read(SOURCE)
    assert source_hashes() == source['source_hashes'], 'acceptance source changed'
    assert git('rev-parse', 'HEAD') == source['head'], 'acceptance revision changed'
    assert git('branch', '--show-current') == 'codex/native-format-strategy-parity'
    assert identity(__file__) == source['helper']
    assert identity(GUARD) == source['guard']
    return source


def guarded(name, command, timeout=3600):
    before = verify()
    stem = 'format-strategy-' + name + '-904'
    completed = subprocess.run([PYTHON, '-B', str(GUARD), '--name', stem,
                                '--timeout', str(timeout), '--', *command], cwd=ROOT, check=False)
    assert verify() == before
    receipt, log = OUT / (stem + '.json'), OUT / (stem + '.log')
    value = read(receipt)
    assert value['command'] == command and value['head'] == before['head']
    assert value['process_group_drained'] and value['direct_child_reaped']
    assert value['log_sha256'] == identity(log)['sha256']
    assert completed.returncode == value['returncode'] == 0 and value['status'] == 'passed', stem
    return dict(receipt=identity(receipt), log=identity(log)), log.read_text()


def build():
    result = {}
    result['cli'], log = guarded('build-cli', [*CARGO, 'build', '--release', '--offline', '--locked',
        '-p', 'shardloom-cli', '--bin', 'shardloom', '--features', 'release-user-surfaces',
        '--message-format=json-render-diagnostics'])
    messages = [json.loads(line) for line in log.splitlines() if line.startswith('{')]
    compiled = {row.get('target', {}).get('name') for row in messages
                if row.get('reason') == 'compiler-artifact' and not row['fresh']}
    assert {'shardloom_cli', 'shardloom_vortex', 'shardloom'} <= compiled, compiled
    artifacts = [row for row in messages if row.get('reason') == 'compiler-artifact'
                 and row.get('target', {}).get('name') == 'shardloom' and row.get('executable')]
    assert len(artifacts) == 1 and artifacts[0]['profile']['opt_level'] == '3'
    built = Path(artifacts[0]['executable'])
    assert built.is_relative_to('/Users/dylan/.cache/shardloom/cargo-target')
    ARTIFACTS.mkdir()
    binary = ARTIFACTS / 'shardloom'
    with binary.open('xb') as stream:
        stream.write(built.read_bytes())
    binary.chmod(built.stat().st_mode & 0o777)
    assert identity(binary)['sha256'] == identity(built)['sha256']
    result['extension'], log = guarded('build-extension', [BUILD_PYTHON, '-B',
        'scripts/build_native_python.py', '--release', '--offline',
        '--output-dir', str(ARTIFACTS / 'native')])
    start = log.index('{\n  "schema_version": "shardloom.native_python_build.v1"')
    native = json.JSONDecoder().raw_decode(log[start:])[0]
    library = identity(native['library'])
    assert native['status'] == 'passed' and library['sha256'] == native['library_sha256']
    save(BUILD, dict(status='passed', source=identity(SOURCE), source_commit=verify()['head'],
        binary=identity(binary), library=library, cli_compiler_artifact=artifacts[0],
        freshly_compiled_targets=sorted(compiled), native_build=native, checks=result))
    return result


def wheel():
    built = read(BUILD)
    assert built['source'] == identity(SOURCE)
    for key in ('binary', 'library'):
        assert identity(built[key]['path']) == built[key]
    run, _ = guarded('wheel', [BUILD_PYTHON, '-B', 'scripts/prove_native_python_wheel.py',
        '--repo-root', str(ROOT), '--output-dir', str(WHEEL), '--native-library', built['library']['path'],
        '--cli-binary', built['binary']['path'], '--wheelhouse', str(OUT / 'pyarrow-wheelhouse-cp312')])
    report = read(WHEEL / 'report.json')
    assert report['status'] == report['uninstall_status'] == report['integration']['status'] == 'passed'
    assert report['integration']['tests'] == 121, report['integration']
    assert report['integration']['failures'] == report['integration']['errors'] == report['integration']['skipped'] == 0
    assert report['integrity']['cli_sha256'] == built['binary']['sha256']
    assert report['integrity']['native_library_sha256'] == built['library']['sha256']
    assert report['installed_load']['isolated_install'] and not report['publication_attempted']
    for step in report['steps']:
        assert step['returncode'] == 0 and identity(WHEEL / step['log'])['sha256'] == step['log_sha256']
    return dict(run=run, report=identity(WHEEL / 'report.json'), integration=identity(WHEEL / 'integration.json'))


def full43():
    from native_workload_guard_816 import WorkloadGuard
    sys.path.insert(0, str(ROOT / 'scripts'))
    from local_uat_storage import GIB, MIB, check_budgets, require_local_path

    run_root = OUT / 'format-strategy-full43-904'
    plan_path = OUT / 'format-strategy-full43-plan-904.json'
    receipt = OUT / 'format-strategy-full43-run-904.json'
    log = OUT / 'format-strategy-full43-run-904.log'
    assert not any(path.exists() for path in (run_root, plan_path, receipt, log))
    frozen = verify()
    original = read(OUT / 'structural-single-full43-plan-887.json')
    built = read(BUILD)
    assert built['source'] == identity(SOURCE)
    assert identity(built['binary']['path']) == built['binary']

    def generation(path):
        s = Path(path).stat()
        return dict(device=s.st_dev, inode=s.st_ino, size_bytes=s.st_size,
                    mtime_ns=s.st_mtime_ns, ctime_ns=s.st_ctime_ns)

    expected_input = original['input']
    assert generation(expected_input['path']) == expected_input['generation']
    assert identity(expected_input['path'])['sha256'] == expected_input['sha256']
    assert generation(expected_input['path']) == expected_input['generation']
    assert identity(original['reference']['path']) == original['reference']
    for source in original['schema_sources']:
        assert identity(source['path']) == source
    command = original['command'].copy()
    command[command.index('--uat-root') + 1] = str(run_root)
    command[command.index('--binary') + 1] = built['binary']['path']
    command[command.index('--build-commit') + 1] = frozen['head']
    assert command[command.index('--repeats') + 1] == '1' and '--query-ids' not in command
    helper = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
    assert identity(helper)['sha256'] == '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97'
    spec = importlib.util.spec_from_file_location('format_full43_supervisor', helper)
    supervisor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(supervisor)
    workload = WorkloadGuard()
    workload.check()

    def storage_snapshot():
        values = {}
        for label, path in (('evidence', OUT), ('cargo', Path('/Users/dylan/.cache/shardloom/cargo-target'))):
            require_local_path(path, Path.home(), sys.platform)
            values[label] = check_budgets(path, path / 'reserved-artifact', path / 'logs',
                min_free_bytes=12 * GIB, reserve_bytes=128 * MIB,
                max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
        return values

    record = dict(status='preparing', command=command, cwd=str(ROOT), source=identity(SOURCE),
        binary=built['binary'], build=identity(BUILD), input=expected_input, pre_input_hash_verified=True,
        source_commit=frozen['head'], host=dict(platform=platform.platform(), logical_cpus=os.cpu_count(),
            physical_ram_bytes=int(subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.memsize'], text=True))),
        host_samples=[], storage_before=storage_snapshot())
    save(plan_path, dict(schema='shardloom.single_full43_plan.v1', status='predeclared',
        helper=identity(__file__), supervisor=identity(helper), workload_guard=identity(OUT / 'native_workload_guard_816.py'),
        source=identity(SOURCE), build=identity(BUILD), input=expected_input, reference=original['reference'],
        schema_sources=original['schema_sources'], query_ids=list(range(1, 44)), repeats=1, expected_calls=43,
        command=command, parallel_work=False, extra_profiling=False, artificial_pacing=False,
        request='Final isolated acceptance of shared format strategy correction using the existing native Full43 reference.',
        input_hashing='Full input hash before and after queries; cache state uncontrolled.',
        methodology='Unchanged standard runner with storage limits, deadlines, complete results and cleanup. Outer workload guard and small host observations only during queries. No builds, tests, agents, packaging, recursive inventories or input hashes during execution.',
        interpretation='One observation; no repeated comparison or speedup claim. Prior observations remain unchanged.'))
    last_sample = 0.0

    def guard():
        nonlocal last_sample
        workload.check(record.get('pid'))
        if time.monotonic() - last_sample < 2:
            return
        rows = subprocess.check_output(['ps', '-axo', 'pid=,ppid=,pgid=,pcpu=,rss=,comm='], text=True, timeout=10)
        samples = []
        for line in rows.splitlines():
            fields = line.strip().split(None, 5)
            if len(fields) == 6 and (int(fields[0]) in workload.owned or float(fields[3]) >= 1):
                samples.append(dict(pid=int(fields[0]), parent=int(fields[1]), group=int(fields[2]),
                    cpu_percent=float(fields[3]), rss_bytes=int(fields[4]) * 1024,
                    executable=Path(fields[5]).name))
        record['host_samples'].append(dict(load_average=list(os.getloadavg()), processes=samples))
        last_sample = time.monotonic()

    try:
        print('Preparation complete; starting one standard Full43 pass.', flush=True)
        record['status'] = 'running'
        with log.open('xb') as stream:
            code = supervisor.run(command, cwd=ROOT,
                env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONPATH='python/src:scripts'),
                output=stream, timeout=900, evidence=record, guard=guard, max_output_bytes=8 << 20)
        assert code == 0
        print('Query pass finished; verifying retained results and identities.', flush=True)
        record['storage_after'] = storage_snapshot()
        assert generation(expected_input['path']) == expected_input['generation']
        assert identity(expected_input['path'])['sha256'] == expected_input['sha256']
        assert generation(expected_input['path']) == expected_input['generation']
        record['post_input_hash_verified'] = True
        assert verify() == frozen
        record['source_unchanged'] = True
        workload.check()
        assert not (run_root / '.ingest-uat.lock').exists()
        record['uat_lock_released'] = True
        record['status'] = 'passed'
    except BaseException as error:
        record.update(status='failed', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        if log.exists():
            record['log'] = identity(log)
        record['plan'] = identity(plan_path)
        save(receipt, record)
    return dict(receipt=identity(receipt), plan=identity(plan_path))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=('freeze', 'format', 'lint', 'cli', 'core', 'build', 'wheel', 'references', 'full43', 'verify'))
    phase = parser.parse_args().phase
    if phase == 'freeze':
        assert not git('status', '--porcelain'), 'commit the coherent correction before final acceptance'
        save(SOURCE, dict(schema='shardloom.format_strategy_source.v1', head=git('rev-parse', 'HEAD'),
            source_hashes=source_hashes(), helper=identity(__file__), guard=identity(GUARD)))
        result = dict(source=identity(SOURCE))
    else:
        verify()
        if phase == 'verify':
            result = {}
        elif phase == 'format':
            run, _ = guarded('format', [*CARGO, 'fmt', '--all', '--', '--check'], 300)
            result = dict(run=run)
        elif phase == 'lint':
            run, _ = guarded('lint', [*CARGO, 'clippy', '--offline', '--locked',
                '-p', 'shardloom-cli', '-p', 'shardloom-vortex', '--all-targets',
                '--features', 'release-user-surfaces', '--', '-D', 'warnings'])
            result = dict(run=run)
        elif phase == 'cli':
            run, log = guarded('cli', [*CARGO, 'test', '--offline', '--locked', '-p', 'shardloom-cli',
                '--features', 'release-user-surfaces', '--lib', '--test', 'public_memory_inputs',
                '--test', 'public_workflow_route', '--test', 'resident_worker', '--test', 'vortex_prepare'])
            summaries = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
            assert summaries and all(failed == ignored == '0' for _, failed, ignored in summaries)
            result = dict(run=run, summaries=summaries)
        elif phase == 'core':
            directory = OUT / 'format-strategy-python-core-904'
            run, _ = guarded('core', [PYTHON, '-B', 'scripts/run_python_test_shard.py',
                '--shard', 'core', '--output-dir', str(directory)])
            report = read(directory / 'core.json')
            assert report['status'] == 'passed' and report['failure_count'] == report['error_count'] == 0
            result = dict(run=run, report=identity(directory / 'core.json'))
        elif phase == 'build':
            result = build()
        elif phase == 'wheel':
            result = wheel()
        elif phase == 'full43':
            result = full43()
        elif phase == 'references':
            checks = {}
            for name in ('python_license_bundle', 'user_surface_reference', 'public_status_docs',
                         'contribution_governance', 'v1_inclusion_scope'):
                command = [PYTHON, '-B', 'scripts/check_' + name + '.py']
                if name not in ('python_license_bundle', 'user_surface_reference'):
                    command += ['--output', str(OUT / ('format-strategy-' + name + '-904.json'))]
                checks[name], _ = guarded(name.replace('_', '-'), command, 300)
            built = read(BUILD)
            checks['golden_workflows'], _ = guarded('golden-workflows', [PYTHON, '-B',
                'scripts/check_golden_workflows.py', '--skip-build', '--binary', built['binary']['path'],
                '--output', str(OUT / 'format-strategy-golden-904.json'),
                '--work-dir', str(OUT / 'format-strategy-golden-904')], 300)
            result = dict(checks=checks)
        verify()
    if phase != 'verify':
        save(OUT / ('format-strategy-' + phase + '-verified-904.json'),
             dict(status='passed', phase=phase, source=identity(SOURCE), result=result))
    print(json.dumps(dict(status='passed', phase=phase)), flush=True)


if __name__ == '__main__':
    main()

