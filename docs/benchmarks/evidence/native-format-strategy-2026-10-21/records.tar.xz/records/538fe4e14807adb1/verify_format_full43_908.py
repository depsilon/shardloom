"""Recheck every retained Full43 output, identity, clock and cleanup assertion."""
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
import sys

from accept_format_strategy_907 import OUT, ROOT, identity, read, save, verify

sys.path[:0] = [str(ROOT / 'scripts'), str(ROOT / 'python/src')]
from clickbench_reference_packet import load_reference_packet
from native_workflow_protocol import extract_result, report_fields
from run_clickbench_query_uat import equivalent

frozen = verify()
plan = read(OUT / 'format-strategy-full43-plan-908.json')
run = read(OUT / 'format-strategy-full43-run-908.json')
root = OUT / 'format-strategy-full43-908/logs/full43_20261022T014521046967Z'
summary = read(root / 'summary.json')
records = summary['records']
for key in ('complete', 'timing_available', 'full_result_validation',
            'completed_identity_check', 'reference_packet_identity_verified',
            'harness_identity_verified'):
    assert summary[key] is True, key
assert summary['timing_metric'] == 'engine_execution_seconds'
assert summary['repeats'] == 1
assert [record['query'] for record in records] == list(range(1, 44))
assert all(record['run'] == 1 and record['passed'] and record['returncode'] == 0
           and not record['guard_failures'] and record['validation'] == 'complete_values'
           for record in records)
command = plan['command']
query_path = (Path(command[command.index('--queries') + 1]) if '--queries' in command
              else ROOT / 'benchmarks/clickbench/queries.sql')
reference = load_reference_packet(Path(plan['reference']['path']), query_path)
assert identity(plan['reference']['path']) == plan['reference']
checked = []
for record in records:
    archives = record['completed_log_archives']
    assert len(archives) == 1
    archive = archives[0]
    raw = gzip.decompress(Path(archive['path']).read_bytes())
    assert identity(archive['path'])['sha256'] == archive['gzip_sha256']
    assert hashlib.sha256(raw).hexdigest() == archive['raw_sha256']
    assert len(raw) == archive['raw_bytes']
    report = json.loads(raw)
    values, fields = extract_result(report), report_fields(report)
    assert equivalent(values, reference['values'][record['query']]), record['query']
    for name in ('public_workflow_fallback_attempted', 'public_workflow_external_engine_invoked'):
        assert fields[name] == 'false'
    assert hashlib.sha256(json.dumps(values, sort_keys=True, allow_nan=False).encode()).hexdigest() == record['result_sha256']
    assert math.isfinite(record['engine_execution_seconds']) and record['engine_execution_seconds'] >= 0
    checked.append(dict(query=record['query'], engine_execution_seconds=record['engine_execution_seconds'],
                        rows=len(values), values=values, result_sha256=record['result_sha256'],
                        envelope=identity(archive['path']), fallback_attempted=False,
                        external_engine_invoked=False))
assert sum(record['rows'] for record in checked) == 381
engine = sum(record['engine_execution_seconds'] for record in records)
assert math.isclose(engine, summary['query_total_seconds'], abs_tol=1e-12)
timing = list(csv.DictReader((root / 'query-timings.csv').open()))
assert len(timing) == 43
for path, digest in summary['harness_sha256'].items():
    assert identity(path)['sha256'] == digest
for name in ('process_group_drained', 'direct_child_reaped', 'uat_lock_released',
             'source_unchanged', 'pre_input_hash_verified', 'post_input_hash_verified'):
    assert run[name] is True
for key in ('log', 'plan'):
    assert identity(run[key]['path']) == run[key]
assert not (OUT / 'format-strategy-full43-908/.ingest-uat.lock').exists()
assert verify() == frozen
proof = dict(status='passed', source_commit=frozen['head'],
             summary=identity(root / 'summary.json'),
             plan=identity(OUT / 'format-strategy-full43-plan-908.json'),
             run=identity(OUT / 'format-strategy-full43-run-908.json'),
             query_timing_csv=identity(root / 'query-timings.csv'),
             helper=identity(__file__), queries=43, repeats=1, rows=381,
             engine_execution_seconds=engine, reference_kind=summary['reference_kind'],
             reference=reference['packet'], records=checked)
save(OUT / 'format-strategy-full43-independent-verification-908.json', proof)
print(json.dumps({key: proof[key] for key in ('status', 'queries', 'repeats', 'rows', 'engine_execution_seconds', 'reference_kind')}))
