"""Source-frozen selection accounting checks, strictly serial and supervised."""
import argparse
import json
import re
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sha, sources, save


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', default='406')
    args = parser.parse_args()
    assert args.attempt.replace('-', '').isalnum()
    frozen = dict(head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                  source_sha256=sources())
    source_path = OUT / f'selection-check-source-{args.attempt}.json'
    save(source_path, frozen)
    checks = [
        ('fmt', 180, ['cargo', 'fmt', '--all', '--', '--check']),
        ('vendor-fmt', 180, ['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--check',
            'vendor/vortex-zstd/src/array.rs', 'vendor/vortex-zstd/src/decoder_workspace.rs',
            'vendor/vortex-zstd/src/lib.rs', 'vendor/vortex-zstd/src/rules.rs']),
        ('license-bundle', 180, [sys.executable, '-B', 'scripts/check_python_license_bundle.py']),
        ('release-clippy', 1200, ['cargo', 'clippy', '--offline', '--locked', '-p', 'shardloom-vortex',
            '-p', 'shardloom-cli', '--all-targets', '--features', 'release-user-surfaces', '--', '-D', 'warnings']),
        ('read-clippy', 1200, ['cargo', 'clippy', '--offline', '--locked', '-p', 'shardloom-vortex',
            '-p', 'shardloom-cli', '--all-targets', '--features', 'vortex-local-primitives', '--', '-D', 'warnings']),
        ('workspace-clippy', 1200, ['cargo', 'clippy', '--workspace', '--all-targets', '--', '-D', 'warnings']),
        ('workspace-tests', 1800, ['cargo', 'test', '--workspace', '--all-targets', '--', '--test-threads=2']),
        ('native-tests', 3600, ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-vortex',
            '-p', 'shardloom-cli', '--all-targets', '--features',
            'vortex-local-primitives,vortex-write,universal-format-io', '--', '--test-threads=2']),
    ]
    completed = []
    failure = None
    try:
        for name, timeout, command in checks:
            assert sources() == frozen['source_sha256'], 'selection sources changed during checks'
            guard_name = f'native-selection-{name}-{args.attempt}'
            subprocess.run([sys.executable, '-B', str(OUT / 'run_guarded.py'), '--name', guard_name,
                '--timeout', str(timeout), '--', *command], cwd=ROOT, check=True)
            path = OUT / f'{guard_name}.json'
            receipt = json.loads(path.read_text())
            log = path.with_suffix('.log')
            assert receipt['status'] == 'passed' and receipt['process_group_drained']
            assert sha(log) == receipt['log_sha256']
            rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log.read_text())
            item = dict(name=name, command=command, receipt=str(path), receipt_sha256=sha(path),
                        seconds=receipt['seconds'], log=str(log), log_sha256=sha(log))
            if name.endswith('tests'):
                assert rows and all(int(f) == 0 and int(i) == 0 for _, f, i in rows)
                item['tests'] = dict(passed=sum(int(p) for p, _, _ in rows), failed=0, ignored=0,
                                     groups=len(rows))
            completed.append(item)
        assert sources() == frozen['source_sha256']
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        report = dict(schema_version='shardloom.selection_local_checks.v1',
                      status='passed' if len(completed) == len(checks) and failure is None else 'failed',
                      source_manifest=str(source_path), source_manifest_sha256=sha(source_path),
                      source_files=len(frozen['source_sha256']), completed=completed,
                      failure=failure, next_check=checks[len(completed)][0] if len(completed) < len(checks) else None,
                      runtime_source_unchanged=sources() == frozen['source_sha256'])
        save(OUT / f'selection-checks-{args.attempt}.json', report)
        print(json.dumps(report, indent=2), flush=True)


if __name__ == '__main__':
    main()
