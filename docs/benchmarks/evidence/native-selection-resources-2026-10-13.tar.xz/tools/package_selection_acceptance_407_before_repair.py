"""Prepare a compact, hash-verified selection-resource acceptance evidence package.

This helper is intentionally not run during preparation. It requires the named
final acceptance gates, refuses to overwrite any output, caps archived raw
evidence at 128 MiB, excludes binaries and bulk data, and verifies every tar
member by streaming it back before publishing the package.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import tarfile
from dataclasses import dataclass, field

O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
REPO = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
UAT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
BASE = '528aa23ed7f09442b664bc07ca44b5c48a8d5c0f'
CHECKS = O / 'selection-checks-final-407.json'
RUNTIME = O / 'selection-runtime-406.json'
FULL43_REVIEW = O / 'selection-resources-full43-primary-review-406.json'
COST_SUMMARY = UAT / 'logs/selection-cost-pairs-406/summary.json'
SOURCE_MANIFEST = O / 'selection-resources-406-source.json'
RELEASE_MANIFEST = O / 'selection-resources-406-release.json'
NATIVE_MANIFEST = O / 'selection-native-artifacts-406.json'
PROTOCOL = O / 'selection-cost-protocol-406.json'
FROZEN_COST = O / 'selection-cost-frozen-406.json'
PUBLIC_ROOT = O / 'selection-public-406'
HELPER = Path(__file__).resolve()
ARCHIVE = O / 'selection-resources-evidence-407.tar.xz'
MANIFEST = O / 'selection-resources-evidence-407.manifest.json'
VERIFICATION = O / 'selection-resources-evidence-407.verification.json'
PARTIAL = O / '.selection-resources-evidence-407.tar.xz.partial'
MANIFEST_PARTIAL = O / '.selection-resources-evidence-407.manifest.json.partial'
VERIFY_PARTIAL = O / '.selection-resources-evidence-407.verification.json.partial'
MAX_RAW_BYTES = 128 * 1024 * 1024
CHUNK = 4 * 1024 * 1024
GIB = 1024 ** 3
MIB = 1024 ** 2
MAX_LOG_BYTES = 1024 * MIB
sys.path.insert(0, str(REPO / 'scripts'))
from local_uat_storage import check_budgets, require_local_path  # noqa: E402


class NeedsReasoning(ValueError):
    """A missing, inconsistent, or ambiguous acceptance input needs review."""


def need(test: bool, message: str) -> None:
    if not test:
        raise NeedsReasoning(message)


def sha_stream(stream) -> tuple[int, str]:
    digest = hashlib.sha256()
    size = 0
    while True:
        data = stream.read(CHUNK)
        if not data:
            break
        size += len(data)
        digest.update(data)
    return size, digest.hexdigest()


def sha_file(path: Path) -> tuple[int, str]:
    with path.open('rb') as stream:
        return sha_stream(stream)


def read_json(path: Path):
    return json.loads(path.read_text())


def regular(path: Path) -> Path:
    info = path.lstat()
    need(stat.S_ISREG(info.st_mode) and not stat.S_ISLNK(info.st_mode),
         f'expected a regular non-symlink file: {path}')
    return path.resolve(strict=True)


def verify(path: Path, expected_sha: str | None = None,
           expected_size: int | None = None) -> tuple[int, str]:
    regular(path)
    before = path.stat()
    size, digest = sha_file(path)
    after = path.stat()
    identity_before = (before.st_dev, before.st_ino, before.st_size,
                       before.st_mtime_ns, before.st_ctime_ns)
    identity_after = (after.st_dev, after.st_ino, after.st_size,
                      after.st_mtime_ns, after.st_ctime_ns)
    need(identity_before == identity_after and size == after.st_size,
         f'file changed while hashing: {path}')
    need(expected_sha is None or digest == expected_sha,
         f'SHA-256 mismatch for {path}')
    need(expected_size is None or size == expected_size,
         f'byte-count mismatch for {path}')
    return size, digest


@dataclass
class Item:
    path: Path
    name: str
    root_key: str
    relative: str
    size: int
    digest: str
    roles: list[str] = field(default_factory=list)


class Members:
    def __init__(self) -> None:
        self.paths: dict[Path, Item] = {}
        self.names: dict[str, Path] = {}

    def add(self, path: Path, name: str, root_key: str, root: Path,
            role: str, expected_sha: str | None = None,
            expected_size: int | None = None) -> Item:
        resolved = regular(path)
        member_name = PurePosixPath(name)
        need(not member_name.is_absolute() and '..' not in member_name.parts and
             bool(member_name.parts), f'unsafe archive member name: {name}')
        name = member_name.as_posix()
        prior = self.paths.get(resolved)
        if prior:
            need(expected_sha is None or prior.digest == expected_sha,
                 f'conflicting expected hash for {path}')
            need(expected_size is None or prior.size == expected_size,
                 f'conflicting expected size for {path}')
            prior.roles.append(role)
            return prior
        need(name not in self.names, f'archive member name collision: {name}')
        size, digest = verify(path, expected_sha, expected_size)
        try:
            relative = resolved.relative_to(root.resolve()).as_posix()
        except ValueError:
            relative = path.name
        item = Item(resolved, name, root_key, relative, size, digest, [role])
        self.paths[resolved] = item
        self.names[name] = resolved
        return item

    def tree(self, root: Path, prefix: str, root_key: str, role: str,
             excluded: list[dict], *, omit_outputs: bool = False) -> None:
        regular_root = root.resolve(strict=True)
        need(root.is_dir() and not root.is_symlink(), f'expected evidence directory: {root}')
        pending = [root]
        while pending:
            directory = pending.pop()
            with os.scandir(directory) as scan:
                entries = sorted(scan, key=lambda e: e.name, reverse=True)
            for entry in entries:
                path = Path(entry.path)
                need(not entry.is_symlink(), f'symlink in evidence tree: {path}')
                if entry.is_dir(follow_symlinks=False):
                    if omit_outputs and entry.name == 'outputs':
                        excluded.extend(excluded_tree(path, f'{prefix}/{path.relative_to(root).as_posix()}'))
                    else:
                        pending.append(path)
                    continue
                need(entry.is_file(follow_symlinks=False), f'unsupported tree entry: {path}')
                rel = path.relative_to(root).as_posix()
                suffix = path.suffix.lower()
                if suffix in {'.vortex', '.parquet', '.arrow', '.ipc'} or is_binary_name(path.name):
                    excluded.append(excluded_identity(path, f'{prefix}/{rel}', 'bulk or executable data excluded'))
                    continue
                self.add(path, f'{prefix}/{rel}', root_key, regular_root, role)


def is_binary_name(name: str) -> bool:
    lowered = name.lower()
    return (lowered.endswith(('.dylib', '.so', '.dll', '.exe', '.bin')) or
            lowered.endswith(('.a', '.rlib', '.o')) or lowered.startswith('shardloom-'))


def excluded_identity(path: Path, logical_name: str, reason: str) -> dict:
    size, digest = verify(path)
    return dict(archive_path=logical_name, original_absolute_path=str(path),
                byte_count=size, sha256=digest, reason=reason)


def excluded_tree(root: Path, prefix: str) -> list[dict]:
    rows = []
    pending = [root]
    while pending:
        directory = pending.pop()
        with os.scandir(directory) as scan:
            entries = sorted(scan, key=lambda e: e.name, reverse=True)
        for entry in entries:
            path = Path(entry.path)
            need(not entry.is_symlink(), f'symlink in excluded payload tree: {path}')
            logical = prefix + '/' + path.relative_to(root).as_posix()
            if entry.is_dir(follow_symlinks=False):
                pending.append(path)
            elif entry.is_file(follow_symlinks=False):
                rows.append(excluded_identity(path, logical, 'public outputs payload excluded'))
            else:
                raise NeedsReasoning(f'unsupported output payload entry: {path}')
    return rows


def bound(record: dict, label: str) -> tuple[Path, str, int]:
    need(isinstance(record, dict) and {'path', 'sha256', 'bytes'} <= record.keys(),
         f'{label} lacks path/hash/byte identity')
    path = Path(record['path'])
    need(path.is_absolute(), f'{label} path must be absolute')
    return path, record['sha256'], record['bytes']


def receipt_pair(path: Path, members: Members, prefix: str,
                 expected_status: str | None = None) -> dict:
    receipt = read_json(path)
    need(receipt.get('status') in {'passed', 'failed'}, f'unknown receipt status: {path}')
    need(expected_status is None or receipt['status'] == expected_status,
         f'unexpected receipt status for {path}')
    need(receipt.get('process_group_drained') is True and
         receipt.get('direct_child_reaped') is True,
         f'process cleanup is not affirmatively recorded: {path}')
    log_path = path.with_suffix('.log')
    need(isinstance(receipt.get('log_sha256'), str), f'no log hash in receipt: {path}')
    members.add(path, f'{prefix}/{path.name}', 'out', O, 'guard receipt; failures retained')
    members.add(log_path, f'{prefix}/{log_path.name}', 'out', O,
                'guard log matching receipt SHA-256', receipt['log_sha256'])
    return receipt


def add_bound_file(members: Members, record: dict, logical: str,
                   role: str, label: str) -> Path:
    path, digest, size = bound(record, label)
    members.add(path, logical, 'external', path.parent, role, digest, size)
    return path


def add_frozen_identity(members: Members, record: dict, logical_prefix: str,
                        label: str, excluded: list[dict],
                        role: str = 'frozen cost/build input') -> None:
    path, digest, size = bound(record, label)
    if is_binary_name(path.name) or path.suffix.lower() in {'.vortex', '.parquet'}:
        excluded.append(dict(path=str(path), byte_count=size, sha256=digest,
                             identity_source='frozen protocol; excluded bytes not reopened',
                             reason=f'{label}: binary or bulk input excluded'))
    else:
        members.add(path, f'{logical_prefix}/{path.name}', 'external', path.parent,
                    role, digest, size)


def source_overlay(members: Members, final_source: dict) -> dict:
    source_map = final_source.get('source_sha256')
    need(isinstance(source_map, dict) and len(source_map) == 2240,
         'final source map must contain exactly the accepted 2240 selected files')
    need(final_source.get('head') == BASE, 'final source map is not bound to required base')
    for rel, digest in source_map.items():
        safe = PurePosixPath(rel)
        need(not safe.is_absolute() and '..' not in safe.parts,
             f'unsafe source path in final source map: {rel}')
        path = REPO.joinpath(*safe.parts)
        verify(path, digest)

    changed = subprocess.check_output(
        ['git', 'diff', '--name-only', BASE, '--'], cwd=REPO, text=True).splitlines()
    deleted = subprocess.check_output(
        ['git', 'diff', '--diff-filter=D', '--name-only', BASE, '--'], cwd=REPO, text=True).splitlines()
    untracked = subprocess.check_output(
        ['git', 'ls-files', '--others', '--exclude-standard'], cwd=REPO, text=True).splitlines()
    current_overlay = sorted(set(changed + untracked) - set(deleted))
    workflow = '.github/workflows/ci.yml'
    selected = sorted(set(current_overlay) & set(source_map))
    unbound = sorted(set(current_overlay) - set(selected) - {workflow})
    need(not unbound,
         f'working-tree overlay paths absent from final source map: {unbound}')
    workflow_path = REPO / workflow
    workflow_sha = final_source.get('workflow_sha256')
    need(workflow in current_overlay and isinstance(workflow_sha, str),
         'current .github/workflows/ci.yml overlay lacks its final recorded identity')
    members.add(workflow_path, f'source-overlay/{workflow}', 'repository', REPO,
                'current CI workflow explicitly bound by final check source manifest', workflow_sha)

    capture_paths = [O / f'selection-source-405-{suffix}' / 'source.json'
                     for suffix in ('first', 'second', 'third')]
    capture_records = [read_json(path) for path in capture_paths]
    deleted_sets = [record.get('deleted') for record in capture_records]
    need(all(isinstance(items, list) for items in deleted_sets) and
         deleted_sets[0] == deleted_sets[1] == deleted_sets[2],
         'three source captures disagree about deleted paths')
    captured_deleted = sorted(deleted_sets[0])
    need(captured_deleted == sorted(deleted),
         'exact base-relative deleted path list differs from the three frozen captures')
    need('vendor/vortex-zstd/src/filter.rs' in captured_deleted,
         'required deleted vendor filter path is absent')
    for rel in selected:
        path = REPO / rel
        members.add(path, f'source-overlay/{rel}', 'repository', REPO,
                    'current selected source overlay relative to base commit', source_map[rel])
    return dict(base_commit=BASE, selected_source_files=len(source_map),
                changed_or_added_selected_paths=selected,
                deleted_paths=captured_deleted,
                current_workflow_included=True,
                workflow_sha256=workflow_sha)


def main() -> None:
    for path in (ARCHIVE, MANIFEST, VERIFICATION, PARTIAL, MANIFEST_PARTIAL, VERIFY_PARTIAL):
        need(not path.exists() and not path.is_symlink(),
             f'refusing to replace existing package output: {path}')

    FINAL_SOURCE_MAP = O / 'selection-check-source-final-407.json'
    for path in (CHECKS, RUNTIME, FULL43_REVIEW, COST_SUMMARY, SOURCE_MANIFEST,
                 RELEASE_MANIFEST, NATIVE_MANIFEST, PROTOCOL, FROZEN_COST):
        need(path.is_file(), f'acceptance prerequisite is not ready: {path}')
        verify(path)
    checks = read_json(CHECKS)
    runtime = read_json(RUNTIME)
    review = read_json(FULL43_REVIEW)
    cost = read_json(COST_SUMMARY)
    need(checks.get('status') == 'passed', 'selection-checks-final-407 is not passed')
    need(runtime.get('status') == 'passed', 'selection-runtime-406 is not passed')
    need(review.get('status') == 'passed' and review.get('calls') == 129 and
         review.get('all_values_and_schemas_reopened') is True,
         'Full43 primary review must pass all 129 calls with every value checked')
    need(cost.get('status') == 'passed' and
         cost.get('decision') == 'within_predeclared_cost_bounds',
         'cost gate is not passed within its predeclared bounds; NEEDS_REASONING')

    source = read_json(SOURCE_MANIFEST)
    release = read_json(RELEASE_MANIFEST)
    native = read_json(NATIVE_MANIFEST)
    need(release.get('status') == 'passed' and native.get('status') == 'passed',
         'release/native artifact manifests are not passed')
    need(release.get('source_sha256') == source.get('source_sha256') ==
         native.get('source_sha256'), 'release/native manifests disagree with source manifest')
    need(runtime.get('manifest') == str(NATIVE_MANIFEST) and
         runtime.get('manifest_sha256') == verify(NATIVE_MANIFEST)[1],
         'runtime summary does not bind the native artifact manifest')

    members = Members()
    exclusions: list[dict] = []
    selected_top = [
        SOURCE_MANIFEST, RELEASE_MANIFEST, NATIVE_MANIFEST, CHECKS,
        O / 'selection-checks-reconciled-407.json', O / 'selection-checks-406.json',
        O / 'selection-check-source-406.json', FINAL_SOURCE_MAP,
        O / 'selection-direct-406.json', RUNTIME,
    ]
    for path in selected_top:
        members.add(path, f'acceptance/{path.name}', 'out', O,
                    'source, release, native artifact, check, direct, or runtime record')

    attempt = re.compile(r'^native-selection-.*-(?:405|405-2|405-3|406|407|407b)\.(?:json|log)$')
    receipt_paths = sorted(p for p in O.glob('native-selection-*')
                           if p.suffix == '.json' and attempt.fullmatch(p.name))
    need(bool(receipt_paths), 'no approved numbered native-selection receipts were found')
    for receipt_path in receipt_paths:
        receipt_pair(receipt_path, members, 'guard-receipts')
    receipt_stems = {path.stem for path in receipt_paths}
    for log_path in sorted(p for p in O.glob('native-selection-*.log')
                           if attempt.fullmatch(p.name) and p.stem not in receipt_stems):
        members.add(log_path, f'guard-receipts/{log_path.name}', 'out', O,
                    'approved numbered native-selection log without a same-stem receipt')
    # Include source-capture guard receipts only when explicitly named in source-capture records.
    for capture in read_json(O / 'selection-source-405-first/source.json'), \
                   read_json(O / 'selection-source-405-second/source.json'), \
                   read_json(O / 'selection-source-405-third/source.json'):
        for key in ('guard_receipt', 'capture_receipt'):
            entry = capture.get(key)
            if entry:
                path, digest, size = bound(entry, f'source capture {key}')
                verify(path, digest, size)
                receipt_pair(path, members, 'source-capture-guards')

    for directory in ('selection-source-405-first', 'selection-source-405-second',
                      'selection-source-405-third', 'selection-test-supplement-407-before'):
        members.tree(O / directory, f'source-captures/{directory}', 'out',
                     'frozen source capture')
    for directory in ('selection-check-supplement-407', 'selection-check-docs-407b'):
        root = O / directory
        need(root.is_dir(), f'missing check evidence directory: {root}')
        for path in sorted(root.rglob('*')):
            if not path.is_file() or path.is_symlink():
                continue
            rel = path.relative_to(root).as_posix()
            if directory == 'selection-check-supplement-407' and rel.startswith('vortex-zstd/'):
                # Duplicate vendor source tree is retained in the exact source overlay;
                # preserve only the standalone lockfile as independent test provenance.
                if rel != 'vortex-zstd/Cargo.lock':
                    continue
            members.add(path, f'check-evidence/{directory}/{rel}', 'out', root,
                        'check logs, reports, patch, or standalone Cargo.lock')

    public_summary_path = PUBLIC_ROOT / 'summary.json'
    public = read_json(public_summary_path)
    need(public.get('status') == 'passed' and isinstance(public.get('families'), list) and
         len(public['families']) == len(set(public['families'])) == 19 and
         all(item.get('status') == 'passed' for item in public.get('cases', [])),
         'selection-public-406 summary does not contain a complete passing family/case set')
    members.add(public_summary_path, 'public/selection-public-406/summary.json', 'public',
                PUBLIC_ROOT, 'complete public summary')
    members.tree(PUBLIC_ROOT / 'logs', 'public/selection-public-406/logs', 'public',
                 'complete public UAT logs')
    outputs = PUBLIC_ROOT / 'outputs'
    if outputs.exists():
        exclusions.extend(excluded_tree(outputs, 'public/selection-public-406/outputs'))

    # Full43 admission, supervisor receipt/log, and the complete summary-parent folder.
    admission_entry = review.get('admission')
    guard_entry = review.get('receipt')
    summary_entry = review.get('summary')
    admission_path = add_bound_file(members, admission_entry, 'full43/admission.json',
                                    'Full43 admission', 'Full43 admission')
    guard_path = add_bound_file(members, guard_entry, f'full43/{Path(guard_entry["path"]).name}',
                                'Full43 guard receipt', 'Full43 guard receipt')
    guard = read_json(guard_path)
    need(guard.get('status') == 'passed' and guard.get('returncode') == 0 and
         guard.get('process_group_drained') is True and guard.get('direct_child_reaped') is True,
         'Full43 guard is not a fully successful cleaned process')
    full_log = guard_path.with_suffix('.log')
    members.add(full_log, f'full43/{full_log.name}', 'external', full_log.parent,
                'Full43 guard log matching receipt SHA', guard['log_sha256'])
    summary_path, summary_sha, summary_size = bound(summary_entry, 'Full43 summary')
    summary_parent = summary_path.parent
    members.tree(summary_parent, 'full43/summary-parent', 'full43',
                 'complete Full43 summary and call logs')
    members.add(summary_path, 'full43/summary-parent/summary.json', 'full43', summary_parent,
                'Full43 summary hash/size bound by primary review', summary_sha, summary_size)
    admission = read_json(admission_path)
    for key in ('reference', 'queries', 'harness', 'driver'):
        value = admission.get(key)
        entries = value if isinstance(value, list) else [value]
        for index, entry in enumerate(entries):
            if not entry:
                continue
            add_frozen_identity(members, entry,
                f'full43/frozen-inputs/{key}/{index:03d}', f'Full43 {key}', exclusions)

    # Paired cost evidence, frozen manifests/build provenance, and helpers explicitly bound there.
    members.add(PROTOCOL, f'cost/{PROTOCOL.name}', 'out', O, 'predeclared cost protocol')
    frozen = read_json(FROZEN_COST)
    members.add(FROZEN_COST, f'cost/{FROZEN_COST.name}', 'out', O, 'frozen cost identities')
    cost_root = COST_SUMMARY.parent
    members.tree(cost_root, 'cost/selection-cost-pairs-406', 'cost',
                 'complete paired cost summary and logs')
    cost_record = read_json(COST_SUMMARY)
    need(cost_record.get('status') == 'passed' and
         cost_record.get('decision') == 'within_predeclared_cost_bounds',
         'cost summary changed or no longer meets its acceptance decision')
    for variant, identity in frozen.get('identities', {}).items():
        for kind in ('manifest', 'binary'):
            record = identity.get(kind)
            if record:
                add_frozen_identity(members, record, f'cost/frozen/{variant}/{kind}',
                                    f'{variant} {kind}', exclusions,
                                    'frozen baseline/candidate identity')
        manifest_record = identity.get('manifest')
        if manifest_record:
            manifest_path = Path(manifest_record['path'])
            manifest = read_json(manifest_path)
            cli = manifest.get('cli', {})
            receipt_path = Path(cli.get('build_receipt', ''))
            log_path = Path(cli.get('build_log', ''))
            receipt_sha = cli.get('build_receipt_sha256')
            need(receipt_path.is_absolute() and log_path.is_absolute() and receipt_sha,
                 f'{variant} frozen manifest lacks build receipt/log identities')
            members.add(receipt_path, f'cost/builds/{variant}/{receipt_path.name}',
                        'external', receipt_path.parent, f'{variant} build receipt', receipt_sha)
            receipt = read_json(receipt_path)
            need(receipt.get('status') == 'passed' and receipt.get('process_group_drained') is True and
                 receipt.get('direct_child_reaped') is True,
                 f'{variant} build receipt does not show a successful, cleaned build')
            members.add(log_path, f'cost/builds/{variant}/{log_path.name}', 'external',
                        log_path.parent, f'{variant} build log matching recorded SHA',
                        receipt['log_sha256'])
    for entry in frozen.get('helpers', []):
        add_frozen_identity(members, entry, 'cost/helpers', 'frozen cost helper', exclusions)

    final_source = read_json(FINAL_SOURCE_MAP)
    overlay = source_overlay(members, final_source)
    helper_names = (
        'run_selection_checks_406.py', 'run_selection_vendor_407.py',
        'complete_selection_checks_407.py', 'finish_selection_checks_407.py',
        'reconcile_selection_checks_407.py', 'run_selection_runtime_406.py',
        'run_selection_full43_406.py', 'measure_selection_cost_406.py',
        'capture_selection_state_405.py', 'freeze_native_release_298.py',
        'freeze_query_cli_368.py', 'run_guarded.py', 'package_selection_acceptance_407.py',
    )
    for name in helper_names:
        path = O / name
        members.add(path, f'tools/{name}', 'out', O, 'executed or acceptance packaging helper')
    # run_guarded imports these safety helpers from the repository scripts tree.
    for name in ('bounded_build_process_resume_20260912.py', 'release_validation_guard.py',
                 'local_uat_storage.py'):
        candidates = [REPO / 'scripts' / name,
                      Path('/Users/dylan/LocalData/shardloom/perf-all-20260906') / name]
        path = next((candidate for candidate in candidates if candidate.is_file()), None)
        need(path is not None, f'cannot locate run_guarded support helper {name}')
        members.add(path, f'tools/support/{name}', 'support', path.parent,
                    'guard supervisor or workload/storage guard helper')
    # Include every helper and identity explicitly frozen by the cost protocol, including
    # the paired-query harness and retained reference packet/query file.
    for entry in frozen.get('helpers', []):
        add_frozen_identity(members, entry, 'cost/frozen-helpers',
                            'helper frozen by cost protocol', exclusions)
    for key in ('query_file', 'reference_packet', 'driver'):
        if frozen.get(key):
            add_frozen_identity(members, frozen[key], f'cost/frozen-inputs/{key}',
                                f'{key} frozen by cost protocol', exclusions)
    source_identity = frozen.get('source')
    if source_identity:
        path, digest, size = bound(source_identity, 'frozen 15.7 GB cost input')
        exclusions.append(dict(path=str(path), byte_count=size, sha256=digest,
                               identity_source='selection-cost-frozen-406.json',
                               reason='15.7 GB input bytes excluded by package scope'))

    ordered = sorted(members.paths.values(), key=lambda item: item.name)
    raw_bytes = sum(item.size for item in ordered)
    need(raw_bytes <= MAX_RAW_BYTES,
         f'archived raw evidence is {raw_bytes} bytes, above 128 MiB cap')
    need(bool(ordered), 'refusing to package an empty selection evidence set')
    for root, log_root in ((O, O / 'logs'), (UAT, UAT / 'logs')):
        require_local_path(root, Path.home(), sys.platform)
        check_budgets(root, ARCHIVE, log_root, min_free_bytes=12 * GIB,
                      reserve_bytes=raw_bytes + 64 * MIB,
                      max_workspace_bytes=100 * GIB, max_log_bytes=MAX_LOG_BYTES)

    # All output publication is exclusive. The temporary archive is read back before
    # linking final names; any failure removes only the temporary files created here.
    temp_archive_created = temp_manifest_created = temp_verification_created = False
    published: list[Path] = []
    try:
        with PARTIAL.open('xb') as output:
            temp_archive_created = True
            with tarfile.open(fileobj=output, mode='w:xz', preset=6,
                              format=tarfile.PAX_FORMAT) as tar:
                for item in ordered:
                    before = item.path.stat()
                    info = tarfile.TarInfo(item.name)
                    info.size = item.size
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ''
                    with item.path.open('rb') as source_stream:
                        digest = hashlib.sha256()
                        count = 0
                        class Reader:
                            def read(self, size=-1):
                                nonlocal count
                                data = source_stream.read(size)
                                count += len(data)
                                digest.update(data)
                                return data
                        tar.addfile(info, Reader())
                    after = item.path.stat()
                    need((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) ==
                         (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns) and
                         count == item.size and digest.hexdigest() == item.digest,
                         f'archive input changed while packaging: {item.path}')

        seen: set[str] = set()
        verified_members = []
        with tarfile.open(PARTIAL, mode='r|xz') as tar:
            for info in tar:
                need(info.isfile() and info.name not in seen and info.name in members.names,
                     f'unexpected, duplicate, or non-file tar member: {info.name}')
                seen.add(info.name)
                item = members.paths[members.names[info.name]]
                stream = tar.extractfile(info)
                need(stream is not None, f'cannot read back tar member: {info.name}')
                size, digest = sha_stream(stream)
                need(size == item.size and digest == item.digest,
                     f'archive member hash/size mismatch: {info.name}')
                verify(item.path, item.digest, item.size)
                verified_members.append(dict(archive_path=info.name, byte_count=size, sha256=digest))
        need(seen == set(members.names), 'tar archive omits selected evidence members')
        archive_size, archive_sha = sha_file(PARTIAL)
        records = [dict(archive_path=item.name, logical_root=item.root_key,
                        relative_path=item.relative, original_absolute_path=str(item.path),
                        byte_count=item.size, sha256=item.digest, roles=item.roles)
                   for item in ordered]
        manifest_value = dict(
            schema='shardloom.selection_resources_evidence.v1', status='passed',
            base_commit=BASE, source_overlay=overlay,
            prerequisites=dict(checks_status=checks['status'], runtime_status=runtime['status'],
                full43_status=review['status'], full43_calls=review['calls'],
                cost_status=cost['status'], cost_decision=cost['decision']),
            archive=dict(path=str(ARCHIVE), byte_count=archive_size, sha256=archive_sha),
            raw_input_cap_bytes=MAX_RAW_BYTES, archived_raw_bytes=raw_bytes,
            member_count=len(records), members=records,
            exclusions=exclusions,
            limitations=['Binaries and bulk Vortex/Parquet/Arrow payloads are excluded; their identities are retained where available.',
                         'Packaging proves membership and byte identity only; it does not itself validate performance or correctness.'])
        manifest_bytes = (json.dumps(manifest_value, sort_keys=True, indent=2) + '\n').encode()
        with MANIFEST_PARTIAL.open('xb') as stream:
            temp_manifest_created = True
            stream.write(manifest_bytes)
        verification_value = dict(
            schema='shardloom.selection_resources_package_verification.v1', status='passed',
            archive_path=str(ARCHIVE), archive_byte_count=archive_size, archive_sha256=archive_sha,
            manifest_path=str(MANIFEST), manifest_sha256=hashlib.sha256(manifest_bytes).hexdigest(),
            member_count=len(verified_members), verified_members=verified_members,
            unique_names=len(seen), all_selected_members_verified=(seen == set(members.names)))
        verification_bytes = (json.dumps(verification_value, sort_keys=True, indent=2) + '\n').encode()
        with VERIFY_PARTIAL.open('xb') as stream:
            temp_verification_created = True
            stream.write(verification_bytes)
        os.link(PARTIAL, ARCHIVE)
        published.append(ARCHIVE)
        PARTIAL.unlink()
        temp_archive_created = False
        os.link(MANIFEST_PARTIAL, MANIFEST)
        published.append(MANIFEST)
        MANIFEST_PARTIAL.unlink()
        temp_manifest_created = False
        os.link(VERIFY_PARTIAL, VERIFICATION)
        published.append(VERIFICATION)
        VERIFY_PARTIAL.unlink()
        temp_verification_created = False
        print(json.dumps(dict(status='passed', archive=str(ARCHIVE), manifest=str(MANIFEST),
                              verification=str(VERIFICATION), member_count=len(records),
                              raw_bytes=raw_bytes, archive_bytes=archive_size,
                              archive_sha256=archive_sha), indent=2))
    except BaseException:
        for path in published:
            path.unlink(missing_ok=True)
        raise
    finally:
        if temp_archive_created:
            PARTIAL.unlink(missing_ok=True)
        if temp_manifest_created:
            MANIFEST_PARTIAL.unlink(missing_ok=True)
        if temp_verification_created:
            VERIFY_PARTIAL.unlink(missing_ok=True)


if __name__ == '__main__':
    try:
        main()
    except NeedsReasoning as error:
        raise SystemExit(f'NEEDS_REASONING: {error}') from error
    except (KeyError, TypeError, json.JSONDecodeError, FileNotFoundError) as error:
        raise SystemExit(f'NEEDS_REASONING: evidence schema or referenced input is incomplete: {error}') from error
