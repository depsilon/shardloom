"""Retain exact development source and failure identity before another edit."""
import argparse
import json
import subprocess
from freeze_native_release_298 import ROOT, OUT, save, sha, sources

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--attempt', required=True)
args = parser.parse_args()
assert args.attempt.replace('-', '').isalnum()
dest = OUT / ('selection-source-' + args.attempt)
dest.mkdir()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
frozen = sources()
changed = subprocess.check_output(['git', 'diff', '--name-only', '-z', head], cwd=ROOT).split(b'\0')
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=ROOT).split(b'\0')
overlay = {}
deleted = []
for raw in sorted(set(changed + untracked)):
    if not raw:
        continue
    name = raw.decode()
    path = ROOT / name
    if not path.is_file():
        deleted.append(name)
        continue
    if name not in frozen:
        continue
    target = dest / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(path.read_bytes())
    assert sha(target) == frozen[name]
    overlay[name] = frozen[name]
assert sources() == frozen
save(dest / 'source.json', dict(base_commit=head, source_sha256=frozen,
    overlay_sha256=overlay, deleted=deleted,
    capture_boundary='After completed development run, before subsequent source edits.'))
print(json.dumps(dict(path=str(dest), source_files=len(frozen), overlay_files=len(overlay), deleted=deleted)))
