#!/usr/bin/env python3
"""Reconcile selection-check receipts and declared Rust ignores without running tests."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import subprocess

OUT = Path("/Users/dylan/LocalData/shardloom/native-python-surface-20261010")
REPO = Path("/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo")
HEAD = "528aa23ed7f09442b664bc07ca44b5c48a8d5c0f"
SUMMARY = OUT / "selection-checks-406.json"
SOURCE_MANIFEST = OUT / "selection-check-source-406.json"
NATIVE_RECEIPT = OUT / "native-selection-native-tests-406.json"
NATIVE_LOG = OUT / "native-selection-native-tests-406.log"
OUTPUT = OUT / "selection-checks-reconciled-407.json"


def sha_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha_file(path: Path) -> str:
    return sha_bytes(path.read_bytes())


def rust_source_at_head(path: str) -> bytes:
    return subprocess.run(["git", "show", f"{HEAD}:{path}"], cwd=REPO,
                          check=True, stdout=subprocess.PIPE).stdout


def ignored_records(log_text: str) -> list[dict]:
    records = []
    for line_number, line in enumerate(log_text.splitlines(), 1):
        match = re.fullmatch(r"test (.+) \.\.\. ignored, (.+)", line)
        if match:
            records.append({"log_line_number": line_number,
                            "test": match.group(1), "reason": match.group(2),
                            "log_label": line})
    return records


def source_evidence(records: list[dict]) -> tuple[list[dict], list[str]]:
    evidence = []
    issues = []
    for item in records:
        leaf = item["test"].split("::")[-1]
        grep = subprocess.run(["git", "grep", "-n", "-F", f"fn {leaf}(", HEAD,
                              "--", "*.rs"], cwd=REPO, text=True,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        matches = [row for row in grep.stdout.splitlines() if row]
        if len(matches) != 1:
            issues.append(f"{item['test']}: expected one function definition at HEAD, found {len(matches)}")
            evidence.append({**item, "head_match_status": "ambiguous",
                             "head_match_count": len(matches)})
            continue
        _, source_path, line_text, _ = matches[0].split(":", 3)
        function_line = int(line_text)
        raw = rust_source_at_head(source_path)
        lines = raw.decode("utf-8", errors="replace").splitlines()
        begin = max(0, function_line - 7)
        window = lines[begin:function_line]
        exact_reason_lines = [begin + i + 1 for i, line in enumerate(window)
                              if item["reason"] in line]
        evidence_lines = [{"line": begin + i + 1, "text": line}
                          for i, line in enumerate(window)
                          if ("ignore" in line or "cfg_attr" in line or
                              re.search(rf"\bfn {re.escape(leaf)}\(", line))]
        if not exact_reason_lines:
            issues.append(f"{item['test']}: logged ignore reason not found immediately above HEAD source definition")
        evidence.append({**item,
                         "head_match_status": "verified" if exact_reason_lines else "reason_mismatch",
                         "source_path_at_head": source_path,
                         "function_line_at_head": function_line,
                         "source_file_sha256_at_head": sha_bytes(raw),
                         "source_file_bytes_at_head": len(raw),
                         "reason_line_numbers_at_head": exact_reason_lines,
                         "source_evidence_lines": evidence_lines})
    return evidence, issues


def main() -> int:
    original_bytes = SUMMARY.read_bytes()
    original = json.loads(original_bytes)
    frozen_bytes = SOURCE_MANIFEST.read_bytes()
    frozen = json.loads(frozen_bytes)
    issues: list[str] = []
    if sha_bytes(frozen_bytes) != original.get("source_manifest_sha256"):
        issues.append("frozen source manifest hash differs from original summary")
    if len(frozen.get("source_sha256", {})) != original.get("source_files"):
        issues.append("frozen source manifest file count differs from original summary")

    test_group_pattern = re.compile(
        r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in (.+)"
    )
    completed = []
    for entry in original.get("completed", []):
        receipt_path = Path(entry["receipt"])
        log_path = Path(entry["log"])
        receipt_bytes = receipt_path.read_bytes()
        log_bytes = log_path.read_bytes()
        receipt = json.loads(receipt_bytes)
        checks = {
            "receipt_sha_matches_original": sha_bytes(receipt_bytes) == entry.get("receipt_sha256"),
            "log_sha_matches_original": sha_bytes(log_bytes) == entry.get("log_sha256"),
            "receipt_log_sha_matches": receipt.get("log_sha256") == sha_bytes(log_bytes),
            "guard_passed": receipt.get("status") == "passed",
            "returncode_zero": receipt.get("returncode") == 0,
            "process_group_drained": receipt.get("process_group_drained") is True,
            "direct_child_reaped": receipt.get("direct_child_reaped") is True,
        }
        if not all(checks.values()):
            issues.append(f"{entry['name']}: prior receipt/log validation failed: {checks}")
        completed_item = {**entry, "receipt_bytes": len(receipt_bytes),
                          "actual_receipt_sha256": sha_bytes(receipt_bytes),
                          "log_bytes": len(log_bytes), "actual_log_sha256": sha_bytes(log_bytes),
                          "guard": {"status": receipt.get("status"),
                                    "returncode": receipt.get("returncode"),
                                    "process_group_drained": receipt.get("process_group_drained"),
                                    "direct_child_reaped": receipt.get("direct_child_reaped")},
                          "hash_and_guard_checks": checks}
        if entry["name"] == "workspace-tests":
            workspace_groups = []
            for line_number, line in enumerate(log_bytes.decode("utf-8", errors="replace").splitlines(), 1):
                match = test_group_pattern.fullmatch(line)
                if match:
                    workspace_groups.append({"log_line_number": line_number, "summary_line": line,
                                             "passed": int(match.group(1)), "failed": int(match.group(2)),
                                             "ignored": int(match.group(3)), "measured": int(match.group(4)),
                                             "filtered_out": int(match.group(5)), "finished_in": match.group(6)})
            workspace_counts = {key: sum(group[key] for group in workspace_groups)
                                for key in ("passed", "failed", "ignored", "measured", "filtered_out")}
            expected = entry.get("tests", {})
            workspace_match = (len(workspace_groups) == expected.get("groups") and
                               workspace_counts["passed"] == expected.get("passed") and
                               workspace_counts["failed"] == expected.get("failed") and
                               workspace_counts["ignored"] == expected.get("ignored"))
            if not workspace_match:
                issues.append(f"workspace-tests: exact Rust summaries differ from prior summary: {workspace_counts}")
            completed_item["rust_summary_groups"] = workspace_groups
            completed_item["rust_summary_totals"] = workspace_counts
            completed_item["rust_summary_matches_original"] = workspace_match
        completed.append(completed_item)

    native_receipt_bytes = NATIVE_RECEIPT.read_bytes()
    native_log_bytes = NATIVE_LOG.read_bytes()
    native_receipt = json.loads(native_receipt_bytes)
    native_log_text = native_log_bytes.decode("utf-8", errors="replace")
    native_checks = {
        "receipt_log_hash_matches": native_receipt.get("log_sha256") == sha_bytes(native_log_bytes),
        "receipt_status_passed": native_receipt.get("status") == "passed",
        "returncode_zero": native_receipt.get("returncode") == 0,
        "process_group_drained": native_receipt.get("process_group_drained") is True,
        "direct_child_reaped": native_receipt.get("direct_child_reaped") is True,
    }
    if not all(native_checks.values()):
        issues.append(f"native-tests receipt/log validation failed: {native_checks}")

    summary_groups = []
    for line_number, line in enumerate(native_log_text.splitlines(), 1):
        match = test_group_pattern.fullmatch(line)
        if match:
            summary_groups.append({"log_line_number": line_number, "summary_line": line,
                                   "passed": int(match.group(1)), "failed": int(match.group(2)),
                                   "ignored": int(match.group(3)), "measured": int(match.group(4)),
                                   "filtered_out": int(match.group(5)), "finished_in": match.group(6)})
    totals = {key: sum(group[key] for group in summary_groups)
              for key in ("passed", "failed", "ignored", "measured", "filtered_out")}
    ignored = ignored_records(native_log_text)
    if not summary_groups:
        issues.append("native test log contains no Rust test-result summary groups")
    if any(group["failed"] for group in summary_groups):
        issues.append("native test log contains a failing Rust summary group")
    if len(ignored) != totals["ignored"]:
        issues.append(f"ignored-name count {len(ignored)} differs from ignored summary count {totals['ignored']}")

    head_ignored, source_issues = source_evidence(ignored)
    issues.extend(source_issues)
    platform_label = "requires the non-Unix runtime branch; executed by Windows CI"
    platform_items = [x for x in head_ignored if x["reason"] == platform_label]
    helper_items = [x for x in head_ignored if x["reason"] != platform_label]
    if len(platform_items) != 3 or len(helper_items) != 24:
        issues.append(f"expected 3 non-Unix platform ignores and 24 manual/fixture helpers; got {len(platform_items)} and {len(helper_items)}")
    if any(x.get("head_match_status") != "verified" for x in head_ignored):
        issues.append("one or more ignored names/reasons are not source-bound to frozen HEAD")

    native_entry = {
        "name": "native-tests", "command": native_receipt.get("command"),
        "receipt": str(NATIVE_RECEIPT), "receipt_sha256": sha_bytes(native_receipt_bytes),
        "receipt_bytes": len(native_receipt_bytes), "seconds": native_receipt.get("seconds"),
        "log": str(NATIVE_LOG), "log_sha256": sha_bytes(native_log_bytes),
        "log_bytes": len(native_log_bytes), "tests": {"passed": totals["passed"],
            "failed": totals["failed"], "ignored": totals["ignored"],
            "groups": len(summary_groups)}, "hash_and_guard_checks": native_checks,
    }
    native_entry["guard"] = {"status": native_receipt.get("status"),
                              "returncode": native_receipt.get("returncode"),
                              "process_group_drained": native_receipt.get("process_group_drained"),
                              "direct_child_reaped": native_receipt.get("direct_child_reaped")}
    status = "passed_with_declared_skips" if not issues else "needs_reasoning"
    result = {
        "schema_version": "shardloom.selection_checks_reconciliation.v1",
        "status": status,
        "source_head_for_ignore_audit": HEAD,
        "frozen_source_manifest": {"path": str(SOURCE_MANIFEST),
                                   "sha256": sha_bytes(frozen_bytes),
                                   "source_files": len(frozen.get("source_sha256", {}))},
        "completed": completed + [native_entry],
        "native_tests": {"command_status": native_receipt.get("status"),
                         "returncode": native_receipt.get("returncode"),
                         "summary_group_count": len(summary_groups),
                         "totals": totals,
                         "summary_groups": summary_groups,
                         "ignored_total": len(ignored),
                         "ignored_platform_tests": platform_items,
                         "ignored_manual_benchmark_fixture_helpers": helper_items,
                         "all_ignored_names_and_exact_reasons_found_at_head": (
                             not source_issues and len(head_ignored) == len(ignored)),
                         "current_source_vs_frozen_source_comparison": "not required; final source binding remains primary-owned"},
        "original_failed_summary": {"path": str(SUMMARY),
                                    "sha256": sha_bytes(original_bytes),
                                    "summary": original},
        "postprocessor_failure_interpretation": {
            "classification": "helper_assertion_only",
            "detail": "run_selection_checks_406.py line 53 asserts zero ignored tests; native-tests passed, but Cargo reported declared ignored tests, so the postprocessor raised AssertionError. This is not a product/test failure.",
            "failed_native_test_claim": False,
        },
        "issues": issues,
    }
    OUTPUT.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": status, "output": str(OUTPUT),
                      "native_groups": len(summary_groups), "native_totals": totals,
                      "ignored_platform": len(platform_items), "ignored_helpers": len(helper_items),
                      "issues": issues}, indent=2))
    return 0 if not issues else 2


if __name__ == "__main__":
    raise SystemExit(main())
