"""Run independent evidence readback, Full43, and frozen paired cost checks serially."""
import subprocess
import sys
from freeze_native_release_298 import ROOT, OUT


def run(arguments):
    subprocess.run([str(value) for value in arguments], cwd=ROOT, check=True)


def guarded(name, timeout, arguments):
    run([sys.executable, '-B', OUT / 'run_guarded.py', '--name', name,
         '--timeout', timeout, '--', *arguments])


guarded('native-selection-public-review-408c', 300,
        [sys.executable, '-B', OUT / 'verify_selection_public_408.py'])
run([sys.executable, '-B', OUT / 'run_selection_full43_406.py',
     '--max-log-mib', '1024', '--max-run-log-mib', '256'])
guarded('native-selection-cost-freeze-408', 300,
        [sys.executable, '-B', OUT / 'measure_selection_cost_406.py', 'freeze',
         '--candidate', OUT / 'selection-resources-406-release.json'])
guarded('native-selection-cost-pairs-408', 1800,
        [sys.executable, '-B', OUT / 'measure_selection_cost_406.py', 'run'])
