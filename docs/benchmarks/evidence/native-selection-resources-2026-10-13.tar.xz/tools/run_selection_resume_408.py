"""Resume frozen selection acceptance with the retained Python test dependencies."""
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

from freeze_native_release_298 import ROOT, OUT, sha, sources, save

TEST_PYTHON = OUT / 'native-wheel-proof-376/venv/bin/python'
MANIFEST = OUT / 'selection-native-artifacts-406.json'
DIRECT = OUT / 'selection-direct-408.json'


def load():
    manifest = json.loads(MANIFEST.read_text())
    assert sources() == manifest['source_sha256']
    for kind in ('cli', 'binding'):
        assert sha(manifest[kind]['path']) == manifest[kind]['sha256']
    checks = json.loads(Path(manifest['checks']['path']).read_text())
    assert sha(manifest['checks']['path']) == manifest['checks']['sha256']
    assert checks['status'] == 'passed' and checks['runtime_source_unchanged']
    return manifest


def direct():
    import pyarrow
    import shardloom
    manifest = load()
    assert Path(sys.executable) == TEST_PYTHON
    assert Path(shardloom.__file__).resolve() == ROOT / 'python/src/shardloom/__init__.py'
    os.environ['SHARDLOOM_NATIVE_TEST_LIBRARY'] = manifest['binding']['path']
    os.environ['SHARDLOOM_REQUIRE_NATIVE_PYTHON'] = '1'
    os.environ['SHARDLOOM_BIN'] = manifest['cli']['path']
    suite = unittest.defaultTestLoader.discover(str(ROOT / 'python/tests'), pattern='test_native*binding.py')
    def identifiers(test):
        if isinstance(test, unittest.TestSuite):
            return [name for child in test for name in identifiers(child)]
        return [test.id()]
    names = identifiers(suite)
    assert len(names) == len(set(names)) == 80
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    passed = result.wasSuccessful() and result.testsRun == 80 and not result.skipped
    report = dict(status='passed' if passed else 'failed', tests=result.testsRun,
                  failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
                  test_names=names, manifest_sha256=sha(MANIFEST),
                  interpreter=sys.executable, python_version=sys.version,
                  pyarrow_version=pyarrow.__version__, pyarrow_file=pyarrow.__file__,
                  package_source=shardloom.__file__, helper_sha256=sha(__file__),
                  mode='direct_source_package_with_explicit_frozen_native_library',
                  installed_wheel_proof=False,
                  prior_failed_attempt=dict(summary=str(OUT / 'selection-direct-406.json'),
                      summary_sha256=sha(OUT / 'selection-direct-406.json'),
                      receipt=str(OUT / 'native-selection-direct-406.json'),
                      receipt_sha256=sha(OUT / 'native-selection-direct-406.json'),
                      cause='Test interpreter did not have the optional PyArrow dependency.'))
    assert not DIRECT.exists()
    save(DIRECT, report)
    assert load() == manifest and passed


def guarded(name, timeout, command):
    subprocess.run([sys.executable, '-B', str(OUT / 'run_guarded.py'), '--name', name,
                    '--timeout', str(timeout), '--', *map(str, command)], cwd=ROOT, check=True)


def main():
    manifest = load()
    guarded('native-selection-direct-408', 1800, [TEST_PYTHON, '-B', __file__, 'direct'])
    direct_report = json.loads(DIRECT.read_text())
    assert direct_report['status'] == 'passed' and direct_report['tests'] == 80
    public_root = OUT / 'selection-public-406'
    guarded('native-selection-public-406', 5400,
            [sys.executable, '-B', ROOT / 'scripts/run_native_streaming_input_uat.py',
             '--binary', manifest['cli']['path'], '--uat-root', public_root, '--operation-timeout', '600'])
    summary = json.loads((public_root / 'summary.json').read_text())
    assert summary['status'] == 'passed' and len(summary['families']) == len(set(summary['families'])) == 19
    assert all(case['status'] == 'passed' for case in summary['cases'])
    assert load() == manifest
    destination = OUT / 'selection-runtime-406.json'
    assert not destination.exists()
    save(destination, dict(status='passed', manifest=str(MANIFEST), manifest_sha256=sha(MANIFEST),
         direct_summary=str(DIRECT), direct_summary_sha256=sha(DIRECT),
         public_summary=str(public_root / 'summary.json'), public_summary_sha256=sha(public_root / 'summary.json'),
         public_families=summary['families'], public_cases=len(summary['cases']),
         source_identity_preserved=True, full43_and_cost_screen='pending',
         helper=str(Path(__file__).resolve()), helper_sha256=sha(__file__)))
    print(json.dumps(dict(status='passed', direct_tests=80, public_cases=len(summary['cases']), public_families=19)))


if __name__ == '__main__':
    direct() if sys.argv[1:] == ['direct'] else main()
