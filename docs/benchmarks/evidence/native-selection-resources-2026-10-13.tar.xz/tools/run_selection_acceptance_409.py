"""Finish revised source, native binding, public and complete-query acceptance."""
import json
from pathlib import Path
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sources


def call(command):
    subprocess.run([str(value) for value in command], cwd=ROOT, check=True)


def guarded(name, timeout, command):
    call([sys.executable, '-B', OUT / 'run_guarded.py', '--name', name,
          '--timeout', timeout, '--', *command])


cost = json.loads(Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat/logs/selection-cost-pairs-409/summary.json').read_text())
assert cost['status'] == 'passed' and cost['decision'] == 'within_predeclared_cost_bounds'
frozen = json.loads((OUT / 'selection-resources-409-release.json').read_text())
assert sources() == frozen['source_sha256']
guarded('native-selection-cost-review-409', 180,
        [sys.executable, '-B', OUT / 'verify_selection_cost_409.py'])
call([sys.executable, '-B', OUT / 'run_selection_checks_409.py'])
call([sys.executable, '-B', OUT / 'run_selection_runtime_409.py'])
guarded('native-selection-public-review-409', 300,
        [sys.executable, '-B', OUT / 'verify_selection_public_409.py'])
call([sys.executable, '-B', OUT / 'run_selection_full43_409.py',
      '--max-log-mib', '1024', '--max-run-log-mib', '256'])
assert sources() == frozen['source_sha256']
