"""Build frozen native artifacts and verify the public/direct selection regression."""
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

from freeze_native_release_298 import ROOT, OUT, sha, sources, save


def call(command):
    subprocess.run([str(value) for value in command], cwd=ROOT, check=True)


def guarded(name, timeout, command):
    call([sys.executable, '-B', OUT / 'run_guarded.py', '--name', name,
          '--timeout', timeout, '--', *command])


def direct():
    manifest = json.loads((OUT / 'selection-native-artifacts-406.json').read_text())
    assert sources() == manifest['source_sha256']
    for kind in ('cli', 'binding'):
        assert sha(manifest[kind]['path']) == manifest[kind]['sha256']
    os.environ['SHARDLOOM_NATIVE_TEST_LIBRARY'] = manifest['binding']['path']
    os.environ['SHARDLOOM_REQUIRE_NATIVE_PYTHON'] = '1'
    os.environ['SHARDLOOM_BIN'] = manifest['cli']['path']
    suite = unittest.defaultTestLoader.discover(str(ROOT / 'python/tests'), pattern='test_native*binding.py')
    def identifiers(test):
        if isinstance(test, unittest.TestSuite):
            return [name for child in test for name in identifiers(child)]
        return [test.id()]
    names = identifiers(suite)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    passed = result.wasSuccessful() and result.testsRun == len(names) and result.testsRun > 0 and not result.skipped
    report = dict(status='passed' if passed else 'failed', tests=result.testsRun,
                  failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
                  test_names=names, manifest_sha256=sha(OUT / 'selection-native-artifacts-406.json'),
                  mode='direct_source_package_with_explicit_frozen_native_library',
                  installed_wheel_proof=False)
    save(OUT / 'selection-direct-406.json', report)
    assert sources() == manifest['source_sha256'] and passed


def main():
    checks_path = OUT / 'selection-checks-final-407.json'
    checks = json.loads(checks_path.read_text())
    assert checks['status'] == 'passed' and checks['runtime_source_unchanged']
    accepted = json.loads(Path(checks['source_manifest']).read_text())['source_sha256']
    assert sources() == accepted
    call([sys.executable, '-B', OUT / 'freeze_query_cli_368.py', 'prepare', '--name', 'selection-resources-406'])
    guarded('native-selection-release-build-406', 2100,
            ['cargo', 'build', '--offline', '--locked', '--release', '-p', 'shardloom-cli',
             '--bin', 'shardloom', '--features', 'release-user-surfaces', '--message-format=json'])
    call([sys.executable, '-B', OUT / 'freeze_query_cli_368.py', 'freeze',
          '--name', 'selection-resources-406', '--build-receipt', OUT / 'native-selection-release-build-406.json'])
    cli_path = OUT / 'selection-resources-406-release.json'
    manifest = json.loads(cli_path.read_text())
    binding_name = 'native-selection-binding-build-406'
    guarded(binding_name, 2100,
            [sys.executable, '-B', ROOT / 'scripts/build_native_python.py', '--release', '--offline',
             '--output-dir', OUT / 'selection-native-binding-406'])
    receipt = OUT / f'{binding_name}.json'
    report = json.loads(receipt.read_text())
    log = receipt.with_suffix('.log')
    assert report['status'] == 'passed' and report['process_group_drained'] and report['direct_child_reaped']
    assert sha(log) == report['log_sha256']
    raw = log.read_text()
    start = raw.index('{\n  "schema_version": "shardloom.native_python_build.v1"')
    binding = json.loads(raw[start:])
    assert binding['status'] == 'passed' and '--release' in binding['command']
    assert sha(binding['library']) == sha(binding['cargo_artifact']) == binding['library_sha256']
    manifest.update(schema_version='shardloom.selection_native_artifacts.v1',
                    cli_manifest=dict(path=str(cli_path), sha256=sha(cli_path)),
                    checks=dict(path=str(checks_path), sha256=sha(checks_path)),
                    binding=dict(path=binding['library'], sha256=binding['library_sha256'],
                                 bytes=binding['library_bytes'], build_receipt=str(receipt),
                                 build_receipt_sha256=sha(receipt), build_log=str(log)))
    assert sources() == accepted == manifest['source_sha256']
    save(OUT / 'selection-native-artifacts-406.json', manifest)
    guarded('native-selection-direct-406', 1800, [sys.executable, '-B', __file__, 'direct'])
    public_root = OUT / 'selection-public-406'
    guarded('native-selection-public-406', 5400,
            [sys.executable, '-B', ROOT / 'scripts/run_native_streaming_input_uat.py',
             '--binary', manifest['cli']['path'], '--uat-root', public_root, '--operation-timeout', '600'])
    summary = json.loads((public_root / 'summary.json').read_text())
    assert summary['status'] == 'passed' and len(summary['families']) == len(set(summary['families'])) == 19
    assert all(case['status'] == 'passed' for case in summary['cases'])
    assert sources() == accepted and sha(manifest['cli']['path']) == manifest['cli']['sha256']
    save(OUT / 'selection-runtime-406.json', dict(status='passed',
         manifest=str(OUT / 'selection-native-artifacts-406.json'),
         manifest_sha256=sha(OUT / 'selection-native-artifacts-406.json'),
         direct_summary=str(OUT / 'selection-direct-406.json'),
         direct_summary_sha256=sha(OUT / 'selection-direct-406.json'),
         public_summary=str(public_root / 'summary.json'),
         public_summary_sha256=sha(public_root / 'summary.json'),
         public_families=summary['families'], public_cases=len(summary['cases']),
         source_identity_preserved=True, full43_and_cost_screen='pending'))
    print(json.dumps(dict(status='passed', public_cases=len(summary['cases']), public_families=19)))


if __name__ == '__main__':
    direct() if sys.argv[1:] == ['direct'] else main()
