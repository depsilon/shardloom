"""Validate the context repair, then measure a newly frozen candidate serially."""
import json
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, save, sha, sources


def call(command):
    subprocess.run([str(value) for value in command], cwd=ROOT, check=True)


def guarded(name, timeout, command):
    call([sys.executable, '-B', OUT / 'run_guarded.py', '--name', name,
          '--timeout', timeout, '--', *command])
    path = OUT / f'{name}.json'
    receipt = json.loads(path.read_text())
    assert receipt['status'] == 'passed' and receipt['direct_child_reaped'] and receipt['process_group_drained']
    assert sha(path.with_suffix('.log')) == receipt['log_sha256']
    assert sources() == frozen


frozen = sources()
save(OUT / 'selection-revision-source-409.json', dict(source_sha256=frozen))
for label in ('dictionary_preparation', 'utf8_dictionary_ownership_tests',
              'dictionary_handoff', 'scalar_distinct', 'native_zstd'):
    guarded('native-selection-adjacent-' + label.replace('_', '-') + '-409', 900,
            ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-vortex', '--lib',
             '--features', 'vortex-local-primitives,vortex-write,universal-format-io',
             label, '--', '--test-threads=2'])
guarded('native-selection-revision-clippy-409', 1200,
        ['cargo', 'clippy', '--offline', '--locked', '-p', 'shardloom-vortex',
         '-p', 'shardloom-cli', '--all-targets', '--features', 'release-user-surfaces',
         '--', '-D', 'warnings'])
call([sys.executable, '-B', OUT / 'freeze_query_cli_368.py', 'prepare',
      '--name', 'selection-resources-409'])
guarded('native-selection-release-build-409', 2100,
        ['cargo', 'build', '--offline', '--locked', '--release', '-p', 'shardloom-cli',
         '--bin', 'shardloom', '--features', 'release-user-surfaces', '--message-format=json'])
call([sys.executable, '-B', OUT / 'freeze_query_cli_368.py', 'freeze',
      '--name', 'selection-resources-409', '--build-receipt', OUT / 'native-selection-release-build-409.json'])
guarded('native-selection-cost-freeze-409', 240,
        [sys.executable, '-B', OUT / 'measure_selection_cost_409.py', 'freeze',
         '--candidate', OUT / 'selection-resources-409-release.json'])
guarded('native-selection-cost-pairs-409', 1800,
        [sys.executable, '-B', OUT / 'measure_selection_cost_409.py', 'run'])
