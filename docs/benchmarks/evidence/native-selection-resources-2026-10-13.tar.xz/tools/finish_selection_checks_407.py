"""Finish unchanged source acceptance after correcting the missing scope matrix row."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

from freeze_native_release_298 import ROOT, OUT, sha, sources, save

base = OUT / 'selection-check-supplement-407'
destination = OUT / 'selection-check-docs-407b'
destination.mkdir()
accepted_path = OUT / 'selection-checks-reconciled-407.json'
accepted = json.loads(accepted_path.read_text())
assert accepted['status'] == 'passed_with_declared_skips' and not accepted['issues']
assert len(accepted['completed']) == 8
original = json.loads((OUT / 'selection-test-supplement-407-before/source.json').read_text())
current = sources()
name = 'vendor/vortex-zstd/src/array.rs'
assert current.keys() == original['source_sha256'].keys()
assert [path for path in current if current[path] != original['source_sha256'][path]] == [name]
before = (OUT / 'selection-test-supplement-407-before' / name).read_bytes()
after = (ROOT / name).read_bytes()
assert hashlib.sha256(before).hexdigest() == original['source_sha256'][name]
marker = b'\n#[cfg(test)]\n#[expect(clippy::cast_possible_truncation)]\nmod tests {'
assert before.count(marker) == after.count(marker) == 1
assert before.split(marker)[0] == after.split(marker)[0]
assert sha(base / 'vortex-zstd/src/array.rs') == current[name]
prior = json.loads((base / 'failure.json').read_text())
assert prior['completed'][-1]['name'] == 'public-status' and prior['completed'][-1]['returncode'] == 1
assert json.loads((base / 'public-status.json').read_text())['blockers'] == [
    'v1 inclusion scope: NATIVE-SELECTION-RESOURCES: missing v1 inclusion matrix row']
completed = prior['completed'][:-1]
assert [c['name'] for c in completed] == ['vendor-tests', 'fmt', 'vendor-fmt', 'license-bundle', 'user-surface-reference']
for check in completed:
    assert check['returncode'] == 0 and sha(check['log']) == check['log_sha256']
assert re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',
                  Path(completed[0]['log']).read_text()) == [('17', '0', '0')]
for check in accepted['completed']:
    receipt = json.loads(Path(check['receipt']).read_text())
    assert sha(check['receipt']) == check['receipt_sha256']
    assert sha(check['log']) == check['log_sha256'] == receipt['log_sha256']
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
commands = [
    ('public-status', [sys.executable, '-B', 'scripts/check_public_status_docs.py', '--output', str(destination / 'public-status.json')]),
    ('use-case-backlinks', [sys.executable, '-B', 'scripts/check_use_case_backlinks.py']),
    ('contribution-governance', [sys.executable, '-B', 'scripts/check_contribution_governance.py', '--output', str(destination / 'contribution-governance.json')]),
    ('ci-gate-matrix', [sys.executable, '-B', 'scripts/check_ci_gate_matrix.py', '--output', str(destination / 'ci-gate-matrix.json')]),
    ('diff-check', ['git', 'diff', '--check']),
]
for label, command in commands:
    assert sources() == current
    log = destination / (label + '.log')
    started = time.monotonic()
    with log.open('xb') as stream:
        result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, timeout=180)
    record = dict(name=label, command=command, returncode=result.returncode,
                  seconds=time.monotonic() - started, log=str(log), log_sha256=sha(log))
    completed.append(record)
    print(json.dumps(record), flush=True)
    result.check_returncode()
assert sources() == current
source_path = OUT / 'selection-check-source-final-407.json'
save(source_path, dict(head=original['head'], source_sha256=current,
                      workflow_sha256=sha(ROOT / '.github/workflows/ci.yml')))
summary = dict(status='passed', runtime_source_unchanged=True,
    source_manifest=str(source_path), source_manifest_sha256=sha(source_path), source_files=len(current),
    runtime_checks=dict(path=str(accepted_path), sha256=sha(accepted_path),
                        native_passed=4154, native_ignored=27, workspace_passed=3219),
    ignored_tests=accepted['native_tests']['ignored_platform_tests'] + accepted['native_tests']['ignored_manual_benchmark_fixture_helpers'],
    source_supplement=dict(path=name, before_sha256=hashlib.sha256(before).hexdigest(), after_sha256=current[name],
        scope='Only the existing cfg(test) module after an identical production prefix changed; two allocator-view boundary tests and their imports added.',
        diff=str(base / 'test-only.patch'), diff_sha256=sha(base / 'test-only.patch'),
        runtime_prefix_sha256=hashlib.sha256(before.split(marker)[0]).hexdigest(),
        other_source_files_unchanged=len(current)-1, extra_runtime_suite_repeat=False),
    supplement_checks=completed, standalone_vendor_lock_sha256=sha(base / 'vortex-zstd/Cargo.lock'),
    failure_history=[str(OUT / 'selection-checks-406.json'), str(OUT / 'native-selection-vendor-test-intake-407.json'),
                     str(OUT / 'native-selection-supplement-407.json'), str(base / 'public-status.json')],
    ci_addition='Existing native_vortex_tests lane now runs the vendor array tests; hosted evidence is pending.')
save(OUT / 'selection-checks-final-407.json', summary)
print(json.dumps(dict(status='passed', source_files=len(current), supplement_checks=len(completed))), flush=True)
