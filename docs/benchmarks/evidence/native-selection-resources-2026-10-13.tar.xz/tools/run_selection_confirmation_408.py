"""Run the frozen reversed-order cost confirmation after the original completed screen."""
import subprocess
import sys
from freeze_native_release_298 import ROOT, OUT

for operation, timeout in [('freeze', 300), ('run', 1800)]:
    command = [sys.executable, '-B', str(OUT / 'measure_selection_confirmation_408.py'), operation]
    if operation == 'freeze':
        command += ['--candidate', str(OUT / 'selection-resources-406-release.json')]
    subprocess.run([sys.executable, '-B', str(OUT / 'run_guarded.py'), '--name',
                    'native-selection-cost-confirm-' + operation + '-408',
                    '--timeout', str(timeout), '--', *command], cwd=ROOT, check=True)
