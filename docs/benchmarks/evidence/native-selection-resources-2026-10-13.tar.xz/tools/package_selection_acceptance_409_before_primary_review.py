"""Prepare a compact, hash-verified selection-resource acceptance evidence package.

This helper is intentionally not run during preparation. It requires the named
final acceptance gates, refuses to overwrite any output, caps archived raw
evidence at 192 MiB, excludes binaries and bulk data, and verifies every tar
member by streaming it back before publishing the package.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import tarfile
from dataclasses import dataclass, field

O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
REPO = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
UAT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
BASE = '528aa23ed7f09442b664bc07ca44b5c48a8d5c0f'
CHECKS = O / 'selection-checks-409.json'
RUNTIME = O / 'selection-runtime-409.json'
FULL43_REVIEW = O / 'selection-resources-full43-primary-review-409.json'
COST_SUMMARY = UAT / 'logs/selection-cost-pairs-409/summary.json'
SOURCE_MANIFEST = O / 'selection-resources-409-source.json'
RELEASE_MANIFEST = O / 'selection-resources-409-release.json'
NATIVE_MANIFEST = O / 'selection-native-artifacts-409.json'
PROTOCOL = O / 'selection-cost-protocol-409.json'
FROZEN_COST = O / 'selection-cost-frozen-409.json'
COST_PRIMARY_REVIEW = O / 'selection-cost-primary-review-409.json'
PUBLIC_ROOT = O / 'selection-public-409'
PUBLIC_REVIEW = O / 'selection-public-review-409.json'
FINAL_SOURCE_MAP = O / 'selection-check-source-409.json'
OLD_PUBLIC_ROOT = O / 'selection-public-406'
OLD_PUBLIC_REVIEW = O / 'selection-public-review-408.json'
OLD_FULL43_REVIEW = O / 'selection-resources-full43-primary-review-406.json'
OLD_COST_406 = UAT / 'logs/selection-cost-pairs-406'
OLD_COST_CONFIRM_408 = UAT / 'logs/selection-cost-confirm-pairs-408'
OLD_COST_PROTOCOLS = (O / 'selection-cost-protocol-406.json',
                      O / 'selection-cost-frozen-406.json',
                      O / 'selection-cost-confirm-protocol-408.json',
                      O / 'selection-cost-confirm-frozen-408.json')
HELPER = Path(__file__).resolve()
ARCHIVE = O / 'selection-resources-evidence-409.tar.xz'
MANIFEST = O / 'selection-resources-evidence-409.manifest.json'
VERIFICATION = O / 'selection-resources-evidence-409.verification.json'
PARTIAL = O / '.selection-resources-evidence-409.tar.xz.partial'
MANIFEST_PARTIAL = O / '.selection-resources-evidence-409.manifest.json.partial'
VERIFY_PARTIAL = O / '.selection-resources-evidence-409.verification.json.partial'
# Public regression logs alone contain 145,221,770 bytes. This archive-input
# ceiling accommodates their complete immutable bytes and compact source proof;
# workspace, native-process and retained/run log storage guards are unchanged.
MAX_RAW_BYTES = 192 * 1024 * 1024
CHUNK = 4 * 1024 * 1024
GIB = 1024 ** 3
MIB = 1024 ** 2
MAX_LOG_BYTES = 1024 * MIB
sys.path.insert(0, str(REPO / 'scripts'))
sys.path.insert(0, str(O))
from local_uat_storage import check_budgets, require_local_path  # noqa: E402
from freeze_native_release_298 import sources  # noqa: E402


class NeedsReasoning(ValueError):
    """A missing, inconsistent, or ambiguous acceptance input needs review."""


def need(test: bool, message: str) -> None:
    if not test:
        raise NeedsReasoning(message)


def sha_stream(stream) -> tuple[int, str]:
    digest = hashlib.sha256()
    size = 0
    while True:
        data = stream.read(CHUNK)
        if not data:
            break
        size += len(data)
        digest.update(data)
    return size, digest.hexdigest()


def sha_file(path: Path) -> tuple[int, str]:
    with path.open('rb') as stream:
        return sha_stream(stream)


def read_json(path: Path):
    return json.loads(path.read_text())


def regular(path: Path) -> Path:
    info = path.lstat()
    need(stat.S_ISREG(info.st_mode) and not stat.S_ISLNK(info.st_mode),
         f'expected a regular non-symlink file: {path}')
    return path.resolve(strict=True)


def verify(path: Path, expected_sha: str | None = None,
           expected_size: int | None = None) -> tuple[int, str]:
    regular(path)
    before = path.stat()
    size, digest = sha_file(path)
    after = path.stat()
    identity_before = (before.st_dev, before.st_ino, before.st_size,
                       before.st_mtime_ns, before.st_ctime_ns)
    identity_after = (after.st_dev, after.st_ino, after.st_size,
                      after.st_mtime_ns, after.st_ctime_ns)
    need(identity_before == identity_after and size == after.st_size,
         f'file changed while hashing: {path}')
    need(expected_sha is None or digest == expected_sha,
         f'SHA-256 mismatch for {path}')
    need(expected_size is None or size == expected_size,
         f'byte-count mismatch for {path}')
    return size, digest


@dataclass
class Item:
    path: Path
    name: str
    root_key: str
    relative: str
    size: int
    digest: str
    roles: list[str] = field(default_factory=list)


class Members:
    def __init__(self) -> None:
        self.paths: dict[Path, Item] = {}
        self.names: dict[str, Path] = {}

    def add(self, path: Path, name: str, root_key: str, root: Path,
            role: str, expected_sha: str | None = None,
            expected_size: int | None = None) -> Item:
        resolved = regular(path)
        member_name = PurePosixPath(name)
        need(not member_name.is_absolute() and '..' not in member_name.parts and
             bool(member_name.parts), f'unsafe archive member name: {name}')
        name = member_name.as_posix()
        prior = self.paths.get(resolved)
        if prior:
            need(expected_sha is None or prior.digest == expected_sha,
                 f'conflicting expected hash for {path}')
            need(expected_size is None or prior.size == expected_size,
                 f'conflicting expected size for {path}')
            prior.roles.append(role)
            return prior
        need(name not in self.names, f'archive member name collision: {name}')
        size, digest = verify(path, expected_sha, expected_size)
        try:
            relative = resolved.relative_to(root.resolve()).as_posix()
        except ValueError:
            relative = path.name
        item = Item(resolved, name, root_key, relative, size, digest, [role])
        self.paths[resolved] = item
        self.names[name] = resolved
        return item

    def tree(self, root: Path, prefix: str, root_key: str, role: str,
             excluded: list[dict], *, omit_outputs: bool = False) -> None:
        regular_root = root.resolve(strict=True)
        need(root.is_dir() and not root.is_symlink(), f'expected evidence directory: {root}')
        pending = [root]
        while pending:
            directory = pending.pop()
            with os.scandir(directory) as scan:
                entries = sorted(scan, key=lambda e: e.name, reverse=True)
            for entry in entries:
                path = Path(entry.path)
                need(not entry.is_symlink(), f'symlink in evidence tree: {path}')
                if entry.is_dir(follow_symlinks=False):
                    if omit_outputs and entry.name == 'outputs':
                        excluded.extend(excluded_tree(path, f'{prefix}/{path.relative_to(root).as_posix()}'))
                    else:
                        pending.append(path)
                    continue
                need(entry.is_file(follow_symlinks=False), f'unsupported tree entry: {path}')
                rel = path.relative_to(root).as_posix()
                suffix = path.suffix.lower()
                if suffix in {'.vortex', '.parquet', '.arrow', '.ipc'} or is_binary_name(path.name):
                    excluded.append(excluded_identity(path, f'{prefix}/{rel}', 'bulk or executable data excluded'))
                    continue
                self.add(path, f'{prefix}/{rel}', root_key, regular_root, role)


def is_binary_name(name: str) -> bool:
    lowered = name.lower()
    return (lowered == 'shardloom' or lowered.endswith(('.dylib', '.so', '.dll', '.exe', '.bin')) or
            lowered.endswith(('.a', '.rlib', '.o')) or lowered.startswith('shardloom-'))


def excluded_identity(path: Path, logical_name: str, reason: str) -> dict:
    size, digest = verify(path)
    return dict(archive_path=logical_name, original_absolute_path=str(path),
                byte_count=size, sha256=digest, reason=reason)


def excluded_tree(root: Path, prefix: str) -> list[dict]:
    rows = []
    pending = [root]
    while pending:
        directory = pending.pop()
        with os.scandir(directory) as scan:
            entries = sorted(scan, key=lambda e: e.name, reverse=True)
        for entry in entries:
            path = Path(entry.path)
            need(not entry.is_symlink(), f'symlink in excluded payload tree: {path}')
            logical = prefix + '/' + path.relative_to(root).as_posix()
            if entry.is_dir(follow_symlinks=False):
                pending.append(path)
            elif entry.is_file(follow_symlinks=False):
                rows.append(excluded_identity(path, logical, 'public outputs payload excluded'))
            else:
                raise NeedsReasoning(f'unsupported output payload entry: {path}')
    return rows


def bound(record: dict, label: str) -> tuple[Path, str, int]:
    need(isinstance(record, dict) and {'path', 'sha256', 'bytes'} <= record.keys(),
         f'{label} lacks path/hash/byte identity')
    path = Path(record['path'])
    need(path.is_absolute(), f'{label} path must be absolute')
    return path, record['sha256'], record['bytes']


def receipt_pair(path: Path, members: Members, prefix: str,
                 expected_status: str | None = None) -> dict:
    receipt = read_json(path)
    need(receipt.get('status') in {'passed', 'failed'}, f'unknown receipt status: {path}')
    need(expected_status is None or receipt['status'] == expected_status,
         f'unexpected receipt status for {path}')
    need(receipt.get('process_group_drained') is True and
         receipt.get('direct_child_reaped') is True,
         f'process cleanup is not affirmatively recorded: {path}')
    log_path = path.with_suffix('.log')
    need(isinstance(receipt.get('log_sha256'), str), f'no log hash in receipt: {path}')
    members.add(path, f'{prefix}/{path.name}', 'out', O, 'guard receipt; failures retained')
    members.add(log_path, f'{prefix}/{log_path.name}', 'out', O,
                'guard log matching receipt SHA-256', receipt['log_sha256'])
    return receipt


def add_bound_file(members: Members, record: dict, logical: str,
                   role: str, label: str) -> Path:
    path, digest, size = bound(record, label)
    members.add(path, logical, 'external', path.parent, role, digest, size)
    return path


def add_frozen_identity(members: Members, record: dict, logical_prefix: str,
                        label: str, excluded: list[dict],
                        role: str = 'frozen cost/build input') -> None:
    path, digest, size = bound(record, label)
    if is_binary_name(path.name) or path.suffix.lower() in {'.vortex', '.parquet'}:
        excluded.append(dict(path=str(path), byte_count=size, sha256=digest,
                             identity_source='frozen protocol; excluded bytes not reopened',
                             reason=f'{label}: binary or bulk input excluded'))
    else:
        members.add(path, f'{logical_prefix}/{path.name}', 'external', path.parent,
                    role, digest, size)


def source_overlay(members: Members, final_source: dict, exclusions: list[dict]) -> dict:
    source_map = final_source.get('source_sha256')
    need(isinstance(source_map, dict) and len(source_map) == 2241,
         'final source map must contain exactly the accepted 2241 selected files')
    need(final_source.get('head') == BASE, 'final source map is not bound to required base')
    actual_sources = sources()
    need(actual_sources == source_map,
         'freeze_native_release_298.sources() does not exactly match the final 2241-file map')
    for rel, digest in actual_sources.items():
        safe = PurePosixPath(rel)
        need(not safe.is_absolute() and '..' not in safe.parts,
             f'unsafe source path in final source map: {rel}')
        path = REPO.joinpath(*safe.parts)
        verify(path, digest)

    changed = subprocess.check_output(
        ['git', 'diff', '--name-only', BASE, '--'], cwd=REPO, text=True).splitlines()
    deleted = subprocess.check_output(
        ['git', 'diff', '--diff-filter=D', '--name-only', BASE, '--'], cwd=REPO, text=True).splitlines()
    untracked = subprocess.check_output(
        ['git', 'ls-files', '--others', '--exclude-standard'], cwd=REPO, text=True).splitlines()
    current_overlay = sorted(set(changed + untracked) - set(deleted))
    workflow = '.github/workflows/ci.yml'
    selected = sorted(set(current_overlay) & set(source_map))
    other_paths = sorted(set(current_overlay) - set(selected) - {workflow})
    for rel in other_paths:
        path = REPO / rel
        need(path.is_file() and not path.is_symlink(),
             f'changed or untracked non-source path lacks a safe file identity: {rel}')
        exclusions.append(excluded_identity(path, f'repository-excluded/{rel}',
            'changed or untracked documentation/evidence outside frozen runtime source selection'))
    workflow_path = REPO / workflow
    workflow_sha = final_source.get('workflow_sha256')
    need(workflow in current_overlay and isinstance(workflow_sha, str),
         'current .github/workflows/ci.yml overlay lacks its final recorded identity')
    members.add(workflow_path, f'source-overlay/{workflow}', 'repository', REPO,
                'current CI workflow explicitly bound by final check source manifest', workflow_sha)

    capture_paths = [O / 'selection-source-rejected-cost-408/source.json',
                     O / 'selection-source-context-repro-409/source.json']
    capture_records = [read_json(path) for path in capture_paths]
    deleted_sets = [record.get('deleted') for record in capture_records]
    need(all(isinstance(items, list) for items in deleted_sets) and
         deleted_sets[0] == deleted_sets[1],
         'source captures disagree about deleted paths')
    captured_deleted = sorted(deleted_sets[0])
    need(capture_records[0].get('base_commit') == BASE and
         capture_records[0].get('source_sha256') and len(capture_records[0]['source_sha256']) == 2240 and
         capture_records[1].get('base_commit') == BASE and
         len(capture_records[1].get('source_sha256', {})) == 2241 and
         capture_records[1].get('source_sha256') == source_map,
         'latest source captures do not bind the rejected baseline and final 2241-file source map')
    need(captured_deleted == sorted(deleted),
         'exact base-relative deleted path list differs from the three frozen captures')
    need('vendor/vortex-zstd/src/filter.rs' in captured_deleted,
         'required deleted vendor filter path is absent')
    for rel in selected:
        path = REPO / rel
        members.add(path, f'source-overlay/{rel}', 'repository', REPO,
                    'current selected source overlay relative to base commit', source_map[rel])
    return dict(base_commit=BASE, selected_source_files=len(actual_sources),
                changed_or_added_selected_paths=selected,
                other_changed_or_untracked_paths=other_paths,
                deleted_paths=captured_deleted,
                current_workflow_included=True,
                workflow_sha256=workflow_sha)


def main() -> None:
    for path in (ARCHIVE, MANIFEST, VERIFICATION, PARTIAL, MANIFEST_PARTIAL, VERIFY_PARTIAL):
        need(not path.exists() and not path.is_symlink(),
             f'refusing to replace existing package output: {path}')

    for path in (CHECKS, RUNTIME, FULL43_REVIEW, COST_SUMMARY, SOURCE_MANIFEST,
                 RELEASE_MANIFEST, NATIVE_MANIFEST, PROTOCOL, FROZEN_COST,
                 COST_PRIMARY_REVIEW, PUBLIC_REVIEW, FINAL_SOURCE_MAP):
        need(path.is_file(), f'acceptance prerequisite is not ready: {path}')
        verify(path)
    checks = read_json(CHECKS)
    runtime = read_json(RUNTIME)
    review = read_json(FULL43_REVIEW)
    cost = read_json(COST_SUMMARY)
    need(checks.get('status') == 'passed' and checks.get('source_files') == 2241,
         'selection-checks-409 is not passed for the 2241-file source set')
    need(runtime.get('status') == 'passed', 'selection-runtime-409 is not passed')
    need(review.get('status') == 'passed' and review.get('calls') == 129 and
         review.get('all_values_and_schemas_reopened') is True,
         'Full43 primary review must pass all 129 calls with every value checked')
    need(cost.get('status') == 'passed' and
         cost.get('decision') == 'within_predeclared_cost_bounds',
         'cost gate is not passed within its predeclared bounds; NEEDS_REASONING')
    cost_review = read_json(COST_PRIMARY_REVIEW)
    need(cost_review.get('status') == 'passed' and
         cost_review.get('final_cost_accepted') is True,
         'selection-cost-primary-review-409 must explicitly accept final cost')
    public_review = read_json(PUBLIC_REVIEW)
    need(public_review.get('status') == 'passed' and public_review.get('cases') == 757 and
         public_review.get('families') == 19,
         'selection-public-review-409 must accept all 757 cases across 19 families')

    source = read_json(SOURCE_MANIFEST)
    release = read_json(RELEASE_MANIFEST)
    native = read_json(NATIVE_MANIFEST)
    need(len(source.get('source_sha256', {})) == 2241,
         '409 source manifest must contain the accepted 2241-file map')
    need(release.get('status') == 'passed' and native.get('status') == 'passed',
         'release/native artifact manifests are not passed')
    need(release.get('source_sha256') == source.get('source_sha256') ==
         native.get('source_sha256'), 'release/native manifests disagree with source manifest')
    need(runtime.get('manifest') == str(NATIVE_MANIFEST) and
         runtime.get('manifest_sha256') == verify(NATIVE_MANIFEST)[1],
         'runtime summary does not bind the 409 native artifact manifest')
    direct_path = Path(runtime.get('direct_summary', ''))
    direct_sha = runtime.get('direct_summary_sha256')
    need(direct_path == O / 'selection-direct-409.json' and isinstance(direct_sha, str),
         'runtime must bind the selection-direct-409 summary')
    direct = read_json(direct_path)
    need(direct.get('status') == 'passed' and direct.get('tests') == 80 and
         direct.get('failures') == 0 and direct.get('errors') == 0 and direct.get('skipped') == 0 and
         direct.get('manifest_sha256') == verify(NATIVE_MANIFEST)[1],
         'direct acceptance must pass all 80 tests without failures, errors, or skips')
    verify(direct_path, direct_sha)

    members = Members()
    exclusions: list[dict] = []
    for label, record in (
        ('409 release CLI', release.get('cli', {})),
        ('409 native CLI', native.get('cli', {})),
        ('409 native binding', native.get('binding', {})),
    ):
        if record.get('path') and record.get('sha256') and record.get('bytes') is not None:
            exclusions.append(dict(path=record['path'], byte_count=record['bytes'],
                sha256=record['sha256'], identity_source=label + ' manifest',
                reason='executable/shared library identity retained; binary bytes never archived'))
    selected_top = [
        SOURCE_MANIFEST, RELEASE_MANIFEST, NATIVE_MANIFEST, CHECKS, FULL43_REVIEW,
        COST_PRIMARY_REVIEW, PUBLIC_REVIEW,
        O / 'selection-checks-reconciled-407.json', O / 'selection-checks-406.json',
        O / 'selection-check-source-406.json', FINAL_SOURCE_MAP,
        O / 'selection-revision-source-409.json',
        O / 'selection-direct-406.json', O / 'selection-direct-408.json', direct_path, RUNTIME,
    ]
    for path in selected_top:
        members.add(path, f'acceptance/{path.name}', 'out', O,
                    'source, release, native artifact, check, direct, or runtime record')
    public_summary_record = public_review.get('summary', {})
    need(public_summary_record.get('path') == str(PUBLIC_ROOT / 'summary.json') and
         public_summary_record.get('sha256') == runtime.get('public_summary_sha256') and
         public_summary_record.get('bytes') == (PUBLIC_ROOT / 'summary.json').stat().st_size,
         'public primary review does not bind the accepted 409 public summary')

    attempt = re.compile(r'^native-selection-.*-(?:405|405-2|405-3|406|407|407b|408|408b|408c|409)\.(?:json|log)$')
    receipt_paths = sorted(p for p in O.glob('native-selection-*')
                           if p.suffix == '.json' and attempt.fullmatch(p.name))
    need(bool(receipt_paths), 'no approved numbered native-selection receipts were found')
    for receipt_path in receipt_paths:
        receipt_pair(receipt_path, members, 'guard-receipts')
    receipt_stems = {path.stem for path in receipt_paths}
    for log_path in sorted(p for p in O.glob('native-selection-*.log')
                           if attempt.fullmatch(p.name) and p.stem not in receipt_stems):
        members.add(log_path, f'guard-receipts/{log_path.name}', 'out', O,
                    'approved numbered native-selection log without a same-stem receipt')
    # Include source-capture guard receipts only when explicitly named in source-capture records.
    for capture in read_json(O / 'selection-source-405-first/source.json'), \
                   read_json(O / 'selection-source-405-second/source.json'), \
                   read_json(O / 'selection-source-405-third/source.json'), \
                   read_json(O / 'selection-source-rejected-cost-408/source.json'), \
                   read_json(O / 'selection-source-context-repro-409/source.json'):
        for key in ('guard_receipt', 'capture_receipt'):
            entry = capture.get(key)
            if entry:
                path, digest, size = bound(entry, f'source capture {key}')
                verify(path, digest, size)
                receipt_pair(path, members, 'source-capture-guards')

    for directory in ('selection-source-405-first', 'selection-source-405-second',
                      'selection-source-405-third', 'selection-test-supplement-407-before',
                      'selection-source-rejected-cost-408', 'selection-source-context-repro-409'):
        members.tree(O / directory, f'source-captures/{directory}', 'out',
                     'frozen source capture', exclusions)
    for directory in ('selection-check-supplement-407', 'selection-check-docs-407b'):
        root = O / directory
        need(root.is_dir(), f'missing check evidence directory: {root}')
        for path in sorted(root.rglob('*')):
            if not path.is_file() or path.is_symlink():
                continue
            rel = path.relative_to(root).as_posix()
            if directory == 'selection-check-supplement-407' and rel.startswith('vortex-zstd/'):
                # Duplicate vendor source tree is retained in the exact source overlay;
                # preserve only the standalone lockfile as independent test provenance.
                if rel != 'vortex-zstd/Cargo.lock':
                    continue
            members.add(path, f'check-evidence/{directory}/{rel}', 'out', root,
                        'check logs, reports, patch, or standalone Cargo.lock')

    public_summary_path = PUBLIC_ROOT / 'summary.json'
    verify(public_summary_path, runtime['public_summary_sha256'])
    public = read_json(public_summary_path)
    need(public.get('status') == 'passed' and isinstance(public.get('families'), list) and
         len(public['families']) == len(set(public['families'])) == 19 and
         len(public.get('cases', [])) == 757 and
         all(item.get('status') == 'passed' for item in public.get('cases', [])),
         'selection-public-409 summary does not contain a complete passing family/case set')
    members.add(public_summary_path, 'public/selection-public-409/summary.json', 'public',
                PUBLIC_ROOT, 'complete public summary')
    members.tree(PUBLIC_ROOT / 'logs', 'public/selection-public-409/logs', 'public',
                 'complete public UAT logs', exclusions)
    outputs = PUBLIC_ROOT / 'outputs'
    if outputs.exists():
        exclusions.extend(excluded_tree(outputs, 'public/selection-public-409/outputs'))

    # The 409 public primary review is a required acceptance artifact. Preserve its
    # bound receipt and provenance while keeping the summary's complete case set.
    for key, logical in (('receipt', 'public/review-receipt'),
                         ('runtime', 'public/review-runtime'),
                         ('helper', 'public/review-helper'),
                         ('complete_case_set_comparison', 'public/review-baseline')):
        record = public_review.get(key)
        if record:
            path = add_bound_file(members, record, f'{logical}/{Path(record["path"]).name}',
                                  f'409 public review {key}', f'public review {key}')
            if key == 'receipt':
                review_receipt = read_json(path)
                need(review_receipt.get('status') == 'passed' and
                     review_receipt.get('process_group_drained') is True and
                     review_receipt.get('direct_child_reaped') is True,
                     'public review guard receipt is not passed and drained')
                log_path = path.with_suffix('.log')
                members.add(log_path, f'public/review-receipt/{log_path.name}', 'external',
                            log_path.parent, 'public review receipt log', review_receipt['log_sha256'])

    # Preserve the prior public 406 summary and 408 review as superseded evidence;
    # the bulky successful 406 raw UAT log directory remains local by explicit scope.
    old_runtime_path = O / 'selection-runtime-406.json'
    old_runtime = read_json(old_runtime_path)
    members.add(old_runtime_path, f'superseded/{old_runtime_path.name}', 'out', O,
                'superseded runtime binding for public-406 summary')
    old_public_summary = OLD_PUBLIC_ROOT / 'summary.json'
    verify(old_public_summary, old_runtime['public_summary_sha256'])
    members.add(old_public_summary, 'superseded/public-406/summary.json', 'public',
                OLD_PUBLIC_ROOT, 'superseded 406 public summary; successful historical cohort')
    old_review = read_json(OLD_PUBLIC_REVIEW)
    need(old_review.get('status') == 'passed' and old_review.get('cases') == 757 and
         old_review.get('families') == 19,
         'superseded 408 public review has unexpected status or coverage')
    members.add(OLD_PUBLIC_REVIEW, f'superseded/{OLD_PUBLIC_REVIEW.name}', 'out', O,
                'superseded public review, retained for history')
    for key in ('summary', 'runtime', 'helper', 'complete_case_set_comparison', 'receipt'):
        record = old_review.get(key)
        if not record:
            continue
        path = add_bound_file(members, record,
            f'superseded/public-review-408/{key}/{Path(record["path"]).name}',
            f'superseded public 408 review {key}', f'old public review {key}')
        if key == 'receipt':
            old_receipt = receipt_pair(path, members, 'superseded/public-review-408/receipts')
            need(old_receipt.get('status') == 'passed',
                 'superseded 408 public-review receipt was not successful')
    exclusions.append(dict(path=str(OLD_PUBLIC_ROOT / 'logs'), byte_count=None, sha256=None,
        reason='Original successful public-406 raw UAT logs remain local and are excluded by scope; this is not failed evidence. Complete public-409 logs are included.'))

    # Full43 admission, supervisor receipt/log, and the complete summary-parent folder.
    admission_entry = review.get('admission')
    guard_entry = review.get('receipt')
    summary_entry = review.get('summary')
    admission_path = add_bound_file(members, admission_entry, 'full43/admission.json',
                                    'Full43 admission', 'Full43 admission')
    guard_path = add_bound_file(members, guard_entry, f'full43/{Path(guard_entry["path"]).name}',
                                'Full43 guard receipt', 'Full43 guard receipt')
    guard = read_json(guard_path)
    need(guard.get('status') == 'passed' and guard.get('returncode') == 0 and
         guard.get('process_group_drained') is True and guard.get('direct_child_reaped') is True,
         'Full43 guard is not a fully successful cleaned process')
    full_log = guard_path.with_suffix('.log')
    members.add(full_log, f'full43/{full_log.name}', 'external', full_log.parent,
                'Full43 guard log matching receipt SHA', guard['log_sha256'])
    summary_path, summary_sha, summary_size = bound(summary_entry, 'Full43 summary')
    summary_parent = summary_path.parent
    members.tree(summary_parent, 'full43/summary-parent', 'full43',
                 'complete Full43 summary and call logs', exclusions)
    members.add(summary_path, 'full43/summary-parent/summary.json', 'full43', summary_parent,
                'Full43 summary hash/size bound by primary review', summary_sha, summary_size)
    admission = read_json(admission_path)
    for key in ('reference', 'queries', 'harness', 'driver'):
        value = admission.get(key)
        entries = value if isinstance(value, list) else [value]
        for index, entry in enumerate(entries):
            if not entry:
                continue
            add_frozen_identity(members, entry,
                f'full43/frozen-inputs/{key}/{index:03d}', f'Full43 {key}', exclusions)

    # Keep the original 406 Full43 report as superseded provenance, including its
    # exact admission, cleaned guard, and complete summary-parent tree.
    old_full43 = read_json(OLD_FULL43_REVIEW)
    need(old_full43.get('status') == 'passed' and old_full43.get('calls') == 129 and
         old_full43.get('all_values_and_schemas_reopened') is True,
         'original Full43-406 evidence does not match its recorded completed review')
    members.add(OLD_FULL43_REVIEW, f'superseded/{OLD_FULL43_REVIEW.name}', 'out', O,
                'superseded original Full43 primary review')
    old_admission = add_bound_file(members, old_full43['admission'],
        'superseded/full43-406/admission.json', 'original Full43 admission',
        'original Full43 admission')
    old_guard_path = add_bound_file(members, old_full43['receipt'],
        f'superseded/full43-406/{Path(old_full43["receipt"]["path"]).name}',
        'original Full43 guard receipt', 'original Full43 guard receipt')
    old_guard = receipt_pair(old_guard_path, members, 'superseded/full43-406/guard')
    need(old_guard.get('status') == 'passed' and old_guard.get('returncode') == 0,
         'original Full43-406 guard is not a successful historical run')
    old_summary_path, old_summary_sha, old_summary_size = bound(old_full43['summary'],
                                                                 'original Full43 summary')
    members.tree(old_summary_path.parent, 'superseded/full43-406/summary-parent',
                 'historical_full43', 'complete original Full43-406 summary/log directory',
                 exclusions)
    members.add(old_summary_path, 'superseded/full43-406/summary-parent/summary.json',
                'historical_full43', old_summary_path.parent,
                'original Full43 summary bound by review', old_summary_sha, old_summary_size)
    old_admission_record = read_json(old_admission)
    for key in ('reference', 'queries', 'harness', 'driver', 'source'):
        value = old_admission_record.get(key)
        entries = value if isinstance(value, list) else [value]
        for index, entry in enumerate(entries):
            if entry:
                add_frozen_identity(members, entry,
                    f'superseded/full43-406/inputs/{key}/{index:03d}',
                    f'original Full43 {key}', exclusions)
    historical_full43 = dict(status=old_full43['status'], calls=old_full43['calls'],
                             accepted_as_final=False,
                             reason='preserved original review; current acceptance is bound to Full43-409')

    # Paired cost evidence, frozen manifests/build provenance, and helpers explicitly bound there.
    members.add(PROTOCOL, f'cost/{PROTOCOL.name}', 'out', O, 'predeclared cost protocol')
    frozen = read_json(FROZEN_COST)
    members.add(FROZEN_COST, f'cost/{FROZEN_COST.name}', 'out', O, 'frozen cost identities')
    cost_root = COST_SUMMARY.parent
    members.tree(cost_root, 'cost/selection-cost-pairs-409', 'cost',
                 'complete paired cost summary and logs', exclusions)
    cost_record = read_json(COST_SUMMARY)
    need(cost_record.get('status') == 'passed' and
         cost_record.get('decision') == 'within_predeclared_cost_bounds',
         'cost summary changed or no longer meets its acceptance decision')
    for variant, identity in frozen.get('identities', {}).items():
        for kind in ('manifest', 'binary'):
            record = identity.get(kind)
            if record:
                add_frozen_identity(members, record, f'cost/frozen/{variant}/{kind}',
                                    f'{variant} {kind}', exclusions,
                                    'frozen baseline/candidate identity')
        manifest_record = identity.get('manifest')
        if manifest_record:
            manifest_path = Path(manifest_record['path'])
            manifest = read_json(manifest_path)
            cli = manifest.get('cli', {})
            receipt_path = Path(cli.get('build_receipt', ''))
            log_path = Path(cli.get('build_log', ''))
            receipt_sha = cli.get('build_receipt_sha256')
            need(receipt_path.is_absolute() and log_path.is_absolute() and receipt_sha,
                 f'{variant} frozen manifest lacks build receipt/log identities')
            members.add(receipt_path, f'cost/builds/{variant}/{receipt_path.name}',
                        'external', receipt_path.parent, f'{variant} build receipt', receipt_sha)
            receipt = read_json(receipt_path)
            need(receipt.get('status') == 'passed' and receipt.get('process_group_drained') is True and
                 receipt.get('direct_child_reaped') is True,
                 f'{variant} build receipt does not show a successful, cleaned build')
            members.add(log_path, f'cost/builds/{variant}/{log_path.name}', 'external',
                        log_path.parent, f'{variant} build log matching recorded SHA',
                        receipt['log_sha256'])
    for entry in frozen.get('helpers', []):
        add_frozen_identity(members, entry, 'cost/helpers', 'frozen cost helper', exclusions)

    # Preserve the completed 406 screen and 408 reversed confirmation as rejected
    # history. Completed measurement is not acceptance; the 409 review is current.
    historical_costs = []
    historical_sets = (
        ('406', O / 'selection-cost-protocol-406.json',
         O / 'selection-cost-frozen-406.json',
         UAT / 'logs/selection-cost-pairs-406/summary.json',
         'needs_reversed_confirmation'),
        ('408-confirmation', O / 'selection-cost-confirm-protocol-408.json',
         O / 'selection-cost-confirm-frozen-408.json',
         UAT / 'logs/selection-cost-confirm-pairs-408/summary.json',
         'confirmed_cost_regression'),
    )
    for label, protocol_path, frozen_path, summary_path, expected_decision in historical_sets:
        old_frozen = read_json(frozen_path)
        old_summary = read_json(summary_path)
        need(old_summary.get('status') == 'passed' and
             old_summary.get('decision') == expected_decision,
             f'historical cost cohort {label} changed its recorded decision')
        members.add(protocol_path, f'superseded/cost-{label}/{protocol_path.name}',
                    'out', O, 'superseded cost protocol')
        members.add(frozen_path, f'superseded/cost-{label}/{frozen_path.name}',
                    'out', O, 'superseded cost freeze')
        members.tree(summary_path.parent,
                     f'superseded/cost-{label}/{summary_path.parent.name}',
                     f'historical_cost_{label}', 'complete historical cost summary and logs',
                     exclusions)
        members.add(summary_path,
                    f'superseded/cost-{label}/{summary_path.parent.name}/summary.json',
                    f'historical_cost_{label}', summary_path.parent,
                    'historical cost decision summary; not final acceptance')
        for variant, identity in old_frozen.get('identities', {}).items():
            for kind in ('manifest', 'binary'):
                record = identity.get(kind)
                if record:
                    add_frozen_identity(members, record,
                        f'superseded/cost-{label}/frozen/{variant}/{kind}',
                        f'{label} {variant} {kind}', exclusions,
                        'superseded frozen cost/build identity')
            manifest_record = identity.get('manifest')
            if manifest_record:
                old_manifest = read_json(Path(manifest_record['path']))
                cli = old_manifest.get('cli', {})
                receipt_path = Path(cli.get('build_receipt', ''))
                log_path = Path(cli.get('build_log', ''))
                receipt_sha = cli.get('build_receipt_sha256')
                need(receipt_path.is_absolute() and log_path.is_absolute() and receipt_sha,
                     f'{label} {variant} manifest lacks build receipt/log identities')
                members.add(receipt_path,
                    f'superseded/cost-{label}/builds/{variant}/{receipt_path.name}',
                    'external', receipt_path.parent, f'{label} {variant} build receipt', receipt_sha)
                old_receipt = read_json(receipt_path)
                need(old_receipt.get('status') == 'passed' and
                     old_receipt.get('process_group_drained') is True and
                     old_receipt.get('direct_child_reaped') is True,
                     f'{label} {variant} build receipt lacks successful cleanup')
                members.add(log_path,
                    f'superseded/cost-{label}/builds/{variant}/{log_path.name}',
                    'external', log_path.parent, f'{label} {variant} build log',
                    old_receipt['log_sha256'])
        for entry in old_frozen.get('helpers', []):
            add_frozen_identity(members, entry, f'superseded/cost-{label}/helpers',
                f'{label} frozen helper', exclusions, 'superseded cost helper')
        for key in ('driver', 'query_file', 'reference_packet'):
            entry = old_frozen.get(key)
            if entry:
                add_frozen_identity(members, entry,
                    f'superseded/cost-{label}/inputs/{key}', f'{label} {key}',
                    exclusions, 'superseded frozen cost input')
        if old_frozen.get('source'):
            path, digest, size = bound(old_frozen['source'], f'{label} dataset')
            exclusions.append(dict(path=str(path), byte_count=size, sha256=digest,
                identity_source=f'selection-cost-frozen-{label}.json',
                reason='Vortex dataset identity retained; payload excluded'))
        historical_costs.append(dict(cohort=label,
            measurement_status=old_summary['status'], decision=old_summary['decision'],
            accepted_for_final=False))

    final_source = read_json(FINAL_SOURCE_MAP)
    need(final_source['source_sha256'] == native['source_sha256'],
         'final check source and native artifact source maps differ')
    verify(FINAL_SOURCE_MAP, checks['source_manifest_sha256'])
    overlay = source_overlay(members, final_source, exclusions)
    helper_names = (
        'run_selection_checks_406.py', 'run_selection_vendor_407.py',
        'complete_selection_checks_407.py', 'finish_selection_checks_407.py',
        'reconcile_selection_checks_407.py', 'run_selection_runtime_406.py',
        'run_selection_full43_406.py', 'measure_selection_cost_406.py',
        'capture_selection_state_405.py', 'freeze_native_release_298.py',
        'freeze_query_cli_368.py', 'run_guarded.py', 'run_selection_resume_408.py',
        'verify_selection_public_408.py', 'run_selection_post_runtime_408.py',
        'verify_selection_public_408_before_refusal_fix.py',
        'run_selection_post_runtime_408_before_refusal_fix.py',
        'verify_selection_public_408_before_count_fix.py',
        'run_selection_post_runtime_408_before_count_fix.py',
        'package_selection_acceptance_407_before_repair.py',
        'package_selection_acceptance_407.py', 'package_selection_acceptance_409.py',
        'run_selection_revision_409.py', 'run_selection_checks_409.py',
        'run_selection_runtime_409.py', 'run_selection_full43_409.py',
        'verify_selection_public_409.py', 'verify_selection_cost_409.py',
        'run_selection_acceptance_409.py', 'measure_selection_cost_409.py',
        'run_selection_confirmation_408.py', 'measure_selection_confirmation_408.py',
    )
    for name in helper_names:
        path = O / name
        members.add(path, f'tools/{name}', 'out', O, 'executed or acceptance packaging helper')
    # run_guarded imports these safety helpers from the repository scripts tree.
    support_files = (
        ('bounded_build_process_resume_20260912.py',
         Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')),
        ('release_validation_guard.py',
         Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py')),
        ('local_uat_storage.py', REPO / 'scripts/local_uat_storage.py'),
    )
    for name, path in support_files:
        need(path.is_file(), f'cannot locate exact run_guarded support helper {path}')
        members.add(path, f'tools/support/{name}', 'support', path.parent,
                    'guard supervisor or workload/storage guard helper')
    # Include every helper and identity explicitly frozen by the cost protocol, including
    # the paired-query harness and retained reference packet/query file.
    for entry in frozen.get('helpers', []):
        add_frozen_identity(members, entry, 'cost/frozen-helpers',
                            'helper frozen by cost protocol', exclusions)
    for key in ('query_file', 'reference_packet', 'driver'):
        if frozen.get(key):
            add_frozen_identity(members, frozen[key], f'cost/frozen-inputs/{key}',
                                f'{key} frozen by cost protocol', exclusions)
    source_identity = frozen.get('source')
    if source_identity:
        path, digest, size = bound(source_identity, 'frozen 15.7 GB cost input')
        exclusions.append(dict(path=str(path), byte_count=size, sha256=digest,
                               identity_source='selection-cost-frozen-409.json',
                               reason='15.7 GB input bytes excluded by package scope'))

    ordered = sorted(members.paths.values(), key=lambda item: item.name)
    raw_bytes = sum(item.size for item in ordered)
    need(raw_bytes <= MAX_RAW_BYTES,
         f'archived raw evidence is {raw_bytes} bytes, above 192 MiB cap')
    need(bool(ordered), 'refusing to package an empty selection evidence set')
    for root, log_root in ((O, O / 'logs'), (UAT, UAT / 'logs')):
        require_local_path(root, Path.home(), sys.platform)
        check_budgets(root, ARCHIVE, log_root, min_free_bytes=12 * GIB,
                      reserve_bytes=raw_bytes + 64 * MIB,
                      max_workspace_bytes=100 * GIB, max_log_bytes=MAX_LOG_BYTES)

    # All output publication is exclusive. The temporary archive is read back before
    # linking final names; any failure removes only the temporary files created here.
    temp_archive_created = temp_manifest_created = temp_verification_created = False
    published: list[Path] = []
    try:
        with PARTIAL.open('xb') as output:
            temp_archive_created = True
            with tarfile.open(fileobj=output, mode='w:xz', preset=6,
                              format=tarfile.PAX_FORMAT) as tar:
                for item in ordered:
                    before = item.path.stat()
                    info = tarfile.TarInfo(item.name)
                    info.size = item.size
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ''
                    with item.path.open('rb') as source_stream:
                        digest = hashlib.sha256()
                        count = 0
                        class Reader:
                            def read(self, size=-1):
                                nonlocal count
                                data = source_stream.read(size)
                                count += len(data)
                                digest.update(data)
                                return data
                        tar.addfile(info, Reader())
                    after = item.path.stat()
                    need((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) ==
                         (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns) and
                         count == item.size and digest.hexdigest() == item.digest,
                         f'archive input changed while packaging: {item.path}')

        seen: set[str] = set()
        verified_members = []
        with tarfile.open(PARTIAL, mode='r|xz') as tar:
            for info in tar:
                need(info.isfile() and info.name not in seen and info.name in members.names,
                     f'unexpected, duplicate, or non-file tar member: {info.name}')
                seen.add(info.name)
                item = members.paths[members.names[info.name]]
                stream = tar.extractfile(info)
                need(stream is not None, f'cannot read back tar member: {info.name}')
                size, digest = sha_stream(stream)
                need(size == item.size and digest == item.digest,
                     f'archive member hash/size mismatch: {info.name}')
                verify(item.path, item.digest, item.size)
                verified_members.append(dict(archive_path=info.name, byte_count=size, sha256=digest))
        need(seen == set(members.names), 'tar archive omits selected evidence members')
        archive_size, archive_sha = sha_file(PARTIAL)
        records = [dict(archive_path=item.name, logical_root=item.root_key,
                        relative_path=item.relative, original_absolute_path=str(item.path),
                        byte_count=item.size, sha256=item.digest, roles=item.roles)
                   for item in ordered]
        manifest_value = dict(
            schema='shardloom.selection_resources_evidence.v1', status='passed',
            base_commit=BASE, source_overlay=overlay,
            prerequisites=dict(checks_status=checks['status'], runtime_status=runtime['status'],
                full43_status=review['status'], full43_calls=review['calls'],
                full43_primary_review_status=review['status'],
                public_review_status=public_review['status'],
                public_review_cases=public_review['cases'],
                public_review_families=public_review['families'],
                cost_status=cost['status'], cost_decision=cost['decision'],
                cost_primary_review_status=cost_review['status'],
                cost_final_accepted=cost_review['final_cost_accepted']),
            historical_full43=historical_full43,
            historical_costs=historical_costs,
            archive=dict(path=str(ARCHIVE), byte_count=archive_size, sha256=archive_sha),
            raw_input_cap_bytes=MAX_RAW_BYTES, archived_raw_bytes=raw_bytes,
            member_count=len(records), members=records,
            exclusions=exclusions,
            limitations=['Binaries and bulk Vortex/Parquet/Arrow payloads are excluded; their identities are retained where available.',
                         'Packaging proves membership and byte identity only; it does not itself validate performance or correctness.'])
        manifest_bytes = (json.dumps(manifest_value, sort_keys=True, indent=2) + '\n').encode()
        with MANIFEST_PARTIAL.open('xb') as stream:
            temp_manifest_created = True
            stream.write(manifest_bytes)
        verification_value = dict(
            schema='shardloom.selection_resources_package_verification.v1', status='passed',
            archive_path=str(ARCHIVE), archive_byte_count=archive_size, archive_sha256=archive_sha,
            manifest_path=str(MANIFEST), manifest_sha256=hashlib.sha256(manifest_bytes).hexdigest(),
            member_count=len(verified_members), verified_members=verified_members,
            unique_names=len(seen), all_selected_members_verified=(seen == set(members.names)))
        verification_bytes = (json.dumps(verification_value, sort_keys=True, indent=2) + '\n').encode()
        with VERIFY_PARTIAL.open('xb') as stream:
            temp_verification_created = True
            stream.write(verification_bytes)
        os.link(PARTIAL, ARCHIVE)
        published.append(ARCHIVE)
        PARTIAL.unlink()
        temp_archive_created = False
        os.link(MANIFEST_PARTIAL, MANIFEST)
        published.append(MANIFEST)
        MANIFEST_PARTIAL.unlink()
        temp_manifest_created = False
        os.link(VERIFY_PARTIAL, VERIFICATION)
        published.append(VERIFICATION)
        VERIFY_PARTIAL.unlink()
        temp_verification_created = False
        print(json.dumps(dict(status='passed', archive=str(ARCHIVE), manifest=str(MANIFEST),
                              verification=str(VERIFICATION), member_count=len(records),
                              raw_bytes=raw_bytes, archive_bytes=archive_size,
                              archive_sha256=archive_sha), indent=2))
    except BaseException:
        for path in published:
            path.unlink(missing_ok=True)
        raise
    finally:
        if temp_archive_created:
            PARTIAL.unlink(missing_ok=True)
        if temp_manifest_created:
            MANIFEST_PARTIAL.unlink(missing_ok=True)
        if temp_verification_created:
            VERIFY_PARTIAL.unlink(missing_ok=True)


if __name__ == '__main__':
    try:
        main()
    except NeedsReasoning as error:
        raise SystemExit(f'NEEDS_REASONING: {error}') from error
    except (KeyError, TypeError, json.JSONDecodeError, FileNotFoundError) as error:
        raise SystemExit(f'NEEDS_REASONING: evidence schema or referenced input is incomplete: {error}') from error
