"""Final serial validation for the repaired aggregate execution contexts."""
import json
from pathlib import Path
import re
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sha, sources, save


def read(path):
    return json.loads(Path(path).read_text())


def bound(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def inspect_receipt(name):
    path = OUT / (name + '.json')
    receipt = read(path)
    log = path.with_suffix('.log')
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert receipt['head'] == frozen['head'] and receipt['cwd'] == str(ROOT)
    assert sha(log) == receipt['log_sha256']
    return dict(name=name, command=receipt['command'], receipt=str(path),
                receipt_sha256=sha(path), log=str(log), log_sha256=sha(log),
                seconds=receipt['seconds'])


def inspect_tests(item, native):
    raw = Path(item['log']).read_text()
    groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', raw)
    assert groups and all(int(g[1]) == int(g[3]) == int(g[4]) == 0 for g in groups)
    ignored = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', raw, re.M)
    assert sum(int(g[2]) for g in groups) == len(ignored)
    expected = read(OUT / 'selection-checks-final-407.json')['ignored_tests'] if native else []
    assert sorted(ignored) == sorted((x['test'], x['reason']) for x in expected)
    evidence = []
    for test, reason in ignored:
        prior = next(x for x in expected if x['test'] == test and x['reason'] == reason)
        name = prior['source_path_at_head']
        assert sha(ROOT / name) == frozen['source_sha256'][name]
        lines = (ROOT / name).read_text().splitlines()
        leaf = test.split('::')[-1]
        matches = [i for i, line in enumerate(lines) if re.search(r'\bfn ' + re.escape(leaf) + r'\(', line)]
        assert len(matches) == 1
        position = matches[0]
        window = lines[max(0, position - 6):position+1]
        assert any(reason in line for line in window) and any('ignore' in line for line in window)
        evidence.append(dict(test=test, reason=reason, source=name, line=position+1,
                             source_sha256=frozen['source_sha256'][name], declaration=window))
    item['tests'] = dict(passed=sum(int(g[0]) for g in groups), failed=0,
                         ignored=len(ignored), groups=len(groups), ignored_evidence=evidence)


frozen = read(OUT / 'selection-resources-409-source.json')
assert sources() == frozen['source_sha256']
assert sources() == read(OUT / 'selection-revision-source-409.json')['source_sha256']
cost = read('/Users/dylan/LocalData/shardloom/clickbench-100m-uat/logs/selection-cost-pairs-409/summary.json')
assert cost['status'] == 'passed' and cost['decision'] == 'within_predeclared_cost_bounds'
source_path = OUT / 'selection-check-source-409.json'
save(source_path, dict(**frozen, workflow_sha256=sha(ROOT / '.github/workflows/ci.yml')))
completed = [inspect_receipt('native-selection-revision-clippy-409')]
completed[0]['name'] = 'release-clippy'
completed[0]['reused_identical_source'] = bound(OUT / 'selection-revision-source-409.json')
checks = [
    ('fmt', 180, ['cargo', 'fmt', '--all', '--', '--check']),
    ('vendor-fmt', 180, ['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--check',
        'vendor/vortex-zstd/src/array.rs', 'vendor/vortex-zstd/src/decoder_workspace.rs',
        'vendor/vortex-zstd/src/lib.rs', 'vendor/vortex-zstd/src/rules.rs']),
    ('license-bundle', 180, [sys.executable, '-B', 'scripts/check_python_license_bundle.py']),
    ('read-clippy', 1200, ['cargo', 'clippy', '--offline', '--locked', '-p', 'shardloom-vortex',
        '-p', 'shardloom-cli', '--all-targets', '--features', 'vortex-local-primitives', '--', '-D', 'warnings']),
    ('workspace-clippy', 1200, ['cargo', 'clippy', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('workspace-tests', 1800, ['cargo', 'test', '--workspace', '--all-targets', '--', '--test-threads=2']),
    ('native-tests', 3600, ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-vortex',
        '-p', 'shardloom-cli', '--all-targets', '--features',
        'vortex-local-primitives,vortex-write,universal-format-io', '--', '--test-threads=2']),
]
failure = None
try:
    for label, timeout, command in checks:
        assert sources() == frozen['source_sha256']
        name = f'native-selection-{label}-409'
        subprocess.run([sys.executable, '-B', str(OUT / 'run_guarded.py'), '--name', name,
                        '--timeout', str(timeout), '--', *command], cwd=ROOT, check=True)
        item = inspect_receipt(name)
        item['name'] = label
        if label.endswith('tests'):
            inspect_tests(item, native=label == 'native-tests')
        completed.append(item)
    assert sources() == frozen['source_sha256']
except BaseException as error:
    failure = f'{type(error).__name__}: {error}'
    raise
finally:
    save(OUT / 'selection-checks-409.json', dict(status='passed' if failure is None else 'failed',
         source_manifest=str(source_path), source_manifest_sha256=sha(source_path),
         source_files=len(frozen['source_sha256']), runtime_source_unchanged=sources() == frozen['source_sha256'],
         completed=completed, failure=failure))
