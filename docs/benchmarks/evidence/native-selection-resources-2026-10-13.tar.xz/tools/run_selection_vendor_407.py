"""Test the exact vendored Zstd module in an isolated manifest outside the checkout."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sha, sources, save

before = sources()
original = ROOT / 'vendor/vortex-zstd'
destination = OUT / 'selection-zstd-vendor-tests-407'
files = [path for path in original.rglob('*') if path.is_file()]
assert sum(path.stat().st_size for path in files) < 2 << 20
assert all(not path.is_symlink() for path in files)
assert not destination.exists()
shutil.copytree(original, destination)
shutil.copy2(ROOT / 'Cargo.lock', destination / 'Cargo.lock')
copied = {str(path.relative_to(original)): sha(path) for path in files}
assert all(sha(destination / name) == digest for name, digest in copied.items())
command = ['cargo', 'test', '--offline', '--manifest-path', str(destination / 'Cargo.toml'),
           '--config', 'patch.crates-io.vortex-array.path=' + json.dumps(str(ROOT / 'vendor/vortex-array')),
           '--features', 'vortex-array/table-display', '--lib', 'array::tests::',
           '--', '--test-threads=2']
result = subprocess.run(command, cwd=ROOT, check=False)
report = dict(status='passed' if result.returncode == 0 else 'failed', returncode=result.returncode,
              command=command, copied_sources=copied,
              original_lock_sha256=sha(ROOT / 'Cargo.lock'),
              standalone_lock_sha256=sha(destination / 'Cargo.lock'),
              source_sha256=before, source_unchanged=sources() == before,
              copy_unchanged=all(sha(destination / name) == digest for name, digest in copied.items()))
save(OUT / 'selection-vendor-tests-407.json', report)
assert report['source_unchanged'] and report['copy_unchanged']
raise SystemExit(result.returncode)
