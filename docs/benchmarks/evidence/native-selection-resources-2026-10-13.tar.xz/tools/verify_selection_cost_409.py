"""Reopen every original/revised cost result and independently recompute the gates."""
import gzip
import hashlib
import json
from pathlib import Path
import statistics
import sys

from freeze_native_release_298 import ROOT, OUT, sha, save

sys.path.insert(0, str(ROOT / 'scripts'))
from native_workflow_protocol import extract_result, public_workflow_command, report_fields, strict_json
from run_clickbench_query_uat import equivalent

UAT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
CASES = [(23, 12), (23, 1), (22, 12), (21, 12), (20, 12), (29, 12)]


def read(path):
    return json.loads(Path(path).read_text())


def bound(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def verify(item):
    assert bound(item['path']) == item, item['path']


def cohort(stage, log_name, guard_name, reverse):
    logs = UAT / 'logs' / log_name
    summary_path = logs / 'summary.json'
    summary = read(summary_path)
    assert summary['status'] == 'passed' and summary['lock_released']
    verify(summary['protocol'])
    protocol = read(summary['protocol']['path'])
    assert [(c['query'], c['lanes']) for c in protocol['cases']] == CASES
    assert all(c['pairs'] == 5 for c in protocol['cases'])
    assert protocol['memory_gib'] == 24 and protocol['version'] == '0.5.1'
    expected = [dict(query=q, lanes=lanes, pair=p+1, variant=v)
                for i, (q, lanes) in enumerate(CASES) for p in range(5)
                for v in (('baseline', 'candidate') if (i+p) % 2 == 0 else ('candidate', 'baseline'))]
    if reverse:
        expected.reverse()
    records = summary['records']
    assert len(records) == 60
    assert [{key: r[key] for key in ('query', 'lanes', 'pair', 'variant')} for r in records] == expected
    for variant in ('baseline', 'candidate'):
        identity = protocol['identities'][variant]
        verify(identity['manifest'])
        verify(identity['binary'])
        manifest = read(identity['manifest']['path'])
        assert manifest['cli']['sha256'] == identity['binary']['sha256']
    guard_path = OUT / (guard_name + '.json')
    guard = read(guard_path)
    assert guard['status'] == 'passed' and guard['returncode'] == 0
    assert guard['process_group_drained'] and guard['direct_child_reaped']
    assert sha(guard_path.with_suffix('.log')) == guard['log_sha256']
    files = []
    schemas = {}
    rows = 0
    for index, record in enumerate(records):
        prefix = logs / f's{index:03d}'
        assert read(prefix.with_suffix('.result.json')) == record
        timing = read(prefix.with_suffix('.timing.json'))
        for reported, measured in [('seconds', 'seconds'), ('returncode', 'returncode'),
                                   ('native_peak_rss_bytes', 'peak_rss_bytes'),
                                   ('user_cpu_seconds', 'user_cpu_seconds'),
                                   ('system_cpu_seconds', 'system_cpu_seconds')]:
            assert record[reported] == timing[measured]
        assert record['passed'] and record['returncode'] == 0 and not record['guard_failures']
        assert record['cpu_seconds'] == record['user_cpu_seconds'] + record['system_cpu_seconds']
        query = protocol['queries'][str(record['query'])]
        assert record['command'] == public_workflow_command(
            protocol['identities'][record['variant']]['binary']['path'], query['sql'],
            input_path=Path(protocol['source']['path']), input_format='vortex',
            memory_gb=24, max_parallelism=record['lanes'])
        output = None
        for archive in record['archives']:
            path = Path(archive['path'])
            data = path.read_bytes()
            assert len(data) == archive['gzip_bytes']
            assert hashlib.sha256(data).hexdigest() == archive['gzip_sha256']
            raw = gzip.decompress(data)
            assert len(raw) == archive['raw_bytes']
            assert hashlib.sha256(raw).hexdigest() == archive['raw_sha256']
            files.append(bound(path))
            if path.name.endswith('.stdout.json.gz'):
                assert output is None
                output = strict_json(raw.decode())
        assert output is not None
        result = extract_result(output)
        fields = report_fields(output)
        assert equivalent(result, query['values']) and len(result) == record['complete_rows']
        assert hashlib.sha256(json.dumps(result, sort_keys=True).encode()).hexdigest() == record['result_sha256']
        assert fields['fallback_attempted'] == fields['external_engine_invoked'] == 'false'
        assert fields['execution_resource_declared_memory_bytes'] == str(24 << 30)
        assert fields['execution_resource_declared_max_parallelism'] == str(record['lanes'])
        assert any(c['kind'] == 'native_io_certificate' and c['status'] == 'available'
                   for c in output['certificates'])
        schema = (fields['result_schema_format'], strict_json(fields['result_schema_json']))
        assert schema == schemas.setdefault(record['query'], schema)
        rows += len(result)
    gates = []
    for (query, lanes), reported in zip(CASES, summary['gates'], strict=True):
        medians = {variant: {key: statistics.median(r[key] for r in records
                    if (r['query'], r['lanes'], r['variant']) == (query, lanes, variant))
                    for key in ('seconds', 'cpu_seconds', 'user_cpu_seconds', 'system_cpu_seconds', 'native_peak_rss_bytes')}
                    for variant in ('baseline', 'candidate')}
        assert medians == reported['medians']
        a, b = medians['baseline'], medians['candidate']
        wall = b['seconds'] <= a['seconds'] + max(a['seconds'] / 10, .005)
        cpu = b['cpu_seconds'] <= a['cpu_seconds'] + max(a['cpu_seconds'] / 10, .005)
        rss = b['native_peak_rss_bytes'] <= a['native_peak_rss_bytes'] + max(a['native_peak_rss_bytes'] / 4, 256 << 20)
        assert (wall, cpu, rss, wall and cpu and rss) == tuple(reported[k] for k in
            ('timing_passed', 'cpu_passed', 'rss_passed', 'passed'))
        gates.append(dict(query=query, lanes=lanes, wall_passed=wall, cpu_passed=cpu,
                          rss_passed=rss, medians=medians, passed=wall and cpu and rss))
    within_bounds = all(row['passed'] for row in gates)
    expected_decision = ('within_predeclared_cost_bounds' if within_bounds else
                         'confirmed_cost_regression' if reverse else 'needs_reversed_confirmation')
    assert summary['decision'] == expected_decision
    return dict(stage=stage, status='passed', calls=60, complete_rows=rows,
                summary=bound(summary_path), protocol=summary['protocol'],
                guard=bound(guard_path), decision=expected_decision, within_bounds=within_bounds,
                gates=gates, reopened_output_files=files)


if __name__ == '__main__':
    reports = [
        cohort('original', 'selection-cost-pairs-406', 'native-selection-cost-pairs-408', False),
        cohort('original_confirmation', 'selection-cost-confirm-pairs-408', 'native-selection-cost-confirm-run-408', True),
        cohort('context_repair', 'selection-cost-pairs-409', 'native-selection-cost-pairs-409', False),
    ]
    output = OUT / 'selection-cost-primary-review-409.json'
    save(output, dict(status='passed', cohorts=reports, calls=sum(r['calls'] for r in reports),
                      final_cost_accepted=reports[-1]['within_bounds'],
                      scope='Every complete result, schema, certificate, native timing, source-bound binary identity and symmetric cost gate; input hashing performed by each frozen measurement driver.'))
    print(json.dumps(dict(status='passed', report=str(output),
                         final_cost_accepted=reports[-1]['within_bounds'])))
