"""Bind the cfg(test)-only supplement to accepted runtime checks and final source."""
import difflib
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

from freeze_native_release_298 import ROOT, OUT, sha, sources, save

destination = OUT / 'selection-check-supplement-407'
destination.mkdir()
accepted_path = OUT / 'selection-checks-reconciled-407.json'
accepted = json.loads(accepted_path.read_text())
assert accepted['status'] == 'passed_with_declared_skips' and not accepted['issues']
assert len(accepted['completed']) == 8
original_path = OUT / 'selection-test-supplement-407-before/source.json'
original = json.loads(original_path.read_text())
current = sources()
name = 'vendor/vortex-zstd/src/array.rs'
assert current.keys() == original['source_sha256'].keys()
assert [path for path in current if current[path] != original['source_sha256'][path]] == [name]
before = (OUT / 'selection-test-supplement-407-before' / name).read_bytes()
after = (ROOT / name).read_bytes()
assert hashlib.sha256(before).hexdigest() == original['source_sha256'][name]
marker = b'\n#[cfg(test)]\n#[expect(clippy::cast_possible_truncation)]\nmod tests {'
assert before.count(marker) == after.count(marker) == 1
assert before.split(marker)[0] == after.split(marker)[0]
assert after.endswith(b'\n}\n') and before.endswith(b'\n}\n')
diff = ''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),
    after.decode().splitlines(keepends=True), fromfile='accepted/' + name, tofile='final/' + name))
(destination / 'test-only.patch').write_text(diff)
for check in accepted['completed']:
    receipt = json.loads(Path(check['receipt']).read_text())
    assert sha(check['receipt']) == check['receipt_sha256']
    assert sha(check['log']) == check['log_sha256'] == receipt['log_sha256']
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']

vendor = destination / 'vortex-zstd'
shutil.copytree(ROOT / 'vendor/vortex-zstd', vendor)
shutil.copy2(OUT / 'selection-zstd-vendor-tests-407/Cargo.lock', vendor / 'Cargo.lock')
assert sha(vendor / 'src/array.rs') == current[name]
vendor_command = ['cargo', 'test', '--offline', '--locked', '--manifest-path', str(vendor / 'Cargo.toml'),
    '--config', 'patch.crates-io.vortex-array.path=' + json.dumps(str(ROOT / 'vendor/vortex-array')),
    '--features', 'vortex-array/table-display', '--lib', 'array::tests::', '--', '--test-threads=2']
commands = [
    ('vendor-tests', vendor_command),
    ('fmt', ['cargo', 'fmt', '--all', '--', '--check']),
    ('vendor-fmt', ['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--check',
        'vendor/vortex-zstd/src/array.rs', 'vendor/vortex-zstd/src/decoder_workspace.rs',
        'vendor/vortex-zstd/src/lib.rs', 'vendor/vortex-zstd/src/rules.rs']),
    ('license-bundle', [sys.executable, '-B', 'scripts/check_python_license_bundle.py']),
    ('user-surface-reference', [sys.executable, '-B', 'scripts/check_user_surface_reference.py']),
    ('public-status', [sys.executable, '-B', 'scripts/check_public_status_docs.py', '--output', str(destination / 'public-status.json')]),
    ('use-case-backlinks', [sys.executable, '-B', 'scripts/check_use_case_backlinks.py']),
    ('contribution-governance', [sys.executable, '-B', 'scripts/check_contribution_governance.py', '--output', str(destination / 'contribution-governance.json')]),
    ('ci-gate-matrix', [sys.executable, '-B', 'scripts/check_ci_gate_matrix.py', '--output', str(destination / 'ci-gate-matrix.json')]),
    ('diff-check', ['git', 'diff', '--check']),
]
completed = []
for label, command in commands:
    assert sources() == current
    log = destination / (label + '.log')
    started = time.monotonic()
    with log.open('xb') as stream:
        result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, timeout=300)
    record = dict(name=label, command=command, returncode=result.returncode,
                  seconds=time.monotonic() - started, log=str(log), log_sha256=sha(log))
    completed.append(record)
    print(json.dumps(record), flush=True)
    if result.returncode:
        save(destination / 'failure.json', dict(status='failed', completed=completed))
        result.check_returncode()
    if label == 'vendor-tests':
        groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log.read_text())
        assert groups == [('17', '0', '0')]
        assert 'test_reconstruct_views_in_preserves_values_at_segment_boundaries ... ok' in log.read_text()
        assert 'test_reconstruct_views_in_rejects_corruption_and_buffer_index_overflow ... ok' in log.read_text()
        record['tests'] = dict(passed=17, failed=0, ignored=0, filtered=34)

assert sources() == current and sha(vendor / 'src/array.rs') == current[name]
source_path = OUT / 'selection-check-source-final-407.json'
save(source_path, dict(head=original['head'], source_sha256=current,
                      workflow_sha256=sha(ROOT / '.github/workflows/ci.yml')))
summary = dict(status='passed', runtime_source_unchanged=True,
    source_manifest=str(source_path), source_manifest_sha256=sha(source_path), source_files=len(current),
    runtime_checks=dict(path=str(accepted_path), sha256=sha(accepted_path),
                        native_passed=4154, native_ignored=27, workspace_passed=3219),
    ignored_tests=accepted['native_tests']['ignored_platform_tests'] + accepted['native_tests']['ignored_manual_benchmark_fixture_helpers'],
    source_supplement=dict(path=name, before_sha256=hashlib.sha256(before).hexdigest(), after_sha256=current[name],
        scope='Only the existing cfg(test) module after an identical production prefix changed; two allocator-view boundary tests and their imports added.',
        diff=str(destination / 'test-only.patch'), diff_sha256=sha(destination / 'test-only.patch'),
        runtime_prefix_sha256=hashlib.sha256(before.split(marker)[0]).hexdigest(),
        other_source_files_unchanged=len(current)-1, extra_runtime_suite_repeat=False),
    supplement_checks=completed, standalone_vendor_lock_sha256=sha(vendor / 'Cargo.lock'),
    failure_history=[str(OUT / 'selection-checks-406.json'), str(OUT / 'native-selection-vendor-test-intake-407.json')],
    ci_addition='Existing native_vortex_tests lane now runs the vendor array tests; hosted evidence is pending.')
save(OUT / 'selection-checks-final-407.json', summary)
print(json.dumps(dict(status='passed', source_files=len(current), supplement_checks=len(completed))), flush=True)
