"""Measure complete native query cost after selection resource admission."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import signal
import statistics
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
HARNESS = ROOT / 'scripts'
UAT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
sys.path[:0] = [str(HARNESS), str(OUT), '/Users/dylan/LocalData/shardloom/release-0.3.3-20260930']
from local_uat_storage import GIB, MIB, DEFAULT_MAX_LOG_MIB, DEFAULT_MAX_RUN_LOG_MIB, check_budgets, require_local_path
from clickbench_reference_packet import load_reference_packet
from native_workflow_protocol import extract_result, public_workflow_command, report_fields, strict_json
from run_clickbench_query_uat import compress_completed_log, equivalent, run_profiled_command
from run_clickbench_paired_query_uat import host_snapshot, generation
from release_validation_guard import WorkloadGuard
from freeze_native_release_298 import save, sha, sources

def read(path):
    return json.loads(Path(path).read_text())

def bound(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))

def verify(item):
    assert bound(item['path']) == item, item['path']

def samples(protocol):
    return [dict(query=case['query'], lanes=case['lanes'], pair=pair + 1, variant=variant)
            for index, case in enumerate(protocol['cases']) for pair in range(case['pairs'])
            for variant in (('baseline', 'candidate') if (index + pair) % 2 == 0 else ('candidate', 'baseline'))]

def gates(protocol, records):
    assert [{k: r[k] for k in ('query', 'lanes', 'pair', 'variant')} for r in records] == samples(protocol)
    result = []
    for case in protocol['cases']:
        rows = {v: [r for r in records if r['query'] == case['query'] and r['lanes'] == case['lanes']
                    and r['variant'] == v] for v in ('baseline', 'candidate')}
        assert all(len(x) == case['pairs'] and all(r['passed'] for r in x) for x in rows.values())
        medians = {v: {k: statistics.median(r[k] for r in x)
                       for k in ('seconds', 'native_peak_rss_bytes', 'user_cpu_seconds', 'system_cpu_seconds', 'cpu_seconds')}
                   for v, x in rows.items()}
        a, b = medians['baseline'], medians['candidate']
        timing = b['seconds'] <= a['seconds'] + max(.10 * a['seconds'], .005)
        cpu = b['cpu_seconds'] <= a['cpu_seconds'] + max(.10 * a['cpu_seconds'], .005)
        rss = b['native_peak_rss_bytes'] <= a['native_peak_rss_bytes'] + max(.25 * a['native_peak_rss_bytes'], 256 * MIB)
        paired = [x['seconds'] - y['seconds'] for x, y in zip(rows['baseline'], rows['candidate'], strict=True)]
        result.append(dict(**case, medians=medians, paired_savings_seconds=paired,
                           timing_passed=timing, cpu_passed=cpu, rss_passed=rss, passed=timing and cpu and rss))
    return result

def freeze(candidate):
    protocol = read(OUT / 'selection-cost-protocol-409.json')
    records = {}
    for variant, path in [('baseline', OUT / 'stream-composition-398-release.json'), ('candidate', candidate)]:
        manifest = read(path)
        assert manifest['status'] == 'passed'
        build = read(manifest['cli']['build_receipt'])
        assert build['status'] == 'passed' and build['direct_child_reaped'] and build['process_group_drained']
        assert sha(manifest['cli']['build_log']) == build['log_sha256']
        assert sha(manifest['cli']['build_receipt']) == manifest['cli']['build_receipt_sha256']
        assert sha(manifest['cli']['path']) == manifest['cli']['sha256']
        records[variant] = dict(manifest=bound(path), binary=bound(manifest['cli']['path']))
    assert sources() == read(candidate)['source_sha256']
    source = UAT / 'vortex/persisted-native-343-a1.vortex'
    assert source.stat().st_flags == 0 and source.stat().st_blocks * 512 >= source.stat().st_size
    queries = ROOT / 'benchmarks/clickbench/queries.sql'
    reference = Path('/Users/dylan/LocalData/shardloom/native-typed-reductions-20261004/clickbench-reference-values-2.json')
    assert sha(reference) == 'cb83c770674073f31ad0c4224f02faeb1ba557c512595a5c2d36f92bb2344b39'
    values = load_reference_packet(reference, queries)
    source_identity = bound(source)
    assert source_identity['sha256'] == '004f9639fa0aa527b70f326c366c37b1173dceeacb92b50b2d8fd02957155c18'
    helpers = [Path(__file__), OUT/'freeze_native_release_298.py',
               Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py')]
    helpers += [HARNESS / name for name in ('local_uat_storage.py', 'run_clickbench_query_uat.py',
                'run_clickbench_paired_query_uat.py', 'native_workflow_protocol.py',
                'timed_native_command.py', 'clickbench_reference_packet.py')]
    protocol.update(driver=bound(__file__), identities=records, source=source_identity, generation=generation(source),
                    query_file=bound(queries), reference_packet=bound(reference), helpers=[bound(p) for p in helpers],
                    queries={str(q): dict(sql=values['queries'][q-1], values=values['values'][q])
                             for q in sorted({c['query'] for c in protocol['cases']})},
                    platform=platform.platform(), logical_cpus=os.cpu_count(),
                    physical_memory_bytes=os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES'),
                    frozen_at=time.time())
    save(OUT / 'selection-cost-frozen-409.json', protocol)
    print(json.dumps(dict(status='frozen', samples=len(samples(protocol)))))

def run():
    protocol = read(OUT / 'selection-cost-frozen-409.json')
    for item in protocol['helpers'] + [protocol['query_file'], protocol['reference_packet']]: verify(item)
    for item in protocol['identities'].values():
        verify(item['manifest']); verify(item['binary'])
    candidate_sources = read(protocol['identities']['candidate']['manifest']['path'])['source_sha256']
    assert sources() == candidate_sources
    source = require_local_path(Path(protocol['source']['path']), Path.home(), sys.platform)
    root = require_local_path(UAT, Path.home(), sys.platform)
    logs = root / 'logs/selection-cost-pairs-409'
    assert not logs.exists()
    assert generation(source) == protocol['generation']
    verify(protocol['source'])
    workload = WorkloadGuard()
    report = dict(status='running', protocol=bound(OUT/'selection-cost-frozen-409.json'), records=[])
    def guard(reserve_log_bytes=0):
        workload.check(os.getpid())
        assert generation(source) == protocol['generation'], 'input changed'
        report['storage'] = check_budgets(root, source, logs, min_free_bytes=12*GIB,
            reserve_bytes=reserve_log_bytes, reserve_log_bytes=reserve_log_bytes, max_workspace_bytes=100*GIB,
            max_log_bytes=DEFAULT_MAX_LOG_MIB*MIB, max_run_log_bytes=DEFAULT_MAX_RUN_LOG_MIB*MIB)
    guard()
    lock = root / '.ingest-uat.lock'
    lock.mkdir()
    schemas = {}
    try:
        logs.mkdir()
        started = time.perf_counter()
        for i, item in enumerate(samples(protocol)):
            guard()
            prefix = logs / f's{i:03d}'
            declaration = protocol['queries'][str(item['query'])]
            command = public_workflow_command(protocol['identities'][item['variant']]['binary']['path'],
                declaration['sql'], input_path=source, input_format='vortex', memory_gb=24, max_parallelism=item['lanes'])
            before = host_snapshot()
            row = run_profiled_command(command, prefix, 120, guard)
            row.update(item, command=command, host_before=before, host_after=host_snapshot(), passed=False)
            report['records'].append(row)
            try:
                assert row['returncode'] == 0 and not row['guard_failures']
                assert all(math.isfinite(row[key]) and row[key] >= 0 for key in
                           ('seconds', 'native_peak_rss_bytes', 'user_cpu_seconds', 'system_cpu_seconds'))
                row['cpu_seconds'] = row['user_cpu_seconds'] + row['system_cpu_seconds']
                assert row['seconds'] > 0 and row['native_peak_rss_bytes'] > 0
                envelope = strict_json(prefix.with_suffix('.stdout.json').read_text())
                fields = report_fields(envelope)
                result = extract_result(envelope)
                assert equivalent(result, declaration['values']), item
                schema = (fields['result_schema_format'], strict_json(fields['result_schema_json']))
                assert schema == schemas.setdefault(item['query'], schema)
                assert fields['execution_resource_declared_memory_bytes'] == str(24*GIB)
                assert fields['execution_resource_declared_max_parallelism'] == str(item['lanes'])
                assert fields['fallback_attempted'] == 'false' and fields['external_engine_invoked'] == 'false'
                assert any(c['kind'] == 'native_io_certificate' and c['status'] == 'available' for c in envelope['certificates'])
                if item['query'] in (2, 21) and item['variant'] == 'candidate':
                    expected = min(item['lanes'], protocol['logical_cpus']) - 1
                    assert int(fields['resident_provider_background_workers']) == expected
                row.update(complete_rows=len(result), result_sha256=hashlib.sha256(json.dumps(result, sort_keys=True).encode()).hexdigest(),
                           reported_provider_workers=fields.get('resident_provider_background_workers'))
                pid = int(prefix.with_suffix('.pid').read_text())
                try: os.kill(pid, 0)
                except ProcessLookupError: pass
                else: raise AssertionError('native child remains')
                row['archives'] = [compress_completed_log(prefix.with_suffix(suffix), guard)
                    for suffix in ('.stdout.json', '.stderr.txt') if prefix.with_suffix(suffix).stat().st_size]
                row['passed'] = True
            finally:
                save(prefix.with_suffix('.result.json'), row)
            print(json.dumps(dict(**item, seconds=row['seconds'], passed=row['passed'])), flush=True)
        report['workflow_seconds'] = time.perf_counter() - started
        report['gates'] = gates(protocol, report['records'])
        assert sources() == candidate_sources
        verify(protocol['source'])
        for item in protocol['helpers'] + [protocol['query_file'], protocol['reference_packet']]: verify(item)
        for item in protocol['identities'].values(): verify(item['manifest']); verify(item['binary'])
        report.update(status='passed', decision='within_predeclared_cost_bounds' if all(g['passed'] for g in report['gates']) else 'needs_reversed_confirmation')
    except BaseException as error:
        report.update(status='failed', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        lock.rmdir()
        report['lock_released'] = True
        save(logs/'summary.json', report)
        try:
            guard()
        except BaseException as error:
            report.update(status='failed', decision='invalid', storage_error=f'{type(error).__name__}: {error}')
            (logs/'summary.json').write_text(json.dumps(report, indent=2) + '\n')
            raise
    print(json.dumps(dict(status=report['status'], decision=report['decision'], summary=str(logs/'summary.json'))))

if __name__ == '__main__':
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=['freeze', 'run'])
    parser.add_argument('--candidate', type=Path)
    args = parser.parse_args()
    if args.operation == 'freeze': freeze(args.candidate)
    else: run()

