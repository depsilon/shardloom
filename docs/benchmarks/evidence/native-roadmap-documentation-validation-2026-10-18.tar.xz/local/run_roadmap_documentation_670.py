"""Validate the reconciled queue and existing site without changing runtime contracts."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
N='/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
P=sys.executable
sys.path[:0]=[str(O),str(R/'scripts')]
from freeze_native_release_298 import sources, save, sha
frozen=json.loads((O/'native-release-source-roadmap663.json').read_text())
assert sources()==frozen['source_sha256']
selectors=[
 'test_architecture_tracker_missing_inputs_fail_even_when_blocked_allowed',
 'test_architecture_tracker_accepts_mapped_global_review_burn_down',
 'test_architecture_tracker_rejects_stale_global_review_burn_down',
 'test_v1_inclusion_scope_accepts_required_and_candidate_rows',
 'test_v1_inclusion_scope_blocks_missing_phase_classification',
 'test_v1_inclusion_scope_blocks_required_report_only_posture',
 'test_v1_inclusion_scope_blocks_deferred_without_diagnostics',
 'test_v1_inclusion_scope_blocks_missing_production_diagnostic_row',
]
def output(name):return str(O/('roadmap-docs-'+name+'-670a2.json'))
commands=[
 ('git-whitespace',['git','diff','--check'],R),
 ('rust-format',['cargo','fmt','--all','--','--check'],R),
 ('roadmap-tests',[P,'-m','unittest','python.tests.test_runtime_gap_family_burn_down','python.tests.test_compute_engine_completion_gate']+['python.tests.test_release_scripts.ReleaseScriptTests.'+x for x in selectors],R),
 ('v1-scope',[P,'scripts/check_v1_inclusion_scope.py','--output',output('v1-scope')],R),
 ('runtime-gap',[P,'scripts/check_runtime_gap_family_burn_down.py','--output',output('runtime-gap')],R),
 ('completion-boundary',[P,'scripts/check_compute_engine_completion_gate.py','--allow-incomplete','--output',output('completion-boundary')],R),
 ('release-boundary',[P,'scripts/check_release_architecture_tracker.py','--allow-blocked','--output',output('release-boundary')],R),
 ('security-posture',[P,'scripts/check_security_posture.py','--json-output',output('security-posture')],R),
 ('search-policy',[N,'--test','scripts/pagefind-policy.test.mjs'],R/'website-src'),
 ('website-prepare',[N,'scripts/prebuild-static.mjs','--reset-output'],R/'website-src'),
 ('website-content',[N,'scripts/sync-content.mjs'],R/'website-src'),
 ('website-types',[N,'node_modules/.bin/astro','check'],R/'website-src'),
 ('website-build',[N,'node_modules/.bin/astro','build'],R/'website-src'),
 ('website-static',[N,'scripts/postbuild-static.mjs'],R/'website-src'),
 ('website-assets',[N,'scripts/validate_static_assets.cjs'],R),
 ('website-links',[P,'-m','unittest','discover','-s','scripts','-p','test_website_links.py'],R),
 ('website-readiness',[P,'scripts/check_website_readiness.py','--output',output('website-readiness')],R),
 ('public-status',[P,'scripts/check_public_status_docs.py','--output',output('public-status')],R),
 ('contribution',[P,'scripts/check_contribution_governance.py','--output',output('contribution')],R),
]
results=[]
for name,command,cwd in commands:
    print(json.dumps(dict(stage=name,command=command)),flush=True)
    completed=subprocess.run(command,cwd=cwd)
    results.append(dict(name=name,command=command,cwd=str(cwd),returncode=completed.returncode))
    assert completed.returncode==0,name
import check_production_certification_gate as cert
import check_production_usability_gate as usability
for name,function in [('production-claim-surfaces',cert.validate_claim_surfaces),('production-documentation',usability.validate_docs)]:
    report,blockers=function(R)
    assert not blockers,blockers
    save(Path(output(name)),report)
    results.append(dict(name=name,function=function.__module__+'.'+function.__name__,returncode=0,blockers=blockers))
assert sources()==frozen['source_sha256']
completed=subprocess.run(['git','diff','--check'],cwd=R)
assert completed.returncode==0
results.append(dict(name='generated-whitespace',command=['git','diff','--check'],returncode=0))
reports=[]
for path in sorted(O.glob('roadmap-docs-*-670a2.json')):
    reports.append(dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path)))
record=dict(schema_version='shardloom.native_roadmap_documentation_validation.v1',status='passed',
    checks=results,source_commit=frozen['head'],runtime_source_files=len(frozen['source_sha256']),
    runtime_source_unchanged=True,reports=reports,version_changed=False,
    broad_rust_gate_note='No runtime/test/config implementation changes in this documentation batch. Exact unchanged runtime passed PR #1574 workspace/native/provider gates, installed wheels and fresh merged-source UAT. Formatting rerun; existing roadmap contract tests and documentation/site validators run here.',
    completion_claim_allowed=False,release_claim_allowed=False,
    boundary_note='Compute completion and release tracker run in their existing inspection modes. Open development remains a blocker; exit zero does not mark either claim ready.',
    helper=dict(path=str(Path(__file__)),bytes=Path(__file__).stat().st_size,sha256=sha(__file__)))
save(O/'roadmap-documentation-validation-670.json',record)
print(json.dumps(dict(status='passed',checks=len(results),runtime_source_files=len(frozen['source_sha256']))),flush=True)
