# Backlog production-evidence inventory

Inventory only; no checklist statuses or ordering are changed here. Source checkout inspected: `/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo`, HEAD `7daf50a9`; phase source is `docs/architecture/phased-execution-plan.md`. Output root `/Users/dylan/LocalData/shardloom/native-python-surface-20261010/O` is not a Git checkout. The scope is the six unchecked production parents after PERF-13 and their direct unchecked execution-checklist children. Later narrative and the repeated October 15 transport mention are excluded unless they are an actual checklist. Each unchecked child is listed once below as its literal checkbox line (some labels continue on the next source line; the source line number points to the checkbox line).

## Count and completion evidence

| Parent (phase-plan line) | Checked children | Unchecked children | Direct implementation/completion evidence and scope gap |
| --- | ---: | ---: | --- |
| `CLICKBENCH-PRODUCTION-WRITER-PHYSICAL-DESIGN-1` (1595) | 3 | 10 | Partial implementation is directly recorded in `docs/architecture/phased-execution-completed-ledger.md:2412-2476`: source-aware writer physical-design plan, ordered multi-worker pre-writer conversion, and September replacement-ingest/full43 evidence. Source includes `shardloom-vortex/src/vortex_ingest.rs:6473-6500,6527-6559` and public evidence in `shardloom-cli/src/sql_local_source_runtime.rs:3155-3206`. The same ledger explicitly leaves writer-profile retain/drop and the top-level production item open at `2472-2476`; this is not proof of the decoupled, ordered multi-stage production pipeline or the listed governor/codec packets. |
| `CLICKBENCH-PRODUCTION-SEGMENT-METADATA-PRIMITIVE-1` (1888) | 4 | 7 | Partial primitive is directly recorded in the same ledger at `2420-2422,2481-2482`; implementation is `shardloom-vortex/src/vortex_ingest.rs:482-518,520-530` and public fields at `shardloom-cli/src/sql_local_source_runtime.rs:3209-3220`. Phase-plan completed child at `1979` covers public primitive evidence. Ledger explicitly says per-query `segments_pruned`/`rows_pruned`/`bytes_pruned` consumption remains open (`2481-2482`). No direct completion evidence was found for the unchecked specialized summaries, route consumption, query counters or targeted UAT as a complete parent. |
| `CLICKBENCH-PRODUCTION-MORSEL-SCHEDULER-THREADLOCAL-MERGE-1` (2013) | 5 | 9 | Shared scheduler and observer hooks are directly recorded in ledger `2423-2426`; implementation is `shardloom-vortex/src/scheduler_bridge.rs:801-865,1171-1225`, lifetime tests include `shardloom-vortex/src/scheduler_bridge_lifetime_tests.rs:187-217`, and public report lifting is in `shardloom-cli/src/vortex_runtime_planning.rs:881-904`. Ledger states only source-state morsel evidence consumes it and concrete top-K/distinct/grouped routes remain (`2477-2480`). This supports a foundation, not route-wide thread-local state families, idle/backpressure evidence or all-family merge correctness. |
| `CLICKBENCH-PRODUCTION-SPECIALIZED-KERNEL-REGISTRY-1` (2160) | 3 | 12 | Registry contract and traditional hot-lane evidence are directly recorded in ledger `2427-2429,2483-2485`; implementation is `shardloom-vortex/src/specialized_kernel_registry.rs:635-675` and capability discovery is `shardloom-cli/src/status_capabilities.rs:9152-9153`. Checked plan children at `3016-3021` cover route-label replacement and registry evidence. Ledger explicitly leaves per-kernel decoded-reference parity and retain/drop gates open (`2483-2485`). Registry admission is not evidence that every listed packet executes or meets the production acceptance contract. |
| `CLICKBENCH-PRODUCTION-COLUMNAR-RESULT-DATAPLANE-1` (3050) | 3 | 5 | Contract and certificates are directly recorded in ledger `2430-2432,2486-2487`; implementation is `shardloom-vortex/src/columnar_result_dataplane.rs:256-276,554-613` with the module’s sink/materialization paths and tests. Checked children at `3075,3111,3113` cover the contract, some sink adapters, and certificates. Ledger explicitly leaves route-wide result flow and targeted UAT open (`2486-2487`). No direct completion evidence for all aggregate/top-K route parity was found. |
| `NATIVE-ENCODED-EXCHANGE` (3146) | 0 | 8 | No direct implementation/completion evidence for a cross-process native exchange service was found. The parent itself states protocol, security/resource design, and cross-process evidence do not exist (`phased-execution-plan.md:3153-3162`). RFC 0013, RFC 0035/CG-23H and RFC 0044 are design references, not completion evidence. Local encoded interchange, local arrays and sinks are explicitly only foundations in the parent’s current-state statement. |

Totals: **6/6 parents unchecked; 18 checked and 51 unchecked direct child checkboxes.** Checked child counts are transcribed from the six checklist blocks, not inferred from code. Evidence above records partial implementation only and does not recommend changing a parent or child status.

## Unchecked child lines

### `CLICKBENCH-PRODUCTION-WRITER-PHYSICAL-DESIGN-1`

- `phased-execution-plan.md:1629` — `- [ ] Implement H/VH ingest packet \`decoupled ordered pre-writer pipeline\`.`
- `phased-execution-plan.md:1660` — `- [ ] Implement H/VH ingest packet \`dictionary-lifted derived-column construction\`.`
- `phased-execution-plan.md:1735` — `- [ ] Implement H/VH ingest packet \`single resource governor\`.`
- `phased-execution-plan.md:1779` — `- [ ] Implement H/VH ingest packet \`retained layout/codec portfolio admission\`.`
- `phased-execution-plan.md:1835` — `- [ ] Build a staged pipeline for source read, embedded-derived construction, Arrow-to-Vortex`
- `phased-execution-plan.md:1838` — `- [ ] Parallelize CPU-heavy pre-writer work under ShardLoom control before the final Vortex sink`
- `phased-execution-plan.md:1841` — `- [ ] Add a retain/drop gate that rejects writer profiles slower than the retained replacement`
- `phased-execution-plan.md:1843` — `- [ ] Remove or revert the 2026-09-02 experimental tuning patch if its only evidence remains the`
- `phased-execution-plan.md:1845` — `- [ ] Add unit tests for planner decisions across small sources, large numeric sources,`
- `phased-execution-plan.md:1848` — `- [ ] Add integration/UAT harness fields for stage CPU utilization, queue depth/backpressure,`

### `CLICKBENCH-PRODUCTION-SEGMENT-METADATA-PRIMITIVE-1`

- `phased-execution-plan.md:1923` — `- [ ] Implement H/VH metadata packet \`false-negative-safe string absence summaries\`.`
- `phased-execution-plan.md:1939` — `- [ ] Implement H/VH metadata packet \`stable transform and frequency summaries\`.`
- `phased-execution-plan.md:1958` — `- [ ] Implement H/VH metadata packet \`candidate segment directories for duplicate-heavy lanes\`.`
- `phased-execution-plan.md:1974` — `- [ ] Feed the metadata primitive into predicate pruning, URL/domain grouping, heavy-hitter`
- `phased-execution-plan.md:1977` — `- [ ] Add tests proving no false negatives for min/max, null, byte-length, dictionary membership,`
- `phased-execution-plan.md:1981` — `- [ ] Add public query-consumption evidence fields for \`segments_total\`, \`segments_pruned\`, \`segments_read\`,`
- `phased-execution-plan.md:1983` — `- [ ] Run targeted ClickBench lanes that should benefit from metadata before full UAT: Q21-Q24`

### `CLICKBENCH-PRODUCTION-MORSEL-SCHEDULER-THREADLOCAL-MERGE-1`

- `phased-execution-plan.md:2053` — `- [ ] Define thread-local state traits for count, sum/avg, grouped aggregate, exact distinct,`
- `phased-execution-plan.md:2055` — `- [ ] Implement H/VH scheduler packet \`mergeable string heavy-hitter top-K states\`.`
- `phased-execution-plan.md:2070` — `- [ ] Implement H/VH scheduler packet \`numeric-plus-UTF8 heavy-hitter candidate and recount\`.`
- `phased-execution-plan.md:2086` — `- [ ] Implement H/VH scheduler packet \`tri-key grouped aggregate state\`.`
- `phased-execution-plan.md:2101` — `- [ ] Implement H/VH scheduler packet \`packed pair and grouped distinct states\`.`
- `phased-execution-plan.md:2119` — `- [ ] Implement deterministic merge ordering for every state family, including ties, null`
- `phased-execution-plan.md:2125` — `- [ ] Add worker idle/starved/backpressure time once route operators run directly through the`
- `phased-execution-plan.md:2127` — `- [ ] Convert at least the Q10/Q14/Q17/Q19/Q33/Q34/Q35-style families to the shared scheduler`
- `phased-execution-plan.md:2132` — `- [ ] Test intentionally skewed segment distributions and deterministic tie cases for each`

### `CLICKBENCH-PRODUCTION-SPECIALIZED-KERNEL-REGISTRY-1`

- `phased-execution-plan.md:2191` — `- [ ] Implement H/VH kernel packet \`reclaimable string identity and active-candidate arena\`.`
- `phased-execution-plan.md:2214` — `- [ ] Implement H/VH kernel packet \`Q35 constant-key canonicalization\`.`
- `phased-execution-plan.md:2237` — `- [ ] Implement H/VH kernel packet \`exact string heavy-hitter histogram replay\`.`
- `phased-execution-plan.md:2405` — `- [ ] Implement H/VH kernel packet \`Q17 packed numeric-plus-UTF8 top-K\`.`
- `phased-execution-plan.md:2503` — `- [ ] Implement H/VH kernel packet \`Q29 fused weighted dictionary-domain aggregate\`.`
- `phased-execution-plan.md:2676` — `- [ ] Implement H/VH kernel packet \`Q23 encoded predicate and selected-row aggregate\`.`
- `phased-execution-plan.md:2808` — `- [ ] Implement H/VH kernel packet \`Q19 fixed-width tri-key grouped top-K\`.`
- `phased-execution-plan.md:2866` — `- [ ] Implement H/VH kernel packet \`Q33 duplicate-promotion packed-pair aggregate\`.`
- `phased-execution-plan.md:2936` — `- [ ] Implement H/VH kernel packet \`Q10 exact distinct family split\`.`
- `phased-execution-plan.md:3013` — `- [ ] Register first production kernels for string heavy-hitter top-K, transformed`
- `phased-execution-plan.md:3018` — `- [ ] Add decoded-reference parity tests for every admitted kernel, including empty, all-null,`
- `phased-execution-plan.md:3023` — `- [ ] Add retain/drop gates so kernel specialization that fails correctness, degrades target UAT,`

### `CLICKBENCH-PRODUCTION-COLUMNAR-RESULT-DATAPLANE-1`

- `phased-execution-plan.md:3078` — `- [ ] Implement H/VH result packet \`selected-row aggregate and retained-row handoff\`.`
- `phased-execution-plan.md:3094` — `- [ ] Implement H/VH result packet \`columnar sink parity for exact aggregate families\`.`
- `phased-execution-plan.md:3109` — `- [ ] Route filter/project/limit, sort/top-K, grouped aggregate, distinct, and row export`
- `phased-execution-plan.md:3115` — `- [ ] Add tests for order stability, null rendering, selected-column projection, wide payload`
- `phased-execution-plan.md:3117` — `- [ ] Run targeted UAT on Q23/Q24/Q25 and broad top-K/grouped rows, then full UAT for retained`

### `NATIVE-ENCODED-EXCHANGE`

- `phased-execution-plan.md:3173` — `- [ ] Write the RFC/provider review against the then-pinned Vortex array`
- `phased-execution-plan.md:3177` — `- [ ] Define negotiation, schema/encoding/wire versions, query/partition/`
- `phased-execution-plan.md:3180` — `- [ ] Define grants for queued buffers, receive storage and retained`
- `phased-execution-plan.md:3183` — `- [ ] Define authentication, per-request authorization and transport security`
- `phased-execution-plan.md:3186` — `- [ ] Implement the first bounded producer -> transport -> receiver -> real`
- `phased-execution-plan.md:3190` — `- [ ] Measure actual wire bytes, sender/receiver CPU, copies, materialized`
- `phased-execution-plan.md:3193` — `- [ ] Admit useful dictionary/buffer reuse and supported execution metadata`
- `phased-execution-plan.md:3196` — `- [ ] Prove ordinary Flight SQL client interoperability and explicit native`

## Literal PERF cross-references and duplicate ownership signals

These are the phase plan's existing references; this inventory does not decide whether they should be deduplicated, reparented, or retained as separate acceptance obligations.

- PERF-03 says it “merges shared scheduler and writer-governor obligations below” (`phased-execution-plan.md:1146-1149`); the writer child at 1735 is the `single resource governor`, and the scheduler parent is at 2013. PERF-03 separately states global resource accounting remains open (`1152-1157`).
- PERF-04 explicitly “incorporates scheduler family conversion below” and depends on PERF-03 (`1224-1226`). Its child at 1235 migrates Q10/Q14/Q17/Q19/Q33/Q34/Q35-style production families to shared workers; scheduler child 2127 names the same seven families for conversion to the shared scheduler. These obligations have the same family list and distinct stated destinations.
- PERF-05 says it “incorporates string/composite packets” (`1246-1249`); the specialized-kernel parent includes multiple string/composite aggregate packets at 2191, 2237, 2503, 2808, and 2866. This is a stated cross-reference, not evidence those packet checkboxes are complete.
- PERF-07 says it “incorporates columnar result dataplane item below” and depends on PERF-02 (`1296-1299`). PERF-07 still has its own remaining physical-result/sink families (`1321-1357`) while the columnar parent has shared sink-facing route obligations (`3078-3117`).
- PERF-08 says it “incorporates writer physical-design item” (`1361-1364`); PERF-09 says it “incorporates writer H/VH packets” and depends on PERF-08/PERF-03 (`1382-1385`). The writer packet checklist at 1629-1848 remains open and includes stage design, governance, retention, and lifecycle tests.
- PERF-10 says it “incorporates typed kernel registry below” and depends on PERF-04/PERF-07 (`1430-1433`). Its metadata pruning child at 1435-1436 overlaps the metadata parent’s pruning consumers at 1974-1977; its fused-operator/kernel obligations overlap specialized-kernel parent 2160-3023.
- `NATIVE-ENCODED-EXCHANGE` sequencing is expressly deferred until the optimization and breadth completion contract (parent at 3150-3155); the later narrative at 3325 is not an additional checklist and was excluded from child counts.

