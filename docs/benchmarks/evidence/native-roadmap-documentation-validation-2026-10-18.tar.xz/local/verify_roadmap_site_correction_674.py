"""Verify the fresh-UAT entry in its generator, generated page and built output."""
import json
from pathlib import Path
import subprocess
import sys

O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
N='/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
sys.path[:0]=[str(O),str(R/'scripts')]
from freeze_native_release_298 import save, sha, sources
frozen=json.loads((O/'native-release-source-roadmap663.json').read_text())
assert sources()==frozen['source_sha256']
commands=[
 ('prepare',[N,'scripts/prebuild-static.mjs','--reset-output'],R/'website-src'),
 ('generate',[N,'scripts/sync-content.mjs'],R/'website-src'),
 ('types',[N,'node_modules/.bin/astro','check'],R/'website-src'),
 ('build',[N,'node_modules/.bin/astro','build'],R/'website-src'),
 ('postbuild',[N,'scripts/postbuild-static.mjs'],R/'website-src'),
 ('assets',[N,'scripts/validate_static_assets.cjs'],R),
 ('links',[sys.executable,'-m','unittest','discover','-s','scripts','-p','test_website_links.py'],R),
 ('readiness',[sys.executable,'scripts/check_website_readiness.py','--output',str(O/'roadmap-site-readiness-674.json')],R),
 ('whitespace',['git','diff','--check'],R),
]
results=[]
for name,command,cwd in commands:
 print(json.dumps(dict(stage=name,command=command)),flush=True)
 completed=subprocess.run(command,cwd=cwd)
 results.append(dict(name=name,command=command,cwd=str(cwd),returncode=completed.returncode))
 assert completed.returncode==0,name
identities=[]
for rel in ['website-src/scripts/sync-content.mjs','website-src/src/content/docs/field-guide/benchmark-methodology.mdx','website/field-guide/benchmark-methodology/index.html']:
 p=R/rel
 text=p.read_text()
 for required in ['native-roadmap-fresh-uat-2026-10-18.md','54.358','99,997,497','704 native records','without a matched speedup claim']:
  assert required in text,(rel,required)
 identities.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
assert sources()==frozen['source_sha256']
save(O/'roadmap-site-correction-674.json',dict(schema_version='shardloom.roadmap_site_correction.v1',status='passed',checks=results,source_identities=identities,runtime_source_unchanged=True,correction='The first doc validation regenerated the page from its unchanged producer and removed the new entry. The final review caught the missing entry. The generator is now updated and regeneration plus exact content checks pass; previous passing checks are preserved without treating them as proof of the missing content.',helper=dict(path=str(Path(__file__)),sha256=sha(__file__))))
print(json.dumps(dict(status='passed',checks=len(results),fresh_entry_verified_in_source_generated_and_built=True)),flush=True)
