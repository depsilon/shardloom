"""Build a reviewable roadmap draft and complete, source-bound reconciliation."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess

O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
original = json.loads((O / 'backlog-original-660.json').read_text())
raw = subprocess.check_output(['git', 'show', original['source_head'] + ':' + original['source_path']], cwd=R)
assert hashlib.sha256(raw).hexdigest() == original['source_sha256']
assert raw == (O / 'backlog-original-plan-660.md').read_bytes()

# A step owns an obligation once. Other parents link to it instead of repeating it.
parents = []
steps = {}


def parent(key, title, state, dependencies, source, scope, outcome, rows):
    p = dict(id=key, title=title, current_state=state, dependencies=dependencies,
             source=source, implementation_scope=scope, next_outcome=outcome, children=[])
    for name, label, kind in rows:
        step_id = key + '.' + name
        assert step_id not in steps
        steps[step_id] = dict(id=step_id, parent=key, label=label, kind=kind)
        p['children'].append(step_id)
    parents.append(p)


parent('PERF-01', 'attribute remaining work and keep execution evidence accurate.',
    'Fresh-source ingestion, Full43, separate engine/result/transport clocks and several measured optimization campaigns already exist. Internal overlapping work and the legacy numeric bridge still need scoped attribution.',
    'Cross-cutting: freeze the opportunity and gate before each performance candidate; accompany every implementation family below.',
    'RFC 0044; performance-attribution-and-execution-structure.md; native-drop-review-2026-10-18.md.',
    'Shared timing/certificate helpers, source_backed_encoded_execution.rs, local_primitives.rs, benchmark reports and public evidence.',
    'A named current-source cost signal and a truthful boundary for each selected candidate.', [
    ('attribution', 'Attribute exclusive engine/operator spans and overlapping worker work for measured hotspots; retain raw cost and negative-control evidence without treating summed work as elapsed time.', 'required'),
    ('numeric_bridge', 'Resolve the legacy reader-generated BitPackedUnsigned contract: distinguish unpacked test/descriptive values from executable packed-provider buffers, preserve callable behavior and report actual decode/ownership bytes. The old expansion helpers are currently test-only; do not claim a production hot-path defect without a caller.', 'required'),
])

parent('PERF-03', 'complete shared resource ownership and bounded scheduling.',
    'Explicit operation grants, reviewed payload/selection/codec/metadata owners, worker cleanup and the Q24 provider-driver correction are integrated. The source-split inventory is complete. These scoped owners do not establish a process-RSS ceiling or cover all provider allocations.',
    'First runtime dependency. Finish concrete ownership gaps before dependent state, topology or writer experiments.',
    'RFCs 0013/0014/0017/0044; native-local-completion-scope-2026-10-07.md; native-query-revisit-2026-10-12.md; native-file-metadata-buffers-2026-10-16.md.',
    'Resource grants, native session/scan/reader/codec owners, ComputePool and AggregateChunkJobs; preparation and writer ownership.',
    'A bounded owner or deterministic denial for each newly admitted provider allocation, with actual scheduling and drain proof.', [
    ('providers', 'Extend one CPU/memory owner to remaining I/O, codec, structural metadata, preparation and writer allocations. Prove actual driver-free sort/filter/projection progress within the grant; preserve the completed Q24 and filtered-count corrections and identify excluded owners.', 'required'),
    ('regions', 'For a newly justified topology candidate, discover generation-bound natural regions independently of worker count and run them through bounded Capillary admission. Prove complete coverage, original batch boundaries, skew progress, ordered handoff, cancellation and drain before measuring reductions or ordered candidates.', 'conditional'),
    ('mixed_load', 'Exercise queue bytes, state growth denial, worker reuse and cancellation under mixed jobs and retained-result pressure; distinguish native credits from caller/Python/library retention and whole-process memory.', 'required'),
])

parent('PERF-06', 'finish native pressure transitions and recovery.',
    'General aggregate, join, analytic-window and pivot pressure, input replay and finite operator cleanup are accepted. Resident membership/population state and broader recovery remain; replay spill alone does not spill consuming state.',
    'After the relevant PERF-03 owner; before broader streaming/type compositions and output recovery depend on it.',
    'RFCs 0014/0017/0044; native-local-completion-scope-2026-10-07.md; native-state-structure-campaign-2026-10-07.md.',
    'Native membership/population consumers, query-run store, operator pressure strategies and owned cleanup/recovery.',
    'Complete exact supported workloads under the caller’s memory/storage policy, beginning with remaining membership/population families.', [
    ('membership', 'Implement quota-accounted native external-memory transitions for remaining resident membership/population consumers and other explicitly unadmitted state families. Preserve exact key, bag, NULL and order semantics; inventory the concrete family before extending the existing run store.', 'required'),
    ('recovery', 'Complete per-family cancellation, crash/restart, quota exhaustion, corrupt/truncated run, source-generation and owned-cleanup acceptance. State separately whether a route restarts or actually resumes execution.', 'required'),
    ('strategy', 'Select resident or native external-memory strategies automatically inside authorized memory, temporary-storage and effect policy; prove complete results at pressure transitions on supported large workloads without an arbitrary fixed 4-GiB target.', 'required'),
    ('rematerialization', 'Conditional investigation: compare retain/spill/regenerate for the already observed reclaimable derived owners. First pin whole-dependency reconstruction cost, lifetime/revocation, headroom and bounded regeneration; preserve zero-reclaim alias/key/constant controls.', 'conditional'),
    ('merge_cost', 'Conditional investigation: capture actual spill-run sizes and stable lineage, then compare adjacent cost-aware merge schedules within reader, memory and disk-overlap grants. Preserve stable adjacency and all complete outputs; an ordering-spill connection is not this experiment.', 'conditional'),
])

parent('PERF-07', 'complete owned result and publication contracts.',
    'Owned native arrays, bounded flat aggregate/ordered streams, persisted output preparation, encoded receiving copies, independent native-file producers, all eight local streaming destinations and single-execution fanout are integrated. Remaining family-specific payload avoidance, transfer lifetime and publication recovery need separate proof.',
    'After relevant PERF-03/06 owners. Generation-conditional publication follows the current correctness work; transport remains later.',
    'RFCs 0013/0017/0044; universal-workflow-completion-2026-10-01.md; native-stream-destinations-2026-10-15.md; native-encoded-interchange-2026-10-12.md.',
    'OwnedVortexResultBatch, result streams, native/compatibility writers, retained selections and output transaction owners.',
    'Generation-checked output replacement and recoverable publication, with explicit single-file versus multi-destination guarantees.', [
    ('remaining_arrays', 'Complete the remaining physical-result and sink-family matrix using executable arrays, selections, validity and retained owners. Audit selected-row aggregate handoff, exact DISTINCT/compound and three-key Top-K/transformed grouping/pair-measure outputs; extend only missing adapters and prove late payload access, dtype/order/NULL and copied/decoded bytes at close/cancel/slice.', 'required'),
    ('publication', 'Finish generation-conditional replacement/publication and partial-commit recovery for the existing local writers/fanout. Validate complete input before publication, preserve one execution and owned retention/spooling, and prove single-file atomicity separately from multi-destination recovery/atomicity.', 'required'),
    ('transfer_lifetime', 'Preserve the completed reuse of accepted native transfers/prepared sources across later operations. Admit immutable cross-owner sharing only after explicit receiving charges, generation identity, lifetime/revocation and isolation proof; retain the accepted isolated-copy route.', 'required'),
    ('output_windows', 'Conditional investigation: compare byte-credited producer/consumer overlap with the current native/transport acknowledgement path. Establish a current complete-workflow queue bottleneck first; include slow/failing consumers, bounded queues, cancellation and provisional completion.', 'conditional'),
])

parent('PERF-10', 'extend shared physical planning and avoided work.',
    'Typed native operators, owned results, exact reductions and several fused/encoded paths exist. Typed metadata and conservative pruning foundations are real; richer summaries and consumer-wide proof remain. Total-node admission is implemented, while recursive traversal depth remains bounded.',
    'PERF-03 for regions/resources; PERF-04 for local reduction before region-local ordered candidates. Semantics and ownership precede cost-based selection.',
    'RFCs 0016/0021/0022/0044; universal-workflow-completion-2026-10-01.md; performance-plan-exhaustion-2026-09-12.md; native-state-structure-campaign-2026-10-07.md.',
    'Shared native plan/binder, metadata pruning, typed kernel selection and aggregate/order/join/window strategies.',
    'Concrete missing operator/type contracts and exact work avoidance through existing native providers.', [
    ('contracts', 'Carry physical encoding, ordering, selection, ownership and memory contracts through remaining plan/result families; preserve one native lowering across SQL, Python, DataFrame and CLI aliases.', 'required'),
    ('summaries', 'Extend native metadata with false-negative-safe string/domain/dictionary absence, stable transform/frequency summaries and duplicate-heavy candidate directories only where retained physical representation supports them. Preserve exact/conservative/advice-only distinctions and single-artifact provenance.', 'required'),
    ('metadata_consumers', 'Connect admitted metadata to actual predicate pruning, transformed grouping, heavy-hitter candidates, exact distinct, row-ref Top-K and layout advice. Prove missing/empty/all-null/mixed-null safety with independent false-negative tests and report actual segments/rows/bytes avoided, metadata reads and exactness.', 'required'),
    ('ordered_candidates', 'After region and local-reduction gates, compare exact region-local ordered candidates with bounded global merge before payload access; cover offset/limit, complete multi-keys, NULL order, ties and absolute source identity.', 'conditional'),
    ('fusion_registry', 'Extend shared filter/project/aggregate fusion and executable typed registry selection to remaining admitted specialized families. Preserve provider preconditions, candidate/blocked reasons and decoded-reference parity; remove specializations that fail correctness or their frozen complete-operation gate.', 'required'),
    ('constant_keys', 'Generalize retained literal-integer constant-key pruning to proven string/NULL constants with exact output reconstruction; do not count ConstantInt-only support as closure.', 'required'),
    ('costs', 'Cost native canonicalization, aggregate, distinct, joins, sorting and windows against actual materialization/state work; select only semantics-equivalent, resource-admitted strategies.', 'required'),
    ('traversal', 'Replace fixed recursive plan/expression and nested-schema traversal ceilings with scalable credited traversal/lowering. Prove wide/deep compositions, cancellation and deterministic resource denial without stack exhaustion; total-node admission alone does not close depth.', 'required'),
    ('multiway_joins', 'Conditional investigation: compare a native compatible-domain multiway strategy with existing binary joins, including first-use preparation and exact multiplicity/NULL/order semantics. Use an independently specified workload and ordinary-join controls before production selection.', 'conditional'),
    ('learned_indexes', 'Conditional investigation: identify a large ordered structure with repeated search cost, then certify bounded-error prediction plus exact correction against ordinary search. Include construction, memory, distribution shifts and nonbenefiting controls.', 'conditional'),
])

parent('PERF-02', 'finish prepared execution and measured reuse.',
    'The in-process native Python/resource boundary and persisted native-output reuse are accepted. Remaining family lowering and high-level builder costs are separate from answer caching.',
    'Use PERF-10 native plan/type contracts and PERF-03 ownership; preserve generation invalidation before reuse.',
    'RFC 0044; native-python-surface-2026-10-10.md; native-persisted-reuse-2026-10-11.md; native-conditional-work-campaign-2026-10-07.md.',
    'Prepared native plans, resident session/source owners and Python builder lowering.',
    'Remaining admitted families use the same typed prepared boundary; a builder change requires material complete-workflow overhead.', [
    ('families', 'Extend typed prepared execution to remaining operator/type families while preserving actual execution, invalidation and native/public parity; reuse accepted lowering instead of adding a parallel route.', 'required'),
    ('builder', 'Measure high-level SQL generation/parsing/lowering against typed prepared construction on complete workflows, then remove material duplicate work through the shared plan boundary.', 'conditional'),
    ('physical_cache', 'Conditional investigation: show repeated reconstruction of physical state rather than repeated references to a live owner. Compare admission/reuse/eviction with exact generation identity, retained bytes and reconstruction cost.', 'conditional'),
    ('changed_source', 'Conditional investigation: identify verifiably reusable regions across changed generations with exact layout/encoding identity and source validation, then compare complete preparation/use. Preserve hard generation rejection until the changed-region proof exists.', 'conditional'),
])

parent('PERF-11', 'certify bounded ingest-to-result composition.',
    'Finite single-use/multiple/repeated producers, native replay, cancellable compatibility preparation, generated ranges and rich typed batch intake are accepted. Remaining type/source/operator/destination combinations and declared envelope tails remain.',
    'PERF-03/06 owners and PERF-07 publication before broadening dependent compositions; PERF-10 for deeper plans.',
    'RFCs 0013/0014/0033/0044; universal-workflow-completion-2026-10-01.md; native-stream-input-composition-2026-10-13.md.',
    'Shared input transaction, bounded result streams, source discovery, cancellation and latency harnesses.',
    'An explicit supported composition envelope with complete results and resource/failure evidence.', [
    ('envelope', 'Validate declared input/output/memory/queue envelopes under pressure, cancellation, late input failure and slow consumers, including remaining operator/type compositions. Keep original caller owners, finite-completion semantics and unobserved providers explicit.', 'required'),
    ('latency', 'Extend separately measured p50/p95/p99 to newly admitted families and the remaining bulk-load envelope, including validation/intake/queue/result stages and native, worker, Python and fresh-process surfaces. Preserve actual execution/invalidation and report engine time for routine query comparisons.', 'required'),
])

parent('PERF-04', 'complete shared aggregate workers and deterministic reduction.',
    'Shared jobs/partitions, worker grants and exact non-null UTF8 COUNT partitions exist, including removal of dual histogram/sketch maintenance. Other concrete states and actual operator scheduling are not certified by descriptor-only scheduler tests.',
    'PERF-03 ownership first; region-local reduction additionally needs retained topology. Extend concrete states through existing jobs without waiting for a new topology. PERF-06 owns pressure transitions and PERF-05 exact keys.',
    'RFCs 0014/0016/0044; performance-plan-exhaustion-2026-09-12.md; native-local-completion-scope-2026-10-07.md.',
    'AggregateChunkJobs, native worker states, deterministic reducers and scheduling observers.',
    'Actual shared-worker execution for a coherent remaining state family with complete semantic controls.', [
    ('workers', 'Move remaining Q10/Q14/Q17/Q19/Q33/Q34/Q35-style production families onto actual shared workers. After topology retention, push admitted mergeable states into regions and compare compact-state reduction with unchanged consumers.', 'required'),
    ('states', 'Extend mergeable count/sum/avg/grouped/exact-distinct/predicate and numeric/string/row-ref Top-K states beyond non-null UTF8 COUNT: include additional measures, numeric-plus-UTF8, three-key grouping and packed-pair/grouped-distinct pressure without lossy local Top-K.', 'required'),
    ('semantics', 'Prove every admitted state’s stable merge order, complete keys, source identity, NULL/tie/offset/limit, integer overflow and floating evaluation policy under skew at 1/2/4/8/12 workers; generic row-count scheduling is insufficient.', 'required'),
    ('utilization', 'Measure actual kernel/merge work and worker idle/starved/backpressure time through the shared observer; remove superseded scheduling only after the retained candidate passes its complete-operation and control gates.', 'required'),
])

parent('PERF-05', 'complete exact key ownership and pressure behavior.',
    'Several reclaimable string, compound-key, weighted-domain and exact-distinct mechanisms are retained. The generic/direct key transition audit and broader nullable/composite pressure contracts remain.',
    'Coordinate with PERF-04 states and PERF-06 pressure; do not revive rejected histogram/sketch or bitmap variants unchanged.',
    'RFCs 0014/0021/0044; native-shared-execution-2026-10-17.md; native-text-aggregation-screen-2026-10-17.md; native-state-structure-campaign-2026-10-07.md.',
    'Dictionary domains, owned/interned keys, candidate arenas and compact/general aggregate states.',
    'Domain-safe exact keys across all admitted transitions with delayed string materialization and bounded retained state.', [
    ('identity', 'Bind referenced dictionary entries by exact domain-safe equality and normalize owned/interned keys across generic/direct transitions before and after source-order admission. Audit reclaimable identity/arena and weighted-domain consumers through the same ownership contract.', 'required'),
    ('pressure', 'Partition compact owned state, defer final strings and establish exact overflow transitions for remaining composite/pair/grouped-distinct families. Preserve PR #1428’s completed removal of dual histogram/sketch work.', 'required'),
    ('validation', 'Prove nulls, all-unique and duplicate-heavy keys, skew, composites and non-URL workloads against decoded references, including already retained Q17/Q29/Q33/Q35-style kernels and unsupported layouts.', 'required'),
    ('nested_identity', 'Conditional investigation: measure repeated recursive nested-key work, then compare shared identities after charging canonicalization, collision resolution, representatives and row mapping. Preserve exact nested equality and nonrepeating controls.', 'conditional'),
])

parent('PERF-08', 'remove measured ingestion representation duplication.',
    'CPU-stage attribution and the rejected matched-owner allocation screen are complete. Dictionary-derived paths exist; forced dictionaries/plain replay caches and rejected conversion ownership must not be recreated.',
    'PERF-03 ownership; measure actual duplication before changing representation. Feed accepted costs into PERF-09.',
    'RFC 0044; ingest-performance-implementation-2026-09-12.md; performance-plan-exhaustion-2026-09-12.md.',
    'Universal ingest read/normalize/derived/convert/codec/write/finalize stages and source preflight.',
    'A measured same-generation duplicate representation or transform removed without weakening validation.', [
    ('duplication', 'Inventory repeated representations and traversal/conversion work, then remove only measured duplication. For dictionary-lifted derived columns, require a real dictionary/native metadata seam and prove unique transforms/code replay plus NULL/Unicode/temporal parity; preserve source preflight and retained layout.', 'required'),
    ('stages', 'Attribute real normalization, derived build, metadata, codec, writer-feed, write and commit CPU/wait spans; report actual queue/backpressure, stage throughput, bytes/segments/compression and no-fallback evidence without double-counting overlapping work.', 'required'),
])

parent('PERF-09', 'cost physical layout and bounded ordered writing.',
    'Physical ingest plans, planner-selected large-source settings and the writer retain/drop gate exist. September tuning cleanup and the October six-profile text-size screen are complete; all five new profiles were dropped. Persisted output properties are accepted.',
    'PERF-08 attribution and PERF-03 resource ownership; independent-region evidence before topology-aware preparation. Keep the retained writer until lifecycle proof passes.',
    'RFC 0044; ingest-performance-implementation-2026-09-12.md; native-ingest-text-size-2026-10-18.md; native-persisted-reuse-2026-10-11.md.',
    'PhysicalIngestPlan/WriterPhysicalDesignPlan, native codec/layout providers, ordered writer queues and atomic commit.',
    'A justified layout or pipeline change with complete durable-ingest and downstream-query economics, or an evidenced drop.', [
    ('overlap', 'Only after measured recoverable idle time, extend bounded staged pre-writer overlap across read/derived/convert/compress/ordered feed/digest/commit. Bound completed blocks and head-of-line waits; prove EOF, cancellation, transient ownership, publication races and newly written-artifact queries.', 'conditional'),
    ('portfolio', 'For genuinely different admitted Vortex profiles, measure per-column physical bytes and encode/decode CPU and decide costed portfolio admission. Do not rerun the rejected five text profiles unchanged or infer whole-file savings from sampled text.', 'conditional'),
    ('design', 'After region evidence, cost preparation jointly for storage, ingest, schedulable topology, pruning, encoded work and merge. Cover small, wide-text, large-numeric, dictionary-heavy, unknown-row-count and constrained-memory planner inputs.', 'conditional'),
    ('lifecycle', 'Validate same-source durable ingestion, single-file integrity/atomicity and first/repeated downstream use for every retained writer change. Apply the existing size/ingest/query gate and preserve source validation, statistics and no-fallback evidence.', 'required'),
])

parent('PERF-12', 'complete workload, platform and comparative acceptance.',
    'Extensive public, direct, format and Full43 packets certify finite scopes. They do not complete the broad workflow matrix, all OS/resource envelopes, production certification or comparative superiority.',
    'Cross-cutting: focused tests during implementation, then complete acceptance at each coherent boundary. The current pre-bump refresh follows cleanup and any retained ship/drop work.',
    'RFCs 0015/0024/0033/0044; universal-workflow-completion-2026-10-01.md; native-local-completion-scope-2026-10-07.md; production-certification-gate.md.',
    'Complete public/native workflow matrices, UAT runners, platform/runtime evidence and release support/claim surfaces.',
    'One fresh source-bound ingest, one execution of every Full43 query, and complete format/workflow acceptance before the next version decision.', [
    ('prebump', 'Complete safe retirement of obsolete local artifacts, this backlog reconciliation and the runnable ship/drop audit; after retained changes, record fresh ingest, all 43 complete queries and all 18 modular cohorts on the final source. Keep the version bump held until this packet is accepted.', 'current'),
    ('workflows', 'Certify read/transform/retain-or-spill/reconsume/write/reopen across formats, renamed schemas, distributions and remaining types/operators. Include held-out ingest/aggregate/relational/ownership/serving cases, source/type/destination combinations and wide/deep plans after their mechanisms; every exposed composition is tested or an explicit implementation gap.', 'required'),
    ('cohort', 'Pin eligible ClickBench scoring/cohorts separately from cached product sessions; preserve one-call Full43 acceptance versus explicitly authorized repeated comparative cohorts.', 'required'),
    ('topology', 'After a newly admitted topology mechanism, compare current/coarse and safe small/medium/large topology on identical immutable 100M-row input, build and resources. Preserve the original 129-call comparative protocol and classify scan/reduction/filter/grouped/ordered/global-state response with realized/pruned/materialized work; do not restart rejected coalescing without a new mechanism.', 'conditional'),
    ('support', 'Prove ordinary and benchmark resource envelopes, late failure, slow consumers, cancellation, cleanup/recovery and actual supported OS/architecture runtimes. Record observed resources/RSS and scoped support, known issues, compatibility, upgrade/rollback and install evidence; builds alone are not platform-runtime acceptance.', 'required'),
    ('comparisons', 'Record complete outputs, paired uncertainty and non-ClickBench benefit for retained performance changes; separate engine clocks from transport/ingest/storage and preserve all failures and samples. CG-5/6 and claim gates remain mandatory.', 'required'),
])

parent('PERF-13', 'evaluate profile-guided compilation only when justified.',
    'No PGO promotion is established. Earlier optimized-build screens retain their recorded decisions.',
    'After measured PERF-10 instruction/dispatch costs; not an automatic sweep or another runtime route.',
    'RFC 0044 and the current native performance/control reports.',
    'Build configuration, representative training/held-out workloads and portable-package checks.',
    'A reproducible retained benefit or a recorded reasoned drop with unchanged runtime semantics.', [
    ('pgo', 'Establish material remaining instruction/dispatch cost, then freeze representative/held-out training, compilation/transfer break-even and portable-package correctness gates. Retain PGO only on measured complete-workflow benefit; otherwise record the drop.', 'conditional'),
])

parent('NATIVE-ENCODED-EXCHANGE', 'extend native execution across process and transport boundaries.',
    'Local receiving copies and independent native-file producer intake are accepted. Negotiated remote native exchange, authorization and transport runtime are not implemented by those local paths.',
    'After the current optimization/breadth completion contract; design/provider/security gates precede implementation. CG-23H is attribution, not a replacement phase.',
    'RFCs 0013/0035/0044; native-encoded-interchange-2026-10-12.md; then-pinned Vortex serialization/IPC and current official Flight SQL/RPC contracts.',
    'Native producer/transport/receiver boundary, negotiation, authorization, dictionaries/credits and client interoperability.',
    'A reviewed protocol and one bounded producer-to-real-native-consumer experiment with matched Arrow/Flight and ordinary Vortex IPC controls.', [
    ('protocol', 'Write the pinned-provider RFC/review: native wire/encoding/schema versions, registry/alignment/message duplication, query/partition/snapshot identity, completion/truncation, cancel/reconnect/replay and deterministic strict-native incompatibility. Define authentication, per-request authorization and transport security using established infrastructure.', 'required'),
    ('ownership', 'Define queue/receive/dictionary grants and exact identity, release/eviction, lifetime and isolation rules. Evaluate buffer/dictionary reuse and same-host mapped handles only with explicit rights/cleanup; version aggregate state separately and keep in-process handles distinct from serialization.', 'required'),
    ('experiment', 'Implement a bounded producer → transport → receiver → real downstream native operation with equivalent semantics/security/resources and complete error/cleanup behavior. Freeze and measure wire bytes, sender/receiver CPU, copies/materialization, memory and complete downstream cost against optimized Arrow/Flight and ordinary Vortex IPC.', 'conditional'),
    ('clients', 'Prove ordinary Flight SQL client interoperability and explicit native client selection, then align README, field guide, capabilities, execution evidence and hosted checks before closing only the accepted scope.', 'required'),
])

mapping = {}


def map_rows(prefix, assignments):
    for ordinal, targets in assignments.items():
        key = f'{prefix}.{ordinal:02d}'
        assert key not in mapping
        mapping[key] = dict(disposition='remaining', targets=targets.split(), evidence=[])


map_rows('PERF-01', {2:'PERF-01.attribution',3:'PERF-11.latency',4:'PERF-01.attribution',5:'PERF-01.numeric_bridge'})
map_rows('PERF-02', {1:'PERF-02.families',3:'PERF-02.builder',4:'PERF-11.latency'})
map_rows('PERF-03', {1:'PERF-03.providers',2:'PERF-03.providers',4:'PERF-03.regions',5:'PERF-03.regions',6:'PERF-03.mixed_load'})
map_rows('PERF-04', {1:'PERF-04.workers',2:'PERF-04.workers',3:'PERF-04.states',4:'PERF-04.semantics',5:'PERF-04.utilization'})
map_rows('PERF-05', {1:'PERF-05.identity',2:'PERF-05.identity',3:'PERF-05.pressure',4:'PERF-05.pressure',5:'PERF-05.validation'})
map_rows('PERF-06', {1:'PERF-06.membership',2:'PERF-06.recovery',3:'PERF-06.strategy',4:'PERF-06.strategy'})
map_rows('PERF-07', {2:'PERF-07.remaining_arrays',3:'PERF-07.publication',5:'PERF-07.transfer_lifetime',9:'PERF-07.remaining_arrays',10:'PERF-01.numeric_bridge'})
map_rows('PERF-08', {2:'PERF-08.duplication',3:'PERF-08.stages',4:'PERF-08.duplication',5:'PERF-08.duplication',6:'PERF-09.lifecycle'})
map_rows('PERF-09', {2:'PERF-09.overlap',3:'PERF-09.portfolio',4:'PERF-09.design',5:'PERF-03.providers',6:'PERF-09.overlap',8:'PERF-09.lifecycle'})
map_rows('PERF-10', {1:'PERF-10.contracts',2:'PERF-10.metadata_consumers',3:'PERF-10.ordered_candidates',4:'PERF-10.fusion_registry',5:'PERF-10.costs',6:'PERF-12.workflows',7:'PERF-10.traversal'})
map_rows('PERF-11', {1:'PERF-11.envelope',6:'PERF-11.latency'})
map_rows('PERF-12', {1:'PERF-12.workflows',2:'PERF-12.cohort',3:'PERF-12.topology',4:'PERF-12.topology',5:'PERF-12.workflows',6:'PERF-12.support',7:'PERF-12.workflows',8:'PERF-12.comparisons'})
map_rows('PERF-13', {1:'PERF-13.pgo',2:'PERF-13.pgo',3:'PERF-13.pgo',4:'PERF-13.pgo'})
W='CLICKBENCH-PRODUCTION-WRITER-PHYSICAL-DESIGN-1'
M='CLICKBENCH-PRODUCTION-SEGMENT-METADATA-PRIMITIVE-1'
S='CLICKBENCH-PRODUCTION-MORSEL-SCHEDULER-THREADLOCAL-MERGE-1'
K='CLICKBENCH-PRODUCTION-SPECIALIZED-KERNEL-REGISTRY-1'
C='CLICKBENCH-PRODUCTION-COLUMNAR-RESULT-DATAPLANE-1'
map_rows(W,{3:'PERF-09.overlap',4:'PERF-08.duplication',5:'PERF-03.providers',6:'PERF-09.portfolio',7:'PERF-09.overlap',8:'PERF-09.overlap PERF-08.stages',11:'PERF-09.design',12:'PERF-08.stages'})
map_rows(M,{4:'PERF-10.summaries',5:'PERF-10.summaries',6:'PERF-10.summaries',7:'PERF-10.metadata_consumers',8:'PERF-10.metadata_consumers',10:'PERF-10.metadata_consumers',11:'PERF-12.comparisons'})
map_rows(S,{2:'PERF-04.states',3:'PERF-04.states',4:'PERF-04.states',5:'PERF-04.states',6:'PERF-04.states PERF-05.pressure',8:'PERF-04.semantics',11:'PERF-04.utilization',12:'PERF-04.workers',14:'PERF-04.semantics'})
map_rows(K,{2:'PERF-05.identity',3:'PERF-10.constant_keys',4:'PERF-04.states PERF-05.pressure',5:'PERF-04.states PERF-05.validation',6:'PERF-05.identity PERF-10.fusion_registry',7:'PERF-10.fusion_registry PERF-07.remaining_arrays',8:'PERF-04.states',9:'PERF-05.pressure',10:'PERF-04.states',11:'PERF-10.fusion_registry',13:'PERF-10.fusion_registry PERF-05.validation'})
map_rows(C,{2:'PERF-07.remaining_arrays',3:'PERF-07.remaining_arrays',4:'PERF-07.remaining_arrays',7:'PERF-07.remaining_arrays PERF-12.workflows',8:'PERF-12.comparisons'})
map_rows('NATIVE-ENCODED-EXCHANGE',{1:'NATIVE-ENCODED-EXCHANGE.protocol',2:'NATIVE-ENCODED-EXCHANGE.protocol',3:'NATIVE-ENCODED-EXCHANGE.ownership',4:'NATIVE-ENCODED-EXCHANGE.protocol',5:'NATIVE-ENCODED-EXCHANGE.experiment',6:'NATIVE-ENCODED-EXCHANGE.experiment',7:'NATIVE-ENCODED-EXCHANGE.ownership',8:'NATIVE-ENCODED-EXCHANGE.clients'})

closed = {
    'PERF-02.05': ['docs/architecture/native-persisted-reuse-2026-10-11.md', 'docs/benchmarks/evidence/native-persisted-hosted-2026-10-12.json'],
    'PERF-03.03': ['docs/architecture/performance-plan-exhaustion-2026-09-12.md#perf-03--one-resource-budget-and-scheduling'],
    'PERF-07.04': ['docs/architecture/native-encoded-interchange-2026-10-12.md', 'docs/benchmarks/evidence/native-encoded-hosted-2026-10-14.json'],
    'PERF-07.06': ['docs/architecture/native-encoded-interchange-2026-10-12.md', 'python/src/shardloom/_native_backend.py'],
    'PERF-07.07': ['docs/architecture/native-encoded-interchange-2026-10-12.md', 'docs/benchmarks/evidence/native-encoded-hosted-2026-10-14.json'],
    'PERF-09.07': ['docs/architecture/native-persisted-reuse-2026-10-11.md', 'docs/benchmarks/evidence/native-persisted-hosted-2026-10-12.json'],
    'PERF-11.03': ['docs/architecture/native-typed-input-2026-10-10.md', 'docs/benchmarks/evidence/native-typed-input-hosted-2026-10-10.json'],
    W+'.09': ['docs/architecture/performance-plan-exhaustion-2026-09-12.md#clickbench-production-writer-physical-design-1'],
    W+'.10': ['docs/architecture/performance-plan-exhaustion-2026-09-12.md#clickbench-production-writer-physical-design-1'],
    K+'.15': ['docs/architecture/performance-plan-exhaustion-2026-09-12.md#clickbench-production-specialized-kernel-registry-1', 'docs/architecture/native-drop-review-2026-10-18.md'],
}
assert len(closed) == 10
for key, evidence in closed.items():
    assert key not in mapping
    mapping[key] = dict(disposition='completed_reconciled', targets=[], evidence=evidence)
for row in original['children']:
    if row['checked']:
        assert row['id'] not in mapping
        mapping[row['id']] = dict(disposition='completed_preexisting', targets=[], evidence=[
            f"https://github.com/depsilon/shardloom/blob/{original['source_head']}/{original['source_path']}#L{row['line']}"
        ])
assert set(mapping) == {row['id'] for row in original['children']}
assert len(mapping) == 149
partial = {
    'PERF-03.01': ('Reviewed native file/footer/segment/user-metadata buffers are integrated; structural collections and preparation lifetimes remain.', 'docs/benchmarks/evidence/native-file-metadata-hosted-2026-10-17.json'),
    'PERF-03.02': ('Q24 provider-driver and filtered-count corrections are accepted; remaining provider scheduling is separate.', 'docs/benchmarks/native-query-revisit-2026-10-12.md'),
    'PERF-07.02': ('Bounded aggregate/ordered results and later typed streams exist. Nullable structural-layout correction has local acceptance; hosted closure belongs to PR #1574, separately from remaining physical/sink families.', 'docs/benchmarks/native-nullable-layout-2026-10-18.md'),
    'PERF-07.03': ('All eight existing local streaming destinations and single-use one-execution fanout are integrated; generation-conditional replacement and broader partial-commit recovery remain.', 'docs/architecture/native-stream-destinations-2026-10-15.md'),
    'PERF-07.05': ('Accepted receiving sources/prepared handles already survive and execute later operations; immutable cross-owner sharing retains its separate lifetime/isolation gate.', 'docs/architecture/native-encoded-interchange-2026-10-12.md'),
    'PERF-10.07': ('Total-node credit admission and 255-node plans are proved; recursive depth and nested-schema traversal remain.', 'docs/architecture/native-local-completion-scope-2026-10-07.md'),
    'PERF-12.07': ('Cumulative batches, 4,097 top-level fields, generated range beyond one million rows and total-node growth are accepted; deep plans and broader combinations remain.', 'docs/benchmarks/native-input-growth-2026-10-09.md'),
    W+'.03': ('Retained bounded source/conversion stages, sequence order and one-subtree writing exist; another stage requires measured waiting and complete transient/EOF/cancel proof.', 'docs/architecture/performance-plan-exhaustion-2026-09-12.md'),
    W+'.05': ('IngestCpuLanes and later explicit operation grants exist; unreviewed scratch/transient copies and progress remain.', 'docs/architecture/performance-plan-exhaustion-2026-09-12.md'),
    W+'.07': ('Source/conversion/provider pipeline and single-artifact staging exist; source mutation/publication races and transient ownership remain.', 'docs/architecture/performance-plan-exhaustion-2026-09-12.md'),
    W+'.08': ('Actual source/conversion/provider workers and work clocks exist; exclusive stage CPU attribution is not established by owner counts.', 'docs/architecture/performance-plan-exhaustion-2026-09-12.md'),
    M+'.07': ('Typed metadata and conservative real-file predicate pruning exist; remaining grouping/distinct/ordered/advisor consumers require their own proof.', 'docs/architecture/performance-plan-exhaustion-2026-09-12.md'),
    S+'.03': ('Exact complete-key partitions and final Top-K supersede speculative sketch/recount for non-null COUNT; nullable/extra-measure/pressure scope remains.', 'docs/architecture/performance-plan-exhaustion-2026-09-12.md'),
    S+'.04': ('Scoped compound COUNT workers and domain reconciliation supersede the old Q17-only candidate/recount motivation; NULL/additional-measure/pressure scope remains.', 'docs/architecture/performance-plan-exhaustion-2026-09-12.md'),
    S+'.06': ('Grouped integer DISTINCT, exact pair union and near-unique directories exist; remaining parallel multi-measure and pressure transfer are separate.', 'docs/architecture/performance-plan-exhaustion-2026-09-12.md'),
    K+'.02': ('The historical hot-eviction arena is a measured drop; retained partition/dictionary ownership and later text mechanisms are different implementations. Require a remaining lifetime problem before another reclamation design.', 'docs/architecture/performance-plan-exhaustion-2026-09-12.md'),
    K+'.04': ('Weighted dictionary updates, exact histograms and complete-key partitions already remove accepted recount work; do not revive sparse replay or dual maintenance unchanged.', 'docs/architecture/performance-plan-exhaustion-2026-09-12.md'),
    K+'.05': ('Dictionary binding, candidate-to-numeric reuse and compound partitions exist; remaining NULL/measure/result-array scope is not a fresh packed-key implementation.', 'docs/architecture/performance-plan-exhaustion-2026-09-12.md'),
    K+'.06': ('Interned transformed-domain keys and weighted updates exist; remaining measure/result ownership or transform metadata needs actual avoided-work evidence.', 'docs/architecture/performance-plan-exhaustion-2026-09-12.md'),
    K+'.07': ('Column-scoped residual refinement and native predicates exist; selected-measure/result ownership is shared with PERF-07, not a second predicate implementation.', 'docs/architecture/performance-plan-exhaustion-2026-09-12.md'),
    K+'.09': ('Exact near-unique duplicate promotion and late measures exist; the ordered singleton-window variant is dropped. Remaining NULL/parallel/pressure scope does not require replacing the directory.', 'docs/architecture/performance-plan-exhaustion-2026-09-12.md'),
    K+'.10': ('Packed-pair preunion, chunk partials and grouped integer DISTINCT workers exist; other dtype/NULL/multi-measure/pressure families remain.', 'docs/architecture/performance-plan-exhaustion-2026-09-12.md'),
    C+'.04': ('Source arrays and later bounded aggregate/ordered streams use actual owned native results. Remaining family coverage must follow state-to-sink behavior; absence of the old descriptor type name alone does not prove a runtime gap.', 'docs/architecture/universal-workflow-completion-2026-10-01.md'),
}
for key,(note,proof) in partial.items():
    assert mapping[key]['disposition']=='remaining'
    mapping[key]['completed_portion']=note
    mapping[key]['evidence'].append(proof)
for entry in mapping.values():
    assert set(entry['targets']) <= set(steps)
    for proof in entry['evidence']:
        if not proof.startswith('https://'):
            assert (R / proof.split('#',1)[0]).is_file(), proof

prose_sources = {
    'PERF-06.rematerialization': 'docs/architecture/native-local-completion-scope-2026-10-07.md#eight-investigations-with-current-evidence-prerequisites',
    'PERF-06.merge_cost': 'docs/architecture/native-local-completion-scope-2026-10-07.md#eight-investigations-with-current-evidence-prerequisites',
    'PERF-10.multiway_joins': 'docs/architecture/native-local-completion-scope-2026-10-07.md#eight-investigations-with-current-evidence-prerequisites',
    'PERF-10.learned_indexes': 'docs/architecture/native-local-completion-scope-2026-10-07.md#eight-investigations-with-current-evidence-prerequisites',
    'PERF-05.nested_identity': 'docs/architecture/native-local-completion-scope-2026-10-07.md#eight-investigations-with-current-evidence-prerequisites',
    'PERF-02.physical_cache': 'docs/architecture/native-local-completion-scope-2026-10-07.md#eight-investigations-with-current-evidence-prerequisites',
    'PERF-07.output_windows': 'docs/architecture/native-local-completion-scope-2026-10-07.md#eight-investigations-with-current-evidence-prerequisites',
    'PERF-02.changed_source': 'docs/architecture/native-local-completion-scope-2026-10-07.md#eight-investigations-with-current-evidence-prerequisites',
    'PERF-12.prebump': 'October 18 maintainer instructions: cleanup, backlog reconciliation, eligible ship/drop work and fresh full UAT before the next version bump',
}
used = {key for entry in mapping.values() for key in entry['targets']}
assert set(steps) - used == set(prose_sources), sorted(set(steps)-used)
retired = {W:['PERF-03','PERF-08','PERF-09'],M:['PERF-10','PERF-12'],S:['PERF-03','PERF-04','PERF-05'],K:['PERF-04','PERF-05','PERF-07','PERF-10','PERF-12'],C:['PERF-07','PERF-12']}
result = dict(schema_version='shardloom.roadmap_reconciliation.v1', status='draft_pending_review',
    source_head=original['source_head'], source_path=original['source_path'], source_sha256=original['source_sha256'],
    original_counts=dict(parents=len(original['parents']), children=len(original['children']), unchecked_children=sum(not r['checked'] for r in original['children'])),
    current_counts=dict(parents=len(parents), children=len(steps), dispositions=dict(Counter(x['disposition'] for x in mapping.values())), step_kinds=dict(Counter(x['kind'] for x in steps.values()))),
    parents=parents, steps=list(steps.values()), retired_parent_aliases=retired, prose_obligations=prose_sources,
    reconciliation=[dict(row, source_url=f"https://github.com/depsilon/shardloom/blob/{original['source_head']}/{original['source_path']}#L{row['line']}", **mapping[row['id']]) for row in original['children']],
    scope='One canonical owner per remaining obligation; completed historical rows are retained, ten stale unchecked rows reconciled, eight existing prose investigations made explicit. No whole PERF/CG gate is closed, no runtime behavior or performance result is changed.')
(O/'backlog-reconciliation-draft-661.json').write_text(json.dumps(result,indent=2)+'\n')

lines = [raw.decode().split('## Planned\n',1)[0].rstrip(), '', '## Planned', '',
    'Current autonomous execution order:', '',
    '1. Finish the current nullable-layout hosted integration and preserve its immutable acceptance packet.',
    '2. Complete `PERF-12.prebump`: retire obsolete local artifacts safely, reconcile this roadmap, finish any eligible deciding ship/drop tests, then run fresh ingest, one execution of each Full43 query and all 18 format/workflow cohorts on the final retained source.',
    '3. Keep the next version bump held until that packet is accepted. Continue runtime breadth in dependency order: remaining resource owners and membership/population state, generation-conditional output publication/recovery, then the other supported source/type/operator compositions.',
    '4. Admit performance experiments only from current measured costs. Preserve original drop decisions and paused large format/text experiments; no unchanged sweep is authorized by a roadmap cleanup.',
    '5. Queue native encoded transport after the current optimization/breadth contract. Continuous, distributed and shared-service outcomes retain the roadmap dependencies below.', '',
    'The current implementation remains the RFC 0044 native execution program. Prior R3 cleanup is recorded in the completed ledger; this reconciliation adds no phase IDs and does not bypass an active cleanup dependency. CG-1 through CG-23 remain independent evidence gates.', '',
    f"The [reconciliation](native-roadmap-reconciliation-2026-10-18.md) maps all 19 previous parents and all 149 children (121 unchecked, 28 already checked). Five overlapping production epics become aliases of the 14 canonical owners below. Ten stale unchecked rows are completed; unresolved scope remains explicit in {len(steps)} current substeps, including the eight previously prose-only investigations and the current pre-bump packet. These are obligations, not a forecast of PR count.", '',
    '### Common implementation and acceptance contract', '',
    '- Source and scope: use each owner’s governing RFC/provider review and the current code, tests and completed ledger. Check Vortex-native providers before inventing an abstraction; public front doors converge on shared native plan/state/sink contracts.',
    '- ShardLoom technique review: evaluate PulseWeave, capillary work units, dynamic admission/work shaping, metadata-first work avoidance, late materialization, timing-surface separation and evidence tiers for each concrete family. Record actual activation; descriptor fields alone are not execution proof.',
    '- Evidence and acceptance: exact complete values, logical types, NULL/bag/order semantics, source identity, resource credits, cancellation/failure/cleanup and actual work/copy/decode counters. Preserve `fallback_attempted=false` and `external_engine_invoked=false`; Vortex stays the native persistence target and compatibility formats remain explicit translation boundaries.',
    '- Performance: freeze current workload, mechanism, samples, controls and retain/drop threshold before timing. The latest prospective speed target is at least 2% of complete-workload engine time, subject to correctness, repeatability and resource/control gates. Do not relax historical gates, combine unrelated gains or infer a whole-engine gain from a focused cohort. Routine Full43 timing is the sum of `engine_execution_seconds` for one call to each query.',
    '- Verification: choose exact Rust library/binary/integration targets and Python test selectors from changed symbols; run `cargo fmt --all -- --check`, `cargo clippy --workspace --all-targets -- -D warnings`, and `cargo test --workspace --all-targets` for nontrivial implementation, plus applicable native/provider/public matrices. Complete Full43/format acceptance at coherent batch boundaries under local storage/process guards.',
    '- User-visible surfaces: shared CLI/Python/SQL/DataFrame behavior, native/compatibility outputs, diagnostics/certificates, documented support and workload evidence. Align affected docs/site/capabilities and hosted installed-wheel checks before claiming integration.',
    '- Non-goals and claims: no fallback engines, unapproved effects/dependencies, package publication, global-RSS promises, or unsupported superiority/production claims. `claim_gate_status=not_claim_grade` until the corresponding workload and release gates pass.',
    '- Ledger rule: close a finite substep only with implementation/diagnostics, tests and linked acceptance. Move completed narrative to the completed ledger; leave broader owners open. A conditional item is pending evidence, not a dropped or completed obligation.', '',
    '### Canonical owners and substeps', '']
for p in parents:
    classification='v1_candidate_pending_feasibility' if p['id'] in ('PERF-13','NATIVE-ENCODED-EXCHANGE') else 'required_for_v1'
    lines += [f"- [ ] `{p['id']}` {p['title']}",
              f"  - V1 scope classification: `{classification}`.",
              f"  - Source: {p['source']}", f"  - Current state: {p['current_state']}",
              f"  - Dependencies: {p['dependencies']}", f"  - Implementation scope: {p['implementation_scope']}",
              '  - ShardLoom technique review: apply the common contract above to these shared owners; retain actual activation, resource and avoided-work evidence.',
              '  - Execution checklist:']
    for child in p['children']:
        lines.append(f"    - [ ] `{child}` {steps[child]['label']}")
    lines += [f"  - Next outcome: {p['next_outcome']}",
              '  - Acceptance/verification: the common contract above plus the exact family/protocol controls named in the checklist; preserve original experiment gates and links in the reconciliation.', '']

lines += ['### Breadth and later roadmap coverage', '',
    'Five breadth/operational areas remain. They overlap the owners above and are not five additional parent checklists:', '',
    '| Area | Canonical owners | Remaining completion boundary |', '| --- | --- | --- |',
    '| Stateful pressure and recovery | PERF-03/06/10/12 | Remaining membership/population and other unadmitted state, automatic policy selection, per-family corruption/cancellation/cleanup and honest restart/resume guarantees. |',
    '| Remaining allocation coverage | PERF-03/06/08/09 | Unreviewed provider/structural metadata/preparation/writer owners; preserve completed decoder, compression, selection and file-buffer scopes. |',
    '| Broader streaming | PERF-03/06/07/11/12 | Remaining stateful/type combinations and output recovery; accepted finite producers, sets, unary/subqueries and eight local destinations are foundations. |',
    '| Adapter and composition coverage | PERF-02/07/10/11/12; CG-19/20/21 | Complete typed/nested source → transform → retain/spill → reconsume → write → reopen workflows, partition/schema evolution and deeper plans. |',
    '| Defined local support and release | PERF-12; existing release gates | Declared OS/workload/resource envelopes, actual platform runtime, failures/recovery, compatibility, install and upgrade/rollback evidence. |', '',
    'The eight conditional investigations are explicit above: rematerialization, multiway joins, nested identities, spill-merge costs, learned indexes, physical-state cache admission, byte-credit output windows and changed-source preparation reuse. Their prerequisites and original experiment contracts remain unchanged. They are not eight unfinished timed runs.', '',
    '| Later outcome | Existing roadmap owner and dependency |', '| --- | --- |',
    '| Independent jobs/users and analytical serving | PERF-03/11/12 and CG-11/20/21/23: deployment-driven concurrent admission/isolation/priorities, protocols, identity, cancellation and publication. Distinct from distributing one query. |',
    '| Incremental/continuous computation | CG-9/17/22/23 and RFCs 0017/0034/0035: change identity, event time, durable progress/checkpoints and coordinated source/sink recovery. |',
    '| Distributed individual computations | CG-10 and existing distributed/runtime owners: partition/stage ownership, exchange, skew, remote data access, recovery and coordinated publication after local contracts. |',
    '| Federation, remote APIs and optional Foundry integration | CG-18/20/21/23 and RFC 0036: governed connectors/identity and explicit control/data planes with platform proof. Foundry is optional; external engines are baselines or declared sources/sinks, never runtime fallback. |', '',
    '### Competitive Engine Track', '',
    'These are evidence gates, not replacement phase IDs or closure claims. The [detailed ledger](phased-execution-completed-ledger.md#reference-competitive-engine-gate-detailed-checklist-ledger) and [RFC mapping](rfc-phase-traceability.md) retain their scoped status. Real Vortex output payload acceptance is distinct from CG-3 placeholder artifact-path status; superiority requires CG-5 and CG-6.', '',
    '| Gate | Scope |', '| --- | --- |']
cg = ['encoded read boundary and real encoded reads','real query primitives over Vortex data','real output payload write path','commit protocol execution','correctness/differential harness','benchmark harness','physical operators/kernels','streaming/parallel/adaptive execution','lakehouse/table intelligence','object-store/distributed execution','Python/API foundation','plan portability and semantic IR','encoded-native compressed execution','runtime-adaptive optimizer and execution memory','CPU operator specialization','evidence-first execution certificates','stateful result reuse and incremental execution','universal import/deployment/baseline harness','universal native I/O envelope','SQL/operator/function/adapter/user capability certification','user data workflow and ETL','native batch/live/hybrid certified execution fabric','REST/event/remote API and explicit data planes']
lines += [f'| CG-{i} | {name} |' for i,name in enumerate(cg,1)]
lines += ['', '`GLOBAL-RUNTIME-GAP-CARRY-FORWARD-1` remains the global-review traceability owner. Its GAR family references stay in the completed ledger and runtime-gap mapping; this reorganization does not mark global runtime gaps or release claims complete.', '', '## Completed', '',
    'Completed finite units and historical decisions live in [the completed ledger](phased-execution-completed-ledger.md). The [reconciliation record](native-roadmap-reconciliation-2026-10-18.md) retains the exact prior-plan identity and every old checkbox disposition.', '']
draft='\n'.join(lines)
assert len(re.findall(r'^- \[ \] `',draft,re.M)) == len(parents) == 14
assert len(re.findall(r'^    - \[ \] `',draft,re.M)) == len(steps)
(O/'phased-execution-plan-draft-661.md').write_text(draft)


def local_link(ref):
    if ref.startswith('https://'):
        return ref
    if ref.startswith('docs/architecture/'):
        return ref[len('docs/architecture/'):]
    if ref.startswith('docs/'):
        return '../' + ref[len('docs/'):]
    return '../../' + ref


md = ['# Native roadmap reconciliation — October 18, 2026', '',
    'Status: draft pending primary semantic review and documentation validation. This is an immutable reconciliation record, not a second active queue. The [phased plan](phased-execution-plan.md) owns current work and ordering.', '',
    '## Decision and coverage', '',
    f"The source is [`{original['source_head'][:8]}`](https://github.com/depsilon/shardloom/blob/{original['source_head']}/{original['source_path']}), SHA-256 `{original['source_sha256']}`. All 19 parents and all 149 direct children are accounted for in the [machine-readable map](native-roadmap-reconciliation-2026-10-18.json). Stable `.NN` legacy IDs identify rows by original order, including checked rows; they are audit identifiers, not new implementation phases.", '',
    '| Measure | Before | Reconciled draft |', '| --- | ---: | ---: |',
    '| Canonical open parent owners | 19 | 14 |',
    '| Historical child rows | 149 | 149 mapped |',
    '| Already checked historical children | 28 | 28 preserved |',
    '| Additional stale unchecked children completed | — | 10 |',
    '| Historical unchecked rows still carrying obligations | 121 | 111 mapped into shared steps |',
    f'| Current concrete substeps | Overlapping historical rows | {len(steps)} |', '',
    'The 55 current steps include 46 destinations for legacy obligations, eight existing investigations previously carried in prose, and one current pre-bump acceptance packet. Consolidation does not complete 66 tasks: it removes duplicate ownership and historical repetition. No whole PERF owner, CG gate, runtime gap or production/release claim is closed.', '',
    'The five remaining breadth areas are stateful pressure/recovery, allocation coverage, broader streaming, adapter/composition coverage and defined local support/release. Eight conditional investigations remain open; no candidate-specific comparison is currently running or waiting only for its final timing pass. The completed rematerialization owner screen is preliminary evidence, not a full policy decision. Existing opportunity/safety prerequisites remain actionable work; absence of an old benchmark is not a deferral reason.', '',
    '## Parent ownership consolidation', '',
    '| Retired duplicate parent identifier | Canonical owners | Disposition |', '| --- | --- | --- |']
md += [f"| `{key}` | {'; '.join('`'+x+'`' for x in values)} | Merged ownership; required remaining scope stays open. |" for key,values in retired.items()]
md += ['', 'PERF-01 through PERF-13 and NATIVE-ENCODED-EXCHANGE retain their original phase identities and v1 classifications. All old checklists remain retrievable from the pinned source. In particular, a different retained native representation may satisfy the old intent: no new sketch, generic scheduler, result descriptor, cache or registry is required merely to reproduce historical terminology.', '',
    '## Ship/drop status at reconciliation', '',
    'The recent shared-execution, native text-scan and ingest text-size campaigns have complete decisions and preserved rejected variants. The [drop review](native-drop-review-2026-10-18.md) found no unused, already-proven whole-Full43 engine gain above the prospective 2% threshold. None of the eight investigations below has an implemented candidate waiting only for its final timing run. This is a test-readiness inventory, not eight drop decisions or a claim that further experiments are infeasible.', '',
    '| Investigation | Current source/evidence | Next deciding work, still open |', '| --- | --- | --- |',
    '| Selective rematerialization | The 25-case real-owner screen is complete; its observer was removed. Shared native transforms/owners remain. | Define whole-dependency lifetime/headroom and bounded regeneration, then complete retain/spill/regenerate with alias/key/constant controls. |',
    '| Constraint-guided multiway joins | `native_relational_join.rs::Join` still builds the existing exact binary index and enumerates duplicate chains. Ordinary join-pressure acceptance is separate. | Define independent cyclic and ordinary-join fixtures/oracles, then a compatible-domain candidate with first-use cost and exact multiplicity/NULL/order. This is feasible new experiment work, not a pending final sample. |',
    '| Shared nested identities | `native_relational_nested_keys.rs::Column` recursively compares, hashes and writes exact keys; owner caching does not establish hash-consing. | Measure repeated recursive work and charge canonicalization/collisions/representatives/row maps before a candidate. |',
    '| Cost-aware spill merging | `native_relational_spill.rs::Ordering` still appends level-zero native runs and merges adjacent equal-level pairs. The run store exposes actual row/byte facts. | Capture real run sizes/lineage, replay stable adjacent schedules and implement a candidate only with bounded readers/memory/disk overlap. The existing schedule is a concrete baseline, not a blocker or completed experiment. |',
    '| Learned indexes | Retained batch location uses `partition_point`; the segment cache uses sorted-ID search and bounded sort output has ordinary exact searches. | Identify a sufficiently large repeatedly searched owner, then prove exact bounded-error correction including absent/duplicate/boundary keys. Do not enlarge or sort data merely to manufacture a target. |',
    '| Physical-state cache admission | `resident_segment_reuse.rs` reports a one-prepared-execution serialized-buffer cache with generation validation and live-buffer hits; pressure replay has explicit scope. | Trace actual reconstruction after owner release and compare bounded admission/eviction policies, not repeated references to live state. |',
    '| Byte-credit output windows | `python_batch_protocol.rs::consume` still flushes and requires the exact acknowledgement; the native Python binding now has its own in-process batch iterator. The old resident-only input description is obsolete. | Establish which current delivery path has a complete-workflow queue bottleneck and compare a bounded window there; preserve native/direct controls, demand, slow/failing consumers and final acknowledgement. |',
    '| Changed-source preparation reuse | `evaluate_vortex_prepared_state_append_only_refinement` validates a narrow prefix/line-boundary/configuration/artifact contract. General generation-bound state still rejects changed identity. | Measure changed-source preparation and prove reusable logical regions/layout dependencies beyond that narrow existing refinement; retain full source verification and reopened values. |', '',
    'Source review at the pinned head confirms these boundaries; it runs no new timing experiment. The two [campaign contracts](native-state-structure-campaign-2026-10-07.md) and [conditional-work contract](native-conditional-work-campaign-2026-10-07.md) retain their detailed semantics, controls and refusal conditions. New prototypes require the existing predeclared gates. No benchmark framework, provider dependency, runtime fallback or unexplained historical retry is introduced.', '',
    '## Newly reconciled completed rows', '',
    '| Legacy row | Completed scope | Evidence |', '| --- | --- | --- |']
for row in result['reconciliation']:
    if row['disposition']=='completed_reconciled':
        label=row['label'].replace('|','\\|')
        refs='; '.join(f'[proof {i}]({local_link(ref)})' for i,ref in enumerate(row['evidence'],1))
        md.append(f"| `{row['id']}` | {label} | {refs} |")
md += ['', 'Persisted preparation is distinct from answer caching. Encoded transfer completion covers receiving-owned isolation and the tested independent producer; remote transport and immutable cross-owner sharing retain their own gates. Rich input covers the existing admitted types and destination fidelity, not arbitrary extension/Decimal256/ORC support. The writer retention rule and September rejected-patch cleanup do not need a new benchmark merely to correct stale checkbox wording.', '',
    '## Completed portions inside still-open rows', '',
    'These partial dispositions prevent accepted work from being implemented again. The remaining destination in the full map still owns the unfinished scope.', '',
    '| Legacy row | Accepted or superseding portion | Evidence |', '| --- | --- | --- |']
for row in result['reconciliation']:
    if 'completed_portion' in row:
        md.append(f"| `{row['id']}` | {row['completed_portion']} | [source]({local_link(row['evidence'][0])}) |")
md += ['', '## Complete legacy-to-current map', '',
    'Every row below links to its original full checklist context, including original acceptance/retain-drop gates. `Preexisting complete` preserves the prior checked disposition; it is not a new execution claim. The JSON retains every full original label, line, state and evidence reference. Broader partial rows remain open even when a finite constituent is accepted.', '',
    '| Legacy row and original context | Disposition | Current destination |', '| --- | --- | --- |']
for row in result['reconciliation']:
    disposition={'remaining':'Remaining / consolidated','completed_reconciled':'Completed / corrected stale checkbox','completed_preexisting':'Preexisting complete'}[row['disposition']]
    targets='; '.join('`'+x+'`' for x in row['targets']) or 'Completed ledger and evidence above'
    md.append(f"| [`{row['id']}`]({row['source_url']}) | {disposition} | {targets} |")
md += ['', '## Existing prose obligations made explicit', '',
    '| Current substep | Original authority |', '| --- | --- |']
for key,source in prose_sources.items():
    ref=f'[scope]({local_link(source)})' if source.startswith('docs/') else source
    md.append(f'| `{key}` | {ref} |')
md += ['', '## Verification and claim boundary', '',
    'The draft generator independently checks exact original file bytes, all 149 old row identities, target existence and all 14 parent blocks. Mechanical review confirms every old label/state/line is preserved and every referenced destination appears once. Primary review owns semantic closure; the historical source, current implementation contracts and merged evidence—not an agent inventory alone—support the ten corrected rows.', '',
    'Documentation, v1-scope, runtime-gap, compute-completion and release-tracker validation must pass before this record is accepted. Completion and release trackers must continue to report the remaining open development queue. No checker is weakened, no runtime source changes, no benchmark is rerun merely to change prose, and no package version/publication follows from this reconciliation.', '',
    'Historical completed narratives are removed from the active plan because their canonical ledger and linked experiment reports already retain them. The exact pre-reconciliation plan remains pinned above; original measurements, failures, gates, source identities and published artifacts are unchanged.', '']
(O/'native-roadmap-reconciliation-draft-661.md').write_text('\n'.join(md))
print(json.dumps(dict(status='drafted', parents=len(parents),steps=len(steps),mapping=len(mapping),counts=result['current_counts'],lines=len(draft.splitlines()))))
