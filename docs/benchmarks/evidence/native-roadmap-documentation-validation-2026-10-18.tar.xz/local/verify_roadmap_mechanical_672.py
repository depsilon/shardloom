"""Independently verify every reconciliation field, owner, step and local link."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import unquote

R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
N='/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
original=read(O/'backlog-original-660.json')
data=read(R/'docs/architecture/native-roadmap-reconciliation-2026-10-18.json')
raw=subprocess.check_output(['git','show',original['source_head']+':'+original['source_path']],cwd=R)
assert raw==(O/'backlog-original-plan-660.md').read_bytes()
assert hashlib.sha256(raw).hexdigest()==original['source_sha256']==data['source_sha256']
assert data['source_head']==original['source_head'] and data['source_path']==original['source_path']
rows={x['id']:x for x in data['reconciliation']}
assert len(rows)==len(data['reconciliation'])==len(original['children'])==149
assert set(rows)=={x['id'] for x in original['children']}
for old in original['children']:
    current=rows[old['id']]
    assert raw.decode().splitlines()[old['line']-1]==old['first_line']
    for key in ('id','parent','label','checked','line','first_line'):
        assert current[key]==old[key],(old['id'],key)
    assert current['source_url']==f"https://github.com/depsilon/shardloom/blob/{original['source_head']}/{original['source_path']}#L{old['line']}"
dispositions=Counter(x['disposition'] for x in rows.values())
assert dispositions==dict(completed_preexisting=28,completed_reconciled=10,remaining=111)
assert all(x['checked']==(x['disposition']=='completed_preexisting') for x in rows.values())
assert all(x.get('evidence') for x in rows.values() if x['disposition']=='completed_reconciled')
plan=(R/original['source_path']).read_text()
assert plan.split('## Planned\n',1)[0]==raw.decode().split('## Planned\n',1)[0]
parents=re.findall(r'^- \[ \] `([^`]+)`',plan,re.M)
child_rows=re.findall(r'^    - \[ \] `([^`]+)` (.*)$',plan,re.M)
children=dict(child_rows)
steps={x['id']:x for x in data['steps']}
assert len(parents)==len(set(parents))==len(data['parents'])==14
assert parents==[x['id'] for x in data['parents']]
assert len(children)==len(child_rows)==len(steps)==len(data['steps'])==54
assert set(children)==set(steps)
kinds=Counter(x['kind'] for x in steps.values())
assert kinds==dict(required=37,conditional=17)
for step in steps.values():
    prefix='**Conditional.** ' if step['kind']=='conditional' else ''
    assert children[step['id']]==prefix+step['label']
for parent in data['parents']:
    assert set(parent['children'])=={x['id'] for x in steps.values() if x['parent']==parent['id']}
targets=[t for row in rows.values() for t in row['targets']]
assert len(targets)==119 and len(set(targets))==46
assert set(targets)<=set(steps)
assert all(row['targets'] for row in rows.values() if row['disposition']=='remaining')
assert all(not row['targets'] for row in rows.values() if row['disposition']!='remaining')
assert set(data['prose_obligations'])==set(steps)-set(targets)
assert len(data['prose_obligations'])==8
assert len(data['completed_batch_steps'])==1
assert data['completed_batch_steps'][0]['id']=='PERF-12.prebump'
assert data['completed_batch_steps'][0]['status']=='completed'
assert 'PERF-12.prebump' not in children
ledger=(R/'docs/architecture/phased-execution-completed-ledger.md').read_text()
assert len(re.findall(r'^- \[x\] `PERF-12.prebump`',ledger,re.M))==1
assert data['current_counts']['parents']==14 and data['current_counts']['children']==54
assert data['current_counts']['dispositions']==dispositions and data['current_counts']['step_kinds']==kinds
sys.path.insert(0,str(R/'scripts'))
from check_v1_inclusion_scope import open_phase_items,parse_matrix_rows
matrix=parse_matrix_rows((R/'docs/release/v1-inclusion-scope-matrix.md').read_text())
for key,row in open_phase_items(plan).items():assert matrix[key]['Classification'].strip('`')==row['classification']
assert len(data['retired_parent_aliases'])==5
for key,owners in data['retired_parent_aliases'].items():
    assert key not in parents and matrix[key]['Classification']=='`required_for_v1`'
    assert all(x in parents for x in owners)
    assert all('`'+x+'`' in matrix[key]['Feasibility status'] for x in owners)
assert all(re.search(r'\bCG-'+str(i)+r'\b',plan) for i in range(1,24))
assert plan.count('GLOBAL-RUNTIME-GAP-CARRY-FORWARD-1')==1
manifest=read(O/'roadmap-documentation-prepared-669/manifest.json')
docs=[R/x['path'] for x in manifest if x['path'].endswith(('.md','.mdx'))]
links=[];headings={}
for path in docs:
    # The completed ledger is historical; check only its new block in this batch.
    content=path.read_text()
    if path.name=='phased-execution-completed-ledger.md':
        content=content.split('- [x] `PERF-12.prebump`',1)[1].split('- [x] `NATIVE-SHARED-SPEED-FOLLOWUP`',1)[0]
    for m in re.finditer(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',content):
        ref=m.group(1).strip().strip('<>')
        if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:',ref):continue
        ref=ref.split(' "',1)[0]
        base,_,anchor=ref.partition('#')
        if base.startswith('/') and path.suffix=='.mdx':
            target=R/'website'/unquote(base).lstrip('/')
            if not target.suffix:target=target/'index.html'
            target=target.resolve()
        else:
            target=(path.parent/unquote(base)).resolve() if base else path
        assert target.is_file(),(str(path),ref)
        links.append(dict(source=str(path.relative_to(R)),target=ref,resolved=str(target),anchor=unquote(anchor)))
        if anchor and str(target) not in headings:
            hs=[]
            for match in re.finditer(r'^#{1,6}\s+(.+?)\s*#*$',target.read_text(),re.M):
                plain=re.sub(r'\[([^\]]+)\]\([^)]+\)',r'\1',match.group(1))
                plain=re.sub(r'<[^>]+>','',plain).replace('`','').replace('**','').replace('*','')
                hs.append(plain)
            headings[str(target)]=hs
code="""import GithubSlugger from './website-src/node_modules/github-slugger/index.js';
let input='';for await(const part of process.stdin)input+=part;
const output={};for(const [path,headings] of Object.entries(JSON.parse(input))){
const slugger=new GithubSlugger();output[path]=headings.map(x=>slugger.slug(x));}
process.stdout.write(JSON.stringify(output));"""
run=subprocess.run([N,'--input-type=module','-e',code],input=json.dumps(headings),cwd=R,text=True,capture_output=True,check=True)
slugs=json.loads(run.stdout)
for link in links:
    if link['anchor']:assert link['anchor'] in slugs[link['resolved']],link
boundary=read(O/'roadmap-docs-completion-boundary-670a2.json')
release=read(O/'roadmap-docs-release-boundary-670a2.json')
assert boundary['status']=='blocked' and boundary['phase_plan_unchecked_count']==68
assert release['status']=='blocked' and release['phase_plan_queue_status']=='open_development_queue_blocks_release_claims'
assert not boundary['runtime_gap_family_burn_down_blockers'] and not release['runtime_gap_family_burn_down_blockers']
record=dict(schema_version='shardloom.roadmap_primary_mechanical_review.v1',status='passed',
    original_file_sha256=original['source_sha256'],original_rows=149,fields_verified_per_row=6,
    dispositions=dict(dispositions),parents=14,steps=54,step_kinds=dict(kinds),
    target_references=len(targets),distinct_legacy_destinations=len(set(targets)),prose_investigations=8,
    retired_required_parent_aliases=5,completed_current_packet='PERF-12.prebump',
    local_links_verified=len(links),anchors_verified=sum(bool(x['anchor']) for x in links),
    anchor_algorithm='Installed github-slugger; repeated hyphens preserved and duplicate headings numbered.',
    links=links,source_identities=[dict(path=str(p),sha256=sha(p)) for p in docs],
    completion_open_rows=68,completion_and_release_remain_blocked=True,
    prior_worker_check_accepted=False,prior_worker_correction='Wrong structured keys and hard-coded outcomes did not verify the requested counts. Its collapsed-hyphen slugger produced a false anchor warning. Primary independently checks every fact here; no document anchor change is needed.',
    helper=dict(path=__file__,sha256=sha(__file__)))
with (O/'roadmap-primary-mechanical-review-672.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps({k:record[k] for k in ('status','original_rows','parents','steps','local_links_verified','anchors_verified')}))
