"""Preserve verified roadmap/documentation checks with exact final-source identities."""
import ast
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile

O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
sys.path[:0]=[str(O),str(R/'scripts')]
from freeze_native_release_298 import save,sha,sources
from package_selection_acceptance_409 import Members,verify,sha_stream
from local_uat_storage import require_local_path,check_budgets,GIB,MIB
read=lambda p:json.loads(Path(p).read_text())
def identity(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))

validation=read(O/'roadmap-documentation-validation-670.json')
mechanical=read(O/'roadmap-primary-mechanical-review-672.json')
assert validation['status']==mechanical['status']=='passed'
assert len(validation['checks'])==22 and all(x['returncode']==0 for x in validation['checks'])
frozen=read(O/'native-release-source-roadmap663.json')
assert sources()==frozen['source_sha256']
for name in ['roadmap-documentation-670a2','roadmap-site-correction-674']:
 receipt=read(O/(name+'.json'))
 assert receipt['status']=='passed' and receipt['returncode']==0
 assert receipt['process_group_drained'] and receipt['direct_child_reaped']
 assert sha(O/(name+'.log'))==receipt['log_sha256']
for ref in validation['reports']:
 assert identity(ref['path'])==ref
for ref in mechanical['source_identities']:
 if not ref['path'].endswith('website-src/src/content/docs/field-guide/benchmark-methodology.mdx'):
  assert sha(ref['path'])==ref['sha256']
site_log=(O/'roadmap-site-correction-674.log').read_text()
assert '"fresh_entry_verified_in_source_generated_and_built": true' in site_log
site_paths=['website-src/scripts/sync-content.mjs','website-src/src/content/docs/field-guide/benchmark-methodology.mdx','website/field-guide/benchmark-methodology/index.html']
for rel in site_paths:
 text=(R/rel).read_text()
 for required in ['native-roadmap-fresh-uat-2026-10-18.md','54.358','99,997,497','704 native records','without a matched speedup claim']:
  assert required in text,(rel,required)
completion=read(O/'roadmap-docs-completion-boundary-670a2.json')
release=read(O/'roadmap-docs-release-boundary-670a2.json')
assert completion['status']=='blocked' and release['status']=='blocked'
members=Members()
def add(p,role):
 p=Path(p)
 if p.is_relative_to(R):root=R;prefix='repository'
 elif p.is_relative_to(O):root=O;prefix='local'
 else:root=p.parent;prefix='external/'+p.parent.as_posix().lstrip('/')
 return members.add(p,prefix+'/'+p.relative_to(root).as_posix(),prefix,root,role)

for p in sorted(O.iterdir()):
 if p.is_file() and re.search(r'(?:660|661|668|669|670(?:a2)?|671|672|674)(?:\.|-|$)',p.name):
  add(p,'reconciliation, raw checks and preserved earlier attempts')
for p in sorted((O/'roadmap-documentation-prepared-669').rglob('*')):
 if p.is_file():add(p,'original prepared documentation including later-corrected draft')
add(O/'native-release-source-roadmap663.json','unchanged runtime source identity')
helpers=[Path(__file__),O/'run_guarded.py',O/'freeze_native_release_298.py',O/'package_selection_acceptance_409.py',
 Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'),
 Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')]
helpers += [Path(x.path) for x in members.paths.values() if Path(x.path).suffix=='.py']
seen=set()
while helpers:
 p=helpers.pop().resolve()
 if p in seen:continue
 seen.add(p);add(p,'helper and local import closure')
 if p.suffix=='.py':
  for node in ast.walk(ast.parse(p.read_text())):
   names=[a.name.split('.')[0] for a in node.names] if isinstance(node,ast.Import) else [node.module.split('.')[0]] if isinstance(node,ast.ImportFrom) and node.module else []
   for name in names:
    for base in [p.parent,O,R/'scripts']:
     q=base/(name+'.py')
     if q.is_file() and q.resolve() not in seen:helpers.append(q)
changed=subprocess.check_output(['git','status','--porcelain','-z'],cwd=R).split(b'\0')
final_sources=[];existing_evidence=[];deleted=[]
stem='native-roadmap-documentation-validation-2026-10-18'
index_rel='docs/benchmarks/evidence/'+stem+'.json'
for raw in changed:
 if not raw:continue
 name=raw.decode()[3:];p=R/name
 assert name.startswith(('docs/','website-src/','website/')),name
 if not p.exists():deleted.append(name);continue
 if name==index_rel:continue
 ref=dict(file=name,bytes=p.stat().st_size,sha256=sha(p))
 final_sources.append(ref)
 if '/evidence/' in name and (name.endswith(('.tar.xz','.manifest.json.xz')) or 'native-roadmap-fresh-uat' in name or 'native-nullable-layout-hosted' in name):
  existing_evidence.append(ref)
 else:add(p,'final proposed documentation or generated website')
ordered=sorted(members.paths.values(),key=lambda x:x.name)
raw_bytes=sum(x.size for x in ordered)
assert raw_bytes<=192*MIB
dest=require_local_path(O/'roadmap-documentation-evidence-675',Path.home(),sys.platform)
assert not dest.exists()
check_budgets(O,dest,O/'logs',min_free_bytes=12*GIB,reserve_bytes=256*MIB,max_workspace_bytes=100*GIB,max_log_bytes=192*MIB)
dest.mkdir()
archive=dest/(stem+'.tar.xz')
with tarfile.open(archive,'x:xz') as bundle:
 for x in ordered:
  verify(x.path,x.digest,x.size);bundle.add(x.path,arcname=x.name,recursive=False)
assert archive.stat().st_size<=32*MIB
with tarfile.open(archive,'r:xz') as bundle:
 entries=bundle.getmembers()
 assert len(entries)==len(ordered)==len({x.name for x in entries})
 for x in ordered:
  member=bundle.getmember(x.name)
  assert member.isfile() and member.size==x.size
  with bundle.extractfile(member) as stream:assert sha_stream(stream)==(x.size,x.digest)
  verify(x.path,x.digest,x.size)
assert sources()==frozen['source_sha256']
index=dict(validation)
index.update(archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),
 member_count=len(ordered),raw_bytes=raw_bytes,all_members_reopened=True,
 members=[dict(path=str(x.path),archive_path=x.name,bytes=x.size,sha256=x.digest,roles=x.roles) for x in ordered],
 final_source_identities=final_sources,deleted_generated_paths=deleted,existing_evidence=existing_evidence,
 primary_mechanical_review=identity(O/'roadmap-primary-mechanical-review-672.json'),
 primary_review_summary={k:mechanical[k] for k in ['original_rows','fields_verified_per_row','dispositions','parents','steps','step_kinds','target_references','distinct_legacy_destinations','prose_investigations','local_links_verified','anchors_verified','completion_open_rows','prior_worker_check_accepted']},
 site_correction=dict(status='passed',checks=9,receipt=identity(O/'roadmap-site-correction-674.json'),log=identity(O/'roadmap-site-correction-674.log'),source_identities=[identity(R/p) for p in site_paths],reason='Final review found the new entry was only in the generated page and regeneration removed it. Updated the producer, rebuilt and checked the entry in source, generated page and built output. The child report and supervisor used one filename; the preserved supervisor receipt and complete log retain the successful commands and final content assertion.'),
 verification_note='The original 22 checks and full mechanical audit remain immutable. Nine focused website checks and final content/source identity checks cover the subsequent generator correction. No runtime source or version change; no benchmark rerun.',
 packager=identity(Path(__file__)))
index_path=dest/(stem+'.json');save(index_path,index)
assert read(index_path)==index
target=R/index_rel
assert read(target)['status']=='pending_validation'
shutil.copy2(archive,target.with_suffix('.tar.xz'))
shutil.copy2(index_path,target)
assert sha(target)==sha(index_path) and sha(target.with_suffix('.tar.xz'))==sha(archive)
print(json.dumps(dict(status='passed',members=len(ordered),raw_bytes=raw_bytes,archive_bytes=archive.stat().st_size,final_sources=len(final_sources),index=str(target))))
