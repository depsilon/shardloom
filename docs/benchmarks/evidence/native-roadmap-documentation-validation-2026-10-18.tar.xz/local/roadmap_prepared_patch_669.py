"""Emit one exact, hash-checked apply_patch input for the prepared documentation."""
import hashlib
import difflib
import json
from pathlib import Path
import sys

R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
D=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010/roadmap-documentation-prepared-669')
entries=json.loads((D/'manifest.json').read_text())
entry=entries[int(sys.argv[1])]
name=entry['path']
assert '..' not in Path(name).parts and not Path(name).is_absolute()
new=(D/name).read_bytes()
assert hashlib.sha256(new).hexdigest()==entry['new_sha256']
path=R/name
patch=['*** Begin Patch']
if entry['old_sha256'] is None:
    assert not path.exists()
    patch.append('*** Add File: '+str(path))
    patch+=['+'+line for line in new.decode().splitlines()]
else:
    old=path.read_bytes()
    assert hashlib.sha256(old).hexdigest()==entry['old_sha256'],name
    patch+=['*** Update File: '+str(path)]
    diff=list(difflib.unified_diff(old.decode().splitlines(),new.decode().splitlines(),n=3,lineterm=''))
    assert diff and diff[0].startswith('---') and diff[1].startswith('+++')
    patch+=['@@' if line.startswith('@@') else line for line in diff[2:]]
patch+=['*** End Patch']
print('\n'.join(patch))
