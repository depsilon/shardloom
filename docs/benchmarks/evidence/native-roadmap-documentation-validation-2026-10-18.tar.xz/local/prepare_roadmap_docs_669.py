"""Prepare reviewed documentation edits outside the clean measured checkout."""
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path

O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
read=lambda p:json.loads(Path(p).read_text())
a=read(O/'fresh-uat663-acceptance.json')
packet=read(O/'roadmap-fresh-evidence-667/native-roadmap-fresh-uat-2026-10-18.json')
cleanup=read(O/'debug-cache-cleanup-662.json')
retired=read(O/'superseded-vortex-retirement-666.json')
roadmap=read(O/'backlog-reconciliation-final-668.json')
assert a['status']==cleanup['status']==retired['status']=='passed'
assert packet['all_members_reopened'] and roadmap['current_counts']['children']==54
files={}

def current(name):return (R/name).read_text()
def replace(text,before,after):
    assert text.count(before)==1,before
    return text.replace(before,after)

files['docs/architecture/phased-execution-plan.md']=(O/'phased-execution-plan-final-668.md').read_text()
files['docs/architecture/native-roadmap-reconciliation-2026-10-18.md']=(O/'native-roadmap-reconciliation-final-668.md').read_text()
files['docs/architecture/native-roadmap-reconciliation-2026-10-18.json']=(O/'backlog-reconciliation-final-668.json').read_text()
files['docs/benchmarks/evidence/native-roadmap-documentation-validation-2026-10-18.json']=json.dumps(dict(
    schema_version='shardloom.native_roadmap_documentation_validation.v1',status='pending_validation',
    completion_claim_allowed=False,release_claim_allowed=False),indent=2)+'\n'

name='docs/release/v1-inclusion-scope-matrix.md'
text=current(name)
lines=text.splitlines()
states={
 'PERF-01':'Existing clocks and complete UAT retained; exclusive cost attribution and the legacy numeric descriptor/packed-provider boundary remain.',
 'PERF-02':'Native prepared/transfer reuse and persisted preparation accepted; hidden family materialization and evidence-gated physical-state/changed-source reuse remain.',
 'PERF-03':'Scoped allocation owners and Q24 driver cleanup accepted; remaining provider, preparation and writer owners, mixed-load admission and conditional regions remain.',
 'PERF-04':'Native reductions and exact local partitioned aggregation accepted; remaining shared worker-local state, deterministic merges and measured skew work remain.',
 'PERF-05':'Exact shared string, compound-key, weighted-domain and DISTINCT mechanisms accepted; direct/generic key transitions and broader pressure/type scope remain.',
 'PERF-06':'Aggregate, join, window and pivot pressure and finite recovery accepted; resident membership/population transitions and broader recovery remain.',
 'PERF-07':'Owned native arrays, local receiving copies, independent producers and eight streaming writers/fanout accepted; remaining family payload avoidance, transfer sharing and publication recovery remain.',
 'PERF-08':'Publication fingerprint and scoped native buffer ownership corrections accepted; exclusive preparation attribution and remaining conversion/metadata work remain.',
 'PERF-09':'Physical writer planning, persisted properties and retain/drop discipline accepted; justified overlap/portfolio/topology experiments and durable lifecycle proof remain.',
 'PERF-10':'Typed physical operators, conservative pruning and node-count growth accepted; remaining fused families, recursive-depth growth and evidence-gated algorithms remain.',
 'PERF-11':'Finite multi-producer, set, unary and declared subquery streaming accepted; remaining state/type/source combinations and broad support envelopes remain.',
 'PERF-12':'Fresh October 18 ingest, Full43 and 18 modular cohorts accepted; remaining complete compositions, actual platform/resource support and independent comparative claims remain.',
 'PERF-13':'Profile-guided compilation remains pending feasibility, conditional on current measured instruction/dispatch costs and representative held-out/package proof.',
}
seen=set()
for i,line in enumerate(lines):
    if not line.startswith('| `'):continue
    key=line.split('`',2)[1]
    parts=[p.strip() for p in line.strip('|').split('|')]
    if key in states:
        assert len(parts)==6
        parts[3]=states[key]+' [Current owners and reconciliation](../architecture/native-roadmap-reconciliation-2026-10-18.md).'
        seen.add(key)
    elif key in roadmap['retired_parent_aliases']:
        assert len(parts)==6
        owners=', '.join('`'+x+'`' for x in roadmap['retired_parent_aliases'][key])
        parts[2]='`implementation_required`'
        parts[3]='Historical identifier retained as an alias of '+owners+'. Completed foundations and every remaining obligation are mapped in the [reconciliation](../architecture/native-roadmap-reconciliation-2026-10-18.md); this parent is not separately queued or marked complete.'
    elif key=='NATIVE-VARBIN-METADATA-RESOURCES':
        assert len(parts)==6
        parts[2]='`completed_finite_unit`'
        parts[3]='The [reviewed buffer-table acceptance](../benchmarks/native-varbin-metadata-review-2026-10-16.md) supersedes the initial packet: malformed host-readable views and invalid text are rejected, unchanged validated tables are reused with fresh receiving credit, and all 19,538 local evidence members are verified. PR #1563 completes all 44 hosted checks, three installed-wheel lanes and preview/production verification in its 176-member hosted packet. Original measurements and rejected comparisons remain preserved.'
    elif key=='NATIVE-ENCODED-EXCHANGE':
        assert 'all six areas and eight conditional investigations' in parts[3]
        parts[3]=parts[3].replace('all six areas and eight conditional investigations','the five remaining breadth areas and eight conditional investigations in the reconciled plan')
    else:continue
    lines[i]='| '+' | '.join(parts)+' |'
assert seen==set(states)
intro='Hosted completion\nand the broader PERF/CG obligations remain distinct.'
text='\n'.join(lines)+'\n'
text=replace(text,intro,intro+' The [October 18 reconciliation](../architecture/native-roadmap-reconciliation-2026-10-18.md) consolidates five overlapping production parents into existing PERF owners. Historical rows and six-area wording retain their original scope; the current queue has five remaining breadth areas and eight conditional investigations.')
files[name]=text

name='docs/architecture/native-local-completion-scope-2026-10-07.md'
text=current(name)
anchor='this document is not a second queue or a new set of competitive gates.\n'
files[name]=replace(text,anchor,anchor+'\nThe [October 18 reconciliation](native-roadmap-reconciliation-2026-10-18.md) maps completed portions and remaining obligations into 14 canonical parents and 54 active substeps. It records five remaining breadth areas and eight conditional investigations; these overlap the checklist, rather than adding separate tasks. The historical assessments and original experiment contracts below remain intact.\n')

name='docs/benchmarks/native-nullable-layout-2026-10-18.md'
text=current(name)
text=replace(text,'workspace, native, Python and format/workflow acceptance passes. Hosted checks\nand merge remain pending.','workspace, native, Python and format/workflow acceptance passes. PR #1574 merged\nat `6780e7df` after all 44 hosted checks passed; installed-wheel and deployed-site\nverification are complete.')
text=replace(text,'delta. Hosted CodeQL must validate the updated PR head; no alert is dismissed.','delta. Hosted CodeQL passes on the updated PR head. All four historical review\nthreads are resolved and no open alert remains; no alert was dismissed.')
text=replace(text,'contracts remain separate. Installed-wheel and hosted integration evidence will\nbe recorded separately after the final PR head passes.','contracts remain separate. The [hosted packet](evidence/native-nullable-layout-hosted-2026-10-18.json)\nreopens all 144 members and binds the reviewed head, synthetic CI merge and actual\nmerge to all 2,416 final source files. Complete hosted logs verify 7,037 native/provider\ntest executions and three installed-wheel lanes passing 100 methods each. Sixteen\npreview/production responses and desktop/mobile navigation and search pass. The\npacket retains the three-file test-only bridge, original alerts, parser correction\nand closeout-validator correction; the earlier measured build is not relabeled.\n\nThe subsequent [fresh-source UAT](native-roadmap-fresh-uat-2026-10-18.md) rebuilds\nthe merged source, performs fresh ingestion and reruns all 43 queries and 18\nformat/workflow cohorts. The historical observation above retains its original\nbuild, input and timing identity.')
files[name]=text

engine=Decimal(a['engine_execution_seconds'])
source=next(x for x in a['datasets'] if x['path'].endswith('.parquet'))
target=next(x for x in a['datasets'] if x['path'].endswith('.vortex'))
build=read(O/'native-release-artifacts-roadmap663.json')
report=f'''<!-- SPDX-License-Identifier: Apache-2.0 -->

# Fresh native UAT after roadmap reconciliation

Fresh ingestion validates all 99,997,497 ClickBench rows, all 43 queries pass
complete-value and schema checks, and all 18 format/workflow cohorts pass on
merged runtime `6780e7df564c55f3e256822be1d0383cfabff0c9`.

**Full43 engine time: {engine} seconds (43 queries, one execution each).**

This is one regression observation with a retained native reference. It is not
a matched speedup comparison. The [roadmap reconciliation](../architecture/native-roadmap-reconciliation-2026-10-18.md)
accounts for every historical substep, and the [cleanup record](../architecture/local-artifact-cleanup-2026-10-18.md)
preserves scoped retirement evidence. The next package version remains a separate
maintainer decision.

## Fresh execution and verification

| Gate | Result |
| --- | --- |
| Source and build | Fresh release CLI and binding; all 2,416 frozen source files match the merged runtime |
| Fresh ingestion | 99,997,497 validation rows and 99,997,497 projection rows; native output reopened |
| Full43 | 43 calls, one per query; all 381 complete result rows, schemas and native certificates reopened |
| Format/workflow matrix | 18 cohorts; 704 native records and 704 independent pandas correctness-oracle records |
| Clocks and process cleanup | All 43 timing/PID companions, complete timing CSV and compressed output identities verified; native children absent |
| Dataset identity | Full source/output SHA-256, residency and stable generations checked before and after execution |
| Evidence packet | All {packet['member_count']:,} archived members reopened against original sizes and hashes |

The modular scope is 22 workflows: all eight admitted inputs with collection,
plus CSV input to all eight outputs, each with raw and prepared inputs. It does
not claim the full input/output Cartesian product. Pandas is an independent test
oracle only and never executes ShardLoom work.

The earlier 4,827-case public matrix across 36 families and 100 direct-binding
methods are inherited through the explicit final test-only source bridge and
PR #1574 hosted acceptance; they were not executed again by this fresh UAT.
The fresh merged CLI is used for ingestion, Full43 and every native modular row.
No runtime source changes are made by the documentation reconciliation.

## Reproduction and identities

The machine is macOS 27 ARM64 with 10 logical CPUs and 16 GiB physical memory.
Query admission is 24 GiB with maximum parallelism 12; this is not an enforced
whole-process RSS ceiling. Input/output files are resident and prehashed. OS
cache state is uncontrolled. Builds and workloads run sequentially under the
existing process/storage guards, with no artificial inter-query pacing or retry.

The retained original Parquet has {source['bytes']:,} bytes and SHA-256
`{source['sha256']}`. The newly generated Vortex output has
{target['bytes']:,} bytes and SHA-256 `{target['sha256']}`.
The new output is byte-identical to the previous accepted Vortex generation;
only that superseded payload is retired after full identity and open-handle checks.

The release CLI uses `release-user-surfaces` and SHA-256
`{build['cli']['sha256']}`. The separate release binding has SHA-256
`{build['binding']['sha256']}`. The pinned Vortex 0.85.0 provider and
native no-fallback boundary are unchanged. Result evidence preserves
`fallback_attempted=false` and `external_engine_invoked=false`.

The [portable index](evidence/native-roadmap-fresh-uat-2026-10-18.json) identifies
the partitioned archives and compressed complete member manifest. They retain all runtime
sources, exact build/launch commands, source bridges, reference values, full
ingest/query/modular results, host observations, cleanup receipts and executable
helpers with their local import closure. Bulk input/output files, executable
binaries and redundant fixture payloads have explicit exclusion identities.
Local paths are provenance and must be remapped explicitly on another host.
The packet also preserves an initial post-run verifier path error and its
correction: retained historical logs were incorrectly treated as one active run.
The corrected check validates each real run under the original limits; no query
or workflow was repeated and no storage limit changed.

Reproduction starts with `prepare_roadmap_fresh_launch_663.py` after the guarded
release builds and source freeze. The launch record retains the exact sequential
ingest, Full43 and modular commands and runner source. The ingestion command uses
`scripts/run_clickbench_ingest_uat.sh`; `verify_roadmap_fresh_uat_663.py` independently
reopens every result and verifies stable full dataset hashes. The final
`package_roadmap_fresh_uat_667.py` records and verifies the portable evidence.

## Per-query engine times

Each row is one execution. The [complete timing CSV](evidence/native-roadmap-fresh-uat-2026-10-18-query-timings.csv)
retains all other diagnostic clocks and resource observations separately.

| Query | Engine seconds |
| --- | ---: |
'''
report+='\n'.join(f"| Q{x['query']:02d} | {x['engine_execution_seconds']:.9f} |" for x in a['engine_times'])+'\n'
report+='''
The sum excludes UAT preparation, external verification, packaging and cleanup.
No production-readiness, comparative superiority, process-RSS, new format or
package-release claim follows. Broader PERF owners and CG-1 through CG-23 remain
open under their existing evidence gates.
'''
assert retired['byte_identical']
files['docs/benchmarks/native-roadmap-fresh-uat-2026-10-18.md']=report

cleanup_doc=f'''# Local artifact cleanup — October 18, 2026

The requested cleanup retires completed compiler outputs and the superseded
large Vortex output while preserving source, current execution artifacts and
compact result/failure evidence. Storage limits and execution guards are unchanged.

| Retired scope | Accounted bytes | Verification |
| --- | ---: | --- |
| Completed Cargo debug cache | 26,352,421,883 regular-file bytes | Exact member manifest, two closed-handle checks, unchanged source/release cache/frozen artifacts/datasets |
| Superseded `fresh-text-aggregation-588-a1.vortex` | {retired['retired']['bytes']:,} | Full hash and stable resident generation, closed handles, byte-identical accepted replacement |

The cache retirement increases observed free space by
{cleanup['observed_free_bytes_increase']:,} bytes. After fresh UAT acceptance, the
Vortex retirement increases observed free space by
{retired['observed_free_bytes_increase']:,} bytes. These are separate observations;
intervening builds and UAT writes mean they are not one before/after measurement.

The resident original Parquet and latest accepted `fresh-roadmap-663-a1.vortex`
remain available. The current release cache and frozen merged-source executables
are retained. Historical evidence paths keep their original identities; retired
payloads require regeneration. No CloudDocs internals, cloud placeholders or
unrelated user files are changed.

The [fresh-UAT packet](../benchmarks/evidence/native-roadmap-fresh-uat-2026-10-18.json)
contains both retirement receipts, exact member/generation manifests and the
scoped cleanup helpers. The [acceptance report](../benchmarks/native-roadmap-fresh-uat-2026-10-18.md)
records the complete replacement validation before the old output was removed.
'''
files['docs/architecture/local-artifact-cleanup-2026-10-18.md']=cleanup_doc
name='docs/architecture/local-development-storage.md'
text=current(name)
anchor='After the [October 17 text aggregation acceptance]'
assert text.count(anchor)==1
text=text.replace(anchor,'The [October 18 cleanup](local-artifact-cleanup-2026-10-18.md) retires the completed\ndebug cache and, after fresh ingestion and complete acceptance, the superseded\n`fresh-text-aggregation-588-a1.vortex`. The original Parquet, current frozen runtime\nand latest accepted `fresh-roadmap-663-a1.vortex` remain. Compact source/result/failure\nevidence and exact retirement receipts are preserved; storage limits are unchanged.\n\n'+anchor)
files[name]=text

name='docs/architecture/phased-execution-completed-ledger.md'
text=current(name)
anchor='### Recent Completed Session Ledger\n'
block=f'''

- [x] `PERF-12.prebump` — October 18 cleanup, backlog reconciliation and fresh
  acceptance complete without a package-version change. The [reconciliation](native-roadmap-reconciliation-2026-10-18.md)
  maps all 149 historical children: 28 prior completions, ten corrected stale
  unchecked rows and 111 remaining rows consolidated under 14 parents and 54
  current substeps. Five overlapping production parents remain historical aliases;
  required scope, eight investigations and CG-1 through CG-23 stay visible.
  - The [ship/drop audit](native-drop-review-2026-10-18.md) and reconciliation
    find no implemented candidate awaiting only its final timing comparison.
    Existing prerequisites and new candidates remain open; prior drops and gates
    are preserved.
  - [Fresh UAT](../benchmarks/native-roadmap-fresh-uat-2026-10-18.md) on merged
    runtime `6780e7df` validates all 99,997,497 ingested rows, 43 complete queries
    and 18 format/workflow cohorts (704 native plus 704 independent oracle rows).
    Full43 engine time is {engine} seconds, one execution per query; no matched
    speedup is claimed. Every one of {packet['member_count']:,} evidence members is verified.
  - [Scoped cleanup](local-artifact-cleanup-2026-10-18.md) retires the completed
    debug cache and superseded Vortex payload after identity/closed-handle checks,
    preserving the original input, accepted replacement and compact evidence.

- [x] `NATIVE-NULLABLE-LAYOUT` — [PR #1574](https://github.com/depsilon/shardloom/pull/1574)
  merges nullable structural-record validity and DType preservation at `6780e7df`.
  [Acceptance](../benchmarks/native-nullable-layout-2026-10-18.md) retains provider,
  workspace, native, direct/public, Full43 and modular checks. The
  [144-member hosted packet](../benchmarks/evidence/native-nullable-layout-hosted-2026-10-18.json)
  verifies all 44 checks, 7,037 native/provider executions, three 100-method wheel
  lanes and preview/production source, navigation and search. Historical alerts,
  the test-only correction and closeout/parser corrections remain preserved.
  No broader state/sink family, PERF owner, CG gate or package release is closed.
'''
files[name]=replace(text,anchor,anchor+block)

name='website-src/src/content/docs/field-guide/benchmark-methodology.mdx'
text=current(name)
anchor='individual changes against a frozen ShardLoom control:\n'
line=f'''\n- [October 18 fresh merged-source UAT](https://github.com/depsilon/shardloom/blob/main/docs/benchmarks/native-roadmap-fresh-uat-2026-10-18.md) — fresh ingestion validates all 99,997,497 rows, all 43 queries pass complete values and schemas, and all 18 format/workflow cohorts pass (704 native records with 704 independent correctness-oracle records). Full43 engine time is {engine:.3f} s, one execution per query. This is one regression observation, without a matched speedup claim. The portable packet binds the merged runtime, complete results, all per-query clocks and scoped cleanup.\n'''
files[name]=replace(text,anchor,anchor+line)

dest=O/'roadmap-documentation-prepared-669'
assert not dest.exists()
dest.mkdir()
manifest=[]
for name,value in files.items():
    path=dest/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(value)
    old=(R/name).read_bytes() if (R/name).exists() else None
    manifest.append(dict(path=name,old_sha256=None if old is None else hashlib.sha256(old).hexdigest(),
        new_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),bytes=path.stat().st_size))
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(status='prepared',files=len(files),path=str(dest))))
