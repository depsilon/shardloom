"""Finalize the reviewed draft after fresh acceptance, without editing the checkout."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
read=lambda name:json.loads((O/name).read_text())
accepted=read('fresh-uat663-acceptance.json')
assert accepted['status']=='passed' and accepted['queries']==43 and accepted['modular_cohorts']==18
assert read('superseded-vortex-retirement-666.json')['status']=='passed'
packet=read('roadmap-fresh-evidence-667/native-roadmap-fresh-uat-2026-10-18.json')
assert packet['all_members_reopened'] and packet['source_identity_preserved']
data=read('backlog-reconciliation-draft-661.json')
original=read('backlog-original-660.json')
old=(O/'backlog-original-plan-660.md').read_bytes()
assert hashlib.sha256(old).hexdigest()==data['source_sha256']==original['source_sha256']

prebump=next(x for x in data['steps'] if x['id']=='PERF-12.prebump')
data['steps']=[x for x in data['steps'] if x['id']!=prebump['id']]
authority=data['prose_obligations'].pop(prebump['id'])
p=next(x for x in data['parents'] if x['id']=='PERF-12')
p['children'].remove(prebump['id'])
old_dependency=p['dependencies']
p['dependencies']='Cross-cutting: focused tests during implementation, then complete acceptance at each coherent boundary. The October 18 cleanup, ship/drop audit and fresh UAT are recorded in the completed ledger.'
old_outcome=p['next_outcome']
p['next_outcome']='Complete the remaining source/type/operator workflows and declared platform/resource envelopes; preserve independent correctness and matched comparative evidence for every new claim.'
old_partial='Nullable structural-layout correction has local acceptance; hosted closure belongs to PR #1574, separately from remaining physical/sink families.'
new_partial='Nullable structural-layout correction completed local and hosted acceptance in merged PR #1574; remaining physical/sink families stay open.'
for row in data['reconciliation']:
    if row['id']=='PERF-07.02':
        assert old_partial in row['completed_portion']
        row['completed_portion']=row['completed_portion'].replace(old_partial,new_partial)
data['status']='reconciled'
data['current_counts']['children']=len(data['steps'])
data['current_counts']['step_kinds']=dict(Counter(x['kind'] for x in data['steps']))
data['completed_batch_steps']=[dict(prebump, status='completed', authority=authority,
    evidence=['docs/benchmarks/native-roadmap-fresh-uat-2026-10-18.md',
        'docs/benchmarks/evidence/native-roadmap-fresh-uat-2026-10-18.json',
        'docs/architecture/local-artifact-cleanup-2026-10-18.md',
        'docs/architecture/native-roadmap-reconciliation-2026-10-18.md'])]
data['accepted_runtime_commit']=accepted['accepted_commit']
data['fresh_acceptance_scope']=dict(queries=43,calls=43,modular_cohorts=18,
    native_workflows=704,independent_oracle_records=704,public_acceptance_reexecuted=False)
assert data['current_counts']['children']==54
assert data['current_counts']['step_kinds']==dict(required=37,conditional=17)
assert len(data['reconciliation'])==149
for a,b in zip(original['children'],data['reconciliation']):
    for k in ('id','parent','label','checked','line','first_line'):assert a[k]==b[k],(a['id'],k)

plan=(O/'phased-execution-plan-draft-661.md').read_text()
start=plan.index('Current autonomous execution order:')
end=plan.index('\nThe current implementation remains',start)
plan=plan[:start]+'''Current autonomous execution order:

1. The nullable-layout integration, cleanup, ship/drop readiness audit and fresh UAT are complete in the [October 18 packet](../benchmarks/native-roadmap-fresh-uat-2026-10-18.md). Keep the next version bump held for the maintainer's next version decision.
2. Continue runtime breadth in dependency order: remaining PERF-03 resource owners, PERF-06 membership/population pressure and recovery, PERF-07 generation-conditional output publication/recovery, then the remaining PERF-02/10/11 source/type/operator compositions. PERF-01 attribution and PERF-12 acceptance accompany each coherent unit.
3. Extend PERF-04 reductions within existing accepted jobs when justified; new region/topology work must first pass PERF-03 region admission. Select performance experiments from current measured costs and retain their original gates and controls.
4. Preserve recorded drop decisions and paused large format/text experiments. The eight investigations remain open prerequisite/candidate work; no candidate is waiting only for a final timing run, and no unchanged sweep follows from this cleanup.
5. Queue native encoded transport after the current optimization/breadth contract. Continuous, distributed and shared-service outcomes retain the roadmap dependencies below.
'''+plan[end:]
old_counts='55 current substeps, including the eight previously prose-only investigations and the current pre-bump packet.'
assert plan.count(old_counts)==1
plan=plan.replace(old_counts,'54 current substeps: 37 required and 17 conditional, including the eight previously prose-only investigations. The completed pre-bump packet is in the ledger.')
lines=plan.splitlines()
assert sum('    - [ ] `PERF-12.prebump`' in x for x in lines)==1
plan='\n'.join(x for x in lines if '    - [ ] `PERF-12.prebump`' not in x)+'\n'
for before,after in ((old_dependency,p['dependencies']),(old_outcome,p['next_outcome'])):
    assert plan.count(before)==1
    plan=plan.replace(before,after)
for step in data['steps']:
    if step['kind']=='conditional':
        marker='    - [ ] `'+step['id']+'` '
        assert plan.count(marker)==1
        plan=plan.replace(marker,marker+'**Conditional.** ')
assert plan.split('## Planned\n',1)[0]==old.decode().split('## Planned\n',1)[0]
assert len(re.findall(r'^- \[ \] `',plan,re.M))==14
step_ids=re.findall(r'^    - \[ \] `([^`]+)`',plan,re.M)
assert len(step_ids)==len(set(step_ids))==54
assert set(step_ids)=={x['id'] for x in data['steps']}
assert all(t in step_ids for r in data['reconciliation'] for t in r['targets'])

md=(O/'native-roadmap-reconciliation-draft-661.md').read_text()
changes={
    'Status: draft pending primary semantic review and documentation validation.':'Status: reconciled after primary semantic review; documentation and gate validation are recorded with the accepted batch.',
    '| Measure | Before | Reconciled draft |':'| Measure | Before | Reconciled |',
    '| Current concrete substeps | Overlapping historical rows | 55 |':'| Current concrete substeps | Overlapping historical rows | 54: 37 required, 17 conditional |',
    'The 55 current steps include 46 destinations for legacy obligations, eight existing investigations previously carried in prose, and one current pre-bump acceptance packet.':'The 54 current steps include 46 destinations for legacy obligations and eight existing investigations previously carried in prose. The fresh pre-bump acceptance packet is completed separately in the ledger.',
    'Consolidation does not complete 66 tasks: it removes duplicate ownership and historical repetition.':'Consolidation removes duplicate ownership and historical repetition; it does not turn the merged obligations into completed work.',
    old_partial:new_partial,
    'The draft generator independently checks':'The reconciliation generator independently checks',
    'Documentation, v1-scope, runtime-gap, compute-completion and release-tracker validation must pass before this record is accepted. Completion and release trackers must continue to report the remaining open development queue.':'Documentation, v1-scope and runtime-gap checks pass; compute-completion and release-tracker checks retain the expected open-development blockers. The [batch validation record](../benchmarks/evidence/native-roadmap-documentation-validation-2026-10-18.json) records exact commands and results.',
}
for before,after in changes.items():
    assert md.count(before)==1,before
    md=md.replace(before,after)
md='\n'.join(x for x in md.splitlines() if not x.startswith('| `PERF-12.prebump` |'))+'\n'
md+='''
## Completed current acceptance packet

`PERF-12.prebump` is complete for this batch: the [fresh UAT](../benchmarks/native-roadmap-fresh-uat-2026-10-18.md) validates fresh ingestion, all 43 queries and 18 modular cohorts on merged runtime `6780e7df`; the [cleanup record](local-artifact-cleanup-2026-10-18.md) preserves scoped retirement receipts. The current source has no implemented ship/drop candidate awaiting only its final comparison. The eight prerequisite/candidate investigations remain open. The broader PERF-12 owner, platform claims and next version decision are unchanged.
'''
for name,value in [('phased-execution-plan-final-668.md',plan),
        ('native-roadmap-reconciliation-final-668.md',md),
        ('backlog-reconciliation-final-668.json',json.dumps(data,indent=2)+'\n')]:
    (O/name).open('x').write(value)
print(json.dumps(dict(status='finalized_for_validation',parents=14,steps=54,required=37,conditional=17,legacy_rows=149)))
