# CLICKBENCH-PRODUCTION-COLUMNAR-RESULT-DATAPLANE-1: current proof inventory

Source baseline: checkout `codex/native-nullable-layout` at `7daf50a9` (2026-10-18); frozen request `/Users/dylan/LocalData/shardloom/native-python-surface-20261010/backlog-original-660.json`. Read-only inventory: no builds, tests, benchmarks, source edits, or runtime UAT were performed for this report.

The eight child IDs below are exactly the child set listed by the JSON parent. Their checkbox state mirrors that frozen request (01/05/06 checked; 02/03/04/07/08 open), while the evidence assessment is current at the stated checkout. The checklist status is not upgraded by this inventory. No direct PR identifier is recorded for the September 3 shared-dataplane slice in the maintained completed ledger; PR #1456 is related native-result composition evidence only and explicitly does not establish broad operator parity.

## Child evidence

### CLICKBENCH-PRODUCTION-COLUMNAR-RESULT-DATAPLANE-1.01 — checked

**Contract evidence exists.** `shardloom-vortex/src/columnar_result_dataplane.rs:216-255` defines `VortexRetainedRowSet`; `:257-362` defines `VortexColumnarResultBatch` with constructors, selected columns and optional retained row set; the materialization boundary/report and certificate types are at `:449-639`. Exports are in `shardloom-vortex/src/lib.rs:183-191`. Unit tests `retained_row_refs_are_part_of_row_count_contract` (`:1001`) and `output_payload_descriptor_tracks_columnar_batch_content` (`:1035`) exercise row-count consistency and descriptor content.

The checked item is supported as a shared contract/model, not proof that production routes carry every validity, ordering/tie, and sink requirement through it. The active phase plan explicitly says route-wide result flow remains open (`docs/architecture/phased-execution-plan.md:3050-3124`).

### CLICKBENCH-PRODUCTION-COLUMNAR-RESULT-DATAPLANE-1.02 — open

**No selected-row aggregate handoff to this shared batch is evidenced.** The shared module exposes constructors and sink helpers but there is no reference to `VortexColumnarResultBatch`, `materialize_columnar_result_batch_for_sink`, or `output_payload_descriptor_from_columnar_result_batch` in `shardloom-cli/src` or `shardloom-python/src`. Existing Q23 evidence is narrower: `docs/architecture/public-io-route-repair-2026-09-27.md:94-103` records 7,128 selected rows and notes consumers that still materialize dictionary values in reader evidence and aggregate accessors. The active checklist at `docs/architecture/phased-execution-plan.md:3078-3093` retains selected measure ownership, exact aggregate arrays, and sink rendering as open work. No current source/test symbol proves the requested aggregate-to-retained-row handoff or avoided payload work.

### CLICKBENCH-PRODUCTION-COLUMNAR-RESULT-DATAPLANE-1.03 — open

**No exact aggregate-family sink parity is evidenced.** The phase-plan row at `docs/architecture/phased-execution-plan.md:3094-3107` still lists DISTINCT, compound/three-key Top-K, transformed grouping, pair late-measure state, Vortex/IPC/Parquet complete replay, and compatibility metadata-loss reporting as remaining adapters/acceptance. The generic batch sink tests below do not exercise those families. No family-specific result-batch adapter or parity test symbol was found in current source search; no source-backed PR completing this scope is identified.

### CLICKBENCH-PRODUCTION-COLUMNAR-RESULT-DATAPLANE-1.04 — open

**The production shared-batch route is not established.** `shardloom-cli/src/public_workflow_route.rs` contains independent native materialization and sink evidence paths (for example `append_native_array_sink_fields` at line 1254, `native_vortex_primitive_row_export_typed_sink_contract` at 2265, and `execute_native_vortex_materializing_with_source` at 3211), but does not call the shared `columnar_result_dataplane` helpers. Existing owners such as `OwnedVortexResultBatch` in `shardloom-vortex/src/resident_session.rs:1309` and native row-export/sink modules are distinct contracts, not evidence that filter/project/limit, sort/top-K, grouped aggregate, distinct, and row export all traverse `VortexColumnarResultBatch`. The active checklist says these route classes remain open (`docs/architecture/phased-execution-plan.md:3109-3110`); the maintained ledger likewise says full route-wide conversion remains open (`docs/architecture/phased-execution-completed-ledger.md:2486-2487`).

### CLICKBENCH-PRODUCTION-COLUMNAR-RESULT-DATAPLANE-1.05 — checked

**Generic sink adapter behavior is implemented and unit-tested.** `materialize_columnar_result_batch_for_sink` is at `shardloom-vortex/src/columnar_result_dataplane.rs:647`; it keeps a non-row-materializing sink on the batch path and returns a blocked result when encoded JSON materialization is unavailable. Tests: `columnar_batch_materializes_rows_only_at_json_sink_boundary` (`:890`), `native_vortex_sink_keeps_batch_columnar` (`:929`), and `opaque_encoded_json_materialization_blocks_without_fallback` (`:965`). The completed ledger records Vortex/Arrow-compatible handoff plus JSONL/CSV/CLI/Python materialization-boundary intent (`docs/architecture/phased-execution-completed-ledger.md:2430-2444`).

This supports the generic adapter contract only. It does not show every public local output route currently invokes this API or certify complete family parity; remote delivery remains explicitly unsupported (`:653-658`).

### CLICKBENCH-PRODUCTION-COLUMNAR-RESULT-DATAPLANE-1.06 — checked

**Certificate/report schema and generic behavior are present.** `VortexColumnarResultMaterializationCertificate` and evidence serialization are at `shardloom-vortex/src/columnar_result_dataplane.rs:449-551`; `VortexColumnarResultDataPlaneReport` and its evidence fields are at `:553-639`; report construction is at `:761-817`. The JSON sink test checks materialization accounting and boundary (`:890-927`); the native sink test checks zero row materialization (`:929-963`). This supports certificate fields and generic test behavior, not route-wide emission or the evidence required for every operator family.

### CLICKBENCH-PRODUCTION-COLUMNAR-RESULT-DATAPLANE-1.07 — open

**Broad parity suite is not evidenced.** Current module tests cover one simple JSON sink, one columnar Vortex sink, blocked opaque JSON, row-reference row-count contract, and descriptor content (`columnar_result_dataplane.rs:890-1070`). The active checklist still asks for order stability, null rendering, selected projection, wide-payload top-K, grouped and distinct output, JSON/CSV parity, and unsupported remote delivery (`docs/architecture/phased-execution-plan.md:3115-3116`). Existing individual native-operator tests or PR #1456 composition acceptance do not constitute this shared-dataplane family matrix; #1456 explicitly disclaims public operator parity in `docs/architecture/native-result-composition-2026-09-20.md:1-8`.

### CLICKBENCH-PRODUCTION-COLUMNAR-RESULT-DATAPLANE-1.08 — open

**No targeted Q23/Q24/Q25 plus top-K/grouped UAT tied to shared-batch routing is evidenced.** The completed ledger’s September 3 UAT is real historical full43 and ingest evidence, but explicitly leaves route-wide result conversion and targeted UAT open (`docs/architecture/phased-execution-completed-ledger.md:2430-2449,2486-2487`); it must not be read as proof of this checklist’s sink-path retain/drop gate. Later Q23 reports and Full43 passes concern other implementation slices and do not prove these routes used the shared result batch. The active plan retains targeted then full acceptance at `docs/architecture/phased-execution-plan.md:3117-3118`. `docs/architecture/native-result-composition-2026-09-20.md` records PR #1456 and complete scoped acceptance, but states it does not complete public operator parity (`:1-8`); no PR is identified as closing this child.

## Inventory conclusion

The checked rows 01, 05, and 06 have literal current contract/unit evidence at the stated scope. Five unchecked rows remain open. The shared model, generic sink helper, certificates, Q23 selected-row counts, separate native-result ownership, and broad Full43 success are not evidence of complete route-wide `ColumnarResultBatch` integration. No benchmark or runtime claim is made here.
