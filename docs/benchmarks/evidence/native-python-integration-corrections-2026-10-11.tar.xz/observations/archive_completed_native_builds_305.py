"""Preserve superseded task-local debug libraries before the corrected build."""
from pathlib import Path
import hashlib
import json
import os
import stat
import subprocess
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, '/Users/dylan/LocalData/shardloom/release-0.3.3-20260930')
sys.path.insert(0, '/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo/scripts')
from release_validation_guard import WorkloadGuard
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

require_local_path(ROOT, Path.home(), sys.platform)
workload = WorkloadGuard()
last_check = 0.0

def guard():
    global last_check
    if time.monotonic() - last_check >= 2:
        workload.check()
        check_budgets(ROOT, ROOT / 'reserved-artifact', ROOT / 'logs',
                      min_free_bytes=12 * GIB, reserve_bytes=128 * MIB,
                      max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
        last_check = time.monotonic()

def identity(path):
    s = path.lstat()
    assert stat.S_ISREG(s.st_mode) and s.st_nlink == 1
    return [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, stat.S_IMODE(s.st_mode), s.st_blocks * 512]

def digest(source):
    sha, size = hashlib.sha256(), 0
    while block := source.read(1 << 20):
        guard()
        sha.update(block)
        size += len(block)
    return sha.hexdigest(), size

# Debug-7 is already shared by six hardlinks and is intentionally preserved.
# Initial preflight stopped on that identity before any archive or removal.
for index, run in [(8, 'native-python-build-272'),
                   (304, 'native-failure-binding-build-304')]:
    guard()
    path = ROOT / f'native-binding-debug-{index}/_native.abi3.so'
    archive = ROOT / f'completed-native-bindings-305-{index}.zip'
    partial = archive.with_suffix('.zip.partial')
    receipt = archive.with_suffix('.json')
    assert all(not p.exists() for p in (archive, partial, receipt))
    completion = json.loads((ROOT / f'{run}.json').read_text())
    raw = (ROOT / f'{run}.log').read_bytes()
    assert completion['status'] == 'passed' and completion['process_group_drained']
    assert hashlib.sha256(raw).hexdigest() == completion['log_sha256']
    build = json.loads(raw.decode()[raw.decode().index('{\n  "schema_version": "shardloom.native_python_build.v1"'):])
    assert Path(build['library']) == path and build['status'] == 'passed'
    before = identity(path)
    with path.open('rb') as source:
        sha, size = digest(source)
    assert sha == build['library_sha256'] and size == build['library_bytes'] == before[2]
    opened = subprocess.run(['/usr/sbin/lsof', '-F', 'pfn', '--', str(path)],
                            text=True, capture_output=True)
    assert opened.returncode in (0, 1) and not opened.stdout, opened.stdout
    member = path.relative_to(ROOT).as_posix()
    record = {'status': 'running', 'path': str(path), 'archive': str(archive),
              'member': member, 'identity': before, 'sha256': sha, 'bytes': size,
              'build_receipt': str(ROOT / f'{run}.json'), 'open_handles': False,
              'removed': False, 'free_bytes_before': os.statvfs(ROOT).f_bavail * os.statvfs(ROOT).f_frsize,
              'scope': 'completed superseded native debug build retained byte-for-byte; failed test receipts and other evidence remain unchanged',
              'restoration': 'Extract the recorded member to its original path, restore recorded mode, and verify SHA-256.'}
    try:
        with zipfile.ZipFile(partial, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
            with path.open('rb') as source, output.open(member, 'w', force_zip64=True) as target:
                while block := source.read(1 << 20):
                    guard()
                    target.write(block)
        assert identity(path) == before
        with zipfile.ZipFile(partial) as saved:
            assert saved.namelist() == [member]
            with saved.open(member) as source:
                assert digest(source) == (sha, size)
        assert identity(path) == before
        os.replace(partial, archive)
        with archive.open('rb') as source:
            record['archive_sha256'], record['archive_bytes'] = digest(source)
        record['status'] = 'verified'
        receipt.write_text(json.dumps(record, indent=2) + '\n')
        opened = subprocess.run(['/usr/sbin/lsof', '-F', 'pfn', '--', str(path)],
                                text=True, capture_output=True)
        assert opened.returncode in (0, 1) and not opened.stdout and identity(path) == before
        path.unlink()
        record.update(status='passed', removed=True)
    finally:
        record['free_bytes_after'] = os.statvfs(ROOT).f_bavail * os.statvfs(ROOT).f_frsize
        receipt.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'status': record['status'], 'member': member,
                      'verified_bytes': size, 'archive_bytes': record['archive_bytes']}), flush=True)
