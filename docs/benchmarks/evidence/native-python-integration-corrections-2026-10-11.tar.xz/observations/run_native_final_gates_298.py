"""Run the remaining required source gates serially under run_guarded.py."""
import json
import argparse
from pathlib import Path
import subprocess
import time
from freeze_native_release_298 import sources

OUT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--run-id', required=True)
args = parser.parse_args()
assert args.run_id.isalnum()
frozen = json.loads((OUT / f'native-release-source-{args.run_id}.json').read_text())['source_sha256']
commands = [
    ('default-format', ['cargo', 'fmt', '--all', '--', '--check']),
    ('default-clippy', ['cargo', 'clippy', '--offline', '--locked', '--workspace',
                        '--all-targets', '--', '-D', 'warnings']),
    ('default-tests', ['cargo', 'test', '--offline', '--locked', '--workspace',
                       '--all-targets']),
    ('reduced-writer-tests', ['cargo', 'test', '--offline', '--locked', '-p',
                             'shardloom-cli', '--all-targets', '--no-default-features',
                             '--features', 'vortex-write']),
]
results = []
code = 1
try:
    assert sources() == frozen
    for name, command in commands:
        print(json.dumps({'gate': name, 'command': command}), flush=True)
        started = time.perf_counter()
        completed = subprocess.run(command, check=False)
        results.append({'name': name, 'command': command,
                        'returncode': completed.returncode,
                        'seconds': time.perf_counter() - started})
        print(json.dumps(results[-1]), flush=True)
        assert sources() == frozen
        if completed.returncode:
            raise SystemExit(completed.returncode)
    code = 0
finally:
    with (OUT / f'native-final-source-gate-results-{args.run_id}.json').open('x') as stream:
        json.dump({'status': 'passed' if code == 0 else 'failed', 'gates': results},
                  stream, indent=2)
        stream.write('\n')
