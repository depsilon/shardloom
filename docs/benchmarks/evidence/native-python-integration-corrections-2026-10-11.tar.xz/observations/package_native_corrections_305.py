"""Bind integration corrections and regression evidence to exact native source."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
from freeze_native_release_298 import ROOT, OUT, sha, sources

frozen_path = OUT / 'native-release-source-305.json'
frozen = json.loads(frozen_path.read_text())['source_sha256']
assert sources() == frozen
original = json.loads((OUT / 'native-release-source-300.json').read_text())['source_sha256']
changed = sorted(name for name, value in frozen.items() if original.get(name) != value)
assert len(frozen) == 1319 and len(changed) == 13
assert all(name in frozen for name in original)

names = [
    'native-quickstart-counter-before-304', 'native-quickstart-counter-after-304',
    'native-quickstart-release-tests-304', 'native-failure-evidence-red-304',
    'native-failure-evidence-green-304', 'native-failure-binding-build-304',
    'native-failure-binding-build-305', 'native-failure-red-305', 'native-failure-green-305',
    'native-final-source-gates-305', 'native-final-clippy-305',
    'native-final-cli-tests-305', 'native-final-python-tests-305',
]
receipts = {}
members = {}

def add_file(path, member):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    data = path.read_bytes()
    assert member not in members
    members[member] = data
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

for name in names:
    path = OUT / (name + '.json')
    receipt = json.loads(path.read_text())
    log = OUT / (name + '.log')
    assert receipt['process_group_drained'] and sha(log) == receipt['log_sha256']
    expected = 'failed' if name in (
        'native-failure-evidence-red-304', 'native-failure-evidence-green-304',
        'native-failure-red-305',
    ) else 'passed'
    assert receipt['status'] == expected, (name, receipt['status'])
    receipts[name] = {'receipt': add_file(path, 'observations/' + path.name),
                      'log': add_file(log, 'observations/' + log.name),
                      'status': receipt['status'], 'command': receipt['command'],
                      'seconds': receipt['seconds']}

for name in [
    'run_guarded.py', 'freeze_native_release_298.py', 'run_native_final_gates_298.py',
    'native-final-source-gate-results-305.json', 'native-release-source-305.json',
    'prove_quickstart_counter_304.py', 'native-hosted-package-transcript-304.json',
    'native-hosted-package-transcript-fetch-304.json', 'native-hosted-package-failure-303.log',
    'native-hosted-windows-failure-304.log', 'native-refusal-report-inventory-305.json',
    'archive_completed_native_builds_305.py', 'completed-native-bindings-305-8.json',
    'completed-native-bindings-305-304.json', 'package_native_corrections_305.py',
]:
    add_file(OUT / name, 'observations/' + name)
for relative in ('quickstart-counter-before-304/report.json', 'quickstart-counter-after-304/report.json'):
    add_file(OUT / relative, 'observations/' + relative)
for name in changed:
    assert sha(ROOT / name) == frozen[name]
    add_file(ROOT / name, 'source/' + name)
patch = subprocess.check_output(['git', 'diff', '--binary', '9b730d45', '--',
                                'shardloom-cli', 'shardloom-python', 'python',
                                'examples/local-python-smoke/run.py'], cwd=ROOT)
members['source/tracked-correction.patch'] = patch

def counts(name):
    result = {}
    section = name
    for line in (OUT / (name + '.log')).read_text().splitlines():
        if line.startswith('{"gate":'):
            section = json.loads(line)['gate']
        found = re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', line)
        if found:
            entry = result.setdefault(section, {'passed': 0, 'failed': 0, 'ignored': 0, 'suites': 0})
            for key, value in zip(('passed', 'failed', 'ignored'), found.groups()):
                entry[key] += int(value)
            entry['suites'] += 1
    return result

python_log = (OUT / 'native-final-python-tests-305.log').read_text()
assert re.search(r'Ran 739 tests in [0-9.]+s\n\nOK\n', python_log)
assert 'skipped=' not in python_log
build_text = (OUT / 'native-failure-binding-build-305.log').read_text()
build = json.loads(build_text[build_text.index('{\n  "schema_version": "shardloom.native_python_build.v1"'):])
assert sha(build['library']) == build['library_sha256']
index = {
    'schema_version': 'shardloom.native_python_integration_corrections.v1',
    'status': 'local_corrections_verified_hosted_pending',
    'base_commit': '9b730d4502eee0a7609ee67483978e2a4fd5bd6f',
    'selected_source_files': len(frozen), 'source_manifest_sha256': sha(frozen_path),
    'changed_from_initial_acceptance': changed,
    'unchanged_selected_initial_files': sum(frozen.get(name) == value for name, value in original.items()),
    'debug_library': build, 'receipts': receipts,
    'test_counts': {**counts('native-final-source-gates-305'),
                    **counts('native-final-cli-tests-305'),
                    'python-all': {'passed': 739, 'failed': 0, 'skipped': 0},
                    'new-native-failure-regressions': {'passed': 6, 'failed': 0}},
    'corrections': [
        'Freeze native plan/input failure resource snapshots inside the admitted operation; keep declaration-only fields on admission refusal.',
        'Carry native resource fields into public returned/raised errors and stream failures; preserve producer exception identity.',
        'Keep explicit native-owner refusal authoritative over an enclosing generic command workspace observation.',
        'Compute quickstart generated-input file opens as a delta of the retained session counter; reject reset and extra-open fixtures.',
    ],
    'preserved_failures': [
        'Hosted package quickstart and Windows native-admission tests failed on 9b730d45; original logs and package transcript are retained.',
        'The first new test run used invalid low-level writer format labels and a legacy-only envelope accessor. Corrected tests use write_jsonl/write_vortex and typed result fields.',
        'All six corrected regression methods fail against the original release extension with missing resource fields, then pass against the corrected debug extension.',
        'Initial archive preflight stopped on debug-7 with six hardlinks before writing or removing anything; that shared file remains preserved.',
    ],
    'scope': {
        'current_native_integration': 'Included in the 739-test suite; native extension required and no skips.',
        'windows_execution': 'Not simulated on macOS; actual hosted Windows regression remains required.',
        'installed_release_wheel': 'Original installed wheel remains historical; corrected native release wheel proof is required in all three hosted matrix jobs.',
        'unchanged_engine': 'All original Vortex source hashes and the dependency graph remain identical; prior full native Vortex and paired-workflow evidence keeps its original source identity.',
        'timings': 'No new Full43, ingestion or Python-workflow timing claim; original 300c measurements remain bound to their original build.',
        'published': False, 'version': '0.5.1',
    },
    'members': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                for name, data in members.items()},
}
assert index['test_counts']['default-tests']['passed'] == 3214
assert index['test_counts']['reduced-writer-tests']['passed'] == 1145
assert index['test_counts']['native-final-cli-tests-305']['passed'] == 1398
assert index['test_counts']['native-final-cli-tests-305']['ignored'] == 3
assert all(frozen[name] == value for name, value in original.items()
           if name.startswith('shardloom-vortex/') or name in ('Cargo.lock', 'Cargo.toml'))
index_bytes = (json.dumps(index, indent=2) + '\n').encode()
archive_path = OUT / 'native-python-integration-corrections-305.tar.xz'
with tarfile.open(archive_path, 'x:xz') as archive:
    for name, data in {**members, 'index.json': index_bytes}.items():
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        archive.addfile(info, io.BytesIO(data))
with tarfile.open(archive_path, 'r:xz') as archive:
    assert set(archive.getnames()) == set(members) | {'index.json'}
    for entry in archive:
        assert entry.isfile()
        expected = index_bytes if entry.name == 'index.json' else members[entry.name]
        assert archive.extractfile(entry).read() == expected
assert sources() == frozen and sha(build['library']) == build['library_sha256']
summary = {key: value for key, value in index.items() if key != 'members'}
summary.update(archive_bytes=archive_path.stat().st_size, archive_sha256=sha(archive_path),
               index_sha256=hashlib.sha256(index_bytes).hexdigest(),
               verified_members=len(members) + 1)
summary_path = OUT / 'native-python-integration-corrections-305.json'
with summary_path.open('x') as output:
    json.dump(summary, output, indent=2)
    output.write('\n')
for source, suffix in [(archive_path, '.tar.xz'), (summary_path, '.json')]:
    target = ROOT / ('docs/benchmarks/evidence/native-python-integration-corrections-2026-10-11' + suffix)
    with source.open('rb') as origin, target.open('xb') as dest:
        while block := origin.read(1 << 20):
            dest.write(block)
    assert sha(target) == sha(source)
print(json.dumps({'status': summary['status'], 'members': summary['verified_members'],
                  'bytes': summary['archive_bytes'], 'sha256': summary['archive_sha256']}), flush=True)
