"""Replay the release quickstart against the accepted native CLI."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--phase', choices=['before', 'after'], required=True)
args = parser.parse_args()
frozen = json.loads((OUT / 'native-release-artifacts-300.json').read_text())
binary = Path(frozen['cli']['path'])
assert hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest() == frozen['cli']['sha256']
fixture = OUT / f'quickstart-counter-{args.phase}-304'
assert not fixture.exists()
(fixture / 'python/src').mkdir(parents=True)
(fixture / 'python/src/shardloom').symlink_to(ROOT / 'python/src/shardloom', target_is_directory=True)
command = [sys.executable, str(ROOT / 'examples/local-python-smoke/run.py'),
           '--repo-root', str(fixture), '--shardloom-bin', str(binary),
           '--memory-gb', '4', '--max-parallelism', '2']
run = subprocess.run(command, capture_output=True, text=True, timeout=60)
record = {'phase': args.phase, 'binary': frozen['cli'], 'command': command,
          'returncode': run.returncode, 'stdout': run.stdout, 'stderr': run.stderr,
          'example_sha256': hashlib.sha256((ROOT / 'examples/local-python-smoke/run.py').read_bytes()).hexdigest()}
(fixture / 'report.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
assert run.returncode == (1 if args.phase == 'before' else 0)
assert 'quickstart_local_file_route_status=passed' in run.stdout
assert 'quickstart_generated_result_verified=true' in run.stdout
assert f'quickstart_generated_source_opens={1 if args.phase == "before" else 0}\n' in run.stdout
if args.phase == 'after':
    sys.path.insert(0, str(ROOT / 'scripts'))
    from check_v1_example_replay import validate_quickstart
    _, blockers = validate_quickstart({'returncode': run.returncode, 'stdout_tail': run.stdout})
    assert not blockers, blockers
