"""Locate the frozen-build fanout/readback denial without changing its grant."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
DEST = OUT / 'fanout-diagnostic-724'
DEST.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT / 'python/tests'))
from test_native_binding import _load_native
from test_native_set_binding import combine
_load_native()
import shardloom as sl

COUNT, OFFSET, GRANT = 8193, 4096, 16 << 20

def row(key):
    return {'n': key, 's': f'{key:08d}' + 'p' * 2040}

def snapshot(client):
    return client._native_backend.session.snapshot()

def client():
    return sl.ShardLoomClient(transport='native', memory_bytes=GRANT, max_parallelism=1)

def read(path, format_name, owner, keys, retain):
    before = snapshot(owner) if owner._native_backend is not None else None
    frame = getattr(sl, 'read_' + format_name)(path, client=owner)
    seen, held, failure = 0, None, None
    try:
        with frame.iter_batches(batch_rows=127) as stream:
            for batch in stream:
                table = batch.to_arrow()
                if retain and seen == 0:
                    held = table
                for value in table.to_pylist():
                    assert value == row(keys[seen])
                    seen += 1
            assert seen == len(keys)
    except Exception as error:
        failure = str(error)
    during = snapshot(owner)
    if held is not None:
        assert held.to_pylist() == [row(key) for key in keys[:held.num_rows]]
    del frame, held
    return {'status': 'failed' if failure else 'passed', 'rows': seen,
            'retain_first': retain, 'error': failure, 'before': before,
            'at_end': during, 'after_frame_drop': snapshot(owner)}

records = []
with patch('subprocess.Popen', side_effect=AssertionError('child process')), \
     patch('shardloom._batches.BatchInput.encode', side_effect=AssertionError('JSON input')):
    for kind in ('union', 'intersect', 'except_'):
        root = DEST / kind
        root.mkdir()
        workspace = root / 'runs'
        workspace.mkdir()
        owner = client()
        events = [[], []]
        def source(side):
            def produce():
                events[side].append('opened')
                try:
                    for start in range(0, COUNT, 251):
                        yield [row(COUNT - 1 - index if side == 0 else OFFSET + index)
                               for index in range(start, min(start + 251, COUNT))]
                    events[side].append('ended')
                finally:
                    events[side].append('closed')
            return sl.from_batches(produce, schema={'n': 'int64', 's': 'utf8'},
                                   streaming=True, client=owner)
        left, right = source(0), source(1)
        query = combine(left, right, kind)
        keys = [key for key in range(COUNT - 1, -1, -1)
                if kind == 'union' or (key >= OFFSET) == (kind == 'intersect')]
        if kind == 'union':
            keys.extend(range(COUNT, COUNT + OFFSET))
        targets = {name: root / ('result.' + name) for name in ('vortex', 'parquet', 'jsonl')}
        record = {'kind': kind, 'memory_bytes': GRANT, 'source_events': events}
        try:
            report = query.fanout(targets, spill={'workspace': str(workspace),
                'quota_bytes': 128 << 20, 'buffer_bytes': 1 << 20})
            record['fanout'] = {'status': 'passed', 'snapshot': snapshot(owner),
                               'report': report.envelope.raw}
        except Exception as error:
            record['fanout'] = {'status': 'failed', 'error': str(error),
                               'snapshot': snapshot(owner)}
        assert list(workspace.iterdir()) == []
        if record['fanout']['status'] == 'passed':
            record['readback'] = []
            for format_name in ('vortex', 'parquet'):
                observation = read(targets[format_name], format_name, owner, keys, True)
                record['readback'].append(dict(observation, format=format_name, owner='producer'))
                for retain in (False, True):
                    reader = client()
                    observation = read(targets[format_name], format_name, reader, keys, retain)
                    record['readback'].append(dict(observation, format=format_name, owner='fresh'))
                    reader.close()
            with targets['jsonl'].open() as stream:
                seen = 0
                for line in stream:
                    assert json.loads(line) == row(keys[seen])
                    seen += 1
                assert seen == len(keys)
            record['jsonl_complete_values_passed'] = True
        record['artifacts'] = [dict(path=str(path), bytes=path.stat().st_size,
            sha256=hashlib.sha256(path.read_bytes()).hexdigest())
            for path in targets.values() if path.exists()]
        owner.close()
        records.append(record)
        print(json.dumps({'kind': kind, 'fanout': record['fanout']['status'],
            'readback': [{key: item[key] for key in ('format', 'owner', 'retain_first', 'status', 'rows')}
                         for item in record.get('readback', [])]}), flush=True)

assert records[0]['fanout']['status'] == 'failed'
assert all(item['source_events'] == [['opened', 'ended', 'closed']] * 2 for item in records)
result = {'status': 'diagnosis_recorded', 'source_commit': subprocess.check_output(
    ['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'grant_unchanged': True, 'records': records}
with (OUT / 'fanout-diagnostic-724.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
