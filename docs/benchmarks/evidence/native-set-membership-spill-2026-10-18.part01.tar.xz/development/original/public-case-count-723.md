# Public set-pressure UAT case count

Read-only source count against `HEAD 5829e71cadab82c75e25285e52c3d8800479a1fe`. No UAT, native job, build or test was run, and no repository file was edited.

## Count

| Change | Loop-derived public cases | Source |
| --- | ---: | --- |
| New distinct-set streaming cases: kinds × right-side offsets × surfaces | 3 × 3 × 2 = 18 | `scripts/native_streaming_set_spill_cases.py:33–34,65–79` |
| New distinct-set writes: kinds × all writer formats | 3 × 8 = 24 | `scripts/native_streaming_set_spill_cases.py:107–122`; `LOCAL_FORMATS` at `scripts/native_workflow_outputs.py:18` |
| New empty EXCEPT writes: all writer formats | 8 | `scripts/native_streaming_set_spill_cases.py:124–136` |
| New distinct-set fanout: one all-eight fanout per distinct operation | 3 | `scripts/native_streaming_set_spill_cases.py:138–155` |
| New failure cases: producer/corrupt failures on both sides and both output modes, plus quota on the selected side and both output modes | 3 × ((2 × 2 sides × 2 modes) + (1 quota side × 2 modes)) = 30 | `scripts/native_streaming_set_spill_cases.py:157–194` |
| **New module subtotal** | **83** | |
| Removed duplicate denial cases: old spill-disabled and spill-enabled denial per distinct operation becomes one spill-disabled denial per operation | 3 − 6 = **−3** | HEAD version `git show 5829e71c:scripts/native_streaming_set_pressure_cases.py:128–150`; current `scripts/native_streaming_set_pressure_cases.py:129–149` |
| **Net expected delta** | **+80** | |

Using the supplied prior full-public total of 4,827, the expected total is **4,907**. The loop-derived delta is exact from the current source; 4,827 is the stated prior total and was not independently recomputed across all public families in this read-only assignment.

## Case labels and helper accounting

The new module's 83 `harness.case` registrations have these label families:

- `set-membership-spilled-{union|intersect|except_}-{0|4096|8193}-{dataframe|sql}`: 18 complete streamed-result cases. Offsets are `0`, `ROWS // 2` (4,096), and `ROWS` (8,193), with DataFrame and SQL surfaces (`:33–34,65–79`).
- `set-membership-spilled-{union|intersect|except_}-write-{vortex|parquet|arrow_ipc|avro|orc|json|jsonl|csv}`: 24 cases (`:107–122`).
- `set-membership-spilled-except-empty-write-{vortex|parquet|arrow_ipc|avro|orc|json|jsonl|csv}`: 8 empty-result cases (`:124–136`).
- `set-membership-spilled-{union|intersect|except_}-fanout-all-eight`: 3 fanout cases (`:138–155`). Each produces eight outputs, confirms one relational execution and eight result replays; the per-format `verify_output` callbacks validate those artifacts but do not call `harness.case`.
- `set-membership-spill-{union|intersect|except_}-{producer|corrupt}-side-{0|1}-write-{False|True}`: 24 fault cases; producer and corrupt failures each cover both source sides and both streaming batches/Vortex-write modes (`:157–194`).
- `set-membership-spill-{union|intersect|except_}-quota-side-0-write-{False|True}`: 6 quota cases (`:157–194`).

The current pressure family retains four duplicate-heavy cases (the four `KINDS` values), three no-policy distinct-membership denial controls, one `set-replay-resident-denied` control, two `set-replay-spilled-{batches|vortex}` cases, and six `set-replay-{producer|corrupt|quota}-write-{False|True}` failures. Total: 16; HEAD has the same groups except six denial controls, for 19 total. The `UNION ALL` replay-resident control is unchanged and is not a distinct-membership denial (`scripts/native_streaming_set_pressure_cases.py:101–149,163–199,201–232`).

Shared helpers such as `capture`, `complete`, `verify_output`, `accepted`, and `checked_values` produce/validate evidence but do not register additional cases. `Harness.case` appends exactly one result for each explicit call (`scripts/run_native_streaming_input_uat.py:171–184`). Writer-format names come from the eight-entry `LOCAL_FORMATS` tuple at `scripts/native_workflow_outputs.py:18`.

## Runner capture and selection

`run_native_streaming_input_uat.py` includes `native_streaming_set_pressure_cases.py` and the new `native_streaming_set_spill_cases.py` in its frozen source list at lines 238–239. The pressure module imports and invokes the new `run` helper at lines 234–235, so it is exercised by the existing `sets-pressure` family key (`:68–70`). The source list inclusion is explicit; this verifies source hashing/capture by inspection, not an executed UAT receipt.

## Unresolved issues

- The baseline total of 4,827 was supplied as context, not rederived from all public family loops here. Therefore 4,907 is conditional on that prior total, while the source-level delta of +80 is independently loop-counted.
- The current no-spill denial names/assertions remain intentional capability controls. They do not assert that the explicit-spill cases fail; those positive cases are registered separately by the new module.
- No source-level issue was found that adds implicit `Harness.case` registrations from helper callbacks; callbacks emit evidence and value checks only.
