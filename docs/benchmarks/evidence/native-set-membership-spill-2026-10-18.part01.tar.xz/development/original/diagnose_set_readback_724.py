"""Check the independent file-reader verification grant on existing diagnostic outputs."""
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'python/tests'))
from test_native_binding import _load_native
_load_native()
import shardloom as sl

records = []
with patch('subprocess.Popen', side_effect=AssertionError('child process')), \
     patch('shardloom._batches.BatchInput.encode', side_effect=AssertionError('JSON input')):
    for kind in ('intersect', 'except_'):
        keys = list(range(8192, 4095, -1)) if kind == 'intersect' else list(range(4095, -1, -1))
        for format_name in ('vortex', 'parquet'):
            path = OUT / 'fanout-diagnostic-724' / kind / ('result.' + format_name)
            client = sl.ShardLoomClient(transport='native', memory_bytes=32 << 20, max_parallelism=1)
            frame = getattr(sl, 'read_' + format_name)(path, client=client)
            seen, held, digest = 0, None, hashlib.sha256()
            with frame.iter_batches(batch_rows=127) as stream:
                for batch in stream:
                    table = batch.to_arrow()
                    if seen == 0:
                        held = table
                    for value in table.to_pylist():
                        key = keys[seen]
                        assert value == {'n': key, 's': f'{key:08d}' + 'p' * 2040}
                        digest.update((json.dumps(value, sort_keys=True) + '\n').encode())
                        seen += 1
                assert seen == len(keys)
            snapshot = client._native_backend.session.snapshot()
            assert snapshot['memory_limit_bytes'] == 32 << 20
            assert snapshot['denied_reservations'] == 0
            del frame
            client.close()
            assert held.to_pylist() == [{'n': key, 's': f'{key:08d}' + 'p' * 2040}
                                       for key in keys[:held.num_rows]]
            records.append({'kind': kind, 'format': format_name, 'status': 'passed',
                'rows': seen, 'values_sha256': digest.hexdigest(), 'snapshot': snapshot,
                'file': str(path), 'file_sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
result = {'status': 'passed', 'operator_grant_bytes': 16 << 20,
          'independent_readback_grant_bytes': 32 << 20, 'records': records,
          'readback_is_not_operator_pressure_evidence': True}
with (OUT / 'readback-diagnostic-724.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({'status': 'passed', 'complete_readbacks': len(records)}))
