# Remaining native membership and population state inventory (PERF-06)

Scope: production consumers in the prepared relational and native relational unary/subquery paths after the distinct set spill path. This is an inventory of visible state and pressure coverage, not an architecture proposal or a defect finding.

## Unary operations

`shardloom-vortex/src/local_primitive_prepared_relational.rs:1217-1225` dispatches `NodeKind::Unary` to `operation.consume_relation(...)` and records state usage. That dispatch has no spill argument or spill branch. The prepared operation selector admits `DistinctRows`, `DropDuplicateRows`, `DuplicateMaskRows`, `TailRows`, `SampleRows`, and `PivotRows` (`local_primitive_prepared_unary.rs:109-123`); `consume_relation` constructs a `select::State`, streams all input through it, then finishes (`:468-502`). The source-file Tail path separately uses a native Vortex row range (`:919-926`), while relational Tail uses its unary state.

`local_primitive_unary_select.rs:24-55,58-68,255-410` contains the stateful selector and its key index:

- `DistinctRows` and first-occurrence `DropDuplicateRows` retain distinct keys in `KeyIndex` (`:295-314`).
- Last/all duplicate modes retain keyed `OwnedRow` entries (`:315-328`).
- Non-first `DuplicateMaskRows` retain per-input identity tuples `(ordinal, key_index)` (`:336-339`); finish reconstructs output from those identities (`:363-410`). This population-sized vector is separate from the distinct-key index.
- `TailRows` uses a ring buffer bounded by the requested tail count (`:192-251`), rather than retaining the entire input by default.

Sampling state is in `local_primitive_unary_sample.rs:31-75,112-150`: with-replacement sampling retains a candidate per observed input row (`:112-125`); without-replacement sampling retains a bounded top-k set (`:126-150`). Fractional sampling with unknown input size sets its target cap to `usize::MAX` (`:64-70`).

PivotRows is present in the prepared unary capability list but has a separate pivot spill implementation (`local_primitive_unary_pivot_spill.rs`); it is not counted here as an unspilled remaining state family.

Existing negative pressure selectors:

- `streaming_unary_resident_keys_and_sample_population_refuse_excess_even_with_replay_spill` — `local_primitive_relational_batch_unary_pressure_tests.rs:234-293`; exercises resident key/sample pressure with replay spill disabled and enabled.
- `streaming_future_duplicate_masks_charge_population_identities_separately_from_keys` — same file, `:297-363`; covers identity-vector pressure separately from unique-key pressure.
- `streaming_unary_bounded_state_completes_input_larger_than_its_grant` — same file, `:181-230`; positive bounded-state contrast.

## Subquery operations and RowIndex

The implementation is `shardloom-vortex/src/local_primitives/native_relational_subquery.rs` (there is no `native_relational_subquery*.rs` at the crate root). `Kind` covers `In`, `Quantified`, `Exists`, and `Scalar` (`:27-37`). `Subquery` owns a right-side `Table`, correlation `RowIndex`, IN-match `RowIndex`, and nullable-row vector (`:49-55`); `new` allocates these resident structures (`:118-127`). `build` accumulates right-side rows; correlated forms index correlation keys, and `IN` indexes non-null exact keys while recording nullable rows (`:129-176`). No spill branch is visible in this build/index path.

`evaluate` first does correlated lookup and exact `IN` membership lookup (`:266-326`); remaining cases reduce over correlated rows, nullable candidates, or the retained right table (`:304-325,338-385`). `Scalar` rejects more than one row before retaining a result (`:134-145`), so it is cardinality-bounded by its semantic check. `Exists` and quantified forms retain/inspect the right table; whether this population is material for a given plan depends on its input cardinality and correlation.

`shardloom-vortex/src/local_primitives/native_relational_index.rs:21-35,38-148` defines `RowIndex` as resident reserved bucket, entry, and duplicate-link vectors; it has no visible spill path. The prepared relational subquery dispatch is `local_primitive_prepared_relational.rs:1292` (subquery node); its relational runner builds the native subquery state and supplies right-side batches to it. Replay spill is a separate source/replay path and does not itself spill these indexes.

Existing negative pressure selectors:

- `streaming_subqueries_resident_membership_denial_is_not_hidden_by_replay_spill` — `local_primitive_relational_batch_subquery_pressure_tests.rs:156-211`; checks resident membership denial with replay spill off/on and a successful subsequent execution.
- `streaming_dynamic_subqueries_resident_membership_denial_survives_replay_spill_and_recovers` — `local_primitive_relational_batch_deferred_pressure_tests.rs:295-340`; same distinction for deferred/dynamic subqueries.

The RowIndex unit-level pressure and cancellation coverage is in `native_relational_index.rs`: `growth_keeps_all_collision_chains_and_denial_does_not_publish_a_partial_row` (`:228-258`) and `cancellation_interrupts_collision_search_without_publishing_a_row` (`:260+`).

## Boundary note

The distinct set path is already a separate `NodeKind::Set` spill branch in `local_primitive_prepared_relational.rs:1436-1463`, followed by the resident `RowSet` path at `:1465+`; it is recorded here only to mark the inventory boundary. No conclusion is made here about whether the remaining state families should share a spill design or how they should be prioritized.
