# Native set spill acceptance inventory

Read-only inventory for the native distinct-set spill acceptance. Repository inspected at `/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo`, branch `codex/native-membership-spill`. Repository files were not edited and no build, test, benchmark or runtime job was run. The checkout already had primary-owned uncommitted changes when inspected.

## Contract boundary

The active contract is `/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo/docs/architecture/native-set-membership-spill-2026-10-18.md`. It enables spill only for distinct `UNION`, `INTERSECT`, and `EXCEPT`; `UNION ALL` and the resident path remain controls (contract lines 22–55). It expressly excludes general unary/population and subquery membership spill. The intended distinction is important because other existing tests exercise refusals for those unaffected state families.

## Existing native set selectors

Rust unit tests in `shardloom-vortex/src/local_primitive_relational_batch_set_pressure_tests.rs` currently contain:

| Exact selector | Current assertion / scope | Source lines |
| --- | --- | --- |
| `streaming_sets_release_duplicate_payload_when_cumulative_input_exceeds_grant` | All four set kinds; long low-cardinality input, batch release, resident state fits | 104–157 |
| `streaming_set_membership_growth_is_denied_without_spill_permission` | Only distinct `UNION`/`INTERSECT`/`EXCEPT`; high-cardinality denial, no spill policy | 161–190 |
| `streaming_set_membership_spill_completes_exact_values_beyond_the_resident_grant` | Current worktree already has the positive spill case for the same three kinds; exact count/order, complete sources, grant, run/quota/cleanup checks | 193–250 |

The architecture roadmap verification document still names the older selector `streaming_set_membership_growth_is_denied_with_or_without_replay_spill_permission` and asks for the refusal regression to be updated when the boundary changes (`docs/architecture/native-roadmap-verification-contracts-2026-10-18.md:85–92`). That literal does **not** match the current Rust source selector; it needs reconciliation in the acceptance command record. The current public harness refusal names are generated as `set-membership-pressure-denied-{union|intersect|except_}-spill-{False|True}` (`scripts/native_streaming_set_pressure_cases.py:128–146`). Those are stale as positive-capability acceptance selectors for the three distinct kinds; the separate `set-replay-resident-denied` case is the repeated-source `UNION ALL` replay control (`:167–179`).

Existing semantic/composition Rust selectors are in `shardloom-vortex/src/local_primitive_relational_batch_set_tests.rs`:

- `streaming_sets_complete_nulls_duplicates_empty_branches_and_retained_outputs` (`151–256`): kinds include `UNION ALL` plus distinct variants; nulls, duplicates, empty sides, held outputs, spill-policy control, cleanup and owner refund.
- `streaming_sets_inspect_both_branches_and_preserve_static_depth_refusals` (`259–283`): malformed/correlated branches and depth remain early refusals.
- `streaming_sets_reuse_one_producer_through_native_replay_for_every_kind` (`285–314`): repeated producer/replay and fresh re-execution.
- `streaming_sets_nested_replay_and_zero_limits_drain_all_producers` (`316–362`): nested sets and complete draining at zero/nonzero limits.
- `streaming_sets_failure_cancellation_and_consumer_errors_release_all_state` (`364–425`): producer sides, cancellation and consumer failure.

The distinct spill implementation is connected from `shardloom-vortex/src/local_primitive_prepared_relational.rs:1437`; implementation module path is `shardloom-vortex/src/local_primitives/native_relational_set_spill.rs` (current branch file). No source-level test run was performed here.

## Public streaming family and output formats

Public driver: `scripts/run_native_streaming_input_uat.py`. It exposes `--families` with choices from `FAMILIES` and defaults to every family (`:61–74`, `:194–205`). The relevant family keys are exactly `sets` and `sets-pressure` (`:68–70`). A focused invocation shape is:

```sh
python3 scripts/run_native_streaming_input_uat.py --binary <frozen-binary> --uat-root <new-local-only-directory> --families sets sets-pressure
```

The runner requires a new output root; on macOS it must be local-only and use the repository's storage controls. The repo's existing runner source selects `native_streaming_set_cases.run` and `native_streaming_set_pressure_cases.run` for those family keys.

The exact `LOCAL_FORMATS` tuple in `scripts/native_workflow_outputs.py:18` is:

`vortex`, `parquet`, `arrow_ipc`, `avro`, `orc`, `json`, `jsonl`, `csv`.

For every operation in `KINDS` (`union_all`, `union`, `intersect`, `except_`), `scripts/native_streaming_set_cases.py:151–174` writes each local format individually and writes a fanout case; it reopens each target and checks complete values (`:169–171`). Lines 176–186 add an empty-result write/reopen for every format. Thus the public modular writer matrix already includes all eight formats for every set kind, with non-empty and empty output cases. The pressure public harness currently does not run distinct set pressure writes: its positive-pressure loops cover batches (`:93–126`), its distinct cases assert denial (`:128–149`), and its write cases exercise source replay controls only (`:202–233`). The direct binding test's fanout list is only `("vortex", "parquet", "jsonl")` and its single-writer terminal is Vortex (`python/tests/test_native_set_binding.py:133–143`); it is not the all-eight writer matrix.

The complete streaming modular workflow acceptance is broader than the set format matrix. The runner's `--families` default selects all current entries in `FAMILIES`, while the October 13 acceptance describes the complete modular format/workflow matrix and separate Full43 runner (`docs/benchmarks/native-stream-input-composition-2026-10-13.md:125–131`). The set-specific report describes its own all-family and Full43 reproduction context (`docs/benchmarks/native-stream-sets-2026-10-15.md:276–281`), but its historical immutable command transcript is outside this source inventory. **Unknown:** exact safe output-root, frozen binary/library and retained Full43 input arguments from the historical evidence packet are not restated here.

## Direct binding cases

Source-level test class is `NativeSetBindingTests` in `python/tests/test_native_set_binding.py:51–61`. Exact methods found:

- `test_native_set_independent_repeated_and_positional_sources_across_terminals` (`92–155`): all four kinds, independent/repeated/positional sources, DataFrame and SQL, collect/batches/Vortex/fanout; patches subprocess creation and JSON input encoding to prove direct binding path.
- `test_native_set_late_failure_zero_limit_and_early_consumer_close` (`157–210+`): producer/schema/cancel failures from both sides, collect/zero/fanout, publication and foreign-file preservation, then recovery query.
- `test_native_set_rich_full_row_equality_preserves_owned_output` (later in the same file): typed nested full-row values and retained ownership.

**Unknown:** no repository script or doc was found that records the exact unittest command for this one module in the searched roots. Do not infer that `python -m unittest ...` was run; source inspection only. The prior set acceptance report records 87 direct Python binding tests overall, not a newly run result (`docs/benchmarks/native-stream-sets-2026-10-15.md:48–59`).

## Failure and process-recovery coverage

For streamed-set source replay (the adjacent but distinct state), the exact Rust fault selector is `streaming_union_source_replay_faults_preserve_foreign_files_and_deny_completion` in `shardloom-vortex/src/local_primitive_relational_batch_set_fault_tests.rs:25–35`; it exercises producer/schema/input-cancel/corrupt/quota/consumer/replay-cancel/replay-allocation and publication/cleanup (`:45–179`). It does **not** exercise distinct-set membership spill.

Existing actual process-death tests are generic to adjacent spill families. The replay process pair is `streaming_replay_faults_process_child` and `streaming_replay_faults_recovery_preserves_live_and_unknown_owners_then_restarts_exactly` in `shardloom-vortex/src/local_primitive_relational_batch_replay_recovery_tests.rs:24–62+`; it kills a replay owner, rejects cleanup while live/unknown ownership remains, performs guarded cleanup and proves a fresh exact execution. Other process-family selectors found by source search: `ordered_aggregate_recovery_process_child` / `ordered_aggregate_recovery_refuses_live_owner_cleans_dead_runs_and_restarts_exactly`; `streamed_ordering_recovery_process_child` / `streamed_ordering_recovery_refuses_live_owner_then_cleans_abandoned_runs_for_restart`; `streaming_join_recovery_process_child` / `streaming_join_recovery_refuses_live_and_unknown_owners_then_restarts_exactly`; and `streaming_window_recovery_process_child` / `streaming_window_recovery_preserves_live_and_unknown_owners_then_restarts_complete_values`.

**Unknown / acceptance gap:** source search found no set-membership-specific process-child/crash-recovery selector. Current recovery process tests cover other run consumers or source replay. A distinct-set process recovery case cannot be claimed from those selectors alone. Do not mislabel fresh cleanup/restart as interrupted query resume.

## Unaffected refusal selectors and distinctions

These are not the three distinct set variants and remain resident-state refusal scope:

- `streaming_subqueries_resident_membership_denial_is_not_hidden_by_replay_spill` in `shardloom-vortex/src/local_primitive_relational_batch_subquery_pressure_tests.rs:156+` (subquery membership/index state).
- `streaming_dynamic_subqueries_resident_membership_denial_survives_replay_spill_and_recovers` in `shardloom-vortex/src/local_primitive_relational_batch_deferred_pressure_tests.rs:295+` (dynamic subquery membership).
- `set-replay-resident-denied` in `scripts/native_streaming_set_pressure_cases.py:167–179` is replay residency for repeated-source `UNION ALL`, not distinct set membership.
- Unary distinct/dedup/population refusal cases reside in the unary pressure suite; they are not set membership. The broad feature flag `unary_state_spill` remains a separate false field in `scripts/check_user_surface_reference.py:306–313`.

## Capability/documentation rows that encode the old boundary

Explicit stale statements/fields found for review when the capability changes:

- `docs/architecture/native-stream-set-operations-2026-10-15.md:94–100`: says set membership remains resident, has no spill algorithm and calls for denial with/without replay spill. The prior finite contract must stay historically accurate as a dated contract, but current-status references may need a superseding link.
- `docs/benchmarks/native-stream-sets-2026-10-15.md:73–75`: records resident membership and denial under replay-spill permission as historical acceptance.
- `docs/reference/native-query-spill.md:157–161`: combines set membership and unary membership/population as resident. The unary clause remains valid; only the set half is superseded. Also `:402–405` says replay/pivot spill does not make membership/index state spillable; surrounding paragraph is dynamic subquery scope and remains valid for subqueries.
- `docs/reference/resident-native-results.md:88–91`: combines set membership and unary retained state as resident. The unary clause remains valid; only set membership is in scope.
- `docs/reference/shardloom-user-surface-index.json:190–196`: `set_membership_spill: false` for `UNION ALL`, `UNION`, `INTERSECT`, `EXCEPT`; this is the current machine-readable capability row.
- `scripts/check_user_surface_reference.py:310–313`: hard-codes `("set_membership_spill", False)` as the validation expectation for that machine-readable row.
- `scripts/native_streaming_set_cases.py:88–92`: emits fixture metadata literal `"credited resident state; replay spill does not spill set membership"`.
- `scripts/native_streaming_set_pressure_cases.py:78–82`: emits `"set_membership_spill": False` in pressure fixture metadata; this and the three denial case labels/assertions must be distinguished from the `UNION ALL` replay control.
- `docs/architecture/native-roadmap-verification-contracts-2026-10-18.md:85–92`: old refusal selector and instruction to retain explicit denial cases become stale for this boundary.
- `docs/architecture/phased-execution-plan.md:319–325`: PERF-06 status still says resident membership remains and describes unfinished membership implementation; that is phase-level tracked scope, not solely a statement about this one set family. It should not be treated as proof that unary/subquery/population work also closed.
- `docs/architecture/native-stream-dynamic-subqueries-2026-10-15.md:109–111`, `docs/benchmarks/native-stream-dynamic-subqueries-2026-10-16.md:150–153,283–285`, and `docs/architecture/phased-execution-completed-ledger.md:299,356–357` refer to subquery or broad membership scopes. Preserve their distinctions; the subquery/index and unary/population statements are unaffected.

## Search record and limits

Read `AGENTS.md`, then the full active contract `docs/architecture/native-set-membership-spill-2026-10-18.md`. Read-only `rg`/line inspection covered these source roots: `shardloom-vortex/src`, `shardloom-cli/src`, `shardloom-python/src`, `python/tests`, `scripts`, `docs/architecture`, `docs/benchmarks` (excluding bulky `docs/benchmarks/evidence` from broad text search), and `docs/reference`.

Search terms included: `streaming_set_membership_growth_is_denied`; `streaming_set_membership_spill`; `streaming_sets`; `union_distinct`; `INTERSECT`; `EXCEPT`; `set_membership_spill`; `membership state`; `membership/index`; `resident membership`; `set-membership-pressure-denied`; `set-replay-resident-denied`; `NativeSetBindingTests`; `test_native_set_binding`; `LOCAL_FORMATS`; `all eight`; `process_child`; `recovery_process`; `recover`; `sets-pressure`; `--families`; and `--family`.

No exact full modular-matrix command, new set-specific process-death test, or direct-binding module command is evidenced by this read-only source inventory. No runtime behavior, test pass, build result, timing, or acceptance completion is asserted.
