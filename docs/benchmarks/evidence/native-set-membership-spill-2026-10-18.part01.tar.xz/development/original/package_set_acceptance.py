"""Archive set-membership evidence and source; reopen every archived member."""
import hashlib
import json
import lzma
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
NAME = 'native-set-membership-spill-2026-10-18'
DEST = OUT / 'packet-723'
DEST.mkdir(exist_ok=False)

def read(path):
    return json.loads(Path(path).read_text())

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def identity(path):
    path = Path(path)
    return {'file': path.name, 'bytes': path.stat().st_size, 'sha256': digest(path)}

accepted = read(OUT / 'perf-06-acceptance.json')
source = read(OUT / 'acceptance-source.json')
bridge = read(OUT / 'set-closeout-source-bridge.json')
assert accepted['status'] == 'accepted_finite_local_scope'
assert accepted['completed_substeps'] == accepted['broader_owners_closed'] == []
assert read(OUT / 'closeout-checks-723/report.json')['status'] == 'passed'
assert bridge['status'] == 'passed' and bridge['accepted_source_commit'] == source['source_commit']
for name, frozen in source['source_hashes'].items():
    expected = bridge['only_frozen_source_change'].get(name, {}).get('closeout_sha256', frozen)
    assert digest(ROOT / name) == expected, name
for name, expected in bridge['documents'].items():
    assert digest(ROOT / name) == expected, name
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head == source['source_commit']
base = source['base_commit']
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
with (OUT / 'set-implementation.patch').open('xb') as stream:
    stream.write(subprocess.check_output(['git', 'diff', '--binary', base, head], cwd=ROOT))
with (OUT / 'set-closeout-documents.patch').open('xb') as stream:
    stream.write(subprocess.check_output(['git', 'diff', '--binary'], cwd=ROOT))

members, omitted = {}, []
for path in sorted(OUT.rglob('*')):
    if not path.is_file():
        continue
    relative = path.relative_to(OUT)
    if (relative.parts[0] in ('packet-723', '__pycache__') or '__pycache__' in relative.parts
            or relative.as_posix() in ('set-package-723.log', 'set-package-723.json')):
        continue
    assert not path.is_symlink(), path
    bulk = relative.parts[0] == 'artifacts' or relative.parts[:2] == ('public-36', 'outputs')
    if bulk:
        omitted.append({'path': str(relative), **identity(path),
                        'scope': 'native build or generated output retained locally; complete values and regeneration sources archived'})
        continue
    assert path.stat().st_size < 128 << 20, (path, path.stat().st_size)
    members['evidence/' + str(relative)] = path
changed = subprocess.check_output(['git', 'diff', '--name-only', '--diff-filter=ACMR', base, head], cwd=ROOT, text=True).splitlines()
for name in sorted(set(changed) | set(bridge['documents'])):
    path = ROOT / name
    assert path.is_file() and not path.is_symlink()
    members['source/' + name] = path
plan = read(OUT / 'acceptance-plan.json')
support = [
    Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py'),
    Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'),
    Path('/Users/dylan/LocalData/shardloom/native-cpu-20261018/selection-final-source-bridge.json'),
]
support += [Path(ref['path']) for ref in plan['query_harness']]
support += [Path(plan[key]['path']) for key in ('query_source', 'public_runner', 'reference')]
support += [Path(ref['path']) for ref in plan['schema_sources']]
for path in support:
    label = str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else path.name
    name = 'support/' + label
    assert name not in members or digest(members[name]) == digest(path)
    members[name] = path
manifest = [{'name': name, 'bytes': path.stat().st_size, 'sha256': digest(path)}
            for name, path in sorted(members.items())]
raw_bytes = sum(item['bytes'] for item in manifest)
assert raw_bytes < 1 << 30, raw_bytes
archive_path = DEST / (NAME + '.tar.xz')
with tarfile.open(archive_path, 'w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
    for item in manifest:
        info = tarfile.TarInfo(item['name'])
        info.size, info.mode, info.mtime = item['bytes'], 0o644, 0
        with members[item['name']].open('rb') as stream:
            archive.addfile(info, stream)
by_name = {item['name']: item for item in manifest}
verified = []
with tarfile.open(archive_path, 'r:xz') as archive:
    for member in archive:
        assert member.isfile() and member.name in by_name
        expected = by_name[member.name]
        payload = archive.extractfile(member).read()
        assert len(payload) == expected['bytes']
        assert hashlib.sha256(payload).hexdigest() == expected['sha256']
        assert digest(members[member.name]) == expected['sha256']
        verified.append(member.name)
assert len(verified) == len(set(verified)) == len(manifest)
manifest_path = DEST / (NAME + '.manifest.json.xz')
manifest_path.write_bytes(lzma.compress((json.dumps(manifest, indent=2) + '\n').encode()))
assert json.loads(lzma.decompress(manifest_path.read_bytes())) == manifest
assert read(OUT / 'perf-06-acceptance.json') == accepted
index = {
    'schema_version': 'shardloom.native_set_membership_evidence.v1',
    'status': 'accepted_finite_local_scope', 'scope': accepted['scope'],
    'completed_substeps': [], 'broader_owners_closed': [],
    'base_commit': base, 'source_commit': head,
    'acceptance': '../native-set-membership-spill-2026-10-18.md',
    'architecture': '../../architecture/native-set-membership-spill-2026-10-18.md',
    'archive': identity(archive_path), 'manifest': identity(manifest_path),
    'member_count': len(manifest), 'uncompressed_bytes': raw_bytes, 'all_members_reopened': True,
    'owner_acceptance': 'evidence/perf-06-acceptance.json',
    'runtime_acceptance': 'evidence/acceptance-final-verified.json',
    'closeout_source_bridge': 'evidence/set-closeout-source-bridge.json',
    'failed_and_superseded_observations_retained': True,
    'public_cases': accepted['public_cases'], 'new_public_set_cases': 83,
    'new_set_complete_value_archives': 74,
    'full43': accepted['full43'], 'modular_cohorts': 18, 'native_workflows': 704,
    'fresh_independent_pandas_oracle_workflows': 704,
    'platform_scope': accepted['platform_scope'], 'omitted_bulk_artifacts': omitted,
    'external_input': plan['input'], 'claim_gate_status': 'not_claim_grade',
    'performance_claim': False, 'release_version_changed': False, 'publication_attempted': False,
    'limitations': accepted['unresolved'],
    'replay_note': 'Bind recorded local paths to resident inputs and a fresh evidence directory; historical output paths are immutable.',
}
index_path = DEST / (NAME + '.json')
index_path.write_text(json.dumps(index, indent=2) + '\n')
for path in (archive_path, manifest_path, index_path):
    assert path.stat().st_size < 24 << 20
    destination = ROOT / 'docs/benchmarks/evidence' / path.name
    assert not destination.exists()
    shutil.copyfile(path, destination)
    assert digest(path) == digest(destination)
print(json.dumps({'status': 'passed', 'members': len(manifest), 'all_members_reopened': True,
                  'archive_bytes': archive_path.stat().st_size}))

