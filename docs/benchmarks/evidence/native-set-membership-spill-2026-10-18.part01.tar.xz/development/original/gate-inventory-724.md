# Completed set acceptance gates: command and result inventory

All seven requested receipts report `passed`, return code 0, the frozen worktree commit `f5b9231f924b1dac42830131e6ad1535e60b641c`, and an empty working tree. Each receipt's `log_sha256` matches the SHA-256 of its corresponding log on disk. The exact command arrays are in each cited JSON receipt; commands are rendered below in shell form.

| Gate | Command | Result |
|---|---|---|
| `set-workspace-fmt-723` | `cargo fmt --all -- --check` | Passed (exit 0); no test counts apply. Log is empty (0 bytes), and its SHA-256 is the empty-file hash `e3b0c442…b855`. [receipt](set-workspace-fmt-723.json:1-12), [log](set-workspace-fmt-723.log) |
| `set-native-vortex-tests-723` | `cargo test --release --offline --locked -p shardloom-vortex --features release-user-surfaces --lib -- --test-threads=1` | Passed: **2,977 passed, 0 failed, 29 ignored**. [receipt](set-native-vortex-tests-723.json:1-19), [summary](set-native-vortex-tests-723.log:3012) |
| `set-workspace-clippy-723` | `cargo clippy --offline --locked --workspace --all-targets -- -D warnings` | Passed (exit 0); no test counts apply. [receipt](set-workspace-clippy-723.json:1-16), [log](set-workspace-clippy-723.log) |
| `set-workspace-tests-723` | `cargo test --offline --locked --workspace --all-targets -- --test-threads=1` | Passed: **3,235 passed, 0 failed, 0 ignored** across 107 test-result records. [receipt](set-workspace-tests-723.json:1-15), [log results](set-workspace-tests-723.log:3150-6218) |
| `set-native-clippy-723` | `cargo clippy --release --offline --locked -p shardloom-vortex -p shardloom-cli --all-targets --features release-user-surfaces -- -D warnings` | Passed (exit 0); no test counts apply. [receipt](set-native-clippy-723.json:1-23), [log](set-native-clippy-723.log) |
| `set-native-cli-tests-723` | `cargo test --offline --locked -p shardloom-cli --lib --bin shardloom --test vortex_prepare --test public_memory_inputs --test public_workflow_route --test resident_worker --features release-user-surfaces -- --test-threads=1` | Passed: **1,087 passed, 0 failed, 0 ignored** across six test-result records. [receipt](set-native-cli-tests-723.json:1-28), [log results](set-native-cli-tests-723.log:3319-3479) |
| `set-native-family-repair-723` | `cargo test --release --offline --locked -p shardloom-vortex --features release-user-surfaces --lib batch_input_tests::set_tests -- --nocapture --test-threads=1` | Passed: **15 passed, 0 failed, 0 ignored; 2,991 filtered out** by the set-family selector. [receipt](set-native-family-repair-723.json:1-21), [log result](set-native-family-repair-723.log:35) |

The native CLI log also explicitly reports a zero-test `shardloom` main binary (`unittests src/main.rs`, `shardloom-0d27f96fd7df1854`; [log](set-native-cli-tests-723.log:3323-3325)); it is separate from the five nonzero CLI result records and their 1,087-test total. The workspace-wide result is the sum of all 107 `test result` records in its log: 3,235 passed and no failed, ignored, measured, or filtered tests. Eight test binaries explicitly ran zero tests: `shardloom` main, `native_count_payload_write_feature`, `non_unix_resource_admission`, `preparation_resource_profile`, `resident_worker`, `shardloom_contract_tests`, `_native`, and `staged_write_readiness` ([log](set-workspace-tests-723.log:3154-3156), [3599-3616], [3711-3713], [3789-3791], [3982-3984], [5448-5450], [6216-6218]). These zero-test suites are surfaced individually and are not failures; they are distinct from the nonzero workspace total.

## Ignored selectors in the native Vortex library run

The 29 ignored cases below are the complete ignored-name lines reported by that `--lib` run ([log](set-native-vortex-tests-723.log:517-2971)); the text following each selector is Cargo's recorded ignore reason. The descriptions indicate manual, bounded, benchmark/cost, input-dependent, fixture-writing, or explicitly gated work; no further inference about why they were omitted is made here.

1. `local_primitives::bounded_numeric_reduction_experiment::tests::bounded_numeric_measured_scalar_consumers` — manual release-mode bounded-native-consumer feasibility measurement (line 517).
2. `local_primitives::columnar_compat_sink::tests::benchmark::columnar_compatibility_release_lifecycle` — bounded serial native compatibility lifecycle; root owns release timing (534).
3. `local_primitives::compact_string_state::benchmark::paired::compact_string_state_actual_retained_paired_release` — paired release state benchmark; run serially with `--release --ignored --nocapture` (552).
4. `local_primitives::encoded_numeric_reduction::tests::encoded_numeric_reduction_measured_native_scalar_consumers` — manual release-mode scalar-consumer benchmark; emits paired complete-value evidence (626).
5. `local_primitives::native_sink::tests::overlap_screen::complete_native_sink_overlap_screen` — native sink attribution; release, guarded local TMPDIR and serial execution required (779).
6. `local_primitives::numeric_worker_selection_screen::extended_small_numeric_count_selection_screen` — extended-boundary release screen; guarded local root and serial execution required (824).
7. `local_primitives::numeric_worker_selection_screen::held_out_small_numeric_count_selection_screen` — held-out release screen; guarded local root and serial execution required (825).
8. `local_primitives::numeric_worker_selection_screen::paired_small_numeric_count_selection_screen` — bounded public-call selector screen; guarded local root, release and serial execution required (826).
9. `local_primitives::prepared_relational::tests::selection_cost_tests::native_selection_complete_cost_screen` — frozen complete-operation resource/cost screen; use serial guarded release execution (1269).
10. `local_primitives::string_count_partitions::owner_scheduling::benchmark::owner_scheduling_actual_retained_paired_release` — requires isolated release timing; root owns serial benchmark gate (1567).
11. `local_primitives::string_count_partitions::tests::tagged_directory_real_input_work_diagnostic` — requires an explicitly supplied resident Vortex file and exact reference values (1585).
12. `local_primitives::tests::regenerate_checked_in_local_primitive_struct_fixture` — fixture regeneration helper; writes `shardloom-vortex/tests/fixtures/local_primitive_struct_five.vortex` (1837).
13. `local_primitives::weighted_count_spill_query::tests::owner_bench::complete_spill_key_owner_workflows` — bounded spill ownership screen; guarded local TMPDIR, release and serial execution required (1969).
14. `native_provider_memory::builder_tests::cost::native_builder_lifecycle_cost_screen` — native builder lifecycle screen; guarded serial release execution required (2111).
15. `native_provider_memory::builder_tests::decoder_cost::native_decoder_lifecycle_cost_sample` — native decoder lifecycle screen; guarded serial release execution required (2113).
16. `native_provider_memory::zstd_tests::compression_cost_tests::native_zstd_complete_compression_cost_screen` — explicit frozen compression lifecycle cost screen; not a routine unit test (2210).
17. `resident_memory_source::encoded_transfer::tests::varbin_metadata_cost_tests::native_varbin_metadata_complete_lifecycle_cost_screen` — frozen complete buffer-table lifecycle screen; guarded serial release execution only (2407).
18. `resident_session::composition_bench::native_composition_producer_memory_attribution` — bounded R5.a producer memory attribution; requires `SHARDLOOM_R5A_SOURCE` (2463).
19. `resident_session::composition_bench::native_memory_file_composition_baseline` — bounded R5.a native baseline; requires `SHARDLOOM_R5A_SOURCE` and `--release --ignored --exact` (2464).
20. `resident_session::composition_bench::native_owned_array_composition_candidate` — bounded R5.a owned-array candidate; requires `SHARDLOOM_R5A_SOURCE` and `--release --ignored --exact` (2465).
21. `resident_session::concurrent_serving_tests::load_harness::serving_fixed_arrival_load_receipt` — explicit bounded fixed-arrival load run; prints complete JSON receipts (2478).
22. `resident_session::segment_reuse::tests::io_tests::release_bench::scan_segment_reuse_release_lifecycle_pairs` — paired release-mode native query lifecycle experiment; run serially with `--release --ignored --exact` (2535).
23. `resident_session::source_reuse_bench::concurrent_source_reuse_attribution` — bounded release-only concurrent native source attribution screen; run serially with `--release --ignored --exact` (2544).
24. `resident_session::source_reuse_bench::fanout::existing_owned_producer_fanout_pairs` — bounded release-only owned producer fanout screen; run serially with `--release --ignored --exact` (2545).
25. `vortex_ingest::column_layout_tests::benchmark::column_footer_release_lifecycle_and_repeated_native_consumers` — bounded paired release writer lifecycle; root owns serial timings (2818).
26. `vortex_ingest::dictionary_preservation::source_dictionary_bench::clickbench_source_dictionary_admission_screen` — manual bounded R1.b source-dictionary admission screen; requires `SHARDLOOM_R1B_SOURCE` (2833).
27. `vortex_ingest::dictionary_preservation::source_dictionary_bench::fsst_screen::clickbench_fsst_predicate_admission_screen` — manual bounded R6.b FSST admission; requires `SHARDLOOM_R1B_SOURCE` (2834).
28. `vortex_ingest::dictionary_preservation::source_dictionary_bench::zstd_size_screen::clickbench_zstd_size_admission_screen` — manual bounded native text-size screen; requires `SHARDLOOM_R1B_SOURCE` (2835).
29. `vortex_ingest::text_codec_portfolio::text_codec_portfolio_release_reuse_1_10_100` — bounded serial native text lifecycle portfolio; release only, root owns timing (2971).
