"""Verify documentation closeout without changing the accepted runtime source."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
EVIDENCE = Path(__file__).resolve().parent
OUT = EVIDENCE / 'closeout-checks-725'
OUT.mkdir(exist_ok=False)
checks = []

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def run(name, command):
    path = OUT / (name + '.log')
    with path.open('xb') as log:
        result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    checks.append({'name': name, 'command': [str(x) for x in command], 'returncode': result.returncode,
                   'log': str(path), 'log_sha256': digest(path)})
    print(json.dumps({'name': name, 'returncode': result.returncode}), flush=True)
    assert result.returncode == 0, name

try:
    accepted = json.loads((EVIDENCE / 'perf-06-acceptance.json').read_text())
    assert accepted['status'] == 'accepted_finite_local_scope'
    source = json.loads((EVIDENCE / 'acceptance-source.json').read_text())
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    assert head == source['source_commit'] == accepted['source_commit']
    changes = {}
    for name, expected in source['source_hashes'].items():
        actual = digest(ROOT / name)
        if actual != expected:
            assert name == 'scripts/check_user_surface_reference.py', name
            old = subprocess.check_output(['git', 'show', head + ':' + name], cwd=ROOT).decode()
            assert (ROOT / name).read_text() == old.replace(
                '("set_membership_spill_acceptance_status", "local_acceptance_in_progress")',
                '("set_membership_spill_acceptance_status", "locally_accepted_hosted_pending")')
            changes[name] = {'accepted_sha256': expected, 'closeout_sha256': actual,
                             'change': 'acceptance status expectation only'}
    assert set(changes) == {'scripts/check_user_surface_reference.py'}
    plan = (ROOT / 'docs/architecture/phased-execution-plan.md').read_text()
    owners = re.findall(r'^- \[ \] `((?:PERF-\d+|NATIVE-ENCODED-EXCHANGE))`', plan, re.M)
    children = re.findall(r'^    - \[ \] `((?:PERF-\d+|NATIVE-ENCODED-EXCHANGE)\.[^`]+)`(.*)$', plan, re.M)
    conditional = [name for name, text in children if '**Conditional.**' in text]
    assert len(owners) == len(set(owners)) == 14
    assert len(children) == len({name for name, _ in children}) == 58
    assert len(conditional) == 21 and len(children) - len(conditional) == 37
    assert all(name in {child for child, _ in children} for name in
               ('PERF-06.membership', 'PERF-06.recovery', 'PERF-06.strategy'))
    ledger = (ROOT / 'docs/architecture/phased-execution-completed-ledger.md').read_text()
    assert '- [x] `PERF-06 distinct-set membership`' in ledger
    for gate in range(1, 24):
        assert f'CG-{gate}' in plan
    (OUT / 'queue.json').write_text(json.dumps({'status': 'passed', 'owners': owners,
        'children': children, 'remaining': 58, 'required': 37, 'conditional': 21,
        'completed_substeps': [], 'accepted_finite_scope': ['UNION DISTINCT', 'INTERSECT', 'EXCEPT'],
        'cg1_through_cg23_preserved': True}, indent=2) + '\n')
    run('whitespace', ['git', 'diff', '--check'])
    run('docs-regressions', [sys.executable, '-m', 'unittest', 'python.tests.test_release_scripts',
                            'python.tests.test_runtime_gap_family_burn_down',
                            'python.tests.test_compute_engine_completion_gate'])
    run('user-surface', [sys.executable, 'scripts/check_user_surface_reference.py'])
    run('application-reference', [sys.executable, 'scripts/write_public_api_reference.py', '--check'])
    for name, script, flags in (
        ('contribution', 'check_contribution_governance.py', []),
        ('v1-scope', 'check_v1_inclusion_scope.py', []),
        ('runtime-gaps', 'check_runtime_gap_family_burn_down.py', []),
        ('completion-inspection', 'check_compute_engine_completion_gate.py', ['--allow-incomplete']),
        ('architecture-inspection', 'check_release_architecture_tracker.py', ['--allow-blocked']),
        ('public-status', 'check_public_status_docs.py', []),
        ('website-readiness', 'check_website_readiness.py', []),
    ):
        run(name, [sys.executable, 'scripts/' + script, *flags, '--output', OUT / (name + '.json')])
    documents = subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT, text=True).splitlines()
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=ROOT, text=True).splitlines()
    names = sorted(set(documents + untracked))
    assert all(name.startswith(('docs/', 'website/', 'website-src/', 'website-public/')) or name in changes for name in names)
    bridge = {'status': 'passed', 'accepted_source_commit': head,
              'runtime_python_and_harness_sources_unchanged': True,
              'only_frozen_source_change': changes,
              'documents': {name: digest(ROOT / name) for name in names},
              'source_manifest_sha256': digest(EVIDENCE / 'acceptance-source.json'),
              'owner_acceptance_sha256': digest(EVIDENCE / 'perf-06-acceptance.json')}
    with (EVIDENCE / 'set-closeout-source-bridge.json').open('x') as stream:
        json.dump(bridge, stream, indent=2)
        stream.write('\n')
    status = 'passed'
except BaseException:
    status = 'failed'
    raise
finally:
    (OUT / 'report.json').write_text(json.dumps({'status': status, 'checks': checks,
        'completion_and_release_inspection_only': True,
        'claim_gate_status': 'not_claim_grade'}, indent=2) + '\n')

