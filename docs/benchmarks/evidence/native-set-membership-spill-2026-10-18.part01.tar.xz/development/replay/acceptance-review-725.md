# Set membership spill: review and acceptance boundaries

Candidate source: `7a55bc7f`, based on `f5b9231f`, with production baseline
`5829e71c`. Acceptance is pending until the frozen verification driver produces
`perf-06-acceptance.json` with `accepted_finite_local_scope`.

## Review findings and dispositions

1. **Fanout replay could enlarge bounded set batches while the final set reader
   remained live.** The earlier binding acceptance failed its unchanged 16 MiB
   grant for UNION DISTINCT. The repair bounds both fanout producer handoff and
   replay storage blocks to 256 rows. Source replay retains its 1024-row bound.
   The new native regression checks all three set kinds and all eight local
   destinations under the 16 MiB grant, complete ordered values, one execution,
   actual spill, cleanup, retained foreign files and reservation refunds. Its
   development run passed; the complete 16-test family also passed at the clean
   candidate commit. A row bound is not a promise that an arbitrarily wide row
   fits a grant.

2. **Independent file verification was conflated with operator pressure.**
   INTERSECT and EXCEPT fanout writes completed in the earlier binding run, but
   their subsequent file readers were denied. Python `batch_rows=127` slices
   an already admitted native producer batch. This file route uses 2048-row
   native scan ranges and conservative Arrow conversion admission. The direct
   binding test now uses a separate 128 MiB verification client for complete
   Vortex and Parquet readback; the set producer remains at 16 MiB. This does
   not establish small-grant file-reader admission or a whole-process ceiling.

3. **Superseded passing Rust gates cannot override failed Python acceptance.**
   The complete earlier attempt remains in the development evidence directory,
   including its failed 102-test binding run and separate failed readback
   diagnostic. The repaired source is committed and hashed afresh. CLI,
   binding, public workflow, Full43 and format evidence must all match this
   source. No public workflow or Full43 pass from the failed attempt exists.

4. **Finite family proof must not close broader owners.** This work is confined
   to UNION DISTINCT, INTERSECT and EXCEPT. The broader membership/population,
   recovery and strategy substeps remain open. Crash evidence proves exact
   owned cleanup followed by a fresh execution, not continuation of the
   interrupted computation. Existing output targets are rejected before input
   demand; generation-conditional replacement remains separate work.

5. **Complete values and source identity remain acceptance requirements.**
   Public set fixtures retain all 74 checked value archives and reopen them
   against an independent integer-domain oracle, including CSV spellings and
   empty outputs. All 43 query results and all native modular workflows must
   pass their existing reference checks. The retained input is hashed before
   and after query execution. Full43 timing uses the sum of engine execution
   seconds for one call to each query; this packet makes no speed claim.

No runtime fallback, dependency, publication, release version or resource
ceiling change is authorized or introduced by this acceptance procedure.
