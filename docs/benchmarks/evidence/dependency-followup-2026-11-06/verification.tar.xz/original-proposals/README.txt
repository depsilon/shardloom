PRIMARY VERIFICATION — supersedes the original comparison claims below
Seven published archives were independently downloaded, checked against exact
GitHub PR Cargo.lock blobs or the current source lockfile, and matched to the
saved manifests and license/VCS members. See primary-verification-r1.json and
manifest-field-comparison-r2.json. The first comparison read features/dependencies
from the package table and incorrectly compared empty maps; it is rejected and
retained only as an original observation. Real root tables show:
- flate2 changes dependencies, default/runtime-detection features, backend
  feature routing, and target-specific dependency declarations. It removes the
  cloudflare-zlib-sys dependency; the earlier statement that it adds it is wrong.
- tonic increases its optional Hyper requirement from 1 to 1.10.
- tonic-prost increases its tonic requirement from 0.14.6 to 0.14.8 and changes
  its package authors/homepage/repository metadata to the grpc/grpc-rust project.
The first miniz_oxide member scan also omitted three .md-suffixed license files;
the exact Apache, MIT and Zlib files now exist in primary-added-members, bound to
the verified archive. No original observation was removed. Failed-log retrieval
receipts supersede the original 'not downloaded' statement. Compatibility and
notice-bundle acceptance remain primary work, not conclusions of this inventory.

Read-only dependency PR inventory, captured 2026-11-06
Source checkout: /Users/dylan/.codex/worktrees/native-selection-retention/shardloom-local-repo
Verified local HEAD before and after collection: 56902a0f6fece3e53cb42599c478d480e25188dd
Repository state: clean; no fetch or git mutation performed.

Per-PR JSON includes GitHub metadata, full changed-file list, exact patch, PR reviews, inline review comments, issue discussion comments, check-runs and commit statuses. Each requested exact PR head matched. Check runs: #1648 57/57, #1647 57/57, #1646 57/57, #1642 54/54 (GitHub API total_count equals collected count; each response within one 100-item page). Status contexts and check runs both preserved. Review state: no submitted reviews or inline comments for all four; issue-level discussion comment counts #1648=1, #1647=1, #1646=1, #1642=1. These are automation/conversation comments, not approval conclusions.

Registry archives for the three patch PRs were downloaded from static.crates.io and SHA-256 verified against target and previous Cargo.lock checksums. Archive manifests are retained as exact Cargo.toml text; paired archive JSON records URL, SHA-256, lock checksum and archived manifest path. No package code was executed.

Literal package manifest metadata:
- flate2 1.1.9 and 1.1.10: license "MIT OR Apache-2.0"; rust-version "1.67.0". Compare Cargo.toml files for feature/dependency deltas (1.1.10 adds cloudflare-zlib-sys and cloudflare_zlib feature; changes miniz_oxide feature declaration; target lock graph changes miniz_oxide 0.8.9 -> 0.9.1 while retaining 0.8.9 for other consumers).
- tonic 0.14.8 and 0.14.9: license "MIT"; rust-version "1.88". Compare manifests: package dependency/feature declarations appear unchanged; lockfile patch changes tonic package checksum/version only.
- tonic-prost 0.14.6 and 0.14.8: license "MIT"; rust-version "1.88". Compare manifests: package dependency/feature declarations appear unchanged; lockfile patch changes package checksum/version only.

GitHub check inventory contains failing check-run names/URLs and conclusions, but workflow logs were not downloaded in this pass; failure log text is unavailable in the packet. Failure-check URLs are present in the check_runs array of each PR JSON. No compatibility or approval inference is made.

PR #1642 patch remains the source's already-deferred partial Arrow 60 graph; patch retained verbatim for review only. No attempt to solve upgrade.

Focused source-evidence completion (2026-11-06):
- Failed completed GitHub job logs were retrieved with `gh run view <run> --repo depsilon/shardloom --log-failed`. Four complete run log outputs and request receipts are retained: `failed-logs-run-41559692987.txt` (#1648), `failed-logs-run-41592721009.txt` (#1647), `failed-logs-run-41592794987.txt` (#1646), and `failed-logs-run-42077906141.txt` (#1642); `failed-log-receipts.json` records command, status, byte count, run and PR. All requests succeeded. These are full failed-job logs, so they include runner output in addition to failure lines.
- For each of six previous/target crate archives, exact archive members matching license/notice and `.cargo_vcs_info.json` were extracted under `<crate>-<version>-archive-members/`; each archive JSON binds downloaded archive SHA256 to the exact lock checksum and gives member paths, sizes and SHA256s. No NOTICE member exists for some packages; the member inventory records exactly what was present. No package code executed.
- `manifest-field-comparison.json` contains a parsed TOML comparison grouped into identity, features, and dependency fields, each with literal old/new values and an equality result, bound to archive SHA256. For flate2, tonic and tonic-prost, feature maps and dependency declarations compare equal; identity differs due to version (license, Rust version, repository retained in literal identity payload). This is a mechanical comparison, not a compatibility conclusion.
- flate2 PR #1648 adds registry `miniz_oxide 0.9.1` while retaining 0.8.9 for other consumers. Its Cargo.lock checksum is `b63fbc4a50860e98e7b2aa7804ded1db5cbc3aff9193adaff57a6931bf7c4b4c`; matching static.crates.io archive SHA256, manifest, exact license member(s), `.cargo_vcs_info.json`, and member hashes are included as `miniz_oxide-0.9.1-*`.
