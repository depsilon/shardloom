"""Verify frozen PR and archive evidence, then compare complete TOML tables."""
import base64
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
import tomllib
import urllib.request

Q = Path(__file__).resolve().parents[1]
P = Q / 'dependency-pr-inventory-r1'
T = Path('/Users/dylan/.codex/worktrees/native-selection-retention/shardloom-local-repo')
PAIRS = [(1648, 'flate2', '1.1.9', '1.1.10'), (1647, 'tonic', '0.14.8', '0.14.9'),
         (1646, 'tonic-prost', '0.14.6', '0.14.8')]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def api(endpoint):
    return json.loads(subprocess.check_output(['/opt/homebrew/bin/gh', 'api',
        'repos/depsilon/shardloom/' + endpoint], cwd=T, timeout=45))


def packages(lock):
    return {(p['name'], p['version']): p for p in tomllib.loads(lock)['package']}


original_lock = (T / 'Cargo.lock').read_bytes()
original = packages(original_lock.decode())
target_maps, sources, verified, manifests = {}, {}, {}, {}
for number, name, old, new in PAIRS:
    record = read(P / f'pr-{number}.json')
    head = record['expected_head']
    assert record['metadata']['headRefOid'] == head
    live = api(f'pulls/{number}')
    assert live['state'] == 'open' and live['head']['sha'] == head
    response = api(f'contents/Cargo.lock?ref={head}')
    raw = base64.b64decode(response['content'], validate=False)
    assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == response['sha']
    target_maps[number] = packages(raw.decode())
    sources[str(number)] = dict(head=head, observed_base=live['base']['sha'],
        lock_git_blob=response['sha'], lock_sha256=sha(raw))
    assert target_maps[number][name, new]['checksum'] == read(P / f'{name}-{new}-archive.json')['lock_checksum']
    assert original[name, old]['checksum'] == read(P / f'{name}-{old}-archive.json')['lock_checksum']

records = [(name, old, original) for _, name, old, _ in PAIRS]
records += [(name, new, target_maps[number]) for number, name, _, new in PAIRS]
records += [('miniz_oxide', '0.9.1', target_maps[1648])]
for name, version, locked in records:
    key = f'{name}-{version}'
    record = read(P / (key + '-archive.json'))
    url = f'https://static.crates.io/crates/{name}/{key}.crate'
    assert record['url'] == url
    with urllib.request.urlopen(url, timeout=45) as response:
        raw = response.read((4 << 20) + 1)
    assert len(raw) <= 4 << 20
    digest = sha(raw)
    assert digest == locked[name, version]['checksum'] == record['sha256'] == record['lock_checksum']
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        manifest = archive.extractfile(record['manifest_path']).read()
        assert manifest == (P / (key + '-Cargo.toml')).read_bytes()
        parsed = tomllib.loads(manifest.decode())
        assert parsed['package']['name'] == name and parsed['package']['version'] == version
        relevant = [m.name for m in archive.getmembers() if m.isfile() and
            (Path(m.name).name == '.cargo_vcs_info.json' or
             re.search(r'^(?:LICENSE|LICENCE|NOTICE|COPYING|COPYRIGHT|UNLICENSE)', Path(m.name).name, re.I))]
        by_name = {m['archive_member']: m for m in record['members']}
        assert set(by_name) <= set(relevant), (key, set(by_name) - set(relevant))
        missing = set(relevant) - set(by_name)
        if missing:
            assert key == 'miniz_oxide-0.9.1' and missing == {
                key + '/LICENSE-APACHE.md', key + '/LICENSE-MIT.md', key + '/LICENSE-ZLIB.md'}
        members = {}
        for member, row in by_name.items():
            data = archive.extractfile(member).read()
            saved = Path(row['saved_as'])
            assert saved.is_relative_to(P) and data == saved.read_bytes()
            assert sha(data) == row['sha256'] and len(data) == row['bytes']
            members[member] = dict(bytes=len(data), sha256=sha(data))
        for member in sorted(missing):
            data = archive.extractfile(member).read()
            saved = P / 'primary-added-members' / key / Path(member).name
            saved.parent.mkdir(parents=True, exist_ok=True)
            with saved.open('xb') as stream:
                stream.write(data)
            assert saved.read_bytes() == data
            members[member] = dict(bytes=len(data), sha256=sha(data),
                saved_as=str(saved), omitted_from_original_inventory=True)
        vcs = json.loads(archive.extractfile(key + '/.cargo_vcs_info.json').read())
        verified[key] = dict(url=url, archive_sha256=digest, archive_bytes=len(raw),
            manifest_sha256=sha(manifest), package=parsed['package'], vcs=vcs, verified_members=members)
        manifests[key] = parsed

comparison = []
for number, name, old, new in PAIRS:
    before, after = manifests[f'{name}-{old}'], manifests[f'{name}-{new}']
    assert before['dependencies'] and after['dependencies']
    if name != 'tonic-prost':
        assert before['features'] and after['features']
    differences = {key: dict(before=before.get(key), after=after.get(key))
        for key in sorted(set(before) | set(after)) if before.get(key) != after.get(key)}
    assert 'dependencies' in differences
    if name == 'flate2':
        assert 'features' in differences and 'target' in differences
    comparison.append(dict(pr=number, crate=name, before=old, after=new,
        before_archive_sha256=verified[f'{name}-{old}']['archive_sha256'],
        after_archive_sha256=verified[f'{name}-{new}']['archive_sha256'],
        complete_root_tables_compared=True, changed_tables=differences))

out = dict(status='passed', source_checkout=str(T), original_lock_sha256=sha(original_lock),
    pr_sources=sources, archives=verified,
    original_comparison_disposition='rejected: features/dependencies read from the package table, yielding empty maps',
    original_comparison_sha256=sha((P / 'manifest-field-comparison.json').read_bytes()),
    comparison_file='manifest-field-comparison-r2.json', script_sha256=sha(Path(__file__).read_bytes()))
with (P / 'manifest-field-comparison-r2.json').open('x') as stream:
    json.dump(comparison, stream, indent=2)
    stream.write('\n')
out['comparison_sha256'] = sha((P / out['comparison_file']).read_bytes())
with (P / 'primary-verification-r1.json').open('x') as stream:
    json.dump(out, stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(status=out['status'], archives=len(verified),
    changes={row['crate']: list(row['changed_tables']) for row in comparison})))
