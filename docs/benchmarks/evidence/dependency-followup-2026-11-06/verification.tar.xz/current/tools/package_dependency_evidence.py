"""Seal combined dependency acceptance and preserve original failed observations."""
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/dependency-compatibility-batch/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PREVIOUS = Path('/Users/dylan/LocalData/shardloom/managed-binary-2026-11-06')
INVENTORY = PREVIOUS / 'dependency-pr-inventory-r1'
DEST = ROOT / 'docs/benchmarks/evidence/dependency-followup-2026-11-06'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


required = ['format-r1', 'static-docs-r1', 'compressed-text-tests-r1',
    'default-clippy-r1', 'default-tests-r1', 'native-clippy-r1', 'native-tests-r1',
    'feature-matrix-r1', 'msrv-default-r1', 'msrv-native-r1', 'dependency-audit-r1',
    'release-build-r1', 'freeze-runtime-r1', 'installed-wheel-r1', 'python-core-r1']
checks = []
for name in required:
    result = read(OUT / (name + '.json'))
    assert result['status'] == 'passed' and result['returncode'] == 0 and result['process_group_drained'], name
    log = (OUT / (name + '.log')).read_bytes()
    assert sha(log) == result['log_sha256'], name
    item = dict(receipt=name + '.json', status='passed', command=result['command'])
    rows = re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
    if rows:
        item['rust_tests'] = dict(zip(('passed', 'failed', 'ignored'),
            (sum(int(row[i]) for row in rows) for i in range(3))))
        assert item['rust_tests']['failed'] == 0
    checks.append(item)
assert read(OUT / 'validation-sequence-r1.json')['status'] == 'passed'
assert read(OUT / 'core-followup-sequence-r1.json')['status'] == 'passed'
assert read(OUT / 'combined-graph-r1.json')['status'] == 'passed'
assert read(OUT / 'source-replay-primary-r1.json')['status'] == 'passed'
notice = read(OUT / 'notice-update-r1.json')
assert notice['status'] == 'passed'
assert notice['verification'] == dict(status='passed', registry_packages=435,
    vendored_packages=13, license_file_records=833, unique_text_files=250)

installed = read(OUT / 'installed-proof-r1/report.json')
assert installed['status'] == installed['uninstall_status'] == installed['integration']['status'] == 'passed'
assert installed['integration']['tests'] == 319
assert installed['integration']['failures'] == installed['integration']['errors'] == installed['integration']['skipped'] == 0
assert not installed['publication_attempted'] and not installed['performance_claim']
assert installed['integrity']['licenses'] == notice['verification']
for name, key in [('shardloom', 'cli_sha256'), ('lib_native.dylib', 'native_library_sha256')]:
    assert sha((OUT / 'runtime-r1' / name).read_bytes()) == installed['integrity'][key]
wheel = OUT / 'installed-proof-r1/dist' / installed['integrity']['wheel']
assert sha(wheel.read_bytes()) == installed['integrity']['wheel_sha256']

core = read(OUT / 'python-core-r1/core.json')
assert core['status'] == 'passed' and core['error_count'] == core['failure_count'] == 0
core_log = (OUT / 'python-core-r1.log').read_text()
match = re.search(r'Ran (\d+) tests? in [0-9.]+s', core_log)
assert match, 'unittest execution count missing'
python_core = dict(status='passed', discovered_test_cases=core['test_count'],
    reported_test_runs=int(match.group(1)), skip_records=core['skipped_count'],
    failures=core['failure_count'], errors=core['error_count'],
    counting_note='Discovery includes opt-in classes; reported runs and skip records are retained separately, not called a pass count.')

sources = read(OUT / 'combined-graph-r1.json')['build_sources']
for name, expected in sources.items():
    raw = (ROOT / name).read_bytes()
    assert sha(raw) == expected['sha256'] and len(raw) == expected['bytes']
for proof in required:
    result = read(OUT / (proof + '.json'))
    for name, expected in sources.items():
        assert result['changed_source_inventory'][name] == expected, (proof, name)
changed = subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], cwd=ROOT, text=True).splitlines()
assert not any(Path(name).suffix in {'.rs', '.py', '.sh'} for name in changed)

failure_dispositions = {
    'integrate-proposals-r1': 'The original octopus merge stopped on adjacent tonic/tonic-prost manifest lines. The combined pins were resolved explicitly; complete graph verification and final acceptance cover the result.',
}
failures = []
for path in sorted(OUT.glob('*.json')):
    if path.name.startswith('package-evidence-'):
        continue
    result = read(path)
    if isinstance(result, dict) and result.get('status') == 'failed':
        assert path.stem in failure_dispositions, path
        failures.append(dict(receipt=path.name, status='failed', returncode=result.get('returncode'),
            error=result.get('error'), disposition=failure_dispositions[path.stem]))

files = {}
for pattern in ['*.json', '*.log', 'tools/*.py', 'source-blobs/*',
        'archived-source-comparisons/*', 'notice-inventory-r1/**/*',
        'prior-archive-replay-r1/*', 'python-core-r1/*.json',
        'installed-proof-r1/*.json', 'installed-proof-r1/*.log']:
    for path in OUT.glob(pattern):
        if path.is_file() and not path.name.startswith('package-evidence-'):
            files['current/' + path.relative_to(OUT).as_posix()] = path
for path in INVENTORY.rglob('*'):
    if path.is_file():
        files['original-proposals/' + path.relative_to(INVENTORY).as_posix()] = path
for pattern in ['verify-dependency-inventory-r*.json', 'verify-dependency-inventory-r*.log']:
    for path in PREVIOUS.glob(pattern):
        files['original-review/' + path.name] = path
files['original-review/verify_dependency_inventory.py'] = PREVIOUS / 'tools/verify_dependency_inventory.py'
for path in (ROOT / 'python/THIRD_PARTY_LICENSES').rglob('*'):
    if path.is_file():
        files['reviewed-notices/' + path.relative_to(ROOT / 'python/THIRD_PARTY_LICENSES').as_posix()] = path
assert sum(path.stat().st_size for path in files.values()) < 64 << 20
assert not DEST.exists()
DEST.mkdir(parents=True)
manifest = []
archive_path = DEST / 'verification.tar.xz'
with tarfile.open(archive_path, 'w:xz', preset=6) as archive:
    for relative, path in sorted(files.items()):
        assert not path.is_symlink()
        raw = path.read_bytes()
        manifest.append(dict(path=relative, bytes=len(raw), sha256=sha(raw)))
        info = tarfile.TarInfo(relative)
        info.size, info.mode, info.mtime = len(raw), 0o644, 0
        archive.addfile(info, io.BytesIO(raw))
with tarfile.open(archive_path, 'r:xz') as archive:
    assert archive.getnames() == [item['path'] for item in manifest]
    for item in manifest:
        raw = archive.extractfile(item['path']).read()
        assert len(raw) == item['bytes'] and sha(raw) == item['sha256']

report = dict(schema_version='shardloom.compatible_dependency_acceptance.v1',
    status='local_acceptance_passed',
    source_base=read(OUT / 'combined-graph-r1.json')['base'], code_snapshot=sources,
    original_proposal_heads=read(OUT / 'combined-graph-r1.json')['proposal_heads'],
    changed_runtime_source=False, checks=checks, original_local_failures=failures,
    original_hosted_failures=[
        dict(pr=1648, disposition='Generated API identity and package dependency notices were stale; combined acceptance regenerates both.'),
        dict(pr=1647, disposition='Same generated identity/notice drift, plus a provider compilation failure from exhausted hosted disk before tests. Full original logs and the provider artifact digest are retained.'),
        dict(pr=1646, disposition='Generated API identity and package dependency notices were stale; combined acceptance regenerates both.'),
        dict(pr=1642, disposition='Partial Arrow 60 graph remains deferred; incompatible public Arrow type identities require coordinated provider intake, not conversion bridges.')],
    review_corrections=[
        'Initial manifest comparison looked in package sub-tables instead of root feature/dependency tables; corrected complete root-table comparison and independent archive verification supersede it.',
        'Initial miniz license filename scan omitted three Markdown licenses; all four exact legal files are included.',
        'The later header inventory included one ordinary miniz documentation block; primary verification excluded it and retained complete exact legal comments separately from API docs.',
        'GitHub tonic-prost comparison files were truncated; complete published-archive comparisons and offline replay supply accepted source coverage.'],
    dependency_notices=notice['verification'], python_core=python_core,
    installed_package=installed['integration'], installed_wheel_sha256=installed['integrity']['wheel_sha256'],
    native_library_sha256=installed['integrity']['native_library_sha256'],
    cli_sha256=installed['integrity']['cli_sha256'],
    feature_boundary='Compression stays in existing universal format I/O; tonic/tonic-prost remain optional encoded-exchange prerequisites, outside release/default groups. Rejected transport code remains removed.',
    limitations=['Existing opt-in/manual native observations remain ignored; no benchmark or performance claim.',
        'The audit retains paste/anyhow/event-listener informational warnings, with unchanged versions and IDs from the accepted November 2 batch. No remediation or reachability conclusion is claimed.',
        'Local installed-wheel proof is macOS arm64; hosted Linux/Windows and final review remain pending.',
        'The existing Apple linker compact-unwind-size warning remains visible in native test logs.',
        'The partial Arrow major upgrade remains deferred; no package publication is authorized.'],
    publication_attempted=False, performance_claim=False, hosted_integration='pending',
    archive='verification.tar.xz', archive_sha256=sha(archive_path.read_bytes()), members=manifest)
(DEST / 'acceptance.json').write_text(json.dumps(report, indent=2) + '\n')
shutil.copyfile(OUT / 'tools/verify_dependency_packet.py', DEST / 'verify.py')
subprocess.run(['/opt/homebrew/opt/python@3.13/libexec/bin/python3', str(DEST / 'verify.py'),
    '--repo-root', str(ROOT)], check=True, timeout=120)
print(json.dumps(dict(status='local_acceptance_passed', files=len(manifest),
    archive_bytes=archive_path.stat().st_size, installed_package=report['installed_package'],
    python_core=python_core)))
