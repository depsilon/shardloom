"""Bound task-owned build and test processes outside synced storage."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/Users/dylan/.codex/worktrees/dependency-compatibility-batch/shardloom-local-repo')
OUT = Path(__file__).resolve().parent.parent
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
sys.path[:0] = [str(ROOT / 'scripts'), '/Users/dylan/LocalData/shardloom/release-0.3.3-20260930']
from release_validation_guard import WorkloadGuard
from local_uat_storage import GIB, MIB, accounted_bytes, available_bytes, check_budgets, require_local_path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--name', required=True)
parser.add_argument('--timeout', type=float, default=2400)
parser.add_argument('--query-workload', action='store_true',
                    help='Keep full evidence/cache inventories before/after queries; active output and free-space guards remain.')
parser.add_argument('--active-output', type=Path,
                    help='Required with --query-workload: only this active output subtree is inventoried during queries.')
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
assert args.name.replace('-', '').isalnum() and args.timeout > 0
if args.query_workload != (args.active_output is not None):
    parser.error('--query-workload and --active-output must be supplied together')
if args.active_output is not None:
    args.active_output = args.active_output.resolve()
    if args.active_output == OUT or not args.active_output.is_relative_to(OUT):
        parser.error('--active-output must be a strict descendant of this task output directory')
command = args.command[1:] if args.command[:1] == ['--'] else args.command
assert command
for path in (OUT, CACHE):
    require_local_path(path, Path.home(), sys.platform)
helper = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
assert hashlib.sha256(helper.read_bytes()).hexdigest() == '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97'
spec = importlib.util.spec_from_file_location('supervisor', helper)
supervisor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(supervisor)
env = dict(os.environ,
    PATH='/Users/dylan/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/Users/dylan/.cargo/bin:/opt/homebrew/opt/python@3.13/libexec/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
    CARGO_TARGET_DIR=str(CACHE), CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0',
    PYTHONPATH='python/src:scripts', PYTHONDONTWRITEBYTECODE='1', CARGO_TERM_COLOR='never')
metadata = json.loads(subprocess.check_output(['cargo', 'metadata', '--offline', '--locked',
    '--no-deps', '--format-version', '1'], cwd=ROOT, env=env))
assert metadata['target_directory'] == str(CACHE)
workload = WorkloadGuard()
workload.check()
changed = set()
for argv in (['git', 'diff', '--name-only', '-z', 'HEAD'],
             ['git', 'ls-files', '--others', '--exclude-standard', '-z']):
    changed.update(path for path in subprocess.check_output(argv, cwd=ROOT).decode().split('\0') if path)
source_inventory = {}
for relative in sorted(changed):
    path = ROOT / relative
    if path.is_symlink():
        source_inventory[relative] = {'symlink': os.readlink(path)}
    elif path.is_file():
        source_inventory[relative] = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                                      'bytes': path.stat().st_size}
        snapshot = OUT / 'source-blobs' / source_inventory[relative]['sha256']
        snapshot.parent.mkdir(exist_ok=True)
        if not snapshot.exists():
            shutil.copyfile(path, snapshot)
        assert hashlib.sha256(snapshot.read_bytes()).hexdigest() == source_inventory[relative]['sha256']
    else:
        source_inventory[relative] = {'absent': True}
record = {'status': 'running', 'command': command, 'cwd': str(ROOT),
    'query_workload': args.query_workload,
    'build_inventory_policy': 'before_and_after_only' if args.query_workload else 'periodic',
    'evidence_inventory_policy': 'before_and_after_only' if args.query_workload else 'periodic',
    'active_output': str(args.active_output) if args.active_output else None,
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'working_tree': subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True),
    'changed_source_inventory': source_inventory,
    'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'environment': {key: env.get(key) for key in ('CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL', 'CLIPPY_CONF_DIR', 'SHARDLOOM_PIP_AUDIT_PYTHON')},
    'supervisor_sha256': hashlib.sha256(helper.read_bytes()).hexdigest()}
driver_snapshot = OUT / 'source-blobs' / record['driver_sha256']
if not driver_snapshot.exists():
    shutil.copyfile(Path(__file__), driver_snapshot)
receipt = OUT / f'{args.name}.json'
assert not receipt.exists()
log = OUT / f'{args.name}.log'
last_storage = None

def guard(force_build=False):
    global last_storage
    workload.check(record.get('pid'))
    assert available_bytes(CACHE) >= 12 * GIB, 'minimum free storage reached'
    if not force_build and last_storage is not None and time.monotonic() - last_storage < 30:
        return
    observations = {}
    paths = (('output', OUT), ('cargo', CACHE))
    if args.query_workload and record.get('pid') and not force_build:
        paths = (('active_output', args.active_output),)
    for label, path in paths:
        budget = record['active_output_workspace_budget_bytes'] if label == 'active_output' else 100 * GIB
        observations[label] = check_budgets(path, path / 'reserved-artifact', path / 'logs',
            min_free_bytes=12 * GIB, reserve_bytes=128 * MIB,
            max_workspace_bytes=budget, max_log_bytes=192 * MIB)
    if args.query_workload and not record.get('pid'):
        # The inactive evidence tree is fixed while the isolated query job runs.
        # Subtract it once so narrowing the active scan never raises the total cap.
        inactive = observations['output']['workspace_bytes'] - accounted_bytes(args.active_output)
        assert inactive >= 0
        record['inactive_output_bytes'] = inactive
        record['active_output_workspace_budget_bytes'] = 100 * GIB - inactive
    record['storage_last_observation'] = observations
    record.setdefault('storage_inventory_scopes', []).append(dict(
        scopes=list(observations), child_started=bool(record.get('pid')), forced=force_build))
    last_storage = time.monotonic()

try:
    guard()
    with log.open('xb') as stream:
        code = supervisor.run(command, cwd=ROOT, env=env, output=stream,
            timeout=args.timeout, evidence=record, guard=guard, max_output_bytes=8 << 20)
    record['status'] = 'passed' if code == 0 else 'failed'
    guard(force_build=True)
except BaseException as error:
    record.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    if log.exists():
        record['log_sha256'] = hashlib.sha256(log.read_bytes()).hexdigest()
    receipt.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({key: record.get(key) for key in ('status', 'returncode', 'seconds', 'process_group_drained', 'error')}), flush=True)
    print(str(receipt), flush=True)
raise SystemExit(code)
