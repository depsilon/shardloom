"""Verify the exact combined proposal graph and unchanged engine sources."""
import hashlib
import json
from pathlib import Path
import subprocess
import tomllib

ROOT = Path('/Users/dylan/.codex/worktrees/dependency-compatibility-batch/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
EXPECTED = {'1648': '88a5e1bd9bee8820b15cd751b780367513782e5d',
            '1647': 'add444ff4ef41b467b935191673318a833af499c',
            '1646': '7b6c5cc3d737adce3a0bff9d5bf9f1fbe0ccbd49'}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


head = git('rev-parse', 'HEAD').decode().strip()
assert head == '56902a0f6fece3e53cb42599c478d480e25188dd'
for pr, expected in EXPECTED.items():
    assert git('rev-parse', 'refs/remotes/origin/review-pr' + pr).decode().strip() == expected
merge_path = Path(git('rev-parse', '--git-path', 'MERGE_HEAD').decode().strip())
assert merge_path.read_text().splitlines() == list(EXPECTED.values())
assert not git('ls-files', '--unmerged')
original = tomllib.loads(git('show', 'HEAD:Cargo.lock').decode())
current = tomllib.loads((ROOT / 'Cargo.lock').read_text())


def packages(lock):
    return {(p['name'], p['version'], p.get('source')): p for p in lock['package']}


before, after = packages(original), packages(current)
added, removed = set(after) - set(before), set(before) - set(after)
assert {(key[0], key[1]) for key in added} == {
    ('flate2', '1.1.10'), ('miniz_oxide', '0.9.1'), ('tonic', '0.14.9'), ('tonic-prost', '0.14.8')}
assert {(key[0], key[1]) for key in removed} == {
    ('flate2', '1.1.9'), ('tonic', '0.14.8'), ('tonic-prost', '0.14.6')}
changed_existing = []
for key in sorted(set(before) & set(after)):
    old, new = before[key], after[key]
    if old == new:
        continue
    assert key[0] in {'arrow-avro', 'orc-rust', 'miniz_oxide'}, key
    assert {k: v for k, v in old.items() if k != 'dependencies'} == {
        k: v for k, v in new.items() if k != 'dependencies'}
    a, b = set(old['dependencies']), set(new['dependencies'])
    if key[0] == 'miniz_oxide':
        assert key[1] == '0.8.9' and a - b == {'simd-adler32'} and not b - a
    else:
        assert a - b == {'miniz_oxide'} and b - a == {'miniz_oxide 0.8.9'}
    changed_existing.append({'package': list(key), 'removed_dependencies': sorted(a - b),
                             'added_dependencies': sorted(b - a)})
changed = git('diff', '--name-only', 'HEAD').decode().splitlines()
assert not any(Path(p).suffix in {'.rs', '.py', '.sh'} for p in changed), changed
build_sources = {}
for relative in ('Cargo.lock', 'Cargo.toml', 'shardloom-vortex/Cargo.toml'):
    raw = (ROOT / relative).read_bytes()
    build_sources[relative] = {'sha256': sha(raw), 'bytes': len(raw)}
report = {'status': 'passed', 'base': head, 'proposal_heads': EXPECTED,
    'all_original_heads_retained_in_pending_merge': True,
    'engine_source_changed': False, 'build_sources': build_sources,
    'added_locked_packages': [after[k] for k in sorted(added)],
    'removed_locked_packages': [before[k] for k in sorted(removed)],
    'changed_existing_package_edges': changed_existing,
    'conflict_resolution': 'Keep tonic 0.14.9 and tonic-prost 0.14.8 in the adjacent workspace dependency lines.',
    'original_failed_merge_receipt': 'integrate-proposals-r1.json'}
path = OUT / 'combined-graph-r1.json'
assert not path.exists()
path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': 'passed', 'added': len(added), 'removed': len(removed),
    'changed_existing_edges': len(changed_existing), 'engine_source_changed': False}))
