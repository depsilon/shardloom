"""Run the public Python shard after the sequential native checks finish."""
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/Users/dylan/.codex/worktrees/dependency-compatibility-batch/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PYTHON = '/opt/homebrew/opt/python@3.13/libexec/bin/python3'
TEST_PYTHON = '/Users/dylan/LocalData/shardloom/managed-binary-2026-11-06/test-env/bin/python'
receipt = OUT / 'core-followup-sequence-r1.json'
assert not receipt.exists()
state = {'status': 'waiting', 'dependency': 'validation-sequence-r1.json',
         'retained_environment': TEST_PYTHON}

def save():
    receipt.write_text(json.dumps(state, indent=2) + '\n')

try:
    save()
    deadline = time.monotonic() + 3 * 3600
    while True:
        prior = json.loads((OUT / state['dependency']).read_text())
        if prior['status'] != 'running':
            assert prior['status'] == 'passed', prior
            break
        assert time.monotonic() < deadline, 'native validation wait deadline reached'
        time.sleep(5)
    state.update(status='running', active_stage='python-core-r1')
    save()
    subprocess.run([PYTHON, str(OUT / 'tools/guard_dependency_followup.py'), '--name',
        'python-core-r1', '--timeout', '1200', '--', TEST_PYTHON, '-B',
        'scripts/run_python_test_shard.py', '--shard', 'core', '--output-dir',
        str(OUT / 'python-core-r1')], cwd=ROOT, check=True)
    result = json.loads((OUT / 'python-core-r1.json').read_text())
    assert result['status'] == 'passed' and result['process_group_drained']
    state.update(status='passed', active_stage=None)
except BaseException as error:
    state.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    save()
    print(json.dumps(state), flush=True)
