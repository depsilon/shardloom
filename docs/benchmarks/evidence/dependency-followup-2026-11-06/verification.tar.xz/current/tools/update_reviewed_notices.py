"""Bind the complete notice bundle to four checksum-verified package archives."""
import base64
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import tomllib

ROOT = Path('/Users/dylan/.codex/worktrees/dependency-compatibility-batch/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
INPUT = OUT / 'notice-inventory-r1'
PRIOR = Path('/Users/dylan/LocalData/shardloom/managed-binary-2026-11-06/dependency-pr-inventory-r1')
BUNDLE = ROOT / 'python/THIRD_PARTY_LICENSES'
RECEIPT = OUT / 'notice-update-r1.json'
assert not RECEIPT.exists()
sys.path.insert(0, str(ROOT / 'scripts'))
from check_python_license_bundle import identity, verify


def sha(data):
    return hashlib.sha256(data).hexdigest()


def package_map(raw):
    return {identity(p): p for p in tomllib.loads(raw)['package']
            if p.get('source', '').startswith('registry+')}


original_lock = subprocess.check_output(['git', 'show', 'HEAD:Cargo.lock'], cwd=ROOT)
before = package_map(original_lock.decode())
after = package_map((ROOT / 'Cargo.lock').read_text())
old_bytes = subprocess.check_output(['git', 'show', 'HEAD:python/THIRD_PARTY_LICENSES/manifest.json'], cwd=ROOT)
assert (BUNDLE / 'manifest.json').read_bytes() == old_bytes
old = json.loads(old_bytes)
components = {identity(p): p for p in old['components']}
assert set(components) == set(before)
added = set(after) - set(before)
removed = set(before) - set(after)
assert {(p[0], p[1]) for p in added} == {
    ('flate2', '1.1.10'), ('miniz_oxide', '0.9.1'), ('tonic', '0.14.9'), ('tonic-prost', '0.14.8')}
assert {(p[0], p[1]) for p in removed} == {
    ('flate2', '1.1.9'), ('tonic', '0.14.8'), ('tonic-prost', '0.14.6')}
for key in set(before) & set(after):
    assert before[key]['checksum'] == after[key]['checksum']
old_texts = {}
for component in old['components'] + old['vendored_components']:
    for item in component['files']:
        path = BUNDLE / item['text']
        assert path.is_file() and not path.is_symlink()
        raw = path.read_bytes()
        assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
        old_texts[item['text']] = raw
assert {str(p.relative_to(BUNDLE)) for p in (BUNDLE / 'texts').iterdir()} == set(old_texts)

verified = json.loads((PRIOR / 'primary-verification-r1.json').read_text())
leaf = json.loads((INPUT / 'inventory.json').read_text())
files_by_package, package_metadata, archive_receipts = {}, {}, []
legal_occurrences, raw_sources = set(), {}
for key in sorted(added):
    name, version, _ = key
    label = f'{name}-{version}'
    source = verified['archives'][label]
    archive_raw = (INPUT / (label + '.crate')).read_bytes()
    assert sha(archive_raw) == source['archive_sha256'] == after[key]['checksum']
    assert len(archive_raw) == source['archive_bytes'] <= 4 << 20
    with tarfile.open(fileobj=io.BytesIO(archive_raw), mode='r:gz') as archive:
        members = {m.name.removeprefix(label + '/'): archive.extractfile(m).read()
                   for m in archive.getmembers() if m.isfile() and m.name.startswith(label + '/')}
    manifest = tomllib.loads(members['Cargo.toml'].decode())['package']
    vcs = json.loads(members['.cargo_vcs_info.json'])
    assert (manifest['name'], manifest['version']) == (name, version)
    assert manifest == source['package'] and vcs == source['vcs']
    package_metadata[key] = (manifest, vcs)
    raw_sources[label] = members
    files_by_package[key] = []
    legal = []
    for path, raw in sorted(members.items()):
        if re.match(r'^(LICENSE|LICENCE|COPYING|NOTICE|UNLICENSE)(?:$|[._-])', Path(path).name, re.I):
            legal_occurrences.add((label, label + '/' + path))
            legal.append(path)
            files_by_package[key].append((raw, {'crate_path': path}))
    archive_receipts.append(dict(package=label, archive_sha256=sha(archive_raw),
        archive_bytes=len(archive_raw), members=len(members), legal_members=legal,
        manifest_sha256=sha(members['Cargo.toml']), vcs=vcs))

# Independently verify every worker text and occurrence against archive bytes.
reported_legal = set()
for item in leaf['unique_license_texts']:
    raw = Path(item['text_file']).read_bytes()
    assert sha(raw) == item['sha256'] and len(raw) == item['bytes']
    for occurrence in item['occurrences']:
        label = occurrence['crate']
        member = occurrence['member_path']
        assert raw_sources[label][member.removeprefix(label + '/')] == raw
        assert occurrence['raw_sha256'] == sha(raw) and occurrence['raw_bytes'] == len(raw)
        reported_legal.add((label, member))
assert reported_legal == legal_occurrences
false_positive_headers = []
reported_source_headers = set()
for item in leaf['unique_source_header_texts']:
    raw = Path(item['text_file']).read_bytes()
    assert sha(raw) == item['sha256'] and len(raw) == item['bytes']
    for occurrence in item['occurrences']:
        label = occurrence['crate']
        member = occurrence['member_path'].removeprefix(label + '/')
        original = raw_sources[label][member]
        assert sha(original) == occurrence['source_member_sha256']
        assert len(original) == occurrence['source_member_bytes']
        start, end = occurrence['header_start_offset'], occurrence['header_end_offset_exclusive']
        assert original[start:end] == raw
        if not re.search(rb'copyright|permission is hereby granted|licen[cs]e', raw, re.I):
            false_positive_headers.append(dict(package=label, member=member,
                reason='ordinary documentation; contains no copyright or license text'))
        else:
            reported_source_headers.add((label, member))

# Use exact complete legal comments, excluding adjacent API documentation.
headers = {}
header_occurrences = []
for key in sorted(added):
    name, version, _ = key
    label = f'{name}-{version}'
    metadata, vcs = package_metadata[key]
    for member, raw in sorted(raw_sources[label].items()):
        if not member.endswith('.rs') or not re.search(rb'copyright|permission is hereby granted', raw, re.I):
            continue
        if raw.startswith(b'/*'):
            end = raw.index(b'*/') + 2
            if raw[end:end + 1] == b'\n':
                end += 1
            header = raw[:end]
        else:
            assert label.startswith('flate2-') and member == 'src/bufreader.rs'
            end = raw.index(b'\n\n') + 1
            header = raw[:end]
        assert re.search(rb'copyright', header, re.I)
        assert not re.search(rb'copyright|permission is hereby granted', raw[end:], re.I)
        if member.startswith('src/'):
            assert (label, member) in reported_source_headers
        revision = vcs['git']['sha1']
        relative = '/'.join(filter(None, [vcs.get('path_in_vcs'), member]))
        url = metadata['repository'].removesuffix('.git') + '/blob/' + revision + '/' + relative
        h = sha(header)
        header_occurrences.append(dict(package=label, member=member, source_sha256=sha(raw),
            offset_start=0, offset_end=end, header_sha256=h, upstream_url=url))
        if (key, h) not in headers:
            headers[(key, h)] = header
            files_by_package[key].append((header, {'upstream_url': url}))
assert len(false_positive_headers) == 1 and false_positive_headers[0]['package'] == 'miniz_oxide-0.9.1'

pinned = json.loads((OUT / 'tonic-prost-root-license-response.json').read_text())
root_license = base64.b64decode(pinned['content'])
assert hashlib.sha1(b'blob ' + str(len(root_license)).encode() + b'\0' + root_license).hexdigest() == pinned['sha'] == '10524c35a11a420af046e50d1d2316eac49e08cc'
prost_key = next(k for k in added if k[0] == 'tonic-prost')
assert package_metadata[prost_key][1]['git']['sha1'] == '541379959bf197057a7c04eeca7f1d976f5ba7c6'
assert pinned['display_url'] == 'https://github.com/grpc/grpc-rust/blob/541379959bf197057a7c04eeca7f1d976f5ba7c6/LICENSE'
files_by_package[prost_key].append((root_license, {'upstream_url': pinned['display_url']}))

next_components = [p for key, p in components.items() if key not in removed]
texts = dict(old_texts)
for key in sorted(added):
    metadata, _ = package_metadata[key]
    records = []
    for raw, provenance in files_by_package[key]:
        raw.decode('utf-8')
        h = sha(raw)
        path = f'texts/{h}.txt'
        texts[path] = raw
        records.append(dict(text=path, sha256=h, bytes=len(raw), **provenance))
    assert records and metadata['license'] in {'MIT', 'MIT OR Apache-2.0', 'MIT OR Zlib OR Apache-2.0'}
    next_components.append(dict(name=key[0], version=key[1], source=key[2],
        license=metadata['license'], repository=metadata['repository'], crate_checksum_sha256=after[key]['checksum'],
        files=sorted(records, key=lambda r: (r['text'], json.dumps(r, sort_keys=True)))))
next_manifest = dict(old, components=sorted(next_components, key=identity))
referenced = {r['text'] for c in next_manifest['components'] + next_manifest['vendored_components'] for r in c['files']}
retired = sorted(set(old_texts) - referenced)
for relative in sorted(referenced):
    path = BUNDLE / relative
    if path.exists():
        assert path.read_bytes() == texts[relative]
    else:
        path.write_bytes(texts[relative])
for relative in retired:
    path = BUNDLE / relative
    assert not path.is_symlink() and path.read_bytes() == old_texts[relative]
    path.unlink()
(BUNDLE / 'manifest.json').write_text(json.dumps(next_manifest, indent=2, ensure_ascii=False) + '\n')
assert {identity(p): p for p in next_manifest['components'] if identity(p) not in added} == {
    k: p for k, p in components.items() if k not in removed}
report = dict(status='passed', verification=verify(ROOT),
    original_lock_sha256=sha(original_lock), combined_lock_sha256=sha((ROOT / 'Cargo.lock').read_bytes()),
    original_manifest_sha256=sha(old_bytes), final_manifest_sha256=sha((BUNDLE / 'manifest.json').read_bytes()),
    archives=archive_receipts, source_header_occurrences=header_occurrences,
    discarded_worker_false_positive_headers=false_positive_headers,
    root_license=dict(upstream_url=pinned['display_url'], git_blob=pinned['sha'], sha256=sha(root_license), bytes=len(root_license)),
    unchanged_components_preserved_exactly=len(components) - len(removed),
    removed_components=sorted(removed), added_components=sorted(added), retired_unreferenced_texts=retired)
RECEIPT.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report['verification']))
