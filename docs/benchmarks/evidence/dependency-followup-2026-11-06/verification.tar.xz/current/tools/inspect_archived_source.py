"""Compare exact published package sources without executing dependency code."""
import difflib
import hashlib
import io
import json
from pathlib import Path
import tarfile
import urllib.request

OUT = Path(__file__).resolve().parents[1]
INVENTORY = Path('/Users/dylan/LocalData/shardloom/managed-binary-2026-11-06/dependency-pr-inventory-r1')
verified = json.loads((INVENTORY / 'primary-verification-r1.json').read_bytes())
assert verified['status'] == 'passed'
target = OUT / 'archived-source-comparisons'
target.mkdir()


def snapshot(name, version):
    key = f'{name}-{version}'
    evidence = verified['archives'][key]
    with urllib.request.urlopen(evidence['url'], timeout=45) as response:
        raw = response.read((4 << 20) + 1)
    assert len(raw) <= 4 << 20
    assert hashlib.sha256(raw).hexdigest() == evidence['archive_sha256']
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        files = {m.name.removeprefix(key + '/'): archive.extractfile(m).read()
            for m in archive.getmembers() if m.isfile() and m.name.startswith(key + '/')}
    return files


summary = []
for name, old, new in [('flate2', '1.1.9', '1.1.10'), ('tonic', '0.14.8', '0.14.9'),
                       ('tonic-prost', '0.14.6', '0.14.8')]:
    before, after = snapshot(name, old), snapshot(name, new)
    changes = []
    for path in sorted(set(before) | set(after)):
        a, b = before.get(path), after.get(path)
        if a == b:
            continue
        row = dict(path=path, before_sha256=hashlib.sha256(a).hexdigest() if a is not None else None,
            after_sha256=hashlib.sha256(b).hexdigest() if b is not None else None)
        if path.startswith('src/') and path.endswith('.rs'):
            row['diff'] = ''.join(difflib.unified_diff((a or b'').decode().splitlines(True),
                (b or b'').decode().splitlines(True), fromfile=old + '/' + path, tofile=new + '/' + path))
        changes.append(row)
    report = dict(crate=name, before=old, after=new,
        before_archive_sha256=verified['archives'][f'{name}-{old}']['archive_sha256'],
        after_archive_sha256=verified['archives'][f'{name}-{new}']['archive_sha256'],
        complete_archive_members_compared=True, changed_files=changes)
    with (target / (name + '.json')).open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    summary.append(dict(crate=name, files=len(changes), production_rust=[r['path'] for r in changes if 'diff' in r]))
print(json.dumps(summary))
