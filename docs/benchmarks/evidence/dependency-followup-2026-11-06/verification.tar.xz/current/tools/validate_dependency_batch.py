"""Validate the combined dependency graph through isolated, bounded stages."""
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/dependency-compatibility-batch/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PYTHON = '/opt/homebrew/opt/python@3.13/libexec/bin/python3'
GUARD = OUT / 'tools/guard_dependency_followup.py'
ENV = ['env', 'CARGO_PROFILE_DEV_DEBUG=0', 'CARGO_PROFILE_TEST_DEBUG=0', 'PYO3_PYTHON=' + PYTHON]
FEATURES = 'shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment'
BUILD_PYTHON = '/Users/dylan/LocalData/shardloom/item20-completion-2026-10-28/wheel-build-tools/bin/python'
WHEELHOUSE = '/Users/dylan/LocalData/shardloom/item20-completion-2026-10-28/installed-proof-wheelhouse'
AUDIT_PYTHON = '/Users/dylan/LocalData/shardloom/direct-source-count-2026-10-31/dependency-audit-tools/bin/python'
stages = [
    ('format-r1', 120, ['cargo', 'fmt', '--all', '--', '--check']),
    ('static-docs-r1', 300, [PYTHON, str(OUT / 'tools/check_dependency_docs.py')]),
    ('compressed-text-tests-r1', 2400, ENV + ['cargo', 'test', '-p', 'shardloom-vortex', '--features', 'native-binary-objects', '--lib', 'universal_format_io::text_stream::tests', '--locked', '--offline']),
    ('default-clippy-r1', 2400, ENV + ['cargo', 'clippy', '--workspace', '--all-targets', '--locked', '--offline', '--', '-D', 'warnings']),
    ('default-tests-r1', 3600, ENV + ['cargo', 'test', '--workspace', '--all-targets', '--locked', '--offline']),
    ('native-clippy-r1', 3600, ENV + ['cargo', 'clippy', '--workspace', '--all-targets', '--features', FEATURES, '--locked', '--offline', '--', '-D', 'warnings']),
    ('native-tests-r1', 5400, ENV + ['cargo', 'test', '--workspace', '--all-targets', '--features', FEATURES, '--locked', '--offline']),
    ('feature-matrix-r1', 3600, ENV + [PYTHON, str(OUT / 'tools/check_dependency_feature_matrix.py')]),
    ('msrv-default-r1', 2400, ENV + ['rustup', 'run', '1.96.0', 'cargo', 'check', '--workspace', '--no-default-features', '--locked', '--offline']),
    ('msrv-native-r1', 3600, ENV + ['rustup', 'run', '1.96.0', 'cargo', 'check', '--workspace', '--all-targets', '--features', 'release-user-surfaces', '--locked', '--offline']),
    ('dependency-audit-r1', 900, ENV + ['env', 'SHARDLOOM_PIP_AUDIT_PYTHON=' + AUDIT_PYTHON, PYTHON, 'scripts/check_dependency_audit.py', '--release-gate', '--json-output', str(OUT / 'dependency-audit-report-r1.json')]),
    ('release-build-r1', 5400, ENV + ['cargo', 'build', '--locked', '--offline', '--release', '--features', 'release-user-surfaces', '-p', 'shardloom-cli', '-p', 'shardloom-python']),
    ('freeze-runtime-r1', 600, [PYTHON, str(OUT / 'tools/freeze_dependency_runtime.py')]),
    ('installed-wheel-r1', 2400, [BUILD_PYTHON, '-B', 'scripts/prove_native_python_wheel.py', '--output-dir', str(OUT / 'installed-proof-r1'), '--native-library', str(OUT / 'runtime-r1/lib_native.dylib'), '--cli-binary', str(OUT / 'runtime-r1/shardloom'), '--wheelhouse', WHEELHOUSE]),
]
receipt = OUT / 'validation-sequence-r1.json'
assert not receipt.exists()
for executable in (PYTHON, BUILD_PYTHON, AUDIT_PYTHON):
    assert Path(executable).is_file(), executable
state = {'status': 'running', 'completed': [], 'active_stage': None}

def save():
    receipt.write_text(json.dumps(state, indent=2) + '\n')

try:
    for name, timeout, command in stages:
        state['active_stage'] = name
        save()
        print('Starting ' + name, flush=True)
        result = subprocess.run([PYTHON, str(GUARD), '--name', name, '--timeout', str(timeout), '--', *command], cwd=ROOT, check=False)
        stage = json.loads((OUT / (name + '.json')).read_text())
        assert result.returncode == 0 and stage['status'] == 'passed' and stage['process_group_drained'], name
        state['completed'].append(name)
        save()
    state.update(status='passed', active_stage=None)
except BaseException as error:
    state.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    save()
