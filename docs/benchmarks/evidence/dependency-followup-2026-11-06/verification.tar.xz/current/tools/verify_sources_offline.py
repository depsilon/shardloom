"""Verify complete published-source comparisons from saved archives, offline."""
import difflib
import hashlib
import io
import json
from pathlib import Path
import tarfile

OUT = Path(__file__).resolve().parents[1]
PRIOR = Path('/Users/dylan/LocalData/shardloom/managed-binary-2026-11-06/dependency-pr-inventory-r1')
inventory = json.loads((PRIOR / 'primary-verification-r1.json').read_bytes())
assert inventory['status'] == 'passed'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def snapshot(name, version):
    key = f'{name}-{version}'
    recorded = inventory['archives'][key]
    raw = (OUT / 'prior-archive-replay-r1' / (key + '.crate')).read_bytes()
    assert sha(raw) == recorded['archive_sha256']
    assert len(raw) == recorded['archive_bytes'] <= 4 << 20
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        members = [m for m in archive.getmembers() if m.isfile()]
        assert all(m.name.startswith(key + '/') for m in members)
        assert len({m.name for m in members}) == len(members)
        data = {m.name.removeprefix(key + '/'): archive.extractfile(m).read() for m in members}
    return raw, data

reports = []
for name, before_version, after_version in [('flate2', '1.1.9', '1.1.10'),
        ('tonic', '0.14.8', '0.14.9'), ('tonic-prost', '0.14.6', '0.14.8')]:
    before_raw, before = snapshot(name, before_version)
    after_raw, after = snapshot(name, after_version)
    changes = []
    for path in sorted(set(before) | set(after)):
        a, b = before.get(path), after.get(path)
        if a == b:
            continue
        row = dict(path=path, before_sha256=sha(a) if a is not None else None,
                   after_sha256=sha(b) if b is not None else None)
        if path.startswith('src/') and path.endswith('.rs'):
            row['diff'] = ''.join(difflib.unified_diff(
                (a or b'').decode().splitlines(True), (b or b'').decode().splitlines(True),
                fromfile=before_version + '/' + path, tofile=after_version + '/' + path))
        changes.append(row)
    expected = json.loads((OUT / 'archived-source-comparisons' / (name + '.json')).read_bytes())
    report = dict(crate=name, before=before_version, after=after_version,
        before_archive_sha256=sha(before_raw), after_archive_sha256=sha(after_raw),
        complete_archive_members_compared=True, changed_files=changes)
    assert report == expected, name
    reports.append(dict(crate=name, before_members=len(before), after_members=len(after),
        changed_files=len(changes), rust_diffs=sum('diff' in row for row in changes),
        before_archive_sha256=sha(before_raw), after_archive_sha256=sha(after_raw)))
result = dict(status='passed', offline=True, all_fields_exact=True, crates=reports)
destination = OUT / 'source-replay-primary-r1.json'
assert not destination.exists()
destination.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
