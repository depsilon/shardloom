"""Bind reviewed dependency evidence to one clean, ancestry-preserving commit."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/dependency-compatibility-batch/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
PACKET = ROOT / 'docs/benchmarks/evidence/dependency-followup-2026-11-06'
BASE = '56902a0f6fece3e53cb42599c478d480e25188dd'
OLD_MAIN = 'a8d35b6257775f07e1bb3649cacfe3f3382842dc'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True, timeout=90).strip()


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    return dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())


assert not git('status', '--porcelain')
assert git('branch', '--show-current') == 'codex/native-dependency-followup'
head = git('rev-parse', 'HEAD')
report = read(PACKET / 'acceptance.json')
assert report['status'] == 'local_acceptance_passed' and report['source_base'] == BASE
parents = git('show', '-s', '--format=%P', head).split()
assert parents[0] == BASE and len(parents) == 4
assert set(parents[1:]) == set(report['original_proposal_heads'].values())
for parent in parents:
    subprocess.run(['git', 'merge-base', '--is-ancestor', parent, head], cwd=ROOT, check=True)
expected_files = {
    'Cargo.toml', 'Cargo.lock', 'shardloom-vortex/Cargo.toml',
    'docs/architecture/dependency-intake-2026-11-06.md',
    'docs/architecture/phased-execution-plan.md',
    'docs/reference/shardloom-user-surface-index.json',
    'docs/reference/shardloom-user-surface-index.md',
    'python/THIRD_PARTY_LICENSES/manifest.json',
    'python/THIRD_PARTY_LICENSES/texts/e24a56698aa6feaf3a02272b3624f9dc255d982970c5ed97ac4525a95056a5b3.txt',
    'python/THIRD_PARTY_LICENSES/texts/163fbee5116a2725fdba8faa47a9fbf8006e0a7cbdb14ae5ecf62c8f9ccc00af.txt',
    'python/THIRD_PARTY_LICENSES/texts/44a626f7cf572fb5d30a97a3f7bf223ff05626a1c95094b0847ffe51d5c314d8.txt',
}
expected_files.update('docs/benchmarks/evidence/dependency-followup-2026-11-06/' + name
    for name in ('acceptance.json', 'verification.tar.xz', 'verify.py', 'README.md'))
assert set(git('diff', '--name-only', BASE, head).splitlines()) == expected_files
for name, expected in report['code_snapshot'].items():
    assert identity(ROOT / name) == expected
subprocess.run(['/opt/homebrew/opt/python@3.13/libexec/bin/python3', '-B',
    str(PACKET / 'verify.py'), '--repo-root', str(ROOT)], cwd=ROOT, check=True, timeout=120)
installed = read(OUT / 'installed-proof-r1/report.json')
for relative, key in [('runtime-r1/shardloom', 'cli_sha256'),
        ('runtime-r1/lib_native.dylib', 'native_library_sha256'),
        ('installed-proof-r1/dist/' + installed['integrity']['wheel'], 'wheel_sha256')]:
    assert identity(OUT / relative)['sha256'] == installed['integrity'][key]
result = dict(status='passed', head=head, tree=git('rev-parse', head + '^{tree}'),
    base=BASE, base_branch='codex/native-managed-binary-objects',
    base_tree=git('rev-parse', BASE + '^{tree}'), parents=parents,
    allowed_main_merge=dict(first_parent=OLD_MAIN, second_parent=BASE,
        tree=git('rev-parse', BASE + '^{tree}')),
    original_proposals_preserved=True, runtime_sources_match_build=True,
    runtime_source_proof='The only changed build sources are the three manifests/lockfile bound by every accepted stage. All runtime implementation, Python, scripts and CI files are unchanged from the reviewed binary-object base.',
    ci_workflow_blob=git('rev-parse', head + ':.github/workflows/ci.yml'),
    acceptance=identity(PACKET / 'acceptance.json'), archive=identity(PACKET / 'verification.tar.xz'),
    verifier=identity(PACKET / 'verify.py'), installed_package=report['installed_package'],
    changed_files=sorted(expected_files), publication_attempted=False, performance_claim=False)
with (OUT / 'delivery-acceptance-r1.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: result[key] for key in ('status', 'head', 'tree', 'parents')}))
