"""Check combined generated identities, notices and public documentation."""
import subprocess
import sys

checks = [
    ['scripts/write_public_api_reference.py', '--check'],
    ['scripts/write_python_api_exports.py', '--check'],
    ['scripts/check_user_surface_reference.py'],
    ['scripts/check_public_status_docs.py', '--output', '/Users/dylan/LocalData/shardloom/dependency-followup-2026-11-06/public-status-docs-r1.json'],
    ['scripts/check_contribution_governance.py', '--output', '/Users/dylan/LocalData/shardloom/dependency-followup-2026-11-06/contribution-governance-r1.json'],
    ['scripts/check_python_license_bundle.py'],
    ['-m', 'unittest', '-v', 'scripts.test_python_license_bundle', 'python.tests.test_public_api_reference'],
]
for arguments in checks:
    print('Checking ' + ' '.join(arguments), flush=True)
    subprocess.run([sys.executable, '-B', *arguments], check=True, timeout=120)
