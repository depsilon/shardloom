"""Reproduce archived-source-comparisons reports from exact published crate archives."""
import difflib, hashlib, io, json, tarfile, urllib.request
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
MANIFEST=Path('/Users/dylan/LocalData/shardloom/managed-binary-2026-11-06/dependency-pr-inventory-r1/primary-verification-r1.json')
REPORTS=ROOT/'archived-source-comparisons'
verified=json.loads(MANIFEST.read_bytes())
assert verified['status']=='passed'
MAX=4<<20
pairs=[('flate2','1.1.9','1.1.10'),('tonic','0.14.8','0.14.9'),('tonic-prost','0.14.6','0.14.8')]
def digest(b): return hashlib.sha256(b).hexdigest()
def load_archive(name,version):
 key=f'{name}-{version}'; evidence=verified['archives'][key]
 if (name,version) in {('flate2','1.1.10'),('tonic','0.14.9'),('tonic-prost','0.14.8')}:
  raw=(ROOT/'notice-inventory-r1'/f'{key}.crate').read_bytes()
 else:
  req=urllib.request.Request(evidence['url'],headers={'User-Agent':'ShardLoom archived source replay/1.0'})
  chunks=[]; total=0
  with urllib.request.urlopen(req,timeout=45) as response:
   while True:
    part=response.read(65536)
    if not part: break
    total+=len(part)
    if total>MAX: raise ValueError(f'{key}: exceeds 4 MiB')
    chunks.append(part)
  raw=b''.join(chunks)
 if len(raw)>MAX: raise ValueError(f'{key}: exceeds 4 MiB')
 actual=digest(raw)
 if actual!=evidence['archive_sha256']: raise ValueError(f'{key}: digest mismatch {actual}')
 (OUT/f'{key}.crate').write_bytes(raw)
 files={}
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as archive:
  for member in archive.getmembers():
   if member.isfile() and member.name.startswith(key+'/'):
    stream=archive.extractfile(member)
    if stream is None: raise ValueError(f'cannot read {member.name}')
    data=stream.read(MAX+1)
    if len(data)>MAX: raise ValueError(f'member too large {member.name}')
    files[member.name.removeprefix(key+'/')]=data
 return evidence,raw,files
def make_report(name,old,new):
 be,br,before=load_archive(name,old); ae,ar,after=load_archive(name,new)
 changes=[]
 for path in sorted(set(before)|set(after)):
  a,b=before.get(path),after.get(path)
  if a==b: continue
  row=dict(path=path,before_sha256=digest(a) if a is not None else None,after_sha256=digest(b) if b is not None else None)
  if path.startswith('src/') and path.endswith('.rs'):
   row['diff']=''.join(difflib.unified_diff((a or b'').decode().splitlines(True),(b or b'').decode().splitlines(True),fromfile=old+'/'+path,tofile=new+'/'+path))
  changes.append(row)
 report=dict(crate=name,before=old,after=new,before_archive_sha256=be['archive_sha256'],after_archive_sha256=ae['archive_sha256'],complete_archive_members_compared=True,changed_files=changes)
 expected=json.loads((REPORTS/f'{name}.json').read_bytes())
 mismatches=[]
 for field in sorted(set(report)|set(expected)):
  if report.get(field)!=expected.get(field): mismatches.append(field)
 return {'crate':name,'before_archive':{'version':old,'sha256':digest(br),'bytes':len(br),'member_count':len(before)},'after_archive':{'version':new,'sha256':digest(ar),'bytes':len(ar),'member_count':len(after)},'before_members':len(before),'after_members':len(after),'changed_file_count':len(changes),'source_rust_diff_count':sum('diff' in x for x in changes),'report_fields_compared':sorted(set(report)|set(expected)),'mismatched_fields':mismatches}
receipts=[make_report(*p) for p in pairs]
result={'status':'COMPLETE' if all(not x['mismatched_fields'] for x in receipts) else 'MISMATCH','manifest':str(MANIFEST),'report_directory':str(REPORTS),'max_archive_bytes':MAX,'algorithm':'inspect_archived_source.py snapshot/member map, sorted union comparison, SHA-256 changed-member rows, unified diffs for src/*.rs; structural JSON field comparison','crates':receipts}
(OUT/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
if result['status']!='COMPLETE': raise SystemExit(1)
