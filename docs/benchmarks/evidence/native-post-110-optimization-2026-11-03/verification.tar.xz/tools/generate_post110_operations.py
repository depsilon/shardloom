"""Rebuild the machine table and component analysis from frozen archive bytes."""
from pathlib import Path
import json
import lzma
import sys

sys.path.insert(0, str(Path.cwd() / "scripts"))
from verify_native_saved_operations import EVIDENCE, analyze

root = Path(sys.argv[1]) if len(sys.argv) >= 2 else Path(__file__).resolve().parents[1] / 'post110-analysis-r1'
report, table = analyze(root, EVIDENCE)
destination = Path(sys.argv[2]) if len(sys.argv) == 3 else root
if destination != root:
    destination.mkdir(exist_ok=False)
with (destination/'report.json').open('x') as out:
    out.write(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + '\n')
with (destination/'operations.jsonl.xz').open('xb') as out:
    out.write(lzma.compress(table, preset=6))
assert lzma.decompress((destination/'operations.jsonl.xz').read_bytes()) == table
print({k:report[k] for k in ('operation_count','archived_inputs','operation_table_sha256')})
