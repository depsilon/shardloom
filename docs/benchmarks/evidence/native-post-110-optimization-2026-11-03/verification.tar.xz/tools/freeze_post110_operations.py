"""Freeze the exact saved records used by the post-1.1.0 analysis."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path.cwd() / "scripts"))
from verify_native_saved_operations import ANCHORS, EVIDENCE, identities, operations
from shared_performance_bundle import sha, strict_json, write_bundle

out = Path(sys.argv[1]) if len(sys.argv) == 2 else Path(__file__).resolve().parents[1] / 'post110-analysis-r1'
out.mkdir(exist_ok=False)
base = out.parent.parent
anchor_data = {key: (EVIDENCE / rel).read_bytes() for key, rel in ANCHORS.items()}
anchors = {key: strict_json(data) for key, data in anchor_data.items()}
sources = {}

def raw(label):
    path = Path(label)
    assert path.is_absolute() and path.resolve().is_relative_to(base) and path.is_file()
    if label not in sources:
        assert path.stat().st_size < 16 << 20
        sources[label] = path.read_bytes()
    return sources[label]

rows = operations(raw, anchors)
if out.name != 'post110-analysis-r1':
    from shared_performance_bundle import Bundle
    original = Bundle(out.parent / 'post110-analysis-r1/inputs')
    assert all(sha(sources[label]) in original.paths[label] for label in original.paths)
    assert identities(rows) == original.index['evidence']['operations']
prior = {k: [] for k in ('probe', 'workflow')}
for key in prior:
    for member, ref in anchors[key]['archive']['source_map'].items():
        label = ref['source_path']
        if label in sources and sha(sources[label]) == ref['sha256']:
            prior[key].append(member)
            del sources[label]
    prior[key].sort()
digests = {p: [sha(value)] for p, value in sorted(sources.items())}
objects = {digests[p][0]: sources[p] for p in sorted(sources)}
frozen = dict(schema_version='shardloom.retained_component_inputs.v1',
    anchor_sha256={key: sha(data) for key,data in anchor_data.items()},
    prior_members=prior, operations=identities(rows))
bundle = write_bundle(out / 'inputs', objects, digests, frozen)
assert all(bundle.raw(p) == data for p, data in sources.items())
print(dict(operations=len(rows), existing_archive_members={k:len(v) for k,v in prior.items()},
           additional_paths=len(sources), input_manifest_sha256=sha((out/'inputs/manifest.json').read_bytes())))
