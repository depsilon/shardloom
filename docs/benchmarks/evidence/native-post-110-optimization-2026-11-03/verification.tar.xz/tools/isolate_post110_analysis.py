"""Exercise the default verifier while denying original input and engine access."""
import os
from pathlib import Path
import sys
sys.path.insert(0, str(Path.cwd() / "scripts"))
from verify_native_saved_operations import EVIDENCE, PACKET, main

root = Path(__file__).resolve().parents[2]
denied = []
def guard(event, args):
    if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
        path = Path(os.fsdecode(args[0])).resolve()
        if path.is_relative_to(root):
            denied.append('original')
            raise PermissionError('original input denied: ' + str(path))
    if event == 'subprocess.Popen' or event == 'os.system' or event.startswith(('socket.', 'os.exec', 'os.posix_spawn', 'os.spawn')):
        denied.append('external')
        raise PermissionError('external effect denied')
sys.addaudithook(guard)
try:
    (root/'direct-source-count-2026-10-31/source-strategy-probe-r1-acceptance.json').read_bytes()
except PermissionError:
    pass
assert denied == ['original']
sys.argv = [sys.argv[0]]
main()
assert denied == ['original']
print('Passed original-open control. The committed archives reproduced the table without original-input opens or process/network calls.')
