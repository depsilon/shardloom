"""Preserve every local validation attempt and the small forward controls."""
from pathlib import Path
import hashlib
import io
import json
import re
import tarfile

source = Path(__file__).resolve().parents[1]
output = Path.cwd() / 'docs/benchmarks/evidence/native-post-110-optimization-2026-11-03'
archive = output / 'verification.tar.xz'
acceptance = output / 'acceptance.json'
assert not archive.exists() and not acceptance.exists()
files, receipts = {}, {}
sha = lambda data: hashlib.sha256(data).hexdigest()
def keep(path, key=None):
    key = key or str(path.relative_to(source))
    assert key not in files and path.is_file() and not path.is_symlink()
    files[key] = path.read_bytes()
    return files[key]

for num in range(804, 830):
    [path] = source.glob(f'io{num}-post110-*.json')
    receipt = json.loads(keep(path))
    log = keep(path.with_suffix('.log'))
    assert sha(log) == receipt['log_sha256'] and receipt['process_group_drained']
    receipts[num] = {k:receipt[k] for k in ('head','status','returncode','log_sha256')}
    receipts[num]['path'] = path.name
    assert (receipt['status']=='passed') == (num not in {808,817,818,821}), (num,receipt['status'])

def tests(num):
    data = files[receipts[num]['path'].replace('.json','.log')].decode()
    lines = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored', data)
    assert lines
    return dict(zip(('passed','failed','ignored'),(sum(int(row[i]) for row in lines) for i in range(3))))

for run in ('post110-public-copies-r1','post110-public-copies-r2'):
    for path in sorted((source/run).iterdir()):
        if path.name == '_native.abi3.so':
            assert path.is_symlink()
        else:
            assert path.stat().st_size < 2 << 20
            keep(path)
for name in ('freeze_post110_operations','generate_post110_operations','isolate_post110_analysis',
             'run_guarded_post110','post110_public_copy_controls','record_post110_controls'):
    keep(source/'tools'/f'{name}.py')
keep(source/'post110-ci-gate.json')
with tarfile.open(archive, 'x:xz', preset=6) as stream:
    for name, data in sorted(files.items()):
        m = tarfile.TarInfo(name)
        m.size, m.mode, m.mtime = len(data), 0o644, 0
        stream.addfile(m, io.BytesIO(data))
with tarfile.open(archive,'r:xz') as stream:
    assert {f.name:stream.extractfile(f).read() for f in stream if f.isfile()} == files
forward = json.loads(files[receipts[827]['path'].replace('.json','.log')])
assert forward['status']=='passed' and forward['metadata_omits_copy_map']
assert (forward['rows'],forward['prepared_readback_rows'],forward['embedded_complete_rows'],forward['direct_complete_rows']) == (2048,2048,13,13)
report = json.loads((output/'report.json').read_bytes())
assert (report['operation_count'],report['archived_inputs'],report['new_engine_executions']) == (406,2628,0)
runtime = receipts[826]['head']
assert {receipts[i]['head'] for i in range(822,830)} == {runtime}
result = dict(schema_version='shardloom.retained_component_investigation_acceptance.v1', status='passed',
    saved_analysis=dict(operations=406, inputs=2628, new_engine_queries=0, independent_query_rows=13038,
        input_manifest_sha256=report['input_manifest_sha256'], operation_table_sha256=report['operation_table_sha256'],
        replay_isolation='Python audit hook blocked original artifact reads and subprocess/network effects after imports',
        new_performance_observations=0),
    forward_capture=dict(runtime_source_revision=runtime, profile='ci-native', features=['release-user-surfaces'],
        fixture=forward, scope='Small correctness controls. Historical benchmark reason volumes remain unknown.'),
    checks=dict(default_workspace=tests(824), native_workspace=tests(828), native_initial=tests(808),
        formatting_and_strict_default_and_native_clippy='passed', saved_evidence_controls=5),
    original_failed_attempts={808:'Default CLI invoked by staged-write smoke could not use optional Serde derive.',
        817:'Strict native lint required explicit defaults and a Copy disposition.',
        818:'The initial CLI evidence appender exceeded its lint line budget.',
        821:'Direct and metadata controls passed. Public preparation projected out conditional owner fields.'},
    attempts=list(receipts.values()), archive=dict(file=archive.name, members=len(files), bytes=archive.stat().st_size,
        sha256=sha(archive.read_bytes()), complete_member_readback=True))
with acceptance.open('x') as out:
    out.write(json.dumps(result, indent=2, allow_nan=False)+'\n')
print(json.dumps({k:result[k] for k in ('status','saved_analysis','checks','archive')}))
