"""Small public-surface correctness controls; no scored workload."""
from pathlib import Path
import json
import subprocess
import sys
import hashlib
import pyarrow as pa
import pyarrow.parquet as pq

repo = Path.cwd()
sys.path[:0] = [str(repo/'scripts'), str(repo/'python/src'), str(repo/'benchmarks/traditional_analytics')]
from native_workflow_protocol import extract_result, public_workflow_command, report_fields
from query_surface.evidence import no_fallback
from query_surface.worker import load_native

root = Path(sys.argv[1])
root.mkdir(exist_ok=False)
target = Path(json.loads(subprocess.check_output(['cargo','metadata','--offline','--locked','--no-deps','--format-version','1']))['target_directory'])/'ci-native'
cli = target/'shardloom'
library = target/'lib_native.dylib'
extension = root/'_native.abi3.so'
extension.symlink_to(library)
source = root/'hits.parquet'
out = root/'hits.vortex'
rows = [{'id': i, 'label': None if i % 5 == 0 else f'label-{i%7}-λ'} for i in range(2048)]
pq.write_table(pa.Table.from_pylist(rows), source, row_group_size=127)

def execute(case, command):
    result = subprocess.run(command, capture_output=True, timeout=30)
    (root/(case+'.stdout.json')).write_bytes(result.stdout)
    (root/(case+'.stderr.txt')).write_bytes(result.stderr)
    result.check_returncode()
    return json.loads(result.stdout)

def measure(fields, reasons, copied, scope):
    values = json.loads(fields[reasons])
    assert 'first_failed_transfer_condition_per_copied_region' in fields[scope]
    assert all(x['regions'] > 0 and x['visible_bytes'] >= 0 for x in values.values())
    assert sum(x['visible_bytes'] for x in values.values()) == int(fields[copied])
    return values

sql = "SELECT id, label FROM hits WHERE id < 13 ORDER BY id"
direct = execute('direct', public_workflow_command(cli, sql, input_path=source, input_format='parquet', max_parallelism=2))
fields = report_fields(direct)
assert extract_result(direct) == rows[:13]
args = ('native_input_columnar_copy_reasons','native_input_columnar_buffer_bytes_copied','native_input_columnar_copy_reason_scope')
cli_reasons = measure(fields, *args)
count = execute('metadata', public_workflow_command(cli, 'SELECT COUNT(*) AS n FROM hits', input_path=source, input_format='parquet'))
assert extract_result(count) == [{'n': len(rows)}]
assert args[0] not in report_fields(count)
prep = execute('preparation', [str(cli),'prepare','dataframe','--input',str(source),'--input-format','parquet',
    '--output',str(out),'--memory-gb','1','--max-parallelism','2','--format','json'])
prep_fields = report_fields(prep)
prefix = 'public_workflow_preparation_vortex_ingest_ownership_'
prep_reasons = measure(prep_fields, prefix+'copy_reasons', prefix+'copied_buffer_bytes', prefix+'copy_reason_scope')
assert sum(x['regions'] for x in prep_reasons.values()) + int(prep_fields[prefix+'transferred_buffer_regions']) == int(prep_fields[prefix+'buffer_regions'])
prepared = execute('prepared-readback', public_workflow_command(cli, 'SELECT id, label FROM hits ORDER BY id',
    input_path=out, input_format='vortex', max_parallelism=2))
assert extract_result(prepared) == rows
native = load_native(extension)
session = native.Session(native.ExecutionResources(1 << 30, 2))
try:
    selection = sql.replace('FROM hits', f"FROM '{source}'")
    result = session.sql(selection, files=[(str(source),'parquet',None)]).collect()
    values, export = result.row_export(temporal_objects=False)
    assert values == rows[:13] and export['complete'] and not export['fallback_attempted']
    native_fields = dict(result.report)
    no_fallback(native_fields)
    embedded_reasons = measure(native_fields, *args)
    (root/'embedded-fields.json').write_text(json.dumps(native_fields, sort_keys=True, indent=2))
finally:
    session.close()
print(json.dumps(dict(status='passed', rows=len(rows), prepared_readback_rows=len(rows), direct_complete_rows=13, embedded_complete_rows=13,
    metadata_count=len(rows), metadata_omits_copy_map=True, direct=cli_reasons,
    preparation=prep_reasons, embedded=embedded_reasons,
    source_output_bytes=out.stat().st_size, binaries={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (cli,library)})))
