"""Preserve the complete bounded owner observation and exact restoration proof."""
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

import observe_retained_owner as o

EVIDENCE = o.ROOT / 'docs/benchmarks/evidence'
BASENAME = 'native-rematerialization-owners-2026-10-07'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def portable(data):
    text = data.decode()
    replacements = (
        (str(o.ROOT), '<SOURCE_ROOT>'), (str(o.OUT), '<OBSERVATION_ROOT>'),
        (str(o.PRIOR), '<FSST_ACCEPTANCE_ROOT>'),
        ('<CARGO_TARGET>', '<CARGO_TARGET>'),
        ('<USER_HOME>', '<USER_HOME>'),
    )
    for before, after in replacements:
        text = text.replace(before, after)
    assert not re.search(r"/(?:Users|home)/[^\s/'\"]+/", text)
    return text.encode()


def main():
    protocol = o.frozen(overlay=False)
    assert not o.original.git('status', '--porcelain')
    restored = o.read(o.OUT / 'retained-owner-restored-1.json')
    inspected = o.read(o.OUT / 'retained-owner-inspection-1.json')
    build = o.read(o.OUT / 'retained-owner-build-1.json')
    assert restored['status'] == 'restored_exact_accepted_runtime_sources'
    assert restored['source_assets'] == 947 and restored['temporary_observer_absent']
    assert inspected['status'] == 'passed_bounded_owner_observation'
    assert inspected['protocol_sha256'] == restored['protocol_sha256'] == o.sha(o.PROTOCOL)
    assert build['status'] == 'passed' and build['protocol_sha256'] == o.sha(o.PROTOCOL)
    assert o.sha(build['binary']) == build['binary_sha256']
    assert len(inspected['cases']) == len(inspected['summaries']) == 25
    assert inspected['full_original_values_compared'] == 12_263_424
    assert inspected['full_reconstructed_values_compared'] == 12_263_424
    summaries = inspected['summaries']
    ordinary = [case for case in summaries if case['mode'] == 'Derived']
    controls = [case for case in summaries if case['mode'] in ('SourceAlias', 'Constant', 'DerivedKeys')]
    assert len(ordinary) == 6 and len(controls) == 18
    assert all(case['released_after_table_bytes'] > 0 for case in ordinary)
    assert all(case['released_after_slice_bytes'] == 0 for case in controls)
    alias = summaries[-1]
    assert alias['mode'] == 'DerivedCloneSlice'
    assert alias['released_after_table_bytes'] == alias['released_after_clone_bytes'] == 0
    assert alias['released_after_slice_bytes'] == 17_072_128
    largest = next(case for case in ordinary if case['rows'] == 32768 and case['payload_columns'] == 64)
    assert largest['retained_bytes'] == 17_869_504
    assert largest['released_after_table_bytes'] == 17_072_128
    assert largest['still_retained_bytes'] == 797_376
    assert largest['sampled_max_reconstruction_increment_bytes'] == 266_752
    for name in ('retained-owner-freeze-1', 'retained-owner-build-check-1',
                 'retained-owner-observation-check-1', 'retained-owner-inspection-check-1',
                 'retained-owner-restore-check-1'):
        guard = o.read(o.OUT / (name + '.json'))
        assert guard['status'] == 'passed' and guard['returncode'] == 0
        assert guard['process_group_drained']
        assert guard['log_sha256'] == o.sha(o.OUT / (name + '.log'))

    names = [
        'retained-owner-screen-draft.md', 'retained_owner_observation.rs',
        'observe_retained_owner.py', 'run_guarded.py', 'archive_retained_owner.py',
        'archive_retained_owner_before_fix.py',
        'retained-owner-archive-1.json', 'retained-owner-archive-1.log',
        'retained-owner-protocol-1.json',
        'retained-owner-freeze-1.json', 'retained-owner-freeze-1.log',
        'retained-owner-build-1.json', 'retained-owner-build-1.jsonl', 'retained-owner-build-1.stderr.log',
        'retained-owner-build-check-1.json', 'retained-owner-build-check-1.log',
        'retained-owner-observation-1.json', 'retained-owner-observation-1.log',
        'retained-owner-observation-check-1.json', 'retained-owner-observation-check-1.log',
        'retained-owner-inspection-1.json',
        'retained-owner-inspection-check-1.json', 'retained-owner-inspection-check-1.log',
        'retained-owner-restored-1.json',
        'retained-owner-restore-check-1.json', 'retained-owner-restore-check-1.log',
    ]
    members = {}
    identities = []
    for name in names:
        raw = (o.OUT / name).read_bytes()
        content = portable(raw)
        member = 'observation/' + name
        members[member] = content
        identities.append({'member': member, 'original_bytes': len(raw), 'original_sha256': digest(raw),
                           'portable_bytes': len(content), 'portable_sha256': digest(content)})
    dependencies = {
        'fsst_common.py': o.PRIOR / 'fsst_common.py',
        'fsst-source-1.json': o.PRIOR / 'fsst-source-1.json',
        'release_validation_guard.py': Path('<USER_HOME>/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'),
        'bounded_build_process_resume_20260912.py': Path('<USER_HOME>/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py'),
    }
    for name, path in dependencies.items():
        raw = path.read_bytes()
        content = portable(raw)
        member = 'dependencies/' + name
        members[member] = content
        identities.append({'member': member, 'original_bytes': len(raw), 'original_sha256': digest(raw),
                           'portable_bytes': len(content), 'portable_sha256': digest(content)})
    manifest = {
        'schema_version': 'shardloom.retained_native_owner_archive.v1',
        'protocol_original_sha256': o.sha(o.PROTOCOL),
        'source_commit': protocol['source_commit'], 'accepted_merge_commit': protocol['accepted_merge_commit'],
        'accepted_runtime_commit': protocol['accepted_runtime_commit'],
        'members': identities,
        'path_translation': 'Personal local roots are explicit placeholders; original-byte and portable-text hashes are separate. Rebind paths and create fresh evidence names/protocol for replay. The source commit and the earlier FSST packet supply referenced repository/prior-validation prerequisites.',
        'binary_contents_included': False, 'binary_sha256': build['binary_sha256'],
    }
    members['manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
    local = o.OUT / (BASENAME + '.tar.xz')
    with local.open('xb') as output:
        with tarfile.open(fileobj=output, mode='w:xz', preset=6) as archive:
            for name, data in sorted(members.items()):
                header = tarfile.TarInfo(name)
                header.size = len(data)
                header.mode = 0o644
                header.mtime = 0
                archive.addfile(header, io.BytesIO(data))
    with tarfile.open(local, 'r:xz') as archive:
        assert sorted(archive.getnames()) == sorted(members)
        for member in archive.getmembers():
            assert member.isfile()
            assert archive.extractfile(member).read() == members[member.name]
    target = EVIDENCE / local.name
    with target.open('xb') as output:
        output.write(local.read_bytes())
    assert o.sha(target) == o.sha(local)
    record = {
        'schema_version': 'shardloom.retained_native_owner_observation_index.v1',
        'status': 'passed_bounded_owner_observation',
        'disposition': 'Retained derived non-key payload is a measured candidate for a complete-workflow experiment; no production rematerialization policy is admitted.',
        'accepted_runtime_commit': protocol['accepted_runtime_commit'],
        'accepted_merge_commit': protocol['accepted_merge_commit'],
        'source_commit': protocol['source_commit'],
        'protocol_original_sha256': o.sha(o.PROTOCOL),
        'overlay_source_identity_sha256': protocol['overlay_source_identity_sha256'],
        'production_assets_restored': 947, 'temporary_observer_removed': True,
        'build_profile': protocol['profile'], 'binary_sha256': build['binary_sha256'],
        'grant_bytes_per_case': 256 * 1024 * 1024, 'cpu_lanes_per_case': 1,
        'cases': 25, 'positive_derived_cases': 6, 'zero_reclaim_controls': 18,
        'original_values_compared': 12_263_424, 'regenerated_values_compared': 12_263_424,
        'final_reserved_bytes_every_case': 0, 'denied_reservations_every_case': 0,
        'largest_derived': largest, 'clone_slice_control': alias,
        'summaries': summaries,
        'archive': {'path': str(target.relative_to(o.ROOT)), 'bytes': target.stat().st_size,
                    'sha256': o.sha(target), 'members': len(members),
                    'all_members_reopened_and_compared': True},
        'complete_public_workflow_tested': False, 'production_policy_admitted': False,
        'process_rss_cap_claim': False, 'speed_claim_allowed': False,
        'reconstruction_headroom_is_sampled': True, 'pool_peak_is_cumulative': True,
        'test_metadata_outside_native_pool': True,
        'package_publication_attempted': False,
        'packaging_failure_preserved': 'The first archive attempt stopped before creating an archive because its privacy assertion matched its own generic path-prefix literals. The corrected check detects concrete user-home paths. Original packaging source, failure log and drained supervisor receipt are retained; frozen observation code and results are unchanged.',
    }
    o.write(EVIDENCE / (BASENAME + '.json'), record)
    print(json.dumps({'status': record['status'], 'archive_sha256': o.sha(target),
                      'archive_bytes': target.stat().st_size, 'members': len(members)}), flush=True)


if __name__ == '__main__':
    main()
