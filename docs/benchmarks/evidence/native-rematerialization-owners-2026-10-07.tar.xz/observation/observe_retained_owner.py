"""Freeze and observe retained native ownership; not a production policy."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('<SOURCE_ROOT>')
OUT = Path(__file__).resolve().parent
PRIOR = Path('<FSST_ACCEPTANCE_ROOT>')
sys.path.insert(0, str(PRIOR))
import fsst_common as original

PARENT = 'shardloom-vortex/src/local_primitives/native_relational_batch.rs'
OBSERVER = 'shardloom-vortex/src/local_primitives/retained_owner_observation.rs'
HOOK = '\n#[cfg(test)]\n#[path = "retained_owner_observation.rs"]\nmod retained_owner_observation;\n'
TEST = 'local_primitives::native_relational_batch::retained_owner_observation::retained_owner_observation'
PROTOCOL = OUT / 'retained-owner-protocol-1.json'
RUST = ['<USER_HOME>/.cargo/bin/rustup', 'run', '1.99.0', 'cargo']
BUILD = RUST + ['test', '--offline', '--locked', '-p', 'shardloom-vortex', '--lib',
                '--features', 'release-user-surfaces', '--no-run', '--message-format=json']
STAGES = ['after_source', 'after_recipe', 'after_retention', 'after_table_payload_release',
          'after_clone_release', 'after_slice_release', 'after_reconstruction',
          'after_drop', 'after_session_drop']


def sha(path):
    return original.sha(path)


def read(path):
    return original.read(path)


def write(path, value):
    original.write(path, value)


def source_identity(sources):
    return hashlib.sha256(json.dumps(sources, sort_keys=True).encode()).hexdigest()


def matrix():
    cases = [{'rows': rows, 'payload_columns': width, 'mode': mode}
             for rows in (2048, 32768) for width in (1, 8, 64)
             for mode in ('Derived', 'SourceAlias', 'Constant', 'DerivedKeys')]
    return cases + [{'rows': 32768, 'payload_columns': 64, 'mode': 'DerivedCloneSlice'}]


def helpers():
    return {name: sha(OUT / name) for name in (
        'observe_retained_owner.py', 'run_guarded.py',
        'retained_owner_observation.rs', 'retained-owner-screen-draft.md')}


def freeze():
    assert not original.git('status', '--porcelain'), 'requires a clean accepted source tree'
    hosted = read(ROOT / 'docs/benchmarks/evidence/native-fsst-hosted-2026-10-07.json')
    assert hosted['status'] == 'passed_hosted_integration'
    assert hosted['successful_pr_checks'] == 39
    assert hosted['runtime_source_assets_unchanged']
    original.git('merge-base', '--is-ancestor', hosted['merge_commit'], 'HEAD')
    source = original.frozen()
    assert len(source['source_hashes']) == 947
    base = (ROOT / PARENT).read_bytes()
    assert b'retained_owner_observation' not in base and not (ROOT / OBSERVER).exists()
    overlay = dict(source['source_hashes'])
    overlay[PARENT] = hashlib.sha256(base + HOOK.encode()).hexdigest()
    overlay[OBSERVER] = sha(OUT / 'retained_owner_observation.rs')
    protocol = {
        'schema_version': 'shardloom.retained_native_owner_observation.v1',
        'frozen_at': datetime.now(timezone.utc).isoformat(),
        'source_commit': original.git('rev-parse', 'HEAD'),
        'accepted_merge_commit': hosted['merge_commit'],
        'accepted_runtime_commit': hosted['runtime_commit'],
        'base_source_hashes': source['source_hashes'],
        'overlay_source_hashes': overlay,
        'overlay_source_identity_sha256': source_identity(overlay),
        'helpers': helpers(),
        'prior_common_sha256': sha(PRIOR / 'fsst_common.py'),
        'prior_source_manifest_sha256': sha(PRIOR / 'fsst-source-1.json'),
        'hosted_receipt_sha256': sha(ROOT / 'docs/benchmarks/evidence/native-fsst-hosted-2026-10-07.json'),
        'matrix': matrix(), 'native_grant_bytes': 256 * 1024 * 1024, 'cpu_lanes': 1,
        'build_command': BUILD, 'test_name': TEST,
        'profile': 'Cargo test development profile; durations are observational, not a production performance comparison',
        'fixture': 'Allocator-owned ordinal plus nullable a and b. a=NULL at row%97==0 else row%257-128; b=NULL at row%89==0 else (row%61)*3-90. Derived=(a+b)+(column+1).',
        'observations': STAGES,
        'ownership': 'Retain immutable source checkpoint, recipe and actual Batch/Table/KeyColumn owners. Release only payload ArrayRef, then declared clone and slice. Reconstruct each column once, verify all values independently, drop all owners to zero credits.',
        'admission_gate': 'Positive live credits actually released with dependencies/keys retained, exact original and regenerated values, bounded one regeneration per column and zero final credits. This only permits designing a complete workflow experiment, not shipping a production policy.',
        'no_fallback': True, 'public_workflow_acceptance': False,
        'process_rss_cap_claim': False, 'performance_claim_allowed': False,
        'test_metadata_outside_native_pool': True,
        'reconstruction_headroom_is_sampled': True,
        'native_pool_peak_is_cumulative': True,
    }
    write(PROTOCOL, protocol)
    print(json.dumps({'status': 'frozen', 'protocol_sha256': sha(PROTOCOL),
                      'source_assets': len(overlay), 'cases': len(matrix())}), flush=True)


def frozen(overlay=True):
    protocol = read(PROTOCOL)
    assert helpers() == protocol['helpers']
    assert sha(PRIOR / 'fsst_common.py') == protocol['prior_common_sha256']
    assert sha(PRIOR / 'fsst-source-1.json') == protocol['prior_source_manifest_sha256']
    assert original.git('rev-parse', 'HEAD') == protocol['source_commit']
    expected = protocol['overlay_source_hashes'] if overlay else protocol['base_source_hashes']
    assert original.source_hashes() == expected, 'source differs from the frozen ownership observation'
    return protocol


def build(attempt):
    protocol = frozen()
    output = OUT / f'retained-owner-build-{attempt}.jsonl'
    errors = OUT / f'retained-owner-build-{attempt}.stderr.log'
    with output.open('xb') as stdout, errors.open('xb') as stderr:
        result = subprocess.run(BUILD, cwd=ROOT, stdout=stdout, stderr=stderr, check=False)
    record = {'status': 'passed' if result.returncode == 0 else 'failed',
              'returncode': result.returncode, 'protocol_sha256': sha(PROTOCOL),
              'stdout_sha256': sha(output), 'stderr_sha256': sha(errors),
              'command': BUILD, 'source_identity_sha256': protocol['overlay_source_identity_sha256']}
    if result.returncode == 0:
        artifacts = [json.loads(line) for line in output.read_text().splitlines() if line.strip()]
        binaries = [row['executable'] for row in artifacts if row.get('reason') == 'compiler-artifact'
                    and row.get('target', {}).get('name') == 'shardloom_vortex'
                    and row.get('profile', {}).get('test') and row.get('executable')]
        assert len(binaries) == 1, binaries
        record.update(binary=binaries[0], binary_sha256=sha(binaries[0]))
        frozen()
    write(OUT / f'retained-owner-build-{attempt}.json', record)
    print(json.dumps(record), flush=True)
    raise SystemExit(result.returncode)


def observe(attempt, build_attempt):
    protocol = frozen()
    build_record = read(OUT / f'retained-owner-build-{build_attempt}.json')
    assert build_record['status'] == 'passed'
    assert build_record['protocol_sha256'] == sha(PROTOCOL)
    binary = build_record['binary']
    assert sha(binary) == build_record['binary_sha256']
    command = [binary, TEST, '--exact', '--ignored', '--nocapture', '--test-threads=1']
    output = OUT / f'retained-owner-observation-{attempt}.log'
    env = dict(os.environ, SHARDLOOM_REMAT_PROTOCOL_SHA256=sha(PROTOCOL))
    with output.open('xb') as stream:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=stream,
                                stderr=subprocess.STDOUT, check=False)
    record = {'status': 'passed' if result.returncode == 0 else 'failed',
              'returncode': result.returncode, 'protocol_sha256': sha(PROTOCOL),
              'binary_sha256': sha(binary), 'command': command,
              'stdout_sha256': sha(output)}
    write(OUT / f'retained-owner-observation-{attempt}.json', record)
    frozen()
    print(json.dumps(record), flush=True)
    raise SystemExit(result.returncode)


def inspect(attempt):
    protocol = frozen()
    result = read(OUT / f'retained-owner-observation-{attempt}.json')
    assert result['status'] == 'passed' and result['returncode'] == 0
    log = OUT / f'retained-owner-observation-{attempt}.log'
    assert sha(log) == result['stdout_sha256']
    raw = log.read_text()
    assert 'test result: ok. 1 passed; 0 failed;' in raw
    cases = []
    terminal = []
    for line in raw.splitlines():
        if 'REMAT_OWNER_CASE ' in line:
            entry = json.loads(line.split('REMAT_OWNER_CASE ', 1)[1])
            assert entry['protocol_sha256'] == sha(PROTOCOL)
            cases.append(entry['case'])
        if 'REMAT_OWNER_COMPLETE ' in line:
            terminal.append(json.loads(line.split('REMAT_OWNER_COMPLETE ', 1)[1]))
    assert terminal == [{'protocol_sha256': sha(PROTOCOL), 'cases': 25}]
    assert len(cases) == 25
    summaries = []
    for expected, case in zip(protocol['matrix'], cases, strict=True):
        assert all(case[key] == value for key, value in expected.items())
        rows, width, mode = case['rows'], case['payload_columns'], case['mode']
        assert case['grant_bytes'] == protocol['native_grant_bytes'] and case['cpu_lanes'] == 1
        assert case['source_columns'] == 3
        assert case['key_columns'] == (width + 1 if mode == 'DerivedKeys' else 1)
        assert case['original_values_compared'] == case['reconstructed_values_compared'] == rows * width
        assert case['logical_dense_payload_value_bytes'] == rows * width * 8
        assert case['key_rows_rechecked'] == rows and case['reconstruction_count_per_column'] == 1
        assert case['validation_excluded_from_operation_timings']
        assert case['test_metadata_outside_native_pool'] and case['pool_peak_is_cumulative_not_reconstruction_only']
        for stage in STAGES:
            snapshot = case[stage]
            assert snapshot['limit_bytes'] == case['grant_bytes']
            assert snapshot['denied_reservations'] == 0
            assert 0 <= snapshot['reserved_bytes'] <= snapshot['cumulative_peak_reserved_bytes'] <= case['grant_bytes']
        assert case['after_drop']['reserved_bytes'] == case['after_session_drop']['reserved_bytes'] == 0
        baseline = case['after_slice_release']['reserved_bytes']
        assert case['after_reconstruction']['reserved_bytes'] == baseline
        assert len(case['reconstruction_columns']) == width
        live = [entry['reserved_with_restored_column'] for entry in case['reconstruction_columns']]
        assert [entry['column'] for entry in case['reconstruction_columns']] == list(range(width))
        assert all(baseline <= value <= case['grant_bytes'] for value in live)
        assert case['minimum_sampled_reconstruction_headroom_bytes'] == case['grant_bytes'] - max([baseline] + live)
        for key, value in case.items():
            if key.endswith('_seconds') or key == 'construction_seconds_including_checkpoint_recipe_keys':
                assert math.isfinite(value) and value >= 0
        retained = case['after_retention']['reserved_bytes']
        summaries.append(dict(expected,
            native_payload_nbytes=case['native_payload_nbytes_before_release'],
            logical_dense_payload_value_bytes=case['logical_dense_payload_value_bytes'],
            after_source_bytes=case['after_source']['reserved_bytes'],
            retained_bytes=retained,
            released_after_table_bytes=retained - case['after_table_payload_release']['reserved_bytes'],
            released_after_clone_bytes=retained - case['after_clone_release']['reserved_bytes'],
            released_after_slice_bytes=retained - baseline,
            still_retained_bytes=baseline,
            sampled_max_reconstruction_increment_bytes=max(live) - baseline,
            construction_seconds=case['construction_seconds_including_checkpoint_recipe_keys'],
            reconstruction_evaluation_seconds=case['reconstruction_evaluation_seconds'],
            reconstruction_release_seconds=case['reconstruction_release_seconds']))
    record = {'status': 'passed_bounded_owner_observation', 'protocol_sha256': sha(PROTOCOL),
              'source_identity_sha256': protocol['overlay_source_identity_sha256'],
              'observation_receipt_sha256': sha(OUT / f'retained-owner-observation-{attempt}.json'),
              'raw_log_sha256': sha(log), 'cases': cases, 'summaries': summaries,
              'full_original_values_compared': sum(row['original_values_compared'] for row in cases),
              'full_reconstructed_values_compared': sum(row['reconstructed_values_compared'] for row in cases),
              'public_workflow_acceptance': False, 'production_policy_admitted': False,
              'speed_claim_allowed': False, 'process_rss_cap_claim': False}
    write(OUT / f'retained-owner-inspection-{attempt}.json', record)
    print(json.dumps({'status': record['status'], 'cases': len(cases),
                      'full_original_values_compared': record['full_original_values_compared'],
                      'summaries': summaries}, indent=2), flush=True)


def restored(attempt):
    protocol = frozen(overlay=False)
    assert not original.git('status', '--porcelain'), 'restoration must leave the original clean tree'
    record = {'status': 'restored_exact_accepted_runtime_sources',
              'protocol_sha256': sha(PROTOCOL), 'source_assets': len(protocol['base_source_hashes']),
              'temporary_observer_absent': not (ROOT / OBSERVER).exists(),
              'source_commit': protocol['source_commit']}
    assert record['source_assets'] == 947 and record['temporary_observer_absent']
    write(OUT / f'retained-owner-restored-{attempt}.json', record)
    print(json.dumps(record), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=('freeze', 'build', 'observe', 'inspect', 'restored'))
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--build-attempt', type=int, default=1)
    args = parser.parse_args()
    assert args.attempt > 0 and args.build_attempt > 0
    if args.stage == 'freeze':
        freeze()
    elif args.stage == 'build':
        build(args.attempt)
    elif args.stage == 'observe':
        observe(args.attempt, args.build_attempt)
    elif args.stage == 'inspect':
        inspect(args.attempt)
    else:
        restored(args.attempt)
