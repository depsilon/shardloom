//! Temporary ownership observation; no production policy or public benchmark.

use super::super::native_relational_expression::{Expression, Kind};
use super::{Batch, Table, logical_field_from_native_array, result_batch, vortex_error};
use crate::resident_session::{NativeExecutionContext, ResidentVortexSession};
use serde_json::{Value as JsonValue, json};
use shardloom_core::{BinaryOp, Result};
use shardloom_exec::{compute_pool::CancellationToken, live_memory::LiveMemoryPool};
use std::time::Instant;
use vortex::array::{
    ArrayRef, IntoArray, VortexSessionExecute as _,
    arrays::StructArray,
    dtype::{DType, FieldNames, Nullability, PType},
    memory::MemorySessionExt as _,
    scalar::Scalar,
    validity::Validity,
};

const GRANT: u64 = 256 * 1024 * 1024;

#[derive(Clone, Copy, Debug)]
enum Mode {
    Derived,
    SourceAlias,
    Constant,
    DerivedKeys,
    DerivedCloneSlice,
}

fn dtype(nullable: bool) -> DType {
    DType::Primitive(
        PType::I64,
        if nullable {
            Nullability::Nullable
        } else {
            Nullability::NonNullable
        },
    )
}

fn source_value(side: usize, row: usize) -> Option<i64> {
    match side {
        0 => (!row.is_multiple_of(97)).then_some((row % 257) as i64 - 128),
        1 => (!row.is_multiple_of(89)).then_some((row % 61) as i64 * 3 - 90),
        _ => panic!("two source values only"),
    }
}

fn expected(mode: Mode, column: usize, row: usize) -> Option<i64> {
    let offset = i64::try_from(column + 1).unwrap();
    match mode {
        Mode::SourceAlias => source_value(0, row),
        Mode::Constant => Some(offset),
        Mode::Derived | Mode::DerivedKeys | Mode::DerivedCloneSlice => source_value(0, row)
            .zip(source_value(1, row))
            .map(|(a, b)| a + b + offset),
    }
}

fn column(name: &str, nullable: bool) -> Expression {
    Expression {
        dtype: dtype(nullable),
        kind: Kind::Column(name.to_owned()),
    }
}

fn recipe(mode: Mode, ordinal: usize) -> Expression {
    let offset = i64::try_from(ordinal + 1).unwrap();
    let literal = Expression {
        dtype: dtype(false),
        kind: Kind::Literal(Scalar::from(offset)),
    };
    match mode {
        Mode::SourceAlias => column("a", true),
        Mode::Constant => literal,
        Mode::Derived | Mode::DerivedKeys | Mode::DerivedCloneSlice => Expression {
            dtype: dtype(true),
            kind: Kind::Binary(
                Box::new(Expression {
                    dtype: dtype(true),
                    kind: Kind::Binary(
                        Box::new(column("a", true)),
                        BinaryOp::Add,
                        Box::new(column("b", true)),
                    ),
                }),
                BinaryOp::Add,
                Box::new(literal),
            ),
        },
    }
}

fn native_struct(names: &[String], columns: Vec<ArrayRef>, rows: usize) -> Result<ArrayRef> {
    StructArray::try_new(
        names.iter().map(String::as_str).collect::<FieldNames>(),
        columns,
        rows,
        Validity::NonNullable,
    )
    .map_err(vortex_error)
    .map(IntoArray::into_array)
}

fn snapshot(memory: &LiveMemoryPool) -> JsonValue {
    let value = memory.snapshot();
    json!({
        "limit_bytes": value.limit_bytes,
        "reserved_bytes": value.reserved_bytes,
        "cumulative_peak_reserved_bytes": value.peak_reserved_bytes,
        "denied_reservations": value.denied_reservations,
    })
}

fn verify_column(
    array: &ArrayRef,
    mode: Mode,
    column: usize,
    rows: usize,
    context: &NativeExecutionContext<'_>,
) -> Result<()> {
    assert_eq!(array.len(), rows);
    assert_eq!(array.dtype(), &dtype(!matches!(mode, Mode::Constant)));
    let mut execution = context.native_session().create_execution_ctx();
    for row in 0..rows {
        match (
            result_batch::scalar_value(array, row, &mut execution)?,
            expected(mode, column, row),
        ) {
            (result_batch::Value::Null, None) => {}
            (result_batch::Value::Int(actual), Some(value)) => assert_eq!(actual, value),
            _ => panic!("native value differs from the independent nullable Int64 formula"),
        }
    }
    Ok(())
}

fn observe_case(rows: usize, width: usize, mode: Mode) -> Result<JsonValue> {
    let session = ResidentVortexSession::new(GRANT, 1)?;
    let memory = session.memory().clone();
    let mut record =
        session.with_native_execution_context(&CancellationToken::default(), |context| {
            let construction_started = Instant::now();
            let allocator = context.native_session().allocator();
            let mut source_columns = Vec::new();
            source_columns.push(result_batch::build_column(
                &dtype(false),
                rows,
                &allocator,
                |row| Ok(result_batch::Value::Int(i64::try_from(row).unwrap())),
            )?);
            for side in 0..2 {
                source_columns.push(result_batch::build_column(
                    &dtype(true),
                    rows,
                    &allocator,
                    |row| {
                        Ok(source_value(side, row)
                            .map_or(result_batch::Value::Null, result_batch::Value::Int))
                    },
                )?);
            }
            let checkpoint = native_struct(
                &["ordinal".to_owned(), "a".to_owned(), "b".to_owned()],
                source_columns,
                rows,
            )?;
            let source_construction_seconds = construction_started.elapsed().as_secs_f64();
            let after_source = snapshot(&memory);
            let expressions = (0..width)
                .map(|index| recipe(mode, index))
                .collect::<Vec<_>>();
            let payload_names = (0..width)
                .map(|index| format!("payload_{index:02}"))
                .collect::<Vec<_>>();
            let after_recipe = snapshot(&memory);
            let mut names = vec!["ordinal".to_owned()];
            names.extend(payload_names.iter().cloned());
            let key_names = if matches!(mode, Mode::DerivedKeys) {
                names.clone()
            } else {
                names[..1].to_vec()
            };
            let ordinal = logical_field_from_native_array(&checkpoint, "ordinal")?;
            let key_only = native_struct(&names[..1], vec![ordinal.clone()], rows)?;
            let mut columns = vec![ordinal];
            let mut payload_nbytes = 0u64;
            for expression in &expressions {
                let array = expression.evaluate(&checkpoint, context)?;
                payload_nbytes += array.nbytes();
                columns.push(array);
            }
            let output = native_struct(&names, columns, rows)?;
            let output_dtype = output.dtype().to_string();
            let mut clone = matches!(mode, Mode::DerivedCloneSlice).then(|| output.clone());
            let mut slice = if clone.is_some() {
                Some(output.slice(1..rows - 1).map_err(vortex_error)?)
            } else {
                None
            };
            let mut table = Table::new(&memory)?;
            assert_eq!(
                table.push(Batch::new(output, &key_names, context)?)?,
                0..rows
            );
            assert_eq!(table.rows(), rows);
            let construction_seconds = construction_started.elapsed().as_secs_f64();
            let after_retention = snapshot(&memory);
            let key_hashes = (0..rows)
                .map(|row| table.hash(row, true))
                .collect::<Result<Vec<_>>>()?;
            for (index, name) in payload_names.iter().enumerate() {
                verify_column(
                    &logical_field_from_native_array(&table.segments.values[0].batch.array, name)?,
                    mode,
                    index,
                    rows,
                    context,
                )?;
            }
            assert_eq!(
                memory.snapshot().reserved_bytes,
                after_retention["reserved_bytes"].as_u64().unwrap()
            );

            // Keep the real key owners, checkpoint and declared aliases alive.
            table.segments.values[0].batch.array = key_only;
            let after_table_payload_release = snapshot(&memory);
            drop(clone.take());
            let after_clone_release = snapshot(&memory);
            drop(slice.take());
            let after_slice_release = snapshot(&memory);
            let retained_baseline = memory.snapshot().reserved_bytes;
            let mut reconstruction_evaluation_seconds = 0.0;
            let mut reconstruction_release_seconds = 0.0;
            let mut minimum_observed_headroom = GRANT - retained_baseline;
            let mut reconstruction_columns = Vec::new();
            for (index, expression) in expressions.iter().enumerate() {
                let started = Instant::now();
                let restored = expression.evaluate(&checkpoint, context)?;
                reconstruction_evaluation_seconds += started.elapsed().as_secs_f64();
                let live = memory.snapshot().reserved_bytes;
                minimum_observed_headroom = minimum_observed_headroom.min(GRANT - live);
                verify_column(&restored, mode, index, rows, context)?;
                let started = Instant::now();
                drop(restored);
                reconstruction_release_seconds += started.elapsed().as_secs_f64();
                assert_eq!(memory.snapshot().reserved_bytes, retained_baseline);
                reconstruction_columns
                    .push(json!({"column": index, "reserved_with_restored_column": live}));
            }
            for (row, original) in key_hashes.into_iter().enumerate() {
                assert_eq!(table.hash(row, true)?, original);
                assert!(table.equal(row, row, true)?);
                if row > 0 {
                    assert!(!table.equal(row - 1, row, true)?);
                }
            }
            let after_reconstruction = snapshot(&memory);
            drop((table, checkpoint, expressions));
            let after_drop = snapshot(&memory);
            assert_eq!(memory.snapshot().reserved_bytes, 0);
            assert_eq!(memory.snapshot().denied_reservations, 0);
            Ok(json!({
                "rows": rows, "payload_columns": width, "mode": format!("{mode:?}"),
                "source_columns": 3, "key_columns": key_names.len(), "dtype": output_dtype,
                "grant_bytes": GRANT, "cpu_lanes": 1,
                "logical_dense_payload_value_bytes": rows * width * 8,
                "native_payload_nbytes_before_release": payload_nbytes,
                "after_source": after_source, "after_recipe": after_recipe,
                "after_retention": after_retention,
                "after_table_payload_release": after_table_payload_release,
                "after_clone_release": after_clone_release,
                "after_slice_release": after_slice_release,
                "after_reconstruction": after_reconstruction, "after_drop": after_drop,
                "source_construction_seconds": source_construction_seconds,
                "construction_seconds_including_checkpoint_recipe_keys": construction_seconds,
                "reconstruction_evaluation_seconds": reconstruction_evaluation_seconds,
                "reconstruction_release_seconds": reconstruction_release_seconds,
                "minimum_sampled_reconstruction_headroom_bytes": minimum_observed_headroom,
                "reconstruction_columns": reconstruction_columns,
                "original_values_compared": rows * width,
                "reconstructed_values_compared": rows * width,
                "key_rows_rechecked": rows, "reconstruction_count_per_column": 1,
                "validation_excluded_from_operation_timings": true,
                "test_metadata_outside_native_pool": true,
                "pool_peak_is_cumulative_not_reconstruction_only": true,
            }))
        })?;
    drop(session);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    record["after_session_drop"] = snapshot(&memory);
    Ok(record)
}

#[test]
#[ignore = "temporary bounded ownership screen; requires the frozen external protocol"]
fn retained_owner_observation() {
    let protocol =
        std::env::var("SHARDLOOM_REMAT_PROTOCOL_SHA256").expect("frozen protocol required");
    assert!(protocol.len() == 64 && protocol.bytes().all(|byte| byte.is_ascii_hexdigit()));
    let mut cases = Vec::new();
    for rows in [2_048, 32_768] {
        for width in [1, 8, 64] {
            for mode in [
                Mode::Derived,
                Mode::SourceAlias,
                Mode::Constant,
                Mode::DerivedKeys,
            ] {
                let case = observe_case(rows, width, mode).unwrap();
                println!(
                    "REMAT_OWNER_CASE {}",
                    json!({"protocol_sha256": protocol, "case": case})
                );
                cases.push(case);
            }
        }
    }
    let case = observe_case(32_768, 64, Mode::DerivedCloneSlice).unwrap();
    println!(
        "REMAT_OWNER_CASE {}",
        json!({"protocol_sha256": protocol, "case": case})
    );
    cases.push(case);
    assert_eq!(cases.len(), 25);
    println!(
        "REMAT_OWNER_COMPLETE {}",
        json!({"protocol_sha256": protocol, "cases": cases.len()})
    );
}
