# Retained native projection ownership screen

Status: pre-measurement design. No prototype or workload observation has run.
Prepared while PR #1530 finished integration. The corrected runtime is
`b7de216fe421012d3f9b632ad19e95f19b88dbe5`; accepted integration head
`24bd2e5bd7e2eae67a5b39d90777e46bcd71f9d0` merged as
`c16f8da71581c1b1b874aaa18aefa95a8264d0ad` after all 39 checks passed.
Production deployment, browser search and the merged report link now pass.
Freeze the accepted runtime sources and complete observation driver before
execution on the next work branch; the hosted receipt is committed separately.

This is the first evidence step for selective rematerialization under the
existing state/structure campaign and PERF-03/06/07/12. It does not reopen the
dropped directory, locality, composed-COUNT, decimal or membership prototypes.
It is not a public feature, spill implementation, query cache or speed claim.

## Question and mechanism

Does a real retained native row owner hold enough independently owned derived
payload to justify discarding and reconstructing that payload while preserving
its source, key owners, aliases and exact values?

The current projection executes every bound expression and assembles native
StructArray children. Native joins retain these arrays in Batch/Table and also
construct separate KeyColumn owners. Therefore array logical size is not a
measurement of memory that eviction can reclaim. Measure shared-pool credits
before and after releasing the relevant owner, with all dependencies alive.

Predicate truth words are transient in the current filter path. They are not
the target. Evaluating a previously unevaluated projection only after selection
would be deferred evaluation/fusion, not the proposed regeneration experiment.

## Existing provider and source boundary

- Pinned Vortex 0.85.0 native ArrayRef/StructArray/PrimitiveArray/ConstantArray
  and validity remain the representation; the session's ReservedHostAllocator
  owns source and result buffers. No Arrow or external query engine is used.
- Vortex ScalarFn arrays already represent a function with native children.
  The inspected `scalar_fn/array.rs` and `scalar_fn/vtable/mod.rs` construct that
  representation and execute its function. They do not establish ShardLoom's
  retained-table eviction policy or its error-order/credit/reconstruction proof.
  Do not replace the admitted ShardLoom expression semantics merely to use a
  deferred representation.
- `native_relational_expression.rs` evaluates the already-bound immutable
  recipe. `local_primitive_result_batch.rs::build_column` allocates native
  value/validity buffers through the supplied session allocator.
- `native_relational_batch.rs::Batch` stores its ArrayRef and private
  ReservedVec<KeyColumn>; `Table` retains Batches. `Gather::column` currently
  fetches retained fields then constructs selected native output.
- `native_relational_join.rs::build` uses those owners and RowIndex. This first
  observation examines that ownership geometry, not the performance of a join.

Provider disposition for the observation is reuse of existing admitted native
arrays and expression execution. A production eviction policy remains blocked
until measured ownership and complete workflow evidence establish its contract.

The explicit Vortex-first classification is `use_vortex_native_provider` for
the owner observation: pinned native Struct/Primitive/Constant arrays and the
existing ShardLoom expression evaluator, behind `vortex-local-primitives`.
`blocked_until_vortex_or_shardloom_evidence` applies separately to production
eviction policy. No new provider or execution support is admitted by this test.
The full original row scope materializes through the existing allocator; every
reconstructed payload is also a charged native allocation. Source and result
identity remain in the same session. No residual or external engine executes.

Pinned-source verification on October 7 confirms ScalarFn's constructor retains
its native child slots, checks arity/equal lengths and infers dtype; execution
clones those child handles and calls the bound function. Those inspected files
have no explicit cache/eviction API. The search is bounded, not an assertion about
every upstream provider. Identities:

- `vortex-array-0.85.0/src/arrays/scalar_fn/array.rs`:
  `82eb9af7af8ec9741bf2e3b36ad4b85918fe3b405764ab6c624b5bb4e68f39e0`.
- `vortex-array-0.85.0/src/arrays/scalar_fn/vtable/mod.rs`:
  `f357b2edb4649c14d0197836f811ff056d8ae9cff86dfb1fbbe4d3bc5f95d5cc`.

ShardLoom already inspects ScalarFn children for admitted provider-memory and
GetItem/Select numeric boundaries. This observation does not replace that
existing admission with arbitrary upstream deferred functions.

## Bounded observation matrix

Use a test-only observer in the existing native module. Keep production code
unchanged. Exercise 2,048 and 32,768 rows, with 1, 8 and 64 projected payload
columns, within a 256-MiB native grant. Run serially with a fixed 1-CPU session.
No file preparation or Python producer replay is part of this owner screen.

Construct two allocator-owned nullable Int64 source columns plus one non-null
ordinal key. Values use deterministic small magnitudes; every 97th value of
one input is NULL and every 89th value of the other is NULL. Keep the exact
checkpoint alive through all observation steps. Generate expected values
directly from these row formulas, independently of native scalar evaluation.

For each row count and width, include:

1. Distinct computed non-key payload, formed from the two source columns and
   a per-column small integer. Retain the ordinal as the only matching key.
2. Source aliases as the payload. Dropping the projected owner must not be
   credited with freeing source buffers that the checkpoint still owns.
3. Constant payload. Its logical size must not masquerade as reclaimed
   row-sized storage.
4. The computed payload also retained as matching keys. Keep those KeyColumn
   owners alive while dropping the projected payload to expose alias pinning.

Also include one derived-payload case with an explicit output clone and slice.
Measure after removing the table's reference, after dropping the clone and after
dropping the final slice. A remaining alias must continue to carry its credits.
Each matrix case gets a fresh session and memory pool.

This freezes 24 ordinary matrix cases and one clone/slice case at 32,768 rows
and 64 payload columns. The temporary test implementation is
`retained_owner_observation.rs` beside this draft; it is not yet applied or run.
Probe/oracle metadata is outside the native pool and excluded from memory claims.
Native buffers, actual Table/Batch/KeyColumn capacity and their existing provider
owners retain the normal accounting. The screen records logical dense value
bytes, provider `nbytes()` and live released credits as distinct measurements.
Compile the observer with the existing native library test feature set
`release-user-surfaces` in Cargo's development test profile. This matches the
current native test dependency cache and exercises the real allocator/owners;
its durations are observations, not release-binary performance comparisons.
Run exactly the ignored observer test once and inspect all 25 emitted records.
Any failing attempt remains retained; correction requires a new frozen protocol.

## Observation sequence

1. Create fully credited native source buffers. Record the pool after source
   construction and after the immutable recipe/owner metadata is constructed.
2. Evaluate every expression for every input row through the current evaluator;
   construct and retain the actual Batch/Table owner and its keys. Record live,
   peak and denied reservation counts after temporary evaluator owners drop.
3. Verify all original result values, nulls, schema and row order against the
   direct formula. Verification is excluded from operation timing.
4. Replace only the payload-bearing table ArrayRef with its key-only view.
   Keep checkpoint, recipe, actual keys and declared aliases alive. Record the
   released shared-pool credits. Preserve both the pre- and post-release states.
5. Reconstruct each discarded column exactly once from the same owned source.
   Verify every reconstructed value independently and drop each completed
   reconstructed column. Record complete reconstruction time and the minimum
   observed headroom; report the pool's cumulative peak honestly rather than
   pretending it is a separately reset reconstruction peak.
6. Recheck unchanged key hashes/equality as applicable; drop all owners,
   checkpoint and recipes. Require zero retained pool credits. Record every
   denied reservation and failed attempt.

Record source and experiment hashes, row/column counts, source/key/alias
lifetimes, logical payload bytes separately from actual released credits,
construction/reconstruction durations, full-value comparison counts and final
cleanup. Keep the complete stdout and supervisor result, including failures.
Avoid asserting an expected savings result before measuring it.

## Admission to a complete workflow experiment

This screen only establishes a possible retained owner. A production candidate
requires repeatable positive reclaimed credits after all pinned dependencies,
bounded reconstruction and complete value/ownership correctness. A non-positive
result or credit leak blocks that candidate and is retained as counterevidence.

If the owner screen passes, first freeze a complete public-workflow matrix:
projection/filter/join or ordering with competing retained state; progressively
smaller grants; and matching ample-memory, narrow, alias, constant, high-reuse,
NULL, error and cancellation controls. Compare retaining with existing native
spill only where that exact operator already supports spill. General join or
aggregate spill may not be invented as the baseline.

All potentially failing expressions must execute over their original full row
scope before eviction so an unmatched row cannot hide an error. A real policy
must preserve immutable source identity, original evaluation/error order,
exact output, keyed ownership and separately reserved reconstruction headroom.
It must impose a finite regeneration bound and avoid repeatedly rebuilding a
batch for duplicate output. One-shot producers, effects, mutable sources and
ordered aggregate state are excluded.

Complete-operation timing includes first construction, checkpoint/key costs,
eviction decisions, reconstruction and full delivery. Measure the predicted
mechanism alongside timing. A small owner-screen result cannot establish a
workflow memory improvement, a process-RSS ceiling, a ClickBench gain or a ship
decision. Freeze workflow acceptance gates before running that later experiment.

The maintainer's subsequent positive review keeps a complete stateful workflow
under constrained memory as the next major capability milestone. This bounded
ownership screen is a prerequisite decision, not a substitute for a coherent
stateful spill/recovery family. Preserve the accepted resource protections and
the measured negative controls while pursuing that milestone.

## Local execution requirements

Use the existing local-only artifact and Cargo cache locations, workload
exclusion, source freeze, bounded process-group supervisor and unchanged storage
ceilings. Resolve Cargo's target with metadata. Do not overlap native workloads,
alter an accepted evidence packet, or retire unrelated files. After the temporary
observer, prove the exact production sources are restored before another unit
uses their accepted identities.
