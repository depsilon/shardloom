"""Frozen source identities for the FSST admission integration correction."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('<SOURCE_ROOT>')
OUT = Path(__file__).resolve().parent
PYTHON = '/opt/homebrew/opt/python@3.13/bin/python3.13'

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def source_hashes():
    names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
    return {name: sha(ROOT / name) for name in sorted(set(names)) if name and (
        name.endswith(('.rs', '.py')) or Path(name).name in ('Cargo.toml', 'Cargo.lock')
        or name.startswith('vendor/'))}

def frozen():
    source = read(OUT / 'fsst-source-1.json')
    assert source_hashes() == source['source_hashes']
    assert all(sha(OUT / name) == digest for name, digest in source['helpers'].items())
    return source
