"""Bound a local build command and drain its owned POSIX process group.

This module does not execute work when imported. Callers own log paths, source
generation checks and receipts. Children that deliberately leave the process
group are outside this local Cargo/build-script supervision contract.
"""
import math
import os
import signal
import subprocess
import tempfile
import threading
import time


def _group_exists(group, evidence=None):
    # True means absence has not been proved. Permission denial cannot certify
    # either presence or absence, so cleanup must keep its bounded retry path.
    try:
        os.killpg(group, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        if evidence is not None:
            evidence['group_query_permission_denials'] = evidence.get('group_query_permission_denials', 0) + 1
    return True


def _signal_group(group, action):
    try:
        os.killpg(group, action)
    except ProcessLookupError:
        return 'absent'
    except PermissionError:
        return 'permission_denied'
    return 'sent'


def _drain(process, evidence, grace):
    # Reap the direct child before checking for remaining descendants. A leader
    # exiting is not proof that its process group has finished.
    evidence.update(process_group_drained=False, direct_child_reaped=False)
    process.poll()
    evidence['group_absence_unproved_at_cleanup'] = _group_exists(process.pid, evidence)
    for action, label in ((signal.SIGTERM, 'term'), (signal.SIGKILL, 'kill')):
        if not _group_exists(process.pid, evidence):
            break
        deadline = time.monotonic() + grace
        signal_status = 'permission_denied'
        while time.monotonic() < deadline:
            process.poll()
            if not _group_exists(process.pid, evidence):
                break
            if signal_status == 'permission_denied':
                # A denied send may become possible later. Retry within this
                # signal's original deadline only.
                signal_status = _signal_group(process.pid, action)
                evidence[label + '_last_signal_status'] = signal_status
                evidence[label + '_signal_attempts'] = evidence.get(label + '_signal_attempts', 0) + 1
                if signal_status == 'sent':
                    evidence[label + '_sent_to_group'] = True
                elif signal_status == 'permission_denied':
                    evidence[label + '_permission_denials'] = evidence.get(label + '_permission_denials', 0) + 1
            time.sleep(min(0.05, max(0, deadline - time.monotonic())))
    process.poll()
    evidence['direct_child_reaped'] = process.returncode is not None
    evidence['process_group_drained'] = not _group_exists(process.pid, evidence)
    if not evidence['direct_child_reaped'] or not evidence['process_group_drained']:
        raise RuntimeError('process group did not drain after bounded TERM/KILL cleanup')


def run(command, *, cwd, env, output, timeout, evidence, guard=None,
        max_output_bytes=8 << 20, grace=3.0, error_output=None, handle_signals=True):
    """Run with a deadline, bounded log sampling and TERM/KILL group cleanup.

    Evidence is updated even on timeout, guard failure, signal or spawn error.
    With handle_signals=True, SIGINT/SIGTERM handlers are restored after cleanup;
    a second signal cannot interrupt it. Existing watchdog threads may explicitly
    leave signal handling with their joining main thread. Kernel tasks can cause
    cleanup to fail, which is recorded and never certified as drained.
    """
    if os.name != 'posix' or (handle_signals and threading.current_thread() is not threading.main_thread()):
        raise ValueError('signal-owning process supervision requires the main POSIX thread')
    if not math.isfinite(timeout) or timeout <= 0 or not math.isfinite(grace) or grace <= 0:
        raise ValueError('deadline and cleanup grace must be finite and positive')
    if type(max_output_bytes) is not int or max_output_bytes <= 0:
        raise ValueError('output limit must be positive')
    evidence.update(timeout_seconds=timeout, cleanup_grace_seconds_per_signal=grace,
                    output_limit_bytes=max_output_bytes, timed_out=False,
                    interrupted_signal=None, process_group_drained=False,
                    direct_child_reaped=False)
    previous = ({item: signal.getsignal(item) for item in (signal.SIGINT, signal.SIGTERM)}
                if handle_signals else {})

    def interrupted(item, _frame):
        evidence['interrupted_signal'] = item
        raise KeyboardInterrupt('build supervisor received signal ' + str(item))

    def check_output():
        streams = [output] if error_output is None else [output, error_output]
        sizes = {}
        for stream in streams:
            metadata = os.fstat(stream.fileno())
            sizes[(metadata.st_dev, metadata.st_ino)] = metadata.st_size
        evidence['output_bytes'] = sum(sizes.values())
        if evidence['output_bytes'] > max_output_bytes:
            raise ValueError('command output exceeded bounded packet')

    def check_deadline():
        if time.monotonic() - started >= timeout:
            evidence['timed_out'] = True
            raise subprocess.TimeoutExpired(command, timeout)

    started = time.monotonic()
    process = None
    failure = None
    try:
        for item in previous:
            signal.signal(item, interrupted)
        if guard is not None:
            guard()
        check_deadline()
        process = subprocess.Popen(command, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                                   stdout=output,
                                   stderr=subprocess.STDOUT if error_output is None else error_output,
                                   start_new_session=True)
        evidence['pid'] = process.pid
        deadline = started + timeout
        while process.poll() is None:
            check_deadline()
            check_output()
            if guard is not None:
                guard()
            try:
                process.wait(timeout=min(0.25, max(0, deadline - time.monotonic())))
            except subprocess.TimeoutExpired:
                pass
        check_output()
        if guard is not None:
            guard()
        check_deadline()
        return process.returncode
    except BaseException as error:
        failure = error
        evidence['error'] = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        for item in previous:
            signal.signal(item, signal.SIG_IGN)
        try:
            if process is not None:
                unexpected_members = failure is None and _group_exists(process.pid, evidence)
                _drain(process, evidence, grace)
                if unexpected_members:
                    raise RuntimeError('command leader exited with live or unproved group members; group stopped')
        except BaseException as error:
            evidence['cleanup_error'] = type(error).__name__ + ': ' + str(error)
            if failure is None:
                raise
            if hasattr(failure, 'add_note'):
                failure.add_note('cleanup also failed: ' + str(error))
        finally:
            evidence['returncode'] = None if process is None else process.returncode
            evidence['seconds'] = time.monotonic() - started
            for item, handler in previous.items():
                signal.signal(item, handler)


def capture(command, *, cwd, env=None, text=False, timeout=30, directory, evidence=None,
            handle_signals=True):
    """Bound setup probes without pipe-buffer deadlocks or unbounded RAM output."""
    with tempfile.TemporaryFile(dir=directory, prefix='bounded-build-probe-') as output, \
            tempfile.TemporaryFile(dir=directory, prefix='bounded-build-probe-error-') as errors:
        status = run(command, cwd=cwd, env=env, output=output, timeout=timeout,
                     evidence={} if evidence is None else evidence, error_output=errors,
                     handle_signals=handle_signals)
        output.seek(0)
        value = output.read((8 << 20) + 1)
        errors.seek(0)
        error_value = errors.read((8 << 20) + 1)
    if status != 0:
        raise subprocess.CalledProcessError(status, command, output=value, stderr=error_value)
    return value.decode('utf-8') if text else value
