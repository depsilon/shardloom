"""Reject overlapping native workloads during this sequential release train."""
from pathlib import Path
import subprocess
import time

UAT_LOCK = Path('<USER_HOME>/LocalData/shardloom/clickbench-100m-uat/.ingest-uat.lock')


class WorkloadGuard:
    def __init__(self):
        self.last_check = 0.0
        self.owned = set()

    def check(self, owned_pid=None):
        if owned_pid is not None and time.monotonic() - self.last_check < 2:
            return
        self.last_check = time.monotonic()
        output = subprocess.check_output(
            ['ps', '-axo', 'pid=,ppid=,pgid=,rss=,comm='], text=True, timeout=10)
        rows = []
        for line in output.splitlines():
            fields = line.strip().split(None, 4)
            if len(fields) == 5:
                rows.append((*map(int, fields[:4]), fields[4]))
        if owned_pid is not None:
            self.owned.add(owned_pid)
            while True:
                children = {pid for pid, parent, group, rss, name in rows
                            if parent in self.owned or group == owned_pid}
                if children <= self.owned:
                    break
                self.owned.update(children)
        conflicts = [dict(pid=pid, executable=name)
            for pid, parent, group, rss, name in rows if pid not in self.owned and
            (Path(name).name in {'cargo', 'rustc', 'shardloom', 'pytest', 'nextest',
                                'plain_vortex_fixture', 'plain-vortex-fixture'}
             or Path(name).name.startswith(('shardloom-', 'compare-native-artifacts')))]
        assert not conflicts, 'another native build/test/query is active: ' + str(conflicts)
