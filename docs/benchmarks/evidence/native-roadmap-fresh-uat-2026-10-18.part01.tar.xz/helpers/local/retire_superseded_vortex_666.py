"""Retire only the prior accepted Vortex output after the fresh run is accepted."""
import json
from pathlib import Path
import shutil
import subprocess
import sys

O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
U=Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
sys.path[:0]=[str(O),str(R/'scripts'),'/Users/dylan/LocalData/shardloom/release-0.3.3-20260930']
from freeze_native_release_298 import save, sha, sources
from release_validation_guard import WorkloadGuard
from local_uat_storage import require_local_path

def identity(p):
    p=Path(p)
    assert p.is_file() and not p.is_symlink()
    return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))

def generation(p):
    s=Path(p).lstat()
    assert s.st_blocks*512>=s.st_size
    return dict(device=s.st_dev,inode=s.st_ino,size_bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)

current_path=O/'fresh-uat663-acceptance.json'
current=json.loads(current_path.read_text())
prior_path=O/'fresh-uat588-acceptance.json'
prior=json.loads(prior_path.read_text())
assert current['status']=='passed' and current['fresh_ingest']
assert current['queries']==current['calls']==43 and current['modular_cohorts']==18
assert current['all_values_schemas_and_clocks_reopened'] and current['native_query_children_absent']
assert current['accepted_commit']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)==''
old=U/'vortex/fresh-text-aggregation-588-a1.vortex'
new=U/'vortex/fresh-roadmap-663-a1.vortex'
require_local_path(old,Path.home(),sys.platform)
assert old.resolve()==old and new.resolve()==new and old!=new
previous=next(x for x in prior['datasets'] if x['path']==str(old))
accepted=next(x for x in current['datasets'] if x['path']==str(new))
original=next(x for x in current['datasets'] if x['path'].endswith('.parquet'))
assert generation(old)==previous['generation']
assert generation(new)==accepted['generation']
assert generation(original['path'])==original['generation']
watch=WorkloadGuard();watch.check()
assert not (U/'.ingest-uat.lock').exists()
handles=subprocess.run(['/usr/sbin/lsof','-nP',str(old),str(new)],capture_output=True,text=True,timeout=30)
assert handles.returncode==1 and not handles.stdout.strip() and not handles.stderr.strip()
old_identity=identity(old)
assert old_identity=={k:previous[k] for k in ('path','bytes','sha256')}
assert generation(old)==previous['generation']
frozen=sources()
free_before=shutil.disk_usage(U).free
record=dict(schema_version='shardloom.superseded_vortex_retirement.v1',status='prepared',
    retired=old_identity,retired_generation=previous['generation'],retained=accepted,
    original_source=original,current_acceptance=identity(current_path),prior_acceptance=identity(prior_path),
    byte_identical=old_identity['sha256']==accepted['sha256'] and old_identity['bytes']==accepted['bytes'],
    open_handle_check=dict(command=handles.args,returncode=handles.returncode,stdout=handles.stdout,stderr=handles.stderr),
    authorization='Maintainer requested cleanup and fresh UAT before the next version bump; storage policy retains only the latest accepted output.',
    free_bytes_before=free_before,helper=identity(__file__),measurements_preserved=True,storage_limits_changed=False)
save(O/'superseded-vortex-retirement-plan-666.json',record)
assert sys.argv[1:]==['--apply']
watch.check();assert generation(old)==previous['generation'] and generation(new)==accepted['generation']
old.unlink()
assert not old.exists() and generation(new)==accepted['generation']
assert generation(original['path'])==original['generation'] and sources()==frozen
record.update(status='passed',old_payload_absent=True,retained_generations_unchanged=True,
    free_bytes_after=shutil.disk_usage(U).free,plan=identity(O/'superseded-vortex-retirement-plan-666.json'))
record['observed_free_bytes_increase']=record['free_bytes_after']-free_before
save(O/'superseded-vortex-retirement-666.json',record)
print(json.dumps({k:record[k] for k in ('status','byte_identical','observed_free_bytes_increase','free_bytes_after')}))
