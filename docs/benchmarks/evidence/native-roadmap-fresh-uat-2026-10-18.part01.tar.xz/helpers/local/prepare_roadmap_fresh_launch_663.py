"""Reuse the accepted serial fresh-UAT protocol on the post-merge build."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys

O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
sys.path[:0]=[str(O),str(R/'scripts')]
from freeze_native_release_298 import save, sources
import run_zstd_metadata_acceptance_533 as common
common.SOURCE=O/'native-release-source-roadmap663.json'
common.MANIFEST=O/'native-release-artifacts-roadmap663.json'
m=common.load()
packet_path=O/'nullable-layout-hosted-packet-658/native-nullable-layout-hosted-2026-10-18.json'
packet=json.loads(packet_path.read_text())
assert packet['status']=='passed' and packet['final_tested_source_identity']
assert packet['accepted_non_test_runtime_unchanged'] and packet['checks_passed']==44
assert m['head']==packet['merge']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)==''
merged=json.loads(Path(packet['merged_sources']['path']).read_text())
assert common.identity(packet['merged_sources']['path'])==packet['merged_sources']
assert {k:v['sha256'] for k,v in merged['source_files'].items()}==m['source_sha256']==sources()
prior_public=O/'nullable-layout-public-inspection-report-650.json'
public=json.loads(prior_public.read_text())
assert public['status']=='passed' and public['cases']==4827 and public['families']==36
prior_source=json.loads(Path(public['accepted_source']['path']).read_text())
assert common.identity(public['accepted_source']['path'])==public['accepted_source']
changes={p:dict(before=before,after=m['source_sha256'][p]) for p,before in prior_source['source_sha256'].items() if before!=m['source_sha256'][p]}
assert changes==packet['test_only_source_changes']==merged['test_only_source_changes']
assert set(changes)=={'vendor/vortex-file/src/lib.rs','vendor/vortex-file/src/tests.rs','vendor/vortex-layout/src/layouts/struct_/reader/tests/nullable.rs'}
bridge=O/'roadmap-public-source-bridge-663.json'
save(bridge,dict(status='passed',cases=4827,families=36,accepted_source=common.identity(common.SOURCE),
    artifact_manifest=common.identity(common.MANIFEST),prior_public_inspection=common.identity(prior_public),
    prior_public_source=public['accepted_source'],prior_public_artifacts=public['artifact_manifest'],
    hosted_merge_packet=common.identity(packet_path),merged_sources=packet['merged_sources'],
    test_only_source_changes=changes,accepted_non_test_runtime_unchanged=True,
    public_acceptance_reexecuted=False,scope='Prior complete public acceptance remains bound to build 650-a1. The final hosted/test bridge changes only cfg(test) fixtures/imports; the fresh ingest/Full43/modular run uses a new build of the exact merged source.'))
template_path=O/'text-aggregation-fresh-launch-588.json'
assert common.identity(template_path)['sha256']=='446375859e3c75dc6c78eaa4a3ae47ba8be7b9ac5c59061e5469e04c12cee894'
template=json.loads(template_path.read_text())
programs={}
changes_text=[
    ('native-release-source-textaggregation588.json','native-release-source-roadmap663.json'),
    ('native-release-artifacts-textaggregation588.json','native-release-artifacts-roadmap663.json'),
    ('text-aggregation-public-inspection-report-588.json','roadmap-public-source-bridge-663.json'),
    ('text-aggregation-fresh-launch-588.json','roadmap-fresh-launch-663.json'),
    ('fresh-uat588','fresh-uat663'),
    ('fresh-uat579','fresh-uat588'),
    ('fresh-text-aggregation-588-a1.vortex','fresh-roadmap-663-a1.vortex'),
    ('file-metadata-full43-admission-573.json','nullable-layout-full43-admission-650.json'),
    ("'--prefix':'fresh-text-aggregation','--attempt':'588'","'--prefix':'fresh-roadmap','--attempt':'663'"),
    ('fresh-text-aggregation-matrix-588-report.json','fresh-roadmap-matrix-663-report.json'),
]
for key in ('plan_source','runner_source'):
    source=template[key]
    assert hashlib.sha256(source.encode()).hexdigest()==template[key+'_sha256']
    for old,new in changes_text:
        source=source.replace(old,new)
    if key=='plan_source':
        source=source.replace('public_inspection=common.identity(public_path),launch=',
            'public_inspection=common.identity(public_path),public_acceptance_reexecuted=False,launch=')
    ast.parse(source)
    programs[key]=source
    programs[key+'_sha256']=hashlib.sha256(source.encode()).hexdigest()
launch=O/'roadmap-fresh-launch-663.json'
save(launch,dict(status='prepared_not_executed',program_file_created=False,template=common.identity(template_path),
    substitutions=changes_text,public_source_bridge=common.identity(bridge),generator=common.identity(__file__),**programs))
subprocess.run([sys.executable,'-B','-'],input=programs['plan_source'],text=True,cwd=R,check=True)
plan=json.loads((O/'fresh-uat663-plan.json').read_text())
assert plan['expected_calls']==43 and plan['repeats']==1 and plan['expected_modular_cohorts']==18
assert plan['target'].endswith('/fresh-roadmap-663-a1.vortex') and not plan['public_acceptance_reexecuted']
assert plan['prior_acceptance']==common.identity(O/'fresh-uat588-acceptance.json')
assert plan['commands']['modular'][-1]=='663'
assert common.load()==m
print(json.dumps(dict(status='predeclared',merge=m['head'],calls=43,modular_cohorts=18,launch=common.identity(launch))))
