"""Retire only the completed debug compiler tree after PR 1574 is sealed."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
from datetime import datetime, timezone

O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
CACHE=Path('/Users/dylan/.cache/shardloom/cargo-target')
DEBUG=CACHE/'debug'
sys.path[:0]=[str(O),str(R/'scripts'),'/Users/dylan/LocalData/shardloom/release-0.3.3-20260930']
from freeze_native_release_298 import sha, sources, save
from local_uat_storage import require_local_path
from release_validation_guard import WorkloadGuard

def identity(path):
    path=Path(path)
    assert path.is_file() and not path.is_symlink()
    return dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path))

def generation(path):
    s=path.lstat()
    return dict(device=s.st_dev,inode=s.st_ino,mode=s.st_mode,bytes=s.st_size,
                blocks=s.st_blocks,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)

def inventory(root):
    assert root.is_dir() and not root.is_symlink()
    records=[]
    for base,dirs,files in os.walk(root,followlinks=False):
        for name in sorted(dirs+files):
            p=Path(base)/name
            item=dict(path=p.relative_to(root).as_posix(),**generation(p))
            if p.is_symlink(): item['link']=os.readlink(p)
            records.append(item)
    return sorted(records,key=lambda row:row['path'])

def no_handles():
    p=subprocess.run(['/usr/sbin/lsof','-nP','+D',str(DEBUG)],capture_output=True,text=True,timeout=50)
    assert p.returncode==1 and not p.stdout.strip() and not p.stderr.strip(), (p.returncode,p.stdout,p.stderr)
    return dict(command=p.args,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)

packet_path=O/'nullable-layout-hosted-packet-658/native-nullable-layout-hosted-2026-10-18.json'
packet=json.loads(packet_path.read_text())
assert packet['status']=='passed' and packet['pr']==1574 and packet['checks_passed']==44
assert packet['final_tested_source_identity'] and packet['accepted_non_test_runtime_unchanged']
assert identity(packet['archive']['path'])==packet['archive']
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head==packet['merge']
assert subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)==''
require_local_path(DEBUG,Path.home(),sys.platform)
assert DEBUG.resolve()==Path('/Users/dylan/.cache/shardloom/cargo-target/debug')
env=dict(os.environ,CARGO_TARGET_DIR=str(CACHE))
metadata=json.loads(subprocess.check_output(['/Users/dylan/.cargo/bin/rustup','run','1.99.0','cargo','metadata','--offline','--locked','--no-deps','--format-version','1'],cwd=R,env=env))
assert metadata['target_directory']==str(CACHE)
watch=WorkloadGuard();watch.check()
handles=no_handles()
frozen=sources()
expected=json.loads((O/'native-release-source-nullable657a4.json').read_text())['source_sha256']
assert frozen==expected
artifacts=json.loads((O/'native-release-artifacts-nullable650a1.json').read_text())
retained=[identity(artifacts[key]['path']) for key in ('cli','binding')]
for item,key in zip(retained,('cli','binding')):
    assert item=={k:artifacts[key][k] for k in ('path','bytes','sha256')}
datasets=[Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat/sources/hits.parquet'),
          Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat/vortex/fresh-text-aggregation-588-a1.vortex')]
dataset_state=[dict(path=str(p),generation=generation(p)) for p in datasets]
for item in dataset_state:
    assert stat.S_ISREG(item['generation']['mode']) and item['generation']['blocks']*512>=item['generation']['bytes']
before=inventory(DEBUG)
release_before=inventory(CACHE/'release')
free_before=shutil.disk_usage(CACHE).free
record=dict(schema_version='shardloom.scoped_debug_cache_cleanup.v1',status='prepared',
    recorded_at=datetime.now(timezone.utc).isoformat(),merge=head,hosted_packet=identity(packet_path),
    target=str(DEBUG),target_generation=generation(DEBUG),members=before,
    regular_file_bytes=sum(x['bytes'] for x in before if stat.S_ISREG(x['mode'])),
    allocated_member_bytes=sum(x['blocks']*512 for x in before),free_bytes_before=free_before,
    retained_artifacts=retained,retained_datasets=dataset_state,open_handle_check=handles,
    source_files=len(frozen),release_metadata_sha256=hashlib.sha256(json.dumps(release_before,sort_keys=True).encode()).hexdigest(),
    authorization='October 18 maintainer requested cleanup after the current PR and before fresh UAT.',
    disposal_reason='Completed rebuildable compiler outputs only; current frozen executables, source/result/failure evidence, inputs, latest accepted output and the release cache remain.',
    helper=identity(__file__))
save(O/'debug-cache-cleanup-plan-662.json',record)
assert sys.argv[1:]==['--apply'], 'explicit --apply required; no deletion performed'
watch.check();assert inventory(DEBUG)==before
assert no_handles()==handles
assert sources()==frozen
shutil.rmtree(DEBUG)
assert not DEBUG.exists()
assert inventory(CACHE/'release')==release_before
assert sources()==frozen
assert [identity(item['path']) for item in retained]==retained
assert [dict(path=str(p),generation=generation(p)) for p in datasets]==dataset_state
assert subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)==''
watch.check()
record.update(status='passed',target_absent=True,release_cache_unchanged=True,source_unchanged=True,
              retained_artifacts_unchanged=True,retained_datasets_unchanged=True,
              free_bytes_after=shutil.disk_usage(CACHE).free)
record['observed_free_bytes_increase']=record['free_bytes_after']-free_before
record['members_manifest']=identity(O/'debug-cache-cleanup-plan-662.json')
del record['members']
save(O/'debug-cache-cleanup-662.json',record)
print(json.dumps({k:record[k] for k in ('status','target','regular_file_bytes','allocated_member_bytes','observed_free_bytes_increase','free_bytes_after')}))
