"""Reopen fresh UAT results, clocks, native certificates and independent cohorts."""
import csv
from decimal import Decimal
import gzip
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
U = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
sys.path[:0] = [str(O), str(R/'scripts'), str(R/'benchmarks/traditional_analytics'),
    '/Users/dylan/LocalData/shardloom/release-0.3.3-20260930']
from freeze_native_release_298 import save, sha, sources
from clickbench_reference_packet import load_reference_packet
from native_workflow_protocol import extract_result, report_fields, strict_json
from query_timing_report import query_phase_timings, timing_totals, TIMING_METRICS
from run_clickbench_query_uat import equivalent, score
from check_benchmark_artifact_completeness import validate_manifest
from release_validation_guard import WorkloadGuard
from local_uat_storage import require_local_path, check_budgets, GIB, MIB
import run_zstd_metadata_acceptance_533 as common
common.SOURCE = O/'native-release-source-roadmap663.json'
common.MANIFEST = O/'native-release-artifacts-roadmap663.json'
identity = common.identity
read = lambda p: strict_json(Path(p).read_text())


def check(ref):
    assert identity(ref['path']) == ref, ref['path']
    return Path(ref['path'])


def generation(path):
    path = Path(path)
    require_local_path(path, Path.home(), sys.platform)
    s = path.lstat()
    assert stat.S_ISREG(s.st_mode) and not path.is_symlink()
    assert not s.st_flags & getattr(stat, 'SF_DATALESS', 0x40000000)
    assert s.st_blocks * 512 >= s.st_size
    return dict(device=s.st_dev, inode=s.st_ino, size_bytes=s.st_size,
        mtime_ns=s.st_mtime_ns, ctime_ns=s.st_ctime_ns)


manifest = common.load()
plan_path = O/'fresh-uat663-plan.json'
plan = read(plan_path)
plan_identity = identity(plan_path)
assert manifest['head'] == '6780e7df564c55f3e256822be1d0383cfabff0c9'
assert plan['source'] == identity(common.SOURCE) and plan['artifacts'] == identity(common.MANIFEST)
assert not plan['public_acceptance_reexecuted']
build = read(check(plan['build']))
assert build['working_tree'] == ''
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=R, text=True) == ''
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == manifest['head']
for ref in [plan[k] for k in ('prior_acceptance','reference','queries','guard','modular_runner',
        'host_sampler','public_inspection','launch')] + plan['schema_sources'] + plan['harness']:
    check(ref)
state_path = O/'fresh-uat663-run-state.json'
state = read(state_path)
assert state['status'] == 'passed_workflows_pending_independent_verification'
assert state['plan'] == plan_identity and state['host_sampler_stopped'] and not state['host_errors']
check(state['host_observations'])
assert [x['stage'] for x in state['stages']] == ['ingest', 'full43', 'modular']
for stage in state['stages']:
    check(stage['summary']); check(stage['receipt'])
    receipt = common.receipt(stage['receipt']['path'])
    assert receipt['command'] == plan['commands'][stage['stage']]
watch = WorkloadGuard(); watch.check()
assert not (U/'.ingest-uat.lock').exists()
target = Path(plan['target'])
target_generation = generation(target)
source = Path(plan['expected_parquet']['path'])
assert generation(source) == plan['expected_parquet']['generation']
admission = read(O/'fresh-uat663-admission.json')
assert admission['plan'] == plan_identity and admission['target'] == str(target)
assert admission['input']['sha256'] == plan['expected_parquet']['sha256']

ingest_location = read(O/'fresh-uat663-ingest-location.json')
ingest_path = check(ingest_location['summary'])
ingest = read(ingest_path)
assert ingest['returncode'] == 0 and ingest['stdout_json_ok'] and ingest['target_exists']
assert ingest['target'] == str(target) and ingest_location['target_generation'] == target_generation
ingest_stdout = Path(ingest['stdout_path'])
ingest_envelope = read(ingest_stdout)
assert ingest_envelope['status'] == 'success'
assert ingest_envelope['fallback']['attempted'] is False and ingest_envelope['fallback']['allowed'] is False
ingest_fields = report_fields(ingest_envelope)
for name in ('validation_rows', 'projection_rows'):
    assert ingest_fields['public_workflow_preparation_vortex_ingest_stream_' + name] == '99997497'
for key, value in ingest_fields.items():
    if key.endswith(('fallback_attempted', 'external_engine_invoked')):
        assert value == 'false' or value is False

location = read(O/'fresh-uat663-full43-location.json')
summary_path = check(location['summary'])
report = read(summary_path)
assert report['build_commit'] == manifest['head'] and report['binary_sha256'] == manifest['cli']['sha256']
assert report['source'] == str(target) and report['source_generation'] == target_generation == location['target_generation']
for key in ('complete', 'full_result_validation', 'completed_identity_check',
        'reference_packet_identity_verified', 'harness_identity_verified', 'engine_timing_required'):
    assert report[key] is True, key
assert report['reference_kind'] == 'retained_native_regression'
assert report['reference_packet']['sha256'] == plan['reference']['sha256']
assert report['queries_sha256'] == plan['queries']['sha256']
assert report['harness_sha256'] == {x['path']:x['sha256'] for x in plan['harness']}
assert report['memory_gb'] == 24 and report['max_parallelism'] == 12
assert report['log_budget_bytes'] == dict(retained=1024*MIB, active_run=256*MIB)
assert report['selected_query_ids'] == list(range(1,44)) and len(report['records']) == 43
assert report['repeats'] == 1 and report['hot_total_seconds'] is None and report['hot_geomean_seconds'] is None
assert {(x['query'],x['run']) for x in report['records']} == {(q,1) for q in range(1,44)}
reference = load_reference_packet(Path(plan['reference']['path']), Path(plan['queries']['path']))
schema_records = [read(x['path']) for x in plan['schema_sources']]
schemas = {int(q):tuple(schema) for source_record in schema_records
    for q,schema in source_record['expected_schemas'].items()}
assert set(schemas) == set(range(1,44))
rows, companions, envelopes, nanos, engine_times = 0, [], [], 0, []
for record in report['records']:
    query = record['query']
    assert record['passed'] and record['validation'] == 'complete_values'
    assert record['returncode'] == 0 and not record['guard_failures']
    command = record['command']
    assert command[0] == manifest['cli']['path']
    assert command[command.index('--input')+1] == str(target)
    prefix = summary_path.parent / f'q{query:02d}_run1'
    timing_path = prefix.with_suffix('.timing.json')
    timing = read(timing_path)
    assert timing['returncode'] == 0
    for key in ('seconds','user_cpu_seconds','system_cpu_seconds'):
        assert timing[key] == record[key]
    assert timing['peak_rss_bytes'] == record['native_peak_rss_bytes']
    pid_path = prefix.with_suffix('.pid')
    try:
        os.kill(int(pid_path.read_text()), 0)
    except ProcessLookupError:
        pass
    else:
        raise AssertionError(f'Native query PID remains: {pid_path}')
    companions += [identity(timing_path), identity(pid_path)]
    envelope = None
    for packed in record['completed_log_archives']:
        payload = Path(packed['path']).read_bytes()
        assert len(payload) == packed['gzip_bytes'] and hashlib.sha256(payload).hexdigest() == packed['gzip_sha256']
        raw = gzip.decompress(payload)
        assert len(raw) == packed['raw_bytes'] and hashlib.sha256(raw).hexdigest() == packed['raw_sha256']
        envelopes.append(identity(packed['path']))
        if packed['path'].endswith('.stdout.json.gz'):
            assert envelope is None
            envelope = strict_json(raw.decode())
    assert envelope is not None
    fields = report_fields(envelope)
    for key,value in query_phase_timings(fields,timing['seconds']).items():
        assert record[key] == value, (query,key)
    assert fields['execution_resource_declared_memory_bytes'] == str(24*GIB)
    assert fields['execution_resource_declared_max_parallelism'] == '12'
    assert fields['execution_resource_whole_process_memory_limit_enforced'] == 'false'
    for key,value in fields.items():
        if key.endswith(('fallback_attempted','fallback_execution_allowed','external_engine_invoked')):
            assert value == 'false' or value is False, (query,key)
    assert any(c['kind']=='native_io_certificate' and c['status']=='available' for c in envelope['certificates'])
    actual = extract_result(envelope)
    assert equivalent(actual,reference['values'][query])
    assert hashlib.sha256(json.dumps(actual,sort_keys=True,allow_nan=False).encode()).hexdigest() == record['result_sha256']
    assert (fields['result_schema_format'],strict_json(fields['result_schema_json'])) == schemas[query]
    rows += len(actual)
    nanos += int(fields['native_query_execution_nanos'])
    engine_times.append(dict(query=query,engine_execution_seconds=record['engine_execution_seconds']))
assert rows == 381 and len(envelopes) == 43 and len(companions) == 86
for key,value in score(report['records'],43,repeats=1,timing_key='engine_execution_seconds').items():
    assert report[key] == value, key
assert report['secondary_process_wall'] == score(report['records'],43,repeats=1)
assert report['timing_totals'] == timing_totals(report['records'])
csv_path = summary_path.parent/'query-timings.csv'
with csv_path.open(newline='') as stream:
    csv_rows = list(csv.DictReader(stream))
assert len(csv_rows) == 43
for row,record in zip(csv_rows,report['records']):
    assert int(row['query']) == record['query'] and int(row['run']) == 1
    assert row['passed'] == row['engine_timing_reported'] == 'True'
    for key in TIMING_METRICS:
        assert float(row[key]) == record[key], (record['query'],key)

matrix_path = O/'fresh-timed-uat-461/fresh-roadmap-matrix-663-report.json'
matrix = read(matrix_path)
assert matrix['status'] == 'passed' and matrix['records'] == 1408 and matrix['native_records'] == 704
assert len(matrix['cohorts']) == 18
assert not matrix['performance_claim'] and not matrix['complete_cartesian_input_output_coverage_claimed']
assert matrix['binary'] == manifest['cli']['path'] and matrix['binary_sha256'] == manifest['cli']['sha256']
assert matrix['runtime_commit'] == matrix['harness_commit'] == manifest['head']
assert not matrix['changed_metadata_test_only']
assert matrix['build_manifest_sha256'] == plan['build']['sha256']
assert matrix['driver_sha256'] == plan['modular_runner']['sha256']
cohorts = []
for cohort in matrix['cohorts']:
    assert cohort['receipt']['returncode'] == 0 and not cohort['receipt']['guard_failures']
    assert cohort['independently_reopened']
    path = Path(cohort['report'])
    assert identity(path)['sha256'] == cohort['report_sha256']
    assert identity(cohort['stdout'])['sha256'] == cohort['stdout_sha256']
    stderr = Path(cohort['stdout']).with_name(Path(cohort['stdout']).name.replace('.stdout.json','.stderr.txt'))
    assert identity(stderr)['sha256'] == cohort['stderr_sha256']
    blockers,observed = validate_manifest(path)
    assert not blockers, blockers
    assert len(observed['records']) == cohort['observed_records']
    assert sum(x['engine']=='shardloom' for x in observed['records']) == cohort['native_records']
    assert sum(x['engine']=='pandas' for x in observed['records']) == cohort['native_records']
    cohorts.append(dict(report=identity(path),stdout=identity(cohort['stdout']),stderr=identity(stderr),
        records=len(observed['records']),native_records=cohort['native_records'],
        input_state=cohort['input_state'],inputs=cohort['formats'],output=cohort['output_format']))
assert sum(x['native_records'] for x in cohorts) == 704
watch.check()
print(json.dumps(dict(stage='final-dataset-identity',status='starting')),flush=True)
datasets = []
for path,expected in [(source,plan['expected_parquet']['generation']),(target,target_generation)]:
    assert generation(path) == expected
    ref = identity(path)
    assert generation(path) == expected
    datasets.append(dict(**ref,generation=expected,resident=True))
assert datasets[0]['sha256'] == plan['expected_parquet']['sha256']
assert sources() == manifest['source_sha256'] and common.load() == manifest
assert identity(plan_path) == plan_identity
assert subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True) == ''
assert not (U/'.ingest-uat.lock').exists()
watch.check()
storage = check_budgets(U,target,summary_path.parent,min_free_bytes=12*GIB,reserve_bytes=0,
    max_workspace_bytes=100*GIB,max_log_bytes=1024*MIB,max_run_log_bytes=256*MIB)
ingest_storage = check_budgets(U,target,ingest_path.parent,min_free_bytes=12*GIB,reserve_bytes=0,
    max_workspace_bytes=100*GIB,max_log_bytes=1024*MIB,max_run_log_bytes=256*MIB)
acceptance = dict(schema_version='shardloom.native_roadmap_fresh_uat.v1',status='passed',
    accepted_commit=manifest['head'],source=identity(common.SOURCE),artifact_manifest=identity(common.MANIFEST),
    source_files_verified=len(manifest['source_sha256']),source_identity_preserved=True,
    fresh_ingest=True,ingest_rows=99997497,ingest_summary=identity(ingest_path),ingest_stdout=identity(ingest_stdout),
    queries=43,calls=43,repeats=1,complete_rows=rows,query_summary=identity(summary_path),timing_csv=identity(csv_path),
    engine_execution_seconds=str(Decimal(nanos)/Decimal(1_000_000_000)),engine_execution_nanos=nanos,
    engine_times=engine_times,all_values_schemas_and_clocks_reopened=True,
    resources_no_fallback_native_certificates=True,native_query_children_absent=True,
    modular_report=identity(matrix_path),modular_cohorts=18,native_workflows=704,
    independent_pandas_oracle_records=704,cohort_reports=cohorts,
    modular_scope='Eight inputs with collect and CSV input to eight outputs; raw/prepared; 22 workflows.',
    complete_cartesian_input_output_coverage_claimed=False,datasets=datasets,
    receipts=[x['receipt'] for x in state['stages']],envelopes=envelopes,companions=companions,
    performance_claim=False,reference_kind='retained_native_regression',publication_attempted=False,
    run_state=identity(state_path),plan=plan_identity,host_observations=state['host_observations'],
    host_sampler_stopped=True,storage=storage,ingest_storage=ingest_storage,verifier=identity(__file__),
    postrun_verifier_correction=identity(O/'fresh-uat663-verifier-correction.json'),
    public_source_bridge=plan['public_inspection'],public_acceptance_reexecuted=False,
    verification_note='Every complete Full43 output, schema, certificate, timing/PID companion and CSV was reopened. Each modular manifest was independently validated; complete dataset hashes preserve stable resident generations. No execution was repeated by this verifier.')
save(O/'fresh-uat663-acceptance.json',acceptance)
print(json.dumps(dict(status='passed',queries=43,complete_rows=rows,modular_cohorts=18,
    engine_execution_seconds=acceptance['engine_execution_seconds'])),flush=True)
