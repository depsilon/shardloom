"""Preserve compact fresh-UAT evidence without retaining obsolete bulk payloads."""
import ast
import hashlib
import json
import lzma
from pathlib import Path
import sys
import tarfile

O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
sys.path[:0]=[str(O),str(R/'scripts')]
from freeze_native_release_298 import sha, save, sources
from package_selection_acceptance_409 import Members, verify, sha_stream
from local_uat_storage import require_local_path, check_budgets, GIB, MIB
import run_zstd_metadata_acceptance_533 as common
common.SOURCE=O/'native-release-source-roadmap663.json'
common.MANIFEST=O/'native-release-artifacts-roadmap663.json'
identity=common.identity
read=lambda p:json.loads(Path(p).read_text())
accept_path=O/'fresh-uat663-acceptance.json'
accepted=read(accept_path)
build=common.load()
assert accepted['status']=='passed' and accepted['accepted_commit']==build['head']
assert accepted['all_values_schemas_and_clocks_reopened'] and accepted['source_identity_preserved']
assert accepted['calls']==43 and accepted['modular_cohorts']==18
assert accepted['native_workflows']==accepted['independent_pandas_oracle_records']==704
plan=read(accepted['plan']['path'])
retirement=read(O/'superseded-vortex-retirement-666.json')
assert retirement['status']=='passed' and retirement['current_acceptance']==identity(accept_path)
cleanup=read(O/'debug-cache-cleanup-662.json')
assert cleanup['status']=='passed' and cleanup['source_unchanged']
dest=require_local_path(O/'roadmap-fresh-evidence-667',Path.home(),sys.platform)
assert not dest.exists()
check_budgets(O,dest,O/'logs',min_free_bytes=12*GIB,reserve_bytes=512*MIB,
    max_workspace_bytes=100*GIB,max_log_bytes=192*MIB)
members,aliases,exclusions=Members(),{},[]

def add(path,name,role,expected=None):
    path=Path(path)
    root=R if path.is_relative_to(R) else O if path.is_relative_to(O) else path.parent
    item=members.add(path,name,root.name,root,role,expected)
    if item.name!=name: aliases[name]=item.name
    return item

def bound(ref,prefix,role):
    assert identity(ref['path'])==ref
    path=Path(ref['path'])
    rel=('repo/'+path.relative_to(R).as_posix() if path.is_relative_to(R)
        else 'local/'+path.relative_to(O).as_posix() if path.is_relative_to(O)
        else 'external/'+path.as_posix().lstrip('/'))
    return add(path,prefix+'/'+rel,role,ref['sha256'])

for name,digest in build['source_sha256'].items():
    add(R/name,'runtime-source/'+name,'exact merged runtime source',digest)
for path in sorted(O.iterdir()):
    if path.is_file() and (path.name.startswith(('fresh-uat663-',
        'native-final-cli-release-build-roadmap663','native-final-python-release-build-roadmap663',
        'native-release-source-roadmap663','native-release-artifacts-roadmap663',
        'roadmap-public-source-bridge-663','roadmap-fresh-launch-663',
        'debug-cache-cleanup-','superseded-vortex-retirement-'))):
        add(path,'receipts/'+path.name,'fresh execution, source binding and scoped cleanup')
for key in ('reference','queries','prior_acceptance','public_inspection','launch','build'):
    bound(plan[key],'protocol','frozen protocol input')
for ref in plan['schema_sources']+plan['harness']:
    bound(ref,'protocol','frozen schema and harness')
members.tree(Path(accepted['query_summary']['path']).parent,'full43','full43',
    'all complete query outputs and clocks',exclusions)
members.tree(Path(accepted['ingest_summary']['path']).parent,'fresh-ingest','fresh-ingest',
    'fresh ingest validation and source/output identity',exclusions)
mod=O/'fresh-timed-uat-461'
members.tree(mod/'fresh-roadmap-matrix-663','modular','modular',
    'complete native and independent-oracle cohorts',exclusions)
for p in sorted(mod.glob('fresh-roadmap-matrix-663-*')):
    if p.is_file():add(p,'modular-receipts/'+p.name,'all modular cohort receipts')
helpers=[Path(__file__),O/'prepare_roadmap_fresh_launch_663.py',
    O/'verify_roadmap_fresh_uat_663.py',O/'retire_completed_debug_cache_662.py',
    O/'retire_superseded_vortex_666.py',O/'freeze_native_release_298.py',O/'run_guarded.py',
    O/'run_query_timing_runtime_461.py',O/'run_zstd_metadata_acceptance_533.py',
    O/'package_selection_acceptance_409.py',mod/'run_modular_acceptance.py',
    R/'scripts/run_clickbench_ingest_uat.sh',R/'scripts/build_native_python.py',
    Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'),
    Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')]
seen=set()
while helpers:
    p=helpers.pop().resolve()
    if p in seen:continue
    seen.add(p)
    rel=('repo/'+p.relative_to(R).as_posix() if p.is_relative_to(R)
        else 'local/'+p.relative_to(O).as_posix() if p.is_relative_to(O)
        else 'external/'+p.as_posix().lstrip('/'))
    add(p,'helpers/'+rel,'reproduction helper and local import closure')
    if p.suffix=='.py':
        for node in ast.walk(ast.parse(p.read_text())):
            roots=[]
            if isinstance(node,ast.Import):roots=[a.name.split('.')[0] for a in node.names]
            elif isinstance(node,ast.ImportFrom) and node.module:roots=[node.module.split('.')[0]]
            for name in roots:
                for base in (p.parent,O):
                    candidate=base/(name+'.py')
                    if candidate.is_file() and candidate.resolve() not in seen:helpers.append(candidate)
bridge=read(plan['public_inspection']['path'])
for key in ('prior_public_inspection','prior_public_source','prior_public_artifacts','hosted_merge_packet','merged_sources'):
    bound(bridge[key],'prior-proof','separately identified prior public acceptance and hosted source bridge')
ordered=sorted(members.paths.values(),key=lambda x:x.name)
raw_bytes=sum(x.size for x in ordered)
partitions=[]
pending=[]
pending_bytes=0
for item in ordered:
    assert item.size<=128*MIB,(item.name,item.size)
    if pending and pending_bytes+item.size>128*MIB:
        partitions.append(pending);pending=[];pending_bytes=0
    pending.append(item);pending_bytes+=item.size
if pending:partitions.append(pending)
assert sum(len(p) for p in partitions)==len(ordered)
assert all(sum(i.size for i in p)<=128*MIB for p in partitions)
dest.mkdir()
stem='native-roadmap-fresh-uat-2026-10-18'
archives=[]
member_parts={}
for number,partition in enumerate(partitions,1):
    archive=dest/(stem+f'.part{number:02d}.tar.xz')
    with tarfile.open(archive,'x:xz') as bundle:
        for item in partition:
            verify(item.path,item.digest,item.size)
            bundle.add(item.path,arcname=item.name,recursive=False)
            member_parts[item.name]=archive.name
    assert archive.stat().st_size<=100*MIB
    with tarfile.open(archive,'r:xz') as bundle:
        entries=bundle.getmembers()
        assert len(entries)==len(partition)==len({x.name for x in entries})
        for item in partition:
            member=bundle.getmember(item.name)
            assert member.isfile() and member.size==item.size
            with bundle.extractfile(member) as stream:
                assert sha_stream(stream)==(item.size,item.digest)
            verify(item.path,item.digest,item.size)
    archives.append(dict(**identity(archive),members=len(partition),raw_bytes=sum(i.size for i in partition)))
    print(json.dumps(dict(stage='archive-verified',part=number,members=len(partition))),flush=True)
assert sum(x['bytes'] for x in archives)<=100*MIB
assert common.load()==build and sources()==build['source_sha256']
manifest=dict(schema_version='shardloom.native_roadmap_fresh_uat_evidence.v1',
    status='passed_local_evidence_packaged',source_commit=build['head'],source_files=2416,
    source_manifest=identity(common.SOURCE),artifact_manifest=identity(common.MANIFEST),
    acceptance=identity(accept_path),member_count=len(ordered),raw_bytes=raw_bytes,
    archives=archives,members=[dict(path=str(x.path),archive_path=x.name,
        archive_part=member_parts[x.name],bytes=x.size,sha256=x.digest,roles=x.roles) for x in ordered],archive_aliases=aliases,
    excluded_fixture_payloads=exclusions,bulk_dataset_identities=accepted['datasets'],
    executable_identities={k:{n:build[k][n] for n in ('path','bytes','sha256')} for k in ('cli','binding')},
    all_members_reopened=True,source_identity_preserved=True,
    full43_engine_seconds=accepted['engine_execution_seconds'],fresh_ingest_rows=99997497,
    full43_calls=43,modular_cohorts=18,native_workflows=704,independent_oracle_records=704,
    public_acceptance_reexecuted=False,performance_claim=False,publication_attempted=False,
    debug_cleanup=identity(O/'debug-cache-cleanup-662.json'),
    superseded_output_cleanup=identity(O/'superseded-vortex-retirement-666.json'),
    limitations=['One complete Full43 observation; retained-native regression reference, no comparative speedup.',
        'Pandas appears only as the independent modular correctness oracle.',
        'Public 4827-case acceptance is inherited through the explicit test-only source bridge, not rerun.',
        'Bulk datasets, native binaries and fixture binary payloads are excluded with exact identities; regenerate from the archived sources and commands.',
        'No full input/output Cartesian-product, whole-process RSS, competitive, production-readiness or package-release claim.'])
manifest_path=dest/(stem+'.manifest.json.xz')
with lzma.open(manifest_path,'xt',encoding='utf-8') as stream:
    json.dump(manifest,stream,indent=2);stream.write('\n')
with lzma.open(manifest_path,'rt',encoding='utf-8') as stream:assert json.load(stream)==manifest
index={k:v for k,v in manifest.items() if k not in ('members','excluded_fixture_payloads','archive_aliases')}
index['archives']=[dict(file=Path(x['path']).name,**{k:x[k] for k in ('bytes','sha256','members','raw_bytes')}) for x in archives]
index['manifest']={k:identity(manifest_path)[k] for k in ('bytes','sha256')}
index['manifest']['file']=manifest_path.name
index['excluded_fixture_payload_count']=len(exclusions)
save(dest/(stem+'.json'),index)
print(json.dumps(dict(status='passed',members=len(ordered),raw_bytes=raw_bytes,
    archives=len(archives),archive_bytes=sum(x['bytes'] for x in archives),index=str(dest/(stem+'.json')))))
