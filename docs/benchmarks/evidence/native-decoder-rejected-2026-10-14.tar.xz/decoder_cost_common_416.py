"""Shared immutable identities for the finite decoder cost comparison."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sha, sources, save

DEST = OUT / 'decoder-cost-416'
BASE = '22b2cde04973ce4462517d73fe67b5f7a1e8177c'
TEST = 'native_provider_memory::builder_tests::decoder_cost::native_decoder_lifecycle_cost_sample'
OVERLAY = tuple('shardloom-vortex/src/' + name for name in (
    'native_provider_memory.rs', 'native_provider_fixed_width_builder.rs'))
HARNESS = tuple('shardloom-vortex/src/' + name for name in (
    'native_provider_builder_cost.rs', 'native_provider_builder_tests.rs',
    'native_provider_memory_tests.rs', 'native_provider_decoder_cost.rs'))
NEW_RUNTIME = tuple('shardloom-vortex/src/' + name for name in (
    'native_provider_decoder_scratch.rs', 'native_provider_decoder_scratch_tests.rs'))
HELPERS = ('decoder_cost_common_416.py', 'decoder_cost_build_416.py',
           'decoder_cost_run_416.py', 'decoder_cost_analyze_416.py',
           'run_guarded.py', 'freeze_native_release_298.py')


def read(path):
    return json.loads(Path(path).read_text())


def identity(mapping):
    return hashlib.sha256(json.dumps(mapping, sort_keys=True).encode()).hexdigest()


def head():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()


def bound(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def contract():
    return read(DEST / 'contract.json')


def frozen(variant='candidate'):
    record = read(DEST / 'source.json')
    assert head() == record['head'] == BASE
    assert sha(DEST / 'contract.json') == record['contract_sha256']
    assert all(sha(OUT / name) == digest for name, digest in record['helpers'].items())
    assert sources() == record[variant + '_source_sha256'], 'source changed after freeze'
    return record


def storage(logs, reserve=128 << 20, *, cohort=False):
    sys.path.insert(0, str(ROOT / 'scripts'))
    from local_uat_storage import GIB, MIB, check_budgets, require_local_path
    require_local_path(DEST, Path.home(), sys.platform)
    return check_budgets(OUT, DEST / 'reserved-artifact', logs,
        min_free_bytes=12 * GIB, reserve_bytes=reserve,
        max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB,
        max_run_log_bytes=192 * MIB if cohort else None)


def build(variant):
    result = read(DEST / (variant + '-build.json'))
    assert result['status'] == 'passed' and result['variant'] == variant
    assert sha(result['binary']['path']) == result['binary']['sha256']
    frozen_source = read(DEST / 'source.json')
    assert result['source_identity_sha256'] == identity(frozen_source[variant + '_source_sha256'])
    assert result['source_manifest_sha256'] == sha(DEST / 'source.json')
    receipt = read(result['build_receipt']['path'])
    assert sha(result['build_receipt']['path']) == result['build_receipt']['sha256']
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert sha(result['build_log']['path']) == result['build_log']['sha256'] == receipt['log_sha256']
    if 'source_rebinding' in result:
        proof = result['source_rebinding']
        for key in ('original_source_manifest', 'original_build_manifest'):
            assert bound(proof[key]['path']) == proof[key]
        original_source = read(proof['original_source_manifest']['path'])
        original_build = read(proof['original_build_manifest']['path'])
        assert original_build['source_manifest_sha256'] == proof['original_source_manifest']['sha256']
        assert original_source[variant + '_source_sha256'] == frozen_source[variant + '_source_sha256']
        for key in ('binary', 'build_receipt', 'build_log', 'command', 'environment', 'source_identity_sha256'):
            assert original_build[key] == result[key]
        for name, digest in original_source['helpers'].items():
            assert sha(Path(proof['original_source_manifest']['path']).parent / name) == digest
    return result
