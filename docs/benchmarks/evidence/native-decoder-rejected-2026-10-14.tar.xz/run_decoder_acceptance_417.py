"""Run the declared decoder acceptance stages after the frozen cost decision."""
import json
from pathlib import Path
import subprocess
import sys

import decoder_cost_common_416 as c


def main():
    source = c.frozen()
    decision_path = c.DEST / 'decision.json'
    decision = c.read(decision_path)
    assert decision['status'] == 'retained_for_resource_correctness_pending_wider_acceptance'
    assert not decision['repeated_material_regressions']
    assert decision['forward']['source_manifest_sha256'] == c.sha(c.DEST / 'source.json')
    python = sys.executable
    helper = lambda name: [python, '-B', str(c.OUT / name)]
    stages = [
        ('workspace_and_native_gates', helper('run_decoder_checks_416.py')),
        ('cli_source_freeze', helper('freeze_query_cli_368.py') +
            ['prepare', '--name', 'decoder-resources-416']),
        ('cli_release_build', helper('run_guarded.py') +
            ['--name', 'native-decoder-release-build-416', '--timeout', '2400', '--',
             'cargo', 'build', '--offline', '--locked', '--release', '-p', 'shardloom-cli',
             '--bin', 'shardloom', '--features', 'release-user-surfaces', '--message-format=json']),
        ('cli_artifact_freeze', helper('freeze_query_cli_368.py') +
            ['freeze', '--name', 'decoder-resources-416', '--build-receipt',
             str(c.OUT / 'native-decoder-release-build-416.json')]),
        ('direct_and_public_workflows', helper('run_decoder_runtime_416.py')),
        ('public_evidence_reopening', helper('verify_decoder_public_416.py')),
        ('retained_full43', helper('run_decoder_full43_416.py') +
            ['--max-log-mib', '1024', '--max-run-log-mib', '256']),
    ]
    helpers = [
        'run_decoder_acceptance_417.py', 'run_decoder_checks_416.py',
        'run_decoder_runtime_416.py', 'verify_decoder_public_416.py',
        'run_decoder_full43_416.py', 'freeze_query_cli_368.py',
        'freeze_native_release_298.py', 'run_guarded.py',
    ]
    identities = {name: c.bound(c.OUT / name) for name in helpers}
    protocol_path = c.OUT / 'decoder-acceptance-protocol-417.json'
    c.save(protocol_path, dict(status='frozen_before_broad_acceptance',
        stages=stages, helpers=identities, cost_decision=c.bound(decision_path),
        source_manifest=c.bound(c.DEST / 'source.json'),
        note='Sequential guarded stages. Direct source-package checks are not installed-wheel proof. Full43 reuses the retained resident Vortex input and exact native regression values; no performance claim.'))
    completed, failure = [], None
    try:
        for label, command in stages:
            c.frozen()
            assert all(c.bound(c.OUT / name) == bound for name, bound in identities.items())
            print(json.dumps(dict(stage=label, status='starting')), flush=True)
            result = subprocess.run(command, cwd=c.ROOT, check=True)
            assert result.returncode == 0
            completed.append(dict(stage=label, command=command, returncode=0))
            print(json.dumps(dict(stage=label, status='passed')), flush=True)
        final_files = [
            'decoder-checks-416.json', 'decoder-resources-416-release.json',
            'decoder-native-artifacts-416.json', 'decoder-runtime-416.json',
            'decoder-public-review-416.json', 'decoder-resources-full43-primary-review-416.json',
        ]
        for name in final_files:
            assert c.read(c.OUT / name)['status'] == 'passed', name
        assert c.sources() == source['candidate_source_sha256']
        assert all(c.bound(c.OUT / name) == bound for name, bound in identities.items())
    except BaseException as error:
        failure = f'{type(error).__name__}: {error}'
        raise
    finally:
        c.save(c.OUT / 'decoder-acceptance-417.json', dict(
            status='passed' if failure is None else 'failed', failure=failure,
            protocol=c.bound(protocol_path), completed=completed,
            sources_unchanged=c.sources() == source['candidate_source_sha256'],
            evidence=[c.bound(c.OUT / name) for name in final_files] if failure is None else [],
            performance_claim_allowed=False, publication_attempted=False))


if __name__ == '__main__':
    main()
