"""Build the revised binding and check complete direct/public workflows."""
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

from freeze_native_release_298 import ROOT, OUT, sha, sources, save

TEST_PYTHON = OUT / 'native-wheel-proof-376/venv/bin/python'
MANIFEST = OUT / 'decoder-native-artifacts-416.json'
DIRECT = OUT / 'decoder-direct-416.json'


def load():
    manifest = json.loads(MANIFEST.read_text())
    assert sources() == manifest['source_sha256']
    for kind in ('cli', 'binding'):
        assert sha(manifest[kind]['path']) == manifest[kind]['sha256']
    checks = json.loads(Path(manifest['checks']['path']).read_text())
    assert sha(manifest['checks']['path']) == manifest['checks']['sha256']
    assert checks['status'] == 'passed' and checks['runtime_source_unchanged']
    return manifest


def direct():
    import pyarrow
    import shardloom
    manifest = load()
    assert Path(sys.executable) == TEST_PYTHON
    assert Path(shardloom.__file__).resolve() == ROOT / 'python/src/shardloom/__init__.py'
    os.environ['SHARDLOOM_NATIVE_TEST_LIBRARY'] = manifest['binding']['path']
    os.environ['SHARDLOOM_REQUIRE_NATIVE_PYTHON'] = '1'
    os.environ['SHARDLOOM_BIN'] = manifest['cli']['path']
    suite = unittest.defaultTestLoader.discover(str(ROOT / 'python/tests'), pattern='test_native*binding.py')
    def identifiers(test):
        if isinstance(test, unittest.TestSuite):
            return [name for child in test for name in identifiers(child)]
        return [test.id()]
    names = identifiers(suite)
    assert len(names) == len(set(names)) == 80
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    passed = result.wasSuccessful() and result.testsRun == 80 and not result.skipped
    report = dict(status='passed' if passed else 'failed', tests=result.testsRun,
                  failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
                  test_names=names, manifest_sha256=sha(MANIFEST),
                  interpreter=sys.executable, python_version=sys.version,
                  pyarrow_version=pyarrow.__version__, pyarrow_file=pyarrow.__file__,
                  package_source=shardloom.__file__, helper_sha256=sha(__file__),
                  mode='direct_source_package_with_explicit_frozen_native_library',
                  installed_wheel_proof=False)
    assert not DIRECT.exists()
    save(DIRECT, report)
    assert load() == manifest and passed


def guarded(name, timeout, command):
    subprocess.run([sys.executable, '-B', str(OUT / 'run_guarded.py'), '--name', name,
                    '--timeout', str(timeout), '--', *map(str, command)], cwd=ROOT, check=True)


def main():
    checks_path = OUT / 'decoder-checks-416.json'
    checks = json.loads(checks_path.read_text())
    assert checks['status'] == 'passed' and checks['runtime_source_unchanged']
    accepted = json.loads(Path(checks['source_manifest']).read_text())['source_sha256']
    assert sources() == accepted
    cli_path = OUT / 'decoder-resources-416-release.json'
    manifest = json.loads(cli_path.read_text())
    assert manifest['status'] == 'passed' and manifest['source_sha256'] == accepted
    assert sha(manifest['cli']['path']) == manifest['cli']['sha256']
    binding_name = 'native-decoder-binding-build-416'
    guarded(binding_name, 2100,
            [sys.executable, '-B', ROOT / 'scripts/build_native_python.py', '--release', '--offline',
             '--output-dir', OUT / 'decoder-native-binding-416'])
    receipt = OUT / f'{binding_name}.json'
    report = json.loads(receipt.read_text())
    log = receipt.with_suffix('.log')
    assert report['status'] == 'passed' and report['process_group_drained'] and report['direct_child_reaped']
    assert sha(log) == report['log_sha256']
    raw = log.read_text()
    start = raw.index('{\n  "schema_version": "shardloom.native_python_build.v1"')
    binding = json.loads(raw[start:])
    assert binding['status'] == 'passed' and '--release' in binding['command']
    assert sha(binding['library']) == sha(binding['cargo_artifact']) == binding['library_sha256']
    manifest.update(schema_version='shardloom.decoder_native_artifacts.v1',
                    cli_manifest=dict(path=str(cli_path), sha256=sha(cli_path)),
                    checks=dict(path=str(checks_path), sha256=sha(checks_path)),
                    binding=dict(path=binding['library'], sha256=binding['library_sha256'],
                                 bytes=binding['library_bytes'], build_receipt=str(receipt),
                                 build_receipt_sha256=sha(receipt), build_log=str(log)))
    assert sources() == accepted
    save(MANIFEST, manifest)
    manifest = load()
    guarded('native-decoder-direct-416', 1800, [TEST_PYTHON, '-B', __file__, 'direct'])
    direct_report = json.loads(DIRECT.read_text())
    assert direct_report['status'] == 'passed' and direct_report['tests'] == 80
    public_root = OUT / 'decoder-public-416'
    guarded('native-decoder-public-416', 5400,
            [sys.executable, '-B', ROOT / 'scripts/run_native_streaming_input_uat.py',
             '--binary', manifest['cli']['path'], '--uat-root', public_root, '--operation-timeout', '600'])
    summary = json.loads((public_root / 'summary.json').read_text())
    assert summary['status'] == 'passed' and len(summary['families']) == len(set(summary['families'])) == 19
    assert all(case['status'] == 'passed' for case in summary['cases'])
    assert load() == manifest
    destination = OUT / 'decoder-runtime-416.json'
    assert not destination.exists()
    save(destination, dict(status='passed', manifest=str(MANIFEST), manifest_sha256=sha(MANIFEST),
         direct_summary=str(DIRECT), direct_summary_sha256=sha(DIRECT),
         public_summary=str(public_root / 'summary.json'), public_summary_sha256=sha(public_root / 'summary.json'),
         public_families=summary['families'], public_cases=len(summary['cases']),
         source_identity_preserved=True, full43='pending', cost_screen='completed_before_broad_acceptance',
         helper=str(Path(__file__).resolve()), helper_sha256=sha(__file__)))
    print(json.dumps(dict(status='passed', direct_tests=80, public_cases=len(summary['cases']), public_families=19)))


if __name__ == '__main__':
    direct() if sys.argv[1:] == ['direct'] else main()
