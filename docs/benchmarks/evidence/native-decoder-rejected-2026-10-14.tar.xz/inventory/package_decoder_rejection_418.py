"""Archive the verified, closed rejected decoder attempt without bulk binaries."""
import hashlib
import json
import os
from pathlib import Path
import sys
import tarfile

from package_selection_acceptance_409 import Members, need, sha_file, sha_stream, verify

OUT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
REPO = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
ARCHIVE = OUT / 'decoder-rejected-evidence-418.tar.xz'
MANIFEST = OUT / 'decoder-rejected-evidence-418.manifest.json'
VERIFICATION = OUT / 'decoder-rejected-evidence-418.verification.json'


def read(path):
    return json.loads(path.read_text())


def main():
    outputs = (ARCHIVE, MANIFEST, VERIFICATION)
    partials = tuple(path.with_name('.' + path.name + '.partial') for path in outputs)
    for path in (*outputs, *partials):
        need(not path.exists() and not path.is_symlink(), f'output already exists: {path}')
    review_path = OUT / 'decoder-rejected-evidence-primary-418.json'
    review = read(review_path)
    need(review['status'] == 'passed_literal_inventory', 'unverified inventory')
    inventory_path = Path(review['inventory']['path'])
    verify(inventory_path, review['inventory']['sha256'])
    inventory = read(inventory_path)
    members = Members()
    for row in inventory['records']:
        members.add(Path(row['path']), row['archive_path'], 'local_evidence', OUT,
            row['category'], row['sha256'], row['bytes'])
    decision = read(OUT / 'decoder-cost-416/decision.json')
    need(decision['status'] == 'revision_required' and len(decision['repeated_material_regressions']) == 12,
         'rejected attempt decision changed')
    for path in (
        inventory_path, review_path, OUT / 'decoder-rejected-evidence-inventory-418.json',
        OUT / 'decoder-rejected-evidence-inventory-418-worker-original.json',
        OUT / 'verify_decoder_rejected_inventory_418.py', Path(__file__).resolve(),
        OUT / 'package_selection_acceptance_409.py',
    ):
        members.add(path, 'inventory/' + path.name, 'local_evidence', OUT, 'inventory or packaging provenance')
    source = read(OUT / 'decoder-cost-416/source.json')
    for name, digest in source['helpers'].items():
        members.add(OUT / name, 'tools/' + name, 'local_evidence', OUT,
            'executed helper bound by original source manifest', digest)
    for path in (
        REPO / 'scripts/local_uat_storage.py',
        Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py'),
        Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'),
    ):
        members.add(path, 'tools/support/' + path.name, 'support', path.parent,
            'guard dependency; archived current bytes, original helper provenance remains in receipts')
    ordered = sorted(members.paths.values(), key=lambda item: item.name)
    raw_bytes = sum(item.size for item in ordered)
    need(raw_bytes <= 64 << 20, 'closed attempt archive exceeds 64 MiB raw input budget')
    sys.path.insert(0, str(REPO / 'scripts'))
    from local_uat_storage import GIB, MIB, check_budgets, require_local_path
    require_local_path(OUT, Path.home(), sys.platform)
    check_budgets(OUT, ARCHIVE, OUT / 'logs', min_free_bytes=12 * GIB,
        reserve_bytes=raw_bytes + 64 * MIB, max_workspace_bytes=100 * GIB,
        max_log_bytes=1024 * MIB)
    created, published = [], []
    try:
        with partials[0].open('xb') as output:
            created.append(partials[0])
            with tarfile.open(fileobj=output, mode='w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
                for item in ordered:
                    verify(item.path, item.digest, item.size)
                    info = tarfile.TarInfo(item.name)
                    info.size, info.mode, info.mtime = item.size, 0o644, 0
                    with item.path.open('rb') as stream:
                        archive.addfile(info, stream)
                    verify(item.path, item.digest, item.size)
        seen = set()
        with tarfile.open(partials[0], mode='r|xz') as archive:
            for entry in archive:
                need(entry.isfile() and entry.name in members.names and entry.name not in seen,
                     f'invalid archive member: {entry.name}')
                item = members.paths[members.names[entry.name]]
                stream = archive.extractfile(entry)
                need(stream is not None, 'missing member data')
                size, digest = sha_stream(stream)
                need((size, digest) == (item.size, item.digest), f'archive mismatch: {entry.name}')
                seen.add(entry.name)
        need(seen == set(members.names), 'archive membership incomplete')
        archive_bytes, archive_sha = sha_file(partials[0])
        for item in ordered:
            verify(item.path, item.digest, item.size)
        manifest = dict(status='passed', kind='rejected_decoder_candidate_history',
            cost_decision='revision_required', repeated_material_cells=12,
            source_manifest_sha256=sha_file(OUT / 'decoder-cost-416/source.json')[1],
            archive=dict(path=str(ARCHIVE), bytes=archive_bytes, sha256=archive_sha),
            members=[dict(path=str(item.path), archive_path=item.name,
                bytes=item.size, sha256=item.digest, roles=item.roles) for item in ordered],
            member_count=len(ordered), raw_bytes=raw_bytes, raw_limit_bytes=64 << 20,
            exclusions=inventory['explicit_exclusions'],
            binary_identities=inventory['binary_payload_exclusions'],
            limitations='Verifies preserved bytes and membership. Does not accept the rejected candidate, assert reproducible binary builds, or include bulk executable payloads.')
        manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
        values = [manifest, dict(status='passed', all_members_reopened=True,
            member_count=len(seen), archive_sha256=archive_sha, archive_bytes=archive_bytes)]
        values[1]['manifest_sha256'] = hashlib.sha256(manifest_bytes).hexdigest()
        for temporary, value in zip(partials[1:], values, strict=True):
            with temporary.open('xb') as stream:
                created.append(temporary)
                stream.write((json.dumps(value, indent=2, sort_keys=True) + '\n').encode())
        for temporary, output in zip(partials, outputs, strict=True):
            os.link(temporary, output)
            published.append(output)
            temporary.unlink()
            created.remove(temporary)
        print(json.dumps(dict(status='passed', archive=str(ARCHIVE), members=len(seen),
            archive_bytes=archive_bytes, archive_sha256=archive_sha, raw_bytes=raw_bytes)), flush=True)
    except BaseException:
        for path in published:
            path.unlink(missing_ok=True)
        raise
    finally:
        for path in created:
            path.unlink(missing_ok=True)


if __name__ == '__main__':
    main()
