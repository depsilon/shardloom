"""Verify the closed rejected attempt inventory without using live candidate source."""
import collections
import hashlib
import json
from pathlib import Path

OUT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
ROOT = OUT / 'decoder-cost-416'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def bound(path):
    return dict(path=str(path), sha256=sha(path))


def main():
    path = OUT / 'decoder-rejected-evidence-inventory-418.json'
    original = OUT / 'decoder-rejected-evidence-inventory-418-worker-original.json'
    assert sha(path) == 'acf321533092731d74c6f1951a4da2b15eb81e937c32631588a5428520d174f9'
    assert sha(original) == 'ec86c15c2550ed03aeb48ab6af634e34df59b97a5290bbde26dc1a2ecfcf4d86'
    data, old = read(path), read(original)
    records = data['records']
    selected = {Path(row['path']) for row in records}
    overlaps = [row for row in data['explicit_exclusions'] if Path(row['path']) in selected]
    assert len(overlaps) == 10 and all('/source-files/' in row['path'] for row in overlaps)
    data['explicit_exclusions'] = [row for row in data['explicit_exclusions'] if Path(row['path']) not in selected]
    data['primary_correction'] = dict(worker_inventory=bound(path),
        reason='Remove ten contradictory exclusions of selected source snapshots. Preserve every selected identity and both original worker inventories.',
        removed_exclusion_records=overlaps)
    assert len(selected) == len(records) == data['record_count'] == 7862
    assert len({row['archive_path'] for row in records}) == len(records)
    assert sum(row['bytes'] for row in records) == data['total_selected_bytes'] == 24411101
    assert dict(collections.Counter(row['category'] for row in records)) == data['category_counts']
    for row in records:
        item = Path(row['path'])
        assert item.is_file() and not item.is_symlink()
        assert item.stat().st_size == row['bytes'] and sha(item) == row['sha256'], item
        assert not Path(row['archive_path']).is_absolute() and '..' not in Path(row['archive_path']).parts
    for before, after in zip(old['records'], records, strict=True):
        assert {key: value for key, value in before.items() if key != 'category'} == {
            key: value for key, value in after.items() if key != 'category'}
    assert sum(before['category'] != after['category'] for before, after in zip(old['records'], records)) == 10
    excluded = {Path(row['path']) for row in data['explicit_exclusions']}
    actual = {item for item in ROOT.rglob('*') if item.is_file()}
    assert all(not item.is_symlink() for item in ROOT.rglob('*'))
    assert actual == (selected & actual) | (excluded & actual) and not selected & excluded
    source = read(ROOT / 'source.json')
    assert sha(ROOT / 'contract.json') == source['contract_sha256']
    for name, digest in source['helpers'].items():
        assert sha(OUT / name) == digest
    prior = ROOT / 'pre-cohort-guard-correction'
    prior_source = read(prior / 'source.json')
    assert sha(prior / 'contract.json') == prior_source['contract_sha256']
    for name, digest in prior_source['helpers'].items():
        assert sha(prior / name) == digest
    for row in records:
        if row['category'].startswith('source_snapshot_'):
            variant = 'candidate' if row['category'].endswith('candidate') else 'baseline'
            folder = 'candidate' if variant == 'candidate' else 'baseline-overlay'
            relative = Path(row['path']).relative_to(ROOT / 'source-files' / folder).as_posix()
            assert row['sha256'] == source[variant + '_source_sha256'][relative]
    for variant in ('baseline', 'candidate'):
        build = read(ROOT / (variant + '-build.json'))
        assert build['source_manifest_sha256'] == sha(ROOT / 'source.json')
        for kind in ('build_receipt', 'build_log'):
            item = build[kind]
            assert sha(Path(item['path'])) == item['sha256'] and Path(item['path']) in selected
    for order in ('forward', 'reverse'):
        run = read(ROOT / order / 'summary.json')
        assert run['source_manifest_sha256'] == sha(ROOT / 'source.json')
        assert run['contract_sha256'] == sha(ROOT / 'contract.json')
        assert len(run['samples']) == 1944
        logs = set()
        for index, sample in enumerate(run['samples']):
            sample_path = ROOT / order / f'sample-{index:04}.json'
            assert sample_path in selected and read(sample_path) == sample
            log = Path(sample['log']['path'])
            assert log in selected and sha(log) == sample['log']['sha256']
            logs.add(log)
        assert len(logs) == 1944
    corrected = OUT / 'decoder-rejected-evidence-inventory-primary-418.json'
    save(corrected, data)
    report = dict(status='passed_literal_inventory', inventory=bound(corrected),
        worker_inventory=bound(path), original=bound(original), helper=bound(Path(__file__)),
        selected_records=len(records), selected_bytes=data['total_selected_bytes'],
        all_selected_bytes_rehashed=True, closed_cost_tree_complete_with_explicit_exclusions=True,
        all_selected_source_snapshots_and_original_helpers_verified=True,
        all_3888_sample_records_and_logs_verified=True, source_category_repair_count=10,
        contradictory_exclusions_removed=10,
        preliminary_primary_checks=['Detected selected/excluded snapshot overlap; corrected explicitly.',
            'A guessed sample log filename check failed; corrected to use each original sample manifest log path.'],
        scope='Literal inventory/provenance only; no performance or correctness acceptance inferred.')
    save(OUT / 'decoder-rejected-evidence-primary-418.json', report)
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
