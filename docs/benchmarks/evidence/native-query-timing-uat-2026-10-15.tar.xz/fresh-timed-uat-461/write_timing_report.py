"""Render the complete verified Full43 timings and fresh-UAT stage boundaries."""
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
RESULTS = OUT / 'timed-native-fresh-uat-1-results.json'


def read(path):
    return json.loads(Path(path).read_text())


def checked(path, digest):
    raw = Path(path).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == digest
    return json.loads(raw)


def main():
    results = read(RESULTS)
    assert results['status'] == 'passed_local_fresh_uat'
    protocol_path = OUT / 'timed-native-fresh-uat-1-protocol.json'
    protocol = checked(protocol_path, results['protocol_sha256'])
    query = checked(results['queries']['summary'], results['queries']['summary_sha256'])
    ingest = checked(results['ingest']['summary'], results['ingest']['summary_sha256'])
    modular = checked(results['modular']['summary'], results['modular']['summary_sha256'])
    assert query['complete'] and query['runs_passed'] == query['runs_completed'] == 43
    assert query['repeats'] == 1 and results['queries']['complete_rows'] == 381
    assert query['timing_totals']['calls_with_engine_timing'] == 43
    assert modular['status'] == 'passed' and len(modular['cohorts']) == 18
    records = sorted(query['records'], key=lambda item: item['query'])
    assert [item['query'] for item in records] == list(range(1, 44))
    totals = query['timing_totals']['totals']
    stages = {item['stage']: item for item in results['stages']}
    peak = max(item['native_peak_rss_bytes'] for item in records)
    csv_path = Path(results['queries']['timing_csv'])
    assert hashlib.sha256(csv_path.read_bytes()).hexdigest() == results['queries']['timing_csv_sha256']
    text = f'''<!-- SPDX-License-Identifier: Apache-2.0 -->

# Fresh native UAT with separated query timings — October 15, 2026

Fresh ingestion passed for all **99,997,497 rows**. All **43 queries** passed in
one sequential execution each, with every one of the **381 returned rows** checked
against the retained native regression reference. All **18 modular cohorts** also
passed: **704 ShardLoom executions** and **704 independent pandas reference records**
across the declared input, output and raw/prepared workflow matrix. Pandas is a
testing reference; it does not execute ShardLoom work.

The primary query optimization clock is **{totals['engine_execution_seconds']:.6f} s**
of engine-owned execution. This is elapsed wall time including native query I/O,
decode where required, source-generation validation, native operators and
certification after preparation. It excludes separately measured result
serialization and the rest of the public process. CPU counters overlap elapsed
time and include parallel workers; they must not be added to wall time.

This is a local acceptance baseline on current source after the immutable 0.6.0
release. It does not establish a speedup, a cold-cache result, a new package
release, an engine comparison, whole-file every-cell ingest equivalence or the
complete input/output Cartesian product. The original Parquet was prehashed and
queries used newly written Vortex; the OS cache and normal host activity were
uncontrolled. No artificial pacing, power/thermal gate or automatic retry was used.

## Measured boundaries

| Measurement | Seconds | Scope |
| --- | ---: | --- |
| Engine execution, sum of 43 calls | {totals['engine_execution_seconds']:.6f} | Primary query clock; includes query I/O and native validation |
| Result serialization, sum of 43 calls | {totals['result_serialization_seconds']:.9f} | Synchronous native values/schema serialization |
| Remaining process work, sum of 43 calls | {totals['process_other_seconds']:.6f} | Startup, parsing, preparation, control/report work, exit and unattributed process work |
| Complete CLI processes, sum of 43 calls | {totals['process_wall_seconds']:.6f} | Engine + result serialization + remaining process work |
| Per-call supervision overhead | {totals['supervision_overhead_seconds']:.6f} | Outside complete native processes |
| Supervised calls, sum of 43 calls | {totals['supervised_wall_seconds']:.6f} | Process wall + per-call supervision |
| Complete-result value validation | {totals['validation_seconds']:.6f} | External per-call validation; outside process and supervision clocks |
| Complete query stage | {stages['fresh-full43']['stage_workflow_seconds']:.6f} | Guard invocation through query runner exit; includes setup, archiving and summary writes |
| Fresh ingest process | {ingest['native_process_seconds']:.6f} | Complete native prepare process |
| Complete ingest stage | {stages['full-ingest']['stage_workflow_seconds']:.6f} | Guard invocation through ingest runner exit |
| Ingest plus query workflow | {results['ingest_plus_query_supervised_workflow_seconds']:.6f} | Includes stage checks; excludes source prehash, later independent readback, modular checks and final hashes |
| Independent reopening of all query outputs | {results['queries']['independent_readback_seconds']:.6f} | Rechecks saved raw envelopes, values, certificates, clocks and hashes |
| Modular matrix workflow | {modular['actual_supervised_wall_seconds']:.6f} | All 18 native/reference cohorts and output validation |
| Source prehash | {results['source_prehash_seconds']:.6f} | Outside all native operation clocks |
| Final source and Vortex hashes | {results['final_artifact_hash_seconds']:.6f} | Outside all native operation clocks |
| Entire fresh UAT | {results['full_uat_wall_seconds']:.6f} | Driver start through final verification and host-sampler cleanup |

Rows have explicit nested boundaries and must not all be summed. In particular,
remaining process work is a residual; it does not separately measure startup or
preparation. Whole-query user CPU was {totals['user_cpu_seconds']:.6f} s and system
CPU was {totals['system_cpu_seconds']:.6f} s. Maximum query process RSS was
{peak / 1024**3:.6f} GiB ({peak:,} bytes); ingest peak RSS was
{ingest['native_peak_rss_bytes'] / 1024**3:.6f} GiB
({ingest['native_peak_rss_bytes']:,} bytes). RSS is an observed process high-water
mark, separate from the declared 24-GiB engine admission and maximum parallelism
12. The host had {protocol['physical_memory_bytes'] / 1024**3:g} GiB physical RAM
and {protocol['logical_cpus']} logical CPUs. The modular matrix uses its own
1-GiB admission and maximum parallelism 2.

## Every query

All rows passed. Times use the single observed call; no best-of-repeats selection
or hot-run score applies. Serialization is shown in milliseconds to retain its
scale. The CSV retains full SQL, all clocks, CPU, RSS, page faults and block I/O.

| Query | Engine s | Serialization ms | Other process s | Complete process s |
| --- | ---: | ---: | ---: | ---: |
'''
    for item in records:
        text += (f"| Q{item['query']:02} | {item['engine_execution_seconds']:.6f} | "
                 f"{item['result_serialization_seconds'] * 1000:.6f} | "
                 f"{item['process_other_seconds']:.6f} | {item['process_wall_seconds']:.6f} |\n")
    text += f'''
The [complete timing CSV](evidence/native-query-timing-uat-2026-10-15.csv) and
[portable evidence index](evidence/native-query-timing-uat-2026-10-15.json) retain
unrounded measurements and exact source/result identities. Both Full43 runners
now require engine clocks by default, record one execution per query by default,
and produce the same timing columns. Explicit historical comparisons can allow
absent engine clocks; those values remain unavailable.

## Reproduction and evidence

The frozen optimized executable has SHA-256 `{protocol['binary_sha256']}`.
The build records base commit `{protocol['source_commit']}` plus all
{len(protocol['source_hashes']):,} exact source-file hashes for the uncommitted
compression and timing changes. The portable evidence preserves the source
manifest, build receipt/log, commands, complete query definitions and reference
packet, complete saved outputs, process cleanup receipts, modular fixtures and
reports, host observations and helper sources.

Every query output was reopened independently, with the native I/O certificate
available and `fallback_attempted=false` / `external_engine_invoked=false`.
The original 14,779,976,446-byte Parquet and new 15,713,610,513-byte Vortex file
were hashed after the run and had unchanged generations. Large dataset payloads
and executable bytes are excluded from the portable evidence archive, with their
identities retained. This evidence supplements the earlier
[compression acceptance](native-compression-resources-2026-10-15.md); it does not
rewrite its historical process-only timings.
'''
    destination = OUT / 'native-query-timing-uat-2026-10-15.md'
    with destination.open('x') as stream:
        stream.write(text)
    print(json.dumps(dict(report=str(destination),csv=str(csv_path),status='passed',
                          engine_seconds=totals['engine_execution_seconds'],rows=43)))


if __name__ == '__main__':
    main()
