"""Independently reopen sampling values, scope counters and failed publications."""
import gzip
import hashlib
import json

from native_unary_reference import sample_ordinals

KINDS = ('fraction-unweighted', 'replacement-unweighted', 'fraction-replacement-unweighted',
         'fraction-weighted', 'replacement-weighted', 'fraction-replacement-weighted')
FORMATS = ('vortex', 'parquet', 'arrow_ipc', 'avro', 'orc', 'json', 'jsonl', 'csv')


def verify(root, summary, identity, strict_json, report_fields):
    cases = {case['name']: case for case in summary['cases']}
    assert len(cases) == len(summary['cases'])
    values, envelopes, failures = [], [], []

    def saved(name):
        path = root / 'logs' / (name + '.json.gz')
        return path, strict_json(gzip.decompress(path.read_bytes()).decode())

    def complete_values(name, expected):
        path, record = saved(name + '-values')
        assert record['actual'] == record['expected'] == expected, name
        values.append({'name': name, 'rows': len(expected), 'values': identity(path)})

    def completion(name, *, population, count, replace, admitted=True, runs=False, stages=1, replay=0):
        path, envelope = saved(name + '-envelope')
        assert envelope['status'] == 'success' and not envelope['fallback']['attempted']
        fields = report_fields(envelope)
        assert fields['native_input_end_observed'] == 'true', name
        assert fields['resident_completed_executions'] == '1', name
        assert int(fields['native_input_replay_sources']) == replay, name
        assert int(fields['relational_spillable_sampling_stages']) == (stages if admitted else 0), name
        if admitted:
            for suffix in ('input_rows', 'population_rows'):
                assert int(fields['relational_spillable_sampling_' + suffix]) == population * stages, (name, suffix)
            assert int(fields['relational_spillable_sampling_output_rows']) == count * stages, name
            assert int(fields['relational_spillable_sampling_replacement_draws']) == (count * stages if replace else 0), name
            assert (int(fields['relational_spillable_sampling_lookup_blocks']) > 0) == (replace and count > 0), name
        assert (int(fields['relational_spill_runs_written']) > 0) == runs, name
        assert fields['relational_spill_owned_cleanup_completed'] == 'true', name
        assert int(fields['relational_spill_peak_disk_bytes']) <= 128 << 20
        envelopes.append(identity(path))
        return fields

    def row(index, width):
        return {'n': index, 's': f'{index:08d}' + 'u' * (width - 8)}

    _, declared = saved('sampling-population-predeclared')
    reference = declared['small']
    assert len(reference['sampling_cases']) == 54
    assert declared['grant_bytes'] == 32 << 20 and declared['formats'] == list(FORMATS)
    assert declared['source_replay_is_separate'] is True
    for case in reference['sampling_cases']:
        rows = case.get('rows', reference['sampling_rows'])
        options = case['options']
        replace = options.get('replace', False)
        target = options.get('n', case.get('declared_target'))
        selected = sample_ordinals(len(rows), target, options['random_state'],
            weights=[item['weight'] for item in rows] if options.get('weights') else None, replace=replace)
        expected = [rows[index] for index in selected]
        assert selected == case['ordinals'] and expected == case['expected']
        admitted = replace or options.get('frac') is not None
        for surface in ('dataframe', 'sql'):
            for terminal in ('collect', 'batches'):
                name = f"sampling-population-{case['name']}-{surface}-{terminal}"
                assert cases[name]['complete_rows'] == len(expected)
                assert cases[name]['population_strategy'] == admitted
                complete_values(name, expected)
                completion(name, population=len(rows), count=len(expected), replace=replace, admitted=admitted)

    populations = declared['populations']
    assert populations['schema'] == 'shardloom.sampling_population_reference.v1'
    for label, count, width, grant, draws in [('cases', 8193, 2048, 16 << 20, 3),
                                            ('failure_cases', 65, 32768, 32 << 20, 7),
                                            ('typed_cases', 6, 600 << 10, 64 << 20, 11)]:
        assert [case['name'] for case in populations[label]] == list(KINDS)
        for case in populations[label]:
            first = int(case['weighted'])
            population = count - first
            assert (case['rows'], case['width'], case['grant_bytes'], case['first'], case['population']) == (
                count, width, grant, first, population)
            assert case['seed'] == 7
            target = case['count']
            if target is None:
                assert case['fraction'] in (0.5, 1 / 64)
                denominator = 2 if case['fraction'] == 0.5 else 64
                target = (population + denominator - 1) // denominator
            else:
                assert target == draws and case['replace'] and case['fraction'] is None
            selected = sample_ordinals(population, target, 7,
                weights=list(range(1, count)) if first else None, replace=case['replace'])
            assert case['expected'] == [first + index for index in selected]

    wide = populations['failure_cases']
    for case in wide:
        expected = [row(index, case['width']) for index in case['expected']]
        arguments = dict(population=case['population'], count=len(expected), replace=case['replace'], runs=True)
        for terminal in ('collect', 'batches'):
            name = f"sampling-population-wide-{case['name']}-{terminal}"
            complete_values(name, expected)
            completion(name, **arguments)
        for destination in (*FORMATS, 'fanout'):
            name = f"sampling-population-{case['name']}-write-{destination}"
            fields = completion(name, **arguments)
            formats = FORMATS if destination == 'fanout' else (destination,)
            if destination == 'fanout':
                for suffix, value in [('execution_count', 1), ('target_count', 8), ('replay_count', 8)]:
                    assert int(fields['native_vortex_result_export_' + suffix]) == value
            artifacts = cases[name]['artifacts']
            assert len(artifacts) == len(formats)
            for artifact in artifacts:
                actual = identity(root / artifact['path'])
                assert (actual['bytes'], actual['sha256']) == (artifact['bytes'], artifact['sha256'])
            for extension in formats:
                wanted = [{'n': str(value['n']), 's': value['s']} for value in expected] if extension == 'csv' else expected
                complete_values(name + '-' + extension, wanted)
        name = 'sampling-population-early-close-' + case['name']
        assert cases[name]['completion_report'] is None
        assert cases[name]['source_completed_before_output'] is True
        assert not (root / 'logs' / (name + '-envelope.json.gz')).exists()
        complete_values(name, expected[:1])
        if case['replace']:
            name = 'sampling-population-source-replay-' + case['name']
            complete_values(name, expected * 2)
            fields = completion(name, **arguments, stages=2, replay=1)
            assert fields['native_input_replay_spilled_sources'] == '1'
            assert int(fields['native_input_replay_rows']) == case['rows']
            assert cases[name]['producer_executions'] == 1 and cases[name]['source_replay_separate_from_population']

    for case in populations['cases']:
        name = f"unary-sampling-population-{case['name']}-spill-True"
        expected = [row(index, case['width']) for index in case['expected']]
        path = root / 'logs' / (name + '-values.jsonl.gz')
        digest, observed = hashlib.sha256(), 0
        with gzip.open(path, 'rb') as stream:
            for index, line in enumerate(stream):
                assert index < len(expected) and strict_json(line.decode()) == expected[index], (name, index)
                digest.update(line)
                observed += 1
        assert observed == len(expected)
        record = cases[name]
        assert record['complete_rows'] == observed and record['expected_sha256'] == digest.hexdigest()
        actual = identity(path)
        assert record['values'] == dict(path=str(path.relative_to(root)), bytes=actual['bytes'], sha256=actual['sha256'])
        values.append({'name': name, 'rows': observed, 'values': actual, 'raw_sha256': digest.hexdigest()})
        completion(name, population=case['population'], count=observed, replace=case['replace'], runs=True)
        denied = f"unary-sampling-population-{case['name']}-spill-False"
        assert cases[denied]['sampling_population_spill'] is False
        trace = cases[denied]['producer_trace']
        assert trace['opened'] == 1 and trace['closed'] and not trace['ended']
        _, envelope = saved(denied + '-envelope')
        assert envelope['status'] == 'error' and not envelope['fallback']['attempted']
        assert 'reservation denied' in json.dumps(envelope)

        for failure in ('producer', 'corrupt', 'quota'):
            for terminal in ('batches', 'vortex', 'fanout'):
                for existing in ((False, True) if failure == 'producer' and terminal != 'batches' else (False,)):
                    name = f"sampling-population-{case['name']}-{failure}-{terminal}-existing-{existing}"
                    record = cases[name]
                    assert record['failure'] == failure and record['terminal'] == terminal
                    assert record['existing_preserved'] == existing
                    assert record['failure_phase'] == ('destination_admission' if existing else 'execution')
                    trace = record['failed_trace']
                    if existing:
                        assert trace['opened'] == 0 and not any(trace[key] for key in ('closed', 'ended', 'fault'))
                        _, error = saved(name + '-envelope')
                        assert error['status'] == 'error' and 'existing destination' in json.dumps(error)
                    elif failure != 'quota':
                        assert trace['opened'] == 1 and trace['closed'] and not trace['ended']
                        assert trace['fault'] is True
                    else:
                        assert trace['opened'] == 1 and trace['closed'] and not trace['ended']
                        _, error = saved(name + '-envelope')
                        assert error['status'] == 'error' and 'quota' in json.dumps(error)
                    for extension in (('vortex', 'jsonl') if terminal == 'fanout' else ('vortex',)):
                        target = root / 'outputs' / (name + '.' + extension)
                        if existing:
                            assert target.read_bytes() == b'preserve existing sample target'
                        else:
                            assert not target.exists()
                    recovered = case['count'] if case['count'] is not None else 1
                    assert record['complete_recovery_rows'] == recovered
                    complete_values(name + '-recovery', [{'n': 1, 's': 'fresh'}] * recovered)
                    completion(name + '-recovery', population=1, count=recovered, replace=case['replace'])
                    failures.append(name)

    assert len(values) == 406, len(values)
    assert len(failures) == 66
    assert len([name for name in cases if name.startswith('sampling-population-')]) == 358
    return {'sampling_complete_value_archives': values, 'sampling_completion_envelopes': envelopes,
            'sampling_publication_failure_cases': failures,
            'sampling_existing_destination_admission_denials': 12,
            'sampling_incomplete_execution_failure_cases': 54,
            'sampling_population_public_cases': 358, 'sampling_pressure_cases': 12,
            'sampling_rows_independently_reopened': sum(item['rows'] for item in values)}
