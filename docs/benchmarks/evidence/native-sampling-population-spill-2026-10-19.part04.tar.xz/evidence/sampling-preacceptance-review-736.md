# Sampling population review before broad acceptance

Reviewed implementation: `f363f2890436b532469d9682f69457cee3ef7b2f`.
This records source review and focused evidence, not completion of the full gates.

1. **Population retention must preserve existing observation and sampling semantics.**
   Compared `local_primitive_unary_sampling_spill.rs` against
   `local_primitive_unary_sample.rs`. Admission is confined to replacement or an
   unknown-bound fractional sample without replacement. Predicates precede
   ordinals and weight observation; the existing seed, score, target and draw
   functions are reused. Cumulative totals keep sequential addition and the
   finite-total check before payload access. Without replacement, rank is score
   descending then ordinal ascending and final output is restored to source
   order. The private unsigned score representation normalizes zero ties and
   preserves negative infinity. The focused tests exercise independent expected
   results across bounds/chunks/seeds, tiny weights, cumulative rounding ties,
   fractional carry behavior, overflow and nonfinite payload observation.

2. **External state must not hide an uncredited full-population owner.**
   `Population` uses a credited pending vector bounded by at most 256 rows and
   a 256-KiB shaping threshold, with individual records still subject to the
   shared memory grant. It clears pending payload owners before ordering merge
   work. Replacement has one credited cached positional block and compacts
   selected rows into independently credited output. Schema and buffer owners
   use the existing native ownership helpers. Original 16-MiB pressure tests and
   large typed/dictionary payload tests pass. The state-item report explicitly
   counts the logical retained population, including files; it does not claim
   a resident entry count or a process-wide memory ceiling.

3. **Cached reads and output publication must retain failure boundaries.**
   `Access::at` validates the stored population on every access, including a
   cache hit, and checks the stored ordinal. It drops the previous block before
   loading another and releases the cache before final generation/cleanup checks.
   Focused tests pass for open/cache/merge generation changes, quotas, reduced
   grants, cancellation, producer/schema/consumer failure, real child-process
   abandonment, unknown-owner refusal and cleanup followed by a fresh run.
   A public test initially expected producer failure when a destination already
   existed. Source review of `local_primitive_native_sink.rs` and the existing
   destination tests established that admission must reject before demand. The
   harness was corrected before freezing: twelve cases now assert that refusal
   and unchanged bytes, separate from 54 incomplete-execution failures.

Focused evidence: `sampling-focused-735b.json` and its log record 24 passing
selectors, including all 18 new selectors. The focused run was before the source
commit; final acceptance therefore separately requires the full native suite
and all other gates against the frozen clean source. The earlier failed path-
alias recovery assertion and strict-lint attempt remain in the evidence folder.

The primary independently recomputed the declaration: 5,492 unique public names
in 38 registry-ordered families, replacing 51 old pressure names with 59 and
adding 358 sampling names. All declared source identities were checked.
The final source manifest has 2,195 verified source entries and the broad native
suite must include all 17 existing unary-membership regression selectors.

Pending: binding and public executions, full workspace/native/CLI checks,
independent full-result readback, Full43, format workflows, documentation
closeout and portable evidence inspection. No broader PERF owner, interrupted-
execution resume, release or competitive claim is established by this review.
