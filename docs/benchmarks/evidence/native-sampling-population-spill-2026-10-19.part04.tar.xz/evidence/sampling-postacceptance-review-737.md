# Sampling population acceptance review

Runtime, binding and harness source: f363f2890436b532469d9682f69457cee3ef7b2f.
The guarded serial controller completed all declared phases without a failed
acceptance gate. This follows the earlier source review; it is not a second
runtime execution or a performance comparison.

1. Exact sampling and observation semantics are supported by all 18 required
   native selectors, independent predeclared rank/draw fixtures and 48 direct
   binding subcases. The public verifier reopened all 406 sampling value archives
   and all 11,518 rows. Scope remains unknown-bound fractional nonreplacement and
   fixed/fractional replacement, weighted/unweighted. Bounded top-k and legacy
   callers remain separate. The documentation and machine index name those
   restrictions, rather than granting broad unary state spill.
2. Pressure completion uses the original 16-MiB population fixture; explicit
   no-spill denial remains. Writer/binding 32-MiB and independent file-readback
   128-MiB grants are disclosed separately. Native cache, merge, failure and real
   process-death tests pass with ownership cleanup. Logical state-item counts
   are not resident heap counts. Cleanup followed by fresh execution does not
   establish interrupted-query resume or a whole-process memory ceiling.
3. The complete 5,492-case public run, Full43 and all 18 format cohorts pass.
   Verification checks all 2,195 frozen source entries, artifact/plan/helper
   identities and complete archived values. Full43 is one retained-native
   regression observation, with 50.415902622 seconds of engine execution. The
   704 fresh pandas comparisons are modular independent oracles only. The 66
   public failure/preservation cases remain explicitly split into 54 execution
   faults and 12 existing-destination refusals before input demand.

Documentation closeout changes only the claim validator among the frozen source
entries. Its explicit source bridge must prove all other 2,194 entries unchanged
and pass the documentation, reference and queue checks before packaging. The
delivered packet must then be independently reopened, including source snapshots,
source bridge, complete results and the retained earlier lint/recovery failures.

Residual scope: hosted/installed-package/other-platform acceptance, remaining
sampling strategies, subquery state, legacy standalone state, broader recovery,
generation-conditional replacement and all broader roadmap/competitive gates.
No version, release, publication or external runtime fallback is admitted.
