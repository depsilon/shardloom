"""Required serial Rust gates on the source frozen for the fresh timing UAT."""
import json
from pathlib import Path
import re
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sources, sha, save


def main():
    frozen_path = OUT / 'native-release-source-timing460.json'
    frozen = json.loads(frozen_path.read_text())
    assert sources() == frozen['source_sha256']
    prior_clippy_path = OUT / 'query-timing-460-clippy.json'
    prior_clippy = json.loads(prior_clippy_path.read_text())
    assert prior_clippy['status'] == 'passed' and prior_clippy['process_group_drained']
    assert sha(prior_clippy_path.with_suffix('.log')) == prior_clippy['log_sha256']
    assert prior_clippy['command'] == ['cargo','clippy','--offline','--locked','--workspace',
        '--all-targets','--features','shardloom-cli/release-user-surfaces,shardloom-python/python-native',
        '--','-D','warnings']
    checks = [
        ('fmt',180,['cargo','fmt','--all','--','--check']),
        ('workspace-clippy',1200,['cargo','clippy','--workspace','--all-targets','--','-D','warnings']),
        ('workspace-tests',1800,['cargo','test','--workspace','--all-targets','--','--test-threads=2']),
        ('read-clippy',1200,['cargo','clippy','--offline','--locked','-p','shardloom-vortex',
            '-p','shardloom-cli','--all-targets','--features','vortex-local-primitives','--','-D','warnings']),
        ('native-tests',3600,['cargo','test','--offline','--locked','-p','shardloom-vortex',
            '-p','shardloom-cli','--all-targets','--features',
            'vortex-local-primitives,vortex-write,universal-format-io','--','--test-threads=2']),
    ]
    protocol = dict(source_manifest=str(frozen_path),source_manifest_sha256=sha(frozen_path),
        helper_sha256=sha(__file__),checks=checks,
        retained_current_native_python_clippy=dict(path=str(prior_clippy_path),sha256=sha(prior_clippy_path)))
    save(OUT/'query-timing-check-protocol-461.json',protocol)
    records=[]
    failure=None
    try:
        for label,timeout,command in checks:
            assert sources()==frozen['source_sha256']
            name='query-timing-'+label+'-461'
            print(json.dumps(dict(stage=label,status='starting')),flush=True)
            subprocess.run([sys.executable,'-B',str(OUT/'run_guarded.py'),'--name',name,
                '--timeout',str(timeout),'--',*command],cwd=ROOT,check=True)
            path=OUT/(name+'.json');receipt=json.loads(path.read_text());log=path.with_suffix('.log')
            assert receipt['status']=='passed' and receipt['returncode']==0
            assert receipt['process_group_drained'] and receipt['direct_child_reaped']
            assert not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup']
            assert receipt['head']==frozen['head'] and sha(log)==receipt['log_sha256']
            record=dict(stage=label,receipt=str(path),receipt_sha256=sha(path),
                        log=str(log),log_sha256=sha(log),seconds=receipt['seconds'])
            if label.endswith('tests'):
                raw=log.read_text()
                groups=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',raw)
                assert groups and all(int(row[1])==int(row[3])==int(row[4])==0 for row in groups)
                ignored=re.findall(r'^test (.+) \.\.\. ignored, (.+)$',raw,re.M)
                assert sum(int(row[2]) for row in groups)==len(ignored)
                if label=='native-tests':
                    inventory=json.loads((OUT/'compression-manual-tests-inventory-456.json').read_text())
                    assert sorted(ignored)==sorted((row['test'],row['reason']) for row in inventory['tests'])
                    for row in inventory['tests']:
                        assert sha(ROOT/row['source'])==row['source_sha256']
                    for required in [
                        'native_query_timing_covers_public_count_aggregate_projection_sort_and_relational_results',
                        'prepared_native_query_timing_excludes_preparation_and_later_row_export',
                        'synchronous_sink_is_excluded_from_execution',
                    ]:
                        assert re.search(r'^test .*::'+required+r' \.\.\. ok$',raw,re.M),required
                else:
                    assert not ignored
                record['tests']=dict(passed=sum(int(row[0]) for row in groups),failed=0,
                                     ignored=len(ignored),groups=len(groups),ignored_declarations=ignored)
            records.append(record)
            print(json.dumps(dict(stage=label,status='passed',tests=record.get('tests'))),flush=True)
        assert sources()==frozen['source_sha256']
    except BaseException as error:
        failure=type(error).__name__+': '+str(error)
        raise
    finally:
        save(OUT/'query-timing-checks-461.json',dict(status='passed' if failure is None else 'failed',
            failure=failure,protocol=protocol,source_files=len(frozen['source_sha256']),
            source_identity_preserved=sources()==frozen['source_sha256'],completed=records))


if __name__=='__main__':
    main()
