"""Retain current-source gates, direct/public checks, documentation and failure history."""
import hashlib
import json
import lzma
import os
from pathlib import Path
import subprocess
import sys
import tarfile

from freeze_native_release_298 import ROOT, OUT, sha, sources, save
from package_selection_acceptance_409 import Members, verify, sha_stream
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

PREFIX = 'native-query-timing-acceptance-2026-10-15'
LOCAL = OUT / 'query-timing-acceptance-463'
DEST = ROOT / 'docs/benchmarks/evidence'


def bound(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def read(name):
    return json.loads((OUT / name).read_text())


def main():
    frozen = read('native-release-source-timing460.json')
    accepted = frozen['source_sha256']
    assert sources() == accepted
    checks = read('query-timing-checks-461b.json')
    runtime = read('query-timing-runtime-463.json')
    direct = read('query-timing-direct-tests-463.json')
    public = read('query-timing-public-inspection-463.json')
    artifact = read('query-timing-native-artifacts-461.json')
    docs = read('query-timing-documentation-461/summary.json')
    assert all(item['status'] == 'passed' for item in (checks, runtime, direct, public, artifact, docs))
    assert runtime['source_identity_preserved'] and artifact['source_sha256'] == accepted
    assert direct['tests'] == 80 and direct['failures'] == direct['errors'] == direct['skipped'] == 0
    assert public['cases'] == runtime['public_cases'] == 757 and public['families'] == 19
    assert public['complete_case_log_records_equal'] and public['frozen_sources_and_binary_unchanged']
    assert len(checks['completed']) == 5 and checks['source_identity_preserved']
    test_counts = {row['stage']: row['tests'] for row in checks['completed'] if 'tests' in row}
    assert test_counts['workspace-tests']['passed'] == 3219
    assert test_counts['native-tests']['passed'] == 4222
    assert test_counts['native-tests']['ignored'] == 29 and test_counts['workspace-tests']['ignored'] == 0
    for row in checks['completed']:
        assert sha(row['receipt']) == row['receipt_sha256'] and sha(row['log']) == row['log_sha256']
    assert len(docs['checks']) == 18 and docs['selected_sources_unchanged']
    assert all(row['returncode'] == 0 and sha(row['log']) == row['log_sha256'] for row in docs['checks'])
    old = read('compression-resources-457-source.json')['source_sha256']
    compression_paths = sorted(name for name in old if name.startswith(('vendor/vortex-zstd/',
        'vendor/vortex-array/', 'shardloom-vortex/src/native_provider_zstd',
        'shardloom-vortex/src/owned_buffers.rs')))
    assert compression_paths and all(old[name] == accepted[name] for name in compression_paths)
    vendor = read('compression-vendor-count-correction-457.json')
    assert vendor['status'] == 'passed' and vendor['total_passed'] == 72

    members, exclusions = Members(), []
    def add(path, prefix='evidence', role='closed acceptance or original failure history'):
        path = Path(path)
        parent = ROOT if path.is_relative_to(ROOT) else OUT
        relative = path.relative_to(parent).as_posix()
        members.add(path, prefix + '/' + relative, prefix, parent, role)
    for path in sorted(OUT.glob('query-timing-*')):
        if path.is_file() and path.suffix in {'.json', '.log', '.jpg'}:
            add(path)
    for name in ('native-release-source-timing460.json', 'compression-resources-457-source.json',
                 'compression-vendor-count-correction-457.json', 'compression-manual-tests-inventory-456.json',
                 'compression-browser-459.json', 'compression-public-docs-459.json',
                 'compression-static-followup-459.json', 'compression-static-followup-459.log',
                 'compression-static-followup-459b.json', 'compression-static-followup-459b.log'):
        add(OUT / name)
    for path in sorted(OUT.glob('compression-*-459.jpg')):
        add(path, 'rendered')
    for path in sorted(OUT.glob('*query_timing*.py')):
        add(path, 'tools', 'reproduction, verification or packaging helper')
    for name in ('freeze_native_release_298.py', 'run_guarded.py', 'package_selection_acceptance_409.py'):
        add(OUT / name, 'tools', 'shared reproduction helper')
    add(OUT / 'query-timing-python-463/lib/python3.12/site-packages/shardloom-acceptance.pth',
        'environment', 'private source-package environment; no installed-wheel claim')
    members.tree(OUT / 'query-timing-documentation-461', 'documentation', 'documentation',
                 'closed documentation build and validation', exclusions)
    members.tree(OUT / 'query-timing-public-463', 'public', 'public',
                 'complete public values, envelopes, pressure results and summaries', exclusions,
                 omit_outputs=True)
    for key in ('artifacts', 'value_files', 'envelopes', 'pressure_files'):
        for item in public[key]:
            verify(Path(item['path']), item['sha256'], item['bytes'])
    add(public['complete_case_set_comparison']['path'], 'public-inputs', 'unchanged full case inventory')
    for role in ('cli', 'binding'):
        item = artifact[role]
        verify(Path(item['path']), item['sha256'], item['bytes'])
        exclusions.append(dict(**item, reason='frozen native executable; bulk payload omitted'))
    changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT, text=True).splitlines()
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=ROOT, text=True).splitlines()
    overlay = sorted(set(changed + untracked) & set(accepted))
    for name in overlay:
        members.add(ROOT / name, 'source-overlay/' + name, 'repository', ROOT,
                    'complete current native/source overlay', accepted[name])
    add(ROOT / '.github/workflows/ci.yml', 'source-overlay', 'hosted validation wiring')
    companions = {}
    for stem in ('native-compression-resources-2026-10-15', 'native-query-timing-uat-2026-10-15',
                 'local-artifact-cleanup-2026-10-15'):
        index_path = DEST / (stem + '.json')
        add(index_path, 'companion-indices', 'immutable companion evidence identity')
        companions[stem] = bound(index_path)
        index = json.loads(index_path.read_text())
        archive = index.get('archive')
        if archive:
            path = DEST / archive.get('file', archive.get('path'))
            verify(path, archive['sha256'], archive.get('bytes'))
            companions[stem]['archive'] = bound(path)
    require_local_path(LOCAL, Path.home(), sys.platform)
    assert not LOCAL.exists()
    ordered = sorted(members.paths.values(), key=lambda item: item.name)
    raw_size = sum(item.size for item in ordered)
    assert raw_size <= 256 * MIB
    storage = check_budgets(OUT, LOCAL, OUT / 'logs', min_free_bytes=12 * GIB,
        reserve_bytes=raw_size + 64 * MIB, max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    LOCAL.mkdir()
    archive_path = LOCAL / (PREFIX + '.tar.xz')
    with archive_path.open('xb') as stream:
        with tarfile.open(fileobj=stream, mode='w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
            for item in ordered:
                verify(item.path, item.digest, item.size)
                info = tarfile.TarInfo(item.name)
                info.size, info.mode, info.mtime = item.size, 0o644, 0
                with item.path.open('rb') as source:
                    archive.addfile(info, source)
    seen = set()
    with tarfile.open(archive_path, mode='r|xz') as archive:
        for entry in archive:
            assert entry.isfile() and entry.name in members.names and entry.name not in seen
            item = members.paths[members.names[entry.name]]
            with archive.extractfile(entry) as stream:
                assert sha_stream(stream) == (item.size, item.digest)
            seen.add(entry.name)
    assert seen == set(members.names) and sources() == accepted
    for item in ordered:
        verify(item.path, item.digest, item.size)
    manifest = dict(status='passed', base_commit=frozen['head'], source_files=len(accepted),
        source_manifest=bound(OUT / 'native-release-source-timing460.json'),
        archive=bound(archive_path), source_overlay=overlay,
        members=[dict(path=str(item.path), archive_path=item.name, bytes=item.size,
                      sha256=item.digest, roles=item.roles) for item in ordered],
        member_count=len(ordered), raw_bytes=raw_size, raw_limit_bytes=256 * MIB,
        all_members_reopened=True, storage=storage, exclusions=exclusions,
        reused_compression_source_paths=compression_paths, companion_evidence=companions,
        acceptance=dict(workspace_tests=3219, native_tests=4222, native_manual_platform_exclusions=29,
            vendor_tests=72, direct_tests=80, public_cases=757, public_families=19,
            explicit_expected_value_files=len(public['value_files']),
            explicit_expected_value_rows=public['explicit_expected_value_rows'],
            envelopes=len(public['envelopes']), pressure_files=len(public['pressure_files']),
            pressure_rows=public['pressure_rows'], documentation_checks=18),
        failure_history=dict(direct_first_attempt='Nine missing-pyarrow child-process failures; private environment correction, same native binaries, all 80 pass.',
            broad_postcheck='One stale source hash in the manual-exclusion inventory; all 29 declarations preserved, completed native commands verified without rerunning.',
            verification_first_attempt='Corrected recognition of cfg_attr(unix, ignore) declarations without changing tests.',
            public_readback='First detailed readback report shared a name with its outer guard receipt; retained the successful log and repeated read-only inspection with distinct paths.'),
        source_identity_preserved=True, hosted_integration_complete=False,
        installed_wheel_proof=False, new_performance_measurement=False,
        limitations='Finite local source-package acceptance. Existing fresh Full43 and compression cost evidence remain separate and unchanged. No all-platform, process-RSS ceiling, cold-cache, speedup or new-release claim.')
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    compressed = lzma.compress(manifest_bytes, preset=6)
    assert lzma.decompress(compressed) == manifest_bytes
    manifest_path = LOCAL / (PREFIX + '.manifest.json.xz')
    with manifest_path.open('xb') as stream:
        stream.write(compressed)
    verification = dict(status='passed', all_members_reopened=True, member_count=len(seen),
        archive=bound(archive_path), manifest=bound(manifest_path),
        manifest_uncompressed_sha256=hashlib.sha256(manifest_bytes).hexdigest(),
        source_identity_preserved=True, helper=bound(__file__))
    verification_path = LOCAL / (PREFIX + '.verification.json')
    save(verification_path, verification)
    copied = {}
    for path in (archive_path, manifest_path, verification_path):
        target = DEST / path.name
        assert not target.exists()
        with target.open('xb') as output, path.open('rb') as source:
            while chunk := source.read(4 * MIB):
                output.write(chunk)
        assert sha(target) == sha(path)
        copied[path.suffix if path == archive_path else path.name] = bound(target)
    index = dict(schema_version='shardloom.native_query_timing_acceptance.v1',
        status='passed_local_acceptance_hosted_integration_pending', source_commit=frozen['head'],
        source_files=len(accepted), source_state='uncommitted_compression_and_query_timing',
        archive=dict(file=archive_path.name, bytes=archive_path.stat().st_size, sha256=sha(archive_path)),
        manifest=dict(file=manifest_path.name, bytes=manifest_path.stat().st_size, sha256=sha(manifest_path),
                      uncompressed_sha256=hashlib.sha256(manifest_bytes).hexdigest()),
        verification=dict(file=verification_path.name, sha256=sha(verification_path)),
        verified_members=len(seen), all_archive_members_reopened=True,
        acceptance=manifest['acceptance'], original_failure_history_preserved=True,
        source_identity_preserved=True, native_execution_rerun_for_packaging=False,
        fresh_uat='native-query-timing-uat-2026-10-15.json',
        compression_cost='native-compression-resources-2026-10-15.json',
        report='../native-query-timing-uat-2026-10-15.md', limitations=manifest['limitations'])
    save(DEST / (PREFIX + '.json'), index)
    save(OUT / 'query-timing-evidence-copy-463.json', dict(status='passed',
        index=bound(DEST / (PREFIX + '.json')), verification=bound(verification_path),
        copied=copied, source_identity_preserved=sources() == accepted))
    print(json.dumps(dict(status='passed', members=len(seen), archive_bytes=archive_path.stat().st_size,
                         archive_sha256=sha(archive_path), raw_bytes=raw_size)))


if __name__ == '__main__':
    main()
