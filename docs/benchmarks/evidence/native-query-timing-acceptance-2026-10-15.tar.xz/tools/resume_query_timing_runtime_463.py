"""Complete direct/public checks with dependencies visible to isolated child jobs."""
import json
from pathlib import Path
import subprocess
import sys
import venv

import run_query_timing_runtime_461 as prior
from freeze_native_release_298 import ROOT, OUT, sha, save

ENV = OUT / 'query-timing-python-463'
PYTHON = ENV / 'bin/python'
DIRECT = OUT / 'query-timing-direct-tests-463.json'
PUBLIC = OUT / 'query-timing-public-463'
SUMMARY = OUT / 'query-timing-runtime-463.json'


def direct():
    prior.TEST_PYTHON = PYTHON
    prior.DIRECT = DIRECT
    prior.direct()


def main():
    manifest = prior.load()
    failed_path = OUT / 'query-timing-direct-461.json'
    failed = json.loads(failed_path.read_text())
    assert failed['status'] == 'failed' and failed['process_group_drained']
    failed_log = failed_path.with_suffix('.log')
    assert sha(failed_log) == failed['log_sha256']
    assert failed_log.read_text().count("ModuleNotFoundError: No module named 'pyarrow'") == 9
    failed_tests = json.loads((OUT / 'query-timing-direct-tests-461.json').read_text())
    assert failed_tests['tests'] == 80 and failed_tests['failures'] == 9
    assert failed_tests['errors'] == failed_tests['skipped'] == 0
    assert not ENV.exists() and not DIRECT.exists() and not PUBLIC.exists() and not SUMMARY.exists()
    # Isolated Python (-I) intentionally ignores PYTHONPATH. A private environment
    # exposes the already-retained dependencies through its own site-packages.
    # No package is fetched, duplicated, or installed into the shared runtime.
    venv.EnvBuilder(with_pip=False).create(ENV)
    site = ENV / f'lib/python{sys.version_info.major}.{sys.version_info.minor}/site-packages'
    path_file = site / 'shardloom-acceptance.pth'
    path_file.write_text(str(prior.PYTHON_DEPS) + '\n' + str(ROOT / 'python/src') + '\n')
    probe = subprocess.run([str(PYTHON), '-I', '-c',
        'import json,pyarrow,shardloom,sys; print(json.dumps(dict(interpreter=sys.executable, '
        'pyarrow=pyarrow.__file__,version=pyarrow.__version__,package=shardloom.__file__, '
        'isolated=sys.flags.isolated)))'], check=True, capture_output=True, text=True, timeout=30)
    observed = json.loads(probe.stdout)
    assert Path(observed['interpreter']) == PYTHON and observed['isolated'] == 1
    assert Path(observed['pyarrow']).is_relative_to(prior.PYTHON_DEPS)
    assert Path(observed['package']) == ROOT / 'python/src/shardloom/__init__.py'
    save(OUT / 'query-timing-python-environment-463.json', dict(status='passed',
        observation=observed, path_file=str(path_file), path_file_sha256=sha(path_file),
        setup='private_venv_with_existing_dependency_paths', network_used=False,
        installed_wheel_proof=False, original_failure=str(failed_path),
        original_failure_sha256=sha(failed_path), helper_sha256=sha(__file__)))
    prior.guarded('query-timing-direct-463', 1800, [PYTHON, '-B', __file__, 'direct'])
    direct_report = json.loads(DIRECT.read_text())
    assert direct_report['status'] == 'passed' and direct_report['tests'] == 80
    prior.guarded('query-timing-public-463', 5400,
        [sys.executable, '-B', ROOT / 'scripts/run_native_streaming_input_uat.py',
         '--binary', manifest['cli']['path'], '--uat-root', PUBLIC, '--operation-timeout', '600'])
    public_path = PUBLIC / 'summary.json'
    public = json.loads(public_path.read_text())
    assert public['status'] == 'passed'
    assert len(public['families']) == len(set(public['families'])) == 19
    assert len(public['cases']) == len({case['name'] for case in public['cases']}) == 757
    assert all(case['status'] == 'passed' for case in public['cases'])
    assert prior.load() == manifest
    save(SUMMARY, dict(status='passed', manifest=str(prior.MANIFEST), manifest_sha256=sha(prior.MANIFEST),
        direct_summary=str(DIRECT), direct_summary_sha256=sha(DIRECT),
        public_summary=str(public_path), public_summary_sha256=sha(public_path),
        public_families=public['families'], public_cases=len(public['cases']),
        source_identity_preserved=True, full43='fresh_461_passed_before_these_checks',
        cost_screen='compression_456c_retained_for_unchanged_compressor_sources',
        helper=str(Path(__file__).resolve()), helper_sha256=sha(__file__),
        original_runtime_helper=str(Path(prior.__file__).resolve()),
        original_runtime_helper_sha256=sha(prior.__file__),
        original_direct_failure=str(failed_path), original_direct_failure_sha256=sha(failed_path),
        environment_receipt=str(OUT / 'query-timing-python-environment-463.json')))
    print(json.dumps(dict(status='passed', direct_tests=80, public_cases=757, public_families=19)))


if __name__ == '__main__':
    direct() if sys.argv[1:] == ['direct'] else main()
