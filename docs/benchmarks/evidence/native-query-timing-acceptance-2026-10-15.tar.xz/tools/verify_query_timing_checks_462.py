"""Verify completed gates and refresh unchanged manual declarations on frozen source."""
import json
import re
from pathlib import Path

from freeze_native_release_298 import ROOT, OUT, sha, sources, save


def main():
    source_path = OUT / 'native-release-source-timing460.json'
    source = json.loads(source_path.read_text())
    assert sources() == source['source_sha256']
    failed_path = OUT / 'query-timing-checks-461.json'
    original = json.loads(failed_path.read_text())
    assert original['status'] == 'failed' and original['source_identity_preserved']
    assert original['failure'] == 'AssertionError: '
    assert original['protocol']['source_manifest_sha256'] == sha(source_path)
    old_inventory_path = OUT / 'compression-manual-tests-inventory-456.json'
    old_inventory = json.loads(old_inventory_path.read_text())
    current_tests, changed_files = [], set()
    for row in old_inventory['tests']:
        path = ROOT / row['source']
        digest = sha(path)
        assert digest == source['source_sha256'][row['source']]
        lines = path.read_text().splitlines()
        declaration = row['declaration']
        starts = [i for i in range(len(lines)) if lines[i:i+len(declaration)] == declaration]
        assert len(starts) == 1, row['test']
        assert 'ignore = ' in '\n'.join(declaration)
        assert row['reason'] in '\n'.join(declaration)
        current_tests.append(dict(row, source_sha256=digest, line=starts[0]+1))
        if digest != row['source_sha256']:
            changed_files.add(row['source'])
    assert changed_files == {'shardloom-vortex/src/local_primitives.rs'}
    inventory_path = OUT / 'query-timing-manual-tests-inventory-462.json'
    assert not inventory_path.exists()
    save(inventory_path, dict(status='passed', test_count=len(current_tests), tests=current_tests,
         prior_inventory=str(old_inventory_path), prior_inventory_sha256=sha(old_inventory_path),
         source_manifest=str(source_path), source_manifest_sha256=sha(source_path),
         changed_files=sorted(changed_files), declarations_identical=True))

    completed = []
    for label, _, expected_command in original['protocol']['checks']:
        path = OUT / ('query-timing-'+label+'-461.json')
        receipt = json.loads(path.read_text())
        log = path.with_suffix('.log')
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['command'] == expected_command
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup']
        assert receipt['head'] == source['head'] and sha(log) == receipt['log_sha256']
        record = dict(stage=label,receipt=str(path),receipt_sha256=sha(path),
                      log=str(log),log_sha256=sha(log),seconds=receipt['seconds'])
        if label.endswith('tests'):
            raw = log.read_text()
            groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',raw)
            assert groups and all(int(row[1]) == int(row[3]) == int(row[4]) == 0 for row in groups)
            ignored = re.findall(r'^test (.+) \.\.\. ignored, (.+)$',raw,re.M)
            assert sum(int(row[2]) for row in groups) == len(ignored)
            passed = sum(int(row[0]) for row in groups)
            if label == 'native-tests':
                assert passed == 4222 and len(ignored) == 29
                assert sorted(ignored) == sorted((r['test'],r['reason']) for r in current_tests)
                for name in (
                    'native_query_timing_covers_public_count_aggregate_projection_sort_and_relational_results',
                    'prepared_native_query_timing_excludes_preparation_and_later_row_export',
                    'synchronous_sink_is_excluded_from_execution',
                ):
                    assert re.search(r'^test .*::'+name+r' \.\.\. ok$',raw,re.M),name
            else:
                assert passed == 3219 and not ignored
            record['tests'] = dict(passed=passed,failed=0,ignored=len(ignored),groups=len(groups),
                                   ignored_declarations=ignored)
        completed.append(record)
    retained = original['protocol']['retained_current_native_python_clippy']
    assert sha(retained['path']) == retained['sha256']
    receipt = json.loads(Path(retained['path']).read_text())
    assert receipt['status'] == 'passed' and receipt['process_group_drained']
    assert sha(Path(retained['path']).with_suffix('.log')) == receipt['log_sha256']
    assert sources() == source['source_sha256']
    target = OUT / 'query-timing-checks-461b.json'
    assert not target.exists()
    save(target,dict(status='passed',failure=None,protocol=original['protocol'],
        completed=completed,source_files=len(source['source_sha256']),source_identity_preserved=True,
        original_failed_postcheck=dict(path=str(failed_path),sha256=sha(failed_path)),
        current_manual_inventory=dict(path=str(inventory_path),sha256=sha(inventory_path)),
        verification_helper=dict(path=str(Path(__file__).resolve()),sha256=sha(__file__)),
        correction='Refresh one module hash and declaration location after timing registration; all 29 exclusion declarations are byte-identical. Preserve all original runs and the failed postcheck.',
        native_commands_rerun=False))
    print(json.dumps(dict(status='passed',workspace_tests=3219,native_tests=4222,
                          manual_exclusions=29,source_files=len(source['source_sha256']),path=str(target))))


if __name__ == '__main__':
    main()
