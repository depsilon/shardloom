"""Validate compression and query-timing documentation and the generated guide."""
import json
from pathlib import Path
import re
import subprocess
import sys
import time

from freeze_native_release_298 import ROOT, OUT, sha, sources, save

DEST = OUT / 'query-timing-documentation-461'
NODE = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
SITE = ROOT / 'website-src'


def main():
    accepted = json.loads((OUT / 'native-release-source-timing460.json').read_text())['source_sha256']
    assert sources() == accepted
    workflow = sha(ROOT / '.github/workflows/ci.yml')
    DEST.mkdir()
    node = lambda *args: [NODE, *map(str, args)]
    python = lambda *args: [sys.executable, '-B', *map(str, args)]
    commands = [
        ('search-policy', node('scripts/pagefind-policy.test.mjs'), SITE),
        ('static-reset', node('scripts/prebuild-static.mjs', '--reset-output'), SITE),
        ('sync-content', node('scripts/sync-content.mjs'), SITE),
        ('astro-build', node('node_modules/astro/bin/astro.mjs', 'build'), SITE),
        ('static-postbuild', node('scripts/postbuild-static.mjs'), SITE),
        ('check-preparation', node('scripts/prebuild-static.mjs'), SITE),
        ('check-content', node('scripts/sync-content.mjs'), SITE),
        ('astro-check', node('node_modules/astro/bin/astro.mjs', 'check'), SITE),
        ('check-settle', node('scripts/prebuild-static.mjs', '--settle-output'), SITE),
        ('public-status', python('scripts/check_public_status_docs.py', '--output', DEST / 'public-status.json'), ROOT),
        ('website-links', python('-m', 'unittest', 'discover', '-s', 'scripts', '-p', 'test_website_links.py'), ROOT),
        ('website-readiness', python('scripts/check_website_readiness.py', '--output', DEST / 'website-readiness.json'), ROOT),
        ('static-assets', node('scripts/validate_static_assets.cjs'), ROOT),
        ('user-surface', python('scripts/check_user_surface_reference.py'), ROOT),
        ('use-case-backlinks', python('scripts/check_use_case_backlinks.py'), ROOT),
        ('contribution-governance', python('scripts/check_contribution_governance.py', '--output', DEST / 'contribution-governance.json'), ROOT),
        ('ci-gate-matrix', python('scripts/check_ci_gate_matrix.py', '--output', DEST / 'ci-gate-matrix.json'), ROOT),
        ('diff-check', ['git', 'diff', '--check'], ROOT),
    ]
    commands[0][1].insert(1, '--test')
    completed, failure, links = [], None, []
    try:
        for name, command, cwd in commands:
            log = DEST / (name + '.log')
            start = time.monotonic()
            with log.open('xb') as output:
                result = subprocess.run(command, cwd=cwd, stdout=output, stderr=subprocess.STDOUT, timeout=300)
            row = dict(name=name, command=command, cwd=str(cwd), returncode=result.returncode,
                seconds=time.monotonic()-start, log=str(log), log_sha256=sha(log))
            completed.append(row)
            print(json.dumps(row), flush=True)
            result.check_returncode()
        changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT, text=True).splitlines()
        untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=ROOT, text=True).splitlines()
        documents = sorted(name for name in set(changed + untracked) if name.endswith('.md'))
        for name in documents:
            path = ROOT / name
            for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^\s)]+)\)', path.read_text()):
                if target.startswith(('https:', 'http:', 'mailto:', '#')):
                    continue
                destination = (path.parent / target.split('#', 1)[0]).resolve()
                assert destination.exists(), (name, target)
                links.append(dict(document=name, target=target))
        assert sources() == accepted and sha(ROOT / '.github/workflows/ci.yml') == workflow
        for name in ('runtime-and-io', 'limitations'):
            generated = ROOT / 'website/field-guide' / name / 'index.html'
            text = generated.read_text()
            assert 'native-compression-resources-2026-10-15.md' in text
            assert 'immutable' in text and '0.6.0 packages' in text
        benchmark = (ROOT / 'website/field-guide/benchmark-methodology/index.html').read_text()
        assert 'native-query-timing-uat-2026-10-15.md' in benchmark
        assert 'query-timings.csv' in benchmark and '62.560 s' in benchmark
        assert 'Other process work' in benchmark and 'Source preparation' in benchmark
    except BaseException as error:
        failure = f'{type(error).__name__}: {error}'
        raise
    finally:
        save(DEST / 'summary.json', dict(status='passed' if failure is None else 'failed',
            failure=failure, checks=completed, local_links=links,
            selected_sources_unchanged=sources() == accepted,
            source_files=len(accepted), workflow_sha256=workflow,
            helper_sha256=sha(__file__), rendered_browser_verification=False,
            native_workloads_rerun=False))
    print(json.dumps(dict(status='passed', checks=len(completed), local_links=len(links))))


if __name__ == '__main__':
    main()
