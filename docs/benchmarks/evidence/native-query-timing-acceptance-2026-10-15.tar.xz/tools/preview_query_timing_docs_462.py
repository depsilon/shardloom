"""Serve generated documentation briefly for a local browser acceptance check."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import time

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
stop = OUT / 'query-timing-doc-preview-stop-462'
assert not stop.exists()
server = ThreadingHTTPServer(('127.0.0.1', 0),
                            partial(SimpleHTTPRequestHandler, directory=str(ROOT / 'website')))
server.timeout = 0.2
address = f'http://127.0.0.1:{server.server_port}'
with (OUT / 'query-timing-doc-preview-address-462.json').open('x') as stream:
    json.dump({'address': address}, stream)
print(address, flush=True)
deadline = time.monotonic() + 600
try:
    while not stop.exists() and time.monotonic() < deadline:
        server.handle_request()
finally:
    server.server_close()
assert stop.exists(), 'bounded preview timed out before explicit completion'
print('preview closed', flush=True)
