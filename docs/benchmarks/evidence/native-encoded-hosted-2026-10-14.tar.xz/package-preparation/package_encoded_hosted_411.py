"""Prepare a deterministic, integrity-checked archive of hosted evidence 410.

This helper is intentionally not run as part of preparation. It writes only the
archive, its member manifest, and a verification record under O, and refuses to
overwrite any of them.
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import stat
import tarfile


O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
ARCHIVE = O / 'encoded-hosted-evidence-411.tar.xz'
MANIFEST = O / 'encoded-hosted-evidence-411.manifest.json'
VERIFICATION = O / 'encoded-hosted-evidence-411.verification.json'
MAX_MEMBER_BYTES = 32 * 1024 * 1024
MAX_RAW_BYTES = 32 * 1024 * 1024
BLOCK_BYTES = 1024 * 1024


def read_json(path: Path) -> dict:
    with path.open('r', encoding='utf-8') as stream:
        return json.load(stream)


def digest_file(path: Path) -> tuple[int, str]:
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        while block := stream.read(BLOCK_BYTES):
            size += len(block)
            digest.update(block)
    return size, digest.hexdigest()


def identity(path: Path) -> dict:
    before = path.stat(follow_symlinks=False)
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError(f'expected regular file: {path}')
    size, sha256 = digest_file(path)
    after = path.stat(follow_symlinks=False)
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (
        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns
    ) or size != before.st_size:
        raise RuntimeError(f'input changed while hashing: {path}')
    if size > MAX_MEMBER_BYTES:
        raise RuntimeError(f'input exceeds 32 MiB raw-member ceiling: {path} ({size})')
    return {
        'bytes': size,
        'sha256': sha256,
        'stat': {
            'device': before.st_dev,
            'inode': before.st_ino,
            'mtime_ns': before.st_mtime_ns,
            'size': before.st_size,
        },
    }


def add(entries: list[tuple[Path, str]], source: Path, member: str) -> None:
    if source.is_symlink() or not source.is_file():
        raise RuntimeError(f'missing or non-regular package input: {source}')
    if Path(member).is_absolute() or '..' in Path(member).parts:
        raise RuntimeError(f'unsafe archive member name: {member}')
    if any(name == member or path == source for path, name in entries):
        raise RuntimeError(f'duplicate package source or archive name: {source} -> {member}')
    entries.append((source, member))


def expected_entries(inventory: dict, runtime: dict) -> list[tuple[Path, str]]:
    entries: list[tuple[Path, str]] = []
    api = inventory.get('raw_api_responses')
    jobs = runtime.get('jobs')
    if not isinstance(api, list) or len(api) != 19:
        raise RuntimeError('inventory must contain exactly 19 raw API response records')
    if not isinstance(jobs, list) or len(jobs) != 8:
        raise RuntimeError('runtime inventory must contain exactly 8 hosted job logs')

    for record in api:
        source = Path(record['path'])
        if not source.is_relative_to(O):
            raise RuntimeError(f'raw API response outside evidence root: {source}')
        add(entries, source, f"hosted-api/{source.name}")
    for job in jobs:
        source = Path(job['log']['path'])
        if not source.is_relative_to(O):
            raise RuntimeError(f'hosted log outside evidence root: {source}')
        add(entries, source, f"hosted-runtime/{source.name}")

    fixed = [
        (O / 'encoded-hosted-inventory-410.json', 'inventories/encoded-hosted-inventory-410.json'),
        (O / 'encoded-hosted-runtime-410.json', 'inventories/encoded-hosted-runtime-410.json'),
        (O / 'encoded-hosted-primary-410.json', 'primary-review/encoded-hosted-primary-410.json'),
        (O / 'review_encoded_hosted_410.py', 'primary-review/review_encoded_hosted_410.py'),
        (O / 'native-release-artifacts-376c.json', 'source-manifests/native-release-artifacts-376c.json'),
        (O / 'zstd-views-base-386-release.json', 'source-manifests/zstd-views-base-386-release.json'),
        (O / 'pr1547-merge-verification-388.json', 'immutable-review/pr1547-merge-verification-388.json'),
        (R / 'docs/benchmarks/evidence/native-encoded-ipc-admission-2026-10-13.json.xz',
         'immutable-review/native-encoded-ipc-admission-2026-10-13.json.xz'),
        (Path(__file__).resolve(), 'package-preparation/package_encoded_hosted_411.py'),
        (O / 'encoded-hosted-package-plan-411.json', 'package-preparation/encoded-hosted-package-plan-411.json'),
    ]
    for source, member in fixed:
        add(entries, source, member)
    if len(entries) != 37:
        raise RuntimeError(f'expected 37 deterministic inputs, found {len(entries)}')
    return sorted(entries, key=lambda pair: pair[1])


def require_primary_contract(inventory: dict, runtime: dict, primary: dict,
                             entries: list[tuple[Path, str]]) -> None:
    if primary.get('schema') != 'shardloom.encoded_hosted_primary_review.v1' or primary.get('status') != 'passed':
        raise RuntimeError('primary hosted review is not passed')
    prs = {record['number']: record for record in primary.get('pull_requests', [])}
    expected = {
        1545: ('230d5908cb8d34968406395a31df2354214a847d', 43),
        1547: ('ea175308777da778c88d446e239d628ff9953fa2', 44),
    }
    if set(prs) != set(expected):
        raise RuntimeError('primary review PR set is not exactly #1545 and #1547')
    for number, (head, check_count) in expected.items():
        pr = prs[number]
        if pr.get('head') != head or pr.get('checks') != check_count or len(pr.get('jobs', [])) != 4:
            raise RuntimeError(f'primary review identity mismatch for PR #{number}')
        pr_raw_path = O / f'encoded-hosted-pr{number}-raw.json'
        checks_path = O / f'encoded-hosted-pr{number}-checks-raw.json'
        raw_pr = read_json(pr_raw_path)
        raw_checks = read_json(checks_path)
        checks = raw_checks.get('check_runs', [])
        if (raw_pr.get('number') != number or raw_pr.get('merged') is not True
                or raw_pr.get('state') != 'closed' or raw_pr.get('head', {}).get('sha') != head):
            raise RuntimeError(f'raw merged PR identity mismatch for PR #{number}')
        if (raw_checks.get('total_count') != check_count or len(checks) != check_count
                or any(check.get('status') != 'completed'
                       or check.get('conclusion') != 'success'
                       or check.get('head_sha') != head for check in checks)
                or len({check.get('name') for check in checks}) != check_count):
            raise RuntimeError(f'raw successful-check evidence mismatch for PR #{number}')
    wheels = [job for pr in prs.values() for job in pr['jobs']
              if job.get('job_name', '').startswith('Native Python wheel')]
    if len(wheels) != 6:
        raise RuntimeError('expected six hosted installed-wheel records')
    for job in wheels:
        integration = job.get('integration', {})
        installed = job.get('installed_load', {})
        if (integration != {'tests': 80, 'failures': 0, 'errors': 0,
                            'skipped': 0, 'status': 'passed'}
                or installed.get('isolated_install') is not True
                or installed.get('version') != '0.5.1'):
            raise RuntimeError(f'installed-wheel proof contract mismatch: {job.get("job_name")}')
    if len(runtime.get('jobs', [])) != 8:
        raise RuntimeError('expected eight raw hosted job logs')
    if len(inventory.get('raw_api_responses', [])) != 19:
        raise RuntimeError('expected 19 raw REST/GraphQL responses')

    by_source = {str(source): source for source, _ in entries}
    for record in inventory['raw_api_responses']:
        path = str(Path(record['path']))
        if path not in by_source:
            raise RuntimeError(f'inventory API response not in package: {path}')
    for job in runtime['jobs']:
        path = str(Path(job['log']['path']))
        if path not in by_source:
            raise RuntimeError(f'runtime log not in package: {path}')

    acceptance = primary.get('source_acceptance', {})
    if not (acceptance.get('all_2219_sources_match_merged_pr1545') is True
            and acceptance.get('all_2221_sources_match_pr1547_head') is True
            and acceptance.get('production_sources_unchanged_in_pr1547_merge') is True):
        raise RuntimeError('source acceptance contract is incomplete')


def stable_tar_info(name: str, size: int) -> tarfile.TarInfo:
    info = tarfile.TarInfo(name)
    info.size = size
    info.mtime = 0
    info.mode = 0o644
    info.uid = info.gid = 0
    info.uname = info.gname = ''
    return info


class HashingReader:
    """A read-through wrapper that hashes exactly the bytes tarfile consumes."""

    def __init__(self, stream):
        self.stream = stream
        self.digest = hashlib.sha256()
        self.size = 0

    def read(self, size: int = -1) -> bytes:
        block = self.stream.read(size)
        self.digest.update(block)
        self.size += len(block)
        return block


def write_exclusive_json(path: Path, value: dict) -> None:
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def main() -> None:
    outputs = (ARCHIVE, MANIFEST, VERIFICATION)
    if any(path.exists() for path in outputs):
        raise FileExistsError('one or more package outputs already exist; refusing overwrite')

    inventory_path = O / 'encoded-hosted-inventory-410.json'
    runtime_path = O / 'encoded-hosted-runtime-410.json'
    primary_path = O / 'encoded-hosted-primary-410.json'
    inventory = read_json(inventory_path)
    runtime = read_json(runtime_path)
    primary = read_json(primary_path)
    entries = expected_entries(inventory, runtime)
    require_primary_contract(inventory, runtime, primary, entries)

    before = {str(path): identity(path) for path, _ in entries}
    raw_bytes = sum(record['bytes'] for record in before.values())
    if raw_bytes > MAX_RAW_BYTES:
        raise RuntimeError(f'package input exceeds the 32 MiB total raw-byte ceiling: {raw_bytes}')
    # Bind every original primary-review input to the exact reviewed bytes.
    primary_inputs = [primary[key] for key in ('raw_inventory', 'raw_runtime', 'helper')]
    primary_inputs.extend(primary['source_acceptance'][key]
                          for key in ('original_manifest', 'pr1547_manifest', 'runend_correction'))
    for pr in primary['pull_requests']:
        primary_inputs.extend(pr[key] for key in ('raw_pr', 'raw_checks'))
        primary_inputs.extend(job['log'] for job in pr['jobs'])
    for record in primary_inputs:
        observed = before[record['path']]
        if any(observed[key] != record[key] for key in ('bytes', 'sha256')):
            raise RuntimeError(f'primary-review input changed: {record["path"]}')
    inventory_records = {record['path']: record for record in inventory['raw_api_responses']}
    runtime_records = {job['log']['path']: job['log'] for job in runtime['jobs']}
    for source, _ in entries:
        expected = inventory_records.get(str(source)) or runtime_records.get(str(source))
        if expected and (before[str(source)]['bytes'] != expected['bytes']
                         or before[str(source)]['sha256'] != expected['sha256']):
            raise RuntimeError(f'raw evidence identity mismatch: {source}')

    manifest_members = []
    fd = os.open(ARCHIVE, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, 'wb') as archive_stream:
            with tarfile.open(fileobj=archive_stream, mode='w:xz', preset=6) as archive:
                for source, member in entries:
                    expected = before[str(source)]
                    with source.open('rb') as stream:
                        hashing_stream = HashingReader(stream)
                        info = stable_tar_info(member, expected['bytes'])
                        archive.addfile(info, fileobj=hashing_stream)
                    if (hashing_stream.size != expected['bytes']
                            or hashing_stream.digest.hexdigest() != expected['sha256']):
                        raise RuntimeError(f'input changed during archive write: {source}')
                    manifest_members.append({
                        'archive_path': member,
                        'original_path': str(source),
                        'bytes': hashing_stream.size,
                        'sha256': hashing_stream.digest.hexdigest(),
                    })
    except Exception:
        ARCHIVE.unlink(missing_ok=True)
        raise

    after = {str(path): identity(path) for path, _ in entries}
    if before != after:
        ARCHIVE.unlink(missing_ok=True)
        raise RuntimeError('one or more package inputs changed during packaging')

    verified = []
    with tarfile.open(ARCHIVE, mode='r|xz') as archive:
        expected_by_name = {record['archive_path']: record for record in manifest_members}
        if len(expected_by_name) != len(manifest_members):
            raise RuntimeError('duplicate archive member name')
        for member in archive:
            if not member.isfile() or member.name not in expected_by_name or member.name in verified:
                raise RuntimeError(f'unexpected archive member: {member.name}')
            record = expected_by_name[member.name]
            stream = archive.extractfile(member)
            if stream is None:
                raise RuntimeError(f'cannot read archive member: {member.name}')
            digest = hashlib.sha256()
            size = 0
            with stream:
                while block := stream.read(BLOCK_BYTES):
                    size += len(block)
                    digest.update(block)
            if size != record['bytes'] or digest.hexdigest() != record['sha256']:
                raise RuntimeError(f'archive member differs from source: {member.name}')
            verified.append(member.name)
    if set(verified) != set(expected_by_name):
        raise RuntimeError('archive member coverage mismatch')

    archive_bytes, archive_sha256 = digest_file(ARCHIVE)
    manifest = {
        'schema': 'shardloom.encoded_hosted_evidence_bundle_manifest.v1',
        'archive': {'path': str(ARCHIVE), 'bytes': archive_bytes, 'sha256': archive_sha256},
        'member_count': len(manifest_members),
        'raw_input_bytes': raw_bytes,
        'max_raw_input_bytes': MAX_RAW_BYTES,
        'max_raw_member_bytes': MAX_MEMBER_BYTES,
        'members': manifest_members,
    }
    verification = {
        'schema': 'shardloom.encoded_hosted_evidence_bundle_verification.v1',
        'status': 'passed',
        'archive': {'path': str(ARCHIVE), 'bytes': archive_bytes, 'sha256': archive_sha256},
        'member_count': len(verified),
        'all_members_stream_verified': True,
        'all_sources_unchanged_before_after': True,
        'github_approval_or_thread_resolution_implied': False,
        'publication_attempted': False,
        'public_production_website_observation_added': False,
    }
    write_exclusive_json(MANIFEST, manifest)
    write_exclusive_json(VERIFICATION, verification)
    print(json.dumps({'status': 'passed', 'members': len(verified),
                      'archive': str(ARCHIVE), 'manifest': str(MANIFEST),
                      'verification': str(VERIFICATION)}))


if __name__ == '__main__':
    main()
