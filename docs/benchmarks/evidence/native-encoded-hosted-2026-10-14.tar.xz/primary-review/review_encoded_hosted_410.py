"""Bind historical encoded-transfer acceptance to immutable merged GitHub heads."""
import hashlib
import json
import lzma
from pathlib import Path
import re
import subprocess

O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bound(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def git(*args):
    return subprocess.check_output(['git', *args], cwd=R).decode().strip()


def source_hashes(revision, names):
    process = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=R,
                               stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    result = {}
    try:
        for name in sorted(names):
            process.stdin.write(f'{revision}:{name}\n'.encode())
            process.stdin.flush()
            header = process.stdout.readline().decode().split()
            assert len(header) == 3 and header[1] == 'blob', (revision, name, header)
            remaining = int(header[2])
            digest = hashlib.sha256()
            while remaining:
                block = process.stdout.read(min(remaining, 1 << 20))
                assert block
                digest.update(block)
                remaining -= len(block)
            assert process.stdout.read(1) == b'\n'
            result[name] = digest.hexdigest()
    finally:
        process.stdin.close()
        assert process.wait() == 0
    return result


inventory = read(O / 'encoded-hosted-inventory-410.json')
runtime = read(O / 'encoded-hosted-runtime-410.json')
for record in inventory['raw_api_responses']:
    assert bound(record['path']) == record
prs = []
for number, count in ((1545, 43), (1547, 44)):
    pr_path = O / f'encoded-hosted-pr{number}-raw.json'
    checks_path = O / f'encoded-hosted-pr{number}-checks-raw.json'
    pr = read(pr_path)
    checks = read(checks_path)
    assert pr['number'] == number and pr['merged'] and pr['state'] == 'closed'
    assert checks['total_count'] == len(checks['check_runs']) == count
    assert all(c['status'] == 'completed' and c['conclusion'] == 'success'
               and c['head_sha'] == pr['head']['sha'] for c in checks['check_runs'])
    assert len({c['name'] for c in checks['check_runs']}) == count
    subprocess.run(['git', 'merge-base', '--is-ancestor', pr['merge_commit_sha'], 'HEAD'],
                   cwd=R, check=True)
    jobs = []
    selected = [j for j in runtime['jobs'] if j['pull_request'] == number]
    assert len(selected) == 4
    for job in selected:
        identity = job['log']
        assert bound(identity['path']) == {k: identity[k] for k in ('path', 'bytes', 'sha256')}
        assert job['head_sha'] == pr['head']['sha']
        matches = [c for c in checks['check_runs'] if c['name'] == job['job_name']]
        assert len(matches) == 1 and matches[0]['details_url'].endswith(f"/job/{job['job_id']}")
        assert f"/runs/{job['workflow_run_id']}/" in matches[0]['details_url']
        raw = Path(identity['path']).read_text()
        plain = '\n'.join(re.sub(r'^[^\t]*\t[^\t]*\t\S+\s', '', line)
                          for line in raw.splitlines())
        record = dict(job_name=job['job_name'], job_id=job['job_id'],
                      run_id=job['workflow_run_id'], url=matches[0]['details_url'],
                      log=bound(identity['path']))
        if job['job_name'].startswith('Native Python wheel'):
            marker = '{\n  "schema_version": "shardloom.native_python_wheel_proof.v1"'
            assert plain.count(marker) == 1
            proof, _ = json.JSONDecoder().raw_decode(plain[plain.index(marker):])
            assert proof['status'] == proof['stage']['status'] == proof['integrity']['status'] == 'passed'
            assert proof['integration'] == dict(tests=80, failures=0, errors=0, skipped=0, status='passed')
            assert proof['installed_load']['isolated_install']
            assert proof['publication_attempted'] is False and proof['performance_claim'] is False
            assert all(step['returncode'] == 0 for step in proof['steps'])
            record.update(platform=proof['platform'], python=proof['python'],
                          integration=proof['integration'], installed_load=proof['installed_load'],
                          integrity=proof['integrity'], stage=proof['stage'])
        else:
            groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', plain)
            assert len(groups) == 3 and all(int(g[1]) == int(g[3]) == 0 for g in groups)
            names = ['ipc_rejects_empty_run_ends_for_nonempty_records',
                     'null_record_views_keep_receiving_credit_without_payload_buffers',
                     'encoded_transfer_preserves_complete_values_validity_and_physical_trees']
            lines = [next(line for line in plain.splitlines()
                          if f'::{name} ... ok' in line) for name in names]
            record.update(cargo_groups=[dict(zip(('passed', 'failed', 'ignored', 'measured', 'filtered'),
                                                 map(int, group))) for group in groups],
                          specific_regressions=lines)
        jobs.append(record)
    prs.append(dict(number=number, url=pr['html_url'], head=pr['head']['sha'],
                    merge=pr['merge_commit_sha'], merged_at=pr['merged_at'],
                    checks=count, raw_pr=bound(pr_path), raw_checks=bound(checks_path), jobs=jobs))

manifest = read(O / 'native-release-artifacts-376c.json')
assert len(manifest['source_sha256']) == 2219
with lzma.open(R / 'docs/benchmarks/evidence/native-encoded-ipc-admission-2026-10-13.json.xz', 'rt') as stream:
    correction = json.load(stream)
expected = dict(manifest['source_sha256'])
for name, record in correction['review']['source_before_after'].items():
    assert expected[name] == record['before_sha256']
    expected[name] = record['after_sha256']
assert len(correction['review']['source_before_after']) == 3
assert source_hashes(prs[0]['head'], expected) == expected
assert git('rev-parse', prs[0]['head'] + '^{tree}') == git('rev-parse', prs[0]['merge'] + '^{tree}')

later_manifest_path = O / 'zstd-views-base-386-release.json'
later = read(later_manifest_path)
assert len(later['source_sha256']) == 2221
assert source_hashes(prs[1]['head'], later['source_sha256']) == later['source_sha256']
merged = source_hashes(prs[1]['merge'], later['source_sha256'])
changed = sorted(k for k, v in merged.items() if later['source_sha256'][k] != v)
merge_record = read(O / 'pr1547-merge-verification-388.json')
assert changed == sorted(merge_record['prior_merged_harness_assets']) and len(changed) == 7
# Resolve the actual previously merged storage-policy revision from its unique local prefix.
prior_main = git('rev-parse', '23939226')
assert source_hashes(prior_main, changed) == {k: merged[k] for k in changed}
assert sha(later_manifest_path) == merge_record['frozen_artifact_manifest_sha256']

result = dict(schema='shardloom.encoded_hosted_primary_review.v1', status='passed',
    pull_requests=prs,
    source_acceptance=dict(original_manifest=bound(O / 'native-release-artifacts-376c.json'),
        runend_correction=bound(R / 'docs/benchmarks/evidence/native-encoded-ipc-admission-2026-10-13.json.xz'),
        unchanged_original_sources=2216, reviewed_runend_sources=3,
        all_2219_sources_match_merged_pr1545=True,
        pr1547_manifest=bound(later_manifest_path),
        all_2221_sources_match_pr1547_head=True, production_sources_unchanged_in_pr1547_merge=True,
        seven_integrated_harness_paths=changed, harnesses_equal_pr1546_merge=prior_main),
    raw_inventory=bound(O / 'encoded-hosted-inventory-410.json'),
    raw_runtime=bound(O / 'encoded-hosted-runtime-410.json'), helper=bound(__file__),
    review_disposition=dict(
        runend='The existing three-file correction rejects nonempty arrays with no ends; both final hosted native jobs explicitly pass the regression.',
        null_schema='The reviewed Null-schema source matches PR1545 and its hosted native regression passes.',
        sparse_owner='The subsequent sparse-frame optimization owner issue is handled by the separate in-progress NATIVE-SELECTION-RESOURCES session-kernel unit; this hosted packet does not claim that unit completed.',
        github_threads_unchanged=True),
    limitations=['The raw GitHub threads remain unresolved in the UI; no resolution or approval was posted.',
        'Hosted wheel proof covers the six named Linux/macOS job observations, 80 tests each; it is not Windows runtime or production workload certification.',
        'The recorded successful website build checks are retained; this packet does not claim a new live website observation.',
        'Historical timing artifacts retain their original executables and methodology; hosted tests are not new performance measurements.'],
    publication_attempted=False, version='0.5.1')
destination = O / 'encoded-hosted-primary-410.json'
with destination.open('x') as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps(dict(status='passed', prs=[p['number'] for p in prs], installed_tests_per_lane=80,
                     installed_lanes=6, source_checks=[2219, 2221], output=str(destination))))
