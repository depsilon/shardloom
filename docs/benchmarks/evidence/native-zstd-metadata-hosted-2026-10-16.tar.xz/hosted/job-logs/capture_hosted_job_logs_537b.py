#!/usr/bin/env python3
"""One-pass, read-only capture of selected GitHub Actions job logs."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent
REPO = "depsilon/shardloom"
PR = 1562
RUN_ID = 38897859290
EXPECTED_HEAD = "477bbf62b51f68edb64d76676727e2582a5c2d37"
MAX_LOG_BYTES = 12 * 1024 * 1024
GH = "/opt/homebrew/bin/gh"
JOBS = {
    116963000360: "Python test shard (core)",
    116963000561: "Rust feature matrix (native_public_surface_tests)",
    116963000419: "Rust feature matrix (native_vortex_tests)",
    116963000519: "Native Python wheel (py310_ubuntu)",
    116963000393: "Native Python wheel (py313_ubuntu)",
    116963000270: "Native Python wheel (py313_macos)",
}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def json_bytes(data: bytes) -> dict:
    return json.loads(data.decode("utf-8-sig"))


def invoke(label: str, endpoint: str, snapshot: Path, commands: list[dict]) -> tuple[bytes | None, dict]:
    argv = [GH, "api", endpoint]
    env = dict(os.environ, GH_RETRY="0")
    try:
        result = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                timeout=60, check=False, env=env)
        record = {
            "label": label, "argv": argv, "timeout_seconds": 60,
            "exit_code": result.returncode,
            "stdout_bytes": len(result.stdout), "stdout_sha256": digest(result.stdout),
            "stderr": result.stderr.decode("utf-8", "replace"),
        }
        commands.append(record)
        return (result.stdout if result.returncode == 0 else None), record
    except subprocess.TimeoutExpired as error:
        stdout = error.stdout or b""
        stderr = error.stderr or b""
        record = {
            "label": label, "argv": argv, "timeout_seconds": 60,
            "exit_code": None, "timed_out": True,
            "stdout_bytes": len(stdout), "stdout_sha256": digest(stdout),
            "stderr": stderr.decode("utf-8", "replace"),
        }
        commands.append(record)
        return None, record


def write_raw(snapshot: Path, name: str, data: bytes) -> dict:
    path = snapshot / name
    path.write_bytes(data)
    return {"path": str(path.relative_to(OUT)), "bytes": len(data), "sha256": digest(data)}


def previous_summary() -> dict | None:
    candidates = sorted(OUT.glob("capture-*/summary.json"))
    for path in reversed(candidates):
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
    return None


def reusable_log(previous: dict | None, job_id: int, expected_name: str) -> tuple[bytes, str] | None:
    if not previous:
        return None
    if (previous.get("run_id") != RUN_ID
            or previous.get("expected_head_sha") != EXPECTED_HEAD
            or previous.get("run", {}).get("identity_matches") is not True):
        return None
    for row in previous.get("jobs", []):
        if row.get("job_id") != job_id or row.get("expected_name") != expected_name:
            continue
        metadata = row.get("metadata") or {}
        if (row.get("identity_matches_expected_run_head_and_name") is not True
                or metadata.get("id") != job_id or metadata.get("run_id") != RUN_ID
                or metadata.get("name") != expected_name):
            return None
        info = row.get("log") or {}
        rel = info.get("path")
        if row.get("capture_state") != "captured" or not rel:
            return None
        source = OUT / rel
        try:
            raw = source.read_bytes()
        except OSError:
            return None
        if len(raw) != info.get("bytes") or digest(raw) != info.get("sha256"):
            return None
        return raw, str(source.relative_to(OUT))
    return None


def complete_marker(lines: list[str]) -> bool:
    if not lines:
        return False
    last = lines[-1]
    return any(marker in last for marker in (
        "Cleaning up orphan processes", "Post job cleanup.", "Complete job",
    ))


def extract_wheel_proof(lines: list[str]) -> dict | None:
    marker = '"schema_version": "shardloom.native_python_wheel_proof.v1"'
    marker_line = next((i for i, line in enumerate(lines) if marker in line), None)
    if marker_line is None:
        return None
    start = next((i for i in range(marker_line - 1, -1, -1) if lines[i].endswith("Z {")), None)
    if start is None:
        return None
    pieces = []
    for index, line in enumerate(lines[start:], start):
        if "Z " not in line:
            break
        pieces.append(line.split("Z ", 1)[1])
        next_line = lines[index + 1] if index + 1 < len(lines) else ""
        if pieces[-1] == "}" and "##[group]" in next_line:
            break
    try:
        return json.loads("\n".join(pieces))
    except json.JSONDecodeError:
        return None


def analyze_log(raw: bytes, expected_name: str, snapshot: Path, job_id: int) -> dict:
    text = raw.decode("utf-8-sig", "replace")
    lines = text.splitlines()
    records = lambda predicate: [
        {"line": i + 1, "text": line}
        for i, line in enumerate(lines) if predicate(line)
    ]
    summaries = records(lambda line: (
        ("Ran " in line and " test" in line) or line.endswith("Z OK")
        or "OK (skipped=" in line or "test_count" in line
        or "skipped_count" in line or "failure_count" in line
        or "error_count" in line or "pytest" in line
    ))
    rust_results = records(lambda line: "test result:" in line)
    synthetic = records(lambda line: (
        "HEAD is now at " in line or re.fullmatch(r"[0-9a-f]{40}", line.strip()) is not None
    ))
    merge_revision_rows = []
    for i, line in enumerate(lines):
        fetched = re.search(
            rf"\+?([0-9a-f]{{40}}):refs/remotes/pull/{PR}/merge(?:\s|$)", line
        )
        installed_ref = re.search(
            rf"\b([0-9a-f]{{40}})\s+->\s+pull/{PR}/merge(?:\s|$)", line
        )
        match = fetched or installed_ref
        if match:
            merge_revision_rows.append({"line": i + 1, "sha": match.group(1), "text": line})
    merge_shas = sorted({row["sha"] for row in merge_revision_rows})
    proof_path = None
    proof = extract_wheel_proof(lines) if expected_name.startswith("Native Python wheel") else None
    if proof is not None:
        proof_path = write_raw(snapshot, f"wheel-proof-{job_id}.json",
                               (json.dumps(proof, indent=2, sort_keys=True) + "\n").encode())
    return {
        "line_count": len(lines),
        "first_line": lines[0] if lines else None,
        "last_line": lines[-1] if lines else None,
        "complete_cleanup_tail": complete_marker(lines),
        "synthetic_checkout_revision_candidates": synthetic,
        "synthetic_checkout_merge_sha": merge_shas[0] if len(merge_shas) == 1 else None,
        "synthetic_checkout_merge_sha_evidence": merge_revision_rows,
        "test_summary_lines": summaries,
        "rust_test_result_groups": rust_results,
        "wheel_proof": proof,
        "wheel_proof_file": proof_path,
    }


def main() -> int:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    snapshot = OUT / f"capture-{stamp}"
    snapshot.mkdir(parents=True, exist_ok=False)
    commands: list[dict] = []
    errors: list[str] = []
    prior = previous_summary()

    run_raw, _ = invoke("run_metadata", f"repos/{REPO}/actions/runs/{RUN_ID}", snapshot, commands)
    run_obj = {}
    run_record = {"identity_matches": False}
    if run_raw is not None:
        try:
            run_obj = json_bytes(run_raw)
            raw_record = write_raw(snapshot, f"run-{RUN_ID}.json", run_raw)
            prs = [{
                "number": row.get("number"),
                "head_sha": row.get("head", {}).get("sha"),
                "base_sha": row.get("base", {}).get("sha"),
                "head_ref": row.get("head", {}).get("ref"),
            } for row in run_obj.get("pull_requests", [])]
            matches = run_obj.get("id") == RUN_ID and any(
                row.get("number") == PR and row.get("head_sha") == EXPECTED_HEAD for row in prs
            )
            run_record = {
                **raw_record, "id": run_obj.get("id"), "event": run_obj.get("event"),
                "status": run_obj.get("status"), "conclusion": run_obj.get("conclusion"),
                "run_attempt": run_obj.get("run_attempt"), "head_sha": run_obj.get("head_sha"),
                "pull_requests": prs, "identity_matches": matches,
            }
        except (ValueError, TypeError, json.JSONDecodeError) as error:
            errors.append(f"run metadata parse failed: {error}")
    else:
        errors.append("run metadata request failed")

    jobs = []
    for job_id, expected_name in JOBS.items():
        raw, _ = invoke(f"job_{job_id}_metadata", f"repos/{REPO}/actions/jobs/{job_id}", snapshot, commands)
        if raw is None:
            jobs.append({"job_id": job_id, "expected_name": expected_name,
                         "capture_state": "metadata_error", "log": None})
            errors.append(f"job {job_id} metadata request failed")
            continue
        try:
            job = json_bytes(raw)
            metadata_raw = write_raw(snapshot, f"job-{job_id}.json", raw)
        except (ValueError, TypeError, json.JSONDecodeError) as error:
            jobs.append({"job_id": job_id, "expected_name": expected_name,
                         "capture_state": "metadata_error", "log": None})
            errors.append(f"job {job_id} metadata parse failed: {error}")
            continue
        job_identity = (
            job.get("id") == job_id and job.get("run_id") == RUN_ID
            and job.get("name") == expected_name
            and job.get("head_sha") == run_obj.get("head_sha")
            and run_record.get("identity_matches") is True
        )
        metadata = {
            **metadata_raw,
            "id": job.get("id"), "name": job.get("name"),
            "status": job.get("status"), "conclusion": job.get("conclusion"),
            "run_id": job.get("run_id"), "head_sha": job.get("head_sha"),
            "started_at": job.get("started_at"), "completed_at": job.get("completed_at"),
            "steps": [{k: step.get(k) for k in (
                "name", "number", "status", "conclusion", "started_at", "completed_at"
            )} for step in job.get("steps", [])],
        }
        row = {
            "job_id": job_id, "expected_name": expected_name, "metadata": metadata,
            "identity_matches_expected_run_head_and_name": job_identity,
            "capture_state": None, "log": None,
        }
        if not job_identity:
            row["capture_state"] = "identity_mismatch"
            errors.append(f"job {job_id} identity does not match expected run/head/name")
            jobs.append(row)
            continue
        if job.get("status") != "completed" or job.get("conclusion") != "success":
            row["capture_state"] = "pending" if job.get("status") != "completed" else "not_successful"
            jobs.append(row)
            continue

        prior_log = reusable_log(prior, job_id, expected_name)
        if prior_log is not None:
            log_bytes, prior_path = prior_log
            rec = write_raw(snapshot, f"job-{job_id}.log", log_bytes)
            row["reused_from"] = prior_path
        else:
            log_bytes, command = invoke(f"job_{job_id}_complete_log", f"repos/{REPO}/actions/jobs/{job_id}/logs", snapshot, commands)
            if log_bytes is None:
                row["capture_state"] = "log_error"
                errors.append(f"job {job_id} completed log request failed")
                jobs.append(row)
                continue
            if len(log_bytes) > MAX_LOG_BYTES:
                row["capture_state"] = "oversize"
                row["log_response_bytes"] = len(log_bytes)
                errors.append(f"job {job_id} log exceeds {MAX_LOG_BYTES} byte ceiling")
                jobs.append(row)
                continue
            rec = write_raw(snapshot, f"job-{job_id}.log", log_bytes)
        row["capture_state"] = "captured"
        row["log"] = rec
        row["analysis"] = analyze_log(log_bytes, expected_name, snapshot, job_id)
        jobs.append(row)

    mismatch = not run_record.get("identity_matches") or any(
        row.get("capture_state") == "identity_mismatch" for row in jobs
    )
    pending = [row["expected_name"] for row in jobs if row.get("capture_state") == "pending"]
    all_captured = len(jobs) == len(JOBS) and all(row.get("capture_state") == "captured" for row in jobs)
    status = "NEEDS_REASONING" if mismatch else ("COMPLETE" if all_captured else "PARTIAL")
    summary = {
        "schema": "shardloom.github_hosted_job_capture.v1",
        "status": status, "captured_at_utc": datetime.now(timezone.utc).isoformat(),
        "repository": REPO, "pull_request": PR, "run_id": RUN_ID,
        "expected_head_sha": EXPECTED_HEAD,
        "expected_synthetic_checkout_merge_sha": "624c7182f91a685cad9afb01427bd7d50755e0ef",
        "max_raw_log_bytes": MAX_LOG_BYTES,
        "capture_method": "Read-only GitHub REST API via gh api; GH_RETRY=0; each command timeout is 60 seconds.",
        "run": run_record, "jobs": jobs, "pending_job_names": pending,
        "commands": commands, "errors": errors,
        "non_acceptance_notice": "Raw evidence inventory only; contains no review or acceptance decision.",
    }
    summary_path = snapshot / "summary.json"
    summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": status, "summary": str(summary_path), "pending_job_names": pending,
        "errors": errors,
        "jobs": [{"job_id": row["job_id"], "name": row["expected_name"],
                  "state": row.get("capture_state"), "bytes": (row.get("log") or {}).get("bytes"),
                  "sha256": (row.get("log") or {}).get("sha256"),
                  "cleanup_tail": (row.get("analysis") or {}).get("complete_cleanup_tail")}
                 for row in jobs],
    }, indent=2))
    return 0 if status == "COMPLETE" else 2 if status == "NEEDS_REASONING" else 1


if __name__ == "__main__":
    raise SystemExit(main())
