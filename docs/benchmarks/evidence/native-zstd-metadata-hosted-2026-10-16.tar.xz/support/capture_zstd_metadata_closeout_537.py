"""Capture fresh PR/check/review metadata for an exact premerge or merged head."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

OUT = Path(__file__).resolve().parent / 'zstd-metadata-hosted-537'
HEAD = 'e1c1bca8e0713d7b73d57404deea4deeccd2f413'
BASE = '4217c2cd7d322e054d483e3e389f6f22df8d0970'
GH = '/opt/homebrew/bin/gh'


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', choices=('premerge', 'postmerge'), required=True)
    parser.add_argument('--merged')
    parser.add_argument('--attempt', default='537')
    args = parser.parse_args()
    assert re.fullmatch(r'[a-z0-9-]+', args.attempt)
    assert (args.stage == 'postmerge') == bool(args.merged)
    if args.merged:
        assert re.fullmatch(r'[a-f0-9]{40}', args.merged)
    destination = OUT / (args.stage + '-' + args.attempt)
    destination.mkdir(exist_ok=False)
    records = []

    def api(name, arguments):
        completed = subprocess.run([GH, 'api', *arguments], capture_output=True, timeout=60)
        assert completed.returncode == 0, completed.stderr.decode()
        path = destination / (name + '.json')
        path.write_bytes(completed.stdout)
        value = json.loads(completed.stdout)
        records.append(identity(path))
        return value

    pr = api('pull-request', ['repos/depsilon/shardloom/pulls/1562'])
    checks = api('checks', [f'repos/depsilon/shardloom/commits/{HEAD}/check-runs?per_page=100'])
    statuses = api('statuses', [f'repos/depsilon/shardloom/commits/{HEAD}/status?per_page=100'])
    comments = api('issue-comments', ['repos/depsilon/shardloom/issues/1562/comments?per_page=100'])
    query = '''query { repository(owner:"depsilon", name:"shardloom") {
      pullRequest(number:1562) { number headRefOid merged mergeCommit { oid }
        reviews(first:100) { pageInfo { hasNextPage } nodes { id state commit { oid } } }
        reviewThreads(first:100) { pageInfo { hasNextPage } nodes { id isResolved } }
      } } }'''
    review = api('review-state', ['graphql', '-f', 'query=' + query])
    assert pr['number'] == 1562 and pr['head']['sha'] == HEAD
    if args.stage == 'premerge':
        assert pr['state'] == 'open' and not pr['merged'] and not pr['draft']
        assert pr['base']['sha'] == BASE and pr['mergeable'] and pr['mergeable_state'] == 'clean'
    else:
        assert pr['merged'] and pr['merge_commit_sha'] == args.merged
    assert checks['total_count'] == len(checks['check_runs']) == 44
    assert len({row['id'] for row in checks['check_runs']}) == 44
    assert all(row['head_sha'] == HEAD and row['status'] == 'completed'
               and row['conclusion'] == 'success' for row in checks['check_runs'])
    assert statuses['sha'] == HEAD and statuses['total_count'] == 0 and statuses['statuses'] == []
    assert len(comments) < 100
    bot = [row for row in comments if row['user']['login'] == 'chatgpt-codex-connector[bot]']
    assert len(bot) == 1
    marker = re.search(r'<!-- codex-review-state:v1 (.*?) -->', bot[0]['body'])
    assert marker
    state = json.loads(marker.group(1))['code_review']
    assert state == dict(commit_sha=HEAD, has_any_findings=False,
                        has_unresolved_findings=False, status='completed')
    reviewed = review['data']['repository']['pullRequest']
    assert reviewed['number'] == 1562 and reviewed['headRefOid'] == HEAD
    assert reviewed['merged'] == (args.stage == 'postmerge')
    if args.merged:
        assert reviewed['mergeCommit']['oid'] == args.merged
    for kind in ('reviews', 'reviewThreads'):
        assert reviewed[kind]['pageInfo']['hasNextPage'] is False
        assert reviewed[kind]['nodes'] == []
    report = dict(schema_version='shardloom.native_zstd_metadata_closeout.v1',
        status='passed', stage=args.stage, recorded_at=datetime.now(timezone.utc).isoformat(),
        head=HEAD, merge=args.merged, checks_passed=44, code_review=state,
        review_threads=0, metadata=records, helper=identity(Path(__file__)))
    with (destination / 'report.json').open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status='passed', stage=args.stage, checks=44,
                         review_findings=0, report=str(destination / 'report.json'))))


if __name__ == '__main__':
    main()

