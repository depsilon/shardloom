"""Compare frozen accepted runtime sources with immutable reviewed Git trees."""
import argparse
import json
from pathlib import Path
import subprocess

import verify_stream_destination_integrated_sources_482 as immutable
from verify_stream_subquery_integrated_sources_513 import selector_check, identity
from freeze_native_release_298 import ROOT, OUT, sources, save

HEAD = '477bbf62b51f68edb64d76676727e2582a5c2d37'
BASE = '4217c2cd7d322e054d483e3e389f6f22df8d0970'
SYNTHETIC = '624c7182f91a685cad9afb01427bd7d50755e0ef'
TREE = '10f43e54a92ce7f09bffefdccea8b42218869a93'
DEST = OUT / 'zstd-metadata-hosted-537b'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--merged')
    args = parser.parse_args()
    selector_check()
    accepted_path = OUT / 'native-release-source-zstdmetadata532.json'
    accepted = json.loads(accepted_path.read_text())['source_sha256']
    assert len(accepted) == 2307 and sources() == accepted
    DEST.mkdir(exist_ok=True)
    metadata_path = DEST / 'synthetic-merge-537b.json'
    if not metadata_path.exists():
        raw = subprocess.check_output(['/opt/homebrew/bin/gh', 'api',
            'repos/depsilon/shardloom/git/commits/' + SYNTHETIC], timeout=45)
        metadata_path.open('xb').write(raw)
    synthetic = json.loads(metadata_path.read_text())
    assert synthetic['sha'] == SYNTHETIC and synthetic['tree']['sha'] == TREE
    assert [p['sha'] for p in synthetic['parents']] == [BASE, HEAD]
    revisions = dict(pr_head=HEAD, ci_merge=SYNTHETIC)
    if args.merged:
        revisions['merged'] = args.merged
    trees = {key:subprocess.check_output(['git','rev-parse',rev+'^{tree}'],
        cwd=ROOT,text=True).strip() for key,rev in revisions.items()}
    assert set(trees.values()) == {TREE}
    mapping, records = immutable.immutable_source_map(HEAD)
    assert {p:r['sha256'] for p,r in mapping.items()} == accepted
    assert all(mode in ('100644','100755') for _,_,mode in records)
    artifact_path = OUT / 'native-release-artifacts-zstdmetadata532.json'
    artifact = json.loads(artifact_path.read_text())
    assert artifact['source_sha256'] == accepted
    binaries = {key:identity(artifact[key]['path']) for key in ('cli','binding')}
    for key,row in binaries.items():
        assert row == {k:artifact[key][k] for k in ('path','bytes','sha256')}
    previous = 'e1c1bca8e0713d7b73d57404deea4deeccd2f413'
    paths = subprocess.check_output(['git','diff','--name-only',previous,HEAD],cwd=ROOT,text=True).splitlines()
    assert paths == ['.github/workflows/ci.yml']
    diff = subprocess.check_output(['git','diff',previous,HEAD,'--','.github/workflows/ci.yml'],cwd=ROOT,text=True)
    additions = [line[1:] for line in diff.splitlines() if line.startswith('+') and not line.startswith('+++')]
    deletions = [line for line in diff.splitlines() if line.startswith('-') and not line.startswith('---')]
    assert len(additions) == 4 and deletions == []
    assert additions[-1].strip() == '--lib metadata_resources::tests:: -- --test-threads=1'
    correction = dict(previous_head=previous,final_head=HEAD,paths=paths,diff=diff,
        ci_selection_contract=identity(OUT/'zstd-metadata-ci-selection-537.json'),
        runtime_sources_unchanged=True,local_vendor_tests_passed=67,
        reason='The original CI filter omitted six new standalone metadata tests. Add their existing module to the hosted native lane before merge.',
        first_ci_run=38896923006,final_ci_run=38897859290,
        superseded_capture=str(OUT/'zstd-metadata-hosted-537'),
        local_runtime_evidence_reused='All runtime sources, binaries and 43-query results are unchanged; only CI selection changed.')
    report = dict(status='passed',revisions=revisions,trees=trees,source_files=len(mapping),
        selector_ast_matches=True,all_selected_sources_match=True,immutable_source=mapping,
        accepted=identity(accepted_path),artifact_manifest=identity(artifact_path),binaries=binaries,
        synthetic_metadata=identity(metadata_path),ci_selection_correction=correction,helpers=[identity(__file__),
            identity(immutable.__file__),identity(OUT/'verify_stream_subquery_integrated_sources_513.py'),
            identity(OUT/'freeze_native_release_298.py')],
        scope='Source identity only; hosted runtime, review, deployment and merge are verified separately.')
    destination = DEST / ('merged-sources-537b.json' if args.merged else 'pr-sources-537b.json')
    save(destination,report)
    print(json.dumps(dict(status='passed',source_files=len(mapping),trees=trees,report=str(destination))))


if __name__ == '__main__':
    main()
