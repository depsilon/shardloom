"""Compare frozen accepted runtime sources with immutable reviewed Git trees."""
import argparse
import json
from pathlib import Path
import subprocess

import verify_stream_destination_integrated_sources_482 as immutable
from verify_stream_subquery_integrated_sources_513 import selector_check, identity
from freeze_native_release_298 import ROOT, OUT, sources, save

HEAD = 'e1c1bca8e0713d7b73d57404deea4deeccd2f413'
BASE = '4217c2cd7d322e054d483e3e389f6f22df8d0970'
SYNTHETIC = 'a57608aca0c542edeca41cc52b620ba25fff8d47'
TREE = 'f1e5ee780222580b52e890c41b44230862008694'
DEST = OUT / 'zstd-metadata-hosted-537'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--merged')
    args = parser.parse_args()
    selector_check()
    accepted_path = OUT / 'native-release-source-zstdmetadata532.json'
    accepted = json.loads(accepted_path.read_text())['source_sha256']
    assert len(accepted) == 2307 and sources() == accepted
    metadata_path = DEST / 'synthetic-merge-537.json'
    if not metadata_path.exists():
        raw = subprocess.check_output(['/opt/homebrew/bin/gh', 'api',
            'repos/depsilon/shardloom/git/commits/' + SYNTHETIC], timeout=45)
        metadata_path.open('xb').write(raw)
    synthetic = json.loads(metadata_path.read_text())
    assert synthetic['sha'] == SYNTHETIC and synthetic['tree']['sha'] == TREE
    assert [p['sha'] for p in synthetic['parents']] == [BASE, HEAD]
    revisions = dict(pr_head=HEAD, ci_merge=SYNTHETIC)
    if args.merged:
        revisions['merged'] = args.merged
    trees = {key:subprocess.check_output(['git','rev-parse',rev+'^{tree}'],
        cwd=ROOT,text=True).strip() for key,rev in revisions.items()}
    assert set(trees.values()) == {TREE}
    mapping, records = immutable.immutable_source_map(HEAD)
    assert {p:r['sha256'] for p,r in mapping.items()} == accepted
    assert all(mode in ('100644','100755') for _,_,mode in records)
    artifact_path = OUT / 'native-release-artifacts-zstdmetadata532.json'
    artifact = json.loads(artifact_path.read_text())
    assert artifact['source_sha256'] == accepted
    binaries = {key:identity(artifact[key]['path']) for key in ('cli','binding')}
    for key,row in binaries.items():
        assert row == {k:artifact[key][k] for k in ('path','bytes','sha256')}
    report = dict(status='passed',revisions=revisions,trees=trees,source_files=len(mapping),
        selector_ast_matches=True,all_selected_sources_match=True,immutable_source=mapping,
        accepted=identity(accepted_path),artifact_manifest=identity(artifact_path),binaries=binaries,
        synthetic_metadata=identity(metadata_path),helpers=[identity(__file__),
            identity(immutable.__file__),identity(OUT/'verify_stream_subquery_integrated_sources_513.py'),
            identity(OUT/'freeze_native_release_298.py')],
        scope='Source identity only; hosted runtime, review, deployment and merge are verified separately.')
    destination = DEST / ('merged-sources-537.json' if args.merged else 'pr-sources-537.json')
    save(destination,report)
    print(json.dumps(dict(status='passed',source_files=len(mapping),trees=trees,report=str(destination))))


if __name__ == '__main__':
    main()
