"""Verify and archive immutable Zstd metadata hosted integration evidence."""
import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile

import accept_zstd_metadata_hosted_jobs_537b as jobs
import verify_zstd_metadata_integrated_sources_537b as sources

ROOT, OUT, RAW = sources.ROOT, sources.OUT, sources.DEST
HEAD, SYNTHETIC, TREE = sources.HEAD, sources.SYNTHETIC, sources.TREE
sys.path.insert(0, str(ROOT/'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def read(path):
    return json.loads(Path(path).read_text())


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=digest(raw))


def check(record):
    actual = identity(record['path'])
    assert all(actual[k] == record[k] for k in ('path','bytes','sha256'))


def save(path, value):
    Path(path).open('x').write(json.dumps(value,indent=2)+'\n')


def served(stage, revision):
    folder = RAW/(stage+'-served-537b')
    report = read(folder/'report.json')
    assert report['status'] == 'passed' and report['stage'] == stage
    assert report['head'] == revision and report['reviewed_head'] == HEAD
    assert identity(report['helper']['path'])['sha256'] == report['helper']['sha256']
    checks = read(folder/'deployment-checks.json')
    assert checks['total_count'] == len(checks['check_runs']) <= 100
    workers = [r for r in checks['check_runs'] if r['name'] == 'Workers Builds: shardloom']
    assert len(workers) == 1
    worker = workers[0]
    assert worker['head_sha'] == revision and worker['status'] == 'completed' and worker['conclusion'] == 'success'
    assert all(report['deployment'][k] == worker[k] for k in report['deployment'])
    versions = re.findall(r'Version ID: ([0-9a-f-]{36})',worker['output']['summary'])
    assert len(versions) == 1
    pr = read(folder/'pull-request.json')
    assert pr['number'] == 1562 and pr['head']['sha'] == HEAD
    if stage == 'production':
        assert pr['merged'] and pr['merge_commit_sha'] == revision
    assert len(report['responses']) == len({r['source'] for r in report['responses']}) == 8
    for row in report['responses']:
        actual = (folder/row['response']).read_bytes()
        expected = subprocess.check_output(['git','show',revision+':'+row['source']],cwd=ROOT)
        assert row['http_status'] == 200 and row['source_preserved']
        assert row['observed_bytes'] == len(actual) and row['observed_sha256'] == digest(actual)
        assert row['expected_bytes'] == len(expected) and row['expected_sha256'] == digest(expected)
        assert row['raw_byte_identical'] == (actual == expected)
        assert read(folder/(row['response']+'.attempts.json')) == row['attempts']
        assert row['attempts'][-1]['status'] == 'passed' and 1 <= len(row['attempts']) <= 3
        if actual != expected:
            prefix = next(i for i,(a,b) in enumerate(zip(actual,expected)) if a != b)
            extra = len(actual)-len(expected)
            assert 0 < extra <= 16384 and row['source'].endswith('.html')
            inserted = actual[prefix:prefix+extra]
            assert actual[prefix+extra:] == expected[prefix:]
            assert b'/cdn-cgi/challenge-platform/' in inserted or b'static.cloudflareinsights.com/' in inserted
            assert row['insertion_bytes'] == extra and row['insertion_sha256'] == digest(inserted)
    return dict(report=report,deployment_version=versions[0])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--merge',required=True)
    parser.add_argument('--capture',required=True)
    args = parser.parse_args()
    assert re.fullmatch(r'[0-9a-f]{40}',args.merge)
    assert re.fullmatch(r'capture-\d{8}T\d{6}Z',args.capture)
    destination = require_local_path(OUT/'zstd-metadata-hosted-packet-538',Path.home(),sys.platform)
    assert not destination.exists()
    check_budgets(OUT,destination,OUT/'logs',min_free_bytes=12*GIB,
                  reserve_bytes=128*MIB,max_workspace_bytes=100*GIB,max_log_bytes=192*MIB)
    closeouts = {}
    for stage in ('premerge','postmerge'):
        report = read(RAW/(stage+'-537b')/'report.json')
        assert report['status'] == 'passed' and report['head'] == HEAD and report['checks_passed'] == 44
        assert report['merge'] == (args.merge if stage == 'postmerge' else None)
        assert report['review_threads'] == 0
        review = report['code_review']
        assert review['commit_sha'] in (HEAD,'e1c1bca8e0713d7b73d57404deea4deeccd2f413')
        assert review['status'] == 'completed' and review['has_any_findings'] is False
        assert review['has_unresolved_findings'] is False
        coverage = report['review_coverage']
        assert coverage['automated_review_head'] == review['commit_sha'] and coverage['final_head'] == HEAD
        if review['commit_sha'] != HEAD:
            assert coverage['automated_review_covers_final_head'] is False
            assert coverage['runtime_changes_after_review'] is False
            assert coverage['changed_paths'] == ['.github/workflows/ci.yml']
            check(coverage['ci_selection_contract'])
        for record in report['metadata']+[report['helper']]:
            check(record)
        closeouts[stage] = report
    receipt = read(RAW/'merge-receipt-538.json')
    assert receipt['isError'] is False and receipt['structuredContent']['merged'] is True
    assert receipt['structuredContent']['sha'] == args.merge
    source = read(RAW/'merged-sources-537b.json')
    assert source['status'] == 'passed' and source['selector_ast_matches']
    assert source['revisions'] == dict(pr_head=HEAD,ci_merge=SYNTHETIC,merged=args.merge)
    assert set(source['trees'].values()) == {TREE}
    immutable,records = sources.immutable.immutable_source_map(args.merge)
    assert len(immutable) == source['source_files'] == 2307
    assert source['immutable_source'] == immutable
    assert {p:r['sha256'] for p,r in immutable.items()} == read(source['accepted']['path'])['source_sha256']
    assert all(mode in ('100644','100755') for _,_,mode in records)
    for record in [source['accepted'],source['artifact_manifest'],source['synthetic_metadata'],
                   *source['helpers'],*source['binaries'].values(),
                   source['ci_selection_correction']['ci_selection_contract']]:
        check(record)
    assert source['ci_selection_correction']['runtime_sources_unchanged']
    runtime = read(RAW/('primary-acceptance-537b-'+args.capture+'.json'))
    assert runtime['status'] == 'passed_all_six' and runtime['pending'] == []
    assert runtime['head'] == HEAD and runtime['synthetic'] == SYNTHETIC and runtime['tree'] == TREE
    for key in ('source_verification','capture','run','capture_helper','acceptance_helper','parser_helper'):
        check(runtime[key])
    assert len(runtime['jobs']) == 6 and {r['job_id']:r['name'] for r in runtime['jobs']} == jobs.JOBS
    wheels = []
    for row in runtime['jobs']:
        check(row['raw'])
        check(row['metadata'])
        metadata = read(row['metadata']['path'])
        assert metadata['head_sha'] == HEAD and metadata['status'] == 'completed' and metadata['conclusion'] == 'success'
        text = jobs.normalized(Path(row['raw']['path']))
        assert SYNTHETIC+':refs/remotes/pull/1562/merge' in text
        assert text.splitlines()[-1].startswith('Cleaning up orphan processes')
        if row['name'].startswith('Native Python wheel'):
            proof,offsets = jobs.machine_report(text,'shardloom.native_python_wheel_proof.v1')
            assert proof == row['proof'] and offsets == row['normalized_offsets']
            assert proof['integration'] == dict(tests=100,failures=0,errors=0,skipped=0,status='passed')
            assert proof['status'] == proof['uninstall_status'] == 'passed' and proof['installed_load']['isolated_install']
            assert all(r['returncode'] == 0 for r in proof['steps'])
            wheels.append(row['name'])
        elif row['job_id'] == 116963000360:
            proof,offsets = jobs.machine_report(text,'shardloom.python_test_shard_evidence.v1')
            assert proof == row['proof'] and offsets == row['normalized_offsets']
            assert proof['test_count'] == 626 and proof['module_count'] == 57 and proof['skipped_count'] == 14
            assert row['console_tests_run'] == 526
        else:
            groups = [list(map(int,r)) for r in re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text,re.M)]
            expected = ([[949,0,0],[0,0,0],[6,0,0],[65,0,0],[44,0,0],[15,0,0]] if row['job_id'] == 116963000561
                        else [[2872,0,26],[10,0,0],[7,0,0],[7,0,0],[23,0,0],[4,0,0],[6,0,0]])
            assert groups == row['result_groups'] == expected
            if row['job_id'] == 116963000419:
                assert len(row['new_native_tests']) == 9 and len(row['standalone_metadata_tests']) == 6
                for test in row['new_native_tests']+row['standalone_metadata_tests']:
                    assert digest(jobs.source(test['source'])) == test['sha256']
                    assert 'test '+test['observed_test_path']+' ... ok' in text
    assert len(wheels) == 3 and sum(len(r['methods']) for r in runtime['wheel_binding_sources']) == 100
    for row in runtime['wheel_binding_sources']:
        assert digest(jobs.source(row['path'])) == row['sha256']
    deployments = dict(preview=served('preview',HEAD),production=served('production',args.merge))
    browsers = {stage:read(RAW/(stage+'-browser-537b.json')) for stage in ('preview','production')}
    for stage,browser in browsers.items():
        assert browser['stage'] == stage and browser['head'] == (HEAD if stage == 'preview' else args.merge)
        assert browser['search']['query'] == 'frame metadata' and browser['search']['result_pages'] == 5
        assert browser['mobile_menu_navigation_passed'] and browser['console'] == []
        assert browser['desktop']['body'] <= browser['desktop']['width'] == 1280
        assert browser['mobile']['body'] <= browser['mobile']['width'] == 390
        assert browser['limits']['metadataText'] and browser['limits']['pending']
    limits = [
        'Browser observations cover the in-app browser, desktop and phone viewports, search and mobile navigation; no cross-browser matrix is claimed.',
        'Deployed pages retain the reviewed pre-closeout wording, including hosted integration pending. A later documentation closeout has separate deployment evidence.',
        'Automated review scope is the exact commit recorded in review_coverage. Any subsequent four-line CI-only test-selection addition is reviewed by the primary; no final-head automated approval is inferred.',
        'The accepted premerge Full43 remains the query regression observation; no query rerun was used for merge or deployment proof.',
        'Published 0.6.0 packages remain immutable; installed-wheel proofs are CI builds, not a new package publication.']
    report = dict(schema_version='shardloom.native_zstd_metadata_hosted_verification.v1',status='passed',
        recorded_at=datetime.now(timezone.utc).isoformat(),pr=1562,head=HEAD,merge=args.merge,synthetic=SYNTHETIC,
        checks_passed=44,source_files_verified=2307,trees=source['trees'],native_total=2929,native_manual_exclusions=26,
        new_native_tests=9,standalone_metadata_tests=6,native_public_total=1079,wheel_lanes=wheels,wheel_tests_per_lane=100,
        core_discovered=626,core_run=526,core_skipped=14,core_modules=57,closeouts=closeouts,served=deployments,
        browsers=browsers,interpretation=runtime['interpretation'],observation_limits=limits,
        driver=identity(__file__),publication_attempted=False,performance_claim=False)
    save(RAW/'verification-538.json',report)
    files = {'hosted/'+p.relative_to(RAW).as_posix():p for p in RAW.rglob('*') if p.is_file()}
    previous = OUT/'zstd-metadata-hosted-537'
    files.update({'superseded/'+p.relative_to(previous).as_posix():p for p in previous.rglob('*') if p.is_file()})
    helpers = [Path(__file__),Path(jobs.__file__),Path(sources.__file__),Path(sources.immutable.__file__),
        OUT/'freeze_native_release_298.py',OUT/'verify_stream_subquery_integrated_sources_513.py',
        OUT/'accept_stream_dynamic_subquery_hosted_jobs_corrected_528.py',
        OUT/'native-release-source-zstdmetadata532.json',OUT/'native-release-artifacts-zstdmetadata532.json',
        OUT/'capture_zstd_metadata_served_537b.py',OUT/'capture_zstd_metadata_closeout_537b.py',
        OUT/'capture_zstd_metadata_served_537.py',OUT/'capture_zstd_metadata_closeout_537.py',
        OUT/'verify_zstd_metadata_integrated_sources_537.py',OUT/'zstd-metadata-ci-selection-537.json',
        ROOT/'scripts/local_uat_storage.py',
        ROOT/'docs/benchmarks/evidence/native-zstd-metadata-resources-2026-10-16.json']
    for path in helpers:
        name = 'support/'+path.name
        assert name not in files
        files[name] = path
    for name,path in files.items():
        assert not path.is_symlink() and path.is_file()
        if path.suffix.lower() in ('.jpg','.jpeg'):
            assert path.read_bytes().startswith(b'\xff\xd8\xff'),name
    assert sum(path.stat().st_size for path in files.values()) < 128*MIB
    destination.mkdir(exist_ok=False)
    archive = destination/'native-zstd-metadata-hosted-2026-10-16.tar.xz'
    index = destination/'native-zstd-metadata-hosted-2026-10-16.json'
    members = []
    with tarfile.open(archive,'x:xz') as stream:
        for name,path in sorted(files.items()):
            before = identity(path)
            payload = path.read_bytes()
            info = tarfile.TarInfo(name)
            info.size = len(payload)
            info.mode = 0o644
            stream.addfile(info,io.BytesIO(payload))
            assert identity(path) == before
            members.append(dict(name=name,bytes=len(payload),sha256=digest(payload)))
    with tarfile.open(archive,'r:xz') as stream:
        entries = stream.getmembers()
        assert len(entries) == len({r.name for r in entries}) == len(members)
        assert all(r.isfile() for r in entries) and {r.name for r in entries} == set(files)
        for member in members:
            payload = stream.extractfile(member['name']).read()
            assert len(payload) == member['bytes'] and digest(payload) == member['sha256']
            assert payload == files[member['name']].read_bytes()
    save(index,dict(schema_version='shardloom.native_zstd_metadata_hosted_packet.v1',status='passed',
        pr=1562,head=HEAD,merge=args.merge,synthetic=SYNTHETIC,checks_passed=44,source_files_verified=2307,
        native_total=2929,native_manual_exclusions=26,new_native_tests=9,standalone_metadata_tests=6,native_public_total=1079,
        wheel_lanes=3,wheel_tests_per_lane=100,core_discovered=626,core_run=526,core_skipped=14,core_modules=57,
        served_responses_verified=16,production_deployment_check_complete=True,
        production_deployment_check_id=deployments['production']['report']['deployment']['id'],
        production_version=deployments['production']['deployment_version'],observation_limits=limits,
        review_coverage=closeouts['premerge']['review_coverage'],ci_selection_correction=source['ci_selection_correction'],
        archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=identity(archive)['sha256']),
        members_verified=len(members),members=members,publication_attempted=False,performance_claim=False))
    check_budgets(OUT,destination,OUT/'logs',min_free_bytes=12*GIB,reserve_bytes=0,
                  max_workspace_bytes=100*GIB,max_log_bytes=192*MIB)
    for path in (archive,index):
        target = ROOT/'docs/benchmarks/evidence'/path.name
        assert not target.exists()
        shutil.copy2(path,target)
        assert identity(path)['sha256'] == identity(target)['sha256']
    print(json.dumps(dict(status='passed',checks=44,wheel_lanes=3,sources=2307,served_responses=16,
                         members=len(members),archive=identity(archive))))


if __name__ == '__main__':
    main()
