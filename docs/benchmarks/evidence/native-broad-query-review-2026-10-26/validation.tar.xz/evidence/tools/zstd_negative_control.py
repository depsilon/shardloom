"""Check the same synthetic regressions against the originally locked wrapper."""
from pathlib import Path
import hashlib
import json
import os
import subprocess

evidence = Path(__file__).resolve().parent.parent
source = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo/vendor/vortex-zstd/src/dependency_regression_tests.rs')
destination = evidence / 'negative-control-original-zstd'
destination.mkdir()
(destination / 'src').mkdir()
test_bytes = source.read_bytes()
(destination / 'src/lib.rs').write_bytes(test_bytes)
(destination / 'Cargo.toml').write_text('''[package]
name = "shardloom-zstd-original-negative-control"
version = "0.0.0"
edition = "2024"
publish = false

[dependencies]
zstd = "=0.13.3"
zstd-safe = "=7.2.4"
zstd-sys = "=2.0.16"
''')
command = ['cargo', 'test', '--offline', '--manifest-path', str(destination / 'Cargo.toml'),
           '--lib', '--', '--test-threads=1']
result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
log = evidence / 'negative-control-original-zstd.log'
log.write_bytes(result.stdout)
output = result.stdout.decode()
expected = [
    'test borrowed_decoder_restarts_after_partial_delivery ... FAILED',
    'test borrowed_encoder_restarts_after_an_abandoned_stream ... FAILED',
    'test bulk_decoder_recovers_after_corrupt_input ... ok',
    'test result: FAILED. 1 passed; 2 failed; 0 ignored',
]
passed = result.returncode == 101 and all(value in output for value in expected)
record = {'status': 'passed' if passed else 'failed',
          'meaning': 'expected failures on the originally locked dependency versions',
          'source_sha256': hashlib.sha256(test_bytes).hexdigest(),
          'source': str(source), 'command': command, 'cargo_returncode': result.returncode,
          'expected_output': expected,
          'matched': {value: value in output for value in expected},
          'log_sha256': hashlib.sha256(result.stdout).hexdigest()}
(evidence / 'negative-control-original-zstd.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
raise SystemExit(0 if passed else 1)
