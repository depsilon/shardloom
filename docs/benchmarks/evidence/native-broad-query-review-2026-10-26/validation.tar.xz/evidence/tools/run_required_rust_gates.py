"""Run the required Rust gates sequentially under the existing local guards."""
from pathlib import Path
import os
import subprocess
import sys

guard = Path(__file__).with_name('run_guarded.py')
commands = [
    ('r14-default-clippy', ['cargo', 'clippy', '--locked', '--offline', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('r15-default-tests', ['cargo', 'test', '--locked', '--offline', '--workspace', '--all-targets', '--', '--test-threads=2']),
    ('r16-native-clippy', ['cargo', 'clippy', '--locked', '--offline', '--profile', 'ci-native', '-p', 'shardloom-cli', '-p', 'shardloom-vortex', '--all-targets', '--features', 'release-user-surfaces', '--', '-D', 'warnings']),
    ('r17-provider-clippy', ['cargo', 'clippy', '--locked', '--offline', '--manifest-path', 'vendor/vortex-zstd/Cargo.toml', '--config', 'patch.crates-io.vortex-array.path="vendor/vortex-array"', '--features', 'vortex-array/table-display', '--lib', '--', '-D', 'warnings']),
]
for name, command in commands:
    print(name, flush=True)
    env = dict(os.environ)
    env.pop('CLIPPY_CONF_DIR', None)
    if name == 'r17-provider-clippy':
        env['CLIPPY_CONF_DIR'] = '/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo/vendor/vortex-array'
    result = subprocess.run([sys.executable, str(guard), '--name', name, '--timeout', '2400', '--', *command], env=env)
    if result.returncode:
        raise SystemExit(result.returncode)
