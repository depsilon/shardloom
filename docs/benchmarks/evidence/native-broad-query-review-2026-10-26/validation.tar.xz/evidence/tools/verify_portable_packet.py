"""Relocate the final packet and test semantic corruption without engine access."""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
PACKET = ROOT / 'docs/benchmarks/evidence/native-broad-query-2026-10-26'
sys.path.insert(0, str(ROOT / 'benchmarks/traditional_analytics'))
from query_surface.replay import object_files, sha, verify_runs
from query_surface.semantics import ResultMismatch


def encoded(value):
    return json.dumps(value, sort_keys=True, allow_nan=False).encode()


def main():
    manifest_bytes = (PACKET / 'manifest.json').read_bytes()
    manifest = json.loads(manifest_bytes)
    packed = (PACKET / 'packet.tar.xz').read_bytes()
    files = object_files(manifest, packed)
    accepted = verify_runs(files, manifest)
    prefix = manifest['original_evidence_root'].rstrip('/') + '/'
    def key(path):
        assert path.startswith(prefix)
        return 'evidence/' + path[len(prefix):]
    selected_run = 'tiny_runner_r2'
    observation_key = 'evidence/' + selected_run + '/observations.jsonl'
    observations = [json.loads(line) for line in files[observation_key].splitlines()]
    row = next(row for row in observations if row['status'] == 'passed')
    outcome_key = key(row['evidence'])
    receipt_key = outcome_key.removesuffix('.stdout.json') + '.receipt.json'

    controls = []
    def reject(name, changed, changed_manifest=None):
        try:
            verify_runs(changed, changed_manifest or manifest)
        except (ValueError, ResultMismatch, KeyError) as error:
            controls.append({'name': name, 'status': 'rejected', 'exception': type(error).__name__, 'reason': str(error)})
        else:
            raise AssertionError('corruption accepted: ' + name)

    changed = dict(files)
    del changed[receipt_key]
    reject('missing_execution_receipt', changed)
    changed = dict(files)
    changed[observation_key] = b'\n'.join(encoded(item) for item in observations[1:])
    reject('missing_observation', changed)
    changed = dict(files)
    changed[observation_key] = files[observation_key] + encoded(observations[0]) + b'\n'
    reject('duplicate_observation', changed)
    for mutation in ('value', 'schema', 'fallback', 'surface', 'incomplete', 'clock'):
        changed, changed_rows = dict(files), deepcopy(observations)
        outcome = json.loads(files[outcome_key])
        if mutation == 'value':
            first = outcome['actual']['rows'][0]
            column = next(name for name, value in first.items() if type(value) is int)
            first[column] += 1
        elif mutation == 'schema':
            dtype = outcome['actual']['schema'][0]['type']
            dtype['nullable'] = not dtype['nullable']
        elif mutation == 'fallback':
            outcome['observation']['fields']['fallback_attempted'] = True
        elif mutation == 'surface':
            outcome['observation']['surface'] = 'invented_surface'
        elif mutation == 'incomplete':
            outcome['observation']['complete_consumption'] = False
        else:
            changed_rows[observations.index(row)]['engine_execution_seconds'] += 1.0
        changed[outcome_key] = encoded(outcome)
        changed_rows[observations.index(row)]['evidence_sha256'] = sha(changed[outcome_key])
        receipt = json.loads(files[receipt_key])
        receipt['stdout_sha256'] = sha(changed[outcome_key])
        changed[receipt_key] = encoded(receipt)
        changed[observation_key] = b'\n'.join(encoded(item) for item in changed_rows)
        reject('rehashed_' + mutation, changed)
    changed = dict(files)
    summary_key = 'evidence/full238_tiny_parity_r1/summary.json'
    summary = json.loads(files[summary_key])
    for family in summary['families'].values():
        family['case_surface_outcomes'].pop('engine_error', None)
    changed[summary_key] = encoded(summary)
    reject('erased_original_cli_failure', changed)
    changed_manifest = deepcopy(manifest)
    changed_manifest['baseline_pairs'].pop()
    reject('missing_polars_pair', files, changed_manifest)

    # The child receives only source files and compact evidence. Its audit hook
    # forbids original workspace/data access, native/baseline imports and effects.
    cache = Path('/Users/dylan/.cache/shardloom')
    with tempfile.TemporaryDirectory(prefix='broad-query-replay-', dir=cache) as directory:
        destination = Path(directory)
        copied = []
        sources = [*sorted((ROOT / 'python/src').rglob('*.py')),
                   *sorted((ROOT / 'benchmarks/traditional_analytics/query_surface').glob('*.py')),
                   ROOT / 'scripts/native_workflow_protocol.py', PACKET / 'manifest.json', PACKET / 'packet.tar.xz']
        for source in sources:
            relative = source.relative_to(ROOT)
            target = destination / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            digest = sha(source.read_bytes())
            assert sha(target.read_bytes()) == digest
            copied.append({'path': str(relative), 'sha256': digest})
        program = '''
import importlib.abc, os, pathlib, runpy, sys
class NoEngine(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in {'polars', 'pyarrow'} or fullname == 'shardloom._native':
            raise AssertionError('engine/transport import attempted: ' + fullname)
sys.meta_path.insert(0, NoEngine())
def audit(event, args):
    if event in {'subprocess.Popen', 'os.system', 'socket.connect'}:
        raise AssertionError('effect attempted: ' + event)
    if event == 'open' and isinstance(args[0], (str, bytes)):
        name = os.fsdecode(args[0])
        if name.startswith(('/Users/dylan/LocalData/shardloom/', '/Users/dylan/.codex/worktrees/')):
            raise AssertionError('original local evidence/source access: ' + name)
sys.addaudithook(audit)
sys.argv = sys.argv[1:]
runpy.run_path(sys.argv[0], run_name='__main__')
'''
        result = subprocess.run([sys.executable, '-I', '-B', '-c', program,
            str(destination / 'benchmarks/traditional_analytics/query_surface/replay.py'),
            str(destination / PACKET.relative_to(ROOT))], cwd=destination,
            capture_output=True, text=True, timeout=120, check=False)
        if result.returncode:
            raise AssertionError(result.stdout + result.stderr)
        relocated = json.loads(result.stdout)
        assert relocated == accepted
        copied_unchanged = all(sha((destination / row['path']).read_bytes()) == row['sha256'] for row in copied)
        assert copied_unchanged
    report = {'schema_version': 'shardloom.broad_query.portable_controls.v1', 'status': 'passed',
        'packet_manifest_sha256': sha(manifest_bytes), 'packet_archive_sha256': sha(packed),
        'semantic_controls': controls, 'semantic_controls_count': len(controls),
        'relocated_replay': relocated, 'copied_files': copied,
        'copied_files_unchanged': copied_unchanged, 'temporary_source_copy_removed': not destination.exists(),
        'original_source_and_evidence_access_denied': True, 'native_and_polars_pyarrow_imports_denied': True,
        'subprocess_network_and_shell_effects_denied': True, 'queries_executed': 0,
        'python': sys.version, 'script_sha256': sha(Path(__file__).read_bytes())}
    (Path(__file__).resolve().parent.parent / 'portable-controls-r2.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': 'passed', 'semantic_controls': len(controls),
        'complete_results': accepted['checked_complete_results'], 'receipts': accepted['checked_receipts'],
        'relocated_with_engines_and_original_data_denied': True, 'queries_executed': 0}))


if __name__ == '__main__':
    main()
