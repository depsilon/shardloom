"""Check generated references and the reviewed package/legal boundaries."""
import subprocess
import sys
from pathlib import Path

evidence = Path(__file__).resolve().parent.parent
commands = [
    [sys.executable, 'scripts/write_public_api_reference.py', '--check'],
    [sys.executable, 'scripts/check_python_license_bundle.py'],
    [sys.executable, 'scripts/check_security_posture.py'],
    [sys.executable, 'scripts/check_contribution_governance.py', '--output', str(evidence / 'governance-r1.json')],
    [sys.executable, '-m', 'unittest', 'discover', '-s', 'scripts', '-p', 'test_python_license_bundle.py', '-v'],
    [sys.executable, '-m', 'unittest', 'discover', '-s', 'python/tests', '-p', 'test_public_api_reference.py', '-v'],
    [sys.executable, '-m', 'unittest', 'discover', '-s', 'python/tests', '-p', 'test_query_surface_replay.py', '-v'],
    [sys.executable, '-m', 'unittest', 'discover', '-s', 'python/tests', '-p', 'test_query_surface_evidence.py', '-v'],
]
for command in commands:
    print('Running', command, flush=True)
    subprocess.run(command, check=True)
