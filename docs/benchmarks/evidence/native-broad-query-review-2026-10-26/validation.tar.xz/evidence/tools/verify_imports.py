#!/usr/bin/env python3
"""Read-only verifier for the Arrow IPC, Parquet, and ORC dependency-only imports."""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import tarfile
import tomllib
from pathlib import Path, PurePosixPath


BASELINE = "1b21bf0f11a7f4f15919db2790cc174243d26c3b"
PROVIDERS = {
    "arrow-ipc": ("59.3.1", 22, 881877, "8e244f39b82fa7a823e8b5984a0bd988234f9c92c1df79378fb85090e6e4c821"),
    "parquet": ("59.3.1", 227, 5381052, "8b3d2ef0fb136e9341570f219ecb168902e76079c6d81ad555f0a4840b1e08a3"),
    "orc-rust": ("0.9.0", 60, 721721, "e54c163f843c4f0fcfca65b9b73ca6f93c37c8e86736d5a1e578c6e843eed0a0"),
}
EXPECTED_ZSTD = {
    "zstd": ("0.14.3", "db3ae9bf90af6e40197bef767eeefc46ad6397420fe873830bd85e5fbbfb3c70"),
    "zstd-safe": ("8.2.0", "ded520f16b29e1a9b771c722221b2b0a0398c2316d9bb3c42b458a5414d7434b"),
    "zstd-sys": ("2.1.2+zstd.1.5.7", "481ada9c543b2323cbb7bbdbb5249177fbf0188ed959ed2c15e4b22421c84ed3"),
}
EXPECTED_PARENTS = {"arrow-ipc": "59.3.1", "parquet": "59.3.1", "orc-rust": "0.9.0"}
OLD_ZSTD = {
    "zstd": ("0.13.3", "e91ee311a569c327171651566e07972200e76fcfe2242a4fa446149a3881c08a"),
    "zstd-safe": ("7.2.4", "8f49c4d5f0abb602a93fb8736af2a4f4dd9512e36f7f570d66e65ff867ed3b9d"),
    "zstd-sys": ("2.0.16+zstd.1.5.7", "91e19ebc2adc8f83e43039e79776e3fda8ca919132d68a1fed6a5faca2683748"),
}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def package_map(lock: dict) -> dict[tuple[str, str], dict]:
    return {(p["name"], p["version"]): p for p in lock["package"]}


def verify_manifest_delta(original: bytes, current: bytes, name: str) -> list[str]:
    before = tomllib.loads(original.decode())
    after = tomllib.loads(current.decode())
    expected = json.loads(json.dumps(before))
    expected.setdefault("package", {})["publish"] = False
    zstd_sections = []
    for section in ("dependencies", "dev-dependencies", "build-dependencies"):
        dep = expected.get(section, {}).get("zstd")
        if dep is not None:
            if isinstance(dep, str):
                expected[section]["zstd"] = "=0.14.3"
            else:
                dep["version"] = "=0.14.3"
            zstd_sections.append(section)
    if not zstd_sections:
        raise ValueError(f"{name}: source manifest had no zstd dependency")
    if after != expected:
        raise ValueError(f"{name}: manifest semantic delta exceeds publish=false and zstd version pins")
    if current == original:
        raise ValueError(f"{name}: manifest does not contain the requested changes")
    # In these registry manifests every direct zstd dependency is in the ordinary or dev section.
    for section in zstd_sections:
        value = after[section]["zstd"]
        version = value if isinstance(value, str) else value.get("version")
        if version != "=0.14.3":
            raise ValueError(f"{name}: {section}.zstd is not exactly pinned")
    return zstd_sections


def verify_provider(root: Path, cache: Path, name: str) -> dict:
    version, expected_count, expected_bytes, expected_archive_sha = PROVIDERS[name]
    folder = root / "vendor" / name
    provenance_path = folder / "upstream-provenance.json"
    provenance = json.loads(provenance_path.read_text())
    archive_path = cache / f"{name}-{version}.crate"
    archive_bytes = archive_path.read_bytes()
    archive_sha = sha(archive_bytes)
    if archive_sha != expected_archive_sha or archive_sha != provenance["registry_archive_sha256"]:
        raise ValueError(f"{name}: cached archive digest mismatch")

    prefix = f"{name}-{version}/"
    raw_members: dict[str, bytes] = {}
    total = 0
    with tarfile.open(archive_path, "r:gz") as archive:
        members = archive.getmembers()
        seen = set()
        for member in members:
            path = PurePosixPath(member.name)
            if path.is_absolute() or ".." in path.parts or not member.isfile() or member.name in seen:
                raise ValueError(f"{name}: unsafe, nonregular, or duplicate archive member {member.name}")
            if not member.name.startswith(prefix):
                raise ValueError(f"{name}: archive member has unexpected root {member.name}")
            seen.add(member.name)
            data = archive.extractfile(member).read()
            if len(data) != member.size:
                raise ValueError(f"{name}: archive member byte count mismatch {member.name}")
            rel = str(path.relative_to(name + "-" + version))
            raw_members[rel] = data
            total += len(data)
    if (len(members), total) != (expected_count, expected_bytes):
        raise ValueError(f"{name}: archive count/size differs from expected values")
    if (len(members), total) != (provenance["registry_archive_file_count"], provenance["registry_archive_uncompressed_bytes"]):
        raise ValueError(f"{name}: archive count/size differs from provenance")

    original_hashes = {rel: sha(data) for rel, data in raw_members.items()}
    if original_hashes != provenance["original_files_sha256"]:
        raise ValueError(f"{name}: archive original member map differs from provenance")
    omitted = provenance["omitted_files"].get("Cargo.lock")
    if not omitted or omitted.get("original_sha256") != original_hashes.get("Cargo.lock"):
        raise ValueError(f"{name}: omitted Cargo.lock hash/reason record mismatch")
    if "root Cargo.lock" not in omitted.get("reason", ""):
        raise ValueError(f"{name}: Cargo.lock omission reason does not state root lock ownership")

    modified = provenance.get("modified_files_sha256", {})
    expected_modified = {"Cargo.toml", "src/compression.rs"} if name == "orc-rust" else {"Cargo.toml"}
    if set(modified) != expected_modified:
        raise ValueError(f"{name}: modified source inventory differs from reviewed patch")
    manifest_sections = verify_manifest_delta(raw_members["Cargo.toml"], (folder / "Cargo.toml").read_bytes(), name)
    if sha((folder / "Cargo.toml").read_bytes()) != modified["Cargo.toml"]:
        raise ValueError(f"{name}: edited Cargo.toml hash differs from provenance")

    added = provenance.get("added_files_sha256", {})
    if "upstream-provenance.json" in added:
        raise ValueError(f"{name}: provenance self-hash must be excluded from added map")
    expected_paths = set(raw_members) - {"Cargo.lock"}
    expected_paths.update(added)
    expected_paths.add("upstream-provenance.json")
    actual_paths = {f.relative_to(folder).as_posix() for f in folder.rglob("*") if f.is_file() and f.name != "Cargo.lock"}
    if actual_paths != expected_paths:
        raise ValueError(f"{name}: imported file accounting differs; missing={sorted(expected_paths-actual_paths)}, extra={sorted(actual_paths-expected_paths)}")

    for rel, original in raw_members.items():
        if rel == "Cargo.lock":
            continue
        data = (folder / rel).read_bytes()
        if rel in modified:
            if sha(data) != modified[rel]:
                raise ValueError(f"{name}: modified member hash mismatch: {rel}")
            if rel == "src/compression.rs":
                before = b'self.decompressor.advance().unwrap();'
                after = b'self.decompressor.advance().map_err(std::io::Error::other)?;'
                if original.count(before) != 2 or data != original.replace(before, after):
                    raise ValueError("orc-rust: source patch differs from the two reviewed error propagations")
        elif sha(data) != original_hashes[rel]:
            raise ValueError(f"{name}: original member changed: {rel}")
    for rel, expected_sha in added.items():
        data = (folder / rel).read_bytes()
        if sha(data) != expected_sha:
            raise ValueError(f"{name}: added member hash mismatch: {rel}")
    if sha((folder / "upstream-provenance.json").read_bytes()) == added.get("upstream-provenance.json"):
        raise ValueError(f"{name}: impossible self-hash entry")

    lock_path = folder / "Cargo.lock"
    ignored_lock = None
    if lock_path.exists():
        lock_bytes = lock_path.read_bytes()
        if sha(lock_bytes) != original_hashes["Cargo.lock"]:
            raise ValueError(f"{name}: existing local Cargo.lock differs from archive")
        tracked = subprocess.run(["git", "ls-files", "--error-unmatch", str(lock_path.relative_to(root))], cwd=root,
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False).returncode == 0
        if tracked:
            raise ValueError(f"{name}: Cargo.lock is tracked despite committed-scope omission")
        ignored_lock = {"present": True, "sha256": sha(lock_bytes), "bytes": len(lock_bytes), "tracked": False}
    else:
        ignored_lock = {"present": False, "sha256": original_hashes["Cargo.lock"], "tracked": False}

    for field in ("LICENSE", "NOTICE"):
        if field == "NOTICE" and name == "orc-rust":
            if not provenance.get("notice_status"):
                raise ValueError("orc-rust: missing recorded NOTICE status")
            continue
        source_rel = field + ".txt" if name != "orc-rust" else field
        alias = folder / field
        source = folder / source_rel
        if not alias.is_file() or not source.is_file() or alias.read_bytes() != source.read_bytes():
            raise ValueError(f"{name}: {field} alias is not byte-identical to source")
        if sha(alias.read_bytes()) != provenance.get(field.lower() + "_sha256"):
            raise ValueError(f"{name}: {field} digest differs from provenance")
        if field == "NOTICE" and sha(alias.read_bytes()) != provenance.get("notice_sha256"):
            raise ValueError(f"{name}: NOTICE digest differs from provenance")

    provenance_rel = "upstream-provenance.json"
    deliverable_paths = actual_paths - {provenance_rel}
    deliverable_bytes = sum((folder / rel).stat().st_size for rel in deliverable_paths)
    return {
        "archive_sha256": archive_sha,
        "archive_file_count": len(members),
        "archive_uncompressed_bytes": total,
        "original_members_verified": len(raw_members) - 1,
        "modified_files": modified,
        "zstd_dependency_sections_pinned": manifest_sections,
        "added_files_verified": len(added),
        "deliverable_file_count_excluding_provenance_and_local_lock": len(deliverable_paths),
        "deliverable_bytes_excluding_provenance_and_local_lock": deliverable_bytes,
        "omitted_lock": ignored_lock,
        "license_sha256": provenance["license_sha256"],
        "notice_sha256": provenance.get("notice_sha256"),
    }


def verify_locks(root: Path) -> dict:
    current = tomllib.loads((root / "Cargo.lock").read_text())
    current_map = package_map(current)
    zstd_result = {}
    for name, (version, checksum) in EXPECTED_ZSTD.items():
        entries = [x for x in current["package"] if x["name"] == name]
        if len(entries) != 1 or entries[0]["version"] != version or entries[0].get("checksum") != checksum:
            raise ValueError(f"root Cargo.lock: expected exactly one {name} {version} with recorded checksum")
        zstd_result[name] = {"version": version, "checksum": checksum, "count": len(entries)}
    for name, version in EXPECTED_PARENTS.items():
        if (name, version) not in current_map:
            raise ValueError(f"root Cargo.lock: expected original immediate parent {name} {version}")
    baseline_bytes = subprocess.run(["git", "show", f"{BASELINE}:Cargo.lock"], cwd=root,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True).stdout
    baseline = tomllib.loads(baseline_bytes.decode())
    old_map, new_map = package_map(baseline), package_map(current)
    expected_changed = {("arrow-ipc", "59.3.1"), ("parquet", "59.3.1"), ("orc-rust", "0.9.0"),
                        ("zstd", "0.13.3"), ("zstd-safe", "7.2.4"), ("zstd-sys", "2.0.16+zstd.1.5.7")}
    expected_packages = []
    for package in baseline["package"]:
        transformed = dict(package)
        ident = (package["name"], package["version"])
        if ident in {("arrow-ipc", "59.3.1"), ("parquet", "59.3.1"), ("orc-rust", "0.9.0")}:
            transformed.pop("source", None)
            transformed.pop("checksum", None)
        elif ident[0] in EXPECTED_ZSTD:
            transformed["version"], transformed["checksum"] = EXPECTED_ZSTD[ident[0]]
        expected_packages.append(transformed)
    canonical = lambda rows: sorted(json.dumps(x, sort_keys=True) for x in rows)
    if canonical(expected_packages) != canonical(current["package"]):
        raise ValueError("root Cargo.lock differs from baseline by more than three path identities and three Zstd package version/checksum updates")
    changes = []
    for ident in sorted(expected_changed):
        old = old_map[ident]
        new_version = EXPECTED_ZSTD[ident[0]][0] if ident[0] in EXPECTED_ZSTD else ident[1]
        new = new_map[(ident[0], new_version)]
        changes.append({"baseline_identity": list(ident), "before": old, "after": new})
    return {"zstd_packages": zstd_result, "original_parent_versions_present": EXPECTED_PARENTS,
            "baseline_commit": BASELINE, "only_expected_lock_entries_changed": True,
            "changed_entries": [{"identity": x["baseline_identity"],
                                 "before_version": x["before"]["version"], "after_version": x["after"]["version"],
                                 "source_identity_changed": x["before"].get("source") != x["after"].get("source"),
                                 "checksum_changed": x["before"].get("checksum") != x["after"].get("checksum")}
                                for x in changes]}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True, help="repository checkout root")
    parser.add_argument("--archive-dir", type=Path, required=True, help="directory containing exact .crate archives")
    parser.add_argument("--output", type=Path, required=True, help="verification JSON output path")
    args = parser.parse_args()
    root, cache = args.root.resolve(), args.archive_dir.resolve()
    report = {"schema": "shardloom.source_import_verification.v1", "root": str(root),
              "archive_dir": str(cache), "status": "failed", "providers": {}, "checks": {}}
    try:
        for provider in PROVIDERS:
            report["providers"][provider] = verify_provider(root, cache, provider)
        report["checks"]["root_lock"] = verify_locks(root)
        report["checks"]["all_imports_verified"] = True
        report["status"] = "passed"
    except Exception as error:
        report["error"] = f"{type(error).__name__}: {error}"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "output": str(args.output.resolve()),
                      "error": report.get("error")}, sort_keys=True))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
