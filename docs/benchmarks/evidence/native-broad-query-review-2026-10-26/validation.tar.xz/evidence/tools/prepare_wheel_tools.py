"""Prepare the repository's hash-pinned wheel tooling and optional test clients."""
from pathlib import Path
import subprocess
import sys

root = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
evidence = Path(__file__).resolve().parent.parent
environment = evidence / 'wheel-build-tools'
wheelhouse = evidence / 'installed-proof-wheelhouse'
assert not environment.exists() and not wheelhouse.exists()
subprocess.run([sys.executable, '-m', 'venv', str(environment)], check=True)
python = str(environment / 'bin/python')
subprocess.run([python, '-m', 'pip', 'install', '--require-hashes', '--only-binary=:all:',
                '-r', str(root / '.github/requirements/ci-native-python-build.txt')], check=True)
wheelhouse.mkdir()
subprocess.run([python, '-m', 'pip', 'download', '--require-hashes', '--only-binary=:all:',
                '--dest', str(wheelhouse), '-r', str(root / '.github/requirements/ci-native-python.txt')], check=True)
