"""Finish changed-test lint, package integrity and installed-wheel proof sequentially."""
from pathlib import Path
import subprocess
import sys

evidence = Path(__file__).resolve().parent.parent
guard = str(evidence / 'tools/run_guarded.py')
commands = [
    ('r29-default-clippy', ['cargo', 'clippy', '--locked', '--offline', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('r30-default-tests', ['cargo', 'test', '--locked', '--offline', '--workspace', '--all-targets', '--', '--test-threads=2']),
    ('r31-native-zstd', ['cargo', 'test', '--locked', '--offline', '--profile', 'ci-native', '-p', 'shardloom-vortex', '--lib', '--features', 'release-user-surfaces', 'zstd', '--', '--test-threads=2']),
    ('r32-native-formats', ['cargo', 'test', '--locked', '--offline', '--profile', 'ci-native', '-p', 'shardloom-vortex', '--lib', '--features', 'release-user-surfaces', 'universal_format_io', '--', '--test-threads=2']),
    ('r35-format', ['cargo', 'fmt', '--all', '--', '--check']),
    ('r34-native-clippy', ['cargo', 'clippy', '--locked', '--offline', '--profile', 'ci-native', '-p', 'shardloom-cli', '-p', 'shardloom-vortex', '--all-targets', '--features', 'release-user-surfaces', '--', '-D', 'warnings']),
    ('r21-docs-notices', [sys.executable, str(evidence / 'tools/check_docs_and_notices.py')]),
    ('r33-portable-replay', [sys.executable, str(evidence / 'tools/verify_portable_packet.py')]),
    ('r22-wheel-tools', [sys.executable, str(evidence / 'tools/prepare_wheel_tools.py')]),
    ('r23-release-build', ['cargo', 'build', '--release', '--locked', '--offline', '-p', 'shardloom-cli', '-p', 'shardloom-python', '--features', 'shardloom-cli/release-user-surfaces,shardloom-python/python-native']),
    ('r24-freeze-runtime', [sys.executable, str(evidence / 'tools/freeze_candidate_runtime.py')]),
    ('r25-installed-wheel', [str(evidence / 'wheel-build-tools/bin/python'), '-B', 'scripts/prove_native_python_wheel.py', '--repo-root', '/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo', '--output-dir', str(evidence / 'installed-wheel-r1'), '--native-library', str(evidence / 'candidate-runtime-r1/_native.abi3.so'), '--cli-binary', str(evidence / 'candidate-runtime-r1/shardloom'), '--wheelhouse', str(evidence / 'installed-proof-wheelhouse')]),
]
for name, command in commands[4:]:
    print(name, flush=True)
    result = subprocess.run([sys.executable, guard, '--name', name, '--timeout', '2400', '--', *command])
    if result.returncode:
        raise SystemExit(result.returncode)
