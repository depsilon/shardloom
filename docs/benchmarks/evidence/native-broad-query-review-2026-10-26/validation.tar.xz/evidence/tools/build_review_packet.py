"""Retain closed validation records and verify every compressed member without extraction."""
from __future__ import annotations

import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
EVIDENCE = Path(__file__).resolve().parent.parent
PACKET = ROOT / 'docs/benchmarks/evidence/native-broad-query-review-2026-10-26'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text())


files = {}


def add(path, name):
    assert path.is_file() and not path.is_symlink(), path
    assert name not in files and not PurePosixPath(name).is_absolute()
    assert '..' not in PurePosixPath(name).parts
    data = path.read_bytes()
    assert len(data) <= 16 << 20, path
    files[name] = data


assert not PACKET.exists()
required = ['r04-provider', 'r07-dependency-audit', 'r08-old-zstd-negative-control',
            'r17-provider-clippy', 'r21-docs-notices', 'r23-release-build',
            'r24-freeze-runtime', 'r25-installed-wheel', 'r28-native-compression-correction',
            'r29-default-clippy', 'r30-default-tests', 'r31-native-zstd',
            'r32-native-formats', 'r33-portable-replay', 'r34-native-clippy', 'r35-format']
for name in required:
    record = read(EVIDENCE / (name + '.json'))
    assert record['status'] == 'passed' and record['returncode'] == 0, name
    assert record['process_group_drained'] and record['direct_child_reaped'], name
package = read(EVIDENCE / 'installed-wheel-r1/report.json')
assert package['status'] == package['uninstall_status'] == 'passed'
assert package['integration'] == dict(tests=183, failures=0, errors=0, skipped=0, status='passed')
assert read(EVIDENCE / 'source-import-verification-r2.json')['status'] == 'passed'
assert read(EVIDENCE / 'license-bundle-verification-r2.json')['status'] == 'passed'
assert read(EVIDENCE / 'package-cleanup-r1.json')['status'] == 'passed'
assert read(EVIDENCE / 'dependency-audit-r2.json')['release_gate'] is True
controls = read(EVIDENCE / 'portable-controls-r2.json')
assert controls['status'] == 'passed' and controls['queries_executed'] == 0
baseline = ROOT / 'docs/benchmarks/evidence/native-broad-query-2026-10-26'
assert sha((baseline / 'manifest.json').read_bytes()) == controls['packet_manifest_sha256']
assert sha((baseline / 'packet.tar.xz').read_bytes()) == controls['packet_archive_sha256']

receipts = []
for path in sorted(EVIDENCE.glob('r[0-9][0-9]-*.json')):
    record = read(path)
    log = path.with_suffix('.log')
    assert sha(log.read_bytes()) == record['log_sha256'], path
    assert record['process_group_drained'] and record['direct_child_reaped'], path
    receipts.append({key: record.get(key) for key in
                     ('status', 'command', 'returncode', 'log_sha256', 'process_group_drained')}
                    | {'receipt': path.name, 'log': log.name})
assert {r['receipt'] for r in receipts if r['status'] != 'passed'} == {
    'r05-dependency-audit.json', 'r10-default-clippy.json', 'r18-native-tests.json',
    'r20-native-clippy.json', 'r26-replay-before.json'}
for directory in [EVIDENCE, EVIDENCE / 'installed-wheel-r1']:
    for path in sorted(directory.iterdir()):
        if path.is_file() and path.suffix in {'.json', '.log'}:
            add(path, 'evidence/' + str(path.relative_to(EVIDENCE)))
for path in sorted((EVIDENCE / 'tools').glob('*.py')):
    add(path, 'evidence/tools/' + path.name)
for name in ('Cargo.toml', 'Cargo.lock', 'src/lib.rs'):
    add(EVIDENCE / 'negative-control-original-zstd' / name, 'evidence/negative-control-original-zstd/' + name)
add(EVIDENCE / 'candidate-runtime-r1/manifest.json', 'evidence/candidate-runtime-r1/manifest.json')

changed = subprocess.check_output(['git', 'diff', '--name-only', '--diff-filter=ACMRT'], cwd=ROOT, text=True).splitlines()
changed += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=ROOT, text=True).splitlines()
source_inventory = {}
for name in sorted(set(changed)):
    path = ROOT / name
    assert path.is_file() and not path.is_symlink()
    data = path.read_bytes()
    source_inventory[name] = {'sha256': sha(data), 'bytes': len(data)}
    add(path, 'source/' + name)
assert sum(len(data) for data in files.values()) < 64 << 20

PACKET.mkdir()
archive_path = PACKET / 'validation.tar.xz'
with tarfile.open(archive_path, 'w:xz', preset=6) as archive:
    for name, data in sorted(files.items()):
        entry = tarfile.TarInfo(name)
        entry.size, entry.mode, entry.mtime = len(data), 0o644, 0
        archive.addfile(entry, io.BytesIO(data))
seen = set()
with tarfile.open(archive_path, 'r:xz') as archive:
    for entry in archive:
        assert entry.isfile() and entry.name in files and entry.name not in seen
        assert entry.size == len(files[entry.name])
        assert archive.extractfile(entry).read() == files[entry.name]
        seen.add(entry.name)
assert seen == files.keys()
manifest = {
    'schema_version': 'shardloom.review_validation_packet.v1',
    'status': 'passed',
    'scope': 'PR 1611 compression dependency correction, ORC malformed-input errors and receipt-first replay',
    'base_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'source_inventory': source_inventory,
    'archive': {'path': archive_path.name, 'sha256': sha(archive_path.read_bytes()), 'bytes': archive_path.stat().st_size},
    'files': {name: {'sha256': sha(data), 'bytes': len(data)} for name, data in sorted(files.items())},
    'receipts': receipts,
    'baseline_packet_unchanged': {'manifest_sha256': controls['packet_manifest_sha256'],
                                  'archive_sha256': controls['packet_archive_sha256'], 'queries_executed': 0},
    'proof_boundaries': [
        'Unsigned consistency and recorded validation evidence; no signature or independent build attestation.',
        'Full native local attempt retained: 3300 passed, one ORC panic, 32 manual ignores; corrected native format and Zstd suites pass. Hosted CI supplies final complete native partitions.',
        'Two wrapper regressions fail against original dependencies; this is not proof that all four advisory mechanisms were reachable in the supported product.',
        'Runtime binaries, wheel and registry archives are identified by hash; payloads are not included.',
        'Existing frozen baseline results and their known provenance gaps are unchanged.'
    ],
}
(PACKET / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
assert read(PACKET / 'manifest.json') == manifest
print(json.dumps({'status': 'passed', 'archive_bytes': archive_path.stat().st_size,
                  'retained_files': len(files), 'receipt_count': len(receipts),
                  'retained_failures': sum(r['status'] != 'passed' for r in receipts),
                  'source_files': len(source_inventory), 'every_member_reopened': True}, indent=2))
