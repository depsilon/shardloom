"""Preserve the tested dependency-corrected runtime separately from the baseline."""
import hashlib
import json
import shutil
from pathlib import Path

evidence = Path(__file__).resolve().parent.parent
destination = evidence / 'candidate-runtime-r1'
destination.mkdir()
target = Path('/Users/dylan/.cache/shardloom/cargo-target/release')
files = {}
for source_name, target_name in [('shardloom', 'shardloom'), ('lib_native.dylib', '_native.abi3.so')]:
    source = target / source_name
    assert source.is_file() and not source.is_symlink()
    data = source.read_bytes()
    copied = destination / target_name
    shutil.copy2(source, copied)
    assert copied.read_bytes() == data
    files[target_name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'source': str(source)}
(destination / 'manifest.json').write_text(json.dumps({'files': files, 'build_receipt': 'r23-release-build.json'}, indent=2) + '\n')
print(json.dumps(files, indent=2))
