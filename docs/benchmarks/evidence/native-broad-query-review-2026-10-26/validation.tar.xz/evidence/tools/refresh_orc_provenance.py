"""Record the narrow ORC error-propagation correction and regenerate legal metadata."""
from pathlib import Path
import hashlib
import importlib.util
import json

root = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
evidence = Path(__file__).resolve().parent.parent
provider = root / 'vendor/orc-rust'
path = provider / 'upstream-provenance.json'
record = json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
record['migration_status'] = 'dependency_pin_and_compressed_error_propagation'
record['modified_files_sha256']['src/compression.rs'] = sha(provider / 'src/compression.rs')
record['added_files_sha256']['README.shardloom.md'] = sha(provider / 'README.shardloom.md')
record['local_changes_documentation']['sha256'] = sha(provider / 'README.shardloom.md')
path.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
spec = importlib.util.spec_from_file_location('notices', root / 'scripts/check_python_license_bundle.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.generate(root, evidence / 'license-inventory-r1.json', replace=True)
(evidence / 'license-bundle-verification-r2.json').write_text(json.dumps(module.verify(root), indent=2) + '\n')
