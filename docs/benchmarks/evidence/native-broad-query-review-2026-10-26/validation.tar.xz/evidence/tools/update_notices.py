"""Refresh reviewed notices for the exact compression dependency correction."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import tarfile
import tomllib

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent.parent
REGISTRY = Path('/Users/dylan/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f')
ARCHIVES = Path('/Users/dylan/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f')
BUNDLE = ROOT / 'python/THIRD_PARTY_LICENSES'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    prior_bytes = subprocess.check_output(
        ['git', 'show', '1b21bf0f:python/THIRD_PARTY_LICENSES/manifest.json'], cwd=ROOT)
    assert (BUNDLE / 'manifest.json').read_bytes() == prior_bytes
    prior = json.loads(prior_bytes)
    by_identity = {(p['name'], p['version'], p['source']): p for p in prior['components']}
    packages = []
    changed = []
    for locked in tomllib.loads((ROOT / 'Cargo.lock').read_text())['package']:
        if not locked.get('source', '').startswith('registry+'):
            continue
        key = locked['name'], locked['version'], locked['source']
        directory = REGISTRY / f'{locked["name"]}-{locked["version"]}'
        manifest_path = directory / 'Cargo.toml'
        row = {k: locked[k] for k in ('name', 'version', 'source')}
        row['manifest_path'] = str(manifest_path)
        row['files'] = []
        if key in by_identity:
            original = by_identity[key]
            assert locked['checksum'] == original['crate_checksum_sha256']
            row.update({k: original[k] for k in ('license', 'repository')})
            for item in original['files']:
                data = (BUNDLE / item['text']).read_bytes()
                assert sha(data) == item['sha256'] and len(data) == item['bytes']
                cached = directory / item.get('crate_path', '__no_registry_path__')
                file = {'sha256': sha(data), 'bytes': len(data)}
                if item.get('crate_path') and cached.is_file():
                    assert cached.read_bytes() == data
                    file.update(source_path=str(cached), evidence_source='registry_cache',
                                package_relative_path=item['crate_path'])
                else:
                    # Same immutable committed notice, package checksum and exact bytes.
                    # Its source remains the previously reviewed archive or upstream URL.
                    url = item.get('upstream_url') or (
                        f'https://static.crates.io/crates/{locked["name"]}/'
                        f'{locked["name"]}-{locked["version"]}.crate#{item["crate_path"]}')
                    file.update(source_path=str(BUNDLE / item['text']),
                                evidence_source='preserved_reviewed_bundle_1b21bf0f',
                                upstream_url=url)
                row['files'].append(file)
        else:
            assert locked['name'] in {'zstd', 'zstd-safe', 'zstd-sys'}, key
            package = tomllib.loads(manifest_path.read_text())['package']
            assert package['license'] == 'BSD-3-Clause'
            row.update({k: package[k] for k in ('license', 'repository')})
            archive = ARCHIVES / f'{locked["name"]}-{locked["version"]}.crate'
            assert sha(archive.read_bytes()) == locked['checksum']
            prefix = f'{locked["name"]}-{locked["version"]}/'
            with tarfile.open(archive, 'r:gz') as stream:
                for member in stream.getmembers():
                    assert member.isreg() and member.name.startswith(prefix)
                    relative = member.name[len(prefix):]
                    if not Path(relative).name.upper().startswith(('LICENSE', 'NOTICE', 'COPYING')):
                        continue
                    data = stream.extractfile(member).read()
                    cached = directory / relative
                    assert cached.read_bytes() == data
                    row['files'].append({'source_path': str(cached), 'sha256': sha(data),
                        'bytes': len(data), 'evidence_source': 'registry_cache',
                        'package_relative_path': relative})
            assert row['files']
            changed.append({'name': locked['name'], 'version': locked['version'],
                            'archive_sha256': locked['checksum'], 'legal_files': row['files']})
        packages.append(row)
    inventory = OUT / 'license-inventory-r1.json'
    assert not inventory.exists()
    inventory.write_text(json.dumps({'packages': packages}, indent=2) + '\n')
    spec = importlib.util.spec_from_file_location('notices', ROOT / 'scripts/check_python_license_bundle.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.generate(ROOT, inventory, replace=True)
    current = json.loads((BUNDLE / 'manifest.json').read_text())
    used = {f['text'] for p in current['components'] + current['vendored_components'] for f in p['files']}
    original_texts = {f['text']: f for p in prior['components'] + prior['vendored_components'] for f in p['files']}
    retired = []
    for path in (BUNDLE / 'texts').iterdir():
        relative = str(path.relative_to(BUNDLE))
        if relative in used:
            continue
        data = path.read_bytes()
        assert not path.is_symlink() and sha(data) == original_texts[relative]['sha256']
        retired.append({'path': relative, 'sha256': sha(data), 'bytes': len(data)})
        path.unlink()
    result = module.verify(ROOT)
    result.update(changed_registry_packages=changed, retired_unreferenced_texts=retired,
                  prior_manifest_sha256=sha(prior_bytes),
                  manifest_sha256=sha((BUNDLE / 'manifest.json').read_bytes()))
    (OUT / 'license-bundle-verification-r1.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('status', 'registry_packages', 'vendored_packages',
                                          'license_file_records', 'unique_text_files')}))


if __name__ == '__main__':
    main()
