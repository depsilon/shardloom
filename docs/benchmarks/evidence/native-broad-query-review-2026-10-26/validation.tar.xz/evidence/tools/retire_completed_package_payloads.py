"""Retire only this correction's completed temporary installation environments."""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

ROOT = Path(__file__).resolve().parents[1]
assert ROOT == Path('/Users/dylan/LocalData/shardloom/compression-security-2026-10-26')
assert ROOT.resolve() == ROOT
OUTPUT, INVENTORY = ROOT / 'package-cleanup-r1.json', ROOT / 'package-retirement-r1.json'
assert not OUTPUT.exists() and not INVENTORY.exists()


def read(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    value = path.lstat()
    row = {'path': str(path), 'generation': [value.st_dev, value.st_ino, value.st_mode,
        value.st_size, value.st_mtime_ns, value.st_ctime_ns]}
    if stat.S_ISREG(value.st_mode):
        row.update(kind='regular', sha256=sha(path), allocated_bytes=value.st_blocks * 512)
    elif stat.S_ISLNK(value.st_mode):
        row.update(kind='symlink', target=os.readlink(path))
    elif stat.S_ISDIR(value.st_mode):
        row.update(kind='directory')
    else:
        raise ValueError('unexpected generated file type: ' + str(path))
    return row


def inventory(root):
    assert root.is_dir() and root.resolve() == root and not (root / '.git').exists()
    rows = [identity(root)]
    def visit(directory):
        for path in sorted(directory.iterdir()):
            row = identity(path)
            rows.append(row)
            if row['kind'] == 'directory':
                visit(path)
    visit(root)
    return rows


package = read(ROOT / 'installed-wheel-r1/report.json')
assert package['status'] == package['uninstall_status'] == 'passed'
assert package['integration'] == dict(tests=183, failures=0, errors=0, skipped=0, status='passed')
for name in ('r25-installed-wheel', 'r21-docs-notices', 'r33-portable-replay'):
    record = read(ROOT / (name + '.json'))
    assert record['status'] == 'passed' and record['process_group_drained']
assert read(ROOT / 'portable-controls-r2.json')['status'] == 'passed'
retained = {str(ROOT / 'candidate-runtime-r1/_native.abi3.so'): package['integrity']['native_library_sha256'],
    str(ROOT / 'candidate-runtime-r1/shardloom'): package['integrity']['cli_sha256'],
    str(ROOT / 'installed-wheel-r1/dist' / package['integrity']['wheel']): package['integrity']['wheel_sha256']}
assert all(sha(Path(path)) == digest for path, digest in retained.items())
roots = [ROOT / path for path in ('installed-wheel-r1/package', 'installed-wheel-r1/venv',
    'wheel-build-tools', 'installed-proof-wheelhouse', 'audit-env')]
assert all(not (root == Path(path) or root in Path(path).parents) for root in roots for path in retained)
for name in ('installed-wheel-r1/venv', 'wheel-build-tools', 'audit-env'):
    assert (ROOT / name / 'pyvenv.cfg').is_file()
proofs = {}
for directory in (ROOT, ROOT / 'installed-wheel-r1'):
    for path in directory.iterdir():
        if path.is_file() and not path.is_symlink() and path.suffix in {'.json', '.log'}:
            proofs[str(path)] = sha(path)
rows = [row for root in roots for row in inventory(root)]
manifest = {'entries': rows, 'retained_sha256': retained, 'proof_sha256': proofs,
    'regeneration_basis': 'Locked requirements, source, audit/package commands, installed-tested wheel and corrected runtime retained. No bit-identical rebuild claim.'}
serialized = json.dumps(manifest, sort_keys=True).encode()
assert len(serialized) <= 16 << 20
INVENTORY.write_bytes(serialized + b'\n')
assert read(INVENTORY) == manifest
result = {'schema_version': 'shardloom.generated_artifact_retirement.v1', 'status': 'running',
    'roots': [str(path) for path in roots], 'manifest': str(INVENTORY), 'manifest_sha256': sha(INVENTORY),
    'retained_sha256': retained, 'closed_handle_checks': [], 'removed_entries': 0,
    'symlink_targets_followed': False, 'payload_backups_created': False,
    'source_inputs_touched': False, 'unfinished_item18_touched': False,
    'active_cargo_cache_touched': False, 'original_baseline_runtime_touched': False}
try:
    for root in roots:
        check = subprocess.run(['/usr/sbin/lsof', '-nP', '-Fpn', '+D', str(root)],
            capture_output=True, timeout=45)
        result['closed_handle_checks'].append({'path': str(root), 'returncode': check.returncode,
            'stdout': check.stdout.decode(), 'stderr': check.stderr.decode()})
        assert check.returncode == 1 and not check.stdout and not check.stderr, root
    assert all(sha(Path(path)) == digest for path, digest in proofs.items())
    assert [row for root in roots for row in inventory(root)] == rows
    for row in sorted(rows, key=lambda item: len(Path(item['path']).parts), reverse=True):
        path = Path(row['path'])
        if row['kind'] == 'directory':
            value = path.lstat()
            assert [value.st_dev, value.st_ino, value.st_mode] == row['generation'][:3]
            path.rmdir()
        else:
            assert identity(path) == row
            path.unlink()
        result['removed_entries'] += 1
    assert all(not root.exists() and not root.is_symlink() for root in roots)
    assert all(sha(Path(path)) == digest for path, digest in {**retained, **proofs}.items())
    result.update(status='passed', regular_files=sum(row['kind'] == 'regular' for row in rows),
        symlinks=sum(row['kind'] == 'symlink' for row in rows),
        retired_regular_bytes=sum(row['generation'][3] for row in rows if row['kind'] == 'regular'),
        retired_allocated_file_bytes=sum(row.get('allocated_bytes', 0) for row in rows),
        all_proof_files_unchanged=True)
except BaseException as error:
    result.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    OUTPUT.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('status', 'regular_files', 'symlinks', 'retired_regular_bytes')}))
