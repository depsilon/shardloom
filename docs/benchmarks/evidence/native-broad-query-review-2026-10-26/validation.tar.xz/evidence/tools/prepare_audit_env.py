"""Create the same hash-pinned dependency auditing environment used by CI."""
from pathlib import Path
import subprocess
import sys

root = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
destination = Path('/Users/dylan/LocalData/shardloom/compression-security-2026-10-26/audit-env')
assert not destination.exists()
subprocess.run([sys.executable, '-m', 'venv', str(destination)], check=True)
subprocess.run([
    str(destination / 'bin/python'), '-m', 'pip', 'install', '--require-hashes',
    '--only-binary=:all:', '-r', str(root / '.github/requirements/ci-dependency-security.txt'),
], check=True)
subprocess.run([str(destination / 'bin/python'), '-m', 'pip_audit', '--version'], check=True)
