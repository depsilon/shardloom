"""Retain missing-clock replay validation without rewriting earlier packets."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
E = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / 'docs/benchmarks/evidence/native-broad-query-review-2026-10-26'
BASE = 'af2e40093c6b4ca52873f97953f04be24e263d90'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
sha = lambda raw: hashlib.sha256(raw).hexdigest()
files, receipts = {}, []
for name in ('r41-review3-before', 'r42-review3-after', 'r43-review3-portable'):
    record = json.loads((E / (name + '.json')).read_bytes())
    assert record['status'] == ('failed' if name.endswith('before') else 'passed')
    assert record['process_group_drained'] and record['log_sha256'] == sha((E / (name + '.log')).read_bytes())
    receipts.append({'name': name, 'status': record['status'], 'command': record['command'], 'returncode': record['returncode']})
    for suffix in ('.json', '.log'):
        files['validation/' + name + suffix] = (E / (name + suffix)).read_bytes()
for path in ('portable-controls-r4.json', 'tools/run_guarded.py',
             'tools/verify_portable_packet_review3.py', 'tools/build_replay_timing_followup.py'):
    files['validation/' + path] = (E / path).read_bytes()
sources = ('benchmarks/traditional_analytics/query_surface/replay.py',
           'benchmarks/traditional_analytics/query_surface/adapters.py',
           'python/tests/test_query_surface_replay.py',
           'docs/architecture/compression-dependency-intake-2026-10-26.md')
for path in sources:
    files['source/' + path] = (ROOT / path).read_bytes()
files['original/replay.py'] = subprocess.check_output(['git', 'show', BASE + ':' + sources[0]], cwd=ROOT)
files['correction.patch'] = subprocess.check_output(['git', 'diff', '--', *sources], cwd=ROOT)
portable = json.loads(files['validation/portable-controls-r4.json'])
assert portable['semantic_controls_count'] == 18 and portable['queries_executed'] == 0
assert portable['relocated_replay']['checked_complete_results'] == 2331
assert portable['relocated_replay']['checked_receipts'] == 2334
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w:xz', preset=6) as archive:
    for name, raw in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(raw), 0o644, 0
        archive.addfile(info, io.BytesIO(raw))
packed = buffer.getvalue()
assert len(packed) < 1 << 20
with tarfile.open(fileobj=io.BytesIO(packed), mode='r:xz') as archive:
    assert len(archive.getmembers()) == len(files)
    for member in archive:
        assert member.isfile() and archive.extractfile(member).read() == files[member.name]
for path, expected in (
    (ROOT / 'docs/benchmarks/evidence/native-broad-query-2026-10-26/packet.tar.xz',
     '0549271bd5fdf0b290fe752ae59db53d6f92db003bdf6caae505513b1699d231'),
    (OUTPUT / 'validation.tar.xz', '61cbe38e212a695c6cf7c7383392e23f061556bbe29abe12200bcb354e683327'),
):
    assert sha(path.read_bytes()) == expected
earlier = json.loads((OUTPUT / 'replay-followup.json').read_bytes())
assert sha((OUTPUT / earlier['archive']['path']).read_bytes()) == earlier['archive']['sha256']
report = {
    'schema_version': 'shardloom.replay_timing_followup.v1', 'status': 'passed', 'base_revision': BASE,
    'review_comment': 'https://github.com/depsilon/shardloom/pull/1611#discussion_r4381872245',
    'archive': {'path': 'replay-timing-followup.tar.xz', 'bytes': len(packed), 'sha256': sha(packed)},
    'files': [{'path': name, 'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(files.items())],
    'archived_files_reopened_and_verified': len(files), 'receipts': receipts,
    'replay_tests': {'passed': 19, 'skipped': 0}, 'rejected_semantic_controls': 18,
    'unavailable_nonbaseline_engine_clock': portable['unavailable_nonbaseline_engine_clock'],
    'relocated_replay': portable['relocated_replay'], 'queries_executed': 0,
    'original_data_and_engine_access_denied': True, 'native_builds_rerun': False,
    'validation_scope': 'Offline Python replay correction; earlier native build/package evidence and all original benchmark observations remain unchanged. Hosted CI is the merge gate.',
}
with (OUTPUT / 'replay-timing-followup.tar.xz').open('xb') as target:
    target.write(packed)
with (OUTPUT / 'replay-timing-followup.json').open('x') as target:
    json.dump(report, target, indent=2, sort_keys=True)
    target.write('\n')
print(json.dumps({'status': 'passed', 'archived_files_verified': len(files), 'archive_bytes': len(packed)}))
