"""Bound task-owned build and test processes outside synced storage."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent.parent
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
sys.path[:0] = [str(ROOT / 'scripts'), '/Users/dylan/LocalData/shardloom/release-0.3.3-20260930']
from release_validation_guard import WorkloadGuard
from local_uat_storage import GIB, MIB, available_bytes, check_budgets, require_local_path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--name', required=True)
parser.add_argument('--timeout', type=float, default=2400)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
assert args.name.replace('-', '').isalnum() and args.timeout > 0
command = args.command[1:] if args.command[:1] == ['--'] else args.command
assert command
for path in (OUT, CACHE):
    require_local_path(path, Path.home(), sys.platform)
helper = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
assert hashlib.sha256(helper.read_bytes()).hexdigest() == '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97'
spec = importlib.util.spec_from_file_location('supervisor', helper)
supervisor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(supervisor)
env = dict(os.environ,
    PATH='/Users/dylan/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/Users/dylan/.cargo/bin:/opt/homebrew/opt/python@3.13/libexec/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
    CARGO_TARGET_DIR=str(CACHE), CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0',
    PYTHONPATH='python/src:scripts', PYTHONDONTWRITEBYTECODE='1', CARGO_TERM_COLOR='never')
metadata = json.loads(subprocess.check_output(['cargo', 'metadata', '--offline', '--locked',
    '--no-deps', '--format-version', '1'], cwd=ROOT, env=env))
assert metadata['target_directory'] == str(CACHE)
workload = WorkloadGuard()
workload.check()
changed = set()
for argv in (['git', 'diff', '--name-only', '-z', 'HEAD'],
             ['git', 'ls-files', '--others', '--exclude-standard', '-z']):
    changed.update(path for path in subprocess.check_output(argv, cwd=ROOT).decode().split('\0') if path)
source_inventory = {}
for relative in sorted(changed):
    path = ROOT / relative
    if path.is_symlink():
        source_inventory[relative] = {'symlink': os.readlink(path)}
    elif path.is_file():
        source_inventory[relative] = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                                      'bytes': path.stat().st_size}
    else:
        source_inventory[relative] = {'absent': True}
record = {'status': 'running', 'command': command, 'cwd': str(ROOT),
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'working_tree': subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True),
    'changed_source_inventory': source_inventory,
    'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'environment': {key: env.get(key) for key in ('CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL', 'CLIPPY_CONF_DIR', 'SHARDLOOM_PIP_AUDIT_PYTHON')},
    'supervisor_sha256': hashlib.sha256(helper.read_bytes()).hexdigest()}
receipt = OUT / f'{args.name}.json'
assert not receipt.exists()
log = OUT / f'{args.name}.log'
last_storage = 0.0

def guard():
    global last_storage
    workload.check(record.get('pid'))
    assert available_bytes(CACHE) >= 12 * GIB, 'minimum free storage reached'
    if time.monotonic() - last_storage < 30:
        return
    observations = {}
    for label, path in (('output', OUT), ('cargo', CACHE)):
        observations[label] = check_budgets(path, path / 'reserved-artifact', path / 'logs',
            min_free_bytes=12 * GIB, reserve_bytes=128 * MIB,
            max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    record['storage_last_observation'] = observations
    last_storage = time.monotonic()

try:
    guard()
    with log.open('xb') as stream:
        code = supervisor.run(command, cwd=ROOT, env=env, output=stream,
            timeout=args.timeout, evidence=record, guard=guard, max_output_bytes=8 << 20)
    record['status'] = 'passed' if code == 0 else 'failed'
except BaseException as error:
    record.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    if log.exists():
        record['log_sha256'] = hashlib.sha256(log.read_bytes()).hexdigest()
    receipt.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({key: record.get(key) for key in ('status', 'returncode', 'seconds', 'process_group_drained', 'error')}), flush=True)
    print(str(receipt), flush=True)
raise SystemExit(code)

