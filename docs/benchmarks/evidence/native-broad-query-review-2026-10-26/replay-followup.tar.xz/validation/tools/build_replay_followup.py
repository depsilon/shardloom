"""Retain the second replay correction without rewriting previous evidence."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
EVIDENCE = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / 'docs/benchmarks/evidence/native-broad-query-review-2026-10-26'
BASE = '2b29a7e0055eb3f27d0562829d044f6c09b0a481'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE


def digest(value):
    return hashlib.sha256(value).hexdigest()


files = {}
names = ['r36-review2-before', 'r37-review2-after', 'r38-review2-final',
         'r39-review2-portable', 'r40-review2-query-surface']
receipts = []
for name in names:
    receipt = json.loads((EVIDENCE / (name + '.json')).read_bytes())
    log = (EVIDENCE / (name + '.log')).read_bytes()
    assert receipt['log_sha256'] == digest(log) and receipt['process_group_drained']
    assert receipt['status'] == ('failed' if 'before' in name else 'passed')
    receipts.append({'name': name, 'status': receipt['status'], 'returncode': receipt['returncode']})
    for suffix in ('.json', '.log'):
        files['validation/' + name + suffix] = (EVIDENCE / (name + suffix)).read_bytes()
for path in ('portable-controls-r3.json', 'tools/run_guarded.py',
             'tools/verify_portable_packet_review2.py', 'tools/build_replay_followup.py'):
    files['validation/' + path] = (EVIDENCE / path).read_bytes()
sources = ('benchmarks/traditional_analytics/query_surface/replay.py',
           'benchmarks/traditional_analytics/query_surface/run.py',
           'benchmarks/traditional_analytics/query_surface/polars_run.py',
           'python/tests/test_query_surface_replay.py',
           'docs/architecture/compression-dependency-intake-2026-10-26.md')
for path in sources:
    files['source/' + path] = (ROOT / path).read_bytes()
files['original/replay.py'] = subprocess.check_output(
    ['git', 'show', BASE + ':benchmarks/traditional_analytics/query_surface/replay.py'], cwd=ROOT)
files['correction.patch'] = subprocess.check_output(['git', 'diff', '--', *sources], cwd=ROOT)
portable = json.loads(files['validation/portable-controls-r3.json'])
assert portable['semantic_controls_count'] == 17 and portable['queries_executed'] == 0
assert portable['relocated_replay']['checked_complete_results'] == 2331
assert portable['relocated_replay']['checked_receipts'] == 2334
inventory = [{'path': name, 'bytes': len(value), 'sha256': digest(value)} for name, value in sorted(files.items())]
stream = io.BytesIO()
with tarfile.open(fileobj=stream, mode='w:xz', preset=6) as archive:
    for name, value in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(value), 0o644, 0
        archive.addfile(info, io.BytesIO(value))
packed = stream.getvalue()
assert len(packed) < (1 << 20)
with tarfile.open(fileobj=io.BytesIO(packed), mode='r:xz') as archive:
    assert len(archive.getmembers()) == len(files)
    for member in archive:
        assert member.isfile() and archive.extractfile(member).read() == files[member.name]
baseline = ROOT / 'docs/benchmarks/evidence/native-broad-query-2026-10-26'
unchanged = {
    'baseline_manifest': (baseline / 'manifest.json', '800ac1b971cbbab183fbd946dce721daccd26fc20c52d8d408e2c3a6c742f025'),
    'baseline_archive': (baseline / 'packet.tar.xz', '0549271bd5fdf0b290fe752ae59db53d6f92db003bdf6caae505513b1699d231'),
    'prior_review_archive': (OUTPUT / 'validation.tar.xz', '61cbe38e212a695c6cf7c7383392e23f061556bbe29abe12200bcb354e683327'),
}
for path, expected in unchanged.values():
    assert digest(path.read_bytes()) == expected
report = {
    'schema_version': 'shardloom.replay_review_followup.v1', 'status': 'passed',
    'base_revision': BASE,
    'review_comment': 'https://github.com/depsilon/shardloom/pull/1611#discussion_r4381696976',
    'archive': {'path': 'replay-followup.tar.xz', 'bytes': len(packed), 'sha256': digest(packed)},
    'files': inventory, 'archived_files_reopened_and_verified': len(files), 'receipts': receipts,
    'replay_tests': {'passed': 16, 'skipped': 0},
    'query_surface_tests': {'passed': 54, 'skipped': 2,
                            'skip_reason': 'Optional native library and Polars engine are not installed in this test environment.'},
    'rejected_semantic_controls': 17,
    'retained_incomplete_polars_cohort': portable['retained_incomplete_polars_cohort'],
    'relocated_replay': portable['relocated_replay'],
    'original_data_and_engine_access_denied': True,
    'unchanged_evidence': {key: expected for key, (_, expected) in unchanged.items()},
    'native_builds_rerun': False, 'queries_executed': 0,
    'validation_scope': 'Python-only replay correction; preceding Rust, provider and installed-wheel evidence remains at its recorded revision. Hosted CI is required before merge.',
}
with (OUTPUT / 'replay-followup.tar.xz').open('xb') as target:
    target.write(packed)
with (OUTPUT / 'replay-followup.json').open('x') as target:
    json.dump(report, target, indent=2, sort_keys=True)
    target.write('\n')
print(json.dumps({'status': 'passed', 'archived_files_verified': len(files), 'archive_bytes': len(packed)}))
