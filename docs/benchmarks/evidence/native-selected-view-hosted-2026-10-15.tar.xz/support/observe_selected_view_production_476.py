"""Observe served bytes while the deployment check remains independently pending."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import urllib.request

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent / 'selected-view-hosted-469' / 'production-observed-476'
MERGE = 'fb1812dec4f9fa724b2c587353c74162935e0b2c'
ORIGIN = 'https://shardloom.io'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    check_raw = subprocess.check_output([
        '/opt/homebrew/bin/gh', 'api',
        'repos/depsilon/shardloom/check-runs/116463923886',
    ])
    check = json.loads(check_raw)
    assert check['head_sha'] == MERGE
    matched_version = re.search(r'Version ID: ([a-f0-9-]{36})', check['output']['summary'])
    version = matched_version.group(1) if matched_version else None
    OUT.mkdir(exist_ok=False)
    (OUT / 'deployment-check.json').write_bytes(check_raw)
    routes = [
        'field-guide/benchmark-methodology/index.html',
        'field-guide/runtime-and-io/index.html',
        'field-guide/limitations/index.html',
        'benchmarks/index.html', 'benchmarks.html',
        'assets/parallax-home.js', 'pagefind/pagefind-entry.json',
    ]
    records = []
    for route in routes:
        source = 'website/' + route
        expected = subprocess.check_output(['git', 'show', MERGE + ':' + source], cwd=ROOT)
        url = ORIGIN + '/' + route.removesuffix('index.html')
        request = urllib.request.Request(url, headers={'User-Agent': 'ShardLoom-owned-site-verification'})
        with urllib.request.urlopen(request, timeout=30) as response:
            actual = response.read((2 << 20) + 1)
            assert response.status == 200 and len(actual) <= 2 << 20
            final_url = response.url
        filename = route.replace('/', '_')
        (OUT / filename).write_bytes(actual)
        prefix = 0
        while prefix < min(len(actual), len(expected)) and actual[prefix] == expected[prefix]:
            prefix += 1
        extra = len(actual) - len(expected)
        insertion = b''
        preserved = actual == expected
        if not preserved and 0 < extra <= 16384 and route.endswith('.html'):
            insertion = actual[prefix:prefix + extra]
            preserved = actual[prefix + extra:] == expected[prefix:]
            preserved &= b'/cdn-cgi/challenge-platform/' in insertion or b'static.cloudflareinsights.com/' in insertion
        records.append(dict(source=source, response=filename, url=url,
            final_url=final_url, http_status=200, expected_bytes=len(expected),
            expected_sha256=sha(expected), observed_bytes=len(actual),
            observed_sha256=sha(actual), raw_byte_identical=actual == expected,
            source_preserved=bool(preserved), insertion_bytes=len(insertion),
            insertion_sha256=sha(insertion) if insertion else None))
    report = dict(schema_version='shardloom.selected_text_views_production_observation.v1',
        status='source_matches' if all(row['source_preserved'] for row in records) else 'source_differs',
        observed_at=datetime.now(timezone.utc).isoformat(), head=MERGE,
        origin=ORIGIN, deployment_version=version, responses=records,
        deployment_check_sha256=sha(check_raw), deployment_check_status=check['status'],
        deployment_check_conclusion=check['conclusion'],
        deployment_completion_proven=check['status'] == 'completed' and check['conclusion'] == 'success',
        scope='Read-only observation of response bytes against immutable merge; the deployment check is a separate fact. No completed-deployment or browser-rendering claim follows from matching bytes.')
    with (OUT / 'report.json').open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': report['status'], 'responses': len(records),
        'source_preserved': sum(r['source_preserved'] for r in records)}))


if __name__ == '__main__':
    main()
