"""Bind the deployed selected-view preview to its exact reviewed source."""
import importlib.util
from pathlib import Path

root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    'selected_view_preview_verifier', root / 'capture_compression_preview_464.py'
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.OUT = root / 'selected-view-hosted-469' / 'preview'
module.HEAD = 'ba7643df4576c1869dae33ed0c2ef4f9a2e335bb'
module.ORIGIN = 'https://6b30fe20-shardloom.djheinrich.workers.dev'
module.VERSION = '6b30fe20-f903-43d5-81c9-8db735494b55'
module.main()
