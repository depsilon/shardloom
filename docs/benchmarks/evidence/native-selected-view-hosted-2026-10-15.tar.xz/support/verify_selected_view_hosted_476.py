"""Verify PR1556 integration and served source while preserving a pending deployment notification."""
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
RAW = OUT / 'selected-view-hosted-469'
HEAD = 'ba7643df4576c1869dae33ed0c2ef4f9a2e335bb'
MERGE = 'fb1812dec4f9fa724b2c587353c74162935e0b2c'
SYNTHETIC = 'b800fc0910521e44d1b8f7ce01884f2c104911aa'
sys.path.insert(0, str(ROOT / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def read(path):
    return json.loads(path.read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def save(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')


def plain(text):
    return '\n'.join(re.sub(r'^\d{4}-\d{2}-\d{2}T\S+Z ', '', line)
                     for line in text.lstrip('\ufeff').splitlines())


def main():
    checks = read(RAW / 'checks-final.json')['structuredContent']
    assert checks['headRevision'] == HEAD and not checks['hasMore']
    assert len(checks['checks']) == len({c['id'] for c in checks['checks']}) == 44
    assert all(c['head_sha'] == HEAD and c['status'] == 'completed' and c['conclusion'] == 'success'
               for c in checks['checks'])
    merged = read(RAW / 'merge.json')['structuredContent']
    assert merged['merged'] is True and merged['sha'] == MERGE
    trees = {revision: subprocess.check_output(['git', 'rev-parse', revision + '^{tree}'],
                                              cwd=ROOT, text=True).strip()
             for revision in (HEAD, MERGE, SYNTHETIC)}
    assert len(set(trees.values())) == 1
    inventory = read(OUT / 'selected-view-hosted-inventory-476b.json')
    inputs = {}
    for row in inventory['source_file_inventory']:
        path = Path(row['path'])
        assert identity(path) == row
        inputs[str(path)] = path.read_text()
    excerpts = 0
    def verify_excerpts(value):
        nonlocal excerpts
        if isinstance(value, dict):
            for key, literal in value.items():
                if key.endswith('excerpt') and isinstance(literal, (str, list)):
                    source = value.get(key.removesuffix('_excerpt') + '_source_path')
                    source = source or value.get('source_path')
                    assert source in inputs, (key, source)
                    for text in literal if isinstance(literal, list) else [literal]:
                        assert isinstance(text, str) and text in inputs[source]
                        excerpts += 1
            for child in value.values():
                verify_excerpts(child)
        elif isinstance(value, list):
            for child in value:
                verify_excerpts(child)
    verify_excerpts(inventory)
    assert excerpts == 67
    log = plain((RAW / 'native-vortex-472-full.log').read_text())
    assert SYNTHETIC + ':refs/remotes/pull/1556/merge' in log
    groups = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log, re.M)
    assert groups == [('2807', '0', '26'), ('10', '0', '0'), ('7', '0', '0'),
                      ('7', '0', '0'), ('23', '0', '0'), ('4', '0', '0')], groups
    assert not re.search(r'^test .* \.\.\. FAILED$', log, re.M)
    ignored = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', log, re.M)
    manual = read(OUT / 'compression-manual-tests-inventory-456.json')['tests']
    assert sorted(ignored) == sorted((row['test'], row['reason']) for row in manual if row['source'].startswith('shardloom-vortex/'))
    assert 'test native_provider_memory::zstd_tests::filter_tests::native_zstd_sparse_text_filter_constructs_only_selected_views ... ok' in log
    wheels = []
    for lane in ('py310-ubuntu', 'py313-ubuntu', 'py313-macos'):
        path = RAW / f'wheel-{lane}-471-full.log'
        text = plain(path.read_text())
        assert SYNTHETIC + ':refs/remotes/pull/1556/merge' in text
        marker = '{\n  "schema_version": "shardloom.native_python_wheel_proof.v1"'
        assert text.count(marker) == 1
        proof, _ = json.JSONDecoder().raw_decode(text[text.index(marker):])
        assert proof == read(RAW / f'wheel-{lane}-proof-471.json')
        assert proof['status'] == proof['stage']['status'] == proof['integrity']['status'] == 'passed'
        assert proof['integration'] == dict(tests=80, failures=0, errors=0, skipped=0, status='passed')
        assert all(step['returncode'] == 0 for step in proof['steps'])
        assert proof['installed_load']['isolated_install'] and proof['installed_load']['version'] == '0.6.0'
        assert proof['publication_attempted'] is False and proof['performance_claim'] is False
        wheels.append(dict(lane=lane, raw=identity(path), proof=proof))
    reviews = read(RAW / 'reviews-final.json')['structuredContent']['reviews']
    assert reviews == []
    threads = read(RAW / 'review-threads-final.json')['structuredContent']['review_threads']
    assert threads == []
    comments = read(RAW / 'comments-final.json')
    clean = [c for c in comments if c['id'] == 6192432287]
    assert len(clean) == 1 and HEAD[:7] in clean[0]['body'] and '**Completed**' in clean[0]['body']
    before = read(OUT / 'selected-views-467-source.json')['source_sha256']
    assert len(before) == 2259
    changed = {}
    with subprocess.Popen(['git', 'cat-file', '--batch'], cwd=ROOT,
                          stdin=subprocess.PIPE, stdout=subprocess.PIPE) as child:
        for name, expected in sorted(before.items()):
            assert '\n' not in name
            child.stdin.write((MERGE + ':' + name + '\n').encode()); child.stdin.flush()
            header = child.stdout.readline().decode().split()
            assert len(header) == 3 and header[1] == 'blob', name
            payload = child.stdout.read(int(header[2]))
            assert child.stdout.read(1) == b'\n'
            digest = sha(payload)
            if digest != expected:
                changed[name] = dict(measured_sha256=expected, merged_sha256=digest)
        child.stdin.close()
        assert child.wait(timeout=30) == 0
    assert set(changed) == {'python/THIRD_PARTY_LICENSES/manifest.json'}
    correction = read(RAW / 'notice-correction-470.json')
    assert changed['python/THIRD_PARTY_LICENSES/manifest.json'] == dict(
        measured_sha256=correction['before_sha256'], merged_sha256=correction['after_sha256'])
    artifacts = read(OUT / 'selected-view-native-artifacts-468.json')
    for key in ('cli', 'binding'):
        actual = identity(Path(artifacts[key]['path']))
        assert actual['sha256'] == artifacts[key]['sha256'] and actual['bytes'] == artifacts[key]['bytes']
    served = {}
    for name, revision in [('preview', HEAD), ('production-observed-476', MERGE)]:
        folder = RAW / name
        report = read(folder / 'report.json')
        assert report['status'] == ('passed' if name == 'preview' else 'source_matches') and report['head'] == revision
        assert len(report['responses']) == 7
        for response in report['responses']:
            assert response['source_preserved'] and response['http_status'] == 200
            actual = (folder / response['response']).read_bytes()
            expected = subprocess.check_output(['git', 'show', revision + ':' + response['source']], cwd=ROOT)
            assert sha(actual) == response['observed_sha256']
            assert sha(expected) == response['expected_sha256']
            assert len(actual) == response['observed_bytes']
            assert len(expected) == response['expected_bytes']
            if actual != expected:
                prefix = next(i for i, (left, right) in enumerate(zip(actual, expected)) if left != right)
                extra = len(actual) - len(expected)
                assert 0 < extra <= 16384 and response['source'].endswith('.html')
                insertion = actual[prefix:prefix + extra]
                assert actual[prefix + extra:] == expected[prefix:]
                assert b'/cdn-cgi/challenge-platform/' in insertion or b'static.cloudflareinsights.com/' in insertion
                assert response['insertion_bytes'] == extra and response['insertion_sha256'] == sha(insertion)
        served[name] = report
    production = served['production-observed-476']
    deployment = read(RAW / 'production-observed-476/deployment-check.json')
    assert deployment['head_sha'] == MERGE and deployment['status'] == 'in_progress' and deployment['conclusion'] is None
    assert production['deployment_completion_proven'] is False and production['deployment_version'] is None
    assert sha((RAW / 'production-observed-476/deployment-check.json').read_bytes()) == production['deployment_check_sha256']
    report = dict(schema_version='shardloom.native_selected_view_hosted_verification.v1', status='passed',
        head=HEAD, merge=MERGE, synthetic=SYNTHETIC, trees=trees, checks_passed=44,
        native_test_groups=groups, wheel_lanes=wheels, inventory_excerpts_verified=excerpts,
        source_files_checked=len(before), changed_since_measured_source=changed,
        accepted_native_source_preserved=True, accepted_cli_and_binding_hashes_verified=True,
        source_version='0.6.0', publication_claimed=False, served=served,
        review='Final-head automated review completed; final review and thread snapshots contain no findings.',
        production_served_source_verified=True, production_deployment_check_complete=False,
        production_deployment_check_limitation='Cloudflare check remains in_progress without a version ID; all seven production responses preserve the merged source. No completed-check claim.',
        driver=identity(Path(__file__)))
    save(RAW / 'verification-476.json', report)
    files = {'hosted/' + str(p.relative_to(RAW)): p for p in RAW.rglob('*') if p.is_file()}
    for path in (Path(__file__), OUT / 'selected-view-hosted-inventory-476.json',
                 OUT / 'selected-view-hosted-inventory-476b.json',
                 OUT / 'selected-views-467-source.json', OUT / 'selected-view-native-artifacts-468.json',
                 OUT / 'compression-manual-tests-inventory-456.json',
                 OUT / 'capture_selected_view_preview_470.py', OUT / 'capture_selected_view_production_472.py',
                 OUT / 'observe_selected_view_production_476.py'):
        files['support/' + path.name] = path
    destination = require_local_path(OUT / 'selected-view-hosted-packet-476', Path.home(), sys.platform)
    check_budgets(OUT, destination, OUT / 'logs', min_free_bytes=12*GIB,
        reserve_bytes=128*MIB, max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
    destination.mkdir(exist_ok=False)
    archive = destination / 'native-selected-view-hosted-2026-10-15.tar.xz'
    index = destination / 'native-selected-view-hosted-2026-10-15.json'
    assert not archive.exists() and not index.exists()
    members = []
    with tarfile.open(archive, 'x:xz') as stream:
        for name, path in sorted(files.items()):
            payload = path.read_bytes()
            member = tarfile.TarInfo(name); member.size = len(payload); member.mode = 0o644
            stream.addfile(member, io.BytesIO(payload))
            members.append(dict(name=name, bytes=len(payload), sha256=sha(payload)))
    with tarfile.open(archive, 'r:xz') as stream:
        assert len(stream.getmembers()) == len(members)
        for member in members:
            payload = stream.extractfile(member['name']).read()
            assert len(payload) == member['bytes'] and sha(payload) == member['sha256']
            assert payload == files[member['name']].read_bytes()
    save(index, dict(schema_version='shardloom.native_selected_view_hosted_packet.v1', status='passed',
        pr=1556, head=HEAD, merge=MERGE, synthetic=SYNTHETIC, checks_passed=44,
        native_test_groups=groups, wheel_lanes=[w['lane'] for w in wheels], wheel_tests_per_lane=80,
        served_responses_verified=14, production_version=None, production_served_source_verified=True,
        production_deployment_check_complete=False, production_deployment_check_status='in_progress',
        production_deployment_check_limitation=report['production_deployment_check_limitation'],
        accepted_native_source_preserved=True, source_files_checked=len(before),
        changed_since_measured_source=changed, inventory_excerpts_verified=excerpts,
        archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=sha(archive.read_bytes())),
        members_verified=len(members), members=members, publication_claimed=False,
        browser_scope='Earlier rendered guide/search proof remains in its original packet; this packet verifies preview/production served-source preservation and does not claim a new rendering check.'))
    for path in (archive, index):
        target = ROOT / 'docs/benchmarks/evidence' / path.name
        assert not target.exists()
        shutil.copy2(path, target)
        assert target.read_bytes() == path.read_bytes()
    print(json.dumps(dict(status='passed', checks=44, wheel_lanes=3, excerpts=excerpts,
        sources=len(before), served_responses=14, members=len(members))))


if __name__ == '__main__':
    main()
