"""Apply the predeclared native text-size screen thresholds without selecting defaults."""
from pathlib import Path
from decimal import Decimal
import hashlib
import json
import statistics

D = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010/native-ingest-text-screen-629')
read = lambda p: json.loads(p.read_text())

def checked(reference):
    path = Path(reference['path'])
    assert path.stat().st_size == reference['bytes']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == reference['sha256']
    return path

acceptance = read(D / 'acceptance.json')
assert acceptance['status'] == 'passed_complete_screen'
report = read(checked(acceptance['screen']))
preflight = read(checked(acceptance['preflight']))
plan = preflight['sources']['docs/benchmarks/native-ingest-text-size-2026-10-18.md']
plan_text = checked(plan).read_text()
assert 'at least 30%' in plan_text and '1.25 times retained' in plan_text and '1.05 times retained' in plan_text
baseline_name = 'level_-3_frame_8192_dict_false'
assert baseline_name in report['profiles']
rows = {name: [] for name in report['profiles']}
for sample in report['samples']:
    for row in sample['cases']:
        rows[row['profile']].append(dict(row, row_group=sample['row_group'], batch_index=sample['batch_index']))
assert all(len(group) == 60 for group in rows.values())

def total(group, field):
    return sum(row[field] for row in group)

def aggregate(group):
    return dict(physical_column_bytes=total(group, 'physical_column_bytes'),
                complete_file_bytes=total(group, 'complete_file_bytes'),
                native_write_micros=total(group, 'native_write_micros'),
                native_read_median_sum_micros=sum(statistics.median(row['native_read_and_exact_compare_micros']) for row in group),
                positive_filter_median_sum_micros=sum(statistics.median(row['predicates'][0]['native_scan_count_micros']) for row in group),
                negative_filter_median_sum_micros=sum(statistics.median(row['predicates'][1]['native_scan_count_micros']) for row in group))

baseline = aggregate(rows[baseline_name])
decisions = []
for profile, group in rows.items():
    values = aggregate(group)
    ratios = {key: str(Decimal(value) / Decimal(baseline[key])) for key, value in values.items()}
    regions = []
    for region in report['row_groups']:
        before = total([row for row in rows[baseline_name] if row['row_group'] == region], 'physical_column_bytes')
        after = total([row for row in group if row['row_group'] == region], 'physical_column_bytes')
        regions.append(dict(row_group=region, baseline_bytes=before, candidate_bytes=after, no_growth=after <= before))
    gates = dict(exact_checks_passed=True,
                 physical_byte_reduction_at_least_30_percent=values['physical_column_bytes'] * 10 <= baseline['physical_column_bytes'] * 7,
                 no_region_grows=all(row['no_growth'] for row in regions),
                 aggregate_write_at_most_1_25=values['native_write_micros'] * 4 <= baseline['native_write_micros'] * 5,
                 repeated_read_at_most_1_05=values['native_read_median_sum_micros'] * 20 <= baseline['native_read_median_sum_micros'] * 21,
                 positive_filter_at_most_1_05=values['positive_filter_median_sum_micros'] * 20 <= baseline['positive_filter_median_sum_micros'] * 21,
                 negative_filter_at_most_1_05=values['negative_filter_median_sum_micros'] * 20 <= baseline['negative_filter_median_sum_micros'] * 21)
    decision = 'retained_control' if profile == baseline_name else ('advance_to_production_path_investigation' if all(gates.values()) else 'drop_failed_frozen_screen')
    decisions.append(dict(profile=profile, decision=decision, values=values, ratios_to_retained=ratios, regions=regions, gates=gates))
result = dict(schema_version='shardloom.native_zstd_size_decision.v1', status='passed_integrity',
              screen=acceptance['screen'], preflight=acceptance['preflight'], frozen_plan=plan,
              baseline=baseline_name, decisions=decisions,
              accepted_production_policy=False, full_ingest_proven=False, public_query_dispatch_proven=False,
              timing_contract='Sum one complete native write per sample; independently sum each sample median of three complete reads, positive counts and negative counts. Provider-screen observations are not engine Full43 timings.',
              extrapolation='Text samples do not establish complete-file size reduction; no field name is a runtime policy.')
target = D / 'decision.json'
with target.open('x') as output:
    json.dump(result, output, indent=2)
    output.write('\n')
print(json.dumps({key: result[key] for key in ('status', 'baseline', 'decisions')}))
