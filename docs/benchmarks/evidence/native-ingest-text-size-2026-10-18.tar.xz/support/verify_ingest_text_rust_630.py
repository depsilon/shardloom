"""Run repository Rust gates and the optional native benchmark compilation gate."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

R = Path('/Users/dylan/.codex/worktrees/native-ingest-text-size/shardloom-local-repo')
O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
files = ['shardloom-vortex/src/vortex_ingest_source_dictionary_bench.rs',
         'shardloom-vortex/src/vortex_ingest_zstd_size_bench.rs', 'Cargo.lock',
         'Cargo.toml', 'shardloom-vortex/Cargo.toml']
hashes = lambda: {p: hashlib.sha256((R/p).read_bytes()).hexdigest() for p in files}
before = hashes()
commands = [
    ['cargo', 'fmt', '--all', '--', '--check'],
    ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings'],
    ['cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets'],
    ['cargo', 'clippy', '--offline', '--locked', '-p', 'shardloom-vortex', '--all-targets',
     '--features', 'vortex-write,universal-format-io,vortex-local-primitives', '--', '-D', 'warnings'],
]
results = []
for command in commands:
    code = subprocess.run(command, cwd=R).returncode
    assert hashes() == before, 'Rust source changed during validation'
    results.append(dict(command=command, returncode=code))
    print(json.dumps(results[-1]), flush=True)
    if code:
        break
report = dict(status='passed' if len(results)==len(commands) and all(x['returncode']==0 for x in results) else 'failed',
              checks=results, source_sha256=before, source_unchanged=True,
              measured_native_unit_tests='native-ingest-text-screen-unit-628.json',
              formatting_bridge='native-ingest-text-screen-format-bridge-630.json')
(O/'native-ingest-text-rust-results-630.json').open('x').write(json.dumps(report, indent=2)+'\n')
raise SystemExit(0 if report['status']=='passed' else 1)
