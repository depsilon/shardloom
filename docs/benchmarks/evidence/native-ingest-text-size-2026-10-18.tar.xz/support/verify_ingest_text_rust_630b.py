"""Recheck the native lint fixes and retain the unchanged passed workspace gates."""
from pathlib import Path
import hashlib
import json
import subprocess

R=Path('/Users/dylan/.codex/worktrees/native-ingest-text-size/shardloom-local-repo')
O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
previous=O/'native-ingest-text-rust-results-630.json'
prior=json.loads(previous.read_text())
assert prior['status']=='failed' and [x['returncode'] for x in prior['checks']]==[0,0,0,101]
files=list(prior['source_sha256'])
hashes=lambda:{p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in files}
before=hashes()
changed=[p for p in files if before[p]!=prior['source_sha256'][p]]
assert changed==['shardloom-vortex/src/vortex_ingest_zstd_size_bench.rs']
bridge=json.loads((O/'native-ingest-text-screen-lint-bridge-630b.json').read_text())
assert bridge['status']=='passed' and before[changed[0]]==bridge['final_sha256']
commands=[prior['checks'][0]['command'],prior['checks'][3]['command']]
results=[]
for command in commands:
    code=subprocess.run(command,cwd=R).returncode
    results.append(dict(command=command,returncode=code))
    assert hashes()==before
    if code:break
passed=len(results)==2 and all(x['returncode']==0 for x in results)
report=dict(status='passed' if passed else 'failed',checks=prior['checks'][:3]+results[-1:],
    rerun_checks=results,source_sha256=before,source_unchanged=True,
    previous_attempt=dict(path=str(previous),sha256=hashlib.sha256(previous.read_bytes()).hexdigest()),
    native_units='native-ingest-text-screen-units-628.json',measured_case_bridge='native-ingest-text-screen-lint-bridge-630b.json',
    carried_check_scope='Workspace formatting, default clippy and default tests passed. The only code repair is inside the optional test-only native screen; default-feature code is unchanged. Formatting and optional native lint are rechecked.')
(O/'native-ingest-text-rust-results-630b.json').open('x').write(json.dumps(report,indent=2)+'\n')
raise SystemExit(0 if passed else 1)
