"""Verify the three lint repairs stay outside the measured codec/consumer work."""
from pathlib import Path
import hashlib
import json
import subprocess

R=Path('/Users/dylan/.codex/worktrees/native-ingest-text-size/shardloom-local-repo')
O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
D=O/'native-ingest-text-screen-629'
relative='shardloom-vortex/src/vortex_ingest_zstd_size_bench.rs'
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text())
command=['/Users/dylan/.cargo/bin/rustup','run','1.99.0','rustfmt','--edition','2024','--emit','stdout']
def formatted(raw):
    result=subprocess.run(command,input=raw,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True,cwd=R)
    assert not result.stderr
    return result.stdout
measured=(D/'measured-source'/relative).read_bytes()
before=formatted(measured)
bridge=read(O/'native-ingest-text-screen-format-bridge-630.json')
assert bridge['status']=='passed' and sha(before)==bridge['formatted_sha256']
replacements=[
    ('parts.dictionary.as_ref().map_or(0, |dict| dict.len())','parts.dictionary.as_ref().map_or(0, vortex::buffer::Buffer::len)'),
    ('rows as usize <= profile.values_per_frame','rows <= u64::try_from(profile.values_per_frame).unwrap()'),
    ('parts.frames.iter().map(|frame| frame.len())','parts.frames.iter().map(vortex::buffer::Buffer::len)'),
]
text=before.decode()
start=text.index('    let sizes = file.footer().compressed_field_sizes()')
end=text.index('    let read_micros: Vec<_>')
for old,new in replacements:
    assert text.count(old)==1 and old in text[start:end]
    text=text.replace(old,new)
expected=formatted(text.encode());actual=(R/relative).read_bytes()
assert expected==actual
screen=read(D/'screen.json')
frames=[n for sample in screen['samples'] for row in sample['cases'] for witness in row['persisted_zstd_witnesses'] for n in witness['frame_value_counts']]
assert frames and min(frames)>0 and max(frames)<=8192
result=dict(status='passed',source=relative,measured_sha256=sha(measured),formatted_sha256=sha(before),final_sha256=sha(actual),
    exact_three_replacements_and_formatter_only=True,replacements=replacements,
    all_changes_in_untimed_structural_witness=True,measured_frames=len(frames),largest_measured_frame_rows=max(frames),
    measured_case_results_equivalent=True,codec_and_consumer_timing_bodies_unchanged=True,production_writer_changed=False,
    boundary='Two method-reference substitutions and a non-narrowing metadata bounds check; no compression policy, values, frames, training or timed operations changed.')
path=O/'native-ingest-text-screen-lint-bridge-630b.json'
path.open('x').write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
