"""Inspect the accepted native artifact without changing data or writer policy."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

R = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
U = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
D = O / 'native-ingest-inventory-627'
HEAD = '77d5b5da9561b04b4c5cb81e94cce07529528cd8'
sys.path[:0] = [str(R / 'scripts')]
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
from run_clickbench_paired_query_uat import generation

def read(path):
    return json.loads(path.read_text())

def identity(path):
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=R)

assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert not git('status', '--porcelain').strip()
build_path = O / 'native-ingest-inventory-build-627.json'
build = read(build_path)
assert build['status'] == 'passed' and build['process_group_drained']
assert build['head'] == HEAD and not build['working_tree']
cache = Path(build['environment']['CARGO_TARGET_DIR'])
original = cache / 'release/examples/physical_encoding_inventory'
require_local_path(original, Path.home(), sys.platform)
plan_path = O / 'native-shared-execution-full43-plan-619.json'
plan = read(plan_path)
source = require_local_path(Path(plan['input']), Path.home(), sys.platform)
assert source.stat().st_size == 15_713_610_513
assert source.stat().st_flags == 0
assert source.stat().st_blocks * 512 >= source.stat().st_size
source_generation = generation(source)
require_local_path(D, Path.home(), sys.platform)
assert not D.exists()
check_budgets(O, D, O / 'logs', min_free_bytes=12 * GIB,
              reserve_bytes=128 * MIB, max_workspace_bytes=100 * GIB,
              max_log_bytes=192 * MIB)
D.mkdir()
binary = D / original.name
shutil.copy2(original, binary)
assert identity(original)['sha256'] == identity(binary)['sha256']
relative_sources = [
    'Cargo.lock', 'Cargo.toml', 'shardloom-vortex/Cargo.toml',
    'shardloom-vortex/examples/physical_encoding_inventory.rs',
    'shardloom-vortex/src/physical_encoding_inventory.rs',
    'scripts/run_local_readonly_proof.py', 'scripts/run_clickbench_paired_query_uat.py',
    'scripts/run_clickbench_query_uat.py', 'scripts/local_uat_storage.py',
    'scripts/timed_native_command.py',
]
source_identities = {}
for relative in relative_sources:
    path = R / relative
    assert git('show', HEAD + ':' + relative) == path.read_bytes()
    source_identities[relative] = identity(path)
command = [sys.executable, '-B', str(R / 'scripts/run_local_readonly_proof.py'),
           '--uat-root', str(U), '--source', str(source),
           '--name', 'native-ingest-layout-627', '--timeout-seconds', '600',
           '--max-log-mib', '192', '--max-run-log-mib', '8']
for relative in relative_sources:
    command += ['--input', str(R / relative)]
command += ['--', str(binary), str(source), '--max-flat-references', '500000',
            '--summary-only']
preflight = dict(status='frozen_before_inspection', head=HEAD,
                 binary=identity(binary), build=identity(build_path),
                 retained_input_plan=identity(plan_path), input=str(source),
                 expected_input_sha256=plan['input_sha256'],
                 input_generation=source_generation, sources=source_identities,
                 command=command, script=identity(Path(__file__)),
                 scope='read_only_encoded_array_inspection;no_query_or_ingest_timing')
(D / 'preflight.json').write_text(json.dumps(preflight, indent=2) + '\n')
with (D / 'runner.stdout.json').open('xb') as stdout:
    completed = subprocess.run(command, cwd=R, stdout=stdout, check=False)
assert completed.returncode == 0, completed.returncode
logs = U / 'logs/readonly-proof-native-ingest-layout-627'
receipt = read(logs / 'receipt.json')
assert receipt['status'] == 'passed' and receipt['unchanged']
assert receipt['result']['returncode'] == 0 and not receipt['result']['guard_failures']
inventory_path = logs / 'proof.stdout.json'
inventory = read(inventory_path)
assert inventory['artifact']['sha256'] == 'sha256:' + plan['input_sha256']
assert inventory['artifact']['bytes'] == source.stat().st_size
assert inventory['complete_flat_inspection'] and inventory['summary_only']
assert inventory['fallback_attempted'] is False and inventory['external_engine_invoked'] is False
assert generation(source) == source_generation
assert identity(binary) == preflight['binary']
for relative, expected in source_identities.items():
    assert identity(R / relative) == expected
columns = sorted(inventory['columns'],
                 key=lambda row: row['referenced_segment_bytes_non_additive'], reverse=True)
report = dict(status='passed', head=HEAD, preflight=identity(D / 'preflight.json'),
              receipt=identity(logs / 'receipt.json'), inventory=identity(inventory_path),
              artifact=inventory['artifact'], columns=columns,
              byte_scope=inventory['byte_scope'], scope=inventory['scope'],
              unique_flat_segment_bytes=inventory['unique_flat_segment_bytes'],
              remaining_file_bytes=source.stat().st_size - inventory['unique_flat_segment_bytes'],
              all_referenced_segments_are_flat=inventory['all_referenced_segments_are_flat'],
              layout_nodes=inventory['layout_nodes'], array_nodes=inventory['array_nodes'],
              flat_reference_count=inventory['flat_reference_count'],
              no_writer_change=True, performance_claim=False)
(D / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(status='passed', report=str(D / 'report.json'),
                      file_bytes=report['artifact']['bytes'],
                      remaining_file_bytes=report['remaining_file_bytes'],
                      top_columns=columns[:12])))
