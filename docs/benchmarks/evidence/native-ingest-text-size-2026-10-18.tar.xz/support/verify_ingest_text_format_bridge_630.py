"""Bind the measured native-text screen to its formatting-only source update."""
from pathlib import Path
import hashlib
import json
import subprocess

R = Path('/Users/dylan/.codex/worktrees/native-ingest-text-size/shardloom-local-repo')
O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
D = O / 'native-ingest-text-screen-629'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda path: json.loads(path.read_text())
preflight = read(D / 'preflight.json')
measured_path = O / 'native-ingest-text-screen-measured-sources-628.json'
measured = read(measured_path)
sources = measured['sources']
assert sources == preflight['sources'] and len(sources) == 3265
relative = 'shardloom-vortex/src/vortex_ingest_zstd_size_bench.rs'
frozen = D / 'measured-source' / relative
before = frozen.read_bytes()
after = (R / relative).read_bytes()
assert sha(before) == sources[relative]['sha256']
command = ['/Users/dylan/.cargo/bin/rustup', 'run', '1.99.0', 'rustfmt', '--edition', '2024', '--emit', 'stdout']
formatted = subprocess.run(command, input=before, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True, cwd=R)
assert not formatted.stderr and formatted.stdout == after
unchanged = 0
for path, ref in sources.items():
    if path == relative:
        continue
    raw = (R / path).read_bytes()
    assert len(raw) == ref['bytes'] and sha(raw) == ref['sha256'], path
    unchanged += 1
report = dict(
    status='passed', measured_source_map=dict(path=str(measured_path), sha256=sha(measured_path.read_bytes())),
    selected_sources=len(sources), unchanged_sources=unchanged, changed_source=relative,
    measured_sha256=sha(before), formatted_sha256=sha(after),
    rustfmt_version=subprocess.check_output(command[:4]+['--version'], text=True).strip(),
    formatter_command=command, exact_formatter_output_matches=True, runtime_behavior_changed=False,
    measured_source_preserved=str(frozen),
)
target = O / 'native-ingest-text-screen-format-bridge-630.json'
target.open('x').write(json.dumps(report, indent=2)+'\n')
print(json.dumps(report))
