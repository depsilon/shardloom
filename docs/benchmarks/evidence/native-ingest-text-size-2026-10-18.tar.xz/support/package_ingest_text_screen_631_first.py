"""Preserve the complete bounded text screen, input inventory and rejected arms."""
from pathlib import Path
from decimal import Decimal
import hashlib
import io
import json
import statistics
import subprocess
import sys
import tarfile
import tempfile

R = Path('/Users/dylan/.codex/worktrees/native-ingest-text-size/shardloom-local-repo')
O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
D = O/'native-ingest-text-screen-629'
BASE = '77d5b5da9561b04b4c5cb81e94cce07529528cd8'
sys.path.insert(0, str(R/'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

read = lambda p: json.loads(Path(p).read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()
identity = lambda p: dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p.read_bytes()))
def checked(ref):
    p=Path(ref['path'])
    assert p.is_file() and not p.is_symlink(),p
    assert sha(p.read_bytes())==ref['sha256'],p
    assert p.stat().st_size==ref.get('bytes',p.stat().st_size),p
    return p

accept=read(D/'acceptance.json')
assert accept['status']=='passed_complete_screen'
assert (accept['profiles'],accept['native_files'],accept['complete_reads'],accept['predicate_count_checks'])==(6,360,1080,2160)
assert accept['source_generation_unchanged'] and accept['source_code_unchanged']
screen=read(checked(accept['screen']));pre=read(checked(accept['preflight']))
assert pre['base']==BASE and not screen['fallback_attempted'] and not screen['external_engine_invoked']
assert not screen['public_query_dispatch_proven'] and not screen['full_ingest_proven']
assert screen['row_groups']==[0,113,225] and screen['batches_per_region']==4 and screen['rows_per_batch']==32768
receipt=read(checked(accept['receipt']))
assert receipt['status']=='passed' and receipt['unchanged']
assert receipt['result']['returncode']==0 and not receipt['result']['guard_failures']
assert receipt['binary_sha256']==pre['binary']['sha256']
raw=checked(accept['raw']).read_text()
emitted=[line.removeprefix('NATIVE_ZSTD_SIZE_SCREEN ') for line in raw.splitlines() if line.startswith('NATIVE_ZSTD_SIZE_SCREEN ')]
assert len(emitted)==1 and json.loads(emitted[0])==screen
decision=read(D/'decision.json')
assert decision['status']=='passed_integrity' and not decision['accepted_production_policy']
assert decision['screen']==accept['screen'] and decision['preflight']==accept['preflight']
groups={name:[] for name in screen['profiles']}
assert len(groups)==6
for sample in screen['samples']:
    assert len(sample['cases'])==30 and sample['native_reserved_bytes_after_batch']==0
    for field in screen['columns']:
        cases=[row for row in sample['cases'] if row['column']==field]
        assert len(cases)==6 and len({row['footer_statistics'] for row in cases})==1
    for row in sample['cases']:
        assert row['all_values_validity_order_dtype_exact'] and row['rows']==32768
        assert len(row['native_read_and_exact_compare_micros'])==3 and len(row['predicates'])==2
        assert [x['negated'] for x in row['predicates']]==[False,True]
        assert all(len(x['native_scan_count_micros'])==3 for x in row['predicates'])
        assert len(row['persisted_zstd_witnesses'])==1
        witness=row['persisted_zstd_witnesses'][0]
        dictionary=row['profile'].endswith('_true');frame=4096 if '_4096_' in row['profile'] else 8192
        assert witness['rows']==sum(witness['frame_value_counts'])==32768
        assert witness['frame_count']==len(witness['frame_value_counts'])==32768//frame
        assert max(witness['frame_value_counts'])<=frame and (witness['dictionary_bytes']>0)==dictionary
        groups[row['profile']].append(dict(row,row_group=sample['row_group']))
assert len(screen['samples'])==12 and all(len(v)==60 for v in groups.values())
def aggregate(rows):
    return dict(physical_column_bytes=sum(r['physical_column_bytes'] for r in rows),
        complete_file_bytes=sum(r['complete_file_bytes'] for r in rows),
        native_write_micros=sum(r['native_write_micros'] for r in rows),
        native_read_median_sum_micros=sum(statistics.median(r['native_read_and_exact_compare_micros']) for r in rows),
        positive_filter_median_sum_micros=sum(statistics.median(r['predicates'][0]['native_scan_count_micros']) for r in rows),
        negative_filter_median_sum_micros=sum(statistics.median(r['predicates'][1]['native_scan_count_micros']) for r in rows))
base=aggregate(groups[decision['baseline']])
for row in decision['decisions']:
    values=aggregate(groups[row['profile']]);assert values==row['values']
    assert row['ratios_to_retained']=={k:str(Decimal(v)/Decimal(base[k])) for k,v in values.items()}
    regions=[dict(row_group=g,baseline_bytes=sum(r['physical_column_bytes'] for r in groups[decision['baseline']] if r['row_group']==g),
                  candidate_bytes=sum(r['physical_column_bytes'] for r in groups[row['profile']] if r['row_group']==g)) for g in screen['row_groups']]
    for region in regions:region['no_growth']=region['candidate_bytes']<=region['baseline_bytes']
    assert regions==row['regions']
    gates=dict(exact_checks_passed=True,
        physical_byte_reduction_at_least_30_percent=values['physical_column_bytes']*10<=base['physical_column_bytes']*7,
        no_region_grows=all(x['no_growth'] for x in regions),
        aggregate_write_at_most_1_25=values['native_write_micros']*4<=base['native_write_micros']*5,
        repeated_read_at_most_1_05=values['native_read_median_sum_micros']*20<=base['native_read_median_sum_micros']*21,
        positive_filter_at_most_1_05=values['positive_filter_median_sum_micros']*20<=base['positive_filter_median_sum_micros']*21,
        negative_filter_at_most_1_05=values['negative_filter_median_sum_micros']*20<=base['negative_filter_median_sum_micros']*21)
    assert gates==row['gates']
    assert row['decision']==('retained_control' if row['profile']==decision['baseline'] else 'drop_failed_frozen_screen')
    if row['profile']!=decision['baseline']:assert not all(gates.values())

sources=pre['sources'];assert len(sources)==3265
exceptions={Path(x['original']['path']).relative_to(R).as_posix():x for x in read(D/'measured-source/index.json')}
assert len(exceptions)==4
for relative,row in exceptions.items():
    original=row['original'];assert original==sources[relative]
    raw=Path(row['frozen_path']).read_bytes();assert len(raw)==original['bytes'] and sha(raw)==original['sha256']
plan_path=Path(exceptions['docs/benchmarks/native-ingest-text-size-2026-10-18.md']['frozen_path'])
assert decision['frozen_plan']==sources['docs/benchmarks/native-ingest-text-size-2026-10-18.md']
assert all(x in plan_path.read_text() for x in ['at least 30%','1.25 times retained','1.05 times retained'])
tree=subprocess.check_output(['git','ls-tree','-rz','--full-tree',BASE],cwd=R)
blobs={}
for record in tree.split(b'\0'):
    if record:
        meta,path=record.split(b'\t',1);mode,kind,oid=meta.split();
        if kind==b'blob':blobs[path.decode()]=oid.decode()
selected=[(p,blobs[p]) for p in sorted(sources) if p not in exceptions]
assert len(selected)==3261
source_proof={}
with tempfile.TemporaryFile(dir=O) as request:
    request.write(''.join(oid+'\n' for _,oid in selected).encode());request.seek(0)
    proc=subprocess.Popen(['git','cat-file','--batch'],cwd=R,stdin=request,stdout=subprocess.PIPE)
    for relative,oid in selected:
        actual,kind,size=proc.stdout.readline().strip().split();remaining=int(size)
        assert actual.decode()==oid and kind==b'blob' and remaining==sources[relative]['bytes'],relative
        digest=hashlib.sha256()
        while remaining:
            chunk=proc.stdout.read(min(remaining,1<<20));assert chunk;digest.update(chunk);remaining-=len(chunk)
        assert proc.stdout.read(1)==b'\n' and digest.hexdigest()==sources[relative]['sha256'],relative
        source_proof[relative]=dict(git_blob=oid,sha256=digest.hexdigest())
    assert proc.wait()==0 and not proc.stdout.read()
bridge=read(O/'native-ingest-text-screen-format-bridge-630.json')
assert bridge['status']=='passed' and bridge['unchanged_sources']==3264 and bridge['exact_formatter_output_matches']
lint_bridge=read(O/'native-ingest-text-screen-lint-bridge-630b.json')
assert lint_bridge['status']=='passed' and lint_bridge['formatted_sha256']==bridge['formatted_sha256']
assert lint_bridge['codec_and_consumer_timing_bodies_unchanged'] and lint_bridge['measured_case_results_equivalent']
assert sha((R/bridge['changed_source']).read_bytes())==lint_bridge['final_sha256']
checks=read(O/'native-ingest-text-rust-results-630b.json')
assert checks['status']=='passed' and len(checks['checks'])==4 and all(x['returncode']==0 for x in checks['checks'])
for name in ['native-ingest-text-screen-check-628','native-ingest-text-screen-units-628','native-ingest-text-screen-629b','native-ingest-text-rust-630b','native-ingest-inventory-build-627','native-ingest-inventory-627c']:
    record=read(O/(name+'.json'));assert record['status']=='passed' and record['returncode']==0 and record['process_group_drained']
    assert sha((O/(name+'.log')).read_bytes())==record['log_sha256']
unit_log=(O/'native-ingest-text-screen-units-628.log').read_text()
assert '2 passed; 0 failed; 1 ignored' in unit_log
inventory=read(O/'native-ingest-inventory-627c/report.json')
assert inventory['status']=='passed' and inventory['head']==BASE and inventory['flat_reference_count']==611520
assert inventory['artifact']['bytes']==15713610513 and inventory['unique_flat_segment_bytes']==15658321452
assert inventory['remaining_file_bytes']==55289061 and inventory['all_referenced_segments_are_flat']
for key in ['preflight','receipt','inventory']:checked(inventory[key])
attribution=read(O/'native-ingest-inventory-627c/attribution.json')
assert attribution['source_zstd_bytes']==7602132264 and attribution['source_zstd_columns']==28
assert attribution['column_bytes_additive_for_this_artifact_only']
checked(attribution['inventory']);checked(attribution['ingest_output'])

files={}
def add(name,path):
    path=Path(path)
    assert name not in files and path.is_file() and not path.is_symlink() and path.stat().st_size<8*MIB,(name,path)
    files[name]=path
for folder in ['native-ingest-inventory-627','native-ingest-inventory-627b','native-ingest-inventory-627c','native-ingest-text-screen-629']:
    for path in sorted((O/folder).rglob('*')):
        if path.is_file() and path.name not in ['physical_encoding_inventory','native-zstd-size-screen']:
            add('observations/'+path.relative_to(O).as_posix(),path)
for prefix in ['native-ingest-inventory-build-627','native-ingest-inventory-627','native-ingest-inventory-627b','native-ingest-inventory-627c',
               'native-ingest-text-screen-check-628','native-ingest-text-screen-units-628','native-ingest-text-screen-629','native-ingest-text-screen-629b','native-ingest-text-rust-630','native-ingest-text-rust-630b']:
    for suffix in ['.json','.log']:add('supervision/'+prefix+suffix,O/(prefix+suffix))
for name in ['inspect_current_ingest_layout_627.py','inspect_current_ingest_layout_627_first.py','inspect_current_ingest_layout_627_second.py',
             'run_ingest_text_screen_629.py','run_ingest_text_screen_629_first.py','evaluate_ingest_text_screen_629.py',
             'native-ingest-text-screen-preflight-correction-629.json','native-ingest-text-screen-measured-sources-628.json',
             'native-ingest-text-screen-format-bridge-630.json','verify_ingest_text_format_bridge_630.py',
             'verify_ingest_text_rust_630.py','native-ingest-text-rust-results-630.json',
             'verify_ingest_text_rust_630b.py','native-ingest-text-rust-results-630b.json',
             'verify_ingest_text_lint_bridge_630b.py','native-ingest-text-screen-lint-bridge-630b.json',Path(__file__).name]:
    add('support/'+name,O/name)
for ref in [accept['raw'],accept['receipt'],inventory['receipt'],inventory['inventory'],attribution['ingest_output']]:
    path=checked(ref);add('raw/'+path.parent.name+'/'+path.name,path)
failed_logs=Path(inventory['receipt']['path']).parent.parent/'readonly-proof-native-ingest-layout-627b'
for path in sorted(failed_logs.glob('*')):
    if path.is_file():add('raw/'+failed_logs.name+'/'+path.name,path)
for name in ['scripts/run_local_readonly_proof.py','scripts/local_uat_storage.py','shardloom-vortex/src/vortex_ingest_zstd_size_bench.rs']:
    add('formatted-source/'+name,R/name)
out=require_local_path(O/'native-ingest-text-size-packet-631',Path.home(),sys.platform)
assert not out.exists() and sum(p.stat().st_size for p in files.values())<16*MIB
check_budgets(O,out,O/'logs',min_free_bytes=12*GIB,reserve_bytes=64*MIB,max_workspace_bytes=100*GIB,max_log_bytes=192*MIB)
out.mkdir()
proof_path=out/'measured-source-reconstruction.json'
proof_path.write_text(json.dumps(dict(base=BASE,immutable_base_sources=source_proof,measured_exceptions=exceptions),indent=2)+'\n')
add('source-reconstruction.json',proof_path)
archive=out/'native-ingest-text-size-2026-10-18.tar.xz';members=[]
with tarfile.open(archive,'x:xz') as bundle:
    for name,path in sorted(files.items()):
        raw=path.read_bytes();item=tarfile.TarInfo(name);item.size=len(raw);item.mode=0o644
        bundle.addfile(item,io.BytesIO(raw));members.append(dict(name=name,bytes=len(raw),sha256=sha(raw)))
with tarfile.open(archive,'r:xz') as bundle:
    assert len(bundle.getmembers())==len(members)
    for row in members:
        member=bundle.getmember(row['name']);assert member.isfile()
        raw=bundle.extractfile(member).read()
        assert len(raw)==row['bytes'] and sha(raw)==row['sha256'] and raw==files[row['name']].read_bytes()
result=dict(schema_version='shardloom.native_ingest_text_size_packet.v1',status='passed',base=BASE,
    inventory_artifact=inventory['artifact'],unique_flat_segment_bytes=inventory['unique_flat_segment_bytes'],remaining_file_bytes=inventory['remaining_file_bytes'],
    source_zstd_columns=28,source_zstd_bytes=7602132264,measured_sources=3265,immutable_base_sources=3261,source_exceptions=4,
    source_identity_preserved=True,all_members_reopened=True,profiles=6,native_files=360,complete_reads=1080,predicate_count_checks=2160,
    decision='all_five_alternatives_rejected_under_frozen_screen',production_writer_changed=False,
    best_sample_physical_bytes=27657172,retained_sample_physical_bytes=44413684,
    full_ingest_proven=False,public_query_dispatch_proven=False,benchmark_decision=decision,
    archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes())),members=members,
    limits=['Structured text samples are not whole-artifact reductions.',
            'Native provider costs are not Full43 engine times or public query dispatch.',
            'Footer statistics match the retained writer, without an independent source-statistics oracle.',
            'The admitted native pool is not a process RSS bound.',
            'Large inputs and binaries stay local; the packet retains identities and source reconstruction.'])
index=out/'native-ingest-text-size-2026-10-18.json';index.open('x').write(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status='passed',index=str(index),archive=result['archive'],members=len(members))))
