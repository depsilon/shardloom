"""Freeze and run the bounded native Zstd screen with the established UAT guards."""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

R = Path('/Users/dylan/.codex/worktrees/native-ingest-text-size/shardloom-local-repo')
O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
U = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
D = O / 'native-ingest-text-screen-629'
SOURCE = U / 'sources/hits.parquet'
BASE = '77d5b5da9561b04b4c5cb81e94cce07529528cd8'
BUILD_NAME = 'native-ingest-text-screen-check-628'
TEST = 'vortex_ingest::dictionary_preservation::source_dictionary_bench::zstd_size_screen::clickbench_zstd_size_admission_screen'
sys.path.insert(0, str(R / 'scripts'))
from local_uat_storage import DEFAULT_MAX_LOG_MIB, GIB, MIB, check_budgets, require_local_path
from run_clickbench_paired_query_uat import generation

def read(path):
    return json.loads(path.read_text())

def identity(path):
    before = generation(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    assert generation(path) == before, path
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=R)

def sources():
    names = sorted(set(git('ls-files', '-c', '-o', '--exclude-standard', '-z').decode().split('\0')) - {''})
    suffixes = ('.rs', '.toml', '.lock', '.py', '.pyi', '.sh', '.md', '.json', '.yaml', '.yml', '.fbs')
    return {name: identity(R / name) for name in names if name.endswith(suffixes) or name.startswith('vendor/')}

assert git('rev-parse', 'HEAD').decode().strip() == BASE
build_path = O / (BUILD_NAME + '.json')
build = read(build_path)
assert build['status'] == 'passed' and build['process_group_drained']
assert build['head'] == BASE and build['cwd'] == str(R)
build_log = O / (BUILD_NAME + '.log')
assert identity(build_log)['sha256'] == build['log_sha256']
matches = re.findall(r'Executable unittests src/lib.rs \(([^)]+)\)', build_log.read_text())
assert len(matches) == 1, matches
binary = require_local_path(Path(matches[0]), Path.home(), sys.platform)
assert binary.is_relative_to(Path(build['environment']['CARGO_TARGET_DIR']))
for path in (SOURCE, D):
    require_local_path(path, Path.home(), sys.platform)
assert SOURCE.stat().st_size == 14_779_976_446 and SOURCE.stat().st_flags == 0
assert SOURCE.stat().st_blocks * 512 >= SOURCE.stat().st_size
assert not D.exists()
check_budgets(O, D, O / 'logs', min_free_bytes=12 * GIB, reserve_bytes=128 * MIB,
              max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
source_generation = generation(SOURCE)
source_identity = identity(SOURCE)
mapping = sources()
assert mapping == read(O / 'native-ingest-text-screen-measured-sources-628.json')['sources']
D.mkdir()
frozen = D / 'native-zstd-size-screen'
shutil.copy2(binary, frozen)
assert identity(frozen)['sha256'] == identity(binary)['sha256']
listing = subprocess.check_output([str(frozen), '--list', '--format', 'terse'], text=True)
assert listing.count(TEST + ': test') == 1
command = [sys.executable, '-B', str(R / 'scripts/run_local_readonly_proof.py'),
           '--uat-root', str(U), '--source', str(SOURCE), '--name', 'native-zstd-size-629',
           '--timeout-seconds', '900', '--max-log-mib', str(DEFAULT_MAX_LOG_MIB),
           '--max-run-log-mib', '8']
for relative in ('docs/benchmarks/native-ingest-text-size-2026-10-18.md',
                 'shardloom-vortex/src/vortex_ingest_zstd_size_bench.rs',
                 'shardloom-vortex/src/vortex_ingest_source_dictionary_bench.rs',
                 'scripts/run_local_readonly_proof.py', 'scripts/local_uat_storage.py'):
    command += ['--input', str(R / relative)]
command += ['--', str(frozen), '--exact', TEST, '--ignored', '--nocapture', '--test-threads=1']
preflight = dict(status='frozen_before_measurement', base=BASE, build=identity(build_path),
                 script=identity(Path(__file__)), source=source_identity,
                 decision_evaluator=identity(O / 'evaluate_ingest_text_screen_629.py'),
                 source_generation=source_generation, binary=identity(frozen), sources=mapping,
                 command=command, input_environment={'SHARDLOOM_R1B_SOURCE':str(SOURCE)})
(D / 'preflight.json').write_text(json.dumps(preflight, indent=2) + '\n')
env = dict(os.environ, SHARDLOOM_R1B_SOURCE=str(SOURCE))
with (D / 'runner.stdout.json').open('xb') as output:
    code = subprocess.call(command, cwd=R, env=env, stdout=output, stderr=subprocess.STDOUT)
assert code == 0, f'guarded screen failed: {code}'
receipt_path = U / 'logs/readonly-proof-native-zstd-size-629/receipt.json'
receipt = read(receipt_path)
assert receipt['status'] == 'passed' and receipt['unchanged']
assert receipt['result']['returncode'] == 0 and not receipt['result']['guard_failures']
assert receipt['binary_sha256'] == identity(frozen)['sha256']
assert source_generation == generation(SOURCE)
assert sources() == mapping
raw_path = receipt_path.parent / 'proof.stdout.json'
text = raw_path.read_text()
prefix = 'NATIVE_ZSTD_SIZE_SCREEN '
records = [line.split(prefix, 1)[1] for line in text.splitlines() if prefix in line]
assert len(records) == 1
report = json.loads(records[0])
assert report['schema_version'] == 'shardloom.native_zstd_size_screen.v1'
assert report['fallback_attempted'] is report['external_engine_invoked'] is False
assert report['rows_per_batch'] == 32768 and report['batches_per_region'] == 4
assert report['row_groups'] == [0, 113, 225] and len(report['profiles']) == 6
assert len(report['samples']) == 12
for sample in report['samples']:
    assert sample['rows'] == 32768 and sample['native_reserved_bytes_after_batch'] == 0
    assert len(sample['cases']) == 30
    assert len({(x['column'], x['profile']) for x in sample['cases']}) == 30
    assert {x['profile'] for x in sample['cases']} == set(report['profiles'])
    for row in sample['cases']:
        assert row['all_values_validity_order_dtype_exact'] and row['rows'] == 32768
        assert len(row['native_read_and_exact_compare_micros']) == 3
        assert len(row['predicates']) == 2 and all(len(x['native_scan_count_micros']) == 3 for x in row['predicates'])
(D / 'screen.json').write_text(json.dumps(report, indent=2) + '\n')
result = dict(status='passed_complete_screen', preflight=identity(D / 'preflight.json'),
              raw=identity(raw_path), receipt=identity(receipt_path), screen=identity(D / 'screen.json'),
              source_generation_unchanged=True, source_code_unchanged=True,
              profiles=6, native_files=360, complete_reads=1080, predicate_count_checks=2160,
              full_ingest_proven=False, public_query_dispatch_proven=False)
(D / 'acceptance.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
