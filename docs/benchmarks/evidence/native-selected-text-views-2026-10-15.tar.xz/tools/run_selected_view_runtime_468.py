"""Build and verify the same selected-view provider through Python and public CLI workflows."""
import json
from pathlib import Path
import subprocess
import sys
import venv

import run_query_timing_runtime_461 as shared
from freeze_native_release_298 import ROOT, OUT, sha, sources, save

MANIFEST = OUT / 'selected-view-native-artifacts-468.json'
ENV = OUT / 'selected-view-python-468'
PYTHON = ENV / 'bin/python'
DIRECT = OUT / 'selected-view-direct-tests-468.json'
PUBLIC = OUT / 'selected-view-public-468'
shared.MANIFEST = MANIFEST
shared.DIRECT = DIRECT
shared.TEST_PYTHON = PYTHON


def main():
    checks_path = OUT / 'selected-view-checks-468b.json'
    checks = json.loads(checks_path.read_text())
    assert checks['status'] == 'passed' and checks['source_identity_preserved']
    assert len(checks['completed']) == 7
    source_path = Path(checks['protocol']['source_manifest'])
    assert sha(source_path) == checks['protocol']['source_manifest_sha256']
    accepted = json.loads(source_path.read_text())['source_sha256']
    assert sources() == accepted
    cli_path = OUT / 'selected-views-467-release.json'
    manifest = json.loads(cli_path.read_text())
    assert manifest['status'] == 'passed' and manifest['source_sha256'] == accepted
    assert sha(manifest['cli']['path']) == manifest['cli']['sha256']
    assert not MANIFEST.exists() and not ENV.exists() and not PUBLIC.exists()
    shared.guarded('selected-view-binding-build-468', 2100,
        [sys.executable, '-B', ROOT / 'scripts/build_native_python.py', '--release', '--offline',
         '--output-dir', OUT / 'selected-view-native-binding-468'])
    receipt_path = OUT / 'selected-view-binding-build-468.json'
    receipt = json.loads(receipt_path.read_text())
    log = receipt_path.with_suffix('.log')
    assert receipt['status'] == 'passed' and receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert sha(log) == receipt['log_sha256']
    raw = log.read_text()
    start = raw.index('{\n  "schema_version": "shardloom.native_python_build.v1"')
    binding = json.loads(raw[start:])
    assert binding['status'] == 'passed' and '--release' in binding['command']
    assert sha(binding['library']) == sha(binding['cargo_artifact']) == binding['library_sha256']
    manifest.update(schema_version='shardloom.selected_view_native_artifacts.v1',
        cli_manifest=dict(path=str(cli_path), sha256=sha(cli_path)),
        checks=dict(path=str(checks_path), sha256=sha(checks_path)),
        binding=dict(path=binding['library'], sha256=binding['library_sha256'], bytes=binding['library_bytes'],
            build_receipt=str(receipt_path), build_receipt_sha256=sha(receipt_path), build_log=str(log)))
    assert sources() == accepted
    save(MANIFEST, manifest)
    assert shared.load() == manifest
    venv.EnvBuilder(with_pip=False).create(ENV)
    site = ENV / f'lib/python{sys.version_info.major}.{sys.version_info.minor}/site-packages'
    path_file = site / 'shardloom-acceptance.pth'
    path_file.write_text(str(shared.PYTHON_DEPS) + '\n' + str(ROOT / 'python/src') + '\n')
    probe = subprocess.run([str(PYTHON), '-I', '-c',
        'import json,pyarrow,shardloom,sys; print(json.dumps(dict(interpreter=sys.executable, '
        'pyarrow=pyarrow.__file__,version=pyarrow.__version__,package=shardloom.__file__, '
        'isolated=sys.flags.isolated)))'], check=True, capture_output=True, text=True, timeout=30)
    observed = json.loads(probe.stdout)
    assert Path(observed['interpreter']) == PYTHON and observed['isolated'] == 1
    assert Path(observed['pyarrow']).is_relative_to(shared.PYTHON_DEPS)
    assert Path(observed['package']) == ROOT / 'python/src/shardloom/__init__.py'
    environment_path = OUT / 'selected-view-python-environment-468.json'
    save(environment_path, dict(status='passed', observation=observed, path_file=str(path_file),
        path_file_sha256=sha(path_file), setup='private_venv_with_existing_dependency_paths',
        network_used=False, installed_wheel_proof=False, helper_sha256=sha(__file__)))
    shared.guarded('selected-view-direct-468', 1800, [PYTHON, '-B', __file__, 'direct'])
    direct = json.loads(DIRECT.read_text())
    assert direct['status'] == 'passed' and direct['tests'] == 80
    shared.guarded('selected-view-public-468', 5400,
        [sys.executable, '-B', ROOT / 'scripts/run_native_streaming_input_uat.py',
         '--binary', manifest['cli']['path'], '--uat-root', PUBLIC, '--operation-timeout', '600'])
    public_path = PUBLIC / 'summary.json'
    public = json.loads(public_path.read_text())
    assert public['status'] == 'passed'
    assert len(public['families']) == len(set(public['families'])) == 19
    assert len(public['cases']) == len({case['name'] for case in public['cases']}) == 757
    assert all(case['status'] == 'passed' for case in public['cases'])
    assert shared.load() == manifest
    save(OUT / 'selected-view-runtime-468.json', dict(status='passed',
        manifest=str(MANIFEST), manifest_sha256=sha(MANIFEST),
        direct_summary=str(DIRECT), direct_summary_sha256=sha(DIRECT),
        public_summary=str(public_path), public_summary_sha256=sha(public_path),
        public_families=public['families'], public_cases=len(public['cases']), source_identity_preserved=True,
        environment_receipt=str(environment_path), environment_receipt_sha256=sha(environment_path),
        helper=str(Path(__file__).resolve()), helper_sha256=sha(__file__),
        reused_direct_helper=str(Path(shared.__file__).resolve()),
        reused_direct_helper_sha256=sha(shared.__file__), installed_wheel_proof=False,
        publication_attempted=False))
    print(json.dumps(dict(status='passed', direct_tests=80, public_cases=757, public_families=19)))


if __name__ == '__main__':
    shared.direct() if sys.argv[1:] == ['direct'] else main()
