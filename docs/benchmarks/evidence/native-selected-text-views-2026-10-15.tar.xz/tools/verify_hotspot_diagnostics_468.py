"""Reopen the five diagnostic samples without treating profiled clocks as benchmarks."""
import hashlib
import json
from pathlib import Path
import sys

from freeze_native_release_298 import ROOT, OUT, sha, save
sys.path.insert(0, str(ROOT / 'scripts'))
from clickbench_reference_packet import load_reference_packet
from native_workflow_protocol import extract_result, report_fields, strict_json
from run_clickbench_query_uat import equivalent, read_json_log


def bound(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def main():
    folder = OUT / 'hotspot-profiles-465'
    summary_path = folder / 'summary.json'
    summary = json.loads(summary_path.read_text())
    assert summary['status'] == 'passed' and summary['lock_released']
    assert summary['purpose'] == 'diagnostic_sampling_not_benchmark_timing'
    assert summary['query_order'] == [23, 19, 29, 34, 35]
    assert [r['query'] for r in summary['records']] == summary['query_order']
    manifest_path = Path(summary['artifact_manifest'])
    assert sha(manifest_path) == summary['artifact_manifest_sha256']
    manifest = json.loads(manifest_path.read_text())
    assert sha(manifest['cli']['path']) == manifest['cli']['sha256'] == summary['binary_sha256']
    assert sha(OUT / 'profile_hotspots_465.py') == summary['helper_sha256']
    hosted_path = OUT / 'compression-hosted-466/verification.json'
    hosted_index = json.loads((ROOT / 'docs/benchmarks/evidence/native-compression-hosted-2026-10-15.json').read_text())
    archived = [m for m in hosted_index['members'] if m['name'] == 'hosted/verification.json']
    assert len(archived) == 1 and sha(hosted_path) == archived[0]['sha256']
    hosted = json.loads(hosted_path.read_text())
    assert hosted['status'] == 'passed' and hosted['accepted_native_source_preserved']
    assert summary['current_head'] == hosted['head']
    expected = dict(manifest['source_sha256'])
    for path, change in hosted['changed_since_measured_source'].items():
        assert expected[path] == change['measured_sha256']
        expected[path] = change['merged_sha256']
    assert expected == summary['source_sha256']
    assert sorted(summary['source_differences_from_accepted']) == sorted(hosted['changed_since_measured_source'])
    assert sha(summary['baseline_summary']) == summary['baseline_sha256']
    reference_path = Path('/Users/dylan/LocalData/shardloom/native-typed-reductions-20261004/clickbench-reference-values-2.json')
    reference = load_reference_packet(reference_path, ROOT / 'benchmarks/clickbench/queries.sql')
    inspected = []
    for row in summary['records']:
        query = row['query']
        assert row['passed'] and row['returncode'] == row['sample_returncode'] == 0
        assert row['native_child_absent'] and row['timing_supervisor_reaped'] and row['sampler_reaped']
        for item in row['files']:
            assert bound(item['path']) == item
        receipt_path = folder / f'q{query}.receipt.json'
        assert json.loads(receipt_path.read_text()) == row
        envelope = strict_json((folder / f'q{query}.stdout.json').read_text())
        fields = report_fields(envelope)
        baseline = read_json_log(Path(summary['baseline_summary']).parent / f'q{query:02d}_run1.stdout.json')
        baseline_fields = report_fields(baseline)
        values = extract_result(envelope)
        assert equivalent(values, reference['values'][query])
        assert len(values) == row['complete_rows']
        assert hashlib.sha256(json.dumps(values, sort_keys=True, allow_nan=False).encode()).hexdigest() == row['result_sha256']
        assert fields['result_schema_json'] == baseline_fields['result_schema_json'] == row['schema_json']
        assert fields['result_schema_format'] == baseline_fields['result_schema_format'] == row['schema_format']
        assert fields['execution_resource_declared_memory_bytes'] == str(24 * (1 << 30))
        assert fields['execution_resource_declared_max_parallelism'] == '12'
        assert fields['fallback_attempted'] == fields['external_engine_invoked'] == 'false'
        assert any(c['kind'] == 'native_io_certificate' and c['status'] == 'available' for c in envelope['certificates'])
        inspected.append(dict(query=query, complete_rows=len(values), receipt=bound(receipt_path), files=row['files']))
    guard_path = OUT / 'hotspot-diagnostics-465.json'
    guard = json.loads(guard_path.read_text())
    assert guard['status'] == 'passed' and guard['process_group_drained'] and guard['direct_child_reaped']
    assert sha(guard_path.with_suffix('.log')) == guard['log_sha256']
    output = OUT / 'hotspot-diagnostics-primary-review-468.json'
    save(output, dict(status='passed', summary=bound(summary_path), guard=bound(guard_path),
        hosted_source_proof=bound(hosted_path), source_files=len(expected), binary_sha256=summary['binary_sha256'],
        reference=bound(reference_path), records=inspected, helper=bound(__file__),
        profiled_durations_allowed_for_benchmark=False, exclusive_cpu_attribution_established=False,
        boundary='Five diagnostic samples of the accepted baseline; profiling perturbs timing. No speedup gate uses these durations.'))
    print(json.dumps(dict(status='passed', queries=summary['query_order'], source_files=len(expected))))


if __name__ == '__main__':
    main()
