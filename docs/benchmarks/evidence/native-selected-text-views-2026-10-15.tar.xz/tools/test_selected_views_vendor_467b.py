"""Fresh source copy after repairing the test's missing allocator-extension import."""
import test_selected_views_vendor_467 as driver

driver.OUT = driver.OUT.with_name('selected-view-vendor-467b')
driver.main()
