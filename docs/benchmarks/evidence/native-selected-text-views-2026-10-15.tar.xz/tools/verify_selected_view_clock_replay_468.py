#!/usr/bin/env python3
"""Independently replay selected-view clocks from retained raw archives."""
import hashlib
import json
import math
import statistics
import tarfile
from pathlib import Path

OUT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
BASE = OUT / 'selected-view-comparison-467'
RESULTS = BASE / 'results.json'
PROTOCOL = BASE / 'protocol.json'
DEST = OUT / 'selected-view-clock-replay-468.json'
CLOCK = 'monotonic_wall_not_cpu'
BOUNDARY = ('prepared_native_execution_including_io_generation_validation_and_certification_'
            'excluding_result_serialization')
TOL = 1e-12


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_identity(path):
    data = Path(path).read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def load(path):
    return json.loads(Path(path).read_text())


def fields(envelope):
    result = {}
    for item in envelope['fields']:
        key = item['key']
        if key in result:
            raise ValueError('duplicate raw field: ' + key)
        result[key] = item.get('value')
    return result


def close(a, b):
    return type(a) in (int, float) and type(b) in (int, float) and math.isclose(a, b, rel_tol=TOL, abs_tol=TOL)


def compare_field(mismatches, identity, field, expected, actual):
    if expected is None and actual is None:
        return
    if isinstance(expected, (int, float)) and not isinstance(expected, bool):
        ok = close(expected, actual)
    else:
        ok = expected == actual
    if not ok:
        mismatches.append({'identity': identity, 'field': field, 'stored': expected, 'replayed': actual})


def main():
    protocol = load(PROTOCOL)
    results = load(RESULTS)
    mismatches = []
    source_paths = {
        'comparison_driver': OUT / 'compare_selected_views_467.py',
        'query_timing_report': ROOT / 'scripts/query_timing_report.py',
        'timed_native_command': ROOT / 'scripts/timed_native_command.py',
        'paired_runner': ROOT / 'scripts/run_clickbench_paired_query_uat.py',
        'query_runner': ROOT / 'scripts/run_clickbench_query_uat.py',
        'protocol_reader': ROOT / 'scripts/native_workflow_protocol.py',
    }
    source_identities = {name: file_identity(path) for name, path in source_paths.items()}
    archive_evidence = []
    raw_records = []
    result_records = {(r['query'], r['lanes'], r['run'], r['role']): r for r in results['records']}
    cohort_summaries = []
    archive_count = member_count = 0

    for cohort in results['cohorts']:
        summary_ref = cohort['summary']
        summary_path = Path(summary_ref['path'])
        summary_identity = file_identity(summary_path)
        compare_field(mismatches, str(summary_path), 'summary.bytes', summary_ref['bytes'], summary_identity['bytes'])
        compare_field(mismatches, str(summary_path), 'summary.sha256', summary_ref['sha256'], summary_identity['sha256'])
        summary = load(summary_path)
        expected_records = []
        archive_raw = {}
        for archive in summary['archives']:
            archive_identity = file_identity(archive['path'])
            compare_field(mismatches, archive['path'], 'archive.sha256', archive['sha256'], archive_identity['sha256'])
            archive_count += 1
            this_archive = {'identity': archive_identity, 'declared_sha256': archive['sha256'], 'members': []}
            with tarfile.open(archive['path'], 'r:xz') as stream:
                names = stream.getnames()
                declared_names = [m['name'] for m in archive['members']]
                compare_field(mismatches, archive['path'], 'archive.member_order', declared_names, names)
                for member in archive['members']:
                    payload = stream.extractfile(member['name']).read()
                    actual_hash = sha(payload)
                    compare_field(mismatches, member['name'], 'member.bytes', member['bytes'], len(payload))
                    compare_field(mismatches, member['name'], 'member.sha256', member['sha256'], actual_hash)
                    if member['name'] in archive_raw:
                        mismatches.append({'identity': member['name'], 'field': 'duplicate_member', 'stored': None, 'replayed': 'duplicate'})
                    archive_raw[member['name']] = payload
                    member_count += 1
                    this_archive['members'].append({'name': member['name'], 'bytes': len(payload), 'sha256': actual_hash})
            archive_evidence.append(this_archive)

        for row in summary['records']:
            key = (row['query'], row['run'], row['role'])
            result_key = (row['query'], cohort['lanes'], row['run'], row['role'])
            prefix = f"q{row['query']:02d}_run{row['run']}_{row['role']}"
            env_name, timing_name = prefix + '.stdout.json', prefix + '.timing.json'
            envelope = json.loads(archive_raw[env_name].decode('utf-8'))
            f = fields(envelope)
            timing = json.loads(archive_raw[timing_name].decode('utf-8'))
            identity = f'q{key[0]:02d}_run{key[1]}_{key[2]}'
            if envelope.get('status') != 'success':
                mismatches.append({'identity': identity, 'field': 'envelope.status', 'stored': 'success', 'replayed': envelope.get('status')})
            compare_field(mismatches, identity, 'native_query_timing_reported', 'true', f.get('native_query_timing_reported'))
            compare_field(mismatches, identity, 'native_query_timing_clock', CLOCK, f.get('native_query_timing_clock'))
            compare_field(mismatches, identity, 'native_query_timing_boundary', BOUNDARY, f.get('native_query_timing_boundary'))
            for key_name in ('public_workflow_fallback_attempted', 'public_workflow_external_engine_invoked'):
                compare_field(mismatches, identity, key_name, 'false', f.get(key_name))
            engine = int(f['native_query_execution_nanos']) / 1_000_000_000
            serialization = int(f['native_result_serialization_nanos']) / 1_000_000_000
            process = timing['seconds']
            record = {
                'query': row['query'], 'run': row['run'], 'role': row['role'],
                'lanes': cohort['lanes'],
                'engine_execution_seconds': engine,
                'result_serialization_seconds': serialization,
                'process_other_seconds': max(0.0, process - engine - serialization),
                'process_wall_seconds': process, 'seconds': process,
                'cpu_seconds': timing['user_cpu_seconds'] + timing['system_cpu_seconds'],
                'native_peak_rss_bytes': timing['peak_rss_bytes'],
                'user_cpu_seconds': timing['user_cpu_seconds'], 'system_cpu_seconds': timing['system_cpu_seconds'],
                'minor_page_faults': timing['minor_page_faults'], 'major_page_faults': timing['major_page_faults'],
                'input_block_operations': timing['input_block_operations'], 'output_block_operations': timing['output_block_operations'],
                'returncode': timing['returncode'],
            }
            fields_to_compare = ('engine_execution_seconds', 'result_serialization_seconds', 'process_other_seconds',
                                 'process_wall_seconds', 'seconds', 'user_cpu_seconds', 'system_cpu_seconds',
                                 'minor_page_faults', 'major_page_faults', 'input_block_operations', 'output_block_operations')
            for field in fields_to_compare:
                compare_field(mismatches, identity, field, row.get(field), record.get(field))
                compare_field(mismatches, identity, 'results.' + field, result_records[result_key].get(field), record.get(field))
            compare_field(mismatches, identity, 'native_peak_rss_bytes', row.get('native_peak_rss_bytes'), record['native_peak_rss_bytes'])
            compare_field(mismatches, identity, 'results.native_peak_rss_bytes', result_records[result_key].get('native_peak_rss_bytes'), record['native_peak_rss_bytes'])
            compare_field(mismatches, identity, 'returncode', row.get('returncode'), timing.get('returncode'))
            compare_field(mismatches, identity, 'timing.returncode', 0, timing.get('returncode'))
            compare_field(mismatches, identity, 'passed', True, row.get('passed'))
            compare_field(mismatches, identity, 'validation', 'complete_values', row.get('validation'))
            compare_field(mismatches, identity, 'guard_failures', [], row.get('guard_failures'))
            output = f.get('result_jsonl')
            rows = [json.loads(line) for line in output.splitlines()]
            canonical_result_sha = sha(json.dumps(rows, sort_keys=True, allow_nan=False).encode())
            compare_field(mismatches, identity, 'result_sha256', row.get('result_sha256'), canonical_result_sha)
            compare_field(mismatches, identity, 'results.result_sha256', result_records[result_key].get('result_sha256'), canonical_result_sha)
            expected_records.append(record)
            raw_records.append(record)
        # Paired outputs must agree exactly for each query/run.
        paired = {}
        for row in summary['records']:
            prefix = f"q{row['query']:02d}_run{row['run']}_{row['role']}"
            env = json.loads(archive_raw[prefix + '.stdout.json'].decode())
            output = fields(env)['result_jsonl']
            paired.setdefault((row['query'], row['run']), {})[row['role']] = sha(output.encode())
        for pair_key, roles in paired.items():
            compare_field(mismatches, f'q{pair_key[0]:02d}_run{pair_key[1]}', 'paired_result_payload_sha256', roles.get('control'), roles.get('candidate'))
        cohort_summaries.append({'query_ids': cohort['query_ids'], 'lanes': cohort['lanes'],
                                 'records': len(expected_records), 'summary': summary_identity,
                                 'score_replay': score_cohort(expected_records, summary, mismatches)})

    replay_gates = compute_gates(protocol, raw_records)
    stored_gates = results['gates']
    if len(replay_gates) != len(stored_gates):
        mismatches.append({'identity': 'results.gates', 'field': 'count', 'stored': len(stored_gates), 'replayed': len(replay_gates)})
    for actual, stored in zip(replay_gates, stored_gates):
        for key in ('query', 'lanes', 'pairs', 'target', 'positive_pairs', 'engine_passed', 'cpu_passed', 'rss_passed', 'passed'):
            compare_field(mismatches, f"q{actual['query']}_lanes{actual['lanes']}", 'gate.' + key, stored.get(key), actual.get(key))
        for role in ('control', 'candidate'):
            for metric, value in actual['medians'][role].items():
                compare_field(mismatches, f"q{actual['query']}_lanes{actual['lanes']}", f'gate.medians.{role}.{metric}', stored['medians'][role].get(metric), value)
        compare_field(mismatches, f"q{actual['query']}_lanes{actual['lanes']}", 'gate.paired_engine_savings_seconds', stored.get('paired_engine_savings_seconds'), actual['paired_engine_savings_seconds'])
        compare_field(mismatches, f"q{actual['query']}_lanes{actual['lanes']}", 'gate.engine_median_improvement_percent', stored.get('engine_median_improvement_percent'), actual['engine_median_improvement_percent'])
    report = {
        'schema_version': 'shardloom.selected_view_clock_replay.v1',
        'status': 'passed' if not mismatches else 'mismatch',
        'inputs': {'protocol': file_identity(PROTOCOL), 'results': file_identity(RESULTS)},
        'sources': source_identities,
        'source_contract': [
            {'file': str(source_paths['query_timing_report']), 'lines': '8-19, 24-56', 'fields': ['TIMING_CLOCK', 'TIMING_BOUNDARY', 'native_query_execution_nanos', 'native_result_serialization_nanos']},
            {'file': str(source_paths['timed_native_command']), 'lines': '55-77', 'fields': ['seconds', 'returncode', 'peak_rss_bytes', 'user_cpu_seconds', 'system_cpu_seconds', 'page faults', 'block operations']},
            {'file': str(source_paths['comparison_driver']), 'lines': '130-216', 'fields': ['archive/member verification', 'raw timing mapping', 'gate recomputation']},
            {'file': str(source_paths['paired_runner']), 'lines': '94-154, 318-333', 'fields': ['paired scoring', 'canonical result hash']},
            {'file': str(source_paths['query_runner']), 'lines': '258-321', 'fields': ['best complete raw run per query scoring rule']},
        ],
        'coverage': {'cohorts': len(cohort_summaries), 'records': len(raw_records), 'pairs': len(raw_records)//2,
                     'archives': archive_count, 'archive_members': member_count,
                     'stdout_envelopes': sum(m['name'].endswith('.stdout.json') for a in archive_evidence for m in a['members']),
                     'timing_files': sum(m['name'].endswith('.timing.json') for a in archive_evidence for m in a['members']),
                     'pid_files': sum(m['name'].endswith('.pid') for a in archive_evidence for m in a['members']),
                     'stderr_files': sum(m['name'].endswith('.stderr.txt') for a in archive_evidence for m in a['members'])},
        'cohorts': cohort_summaries, 'gates': replay_gates,
        'archive_evidence': archive_evidence, 'mismatches': mismatches,
        'limitations': ['This replay validates timing, pairing, result identity, score summaries and declared gates; it does not rerun native workloads or revalidate against the independent ClickBench reference packet.'],
    }
    DEST.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    return report


def score_cohort(records, summary, mismatches):
    replay = {}
    for role in ('control', 'candidate'):
        rows = [r for r in records if r['role'] == role]
        query_ids = sorted({r['query'] for r in rows})
        best = [min(r['engine_execution_seconds'] for r in rows if r['query'] == q) for q in query_ids]
        replay[role] = {'query_total_seconds': sum(best), 'query_ids': query_ids}
        stored = summary['scores']['roles'][role]
        compare_field(mismatches, 'cohort.' + role, 'query_total_seconds', stored['query_total_seconds'], replay[role]['query_total_seconds'])
    return replay


def compute_gates(protocol, records):
    out = []
    policy = protocol['policy']
    for case in protocol['cases']:
        by_role = {role: sorted((r for r in records if r['query'] == case['query'] and r.get('lanes') == case['lanes'] and r['role'] == role), key=lambda r:r['run']) for role in ('control', 'candidate')}
        medians = {role: {metric: statistics.median(r[metric] for r in by_role[role]) for metric in ('engine_execution_seconds','seconds','cpu_seconds','native_peak_rss_bytes')} for role in by_role}
        a, b = medians['control'], medians['candidate']
        savings = [x['engine_execution_seconds'] - y['engine_execution_seconds'] for x,y in zip(by_role['control'],by_role['candidate'])]
        positives = sum(x > 0 for x in savings)
        engine_pass = (b['engine_execution_seconds'] < a['engine_execution_seconds'] and statistics.median(savings) > 0 and positives >= policy['target_positive_pairs']) if case['target'] else b['engine_execution_seconds'] <= a['engine_execution_seconds'] + max(policy['control_engine_increase_fraction']*a['engine_execution_seconds'], policy['control_engine_increase_seconds'])
        cpu_pass = not case['target'] or b['cpu_seconds'] <= a['cpu_seconds']*(1+policy['target_cpu_increase_fraction'])
        rss_pass = b['native_peak_rss_bytes'] <= a['native_peak_rss_bytes'] + max(policy['rss_increase_fraction']*a['native_peak_rss_bytes'], policy['rss_increase_bytes'])
        out.append({**case,'medians':medians,'paired_engine_savings_seconds':savings,'positive_pairs':positives,
                    'engine_passed':engine_pass,'cpu_passed':cpu_pass,'rss_passed':rss_pass,'passed':engine_pass and cpu_pass and rss_pass,
                    'engine_median_improvement_percent':100*(a['engine_execution_seconds']-b['engine_execution_seconds'])/a['engine_execution_seconds']})
    return out


if __name__ == '__main__':
    result = main()
    print(json.dumps({'status':result['status'],'coverage':result['coverage'],'mismatch_count':len(result['mismatches'])}))
