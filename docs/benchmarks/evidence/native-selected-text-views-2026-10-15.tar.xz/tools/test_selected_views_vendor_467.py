"""Run the selected-view provider tests from byte-verified local source copies."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent / 'selected-view-vendor-467'
SOURCE = ROOT / 'vendor/vortex-zstd'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    assert not OUT.exists()
    files = [p for p in SOURCE.rglob('*') if p.is_file() and p.name != 'Cargo.lock']
    assert all(not p.is_symlink() for p in files)
    assert sum(p.stat().st_size for p in files) < 8 << 20
    source = {str(p.relative_to(SOURCE)): sha(p) for p in files}
    OUT.mkdir()
    target = OUT / 'vortex-zstd'
    for path in files:
        dest = target / path.relative_to(SOURCE)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, dest)
    shutil.copy2(ROOT / 'Cargo.lock', target / 'Cargo.lock')
    command = ['cargo', 'test', '--offline', '--manifest-path', str(target / 'Cargo.toml'),
        '--config', 'patch.crates-io.vortex-array.path=' + json.dumps(str(ROOT / 'vendor/vortex-array')),
        '--features', 'vortex-array/table-display', '--lib', 'array::selected::tests::',
        '--', '--test-threads=2']
    save(OUT / 'protocol.json', dict(source=str(SOURCE), files=source,
        root_lock_sha256=sha(ROOT / 'Cargo.lock'), command=command, helper_sha256=sha(Path(__file__))))
    completed = subprocess.run(command, cwd=ROOT)
    unchanged = all(sha(SOURCE / name) == digest and sha(target / name) == digest
                    for name, digest in source.items())
    save(OUT / 'summary.json', dict(status='passed' if completed.returncode == 0 and unchanged else 'failed',
        returncode=completed.returncode, all_source_bytes_unchanged=unchanged,
        standalone_lock_sha256=sha(target / 'Cargo.lock')))
    assert unchanged
    raise SystemExit(completed.returncode)


if __name__ == '__main__':
    main()
