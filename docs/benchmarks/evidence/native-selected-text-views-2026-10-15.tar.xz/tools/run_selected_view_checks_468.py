"""Serial broad acceptance for the frozen selected-view native provider."""
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sources, sha, save

FROZEN = OUT / 'selected-views-467-source.json'
VENDOR = OUT / 'selected-view-vendor-all-468'


def vendor():
    source = ROOT / 'vendor/vortex-zstd'
    assert not VENDOR.exists()
    files = [p for p in source.rglob('*') if p.is_file() and p.name != 'Cargo.lock']
    assert all(not p.is_symlink() for p in files)
    assert sum(p.stat().st_size for p in files) < 8 << 20
    hashes = {str(p.relative_to(source)): sha(p) for p in files}
    target = VENDOR / 'vortex-zstd'
    for path in files:
        dest = target / path.relative_to(source)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, dest)
    shutil.copy2(ROOT / 'Cargo.lock', target / 'Cargo.lock')
    command = ['cargo', 'test', '--offline', '--manifest-path', str(target / 'Cargo.toml'),
        '--config', 'patch.crates-io.vortex-array.path=' + json.dumps(str(ROOT / 'vendor/vortex-array')),
        '--features', 'vortex-array/table-display', '--lib', '--', '--test-threads=2']
    save(VENDOR / 'protocol.json', dict(files=hashes, source=str(source), command=command,
        helper_sha256=sha(__file__), root_lock_sha256=sha(ROOT / 'Cargo.lock')))
    result = subprocess.run(command, cwd=ROOT)
    unchanged = all(sha(source / name) == digest and sha(target / name) == digest
                    for name, digest in hashes.items())
    save(VENDOR / 'summary.json', dict(status='passed' if not result.returncode and unchanged else 'failed',
        returncode=result.returncode, all_source_bytes_unchanged=unchanged,
        standalone_lock_sha256=sha(target / 'Cargo.lock')))
    assert unchanged
    raise SystemExit(result.returncode)


def main():
    frozen = json.loads(FROZEN.read_text())
    assert sources() == frozen['source_sha256']
    checks = [
        ('fmt', 180, ['cargo', 'fmt', '--all', '--', '--check']),
        ('vendor-tests', 900, [sys.executable, '-B', __file__, 'vendor']),
        ('workspace-clippy', 1800, ['cargo', 'clippy', '--workspace', '--all-targets', '--', '-D', 'warnings']),
        ('workspace-tests', 1800, ['cargo', 'test', '--workspace', '--all-targets', '--', '--test-threads=2']),
        ('read-clippy', 1800, ['cargo', 'clippy', '--offline', '--locked', '-p', 'shardloom-vortex',
            '-p', 'shardloom-cli', '--all-targets', '--features', 'vortex-local-primitives', '--', '-D', 'warnings']),
        ('release-clippy', 1800, ['cargo', 'clippy', '--offline', '--locked', '--workspace',
            '--all-targets', '--features', 'shardloom-cli/release-user-surfaces,shardloom-python/python-native',
            '--', '-D', 'warnings']),
        ('native-tests', 3600, ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-vortex',
            '-p', 'shardloom-cli', '--all-targets', '--features',
            'vortex-local-primitives,vortex-write,universal-format-io', '--', '--test-threads=2']),
    ]
    protocol = dict(source_manifest=str(FROZEN), source_manifest_sha256=sha(FROZEN),
        helper_sha256=sha(__file__), guard_sha256=sha(OUT / 'run_guarded.py'), checks=checks)
    save(OUT / 'selected-view-check-protocol-468.json', protocol)
    records = []
    failure = None
    try:
        for label, timeout, command in checks:
            assert sources() == frozen['source_sha256']
            name = 'selected-view-' + label + '-468'
            print(json.dumps(dict(stage=label, status='starting')), flush=True)
            subprocess.run([sys.executable, '-B', str(OUT / 'run_guarded.py'), '--name', name,
                '--timeout', str(timeout), '--', *command], cwd=ROOT, check=True)
            path = OUT / (name + '.json')
            receipt = json.loads(path.read_text())
            log = path.with_suffix('.log')
            assert receipt['status'] == 'passed' and receipt['returncode'] == 0
            assert receipt['process_group_drained'] and receipt['direct_child_reaped']
            assert not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup']
            assert receipt['head'] == frozen['head'] and sha(log) == receipt['log_sha256']
            record = dict(stage=label, receipt=str(path), receipt_sha256=sha(path),
                log=str(log), log_sha256=sha(log), seconds=receipt['seconds'])
            if label.endswith('tests'):
                raw = log.read_text()
                groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', raw)
                assert groups and all(int(row[1]) == int(row[3]) == int(row[4]) == 0 for row in groups)
                ignored = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', raw, re.M)
                assert sum(int(row[2]) for row in groups) == len(ignored)
                if label == 'native-tests':
                    inventory = json.loads((OUT / 'compression-manual-tests-inventory-456.json').read_text())
                    assert sorted(ignored) == sorted((row['test'], row['reason']) for row in inventory['tests'])
                    assert all(sha(ROOT / row['source']) == row['source_sha256'] for row in inventory['tests'])
                    for required in [
                        'native_zstd_sparse_text_filter_constructs_only_selected_views',
                        'native_zstd_sparse_selection_releases_every_failed_allocation_and_preserves_dictionary',
                        'native_zstd_sparse_text_filter_retains_source_metadata_owner',
                    ]:
                        assert re.search(r'^test .*::' + required + r' \.\.\. ok$', raw, re.M), required
                else:
                    assert not ignored
                record['tests'] = dict(passed=sum(int(row[0]) for row in groups), failed=0,
                    ignored=len(ignored), groups=len(groups), ignored_declarations=ignored)
            records.append(record)
            print(json.dumps(dict(stage=label, status='passed', tests=record.get('tests'))), flush=True)
        assert sources() == frozen['source_sha256']
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        save(OUT / 'selected-view-checks-468.json', dict(status='passed' if failure is None else 'failed',
            failure=failure, protocol=protocol, source_files=len(frozen['source_sha256']),
            source_identity_preserved=sources() == frozen['source_sha256'], completed=records))


if __name__ == '__main__':
    vendor() if sys.argv[1:] == ['vendor'] else main()
