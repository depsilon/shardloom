"""Package complete selected-view acceptance and baseline hotspot diagnostics."""
import hashlib
import json
import lzma
from pathlib import Path
import subprocess
import sys
import tarfile

from freeze_native_release_298 import ROOT, OUT, sha, sources, save
from package_selection_acceptance_409 import Members, verify, sha_stream
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

PREFIX = 'native-selected-text-views-2026-10-15'
LOCAL = OUT / 'selected-view-packet-468'
DEST = ROOT / 'docs/benchmarks/evidence'


def bound(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def read(name):
    return json.loads((OUT / name).read_text())


def main():
    frozen = read('selected-views-467-source.json')
    accepted = frozen['source_sha256']
    assert sources() == accepted and len(accepted) == 2259
    checks = read('selected-view-checks-468b.json')
    runtime = read('selected-view-runtime-468.json')
    direct = read('selected-view-direct-tests-468.json')
    public = read('selected-view-public-inspection-468.json')
    artifacts = read('selected-view-native-artifacts-468.json')
    full = read('selected-view-full43-review-468.json')
    replay = read('selected-view-clock-replay-primary-468.json')
    profiles = read('hotspot-diagnostics-primary-review-468.json')
    comparison = read('selected-view-comparison-467/results.json')
    protocol = read('selected-view-comparison-467/protocol.json')
    assert all(x['status'] == 'passed' for x in (checks, runtime, direct, public, artifacts, full, replay, profiles, comparison))
    assert comparison['decision'] == 'retain' and all(row['passed'] for row in comparison['gates'])
    assert len(comparison['records']) == 70 and replay['coverage']['records'] == 70 and not replay['mismatches']
    assert artifacts['source_sha256'] == accepted and checks['source_identity_preserved']
    assert direct['tests'] == 80 and direct['failures'] == direct['errors'] == direct['skipped'] == 0
    assert public['cases'] == runtime['public_cases'] == 757 and public['families'] == 19
    assert public['complete_case_log_records_equal'] and public['frozen_sources_and_binary_unchanged']
    assert full['queries'] == full['calls'] == 43 and full['repeats'] == 1
    assert full['all_values_schemas_and_clocks_reopened'] and full['original_input_and_sources_unchanged']
    counts = {row['stage']: row['tests'] for row in checks['completed'] if 'tests' in row}
    assert len(checks['completed']) == 7
    assert counts['workspace-tests']['passed'] == 3219 and counts['workspace-tests']['ignored'] == 0
    assert counts['native-tests']['passed'] == 4223 and counts['native-tests']['ignored'] == 29
    assert counts['vendor-tests']['passed'] == 61 and counts['vendor-tests']['ignored'] == 0
    for row in checks['completed']:
        assert sha(row['receipt']) == row['receipt_sha256'] and sha(row['log']) == row['log_sha256']
    assert sha(OUT / 'selected-view-frozen-design-468.md') == protocol['design']['sha256']

    members, exclusions = Members(), []
    def add(path, prefix='evidence', role='closed acceptance, original failure history or frozen identity'):
        path = Path(path)
        uat = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
        parent = next((root for root in (ROOT, OUT, uat) if path.is_relative_to(root)), path.parent)
        relative = path.relative_to(parent).as_posix()
        members.add(path, prefix + '/' + relative, prefix, parent, role)
    for path in sorted(OUT.glob('selected-view*')):
        if path.is_file() and path.suffix in {'.json', '.log', '.md'}:
            add(path)
    for name in ('selected-view-red-466', 'selected-view-first-green-466', 'selected-view-green-466b'):
        for suffix in ('.json', '.log'):
            add(OUT / (name + suffix))
    for name in ('hotspot-diagnostics-465.json', 'hotspot-diagnostics-465.log',
                 'hotspot-diagnostics-primary-review-468.json', 'hotspot-sample-inventory-466.json',
                 'q23-accessor-source-inventory-465.json', 'query-timing-manual-tests-inventory-462.json',
                 'compression-manual-tests-inventory-456.json', 'query-timing-native-artifacts-461.json',
                 'query-timing-460-artifacts.json', 'native-release-source-timing460.json'):
        add(OUT / name)
    for pattern in ('*selected*46*.py', 'verify_hotspot_diagnostics_468.py', 'profile_hotspots_465.py'):
        for path in sorted(OUT.glob(pattern)):
            add(path, 'tools', 'reproduction or verification helper')
    for name in ('freeze_native_release_298.py', 'freeze_query_cli_368.py', 'run_guarded.py',
                 'run_query_timing_runtime_461.py', 'run_compression_full43_457.py',
                 'package_selection_acceptance_409.py'):
        add(OUT / name, 'tools', 'shared reproduction helper')
    for folder, prefix, omit in [
        (OUT / 'selected-view-comparison-467', 'comparison', False),
        (OUT / 'hotspot-profiles-465', 'diagnostics', False),
        (OUT / 'selected-view-public-468', 'public', True),
        (Path(full['summary']['path']).parent, 'full43', False),
    ]:
        members.tree(folder, prefix, prefix, 'complete local evidence', exclusions, omit_outputs=omit)
    for cohort in comparison['cohorts']:
        folder = Path(cohort['summary']['path']).parent
        assert bound(folder / 'summary.json') == cohort['summary']
        members.tree(folder, 'pairs/' + folder.name, 'pairs', 'all paired raw calls and archives', exclusions)
    for name in ('selected-view-vendor-467', 'selected-view-vendor-467b', 'selected-view-vendor-all-468'):
        for basename in ('protocol.json', 'summary.json'):
            add(OUT / name / basename, 'vendor-runs')
    for key in ('artifacts', 'value_files', 'envelopes', 'pressure_files'):
        for item in public[key]:
            verify(Path(item['path']), item['sha256'], item['bytes'])
    add(public['complete_case_set_comparison']['path'], 'reference', 'unchanged complete public case inventory')
    full_admission = json.loads(Path(full['admission']['path']).read_text())
    for item in full_admission['schema_sources']:
        verify(Path(item['path']), item['sha256'], item['bytes'])
        add(item['path'], 'reference', 'precomparison expected schema')
    profile_summary = read('hotspot-profiles-465/summary.json')
    add(profile_summary['baseline_summary'], 'reference', 'accepted unprofiled Full43 baseline')
    reference_path = Path(protocol['reference']['path'])
    verify(reference_path, protocol['reference']['sha256'], protocol['reference']['bytes'])
    members.add(reference_path, 'reference/' + reference_path.name, 'reference', reference_path.parent,
                'retained complete query reference values')
    add(ROOT / 'benchmarks/clickbench/queries.sql', 'reference', 'complete query text')
    for role in ('cli', 'binding'):
        item = artifacts[role]
        verify(Path(item['path']), item['sha256'], item['bytes'])
        exclusions.append(dict(**item, reason='frozen native executable; bulk payload omitted'))
    exclusions.append(dict(**protocol['input'], reason='resident full native input; full pre/post hash retained in admission'))
    for role in ('control', 'candidate'):
        for key in ('manifest', 'build_receipt', 'build_log'):
            item = protocol['identities'][role][key]
            verify(Path(item['path']), item['sha256'], item['bytes'])
            add(item['path'], 'builds')
    changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT, text=True).splitlines()
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=ROOT, text=True).splitlines()
    overlay = sorted(set(changed + untracked) & set(accepted))
    assert len(overlay) == 5
    for name in overlay:
        members.add(ROOT / name, 'source-overlay/' + name, 'repository', ROOT,
                    'complete candidate source overlay', accepted[name])
    add(ROOT / '.github/workflows/ci.yml', 'source-overlay', 'hosted selected-view test wiring')
    for name in ('native-compression-hosted-2026-10-15.json', 'native-query-timing-uat-2026-10-15.json'):
        add(DEST / name, 'companion-indices', 'accepted baseline provenance')
    require_local_path(LOCAL, Path.home(), sys.platform)
    assert not LOCAL.exists()
    ordered = sorted(members.paths.values(), key=lambda item: item.name)
    raw_size = sum(item.size for item in ordered)
    assert raw_size <= 256 * MIB
    storage = check_budgets(OUT, LOCAL, OUT / 'logs', min_free_bytes=12*GIB,
        reserve_bytes=raw_size + 64*MIB, max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
    LOCAL.mkdir()
    archive_path = LOCAL / (PREFIX + '.tar.xz')
    with archive_path.open('xb') as stream:
        with tarfile.open(fileobj=stream, mode='w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
            for item in ordered:
                verify(item.path, item.digest, item.size)
                info = tarfile.TarInfo(item.name)
                info.size, info.mode, info.mtime = item.size, 0o644, 0
                with item.path.open('rb') as source:
                    archive.addfile(info, source)
    seen = set()
    with tarfile.open(archive_path, mode='r|xz') as archive:
        for entry in archive:
            assert entry.isfile() and entry.name in members.names and entry.name not in seen
            item = members.paths[members.names[entry.name]]
            with archive.extractfile(entry) as stream:
                assert sha_stream(stream) == (item.size, item.digest)
            seen.add(entry.name)
    assert seen == set(members.names) and sources() == accepted
    for item in ordered:
        verify(item.path, item.digest, item.size)
    manifest = dict(status='passed', base_commit=frozen['head'], source_files=len(accepted),
        source_manifest=bound(OUT / 'selected-views-467-source.json'), archive=bound(archive_path),
        source_overlay=overlay, members=[dict(path=str(item.path), archive_path=item.name,
            bytes=item.size, sha256=item.digest, roles=item.roles) for item in ordered],
        member_count=len(ordered), raw_bytes=raw_size, all_members_reopened=True, storage=storage,
        exclusions=exclusions, acceptance=dict(workspace_tests=3219, native_tests=4223,
            native_manual_platform_exclusions=29, vendor_tests=61, direct_tests=80,
            public_cases=757, public_families=19, public_expected_rows=public['explicit_expected_value_rows'],
            public_pressure_rows=public['pressure_rows'], complete_queries=43,
            complete_query_rows=full['complete_rows'], paired_calls=70, diagnostic_profiles=5),
        decision='retain', gates=comparison['gates'], full43_timing_totals=full['timing_totals'],
        profile_timings_used_for_retention=False, source_identity_preserved=True,
        hosted_integration_complete=False, installed_wheel_proof=False, publication_attempted=False,
        failure_history=dict(baseline_regression='Old filter allocates retained-row and gathered views; selected-only allocation regression fails as intended.',
            native_first_attempt='One allocation-count expectation still named six stages; selected-only view construction correctly removes one. Updated to five and reran all fourteen filter tests.',
            vendor_first_attempt='Test compilation lacked the allocator-extension import; corrected and reran all six new tests, then all 61 provider tests.',
            full43_preflight='The temporary wrapper copied an obsolete retained-log ceiling and stopped before any native query. Corrected it to the maintained policy already used by the accepted baseline; no logs or datasets were removed.',
            broad_postcheck='Runner named predecessor manual-exclusion inventory. All seven commands passed; current literal declarations and completed receipts were independently reverified without rerunning.'),
        limitations='Finite local candidate acceptance with uncontrolled OS cache. Q23 improves in this comparison; all four other parallel controls have slower medians within the predeclared limits. Dense decoding and compressed frame bytes are unchanged. No general speedup, whole-process RSS cap, all-platform or release claim.')
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    packed = lzma.compress(manifest_bytes, preset=6)
    assert lzma.decompress(packed) == manifest_bytes
    manifest_path = LOCAL / (PREFIX + '.manifest.json.xz')
    with manifest_path.open('xb') as stream:
        stream.write(packed)
    index = dict(schema_version='shardloom.selected_text_views_acceptance.v1', status='passed_local',
        base_commit=frozen['head'], source_files=len(accepted), member_count=len(seen),
        all_members_reopened=True, raw_bytes=raw_size, acceptance=manifest['acceptance'],
        decision='retain', gates=comparison['gates'], full43_timing_totals=full['timing_totals'],
        archive=dict(file=archive_path.name, bytes=archive_path.stat().st_size, sha256=sha(archive_path)),
        manifest=dict(file=manifest_path.name, bytes=manifest_path.stat().st_size, sha256=sha(manifest_path),
            raw_sha256=hashlib.sha256(manifest_bytes).hexdigest()),
        source_manifest=manifest['source_manifest'], profile_timings_used_for_retention=False,
        hosted_integration_complete=False, installed_wheel_proof=False, publication_attempted=False,
        limitations=manifest['limitations'])
    for path in (archive_path, manifest_path):
        target = DEST / path.name
        assert not target.exists()
        with target.open('xb') as stream:
            stream.write(path.read_bytes())
        assert sha(target) == sha(path)
    save(DEST / (PREFIX + '.json'), index)
    save(LOCAL / 'verification.json', dict(status='passed', member_count=len(seen),
        all_members_reopened=True, helper=bound(__file__), archive=bound(archive_path),
        manifest=bound(manifest_path), index=bound(DEST / (PREFIX + '.json'))))
    print(json.dumps(dict(status='passed', members=len(seen), raw_bytes=raw_size,
        archive_bytes=archive_path.stat().st_size, destination=str(DEST / (PREFIX + '.json')))))


if __name__ == '__main__':
    main()
