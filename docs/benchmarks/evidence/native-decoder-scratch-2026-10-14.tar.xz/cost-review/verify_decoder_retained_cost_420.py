"""Verify the closed revised cost inventory and independently recompute its decision."""
import collections
import hashlib
import itertools
import json
import math
from pathlib import Path
import re
import statistics

OUT = Path(__file__).resolve().parent
DEST = OUT / 'decoder-cost-418'


def read(path):
    return json.loads(Path(path).read_text())


def bound(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    inventory_path = OUT / 'decoder-retained-cost-inventory-420.json'
    inventory = read(inventory_path)
    original_path = OUT / 'decoder-retained-cost-inventory-420-worker-original.json'
    original = read(original_path)
    originals = {row['path']: row for row in original['members']}
    revised = {row['path']: row for row in inventory['members']}
    added_paths = {str(DEST / order / 'before.json') for order in ('forward', 'reverse')}
    assert revised.keys() - originals.keys() == added_paths
    assert all(revised[path] == row for path, row in originals.items())
    original['members'] = inventory['members']
    original['coverage']['selected_unique_members'] += 2
    original['coverage']['selected_bytes'] += 8194
    assert original == inventory
    assert inventory['status'] == 'closed_cost_cohort_inventory_only'
    assert inventory['wider_acceptance_complete'] is False
    selected = {Path(row['path']): row for row in inventory['members']}
    excluded = {Path(row['path']): row for row in inventory['exclusions']}
    assert len(selected) == len(inventory['members']) == 7813
    assert len({row['archive_path'] for row in selected.values()}) == len(selected)
    assert len(excluded) == len(inventory['exclusions']) == 2238 and not selected.keys() & excluded.keys()
    assert sum(row['bytes'] for row in selected.values()) == inventory['coverage']['selected_bytes'] == 22611934
    for path, row in selected.items():
        assert path.is_file() and not path.is_symlink()
        assert bound(path) == {key: row[key] for key in ('path', 'bytes', 'sha256')}
        target = Path(row['archive_path'])
        assert not target.is_absolute() and '..' not in target.parts
        assert 'decoder-cost-416' not in str(path)
    actual = {path for path in DEST.rglob('*') if path.is_file()}
    assert all(not path.is_symlink() for path in DEST.rglob('*'))
    assert actual == (actual & selected.keys()) | (actual & excluded.keys())
    source = read(DEST / 'source.json')
    source_identity = bound(DEST / 'source.json')
    contract = read(DEST / 'contract.json')
    assert bound(DEST / 'contract.json')['sha256'] == source['contract_sha256']
    assert (DEST / 'contract.json').read_bytes() == (OUT / 'decoder-cost-416/contract.json').read_bytes()
    assert contract['relative_ratio_threshold'] == 1.10 and contract['absolute_added_ns_threshold'] == 5000
    for name, digest in source['helpers'].items():
        assert (OUT / name) in selected and bound(OUT / name)['sha256'] == digest
    for row in selected.values():
        if row['category'] in ('candidate_changed_source_snapshot', 'baseline_overlay_source_snapshot'):
            variant = 'candidate' if row['category'].startswith('candidate') else 'baseline'
            assert row['sha256'] == source[variant + '_source_sha256'][row['source_path']]
    changed = {row['source_path'] for row in selected.values() if row['category'] == 'candidate_changed_source_snapshot'}
    assert changed == set(source['changed_source_paths']) and len(changed) == 8
    for role in ('baseline', 'candidate'):
        build = read(DEST / (role + '-build.json'))
        assert build['status'] == 'passed' and build['source_manifest_sha256'] == source_identity['sha256']
        for key in ('build_receipt', 'build_log'):
            item = build[key]
            assert Path(item['path']) in selected and bound(item['path']) == item
        receipt = read(build['build_receipt']['path'])
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert receipt['log_sha256'] == build['build_log']['sha256']
        omitted = excluded[Path(build['binary']['path'])]
        assert omitted['bytes'] == build['binary']['bytes']
        assert omitted['sha256_from_build_manifest'] == build['binary']['sha256']
    decision = read(DEST / 'decision.json')
    assert decision['status'] == 'retained_for_resource_correctness_pending_wider_acceptance'
    assert decision['forward'] == read(DEST / 'screen.json')
    orders, reference_hashes = {}, {}
    cells = list(itertools.product(contract['shapes'], contract['rows'], contract['chunks']))
    for order in ('forward', 'reverse'):
        run = read(DEST / order / 'summary.json')
        before = read(DEST / order / 'before.json')
        assert before['order'] == order and before['status'] == 'running'
        assert before['builds'] == run['builds']
        assert run['status'] == 'passed' and run['source_and_binaries_unchanged']
        assert run['source_manifest_sha256'] == source_identity['sha256']
        assert run['contract_sha256'] == source['contract_sha256']
        assert len(run['samples']) == 1944 and len(decision[order]['cells']) == 108
        groups, logs = collections.defaultdict(lambda: collections.defaultdict(list)), set()
        for index, row in enumerate(run['samples']):
            sample_path = DEST / order / f'sample-{index:04}.json'
            assert sample_path in selected and read(sample_path) == row
            log_path = Path(row['log']['path'])
            assert log_path in selected and bound(log_path) == row['log'] and log_path not in logs
            logs.add(log_path)
            log = log_path.read_text()
            sample, = [json.loads(line.split('SHARDLOOM_DECODER_COST_SAMPLE=', 1)[1])
                for line in log.splitlines() if 'SHARDLOOM_DECODER_COST_SAMPLE=' in line]
            assert sample == row['sample'] and 'test result: ok. 1 passed; 0 failed;' in log
            assert row['returncode'] == 0 and row['observations']
            cell_index, remainder = divmod(index, contract['pairs_per_cell'] * 2)
            pair, position = divmod(remainder, 2)
            roles = ('candidate', 'baseline') if (cell_index + pair + int(order == 'reverse')) % 2 else ('baseline', 'candidate')
            assert (row['index'], row['pair'], row['order_position'], row['variant']) == (index, pair, position, roles[position])
            assert row['command'][2] == run['builds'][row['variant']]['binary']['path']
            key = (sample['shape'], sample['rows'], sample['chunks'])
            assert key == cells[cell_index]
            assert sample['iterations'] == contract['iterations_per_sample_by_rows'][str(sample['rows'])]
            assert sample['warmup'] == contract['warmup_calls'] and sample['grant'] == contract['grant_bytes']
            assert sample['batch_nanos'] > 0 and sample['reserved_bytes_after'] == 0
            assert sample['complete_reference_checks'] == 2 and sample['complete_result_lifecycle']
            assert 0 <= sample['peak_reserved_bytes'] <= contract['grant_bytes']
            identity = tuple(sample[k] for k in ('input_sha256', 'reference_sha256'))
            assert all(re.fullmatch('[0-9a-f]{64}', digest) for digest in identity)
            assert reference_hashes.setdefault(key, identity) == identity
            groups[key][row['variant']].append(sample['batch_nanos'] / sample['iterations'])
        computed = []
        for key, reported in zip(cells, decision[order]['cells'], strict=True):
            assert tuple(reported[k] for k in ('shape', 'rows', 'chunks')) == key
            values = groups[key]
            assert all(len(values[role]) == 9 for role in ('baseline', 'candidate'))
            a, b = (statistics.median(values[role]) for role in ('baseline', 'candidate'))
            ratio, added = b / a, b - a
            for field, value in (('baseline_median_ns', a), ('candidate_median_ns', b), ('median_ratio', ratio), ('median_added_ns', added)):
                assert math.isclose(reported[field], value, rel_tol=1e-14, abs_tol=1e-14)
            trigger = ratio > contract['relative_ratio_threshold']
            material = trigger and added > contract['absolute_added_ns_threshold']
            assert reported['confirmation_trigger'] == trigger and reported['material_regression'] == material
            computed.append(dict(shape=key[0], rows=key[1], chunks=key[2], material=material, trigger=trigger))
        outer_path = OUT / f'native-decoder-cost-{order}-418.json'
        outer = read(outer_path)
        assert outer['status'] == 'passed' and outer['returncode'] == 0
        assert outer['process_group_drained'] and outer['direct_child_reaped']
        assert bound(outer_path.with_suffix('.log'))['sha256'] == outer['log_sha256']
        orders[order] = dict(cells=len(groups), samples=len(run['samples']),
            trigger_cells=sum(row['trigger'] for row in computed),
            material_cells=sum(row['material'] for row in computed),
            supervised_seconds=outer['seconds'])
    assert not decision['repeated_material_regressions']
    assert orders['forward']['material_cells'] == orders['reverse']['material_cells'] == 0
    result = dict(status='passed_inventory_and_independent_cost_recomputation',
        inventory=bound(inventory_path), original_worker_inventory=bound(original_path),
        added_missing_setup_records=2, verifier=bound(__file__), source_manifest=source_identity,
        decision=bound(DEST / 'decision.json'), selected_members=len(selected),
        selected_bytes=inventory['coverage']['selected_bytes'], orders=orders,
        complete_sample_log_pairs=3888, unchanged_contract_from_rejected_attempt=True,
        actual_cost_tree_covered_by_selection_and_explicit_exclusions=True,
        binary_payloads_rehashed_here=False, wider_acceptance_complete=False,
        performance_claim_allowed=False)
    with (OUT / 'decoder-retained-cost-primary-420.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
