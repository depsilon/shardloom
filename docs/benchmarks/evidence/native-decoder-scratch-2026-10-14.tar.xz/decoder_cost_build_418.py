"""Freeze both sources and build accepted-baseline/candidate test executables."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

import decoder_cost_common_418 as c


def freeze():
    assert c.head() == c.BASE
    c.storage(c.DEST)
    current = c.sources()
    names = sorted(current)
    # One exact Git object read per tracked source, in a single batch process.
    raw = subprocess.check_output(['git', 'cat-file', '--batch'], cwd=c.ROOT,
        input=''.join(c.BASE + ':' + name + '\n' for name in names).encode())
    offset, accepted, baseline_bytes = 0, {}, {}
    for name in names:
        end = raw.index(b'\n', offset)
        header = raw[offset:end].split()
        offset = end + 1
        if header[-1] == b'missing':
            continue
        assert header[1] == b'blob'
        count = int(header[2])
        value = raw[offset:offset + count]
        offset += count
        assert raw[offset:offset + 1] == b'\n'
        offset += 1
        accepted[name] = hashlib.sha256(value).hexdigest()
        if name in c.OVERLAY:
            baseline_bytes[name] = value
    assert offset == len(raw)
    changed = {name for name in names if current[name] != accepted.get(name)}
    assert changed == set(c.OVERLAY + c.HARNESS + c.NEW_RUNTIME), changed
    # In baseline builds the only new production module has no inclusion hook:
    # restoring fixed_width_builder removes its mod scratch declaration.
    assert b'native_provider_decoder_scratch' not in baseline_bytes[c.OVERLAY[1]]
    baseline = dict(current, **{name: accepted[name] for name in c.OVERLAY})
    snapshots = c.DEST / 'source-files'
    snapshots.mkdir(exist_ok=False)
    for name, digest in current.items():
        target = snapshots / 'candidate' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with (c.ROOT / name).open('rb') as source, target.open('xb') as sink:
            shutil.copyfileobj(source, sink)
        assert c.sha(target) == digest
    for name, value in baseline_bytes.items():
        target = snapshots / 'baseline-overlay' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as sink:
            sink.write(value)
        assert c.sha(target) == accepted[name]
    assert current == c.sources()
    result = dict(status='frozen_before_release_build_and_timing', head=c.head(),
        candidate_source_sha256=current, baseline_source_sha256=baseline,
        accepted_head_source_sha256=accepted, changed_source_paths=sorted(changed),
        source_snapshots=str(snapshots), baseline_overlay=list(c.OVERLAY),
        common_test_only_changes=list(c.HARNESS),
        unreferenced_in_baseline=list(c.NEW_RUNTIME),
        contract_sha256=c.sha(c.DEST / 'contract.json'),
        helpers={name: c.sha(c.OUT / name) for name in c.HELPERS},
        working_tree=subprocess.check_output(['git', 'status', '--porcelain'], cwd=c.ROOT, text=True),
        tracked_patch=subprocess.check_output(['git', 'diff', '--binary', 'HEAD'], cwd=c.ROOT, text=True),
        rustc=subprocess.check_output(['/Users/dylan/.cargo/bin/rustup', 'run', '1.99.0', 'rustc', '-Vv'], text=True))
    c.save(c.DEST / 'source.json', result)
    print(json.dumps(dict(status=result['status'], files=len(current), changed=sorted(changed))), flush=True)


def build(variant):
    record = c.frozen()
    baseline = variant == 'baseline'
    changed = []
    restored = []
    failure = None
    label = 'native-decoder-' + variant + '-build-418'
    result_path = c.DEST / (variant + '-build.json')
    assert not result_path.exists()
    try:
        if baseline:
            for name in c.OVERLAY:
                path = c.ROOT / name
                assert c.sha(path) == record['candidate_source_sha256'][name]
                replacement = Path(record['source_snapshots']) / 'baseline-overlay' / name
                assert c.sha(replacement) == record['baseline_source_sha256'][name]
                path.write_bytes(replacement.read_bytes())
                changed.append(name)
        c.frozen(variant)
        command = [sys.executable, '-B', str(c.OUT / 'run_guarded.py'), '--name', label,
            '--timeout', '1800', '--', 'cargo', 'test', '--offline', '--locked', '--release',
            '-p', 'shardloom-vortex', '--features', 'release-user-surfaces', '--lib',
            '--no-run', '--message-format=json-render-diagnostics']
        subprocess.run(command, cwd=c.ROOT, check=True)
        c.frozen(variant)
        receipt_path = c.OUT / (label + '.json')
        receipt = c.read(receipt_path)
        log = receipt_path.with_suffix('.log')
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert receipt['log_sha256'] == c.sha(log) and receipt['head'] == c.BASE
        artifacts = [json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
        native, = [item for item in artifacts if item.get('reason') == 'compiler-artifact'
            and item.get('target', {}).get('name') == 'shardloom_vortex'
            and item.get('executable') and item['profile']['test']]
        assert native['profile']['opt_level'] == '3'
        binary = Path(native['executable'])
        assert binary.parent == Path(receipt['environment']['CARGO_TARGET_DIR']) / 'release/deps'
        assert not binary.is_symlink()
        c.storage(c.DEST, binary.stat().st_size + (128 << 20))
        target = c.DEST / (variant + '-tests')
        digest = c.sha(binary)
        with binary.open('rb') as source, target.open('xb') as sink:
            shutil.copyfileobj(source, sink)
        target.chmod(0o555)
        assert c.sha(binary) == c.sha(target) == digest
        c.frozen(variant)
        result = dict(status='passed', variant=variant, head=c.BASE,
            source_identity_sha256=c.identity(record[variant + '_source_sha256']),
            source_manifest_sha256=c.sha(c.DEST / 'source.json'),
            binary=c.bound(target), build_receipt=c.bound(receipt_path), build_log=c.bound(log),
            command=receipt['command'], environment=receipt['environment'])
    except BaseException as error:
        failure = f'{type(error).__name__}: {error}'
        raise
    finally:
        for name in reversed(changed):
            path = c.ROOT / name
            assert c.sha(path) == record['baseline_source_sha256'][name], 'concurrent overlay edit; original snapshot retained'
            candidate = Path(record['source_snapshots']) / 'candidate' / name
            assert c.sha(candidate) == record['candidate_source_sha256'][name]
            path.write_bytes(candidate.read_bytes())
            assert c.sha(path) == record['candidate_source_sha256'][name]
            restored.append(name)
        source_restored = c.sources() == record['candidate_source_sha256']
        c.save(c.DEST / (variant + '-restoration.json'), dict(status='passed' if source_restored else 'failed',
            overlay_applied=changed, restored=restored, candidate_source_unchanged=source_restored, failure=failure))
        assert source_restored
    c.save(result_path, result)
    print(json.dumps(dict(status='passed', variant=variant, binary=result['binary'], source_restored=True)), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=('freeze', 'baseline', 'candidate'))
    args = parser.parse_args()
    freeze() if args.stage == 'freeze' else build(args.stage)
