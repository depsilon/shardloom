"""Validate all samples and apply the decoder rule frozen before timing."""
import argparse
import itertools
import json
from pathlib import Path
import re
import statistics

import decoder_cost_common_418 as c


def analyze(order):
    c.frozen()
    contract = c.contract()
    summary_path = c.DEST / order / 'summary.json'
    run = c.read(summary_path)
    outer = c.read(c.OUT / f'native-decoder-cost-{order}-418.json')
    assert outer['status'] == run['status'] == 'passed'
    assert outer['returncode'] == 0 and outer['process_group_drained'] and outer['direct_child_reaped']
    outer_log = c.OUT / f'native-decoder-cost-{order}-418.log'
    assert outer['log_sha256'] == c.sha(outer_log)
    assert run['order'] == order and run['source_and_binaries_unchanged']
    assert run['source_manifest_sha256'] == c.sha(c.DEST / 'source.json')
    assert run['contract_sha256'] == c.sha(c.DEST / 'contract.json')
    assert run['builds'] == {key: c.build(key) for key in ('baseline', 'candidate')}
    cells = list(itertools.product(contract['shapes'], contract['rows'], contract['chunks']))
    pairs = contract['pairs_per_cell']
    assert len(run['samples']) == len(cells) * pairs * 2 == 1944
    results = []
    for cell_index, (shape, rows, chunks) in enumerate(cells):
        values = dict(baseline=[], candidate=[])
        peaks = dict(baseline=set(), candidate=set())
        identities = set()
        for pair in range(pairs):
            variants = ['baseline', 'candidate']
            if (cell_index + pair + int(order == 'reverse')) % 2:
                variants.reverse()
            for position, variant in enumerate(variants):
                index = cell_index * pairs * 2 + pair * 2 + position
                record = run['samples'][index]
                assert (record['index'], record['pair'], record['order_position'], record['variant']) == (index, pair, position, variant)
                assert record == c.read(c.DEST / order / f'sample-{index:04}.json')
                assert c.sha(record['log']['path']) == record['log']['sha256']
                log = Path(record['log']['path']).read_text()
                sample, = [json.loads(line.split('SHARDLOOM_DECODER_COST_SAMPLE=', 1)[1])
                    for line in log.splitlines() if 'SHARDLOOM_DECODER_COST_SAMPLE=' in line]
                assert record['sample'] == sample and 'test result: ok. 1 passed; 0 failed;' in log
                assert (sample['shape'], sample['rows'], sample['chunks']) == (shape, rows, chunks)
                assert sample['iterations'] == contract['iterations_per_sample_by_rows'][str(rows)]
                assert sample['warmup'] == contract['warmup_calls'] and sample['grant'] == contract['grant_bytes']
                assert sample['batch_nanos'] > 0 and sample['reserved_bytes_after'] == 0
                assert sample['complete_reference_checks'] == 2 and sample['complete_result_lifecycle']
                assert 0 <= sample['peak_reserved_bytes'] <= contract['grant_bytes']
                assert all(re.fullmatch('[0-9a-f]{64}', sample[key]) for key in ('input_sha256', 'reference_sha256'))
                assert record['returncode'] == 0 and record['observations']
                assert record['command'][2] == run['builds'][variant]['binary']['path']
                rss, = re.findall(r'^\s*(\d+)\s+maximum resident set size\s*$', log, re.M)
                cpu, = re.findall(r'^\s*([0-9.]+) real\s+([0-9.]+) user\s+([0-9.]+) sys\s*$', log, re.M)
                assert record['process_metrics'] == dict(real_seconds=float(cpu[0]), user_seconds=float(cpu[1]),
                    sys_seconds=float(cpu[2]), max_rss_bytes=int(rss))
                identities.add((sample['input_sha256'], sample['reference_sha256']))
                values[variant].append(sample['batch_nanos'] / sample['iterations'])
                peaks[variant].add(sample['peak_reserved_bytes'])
        hashes, = identities
        before, after = (statistics.median(values[key]) for key in ('baseline', 'candidate'))
        ratio, added = after / before, after - before
        results.append(dict(shape=shape, rows=rows, chunks=chunks, input_sha256=hashes[0],
            reference_sha256=hashes[1], nanoseconds_per_call=values,
            baseline_median_ns=before, candidate_median_ns=after, median_ratio=ratio, median_added_ns=added,
            peak_reserved_bytes={key: sorted(value) for key, value in peaks.items()},
            confirmation_trigger=ratio > contract['relative_ratio_threshold'],
            material_regression=ratio > contract['relative_ratio_threshold'] and added > contract['absolute_added_ns_threshold']))
    return dict(status='complete_valid_screen', order=order, cells=results, samples=len(run['samples']),
        summary=c.bound(summary_path), outer_receipt=c.bound(c.OUT / f'native-decoder-cost-{order}-418.json'),
        source_manifest_sha256=run['source_manifest_sha256'], contract_sha256=run['contract_sha256'],
        confirmation_required=any(row['confirmation_trigger'] for row in results),
        material_regressions=[row for row in results if row['material_regression']],
        performance_claim_allowed=False)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=('screen', 'decision'))
    args = parser.parse_args()
    forward = analyze('forward')
    if args.stage == 'screen':
        result = forward
    else:
        reverse = analyze('reverse') if forward['confirmation_required'] else None
        repeated = []
        if reverse:
            for first, second in zip(forward['cells'], reverse['cells'], strict=True):
                assert all(first[key] == second[key] for key in ('shape', 'rows', 'chunks', 'input_sha256', 'reference_sha256'))
                if first['material_regression'] and second['material_regression']:
                    repeated.append(dict(forward=first, reverse=second))
        result = dict(status='revision_required' if repeated else 'retained_for_resource_correctness_pending_wider_acceptance',
            forward=forward, reverse=reverse, repeated_material_regressions=repeated,
            interpretation='Marginal comparison against accepted production code with identical fixture and verifier; finite native array lifecycle only, not complete public query or whole-process timing.',
            performance_claim_allowed=False)
    c.save(c.DEST / (args.stage + '.json'), result)
    print(json.dumps(dict(status=result['status'], cells=len(forward['cells']),
        confirmation_required=forward['confirmation_required'],
        trigger_cells=sum(row['confirmation_trigger'] for row in forward['cells']),
        material_cells=[(row['shape'], row['rows'], row['chunks']) for row in forward['material_regressions']],
        repeated_material_cells=len(result.get('repeated_material_regressions', [])))), flush=True)
