"""Sequential externally paired complete decoder lifecycles under an outer guard."""
import argparse
import itertools
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import time

import decoder_cost_common_418 as c


def observation(root_pid):
    rows = [line.split() for line in subprocess.check_output(
        ['/bin/ps', '-axo', 'pid=,ppid=,%cpu=,rss='], text=True).splitlines()]
    selected = {root_pid}
    for _ in range(8):
        expanded = selected | {int(pid) for pid, parent, _, _ in rows if int(parent) in selected}
        if expanded == selected:
            break
        selected = expanded
    return dict(monotonic=time.monotonic(), host_load=os.getloadavg(),
        owned_processes=[dict(pid=int(pid), cpu_percent=float(cpu), rss_kib=int(rss))
            for pid, _, cpu, rss in rows if int(pid) in selected])


def stat_identity(path):
    value = Path(path).stat()
    return value.st_size, value.st_mtime_ns, value.st_ino


def sample(run_dir, index, shape, rows, chunks, pair, position, variant, binary):
    log = run_dir / f'{index:04}-{shape}-{rows}-{chunks}-{pair}-{variant}.log'
    environment = dict(os.environ, SHARDLOOM_DECODER_COST_SCREEN='1',
        SHARDLOOM_DECODER_COST_SHAPE=shape, SHARDLOOM_DECODER_COST_ROWS=str(rows),
        SHARDLOOM_DECODER_COST_CHUNKS=str(chunks))
    command = ['/usr/bin/time', '-l', binary, '--ignored', '--exact', c.TEST,
               '--test-threads=1', '--nocapture']
    observations = []
    started = time.monotonic()
    with log.open('xb') as stream:
        process = subprocess.Popen(command, cwd=c.ROOT, env=environment, stdout=stream, stderr=subprocess.STDOUT)
        observations.append(observation(process.pid))
        while process.poll() is None:
            assert log.stat().st_size <= 256 << 10, 'per-process log ceiling exceeded'
            if time.monotonic() - started > 60:
                process.terminate()
                raise TimeoutError('sample exceeded 60 seconds; outer supervisor drains the process group')
            try:
                process.wait(timeout=0.2)
            except subprocess.TimeoutExpired:
                observations.append(observation(process.pid))
        code = process.wait()
    assert log.stat().st_size <= 256 << 10, 'per-process log ceiling exceeded at exit'
    assert code == 0, (log, code)
    text = log.read_text()
    assert 'test result: ok. 1 passed; 0 failed;' in text
    result, = [json.loads(line.split('SHARDLOOM_DECODER_COST_SAMPLE=', 1)[1])
        for line in text.splitlines() if 'SHARDLOOM_DECODER_COST_SAMPLE=' in line]
    assert (result['shape'], result['rows'], result['chunks']) == (shape, rows, chunks)
    assert result['reserved_bytes_after'] == 0 and result['complete_reference_checks'] == 2
    assert result['complete_result_lifecycle'] and result['batch_nanos'] > 0
    rss, = re.findall(r'^\s*(\d+)\s+maximum resident set size\s*$', text, re.M)
    cpu, = re.findall(r'^\s*([0-9.]+) real\s+([0-9.]+) user\s+([0-9.]+) sys\s*$', text, re.M)
    return dict(index=index, pair=pair, order_position=position, variant=variant,
        command=command, sample=result, log=c.bound(log), pid=process.pid, returncode=code,
        supervised_seconds=time.monotonic() - started, observations=observations,
        process_metrics=dict(real_seconds=float(cpu[0]), user_seconds=float(cpu[1]),
            sys_seconds=float(cpu[2]), max_rss_bytes=int(rss)))


def run(order):
    source = c.frozen()
    contract = c.contract()
    builds = {variant: c.build(variant) for variant in ('baseline', 'candidate')}
    identities = {variant: stat_identity(value['binary']['path']) for variant, value in builds.items()}
    run_dir = c.DEST / order
    run_dir.mkdir(exist_ok=False)
    host = dict(platform=platform.platform(), machine=platform.machine(), logical_cpus=os.cpu_count(),
        physical_memory_bytes=int(subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.memsize'], text=True)))
    record = dict(status='running', order=order, host=host, builds=builds,
        source_manifest_sha256=c.sha(c.DEST / 'source.json'),
        contract_sha256=c.sha(c.DEST / 'contract.json'), samples=[],
        cache_state='Eight warmup lifecycles per fresh process; ordinary host activity and OS cache uncontrolled.',
        process_metrics_scope='time -l includes process startup, fixture construction, full reference checks and exit; batch_nanos covers only complete native array execution, shape checks and destruction.')
    c.save(run_dir / 'before.json', record)
    failure = None
    started = time.monotonic()
    try:
        cells = list(itertools.product(contract['shapes'], contract['rows'], contract['chunks']))
        for cell_index, (shape, rows, chunks) in enumerate(cells):
            c.storage(run_dir, cohort=True)
            for pair in range(contract['pairs_per_cell']):
                variants = ['baseline', 'candidate']
                if (cell_index + pair + int(order == 'reverse')) % 2:
                    variants.reverse()
                for position, variant in enumerate(variants):
                    binary = builds[variant]['binary']['path']
                    assert stat_identity(binary) == identities[variant]
                    result = sample(run_dir, len(record['samples']), shape, rows, chunks,
                        pair, position, variant, binary)
                    assert stat_identity(binary) == identities[variant]
                    record['samples'].append(result)
                    c.save(run_dir / f"sample-{result['index']:04}.json", result)
            print(json.dumps(dict(status='cell_passed', order=order, cell=cell_index + 1,
                cells=len(cells), shape=shape, rows=rows, chunks=chunks)), flush=True)
        c.frozen()
        assert all(c.sha(value['binary']['path']) == value['binary']['sha256'] for value in builds.values())
        record['source_and_binaries_unchanged'] = True
        record['status'] = 'passed'
    except BaseException as error:
        failure = f'{type(error).__name__}: {error}'
        record['status'] = 'failed'
        raise
    finally:
        record['failure'] = failure
        record['seconds'] = time.monotonic() - started
        c.save(run_dir / 'summary.json', record)
        c.storage(run_dir, cohort=True)
    print(json.dumps(dict(status=record['status'], samples=len(record['samples']), seconds=record['seconds'])), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('order', choices=('forward', 'reverse'))
    run(parser.parse_args().order)
