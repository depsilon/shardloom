"""Run required workspace and native feature gates on the frozen decoder source."""
import json
from pathlib import Path
import re
import subprocess
import sys

import decoder_cost_common_418 as c


def receipt(name):
    path = c.OUT / (name + '.json')
    value = c.read(path)
    log = path.with_suffix('.log')
    assert value['status'] == 'passed' and value['returncode'] == 0
    assert value['process_group_drained'] and value['direct_child_reaped']
    assert value['head'] == c.BASE and value['cwd'] == str(c.ROOT)
    assert value['log_sha256'] == c.sha(log)
    return dict(name=name, command=value['command'], receipt=str(path),
        receipt_sha256=c.sha(path), log=str(log), log_sha256=c.sha(log), seconds=value['seconds'])


def inspect_tests(item, native, frozen):
    raw = Path(item['log']).read_text()
    groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', raw)
    assert groups and all(int(row[1]) == int(row[3]) == int(row[4]) == 0 for row in groups)
    ignored = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', raw, re.M)
    expected = []
    if native:
        expected = c.read(c.OUT / 'selection-checks-final-407.json')['ignored_tests']
        expected.append(dict(test=c.TEST,
            reason='native decoder lifecycle screen; guarded serial release execution required',
            source_path_at_head='shardloom-vortex/src/native_provider_decoder_cost.rs'))
    assert sum(int(row[2]) for row in groups) == len(ignored)
    assert sorted(ignored) == sorted((row['test'], row['reason']) for row in expected)
    evidence = []
    for test, reason in ignored:
        entry = next(row for row in expected if (row['test'], row['reason']) == (test, reason))
        name = entry['source_path_at_head']
        assert c.sha(c.ROOT / name) == frozen[name]
        lines = (c.ROOT / name).read_text().splitlines()
        matches = [i for i, line in enumerate(lines) if re.search(r'\bfn ' + re.escape(test.split('::')[-1]) + r'\(', line)]
        position, = matches
        declaration = lines[max(0, position - 6):position + 1]
        assert any(reason in line for line in declaration) and any('ignore' in line for line in declaration)
        evidence.append(dict(test=test, reason=reason, source=name, line=position + 1,
            source_sha256=frozen[name], declaration=declaration))
    item['tests'] = dict(passed=sum(int(row[0]) for row in groups), failed=0,
        ignored=len(ignored), groups=len(groups), ignored_evidence=evidence)


def main():
    source = c.frozen()
    decision = c.read(c.DEST / 'decision.json')
    assert decision['status'] == 'retained_for_resource_correctness_pending_wider_acceptance'
    assert decision['forward']['source_manifest_sha256'] == c.sha(c.DEST / 'source.json')
    frozen = source['candidate_source_sha256']
    manifest = c.OUT / 'decoder-check-source-418.json'
    c.save(manifest, dict(head=c.BASE, source_sha256=frozen,
        cost_decision=c.bound(c.DEST / 'decision.json'),
        workflow_sha256=c.sha(c.ROOT / '.github/workflows/ci.yml'), helper=c.bound(__file__)))
    checks = [
        ('fmt', 180, ['cargo', 'fmt', '--all', '--', '--check']),
        ('read-clippy', 1200, ['cargo', 'clippy', '--offline', '--locked', '-p', 'shardloom-vortex',
            '-p', 'shardloom-cli', '--all-targets', '--features', 'vortex-local-primitives', '--', '-D', 'warnings']),
        ('release-clippy', 1200, ['cargo', 'clippy', '--offline', '--locked', '-p', 'shardloom-vortex',
            '-p', 'shardloom-cli', '--all-targets', '--features', 'release-user-surfaces', '--', '-D', 'warnings']),
        ('workspace-clippy', 1200, ['cargo', 'clippy', '--workspace', '--all-targets', '--', '-D', 'warnings']),
        ('workspace-tests', 1800, ['cargo', 'test', '--workspace', '--all-targets', '--', '--test-threads=2']),
        ('native-tests', 3600, ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-vortex',
            '-p', 'shardloom-cli', '--all-targets', '--features',
            'vortex-local-primitives,vortex-write,universal-format-io', '--', '--test-threads=2']),
    ]
    c.save(c.OUT / 'decoder-check-protocol-418.json', dict(checks=checks, source=c.bound(manifest),
        helper=c.bound(__file__), prior_ignored_declarations=c.bound(c.OUT / 'selection-checks-final-407.json'),
        unchanged_vendor_scope='No vendor/dependency changes in this unit. Prior vendor-specific acceptance retains its original source identity; current native integration gates exercise the wrapper.'))
    completed, failure = [], None
    try:
        for label, timeout, command in checks:
            c.frozen()
            name = f'native-decoder-{label}-418'
            subprocess.run([sys.executable, '-B', str(c.OUT / 'run_guarded.py'), '--name', name,
                '--timeout', str(timeout), '--', *command], cwd=c.ROOT, check=True)
            result = receipt(name)
            result['name'] = label
            if label.endswith('tests'):
                inspect_tests(result, label == 'native-tests', frozen)
            completed.append(result)
        c.frozen()
    except BaseException as error:
        failure = f'{type(error).__name__}: {error}'
        raise
    finally:
        c.save(c.OUT / 'decoder-checks-418.json', dict(status='passed' if failure is None else 'failed',
            source_manifest=str(manifest), source_manifest_sha256=c.sha(manifest), source_files=len(frozen),
            runtime_source_unchanged=c.sources() == frozen, completed=completed, failure=failure))
    print(json.dumps(dict(status='passed', gates=len(completed), tests=[
        dict(name=row['name'], **{key:value for key,value in row['tests'].items() if key != 'ignored_evidence'})
        for row in completed if 'tests' in row])), flush=True)


if __name__ == '__main__':
    main()
