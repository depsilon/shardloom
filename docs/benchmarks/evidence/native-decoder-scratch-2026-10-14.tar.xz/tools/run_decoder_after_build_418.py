"""Run frozen cost orders, then wider acceptance only if the cost decision allows it."""
import json
from pathlib import Path
import subprocess
import sys

import decoder_cost_common_418 as c


def main():
    source = c.frozen()
    builds = {variant: c.build(variant) for variant in ('baseline', 'candidate')}
    for variant in builds:
        restored = c.read(c.DEST / (variant + '-restoration.json'))
        assert restored['status'] == 'passed' and restored['candidate_source_unchanged']
        assert restored['failure'] is None
    assert (c.DEST / 'contract.json').read_bytes() == (c.OUT / 'decoder-cost-416/contract.json').read_bytes()
    assert c.read(c.OUT / 'decoder-cost-416/decision.json')['status'] == 'revision_required'
    for name in ('forward', 'reverse', 'screen.json', 'decision.json'):
        assert not (c.DEST / name).exists(), name
    helper_names = [*c.HELPERS, 'run_decoder_after_build_418.py', 'run_decoder_acceptance_418.py',
        'run_decoder_checks_418.py', 'run_decoder_runtime_418.py', 'verify_decoder_public_418.py',
        'run_decoder_full43_418.py', 'freeze_query_cli_368.py']
    helpers = {name: c.bound(c.OUT / name) for name in helper_names}
    protocol = c.OUT / 'decoder-comparison-protocol-418.json'
    c.save(protocol, dict(status='frozen_before_any_418_timing',
        source_manifest=c.bound(c.DEST / 'source.json'), builds=builds,
        contract=c.bound(c.DEST / 'contract.json'), helpers=helpers,
        order=['forward', 'screen', 'reverse_if_triggered', 'decision', 'wider_acceptance_if_retained'],
        rejected_attempt=c.bound(c.OUT / 'decoder-cost-416/decision.json'),
        thresholds_unchanged=True, performance_claim_allowed=False))
    completed, failure, decision = [], None, None

    def run(label, command):
        c.frozen()
        assert all(c.bound(c.OUT / name) == item for name, item in helpers.items())
        print(json.dumps(dict(stage=label, status='starting')), flush=True)
        subprocess.run(command, cwd=c.ROOT, check=True)
        c.frozen()
        assert all(c.bound(c.OUT / name) == item for name, item in helpers.items())
        completed.append(dict(stage=label, command=command, returncode=0))
        print(json.dumps(dict(stage=label, status='completed')), flush=True)

    def cost_order(order):
        run(order, [sys.executable, '-B', str(c.OUT / 'run_guarded.py'),
            '--name', f'native-decoder-cost-{order}-418', '--timeout', '2400', '--',
            sys.executable, '-B', str(c.OUT / 'decoder_cost_run_418.py'), order])

    def analyze(stage):
        run(stage, [sys.executable, '-B', str(c.OUT / 'decoder_cost_analyze_418.py'), stage])

    try:
        cost_order('forward')
        analyze('screen')
        if c.read(c.DEST / 'screen.json')['confirmation_required']:
            cost_order('reverse')
        analyze('decision')
        decision = c.read(c.DEST / 'decision.json')
        if decision['status'] == 'retained_for_resource_correctness_pending_wider_acceptance':
            assert not decision['repeated_material_regressions']
            run('wider_acceptance', [sys.executable, '-B', str(c.OUT / 'run_decoder_acceptance_418.py')])
            assert c.read(c.OUT / 'decoder-acceptance-418.json')['status'] == 'passed'
        else:
            assert decision['status'] == 'revision_required'
        assert c.sources() == source['candidate_source_sha256']
    except BaseException as error:
        failure = f'{type(error).__name__}: {error}'
        raise
    finally:
        c.save(c.OUT / 'decoder-after-build-418.json', dict(
            status='passed' if failure is None else 'failed', failure=failure,
            protocol=c.bound(protocol), completed=completed,
            cost_decision=decision['status'] if decision else None,
            decision=c.bound(c.DEST / 'decision.json') if decision else None,
            wider_acceptance_ran=any(row['stage'] == 'wider_acceptance' for row in completed),
            sources_unchanged=c.sources() == source['candidate_source_sha256'],
            performance_claim_allowed=False))


if __name__ == '__main__':
    main()
