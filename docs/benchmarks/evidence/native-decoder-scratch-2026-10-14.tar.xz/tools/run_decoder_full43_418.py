"""Recheck all complete ClickBench queries after native fixed-width decoder resource admission."""
import argparse
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import stat
import statistics
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sha, sources, save

sys.path.insert(0, str(ROOT / 'scripts'))
from clickbench_reference_packet import load_reference_packet
from local_uat_storage import (
    GIB, MIB, add_log_budget_arguments, check_budgets, require_local_path,
)
from native_workflow_protocol import extract_result, report_fields, strict_json
from run_clickbench_query_uat import clickbench_harness_paths, equivalent, score

MANIFEST = OUT / 'decoder-resources-418-release.json'
UAT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
SOURCE = UAT / 'vortex/persisted-native-343-a1.vortex'
REFERENCE = Path('/Users/dylan/LocalData/shardloom/native-typed-reductions-20261004/clickbench-reference-values-2.json')
QUERIES = ROOT / 'benchmarks/clickbench/queries.sql'


def bound(path):
    path = Path(path)
    return dict(path=str(path), sha256=sha(path), bytes=path.stat().st_size)


def generation(path):
    value = Path(path).stat()
    return {key: getattr(value, key) for key in (
        'st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_blocks', 'st_flags')}


def frozen():
    manifest = strict_json(MANIFEST.read_text())
    assert manifest['status'] == 'passed' and manifest['build_profile'] == 'release'
    assert sources() == manifest['source_sha256']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == manifest['head']

    source_manifest = manifest['source_manifest']
    source_manifest_path = Path(source_manifest['path'])
    assert sha(source_manifest_path) == source_manifest['sha256']
    source_record = strict_json(source_manifest_path.read_text())
    assert source_record['head'] == manifest['head']
    assert source_record['source_sha256'] == manifest['source_sha256']

    artifact = manifest['cli']
    assert bound(artifact['path']) == {key: artifact[key] for key in ('path', 'sha256', 'bytes')}
    assert sha(artifact['build_receipt']) == artifact['build_receipt_sha256']
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    add_log_budget_arguments(parser)
    args = parser.parse_args()

    build = frozen()
    original_manifest = bound(MANIFEST)
    require_local_path(UAT, Path.home(), sys.platform)
    require_local_path(SOURCE, Path.home(), sys.platform)
    before = generation(SOURCE)
    assert stat.S_ISREG(SOURCE.stat().st_mode) and before['st_flags'] == 0
    assert before['st_size'] == 15713610513 and before['st_blocks'] * 512 >= before['st_size']
    run_log_budget_bytes = math.floor(args.max_run_log_mib * MIB)
    preflight_run_logs = UAT / 'logs' / 'decoder-resources-full43-418-admission'
    storage = check_budgets(
        UAT, SOURCE, preflight_run_logs, min_free_bytes=12 * GIB,
        reserve_bytes=4 * MIB + run_log_budget_bytes,
        max_workspace_bytes=100 * GIB,
        max_log_bytes=math.floor(args.max_log_mib * MIB),
        max_run_log_bytes=run_log_budget_bytes,
        reserve_log_bytes=run_log_budget_bytes,
    )
    assert not (UAT / '.ingest-uat.lock').exists()
    source_sha = sha(SOURCE)
    assert source_sha == '004f9639fa0aa527b70f326c366c37b1173dceeacb92b50b2d8fd02957155c18'
    assert generation(SOURCE) == before
    assert sha(REFERENCE) == 'cb83c770674073f31ad0c4224f02faeb1ba557c512595a5c2d36f92bb2344b39'
    reference = load_reference_packet(REFERENCE, QUERIES)
    provenance_path = OUT / 'persisted-acceptance-343/persisted-native-fresh-uat-1-results.json'
    provenance = strict_json(provenance_path.read_text())
    assert provenance['status'] == 'passed_local_fresh_uat'
    assert provenance['artifact_identities'][str(SOURCE)]['sha256'] == source_sha
    harness = [bound(path) for path in clickbench_harness_paths()]
    admission = dict(
        status='passed', manifest=original_manifest, source=str(SOURCE),
        source_sha256=source_sha, source_generation=before, source_resident_before_read=True,
        provenance=bound(provenance_path), reference=bound(REFERENCE), queries=bound(QUERIES),
        harness=harness, driver=bound(__file__), storage=storage,
        max_log_mib=args.max_log_mib, max_run_log_mib=args.max_run_log_mib,
        max_log_bytes=math.floor(args.max_log_mib * MIB),
        max_run_log_bytes=run_log_budget_bytes,
        memory_gb=24, maximum_parallelism=12, runs_per_query=3,
        performance_claim_allowed=False,
        reference_kind='retained_native_regression',
        cache_state='prehashed; OS cache uncontrolled',
    )
    admission_path = OUT / 'decoder-resources-full43-admission-418.json'
    save(admission_path, admission)
    old = set((UAT / 'logs').glob('full43_*/summary.json'))
    command = [
        sys.executable, '-B', str(OUT / 'run_guarded.py'),
        '--name', 'decoder-resources-full43-418', '--timeout', '2400', '--', sys.executable,
        '-B', str(ROOT / 'scripts/run_clickbench_query_uat.py'), '--binary', build['cli']['path'],
        '--build-commit', build['head'], '--input', str(SOURCE), '--uat-root', str(UAT),
        '--reference-packet', str(REFERENCE), '--queries', str(QUERIES),
        '--memory-gb', '24', '--max-parallelism', '12', '--timeout', '120', '--compress-logs',
        '--max-log-mib', str(args.max_log_mib),
        '--max-run-log-mib', str(args.max_run_log_mib),
    ]
    subprocess.run(command, cwd=ROOT, check=True)
    receipt_path = OUT / 'decoder-resources-full43-418.json'
    receipt = strict_json(receipt_path.read_text())
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert sha(receipt_path.with_suffix('.log')) == receipt['log_sha256']
    new = set((UAT / 'logs').glob('full43_*/summary.json')) - old
    assert len(new) == 1
    summary_path = new.pop()
    report = strict_json(summary_path.read_text())
    assert report['build_commit'] == build['head'] and report['binary_sha256'] == build['cli']['sha256']
    for key in ('complete', 'full_result_validation', 'completed_identity_check',
                'reference_packet_identity_verified', 'harness_identity_verified'):
        assert report[key] is True, key
    assert report['reference_kind'] == 'retained_native_regression'
    assert report['reference_packet']['sha256'] == admission['reference']['sha256']
    assert report['memory_gb'] == 24 and report['max_parallelism'] == 12
    assert report['log_budget_bytes'] == {
        'retained': math.floor(args.max_log_mib * MIB),
        'active_run': run_log_budget_bytes,
    }
    assert report['selected_query_ids'] == list(range(1, 44)) and len(report['records']) == 129
    schemas, rows, companions, envelopes = {}, 0, [], []
    for record in report['records']:
        query, run = record['query'], record['run']
        assert record['passed'] and record['validation'] == 'complete_values'
        assert record['returncode'] == 0 and not record['guard_failures']
        assert record['command'][0] == build['cli']['path']
        prefix = summary_path.parent / f'q{query:02d}_run{run}'
        timing_path = prefix.with_suffix('.timing.json')
        timing = strict_json(timing_path.read_text())
        assert timing['returncode'] == 0
        for key in ('seconds', 'user_cpu_seconds', 'system_cpu_seconds'):
            assert timing[key] == record[key]
        assert timing['peak_rss_bytes'] == record['native_peak_rss_bytes']
        companions.extend([bound(timing_path), bound(prefix.with_suffix('.pid'))])
        envelope = None
        for archive in record['completed_log_archives']:
            packed = Path(archive['path']).read_bytes()
            assert len(packed) == archive['gzip_bytes'] and hashlib.sha256(packed).hexdigest() == archive['gzip_sha256']
            raw = gzip.decompress(packed)
            assert len(raw) == archive['raw_bytes'] and hashlib.sha256(raw).hexdigest() == archive['raw_sha256']
            envelopes.append(bound(archive['path']))
            if archive['path'].endswith('.stdout.json.gz'):
                assert envelope is None
                envelope = strict_json(raw.decode())
        assert envelope is not None
        fields = report_fields(envelope)
        assert fields['execution_resource_declared_memory_bytes'] == str(24 * GIB)
        assert fields['execution_resource_declared_max_parallelism'] == '12'
        assert fields['execution_resource_whole_process_memory_limit_enforced'] == 'false'
        for key, value in fields.items():
            if key.endswith(('fallback_attempted', 'fallback_execution_allowed', 'external_engine_invoked')):
                assert value == 'false' or value is False, (query, key)
        actual = extract_result(envelope)
        assert equivalent(actual, reference['values'][query])
        assert hashlib.sha256(json.dumps(actual, sort_keys=True, allow_nan=False).encode()).hexdigest() == record['result_sha256']
        schema = (fields['result_schema_format'], strict_json(fields['result_schema_json']))
        assert schemas.setdefault(query, schema) == schema
        rows += len(actual)
    recomputed = score(report['records'], 43)
    for key, value in recomputed.items():
        assert report[key] == value, key
    assert generation(SOURCE) == before and sha(SOURCE) == source_sha and generation(SOURCE) == before
    assert bound(MANIFEST) == original_manifest and frozen() == build
    for item in harness + [admission['reference'], admission['queries'], admission['driver']]:
        assert bound(item['path']) == item
    assert not (UAT / '.ingest-uat.lock').exists()
    result = dict(
        status='passed', admission=bound(admission_path), receipt=bound(receipt_path),
        summary=bound(summary_path), manifest=original_manifest, queries=43, calls=129,
        complete_rows=rows, all_values_and_schemas_reopened=True, resources_and_no_fallback=True,
        original_input_and_sources_unchanged=True, performance_claim_allowed=False,
        no_new_ingest=True, reference_kind='retained_native_regression',
        complete_operation_seconds=sum(r['seconds'] for r in report['records']),
        supervised_suite_seconds=receipt['seconds'],
        query_medians_seconds={str(q): statistics.median(
            r['seconds'] for r in report['records'] if r['query'] == q
        ) for q in range(1, 44)},
        companions=companions, envelopes=envelopes, publication_attempted=False,
    )
    result_path = OUT / 'decoder-resources-full43-primary-review-418.json'
    save(result_path, result)
    print(json.dumps({key: result[key] for key in (
        'status', 'queries', 'calls', 'complete_rows',
        'complete_operation_seconds', 'supervised_suite_seconds')}), flush=True)
    print(json.dumps(bound(result_path)), flush=True)


if __name__ == '__main__':
    main()

