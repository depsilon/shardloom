"""Package completed decoder acceptance; do not run before every prerequisite passes."""
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import tarfile

from package_selection_acceptance_409 import Members, need, receipt_pair, sha_file, sha_stream, verify
from freeze_native_release_298 import sources

OUT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
BASE = '22b2cde04973ce4462517d73fe67b5f7a1e8177c'
OUTPUTS = tuple(OUT / ('decoder-resources-evidence-421.' + suffix)
                for suffix in ('tar.xz', 'manifest.json', 'verification.json'))
LIMIT = 192 << 20


def read(path):
    return json.loads(Path(path).read_text())


def bound(path):
    size, digest = verify(Path(path))
    return dict(path=str(path), bytes=size, sha256=digest)


def add_bound(members, item, prefix, role):
    path = Path(item['path'])
    relative = (path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT)
                else path.relative_to(OUT).as_posix() if path.is_relative_to(OUT)
                else path.name)
    members.add(path, prefix + '/' + relative, 'evidence', path.parent,
                role, item['sha256'], item.get('bytes'))


def main():
    partials = tuple(path.with_name('.' + path.name + '.partial') for path in OUTPUTS)
    for path in (*OUTPUTS, *partials):
        need(not path.exists() and not path.is_symlink(), f'output exists: {path}')
    required = [
        'decoder-after-build-418.json', 'decoder-acceptance-418.json',
        'decoder-checks-418.json', 'decoder-resources-418-release.json',
        'decoder-native-artifacts-418.json', 'decoder-direct-418.json',
        'decoder-runtime-418.json', 'decoder-public-review-418.json',
        'decoder-resources-full43-primary-review-418.json',
    ]
    reports = {name: read(OUT / name) for name in required}
    need(all(value['status'] == 'passed' for value in reports.values()), 'acceptance incomplete')
    after = reports['decoder-after-build-418.json']
    need(after['wider_acceptance_ran'], 'wider acceptance not executed')
    source_path = OUT / 'decoder-cost-418/source.json'
    source = read(source_path)
    accepted = source['candidate_source_sha256']
    need(source['head'] == BASE and len(accepted) == 2244, 'unexpected source scope')
    need(sources() == accepted, 'current source changed after acceptance')
    release = reports['decoder-resources-418-release.json']
    native = reports['decoder-native-artifacts-418.json']
    need(release['source_sha256'] == native['source_sha256'] == accepted,
         'accepted builds disagree with frozen source')
    checks = reports['decoder-checks-418.json']
    need(checks['runtime_source_unchanged'] and len(checks['completed']) == 6,
         'required validation gates incomplete')
    direct = reports['decoder-direct-418.json']
    need(direct['tests'] == 80 and direct['failures'] == direct['errors'] == direct['skipped'] == 0,
         'direct binding acceptance incomplete')
    runtime = reports['decoder-runtime-418.json']
    need(runtime['public_cases'] == 757 and len(runtime['public_families']) == 19,
         'public workflow coverage incomplete')
    public = reports['decoder-public-review-418.json']
    need(public['cases'] == 757 and public['families'] == 19
         and public['complete_case_log_records_equal'], 'public evidence not reopened')
    full = reports['decoder-resources-full43-primary-review-418.json']
    need(full['calls'] == 129 and full['queries'] == 43 and full['complete_rows'] == 1143
         and full['all_values_and_schemas_reopened'] and full['resources_and_no_fallback'],
         'complete Full43 acceptance missing')
    cost_review_path = OUT / 'decoder-retained-cost-primary-420.json'
    cost_review = read(cost_review_path)
    need(cost_review['status'] == 'passed_inventory_and_independent_cost_recomputation'
         and cost_review['complete_sample_log_pairs'] == 3888
         and all(order['material_cells'] == 0 for order in cost_review['orders'].values()),
         'cost decision lacks independent verification')
    decision = read(OUT / 'decoder-cost-418/decision.json')
    need(decision['status'] == 'retained_for_resource_correctness_pending_wider_acceptance'
         and not decision['repeated_material_regressions'], 'candidate requires revision')

    members, exclusions = Members(), []
    inventory_path = Path(cost_review['inventory']['path'])
    verify(inventory_path, cost_review['inventory']['sha256'], cost_review['inventory']['bytes'])
    inventory = read(inventory_path)
    for item in inventory['members']:
        members.add(Path(item['path']), item['archive_path'], 'evidence', OUT,
                    item['category'], item['sha256'], item['bytes'])
    exclusions.extend(inventory['exclusions'])
    for item in (cost_review['inventory'], cost_review['original_worker_inventory'],
                 cost_review['verifier'], cost_review['source_manifest'], cost_review['decision']):
        add_bound(members, item, 'cost-review', 'independent cost verification')
    for name in required + [
        'decoder-retained-cost-primary-420.json', 'decoder-comparison-protocol-418.json',
        'decoder-acceptance-protocol-418.json', 'decoder-check-protocol-418.json',
        'decoder-check-source-418.json', 'decoder-resources-418-source.json',
        'decoder-resources-full43-admission-418.json', 'decoder-primary-source-review-418.json',
        'decoder-inspection-source-formatted-417.json', 'decoder-inspection-focused-417.json',
        'decoder-first-candidate-rejection-417.json',
    ]:
        members.add(OUT / name, 'acceptance/' + name, 'evidence', OUT, 'acceptance or source record')
    for name in ('decoder-comparison-protocol-418.json', 'decoder-acceptance-protocol-418.json'):
        for item in read(OUT / name)['helpers'].values():
            add_bound(members, item, 'tools', 'frozen executed helper')
    for name, digest in source['helpers'].items():
        members.add(OUT / name, 'tools/' + name, 'evidence', OUT, 'source-bound helper', digest)
    add_bound(members, read(OUT / 'decoder-check-protocol-418.json')['source'],
              'acceptance', 'check source identity')
    add_bound(members, read(OUT / 'decoder-check-protocol-418.json')['prior_ignored_declarations'],
              'acceptance', 'prior manual/platform exclusion declarations')
    for path in (Path(__file__).resolve(), OUT / 'package_selection_acceptance_409.py',
                 OUT / 'package_decoder_rejection_418.py', ROOT / 'scripts/local_uat_storage.py',
                 Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py'),
                 Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py')):
        members.add(path, 'tools/support/' + path.name, 'support', path.parent, 'packager or guard support')
    pattern = re.compile(r'native-decoder-.*-(?:417|418)\.json')
    receipts = sorted(path for path in OUT.glob('native-decoder-*.json') if pattern.fullmatch(path.name))
    need(len(receipts) >= 14, 'missing decoder validation receipts')
    for path in receipts:
        receipt_pair(path, members, 'guards')
    receipt_pair(OUT / 'decoder-resources-full43-418.json', members, 'guards', 'passed')
    for item in checks['completed']:
        verify(Path(item['receipt']), item['receipt_sha256'])
        verify(Path(item['log']), item['log_sha256'])
    for record in (release['cli'], native['binding']):
        verify(Path(record['path']), record['sha256'], record['bytes'])
        exclusions.append(dict(**record, reason='verified executable identity; binary payload excluded'))

    members.tree(OUT / 'decoder-public-418', 'public', 'public',
                 'complete public logs, summaries and value evidence', exclusions, omit_outputs=True)
    add_bound(members, public['summary'], 'public', 'reopened public summary')
    for key in ('artifacts', 'value_files', 'envelopes', 'pressure_files'):
        for item in public[key]:
            verify(Path(item['path']), item['sha256'], item['bytes'])
    for item in full['companions'] + full['envelopes'] + [full['summary'], full['admission'], full['receipt']]:
        verify(Path(item['path']), item['sha256'], item['bytes'])
    members.tree(Path(full['summary']['path']).parent, 'full43', 'full43',
                 'complete Full43 raw outputs and timing companions', exclusions)
    admission = read(OUT / 'decoder-resources-full43-admission-418.json')
    for item in admission['harness'] + [admission['reference'], admission['queries'], admission['provenance']]:
        add_bound(members, item, 'full43-inputs', 'frozen workload or provenance')

    rejected = read(OUT / 'decoder-rejected-evidence-418.manifest.json')
    reopened = read(OUT / 'decoder-rejected-evidence-418.verification.json')
    need(rejected['status'] == reopened['status'] == 'passed' and reopened['all_members_reopened'],
         'rejected history archive not verified')
    need(rejected['archive']['sha256'] == reopened['archive_sha256']
         and bound(OUT / 'decoder-rejected-evidence-418.manifest.json')['sha256'] == reopened['manifest_sha256'],
         'rejected history archive identities disagree')
    add_bound(members, rejected['archive'], 'rejected-history', 'complete rejected candidate archive')
    for suffix in ('manifest.json', 'verification.json'):
        path = OUT / ('decoder-rejected-evidence-418.' + suffix)
        members.add(path, 'rejected-history/' + path.name, 'evidence', OUT, 'rejected archive verification')

    ordered = sorted(members.paths.values(), key=lambda item: item.name)
    raw_bytes = sum(item.size for item in ordered)
    need(raw_bytes <= LIMIT, 'archive exceeds 192 MiB raw-input budget')
    sys.path.insert(0, str(ROOT / 'scripts'))
    from local_uat_storage import GIB, MIB, check_budgets, require_local_path
    require_local_path(OUT, Path.home(), sys.platform)
    storage = check_budgets(OUT, OUTPUTS[0], OUT / 'logs', min_free_bytes=12 * GIB,
        reserve_bytes=raw_bytes + 64 * MIB, max_workspace_bytes=100 * GIB, max_log_bytes=1024 * MIB)
    created, published = [], []
    try:
        with partials[0].open('xb') as output:
            created.append(partials[0])
            with tarfile.open(fileobj=output, mode='w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
                for item in ordered:
                    verify(item.path, item.digest, item.size)
                    info = tarfile.TarInfo(item.name)
                    info.size, info.mode, info.mtime = item.size, 0o644, 0
                    with item.path.open('rb') as stream:
                        archive.addfile(info, stream)
                    verify(item.path, item.digest, item.size)
        seen = set()
        with tarfile.open(partials[0], mode='r|xz') as archive:
            for entry in archive:
                need(entry.isfile() and entry.name in members.names and entry.name not in seen,
                     f'invalid member: {entry.name}')
                item = members.paths[members.names[entry.name]]
                stream = archive.extractfile(entry)
                need(stream is not None, 'missing member bytes')
                need(sha_stream(stream) == (item.size, item.digest), f'archive mismatch: {entry.name}')
                seen.add(entry.name)
        need(seen == set(members.names), 'incomplete archive membership')
        for item in ordered:
            verify(item.path, item.digest, item.size)
        need(sources() == accepted, 'runtime source changed while packaging')
        size, digest = sha_file(partials[0])
        manifest = dict(status='passed', kind='native_decoder_resource_acceptance', base_commit=BASE,
            source_manifest=bound(source_path), source_files=len(accepted),
            changed_source_paths=source['changed_source_paths'],
            archive=dict(path=str(OUTPUTS[0]), bytes=size, sha256=digest),
            members=[dict(path=str(item.path), archive_path=item.name, bytes=item.size,
                          sha256=item.digest, roles=item.roles) for item in ordered],
            member_count=len(ordered), raw_bytes=raw_bytes, raw_limit_bytes=LIMIT, exclusions=exclusions,
            acceptance=dict(cost_samples=3888, cost_cells_per_order=108, repeated_material_cells=0,
                broad_gates=6, direct_tests=80, public_cases=757, public_families=19,
                full43_calls=129, full43_rows=1143, rejected_history_preserved=True),
            storage=storage, all_members_reopened=True, performance_claim_allowed=False,
            hosted_integration_complete=False, publication_attempted=False,
            limitations='Finite local source-package/native acceptance. No installed-wheel, general memory, process-RSS ceiling, cross-platform, performance-superiority or release-readiness claim.')
        encoded = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
        verification = dict(status='passed', all_members_reopened=True, member_count=len(seen),
            archive_bytes=size, archive_sha256=digest, manifest_sha256=hashlib.sha256(encoded).hexdigest())
        for temporary, value in zip(partials[1:], (encoded, (json.dumps(verification, indent=2, sort_keys=True) + '\n').encode()), strict=True):
            with temporary.open('xb') as stream:
                created.append(temporary)
                stream.write(value)
        for temporary, output in zip(partials, OUTPUTS, strict=True):
            os.link(temporary, output)
            published.append(output)
            temporary.unlink()
            created.remove(temporary)
        print(json.dumps(dict(status='passed', archive=str(OUTPUTS[0]), members=len(seen),
                             archive_bytes=size, archive_sha256=digest, raw_bytes=raw_bytes)), flush=True)
    except BaseException:
        for path in published:
            path.unlink(missing_ok=True)
        raise
    finally:
        for path in created:
            path.unlink(missing_ok=True)


if __name__ == '__main__':
    main()
