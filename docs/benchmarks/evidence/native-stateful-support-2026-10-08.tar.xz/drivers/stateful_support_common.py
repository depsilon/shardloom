"""Verify the accepted runtime plus exactly one public Python docstring correction."""
import ast
import copy
import json

import stateful_acceptance_common as c

ROOT, OUT, PYTHON = c.ROOT, c.OUT, c.PYTHON
read, sha, write = c.read, c.sha, c.write
DOCUMENTED_ASSET = 'python/src/shardloom/query.py'


def checked_runtime():
    snapshot = read(OUT / 'stateful-source-1.json')
    build = read(OUT / 'stateful-acceptance-build-1.json')
    actual = c.source_hashes()
    assert set(actual) == set(snapshot['source_hashes'])
    changed = sorted(name for name in actual if actual[name] != snapshot['source_hashes'][name])
    assert changed == [DOCUMENTED_ASSET], changed
    original = c.git('show', snapshot['head'] + ':' + DOCUMENTED_ASSET)
    current = (ROOT / DOCUMENTED_ASSET).read_text()
    old_tree, new_tree = ast.parse(original), ast.parse(current)
    old_fn, = [item for item in old_tree.body if isinstance(item, ast.FunctionDef) and item.name == 'from_batches']
    new_fn, = [item for item in new_tree.body if isinstance(item, ast.FunctionDef) and item.name == 'from_batches']
    assert isinstance(old_fn.body[0], ast.Expr) and isinstance(old_fn.body[0].value, ast.Constant)
    assert isinstance(new_fn.body[0], ast.Expr) and isinstance(new_fn.body[0].value, ast.Constant)
    before, after = old_fn.body[0].value.value, new_fn.body[0].value.value
    assert isinstance(before, str) and isinstance(after, str) and before != after
    assert 'pure filters/projections' in before
    assert all(text in after for text in ('sorting', 'aggregation', 'limits', 'drain'))
    old_fn.body[0] = copy.deepcopy(new_fn.body[0])
    assert ast.dump(old_tree, include_attributes=False) == ast.dump(new_tree, include_attributes=False)
    assert build['source_identity_sha256'] == snapshot['source_identity_sha256']
    assert sha(build['binary']) == build['binary_sha256']
    annotation = {'accepted_runtime_commit': snapshot['head'],
        'accepted_source_identity_sha256': snapshot['source_identity_sha256'],
        'assets_byte_identical': len(actual) - 1, 'asset_count_unchanged': len(actual),
        'docstring_only_asset': DOCUMENTED_ASSET,
        'accepted_file_sha256': snapshot['source_hashes'][DOCUMENTED_ASSET],
        'current_file_sha256': actual[DOCUMENTED_ASSET], 'function': 'from_batches',
        'prior_docstring': before, 'current_docstring': after,
        'entire_module_ast_identical_after_replacing_only_named_docstring': True,
        'executable_behavior_changed': False, 'binary_sha256': build['binary_sha256']}
    return snapshot, build, annotation


def portable(value):
    text = json.dumps(value, indent=2, allow_nan=False)
    for original, replacement in ((str(ROOT), '<repo>'), (str(OUT), '<stateful-uat>'), (str(ROOT.home()), '<home>')):
        text = text.replace(original, replacement)
    return text + '\n'
