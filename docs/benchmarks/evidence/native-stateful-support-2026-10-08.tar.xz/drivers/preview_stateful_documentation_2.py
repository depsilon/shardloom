"""Serve corrected stateful documentation for final local browser verification."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import os
import time

import stateful_support_common as c

stop = c.OUT / 'stateful-documentation-preview-stop-2'
assert not stop.exists()
assert c.read(c.OUT / 'stateful-support-checks-3/summary.json')['status'] == 'passed'
c.checked_runtime()
handler = partial(SimpleHTTPRequestHandler, directory=str(c.ROOT / 'website'))
server = ThreadingHTTPServer(('127.0.0.1', 0), handler)
server.daemon_threads = True
server.timeout = 0.5
c.write(c.OUT / 'stateful-documentation-preview-address-2.json', {
    'url': f'http://127.0.0.1:{server.server_address[1]}', 'pid': os.getpid(),
    'root': str(c.ROOT / 'website'), 'maximum_seconds': 600})
deadline = time.monotonic() + 600
try:
    while not stop.exists() and time.monotonic() < deadline:
        server.handle_request()
finally:
    server.server_close()
print('Preview server closed', flush=True)
