"""Immutable identities for the complete local stateful execution unit."""
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
PRIOR = Path('/Users/dylan/LocalData/shardloom/native-input-completion-20261007')
sys.path.insert(0, str(PRIOR))
from input_common import ROOT, PYTHON, git, read, sha, source_hashes, write

def frozen_source():
    source = read(OUT / 'stateful-source-1.json')
    assert source_hashes() == source['source_hashes']
    assert git('rev-parse', 'HEAD') == source['head']
    assert git('status', '--porcelain') == source['working_tree'] == ''
    assert all(sha(path) == digest for path, digest in source['helpers'].items())
    return source

def frozen_build():
    source = frozen_source()
    build = read(OUT / 'stateful-acceptance-build-1.json')
    assert build['source_identity_sha256'] == source['source_identity_sha256']
    assert build['source_manifest_sha256'] == sha(OUT / 'stateful-source-1.json')
    for artifact in build['artifacts'].values():
        assert Path(artifact['binary']).stat().st_size == artifact['bytes']
        assert sha(artifact['binary']) == artifact['sha256']
    scope = read(build['scope_manifest'])
    assert sha(build['scope_manifest']) == build['scope_sha256']
    assert scope['case_count'] == len(scope['cases']) == 27373
    assert scope['complete_rows'] == sum(scope['cases'].values()) == 15820181
    assert all(sha(path) == digest for path, digest in scope['unchanged_declaration_sources'].items())
    assert all(sha(path) == item['candidate_sha256'] for path, item in scope['changed_product_adapters'].items())
    assert sha(scope['nested_pivot_oracle']['path']) == scope['nested_pivot_oracle']['sha256']
    assert all(sha(item['path']) == item['sha256'] for item in scope['literal_oracles'])
    return source, build, scope
