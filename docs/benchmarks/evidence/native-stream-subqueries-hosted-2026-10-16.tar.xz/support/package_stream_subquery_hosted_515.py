"""Verify and retain complete finite-subquery hosted integration."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile

import accept_stream_subquery_hosted_jobs_513 as jobs
import verify_stream_subquery_integrated_sources_513 as sources

ROOT, OUT = sources.ROOT, sources.OUT
RAW = OUT / 'stream-subquery-hosted-512'
HEAD, SYNTHETIC = sources.HEAD, sources.SYNTHETIC
MERGE = 'c30846afb0ab5abfff6fdb5d95ed20f1c10a9477'
sys.path.insert(0, str(ROOT / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def read(path):
    return json.loads(Path(path).read_text())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=digest(raw))


def check(record):
    actual = identity(record['path'])
    assert actual == {k: record[k] for k in ('path', 'bytes', 'sha256')}, record['path']


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def served(stage, revision):
    folder = RAW / (stage + '-served-513')
    report = read(folder / 'report.json')
    assert report['status'] == 'passed' and report['stage'] == stage
    assert report['head'] == revision and report['reviewed_head'] == HEAD
    check(dict(report['helper'], bytes=Path(report['helper']['path']).stat().st_size))
    checks = read(folder / 'deployment-checks.json')
    assert checks['total_count'] == len(checks['check_runs']) <= 100
    workers = [r for r in checks['check_runs'] if r['name'] == 'Workers Builds: shardloom']
    assert len(workers) == 1
    worker = workers[0]
    assert worker['head_sha'] == revision and worker['status'] == 'completed' and worker['conclusion'] == 'success'
    assert all(report['deployment'][k] == worker[k] for k in report['deployment'])
    versions = re.findall(r'Version ID: ([0-9a-f-]{36})', worker['output']['summary'])
    assert len(versions) == 1
    pr = read(folder / 'pull-request.json')
    assert pr['number'] == 1560 and pr['head']['sha'] == HEAD
    if stage == 'production':
        assert pr['merged'] and pr['merge_commit_sha'] == MERGE
    assert len(report['responses']) == len({r['source'] for r in report['responses']}) == 8
    for row in report['responses']:
        actual = (folder / row['response']).read_bytes()
        expected = subprocess.check_output(['git', 'show', revision + ':' + row['source']], cwd=ROOT)
        assert row['http_status'] == 200 and row['source_preserved']
        assert row['observed_bytes'] == len(actual) and row['observed_sha256'] == digest(actual)
        assert row['expected_bytes'] == len(expected) and row['expected_sha256'] == digest(expected)
        assert row['raw_byte_identical'] == (actual == expected)
        assert read(folder / (row['response'] + '.attempts.json')) == row['attempts']
        assert row['attempts'][-1]['status'] == 'passed' and 1 <= len(row['attempts']) <= 3
        if actual != expected:
            prefix = next(i for i, (a, b) in enumerate(zip(actual, expected)) if a != b)
            extra = len(actual) - len(expected)
            assert 0 < extra <= 16384 and row['source'].endswith('.html')
            inserted = actual[prefix:prefix + extra]
            assert actual[prefix + extra:] == expected[prefix:]
            assert b'/cdn-cgi/challenge-platform/' in inserted or b'static.cloudflareinsights.com/' in inserted
            assert row['insertion_bytes'] == extra and row['insertion_sha256'] == digest(inserted)
    return dict(report=report, deployment_version=versions[0])


def main():
    destination = require_local_path(OUT / 'stream-subquery-hosted-packet-515', Path.home(), sys.platform)
    check_budgets(OUT, destination, OUT / 'logs', min_free_bytes=12*GIB,
                  reserve_bytes=128*MIB, max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
    assert not destination.exists()
    pr = read(RAW / 'postmerge-515/pull-request.json')
    assert pr['head']['sha'] == HEAD and pr['merged'] and pr['merge_commit_sha'] == MERGE
    checks = read(RAW / 'postmerge-515/checks.json')
    assert checks['total_count'] == len(checks['check_runs']) == 44
    assert len({r['id'] for r in checks['check_runs']}) == 44
    assert all(r['head_sha'] == HEAD and r['status'] == 'completed' and r['conclusion'] == 'success'
               for r in checks['check_runs'])
    statuses = read(RAW / 'postmerge-515/statuses.json')
    assert statuses['sha'] == HEAD and statuses['total_count'] == 0 and statuses['statuses'] == []
    review = read(RAW / 'postmerge-515/review-state.json')['data']['repository']['pullRequest']
    assert review['headRefOid'] == HEAD and review['merged'] and review['mergeCommit']['oid'] == MERGE
    for kind in ('reviews', 'reviewThreads'):
        assert not review[kind]['pageInfo']['hasNextPage'] and review[kind]['nodes'] == []
    comments = read(RAW / 'postmerge-515/issue-comments.json')
    assert len(comments) < 100
    bot = [r for r in comments if r['user']['login'] == 'chatgpt-codex-connector[bot]']
    assert len(bot) == 1
    state = json.loads(re.search(r'<!-- codex-review-state:v1 (.*?) -->', bot[0]['body']).group(1))['code_review']
    assert state == dict(commit_sha=HEAD, has_any_findings=False, has_unresolved_findings=False, status='completed')

    sources.selector_check()
    source = read(RAW / 'merged-sources-515.json')
    immutable, records = sources.immutable.immutable_source_map(MERGE)
    accepted = read(sources.ACCEPTED)['source_sha256']
    assert source['status'] == 'passed' and source['selector_ast_matches']
    assert len(immutable) == len(accepted) == source['source_files'] == 2291
    assert {p: r['sha256'] for p, r in immutable.items()} == accepted
    assert source['immutable_source'] == immutable
    assert all(mode in ('100644', '100755') for _, _, mode in records)
    assert set(source['trees'].values()) == {sources.TREE}
    assert source['revisions'] == dict(pr_head=HEAD, ci_merge=SYNTHETIC, merged=MERGE)
    for record in [source['accepted'], source['artifact_manifest'], source['synthetic_metadata'],
                   *source['helpers'], *source['binaries'].values()]:
        check(record)

    runtime = read(RAW / 'primary-acceptance-513-capture-20261016T051113Z.json')
    assert runtime['status'] == 'passed_all_six' and runtime['pending'] == []
    assert runtime['head'] == HEAD and runtime['synthetic'] == SYNTHETIC and runtime['tree'] == sources.TREE
    for key in ('synthetic_metadata', 'capture', 'run', 'capture_helper', 'acceptance_helper'):
        check(runtime[key])
    assert len(runtime['jobs']) == 6
    assert {r['job_id']: r['name'] for r in runtime['jobs']} == jobs.JOBS
    wheel_lanes = []
    for row in runtime['jobs']:
        for key in ('raw', 'metadata'):
            check(row[key])
        metadata = read(row['metadata']['path'])
        assert metadata['head_sha'] == HEAD and metadata['status'] == 'completed' and metadata['conclusion'] == 'success'
        text = jobs.normalized(Path(row['raw']['path']))
        assert SYNTHETIC + ':refs/remotes/pull/1560/merge' in text
        assert text.splitlines()[-1].startswith('Cleaning up orphan processes')
        if row['name'].startswith('Native Python wheel'):
            proof, offsets = jobs.machine_report(text, 'shardloom.native_python_wheel_proof.v1')
            assert proof == row['proof'] and offsets == row['normalized_offsets']
            assert proof['integration'] == dict(tests=96, failures=0, errors=0, skipped=0, status='passed')
            assert proof['status'] == proof['stage']['status'] == proof['integrity']['status'] == proof['uninstall_status'] == 'passed'
            assert proof['installed_load']['isolated_install'] and proof['installed_load']['version'] == '0.6.0'
            assert all(r['returncode'] == 0 for r in proof['steps'])
            wheel_lanes.append(row['name'])
        elif row['job_id'] == 116811770736:
            proof, offsets = jobs.machine_report(text, 'shardloom.python_test_shard_evidence.v1')
            assert proof == row['proof'] and offsets == row['normalized_offsets']
            assert proof['status'] == 'passed' and proof['test_count'] == 620 and proof['skipped_count'] == 13
            assert row['console_tests_run'] == 524 and re.search(r'^Ran 524 tests in [0-9.]+s$', text, re.M)
        else:
            groups = [list(map(int, r)) for r in re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)]
            expected = ([[947,0,0],[0,0,0],[6,0,0],[65,0,0],[44,0,0],[15,0,0]]
                        if row['job_id'] == 116811770395 else
                        [[2844,0,26],[10,0,0],[7,0,0],[7,0,0],[23,0,0],[4,0,0]])
            assert groups == row['result_groups'] == expected
            if row['job_id'] == 116811770395:
                assert row['total_passed'] == 1077
                parser_test = row['new_parser_test']
                assert 'test ' + parser_test['observed_test_path'] + ' ... ok' in text
                assert digest(jobs.source(parser_test['source'])) == parser_test['sha256']
            if row['job_id'] == 116811770368:
                assert row['total_passed'] == 2895 and len(row['new_native_tests']) == 14
                for test in row['new_native_tests']:
                    assert 'test ' + test['observed_test_path'] + ' ... ok' in text
                    assert digest(jobs.source(test['source'])) == test['sha256']
    assert len(wheel_lanes) == 3
    check(runtime['acceptance_protocol'])
    for row in runtime['wheel_binding_sources']:
        assert digest(jobs.source(row['path'])) == row['sha256']
    assert sum(len(row['methods']) for row in runtime['wheel_binding_sources']) == 96

    served_reports = dict(preview=served('preview', HEAD), production=served('production', MERGE))
    browsers = {stage: read(RAW / filename) for stage, filename in
                [('preview','preview-browser-513.json'),('production','production-browser-513.json')]}
    for stage, browser in browsers.items():
        assert browser['status'] == 'passed' and len(browser['pages']) == 4
        assert browser['search']['result_pages'] == 4 and browser['search']['query'] == 'finite subquery'
        assert browser['served_revision'] == (HEAD if stage == 'preview' else MERGE)
        assert browser['reviewed_head'] == HEAD and browser['console_warnings_errors'] == []
        check(browser['helper'])
        assert all(r['document_width'] <= r['viewport_width'] == 1280 and r['subquery_scope_present']
                   and r['resident_state_limit_present'] and r['hosted_pending_status_present'] for r in browser['pages'])
        check(browser['served_source'])
    assert browsers['production']['reviewed_head'] == HEAD and browsers['production']['served_revision'] == MERGE

    for stage, folder in [('premerge', 'premerge-514'), ('postmerge', 'postmerge-515')]:
        closeout = read(RAW / folder / 'report.json')
        assert closeout['status'] == 'passed' and closeout['stage'] == stage
        assert closeout['head'] == HEAD and closeout['checks_passed'] == 44
        assert closeout['merge'] == (MERGE if stage == 'postmerge' else None)
        assert closeout['code_review'] == state and closeout['review_threads'] == 0
        for ref in closeout['metadata'] + [closeout['helper']]:
            check(ref)
    receipt = read(RAW / 'merge-receipt-515.json')
    assert receipt['isError'] is False
    assert receipt['structuredContent']['merged'] is True
    assert receipt['structuredContent']['sha'] == MERGE

    report = dict(schema_version='shardloom.native_stream_subquery_hosted_verification.v1', status='passed',
        recorded_at=datetime.now(timezone.utc).isoformat(), pr=1560, head=HEAD, merge=MERGE,
        synthetic=SYNTHETIC, trees=source['trees'], checks_passed=44,
        native_total=2895, native_manual_exclusions=26, new_native_tests=14,
        native_public_total=1077, wheel_lanes=wheel_lanes, wheel_tests_per_lane=96,
        core_discovered=620, core_run=524, core_skipped=13, source_files_verified=2291,
        source_changes_after_original_build=source['changes_after_original_build'],
        cli_and_binding_identity_verified=True, code_review=state, review_threads=0,
        served=served_reports, browsers=browsers, interpretation=runtime['interpretation'],
        observation_limits=[
            'Production HTML retains the entire merged source around six bounded Cloudflare script insertions; JavaScript and the search entry are byte-identical.',
            'Actual browser checks prove the deployed pre-closeout wording, including its pending status; later closeout wording requires later deployment.',
            'Screenshots were inspected inline, not archived. No mobile or cross-browser matrix is claimed.',
            'The accepted premerge Full43 remains the regression observation. No additional queries were run solely for merge or deployment verification.'],
        source_version='0.6.0', publication_attempted=False, performance_claim=False, driver=identity(__file__))
    save(RAW / 'verification-515.json', report)
    files = {'hosted/' + str(p.relative_to(RAW)):p for p in RAW.rglob('*') if p.is_file()}
    helpers = [Path(__file__), Path(jobs.__file__), Path(sources.__file__), Path(sources.immutable.__file__),
               sources.FREEZER, sources.ARTIFACTS, sources.ACCEPTED,
               OUT/'capture_stream_subquery_served_513.py', OUT/'capture_stream_subquery_closeout_514.py',
               OUT/'record_stream_subquery_browser_513.py', ROOT/'scripts/local_uat_storage.py',
               OUT/'stream-subquery-acceptance-protocol-509.json',
               OUT/'stream-subquery-hosted-coverage-inventory-511.json']
    for path in helpers:
        name = 'support/' + path.name
        assert name not in files
        files[name] = path
    destination.mkdir(exist_ok=False)
    archive = destination/'native-stream-subqueries-hosted-2026-10-16.tar.xz'
    index = destination/'native-stream-subqueries-hosted-2026-10-16.json'
    members = []
    with tarfile.open(archive, 'x:xz') as stream:
        for name,path in sorted(files.items()):
            before = identity(path)
            payload = path.read_bytes()
            info = tarfile.TarInfo(name)
            info.size = len(payload)
            info.mode = 0o644
            stream.addfile(info, io.BytesIO(payload))
            assert identity(path) == before
            members.append(dict(name=name, bytes=len(payload), sha256=digest(payload)))
    with tarfile.open(archive,'r:xz') as stream:
        entries = stream.getmembers()
        assert len(entries) == len({r.name for r in entries}) == len(members)
        assert all(r.isfile() for r in entries) and {r.name for r in entries} == set(files)
        for member in members:
            payload = stream.extractfile(member['name']).read()
            assert len(payload) == member['bytes'] and digest(payload) == member['sha256']
            assert payload == files[member['name']].read_bytes()
    save(index, dict(schema_version='shardloom.native_stream_subquery_hosted_packet.v1', status='passed',
        pr=1560, head=HEAD, merge=MERGE, synthetic=SYNTHETIC, checks_passed=44,
        native_total=2895, native_manual_exclusions=26, new_native_tests=14,
        native_public_total=1077, wheel_lanes=3, wheel_tests_per_lane=96,
        core_discovered=620, core_run=524, core_skipped=13, source_files_verified=2291,
        served_responses_verified=16, production_deployment_check_complete=True,
        production_deployment_check_id=served_reports['production']['report']['deployment']['id'],
        production_version=served_reports['production']['deployment_version'],
        observation_limits=report['observation_limits'],
        archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=identity(archive)['sha256']),
        members_verified=len(members), members=members, publication_attempted=False, performance_claim=False))
    check_budgets(OUT,destination,OUT/'logs',min_free_bytes=12*GIB,
                  reserve_bytes=0,max_workspace_bytes=100*GIB,max_log_bytes=192*MIB)
    for path in (archive,index):
        target = ROOT/'docs/benchmarks/evidence'/path.name
        assert not target.exists()
        shutil.copy2(path,target)
        assert identity(path)['sha256'] == identity(target)['sha256']
    print(json.dumps(dict(status='passed',checks=44,wheel_lanes=3,sources=2291,
        served_responses=16,members=len(members),archive=identity(archive))))


if __name__ == '__main__':
    main()
