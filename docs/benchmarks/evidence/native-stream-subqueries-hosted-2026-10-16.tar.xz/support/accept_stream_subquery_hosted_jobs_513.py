"""Primary acceptance of immutable captured subquery CI logs and installed wheels."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent / 'stream-subquery-hosted-512'
LOGS = OUT / 'job-logs'
HEAD = 'b6b585a45aadd144f6b90cc2053744544518897a'
BASE = 'ff9aa27338ca9f1ff5581f5a57603400f5aec926'
SYNTHETIC = '4c4e47e105945cf13e6af9b289f88e0c93906caa'
RUN = 38850936216
JOBS = {116811770736: 'Python test shard (core)',
        116811770395: 'Rust feature matrix (native_public_surface_tests)',
        116811770056: 'Native Python wheel (py313_macos)',
        116811771033: 'Native Python wheel (py313_ubuntu)',
        116811770124: 'Native Python wheel (py310_ubuntu)',
        116811770368: 'Rust feature matrix (native_vortex_tests)'}


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def checked(ref):
    path = (LOGS / ref['path']).resolve()
    assert LOGS.resolve() in path.parents
    actual = identity(path)
    assert actual['bytes'] == ref['bytes'] and actual['sha256'] == ref['sha256']
    return path


def normalized(path):
    return '\n'.join(re.sub(r'^\d{4}-\d{2}-\d{2}T\S+Z ', '', line)
                     for line in path.read_text().lstrip('\ufeff').splitlines())


def machine_report(text, schema):
    marker = '"schema_version": "' + schema + '"'
    assert text.count(marker) == 1
    offset = text.index(marker)
    start = text.rfind('\n{\n', 0, offset) + 1
    assert start > 0
    value, length = json.JSONDecoder().raw_decode(text[start:])
    assert value['schema_version'] == schema
    return value, dict(start=start, end=start + length)


def source(path):
    return subprocess.check_output(['git', 'show', HEAD + ':' + path], cwd=ROOT)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('snapshot')
    parser.add_argument('--require-complete', action='store_true')
    args = parser.parse_args()
    assert re.fullmatch(r'capture-\d{8}T\d{6}Z', args.snapshot)
    summary_path = LOGS / args.snapshot / 'summary.json'
    summary = json.loads(summary_path.read_text())
    assert summary['status'] in ('PARTIAL', 'COMPLETE') and not summary['errors']
    assert summary['expected_head_sha'] == HEAD and summary['run_id'] == RUN
    assert len(summary['jobs']) == 6 and {r['job_id']: r['expected_name'] for r in summary['jobs']} == JOBS
    assert all(command['exit_code'] == 0 for command in summary['commands'])
    helper_path = LOGS / 'capture_hosted_job_logs_512.py'
    assert identity(helper_path)['sha256'] == '8f154099b6f72b1e9d94f9c229f8b575809d5c8859f399e5c7b00abfd89dc213'
    run_path = checked(summary['run'])
    run = json.loads(run_path.read_text())
    assert run['id'] == RUN and run['head_sha'] == HEAD
    assert any(pr['number'] == 1560 and pr['head']['sha'] == HEAD and pr['base']['sha'] == BASE
               for pr in run['pull_requests'])
    synthetic_path = OUT / 'synthetic-merge-512.json'
    synthetic = json.loads(synthetic_path.read_text())
    assert synthetic['sha'] == SYNTHETIC
    assert [p['sha'] for p in synthetic['parents']] == [BASE, HEAD]
    tree = subprocess.check_output(['git', 'rev-parse', HEAD + '^{tree}'], cwd=ROOT, text=True).strip()
    assert synthetic['tree']['sha'] == tree
    protocol_path = OUT.parent / 'stream-subquery-acceptance-protocol-509.json'
    protocol = json.loads(protocol_path.read_text())
    coverage_path = OUT.parent / 'stream-subquery-hosted-coverage-inventory-511.json'
    assert identity(coverage_path)['sha256'] == 'ddb0f15a2c4f131929c25c877e806393b5dcdc8cd1c4e43afefab9791b603741'
    coverage = json.loads(coverage_path.read_text())
    native_tests = []
    for row in coverage['required_test_declarations']:
        if not row['name'].startswith('streaming_subqueries_'):
            continue
        assert len(row['declarations']) == 1
        declaration = row['declarations'][0]
        path, line = declaration['path'], declaration['line']
        raw = source(path)
        lines = raw.decode().splitlines()
        assert 'fn ' + row['name'] + '(' in lines[line - 1]
        assert '#[test]' in [text.strip() for text in lines[max(0, line - 5):line - 1]]
        native_tests.append(dict(name=row['name'], source=path,
                                sha256=hashlib.sha256(raw).hexdigest()))
    assert len(native_tests) == len({r['name'] for r in native_tests}) == 14
    parser_source = 'shardloom-cli/src/sql_syntax.rs'
    parser_name = 'projected_exists_subqueries_use_predicate_lowering'
    parser_raw = source(parser_source)
    assert 'fn ' + parser_name + '(' in parser_raw.decode()
    parser_test = dict(name=parser_name, source=parser_source,
                       sha256=hashlib.sha256(parser_raw).hexdigest())
    assert set(protocol['native_required_tests']) == {r['name'] for r in native_tests} | {parser_name}
    binding_sources, methods = [], 0
    for path in sorted((ROOT / 'python/tests').glob('test_native*binding.py')):
        relative = path.relative_to(ROOT).as_posix()
        raw = source(relative)
        names = [node.name for node in ast.walk(ast.parse(raw))
                 if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')]
        methods += len(names)
        binding_sources.append(dict(path=relative, sha256=hashlib.sha256(raw).hexdigest(), methods=names))
    assert methods == 96
    proof_source = source('scripts/prove_native_python_wheel.py').decode()
    assert 'pattern="test_native*binding.py"' in proof_source
    assert 'SHARDLOOM_REQUIRE_NATIVE_PYTHON="1"' in proof_source
    accepted, pending = [], []
    for row in summary['jobs']:
        metadata_path = checked(row['metadata'])
        metadata = json.loads(metadata_path.read_text())
        assert metadata['id'] == row['job_id'] and metadata['run_id'] == RUN
        assert metadata['head_sha'] == HEAD and metadata['name'] == JOBS[row['job_id']]
        if row['capture_state'] == 'pending':
            assert metadata['status'] != 'completed' and row['log'] is None
            pending.append(metadata['name'])
            continue
        assert row['capture_state'] == 'captured'
        assert metadata['status'] == 'completed' and metadata['conclusion'] == 'success'
        assert all(step['conclusion'] in ('success', 'skipped') for step in metadata['steps'])
        log_path = checked(row['log'])
        assert log_path.stat().st_size <= 12 * 1024 * 1024
        text = normalized(log_path)
        assert SYNTHETIC + ':refs/remotes/pull/1560/merge' in text
        assert text.splitlines()[-1].startswith('Cleaning up orphan processes')
        assert not re.search(r'^test .* \.\.\. FAILED$|^test result: FAILED', text, re.M)
        record = dict(job_id=row['job_id'], name=metadata['name'], raw=identity(log_path),
                      metadata=identity(metadata_path), synthetic_tree_matches_reviewed_tree=True)
        if metadata['name'].startswith('Native Python wheel'):
            result, offsets = machine_report(text, 'shardloom.native_python_wheel_proof.v1')
            assert result == row['analysis']['wheel_proof']
            assert result == json.loads(checked(row['analysis']['wheel_proof_file']).read_text())
            assert result['status'] == result['stage']['status'] == result['integrity']['status'] == 'passed'
            assert result['integration'] == dict(tests=96, failures=0, errors=0, skipped=0, status='passed')
            assert result['installed_load']['isolated_install'] and result['installed_load']['version'] == '0.6.0'
            assert result['uninstall_status'] == 'passed'
            assert result['publication_attempted'] is False and result['performance_claim'] is False
            assert all(step['returncode'] == 0 for step in result['steps'])
            steps = {step['name']: step for step in result['steps']}
            assert {'load', 'integration', 'install', 'uninstall', 'verify_uninstalled'} <= steps.keys()
            assert '-I' in steps['load']['command'] and '-I' in steps['integration']['command']
            assert result['integrity']['native_library_sha256'] in steps['load']['command']
            assert result['integrity']['cli_sha256'] in steps['load']['command']
            assert result['integrity']['load_verified'] is False
            if 'ubuntu' in metadata['name']:
                assert result['linux_audit']['status'] == 'passed' and result['integrity']['linux_audit_verified']
            assert result['installed_load']['python'].startswith('3.10.' if 'py310' in metadata['name'] else '3.13.')
            record.update(proof=result, normalized_offsets=offsets)
        elif row['job_id'] == 116811770736:
            result, offsets = machine_report(text, 'shardloom.python_test_shard_evidence.v1')
            assert result['status'] == 'passed' and result['test_count'] == 620 and result['skipped_count'] == 13
            assert result['failure_count'] == result['error_count'] == 0
            assert {'python.tests.test_native_subquery_binding', 'python.tests.test_native_streaming_uat_compression'} <= set(result['modules'])
            assert re.search(r'^Ran 524 tests in [0-9.]+s$', text, re.M) and 'OK (skipped=13)' in text
            assert result['module_count'] == len(result['modules']) == 56
            assert result['external_engine_invoked'] is result['fallback_attempted'] is False
            record.update(proof=result, normalized_offsets=offsets, console_tests_run=524)
        else:
            groups = [tuple(map(int, r)) for r in re.findall(
                r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)]
            if row['job_id'] == 116811770395:
                assert groups == [(947, 0, 0), (0, 0, 0), (6, 0, 0), (65, 0, 0), (44, 0, 0), (15, 0, 0)]
                matches = re.findall(r'^test (.*::' + re.escape(parser_name) + r') \.\.\. ok$', text, re.M)
                assert len(matches) == 1
                parser_test['observed_test_path'] = matches[0]
                record.update(new_parser_test=parser_test)
            else:
                assert groups == [(2844, 0, 26), (10, 0, 0), (7, 0, 0), (7, 0, 0), (23, 0, 0), (4, 0, 0)], groups
                for test in native_tests:
                    matches = re.findall(r'^test (.*::' + re.escape(test['name']) + r') \.\.\. ok$', text, re.M)
                    assert len(matches) == 1, test['name']
                    test['observed_test_path'] = matches[0]
                ignored = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', text, re.M)
                assert len(ignored) == 26
                record.update(new_native_tests=native_tests, ignored_test_reasons=ignored)
            record.update(result_groups=groups, total_passed=sum(r[0] for r in groups))
        accepted.append(record)
    assert set(pending) == set(summary['pending_job_names'])
    if args.require_complete:
        assert len(accepted) == 6 and not pending and summary['status'] == 'COMPLETE'
    report = dict(schema_version='shardloom.native_stream_subquery_primary_hosted_jobs.v1',
        status='passed_all_six' if not pending else 'passed_completed_subset', head=HEAD,
        synthetic=SYNTHETIC, tree=tree, synthetic_metadata=identity(synthetic_path),
        capture=identity(summary_path), run=identity(run_path), capture_helper=identity(helper_path),
        acceptance_helper=identity(Path(__file__)), jobs=accepted, pending=pending,
        wheel_binding_sources=binding_sources, acceptance_protocol=identity(protocol_path),
        interpretation={
            'integrity_load_verified_false': 'Archive-integrity verification does not load a library. The separate isolated load step verifies package location, runtime version and both native-library/CLI hashes.',
            'individual_binding_names': 'Wheel evidence embeds the aggregate 96-test report. Individual passing method names are not printed in the outer hosted log. Exact source discovery and zero skips provide the coverage linkage.',
            'core_skips': 'Hosted core records 13 skips, compared with 11 locally; both discover 620 tests in 56 modules, while the console records 524 tests run. Class-level native-binding skips are not equivalent to individual executed methods. Installed native-wheel integration records zero skips.',
            'scope': 'Only the listed immutable job captures. Overall CI, review state, final merge and production deployment are separate checks.'})
    destination = OUT / ('primary-acceptance-513-' + args.snapshot + '.json')
    destination.open('x').write(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(status=report['status'], accepted_jobs=len(accepted), pending=pending,
        wheel_lanes=sum(r['name'].startswith('Native Python wheel') for r in accepted),
        report=str(destination))))


if __name__ == '__main__':
    main()
