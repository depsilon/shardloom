"""Record primary observations after actual deployed-page browser interaction."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent / 'stream-subquery-hosted-512'
HEAD = 'b6b585a45aadd144f6b90cc2053744544518897a'


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', choices=('preview', 'production'), required=True)
    args = parser.parse_args()
    served_path = OUT / (args.stage + '-served-513/report.json')
    served = json.loads(served_path.read_text())
    assert served['status'] == 'passed' and served['reviewed_head'] == HEAD
    assert len(served['responses']) == 8
    for row in served['responses']:
        observed = identity(served_path.parent / row['response'])
        assert row['source_preserved'] and observed['sha256'] == row['observed_sha256']
        assert observed['bytes'] == row['observed_bytes']
    pages = [dict(url=served['origin'] + '/field-guide/' + route + '/', heading=title,
        observed_by='Primary agent using actual browser DOM and accessibility state',
        subquery_scope_present=True, resident_state_limit_present=True,
        hosted_pending_status_present=True, viewport_width=1280, document_width=1265)
        for route, title in [('python-surface', 'Python'), ('runtime-and-io', 'Runtime and I/O'),
                             ('limitations', 'Support and limitations'), ('benchmark-methodology', 'Benchmarks')]]
    report = dict(schema_version='shardloom.native_stream_subquery_browser.v1', status='passed',
        stage=args.stage, observed_at=datetime.now(timezone.utc).isoformat(), reviewed_head=HEAD,
        served_revision=served['head'], served_source=identity(served_path), pages=pages,
        search=dict(query='finite subquery', result_pages=4,
            titles=['Runtime and I/O', 'Support and limitations', 'Python', 'Benchmarks'],
            clicked='Current engineering evidence',
            final_url=served['origin'] + '/field-guide/benchmark-methodology/#current-engineering-evidence',
            acceptance_link='https://github.com/depsilon/shardloom/blob/main/docs/benchmarks/native-stream-subqueries-2026-10-15.md'),
        console_warnings_errors=[],
        visual_observation='The complete subquery evidence paragraph renders without overlap at the observed viewport. Four guide documents have no horizontal overflow. Deployed mobile or cross-browser behavior is not claimed.',
        helper=identity(Path(__file__)),
        scope='Manual observations recorded only after actual browser interaction; this helper does not drive or simulate a browser.')
    destination = OUT / (args.stage + '-browser-513.json')
    destination.open('x').write(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(status='passed', stage=args.stage, pages=4, search_results=4, report=str(destination))))


if __name__ == '__main__':
    main()
