<!-- SPDX-License-Identifier: Apache-2.0 -->

# ShardLoom User Surface Index

Status: canonical agent-facing v0.1.x user-surface reference.

Schema marker: `shardloom.user_surface_index.v1`.

This file is the durable starting point for agents and humans that need to know which ShardLoom
commands, Python helpers, SQL forms, local inputs, local outputs, and diagnostics exist. It is an
index, not a runtime claim. Runtime support still depends on the command registry, capability
reports, execution certificates, feature gates, and no-fallback evidence.

All ShardLoom user surfaces must preserve:

```text
fallback_attempted=false
external_engine_invoked=false
```

## Source Of Truth Order

Use this order before executing or documenting a workflow:

1. Read this file for the stable user-surface map.
2. Read `docs/reference/shardloom-user-surface-index.json` for machine-readable surface groups.
3. Run `shardloom command-metadata --format json` for the exhaustive CLI command inventory.
4. Run `shardloom command-metadata <command> --format json` or
   `shardloom help <command> --format json` for one CLI command.
5. Run `shardloom agent-contract-pack --format json` for report-order and safety defaults.
6. Use `ctx.capabilities()` / `ShardLoomClient.capabilities(...)` for Python capability posture.
7. Use `ctx.user_surface_graduation_matrix()`, `ctx.front_door_parity_matrix()`, and
   `ctx.front_door_semantic_surface_matrix()` before treating a Python, SQL, DataFrame-style, or
   CLI surface as promoted user workflow support.

The CLI command list is intentionally not hand-copied here. The exhaustive registry has 214 rows
and lives in `shardloom-cli/src/command_registry.rs`; the side-effect-free command
`shardloom command-metadata --format json` renders those rows for agents without scraping Rust
source or human text.

## Semantic Claim Surface

ShardLoom does not claim broad pandas, Polars, DataFrame, or SQL-standard/ANSI-style compatibility
labels. The supported claim is narrower: ShardLoom exposes a familiar
Python/DataFrame-style front door and a SQL-standard-inspired SELECT-query subset that lower
admitted operations into ShardLoom-native/Vortex-native routes. Unsupported pandas/Polars-style or
SQL behavior must return deterministic diagnostics with:

```text
fallback_attempted=false
external_engine_invoked=false
```

Use `ctx.front_door_semantic_surface_matrix()` for the agent-facing semantic matrix. It covers the
documented DataFrame-style families (construction/read APIs, projection, filtering, type system,
casts, missing data, aggregation, joins, ordering/window-ish behavior, reshaping, materialization,
index semantics, expression/callable APIs, determinism, errors, and fallback boundary) and SQL
families (parser scope, binder/name resolution, type system, casts, NULL semantics, relational
semantics, operators, aggregates, joins, subqueries, windows, ordering/collation, errors, and
fallback boundary).

## Normal Python Entry Points

Normal application code starts with:

```python
import shardloom as sl

ctx = sl.context()
```

`sl.context(...)` and `sl.session(...)` construct clients only. They do not read data, probe object
stores, touch catalogs, execute SQL, invoke external engines, or create hidden global state.

Use `repo_root`, `profile_order`, `SHARDLOOM_BIN`, or `SHARDLOOM_REPO_ROOT` only when a source
checkout, CI job, managed environment, or benchmark reproduction needs explicit CLI resolution.
Normal resolved clients use a private local `python-worker` transport when available to amortize
CLI process startup across repeated calls. This is not a separate execution route: every response is
still the command's normal typed envelope with `fallback_attempted=false` and
`external_engine_invoked=false` evidence from the underlying ShardLoom/Vortex route. Set
`SHARDLOOM_PERSISTENT_WORKER=0` to force one-shot subprocess transport for diagnostics.

## Resident Native Results

The Unix `vortex-local-primitives` build supports typed immutable memory intake
through `ResidentMemorySource`, caller-owned prepared native arrays and bounded
JSON, and source-free SQL collection through `shardloom run sql --sql "SELECT 1 AS value"
--request collect --bounded true --format json`. Declared local files use the same
public run command with `--input <path> --input-format <format>`. Direct single-file count/projection/filter
collect calls can retain prepared operations in the existing public worker.
See [Resident Native Results](resident-native-results.md) for exact types, bounds,
ownership, source-change behavior, and examples. This is a bounded native Rust and
CLI-backed transport surface; it does not add a native Python binding or establish
performance claims.

Current source also exposes `shardloom.from_batches` and
`ShardLoomContext.from_batches` for explicitly typed resident input, plus
`LazyFrame.iter_batches` and `SqlWorkflow.iter_batches` for acknowledged
incremental results. Those adapters merged in PR #1526 after local and hosted
checks; published v0.4.0 predates them. The [batch API contract](../architecture/native-bounded-adapters-2026-10-06.md)
records row/frame/schema limits, one-shot versus factory inputs, final-report
completion and early-close cleanup. Default resident input must fit the shared native grant;
batch-shaped output does not make all operator state spillable.

The separate [completion-aware input contract](../architecture/native-input-completion-2026-10-07.md)
admits `streaming=True` for one finite source used once through pure
Scan/Filter/Project, with incremental results, bounded small collection or one
native Vortex destination. It retains at most one native input batch, permitting
cumulative input above the shared grant within the existing finite intake limits.
Typed intake and output compaction remain charged; result and sink reservations
remain separate. Unsupported plans reject before producer consumption, and success
requires observed end-of-input. [Corrected local acceptance](../benchmarks/native-fsst-admission-2026-10-07.md)
and independent packet inspection pass. Final integration is tracked in
[PR #1530](https://github.com/depsilon/shardloom/pull/1530).
Resident input remains the default; no input spill or process-RSS bound is added.

Prepared aggregates expose bounded `collect_jsonl` and synchronous `for_each_batch`
with `vortex-local-primitives`. File delivery additionally requires `vortex-write`:
`write` and cancellable `write_controlled`. Computed aggregate and ordered file
outputs use bounded native batches through all eight admitted local formats,
including existing COUNT/DISTINCT/numeric-sort spill families. These file writes
can exceed the independent small-collection limits; they still require admitted
flat types, resource grants and a new destination. Flat aggregate collection and
all eight local writers share native aggregate admission, retaining complete
filter/group/measure/HAVING/order/limit stages plus declared source schemas and
resources. Explicit `NULLS FIRST` and `NULLS LAST` apply independently of sort
direction; Python `sort(..., nulls="first")` and `sort(..., nulls="last")` carry that policy
through. Small JSONL collection returns the complete result only within 65,536
rows and 8 MiB; larger results use streaming writers or, in the accepted local
source branch, the incremental Python consumer above. See the
[computed-result streaming contract](../architecture/native-workflow-streaming-2026-10-01.md).

Single-file sorting can use explicitly admitted temporary Vortex runs, including
the flat typed keys scoped by the [typed key contract](../architecture/native-typed-keys-2026-10-03.md).
See [Native Query Sort Spill](native-query-spill.md) for supported keys, bounded
output, workspace quotas, cancellation, and recovery. The policy is opt-in and
does not enable group, join or window state spill.

## Python Reads

Use `ctx.read(path)` for ordinary local input. It infers:

- `.csv` -> CSV compatibility source.
- `.json`, `.jsonl`, `.ndjson` -> flat JSON/JSONL/NDJSON compatibility source.
- `.parquet` -> Parquet compatibility source when the matching feature-gated build is present.
- `.arrow`, `.ipc`, `.feather` -> Arrow IPC compatibility source when feature-gated.
- `.avro` -> Avro compatibility source when feature-gated.
- `.orc` -> ORC compatibility source when feature-gated.
- `.vortex` -> native Vortex source.
- `.vortex-manifest` -> native Vortex manifest source; manifest `inputs`/`paths` entries bind as
  local Vortex parts.
- local directories of `.vortex` files -> native Vortex partitioned source when the route requests
  native Vortex input.

Explicit helpers remain available when an agent needs a pinned adapter:

- `ctx.read_csv(...)`
- `ctx.read_json(...)`
- `ctx.read_parquet(...)`
- `ctx.read_arrow_ipc(...)`
- `ctx.read_avro(...)`
- `ctx.read_orc(...)`
- `ctx.read_vortex(...)`

Feature-gated readers return deterministic adapter blockers when unavailable. They must not invoke
another engine as a fallback.

Every normal Python execution or route result exposes `activation_summary`. Use it before scraping
raw envelopes when checking route ID/status, execution mode, native Vortex activation, required
feature gate, parallelism, scan/pushdown signals, source-state reuse, decode/materialization,
sink/write status, fallback/external-engine flags, claim gate, and unsupported diagnostics.

For direct `.vortex`, `.vortex-manifest`, or local `.vortex` directory inputs, scoped primitive
routes cover
count/filter/project/limit, no-argument row-level distinct, bounded source-order tail, and
deterministic row-count
`sample(n=..., seed=...|random_state=<int>, weights="<numeric-column>", replace=False|True)` or
fractional
`sample(frac|fraction=..., seed=...|random_state=<int>, weights="<numeric-column>", replace=False|True)`, and scoped
`melt(id_vars=..., value_vars=...)` over heterogeneous scalar value columns plus scoped
single-column and same-length multi-column `explode(...)` over declared list/fixed-size-list
columns with scalar, nullable, list, or struct element values. These routes remain scoped evidence,
not broad arbitrary Vortex SQL/DataFrame parity or performance claims.

## Python Query Builder

Admitted local-source and generated-source workflows use `LazyFrame` and related source
objects. Common admitted methods include:

- Filters and predicates: `filter(...)`, `where(...)`, `query(...)` without unsupported keyword
  arguments, `having(...)` after an aggregate.
- Projection and schema rewrites: `select(...)`, `project(...)`, `rename(...)`,
  `rename_columns(...)`, `drop(...)`, `drop_columns(...)`, `astype(...)`.
- Row bounds: `limit(...)`, `head(...)`, `take(...)`, admitted `tail(...)`, and deterministic
  `sample(n=..., seed=...|random_state=<int>, weights="<numeric-column>", replace=False|True)` or
  fractional
  `sample(frac|fraction=..., seed=...|random_state=<int>, weights="<numeric-column>", replace=False|True)`.
- Aggregation: `group_by(...).agg(...)`, `groupby(...).agg(...)`, scalar `agg(...)`,
  `aggregate(...)`, `nunique(...)`, `value_counts(...)`.
- Joins and set operations: admitted `join(...)`, `merge(...)` when it lowers to the same join,
  `concat(...)` when it lowers to `UNION ALL`, `union(...)`, `union_all(...)`,
  `intersect(...)`, `except_rows(...)`, `subtract(...)`.
- Ordering and top N: `sort(...)`, `order_by(...)`, `sort_by(...)`, `sort_values(...)`,
  admitted index metadata `set_index(..., drop=False)`, source-order-preserving
  `reset_index(drop=True)`/`sort_index(ascending=True)`, `nlargest(...)`, `nsmallest(...)`.
- Windows: admitted fixed-row `rolling(...).sum(...)`, `mean(...)`, `count(...)`, `min(...)`, and
  `max(...)` use source order, valid-observation `min_periods`, and ShardLoom-native window state.
- Null and duplicate helpers: `dropna(...)`, `fillna(...)`, `fill_null(...)`, `isna(...)`,
  `isnull(...)`, `notna(...)`, `notnull(...)`, `distinct()`, `drop_duplicates()`, `unique()`,
  admitted `drop_duplicates(subset=..., keep="first"|"last"|False)` retained-row deduplication,
  admitted `duplicated(subset=..., keep="first"|"last"|False)` duplicate masks, and
  schema-declared scalar/per-column literal `fillna`/`fill_null` projection rewrites for
  `axis=0`/`index` or projection-equivalent `axis=1`/`columns` spellings, plus admitted
  source-order `fillna(method="ffill", limit=<optional positive int>)`/`fill_null(...)`
  forward-fill rewrites.
- Reshape: admitted `melt(id_vars=..., value_vars=..., var_name=..., value_name=...)` for explicit
  flat scalar id columns and heterogeneous scalar value columns through the native/prepared Vortex
  melt primitive; `ignore_index=False` adds an explicit source-order row-number column rather than
  relying on hidden pandas index state. Admitted `explode("list_column")` and same-length
  multi-column list/fixed-size-list `explode("a", "b", ...)` lower through the native/prepared
  Vortex explode primitive with scalar, nullable, list, or struct element values, cardinality
  evidence, and null-shape evidence; admitted `explode("items.field")` projects one field from
  list-of-struct elements. Current source builds carry bounded static nested
  payloads through admitted relational stages and ordered/repeated explode; see
  the [nested composition contract](../architecture/native-nested-composition-2026-10-02.md).
  Vortex, JSON, JSONL, Arrow IPC, Parquet and Avro accept representable nested
  output. The [shared native workflow](../architecture/native-typed-reductions-2026-10-04.md)
  additionally streams nested CSV values as quoted JSON text cells, with NULL parents
  represented by empty cells; CSV does not persist nested dtypes. The pinned ORC
  writer rejects nested output. The subsequent [native nested keys
  and retained state contract](../architecture/native-nested-keys-state-2026-10-04.md)
  admits static List/FixedSizeList/Struct relational keys and finite selected
  nested-value unary operations. Its `native_nested_keys_state` section records
  that subsequent contract; older payload/key section flags continue to
  describe their original unit scope. The new contract has
  [local acceptance](../benchmarks/native-nested-keys-state-full43-2026-10-04.md)
  with independently verified complete results and ownership evidence, followed
  by hosted integration. General Variant/extension operations,
  nested arithmetic/string operations, broader aggregate/window
  behavior, adapters and general state spill remain separate boundaries.
  Binary, Decimal128 (precision 1–38, scale 0–precision), Date32 and timezone-free
  microsecond timestamps are admitted payloads, including nested leaves. The
  [typed key contract](../architecture/native-typed-keys-2026-10-03.md) admits
  flat equality, hashing and ordering for these types through joins, sets, groups,
  windows and subqueries, plus COUNT/COUNT DISTINCT/MIN/MAX and scoped comparisons
  and expressions; Decimal key metadata must match. The
  [typed expression contract](../architecture/native-typed-expressions-2026-10-03.md)
  separately admits explicit casts and scoped exact decimal/binary/calendar
  operations. Flat retained state follows the
  [typed unary contract](../architecture/native-typed-unary-2026-10-03.md). The
  subsequent nested contract extends equality, hashing and ordering for static
  List/FixedSizeList/Struct keys through the existing join, set, group, sort,
  window and subquery kernels, with COUNT/COUNT DISTINCT/MIN/MAX and comparisons,
  NULL tests and selected CASE/COALESCE/NULLIF results. Exact compatible
  recursive schemas require matching field names/order, list identity and fixed
  widths, leaf widths, decimal precision/scale and temporal identity; recursive
  nullability is ignored. It also admits selected nested DISTINCT/duplicate
  selection and masks, tail, sampling, parent forward-fill, lossless same-shape
  melt and rolling COUNT. Do not infer broader key coercion or unary state from
  those operations.
  The earlier [typed unary acceptance report](../benchmarks/native-typed-unary-full43-2026-10-03.md)
  records 2,700 new unary checks within the complete 9,300-check public cohort;
  hosted acceptance and the inconclusive Q9 performance observation remain explicit.
  Binary supports
  all eight writers; ORC rejects decimal and temporal payloads. Text output uses
  explicit typed encodings; see the [typed payload contract](../architecture/native-typed-payloads-2026-10-03.md).
  In the JSON index, `native_typed_keys` and `native_typed_unary` record their
  individual capabilities and link related contracts. Older payload/key flags
  retain the scope of their original contracts; the combined
  `typed_keys_arithmetic_and_unary_state` flag does not grant unrestricted typed
  composition. Use the separate contracts for admitted operation/type pairs.
  The [typed key acceptance report](../benchmarks/native-typed-keys-full43-2026-10-03.md)
  records local verification; hosted integration is recorded in the
  [completed phase ledger](../architecture/phased-execution-completed-ledger.md).
  Admitted `pivot(...)` / `pivot_table(...)` over one
  index column, one pivot column, and one value column lower through the native/prepared Vortex
  pivot primitive. `pivot_table` admits one aggregate from `first`, `sum`, `count`, `mean`, `min`, or `max`
  plus admitted `fill_value`, `dropna`, `margins`, and `margins_name` output policy; multi-level
  nested-field accessor explode, multi-index/multi-value pivot, custom pivot aggregates,
  hidden index-state reshape, and broad reshape parity remain deterministic blockers.
  Current source builds compose scalar pivot stages with preceding and following
  native operators, including successive pivot/melt stages and correlated inner
  queries. SQL spells the stage as `PIVOT((SELECT ...), '<options JSON>')`.
  Actual domains bind during execution; inspection and preparation stay inert.
  Empty input retains the index field and any declared margins field; an absent
  named domain fails explicitly. Representable scalar output can use all eight local
  writers within the existing 128-field and memory limits; decimal output retains
  the explicit ORC denial. Pivot-state spill and
  cross-call answer reuse are unsupported. See the
  [dynamic pivot ownership contract](../architecture/native-dynamic-pivot-composition-2026-10-03.md).
  Source builds after published v0.4.0 also admit static List, FixedSizeList and Struct
  index, domain and selected-value roles. Nested cells support `first`, `first_unique`,
  `count`, `min` and `max`; `first_unique` accepts repeated equal complete values
  and rejects conflicts. Nested extrema skip NULL parents and use the shared child-NULL
  ordering. Python `pivot()` and `pivot_table(aggfunc="first")` retain their
  `first_unique` alias, while SQL's explicit `first` selects the first row, including NULL.
  Nested SUM/MEAN, nested-index margins and pivot-state spill remain unsupported;
  nested MIN/MAX margins require a UTF-8 index. Nested cells accept absent or NULL
  fill only. Representable nested results use Vortex, Parquet, Arrow IPC, Avro,
  JSON and JSONL; CSV translates nested values to quoted JSON text and ORC rejects nested
  output. The 128-field, collection and memory limits still apply. Complete local
  workflow, resource and regression acceptance [passes](../benchmarks/native-nested-pivot-state-full43-2026-10-06.md),
  and [hosted integration](../benchmarks/evidence/native-nested-pivot-state-hosted-2026-10-06.json)
  is complete in PR #1525. Published v0.4.0
  packages predate this source support. See the [nested pivot state contract](../architecture/native-nested-pivot-state-2026-10-06.md).
- Windows: admitted `rolling(window=<positive int>, min_periods<=window, center=True|False).sum/mean/count/min/max(column, alias=...)` for one scalar source-order column through the native/prepared Vortex rolling-window
  primitive; `sum`/`mean`/`min`/`max` require numeric inputs, `count` admits scalar rows, centered windows
  use bounded lookahead evidence, and time/calendar windows, custom frames, callbacks, and broad pandas rolling parity remain deterministic
  blockers.
- Conditional and value rewrites: admitted typed scalar/null `mask(predicate, scalar-or-null)`,
  `replace(old, scalar-or-null)`/column-mapped full-cell scalar/null replacement, admitted UTF-8
  `replace(pattern, replacement, regex=True)`, and in-place UTF-8
  `with_column("col", col("col").replace(...))` string replacement when the schema and projection
  admit the native Vortex expression-project primitive; broad pandas alignment, callable,
  method/limit, nested operations outside the finite [nested key and retained-state
  contract](../architecture/native-nested-keys-state-2026-10-04.md), or mixed-dtype
  variants remain deterministic blockers.
  Flat binary, Decimal128, Date32 and timestamp-microsecond payloads also retain
  their declared types through duplicate selection/masks, tail/sample,
  replacement/forward-fill, lossless melt, rolling COUNT and scoped pivot
  first/first-unique/COUNT. Python bytes, Decimal, date and datetime literals
  lower to exact native declarations. Legacy primitive predicates and typed
  sampling-weight restrictions still apply; see the
  [typed unary contract](../architecture/native-typed-unary-2026-10-03.md).
- Exact reductions: the [typed reduction contract](../architecture/native-typed-reductions-2026-10-04.md)
  adds computed arguments to COUNT, COUNT DISTINCT, SUM, AVG, MIN and MAX through
  the shared native projection and aggregate. Decimal SUM returns
  `decimal128(38,input_scale)`; AVG returns `decimal128(38,max(input_scale,6))`
  and rejects inexact division. MIN/MAX preserve the input decimal type.
  The same policies apply to source-order rolling sum/mean/min/max and numeric
  pivot cells/margins. Grouped reductions skip NULLs; numeric pivot NULLs still
  fail. Centered rolling uses bounded lookahead and stops before unused
  end-of-input frames once its limit is reached. Fully untyped NULL projections
  use a nullable boolean carrier; explicitly typed NULLs retain their type.
  Complete public workflow and Full43 regression acceptance is recorded in the
  [revised engine report](../benchmarks/native-typed-reductions-full43-2026-10-05.md),
  with hosted integration in PR #1518 and no speedup claim. The JSON index records
  this unit separately as `native_typed_reductions`; older unit flags retain their
  original scope. [Analytic frames](../architecture/native-analytic-frames-2026-10-05.md)
  have a separate completed scope; general state spill remains open.
- Computed columns: `with_column(...)`, `with_columns(...)`, `assign(...)` when the expression
  lowers to the admitted ShardLoom expression surface.
- Scoped expression runtime: `eval("amount = amount + 5")`-style in-place numeric scalar
  assignment and `transform({"amount": sl.col("amount") + 5})` mapping-style in-place numeric
  assignment through the native/prepared Vortex expression-project primitive. `map(...)` and
  `applymap(...)` admit explicit `sl.column_transform(...)` wrappers, and `map_rows(...)` admits
  explicit `sl.row_transform(...)` wrappers for the same declarative rewrite route. Python/numexpr
  engines, arbitrary expression trees, shape-changing transforms, cell/element/row callables, and
  row UDFs remain deterministic blockers.
- Plan composition: `apply(sl.plan_transform(...))` and `pipe(sl.plan_transform(...))` when the
  transform returns a ShardLoom
  `LazyFrame`; unwrapped Python callables and data UDFs remain deterministic blockers.
- Local execution and writes: bounded `collect(...)`, `run(...)`, `route(...)`, `prepare(...)`,
  `write(...)`, `write_json(...)` (one JSON array), `write_jsonl(...)`, `write_csv(...)`,
  feature-gated `write_parquet(...)`,
  `write_arrow_ipc(...)`, `write_avro(...)`, `write_orc(...)`, `write_vortex(...)`, and
  `fanout(...)`. JSON and JSONL text sinks do not preserve static type or Vortex layout metadata.
  Local JSONL/CSV fanout uses staged multi-target commit and exposes
  target-level commit, cleanup, and no-fallback evidence.
- Bounded inspection: `schema(...)`, `describe_schema(...)`, `validate_schema(...)`,
  `schema_contract(...)`, `data_quality_check(...)`, `data_quality(...)`,
  `data_quality_summary(...)`, admitted `describe(...)`, `profile(...)`, `preview(...)`, `display(...)`,
  `to_python_objects(...)`, optional bounded `to_pandas(...)`, `to_arrow(...)`,
  `to_arrow_table(...)`, `to_arrow_ipc(...)`, and `to_numpy(...)`.

The optional pandas, PyArrow, and NumPy materialization helpers are decoded result containers, not
execution engines.

## Python Expressions

Expression helpers are admitted SQL/Python front-door builders:

- Column references: `sl.col(...)`, `sl.column(...)`, `sl.outer(...)`.
- Comparison and boolean composition through Python operators, `&`, `|`, and `~`.
- Null and membership: `is_null()`, `is_not_null()`, `is_distinct_from(...)`,
  `is_not_distinct_from(...)`, `isin(...)`, `not_in(...)`, `between(...)`.
- Source subqueries: `isin_source(...)`, `not_in_source(...)`, `any_source(...)`,
  `all_source(...)`, `exists_source(...)`, `not_exists_source(...)`, `row_in(...)`,
  `row_not_in(...)`, `row_in_source(...)`, `row_not_in_source(...)`.
- Scalar values: `sl.scalar_subquery(frame_or_sql_workflow)` preserves the inner
  query's input declarations through expression composition. Current source
  builds after v0.4.0 admit one static output column, typed NULL for zero rows,
  the value for one row and a cardinality error for multiple rows. Explicit
  `outer.<column>` correlation and selected CASE/COALESCE evaluation follow the
  [scalar-subquery contract](../architecture/native-scalar-subqueries-2026-10-05.md).
  Published v0.4.0 packages predate this addition; dynamic-pivot-dependent scalar
  schemas and lateral relations remain unsupported.
- Strings and binary helpers: `contains(...)`, `startswith(...)`, `endswith(...)`,
  `like(...)`, `rlike(...)`, `lower()`, `upper()`, `trim()`, `length()`, `concat(...)`,
  `substr(...)`, `substring(...)`, `left(...)`, `right(...)`, `replace(...)`, `unhex(...)`,
  `from_base64(...)`, `byte_length(...)`.
- Numeric, temporal, and casts: `abs(...)`, `floor(...)`, `ceil(...)`, `round(...)`,
  `cast(...)`, `try_cast(...)`, `interval_days(...)`, `interval_hours(...)`,
  `interval_minutes(...)`, `interval_seconds(...)`, date and timestamp add/diff/extract helpers.
- Projection helpers: `case_when(...)`, `count_distinct(...)`, `null_if(...)`, `array(...)`,
  `struct(...)`.
- Scoped ranking windows: `row_number(...)`, `rank(...)`, `dense_rank(...)`.

Unsupported expression forms must return deterministic blockers or raise local validation errors
before execution.

## Generated And Source-Free Inputs

Source-free helpers are ShardLoom-generated inputs, not external-engine shortcuts:

- `ctx.from_rows(...)` / `sl.from_rows(...)`
- `ctx.literal_table(...)` / `sl.literal_table(...)`
- `ctx.range(...)` / `sl.range(...)`
- `ctx.sequence(...)` / `sl.sequence(...)`
- `ctx.calendar(...)` / `sl.calendar(...)`
- `ctx.sql_values(...)` / `sl.sql_values(...)`
- `ctx.sql_literal_select(...)` / `sl.sql_literal_select(...)`
- `sl.dataframe_source_free_projection(...)`
- `sl.dataframe_generated_with_column(...)`

They can write local JSON arrays, JSONL, or CSV by default and feature-gated structured outputs when
the build admits the sink. They do not read an input dataset.

## SQL Surface

SQL is a frontend into ShardLoom planning and execution. It is not DataFusion, DuckDB, Spark,
pandas, Polars, or another external execution engine.

Entry points:

- `ctx.sql("SELECT ...")`
- `ctx.sql("SELECT ... FROM hits ...", input="hits.vortex")` for a declared Vortex input when
  SQL uses a logical table name.
- `sl.sql("SELECT ...")`
- `shardloom run sql --sql "SELECT 1 AS value" --request collect --bounded true --format json`
  for source-free SQL collection.
- `shardloom run sql --input events.csv --input-format csv --sql "SELECT * FROM events" --request collect --bounded true --format json`
  for a declared local-file input.

Admitted forms include local-source `SELECT` over local file references, declared Vortex
inputs bound to logical table names, admitted projection, filter, group-by, having, order, limit,
joins, set operations, bounded subquery predicates, source-free `VALUES`, source-free literal
`SELECT`, and generated range forms such as `generate_series` or `range` where the local runtime
admits them.

The [native relational contract](../architecture/native-relational-workflows-2026-10-01.md)
records complete collection and local writes for admitted joins, UNION/INTERSECT/EXCEPT,
analytic ranking/navigation/distribution windows and scoped predicate subqueries.
SQL, DataFrame and CLI calls share retained native execution, all-source generation
checks and declared adapter/schema propagation. Use `route(..., bounded=True)` to
inspect a shape without source I/O. The
[composition contract](../architecture/native-relational-composition-2026-10-02.md)
extends that same tree with derived SELECT/set inputs, ordered supported DataFrame
stages, transformed join/subquery operands and post-set transformations. Computed
column replacement preserves column position and binds against the preceding stage;
undeclared schemas use the explicit ShardLoom `SELECT * REPLACE OR ADD (...)`
modifier. These frontend wrappers add no format-specific execution engine.
The [resource contract](../architecture/native-relational-resources-2026-10-02.md)
carries `memory_gb`, `max_parallelism` and optional `spill` through collection,
route/run and local writer aliases. Composed ordering can flush and merge stable
multi-key native rows with shared query memory/quota and verified cleanup.
Specialized sort/aggregate providers keep their existing strategies and admission.
Flat aggregates share admission across complete collection and the eight local
writers, retaining filter/group/measure/HAVING/order/limit stages and declared
source schemas/resources. Explicit null placement is independent of direction;
Python's `sort` forwards the requested `nulls` policy. Small JSONL collection remains
bounded to a complete 65,536-row/8-MiB result, while larger results use streaming
writers.
The [analytic-frame contract](../architecture/native-analytic-frames-2026-10-05.md)
admits explicit ROWS/GROUPS/RANGE frames. Current source builds after v0.4.0 also
admit [scalar-value subqueries](../architecture/native-scalar-subqueries-2026-10-05.md)
with one static output column and explicit correlation; published v0.4.0 packages
predate that addition. Unadmitted operator/type combinations, lateral relations,
dynamic-pivot-dependent scalar schemas, named windows, variable frame offsets,
other relational state spill and relational fanout remain explicit boundaries.

Not claimed by the technical preview: broad SQL-standard/ANSI-style compliance, recursive CTEs, arbitrary dialect functions, arbitrary
subqueries, broad optimizer parity, SQL UDFs, catalog-backed SQL, object-store/table SQL, JDBC/ODBC,
Flight SQL, or SQL execution delegated to another engine.

## CLI Surface

The CLI is scriptable and agent-readable. Use JSON whenever automation is involved.

Primary discovery commands:

```sh
shardloom --version
shardloom command-metadata --format json
shardloom command-metadata <command> --format json
shardloom help <command> --format json
shardloom agent-contract-pack --format json
shardloom capabilities api-surfaces --format json
```

High-level public workflow facade commands:

```sh
shardloom route <sql|python|dataframe|cli> --format json
shardloom run <sql|python|dataframe|cli> --format json
shardloom prepare <sql|python|dataframe|cli> --format json
```

Common report and safety commands:

```sh
shardloom --version --format json
shardloom status --format json
shardloom runs-today --format json
shardloom doctor --format json
shardloom support-bundle --format json
shardloom explain <operation> --format json
shardloom estimate <operation> --format json
shardloom workflow-unsupported-plan <operation> --format json
```

Common executable local proof commands:

```sh
shardloom run sql --sql "SELECT 1 AS value" --request collect --bounded true --format json
shardloom run sql --input events.csv --input-format csv --sql "SELECT * FROM events" --request collect --bounded true --format json
shardloom vortex-prepare --format json
shardloom sqlite-local-import-export-smoke --format json
```

The exhaustive command inventory, support state, side-effect level, input/output contract, feature
gate status, owning phase item, and claim/fallback boundary are generated by
`shardloom command-metadata --format json`.

## Explicit Blockers And Non-Claims

These surfaces can be visible in Python or CLI metadata but remain blocked, report-only, or
future-gated unless the dynamic capability row says otherwise:

- Broad pandas/Polars/PySpark/DataFrame parity.
- Broad SQL grammar or arbitrary SQL execution.
- Hidden fallback execution in DuckDB, DataFusion, Spark, Polars, pandas, Velox, or another engine.
- Unbounded materialization as a convenience path.
- Duplicate and duplicate-mask variants outside admitted scalar-subset `keep="first"|"last"|False`
  semantics with nullable scalar equality, including nested/list/struct equality and hidden-index
  duplicate semantics.
- Object-store, lakehouse/table, catalog, remote API, Foundry, live/hybrid, distributed, and
  production workflows without the matching evidence gate.
- Effectful external writes, credentials, network calls, UDFs, plugins, LLM/API calls, embeddings,
  vector search, media/OCR extraction, or arbitrary database connectors without explicit effect
  admission and certificates.

## Related References

- `docs/architecture/agent-contract-pack.md`
- `docs/architecture/v1-front-door-runtime-scope.md`
- `docs/architecture/v1-source-prepared-state-scope.md`
- `docs/architecture/v1-local-output-sink-scope.md`
- `docs/architecture/v1-vortex-runtime-scope.md`
- `docs/status/cli-command-registry.md`
- `docs/getting-started/examples.md`
- `python/README.md`
- `README.md`
