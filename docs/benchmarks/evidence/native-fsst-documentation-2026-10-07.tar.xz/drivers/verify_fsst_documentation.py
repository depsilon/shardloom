"""Verify current input-mode documentation, generated pages and actual examples."""
import argparse
import ast
import contextlib
import hashlib
import io
import json
import os
import re
import subprocess
import time

import fsst_common as c

DOCUMENTATION_PATHS = [
    'docs/architecture/native-input-completion-2026-10-07.md',
    'docs/architecture/native-state-structure-campaign-2026-10-07.md',
    'docs/architecture/native-conditional-work-campaign-2026-10-07.md',
    'docs/dependencies/vortex-upstream-review.md',
    'docs/benchmarks/native-input-completion-2026-10-07.md',
    'docs/benchmarks/native-fsst-admission-2026-10-07.md',
    'docs/architecture/phased-execution-plan.md',
    'docs/architecture/phased-execution-completed-ledger.md',
    'docs/release/v1-inclusion-scope-matrix.md',
    'docs/release/public-status-matrix.md',
    'docs/architecture/v1-local-resource-safety.md',
    'docs/architecture/local-development-storage.md',
    'docs/architecture/universal-workflow-completion-2026-10-01.md',
    'docs/architecture/native-bounded-adapters-2026-10-06.md',
    'docs/reference/resident-native-results.md',
    'docs/reference/shardloom-user-surface-index.md',
    'docs/reference/shardloom-user-surface-index.json',
    'python/README.md',
    'website-src/scripts/sync-content.mjs',
    'website-src/src/content/docs/field-guide/python-surface.mdx',
    'website-src/src/content/docs/field-guide/runtime-and-io.mdx',
    'website-src/src/content/docs/field-guide/limitations.mdx',
]


def check_examples(build):
    os.environ['SHARDLOOM_BIN'] = build['binary']
    import shardloom as sl
    pattern = re.compile(r'```python\n(.*?)\n```', re.S)
    old_contract = c.ROOT / 'docs/architecture/native-bounded-adapters-2026-10-06.md'
    guide = c.ROOT / 'website-src/src/content/docs/field-guide/python-surface.mdx'
    readme = c.ROOT / 'python/README.md'
    cases = [
        ('resident-contract', old_contract, pattern.search(old_contract.read_text()).group(1),
            [{'order_id': 1, 'amount': 12.5}, {'order_id': 2, 'amount': None},
             {'order_id': 3, 'amount': 7.0}], False),
        ('streaming-readme', readme, next(code for code in pattern.findall(readme.read_text())
            if 'def incoming_rows():' in code), [{'id': 1, 'label': 'kept'}], True),
        ('streaming-field-guide', guide,
            pattern.search(guide.read_text().split('## Consume results in batches', 1)[1]).group(1),
            [{'order_id': 1, 'amount': 12.5}, {'order_id': 2, 'amount': None}], True),
    ]
    examples = []
    for label, path, code, expected, streaming in cases:
        namespace = {'sl': sl}
        captured = io.StringIO()
        try:
            with contextlib.redirect_stdout(captured):
                exec(compile(code, str(path), 'exec'), namespace)
            values = [row for line in captured.getvalue().splitlines()
                for row in ast.literal_eval(line)]
            assert values == expected, (label, values)
            iterator = namespace['batches']
            report = iterator.report
            assert report is not None and report.envelope.status == 'success'
            assert not report.fallback_attempted and not report.external_engine_invoked
            assert iterator._process.poll() == 0
            raw = report.envelope.raw
            fields = {item['key']: item['value'] for item in raw['fields']}
            if streaming:
                assert fields['native_input_end_observed'] == 'true'
                assert fields['native_input_max_retained_batches'] == '1'
                assert fields['native_input_output_ownership_detached'] == 'true'
            else:
                assert 'native_input_end_observed' not in fields
            examples.append({'name': label, 'source': str(path.relative_to(c.ROOT)),
                'source_sha256': c.sha(path), 'code_sha256': hashlib.sha256(code.encode()).hexdigest(),
                'code': code, 'streaming': streaming, 'complete_rows': values, 'envelope': raw})
        finally:
            if 'batches' in namespace:
                namespace['batches'].close()
            if 'frame' in namespace:
                namespace['frame'].client.close()
    return examples


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', type=int, required=True)
    args = parser.parse_args()
    assert args.attempt > 0
    source = c.frozen()
    build = c.read(c.OUT / 'fsst-acceptance-build-1.json')
    assert c.sha(build['binary']) == build['binary_sha256']
    out = c.OUT / f'fsst-documentation-checks-{args.attempt}'
    out.mkdir(exist_ok=False)
    commands = [
        ('user-surface-index', [c.PYTHON, '-B', 'scripts/check_user_surface_reference.py'], c.ROOT),
        ('public-status', [c.PYTHON, '-B', 'scripts/check_public_status_docs.py', '--output', str(out / 'public-status-report.json')], c.ROOT),
        ('use-case-backlinks', [c.PYTHON, '-B', 'scripts/check_use_case_backlinks.py'], c.ROOT),
        ('website-check', ['npm', 'run', 'check'], c.ROOT / 'website-src'),
        ('website-build', ['npm', 'run', 'build'], c.ROOT / 'website-src'),
        ('website-readiness', [c.PYTHON, '-B', 'scripts/check_website_readiness.py', '--output', str(out / 'website-readiness-report.json')], c.ROOT),
        ('diff-whitespace', ['git', 'diff', '--check'], c.ROOT),
    ]
    checks = []
    for name, command, cwd in commands:
        c.frozen()
        path = out / f'{name}.log'
        started = time.monotonic()
        with path.open('xb') as stream:
            result = subprocess.run(command, cwd=cwd, stdout=stream,
                stderr=subprocess.STDOUT, timeout=300, check=False)
        item = {'name': name, 'command': command, 'cwd': str(cwd),
            'returncode': result.returncode, 'seconds': time.monotonic() - started,
            'log': str(path), 'log_sha256': c.sha(path)}
        checks.append(item)
        c.write(out / f'{name}-receipt.json', item)
        print(json.dumps(item), flush=True)
        c.frozen()
        assert result.returncode == 0, name
    examples = check_examples(build)
    c.frozen()
    assert c.sha(build['binary']) == build['binary_sha256']
    c.write(out / 'summary.json', {'status': 'passed', 'checks': checks,
        'executed_examples': examples, 'source_identity_sha256': source['source_identity_sha256'],
        'runtime_source_assets_verified': len(source['source_hashes']),
        'binary_sha256': build['binary_sha256'], 'driver_sha256': c.sha(__file__),
        'documentation_source_hashes': {name: c.sha(c.ROOT / name) for name in DOCUMENTATION_PATHS},
        'examples_changed': False, 'browser_visual_qa': 'pending', 'hosted_integration': 'pending'})
    print(json.dumps({'status': 'passed', 'checks': len(checks), 'examples': len(examples)}), flush=True)


if __name__ == '__main__':
    main()
