"""Keep accepted runtime and executable bytes fixed during documentation work."""
import json

import growth_acceptance_common as c

ROOT, OUT, PYTHON = c.ROOT, c.OUT, c.PYTHON
read, sha, write = c.read, c.sha, c.write


def checked_runtime():
    snapshot = read(OUT / 'growth-source-1.json')
    build = read(OUT / 'growth-acceptance-build-1.json')
    actual = c.source_hashes()
    assert snapshot['source_hashes'] == build['source_hashes']
    assert len(actual) == 1020
    assert build['source_identity_sha256'] == snapshot['source_identity_sha256']
    assert sha(build['binary']) == build['binary_sha256']
    final_path = OUT / 'growth-final-acceptance-1.json'
    final = read(final_path)
    assert final['status'] == 'passed_local_engine'
    assert final['source_identity_sha256'] == snapshot['source_identity_sha256']
    assert final['binary_sha256'] == build['binary_sha256'] and final['source_assets'] == len(actual)
    inputs_path = OUT / 'growth-evidence-inputs-1.json'
    assert final['acceptance_inputs_sha256'] == sha(inputs_path)
    assert final['all_current_stages_executed_freshly']
    assert actual == snapshot['source_hashes']
    inspection = read(OUT / 'growth-packet-verified-1.json')
    assert inspection['status'] == 'passed_independent_stream_inspection'
    assert inspection['final_acceptance_sha256'] == sha(final_path)
    assert inspection['packet_sha256'] == final['packet_sha256']
    annotation = {'accepted_runtime_commit': snapshot['head'],
        'accepted_source_identity_sha256': snapshot['source_identity_sha256'],
        'assets_byte_identical': len(actual), 'asset_count_unchanged': len(actual),
        'runtime_or_harness_changed': False,
        'binary_sha256': build['binary_sha256']}
    return snapshot, build, annotation


def portable(value):
    text = json.dumps(value, indent=2, allow_nan=False)
    for original, replacement in ((str(ROOT), '<repo>'), (str(OUT), '<growth-uat>'), (str(ROOT.home()), '<home>')):
        text = text.replace(original, replacement)
    return text + '\n'
