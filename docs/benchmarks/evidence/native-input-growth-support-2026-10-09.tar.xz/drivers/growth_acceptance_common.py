"""Frozen identities for input growth acceptance, without release publication."""
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
PRIOR = Path('/Users/dylan/LocalData/shardloom/native-input-completion-20261007')
PARENT = Path('/Users/dylan/LocalData/shardloom/native-pivot-pressure-20261008')
sys.path.insert(0, str(PRIOR))
from input_common import ROOT, PYTHON, git, read, sha, source_hashes, write


def frozen_source():
    source = read(OUT / 'growth-source-1.json')
    assert source_hashes() == source['source_hashes']
    assert git('rev-parse', 'HEAD') == source['head']
    assert git('status', '--porcelain') == source['working_tree'] == ''
    assert all(sha(path) == digest for path, digest in source['helpers'].items())
    assert sha(source['scope_manifest']) == source['scope_sha256']
    return source


def frozen_build():
    source = frozen_source()
    build = read(OUT / 'growth-acceptance-build-1.json')
    assert build['source_identity_sha256'] == source['source_identity_sha256']
    assert build['source_manifest_sha256'] == sha(OUT / 'growth-source-1.json')
    assert build['source_commit'] == source['head']
    for artifact in build['artifacts'].values():
        assert Path(artifact['binary']).stat().st_size == artifact['bytes']
        assert sha(artifact['binary']) == artifact['sha256']
    scope = read(build['scope_manifest'])
    assert sha(build['scope_manifest']) == build['scope_sha256']
    assert build['scope_manifest'] == source['scope_manifest']
    assert build['scope_sha256'] == source['scope_sha256']
    assert scope['source_identity_sha256'] == source['source_identity_sha256']
    assert scope['source_commit'] == source['head']
    assert scope['case_count'] == len(scope['cases']) == 32497
    assert scope['complete_rows'] == sum(scope['cases'].values()) == 18595284
    assert all(sha(path) == digest for path, digest in scope['declaration_source_hashes'].items())
    parent = scope['prior_declarations']
    assert sha(parent['path']) == parent['sha256']
    assert scope['cases'] == read(parent['path'])['cases']
    assert scope['additional_cohort'] == read(parent['path'])['additional_cohort']
    for oracle in scope['literal_oracles'] + [scope['nested_pivot_oracle']]:
        assert sha(oracle['path']) == oracle['sha256']
    provenance = build['unchanged_fixture_provenance']
    assert sha(provenance['path']) == provenance['sha256']
    parent_build = read(provenance['path'])
    for name in ('nested', 'typed'):
        assert build['artifacts'][name] == parent_build['artifacts'][name]
    return source, build, scope
