"""Bind verified documentation, native examples and browser proof to engine evidence."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import time

import growth_acceptance_common as a
import growth_support_common as c
from verify_growth_support import DOCUMENTS


def guard(name, attempt):
    path = c.OUT / f'{name}-{attempt}.json'
    value = c.read(path)
    assert value['status'] == 'passed' and value['returncode'] == 0
    assert value['process_group_drained'] and value['direct_child_reaped']
    assert not value['timed_out'] and not value['group_absence_unproved_at_cleanup']
    assert c.sha(path.with_suffix('.log')) == value['log_sha256']
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', type=int, required=True)
    args = parser.parse_args()
    attempt = args.attempt
    assert attempt > 0
    _, build, annotation = c.checked_runtime()
    checks = c.read(c.OUT / f'growth-support-checks-{attempt}/summary.json')
    site = c.read(c.OUT / f'growth-site-checks-{attempt}/summary.json')
    assert checks['status'] == site['status'] == 'passed'
    assert len(checks['checks']) == 6 and len(site['checks']) == 10
    assert len(checks['executed_examples']) == 3
    assert checks['runtime_provenance'] == annotation
    assert checks['binary_sha256'] == build['binary_sha256']
    assert c.sha(c.OUT / f'growth-site-checks-{attempt}/summary.json') == checks['site_summary_sha256']
    for item in [*checks['checks'], *site['checks']]:
        assert item['returncode'] == 0 and c.sha(item['log']) == item['log_sha256']
    for item in checks['executed_examples']:
        assert c.sha(c.ROOT / item['source']) == item['source_sha256']
        assert hashlib.sha256(item['code'].encode()).hexdigest() == item['code_sha256']
        assert item['envelope']['status'] == 'success' and item['complete_rows']
    for name, field in (('verify_growth_support.py', 'driver_sha256'),
                        ('growth_support_common.py', 'support_helper_sha256'),
                        ('run_growth_site_checks.py', 'site_driver_sha256')):
        assert c.sha(c.OUT / name) == checks[field]
    guards = {name: guard(name, attempt) for name in (
        'growth-support-validation', 'growth-docs-contribution', 'growth-documentation-preview')}
    contribution = c.read(c.OUT / f'growth-docs-contribution-report-{attempt}.json')
    assert contribution['status'] == 'passed'
    assert (c.OUT / f'growth-documentation-preview-stop-{attempt}').is_file()
    browser = c.read(c.OUT / f'growth-documentation-browser-{attempt}.json')
    assert browser['status'] == 'passed_manual_browser_review'
    assert not browser['console_warnings_errors']
    for name in ('desktop', 'mobile', 'resources', 'limitations'):
        assert browser[name]['body'] <= browser[name]['viewport']
    assert browser['desktop']['theme'] == 'dark' and browser['mobile']['theme'] == 'light'
    assert browser['search']['landed_url'].endswith('/python-surface/#consume-results-in-batches')
    assert browser['search']['query'] == 'cumulative'
    assert 'cumulative' in browser['search']['text'].lower()
    assert browser['mobile_menu_opened_and_closed'] and browser['temporary_viewport_reset']
    assert browser['tab_closed']
    for name in browser['screenshots']:
        path = c.OUT / name
        assert path.is_file() and not path.is_symlink() and path.stat().st_size > 0
    revised = {name: {'checked_sha256': digest, 'final_sha256': c.sha(c.ROOT / name)}
               for name, digest in checks['documentation_source_hashes'].items()
               if c.sha(c.ROOT / name) != digest}
    assert set(revised) <= {
        'docs/architecture/native-input-growth-2026-10-09.md',
        'docs/architecture/native-local-completion-scope-2026-10-07.md',
        'docs/architecture/phased-execution-plan.md',
        'docs/architecture/phased-execution-completed-ledger.md',
        'docs/architecture/universal-workflow-completion-2026-10-01.md',
        'docs/benchmarks/native-input-growth-2026-10-09.md',
        'docs/release/public-status-matrix.md',
        'docs/release/v1-inclusion-scope-matrix.md'}, revised
    final = c.OUT / f'growth-support-final-{attempt}'
    final.mkdir(exist_ok=False)
    final_checks = []
    for name, command in (
        ('user-surface-index', [c.PYTHON, '-B', 'scripts/check_user_surface_reference.py']),
        ('use-case-backlinks', [c.PYTHON, '-B', 'scripts/check_use_case_backlinks.py']),
        ('v1-inclusion-scope', [c.PYTHON, '-B', 'scripts/check_v1_inclusion_scope.py',
                                '--output', str(final / 'v1-inclusion-scope-report.json')]),
        ('public-status', [c.PYTHON, '-B', 'scripts/check_public_status_docs.py',
                           '--output', str(final / 'public-status-report.json')]),
        ('website-readiness', [c.PYTHON, '-B', 'scripts/check_website_readiness.py',
                               '--output', str(final / 'website-readiness-report.json')]),
        ('diff-whitespace', ['git', 'diff', '--check']),
    ):
        path = final / f'{name}.log'
        start = time.monotonic()
        with path.open('xb') as stream:
            result = subprocess.run(command, cwd=c.ROOT, stdout=stream,
                                    stderr=subprocess.STDOUT, timeout=60, check=False)
        item = {'name': name, 'command': command, 'returncode': result.returncode,
                'seconds': time.monotonic() - start, 'log': str(path), 'log_sha256': c.sha(path)}
        c.write(final / f'{name}-receipt.json', item)
        final_checks.append(item)
        assert result.returncode == 0, item
    c.write(final / 'checks.json', {'status': 'passed', 'checks': final_checks})
    assert c.checked_runtime()[2] == annotation

    paths = {}
    for prefix in ('growth-support-', 'growth-site-checks-', 'growth-documentation-', 'growth-docs-'):
        for path in sorted(c.OUT.glob(prefix + '*')):
            for item in sorted(path.rglob('*')) if path.is_dir() else [path]:
                if item.is_file():
                    assert not item.is_symlink()
                    paths['proof/' + str(item.relative_to(c.OUT))] = item
    for name in ('verify_growth_support.py', 'growth_support_common.py', 'run_growth_site_checks.py',
                 'preview_growth_documentation.py', 'growth_acceptance_common.py',
                 'run_guarded.py', Path(__file__).name):
        paths['drivers/' + name] = c.OUT / name
    names = list(DOCUMENTS)
    names += a.git('diff', '--name-only', 'HEAD').splitlines()
    names += a.git('ls-files', '--others', '--exclude-standard').splitlines()
    for name in sorted(set(names)):
        path = c.ROOT / name
        if path.is_file() and not name.startswith('docs/benchmarks/evidence/'):
            assert name.startswith(('docs/', 'website-src/', 'website/')) or name in ('README.md', 'python/README.md'), name
            assert not path.is_symlink()
            paths['source/' + name] = path
    assert sum(path.stat().st_size for path in paths.values()) < 32 * 1024 * 1024
    manifest = {name: {'bytes': path.stat().st_size, 'sha256': c.sha(path)}
                for name, path in sorted(paths.items())}
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    browser_bytes = c.portable(browser).encode()
    target = c.ROOT / 'docs/benchmarks/evidence/native-input-growth-support-2026-10-09.tar.xz'
    with tarfile.open(target, 'x:xz', preset=6) as archive:
        for name, path in sorted(paths.items()):
            info = tarfile.TarInfo(name)
            info.size = path.stat().st_size
            info.mode = 0o644
            with path.open('rb') as stream:
                archive.addfile(info, stream)
        for name, raw in (('manifest.json', manifest_bytes), ('browser.json', browser_bytes)):
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(raw))
    with tarfile.open(target, 'r:xz') as archive:
        members = archive.getmembers()
        assert len(members) == len(manifest) + 2
        assert {item.name for item in members} == set(manifest) | {'manifest.json', 'browser.json'}
        assert archive.extractfile('manifest.json').read() == manifest_bytes
        assert archive.extractfile('browser.json').read() == browser_bytes
        for name, expected in manifest.items():
            assert archive.getmember(name).isfile()
            with archive.extractfile(name) as stream:
                assert hashlib.file_digest(stream, 'sha256').hexdigest() == expected['sha256']
            assert archive.getmember(name).size == expected['bytes']
            assert c.sha(paths[name]) == expected['sha256'], name
    assert c.checked_runtime()[2] == annotation
    report = {
        'schema_version': 'shardloom.native_input_growth_support_acceptance.v1',
        'status': 'passed_local_documentation_acceptance',
        'runtime_commit': annotation['accepted_runtime_commit'], 'runtime_provenance': annotation,
        'documentation_checks': checks['checks'], 'generated_site_checks': site['checks'],
        'executed_examples': checks['executed_examples'], 'final_selected_checks': final_checks,
        'contribution_governance': contribution, 'post_check_status_prose_changes': revised,
        'browser': browser, 'guards': guards,
        'review_correction': 'Align current growth admission and historical fixed limits across canonical docs and generated guides; retain published 0.5.1 behavior, four-domain intake, streaming composition and deep-traversal obligations.',
        'runtime_implementation_rerun_required': False,
        'archive': {'path': str(target.relative_to(c.ROOT)),
                    'bytes': target.stat().st_size, 'sha256': c.sha(target),
                    'file_members': len(manifest), 'total_members': len(manifest) + 2,
                    'manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
                    'all_members_reopened_and_hash_checked': True},
        'source_files': {name.removeprefix('source/'): item
                         for name, item in manifest.items() if name.startswith('source/')},
        'temporary_servers_drained': True, 'hosted_integration': 'pending',
        'claim_boundary': 'Exact documentation, three native examples and generated guides; no new performance, whole-process RSS or package claim.',
        'driver_sha256': c.sha(__file__),
    }
    result_path = target.with_name('native-input-growth-support-2026-10-09.json')
    with result_path.open('x') as stream:
        stream.write(c.portable(report))
    index_path = target.with_name('native-input-growth-2026-10-09.json')
    index = c.read(index_path)
    assert index['documentation_updates_complete'] is False
    assert index['runtime_commit'] == annotation['accepted_runtime_commit']
    assert c.sha(c.ROOT / index['acceptance']['packet']) == index['acceptance']['packet_sha256']
    index.update(documentation_updates_complete=True,
                 documentation_acceptance=str(result_path.relative_to(c.ROOT)),
                 documentation_acceptance_sha256=c.sha(result_path),
                 support_alignment_runtime_provenance=annotation)
    index_path.write_text(c.portable(index))
    result = {'status': 'passed', 'selected_checks': len(final_checks),
              'members': len(manifest) + 2, 'archive_bytes': target.stat().st_size,
              'archive_sha256': c.sha(target), 'support_sha256': c.sha(result_path),
              'index_sha256': c.sha(index_path), 'runtime_provenance': annotation}
    c.write(final / 'summary.json', result)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
