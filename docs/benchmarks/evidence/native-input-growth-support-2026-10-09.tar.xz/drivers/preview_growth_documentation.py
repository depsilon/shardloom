"""Serve accepted generated guides for bounded local browser verification."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import argparse
import os
import time

import growth_support_common as c

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--attempt', type=int, required=True)
args = parser.parse_args()
assert args.attempt > 0
stop = c.OUT / f'growth-documentation-preview-stop-{args.attempt}'
assert not stop.exists()
assert c.read(c.OUT / f'growth-support-checks-{args.attempt}/summary.json')['status'] == 'passed'
c.checked_runtime()
handler = partial(SimpleHTTPRequestHandler, directory=str(c.ROOT / 'website'))
server = ThreadingHTTPServer(('127.0.0.1', 0), handler)
server.daemon_threads = True
server.timeout = 0.5
c.write(c.OUT / f'growth-documentation-preview-address-{args.attempt}.json', {
    'url': f'http://127.0.0.1:{server.server_address[1]}', 'pid': os.getpid(),
    'root': str(c.ROOT / 'website'), 'maximum_seconds': 600})
deadline = time.monotonic() + 600
try:
    while not stop.exists() and time.monotonic() < deadline:
        server.handle_request()
finally:
    server.server_close()
print('Preview server closed', flush=True)
