"""Regenerate and validate the existing docs site without changing runtime sources."""
import argparse
import json
from pathlib import Path
import subprocess

import growth_acceptance_common as c

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--attempt', type=int, required=True)
args = parser.parse_args()
assert args.attempt > 0
out = c.OUT / f'growth-site-checks-{args.attempt}'
out.mkdir()
node = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
site = c.ROOT / 'website-src'
frozen = c.read(c.OUT / 'growth-source-1.json')['source_hashes']
steps = [
    ('clean-static', site, [node, 'scripts/prebuild-static.mjs']),
    ('sync-content', site, [node, 'scripts/sync-content.mjs']),
    ('astro-check', site, [node, 'node_modules/astro/bin/astro.mjs', 'check']),
    ('settle-static', site, [node, 'scripts/prebuild-static.mjs', '--settle-output']),
    ('search-policy', site, [node, '--test', 'scripts/pagefind-policy.test.mjs']),
    ('prebuild-static', site, [node, 'scripts/prebuild-static.mjs', '--reset-output']),
    ('astro-build', site, [node, 'node_modules/astro/bin/astro.mjs', 'build']),
    ('postbuild-static', site, [node, 'scripts/postbuild-static.mjs']),
    ('user-surface-reference', c.ROOT, [c.PYTHON, '-B', 'scripts/check_user_surface_reference.py', '--repo-root', str(c.ROOT)]),
    ('diff-check', c.ROOT, ['git', 'diff', '--check']),
]
report = {'status': 'running', 'runtime_sources_unchanged': True, 'checks': []}
try:
    for name, cwd, command in steps:
        assert c.source_hashes() == frozen
        print('Starting site check: ' + name, flush=True)
        path = out / f'{name}.log'
        with path.open('xb') as stream:
            result = subprocess.run(command, cwd=cwd, stdout=stream, stderr=subprocess.STDOUT, timeout=300)
        report['checks'].append({'name': name, 'command': command, 'cwd': str(cwd),
            'returncode': result.returncode, 'log': str(path), 'log_sha256': c.sha(path)})
        assert result.returncode == 0, name + ' failed; original log retained'
        assert c.source_hashes() == frozen
    report['status'] = 'passed'
finally:
    c.write(out / 'summary.json', report)
print(json.dumps({'status': report['status'], 'checks': len(report['checks'])}), flush=True)
