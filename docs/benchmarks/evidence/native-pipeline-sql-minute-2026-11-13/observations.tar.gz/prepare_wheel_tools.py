"""Create hash-pinned build tooling from the retained wheelhouse; no queries."""
import hashlib
import json
from pathlib import Path
import sys

from guard_checks import ROOT, OUT, ENV, supervisor
from local_uat_storage import GIB, accounted_bytes, available_bytes, require_local_path

destination = OUT / 'wheel-tools-r1'
wheelhouse = Path('/Users/dylan/LocalData/shardloom/native-pipeline-consolidation-2026-11-12/wheel-tools-r1/wheelhouse')
require_local_path(destination, Path.home(), sys.platform)
assert __debug__ and wheelhouse.is_dir() and not destination.exists()
destination.mkdir()
environment = destination / 'venv'
evidence = dict(status='running', native_query_executions=0,
    retained_wheelhouse=str(wheelhouse), downloads=0, steps=[])

def identity(path):
    return dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())

before = {p.name: identity(p) for p in sorted(wheelhouse.glob('*.whl'))}

def storage_guard():
    assert available_bytes(OUT) >= 12 * GIB, 'free storage below 12 GiB'
    assert accounted_bytes(destination) <= GIB, 'tool environment exceeds 1 GiB'

commands = [
    ('create-environment', [sys.executable, '-m', 'venv', str(environment)]),
    ('install-build-tools', [str(environment / 'bin/python'), '-I', '-m', 'pip',
        'install', '--disable-pip-version-check', '--no-cache-dir', '--no-index',
        '--find-links', str(wheelhouse), '--only-binary=:all:', '--require-hashes',
        '-r', str(ROOT / '.github/requirements/ci-native-python-build.txt')]),
]
try:
    for name, command in commands:
        storage_guard()
        step = dict(name=name, command=command)
        evidence['steps'].append(step)
        with (destination / (name + '.log')).open('xb') as log:
            code = supervisor.run(command, cwd=destination, env=ENV, output=log,
                timeout=900, evidence=step, guard=storage_guard)
        assert code == 0 and step['process_group_drained'], name
        step['status'] = 'passed'
    assert before == {p.name: identity(p) for p in sorted(wheelhouse.glob('*.whl'))}
    evidence.update(status='passed', wheelhouse_unchanged=True, wheels=before)
except BaseException as error:
    evidence.update(status='failed', error=repr(error))
    raise
finally:
    (destination / 'report.json').write_text(json.dumps(evidence, indent=2) + '\n')
    print(json.dumps({'status': evidence['status']}))
