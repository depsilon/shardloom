"""Package exact correctness receipts; execute no native query or benchmark."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

from guard_checks import ROOT, OUT, sources

def identity(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def read(name):
    return json.loads((OUT / name).read_bytes())

build = read('release-build-r2.json')
assert __debug__ and build['source_files'] == sources()
names = ['minute-focused-r3', 'fmt-r2', 'default-clippy-r2', 'default-tests-r2',
         'native-clippy-r2', 'native-cli-python-tests-r2', 'release-build-r2', 'installed-wheel-r1']
checks = {}
for name in names:
    receipt = read(name + '.json')
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['sources_unchanged'] and receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert receipt['source_files'] == build['source_files'], name
    log = (OUT / 'logs' / (name + '.log')).read_text()
    counts = [tuple(map(int, match)) for match in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)]
    checks[name] = dict(command=receipt['command'], status=receipt['status'],
        recorded_head=receipt['head'], source_files_match_build=True,
        receipt=name + '.json', receipt_identity=identity((OUT / (name + '.json')).read_bytes()),
        log='logs/' + name + '.log')
    if counts:
        checks[name]['tests'] = dict(zip(('passed','failed','ignored'), map(sum,zip(*counts))))
assert checks['default-tests-r2']['tests'] == dict(passed=3325,failed=0,ignored=0)
assert checks['native-cli-python-tests-r2']['tests'] == dict(passed=1567,failed=0,ignored=3)
installed = read('installed-wheel-r1/report.json')
assert installed['status'] == installed['uninstall_status'] == 'passed'
assert installed['integration'] == dict(status='passed',tests=442,failures=0,errors=0,skipped=0)
assert installed['publication_attempted'] is False and installed['performance_claim'] is False
runtime = read('runtime-r1-identity.json')
assert installed['integrity']['cli_sha256'] == runtime['files']['runtime-r1/shardloom']['sha256']
assert installed['integrity']['native_library_sha256'] == runtime['files']['runtime-r1/lib_native.dylib']['sha256']
assert read('minute-focused-r1.json')['status'] == 'failed'
assert read('release-build-r1.json')['status'] == 'failed'
assert read('release-build-r1.json')['process_group_drained'] is True

destination = OUT / 'evidence-r1'
assert not destination.exists()
destination.mkdir()
paths = [*OUT.glob('*.json'), *OUT.glob('logs/*.log')]
paths += [OUT / name for name in ('guard_checks.py','freeze_runtime.py','prepare_wheel_tools.py','pack_validation.py')]
for prefix in ('installed-wheel-r1','wheel-tools-r1'):
    paths += list((OUT / prefix).glob('*.json')) + list((OUT / prefix).glob('*.log'))
payloads = {str(path.relative_to(OUT)): path.read_bytes() for path in sorted(set(paths))}
archive_path = destination / 'observations.tar.gz'
with archive_path.open('xb') as file, gzip.GzipFile(filename='', fileobj=file, mode='wb',mtime=0) as compressed, tarfile.open(fileobj=compressed,mode='w') as archive:
    for name, raw in payloads.items():
        entry = tarfile.TarInfo(name)
        entry.size = len(raw)
        entry.mode = 0o644
        archive.addfile(entry,io.BytesIO(raw))
with tarfile.open(archive_path,'r:gz') as archive:
    assert {member.name for member in archive.getmembers()} == set(payloads)
    for member in archive.getmembers():
        assert member.isfile() and archive.extractfile(member).read() == payloads[member.name]
summary = dict(schema='shardloom.native_pipeline_sql_minute_validation.v1',status='passed',
    scope='Correctness and installed-package validation of SQL minute syntax; no new performance observation.',
    source_commit=build['head'], source_tree=build['source_tree'],
    source_fingerprint_sha256=runtime['source_fingerprint_sha256'], checks=checks,
    installed=installed['integration'], runtime=runtime, publication_attempted=False,
    benchmark_executions=0, old_packet_replay=read('old-packet-replay-r1.json'),
    preserved_observations=[
        dict(receipt='minute-focused-r1.json', disposition='Original 6-pass/1-fail test run: invalid integer-to-timestamp fixture corrected to supported text conversion; positive typed-helper control added.'),
        dict(receipt='release-build-r1.json',disposition='Stopped deliberately for final parser review correction; process group drained. Not a completed build.'),
    ],
    focused_recorded_head_note='Focused r3 began while the local commit metadata advanced; its full source inventory equals the final build. All broad final checks and installed proof record the final source commit.',
    archive=identity(archive_path.read_bytes()),
    archive_members={name:identity(raw) for name,raw in payloads.items()})
(destination / 'validation.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(status='passed',members=len(payloads),archive_bytes=archive_path.stat().st_size,source_commit=build['head'])))
