"""Freeze the source-verified minute SQL runtime for installed-package proof."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

from guard_checks import ROOT, OUT, CACHE, sources
from local_uat_storage import GIB, check_budgets, require_local_path

def identity(path):
    assert path.is_file() and not path.is_symlink(), path
    before = path.stat()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    after = path.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    return dict(bytes=before.st_size, sha256=digest)

receipt = OUT / 'release-build-r2.json'
build = json.loads(receipt.read_bytes())
assert __debug__ and build['status'] == 'passed' and build['returncode'] == 0
assert build['sources_unchanged'] and build['process_group_drained'] and build['direct_child_reaped']
assert build['target_directory'] == str(CACHE)
assert build['source_files'] == sources()
assert subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT, text=True).strip() == build['head']
assert not subprocess.check_output(['git','status','--porcelain'], cwd=ROOT, text=True).strip()
destination = OUT / 'runtime-r1'
require_local_path(destination, Path.home(), sys.platform)
assert not destination.exists()
artifacts = [CACHE / 'release' / name for name in ('shardloom', 'lib_native.dylib')]
before = {str(path): identity(path) for path in artifacts}
check_budgets(OUT, destination, OUT / 'logs', min_free_bytes=12*GIB,
    reserve_bytes=sum(item['bytes'] for item in before.values()),
    max_workspace_bytes=100*GIB, max_log_bytes=192*(1 << 20))
destination.mkdir()
files = {}
for source in artifacts:
    target = destination / source.name
    with source.open('rb') as src, target.open('xb') as dst:
        shutil.copyfileobj(src, dst)
    shutil.copymode(source, target)
    assert identity(source) == identity(target) == before[str(source)]
    files[str(target.relative_to(OUT))] = identity(target)
assert os.access(destination / 'shardloom', os.X_OK)
assert build['source_files'] == sources()
result = dict(status='passed', source_commit=build['head'], source_tree=build['source_tree'],
    source_fingerprint_sha256=hashlib.sha256(json.dumps(build['source_files'], sort_keys=True, separators=(',',':')).encode()).hexdigest(),
    build_receipt=receipt.name, build_receipt_identity=identity(receipt), profile='release',
    files=files, publication_attempted=False, benchmark_executions=0)
(OUT / 'runtime-r1-identity.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'source_commit':result['source_commit']}))
