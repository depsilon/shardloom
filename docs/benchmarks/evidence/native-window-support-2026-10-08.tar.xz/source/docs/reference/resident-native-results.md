<!-- SPDX-License-Identifier: Apache-2.0 -->

# Resident Native Results

Use a Unix build with `vortex-local-primitives` for the interfaces on this page.
They execute through the pinned native Vortex provider. Unsupported requests fail
explicitly; no external query engine participates.

`PreparedVortexAggregate::execute()` retains ordinary native aggregate lowering
across text, numeric and nullable schemas, derived grouping keys, transformed
measures and wide measure sets of at most 1,024 measures. Grouping, expression
arguments, ordering and HAVING share a separate 1,024-entry syntax limit.
These limits are checked before projection building, request cloning or
aggregate-state allocation; this schema ceiling is not a
whole-process memory bound. Each call computes fresh state. With `vortex-write`,
the admitted weighted UTF8 COUNT and exact integer DISTINCT spill families retain
the source while rebuilding spill lowering and runs for every execution.
After a cancelled prepared spill call returns, call
`renew_spill_cancellation(&mut self)` before re-execution. It retains the source
and workspace/quotas and returns a policy whose `cancel()` controls the new scope.
Old policy clones cannot cancel the renewed call. Exclusive mutable access
prevents changing cancellation while a prepared execution still borrows the handle.
For standalone recovery, both `VortexSortSpillPolicy::renew_cancellation()` and
`VortexAggregateSpillPolicy::renew_cancellation()` return a freshly validated policy
with the same workspace and quotas. Use that policy to retry interrupted cleanup;
the original cancelled policy and its clones remain cancelled.

`execute_owned()` returns complete bounded flat-scalar results, including mixed
and nullable grouping keys, derived keys and COUNT/SUM/AVG/MIN/MAX measures.
The [owned COUNT results](owned-count-results.md) retain their direct finalizers;
other admitted aggregates construct typed native columns from completed state.
Owned collection keeps its 65,536-row, 128-field and 8-MiB admission bounds and
does not admit explicit spill output. These bounds do not limit streaming writes.
See the [current completion evidence](../architecture/native-runtime-completion-2026-09-20.md).

`execute_cancellable(&CancellationToken)` adds cooperative cancellation to ordinary
prepared aggregate calls without discarding their retained source or lowering.
Scans check the token at chunk/stage boundaries and before publication. Explicit
spill calls observe both the operation token and their policy token while waiting
in the serving admission queue and inside admitted weighted COUNT and exact
DISTINCT spill work, including workers and merge boundaries. Neither token
cancels the other owner. Running provider work drains before return, and cancelled
worker attempts do not cancel the parent.

## Python Batch Input and Results

Current source exposes `shardloom.from_batches` / `ShardLoomContext.from_batches`
and `LazyFrame.iter_batches` / `SqlWorkflow.iter_batches`, merged in PR #1526
after local and hosted checks. Published v0.4.0 predates those adapters. The
[batch API contract and example](../architecture/native-bounded-adapters-2026-10-06.md)
define exact types, resource bounds and failure behavior.

Input batches contain up to 2,048 row mappings with an explicit schema of up to
128 nullable Int64, finite Float64, Boolean or UTF8 fields. An iterable is used
once; a factory supplies fresh input on repeated execution. Each frame is at
most 8 MiB, with at most 4,096 batches per source. In the default resident mode
(`streaming=False`), total native input must fit the shared grant.

Opt-in `streaming=True` consumes one finite batch source once, retaining at most
one native input batch. Current source composes Scan/Filter/Project, Sort, Limit,
Aggregate, Join and Window alongside ordinary file/resident sources. Repeated batch use
and multiple batch producers reject before consumption. Incremental results,
bounded small collection and one native Vortex destination are admitted.
Cumulative input may exceed the query grant within the finite batch/frame limits;
typed intake, retained operator state, output compaction and result/sink owners
remain charged. Ordering, aggregation, joins and analytic windows admit explicit
native spill.
Limits, including zero, drain and validate input; observed end-of-input is required
for success. Neither mode admits repeated-source spooling or an RSS bound. Ordering/aggregate
acceptance merged in [PR #1531](https://github.com/depsilon/shardloom/pull/1531).
The [join contract](../architecture/native-join-pressure-2026-10-08.md) has
[complete local acceptance](../benchmarks/native-join-pressure-2026-10-08.md),
including independent packet inspection and hosted integration in
[PR #1532](https://github.com/depsilon/shardloom/pull/1532). The
[window contract](../architecture/native-window-pressure-2026-10-08.md) has
[complete local acceptance](../benchmarks/native-window-pressure-2026-10-08.md)
for existing analytic functions/frames under explicit native spill and one finite
single-use batch source; hosted window integration remains pending.
The [spill guide](native-query-spill.md) gives current examples and recovery
boundaries.

`iter_batches(batch_rows=2048, memory_gb=..., max_parallelism=..., spill=...)`
delivers admitted typed/nested results with acknowledged backpressure. Consume
inside a `with` block, especially when stopping early. Each batch is provisional
until the iterator is exhausted and its final `report` is present after source
validation. Retaining Python objects is outside the native grant. Prepare
compatibility file inputs explicitly to Vortex before using this transaction.

## Stream Computed Results

With `vortex-local-primitives`, `PreparedVortexAggregate::for_each_batch(&cancellation,
consume)` executes once and synchronously delivers native arrays together with
the borrowed `NativeExecutionContext`. A callback may use that context for
downstream native filtering or projection. It must not acquire a second ordinary
execution admission in the same session. Empty results deliver the declared
schema. Batches contain at most 2,048 rows and 8 MiB of native value, offset and
validity buffers; a smaller batch is selected when needed. A single oversized row
fails. Retained clones and slices retain their buffer reservations.

The callback supplies backpressure: execution does not produce the next batch
until the callback returns. Delivered batches are provisional until the whole
call succeeds, including final source-generation validation. Consumer errors and
cancellation fail the operation; consumers must not publish a prefix as success.

`PreparedVortexAggregate::collect_jsonl(&cancellation)` consumes those same native
batches once and returns complete bounded JSONL with its execution report.
Collection admits at most 65,536 rows and 8 MiB of serialized bytes, including
escaping. Failure returns no partial result and releases its reservations; a
successful `Budgeted<String>` retains its credits even after preparation/session
handles are dropped. The shared aggregate, unary and relational JSON sink records
the explicit row boundary and loss of physical dtype, encoding, statistics and
metadata while retaining the native operation's source and execution evidence.
Public aggregate consumers read the complete `result_jsonl` payload or Python
`report.result_rows`. The diagnostic summary retains execution and spill metrics;
streamed collection does not require a second copy of rows in that summary.

SQL and DataFrame flat aggregate chains share admission across collection and
local writers, preserving filters, groups, measures, HAVING, order, offset/limit
and source declarations. Explicit `NULLS FIRST`/`NULLS LAST` applies independently
of ASC/DESC during candidate selection and final delivery. The primitive API's
omitted policy remains nulls first ascending and last descending; general
relational binding keeps its existing explicit-null requirement on nullable keys.
See the [aggregate contract](../architecture/native-aggregate-ordering-2026-10-02.md).

`PreparedVortexAggregate::write(path, format, allow_overwrite)` and
`write_controlled(path, format, allow_overwrite, &cancellation)` use the same
typed result stream and additionally require `vortex-write`.
Public aggregate and ordered-result file exports share these
writers. Vortex, JSON, JSONL and CSV are available with `vortex-write`; Parquet,
Arrow IPC, Avro and ORC also require `universal-format-io`. Admitted weighted
COUNT, integer DISTINCT and numeric-sort spills can complete through the writers.
Composed relational ordering also uses those sinks after stable multi-key native
row spill/merge under one query workspace, quota and resident memory grant. Public
SQL and DataFrame collection/writers forward `memory_gb`, `max_parallelism` and
optional `spill` to the selected native provider. Other relational state spill
and relational fanout remain separate work. See the
[relational resource contract](../architecture/native-relational-resources-2026-10-02.md).
In-memory collection limits no longer cap these file outputs. Native writers
request at most 8,192 rows per batch; text and compatibility writers request
2,048. Ordered payload reads use selections of at most 512 source rows.
Completed DISTINCT and weighted COUNT handoffs borrow at most 2,048 selected
keys/counts at once; their completed owners retain the globally selected state.

Writers stage the complete output, validate it and the source generation, and
atomically publish a new destination. Existing destinations are rejected even
when `allow_overwrite` is true because this route cannot atomically replace an
expected destination generation. Failure removes owned staging files and drains
accepted writer buffers. JSON/JSONL/CSV encode final native values at the sink;
they do not construct a whole result table or use JSON as an execution boundary.
An aggregate sink's observed row count is a lower bound before OFFSET/LIMIT when
either may remove groups; the evidence does not mark that count exact.

The accounted scope includes constructed result buffers, selection admission and
writer retention/metadata grants. It does not establish a total RSS bound or
account for every existing aggregate state and upstream allocation. The
[static nested contract](../architecture/native-nested-composition-2026-10-02.md)
extends shared payload ownership, relational delivery and representable writers.
The [typed payload contract](../architecture/native-typed-payloads-2026-10-03.md)
adds binary, exact Decimal128, Date32 and timezone-free microsecond timestamps,
including nested leaves, to this delivery path. The subsequent [typed key contract](../architecture/native-typed-keys-2026-10-03.md)
admits flat binary, exact Decimal128 with matching precision/scale, Date32 and
timezone-free timestamp-microsecond equality, hashing and ordering through
relational joins, sets, groups, windows and subqueries, plus COUNT/COUNT
DISTINCT/MIN/MAX and the scoped expressions it lists. Its existing explicit
ORDER BY spill policy applies to these flat keys. General aggregation, joins and
analytic windows use their separately admitted [spill strategies](native-query-spill.md).
The subsequent [nested key and retained-state contract](../architecture/native-nested-keys-state-2026-10-04.md)
admits static List/FixedSizeList/Struct equality, hashing and ordering through
existing relational kernels, plus selected nested values for DISTINCT/duplicate
selection and masks, tail, sampling, parent forward fill, lossless same-shape
melt and rolling COUNT. Forward fill replaces a NULL parent with the prior
complete value; child NULLs do not trigger filling. Exact recursive key schemas
must match except for nullability. The
[local acceptance report](../benchmarks/native-nested-keys-state-full43-2026-10-04.md)
records complete results, resource/failure proof and regression checks. The unit
merged in PR #1516 after all 37 hosted checks passed.
General Variant/extension operations, nested
arithmetic/string operations and broader state-spill families remain explicit
gaps. Current source builds admit typed literals, explicit CAST/TRY_CAST, exact
decimal arithmetic/rounding and scoped binary/calendar functions through the
shared native expression binder. Decimal arithmetic
output metadata binds before execution; explicit decimal downscaling requires
zero discarded digits. Key compatibility still requires matching decimal
precision/scale and preserves distinct temporal types. Wider analytic-window
semantics, broader adapters and state spill remain separate. See the [typed
expression contract](../architecture/native-typed-expressions-2026-10-03.md).
Retained unary state also admits those four flat scalar domains for DISTINCT,
duplicate selection/masks, tail, sampling, scalar replacement/forward-fill,
lossless melt, rolling COUNT and scoped pivot first/first-unique/COUNT. The
nested contract adds the finite selected-value operations listed above; nested
values retain their exact logical shape for same-shape melt, and forward fill
replaces a NULL parent with the prior complete valid value. Direct
file requests and composed unary stages share binding and native ownership.
Typed sampling weights remain unsupported. The
[typed reduction continuation](../architecture/native-typed-reductions-2026-10-04.md)
adds computed aggregate arguments and exact Decimal128 SUM/AVG, rolling
sum/mean/min/max and numeric pivot cells/margins through the existing owners.
SUM binds precision 38 at the input scale; AVG binds precision 38 at scale
`max(input_scale,6)` and fails on inexact division. Extrema preserve the input
decimal type, and numeric pivot NULL values remain errors. Wide intermediate
totals allow cancellation and representable averages without floating conversion.
Complete local acceptance passes 20,445 public checks and all 129 shared-engine
Full43 executions; the [report and independently inspected packet](../benchmarks/native-typed-reductions-full43-2026-10-05.md)
retain exact runtime and source identities. No speedup is claimed. Native
ARRAY/STRUCT constructors also preserve admitted child types through shared
expression and output owners. Primitive predicates retain their narrower domain; use
the shared typed expression binder for typed filtering around a unary stage.
The [typed unary contract](../architecture/native-typed-unary-2026-10-03.md)
defines exact literal JSON and the 0.4 Rust request migration from `StatValue` to
`ScalarValue`. Empty inputs bind the same logical types as populated inputs.
The [typed key acceptance report](../benchmarks/native-typed-keys-full43-2026-10-03.md)
records complete public writer/readback and forced-sort-run evidence.
See the [streaming contract and acceptance](../architecture/native-workflow-streaming-2026-10-01.md).

## Compose Owned Native Results

`OwnedVortexResultBatch::dtype()` returns the authoritative native schema, including
when an empty result has no arrays. Native and compatibility sinks retain that
schema. With `vortex-local-primitives` and `vortex-write`,
`owned_array_source::OwnedArraySource::from_owned(result, bounds, &cancellation)`
consumes completed arrays without an intermediate serialization step. Use its
`source_uri()` in the aggregate request and call `prepare_aggregate(&request, policy)`.
The returned `PreparedVortexAggregate` reuses ordinary lowering, workers, exact
reducers and finalizers. Each execution has fresh state; a prepared handle retains
the source buffers and their reservations after the producer and source handles drop.

`OwnedArraySourceBounds` defaults to 1,048,576 rows, 1,024 columns, 4,096 batches,
64 MiB of logical array bytes and 1 MiB of adapter reference metadata. These are
not process-RSS limits. Typed empty schemas and nullable root/field validity are
preserved. Certificates identify `owned_vortex_arrays`, zero source-specific file
opens and no construction serialization; they do not claim a persisted footer.
This direct adapter admits ordinary aggregation; explicit spill requires the
existing file-backed composition below. It adds no new aggregate or owned-output
families. The [R5.a evidence](../architecture/owned-array-handoff-screen-2026-09-26.md)
records its scoped complete-workflow memory result and acceptance status.

For an immutable serialized source with the existing persistence/spill contract,
`memory_file_generation::MemoryFileGeneration::from_owned(result, bounds, &cancellation)`
consumes a complete owned batch and creates immutable Vortex segments in memory.
Its `MemoryFileCompositionBounds` defaults admit at most 1,048,576 rows, 1,024
columns, 4,096 batches, 64 MiB of serialized data and 1 MiB of construction metadata.
These composition bounds are separate from the typed external-intake defaults below.

The source retains typed columns, chunk references and logical null validity.
Serialization is an explicit copy boundary; lazy array expressions may require
native completion. Construction evidence records that work separately from query
execution. Serialized bounds include retained dictionary and backing-buffer
amplification. This API neither reconstructs JSON rows nor imports an Arrow table.

Use the generation's `source_uri()` in a `VortexQueryPrimitiveRequest`, then call
`prepare_aggregate(&request, policy)` to bind the existing native aggregate kernels.
The URI is a process-local evidence identity, not a filesystem path or a remotely
resolvable source. Prepared calls retain the generation, compute fresh state and
report zero source-file opens. Ordinary aggregate schema/expression and explicit
spill admission rules still apply. Additional relational and owned-output families
remain in the [completion plan](../architecture/native-runtime-completion-2026-09-20.md).

Construction uses the result's session and one native operation context. Bounds,
schema inconsistencies and cancellation fail before publication; input and output
reservations cover their ownership overlap. Upstream metadata/serializer allocations
outside the native allocator and process RSS remain outside the reservation claim.

## Concurrent Rust Sessions

Ordinary sessions keep exclusive batch admission. Choose bounded concurrency
explicitly when multiple callers share a session:

```rust
use shardloom_vortex::resident_session::{ResidentServingPolicy, ResidentVortexSession};

fn main() -> shardloom_core::Result<()> {
    let session = ResidentVortexSession::with_serving_policy(
        512 * 1024 * 1024,
        4,
        ResidentServingPolicy::default(),
    )?;
    let source = session.prepare_file("events.vortex")?;
    let count = source.prepare_count();
    println!("{}", count.execute()?);
    Ok(())
}
```

The default serving policy gives general calls one CPU lane including the caller,
reserves a metadata lane when at least two CPUs are available, and bounds the
waiting queue and positional I/O across the session's sources. Queue bytes cover
admission tickets, not payloads held by callers. `execute_timed(&cancellation)` on
prepared count/projection returns separate queue and native service durations;
complete delivery also includes the chosen result sink. I/O limits reject excess
work explicitly. Cancellation is cooperative and drains already running reads.
`admission_snapshot()` and `io_snapshot()` expose the corresponding counters.
`close_admission()` rejects new/queued calls while active calls finish and drain.

This policy is currently an explicit Rust surface; the broader public serving
rollout and production-scale acceptance remain in the
[runtime completion plan](../architecture/native-runtime-completion-2026-09-20.md).

## Typed Rust Memory Intake

Keep a `ResidentVortexSession` and prepared operation across calls. Typed intake
validates borrowed columns and copies their values into immutable native Vortex
buffers owned by that session. It becomes queryable without publishing a file.

```rust
use shardloom_vortex::{
    resident_memory_source::{
        MemoryColumn, MemoryColumnValues, MemorySourceBounds, ResidentMemorySource,
    },
    resident_session::ResidentVortexSession,
};

fn main() -> shardloom_core::Result<()> {
    let session = ResidentVortexSession::new(4 * 1024 * 1024, 2)?;
    let ids = [Some(i64::MAX), None];
    let labels = [Some("東京"), None];
    let source = ResidentMemorySource::from_columns(
        &session,
        &[
            MemoryColumn { name: "id", values: MemoryColumnValues::Int64(&ids) },
            MemoryColumn { name: "label", values: MemoryColumnValues::Utf8(&labels) },
        ],
        MemorySourceBounds::default(),
    )?;
    let prepared = source.prepare_projection(&["label", "id"], None, None)?;
    let arrays = prepared.execute_arrays()?;
    assert_eq!(arrays.row_count(), 2);
    drop(arrays);
    let rows = prepared.execute()?;
    println!("{}", rows.values_json.value());
    Ok(())
}
```

The JSON result contains both complete rows, including the exact signed 64-bit
integer and null values. `execute_arrays()` retains native arrays;
`execute()` explicitly materializes complete bounded JSON. Repeated calls execute
again, without an answer cache. Owned arrays and JSON may outlive their prepared
operation and source; their retained buffers keep the corresponding reservations.

`MemoryColumnValues` admits nullable `Int64`, finite `Float64`, `Bool`, and `Utf8`
slices. All four retain nullable native DTypes, including an all-valid or empty
column. Duplicate names, names outside 1–256 UTF-8 bytes, mismatched lengths,
nonfinite floats, and more than 64 columns are rejected before native allocation.
Rust intake permits empty typed sources. Nested, decimal, binary, and arbitrary
externally allocated `ArrayRef` intake are outside this interface.

`prepare_projection(columns, filter, limit)` accepts an optional native Vortex
boolean expression and an optional source-order limit. The provider binds and
executes the filter; a null predicate excludes the row. Filtering precedes the
limit. This is the Rust provider boundary; public generated-row collect below
admits the supplied rows without additional predicates or limits.

`MemorySourceBounds` defaults to 65,536 input/output rows, 32 MiB of validated
input bytes, and 32 MiB of native output bytes. Callers may choose stricter bounds.
JSON also has an 8 MiB ceiling, reduced by a smaller requested output-byte bound.
Exceeding a bound fails the complete request instead of returning a truncated
preview. Use an explicit admitted export workflow for larger results.

The session pool admits native value, offset, and validity buffers before their
allocation and retains credits for their lifetime. It also owns completed JSON
capacity. Caller/parser storage, array metadata, upstream scratch that does not
use the session allocator, and process RSS are outside this accounting scope.
This is an immutable memory snapshot API, not an asynchronous ingestion queue,
native Python binding, general shared-memory import, or durable write API.

## Public Generated-Row Collect

The existing public workflow command accepts a bounded supplied-row batch:

```sh
shardloom run dataframe \
  --generated-source-kind user_rows \
  --generated-schema 'id:int64,label:utf8' \
  --generated-rows 'id=9223372036854775807,label=%CE%BB;id=-9223372036854775808,label=hello' \
  --request collect --bounded true \
  --execution-policy native_vortex --materialization-policy bounded \
  --memory-gb 1 --max-parallelism 2 --format json
```

The complete response reports `generated_rows_memory_collect`,
`publication_state=visible_in_memory`, `durable=false`, `write_io_performed=false`,
`fallback_attempted=false`, and `external_engine_invoked=false`. There is no
intermediate file. A persistent public worker retains the runtime and budget;
each call validates and constructs a fresh immutable batch from the supplied
values. Worker request frames are capped at 16 MiB before JSON parsing, excluding
the newline delimiter. Each request admits at most 4,096 string arguments;
unknown request metadata is skipped without materializing its JSON tree, and
duplicate argument lists fail. An oversized frame returns an error and terminates the
worker; malformed bounded requests clear retained execution context. Starting a
new worker permits subsequent valid requests.

This adapter preserves the existing percent-encoded schema and row grammar:
commas separate fields, semicolons separate rows, and reserved characters inside
names or values must be percent-encoded. It admits `int64`, finite `float64`,
`bool`, and `utf8`. The grammar has no null token: `null` in a UTF-8 column is the
literal string; `null` in a numeric column is invalid. Use typed Rust intake for
nullable batches. Empty public row payloads are rejected.

The combined raw schema/rows payload is capped at 8 MiB, 64 columns, and 65,536
rows before parsing. Native and JSON output bounds also apply. Explicit supplied
`literal_table`, `calendar`, `dataframe_source_free_projection`, and
`dataframe_generated_with_column` batches use the same path with their existing
shape constraints. This route rejects input/output paths, SQL, filters, limits,
other operation payloads, `prepare_once`, and `zero_decode` materialization.

Python can call this public workflow through its existing CLI-backed worker
transport. This does not add an in-process native Python binding or change every
`LazyFrame` generated-source route.

## Prepared Local File Results

`local_primitives::collect::prepare_rows_in_session(request, session)` retains a
validated native file source and its bound projection/filter. Its
`execute_arrays()` and `execute()` methods return complete owned native arrays
and bounded JSON respectively. `prepare_count_in_session(request, session)`
returns a prepared exact footer count, whose `execute()` returns `u64`.

Direct single-file public count, projection, and exact filter collect calls retain
their prepared operation in the persistent worker. A changed request releases the
previous file handle. Every execution validates source generation; replacement or
mutation fails explicitly, clears the handle, and allows the next call to prepare
the current source. Compatibility-input preparation and manifest/directory routes
have separate policies and do not inherit this single-file reuse guarantee.

The final resident owner signals and joins its background CPU drivers before
ordinary caller teardown returns. Returned native arrays retain that owner until
their last reference is released. Upstream blocking I/O uses a separate provider
pool; an active blocking read remains cooperative and retains its allocator
credits until it returns. This is not a guarantee of interruptible I/O shutdown.

The count route reports zero row reads, decoding, and row materialization. Its
file I/O scope is source-generation checks plus the initial footer open. It does
not fabricate a row-execution report or independent correctness certificate.

### Shared-session serving scope

The default exclusive batch session serializes admission. A short
metadata count submitted while a scan holds admission waits for that scan to
finish or return an error. Explicit serving sessions use the bounded policy
described above. The earlier exclusive-session
[file-backed serving tests](../../shardloom-vortex/src/resident_file_serving_tests.rs)
cover contended arrivals at P1/P4, complete ordered scan values, complete counts,
cooperative scan cancellation after a native read returns, and recovery under
retained-result memory pressure. The focused three-test run passed on September
12; it does not establish full-workspace acceptance.

The deliberately gated fixture records arrival-to-native-callback queue residence
and completion latency. Queue residence includes source-generation admission;
these are fixture diagnostics, not production latency percentiles. These earlier tests
establish completion of the submitted callers, not FIFO fairness, cancellation
while waiting on admission, or interruption of blocked I/O. They do not run
small-query traffic during ingest or change the scheduler. Native buffer credits
and constructed worker counts retain their existing accounting scope; they do
not measure total RSS or actual CPU utilization.

## Native Array Output

With `vortex-write` enabled, admitted single-file projection, filter/projection,
and source-column alias exports stream native arrays directly into a Vortex
writer. For example, an existing native source with nullable UTF-8 `label` and
integer `id` columns can write a renamed projection:

```sh
shardloom run dataframe --input source.vortex --input-format vortex \
  --request write_vortex --output selected.vortex --bounded true \
  --vortex-primitive expression_project --vortex-columns label,id \
  --vortex-expression-projection '{"structured_columns":[{"name":"renamed_label","source":"label"},{"name":"id","source":"id"}]}' \
  --vortex-source-order-limit 10003 --memory-gb 1 --max-parallelism 2 --format json
```

The writer completes one native leaf at a time. Its bounded handoff retains at
most three input batches across the active writer, channel and pending caller.
It validates source generation, reopens the completed output to check DType and
row count, computes a complete checksum, and then publishes the staged artifact.
Unknown staging files or replaced destination identities are preserved on error.

The response reports `native_vortex_result_export_kind=owned_native_array_stream`
and records native arrays, logical bytes, adapter copies, scalar materialization,
reserved-byte scope and checksum. This adapter performs no Arrow conversion or
scalar row construction. The provider may canonicalize lazy/unsupported physical
encodings for serialization; the counters do not establish zero provider decode
or zero-copy execution. DType and validity are preserved. Original file layout,
user metadata and file-level statistics are not copied or recomputed by this path.

An unfiltered source can report its exact pre-limit footer count. A filtered scan
that stops at its limit reports a lower bound on matches; it does not perform an
extra full scan for that count. Other structured expressions and compatibility
formats retain their separately admitted execution paths.

## Bounded Compatibility Ingest Ownership

The supplied CPU and memory limits apply to the operation, across Rust, CLI and
Python entrypoints. CPU owners select at most the supplied `max_parallelism` and
the capacity available to the process; explicit one-CPU settings are preserved.
Budgets may differ between operations. Existing owners are not resized mid-call.
Serial input, limited independent work and memory pressure may reduce useful
parallelism; this contract does not promise full CPU utilization for every input.

Streaming ingestion shares one native executor across source tasks, conversion,
statistics, compression and layout work. Its caller and joined background drivers
fit one CPU grant. Full bounded queues release their drivers to other ready work.
Source task windows follow natural reader work; conversion windows follow the
applied CPU grant and observed batch memory needs, without fixed P4/P6/P8 tiers
or a 32-conversion ceiling. Requested and applied counts remain distinct evidence.
Blocking I/O services and source-library internal threads remain outside this
scoped CPU-driver accounting. See the
[allocation contract](../architecture/adaptive-ingest-budget-2026-10-02.md).

With `vortex-write` and `universal-format-io`, the streaming Rust ingest request
accepts `shared_native_memory_budget_bytes(bytes)`. Public bounded compatibility
ingest forwards its memory budget to this option. Imported Arrow value, offset,
validity and child buffers are copied into the native session allocator before
handoff. Their allocation credits survive conversion, queued work and writer
ownership until the last buffer reference is dropped. This intake makes no
zero-copy claim: Arrow's public buffer capacity cannot establish the retained
allocation size of an arbitrary external owner.

The shared pool covers those native copies, prefetch admission, provider host
allocations made through the session allocator, and root layout references.
Original source/input owners until conversion, reader internals, provider codec
or metadata allocations that bypass that allocator, and process RSS are excluded.
Evidence reports the admitted scope and exclusions alongside reserved-byte peaks.

The writer completes one source batch subtree before admitting the next. Native
coalescing and dictionary domains are therefore limited to each source batch;
this physical policy can change output layout, size and throughput. The Rust
option remains explicit, and omitting it preserves the existing ingest policy.
Performance and memory claims require measurements of the selected policy.

### Rust streaming-source migration: held file generations

The September 12 source-generation change adds the required public field
`FlatLocalColumnarStreamSource.source_identities`. This is a Rust source
compatibility change for downstream callers constructing the struct directly;
existing struct literals must be updated. For a manually constructed in-memory
source, or a custom source that does not carry a file-generation guard, add this
field to the existing literal:

```rust
source_identities: Vec::new(),
```

The shared ingest executor adds `ingest_runtime` when `vortex-write` is enabled.
Manual custom-reader literals use `ingest_runtime: None`; wrappers must preserve
the adapter-produced handle when keeping that adapter's reader. Cloning the
handle starts no workers and cannot admit overlapping writer driver groups.

This is a field fragment, not a complete construction example. An empty vector
does not certify source immutability. When wrapping an adapter-produced source,
preserve its identities along with its reader; a combined source must retain
every contributing identity through final writer validation.

For local Parquet intake, prefer
`shardloom_vortex::stream_flat_parquet_columnar_source(path, max_rows)` or
`stream_flat_parquet_columnar_source_with_parallelism(path, max_rows, parallelism)`
over manually assembling the struct. With `universal-format-io`, these
[adapter constructors](../../shardloom-vortex/src/universal_format_io.rs)
automatically capture a held identity on Unix. The optional
`stream_flat_parquet_columnar_source_with_batch_budget` variant lives in
`shardloom_vortex::universal_format_io`; `max_rows` bounds the complete
source, rather than truncating its result. Writing the stream additionally
requires `vortex-write`.

The guard compares the held descriptor and current path's device, inode, length,
modification time and change time. Parquet opens, source pulls and EOF are checked;
the streaming writer checks again after writing and before publication, including
empty streams. A detected change invalidates that identity and fails the request
without fallback. Recreate the source with an adapter constructor after resolving
the mutation. Existing conversion/provider errors remain the primary failure when
the reader itself fails.

These are generation checks, not an atomic filesystem snapshot or a content hash.
Keep the source immutable throughout intake; a source change after the final
check is not atomically excluded by output publication. Automatic compatibility
intake protection currently covers Unix Parquet, including identities carried by
the partition adapter. Arrow IPC, text and other adapters do not acquire this
guard. Non-Unix Parquet retains the existing input route and reports
`source_generation_guard=unavailable_non_unix`.

The
[streaming pressure and mutation tests](../../shardloom-vortex/src/vortex_ingest_pipeline_pressure_tests.rs)
exercise replacement, truncation and same-size mutation with restored modification
time before pull and after EOF, including empty sources, native output validation,
destination preservation and credit release. Their seven cases passed within the
focused 21-test streaming run on September 12. This evidence does not establish
blocked-codec cancellation, crash durability, or protection for other formats.
Ordinary streaming publication flushes, validates and renames; it does not add
file or parent-directory fsync. Broader checks and remaining acceptance stay in
the [implementation plan](../architecture/ingest-performance-implementation-2026-09-12.md).

## Validation Surfaces

`resident_memory_latency` measures full borrowed-view construction, validation,
native intake, binding, filtering/projection, and complete JSON return. It reports
isolated and concurrent shared-session load separately, verifies complete
foreground values against a literal fixture, and retains raw samples. The
default remains `resident_memory_latency 1000` with the original 32-row nullable
five-field fixture. `resident_memory_latency 1000 int64_64k` selects 4,096 rows
of two nonnullable native Int64 columns and returns the final eight exact rows.
That profile has exactly 65,536 raw value bytes; typed-input admission is 65,562
bytes including its 26 bytes of field names. Neither figure is total retained
process memory. Both profiles report p50/p95/p99 for isolated execution and the
same 16,384-row background workload sharing their resident session. Every
foreground result is checked completely; the background's complete independent
values are checked before overlap and its row count on every operation. Results
apply to the measured profile and do not establish a general latency guarantee.

The `resident_latency` example separates prepared file arrays from JSON rendering;
`scripts/run_resident_call_path_uat.py` compares the public process, persistent
worker, and Python client boundaries. Follow
[local development storage rules](../architecture/local-development-storage.md)
for retained benchmark artifacts. These interfaces alone do not close the broader
PERF acceptance gates or establish a latency claim.
