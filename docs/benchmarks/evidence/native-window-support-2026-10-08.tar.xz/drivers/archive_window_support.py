"""Archive final support pages, native examples and observed browser behavior."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

import window_acceptance_common as a
import window_support_common as c


def guard(name, status='passed'):
    path = c.OUT / f'{name}.json'
    value = c.read(path)
    assert value['status'] == status
    assert value['returncode'] == (0 if status == 'passed' else 1)
    assert value['process_group_drained'] and value['direct_child_reaped']
    assert c.sha(path.with_suffix('.log')) == value['log_sha256']
    return value


def main():
    _, build, annotation = c.checked_runtime()
    checks = c.read(c.OUT / 'window-support-checks-2/summary.json')
    assert checks['status'] == 'passed' and len(checks['checks']) == 7
    assert checks['runtime_provenance'] == annotation
    assert checks['binary_sha256'] == build['binary_sha256']
    assert len(checks['executed_examples']) == 6
    for item in checks['checks']:
        assert item['returncode'] == 0 and c.sha(item['log']) == item['log_sha256']
    for item in checks['executed_examples']:
        assert c.sha(c.ROOT / item['source']) == item['source_sha256']
        assert hashlib.sha256(item['code'].encode()).hexdigest() == item['code_sha256']
        assert item['envelope']['status'] == 'success'
        assert item['complete_rows']
    assert c.sha(c.OUT / 'verify_window_support.py') == checks['driver_sha256']
    assert c.sha(c.OUT / 'window_support_common.py') == checks['support_helper_sha256']
    guards = {name: guard(name) for name in (
        'window-support-validation-2', 'window-documentation-preview-2')}
    assert (c.OUT / 'window-documentation-preview-stop-2').is_file()
    browser = c.read(c.OUT / 'window-documentation-browser-2.json')
    assert browser['status'] == 'passed_manual_browser_review'
    assert not browser['console_warnings_errors']
    for name in ('desktop', 'mobile', 'resources', 'limitations'):
        assert browser[name]['body'] <= browser[name]['viewport']
    assert browser['desktop']['theme'] == 'dark' and browser['mobile']['theme'] == 'light'
    assert browser['search']['landed_url'].endswith('/python-surface/#consume-results-in-batches')
    assert 'window' in browser['search']['text'].lower()
    assert browser['mobile_menu_opened_and_closed'] and browser['temporary_viewport_reset']
    assert browser['tab_closed']
    for name in browser['screenshots']:
        path = c.OUT / name
        assert path.is_file() and not path.is_symlink() and path.stat().st_size > 0
    revised = {name: {'checked_sha256': digest, 'final_sha256': c.sha(c.ROOT / name)}
               for name, digest in checks['documentation_source_hashes'].items()
               if c.sha(c.ROOT / name) != digest}
    assert set(revised) <= {
        'docs/architecture/native-window-pressure-2026-10-08.md',
        'docs/architecture/phased-execution-plan.md',
        'docs/benchmarks/native-window-pressure-2026-10-08.md',
        'docs/release/v1-inclusion-scope-matrix.md'}, revised

    paths = {}
    for prefix in ('window-support-', 'window-documentation-', 'window-docs-'):
        for path in sorted(c.OUT.glob(prefix + '*')):
            for item in sorted(path.rglob('*')) if path.is_dir() else [path]:
                if item.is_file():
                    assert not item.is_symlink()
                    paths['proof/' + str(item.relative_to(c.OUT))] = item
    for name in ('verify_window_support.py', 'window_support_common.py',
                 'preview_window_documentation.py',
                 'window_acceptance_common.py', 'run_guarded.py',
                 'finalize_window_support.py', Path(__file__).name):
        paths['drivers/' + name] = c.OUT / name
    names = a.git('diff', '--name-only', 'HEAD').splitlines()
    names += a.git('ls-files', '--others', '--exclude-standard').splitlines()
    for name in sorted(set(names)):
        path = c.ROOT / name
        if path.is_file() and not name.startswith('docs/benchmarks/evidence/'):
            assert name.startswith(('docs/', 'website-src/', 'website/')) or name in (
                'python/README.md', 'python/src/shardloom/query.py'), name
            assert not path.is_symlink()
            paths['source/' + name] = path
    assert sum(path.stat().st_size for path in paths.values()) < 32 * 1024 * 1024
    manifest = {name: {'bytes': path.stat().st_size, 'sha256': c.sha(path)}
                for name, path in sorted(paths.items())}
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    browser_bytes = c.portable(browser).encode()
    target = c.ROOT / 'docs/benchmarks/evidence/native-window-support-2026-10-08.tar.xz'
    with tarfile.open(target, 'x:xz', preset=6) as archive:
        for name, path in sorted(paths.items()):
            info = tarfile.TarInfo(name)
            info.size = path.stat().st_size
            info.mode = 0o644
            with path.open('rb') as stream:
                archive.addfile(info, stream)
        for name, raw in (('manifest.json', manifest_bytes), ('browser.json', browser_bytes)):
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(raw))
    with tarfile.open(target, 'r:xz') as archive:
        members = archive.getmembers()
        assert len(members) == len(manifest) + 2
        assert {item.name for item in members} == set(manifest) | {'manifest.json', 'browser.json'}
        assert archive.extractfile('manifest.json').read() == manifest_bytes
        assert archive.extractfile('browser.json').read() == browser_bytes
        for name, expected in manifest.items():
            assert archive.getmember(name).isfile()
            with archive.extractfile(name) as stream:
                assert hashlib.file_digest(stream, 'sha256').hexdigest() == expected['sha256']
            assert archive.getmember(name).size == expected['bytes']
            assert c.sha(paths[name]) == expected['sha256'], name
    assert c.checked_runtime()[2] == annotation
    report = {
        'schema_version': 'shardloom.native_window_support_acceptance.v1',
        'status': 'passed_local_documentation_acceptance',
        'runtime_commit': annotation['accepted_runtime_commit'],
        'runtime_provenance': annotation,
        'documentation_checks': checks['checks'],
        'executed_examples': checks['executed_examples'],
        'post_check_status_prose_changes': revised,
        'browser': browser, 'guards': guards,
        'review_correction': 'Aligned native window pressure and single-use streamed windows in canonical guides and generated output; corrected stale join integration prose while preserving pivot, repeated-batch, compatibility-stream, allocation and platform limits.',
        'runtime_implementation_rerun_required': False,
        'archive': {'path': str(target.relative_to(c.ROOT)),
                    'bytes': target.stat().st_size, 'sha256': c.sha(target),
                    'file_members': len(manifest), 'total_members': len(manifest) + 2,
                    'manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
                    'all_members_reopened_and_hash_checked': True},
        'source_files': {name.removeprefix('source/'): item
                         for name, item in manifest.items() if name.startswith('source/')},
        'temporary_servers_drained': True,
        'hosted_integration': 'pending',
        'claim_boundary': 'Exact documentation, six native examples and generated guides; no new performance, whole-process RSS or package claim.',
        'driver_sha256': c.sha(__file__),
    }
    result_path = target.with_name('native-window-support-2026-10-08.json')
    with result_path.open('x') as stream:
        stream.write(c.portable(report))
    print(json.dumps({'status': 'passed', 'members': len(manifest) + 2,
                      'bytes': target.stat().st_size, 'sha256': c.sha(target)}), flush=True)


if __name__ == '__main__':
    main()
