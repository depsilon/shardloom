"""Validate the nullable provider test-diagnostic follow-up documentation."""
import hashlib
from pathlib import Path

path = Path(__file__).with_name('run_text_scan_final_docs_645.py')
raw = path.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '3c6da1e5c800727e7a776e644be31a3c913103fe018a750a39c3fbd32fbba251'
source = raw.decode().replace('native-text-scan-final-', 'nullable-layout-diagnostic-final-')
source = source.replace('-645.json', '-657.json')
exec(compile(source, __file__, 'exec'))
