"""Bind the merge to reviewed, hosted and locally accepted nullable-layout source."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys

O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
D = O / 'nullable-layout-hosted-658'
sys.path.insert(0, str(O))
import verify_stream_destination_integrated_sources_482 as verifier
verifier.R = R
read = lambda path: json.loads(Path(path).read_text())
identity = lambda path: dict(path=str(path), bytes=Path(path).stat().st_size,
    sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest())
coverage = read(D / 'pr-sources.json')
merge = sys.argv[1]
assert re.fullmatch('[a-f0-9]{40}', merge)
head, base, synthetic = coverage['head'], coverage['base'], coverage['ci_merge']
trees = {key: verifier.git('rev-parse', revision + '^{tree}').decode().strip()
    for key, revision in dict(head=head, synthetic=synthetic, merge=merge).items()}
assert len(set(trees.values())) == 1
parents = verifier.git('rev-list', '--parents', '-n', '1', merge).decode().split()
assert parents == [merge, base, head]
mapping, _ = verifier.immutable_source_map(merge)
assert len(mapping) == 2416
assert {path: item['sha256'] for path, item in mapping.items()} == coverage['source_sha256']
for field in ('accepted_source', 'tested_source', 'ci_source_bridge', 'artifacts', 'build_source', 'diagnostic_bridge', 'diagnostic_packet'):
    assert identity(coverage[field]['path']) == coverage[field]
assert read(coverage['accepted_source']['path'])['source_sha256'] == coverage['source_sha256']
tested = read(coverage['tested_source']['path'])['source_sha256']
build = read(coverage['build_source']['path'])['source_sha256']
assert tested.keys() == build.keys() == coverage['source_sha256'].keys()
assert {path for path, digest in tested.items() if digest != build[path]} == {'scripts/check_ci_gate_matrix.py'}
bridge = read(coverage['ci_source_bridge']['path'])
assert bridge['status'] == 'passed' and set(bridge['changes']) == {'scripts/check_ci_gate_matrix.py'}
diagnostic = read(coverage['diagnostic_bridge']['path'])
assert diagnostic['status'] == 'passed' and len(diagnostic['gates']) == 9
changes = {path: dict(before=build[path], after=digest) for path, digest in coverage['source_sha256'].items() if digest != build[path]}
assert changes == diagnostic['changes'] and set(changes) == {'vendor/vortex-file/src/lib.rs', 'vendor/vortex-file/src/tests.rs', 'vendor/vortex-layout/src/layouts/struct_/reader/tests/nullable.rs'}
before = verifier.git('show', '807c10ac423e0e7978158242e0e515629dfae80c:vendor/vortex-file/src/lib.rs').decode()
marker = '    #[cfg(test)]\n    mod test {\n        use super::*;\n        use crate::*;'
assert before.count(marker) == 1
assert before.replace(marker, marker.replace('        use super::*;\n', '')) == verifier.git('show', merge + ':vendor/vortex-file/src/lib.rs').decode()
assert read(coverage['artifacts']['path'])['source_sha256'] == build
record = dict(status='passed', recorded_at=datetime.now(timezone.utc).isoformat(),
    head=head, base=base, merge=merge, ci_merge=synthetic, trees=trees,
    parents=parents[1:], source_files=mapping, selected_source_count=2416,
    all_selected_sources_match=True, accepted_source=coverage['accepted_source'],
    tested_source=coverage['tested_source'], ci_source_bridge=coverage['ci_source_bridge'],
    build_source=coverage['build_source'], diagnostic_bridge=coverage['diagnostic_bridge'],
    test_only_source_changes=changes, accepted_non_test_runtime_unchanged=True,
    pr_source_verification=identity(D / 'pr-sources.json'),
    helper=identity(Path(verifier.__file__)), executed_program=identity(Path(__file__)),
    scope='All 2,416 merged sources are byte-identical to the reviewed head, CI merge and final tested source. Build 650-a1 differs only in two cfg(test) fixture files and one redundant test-module import, verified by the diagnostic bridge. Rust gates 649 differ from the accepted build only in the validated CI checker.')
(D / 'merged-sources-658.json').open('x').write(json.dumps(record, indent=2) + '\n')
print(json.dumps(dict(status='passed', merge=merge, source_files=len(mapping),
    tree=next(iter(trees.values())))))
