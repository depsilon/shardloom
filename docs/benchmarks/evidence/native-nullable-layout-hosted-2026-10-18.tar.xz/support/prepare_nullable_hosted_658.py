"""Bind established hosted log readers to the nullable-layout PR and frozen sources."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
import sys

O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
D = O / 'nullable-layout-hosted-658'
read = lambda path: json.loads(Path(path).read_text())
identity = lambda path: dict(path=str(path), bytes=Path(path).stat().st_size,
    sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest())
save = lambda path, value: Path(path).open('x').write(json.dumps(value, indent=2) + '\n')
parser = argparse.ArgumentParser()
for name in ('head', 'base', 'synthetic', 'jobs-file'):
    parser.add_argument('--' + name, required=True)
parser.add_argument('--pr', type=int, required=True)
parser.add_argument('--run', type=int, required=True)
args = parser.parse_args()
assert all(re.fullmatch('[a-f0-9]{40}', getattr(args, name)) for name in ('head', 'base', 'synthetic'))
assert args.pr > 1573 and args.run > 0 and not D.exists()
sys.path.insert(0, str(O))
import verify_stream_destination_integrated_sources_482 as verifier
verifier.R = R
selected = O / 'native-release-source-nullable657a4.json'
expected = read(selected)['source_sha256']
assert len(expected) == 2416
build_path = O / 'native-release-source-nullable650a1.json'
build_source = read(build_path)['source_sha256']
bridge_path = O / 'nullable-layout-diagnostic-bridge-657-a4.json'
bridge = read(bridge_path)
assert bridge['status'] == 'passed' and len(bridge['gates']) == 9
assert all(gate['returncode'] == 0 for gate in bridge['gates'])
changes = {name: dict(before=build_source[name], after=expected[name]) for name in expected if expected[name] != build_source[name]}
assert changes == bridge['changes'] and set(changes) == {
    'vendor/vortex-file/src/lib.rs', 'vendor/vortex-file/src/tests.rs',
    'vendor/vortex-layout/src/layouts/struct_/reader/tests/nullable.rs'}
lib_before = verifier.git('show', '807c10ac423e0e7978158242e0e515629dfae80c:vendor/vortex-file/src/lib.rs').decode()
lib_marker = '    #[cfg(test)]\n    mod test {\n        use super::*;\n        use crate::*;'
assert lib_before.count(lib_marker) == 1
assert lib_before.replace(lib_marker, lib_marker.replace('        use super::*;\n', '')) == verifier.git('show', args.head + ':vendor/vortex-file/src/lib.rs').decode()
maps, trees = {}, {}
for kind, revision in [('head', args.head), ('ci_merge', args.synthetic)]:
    mapping, _ = verifier.immutable_source_map(revision)
    assert {path: item['sha256'] for path, item in mapping.items()} == expected
    maps[kind] = verifier.identity_summary(mapping)
    trees[kind] = verifier.git('rev-parse', revision + '^{tree}').decode().strip()
assert len(set(trees.values())) == 1
parents = verifier.git('rev-list', '--parents', '-n', '1', args.synthetic).decode().split()
assert parents == [args.synthetic, args.base, args.head]
coverage = dict(status='passed', head=args.head, base=args.base, ci_merge=args.synthetic,
    trees=trees, source_files=2416, source_sha256=expected, source_maps=maps,
    accepted_source=identity(selected), tested_source=identity(O / 'native-release-source-nullable649.json'),
    ci_source_bridge=identity(O / 'nullable-layout-ci-bridge-650-a1.json'),
    build_source=identity(build_path), diagnostic_bridge=identity(bridge_path),
    diagnostic_packet=identity(R / 'docs/benchmarks/evidence/native-nullable-layout-test-diagnostics-2026-10-18.json'),
    artifacts=identity(O / 'native-release-artifacts-nullable650a1.json'),
    helper=identity(Path(verifier.__file__)),
    scope='All 2,416 selected sources in the reviewed head and CI merge match the final tested source. The accepted release build differs only in two cfg(test) fixture files and one redundant test-module import; the explicit diagnostic bridge preserves non-test runtime identity. The earlier Rust gates differ from that build only in the separately validated CI checker.')
inventory_path = O / 'nullable-layout-hosted-test-inventory-657.json'
original_inventory = read(inventory_path)
inventory = dict(original_inventory)
inventory['native_regression_tests'] = [dict(test, name=test['function_name'])
    for test in original_inventory['native_regression_tests']]
inventory['provider_regression_tests'] = [dict(test, name=test['function_name'])
    for family in ('layout_provider', 'file_provider')
    for test in original_inventory['provider_regression_tests'][family]]
inventory['head'] = args.head
for test in inventory['native_regression_tests'] + inventory['provider_regression_tests']:
    raw = verifier.git('show', args.head + ':' + test['path'])
    assert hashlib.sha256(raw).hexdigest() == test['source_sha256'] == expected[test['path']]
    assert 'fn ' + test['name'] + '(' in raw.decode().splitlines()[test['line'] - 1]
assert len(inventory['native_regression_tests']) == 2 and len(inventory['provider_regression_tests']) == 7
template = O / 'native-text-scan-hosted-646/hosted-validation-launch.json'
prior = read(template)
wanted = {'Python test shard (core)', 'Python test shard (release_scripts)',
    'Rust feature matrix (native_public_surface_tests)', 'Rust feature matrix (native_vortex_tests)',
    'Native Python wheel (py313_macos)', 'Native Python wheel (py313_ubuntu)',
    'Native Python wheel (py310_ubuntu)', 'Website and docs validation'}
jobdoc = read(args.jobs_file)
jobs = {job['id']: job['name'] for job in jobdoc['jobs'] if job['name'] in wanted}
assert len(jobs) == 8 and set(jobs.values()) == wanted
assert all(job['run_id'] == args.run and job['head_sha'] == args.head
           for job in jobdoc['jobs'] if job['id'] in jobs)
replacements = {
    'native-text-scan-hosted-646': 'nullable-layout-hosted-658',
    prior['source_verification']['head']: args.head,
    prior['source_verification']['base']: args.base,
    prior['source_verification']['ci_merge']: args.synthetic,
    '39094125843': str(args.run), '1573': str(args.pr), '2415': '2416',
    'groups[0]==(2967,0,28)': 'groups[0]==(2968,0,28)',
    'native_text_scan_reuse': 'native_nullable_layout',
    "inventory['native_new_tests']": "inventory['native_regression_tests']",
}
provider_checks = '''
   provider_observed=[]
   for test in inventory['provider_regression_tests']:
    raw=source(test['path']);assert hashlib.sha256(raw).hexdigest()==test['source_sha256'] and 'fn '+test['name']+'(' in raw.decode().splitlines()[test['line']-1]
    matches=re.findall(r'^test (.*::'+re.escape(test['name'])+r') \\.\\.\\. ok$',text,re.M);assert len(matches)==1,(test['name'],matches)
    provider_observed.append(dict(test,observed_test_path=matches[0]))
   assert (249,0,0) in groups and (140,0,0) in groups
   record['nullable_provider_regressions']=provider_observed
'''
programs = {}
for key in ('capture_source', 'acceptance_source', 'closeout_wrapper', 'served_source'):
    source = prior[key]
    assert hashlib.sha256(source.encode()).hexdigest() == prior[key + '_sha256']
    for before, after in replacements.items():
        source = source.replace(before, after)
    if key == 'capture_source':
        source, count = re.subn(r'^jobs=.*$', lambda _: 'jobs=' + repr(jobs), source, flags=re.M)
        assert count == 1
    if key == 'acceptance_source':
        marker = '   record.update(new_native_tests=observed,ignored_test_reasons=ignored)'
        assert source.count(marker) == 1
        source = source.replace(marker, marker + '\n' + provider_checks)
        source = source.replace('record.update(new_native_tests=', 'record.update(native_regressions=')
        assert 'groups[0]==(2968,0,28)' in source
        assert "inventory['native_regression_tests']" in source
    ast.parse(source)
    programs[key] = source
D.mkdir()
save(D / 'pr-sources.json', coverage)
save(D / 'test-inventory.json', inventory)
record = dict(programs, source_verification=coverage, test_inventory=inventory,
    template=identity(template), test_inventory_input=identity(inventory_path),
    job_inventory=identity(Path(args.jobs_file)), substitutions=replacements,
    added_provider_acceptance=provider_checks, program_file_created=False)
for key, source in programs.items():
    record[key + '_sha256'] = hashlib.sha256(source.encode()).hexdigest()
save(D / 'hosted-validation-launch.json', record)
print(json.dumps(dict(status='prepared', directory=str(D), pr=args.pr,
                     head=args.head, source_files=2416, jobs=8)))
