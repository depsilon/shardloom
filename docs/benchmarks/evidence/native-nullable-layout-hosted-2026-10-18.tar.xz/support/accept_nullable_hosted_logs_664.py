"""Accept original hosted logs with one explicit stdout/stderr interleave repair."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys

O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
D = O / 'nullable-layout-hosted-658'
launch_path = D / 'hosted-validation-launch.json'
launch = json.loads(launch_path.read_text())
source = launch['acceptance_source']
assert hashlib.sha256(source.encode()).hexdigest() == launch['acceptance_source_sha256']
helper = '''
def python_machine_report(text, schema):
    marker = '"schema_version": "' + schema + '"'
    assert text.count(marker) == 1
    offset = text.index(marker)
    start = text.rfind('\\n{\\n', 0, offset) + 1
    assert start > 0
    if text[start:start + 5] != '{\\nOK\\n':
        return a.machine_report(text, schema)
    assert schema == 'shardloom.python_test_shard_evidence.v1'
    assert metadata['name'] == 'Python test shard (release_scripts)'
    fragment = text[start:start + 2] + text[start + 5:]
    value, length = json.JSONDecoder().raw_decode(fragment)
    assert value['schema_version'] == schema and value['shard_id'] == 'release_scripts'
    assert value['status'] == 'passed' and value['error_count'] == value['failure_count'] == 0
    assert text[start:start + length + 3] == fragment[:2] + 'OK\\n' + fragment[2:length]
    return value, dict(start=start, end=start + length + 3,
        stdout_stderr_interleave=dict(line='OK', raw_start=start + 2, raw_end=start + 5,
            explanation='One exact unittest stderr success line appears immediately after the JSON opening brace in the merged Actions log.',
            parsed_json_sha256=hashlib.sha256(fragment[:length].encode()).hexdigest()))
'''
needle = "result,offsets=a.machine_report(text,'shardloom.python_test_shard_evidence.v1')"
assert source.count(needle) == 1
source = source.replace('a.LOGS=LOGS\n', 'a.LOGS=LOGS\n' + helper + '\n')
source = source.replace(needle, "result,offsets=python_machine_report(text,'shardloom.python_test_shard_evidence.v1')")
needle2 = "target=D/('primary-jobs-'+snapshot.parent.name+'.json')"
assert source.count(needle2) == 1
source = source.replace(needle2, "report['parser_correction']=a.identity(D/'acceptance-parser-correction-664.json')\n" + needle2)
ast.parse(source)
record = dict(status='prepared', original_launch_sha256=hashlib.sha256(launch_path.read_bytes()).hexdigest(),
    original_acceptance_source_sha256=launch['acceptance_source_sha256'],
    reason='Initial acceptance stopped at JSONDecodeError because unittest stderr OK interleaved inside the otherwise intact release_scripts JSON. No runtime or CI failure.',
    raw_logs_preserved=True, source=source, source_sha256=hashlib.sha256(source.encode()).hexdigest(),
    generator_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
path = D / 'acceptance-parser-correction-664.json'
path.open('x').write(json.dumps(record, indent=2) + '\n')
subprocess.run([sys.executable, '-B', '-', '--require-complete'], input=source, text=True, check=True)
