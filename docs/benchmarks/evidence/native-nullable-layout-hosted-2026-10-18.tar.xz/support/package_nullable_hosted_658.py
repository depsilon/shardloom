"""Preserve nullable-layout hosted closure without rewriting local observations."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
D = O / 'nullable-layout-hosted-658'
sys.path[:0] = [str(O), str(R / 'scripts')]
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
import verify_stream_destination_integrated_sources_482 as v
v.R = R
read = lambda path: json.loads(Path(path).read_text())
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
identity = lambda path: dict(path=str(path), bytes=Path(path).stat().st_size, sha256=sha(path))


def check(ref):
    path = Path(ref['path'])
    assert path.is_file() and not path.is_symlink() and sha(path) == ref['sha256'], path
    if 'bytes' in ref:
        assert path.stat().st_size == ref['bytes'], path
    return path


def immutable(path, revision):
    assert v.git('show', revision + ':' + path.relative_to(R).as_posix()) == path.read_bytes(), path


merge = sys.argv[1]
coverage = read(D / 'pr-sources.json')
merged = read(D / 'merged-sources-658.json')
head, synthetic = coverage['head'], coverage['ci_merge']
assert head == '7daf50a9fc9125b708310cbba0fb13ac4d83a0cc'
assert coverage['status'] == merged['status'] == 'passed' and merged['head'] == head and merged['merge'] == merge
mapping, _ = v.immutable_source_map(merge)
assert len(mapping) == 2416 and mapping == merged['source_files']
assert {path: item['sha256'] for path, item in mapping.items()} == coverage['source_sha256']
assert set(merged['trees'].values()) == {v.git('rev-parse', merge + '^{tree}').decode().strip()}
closeouts = {}
for stage in ('premerge', 'postmerge'):
    path = D / (stage + '-658') / 'report.json'
    result = read(path)
    assert result['status'] == 'passed' and result['checks_passed'] == 44
    assert result['head'] == head and result['merge'] == (merge if stage == 'postmerge' else None)
    assert result['review_threads'] == result['resolved_review_threads'] == 4
    assert result['unresolved_review_threads'] == result['open_pr_code_scanning_alerts'] == 0
    check(result['closeout_correction'])
    assert result['premerge_metadata_replayed'] == (stage == 'premerge')
    assert result['code_review'] == dict(commit_sha=head, has_any_findings=False, has_unresolved_findings=False, status='completed')
    assert result['review_coverage'] == dict(automated_review_head=head, final_head=head, automated_review_covers_final_head=True)
    for item in result['metadata'] + [result['source_verification'], result['helper']]:
        check(item)
    review_state = read(path.parent / 'review-state.json')['data']['repository']['pullRequest']
    assert len(review_state['reviewThreads']['nodes']) == 4
    assert all(row['isResolved'] for row in review_state['reviewThreads']['nodes'])
    checks = read(path.parent / 'checks.json')
    assert checks['total_count'] == len(checks['check_runs']) == 44
    assert all(row['head_sha'] == head and row['status'] == 'completed' and row['conclusion'] == 'success' for row in checks['check_runs'])
    closeouts[stage] = identity(path)
candidates = [path for path in D.glob('primary-jobs-capture-*.json') if read(path)['status'] == 'passed_all_eight']
assert len(candidates) == 1
jobs_path = candidates[0]
jobs = read(jobs_path)
assert jobs['head'] == head and jobs['synthetic'] == synthetic and not jobs['pending'] and len(jobs['jobs']) == 8
for key in ('capture', 'run', 'source_verification', 'test_inventory', 'capture_parameters', 'parser_helper'):
    check(jobs[key])
check(jobs['parser_correction'])
release_shard = next(row for row in jobs['jobs'] if row['name'] == 'Python test shard (release_scripts)')
assert release_shard['normalized_offsets']['stdout_stderr_interleave']['line'] == 'OK'
for row in jobs['jobs']:
    check(row['raw'])
    meta = read(check(row['metadata']))
    assert meta['head_sha'] == head and meta['status'] == 'completed' and meta['conclusion'] == 'success'
wheels = [row for row in jobs['jobs'] if row['name'].startswith('Native Python wheel')]
assert len(wheels) == 3
assert all(row['proof']['integration'] == dict(tests=100, failures=0, errors=0, skipped=0, status='passed') for row in wheels)
native = next(row for row in jobs['jobs'] if 'native_vortex_tests' in row['name'])
assert native['result_groups'][0] == [2968, 0, 28]
assert len(native['native_regressions']) == 2 and len(native['nullable_provider_regressions']) == 7
assert [249, 0, 0] in native['result_groups'] and [140, 0, 0] in native['result_groups']
assert native['total_passed'] == sum(group[0] for group in native['result_groups'])
assert next(row for row in jobs['jobs'] if 'native_public_surface_tests' in row['name'])['total_passed'] == 1079
served = {}
for stage, revision in [('preview', head), ('production', merge)]:
    path = D / (stage + '-served-569') / 'report.json'
    result = read(path)
    assert result['status'] == 'passed' and result['head'] == revision and result['reviewed_head'] == head and len(result['responses']) == 8
    checks = read(path.parent / 'deployment-checks.json')
    workers = [row for row in checks['check_runs'] if row['name'] == 'Workers Builds: shardloom']
    assert len(workers) == 1
    assert workers[0]['head_sha'] == revision and workers[0]['status'] == 'completed' and workers[0]['conclusion'] == 'success'
    for row in result['responses']:
        raw = (path.parent / row['response']).read_bytes()
        expected = v.git('show', revision + ':' + row['source'])
        assert row['http_status'] == 200 and row['source_preserved']
        assert len(raw) == row['observed_bytes'] and hashlib.sha256(raw).hexdigest() == row['observed_sha256']
        assert len(expected) == row['expected_bytes'] and hashlib.sha256(expected).hexdigest() == row['expected_sha256']
        if raw != expected:
            prefix = next(index for index, (a, b) in enumerate(zip(raw, expected)) if a != b)
            extra = len(raw) - len(expected)
            insertion = raw[prefix:prefix + extra]
            assert 0 < extra <= 16384 and raw[prefix + extra:] == expected[prefix:]
            assert b'/cdn-cgi/challenge-platform/' in insertion or b'static.cloudflareinsights.com/' in insertion
            assert extra == row['insertion_bytes'] and hashlib.sha256(insertion).hexdigest() == row['insertion_sha256']
    served[stage] = identity(path)
for stage in ('preview', 'production'):
    result = read(D / 'browser' / (stage + '-report.json'))
    assert result['status'] == 'passed' and result['head'] == head
    assert result['viewport_restored'] and result['mobile']['no_horizontal_overflow'] and not result['console']
    if stage == 'production':
        assert result['merge'] == merge
review_path = O / 'nullable-layout-final-review-652.json'
review = read(review_path)
assert review['status'] == 'passed' and review['selected_source_files'] == 2416 and not review['unresolved_local_findings']
assert review['exact_runtime_source_identity'] and not review['performance_claim']
index_path = check(review['portable_evidence'])
index = read(index_path)
assert index['status'] == 'passed_local_evidence_packaged' and index['source_files'] == 2416 and index['member_count'] == 27939
assert index['all_members_reopened'] and index['source_identity_preserved'] and not index['hosted_integration_complete']
expected_acceptance = dict(rust_test_executions=8810, rust_ignored=28, direct_tests=100,
    public_cases=4827, public_families=36, full43_calls=43, modular_cohorts=18,
    native_workflows=704, independent_oracle_records=704)
assert index['acceptance'] == review['acceptance'] == expected_acceptance
full43 = read(check(review['full43']))
assert full43['status'] == 'passed' and full43['calls'] == full43['queries'] == 43
assert index['full43_engine_seconds'] == full43['timing_totals']['totals']['engine_execution_seconds']
assert not index['performance_claim'] and not full43['performance_claim_allowed']
immutable(index_path, merge)
published = []
for item in [*index['archives'].values(), index['manifest']]:
    path = index_path.parent / item['file']
    assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256']
    immutable(path, merge)
    published.append(identity(path))
assert read(check(coverage['accepted_source']))['source_sha256'] == coverage['source_sha256']
for field in ('tested_source', 'ci_source_bridge', 'artifacts', 'build_source', 'diagnostic_bridge'):
    check(coverage[field])
build = read(check(coverage['build_source']))['source_sha256']
diagnostic = read(check(coverage['diagnostic_bridge']))
changes = {path: dict(before=build[path], after=digest)
    for path, digest in coverage['source_sha256'].items() if digest != build[path]}
assert diagnostic['status'] == 'passed' and len(diagnostic['gates']) == 9
assert changes == diagnostic['changes'] == merged['test_only_source_changes']
assert set(changes) == {'vendor/vortex-file/src/lib.rs', 'vendor/vortex-file/src/tests.rs',
    'vendor/vortex-layout/src/layouts/struct_/reader/tests/nullable.rs'}
assert merged['accepted_non_test_runtime_unchanged']
assert read(check(coverage['artifacts']))['source_sha256'] == build
diagnostic_index_path = check(coverage['diagnostic_packet'])
diagnostic_index = read(diagnostic_index_path)
assert diagnostic_index['status'] == 'passed' and diagnostic_index['accepted_runtime_unchanged']
assert diagnostic_index['changed_files'] == changes and diagnostic_index['member_count'] == 47
assert diagnostic_index['all_members_reopened']
diagnostic_archive_path = diagnostic_index_path.parent / diagnostic_index['archive']['file']
assert identity(diagnostic_archive_path) == dict(path=str(diagnostic_archive_path),
    **{key: diagnostic_index['archive'][key] for key in ('bytes', 'sha256')})
immutable(diagnostic_index_path, merge)
immutable(diagnostic_archive_path, merge)
with tarfile.open(diagnostic_archive_path, 'r:xz') as bundle:
    assert len(bundle.getmembers()) == len(diagnostic_index['members']) == 47
    assert len({member.name for member in bundle.getmembers()}) == 47
    for member in diagnostic_index['members']:
        entry = bundle.getmember(member['name'])
        assert entry.isfile()
        raw = bundle.extractfile(entry).read()
        assert len(raw) == member['bytes'] and hashlib.sha256(raw).hexdigest() == member['sha256']
final_docs_path = O / 'nullable-layout-diagnostic-final-doc-results-657.json'
final_docs_receipt = O / 'nullable-layout-diagnostic-final-docs-657.json'
assert read(final_docs_receipt)['status'] == read(final_docs_path)['status'] == 'passed'
assert len(read(final_docs_path)['checks']) == 16
assert all(row['returncode'] == 0 for row in read(final_docs_path)['checks'])
for field in ('archive_receipt', 'documentation_receipt', 'documentation_results'):
    assert read(check(review[field]))['status'] == 'passed'
assert all(row['returncode'] == 0 for row in read(check(review['documentation_results']))['checks'])
files = {}


def add(name, path):
    assert name not in files and path.is_file() and not path.is_symlink(), (name, path)
    files[name] = path


for path in sorted(D.rglob('*')):
    if path.is_file():
        add('hosted/' + path.relative_to(D).as_posix(), path)
support = [review_path, index_path, diagnostic_index_path, diagnostic_archive_path, final_docs_path,
    final_docs_receipt, *[check(coverage[key]) for key in ('accepted_source', 'tested_source',
        'ci_source_bridge', 'artifacts', 'build_source', 'diagnostic_bridge')],
    *[check(review[key]) for key in ('archive_receipt', 'documentation_receipt', 'documentation_results', 'full43')],
    O / 'nullable-layout-hosted-test-inventory-652.json', O / 'nullable-layout-hosted-jobs-658.json',
    O / 'nullable-layout-hosted-test-inventory-657.json', O / 'prepare_nullable_hosted_658.py',
    O / 'verify_nullable_merged_sources_658.py', O / 'run_nullable_final_docs_657.py',
    O / 'nullable-layout-diagnostic-final-docs-657.log',
    O / 'verify_nullable_final_review_652.py', O / 'run_nullable_final_docs_652.py',
    O / 'run_text_scan_final_docs_645.py', O / 'nullable-layout-final-docs-652.log',
    O / 'nullable-layout-archive-652.log', O / 'accept_nullable_hosted_logs_664.py',
    O / 'capture_nullable_closeout_664.py', Path(__file__)]
for path in support:
    add('support/' + (path.relative_to(O).as_posix() if path.is_relative_to(O) else 'repo/' + path.relative_to(R).as_posix()), path)
helpers = [check(jobs['parser_helper']), Path(read(D / 'capture-parameters.json')['helper']),
    Path(read(D / 'served-parameters.json')['helper']), Path(read(D / 'closeout-launch.json')['helper']),
    O / 'verify_worker_drain_integrated_sources_569.py', O / 'verify_stream_subquery_integrated_sources_513.py',
    Path(v.__file__), O / 'freeze_native_release_298.py', R / 'scripts/local_uat_storage.py']
for path in helpers:
    add('helpers/' + path.name, path)
for relative in ('docs/benchmarks/native-nullable-layout-2026-10-18.md',
    'docs/architecture/native-nullable-layout-2026-10-18.md', 'docs/architecture/native-drop-review-2026-10-18.md',
    'docs/architecture/phased-execution-plan.md', 'docs/architecture/phased-execution-completed-ledger.md'):
    path = R / relative
    immutable(path, merge)
    add('source/' + relative, path)
destination = require_local_path(O / 'nullable-layout-hosted-packet-658', Path.home(), sys.platform)
assert not destination.exists() and sum(path.stat().st_size for path in files.values()) < 32 * MIB
check_budgets(O, destination, O / 'logs', min_free_bytes=12*GIB, reserve_bytes=64*MIB,
    max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
destination.mkdir()
archive = destination / 'native-nullable-layout-hosted-2026-10-18.tar.xz'
members = []
with tarfile.open(archive, 'x:xz') as bundle:
    for name, path in sorted(files.items()):
        before, raw = identity(path), path.read_bytes()
        item = tarfile.TarInfo(name)
        item.size, item.mode = len(raw), 0o644
        bundle.addfile(item, io.BytesIO(raw))
        assert identity(path) == before
        members.append(dict(name=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(), original_path=str(path)))
with tarfile.open(archive, 'r:xz') as bundle:
    assert len(bundle.getmembers()) == len({item.name for item in bundle.getmembers()}) == len(members)
    for item in members:
        entry = bundle.getmember(item['name'])
        assert entry.isfile()
        raw = bundle.extractfile(entry).read()
        assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
        assert raw == files[item['name']].read_bytes()
report = dict(schema_version='shardloom.native_nullable_layout_hosted_packet.v1', status='passed',
    recorded_at=datetime.now(timezone.utc).isoformat(), pr=1574, head=head, merge=merge, synthetic=synthetic,
    checks_passed=44, source_files_verified=2416, native_total=native['total_passed'], native_library_tests=2968,
    native_ignored_tests=28, native_regression_fixtures=2, nullable_provider_regression_fixtures=7,
    native_public_total=1079, wheel_lanes=3, wheel_tests_per_lane=100, served_responses_verified=16,
    closeouts=closeouts, primary_jobs=identity(jobs_path), merged_sources=identity(D / 'merged-sources-658.json'),
    resolved_review_threads=4, unresolved_review_threads=0,
    served=served, preview_browser=identity(D / 'browser/preview-report.json'),
    production_browser=identity(D / 'browser/production-report.json'), local_evidence_index=identity(index_path),
    local_evidence_archives=published, local_acceptance=expected_acceptance, local_review=identity(review_path),
    final_tested_source_identity=True, accepted_non_test_runtime_unchanged=True,
    test_only_source_changes=changes, diagnostic_packet=identity(diagnostic_index_path),
    diagnostic_archive=identity(diagnostic_archive_path), final_documentation_results=identity(final_docs_path),
    full43_engine_seconds=index['full43_engine_seconds'], performance_claim=False,
    conclusion='Scoped nullable structural-layout correctness passes local acceptance, final-head hosted checks, installed wheels, review, merge and deployment verification. Broader PERF/CG obligations remain open.',
    archive=identity(archive), members_verified=len(members), members=members,
    limits=['Full43 is one retained-native regression pass, not a comparative speed claim.',
        'Browser checks cover the in-app browser and mobile navigation/search; no cross-browser claim.',
        'Installed-wheel lanes are CI builds; published 0.6.0 artifacts remain unchanged.',
        'No new public spill family, external-engine fallback or performance-superiority claim.'])
target = destination / 'native-nullable-layout-hosted-2026-10-18.json'
target.open('x').write(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(status='passed', report=str(target), archive=identity(archive), members=len(members), checks=44)))
