"""Bind final documentation and portable acceptance to the reviewed nullable runtime."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
sys.path[:0] = [str(O), str(R / 'scripts')]
import nullable_layout_acceptance_650 as acceptance

read = lambda path: json.loads(Path(path).read_text())
identity = acceptance.identity
source = acceptance.unchanged()
acceptance.protocol()
artifacts = acceptance.load()
assert len(source['source_sha256']) == 2416
bridge = read(O / 'nullable-layout-ci-bridge-650-a1.json')
assert bridge['status'] == 'passed' and set(bridge['changes']) == {'scripts/check_ci_gate_matrix.py'}
assert bridge['build_source'] == identity(acceptance.SOURCE)
assert bridge['old_narrow_target_rejected'] and bridge['missing_layout_clippy_rejected']
assert all(gate['returncode'] == 0 for gate in bridge['gates'])
index_path = R / 'docs/benchmarks/evidence/native-nullable-layout-2026-10-18.json'
index = read(index_path)
assert index['status'] == 'passed_local_evidence_packaged' and index['source_files'] == 2416
assert index['all_members_reopened'] and index['source_identity_preserved']
assert not index['performance_claim'] and not index['hosted_integration_complete']
assert index['source_manifest'] == identity(acceptance.SOURCE)
assert index['artifact_manifest'] == identity(acceptance.MANIFEST)
for item in [*index['archives'].values(), index['manifest']]:
    path = index_path.parent / item['file']
    assert path.stat().st_size == item['bytes'] and identity(path)['sha256'] == item['sha256']
verification = read(O / 'nullable-layout-evidence-652/verification.json')
assert verification['status'] == 'all_members_reopened'
assert verification['member_count'] == index['member_count']
assert verification['index'] == identity(index_path)
receipts = {}
for name in ('nullable-layout-archive-652', 'nullable-layout-final-docs-652'):
    path = O / (name + '.json')
    acceptance.receipt(path)
    receipts[name] = identity(path)
docs = O / 'nullable-layout-final-doc-results-652.json'
checks = read(docs)
assert checks['status'] == 'passed' and len(checks['checks']) == 16
assert all(check['returncode'] == 0 for check in checks['checks'])
inventory = read(O / 'nullable-layout-hosted-test-inventory-652.json')
tests = (inventory['native_regression_tests']
         + inventory['provider_regression_tests']['layout_provider']
         + inventory['provider_regression_tests']['file_provider'])
assert len(tests) == 9
for test in tests:
    raw = (R / test['path']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == test['source_sha256']
    assert 'fn ' + test['function_name'] + '(' in raw.decode().splitlines()[test['line'] - 1]
expected = dict(rust_test_executions=8810, rust_ignored=28, direct_tests=100,
    public_cases=4827, public_families=36, full43_calls=43,
    modular_cohorts=18, native_workflows=704, independent_oracle_records=704)
assert index['acceptance'] == expected
full43 = read(O / 'nullable-layout-full43-review-650.json')
assert full43['status'] == 'passed' and full43['queries'] == full43['calls'] == 43
assert index['full43_engine_seconds'] == full43['timing_totals']['totals']['engine_execution_seconds']
assert not full43['performance_claim_allowed']
subprocess.run(['git', 'diff', '--check'], cwd=R, check=True)
report = dict(status='passed', selected_source_files=2416,
    selected_source=identity(acceptance.SOURCE), tested_source=bridge['tested_source'],
    source_bridge=identity(O / 'nullable-layout-ci-bridge-650-a1.json'),
    artifacts=identity(acceptance.MANIFEST), exact_runtime_source_identity=True,
    portable_evidence=identity(index_path),
    archive_receipt=receipts['nullable-layout-archive-652'],
    documentation_results=identity(docs),
    documentation_receipt=receipts['nullable-layout-final-docs-652'],
    acceptance=expected, full43=identity(O / 'nullable-layout-full43-review-650.json'),
    performance_claim=False,
    reviewed_boundaries=[
        'Original root validity is applied before surrounding native expressions; new records and literals preserve their own semantics.',
        'Private validity and user field partitions have disjoint names and source scopes; null-only predicates do not read fields.',
        'Nullable pruning retains candidate rows when child-only statistics cannot prove the masked predicate.',
        'Ranges, incoming masks, empty/all-valid/all-null/mixed validity, nested records and encoded children have complete value and DType checks.',
        'Native persisted output and private query-run fixtures retain source/type identity and memory ownership through cleanup and release.',
        'Complete default/native/provider tests, 100 direct methods, all public workflows and all 18 finite format/oracle cohorts pass.',
        'The 28 existing ignored native selectors and reasons are unchanged; no skipped-test execution claim is made.',
        'Full43 is a single 43-call retained-native regression observation, not a comparative speed claim.',
        'The final accepted runtime source and binaries remain unchanged; the only earlier source bridge is the validated CI checker.',
        'The phase queue preserves remaining external-memory membership/population, destination recovery and encoded-transfer obligations.'
    ], unresolved_local_findings=[],
    remaining_gates=['final-head CI and automated review', 'three installed-wheel proofs',
        'preview source and browser checks', 'authorized merge and production source/browser verification'])
(O / 'nullable-layout-final-review-652.json').open('x').write(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(status='passed', selected_source_files=2416,
    portable_members=index['member_count'], documentation_checks=len(checks['checks']))))
