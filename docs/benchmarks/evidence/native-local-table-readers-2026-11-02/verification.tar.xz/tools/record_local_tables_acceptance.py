"""Archive exact local table-reader acceptance receipts and source evidence."""
from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile


O = Path(__file__).resolve().parents[1]
T = Path('/Users/dylan/.codex/worktrees/native-local-table-readers/shardloom-local-repo')
DEST = T / 'docs/benchmarks/evidence/native-local-table-readers-2026-11-02'
FIRST_NUMBER = 601
UNPACKED_LIMIT = 128 << 20
ARCHIVE_LIMIT = 8 << 20


def identity(data: bytes) -> dict[str, int | str]:
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def read_json(path: Path) -> dict:
    return json.loads(path.read_text())


def safe_name(value: str, label: str) -> str:
    if (not value or value in {'.', '..'} or Path(value).name != value
            or '/' in value or '\\' in value or '..' in Path(value).parts):
        raise ValueError(f'{label} must be a basename under the evidence directory')
    return value


def cargo_command(receipt: dict) -> list[str]:
    command = receipt.get('command', [])
    return command if isinstance(command, list) and command and command[0] == 'cargo' else []


def source_entry(path_name: str, entry: dict, root: Path) -> None:
    assert set(entry) >= {'bytes', 'sha256'}, (path_name, entry)
    assert identity((root / path_name).read_bytes()) == entry, path_name


def archive(args: argparse.Namespace) -> dict:
    runtime_name = safe_name(args.runtime, '--runtime')
    wheel_name = safe_name(args.wheel, '--wheel')
    runtime_dir = O / runtime_name
    wheel_dir = O / wheel_name
    assert re.fullmatch(r'io-runtime-local-tables-r[0-9]+', runtime_name)
    assert runtime_dir.is_dir() and not runtime_dir.is_symlink()
    assert re.fullmatch(r'installed-wheel-[A-Za-z0-9-]+', wheel_name)
    assert wheel_dir.is_dir() and not wheel_dir.is_symlink()
    if DEST.exists():
        raise FileExistsError(DEST)
    if args.last_number < FIRST_NUMBER:
        raise ValueError('--last-number must include the local table acceptance range')

    runtime = read_json(runtime_dir / 'manifest.json')
    source_revision = subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=T, text=True).strip()
    assert runtime['source_revision'] == source_revision
    for name, entry in runtime['source_snapshot'].items():
        source_entry(name, entry, T)
    runtime_files = runtime['files']
    for binary in ('_native.abi3.so', 'shardloom'):
        assert binary in runtime_files, binary
        assert identity((runtime_dir / binary).read_bytes()) == runtime_files[binary], binary

    wheel = read_json(wheel_dir / 'report.json')
    assert wheel['status'] == 'passed'
    assert wheel['uninstall_status'] == 'passed'
    integration = wheel['integration']
    assert integration['status'] == 'passed'
    assert integration['tests'] > 0
    assert integration['failures'] == integration['errors'] == integration['skipped'] == 0
    assert wheel['stage']['native_library_sha256'] == runtime_files['_native.abi3.so']['sha256']
    assert wheel['stage']['cli_sha256'] == runtime_files['shardloom']['sha256']

    final_names = [safe_name(item, '--final-receipts') for item in args.final_receipts]
    assert final_names and len(final_names) == len(set(final_names))
    final_receipt_numbers = set()
    for name in final_names:
        match = re.fullmatch(r'io([0-9]{3})-[A-Za-z0-9-]+\.json', name)
        assert match, name
        number = int(match.group(1))
        assert FIRST_NUMBER <= number <= args.last_number, (name, args.last_number)
        final_receipt_numbers.add(number)

    members: dict[str, bytes] = {}
    receipt_rows: list[dict] = []
    source_blobs: set[str] = set()
    receipts_by_name: dict[str, dict] = {}

    def add(path: Path, name: str | None = None) -> None:
        assert path.is_file() and not path.is_symlink(), path
        member_name = name or str(path.relative_to(O))
        assert (member_name not in members and not member_name.startswith('/')
                and '..' not in Path(member_name).parts), member_name
        members[member_name] = path.read_bytes()

    for number in range(FIRST_NUMBER, args.last_number + 1):
        paths = sorted(O.glob(f'io{number:03d}-*.json'))
        assert len(paths) == 1, (number, [path.name for path in paths])
        path = paths[0]
        receipt = read_json(path)
        assert receipt.get('status') in {'passed', 'failed'}, path.name
        log = path.with_suffix('.log')
        log_bytes = log.read_bytes()
        assert identity(log_bytes)['sha256'] == receipt['log_sha256'], path.name
        command = receipt.get('command', [])
        is_python_check = ('unittest' in command or any(
            str(arg).endswith('prove_native_python_wheel.py') for arg in command))
        if path.name in final_names:
            assert receipt['status'] == 'passed' and receipt.get('returncode') == 0, path.name
            assert receipt.get('process_group_drained') is True, path.name

        is_final_cargo = path.name in final_names and bool(cargo_command(receipt))
        if is_final_cargo:
            rust_entries = {name: entry for name, entry in receipt.get(
                'changed_source_inventory', {}).items()
                if name.endswith(('.rs', '.toml', '.lock'))}
            assert rust_entries, f'final Cargo receipt lacks Rust source identities: {path.name}'
            for name, entry in rust_entries.items():
                source_entry(name, entry, T)

        if path.name in final_names and is_python_check:
            for name, entry in receipt.get('changed_source_inventory', {}).items():
                if name.startswith('python/') and name.endswith('.py'):
                    source_entry(name, entry, T)

        add(path)
        add(log)
        row = dict(name=path.name, status=receipt['status'], returncode=receipt.get('returncode'),
                   final=path.name in final_names, receipt=identity(path.read_bytes()),
                   log=identity(log_bytes))
        results = re.findall(
            r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',
            log_bytes.decode('utf-8', errors='replace'))
        if results:
            row['rust_results'] = dict(
                binaries=len(results), passed=sum(int(item[1]) for item in results),
                failed=sum(int(item[2]) for item in results),
                ignored=sum(int(item[3]) for item in results))
        receipt_rows.append(row)
        receipts_by_name[path.name] = receipt
        if receipt.get('driver_sha256'):
            source_blobs.add(receipt['driver_sha256'])
        for field_name in ('changed_source_inventory', 'source_snapshot'):
            for entry in receipt.get(field_name, {}).values():
                if isinstance(entry, dict) and re.fullmatch(r'[0-9a-f]{64}', entry.get('sha256', '')):
                    source_blobs.add(entry['sha256'])

    assert final_names == [name for name in final_names if name in receipts_by_name]
    final_receipts = [receipts_by_name[name] for name in final_names]
    final_python_sources = {
        name
        for receipt in final_receipts
        for name in receipt.get('changed_source_inventory', {})
        if name.startswith('python/')
    }
    for required in ('python/tests/test_native_table_binding.py',
                     'python/tests/test_native_table_declarations.py'):
        assert required in final_python_sources, f'final receipt does not bind {required}'

    formatting_passed = any(
        receipt.get('command') == ['cargo', 'fmt', '--all', '--', '--check']
        for receipt in final_receipts)
    assert formatting_passed, 'final formatting receipt required'
    for action in ('clippy', 'test'):
        for native in (False, True):
            assert any(cargo_command(receipt)[1:2] == [action]
                and '--workspace' in receipt['command'] and '--all-targets' in receipt['command']
                and ('release-user-surfaces' in receipt['command']) == native
                for receipt in final_receipts), (action, native)
    for pattern in ('test_native_table_binding.py', 'test_native_table_declarations.py'):
        checks = [receipt for receipt in final_receipts if pattern in receipt.get('command', [])]
        assert len(checks) == 1, pattern
        log = O / next(name for name in final_names if receipts_by_name[name] is checks[0])
        text = log.with_suffix('.log').read_text()
        assert re.search(r'Ran [1-9][0-9]* tests', text) and '\nOK\n' in text, pattern
        assert 'skipped' not in text.lower(), pattern
        if pattern == 'test_native_table_binding.py':
            for variable, binary in (('SHARDLOOM_NATIVE_TEST_LIBRARY', '_native.abi3.so'),
                                     ('SHARDLOOM_SURFACE_TEST_BINARY', 'shardloom')):
                values = [arg.split('=', 1)[1] for arg in checks[0]['command']
                          if arg.startswith(variable + '=')]
                assert len(values) == 1, variable
                path = Path(values[0])
                assert path.is_relative_to(O) and path.is_file() and not path.is_symlink()
                assert identity(path.read_bytes()) == runtime_files[binary], variable
    assert any(any(str(arg).endswith('prove_native_python_wheel.py')
        for arg in receipt.get('command', [])) for receipt in final_receipts)
    format_row = dict(command=['cargo', 'fmt', '--all', '--', '--check'], status='passed')

    for digest in sorted(source_blobs):
        blob = O / 'source-blobs' / digest
        assert blob.is_file() and identity(blob.read_bytes())['sha256'] == digest, digest
        add(blob)

    for runtime_path in sorted(O.glob('io-runtime-local-tables-r*')):
        if runtime_path.is_dir() and not runtime_path.is_symlink():
            for filename in ('manifest.json', 'source-overlay.patch'):
                add(runtime_path / filename)
    for path in sorted(wheel_dir.iterdir()):
        if path.is_file() and path.suffix in {'.log', '.json'}:
            add(path)
    for script in ('run_guarded_table_readers.py', 'freeze_table_runtime.py',
                   Path(__file__).name):
        add(O / 'tools' / script)

    unpacked_bytes = sum(map(len, members.values()))
    assert unpacked_bytes < UNPACKED_LIMIT, unpacked_bytes
    DEST.mkdir(parents=True)
    archive_path = DEST / 'verification.tar.xz'
    with tarfile.open(archive_path, 'x:xz', preset=6) as bundle:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            bundle.addfile(info, io.BytesIO(data))
    with tarfile.open(archive_path, 'r:xz') as bundle:
        assert {item.name for item in bundle.getmembers()} == set(members)
        for item in bundle.getmembers():
            assert item.isfile() and bundle.extractfile(item).read() == members[item.name]
    archive_bytes = archive_path.read_bytes()
    assert len(archive_bytes) < ARCHIVE_LIMIT, len(archive_bytes)

    historical_rust_totals = dict(
        binaries=sum(row.get('rust_results', {}).get('binaries', 0) for row in receipt_rows),
        passed=sum(row.get('rust_results', {}).get('passed', 0) for row in receipt_rows),
        failed=sum(row.get('rust_results', {}).get('failed', 0) for row in receipt_rows),
        ignored=sum(row.get('rust_results', {}).get('ignored', 0) for row in receipt_rows))
    report = dict(
        schema_version='shardloom.native_local_table_readers_acceptance.v1',
        status='local_acceptance_passed', source_base=runtime['source_revision'],
        code_snapshot=runtime['source_snapshot'], runtime_files=runtime_files,
        installed_wheel=wheel['integrity'], installed_integration=integration,
        installed_load=wheel['installed_load'], uninstall_status=wheel['uninstall_status'],
        formatting=format_row,
        final_rust_test_results={row['name']: row['rust_results'] for row in receipt_rows
            if row['final'] and 'rust_results' in row},
        historical_rust_test_totals_including_repeated_and_failed_attempts=historical_rust_totals,
        final_receipts=final_names, all_receipts=receipt_rows,
        public_matrix=dict(
            formats=3, surfaces=5,
            grants=[dict(memory_bytes=16 << 20, lanes=2), dict(memory_bytes=128 << 20, lanes=2)],
            base_queries=240, typed_queries=15, delta_partition_queries=5,
            writes_and_readbacks=9, retained_results=3, output_alias_refusals=6,
            unsupported_state_refusals=15, conflicting_snapshot_refusals=9,
            schema_inspection_refusals=9,
            scope='authored current test scope; execution evidenced only by final receipts'),
        claims=['no benchmark or performance claim', 'hosted status pending'],
        hosted_acceptance='pending',
        archive=dict(path=archive_path.name, **identity(archive_bytes), members=len(members),
                     unpacked_bytes=unpacked_bytes, complete_byte_readback='passed',
                     member_identities={name: identity(data) for name, data in sorted(members.items())}))
    (DEST / 'acceptance.json').write_text(json.dumps(report, indent=2) + '\n')
    return dict(status=report['status'], destination=str(DEST), receipts=len(receipt_rows),
                members=len(members), archive_bytes=len(archive_bytes),
                final_rust_test_results=report['final_rust_test_results'])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--runtime', required=True, help='runtime directory basename under O')
    parser.add_argument('--wheel', required=True, help='installed wheel directory basename under O')
    parser.add_argument('--last-number', required=True, type=int)
    parser.add_argument('--final-receipts', required=True, nargs='+',
                        help='receipt JSON basenames, all within the included numbered range')
    print(json.dumps(archive(parser.parse_args()), sort_keys=True))


if __name__ == '__main__':
    main()
