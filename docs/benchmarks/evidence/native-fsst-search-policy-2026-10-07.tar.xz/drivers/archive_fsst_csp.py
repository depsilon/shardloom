"""Preserve the hosted-search regression and its narrow deployment-policy fix."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

import fsst_common as c

BASELINE = '2a392c0e1160f487d8412bece5b6187af97ab1d0'
EVIDENCE = c.ROOT / 'docs/benchmarks/evidence'
STEM = 'native-fsst-search-policy-2026-10-07'


def main():
    source = c.frozen()
    assert c.git('rev-parse', 'HEAD') == BASELINE
    static = c.read(c.OUT / 'fsst-csp-static-1/summary.json')
    assert static['status'] == 'passed_csp_source_and_static_checks'
    assert static['source_identity_sha256'] == source['source_identity_sha256']
    for name, digest in static['source_hashes'].items():
        assert c.sha(c.ROOT / name) == digest, name
    assert len(static['source_hashes']) == 6
    assert all(row['returncode'] == 0 for row in static['checks'])
    for name, status, code in (
        ('fsst-csp-regression-before-1', 'failed', 1),
        ('fsst-csp-build-2', 'passed', 0),
        ('fsst-csp-static-checks-1', 'passed', 0),
        ('fsst-csp-preview-1', 'passed', 0),
    ):
        record = c.read(c.OUT / (name + '.json'))
        assert record['status'] == status and record['returncode'] == code
        assert record['process_group_drained'] and record['direct_child_reaped']
        assert c.sha(c.OUT / (name + '.log')) == record['log_sha256']
    launch = c.read(c.OUT / 'fsst-csp-build-1.json')
    assert launch['status'] == 'failed' and launch['returncode'] is None
    assert launch['error'].startswith('FileNotFoundError:') and 'pid' not in launch
    assert c.sha(c.OUT / 'fsst-csp-build-1.log') == launch['log_sha256']
    failed = c.read(c.OUT / 'fsst-hosted-preview-failure-1.json')
    assert failed['status'] == 'failed_hosted_search_csp' and failed['head'] == BASELINE
    assert 'Searching for streaming...' in failed['search']['text']
    assert len(failed['warningAndErrorLogs']) == 3
    assert all('WebAssembly.instantiate()' in row['message'] for row in failed['warningAndErrorLogs'])
    browser = c.read(c.OUT / 'fsst-csp-browser-1.json')
    assert browser['status'] == 'passed_search_with_actual_deployment_headers'
    assert browser['baseline_head'] == BASELINE and not browser['console_warnings_errors']
    assert '4 results for streaming' in browser['search_state']
    assert browser['landed']['url'].endswith('/python-surface/#consume-results-in-batches')
    assert browser['landed']['viewport'] == browser['landed']['body']
    address = c.read(c.OUT / 'fsst-csp-preview-1-address.json')
    assert browser['preview'] == address['url']
    assert address['headers_sha256'] == c.sha(c.ROOT / 'website/_headers')
    assert (c.OUT / 'fsst-csp-preview-1-stop').is_file()
    assert c.sha(c.OUT / 'preview_fsst_csp.py') == address['driver_sha256']
    assert c.sha(c.OUT / 'verify_fsst_csp.py') == static['driver_sha256']
    docs_path = EVIDENCE / 'native-fsst-documentation-2026-10-07.json'
    docs = c.read(docs_path)
    assert len(docs['source_files']) == 29
    for name, expected in docs['source_files'].items():
        assert c.sha(c.ROOT / name) == expected['sha256'], name
    assert c.sha(c.ROOT / docs['archive']['path']) == docs['archive']['sha256']

    paths = {}
    for name in (
        'fsst-csp-regression-before-1', 'fsst-csp-build-1', 'fsst-csp-build-2',
        'fsst-csp-static-checks-1', 'fsst-csp-preview-1',
    ):
        for extension in ('.json', '.log'):
            paths['proof/' + name + extension] = c.OUT / (name + extension)
    for name in (
        'fsst-csp-preview-1-address.json', 'fsst-csp-preview-1-stop',
        'fsst-csp-browser-1.json', 'fsst-hosted-preview-failure-1.json',
        'fsst-hosted-preview-search-failure-1.jpg', *browser['screenshots'],
    ):
        paths['proof/' + name] = c.OUT / name
    for path in sorted((c.OUT / 'fsst-csp-static-1').iterdir()):
        assert path.is_file() and not path.is_symlink()
        paths['proof/fsst-csp-static-1/' + path.name] = path
    for name in ('preview_fsst_csp.py', 'verify_fsst_csp.py', 'fsst_common.py',
                 'run_guarded.py', Path(__file__).name):
        paths['drivers/' + name] = c.OUT / name
    for name in static['source_hashes']:
        paths['source/' + name] = c.ROOT / name
    assert sum(path.stat().st_size for path in paths.values()) < 8 * 1024 * 1024
    raw = {name: path.read_bytes() for name, path in paths.items()}
    raw['baseline/website-public/_headers'] = subprocess.check_output(
        ['git', 'show', BASELINE + ':website-public/_headers'], cwd=c.ROOT)
    before = raw['baseline/website-public/_headers']
    assert raw['source/website-public/_headers'] == before.replace(
        b"script-src 'self' 'unsafe-inline';",
        b"script-src 'self' 'unsafe-inline' 'wasm-unsafe-eval';")
    manifest = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                for name, data in sorted(raw.items())}
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    target = EVIDENCE / (STEM + '.tar.xz')
    with tarfile.open(target, 'x:xz', preset=6) as archive:
        for name, data in sorted((raw | {'manifest.json': manifest_bytes}).items()):
            item = tarfile.TarInfo(name)
            item.mode = 0o644
            item.size = len(data)
            archive.addfile(item, io.BytesIO(data))
    with tarfile.open(target, 'r:xz') as archive:
        assert len(archive.getmembers()) == len(raw) + 1
        assert {row.name for row in archive.getmembers()} == set(raw) | {'manifest.json'}
        assert archive.extractfile('manifest.json').read() == manifest_bytes
        for name, expected in manifest.items():
            assert archive.getmember(name).size == expected['bytes']
            with archive.extractfile(name) as stream:
                assert hashlib.file_digest(stream, 'sha256').hexdigest() == expected['sha256']
    c.frozen()
    record = {
        'schema_version': 'shardloom.native_fsst_search_policy_acceptance.v1',
        'status': 'passed_local_search_policy_acceptance',
        'baseline_head': BASELINE,
        'runtime_commit': 'b7de216fe421012d3f9b632ad19e95f19b88dbe5',
        'runtime_source_assets_unchanged': len(source['source_hashes']),
        'source_identity_sha256': source['source_identity_sha256'],
        'problem': 'Hosted Pagefind search remained pending because its WebAssembly compilation was blocked by script-src. A local preview without deployment headers did not expose the failure.',
        'change': static['only_header_policy_change'],
        'regression': 'The new source-policy test fails on the original headers; all seven tests, the complete site build, website readiness and browser search with actual deployment headers pass after the fix.',
        'original_hosted_failure_preserved': True,
        'failed_build_launch_preserved': 'The first npm path did not exist. No child launched; the actual npm build then passed. Both receipts and logs are archived.',
        'source_files': {name.removeprefix('source/'): item for name, item in manifest.items()
                         if name.startswith('source/')},
        'browser': browser,
        'original_documentation_assets_unchanged': len(docs['source_files']),
        'original_documentation_receipt_sha256': c.sha(docs_path),
        'original_documentation_archive_sha256': docs['archive']['sha256'],
        'archive': {'path': str(target.relative_to(c.ROOT)), 'bytes': target.stat().st_size,
                    'sha256': c.sha(target), 'total_members': len(raw) + 1,
                    'manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
                    'all_members_reopened_and_hash_checked': True},
        'sources': static['sources'],
        'temporary_preview_drained': True,
        'new_hosted_preview_verified': False,
        'driver_sha256': c.sha(__file__),
    }
    portable = json.dumps(record, indent=2, allow_nan=False)
    for path, replacement in ((c.ROOT, '<repo>'), (c.OUT, '<fsst-uat>'), (Path.home(), '<home>')):
        portable = portable.replace(str(path), replacement)
    with (EVIDENCE / (STEM + '.json')).open('x') as stream:
        stream.write(portable + '\n')
    print(json.dumps({'status': record['status'], 'archive_bytes': target.stat().st_size,
                      'members': len(raw) + 1, 'archive_sha256': c.sha(target)}), flush=True)


if __name__ == '__main__':
    main()
