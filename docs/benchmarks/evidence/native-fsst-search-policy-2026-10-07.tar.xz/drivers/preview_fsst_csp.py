"""Serve the built site with its actual global deployment security headers."""
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import os
import time

import fsst_common as c

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--attempt', type=int, required=True)
args = parser.parse_args()
assert args.attempt > 0
prefix = f'fsst-csp-preview-{args.attempt}'
stop = c.OUT / (prefix + '-stop')
assert not stop.exists()
c.frozen()
headers_path = c.ROOT / 'website/_headers'
headers_hash = c.sha(headers_path)
assert headers_path.read_bytes() == (c.ROOT / 'website-public/_headers').read_bytes()
headers = {}
route = None
for line in headers_path.read_text().splitlines():
    if not line.strip() or line.lstrip().startswith('#'):
        continue
    if not line[:1].isspace():
        route = line.strip()
    elif route == '/*':
        name, value = line.strip().split(':', 1)
        assert name not in headers
        headers[name] = value.strip()
assert len(headers) == 5 and 'Content-Security-Policy' in headers
assert "'wasm-unsafe-eval'" in headers['Content-Security-Policy']
assert "'unsafe-eval'" not in headers['Content-Security-Policy']


class Handler(SimpleHTTPRequestHandler):
    def end_headers(self):
        for name, value in headers.items():
            self.send_header(name, value)
        super().end_headers()


handler = partial(Handler, directory=str(c.ROOT / 'website'))
server = ThreadingHTTPServer(('127.0.0.1', 0), handler)
server.daemon_threads = True
server.timeout = 0.5
c.write(c.OUT / (prefix + '-address.json'), {
    'url': f'http://127.0.0.1:{server.server_address[1]}',
    'pid': os.getpid(), 'root': str(c.ROOT / 'website'),
    'maximum_seconds': 600, 'global_response_headers': headers,
    'headers_sha256': headers_hash, 'driver_sha256': c.sha(__file__),
})
deadline = time.monotonic() + 600
try:
    while not stop.exists() and time.monotonic() < deadline:
        server.handle_request()
finally:
    server.server_close()
assert stop.is_file(), 'browser review did not request preview shutdown before deadline'
assert c.sha(headers_path) == headers_hash
c.frozen()
print('Deployment-header preview closed after completed browser review', flush=True)
