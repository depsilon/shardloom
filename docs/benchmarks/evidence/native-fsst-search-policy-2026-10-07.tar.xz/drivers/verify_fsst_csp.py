"""Verify the narrow Pagefind policy repair without changing engine acceptance."""
import json
from pathlib import Path
import subprocess
import time

import fsst_common as c

HEAD = '2a392c0e1160f487d8412bece5b6187af97ab1d0'
paths = {
    'website-public/_headers', 'website/_headers', 'website-src/package.json',
    'website-src/scripts/postbuild-static.mjs',
    'website-src/scripts/pagefind-policy.mjs',
    'website-src/scripts/pagefind-policy.test.mjs',
}
source = c.frozen()
assert c.git('rev-parse', 'HEAD') == HEAD
changes = set(c.git('diff', '--name-only', 'HEAD').splitlines())
changes.update(c.git('ls-files', '--others', '--exclude-standard').splitlines())
assert changes == paths, changes
before = subprocess.check_output(['git', 'show', HEAD + ':website-public/_headers'], cwd=c.ROOT)
after = (c.ROOT / 'website-public/_headers').read_bytes()
assert before.count(b"script-src 'self' 'unsafe-inline';") == 1
assert after == before.replace(b"script-src 'self' 'unsafe-inline';", b"script-src 'self' 'unsafe-inline' 'wasm-unsafe-eval';")
assert (c.ROOT / 'website/_headers').read_bytes() == after
old_test = c.read(c.OUT / 'fsst-csp-regression-before-1.json')
assert old_test['status'] == 'failed' and old_test['returncode'] == 1
assert old_test['process_group_drained'] and old_test['direct_child_reaped']
old_log = (c.OUT / 'fsst-csp-regression-before-1.log').read_text()
assert 'tests 7' in old_log and 'pass 6' in old_log and 'fail 1' in old_log
assert 'Pagefind script-src must allow only' in old_log
build = c.read(c.OUT / 'fsst-csp-build-2.json')
assert build['status'] == 'passed' and build['returncode'] == 0
assert build['process_group_drained'] and build['direct_child_reaped']
assert c.sha(c.OUT / 'fsst-csp-build-2.log') == build['log_sha256']
log = (c.OUT / 'fsst-csp-build-2.log').read_text()
assert 'tests 7' in log and 'pass 7' in log and 'fail 0' in log
docs = c.read(c.ROOT / 'docs/benchmarks/evidence/native-fsst-documentation-2026-10-07.json')
for name, expected in docs['source_files'].items():
    assert c.sha(c.ROOT / name) == expected['sha256'], name
out = c.OUT / 'fsst-csp-static-1'
out.mkdir(exist_ok=False)
checks = []
for name, command in (
    ('website-readiness', [c.PYTHON, '-B', 'scripts/check_website_readiness.py', '--output', str(out / 'website-readiness-report.json')]),
    ('diff-whitespace', ['git', 'diff', '--check']),
):
    path = out / (name + '.log')
    start = time.monotonic()
    with path.open('xb') as stream:
        completed = subprocess.run(command, cwd=c.ROOT, stdout=stream, stderr=subprocess.STDOUT, timeout=60, check=False)
    row = {'name': name, 'returncode': completed.returncode, 'seconds': time.monotonic() - start,
           'command': command, 'log_sha256': c.sha(path), 'log_text': path.read_text()}
    checks.append(row)
    assert completed.returncode == 0, row
c.frozen()
report = {'status': 'passed_csp_source_and_static_checks', 'baseline_head': HEAD,
          'source_identity_sha256': source['source_identity_sha256'],
          'runtime_source_assets_unchanged': len(source['source_hashes']),
          'original_documentation_assets_unchanged': len(docs['source_files']),
          'only_header_policy_change': "Add 'wasm-unsafe-eval' to script-src; all other header bytes unchanged",
          'new_regression_tests': 7, 'original_policy_failure_preserved': True,
          'source_hashes': {name: c.sha(c.ROOT / name) for name in sorted(paths)},
          'checks': checks, 'driver_sha256': c.sha(__file__), 'browser_review_pending': True,
          'sources': ['https://pagefind.app/docs/hosting/#content-security-policy-csp',
                      'https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Content-Security-Policy/script-src']}
c.write(out / 'summary.json', report)
print(json.dumps({key: report[key] for key in ('status', 'runtime_source_assets_unchanged', 'original_documentation_assets_unchanged', 'new_regression_tests')}), flush=True)
