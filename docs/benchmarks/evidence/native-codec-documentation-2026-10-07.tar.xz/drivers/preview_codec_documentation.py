"""Serve the generated codec documentation from an owned temporary local port."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import os
import time

import codec_common as c

stop = c.OUT / 'codec-documentation-preview-stop-1'
assert not stop.exists()
handler = partial(SimpleHTTPRequestHandler, directory=str(c.ROOT / 'website'))
server = ThreadingHTTPServer(('127.0.0.1', 0), handler)
server.daemon_threads = True
server.timeout = 0.5
c.write(c.OUT / 'codec-documentation-preview-address-1.json', {
    'url': f'http://127.0.0.1:{server.server_address[1]}', 'pid': os.getpid(),
    'root': str(c.ROOT / 'website'), 'maximum_seconds': 600})
deadline = time.monotonic() + 600
try:
    while not stop.exists() and time.monotonic() < deadline:
        server.handle_request()
finally:
    server.server_close()
print('Preview server closed', flush=True)
