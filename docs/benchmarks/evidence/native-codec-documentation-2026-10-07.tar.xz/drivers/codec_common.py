"""Source and artifact identities for the bounded native codec workspace unit."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PRIOR = OUT.parent / 'native-hardware-campaign-20261006'
PYTHON = '/opt/homebrew/opt/python@3.13/libexec/bin/python3'
RUSTUP = '/Users/dylan/.cargo/bin/rustup'
BASE = '83d26a0e4acedab3e51bb8fc67437a867a13f28b'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def source_hashes():
    names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
    return {name: sha(ROOT / name) for name in sorted(set(names)) if name and (
        name.endswith(('.rs', '.py')) or Path(name).name in ('Cargo.toml', 'Cargo.lock')
        or name.startswith('vendor/'))}


def freeze(variant):
    assert git('rev-parse', 'HEAD') == BASE
    hashes = source_hashes()
    if variant == 'baseline':
        assert hashes == read(PRIOR / 'integration-repair-checks-2/summary.json')['source_hashes']
    result = {'variant': variant, 'status': 'frozen_before_build', 'head': BASE,
        'source_hashes': hashes,
        'source_identity_sha256': hashlib.sha256(json.dumps(hashes, sort_keys=True).encode()).hexdigest(),
        'working_tree': git('status', '--porcelain'), 'patch': git('diff', '--binary', 'HEAD'),
        'contract_sha256': sha(OUT / 'codec-workspace-contract.json'),
        'guard_sha256': sha(OUT / 'run_guarded.py'),
        'helpers': {name: sha(OUT / name) for name in ('codec_common.py', 'codec_experiment.py')}}
    write(OUT / f'{variant}-source-1.json', result)
    return result


def frozen(variant):
    source = read(OUT / f'{variant}-source-1.json')
    assert source_hashes() == source['source_hashes']
    assert git('rev-parse', 'HEAD') == source['head']
    assert sha(OUT / 'codec-workspace-contract.json') == source['contract_sha256']
    assert sha(OUT / 'run_guarded.py') == source['guard_sha256']
    assert all(sha(OUT / name) == digest for name, digest in source['helpers'].items())
    return source
