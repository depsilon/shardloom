"""Archive exact documentation source, check logs and observed browser evidence."""
import hashlib
import io
import json
import tarfile
from pathlib import Path

import codec_common as c


def main():
    source = c.read(c.OUT / 'accepted-source-1.json')
    assert c.source_hashes() == source['source_hashes']
    assert c.git('rev-parse', 'HEAD') == 'ab96cd7e5d0698d90c33ea2835896a68cb5f3543'
    checks = c.read(c.OUT / 'codec-documentation-checks-2/summary.json')
    assert checks['status'] == 'passed' and len(checks['checks']) == 7
    for row in checks['checks']:
        assert row['returncode'] == 0 and c.sha(row['log']) == row['log_sha256']
    for name in ('codec-documentation-checks-2', 'codec-documentation-preview-1'):
        receipt = c.read(c.OUT / f'{name}.json')
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert c.sha(c.OUT / f'{name}.log') == receipt['log_sha256']
    previous = c.read(c.OUT / 'codec-documentation-checks-1.json')
    assert previous['status'] == 'failed' and previous['process_group_drained']
    assert c.sha(c.OUT / 'codec-documentation-checks-1.log') == previous['log_sha256']
    assert (c.OUT / 'codec-documentation-preview-stop-1').is_file()
    browser = {
        'status': 'passed_manual_browser_review',
        'pages': ['field-guide/runtime-and-io/', 'field-guide/limitations/'],
        'desktop': {'capture': 'codec-docs-desktop-1.png', 'width': 1280,
                    'height': 720, 'theme': 'dark', 'resource_text_readable': True},
        'mobile': {'width': 390, 'height': 844,
                   'runtime_body_width': 390, 'limitations_body_width': 390,
                   'runtime_light_and_dark_captures': True,
                   'table_client_width': 358, 'table_scroll_width': 474,
                   'table_overflow_x': 'auto', 'table_parent_scroll_width': 358},
        'search': {'query': 'workspaces', 'result_count': 2,
                   'result_targets': ['field-guide/runtime-and-io/#resources-and-recovery',
                                      'field-guide/limitations/#runtime-limits'],
                   'limitations_result_clicked_and_verified': True,
                   'capture': 'codec-docs-search-1.png'},
        'warning_and_error_logs': [],
        'temporary_tab_closed_and_viewport_reset': True,
        'scope': 'Recorded primary browser observations and captured pixels; not an automated browser test.'}
    paths = {}
    for prefix in ('codec-documentation-', 'codec-docs-'):
        for path in sorted(c.OUT.glob(prefix + '*')):
            for item in sorted(path.rglob('*')) if path.is_dir() else [path]:
                if item.is_file():
                    paths['proof/' + str(item.relative_to(c.OUT))] = item
    for name in ('verify_codec_documentation.py', 'verify_codec_documentation_2.py',
                 'preview_codec_documentation.py', 'codec_common.py', 'run_guarded.py',
                 Path(__file__).name):
        paths['drivers/' + name] = c.OUT / name
    names = c.git('diff', '--name-only', 'HEAD').splitlines()
    names += c.git('ls-files', '--others', '--exclude-standard').splitlines()
    for name in sorted(set(names)):
        path = c.ROOT / name
        if path.is_file() and not name.startswith('docs/benchmarks/evidence/'):
            assert name.startswith(('docs/', 'website-src/', 'website/')), name
            paths['source/' + name] = path
    assert sum(path.stat().st_size for path in paths.values()) < 32 * 1024 * 1024
    manifest = {name: {'bytes': path.stat().st_size, 'sha256': c.sha(path)}
                for name, path in sorted(paths.items())}
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    browser_bytes = (json.dumps(browser, indent=2, sort_keys=True) + '\n').encode()
    target = c.ROOT / 'docs/benchmarks/evidence/native-codec-documentation-2026-10-07.tar.xz'
    with tarfile.open(target, 'x:xz', preset=6) as archive:
        for name, path in sorted(paths.items()):
            info = tarfile.TarInfo(name)
            info.size = path.stat().st_size
            info.mode = 0o644
            with path.open('rb') as stream:
                archive.addfile(info, stream)
        for name, raw in (('manifest.json', manifest_bytes), ('browser.json', browser_bytes)):
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(raw))
    with tarfile.open(target, 'r:xz') as archive:
        members = archive.getmembers()
        assert len(members) == len(manifest) + 2
        assert {x.name for x in members} == set(manifest) | {'manifest.json', 'browser.json'}
        assert archive.extractfile('manifest.json').read() == manifest_bytes
        assert archive.extractfile('browser.json').read() == browser_bytes
        for name, expected in manifest.items():
            with archive.extractfile(name) as stream:
                assert hashlib.file_digest(stream, 'sha256').hexdigest() == expected['sha256']
            assert archive.getmember(name).size == expected['bytes']
    assert c.source_hashes() == source['source_hashes']
    report = {
        'schema_version': 'shardloom.native_codec_documentation_acceptance.v1',
        'status': 'passed_local_documentation_acceptance',
        'runtime_commit': c.git('rev-parse', 'HEAD'),
        'source_identity_sha256': source['source_identity_sha256'],
        'runtime_source_assets_verified': len(source['source_hashes']),
        'documentation_checks': checks['checks'], 'browser': browser,
        'examples_changed': False, 'runtime_rerun_required': False,
        'archive': {'path': str(target.relative_to(c.ROOT)),
                    'bytes': target.stat().st_size, 'sha256': c.sha(target),
                    'file_members': len(manifest), 'total_members': len(manifest) + 2,
                    'manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
                    'all_members_reopened_and_hash_checked': True},
        'source_files': {name.removeprefix('source/'): item for name, item in manifest.items()
                         if name.startswith('source/')},
        'preserved_failed_attempt': checks['prior_failed_attempt'],
        'temporary_server_drained': True,
        'hosted_integration': 'pending',
        'claim_boundary': 'Documentation acceptance for the exact recorded pages and source. No new engine, performance, RSS or package claim.',
        'driver_sha256': c.sha(__file__)}
    portable = json.dumps(report, indent=2, allow_nan=False)
    for path, replacement in ((c.ROOT, '<repo>'), (c.OUT, '<codec-uat>'), (Path.home(), '<home>')):
        portable = portable.replace(str(path), replacement)
    result_path = target.with_name('native-codec-documentation-2026-10-07.json')
    with result_path.open('x') as stream:
        stream.write(portable + '\n')
    print(json.dumps({'status': 'passed', 'members': len(manifest) + 2,
                      'bytes': target.stat().st_size, 'sha256': c.sha(target)}), flush=True)


if __name__ == '__main__':
    main()
