"""Validate the finite codec documentation without repeating accepted engine runs."""
import json
from pathlib import Path
import subprocess
import time

import codec_common as c


def main():
    source = c.read(c.OUT / 'accepted-source-1.json')
    assert c.source_hashes() == source['source_hashes']
    build = c.read(c.OUT / 'codec-build-1.json')
    assert c.sha(build['binary']) == build['binary_sha256']
    out = c.OUT / 'codec-documentation-checks-1'
    out.mkdir(exist_ok=False)
    checks = []
    commands = [
        ('user-surface-index', [c.PYTHON, '-B', 'scripts/check_user_surface_reference.py'], c.ROOT),
        ('public-status', [c.PYTHON, '-B', 'scripts/check_public_status_docs.py', '--output', str(out / 'public-status.json')], c.ROOT),
        ('use-case-backlinks', [c.PYTHON, '-B', 'scripts/check_use_case_backlinks.py'], c.ROOT),
        ('website-check', ['npm', 'run', 'check'], c.ROOT / 'website-src'),
        ('website-build', ['npm', 'run', 'build'], c.ROOT / 'website-src'),
        ('website-readiness', [c.PYTHON, '-B', 'scripts/check_website_readiness.py', '--output', str(out / 'website-readiness.json')], c.ROOT),
        ('diff-whitespace', ['git', 'diff', '--check'], c.ROOT),
    ]
    for name, command, cwd in commands:
        path = out / f'{name}.log'
        start = time.monotonic()
        with path.open('xb') as stream:
            result = subprocess.run(command, cwd=cwd, stdout=stream,
                                    stderr=subprocess.STDOUT, timeout=300, check=False)
        item = {'name': name, 'command': command, 'cwd': str(cwd),
                'returncode': result.returncode, 'seconds': time.monotonic() - start,
                'log': str(path), 'log_sha256': c.sha(path)}
        checks.append(item)
        print(json.dumps(item), flush=True)
        c.write(out / f'{name}.json', item)
        assert result.returncode == 0, name
        assert c.source_hashes() == source['source_hashes']
    result = {'status': 'passed', 'checks': checks,
              'source_identity_sha256': source['source_identity_sha256'],
              'runtime_source_assets_verified': len(source['source_hashes']),
              'binary_sha256': build['binary_sha256'], 'driver_sha256': c.sha(__file__),
              'examples_changed': False, 'new_runtime_execution_required': False,
              'browser_visual_qa': 'pending', 'hosted_integration': 'pending'}
    c.write(out / 'summary.json', result)
    print(json.dumps({'status': 'passed', 'checks': len(checks)}), flush=True)


if __name__ == '__main__':
    main()
