"""Serial required regression against the frozen streaming destination sources."""
import json
from pathlib import Path
import re
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sources, sha, save

FROZEN = OUT / 'stream-destinations-source-475.json'
CHECKS = [
    ('fmt', 180, ['cargo', 'fmt', '--all', '--', '--check']),
    ('workspace-clippy', 1800, ['cargo', 'clippy', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('workspace-tests', 1800, ['cargo', 'test', '--workspace', '--all-targets', '--', '--test-threads=2']),
    ('read-clippy', 1800, ['cargo', 'clippy', '--offline', '--locked', '-p', 'shardloom-vortex', '-p', 'shardloom-cli', '--all-targets', '--features', 'vortex-local-primitives', '--', '-D', 'warnings']),
    ('release-clippy', 1800, ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--features', 'shardloom-cli/release-user-surfaces,shardloom-python/python-native', '--', '-D', 'warnings']),
    ('native-tests', 3600, ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-vortex', '-p', 'shardloom-cli', '--all-targets', '--features', 'vortex-local-primitives,vortex-write,universal-format-io', '--', '--test-threads=2']),
]


def main():
    frozen = json.loads(FROZEN.read_text())
    assert sources() == frozen['source_sha256']
    protocol = dict(source_manifest=str(FROZEN), source_manifest_sha256=sha(FROZEN),
                    helper_sha256=sha(__file__), guard_sha256=sha(OUT / 'run_guarded.py'), checks=CHECKS,
                    unchanged_vendor_tests='No vendor source is modified in this unit; prior selected-view acceptance remains recorded separately.')
    save(OUT / 'stream-destination-check-protocol-475.json', protocol)
    records, failure = [], None
    try:
        for label, timeout, command in CHECKS:
            assert sources() == frozen['source_sha256']
            name = 'stream-destination-' + label + '-475'
            print(json.dumps(dict(stage=label, status='starting')), flush=True)
            subprocess.run([sys.executable, '-B', str(OUT / 'run_guarded.py'), '--name', name,
                            '--timeout', str(timeout), '--', *command], cwd=ROOT, check=True)
            path = OUT / (name + '.json')
            receipt, log = json.loads(path.read_text()), path.with_suffix('.log')
            assert receipt['status'] == 'passed' and receipt['returncode'] == 0
            assert receipt['process_group_drained'] and receipt['direct_child_reaped']
            assert not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup']
            assert receipt['head'] == frozen['head'] and sha(log) == receipt['log_sha256']
            record = dict(stage=label, receipt=str(path), receipt_sha256=sha(path),
                          log=str(log), log_sha256=sha(log), seconds=receipt['seconds'])
            if label.endswith('tests'):
                raw = log.read_text()
                groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', raw)
                assert groups and all(int(row[1]) == int(row[3]) == int(row[4]) == 0 for row in groups)
                ignored = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', raw, re.M)
                assert sum(int(row[2]) for row in groups) == len(ignored)
                if label == 'native-tests':
                    inventory = json.loads((OUT / 'compression-manual-tests-inventory-456.json').read_text())
                    assert sorted(ignored) == sorted((row['test'], row['reason']) for row in inventory['tests'])
                    assert all(sha(ROOT / row['source']) == row['source_sha256'] for row in inventory['tests'])
                    for required in (
                        'completion_input_all_writers_preserve_values_and_require_source_end',
                        'completion_input_fanout_executes_once_for_all_writers_and_typed_empty_output',
                        'completion_input_fanout_failures_leave_no_published_prefix_or_owners',
                        'completion_input_fanout_target_admission_and_cancellation_precede_demand',
                        'completion_input_fanout_pressure_denies_resident_and_replays_native_runs_under_same_grant',
                        'completion_input_fanout_spill_faults_do_not_publish_and_preserve_unknown_files',
                    ):
                        assert re.search(r'^test .*::' + required + r' \.\.\. ok$', raw, re.M), required
                else:
                    assert not ignored
                record['tests'] = dict(passed=sum(int(row[0]) for row in groups), failed=0,
                                       ignored=len(ignored), groups=len(groups), ignored_declarations=ignored)
            records.append(record)
            print(json.dumps(dict(stage=label, status='passed', tests=record.get('tests'))), flush=True)
        assert sources() == frozen['source_sha256']
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        save(OUT / 'stream-destination-checks-475.json', dict(status='passed' if failure is None else 'failed',
             failure=failure, protocol=protocol, source_files=len(frozen['source_sha256']),
             source_identity_preserved=sources() == frozen['source_sha256'], completed=records))


if __name__ == '__main__':
    main()
