//! Text encoding is a terminal consumer of complete typed native batches.
//! No full row table, JSON query report, disk spool or query replay is required.

use super::{
    Result, ShardLoomError, StatValue, VortexLocalPrimitiveExecutionPolicy,
    VortexLocalPrimitiveExecutionStatus, VortexLocalPrimitivePhysicalPolicyReport,
    VortexLocalPrimitiveRowExportFormat as Format, VortexLocalPrimitiveRowExportReport,
    VortexLocalPrimitiveStateBudgetReport, VortexNativeArraySinkEvidence,
    VortexQueryPrimitiveRequest, disabled_row_export_evidence, logical_field_from_native_array,
    native_sink::{ArrayProducer, NativeSinkPlan, OwnedOutput},
    usize_to_u64, vortex_error, vortex_scalar_to_stat_value,
};
use shardloom_exec::compute_pool::CancellationToken;
use std::{
    io::{BufWriter, Write},
    path::Path,
};
use vortex::array::VortexSessionExecute as _;

const BATCH_ROWS: usize = 2048;
const BATCH_BYTES: u64 = 8 * 1024 * 1024;

fn failed(reason: &str) -> ShardLoomError {
    ShardLoomError::InvalidOperation(format!(
        "native text sink: {reason}; no fallback execution was attempted"
    ))
}

pub(super) fn validate_schema(dtype: &vortex::array::dtype::DType) -> Result<()> {
    if let Some(fields) = dtype.as_struct_fields_opt() {
        for dtype in fields.fields() {
            if super::native_payload::is_nested(&dtype) {
                super::native_payload::metadata_bytes(&dtype)?;
            }
        }
    }
    Ok(())
}

#[allow(clippy::too_many_arguments, clippy::too_many_lines)]
pub(super) fn write(
    plan: NativeSinkPlan,
    request: &VortexQueryPrimitiveRequest,
    path: &Path,
    format: Format,
    overwrite: bool,
    policy: VortexLocalPrimitiveExecutionPolicy,
    producer: Option<&mut ArrayProducer<'_>>,
    cancellation: &CancellationToken,
    admitted: Option<&crate::resident_session::NativeExecutionContext<'_>>,
) -> Result<VortexLocalPrimitiveRowExportReport> {
    if !matches!(format, Format::Json | Format::Jsonl | Format::Csv) {
        return Err(failed("requires JSON, JSONL or CSV output"));
    }
    cancellation.check()?;
    validate_schema(&plan.dtype)?;
    plan.validate_destination(path)?;
    let mut scratch = plan.session.memory().reserve(128 * 1024)?;
    let mut output = OwnedOutput::new(path, overwrite)?;
    let mut rows = 0_u64;
    let mut batches = 0_usize;
    let mut maximum_rows = 0_usize;
    let mut logical_bytes = 0_u64;
    let mut text_copies = 0_u64;
    let mut scalars_materialized = 0_u64;
    let mut matched_rows_observed = 0_u64;
    let mut stopped_at_limit = false;
    plan.source
        .with_native_execution_or_admitted(cancellation, admitted, |file, context| {
            let mut scalar_context = context.native_session().create_execution_ctx();
            let mut writer = BufWriter::with_capacity(64 * 1024, &mut output.file);
            match format {
                Format::Json => writer.write_all(b"["),
                Format::Csv => {
                    for (index, name) in plan.columns.iter().enumerate() {
                        if index > 0 {
                            writer.write_all(b",").map_err(vortex_error)?;
                        }
                        csv_text(&mut writer, name)?;
                    }
                    writer.write_all(b"\n")
                }
                _ => Ok(()),
            }
            .map_err(vortex_error)?;
            if plan.source.is_produced() || (!plan.metadata_pruned && plan.row_count > 0) {
                plan.consume(file, context, BATCH_ROWS, producer, |array| {
                    context.check_cancelled()?;
                    if array.dtype() != &plan.dtype
                        || array.len() > BATCH_ROWS
                        || array.nbytes() > BATCH_BYTES
                    {
                        return Err(failed("result batch changed its admitted schema or size"));
                    }
                    matched_rows_observed = matched_rows_observed
                        .checked_add(usize_to_u64(array.len())?)
                        .ok_or_else(|| failed("text observed row count overflow"))?;
                    let remaining = plan.limit.map_or(usize::MAX, |limit| {
                        usize::try_from(limit.saturating_sub(rows)).unwrap_or(usize::MAX)
                    });
                    let array = if array.len() > remaining {
                        array.slice(0..remaining).map_err(vortex_error)?
                    } else {
                        array
                    };
                    let bytes = array
                        .nbytes()
                        .checked_mul(2)
                        .and_then(|n| n.checked_add(128 * 1024))
                        .ok_or_else(|| failed("text scratch reservation overflow"))?;
                    if bytes > scratch.bytes() {
                        scratch.resize(bytes)?;
                    }
                    let columns = plan
                        .columns
                        .iter()
                        .map(|name| logical_field_from_native_array(&array, name))
                        .collect::<Result<Vec<_>>>()?;
                    let json = columns
                        .iter()
                        .map(|column| {
                            if format != Format::Csv
                                || super::native_payload::is_nested(column.dtype())
                            {
                                super::native_json::Column::new(
                                    column,
                                    &mut scalar_context,
                                    context.memory(),
                                )
                                .map(Some)
                            } else {
                                Ok(None)
                            }
                        })
                        .collect::<Result<Vec<_>>>()?;
                    batches += 1;
                    maximum_rows = maximum_rows.max(array.len());
                    logical_bytes = logical_bytes
                        .checked_add(array.nbytes())
                        .ok_or_else(|| failed("logical byte counter overflow"))?;
                    for row in 0..array.len() {
                        context.check_cancelled()?;
                        if format == Format::Json && rows > 0 {
                            writer.write_all(b",").map_err(vortex_error)?;
                        }
                        if format != Format::Csv {
                            writer.write_all(b"{").map_err(vortex_error)?;
                        }
                        for (index, (name, column)) in plan.columns.iter().zip(&columns).enumerate()
                        {
                            if index > 0 {
                                writer.write_all(b",").map_err(vortex_error)?;
                            }
                            if let Some(json) = &json[index] {
                                let counts = if format == Format::Csv {
                                    if column
                                        .is_valid(row, &mut scalar_context)
                                        .map_err(vortex_error)?
                                    {
                                        writer.write_all(b"\"").map_err(vortex_error)?;
                                        let counts = json.write(
                                            row,
                                            &mut CsvQuotedWriter(&mut writer),
                                            &mut scalar_context,
                                            cancellation,
                                        )?;
                                        writer.write_all(b"\"").map_err(vortex_error)?;
                                        counts
                                    } else {
                                        if plan.columns.len() == 1 {
                                            csv_text(&mut writer, "")?;
                                        }
                                        super::native_json::WriteCounts {
                                            scalars: 1,
                                            utf8_bytes: 0,
                                        }
                                    }
                                } else {
                                    serde_json::to_writer(&mut writer, name)
                                        .map_err(vortex_error)?;
                                    writer.write_all(b":").map_err(vortex_error)?;
                                    json.write(row, &mut writer, &mut scalar_context, cancellation)?
                                };
                                scalars_materialized = scalars_materialized
                                    .checked_add(counts.scalars)
                                    .ok_or_else(|| failed("scalar counter overflow"))?;
                                text_copies = text_copies
                                    .checked_add(counts.utf8_bytes)
                                    .ok_or_else(|| failed("text copy counter overflow"))?;
                                continue;
                            }
                            let scalar =
                                super::result_batch::scalar(column, row, &mut scalar_context)?;
                            let value = terminal_scalar(&scalar)?;
                            scalars_materialized = scalars_materialized
                                .checked_add(1)
                                .ok_or_else(|| failed("scalar counter overflow"))?;
                            if let StatValue::Utf8(text) = &value {
                                text_copies = text_copies
                                    .checked_add(usize_to_u64(text.len())?)
                                    .ok_or_else(|| failed("text copy counter overflow"))?;
                            }
                            if format == Format::Csv
                                && plan.columns.len() == 1
                                && value == StatValue::Null
                            {
                                // A bare newline is skipped as a blank record by CSV
                                // readers. A quoted empty cell keeps this null row.
                                csv_text(&mut writer, "")?;
                            } else {
                                write_value(&mut writer, value, format)?;
                            }
                        }
                        writer
                            .write_all(if format == Format::Csv { b"\n" } else { b"}\n" })
                            .map_err(vortex_error)?;
                        rows = rows
                            .checked_add(1)
                            .ok_or_else(|| failed("row counter overflow"))?;
                    }
                    if plan.limit == Some(rows) {
                        stopped_at_limit = true;
                        return Ok(false);
                    }
                    Ok(true)
                })?;
            }
            if format == Format::Json {
                writer.write_all(b"]\n").map_err(vortex_error)?;
            }
            writer.flush().map_err(vortex_error)?;
            context.check_cancelled()
        })?;
    output.file.sync_all().map_err(vortex_error)?;
    let checksum = output.checksum()?;
    cancellation.check()?;
    plan.source.validate_generation()?;
    output.commit()?;
    let pre_limit_result_row_count = if plan.source.is_produced() {
        rows
    } else if plan.metadata_pruned {
        0
    } else if plan.filter.is_none() {
        plan.row_count
    } else {
        matched_rows_observed
    };
    let mut evidence = disabled_row_export_evidence();
    evidence.pushdown = super::VortexLocalPrimitiveRowExportPushdownEvidence {
        filter_pushdown_applied: plan.filter.is_some(),
        projection_pushdown_applied: plan.projection.is_some(),
        source_order_limit_applied: plan.limit.is_some(),
    };
    // Empty filtered scan output does not prove that the provider read or
    // decoded nothing. These flags conservatively describe the scan boundary.
    evidence.upstream_scan_called =
        plan.source.is_source() && !plan.metadata_pruned && plan.row_count > 0;
    evidence.side_effects.data_read = evidence.upstream_scan_called;
    evidence.side_effects.data_decoded = evidence.upstream_scan_called;
    evidence.side_effects.row_read = evidence.upstream_scan_called && scalars_materialized > 0;
    evidence.side_effects.write_io = true;
    evidence.side_effects.data_materialized = rows > 0;
    evidence.materialization_boundary_reported = true;
    evidence.native_array_sink = Some(VortexNativeArraySinkEvidence {
        native_arrays_submitted: usize_to_u64(batches)?,
        native_array_logical_bytes: logical_bytes,
        adapter_payload_bytes_copied: text_copies,
        scalar_values_materialized: scalars_materialized,
        scan_row_bound: BATCH_ROWS,
        writer_input_batch_bound: 1,
        peak_reserved_bytes: plan.session.snapshot().memory.peak_reserved_bytes,
        metadata_reserved_bytes: 128 * 1024,
        pre_limit_result_row_count,
        pre_limit_result_row_count_exact: plan.filter.is_none() || !stopped_at_limit,
        source_generation_validated: true,
        dtype_and_row_count_validated: false,
        output_sha256: checksum,
        compatibility: None,
        metadata_fidelity: if format == Format::Csv {
            "terminal_CSV_encoding;header_and_row_order_preserved;nulls_emit_empty_cells;nested_values_stream_as_quoted_JSON_text_cells;binary_hex_and_decimal128_tagged_JSON_scalars_escaped_as_CSV_cells;Date32_days_and_TimestampMicros_integers;dtype_validity_encodings_layout_statistics_not_persisted;native_input_schema_checked;no_persisted_dtype_claim"
        } else {
            "terminal_JSON_encoding;field_names_nulls_values_and_row_order_preserved;binary_hex_and_decimal128_tagged_strings;Date32_days_and_TimestampMicros_integers;logical_dtypes_native_encodings_layout_statistics_not_persisted;native_input_schema_checked;no_persisted_dtype_claim"
        },
    });
    Ok(VortexLocalPrimitiveRowExportReport {
        status: VortexLocalPrimitiveExecutionStatus::Executed,
        primitive_kind: request.kind,
        output_path: path.display().to_string(),
        output_format: format.as_str(),
        rows_scanned: plan.row_count,
        rows_written: rows,
        pre_limit_result_row_count,
        projected_columns: plan.columns,
        arrays_read_count: batches,
        max_chunk_rows: maximum_rows,
        resource_envelope: policy.resource_envelope(),
        physical_policy: VortexLocalPrimitivePhysicalPolicyReport::not_selected(),
        max_parallelism_requested: policy.max_parallelism,
        scan_concurrency_per_worker: 1,
        source_order_limit_requested: plan.limit,
        state_budget: VortexLocalPrimitiveStateBudgetReport::not_required(),
        evidence,
        diagnostics: Vec::new(),
    })
}

fn terminal_scalar(scalar: &vortex::array::scalar::Scalar) -> Result<StatValue> {
    let scalar = match scalar.value() {
        Some(vortex::array::scalar::ScalarValue::Variant(value)) => value.as_ref(),
        _ => scalar,
    };
    if scalar.is_null() {
        Ok(StatValue::Null)
    } else if matches!(
        scalar.value(),
        Some(
            vortex::array::scalar::ScalarValue::Binary(_)
                | vortex::array::scalar::ScalarValue::Decimal(_)
        )
    ) {
        // Match the established typed CSV cell contract: the JSON scalar is
        // escaped as a CSV cell. Binary empty text remains distinct from null.
        let mut bytes = Vec::new();
        super::collect::write_scalar_json(&mut bytes, scalar)?;
        String::from_utf8(bytes)
            .map(StatValue::Utf8)
            .map_err(vortex_error)
    } else {
        vortex_scalar_to_stat_value(scalar)
            .ok_or_else(|| failed("text output requires a flat scalar value"))
    }
}

fn write_value(writer: &mut impl Write, value: StatValue, format: Format) -> Result<()> {
    if let StatValue::Float64(value) = &value
        && !value.is_finite()
    {
        return Err(failed("nonfinite text numbers are not admitted"));
    }
    if format != Format::Csv {
        return match value {
            StatValue::Null => writer.write_all(b"null").map_err(vortex_error),
            StatValue::Boolean(value) => {
                serde_json::to_writer(writer, &value).map_err(vortex_error)
            }
            StatValue::Int64(value) => serde_json::to_writer(writer, &value).map_err(vortex_error),
            StatValue::UInt64(value) => serde_json::to_writer(writer, &value).map_err(vortex_error),
            StatValue::Float64(value) => {
                serde_json::to_writer(writer, &value).map_err(vortex_error)
            }
            StatValue::Utf8(value) => serde_json::to_writer(writer, &value).map_err(vortex_error),
        };
    }
    match value {
        StatValue::Null => Ok(()),
        StatValue::Boolean(value) => write!(writer, "{value}").map_err(vortex_error),
        StatValue::Int64(value) => write!(writer, "{value}").map_err(vortex_error),
        StatValue::UInt64(value) => write!(writer, "{value}").map_err(vortex_error),
        StatValue::Float64(value) => write!(writer, "{value}").map_err(vortex_error),
        StatValue::Utf8(value) => csv_text(writer, &value),
    }
}

fn csv_text(writer: &mut impl Write, text: &str) -> Result<()> {
    if !text.is_empty() && !text.contains([',', '"', '\r', '\n']) {
        return writer.write_all(text.as_bytes()).map_err(vortex_error);
    }
    writer.write_all(b"\"").map_err(vortex_error)?;
    for (index, part) in text.split('"').enumerate() {
        if index > 0 {
            writer.write_all(b"\"\"").map_err(vortex_error)?;
        }
        writer.write_all(part.as_bytes()).map_err(vortex_error)?;
    }
    writer.write_all(b"\"").map_err(vortex_error)
}

/// Stream JSON directly inside a quoted CSV cell. Doubling quote bytes does not
/// allocate a cell-sized string or change the JSON traversal's ownership.
struct CsvQuotedWriter<'a, W>(&'a mut W);

impl<W: Write> Write for CsvQuotedWriter<'_, W> {
    fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
        let mut start = 0;
        for (index, byte) in bytes.iter().enumerate() {
            if *byte == b'"' {
                self.0.write_all(&bytes[start..=index])?;
                self.0.write_all(b"\"")?;
                start = index + 1;
            }
        }
        self.0.write_all(&bytes[start..])?;
        Ok(bytes.len())
    }

    fn flush(&mut self) -> std::io::Result<()> {
        self.0.flush()
    }
}
