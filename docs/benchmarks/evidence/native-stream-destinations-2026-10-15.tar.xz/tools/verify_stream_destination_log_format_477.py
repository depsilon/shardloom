"""Prove the evidence-only formatting correction against every retained JSON file."""
import ast
import io
import json
from pathlib import Path
import sys

from freeze_native_release_298 import ROOT, OUT, save, sha, sources

HARNESS = 'scripts/run_native_streaming_input_uat.py'
OLD_SOURCE = OUT / 'native-release-source-stream476.json'
FAILED = OUT / 'stream-destination-public-476'
RESULT = OUT / 'stream-destination-log-format-correction-477.json'


def bound(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def main():
    old = json.loads(OLD_SOURCE.read_text())['source_sha256']
    current = sources()
    assert current.keys() == old.keys()
    changed = [name for name in current if current[name] != old[name]]
    assert changed == [HARNESS]
    original = FAILED / 'logs/run_native_streaming_input_uat.py'
    assert sha(original) == old[HARNESS]
    expected = ast.parse(original.read_text())
    edits = 0
    for node in ast.walk(expected):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if isinstance(node.func.value, ast.Name) and node.func.value.id == 'json' and node.func.attr == 'dump':
                assert len([kw for kw in node.keywords if kw.arg == 'indent']) == 1
                for index, keyword in enumerate(node.keywords):
                    if keyword.arg == 'indent':
                        assert isinstance(keyword.value, ast.Constant) and keyword.value.value == 2
                        node.keywords[index] = ast.keyword(arg='separators',
                            value=ast.Tuple(elts=[ast.Constant(value=','), ast.Constant(value=':')], ctx=ast.Load()))
                        edits += 1
    assert edits == 1
    assert ast.dump(expected) == ast.dump(ast.parse((ROOT / HARNESS).read_text()))
    sys.path.insert(0, str(ROOT / 'python/src'))
    sys.path.insert(0, str(ROOT / 'scripts'))
    from run_native_streaming_input_uat import Harness

    class Sink:
        def __init__(self):
            self.stream = io.StringIO()
            self.result = None
        def open(self, mode):
            assert mode == 'x'
            return self
        def __enter__(self):
            return self.stream
        def __exit__(self, *unused):
            self.result = self.stream.getvalue()
            self.stream.close()

    members, original_bytes, compact_bytes = [], 0, 0
    for path in sorted((FAILED / 'logs').glob('*.json')):
        raw = path.read_bytes()
        payload = json.loads(raw)
        sink = Sink()
        Harness.json(None, sink, payload)
        encoded = sink.result.encode('utf-8')
        assert json.loads(encoded) == payload
        assert encoded.endswith(b'\n')
        original_bytes += len(raw)
        compact_bytes += len(encoded)
        members.append(dict(**bound(path), compact_bytes=len(encoded)))
    summary = json.loads((FAILED / 'summary.json').read_text())
    assert summary['status'] == 'failed' and len(summary['cases']) == 765
    assert all(case['status'] == 'passed' for case in summary['cases'])
    receipt = json.loads((OUT / 'stream-destination-public-476.json').read_text())
    assert receipt['status'] == 'failed' and receipt['returncode'] == 1
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert receipt['log_sha256'] == sha(OUT / 'stream-destination-public-476.log')
    log = (OUT / 'stream-destination-public-476.log').read_text()
    assert 'UAT retained log budget exceeded: 202231808 existing + 0 reserved > 201326592 bytes' in log
    assert not RESULT.exists()
    result = dict(status='passed', changed_source_files=changed, original_source=bound(OLD_SOURCE),
        original_harness=bound(original), corrected_harness=bound(ROOT / HARNESS),
        ast_change='Only json.dump indentation is replaced with compact separators; comments are non-executable.',
        complete_json_roundtrips=len(members), original_json_bytes=original_bytes,
        compact_json_bytes=compact_bytes, saved_json_bytes=original_bytes-compact_bytes,
        files=members, runtime_and_package_sources_unchanged=True, binaries_rebuilt=False,
        guard_limits_unchanged=True, failed_summary=bound(FAILED / 'summary.json'),
        failed_receipt=bound(OUT / 'stream-destination-public-476.json'), helper=bound(__file__))
    save(RESULT, result)
    print(json.dumps({key:value for key,value in result.items() if key != 'files'}))


if __name__ == '__main__':
    main()
