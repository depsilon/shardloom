"""Freeze final binaries and verify direct and subprocess destination workflows."""
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

from freeze_native_release_298 import ROOT, OUT, sha, sources, save
from run_query_timing_runtime_461 import guarded, PYTHON_DEPS

SOURCE = OUT / 'native-release-source-stream476.json'
CHECKS = OUT / 'stream-destination-checks-476b.json'
MANIFEST = OUT / 'stream-destination-native-artifacts-476.json'
PYTHON = OUT / 'selected-view-python-468/bin/python'
DIRECT = OUT / 'stream-destination-direct-tests-476.json'
PUBLIC = OUT / 'stream-destination-public-476'
PRIOR = OUT / 'selected-view-public-468/summary.json'
FOCUSED = OUT / 'stream-destination-public-focused-474b/summary.json'


def bound(path):
    path = Path(path)
    return dict(path=str(path), sha256=sha(path), bytes=path.stat().st_size)


def load():
    manifest = json.loads(MANIFEST.read_text())
    assert sources() == manifest['source_sha256']
    assert sha(SOURCE) == manifest['source_manifest']['sha256']
    for kind in ('cli', 'binding'):
        assert sha(manifest[kind]['path']) == manifest[kind]['sha256']
    assert sha(CHECKS) == manifest['checks']['sha256']
    assert json.loads(CHECKS.read_text())['status'] == 'passed'
    return manifest


def direct():
    sys.path.insert(0, str(PYTHON_DEPS))
    sys.path.insert(0, str(ROOT / 'python/src'))
    import pyarrow
    import shardloom
    manifest = load()
    assert Path(sys.executable) == PYTHON
    assert Path(shardloom.__file__).resolve() == ROOT / 'python/src/shardloom/__init__.py'
    os.environ['SHARDLOOM_NATIVE_TEST_LIBRARY'] = manifest['binding']['path']
    os.environ['SHARDLOOM_REQUIRE_NATIVE_PYTHON'] = '1'
    os.environ['SHARDLOOM_BIN'] = manifest['cli']['path']
    suite = unittest.defaultTestLoader.discover(str(ROOT / 'python/tests'), pattern='test_native*binding.py')

    def identifiers(test):
        if isinstance(test, unittest.TestSuite):
            return [name for child in test for name in identifiers(child)]
        return [test.id()]

    names = identifiers(suite)
    prior = json.loads((OUT / 'selected-view-direct-tests-468.json').read_text())['test_names']
    assert len(prior) == 80 and set(prior).issubset(names)
    assert len(names) == len(set(names)) == 84
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    passed = result.wasSuccessful() and result.testsRun == len(names) and not result.skipped
    save(DIRECT, dict(status='passed' if passed else 'failed', tests=result.testsRun,
        failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
        test_names=names, prior_tests_preserved=prior, manifest_sha256=sha(MANIFEST),
        interpreter=sys.executable, python_version=sys.version,
        pyarrow_version=pyarrow.__version__, pyarrow_file=pyarrow.__file__,
        package_source=shardloom.__file__, helper_sha256=sha(__file__),
        mode='direct_source_package_with_explicit_frozen_native_library', installed_wheel_proof=False))
    assert load() == manifest and passed


def main():
    frozen = json.loads(SOURCE.read_text())
    checks = json.loads(CHECKS.read_text())
    assert checks['status'] == 'passed' and checks['source_identity_preserved']
    assert len(checks['completed']) == 6
    assert checks['protocol']['source_manifest_sha256'] == sha(SOURCE)
    assert sources() == frozen['source_sha256']
    assert not MANIFEST.exists() and not DIRECT.exists() and not PUBLIC.exists()
    baseline = json.loads(PRIOR.read_text())
    focused = json.loads(FOCUSED.read_text())
    added = [case['name'] for case in focused['cases'] if case['name'].startswith('destination-')]
    assert len(added) == 22 and len(baseline['cases']) == 757
    expected = [case['name'] for case in baseline['cases']
                if case['name'] not in ('deny-parquet', 'deny-fanout')]
    expected = [('typed-stream-orc-schema-denied' if name == 'typed-stream-compatibility-denied' else name)
                for name in expected] + added
    assert len(expected) == len(set(expected)) == 777
    families = baseline['families'] + ['destinations']
    assert len(families) == len(set(families)) == 20
    protocol = dict(source=bound(SOURCE), checks=bound(CHECKS), helper=bound(__file__),
        guard=bound(OUT / 'run_guarded.py'), artifact_freezer=bound(OUT / 'freeze_native_release_298.py'),
        reused_guard_helper=bound(OUT / 'run_query_timing_runtime_461.py'),
        prior_public=bound(PRIOR), focused_names=bound(FOCUSED),
        expected_public_names=expected, expected_public_families=families,
        direct_expected_tests=84, installed_wheel_proof=False, publication_attempted=False)
    save(OUT / 'stream-destination-runtime-protocol-476.json', protocol)
    print(json.dumps(dict(stage='release-cli', status='starting')), flush=True)
    guarded('native-final-cli-release-build-stream476', 2100,
        ['cargo', 'build', '--offline', '--locked', '--release', '-p', 'shardloom-cli',
         '--features', 'release-user-surfaces', '--message-format=json-render-diagnostics'])
    assert sources() == frozen['source_sha256']
    print(json.dumps(dict(stage='release-binding', status='starting')), flush=True)
    guarded('native-final-python-release-build-stream476', 2100,
        [sys.executable, '-B', ROOT / 'scripts/build_native_python.py', '--release', '--offline',
         '--output-dir', OUT / 'stream-destination-native-binding-476'])
    subprocess.run([sys.executable, '-B', str(OUT / 'freeze_native_release_298.py'),
                    '--run-id', 'stream476'], cwd=ROOT, check=True)
    artifact_path = OUT / 'native-release-artifacts-stream476.json'
    manifest = json.loads(artifact_path.read_text())
    manifest.update(schema_version='shardloom.stream_destination_native_artifacts.v1',
        source_manifest=bound(SOURCE), checks=bound(CHECKS), original_artifact_manifest=bound(artifact_path))
    save(MANIFEST, manifest)
    assert load() == manifest
    probe = subprocess.run([str(PYTHON), '-I', '-c',
        'import json,pyarrow,shardloom,sys; print(json.dumps(dict(interpreter=sys.executable, '
        'pyarrow=pyarrow.__file__,version=pyarrow.__version__,package=shardloom.__file__, '
        'isolated=sys.flags.isolated)))'], check=True, capture_output=True, text=True, timeout=30)
    observed = json.loads(probe.stdout)
    assert Path(observed['interpreter']) == PYTHON and observed['isolated'] == 1
    assert Path(observed['pyarrow']).is_relative_to(PYTHON_DEPS)
    assert Path(observed['package']) == ROOT / 'python/src/shardloom/__init__.py'
    save(OUT / 'stream-destination-python-environment-476.json', dict(status='passed', observation=observed,
        setup='reused_private_venv_with_existing_dependency_paths', network_used=False,
        installed_wheel_proof=False, helper_sha256=sha(__file__)))
    print(json.dumps(dict(stage='direct-binding', status='starting')), flush=True)
    guarded('stream-destination-direct-476', 1800, [PYTHON, '-B', __file__, 'direct'])
    direct_report = json.loads(DIRECT.read_text())
    assert direct_report['status'] == 'passed' and direct_report['tests'] == 84
    print(json.dumps(dict(stage='public-subprocess', status='starting')), flush=True)
    guarded('stream-destination-public-476', 5400,
        [sys.executable, '-B', ROOT / 'scripts/run_native_streaming_input_uat.py',
         '--binary', manifest['cli']['path'], '--uat-root', PUBLIC, '--operation-timeout', '600'])
    public_path = PUBLIC / 'summary.json'
    public = json.loads(public_path.read_text())
    assert public['status'] == 'passed' and all(case['status'] == 'passed' for case in public['cases'])
    assert [case['name'] for case in public['cases']] == expected
    assert public['families'] == families
    assert load() == manifest
    save(OUT / 'stream-destination-runtime-476.json', dict(status='passed',
        manifest=str(MANIFEST), manifest_sha256=sha(MANIFEST), direct_summary=str(DIRECT),
        direct_summary_sha256=sha(DIRECT), public_summary=str(public_path),
        public_summary_sha256=sha(public_path), public_families=families, public_cases=len(expected),
        source_identity_preserved=True, protocol=bound(OUT / 'stream-destination-runtime-protocol-476.json'),
        environment=bound(OUT / 'stream-destination-python-environment-476.json'),
        helper=bound(__file__), installed_wheel_proof=False, publication_attempted=False))
    print(json.dumps(dict(status='passed', direct_tests=84, public_cases=777, public_families=20)), flush=True)


if __name__ == '__main__':
    direct() if sys.argv[1:] == ['direct'] else main()
