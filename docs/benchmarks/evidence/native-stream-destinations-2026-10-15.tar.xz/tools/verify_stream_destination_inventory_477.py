"""Primary byte, membership and literal-source audit of completed-check inventory."""
import hashlib
import json
from pathlib import Path
import re

OUT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
REPORT = OUT / 'stream-destination-completed-check-inventory-477.json'
RESULT = OUT / 'stream-destination-completed-check-audit-477.json'


def bound(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    inventory = json.loads(REPORT.read_text())
    assert inventory['status'] == 'COMPLETE'
    members = inventory['members']
    associated = inventory['associated_source_and_inventory_files']
    assert len(members) == inventory['member_count'] == 85
    assert len(associated) == inventory['associated_count'] == 7
    rule = inventory['membership_rule']
    pattern = re.compile(r'stream-destination-.*-(?:' + '|'.join(rule['suffix_variants_before_extension']) + r')\.(?:json|log)$')
    actual_names = sorted(path.name for path in OUT.iterdir()
                          if path.is_file() and pattern.fullmatch(path.name)
                          and not any(token in path.name for token in rule['excluded_name_tokens']))
    assert actual_names == inventory['reproducible_sorted_membership_list']
    assert actual_names == [member['name'] for member in members]
    checked_fields = 0
    for member in members + associated:
        path = Path(member['path'])
        assert path.parent == OUT and path.is_file() and not path.is_symlink()
        assert bound(path) == {key: member[key] for key in ('path', 'bytes', 'sha256')}
        if path.suffix == '.json':
            document = json.loads(path.read_text())
            for field in member.get('reported_status_returncode_and_drain_fields', []):
                value = document
                for part in field['json_pointer'].split('/')[1:]:
                    part = part.replace('~1', '/').replace('~0', '~')
                    value = value[int(part)] if isinstance(value, list) else value[part]
                assert value == field['value']
                checked_fields += 1
    excerpts = inventory['failure_and_baseline_literal_excerpts']
    assert len(excerpts) == 127
    known = {member['path'] for member in members + associated}
    for item in excerpts:
        assert item['source_path'] in known
        text = Path(item['source_path']).read_text()
        assert item['excerpt'] in text
        assert text.splitlines()[item['line'] - 1] == item['excerpt']
    assert not inventory['absent_explicitly_named_associated_files']
    assert not RESULT.exists()
    result = dict(status='passed', inventory=bound(REPORT), helper=bound(__file__),
                  checked_identities=len(members) + len(associated), checked_fields=checked_fields,
                  literal_excerpts=len(excerpts), snapshot_membership_equal=True,
                  scope='Evidence inventory verification only; runtime acceptance is separate.')
    RESULT.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
