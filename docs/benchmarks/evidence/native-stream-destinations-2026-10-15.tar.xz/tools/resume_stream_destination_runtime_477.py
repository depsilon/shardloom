"""Reuse proved binaries and direct tests after an evidence-format-only correction."""
import json
from pathlib import Path
import sys

from freeze_native_release_298 import ROOT, OUT, sha, sources, save
from run_query_timing_runtime_461 import guarded

SOURCE = OUT / 'native-release-source-stream477.json'
ORIGINAL = OUT / 'stream-destination-native-artifacts-476.json'
MANIFEST = OUT / 'stream-destination-native-artifacts-477.json'
CORRECTION = OUT / 'stream-destination-log-format-correction-477.json'
PUBLIC = OUT / 'stream-destination-public-477'
PROTOCOL = OUT / 'stream-destination-runtime-protocol-477.json'


def bound(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def load():
    manifest = json.loads(MANIFEST.read_text())
    assert sources() == manifest['source_sha256']
    assert bound(SOURCE) == manifest['source_manifest']
    assert bound(ORIGINAL) == manifest['build_artifact_manifest']
    assert bound(CORRECTION) == manifest['evidence_format_correction']
    for kind in ('cli', 'binding'):
        assert sha(manifest[kind]['path']) == manifest[kind]['sha256']
    return manifest


def main():
    assert not MANIFEST.exists() and not PROTOCOL.exists() and not PUBLIC.exists()
    before = json.loads(ORIGINAL.read_text())
    after = json.loads(SOURCE.read_text())
    assert sources() == after['source_sha256']
    assert before['head'] == after['head'] and before['source_sha256'].keys() == after['source_sha256'].keys()
    changed = [name for name in after['source_sha256'] if after['source_sha256'][name] != before['source_sha256'][name]]
    assert changed == ['scripts/run_native_streaming_input_uat.py']
    correction = json.loads(CORRECTION.read_text())
    assert correction['status'] == 'passed' and correction['changed_source_files'] == changed
    assert correction['runtime_and_package_sources_unchanged'] and correction['guard_limits_unchanged']
    assert correction['corrected_harness'] == bound(ROOT / changed[0])
    assert correction['original_source'] == before['source_manifest']
    checks_path = Path(before['checks']['path'])
    checks = json.loads(checks_path.read_text())
    assert bound(checks_path) == before['checks'] and checks['status'] == 'passed'
    assert checks['source_identity_preserved'] and len(checks['completed']) == 6
    direct_path = OUT / 'stream-destination-direct-tests-476.json'
    direct = json.loads(direct_path.read_text())
    assert direct['status'] == 'passed' and direct['tests'] == 84
    assert direct['failures'] == direct['errors'] == direct['skipped'] == 0
    assert direct['manifest_sha256'] == sha(ORIGINAL)
    for name in ('native-final-cli-release-build-stream476', 'native-final-python-release-build-stream476',
                 'stream-destination-direct-476'):
        receipt = json.loads((OUT / (name + '.json')).read_text())
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert sha(OUT / (name + '.log')) == receipt['log_sha256']
    manifest = dict(before)
    manifest.update(schema_version='shardloom.stream_destination_reused_native_artifacts.v1',
        source_manifest=bound(SOURCE), source_sha256=after['source_sha256'],
        build_artifact_manifest=bound(ORIGINAL), build_source_manifest=before['source_manifest'],
        evidence_format_correction=bound(CORRECTION), binary_rebuild_required=False,
        source_identity_scope='Current source map differs from build source only in UAT JSON whitespace.')
    save(MANIFEST, manifest)
    prior_protocol_path = OUT / 'stream-destination-runtime-protocol-476.json'
    prior_protocol = json.loads(prior_protocol_path.read_text())
    protocol = dict(prior_protocol)
    protocol.update(source=bound(SOURCE), artifact_manifest=bound(MANIFEST),
        original_protocol=bound(prior_protocol_path), correction=bound(CORRECTION), helper=bound(__file__),
        direct_summary=bound(direct_path), direct_artifact_manifest=bound(ORIGINAL),
        builds_and_direct_tests_reused=True,
        failed_public_summary=bound(OUT / 'stream-destination-public-476/summary.json'),
        failed_public_receipt=bound(OUT / 'stream-destination-public-476.json'))
    save(PROTOCOL, protocol)
    assert load() == manifest
    print(json.dumps(dict(stage='public-subprocess', status='starting',
        cases=777, existing_runtime_binaries=True, original_storage_limits=True)), flush=True)
    guarded('stream-destination-public-477', 5400,
        [sys.executable, '-B', ROOT / 'scripts/run_native_streaming_input_uat.py',
         '--binary', manifest['cli']['path'], '--uat-root', PUBLIC, '--operation-timeout', '600'])
    public_path = PUBLIC / 'summary.json'
    public = json.loads(public_path.read_text())
    assert public['status'] == 'passed' and all(case['status'] == 'passed' for case in public['cases'])
    assert [case['name'] for case in public['cases']] == protocol['expected_public_names']
    assert public['families'] == protocol['expected_public_families']
    assert len(public['cases']) == 777 and len(public['families']) == 20
    assert load() == manifest
    save(OUT / 'stream-destination-runtime-477.json', dict(status='passed',
        manifest=str(MANIFEST), manifest_sha256=sha(MANIFEST), direct_summary=str(direct_path),
        direct_summary_sha256=sha(direct_path), direct_artifact_manifest=bound(ORIGINAL),
        public_summary=str(public_path), public_summary_sha256=sha(public_path),
        public_families=public['families'], public_cases=len(public['cases']),
        source_identity_preserved=True, runtime_and_package_sources_unchanged=True,
        protocol=bound(PROTOCOL), environment=bound(OUT / 'stream-destination-python-environment-476.json'),
        helper=bound(__file__), builds_and_direct_tests_reused=True,
        installed_wheel_proof=False, publication_attempted=False))
    print(json.dumps(dict(status='passed', direct_tests=84, public_cases=777, public_families=20)), flush=True)


if __name__ == '__main__':
    main()
