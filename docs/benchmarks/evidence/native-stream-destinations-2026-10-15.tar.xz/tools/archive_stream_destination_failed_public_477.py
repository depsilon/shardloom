"""Preserve every failed-run evidence byte in a checked nested archive, without deletion."""
import hashlib
import json
import lzma
from pathlib import Path
import sys
import tarfile

from freeze_native_release_298 import OUT, sha, save
from package_selection_acceptance_409 import Members, verify, sha_stream
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

SOURCE = OUT / 'stream-destination-public-476'
PREFIX = 'stream-destination-public-failed-476'
ARCHIVE = OUT / (PREFIX + '.tar.xz')
MANIFEST = OUT / (PREFIX + '.manifest.json.xz')
INDEX = OUT / (PREFIX + '.json')


def bound(path):
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def main():
    assert not any(path.exists() for path in (ARCHIVE, MANIFEST, INDEX))
    summary = json.loads((SOURCE / 'summary.json').read_text())
    receipt_path = OUT / 'stream-destination-public-476.json'
    receipt = json.loads(receipt_path.read_text())
    assert summary['status'] == receipt['status'] == 'failed'
    assert len(summary['cases']) == 765 and all(case['status'] == 'passed' for case in summary['cases'])
    assert receipt['returncode'] == 1 and receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert sha(receipt_path.with_suffix('.log')) == receipt['log_sha256']
    members, exclusions = Members(), []
    members.tree(SOURCE, 'public-failed', 'public-failed', 'all original failed-run evidence', exclusions, omit_outputs=True)
    ordered = sorted(members.paths.values(), key=lambda item: item.name)
    raw_size = sum(item.size for item in ordered)
    assert raw_size <= 256 * MIB
    require_local_path(ARCHIVE, Path.home(), sys.platform)
    storage = check_budgets(OUT, ARCHIVE, OUT / 'logs', min_free_bytes=12*GIB,
        reserve_bytes=raw_size + 64*MIB, max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
    with ARCHIVE.open('xb') as stream:
        with tarfile.open(fileobj=stream, mode='w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
            for item in ordered:
                verify(item.path, item.digest, item.size)
                info = tarfile.TarInfo(item.name)
                info.size, info.mode, info.mtime = item.size, 0o644, 0
                with item.path.open('rb') as source:
                    archive.addfile(info, source)
    seen = set()
    with tarfile.open(ARCHIVE, mode='r|xz') as archive:
        for entry in archive:
            assert entry.isfile() and entry.name not in seen and entry.name in members.names
            item = members.paths[members.names[entry.name]]
            with archive.extractfile(entry) as stream:
                assert sha_stream(stream) == (item.size, item.digest)
            seen.add(entry.name)
    assert seen == set(members.names)
    for item in ordered:
        verify(item.path, item.digest, item.size)
    manifest = dict(status='passed', purpose='Preserved failed full public run; acceptance remains failed.',
        archive=bound(ARCHIVE), failed_summary=bound(SOURCE / 'summary.json'), receipt=bound(receipt_path),
        member_count=len(ordered), raw_bytes=raw_size,
        members=[dict(path=str(item.path), archive_path=item.name, bytes=item.size,
                      sha256=item.digest) for item in ordered],
        exclusions=exclusions, storage=storage, all_members_reopened=True,
        original_files_removed=False, helper=bound(Path(__file__)))
    raw = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    compressed = lzma.compress(raw, preset=6)
    assert lzma.decompress(compressed) == raw
    with MANIFEST.open('xb') as stream:
        stream.write(compressed)
    save(INDEX, dict(status='passed', original_run_status='failed', archive=bound(ARCHIVE),
        manifest=bound(MANIFEST), manifest_raw_sha256=hashlib.sha256(raw).hexdigest(),
        member_count=len(seen), raw_bytes=raw_size, all_members_reopened=True,
        original_files_removed=False, helper=bound(Path(__file__))))
    print(json.dumps(dict(status='passed', members=len(seen), raw_bytes=raw_size,
        archive_bytes=ARCHIVE.stat().st_size, index=str(INDEX), original_files_removed=False)))


if __name__ == '__main__':
    main()
