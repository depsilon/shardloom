"""Package complete local streaming-destination acceptance, preserving failures."""
import hashlib
import json
import lzma
from pathlib import Path
import subprocess
import sys
import tarfile

from freeze_native_release_298 import ROOT, OUT, sha, sources, save
from package_selection_acceptance_409 import Members, verify, sha_stream
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

PREFIX = 'native-stream-destinations-2026-10-15'
LOCAL = OUT / 'stream-destination-packet-477'
DEST = ROOT / 'docs/benchmarks/evidence'
SOURCE = OUT / 'native-release-source-stream477.json'


def bound(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def read(name):
    return json.loads((OUT / name).read_text())


def main():
    frozen = read(SOURCE.name)
    accepted = frozen['source_sha256']
    assert sources() == accepted and len(accepted) == 2263
    checks = read('stream-destination-checks-476b.json')
    runtime = read('stream-destination-runtime-477.json')
    direct = read('stream-destination-direct-tests-476.json')
    public = read('stream-destination-public-inspection-477.json')
    artifacts = read('stream-destination-native-artifacts-477.json')
    full = read('stream-destination-full43-review-477.json')
    correction = read('stream-destination-log-format-correction-477.json')
    failed_public = read('stream-destination-public-failed-476.json')
    inventory_audit = read('stream-destination-completed-check-audit-477.json')
    assert all(item['status'] == 'passed' for item in
               (checks, runtime, direct, public, artifacts, full, inventory_audit, correction, failed_public))
    assert artifacts['source_sha256'] == accepted and checks['source_identity_preserved']
    assert artifacts['source_manifest'] == bound(SOURCE)
    assert artifacts['checks'] == bound(OUT / 'stream-destination-checks-476b.json')
    assert runtime['manifest_sha256'] == sha(OUT / 'stream-destination-native-artifacts-477.json')
    assert direct['manifest_sha256'] == sha(OUT / 'stream-destination-native-artifacts-476.json')
    assert artifacts['build_artifact_manifest'] == runtime['direct_artifact_manifest'] == bound(OUT / 'stream-destination-native-artifacts-476.json')
    assert artifacts['evidence_format_correction'] == bound(OUT / 'stream-destination-log-format-correction-477.json')
    assert correction['changed_source_files'] == ['scripts/run_native_streaming_input_uat.py']
    assert correction['runtime_and_package_sources_unchanged'] and correction['guard_limits_unchanged']
    original_sources = read('native-release-source-stream476.json')['source_sha256']
    assert accepted.keys() == original_sources.keys()
    assert [name for name in accepted if accepted[name] != original_sources[name]] == correction['changed_source_files']
    assert direct['tests'] == len(direct['test_names']) == 84
    assert direct['failures'] == direct['errors'] == direct['skipped'] == 0
    assert public['cases'] == runtime['public_cases'] == 777 and public['families'] == 20
    assert public['complete_case_log_records_equal'] and public['frozen_sources_and_binary_unchanged']
    assert full['queries'] == full['calls'] == 43 and full['repeats'] == 1
    assert full['all_values_schemas_and_clocks_reopened'] and full['original_input_and_sources_unchanged']
    counts = {row['stage']: row['tests'] for row in checks['completed'] if 'tests' in row}
    assert len(checks['completed']) == 6
    assert counts['workspace-tests']['passed'] == 3219 and counts['workspace-tests']['ignored'] == 0
    assert counts['native-tests']['passed'] == 4229 and counts['native-tests']['ignored'] == 29
    for row in checks['completed']:
        assert sha(row['receipt']) == row['receipt_sha256'] and sha(row['log']) == row['log_sha256']
    for name in ('native-final-cli-release-build-stream476', 'native-final-python-release-build-stream476',
                 'stream-destination-direct-476', 'stream-destination-public-477', 'stream-destination-full43-477'):
        receipt = read(name + '.json')
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert sha(OUT / (name + '.log')) == receipt['log_sha256']

    members, exclusions = Members(), []
    def add(path, prefix='evidence', role='acceptance, original failure history or frozen identity'):
        path = Path(path)
        uat = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
        parent = next((root for root in (ROOT, OUT, uat) if path.is_relative_to(root)), path.parent)
        relative = path.relative_to(parent).as_posix()
        members.add(path, prefix + '/' + relative, prefix, parent, role)

    for path in sorted(OUT.glob('stream-destination-*')):
        if path.is_file() and path.suffix in {'.json', '.log', '.md'}:
            add(path)
    inventory = json.loads(Path(inventory_audit['inventory']['path']).read_text())
    assert bound(inventory_audit['inventory']['path']) == inventory_audit['inventory']
    for item in inventory['members'] + inventory['associated_source_and_inventory_files']:
        verify(Path(item['path']), item['sha256'], item['bytes'])
        add(item['path'])
    for pattern in ('*stream_destination*.py', '*stream_destinations*.py'):
        for path in sorted(OUT.glob(pattern)):
            add(path, 'tools', 'reproduction or verification helper')
    for name in ('freeze_native_release_298.py', 'freeze_query_cli_368.py', 'run_guarded.py',
                 'run_query_timing_runtime_461.py', 'run_compression_full43_457.py',
                 'package_selection_acceptance_409.py'):
        add(OUT / name, 'tools', 'shared reproduction helper')
    for name in ('native-release-artifacts-stream476.json', 'native-release-source-stream476.json', 'native-release-source-stream477.json',
                 'stream-destinations-source-475.json', 'query-timing-manual-tests-inventory-462.json',
                 'compression-manual-tests-inventory-456.json', 'selected-view-direct-tests-468.json'):
        add(OUT / name)
    for name in ('native-final-cli-release-build-stream476', 'native-final-python-release-build-stream476'):
        for suffix in ('.json', '.log'):
            add(OUT / (name + suffix), 'builds')
    for folder, prefix in [
        (OUT / 'stream-destination-public-focused-474', 'public-first-attempt'),
        (OUT / 'stream-destination-public-focused-474b', 'public-focused'),
        (OUT / 'stream-destination-public-477', 'public'),
    ]:
        members.tree(folder, prefix, prefix, 'complete public evidence and preserved failures', exclusions, omit_outputs=True)
    members.tree(Path(full['summary']['path']).parent, 'full43', 'full43',
                 'all complete native query calls', exclusions)
    for key in ('artifacts', 'value_files', 'envelopes', 'pressure_files'):
        for item in public[key]:
            verify(Path(item['path']), item['sha256'], item['bytes'])
    for key in ('archive', 'manifest'):
        item = failed_public[key]
        verify(Path(item['path']), item['sha256'], item['bytes'])
        add(item['path'], 'failed-public', 'complete checked nested archive of the storage-refused public run')
    assert failed_public['original_run_status'] == 'failed' and not failed_public['original_files_removed']
    protocol = read('stream-destination-runtime-protocol-477.json')
    for key in ('prior_public', 'focused_names'):
        item = protocol[key]
        verify(Path(item['path']), item['sha256'], item['bytes'])
        add(item['path'], 'reference', 'frozen public case inventory')
    full_admission = json.loads(Path(full['admission']['path']).read_text())
    for item in full_admission['schema_sources']:
        verify(Path(item['path']), item['sha256'], item['bytes'])
        add(item['path'], 'reference', 'previous complete schema observation')
    for key in ('reference', 'queries'):
        item = full_admission[key]
        verify(Path(item['path']), item['sha256'], item['bytes'])
        add(item['path'], 'reference', 'retained complete query regression reference')
    for role in ('cli', 'binding'):
        item = artifacts[role]
        verify(Path(item['path']), item['sha256'], item['bytes'])
        exclusions.append(dict(**item, reason='frozen native executable; bulk payload omitted'))
    exclusions.append(dict(**full_admission['input'], reason='resident native input; full pre/post hash retained'))
    changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT, text=True).splitlines()
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=ROOT, text=True).splitlines()
    overlay = sorted(set(changed + untracked) & set(accepted))
    assert 'shardloom-vortex/src/local_primitive_relational_writer_fanout.rs' in overlay
    assert 'scripts/native_streaming_destination_cases.py' in overlay
    assert 'shardloom-python/src/batch_input.rs' in overlay
    for name in overlay:
        members.add(ROOT / name, 'source-overlay/' + name, 'repository', ROOT,
                    'complete candidate source overlay', accepted[name])
    add(ROOT / 'docs/architecture/native-stream-destinations-2026-10-15.md', 'contract', 'implementation scope and acceptance contract')
    for name in ('native-selected-text-views-2026-10-15.json', 'native-selected-view-hosted-2026-10-15.json',
                 'native-query-timing-uat-2026-10-15.json'):
        add(DEST / name, 'companion-indices', 'accepted baseline provenance')

    require_local_path(LOCAL, Path.home(), sys.platform)
    assert not LOCAL.exists()
    ordered = sorted(members.paths.values(), key=lambda item: item.name)
    raw_size = sum(item.size for item in ordered)
    assert raw_size <= 256 * MIB
    storage = check_budgets(OUT, LOCAL, OUT / 'logs', min_free_bytes=12*GIB,
        reserve_bytes=raw_size + 64*MIB, max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
    LOCAL.mkdir()
    archive_path = LOCAL / (PREFIX + '.tar.xz')
    with archive_path.open('xb') as stream:
        with tarfile.open(fileobj=stream, mode='w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
            for item in ordered:
                verify(item.path, item.digest, item.size)
                info = tarfile.TarInfo(item.name)
                info.size, info.mode, info.mtime = item.size, 0o644, 0
                with item.path.open('rb') as source:
                    archive.addfile(info, source)
    seen = set()
    with tarfile.open(archive_path, mode='r|xz') as archive:
        for entry in archive:
            assert entry.isfile() and entry.name in members.names and entry.name not in seen
            item = members.paths[members.names[entry.name]]
            with archive.extractfile(entry) as stream:
                assert sha_stream(stream) == (item.size, item.digest)
            seen.add(entry.name)
    assert seen == set(members.names) and sources() == accepted
    for item in ordered:
        verify(item.path, item.digest, item.size)
    acceptance = dict(workspace_tests=3219, native_tests=4229, native_manual_platform_exclusions=29,
        direct_tests=84, public_cases=777, public_families=20,
        public_expected_rows=public['explicit_expected_value_rows'], public_pressure_rows=public['pressure_rows'],
        complete_queries=43, complete_query_rows=full['complete_rows'])
    limitations = ('Finite local workflow acceptance and one retained-reference query pass. '
        'No matched performance comparison, whole-process memory cap, group-atomic publication, '
        'network transport, all-platform acceptance or new package release is claimed. '
        'Installed-wheel and hosted integration proof are subsequent gates.')
    manifest = dict(status='passed', base_commit=frozen['head'], source_files=len(accepted),
        source_manifest=bound(SOURCE), archive=bound(archive_path), source_overlay=overlay,
        members=[dict(path=str(item.path), archive_path=item.name, bytes=item.size,
                      sha256=item.digest, roles=item.roles) for item in ordered],
        member_count=len(ordered), raw_bytes=raw_size, all_members_reopened=True,
        storage=storage, exclusions=exclusions, acceptance=acceptance,
        preserved_failed_public=failed_public, evidence_format_correction=artifacts['evidence_format_correction'],
        runtime_build_sources_unchanged=True, builds_and_direct_tests_reused=True,
        full43_timing_totals=full['timing_totals'], source_identity_preserved=True,
        hosted_integration_complete=False, installed_wheel_proof=False, publication_attempted=False,
        vendor_source_unchanged=True, limitations=limitations)
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    packed = lzma.compress(manifest_bytes, preset=6)
    assert lzma.decompress(packed) == manifest_bytes
    manifest_path = LOCAL / (PREFIX + '.manifest.json.xz')
    with manifest_path.open('xb') as stream:
        stream.write(packed)
    index = dict(schema_version='shardloom.stream_destinations_acceptance.v1', status='passed_local',
        base_commit=frozen['head'], source_files=len(accepted), member_count=len(seen),
        all_members_reopened=True, raw_bytes=raw_size, acceptance=acceptance,
        full43_timing_totals=full['timing_totals'], source_overlay=overlay,
        archive=dict(file=archive_path.name, bytes=archive_path.stat().st_size, sha256=sha(archive_path)),
        manifest=dict(file=manifest_path.name, bytes=manifest_path.stat().st_size, sha256=sha(manifest_path),
                      raw_sha256=hashlib.sha256(manifest_bytes).hexdigest()),
        source_manifest=manifest['source_manifest'], hosted_integration_complete=False,
        installed_wheel_proof=False, publication_attempted=False, limitations=limitations)
    for path in (archive_path, manifest_path):
        target = DEST / path.name
        assert not target.exists()
        with target.open('xb') as stream:
            stream.write(path.read_bytes())
        assert sha(target) == sha(path)
    save(DEST / (PREFIX + '.json'), index)
    save(LOCAL / 'verification.json', dict(status='passed', member_count=len(seen),
        all_members_reopened=True, helper=bound(__file__), archive=bound(archive_path),
        manifest=bound(manifest_path), index=bound(DEST / (PREFIX + '.json'))))
    print(json.dumps(dict(status='passed', members=len(seen), source_overlay=len(overlay),
        raw_bytes=raw_size, archive_bytes=archive_path.stat().st_size,
        destination=str(DEST / (PREFIX + '.json')))))


if __name__ == '__main__':
    main()
