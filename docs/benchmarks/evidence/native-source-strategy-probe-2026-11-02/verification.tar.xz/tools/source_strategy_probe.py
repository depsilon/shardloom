"""Freeze and replay one finite, matched source-route investigation."""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import stat
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/dependency-compatibility-batch/shardloom-local-repo')
OUT = Path(__file__).resolve().parent.parent
RUNTIME = OUT / 'io-runtime-dependency-batch-r6'
RUN = OUT / 'source-strategy-probe-r1'
FREEZE = OUT / 'source-strategy-probe-r1-freeze.json'
ACCEPTANCE = OUT / 'source-strategy-probe-r1-acceptance.json'
DRIVER = OUT / 'io738-source-strategy-probe.json'
PYTHON = Path('/Users/dylan/LocalData/shardloom/item20-completion-2026-10-28/wheel-build-tools/bin/python')
REFERENCE = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022/independent-full43-948/reference.json')
QUERIES = ROOT / 'benchmarks/clickbench/queries.sql'
IDS = [1, 3, 13, 19, 20, 24, 34]
sys.path.insert(0, str(ROOT / 'scripts'))
from clickbench_native_sql import native_query_statements
from clickbench_reference_packet import load_reference_packet
from native_workflow_protocol import extract_result, report_fields, strict_json
from query_timing_report import query_phase_timings
from run_clickbench_query_uat import clickbench_harness_paths, equivalent, validate_input_execution
from local_uat_storage import require_local_path


def need(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return strict_json(Path(path).read_text())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def generation(path):
    value = Path(path).lstat()
    return {key: getattr(value, key) for key in
            ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')}


def identity(path):
    path = Path(path)
    before = generation(path)
    need(path.is_file() and not path.is_symlink(), 'not a regular file: ' + str(path))
    sha = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 << 20), b''):
            sha.update(block)
    need(before == generation(path), 'changed while hashing: ' + str(path))
    return dict(path=str(path), bytes=before['st_size'], sha256=sha.hexdigest())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def write_new(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def freeze():
    need(not any(path.exists() for path in (RUN, FREEZE, ACCEPTANCE, DRIVER)), 'probe identity already used')
    need(not git('status', '--porcelain'), 'accepted dependency checkout must be clean')
    manifest_path = RUNTIME / 'manifest.json'
    manifest = read(manifest_path)
    need(manifest['profile'] == 'ci-native' and manifest['features'] == ['release-user-surfaces'],
         'unexpected accepted probe build')
    build_path = OUT / manifest['build_receipt']
    build = read(build_path)
    need(build['status'] == 'passed' and build['returncode'] == 0 and build['process_group_drained'],
         'runtime build failed')
    need(identity(build_path)['sha256'] == manifest['build_receipt_sha256'], 'build receipt changed')
    need(identity(build_path.with_suffix('.log'))['sha256'] == build['log_sha256'], 'build log changed')
    overlay = identity(RUNTIME / 'source-overlay.patch')
    need({k: overlay[k] for k in ('bytes', 'sha256')} == manifest['source_overlay'], 'source overlay changed')
    compiled = []
    for relative, expected in manifest['source_snapshot'].items():
        if relative.endswith(('.rs', '.toml', '.lock')):
            observed = identity(ROOT / relative)
            need({k: observed[k] for k in ('bytes', 'sha256')} == expected, 'compiled source changed: ' + relative)
            compiled.append(observed)
    runtime = [identity(RUNTIME / name) for name in ('shardloom', '_native.abi3.so')]
    for row in runtime:
        need({k: row[k] for k in ('bytes', 'sha256')} == manifest['files'][Path(row['path']).name], 'runtime changed')
    need(runtime[0]['sha256'] == '4be92d1d5ffc8c0d4b5fb0576a08b58b968aec321587a816bda576aa7f94187e',
         'not the selected accepted runtime')
    wheel = OUT / 'installed-wheel-dependency-batch-r3/report.json'
    need(read(wheel)['status'] == 'passed', 'installed runtime acceptance failed')
    baseline = ROOT / 'docs/benchmarks/evidence/native-adaptive-prepared-full43-2026-11-02.json'
    saved = read(baseline)
    inputs = {}
    for kind, key in [('parquet', 'input_source'), ('vortex', 'native_output')]:
        expected = saved[key]
        path = Path(expected['path'])
        require_local_path(path, Path.home(), sys.platform)
        info = path.lstat()
        need(stat.S_ISREG(info.st_mode) and not path.is_symlink()
             and not getattr(info, 'st_flags', 0) & getattr(stat, 'SF_DATALESS', 0x40000000)
             and info.st_blocks * 512 >= info.st_size, 'input is not already fully resident')
        observed = identity(path)
        need(all(observed[k] == expected[k] for k in ('path', 'bytes', 'sha256')), 'input identity changed')
        inputs[kind] = dict(**observed, generation=generation(path))
    need(not (Path(inputs['parquet']['path']).parent / '.shardloom').exists(), 'unexpected automatic preparation')
    packet = load_reference_packet(REFERENCE, QUERIES)
    need(packet['packet']['reference_kind'] == 'independent_reference', 'independent reference required')
    need(packet['packet']['sha256'] == 'fc5780da415dc33bd06ed0879db07fc040db5dd419e3c37ecde7cd40a315696b',
         'reference changed')
    commands = {}
    statements = {}
    for kind in inputs:
        sql, dialect = native_query_statements(packet['queries'], packet['packet']['queries_sha256'], input_format=kind)
        statements[kind] = dict(dialect=dialect, queries={str(q): sql[q - 1] for q in IDS})
        commands[kind] = [str(PYTHON), '-B', str(ROOT / 'scripts/run_clickbench_query_uat.py'),
            '--binary', str(RUNTIME / 'shardloom'), '--input', inputs[kind]['path'], '--input-format', kind,
            '--uat-root', str(RUN / kind), '--reference-packet', str(REFERENCE), '--queries', str(QUERIES),
            '--build-commit', manifest['source_revision'], '--query-ids', ','.join(map(str, IDS)),
            '--memory-gb', '24', '--max-parallelism', '12', '--timeout', '120', '--repeats', '1', '--compress-logs']
    helpers = list(dict.fromkeys([Path(__file__), OUT / 'tools/run_guarded_preparation_contracts.py',
        manifest_path, build_path, build_path.with_suffix('.log'), RUNTIME / 'source-overlay.patch',
        wheel, baseline, REFERENCE, QUERIES, *clickbench_harness_paths()]))
    record = dict(schema_version='shardloom.source_strategy_probe.v1', status='frozen_before_execution',
        authorization='Maintainer brought source/preparation optimization investigation before Full43; bounded representative comparison implements that request.',
        query_ids=IDS, executions_per_query_per_route=1, total_executions=14,
        source_checkout=str(ROOT), accepted_checkout_revision=git('rev-parse', 'HEAD'),
        original_build_revision=manifest['source_revision'], source_overlay=overlay,
        build_profile='ci-native', features=manifest['features'], compiled_source=compiled,
        runtime=runtime, inputs=inputs, helpers=[identity(p) for p in helpers],
        statements=statements, commands=commands, route_order=['parquet', 'vortex'],
        memory_gb=24, max_parallelism=12, per_query_timeout_seconds=120,
        timing='engine_execution_seconds; seven-query totals only, never a Full43 total',
        cache_context='Full input hashing before and after the entire paired probe; uncontrolled OS cache; no flushing or artificial pacing.',
        supervision='Standard selected-query runner, complete values and lightweight workload/storage guard. No builds, tests, agents, cleanup or packaging during queries; full inventories outside execution.',
        limitations=[
            'Accepted parent runtime excludes current preparation A/B/C edits and uses ci-native with checks, not the release measurement profile.',
            'Existing accepted Vortex artifact retains its original helper schemas; this is not preparation-candidate performance acceptance.',
            'No equivalent general-provider diagnostic control: B unavailable; no spill or semantic-policy manipulation.',
            'A/C compares whole normal routes including representation, embedded helpers and provider differences; no isolated causal attribution.',
            'No fresh preparation in this probe, so no matched preparation break-even or whole-workflow claim.',
            'Single observation of seven declared queries; no repeats, automatic thresholds or full-suite extrapolation.'],
        host=dict(platform=platform.platform(), machine=platform.machine(), cpu_count=os.cpu_count()))
    write_new(FREEZE, record)
    print(json.dumps(dict(status='frozen', query_ids=IDS, total_executions=14, profile='ci-native')), flush=True)


def run():
    frozen = read(FREEZE)
    need(not RUN.exists(), 'probe has already started')
    need(identity(Path(__file__)) in frozen['helpers'], 'probe helper changed after freeze')
    for row in frozen['inputs'].values():
        need(generation(row['path']) == row['generation'], 'input generation changed')
    RUN.mkdir()
    write_new(RUN / 'started.json', dict(freeze=identity(FREEZE), total_executions=14))
    for kind in frozen['route_order']:
        print(json.dumps(dict(route=kind, status='starting', query_ids=IDS)), flush=True)
        subprocess.run(frozen['commands'][kind], cwd=ROOT, check=True)


def verify():
    need(not ACCEPTANCE.exists(), 'probe already verified')
    frozen, driver = read(FREEZE), read(DRIVER)
    need(driver['status'] == 'passed' and driver['returncode'] == 0
         and driver['direct_child_reaped'] and driver['process_group_drained'], 'probe supervision failed')
    need(driver['command'] == [str(PYTHON), '-B', str(Path(__file__)), 'run']
         and driver['query_workload'] and driver['active_output'] == str(RUN), 'undeclared driver')
    need(identity(DRIVER.with_suffix('.log'))['sha256'] == driver['log_sha256'], 'driver log changed')
    need(all(row['scopes'] == ['active_output'] for row in driver['storage_inventory_scopes']
             if row['child_started'] and not row['forced']), 'broad inventories during queries')
    need(git('rev-parse', 'HEAD') == frozen['accepted_checkout_revision'] and not git('status', '--porcelain'),
         'accepted source changed during probe')
    for row in frozen['runtime'] + frozen['helpers'] + frozen['compiled_source']:
        need(identity(row['path']) == row, 'source/runtime/helper identity changed: ' + row['path'])
    for row in frozen['inputs'].values():
        need(identity(row['path']) == {k: row[k] for k in ('path', 'bytes', 'sha256')}
             and generation(row['path']) == row['generation'], 'input changed during probe')
    packet = load_reference_packet(REFERENCE, QUERIES)
    routes = {}
    for kind in frozen['route_order']:
        paths = list((RUN / kind).glob('logs/*/summary.json'))
        need(len(paths) == 1 and not (RUN / kind / '.ingest-uat.lock').exists(), 'missing summary or retained lock')
        summary = read(paths[0])
        need(summary['complete'] and summary['completed_identity_check'] and summary['harness_identity_verified']
             and summary['reference_packet_identity_verified'] and summary['runs_completed'] == summary['runs_passed'] == 7
             and summary['score_scope'] == 'targeted_queries_only' and not summary['full_result_validation']
             and summary['selected_query_ids'] == IDS and summary['repeats'] == 1, 'incomplete selected-query observation')
        need(summary['binary_sha256'] == frozen['runtime'][0]['sha256']
             and summary['build_commit'] == frozen['original_build_revision']
             and summary['input_format'] == kind and summary['source'] == frozen['inputs'][kind]['path']
             and summary['memory_gb'] == 24 and summary['max_parallelism'] == 12, 'runtime/source/resources changed')
        need([(r['query'], r['run']) for r in summary['records']] == [(q, 1) for q in IDS], 'wrong query execution set')
        observed = []
        for record in summary['records']:
            q = record['query']
            need(record['passed'] and record['returncode'] == 0 and not record['guard_failures']
                 and record['validation'] == 'complete_values', 'query failed: ' + str(q))
            need(record['query_statement'] == packet['queries'][q - 1]
                 and record['executed_query_statement'] == frozen['statements'][kind]['queries'][str(q)], 'SQL changed')
            archives = [a for a in record['completed_log_archives'] if a['path'].endswith('.stdout.json.gz')]
            need(len(archives) == 1, 'complete stdout missing')
            archive = archives[0]
            compressed = Path(archive['path']).read_bytes()
            raw = gzip.decompress(compressed)
            need(len(compressed) == archive['gzip_bytes'] and digest(compressed) == archive['gzip_sha256']
                 and len(raw) == archive['raw_bytes'] and digest(raw) == archive['raw_sha256'], 'stdout archive changed')
            envelope = strict_json(raw.decode())
            fields = report_fields(envelope)
            validate_input_execution(fields, kind)
            values = extract_result(envelope)
            need(equivalent(values, packet['values'][q]), 'complete independent reference mismatch')
            need(digest(json.dumps(values, sort_keys=True, allow_nan=False).encode()) == record['result_sha256'], 'result hash changed')
            flags = {k: v for k, v in fields.items() if k.endswith(('fallback_attempted', 'external_engine_invoked'))}
            need(flags and all(v in (False, 'false') for v in flags.values()), 'fallback boundary failed')
            clocks = query_phase_timings(fields, record['seconds'])
            need(clocks['engine_execution_seconds'] == record['engine_execution_seconds'], 'engine clock changed')
            observed.append(dict(query=q, rows=len(values), result_sha256=record['result_sha256'],
                engine_execution_seconds=clocks['engine_execution_seconds'], evidence=fields))
        total = math.fsum(r['engine_execution_seconds'] for r in observed)
        need(math.isclose(total, summary['query_total_seconds'], abs_tol=1e-9), 'selected-query engine total mismatch')
        routes[kind] = dict(summary=identity(paths[0]), queries=observed, engine_execution_seconds=total,
                           all_selected_results_independently_replayed=True)
    need(not (Path(frozen['inputs']['parquet']['path']).parent / '.shardloom').exists(), 'unexpected preparation')
    report = dict(schema_version='shardloom.source_strategy_probe_acceptance.v1', status='passed',
        score_scope='seven_declared_queries_per_route', query_ids=IDS, total_executions=14,
        freeze=identity(FREEZE), driver=identity(DRIVER), routes=routes,
        source_runtime_and_harness_unchanged=True, process_group_drained=True, no_fallback=True,
        limitations=frozen['limitations'])
    write_new(ACCEPTANCE, report)
    print(json.dumps(dict(status='passed', queries_per_route=7,
        engine_seconds={k: v['engine_execution_seconds'] for k, v in routes.items()})), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('freeze', 'run', 'verify'))
    args = parser.parse_args()
    {'freeze': freeze, 'run': run, 'verify': verify}[args.mode]()
