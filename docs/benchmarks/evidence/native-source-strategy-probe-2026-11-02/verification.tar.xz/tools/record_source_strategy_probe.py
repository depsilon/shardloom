"""Create a deterministic, read-back-verified source-strategy evidence archive.

This helper is intentionally mechanical: it preserves the frozen probe and its
existing evidence without interpreting performance or creating new measurements.
"""
from __future__ import annotations

import hashlib
import io
import json
import math
from pathlib import Path, PurePosixPath
import tarfile

O = Path('/Users/dylan/LocalData/shardloom/direct-source-count-2026-10-31')
P = Path('/Users/dylan/.codex/worktrees/native-preparation-contracts/shardloom-local-repo')
D = Path('/Users/dylan/.codex/worktrees/dependency-compatibility-batch/shardloom-local-repo')
RUN = O / 'source-strategy-probe-r1'
FREEZE = O / 'source-strategy-probe-r1-freeze.json'
ACCEPTANCE = O / 'source-strategy-probe-r1-acceptance.json'
DRIVER = O / 'io738-source-strategy-probe.json'
DRIVER_LOG = O / 'io738-source-strategy-probe.log'
RUNTIME = O / 'io-runtime-dependency-batch-r6'
BUILD = O / 'io708-dependency-executor-runtime-build.json'
BUILD_LOG = O / 'io708-dependency-executor-runtime-build.log'
REFERENCE = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022/independent-full43-948/reference.json')
QUERIES = D / 'benchmarks/clickbench/queries.sql'
DEST = P / 'docs/benchmarks/evidence/native-source-strategy-probe-2026-11-02'
ARCHIVE = DEST / 'verification.tar.xz'
ACCEPTANCE_OUT = DEST / 'acceptance.json'
QUERY_IDS = [1, 3, 13, 19, 20, 24, 34]
RAW_LIMIT = 64 << 20
COMPRESSED_LIMIT = 8 << 20


def identity(data: bytes) -> dict[str, object]:
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def read_json(path: Path) -> dict:
    value = json.loads(path.read_text())
    if not isinstance(value, dict):
        raise ValueError(f'expected JSON object: {path}')
    return value


def safe_member(name: str) -> str:
    member = PurePosixPath(name)
    if (not name or member.is_absolute() or any(part in {'', '.', '..'} for part in member.parts)
            or '\\' in name or '\x00' in name):
        raise ValueError(f'unsafe archive member: {name!r}')
    return str(member)


def add_file(members: dict[str, bytes], sources: dict[str, dict], path: Path,
             member_name: str, expected: dict | None = None) -> None:
    member_name = safe_member(member_name)
    if member_name in members:
        raise ValueError(f'duplicate archive member: {member_name}')
    info = path.lstat()
    if path.is_symlink() or not path.is_file():
        raise ValueError(f'expected regular non-symlink file: {path}')
    data = path.read_bytes()
    observed = identity(data)
    if expected is not None:
        if any(observed.get(key) != expected.get(key) for key in ('bytes', 'sha256')):
            raise ValueError(f'frozen identity mismatch: {path}')
    after = path.lstat()
    if (info.st_size != len(data)
            or any(getattr(info, key) != getattr(after, key) for key in
                   ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns'))):
        raise ValueError(f'file changed while being read: {path}')
    if sum(map(len, members.values())) + len(data) >= RAW_LIMIT:
        raise ValueError('raw archive payload must be less than 64 MiB')
    members[member_name] = data
    sources[member_name] = {'source_path': str(path), **observed}


def main() -> None:
    if DEST.exists():
        raise FileExistsError(f'refusing existing destination: {DEST}')
    freeze = read_json(FREEZE)
    accepted = read_json(ACCEPTANCE)
    driver = read_json(DRIVER)
    manifest = read_json(RUNTIME / 'manifest.json')
    build = read_json(BUILD)

    if freeze.get('schema_version') != 'shardloom.source_strategy_probe.v1':
        raise ValueError('unexpected freeze schema')
    if freeze.get('status') != 'frozen_before_execution':
        raise ValueError('probe freeze is not in frozen state')
    if freeze.get('query_ids') != QUERY_IDS or freeze.get('total_executions') != 14:
        raise ValueError('unexpected frozen query cohort')
    if accepted.get('schema_version') != 'shardloom.source_strategy_probe_acceptance.v1':
        raise ValueError('unexpected acceptance schema')
    if accepted.get('status') != 'passed' or accepted.get('query_ids') != QUERY_IDS:
        raise ValueError('probe acceptance did not pass for the frozen cohort')
    if accepted.get('total_executions') != 14 or not accepted.get('no_fallback'):
        raise ValueError('acceptance execution/no-fallback contract mismatch')
    if not accepted.get('process_group_drained') or not accepted.get('source_runtime_and_harness_unchanged'):
        raise ValueError('acceptance process/source integrity check failed')
    if accepted.get('freeze') != identity(FREEZE.read_bytes()) | {'path': str(FREEZE)}:
        raise ValueError('acceptance freeze identity mismatch')
    if accepted.get('driver') != identity(DRIVER.read_bytes()) | {'path': str(DRIVER)}:
        raise ValueError('acceptance driver identity mismatch')
    if driver.get('status') != 'passed' or driver.get('returncode') != 0:
        raise ValueError('probe driver receipt did not pass')
    if not driver.get('process_group_drained') or driver.get('head') != freeze.get('accepted_checkout_revision'):
        raise ValueError('probe driver completion/revision mismatch')
    driver_log = DRIVER_LOG.read_bytes()
    if identity(driver_log)['sha256'] != driver.get('log_sha256'):
        raise ValueError('probe driver log digest mismatch')
    if driver.get('driver_sha256') != identity((O / 'tools/run_guarded_preparation_contracts.py').read_bytes())['sha256']:
        raise ValueError('probe driver source digest mismatch')

    if manifest.get('profile') != freeze.get('build_profile') or manifest.get('features') != freeze.get('features'):
        raise ValueError('runtime profile/features differ from freeze')
    if manifest.get('source_revision') != freeze.get('original_build_revision'):
        raise ValueError('runtime source revision differs from freeze')
    for row in freeze.get('runtime', []):
        name = Path(row['path']).name
        expected = manifest.get('files', {}).get(name)
        if not expected or any(row.get(key) != expected.get(key) for key in ('bytes', 'sha256')):
            raise ValueError(f'frozen runtime identity differs from manifest: {name}')
    overlay = identity((RUNTIME / 'source-overlay.patch').read_bytes())
    if overlay != {key: freeze['source_overlay'][key] for key in ('bytes', 'sha256')}:
        raise ValueError('runtime source overlay differs from freeze')
    if build.get('status') != 'passed' or build.get('returncode') != 0 or not build.get('process_group_drained'):
        raise ValueError('runtime build receipt did not pass')
    if identity(BUILD.read_bytes())['sha256'] != manifest.get('build_receipt_sha256'):
        raise ValueError('runtime build receipt digest mismatch')
    if identity(BUILD_LOG.read_bytes())['sha256'] != build.get('log_sha256'):
        raise ValueError('runtime build log digest mismatch')
    if manifest.get('build_receipt') != BUILD.name:
        raise ValueError('runtime build receipt name mismatch')

    expected_helpers = {row['path']: row for row in freeze.get('helpers', [])}
    expected_helpers[str(FREEZE)] = accepted['freeze']
    expected_helpers[str(DRIVER)] = accepted['driver']
    for path in (ACCEPTANCE, DRIVER_LOG, O / 'tools/record_source_strategy_probe.py'):
        expected_helpers.setdefault(str(path), None)
    run_identities = {}
    for route in accepted['routes'].values():
        summary_identity = route['summary']
        summary_path = Path(summary_identity['path'])
        if not summary_path.is_relative_to(RUN):
            raise ValueError('query summary escaped the probe tree')
        run_identities[str(summary_path)] = summary_identity
        for row in read_json(summary_path)['records']:
            for archived in row['completed_log_archives']:
                if not Path(archived['path']).is_relative_to(RUN):
                    raise ValueError('query archive escaped the probe tree')
                run_identities[archived['path']] = {
                    'bytes': archived['gzip_bytes'], 'sha256': archived['gzip_sha256']}

    members: dict[str, bytes] = {}
    sources: dict[str, dict] = {}
    for path in sorted(RUN.rglob('*')):
        if path.is_symlink():
            raise ValueError(f'probe run tree contains symlink: {path}')
        if path.is_file():
            add_file(members, sources, path, path.relative_to(O).as_posix(), run_identities.get(str(path)))
        elif not path.is_dir():
            raise ValueError(f'probe run tree contains non-regular entry: {path}')

    for path in (FREEZE, ACCEPTANCE, DRIVER, DRIVER_LOG,
                 O / 'tools/source_strategy_probe.py',
                 O / 'tools/run_guarded_preparation_contracts.py',
                 O / 'tools/record_source_strategy_probe.py',
                 RUNTIME / 'manifest.json', RUNTIME / 'source-overlay.patch', BUILD, BUILD_LOG,
                 O / 'installed-wheel-dependency-batch-r3/report.json'):
        expected = expected_helpers.get(str(path))
        add_file(members, sources, path, path.relative_to(O).as_posix(), expected)

    add_file(members, sources, REFERENCE, 'reference/reference.json', expected_helpers.get(str(REFERENCE)))
    add_file(members, sources, QUERIES, 'source/benchmarks/clickbench/queries.sql', expected_helpers.get(str(QUERIES)))
    for raw_path in sorted(expected_helpers):
        path = Path(raw_path)
        if path == REFERENCE or path == QUERIES or not path.is_relative_to(D):
            continue
        member = 'source/' + path.relative_to(D).as_posix()
        add_file(members, sources, path, member, expected_helpers[raw_path])

    if not set(expected_helpers) <= {row['source_path'] for row in sources.values()}:
        raise ValueError('frozen helper missing from archive')

    if sum(map(len, members.values())) >= RAW_LIMIT:
        raise ValueError('raw archive payload must be less than 64 MiB')

    route_rows = {}
    for route in ('parquet', 'vortex'):
        route_data = accepted.get('routes', {}).get(route)
        if not isinstance(route_data, dict) or route_data.get('all_selected_results_independently_replayed') is not True:
            raise ValueError(f'{route} results lack independent replay acceptance')
        queries = route_data.get('queries', [])
        if [row.get('query') for row in queries] != QUERY_IDS:
            raise ValueError(f'{route} query rows do not match frozen order')
        if len(queries) != 7:
            raise ValueError(f'{route} query row count mismatch')
        rows = []
        for query_id, row in zip(QUERY_IDS, queries, strict=True):
            rows.append({
                'query_id': query_id,
                'rows': row['rows'],
                'engine_execution_seconds': row['engine_execution_seconds'],
                'result_sha256': row['result_sha256'],
            })
        total = route_data.get('engine_execution_seconds')
        if not math.isclose(math.fsum(row['engine_execution_seconds'] for row in rows), total,
                            rel_tol=0, abs_tol=1e-9):
            raise ValueError(f'{route} engine total does not equal query-time sum')
        route_rows[route] = {
            'engine_execution_seconds': total,
            'queries': rows,
            'all_selected_results_independently_replayed': True,
        }
    source_map = {name: sources[name] for name in sorted(sources)}
    runtime_identity = {
        'source_revision': manifest['source_revision'],
        'profile': manifest['profile'],
        'features': manifest['features'],
        'files': manifest['files'],
        'manifest': identity((RUNTIME / 'manifest.json').read_bytes()),
        'build_receipt': identity(BUILD.read_bytes()),
        'source_overlay': overlay,
        'source_overlay_member': (RUNTIME / 'source-overlay.patch').relative_to(O).as_posix(),
    }
    input_identities = {
        name: {key: value[key] for key in ('path', 'bytes', 'sha256', 'generation')}
        for name, value in freeze['inputs'].items()
    }
    compact = {
        'schema_version': 'shardloom.source_strategy_probe_archive_acceptance.v1',
        'status': 'passed',
        'query_ids': QUERY_IDS,
        'total_executions': 14,
        'routes': route_rows,
        'runtime_build': runtime_identity,
        'inputs': input_identities,
        'limitations': freeze['limitations'],
        'validation': 'All 14 selected results were independently replayed. This is not Full43 and is not a source-only semantic replay.',
        'interpretation': 'No speedup ratio or causal interpretation is asserted.',
        'archive': {'path': ARCHIVE.name, 'bytes': None, 'sha256': None,
                    'members': {}, 'source_map': source_map},
    }

    staged_archive = io.BytesIO()
    with tarfile.open(fileobj=staged_archive, mode='w:xz', preset=6) as bundle:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.mode = 0o644
            info.uid = 0
            info.gid = 0
            info.uname = ''
            info.gname = ''
            info.mtime = 0
            info.size = len(data)
            bundle.addfile(info, io.BytesIO(data))
    archive_data = staged_archive.getvalue()
    if len(archive_data) >= COMPRESSED_LIMIT:
        raise ValueError('compressed archive must be less than 8 MiB')
    DEST.mkdir(parents=True, exist_ok=False)
    with ARCHIVE.open('xb') as stream:
        stream.write(archive_data)
    expected_names = set(members)
    observed_members: dict[str, dict] = {}
    with tarfile.open(ARCHIVE, 'r:xz') as bundle:
        entries = bundle.getmembers()
        if len(entries) != len(expected_names) or {entry.name for entry in entries} != expected_names:
            raise ValueError('archive member set differs from staged source set')
        for entry in entries:
            if not entry.isfile() or entry.issym() or entry.islnk():
                raise ValueError(f'archive contains unexpected entry type: {entry.name}')
            data = bundle.extractfile(entry).read()
            observed = identity(data)
            if data != members[entry.name]:
                raise ValueError(f'archive readback differs: {entry.name}')
            observed_members[entry.name] = observed
    if observed_members != {name: identity(data) for name, data in sorted(members.items())}:
        raise ValueError('archive member digest inventory mismatch')
    compact['archive']['bytes'] = len(archive_data)
    compact['archive']['sha256'] = hashlib.sha256(archive_data).hexdigest()
    compact['archive']['members'] = observed_members
    with ACCEPTANCE_OUT.open('x') as stream:
        json.dump(compact, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


if __name__ == '__main__':
    main()
