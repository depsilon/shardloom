"""Run serial source-bound Rust and metadata-contract gates under the existing guards."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sources, sha, save


def checked_receipt(label):
    path = OUT/(label+'.json')
    row = json.loads(path.read_text())
    assert row['status'] == 'passed' and row['returncode'] == 0
    assert row['process_group_drained'] and row['direct_child_reaped']
    assert not row['timed_out'] and not row['group_absence_unproved_at_cleanup']
    log = OUT/(label+'.log')
    assert sha(log) == row['log_sha256']
    return dict(receipt=str(path), receipt_sha256=sha(path), log=str(log),
                log_sha256=sha(log), command=row['command'])


def main():
    initial = sources()
    source_file = OUT/'native-file-metadata-gate-sources-572.json'
    save(source_file, dict(status='prepared', head=subprocess.check_output(
        ['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(), source_sha256=initial))
    test_path = 'shardloom-vortex/src/native_provider_file_metadata_tests.rs'
    names = re.findall(r'#\[test\]\s*fn (native_file_metadata_\w+)\(', (ROOT/test_path).read_text())
    assert len(names) == len(set(names)) == 15
    commands = (
        ('fmt', ['cargo','fmt','--all','--','--check']),
        ('provider-fmt', ['rustfmt','--edition','2024','--check',
            'vendor/vortex-file/src/footer/deserializer.rs','vendor/vortex-file/src/open.rs',
            'vendor/vortex-file/src/tests.rs']),
        ('clippy', ['cargo','clippy','--offline','--locked','--workspace','--all-targets','--','-D','warnings']),
        ('tests', ['cargo','test','--offline','--locked','--workspace','--all-targets','--','--test-threads=2']),
        ('native-clippy', ['cargo','clippy','--offline','--locked','-p','shardloom-cli','-p','shardloom-vortex',
            '--features','release-user-surfaces','--all-targets','--','-D','warnings']),
        ('native-tests', ['cargo','test','--offline','--locked','-p','shardloom-vortex',
            '--features','release-user-surfaces','--lib','--','--test-threads=2']),
        ('native-public-tests', ['cargo','test','--offline','--locked','-p','shardloom-cli','--lib','--bin','shardloom',
            '--test','vortex_prepare','--test','public_memory_inputs','--test','public_workflow_route',
            '--test','resident_worker','--features','release-user-surfaces','--','--test-threads=2']),
        ('preparation-tests', ['cargo','test','--offline','--locked','-p','shardloom-cli','--all-targets',
            '--no-default-features','--features','vortex-write','--','--test-threads=2']),
        ('ci-matrix', [sys.executable,'-B','scripts/check_ci_gate_matrix.py']),
        ('license-bundle', [sys.executable,'-B','scripts/check_python_license_bundle.py']),
    )
    report = dict(status='running',source_map=str(source_file),source_map_sha256=sha(source_file),
                  source_files=len(initial),helper_sha256=sha(__file__),checks=[])
    try:
        for name, command in commands:
            assert sources() == initial, 'candidate changed during acceptance'
            label = 'native-file-metadata-'+name+'-572'
            print(json.dumps(dict(check=name,status='starting')),flush=True)
            subprocess.run([sys.executable,'-B',str(OUT/'run_guarded_file_metadata_570.py'),
                '--name',label,'--timeout','1800','--',*command],cwd=ROOT,check=True)
            record = checked_receipt(label)
            log = Path(record['log']).read_text()
            groups = [list(map(int,row)) for row in re.findall(
                r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log,re.M)]
            if name.endswith('tests'):
                assert groups and all(row[1] == 0 for row in groups)
            if name == 'native-tests':
                for test in names + ['persisted_nullable_root_keeps_schema_and_omits_unmasked_statistics']:
                    assert len(re.findall(r'^test [\w:]+::'+re.escape(test)+r' \.\.\. ok$',log,re.M)) == 1, test
            record.update(name=name,result_groups=groups,total_passed=sum(row[0] for row in groups))
            report['checks'].append(record)
            assert sources() == initial, 'candidate changed during acceptance'
        report['status'] = 'passed'
    except BaseException as error:
        report.update(status='failed',error=type(error).__name__+': '+str(error))
        raise
    finally:
        destination = OUT/'native-file-metadata-acceptance-572.json'
        save(destination, report)
        print(json.dumps(dict(status=report['status'],checks=len(report['checks']),
            source_files=len(initial),report=str(destination))),flush=True)


if __name__ == '__main__':
    main()
