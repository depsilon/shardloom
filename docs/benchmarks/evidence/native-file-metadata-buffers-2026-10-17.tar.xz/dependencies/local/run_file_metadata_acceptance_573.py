"""Bind file metadata acceptance to frozen release artifacts and complete workflows."""
import argparse
import json
from pathlib import Path
import sys

import run_zstd_metadata_acceptance_533 as common
from freeze_native_release_298 import ROOT, OUT, save
from run_query_timing_runtime_461 import guarded

common.SOURCE = OUT/'native-release-source-filemetadata573.json'
common.MANIFEST = OUT/'native-release-artifacts-filemetadata573.json'
common.PROTOCOL = OUT/'file-metadata-acceptance-protocol-573.json'
common.PRIOR = OUT/'varbin-review-acceptance-protocol-560.json'
common.PRIOR_DIRECT = OUT/'varbin-review-direct-tests-560.json'
common.CHECKS = OUT/'native-file-metadata-acceptance-573.json'
common.PUBLIC = OUT/'file-metadata-public-573'
common.DIRECT = OUT/'file-metadata-direct-tests-573.json'
common.PUBLIC_ACCEPTANCE = OUT/'file-metadata-public-acceptance-573.json'

SOURCE, MANIFEST, PROTOCOL = common.SOURCE, common.MANIFEST, common.PROTOCOL
PUBLIC, PUBLIC_ACCEPTANCE = common.PUBLIC, common.PUBLIC_ACCEPTANCE
identity, receipt, load, unchanged = common.identity, common.receipt, common.load, common.unchanged
VENDOR = OUT/'native-file-provider-patch-review-572.json'


def check_receipt(path):
    path = Path(path)
    row = json.loads(path.read_text())
    assert row['status'] == 'passed' and row['returncode'] == 0
    assert row['process_group_drained'] and row['direct_child_reaped']
    assert not row['timed_out'] and not row['group_absence_unproved_at_cleanup']
    assert identity(path.with_suffix('.log'))['sha256'] == row['log_sha256']
    return row


def prerequisites():
    frozen = unchanged()
    checks = json.loads(common.CHECKS.read_text())
    assert checks['status'] == 'passed' and checks['source_identity_preserved']
    source_path = Path(checks['source_map'])
    assert identity(source_path)['sha256'] == checks['source_map_sha256']
    assert json.loads(source_path.read_text())['source_sha256'] == frozen['source_sha256']
    for row in checks['checks']:
        assert identity(row['receipt'])['sha256'] == row['receipt_sha256']
        assert identity(row['log'])['sha256'] == row['log_sha256']
        check_receipt(row['receipt'])
    assert {row['name'] for row in checks['checks']} == {
        'provider-fmt', 'clippy', 'tests', 'fmt', 'native-clippy',
        'native-correction-sink', 'native-correction-json', 'native-public-tests', 'preparation-tests',
        'ci-matrix', 'license-bundle'}
    assert checks['native_coverage']['status'] == 'passed_after_test_lifetime_correction'
    assert checks['native_coverage']['unique_tests_passed'] == 2920
    assert checks['native_coverage']['ignored'] == 27
    for row in checks['native_coverage']['evidence']:
        assert identity(row['path']) == row
    vendor = json.loads(VENDOR.read_text())
    assert vendor['status'] == 'passed' and vendor['original_members'] == 33
    assert set(vendor['modified_upstream_files']) == {
        'Cargo.toml', 'src/open.rs', 'src/footer/deserializer.rs', 'src/tests.rs'}
    for path, digest in vendor['files'].items():
        assert identity(ROOT/path)['sha256'] == digest
    for label in ('native-file-provider-library-572b', 'native-file-provider-clippy-572'):
        check_receipt(OUT/(label+'.json'))
    assert unchanged() == frozen


def protocol():
    value = json.loads(PROTOCOL.read_text())
    for row in value['helpers'] + [value[key] for key in (
        'source', 'artifacts', 'prior_protocol', 'prior_direct', 'baseline',
        'checks', 'vendor', 'contract')]:
        assert identity(row['path']) == row
    return value


def declare():
    prerequisites()
    manifest = load()
    prior = json.loads(common.PRIOR.read_text())
    direct = json.loads(common.PRIOR_DIRECT.read_text())
    assert prior['status'] == 'predeclared'
    assert direct['status'] == 'passed' and direct['tests'] == 100
    assert len(direct['test_names']) == len(set(direct['test_names'])) == 100
    sys.path[:0] = [str(ROOT/'python/src'), str(ROOT/'scripts')]
    from run_native_streaming_input_uat import FAMILIES
    families, names = prior['expected_public_families'], prior['expected_public_names']
    assert list(FAMILIES) == families and len(families) == 36
    assert len(names) == len(set(names)) == 4827
    assert identity(prior['baseline']['path']) == prior['baseline']
    helpers = [Path(__file__), Path(common.__file__),
        OUT/'freeze_native_release_298.py', OUT/'run_query_timing_runtime_461.py',
        OUT/'run_guarded.py', OUT/'run_file_metadata_remaining_573.py',
        OUT/'verify_file_metadata_public_573.py', OUT/'verify_stream_dynamic_subquery_public_522.py',
        OUT/'verify_file_metadata_acceptance_573.py', OUT/'verify_file_metadata_vendor_572.py']
    save(PROTOCOL, dict(status='predeclared', native_engine_executions=0,
        source=identity(SOURCE), artifacts=identity(MANIFEST), helpers=[identity(path) for path in helpers],
        prior_protocol=identity(common.PRIOR), prior_direct=identity(common.PRIOR_DIRECT),
        expected_direct_tests=100, expected_direct_names=direct['test_names'],
        expected_public_names=names, expected_public_families=families,
        baseline=prior['baseline'], checks=identity(common.CHECKS), vendor=identity(VENDOR),
        contract=identity(ROOT/'docs/architecture/native-file-metadata-buffers-2026-10-16.md'),
        performance_claim=False, whole_process_memory_ceiling=False, installed_wheel_proof=False))
    assert load() == manifest
    print(json.dumps(dict(status='predeclared', direct_tests=100, public_cases=4827, families=36)))


def public():
    prerequisites()
    manifest, frozen = load(), protocol()
    direct = json.loads(common.DIRECT.read_text())
    assert direct['status'] == 'passed' and direct['tests'] == 100 and direct['skipped'] == 0
    receipt(OUT/'file-metadata-direct-573.json')
    assert not PUBLIC.exists()
    families = frozen['expected_public_families']
    guarded('file-metadata-public-573', 7200,
        [sys.executable, '-B', ROOT/'scripts/run_native_streaming_input_uat.py',
         '--binary', manifest['cli']['path'], '--uat-root', PUBLIC, '--operation-timeout', '600',
         '--compress-logs', '--families', *families])
    receipt(OUT/'file-metadata-public-573.json')
    summary = json.loads((PUBLIC/'summary.json').read_text())
    assert summary['status'] == 'passed' and summary['families'] == families and summary['compress_logs']
    assert [row['name'] for row in summary['cases']] == frozen['expected_public_names']
    assert all(row['status'] == 'passed' for row in summary['cases'])
    assert load() == manifest and protocol() == frozen
    save(PUBLIC_ACCEPTANCE, dict(status='passed', cases=4827, families=families,
        manifest=identity(MANIFEST), source=identity(SOURCE), protocol=identity(PROTOCOL),
        summary=identity(PUBLIC/'summary.json'), direct=identity(common.DIRECT),
        source_identity_preserved=True, full43_pending=True))
    print(json.dumps(dict(status='passed', public_cases=4827, families=36)))


common.prerequisites = prerequisites
common.protocol = protocol
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('declare', 'direct', 'public'))
    args = parser.parse_args()
    {'declare': declare, 'direct': common.direct, 'public': public}[args.operation]()
