"""Complete gates after correcting a retained-schema test's final release assertion."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sources, sha, save
from verify_file_metadata_acceptance_572b import checked_receipt

TESTS = {
    'native-correction-sink': ('local_primitives::native_sink::tests::empty_completed_result_writes_native_schema_after_source_owner_drops',
        'shardloom-vortex/src/local_primitive_native_sink_tests.rs', 'native-file-metadata-empty-sink-before-573.rs'),
    'native-correction-json': ('resident_session::result_json::tests::empty_retained_projection_keeps_schema_and_rejects_unknown_json_fields',
        'shardloom-vortex/src/resident_result_json_tests.rs', 'native-file-metadata-empty-json-before-573.rs'),
}
INSERTION = ('    // The retained schema still owns the serialized file DType.\n'
             '    assert!(memory.snapshot().reserved_bytes > 0);\n'
             '    drop(expected_dtype);\n')


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def main():
    initial = sources()
    previous_path = OUT/'native-file-metadata-gate-sources-572b.json'
    previous = json.loads(previous_path.read_text())['source_sha256']
    assert set(initial) == set(previous)
    assert {name for name in initial if initial[name] != previous[name]} == {row[1] for row in TESTS.values()}
    transitions = []
    for _, test_path, before_name in TESTS.values():
        before = OUT/before_name
        after_text = (ROOT/test_path).read_text()
        assert sha(before) == previous[test_path]
        assert after_text.count(INSERTION) == 1
        assert after_text.replace(INSERTION, '', 1) == before.read_text()
        transitions.append(dict(path=test_path, before=identity(before), after=identity(ROOT/test_path)))
    assert ('#[cfg(all(feature = "vortex-local-primitives", feature = "vortex-write", unix))]\n'
            '#[path = "local_primitive_native_sink.rs"]\npub(crate) mod native_sink;') in (ROOT/'shardloom-vortex/src/local_primitives.rs').read_text()
    assert '#[cfg(test)]\n#[path = "local_primitive_native_sink_tests.rs"]\nmod tests;' in (ROOT/'shardloom-vortex/src/local_primitive_native_sink.rs').read_text()
    assert '#[cfg(all(feature = "vortex-local-primitives", unix))]\n#[path = "resident_result_json.rs"]\nmod result_json;' in (ROOT/'shardloom-vortex/src/resident_session.rs').read_text()
    assert '#[cfg(test)]\n#[path = "resident_result_json_tests.rs"]\nmod tests;' in (ROOT/'shardloom-vortex/src/resident_result_json.rs').read_text()
    failure_path = OUT/'native-file-metadata-native-tests-572b.json'
    failure = json.loads(failure_path.read_text())
    failure_log = failure_path.with_suffix('.log')
    raw = failure_log.read_text()
    assert failure['status'] == 'failed' and failure['returncode'] == 101
    assert failure['process_group_drained'] and failure['direct_child_reaped']
    assert not failure['timed_out'] and not failure['group_absence_unproved_at_cleanup']
    assert sha(failure_log) == failure['log_sha256']
    summaries = re.findall(r'^test result: FAILED\. (\d+) passed; (\d+) failed; (\d+) ignored;', raw, re.M)
    assert summaries == [('2918', '2', '27')], summaries
    failures = re.findall(r'^test (.+) \.\.\. FAILED$', raw, re.M)
    assert failures == [row[0] for row in TESTS.values()], failures
    passed_names = re.findall(r'^test (.+) \.\.\. ok$', raw, re.M)
    assert len(passed_names) == len(set(passed_names)) == 2918
    metadata_names = re.findall(r'#\[test\]\s*fn (native_file_metadata_\w+)\(',
        (ROOT/'shardloom-vortex/src/native_provider_file_metadata_tests.rs').read_text())
    assert len(metadata_names) == 16
    for name in metadata_names + ['persisted_nullable_root_keeps_schema_and_omits_unmasked_statistics']:
        assert len([path for path in passed_names if path.endswith('::'+name)]) == 1
    prior_path = OUT/'native-file-metadata-acceptance-572b.json'
    prior = json.loads(prior_path.read_text())
    assert prior['status'] == 'failed' and prior['source_map_sha256'] == sha(previous_path)
    reused = []
    for row in prior['checks']:
        if row['name'] not in ('provider-fmt', 'clippy', 'tests'):
            continue
        checked = checked_receipt(Path(row['receipt']).stem)
        assert all(row[key] == checked[key] for key in checked)
        if row['name'] == 'tests':
            default_log = Path(row['log']).read_text()
            assert all(name not in default_log for name in failures)
        reused.append(dict(**row, final_reuse_reason='Only two test-only native modules changed; default targets and provider source are byte-identical.'))
    assert {row['name'] for row in reused} == {'provider-fmt', 'clippy', 'tests'}
    source_file = OUT/'native-file-metadata-gate-sources-573.json'
    save(source_file, dict(status='prepared', head=subprocess.check_output(
        ['git','rev-parse','HEAD'], cwd=ROOT, text=True).strip(), source_sha256=initial))
    report = dict(status='running', source_map=str(source_file), source_map_sha256=sha(source_file),
        source_files=len(initial), source_identity_preserved=False, checks=reused,
        prior_attempt=identity(prior_path), helper=identity(__file__),
        source_transition=dict(changed_files=[row[1] for row in TESTS.values()], files=transitions,
            exact_inserted_test_assertions=INSERTION,
            production_sources_unchanged=True),
        native_coverage=dict(status='pending_correction', full_suite_passed=2918,
            full_suite_failed=2, ignored=27, focused_metadata_tests_passed=16,
            failed_tests=failures, corrected_tests=[], evidence=[identity(failure_path), identity(failure_log),
                identity(previous_path)]+[row['before'] for row in transitions]))
    commands = (
        ('fmt', ['cargo','fmt','--all','--','--check']),
        ('native-clippy', ['cargo','clippy','--offline','--locked','-p','shardloom-cli','-p','shardloom-vortex',
            '--features','release-user-surfaces','--all-targets','--','-D','warnings']),
        *[(label, ['cargo','test','--offline','--locked','-p','shardloom-vortex',
            '--features','release-user-surfaces','--lib',values[0],'--','--exact','--test-threads=2'])
          for label, values in TESTS.items()],
        ('native-public-tests', ['cargo','test','--offline','--locked','-p','shardloom-cli','--lib','--bin','shardloom',
            '--test','vortex_prepare','--test','public_memory_inputs','--test','public_workflow_route',
            '--test','resident_worker','--features','release-user-surfaces','--','--test-threads=2']),
        ('preparation-tests', ['cargo','test','--offline','--locked','-p','shardloom-cli','--all-targets',
            '--no-default-features','--features','vortex-write','--','--test-threads=2']),
        ('ci-matrix', [sys.executable,'-B','scripts/check_ci_gate_matrix.py',
            '--output',str(OUT/'native-file-metadata-ci-matrix-report-573.json')]),
        ('license-bundle', [sys.executable,'-B','scripts/check_python_license_bundle.py']),
    )
    try:
        for name, command in commands:
            assert sources() == initial
            label = 'native-file-metadata-'+name+'-573'
            print(json.dumps(dict(check=name,status='starting')),flush=True)
            subprocess.run([sys.executable,'-B',str(OUT/'run_guarded_file_metadata_570.py'),
                '--name',label,'--timeout','1800','--',*command], cwd=ROOT, check=True)
            row = checked_receipt(label)
            log = Path(row['log']).read_text()
            groups = [list(map(int,values)) for values in re.findall(
                r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log,re.M)]
            if name.endswith('tests'):
                assert groups and all(values[1] == 0 for values in groups)
            if name in TESTS:
                assert groups == [[1,0,0]]
                assert log.splitlines().count('test '+TESTS[name][0]+' ... ok') == 1
                report['native_coverage']['corrected_tests'].append(TESTS[name][0])
                report['native_coverage']['evidence'] += [identity(Path(row['receipt'])), identity(Path(row['log']))]
            row.update(name=name, result_groups=groups, total_passed=sum(values[0] for values in groups))
            report['checks'].append(row)
            assert sources() == initial
        assert report['native_coverage']['corrected_tests'] == failures
        report['native_coverage'].update(status='passed_after_test_lifetime_correction',
            unique_tests_passed=2920,
            note='The complete run passed 2,918 tests and exposed two test-lifetime assertions. Only those assertions were corrected; both focused reruns passed. All production source identities are unchanged. The failed original run remains explicit.')
        report.update(status='passed', source_identity_preserved=True)
    except BaseException as error:
        report.update(status='failed', error=type(error).__name__+': '+str(error))
        raise
    finally:
        destination = OUT/'native-file-metadata-acceptance-573.json'
        save(destination, report)
        print(json.dumps(dict(status=report['status'], checks=len(report['checks']), report=str(destination))), flush=True)


if __name__ == '__main__':
    main()
