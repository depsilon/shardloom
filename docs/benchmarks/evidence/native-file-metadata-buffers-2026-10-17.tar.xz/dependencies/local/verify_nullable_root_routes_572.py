"""Verify the literal route inventory and retain the separate default-root scan failure."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
HEAD = '36f620a0e38cd13730cd769e8a7a45cad694c73c'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    return dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path.read_bytes()))


def main():
    inventory = OUT/'native-nullable-root-route-inventory-572.json'
    packet = json.loads(inventory.read_text())
    assert packet['baseline_head'] == HEAD
    anchors = 0
    for row in packet['sources']:
        path = ROOT/row['path']
        raw = path.read_bytes()
        assert sha(raw) == row['sha256']
        assert raw == subprocess.check_output(['git','show',HEAD+':'+row['path']],cwd=ROOT)
        lines = raw.decode().splitlines()
        for anchor in row['numbered_excerpt']:
            number, text = anchor.split(': ',1)
            assert lines[int(number)-1] == text, (row['path'],number)
            anchors += 1
    assert len(packet['sources']) == 9 and anchors == 134
    baseline_path = OUT/'native-file-provider-library-571b.json'
    baseline = json.loads(baseline_path.read_text())
    baseline_log = OUT/'native-file-provider-library-571b.log'
    assert baseline['status'] == 'failed' and baseline['returncode'] == 101
    assert sha(baseline_log.read_bytes()) == baseline['log_sha256']
    assert 'test did not panic as expected' in baseline_log.read_text()
    receipt_path = OUT/'native-file-provider-library-572.json'
    receipt = json.loads(receipt_path.read_text())
    log_path = OUT/'native-file-provider-library-572.log'
    assert sha(log_path.read_bytes()) == receipt['log_sha256']
    assert receipt['status'] == 'failed' and receipt['returncode'] == 101
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup']
    log = log_path.read_text()
    assert 'test result: FAILED. 138 passed; 1 failed; 0 ignored;' in log
    assert 'ArrayStreamAdapter expected array with type {age=i32?}?, actual {age=i32?}' in log
    reader = ROOT/'vendor/vortex-layout/src/layouts/struct_/reader.rs'
    assert reader.read_bytes() == subprocess.check_output(
        ['git','show',HEAD+':vendor/vortex-layout/src/layouts/struct_/reader.rs'],cwd=ROOT)
    report = dict(status='passed',schema_version='shardloom.nullable_root_route_primary_review.v1',
        inventory=identity(inventory),source_files=9,verified_numbered_lines=anchors,
        original_expected_panic_failure=dict(receipt=identity(baseline_path),log=identity(baseline_log)),
        default_root_scan_failure=dict(receipt=identity(receipt_path),log=identity(log_path),
            fixture=identity(OUT/'native-file-nullable-root-default-scan-572.rs'),
            unchanged_struct_reader=identity(reader)),
        primary_decision='The obsolete expected-panic writer fixture must follow the admitted statistics contract. Default writer metadata and every logical projected child value are checked for all-valid and mixed-root validity. Default structural-layout root projection is a separate reproduced limitation: its expansion packs a nonnullable root and applies root validity to children. The production persisted writer uses SequentialNativeFlatLayout and has a complete nullable-root value regression; that regression remains required by the broad candidate acceptance. Do not claim generic default structural-layout root scans or nullable-root spill acceptance from this packet.',
        pending='Track the default structural-layout root-projection behavior under native source/type composition, separately from file metadata byte ownership. Generic nullable-root spill has no dedicated proof in the bounded inventory.',
        helper=identity(Path(__file__)))
    destination = OUT/'native-nullable-root-route-primary-review-572.json'
    destination.open('x').write(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(status='passed',source_files=9,verified_numbered_lines=anchors,report=str(destination))))


if __name__ == '__main__':
    main()
