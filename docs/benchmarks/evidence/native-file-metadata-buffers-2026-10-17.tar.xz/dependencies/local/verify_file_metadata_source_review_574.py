"""Bind the primary metadata ownership review to committed, tested source bytes."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess

from freeze_native_release_298 import ROOT, OUT, save, sources
from run_file_metadata_acceptance_573 import SOURCE, identity, prerequisites

BASE = '88c836bd64e1ff93ebc4978ae35e187ed10cb026'
HEAD = '277699af4204d71c1c8377dd11dadfb15d122d26'
REGISTRY = Path('/Users/dylan/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f')


def main():
    prerequisites()
    frozen = json.loads(SOURCE.read_text())
    expected = frozen['source_sha256']
    assert frozen['head'] == HEAD and len(expected) == 2410
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
    requests = ''.join(HEAD + ':' + name + '\n' for name in expected).encode()
    raw = subprocess.check_output(['git', 'cat-file', '--batch'], cwd=ROOT, input=requests)
    stream = io.BytesIO(raw)
    for name, digest in expected.items():
        header = stream.readline().decode().split()
        assert len(header) == 3 and header[1] == 'blob', (name, header)
        payload = stream.read(int(header[2]))
        assert hashlib.sha256(payload).hexdigest() == digest, name
        assert stream.read(1) == b'\n'
    assert not stream.read()
    changed = subprocess.check_output(['git', 'diff', '--name-only', BASE, HEAD], cwd=ROOT, text=True).splitlines()
    overlay = sorted(set(changed) & expected.keys())
    reviewed = [
        'vendor/vortex-file/src/open.rs',
        'vendor/vortex-file/src/footer/deserializer.rs',
        'vendor/vortex-file/src/footer/mod.rs',
        'vendor/vortex-file/src/tests.rs',
        'vendor/vortex-file/upstream-provenance.json',
        'vendor/vortex-array/src/dtype/struct_.rs',
        'vendor/vortex-array/src/dtype/serde/flatbuffers.rs',
        'vendor/vortex-layout/src/flatbuffers.rs',
        'vendor/vortex-layout/src/children.rs',
        'vendor/vortex-layout/src/layouts/struct_/reader.rs',
        'shardloom-vortex/src/owned_buffers.rs',
        'shardloom-vortex/src/native_provider_memory.rs',
        'shardloom-vortex/src/native_provider_file_metadata_tests.rs',
        'shardloom-vortex/src/local_primitive_native_sink_tests.rs',
        'shardloom-vortex/src/resident_result_json_tests.rs',
    ]
    records = [identity(ROOT / name) for name in reviewed]
    assert all(row['sha256'] == expected[str(Path(row['path']).relative_to(ROOT))] for row in records)
    names = re.findall(r'#\[test\]\s*fn (native_file_metadata_\w+)\(',
        (ROOT / 'shardloom-vortex/src/native_provider_file_metadata_tests.rs').read_text())
    assert len(names) == len(set(names)) == 16
    opening = (ROOT / 'vendor/vortex-file/src/open.rs').read_text()
    parser = (ROOT / 'vendor/vortex-file/src/footer/deserializer.rs').read_text()
    assert 'deserializer.try_prefix_data(more_data)?;' in opening
    assert 'deserializer.prefix_data(' not in opening
    assert 'FlatBuffer::copy_from(' not in parser
    assert 'ByteBuffer::copy_from_aligned(' not in opening
    checks = json.loads((OUT / 'native-file-metadata-acceptance-573.json').read_text())
    assert checks['status'] == 'passed' and checks['native_coverage']['unique_tests_passed'] == 2920
    assert {row['name']: row['total_passed'] for row in checks['checks'] if row['name'].endswith('tests')} == {
        'tests': 3225, 'native-public-tests': 1079, 'preparation-tests': 1149}
    assert sources() == expected
    result = dict(
        schema_version='shardloom.native_file_metadata_source_review.v1',
        status='passed_source_review', base=BASE, head=HEAD,
        source_snapshot=identity(SOURCE), committed_source_files_verified=len(expected),
        all_selected_sources_match_commit=True, source_overlay=overlay,
        reviewed_sources=records,
        reviewed_registry_sources=[identity(REGISTRY / name) for name in (
            'vortex-flatbuffers-0.85.0/src/lib.rs', 'vortex-buffer-0.85.0/src/const.rs')],
        gate_report=identity(OUT / 'native-file-metadata-acceptance-573.json'),
        provider_review=identity(OUT / 'native-file-provider-patch-review-572.json'),
        focused_test_names=names,
        expert_objections=[
            dict(concern='Charging after a copy or losing the typed denial during footer growth.',
                 resolution='The session allocator admits before all covered copies. Checked growth retains both inputs until replacement; denied growth preserves the parser buffer. Exact, short, competing-owner and malformed-input tests verify cleanup and the original reservation denial.'),
            dict(concern='Freeing reservations when a file closes while schema/layout consumers still retain copied bytes.',
                 resolution='ReservedWritableBuffer freezes into a shared ByteBuffer owner. ConstBuffer conversion preserves that owner; ViewedDType and ViewedLayoutChildren retain it. Clone, slice, nested/wide and independent layout-only tests cover final-consumer release. Two old cleanup assertions now explicitly drop their retained schemas.'),
            dict(concern='Conflating byte-buffer admission with structural metadata coverage or unrelated nullable-root semantics.',
                 resolution='Only named reader byte copies are covered. The unchanged structural root reader limitation has a preserved failure and its own PERF-07 obligation. Structural tables, lazy caches, writer scratch and whole-process RSS remain excluded; no performance or release claim follows from these checks.'),
        ],
        unresolved_in_scope_findings=[],
        remaining_acceptance=['frozen release-artifact workflows', 'Full43 correctness',
                              'installed wheels and hosted integration'],
        publication_attempted=False, performance_claim=False, helper=identity(__file__),
    )
    destination = OUT / 'native-file-metadata-source-review-574.json'
    save(destination, result)
    print(json.dumps(dict(status=result['status'], sources=len(expected), overlay=len(overlay),
                          focused_tests=len(names), report=str(destination))))


if __name__ == '__main__':
    main()
