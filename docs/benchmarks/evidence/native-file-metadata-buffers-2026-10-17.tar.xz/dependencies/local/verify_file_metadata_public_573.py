"""Reopen every complete public file-metadata acceptance result."""
import verify_stream_dynamic_subquery_public_522 as review
import run_file_metadata_acceptance_573 as acceptance

review.PUBLIC = acceptance.PUBLIC
review.RUNTIME_PATH = acceptance.PUBLIC_ACCEPTANCE
review.RECEIPT_PATH = acceptance.OUT/'file-metadata-public-573.json'
review.BASELINE_PATH = acceptance.PROTOCOL
review.OUTPUT = acceptance.OUT/'file-metadata-public-inspection-report-573.json'
review.ACCEPTED_SOURCE = acceptance.SOURCE
review.load = acceptance.load
review.unchanged = acceptance.unchanged

if __name__ == '__main__':
    acceptance.protocol()
    review.main()
    acceptance.protocol()
