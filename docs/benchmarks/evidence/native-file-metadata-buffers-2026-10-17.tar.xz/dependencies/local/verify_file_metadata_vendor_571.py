"""Check the exact file provider patch and refresh its generated notice record."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tomllib

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
BASE = '36f620a0e38cd13730cd769e8a7a45cad694c73c'
ARCHIVE = Path('/Users/dylan/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f/vortex-file-0.85.0.crate')
sys.path.insert(0, str(ROOT/'scripts'))
import check_python_license_bundle as notices


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def source(path):
    return subprocess.check_output(['git', 'show', BASE+':'+path], cwd=ROOT)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--refresh-notices', action='store_true')
    args = parser.parse_args()
    directory = ROOT/'vendor/vortex-file'
    provenance = json.loads((directory/'upstream-provenance.json').read_text())
    assert digest(ARCHIVE.read_bytes()) == provenance['registry_archive_sha256']
    assert provenance['provider'] == 'vortex-file' and provenance['version'] == '0.85.0'
    assert provenance['license'] == 'Apache-2.0'
    assert digest((directory/'LICENSE').read_bytes()) == provenance['license_sha256']
    with tarfile.open(ARCHIVE, 'r:gz') as archive:
        original = {member.name.split('/', 1)[1]:archive.extractfile(member).read()
            for member in archive.getmembers() if member.isfile()}
    assert len(original) == provenance['registry_archive_file_count'] == 33
    assert {name:digest(raw) for name,raw in original.items()} == provenance['original_files_sha256']
    modified = []
    for name, raw in original.items():
        if name == 'Cargo.lock':
            continue
        current = (directory/name).read_bytes()
        if raw != current:
            modified.append(name)
        if name.endswith('.rs'):
            assert current.startswith(b'// SPDX-License-Identifier: Apache-2.0\n// SPDX-FileCopyrightText: Copyright the Vortex contributors\n')
    assert set(modified) == {'Cargo.toml', 'src/open.rs', 'src/footer/deserializer.rs'}
    normalized = tomllib.loads((directory/'Cargo.toml').read_text())
    assert normalized['package'].pop('publish') is False
    assert normalized == tomllib.loads(original['Cargo.toml'].decode())
    root_manifest = tomllib.loads((ROOT/'Cargo.toml').read_text())
    old_manifest = tomllib.loads(source('Cargo.toml').decode())
    assert root_manifest['patch']['crates-io'].pop('vortex-file') == {'path':'vendor/vortex-file'}
    root_manifest['workspace']['exclude'].remove('vendor/vortex-file')
    assert root_manifest == old_manifest
    locked = tomllib.loads((ROOT/'Cargo.lock').read_text())
    previous = tomllib.loads(source('Cargo.lock').decode())
    old_provider = next(p for p in previous['package'] if p['name'] == 'vortex-file')
    assert old_provider.pop('checksum') == provenance['registry_archive_sha256']
    assert old_provider.pop('source') == 'registry+https://github.com/rust-lang/crates.io-index'
    assert locked == previous
    if args.refresh_notices:
        target = ROOT/notices.BUNDLE/'manifest.json'
        before = target.read_bytes()
        assert before == source(str(notices.BUNDLE/'manifest.json'))
        manifest = json.loads(before)
        removed = [p for p in manifest['components'] if p['name'] == 'vortex-file']
        assert len(removed) == 1 and removed[0]['version'] == '0.85.0'
        assert removed[0]['crate_checksum_sha256'] == provenance['registry_archive_sha256']
        manifest['components'] = [p for p in manifest['components'] if p['name'] != 'vortex-file']
        vendored = notices.vendored_components(ROOT)
        assert [p for p in vendored if p['name'] != 'vortex-file'] == manifest['vendored_components']
        manifest['vendored_components'] = vendored
        # The Vortex Apache license text is already present and shared by providers.
        for record in next(p for p in vendored if p['name'] == 'vortex-file')['files']:
            assert digest((ROOT/notices.BUNDLE/record['text']).read_bytes()) == record['sha256']
        target.write_text(json.dumps(manifest, indent=2, ensure_ascii=False)+'\n')
    notice_report = notices.verify(ROOT)
    report = dict(schema_version='shardloom.native_file_provider_patch_review.v1', status='passed',
        base=BASE, original_members=33, modified_upstream_files=modified,
        lock_graph_change='Only vortex-file 0.85.0 registry identity replaced by the reviewed local path.',
        notice_bundle=notice_report, notices_refreshed=args.refresh_notices,
        files={str(path.relative_to(ROOT)):digest(path.read_bytes()) for path in
            [ROOT/'Cargo.toml', ROOT/'Cargo.lock', ROOT/notices.BUNDLE/'manifest.json',
             directory/'upstream-provenance.json', directory/'LICENSE', directory/'Cargo.toml',
             directory/'src/open.rs', directory/'src/footer/deserializer.rs']},
        helper_sha256=digest(Path(__file__).read_bytes()))
    destination = OUT/('native-file-provider-notices-571.json' if args.refresh_notices else 'native-file-provider-patch-review-571.json')
    destination.open('x').write(json.dumps(report, indent=2)+'\n')
    print(json.dumps(dict(status='passed', original_members=33, modified_upstream_files=modified,
        notice_bundle=notice_report, report=str(destination))))


if __name__ == '__main__':
    main()
