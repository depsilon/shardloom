"""Verify the complete published file provider before an optional local source copy."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import tarfile
import tomllib

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PACKET = OUT/'native-file-provider-provenance-intake-570.json'
ARCHIVE = Path('/Users/dylan/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f/vortex-file-0.85.0.crate')
EXPECTED = '0e98e36429607845b0d573be88c6ef43638095828b0977c8b9c32e022bd6e9fc'
LICENSE_SHA = 'cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = Path(path).read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=digest(raw))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--vendor', action='store_true')
    args = parser.parse_args()
    packet = json.loads(PACKET.read_text())
    assert digest(PACKET.read_bytes()) == 'd2953051c4e93a7a8211369c633f9e8a82b1abf583f193d2557d66c38230d619'
    assert digest(ARCHIVE.read_bytes()) == EXPECTED
    lock_raw = (ROOT/'Cargo.lock').read_bytes()
    locked = [p for p in tomllib.loads(lock_raw.decode())['package'] if p['name'] == 'vortex-file']
    assert len(locked) == 1 and locked[0]['version'] == '0.85.0'
    assert locked[0]['checksum'] == EXPECTED
    assert locked[0]['source'] == 'registry+https://github.com/rust-lang/crates.io-index'
    files, inventory = {}, []
    with tarfile.open(ARCHIVE, 'r:gz') as archive:
        for member in archive.getmembers():
            assert member.isfile() and member.size >= 0
            parts = PurePosixPath(member.name).parts
            assert len(parts) > 1 and parts[0] == 'vortex-file-0.85.0'
            assert not PurePosixPath(member.name).is_absolute()
            assert all(part not in ('.', '..', '') for part in parts)
            relative = PurePosixPath(*parts[1:]).as_posix()
            assert relative not in files
            raw = archive.extractfile(member).read()
            assert len(raw) == member.size
            files[relative] = raw
            inventory.append(dict(tar_name=member.name, relative_path=relative,
                size_bytes=len(raw), sha256=digest(raw)))
    assert len(files) == 33 and sum(map(len, files.values())) == 499083
    assert inventory == packet['archive']['inventory']
    assert not packet['archive']['nonregular_members'] and not packet['archive']['path_or_duplicate_flags']
    normalized = tomllib.loads(files['Cargo.toml'].decode())
    assert normalized['package']['name'] == 'vortex-file'
    assert normalized['package']['version'] == '0.85.0'
    assert normalized['package']['license'] == 'Apache-2.0'
    assert not normalized['package']['build'] and not normalized['package']['autobenches']
    assert 'bench' not in normalized
    forbidden = re.compile(r'(?:^|-)(?:datafusion|duckdb|spark|polars|velox|trino|dask|ray)(?:-|$)', re.I)
    assert not any(forbidden.search(name) for name in normalized['dependencies'])
    excerpt_corrections = []
    for name in ('Cargo.toml', 'Cargo.toml.orig'):
        entry = packet['manifests'][name]
        assert entry['raw_utf8'].encode() == files[name]
        assert entry['sha256'] == digest(files[name])
        lines = files[name].decode().splitlines(keepends=True)
        for key, block in entry.items():
            if key.startswith('literal_') and isinstance(block, dict) and 'text' in block:
                actual = ''.join(lines[block['start_line']-1:block['end_line']])
                if actual != block['text']:
                    assert actual == block['text']+'\n' and lines[block['end_line']-1] == '\n'
                    excerpt_corrections.append(dict(manifest=name, block=key,
                        recorded_end_line=block['end_line'], exact_end_line=block['end_line']-1,
                        reason='The supplied range included one trailing blank line omitted by the excerpt.'))
    assert len(excerpt_corrections) == 4
    vcs = json.loads(files['.cargo_vcs_info.json'])
    assert vcs == dict(git=dict(sha1='afb005379dd9a1b7dc7ae2cb49f4f465d91cc2b3', dirty=True), path_in_vcs='vortex-file')
    license_raw = (ROOT/'vendor/vortex-layout/LICENSE').read_bytes()
    assert digest(license_raw) == LICENSE_SHA
    assert b'Apache License' in license_raw and b'Version 2.0, January 2004' in license_raw
    for name, raw in files.items():
        if name.endswith('.rs'):
            assert not re.search(rb'\binclude(?:_str|_bytes)?!\s*\(', raw), name
    baseline = json.loads((OUT/'native-file-metadata-baseline-570b.json').read_text())
    baseline_log = (OUT/'native-file-metadata-baseline-570b.log').read_bytes()
    assert baseline['returncode'] == 101 and baseline['process_group_drained'] and baseline['direct_child_reaped']
    assert digest(baseline_log) == baseline['log_sha256']
    names = re.findall(rb'^test native_provider_memory::file_metadata_tests::(\w+) \.\.\. FAILED$', baseline_log, re.M)
    assert len(names) == 3
    source = ROOT/'shardloom-vortex/src/native_provider_file_metadata_tests.rs'
    preserved = OUT/'native-file-metadata-baseline-570b.rs'
    if not preserved.exists():
        preserved.open('xb').write(source.read_bytes())
    assert source.read_bytes() == preserved.read_bytes()
    report = dict(schema_version='shardloom.native_file_provider_provenance_review.v1',
        status='passed', archive=identity(ARCHIVE), packet=identity(PACKET),
        lockfile=identity(ROOT/'Cargo.lock'), members=inventory, member_count=33,
        license=identity(ROOT/'vendor/vortex-layout/LICENSE'), vcs_info=vcs,
        baseline_receipt=identity(OUT/'native-file-metadata-baseline-570b.json'),
        baseline_log=identity(OUT/'native-file-metadata-baseline-570b.log'),
        baseline_source=identity(preserved), reproduced_regressions=[n.decode() for n in names],
        source_of_truth='Published registry archive; dirty VCS revision is not an identical substitute.',
        excerpt_corrections=excerpt_corrections,
        helper=identity(__file__), copied=args.vendor)
    if args.vendor:
        destination = ROOT/'vendor/vortex-file'
        destination.mkdir(exist_ok=False)
        for name, raw in files.items():
            if name == 'Cargo.lock':
                continue
            target = destination/name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.open('xb').write(raw)
            assert target.read_bytes() == raw
        (destination/'LICENSE').open('xb').write(license_raw)
        provenance = dict(provider='vortex-file', version='0.85.0', license='Apache-2.0',
            registry_archive_sha256=EXPECTED, registry_archive_file_count=33,
            registry_archive_uncompressed_bytes=499083,
            original_files_sha256={name:digest(raw) for name,raw in files.items()},
            vcs_info=vcs,
            source_of_truth='Published 0.85.0 registry archive. Its dirty VCS marker means the recorded revision is not an identical source substitute. Original Cargo.lock is recorded but omitted; workspace Cargo.lock controls resolution.',
            license_url='https://raw.githubusercontent.com/vortex-data/vortex/afb005379dd9a1b7dc7ae2cb49f4f465d91cc2b3/LICENSE',
            license_sha256=LICENSE_SHA,
            local_changes='Pending file-metadata allocator correction; source initially copied unchanged except omitted crate-local lockfile and added license/provenance. Update this field before acceptance.')
        (destination/'upstream-provenance.json').open('x').write(json.dumps(provenance, indent=2)+'\n')
    report_path = OUT/('native-file-provider-vendoring-571.json' if args.vendor else 'native-file-provider-provenance-primary-review-571.json')
    report_path.open('x').write(json.dumps(report, indent=2)+'\n')
    print(json.dumps(dict(status='passed', members=33, baseline_regressions=3, copied=args.vendor, report=str(report_path))))


if __name__ == '__main__':
    main()
