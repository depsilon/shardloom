"""Build frozen file-metadata release surfaces and execute complete local acceptance."""
import json
from pathlib import Path
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT
from run_query_timing_runtime_461 import guarded
from run_file_metadata_acceptance_573 import unchanged, prerequisites

PYTHON = Path('/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3')
ACCEPTANCE = OUT/'run_file_metadata_acceptance_573.py'


def stage(name, timeout, command):
    unchanged()
    print(json.dumps(dict(stage=name, status='starting')), flush=True)
    guarded(name, timeout, command)
    unchanged()
    print(json.dumps(dict(stage=name, status='passed')), flush=True)


def main():
    assert Path(sys.executable) == PYTHON
    prerequisites()
    stage('native-final-cli-release-build-filemetadata573', 2100,
        ['cargo', 'build', '--offline', '--locked', '--release', '-p', 'shardloom-cli',
         '--features', 'release-user-surfaces', '--message-format=json-render-diagnostics'])
    stage('native-final-python-release-build-filemetadata573', 2100,
        [PYTHON, '-B', ROOT/'scripts/build_native_python.py', '--release', '--offline',
         '--output-dir', OUT/'file-metadata-native-binding-573'])
    stage('file-metadata-freeze-native-573', 180,
        [PYTHON, '-B', OUT/'freeze_native_release_298.py', '--run-id', 'filemetadata573'])
    stage('file-metadata-declarations-573', 180, [PYTHON, '-B', ACCEPTANCE, 'declare'])
    stage('file-metadata-direct-573', 1800,
        [OUT/'selected-view-python-468/bin/python', '-B', ACCEPTANCE, 'direct'])
    print(json.dumps(dict(stage='public', status='starting')), flush=True)
    subprocess.run([str(PYTHON), '-B', str(ACCEPTANCE), 'public'], cwd=ROOT, check=True)
    unchanged()
    stage('file-metadata-public-inspection-573', 600,
        [PYTHON, '-B', OUT/'verify_file_metadata_public_573.py'])
    print(json.dumps(dict(status='passed', full43_pending=True)), flush=True)


if __name__ == '__main__':
    main()
