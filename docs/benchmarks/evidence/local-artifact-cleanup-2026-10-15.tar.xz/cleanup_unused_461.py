"""Retire exact superseded UAT outputs, duplicate downloads and old wheel environments."""
import datetime as dt
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import time

OUT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
UAT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
sys.path[:0] = [str(ROOT / 'scripts'), '/Users/dylan/LocalData/shardloom/release-0.3.3-20260930']
from local_uat_storage import require_local_path
from release_validation_guard import WorkloadGuard

RECEIPT = OUT / 'cleanup-unused-461.json'
MEMBERS = OUT / 'cleanup-unused-461-members.json.gz'
assert not RECEIPT.exists() and not MEMBERS.exists()
started = time.monotonic()


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 << 20), b''):
            value.update(block)
    return value.hexdigest()


def metadata(path):
    value = path.lstat()
    return dict(device=value.st_dev, inode=value.st_ino, size_bytes=value.st_size,
                allocated_bytes=value.st_blocks * 512, mode=value.st_mode,
                mtime_ns=value.st_mtime_ns, ctime_ns=value.st_ctime_ns,
                links=value.st_nlink)


def resident_file(path):
    require_local_path(path, Path.home(), sys.platform)
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and not path.is_symlink(), path
    assert not (info.st_flags & getattr(stat, 'SF_DATALESS', 0x40000000)), path
    assert info.st_blocks * 512 >= info.st_size, path
    return metadata(path)


def closed(path, *, directory=False):
    command = ['/usr/sbin/lsof', '-nP', '-Fpn']
    command += ['+D', str(path)] if directory else ['--', str(path)]
    result = subprocess.run(command, text=True, capture_output=True, timeout=30)
    assert result.returncode == 1 and not result.stdout.strip() and not result.stderr.strip(), (
        'open handle or unproved absence', str(path), result.returncode,
        result.stdout[:500], result.stderr[:500])
    return dict(command=command, returncode=result.returncode, open_handles=False)


def tree(path):
    require_local_path(path, Path.home(), sys.platform)
    assert path.is_dir() and not path.is_symlink()
    result = {'.': metadata(path)}
    for base, directories, files in os.walk(path, followlinks=False):
        for name in sorted(directories + files):
            item = Path(base) / name
            info = metadata(item)
            assert (stat.S_ISREG(info['mode']) or stat.S_ISDIR(info['mode']) or
                    stat.S_ISLNK(info['mode'])), item
            if stat.S_ISLNK(info['mode']):
                info['symlink_target'] = os.readlink(item)
            result[str(item.relative_to(path))] = info
    return result


def persist():
    temporary = RECEIPT.with_suffix('.json.pending')
    temporary.write_text(json.dumps(report, indent=2) + '\n')
    temporary.replace(RECEIPT)


results_path = OUT / 'fresh-timed-uat-461/timed-native-fresh-uat-1-results.json'
results = read(results_path)
assert results['status'] == 'passed_local_fresh_uat'
assert results['queries']['complete_runs'] == 43 and results['modular']['cohorts'] == 18
new_target = UAT / 'vortex/timed-native-461-a1.vortex'
new_identity = results['artifact_identities'][str(new_target)]
observed = resident_file(new_target)
assert all(observed[key] == value for key, value in new_identity['generation'].items())
assert not (UAT / '.ingest-uat.lock').exists()
workload = WorkloadGuard()
workload.check()
protected = [UAT / 'sources/hits.parquet', UAT / 'vortex/persisted-native-343-a1.vortex', new_target]
protected_generations = {str(path): resident_file(path) for path in protected}
report = dict(status='verifying', started_at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
    user_authorization='October 15 request to clean unused artifacts after the revised full UAT',
    fresh_uat_results=str(results_path), fresh_uat_results_sha256=sha(results_path),
    retained_dataset_generations=protected_generations,
    retained_new_output_sha256=new_identity['sha256'],
    free_bytes_before=shutil.disk_usage(OUT).free, candidates=[], removed=[],
    storage_limits_changed=False, compiler_cache_removed=False,
    symlink_targets_followed=False, unrelated_files_changed=False)
members = {}
retained_hashes = {}
persist()
try:
    provenance = read(OUT / 'cleanup-provenance-461.json')
    assert len(provenance['payloads']) == 2
    expected_payloads = {UAT / 'vortex/stream-native-389-a1.vortex', UAT / 'vortex/unpaced-native-435-a1.vortex'}
    assert {Path(item['path']) for item in provenance['payloads']} == expected_payloads
    for item in provenance['payloads']:
        path = Path(item['path'])
        receipt_path = Path(item['acceptance']['receipt'])
        assert sha(receipt_path) == item['acceptance']['receipt_sha256']
        receipt = read(receipt_path)
        assert receipt['status'] == 'passed_local_fresh_uat'
        identity = receipt['artifact_identities'][str(path)]
        assert identity['sha256'] == item['receipt_payload_sha256']
        before = resident_file(path)
        assert before['size_bytes'] == identity['generation']['size_bytes'] == 15713610513
        print('Verifying superseded output ' + path.name, flush=True)
        digest = sha(path)
        assert digest == identity['sha256'] and metadata(path) == before
        report['candidates'].append(dict(path=str(path), kind='superseded_generated_vortex',
            generation=before, sha256=digest, acceptance_receipt=str(receipt_path),
            acceptance_receipt_sha256=sha(receipt_path), replacement=str(new_target),
            replacement_receipt=str(results_path), handle_check=closed(path)))
        retained_hashes[str(receipt_path)] = sha(receipt_path)
    canonical = OUT / 'release-v0.6.0/release-060-assets-1/shardloom-936313473fed-source.tar.gz'
    canonical_generation = resident_file(canonical)
    canonical_hash = sha(canonical)
    assert metadata(canonical) == canonical_generation
    retained_hashes[str(canonical)] = canonical_hash
    for relative in [
        'release-v0.6.0/release-060-assets-1/github-prerelease-assets/shardloom-936313473fed-source.tar.gz',
        'release-v0.6.0/github-package-proof-v0.6.0-936313473fed/downloads/shardloom-936313473fed-source.tar.gz',
    ]:
        path = OUT / relative
        before = resident_file(path)
        assert before['size_bytes'] == canonical_generation['size_bytes']
        digest = sha(path)
        assert digest == canonical_hash and metadata(path) == before
        report['candidates'].append(dict(path=str(path), kind='identical_release_archive_copy',
            generation=before, sha256=digest, retained_identical_copy=str(canonical),
            handle_check=closed(path)))
    environments = read(OUT / 'cleanup-environments-461.json')['proof_roots']
    expected_names = {'native-wheel-proof-' + value for value in ('320','343','361','367b','374b','376')}
    assert {item['id'] for item in environments} == expected_names
    for item in environments:
        root = OUT / item['id']
        assert root == Path(item['root'])
        proof_path = root / 'report.json'
        proof = read(proof_path)
        integration_path = root / 'integration.json'
        integration = read(integration_path)
        assert proof['status'] == proof['stage']['status'] == proof['integrity']['status'] == 'passed'
        assert integration == proof['integration'] == item['integration']
        assert integration['status'] == 'passed' and integration['tests'] > 0
        assert integration['failures'] == integration['errors'] == integration['skipped'] == 0
        assert all(step['returncode'] == 0 for step in proof['steps'])
        wheel = Path(proof['integrity']['wheel'])
        assert wheel == Path(item['wheel']['path']) and wheel.parent == root / 'dist'
        assert sha(wheel) == proof['integrity']['wheel_sha256'] == item['wheel']['sha256']
        retained_hashes[str(wheel)] = item['wheel']['sha256']
        for path in (proof_path, integration_path):
            retained_hashes[str(path)] = sha(path)
        for subdir in ('package', 'venv'):
            path = root / subdir
            assert str(path) == item[subdir + '_root']
            inventory = tree(path)
            members[str(path)] = inventory
            regular = [entry for entry in inventory.values() if stat.S_ISREG(entry['mode'])]
            prior = item[subdir + '_inventory']
            assert len(regular) == prior['regular_files']
            assert sum(entry['size_bytes'] for entry in regular) == prior['logical_bytes']
            report['candidates'].append(dict(path=str(path), kind='completed_temporary_wheel_' + subdir,
                generation=metadata(path), regular_files=len(regular),
                regular_file_bytes=sum(entry['size_bytes'] for entry in regular),
                regular_allocated_bytes=sum(entry['allocated_bytes'] for entry in regular),
                retained_wheel=str(wheel), retained_wheel_sha256=item['wheel']['sha256'],
                retained_proof=str(proof_path), retained_proof_sha256=sha(proof_path),
                reproduction='Recreate the isolated package environment using the retained wheel and recorded install commands.',
                handle_check=closed(path, directory=True)))
    with MEMBERS.open('xb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as stream:
            stream.write(json.dumps(members, sort_keys=True).encode())
    assert json.loads(gzip.decompress(MEMBERS.read_bytes())) == members
    report.update(status='verified_before_removal', tree_metadata_manifest=str(MEMBERS),
                  tree_metadata_manifest_sha256=sha(MEMBERS), retained_hashes=retained_hashes)
    persist()
    for item in report['candidates']:
        workload.check()
        path = Path(item['path'])
        assert not path.is_symlink() and metadata(path) == item['generation']
        is_directory = path.is_dir()
        closed(path, directory=is_directory)
        if is_directory:
            assert tree(path) == members[str(path)]
            shutil.rmtree(path)
        else:
            path.unlink()
        assert not path.exists() and not path.is_symlink()
        report['removed'].append(item['path'])
        persist()
    assert len(report['removed']) == len(report['candidates']) == 16
    for path, before in protected_generations.items():
        assert resident_file(Path(path)) == before
    for path, digest in retained_hashes.items():
        assert sha(path) == digest
    workload.check()
    report.update(status='passed', free_bytes_after=shutil.disk_usage(OUT).free,
                  completed_at_utc=dt.datetime.now(dt.timezone.utc).isoformat())
    report['observed_free_bytes_increase'] = report['free_bytes_after'] - report['free_bytes_before']
except BaseException as error:
    report.update(status='failed',error=type(error).__name__+': '+str(error),
                  free_bytes_after=shutil.disk_usage(OUT).free)
    raise
finally:
    report['wall_seconds'] = time.monotonic() - started
    persist()
    print(json.dumps({key:report.get(key) for key in ('status','free_bytes_before','free_bytes_after',
        'observed_free_bytes_increase','wall_seconds','error')}),flush=True)
