"""Freeze exact-source regression and gate evidence for native owner transfer."""
import ast
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'docs/benchmarks/evidence'
STEM = 'native-python-cross-client-2026-10-11'

def digest(value):
    return hashlib.sha256(value).hexdigest()

def frozen_file(path):
    value = path.read_bytes()
    return {'bytes': len(value), 'sha256': digest(value)}

inventory = json.loads((OUT / 'native-cross-client-source-and-receipt-inventory-310.json').read_text())
expected = inventory['source_path_scope']['current_source_sha256']
current = {name: digest((ROOT / name).read_bytes()) for name in expected}
assert current == expected and len(current) == 1321
built = json.loads((OUT / 'native-cross-client-source-inventory-309.json').read_text())['current_source_sha256']
assert set(built) == set(current)
assert [name for name in current if built[name] != current[name]] == ['python/tests/test_native_binding.py']
baseline = json.loads((OUT / 'native-release-source-305.json').read_text())['source_sha256']
changed = {name: {'previous_sha256': old, 'current_sha256': current[name]}
           for name, old in baseline.items() if current[name] != old}
added = {name: current[name] for name in current.keys() - baseline.keys()}
assert len(changed) == 11 and len(added) == 2
assert all(current[name] == baseline[name] for name in baseline
           if name.startswith('vendor/') or name.endswith(('Cargo.toml', 'Cargo.lock')))
library = OUT / 'native-binding-debug-309b/_native.abi3.so'
library_identity = frozen_file(library)
assert library_identity == {'bytes': 357370400,
                           'sha256': 'f3dada595b092d07f7cd91631b7b61201da86b1852adc59249e6fbaf5b2730cf'}
expected_receipts = {
    'native-cross-client-red-309': 'failed',
    'native-cross-client-rust-309': 'passed',
    'native-cross-client-binding-build-309': 'passed',
    'native-cross-client-green-309': 'passed',
    'native-cross-client-callback-red-309': 'failed',
    'native-cross-client-callback-green-309': 'passed',
    'native-cross-client-clippy-309': 'failed',
    'native-cross-client-clippy-309b': 'passed',
    'native-cross-client-format-309': 'passed',
    'native-cross-client-format-final-309': 'passed',
    'native-cross-client-format-check-309': 'passed',
    'native-cross-client-binding-build-309b': 'passed',
    'native-cross-client-full-python-309': 'failed',
    'native-cross-client-full-python-310': 'passed',
    'native-cross-client-native-vortex-310': 'passed',
    'native-cross-client-default-clippy-310': 'passed',
    'native-cross-client-default-tests-310': 'passed',
}
members = {}
checks = []
for name, status in expected_receipts.items():
    receipt_path = OUT / f'{name}.json'
    receipt = json.loads(receipt_path.read_text())
    log = (OUT / f'{name}.log').read_bytes()
    assert receipt['status'] == status and receipt['process_group_drained']
    assert receipt['direct_child_reaped'] and not receipt.get('timed_out')
    assert receipt['log_sha256'] == digest(log)
    assert (receipt['returncode'] == 0) == (status == 'passed')
    rust = re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
    counts = {'summaries': len(rust), 'passed': sum(int(row[0]) for row in rust),
              'failed': sum(int(row[1]) for row in rust), 'ignored': sum(int(row[2]) for row in rust)} if rust else None
    checks.append({'name': name, 'receipt': receipt, 'rust_test_counts': counts})
    members[f'checks/{name}.json'] = receipt_path.read_bytes()
    members[f'checks/{name}.log'] = log
python_log = members['checks/native-cross-client-full-python-310.log']
assert b'Ran 746 tests' in python_log and b'\nOK\n' in python_log and b'skipped=' not in python_log
native_tests = sum(isinstance(node, ast.FunctionDef) and node.name.startswith('test_')
                   for path in (ROOT / 'python/tests').glob('test_native*binding.py')
                   for node in ast.walk(ast.parse(path.read_text())))
assert native_tests == 75
for name in ('native-cross-client-source-inventory-309.json',
             'native-cross-client-source-and-receipt-inventory-310.json',
             'native-array-copy-api-inventory-309.json'):
    members[f'inventories/{name}'] = (OUT / name).read_bytes()
for name in sorted(changed.keys() | added.keys()):
    members[f'sources/{name}'] = (ROOT / name).read_bytes()
members['driver/package_native_cross_client_310.py'] = Path(__file__).read_bytes()
members['source-sha256.json'] = (json.dumps(current, indent=2) + '\n').encode()
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
archive = EVIDENCE / f'{STEM}.tar.xz'
index = EVIDENCE / f'{STEM}.json'
assert not archive.exists() and not index.exists()
with tarfile.open(archive, 'w:xz') as stream:
    for name, data in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        stream.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:xz') as stream:
    assert set(stream.getnames()) == set(members)
    for item in stream:
        assert item.isfile() and stream.extractfile(item).read() == members[item.name]
report = {
    'status': 'passed_local_correction',
    'parent_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'review_comment_id': 4242144612,
    'behavior': 'Native sources from different clients transfer under receiving admission; same-owner sources share ownership and prepared reuse retains transferred input.',
    'provider_decision': 'Reuse the existing bounded native payload copier and compact generated-range provider. No Arrow or Python-row bridge, source-session execution or new resource pool.',
    'representation_boundary': 'Foreign native arrays may materialize into charged native buffers; columnar copy counts include value, offset and validity buffers. Cross-client transfers are not claimed as zero-copy or encoding-preserving.',
    'proof_scope': 'Cross-client complete SQL/typed results, resource-policy ceilings, denial/cancellation cleanup, escaped child credits, source close, busy producer, rich native types, empty input and compact large/extreme ranges.',
    'source_baseline': 'native-release-source-305.json in native-python-integration-corrections-2026-10-11.tar.xz',
    'selected_source_count': len(current),
    'unchanged_baseline_source_count': len(baseline) - len(changed),
    'changed_selected_sources': changed,
    'new_selected_sources': added,
    'change_since_final_native_build_source_inventory': 'Only python/tests/test_native_binding.py changed; all Rust/provider/dependency and Python implementation hashes match inventory 309.',
    'full_source_sha256_member': 'source-sha256.json',
    'library': {'filename': library.name, 'profile': 'debug', **library_identity},
    'python_test_count': 746,
    'native_integration_test_count': native_tests,
    'check_interpretation': {
        'red-309': 'Original extension reproduces foreign-owner composition failures and NativeSource import failure. The initial resource test also had an incorrect uninitialized-session expectation and a nonexistent exception name; those are test defects, not added production defects.',
        'callback-red-309': 'Original extension rejects completed-result import while the source session has an active stream because it reenters the busy producer for Arrow export.',
        'clippy-309': 'Initial lint run identifies function length and a potentially wrapping test cast. A helper and checked test conversion correct both; the next native workspace lint passes.',
        'full-python-309': 'The final resource-policy test expected a refusal at collection, but the existing public API correctly refuses the incompatible composition earlier. Only the test is corrected.',
        'full-python-310': 'All 746 Python tests pass against the exact final debug extension, including 75 native methods without skips.',
        'prior-timing-evidence': 'Earlier paired Python, public workflow and Full43 observations retain their original source/executable identities; no new speedup is inferred from this correction.',
    },
    'checks': checks,
    'archive': {'filename': archive.name, **frozen_file(archive), 'member_count': len(members),
                'all_members_reopened_and_verified': True,
                'members': {name: {'bytes': len(value), 'sha256': digest(value)} for name, value in sorted(members.items())}},
    'hosted_final_head_acceptance': 'pending',
    'performance_claim': None,
}
index.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'index': str(index), 'index_identity': frozen_file(index),
                  'archive': {k: v for k, v in report['archive'].items() if k != 'members'},
                  'rust_counts': {entry['name']: entry['rust_test_counts'] for entry in checks if entry['rust_test_counts']}}))
