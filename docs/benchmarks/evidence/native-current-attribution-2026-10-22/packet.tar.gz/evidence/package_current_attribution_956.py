#!/usr/bin/env python3
"""Package the completed diagnostic without changing its original bytes."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

ROOT = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022')
REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
DEST = ROOT / 'current-attribution-evidence-956.tar.gz'
assert not DEST.exists(), 'preserve existing packet'
assert shutil.disk_usage(ROOT).free >= 12 * 1024**3
protocol = json.loads((ROOT / 'attribution-protocol-953.json').read_text())
review = json.loads((ROOT / 'current-attribution-review-956.json').read_text())
files = {}


def add(path, member):
    path = Path(path)
    if str(path) in files:
        assert files[str(path)]['member'] == member
        return
    raw = path.read_bytes()
    files[str(path)] = dict(original_path=str(path), member=member, bytes=len(raw),
                           sha256=hashlib.sha256(raw).hexdigest(), raw=raw)


for name in ['attribution-protocol-953.json', 'attribution-result-953.json',
             'current-attribution-review-956.json', 'stack-parser-verification-956.json',
             'review_current_attribution_956.py', 'stack-parser-verification-956.py',
             'verify_current_attribution_956.py', 'package_current_attribution_956.py']:
    add(ROOT / name, 'evidence/' + name)
for path in sorted((ROOT / 'attribution-cohort-953').iterdir()):
    if path.is_file():
        add(path, 'evidence/attribution-cohort-953/' + path.name)
for key in ['source', 'runtime', 'build', 'reference', 'oracle_acceptance', 'driver',
            'common_driver', 'helper', 'supervisor', 'workload_guard', 'original_scope',
            'preceding_diagnostic']:
    path = Path(protocol[key]['path'])
    add(path, 'evidence/provenance/' + path.name)
add(Path(protocol['queries']['path']), 'repo/benchmarks/clickbench/queries.sql')
for binding in review['source_bindings']:
    path = Path(binding['path'])
    add(path, 'repo/' + path.relative_to(REPO).as_posix())
for name in ['native_workflow_protocol.py', 'clickbench_reference_packet.py',
             'run_clickbench_query_uat.py', 'local_uat_storage.py', 'query_timing_report.py']:
    add(REPO / 'scripts' / name, 'repo/scripts/' + name)
for path in sorted((REPO / 'python/src/shardloom').rglob('*.py')):
    add(path, 'repo/' + path.relative_to(REPO).as_posix())
assert len({entry['member'] for entry in files.values()}) == len(files)
assert sum(entry['bytes'] for entry in files.values()) <= 64 * 1024**2
manifest = dict(schema='shardloom.current_attribution_archive.v1',
                files=[{key: value for key, value in entry.items() if key != 'raw'}
                       for entry in sorted(files.values(), key=lambda item: item['member'])],
                external_payloads=[protocol['binary'], protocol['input']],
                replay='Run evidence/verify_current_attribution_956.py with this archive path. It requires Python only and opens a fresh temporary directory.',
                limits='The immutable binary and original large input are identified but not embedded or re-executed. Historical source/binary/input pre/post checks remain original producer evidence. Counter header paths are provenance; saved counters and raw stacks are replayed. External benchmark/reference engines are not invoked.')
with DEST.open('xb') as target:
    with gzip.GzipFile(filename='', mode='wb', fileobj=target, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            members = [(entry['member'], entry['raw']) for entry in files.values()]
            members.append(('manifest.json', (json.dumps(manifest, indent=2) + '\n').encode()))
            for name, raw in sorted(members):
                info = tarfile.TarInfo(name)
                info.size = len(raw)
                info.mode = 0o644
                archive.addfile(info, io.BytesIO(raw))
print(json.dumps(dict(path=str(DEST), bytes=DEST.stat().st_size,
                     sha256=hashlib.sha256(DEST.read_bytes()).hexdigest(),
                     members=len(files) + 1), indent=2))
