#!/usr/bin/env python3
"""Add the reviewed replay checks without rewriting the diagnostic evidence."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

ROOT = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022')
SOURCE = ROOT / 'current-attribution-evidence-956.tar.gz'
DEST = ROOT / 'current-attribution-evidence-958.tar.gz'
assert not DEST.exists(), 'preserve existing packet'
assert shutil.disk_usage(ROOT).free >= 12 * 1024**3


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


with tarfile.open(SOURCE, 'r:gz') as archive:
    members = {}
    for member in archive.getmembers():
        assert member.isfile() and member.name not in members
        members[member.name] = archive.extractfile(member).read()
manifest = json.loads(members.pop('manifest.json'))
assert set(members) == {entry['member'] for entry in manifest['files']}
for entry in manifest['files']:
    raw = members[entry['member']]
    assert len(raw) == entry['bytes'] and sha(raw) == entry['sha256']
for name in [
    'verify_current_attribution_957.py', 'test_current_attribution_957.py',
    'current-attribution-negative-controls-957.json',
    'current-attribution-replay-957.json', 'demangle-verification-957.json',
    'package_current_attribution_958.py',
]:
    path = ROOT / name
    raw = path.read_bytes()
    member = 'evidence/' + name
    assert member not in members
    members[member] = raw
    manifest['files'].append(dict(original_path=str(path), member=member,
                                  bytes=len(raw), sha256=sha(raw)))
manifest['files'].sort(key=lambda entry: entry['member'])
manifest['derived_from'] = dict(path=str(SOURCE), bytes=SOURCE.stat().st_size,
                                sha256=sha(SOURCE.read_bytes()),
                                original_members_preserved=True)
manifest['replay'] = 'Run evidence/verify_current_attribution_957.py with this archive path. It requires Python only and opens a fresh temporary directory.'
assert sum(map(len, members.values())) <= 64 * 1024**2
members['manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
with DEST.open('xb') as output:
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size = len(raw)
                info.mode = 0o644
                archive.addfile(info, io.BytesIO(raw))
print(json.dumps(dict(path=str(DEST), bytes=DEST.stat().st_size,
                     sha256=sha(DEST.read_bytes()), members=len(members)), indent=2))
