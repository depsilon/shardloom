"""One fixed diagnostic cohort after stack-visibility admission; no tuning."""
from __future__ import annotations

import json
from pathlib import Path
import re

import profile_current_runtime_943b as base

QUERY_SCOPES = {
    1: 'metadata-only count negative control',
    3: 'numeric SUM/COUNT/AVG compressed scan control',
    7: 'metadata MIN/MAX negative control',
    19: 'compound numeric/date-minute/UTF8 grouping and exact ordered selection',
    23: 'filtered UTF8 grouping, extrema and exact distinct state',
    29: 'transformed UTF8 dictionary grouping and ordered merge',
    34: 'raw UTF8 count grouping and ordered selection',
    41: 'selective mixed predicate with numeric/date grouping and offset control',
}


def main():
    out = base.OUT
    run_dir = out / 'attribution-cohort-944'
    assert not run_dir.exists()
    run_dir.mkdir()
    base.WorkloadGuard().check()
    before_storage = base.storage(out, run_dir, 64 * base.MIB)
    admission_path = out / 'stack-counter-pilot-admission-943b.json'
    admission = base.strict_json(admission_path.read_text())
    assert admission['status'] == 'admitted_for_bounded_attribution_only'
    build = base.strict_json(base.BUILD.read_text())
    frozen = base.source_freeze(build)
    assert frozen == base.strict_json((out / 'current-native-source-943b.json').read_text())
    pilot = base.strict_json((out / 'stack-counter-pilot-protocol-943b.json').read_text())
    binary = Path(build['binary'])
    source = Path(pilot['input']['path'])
    reference = Path(pilot['reference']['path'])
    queries = Path(pilot['queries']['path'])
    for p, expected in [(binary, pilot['binary']), (reference, pilot['reference']),
                        (queries, pilot['queries']), (base.HELPER, pilot['helper'])]:
        assert base.identity(p) == expected
    assert base.generation(source) == pilot['input']['generation']
    input_identity = base.identity(source)
    assert input_identity['sha256'] == pilot['input']['sha256']
    assert base.generation(source) == pilot['input']['generation']
    packet = base.load_reference_packet(reference, queries)
    protocol = dict(schema='shardloom.current_attribution_cohort.v1', status='frozen_before_execution',
        source=base.identity(out / 'current-native-source-943b.json'), build=base.identity(base.BUILD),
        binary=base.identity(binary), input=pilot['input'], queries=base.identity(queries),
        reference=base.identity(reference), reference_kind=packet['packet']['reference_kind'],
        driver=base.identity(__file__), helper=base.identity(base.HELPER),
        common_driver=base.identity(base.__file__), supervisor=base.identity(base.SUPERVISOR),
        workload_guard=pilot['workload_guard'], admission=base.identity(admission_path),
        query_scopes=QUERY_SCOPES, query_ids=list(QUERY_SCOPES),
        statements={str(i): packet['queries'][i - 1] for i in QUERY_SCOPES},
        calls_per_query=2, roles=['counter-control', 'sampled'], total_native_calls=16,
        no_repeats_within_role=True, memory_gb=24, requested_parallelism=12,
        purpose='Attribute current native execution and the caller/worker boundary before proposing region or PGO work.',
        question='Which current native callers/operators/types dominate active sampled stacks, and do they expose removable handoff/merge work or material dispatch overhead?',
        interpretation={
            'scope': 'A diagnostic workload set, not Full43, a speed comparison or PGO training.',
            'counters': 'Whole native process instructions/cycles only; do not distribute instruction totals among sampled functions.',
            'stacks': 'All-thread wall sampling includes idle time; parse ancestry, report exclusive leaves and separate blocked stacks. Do not sum nested inclusive counts as elapsed time.',
            'controls': 'Q1/Q7 metadata and Q3 numeric/Q41 selective controls distinguish route shape. Early-exit controls may have no usable stack; keep that absence explicit.',
            'native_sampling_admission': 'At least 100 main-thread observations with identifiable engine symbols in each of Q19/Q23/Q29/Q34. Failure leaves that lane unestablished; no automatic extra repetitions.',
            'candidate_admission': 'Current sampled hotspots are opportunity evidence only. A new candidate still needs source analysis, a distinct mechanism, an immutable protocol, exactness/resource tests, and its original prospective complete-operation/control gate.',
            'pgo_admission': 'Identify actual dispatch/code-layout costs at source sites before choosing training. Broad whole-process counts or a slow operator alone do not satisfy this prerequisite.',
        },
        supervision=pilot['sample_policy'], methodology=pilot['methodology'],
        cache_context='Full input hash before and after; no cache manipulation; uncontrolled OS page cache.',
        storage_before=before_storage, host=pilot['host'],
        expected_outputs='Complete retained native regression values; independent oracle remains separate.',
        runtime_changed=False, optional_scope_promoted=False, performance_claim=False)
    protocol_path = out / 'attribution-protocol-944.json'
    base.save(protocol_path, protocol)
    receipt = dict(status='running', protocol=base.identity(protocol_path), records=[])
    lock = out / '.ingest-uat.lock'
    lock.mkdir()
    try:
        print('Frozen diagnostic cohort: eight workloads, one counter control and one sampled call each.', flush=True)
        for query in QUERY_SCOPES:
            for sampled in (False, True):
                record = base.run_call(query, sampled, run_dir, binary, source,
                    packet['queries'][query - 1], packet['values'][query])
                receipt['records'].append(record)
                print(f'Validated Q{query:02d} ' + ('sampled' if sampled else 'counter-control'), flush=True)
        assert base.generation(source) == pilot['input']['generation']
        assert base.identity(source) == input_identity
        assert base.generation(source) == pilot['input']['generation']
        assert base.source_freeze(build) == frozen
        for path, expected in [(binary, protocol['binary']), (reference, protocol['reference']),
                               (queries, protocol['queries']), (base.HELPER, protocol['helper']),
                               (Path(__file__), protocol['driver']), (Path(base.__file__), protocol['common_driver'])]:
            assert base.identity(path) == expected
        captured = {}
        for query in QUERY_SCOPES:
            path = run_dir / f'q{query:02d}-sampled.sample.txt'
            text = path.read_text() if path.exists() else ''
            graph = text.split('Call graph:', 1)[1].split('Total number in stack', 1)[0] if 'Call graph:' in text else ''
            headers = re.findall(r'^\s*\d+ Thread_\d+.*$', graph, re.M)
            count = int(headers[0].strip().split()[0]) if headers else 0
            captured[str(query)] = dict(main_thread_observations=count, thread_count=len(headers),
                engine_symbols='shardloom_vortex' in graph,
                sample_file=base.identity(path) if path.exists() else None)
        receipt.update(status='passed', complete_values_checks=len(receipt['records']),
            sample_capture=captured, input_hash_before_after=True, source_and_binary_unchanged=True,
            attribution_lane_admission={str(q): captured[str(q)]['main_thread_observations'] >= 100
                                       and captured[str(q)]['engine_symbols'] for q in (19, 23, 29, 34)},
            storage_after=base.storage(out, run_dir))
    except BaseException as error:
        receipt.update(status='failed', failure=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        lock.rmdir()
        receipt['uat_lock_released'] = not lock.exists()
        base.save(out / 'attribution-result-944.json', receipt)
    print('Diagnostic execution complete; source attribution and scope review follow.', flush=True)


if __name__ == '__main__':
    main()
