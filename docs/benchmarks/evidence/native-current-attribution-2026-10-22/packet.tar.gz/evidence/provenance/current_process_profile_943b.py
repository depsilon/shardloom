"""Diagnostic-only native process counters and sampled stacks; never Full43 timing."""
from __future__ import annotations

import argparse
import ctypes
import errno
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

SDK = Path('/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk')
HEADER = SDK / 'usr/include/sys/resource.h'
WAIT_HEADER = SDK / 'usr/include/sys/wait.h'
layout = re.search(r'struct rusage_info_v4 \{(.*?)\};', HEADER.read_text(), re.S)
assert layout is not None
COUNTERS = re.findall(r'uint64_t\s+(\w+);', layout[1])
assert len(COUNTERS) == 35 and COUNTERS[-6:] == [
    'ri_instructions', 'ri_cycles', 'ri_billed_energy', 'ri_serviced_energy',
    'ri_interval_max_phys_footprint', 'ri_runnable_time']
assert re.search(r'#define WEXITED\s+0x00000004', WAIT_HEADER.read_text())
assert re.search(r'#define WNOWAIT\s+0x00000020', WAIT_HEADER.read_text())


class Usage(ctypes.Structure):
    _fields_ = [('ri_uuid', ctypes.c_uint8 * 16)] + [(n, ctypes.c_uint64) for n in COUNTERS]


LIB = ctypes.CDLL('/usr/lib/libproc.dylib', use_errno=True)
LIB.proc_pid_rusage.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_void_p]
LIB.proc_pid_rusage.restype = ctypes.c_int
SYSTEM = ctypes.CDLL(None, use_errno=True)
SYSTEM.waitid.argtypes = [ctypes.c_int, ctypes.c_uint, ctypes.c_void_p, ctypes.c_int]
SYSTEM.waitid.restype = ctypes.c_int


def usage(pid):
    item = Usage()
    if LIB.proc_pid_rusage(pid, 4, ctypes.byref(item)) != 0:
        error = ctypes.get_errno()
        raise OSError(error, os.strerror(error))
    return {name: getattr(item, name) for name in COUNTERS}


def await_exit_without_reaping(pid):
    # sys/wait.h has P_ALL=0, P_PID=1. WNOWAIT keeps the child available for
    # process-lifetime counters before wait4 reaps it. Never poll Popen first.
    info = (ctypes.c_uint64 * 64)()
    while SYSTEM.waitid(1, pid, ctypes.byref(info), 0x4 | 0x20) != 0:
        error = ctypes.get_errno()
        if error == errno.EINTR:
            continue
        raise OSError(error, os.strerror(error))


def stop_child(child):
    if child is not None and child.poll() is None:
        child.terminate()
        try:
            child.wait(timeout=1)
        except subprocess.TimeoutExpired:
            child.kill()
            child.wait(timeout=1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--timing', type=Path, required=True)
    parser.add_argument('--pid-file', type=Path, required=True)
    parser.add_argument('--sample-prefix', type=Path, required=True)
    parser.add_argument('--sample', action='store_true')
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ['--'] else args.command
    assert command and not args.timing.exists() and not args.pid_file.exists()
    sample_path = args.sample_prefix.with_suffix('.sample.txt')
    sample_stdout = args.sample_prefix.with_suffix('.sample.stdout')
    sample_stderr = args.sample_prefix.with_suffix('.sample.stderr')
    assert not any(p.exists() for p in (sample_path, sample_stdout, sample_stderr))

    def interrupted(_signal, _frame):
        raise KeyboardInterrupt

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    record = dict(schema='shardloom.current_process_profile.v1', command=command,
        sample_requested=args.sample, counter_provenance=dict(
            rusage_flavor=4, struct_bytes=ctypes.sizeof(Usage),
            headers=[dict(path=str(p), bytes=p.stat().st_size,
                          sha256=hashlib.sha256(p.read_bytes()).hexdigest())
                     for p in (HEADER, WAIT_HEADER)]))
    child, sampler = None, None
    sample_out, sample_err = None, None
    code = 130
    try:
        started = time.perf_counter()
        # The existing run_command watchdog owns this process group and timeout.
        child = subprocess.Popen(command)
        record['pid'] = child.pid
        args.pid_file.write_text(str(child.pid))
        if args.sample:
            sample_out = sample_stdout.open('xb')
            sample_err = sample_stderr.open('xb')
            sample_command = ['/usr/bin/sample', str(child.pid), '30', '1',
                              '-file', str(sample_path)]
            sampler = subprocess.Popen(sample_command, stdout=sample_out, stderr=sample_err)
            record.update(sample_command=sample_command, sampler_pid=sampler.pid,
                          sampler_spawn_after_child_seconds=time.perf_counter() - started)
        await_exit_without_reaping(child.pid)
        record['seconds'] = time.perf_counter() - started
        record['darwin_rusage_v4'] = usage(child.pid)
        pid, status, native = os.wait4(child.pid, 0)
        assert pid == child.pid
        code = os.waitstatus_to_exitcode(status)
        child.returncode = code
        record.update(peak_rss_bytes=int(native.ru_maxrss), user_cpu_seconds=native.ru_utime,
            system_cpu_seconds=native.ru_stime, minor_page_faults=native.ru_minflt,
            major_page_faults=native.ru_majflt, input_block_operations=native.ru_inblock,
            output_block_operations=native.ru_oublock, voluntary_context_switches=native.ru_nvcsw,
            involuntary_context_switches=native.ru_nivcsw, direct_child_reaped=True)
        if sampler is not None:
            record['sampler_returncode'] = sampler.wait(timeout=15)
            record['sample_file_present'] = sample_path.is_file()
    except BaseException as error:
        record['failure'] = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        # Two children stay in the outer group; each gets at most one second
        # before kill, leaving cleanup bounded within its three-second grace.
        stop_child(sampler)
        stop_child(child)
        for stream in (sample_out, sample_err):
            if stream is not None:
                stream.close()
        record.update(returncode=code, native_reaped=child is None or child.returncode is not None,
            sampler_reaped=sampler is None or sampler.returncode is not None,
            timing_boundary='native process creation through complete output and exit; counters and reap follow',
            counter_scope='whole native process, including startup, engine, output and exit; not per-function instructions',
            sample_scope='all-thread wall-clock stack observations while attached; idle stacks are not CPU work',
            os_counter_scope='native child wait4; block counts are not bytes; Darwin rusage kept distinct',
            diagnostic_scope='extra counters and optional sampling; excluded from routine Full43 acceptance')
        for p in (sample_path, sample_stdout, sample_stderr):
            if p.exists():
                data = p.read_bytes()
                record.setdefault('sampling_files', []).append(dict(path=str(p), bytes=len(data),
                    sha256=hashlib.sha256(data).hexdigest()))
        with args.timing.open('x') as stream:
            json.dump(record, stream, indent=2, allow_nan=False)
            stream.write('\n')
    return code if code >= 0 else 128 - code


if __name__ == '__main__':
    raise SystemExit(main())
