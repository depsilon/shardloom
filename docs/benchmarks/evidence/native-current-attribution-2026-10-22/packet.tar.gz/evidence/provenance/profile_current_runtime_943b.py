"""Freeze and run one finite source-current stack/counter diagnostic."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).parent
OLD = Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019')
BUILD = Path('/Users/dylan/LocalData/shardloom/release-v0.7.0/release-070-build-1.json')
HELPER = OUT / 'current_process_profile_943b.py'
PYTHON = Path('/opt/homebrew/opt/python@3.13/bin/python3.13')
sys.path[:0] = [str(ROOT / 'scripts'), str(OLD)]
from clickbench_reference_packet import load_reference_packet, canonical_values_sha256
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
from native_workflow_protocol import extract_result, public_workflow_command, report_fields, strict_json
from native_workload_guard_816 import WorkloadGuard
from query_timing_report import query_phase_timings
from run_clickbench_query_uat import equivalent

SUPERVISOR = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
spec = importlib.util.spec_from_file_location('bounded_profile_supervisor', SUPERVISOR)
supervisor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(supervisor)


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def generation(path):
    s = Path(path).stat()
    return dict(device=s.st_dev, inode=s.st_ino, size_bytes=s.st_size,
                mtime_ns=s.st_mtime_ns, ctime_ns=s.st_ctime_ns)


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def source_freeze(build):
    head = git('rev-parse', 'HEAD').decode().strip()
    # These are the complete compiled native and Python binding crates plus the
    # pinned provider tree and Cargo graph. The separate contract-test crate is
    # not linked into the release executable.
    roots = ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'shardloom-core',
             'shardloom-exec', 'shardloom-plan', 'shardloom-vortex', 'shardloom-cli',
             'shardloom-python', 'vendor']
    names = git('ls-files', '-z', '--', *roots).decode().split('\0')
    names = [n for n in names if n]
    changed = git('diff', '--name-only', build['source_commit'], head, '--', *roots).decode()
    assert not changed, changed
    assert not git('status', '--porcelain', '--', *roots), 'native source has uncommitted changes'
    records = [identity(ROOT / name) | dict(relative_path=name) for name in names]
    return dict(head=head, tree=git('rev-parse', 'HEAD^{tree}').decode().strip(),
        build_source_commit=build['source_commit'], compiled_source_equal=True,
        compared_roots=roots, source_files=records,
        excluded_test_crate='shardloom-contract-tests is not a release binary dependency')


def storage(root, logs, reserve=0):
    require_local_path(root, Path.home(), sys.platform)
    return check_budgets(root, root / 'reserved-artifact', logs,
        min_free_bytes=12 * GIB, reserve_bytes=reserve,
        max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB,
        max_run_log_bytes=192 * MIB, reserve_log_bytes=reserve)


def run_call(query_id, sampled, run_dir, binary, source, statement, expected):
    prefix = run_dir / (f'q{query_id:02d}-' + ('sampled' if sampled else 'counter-control'))
    timing = prefix.with_suffix('.timing.json')
    native = public_workflow_command(binary, statement, input_path=source,
        input_format='vortex', memory_gb=24, max_parallelism=12)
    command = [str(PYTHON), '-B', str(HELPER), '--timing', str(timing),
               '--pid-file', str(prefix.with_suffix('.pid')), '--sample-prefix', str(prefix)]
    if sampled:
        command.append('--sample')
    command.extend(['--', *native])
    record = dict(query=query_id, sample_requested=sampled, command=command,
                  statement=statement, status='running')
    workload = WorkloadGuard()
    workload.check()
    last_host_sample = 0.0

    def guard():
        nonlocal last_host_sample
        workload.check(record.get('pid'))
        storage(OUT, run_dir)
        # Bound each sampler artifact, in addition to the standard native log
        # limit and total active/retained evidence budgets.
        for suffix in ('.sample.txt', '.sample.stdout', '.sample.stderr'):
            p = prefix.with_suffix(suffix)
            if p.exists() and p.stat().st_size > 8 * MIB:
                raise ValueError('sample output exceeded 8 MiB')
        if time.monotonic() - last_host_sample >= 2:
            rows = subprocess.check_output(['ps', '-axo', 'pid=,ppid=,pgid=,pcpu=,rss=,comm='],
                text=True, timeout=10)
            processes = []
            for row in rows.splitlines():
                fields = row.split(None, 5)
                if len(fields) == 6 and (int(fields[0]) in workload.owned or float(fields[3]) >= 1):
                    processes.append(dict(pid=int(fields[0]), parent=int(fields[1]), group=int(fields[2]),
                        cpu_percent=float(fields[3]), rss_bytes=int(fields[4]) * 1024,
                        executable=Path(fields[5]).name))
            record.setdefault('host_samples', []).append(dict(load_average=list(os.getloadavg()),
                processes=processes))
            last_host_sample = time.monotonic()

    try:
        with prefix.with_suffix('.stdout.json').open('xb') as stdout, \
                prefix.with_suffix('.stderr.txt').open('xb') as stderr:
            code = supervisor.run(command, cwd=ROOT,
                env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), output=stdout,
                error_output=stderr, timeout=120, evidence=record, guard=guard)
        assert code == 0 and record['process_group_drained'] and record['direct_child_reaped']
        native_timing = strict_json(timing.read_text())
        assert native_timing['native_reaped'] and native_timing['sampler_reaped']
        assert native_timing['returncode'] == 0
        for name in ('ri_instructions', 'ri_cycles'):
            assert native_timing['darwin_rusage_v4'][name] > 0
        envelope = strict_json(prefix.with_suffix('.stdout.json').read_text())
        fields = report_fields(envelope)
        actual = extract_result(envelope)
        assert equivalent(actual, expected), 'complete values differ from retained reference'
        record.update(status='passed', complete_values_match=True, result_rows=len(actual),
            result_sha256=canonical_values_sha256(actual),
            timings=query_phase_timings(fields, native_timing['seconds'], allow_missing=False),
            native_timing=identity(timing), sample_file_present=native_timing.get('sample_file_present'),
            sampler_returncode=native_timing.get('sampler_returncode'))
        workload.check()
    except BaseException as error:
        record.update(status='failed', failure=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        record['files'] = [identity(p) for p in sorted(run_dir.glob(prefix.name + '.*')) if p.is_file()]
        save(prefix.with_suffix('.receipt.json'), record)
    return record


def main():
    stage = sys.argv[1] if len(sys.argv) == 2 else 'pilot'
    assert stage == 'pilot', 'additional cohorts require a separate prospective protocol'
    run_dir = OUT / 'stack-counter-pilot-943b'
    assert not run_dir.exists()
    run_dir.mkdir()
    storage(OUT, run_dir, 32 * MIB)
    workload = WorkloadGuard()
    workload.check()
    build = strict_json(BUILD.read_text())
    assert build['status'] == 'passed'
    binary = Path(build['binary'])
    assert identity(binary)['sha256'] == build['binary_sha256']
    old_plan = strict_json((OLD / 'format-strategy-full43-plan-908.json').read_text())
    source = Path(old_plan['input']['path'])
    assert generation(source) == old_plan['input']['generation']
    input_identity = identity(source)
    assert input_identity['sha256'] == old_plan['input']['sha256']
    assert generation(source) == old_plan['input']['generation']
    frozen = source_freeze(build)
    save(OUT / 'current-native-source-943b.json', frozen)
    queries = ROOT / 'benchmarks/clickbench/queries.sql'
    reference = Path(old_plan['reference']['path'])
    assert identity(reference) == old_plan['reference']
    packet = load_reference_packet(reference, queries)
    protocol = dict(schema='shardloom.current_attribution_pilot.v1', status='frozen_before_execution',
        source=identity(OUT / 'current-native-source-943b.json'), build=identity(BUILD), binary=identity(binary),
        input=input_identity | dict(generation=generation(source)), queries=identity(queries),
        reference=identity(reference), reference_kind=packet['packet']['reference_kind'],
        helper=identity(HELPER), driver=identity(__file__), supervisor=identity(SUPERVISOR),
        workload_guard=identity(OLD / 'native_workload_guard_816.py'),
        query_ids=[29], roles=['counter-control', 'sampled'], calls=2,
        memory_gb=24, requested_parallelism=12,
        question='Can current optimized production symbols support caller/operator stack attribution, while exact outputs and process counters remain valid?',
        admission='Only a captured nonempty native-engine stack with identifiable symbols admits a broader attribution cohort. Permission, attach or symbol failures remain explicit. This pilot cannot admit PGO or region code.',
        sample_policy='1 ms all-thread stack sampling, 30 s maximum, immediate PID attachment WITHOUT symbol preloading (-mayDie); native operation deadline 120 s; sampling has a 15 s post-exit drain deadline.',
        prior_pilot=identity(OUT / 'stack-counter-pilot-admission-943.json'),
        changed_supervision='Only remove -mayDie: the earlier zero-exit sampler produced an empty call graph. This is a diagnostic repair, not a runtime change.',
        counter_scope='Post-exit, pre-reap whole-process Darwin rusage v4; wait4 CPU/RSS kept distinct. Neither is operator-specific instruction attribution.',
        methodology='Sequential diagnostic calls on one binary and immutable input. No source edits, builds, agents or other task jobs during calls. Existing storage limits, exclusive lock, bounded process-group drain and complete native-reference validation apply.',
        limits=['Not a standard Full43 pass, comparative speed result, PGO trial or independent correctness oracle.',
                'Sampled stacks include blocked threads; later attribution must distinguish idle and active leaves.',
                'Input prehash warms data; cache state remains uncontrolled.',
                'Historical PGO and region rejections remain unchanged.'],
        host=dict(platform=platform.platform(), logical_cpus=os.cpu_count(),
                  physical_ram_bytes=int(subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.memsize'], text=True))))
    protocol_path = OUT / 'stack-counter-pilot-protocol-943b.json'
    save(protocol_path, protocol)
    receipt = dict(status='running', protocol=identity(protocol_path), records=[])
    lock = OUT / '.ingest-uat.lock'
    lock.mkdir()
    try:
        print('Current runtime and inputs frozen; starting the finite diagnostic pilot.', flush=True)
        for sampled in (False, True):
            receipt['records'].append(run_call(29, sampled, run_dir, binary, source,
                packet['queries'][28], packet['values'][29]))
            print('Diagnostic call validated: ' + ('sampled' if sampled else 'counter-control'), flush=True)
        assert generation(source) == protocol['input']['generation']
        assert identity(source) == input_identity
        assert generation(source) == protocol['input']['generation']
        assert source_freeze(build) == frozen
        assert identity(binary) == protocol['binary']
        assert identity(reference) == protocol['reference']
        assert identity(HELPER) == protocol['helper']
        assert identity(__file__) == protocol['driver']
        receipt.update(status='passed', input_hash_before_after=True,
                       source_and_binary_unchanged=True, storage_after=storage(OUT, run_dir))
    except BaseException as error:
        receipt.update(status='failed', failure=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        lock.rmdir()
        receipt['uat_lock_released'] = not lock.exists()
        save(OUT / 'stack-counter-pilot-result-943b.json', receipt)
    print('Pilot finished; sampled stacks require separate source review.', flush=True)


if __name__ == '__main__':
    main()
