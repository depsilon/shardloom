"""Refresh the finite attribution cohort on the independently checked runtime."""
from __future__ import annotations

import json
from pathlib import Path
import platform
import re
import shutil

import profile_current_runtime_943b as base
from local_uat_storage import accounted_bytes
from run_attribution_cohort_944 import QUERY_SCOPES


def main():
    out = base.OUT
    run_dir = out / 'attribution-cohort-953'
    assert not run_dir.exists(), 'preserve every earlier diagnostic observation'
    base.WorkloadGuard().check()
    runtime_path = out / 'native-runtime-950.json'
    runtime = base.strict_json(runtime_path.read_text())
    full43_path = out / 'full43-plan-950.json'
    full43 = base.strict_json(full43_path.read_text())
    assert runtime['status'] == 'passed'
    assert base.identity(runtime_path) == full43['runtime']
    assert base.identity(runtime['build']['path']) == runtime['build'] == full43['build']
    build = base.strict_json(Path(runtime['build']['path']).read_text())
    assert build['status'] == 'passed' and build['source_before'] == build['source_after']
    binary = Path(runtime['executable']['path'])
    assert base.identity(binary) == runtime['executable']
    frozen = base.source_freeze(runtime)
    for row in frozen['source_files']:
        if row['relative_path'] in build['source_after']:
            assert row['sha256'] == build['source_after'][row['relative_path']]
    source = Path(full43['input']['path'])
    assert base.generation(source) == full43['input_generation']
    assert base.identity(source) == full43['input']
    assert base.generation(source) == full43['input_generation']
    reference = Path(full43['reference']['path'])
    queries = Path(full43['queries']['path'])
    assert base.identity(reference) == full43['reference']
    assert base.identity(queries) == full43['queries']
    packet = base.load_reference_packet(reference, queries)
    assert packet['packet']['reference_kind'] == 'independent_reference'
    prior = base.strict_json((out / 'attribution-protocol-944.json').read_text())
    assert base.identity(base.HELPER) == prior['helper']
    assert base.identity(base.SUPERVISOR) == prior['supervisor']
    assert base.identity(out / 'profile_current_runtime_943b.py') == prior['common_driver']
    assert base.identity(base.OLD / 'native_workload_guard_816.py') == prior['workload_guard']
    run_dir.mkdir()
    source_path = out / 'current-native-source-953.json'
    base.save(source_path, frozen)
    storage_before = base.storage(out, run_dir, 64 * base.MIB)
    cache = Path('/Users/dylan/.cache/shardloom/cargo-target')
    cache_bytes = accounted_bytes(cache)
    assert cache_bytes + storage_before['workspace_bytes'] + 64 * base.MIB <= 100 * base.GIB
    protocol = dict(
        schema='shardloom.current_attribution_cohort.v1', status='frozen_before_execution',
        source=base.identity(source_path), runtime=base.identity(runtime_path),
        build=runtime['build'], binary=runtime['executable'], input=full43['input'],
        input_generation=full43['input_generation'], queries=full43['queries'],
        reference=full43['reference'], reference_kind='independent_reference',
        oracle_acceptance=full43['oracle_acceptance'],
        driver=base.identity(__file__), common_driver=base.identity(base.__file__),
        helper=base.identity(base.HELPER), supervisor=base.identity(base.SUPERVISOR),
        workload_guard=prior['workload_guard'], original_scope=base.identity(out / 'run_attribution_cohort_944.py'),
        preceding_diagnostic=base.identity(out / 'attribution-result-944.json'),
        query_scopes=QUERY_SCOPES, query_ids=list(QUERY_SCOPES),
        statements={str(i): packet['queries'][i - 1] for i in QUERY_SCOPES},
        calls_per_query=2, roles=['counter-control', 'sampled'], total_native_calls=16,
        no_repeats_within_role=True, memory_gb=24, requested_parallelism=12,
        purpose='Current-source region and dispatch prerequisite evidence after the integer/regex correction.',
        reason_for_refresh='The preceding diagnostic predates the corrected integer accumulation and regex dictionary paths; it cannot select a current mechanism or PGO corpus.',
        integration_order='Read-only diagnostic collection on the locally accepted runtime while the final hosted native-provider CI lane is pending. All three fresh installed native-wheel lanes have passed. PR integration and diagnostic review remain required before any new implementation or dependent experiment is admitted.',
        interpretation=prior['interpretation'],
        sampler_command_template=['/usr/bin/sample', '<native_pid>', '30', '1', '-file', '<new_sample_path>'],
        counter_scope='One post-exit, pre-reap whole-process Darwin rusage-v4 snapshot per native call; not per-site instructions.',
        stack_scope='All-thread wall sampling, including blocking. Report exclusive leaves with ancestry and keep idle observations separate; do not attribute process counters by stack percentages.',
        methodology='Sequential fixed cohort with source and input hashing before and after, no builds/tests/agents/packaging/cleanup during calls, no cache manipulation or artificial pacing. Not Full43, a speed comparison, or PGO training.',
        supervision_change='Use the preceding sampler and call supervisor unchanged. During calls only scan the bounded new output directory and check free space against preflight inventory plus maximum active outputs; perform broad inventory before and after.',
        storage_before=storage_before, cache_bytes_before=cache_bytes,
        host=dict(platform=platform.platform(), logical_cpus=base.os.cpu_count(),
                  physical_ram_bytes=int(base.subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.memsize'], text=True))),
        runtime_changed=False, optional_scope_promoted=False, performance_claim=False,
        failure_policy='Retain every call and stop on invalid output/process/resource evidence. Insufficient symbols leave that attribution lane unestablished; no automatic additional calls.')
    protocol_path = out / 'attribution-protocol-953.json'
    base.save(protocol_path, protocol)
    frozen_programs = [protocol[k] for k in ('driver', 'common_driver', 'helper', 'supervisor', 'workload_guard', 'original_scope')]
    broad_storage = base.storage

    def active_storage(root, logs, reserve=0):
        assert root == out and logs == run_dir and reserve == 0
        active_bytes = accounted_bytes(run_dir)
        free_bytes = shutil.disk_usage(out).free
        assert active_bytes <= 192 * base.MIB, 'active diagnostic log budget exceeded'
        assert storage_before['log_bytes'] + active_bytes <= 192 * base.MIB, 'retained diagnostic log budget exceeded'
        assert storage_before['workspace_bytes'] + cache_bytes + active_bytes + 4 * base.MIB <= 100 * base.GIB, 'workspace storage budget exceeded'
        assert free_bytes >= 12 * base.GIB, 'minimum free storage reached'
        return dict(active_run_bytes=active_bytes, free_bytes=free_bytes)

    receipt = dict(status='running', protocol=base.identity(protocol_path), records=[])
    lock = out / '.ingest-uat.lock'
    lock.mkdir()
    try:
        base.storage = active_storage
        print('Frozen corrected-runtime diagnostic: eight workloads, two distinct roles each.', flush=True)
        for query in QUERY_SCOPES:
            for sampled in (False, True):
                record = base.run_call(query, sampled, run_dir, binary, source,
                    packet['queries'][query - 1], packet['values'][query])
                receipt['records'].append(record)
                prefix = run_dir / (f'q{query:02d}-' + ('sampled' if sampled else 'counter-control'))
                fields = base.report_fields(base.strict_json(prefix.with_suffix('.stdout.json').read_text()))
                assert fields['fallback_attempted'] == 'false'
                assert fields['external_engine_invoked'] == 'false'
                print(f'Validated Q{query:02d} ' + ('sampled' if sampled else 'counter-control'), flush=True)
        base.storage = broad_storage
        assert base.generation(source) == full43['input_generation']
        assert base.identity(source) == full43['input']
        assert base.generation(source) == full43['input_generation']
        assert base.source_freeze(runtime) == frozen
        for ref in frozen_programs + [protocol['binary'], protocol['reference'], protocol['queries'], protocol['runtime'], protocol['build']]:
            assert base.identity(ref['path']) == ref
        captured = {}
        for query in QUERY_SCOPES:
            path = run_dir / f'q{query:02d}-sampled.sample.txt'
            text = path.read_text() if path.exists() else ''
            graph = text.split('Call graph:', 1)[1].split('Total number in stack', 1)[0] if 'Call graph:' in text else ''
            headers = re.findall(r'^\s*\d+ Thread_\d+.*$', graph, re.M)
            count = int(headers[0].strip().split()[0]) if headers else 0
            captured[str(query)] = dict(main_thread_observations=count, thread_count=len(headers),
                engine_symbols='shardloom_vortex' in graph,
                sample_file=base.identity(path) if path.exists() else None)
        storage_after = broad_storage(out, run_dir)
        cache_after = accounted_bytes(cache)
        assert storage_after['workspace_bytes'] + cache_after <= 100 * base.GIB
        assert cache_after == cache_bytes, 'unrelated compiler output changed during diagnostics'
        receipt.update(status='passed', complete_values_checks=len(receipt['records']),
            sample_capture=captured, input_hash_before_after=True, source_and_binary_unchanged=True,
            independent_reference=True, fallback_attempted=False, external_engine_invoked=False,
            attribution_lane_admission={str(q): captured[str(q)]['main_thread_observations'] >= 100
                                       and captured[str(q)]['engine_symbols'] for q in (19, 23, 29, 34)},
            storage_after=storage_after, cache_bytes_after=cache_after)
    except BaseException as error:
        receipt.update(status='failed', failure=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        base.storage = broad_storage
        lock.rmdir()
        receipt['uat_lock_released'] = not lock.exists()
        base.save(out / 'attribution-result-953.json', receipt)
    print('Corrected-runtime diagnostic complete; attribution review remains separate.', flush=True)


if __name__ == '__main__':
    main()
