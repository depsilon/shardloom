#!/usr/bin/env python3
"""Review already completed samples. This program never invokes the engine."""
import collections
import hashlib
import json
from pathlib import Path

ROOT = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022')
REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
SAMPLES = ROOT / 'attribution-cohort-953'


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read(name):
    return json.loads((ROOT / name).read_text())


def source(path, first, last, interpretation):
    absolute = REPO / path
    lines = absolute.read_text().splitlines()
    return dict(**identity(absolute), first_line=first, last_line=last,
                excerpt='\n'.join(lines[first - 1:last]), interpretation=interpretation)


def main():
    result = read('attribution-result-953.json')
    protocol = read('attribution-protocol-953.json')
    inventory = read('attribution-cohort-953/stack-inventory-954.json')
    independent = read('stack-parser-verification-956.json')
    assert result['status'] == 'passed', result['status']
    assert len(result['records']) == 16
    assert all(result['attribution_lane_admission'].values())
    assert independent['mismatch_count'] == 0
    assert independent['totals']['frames'] == 15209
    assert independent['totals']['exclusive_sum'] == independent['totals']['root_count_sum']
    for entry in independent['inputs']:
        assert identity(Path(entry['path']))['sha256'] == entry['sha256'], entry['path']
    calls = []
    for record in result['records']:
        assert record['status'] == 'passed' and record['complete_values_match']
        assert record['process_group_drained'] and record['direct_child_reaped']
        for member in record['files']:
            actual = identity(Path(member['path']))
            assert actual['sha256'] == member['sha256'] and actual['bytes'] == member['bytes']
        timing = json.loads(Path(record['native_timing']['path']).read_text())
        counters = timing['darwin_rusage_v4']
        assert counters['ri_instructions'] > 0 and counters['ri_cycles'] > 0
        calls.append(dict(query=record['query'], sampled=record['sample_requested'],
                          complete_values_match=True, result_rows=record['result_rows'],
                          native_timing=record['native_timing'],
                          engine_execution_seconds=record['timings']['engine_execution_seconds'],
                          whole_process_instructions=counters['ri_instructions'],
                          whole_process_cycles=counters['ri_cycles'],
                          counter_scope=timing['counter_scope']))
    lanes = []
    for sample in inventory['files']:
        assert identity(Path(sample['source_path']))['sha256'] == sample['source_sha256']
        query = int(sample['file'][1:3])
        threads = []
        for thread in sample['threads']:
            by_symbol = collections.Counter()
            by_line = {frame['line']: frame for frame in thread['frames']}
            for frame in thread['frames']:
                by_symbol[frame['demangled_function_symbol']] += frame['exclusive_count']
            def within(symbol, ancestor):
                total = 0
                for frame in thread['frames']:
                    if symbol not in frame['demangled_function_symbol']:
                        continue
                    current = frame
                    while current is not None:
                        if ancestor in current['demangled_function_symbol']:
                            total += frame['exclusive_count']
                            break
                        current = by_line.get(current['parent_line'])
                return total
            threads.append(dict(name=thread['thread_name'], suffix=thread['header_suffix'],
                                header_line=thread['header_line'], observations=thread['observation_count'],
                                main_thread='com.apple.main-thread' in thread['header_suffix'],
                                top_exclusive=[dict(symbol=s, observations=n) for s, n in by_symbol.most_common(12)],
                                zstd_exclusive_under_serial_aggregate=within('ZSTD_', 'update_compact_direct_from_chunk_profiled'),
                                numeric_value_exclusive=within('aggregate_direct_numeric_value', 'update_direct_from_chunk'),
                                numeric_kind_exclusive=within('numeric_input_is_integer', 'update_direct_from_chunk')))
        main_threads = [thread for thread in threads if thread['main_thread']]
        assert len(main_threads) <= 1
        if query in (19, 23, 29, 34):
            assert len(main_threads) == 1 and main_threads[0]['observations'] >= 100
        lanes.append(dict(query=query, raw=identity(Path(sample['source_path'])),
                          empty_graph=sample['empty_graph'], threads=threads))
    bindings = [
        source('shardloom-vortex/src/local_primitives.rs', 41845, 41859,
               'Q3 numeric-kind dispatch is executed in the per-row numeric measure loop. NativeNumeric calls its retained owner type check; materialized input also checks the individual value kind.'),
        source('shardloom-vortex/src/local_primitives.rs', 44579, 44675,
               'Q3 numeric value dispatch includes accessor variant selection, original-width owner access, validity/bounds and conversion. Its sample count is not exclusively dispatch instructions.'),
        source('shardloom-vortex/src/local_primitives/native_numeric_owner.rs', 20, 96,
               'The native owner retains PrimitiveArray and validity; batch dispatch and per-row type/value paths have distinct costs. No raw sample is apportioned into instruction counts.'),
        source('shardloom-vortex/src/local_primitives.rs', 33282, 33325,
               'Q23 constructs native accessors on the aggregate caller, then invokes unchanged aggregate updates. Source-order candidate selection precedes accessor construction.'),
        source('shardloom-vortex/src/local_primitives.rs', 41975, 42000,
               'Native accessor preparation visits each declared projected field and aggregates its actual representation-work evidence.'),
        source('shardloom-vortex/src/local_primitives/numeric_aggregate_sum.rs', 1, 73,
               'Integer input uses compensated accumulation with original F64 input conversion; floating input remains ordered. Neither mechanism authorizes arbitrary reassociation.'),
        source('vendor/vortex-layout/src/scan/repeated_scan.rs', 174, 195,
               'Native repeated execution registers tasks for exact selected ranges. Registration can request projection input before the future is polled.'),
        source('shardloom-vortex/src/local_primitives/aggregate_chunk_jobs.rs', 140, 206,
               'Existing bounded jobs allocate P-1 workers and retain the caller lane under the shared memory owner.'),
    ]
    out = dict(schema='shardloom.current_attribution_review.v1', status='reviewed_current_runtime',
               protocol=identity(ROOT / 'attribution-protocol-953.json'),
               result=identity(ROOT / 'attribution-result-953.json'),
               inventory=identity(SAMPLES / 'stack-inventory-954.json'),
               independent_tree_verification=identity(ROOT / 'stack-parser-verification-956.json'),
               reviewer=identity(Path(__file__)),
               source_binding=protocol['source'], binary=protocol['binary'], input=protocol['input'],
               complete_call_count=len(calls), calls=calls, lanes=lanes, source_bindings=bindings,
               scope='Diagnostic current-source cost attribution; not Full43, a performance comparison, or PGO training.',
               decisions={
                   'region_opportunity': 'Current-source evidence supports a prospective independently admitted region consumer. Serial numeric evaluation and serial native text preparation are separate candidate opportunities; no speed gain has been measured.',
                   'numeric_semantics': 'The first draft confines local scalar SUM/AVG to a checked exact-in-F64 bound. Large integer and floating SUM/AVG remain unchanged. Metadata-only count/extrema remain on their current route.',
                   'text_ownership': 'Text preparation is not admitted until preallocation, retained dictionary/array ownership and original consumer ordering are proved.',
                   'dispatch_signal': 'Q3 contains sampled per-row accessor/type dispatch sites in the current native numeric consumer. Value access also includes validity, bounds and conversion. This is a concrete source-level candidate for the later PGO intake, not proof of branch misprediction, instruction-cache stalls, or recoverable instruction counts.',
                   'pgo': 'Training remains unadmitted until the earlier region decisions settle and a representative training/held-out, fresh-build, package-correctness and break-even protocol is frozen on the resulting source.',
               },
               limits=[
                   'All-thread samples include blocked threads; only exclusive leaf residuals are aggregated, with ancestry retained.',
                   'Whole-process instruction/cycle snapshots include startup, engine, serialization and exit. No per-function instruction attribution is inferred.',
                   'Sampling can perturb execution. These paired roles are diagnostic observations, not a speed comparison or an overhead acceptance study.',
                   'Q1 exited before a usable sample; Q7 sample has an empty call graph. Neither absence establishes zero execution cost.',
                   'Q19, Q23, Q29 and Q34 meet the frozen >=100 main-thread observation condition; no additional diagnostic repetition was added.',
                   'The original pre-correction diagnostic remains preserved and cannot stand in for this corrected-runtime attribution.',
               ], fallback_attempted=False, external_engine_invoked=False,
               performance_claim=False, compiler_profile_promoted=False, runtime_changed=False)
    target = ROOT / 'current-attribution-review-956.json'
    assert not target.exists(), 'immutable review already exists'
    target.write_text(json.dumps(out, indent=2) + '\n')
    print(json.dumps({'review': identity(target), 'calls': len(calls), 'sample_files': len(lanes),
                      'tree_verification': independent['totals']}, indent=2))


if __name__ == '__main__':
    main()
