#!/usr/bin/env python3
"""Independent verification of stack-inventory-954 tree accounting.

Uses only raw sampled files and the inventory JSON as a comparison target. It does
not import or execute build_stack_inventory_954.py.
"""
import hashlib
import json
import re
from pathlib import Path

BASE = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022/attribution-cohort-953')
INVENTORY = BASE / 'stack-inventory-954.json'
PARSER = BASE / 'build_stack_inventory_954.py'
Q1_EVIDENCE = BASE.parent / 'attribution-result-953.json'
OUT = BASE.parent / 'stack-parser-verification-956.json'
HEADER = re.compile(r'^\s*(\d+)\s+(Thread_\S+)(.*)$')
FRAME = re.compile(r'(\d+)\s+(\S.*)$')
EXPECTED = [f'q{i:02d}-sampled.sample.txt' for i in (3, 7, 19, 23, 29, 34, 41)]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def derive(path):
    lines = path.read_text(encoding='utf-8').splitlines()
    start = next(i for i, s in enumerate(lines) if s == 'Call graph:')
    stop = next(i for i in range(start + 1, len(lines)) if lines[i].startswith('Total number in stack'))
    threads, frames, current = [], [], None
    for lineno in range(start + 1, stop):
        s = lines[lineno]
        if not s.strip():
            continue
        h = HEADER.match(s)
        if h:
            current = {'name': h.group(2), 'count': int(h.group(1)), 'frames': []}
            threads.append(current)
            continue
        m = FRAME.search(s)
        if not m or current is None:
            raise ValueError(f'{path.name}:{lineno+1}: malformed or orphan row: {s!r}')
        node = {'line': lineno + 1, 'count': int(m.group(1)), 'column': m.start(1), 'parent': None, 'depth': None}
        frames.append(node)
        current['frames'].append(node)
    # Reconstruct each thread independently using nearest previous frame at a shallower column.
    for thread in threads:
        ancestors = []
        for node in thread['frames']:
            while ancestors and ancestors[-1]['column'] >= node['column']:
                ancestors.pop()
            node['parent'] = ancestors[-1]['line'] if ancestors else None
            node['depth'] = ancestors[-1]['depth'] + 1 if ancestors else 0
            ancestors.append(node)
    direct = {n['line']: 0 for n in frames}
    for n in frames:
        if n['parent'] is not None:
            direct[n['parent']] += n['count']
    for n in frames:
        n['children'] = direct[n['line']]
        n['exclusive'] = n['count'] - n['children']
    roots = [n for n in frames if n['parent'] is None]
    return {'threads': threads, 'frames': frames, 'root_sum': sum(n['count'] for n in roots),
            'exclusive_sum': sum(n['exclusive'] for n in frames),
            'negative': [n['line'] for n in frames if n['exclusive'] < 0]}

def main():
    expected_inventory = json.loads(INVENTORY.read_text())
    inventory_by_name = {x['file']: x for x in expected_inventory['files']}
    samples = sorted(BASE.glob('q*-sampled.sample.txt'))
    mismatches, records = [], []
    if [p.name for p in samples] != EXPECTED:
        mismatches.append({'type': 'sample_file_set', 'expected': EXPECTED, 'actual': [p.name for p in samples]})
    for path in samples:
        raw = path.read_bytes()
        d = derive(path)
        prior = inventory_by_name.get(path.name)
        per_frame_mismatches = []
        if prior is None:
            mismatches.append({'type': 'inventory_missing_file', 'file': path.name})
        else:
            old_nodes = {n['line']: n for t in prior['threads'] for n in t['frames']}
            for n in d['frames']:
                o = old_nodes.get(n['line'])
                actual = {k: n[k] for k in ('count', 'parent', 'depth', 'children', 'exclusive')}
                if o is None:
                    per_frame_mismatches.append({'line': n['line'], 'expected': None, 'actual': actual})
                    continue
                prior_values = {'count': o['observation_count'], 'parent': o['parent_line'], 'depth': o['depth'],
                                'children': o['immediate_child_count_sum'], 'exclusive': o['exclusive_count']}
                if actual != prior_values:
                    per_frame_mismatches.append({'line': n['line'], 'expected': prior_values, 'actual': actual})
            if len(old_nodes) != len(d['frames']):
                per_frame_mismatches.append({'type': 'frame_count', 'expected': len(old_nodes), 'actual': len(d['frames'])})
            comparisons = {'thread_count': len(d['threads']), 'frame_count': len(d['frames']),
                           'empty_graph': not d['frames'], 'root_sum': d['root_sum'],
                           'exclusive_sum': d['exclusive_sum']}
            prior_comparisons = {'thread_count': prior['thread_count'], 'frame_count': prior['frame_count'],
                                 'empty_graph': prior['empty_graph'], 'root_sum': prior['root_thread_frame_count_sum'],
                                 'exclusive_sum': prior['exclusive_frame_count_sum']}
            if comparisons != prior_comparisons:
                per_frame_mismatches.append({'type': 'file_totals', 'expected': prior_comparisons, 'actual': comparisons})
        if d['negative']:
            per_frame_mismatches.append({'type': 'negative_exclusive', 'lines': d['negative']})
        if d['root_sum'] != d['exclusive_sum']:
            per_frame_mismatches.append({'type': 'root_exclusive_conservation', 'root': d['root_sum'], 'exclusive': d['exclusive_sum']})
        if per_frame_mismatches:
            mismatches.append({'type': 'per_file_mismatches', 'file': path.name, 'items': per_frame_mismatches})
        records.append({'file': path.name, 'sha256': sha(raw), 'bytes': len(raw), 'thread_headers': len(d['threads']),
                        'frames': len(d['frames']), 'empty_graph': not d['frames'], 'root_count_sum': d['root_sum'],
                        'exclusive_sum': d['exclusive_sum'], 'negative_exclusive_count': len(d['negative']),
                        'frame_level_comparisons': len(d['frames']), 'mismatches': len(per_frame_mismatches)})
    totals = {'sample_files': len(records), 'thread_headers': sum(x['thread_headers'] for x in records),
              'frames': sum(x['frames'] for x in records), 'empty_graph_files': sum(x['empty_graph'] for x in records),
              'negative_exclusive_count': sum(x['negative_exclusive_count'] for x in records),
              'root_count_sum': sum(x['root_count_sum'] for x in records),
              'exclusive_sum': sum(x['exclusive_sum'] for x in records)}
    if totals['root_count_sum'] != totals['exclusive_sum']:
        mismatches.append({'type': 'global_root_exclusive_conservation', 'totals': totals})
    q1_record = next(x for x in expected_inventory['missing_sample_files'] if x['file'] == 'q01-sampled.sample.txt')
    q1_actual_sha = sha(Q1_EVIDENCE.read_bytes()) if Q1_EVIDENCE.exists() else None
    q1 = {'sample_file': None, 'requested': q1_record['sample_requested'], 'evidence_path': str(Q1_EVIDENCE),
          'recorded_evidence_sha256': q1_record['evidence_sha256'], 'actual_evidence_sha256': q1_actual_sha,
          'hash_matches': q1_actual_sha == q1_record['evidence_sha256']}
    if not q1['hash_matches']:
        mismatches.append({'type': 'q1_negative_control_evidence_hash', 'recorded': q1_record['evidence_sha256'], 'actual': q1_actual_sha})
    result = {'status': 'COMPLETE' if not mismatches else 'NEEDS_REASONING',
              'method': 'Independent raw-text tree reconstruction; no import/execution of inventory parser. Frame depth/parent derived from raw count-column indentation within each thread; immediate-child sums and exclusive residuals recomputed and compared row-by-row by source line.',
              'inputs': [{'path': str(PARSER), 'sha256': sha(PARSER.read_bytes()), 'role': 'schema and algorithm inspected only'},
                         {'path': str(INVENTORY), 'sha256': sha(INVENTORY.read_bytes()), 'role': 'comparison target'},
                         *[{'path': str(BASE / x['file']), 'sha256': x['sha256'], 'role': 'raw sample independently recomputed'} for x in records],
                         {'path': str(Q1_EVIDENCE), 'sha256': q1_actual_sha, 'role': 'Q1 requested sample absence evidence'}],
              'commands': ['python /Users/dylan/LocalData/shardloom/native-prerequisites-20261022/stack-parser-verification-956.py',
                           'python -m json.tool /Users/dylan/LocalData/shardloom/native-prerequisites-20261022/stack-parser-verification-956.json'],
              'outcomes': {'python_verifier': 'PASS' if not mismatches else 'FAIL', 'json_syntax': 'validated after write'},
              'samples': records, 'q1_negative_control': q1, 'totals': totals,
              'mismatch_count': len(mismatches), 'mismatches': mismatches,
              'interpretation_limits': ['Q7 empty graph is recorded as zero observed threads/frames; this is not a cost measurement.',
                                        'Q1 sampled output is absent; its requested status and result evidence hash are retained as a negative control.',
                                        'No CPU percentages or operator instruction attribution are inferred.']}
    OUT.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'output': str(OUT), 'totals': totals,
                      'mismatch_count': len(mismatches), 'q1_hash_matches': q1['hash_matches']}, indent=2))
    return 0 if not mismatches else 2

if __name__ == '__main__':
    raise SystemExit(main())
