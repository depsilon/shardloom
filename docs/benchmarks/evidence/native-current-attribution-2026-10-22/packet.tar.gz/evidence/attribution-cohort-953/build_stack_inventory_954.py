import hashlib, json, re, subprocess
from pathlib import Path

BASE=Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022/attribution-cohort-953')
OUT=BASE/'stack-inventory-954.json'
FILES=sorted(BASE.glob('q*-sampled.sample.txt'))
EXPECTED_FILES=[
    'q03-sampled.sample.txt',
    'q07-sampled.sample.txt',
    'q19-sampled.sample.txt',
    'q23-sampled.sample.txt',
    'q29-sampled.sample.txt',
    'q34-sampled.sample.txt',
    'q41-sampled.sample.txt',
]
assert [path.name for path in FILES]==EXPECTED_FILES, [path.name for path in FILES]
MISSING_SAMPLE_FILES=[{'file':'q01-sampled.sample.txt','query':1,'evidence_path':'/Users/dylan/LocalData/shardloom/native-prerequisites-20261022/attribution-result-953.json','evidence_sha256':'ac84bba1bcaf155eb2f9bc9b2655c275258a6236455fe6d483ec8231f490f32d','sample_requested':True,'sample_file':None}]
HEADER=re.compile(r'^\s*(?P<count>\d+)\s+(?P<thread>Thread_\S+)(?P<rest>.*)$')
FRAME=re.compile(r'(?P<count>\d+)\s+(?P<frame>\S.*)$')

def sha(b): return hashlib.sha256(b).hexdigest()

all_frames=[]
file_records=[]
errors=[]
for path in FILES:
    raw=path.read_bytes(); text=raw.decode('utf-8'); lines=text.splitlines()
    try: start=next(i for i,x in enumerate(lines) if x=='Call graph:')
    except StopIteration:
        errors.append({'file':path.name,'reason':'missing Call graph header'}); continue
    try: stop=next(i for i in range(start+1,len(lines)) if lines[i].startswith('Total number in stack'))
    except StopIteration:
        errors.append({'file':path.name,'reason':'missing Total number in stack terminator'}); continue
    threads=[]; frames=[]; current=None
    for idx in range(start+1,stop):
        line=lines[idx]
        if not line.strip(): continue
        hm=HEADER.match(line)
        if hm:
            current={'thread_name':hm.group('thread'),'observation_count':int(hm.group('count')),'header_line':idx+1,'header_text':line,'header_suffix':hm.group('rest'),'frames':[]}
            threads.append(current); continue
        fm=FRAME.search(line)
        if not fm:
            errors.append({'file':path.name,'line':idx+1,'text':line,'reason':'nonblank call-graph line is neither thread header nor frame'}); continue
        deco=line[:fm.start('count')]
        if current is None:
            errors.append({'file':path.name,'line':idx+1,'text':line,'reason':'frame precedes first Thread header'}); continue
        count=int(fm.group('count')); frame_text=fm.group('frame')
        symbol=frame_text.split()[0]
        node={'line':idx+1,'original_line_text':line,'tree_decoration_prefix':deco,'indentation_style':'decorated' if any(c in deco for c in '+!|:') else 'spaces_only','indent_column':fm.start('count'),'observation_count':count,'full_frame_text':frame_text,'function_symbol':symbol,'parent_line':None,'depth':None,'exclusive_count':None}
        frames.append(node); current['frames'].append(node)
    for thread in threads:
        stack=[]
        for node in thread['frames']:
            while stack and stack[-1]['indent_column'] >= node['indent_column']: stack.pop()
            if stack:
                node['parent_line']=stack[-1]['line']; node['depth']=stack[-1]['depth']+1
            else:
                node['parent_line']=None; node['depth']=0
            stack.append(node)
        children={n['line']:0 for n in thread['frames']}
        for node in thread['frames']:
            if node['parent_line'] is not None: children[node['parent_line']]+=node['observation_count']
        for node in thread['frames']:
            node['immediate_child_count_sum']=children[node['line']]
            node['exclusive_count']=node['observation_count']-children[node['line']]
            if node['exclusive_count']<0:
                errors.append({'file':path.name,'line':node['line'],'text':node['original_line_text'],'reason':'negative exclusive count','count':node['observation_count'],'immediate_child_count_sum':children[node['line']]})
    root_nodes=[n for t in threads for n in t['frames'] if n['parent_line'] is None]
    root_sum=sum(n['observation_count'] for n in root_nodes)
    exclusive_sum=sum(n['exclusive_count'] for t in threads for n in t['frames'] if n['exclusive_count'] is not None)
    if exclusive_sum!=root_sum:
        errors.append({'file':path.name,'reason':'exclusive/root conservation mismatch','exclusive_sum':exclusive_sum,'root_sum':root_sum})
    file_records.append({'file':path.name,'source_path':str(path),'source_bytes':len(raw),'source_sha256':sha(raw),'call_graph_line_span':[start+1,stop],'empty_graph':not frames,'thread_count':len(threads),'frame_count':len(frames),'threads':threads,'root_thread_frame_count_sum':root_sum,'exclusive_frame_count_sum':exclusive_sum,'conservation_pass':exclusive_sum==root_sum})
    all_frames.extend(frames)

if errors:
    print(json.dumps({'status':'NEEDS_REASONING','errors':errors},indent=2))
    raise SystemExit(2)

symbols=sorted(set(n['function_symbol'] for n in all_frames))
demangler='/usr/bin/c++filt'
version=subprocess.run([demangler,'--version'],text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
demangled=subprocess.run([demangler,'-n'],input='\n'.join(symbols)+'\n',text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
outputs=demangled.stdout.splitlines()
if len(outputs)!=len(symbols):
    print(json.dumps({'status':'NEEDS_REASONING','reason':'demangler output count differs from unique symbol count','symbols':len(symbols),'outputs':len(outputs),'stderr':demangled.stderr},indent=2)); raise SystemExit(2)
symbol_map=[{'original_symbol':s,'demangled_output':d} for s,d in zip(symbols,outputs)]
lookup={x['original_symbol']:x['demangled_output'] for x in symbol_map}
for n in all_frames:n['demangled_function_symbol']=lookup[n['function_symbol']]

result={'schema':'shardloom.sample_stack_tree_inventory.v1','input_directory':str(BASE),'parser':{'scope':'text strictly between Call graph: and Total number in stack','thread_header_regex':HEADER.pattern,'frame_count_regex':FRAME.pattern,'indentation_definition':'zero-based character column where the first integer frame observation count begins; both punctuation-decorated and spaces-only Apple sample rows occur; parent is nearest prior frame in the same Thread header with a strictly smaller indentation column','exclusive_count_definition':'node observation_count minus sum of immediate child observation_count values'},'demangler':{'path':demangler,'version_stdout':version.stdout,'version_stderr':version.stderr,'arguments':['-n'],'input_symbol_count':len(symbols),'mapping':symbol_map,'symbol_handling':'first whitespace-delimited token of full_frame_text; original token passed verbatim, including leading underscores and Rust _R prefixes'},'files':file_records,'missing_sample_files':MISSING_SAMPLE_FILES,'totals':{'files':len(file_records),'empty_graph_files':sum(x['empty_graph'] for x in file_records),'thread_headers':sum(x['thread_count'] for x in file_records),'function_frames':sum(x['frame_count'] for x in file_records),'unique_function_symbols':len(symbols),'negative_exclusive_values':0,'files_passing_root_exclusive_conservation':sum(x['conservation_pass'] for x in file_records),'sum_root_frame_counts':sum(x['root_thread_frame_count_sum'] for x in file_records),'sum_exclusive_counts':sum(x['exclusive_frame_count_sum'] for x in file_records)},'limits':['Textual stack-tree reconstruction only. No source call graph is inferred.','No frames are classified as idle/work; no costs or performance conclusions are drawn.','Tree nesting uses the observed count-column indentation and nearest-prior-shallower rule specified in the packet.']}
OUT.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'COMPLETE','output':str(OUT),'output_sha256':sha(OUT.read_bytes()),'totals':result['totals']},indent=2))
