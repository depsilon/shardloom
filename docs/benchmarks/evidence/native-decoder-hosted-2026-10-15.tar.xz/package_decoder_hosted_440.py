"""Freeze the completed PR1551 hosted and exact-merge production observations."""
import difflib
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
DEST = OUT / 'decoder-hosted-package-440'
NAME = 'native-decoder-hosted-2026-10-15'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(path.read_text())

def dump(path, value):
    with path.open('x') as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write('\n')

def identity(path):
    data = path.read_bytes()
    return {'path': path.name, 'bytes': len(data), 'sha256': sha(data)}

verified = read(OUT / 'decoder-hosted-439/verification.json')
production = read(OUT / 'decoder-hosted-439/production/report.json')
assert verified['status'] == production['status'] == 'passed'
assert verified['checks_passed'] == 44 and len(verified['wheel_lanes']) == 3
assert production['merge'] == verified['merge']
for record in verified['raw_sources'] + verified['wheel_raw_sources'] + [verified['driver']]:
    payload = Path(record['path']).read_bytes()
    assert len(payload) == record['bytes'] and sha(payload) == record['sha256']
assert len(production['responses']) == 4
for record in production['responses']:
    actual = (OUT / 'decoder-hosted-439/production' / record['response']).read_bytes()
    expected = subprocess.check_output(['git', 'show', verified['merge'] + ':website/' + record['route']], cwd=ROOT)
    assert len(actual) == record['observed_bytes'] and sha(actual) == record['observed_sha256']
    assert len(expected) == record['expected_bytes'] and sha(expected) == record['expected_sha256']
    assert record['http_status'] == 200 and record['source_preserved']
    if actual == expected:
        assert record['raw_byte_identical'] and record['insertion_bytes'] == 0
    else:
        edits = [x for x in difflib.SequenceMatcher(None, expected, actual, autojunk=False).get_opcodes() if x[0] != 'equal']
        assert len(edits) == 1 and edits[0][0] == 'insert', edits
        _, _, _, first, last = edits[0]
        insertion = actual[first:last]
        assert len(insertion) == record['insertion_bytes'] and sha(insertion) == record['insertion_sha256']
        assert b'cloudflareinsights.com' in insertion and len(insertion) < 4096
assert not subprocess.check_output(['git', 'diff', '--name-only', production['website_unchanged_from'], verified['merge'], '--', 'website', 'website-src'], cwd=ROOT)

sources = {}
for prefix in ['decoder-hosted-438', 'decoder-hosted-439']:
    for path in sorted((OUT / prefix).rglob('*')):
        if path.is_file():
            sources[path.relative_to(OUT).as_posix()] = path
for name in ['verify_decoder_hosted_439.py', 'context-resources-425-source.json', Path(__file__).name]:
    sources[name] = OUT / name
assert sum(path.stat().st_size for path in sources.values()) < 4 * 1024 * 1024
DEST.mkdir()
archive = DEST / (NAME + '.tar.xz')
members = []
with tarfile.open(archive, 'w:xz', preset=6) as tar:
    for name, path in sorted(sources.items()):
        data = path.read_bytes()
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        tar.addfile(info, io.BytesIO(data))
        members.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
manifest = DEST / (NAME + '.manifest.json')
dump(manifest, {'schema_version': 'shardloom.evidence_member_manifest.v1', 'members': members})
expected = {r['path']: r for r in members}
seen = set()
with tarfile.open(archive, 'r:xz') as tar:
    for item in tar:
        assert item.isfile() and item.name in expected and item.name not in seen
        data = tar.extractfile(item).read()
        assert len(data) == expected[item.name]['bytes'] and sha(data) == expected[item.name]['sha256']
        assert data == sources[item.name].read_bytes()
        seen.add(item.name)
assert seen == set(expected)
verification = DEST / (NAME + '.verification.json')
dump(verification, {'schema_version': 'shardloom.native_decoder_hosted_packet_verification.v1',
                    'status': 'passed', 'members_verified': len(seen),
                    'original_bytes_verified': sum(r['bytes'] for r in members),
                    'archive': identity(archive), 'manifest': identity(manifest),
                    'all_members_match_originals': True, 'production_responses_verified': 4,
                    'unchanged_website_source_verified': True})
dump(DEST / (NAME + '.json'), {
    'schema_version': 'shardloom.native_decoder_hosted_index.v1',
    'status': 'completed_finite_unit', 'collected_utc_date': '2026-10-15',
    'pull_request': {'number': 1551, 'url': 'https://github.com/depsilon/shardloom/pull/1551',
                     'head': verified['head'], 'merge': verified['merge'], 'checks_passed': 44},
    'source_version': '0.5.1', 'equal_reviewed_synthetic_merged_trees': verified['trees'],
    'native_test_groups': [{'passed': int(g[0]), 'failed': int(g[1]), 'ignored': int(g[2])} for g in verified['native_test_groups']],
    'installed_wheel_lanes': 3, 'native_tests_per_lane': 80,
    'native_failures_errors_skips_per_lane': 0,
    'source_files_checked': verified['source_files_checked'],
    'changed_since_measurement': verified['changed_since_measured_source'],
    'production_runtime_source_preserved': True,
    'review_disposition': verified['review_boundary'],
    'production': production,
    'archive': identity(archive), 'manifest': identity(manifest),
    'verification': identity(verification), 'verified_members': len(seen),
    'limitations': [
        'The intermediate hosted verification predates the separate successful production observation; both originals are preserved.',
        'native-job-backend.json contains a truncated backend log; all native test claims use native-job-full.log.',
        'Hosted proof covers the three named Linux/macOS lanes; these 0.5.1 source wheels were not published.',
        'Website source is unchanged from the preceding deployed proof; no new rendered browser inspection is claimed.',
        'Historical UAT retains its source, executable and protocol; hosted checks are not new performance measurements.',
        'This finite closure does not complete whole PERF/CG gates or general decoder/allocation coverage.'
    ]})
print(json.dumps({'status': 'passed', 'members': len(seen), 'archive': identity(archive), 'output': str(DEST)}))
