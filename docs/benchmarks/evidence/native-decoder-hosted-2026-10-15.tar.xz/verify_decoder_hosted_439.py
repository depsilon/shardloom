"""Verify raw PR1551 checks, complete job logs and accepted source identity."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
RAW = OUT / 'decoder-hosted-439'
HEAD = 'e48a82f9597127fda3ded100daa91fdfd71f1515'
MERGE = 'b6d9318d42efb84275742fb3ff972d2adb350b41'
SYNTHETIC = '4bf75be76e6f2439caa75d971f37b3541eb2fdde'

def read(path):
    return json.loads(path.read_text())

def sha(data):
    return hashlib.sha256(data).hexdigest()

def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}

def plain(text):
    return '\n'.join(re.sub(r'^\d{4}-\d{2}-\d{2}T\S+Z ', '', line)
                     for line in text.lstrip('\ufeff').splitlines())

checks = read(RAW / 'checks-final.json')['structuredContent']
assert checks['headRevision'] == HEAD and not checks['hasMore']
assert len(checks['checks']) == len({c['id'] for c in checks['checks']}) == 44
assert all(c['head_sha'] == HEAD and c['status'] == 'completed' and c['conclusion'] == 'success'
           for c in checks['checks'])
merged = read(RAW / 'merge.json')['structuredContent']
assert merged['merged'] is True and merged['sha'] == MERGE
trees = {revision: subprocess.check_output(['git', 'rev-parse', revision + '^{tree}'],
                                          cwd=ROOT, text=True).strip()
         for revision in (HEAD, MERGE, SYNTHETIC)}
assert len(set(trees.values())) == 1
log = plain((RAW / 'native-job-full.log').read_text())
assert SYNTHETIC + ':refs/remotes/pull/1551/merge' in log
groups = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log, re.M)
assert groups == [('2786', '0', '25'), ('10', '0', '0'), ('7', '0', '0'), ('17', '0', '0')], groups
assert not re.search(r'^test .* \.\.\. FAILED$', log, re.M)
assert 'native_decoder_unreviewed_trees_are_exclusions_without_changing_execution ... ok' in log
wheels = read(OUT / 'decoder-hosted-438/wheel-verification.json')
assert len(wheels) == 3
wheel_sources = []
for wheel in wheels:
    path = OUT / 'decoder-hosted-438' / wheel['raw']
    assert sha(path.read_bytes()) == wheel['raw_sha256']
    raw = read(path)
    assert raw['headRevision'] == HEAD and raw['job']['conclusion'] == 'success'
    assert raw['logTruncated'] is False
    text = plain(raw['log'])
    assert SYNTHETIC + ':refs/remotes/pull/1551/merge' in text
    marker = '{\n  "schema_version": "shardloom.native_python_wheel_proof.v1"'
    assert text.count(marker) == 1
    proof, _ = json.JSONDecoder().raw_decode(text[text.index(marker):])
    assert proof['status'] == proof['stage']['status'] == proof['integrity']['status'] == 'passed'
    assert proof['integration'] == dict(tests=80, failures=0, errors=0, skipped=0, status='passed')
    assert all(step['returncode'] == 0 for step in proof['steps'])
    assert proof['installed_load']['isolated_install'] and proof['installed_load']['version'] == '0.5.1'
    assert proof['publication_attempted'] is False and proof['performance_claim'] is False
    assert proof['integrity'] == wheel['integrity']
    wheel_sources.append(identity(path))
reviews = read(RAW / 'reviews-final.json')['structuredContent']['reviews']
assert all(r['state'] != 'CHANGES_REQUESTED' for r in reviews)
threads = read(RAW / 'review-threads-final.json')['structuredContent']['review_threads']
assert len(threads) == 1 and threads[0]['is_resolved'] and threads[0]['is_outdated']
assert threads[0]['resolved_by']['login'] == 'github-advanced-security[bot]'
before = read(OUT / 'context-resources-425-source.json')['source_sha256']
assert len(before) == 2245
changed = {}
with subprocess.Popen(['git', 'cat-file', '--batch'], cwd=ROOT,
                      stdin=subprocess.PIPE, stdout=subprocess.PIPE) as child:
    for name, expected in sorted(before.items()):
        assert '\n' not in name
        child.stdin.write((MERGE + ':' + name + '\n').encode()); child.stdin.flush()
        header = child.stdout.readline().decode().split()
        assert len(header) == 3 and header[1] == 'blob', name
        payload = child.stdout.read(int(header[2]))
        assert child.stdout.read(1) == b'\n'
        digest = sha(payload)
        if digest != expected:
            changed[name] = {'measured_sha256': expected, 'merged_sha256': digest}
    child.stdin.close()
    assert child.wait(timeout=30) == 0
assert set(changed) == {'scripts/run_clickbench_query_uat.py', 'scripts/run_clickbench_paired_query_uat.py',
                        'scripts/test_clickbench_query_uat.py', 'scripts/test_clickbench_paired_query_uat.py',
                        'shardloom-vortex/src/native_provider_decoder_scratch_tests.rs'}, changed
report = {'schema_version': 'shardloom.native_decoder_hosted_verification.v1', 'status': 'passed',
          'head': HEAD, 'merge': MERGE, 'synthetic': SYNTHETIC, 'trees': trees, 'checks_passed': 44,
          'native_test_groups': groups, 'wheel_lanes': wheels, 'wheel_raw_sources': wheel_sources,
          'source_files_checked': len(before), 'changed_since_measured_source': changed,
          'production_runtime_source_preserved': True, 'source_version': '0.5.1',
          'review_boundary': 'One test-only CodeQL thread is outdated and resolved by the security bot; no requested changes.',
          'raw_sources': [identity(p) for p in sorted(RAW.iterdir()) if p.is_file()],
          'publication_claimed': False, 'production_deployment_verified': False,
          'driver': identity(Path(__file__))}
with (RAW / 'verification.json').open('x') as output:
    json.dump(report, output, indent=2); output.write('\n')
print(json.dumps({'status': 'passed', 'checks': 44, 'wheels': 3, 'native_groups': groups,
                  'source_files': len(before), 'source_changes': sorted(changed)}))
