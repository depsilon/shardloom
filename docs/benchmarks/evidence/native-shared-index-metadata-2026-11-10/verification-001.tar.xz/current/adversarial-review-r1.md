# Shared-index candidate review

The review target is a native hash-index change with exact caller equality,
stable entry identities, deterministic duplicate traversal and credited storage.
The frozen candidate is reviewed before any candidate score is observed.

1. **False matches, wraparound and skipped errors.** Occupied controls contain
   only a seven-bit fingerprint; the high bit denotes empty. The word comparison
   cannot carry between bytes, and matches are masked before the first empty
   lane. The mirrored seven-byte tail preserves linear visitation across every
   start. Candidates still require the original full hash and caller equality in
   increasing slot order. Exhaustive lane/occupancy/wrap controls, full-hash
   collision controls and the 22 complete-request diagnostic results cover this
   boundary. No selected-row or expression-error observation is omitted by a
   fingerprint collision.
2. **Uncharged growth or damaged state on failure.** Replacement buckets are
   reserved before optional controls are considered. Old buckets and controls
   remain charged during replacement construction. No publication occurs before
   fallible work and the final cancellation check complete. An admitted metadata
   allocation failure propagates; a pre-admission decline uses the existing
   native layout. Populated denial/retry and duplicate-chain controls preserve
   stable identities. The exact 320-byte eight-entry grant still passes.
3. **Misleading work or performance claims.** Diagnostic counters compile only
   in debug test builds. They distinguish logical probes, entry reads, full-hash
   equality, initialization and rehash work. Raw-log replay independently checks
   all 22 requests and eight cyclic calls; its corruption controls reject 14
   mutations. Reduced entry reads are not CPU-time attribution. Tiny aggregate
   peak credit increases of 320 bytes and all larger metadata costs remain
   recorded. Shipping depends on the entire frozen 2,452-case engine sum after
   correctness, resources, ownership and no-fallback checks.

The candidate capture uses the original worker, request builder, comparator,
engine-clock checks and inner guards. Candidate admission binds final source to
every required check and the fresh release build. The replay verifies ordered
case identities, independent expectation bytes, raw requests, complete results
and clocks for all cases, including failures. It derives the retain/drop result
only after the complete cohort. The 433 saved baseline cases and 2,019 new
baseline cases retain their separate provenance; this is not a full10k claim.

Current proof gap: the complete native suite and fresh ordinary release runtime
are still pending, as is the single candidate score. No hosted acceptance or
final integration is asserted by this review.
