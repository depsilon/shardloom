"""Check out the accepted merge without moving any local branch or other worktree."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
CONTRACT = OUT / 'hosted-contract-r1.json'
contract = json.loads(CONTRACT.read_bytes())
PR = contract['pr']
assert isinstance(PR, int) and PR > 0
DEST = OUT / 'dictionary-repair-main-checkout-r1.json'
assert not DEST.exists()


def read(path):
    return json.loads(path.read_bytes())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True, timeout=90).strip()


def worktrees():
    result = {}
    for block in git('worktree', 'list', '--porcelain').split('\n\n'):
        lines = block.splitlines()
        assert lines[0].startswith('worktree ')
        result[lines[0].removeprefix('worktree ')] = lines[1:]
    return result


pre = read(OUT / f'pr{PR}-premerge-r1.json')
merged = read(OUT / f'pr{PR}-merge-r1.json')
assert pre['status'] == 'passed_premerge' and pre['successful_hosted_checks'] == 58
assert pre['pr'] == PR and pre['head'] == contract['head'] and pre['base'] == contract['base']
assert pre['hosted_contract'] == dict(bytes=CONTRACT.stat().st_size,
    sha256=hashlib.sha256(CONTRACT.read_bytes()).hexdigest())
assert not merged.get('isError') and merged['structuredContent']['merged'] is True
sha = merged['structuredContent']['sha']
assert re.fullmatch('[0-9a-f]{40}', sha)
record = dict(status='needs_attention', merge_commit=sha, source_tree=pre['source_tree'],
    premerge_sha256=hashlib.sha256((OUT / f'pr{PR}-premerge-r1.json').read_bytes()).hexdigest(),
    observer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
try:
    assert git('rev-parse', 'HEAD') == pre['head'] and not git('status', '--porcelain')
    before = worktrees()
    branches = git('for-each-ref', '--format=%(refname) %(objectname)', 'refs/heads/')
    subprocess.run(['git', 'fetch', '--no-tags', 'origin', 'main'], cwd=ROOT, check=True, timeout=90)
    assert git('rev-parse', 'origin/main') == sha
    assert git('rev-parse', sha + '^{tree}') == pre['source_tree']
    assert git('show', '-s', '--format=%P', sha).split() == [pre['base'], pre['head']]
    response = read(OUT / 'merge-commit-connector-r1.json')
    assert not response.get('isError')
    body = response['structuredContent']
    assert body['url'] == 'https://api.github.com/repos/depsilon/shardloom/commits/' + sha
    raw = body['content'].encode('utf-8')
    assert len(raw) < 8 << 20
    commit = json.loads(raw)
    assert commit['sha'] == sha and commit['commit']['tree']['sha'] == pre['source_tree']
    assert [row['sha'] for row in commit['parents']] == [pre['base'], pre['head']]
    assert commit['commit']['verification']['verified'] is True
    assert worktrees() == before and not git('status', '--porcelain')
    subprocess.run(['git', 'switch', '--detach', sha], cwd=ROOT, check=True, timeout=90)
    after = worktrees()
    assert {path: rows for path, rows in before.items() if path != str(ROOT)} == {
        path: rows for path, rows in after.items() if path != str(ROOT)}
    assert git('for-each-ref', '--format=%(refname) %(objectname)', 'refs/heads/') == branches
    assert git('rev-parse', 'HEAD') == sha and git('rev-parse', 'HEAD^{tree}') == pre['source_tree']
    assert not git('status', '--porcelain') and not git('branch', '--show-current')
    record.update(status='passed', active_worktree=str(ROOT), signed_commit=commit,
        worktrees_before=before, worktrees_after=after, all_local_branches_unchanged=True,
        other_worktrees_unchanged=True, accepted_source_tree_unchanged=True, working_tree_clean=True)
except BaseException as error:
    record['error'] = type(error).__name__ + ': ' + str(error)
    raise
finally:
    with DEST.open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
print(json.dumps({key: record[key] for key in ('status', 'merge_commit', 'source_tree')}))
