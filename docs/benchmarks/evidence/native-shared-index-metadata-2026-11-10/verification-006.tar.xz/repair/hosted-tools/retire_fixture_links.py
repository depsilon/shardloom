"""Retire only the 54 accounted Variant corruption-fixture hardlink aliases."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import tempfile

D = Path(__file__).resolve().parents[1]
LOGS = D / 'retirement-command-logs'
PLAN = LOGS / 'fixture-link-plan-r1.json'
RECEIPT = D / 'fixture-link-retirement-r1.json'
CONTROLS = D / 'fixture-link-retirement-controls-r1.json'


def identity(path):
    assert path.is_file() and not path.is_symlink(), path
    before = generation(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    assert generation(path) == before
    return dict(bytes=before[3], sha256=digest)


def generation(path):
    s = path.lstat()
    return [s.st_dev, s.st_ino, s.st_mode, s.st_size,
            s.st_mtime_ns, s.st_ctime_ns, s.st_nlink]


def seal(keeper, aliases):
    paths = [keeper, *aliases]
    assert aliases and len(set(paths)) == len(paths)
    expected = generation(keeper)
    assert stat.S_ISREG(expected[2]) and expected[6] == len(paths)
    for path in paths:
        assert path.resolve() == path and generation(path) == expected
    return dict(keeper=str(keeper), aliases=[str(path) for path in aliases],
                remaining=[str(path) for path in paths], generation=expected,
                identity=identity(keeper), removed=[])


def verify(state):
    assert state['keeper'] in state['remaining']
    assert len(state['remaining']) == state['generation'][6]
    assert set(state['remaining']) == {state['keeper'], *state['aliases']} - set(state['removed'])
    for name in state['remaining']:
        path = Path(name)
        assert path.resolve() == path and generation(path) == state['generation'], name
    assert identity(Path(state['keeper'])) == state['identity']


def unlink_alias(state, name):
    assert name in state['aliases'] and name in state['remaining']
    assert name != state['keeper']
    verify(state)
    before = state['generation']
    Path(name).unlink()
    state['remaining'].remove(name)
    state['removed'].append(name)
    after = generation(Path(state['keeper']))
    # Only ctime and link count may change as a consequence of this unlink.
    assert after[:5] == before[:5] and after[6] == before[6] - 1
    state['generation'] = after
    verify(state)


def retirement():
    spec = importlib.util.spec_from_file_location('dictionary_retirement',
        D / 'hosted-tools/retire_dictionary_intermediates.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def groups(retire):
    controls = retire.read(retire.prior.REPAIR / 'corruption-controls.json')
    assert controls['status'] == 'passed'
    assert controls['positive_controls'] == 2 and controls['rejected_controls'] == 9
    cases = sorted(row['case'] for row in controls['cases'])
    assert len(cases) == len(set(cases)) == 11
    directory = retire.K / 'repair-controls-r1'
    assert retire.read(directory / 'receipt.json') == controls
    names = {'README.md', 'acceptance.json', 'verification.tar.xz',
             'verify.py', 'corruption-controls.json'}
    assert {path.name for path in retire.prior.PACKET.iterdir()} == names
    result = []
    for name in sorted(names):
        keeper = retire.prior.PACKET / name
        aliases = [directory / case / retire.prior.PACKET.name / name for case in cases
                   if (case, name) != ('original_packet_changed', 'acceptance.json')]
        assert all(path.is_relative_to(directory) for path in aliases)
        result.append(seal(keeper, aliases))
    assert len(result) == 5 and sum(len(row['aliases']) for row in result) == 54
    return result


def write_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def plan():
    assert not PLAN.exists() and not RECEIPT.exists()
    retire = retirement()
    assert not retire.TARGET.exists()
    hosted, kept, inputs = retire.gate(), retire.retained(), retire.prior.inputs()
    control = retire.read(CONTROLS)
    assert control['status'] == 'passed' and control['script'] == identity(Path(__file__))
    rows = groups(retire)
    for row in rows:
        assert kept[row['keeper']] == row['identity']
        assert not set(row['aliases']) & (set(kept) | set(inputs))
    retire.base.closed([name for row in rows for name in row['remaining']])
    for row in rows:
        verify(row)
    value = dict(status='planned_no_deletion', script=identity(Path(__file__)),
        controls=identity(CONTROLS), hosted=hosted, retained=kept,
        input_generations=inputs, groups=rows, aliases=54, retained_payloads=5,
        prior_refusal=identity(LOGS / 'plan-r1.log'),
        link_inventory=identity(LOGS / 'link-inventory-r1.json'),
        creator=identity(retire.K / 'tools/check_semantics_repair_controls.py'))
    write_new(PLAN, value)
    print(json.dumps(dict(status=value['status'], aliases=54, retained_payloads=5)))


def apply():
    assert not RECEIPT.exists()
    retire = retirement()
    planned = retire.read(PLAN)
    assert planned['status'] == 'planned_no_deletion'
    assert planned['script'] == identity(Path(__file__))
    assert planned['controls'] == identity(CONTROLS)
    assert planned['hosted'] == retire.gate()
    assert planned['retained'] == retire.retained()
    assert planned['input_generations'] == retire.prior.inputs()
    assert planned['prior_refusal'] == identity(LOGS / 'plan-r1.log')
    assert planned['link_inventory'] == identity(LOGS / 'link-inventory-r1.json')
    assert planned['creator'] == identity(retire.K / 'tools/check_semantics_repair_controls.py')
    for _ in range(2):
        assert groups(retire) == planned['groups']
        retire.base.closed([name for row in planned['groups'] for name in row['remaining']])
    states = planned['groups']
    receipt = dict(status='running', plan=identity(PLAN), script=identity(Path(__file__)),
        controls=identity(CONTROLS), hosted=planned['hosted'], states=states,
        removed_aliases=0, retained_payloads=5, payload_backups_created=False,
        storage_limits_changed=False, query_executions=0)
    try:
        for state in states:
            for name in state['aliases']:
                unlink_alias(state, name)
                receipt['removed_aliases'] += 1
            assert state['remaining'] == [state['keeper']] and state['generation'][6] == 1
        assert receipt['removed_aliases'] == 54
        assert retire.retained() == planned['retained']
        assert retire.prior.inputs() == planned['input_generations']
        assert retire.gate() == planned['hosted']
        receipt.update(status='passed', retained_bytes_unchanged=True,
            input_generations_unchanged=True, all_links_accounted=True,
            committed_files_preserved=True)
    except BaseException as error:
        receipt.update(status='failed', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        write_new(RECEIPT, receipt)
    print(json.dumps({key: receipt[key] for key in ('status', 'removed_aliases', 'retained_payloads')}))


def test():
    assert not CONTROLS.exists()
    outcomes = []
    for case in ('positive_two_aliases', 'unaccounted_link', 'new_link',
                 'changed_content', 'replaced_alias', 'removed_alias'):
        with tempfile.TemporaryDirectory(prefix='fixture-link-control-', dir=LOGS) as directory:
            root = Path(directory)
            keeper, first, second, other = (root / name for name in ('keeper', 'first', 'second', 'other'))
            keeper.write_bytes(b'preserved fixture bytes\n')
            os.link(keeper, first)
            os.link(keeper, second)
            if case == 'unaccounted_link':
                os.link(keeper, other)
                try:
                    seal(keeper, [first, second])
                except AssertionError:
                    outcomes.append(dict(case=case, outcome='rejected_before_unlink'))
                    continue
                raise AssertionError('unaccounted link admitted')
            state = seal(keeper, [first, second])
            if case == 'positive_two_aliases':
                unlink_alias(state, str(first))
                unlink_alias(state, str(second))
                assert keeper.read_bytes() == b'preserved fixture bytes\n'
                assert keeper.stat().st_nlink == 1 and not first.exists() and not second.exists()
                outcomes.append(dict(case=case, outcome='passed'))
                continue
            if case == 'new_link':
                os.link(keeper, other)
            elif case == 'changed_content':
                first.write_bytes(b'changed fixture bytes\n')
            elif case == 'replaced_alias':
                first.unlink()
                first.write_bytes(b'preserved fixture bytes\n')
            elif case == 'removed_alias':
                first.unlink()
            try:
                unlink_alias(state, str(second))
            except (AssertionError, FileNotFoundError):
                assert second.exists() and not state['removed']
                outcomes.append(dict(case=case, outcome='rejected_before_unlink'))
                continue
            raise AssertionError('changed link state admitted: ' + case)
    assert len(outcomes) == 6
    write_new(CONTROLS, dict(status='passed', script=identity(Path(__file__)),
        cases=outcomes, query_executions=0, historical_files_modified=False))
    print(json.dumps(dict(status='passed', positive_controls=1, rejected_controls=5)))


if __name__ == '__main__':
    assert __debug__, 'link retirement requires assertion checks'
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('test', 'plan', 'apply'))
    args = parser.parse_args()
    {'test': test, 'plan': plan, 'apply': apply}[args.action]()
