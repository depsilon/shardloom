"""Record dictionary repair integration and the superseded Variant retirement."""
from datetime import datetime, timezone
import importlib.util
import json
import lzma
from pathlib import Path

D = Path(__file__).resolve().parents[1]
DEST = D/'dictionary-repair-closeout-r1.json'
assert not DEST.exists()
spec = importlib.util.spec_from_file_location('dictionary_retirement',
    D/'hosted-tools/retire_dictionary_intermediates.py')
retire = importlib.util.module_from_spec(spec)
spec.loader.exec_module(retire)
read,identity,git = retire.read,retire.identity,retire.git
hosted = retire.gate()
pre,main = read(retire.PRE),read(retire.MAIN)
accepted = read(retire.PACKET/'acceptance.json')
assert accepted['status'] == 'local_acceptance_passed'
assert accepted['source_fingerprint_sha256'] == pre['source_fingerprint_sha256']
assert all(row['status'] == 'passed' for row in accepted['checks'].values())
assert accepted['original_observation'] == dict(attempts=10000,
    outcomes=dict(passed=9904,crashed=76,harness_error=20),
    complete_performance_result_valid=False,engine_execution_seconds=None)
assert accepted['repair_cohort'] == dict(cases=517,original_failed_cases=96,
    passing_controls=421,outcomes=dict(passed=517),selection_uses_timing=False)
assert not accepted['performance_claim'] and not accepted['complete_10k_performance_claim']
assert len(accepted['original_failed_checks']) == 7
controls = read(retire.PACKET/'corruption-controls.json')
assert controls['status'] == 'passed' and controls['query_executions'] == 0
assert len(controls['cases']) == 14
assert sum(row['status'] == 'rejected' for row in controls['cases']) == 13
positive = [row for row in controls['cases'] if row['status'] == 'passed']
assert len(positive) == 1 and positive[0]['name'] == 'relocated_source_only'

directory = retire.TARGET
aliases_path = D/'fixture-link-retirement-r1.json'
aliases = read(aliases_path)
assert aliases['status'] == 'passed' and aliases['removed_aliases'] == 54
assert aliases['retained_payloads'] == 5 and aliases['all_links_accounted']
assert aliases['retained_bytes_unchanged'] and aliases['input_generations_unchanged']
assert aliases['committed_files_preserved'] and aliases['query_executions'] == 0
assert aliases['plan'] == identity(D/'retirement-command-logs/fixture-link-plan-r1.json')
assert aliases['script'] == identity(D/'hosted-tools/retire_fixture_links.py')
assert aliases['controls'] == identity(D/'fixture-link-retirement-controls-r1.json')
assert not aliases['storage_limits_changed'] and not aliases['payload_backups_created']
retirement,plan = read(directory/'receipt.json'),read(directory/'plan.json')
assert retirement['status'] == 'passed' and retirement['head'] == pre['head']
assert retirement['removed'] == plan['entries']
assert retirement['retained_files_unchanged'] and retirement['input_generations_unchanged']
assert retirement['portable_replay_after_retirement'] == 'passed'
assert retirement['historical_member_identities_preserved'] and retirement['original_failed_observations_preserved']
assert not retirement['storage_limits_changed'] and not retirement['payload_backup_created']
assert retirement['manifest_sha256'] == plan['manifest_sha256'] == identity(directory/'manifest.json.xz')['sha256']
assert plan['script_sha256'] == identity(D/'hosted-tools/retire_dictionary_intermediates.py')['sha256']
assert plan['prior_helper_sha256'] == identity(retire.PRIOR_HELPER)['sha256']
assert plan['helper_sha256'] == identity(retire.prior.HELPER)['sha256']
manifest = json.loads(lzma.decompress((directory/'manifest.json.xz').read_bytes()))
assert manifest['hosted'] == retirement['hosted'] == hosted
assert all(not Path(path).exists() and not Path(path).is_symlink() for path in manifest['roots'])
assert retire.retained() == manifest['retained']
assert retire.prior.inputs() == manifest['input_generations']
assert len(manifest['input_generations']) == 220
replays = retirement['post_retirement_replays']
assert {row['packet'] for row in replays} == {retire.PACKET.name,retire.prior.REPAIR.name,
    'native-uuid-lifecycle-2026-11-10'}
for row in replays:
    assert row['returncode'] == 0 and row['result']['status'] == 'passed'
    assert identity(directory/(row['packet']+'.stdout.json')) == row['stdout']
    assert identity(directory/(row['packet']+'.stderr.log')) == row['stderr']
    assert read(directory/(row['packet']+'.stdout.json')) == row['result']
dictionary_replay = next(row['result'] for row in replays if row['packet'] == retire.PACKET.name)
assert dictionary_replay['query_executions'] == 0
assert dictionary_replay['original_outcomes'] == accepted['original_observation']['outcomes']
assert dictionary_replay['candidate_outcomes'] == dict(passed=517)
assert not dictionary_replay['complete_10k_performance_claim']
checkout_path = D/'dictionary-repair-main-checkout-r1.json'
checkout = read(checkout_path)
assert checkout['status'] == 'passed' and checkout['merge_commit'] == main['source_commit']
assert checkout['all_local_branches_unchanged'] and checkout['other_worktrees_unchanged']
assert checkout['accepted_source_tree_unchanged'] and checkout['working_tree_clean']

workflow_attempts = []
for root,reports in ((D,(pre,main)),(retire.K,(read(retire.K/'pr1676-premerge-r1.json'),
        read(retire.K/'variant-expression-main-r1.json')))):
    for report in reports:
        names = [name for name in report['raw_sources'] if name.endswith('/workflows.json')]
        assert len(names) == 1
        for row in read(root/names[0])['workflow_runs']:
            assert isinstance(row['run_attempt'],int) and row['run_attempt'] >= 1
            workflow_attempts.append(dict(id=row['id'],head_sha=row['head_sha'],
                run_attempt=row['run_attempt'],source=str(root/names[0])))
prior_pre,prior_main = (read(retire.K/name) for name in
    ('pr1676-premerge-r1.json','variant-expression-main-r1.json'))
assert prior_pre['status'] == 'passed_premerge' and prior_main['status'] == 'passed'
assert prior_pre['successful_hosted_checks'] == 58 and prior_main['successful_hosted_checks'] == 55
kept = {str(path):identity(path) for path in sorted((D/'runtime-r1').iterdir())}
assert {Path(path).name for path in kept} == {'shardloom','lib_native.dylib','_native.abi3.so'}
receipts = {retire.PRE,retire.MAIN,retire.CONTRACT,checkout_path,D/f'pr{retire.PR}-merge-r1.json',
    D/'merge-commit-connector-r1.json',D/'runtime-r1-identity.json',D/'runtime-library-copy-r1.json',
    D/'committed-source-replay-r1.json',D/'committed-source-replay-r1.log'}
receipts.update(directory.iterdir())
receipts.update(D/'draft-packet-retention-r1'/name for name in ('summary.json','manifest.json.xz'))
receipts.update(D/name for report in (pre,main) for name in report['raw_sources'])
receipts.update((D/'hosted-tools').glob('*.py'))
receipts.update(D.glob(f'pr{retire.PR}-observation-*.json'))
receipts.update(D.glob(f'main{retire.PR}-observation-*.json'))
receipts.update((D/'retirement-command-logs').glob('*'))
receipts.update((aliases_path,D/'fixture-link-retirement-controls-r1.json'))
receipts.update((D/'ci-diagnostics-r1').glob('*.json'))
assert not git('status','--porcelain')
result = dict(schema='shardloom.dictionary_repair_closeout.v1',status='complete',
    observed_at=datetime.now(timezone.utc).isoformat(),pr_url=f'https://github.com/depsilon/shardloom/pull/{retire.PR}',
    pr_head=pre['head'],merge_commit=main['source_commit'],source_tree=pre['source_tree'],
    pr_checks_passed=58,main_checks_passed=55,review_findings=False,review_url=pre['review_url'],
    main_ci_url=main['ci_run_url'],validation=accepted['checks'],
    source_fingerprint_sha256=accepted['source_fingerprint_sha256'],
    runtime_sources_match_build=True,source_bound_replay='passed',
    retained_runtime=kept,installed_repaired_wheel_claim=False,
    original_observation=accepted['original_observation'],repair_cohort=accepted['repair_cohort'],
    original_failed_result_records_preserved=7,original_control_observations_preserved=True,
    retired_regular_files=retirement['regular_files'],retired_symlinks=retirement['symlinks'],
    retired_regular_bytes=retirement['regular_bytes'],current_inputs_unchanged=True,current_input_files=220,
    retired_fixture_hardlink_aliases=54,retained_linked_evidence_payloads=5,
    initial_retirement_refusal_preserved=True,
    portable_replay_after_retirement='passed',post_retirement_replays=replays,
    superseded_variant=dict(pr=1676,head=prior_pre['head'],merge_commit=prior_main['source_commit'],
        pr_checks_passed=58,main_checks_passed=55,retirement='completed with this repair',
        runtime_and_wheel='retired; original package proof remains historical',
        premerge=identity(retire.K/'pr1676-premerge-r1.json'),main=identity(retire.K/'variant-expression-main-r1.json')),
    committed_evidence={str(path.relative_to(retire.W)):identity(path)
        for folder in retire.PACKETS for path in sorted(folder.iterdir())},
    hosted_jobs_restarted=any(row['run_attempt'] > 1 for row in workflow_attempts),workflow_attempts=workflow_attempts,
    receipts={str(path.relative_to(D)):identity(path) for path in sorted(receipts)},
    working_tree_clean=True,performance_claim=False,complete_10k_performance_claim=False,
    publication_attempted=False,storage_limits_changed=False,payload_backup_created=False,
    whole_item_19_complete=False,whole_item_20_complete=False,
    next_queue_unit='Investigate shared row-index metadata; keep compatible-window sharing independent.',
    original_limitations=accepted['limitations'],
    limitation_update='Hosted repair integration and combined retirement complete; original 10k remains invalid and no repaired installed wheel is claimed.')
with DEST.open('x') as stream:
    json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps({key:result[key] for key in ('status','merge_commit','pr_checks_passed','main_checks_passed',
    'retired_regular_files','retired_symlinks','complete_10k_performance_claim')}))
