"""Copy the verified local packet into its new repository evidence directory."""
import hashlib
import json
from pathlib import Path
import shutil

D = Path(__file__).resolve().parents[1]
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
source = D/'packet-r4'
target = W/'docs/release/evidence/native-dictionary-execution-repair-2026-11-10'
assert target.is_dir() and {p.name for p in target.iterdir()} == {'README.md'}
for name in ('package-r4','packet-controls-r3'):
    receipt = json.loads((D/(name+'.json')).read_bytes())
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert hashlib.sha256((D/(name+'.log')).read_bytes()).hexdigest() == receipt['log_sha256']
extras = {
    'corruption-controls.json':D/'corruption-controls-r3.json',
    'packaging-execution.json':D/'package-r4.json',
    'packaging-execution.log':D/'package-r4.log',
    'controls-execution.json':D/'packet-controls-r3.json',
    'controls-execution.log':D/'packet-controls-r3.log',
}
assert not any((source/name).exists() for name in extras)
required = sum(p.stat().st_size for p in source.iterdir())+2*sum(p.stat().st_size for p in extras.values())
assert shutil.disk_usage(source).free >= (12 << 30)+required+(128 << 20)

def identity(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        return dict(bytes=path.stat().st_size,sha256=hashlib.file_digest(stream,'sha256').hexdigest())

def copy(path,destination):
    before = identity(path)
    with path.open('rb') as src,destination.open('xb') as dst:
        shutil.copyfileobj(src,dst,1 << 20)
    assert identity(path) == identity(destination) == before
    return before

for name,path in extras.items():
    copy(path,source/name)
copied = {path.name:copy(path,target/path.name) for path in sorted(source.iterdir())}
result = dict(status='passed',source=str(source),destination=str(target),files=copied,
    query_executions=0,source_and_destination_byte_identical=True)
with (D/'repository-packet-copy-proof-r1.json').open('x') as output:
    json.dump(result,output,indent=2);output.write('\n')
print(json.dumps(dict(status='passed',files=len(copied),query_executions=0)))
