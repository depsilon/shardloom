"""Retire superseded Variant/dictionary intermediates after exact merged acceptance."""
import argparse
import hashlib
import importlib.util
import json
import lzma
from pathlib import Path
import shutil
import subprocess

D = Path(__file__).resolve().parents[1]
K = D.parent/'variant-expressions-2026-11-10'
S = D.parent/'shared-operator-state-2026-11-10'
U = D.parent/'uuid-lifecycle-2026-11-10'
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
PACKET = W/'docs/release/evidence/native-dictionary-execution-repair-2026-11-10'
TARGET = D/'dictionary-retirement-r1'
CONTRACT = D/'hosted-contract-r1.json'
contract = json.loads(CONTRACT.read_bytes())
PR,HEAD = contract['pr'],contract['head']
PRE,MAIN = D/f'pr{PR}-premerge-r1.json',D/'dictionary-repair-main-r1.json'
PRIOR_HELPER = K/'hosted-tools/retire_variant_expression_intermediates.py'
assert hashlib.sha256(PRIOR_HELPER.read_bytes()).hexdigest() == 'b0e7eab816e8ddb60b91b3a25538448e253bb729b18ca4118779007eb781f92f'
spec = importlib.util.spec_from_file_location('prior_retirement',PRIOR_HELPER)
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
base = prior.base
PACKETS = (PACKET,prior.PACKET,prior.REPAIR,W/'docs/release/evidence/native-uuid-lifecycle-2026-11-10')

def read(path):
    return json.loads(path.read_bytes())

def identity(path):
    assert path.is_file() and not path.is_symlink(),path
    return dict(bytes=path.stat().st_size,sha256=base.sha(path))

def git(*args):
    return subprocess.check_output(['git',*args],cwd=W,text=True,timeout=120).strip()

def gate():
    pre,main = read(PRE),read(MAIN)
    assert pre['status'] == 'passed_premerge' and main['status'] == 'passed'
    assert pre['pr'] == main['pr'] == PR and pre['head'] == main['pr_head'] == HEAD
    assert pre['base'] == main['pr_base'] == contract['base']
    assert pre['hosted_contract'] == identity(CONTRACT)
    assert pre['successful_hosted_checks'] == 58 and main['successful_hosted_checks'] == 55
    assert main['premerge_sha256'] == base.sha(PRE)
    assert pre['source_tree'] == main['source_tree'] == contract['tree'] and pre['tree_matches_synthetic']
    assert pre['review']['commit_sha'] == HEAD and pre['review']['status'] == 'completed'
    assert pre['review']['has_any_findings'] is pre['review']['has_unresolved_findings'] is False
    assert pre['unresolved_threads'] == 0 and not any(row['state'] == 'CHANGES_REQUESTED' for row in pre['review_submissions'])
    assert main['commit_verification']['verified'] and not main['failed'] and not main['pending'] and not main['missing']
    assert not main['duplicate_expected_checks'] and not main['unexpected_workflows']
    assert set(main['required_hosted_check_names']) == set(pre['required_check_names'])-{'CodeQL','CodeQL rust','CodeQL python'}
    for root,reports in ((D,(pre,main)),(K,(read(K/'pr1676-premerge-r1.json'),read(K/'variant-expression-main-r1.json')))):
        for report in reports:
            assert report['status'] in ('passed_premerge','passed')
            for name,expected in report['raw_sources'].items():
                actual = identity(root/name)
                assert actual == expected if isinstance(expected,dict) else actual['sha256'] == expected
    assert git('rev-parse','HEAD') == main['source_commit'] and not git('status','--porcelain')
    assert git('rev-parse','HEAD^{tree}') == pre['source_tree']
    assert git('show','-s','--format=%P','HEAD').split() == [pre['base'],HEAD]
    return dict(premerge=identity(PRE),main=identity(MAIN),merge_commit=main['source_commit'])

def retained():
    result = {}
    runtime = read(D/'runtime-r1-identity.json')
    assert runtime['status'] == 'passed' and runtime['profile'] == 'release'
    assert runtime['build_receipt_identity'] == identity(D/runtime['build_receipt'])
    assert runtime['build_source_fingerprint_sha256'] == read(PRE)['source_fingerprint_sha256']
    assert {path.name for path in (D/'runtime-r1').iterdir()} == {'shardloom','lib_native.dylib','_native.abi3.so'}
    for row in runtime['files']:
        path = Path(row['path'])
        assert path.parent == D/'runtime-r1'
        assert identity(path) == {key:row[key] for key in ('bytes','sha256')}
        result[str(path)] = identity(path)
    copied = read(D/'runtime-library-copy-r1.json')
    assert copied['status'] == 'passed'
    assert identity(Path(copied['source'])) == identity(Path(copied['destination'])) == copied['identity']
    result[copied['destination']] = copied['identity']
    for directory in PACKETS:
        for path in sorted(directory.iterdir()):
            result[str(path)] = identity(path)
    for name,info in read(PRE)['packet_files'].items():
        assert result[str(PACKET/name)] == info
    previous = read(K/'pr1676-premerge-r1.json')
    for directory,key in ((prior.PACKET,'packet_files'),(prior.REPAIR,'repair_packet_files')):
        for name,info in previous[key].items():
            assert result[str(directory/name)] == info
    # Preserve every completed receipt/log and all helpers, including historical
    # failed observations. Current ledgers remain active cohort-selection inputs.
    for root in (D,K,S,U):
        for pattern in ('*.json','*.log','tools/*.py','hosted-tools/*.py'):
            for path in sorted(root.glob(pattern)):
                result[str(path)] = identity(path)
    for root in (S/'current-baseline-10k-r1',D/'correctness-cohort-r1'):
        for path in sorted(root.iterdir()):
            if path.is_file():
                result[str(path)] = identity(path)
    for path in sorted((D/'draft-packet-retention-r1').iterdir()):
        result[str(path)] = identity(path)
    for path in sorted((D/'ci-diagnostics-r1').glob('*.json')):
        result[str(path)] = identity(path)
    for draft in ('packet-r1','packet-r2','packet-r3'):
        for name in ('acceptance.json','verify.py'):
            result[str(D/draft/name)] = identity(D/draft/name)
    for name in ('report.json','report.log'):
        path = K/'installed-proof-r1'/name
        if path.exists():
            result[str(path)] = identity(path)
    return result

def replacement_index(kept):
    known = {}
    for directory in PACKETS:
        for row in read(directory/'acceptance.json')['members']:
            known.setdefault((row['bytes'],row['sha256']),'committed_member:'+str(directory.relative_to(W))+':'+row['path'])
    for path,item in kept.items():
        known.setdefault((item['bytes'],item['sha256']),'retained_file:'+path)
    return known

def selected_roots(kept):
    # Reuse the previous reviewed, exact-source selector for completed Variant
    # staging, tests, duplicate evidence and superseded UUID payloads. Its gate
    # is intentionally not invoked: the stronger dictionary merge gate above
    # establishes the current tree; all prior hosted observations stay checked.
    selected,replacements = prior.roots_and_replacements()
    known = replacement_index(kept)
    def add(path,reason):
        assert path.exists() and not path.is_symlink() and path.resolve() == path
        assert path.is_relative_to(D.parent) and path != D.parent
        assert str(path) not in selected
        selected[str(path)] = reason
    old = prior.retained()
    for directory in (K/'runtime-r2',K/'installed-proof-r1/dist'):
        for path in directory.iterdir():
            assert identity(path) == old[str(path)]
        add(directory,'superseded Variant runtime/wheel; repair CLI/library now accepted; original package proof remains historical')
    baseline = S/'baseline-runtime-r1'
    assert {path.name for path in baseline.iterdir()} == {'_native.abi3.so'}
    protected = read(D/'committed-source-replay-r1.json')['protected_runtime_and_wheel']
    for path in baseline.iterdir():
        assert identity(path) == protected[str(path)]
    add(baseline,'superseded original-observation library copy; exact 10000 results retained, no current full10k claim')
    for root in (D/'source-blobs',S/'source-blobs'):
        for path in sorted(root.iterdir()):
            item = identity(path)
            assert item['sha256'] == path.name
            replacements.append(dict(path=str(path),identity=item,replacement=known[(item['bytes'],item['sha256'])]))
        add(root,'byte-identical source/receipt snapshots retained in committed archives or explicit retained files')
    final = D/'packet-r4'
    assert {path.name for path in final.iterdir()} == {path.name for path in PACKET.iterdir()}-{'README.md'}
    for path in final.iterdir():
        assert identity(path) == identity(PACKET/path.name)
    add(final,'byte-identical committed final dictionary packet')
    compact = D/'draft-packet-retention-r1'
    summary = read(compact/'summary.json')
    assert summary['status'] == 'passed' and summary['deletions'] == summary['query_executions'] == 0
    assert identity(compact/'manifest.json.xz') == summary['manifest']
    manifest = json.loads(lzma.decompress((compact/'manifest.json.xz').read_bytes()))
    assert manifest['status'] == 'passed' and manifest['script'] == identity(D/'hosted-tools/compact_draft_evidence.py')
    assert not manifest['payload_backup_created']
    for name,item in manifest['committed_packet_files'].items():
        assert identity(Path(name)) == item
    for sha,item in manifest['retained_draft_members'].items():
        assert identity(compact/sha) == item
    for draft in manifest['drafts'].values():
        assert draft['all_logical_members_byte_identical_after_reconstruction']
        for name,item in draft['metadata'].items():
            assert identity(Path(name)) == item
        for name,item in draft['archives'].items():
            assert identity(Path(name)) == item
            add(Path(name),'draft logical bytes reconstructed exactly from final archive plus retained unique text; original manifest/verifier remain')
    paths = [Path(name) for name in selected]
    assert not any(a != b and a.is_relative_to(b) for a in paths for b in paths)
    return selected,replacements

def replay():
    results = []
    for directory in (PACKET,prior.REPAIR,W/'docs/release/evidence/native-uuid-lifecycle-2026-11-10'):
        command = ['/opt/homebrew/opt/python@3.13/libexec/bin/python3','-I','-B',str(directory/'verify.py'),'--require-controls']
        if directory == PACKET:
            command += ['--repo-root',str(W)]
        result = subprocess.run(command,cwd=W,capture_output=True,text=True,timeout=600)
        name = directory.name
        (TARGET/(name+'.stdout.json')).write_text(result.stdout)
        (TARGET/(name+'.stderr.log')).write_text(result.stderr)
        assert result.returncode == 0,result.stderr
        observed = json.loads(result.stdout)
        assert observed['status'] == 'passed'
        results.append(dict(packet=name,command=command,returncode=0,
            result=observed,stdout=identity(TARGET/(name+'.stdout.json')),stderr=identity(TARGET/(name+'.stderr.log'))))
    return results

def plan():
    assert not TARGET.exists() and shutil.disk_usage(D).free >= (12 << 30)+(8 << 20)
    hosted,kept,current = gate(),retained(),prior.inputs()
    roots,replacements = selected_roots(kept)
    rows = [row for name in sorted(roots) for row in base.inventory(Path(name))]
    assert len(rows) == len({row['path'] for row in rows})
    assert not (set(kept)|set(current)).intersection(row['path'] for row in rows)
    base.closed(roots)
    for row in rows:
        base.unchanged(row)
    manifest = dict(head=HEAD,roots=roots,entries=rows,retained=kept,
        input_generations=current,hosted=hosted,source_snapshot_replacements=replacements)
    raw = lzma.compress(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode(),preset=6)
    assert len(raw) < 8 << 20 and json.loads(lzma.decompress(raw)) == manifest
    TARGET.mkdir()
    (TARGET/'manifest.json.xz').write_bytes(raw)
    summary = dict(status='planned_no_deletion',head=HEAD,roots=len(roots),entries=len(rows),
        regular_files=sum(row['kind'] == 'regular' for row in rows),symlinks=sum(row['kind'] == 'symlink' for row in rows),
        regular_bytes=sum(row['generation'][3] for row in rows if row['kind'] == 'regular'),
        manifest_sha256=base.sha(TARGET/'manifest.json.xz'),script_sha256=base.sha(Path(__file__)),
        prior_helper_sha256=base.sha(PRIOR_HELPER),helper_sha256=base.sha(prior.HELPER),
        current_input_files=len(current),retained_files=len(kept),payload_backup_created=False)
    (TARGET/'plan.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary),flush=True)

def apply():
    assert gate() and shutil.disk_usage(D).free >= 12 << 30
    summary = read(TARGET/'plan.json')
    assert summary['script_sha256'] == base.sha(Path(__file__))
    assert summary['prior_helper_sha256'] == base.sha(PRIOR_HELPER) and summary['helper_sha256'] == base.sha(prior.HELPER)
    assert summary['manifest_sha256'] == base.sha(TARGET/'manifest.json.xz')
    manifest = json.loads(lzma.decompress((TARGET/'manifest.json.xz').read_bytes()))
    assert manifest['head'] == HEAD and manifest['hosted'] == gate()
    kept = retained()
    roots,replacements = selected_roots(kept)
    assert roots == manifest['roots'] and replacements == manifest['source_snapshot_replacements']
    assert kept == manifest['retained'] and prior.inputs() == manifest['input_generations']
    rows = manifest['entries']
    for _ in range(2):
        assert [row for name in sorted(roots) for row in base.inventory(Path(name))] == rows
        base.closed(roots)
    assert not (TARGET/'receipt.json').exists()
    receipt = dict(status='running',head=HEAD,removed=0,manifest_sha256=summary['manifest_sha256'],
        hosted=manifest['hosted'],merged=True)
    try:
        for row in sorted(rows,key=lambda value:len(Path(value['path']).parts),reverse=True):
            path = Path(row['path'])
            base.unchanged(row,removing_children=row['kind'] == 'directory')
            path.rmdir() if row['kind'] == 'directory' else path.unlink()
            receipt['removed'] += 1
        assert all(not Path(name).exists() and not Path(name).is_symlink() for name in roots)
        assert retained() == manifest['retained'] and prior.inputs() == manifest['input_generations']
        assert gate() == manifest['hosted']
        checked = replay()
        receipt.update(status='passed',retained_files_unchanged=True,input_generations_unchanged=True,
            portable_replay_after_retirement='passed',post_retirement_replays=checked,
            storage_limits_changed=False,payload_backup_created=False,historical_member_identities_preserved=True,
            original_failed_observations_preserved=True,regular_files=summary['regular_files'],
            symlinks=summary['symlinks'],regular_bytes=summary['regular_bytes'])
    except BaseException as error:
        receipt.update(status='failed',error=type(error).__name__+': '+str(error))
        raise
    finally:
        with (TARGET/'receipt.json').open('x') as output:
            json.dump(receipt,output,indent=2);output.write('\n')
    print(json.dumps(receipt),flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=('plan','apply'))
    args = parser.parse_args()
    plan() if args.action == 'plan' else apply()
