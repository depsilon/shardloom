"""Original capture loop with explicit, recorded historical-generation bindings.

Only the admission, historical prerequisite checks and prepared-file bindings
change. Query construction, worker, execution, clocks and storage guards do not.
"""
from __future__ import annotations

import argparse
from contextlib import ExitStack
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import run_investigation_cohort_r2 as common
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
from resources import BenchmarkGuard
from run_clickbench_query_uat import run_profiled_command
from query_surface.evidence import identity, worker_outcome
from query_surface.expanded_freeze import pack, read, unpack
from query_surface.expanded_run import closing_db, raw_packet, request, stage_complete, stage_lock, verify, verify_request_files
from query_surface.run import write_json

TARGET_NAME = "shared-mechanisms-10k-r1"
ADMISSION_NAME = "shared-mechanisms-admission-r1.json"
PROTOCOL_NAME = "shared-mechanisms-10k-protocol-r1.json"
LEGACY_BASELINE = "90c17ec7abb3d414008cbab4446dac63d9cd838e"
WORKER = common.HARNESS_DEFAULT / "benchmarks/traditional_analytics/query_surface/expanded_worker.py"


def observe(root, resume, admission, historical, selection):
    stage = "native"
    design, inputs, frozen_files, updated = admission(root)
    prepared = {}
    prerequisites = {}
    if stage != "polars":
        historical.stage_complete(root, "polars", design["count"])
        prerequisites["polars"] = identity(root / "observe-polars/complete.json")
        prerequisites["preparation"] = identity(root / "native-preparation/complete.json")
        prepared = read(root / "native-preparation/complete.json")
        if (
            prepared["status"] != "passed"
            or historical.current(prepared["frozen"]) != identity(root / "frozen.json")
            or historical.current(prepared["polars_complete"]) != prerequisites["polars"]
        ):
            raise ValueError("explicit preparation is incomplete")
        extra = [
            f for p in prepared["profiles"].values() for f in [p["manifest"], *p["inputs"], *p["receipts"]]
        ]
        extra = historical.files(extra)
        verify(extra)
        frozen_files += extra
    if stage == "alternate":
        historical.stage_complete(root, "native", design["count"])
        prerequisites["native"] = identity(root / "observe-native/complete.json")
    selected = list(selection)
    if stage == "alternate" and [r["id"] for r in selected] != design["alternate_route_cases"]:
        raise ValueError("paired probe order changed")
    target = root / TARGET_NAME
    if (target / "complete.json").exists():
        raise FileExistsError("completed scored stage cannot be repeated")
    if target.exists() != resume:
        raise ValueError("select a fresh stage, or explicitly resume its unattempted requests")
    policy = design["execution"]
    wanted_freeze = identity(root / "frozen.json")
    generations = {f["path"]: f for f in frozen_files}
    budget = check_budgets(
        root,
        root / "reserved-output",
        root / "logs",
        min_free_bytes=12 * GIB,
        reserve_bytes=64 * MIB,
        max_workspace_bytes=100 * GIB,
        max_log_bytes=192 * MIB,
    )
    with stage_lock(root), ExitStack() as stack:
        target.mkdir(exist_ok=resume)
        guard = stack.enter_context(
            BenchmarkGuard(target, binary=Path(inputs["runtime"]["binary"]["path"]), memory_gb=2)
        )
        references = {}
        for profile in {r["profile"] for r in selected}:
            loc = root / ("reference-" + profile) / "expectations.sqlite"
            references[profile] = stack.enter_context(closing_db(loc, readonly=True))
        ledger = target / "attempts.sqlite"
        db = stack.enter_context(closing_db(ledger))
        db.execute(
            "CREATE TABLE IF NOT EXISTS attempt (seq INTEGER PRIMARY KEY,id TEXT NOT NULL UNIQUE,status TEXT NOT NULL, packet BLOB)"
        )
        binding = target / "binding.json"
        contract = {"frozen": wanted_freeze, "stage": stage, "prerequisites": prerequisites, "updated": updated}
        if resume:
            if read(binding)["contract"] != contract:
                raise ValueError("resumed stage bindings differ")
            db.execute("UPDATE attempt SET status='incomplete' WHERE status='started'")
            db.commit()
        else:
            write_json(binding, {"contract": contract, "started_at": datetime.now(timezone.utc).isoformat()})
        active = target / "active"
        active.mkdir(exist_ok=resume)
        # A non-empty active folder after interruption is evidence. Keep it
        # without executing that slot again.
        if any(active.iterdir()):
            if not resume:
                raise ValueError("active directory must initially be empty")
            active.rename(target / ("interrupted-" + str(time.time_ns())))
            active.mkdir()
        seen = {seq: (id_, status) for seq, id_, status in db.execute("SELECT seq,id,status FROM attempt")}
        if any(
            seq < 0 or seq >= len(selected) or selected[seq]["id"] != id_ for seq, (id_, _) in seen.items()
        ):
            raise ValueError("resumed attempt identities differ")
        for seq, row in enumerate(selected):
            if seq in seen:
                continue
            ref = (
                references[row["profile"]]
                .execute("SELECT identity,value FROM expected WHERE id=?", (row["id"],))
                .fetchone()
            )
            if ref is None or ref[0] != row["case_identity"]:
                raise ValueError("case lacks an exact independent result")
            job = request(row, stage, inputs, prepared, unpack(ref[1]), policy)
            verify_request_files(job, generations)
            guard.check()
            if ledger.exists() and ledger.stat().st_size > 1536 * MIB:
                raise ValueError(
                    "active compressed evidence exceeds the prospectively bounded storage allocation"
                )
            job_path = active / "one.job.json"
            write_json(job_path, job)
            db.execute("INSERT INTO attempt VALUES (?,?,?,NULL)", (seq, row["id"], "started"))
            db.commit()
            cmd = [
                sys.executable,
                "-B",
                str(WORKER),
                "--job",
                str(job_path),
            ]
            receipt = run_profiled_command(
                cmd, active / "one", policy["query_deadline_seconds"] + 5, guard.check
            )
            raw = (active / "one.stdout.json").read_bytes()
            outcome = worker_outcome(receipt, raw)
            status = outcome["status"]
            if status in {"passed", "incorrect", "comparison_inconclusive"} and (
                outcome.get("id") != row["id"]
                or outcome.get("case_identity") != row["case_identity"]
                or outcome.get("execution_engine") != job["engine"]
            ):
                raise ValueError("successful worker response belongs to another request")
            packet = dict(
                supervision=receipt,
                files=raw_packet(active),
                classified_status=status,
                classification_detail=outcome.get("detail"),
            )
            encoded = pack(packet)
            db.execute(
                "UPDATE attempt SET status=?,packet=? WHERE id=? AND status='started'",
                (status, encoded, row["id"]),
            )
            db.commit()
            saved = db.execute("SELECT packet FROM attempt WHERE id=?", (row["id"],)).fetchone()[0]
            if saved != encoded:
                raise ValueError("compressed evidence did not persist")
            for name, value in packet["files"].items():
                path = active / name
                if hashlib.sha256(path.read_bytes()).hexdigest() != value["sha256"]:
                    raise ValueError("active evidence changed before compact retention")
                path.unlink()
            global_failure = [
                f
                for f in receipt["guard_failures"]
                if "another native workload" in f or "free" in f or "storage" in f
            ]
            if global_failure:
                raise ValueError("external guard stopped the stage: " + str(global_failure))
            if (seq + 1) % 100 == 0 or seq + 1 == len(selected):
                print(
                    json.dumps(
                        dict(
                            stage=stage,
                            attempts=seq + 1,
                            total=len(selected),
                            outcomes=dict(db.execute("SELECT status,COUNT(*) FROM attempt GROUP BY status")),
                        )
                    ),
                    flush=True,
                )
        outcomes = dict(db.execute("SELECT status,COUNT(*) FROM attempt GROUP BY status"))
        observed = list(db.execute("SELECT id FROM attempt ORDER BY seq"))
        if observed != [(r["id"],) for r in selected] or "started" in outcomes:
            raise ValueError("incomplete attempt inventory")
    verify(frozen_files)
    write_json(
        target / "complete.json",
        dict(
            status="complete_observation",
            stage=stage,
            updated=updated,
            frozen=wanted_freeze,
            total=len(selected),
            attempt_slots=sum(outcomes.values()),
            outcomes=outcomes,
            ledger=identity(ledger),
            binding=identity(binding),
            prerequisites=prerequisites,
            completed_at=datetime.now(timezone.utc).isoformat(),
            storage_before=budget,
            posthash_verified=True,
            attempts_per_case=1,
            requested_repeats=0,
        ),
    )
