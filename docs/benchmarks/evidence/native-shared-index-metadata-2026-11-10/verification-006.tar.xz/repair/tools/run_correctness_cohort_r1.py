"""Bind one predefined correctness cohort to the dictionary repair's verified runtime."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

D = Path(__file__).resolve().parents[1]
S = D.parent / 'shared-operator-state-2026-11-10'
E = D.parent / 'expanded-query-2026-11-03'
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
BASE = '8f426b3d2e774be2a9d30a731c33b8c830378d99'
SELECTION = D / 'correctness-cohort-selection-r1.json'
PROTOCOL = D / 'correctness-cohort-protocol-r1.json'
TARGET = D / 'correctness-cohort-r1'
RUNTIME = D / 'runtime-r1'
BUILD = D / 'release-build-r1.json'
LIBRARY = RUNTIME / '_native.abi3.so'
sys.path.insert(0, str(S / 'tools'))
import run_current_10k as original
import capture_correctness_cohort_r1 as capture
from query_surface.evidence import identity
from query_surface.expanded_freeze import read
from query_surface.expanded_run import verify

CHECKS = ('format-r2', 'default-clippy-r1', 'default-tests-r1',
          'native-clippy-r2', 'native-tests-r1', 'dictionary-focused-r2')
FEATURES = 'shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment'
CHECK_COMMANDS = {
    'format-r2': ['cargo','fmt','--all','--','--check'],
    'default-clippy-r1': ['cargo','clippy','--offline','--locked','--workspace','--all-targets','--','-D','warnings'],
    'default-tests-r1': ['env','RUST_TEST_THREADS=4','cargo','test','--offline','--locked','--workspace','--all-targets'],
    'native-clippy-r2': ['cargo','clippy','--offline','--locked','--workspace','--all-targets','--features',FEATURES,'--','-D','warnings'],
    'native-tests-r1': ['env','RUST_TEST_THREADS=4','cargo','test','--offline','--locked','--workspace','--all-targets','--features',FEATURES],
    'dictionary-focused-r2': ['cargo','test','--offline','--locked','--workspace','--lib','--features',FEATURES,'native_dictionary_suspended_','--','--nocapture','--test-threads=4'],
}
_historical = None

def historical():
    global _historical
    if _historical is None:
        _historical = original.HistoricalBinding()
    return _historical

def file_identity(path):
    full = identity(path)
    assert path.is_file() and not path.is_symlink()
    return dict(bytes=full['generation']['bytes'], sha256=full['sha256'])

def git(*args):
    return subprocess.check_output(['git', *args], cwd=W, text=True, timeout=90).strip()

def verify_capture():
    original.verify_capture_source()
    source = Path(original.capture.__file__).read_text()
    substitutions = [
        ('def observe(root, resume, admission, historical):',
         'def observe(root, resume, admission, historical, selection):'),
        ('    selected = [r for r in design["cases"] if stage != "alternate" or r["surrogate"]]',
         '    selected = list(selection)'),
    ]
    for before, after in substitutions:
        assert source.count(before) == 1
        source = source.replace(before, after)
    assert Path(capture.__file__).read_text() == source

def source_inventory():
    excluded = ('docs/benchmarks/evidence/', 'docs/release/evidence/', 'docs/dependencies/evidence/')
    paths = set()
    for command in (['git','ls-files','--cached','-z'], ['git','ls-files','--others','--exclude-standard','-z']):
        paths.update(p for p in subprocess.check_output(command,cwd=W).decode().split('\0')
            if p and not p.startswith(('.git/', *excluded)) and '.git' not in Path(p).parts)
    inventory = {}
    for name in sorted(paths):
        path = W / name
        if path.is_symlink():
            target = os.readlink(path)
            inventory[name] = dict(symlink=target,sha256=hashlib.sha256(os.fsencode(target)).hexdigest())
        elif path.is_file():
            inventory[name] = file_identity(path)
        else:
            assert not path.exists()
            inventory[name] = dict(absent=True)
    return inventory

def verify_check_sources(receipt, build):
    before, after = receipt['build_sources'], build['build_sources']
    assert set(before) == set(after)
    changed = [name for name in before if before[name] != after[name]]
    if not changed:
        assert receipt['build_source_fingerprint_sha256'] == build['build_source_fingerprint_sha256']
        return
    # Reuse the already passing default/focused checks only across the exact
    # test-comment spelling correction required by Clippy. No executable input
    # or test assertion changes; current native tests still run in full.
    name = 'shardloom-vortex/src/native_provider_dictionary_tests.rs'
    assert changed == [name]
    old = D / 'source-blobs' / before[name]['sha256']
    new = D / 'source-blobs' / after[name]['sha256']
    assert file_identity(old) == before[name] and file_identity(new) == after[name]
    original_text = old.read_text()
    phrase = '/// Restrict the registry so eager take kernels cannot bypass ExecuteSlot.'
    assert original_text.count(phrase) == 1
    assert original_text.replace(phrase, phrase.replace('ExecuteSlot', '`ExecuteSlot`')) == new.read_text()

def runtime_proof():
    assert __debug__
    build = read(BUILD)
    assert build['status'] == 'passed' and build['returncode'] == 0
    assert build['process_group_drained'] and build['direct_child_reaped']
    assert build['fixed_source_validation'] and not build['allow_lockfile_update']
    assert build['command'] == ['env','PYO3_PYTHON=/opt/homebrew/opt/python@3.13/libexec/bin/python3',
        'cargo','build','--offline','--locked','--release','--features','release-user-surfaces',
        '-p','shardloom-cli','-p','shardloom-python']
    assert build['base'] == BASE and git('rev-parse','HEAD') == build['head']
    assert source_inventory() == build['build_sources']
    paths = [BUILD]
    for name in CHECKS:
        path = D / (name + '.json')
        receipt = read(path)
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['command'] == CHECK_COMMANDS[name]
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert receipt['fixed_source_validation'] and not receipt['allow_lockfile_update']
        verify_check_sources(receipt, build)
        assert not receipt['build_source_verification']['post_execution']['changed_paths']
        assert receipt['log_sha256'] == file_identity(path.with_suffix('.log'))['sha256']
        paths.extend([path,path.with_suffix('.log')])
    before = read(D / 'suspended-dictionary-regression-r2.json')
    assert before['status'] == 'failed' and before['returncode'] == 101
    assert before['process_group_drained'] and before['direct_child_reaped']
    before_log = D / 'suspended-dictionary-regression-r2.log'
    assert before['log_sha256'] == file_identity(before_log)['sha256']
    assert 'DictSlots codes slot' in before_log.read_text()
    provider = 'shardloom-vortex/src/native_provider_chunked.rs'
    raw = subprocess.check_output(['git','show',BASE + ':' + provider],cwd=W)
    assert before['build_sources'][provider] == dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    assert before['build_sources'][provider] != build['build_sources'][provider]
    paths.extend([D / 'suspended-dictionary-regression-r2.json',before_log])
    record_path = D / 'runtime-r1-identity.json'
    record = read(record_path)
    assert record['status'] == 'passed' and record['profile'] == 'release'
    assert record['build_receipt'] == BUILD.name and record['build_receipt_identity'] == file_identity(BUILD)
    assert record['build_source_fingerprint_sha256'] == build['build_source_fingerprint_sha256']
    files = {Path(row['path']).name: row for row in record['files']}
    assert set(files) == {'shardloom','lib_native.dylib'}
    for name,row in files.items():
        path = Path(row['path'])
        assert path == RUNTIME / name
        assert file_identity(path) == {key:row[key] for key in ('bytes','sha256')}
    paths.append(record_path)
    return build,files,paths

def prepare_library():
    _,files,_ = runtime_proof()
    source = Path(files['lib_native.dylib']['path'])
    receipt_path = D / 'runtime-library-copy-r1.json'
    expected = file_identity(source)
    if receipt_path.exists():
        assert read(receipt_path) == dict(status='passed',source=str(source),destination=str(LIBRARY),identity=expected)
        assert file_identity(LIBRARY) == expected
        return
    assert not LIBRARY.exists()
    assert shutil.disk_usage(D).free >= (12 << 30) + expected['bytes'] + (128 << 20)
    with source.open('rb') as src,LIBRARY.open('xb') as dst:
        shutil.copyfileobj(src,dst,1 << 20)
    assert file_identity(LIBRARY) == file_identity(source) == expected
    with receipt_path.open('x') as output:
        json.dump(dict(status='passed',source=str(source),destination=str(LIBRARY),identity=expected),output,indent=2)
        output.write('\n')

def admission(root,require_protocol=True):
    assert root == E
    verify_capture()
    build,files,proof = runtime_proof()
    assert file_identity(LIBRARY) == file_identity(Path(files['lib_native.dylib']['path']))
    binding = historical()
    with binding.admission_verifier(capture.common):
        design,inputs,frozen,relocated,archive,_ = capture.common.checked_admission(capture.common.ROOT_DEFAULT,E)
    frozen = binding.files(frozen)
    selected = read(SELECTION)
    assert selected['status'] == 'selected_before_candidate_execution' and selected['query_executions'] == 0
    assert not selected['selection_uses_timing'] and selected['selected_requests'] == len(selected['cases']) == 517
    assert selected['original_failed_requests'] == 96 and selected['passing_controls'] == 421
    assert selected['source_commit'] == BASE
    assert selected['cases'] == sorted(selected['cases'],key=lambda r:r['seq'])
    assert len({r['seq'] for r in selected['cases']}) == 517
    for row in selected['cases']:
        assert row['case'] == design['cases'][row['seq']]
    for row in selected['sources']:
        assert file_identity(Path(row['path'])) == {k:row[k] for k in ('bytes','sha256')}
    baseline = read(S / 'current-baseline-10k-protocol-r1.json')
    observed = read(S / 'current-baseline-10k-r1/failed-observation-replay-r1.json')
    assert observed['verification_passed'] and not observed['complete_performance_result_valid']
    assert observed['original_outcomes'] == {'passed':9904,'crashed':76,'harness_error':20}
    assert {r['seq'] for r in observed['failures']} == {
        r['seq'] for r in selected['cases'] if r['previous_status'] != 'passed'}
    verify([observed['ledger'],observed['complete'],observed['case_rows'],observed['protocol']])
    assert baseline['runtime_binding']['head'] == BASE
    prepared = read(E / 'native-preparation/complete.json')
    prepared_files = [f for p in prepared['profiles'].values() for f in [p['manifest'],*p['inputs'],*p['receipts']]]
    runtime = dict(binary=identity(Path(files['shardloom']['path'])),library=identity(LIBRARY))
    paths = [*proof,SELECTION,Path(__file__),Path(capture.__file__),Path(original.__file__),
        Path(original.capture.__file__),original.BINDING,D / 'runtime-library-copy-r1.json',
        D / 'tools/replay_correctness_cohort_r1.py',D / 'tools/guard_dictionary_repair.py',
        D / 'tools/freeze_correctness_cohort_r1.py',D / 'contract.md',
        S / 'current-baseline-10k-protocol-r1.json',
        S / 'current-baseline-10k-r1/failed-observation-replay-r1.json',
        capture.WORKER,E / 'tools/run_investigation_cohort_r2.py',E / 'tools/run_shared_10k.py',
        E / 'native-preparation/complete.json']
    proof_files = [identity(path) for path in sorted(set(paths))]
    updated = dict(schema='shardloom.dictionary_repair_runtime.v1',role='correctness_repair',
        source_head=build['head'],source_root=str(W),source_fingerprint_sha256=build['build_source_fingerprint_sha256'],
        source_build_receipt=identity(BUILD),runtime=runtime,proof_files=proof_files,
        selection=identity(SELECTION),original_observation=observed['complete'],target=str(TARGET),
        original_worker=identity(capture.WORKER),frozen_harness_files=len(relocated),
        attempts_per_case=1,warmups=0,requested_repeats=0,complete_10k_performance_claim=False,
        fallback_allowed=False)
    protocol = dict(schema='shardloom.dictionary_repair_capture_protocol.v1',
        status='admitted_before_execution',selected_count=517,failed_cases=96,passing_controls=421,
        selection=identity(SELECTION),design=identity(E / 'design.json'),
        inputs=identity(E / 'inputs.json'),frozen=identity(E / 'frozen.json'),
        execution=design['execution'],runtime_binding=updated,
        capture_changes='explicit selection argument only; worker, request, execution loop, clocks, guards and cleanup unchanged from the independently verified current-baseline capture',
        complete_10k_performance_claim=False,
        primary_clock='engine_execution_seconds',attempts_per_case=1,warmups=0,
        isolation='all other task-owned work idle during query execution; full input and source scans before/after only')
    added = [*archive,*proof_files,*runtime.values(),*binding.files(prepared_files),
             observed['ledger'],observed['complete'],observed['case_rows'],observed['protocol']]
    verify(added)
    if require_protocol:
        assert read(PROTOCOL) == protocol
        added.append(identity(PROTOCOL))
    else:
        assert not PROTOCOL.exists() and not TARGET.exists()
        with PROTOCOL.open('x') as output:
            json.dump(protocol,output,indent=2,allow_nan=False)
            output.write('\n')
    return design,dict(inputs,runtime=runtime),[*frozen,*added],updated

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan',action='store_true')
    args = parser.parse_args()
    os.environ['POLARS_MAX_THREADS'] = '2'
    capture.require_local_path(D,Path.home(),sys.platform)
    capture.require_local_path(E,Path.home(),sys.platform)
    if args.plan:
        prepare_library()
        admission(E,require_protocol=False)
        print(json.dumps(dict(status='admitted_before_execution',selected_requests=517,query_executions=0)))
    else:
        selection = [r['case'] for r in read(SELECTION)['cases']]
        capture.TARGET_NAME = str(TARGET)
        capture.observe(E,False,admission,historical(),selection)

if __name__ == '__main__':
    main()

