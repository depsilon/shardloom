"""Verify the complete fixed baseline cohort from saved reuse and new observations."""
from collections import Counter, defaultdict
from contextlib import ExitStack
import gzip
import hashlib
import json
import math
from pathlib import Path

import run_index_baseline as current
from query_surface.corpus import corpus
from query_surface.evidence import identity
from query_surface.expanded_catalog import build, spaces
from query_surface.expanded_freeze import read, unpack
from query_surface.expanded_report import raw_files, replay
from query_surface.expanded_run import closing_db, verify


def main():
    if not __debug__:
        raise RuntimeError('baseline replay requires Python assertion checks')
    assert Path(__file__).resolve() == current.N / 'tools/replay_index_baseline.py', 'unactivated draft cannot execute'
    target = current.TARGET
    destination = current.N / 'baseline-verified-r1.json'
    cases_path = current.N / 'baseline-cases-r1.jsonl.gz'
    partial = current.N / 'baseline-cases-r1.partial.jsonl.gz'
    lock = current.N / '.baseline-replay-r1.lock'
    assert not any(path.exists() for path in (destination, cases_path, partial, lock))
    design, inputs, frozen, admitted = current.admission(current.E)
    protocol = read(current.PROTOCOL)
    selection = read(current.SELECTION)
    reuse = read(current.REUSE)
    done, binding = read(target / 'complete.json'), read(target / 'binding.json')
    assert done['status'] == 'complete_observation' and done['stage'] == 'native'
    assert done['total'] == done['attempt_slots'] == 2019
    assert done['posthash_verified'] and done['attempts_per_case'] == 1 and done['requested_repeats'] == 0
    assert done['updated'] == admitted
    assert binding['contract'] == {key: done[key] for key in ('frozen', 'stage', 'prerequisites', 'updated')}
    assert done['ledger']['path'] == str(target / 'attempts.sqlite')
    assert done['binding']['path'] == str(target / 'binding.json')
    verify([done['ledger'], done['binding'], done['frozen']])
    guard_path = current.N / 'baseline-missing-r1.json'
    guard = read(guard_path)
    assert guard['status'] == 'passed' and guard['returncode'] == 0
    assert guard['process_group_drained'] and guard['direct_child_reaped'] and guard['query_workload']
    assert guard['head'] == guard['base'] == current.MERGE and not guard['working_tree']
    assert guard['active_output'] == str(target)
    assert guard['fixed_source_validation'] and not guard['allow_lockfile_update']
    assert guard['build_inventory_policy'] == guard['evidence_inventory_policy'] == 'before_and_after_only'
    assert guard['accepted_baseline_merge'] == current.MERGE
    assert guard['accepted_dictionary_closeout']['sha256'] == identity(current.CLOSEOUT)['sha256']
    assert guard['command'] == ['/Users/dylan/.cache/shardloom/query-surface-polars-2.1.0/bin/python',
        '-B', str(current.N / 'tools/run_index_baseline.py')]
    assert guard['log_sha256'] == current.file_identity(guard_path.with_suffix('.log'))['sha256']
    reused = {row['cohort_ordinal']: row for row in reuse['rows']}
    missing = {row['cohort_ordinal']: (ordinal, row) for ordinal, row in enumerate(protocol['missing_cases'])}
    assert len(reused) == 433 and len(missing) == 2019 and not set(reused).intersection(missing)
    assert set(reused) | set(missing) == set(range(2452))
    assert reuse['all_complete_results_correct'] and reuse['all_engine_clocks_valid']
    assert reuse['no_external_fallback'] and reuse['exact_requests_and_expected_results']
    prepared = read(current.E / 'native-preparation/complete.json')
    originals = {item.id: item for item in corpus(interactions='all', include_pending=False)}
    definitions = {spec.name: spec for spec in spaces()}
    outcomes, new_outcomes = Counter(), Counter()
    families, values, failures = defaultdict(list), [], []
    with lock.open('x'):
        pass
    with ExitStack() as stack:
        db = stack.enter_context(closing_db(target / 'attempts.sqlite', readonly=True))
        entries = iter(db.execute('SELECT seq,id,status,packet FROM attempt ORDER BY seq'))
        refs = {profile: stack.enter_context(closing_db(current.E / ('reference-' + profile) / 'expectations.sqlite', readonly=True))
            for profile in {row['case']['profile'] for row in protocol['missing_cases']}}
        output = stack.enter_context(gzip.open(partial, 'wt', encoding='utf-8'))
        for ordinal, selected in enumerate(selection['cases']):
            case = selected['case']
            if ordinal in reused:
                row = reused[ordinal]
                assert row['original_seq'] == selected['original_seq']
                assert row['id'] == case['id'] and row['case_identity'] == case['case_identity']
                observed = row['result']
                assert observed['status'] == 'passed'
                provenance = dict(source='saved_dictionary_repair', ledger=reuse['original_ledger']['path'],
                    source_seq=row['repair_ordinal'], packet=row['packet'], job_sha256=row['job_sha256'],
                    independent_expected_blob_sha256=row['independent_expected_blob_sha256'])
            else:
                source_seq, expected_case = missing[ordinal]
                assert expected_case['original_seq'] == selected['original_seq'] and expected_case['case'] == case
                entry = next(entries, None)
                assert entry and entry[:2] == (source_seq, case['id'])
                item = build(case, definitions) if 'cell' in case else originals[case['id']]
                reference = refs[case['profile']].execute('SELECT identity,value FROM expected WHERE id=?', (case['id'],)).fetchone()
                assert reference and reference[0] == item.identity == case['case_identity']
                expected = unpack(reference[1])
                observed = replay(entry, case, 'native', expected, item, inputs, prepared, design['execution'])
                assert observed['status'] == entry[2]
                if observed['status'] == 'passed' or observed['engine_seconds'] is not None:
                    current.clock_verifier.verify_clock(entry, observed)
                files = raw_files(unpack(entry[3])) if entry[3] is not None else {}
                provenance = dict(source='new_missing_baseline', ledger=done['ledger']['path'], source_seq=source_seq,
                    packet=(dict(bytes=len(entry[3]), sha256=hashlib.sha256(entry[3]).hexdigest()) if entry[3] is not None else None),
                    job_sha256=(hashlib.sha256(files['one.job.json']).hexdigest() if files else None),
                    independent_expected_blob_sha256=hashlib.sha256(reference[1]).hexdigest())
                new_outcomes[observed['status']] += 1
            outcomes[observed['status']] += 1
            if observed['status'] == 'passed':
                elapsed = observed['engine_seconds']
                assert type(elapsed) in (int, float) and math.isfinite(elapsed) and elapsed >= 0
                values.append(elapsed)
                families[case['family']].append(elapsed)
            else:
                failures.append(dict(cohort_ordinal=ordinal, original_seq=selected['original_seq'], id=case['id'],
                    status=observed['status'], detail=observed.get('failure_detail')))
            output.write(json.dumps(dict(cohort_ordinal=ordinal, original_seq=selected['original_seq'],
                id=case['id'], case_identity=case['case_identity'], family=case['family'], profile=case['profile'],
                surface=case['surface'], native_format=case['native_format'], provenance=provenance,
                result=observed), separators=(',', ':'), allow_nan=False) + '\n')
        assert next(entries, None) is None
    assert dict(new_outcomes) == done['outcomes'] and sum(new_outcomes.values()) == 2019
    assert sum(outcomes.values()) == 2452
    verify([*frozen, done['ledger'], done['binding'], done['frozen']])
    partial.rename(cases_path)
    passed = outcomes == {'passed': 2452}
    result = dict(schema='shardloom.shared_index_baseline_cohort.v1',
        status='passed_complete_baseline_cohort' if passed else 'failed_baseline_cohort',
        query_executions_during_replay=0, accepted_merge=current.MERGE, accepted_tree=current.TREE,
        selected_cases=2452, reused_saved_cases=433, new_attempts=2019, outcomes=dict(outcomes),
        new_outcomes=dict(new_outcomes), attempts_per_case=1, warmups=0, requested_repeats=0,
        primary_clock='engine_execution_seconds', engine_execution_seconds=math.fsum(values) if passed else None,
        complete_performance_result_valid=passed, all_selected_results_correct=passed,
        all_engine_clocks_valid=passed, native_no_fallback=passed, failures=failures,
        families={name: dict(cases=len(rows), engine_execution_seconds=math.fsum(rows)) for name, rows in sorted(families.items())},
        protocol=identity(current.PROTOCOL), selection=identity(current.SELECTION), reuse=identity(current.REUSE),
        complete=identity(target / 'complete.json'), ledger=done['ledger'], guard=identity(guard_path),
        case_rows=identity(cases_path), verifier=identity(Path(__file__)), runtime_binding=admitted,
        performance_claim=False, complete_10k_performance_claim=False,
        limitations=['This is the fixed 2452-case cohort, with explicitly reused observations and newly measured missing cases.',
            'The original failed 10k observation remains unchanged and invalid as a complete performance result.',
            'The saved repair capture and new missing capture are separate isolated sessions; reuse is explicit, not a new single-pass full cohort claim.'])
    with destination.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False); stream.write('\n')
    lock.unlink()
    print(json.dumps({key: result[key] for key in ('status', 'selected_cases', 'reused_saved_cases',
        'new_attempts', 'outcomes', 'engine_execution_seconds', 'complete_10k_performance_claim')}))
    assert passed, 'complete baseline failed; every observation remains retained'


if __name__ == '__main__':
    main()
