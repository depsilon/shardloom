"""Freeze and capture only missing baseline cases for the fixed shared-index cohort.

Draft: not admitted until the exact dictionary merge and its retirement closeout
pass. The original capture function, worker, request builder, clocks, per-query
guards and result comparator are reused unchanged. No query runs in --plan.
"""
from __future__ import annotations

import argparse
from contextlib import ExitStack
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

N = Path('/Users/dylan/LocalData/shardloom/shared-index-metadata-2026-11-10')
D = N.parent / 'dictionary-execution-repair-2026-11-10'
S = N.parent / 'shared-operator-state-2026-11-10'
E = N.parent / 'expanded-query-2026-11-03'
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
MERGE = '037b6801320aa0bfe939ba10aed9304198b77a5a'
TREE = '7ea0196daa21254d4c1bf0953f20a57e1b4a14e1'
SELECTION = S / 'index-cohort-selection-r1.json'
SELECTION_HASH = '5477c06868540fff63d418d6fd1a50ca8a1597627efb0c35131826efe13bde52'
TARGET = N / 'baseline-missing-r1'
PROTOCOL = N / 'baseline-protocol-r1.json'
REUSE = N / 'baseline-reuse-r1.json'
CLOSEOUT = D / 'dictionary-repair-closeout-r1.json'
PACKET = W / 'docs/release/evidence/native-dictionary-execution-repair-2026-11-10'
sys.path[:0] = [str(D / 'tools'), str(S / 'tools')]
import run_correctness_cohort_r1 as repair
import replay_current_10k as clock_verifier
from query_surface.corpus import corpus
from query_surface.evidence import identity
from query_surface.expanded_catalog import build, spaces
from query_surface.expanded_freeze import read, unpack
from query_surface.expanded_report import raw_files, replay
from query_surface.expanded_run import closing_db, request, verify

capture = repair.capture


def file_identity(path):
    assert path.is_file() and not path.is_symlink(), path
    before = path.stat()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    after = path.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (
        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    return dict(bytes=after.st_size, sha256=digest)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
        allow_nan=False).encode()).hexdigest()


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=W, text=True, timeout=90).strip()


def candidate_contract():
    """Fix the one proposed mechanism and its diagnostics before baseline capture."""
    tests_path = S / 'reuse-metadata-r1/consumer-test-manifest-primary-r1.json'
    tests = read(tests_path)
    assert tests['status'] == 'passed_static_verification' and tests['head'] == MERGE
    assert tests['query_executions'] == tests['build_executions'] == tests['test_executions'] == 0
    assert len(tests['tests']) == 41 and len(tests['module_filters']) == 11
    for relative, expected in tests['source_identities'].items():
        assert file_identity(W / relative) == expected
    sources = [S / 'index-layout-design.md', S / 'index-cohort-preparation-r1.md',
        S / 'index-consumers-current-r1.md', S / 'probe-word-model-r1.json',
        tests_path, S / 'reuse-metadata-r1/verify_consumer_test_manifest.py',
        *[S / 'attribution-draft-r1' / name for name in (
            'native_relational_index.rs', 'native_relational_observation.rs',
            'local_primitive_relational_probe_attribution_tests.rs')]]
    return dict(schema='shardloom.shared_index_candidate_contract.v1',
        stage='prospective_before_candidate_implementation', sources=[identity(path) for path in sources],
        owner='shardloom-vortex/src/local_primitives/native_relational_index.rs',
        mechanism=dict(optional_container='ReservedVec<u8>', empty_control=128,
            fingerprint='high seven full-hash bits', group_bytes=8, mirrored_tail_bytes=7,
            minimum_bucket_capacity=128, control_bytes='bucket_capacity + 7',
            maximum_free_credit_fraction=dict(numerator=1, denominator=16),
            credit_snapshot='after replacement bucket reservation, with old buckets and controls still charged',
            matching='safe little-endian word screening; exact full hash and caller equality still decide',
            probe_order='original linear order, stop at the first empty slot or exact match',
            publication='after every fallible operation and final cancellation check',
            growth='private replacement; preserve stable entry IDs and ordered duplicate links',
            optional_decline='ordinary native layout at the same growth boundary',
            admitted_failure='propagate allocation, cancellation and data errors; no error-text recovery',
            cancellation_maximum_logical_slots=1024),
        diagnostics=dict(configuration='debug-test counters only; ordinary release runtime scores engine time',
            sizes=[17, 4097], request_shapes=['group_unique', 'group_repeat', 'inner_unique',
                'inner_duplicates', 'semi_missing', 'anti_missing', 'set_intersect', 'set_except',
                'window_partitions', 'window_distinct', 'correlated_in'],
            cyclic_test='cyclic_candidate_counts_actual_work_for_all_four_frozen_targets',
            cyclic_calls='retain both existing complete calls for each of four targets as semantic diagnostics',
            counters=['lookups', 'logical_probe_slots', 'bucket_reads', 'entry_reads',
                'fingerprint_candidates', 'exact_equality_calls', 'metadata_groups',
                'bucket_initialization_bytes', 'metadata_initialization_bytes',
                'rehash_entries', 'vacancy_reads', 'peak_charged_bytes', 'final_charged_bytes'],
            activation='all eleven larger complete-request shapes and all four cyclic targets must reach RowIndex; tiny cases must not reach the metadata layout',
            correctness='complete independent ordered values, schema, source exhaustion, no-fallback certificates and final credit release',
            scope='one admitted worker and debug-test caller thread; counters are not CPU-time shares'),
        required_owner_controls=['exact matching-byte and wraparound reference',
            'full-hash collisions with exact equality and ordered duplicates',
            'empty and tiny layout; original exact eight-entry grant unchanged',
            'successful populated growth and stable entry identities',
            'denied populated replacement, prior lookups/chains unchanged, release and successful retry',
            'optional metadata declined at successful growth with unchanged native answers',
            'cancellation bound, fallible equality, no partial row publication and complete credit refund'],
        existing_consumer_controls=dict(manifest=identity(tests_path), tests=41,
            module_filters=tests['module_filters'], execution_status='not_yet_executed_for_this_experiment'),
        acceptance='complete 2452-case engine total must be strictly lower after correctness, resource, ownership and no-fallback checks; equality or increase drops',
        tuning='one candidate; no constants, cases or denominator tuned after scored results',
        future_source_binding='bind the actual candidate source, checks, release build and runtime before its single scored capture',
        separate_work=['compatible-window sharing', 'rolling-DISTINCT deletion/recycling'],
        performance_claim=False)


def accepted_runtime():
    """Bind existing binaries to their original build and completed hosted proof."""
    if not __debug__:
        raise RuntimeError('baseline admission requires Python assertion checks')
    assert git('rev-parse', 'HEAD') == MERGE and git('rev-parse', 'HEAD^{tree}') == TREE
    assert not git('status', '--porcelain'), 'baseline requires the clean accepted merge'
    closeout = read(CLOSEOUT)
    assert closeout['status'] == 'complete' and closeout['merge_commit'] == MERGE
    assert closeout['source_tree'] == TREE
    assert closeout['pr_checks_passed'] == 58 and closeout['main_checks_passed'] == 55
    assert closeout['review_findings'] is False and closeout['working_tree_clean']
    assert closeout['runtime_sources_match_build'] and closeout['source_bound_replay'] == 'passed'
    assert closeout['portable_replay_after_retirement'] == 'passed'
    assert closeout['current_inputs_unchanged'] and closeout['current_input_files'] == 220
    assert not closeout['complete_10k_performance_claim']
    proof = [CLOSEOUT]
    for relative, expected in closeout['receipts'].items():
        path = D / relative
        assert not Path(relative).is_absolute() and path.resolve().is_relative_to(D)
        assert file_identity(path) == expected
        proof.append(path)
    for relative, expected in closeout['committed_evidence'].items():
        path = W / relative
        assert not Path(relative).is_absolute() and path.resolve().is_relative_to(W)
        assert file_identity(path) == expected
        proof.append(path)
    accepted = read(PACKET / 'acceptance.json')
    assert accepted['status'] == 'local_acceptance_passed'
    assert accepted['source_fingerprint_sha256'] == closeout['source_fingerprint_sha256']
    members = {row['path']: {key: row[key] for key in ('bytes', 'sha256')}
        for row in accepted['members']}
    protocol = read(D / 'correctness-cohort-protocol-r1.json')
    runtime = protocol['runtime_binding']['runtime']
    assert protocol['runtime_binding']['source_fingerprint_sha256'] == closeout['source_fingerprint_sha256']
    assert protocol['primary_clock'] == 'engine_execution_seconds'
    assert protocol['attempts_per_case'] == 1 and protocol['warmups'] == 0
    assert set(runtime) == {'binary', 'library'}
    assert runtime['binary']['path'] == str(D / 'runtime-r1/shardloom')
    assert runtime['library']['path'] == str(D / 'runtime-r1/_native.abi3.so')
    verify(list(runtime.values()))
    for name, expected in closeout['retained_runtime'].items():
        assert file_identity(Path(name)) == expected
        proof.append(Path(name))
    for path in [D / 'correctness-cohort-protocol-r1.json', D / 'correctness-cohort-selection-r1.json',
                 D / 'correctness-cohort-r1.json', D / 'correctness-cohort-r1.log',
                 *sorted((D / 'correctness-cohort-r1').glob('*'))]:
        if path.is_file():
            assert file_identity(path) == members['current/' + path.relative_to(D).as_posix()]
            proof.append(path)
    return runtime, protocol, closeout, proof


def selected_cases(design):
    assert file_identity(SELECTION) == dict(bytes=2213038, sha256=SELECTION_HASH)
    selected = read(SELECTION)
    assert selected['query_executions'] == 0 and not selected['selection_uses_timing']
    assert selected['selected_requests'] == len(selected['cases']) == 2452
    assert not selected['execution_admitted'] and not selected['saved_observation_reuse_verified']
    for source in selected['sources'].values():
        assert file_identity(Path(source['path'])) == {key: source[key] for key in ('bytes', 'sha256')}
    original_ordinals = [row['original_seq'] for row in selected['cases']]
    assert original_ordinals == sorted(set(original_ordinals))
    for row in selected['cases']:
        assert row['case'] == design['cases'][row['original_seq']]
    repaired = read(D / 'correctness-cohort-selection-r1.json')
    by_id = {row['case']['id']: (ordinal, row) for ordinal, row in enumerate(repaired['cases'])}
    reused, missing = [], []
    for ordinal, row in enumerate(selected['cases']):
        entry = dict(cohort_ordinal=ordinal, original_seq=row['original_seq'], case=row['case'])
        old = by_id.get(row['case']['id'])
        if old is None:
            missing.append(entry)
        else:
            repair_ordinal, old_row = old
            assert old_row['case'] == row['case'] and old_row['seq'] == row['original_seq']
            reused.append(dict(entry, repair_ordinal=repair_ordinal))
    assert len(reused) == 433 and len(missing) == 2019
    assert [row['original_seq'] for row in reused] == selected['repair_metadata_overlap_original_seqs']
    return selected, reused, missing


def context():
    repair.verify_capture()
    runtime, old_protocol, closeout, proof = accepted_runtime()
    candidate = candidate_contract()
    proof.extend(Path(row['path']) for row in candidate['sources'])
    historical = repair.historical()
    with historical.admission_verifier(capture.common):
        design, inputs, frozen, relocated, archive, _ = capture.common.checked_admission(
            capture.common.ROOT_DEFAULT, E)
    selected, reused, missing = selected_cases(design)
    assert old_protocol['execution'] == design['execution']
    assert old_protocol['design'] == identity(E / 'design.json')
    assert old_protocol['inputs'] == identity(E / 'inputs.json')
    assert old_protocol['frozen'] == identity(E / 'frozen.json')
    assert old_protocol['runtime_binding']['original_worker'] == identity(capture.WORKER)
    assert old_protocol['runtime_binding']['frozen_harness_files'] == len(relocated) == 65
    prepared = read(E / 'native-preparation/complete.json')
    prepared_files = [f for profile in prepared['profiles'].values()
        for f in [profile['manifest'], *profile['inputs'], *profile['receipts']]]
    frozen = [*historical.files(frozen), *historical.files(prepared_files), *archive]
    # The 65-file frozen client remains authoritative. These three extra modules
    # are the source-bound import closure already admitted by the repair packet.
    build_receipt = read(D / 'release-build-r1.json')
    assert build_receipt['build_source_fingerprint_sha256'] == closeout['source_fingerprint_sha256']
    for relative in ('scripts/native_workflow_protocol.py', 'scripts/clickbench_reference_packet.py',
                     'scripts/clickbench_native_sql.py'):
        path = capture.common.HARNESS_DEFAULT / relative
        assert file_identity(path) == build_receipt['build_sources'][relative]
        proof.append(path)
    proof.extend([SELECTION, Path(__file__), N / 'tools/guard_shared_index.py',
        N / 'tools/replay_index_baseline.py',
        Path(repair.__file__), Path(capture.__file__), Path(repair.original.__file__),
        Path(repair.original.capture.__file__), repair.original.BINDING,
        Path(clock_verifier.__file__), E / 'tools/run_investigation_cohort_r2.py',
        E / 'tools/run_shared_10k.py', E / 'native-preparation/complete.json',
        D / 'release-build-r1.json', D / 'runtime-r1-identity.json', D / 'runtime-library-copy-r1.json'])
    proof_files = [identity(path) for path in sorted(set(proof))]
    unique = {}
    for row in [*frozen, *proof_files, *runtime.values()]:
        if row['path'] in unique:
            assert unique[row['path']] == row, 'conflicting file declarations: ' + row['path']
        unique[row['path']] = row
    frozen = list(unique.values())
    verify(frozen)
    return dict(design=design, inputs=dict(inputs, runtime=runtime), prepared=prepared,
        selected=selected, reused=reused, missing=missing, runtime=runtime,
        closeout=closeout, old_protocol=old_protocol, frozen=frozen, proof_files=proof_files,
        candidate_contract=candidate)


def verify_saved_reuse(ctx):
    """Reconstruct exactly the same complete requests; no native code is invoked."""
    old = D / 'correctness-cohort-r1'
    done, binding = read(old / 'complete.json'), read(old / 'binding.json')
    guard = read(D / 'correctness-cohort-r1.json')
    assert done['status'] == 'complete_observation' and done['stage'] == 'native'
    assert done['total'] == done['attempt_slots'] == 517 and done['outcomes'] == {'passed': 517}
    assert done['attempts_per_case'] == 1 and done['requested_repeats'] == 0 and done['posthash_verified']
    assert binding['contract'] == {key: done[key] for key in ('frozen', 'stage', 'prerequisites', 'updated')}
    assert done['updated'] == ctx['old_protocol']['runtime_binding']
    assert done['updated']['runtime'] == ctx['runtime']
    assert guard['status'] == 'passed' and guard['returncode'] == 0
    assert guard['process_group_drained'] and guard['direct_child_reaped'] and guard['query_workload']
    assert guard['fixed_source_validation'] and not guard['allow_lockfile_update']
    assert guard['active_output'] == str(old)
    assert guard['build_inventory_policy'] == guard['evidence_inventory_policy'] == 'before_and_after_only'
    assert guard['log_sha256'] == file_identity(D / 'correctness-cohort-r1.log')['sha256']
    assert guard['build_source_fingerprint_sha256'] == ctx['closeout']['source_fingerprint_sha256']
    assert guard['command'] == ['/Users/dylan/.cache/shardloom/query-surface-polars-2.1.0/bin/python',
        '-B', str(D / 'tools/run_correctness_cohort_r1.py')]
    verify([done['ledger'], done['binding'], done['frozen']])
    originals = {item.id: item for item in corpus(interactions='all', include_pending=False)}
    definitions = {item.name: item for item in spaces()}
    rows = []
    with ExitStack() as stack:
        db = stack.enter_context(closing_db(old / 'attempts.sqlite', readonly=True))
        refs = {profile: stack.enter_context(closing_db(E / ('reference-' + profile) / 'expectations.sqlite', readonly=True))
            for profile in {row['case']['profile'] for row in ctx['reused']}}
        assert dict(db.execute('SELECT status,COUNT(*) FROM attempt GROUP BY status')) == {'passed': 517}
        for selected in ctx['reused']:
            case = selected['case']
            item = build(case, definitions) if 'cell' in case else originals[case['id']]
            ref = refs[case['profile']].execute('SELECT identity,value FROM expected WHERE id=?', (case['id'],)).fetchone()
            assert ref and ref[0] == case['case_identity'] == item.identity
            expected = unpack(ref[1])
            entry = db.execute('SELECT seq,id,status,packet FROM attempt WHERE seq=?', (selected['repair_ordinal'],)).fetchone()
            assert entry and entry[:3] == (selected['repair_ordinal'], case['id'], 'passed')
            observed = replay(entry, case, 'native', expected, item, ctx['inputs'], ctx['prepared'], ctx['design']['execution'])
            assert observed['status'] == 'passed'
            clock_verifier.verify_clock(entry, observed)
            raw = raw_files(unpack(entry[3]))
            assert json.loads(raw['one.job.json']) == request(case, 'native', ctx['inputs'], ctx['prepared'], expected, ctx['design']['execution'])
            rows.append(dict(cohort_ordinal=selected['cohort_ordinal'], original_seq=selected['original_seq'],
                repair_ordinal=selected['repair_ordinal'], id=case['id'], case_identity=case['case_identity'],
                packet=dict(bytes=len(entry[3]), sha256=hashlib.sha256(entry[3]).hexdigest()),
                job_sha256=hashlib.sha256(raw['one.job.json']).hexdigest(),
                independent_expected_blob_sha256=hashlib.sha256(ref[1]).hexdigest(),
                expected_document_sha256=digest(expected), result=observed))
    verify([done['ledger'], done['binding'], done['frozen'], *ctx['frozen']])
    return dict(schema='shardloom.shared_index_baseline_reuse.v1', status='verified_saved_observations',
        query_executions=0, selected_reused_cases=433, primary_clock='engine_execution_seconds',
        accepted_merge=MERGE, accepted_tree=TREE, runtime=ctx['runtime'],
        selection=identity(SELECTION), original_protocol=identity(D / 'correctness-cohort-protocol-r1.json'),
        original_ledger=done['ledger'], original_complete=identity(old / 'complete.json'),
        original_guard=identity(D / 'correctness-cohort-r1.json'), rows=rows,
        all_complete_results_correct=True, all_engine_clocks_valid=True, no_external_fallback=True,
        exact_requests_and_expected_results=True, observation_files_unchanged=True,
        performance_claim=False, complete_10k_performance_claim=False)


def admission(root, require_protocol=True):
    assert root == E
    ctx = context()
    if require_protocol:
        reused = read(REUSE)
    else:
        assert not PROTOCOL.exists() and not REUSE.exists() and not TARGET.exists()
        reused = verify_saved_reuse(ctx)
        with REUSE.open('x') as output:
            json.dump(reused, output, indent=2, allow_nan=False); output.write('\n')
    assert reused['status'] == 'verified_saved_observations' and reused['selected_reused_cases'] == 433
    assert reused['selection'] == identity(SELECTION) and reused['runtime'] == ctx['runtime']
    assert [(r['cohort_ordinal'], r['original_seq'], r['repair_ordinal'], r['id'], r['case_identity']) for r in reused['rows']] == [
        (r['cohort_ordinal'], r['original_seq'], r['repair_ordinal'], r['case']['id'], r['case']['case_identity']) for r in ctx['reused']]
    updated = dict(schema='shardloom.shared_index_baseline_runtime.v1', role='accepted_baseline_missing_cases',
        accepted_merge=MERGE, accepted_tree=TREE, source_root=str(W),
        source_fingerprint_sha256=ctx['closeout']['source_fingerprint_sha256'],
        accepted_closeout=identity(CLOSEOUT), runtime=ctx['runtime'], proof_files=ctx['proof_files'],
        selection=identity(SELECTION), saved_reuse=identity(REUSE), target=str(TARGET),
        original_worker=identity(capture.WORKER), frozen_harness_files=65,
        attempts_per_case=1, warmups=0, requested_repeats=0, fallback_allowed=False)
    protocol = dict(schema='shardloom.shared_index_baseline_protocol.v1', status='frozen_before_new_queries',
        selected_count=2452, reused_count=433, missing_count=2019,
        candidate_contract=ctx['candidate_contract'],
        selection=identity(SELECTION), design=identity(E / 'design.json'), inputs=identity(E / 'inputs.json'),
        frozen=identity(E / 'frozen.json'), execution=ctx['design']['execution'], runtime_binding=updated,
        missing_cases=ctx['missing'], reuse=identity(REUSE), primary_clock='engine_execution_seconds',
        attempts_per_case=1, warmups=0, requested_repeats=0,
        selection_uses_timing=False, complete_10k_performance_claim=False,
        baseline_observations='433 exact saved repair results plus one new observation for each of 2019 missing cases; no synthetic full10k result',
        capture_changes='No capture-loop, worker, request, clock, per-query resource/storage guard or cleanup change; original cohort selection argument reused.',
        supervision_change='Outer guard now binds the accepted dictionary closeout and retained repair observations instead of superseded UUID/Variant runtimes. Same bounded supervisor, workload check, deadlines, storage limits and before/after-only full query inventories.',
        isolation='All other task work and agents idle during queries; no profiling, warmup, cache manipulation or artificial pacing.',
        performance_decision='After correctness, resource, ownership and no-fallback checks: lower engine time over all 2452 fixed cases retains; equal or higher drops. No minimum percentage.')
    if require_protocol:
        assert read(PROTOCOL) == protocol
    else:
        with PROTOCOL.open('x') as output:
            json.dump(protocol, output, indent=2, allow_nan=False); output.write('\n')
    frozen = [*ctx['frozen'], identity(REUSE), identity(PROTOCOL)]
    verify(frozen)
    return ctx['design'], ctx['inputs'], frozen, updated


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', action='store_true')
    args = parser.parse_args()
    os.environ['POLARS_MAX_THREADS'] = '2'
    for path in (N, E):
        capture.require_local_path(path, Path.home(), sys.platform)
    assert Path(__file__).resolve() == N / 'tools/run_index_baseline.py', 'unactivated draft cannot execute'
    if args.plan:
        admission(E, require_protocol=False)
        print(json.dumps(dict(status='frozen_before_new_queries', selected=2452, reused=433,
            missing=2019, query_executions=0)))
    else:
        protocol = read(PROTOCOL)
        selected = [row['case'] for row in protocol['missing_cases']]
        capture.TARGET_NAME = str(TARGET)
        capture.observe(E, False, admission, repair.historical(), selected)


if __name__ == '__main__':
    main()
