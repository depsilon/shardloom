"""Exercise evidence-corruption controls without executing native requests."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path

import verify_index_diagnostics as verifier

ROOT = Path(__file__).resolve().parents[1]


def main():
    if not __debug__:
        raise RuntimeError('corruption controls require assertion checks')
    before = json.loads((ROOT / 'baseline-attribution-observations-r3.json').read_bytes())['observations']
    after = json.loads((ROOT / 'candidate-attribution-observations-r1.json').read_bytes())['observations']
    assert len(verifier.compare_requests(before, after)) == 22
    controls = []

    def reject(label, change):
        corrupt = deepcopy(after)
        change(corrupt)
        try:
            verifier.compare_requests(before, corrupt)
        except AssertionError:
            controls.append(dict(control=label, outcome='rejected'))
        else:
            raise AssertionError('corruption accepted: ' + label)

    reject('missing_case', lambda rows: rows.pop())
    reject('reordered_cases', lambda rows: rows.reverse())
    reject('changed_row_domain', lambda rows: rows[0].update(input_rows_per_side=18))
    reject('changed_complete_result', lambda rows: rows[0].update(actual_sha256='0'*64, expected_sha256='0'*64))
    reject('changed_output_cardinality', lambda rows: rows[0].update(output_rows=0))
    reject('fallback_claim', lambda rows: rows[0].update(no_fallback=False))
    reject('unreleased_credit', lambda rows: rows[0].update(final_charged_bytes=1))
    reject('over_grant', lambda rows: rows[0].update(peak_charged_bytes=(64 << 20)+1))
    reject('changed_exact_equality_work', lambda rows: rows[11]['observations'].update(row_index_equality_calls=0))
    reject('changed_probe_order_work', lambda rows: rows[11]['observations'].update(row_index_probe_slots=0))
    reject('tiny_metadata_activation', lambda rows: rows[0]['observations'].update(row_index_metadata_groups=1))
    reject('missing_large_metadata_activation', lambda rows: rows[11]['observations'].update(row_index_metadata_groups=0))
    reject('wrong_screened_entry_count', lambda rows: rows[11]['observations'].update(row_index_large_entry_reads=0))
    reject('negative_counter', lambda rows: rows[11]['observations'].update(row_index_entry_reads=-1))
    report = dict(schema='shardloom.shared_index_diagnostic_corruption_controls.v1',
        status='passed', queries_executed=0, positive_controls=1, rejected_corruptions=len(controls),
        controls=controls, sources=[verifier.identity(Path(__file__)), verifier.identity(Path(verifier.__file__))],
        input_files=[verifier.identity(ROOT / name) for name in [
            'baseline-attribution-observations-r3.json', 'candidate-attribution-observations-r1.json']])
    with (ROOT / 'diagnostic-corruption-controls-r1.json').open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({key: report[key] for key in ['status', 'queries_executed', 'positive_controls', 'rejected_corruptions']}))


if __name__ == '__main__':
    main()
