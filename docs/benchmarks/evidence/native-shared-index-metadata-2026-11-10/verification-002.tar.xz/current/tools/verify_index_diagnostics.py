"""Replay the diagnostic evidence; counters describe work, never CPU time."""
import hashlib
import json
from pathlib import Path
import re

CASES = ['group_unique', 'group_repeat', 'inner_unique', 'inner_duplicates',
    'semi_missing', 'anti_missing', 'set_intersect', 'set_except',
    'window_partitions', 'window_distinct', 'correlated_in']
CHANGED_COUNTS = {'row_index_bucket_reads', 'row_index_entry_reads',
    'row_index_large_entry_reads', 'row_index_metadata_groups',
    'row_index_metadata_initialization_bytes'}


def identity(path):
    assert path.is_file() and not path.is_symlink()
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def log_rows(path, marker):
    pattern = re.compile(r'(?:^|\s)' + re.escape(marker) + r' (\{.*\})$')
    return [json.loads(match[1]) for line in path.read_text().splitlines()
            if (match := pattern.search(line)) is not None]


def compare_counts(before, after, large):
    assert set(before) == set(after)
    assert all(type(value) is int and value >= 0 for value in [*before.values(), *after.values()])
    assert {k: v for k, v in before.items() if k not in CHANGED_COUNTS} == {
        k: v for k, v in after.items() if k not in CHANGED_COUNTS}
    assert before['row_index_metadata_groups'] == before['row_index_metadata_initialization_bytes'] == 0
    if large:
        assert before['row_index_large_lookups'] > 0
        assert after['row_index_metadata_groups'] > 0 and after['row_index_metadata_initialization_bytes'] > 0
        assert after['row_index_large_entry_reads'] == before['row_index_large_fingerprint_candidates']
        assert after['row_index_entry_reads'] <= before['row_index_entry_reads']
        assert after['row_index_bucket_reads'] <= before['row_index_bucket_reads']
    else:
        assert before == after and after['row_index_large_lookups'] == 0


def compare_requests(before, after):
    if not __debug__:
        raise RuntimeError('diagnostic verification requires assertion checks')
    expected_order = [(case, rows) for rows in [17, 4097] for case in CASES]
    assert [(r['case'], r['input_rows_per_side']) for r in before] == expected_order
    assert [(r['case'], r['input_rows_per_side']) for r in after] == expected_order
    pairs = []
    for a, b in zip(before, after):
        omitted = {'observations', 'peak_charged_bytes'}
        assert {k: v for k, v in a.items() if k not in omitted} == {k: v for k, v in b.items() if k not in omitted}
        for row in [a, b]:
            assert row['complete_values_and_schema_match'] and row['no_fallback']
            assert not row['engine_timing_claimed'] and row['final_charged_bytes'] == 0
            assert row['actual_sha256'] == row['expected_sha256']
            assert type(row['peak_charged_bytes']) is int and 0 < row['peak_charged_bytes'] <= 64 << 20
        p, q = a['observations'], b['observations']
        compare_counts(p, q, b['input_rows_per_side'] == 4097)
        # Empty metadata does not promise zero embedded-owner size overhead.
        pairs.append(dict(case=b['case'], input_rows_per_side=b['input_rows_per_side'],
            baseline_peak_charged_bytes=a['peak_charged_bytes'], candidate_peak_charged_bytes=b['peak_charged_bytes'],
            peak_charged_delta_bytes=b['peak_charged_bytes']-a['peak_charged_bytes'],
            baseline_large_entry_reads=p['row_index_large_entry_reads'], candidate_large_entry_reads=q['row_index_large_entry_reads'],
            avoided_large_entry_reads=p['row_index_large_entry_reads']-q['row_index_large_entry_reads'],
            metadata_groups=q['row_index_metadata_groups'], metadata_initialization_bytes=q['row_index_metadata_initialization_bytes'],
            equal_result_sha256=b['actual_sha256']))
    return pairs


def verify(root):
    if not __debug__:
        raise RuntimeError('diagnostic verification requires assertion checks')
    before_path = root / 'baseline-attribution-observations-r3.json'
    after_path = root / 'candidate-attribution-observations-r1.json'
    before = json.loads(before_path.read_bytes())['observations']
    after = json.loads(after_path.read_bytes())['observations']
    assert before == log_rows(root / 'baseline-attribution-r3.log', 'ROW_INDEX_WORK')
    assert after == log_rows(root / 'candidate-mechanism-r1.log', 'ROW_INDEX_WORK')
    pairs = compare_requests(before, after)
    baseline_cyclic = log_rows(root / 'baseline-consumers-r1.log', 'CYCLIC_ROW_INDEX_WORK')
    candidate_cyclic = log_rows(root / 'candidate-mechanism-r1.log', 'CYCLIC_ROW_INDEX_WORK')
    expected = {(case, call) for case in ['abundant', 'rare', 'absent', 'skew_wide'] for call in [0, 1]}
    assert len(baseline_cyclic) == len(candidate_cyclic) == len(expected) == 8
    a = {(row['case'], row['call']): row['observations'] for row in baseline_cyclic}
    b = {(row['case'], row['call']): row['observations'] for row in candidate_cyclic}
    assert set(a) == set(b) == expected
    for key in expected:
        compare_counts(a[key], b[key], True)
    report_path = root / 'candidate-diagnostic-comparison-r2.json'
    report = json.loads(report_path.read_bytes())
    assert report['status'] == 'passed_frozen_contract'
    assert report['complete_requests'] == 22 and report['cyclic_calls'] == 8
    assert report['pairs'] == pairs
    assert {(row['case'], row['call']): row['baseline'] for row in report['cyclic']} == a
    assert {(row['case'], row['call']): row['candidate'] for row in report['cyclic']} == b
    for item in report['proof']:
        assert identity(Path(item['path'])) == item
    return dict(status='passed_independent_diagnostic_replay', complete_requests=22,
        cyclic_calls=8, query_executions=0, engine_time_attribution=None,
        large_entry_reads_before=sum(row['baseline_large_entry_reads'] for row in pairs),
        large_entry_reads_after=sum(row['candidate_large_entry_reads'] for row in pairs),
        proof=[identity(path) for path in [before_path, after_path, report_path,
            root / 'baseline-attribution-r3.log', root / 'baseline-consumers-r1.log',
            root / 'candidate-mechanism-r1.log', Path(__file__)]])
