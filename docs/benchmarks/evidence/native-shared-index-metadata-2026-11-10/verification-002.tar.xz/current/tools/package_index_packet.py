"""Collect compact, portable evidence for the single fixed shared-index candidate."""
from __future__ import annotations

import argparse
import importlib.util
import io
import json
from pathlib import Path
import re
import shutil
import tarfile
import tempfile

from verify_index_packet import (BASE, CHECKS, DOC_CHECKS, REPLAY_SUPPORT, digest, fingerprint, identity,
    replay_saved, rust_counts, verify, verify_diagnostics, verify_sources)

N = Path(__file__).resolve().parents[1]
S = N.parent / 'shared-operator-state-2026-11-10'
D = N.parent / 'dictionary-execution-repair-2026-11-10'
K = N.parent / 'variant-expressions-2026-11-10'
E = N.parent / 'expanded-query-2026-11-03'
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')


def read(path):
    return json.loads(path.read_bytes())


def collect(execution_name):
    result = read(N / 'candidate-verified-r1.json')
    assert result['selected_cases'] == 2452 and result['new_attempts'] == 2452
    protocol = read(N / 'candidate-protocol-r1.json')
    baseline = read(N / 'baseline-protocol-r1.json')
    data, locations, external = {}, {}, {}

    def mapped(path):
        if path.is_relative_to(E / 'investigation-original-harness-r1'):
            relative = path.relative_to(E / 'investigation-original-harness-r1').as_posix()
            if relative in REPLAY_SUPPORT:
                return 'protocol-support/' + relative
        for root, prefix in ((N, 'current'), (S, 'preparation'), (D, 'repair'), (K, 'prior'),
                (E / 'investigation-original-harness-r1', 'harness'), (E, 'frozen'),
                (W / 'docs/release/evidence', 'prior-packets'), (W, 'source-imports')):
            if path.is_relative_to(root):
                return prefix + '/' + path.relative_to(root).as_posix()
        raise AssertionError('unclassified proof path: ' + str(path))

    def add(path, name=None):
        name = name or mapped(path)
        assert path.is_file() and not path.is_symlink(), path
        raw = path.read_bytes()
        assert name not in data or data[name] == raw
        assert str(path) not in locations or locations[str(path)] == name
        data[name], locations[str(path)] = raw, name
        return raw

    for path in sorted([*N.glob('*.json'), *N.glob('*.log'), *N.glob('tools/*.py')]):
        if path.name not in (execution_name + '.json', execution_name + '.log'):
            add(path)
    for name in ('adversarial-review-r1.md', 'adversarial-review-r2.md'):
        add(N / name)
    # Preserve failed/draft package manifests and verifier source, but not
    # another copy of their archive payloads.
    for previous in sorted(N.glob('packet-r[0-9]*')):
        if previous.is_dir():
            for name in ('acceptance.json', 'verify.py'):
                path = previous / name
                if path.is_file():
                    add(path)
    for prefix in ('baseline-missing-r1', 'candidate-r1'):
        for name in ('complete.json', 'binding.json', 'attempts.sqlite'):
            add(N / prefix / name)
    for path in sorted(N.glob('*-cases-r1.jsonl.gz')):
        add(path)
    for row in protocol['runtime_binding']['proof_files']:
        path = Path(row['path'])
        wanted = dict(bytes=row['generation']['bytes'], sha256=row['sha256'])
        if path.parent == D / 'runtime-r1':
            assert path.name in ('shardloom', 'lib_native.dylib', '_native.abi3.so')
            role = 'accepted_runtime_identity'
        elif path.is_relative_to(W / 'docs/release/evidence') and path.name.endswith('.tar.xz'):
            role = 'historical_committed_archive_identity'
        else:
            assert identity(add(path)) == wanted
            continue
        # Validate the actual retained payload before recording its identity.
        # Payloads themselves are neither duplicated nor archived for rollback.
        with path.open('rb') as stream:
            import hashlib
            assert dict(bytes=path.stat().st_size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest()) == wanted
        external[str(path)] = dict(role=role, identity=wanted)
    for row in baseline['candidate_contract']['sources']:
        assert identity(add(Path(row['path']))) == dict(bytes=row['generation']['bytes'], sha256=row['sha256'])
    for name in ('baseline-missing-r1/binding.json', 'baseline-missing-r1/complete.json',
                 'candidate-r1/binding.json', 'candidate-r1/complete.json'):
        add(N / name)
    for name in ('correctness-cohort-r1/binding.json', 'correctness-cohort-r1/complete.json',
                 'correctness-cohort-r1/attempts.sqlite', 'correctness-cohort-r1.json', 'correctness-cohort-r1.log',
                 'release-build-r1.json', 'dictionary-repair-closeout-r1.json'):
        add(D / name)
    for name in ('design.json', 'inputs.json', 'frozen.json', 'native-preparation/complete.json',
                 'investigation-original-harness-source-r1.json'):
        add(E / name)
    frozen = read(E / 'frozen.json')
    for row in frozen['references']:
        assert identity(add(Path(row['path']))) == dict(bytes=row['generation']['bytes'], sha256=row['sha256'])
    manifest = read(E / 'investigation-original-harness-source-r1.json')
    for relative, sha256 in manifest['harness_sha256'].items():
        path = E / 'investigation-original-harness-r1' / relative
        assert digest(add(path)) == sha256
        original = [row for row in frozen['harness'] if row['path'].endswith('/' + relative)]
        assert len(original) == 1 and original[0]['sha256'] == sha256
        locations[original[0]['path']] = 'harness/' + relative
    # Preserve the original failed observation's status; its complete raw
    # packets remain in the identified predecessor collection.
    add(S / 'current-baseline-10k-r1/failed-observation-replay-r1.json')
    wanted = {}
    for name, raw in list(data.items()):
        if not name.endswith('.json'):
            continue
        try:
            record = json.loads(raw)
        except (json.JSONDecodeError, UnicodeDecodeError):
            continue
        if not isinstance(record, dict):
            continue
        # Changed-path receipts can also name already committed archive
        # payloads. Their identities stay in the receipt; only build and tool
        # source inventories require content-addressed source bytes here.
        for key in ('build_sources', 'tool_source_inventory'):
            for item in record.get(key, {}).values():
                if 'sha256' in item and 'symlink' not in item:
                    assert item['sha256'] not in wanted or wanted[item['sha256']] == item
                    wanted[item['sha256']] = item
        for key in ('source', 'sources'):
            items = record.get(key, [])
            if not isinstance(items, list):
                continue
            for item in items:
                if isinstance(item, dict) and Path(item.get('path', '')).suffix in ('.py', '.rs', '.sh') and 'sha256' in item:
                    size = item.get('bytes', item.get('generation', {}).get('bytes'))
                    assert type(size) is int
                    wanted[item['sha256']] = dict(bytes=size, sha256=item['sha256'])
    existing_bytes = {digest(raw): raw for raw in data.values()}
    predecessor = None
    for sha256, item in sorted(wanted.items()):
        found = [root / 'source-blobs' / sha256 for root in (N, D, S, K)
            if (root / 'source-blobs' / sha256).is_file()]
        if found:
            raw = add(found[0], 'source-blobs/' + sha256)
        elif sha256 in existing_bytes:
            raw = existing_bytes[sha256]
            data['source-blobs/' + sha256] = raw
        else:
            if predecessor is None:
                root = W / 'docs/release/evidence/native-dictionary-execution-repair-2026-11-10'
                spec = importlib.util.spec_from_file_location('accepted_dictionary_packet', root / 'verify.py')
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                _, predecessor_data = module.read_archive(root)
                # Older helper source can be an ordinary archive member rather
                # than a source-blobs entry. Its full content identity is the
                # same proof regardless of that historical storage name.
                predecessor = {digest(raw): raw for raw in predecessor_data.values()}
            raw = predecessor[sha256]
            data['source-blobs/' + sha256] = raw
        assert identity(raw) == item
    build = read(N / 'release-build-r1.json')
    checks = {name: dict(command=command, status='passed', rust_tests=rust_counts(data['current/' + name + '.log']))
        for name, command in CHECKS.items()}
    failures = []
    dispositions = read(N / 'failure-dispositions-r1.json')
    for name, raw in sorted(data.items()):
        if not name.startswith('current/') or name.count('/') != 1 or not name.endswith('.json'):
            continue
        record = json.loads(raw)
        if isinstance(record, dict) and (str(record.get('status')).startswith('failed') or record.get('status') == 'interrupted'):
            key = name.removeprefix('current/')
            assert dispositions[key]
            failures.append(dict(receipt=name, identity=identity(raw), disposition=dispositions[key]))
    assert set(dispositions) == {row['receipt'].removeprefix('current/') for row in failures}
    report = dict(schema='shardloom.shared_index_acceptance.v1', status='local_candidate_decision_recorded',
        source_base=BASE, candidate_source_snapshot=build['build_sources'],
        candidate_source_fingerprint_sha256=fingerprint(build['build_sources']), checks=checks,
        documentation_checks={name: dict(command=command, status='passed',
            rust_tests=rust_counts(data['current/' + name + '.log'])) for name, command in DOC_CHECKS.items()},
        disposition=result['frozen_rule_disposition'], original_failed_checks=failures,
        baseline=dict(cases=2452, reused_saved_cases=433, new_attempts=2019, engine_execution_seconds=320.508980218),
        candidate={key: result[key] for key in ('selected_cases', 'outcomes', 'engine_execution_seconds',
            'engine_seconds_saved', 'observed_engine_reduction_percent', 'complete_performance_result_valid')},
        complete_10k_performance_claim=False, whole_item_19_complete=False, whole_item_20_complete=False,
        publication_attempted=False, hosted_integration='pending',
        source_policy='Exact validated candidate source; named status prose may advance. If the fixed complete score drops the candidate, the accepted baseline source must be restored.',
        limitations=[
            'This is one frozen 2452-case cohort, not a new full10k observation or a broad superiority claim.',
            'The baseline explicitly combines 433 saved repair cases and 2019 newly measured cases from separate isolated sessions.',
            'One candidate execution per case; no repeats, warmup, cache manipulation or statistical confidence claim.',
            'Work counters come from separate debug-only correctness diagnostics, not the scored ordinary release runtime or CPU-time attribution.',
            'Runtime/input payloads and prior committed archive payloads are represented by exact identities; this collection does not duplicate them.',
            'The original failed10000case observation remains invalid; its complete bytes remain in the identified dictionary-repair collection.',
            'Hosted integration, final retention, remaining item19/item20/RFC0044 and CG1through23 are separate obligations.',
        ], identity_only_proof=dict(sorted(external.items())), locations=dict(sorted(locations.items())),
        members=[dict(path=name, **identity(raw)) for name, raw in sorted(data.items())])
    assert sum(len(raw) for raw in data.values()) < 512 << 20
    return report, data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destination', type=Path, required=True)
    parser.add_argument('--execution-name', required=True)
    parser.add_argument('--preflight-only', action='store_true')
    parser.add_argument('--replay-preflight', action='store_true')
    args = parser.parse_args()
    assert args.destination.resolve().is_relative_to(N) and not args.destination.exists()
    assert re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', args.execution_name)
    assert not args.replay_preflight or args.preflight_only
    report, data = collect(args.execution_name)
    packet = verify_sources(report, data, W)
    if args.preflight_only:
        replay = None
        if args.replay_preflight:
            verify_diagnostics(packet)
            with tempfile.TemporaryDirectory(prefix='index-replay-preflight-', dir=N) as temporary:
                replay = replay_saved(report, data, Path(temporary))
        print(json.dumps(dict(status='passed_collection_preflight', query_executions=0,
            logical_files=len(data), logical_bytes=sum(len(raw) for raw in data.values()),
            archives_written=0, replay=replay)))
        return
    stored, assemblies = {}, []
    for name, raw in sorted(data.items()):
        if len(raw) <= 24 << 20:
            stored[name] = raw
        else:
            parts = []
            for ordinal, offset in enumerate(range(0, len(raw), 24 << 20)):
                part = 'parts/' + digest(name.encode()) + '/' + str(ordinal).zfill(4)
                assert part not in stored
                stored[part] = raw[offset:offset + (24 << 20)]
                parts.append(part)
            assemblies.append(dict(path=name, parts=parts, **identity(raw)))
    report['assemblies'] = assemblies
    report['stored_members'] = [dict(path=name, **identity(raw)) for name, raw in sorted(stored.items())]
    groups, group, total = [], [], 0
    for row in report['stored_members']:
        if group and total + row['bytes'] > 48 << 20:
            groups.append(group)
            group, total = [], 0
        group.append(row)
        total += row['bytes']
    if group:
        groups.append(group)
    args.destination.mkdir()
    report['archives'] = []
    for ordinal, group in enumerate(groups):
        path = args.destination / f'verification-{ordinal + 1:03d}.tar.xz'
        with tarfile.open(path, 'w:xz', preset=6) as archive:
            for row in group:
                entry = tarfile.TarInfo(row['path'])
                entry.size, entry.mode, entry.mtime = row['bytes'], 0o644, 0
                archive.addfile(entry, io.BytesIO(stored[row['path']]))
        raw = path.read_bytes()
        assert len(raw) < 64 << 20
        report['archives'].append(dict(path=path.name, members=[row['path'] for row in group], **identity(raw)))
    (args.destination / 'acceptance.json').write_text(json.dumps(report, indent=2) + '\n')
    shutil.copyfile(N / 'tools/verify_index_packet.py', args.destination / 'verify.py')
    del data, stored
    print(json.dumps(verify(args.destination, W), sort_keys=True))


if __name__ == '__main__':
    main()
