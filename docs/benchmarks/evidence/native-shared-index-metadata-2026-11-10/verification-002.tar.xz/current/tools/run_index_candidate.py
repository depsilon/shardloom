"""Bind one ordinary-runtime candidate to the already frozen shared-index cohort.

The capture loop, worker, request builder, comparisons, clocks and inner guards
are the immutable helpers used by the accepted baseline. Only the runtime and
its explicitly verified source/check provenance change. --plan executes no query.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import sys

import run_index_baseline as baseline
import verify_index_diagnostics as diagnostics
from query_surface.evidence import identity
from query_surface.expanded_freeze import read
from query_surface.expanded_run import verify

N, D, S, E, W = baseline.N, baseline.D, baseline.S, baseline.E, baseline.W
repair, capture = baseline.repair, baseline.capture
TARGET = N / 'candidate-r1'
PROTOCOL = N / 'candidate-protocol-r1.json'
RUNTIME = N / 'runtime-r1'
BUILD = N / 'release-build-r1.json'
LIBRARY = RUNTIME / '_native.abi3.so'
BASELINE_PROTOCOL_SHA256 = '326742c88a96116aff6f4bd77d2222270268e864013c41b3dce537ea6ef91ab5'
BASELINE_RESULT_SHA256 = '6e7e36ebfb2d11a8fb650c6710e6c460d39fc9ef0c55e7e9aaf553f495668e36'
FEATURES = 'shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment'
BUILD_COMMAND = ['env', 'PYO3_PYTHON=/opt/homebrew/opt/python@3.13/libexec/bin/python3',
    'cargo', 'build', '--offline', '--locked', '--release', '--features', 'release-user-surfaces',
    '-p', 'shardloom-cli', '-p', 'shardloom-python']
CHECK_COMMANDS = {
    'format-r1': ['cargo', 'fmt', '--all', '--', '--check'],
    'default-clippy-r1': ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings'],
    'default-tests-r1': ['env', 'RUST_TEST_THREADS=4', 'cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets'],
    'native-clippy-r2': ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--features', FEATURES, '--', '-D', 'warnings'],
    'native-tests-r1': ['env', 'RUST_TEST_THREADS=4', 'cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets', '--features', FEATURES],
    'candidate-mechanism-r1': ['env', 'SHARDLOOM_PROBE_ATTRIBUTION_OUTPUT=' + str(N / 'candidate-attribution-observations-r1.json'),
        'cargo', 'test', '--offline', '--locked', '--workspace', '--lib', '--features', FEATURES, '--',
        'local_primitives::native_relational_index::', 'cyclic_candidate_counts_actual_work_for_all_four_frozen_targets',
        'native_row_index_complete_request_attribution', '--include-ignored', '--nocapture', '--test-threads=1'],
}


def file_identity(path):
    return baseline.file_identity(path)


def guard_proof(path, command, sources):
    record = read(path)
    assert record['status'] == 'passed' and record['returncode'] == 0
    assert record['command'] == command
    assert record['process_group_drained'] and record['direct_child_reaped']
    assert record['fixed_source_validation'] and not record['allow_lockfile_update']
    assert record['build_sources'] == sources
    assert record['build_source_fingerprint_sha256'] == baseline.digest(sources)
    assert record['base'] == baseline.MERGE and record['head'] == baseline.git('rev-parse', 'HEAD')
    for stage in ('pre_execution', 'post_execution'):
        check = record['build_source_verification'][stage]
        assert check['head_matches'] and check['path_set_matches'] and not check['changed_paths']
        assert check['fingerprint_sha256'] == record['build_source_fingerprint_sha256']
    assert record['log_sha256'] == file_identity(path.with_suffix('.log'))['sha256']
    return record


def baseline_proof():
    assert file_identity(baseline.PROTOCOL)['sha256'] == BASELINE_PROTOCOL_SHA256
    protocol = read(baseline.PROTOCOL)
    result_path = N / 'baseline-verified-r1.json'
    assert file_identity(result_path)['sha256'] == BASELINE_RESULT_SHA256
    result = read(result_path)
    assert result['status'] == 'passed_complete_baseline_cohort'
    assert result['selected_cases'] == 2452 and result['reused_saved_cases'] == 433 and result['new_attempts'] == 2019
    assert result['outcomes'] == {'passed': 2452} and result['complete_performance_result_valid']
    assert result['all_selected_results_correct'] and result['all_engine_clocks_valid'] and result['native_no_fallback']
    assert result['primary_clock'] == 'engine_execution_seconds' and not result['complete_10k_performance_claim']
    assert result['protocol'] == identity(baseline.PROTOCOL)
    assert result['selection'] == protocol['selection'] == identity(baseline.SELECTION)
    assert result['runtime_binding'] == protocol['runtime_binding']
    verify([result[key] for key in ('case_rows', 'guard', 'complete', 'ledger', 'reuse')])
    with gzip.open(result['case_rows']['path'], 'rt') as stream:
        rows = [json.loads(line) for line in stream]
    selection = read(baseline.SELECTION)['cases']
    assert len(rows) == len(selection) == 2452
    for ordinal, (row, selected) in enumerate(zip(rows, selection)):
        case = selected['case']
        assert row['cohort_ordinal'] == ordinal and row['original_seq'] == selected['original_seq']
        assert row['id'] == case['id'] and row['case_identity'] == case['case_identity']
        assert row['result']['status'] == 'passed'
        seconds = row['result']['engine_seconds']
        assert type(seconds) in (int, float) and math.isfinite(seconds) and seconds >= 0
    assert math.fsum(row['result']['engine_seconds'] for row in rows) == result['engine_execution_seconds']
    guard = read(N / 'baseline-missing-r1.json')
    assert guard['status'] == 'passed' and guard['returncode'] == 0
    assert guard['head'] == guard['base'] == baseline.MERGE and not guard['working_tree']
    assert guard['query_workload'] and guard['process_group_drained'] and guard['direct_child_reaped']
    assert guard['build_inventory_policy'] == guard['evidence_inventory_policy'] == 'before_and_after_only'
    assert guard['log_sha256'] == file_identity(N / 'baseline-missing-r1.log')['sha256']
    proof = [baseline.PROTOCOL, result_path, N / 'baseline-reuse-r1.json',
        N / 'baseline-cases-r1.jsonl.gz', N / 'baseline-missing-r1.json', N / 'baseline-missing-r1.log',
        N / 'baseline-missing-r1/complete.json', N / 'baseline-missing-r1/binding.json',
        N / 'baseline-missing-r1/attempts.sqlite', N / 'baseline-replay-r1.json', N / 'baseline-replay-r1.log']
    for item in protocol['candidate_contract']['sources']:
        assert identity(Path(item['path'])) == item
        proof.append(Path(item['path']))
    for item in protocol['runtime_binding']['proof_files']:
        assert identity(Path(item['path'])) == item
        proof.append(Path(item['path']))
    return protocol, result, proof


def runtime_proof():
    if not __debug__:
        raise RuntimeError('candidate admission requires assertion checks')
    sources = repair.source_inventory()
    build = guard_proof(BUILD, BUILD_COMMAND, sources)
    proof = [BUILD, BUILD.with_suffix('.log')]
    for name, command in CHECK_COMMANDS.items():
        path = N / (name + '.json')
        guard_proof(path, command, sources)
        proof.extend((path, path.with_suffix('.log')))
    # The ordinary full native suite executes every frozen consumer control;
    # the explicit mechanism check also executes its one ignored diagnostic.
    log = (N / 'native-tests-r1.log').read_text()
    tests = read(S / 'reuse-metadata-r1/consumer-test-manifest-primary-r1.json')
    assert len(tests['tests']) == 41
    for row in tests['tests']:
        assert 'test ' + row['exact_test_name'] + ' ... ok\n' in log
    mechanism = (N / 'candidate-mechanism-r1.log').read_text()
    assert 'test result: ok. 16 passed; 0 failed; 0 ignored;' in mechanism
    for name in ('candidate-diagnostic-comparison-r2.json', 'candidate-attribution-observations-r1.json',
                 'baseline-diagnostics-r1.json', 'baseline-attribution-observations-r3.json'):
        proof.append(N / name)
    comparison = read(N / 'candidate-diagnostic-comparison-r2.json')
    diagnostic_replay = diagnostics.verify(N)
    assert diagnostic_replay['status'] == 'passed_independent_diagnostic_replay'
    proof.extend(Path(item['path']) for item in diagnostic_replay['proof'])
    controls_path = N / 'diagnostic-corruption-controls-r1.json'
    controls = read(controls_path)
    assert controls['status'] == 'passed' and controls['queries_executed'] == 0
    assert controls['positive_controls'] == 1 and controls['rejected_corruptions'] == 14
    assert len(controls['controls']) == 14 and all(item['outcome'] == 'rejected' for item in controls['controls'])
    proof.append(controls_path)
    for item in [*controls['sources'], *controls['input_files']]:
        assert diagnostics.identity(Path(item['path'])) == item
        proof.append(Path(item['path']))
    assert comparison['status'] == 'passed_frozen_contract'
    assert comparison['complete_requests'] == 22 and comparison['cyclic_calls'] == 8
    assert comparison['all_output_identities_equal'] and comparison['all_final_credits_zero']
    assert comparison['stable_work_counters_equal'] and comparison['large_entry_screening_matches_baseline_predictions']
    for item in comparison['proof']:
        path = Path(item['path'])
        assert file_identity(path) == {key: item[key] for key in ('bytes', 'sha256')}
        proof.append(path)
    record_path = N / 'runtime-r1-identity.json'
    record = read(record_path)
    assert record['status'] == 'passed' and record['profile'] == 'release'
    assert record['build_receipt'] == BUILD.name and record['build_receipt_identity'] == file_identity(BUILD)
    assert record['build_source_fingerprint_sha256'] == build['build_source_fingerprint_sha256']
    files = {Path(row['path']).name: row for row in record['files']}
    assert set(files) == {'shardloom', 'lib_native.dylib'}
    for name, item in files.items():
        path = Path(item['path'])
        assert path == RUNTIME / name
        assert file_identity(path) == {key: item[key] for key in ('bytes', 'sha256')}
    proof.append(record_path)
    return build, files, proof


def prepare_library():
    _, files, _ = runtime_proof()
    source = Path(files['lib_native.dylib']['path'])
    receipt = N / 'runtime-library-copy-r1.json'
    assert not LIBRARY.exists() and not receipt.exists()
    expected = file_identity(source)
    shutil.copy2(source, LIBRARY)
    assert file_identity(LIBRARY) == expected == file_identity(source)
    with receipt.open('x') as stream:
        json.dump(dict(status='passed', source=identity(source), destination=identity(LIBRARY),
            byte_identical=True, queries_executed=0), stream, indent=2)
        stream.write('\n')


def context():
    repair.verify_capture()
    old_protocol, old_result, proof = baseline_proof()
    build, files, runtime_files = runtime_proof()
    proof.extend(runtime_files)
    copy_path = N / 'runtime-library-copy-r1.json'
    copied = read(copy_path)
    assert copied['status'] == 'passed' and copied['byte_identical'] and copied['queries_executed'] == 0
    assert copied['source'] == identity(RUNTIME / 'lib_native.dylib')
    assert copied['destination'] == identity(LIBRARY)
    assert file_identity(LIBRARY) == file_identity(RUNTIME / 'lib_native.dylib')
    runtime = dict(binary=identity(Path(files['shardloom']['path'])), library=identity(LIBRARY))
    historical = repair.historical()
    with historical.admission_verifier(capture.common):
        design, inputs, frozen, relocated, archive, _ = capture.common.checked_admission(capture.common.ROOT_DEFAULT, E)
    selected, reused, missing = baseline.selected_cases(design)
    assert len(reused) == 433 and len(missing) == 2019
    assert old_protocol['execution'] == design['execution']
    for name in ('design', 'inputs', 'frozen'):
        assert old_protocol[name] == identity(E / (name + '.json'))
    assert old_protocol['runtime_binding']['original_worker'] == identity(capture.WORKER)
    assert old_protocol['runtime_binding']['frozen_harness_files'] == len(relocated) == 65
    prepared = read(E / 'native-preparation/complete.json')
    prepared_files = [f for profile in prepared['profiles'].values()
        for f in [profile['manifest'], *profile['inputs'], *profile['receipts']]]
    frozen = [*historical.files(frozen), *historical.files(prepared_files), *archive]
    accepted_build = read(D / 'release-build-r1.json')
    for relative in ('scripts/native_workflow_protocol.py', 'scripts/clickbench_reference_packet.py', 'scripts/clickbench_native_sql.py'):
        path = capture.common.HARNESS_DEFAULT / relative
        assert file_identity(path) == accepted_build['build_sources'][relative]
        proof.append(path)
    proof.extend([copy_path, Path(__file__), N / 'tools/replay_index_candidate.py',
        N / 'tools/guard_shared_index.py', Path(baseline.__file__), Path(repair.__file__),
        Path(capture.__file__), Path(repair.original.__file__), Path(repair.original.capture.__file__),
        repair.original.BINDING, Path(baseline.clock_verifier.__file__),
        E / 'tools/run_shared_10k.py', E / 'tools/run_investigation_cohort_r2.py', E / 'native-preparation/complete.json'])
    proof_files = [identity(path) for path in sorted(set(proof))]
    unique = {}
    for item in [*frozen, *proof_files, *runtime.values()]:
        if item['path'] in unique:
            assert unique[item['path']] == item
        unique[item['path']] = item
    frozen = list(unique.values())
    verify(frozen)
    return dict(design=design, inputs=dict(inputs, runtime=runtime), selected=selected,
        runtime=runtime, build=build, frozen=frozen, proof_files=proof_files,
        baseline_protocol=old_protocol, baseline_result=old_result)


def admission(root, require_protocol=True):
    assert root == E
    ctx = context()
    updated = dict(schema='shardloom.shared_index_candidate_runtime.v1', role='single_fixed_cohort_candidate',
        accepted_base=baseline.MERGE, source_root=str(W), source_head=ctx['build']['head'],
        source_fingerprint_sha256=ctx['build']['build_source_fingerprint_sha256'],
        runtime=ctx['runtime'], proof_files=ctx['proof_files'], selection=identity(baseline.SELECTION),
        baseline_protocol=identity(baseline.PROTOCOL), target=str(TARGET),
        original_worker=identity(capture.WORKER), frozen_harness_files=65,
        attempts_per_case=1, warmups=0, requested_repeats=0, fallback_allowed=False)
    protocol = dict(schema='shardloom.shared_index_candidate_protocol.v1', status='frozen_before_candidate_queries',
        selected_count=2452, candidate_contract=ctx['baseline_protocol']['candidate_contract'],
        baseline_protocol=identity(baseline.PROTOCOL), baseline_result=identity(N / 'baseline-verified-r1.json'),
        selection=identity(baseline.SELECTION), design=identity(E / 'design.json'), inputs=identity(E / 'inputs.json'),
        frozen=identity(E / 'frozen.json'), execution=ctx['design']['execution'], runtime_binding=updated,
        cases=ctx['selected']['cases'], primary_clock='engine_execution_seconds', attempts_per_case=1,
        warmups=0, requested_repeats=0, selection_uses_timing=False, complete_10k_performance_claim=False,
        baseline_observations=ctx['baseline_protocol']['baseline_observations'],
        capture_changes='Unchanged baseline capture loop, worker, requests, clocks, per-query guards and cleanup; all 2452 preselected cases execute once.',
        supervision_change='Same activated shared-index guard, limits and before/after-only full query inventories; new candidate runtime/source/check admission.',
        isolation=ctx['baseline_protocol']['isolation'], performance_decision=ctx['baseline_protocol']['performance_decision'])
    if require_protocol:
        assert read(PROTOCOL) == protocol
    else:
        assert not PROTOCOL.exists() and not TARGET.exists()
        with PROTOCOL.open('x') as stream:
            json.dump(protocol, stream, indent=2, allow_nan=False)
            stream.write('\n')
    frozen = [*ctx['frozen'], identity(PROTOCOL)]
    verify(frozen)
    return ctx['design'], ctx['inputs'], frozen, updated


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--plan', action='store_true')
    mode.add_argument('--prepare-library', action='store_true')
    args = parser.parse_args()
    assert Path(__file__).resolve() == N / 'tools/run_index_candidate.py'
    os.environ['POLARS_MAX_THREADS'] = '2'
    for path in (N, E):
        capture.require_local_path(path, Path.home(), sys.platform)
    if args.prepare_library:
        prepare_library()
        print(json.dumps(dict(status='byte_identical_library_copy', query_executions=0)))
    elif args.plan:
        admission(E, require_protocol=False)
        print(json.dumps(dict(status='frozen_before_candidate_queries', selected=2452, query_executions=0)))
    else:
        protocol = read(PROTOCOL)
        capture.TARGET_NAME = str(TARGET)
        capture.observe(E, False, admission, repair.historical(), [row['case'] for row in protocol['cases']])


if __name__ == '__main__':
    main()
