"""Validate the exact ignored-test registration without executing native tests."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

N = Path(__file__).resolve().parents[1]
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
HEAD = 'c935ed5036c9dce061bcf91724a6423a069004f4'
POLICY = '.github/ci-native-baseline.json'
NAME = 'local_primitives::prepared_relational::tests::probe_attribution_tests::native_row_index_complete_request_attribution'
EXPERIMENT = 'resident_memory_source::arrow_intake::exchange_fixture_tests::'
sys.path.insert(0, str(W / 'scripts'))
import ci_native_tests as native


def identity(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


before_raw = subprocess.check_output(['git', 'show', HEAD + ':' + POLICY], cwd=W)
after_raw = (W / POLICY).read_bytes()
before, after = json.loads(before_raw), json.loads(after_raw)
assert NAME not in before['ignored_tests'] and len(before['ignored_tests']) == 33
expected = {**before, 'ignored_tests': sorted([*before['ignored_tests'], NAME])}
assert after == expected
anchor = b'    "local_primitives::prepared_relational::tests::selection_cost_tests::native_selection_complete_cost_screen",\n'
assert before_raw.count(anchor) == 1
assert after_raw == before_raw.replace(anchor, ('    "' + NAME + '",\n').encode() + anchor)
raw = (N / 'native-tests-r1.log').read_text()
match = re.search(r'Running unittests src/lib.rs \(([^\n]*shardloom_vortex-[0-9a-f]+)\)\n(.*?test result: ok\.[^\n]+)', raw, re.S)
assert match
binary = Path(match.group(1))
assert binary.is_file() and not binary.is_symlink()
tests = native.discover(binary, root=W)
ignored = native.discover(binary, ignored=True, root=W)
outcomes = re.findall(r'^test (.*?) \.\.\. (ok|ignored)(?:[^\n]*)$', match.group(2), re.M)
assert tests == sorted(name.removesuffix(' - should panic') for name, _ in outcomes)
assert ignored == sorted(name for name, result in outcomes if result == 'ignored')
assert sorted(set(ignored) - set(after['ignored_tests'])) == [EXPERIMENT + 'independent_exchange_fixtures_and_encoded_arrow_controls']
assert set(after['ignored_tests']) <= set(ignored)
assert '#[cfg(all(test, feature = "native-encoded-exchange-experiment"))]\n#[path = "resident_memory_exchange_fixture_tests.rs"]\nmod exchange_fixture_tests;' in (W / 'shardloom-vortex/src/resident_memory_arrow.rs').read_text()
assert '#[cfg(debug_assertions)]\n#[path = "local_primitive_relational_probe_attribution_tests.rs"]\nmod probe_attribution_tests;' in (W / 'shardloom-vortex/src/local_primitive_relational_tests.rs').read_text()
ci_tests = [name for name in tests if not name.startswith(EXPERIMENT)]
ci_ignored = [name for name in ignored if not name.startswith(EXPERIMENT)]
try:
    native.partition_tests(ci_tests, ci_ignored, before)
except ValueError as error:
    assert str(error) == 'native ignored-test policy changed'
else:
    raise AssertionError('old policy unexpectedly accepted')
partitions = native.partition_tests(ci_tests, ci_ignored, after)
native.verify_coverage(ci_tests, partitions)
result = subprocess.run([sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'scripts', '-p', 'test_ci_native_tests.py', '-v'], cwd=W, capture_output=True, text=True, timeout=120)
assert result.returncode == 0, result.stdout + result.stderr
assert re.search(r'Ran \d+ tests in [\d.]+s\n\nOK\n', result.stderr)
print(json.dumps(dict(status='passed', query_executions=0, native_test_executions=0,
    policy_path=POLICY, source_head=HEAD, before=identity(before_raw), after=identity(after_raw),
    added_ignored_tests=[NAME], removed_ignored_tests=[], old_policy_rejected=True,
    local_inventory_matches_passed_native_log=True, local_tests=len(tests), local_ignored=len(ignored),
    native_log=identity((N / 'native-tests-r1.log').read_bytes()),
    binary=identity(binary.read_bytes()), experimental_module_excluded=EXPERIMENT,
    projected_tests=len(ci_tests), projected_ignored=len(ci_ignored), partitions=partitions,
    exact_hosted_inventory_still_required=True, unit_test_command=result.args,
    unit_test_stdout=result.stdout, unit_test_stderr=result.stderr), indent=2))
