"""Check public references and shared-index status documentation against the tested runtime."""
from pathlib import Path
import subprocess
import sys

D = Path(__file__).resolve().parents[1]
commands = [
    ['scripts/write_native_function_reference.py','--check','--native-library',str(D/'runtime-r1/lib_native.dylib')],
    ['scripts/write_public_api_reference.py','--check','--binary',str(D/'runtime-r1/shardloom')],
    ['scripts/write_python_api_exports.py','--check'],
    ['scripts/check_user_surface_reference.py'],
    ['scripts/check_python_license_bundle.py'],
    ['scripts/check_public_status_docs.py','--output',str(D/'public-status-docs-r1.json')],
    ['scripts/check_contribution_governance.py','--output',str(D/'contribution-governance-r1.json')],
]
for command in commands:
    print('Checking '+command[0],flush=True)
    subprocess.run([sys.executable,'-B',*command],check=True,timeout=120)
