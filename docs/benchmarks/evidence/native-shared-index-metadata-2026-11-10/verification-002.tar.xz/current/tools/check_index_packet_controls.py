"""Challenge portable shared-index evidence without executing a query."""
from __future__ import annotations

import argparse
import copy
import gzip
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

import verify_index_packet as verifier

N = Path(__file__).resolve().parents[1]
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
RAW_CONTROLS = {'candidate_engine_total_corrupted', 'candidate_case_omitted',
    'baseline_reuse_corrupted', 'candidate_no_fallback_denied', 'gain_disposition_corrupted'}


def put(data, name, value):
    data[name] = (json.dumps(value, indent=2) + '\n').encode()


def change(data, name, update):
    value = json.loads(data[name])
    update(value)
    put(data, name, value)


def remove_test_line(data, check, matches):
    name = 'current/' + check + '.log'
    rows = data[name].splitlines(keepends=True)
    selected = [i for i, line in enumerate(rows) if matches(line)]
    assert selected
    del rows[selected[0]]
    data[name] = b''.join(rows)
    change(data, 'current/' + check + '.json', lambda row: row.update(log_sha256=verifier.digest(data[name])))


def mutate(name, report, data):
    receipt = 'current/native-tests-r1.json'
    if name == 'native_test_failure':
        change(data, receipt, lambda row: row.update(status='failed', returncode=101))
    elif name == 'undrained_native_process':
        change(data, receipt, lambda row: row.update(process_group_drained=False))
    elif name == 'mutable_source_validation':
        change(data, receipt, lambda row: row.update(fixed_source_validation=False, allow_lockfile_update=True))
    elif name in ('index_source_changed', 'root_lock_changed'):
        source = 'Cargo.lock' if name == 'root_lock_changed' else 'shardloom-vortex/src/local_primitives/native_relational_index.rs'
        key = 'source-blobs/' + report['candidate_source_snapshot'][source]['sha256']
        data[key] += b'\ncorruption-control\n'
    elif name == 'consumer_test_missing_with_rebound_log':
        manifest = json.loads(data['preparation/reuse-metadata-r1/consumer-test-manifest-primary-r1.json'])
        wanted = ('test ' + manifest['tests'][0]['exact_test_name'] + ' ... ok\n').encode()
        remove_test_line(data, 'native-tests-r1', lambda line: line == wanted)
    elif name == 'metadata_test_missing_with_rebound_log':
        remove_test_line(data, 'candidate-mechanism-r1', lambda line:
            line.startswith(b'test local_primitives::native_relational_index::metadata_tests::') and line.endswith(b' ... ok\n'))
    elif name == 'runtime_library_mismatch':
        def alter(row):
            item = next(item for item in row['files'] if Path(item['path']).name == 'lib_native.dylib')
            item['sha256'] = '0' * 64
        change(data, 'current/runtime-r1-identity.json', alter)
    elif name == 'diagnostic_entry_count_corrupted':
        target = 'current/candidate-attribution-observations-r1.json'
        observations = json.loads(data[target])
        row = next(item for item in observations['observations'] if item['input_rows_per_side'] == 4097)
        row['observations']['row_index_large_entry_reads'] += 1
        put(data, target, observations)
        log = 'current/candidate-mechanism-r1.log'
        rows = data[log].decode().splitlines()
        matched = 0
        for ordinal, line in enumerate(rows):
            if 'ROW_INDEX_WORK {' in line and 'CYCLIC_ROW_INDEX_WORK' not in line:
                start = line.index('ROW_INDEX_WORK ') + len('ROW_INDEX_WORK ')
                original = json.loads(line[start:])
                if (original['case'], original['input_rows_per_side']) == (row['case'], 4097):
                    rows[ordinal] = line[:start] + json.dumps(row)
                    matched += 1
        assert matched == 1
        data[log] = ('\n'.join(rows) + '\n').encode()
    elif name == 'candidate_engine_total_corrupted':
        key = 'current/candidate-verified-r1.json'
        row = json.loads(data[key])
        row['engine_execution_seconds'] += 1
        row['engine_seconds_saved'] = row['baseline_engine_execution_seconds'] - row['engine_execution_seconds']
        row['observed_engine_reduction_percent'] = 100 * row['engine_seconds_saved'] / row['baseline_engine_execution_seconds']
        row['frozen_rule_disposition'] = 'drop_candidate_no_gain'
        put(data, key, row)
        report['disposition'] = row['frozen_rule_disposition']
        report['candidate'].update({key: row[key] for key in report['candidate']})
    elif name == 'candidate_case_omitted':
        key = 'current/candidate-cases-r1.jsonl.gz'
        rows = gzip.decompress(data[key]).splitlines(keepends=True)
        assert len(rows) == 2452
        data[key] = gzip.compress(b''.join(rows[:-1]), mtime=0)
        def alter(row):
            row['case_rows']['generation']['bytes'] = len(data[key])
            row['case_rows']['sha256'] = verifier.digest(data[key])
        change(data, 'current/candidate-verified-r1.json', alter)
    elif name == 'baseline_reuse_corrupted':
        def alter(row):
            assert row['rows'][0]['repair_ordinal'] == 0
            row['rows'][0]['repair_ordinal'] = 1
        change(data, 'current/baseline-reuse-r1.json', alter)
    elif name == 'candidate_no_fallback_denied':
        change(data, 'current/candidate-verified-r1.json', lambda row: row.update(native_no_fallback=False))
    elif name == 'gain_disposition_corrupted':
        report['disposition'] = 'drop_candidate_no_gain'
        change(data, 'current/candidate-verified-r1.json', lambda row: row.update(frozen_rule_disposition='drop_candidate_no_gain'))
    elif name == 'original_failure_omitted':
        key = 'native-clippy-r1.json'
        del data['current/' + key]
        report['original_failed_checks'] = [row for row in report['original_failed_checks'] if row['receipt'] != 'current/' + key]
        change(data, 'current/failure-dispositions-r1.json', lambda row: row.pop(key))
    elif name == 'full10k_claim':
        report['complete_10k_performance_claim'] = True
    elif name in ('ci_policy_extra_skip', 'ci_policy_existing_skip_removed', 'ci_policy_weights_changed'):
        # Rebind the altered fixture and its guard fingerprints so rejection
        # must come from the exact one-entry policy, not merely a stale hash.
        receipt_key = 'current/ci-policy-r1.json'
        record = json.loads(data[receipt_key])
        old = record['build_sources'][verifier.CI_POLICY_PATH]
        fixture = json.loads(data['source-blobs/' + old['sha256']])
        if name == 'ci_policy_extra_skip':
            fixture['ignored_tests'].append('ordinary::correctness_test')
            fixture['ignored_tests'].sort()
        elif name == 'ci_policy_existing_skip_removed':
            fixture['ignored_tests'].pop(0)
        else:
            fixture['unmeasured_test_weight_seconds'] += 1
        raw = (json.dumps(fixture, indent=2) + '\n').encode()
        item = verifier.identity(raw)
        data['source-blobs/' + item['sha256']] = raw
        record['build_sources'][verifier.CI_POLICY_PATH] = item
        updated = verifier.fingerprint(record['build_sources'])
        record['build_source_fingerprint_sha256'] = updated
        for phase in ('pre_execution', 'post_execution'):
            record['build_source_verification'][phase]['fingerprint_sha256'] = updated
        report['ci_policy_correction']['after'] = item
        change(data, 'current/ci-policy-r1.log', lambda row: row.update(after=item))
        record['log_sha256'] = verifier.digest(data['current/ci-policy-r1.log'])
        put(data, receipt_key, record)
    else:
        raise ValueError('unrecognized control: ' + name)


def child(packet_path, name):
    report, data = verifier.read_archive(packet_path)
    if name == 'archive_byte_changed':
        with tempfile.TemporaryDirectory(prefix='index-control-archive-', dir=N) as temporary:
            clone = Path(temporary) / 'packet'
            shutil.copytree(packet_path, clone)
            path = clone / report['archives'][0]['path']
            raw = bytearray(path.read_bytes())
            raw[-1] ^= 1
            path.write_bytes(raw)
            try:
                verifier.read_archive(clone)
            except AssertionError:
                return dict(name=name, outcome='rejected', boundary='archive_identity')
        raise AssertionError('corrupted archive was accepted')
    report = copy.deepcopy(report)
    data = dict(data)
    mutate(name, report, data)
    try:
        if name in RAW_CONTROLS:
            with tempfile.TemporaryDirectory(prefix='index-control-replay-', dir=N) as temporary:
                verifier.replay_saved(report, data, Path(temporary))
            boundary = 'complete_saved_result_replay'
        elif name == 'diagnostic_entry_count_corrupted':
            verifier.verify_diagnostics(verifier.Packet(report, data))
            boundary = 'diagnostic_work_invariants'
        else:
            verifier.verify_sources(report, data)
            boundary = 'source_runtime_claim_binding'
    except (AssertionError, KeyError, ValueError) as error:
        return dict(name=name, outcome='rejected', failure_type=type(error).__name__)
    raise AssertionError('corruption was accepted at ' + boundary + ': ' + name)


def invoke(command, name, log_root):
    result = subprocess.run(command, cwd=N, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
        capture_output=True, text=True, timeout=300, check=False)
    (log_root / (name + '.stdout.log')).write_text(result.stdout)
    (log_root / (name + '.stderr.log')).write_text(result.stderr)
    assert result.returncode == 0, (name, result.stderr[-2000:])
    return json.loads(result.stdout)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--packet', type=Path, required=True)
    parser.add_argument('--child', choices=sorted(verifier.CONTROL_NAMES))
    parser.add_argument('--execution-name')
    args = parser.parse_args()
    assert __debug__ and args.packet.resolve().is_relative_to(N)
    if args.child:
        print(json.dumps(child(args.packet, args.child), sort_keys=True))
        return
    assert args.execution_name and re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', args.execution_name)
    log_root = N / args.execution_name
    assert not log_root.exists()
    log_root.mkdir()
    report, data = verifier.read_archive(args.packet)
    assert data['current/tools/check_index_packet_controls.py'] == Path(__file__).read_bytes()
    destination = args.packet / 'corruption-controls.json'
    assert not destination.exists()
    accepted = verifier.identity((args.packet / 'acceptance.json').read_bytes())
    first = invoke([sys.executable, '-B', str(args.packet / 'verify.py'), '--repo-root', str(W)], 'source-bound', log_root)
    assert first['status'] == 'passed_source_bound_replay' and first['query_executions'] == 0
    controls = [dict(name='source_bound', outcome='passed')]
    for name in sorted(verifier.CONTROL_NAMES):
        result = invoke([sys.executable, '-B', str(Path(__file__).resolve()), '--packet', str(args.packet), '--child', name], name, log_root)
        assert result['name'] == name and result['outcome'] == 'rejected'
        controls.append(result)
    with tempfile.TemporaryDirectory(prefix='index-control-relocated-', dir=N) as temporary:
        clone = Path(temporary) / 'packet'
        shutil.copytree(args.packet, clone)
        last = invoke([sys.executable, '-B', str(clone / 'verify.py')], 'relocated', log_root)
        assert last == first
    controls.append(dict(name='relocated_source_only', outcome='passed'))
    assert verifier.identity((args.packet / 'acceptance.json').read_bytes()) == accepted
    observations = args.packet / 'control-observations'
    assert not observations.exists()
    shutil.copytree(log_root, observations)
    result = dict(status='passed', query_executions=0, positive_controls=2,
        rejected_corruptions=len(verifier.CONTROL_NAMES), controls=controls,
        acceptance_manifest=accepted, archives=report['archives'],
        sources={name: verifier.identity(data['current/tools/' + name])
            for name in ('verify_index_packet.py', 'check_index_packet_controls.py')},
        observations=[dict(path='control-observations/' + path.name, **verifier.identity(path.read_bytes()))
            for path in sorted(log_root.iterdir())])
    with destination.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status='passed', query_executions=0, positive_controls=2,
        rejected_corruptions=len(verifier.CONTROL_NAMES)), sort_keys=True))


if __name__ == '__main__':
    main()
