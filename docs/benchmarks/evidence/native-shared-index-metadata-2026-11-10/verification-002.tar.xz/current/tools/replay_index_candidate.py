"""Independently replay every fixed candidate request, result and engine clock."""
from collections import Counter, defaultdict
from contextlib import ExitStack
import gzip
import hashlib
import json
import math
from pathlib import Path

import run_index_candidate as current
from query_surface.corpus import corpus
from query_surface.evidence import identity
from query_surface.expanded_catalog import build, spaces
from query_surface.expanded_freeze import read, unpack
from query_surface.expanded_report import raw_files, replay
from query_surface.expanded_run import closing_db, request, verify


def main():
    if not __debug__:
        raise RuntimeError('candidate replay requires assertion checks')
    assert Path(__file__).resolve() == current.N / 'tools/replay_index_candidate.py'
    target = current.TARGET
    destination = current.N / 'candidate-verified-r1.json'
    cases_path = current.N / 'candidate-cases-r1.jsonl.gz'
    partial = current.N / 'candidate-cases-r1.partial.jsonl.gz'
    lock = current.N / '.candidate-replay-r1.lock'
    assert not any(path.exists() for path in (destination, cases_path, partial, lock))
    design, inputs, frozen, admitted = current.admission(current.E)
    protocol = read(current.PROTOCOL)
    selection = read(current.baseline.SELECTION)
    baseline = read(current.N / 'baseline-verified-r1.json')
    done, binding = read(target / 'complete.json'), read(target / 'binding.json')
    assert done['status'] == 'complete_observation' and done['stage'] == 'native'
    assert done['total'] == done['attempt_slots'] == 2452
    assert done['posthash_verified'] and done['attempts_per_case'] == 1 and done['requested_repeats'] == 0
    assert done['updated'] == admitted
    assert binding['contract'] == {key: done[key] for key in ('frozen', 'stage', 'prerequisites', 'updated')}
    assert done['ledger']['path'] == str(target / 'attempts.sqlite')
    assert done['binding']['path'] == str(target / 'binding.json')
    verify([done['ledger'], done['binding'], done['frozen']])
    guard_path = current.N / 'candidate-r1.json'
    guard = read(guard_path)
    assert guard['status'] == 'passed' and guard['returncode'] == 0
    assert guard['process_group_drained'] and guard['direct_child_reaped'] and guard['query_workload']
    assert guard['base'] == current.baseline.MERGE and guard['head'] == admitted['source_head']
    assert guard['build_source_fingerprint_sha256'] == admitted['source_fingerprint_sha256']
    assert guard['active_output'] == str(target)
    assert guard['fixed_source_validation'] and not guard['allow_lockfile_update']
    assert guard['build_inventory_policy'] == guard['evidence_inventory_policy'] == 'before_and_after_only'
    assert guard['command'] == ['/Users/dylan/.cache/shardloom/query-surface-polars-2.1.0/bin/python',
        '-B', str(current.N / 'tools/run_index_candidate.py')]
    assert guard['log_sha256'] == current.file_identity(guard_path.with_suffix('.log'))['sha256']
    assert protocol['cases'] == selection['cases'] and len(selection['cases']) == 2452
    assert protocol['baseline_result'] == identity(current.N / 'baseline-verified-r1.json')
    assert baseline['outcomes'] == {'passed': 2452} and baseline['complete_performance_result_valid']
    prepared = read(current.E / 'native-preparation/complete.json')
    originals = {item.id: item for item in corpus(interactions='all', include_pending=False)}
    definitions = {spec.name: spec for spec in spaces()}
    outcomes, families, values, failures = Counter(), defaultdict(list), [], []
    with lock.open('x'):
        pass
    with ExitStack() as stack:
        db = stack.enter_context(closing_db(target / 'attempts.sqlite', readonly=True))
        entries = iter(db.execute('SELECT seq,id,status,packet FROM attempt ORDER BY seq'))
        refs = {profile: stack.enter_context(closing_db(current.E / ('reference-' + profile) / 'expectations.sqlite', readonly=True))
            for profile in {row['case']['profile'] for row in selection['cases']}}
        output = stack.enter_context(gzip.open(partial, 'wt', encoding='utf-8'))
        baseline_stream = stack.enter_context(gzip.open(baseline['case_rows']['path'], 'rt', encoding='utf-8'))
        for ordinal, selected in enumerate(selection['cases']):
            case = selected['case']
            prior = json.loads(next(baseline_stream))
            assert prior['cohort_ordinal'] == ordinal and prior['original_seq'] == selected['original_seq']
            assert prior['id'] == case['id'] and prior['case_identity'] == case['case_identity']
            assert prior['result']['status'] == 'passed'
            entry = next(entries, None)
            assert entry and entry[:2] == (ordinal, case['id'])
            item = build(case, definitions) if 'cell' in case else originals[case['id']]
            reference = refs[case['profile']].execute('SELECT identity,value FROM expected WHERE id=?', (case['id'],)).fetchone()
            assert reference and reference[0] == item.identity == case['case_identity']
            expected = unpack(reference[1])
            observed = replay(entry, case, 'native', expected, item, inputs, prepared, design['execution'])
            assert observed['status'] == entry[2]
            if observed['status'] == 'passed' or observed['engine_seconds'] is not None:
                current.baseline.clock_verifier.verify_clock(entry, observed)
            files = raw_files(unpack(entry[3])) if entry[3] is not None else {}
            if files:
                assert json.loads(files['one.job.json']) == request(case, 'native', inputs, prepared, expected, design['execution'])
            expected_hash = hashlib.sha256(reference[1]).hexdigest()
            assert prior['provenance']['independent_expected_blob_sha256'] == expected_hash
            provenance = dict(source='new_single_candidate_observation', ledger=done['ledger']['path'], source_seq=ordinal,
                packet=(dict(bytes=len(entry[3]), sha256=hashlib.sha256(entry[3]).hexdigest()) if entry[3] is not None else None),
                job_sha256=(hashlib.sha256(files['one.job.json']).hexdigest() if files else None),
                independent_expected_blob_sha256=expected_hash)
            outcomes[observed['status']] += 1
            if observed['status'] == 'passed':
                seconds = observed['engine_seconds']
                assert type(seconds) in (int, float) and math.isfinite(seconds) and seconds >= 0
                values.append(seconds)
                families[case['family']].append(seconds)
            else:
                failures.append(dict(cohort_ordinal=ordinal, original_seq=selected['original_seq'], id=case['id'],
                    status=observed['status'], detail=observed.get('failure_detail')))
            output.write(json.dumps(dict(cohort_ordinal=ordinal, original_seq=selected['original_seq'],
                id=case['id'], case_identity=case['case_identity'], family=case['family'], profile=case['profile'],
                surface=case['surface'], native_format=case['native_format'], provenance=provenance,
                baseline_engine_seconds=prior['result']['engine_seconds'], result=observed),
                separators=(',', ':'), allow_nan=False) + '\n')
        assert next(entries, None) is None and next(baseline_stream, None) is None
    assert dict(outcomes) == done['outcomes'] and sum(outcomes.values()) == 2452
    verify([*frozen, done['ledger'], done['binding'], done['frozen'], baseline['case_rows']])
    partial.rename(cases_path)
    passed = outcomes == {'passed': 2452}
    seconds = math.fsum(values) if passed else None
    baseline_seconds = baseline['engine_execution_seconds']
    disposition = ('retain_candidate' if seconds < baseline_seconds else 'drop_candidate_no_gain') if passed else 'drop_candidate_invalid_cohort'
    result = dict(schema='shardloom.shared_index_candidate_cohort.v1',
        status='passed_complete_candidate_cohort' if passed else 'failed_candidate_cohort',
        query_executions_during_replay=0, accepted_base=current.baseline.MERGE,
        selected_cases=2452, new_attempts=2452, outcomes=dict(outcomes), attempts_per_case=1,
        warmups=0, requested_repeats=0, primary_clock='engine_execution_seconds',
        engine_execution_seconds=seconds, baseline_engine_execution_seconds=baseline_seconds,
        engine_seconds_saved=baseline_seconds-seconds if passed else None,
        observed_engine_reduction_percent=100*(baseline_seconds-seconds)/baseline_seconds if passed else None,
        complete_performance_result_valid=passed, all_selected_results_correct=passed,
        all_engine_clocks_valid=passed, native_no_fallback=passed, failures=failures,
        frozen_rule_disposition=disposition, final_integration_accepted=False,
        families={name: dict(cases=len(rows), engine_execution_seconds=math.fsum(rows),
            baseline_engine_execution_seconds=baseline['families'][name]['engine_execution_seconds'])
            for name, rows in sorted(families.items())},
        protocol=identity(current.PROTOCOL), selection=identity(current.baseline.SELECTION),
        baseline_result=identity(current.N / 'baseline-verified-r1.json'), complete=identity(target / 'complete.json'),
        ledger=done['ledger'], guard=identity(guard_path), case_rows=identity(cases_path),
        verifier=identity(Path(__file__)), runtime_binding=admitted,
        complete_10k_performance_claim=False,
        limitations=['The fixed cohort has2452cases; this is not a new full10k result.',
            'The baseline explicitly reuses433saved repair observations and2019new baseline observations from separate isolated sessions.',
            'One ordinary candidate execution per case; no repeats, warmups, profiling, cache manipulation or statistical confidence claim.',
            'Final source review, hosted integration and retention closeout are separate from this local score.'])
    with destination.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    lock.unlink()
    print(json.dumps({key: result[key] for key in ('status', 'selected_cases', 'outcomes',
        'engine_execution_seconds', 'baseline_engine_execution_seconds', 'frozen_rule_disposition')}))
    assert passed, 'candidate cohort failed; every original observation remains retained'


if __name__ == '__main__':
    main()
