#!/usr/bin/env python3
"""Freeze and later run/replay a bounded matched native optimization cohort."""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from contextlib import ExitStack
import base64
import hashlib
import json
import lzma
import math
from pathlib import Path
import platform
import sqlite3
import sys

ROOT_DEFAULT = Path('/Users/dylan/.codex/worktrees/native-post-110-optimization/shardloom-local-repo')
DATA_DEFAULT = Path('/Users/dylan/LocalData/shardloom/expanded-query-2026-11-03')
I_DEFAULT = Path('/Users/dylan/.codex/worktrees/native-expanded-investigations/shardloom-local-repo')
HARNESS_DEFAULT = DATA_DEFAULT / 'investigation-original-harness-r1'
PARENT_REVISION = '0e8f5079917a47f75539c93754239097e703e91a'
FEATURES = ['release-user-surfaces']
PROTOCOL_NAME = 'investigation-protocol-r2.json'
TARGET_NAME = 'investigation-cohort-r2'
CHALLENGE_ID = 'v2_single_key_reducer_d7da0557c5fb3f58'
MULTIKEY_ID = 'v2_multiple_key_reducer_f30d4f98739cb9c9'
WINDOW_5M_ID = 'v2_window_rolling_sum_473addced11c72c6'
TOPK_ID = 'v2_rank_hidden_payload_ec8a8267927d087d'
MEMBERSHIP_SCALE_ID = 'v2_subquery_membership_d377362103f6111c'
WINDOWS = ('window_rolling_sum', 'window_row_number', 'window_lag', 'window_lead')
MEMBERSHIP = ('subquery_membership', 'subquery_null_aware_anti')
FORMATS = ('parquet', 'arrow-ipc', 'vortex')
PROFILES = ('primary', 'holdout', 'smoke')

sys.path[:0] = [str(HARNESS_DEFAULT / 'scripts'), str(HARNESS_DEFAULT / 'python/src'),
                str(HARNESS_DEFAULT / 'benchmarks/traditional_analytics'),
                str(ROOT_DEFAULT / 'scripts'), str(ROOT_DEFAULT / 'python/src'),
                str(ROOT_DEFAULT / 'benchmarks/traditional_analytics')]
from resources import BenchmarkGuard
from run_clickbench_query_uat import run_profiled_command
from query_surface.evidence import generation, identity, no_fallback, worker_outcome
from query_surface.expanded_catalog import build, spaces
from query_surface.expanded_freeze import pack, read, unpack
from query_surface.expanded_report import raw_files, replay
from query_surface.expanded_run import (closing_db, raw_packet, request,
    stage_complete, stage_lock, verify, verify_request_files)
from query_surface.run import write_json


def exact_selector(design):
    """Select only predeclared rows/routes; iteration order is design order."""
    cases = design['cases']
    by_id = {row['id']: row for row in cases}
    reasons = defaultdict(list)
    missing = {'membership': [], 'grouping': [], 'windows': []}

    def mark(row, route, reason):
        reasons[(row['id'], route)].append(reason)

    # A: one first-in-manifest member for each present cell, independently
    # within primary and holdout. All combinations remain explicit in missing.
    membership_found = set()
    for profile in ('primary', 'holdout'):
        for row in cases:
            if row['profile'] not in (profile,):
                continue
            if row['archetype'] not in MEMBERSHIP or row['native_format'] not in FORMATS:
                continue
            cell = row['cell']
            key = (profile, row['archetype'], cell['build'], row['native_format'])
            if key in membership_found:
                continue
            membership_found.add(key)
            mark(row, 'native', 'A:first_manifest_row_for_profile_archetype_rhs_build_format')
        for archetype in MEMBERSHIP:
            for rhs_build in ('all', 'empty', 'small'):
                for fmt in FORMATS:
                    key = (profile, archetype, rhs_build, fmt)
                    if key not in membership_found:
                        missing['membership'].append(dict(profile=profile, archetype=archetype,
                                                          rhs_build=rhs_build, native_format=fmt))
    scale_member = by_id.get(MEMBERSHIP_SCALE_ID)
    if scale_member is not None:
        mark(scale_member, 'native', 'A:explicit_scale_empty_membership_case')
    else:
        missing['membership'].append(dict(id=MEMBERSHIP_SCALE_ID, reason='explicit scale case absent'))

    # B: all prepared (Vortex-input) direct population COUNT/MIN/MAX cases in
    # the three requested profiles, plus first prepared case by function and
    # profile over other scopes.
    group_functions = ('count', 'min', 'max')
    for row in cases:
        cell = row.get('cell', {})
        if (row['archetype'] == 'single_key_reducer' and row['profile'] in PROFILES
                and row['native_format'] == 'vortex' and cell.get('scope') == 'population'
                and cell.get('expression') == 'direct' and cell.get('function') in group_functions):
            mark(row, 'native', 'B:all_prepared_population_direct_count_min_max')
    group_other_found = set()
    for row in cases:
        cell = row.get('cell', {})
        if (row['archetype'] != 'single_key_reducer' or row['profile'] not in PROFILES
                or row['native_format'] != 'vortex' or cell.get('scope') == 'population'
                or cell.get('function') not in group_functions):
            continue
        key = (cell['function'], row['profile'])
        if key not in group_other_found:
            group_other_found.add(key)
            mark(row, 'native', 'B:first_prepared_other_scope_by_function_profile')
    for profile in PROFILES:
        for function in group_functions:
            if (function, profile) not in group_other_found:
                missing['grouping'].append(dict(profile=profile, function=function,
                                                scope='non_population', reason='no prepared row'))
    multikey = by_id.get(MULTIKEY_ID)
    if multikey is not None and multikey.get('surrogate') == 'multikey_group':
        mark(multikey, 'alternate', 'B:5M_prepared_multikey_group_ownership_control')
    else:
        missing['grouping'].append(dict(id=MULTIKEY_ID, reason='declared multikey alternate absent'))

    # C: first prepared/Vortex-input native query for each window archetype
    # and profile. The scale 5M window is additionally paired over native and
    # its already declared alternate route.
    window_found = set()
    for row in cases:
        if (row['archetype'] not in WINDOWS or row['profile'] not in PROFILES
                or row['native_format'] != 'vortex'):
            continue
        key = (row['archetype'], row['profile'])
        if key not in window_found:
            window_found.add(key)
            mark(row, 'native', 'C:first_prepared_window_by_archetype_profile')
    for profile in PROFILES:
        for archetype in WINDOWS:
            if (archetype, profile) not in window_found:
                missing['windows'].append(dict(profile=profile, archetype=archetype,
                                               reason='no prepared/Vortex native route'))
    window_5m = by_id.get(WINDOW_5M_ID)
    if window_5m is not None and window_5m.get('surrogate') == 'window':
        mark(window_5m, 'native', 'C:5M_window_native_route')
        mark(window_5m, 'alternate', 'C:5M_window_prepared_alternate_route')
    else:
        missing['windows'].append(dict(id=WINDOW_5M_ID, reason='declared scale routes absent'))

    # Raw hidden-payload Top-K remains ineligible for a prepared route. Keep it
    # explicit as an exclusion so later edits cannot silently widen the cohort.
    excluded = [dict(id=TOPK_ID, route='alternate', reason=(
        'prepared Top-K has no eligible source access path in the archived route; '
        'conservative ineligibility retained and no rerun authorized'))]

    # Deduplicate by (id, route), then restore exact design order and native
    # before alternate route ordering. Only declared alternate jobs qualify.
    alternate_ids = set(design['alternate_route_cases'])
    selected = []
    for row in cases:
        for route in ('native', 'alternate'):
            why = reasons.get((row['id'], route))
            if not why:
                continue
            if route == 'alternate' and row['id'] not in alternate_ids:
                raise ValueError('selector tried to invent an undeclared alternate: ' + row['id'])
            selected.append(dict(spec=row, route=route, reasons=why))
    if len({(item['spec']['id'], item['route']) for item in selected}) != len(selected):
        raise ValueError('duplicate selector route')

    challenge = by_id.get(CHALLENGE_ID)
    if challenge is None or challenge.get('surrogate') != 'high_cardinality_group' or CHALLENGE_ID not in alternate_ids:
        raise ValueError('historical high-cardinality candidate-only challenge is not declared')
    return selected, dict(spec=challenge, route='alternate',
                          reason='candidate-only historical RSS failure challenge; never paired or rerun on parent'), missing, excluded


def source_record(spec, route, inputs, prepared, policy, expected, role_runtime=None):
    stage = 'native' if route == 'native' else 'alternate'
    job = request(spec, stage, inputs, prepared, expected, policy)
    if role_runtime is not None:
        job['runtime'] = role_runtime
    return job


def require_historical(row, route, inputs, prepared, policy, refs, ledgers):
    spec = row['spec']
    ref = refs[spec['profile']].execute('SELECT identity,value FROM expected WHERE id=?',
                                       (spec['id'],)).fetchone()
    if ref is None or ref[0] != spec['case_identity']:
        raise ValueError('independent reference is absent or has another identity: ' + spec['id'])
    expected = unpack(ref[1])
    job = source_record(spec, route, inputs, prepared, policy, expected)
    archived = ledgers[route].execute('SELECT status,packet FROM attempt WHERE id=?',
                                      (spec['id'],)).fetchone()
    if archived is None or archived[1] is None:
        raise ValueError('historical declared job lacks a raw packet: ' + spec['id'] + '/' + route)
    packet = unpack(archived[1])
    raw = raw_files(packet)
    old_job = json.loads(raw['one.job.json'])
    if job != old_job:
        raise ValueError('request differs from historical declared job: ' + spec['id'] + '/' + route)
    outcome = worker_outcome(packet['supervision'], raw['one.stdout.json'])
    if archived[0] != packet['classified_status'] or archived[0] != outcome['status']:
        raise ValueError('historical classification differs: ' + spec['id'] + '/' + route)
    report = outcome.get('observation') or {}
    clocks = report.get('clocks') or {}
    if archived[0] == 'passed':
        no_fallback(report['fields'])
        if outcome['id'] != spec['id'] or outcome['case_identity'] != spec['case_identity']:
            raise ValueError('historical passing worker identity differs')
    return expected, dict(status=archived[0], detail=outcome.get('detail'),
                          engine_seconds=clocks.get('engine_execution_seconds'),
                          peak_process_rss_bytes=packet['supervision'].get('native_peak_rss_bytes'),
                          packet_blob_sha256=hashlib.sha256(archived[1]).hexdigest(),
                          job_sha256=hashlib.sha256(raw['one.job.json']).hexdigest())


def checked_admission(root, data):
    """Apply expanded_run.admission while relocating only frozen harness code.

    The published freeze remains immutable. Its 65 harness digests are checked
    against the staged original commit; data, references, runtime, and
    environment identities are verified at their original paths/generations.
    """
    frozen=read(data/'frozen.json')
    inputs=read(data/'inputs.json')
    design=read(data/'design.json')
    if frozen['status']!='frozen_before_comparison' or frozen['total']!=10000:
        raise ValueError('incomplete original frozen cohort')
    cases=design['cases']
    if (len(cases)!=frozen['total'] or design['count']!=len(cases)
            or len({r['id'] for r in cases})!=len(cases)
            or len({r['semantic_sql_sha256'] for r in cases})!=len(cases)
            or sum('reference' in r for r in cases)!=347):
        raise ValueError('invalid or incomplete expanded case inventory')
    if frozen['design']!=inputs['design'] or any(design['execution'][k]!=v for k,v in
            {'threads':2,'attempts_per_case_and_route':1,'warmups':0}.items()):
        raise ValueError('frozen execution contract differs')
    if sys.version!=inputs['python'] or platform.machine()!=inputs['machine']:
        raise ValueError('runtime environment differs from archived freeze')
    frozen_hash=identity(data/'frozen.json')
    source_manifest_path=data/'investigation-original-harness-source-r1.json'
    source_manifest=read(source_manifest_path)
    if (source_manifest['commit']!='0155355e7927e6f8a4747daae5a6daf3438e822b'
            or source_manifest['published_frozen_sha256']!=frozen_hash['sha256']
            or source_manifest['complete_harness_count']!=len(frozen['harness'])
            or len(frozen['harness'])!=65):
        raise ValueError('staged original harness source manifest is not bound to this freeze')
    original_root=data/'investigation-original-harness-r1'
    relocated=[]
    expected_hashes={}
    for item in frozen['harness']:
        old=Path(item['path'])
        try:
            relative=old.relative_to(root)
        except ValueError:
            raise ValueError('frozen harness path is outside original repository')
        actual_path=original_root/relative
        actual=identity(actual_path)
        if (actual['sha256']!=item['sha256'] or actual['generation']['bytes']!=item['generation']['bytes']
                or source_manifest['harness_sha256'].get(relative.as_posix())!=item['sha256']):
            raise ValueError('relocated original harness differs from frozen bytes: '+relative.as_posix())
        expected_hashes[relative.as_posix()]=item['sha256']
        relocated.append(dict(frozen_path=item['path'],repo_relative_path=relative.as_posix(),
                              frozen_sha256=item['sha256'],relocated=actual))
    if expected_hashes!=source_manifest['harness_sha256']:
        raise ValueError('staged original harness inventory differs from exact 65-file freeze')

    # Only the original harness paths are relocated. Preserve and verify all
    # input/reference/environment/runtime paths with their frozen generations.
    unchanged=[frozen['design'],frozen['inputs'],*frozen['references'],
               *frozen['environment_files'],*inputs['files'],*inputs['runtime'].values()]
    verify(unchanged)
    if len({f['path'] for f in unchanged})!=len(unchanged):
        # Duplicate declarations are fine only when they carry identical identities.
        verify(unchanged)
    frozen_files=list({f['path']:f for f in unchanged}.values())

    # Bind the immutable design/freeze/input documents to the published
    # portable evidence index and its exact metadata records.
    portable=data/'portable-r2'
    index_path=portable/'index.json'
    index_bytes=index_path.read_bytes()
    index=json.loads(index_bytes)
    if index.get('format')!='shardloom-expanded-portable-evidence' or index.get('schema_version')!=1:
        raise ValueError('portable archive index format differs')
    metadata_desc=index['metadata']
    metadata_path=portable/'metadata.jsonl.xz'
    compressed=metadata_path.read_bytes()
    if (len(compressed)!=metadata_desc['compressed_bytes']
            or hashlib.sha256(compressed).hexdigest()!=metadata_desc['sha256']):
        raise ValueError('portable metadata packet hash differs')
    decoder=lzma.LZMADecompressor(format=lzma.FORMAT_XZ,memlimit=96<<20)
    raw=decoder.decompress(compressed,max_length=metadata_desc['raw_bytes']+1)
    if not decoder.eof or decoder.unused_data or len(raw)!=metadata_desc['raw_bytes']:
        raise ValueError('portable metadata packet framing differs')
    metadata={}
    descriptors={r['name']:r for r in metadata_desc['records']}
    for line in raw.splitlines():
        record=json.loads(line)
        if record['name'] in ('design.json','frozen.json','inputs.json'):
            source=base64.b64decode(record['data'],validate=True)
            if (hashlib.sha256(source).hexdigest()!=record['sha256']
                    or record['sha256']!=descriptors[record['name']]['source_sha256']
                    or len(source)!=descriptors[record['name']]['source_bytes']
                    or source!=(data/record['name']).read_bytes()):
                raise ValueError('archived source binding differs: '+record['name'])
            metadata[record['name']]=record['sha256']
    if set(metadata)!={'design.json','frozen.json','inputs.json'}:
        raise ValueError('portable index lacks frozen design/input source records')
    archive_files=[identity(index_path),identity(metadata_path),identity(source_manifest_path),
                   *[item['relocated'] for item in relocated]]
    return design,inputs,frozen_files,relocated,archive_files,metadata


def make_plan(root, data, candidate_root):
    design, inputs, frozen_files, relocated_harness, archive_files, archive_metadata = checked_admission(root,data)
    native_complete = stage_complete(data, 'native', len(design['cases']))
    alternate_count = len(design['alternate_route_cases'])
    alternate_complete = stage_complete(data, 'alternate', alternate_count)
    prepared = read(data / 'native-preparation/complete.json')
    if (prepared['status'] != 'passed' or prepared['frozen'] != identity(data / 'frozen.json')
            or prepared['polars_complete'] != identity(data / 'observe-polars/complete.json')):
        raise ValueError('archived native preparation does not match the current freeze')
    prep_files = [f for p in prepared['profiles'].values()
                  for f in [p['manifest'], *p['inputs'], *p['receipts']]]
    verify(prep_files)
    frozen_files.extend(prep_files)
    selected, challenge, missing, excluded = exact_selector(design)
    parent_runtime=runtime_role(data,'parent',root,candidate_root)
    by_profile = {p: data / ('reference-' + p) / 'expectations.sqlite'
                  for p in {x['spec']['profile'] for x in selected} | {challenge['spec']['profile']}}
    ledgers = {
        'native': data / 'observe-native/attempts.sqlite',
        'alternate': data / 'observe-alternate/attempts.sqlite',
    }
    refs, attempts = {}, {}
    with ExitStack() as stack:
        for profile, path in by_profile.items():
            refs[profile] = stack.enter_context(closing_db(path, readonly=True))
        for route, path in ledgers.items():
            attempts[route] = stack.enter_context(closing_db(path, readonly=True))
        rows = []
        for seq, item in enumerate(selected):
            spec, route = item['spec'], item['route']
            expected, historic = require_historical(item, route, inputs, prepared,
                                                    design['execution'], refs, attempts)
            exp_ident, exp_value = refs[spec['profile']].execute(
                'SELECT identity,value FROM expected WHERE id=?', (spec['id'],)).fetchone()
            rows.append(dict(seq=seq, id=spec['id'], route=route, profile=spec['profile'],
                archetype=spec['archetype'], native_format=spec['native_format'],
                effective_input_format='vortex' if route=='alternate' else spec['native_format'],
                case_identity=spec['case_identity'], semantic_sql_sha256=spec['semantic_sql_sha256'],
                cell=spec.get('cell'), independent_expected_identity=exp_ident,
                independent_expected_value_sha256=hashlib.sha256(exp_value).hexdigest(),
                selection_reasons=item['reasons'], historical=historic))
        expected, historic = require_historical(challenge, 'alternate', inputs, prepared,
                                                design['execution'], refs, attempts)
        if (historic['status']!='guard_failed'
                or historic['peak_process_rss_bytes'] is None
                or historic['peak_process_rss_bytes']<=design['execution']['process_group_rss_ceiling_bytes']):
            raise ValueError('candidate-only challenge no longer binds the archived RSS guard failure')
        spec = challenge['spec']
        exp_ident, exp_value = refs[spec['profile']].execute(
            'SELECT identity,value FROM expected WHERE id=?', (spec['id'],)).fetchone()
        challenge_record = dict(id=spec['id'], route='alternate', profile=spec['profile'],
            archetype=spec['archetype'], native_format=spec['native_format'],effective_input_format='vortex',
            case_identity=spec['case_identity'], semantic_sql_sha256=spec['semantic_sql_sha256'],
            cell=spec.get('cell'), independent_expected_identity=exp_ident,
            independent_expected_value_sha256=hashlib.sha256(exp_value).hexdigest(),
            selection_reason=challenge['reason'], historical=historic)
    source_files = [identity(data / name) for name in (
        'design.json', 'frozen.json', 'inputs.json', 'native-preparation/complete.json',
        'observe-native/complete.json', 'observe-alternate/complete.json',
        'observe-polars/complete.json', 'report/replay.json')]
    source_files += [identity(path) for path in by_profile.values()]
    source_files += [identity(path) for path in ledgers.values()]
    source_files += [identity(data / 'native-preparation' / profile / 'prepared.json')
                     for profile in prepared['profiles']]
    all_files = list({item['path']: item for item in frozen_files + source_files + archive_files}.values())
    verify(all_files)
    source_manifest=read(data/'investigation-original-harness-source-r1.json')
    harness_helpers=[]
    helper_paths=('benchmarks/traditional_analytics/query_surface/expanded_catalog.py',
        'benchmarks/traditional_analytics/query_surface/expanded_freeze.py',
        'benchmarks/traditional_analytics/query_surface/expanded_report.py',
        'benchmarks/traditional_analytics/query_surface/expanded_run.py',
        'benchmarks/traditional_analytics/query_surface/evidence.py',
        'benchmarks/traditional_analytics/query_surface/semantics.py',
        'benchmarks/traditional_analytics/resources.py',
        'scripts/run_clickbench_query_uat.py')
    for relative in helper_paths:
        item=identity(data/'investigation-original-harness-r1'/relative)
        if item['sha256']!=source_manifest['harness_sha256'][relative]:
            raise ValueError('pinned helper differs from frozen source: '+relative)
        harness_helpers.append(item)
    parent_bound_files=[parent_runtime['manifest'],parent_runtime['build_receipt'],
                        *parent_runtime['runtime'].values()]
    all_files = list({item['path']: item for item in frozen_files + source_files + archive_files + harness_helpers + parent_bound_files}.values())
    verify(all_files)
    selector_counts=Counter()
    for row in rows:
        for reason in row['selection_reasons']:
            selector_counts[reason.split(':',1)[0]]+=1
    return dict(schema_version='shardloom.native_optimization_investigation_protocol.v1',
        protocol_id='investigation-cohort-1653-r2', frozen_before_candidate_observations=True,
        source=dict(repository=str(root), source_revision=PARENT_REVISION,
            archive_root=str(data), design=identity(data / 'design.json'),
            frozen=identity(data / 'frozen.json'), inputs=identity(data / 'inputs.json'),
            portable_archive_metadata=archive_metadata,
            original_harness_commit='0155355e7927e6f8a4747daae5a6daf3438e822b',
            original_harness_manifest=identity(data/'investigation-original-harness-source-r1.json'),
            relocated_original_harness=relocated_harness,
            helper_files=harness_helpers,
            parent_runtime_manifest=str(data / 'investigation-parent-runtime-r1/manifest.json'),
            candidate_runtime_manifest=str(data / 'investigation-candidate-runtime-r1/manifest.json'),
            candidate_repository=str(candidate_root), files=all_files),
        archive_checks=dict(native=identity(data / 'observe-native/complete.json'),
            alternate=identity(data / 'observe-alternate/complete.json'),
            preparation=identity(data / 'native-preparation/complete.json'),
            independent_replay=identity(data / 'report/replay.json'),
            original_native_ledger=identity(ledgers['native']),
            original_alternate_ledger=identity(ledgers['alternate'])),
        driver=identity(Path(__file__)), selector=dict(matched_jobs=len(rows),
            matched_case_ids=len({r['id'] for r in rows}), challenge_jobs=1,
            route_counts=dict(Counter(r['route'] for r in rows)),
            profile_counts=dict(Counter(r['profile'] for r in rows)),
            category_membership_job_count=selector_counts.get('A',0),
            category_grouping_job_count=selector_counts.get('B',0),
            category_window_job_count=selector_counts.get('C',0),
            challenge_case_id=challenge_record['id'], route_order=['native','alternate'],
            membership=[r for r in rows if r['id'] in {x['id'] for x in rows
                if x['archetype'] in MEMBERSHIP}], missing_cells=missing,
            excluded_routes=excluded, rows=rows, challenge=challenge_record),
        runtime_contract=dict(parent_source_revision=PARENT_REVISION,
            parent_verified_runtime=parent_runtime,
            parent_manifest=str(data / 'investigation-parent-runtime-r1/manifest.json'),
            candidate_manifest=str(data / 'investigation-candidate-runtime-r1/manifest.json'),
            candidate_source_checkout=str(candidate_root), required_profile='release',
            required_features=FEATURES, required_clean_committed_source=True,
            required_fresh_role_binary_and_library=True, role_hashes_must_differ=True,
            source_overlay_bytes=0, untracked_source_paths=[]),
        execution_contract=dict(matched_attempts_per_case_route_role=1,
            challenge_attempts=1, order='sequential; alternate first role by frozen row ordinal (parent first for even ordinals); challenge candidate-only last',
            no_retries=True, no_warmups=True, no_polars=True, no_topk_rerun=True,
            query_deadline_seconds=design['execution']['query_deadline_seconds'],
            native_memory_bytes=design['execution']['native_memory_bytes'],
            process_group_rss_ceiling_bytes=design['execution']['process_group_rss_ceiling_bytes'],
            source_hash_validation='complete outside active query execution; generation checks around each job',
            raw_packets='compressed lossless supervision and worker files retained per attempt',
            validation='offline exact independent full-output replay, stable case identity, no-fallback fields and native engine attribution'),
        policy=design['execution'])


def runtime_role(data, role, repo_root, candidate_root):
    name = 'investigation-parent-runtime-r1' if role == 'parent' else 'investigation-candidate-runtime-r1'
    manifest_path = data / name / 'manifest.json'
    manifest = read(manifest_path)
    if (manifest.get('schema_version') != 'shardloom.source_milestone_runtime.v1'
            or manifest.get('profile') != 'release' or manifest.get('features') != FEATURES
            or manifest.get('untracked_source_paths') != []
            or manifest.get('source_overlay') != {'bytes':0,'sha256':hashlib.sha256(b'').hexdigest()}):
        raise ValueError(role + ' runtime manifest is not a clean release build')
    if role == 'parent' and manifest['source_revision'] != PARENT_REVISION:
        raise ValueError('parent runtime source revision differs from frozen parent')
    receipt_path = data / manifest['build_receipt']
    receipt = read(receipt_path)
    receipt_identity = identity(receipt_path)
    if (receipt_identity['sha256'] != manifest['build_receipt_sha256'] or receipt.get('status') != 'passed'
            or receipt.get('head') != manifest['source_revision'] or receipt.get('working_tree') != ''
            or receipt.get('changed_source_inventory') != {}):
        raise ValueError(role + ' build receipt does not prove clean committed source')
    command = receipt.get('command', [])
    if not all(token in command for token in ('--release','--features','release-user-surfaces')):
        raise ValueError(role + ' build receipt lacks identical release feature command')
    expected_cwd = str(repo_root if role == 'parent' else candidate_root)
    if receipt.get('cwd') != expected_cwd:
        raise ValueError(role + ' build receipt cwd differs from its source checkout')
    runtime, products = {}, []
    for key, filename in [('binary','shardloom'),('library','_native.abi3.so')]:
        artifact = identity(data / name / filename)
        expected = manifest['files'][filename]
        if (artifact['sha256'] != expected['sha256'] or artifact['generation']['bytes'] != expected['bytes']
                or manifest['products'][filename] != expected['sha256']):
            raise ValueError(role + ' runtime artifact differs from its manifest: ' + filename)
        runtime[key] = artifact
        products.append(artifact['sha256'])
    if len(set(products)) != 2:
        raise ValueError(role + ' runtime binary/library hashes unexpectedly match')
    return dict(name=role, manifest=identity(manifest_path), build_receipt=receipt_identity,
                source_revision=manifest['source_revision'], features=manifest['features'],
                untracked_source_paths=manifest['untracked_source_paths'], source_overlay=manifest['source_overlay'],
                runtime=runtime)


def run_cohort(root, data, protocol_path):
    plan = read(protocol_path)
    if plan != make_plan(root, data, plan['source']['candidate_repository']):
        raise ValueError('frozen selection or source archive changed after plan mode')
    design, inputs, frozen_files, relocated_harness, archive_files, _ = checked_admission(root,data)
    stage_complete(data, 'native', len(design['cases']))
    stage_complete(data, 'alternate', len(design['alternate_route_cases']))
    prepared = read(data / 'native-preparation/complete.json')
    for p in prepared['profiles'].values():
        frozen_files += [p['manifest'], *p['inputs'], *p['receipts']]
    candidate_root=Path(plan['source']['candidate_repository'])
    roles = {role: runtime_role(data, role, root, candidate_root) for role in ('parent','candidate')}
    if roles['parent']['features'] != roles['candidate']['features']:
        raise ValueError('parent and candidate features differ')
    if any(roles['parent']['runtime'][key]['sha256']==roles['candidate']['runtime'][key]['sha256']
           for key in ('binary','library')):
        raise ValueError('parent and candidate role binaries/libraries are not distinct')
    verify(frozen_files)
    for item in relocated_harness:
        if identity(Path(item['relocated']['path']))!=item['relocated']:
            raise ValueError('relocated original worker source changed')
    target = data / TARGET_NAME
    if target.exists():
        raise FileExistsError('immutable investigation target already exists')
    expected_profiles = {row['profile'] for row in plan['selector']['rows']}
    expected_profiles.add(plan['selector']['challenge']['profile'])
    with ExitStack() as stack:
        stack.enter_context(stage_lock(data))
        target.mkdir()
        guard = stack.enter_context(BenchmarkGuard(target,
            binary=Path(roles['parent']['runtime']['binary']['path']),memory_gb=2))
        active = target / 'active'
        active.mkdir()
        refs = {p:stack.enter_context(closing_db(data / ('reference-'+p) / 'expectations.sqlite',readonly=True))
                for p in expected_profiles}
        history = {route:stack.enter_context(closing_db(data / ('observe-'+route) / 'attempts.sqlite',readonly=True))
                   for route in ('native','alternate')}
        ledgers = {}
        for name in ('matched','challenge'):
            db = stack.enter_context(closing_db(target / (name+'.sqlite')))
            db.execute('CREATE TABLE attempt (seq INTEGER NOT NULL, id TEXT NOT NULL, route TEXT NOT NULL, role TEXT NOT NULL, status TEXT NOT NULL, packet BLOB NOT NULL, PRIMARY KEY(seq,route,role), UNIQUE(id,route,role))')
            ledgers[name] = db
        binding = dict(protocol=identity(protocol_path),driver=identity(Path(__file__)),
            archive=plan['archive_checks'],roles=roles,policy=design['execution'],
            order=plan['execution_contract']['order'])
        write_json(target / 'binding.json',binding)
        generations = {f['path']:f for f in frozen_files}
        for manifest in roles.values():
            for artifact in manifest['runtime'].values():
                generations[artifact['path']] = artifact
        jobs = [(i,row,'matched') for i,row in enumerate(plan['selector']['rows'])]
        jobs.append((0,plan['selector']['challenge'],'challenge'))
        for seq, frozen_row, cohort in jobs:
            route = frozen_row['route']
            spec = next(r for r in design['cases'] if r['id']==frozen_row['id'])
            ref = refs[spec['profile']].execute('SELECT identity,value FROM expected WHERE id=?',
                                               (spec['id'],)).fetchone()
            if ref is None or ref[0] != spec['case_identity'] or ref[0] != frozen_row['independent_expected_identity']:
                raise ValueError('exact independent expectation changed: ' + spec['id'])
            expected = unpack(ref[1])
            if cohort == 'challenge':
                roles_this = ('candidate',)
            else:
                roles_this = ('parent', 'candidate') if seq % 2 == 0 else ('candidate', 'parent')
            for role in roles_this:
                role_runtime = roles[role]['runtime']
                job = source_record(spec,route,inputs,prepared,design['execution'],expected,role_runtime)
                original_job = source_record(spec,route,inputs,prepared,design['execution'],expected)
                old = history[route].execute('SELECT packet FROM attempt WHERE id=?',(spec['id'],)).fetchone()
                if old is None:
                    raise ValueError('source historical job missing')
                old_files = raw_files(unpack(old[0]))
                if json.loads(old_files['one.job.json']) != original_job:
                    raise ValueError('new driver request differs from existing declared job')
                verify_request_files(job,generations)
                guard.check()
                db = ledgers[cohort]
                ledger_path=target/(cohort+'.sqlite')
                if ledger_path.exists() and ledger_path.stat().st_size >= 128<<20:
                    raise RuntimeError('active investigation ledger reached its 128 MiB storage limit')
                db.execute("INSERT INTO attempt VALUES (?,?,?,?, 'started',?)",
                           (seq,spec['id'],route,role,b'pending'))
                db.commit()
                job_path = active / 'one.job.json'
                write_json(job_path,job)
                cmd = [sys.executable,'-B',str(data/'investigation-original-harness-r1/benchmarks/traditional_analytics/query_surface/expanded_worker.py'),
                       '--job',str(job_path)]
                receipt = run_profiled_command(cmd,active/'one',
                    design['execution']['query_deadline_seconds']+5,guard.check)
                files = raw_packet(active)
                outcome = worker_outcome(receipt,(active/'one.stdout.json').read_bytes())
                packet = dict(supervision=receipt,files=files,classified_status=outcome['status'],
                              classification_detail=outcome.get('detail'))
                encoded = pack(packet)
                db.execute("UPDATE attempt SET status=?,packet=? WHERE seq=? AND route=? AND role=? AND status='started'",
                           (outcome['status'],encoded,seq,route,role))
                db.commit()
                saved = db.execute('SELECT packet FROM attempt WHERE seq=? AND route=? AND role=?',
                                   (seq,route,role)).fetchone()[0]
                if saved != encoded:
                    raise ValueError('raw packet did not persist')
                for name in files:
                    path = active/name
                    if identity(path)['sha256'] != files[name]['sha256']:
                        raise ValueError('active result changed before retention')
                    path.unlink()
                if any(any(token in failure for token in ('another native workload','free','storage'))
                       for failure in receipt['guard_failures']):
                    raise RuntimeError(receipt['guard_failures'])
            print(f'{cohort} {seq + 1}: {spec["id"]} ({route}) recorded', flush=True)
        if any(active.iterdir()):
            raise ValueError('active output directory not empty after exact single-pass capture')
        statuses = {name:dict(db.execute('SELECT status,COUNT(*) FROM attempt GROUP BY status'))
                    for name,db in ledgers.items()}
        for name,db in ledgers.items():
            if db.execute('SELECT COUNT(*) FROM attempt').fetchone()[0] != (
                    len(plan['selector']['rows'])*2 if name=='matched' else 1):
                raise ValueError('unexpected attempt ledger cardinality: '+name)
        verify(frozen_files)
        if {role:runtime_role(data,role,root,candidate_root) for role in roles}!=roles:
            raise ValueError('role runtime changed during the isolated cohort')
        for item in relocated_harness:
            if identity(Path(item['relocated']['path']))!=item['relocated']:
                raise ValueError('original worker harness changed during the cohort')
        write_json(target/'complete.json',dict(status='captured_once',protocol=identity(protocol_path),
            binding=identity(target/'binding.json'),ledgers={name:identity(target/(name+'.sqlite')) for name in ledgers},
            statuses=statuses,matched_rows=len(plan['selector']['rows']),challenge_rows=1,
            matched_attempts_per_case_route_role=1,challenge_attempts=1,no_retries=True,
            posthash_verified=True,guard_samples=guard.samples))
    print(json.dumps({'matched_jobs':len(plan['selector']['rows']),'challenge_jobs':1,
                      'statuses':statuses},sort_keys=True))


def replay_cohort(root, data, protocol_path):
    plan = read(protocol_path)
    target = data / TARGET_NAME
    complete = read(target/'complete.json')
    if complete['protocol'] != identity(protocol_path) or complete['status'] != 'captured_once':
        raise ValueError('captured cohort binding is incomplete')
    design, inputs, frozen_files, relocated_harness, archive_files, _ = checked_admission(root,data)
    prepared = read(data/'native-preparation/complete.json')
    for p in prepared['profiles'].values():
        frozen_files += [p['manifest'],*p['inputs'],*p['receipts']]
    binding = read(target/'binding.json')
    if binding['driver'] != identity(Path(__file__)) or binding['protocol'] != identity(protocol_path):
        raise ValueError('driver/protocol artifact binding differs')
    candidate_root=Path(plan['source']['candidate_repository'])
    roles = {role:runtime_role(data,role,root,candidate_root) for role in ('parent','candidate')}
    if roles != binding['roles']:
        raise ValueError('runtime role artifact changed after capture')
    verify(frozen_files)
    for item in relocated_harness:
        if identity(Path(item['relocated']['path']))!=item['relocated']:
            raise ValueError('relocated original worker source changed')
    item_defs = {s.name:s for s in spaces()}
    spec_by_id = {row['id']:row for row in design['cases']}
    refs = {}
    profiles = {r['profile'] for r in plan['selector']['rows']} | {plan['selector']['challenge']['profile']}
    checked, challenge_result = [], None
    with ExitStack() as stack:
        refs = {p:stack.enter_context(closing_db(data/('reference-'+p)/'expectations.sqlite',readonly=True)) for p in profiles}
        for cohort in ('matched','challenge'):
            db = stack.enter_context(closing_db(target/(cohort+'.sqlite'),readonly=True))
            frozen_rows = plan['selector']['rows'] if cohort=='matched' else [plan['selector']['challenge']]
            for seq,frozen_row in enumerate(frozen_rows):
                spec = spec_by_id[frozen_row['id']]
                ref = refs[spec['profile']].execute('SELECT identity,value FROM expected WHERE id=?',(spec['id'],)).fetchone()
                if ref is None or ref[0] != frozen_row['independent_expected_identity']:
                    raise ValueError('reference identity changed during replay')
                expected = unpack(ref[1])
                routes = [(frozen_row['route'],'parent'),(frozen_row['route'],'candidate')] if cohort=='matched' else [(frozen_row['route'],'candidate')]
                values = {}
                for route,role in routes:
                    entry = db.execute('SELECT seq,id,status,packet FROM attempt WHERE seq=? AND id=? AND route=? AND role=?',
                                       (seq,spec['id'],route,role)).fetchone()
                    if entry is None:
                        raise ValueError('missing captured one-shot attempt')
                    role_inputs = dict(inputs,runtime=roles[role]['runtime'])
                    actual = replay(entry,spec,'native' if route=='native' else 'alternate',expected,
                                    build(spec,item_defs),role_inputs,prepared,design['execution'])
                    if actual.get('status') == 'passed':
                        packet = unpack(entry[3])
                        stdout = json.loads(raw_files(packet)['one.stdout.json'])
                        observation = stdout['observation']
                        if stdout['execution_engine'] != 'native' or observation['complete_consumption'] is not True:
                            raise ValueError('candidate is not a complete native execution')
                        no_fallback(observation['fields'])
                        actual['source_owner_fields']={k:v for k,v in observation['fields'].items()
                            if k.startswith(('native_source_','execution_resource_observed_',
                                'relational_','local_primitive_'))}
                    values[role] = actual
                record = dict(seq=seq,id=spec['id'],route=frozen_row['route'],
                    selection_reasons=frozen_row.get('selection_reasons'),parent=values.get('parent'),
                    candidate=values.get('candidate'),historical=frozen_row['historical'])
                record['complete_output_correct']=(values.get('parent',{}).get('status')=='passed'
                    and values.get('candidate',{}).get('status')=='passed') if cohort=='matched' else None
                if cohort=='matched':
                    checked.append(record)
                else:
                    challenge_result = record
    candidate_paired = [r['candidate'].get('engine_seconds') for r in checked]
    parent_paired = [r['parent'].get('engine_seconds') for r in checked]
    totals_available = (len(checked) == plan['selector']['matched_jobs']
        and all(r['complete_output_correct'] for r in checked)
        and all(isinstance(x, (int, float)) and math.isfinite(x) and x >= 0
                for x in candidate_paired + parent_paired))
    comparison = dict(status='replayed', matched_rows=checked,
        matched_case_route_count=len(checked),historical_passed_count=sum(r['historical']['status']=='passed' for r in checked),
        parent_engine_sum=math.fsum(parent_paired) if totals_available else None,
        candidate_engine_sum=math.fsum(candidate_paired) if totals_available else None,
        paired_engine_sum_valid=totals_available,challenge=challenge_result,
        challenge_separate_from_matched_sum=True, protocol=identity(protocol_path),
        complete=identity(target/'complete.json'),
        acceptance='Primary-owned review; no automatic timing verdict. Every captured request is replayed against its exact independent full output; inspect status, no-fallback, native attribution, resource ceiling, and source/owner work fields.')
    write_json(target/'replay.json',comparison)
    print(json.dumps({'status':'replayed','matched_case_route_count':len(checked),
        'parent_engine_sum':comparison['parent_engine_sum'],'candidate_engine_sum':comparison['candidate_engine_sum'],
        'challenge_status':challenge_result['candidate']['status'] if challenge_result else None},sort_keys=True))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=('plan','run','replay'))
    parser.add_argument('--root',type=Path,default=ROOT_DEFAULT)
    parser.add_argument('--data',type=Path,default=DATA_DEFAULT)
    parser.add_argument('--candidate-root',type=Path,default=I_DEFAULT)
    args=parser.parse_args()
    root,data=args.root.resolve(),args.data.resolve()
    candidate_root=args.candidate_root.resolve()
    protocol_path=data/PROTOCOL_NAME
    if args.stage=='plan':
        if protocol_path.exists():
            raise FileExistsError('immutable protocol already exists')
        plan=make_plan(root,data,candidate_root)
        prior_path = data / 'investigation-protocol-r1.json'
        if identity(prior_path)['sha256'] != '53b07f6c7f21edbe95c090f282f115fccccbab18d65d15cf849aac6d6cc6a154':
            raise ValueError('superseded protocol changed')
        prior = read(prior_path)
        for key in ('selector', 'policy', 'source', 'archive_checks', 'runtime_contract'):
            if plan[key] != prior[key]:
                raise ValueError('pre-score revision changed frozen request bindings: ' + key)
        write_json(protocol_path,plan)
        print(json.dumps({'protocol':str(protocol_path),'matched_jobs':plan['selector']['matched_jobs'],
            'matched_case_ids':plan['selector']['matched_case_ids'],'challenge_jobs':1,
            'route_counts':plan['selector']['route_counts'],
            'profile_counts':plan['selector']['profile_counts'],
            'selector_category_job_counts':{'membership':plan['selector']['category_membership_job_count'],
                'grouping':plan['selector']['category_grouping_job_count'],
                'windows':plan['selector']['category_window_job_count']},
            'missing_membership_cells':len(plan['selector']['missing_cells']['membership']),
            'missing_grouping_cells':len(plan['selector']['missing_cells']['grouping']),
            'missing_window_cells':len(plan['selector']['missing_cells']['windows']),
            'topk_rerun':False},sort_keys=True))
    elif args.stage=='run':
        run_cohort(root,data,protocol_path)
    else:
        replay_cohort(root,data,protocol_path)


if __name__=='__main__':
    main()
