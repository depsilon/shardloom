# SPDX-License-Identifier: Apache-2.0
"""Re-observe the original 10,000 native requests on an admitted shared-mechanisms runtime.

The capture loop is the frozen expanded_run.observe. The new admission and
destination keep both completed comparison stages immutable.
"""
from __future__ import annotations

import argparse
from contextlib import ExitStack
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import run_investigation_cohort_r2 as common
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
from resources import BenchmarkGuard
from run_clickbench_query_uat import run_profiled_command
from query_surface.evidence import identity, worker_outcome
from query_surface.expanded_freeze import pack, read, unpack
from query_surface.expanded_run import closing_db, raw_packet, request, stage_complete, stage_lock, verify, verify_request_files
from query_surface.run import write_json

TARGET_NAME = "shared-mechanisms-10k-r1"
ADMISSION_NAME = "shared-mechanisms-admission-r1.json"
PROTOCOL_NAME = "shared-mechanisms-10k-protocol-r1.json"
LEGACY_BASELINE = "90c17ec7abb3d414008cbab4446dac63d9cd838e"
WORKER = common.HARNESS_DEFAULT / "benchmarks/traditional_analytics/query_surface/expanded_worker.py"


def _file_identity(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return dict(bytes=path.stat().st_size, sha256=digest.hexdigest())


def updated_admission(root, require_protocol=True):
    if not __debug__:
        raise ValueError("measurement requires enabled assertions")
    admission_path = root / ADMISSION_NAME
    admission = read(admission_path)
    source_root = Path(admission["source_root"]).resolve(strict=True)
    build_source = admission["build_source"]
    head = admission["head"]
    runtime_directory = Path(admission["runtime_directory"]).resolve(strict=True)
    acceptance = Path(admission["acceptance"]).resolve(strict=True)
    if not source_root.is_dir() or not runtime_directory.is_dir():
        raise ValueError("admitted source/runtime paths must be directories")

    def git(*args):
        return subprocess.check_output(["git", *args], cwd=source_root, text=True).strip()

    if head != build_source or git("rev-parse", "HEAD") != head or git("status", "--porcelain"):
        raise ValueError("admitted source must be the exact clean build source")
    if git("diff", "--name-only", LEGACY_BASELINE, head, "--", "python/src/shardloom"):
        raise ValueError("production Python client differs from the frozen historical baseline")

    manifest_path = runtime_directory / "manifest.json"
    manifest = read(manifest_path)
    if (manifest.get("schema_version") != "shardloom.source_milestone_runtime.v1"
            or manifest.get("profile") != "release"
            or manifest.get("features") != ["release-user-surfaces"]
            or manifest.get("source_revision") != build_source
            or manifest.get("untracked_source_paths") != []
            or manifest.get("source_overlay") != {"bytes": 0,
                "sha256": hashlib.sha256(b"").hexdigest()}):
        raise ValueError("runtime manifest is not a clean release-user-surfaces build")
    snapshot = manifest["source_snapshot"]
    if not snapshot:
        raise ValueError("runtime source snapshot is empty")
    snapshot_identities = []
    for relative, expected in snapshot.items():
        relative_path = Path(relative)
        path = source_root / relative_path
        if (relative_path.is_absolute() or not path.is_file() or path.is_symlink()
                or source_root not in path.resolve().parents or _file_identity(path) != expected):
            raise ValueError("release source snapshot differs: " + relative)
        snapshot_identities.append(identity(path))

    build_path = root / manifest["build_receipt"]
    build_receipt = read(build_path)
    expected_command = ["cargo", "build", "--locked", "--offline", "--release",
                        "--features", "release-user-surfaces", "-p", "shardloom-cli",
                        "-p", "shardloom-python"]
    if (build_receipt.get("status") != "passed" or build_receipt.get("returncode") != 0
            or build_receipt.get("process_group_drained") is not True
            or build_receipt.get("direct_child_reaped") is not True
            or build_receipt.get("working_tree") != ""
            or build_receipt.get("changed_source_inventory") != {}
            or build_receipt.get("command") != expected_command
            or build_receipt.get("head") != head
            or build_receipt.get("cwd") != str(source_root)
            or _file_identity(build_path)["sha256"] != manifest["build_receipt_sha256"]):
        raise ValueError("release build receipt does not prove the exact clean build")

    runtime_files = {}
    product_files = []
    for key, filename in (("binary", "shardloom"), ("library", "_native.abi3.so")):
        artifact_path = runtime_directory / filename
        artifact = identity(artifact_path)
        product = manifest["files"][filename]
        actual = _file_identity(artifact_path)
        if (artifact_path.is_symlink() or actual != {"bytes": product["bytes"],
                "sha256": product["sha256"]}
                or manifest["products"].get(filename) != product["sha256"]):
            raise ValueError("runtime product differs from its manifest: " + filename)
        runtime_files[key] = artifact
        product_files.append(product["sha256"])
    if len(set(product_files)) != 2:
        raise ValueError("runtime binary and library identities unexpectedly match")

    accepted = read(acceptance)
    if (accepted.get("status") != "passed" or accepted.get("head") != head
            or accepted.get("measured_candidate") != build_source
            or accepted.get("runtime_source_equality") is not True):
        raise ValueError("local acceptance does not cover this measured runtime")
    design, inputs, frozen, relocated, archive, _ = common.checked_admission(common.ROOT_DEFAULT, root)
    original = read(root / "updated-native-10k-r1" / "complete.json")
    if (original.get("status") != "complete_observation" or original.get("stage") != "native"
            or original.get("total") != 10000 or original.get("attempt_slots") != 10000
            or original.get("outcomes") != {"passed": 10000}
            or original.get("attempts_per_case") != 1 or original.get("requested_repeats") != 0
            or original.get("posthash_verified") is not True
            or original.get("frozen") != identity(root / "frozen.json")):
        raise ValueError("prior accepted native 10k observation is incomplete or not frozen-match")
    legacy_native = stage_complete(root, "native", design["count"])
    if (legacy_native["outcomes"].get("passed") != 9995
            or sum(legacy_native["outcomes"].values()) != 10000
            or legacy_native.get("posthash_verified") is not True):
        raise ValueError("original native observation is not preserved as its legacy prerequisite")
    baseline = stage_complete(root, "polars", design["count"])
    if baseline["outcomes"] != {"passed": 10000}:
        raise ValueError("cached Polars comparison pass differs from its original observation")
    updated = dict(head=head, build_source=build_source, source_root=str(source_root),
                   runtime_directory=str(runtime_directory), runtime=runtime_files,
                   manifest=identity(manifest_path), build=identity(build_path),
                   selection="all 10000 primary native declarations in original manifest order",
                   previous_native=identity(root / "updated-native-10k-r1/complete.json"),
                   legacy_native=identity(root / "observe-native/complete.json"),
                   cached_polars=identity(root / "observe-polars/complete.json"),
                   prepared=identity(root / "native-preparation/complete.json"),
                   original_freeze=identity(root / "frozen.json"),
                   acceptance=identity(acceptance), driver=identity(Path(__file__).resolve()),
                   admission_helper=identity(Path(common.__file__).resolve()), original_worker=identity(WORKER),
                   admission=identity(admission_path),
                   supervisor=identity(root / "tools/guard_shared_mechanisms.py"),
                   isolation_driver=identity(root / "tools/isolate_shared_10k.py"),
                   warmups=0, attempts_per_case=1, alternate_attempts=0)
    added = [*archive, *snapshot_identities, *runtime_files.values(), updated["manifest"], updated["build"],
             updated["admission"], original["ledger"], baseline["ledger"], legacy_native["ledger"],
             updated["previous_native"], updated["legacy_native"], updated["cached_polars"],
             updated["prepared"], updated["original_freeze"], updated["acceptance"], updated["driver"],
             updated["admission_helper"], updated["original_worker"],
             updated["supervisor"], updated["isolation_driver"]]
    verify(added)
    protocol_path = root / PROTOCOL_NAME
    protocol = dict(status="admitted_before_execution", selection=updated["selection"],
                    design=identity(root / "design.json"), source=identity(root / "inputs.json"),
                    frozen=identity(root / "frozen.json"), execution=design["execution"],
                    runtime_binding=updated, expected_attempt_count=design["count"],
                    supervisor=updated["supervisor"], isolation_driver=updated["isolation_driver"],
                    attempts_per_case=1, warmups=0)
    if require_protocol:
        if not protocol_path.is_file() or read(protocol_path) != protocol:
            raise ValueError("declared run protocol is absent or differs from current admission")
        added.append(identity(protocol_path))
        verify([added[-1]])
    return design, dict(inputs, runtime=runtime_files), [*frozen, *added], updated


def write_plan(root):
    design, _, _, updated = updated_admission(root, require_protocol=False)
    protocol = dict(status="admitted_before_execution", selection=updated["selection"],
                    design=identity(root / "design.json"), source=identity(root / "inputs.json"),
                    frozen=identity(root / "frozen.json"), execution=design["execution"],
                    runtime_binding=updated, expected_attempt_count=design["count"],
                    supervisor=updated["supervisor"], isolation_driver=updated["isolation_driver"],
                    attempts_per_case=1, warmups=0)
    path = root / PROTOCOL_NAME
    with path.open("x") as stream:
        json.dump(protocol, stream, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    verify([identity(path)])
    print(json.dumps(dict(status="admitted_before_execution", protocol=str(path),
                          selection=updated["selection"], total=design["count"])))


def observe(root, resume):
    stage = "native"
    design, inputs, frozen_files, updated = updated_admission(root)
    prepared = {}
    prerequisites = {}
    if stage != "polars":
        stage_complete(root, "polars", design["count"])
        prerequisites["polars"] = identity(root / "observe-polars/complete.json")
        prerequisites["preparation"] = identity(root / "native-preparation/complete.json")
        prepared = read(root / "native-preparation/complete.json")
        if (
            prepared["status"] != "passed"
            or prepared["frozen"] != identity(root / "frozen.json")
            or prepared["polars_complete"] != prerequisites["polars"]
        ):
            raise ValueError("explicit preparation is incomplete")
        extra = [
            f for p in prepared["profiles"].values() for f in [p["manifest"], *p["inputs"], *p["receipts"]]
        ]
        verify(extra)
        frozen_files += extra
    if stage == "alternate":
        stage_complete(root, "native", design["count"])
        prerequisites["native"] = identity(root / "observe-native/complete.json")
    selected = [r for r in design["cases"] if stage != "alternate" or r["surrogate"]]
    if stage == "alternate" and [r["id"] for r in selected] != design["alternate_route_cases"]:
        raise ValueError("paired probe order changed")
    target = root / TARGET_NAME
    if (target / "complete.json").exists():
        raise FileExistsError("completed scored stage cannot be repeated")
    if target.exists() != resume:
        raise ValueError("select a fresh stage, or explicitly resume its unattempted requests")
    policy = design["execution"]
    wanted_freeze = identity(root / "frozen.json")
    generations = {f["path"]: f for f in frozen_files}
    budget = check_budgets(
        root,
        root / "reserved-output",
        root / "logs",
        min_free_bytes=12 * GIB,
        reserve_bytes=64 * MIB,
        max_workspace_bytes=100 * GIB,
        max_log_bytes=192 * MIB,
    )
    with stage_lock(root), ExitStack() as stack:
        target.mkdir(exist_ok=resume)
        guard = stack.enter_context(
            BenchmarkGuard(target, binary=Path(inputs["runtime"]["binary"]["path"]), memory_gb=2)
        )
        references = {}
        for profile in {r["profile"] for r in selected}:
            loc = root / ("reference-" + profile) / "expectations.sqlite"
            references[profile] = stack.enter_context(closing_db(loc, readonly=True))
        ledger = target / "attempts.sqlite"
        db = stack.enter_context(closing_db(ledger))
        db.execute(
            "CREATE TABLE IF NOT EXISTS attempt (seq INTEGER PRIMARY KEY,id TEXT NOT NULL UNIQUE,status TEXT NOT NULL, packet BLOB)"
        )
        binding = target / "binding.json"
        contract = {"frozen": wanted_freeze, "stage": stage, "prerequisites": prerequisites, "updated": updated}
        if resume:
            if read(binding)["contract"] != contract:
                raise ValueError("resumed stage bindings differ")
            db.execute("UPDATE attempt SET status='incomplete' WHERE status='started'")
            db.commit()
        else:
            write_json(binding, {"contract": contract, "started_at": datetime.now(timezone.utc).isoformat()})
        active = target / "active"
        active.mkdir(exist_ok=resume)
        # A non-empty active folder after interruption is evidence. Keep it
        # without executing that slot again.
        if any(active.iterdir()):
            if not resume:
                raise ValueError("active directory must initially be empty")
            active.rename(target / ("interrupted-" + str(time.time_ns())))
            active.mkdir()
        seen = {seq: (id_, status) for seq, id_, status in db.execute("SELECT seq,id,status FROM attempt")}
        if any(
            seq < 0 or seq >= len(selected) or selected[seq]["id"] != id_ for seq, (id_, _) in seen.items()
        ):
            raise ValueError("resumed attempt identities differ")
        for seq, row in enumerate(selected):
            if seq in seen:
                continue
            ref = (
                references[row["profile"]]
                .execute("SELECT identity,value FROM expected WHERE id=?", (row["id"],))
                .fetchone()
            )
            if ref is None or ref[0] != row["case_identity"]:
                raise ValueError("case lacks an exact independent result")
            job = request(row, stage, inputs, prepared, unpack(ref[1]), policy)
            verify_request_files(job, generations)
            guard.check()
            if ledger.exists() and ledger.stat().st_size > 1536 * MIB:
                raise ValueError(
                    "active compressed evidence exceeds the prospectively bounded storage allocation"
                )
            job_path = active / "one.job.json"
            write_json(job_path, job)
            db.execute("INSERT INTO attempt VALUES (?,?,?,NULL)", (seq, row["id"], "started"))
            db.commit()
            cmd = [
                sys.executable,
                "-B",
                str(WORKER),
                "--job",
                str(job_path),
            ]
            receipt = run_profiled_command(
                cmd, active / "one", policy["query_deadline_seconds"] + 5, guard.check
            )
            raw = (active / "one.stdout.json").read_bytes()
            outcome = worker_outcome(receipt, raw)
            status = outcome["status"]
            if status in {"passed", "incorrect", "comparison_inconclusive"} and (
                outcome.get("id") != row["id"]
                or outcome.get("case_identity") != row["case_identity"]
                or outcome.get("execution_engine") != job["engine"]
            ):
                raise ValueError("successful worker response belongs to another request")
            packet = dict(
                supervision=receipt,
                files=raw_packet(active),
                classified_status=status,
                classification_detail=outcome.get("detail"),
            )
            encoded = pack(packet)
            db.execute(
                "UPDATE attempt SET status=?,packet=? WHERE id=? AND status='started'",
                (status, encoded, row["id"]),
            )
            db.commit()
            saved = db.execute("SELECT packet FROM attempt WHERE id=?", (row["id"],)).fetchone()[0]
            if saved != encoded:
                raise ValueError("compressed evidence did not persist")
            for name, value in packet["files"].items():
                path = active / name
                if hashlib.sha256(path.read_bytes()).hexdigest() != value["sha256"]:
                    raise ValueError("active evidence changed before compact retention")
                path.unlink()
            global_failure = [
                f
                for f in receipt["guard_failures"]
                if "another native workload" in f or "free" in f or "storage" in f
            ]
            if global_failure:
                raise ValueError("external guard stopped the stage: " + str(global_failure))
            if (seq + 1) % 100 == 0 or seq + 1 == len(selected):
                print(
                    json.dumps(
                        dict(
                            stage=stage,
                            attempts=seq + 1,
                            total=len(selected),
                            outcomes=dict(db.execute("SELECT status,COUNT(*) FROM attempt GROUP BY status")),
                        )
                    ),
                    flush=True,
                )
        outcomes = dict(db.execute("SELECT status,COUNT(*) FROM attempt GROUP BY status"))
        observed = list(db.execute("SELECT id FROM attempt ORDER BY seq"))
        if observed != [(r["id"],) for r in selected] or "started" in outcomes:
            raise ValueError("incomplete attempt inventory")
    verify(frozen_files)
    write_json(
        target / "complete.json",
        dict(
            status="complete_observation",
            stage=stage,
            updated=updated,
            frozen=wanted_freeze,
            total=len(selected),
            attempt_slots=sum(outcomes.values()),
            outcomes=outcomes,
            ledger=identity(ledger),
            binding=identity(binding),
            prerequisites=prerequisites,
            completed_at=datetime.now(timezone.utc).isoformat(),
            storage_before=budget,
            posthash_verified=True,
            attempts_per_case=1,
            requested_repeats=0,
        ),
    )



if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", action="store_true")
    parser.add_argument("--resume-unattempted", action="store_true")
    args = parser.parse_args()
    os.environ["POLARS_MAX_THREADS"] = "2"
    root = require_local_path(common.DATA_DEFAULT, Path.home(), sys.platform)
    if args.plan:
        if args.resume_unattempted:
            parser.error("--plan cannot be combined with --resume-unattempted")
        write_plan(root)
    else:
        observe(root, args.resume_unattempted)
