# Shared-index cohort preparation

The case list is now fixed in `index-cohort-selection-r1.json`; the complete
experiment protocol is not yet bound and execution is not admitted. Finish the
dictionary repair's hosted integration and cleanup before binding its accepted
source/runtime into that protocol. No candidate implementation or timing results
were used in this selection.

`tools/preview_index_cohort.py` reads the original design and repair selection
metadata only. In original manifest order, keep the first case in each observed:

- Family/archetype/profile/public-surface/native-format cell across all families.
  This retains broad controls, including paths that may bypass this index.
- Archetype/profile/scope/key-or-group-or-partition/right-scope cell in grouped
  aggregation, joins, multiway joins, sets, subqueries, windows, DISTINCT and CTE
  composition. This covers source extent and key-domain combinations.
- Archetype/profile/scope/build/dimension/probe cell in those families where
  build metadata exists. This covers build restrictions and membership probes.
- Archetype/profile/single-factor/value cell in those families. This preserves
  each declared argument/function and other factor value even when the preceding
  combinations selected a different value.

Also retain every named stress surrogate in those eight families. Deduplicate
the union and preserve original order. Family participates in every key to avoid
collapsing similarly named archetypes across distinct family records. This is
coverage of observed cells, not the complete Cartesian product or proof that
every selected request executes this owner. Direct native diagnostics and
consumer tests must separately establish activation, collision semantics and
resource behavior.

The preview produced 2,452 cases: 1,372 route cells, 1,604 shape cells, 605 build
cells, 1,958 single-factor cells and six named stress cases before union. It
includes 695 holdout, 1,565 primary, 63 scale and 129 smoke cases. The ordered
`(ordinal, id, case_identity)` JSON SHA-256 is
`884568fc950671c696bdde26f2016a192a6a218d1370beea195382c7d39514ee`.
The script SHA-256 is
`1d5f2fda08d3ec1a4976bf50cea7e133a8f54e13cba2da335bd88177dd8e5f1c`.
The exact original design SHA-256 remains
`fd0a2604c9abc888a7a24ba75078569fc33e354b16cc98372977c15306a39216`.

433 case identities overlap the repair's 517-case metadata; 2,019 do not. This
is not yet permission to reuse observations: verify each complete saved result,
runtime/source, native input generations, request/expectation, worker/supervisor,
resource policy and engine clock against the new protocol. Capture any required
new baseline observations once with the existing isolation/storage/deadline
guards. Keep instrumentation out of the scored runtime.

`tools/freeze_index_cohort.py` fixed the exact case list after reproducing the
preview's ordered identity digest. The selection is 2,213,038 bytes with SHA-256
`5477c06868540fff63d418d6fd1a50ca8a1597627efb0c35131826efe13bde52`.
It records zero query executions and explicitly denies execution until a separate
source/runtime/input/worker/resource/isolation/clock protocol is frozen after
repair acceptance. The ordinary draft preview remains unchanged as prior evidence.

Bind the comparison/reuse evidence and retain/drop rule before candidate
measurements. Accept only complete correct native results and resource
ownership evidence. Lower total engine time across this entire frozen cohort
retains the candidate; equal or higher drops it. Report this cohort's scope
explicitly. It does not create a repaired full-10k total or erase the original
failed observation. Compatible-window sharing and rolling-DISTINCT membership
remain separate experiments.
