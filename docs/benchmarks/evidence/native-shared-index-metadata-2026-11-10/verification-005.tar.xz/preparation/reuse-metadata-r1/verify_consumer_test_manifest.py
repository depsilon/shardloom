"""Bind the static consumer inventory to actual Rust module paths; run no tests."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
INPUT = ROOT / 'consumer-test-manifest-r1.json'
OUTPUT = ROOT / 'consumer-test-manifest-primary-r1.json'
assert not OUTPUT.exists()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
assert head == '037b6801320aa0bfe939ba10aed9304198b77a5a'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=W, text=True)
leaf = json.loads(INPUT.read_bytes())
assert leaf['head'] == head and leaf['active_repo'] == str(W)
assert leaf['query_build_test_executions'] == 0


def identity(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


sources = {}
for row in leaf['source_identities']:
    assert identity(W / row['path']) == {key: row[key] for key in ('bytes', 'sha256')}
    sources[row['path']] = identity(W / row['path'])
inventory = Path(leaf['inventory_source']['path'])
assert identity(inventory)['sha256'] == leaf['inventory_source']['sha256']
section = inventory.read_text().split('## Existing direct complete-output tests found\n', 1)[1].split('\n## Search coverage', 1)[0]
names = {row['name'] for row in leaf['tests']}
assert len(names) == len(leaf['tests']) == 41
named_in_section = set()
for token in re.findall(r'`([^`]+)`', section):
    name = token.rsplit('::', 1)[-1]
    if name in names:
        named_in_section.add(name)
assert len(named_in_section) == 33
index = 'shardloom-vortex/src/local_primitives/native_relational_index.rs'
index_text = (W / index).read_text()
index_names = set(re.findall(r'#\[test\]\s*fn (\w+)\(', index_text))
assert len(index_names) == 7
cyclic = 'cyclic_candidate_counts_actual_work_for_all_four_frozen_targets'
assert names == named_in_section | index_names | {cyclic}

# These test modules use explicit path attributes. Follow only actual declaration
# edges; a source filename is not a Rust module identifier or a libtest filter.
paths = subprocess.check_output(['git', 'ls-files', 'shardloom-vortex/src'], cwd=W, text=True).splitlines()
edges = {}
pattern = re.compile(r'((?:^\s*#\[[^\n]+\]\n)+)\s*(?:pub(?:\([^\n]*?\))?\s+)?mod\s+(\w+)\s*;', re.M)
for relative in paths:
    if not relative.endswith('.rs'):
        continue
    path = W / relative
    text = path.read_text()
    for match in pattern.finditer(text):
        attrs, module = match.groups()
        target = re.search(r'#\[path = "([^"]+)"\]', attrs)
        if target is None:
            continue
        child = (path.parent / target[1]).resolve()
        if child.is_file() and child.is_relative_to(W):
            edges.setdefault(child.relative_to(W).as_posix(), []).append(dict(
                parent=relative, module=module,
                line=text[:match.start()].count('\n') + 1,
                declaration=match.group().strip()))


def chain(relative):
    if relative == 'shardloom-vortex/src/local_primitives.rs':
        source = W / 'shardloom-vortex/src/lib.rs'
        declaration = 'pub mod local_primitives;'
        text = source.read_text()
        assert text.count(declaration) == 1
        return [dict(parent=source.relative_to(W).as_posix(), module='local_primitives',
            line=text[:text.index(declaration)].count('\n') + 1, declaration=declaration)]
    parents = edges.get(relative, [])
    assert len(parents) == 1, (relative, parents)
    edge = parents[0]
    return [*chain(edge['parent']), edge]


tests = []
for row in leaf['tests']:
    relative, name = row['path'], row['name']
    text = (W / relative).read_text()
    declaration = re.compile(r'^\s*fn ' + re.escape(name) + r'\(', re.M)
    matches = list(declaration.finditer(text))
    assert len(matches) == 1
    start = matches[0].start()
    function_start = text.index('fn ' + name + '(', start)
    assert text[:function_start].count('\n') + 1 == row['line']
    previous = text[:function_start].rstrip()
    assert previous.endswith('#[test]'), (relative, name)
    declarations = chain(relative)
    if relative == index:
        inline = '#[cfg(test)]\nmod tests {'
        assert text.count(inline) == 1
        declarations.append(dict(parent=relative, module='tests',
            line=text[:text.index(inline)].count('\n') + 1, declaration=inline))
    for edge in declarations:
        sources[edge['parent']] = identity(W / edge['parent'])
    modules = [edge['module'] for edge in declarations]
    tests.append(dict(name=name, path=relative, line=row['line'], declarations=declarations,
        module_filter='::'.join(modules) + '::', exact_test_name='::'.join([*modules, name]),
        status='source_resolved_not_executed'))
filters = sorted({row['module_filter'] for row in tests})
filters = [value for value in filters if not any(value != other and value.startswith(other) for other in filters)]
assert all(any(row['exact_test_name'].startswith(value) for value in filters) for row in tests)
sources['shardloom-vortex/Cargo.toml'] = identity(W / 'shardloom-vortex/Cargo.toml')
result = dict(schema='shardloom.row_index_consumer_test_manifest.v1', status='passed_static_verification',
    active_repo=str(W), head=head, query_executions=0, build_executions=0, test_executions=0,
    source_manifest=dict(path=str(INPUT), **identity(INPUT)),
    inventory_source=dict(path=str(inventory), **identity(inventory)),
    inventory_named_tests=33, existing_index_tests=7, existing_cyclic_counter_test=1,
    tests=tests, module_filters=filters, source_identities=sources,
    intended_feature='shardloom-vortex/native-encoded-exchange-experiment',
    limitations=['Static source paths and gates are verified; compiler/libtest selection and test outcomes remain unobserved.',
        'The module filters deliberately include neighboring existing tests; the full native suite is still required.',
        'The source manifest used filenames and a crate-name prefix as speculative filters. This primary result replaces those filters.'])
with OUTPUT.open('x') as output:
    json.dump(result, output, indent=2); output.write('\n')
print(json.dumps(dict(status=result['status'], tests=len(tests), module_filters=filters,
    query_executions=0, build_executions=0, test_executions=0)))
