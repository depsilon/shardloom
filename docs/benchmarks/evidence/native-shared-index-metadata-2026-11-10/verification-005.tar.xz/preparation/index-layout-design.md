# Shared probe metadata — bounded candidate design

November 10 preparation while Variant PR #1676 is in hosted validation. This
records a proposed implementation and admission policy, not a frozen experiment,
accepted optimization, new benchmark or modification of the engine. The exact
accepted baseline and attribution prerequisites below remain to be bound.

## Layout and probe order

Use one private optional `ReservedVec<u8>` alongside the existing bucket vector.
The existing `Entry`, inline first row, ordered duplicate links, caller equality,
bucket hash and FxHasher remain unchanged. Control bytes use `0x80` for empty and
the high seven hash bits for occupied slots. Fingerprints remain candidate filters;
the complete hash and the caller's exact native equality still decide identity.

The one proposed eligibility rule is bucket capacity at least 128 and the new
control allocation, including seven mirrored bytes, at most one sixteenth of
currently unreserved operation memory. The factor follows the existing optional
key-directory admission pattern; it is not a measured optimum. Small or
unadmitted indices keep their ordinary native layout. Do not tune these constants
after inspecting scored outcomes. Allocation or cancellation errors after
admission propagate normally; do not parse generic `InvalidOperation` messages
or swallow them as an eligibility decline.

The control vector has `capacity + 7` logical bytes. Copy the first seven controls
into the tail and update both positions when publishing a bucket below seven.
An unaligned group is read safely as eight bytes and converted with
`u64::from_le_bytes`; no unsafe code, target-specific instruction or dependency
is needed. A group beginning at any bucket therefore preserves the current
linear order across wraparound.

Let `x` be the group XOR the repeated fingerprint, `L = 0x7f7f7f7f7f7f7f7f`
and `H = 0x8080808080808080`. Exact matching-byte high bits are
`!(x | ((x & L) + L)) & H`. The addition cannot carry between bytes: each masked
byte is at most 127 and adding 127 gives at most 254. A zero byte alone leaves
its high bit clear before inversion. The control word's high bits identify empty
slots directly. Discard matches at or after the first empty slot, then visit
candidate positions in increasing lane order. If the whole group is occupied,
advance eight slots with the existing power-of-two mask.

`check_probe_word_model.py` independently checks all 262,144 single-byte/lane
match combinations, all 6,561 empty/matching/nonmatching eight-byte patterns and
1,728 wraparound cases. `probe-word-model-r1.json` records their passing result
and model identity. This is a conceptual-model check, not proof of future Rust
code or evidence of a speed gain.

## Publication and memory

Keep the existing insertion sequence: exact lookup, fallible entry/link and
table reservations, vacancy selection, final cancellation check, publication.
Publish the control byte together with its new bucket after every fallible step.
Duplicates do not change controls or allocate an entry. Metadata must never
introduce a second equality or stable-entry owner.

Rehash prepares replacement buckets and controls privately, with old and new
allocations charged concurrently. Populate replacement controls from existing
full hashes; preserve entry positions and duplicate chains. Commit replacements
only after successful rehash and a final cancellation check. Every temporary
allocation refunds on denial/cancellation. The optional layout may be declined
at a growth boundary under the declared admission rule; that is a choice between
two ShardLoom-native representations. It is not external execution fallback.

Extra control storage is an explicit resource cost. The admission margin is not
a guarantee that all later allocations elsewhere in a query will fit, nor a
claim that total query memory decreases. Test tight-budget admission, denied
populated rehash, successful retry, cancellation and complete credit refunds.
Retain the existing exact eight-entry small-grant test without widening its grant.

Admission clarification from the current containers: take the free-credit
snapshot after reserving the replacement buckets, while the old buckets and
controls are still retained. Allocate new controls in a fresh `ReservedVec`.
Its initial `try_reserve_exact` request is `max(8, capacity + 7)`, so the
proposed minimum bucket capacity makes the charged request exactly
`capacity + 7`; this is not a power-of-two-rounded metadata allocation. Keep
the allocation's existing oversize check and failure propagation. Do not reuse
an old control vector's growth policy when applying this admission calculation.

The existing test named
`growth_keeps_all_collision_chains_and_denial_does_not_publish_a_partial_row`
checks successful populated growth but its denial fixture starts empty.
The candidate needs an actual populated-rehash denial test: retain stable entry
and duplicate identities, force the next bucket replacement to fail under the
unchanged pool, prove all prior lookups/rows still work, release the held credit,
retry and prove successful publication. Also exercise optional-control decline
at an otherwise successful growth boundary and verify that the plain layout
keeps the same answers. These cases are planned, not executed.

## Attribution before candidate implementation

The original 10k archive provides complete-case engine times and family exposure,
not a measured time share for RowIndex. Do not turn family totals or sampled stack
counts into index CPU time. The current index has no probe counters; `Counts`
is debug-test-only and thread-local. New attribution must establish which exact
complete requests reach the owner and which loads a fingerprint could screen.

First inspect existing bounded operator stack captures and their exact source
identity. Reuse them only as historical attribution where identities support it.
If insufficient, freeze a bounded diagnostic request selection before capture,
use the existing task-owned sampler/worker handshake and preserve the sampled
results separately from ordinary-runtime timings. Report unavailable time
attribution as unavailable. Add only the deciding test counters: lookups, logical
probe slots, actual bucket/Entry reads, exact equality calls, metadata groups,
initialization bytes and rehash work. Baseline instrumentation can count
fingerprint candidates without changing the lookup algorithm. Prove thread
coverage or label thread-local evidence explicitly.

The benchmark runtime must not carry those debug counters. Mechanism tests and
sampling establish activation; complete ordinary-runtime requests decide benefit.
Keep any instrumented timing and its overhead separate. Do not claim that the
removed loads cost a particular fraction of an engine second without that proof.

Counter semantics must stay comparable across the two layouts. A logical probe
slot is a position in the original linear sequence, stopping at the first empty
slot or exact successful match. Loading eight control bytes does not mean that
eight logical positions were consumed when lookup ends in an earlier lane.
Count actual bucket and Entry reads separately from metadata-group loads;
fingerprint matches still require full-hash comparison before exact equality.
Keep insertion-vacancy reads, bucket initialization and rehash work separate
from lookup, and preserve the current cancellation bound of at most 1,024
logical slots between checks, including the final check after a successful
equality closure. No counter itself is a CPU-time estimate.

## Freeze and acceptance prerequisites

- Variant's exact-head review and all 58 PR checks passed, and its identical signed
  merge is present. The maintainer's requested current-runtime observation may run
  locally while main verification continues on GitHub. Bind the tested source tree,
  runtime/wheel and current input generations; defer final baseline acceptance and
  retention until all main checks pass. No local cleanup or other work runs during
  the query pass. Candidate implementation still follows this measurement.
- Preserve the original 10,000 cases and independent expectations. The latest
  November 10 maintainer instruction authorizes one full current-runtime pass
  now, then relevant predefined cohorts for later changes. Provider and other
  engine work has changed since the historical measurement; do not infer a
  probe-layout gain by comparing only to the old 1,513.095098453-second total.
  Reuse exact matching case observations from the new full baseline. Freeze the
  index cohort by mechanism exposure and controls before testing the candidate;
  do not choose cases by favorable measured outcomes. Another full 10k pass
  requires a concrete integration or regression reason, not routine repetition.
- Bind the driver, request order, native/public routes, complete result checks,
  engine clock, resource limits and isolation. No warmups, repeats, profiling or
  cache manipulation belongs in either scored pass. Keep full hashing outside
  query execution and use the existing bounded supervisor and cleanup guards.
- Freeze small/large, absent-probe, skewed, duplicate, text/compound and collision
  controls. Deliberate full-hash collisions, wraparound and failed populated
  growth need direct owner tests; complete joins/grouping/membership need real
  native/public output checks. Version any additional compositions separately.
- Only after independent correctness, ownership, resource and no-fallback checks
  pass, compare the same complete predefined relevant cohort for the current
  baseline and candidate. Lower total engine time retains the candidate;
  equal/higher drops it. New cases absent from the original 10k need their own
  versioned baseline and candidate observations.
  Any failure invalidates a complete-pass claim. Preserve every observation.
- Keep compatible-window sharing and rolling DISTINCT outside this experiment.
  Interaction measurements follow independent decisions.

The Vortex-first decision remains `implement_shardloom_kernel` within the
existing logical row-index owner. The pinned provider's structural array hash/
equality surface does not replace caller-defined row equality. Native Vortex
input/output, encoded key owners, materialization boundaries, dependencies and
no-fallback certificates stay authoritative. No new execution family is proposed.

## Implementation notes from the accepted-source review

The accepted merge retains the same owner. Its bucket function uses low hash
bits, so the proposed high seven-bit fingerprint is separate from bucket choice.
The safe eight-byte control read can begin at any bucket because of the mirrored
tail. Mask out candidate lanes at and after the first empty lane, visit remaining
lanes in increasing order, and retain the final cancellation check after equality.
Fully occupied groups advance exactly eight logical slots; the existing 1,024-slot
cancellation bound therefore remains expressible without changing probe order.

For comparable debug counters, account for skipped logical positions up to each
candidate before loading it. A successful or failing equality must not count
later lanes as consumed. After all candidates fail, account for the remainder
through the first empty slot, or all eight slots when the group is full. Count
the actual metadata-word load, candidate bucket load and Entry load separately.
Keep all such bookkeeping inside the existing debug-test configuration.

The populated growth-denial draft now fills 64 colliding unique entries and
retains two ordered duplicates. It reserves the next entry capacity before
holding the remaining pool credit, so failure occurs at the replacement bucket
reservation. It checks all old identities and chains, then retries after release.
This test and the complete-request draft remain uncompiled and unexecuted; only
formatting has passed. The existing collision cancellation and exact small-grant
tests already cover their stated contracts and should remain unchanged.
