"""Verify complete saved answers and engine clocks; never execute a query."""
from collections import Counter, defaultdict
from contextlib import ExitStack
import gzip
import json
import math
from pathlib import Path

import run_current_10k as current
from query_timing_report import query_phase_timings
from query_surface.corpus import corpus
from query_surface.evidence import identity
from query_surface.expanded_catalog import build, spaces
from query_surface.expanded_freeze import read, unpack
from query_surface.expanded_report import raw_files, replay
from query_surface.expanded_run import closing_db, verify


def checked_stage(target, historical=False):
    done, binding = read(target / 'complete.json'), read(target / 'binding.json')
    assert done['status'] == 'complete_observation' and done['stage'] == 'native'
    assert done['total'] == done['attempt_slots'] == 10000
    assert done['outcomes'] == {'passed': 10000}
    assert done['attempts_per_case'] == 1 and done['requested_repeats'] == 0
    assert done['posthash_verified']
    files = [done['ledger'], done['binding'], done['frozen']]
    assert done['ledger']['path'] == str(target / 'attempts.sqlite')
    assert done['binding']['path'] == str(target / 'binding.json')
    assert done['frozen']['path'] == str(current.E / 'frozen.json')
    if historical:
        current.historical_binding().verify(files)
    else:
        verify(files)
    assert binding['contract'] == {key: done[key] for key in ('frozen', 'stage', 'prerequisites', 'updated')}
    return done


def verify_clock(entry, record):
    response = json.loads(raw_files(unpack(entry[3]))['one.stdout.json'])
    report = response['observation']
    fields = query_phase_timings(report['fields'], report['clocks']['complete_workflow_seconds'])
    value = fields['engine_execution_seconds']
    assert type(value) in (int, float) and math.isfinite(value) and value >= 0
    assert report['clocks']['engine_timing_reported'] is True
    assert value == record['engine_seconds'] == report['clocks']['engine_execution_seconds']
    assert fields['result_serialization_seconds'] == report['clocks']['result_serialization_seconds']


def main():
    target, previous = current.TARGET, current.E / 'shared-mechanisms-10k-r1'
    destination = target / 'verified-summary-r1.json'
    cases_path = target / 'verified-cases-r1.jsonl.gz'
    partial = target / 'verified-cases-r1.partial.jsonl.gz'
    assert not any(path.exists() for path in (destination, cases_path, partial))
    design, inputs, frozen, admitted = current.updated_admission(current.E)
    done, prior = checked_stage(target), checked_stage(previous, historical=True)
    assert done['updated'] == admitted
    prepared = read(current.E / 'native-preparation/complete.json')
    previous_inputs = dict(inputs, runtime=prior['updated']['runtime'])
    originals = {item.id: item for item in corpus(interactions='all', include_pending=False)}
    definitions = {spec.name: spec for spec in spaces()}
    seen, values, old_values = [], [], []
    families = defaultdict(lambda: {'current': [], 'historical': []})
    outcomes = Counter()
    lock = target / '.current-offline-replay.lock'
    with lock.open('x'):
        pass
    with ExitStack() as stack:
        stores = {name: stack.enter_context(closing_db(Path(record['ledger']['path']), readonly=True))
                  for name, record in (('current', done), ('historical', prior))}
        attempts = {name: iter(db.execute('SELECT seq,id,status,packet FROM attempt ORDER BY seq'))
                    for name, db in stores.items()}
        references = {profile: stack.enter_context(closing_db(current.E / ('reference-' + profile) / 'expectations.sqlite', readonly=True))
                      for profile in {row['profile'] for row in design['cases']}}
        output = stack.enter_context(gzip.open(partial, 'wt', encoding='utf-8'))
        for ordinal, row in enumerate(design['cases']):
            item = build(row, definitions) if 'cell' in row else originals[row['id']]
            expected_identity, expected_blob = references[row['profile']].execute(
                'SELECT identity,value FROM expected WHERE id=?', (item.id,)).fetchone()
            assert expected_identity == item.identity == row['case_identity']
            expected = unpack(expected_blob)
            observed = {}
            for name, config in (('current', inputs), ('historical', previous_inputs)):
                entry = next(attempts[name], None)
                assert entry is not None and entry[:2] == (ordinal, item.id)
                record = replay(entry, row, 'native', expected, item, config, prepared, design['execution'])
                assert record['status'] == 'passed', (ordinal, item.id, name, record)
                verify_clock(entry, record)
                observed[name] = record
                families[row['family']][name].append(record['engine_seconds'])
            seen.append(item.id)
            outcomes[observed['current']['status']] += 1
            values.append(observed['current']['engine_seconds'])
            old_values.append(observed['historical']['engine_seconds'])
            output.write(json.dumps(dict(seq=ordinal, id=item.id, family=row['family'], profile=row['profile'],
                surface=row['surface'], **observed), separators=(',', ':'), allow_nan=False) + '\n')
        assert all(next(entries, None) is None for entries in attempts.values())
    assert seen == [row['id'] for row in design['cases']] and len(set(seen)) == 10000
    assert dict(outcomes) == {'passed': 10000}
    verify(frozen)
    assert identity(target / 'attempts.sqlite') == done['ledger']
    assert identity(previous / 'attempts.sqlite') == current.historical_binding().current(prior['ledger'])
    total, historical = math.fsum(values), math.fsum(old_values)
    partial.rename(cases_path)
    result = dict(status='passed_complete_current_runtime_observation', query_executions_during_replay=0,
        source_commit=current.MERGE, source_tree=current.TREE, complete_results=10000,
        attempts_per_case=1, requested_repeats=0, primary_clock='engine_execution_seconds',
        engine_execution_seconds=total, historical_engine_execution_seconds=historical,
        historical_change_percent=100 * (total / historical - 1),
        historical_source=prior['updated'],
        comparison_limitation='Same frozen requests and engine clock; cumulative source/provider changes separate these observations. No individual-change attribution or isolated #8/#9 speed claim.',
        families={name: dict(cases=len(clocks['current']), current_engine_seconds=math.fsum(clocks['current']),
            historical_engine_seconds=math.fsum(clocks['historical'])) for name, clocks in sorted(families.items())},
        case_rows=identity(cases_path), complete=identity(target / 'complete.json'), ledger=done['ledger'],
        historical_complete=identity(previous / 'complete.json'), historical_ledger=prior['ledger'],
        protocol=identity(current.PROTOCOL), verifier=identity(Path(__file__)), native_no_fallback=True,
        independent_expected_results_replayed=True, all_engine_clocks_valid=True, warm_reuse_measured=False)
    with destination.open('x') as output:
        json.dump(result, output, indent=2, allow_nan=False)
        output.write('\n')
    lock.unlink()
    print(json.dumps({key: result[key] for key in ('status', 'complete_results', 'engine_execution_seconds',
        'historical_engine_execution_seconds', 'historical_change_percent')}))


if __name__ == '__main__':
    main()
