"""Bind the unchanged original 10k capture loop to the verified November 10 runtime.

This is a new provenance contract, not a rewrite of historical evidence.
Requests, frozen Python client, references, ordering, worker, clocks, execution,
deadlines and inner workload/storage guards remain unchanged. The capture's
historical identity checks explicitly use the independently frozen device binding.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

S = Path(__file__).resolve().parents[1]
K = S.parent / 'variant-expressions-2026-11-10'
E = S.parent / 'expanded-query-2026-11-03'
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
MERGE = '8f426b3d2e774be2a9d30a731c33b8c830378d99'
TREE = '331c8bf3948f0446f7a8382c2ac606ef4c9fdf3a'
TARGET = S / 'current-baseline-10k-r1'
PROTOCOL = S / 'current-baseline-10k-protocol-r1.json'
LIBRARY = S / 'baseline-runtime-r1/_native.abi3.so'
COPY_RECEIPT = S / 'baseline-library-copy-r1.json'
EXPECTED_HELPERS = {
    'run_shared_10k.py': '8836d5d1769aeca5037387de54b36bdb35c3e72e8a06385c4aa3771ff8f7693d',
    'run_investigation_cohort_r2.py': 'b44b21a739c0287bfb502292137ed056c4d91e9d1901327eaf429efdec12c7ec',
}
for name, digest in EXPECTED_HELPERS.items():
    assert hashlib.sha256((E / 'tools' / name).read_bytes()).hexdigest() == digest
sys.path.insert(0, str(E / 'tools'))
import run_shared_10k as original_capture
import run_current_capture_r1 as capture
from frozen_generation_binding import BINDING, HistoricalBinding
from query_surface.evidence import identity
from query_surface.expanded_freeze import read
from query_surface.expanded_run import verify

_historical = None


def historical_binding():
    global _historical
    if _historical is None:
        _historical = HistoricalBinding()
    return _historical


def verify_capture_source():
    """Allow only these explicit provenance edits to the old capture function."""
    source = Path(original_capture.__file__).read_text()
    tree = ast.parse(source)
    node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'observe')
    expected = ast.get_source_segment(source, node)
    changes = [
        ('def observe(root, resume):', 'def observe(root, resume, admission, historical):', 1),
        ('updated_admission(root)', 'admission(root)', 1),
        ('stage_complete(root,', 'historical.stage_complete(root,', 2),
        ('prepared["frozen"] != identity(root / "frozen.json")',
         'historical.current(prepared["frozen"]) != identity(root / "frozen.json")', 1),
        ('prepared["polars_complete"] != prerequisites["polars"]',
         'historical.current(prepared["polars_complete"]) != prerequisites["polars"]', 1),
        ('        verify(extra)', '        extra = historical.files(extra)\n        verify(extra)', 1),
    ]
    for before, after, count in changes:
        assert expected.count(before) == count
        expected = expected.replace(before, after)
    current = Path(capture.__file__).read_text()
    actual_tree = ast.parse(current)
    functions = [n for n in actual_tree.body if isinstance(n, ast.FunctionDef)]
    assert len(functions) == 1 and functions[0].name == 'observe'
    assert ast.get_source_segment(current, functions[0]) == expected
    prefix = source[source.index('from __future__'):source.index('\ndef _file_identity')]
    assert current[current.index('from __future__'):current.index('def observe')] == prefix + '\n'
    assert actual_tree.body[-1] is functions[0]
    assert not ''.join(current.splitlines(keepends=True)[functions[0].end_lineno:]).strip()


def file_identity(path):
    assert path.is_file() and not path.is_symlink(), path
    before = path.stat()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    after = path.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (
        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    return dict(bytes=after.st_size, sha256=digest)


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=W, text=True, timeout=90).strip()


def verified_runtime():
    """Reuse the exact tested runtime with its original, truthful build proof."""
    assert __debug__, 'enabled assertions are required'
    pre_path = K / 'pr1676-premerge-r1.json'
    pre = read(pre_path)
    assert pre['status'] == 'passed_premerge' and pre['pr'] == 1676
    assert pre['source_tree'] == TREE and pre['successful_hosted_checks'] == 58
    assert pre['runtime_sources_match_build'] and pre['source_bound_replay'] == 'passed'
    assert pre['review']['status'] == 'completed' and pre['review']['commit_sha'] == pre['head']
    assert pre['review']['has_any_findings'] is pre['review']['has_unresolved_findings'] is False
    assert pre['unresolved_threads'] == 0 and pre['tree_matches_synthetic']
    checkout_path = K / 'variant-expression-main-checkout-r1.json'
    checkout = read(checkout_path)
    assert checkout['status'] == 'passed' and checkout['merge_commit'] == MERGE
    assert checkout['source_tree'] == TREE and checkout['accepted_source_tree_unchanged']
    assert checkout['signed_commit'] and checkout['premerge_sha256'] == file_identity(pre_path)['sha256']
    commit_path = K / 'merge-commit-connector-r1.json'
    commit = json.loads(read(commit_path)['structuredContent']['content'])
    assert commit['sha'] == MERGE and commit['commit']['tree']['sha'] == TREE
    assert commit['commit']['verification']['verified'] is True
    assert [row['sha'] for row in commit['parents']] == [pre['base'], pre['head']]
    for label in ('checks', 'workflows'):
        snapshot = read(S / f'pre-measurement-main-{label}-r1.json')
        assert not snapshot.get('isError')
        observed = json.loads(snapshot['structuredContent']['content'])
        rows = observed['check_runs' if label == 'checks' else 'workflow_runs']
        assert observed['total_count'] == len(rows) and rows
        assert all(row['head_sha'] == MERGE for row in rows)
        assert all(row['status'] != 'completed' or row['conclusion'] == 'success' for row in rows)
    assert git('rev-parse', 'HEAD') == MERGE and git('rev-parse', 'HEAD^{tree}') == TREE
    assert not git('status', '--porcelain'), 'baseline source must remain clean at the verified merge'
    paths = [pre_path, checkout_path, commit_path]
    for relative, expected in pre['raw_sources'].items():
        path = K / relative
        assert not Path(relative).is_absolute() and path.resolve().is_relative_to(K)
        observed = file_identity(path)
        assert observed == expected if isinstance(expected, dict) else observed['sha256'] == expected
        paths.append(path)
    packet = W / 'docs/release/evidence/native-variant-expressions-2026-11-10'
    repair = W / 'docs/release/evidence/native-variant-semantics-repair-2026-11-10'
    for folder, key in ((packet, 'packet_files'), (repair, 'repair_packet_files')):
        for relative, expected in pre[key].items():
            path = folder / relative
            assert Path(relative).name == relative and file_identity(path) == expected
            paths.append(path)
    accepted, repaired = read(packet / 'acceptance.json'), read(repair / 'acceptance.json')
    assert accepted['status'] == repaired['status'] == 'local_acceptance_passed'
    assert not repaired['production_inputs_changed']
    assert repaired['source_fingerprint_sha256'] == pre['final_source_fingerprint_sha256']
    for filename, key in (('committed-source-replay-r1.log', 'completed_source_replay'),
                          ('repair-committed-source-replay-r1.log', 'completed_repair_source_replay')):
        assert file_identity(K / filename) == pre[key]
        paths.append(K / filename)
    installed_path = K / 'installed-proof-r1/report.json'
    installed = read(installed_path)
    assert installed['status'] == installed['uninstall_status'] == 'passed'
    assert installed['integration'] == accepted['installed_package'] == dict(status='passed', tests=441,
        failures=0, errors=0, skipped=0)
    wheel = K / 'installed-proof-r1/dist' / installed['integrity']['wheel']
    assert file_identity(wheel)['sha256'] == installed['integrity']['wheel_sha256'] == accepted['runtime_and_wheel']['wheel_sha256']
    paths.extend([installed_path, wheel])
    runtime_identity_path = K / 'runtime-r2-identity.json'
    runtime_identity = read(runtime_identity_path)
    build_path = K / runtime_identity['build_receipt']
    build = read(build_path)
    assert runtime_identity['status'] == 'passed' and runtime_identity['profile'] == 'release'
    assert file_identity(build_path) == runtime_identity['build_receipt_identity']
    assert build['status'] == 'passed' and build['returncode'] == 0
    assert build['process_group_drained'] and build['direct_child_reaped']
    assert build['build_source_fingerprint_sha256'] == runtime_identity['build_source_fingerprint_sha256']
    assert build['build_source_verification']['post_execution']['changed_paths'] == []
    assert build['command'] == ['env', 'PYO3_PYTHON=/opt/homebrew/opt/python@3.13/libexec/bin/python3',
        'cargo', 'build', '--offline', '--locked', '--release', '--features', 'release-user-surfaces',
        '-p', 'shardloom-cli', '-p', 'shardloom-python']
    products = {Path(row['path']).name: row for row in runtime_identity['files']}
    assert set(products) == {'shardloom', 'lib_native.dylib'}
    for name, row in products.items():
        path = Path(row['path'])
        assert path.parent == K / 'runtime-r2'
        assert file_identity(path) == {key: row[key] for key in ('bytes', 'sha256')}
        key = 'cli_sha256' if name == 'shardloom' else 'native_library_sha256'
        assert row['sha256'] == installed['integrity'][key] == accepted['runtime_and_wheel'][key]
    paths.extend([runtime_identity_path, build_path])
    return products, paths


def prepare_library():
    products, _ = verified_runtime()
    original = Path(products['lib_native.dylib']['path'])
    expected = file_identity(original)
    if LIBRARY.exists() or COPY_RECEIPT.exists():
        receipt = read(COPY_RECEIPT)
        assert receipt == dict(status='passed', source=str(original), destination=str(LIBRARY), identity=expected,
            purpose='byte-identical .so filename required by the frozen Python extension loader')
        assert file_identity(LIBRARY) == expected
        return
    assert not LIBRARY.parent.exists()
    assert shutil.disk_usage(S).free >= (12 << 30) + expected['bytes'] + (128 << 20)
    LIBRARY.parent.mkdir()
    with original.open('rb') as source, LIBRARY.open('xb') as target:
        shutil.copyfileobj(source, target, 1 << 20)
    assert file_identity(LIBRARY) == file_identity(original) == expected
    with COPY_RECEIPT.open('x') as output:
        json.dump(dict(status='passed', source=str(original), destination=str(LIBRARY), identity=expected,
            purpose='byte-identical .so filename required by the frozen Python extension loader'), output, indent=2)
        output.write('\n')


def updated_admission(root, require_protocol=True):
    assert root == E and root.resolve() == E
    verify_capture_source()
    historical = historical_binding()
    products, proof_paths = verified_runtime()
    assert read(COPY_RECEIPT)['identity'] == file_identity(LIBRARY) == file_identity(Path(products['lib_native.dylib']['path']))
    runtime = {'binary': identity(Path(products['shardloom']['path'])), 'library': identity(LIBRARY)}
    with historical.admission_verifier(capture.common):
        design, inputs, frozen, relocated, archive, _ = capture.common.checked_admission(capture.common.ROOT_DEFAULT, E)
    frozen = historical.files(frozen)
    # Keep every original observation and its original frozen runtime/environment.
    original = historical.stage_complete(E, 'native', 10000)
    assert original['outcomes'].get('passed') == 9995
    polars = historical.stage_complete(E, 'polars', 10000)
    assert polars['outcomes'] == {'passed': 10000}
    history_paths = []
    for name in ('updated-native-10k-r1', 'shared-mechanisms-10k-r1'):
        path = E / name / 'complete.json'
        record = read(path)
        assert record['status'] == 'complete_observation' and record['stage'] == 'native'
        assert record['total'] == record['attempt_slots'] == 10000
        assert record['outcomes'] == {'passed': 10000}
        assert record['attempts_per_case'] == 1 and record['requested_repeats'] == 0
        assert record['posthash_verified'] and historical.current(record['frozen']) == identity(E / 'frozen.json')
        historical.verify([record['ledger'], record['binding']])
        history_paths.extend([path, Path(record['ledger']['path']), Path(record['binding']['path'])])
    prepared = read(E / 'native-preparation/complete.json')
    prepared_files = [f for profile in prepared['profiles'].values()
                      for f in [profile['manifest'], *profile['inputs'], *profile['receipts']]]
    extra_paths = [*proof_paths, *history_paths, COPY_RECEIPT, Path(__file__), BINDING,
        S / 'tools/frozen_generation_binding.py', S / 'tools/test_frozen_generation_binding.py',
        S / 'tools/run_current_capture_r1.py', S / 'baseline-generation-audit-r1.json',
        S / 'baseline-generation-preflight-r1.json', S / 'baseline-generation-review-r1.json',
        S / 'baseline-metadata-restore-r1.json', S / 'tools/verify_generation_capture.py',
        S / 'tools/guard_current_measurement.py', S / 'tools/replay_current_10k.py',
        S / 'pre-measurement-main-checks-r1.json', S / 'pre-measurement-main-workflows-r1.json',
        S / 'current-baseline-isolation-r1.json', S / 'index-layout-design.md', S / 'cohort-policy-r1.md',
        S / 'baseline-helper-primary-review-r1.md', S / 'baseline-helper-import-preflight-r1.json',
        S / 'baseline-helper-import-preflight-r2.json',
        S.parent / 'release-0.3.3-20260930/release_validation_guard.py',
        S.parent / 'perf-all-20260906/bounded_build_process_resume_20260912.py',
        W / 'scripts/local_uat_storage.py',
        E / 'tools/run_shared_10k.py', E / 'tools/run_investigation_cohort_r2.py',
        capture.WORKER, E / 'native-preparation/complete.json', E / 'observe-native/complete.json',
        E / 'observe-polars/complete.json']
    extra = [identity(path) for path in sorted(set(extra_paths))]
    updated = dict(schema='shardloom.verified_runtime_10k_binding.v1', role='current_runtime_observation', head=MERGE,
        source_tree=TREE, source_root=str(W), runtime=runtime,
        runtime_proof='original dirty-build receipt, source-equality packets, all 58 PR checks, clear exact-head review and signed identical merged tree',
        main_acceptance_claimed=False, main_checks_required_for_final_acceptance=55,
        frozen_client_policy='all original archived Python client bytes retained; no current-client substitution',
        selection='all 10000 primary native declarations in original manifest order',
        target=str(TARGET), provenance=extra, original_capture_helpers=EXPECTED_HELPERS,
        original_worker=identity(capture.WORKER), frozen_harness_files=len(relocated),
        warmups=0, attempts_per_case=1, alternate_attempts=0,
        diagnostic_instrumentation=False, profiling=False, cache_manipulation=False)
    added = [*archive, *extra, *runtime.values(), *historical.files(prepared_files),
             historical.current(original['ledger']), historical.current(polars['ledger'])]
    protocol = dict(schema='shardloom.current_baseline_10k_protocol.v1', status='admitted_before_execution',
        selection=updated['selection'], design=identity(E / 'design.json'), inputs=identity(E / 'inputs.json'),
        frozen=identity(E / 'frozen.json'), execution=design['execution'], runtime_binding=updated,
        expected_attempt_count=10000, attempts_per_case=1, warmups=0,
        primary_clock='engine_execution_seconds', required_complete_result_count=10000,
        query_loop='historical capture.observe with exact allowlisted provenance-only edits; execution loop, worker, requests, clocks and guards unchanged',
        historical_generation_binding=identity(BINDING),
        isolation='all other task-owned work idle for the entire capture; lightweight existing guards remain active')
    verify(added)
    if require_protocol:
        assert read(PROTOCOL) == protocol, 'frozen protocol differs from current admission'
        added.append(identity(PROTOCOL))
    else:
        assert not PROTOCOL.exists()
        with PROTOCOL.open('x') as output:
            json.dump(protocol, output, indent=2)
            output.write('\n')
    return design, dict(inputs, runtime=runtime), [*frozen, *added], updated


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', action='store_true')
    parser.add_argument('--resume-unattempted', action='store_true')
    args = parser.parse_args()
    if args.plan and args.resume_unattempted:
        parser.error('planning cannot resume a capture')
    os.environ['POLARS_MAX_THREADS'] = '2'
    capture.require_local_path(E, Path.home(), sys.platform)
    capture.require_local_path(S, Path.home(), sys.platform)
    if args.plan:
        prepare_library()
        design, _, _, _ = updated_admission(E, require_protocol=False)
        print(json.dumps(dict(status='admitted_before_execution', cases=design['count'], protocol=str(PROTOCOL))))
    else:
        # The historical module stays unchanged. The versioned copy has only
        # source-verified provenance changes and a distinct output destination.
        capture.TARGET_NAME = str(TARGET)
        capture.observe(E, args.resume_unattempted, updated_admission, historical_binding())


if __name__ == '__main__':
    main()
