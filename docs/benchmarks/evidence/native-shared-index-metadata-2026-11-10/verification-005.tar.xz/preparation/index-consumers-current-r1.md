# RowIndex consumers at current source HEAD

**Source identity:** `/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo`, HEAD `5d2394039cb6410aedc86c8f483eaee618bf38ce`, branch `codex/native-dictionary-execution-repair`.

**Scope:** read-only `rg -n "RowIndex" shardloom-vortex/src --glob '*.rs'`, followed by source inspection of each production match, RowSet aggregation paths, and focused complete-output tests. Vendor ORC's separate `RowIndex` names are outside this package search. The prior inventories recorded earlier revisions; revision differences alone do not establish source differences. Primary byte comparison confirms that the index and all six direct owner modules are unchanged from `8f426b3d2e774be2a9d30a731c33b8c830378d99`. This packet refreshes ownership and consumer coverage for the assigned HEAD. No tests/builds/queries were run.

## Direct production RowIndex owners and call sites

The direct production owners are six consumer modules, plus the `native_relational_index.rs` definition module. The six owner modules are:

1. **Join** — `shardloom-vortex/src/local_primitives/native_relational_join.rs:8,52-74,106-126,129-208`. `Join` owns `index: RowIndex` and optional `membership: RowSet`; keyed build inserts right row ordinals via `insert`, probe uses `find`, and output walks `rows(entry)`. `false` is passed for nulls-equal in keyed hash/equality. All duplicate right row ordinals are emitted in insertion order for each left row. Existence/semi/anti may use the separate RowSet membership path. The related condition module `native_relational_join_condition.rs:6,16-29,33-120` consumes `Rows` via `Candidates::Key` from this same Join owner; it batches candidates, applies ON filtering, then emits selected candidates in their input order. This is a related iterator consumer, not another RowIndex owner.

2. **RowSet** — `shardloom-vortex/src/local_primitives/native_relational_set.rs:6,21-50,53-68,73-103,117-217`. It owns an index and compact retained `Table`. `contains` calls `find`; ingestion calls `insert_unique`, so it does not need duplicate chains, and checks first-occurrence group ordinal equals insertion ordinal. Default `RowSet::new` treats nulls equal; `with_nulls_equal` selects policy. Its own retained record count comes from `Table::rows`, and is checked against `index.unique_rows`.

3. **Correlated/cyclic EXISTS** — `shardloom-vortex/src/local_primitive_relational_cyclic_exists.rs:7,200-231,234-284`. Each indexed relation owns a `RowIndex`; build uses `insert`; witness search uses `find` then traverses every matching middle duplicate through `rows(entry)` before probing the final index. Null-nonmatching key treatment is explicit in this path (`false` hash/equality; null first key immediately yields no witness).

4. **Subquery** — `shardloom-vortex/src/local_primitives/native_relational_subquery.rs:8,58-59,125-181,272-330`. Owns separate `correlation` and `matches` RowIndexes. Build inserts correlated-prefix duplicates and nonnull IN candidates; NULL IN candidates go to a separate nullable vector. Evaluation uses correlation `find` and `rows(entry)` to reduce over all right rows for that correlation; IN exact membership uses `matches.find` only. Total right input cardinality is read from its `Table`, not RowIndex unique count.

5. **Window partition ordering** — `shardloom-vortex/src/local_primitives/native_relational_window_group_order.rs:5,15-25,28-97,99-127`. `collect` creates a temporary RowIndex, inserts each selected row under a hash of all partition keys, and uses exact `compare_partition` equality. Unique entries create partition descriptors in first-seen order. After sorting descriptors, `rows(entry)` reconstructs each partition's row ordinals; each partition is then ordered by window order keys with original row ordinal as tie-break. This direct RowIndex use supplies partition membership/order grouping.

6. **Window aggregate DISTINCT state** — `shardloom-vortex/src/local_primitives/native_relational_window_frame_state.rs:13,67-87,462-515`. For distinct aggregate windows, `State::new` creates a RowIndex. `Distinct::observe` uses `find` then inserts a newly seen key and requires entry ordinal equal the parallel count-vector index. It does not traverse duplicate chains; multiplicity is maintained by per-entry counts and active distinct count. Hashing requires a nonnull key; NULL handling is outside this indexed key path.

### Shared RowIndex API/behavior cited by owners

`shardloom-vortex/src/local_primitives/native_relational_index.rs:10-35` defines entries and linked row ordinals. `find` selects by hash and asks the caller equality closure to prove key equality (`38-67`). `insert` retains duplicates and `insert_unique` only publishes new keys (`69-92,94-144`). `rows` creates the ordered duplicate iterator (`175-188`); `unique_rows` returns entry count (`190-192`).

## Which operations use this owner?

| Operation | Current implementation evidence | Relationship to this RowIndex |
|---|---|---|
| Grouped native relational aggregate | `native_relational_aggregate.rs:198-205,248-276,1310-1345` | Uses `RowSet` for group identities and, when tracked, distinct measure keys. `RowSet` owns this RowIndex (`native_relational_set.rs:21-27`). Group ordinals are first-occurrence ordinals. Specialized/ordered aggregate paths can bypass tracked RowSet distinct sets; see below. |
| Window partition membership/order | `native_relational_window_group_order.rs:21-25,99-127` | Directly uses this RowIndex. |
| Window aggregate DISTINCT | `native_relational_window_frame_state.rs:78-86,462-515` | Directly uses this RowIndex for distinct identities and parallel counts. |
| Relational set membership and unique/interning | `native_relational_set.rs:21-27,53-103,117-217` | Uses this RowIndex through RowSet. Other set-operation orchestration may use RowSet membership predicates. |
| Keyed joins | `native_relational_join.rs:52-74,106-208` | Directly uses this RowIndex. Conditional joins also consume its `Rows` chain via `native_relational_join_condition.rs:16-29,46-99`. |
| Join existence / semi/anti membership | `native_relational_join.rs:67-73,84-92,149-167` | The short-circuit membership owner is a RowSet, hence this RowIndex indirectly; regular keyed matching uses Join's direct index. |
| Correlated subqueries and IN | `native_relational_subquery.rs:58-59,153-179,272-330` | Directly uses two RowIndexes. |
| SQL/native materialized DISTINCT outside window/RowSet | `shardloom-vortex/src/local_primitives/exact_distinct_workers.rs:45-85,294-325`; `scalar_distinct_workers.rs` and `mixed_distinct_workers.rs` have separate owner types | Other DISTINCT execution paths use `ExactDistinctWorkers`, `ScalarDistinctWorkers`, `MixedDistinctWorkers`, or spill/partition structures, rather than establishing use of this RowIndex. The scoped RowIndex search has no direct type reference from those modules. |

The statements above identify actual type/constructor/call edges; they do not claim that every SQL operation routes through every listed path. In particular, “grouped aggregate” means the `native_relational_aggregate::Aggregate` path when it constructs `RowSet`, not every specialized aggregate executor in the crate.

## Existing direct complete-output tests found

The following names were verified in the current checkout with `rg` and test source inspection. These are direct consumer semantic/result tests; index unit tests alone are not counted as complete operator output tests.

- **Join:** `native_relational_join_tests.rs::join_build_uses_current_batch_and_keeps_cross_batch_duplicate_order` (file lines 23-62) asserts all 256 ordered matching output pairs across builds. `::every_native_join_kind_preserves_duplicates_nulls_order_and_integer_payload_width` (152 onward) asserts exact outputs for inner/outer/semi/anti/cross variants. `::native_relational_join_null_root_hides_keys_and_payload_before_matching` (305 onward) asserts full join output for null root rows. Resource test `::empty_sides_null_extension_and_cancellation_have_no_leaked_native_state` is in the same file (235 onward). Related conditional join complete-output coverage: `local_primitive_relational_join_condition_tests.rs::native_relational_on_precedes_null_extension_for_every_join_kind`, `::native_relational_non_equi_predicate_keeps_unknown_distinct_from_true`, `::native_relational_on_and_post_join_where_have_distinct_results_through_all_writers`, `::native_relational_on_candidates_cross_batches_and_release_after_cancellation_and_pressure`.
- **Join membership (RowSet route):** `native_relational_join_existence_tests.rs::existence_membership_retains_unique_keys_across_batches_and_preserves_left_multiplicity`, `::existence_membership_preserves_dictionary_domains_slices_and_chunked_keys`, `::existence_membership_preserves_float_zero_and_nested_child_null_equality`, `::existence_membership_keeps_compound_null_short_circuit_and_late_nonfinite_failure`; denial/cancellation coverage `::existence_membership_denial_and_cancellation_release_state`.
- **RowSet membership/group ordinals:** `native_relational_set_inline_cache_tests.rs::inline_cache_complete_text_and_binary_results_survive_changed_batches`, `::inline_cache_complete_composite_integer_keys_preserve_all_widths_and_limits`, `::inline_cache_repeat_prefix_cannot_hide_unique_or_long_tail_values`, `::inline_cache_membership_keeps_null_and_semi_anti_policies`; helper `verify_batches` at lines 31-121 compares every interned ordinal and gathered output key against a linear first-occurrence reference. Other tests in that module focus preparation/counters/faults and are not all complete-output fixtures. Additional cache tests from the prior inventory were not independently rebound in this inventory.
- **Correlated/cyclic EXISTS:** `local_primitive_relational_cyclic_exists_tests.rs::cyclic_candidate_preserves_admitted_nulls_duplicates_aliases_and_batch_boundaries` (248 onward), and `::cyclic_candidate_handles_admitted_all_null_sources_and_full_integer_width` (501 onward) assert complete returned values; `::cyclic_candidate_drains_consumer_failure_probe_cancellation_and_partial_allocation_denial` (295 onward) covers faults/resources.
- **Subquery membership:** `native_relational_subquery_lookup_tests.rs::subquery_membership_hash_collisions_preserve_exact_groups_and_nullable_row_truth` (38 onward) directly checks collision-safe group and nullable truth results. Higher-level path tests include `local_primitive_relational_subquery_observation_tests.rs::subquery_membership_mixed_exact_numeric_keys_never_round_integer_identity`, and `local_primitive_relational_subquery_membership_tests.rs::streaming_subquery_membership_wide_keys_spill_at_original_grant_with_complete_predicates`.
- **Window partition ordering:** `native_relational_window_partition_tests.rs::interleaved_partitions_keep_source_output_order_and_sort_each_partition_once`, `::nullable_partitions_descending_nulls_last_and_duplicate_ties_match_reference`, `::empty_and_singleton_partition_windows_deliver_exact_cardinality`, `::partition_membership_preserves_lexicographic_visitation_for_every_distinct_group`, and `::partition_membership_uses_normalized_zero_and_extended_nan_equality`. `::partition_membership_denial_preserves_original_ordinals_and_releases_temporary_credits` is a resource/denial test.
- **Window aggregate DISTINCT:** higher-level `local_primitive_relational_window_frame_tests.rs::native_window_frames_nested_selection_extrema_distinct_and_decimal_totals` includes distinct-window output. `local_primitive_relational_distinct_additive_tests.rs::native_distinct_additive_windows_match_interval_unions_and_original_decimal_values` directly compares distinct additive window results to an interval-union reference. These prove operator output behavior; neither is asserted here as isolating RowIndex internals.
- **Grouped aggregate / DISTINCT output:** `local_primitive_relational_aggregate_tests.rs::native_relational_aggregate_exact_grouping_and_distinct_across_batches_preserve_nulls_and_order` and `::native_relational_aggregate_unsigned_extrema_float_zero_distinct_and_ordered_sum_are_exact` exercise complete aggregate outputs. They establish coverage of the aggregate consumer path, but the tests do not measure internal RowIndex probes.

## Search coverage and unresolved scope

The scoped exact-symbol search found production type/import/construction references in these files: `local_primitive_relational_cyclic_exists.rs`, `local_primitives/native_relational_join.rs`, `local_primitives/native_relational_set.rs`, `local_primitives/native_relational_subquery.rs`, `local_primitives/native_relational_window_frame_state.rs`, and `local_primitives/native_relational_window_group_order.rs`, plus the definition file. The only extra exact-text occurrences under `shardloom-vortex/src` were test modules/comments (`native_relational_index.rs`, `native_relational_key_cache_inline.rs`, `native_relational_key_cache_inline_tests.rs`, `native_relational_set_inline_cache_tests.rs`). The conditional join file uses the `Rows` type rather than spelling `RowIndex`; its related use is included above. Other indexes/sets in specialized DISTINCT executors are explicitly separate types.

Unresolved: this was a scoped repository Rust-source search under `shardloom-vortex/src`. The module is private and the type is `pub(super)`, so it is not an external crate API. Listed tests exist by source-name search, but were not executed. No assertion is made about performance attribution or whether a particular benchmark/candidate is accepted.

Primary follow-up: include window partition membership, window DISTINCT and correlated/cyclic membership in the experiment's coverage decisions. They use this same index even though compatible-window sharing and rolling-DISTINCT retention remain separate investigations. The earlier draft's eight complete-request attribution fixtures cover joins, groups and sets only; extend or explicitly bound that diagnostic coverage before treating it as all-consumer evidence.

Preparation update: the unapplied attribution draft now adds `window_partitions` and `window_distinct`, for ten shapes at the existing 17/4097 row sizes. Independent references count each partition's source-ordered rows and form an exact set from each trailing eight-row frame. Repeated interleaved partition keys prevent the tiny partition case from being already ordered; the DISTINCT case has high-cardinality keys so retained identities can reach the index's proposed metadata threshold. Both preserve the draft's complete schema/value, source-end, native-certificate, thread and credit-release checks. This is an uncompiled off-repository draft, not observed activation or a benchmark. Correlated/cyclic membership retains source/test coverage and still needs an explicit diagnostic-scope decision.

Further preparation: `correlated_in` extends the draft to eleven shapes. It uses a
text correlation key and a nullable integer IN key, with repeated and missing
groups. Its independent BTreeMap multiset oracle implements SQL true/false/null
results, including the empty-group case for null correlation keys. It checks all
original columns plus the appended nullable predicate. This exercises the planned
diagnostic path through both correlation and exact-match indices, subject to
future compilation and observed activation; no execution has occurred.

For the separate cyclic owner, reuse the existing complete-output test
`cyclic_candidate_counts_actual_work_for_all_four_frozen_targets` rather than
adding another synthetic three-input fixture. Its abundant, rare, absent and
skew-wide cases already assert actual cyclic executions and exact rows. During
the future attribution step, wrap each existing `complete` call in the debug
RowIndex observation session and retain those counts with its current cyclic
work counts. Preserve its two calls as existing semantic test observations;
they are not scored engine measurements. Require index activation and keep
thread-local scope explicit. No wrapper is currently applied or executed.
