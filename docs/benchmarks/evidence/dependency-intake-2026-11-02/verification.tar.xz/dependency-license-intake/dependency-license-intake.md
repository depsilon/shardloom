# Dependency license intake — 2026-11-02

Comparison: `origin/main` → `aa6c0f2ee96eff3473b4c1f80f24c8c611003b6a`. Added registry package versions: 7. Removed versions: 7. Archive bytes verified: 3,792,669 total (limit 64 MiB); every archive is <=16 MiB.

Each archive SHA-256 matches the exact checksum in the combined branch `Cargo.lock`. Archives were read as tar streams; no extraction to package source trees and no package code was run. Raw proof-member bytes and SHA-256 are under `proofs/`.

| Added package | Declared license | Repository | Packaged VCS revision/path | Embedded license proof |
|---|---|---|---|---|
| `adbc_core 0.25.0` | `Apache-2.0` | https://github.com/apache/arrow-adbc | `1f9f5540dbcb695c540dfcdafeea421c7d94adb1` / `rust/core` | None in archive |
| `adbc_ffi 0.25.0` | `Apache-2.0` | https://github.com/apache/arrow-adbc | `1f9f5540dbcb695c540dfcdafeea421c7d94adb1` / `rust/ffi` | None in archive |
| `jiff 0.2.38` | `Unlicense OR MIT` | https://github.com/BurntSushi/jiff | `4ce3e20ecd3930b6f18cee5b9e4f0270287ea2d9` / `crates/jiff` | `proofs/jiff-0.2.38/COPYING` (SHA-256 `01c266bced4a434da0051174d6bee16a4c82cf634e2679b6155d40d75012390f`), `proofs/jiff-0.2.38/LICENSE-MIT` (SHA-256 `0f96a83840e146e43c0ec96a22ec1f392e0680e6c1226e6f3ba87e0740af850f`) |
| `jiff-static 0.2.38` | `Unlicense OR MIT` | https://github.com/BurntSushi/jiff | `4ce3e20ecd3930b6f18cee5b9e4f0270287ea2d9` / `crates/jiff-static` | `proofs/jiff-static-0.2.38/COPYING` (SHA-256 `01c266bced4a434da0051174d6bee16a4c82cf634e2679b6155d40d75012390f`), `proofs/jiff-static-0.2.38/LICENSE-MIT` (SHA-256 `0f96a83840e146e43c0ec96a22ec1f392e0680e6c1226e6f3ba87e0740af850f`) |
| `libsqlite3-sys 0.39.1` | `MIT` | https://github.com/rusqlite/rusqlite | `fb7c711f4e988db149f43cac68f7865b25d0b10e` / `libsqlite3-sys` | `proofs/libsqlite3-sys-0.39.1/LICENSE` (SHA-256 `c10c1f27337546471e5f7e4e97fdd398b35b9d4e126115dcd22de8d8e65abf6f`) |
| `rusqlite 0.41.1` | `MIT` | https://github.com/rusqlite/rusqlite | `18ee76dbb976d5ef7e37ad5a8fffae678ca21a78` / repository root (`path_in_vcs` is empty) | `proofs/rusqlite-0.41.1/LICENSE` (SHA-256 `c10c1f27337546471e5f7e4e97fdd398b35b9d4e126115dcd22de8d8e65abf6f`) |
| `tonic 0.14.8` | `MIT` | https://github.com/grpc/grpc-rust | `541379959bf197057a7c04eeca7f1d976f5ba7c6` / `tonic` | `proofs/tonic-0.14.8/LICENSE` (SHA-256 `5c686e0f7978412b49187ae0e9f77e9b52eea9d8d2e6c0de8694b35817d873b1`) |

## Missing archive evidence

The checksum-matching `adbc_core 0.25.0` and `adbc_ffi 0.25.0` archives contain no LICENSE/NOTICE/COPYING/COPYRIGHT files. Their archived manifests declare Apache-2.0 and `.cargo_vcs_info.json` identifies the exact shared source revision. The upstream repository tree at that revision contains these root files; links identify the exact VCS evidence location, but their bytes are not embedded archive proof:

- [arrow-adbc LICENSE.txt at 1f9f5540dbcb695c540dfcdafeea421c7d94adb1](https://github.com/apache/arrow-adbc/blob/1f9f5540dbcb695c540dfcdafeea421c7d94adb1/LICENSE.txt)
- [arrow-adbc NOTICE.txt at 1f9f5540dbcb695c540dfcdafeea421c7d94adb1](https://github.com/apache/arrow-adbc/blob/1f9f5540dbcb695c540dfcdafeea421c7d94adb1/NOTICE.txt)

No older notice bundle was used as evidence. License compatibility is left to the primary agent.

The exact removed registry versions are `adbc_core 0.24.0`, `adbc_ffi 0.24.0`, `jiff 0.2.35`, `jiff-static 0.2.35`, `libsqlite3-sys 0.38.2`, `rusqlite 0.40.2`, and `tonic 0.14.6`. Their prior lockfile checksums are retained in the JSON inventory.
