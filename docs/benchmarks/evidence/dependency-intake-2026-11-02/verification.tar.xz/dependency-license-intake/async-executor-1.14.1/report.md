# async-executor 1.14.1 dependency license intake

**Status: COMPLETE**

Read-only evidence collection. The package was not executed and no repository files were changed.

## Artifact and archive

- Download: `async-executor-1.14.1.crate` (28817 bytes)
- SHA256: `f426a31126c735126297bc5ea7a521263c9faff4f63ca415267ee625651c4f37`
- Expected registry SHA256: `f426a31126c735126297bc5ea7a521263c9faff4f63ca415267ee625651c4f37`
- Checksum verified: **True**
- Archive members: 19; all members were safe relative regular files (no links or special members). Only the requested metadata and legal files were selectively extracted.
- Complete legal-file inventory: **True** — `async-executor-1.14.1/LICENSE-APACHE`, `async-executor-1.14.1/LICENSE-MIT`; no COPYING or NOTICE files are present.

## Package metadata comparison

- Version: 1.14.0 → 1.14.1
- Declared license: `Apache-2.0 OR MIT`
- MSRV: Rust 1.65 → Rust 1.63
- Runtime and dev dependency declarations: unchanged. The `static = []` feature is unchanged. Both `Cargo.toml` and `Cargo.toml.orig` differ only in the version and rust-version entries.
- Changelog: 1.14.1 fixes a use-after-free when a `Waker` fires during `Executor::drop`, described as a regression in 1.14.0 (#164).
- Archived VCS revision: `a75cad623bd5c6c80ab19a5befb3d9b93a79bfcd` (1.14.0 archive records `543403e773ec4941a6272e29c2ff649bfd01a4f8`).

## License and copyright evidence

| File | 1.14.0 SHA256 | 1.14.1 SHA256 | Bytes identical? |
|---|---|---|---|
| `LICENSE-APACHE` | `a60eea817514531668d7e00765731449fe14d059d3249e0bc93b36de45f759f2` | `a60eea817514531668d7e00765731449fe14d059d3249e0bc93b36de45f759f2` | yes |
| `LICENSE-MIT` | `23f18e03dc49df91622fe2a76176497404e46ced8a715d9d2b67a7446571cca3` | `23f18e03dc49df91622fe2a76176497404e46ced8a715d9d2b67a7446571cca3` | yes |

No license or copyright text delta was detected in the bundled license files.

## File evidence hashes

| 1.14.1 archive member | Size | SHA256 |
|---|---:|---|
| `.cargo_vcs_info.json` | 94 | `fa8c4042230fb5a5a16fb78edfa244193856de49d734a2ef9c8c240637c10fab` |
| `CHANGELOG.md` | 3739 | `bdf785d4c2537f3eb2015b464d6fa0dd8a30088d86dcee73f2b94d86785dd510` |
| `Cargo.toml` | 2654 | `8f237e359a5d4f15d50d450a9722a0b0eac5f74e6ca35d6bb8b12915a26caead` |
| `Cargo.toml.orig` | 1313 | `4f4102906412d478fb2d2156fd85be714e255c04af0f691f1b3df2727f8249e1` |
| `LICENSE-APACHE` | 10847 | `a60eea817514531668d7e00765731449fe14d059d3249e0bc93b36de45f759f2` |
| `LICENSE-MIT` | 1023 | `23f18e03dc49df91622fe2a76176497404e46ced8a715d9d2b67a7446571cca3` |\n
## Unresolved gaps

- No independent VCS checkout or signed provenance attestation was fetched; archived crate VCS metadata is recorded as supplied by the registry archive.
- This intake did not inspect dependency licenses or establish full source-level equivalence.
