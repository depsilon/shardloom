# ADBC upstream license and notice source files

Both files were fetched through the GitHub connector from `apache/arrow-adbc` at the exact package VCS revision `1f9f5540dbcb695c540dfcdafeea421c7d94adb1`, then preserved as decoded raw bytes.

| File | Exact source URL | Preserved file | Bytes | SHA-256 | GitHub blob SHA-1 |
|---|---|---|---:|---|---|
| `LICENSE.txt` | [revision-pinned source](https://github.com/apache/arrow-adbc/blob/1f9f5540dbcb695c540dfcdafeea421c7d94adb1/LICENSE.txt) | `LICENSE.txt` | 18,429 | `dc5cebbee29b59a9ac7939feeb810ed88d5c299d964f4941497c1b56c24dac62` | `451c356733927eb4918802223673d863a1af0cb6` |
| `NOTICE.txt` | [revision-pinned source](https://github.com/apache/arrow-adbc/blob/1f9f5540dbcb695c540dfcdafeea421c7d94adb1/NOTICE.txt) | `NOTICE.txt` | 171 | `59d7cc401deb7b8ca6c6463848a9d6a302b18d83c2a3f75136bfead3c5c5f9bb` | `b629176a2b119068967eae2bff8cbd61ab323652` |

Computed Git blob SHA-1 values match the SHAs returned by GitHub for both files. This records source and byte integrity only; it does not assess license compatibility.
