"""Preserve exact dependency-batch source, legal and local validation evidence."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

O = Path(__file__).resolve().parents[1]
D = Path('/Users/dylan/.codex/worktrees/dependency-compatibility-batch/shardloom-local-repo')
DEST = D / 'docs/benchmarks/evidence/dependency-intake-2026-11-02'


def identity(data):
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def read_json(path):
    return json.loads(path.read_text())


def basename(value):
    assert re.fullmatch(r'[A-Za-z0-9_.-]+', value) and value not in {'.', '..'}, value
    return value


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--runtime', required=True)
    parser.add_argument('--wheel', required=True)
    parser.add_argument('--last-number', type=int, required=True)
    parser.add_argument('--final-receipts', nargs='+', required=True)
    args = parser.parse_args()
    assert not DEST.exists(), DEST
    runtime_dir = O / basename(args.runtime)
    wheel_dir = O / basename(args.wheel)
    runtime = read_json(runtime_dir / 'manifest.json')
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=D, text=True).strip()
    changed_code = set()
    for command in (['git', 'diff', '--name-only', '-z', 'HEAD'],
                    ['git', 'ls-files', '--others', '--exclude-standard', '-z']):
        changed_code.update(name for name in subprocess.check_output(command, cwd=D).decode().split('\0')
            if name.endswith(('.rs', '.py', '.toml', '.lock')))
    assert runtime['source_revision'] == head
    for name, expected in runtime['source_snapshot'].items():
        assert identity((D / name).read_bytes()) == expected, name
    for name, expected in runtime['files'].items():
        assert identity((runtime_dir / name).read_bytes()) == expected, name
    wheel = read_json(wheel_dir / 'report.json')
    integration = wheel['integration']
    assert wheel['status'] == wheel['uninstall_status'] == integration['status'] == 'passed'
    assert integration['tests'] == 303
    assert integration['errors'] == integration['failures'] == integration['skipped'] == 0
    for key, product in [('native_library_sha256', '_native.abi3.so'), ('cli_sha256', 'shardloom')]:
        assert wheel['stage'][key] == runtime['files'][product]['sha256']

    final_names = [basename(name) for name in args.final_receipts]
    assert final_names and len(set(final_names)) == len(final_names)
    members = {}
    receipts = {}
    summaries = []
    source_blobs = set()

    def add(path, name=None):
        assert path.is_file() and not path.is_symlink(), path
        name = name or str(path.relative_to(O))
        assert name not in members and not name.startswith('/') and '..' not in Path(name).parts
        data = path.read_bytes()
        assert sum(map(len, members.values())) + len(data) < 64 << 20
        members[name] = data

    for number in range(668, args.last_number + 1):
        paths = sorted(O.glob(f'io{number:03d}-*.json'))
        assert len(paths) == 1, (number, paths)
        path = paths[0]
        receipt = read_json(path)
        assert receipt['cwd'] == str(D), path
        assert receipt['status'] in {'passed', 'failed'}, path
        log = path.with_suffix('.log')
        raw_log = log.read_bytes()
        assert identity(raw_log)['sha256'] == receipt['log_sha256']
        if path.name in final_names:
            assert receipt['status'] == 'passed' and receipt['returncode'] == 0
            assert receipt['process_group_drained'] is True
            assert receipt['head'] == head
            assert changed_code <= set(receipt['changed_source_inventory']), path
            for relative, expected in receipt['changed_source_inventory'].items():
                if relative.endswith(('.rs', '.py', '.toml', '.lock')) and 'sha256' in expected:
                    assert identity((D / relative).read_bytes()) == expected, relative
        add(path)
        add(log)
        results = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored', raw_log.decode())
        summary = dict(name=path.name, status=receipt['status'], returncode=receipt.get('returncode'),
            final=path.name in final_names, receipt=identity(path.read_bytes()), log=identity(raw_log))
        if results:
            summary['rust_results'] = dict(binaries=len(results), passed=sum(int(x[1]) for x in results),
                failed=sum(int(x[2]) for x in results), ignored=sum(int(x[3]) for x in results))
        summaries.append(summary)
        receipts[path.name] = receipt
        source_blobs.add(receipt['driver_sha256'])
        source_blobs.update(item['sha256'] for item in receipt['changed_source_inventory'].values()
            if 'sha256' in item)

    assert set(final_names) <= set(receipts)
    before = read_json(O / 'io-runtime-dependency-batch-r3' / 'manifest.json')
    after = read_json(O / 'io-runtime-dependency-batch-r4' / 'manifest.json')
    rust_changes = sorted(name for name in before['source_snapshot']
        if name.endswith(('.rs', '.toml', '.lock'))
        and before['source_snapshot'][name] != after['source_snapshot'].get(name))
    assert rust_changes == ['shardloom-python/src/adbc.rs']
    regression = 'io684-dependency-adbc-unhandled-reproducer.json'
    fixed = 'io687-dependency-adbc-focused-r3.json'
    assert receipts[regression]['status'] == 'failed' and receipts[regression]['returncode'] == 1
    assert receipts[regression]['process_group_drained']
    negative_log = (O / regression).with_suffix('.log').read_text()
    assert 'AssertionError: -11 != 0' in negative_log and 'Segmentation fault' in negative_log
    assert receipts[fixed]['status'] == 'passed' and receipts[fixed]['returncode'] == 0
    assert receipts[fixed]['process_group_drained']
    assert 'Ran 14 tests' in (O / fixed).with_suffix('.log').read_text()
    test_source = 'python/tests/test_native_standard_adapters.py'
    assert receipts[regression]['changed_source_inventory'][test_source] == (
        receipts[fixed]['changed_source_inventory'][test_source])
    assert identity((D / test_source).read_bytes()) == receipts[fixed]['changed_source_inventory'][test_source]
    later_changes = sorted(name for name in after['source_snapshot']
        if name.endswith(('.rs', '.py', '.toml', '.lock'))
        and after['source_snapshot'][name] != runtime['source_snapshot'].get(name))
    assert later_changes == ['Cargo.lock'], later_changes
    cleanup_regression = dict(before_receipt=regression, after_receipt=fixed,
        before_native_sha256=before['files']['_native.abi3.so']['sha256'],
        after_native_sha256=after['files']['_native.abi3.so']['sha256'],
        changed_rust_files=rust_changes, identical_regression_source=True,
        before='isolated child SIGSEGV; regression failed', after='all 14 adapter tests passed',
        later_runtime_source_changes=later_changes,
        final_regression_covered_by_installed_integration=True)
    commands = [receipts[name]['command'] for name in final_names]
    assert ['cargo', 'fmt', '--all', '--', '--check'] in commands
    for action in ('clippy', 'test'):
        for native in (False, True):
            assert any(command[:2] == ['cargo', action] and '--workspace' in command
                and '--all-targets' in command and ('release-user-surfaces' in command) == native
                for command in commands), (action, native)
    for script in ('prove_native_python_wheel.py', 'check_python_license_bundle.py',
                   'test_python_license_bundle.py', 'check_dependency_audit.py',
                   'write_public_api_reference.py', 'check_public_status_docs.py'):
        assert any(any(str(arg).endswith(script) for arg in command) for command in commands), script
    audit = read_json(O / 'dependency-batch-audit-r2.json')
    assert audit['release_gate'] and audit['fallback_dependency_absent']
    assert audit['cargo_deny_status'] == audit['cargo_audit_status'] == audit['pip_audit_status'] == 'passed'
    license_report = read_json(O / 'dependency-batch-license-bundle.json')
    assert license_report['status'] == 'passed'
    license_receipts = [receipts[name] for name in final_names
        if any(str(arg).endswith('check_python_license_bundle.py')
            for arg in receipts[name]['command'])]
    assert len(license_receipts) == 1
    for relative, expected in license_receipts[0]['changed_source_inventory'].items():
        if relative.startswith('python/THIRD_PARTY_LICENSES/'):
            path = D / relative
            if expected.get('absent'):
                assert not path.exists(), relative
            else:
                assert identity(path.read_bytes()) == expected, relative
    for digest in sorted(source_blobs):
        path = O / 'source-blobs' / digest
        assert identity(path.read_bytes())['sha256'] == digest
        add(path)
    for path in sorted((O / 'dependency-license-intake').rglob('*')):
        if (path.is_file() and path.suffix != '.crate'
                and 'archives' not in path.relative_to(O / 'dependency-license-intake').parts):
            add(path)
    for directory in sorted(O.glob('io-runtime-dependency-batch-r*')):
        if (directory / 'manifest.json').is_file():
            for filename in ('manifest.json', 'source-overlay.patch'):
                add(directory / filename)
    for filename in ('manifest.json', 'source-overlay.patch'):
        add(O / 'io-runtime-local-tables-r5' / filename)
    for number in (657, 659):
        paths = list(O.glob(f'io{number}-*.json'))
        assert len(paths) == 1
        proof = read_json(paths[0])
        assert proof['status'] == 'passed' and proof['process_group_drained']
        assert identity(paths[0].with_suffix('.log').read_bytes())['sha256'] == proof['log_sha256']
        add(paths[0])
        add(paths[0].with_suffix('.log'))
    for directory in sorted(O.glob('installed-wheel-dependency-batch-r*')):
        for path in sorted(directory.iterdir()):
            if path.is_file() and path.suffix in {'.json', '.log'}:
                add(path)
    for filename in ('dependency-batch-audit.json', 'dependency-batch-audit-failed-r1.json',
                     'dependency-batch-audit-r2.json', 'dependency-batch-license-bundle.json',
                     'open-dependency-prs-2026-11-02.md', 'open-dependency-pr-1636-codeql-rust.log',
                     'local-table-completed-payload-retirement-plan.json.xz',
                     'local-table-completed-payload-retirement.json',
                     'dependency-failed-payload-retirement-plan.json.xz',
                     'dependency-failed-payload-retirement.json',
                     'dependency-completed-environment-retirement-plan.json.xz',
                     'dependency-completed-environment-retirement.json',
                     'dependency-completed-test-cache-candidates.json',
                     'dependency-completed-test-cache-candidates-r2.json',
                     'dependency-completed-test-cache-retirement-plan.json.xz',
                     'dependency-completed-test-cache-retirement.json',
                     'dependency-obsolete-table-library-candidates.json',
                     'dependency-packaging-storage-retirement-plan.json.xz',
                     'dependency-packaging-storage-retirement.json',
                     'pr1645-final-hosted-acceptance.json',
                     'adbc-025-cancellation-source-inventory.md', 'adbc-cleanup-crash-summaries.json'):
        add(O / filename)
    for filename in ('run_guarded_dependency_batch.py', 'freeze_dependency_runtime.py',
                     'update_dependency_notices.py', 'complete_dependency_notices.py',
                     'update_executor_notices.py', 'retire_completed_dependency_environments.py',
                     'retire_dependency_test_cache.py', 'retire_completed_test_executables.py',
                     'retire_dependency_packaging_cache.py',
                     'retire_local_table_completed_payloads.py', 'retire_adaptive_decisions_payloads.py',
                     'retire_dependency_failed_payloads.py',
                     Path(__file__).name):
        add(O / 'tools' / filename)
    for relative in ('Cargo.toml', 'Cargo.lock', 'shardloom-cli/Cargo.toml', '.github/dependabot.yml',
                     'python/THIRD_PARTY_LICENSES/manifest.json',
                     'shardloom-python/src/adbc.rs', 'shardloom-python/src/adbc_connection.rs',
                     'shardloom-python/src/adbc_statement.rs',
                     'python/tests/test_native_standard_adapters.py',
                     'docs/reference/shardloom-user-surface-index.json',
                     'docs/reference/shardloom-user-surface-index.md',
                     'docs/architecture/dependency-intake-2026-11-02.md'):
        add(D / relative, 'source/' + relative)
    for filename in ('5c686e0f7978412b49187ae0e9f77e9b52eea9d8d2e6c0de8694b35817d873b1.txt',
                     'dc5cebbee29b59a9ac7939feeb810ed88d5c299d964f4941497c1b56c24dac62.txt'):
        relative = 'python/THIRD_PARTY_LICENSES/texts/' + filename
        add(D / relative, 'source/' + relative)

    DEST.mkdir(parents=True)
    archive_path = DEST / 'verification.tar.xz'
    with tarfile.open(archive_path, 'x:xz', preset=6) as bundle:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.mode = 0o644
            info.size = len(data)
            bundle.addfile(info, io.BytesIO(data))
    with tarfile.open(archive_path, 'r:xz') as bundle:
        entries = bundle.getmembers()
        assert len(entries) == len(members) and {entry.name for entry in entries} == set(members)
        for entry in entries:
            assert entry.isfile() and bundle.extractfile(entry).read() == members[entry.name]
    archive_bytes = archive_path.read_bytes()
    assert len(archive_bytes) < 8 << 20
    report = dict(schema_version='shardloom.compatible_dependency_acceptance.v1',
        status='local_acceptance_passed', source_base=head, code_snapshot=runtime['source_snapshot'],
        runtime_files=runtime['files'], installed_integration=integration,
        installed_wheel=wheel['integrity'], uninstall_status=wheel['uninstall_status'],
        dependency_audit=audit, license_bundle=license_report,
        adbc_cleanup_regression=cleanup_regression,
        final_receipts=final_names, all_receipts=summaries,
        final_rust_results={row['name']: row['rust_results'] for row in summaries
            if row['final'] and 'rust_results' in row},
        hosted_acceptance='pending', performance_claim='none; no benchmark run',
        archive=dict(path=archive_path.name, **identity(archive_bytes), members=len(members),
            unpacked_bytes=sum(map(len, members.values())), complete_byte_readback='passed',
            member_identities={name: identity(data) for name, data in sorted(members.items())}))
    (DEST / 'acceptance.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(status=report['status'], archive_bytes=len(archive_bytes), members=len(members),
        final_rust_results=report['final_rust_results'], installed_tests=integration['tests'])))


if __name__ == '__main__':
    main()
