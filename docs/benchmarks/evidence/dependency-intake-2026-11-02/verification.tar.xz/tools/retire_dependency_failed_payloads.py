"""Retire superseded dependency binaries and failed package payloads, preserving evidence."""
import hashlib
import json
import lzma
from pathlib import Path
import shutil

from retire_adaptive_decisions_payloads import identity, verify, closed

O = Path(__file__).resolve().parents[1]
PLAN = O / 'dependency-failed-payload-retirement-plan.json.xz'
RESULT = O / 'dependency-failed-payload-retirement.json'


def main():
    assert not PLAN.exists() and not RESULT.exists()
    proofs, retained, files, roots = [], [], [], []
    for number in (677, 680, 681, 684, 687):
        matches = list(O.glob(f'io{number}-*.json'))
        assert len(matches) == 1
        receipt = json.loads(matches[0].read_text())
        assert receipt['process_group_drained'] and receipt['status'] == (
            'passed' if number == 687 else 'failed')
        proofs.append(identity(matches[0]))
        proofs.append(verify(matches[0].with_suffix('.log'), dict(
            sha256=receipt['log_sha256'], bytes=matches[0].with_suffix('.log').stat().st_size)))
    for revision in (2, 3):
        root = O / f'io-runtime-dependency-batch-r{revision}'
        manifest_path = root / 'manifest.json'
        manifest = json.loads(manifest_path.read_text())
        proofs.append(identity(manifest_path))
        proofs.append(verify(root / 'source-overlay.patch', manifest['source_overlay']))
        build_path = O / manifest['build_receipt']
        build = json.loads(build_path.read_text())
        assert build['status'] == 'passed' and build['process_group_drained']
        assert hashlib.sha256(build_path.read_bytes()).hexdigest() == manifest['build_receipt_sha256']
        proofs.append(identity(build_path))
        for name, expected in manifest['files'].items():
            assert name in {'shardloom', '_native.abi3.so'}
            files.append(verify(root / name, expected))
    for name in ('io-runtime-dependency-batch-r4', 'io-runtime-local-tables-r5'):
        root = O / name
        manifest = json.loads((root / 'manifest.json').read_text())
        proofs.append(identity(root / 'manifest.json'))
        for filename, expected in manifest['files'].items():
            retained.append(verify(root / filename, expected))
    package = O / 'installed-wheel-dependency-batch-r1'
    report = json.loads((package / 'report.json').read_text())
    assert report['status'] == 'failed'
    integration = json.loads((package / 'integration.json').read_text())
    assert integration == dict(tests=299, failures=0, errors=2, skipped=0, status='failed')
    for path in sorted(package.iterdir()):
        if path.is_file() and path.suffix in {'.json', '.log'}:
            proofs.append(identity(path))
    for name in ('package', 'venv'):
        root = package / name
        assert root.is_dir() and not root.is_symlink() and root.resolve() == root
        roots.append(root)
    wheel = report['integrity']
    files.append(verify(package / 'dist' / wheel['wheel'], dict(
        bytes=wheel['wheel_bytes'], sha256=wheel['wheel_sha256'])))
    entries = [identity(path) for root in roots for path in [root, *sorted(root.rglob('*'))]]
    assert len({row['path'] for row in [*entries, *files]}) == len(entries) + len(files)
    file_paths = [Path(row['path']) for row in files]
    closed(roots, file_paths)
    plan = dict(status='declared_before_retirement', roots=list(map(str, roots)), entries=entries,
        files=files, proofs=proofs, retained=retained,
        scope='Superseded dependency r2/r3 CLI/library pairs and failed r1 wheel/package/venv only.',
        regeneration_basis='Exact successful build receipts, runtime source identities/overlays, '
            'original package report and all source/receipt/log observations remain.',
        no_payload_archive=True, current_dependency_runtime='io-runtime-dependency-batch-r4',
        current_accepted_table_runtime='io-runtime-local-tables-r5')
    raw = json.dumps(plan, sort_keys=True, separators=(',', ':')).encode()
    with lzma.open(PLAN, 'xb') as stream:
        stream.write(raw)
    with lzma.open(PLAN, 'rb') as stream:
        assert stream.read() == raw
    for row in [*entries, *files, *proofs, *retained]:
        assert identity(Path(row['path'])) == row, row['path']
    closed(roots, file_paths)
    for row in files:
        path = Path(row['path'])
        assert identity(path) == row
        path.unlink()
    for root in roots:
        shutil.rmtree(root)
    assert all(not path.exists() for path in [*roots, *file_paths])
    for row in [*proofs, *retained]:
        assert identity(Path(row['path'])) == row, row['path']
    regular = [row for row in [*entries, *files] if 'sha256' in row]
    result = dict(status='passed', retired_regular_files=len(regular),
        retired_links=sum('link' in row for row in entries),
        retired_logical_bytes=sum(row['stat']['st_size'] for row in regular),
        plan_sha256=hashlib.sha256(PLAN.read_bytes()).hexdigest(),
        repeated_identity_checks=True, closed_handles=True, original_reports_unchanged=True,
        no_input_or_observation_retirement=True, no_payload_archive=True,
        available_bytes_after=shutil.disk_usage(O).free)
    with RESULT.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
