"""Retire only completed test executables named in the two successful suite logs."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

OUT = Path(__file__).resolve().parents[1]
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')


def identity(path):
    before = path.stat()
    if path.is_symlink() or not path.is_file() or not before.st_mode & 0o111:
        raise ValueError('not a regular test executable: ' + str(path))
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    after = path.stat()
    fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    if any(getattr(before, field) != getattr(after, field) for field in fields):
        raise ValueError('test executable changed during hashing')
    return dict(path=str(path), bytes=after.st_size, sha256=digest.hexdigest(),
                generation={field: getattr(after, field) for field in fields}, links=after.st_nlink)


def main():
    target = OUT / 'io-completed-test-executable-retirement.json'
    plan_path = OUT / 'io-completed-test-executable-retirement-plan.json'
    if target.exists() or plan_path.exists():
        raise ValueError('refuse repeated retirement')
    paths, proofs = set(), []
    for name, profile in (('io186-array-snapshot-workspace', 'ci-native'),
                          ('io192-array-snapshot-default-tests', 'debug')):
        receipt_path = OUT / (name + '.json')
        receipt = json.loads(receipt_path.read_text())
        log_path = receipt_path.with_suffix('.log')
        raw = log_path.read_bytes()
        if (receipt['status'] != 'passed' or receipt['returncode'] != 0
                or receipt['process_group_drained'] is not True
                or hashlib.sha256(raw).hexdigest() != receipt['log_sha256']):
            raise ValueError('incomplete or changed test proof')
        all_runners = {Path(value) for value in re.findall(r'Running [^\n]*\(([^)]+)\)', raw.decode())}
        found = {path for path in all_runners if path.parent == CACHE / profile / 'deps'}
        excluded = all_runners - found
        if (len(found) != 107 or len(all_runners) != (119 if profile == 'ci-native' else 107)
                or any(path.parent != CACHE / profile / 'examples' for path in excluded)):
            raise ValueError('unexpected executable inventory')
        paths.update(found)
        proofs.append(dict(receipt=str(receipt_path), receipt_sha256=hashlib.sha256(receipt_path.read_bytes()).hexdigest(),
                           log=str(log_path), log_sha256=receipt['log_sha256'],
                           regeneration_command=receipt['command'], executables=len(found),
                           example_test_executables_retained=list(map(str, sorted(excluded)))))
    records = [identity(path) for path in sorted(paths)]
    call = subprocess.run(['/usr/sbin/lsof', '-nP', '-Fpn', '--', *map(str, sorted(paths))],
                          capture_output=True, text=True, timeout=30)
    if call.returncode != 1 or call.stdout or call.stderr:
        raise ValueError('completed executable has an open handle or lsof was inconclusive: ' + call.stdout + call.stderr)
    plan = dict(status='declared_before_retirement', purpose='Space for the required local I/O coverage pass',
                scope='Only executables from the completed native/default test suites; retain runtime pairs, inputs, compact results and compiler dependencies.',
                proofs=proofs, files=records, closed_handle_check='lsof returned no open handles',
                no_payload_archive=True, source_files_removed=False)
    with plan_path.open('x') as stream:
        json.dump(plan, stream, indent=2)
        stream.write('\n')
    before_free = shutil.disk_usage(OUT).free
    for row in records:
        path = Path(row['path'])
        if identity(path) != row:
            raise ValueError('test executable changed before retirement: ' + str(path))
    for row in records:
        path = Path(row['path'])
        current = path.stat()
        if any(getattr(current, field) != value for field, value in row['generation'].items()):
            raise ValueError('test executable changed immediately before removal')
        path.unlink()
    if any(path.exists() for path in paths):
        raise ValueError('retired executable remains')
    result = dict(status='passed', plan=str(plan_path), plan_sha256=hashlib.sha256(plan_path.read_bytes()).hexdigest(),
                  removed_executables=len(records), removed_logical_bytes=sum(row['bytes'] for row in records),
                  available_bytes_before=before_free, available_bytes_after=shutil.disk_usage(OUT).free,
                  repeated_identity_checks=True, closed_handles=True, no_queries=True,
                  no_runtime_or_input_files_removed=True, no_payload_archive=True)
    with target.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({key: result[key] for key in ('status', 'removed_executables', 'removed_logical_bytes')}))


if __name__ == '__main__':
    main()
