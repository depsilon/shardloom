"""Refresh only the seven reviewed registry versions in the dependency batch."""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import tomllib

ROOT = Path('/Users/dylan/.codex/worktrees/dependency-compatibility-batch/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
INTAKE = OUT / 'dependency-license-intake'
BUNDLE = ROOT / 'python/THIRD_PARTY_LICENSES'
BASE = 'd3e943add236baf3200fa07d299437cc3dd71314'
REGISTRY = 'registry+https://github.com/rust-lang/crates.io-index'
ADBC_REVISION = '1f9f5540dbcb695c540dfcdafeea421c7d94adb1'
ADBC_TEXTS = {
    'LICENSE.txt': ('451c356733927eb4918802223673d863a1af0cb6',
                    'dc5cebbee29b59a9ac7939feeb810ed88d5c299d964f4941497c1b56c24dac62'),
    'NOTICE.txt': ('b629176a2b119068967eae2bff8cbd61ab323652',
                   '59d7cc401deb7b8ca6c6463848a9d6a302b18d83c2a3f75136bfead3c5c5f9bb'),
}
EXPECTED = {
    ('adbc_core', '0.25.0'): 'Apache-2.0',
    ('adbc_ffi', '0.25.0'): 'Apache-2.0',
    ('jiff', '0.2.38'): 'Unlicense OR MIT',
    ('jiff-static', '0.2.38'): 'Unlicense OR MIT',
    ('libsqlite3-sys', '0.39.1'): 'MIT',
    ('rusqlite', '0.41.1'): 'MIT',
    ('tonic', '0.14.8'): 'MIT',
}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def key(package: dict) -> tuple[str, str, str]:
    return package['name'], package['version'], package['source']


def main() -> None:
    result_path = INTAKE / 'bundle-verification.json'
    assert not result_path.exists()
    prior_bytes = subprocess.check_output(
        ['git', 'show', f'{BASE}:python/THIRD_PARTY_LICENSES/manifest.json'], cwd=ROOT)
    manifest_path = BUNDLE / 'manifest.json'
    assert manifest_path.read_bytes() == prior_bytes
    prior = json.loads(prior_bytes)
    known = {key(p): p for p in prior['components']}
    locked = {key(p): p for p in tomllib.loads((ROOT / 'Cargo.lock').read_text())['package']
              if p.get('source', '').startswith('registry+')}
    intake = json.loads((INTAKE / 'dependency-license-intake.json').read_text())
    added = {(p['name'], p['version'], REGISTRY): p for p in intake['packages']}
    removed = {key(p): p for p in intake['removed_registry_packages']}
    assert set(added) == set(locked) - set(known)
    assert set(removed) == set(known) - set(locked)
    assert {(p['name'], p['version']) for p in added.values()} == set(EXPECTED)
    for identity, item in removed.items():
        assert item['checksum'] == known[identity]['crate_checksum_sha256']
    for identity in set(known) & set(locked):
        assert known[identity]['crate_checksum_sha256'] == locked[identity]['checksum']

    # Validate all existing text bytes before reusing unchanged records verbatim.
    old_texts = {}
    for component in prior['components'] + prior['vendored_components']:
        for item in component['files']:
            path = BUNDLE / item['text']
            assert path.is_file() and not path.is_symlink()
            data = path.read_bytes()
            assert sha(data) == item['sha256'] and len(data) == item['bytes']
            old_texts[item['text']] = data

    new_texts, records = {}, []
    for identity, package in sorted(added.items()):
        archive_path = Path(package['archive'])
        checksum = locked[identity]['checksum']
        assert package['checksum'] == checksum == sha(archive_path.read_bytes())
        prefix = f'{package["name"]}-{package["version"]}/'
        with tarfile.open(archive_path, 'r:gz') as archive:
            package_meta = tomllib.loads(archive.extractfile(prefix + 'Cargo.toml').read().decode())['package']
            vcs = json.loads(archive.extractfile(prefix + '.cargo_vcs_info.json').read())
            assert package_meta['license'] == EXPECTED[identity[:2]] == package['license']
            assert package_meta['repository'] == package['repository']
            assert vcs['git']['sha1'] == package['vcs_revision']
            legal = [m for m in archive.getmembers()
                     if PurePosixPath(m.name).name.upper().startswith(
                         ('LICENSE', 'NOTICE', 'COPYING', 'COPYRIGHT'))]
            assert sorted(m.name for m in legal) == sorted(package['embedded_license_notice_files'])
            sources = []
            for member in legal:
                assert member.isfile() and member.name.startswith(prefix)
                relative = member.name[len(prefix):]
                assert '..' not in PurePosixPath(relative).parts
                sources.append((archive.extractfile(member).read(), {'crate_path': relative}))
            if package['name'].startswith('adbc_'):
                assert not legal and vcs['git']['sha1'] == ADBC_REVISION
                for filename in ('LICENSE.txt', 'NOTICE.txt'):
                    data = (INTAKE / 'upstream-adbc' / filename).read_bytes()
                    blob_sha = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
                    assert (blob_sha, sha(data)) == ADBC_TEXTS[filename]
                    sources.append((data, {'upstream_url':
                        f'https://github.com/apache/arrow-adbc/blob/{ADBC_REVISION}/{filename}'}))
            assert sources
            files = []
            for data, provenance in sources:
                data.decode('utf-8')
                digest = sha(data)
                text_path = f'texts/{digest}.txt'
                new_texts[text_path] = data
                files.append(dict(text=text_path, sha256=digest, bytes=len(data), **provenance))
            records.append(dict(name=package['name'], version=package['version'], source=REGISTRY,
                license=package_meta['license'], repository=package_meta['repository'],
                crate_checksum_sha256=checksum,
                files=sorted(files, key=lambda item: (item['text'], json.dumps(item, sort_keys=True)))))

    updated = dict(prior, components=sorted(
        [p for identity, p in known.items() if identity not in removed] + records, key=key))
    used = {f['text'] for p in updated['components'] + updated['vendored_components'] for f in p['files']}
    # All input validation precedes the small generated-bundle update.
    for name, data in new_texts.items():
        path = BUNDLE / name
        assert not path.is_symlink()
        if path.exists():
            assert path.read_bytes() == data
        else:
            path.write_bytes(data)
    manifest_path.write_text(json.dumps(updated, indent=2, ensure_ascii=False) + '\n')
    retired = []
    for name, data in old_texts.items():
        if name not in used:
            path = BUNDLE / name
            assert path.read_bytes() == data
            path.unlink()
            retired.append(dict(path=name, bytes=len(data), sha256=sha(data)))
    spec = importlib.util.spec_from_file_location('notices', ROOT / 'scripts/check_python_license_bundle.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    result = module.verify(ROOT)
    result.update(base=BASE, added_components=records, removed_components=list(removed.values()),
                  retired_unreferenced_texts=retired, prior_manifest_sha256=sha(prior_bytes),
                  manifest_sha256=sha(manifest_path.read_bytes()))
    result_path.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('status', 'registry_packages', 'vendored_packages',
                                          'license_file_records', 'unique_text_files')}))


if __name__ == '__main__':
    main()
