"""Retire completed generated cache entries after the final runtime-copy guard stop."""
import datetime
import hashlib
import json
import lzma
from pathlib import Path
import re
import shutil
import stat
import sys

from retire_adaptive_decisions_payloads import identity, verify, closed

O = Path(__file__).resolve().parents[1]
D = Path('/Users/dylan/.codex/worktrees/dependency-compatibility-batch/shardloom-local-repo')
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
sys.path[:0] = [str(D / 'scripts'), '/Users/dylan/LocalData/shardloom/release-0.3.3-20260930']
from release_validation_guard import WorkloadGuard

PLAN = O / 'dependency-packaging-storage-retirement-plan.json.xz'
RESULT = O / 'dependency-packaging-storage-retirement.json'
OLD_LIBRARIES = (
    'libshardloom_vortex-4b820d195600872d.rlib',
    'libshardloom_vortex-e7cd40d7d40c8125.rlib',
    'libshardloom_vortex-9ac6f565732e2f63.rlib',
    'libshardloom_vortex-8e422451d01ba76f.rlib',
    'libshardloom_vortex-2b12a91c6169e2c2.rlib',
    'libshardloom_vortex-1366a70daef0fc12.rlib',
    'libshardloom_vortex-ef4dfded131cebff.rlib',
    'libshardloom_vortex-b2ee7da0273d68b2.rlib',
    'libshardloom_vortex-5c283f8841e3b063.rlib',
    'libshardloom_vortex-b82c24e6d3ceded1.rlib',
)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def receipt(name, expected):
    path = O / name
    value = json.loads(path.read_text())
    assert value['status'] == expected and value['cwd'] == str(D)
    assert value['process_group_drained'] and value['direct_child_reaped']
    raw = path.with_suffix('.log').read_bytes()
    assert sha(raw) == value['log_sha256']
    if expected == 'passed':
        assert value['returncode'] == 0
    return path, value, raw


def regular(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1, path
    return info


def main():
    assert not PLAN.exists() and not RESULT.exists()
    guard = WorkloadGuard()
    guard.check()
    test_path, tests, test_log = receipt('io707-dependency-executor-native-workspace-r2.json', 'passed')
    build_path, build, build_log = receipt('io708-dependency-executor-runtime-build.json', 'passed')
    failed_path, failed, _ = receipt('io709-dependency-executor-runtime-freeze.json', 'failed')
    assert 'minimum free storage' in failed['error']
    assert tests['head'] == build['head'] == failed['head']
    assert tests['command'][:2] == ['cargo', 'test'] and '--workspace' in tests['command']
    assert build['command'][:2] == ['cargo', 'build']
    assert b'Compiling shardloom-vortex' in build_log
    current_manifest = O / 'io-runtime-dependency-batch-r4' / 'manifest.json'
    snapshot = json.loads(current_manifest.read_text())['source_snapshot']
    for name, expected in snapshot.items():
        if name == 'Cargo.lock':
            expected = build['changed_source_inventory'][name]
        raw = (D / name).read_bytes()
        assert dict(bytes=len(raw), sha256=sha(raw)) == expected, name
    proofs = [identity(path) for path in (test_path, test_path.with_suffix('.log'),
        build_path, build_path.with_suffix('.log'), failed_path, failed_path.with_suffix('.log'),
        current_manifest)]
    candidates = []
    provenance = {}
    for label, value in re.findall(r'Running ([^\n]+?) \(([^)]+)\)', test_log.decode()):
        path = Path(value)
        if path.parent != CACHE / 'ci-native' / 'deps':
            continue
        info = regular(path)
        dependency = path.with_suffix('.d')
        regular(dependency)
        assert info.st_mode & 0o111
        assert max(info.st_mtime_ns, dependency.stat().st_mtime_ns) <= test_path.stat().st_mtime_ns
        raw = dependency.read_bytes()
        first = raw.decode().splitlines()[0].split(': ', 1)[1].split()[0]
        source = Path(first) if Path(first).is_absolute() else D / first
        assert source.resolve().is_relative_to(D) and source.suffix == '.rs'
        relative = str(source.relative_to(D))
        content = source.read_bytes()
        assert dict(bytes=len(content), sha256=sha(content)) == snapshot[relative]
        candidates.append(path)
        provenance[str(path)] = dict(kind='completed_test_executable', label=label,
            dependency=str(dependency), dependency_sha256=sha(raw), source=relative,
            receipt=test_path.name, regeneration_command=tests['command'])
    assert len(candidates) == len(set(candidates)) == 108
    cutoff = datetime.datetime(2026, 11, 2, tzinfo=datetime.timezone.utc).timestamp()
    for name in OLD_LIBRARIES:
        path = CACHE / 'ci-native' / 'deps' / name
        info = regular(path)
        assert not info.st_mode & 0o111 and info.st_mtime < cutoff
        dependency = path.with_name(path.name[3:]).with_suffix('.d')
        regular(dependency)
        raw = dependency.read_bytes()
        assert raw.decode().splitlines()[0].split(': ', 1)[1].split()[0] == 'shardloom-vortex/src/lib.rs'
        candidates.append(path)
        provenance[str(path)] = dict(kind='obsolete_generated_vortex_library',
            dependency=str(dependency), dependency_sha256=sha(raw),
            policy='Exact pre-November-2 generated native Vortex cache; regenerable from repository source.',
            original_worktree='unavailable: relative dep-info is not worktree attribution',
            regeneration_command=build['command'])
    replacement = CACHE / 'ci-native' / 'deps' / 'libshardloom_vortex-94d7e3bac33708de.rlib'
    regular(replacement)
    assert test_path.stat().st_mtime_ns < replacement.stat().st_mtime_ns <= build_path.stat().st_mtime_ns
    retained = [identity(replacement)]
    for runtime_name, wheel_name in [('io-runtime-local-tables-r5', 'installed-wheel-local-tables-r2'),
                                    ('io-runtime-dependency-batch-r4', 'installed-wheel-dependency-batch-r2')]:
        runtime = O / runtime_name
        manifest = json.loads((runtime / 'manifest.json').read_text())
        retained.extend(verify(runtime / name, expected) for name, expected in manifest['files'].items())
        package = O / wheel_name
        report = json.loads((package / 'report.json').read_text())
        assert report['status'] == report['uninstall_status'] == 'passed'
        wheel = report['integrity']
        retained.append(verify(package / 'dist' / wheel['wheel'], dict(
            bytes=wheel['wheel_bytes'], sha256=wheel['wheel_sha256'])))
    partial = O / 'io-runtime-dependency-batch-r5'
    assert not partial.is_symlink() and partial.is_dir()
    assert {path.name for path in partial.iterdir()} == {'shardloom', '_native.abi3.so'}
    for name, cache_name in [('shardloom', 'shardloom'), ('_native.abi3.so', 'lib_native.dylib')]:
        original = CACHE / 'ci-native' / cache_name
        expected = identity(original)
        retained.append(expected)
        path = partial / name
        regular(path)
        verify(path, dict(bytes=expected['stat']['st_size'], sha256=expected['sha256']))
        candidates.append(path)
        provenance[str(path)] = dict(kind='incomplete_runtime_copy', failed_receipt=failed_path.name,
            retained_original=str(original), regeneration_command=failed['command'])
    assert len(candidates) == len(set(candidates))
    records = [dict(identity(path), provenance=provenance[str(path)]) for path in candidates]
    closed([partial], candidates)
    plan = dict(status='declared_before_retirement', files=records, proofs=proofs, retained=retained,
        scope='Completed test executables, ten exact obsolete Vortex libraries and incomplete copied runtime; '
              'all inputs, tested runtimes/wheels, current build products and original results retained.',
        rejected_inventory_attribution='Relative .d paths cannot identify the old T worktree; '
            'dependency-obsolete-table-library-candidates.json is retained as a non-authoritative inventory.',
        no_payload_archive=True)
    raw = json.dumps(plan, sort_keys=True, separators=(',', ':')).encode()
    assert len(raw) < 4 << 20
    with lzma.open(PLAN, 'xb') as stream:
        stream.write(raw)
    with lzma.open(PLAN, 'rb') as stream:
        assert stream.read() == raw
    guard.check()
    closed([partial], candidates)
    for row in [*records, *proofs, *retained]:
        expected = {key: value for key, value in row.items() if key != 'provenance'}
        assert identity(Path(row['path'])) == expected
    for row in records:
        evidence = row['provenance']
        if 'dependency' in evidence:
            assert sha(Path(evidence['dependency']).read_bytes()) == evidence['dependency_sha256']
    result = dict(status='running', retired=[], available_bytes_before=shutil.disk_usage(O).free)
    try:
        for row in records:
            path = Path(row['path'])
            info = regular(path)
            assert all(getattr(info, key) == value for key, value in row['stat'].items())
            path.unlink()
            result['retired'].append(str(path))
        partial.rmdir()
        for row in [*proofs, *retained]:
            assert identity(Path(row['path'])) == row
        result.update(status='passed', retired_regular_files=len(records),
            retired_logical_bytes=sum(row['stat']['st_size'] for row in records),
            repeated_identity_checks=True, closed_handles=True, no_payload_archive=True,
            tested_runtime_wheel_and_results_retained=True, plan_sha256=sha(PLAN.read_bytes()),
            available_bytes_after=shutil.disk_usage(O).free)
    finally:
        with RESULT.open('x') as stream:
            json.dump(result, stream, indent=2)
            stream.write('\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'retired'}))


if __name__ == '__main__':
    main()
