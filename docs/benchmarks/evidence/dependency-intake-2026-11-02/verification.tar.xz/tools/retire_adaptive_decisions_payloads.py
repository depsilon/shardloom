"""Retire exact superseded runtimes and completed package trees after hosted acceptance."""
import hashlib
import json
import lzma
import os
from pathlib import Path
import shutil
import stat
import subprocess

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-adaptive-evidence/shardloom-local-repo')
HEAD = '563279a54e398897584eb2b132d7d0bb017f44a2'
GATE = OUT / 'pr1644-final-hosted-acceptance.json'
PLAN = OUT / 'adaptive-decisions-payload-retirement-plan.json.xz'
RESULT = OUT / 'adaptive-decisions-payload-retirement.json'
FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_size', 'st_mtime_ns', 'st_ctime_ns')


def identity(path):
    before = path.lstat()
    if stat.S_ISLNK(before.st_mode):
        value = {'link': os.readlink(path)}
    elif stat.S_ISDIR(before.st_mode):
        value = {'directory': True}
    elif stat.S_ISREG(before.st_mode):
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            for data in iter(lambda: stream.read(1 << 20), b''):
                digest.update(data)
        value = {'sha256': digest.hexdigest()}
    else:
        raise ValueError(f'Unexpected generated file type: {path}')
    after = path.lstat()
    assert all(getattr(before, key) == getattr(after, key) for key in FIELDS), path
    return {'path': str(path), 'stat': {key: getattr(after, key) for key in FIELDS}, **value}


def verify(path, expected):
    actual = identity(path)
    assert actual.get('sha256') == expected['sha256'], path
    assert actual['stat']['st_size'] == expected['bytes'], path
    return actual


def closed(roots, files):
    for root in roots:
        result = subprocess.run(['/usr/sbin/lsof', '-nP', '+D', str(root)],
                                capture_output=True, text=True, timeout=45)
        assert result.returncode == 1 and not result.stdout and not result.stderr, (
            f'Open-handle check is not clear for {root}')
    result = subprocess.run(['/usr/sbin/lsof', '-nP', '-Fpn', '--', *map(str, files)],
                            capture_output=True, text=True, timeout=30)
    assert result.returncode == 1 and not result.stdout and not result.stderr, (
        'Binary open-handle check is not clear')
    commands = subprocess.check_output(['ps', '-axo', 'command'], text=True)
    assert not any(str(path) in commands for path in [*roots, *files]), (
        'Retirement candidate is referenced by an active process')


def main():
    assert not PLAN.exists() and not RESULT.exists(), 'One-shot retirement already started'
    gate = json.loads(GATE.read_text())
    assert gate['head'] == HEAD and gate['status'] == 'passed'
    assert gate['review']['commit_sha'] == HEAD and not gate['review']['has_any_findings']
    assert gate['checks'] and all(row['head_sha'] == HEAD and row['status'] == 'completed'
                                and row['conclusion'] in ('success', 'neutral', 'skipped')
                                for row in gate['checks'])
    local = ROOT / 'docs/benchmarks/evidence/native-adaptive-decisions-acceptance-2026-11-02/acceptance.json'
    acceptance = json.loads(local.read_text())
    assert acceptance['status'] == 'local_acceptance_passed'
    proofs = [identity(GATE), identity(local)]
    current = OUT / 'io-runtime-adaptive-decisions-r2'
    manifest_path = current / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    proofs.append(identity(manifest_path))
    retained = [verify(current / name, value) for name, value in manifest['files'].items()]
    package = OUT / 'installed-wheel-adaptive-decisions-r1'
    report_path = package / 'report.json'
    report = json.loads(report_path.read_text())
    assert report['status'] == report['uninstall_status'] == 'passed'
    assert report['integration'] == {'tests': 292, 'failures': 0, 'errors': 0,
                                     'skipped': 0, 'status': 'passed'}
    for name, key in [('shardloom', 'cli_sha256'), ('_native.abi3.so', 'native_library_sha256')]:
        assert report['stage'][key] == manifest['files'][name]['sha256']
    retained.append(verify(package / 'dist' / report['integrity']['wheel'],
                           {'bytes': report['integrity']['wheel_bytes'],
                            'sha256': report['integrity']['wheel_sha256']}))
    proofs.append(identity(report_path))
    archive = local.parent / acceptance['archive']['path']
    proofs.append(verify(archive, acceptance['archive']))
    files = []
    for name in ('io-runtime-r8', 'io-runtime-adaptive-source-r1',
                 'io-runtime-adaptive-runtime-r1', 'io-runtime-adaptive-ingest-r2',
                 'io-runtime-adaptive-decisions-r1'):
        root = OUT / name
        path = root / 'manifest.json'
        old = json.loads(path.read_text())
        proofs.append(identity(path))
        build_path = OUT / old['build_receipt']
        build = json.loads(build_path.read_text())
        assert build['status'] == 'passed' and build['returncode'] == 0
        assert hashlib.sha256(build_path.read_bytes()).hexdigest() == old['build_receipt_sha256']
        proofs.append(identity(build_path))
        proofs.append(verify(root / 'source-overlay.patch', old['source_overlay']))
        assert old['source_revision'] and old['source_snapshot']
        for filename, expected in old['files'].items():
            assert filename in ('shardloom', '_native.abi3.so')
            files.append(verify(root / filename, expected))
    roots = []
    for name in [*(f'installed-wheel-r{i}' for i in range(1, 8)),
                 'installed-wheel-adaptive-source-r1', 'installed-wheel-adaptive-decisions-r1']:
        root = OUT / name
        path = root / 'report.json'
        old = json.loads(path.read_text())
        assert old['status'] in ('passed', 'failed')
        proofs.extend(identity(p) for p in sorted(root.iterdir())
                      if p.is_file() and p.suffix in ('.json', '.log'))
        for child in ('package', 'venv'):
            candidate = root / child
            if candidate.exists():
                assert candidate.is_dir() and not candidate.is_symlink()
                roots.append(candidate)
        if name != 'installed-wheel-adaptive-decisions-r1':
            wheel = root / 'dist' / old['integrity']['wheel']
            if wheel.exists():
                files.append(verify(wheel, {'bytes': old['integrity']['wheel_bytes'],
                                           'sha256': old['integrity']['wheel_sha256']}))
    records = []
    for root in roots:
        assert root.resolve() == root and root.is_relative_to(OUT), root
        records.extend(identity(path) for path in [root, *sorted(root.rglob('*'))])
    assert len({row['path'] for row in [*records, *files]}) == len(records) + len(files)
    file_paths = [Path(row['path']) for row in files]
    closed(roots, file_paths)
    plan = {'status': 'declared_before_retirement', 'roots': list(map(str, roots)),
            'entries': records, 'files': files, 'retained_runtime_and_wheel': retained,
            'proofs': proofs, 'closed_handles': True,
            'scope': 'Exact superseded runtime/wheel files and completed package/environment trees; '
                     'retain all inputs, all result/benchmark records, source manifests/overlays/blobs, '
                     'logs, current r2 runtime and current installed-tested wheel',
            'regeneration_basis': 'Recorded git revisions, source snapshots, changed source blobs, '
                                  'source overlays and original successful build/package commands',
            'no_payload_archive': True}
    data = json.dumps(plan, sort_keys=True, separators=(',', ':')).encode()
    with lzma.open(PLAN, 'xb') as stream:
        stream.write(data)
    with lzma.open(PLAN, 'rb') as stream:
        assert stream.read() == data
    for row in [*records, *files, *proofs, *retained]:
        assert identity(Path(row['path'])) == row, row['path']
    closed(roots, file_paths)
    for row in files:
        path = Path(row['path'])
        assert identity(path) == row
        path.unlink()
    for root in roots:
        shutil.rmtree(root)
    assert all(not path.exists() for path in [*roots, *file_paths])
    for row in [*proofs, *retained]:
        assert identity(Path(row['path'])) == row, row['path']
    regular = [row for row in [*records, *files] if 'sha256' in row]
    result = {'status': 'passed', 'retired_roots': list(map(str, roots)),
              'retired_files': len(regular), 'retired_links': sum('link' in row for row in records),
              'retired_logical_bytes': sum(row['stat']['st_size'] for row in regular),
              'plan_sha256': hashlib.sha256(PLAN.read_bytes()).hexdigest(),
              'retained_runtime_and_wheel': retained,
              'repeated_identity_checks': True, 'closed_handles': True,
              'original_reports_unchanged': True, 'no_input_or_observation_retirement': True,
              'no_queries': True, 'no_payload_archive': True}
    with RESULT.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ('retired_roots', 'retained_runtime_and_wheel')}))


if __name__ == '__main__':
    main()
