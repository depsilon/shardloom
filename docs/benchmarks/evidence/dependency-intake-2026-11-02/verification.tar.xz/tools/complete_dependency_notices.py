"""Retain the two Jiff UNLICENSE members omitted by the initial filename filter."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/dependency-compatibility-batch/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1] / 'dependency-license-intake'
BUNDLE = ROOT / 'python/THIRD_PARTY_LICENSES'
manifest_path = BUNDLE / 'manifest.json'
before = manifest_path.read_bytes()
original = json.loads((OUT / 'bundle-verification.json').read_text())
assert hashlib.sha256(before).hexdigest() == original['manifest_sha256']
assert not (OUT / 'bundle-verification-complete.json').exists()
manifest = json.loads(before)
intake = json.loads((OUT / 'dependency-license-intake.json').read_text())
additions = []
for name in ('jiff', 'jiff-static'):
    package = next(p for p in intake['packages'] if p['name'] == name)
    archive_path = Path(package['archive'])
    assert hashlib.sha256(archive_path.read_bytes()).hexdigest() == package['checksum']
    with tarfile.open(archive_path, 'r:gz') as archive:
        member = archive.getmember(f'{name}-0.2.38/UNLICENSE')
        assert member.isfile()
        data = archive.extractfile(member).read()
    digest = hashlib.sha256(data).hexdigest()
    assert digest == '7e12e5df4bae12cb21581ba157ced20e1986a0508dd10d0e8a4ab9a4cf94e85c'
    target = BUNDLE / f'texts/{digest}.txt'
    assert target.is_file() and not target.is_symlink() and target.read_bytes() == data
    proof = OUT / 'proofs' / f'{name}-0.2.38' / 'UNLICENSE'
    assert not proof.exists()
    proof.write_bytes(data)
    entry = dict(text=f'texts/{digest}.txt', sha256=digest, bytes=len(data), crate_path='UNLICENSE')
    component = next(p for p in manifest['components'] if p['name'] == name and p['version'] == '0.2.38')
    assert all(p.get('crate_path') != 'UNLICENSE' for p in component['files'])
    component['files'].append(entry)
    component['files'].sort(key=lambda p: (p['text'], json.dumps(p, sort_keys=True)))
    additions.append(dict(name=name, version='0.2.38', archive_sha256=package['checksum'], file=entry))
manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')
spec = importlib.util.spec_from_file_location('notices', ROOT / 'scripts/check_python_license_bundle.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
result = module.verify(ROOT)
result.update(supplemented_files=additions, previous_manifest_sha256=hashlib.sha256(before).hexdigest(),
              manifest_sha256=hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
              initial_attempt='bundle-verification.json')
(OUT / 'bundle-verification-complete.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
