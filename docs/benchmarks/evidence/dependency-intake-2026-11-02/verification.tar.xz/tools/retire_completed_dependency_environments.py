"""Retire a completed wheel staging/install tree, keeping its tested products and proof."""
import hashlib
import json
import lzma
from pathlib import Path
import shutil

from retire_adaptive_decisions_payloads import identity, verify, closed

O = Path(__file__).resolve().parents[1]
PLAN = O / 'dependency-completed-environment-retirement-plan.json.xz'
RESULT = O / 'dependency-completed-environment-retirement.json'


def main():
    assert not PLAN.exists() and not RESULT.exists()
    receipt_path = O / 'io694-dependency-final-installed-wheel.json'
    receipt = json.loads(receipt_path.read_text())
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained']
    proofs = [identity(receipt_path), verify(receipt_path.with_suffix('.log'), dict(
        sha256=receipt['log_sha256'], bytes=receipt_path.with_suffix('.log').stat().st_size))]
    package = O / 'installed-wheel-dependency-batch-r2'
    report = json.loads((package / 'report.json').read_text())
    assert report['status'] == report['uninstall_status'] == 'passed'
    assert report['integration'] == dict(tests=303, failures=0, errors=0, skipped=0, status='passed')
    proofs.extend(identity(p) for p in sorted(package.iterdir())
                  if p.is_file() and p.suffix in {'.json', '.log'})
    runtime = O / 'io-runtime-dependency-batch-r4'
    manifest = json.loads((runtime / 'manifest.json').read_text())
    proofs.append(identity(runtime / 'manifest.json'))
    proofs.append(verify(runtime / 'source-overlay.patch', manifest['source_overlay']))
    retained = [verify(runtime / name, value) for name, value in manifest['files'].items()]
    for key, name in [('native_library_sha256', '_native.abi3.so'), ('cli_sha256', 'shardloom')]:
        assert report['stage'][key] == manifest['files'][name]['sha256']
    wheel = report['integrity']
    retained.append(verify(package / 'dist' / wheel['wheel'], dict(
        bytes=wheel['wheel_bytes'], sha256=wheel['wheel_sha256'])))
    roots = [package / name for name in ('package', 'venv')]
    for root in roots:
        assert root.is_dir() and not root.is_symlink() and root.resolve() == root
    entries = [identity(path) for root in roots for path in [root, *sorted(root.rglob('*'))]]
    assert len({row['path'] for row in entries}) == len(entries)
    current_files = [Path(row['path']) for row in retained]
    closed(roots, current_files)
    plan = dict(status='declared_before_retirement', roots=list(map(str, roots)), entries=entries,
        proofs=proofs, retained=retained,
        scope='Completed dependency r2 package staging and uninstalled test environment only.',
        regeneration_basis='Exact frozen r4 runtime, retained installed-tested wheel, package commands, '
            'all source identities, all original reports and logs.', no_payload_archive=True)
    raw = json.dumps(plan, sort_keys=True, separators=(',', ':')).encode()
    with lzma.open(PLAN, 'xb') as stream:
        stream.write(raw)
    with lzma.open(PLAN, 'rb') as stream:
        assert stream.read() == raw
    for row in [*entries, *proofs, *retained]:
        assert identity(Path(row['path'])) == row, row['path']
    closed(roots, current_files)
    for root in roots:
        shutil.rmtree(root)
    assert all(not root.exists() for root in roots)
    for row in [*proofs, *retained]:
        assert identity(Path(row['path'])) == row, row['path']
    regular = [row for row in entries if 'sha256' in row]
    result = dict(status='passed', retired_regular_files=len(regular),
        retired_links=sum('link' in row for row in entries),
        retired_logical_bytes=sum(row['stat']['st_size'] for row in regular),
        plan_sha256=hashlib.sha256(PLAN.read_bytes()).hexdigest(),
        repeated_identity_checks=True, closed_handles=True, original_reports_unchanged=True,
        current_runtime_and_wheel_retained=True, no_payload_archive=True,
        available_bytes_after=shutil.disk_usage(O).free)
    with RESULT.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
