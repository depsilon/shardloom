"""Freeze release products with exact source and build receipt linkage."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/dependency-compatibility-batch/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('name')
parser.add_argument('receipt')
parser.add_argument('--composition-baseline', action='store_true')
args = parser.parse_args()
assert args.name.replace('-', '').isalnum() and '/' not in args.receipt


def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return dict(bytes=path.stat().st_size, sha256=digest.hexdigest())


receipt_path = OUT / args.receipt
receipt = json.loads(receipt_path.read_text())
assert receipt['status'] == 'passed' and receipt['returncode'] == 0
assert receipt['process_group_drained'] and receipt['cwd'] == str(ROOT)
assert receipt['command'] == ['cargo', 'build', '--locked', '--offline', '--profile', 'ci-native', '-p', 'shardloom-cli', '-p', 'shardloom-python',
    '--features', 'release-user-surfaces']
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head == receipt['head']
for relative, observed in receipt['changed_source_inventory'].items():
    if relative.endswith(('.rs', '.py', '.toml', '.lock')) and 'sha256' in observed:
        assert identity(ROOT / relative) == observed, relative

tracked = {path for path in subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT)
    .decode().split('\0') if path}
paths = tracked | {path for path in subprocess.check_output(
    ['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=ROOT).decode().split('\0') if path}
snapshot = {relative: identity(ROOT / relative) for relative in sorted(paths)
    if relative.endswith(('.rs', '.py', '.toml', '.lock')) and (ROOT / relative).is_file()}
if args.composition_baseline:
    assert head == 'ba3392501c7189b1a592f9075923ffb0f24061ec'
    allowed = {
        'shardloom-vortex/src/local_primitive_relational_batch_order_tests.rs',
        'shardloom-vortex/src/local_primitive_relational_batch_order_rich_prefix_tests.rs',
        'shardloom-vortex/src/local_primitive_relational_batch_order_projection_tests.rs',
    }
    tree = {}
    for entry in subprocess.check_output(['git', 'ls-tree', '-rz', head], cwd=ROOT).split(b'\0'):
        if entry:
            metadata, name = entry.split(b'\t', 1)
            tree[name.decode()] = metadata.split()[2].decode()
    for relative in snapshot:
        if relative in allowed:
            continue
        data = (ROOT / relative).read_bytes()
        git_digest = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert git_digest == tree[relative], relative

target = Path(receipt['environment']['CARGO_TARGET_DIR']) / 'ci-native'
destination = OUT / args.name
assert not destination.exists()
destination.mkdir()
products = {}
for source, name in ((target / 'shardloom', 'shardloom'), (target / 'lib_native.dylib', '_native.abi3.so')):
    assert source.is_file() and not source.is_symlink()
    observed = identity(source)
    shutil.copy2(source, destination / name)
    assert identity(destination / name) == identity(source) == observed
    products[name] = observed
patch = subprocess.check_output(['git', 'diff', '--binary', 'HEAD'], cwd=ROOT)
(destination / 'source-overlay.patch').write_bytes(patch)
manifest = dict(schema_version='shardloom.shared_performance_runtime.v1', profile='ci-native',
    features=['release-user-surfaces'], source_revision=head, source_snapshot=snapshot,
    composition_production_baseline=args.composition_baseline,
    baseline_test_only_changes=sorted(allowed) if args.composition_baseline else [],
    build_receipt=receipt_path.name, build_receipt_sha256=identity(receipt_path)['sha256'],
    files=products, products={name: row['sha256'] for name, row in products.items()},
    source_overlay=identity(destination / 'source-overlay.patch'),
    untracked_source_paths=sorted(path for path in snapshot if path not in tracked))
with (destination / 'manifest.json').open('x') as stream:
    json.dump(manifest, stream, indent=2)
    stream.write('\n')
assert all(identity(ROOT / relative) == observed for relative, observed in snapshot.items())
print(json.dumps(dict(status='frozen', runtime=str(destination), files=products,
    source_files=len(snapshot), composition_production_baseline=args.composition_baseline)))
