"""Retire superseded local table products and a guard-stopped freeze's copies."""
import hashlib
import json
import lzma
from pathlib import Path
import shutil
import tarfile

from retire_adaptive_decisions_payloads import identity, verify, closed

O = Path(__file__).resolve().parents[1]
T = Path('/Users/dylan/.codex/worktrees/native-local-table-readers/shardloom-local-repo')
PLAN = O / 'local-table-completed-payload-retirement-plan.json.xz'
RESULT = O / 'local-table-completed-payload-retirement.json'


def main():
    assert not PLAN.exists() and not RESULT.exists()
    proofs, retained, files, roots = [], [], [], []
    archived = {}
    for name in ('native-local-table-readers-2026-11-02', 'native-local-table-reader-review-2026-11-02'):
        packet = T / 'docs/benchmarks/evidence' / name
        acceptance_path = packet / 'acceptance.json'
        acceptance = json.loads(acceptance_path.read_text())
        assert acceptance['status'] in {'local_acceptance_passed', 'local_review_acceptance_passed'}
        proofs.append(identity(acceptance_path))
        archive = packet / acceptance['archive']['path']
        proofs.append(verify(archive, acceptance['archive']))
        with tarfile.open(archive, 'r:xz') as bundle:
            members = bundle.getmembers()
            expected = acceptance['archive']['member_identities']
            assert len(members) == len(expected)
            assert {member.name for member in members} == set(expected)
            for member in members:
                assert member.isfile()
                data = bundle.extractfile(member).read()
                assert len(data) == expected[member.name]['bytes']
                assert hashlib.sha256(data).hexdigest() == expected[member.name]['sha256']
                archived[member.name] = expected[member.name]

    current = O / 'io-runtime-local-tables-r5'
    manifest = json.loads((current / 'manifest.json').read_text())
    proofs.append(identity(current / 'manifest.json'))
    assert manifest['source_revision'] == '00d504960499c4f18ba7c59ce956f7710ea58874'
    for name, expected in manifest['files'].items():
        retained.append(verify(current / name, expected))
    package = O / 'installed-wheel-local-tables-r2'
    report = json.loads((package / 'report.json').read_text())
    assert report['status'] == report['uninstall_status'] == 'passed'
    assert report['integration'] == dict(tests=299, failures=0, errors=0, skipped=0, status='passed')
    for name, key in [('shardloom', 'cli_sha256'), ('_native.abi3.so', 'native_library_sha256')]:
        assert report['stage'][key] == manifest['files'][name]['sha256']
    retained.append(verify(package / 'dist' / report['integrity']['wheel'],
        dict(bytes=report['integrity']['wheel_bytes'], sha256=report['integrity']['wheel_sha256'])))

    for revision in range(1, 5):
        runtime = O / f'io-runtime-local-tables-r{revision}'
        old = json.loads((runtime / 'manifest.json').read_text())
        for filename in ('manifest.json', 'source-overlay.patch'):
            path = runtime / filename
            proofs.append(verify(path, archived[str(path.relative_to(O))]))
        build_path = O / old['build_receipt']
        build = json.loads(build_path.read_text())
        assert build['status'] == 'passed' and build['returncode'] == 0 and build['process_group_drained']
        assert hashlib.sha256(build_path.read_bytes()).hexdigest() == old['build_receipt_sha256']
        proofs.append(identity(build_path))
        for filename, expected in old['files'].items():
            assert filename in {'shardloom', '_native.abi3.so'}
            files.append(verify(runtime / filename, expected))

    for revision in (1, 2):
        package = O / f'installed-wheel-local-tables-r{revision}'
        old = json.loads((package / 'report.json').read_text())
        assert old['status'] == old['uninstall_status'] == 'passed'
        for path in sorted(package.iterdir()):
            if path.is_file() and path.suffix in {'.log', '.json'}:
                proofs.append(verify(path, archived[str(path.relative_to(O))]))
        for child in ('package', 'venv'):
            path = package / child
            assert path.is_dir() and not path.is_symlink()
            roots.append(path)
        if revision == 1:
            files.append(verify(package / 'dist' / old['integrity']['wheel'],
                dict(bytes=old['integrity']['wheel_bytes'], sha256=old['integrity']['wheel_sha256'])))

    stopped = O / 'io675-dependency-freeze.json'
    failed = json.loads(stopped.read_text())
    assert failed['status'] == 'failed' and failed['process_group_drained']
    assert 'minimum free storage reached' in failed['error']
    proofs.append(identity(stopped))
    build_path = O / 'io674-dependency-cli-python-build.json'
    build = json.loads(build_path.read_text())
    assert build['status'] == 'passed' and build['returncode'] == 0 and build['process_group_drained']
    proofs.append(identity(build_path))
    partial = O / 'io-runtime-dependency-batch-r1'
    assert {path.name for path in partial.iterdir()} == {'shardloom', '_native.abi3.so'}
    for filename, cache_name in [('shardloom', 'shardloom'), ('_native.abi3.so', 'lib_native.dylib')]:
        cache = Path(build['environment']['CARGO_TARGET_DIR']) / 'ci-native' / cache_name
        cache_identity = identity(cache)
        expected = dict(bytes=cache_identity['stat']['st_size'], sha256=cache_identity['sha256'])
        proofs.append(cache_identity)
        files.append(verify(partial / filename, expected))

    entries = []
    for root in roots:
        assert root.resolve() == root and root.is_relative_to(O)
        entries.extend(identity(path) for path in [root, *sorted(root.rglob('*'))])
    assert len({row['path'] for row in [*entries, *files]}) == len(entries) + len(files)
    file_paths = [Path(row['path']) for row in files]
    closed(roots, file_paths)
    plan = dict(status='declared_before_retirement', roots=list(map(str, roots)), entries=entries,
        files=files, proofs=proofs, retained_runtime_and_wheel=retained,
        scope='Superseded table runtimes r1-r4, old table wheel r1, completed r1/r2 package/venv trees, '
              'and partial dependency freeze copies. Current table r5 runtime/r2 wheel, current adaptive '
              'runtime/input, dependency build products, all original observations and source proofs remain.',
        regeneration_basis='Original successful build/package receipts and exact archived source identities/overlays.',
        no_payload_archive=True, hosted_table_acceptance='still pending; no current product retired')
    raw = json.dumps(plan, sort_keys=True, separators=(',', ':')).encode()
    with lzma.open(PLAN, 'xb') as stream:
        stream.write(raw)
    with lzma.open(PLAN, 'rb') as stream:
        assert stream.read() == raw
    for row in [*entries, *files, *proofs, *retained]:
        assert identity(Path(row['path'])) == row, row['path']
    closed(roots, file_paths)
    for row in files:
        path = Path(row['path'])
        assert identity(path) == row
        path.unlink()
    for root in roots:
        shutil.rmtree(root)
    assert all(not path.exists() for path in [*roots, *file_paths])
    for row in [*proofs, *retained]:
        assert identity(Path(row['path'])) == row, row['path']
    regular = [row for row in [*entries, *files] if 'sha256' in row]
    result = dict(status='passed', retired_regular_files=len(regular),
        retired_links=sum('link' in row for row in entries),
        retired_logical_bytes=sum(row['stat']['st_size'] for row in regular),
        plan_sha256=hashlib.sha256(PLAN.read_bytes()).hexdigest(),
        repeated_identity_checks=True, closed_handles=True, original_reports_unchanged=True,
        no_input_or_observation_retirement=True, no_payload_archive=True,
        available_bytes_after=shutil.disk_usage(O).free)
    with RESULT.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
