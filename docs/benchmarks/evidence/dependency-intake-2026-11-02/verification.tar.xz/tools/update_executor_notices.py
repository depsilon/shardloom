"""Verify the exact replacement executor archive and retain its unchanged legal texts."""
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import tarfile
import tomllib

D = Path('/Users/dylan/.codex/worktrees/dependency-compatibility-batch/shardloom-local-repo')
O = Path(__file__).resolve().parents[1]
INTAKE = O / 'dependency-license-intake/async-executor-1.14.1'
BUNDLE = D / 'python/THIRD_PARTY_LICENSES'
CHECKSUM = 'f426a31126c735126297bc5ea7a521263c9faff4f63ca415267ee625651c4f37'
OLD_CHECKSUM = 'c96bf972d85afc50bf5ab8fe2d54d1586b4e0b46c97c50a0c9e71e2f7bcd812a'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    result = INTAKE / 'bundle-verification.json'
    assert not result.exists()
    archive = INTAKE / 'async-executor-1.14.1.crate'
    assert archive.is_file() and not archive.is_symlink()
    assert sha(archive.read_bytes()) == CHECKSUM
    cached = Path('/Users/dylan/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f/async-executor-1.14.1.crate')
    assert cached.read_bytes() == archive.read_bytes()
    old_source = Path('/Users/dylan/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/async-executor-1.14.0')
    report = json.loads((INTAKE / 'report.json').read_text())
    manifest_path = BUNDLE / 'manifest.json'
    before = manifest_path.read_bytes()
    assert sha(before) == 'c106fe58b35255c4de304506265a3a6d4fd642dc6570d32fc4cc28d529d645fc'
    manifest = json.loads(before)
    rows = [p for p in manifest['components'] if p['name'] == 'async-executor']
    assert len(rows) == 1
    component = rows[0]
    assert component['version'] == '1.14.0' and component['crate_checksum_sha256'] == OLD_CHECKSUM
    prefix = 'async-executor-1.14.1/'
    verified = []
    with tarfile.open(archive, 'r:gz') as bundle:
        members = bundle.getmembers()
        assert len({m.name for m in members}) == len(members)
        assert [{'name': m.name, 'type': 'regular' if m.isfile() else 'other', 'size_bytes': m.size}
                for m in members] == report['archive_member_inventory']
        for member in members:
            assert member.isfile() and member.name.startswith(prefix)
            assert '..' not in PurePosixPath(member.name).parts and member.size < 1 << 20
        legal = [m for m in members if PurePosixPath(m.name).name.upper().startswith(
            ('LICENSE', 'UNLICENSE', 'NOTICE', 'COPYING', 'COPYRIGHT'))]
        assert sorted(m.name for m in legal) == [prefix + 'LICENSE-APACHE', prefix + 'LICENSE-MIT']
        assert {f['crate_path'] for f in component['files']} == {'LICENSE-APACHE', 'LICENSE-MIT'}
        for item in report['metadata_files']:
            name = item['filename']
            raw = bundle.extractfile(prefix + name).read()
            assert raw == (INTAKE / 'selected' / name).read_bytes()
            assert sha(raw) == item['1_14_1']['sha256'] and len(raw) == item['1_14_1']['size_bytes']
            verified.append({'name': name, 'sha256': sha(raw), 'bytes': len(raw)})
        for filename in ('Cargo.toml', 'Cargo.toml.orig'):
            current = tomllib.loads(bundle.extractfile(prefix + filename).read().decode())
            prior = tomllib.loads((old_source / filename).read_text())
            assert current['package']['version'] == '1.14.1'
            assert current['package']['rust-version'] == '1.63'
            assert current['package']['license'] == component['license'] == 'Apache-2.0 OR MIT'
            assert current['package']['repository'] == component['repository']
            prior['package']['version'] = '1.14.1'
            prior['package']['rust-version'] = '1.63'
            assert current == prior, filename
        vcs = json.loads(bundle.extractfile(prefix + '.cargo_vcs_info.json').read())
        assert vcs['git']['sha1'] == report['archived_vcs_revision'] == 'a75cad623bd5c6c80ab19a5befb3d9b93a79bfcd'
        for item in component['files']:
            raw = bundle.extractfile(prefix + item['crate_path']).read()
            assert raw == (BUNDLE / item['text']).read_bytes() == (old_source / item['crate_path']).read_bytes()
            assert sha(raw) == item['sha256'] and len(raw) == item['bytes']
    locked = [p for p in tomllib.loads((D / 'Cargo.lock').read_text())['package'] if p['name'] == 'async-executor']
    assert len(locked) == 1 and locked[0]['version'] == '1.14.1' and locked[0]['checksum'] == CHECKSUM
    component['version'] = '1.14.1'
    component['crate_checksum_sha256'] = CHECKSUM
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')
    spec = importlib.util.spec_from_file_location('notices', D / 'scripts/check_python_license_bundle.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    proof = module.verify(D)
    proof.update(before_manifest_sha256=sha(before), manifest_sha256=sha(manifest_path.read_bytes()),
        archive_sha256=CHECKSUM, archive_bytes=archive.stat().st_size, vcs_revision=vcs['git']['sha1'],
        legal_texts_unchanged=True, other_components_unchanged=True, verified_files=verified,
        dependency_declarations_unchanged=True, rust_version='1.63')
    result.write_text(json.dumps(proof, indent=2) + '\n')
    print(json.dumps(proof))


if __name__ == '__main__':
    main()
