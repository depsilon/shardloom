"""Retire completed test executables after a storage refusal; preserve frozen products."""
import hashlib
import json
import lzma
from pathlib import Path
import re
import shutil
import subprocess
import sys

from retire_completed_test_executables import identity
from retire_adaptive_decisions_payloads import verify as verify_file

O = Path(__file__).resolve().parents[1]
D = Path('/Users/dylan/.codex/worktrees/dependency-compatibility-batch/shardloom-local-repo')
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
sys.path[:0] = [str(D / 'scripts'), '/Users/dylan/LocalData/shardloom/release-0.3.3-20260930']
from release_validation_guard import WorkloadGuard

PLAN = O / 'dependency-completed-test-cache-retirement-plan.json.xz'
RESULT = O / 'dependency-completed-test-cache-retirement.json'
SPECS = (
    (657, 'ci-native', 'io-runtime-local-tables-r5'),
    (692, 'ci-native', 'io-runtime-dependency-batch-r4'),
    (659, 'debug', 'io-runtime-local-tables-r5'),
    (704, 'debug', 'io-runtime-dependency-batch-r4'),
)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def closed(paths):
    result = subprocess.run(['/usr/sbin/lsof', '-nP', '-Fpn', '--', *map(str, paths)],
        capture_output=True, text=True, timeout=45)
    assert result.returncode == 1 and not result.stdout and not result.stderr, result
    commands = subprocess.check_output(['ps', '-axo', 'command'], text=True)
    assert all(str(path) not in commands for path in paths)


def collect(number, profile, runtime_name):
    matches = list(O.glob(f'io{number}-*.json'))
    assert len(matches) == 1
    receipt_path = matches[0]
    receipt = json.loads(receipt_path.read_text())
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained']
    assert receipt['command'][:2] == ['cargo', 'test']
    root = Path(receipt['cwd'])
    assert root.name == 'shardloom-local-repo'
    assert root.parent.name in {'native-local-table-readers', 'dependency-compatibility-batch'}
    raw_log = receipt_path.with_suffix('.log').read_bytes()
    assert sha(raw_log) == receipt['log_sha256']
    runtime_path = O / runtime_name / 'manifest.json'
    snapshot = json.loads(runtime_path.read_text())['source_snapshot']
    rows = []
    for label, value in re.findall(r'Running ([^\n]+?) \(([^)]+)\)', raw_log.decode()):
        if label != 'unittests src/lib.rs' and not label.startswith('tests/'):
            continue
        path = Path(value)
        dependency = path.with_suffix('.d')
        if (path.parent != CACHE / profile / 'deps' or not path.is_file()
                or path.is_symlink() or not dependency.is_file() or dependency.is_symlink()):
            continue
        stat = path.stat()
        if not stat.st_mode & 0o111 or max(stat.st_mtime_ns, dependency.stat().st_mtime_ns) > receipt_path.stat().st_mtime_ns:
            continue
        raw_dependency = dependency.read_bytes()
        first_rule = raw_dependency.decode().splitlines()[0]
        assert first_rule.startswith(str(dependency) + ': ')
        relative = first_rule.split(': ', 1)[1].split()[0]
        source = root / relative
        if Path(relative).is_absolute() or not relative.endswith('.rs'):
            continue
        if not source.is_file() or source.is_symlink() or not source.resolve().is_relative_to(root):
            continue
        raw_source = source.read_bytes()
        source_identity = dict(bytes=len(raw_source), sha256=sha(raw_source))
        if snapshot.get(relative) != source_identity:
            continue
        rows.append(dict(path=str(path), bytes=stat.st_size, mtime_ns=stat.st_mtime_ns, inode=stat.st_ino,
            receipt=receipt_path.name, receipt_sha256=sha(receipt_path.read_bytes()),
            log_sha256=receipt['log_sha256'], dependency=str(dependency), dependency_sha256=sha(raw_dependency),
            source_worktree=str(root), source_relative_path=relative, source_identity=source_identity,
            runtime_manifest=str(runtime_path), runtime_manifest_sha256=sha(runtime_path.read_bytes()),
            regeneration_command=receipt['command']))
    return rows


def main():
    assert not PLAN.exists() and not RESULT.exists()
    guard = WorkloadGuard()
    guard.check()
    failed = json.loads((O / 'io706-dependency-executor-native-workspace.json').read_text())
    assert failed['status'] == 'failed' and failed['process_group_drained'] and failed['direct_child_reaped']
    assert 'minimum free storage' in failed['error']
    rows = [row for spec in SPECS for row in collect(*spec)]
    native = {row['path']: row for row in rows if '/ci-native/' in row['path']}
    candidates_path = O / 'dependency-completed-test-cache-candidates-r2.json'
    candidates = json.loads(candidates_path.read_text())['candidates']
    assert set(native) == {row['path'] for row in candidates}
    for expected in candidates:
        actual = native[expected['path']]
        for left, right in [('bytes', 'size_bytes'), ('mtime_ns', 'mtime_ns'), ('inode', 'inode'),
                            ('dependency_sha256', 'dependency_file_sha256'),
                            ('runtime_manifest_sha256', 'runtime_manifest_sha256')]:
            assert actual[left] == expected[right], expected['path']
        assert actual['source_identity'] == dict(bytes=expected['source_bytes'], sha256=expected['source_sha256'])
    by_path = {row['path']: row for row in rows}
    assert 214 <= len(by_path) <= 430
    paths = list(map(Path, sorted(by_path)))
    records = [dict(identity(path), provenance=by_path[str(path)]) for path in paths]
    assert all(row['links'] == 1 for row in records)
    preserved = []
    for runtime_name, wheel_name in [('io-runtime-local-tables-r5', 'installed-wheel-local-tables-r2'),
                                    ('io-runtime-dependency-batch-r4', 'installed-wheel-dependency-batch-r2')]:
        runtime = O / runtime_name
        manifest = json.loads((runtime / 'manifest.json').read_text())
        for filename, expected in manifest['files'].items():
            preserved.append(verify_file(runtime / filename, expected))
        wheel_root = O / wheel_name
        report = json.loads((wheel_root / 'report.json').read_text())
        assert report['status'] == report['uninstall_status'] == 'passed'
        wheel = report['integrity']
        preserved.append(verify_file(wheel_root / 'dist' / wheel['wheel'], dict(
            bytes=wheel['wheel_bytes'], sha256=wheel['wheel_sha256'])))
    closed(paths)
    plan = dict(status='declared_before_retirement', files=records, preserved=preserved,
        candidates_sha256=sha(candidates_path.read_bytes()),
        scope='Only completed default/native test executables from exact successful receipts; '
              'no compiler libraries, source, current frozen runtime/wheel, inputs or result files.',
        regeneration='Recorded receipt commands and exact source snapshots; no binary payload archive.',
        no_payload_archive=True, blocked_build_receipt='io706-dependency-executor-native-workspace.json')
    raw = json.dumps(plan, sort_keys=True, separators=(',', ':')).encode()
    assert len(raw) < 4 << 20
    with lzma.open(PLAN, 'xb') as stream:
        stream.write(raw)
    with lzma.open(PLAN, 'rb') as stream:
        assert stream.read() == raw
    guard.check()
    closed(paths)
    for row in records:
        assert identity(Path(row['path'])) == {key: value for key, value in row.items() if key != 'provenance'}
        p = row['provenance']
        assert sha(Path(p['dependency']).read_bytes()) == p['dependency_sha256']
    result = dict(status='running', retired=[], available_bytes_before=shutil.disk_usage(O).free)
    try:
        for row in records:
            path = Path(row['path'])
            stat = path.stat()
            assert all(getattr(stat, key) == value for key, value in row['generation'].items())
            path.unlink()
            result['retired'].append(row['path'])
        assert all(not path.exists() for path in paths)
        for row in preserved:
            verify_file(Path(row['path']), dict(bytes=row['stat']['st_size'], sha256=row['sha256']))
        result.update(status='passed', retired_regular_files=len(records),
            retired_logical_bytes=sum(row['bytes'] for row in records),
            plan_sha256=sha(PLAN.read_bytes()), repeated_identity_checks=True, closed_handles=True,
            frozen_runtime_and_wheel_retained=True, original_observations_retained=True,
            no_payload_archive=True, available_bytes_after=shutil.disk_usage(O).free)
    finally:
        with RESULT.open('x') as stream:
            json.dump(result, stream, indent=2)
            stream.write('\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'retired'}))


if __name__ == '__main__':
    main()
