# ADBC 0.25.0 cancellation source inventory

Read-only comparison of local Cargo registry sources for the dependency-intake diagnosis. Paths and line numbers below refer to the exact registry files. SHA-256 identities are recorded to make the compared inputs explicit.

## Source identities

| File | SHA-256 |
|---|---|
| `/Users/dylan/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/adbc_core-0.24.0/src/lib.rs` | `d6b7aa17eab267dd8d4f1545278ccc328eb2e70aa35732ae19a0f6857a01e419` |
| `/Users/dylan/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/adbc_core-0.25.0/src/lib.rs` | `d6b7aa17eab267dd8d4f1545278ccc328eb2e70aa35732ae19a0f6857a01e419` |
| `/Users/dylan/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/adbc_core-0.24.0/src/sync.rs` | `b267d1ebeda4b682b32aa7da3fd01296a83d9fa99732cbcbdf223281b9d64aee` |
| `/Users/dylan/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/adbc_core-0.25.0/src/sync.rs` | `c84bf5d6c1e48a69e4ca3110905852bc281d299e08bd15c863c3ad7e1fdc5d27` |
| `/Users/dylan/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/adbc_ffi-0.24.0/src/driver_exporter.rs` | `eee3aa93dbead5b647a069f88072c5dc11a3faf13f7c3cfbf195e326a1cc64b4` |
| `/Users/dylan/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/adbc_ffi-0.25.0/src/driver_exporter.rs` | `01c90ed6cc68044785eac47be6af4fb21ac0fc93eb6b015eb1d22d09ec9214f0` |

The requested `adbc_core/src/lib.rs` files are byte-identical. The cancellation trait APIs are defined in `src/sync.rs`, so that companion source was also compared.

## Core cancellation API delta (`adbc_core/src/sync.rs`)

- 0.25.0 lines 52–55 add `pub trait CancelHandle: Send + Sync { fn try_cancel(&self) -> Result<()>; }`.
- 0.25.0 lines 58–67 add `NoOpCancellationHandle`; its `try_cancel` returns `Error::with_message_and_status("cancellation not implemented", Status::Unknown)`.
- Database: `Database::get_cancel_handle(&self) -> Box<dyn CancelHandle>` default is added at lines 102–105.
- Connection: `cancel(&mut self)` becomes a deprecated default forwarding to `self.get_cancel_handle().try_cancel()` (lines 124–128); `get_cancel_handle(&self)` defaulting to the no-op handle is added at lines 130–133.
- Statement: `cancel(&mut self)` becomes a deprecated default forwarding to `self.get_cancel_handle().try_cancel()` (lines 493–497); `get_cancel_handle(&self)` defaulting to the no-op handle is added at lines 499–509.
- In 0.24.0, Connection and Statement instead required implementors to provide `cancel(&mut self) -> Result<()>` (Connection lines 97–98; Statement lines 458–466); Database gains an optional cancellation-handle default.

## FFI exporter wiring delta (`adbc_ffi/src/driver_exporter.rs`)

- 0.25.0 imports `std::sync::Mutex` (line 22) and changes exported database/connection/statement storage to mutex-backed state (lines 43–145). `FFIDriver` now requires database, connection, and statement associated types to be `Send` (lines 151–156).
- `InitializedConnection` stores both `connection: Mutex<ConnectionType<DriverType>>` and `cancel_handle: Box<dyn adbc_core::CancelHandle>` (lines 75–78). During `connection_init`, exporter obtains `connection.get_cancel_handle()` before storing connection (lines 1011–1017).
- `ExportedStatement` stores `stmt: Mutex<StatementType<DriverType>>` and `cancel: Box<dyn adbc_core::CancelHandle>` (lines 134–145). In `statement_new`, after `new_statement()`, exporter obtains `inner_statement.get_cancel_handle()` and stores it with the mutex-wrapped statement (lines 1563–1571).
- C ABI table continues to wire `ConnectionCancel: Some(connection_cancel::<DriverType>)` and `StatementCancel: Some(statement_cancel::<DriverType>)` (lines 198, 208). These exported function targets existed in 0.24.0 as well.
- Changed connection cancellation target implementation: 0.24.0 `connection_cancel` calls `connection.cancel()` (0.24 file lines 1216–1229); 0.25.0 calls `exported.try_cancel()` then `handle.try_cancel()` (0.25 lines 1357–1373). `try_cancel` returns the retained connection cancel handle (lines 123–130).
- Changed statement cancellation target implementation: 0.24.0 `statement_cancel` calls `statement.cancel()` (0.24 lines 1677–1693); 0.25.0 calls the retained `exported.cancel.try_cancel()` without acquiring the statement mutex (0.25 lines 1827–1842).
- The rest of the exporter broadly migrates getters/setters/execution methods from mutable references to mutex guards. Those are synchronization/storage changes; this inventory does not infer their runtime impact on ShardLoom.

## ShardLoom implementation touchpoints

In the inspected worktree, `shardloom-python/src/adbc_connection.rs` implements `Connection` for `LocalConnection` at lines 47–55, including `new_statement` and legacy `cancel(&mut self)` that calls Python bridge `cancel`.

`shardloom-python/src/adbc_statement.rs` implements `Statement` for `LocalStatement` at lines 93 onward. It defines `execute` at 120–147, and legacy `cancel(&mut self)` at 207–212; that method calls `cancel` on the stored stream when present.

The driver implementation is in `shardloom-python/src/adbc.rs`, not a file named `adbc_driver.rs`: `LocalDriver` implements `Driver` at lines 146–161, and `LocalDatabase` is declared at 142–144. The newly added Database `get_cancel_handle` method has a default, so that implementation does not need to define it merely to satisfy its trait. The inspected Connection/Statement legacy `cancel` methods remain valid trait methods but are deprecated; with no explicit `get_cancel_handle` override in the cited implementations, the core default handle is the no-op handle that returns `Status::Unknown`.

This inventory reports source-level differences only. It does not establish the precise failing test path, concurrency behavior, nor a fix.
