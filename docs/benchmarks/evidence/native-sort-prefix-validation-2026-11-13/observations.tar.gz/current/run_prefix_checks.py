"""Run complete prefix source checks under the existing workload guards."""
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
CHECKS = [
    ('prefix-fmt-r1', 2400, ['cargo', 'fmt', '--all', '--', '--check']),
    ('prefix-default-clippy-r1', 2400,
     ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('prefix-native-clippy-r1', 2400,
     ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets',
      '--features', 'python-native,native-encoded-exchange-experiment', '--', '-D', 'warnings']),
    ('prefix-default-tests-r1', 7200,
     ['cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets']),
    ('prefix-native-tests-r1', 7200,
     ['cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets',
      '--features', 'python-native,native-encoded-exchange-experiment']),
]

if __name__ == '__main__':
    for name, timeout, command in CHECKS:
        print(name, flush=True)
        subprocess.run([sys.executable, '-B', str(OUT / 'guard_checks.py'), '--name', name,
                        '--timeout', str(timeout), '--', *command], check=True)
