"""Reuse the established bounded correctness/build supervisor for this work unit."""
import importlib.util
from pathlib import Path

path = Path('/Users/dylan/LocalData/shardloom/native-pipeline-sql-minute-2026-11-13/guard_checks.py')
spec = importlib.util.spec_from_file_location('coverage_check_guard', path)
guard = importlib.util.module_from_spec(spec)
spec.loader.exec_module(guard)
guard.OUT = Path('/Users/dylan/LocalData/shardloom/native-optimization-coverage-2026-11-13')

if __name__ == '__main__':
    raise SystemExit(guard.main())
