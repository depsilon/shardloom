"""Check complete prefix suites and installed artifacts against frozen expectations."""
import json
from pathlib import Path
import re

from prefix_runtime import CHECKS, EXPECTATIONS, MANIFEST, OUT, VALIDATION, identity, read, sources, verify

assert __debug__ and not VALIDATION.exists()
expectations_identity = identity(EXPECTATIONS)
expectations = read(EXPECTATIONS)
assert identity(EXPECTATIONS) == expectations_identity
assert set(expectations) == {'default', 'native', 'native_library', 'required_new_tests', 'installed'}
for key in ('default', 'native'):
    assert set(expectations[key]) == {'passed', 'failed', 'ignored', 'test_binaries'}
    assert all(type(value) is int and value >= 0 for value in expectations[key].values())
    assert expectations[key]['failed'] == 0
assert expectations['default'] == dict(passed=3325, failed=0, ignored=0, test_binaries=108)
assert expectations['native']['passed'] > 0
assert expectations['native']['ignored'] == 39 and expectations['native']['test_binaries'] == 120
assert set(expectations['native_library']) == {'passed', 'failed', 'ignored'}
assert all(type(value) is int and value >= 0 for value in expectations['native_library'].values())
assert expectations['native_library']['passed'] > 0
assert expectations['native_library']['failed'] == 0 and expectations['native_library']['ignored'] == 36
assert isinstance(expectations['required_new_tests'], list)
assert expectations['required_new_tests']
assert all(isinstance(name, str) and name for name in expectations['required_new_tests'])
assert len(expectations['required_new_tests']) == len(set(expectations['required_new_tests']))
assert set(expectations['installed']) == {'tests', 'failures', 'errors', 'skipped', 'status'}
assert expectations['installed'] == dict(tests=442, failures=0, errors=0, skipped=0, status='passed')
assert all(type(expectations['installed'][key]) is int and expectations['installed'][key] >= 0
           for key in ('tests', 'failures', 'errors', 'skipped'))

manifest = read(MANIFEST)
build = read(OUT / manifest['build_receipt'])
assert manifest['status'] == build['status'] == 'passed'
assert build['source_files'] == sources()
checks = {}
for name in sorted(CHECKS):
    path = OUT / name
    check = read(path)
    assert check['status'] == 'passed' and check['returncode'] == 0, name
    assert check['sources_unchanged'] and check['process_group_drained'] and check['direct_child_reaped'], name
    assert check['source_files'] == build['source_files'], name
    checks[name] = identity(path)

counts = {}
for name, kind in (('prefix-default-tests-r1', 'default'), ('prefix-native-tests-r1', 'native')):
    text = (OUT / 'logs' / (name + '.log')).read_text()
    rows = [tuple(map(int, row)) for row in re.findall(
        r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored', text)]
    total = tuple(sum(row[index] for row in rows) for index in range(3))
    expected = expectations[kind]
    assert total == (expected['passed'], expected['failed'], expected['ignored']), (kind, total)
    assert len(rows) == expected['test_binaries'], (kind, len(rows))
    if kind == 'native':
        library = expectations['native_library']
        library_total = library['passed'] + library['ignored']
        assert f'running {library_total} tests' in text, 'full native library inventory differs'
        assert (library['passed'], library['failed'], library['ignored']) in rows, \
            'full native library result row differs from frozen expectations'
        assert '109 passed; 0 failed' not in text, 'focused group is not the complete suite'
        for test_name in (
            'source_demand_tests::sort_tests::parquet_demand_sort_keeps_hidden_keys_and_skips_unused_corrupt_payload',
            'source_demand_tests::sort_tests::parquet_demand_sort_rebinds_raw_vector_field_observation_after_pruning',
            'cardinality_tests::parquet_demand_cardinality_does_not_read_an_unneeded_row_carrier',
            'cardinality_tests::parquet_demand_explode_keeps_all_zip_lists_and_hidden_predicates_for_count',
            'cardinality_tests::parquet_demand_unary_explicit_inputs_keep_hidden_predicates_without_output_leakage',
        ):
            assert any(line.startswith('test ') and line.rstrip().endswith(f'::{test_name} ... ok')
                       for line in text.splitlines()), test_name
        for test_name in (
            'file_sort_kernel_preserves_hidden_and_outside_prefix_payload_errors',
            'projection_before_sort_retains_file_kernel_with_unobserved_source_payload',
            'text_order_keys_retain_file_kernel_with_integer_payload',
            'sort_payload_validation_respects_prior_filter_and_nulls',
            'sort_preserves_validation_of_hidden_nested_payload',
            'sort_preserves_validation_of_hidden_text_payload',
        ):
            assert any(line.startswith('test ') and line.rstrip().endswith(f'::{test_name} ... ok')
                       for line in text.splitlines()), test_name
        for test_name in expectations['required_new_tests']:
            assert any(line.startswith('test ') and line.rstrip().endswith(f'::{test_name} ... ok')
                       for line in text.splitlines()), test_name
    counts[name] = dict(passed=total[0], failed=total[1], ignored=total[2], test_binaries=len(rows))

installed = read(OUT / 'prefix-installed-wheel-r1/report.json')
integration = read(OUT / 'prefix-installed-wheel-r1/integration.json')
assert installed['status'] == integration['status'] == 'passed'
assert integration == expectations['installed']
assert installed['integrity']['native_library_sha256'] == identity(OUT/'prefix-runtime-r1/_native.abi3.so')['sha256']
assert installed['integrity']['cli_sha256'] == identity(OUT/'prefix-runtime-r1/shardloom')['sha256']
assert not installed['publication_attempted']
assert identity(EXPECTATIONS) == expectations_identity
record = dict(status='passed', source_commit=manifest['source_commit'],
    source_tree=manifest['source_tree'], runtime=identity(MANIFEST),
    expectations=expectations_identity, checks=checks,
    installed_checks={name:identity(OUT/name) for name in (
        'prefix-installed-wheel-r1/report.json', 'prefix-installed-wheel-r1/integration.json')},
    native_validation_scope='full_workspace_all_targets_default_and_native',
    full_native_library_suite_completed=True, test_counts=counts,
    installed_python_tests=integration, benchmark_executions=0)
with VALIDATION.open('x') as output:
    json.dump(record, output, indent=2); output.write('\n')
proof = verify()
print(json.dumps(dict(status='passed', source_commit=proof['head'], test_counts=counts)))
