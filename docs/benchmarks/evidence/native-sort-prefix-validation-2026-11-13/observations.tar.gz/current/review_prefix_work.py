"""Compare saved work, resources and engine clocks with the one frozen current baseline."""
from collections import Counter, defaultdict
import gzip
import hashlib
import json
import math
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
DEST = OUT/'prefix-work-review-r1.json'
COHORT = OUT/'prefix-sort-cohort-r1.json'
BASELINE = '4d5fa4a46268380a634e78f057abba087f4042f5'


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def rows(path):
    with gzip.open(path, 'rt') as stream:
        return [json.loads(line) for line in stream]


def counters(fields):
    pairs = re.findall(r'(?:^|[ ;])([a-z][a-z0-9_]*)=([0-9]+)(?=$|[ ;])',
        fields['local_primitive_native_io_pushdown_proof_basis'])
    assert len(pairs) == len(dict(pairs))
    result = {'proof.'+key:int(value) for key,value in pairs}
    result.update({'report.'+key:int(value) for key,value in fields.items()
                   if re.fullmatch(r'[0-9]+',str(value))})
    return result


def main():
    assert __debug__ and not DEST.exists()
    frozen = json.loads(COHORT.read_bytes())
    assert frozen['status'] == 'frozen_candidate_current_baseline_bound'
    assert frozen['case_count'] == 388 and frozen['query_executions'] == 0
    assert frozen['baseline_source_commit'] == BASELINE
    assert frozen['current_baseline_engine_seconds'] == 337.804658081
    summary_path = OUT/'prefix-cohort-r1/verified-summary-r1.json'
    summary = json.loads(summary_path.read_bytes())
    assert summary['status'] == 'passed_offline_replay' and summary['successful_cases'] == 388
    assert summary['unsuccessful_cases'] == 0 and summary['query_executions'] == 0
    current = rows(OUT/'prefix-cohort-r1/verified-cases-r1.jsonl.gz')
    certificates = rows(OUT/'prefix-cohort-r1/certificate-cases-r1.jsonl.gz')
    assert len(current) == len(certificates) == len(frozen['cases']) == 388
    groups, changes, details = defaultdict(Counter), Counter(), []
    baseline_clocks, candidate_clocks = [], []
    for seq, (case, certificate, declared) in enumerate(zip(current, certificates, frozen['cases'])):
        baseline = declared['current_baseline']
        assert baseline['source_commit'] == BASELINE
        assert baseline['source_tree'] == frozen['baseline_source_tree']
        assert baseline['status'] == baseline['certificate']['status'] == 'passed'
        assert baseline['certificate']['engine_timing_reported'] is True
        group = declared['historical_classification_group']
        assert case['seq'] == certificate['seq'] == declared['candidate_order'] == seq
        assert case['id'] == certificate['id'] == declared['declaration']['id']
        assert case['case_identity'] == declared['case_identity'] == declared['declaration']['case_identity']
        assert case['comparison_group'] == group
        assert case['previous_source_commit'] == baseline['source_commit'] == BASELINE
        before = baseline['engine_execution_seconds']
        after = certificate['engine_seconds']
        assert before == baseline['certificate']['engine_seconds'] == case['previous_engine_seconds']
        assert after == case['current']['engine_seconds']
        assert case['current']['status'] == certificate['status'] == 'passed'
        assert certificate['engine_timing_reported'] is True
        left, right = counters(baseline['certificate']['fields']), counters(certificate['fields'])
        changed = {key:[left.get(key),right.get(key)] for key in sorted(left.keys()|right.keys())
                   if left.get(key)!=right.get(key)}
        changes.update(changed.keys())
        pipeline = {}
        for key in ('native_pipeline_operator_invocations','native_pipeline_file_kernel_invocations'):
            name = 'proof.'+key
            pipeline[key] = dict(before=left[name],after=right[name],delta=right[name]-left[name])
        resources = {}
        for key in ('execution_resource_observed_native_peak_reserved_bytes',
                    'execution_resource_observed_native_reserved_bytes'):
            name = 'report.'+key
            resources[key] = dict(before=left[name],after=right[name],delta=right[name]-left[name])
        old_sort = 'local_primitive_sort_provider_background_workers' in baseline['certificate']['fields']
        new_sort = 'local_primitive_sort_provider_background_workers' in certificate['fields']
        groups[group]['cases'] += 1
        groups[group]['reported_file_sort_removed'] += int(old_sort and not new_sort)
        groups[group]['reported_file_sort_added'] += int(new_sort and not old_sort)
        groups[group]['reported_file_sort_retained'] += int(old_sort and new_sort)
        groups[group]['cases_with_more_file_kernels'] += int(pipeline['native_pipeline_file_kernel_invocations']['delta']>0)
        groups[group]['cases_with_fewer_file_kernels'] += int(pipeline['native_pipeline_file_kernel_invocations']['delta']<0)
        groups[group]['peak_reserved_increased'] += int(resources['execution_resource_observed_native_peak_reserved_bytes']['delta']>0)
        groups[group]['retained_reserved_increased'] += int(resources['execution_resource_observed_native_reserved_bytes']['delta']>0)
        groups[group]['higher_engine_time'] += int(after>before)
        baseline_clocks.append(before)
        candidate_clocks.append(after)
        details.append(dict(seq=seq,id=case['id'],group=group,surface=case['surface'],
            native_format=case['native_format'],baseline_source_commit=BASELINE,
            before_stdout_sha256=baseline['certificate']['raw_stdout_sha256'],
            after_stdout_sha256=certificate['raw_stdout_sha256'],before_engine_seconds=before,
            after_engine_seconds=after,reported_file_sort=dict(before=old_sort,after=new_sort),
            pipeline=pipeline,resources=resources,counter_changes=changed))
    baseline_total = math.fsum(baseline_clocks)
    candidate_total = math.fsum(candidate_clocks)
    assert baseline_total == frozen['current_baseline_engine_seconds'] == 337.804658081
    assert candidate_total == summary['successful_engine_seconds'] == summary['complete_candidate_engine_seconds']
    assert summary['source_commit'] != BASELINE
    result = dict(status='passed_saved_work_review',query_executions=0,
        source_commit=summary['source_commit'],baseline_source_commit=BASELINE,cases=388,
        baseline_engine_seconds=baseline_total,candidate_engine_seconds=candidate_total,
        lower_complete_cohort_engine_time=candidate_total<baseline_total,
        groups={name:dict(values) for name,values in groups.items()},
        changed_counter_occurrences=dict(changes),details=details,
        maximum_peak_reservation_increase=max(row['resources']['execution_resource_observed_native_peak_reserved_bytes']['delta'] for row in details),
        maximum_retained_reservation_increase=max(row['resources']['execution_resource_observed_native_reserved_bytes']['delta'] for row in details),
        source_identities=[identity(path) for path in (COHORT, summary_path,
            OUT/'prefix-cohort-r1/verified-cases-r1.jsonl.gz',
            OUT/'prefix-cohort-r1/certificate-cases-r1.jsonl.gz',Path(__file__))],
        limitation='The baseline is one current source-bound observation at 4d5fa4a46; prior historical '
            'classification provenance does not supply comparison clocks. One observation per runtime '
            'does not establish repeatability, whole-engine coverage or a Vortex physical-column counter.')
    with DEST.open('x') as stream:
        json.dump(result,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({key:result[key] for key in ('status','cases','baseline_engine_seconds',
        'candidate_engine_seconds','groups','maximum_peak_reservation_increase')},indent=2))


if __name__ == '__main__':
    main()
