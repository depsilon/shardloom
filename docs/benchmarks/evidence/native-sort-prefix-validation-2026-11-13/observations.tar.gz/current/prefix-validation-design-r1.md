# Shared Sort payload prefix connection — prospective contract

Status: candidate, not implemented or accepted when written. Current source is
`4d5fa4a46268380a634e78f057abba087f4042f5`. This extends the November 13
optimization-coverage work under item 20; it does not close whole-engine coverage.

## Existing owners and missing connection

`native_relational_sort::Sort::finish_prefix` already preserves complete stable
ordering and complete per-batch payload validation while retaining a bounded
flat output prefix. It declines unvalidated decimal and rich payloads, causing
complete output construction even when a following range requires few rows.
`native_relational_batch::Gather::column_prefix` also reads every flat payload
through the scalar builder. The established `native_payload::validate_selection`
owner can validate the exact selected domain without retaining values, using the
same recursive masks, field order, decimal/extension owners, typed leaf validators
and shared allocator as the native copier. The existing native gather/copy owner
can then copy just the retained indices.

Expert comparator: an encoded-columnar engine maintainer must be able to verify
identical observable validation and failure boundaries, actual work removal and
native output ownership, not merely correct answers on valid primitive inputs.

## Contract

- Preserve full Sort key validation and stable ordering before payload validation.
- Preserve the original sorted output batch boundaries and field-major validation
  order, including fields hidden by a later projection and rows after a limit.
- In each partial output batch, validate a column's complete existing selection,
  then copy only its retained prefix using the existing native gather. Validate
  subsequent batches even after no output remains.
- Admit decimal and rich payload prefixes only through that existing selection
  validator. Keep full gather for unobserved-field/copy-policy contracts and
  unsupported scalar domains. No change to prepared-file StreamingPrefix admission.
- For unchanged declared types use the shared selection validator; preserve the
  current scalar prefix path for casts, including Float16-to-Float64 promotion.
  Signaling NaN bits, strict/extended float policies and null masks remain intact.
- Preserve cancellation, consumer refusal, source generation, temporary credits,
  output ownership and cleanup. No second source scan, new pool, row representation,
  facade-specific shortcut, external execution or fallback is introduced.
- The full, unbounded gather remains the independent behavioral comparison for
  errors and selected values. Success alone cannot certify activation: assert N
  payload rows validated and at most K output rows constructed.

## Vortex-first check

Decision: `use_vortex_native_provider`. Cargo.lock pins Vortex 0.93.0.
Reuse existing `ArrayRef`, `take`, `slice`, chunked/native arrays, native dtype and
validity handling inside shardloom-vortex under the existing feature gates.
ShardLoom's existing recursive payload validator supplies finite-value, decimal,
tensor/vector/Variant and failure-order semantics that generic Vortex selection
alone does not certify. No new upstream API or dependency is required. Existing
execution and Native I/O certificates continue to identify native execution and
`fallback_attempted=false`.

## Proof before acceptance

Regression tests must fail on the current missing prefix connection. Cover nested
lists/structs, decimal and admitted extensions; empty/zero/tiny/large caps; chunked
and dictionary inputs; nullable parents and unreferenced invalid values; errors
outside the prefix; multiple invalid fields and late keys; consumer refusal,
cancellation, denied credit and exact refunds; native child ownership; Float16
bits and common-type promotion. Existing projection/barrier and provider tests
remain required. Tests must inspect work counters as well as complete results.

Run focused checks, then formatting, strict default/native workspace Clippy and
complete default/native tests, release-build provenance and installed-package
proof on one frozen source. Keep source inventories unchanged during checks.

Before any performance query, freeze the candidate source/runtime and the exact
388-case payload cohort already observed at 4d5fa4a46, including its complete
references, inputs, resource grant and original order. Baseline engine total is
337.804658081 seconds. Execute every candidate case exactly once under the same
isolated supervisor; no other task work during query execution. Replay complete
answers/schema/certificates and clocks, and review all work/resource differences.
The 388-case baseline is one current observation; do not recombine earlier9f/cac86
groups into it. Any additional public composition must have its own prospective
declaration/reference before running. No new full10k or Full43 is planned.

After correctness, resource, ownership and no-fallback acceptance, retain only
if the complete candidate cohort engine total is lower. Preserve individual and
family regressions, all failures, and the original correctness correction even
if this performance candidate is dropped. Do not infer universal optimization
coverage, source-read avoidance or external-engine superiority from this result.
