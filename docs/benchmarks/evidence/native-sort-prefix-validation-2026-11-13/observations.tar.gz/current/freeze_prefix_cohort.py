"""Freeze the prior 388 Sort cases against the single 4d5fa4a46 observation."""
from collections import Counter
import gzip
import hashlib
import json
import math
from pathlib import Path
import sqlite3
import sys
import zlib

import verify_sort_exposure as frozen

OUT = Path(__file__).resolve().parent
PRIOR = OUT / 'payload-sort-cohort-r1.json'
VERIFIED = OUT / 'payload-cohort-r1/verified-cases-r1.jsonl.gz'
CERTIFICATES = OUT / 'payload-cohort-r1/certificate-cases-r1.jsonl.gz'
SUMMARY = OUT / 'payload-cohort-r1/verified-summary-r1.json'
LEDGER = OUT / 'payload-cohort-r1/attempts.sqlite'
PROTOCOL = OUT / 'payload-cohort-protocol-r1.json'
DESIGN = frozen.E / 'design.json'
DEST = OUT / 'prefix-sort-cohort-r1.json'
BASELINE_COMMIT = '4d5fa4a46268380a634e78f057abba087f4042f5'


def file_id(path):
    raw = Path(path).read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def jsonl(path):
    with gzip.open(path, 'rt') as stream:
        rows = [json.loads(line) for line in stream]
    assert len(rows) == len({row['id'] for row in rows}) == 388
    return rows


def read_ledger(path):
    uri = f'file:{path}?mode=ro'
    connection = sqlite3.connect(uri, uri=True)
    try:
        rows = connection.execute('SELECT seq, id, status, packet FROM attempt ORDER BY seq').fetchall()
    finally:
        connection.close()
    assert len(rows) == 388 and [row[0] for row in rows] == list(range(388))
    result = {}
    for seq, case_id, status, blob in rows:
        packet = json.loads(zlib.decompress(blob))
        result[case_id] = dict(seq=seq, id=case_id, status=status, packet=packet)
    return result


def main():
    assert __debug__ and not DEST.exists()
    prior = json.loads(PRIOR.read_bytes())
    protocol = json.loads(PROTOCOL.read_bytes())
    summary = json.loads(SUMMARY.read_bytes())
    design = json.loads(DESIGN.read_bytes())
    assert prior['case_count'] == 388 and len(prior['cases']) == 388
    assert protocol['runtime_binding']['head'] == summary['source_commit'] == BASELINE_COMMIT
    assert protocol['runtime_binding']['source_tree'] == summary['source_tree']
    assert protocol['expected_attempt_count'] == protocol['required_complete_result_count'] == 388
    assert summary['attempted_cases'] == summary['successful_cases'] == 388
    assert summary['unsuccessful_cases'] == 0 and summary['outcomes'] == {'passed': 388}
    assert summary['successful_engine_seconds'] == summary['complete_candidate_engine_seconds'] == 337.804658081
    prior_rows = prior['cases']
    assert [row['original_ordinal'] for row in prior_rows] == sorted(row['original_ordinal'] for row in prior_rows)
    assert len({row['declaration']['id'] for row in prior_rows}) == 388
    verified_rows = jsonl(VERIFIED)
    certificate_rows = jsonl(CERTIFICATES)
    verified = {row['id']: row for row in verified_rows}
    certificates = {row['id']: row for row in certificate_rows}
    ledger = read_ledger(LEDGER)
    assert set(verified) == set(certificates) == set(ledger) == {row['declaration']['id'] for row in prior_rows}
    design_by_id = {row['id']: row for row in design['cases']}
    assert len(design_by_id) == 10000
    cases, groups = [], Counter()
    total = []
    for candidate_order, old in enumerate(prior_rows):
        declaration = old['declaration']
        case_id = declaration['id']
        current, cert, attempt = verified[case_id], certificates[case_id], ledger[case_id]
        packet = attempt['packet']
        files = packet['files']
        assert current['seq'] == cert['seq'] == attempt['seq'] == candidate_order
        assert current['id'] == cert['id'] == attempt['id'] == case_id
        assert current['case_identity'] == declaration['case_identity']
        assert current['original_ordinal'] == old['original_ordinal']
        assert current['family'] == declaration['family'] and current['surface'] == declaration['surface']
        assert current['native_format'] == declaration['native_format']
        assert current['current']['status'] == cert['status'] == attempt['status'] == packet['classified_status'] == 'passed'
        assert current['current']['failure_detail'] is None
        assert current['current']['engine_seconds'] == cert['engine_seconds']
        assert cert['engine_timing_reported'] is True
        stdout = json.loads(files['one.stdout.json']['utf8'])
        job = json.loads(files['one.job.json']['utf8'])
        observation = stdout['observation']
        assert stdout['status'] == 'passed' and stdout['id'] == case_id
        assert stdout['case_identity'] == declaration['case_identity']
        assert job['case'] == declaration
        assert job['engine'] == 'native' and job['surface'] == declaration['surface']
        assert job['input_format'] == declaration['native_format']
        assert observation['surface'] == declaration['surface']
        assert isinstance(observation['sql_declaration_submitted'], bool)
        assert observation['fields'] == cert['fields']
        stdout_hash = files['one.stdout.json']['sha256']
        assert hashlib.sha256(files['one.stdout.json']['utf8'].encode()).hexdigest() == stdout_hash
        assert cert['raw_stdout_sha256'] == stdout_hash
        assert packet['files']['one.job.json']['sha256'] == hashlib.sha256(files['one.job.json']['utf8'].encode()).hexdigest()
        runtime_binding = protocol['runtime_binding']['runtime']
        assert job['runtime'] == runtime_binding
        assert observation.get('execution_mode') is not None
        sec = current['current']['engine_seconds']
        assert isinstance(sec, (int, float)) and math.isfinite(sec) and sec >= 0
        total.append(sec)
        groups[old['comparison_group']] += 1
        cases.append(dict(candidate_order=candidate_order,
            original_ordinal=old['original_ordinal'], declaration=declaration,
            case_identity=declaration['case_identity'], family=declaration['family'],
            profile=declaration['profile'], public_surface=declaration['surface'],
            native_format=declaration['native_format'], submitted_workload=dict(
                sql_declaration=observation['sql_declaration'],
                sql_declaration_submitted=observation['sql_declaration_submitted'],
                saved_public_job=job),
            input_source_bindings=dict(input_format=job['input_format'], sources=job['sources']),
            historical_classification_group=old['comparison_group'],
            current_baseline=dict(source_commit=BASELINE_COMMIT, source_tree=summary['source_tree'],
                status='passed', engine_execution_seconds=sec, workflow_seconds=current['current']['workflow_seconds'],
                actual_rows=current['current']['actual_rows'], work=current['current']['work'],
                resources=current['resources'], certificate=dict(status=cert['status'],
                    raw_stdout_sha256=cert['raw_stdout_sha256'], engine_seconds=cert['engine_seconds'],
                    engine_timing_reported=cert['engine_timing_reported'], fields=cert['fields']),
                saved_attempt=dict(sequence=attempt['seq'], status=attempt['status'],
                    packet_classified_status=packet['classified_status'], files={name:{'bytes':meta['bytes'],
                        'sha256':meta['sha256']} for name,meta in files.items()},
                    supervision=packet['supervision']),
                ledger=dict(path=str(LEDGER), table='attempt', sequence=attempt['seq']),
                protocol=dict(path=str(PROTOCOL), schema=protocol['schema'], status=protocol['status'],
                    runtime_binding=protocol['runtime_binding'])),
            historical_baseline_provenance=dict(engine_seconds=old['baseline_engine_seconds'],
                source_commit=old['baseline_source_commit'], ledger=old['baseline_ledger'],
                sequence=old['baseline_seq'], raw_stdout_sha256=old['baseline_raw_stdout_sha256'],
                work=old['baseline_work'])))
    assert len(cases) == 388 and len({row['declaration']['id'] for row in cases}) == 388
    assert math.fsum(total) == 337.804658081
    assert groups == prior['groups'] == {'owned_source_control':10, 'vortex_no_file_kernel':321,
        'vortex_other_file_kernel':36, 'vortex_reported_file_sort':21}
    assert cases[0]['declaration']['id'] == prior_rows[0]['declaration']['id']
    assert [case['candidate_order'] for case in cases] == list(range(388))
    loaded_paths = {Path(module.__file__).resolve() for name,module in tuple(sys.modules.items())
        if name.startswith('query_surface') and getattr(module,'__file__',None)}
    assert not any(name == 'shardloom._native' or name.startswith('shardloom._native.') or
                   name == 'polars' or name.startswith('polars.') or
                   name == '_polars_runtime' or name.startswith('_polars_runtime.') for name in sys.modules)
    inputs = {Path(__file__), Path(frozen.__file__), PRIOR, VERIFIED, CERTIFICATES, SUMMARY,
              LEDGER, PROTOCOL, DESIGN, *loaded_paths}
    result = dict(schema='shardloom.shared_sort_prefix_candidate_cohort.v1',
        status='frozen_candidate_current_baseline_bound', query_executions=0,
        baseline_source_commit=BASELINE_COMMIT, baseline_source_tree=summary['source_tree'],
        case_count=388, original_declarations_verified=10000, candidate_order='exact prior payload-sort-cohort-r1 order',
        attempts_per_case=1, warmups=0, repeats=0, primary_clock='engine_execution_seconds',
        current_baseline_engine_seconds=math.fsum(total), current_baseline_status_counts={'passed':388},
        classification_groups=dict(groups), classification_only=True,
        selection=prior['selection'], protocol_identity=file_id(PROTOCOL),
        runtime_binding=protocol['runtime_binding'], resource_grant=protocol['execution'],
        source_identities=[file_id(path) for path in sorted(inputs)], cases=cases,
        runtime_import_assertion=dict(native_imported=False, polars_imported=False))
    assert result['current_baseline_engine_seconds'] == 337.804658081
    DEST.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    reread = json.loads(DEST.read_bytes())
    assert len(reread['cases']) == 388 and len({r['declaration']['id'] for r in reread['cases']}) == 388
    for path, identity in [(Path(row['path']), row) for row in reread['source_identities']]:
        assert file_id(path) == identity
    assert reread['current_baseline_engine_seconds'] == 337.804658081
    print(json.dumps(dict(status=reread['status'], case_count=388,
        baseline_source_commit=BASELINE_COMMIT, engine_seconds=reread['current_baseline_engine_seconds'],
        groups=dict(groups), manifest_sha256=file_id(DEST)['sha256'], source_identity_count=len(inputs)), sort_keys=True))


if __name__ == '__main__':
    main()
