"""Verify declared Sort consumers and distinguish shape exposure from real demand reduction."""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
E = OUT.parent / 'expanded-query-2026-11-03'
H = E / 'investigation-original-harness-r1/benchmarks/traditional_analytics'
sys.path[:0] = [str(H), str(H.parents[1] / 'python/src')]
from query_surface.corpus import corpus
from query_surface.expanded_catalog import build, spaces


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def nodes(node):
    yield node
    for child in node.inputs:
        yield from nodes(child)


def identity_project(node):
    return node.op == 'project' and all(
        expression.op == 'column' and name == expression.value
        for name, expression in node.args)


def admitted(node):
    if node.op == 'scan':
        return True
    return node.op in {'project', 'filter', 'limit', 'join', 'window'} and all(
        admitted(child) for child in node.inputs)


def scan_demand(node, needed):
    # The independently reconstructed matches below contain only these shapes.
    if node.op == 'scan':
        assert needed <= set(dict(node.schema))
        return {node.args[0]: sorted(needed)}
    assert len(node.inputs) == 1
    if node.op == 'project':
        needed = set().union(*(expression.columns() for name, expression in node.args
                              if name in needed or expression.op != 'column'))
    elif node.op == 'filter':
        needed = needed | node.args[0].columns()
    else:
        assert node.op == 'limit', node.op
    return scan_demand(node.inputs[0], needed)


def main():
    destination = OUT / 'sort-demand-exposure-primary-r1.json'
    assert not destination.exists()
    leaf_path = OUT / 'sort-demand-exposure-r1.json'
    leaf = json.loads(leaf_path.read_text())
    design_path = E / 'design.json'
    design = json.loads(design_path.read_text())
    assert digest(design_path) == leaf['inputs']['design_sha256']
    for name, expected in leaf['inputs']['frozen_module_sha256'].items():
        assert digest(H / 'query_surface' / name) == expected
    saved_path = OUT / 'full10k-r1/verified-cases-r1.jsonl.gz'
    assert digest(saved_path) == leaf['inputs']['saved_verified_cases_sha256']
    with gzip.open(saved_path, 'rt') as stream:
        saved = {row['id']: row for line in stream if (row := json.loads(line))}
    legacy = {case.id: case for case in corpus(interactions='all', include_pending=False)}
    definitions = {space.name: space for space in spaces()}
    expected = {row['id']: row for row in leaf['requested_downstream_consumer_inventory']
                ['all_matching_ids_and_saved_counters']}
    result = []
    verified = 0
    for descriptor in design['cases']:
        case = build(descriptor, definitions) if 'cell' in descriptor else legacy[descriptor['id']]
        assert case.identity == descriptor['case_identity']
        verified += 1
        if descriptor['native_format'] not in {'parquet', 'arrow-ipc'}:
            continue
        for parent in nodes(case.relation):
            if parent.op not in {'project', 'filter', 'aggregate', 'window'} or len(parent.inputs) != 1:
                continue
            child = parent.inputs[0]
            while child.op == 'limit' or identity_project(child):
                child = child.inputs[0]
            if child.op != 'sort' or not admitted(child.inputs[0]):
                continue
            assert parent.op == 'project'
            original = set(dict(child.schema))
            needed = set().union(*(expression.columns() for _, expression in parent.args))
            needed.update(key.column for key in child.args)
            before = scan_demand(child.inputs[0], original)
            after = scan_demand(child.inputs[0], needed)
            removed = {name: sorted(set(columns) - set(after[name])) for name, columns in before.items()}
            observation = saved[case.id]
            assert observation['current']['status'] == 'passed'
            reported = expected[case.id]
            assert reported['engine_seconds'] == observation['current']['engine_seconds']
            assert reported['native_format'] == descriptor['native_format']
            assert reported['family'] == descriptor['family']
            for name, value in reported['work_counters'].items():
                actual = observation['current']['work'].get(name)
                assert value == (int(actual) if actual is not None and str(actual).isdigit() else None)
            result.append(dict(id=case.id, case_identity=case.identity,
                native_format=descriptor['native_format'], family=descriptor['family'],
                sort_fields=sorted(original), required_sort_fields=sorted(needed),
                before_scan_columns=before, after_scan_columns=after,
                removed_scan_columns=removed, narrows_scan=any(removed.values()),
                saved_engine_seconds=reported['engine_seconds']))
    assert verified == 10000 and len(result) == len(expected) == 606
    assert {row['id'] for row in result} == set(expected)
    reduced = [row for row in result if row['narrows_scan']]
    proof = dict(status='passed', query_executions=0, declarations_verified=verified,
        shape_matches=len(result), narrower_source_demand=len(reduced),
        narrower_formats=dict(Counter(row['native_format'] for row in reduced)),
        narrower_families=dict(Counter(row['family'] for row in reduced)),
        input_identities={str(path): digest(path) for path in [leaf_path, design_path, saved_path, Path(__file__)]},
        interpretation='Static demand inference under the source binder rules; actual execution and performance change remain unmeasured.',
        cases=result)
    destination.write_text(json.dumps(proof, indent=2) + '\n')
    print(json.dumps({key:value for key,value in proof.items() if key not in {'cases', 'input_identities'}}))


if __name__ == '__main__':
    main()
