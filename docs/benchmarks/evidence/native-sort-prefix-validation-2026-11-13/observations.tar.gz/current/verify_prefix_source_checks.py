"""Independently bind completed prefix checks to the unchanged working tree."""
import json
from pathlib import Path
import re

from pipeline_runtime import OUT, ROOT, fingerprint, identity, read, sources


def main():
    assert __debug__
    destination = OUT / 'prefix-primary-source-checks-r1.json'
    assert not destination.exists()
    expected_path = OUT / 'prefix-check-expectations-r1.json'
    expected_identity = identity(expected_path)
    expected = read(expected_path)
    snapshot = sources()
    checks = {}
    counts = {}
    names = ('fmt', 'default-clippy', 'native-clippy', 'default-tests', 'native-tests')
    for name in names:
        path = OUT / f'prefix-{name}-r1.json'
        receipt = read(path)
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0, name
        assert receipt['sources_unchanged'], name
        assert receipt['process_group_drained'] and receipt['direct_child_reaped'], name
        assert receipt['source_files'] == snapshot, name
        checks[name] = identity(path)
    for kind in ('default', 'native'):
        path = OUT / 'logs' / f'prefix-{kind}-tests-r1.log'
        log = path.read_text()
        rows = [tuple(map(int, row)) for row in re.findall(
            r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored', log)]
        result = dict(zip(('passed', 'failed', 'ignored'),
                          (sum(row[i] for row in rows) for i in range(3))))
        result['test_binaries'] = len(rows)
        assert result == expected[kind], (kind, result, expected[kind])
        if kind == 'native':
            library = expected['native_library']
            assert tuple(library[key] for key in ('passed', 'failed', 'ignored')) in rows
            assert f"running {library['passed'] + library['ignored']} tests" in log
            for name in expected['required_new_tests']:
                assert len(re.findall(r'^test [^\n]*::' + re.escape(name) +
                                      r' \.\.\. ok$', log, re.M)) == 1, name
        counts[kind] = result
    test_sources = [
        ROOT / 'shardloom-vortex/src/local_primitives' / name for name in (
            'native_relational_sort_tests.rs',
            'native_relational_sort_payload_prefix_tests.rs',
            'native_relational_sort_payload_prefix_rich_tests.rs')]
    for name in expected['required_new_tests']:
        assert sum(len(re.findall(r'\bfn ' + re.escape(name) + r'\(', path.read_text()))
                   for path in test_sources) == 1, name
    assert identity(expected_path) == expected_identity
    assert sources() == snapshot
    proof = dict(status='passed', source_files=len(snapshot),
                 source_fingerprint_sha256=fingerprint(snapshot),
                 expectations=expected_identity, checks=checks, counts=counts,
                 required_test_names=expected['required_new_tests'], query_executions=0)
    with destination.open('x') as output:
        json.dump(proof, output, indent=2)
        output.write('\n')
    print(json.dumps(proof))


if __name__ == '__main__':
    main()
