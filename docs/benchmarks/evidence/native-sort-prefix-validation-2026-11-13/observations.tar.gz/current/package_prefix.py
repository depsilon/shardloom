"""Package the fixed current-baseline Sort prefix cohort; runs no queries."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
DEST = OUT/'compact-prefix-r2'
ORIGINAL = OUT.parent/'expanded-query-2026-11-03'
BASELINE_COMMIT = '4d5fa4a46268380a634e78f057abba087f4042f5'
DESIGN_PATH = 'docs/architecture/native-sort-prefix-validation-2026-11-13.md'
LEDGER_PATH = OUT/'payload-cohort-r1/attempts.sqlite'
EXPECTED_RUST_FILES = (
    'shardloom-vortex/src/local_primitives/native_payload.rs',
    'shardloom-vortex/src/local_primitives/native_payload_validation.rs',
    'shardloom-vortex/src/local_primitives/native_relational_batch.rs',
    'shardloom-vortex/src/local_primitives/native_relational_sort.rs',
    'shardloom-vortex/src/local_primitives/native_relational_sort_payload_prefix_rich_tests.rs',
    'shardloom-vortex/src/local_primitives/native_relational_sort_payload_prefix_tests.rs',
    'shardloom-vortex/src/local_primitives/native_relational_sort_tests.rs',
)
sys.path.insert(0, str(ROOT/'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def identity(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    assert __debug__ and not DEST.exists()
    require_local_path(DEST, Path.home(), sys.platform)
    check_budgets(OUT, DEST, OUT/'logs', min_free_bytes=12*GIB,
        reserve_bytes=128*MIB, max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)

    summary_path = OUT/'prefix-cohort-r1/verified-summary-r1.json'
    summary = json.loads(summary_path.read_bytes())
    cohort_path = OUT/'prefix-sort-cohort-r1.json'
    cohort = json.loads(cohort_path.read_bytes())
    assert summary['status'] == 'passed_offline_replay'
    assert summary['attempted_cases'] == summary['successful_cases'] == 388
    assert summary['unsuccessful_cases'] == 0 and summary['outcomes'] == {'passed':388}
    assert summary['independent_complete_results_replayed'] is True
    assert summary['source_commit'] != BASELINE_COMMIT
    assert cohort['status'] == 'frozen_candidate_current_baseline_bound'
    assert cohort['case_count'] == len(cohort['cases']) == 388 and cohort['query_executions'] == 0
    assert cohort['baseline_source_commit'] == BASELINE_COMMIT
    assert cohort['current_baseline_engine_seconds'] == 337.804658081

    members = {}

    def add(path, name):
        if not path.is_file() or path.is_symlink() or name in members:
            raise ValueError(f'unsafe, missing or duplicate packet member: {path} -> {name}')
        members[name] = (path.read_bytes(), str(path))

    def add_glob(pattern):
        for path in sorted(OUT.glob(pattern)):
            add(path, 'current/'+path.relative_to(OUT).as_posix())

    # Keep every prefix check receipt and note, including failed and stopped attempts.
    for pattern in ('prefix-*.json', 'prefix-*.md', 'prefix-*.log'):
        add_glob(pattern)
    # Preserve the prefix helper family, including this packager, work review,
    # packet verifier and relocation/negative-control helper.
    for path in sorted(OUT.glob('*prefix*.py')):
        add(path, 'current/'+path.relative_to(OUT).as_posix())
    for path in sorted((OUT/'logs').glob('prefix-*.log')):
        add(path, 'current/'+path.relative_to(OUT).as_posix())
    for name in ('pipeline_runtime.py', 'guard_checks.py', 'sort_capture.py'):
        add(OUT/name, 'current/'+name)

    run = OUT/'prefix-cohort-r1'
    for path in sorted(run.iterdir()):
        if path.is_file() and (path.suffix == '.json' or path.name in {
            'verified-cases-r1.jsonl.gz', 'certificate-cases-r1.jsonl.gz'
        }):
            add(path, 'current/'+path.relative_to(OUT).as_posix())

    installed = OUT/'prefix-installed-wheel-r1'
    for path in sorted(installed.iterdir()):
        if path.is_file() and path.suffix in {'.json', '.log', '.txt'}:
            add(path, 'current/'+path.relative_to(OUT).as_posix())

    for name in ('design.json', 'inputs.json', 'frozen.json'):
        add(ORIGINAL/name, 'original/'+name)
    add(OUT/'payload-cohort-r1/complete.json', 'current/payload-cohort-r1/complete.json')
    ledger_records = [record for record in cohort['source_identities']
        if record.get('path') == str(LEDGER_PATH)]
    assert len(ledger_records) == 1
    ledger_identity = ledger_records[0]
    assert ledger_identity['path'] == str(OUT/'payload-cohort-r1/attempts.sqlite')
    assert type(ledger_identity['bytes']) is int and ledger_identity['bytes'] > 0
    assert isinstance(ledger_identity['sha256'],str) and len(ledger_identity['sha256']) == 64
    for record in cohort['source_identities']:
        if record['path'] == str(LEDGER_PATH):
            assert record == ledger_identity
            continue
        path = Path(record['path'])
        if path.is_relative_to(OUT):
            member = 'current/'+path.relative_to(OUT).as_posix()
        elif path.is_relative_to(OUT.parent):
            member = 'provenance/'+path.relative_to(OUT.parent).as_posix()
        else:
            raise ValueError(f'cohort source identity outside retained roots: {path}')
        if member not in members:
            add(path, member)
        assert identity(path.read_bytes()) == {key:record[key] for key in ('bytes','sha256')}

    source_commit = summary['source_commit']
    patch = subprocess.check_output(['git','diff','--binary',BASELINE_COMMIT,source_commit,
        '--','shardloom-vortex/src'], cwd=ROOT)
    members['source/prefix.patch'] = (patch,
        f'git diff --binary {BASELINE_COMMIT} {source_commit} -- shardloom-vortex/src')
    changed = subprocess.check_output(['git','diff','--name-only','--diff-filter=ACMR',
        BASELINE_COMMIT,source_commit,'--','shardloom-vortex/src'],cwd=ROOT,text=True).splitlines()
    rust_files = sorted(path for path in changed if path.endswith('.rs'))
    if tuple(rust_files) != EXPECTED_RUST_FILES:
        raise ValueError(f'Rust source diff differs from the frozen seven-file set: {rust_files}')
    for path in rust_files:
        raw = subprocess.check_output(['git','show',f'{source_commit}:{path}'],cwd=ROOT)
        members['source/files/'+path] = (raw,f'git show {source_commit}:{path}')
    design = subprocess.check_output(['git','show',f'{source_commit}:{DESIGN_PATH}'],cwd=ROOT)
    members['design/native-sort-prefix-validation-2026-11-13.md'] = (
        design, f'git show {source_commit}:{DESIGN_PATH}')

    add(OUT.parent/'native-pipeline-sql-minute-2026-11-13/guard_checks.py',
        'helpers/check-supervisor.py')
    add(OUT.parent/'perf-all-20260906/bounded_build_process_resume_20260912.py',
        'helpers/bounded-supervisor.py')

    DEST.mkdir()
    shutil.copyfile(OUT/'prefix-verify.py', DEST/'verify.py')
    (DEST/'README.md').write_text('''# Shared Sort prefix validation candidate

This packet preserves the fixed 388-case Sort prefix candidate and its single
current baseline at source `4d5fa4a46268380a634e78f057abba087f4042f5`. Every
candidate case is compared with the matching baseline observation from that
same source. Historical classification provenance is preserved in the frozen
cohort but is not used to supply comparison clocks or a mixed baseline total.

The archive includes complete replay records and certificates, source-bound
checks and runtime identity, work/resource deltas, per-case engine clocks,
failed and stopped focused attempts, the exact Rust source patch, and the
prefix validation design. Complete answers were independently replayed locally
against their reference results. The portable verifier checks saved identities
and evidence without repeating the full oracle or running queries.

Run `python3 -B verify.py` from this directory. Do not use optimized Python;
the verifier requires assertions to remain enabled.
''')

    archive_path = DEST/'observations.tar.gz'
    with archive_path.open('xb') as stream:
        with gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for name, (raw, _) in sorted(members.items()):
                    entry = tarfile.TarInfo(name)
                    entry.size, entry.mode, entry.mtime = len(raw), 0o644, 0
                    entry.uid = entry.gid = 0
                    entry.uname = entry.gname = ''
                    archive.addfile(entry, io.BytesIO(raw))
    with tarfile.open(archive_path, 'r:gz') as archive:
        assert set(archive.getnames()) == set(members)
        for item in archive.getmembers():
            assert archive.extractfile(item).read() == members[item.name][0]

    manifest = dict(schema='shardloom.shared_sort_prefix_validation_evidence.v1',
        source_commit=source_commit, baseline_source_commit=BASELINE_COMMIT,
        rust_source_files=rust_files,
        external_artifacts=[dict(ledger_identity)],
        query_executions_during_packaging=0, published=False,
        cohort_summary=identity(summary_path.read_bytes()), cohort=identity(cohort_path.read_bytes()),
        files={path.name:identity(path.read_bytes()) for path in sorted(DEST.iterdir())},
        archive_members={name:dict(**identity(raw),origin=origin)
                         for name,(raw,origin) in sorted(members.items())})
    with (DEST/'manifest.json').open('x') as stream:
        json.dump(manifest,stream,indent=2);stream.write('\n')
    print(json.dumps(dict(status='packaged_readback_verified',archive_members=len(members),
        archive_bytes=archive_path.stat().st_size,source_commit=source_commit,
        baseline_source_commit=BASELINE_COMMIT,successful_cases=summary['successful_cases'],
        unsuccessful_cases=summary['unsuccessful_cases'])))


if __name__ == '__main__':
    main()
