"""Compile and preflight the frozen identity candidate before any comparison."""
from pathlib import Path
import json
import subprocess
import sys

OUT=Path(__file__).resolve().parent
REPO=Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
DRIVER=OUT/'nested_identity_driver_761.py'
GUARD=OUT/'run_guarded_observed_757.py'
LABEL='nested-identity-preflight-761'
DATA='nested-key-attribution-identity-761-a1'

def run(command):subprocess.run(command,cwd=REPO,check=True)
def guarded(name,command):run([sys.executable,str(GUARD),'--name',name,'--timeout','1800','--',*command])

run([sys.executable,str(DRIVER),'freeze','--label',LABEL])
cargo=['/Users/dylan/.cargo/bin/rustup','run','1.99.0','cargo']
guarded('nested-identity-clippy-coverage-761',cargo+['clippy','--offline','--locked','-p','shardloom-vortex','--features','release-user-surfaces','--lib','--tests','--','-D','warnings'])
run([sys.executable,str(DRIVER),'verify','--label',LABEL]) if (OUT/f'{LABEL}-artifact.json').exists() else None
guarded('nested-identity-build-761',cargo+['test','--offline','--locked','--release','-p','shardloom-vortex','--features','release-user-surfaces','--lib','--no-run','--message-format=json'])
run([sys.executable,str(DRIVER),'bind','--label',LABEL,'--build','nested-identity-build-761'])
binary=json.loads((OUT/f'{LABEL}-artifact.json').read_text())['artifact']
for name,selector in [
    ('identities','native_exact_identities_'),
    ('keys','local_primitives::native_relational_keys::nested_tests'),
    ('relational','local_primitives::prepared_relational::tests::nested_tests'),
    ('unary','local_primitives::prepared_unary::tests::'),
    ('membership','unary_membership_'),
]:
    guarded(f'nested-identity-{name}-regressions-761',[binary,selector,'--nocapture','--test-threads=1'])
    run([sys.executable,str(DRIVER),'verify','--label',LABEL])
run([sys.executable,str(DRIVER),'run','--label',LABEL,'--name','nested-identity-preflight-run-761','--mode','preflight','--data',DATA])
run([sys.executable,str(OUT/'analyze_nested_identity_761.py'),'--root',str(OUT/DATA),'--preflight','--output',str(OUT/'nested-identity-preflight-analysis-761.json')])
run([sys.executable,str(DRIVER),'verify','--label',LABEL])
