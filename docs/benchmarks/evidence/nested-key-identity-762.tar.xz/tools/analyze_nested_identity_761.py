"""Complete independent oracle plus predeclared native dictionary identity gate."""
import argparse
from collections import defaultdict
import copy
import hashlib
import json
from pathlib import Path
import statistics
import analyze_nested_attribution_760 as oracle

OUT=Path(__file__).resolve().parent
PROTOCOL_SHA='e083f4c3e25e5a85d3574aaf1b34d4fc30d76ccd46313dd5958cb4b19e6751e9'
COUNTERS=['activated_owners','mapped_rows','canonical_entries','cached_writes','serialized_domain_entries']

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def target(spec): return spec['consumer']=='unary_distinct' and spec['domain']=='eight' and spec['representation']=='parent_dictionary'
def engine(record): return sum(op['engine_execution_ns'] for op in record['operations'])

def validate(record,spec,role,sample,warmup,cohort,witnesses):
    assert record['profile']==role
    standard=copy.copy(record)
    standard['profile']='disabled'
    oracle.validate_record(standard,spec,'disabled',sample,warmup,cohort,witnesses)
    counters=record['identity']
    assert set(counters)==set(COUNTERS)
    assert all(isinstance(value,int) and value>=0 for value in counters.values())
    if role=='candidate' and target(spec):
        assert counters['activated_owners']>0, ('missing candidate activation',spec)
        assert counters['mapped_rows']==spec['rows']*spec['calls']
        assert 0<counters['canonical_entries']<=64*counters['activated_owners']
        assert 0<counters['serialized_domain_entries']<=counters['mapped_rows']
        assert counters['cached_writes']==4*counters['mapped_rows']
    else:
        assert all(value==0 for value in counters.values()),('unexpected activation',spec,role,counters)

def read(root,mode,cohort,witnesses):
    path=root/f'{mode}-{cohort}.jsonl'
    records=[json.loads(line) for line in path.read_text().splitlines()]
    expected=[]; matrix=list(oracle.specs())
    if mode=='measure':
        for role in ['baseline','candidate']: expected.append((matrix[0],role,0,True))
    for index,spec in enumerate(matrix):
        for sample in range(3 if mode=='measure' else 1):
            first=((index+sample)%2==0) ^ (cohort=='B')
            for enabled in [not first,first]: expected.append((spec,'candidate' if enabled else 'baseline',sample,False))
    if mode=='preflight':
        for spec in oracle.controls():
            for role in ['baseline','candidate']: expected.append((spec,role,0,False))
    assert len(records)==len(expected)==(770 if mode=='measure' else 320)
    for record,(spec,role,sample,warmup) in zip(records,expected): validate(record,spec,role,sample,warmup,cohort,witnesses)
    operations=sum(len(r['operations']) for r in records)
    assert operations==(1922 if mode=='measure' else 704)
    return records,dict(path=str(path),sha256=sha(path),workflows=len(records),operations=operations)

def score(base,candidate):
    result={}
    for clock,metric in [('engine',engine),('complete',lambda r:r['complete_workflow_ns'])]:
        before=statistics.median(metric(r) for r in base)
        after=statistics.median(metric(r) for r in candidate)
        assert before>0
        result[clock]=dict(baseline_ns=before,candidate_ns=after,improvement_fraction=(before-after)/before,
            regression=after*100>before*105 and after-before>1_000_000)
    e=result['engine']; complete=result['complete']
    result['material_engine_benefit']=e['candidate_ns']*100<=e['baseline_ns']*95 and e['baseline_ns']-e['candidate_ns']>=1_000_000 and complete['candidate_ns']<=complete['baseline_ns']
    return result

def analyze(cohorts):
    scores={}; totals={}; failures=[]
    specs=list(oracle.specs()); targets=[spec for spec in specs if target(spec)]; assert len(targets)==8
    for cohort,records in cohorts.items():
        grouped=defaultdict(lambda:defaultdict(list))
        for record in records:
            if not record['warmup']:grouped[record['cell_id']][record['profile']].append(record)
        assert len(grouped)==128
        scores[cohort]={}
        for cell,roles in grouped.items():
            assert len(roles['baseline'])==len(roles['candidate'])==3
            cell_score=score(roles['baseline'],roles['candidate']); scores[cohort][cell]=cell_score
            for clock in ['engine','complete']:
                if cell_score[clock]['regression']: failures.append(dict(cohort=cohort,cell_id=cell,clock=clock,**cell_score[clock]))
        totals[cohort]={}
        for clock,required in [('engine',5),('complete',3)]:
            before=sum(scores[cohort][oracle.cell_id(spec)][clock]['baseline_ns'] for spec in targets)
            after=sum(scores[cohort][oracle.cell_id(spec)][clock]['candidate_ns'] for spec in targets)
            totals[cohort][clock]=dict(baseline_sum_medians_ns=before,candidate_sum_medians_ns=after,improvement_fraction=(before-after)/before,passed=after*100<=before*(100-required))
    common=[spec for spec in targets if spec['rows']==4096 and all(scores[c][oracle.cell_id(spec)]['material_engine_benefit'] for c in ['A','B'])]
    accepted=not failures and len({spec['shape'] for spec in common})>=2 and all(totals[c][clock]['passed'] for c in ['A','B'] for clock in ['engine','complete'])
    return dict(outcome='finite_candidate_passes_for_integration_acceptance' if accepted else 'finite_candidate_rejected',
        production_accepted=False,finite_comparison_passed=accepted,scores=scores,target_totals=totals,
        common_material_cells=common,failed_controls=failures,
        scope='Unary native dictionary exact keys only; attribution and this comparison do not close PERF-05.')

def self_tests():
    def record(engine_ns,complete): return dict(operations=[dict(engine_execution_ns=engine_ns)],complete_workflow_ns=complete)
    baseline=[record(20_000_000,30_000_000)]*3
    assert score(baseline,[record(19_000_000,29_100_000)]*3)['material_engine_benefit']
    assert not score(baseline,[record(19_000_001,29_100_000)]*3)['material_engine_benefit']
    assert not score(baseline,[record(21_000_000,30_000_000)]*3)['engine']['regression']
    assert score(baseline,[record(21_000_001,30_000_000)]*3)['engine']['regression']
    assert not score(baseline,[record(19_000_000,30_000_001)]*3)['material_engine_benefit']

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--preflight',action='store_true')
    parser.add_argument('--self-test-only',action='store_true')
    args=parser.parse_args();self_tests()
    assert sha(OUT/'nested-key-identity-protocol-761.json')==PROTOCOL_SHA
    if args.self_test_only: print('identity score boundaries passed'); return
    assert args.root and args.output
    witnesses=oracle.Witnesses(args.root)
    fixtures=oracle.fixture_validation(args.root,witnesses)
    if args.preflight:
        _,receipt=read(args.root,'preflight','preflight',witnesses)
        result=dict(outcome='preflight_semantics_activation_resources_validated',receipt=receipt)
    else:
        cohorts={}; receipts=[]
        for cohort in ['A','B']:
            cohorts[cohort],receipt=read(args.root,'measure',cohort,witnesses);receipts.append(receipt)
        result=analyze(cohorts);result['cohorts']=receipts
    result.update(protocol_sha256=PROTOCOL_SHA,analyzer_sha256=sha(__file__),oracle_sha256=sha(oracle.__file__),fixtures=fixtures,verified_witnesses=list(witnesses.seen.values()))
    with args.output.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps(dict(outcome=result['outcome'],output=str(args.output),sha256=sha(args.output))))

if __name__=='__main__':main()
