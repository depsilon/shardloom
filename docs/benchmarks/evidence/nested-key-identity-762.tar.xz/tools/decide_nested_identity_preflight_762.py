"""Record all frozen preflight failures; do not weaken admission or collect timings."""
import copy
import itertools
import json
from pathlib import Path
import analyze_nested_identity_761 as a

OUT=Path(__file__).resolve().parent
ROOT=OUT/'nested-key-attribution-identity-761-a1'
assert a.sha(OUT/'nested-key-identity-protocol-761.json')==a.PROTOCOL_SHA
witnesses=a.oracle.Witnesses(ROOT)
fixtures=a.oracle.fixture_validation(ROOT,witnesses)
records=[json.loads(line) for line in (ROOT/'preflight-preflight.jsonl').read_text().splitlines()]
expected=[]
for index,spec in enumerate(a.oracle.specs()):
    first=index%2==0
    for enabled in [not first,first]:expected.append((spec,'candidate' if enabled else 'baseline'))
for spec in a.oracle.controls():
    for role in ['baseline','candidate']:expected.append((spec,role))
assert len(records)==len(expected)==320
violations=[];targets=[]
for record,(spec,role) in zip(records,expected):
    assert record['profile']==role
    standard=copy.copy(record);standard['profile']='disabled'
    a.oracle.validate_record(standard,spec,'disabled',0,False,'preflight',witnesses)
    try:a.validate(record,spec,role,0,False,'preflight',witnesses)
    except AssertionError as error:
        violations.append(dict(cell_id=record['cell_id'],profile=role,error=str(error),identity=record['identity']))
    if role=='candidate' and a.target(spec):targets.append(dict(cell_id=record['cell_id'],identity=record['identity']))
assert len(targets)==8 and len(violations)==4
assert all(v['profile']=='candidate' and v['cell_id'].startswith('4096-') and
    'missing candidate activation' in v['error'] and not any(v['identity'].values()) for v in violations)
assert sum(len(r['operations']) for r in records)==704
assert not list(ROOT.glob('measure-*.jsonl'))
guards=[]
for name in ['nested-identity-clippy-coverage-761','nested-identity-build-761',
    'nested-identity-identities-regressions-761','nested-identity-keys-regressions-761',
    'nested-identity-relational-regressions-761','nested-identity-unary-regressions-761',
    'nested-identity-membership-regressions-761','nested-identity-preflight-run-761']:
    path=OUT/f'{name}.json';value=json.loads(path.read_text())
    assert value['status']=='passed' and value['process_group_drained'] and value['returncode']==0
    guards.append(dict(path=str(path),sha256=a.sha(path),native_process_passed=True,process_group_drained=True))
result=dict(schema_version='shardloom.nested_key_identity_preflight_decision.v1',
    outcome='finite_candidate_rejected_missing_required_activation',candidate_accepted=False,
    timing_comparison_started=False,protocol_sha256=a.PROTOCOL_SHA,
    complete_semantics_workflows=320,complete_semantics_operations=704,
    complete_semantics_native_certificates_and_resource_cleanup='passed',
    frozen_activation_gate='failed',required_target_cells=8,activated_target_cells=4,
    activation_failures=violations,all_target_counters=targets,
    interpretation='The frozen Dict/Chunked-only admission does not activate on the production 4096-row target workflows. Correct results and small-target activation do not satisfy this protocol. No threshold, target scope, eligibility, or workload is changed; no benefit measurement is performed.',
    diagnosis_limit='The counter evidence proves the missing admission, not its individual failing predicate. Source review found native sliced views outside the direct Dict/Chunked admission, but the exact rejected runtime wrapper tree was not instrumented; do not claim that inferred explanation as measured fact.',
    next_mechanism_requirement='Any future identity mechanism requires a newly frozen provider/wrapper admission design, full target activation, and the original semantic/resource controls before benefit measurement.',
    fixtures=fixtures,guard_receipts=guards,
    analyzer_sha256=a.sha(a.__file__),oracle_sha256=a.sha(a.oracle.__file__),decision_driver_sha256=a.sha(__file__),
    raw_preflight_sha256=a.sha(ROOT/'preflight-preflight.jsonl'),
    verified_witnesses=list(witnesses.seen.values()),
    broader_owner_and_conditional_substep_remain_open=True)
path=OUT/'nested-identity-preflight-decision-762.json'
with path.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps({k:result[k] for k in ['outcome','complete_semantics_workflows','complete_semantics_operations','activated_target_cells','required_target_cells','timing_comparison_started']}))
