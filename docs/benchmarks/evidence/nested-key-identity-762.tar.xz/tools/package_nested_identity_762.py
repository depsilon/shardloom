"""Package the preflight-rejected nested identity candidate without rerunning it."""
from pathlib import Path
import hashlib
import io
import json
import lzma
import sys
import tarfile
from collections import Counter

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
DEST = ROOT / 'nested-identity-portable-762'
NAME = 'nested-key-identity-762'
EXPECTED_PROTOCOL_SHA = 'e083f4c3e25e5a85d3574aaf1b34d4fc30d76ccd46313dd5958cb4b19e6751e9'
EXPECTED_EXECUTABLE_SHA = '407cc36031b8dc6b254d9482ea84977ddb72d498bccc5421c4eab449bcb5a0ab'
EXPECTED_PREFLIGHT_SHA = '6df9bb292970ab28149f7ba88d226d4bcb8eb44f051649a38c9965cafd42f545'
EXPECTED_SUPERVISOR_SHA = '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97'
sys.path.insert(0, str(REPO / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def digest_file(path):
    hasher = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            hasher.update(chunk)
    return hasher.hexdigest()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def add_file(members, archive_name, path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), f'not a regular file: {path}'
    assert archive_name not in members, f'duplicate member: {archive_name}'
    members[archive_name] = path


decision_path = ROOT / 'nested-identity-preflight-decision-762.json'
decision = json.loads(decision_path.read_text())
protocol_path = ROOT / 'nested-key-identity-protocol-761.json'
protocol = json.loads(protocol_path.read_text())
assert decision['schema_version'] == 'shardloom.nested_key_identity_preflight_decision.v1'
assert decision['outcome'] == 'finite_candidate_rejected_missing_required_activation'
assert decision['candidate_accepted'] is False
assert decision['timing_comparison_started'] is False
assert decision['protocol_sha256'] == EXPECTED_PROTOCOL_SHA == digest_file(protocol_path)
assert protocol['owner'] == 'PERF-05.nested_identity'
assert decision['complete_semantics_workflows'] == 320
assert decision['complete_semantics_operations'] == 704
assert decision['complete_semantics_native_certificates_and_resource_cleanup'] == 'passed'
assert decision['frozen_activation_gate'] == 'failed'
assert decision['required_target_cells'] == 8 and decision['activated_target_cells'] == 4
assert len(decision['activation_failures']) == 4
assert all(str(row['cell_id']).startswith('4096-') for row in decision['activation_failures'])
assert decision['broader_owner_and_conditional_substep_remain_open'] is True

# Verify the complete current runtime-source inventory from the immutable
# preflight source freeze before recording it in the packet index.
freeze_path = ROOT / 'nested-identity-preflight-761-source-freeze.json'
freeze = json.loads(freeze_path.read_text())
assert freeze['protocol_sha256'] == EXPECTED_PROTOCOL_SHA
assert len(freeze['sources']) == 1899
source_mismatches = []
for row in freeze['sources']:
    source = REPO / row['path']
    if (not source.is_file() or source.stat().st_size != row['bytes']
            or digest_file(source) != row['sha256']):
        source_mismatches.append(row['path'])
assert not source_mismatches, f'frozen candidate sources differ: {source_mismatches[:10]}'

extra_dir = ROOT / 'nested-identity-preflight-761-extra-sources'
assert extra_dir.is_dir() and not extra_dir.is_symlink()
assert len(freeze['extra_sources']) == 4
extra_bindings = []
for relative in freeze['extra_sources']:
    source = REPO / relative
    frozen_copy = extra_dir / relative
    assert source.is_file() and frozen_copy.is_file() and not frozen_copy.is_symlink()
    assert (source.stat().st_size, digest_file(source)) == (
        frozen_copy.stat().st_size, digest_file(frozen_copy))
    extra_bindings.append({'path': relative, 'bytes': frozen_copy.stat().st_size,
                           'sha256': digest_file(frozen_copy),
                           'archive_path': str(Path('sources') / frozen_copy.relative_to(ROOT))})
driver_path = ROOT / 'nested_identity_driver_761.py'
assert digest_file(driver_path) == freeze['driver_sha256']

artifact_path = ROOT / 'nested-identity-preflight-761-artifact.json'
artifact = json.loads(artifact_path.read_text())
copied_executable = Path(artifact['artifact'])
assert copied_executable == ROOT / 'nested-identity-preflight-761-test'
assert artifact['artifact_sha256'] == EXPECTED_EXECUTABLE_SHA == digest_file(copied_executable)
assert copied_executable.stat().st_size == artifact['bytes']
assert artifact['source_freeze_sha256'] == digest_file(freeze_path)
assert artifact['build_receipt_sha256'] == digest_file(ROOT / f"{artifact['build']}.json")
build_receipt = json.loads((ROOT / f"{artifact['build']}.json").read_text())

analyzer_path = ROOT / 'analyze_nested_identity_761.py'
oracle_path = ROOT / 'analyze_nested_attribution_760.py'
decision_driver_path = ROOT / 'decide_nested_identity_preflight_762.py'
assert decision['analyzer_sha256'] == digest_file(analyzer_path)
assert decision['oracle_sha256'] == digest_file(oracle_path)
assert decision['decision_driver_sha256'] == digest_file(decision_driver_path)
assert decision['raw_preflight_sha256'] == EXPECTED_PREFLIGHT_SHA
data_dir = ROOT / 'nested-key-attribution-identity-761-a1'
assert data_dir.is_dir() and not data_dir.is_symlink()
assert not list(data_dir.glob('measure-*.jsonl'))
preflight_jsonl = data_dir / 'preflight-preflight.jsonl'
assert digest_file(preflight_jsonl) == EXPECTED_PREFLIGHT_SHA
fixture_manifest_path = data_dir / 'fixtures.json'
fixture_manifest = json.loads(fixture_manifest_path.read_text())
assert len(fixture_manifest) == decision['fixtures']['fixtures'] == 48
assert digest_file(fixture_manifest_path) == decision['fixtures']['manifest_sha256']
fixture_paths = []
for row in fixture_manifest:
    path = Path(row['path'])
    assert path.is_relative_to(data_dir / 'fixtures') and path.is_file()
    assert path.stat().st_size == row['length'] and digest_file(path) == row['sha256']
    fixture_paths.append(path)
witness_paths = sorted((data_dir / 'witnesses').glob('*.json'))
assert len(witness_paths) == 96 and len(decision['verified_witnesses']) == 92
verified_witnesses = sorted((row['bytes'], row['sha256'])
                            for row in decision['verified_witnesses'])
actual_witnesses = sorted((p.stat().st_size, digest_file(p)) for p in witness_paths)
assert all(actual_witnesses.count(row) >= verified_witnesses.count(row)
           for row in set(verified_witnesses))
not_in_verified_list = sorted(
    str(path.relative_to(ROOT)) for path in witness_paths
    if (path.stat().st_size, digest_file(path)) not in set(verified_witnesses))
assert len(not_in_verified_list) == 4

failed_clippy = json.loads((ROOT / 'nested-identity-clippy-761.json').read_text())
assert failed_clippy['status'] == 'failed'
failed_validator_log = ROOT / 'nested-identity-preflight-driver-761.log'
assert failed_validator_log.is_file()
assert 'missing candidate activation' in failed_validator_log.read_text(errors='replace')
assert 'diagnosis_limit' in decision and decision['diagnosis_limit']

# Include all scoped 761/762 evidence, preserving the initial failures with the
# later preflight decision and validator-test pass.
members = {}
root_evidence = sorted(
    p for p in ROOT.glob('nested-identity-*')
    if p.is_file() and not p.is_symlink()
    and p.suffix.lower() in {'.json', '.log', '.patch', '.txt'})
assert len(root_evidence) >= 30
for path in root_evidence:
    add_file(members, 'evidence/' + path.name, path)
add_file(members, 'evidence/nested-key-identity-protocol-761.json', protocol_path)

# Include fixtures.json, the sole raw preflight stream, and every witness; keep
# Vortex payload bytes out of the archive and list their exact identities.
add_file(members, 'evidence/' + str(fixture_manifest_path.relative_to(ROOT)), fixture_manifest_path)
add_file(members, 'evidence/' + str(preflight_jsonl.relative_to(ROOT)), preflight_jsonl)
for path in witness_paths:
    add_file(members, 'evidence/' + str(path.relative_to(ROOT)), path)

for path in sorted(extra_dir.rglob('*')):
    if path.is_file():
        assert not path.is_symlink()
        add_file(members, str(Path('sources') / path.relative_to(ROOT)), path)

# Include both the candidate driver and its attribution-driver/analyzer closure,
# then the decision, preflight, and analyzer validation scripts.
required_tools = {
    'nested_identity_driver_761.py',
    'nested_attribution_driver_760.py',
    'analyze_nested_identity_761.py',
    'analyze_nested_attribution_760.py',
    'preflight_nested_identity_761.py',
    'decide_nested_identity_preflight_762.py',
    'test_nested_identity_analyzer_762.py',
    'run_guarded_observed_757.py',
    'package_nested_identity_762.py',
}
for name in sorted(required_tools):
    path = ROOT / name
    assert path.is_file(), f'missing required tool/source: {path}'
    add_file(members, 'tools/' + name, path)
# The attribution analyzer/driver closure uses this pinned protocol. The separate
# attribution packet remains a distinct artifact and is not copied into this one.
add_file(members, 'tools/nested-key-attribution-protocol-759.json',
         ROOT / 'nested-key-attribution-protocol-759.json')

# Compact transitive source closure for run_guarded_observed_757.py.
repo_scripts = REPO / 'scripts'
external_tools = {
    'tools/local_uat_storage.py': repo_scripts / 'local_uat_storage.py',
    'tools/run_clickbench_paired_query_uat.py': repo_scripts / 'run_clickbench_paired_query_uat.py',
    'tools/run_clickbench_query_uat.py': repo_scripts / 'run_clickbench_query_uat.py',
    'tools/native_workflow_protocol.py': repo_scripts / 'native_workflow_protocol.py',
    'tools/query_timing_report.py': repo_scripts / 'query_timing_report.py',
    'tools/clickbench_reference_packet.py': repo_scripts / 'clickbench_reference_packet.py',
    'tools/release_validation_guard.py':
        Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'),
    'tools/bounded_build_process_resume_20260912.py':
        Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py'),
}
for archive_name, source_path in external_tools.items():
    add_file(members, archive_name, source_path)
assert digest_file(external_tools['tools/bounded_build_process_resume_20260912.py']) == (
    EXPECTED_SUPERVISOR_SHA)

# Exact, historical identities for the omitted copied test executable and all
# Vortex fixture payloads. Every omission points to its included reproduction
# source and receipt. Cargo compiler outputs use a compact packaging-time index:
# the included Cargo JSON logs list exact paths; outputs are rebuildable.
omitted_artifacts = []
omitted_state = {}


def record_omission(path, category, reproduction):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    row = {'path': str(path), 'bytes': path.stat().st_size,
           'sha256': digest_file(path), 'copied': False,
           'category': category, 'source_reproduction': reproduction}
    omitted_artifacts.append(row)
    omitted_state[str(path)] = (row['bytes'], row['sha256'])
    return row


executable_reproduction = {
    'artifact_record': 'evidence/nested-identity-preflight-761-artifact.json',
    'build_receipt': 'evidence/nested-identity-build-761.json',
    'build_log': 'evidence/nested-identity-build-761.log',
    'source_freeze': 'evidence/nested-identity-preflight-761-source-freeze.json',
    'test_inventory': 'evidence/nested-identity-preflight-761-test-inventory.txt',
    'reproduction_command': build_receipt['command'],
}
record_omission(copied_executable, 'copied_test_executable', executable_reproduction)
fixture_omissions = []
for path in fixture_paths:
    fixture_omissions.append(record_omission(path, 'vortex_fixture_payload', {
        'manifest': 'evidence/' + str(fixture_manifest_path.relative_to(ROOT)),
        'driver': 'tools/nested_identity_driver_761.py',
        'source_freeze': 'evidence/nested-identity-preflight-761-source-freeze.json',
        'artifact_record': 'evidence/nested-identity-preflight-761-artifact.json',
        'mode': 'fixtures', 'data_directory': data_dir.name,
        'reproduction_command': [
            'python3', 'nested_identity_driver_761.py', 'run',
            '--label', 'nested-identity-preflight-761', '--name',
            'nested-identity-fixtures-reproduction', '--mode', 'fixtures',
            '--data', data_dir.name],
    }))

cargo_outputs = {}
cargo_logs = sorted(p for p in ROOT.glob('nested-identity-*.log') if p.is_file())
for log_path in cargo_logs:
    for line in log_path.open(errors='replace'):
        if not line.startswith('{'):
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get('reason') != 'compiler-artifact':
            continue
        outputs = list(event.get('filenames', []))
        if event.get('executable'):
            outputs.append(event['executable'])
        for output in outputs:
            path = Path(output)
            assert path.is_absolute() and str(path).startswith(
                '/Users/dylan/.cache/shardloom/cargo-target/')
            assert path.is_file() and not path.is_symlink(), path
            cargo_outputs.setdefault(str(path), set()).add(log_path.name)
assert cargo_outputs
cargo_output_bytes = sum(Path(path).stat().st_size for path in cargo_outputs)
cargo_suffix_counts = dict(sorted(Counter(Path(path).suffix or '<none>'
                                           for path in cargo_outputs).items()))

# Freeze and verify packet inputs before and after writing the deterministic
# archive, then reopen every member and compare its exact source bytes/hash.
inventory = []
members_before = {}
for archive_name, source_path in sorted(members.items()):
    data = source_path.read_bytes()
    row = {'path': archive_name, 'original_path': str(source_path),
           'bytes': len(data), 'sha256': digest(data)}
    inventory.append(row)
    members_before[archive_name] = (row['bytes'], row['sha256'])
uncompressed_bytes = sum(row['bytes'] for row in inventory)
assert uncompressed_bytes < 128 * MIB
assert sum(1 for row in inventory if '/witnesses/' in row['path']) == 96
assert any(row['path'].endswith('preflight-preflight.jsonl') for row in inventory)
assert not any(row['path'].endswith('.vortex') for row in inventory)
assert not any(row['path'].endswith('-test') for row in inventory)
assert not any('measure-' in row['path'] and row['path'].endswith('.jsonl')
               for row in inventory)

require_local_path(DEST, Path.home(), sys.platform)
check_budgets(ROOT, DEST, ROOT / 'logs', min_free_bytes=12 * GIB,
              reserve_bytes=128 * MIB, max_workspace_bytes=100 * GIB,
              max_log_bytes=192 * MIB)
assert not DEST.exists(), f'unique packet destination required: {DEST}'
DEST.mkdir()
archive = DEST / (NAME + '.tar.xz')
with tarfile.open(archive, mode='w:xz', format=tarfile.PAX_FORMAT, preset=6) as output:
    for row in inventory:
        data = members[row['path']].read_bytes()
        assert len(data) == row['bytes'] and digest(data) == row['sha256']
        info = tarfile.TarInfo(row['path'])
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        output.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:xz') as source:
    assert source.getnames() == [row['path'] for row in inventory]
    for row in inventory:
        data = source.extractfile(row['path']).read()
        assert len(data) == row['bytes'] and digest(data) == row['sha256']
for archive_name, source_path in members.items():
    data = source_path.read_bytes()
    assert (len(data), digest(data)) == members_before[archive_name], source_path
for path_text, expected in omitted_state.items():
    path = Path(path_text)
    assert (path.stat().st_size, digest_file(path)) == expected, path

manifest_data = {'schema_version': 'shardloom.evidence_member_manifest.v1',
                 'all_members_reopened': True, 'members': inventory}
manifest_path = DEST / (NAME + '.manifest.json.xz')
manifest_path.write_bytes(lzma.compress(encode(manifest_data), preset=6))
assert json.loads(lzma.decompress(manifest_path.read_bytes())) == manifest_data

index = {
    'schema_version': 'shardloom.nested_key_identity_preflight_packet.v1',
    'scope': 'frozen nested identity candidate rejected in preflight before performance comparison',
    'outcome': decision['outcome'],
    'candidate_accepted': False,
    'timing_comparison_started': False,
    'candidate_implemented': False,
    'broader_owner_and_conditional_substep_remain_open': True,
    'owner': protocol['owner'],
    'decision': {'path': 'evidence/nested-identity-preflight-decision-762.json',
                 'bytes': decision_path.stat().st_size,
                 'sha256': digest_file(decision_path)},
    'protocol': {'path': 'evidence/nested-key-identity-protocol-761.json',
                 'sha256': EXPECTED_PROTOCOL_SHA},
    'semantics_and_resources': {
        'workflows': decision['complete_semantics_workflows'],
        'operations': decision['complete_semantics_operations'],
        'native_certificates_and_resource_cleanup':
            decision['complete_semantics_native_certificates_and_resource_cleanup'],
    },
    'activation_gate': {
        'status': decision['frozen_activation_gate'],
        'required_target_cells': decision['required_target_cells'],
        'activated_target_cells': decision['activated_target_cells'],
        'activation_failures': decision['activation_failures'],
        'all_target_counters': decision['all_target_counters'],
    },
    'diagnosis_limit': decision['diagnosis_limit'],
    'root_cause_measured': False,
    'next_mechanism_requirement': decision['next_mechanism_requirement'],
    'no_measurement_files': True,
    'raw_preflight_sha256': EXPECTED_PREFLIGHT_SHA,
    'copied_test_executable': {
        'path': str(copied_executable), 'bytes': artifact['bytes'],
        'sha256': EXPECTED_EXECUTABLE_SHA,
        'artifact_record': 'evidence/nested-identity-preflight-761-artifact.json',
    },
    'candidate_runtime_source_binding': {
        'worktree': str(REPO), 'head': freeze['head'],
        'tracked_source_file_count': len(freeze['sources']),
        'source_freeze': 'evidence/nested-identity-preflight-761-source-freeze.json',
        'source_freeze_sha256': digest_file(freeze_path),
        'verified_against_current_worktree': True,
        'untracked_extra_sources': extra_bindings,
    },
    'fixture_witness_coverage': {
        'fixtures_manifest': 'evidence/' + str(fixture_manifest_path.relative_to(ROOT)),
        'fixture_count': len(fixture_omissions),
        'witness_count': len(witness_paths),
        'decision_verified_witness_count': len(decision['verified_witnesses']),
        'witness_files_not_listed_as_verified': not_in_verified_list,
        'raw_preflight_jsonl': 'evidence/' + str(preflight_jsonl.relative_to(ROOT)),
    },
    'excluded_artifacts': omitted_artifacts,
    'excluded_cargo_outputs': {
        'status': 'rebuildable_packaging_time_inventory',
        'unique_paths': len(cargo_outputs),
        'aggregate_bytes': cargo_output_bytes,
        'suffix_counts': cargo_suffix_counts,
        'exact_paths_are_recorded_in': ['evidence/' + path.name for path in cargo_logs],
        'source_reproduction': {
            'build_receipt': 'evidence/nested-identity-build-761.json',
            'build_log': 'evidence/nested-identity-build-761.log',
            'command': 'cargo test --offline --locked --release -p shardloom-vortex --features release-user-surfaces --lib --no-run --message-format=json',
        },
    },
    'failed_initial_evidence': [
        'evidence/nested-identity-clippy-761.json',
        'evidence/nested-identity-clippy-761.log',
        'evidence/nested-identity-preflight-driver-761.log',
    ],
    'separate_attribution_packet_reference':
        'nested-key-attribution-760.* (copied unchanged as a separate packet)',
    'binary_fixture_and_cargo_outputs_copied': False,
    'member_count': len(inventory),
    'uncompressed_bytes': uncompressed_bytes,
    'all_members_reopened': True,
    'archive': {'file': archive.name, 'bytes': archive.stat().st_size,
                'sha256': digest_file(archive)},
    'manifest': {'file': manifest_path.name, 'bytes': manifest_path.stat().st_size,
                 'sha256': digest_file(manifest_path)},
}
index_path = DEST / (NAME + '.json')
index_path.write_bytes(encode(index))
check_budgets(ROOT, DEST, ROOT / 'logs', min_free_bytes=12 * GIB,
              reserve_bytes=0, max_workspace_bytes=100 * GIB,
              max_log_bytes=192 * MIB)
print(json.dumps({'status': 'passed', 'members': len(inventory),
                  'uncompressed_bytes': uncompressed_bytes,
                  'archive_bytes': index['archive']['bytes'],
                  'manifest_bytes': index['manifest']['bytes'],
                  'fixtures': len(fixture_omissions),
                  'witnesses': len(witness_paths),
                  'cargo_outputs': len(cargo_outputs),
                  'all_members_reopened': True, 'output': str(index_path)}))
