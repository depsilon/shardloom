"""Challenge the identity validator without changing or rerunning native evidence."""
import copy
import hashlib
import json
from pathlib import Path
import analyze_nested_identity_761 as a

OUT=Path(__file__).resolve().parent
ROOT=OUT/'nested-key-attribution-identity-761-a1'
records=[json.loads(line) for line in (ROOT/'preflight-preflight.jsonl').read_text().splitlines()]
specs=list(a.oracle.specs())
spec=next(s for s in specs if a.target(s))
original=next(r for r in records if r['cell_id']==a.oracle.cell_id(spec) and r['profile']=='candidate')

def check(record,cell=spec,role='candidate'):
    a.validate(record,cell,role,0,False,'preflight',a.oracle.Witnesses(ROOT))

check(original)
cases=[
    ('wrong_actual_values',['operations',0,'actual_rows_witness'],'0'*64),
    ('wrong_expected_values',['expected_rows_witness'],'0'*64),
    ('wrong_schema',['operations',0,'actual_schema_witness'],'0'*64),
    ('remaining_reservation',['reserved_after_cleanup'],1),
    ('denied_reservation',['denied_reservations'],1),
    ('observer_enabled',['observation','stages','key_owner_construction','root_calls'],1),
    ('undrained_root',['observation','active_roots_after_drain'],1),
    ('wrong_call_count',['completed_executions'],2),
    ('wrong_sample',['sample'],1),
    ('wrong_role',['profile'],'baseline'),
    ('fallback',['operations',0,'native_io_certificate','fallback_attempted'],True),
    ('uncertified',['operations',0,'native_io_certificate','certified'],False),
    ('negative_engine_clock',['operations',0,'engine_execution_ns'],-1),
    ('incomplete_workflow_clock',['complete_workflow_ns'],1),
    ('missing_activation',['identity','activated_owners'],0),
    ('missing_mapping',['identity','mapped_rows'],0),
    ('missing_entries',['identity','canonical_entries'],0),
    ('too_many_entries',['identity','canonical_entries'],64*original['identity']['activated_owners']+1),
    ('missing_cached_writes',['identity','cached_writes'],0),
    ('missing_domain_serialization',['identity','serialized_domain_entries'],0),
    ('excess_domain_serialization',['identity','serialized_domain_entries'],original['identity']['mapped_rows']+1),
]
rejected=[]
for name,keys,replacement in cases:
    bad=copy.deepcopy(original)
    target=bad
    for key in keys[:-1]:target=target[key]
    target[keys[-1]]=replacement
    try:check(bad)
    except (AssertionError,KeyError):rejected.append(name)
    else:raise AssertionError(f'corrupt record accepted: {name}')
for role,cell in [('baseline',spec),('candidate',next(s for s in specs if not a.target(s)))]:
    bad=copy.deepcopy(next(r for r in records if r['cell_id']==a.oracle.cell_id(cell) and r['profile']==role))
    check(bad,cell,role)
    bad['identity']['activated_owners']=1
    try:check(bad,cell,role)
    except AssertionError:rejected.append(f'unexpected_{role}_activation_{cell["consumer"]}')
    else:raise AssertionError('non-target activation accepted')

def cohorts():
    result={}
    for cohort in ['A','B']:
        rows=[]
        for cell in specs:
            for role in ['baseline','candidate']:
                improvement=role=='candidate' and a.target(cell)
                for _ in range(3):
                    rows.append(dict(cell_id=a.oracle.cell_id(cell),profile=role,warmup=False,
                        operations=[dict(engine_execution_ns=18_000_000 if improvement else 20_000_000)],
                        complete_workflow_ns=28_000_000 if improvement else 30_000_000))
        result[cohort]=rows
    return result

positive=cohorts()
assert a.analyze(positive)['finite_comparison_passed']
gate_cases=[]
for name,field,value in [('engine_control_regression','engine',21_000_001),('complete_control_regression','complete',31_500_001)]:
    bad=cohorts();identity=a.oracle.cell_id(next(s for s in specs if not a.target(s)))
    for row in bad['A']:
        if row['cell_id']==identity and row['profile']=='candidate':
            if field=='engine':row['operations'][0]['engine_execution_ns']=value
            else:row['complete_workflow_ns']=value
    assert not a.analyze(bad)['finite_comparison_passed'];gate_cases.append(name)
for name,selector in [
    ('one_shape_only',lambda cohort,s:s['shape']=='struct_list_i64'),
    ('different_shapes_across_cohorts',lambda cohort,s:s['shape']==('list_i64' if cohort=='A' else 'struct_list_i64')),
    ('no_large_cell_benefit',lambda cohort,s:s['rows']==4096),
    ('no_target_benefit',lambda cohort,s:True),
]:
    bad=cohorts()
    for cohort,rows in bad.items():
        refused={a.oracle.cell_id(s) for s in specs if a.target(s) and selector(cohort,s)}
        for row in rows:
            if row['profile']=='candidate' and row['cell_id'] in refused:
                row['operations'][0]['engine_execution_ns']=20_000_000
                row['complete_workflow_ns']=30_000_000
    assert not a.analyze(bad)['finite_comparison_passed'];gate_cases.append(name)
a.self_tests()
result=dict(status='passed',corruption_cases_rejected=rejected,finite_gate_cases_rejected=gate_cases,
    positive_complete_gate='passed',score_boundary_tests='passed',
    analyzer_sha256=a.sha(a.__file__),oracle_sha256=a.sha(a.oracle.__file__),
    test_sha256=a.sha(__file__),preflight_sha256=a.sha(ROOT/'preflight-preflight.jsonl'))
with (OUT/'nested-identity-analyzer-tests-762.json').open('x') as stream:
    json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps(result))
