"""Use the verified source/artifact/guard driver with the frozen identity protocol."""
import nested_attribution_driver_760 as driver

driver.PROTOCOL = driver.OUT / 'nested-key-identity-protocol-761.json'
driver.PROTOCOL_SHA = 'e083f4c3e25e5a85d3574aaf1b34d4fc30d76ccd46313dd5958cb4b19e6751e9'
driver.SELECTOR = 'local_primitives::prepared_relational::tests::nested_key_cost_tests::native_nested_key_identity_screen'
# The shared implementation records this wrapper's identity; measurement freeze
# additionally binds both files, rather than treating the wrapper as the closure.
driver.__file__ = __file__
if __name__ == '__main__':
    driver.main()
