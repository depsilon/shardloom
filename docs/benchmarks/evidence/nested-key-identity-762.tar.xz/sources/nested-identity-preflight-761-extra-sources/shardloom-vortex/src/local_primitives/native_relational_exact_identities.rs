//! Bounded exact unary identities from referenced native dictionary domains.
//! Relational normalized comparison/hashing and native output payloads are unchanged.

use super::{KeyColumn, failed, vortex_error};
use crate::local_primitives::{AggregateDistinctValue, NativeNumericOwner};
use shardloom_core::Result;
use shardloom_exec::{
    compute_pool::CancellationToken,
    live_memory::{LiveMemoryPool, MemoryLease},
};
use std::hash::Hasher as _;
use vortex::array::{
    ArrayRef, ExecutionCtx,
    arrays::{
        Chunked, Dict, PrimitiveArray, chunked::ChunkedArrayExt as _, dict::DictArraySlotsExt as _,
    },
    dtype::DType,
};

const MAX_ENTRIES: usize = 64;
const MAX_KEY_BYTES: usize = 16 << 10;
const BUILD_CREDIT: u64 = 4 << 20;

pub(in crate::local_primitives) enum ExactKeyColumn {
    Recursive(KeyColumn),
    Dictionary(Identities),
}

impl ExactKeyColumn {
    pub(in crate::local_primitives) fn new(
        array: &ArrayRef,
        context: &mut ExecutionCtx,
        memory: &LiveMemoryPool,
        cancellation: &CancellationToken,
    ) -> Result<Self> {
        #[cfg(all(test, feature = "vortex-write"))]
        let enabled = test_support::enabled();
        #[cfg(not(all(test, feature = "vortex-write")))]
        let enabled = true;
        if enabled
            && let Some(identities) =
                Identities::build(array, context, memory, cancellation, key_hash)?
        {
            return Ok(Self::Dictionary(identities));
        }
        KeyColumn::new(array, context, memory, cancellation).map(Self::Recursive)
    }

    pub(in crate::local_primitives) fn write_exact_key(
        &self,
        row: usize,
        output: &mut impl std::fmt::Write,
        cancellation: &CancellationToken,
    ) -> Result<()> {
        cancellation.check()?;
        match self {
            Self::Recursive(key) => key.write_exact_key(row, output, cancellation),
            Self::Dictionary(keys) => {
                let index = *keys
                    .rows
                    .get(row)
                    .ok_or_else(|| failed("exact identity row exceeds input"))?;
                let value = &keys.entries[index as usize].value;
                #[cfg(all(test, feature = "vortex-write"))]
                test_support::record(3, 1);
                // Admitted integer/bool/null keys, field names included, are UTF-8.
                let mut start = 0;
                while start < value.len() {
                    cancellation.check()?;
                    let mut end = (start + 1024).min(value.len());
                    while !value.is_char_boundary(end) {
                        end -= 1;
                    }
                    output.write_str(&value[start..end]).map_err(vortex_error)?;
                    start = end;
                }
                cancellation.check()
            }
        }
    }
}

struct Entry {
    hash: u64,
    value: String,
}

// All owned vectors and strings drop before the construction/retention credit.
pub(in crate::local_primitives) struct Identities {
    rows: Vec<u32>,
    entries: Vec<Entry>,
    serialized_domains: u64,
    ownership: MemoryLease,
}

fn key_hash(value: &str) -> u64 {
    let mut hash = rustc_hash::FxHasher::default();
    hash.write(value.as_bytes());
    hash.finish()
}

fn safe_dtype(dtype: &DType, depth: usize) -> bool {
    if depth > 24 {
        return false;
    }
    match dtype {
        DType::Null | DType::Bool(_) => true,
        DType::Primitive(_, _) => dtype.is_int(),
        DType::List(child, _) | DType::FixedSizeList(child, _, _) => safe_dtype(child, depth + 1),
        DType::Struct(fields, _) => fields.fields().all(|child| safe_dtype(&child, depth + 1)),
        _ => false,
    }
}

fn dictionary_tree(array: &ArrayRef, depth: usize) -> bool {
    if depth > 24 {
        return false;
    }
    if array.is_empty() {
        return true;
    }
    if let Some(chunks) = array.as_opt::<Chunked>() {
        return chunks
            .iter_chunks()
            .all(|chunk| dictionary_tree(chunk, depth + 1));
    }
    array.as_opt::<Dict>().is_some_and(|dictionary| {
        let domain = dictionary.values().len();
        domain <= MAX_ENTRIES && domain <= array.len() / 2
    })
}

impl Identities {
    fn build(
        array: &ArrayRef,
        context: &mut ExecutionCtx,
        memory: &LiveMemoryPool,
        cancellation: &CancellationToken,
        hash: fn(&str) -> u64,
    ) -> Result<Option<Self>> {
        cancellation.check()?;
        if !(128..=65_536).contains(&array.len())
            || !crate::local_primitives::native_payload::is_nested(array.dtype())
            || !safe_dtype(array.dtype(), 0)
            || !dictionary_tree(array, 0)
        {
            return Ok(None);
        }
        let snapshot = memory.snapshot();
        if snapshot.limit_bytes.saturating_sub(snapshot.reserved_bytes) < 2 * BUILD_CREDIT {
            return Ok(None);
        }
        let ownership = memory.reserve(BUILD_CREDIT)?;
        let mut rows = Vec::new();
        rows.try_reserve_exact(array.len()).map_err(vortex_error)?;
        if rows.capacity() > array.len() {
            return Err(failed("identity row capacity exceeded credit"));
        }
        let mut entries = Vec::new();
        entries
            .try_reserve_exact(MAX_ENTRIES)
            .map_err(vortex_error)?;
        if entries.capacity() > MAX_ENTRIES {
            return Err(failed("identity entry capacity exceeded credit"));
        }
        let mut result = Self {
            rows,
            entries,
            serialized_domains: 0,
            ownership,
        };
        if !result.append(array, context, memory, cancellation, hash, 0)? {
            return Ok(None);
        }
        if result.rows.len() != array.len() {
            return Err(failed("exact identity row mapping changed length"));
        }
        let retained = result.rows.capacity() * size_of::<u32>()
            + result.entries.capacity() * size_of::<Entry>()
            + result
                .entries
                .iter()
                .map(|entry| entry.value.capacity())
                .sum::<usize>()
            + size_of::<Self>();
        // Maximum row vector, 64 entries, and one temporary 16-KiB key fit the
        // frozen construction credit without vector reallocation or overlap.
        if retained as u64 > BUILD_CREDIT {
            return Err(failed("exact identities exceeded construction credit"));
        }
        result.ownership.resize(retained as u64)?;
        #[cfg(all(test, feature = "vortex-write"))]
        {
            test_support::record(0, 1);
            test_support::record(1, result.rows.len() as u64);
            test_support::record(2, result.entries.len() as u64);
            test_support::record(4, result.serialized_domains);
        }
        Ok(Some(result))
    }

    #[allow(clippy::too_many_arguments)] // Recursion retains the same admitted owner, context and cancellation scope.
    fn append(
        &mut self,
        array: &ArrayRef,
        context: &mut ExecutionCtx,
        memory: &LiveMemoryPool,
        cancellation: &CancellationToken,
        hash: fn(&str) -> u64,
        depth: usize,
    ) -> Result<bool> {
        cancellation.check()?;
        if depth > 24 {
            return Err(failed("identity wrapper depth exceeds admission"));
        }
        if array.is_empty() {
            return Ok(true);
        }
        if let Some(chunks) = array.as_opt::<Chunked>() {
            for chunk in chunks.iter_chunks() {
                if !self.append(chunk, context, memory, cancellation, hash, depth + 1)? {
                    return Ok(false);
                }
            }
            return Ok(true);
        }
        let dictionary = array
            .as_opt::<Dict>()
            .ok_or_else(|| failed("identity dictionary changed after admission"))?;
        let domain = dictionary.values();
        let key = KeyColumn::new(domain, context, memory, cancellation)?;
        let native_codes = dictionary
            .codes()
            .clone()
            .execute::<PrimitiveArray>(context)
            .map_err(vortex_error)?;
        if native_codes.len() != array.len() || native_codes.dtype() != dictionary.codes().dtype() {
            return Err(failed("identity code execution changed dtype or rows"));
        }
        let codes = NativeNumericOwner::new(native_codes, context)?;
        let mut local = [None; MAX_ENTRIES];
        let mut null_identity = None;
        for row in 0..array.len() {
            if row.is_multiple_of(1024) {
                cancellation.check()?;
            }
            let code = match codes.distinct_value(row)? {
                AggregateDistinctValue::Null => None,
                AggregateDistinctValue::Int64(value) => {
                    Some(usize::try_from(value).map_err(vortex_error)?)
                }
                AggregateDistinctValue::UInt64(value) => {
                    Some(usize::try_from(value).map_err(vortex_error)?)
                }
                _ => return Err(failed("identity dictionary code is not an integer")),
            };
            let existing = match code {
                Some(code) if code < domain.len() => local[code],
                Some(_) => return Err(failed("identity dictionary code exceeds its domain")),
                None => null_identity,
            };
            let identity = if let Some(identity) = existing {
                identity
            } else {
                let value = if let Some(code) = code {
                    let mut count = BoundedCount::default();
                    let counted = key.write_exact_key(code, &mut count, cancellation);
                    if count.exceeded {
                        cancellation.check()?;
                        return Ok(false);
                    }
                    counted?;
                    let mut value = String::new();
                    value.try_reserve_exact(count.bytes).map_err(vortex_error)?;
                    if value.capacity() > count.bytes {
                        return Err(failed("identity key capacity exceeded credit"));
                    }
                    key.write_exact_key(code, &mut value, cancellation)?;
                    if value.len() != count.bytes {
                        return Err(failed("identity key changed during construction"));
                    }
                    self.serialized_domains += 1;
                    value
                } else {
                    "n;".to_owned()
                };
                let Some(identity) = self.intern(value, hash)? else {
                    return Ok(false);
                };
                match code {
                    Some(code) => local[code] = Some(identity),
                    None => null_identity = Some(identity),
                }
                identity
            };
            self.rows.push(identity);
        }
        cancellation.check()?;
        Ok(true)
    }

    fn intern(&mut self, value: String, hash: fn(&str) -> u64) -> Result<Option<u32>> {
        let hash = hash(&value);
        // Hashes choose candidates only. Exact bytes certify equality, including
        // distinct codes and separate dictionary domains with overlapping values.
        if let Some(index) = self
            .entries
            .iter()
            .position(|entry| entry.hash == hash && entry.value == value)
        {
            return u32::try_from(index).map(Some).map_err(vortex_error);
        }
        if self.entries.len() == MAX_ENTRIES {
            return Ok(None);
        }
        let identity = u32::try_from(self.entries.len()).map_err(vortex_error)?;
        self.entries.push(Entry { hash, value });
        Ok(Some(identity))
    }
}

#[derive(Default)]
struct BoundedCount {
    bytes: usize,
    exceeded: bool,
}
impl std::fmt::Write for BoundedCount {
    fn write_str(&mut self, value: &str) -> std::fmt::Result {
        if let Some(bytes) = self
            .bytes
            .checked_add(value.len())
            .filter(|&bytes| bytes <= MAX_KEY_BYTES)
        {
            self.bytes = bytes;
            Ok(())
        } else {
            self.exceeded = true;
            Err(std::fmt::Error)
        }
    }
}

#[cfg(all(test, feature = "vortex-write"))]
pub(in crate::local_primitives) mod test_support {
    use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
    static ENABLED: AtomicBool = AtomicBool::new(true);
    static SESSION: AtomicBool = AtomicBool::new(false);
    static COUNTS: [AtomicU64; 5] = [const { AtomicU64::new(0) }; 5];
    pub(super) fn enabled() -> bool {
        ENABLED.load(Ordering::Relaxed)
    }
    pub(super) fn record(index: usize, count: u64) {
        if SESSION.load(Ordering::Relaxed) {
            COUNTS[index].fetch_add(count, Ordering::Relaxed);
        }
    }
    pub(in crate::local_primitives) struct Session;
    impl Session {
        pub(in crate::local_primitives) fn start(enabled: bool) -> Self {
            assert!(
                !SESSION.swap(true, Ordering::SeqCst),
                "identity comparison is serial only"
            );
            for count in &COUNTS {
                count.store(0, Ordering::Relaxed);
            }
            ENABLED.store(enabled, Ordering::SeqCst);
            Self
        }
        pub(in crate::local_primitives) fn finish(self) -> serde_json::Value {
            let names = [
                "activated_owners",
                "mapped_rows",
                "canonical_entries",
                "cached_writes",
                "serialized_domain_entries",
            ];
            let result = names
                .into_iter()
                .enumerate()
                .map(|(i, name)| {
                    (
                        name.to_owned(),
                        serde_json::json!(COUNTS[i].load(Ordering::Relaxed)),
                    )
                })
                .collect::<serde_json::Map<_, _>>();
            drop(self);
            serde_json::Value::Object(result)
        }
    }
    impl Drop for Session {
        fn drop(&mut self) {
            ENABLED.store(true, Ordering::SeqCst);
            SESSION.store(false, Ordering::SeqCst);
        }
    }
}

#[cfg(all(test, feature = "vortex-write"))]
#[path = "native_relational_exact_identities_tests.rs"]
mod tests;
