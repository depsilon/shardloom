use super::*;
use vortex::array::{
    IntoArray as _, VortexSessionExecute as _,
    arrays::{BoolArray, ChunkedArray, DictArray, FixedSizeListArray, ListViewArray, StructArray},
    dtype::FieldNames,
    validity::Validity,
};

fn lists(rows: &[Option<Vec<Option<i64>>>]) -> ArrayRef {
    let mut children = Vec::new();
    let mut offsets = Vec::new();
    let mut sizes = Vec::new();
    for row in rows {
        offsets.push(children.len() as u64);
        sizes.push(row.as_ref().map_or(0, Vec::len) as u64);
        if let Some(row) = row {
            children.extend(row.iter().copied());
        }
    }
    ListViewArray::try_new(
        PrimitiveArray::from_option_iter(children).into_array(),
        PrimitiveArray::from_iter(offsets).into_array(),
        PrimitiveArray::from_iter(sizes).into_array(),
        Validity::from_iter(rows.iter().map(Option::is_some)),
    )
    .unwrap()
    .into_array()
}

fn dict(domain: ArrayRef, codes: impl IntoIterator<Item = Option<u32>>) -> ArrayRef {
    DictArray::try_new(PrimitiveArray::from_option_iter(codes).into_array(), domain)
        .unwrap()
        .into_array()
}

fn expected(row: Option<&Vec<Option<i64>>>) -> String {
    let Some(row) = row else {
        return "n;".into();
    };
    let mut result = format!("L{}:", row.len());
    for value in row {
        result.push_str(&value.map_or_else(|| "n;".into(), |value| format!("i{value};")));
    }
    result
}

#[test]
fn native_exact_identities_cross_domain_collisions_null_codes_and_source_drop() {
    let domains = [
        vec![None, Some(vec![None, Some(-4), Some(12)]), Some(vec![])],
        vec![
            Some(vec![Some(99)]),
            Some(vec![]),
            Some(vec![None, Some(-4), Some(12)]),
        ],
    ];
    let mut oracle = Vec::new();
    let chunks = domains
        .iter()
        .map(|domain| {
            let codes = (0..128)
                .map(|row| (row % 7 != 0).then_some(u32::try_from(row % 3).unwrap()))
                .collect::<Vec<_>>();
            oracle.extend(
                codes
                    .iter()
                    .map(|code| expected(code.and_then(|code| domain[code as usize].as_ref()))),
            );
            dict(lists(domain), codes)
        })
        .collect::<Vec<_>>();
    let array = ChunkedArray::try_new(chunks.clone(), chunks[0].dtype().clone())
        .unwrap()
        .into_array();
    let memory = LiveMemoryPool::new(16 << 20).unwrap();
    let cancellation = CancellationToken::default();
    let mut context = vortex::array::legacy_session().create_execution_ctx();
    let identities = Identities::build(&array, &mut context, &memory, &cancellation, |_| 0)
        .unwrap()
        .unwrap();
    assert_eq!(identities.entries.len(), 4);
    assert_eq!(identities.serialized_domains, 6);
    drop((array, chunks, context));
    assert!(memory.snapshot().reserved_bytes > 0);
    assert!(memory.snapshot().reserved_bytes < BUILD_CREDIT);
    let key = ExactKeyColumn::Dictionary(identities);
    for (row, expected) in oracle.iter().enumerate() {
        let mut actual = String::new();
        key.write_exact_key(row, &mut actual, &cancellation)
            .unwrap();
        assert_eq!(&actual, expected);
    }
    assert!(
        key.write_exact_key(256, &mut String::new(), &cancellation)
            .is_err()
    );
    drop(key);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}

#[test]
fn native_exact_identities_struct_names_parent_validity_and_chunk_order() {
    let domain = StructArray::try_new(
        FieldNames::from(["項目", "tag"]),
        vec![
            lists(&[Some(vec![Some(9)]), Some(vec![]), None]),
            PrimitiveArray::from_option_iter([Some(77i64), None, Some(-2)]).into_array(),
        ],
        3,
        Validity::from_iter([false, true, true]),
    )
    .unwrap()
    .into_array();
    let input = dict(domain, (0..128).map(|row| Some(row % 3)));
    let memory = LiveMemoryPool::new(16 << 20).unwrap();
    let cancellation = CancellationToken::default();
    let key = ExactKeyColumn::new(
        &input,
        &mut vortex::array::legacy_session().create_execution_ctx(),
        &memory,
        &cancellation,
    )
    .unwrap();
    assert!(matches!(key, ExactKeyColumn::Dictionary(_)));
    let expected = ["n;", "S2:6:項目L0:3:tagn;", "S2:6:項目n;3:tagi-2;"];
    for row in 0..128 {
        let mut value = String::new();
        key.write_exact_key(row, &mut value, &cancellation).unwrap();
        assert_eq!(value, expected[row % 3]);
    }
    drop(key);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}

#[test]
fn native_exact_identities_bypass_plain_unique_mixed_low_grant_and_large_domain() {
    let domain = lists(&[None, Some(vec![Some(3)])]);
    let dictionary = dict(domain.clone(), (0..128).map(|row| Some(row % 2)));
    let plain = lists(&vec![Some(vec![Some(3)]); 128]);
    let unique = dict(
        lists(
            &(0..128)
                .map(|row| Some(vec![Some(row)]))
                .collect::<Vec<_>>(),
        ),
        (0..128).map(Some),
    );
    let mixed = ChunkedArray::try_new(
        vec![dictionary.clone(), plain.clone()],
        plain.dtype().clone(),
    )
    .unwrap()
    .into_array();
    for input in [&plain, &unique, &mixed] {
        let memory = LiveMemoryPool::new(16 << 20).unwrap();
        let key = ExactKeyColumn::new(
            input,
            &mut vortex::array::legacy_session().create_execution_ctx(),
            &memory,
            &CancellationToken::default(),
        )
        .unwrap();
        assert!(matches!(key, ExactKeyColumn::Recursive(_)));
        drop(key);
        assert_eq!(memory.snapshot().reserved_bytes, 0);
    }
    let memory = LiveMemoryPool::new(1 << 20).unwrap();
    let key = ExactKeyColumn::new(
        &dictionary,
        &mut vortex::array::legacy_session().create_execution_ctx(),
        &memory,
        &CancellationToken::default(),
    )
    .unwrap();
    assert!(matches!(key, ExactKeyColumn::Recursive(_)));
    drop(key);
    assert_eq!(memory.snapshot().denied_reservations, 0);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    // Each chunk individually qualifies but 65 distinct exact representatives do not.
    let chunks = (0..65)
        .map(|row| dict(lists(&[Some(vec![Some(row)])]), (0..128).map(|_| Some(0))))
        .collect::<Vec<_>>();
    let many = ChunkedArray::try_new(chunks, dictionary.dtype().clone())
        .unwrap()
        .into_array();
    let memory = LiveMemoryPool::new(16 << 20).unwrap();
    assert!(
        Identities::build(
            &many,
            &mut vortex::array::legacy_session().create_execution_ctx(),
            &memory,
            &CancellationToken::default(),
            key_hash
        )
        .unwrap()
        .is_none()
    );
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}

#[test]
fn native_exact_identities_size_refusal_and_failed_cancelled_writes_release() {
    thread_local! { static BUILD_CANCEL: std::cell::RefCell<Option<CancellationToken>> = const { std::cell::RefCell::new(None) }; }
    fn cancel_during_intern(_: &str) -> u64 {
        BUILD_CANCEL.with(|token| token.borrow().as_ref().unwrap().cancel());
        0
    }
    struct Reject;
    impl std::fmt::Write for Reject {
        fn write_str(&mut self, _: &str) -> std::fmt::Result {
            Err(std::fmt::Error)
        }
    }
    struct CancelWriter(CancellationToken);
    impl std::fmt::Write for CancelWriter {
        fn write_str(&mut self, _: &str) -> std::fmt::Result {
            self.0.cancel();
            Ok(())
        }
    }
    let memory = LiveMemoryPool::new(16 << 20).unwrap();
    let mut context = vortex::array::legacy_session().create_execution_ctx();
    let large = dict(
        lists(&[Some(vec![Some(123_456); 4096])]),
        (0..128).map(|_| Some(0)),
    );
    assert!(
        Identities::build(
            &large,
            &mut context,
            &memory,
            &CancellationToken::default(),
            key_hash
        )
        .unwrap()
        .is_none()
    );
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    let input = dict(
        lists(&[Some(vec![Some(123_456); 512])]),
        (0..128).map(|_| Some(0)),
    );
    let cancelled = CancellationToken::default();
    cancelled.cancel();
    assert!(Identities::build(&input, &mut context, &memory, &cancelled, key_hash).is_err());
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    let during = CancellationToken::default();
    BUILD_CANCEL.with(|token| *token.borrow_mut() = Some(during.clone()));
    assert!(
        Identities::build(&input, &mut context, &memory, &during, cancel_during_intern).is_err()
    );
    BUILD_CANCEL.with(|token| *token.borrow_mut() = None);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    let key =
        ExactKeyColumn::new(&input, &mut context, &memory, &CancellationToken::default()).unwrap();
    assert!(matches!(key, ExactKeyColumn::Dictionary(_)));
    assert!(
        key.write_exact_key(0, &mut Reject, &CancellationToken::default())
            .is_err()
    );
    let cancellation = CancellationToken::default();
    assert!(
        key.write_exact_key(0, &mut CancelWriter(cancellation.clone()), &cancellation)
            .is_err()
    );
    drop(key);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}

#[test]
fn native_exact_identities_float_signed_zero_remains_recursive() {
    let lists = ListViewArray::try_new(
        PrimitiveArray::from_iter([-0.0f64, 0.0]).into_array(),
        PrimitiveArray::from_iter([0u64, 1]).into_array(),
        PrimitiveArray::from_iter([1u64, 1]).into_array(),
        Validity::NonNullable,
    )
    .unwrap()
    .into_array();
    let input = DictArray::try_new(
        PrimitiveArray::from_iter((0..128).map(|row| row % 2)).into_array(),
        lists,
    )
    .unwrap()
    .into_array();
    let memory = LiveMemoryPool::new(16 << 20).unwrap();
    let key = ExactKeyColumn::new(
        &input,
        &mut vortex::array::legacy_session().create_execution_ctx(),
        &memory,
        &CancellationToken::default(),
    )
    .unwrap();
    assert!(matches!(key, ExactKeyColumn::Recursive(_)));
    let mut negative = String::new();
    let mut positive = String::new();
    key.write_exact_key(0, &mut negative, &CancellationToken::default())
        .unwrap();
    key.write_exact_key(1, &mut positive, &CancellationToken::default())
        .unwrap();
    assert_eq!(negative, "L1:f8000000000000000;");
    assert_eq!(positive, "L1:f0000000000000000;");
    drop(key);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}

#[test]
fn native_exact_identities_all_null_and_fixed_boolean_domains_are_exact() {
    let all_null = dict(
        lists(&[None]),
        (0..128).map(|row| (row % 2 == 0).then_some(0)),
    );
    let fixed = FixedSizeListArray::try_new(
        BoolArray::from_iter([true, false]).into_array(),
        1,
        Validity::from_iter([true, true]),
        2,
    )
    .unwrap()
    .into_array();
    let fixed = dict(fixed, (0..128).map(|row| Some(row % 2)));
    for (input, expected) in [(all_null, ["n;", "n;"]), (fixed, ["F1:b1;", "F1:b0;"])] {
        let memory = LiveMemoryPool::new(16 << 20).unwrap();
        let token = CancellationToken::default();
        let key = ExactKeyColumn::new(
            &input,
            &mut vortex::array::legacy_session().create_execution_ctx(),
            &memory,
            &token,
        )
        .unwrap();
        assert!(matches!(key, ExactKeyColumn::Dictionary(_)));
        for row in 0..128 {
            let mut actual = String::new();
            key.write_exact_key(row, &mut actual, &token).unwrap();
            assert_eq!(actual, expected[row % 2]);
        }
        drop(key);
        assert_eq!(memory.snapshot().reserved_bytes, 0);
    }
}
