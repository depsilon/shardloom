//! Frozen PERF-05 exact native dictionary identity comparison (protocol 761).

use super::*;
use crate::{
    local_primitives::native_relational_keys::{
        KeyColumn, exact::test_support as identity, observation,
    },
    query_primitive::VortexSimpleAggregateMeasure,
    relational_query::{VortexRelationalAggregate, VortexRelationalUnary},
};
use serde_json::{Value, json};
use sha2::{Digest as _, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    io::Write as _,
    path::Path,
    sync::Arc,
    time::Instant,
};
use vortex::array::{
    arrays::{DictArray, ListViewArray},
    dtype::StructFields,
};

const GRANT: u64 = 128 << 20;
const CHUNK_ROWS: usize = 257;
const CONSUMERS: [&str; 4] = [
    "group_count",
    "count_distinct",
    "left_join",
    "unary_distinct",
];

#[derive(Clone, Copy)]
struct CellSpec {
    rows: usize,
    shape: &'static str,
    domain: &'static str,
    representation: &'static str,
    consumer: &'static str,
    calls: usize,
}

impl CellSpec {
    fn fixture_id(self) -> String {
        format!(
            "{}-{}-{}-{}",
            self.rows, self.shape, self.domain, self.representation
        )
    }

    fn id(self) -> String {
        format!("{}-{}-{}", self.fixture_id(), self.consumer, self.calls)
    }

    fn domains(self) -> Vec<usize> {
        (0..self.rows)
            .map(|row| match self.domain {
                "eight" => row % 8,
                "unique" => row,
                "all_null" => 0,
                _ => panic!("unknown frozen domain"),
            })
            .collect()
    }

    fn right_domains(self) -> Vec<usize> {
        self.domains()
            .into_iter()
            .collect::<BTreeSet<_>>()
            .into_iter()
            .filter(|domain| domain.is_multiple_of(3))
            .flat_map(|domain| [domain, domain])
            .collect()
    }

    fn key_dtype(self) -> DType {
        let list = DType::List(
            Arc::new(DType::Primitive(PType::I64, Nullability::Nullable)),
            Nullability::Nullable,
        );
        if self.shape == "list_i64" {
            list
        } else {
            DType::Struct(
                StructFields::new(
                    FieldNames::from(["items", "tag"]),
                    vec![list, DType::Primitive(PType::I64, Nullability::Nullable)],
                ),
                Nullability::Nullable,
            )
        }
    }

    fn output_dtype(self) -> DType {
        let uint = DType::Primitive(PType::U64, Nullability::NonNullable);
        let (names, types) = match self.consumer {
            "group_count" => (vec!["key", "rows"], vec![self.key_dtype(), uint]),
            "count_distinct" => (vec!["distinct"], vec![uint]),
            "left_join" => (
                vec!["ordinal", "key", "right_ordinal"],
                vec![
                    uint,
                    self.key_dtype(),
                    DType::Primitive(PType::U64, Nullability::Nullable),
                ],
            ),
            "unary_distinct" => (vec!["key"], vec![self.key_dtype()]),
            _ => panic!("unknown frozen consumer"),
        };
        DType::Struct(
            StructFields::new(names.into(), types),
            Nullability::NonNullable,
        )
    }

    fn plan(self, root: &Path) -> VortexRelationalPlan {
        let scan = |side| {
            VortexRelationalPlan::Scan(VortexRelationalScan {
                source_uri: DatasetUri::new(
                    root.join("fixtures")
                        .join(format!("{}-{side}.vortex", self.fixture_id()))
                        .display()
                        .to_string(),
                )
                .unwrap(),
                projection: shardloom_plan::ProjectionRequest::All,
                predicate: None,
            })
        };
        match self.consumer {
            "group_count" | "count_distinct" => {
                let grouped = self.consumer == "group_count";
                VortexRelationalPlan::Aggregate(Box::new(VortexRelationalAggregate {
                    input: scan("left"),
                    group_by: if grouped { vec![column("key")] } else { vec![] },
                    measures: vec![VortexSimpleAggregateMeasure::new(
                        if grouped { "count" } else { "count_distinct" },
                        (!grouped).then(|| column("key")),
                        if grouped { "rows" } else { "distinct" }.into(),
                    )],
                }))
            }
            "left_join" => VortexRelationalPlan::Join(Box::new(VortexRelationalJoin {
                left: scan("left"),
                right: scan("right"),
                kind: JoinKind::Left,
                condition: None,
                keys: vec![VortexRelationalJoinKey {
                    left: column("key"),
                    right: column("key"),
                }],
                columns: vec![
                    VortexRelationalJoinColumn {
                        side: Side::Left,
                        column: column("ordinal"),
                        output_column: "ordinal".into(),
                    },
                    VortexRelationalJoinColumn {
                        side: Side::Left,
                        column: column("key"),
                        output_column: "key".into(),
                    },
                    VortexRelationalJoinColumn {
                        side: Side::Right,
                        column: column("ordinal"),
                        output_column: "right_ordinal".into(),
                    },
                ],
            })),
            "unary_distinct" => VortexRelationalPlan::Unary(Box::new(VortexRelationalUnary {
                input: scan("left"),
                request: VortexQueryPrimitiveRequest::for_relational_input(
                    VortexQueryPrimitiveKind::DistinctRows,
                    shardloom_plan::ProjectionRequest::columns(vec![column("key")]),
                ),
            })),
            _ => panic!("unknown consumer"),
        }
    }

    fn expected(self) -> Vec<Value> {
        let domains = self.domains();
        let mut distinct = Vec::new();
        for domain in &domains {
            if !distinct.contains(domain) {
                distinct.push(*domain);
            }
        }
        match self.consumer {
            "group_count" => distinct
                .into_iter()
                .map(|domain| {
                    json!({
                        "key": logical_key(self.shape, domain),
                        "rows": domains.iter().filter(|value| **value == domain).count(),
                    })
                })
                .collect(),
            "count_distinct" => {
                vec![json!({"distinct": distinct.iter().filter(|d| **d != 0).count()})]
            }
            "unary_distinct" => distinct
                .into_iter()
                .map(|domain| json!({"key": logical_key(self.shape, domain)}))
                .collect(),
            "left_join" => {
                let right = self.right_domains();
                domains.iter().enumerate().flat_map(|(ordinal, domain)| {
                    let matches = right.iter().enumerate().filter(|(_, key)| **key == *domain && *domain != 0).map(|(i, _)| Some(i)).collect::<Vec<_>>();
                    let matches = if matches.is_empty() { vec![None] } else { matches };
                    matches.into_iter().map(move |right| json!({
                        "ordinal": ordinal, "key": logical_key(self.shape, *domain), "right_ordinal": right,
                    }))
                }).collect()
            }
            _ => panic!("unknown consumer"),
        }
    }
}

fn column(name: &str) -> ColumnRef {
    ColumnRef::new(name).unwrap()
}

fn logical_key(shape: &str, domain: usize) -> Value {
    if domain == 0 {
        return Value::Null;
    }
    let list = if domain == 1 {
        vec![]
    } else {
        (0..16 + domain % 3)
            .map(|j| {
                if (domain + j).is_multiple_of(5) {
                    Value::Null
                } else {
                    json!(i64::try_from(domain * 32 + j).unwrap() - 100)
                }
            })
            .collect::<Vec<_>>()
    };
    if shape == "list_i64" {
        json!(list)
    } else {
        json!({
            "items": if domain == 2 { Value::Null } else { json!(list) },
            "tag": if domain.is_multiple_of(5) { Value::Null } else { json!(i64::try_from(domain).unwrap() - 20) },
        })
    }
}

fn key_array(shape: &str, domains: &[usize]) -> ArrayRef {
    let mut children = Vec::new();
    let mut offsets = Vec::new();
    let mut lengths = Vec::new();
    for domain in domains {
        offsets.push(children.len() as u64);
        let count = if *domain <= 1 || (shape == "struct_list_i64" && *domain == 2) {
            0
        } else {
            16 + domain % 3
        };
        lengths.push(count as u64);
        for child in 0..count {
            children.push(
                (!(domain + child).is_multiple_of(5))
                    .then(|| i64::try_from(domain * 32 + child).unwrap() - 100),
            );
        }
    }
    let list = ListViewArray::try_new(
        PrimitiveArray::from_option_iter(children).into_array(),
        PrimitiveArray::from_iter(offsets).into_array(),
        PrimitiveArray::from_iter(lengths).into_array(),
        Validity::from_iter(
            domains
                .iter()
                .map(|d| *d != 0 && (shape == "list_i64" || *d != 2)),
        ),
    )
    .unwrap()
    .into_array();
    if shape == "list_i64" {
        list
    } else {
        StructArray::new(
            FieldNames::from(["items", "tag"]),
            vec![
                list,
                PrimitiveArray::from_option_iter(
                    domains
                        .iter()
                        .map(|d| (!d.is_multiple_of(5)).then(|| i64::try_from(*d).unwrap() - 20)),
                )
                .into_array(),
            ],
            domains.len(),
            Validity::from_iter(domains.iter().map(|d| *d != 0)),
        )
        .into_array()
    }
}

fn chunk(cell: CellSpec, domains: &[usize], first_ordinal: usize) -> ArrayRef {
    let keys = if cell.representation == "parent_dictionary" {
        let mut values = Vec::new();
        let codes = domains
            .iter()
            .map(|d| {
                if let Some(i) = values.iter().position(|v| v == d) {
                    u32::try_from(i).unwrap()
                } else {
                    values.push(*d);
                    u32::try_from(values.len() - 1).unwrap()
                }
            })
            .collect::<Vec<_>>();
        DictArray::try_new(
            PrimitiveArray::from_iter(codes).into_array(),
            key_array(cell.shape, &values),
        )
        .unwrap()
        .into_array()
    } else {
        key_array(cell.shape, domains)
    };
    assert_eq!(keys.dtype(), &cell.key_dtype());
    StructArray::new(
        FieldNames::from(["ordinal", "key"]),
        vec![
            PrimitiveArray::from_iter(
                (first_ordinal..first_ordinal + domains.len()).map(|v| v as u64),
            )
            .into_array(),
            keys,
        ],
        domains.len(),
        Validity::NonNullable,
    )
    .into_array()
}

fn hash(bytes: &[u8]) -> String {
    use std::fmt::Write as _;
    let mut result = String::with_capacity(64);
    for byte in Sha256::digest(bytes) {
        write!(&mut result, "{byte:02x}").unwrap();
    }
    result
}

fn witness(root: &Path, value: &impl serde::Serialize) -> String {
    let bytes = serde_json::to_vec(value).unwrap();
    let identity = hash(&bytes);
    let path = root.join("witnesses").join(format!("{identity}.json"));
    if path.exists() {
        assert_eq!(fs::read(path).unwrap(), bytes);
    } else {
        fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(path)
            .unwrap()
            .write_all(&bytes)
            .unwrap();
    }
    identity
}

fn grant() -> VortexLocalPrimitiveExecutionPolicy {
    let mut policy = VortexLocalPrimitiveExecutionPolicy::new_with_memory_gb(1, 1).unwrap();
    policy.resource_envelope.memory_budget_bytes = GRANT;
    policy
}

#[allow(clippy::too_many_lines)] // Keep generation, physical reopen, complete values and cleanup auditable together.
fn fixture(root: &Path, cell: CellSpec, side: &str) -> Value {
    let domains = if side == "left" {
        cell.domains()
    } else {
        cell.right_domains()
    };
    let path = root
        .join("fixtures")
        .join(format!("{}-{side}.vortex", cell.fixture_id()));
    let runtime = CurrentThreadRuntime::new();
    let session = VortexSession::default().with_handle(runtime.handle());
    let mut file = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&path)
        .unwrap();
    let mut writer = session
        .write_options()
        .with_strategy(
            super::super::super::native_flat_layout::SequentialNativeFlatLayout::strategy(
                domains.len().div_ceil(CHUNK_ROWS).max(1),
            ),
        )
        .with_file_statistics(vec![])
        .blocking(&runtime)
        .writer(&mut file, chunk(cell, &[], 0).dtype().clone());
    let mut written_encodings = BTreeSet::new();
    for start in (0..domains.len().max(1)).step_by(CHUNK_ROWS) {
        let array = chunk(
            cell,
            &domains[start..domains.len().min(start + CHUNK_ROWS)],
            start,
        );
        written_encodings.extend(
            array
                .depth_first_traversal()
                .map(|a| a.encoding_id().to_string()),
        );
        writer.push(array).unwrap();
    }
    writer.finish().unwrap();
    drop(file);
    let bytes = fs::read(&path).unwrap();
    assert!(bytes.len() <= 16 << 20);
    let inspection_session = ResidentVortexSession::new(GRANT, 1).unwrap();
    let inspection_memory = inspection_session.shared_memory_pool();
    let source = inspection_session.prepare_file(&path).unwrap();
    let physical = source
        .with_native_execution(|file, _, runtime| {
            use crate::physical_encoding_inventory::{
                PhysicalEncodingInspectionLimits, inspect_physical_encodings,
            };
            runtime
                .block_on(inspect_physical_encodings(
                    file,
                    PhysicalEncodingInspectionLimits {
                        max_layout_nodes: 128,
                        max_flat_references: 64,
                        max_segment_bytes: 16 << 20,
                        max_total_segment_bytes: 16 << 20,
                        max_array_nodes: 4096,
                    },
                ))
                .map_err(super::super::super::vortex_error)
        })
        .unwrap();
    assert_eq!(physical["complete_flat_inspection"], true);
    if cell.representation == "parent_dictionary" && !domains.is_empty() {
        for flat in physical["flat_references"].as_array().unwrap() {
            assert!(
                flat["stored_array_nodes"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .any(|node| node["encoding_id"] == "vortex.dict")
            );
        }
    }
    let physical_witness = witness(root, &physical);
    drop((source, inspection_session));
    assert_eq!(inspection_memory.snapshot().reserved_bytes, 0);
    let scan = VortexRelationalPlan::Scan(VortexRelationalScan {
        source_uri: DatasetUri::new(path.display().to_string()).unwrap(),
        projection: shardloom_plan::ProjectionRequest::All,
        predicate: None,
    });
    let prepared = prepare_relational(&scan, grant()).unwrap();
    let memory = prepared.session.memory().clone();
    let mut reopened_encodings = BTreeSet::new();
    let execution = prepared
        .for_each_batch(&CancellationToken::default(), |array, _context| {
            reopened_encodings.extend(
                array
                    .depth_first_traversal()
                    .map(|a| a.encoding_id().to_string()),
            );
            Ok(())
        })
        .unwrap();
    assert_eq!(execution.output_rows, domains.len() as u64);
    assert!(execution.native_io_certificate.is_certified());
    let collected = prepared
        .collect_jsonl(&CancellationToken::default())
        .unwrap();
    let actual = json_rows(&collected);
    let expected = domains
        .iter()
        .enumerate()
        .map(|(ordinal, domain)| json!({"ordinal":ordinal,"key":logical_key(cell.shape, *domain)}))
        .collect::<Vec<_>>();
    assert_eq!(actual, expected);
    let actual_witness = witness(root, &actual);
    let schema_witness = witness(
        root,
        &serde_json::from_str::<Value>(collected.result_schema_json.value()).unwrap(),
    );
    drop((collected, execution, prepared));
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    json!({"fixture_id":cell.fixture_id(), "side":side, "path":path, "length":bytes.len(), "sha256":hash(&bytes), "rows":domains.len(),
        "written_encodings": written_encodings, "reopened_result_encodings":reopened_encodings,
        "physical_file_witness":physical_witness,
        "reopened_result_scope":"public native result after nested payload detachment; persisted encoding is inspected separately",
        "actual_rows_witness": actual_witness, "schema_witness":schema_witness, "reserved_after_cleanup":0,
        "chunk_rows":CHUNK_ROWS, "compression":"none", "file_statistics":false,
        "dictionary_domain":"first-seen keys local to each 257-row chunk; no cross-domain identity assumption"})
}

fn cells() -> Vec<CellSpec> {
    let mut result = Vec::new();
    for rows in [128, 4096] {
        for shape in ["list_i64", "struct_list_i64"] {
            for domain in ["eight", "unique"] {
                for representation in ["plain", "parent_dictionary"] {
                    for consumer in CONSUMERS {
                        for calls in [1, 4] {
                            result.push(CellSpec {
                                rows,
                                shape,
                                domain,
                                representation,
                                consumer,
                                calls,
                            });
                        }
                    }
                }
            }
        }
    }
    assert_eq!(result.len(), 128);
    result
}

fn controls() -> Vec<CellSpec> {
    let mut result = Vec::new();
    for rows in [0, 32] {
        for shape in ["list_i64", "struct_list_i64"] {
            for representation in ["plain", "parent_dictionary"] {
                for consumer in CONSUMERS {
                    result.push(CellSpec {
                        rows,
                        shape,
                        domain: "all_null",
                        representation,
                        consumer,
                        calls: 1,
                    });
                }
            }
        }
    }
    result
}

#[allow(clippy::too_many_lines)] // The lifecycle clock must visibly include all runtime owners.
fn workflow(root: &Path, cell: CellSpec, enabled: bool) -> Value {
    let expected = cell.expected();
    let expected_dtype = cell.output_dtype();
    let expected_witness = witness(root, &expected);
    let expected_schema = witness(root, &serde_json::to_value(&expected_dtype).unwrap());
    let mut operations = Vec::new();
    let observer = observation::Session::start(false);
    let identity = identity::Session::start(enabled);
    let started = Instant::now();
    let plan = cell.plan(root);
    let prepared = prepare_relational(&plan, grant()).unwrap();
    let memory = prepared.session.memory().clone();
    let preparation_ns = started.elapsed().as_nanos();
    let mut complete_ns = preparation_ns;
    assert_eq!(prepared.output_dtype().as_ref(), Some(&expected_dtype));
    for call in 0..cell.calls {
        let started = Instant::now();
        let output = prepared
            .collect_jsonl(&CancellationToken::default())
            .unwrap();
        let execution_and_consumption_ns = started.elapsed().as_nanos();
        complete_ns += execution_and_consumption_ns;
        let actual = json_rows(&output);
        assert_eq!(actual, expected, "{} call {call}", cell.id());
        let actual_schema =
            serde_json::from_str::<Value>(output.result_schema_json.value()).unwrap();
        assert_eq!(
            actual_schema,
            serde_json::to_value(&expected_dtype).unwrap()
        );
        let actual_witness = witness(root, &actual);
        assert_eq!(actual_witness, expected_witness);
        let actual_schema_witness = witness(root, &actual_schema);
        assert_eq!(actual_schema_witness, expected_schema);
        let certificate = &output.execution.native_io_certificate;
        assert!(certificate.is_certified());
        assert!(!certificate.side_effects.fallback_attempted);
        assert_eq!(output.execution.output_rows, expected.len() as u64);
        assert_eq!(prepared.snapshot().completed_executions, (call + 1) as u64);
        let mut record = json!({
            "call":call, "rows":actual.len(), "actual_rows_witness":actual_witness,
            "actual_schema_witness":actual_schema_witness,
            "engine_execution_ns":output.timing.execution.as_nanos(),
            "result_serialization_ns":output.timing.result_serialization.as_nanos(),
            "execution_and_consumption_ns":execution_and_consumption_ns,
            "native_io_certificate": {
                "certified":certificate.is_certified(),
                "fallback_attempted":certificate.side_effects.fallback_attempted,
                "complete_debug":format!("{certificate:#?}"),
            },
            "completed_executions":prepared.snapshot().completed_executions,
        });
        let started = Instant::now();
        drop(output);
        let release_ns = started.elapsed().as_nanos();
        complete_ns += release_ns;
        record["output_release_ns"] = json!(release_ns);
        operations.push(record);
    }
    let finished = prepared.snapshot();
    assert_eq!(finished.completed_executions, cell.calls as u64);
    let started = Instant::now();
    drop((prepared, plan));
    let destruction_ns = started.elapsed().as_nanos();
    complete_ns += destruction_ns;
    let observed = observer.finish();
    let identity = identity.finish();
    let memory = memory.snapshot();
    assert_eq!(memory.reserved_bytes, 0);
    assert_eq!(memory.denied_reservations, 0);
    assert!(memory.peak_reserved_bytes <= GRANT);
    {
        for (_, stage) in observed["stages"].as_object().unwrap() {
            assert_eq!(stage["root_calls"], 0);
            assert_eq!(stage["nanoseconds"], 0);
        }
    }
    json!({
        "cell_id":cell.id(), "rows":cell.rows, "shape":cell.shape, "domain":cell.domain,
        "representation":cell.representation, "consumer":cell.consumer, "calls":cell.calls,
        "profile":if enabled { "candidate" } else { "baseline" },
        "identity": identity,
        "expected_rows_witness":expected_witness, "expected_schema_witness":expected_schema,
        "operations":operations, "observation":observed, "preparation_ns":preparation_ns,
        "destruction_ns":destruction_ns, "complete_workflow_ns":complete_ns,
        "peak_reserved_bytes":memory.peak_reserved_bytes, "reserved_after_cleanup":memory.reserved_bytes,
        "denied_reservations":memory.denied_reservations,
        "completed_executions":finished.completed_executions,
        "prepared_source_opens":finished.prepared_source_opens,
        "provider_background_workers":finished.provider_background_workers,
        "admitted_max_parallelism":finished.admitted_max_parallelism,
    })
}

struct FailedWriter;
impl std::fmt::Write for FailedWriter {
    fn write_str(&mut self, _: &str) -> std::fmt::Result {
        Err(std::fmt::Error)
    }
}

fn observer_self_check(root: &Path) {
    use observation::Stage;
    use shardloom_exec::live_memory::LiveMemoryPool;
    let off = observation::Session::start(false);
    assert!(observation::enter(Stage::Construction).is_none());
    assert_eq!(off.finish()["maximum_simultaneous_roots"], 0);
    let on = observation::Session::start(true);
    {
        let _outer = observation::enter(Stage::Construction);
        let _inner = observation::enter(Stage::Hash);
    }
    let nested = on.finish();
    assert_eq!(nested["stages"]["key_owner_construction"]["root_calls"], 1);
    assert_eq!(nested["stages"]["nested_hash"]["root_calls"], 0);
    assert_eq!(nested["maximum_simultaneous_roots"], 1);
    let on = observation::Session::start(true);
    let memory = LiveMemoryPool::new(1 << 20).unwrap();
    let cancellation = CancellationToken::default();
    let input = key_array("struct_list_i64", &[0, 1, 2, 3]);
    let mut context = vortex::array::legacy_session().create_execution_ctx();
    let column = KeyColumn::new(&input, &mut context, &memory, &cancellation).unwrap();
    let other = KeyColumn::new(
        &key_array("list_i64", &[0, 1, 2, 3]),
        &mut context,
        &memory,
        &cancellation,
    )
    .unwrap();
    assert!(column.compare_at(99, &column, 1).is_err());
    assert!(column.compare_at(3, &other, 3).is_err());
    assert!(
        column
            .hash_into(99, &mut rustc_hash::FxHasher::default())
            .is_err()
    );
    assert!(
        column
            .write_exact_key(3, &mut FailedWriter, &cancellation)
            .is_err()
    );
    cancellation.cancel();
    assert!(column.compare_at(3, &column, 3).is_err());
    assert!(
        column
            .hash_into(3, &mut rustc_hash::FxHasher::default())
            .is_err()
    );
    assert!(KeyColumn::new(&input, &mut context, &memory, &cancellation).is_err());
    drop((column, other));
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    let failure = on.finish();
    assert_eq!(failure["active_roots_after_drain"], 0);
    assert_eq!(failure["maximum_simultaneous_roots"], 1);
    assert_eq!(failure["stages"]["key_owner_construction"]["root_calls"], 3);
    assert_eq!(failure["stages"]["nested_compare"]["root_calls"], 2);
    assert_eq!(failure["stages"]["nested_hash"]["root_calls"], 1);
    assert_eq!(
        failure["stages"]["nested_exact_serialization"]["root_calls"],
        1
    );
    println!(
        "observer_self_check={}",
        witness(root, &json!({"nested":nested,"failure":failure}))
    );
}

#[test]
#[ignore = "frozen serial nested-key attribution; requires supervised local evidence directory"]
fn native_nested_key_identity_screen() {
    let root = PathBuf::from(
        std::env::var_os("SHARDLOOM_NESTED_KEY_ROOT").expect("explicit guarded evidence root"),
    );
    let mode = std::env::var("SHARDLOOM_NESTED_KEY_MODE").expect("fixtures, preflight or measure");
    assert!(root.is_absolute());
    fs::create_dir_all(root.join("witnesses")).unwrap();
    let matrix = cells();
    if mode == "fixtures" {
        fs::create_dir(root.join("fixtures")).unwrap();
        let unique = matrix
            .iter()
            .copied()
            .chain(controls())
            .map(|cell| (cell.fixture_id(), cell))
            .collect::<BTreeMap<_, _>>();
        let mut records = Vec::new();
        for cell in unique.values() {
            for side in ["left", "right"] {
                records.push(fixture(&root, *cell, side));
            }
        }
        fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(root.join("fixtures.json"))
            .unwrap()
            .write_all(&serde_json::to_vec_pretty(&records).unwrap())
            .unwrap();
        println!("fixtures_complete={}", records.len());
        return;
    }
    assert!(mode == "preflight" || mode == "measure");
    observer_self_check(&root);
    let cohort =
        std::env::var("SHARDLOOM_NESTED_KEY_COHORT").unwrap_or_else(|_| "preflight".into());
    let mut output = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(root.join(format!("{mode}-{cohort}.jsonl")))
        .unwrap();
    let mut workflows = 0;
    let mut operations = 0;
    let mut record = |cell: CellSpec, enabled, sample, warmup| {
        let mut value = workflow(&root, cell, enabled);
        value["cohort"] = json!(cohort);
        value["sample"] = json!(sample);
        value["warmup"] = json!(warmup);
        serde_json::to_writer(&mut output, &value).unwrap();
        writeln!(&mut output).unwrap();
        output.flush().unwrap();
        workflows += 1;
        operations += cell.calls;
        if workflows % 32 == 0 {
            println!("nested_progress={workflows}");
        }
    };
    if mode == "measure" {
        assert!(cohort == "A" || cohort == "B");
        for enabled in [false, true] {
            record(matrix[0], enabled, 0, true);
        }
    }
    for (index, cell) in matrix.iter().copied().enumerate() {
        for sample in 0..if mode == "measure" { 3 } else { 1 } {
            let first = (index + sample).is_multiple_of(2) ^ (cohort == "B");
            for enabled in [!first, first] {
                record(cell, enabled, sample, false);
            }
        }
    }
    if mode == "preflight" {
        for cell in controls() {
            for enabled in [false, true] {
                record(cell, enabled, 0, false);
            }
        }
    } else {
        assert_eq!((workflows, operations), (770, 1922));
    }
    println!(
        "nested_complete={}",
        json!({"mode":mode,"cohort":cohort,"workflows":workflows,"operations":operations})
    );
}
