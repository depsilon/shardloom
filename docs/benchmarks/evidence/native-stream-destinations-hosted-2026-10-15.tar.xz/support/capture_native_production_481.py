"""Bind production responses to an immutable commit and the latest deployment check."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import urllib.request

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
BASE = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--revision', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    assert re.fullmatch('[a-f0-9]{40}', args.revision)
    output = (BASE / args.output).resolve()
    assert output.is_relative_to(BASE) and not output.exists()
    raw = subprocess.check_output(['gh', 'api',
        f'repos/depsilon/shardloom/commits/{args.revision}/check-runs?per_page=100'])
    checks = json.loads(raw)
    assert checks['total_count'] == len(checks['check_runs']) <= 100
    candidates = [row for row in checks['check_runs'] if row['name'] == 'Workers Builds: shardloom']
    assert len(candidates) == 1, candidates
    deployment = candidates[0]
    assert deployment['head_sha'] == args.revision
    assert deployment['status'] == 'completed' and deployment['conclusion'] == 'success'
    version = re.search(r'Version ID: ([a-f0-9-]{36})', deployment['output']['summary']).group(1)
    output.mkdir()
    (output / 'commit-check-runs.json').write_bytes(raw)
    (output / 'deployment-check.json').write_text(json.dumps(deployment, indent=2) + '\n')
    routes = ['field-guide/benchmark-methodology/index.html', 'field-guide/runtime-and-io/index.html',
              'field-guide/limitations/index.html', 'field-guide/python-surface/index.html',
              'benchmarks/index.html', 'benchmarks.html', 'assets/parallax-home.js', 'pagefind/pagefind-entry.json']
    records = []
    for route in routes:
        source = 'website/' + route
        expected = subprocess.check_output(['git', 'show', args.revision + ':' + source], cwd=ROOT)
        url = 'https://shardloom.io/' + route.removesuffix('index.html')
        request = urllib.request.Request(url, headers={'User-Agent': 'ShardLoom-owned-site-verification'})
        with urllib.request.urlopen(request, timeout=30) as response:
            actual = response.read((2 << 20) + 1)
            assert response.status == 200 and len(actual) <= 2 << 20
            final_url = response.url
        filename = route.replace('/', '_')
        (output / filename).write_bytes(actual)
        prefix = 0
        while prefix < min(len(actual), len(expected)) and actual[prefix] == expected[prefix]:
            prefix += 1
        extra = len(actual) - len(expected)
        insertion = b''
        preserved = actual == expected
        if not preserved and 0 < extra <= 16384 and route.endswith('.html'):
            insertion = actual[prefix:prefix + extra]
            preserved = actual[prefix + extra:] == expected[prefix:]
            preserved &= b'/cdn-cgi/challenge-platform/' in insertion or b'static.cloudflareinsights.com/' in insertion
        records.append(dict(source=source, response=filename, url=url, final_url=final_url,
            http_status=200, expected_bytes=len(expected), expected_sha256=sha(expected),
            observed_bytes=len(actual), observed_sha256=sha(actual), raw_byte_identical=actual == expected,
            source_preserved=bool(preserved), insertion_bytes=len(insertion),
            insertion_sha256=sha(insertion) if insertion else None))
    report = dict(schema_version='shardloom.native_served_source.v1',
        status='passed' if all(row['source_preserved'] for row in records) else 'failed',
        observed_at=datetime.now(timezone.utc).isoformat(), head=args.revision,
        origin='https://shardloom.io', deployment_version=version, deployment_check_id=deployment['id'],
        deployment_completion_proven=True, commit_check_runs_sha256=sha(raw), responses=records,
        scope='Production response bytes compared with immutable merged source; browser rendering is separately observed.')
    with (output / 'report.json').open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status=report['status'], responses=len(records),
        source_preserved=sum(row['source_preserved'] for row in records), deployment_version=version)), flush=True)
    assert report['status'] == 'passed'


if __name__ == '__main__':
    main()
