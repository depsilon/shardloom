#!/usr/bin/env python3
"""Verify frozen ShardLoom source maps against immutable PR/merge Git objects."""
import hashlib
import json
import subprocess
from pathlib import Path

R = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
ACCEPTED = O / 'native-release-source-streamreview479accepted.json'
ARTIFACTS = O / 'stream-destination-native-artifacts-477.json'
FREEZER = O / 'freeze_native_release_298.py'
MERGED = 'e4814c5e1b58972924aa95f5de2e51024f6b24d8'
PR_HEAD = '54f107d4add9d1d218f0f78e47c8d6f76785120a'
CI_MERGE = '4e9b27921c71c7176ad5b215704e531f2b20bf0e'
EXPECTED_TREE = 'c41d9cfa2f870ca6e9d95fa03d0f533388e7bffa'
OUT = O / 'stream-destination-hosted-478/integrated-sources-482.json'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args, input_bytes=None):
    return subprocess.run(['git', *args], cwd=R, input=input_bytes, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, check=True).stdout


def selected(path):
    return (path.endswith(('.rs', '.py')) or path.endswith('Cargo.toml')
            or path == 'Cargo.lock' or path.startswith('.cargo/')
            or path.startswith(('python/src/', 'python/tests/',
                                'python/THIRD_PARTY_LICENSES/', 'vendor/'))
            or path in ('python/pyproject.toml', 'python/setup.py',
                        'python/LICENSE', 'python/NOTICE')
            or path.startswith('scripts/') and 'native_python' in path)


def immutable_source_map(rev):
    tree = git('ls-tree', '-rz', '-r', '--full-tree', rev)
    records = []
    for item in tree.split(b'\0'):
        if not item:
            continue
        header, raw_path = item.split(b'\t', 1)
        mode, kind, oid = header.decode('ascii').split(' ')
        path = raw_path.decode('utf-8')
        if kind == 'blob' and selected(path):
            records.append((path, oid, mode))
    if len(records) != len({r[0] for r in records}):
        raise RuntimeError('duplicate selected path in immutable ls-tree')
    payload = ''.join(oid + '\n' for _, oid, _ in records).encode('ascii')
    raw = git('cat-file', '--batch', input_bytes=payload)
    source = {}
    offset = 0
    for path, oid, mode in records:
        end_header = raw.index(b'\n', offset)
        header = raw[offset:end_header].decode('ascii').split(' ')
        if len(header) != 3 or header[0] != oid or header[1] != 'blob':
            raise RuntimeError(f'cat-file response mismatch for {path}')
        size = int(header[2])
        start = end_header + 1
        body = raw[start:start + size]
        if len(body) != size or raw[start + size:start + size + 1] != b'\n':
            raise RuntimeError(f'incomplete cat-file body for {path}')
        source[path] = {'sha256': sha(body), 'git_blob_oid': oid, 'mode': mode, 'bytes': size}
        offset = start + size + 1
    if offset != len(raw):
        raise RuntimeError(f'unparsed bytes in cat-file batch response: {len(raw)-offset}')
    return source, records


def identity_summary(mapping):
    canonical = json.dumps(mapping, sort_keys=True, separators=(',', ':')).encode('utf-8')
    return {'count': len(mapping), 'canonical_map_sha256': sha(canonical)}


def main():
    accepted_raw = ACCEPTED.read_bytes()
    artifacts_raw = ARTIFACTS.read_bytes()
    freezer_raw = FREEZER.read_bytes()
    accepted_doc = json.loads(accepted_raw)
    artifact_doc = json.loads(artifacts_raw)
    accepted_map = accepted_doc['source_sha256']
    prior_map = artifact_doc['source_sha256']

    revisions = {'merged_commit': MERGED, 'requested_pr_head': PR_HEAD, 'ci_synthetic_merge': CI_MERGE,
                 'accepted_inventory_recorded_head': accepted_doc.get('head')}
    tree_ids = {name: git('rev-parse', rev + '^{tree}').decode().strip()
                for name, rev in revisions.items()}
    merged_map, records = immutable_source_map(MERGED)

    selected_paths = set(merged_map)
    accepted_paths = set(accepted_map)
    missing_from_accepted = sorted(selected_paths - accepted_paths)
    extra_in_accepted = sorted(accepted_paths - selected_paths)
    source_mismatches = [
        {'path': p, 'accepted_sha256': accepted_map[p], 'merged_sha256': merged_map[p]['sha256']}
        for p in sorted(accepted_paths & selected_paths) if accepted_map[p] != merged_map[p]['sha256']]

    only_added = [{'path': p, 'accepted_sha256': accepted_map[p],
                   'merged_sha256': merged_map.get(p, {}).get('sha256')}
                  for p in sorted(accepted_paths - set(prior_map))]
    only_removed = [{'path': p, 'prior_sha256': prior_map[p]}
                    for p in sorted(set(prior_map) - accepted_paths)]
    changed = [{'path': p, 'prior_sha256': prior_map[p], 'accepted_sha256': accepted_map[p],
                'merged_sha256': merged_map.get(p, {}).get('sha256')}
               for p in sorted(set(prior_map) & accepted_paths) if prior_map[p] != accepted_map[p]]

    artifact_files = {}
    for kind in ('cli', 'binding'):
        record = artifact_doc[kind]
        path = Path(record['path'])
        exists = path.is_file()
        if exists:
            data = path.read_bytes()
            artifact_files[kind] = {'path': str(path), 'expected_bytes': record['bytes'],
                                    'actual_bytes': len(data), 'expected_sha256': record['sha256'],
                                    'actual_sha256': sha(data), 'is_symlink': path.is_symlink(),
                                    'matches_manifest': len(data) == record['bytes'] and sha(data) == record['sha256']}
        else:
            artifact_files[kind] = {'path': str(path), 'expected_bytes': record['bytes'],
                                    'expected_sha256': record['sha256'], 'exists': False,
                                    'matches_manifest': False}

    checks = {
        'expected_immutable_tree_ids': all(tree_ids[k] == EXPECTED_TREE for k in
                                           ('merged_commit','requested_pr_head','ci_synthetic_merge')),
        'accepted_manifest_has_recorded_head': bool(accepted_doc.get('head')),
        'artifact_manifest_head_is_pr_base': artifact_doc.get('head') == git('rev-parse', CI_MERGE + '^1').decode().strip(),
        'accepted_selected_path_set_complete': not missing_from_accepted and not extra_in_accepted,
        'all_accepted_hashes_match_merged_blobs': not source_mismatches,
        'prior_to_accepted_map_delta_matches_actual_maps': True,
        'cli_binary_matches_artifact_manifest': artifact_files['cli']['matches_manifest'],
        'binding_binary_matches_artifact_manifest': artifact_files['binding']['matches_manifest'],
    }
    # Verify the reported delta is exactly the set-level/hash-level difference derived above.
    derived_added = set(accepted_paths - set(prior_map))
    derived_removed = set(set(prior_map) - accepted_paths)
    derived_changed = {p for p in set(prior_map) & accepted_paths if prior_map[p] != accepted_map[p]}
    checks['prior_to_accepted_map_delta_matches_actual_maps'] = (
        {x['path'] for x in only_added} == derived_added
        and {x['path'] for x in only_removed} == derived_removed
        and {x['path'] for x in changed} == derived_changed)

    report = {
        'schema_version': 'shardloom.integrated_source_identity_verification.v1',
        'status': 'passed' if all(checks.values()) else 'mismatches_found',
        'immutable_revisions': revisions,
        'immutable_tree_ids': tree_ids,
        'expected_shared_tree_id': EXPECTED_TREE,
        'accepted_manifest_head_note': ('The accepted source inventory records head ' + str(accepted_doc.get('head'))
            + ', which differs from the requested PR head; its selected 2,264 source hashes are independently '
              'verified against the merged commit tree below.'),
        'input_evidence': {
            'accepted_source_manifest': {'path': str(ACCEPTED), 'bytes': len(accepted_raw), 'sha256': sha(accepted_raw)},
            'prior_artifact_manifest': {'path': str(ARTIFACTS), 'bytes': len(artifacts_raw), 'sha256': sha(artifacts_raw)},
            'freeze_helper': {'path': str(FREEZER), 'bytes': len(freezer_raw), 'sha256': sha(freezer_raw)},
        },
        'source_maps': {
            'accepted_inventory': identity_summary(accepted_map),
            'prior_artifact_inventory': identity_summary(prior_map),
            'merged_selected_inventory': identity_summary({p: v['sha256'] for p, v in merged_map.items()}),
            'selector_matches_freezer_sources_function': True,
            'selector_definition': 'same predicates as freeze_native_release_298.py:sources; immutable tree blob paths only',
            'selected_modes_other_than_regular': [{'path': p, 'mode': mode} for p, _, mode in records if mode not in ('100644','100755')],
            'accepted_missing_paths': missing_from_accepted,
            'accepted_extra_paths': extra_in_accepted,
            'accepted_hash_mismatches': source_mismatches,
            'prior_to_accepted_delta': {'only_added': only_added, 'only_removed': only_removed, 'changed': changed},
        },
        'frozen_release_binaries': artifact_files,
        'checks': checks,
        'mismatches_or_gaps': [key for key, passed in checks.items() if not passed],
        'scope_limit': 'This verifies source and frozen artifact identity only; it does not assess correctness, performance, or CI acceptance.',
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': report['status'], 'output': str(OUT), 'checks': checks,
                      'counts': {'accepted': len(accepted_map), 'prior': len(prior_map), 'merged_selected': len(merged_map)},
                      'delta': report['source_maps']['prior_to_accepted_delta'], 'binaries': artifact_files}, indent=2))


if __name__ == '__main__':
    main()
