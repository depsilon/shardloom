#!/usr/bin/env python3
"""Collect existing PR #1557 GitHub Actions job metadata and logs once."""
import hashlib
import json
import re
import subprocess
from pathlib import Path

OWNER, REPO, PR, RUN = 'depsilon', 'shardloom', 1557, 38783563557
EXPECTED_HEAD = '54f107d4add9d1d218f0f78e47c8d6f76785120a'
ROOT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
OUT = ROOT / 'stream-destination-hosted-478' / 'ci-481'
JOBS = {
    116589685494: 'native_python_wheels_py310_ubuntu',
    116589685696: 'native_python_wheels_py313_ubuntu',
    116589685738: 'native_python_wheels_py313_macos',
    116589685901: 'native_public_tests',
    116589685919: 'native_vortex_tests',
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def fetch(endpoint, path):
    proc = subprocess.run(['gh', 'api', endpoint], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    result = {'endpoint': endpoint, 'exit_code': proc.returncode}
    if proc.returncode == 0:
        path.write_bytes(proc.stdout)
        result.update({'path': str(path), 'bytes': len(proc.stdout), 'sha256': digest(proc.stdout)})
        return result, proc.stdout
    error = proc.stdout + (b'\n' if proc.stdout else b'') + proc.stderr
    errpath = path.with_suffix(path.suffix + '.retrieval-error.txt')
    errpath.write_bytes(error)
    result.update({'retrieval_error_path': str(errpath), 'retrieval_error_bytes': len(error),
                   'retrieval_error_sha256': digest(error), 'error_excerpt': error.decode('utf-8', 'replace')[:2000]})
    return result, None


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    report = {'schema_version': 'shardloom.hosted_ci_evidence.v1', 'run_id': RUN,
              'repository': f'{OWNER}/{REPO}', 'requested_pr_head': EXPECTED_HEAD,
              'jobs': [], 'errors_or_gaps': []}
    root = f'repos/{OWNER}/{REPO}'
    run_ev, run_raw = fetch(f'{root}/actions/runs/{RUN}', OUT / f'run-{RUN}.json')
    report['run_metadata_evidence'] = run_ev
    jobs_ev, jobs_raw = fetch(f'{root}/actions/runs/{RUN}/jobs?per_page=100', OUT / f'run-{RUN}-jobs.json')
    report['run_jobs_evidence'] = jobs_ev
    pr_ev, pr_raw = fetch(f'{root}/pulls/{PR}', OUT / f'pr-{PR}.json')
    report['pull_request_evidence'] = pr_ev
    run = json.loads(run_raw) if run_raw else {}
    jobs_doc = json.loads(jobs_raw) if jobs_raw else {}
    pr = json.loads(pr_raw) if pr_raw else {}
    report['workflow_checkout_ref_analysis'] = {
        'workflow_file': 'R/.github/workflows/ci.yml',
        'trigger_and_checkout_facts': [
            'Workflow has a pull_request trigger.',
            'Target jobs use actions/checkout without an explicit ref input, so checkout follows the workflow event ref/GITHUB_SHA.',
        ],
        'run_event': run.get('event'), 'run_head_sha': run.get('head_sha'),
        'run_head_branch': run.get('head_branch'), 'run_status': run.get('status'),
        'run_conclusion': run.get('conclusion'),
        'run_pull_requests': run.get('pull_requests'),
        'pr_head_sha': (pr.get('head') or {}).get('sha'),
        'pr_merge_commit_sha': pr.get('merge_commit_sha'),
        'pr_state': pr.get('state'),
        'run_head_matches_requested_pr_head': run.get('head_sha') == EXPECTED_HEAD,
        'run_head_matches_pr_api_head': run.get('head_sha') == (pr.get('head') or {}).get('sha'),
        'run_head_matches_pr_merge_commit_sha': run.get('head_sha') == pr.get('merge_commit_sha'),
    }
    all_jobs = {j.get('id'): j for j in jobs_doc.get('jobs', [])}
    for job_id, label in JOBS.items():
        entry = {'id': job_id, 'label': label}
        job_ev, job_raw = fetch(f'{root}/actions/jobs/{job_id}', OUT / f'job-{job_id}-{label}.json')
        entry['metadata_evidence'] = job_ev
        job = json.loads(job_raw) if job_raw else all_jobs.get(job_id, {})
        entry['status'] = job.get('status')
        entry['conclusion'] = job.get('conclusion')
        entry['name'] = job.get('name')
        entry['head_sha'] = job.get('head_sha')
        entry['started_at'] = job.get('started_at')
        entry['completed_at'] = job.get('completed_at')
        entry['steps'] = job.get('steps')
        if job.get('status') == 'completed':
            log_ev, log_raw = fetch(f'{root}/actions/jobs/{job_id}/logs', OUT / f'job-{job_id}-{label}.log')
            entry['log_evidence'] = log_ev
            if log_raw is not None:
                text = log_raw.decode('utf-8', 'replace')
                lines = text.splitlines()
                entry['matched_lines'] = [x for x in lines if
                    re.search(r'Ran \d+ tests?|\bOK\b|FAILED|test result:|passed;|error:|Error:|AssertionError|FAILED \(', x)]
                entry['checkout_ref_lines'] = [x for x in lines if any(s in x for s in
                    ('Checking out the ref', 'git checkout --progress --force', 'HEAD is now at'))]
                if label.startswith('native_python_wheels'):
                    entry['python_unittest_summaries'] = [x.strip() for x in lines if
                        re.search(r'Ran \d+ tests? in ', x) or re.search(r'"tests":\s*\d+', x)]
                    entry['packaging_unittest_run_counts'] = [int(n) for x in lines
                        for n in re.findall(r'Ran (\d+) tests? in ', x)]
                    entry['executable_native_unittest_counts'] = [int(n) for x in lines
                        for n in re.findall(r'"tests":\s*(\d+)', x)]
                if label == 'native_public_tests' or label == 'native_vortex_tests':
                    entry['rust_test_result_lines'] = [x.strip() for x in lines if 'test result:' in x]
                    entry['rust_passed_total'] = sum(int(n) for x in entry['rust_test_result_lines']
                        for n in re.findall(r'(\d+) passed;', x))
                if label == 'native_public_tests':
                    expected_tests = ('batch_writes::resident_batch_writes_create_new_destinations_with_either_overwrite_setting',
                                      'batch_writes::single_batch_write_rejections_preserve_existing_files_before_input_demand',
                                      'batch_writes::batch_fanout_keeps_existing_target_rejection_for_resident_and_streaming_input')
                    entry['new_existing_destination_test_lines'] = [x.strip() for x in lines
                        if any(name in x for name in expected_tests)]
        else:
            entry['log_status'] = 'not fetched: job is not completed; no polling or cancellation performed'
            report['errors_or_gaps'].append({'job_id': job_id, 'status': job.get('status'),
                                             'conclusion': job.get('conclusion'), 'gap': 'job not completed at metadata fetch'})
        report['jobs'].append(entry)
    # Preserve explicit absence of any requested job from the run's job listing.
    for job_id in JOBS:
        if job_id not in all_jobs:
            report['errors_or_gaps'].append({'job_id': job_id, 'gap': 'job id absent from run jobs listing'})
    report['status'] = 'evidence_collected' if run_raw and jobs_raw and pr_raw else 'retrieval_incomplete'
    outpath = OUT / 'ci-evidence-report.json'
    outpath.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': report['status'], 'output': str(outpath),
                      'jobs': [{'id': x['id'], 'status': x.get('status'), 'conclusion': x.get('conclusion'),
                                'log_sha256': (x.get('log_evidence') or {}).get('sha256')} for x in report['jobs']],
                      'gaps': report['errors_or_gaps']}, indent=2))


if __name__ == '__main__':
    main()
