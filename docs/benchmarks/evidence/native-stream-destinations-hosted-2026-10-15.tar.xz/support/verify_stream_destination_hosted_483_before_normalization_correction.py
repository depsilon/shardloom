"""Verify and package immutable PR1557 hosted evidence and the PR1556 deployment addendum."""
from datetime import datetime, timezone
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile

from freeze_native_release_298 import ROOT, OUT, sha, save
import verify_stream_destination_integrated_sources_482 as source_check

sys.path.insert(0, str(ROOT / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

RAW = OUT / 'stream-destination-hosted-478'
HEAD = source_check.PR_HEAD
MERGE = source_check.MERGED
SYNTHETIC = source_check.CI_MERGE


def read(path):
    return json.loads(Path(path).read_text())


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def plain(path):
    return '\n'.join(re.sub(r'^\d{4}-\d{2}-\d{2}T\S+Z ', '', line)
                     for line in Path(path).read_text().lstrip('\ufeff').splitlines())


def results(path, expected):
    text = plain(path)
    assert SYNTHETIC + ':refs/remotes/pull/1557/merge' in text
    groups = [tuple(map(int, row)) for row in re.findall(
        r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)]
    assert groups == expected, groups
    assert not re.search(r'^test .* \.\.\. FAILED$', text, re.M)
    return text, groups


def served(folder, revision):
    report = read(folder / 'report.json')
    assert report['status'] == 'passed' and report['head'] == revision
    assert len(report['responses']) == len({r['source'] for r in report['responses']}) == 8
    for row in report['responses']:
        actual_path = folder / row['response']
        actual = actual_path.read_bytes()
        expected = subprocess.check_output(['git', 'show', revision + ':' + row['source']], cwd=ROOT)
        import hashlib
        digest = lambda payload: hashlib.sha256(payload).hexdigest()
        assert row['source_preserved'] and row['http_status'] == 200
        assert len(actual) == row['observed_bytes'] and digest(actual) == row['observed_sha256']
        assert len(expected) == row['expected_bytes'] and digest(expected) == row['expected_sha256']
        if actual != expected:
            prefix = next(i for i, (a, b) in enumerate(zip(actual, expected)) if a != b)
            extra = len(actual) - len(expected)
            assert 0 < extra <= 16384 and row['source'].endswith('.html')
            insertion = actual[prefix:prefix + extra]
            assert actual[prefix + extra:] == expected[prefix:]
            assert b'/cdn-cgi/challenge-platform/' in insertion or b'static.cloudflareinsights.com/' in insertion
            assert row['insertion_bytes'] == extra and row['insertion_sha256'] == digest(insertion)
    return report


def main():
    checks = read(RAW / 'checks-final-482.json')['structuredContent']
    assert checks['headRevision'] == HEAD and not checks['hasMore']
    assert len(checks['checks']) == len({c['id'] for c in checks['checks']}) == 44
    assert all(c['head_sha'] == HEAD and c['status'] == 'completed' and c['conclusion'] == 'success'
               for c in checks['checks'])
    merge = read(RAW / 'merge-482.json')['structuredContent']
    assert merge['merged'] is True and merge['sha'] == MERGE
    reviews = read(RAW / 'review-state-482-final.json')['data']['repository']['pullRequest']
    assert reviews['headRefOid'] == HEAD
    assert not reviews['reviews']['pageInfo']['hasNextPage']
    assert not reviews['reviewThreads']['pageInfo']['hasNextPage']
    assert all(r['state'] != 'CHANGES_REQUESTED' for r in reviews['reviews']['nodes'])
    threads = reviews['reviewThreads']['nodes']
    assert len(threads) == 1 and threads[0]['isResolved']
    assert not threads[0]['comments']['pageInfo']['hasNextPage']
    assert [c['databaseId'] for c in threads[0]['comments']['nodes']] == [4286139155, 4286620802]
    assert HEAD in threads[0]['comments']['nodes'][1]['body']
    final_threads = read(RAW / 'review-threads-final-482.json')['structuredContent']['review_threads']
    assert len(final_threads) == 1 and final_threads[0]['id'] == threads[0]['id'] and final_threads[0]['is_resolved']
    assert all(r['state'] != 'CHANGES_REQUESTED' for r in
               read(RAW / 'reviews-final-482.json')['structuredContent']['reviews'])

    source = read(RAW / 'integrated-sources-482.json')
    primary_source = read(RAW / 'integrated-sources-primary-acceptance-483.json')
    assert source['status'] == primary_source['status'] == 'passed'
    assert all(source['checks'].values()) and primary_source['selector_ast_matches']
    assert primary_source['worker_report_sha256'] == sha(RAW / 'integrated-sources-482.json')
    immutable, records = source_check.immutable_source_map(MERGE)
    accepted = read(source_check.ACCEPTED)['source_sha256']
    assert {p: row['sha256'] for p, row in immutable.items()} == accepted and len(accepted) == 2264
    assert all(mode in ('100644', '100755') for _, _, mode in records)
    trees = {revision: subprocess.check_output(['git', 'rev-parse', revision + '^{tree}'], cwd=ROOT, text=True).strip()
             for revision in (HEAD, MERGE, SYNTHETIC)}
    assert set(trees.values()) == {source_check.EXPECTED_TREE}
    for key in ('cli', 'binding'):
        row = read(source_check.ARTIFACTS)[key]
        assert identity(row['path']) == {field: row[field] for field in ('path', 'bytes', 'sha256')}

    native_path = RAW / 'ci-refresh-481/job-116589685919-native_vortex_tests.log'
    native, native_groups = results(native_path, [(2813, 0, 26), (10, 0, 0), (7, 0, 0),
                                                 (7, 0, 0), (23, 0, 0), (4, 0, 0)])
    prior_native = read(RAW / 'ci-refresh-481/primary-acceptance-482.json')
    ignored = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', native, re.M)
    assert len(ignored) == 26 and sorted(ignored) == sorted(tuple(row) for row in prior_native['ignored_test_reasons'])
    assert len(prior_native['new_test_lines']) == 7 and all(line in native.splitlines() for line in prior_native['new_test_lines'])
    public_path = RAW / 'ci-481/job-116589685901-native_public_tests.log'
    public, public_groups = results(public_path, [(946, 0, 0), (0, 0, 0), (6, 0, 0),
                                                 (65, 0, 0), (44, 0, 0), (15, 0, 0)])
    review_tests = ['resident_batch_writes_create_new_destinations_with_either_overwrite_setting',
                    'single_batch_write_rejections_preserve_existing_files_before_input_demand',
                    'batch_fanout_keeps_existing_target_rejection_for_resident_and_streaming_input']
    assert all(re.search(r'^test .*' + name + r' \.\.\. ok$', public, re.M) for name in review_tests)
    wheel_acceptance = read(RAW / 'primary-wheels-acceptance-482.json')
    assert wheel_acceptance['status'] == 'passed' and len(wheel_acceptance['wheel_lanes']) == 3
    wheels = []
    for row in wheel_acceptance['wheel_lanes']:
        path = Path(row['log'])
        assert identity(path) == dict(path=str(path), bytes=row['bytes'], sha256=row['sha256'])
        text = plain(path)
        assert SYNTHETIC + ':refs/remotes/pull/1557/merge' in text
        marker = '{\n  "schema_version": "shardloom.native_python_wheel_proof.v1"'
        assert text.count(marker) == 1
        start = text.index(marker)
        proof, consumed = json.JSONDecoder().raw_decode(text[start:])
        assert proof == row['proof'] and (start, start + consumed) == (row['proof_start'], row['proof_end'])
        assert proof['status'] == proof['stage']['status'] == proof['integrity']['status'] == 'passed'
        assert proof['integration'] == dict(tests=84, failures=0, errors=0, skipped=0, status='passed')
        assert all(step['returncode'] == 0 for step in proof['steps'])
        assert proof['installed_load']['isolated_install'] and proof['installed_load']['version'] == '0.6.0'
        assert proof['publication_attempted'] is False and proof['performance_claim'] is False
        wheels.append(dict(raw=identity(path), proof=proof))

    preview = served(RAW / 'preview', HEAD)
    production = served(RAW / 'production-483', MERGE)
    deploy = read(RAW / 'production-483/deployment-check.json')
    assert deploy['head_sha'] == MERGE and deploy['status'] == 'completed' and deploy['conclusion'] == 'success'
    assert production['deployment_completion_proven'] is True and production['deployment_check_id'] == deploy['id']
    assert production['deployment_version'] in deploy['output']['summary']
    assert production['commit_check_runs_sha256'] == sha(RAW / 'production-483/commit-check-runs.json')
    browser = {name: read(RAW / name) for name in ('preview-browser-481.json', 'production-browser-483.json')}
    assert all(row['status'] == 'passed' for row in browser.values())
    prior_checks = read(RAW / 'prior-merge-check-runs-481.json')
    assert prior_checks['total_count'] == len(prior_checks['check_runs']) <= 100
    prior = [r for r in prior_checks['check_runs'] if r['name'] == 'Workers Builds: shardloom']
    assert len(prior) == 1 and prior[0]['id'] == 116464471394
    prior = prior[0]
    assert prior['head_sha'] == 'fb1812dec4f9fa724b2c587353c74162935e0b2c'
    assert prior['status'] == 'completed' and prior['conclusion'] == 'success'
    assert 'ac5adae2-94da-44de-acbe-1d1038fc6c13' in prior['output']['summary']

    report = dict(schema_version='shardloom.native_stream_destination_hosted_verification.v1', status='passed',
        recorded_at=datetime.now(timezone.utc).isoformat(), pr=1557, head=HEAD, merge=MERGE, synthetic=SYNTHETIC,
        trees=trees, checks_passed=44, native_test_groups=native_groups, native_total=2864,
        native_manual_exclusions=26, native_public_test_groups=public_groups, native_public_total=1076,
        new_native_tests=prior_native['new_test_lines'], new_public_review_tests=review_tests,
        wheel_lanes=wheels, source_files_verified=2264, source_delta=source['source_maps']['prior_to_accepted_delta'],
        cli_and_binding_identity_verified=True, served=dict(preview=preview, production=production), browser=browser,
        review='The initial runtime review raised one existing-target claim; exact prior/current reproduction disproved it. The final change adds test-only proof. The thread is answered and resolved; no requested changes remain.',
        prior_1556_deployment_addendum=dict(check_id=prior['id'], completed_at=prior['completed_at'],
            version='ac5adae2-94da-44de-acbe-1d1038fc6c13', raw=identity(RAW / 'prior-merge-check-runs-481.json'),
            correction='The earlier packet observed the initial in-progress check ID. A separate completed check supplies success and the deployed version; preserve the earlier observation and supersede its pending conclusion.'),
        preserved_capture_issues=[
            'pr-updated-482-final-5.json is an empty output from a GitHub TLS timeout; complete final checks came from the connector.',
            'The macOS collector reported relative JSON end offsets as absolute. The original report is retained; all three complete wheel proofs and corrected absolute spans are independently checked.',
            'The initial new-test-line search used the wrong substring; seven exact passing test declarations were then checked without rerunning tests.'],
        source_version='0.6.0', publication_attempted=False, driver=identity(__file__))
    save(RAW / 'verification-483.json', report)
    files = {'hosted/' + str(p.relative_to(RAW)): p for p in RAW.rglob('*') if p.is_file()}
    helpers = [Path(__file__), Path(source_check.__file__), source_check.ACCEPTED, source_check.ARTIFACTS,
               OUT / 'freeze_native_release_298.py', OUT / 'capture_stream_destination_preview_480.py',
               OUT / 'capture_native_production_481.py', OUT / 'collect_stream_destination_ci_481.py',
               OUT / 'collect_stream_destination_ci_refresh_481.py', OUT / 'collect_stream_destination_macos_482.py']
    for path in helpers:
        files['support/' + path.name] = path
    destination = require_local_path(OUT / 'stream-destination-hosted-packet-483', Path.home(), sys.platform)
    check_budgets(OUT, destination, OUT / 'logs', min_free_bytes=12*GIB,
                  reserve_bytes=128*MIB, max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
    destination.mkdir(exist_ok=False)
    archive = destination / 'native-stream-destinations-hosted-2026-10-15.tar.xz'
    index = destination / 'native-stream-destinations-hosted-2026-10-15.json'
    members = []
    with tarfile.open(archive, 'x:xz') as stream:
        for name, path in sorted(files.items()):
            before = identity(path)
            payload = path.read_bytes()
            entry = tarfile.TarInfo(name); entry.size = len(payload); entry.mode = 0o644
            stream.addfile(entry, io.BytesIO(payload))
            assert identity(path) == before
            members.append(dict(name=name, bytes=before['bytes'], sha256=before['sha256']))
    import hashlib
    with tarfile.open(archive, 'r:xz') as stream:
        entries = stream.getmembers()
        assert len(entries) == len({r.name for r in entries}) == len(members)
        assert all(entry.isfile() for entry in entries)
        assert {r.name for r in entries} == set(files)
        for member in members:
            payload = stream.extractfile(member['name']).read()
            assert len(payload) == member['bytes'] and hashlib.sha256(payload).hexdigest() == member['sha256']
            assert payload == files[member['name']].read_bytes()
    save(index, dict(schema_version='shardloom.native_stream_destination_hosted_packet.v1', status='passed',
        pr=1557, head=HEAD, merge=MERGE, synthetic=SYNTHETIC, checks_passed=44,
        native_test_groups=native_groups, native_total=2864, native_public_total=1076,
        wheel_lanes=3, wheel_tests_per_lane=84, source_files_verified=2264,
        served_responses_verified=16, production_version=production['deployment_version'],
        production_deployment_check_complete=True, prior_1556_deployment_addendum=report['prior_1556_deployment_addendum'],
        browser_scope='Preview and production each have two inspected viewport screenshots, five search results and successful navigation; screenshots were inspected inline and are not archived.',
        archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=sha(archive)),
        members_verified=len(members), members=members, publication_attempted=False))
    for path in (archive, index):
        target = ROOT / 'docs/benchmarks/evidence' / path.name
        assert not target.exists()
        shutil.copy2(path, target)
        assert sha(target) == sha(path)
    print(json.dumps(dict(status='passed', checks=44, wheel_lanes=3, sources=2264,
                          served_responses=16, members=len(members), archive_sha256=sha(archive))))


if __name__ == '__main__':
    main()
