#!/usr/bin/env python3
"""Single-fetch refresh for the two remaining PR #1557 jobs."""
import hashlib
import json
import re
import subprocess
from pathlib import Path

BASE = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010/stream-destination-hosted-478/ci-refresh-481')
REPO = 'depsilon/shardloom'
JOBS = {116589685919: 'native_vortex_tests', 116589685738: 'native_python_wheel_py313_macos'}
TIME_PREFIX = re.compile(r'^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?Z ?')


def sha(b):
    return hashlib.sha256(b).hexdigest()


def call(endpoint):
    return subprocess.run(['gh', 'api', endpoint], stdout=subprocess.PIPE, stderr=subprocess.PIPE)


def save_evidence(name, kind, data):
    path = BASE / f'{name}.{kind}'
    path.write_bytes(data)
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def get_once(endpoint, pathstem):
    proc = call(endpoint)
    if proc.returncode == 0:
        return {'endpoint': endpoint, 'exit_code': 0,
                'evidence': save_evidence(pathstem, 'json' if 'logs' not in endpoint else 'log', proc.stdout)}, proc.stdout
    error = proc.stdout + (b'\n' if proc.stdout else b'') + proc.stderr
    return {'endpoint': endpoint, 'exit_code': proc.returncode,
            'retrieval_error': save_evidence(pathstem, 'retrieval-error.txt', error),
            'error_excerpt': error.decode('utf-8', 'replace')[:2000]}, None


def unprefix(raw):
    return '\n'.join(TIME_PREFIX.sub('', line) for line in raw.decode('utf-8', 'replace').splitlines())


def extract_proof(text):
    marker = 'shardloom.native_python_wheel_proof.v1'
    pos = text.find(marker)
    if pos < 0:
        return None, 'proof schema marker absent from completed macOS log'
    start = text.rfind('{', 0, pos)
    if start < 0:
        return None, 'opening JSON object for proof schema not found'
    decoder = json.JSONDecoder()
    try:
        value, _ = decoder.raw_decode(text[start:])
    except json.JSONDecodeError as exc:
        return None, f'proof JSON parse failed: {exc}'
    if value.get('schema_version') != marker:
        return None, f'parsed JSON schema mismatch: {value.get("schema_version")!r}'
    return value, None


def main():
    BASE.mkdir(parents=True, exist_ok=True)
    report = {'schema_version': 'shardloom.native_ci_refresh.v1', 'repository': REPO,
              'jobs': [], 'errors_or_gaps': []}
    for job_id, label in JOBS.items():
        stem = f'job-{job_id}-{label}'
        meta_ev, raw = get_once(f'repos/{REPO}/actions/jobs/{job_id}', stem)
        item = {'job_id': job_id, 'label': label, 'metadata_evidence': meta_ev}
        if raw is None:
            item['status'] = 'metadata_fetch_failed'
            report['errors_or_gaps'].append({'job_id': job_id, 'error': meta_ev.get('error_excerpt')})
            report['jobs'].append(item)
            continue
        try:
            meta = json.loads(raw)
        except json.JSONDecodeError as exc:
            item['status'] = 'metadata_parse_failed'
            item['metadata_parse_error'] = str(exc)
            report['errors_or_gaps'].append({'job_id': job_id, 'error': str(exc)})
            report['jobs'].append(item)
            continue
        for key in ('name', 'status', 'conclusion', 'head_sha', 'started_at', 'completed_at', 'run_id', 'steps'):
            item[key] = meta.get(key)
        if meta.get('status') != 'completed':
            item['log_status'] = 'not fetched: one-shot metadata reports job not completed; no polling performed'
            report['errors_or_gaps'].append({'job_id': job_id, 'status': meta.get('status'),
                                             'conclusion': meta.get('conclusion'), 'gap': 'pending at single metadata fetch'})
            report['jobs'].append(item)
            continue
        log_ev, lograw = get_once(f'repos/{REPO}/actions/jobs/{job_id}/logs', stem)
        item['log_evidence'] = log_ev
        if lograw is None:
            report['errors_or_gaps'].append({'job_id': job_id, 'error': log_ev.get('error_excerpt')})
            report['jobs'].append(item)
            continue
        text = unprefix(lograw)
        item['checkout_evidence_lines'] = [x for x in text.splitlines() if any(s in x for s in
            ('Checking out the ref', 'git checkout --progress --force', 'HEAD is now at'))]
        if label == 'native_vortex_tests':
            lines = text.splitlines()
            item['test_result_lines'] = [x.strip() for x in lines if 'test result:' in x]
            item['test_groups'] = []
            current = 'unattributed test output'
            group = None
            for line in lines:
                if line.startswith('##[group]Run '):
                    current = line[len('##[group]Run '):]
                if line.startswith('test result:'):
                    vals = re.search(r'test result:\s+\w+\.\s+(\d+) passed;\s+(\d+) failed;\s+(\d+) ignored;', line)
                    item['test_groups'].append({'group_context': current, 'line': line.strip(),
                        'passed': int(vals.group(1)) if vals else None,
                        'failed': int(vals.group(2)) if vals else None,
                        'ignored': int(vals.group(3)) if vals else None})
                if re.search(r'\btest\s+\S+\s+\.\.\. ignored(?:,|$)', line):
                    item.setdefault('ignored_test_lines', []).append(line.strip())
            item['failed_or_error_lines'] = [x.strip() for x in lines if re.search(r'FAILED|error:|Error:|panicked at', x)]
            item['stream_destination_lines'] = [x.strip() for x in lines if re.search(r'stream.*destination|destination.*stream', x, re.I)]
        else:
            proof, err = extract_proof(text)
            item['proof_parse_error'] = err
            item['proof'] = proof
            if proof is not None:
                item['proof_summary'] = {
                    'schema_version': proof.get('schema_version'),
                    'integration': proof.get('integration'),
                    'installation': proof.get('installation'),
                    'wheel': proof.get('wheel'),
                }
        report['jobs'].append(item)
    report['status'] = 'evidence_collected' if not report['errors_or_gaps'] else 'evidence_collected_with_gaps'
    out = BASE / 'ci-refresh-report.json'
    out.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': report['status'], 'report': str(out),
                      'jobs': [{'job_id': j['job_id'], 'status': j.get('status'), 'conclusion': j.get('conclusion'),
                                'log': j.get('log_evidence')} for j in report['jobs']],
                      'gaps': report['errors_or_gaps']}, indent=2))


if __name__ == '__main__':
    main()
