#!/usr/bin/env python3
"""Fetch and parse the completed macOS native wheel CI job exactly once."""
import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
META_SOURCE = ROOT / 'stream-destination-hosted-478/macos-progress-482-1.json'
OUT = ROOT / 'stream-destination-hosted-478/macos-final-482'
JOB_ID = 116589685738
RUN_ID = 38783563557
PR_HEAD = '54f107d4add9d1d218f0f78e47c8d6f76785120a'
REPO = 'depsilon/shardloom'
SCHEMA = 'shardloom.native_python_wheel_proof.v1'
TS = re.compile(r'^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?Z ?')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def evidence(path, data):
    path.write_bytes(data)
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def parse_proof(raw):
    text = '\n'.join(TS.sub('', line) for line in raw.decode('utf-8', 'replace').splitlines())
    marker = f'"schema_version": "{SCHEMA}"'
    marker_pos = text.find(marker)
    if marker_pos < 0:
        return text, None, {'code': 'proof_schema_marker_missing'}
    # Candidate outer JSON objects are bare opening-brace lines before the marker.
    # Try nearest candidates first and require the parsed root object's schema to match.
    starts = [m.start() for m in re.finditer(r'(?m)^\{\s*$', text[:marker_pos])]
    decoder = json.JSONDecoder()
    candidates = []
    for start in reversed(starts[-80:]):
        try:
            value, end = decoder.raw_decode(text[start:])
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict) and value.get('schema_version') == SCHEMA:
            candidates.append((end, start, value))
    if not candidates:
        return text, None, {'code': 'proof_outer_json_not_found', 'candidate_count': len(starts)}
    # The complete proof object is the matching candidate that spans the most bytes.
    end, start, proof = max(candidates, key=lambda x: x[0] - x[1])
    return text, proof, {'start_offset': start, 'end_offset': end, 'candidate_count': len(candidates),
                         'selected_span_bytes': end - start}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    meta_raw = META_SOURCE.read_bytes()
    meta_ev = evidence(OUT / f'job-{JOB_ID}.json', meta_raw)
    metadata = json.loads(meta_raw)
    report = {'schema_version': 'shardloom.native_python_macos_job.v1', 'repository': REPO,
              'run_id': RUN_ID, 'job_id': JOB_ID, 'requested_pr_head': PR_HEAD,
              'metadata_evidence': meta_ev,
              'metadata_matches_expected': {'job_id': metadata.get('id') == JOB_ID,
                  'run_id': metadata.get('run_id') == RUN_ID,
                  'status_completed': metadata.get('status') == 'completed',
                  'conclusion_success': metadata.get('conclusion') == 'success',
                  'head_sha_matches_requested_pr_head': metadata.get('head_sha') == PR_HEAD},
              'metadata_summary': {k: metadata.get(k) for k in
                  ('name','status','conclusion','head_sha','run_id','started_at','completed_at')},
              'proof_step_outcomes': [{'name':s.get('name'),'status':s.get('status'),
                                       'conclusion':s.get('conclusion'),'started_at':s.get('started_at'),
                                       'completed_at':s.get('completed_at')}
                                      for s in metadata.get('steps',[])]}
    if not all(report['metadata_matches_expected'].values()):
        report['status'] = 'metadata_mismatch'
        report['errors_or_gaps'] = ['Saved completed-job metadata did not match the expected successful job and PR head; log fetch skipped.']
    else:
        endpoint = f'repos/{REPO}/actions/jobs/{JOB_ID}/logs'
        proc = subprocess.run(['gh','api',endpoint],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        report['log_endpoint'] = endpoint
        if proc.returncode != 0:
            err = proc.stdout + (b'\n' if proc.stdout else b'') + proc.stderr
            report['log_retrieval_error'] = evidence(OUT / f'job-{JOB_ID}.retrieval-error.txt',err)
            report['status'] = 'log_retrieval_failed'
            report['errors_or_gaps'] = [err.decode('utf-8','replace')[:2000]]
        else:
            raw = proc.stdout
            log_ev = evidence(OUT / f'job-{JOB_ID}.log',raw)
            text, proof, parse = parse_proof(raw)
            report.update({'status':'evidence_collected','log_evidence':log_ev,
                           'proof_parse':parse,'proof':proof,
                           'checkout_evidence_lines':[x for x in text.splitlines() if any(s in x for s in
                               ('Checking out the ref','git checkout --progress --force','HEAD is now at'))],
                           'errors_or_gaps':[] if proof is not None else ['Completed log did not yield the expected complete proof object.']})
            if proof is not None:
                report['proof_summary'] = {k:proof.get(k) for k in
                    ('schema_version','status','integration','installation','wheel','steps','artifacts') if k in proof}
                report['exact_log_lines'] = [x for x in text.splitlines() if re.search(
                    r'"schema_version"|"tests"|"failures"|"errors"|"skipped"|"status"|"sha256"|"isolated"|"library"|"cli"|"integration"|"installed"',x)]
    out = OUT / 'macos-final-report.json'
    out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':report['status'],'report':str(out),
                      'log':report.get('log_evidence'),
                      'proof_schema':(report.get('proof') or {}).get('schema_version'),
                      'proof_keys':list((report.get('proof') or {}).keys()),
                      'errors_or_gaps':report.get('errors_or_gaps')},indent=2))


if __name__ == '__main__':
    main()
