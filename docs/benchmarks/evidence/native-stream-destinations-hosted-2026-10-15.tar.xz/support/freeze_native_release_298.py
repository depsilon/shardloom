"""Freeze release artifacts and source identities for native Python acceptance."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def sha(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            result.update(block)
    return result.hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def sources():
    paths = subprocess.check_output(
        ['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'],
        cwd=ROOT).split(b'\0')
    files = {}
    for raw in paths:
        name = raw.decode()
        selected = (name.endswith(('.rs', '.py')) or name.endswith('Cargo.toml')
                    or name == 'Cargo.lock' or name.startswith('.cargo/')
                    or name.startswith(('python/src/', 'python/tests/',
                                        'python/THIRD_PARTY_LICENSES/', 'vendor/'))
                    or name in ('python/pyproject.toml', 'python/setup.py',
                                'python/LICENSE', 'python/NOTICE')
                    or name.startswith('scripts/') and 'native_python' in name)
        if name and selected and (ROOT / name).is_file():
            files[name] = sha(ROOT / name)
    assert files
    return files


def receipt(name):
    path = OUT / f'{name}.json'
    record = json.loads(path.read_text())
    assert record['status'] == 'passed' and record['process_group_drained']
    assert '--release' in record['command']
    log = OUT / f'{name}.log'
    assert sha(log) == record['log_sha256']
    return path, record, log


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--run-id', default='298')
    args = parser.parse_args()
    assert args.run_id.isalnum()
    source_path = OUT / f'native-release-source-{args.run_id}.json'
    if args.prepare:
        record = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'],
                  cwd=ROOT, text=True).strip(), 'source_sha256': sources()}
        save(source_path, record)
        print(json.dumps({'status': 'prepared', 'files': len(record['source_sha256'])}))
        return
    frozen = json.loads(source_path.read_text())
    assert sources() == frozen['source_sha256'], 'build source changed after freeze'
    cli_receipt, cli_build, cli_log = receipt(f'native-final-cli-release-build-{args.run_id}')
    entries = [json.loads(line) for line in cli_log.read_text().splitlines()
               if line.startswith('{')]
    artifacts = [entry for entry in entries if entry.get('reason') == 'compiler-artifact'
                 and entry.get('target', {}).get('name') == 'shardloom'
                 and entry.get('executable')]
    assert len(artifacts) == 1 and artifacts[0]['profile']['opt_level'] == '3'
    source = Path(artifacts[0]['executable'])
    assert source.is_file() and not source.is_symlink()
    destination = require_local_path(OUT / f'native-cli-release-{args.run_id}', Path.home(), sys.platform)
    assert not destination.exists()
    check_budgets(OUT, destination, OUT / 'logs', min_free_bytes=12 * GIB,
                  reserve_bytes=source.stat().st_size + 128 * MIB,
                  max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    destination.mkdir()
    cli = destination / 'shardloom'
    identity = sha(source)
    shutil.copy2(source, cli)
    assert sha(cli) == sha(source) == identity
    binding_receipt, binding_build, binding_log = receipt(f'native-final-python-release-build-{args.run_id}')
    content = binding_log.read_text()
    offset = content.index('{\n  "schema_version": "shardloom.native_python_build.v1"')
    binding = json.loads(content[offset:])
    assert binding['status'] == 'passed' and '--release' in binding['command']
    library = Path(binding['library'])
    assert sha(library) == sha(binding['cargo_artifact']) == binding['library_sha256']
    record = {'schema_version': 'shardloom.native_python_release_artifacts.v1',
              'status': 'passed', 'build_profile': 'release', **frozen}
    for kind, artifact, build_path, log in [
        ('cli', cli, cli_receipt, cli_log),
        ('binding', library, binding_receipt, binding_log),
    ]:
        record[kind] = {'path': str(artifact), 'sha256': sha(artifact),
                        'bytes': artifact.stat().st_size,
                        'build_receipt': str(build_path),
                        'build_receipt_sha256': sha(build_path), 'build_log': str(log)}
    save(OUT / f'native-release-artifacts-{args.run_id}.json', record)
    print(json.dumps({'status': 'passed', 'source_files': len(frozen['source_sha256']),
                      'cli_bytes': cli.stat().st_size, 'binding_bytes': library.stat().st_size}))


if __name__ == '__main__':
    main()
