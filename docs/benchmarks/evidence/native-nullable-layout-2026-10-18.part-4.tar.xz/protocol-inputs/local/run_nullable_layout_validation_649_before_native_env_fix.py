"""Run finite nullable-layout validation groups against one frozen source tree."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import time

from freeze_native_release_298 import ROOT, OUT, save, sha, sources

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--group', choices=['provider', 'native'], required=True)
args = parser.parse_args()
source_path = OUT / 'native-release-source-nullable649.json'
frozen = json.loads(source_path.read_text())
array_patch = 'patch.crates-io.vortex-array.path="vendor/vortex-array"'
layout_patch = 'patch.crates-io.vortex-layout.path="vendor/vortex-layout"'
layout_options = ['--manifest-path', 'vendor/vortex-layout/Cargo.toml', '--offline',
                  '--config', array_patch, '--features', 'tokio,vortex-io/tokio,vortex-array/_test-harness']
file_options = ['--manifest-path', 'vendor/vortex-file/Cargo.toml', '--offline',
                '--config', array_patch, '--config', layout_patch, '--features', 'tokio,vortex-array/table-display']
groups = {
    'provider': [
        ('layout-tests', ['cargo', 'test', *layout_options, '--lib', '--', '--test-threads=2']),
        ('layout-clippy', ['cargo', 'clippy', *layout_options, '--lib', '--', '-D', 'warnings']),
        ('file-clippy', ['cargo', 'clippy', *file_options, '--lib', '--', '-D', 'warnings']),
    ],
    'native': [
        ('native-clippy', ['cargo', 'clippy', '--offline', '--locked', '-p', 'shardloom-vortex',
                           '--features', 'release-user-surfaces', '--all-targets', '--', '-D', 'warnings']),
        ('native-vortex-tests', ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-vortex',
                                 '--features', 'release-user-surfaces', '--lib', '--', '--test-threads=2']),
        ('native-cli-tests', ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-cli',
                              '--lib', '--bin', 'shardloom', '--test', 'vortex_prepare',
                              '--test', 'public_memory_inputs', '--test', 'public_workflow_route',
                              '--test', 'resident_worker', '--features', 'release-user-surfaces',
                              '--', '--test-threads=2']),
    ],
}
os.environ['CLIPPY_CONF_DIR'] = str(ROOT / 'vendor/vortex-array')
os.environ['RUST_TEST_THREADS'] = '2'
results = []
passed = False
try:
    assert sources() == frozen['source_sha256']
    for name, command in groups[args.group]:
        print(json.dumps({'gate': name, 'command': command}), flush=True)
        start = time.perf_counter()
        result = subprocess.run(command, cwd=ROOT, check=False)
        results.append(dict(name=name, command=command, returncode=result.returncode,
                            diagnostic_seconds=time.perf_counter() - start))
        assert sources() == frozen['source_sha256'], 'source changed during validation'
        if result.returncode:
            raise SystemExit(result.returncode)
    passed = True
finally:
    save(OUT / f'nullable-layout-{args.group}-results-649.json', dict(
        status='passed' if passed else 'failed', group=args.group, gates=results,
        source=str(source_path), source_sha256=sha(source_path), source_files=len(frozen['source_sha256'])))
