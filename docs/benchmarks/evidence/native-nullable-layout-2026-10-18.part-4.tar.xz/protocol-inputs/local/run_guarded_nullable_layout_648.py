"""Run nullable-layout validation through the unchanged local workload guard."""
import hashlib
from pathlib import Path

source = Path(__file__).with_name('run_guarded_worker_drain_565.py').read_bytes()
assert hashlib.sha256(source).hexdigest() == '31daaeed239f2eddebaca8aede8f329204a1ce8093d90bb41902608b3a763ddd'
old_root = "/Users/dylan/.codex/worktrees/native-relational-workflows/shardloom-local-repo"
new_root = "/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo"
text = source.decode()
assert text.count(old_root) == 1
exec(compile(text.replace(old_root, new_root), __file__, 'exec'))
