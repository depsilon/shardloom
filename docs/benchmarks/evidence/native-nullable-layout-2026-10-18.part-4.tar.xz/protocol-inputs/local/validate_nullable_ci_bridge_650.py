"""Verify the CI-only source update after the native regression source freeze."""
import json
import os
from pathlib import Path
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, save, sha, sources


def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


before_path = OUT / 'native-release-source-nullable649.json'
after_path = OUT / 'native-release-source-nullable650a1.json'
before = json.loads(before_path.read_text())['source_sha256']
after = json.loads(after_path.read_text())['source_sha256']
assert sources() == after and set(before) == set(after)
changes = {name: dict(before=before[name], after=after[name])
           for name in before if before[name] != after[name]}
assert set(changes) == {'scripts/check_ci_gate_matrix.py'}
sys.path[:0] = [str(ROOT / 'scripts'), str(ROOT / 'python/tests')]
import check_ci_gate_matrix as ci
lane = next(lane for lane in ci.REQUIRED_LANES if lane.lane_id == 'rust_feature_matrix')
workflow = (ROOT / '.github/workflows/ci.yml').read_text()
doc = (ROOT / 'docs/release/ci-gate-matrix.md').read_text()
assert ci.lane_status(lane, workflow, doc)['status'] == 'passed'
target = next(command for command in lane.commands
              if command.startswith('cargo test --manifest-path vendor/vortex-layout/Cargo.toml '))
assert workflow.count(target) == 1
narrow = workflow.replace(target, target.replace('--lib -- --test-threads=2', '--lib layouts::file_stats::tests::'))
assert ci.lane_status(lane, narrow, doc)['status'] == 'failed'
clippy = 'CLIPPY_CONF_DIR="$PWD/vendor/vortex-array" cargo clippy --manifest-path vendor/vortex-layout/Cargo.toml'
assert workflow.count(clippy) == 1
assert ci.lane_status(lane, workflow.replace(clippy, 'echo omitted'), doc)['status'] == 'failed'
env = dict(os.environ, PYTHONPATH=os.pathsep.join(map(str, [ROOT / 'python/tests', ROOT / 'python/src', ROOT / 'scripts'])))
tests = ['test_ci_gate_matrix_scopes_commands_to_declared_job',
         'test_ci_gate_matrix_requires_hard_release_without_allow_blocked',
         'test_ci_gate_matrix_requires_windows_native_release_build',
         'test_native_wheel_ci_attempts_do_not_reuse_cached_proofs']
commands = [
    ('ci-matrix', [sys.executable, '-B', 'scripts/check_ci_gate_matrix.py', '--output', str(OUT / 'nullable-layout-ci-matrix-650-a1.json')]),
    ('ci-contract-tests', [sys.executable, '-B', '-m', 'unittest', *['test_release_scripts.ReleaseScriptTests.' + name for name in tests]]),
    ('release-metadata-tests', ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-contract-tests', '--test', 'release_readiness_metadata']),
    ('license-bundle', [sys.executable, '-B', 'scripts/check_python_license_bundle.py']),
]
gates = []
passed = False
try:
    for name, command in commands:
        print(json.dumps(dict(gate=name, command=command)), flush=True)
        result = subprocess.run(command, cwd=ROOT, env=env, check=False)
        gates.append(dict(name=name, command=command, returncode=result.returncode))
        if result.returncode:
            raise SystemExit(result.returncode)
    assert sources() == after
    passed = True
finally:
    save(OUT / 'nullable-layout-ci-bridge-650-a1.json', dict(status='passed' if passed else 'failed',
        tested_source=identity(before_path), build_source=identity(after_path), changes=changes,
        old_narrow_target_rejected=True, missing_layout_clippy_rejected=True, gates=gates,
        workflow=identity(ROOT / '.github/workflows/ci.yml'), documentation=identity(ROOT / 'docs/release/ci-gate-matrix.md')))
