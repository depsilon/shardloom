"""Bind nullable-layout acceptance to frozen source, gates and release artifacts."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

import run_zstd_metadata_acceptance_533 as common
from freeze_native_release_298 import ROOT, OUT, save

SOURCE = OUT / 'native-release-source-nullable650a1.json'
MANIFEST = OUT / 'native-release-artifacts-nullable650a1.json'
TEST_SOURCE = OUT / 'native-release-source-nullable649.json'
PROTOCOL = OUT / 'nullable-layout-acceptance-protocol-650.json'
PUBLIC = OUT / 'nullable-layout-public-650'
DIRECT = OUT / 'nullable-layout-direct-tests-650.json'
PUBLIC_ACCEPTANCE = OUT / 'nullable-layout-public-acceptance-650.json'
PRIOR = OUT / 'native-text-scan-acceptance-protocol-644.json'
for name in ('SOURCE', 'MANIFEST', 'PROTOCOL', 'PUBLIC', 'DIRECT', 'PUBLIC_ACCEPTANCE'):
    setattr(common, name, globals()[name])
identity, receipt, load, unchanged = common.identity, common.receipt, common.load, common.unchanged


def prerequisites():
    frozen = unchanged()
    tested = json.loads(TEST_SOURCE.read_text())
    assert set(tested['source_sha256']) == set(frozen['source_sha256'])
    changed = {name: {'before': before, 'after': frozen['source_sha256'][name]}
               for name, before in tested['source_sha256'].items()
               if before != frozen['source_sha256'][name]}
    assert set(changed) == {'scripts/check_ci_gate_matrix.py'}
    bridge_path = OUT / 'nullable-layout-ci-bridge-650-a1.json'
    bridge = json.loads(bridge_path.read_text())
    assert bridge['status'] == 'passed' and bridge['changes'] == changed
    assert bridge['tested_source'] == identity(TEST_SOURCE) and bridge['build_source'] == identity(SOURCE)
    assert bridge['old_narrow_target_rejected'] and bridge['missing_layout_clippy_rejected']
    assert all(row['returncode'] == 0 for row in bridge['gates'])
    receipt(OUT / 'nullable-layout-ci-contract-650-a1.json')
    groups = [
        ('native-final-source-gate-results-nullable649.json',
         'nullable-layout-workspace-gates-649.json',
         ['default-format', 'default-clippy', 'default-tests', 'reduced-writer-tests']),
        ('nullable-layout-provider-results-649.json', 'nullable-layout-provider-gates-649.json',
         ['layout-tests', 'layout-clippy', 'file-clippy']),
        ('nullable-layout-native-results-649-a1.json', 'nullable-layout-native-gates-649-a1.json',
         ['native-clippy', 'native-vortex-tests', 'native-cli-tests']),
    ]
    checks = [identity(TEST_SOURCE), identity(bridge_path),
              identity(OUT / 'nullable-layout-ci-contract-650-a1.json'),
              identity(OUT / 'nullable-layout-ci-contract-650-a1.log'),
              identity(OUT / 'nullable-layout-ci-matrix-650-a1.json')]
    for filename, guard, names in groups:
        path = OUT / filename
        result = json.loads(path.read_text())
        assert result['status'] == 'passed'
        assert [gate['name'] for gate in result['gates']] == names
        assert all(gate['returncode'] == 0 for gate in result['gates'])
        if 'source' in result:
            assert result['source'] == str(TEST_SOURCE) and result['source_sha256'] == identity(TEST_SOURCE)['sha256']
        receipt(OUT / guard)
        checks.extend([identity(path), identity(OUT / guard), identity((OUT / guard).with_suffix('.log'))])
    guard = OUT / 'nullable-layout-file-provider-tests-649.json'
    receipt(guard)
    checks.extend([identity(guard), identity(guard.with_suffix('.log'))])
    assert unchanged() == frozen
    return checks


def protocol():
    result = json.loads(PROTOCOL.read_text())
    for item in result['helpers'] + result['checks'] + [result[key] for key in
            ('source', 'artifacts', 'prior_protocol', 'baseline', 'contract')]:
        assert identity(item['path']) == item, item['path']
    return result


def declare():
    checks = prerequisites()
    manifest = load()
    prior = json.loads(PRIOR.read_text())
    previous_source = json.loads(Path(prior['source']['path']).read_text())['source_sha256']
    frozen = unchanged()['source_sha256']
    protected = [name for name in frozen if name.startswith(('python/', 'scripts/'))
                 and name != 'scripts/check_ci_gate_matrix.py']
    assert all(frozen[name] == previous_source[name] for name in protected)
    sys.path[:0] = [str(ROOT / 'python/src'), str(ROOT / 'scripts')]
    from run_native_streaming_input_uat import FAMILIES
    assert list(FAMILIES) == prior['expected_public_families'] and len(FAMILIES) == 36
    assert len(prior['expected_direct_names']) == len(set(prior['expected_direct_names'])) == 100
    assert len(prior['expected_public_names']) == len(set(prior['expected_public_names'])) == 4827
    assert identity(prior['baseline']['path']) == prior['baseline']
    contract_source = ROOT / 'docs/architecture/native-nullable-layout-2026-10-18.md'
    contract = OUT / 'nullable-layout-acceptance-contract-650.md'
    with contract.open('xb') as stream:
        stream.write(contract_source.read_bytes())
    helpers = [Path(__file__), Path(common.__file__), OUT / 'freeze_native_release_298.py',
        OUT / 'run_guarded_nullable_layout_648.py', OUT / 'run_guarded_worker_drain_565.py',
        OUT / 'run_query_timing_runtime_461.py', OUT / 'verify_stream_dynamic_subquery_public_522.py',
        OUT / 'run_nullable_layout_validation_649.py',
        OUT / 'run_nullable_layout_validation_649_before_native_env_fix.py',
        OUT / 'validate_nullable_ci_bridge_650.py',
        Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py')]
    save(PROTOCOL, dict(status='predeclared', public_and_direct_execution_started=False,
        source=identity(SOURCE), artifacts=identity(MANIFEST), prior_protocol=identity(PRIOR),
        checks=checks, helpers=[identity(path) for path in helpers], baseline=prior['baseline'],
        expected_direct_tests=100, expected_direct_names=prior['expected_direct_names'],
        expected_public_names=prior['expected_public_names'], expected_public_families=list(FAMILIES),
        contract=identity(contract), contract_source_path=str(contract_source),
        nonruntime_validation_change='scripts/check_ci_gate_matrix.py',
        unchanged_python_and_uat_files=protected, performance_claim=False,
        whole_process_memory_ceiling=False, installed_wheel_proof=False))
    assert load() == manifest
    protocol()
    print(json.dumps(dict(status='predeclared', direct_tests=100, public_cases=4827, families=36)))


def public():
    prerequisites()
    manifest, frozen = load(), protocol()
    direct = json.loads(DIRECT.read_text())
    assert direct['status'] == 'passed' and direct['tests'] == 100
    receipt(OUT / 'nullable-layout-direct-650.json')
    assert not PUBLIC.exists()
    command = [sys.executable, '-B', str(OUT / 'run_guarded_nullable_layout_648.py'),
        '--name', 'nullable-layout-public-650', '--timeout', '7200', '--',
        sys.executable, '-B', str(ROOT / 'scripts/run_native_streaming_input_uat.py'),
        '--binary', manifest['cli']['path'], '--uat-root', str(PUBLIC), '--operation-timeout', '600',
        '--compress-logs', '--families', *frozen['expected_public_families']]
    subprocess.run(command, cwd=ROOT, check=True)
    receipt(OUT / 'nullable-layout-public-650.json')
    summary = json.loads((PUBLIC / 'summary.json').read_text())
    assert summary['status'] == 'passed' and summary['compress_logs']
    assert summary['families'] == frozen['expected_public_families']
    assert [row['name'] for row in summary['cases']] == frozen['expected_public_names']
    assert all(row['status'] == 'passed' for row in summary['cases'])
    assert load() == manifest and protocol() == frozen
    save(PUBLIC_ACCEPTANCE, dict(status='passed', cases=4827, families=summary['families'],
        manifest=identity(MANIFEST), source=identity(SOURCE), protocol=identity(PROTOCOL),
        summary=identity(PUBLIC / 'summary.json'), direct=identity(DIRECT),
        source_identity_preserved=True, full43_pending=True))
    print(json.dumps(dict(status='passed', public_cases=4827, families=36)))


def inspect():
    import verify_stream_dynamic_subquery_public_522 as review
    review.PUBLIC = PUBLIC
    review.RUNTIME_PATH = PUBLIC_ACCEPTANCE
    review.RECEIPT_PATH = OUT / 'nullable-layout-public-650.json'
    review.BASELINE_PATH = PROTOCOL
    review.OUTPUT = OUT / 'nullable-layout-public-inspection-report-650.json'
    review.ACCEPTED_SOURCE = SOURCE
    review.load, review.unchanged = load, unchanged
    protocol()
    review.main()
    protocol()


common.prerequisites, common.protocol = prerequisites, protocol
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('declare', 'direct', 'public', 'inspect'))
    args = parser.parse_args()
    {'declare': declare, 'direct': common.direct, 'public': public, 'inspect': inspect}[args.operation]()
