## Summary

An admitted native aggregate could decode the same compressed text range for its filter and again for projection. Reuse the filtered native owner for that range, keep other columns behind the final selection mask, and release range metadata and payload ownership when the projection completes, fails or is cancelled. Admission depends on expression shape, types, projection and memory policy; it contains no benchmark-specific query, column, row-count or literal checks.

The prospective matched Full43 comparison passes the greater-than-3% retention gate: the sum of all 43 per-query two-sample engine means decreases from **57.3990281195 to 55.3462438375 seconds (3.576340%)**. Both paired totals improve, all 172 complete results and schemas match, and no query crosses the predefined material-regression rule. This is a bounded local comparison with uncontrolled OS cache state. Every sample remains retained.

The batch also preserves the rejected five-alternative ingestion-size screen and rejected mixed-key speed experiment. Neither changes the accepted runtime or input. The [acceptance report](docs/benchmarks/native-text-scan-reuse-2026-10-18.md), architecture contract, portable evidence, phase queue and generated website record the final scope.

## Contribution Route

- [x] Maintainer-authorized Codex-assisted work; contribution rights and the repository's current inactive DCO/future CLA posture reviewed.
- [x] Original implementation reviewed for correctness, license compatibility and tests; no restricted or unknown-license implementation copied.

## No-Fallback And Dependency Check

- [x] Existing Vortex 0.85 native reader, scan, expression and allocator providers remain isolated in `shardloom-vortex`.
- [x] No new dependency, external query-engine execution, input rewrite, package publication or release.
- [x] Sparse selections, pruning, dictionary encoding and residual/winner-filter paths retain their existing provider behavior.

## Security, Release, And RFC Impact

- [x] Range ownership, memory admission, cancellation and failure cleanup reviewed and tested.
- [x] Architecture and performance claims have source-bound evidence. Published 0.6.0 artifacts retain their original scope.
- [x] Broader PERF obligations and CG-1 through CG-23 remain open; no production-readiness or cross-engine superiority claim.

## Tests Run

- [x] Seven new native text-scan tests and seventeen related UTF-8/cancellation tests.
- [x] `cargo fmt --all -- --check`
- [x] `cargo clippy --workspace --all-targets -- -D warnings`
- [x] `cargo test --workspace --all-targets` — 4,374 passing executions.
- [x] Strict native all-target Clippy and native Vortex/CLI feature suites — 4,046 passing executions, 28 explicitly ignored manual benchmark/fixture cases.
- [x] Fresh native binding: all 100 direct methods pass without skips.
- [x] Public workflow acceptance: all 4,827 cases across 36 families pass; independent readback includes 1,578,741 pressure-fixture rows.
- [ ] Format/workflow matrix and final documentation/static-site checks: populate from completed receipts before opening the PR.

Counts across build configurations are execution counts, not unique test methods. Direct source-package testing is separate from installed-wheel acceptance.

## Reviewer State

Local source and evidence review is complete. Final-head CI, automated review, three installed-wheel lanes and deployed preview checks remain required before merge; production verification follows the merge.
