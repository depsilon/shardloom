<!-- SPDX-License-Identifier: Apache-2.0 -->

# Shared text aggregation optimization

Status: campaign started; no candidate retained yet. This batch follows the
native file-metadata correction in PR #1565 and remains under PERF-01/04/05/10.
The maintainer requests at least five retained improvements in one cohesive PR,
with focused ship/drop checks per candidate and full acceptance at the boundary.
Ingest duplication and physical-layout economics remain the second major target
under PERF-08/09. All PERF owners and CG-1 through CG-23 remain open.

The expert comparator is an encoded-columnar maintainer checking exact grouping,
borrowed and independent ownership, checked counters, unchanged floating-point
evaluation, resource admission and complete-operation evidence.

## Current attribution and comparison boundary

The accepted control's compiled sources are frozen at `566643cd`; the final PR
head `0c4a78e3` has exactly the same 2,410 selected source files. Its CLI SHA-256 is
`4dff4bfea01887fe960e081e38a1e556a51cabe04f6af64aea53762ed77f51a6`.
The fresh native dataset, complete reference results, and unprofiled single-pass
Full43 acceptance are recorded in the
[file-metadata report](../benchmarks/native-file-metadata-buffers-2026-10-17.md).

Five new serial diagnostic samples execute Q23, Q19, Q29, Q34 and Q35 through
that same ordinary native CLI, using the accepted fresh dataset and resource
policy. Every complete result matches its reference. All source identities and
30 raw output/profiling companions are checked; child processes and the workload
lock are released. The local `hotspot-profiles-582` packet retains the original
sampling helper and explicit in-memory parameter changes. No new profiling or
testing framework is introduced. Sampled clocks receive no performance credit.

The Q29 sample observes native text decompression, domain parsing, global string
interning, and independently owned strings created inside chunk MIN/MAX updates.
Q19 also observes dictionary construction and global identity binding. These
samples establish exercised mechanisms, not exclusive stage timings or an
expected speedup. Provider, worker and caller spans can overlap.

## First candidate: defer chunk extrema ownership

The dense transformed-dictionary consumer already reduces original dictionary
values into chunk-local domain groups before merging global state. Its temporary
MIN/MAX fields currently acquire independent `Arc<str>` values every time a
local extremum changes. The dictionary's lazy ownership cache retains those
copies until the chunk ends, including values rejected by global extrema.

Keep temporary extrema borrowed from the existing dictionary. Acquire an
independent owner only when global state adopts a final chunk extremum. Reuse
one arithmetic/comparison implementation for borrowed and owned state. Keep
dictionary IDs, row counts, transform order, first-seen dictionaries, chunk order,
floating-point updates, HAVING, ordering and source selection unchanged. Global
state must never retain a provider buffer for an escaping string.

This is distinct from the historical dropped owned weighted-partial experiment:
it neither removes the original dictionary/row IDs nor reconstructs row order.
The already-retained lazy ownership cache remains useful for repeated escaping
consumers. No allocation-growth policy or worker topology changes in this step.

Vortex-first classification: `implement_shardloom_kernel` within the existing
ShardLoom grouped consumer. The pinned Vortex 0.85 `VarBinViewArray`, `BufferString`
and native array owner supply the borrowed values. Vortex's grouped kernels
consume already-grouped arrays; they do not replace this existing flat-column
domain reduction and its exact evaluation order. The current feature gates,
native provider, execution/Native I/O certificates and independent promotion
boundary remain. `fallback_attempted=false` and `external_engine_invoked=false`
remain required. No Arrow execution boundary or external engine is added.

Acceptance starts with source-backed multi-value extrema fixtures that expose
unnecessary promotions on the control. Check MIN/MAX combinations, winning and
losing chunks, Unicode, repeated weights, ties, empty/zero-weight input, overflow,
independent readability and exact release of source-buffer credit. Retain the
existing nullable and native-dictionary admission tests. Follow with matched,
unprofiled ordinary CLI comparisons against the frozen control and unaffected
query controls. A speedup is unproven until those comparisons pass.

The control fails both new promotion regressions: 96 independent strings for
one final winner, and one independent string when global state keeps neither
temporary extremum. The candidate passes all nine ownership tests, including
four new cases, and eight existing transformed-dictionary tests. Native
all-target Clippy also passes. The new arithmetic cases check zero weights,
weights above the exact integer range of `f64`, ties, shared MIN/MAX owners,
count overflow and non-finite merge rejection. The two control failures and
their test-only source patch remain retained. Performance is still unmeasured.

## Following candidates and batch acceptance

Inspect current costs before admitting subsequent mechanisms. Immediate leads
are the scalar delimiter scans in the shared domain parser, repeated global
identity lookup on misses, full-width temporary string-count records, and the
second complete-key routing buffer. These are hypotheses, not retained changes
or authorization to revive an unchanged historical drop. Provider scheduling is
conditional on ownership and actual utilization evidence; additional queues are
not a default optimization.

Freeze each admitted mechanism, changed source, native artifact and comparison
before timing. Preserve complete outputs and all samples; use the existing
symmetric fastest-valid rule with engine execution clocks for both roles.
Numerical historical targets guide prioritization; useful measured gains still
need proportionate complexity, correctness, memory and regression acceptance.
No partial result or overlapping worker span substitutes for a complete query.

At the cohesive boundary, run required workspace formatting, Clippy and tests,
applicable native/provider and public-surface checks, complete Full43 and the
independent renamed/null/skew/collision/arithmetic fixtures. SQL, Python and CLI
must inherit the shared implementation. Keep the separate nullable-root,
remaining resident-state external-memory, and safe output-replacement/publication
backlog visible without claiming those breadth obligations complete.
