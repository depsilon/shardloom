"""Execute the fixed Sort cohort once through the unchanged original public worker."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys

import sort_runtime

OUT = Path(__file__).resolve().parent
S = OUT.parent / 'shared-operator-state-2026-11-10'
E = OUT.parent / 'expanded-query-2026-11-03'
TARGET = OUT / 'sort-cohort-r1'
PROTOCOL = OUT / 'sort-cohort-protocol-r1.json'
COHORT = OUT / 'sort-demand-cohort-r1.json'
sys.path[:0] = [str(S/'tools'), str(E/'tools')]
import run_current_10k as historical_driver
import run_current_capture_r1 as original_capture
import sort_capture as capture
from frozen_generation_binding import BINDING, HistoricalBinding
from query_surface.evidence import identity
from query_surface.expanded_freeze import read
from query_surface.expanded_run import verify

_historical = None


def historical_binding():
    global _historical
    if _historical is None:
        _historical = HistoricalBinding()
    return _historical


def verify_capture_source():
    historical_driver.verify_capture_source()
    expected = Path(original_capture.__file__).read_text()
    replacements = [
        ('def observe(root, resume, admission, historical):',
         'def observe(root, resume, admission, historical, selection):'),
        ('selected = [r for r in design["cases"] if stage != "alternate" or r["surrogate"]]',
         'selected = list(selection)'),
    ]
    for before, after in replacements:
        assert expected.count(before) == 1
        expected = expected.replace(before, after)
    assert Path(capture.__file__).read_text() == expected


def cohort(design):
    record = read(COHORT)
    assert record['status'] == 'frozen_before_candidate_execution'
    assert record['case_count'] == 606 and record['query_executions'] == 0
    assert record['attempts_per_case'] == 1 and record['repeats'] == record['warmups'] == 0
    assert record['groups'] == {'new_column_reduction':98, 'already_narrowed':19, 'all_fields_required':489}
    for item in record['source_identities']:
        actual = sort_runtime.identity(Path(item['path']))
        assert actual == {key:item[key] for key in ('bytes','sha256')}
    selected = []
    ordinals = []
    for item in record['cases']:
        ordinal = item['original_ordinal']
        assert design['cases'][ordinal] == item['declaration']
        selected.append(item['declaration'])
        ordinals.append(ordinal)
    assert ordinals == sorted(set(ordinals)) and len(selected) == 606
    return record, selected


def updated_admission(root):
    assert __debug__ and root == E
    verify_capture_source()
    runtime_proof = sort_runtime.verify()
    historical = historical_binding()
    with historical.admission_verifier(capture.common):
        design, inputs, frozen, relocated, archive, _ = capture.common.checked_admission(capture.common.ROOT_DEFAULT, E)
    frozen = historical.files(frozen)
    assert design['count'] == len(design['cases']) == 10000
    assert design['execution']['native_memory_bytes'] == 2 << 30
    assert design['execution']['threads'] == 2
    assert design['execution']['attempts_per_case_and_route'] == 1 and design['execution']['warmups'] == 0
    selection, selected = cohort(design)
    original = historical.stage_complete(E, 'native', 10000)
    polars = historical.stage_complete(E, 'polars', 10000)
    assert original['outcomes'].get('passed') == 9995 and polars['outcomes'] == {'passed':10000}
    prepared = read(E/'native-preparation/complete.json')
    assert prepared['status'] == 'passed'
    prepared_files = [item for profile in prepared['profiles'].values()
                      for item in [profile['manifest'], *profile['inputs'], *profile['receipts']]]
    runtime = {key:identity(Path(item['path'])) for key,item in runtime_proof['runtime'].items()}
    provenance_paths = [Path(path) for path in runtime_proof['proofs']]
    provenance_paths += [Path(__file__), Path(sort_runtime.__file__), OUT/'pipeline_runtime.py',
        Path(historical_driver.__file__), Path(original_capture.__file__), Path(capture.__file__),
        BINDING, S/'tools/frozen_generation_binding.py', E/'tools/run_shared_10k.py',
        E/'tools/run_investigation_cohort_r2.py', capture.WORKER,
        E/'native-preparation/complete.json', E/'observe-polars/complete.json',
        E/'observe-native/complete.json', COHORT, OUT/'sort-demand-design-r1.md',
        OUT/'supervise_sort_cohort.py', OUT/'replay_sort_cohort.py',
        OUT/'verify_sort_ancestors.py', OUT/'sort-ancestor-adversarial-r2.json']
    provenance_paths += [Path(item['path']) for item in selection['source_identities']]
    provenance = [identity(path) for path in sorted(set(provenance_paths))]
    updated = dict(schema='shardloom.sort_demand_runtime_binding.v1',
        role='fixed_original_sort_cohort_candidate', head=runtime_proof['head'],
        source_tree=runtime_proof['source_tree'], source_root=str(sort_runtime.ROOT),
        runtime=runtime, runtime_proof=runtime_proof,
        frozen_client_policy='Original archived Python client and all 65 harness files retained byte-exact',
        cohort=identity(COHORT), selection=selection['selection'], original_case_count=10000,
        selected_case_count=len(selected), baseline_source_commit=selection['baseline_source_commit'],
        baseline_queries_repeated=0, target=str(TARGET), provenance=provenance,
        original_worker=identity(capture.WORKER), frozen_harness_files=len(relocated),
        warmups=0, attempts_per_case=1, alternate_attempts=0,
        diagnostic_instrumentation=False, profiling=False, cache_manipulation=False)
    contract = dict(schema='shardloom.sort_source_demand_protocol.v1',
        status='admitted_before_execution', selection=updated['selection'],
        cohort=identity(COHORT), design=identity(E/'design.json'),
        inputs=identity(E/'inputs.json'), frozen=identity(E/'frozen.json'),
        execution=design['execution'], runtime_binding=updated,
        expected_attempt_count=606, attempts_per_case=1, warmups=0,
        primary_clock='engine_execution_seconds', required_complete_result_count=606,
        query_loop='Original run_current_capture_r1.observe with explicit selection argument only; same public worker and supervision',
        historical_generation_binding=identity(BINDING),
        isolation='All other task-owned local work idle; full source/input inventory before/after only',
        acceptance='Complete correct results, exact work/dependency review, lower complete-cohort engine sum; investigate resource/control regressions; no repeatability claim')
    if PROTOCOL.exists():
        assert read(PROTOCOL) == contract, 'frozen protocol changed'
    else:
        with PROTOCOL.open('x') as stream:
            json.dump(contract, stream, indent=2); stream.write('\n')
    files = [*frozen, *archive, *provenance, *runtime.values(),
             *historical.files(prepared_files), historical.current(original['ledger']),
             historical.current(polars['ledger']), identity(PROTOCOL)]
    verify(files)
    return design, dict(inputs, runtime=runtime), files, updated


def main():
    assert sys.executable == '/Users/dylan/.cache/shardloom/query-surface-polars-2.1.0/bin/python'
    assert not TARGET.exists() and not PROTOCOL.exists(), 'fresh one-pass destination required'
    os.environ['POLARS_MAX_THREADS'] = '2'
    print(json.dumps(dict(status='preparing_fixed_sort_cohort', at=datetime.now(timezone.utc).isoformat())), flush=True)
    selection = [item['declaration'] for item in read(COHORT)['cases']]
    capture.TARGET_NAME = str(TARGET)
    capture.observe(E, False, updated_admission, historical_binding(), selection)


if __name__ == '__main__':
    main()
