"""Inventory source-declared cardinality/cohort candidates; executes no queries."""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import sys

import verify_sort_exposure as frozen
from coverage_column_demand_r2 import demand
from coverage_declarations import identity

OUT = Path(__file__).resolve().parent
DEST = OUT / 'coverage-inventory-r1'
SORT = OUT / 'sort-demand-cohort-r1.json'
DESIGN = frozen.E / 'design.json'
OBSERVED = DEST / 'observed-query-evidence.jsonl.gz'


def encoded_expr(expr):
    return dict(op=expr.op, value=expr.value,
                args=[encoded_expr(arg) if hasattr(arg, 'op') else arg for arg in expr.args],
                columns=sorted(expr.columns()))


def walk(node, path=()):
    yield path, node
    for index, child in enumerate(node.inputs):
        yield from walk(child, path + (index,))


def main():
    result_path = DEST / 'cardinality-pools.json'
    markdown_path = DEST / 'cardinality-pools.md'
    assert not result_path.exists() and not markdown_path.exists()
    design = json.loads(DESIGN.read_bytes())
    sort_ids = {row['declaration']['id'] for row in json.loads(SORT.read_bytes())['cases']}
    legacy = {case.id: case for case in frozen.corpus(interactions='all', include_pending=False)}
    spaces = {space.name: space for space in frozen.spaces()}
    all_matches = {}
    with OBSERVED.open('rb') as raw:
        pass
    import gzip
    with gzip.open(OBSERVED, 'rt') as observations:
        for descriptor, line in zip(design['cases'], observations, strict=True):
            saved = json.loads(line)
            case = frozen.build(descriptor, spaces) if 'cell' in descriptor else legacy[descriptor['id']]
            assert case.id == saved['id'] == descriptor['id']
            assert case.identity == saved['case_identity'] == descriptor['case_identity']
            nodes = list(walk(case.relation))
            matches = []
            for path, node in nodes:
                if node.op == 'explode_case':
                    matches.append(dict(kind='explode_case', path=list(path)))
                elif node.op == 'aggregate':
                    keys, measures = node.args
                    if not keys and all(measure.argument is None for measure in measures):
                        matches.append(dict(kind='scalar_aggregate_no_arguments', path=list(path),
                            measures=[dict(function=m.function, argument=None) for m in measures]))
                elif node.op == 'project' and all(not expression.columns() for _, expression in node.args):
                    matches.append(dict(kind='constant_or_column_free_project', path=list(path),
                        expressions=[dict(name=name, expression=encoded_expr(expr)) for name, expr in node.args]))
            if not matches:
                continue
            required = defaultdict(set)
            demand(case.relation, {name for name, _ in case.relation.schema}, required)
            fields = saved['fields']
            projected = fields.get('native_source_demand_projected_columns')
            projected_count = int(projected) if projected is not None and str(projected).isdigit() else None
            record = dict(id=case.id, case_identity=case.identity, descriptor=dict(descriptor),
                surface=descriptor['surface'], native_format=descriptor['native_format'],
                family=descriptor['family'], profile=descriptor['profile'],
                declaration_matches=matches,
                source_fields_required_by_existing_demand={k: sorted(v) for k, v in sorted(required.items())},
                original_observation_projected_field_count=projected_count,
                intersects_sort_demand_cohort=case.id in sort_ids)
            all_matches[case.id] = record
    assert len(design['cases']) == 10000
    assert len(sort_ids) == 606
    masks = defaultdict(list)
    for record in all_matches.values():
        kinds = {item['kind'] for item in record['declaration_matches']}
        mask = '+'.join(kind for kind in ('explode_case', 'scalar_aggregate_no_arguments',
                                          'constant_or_column_free_project') if kind in kinds)
        masks[mask].append(record['id'])
    for values in masks.values():
        values.sort()
    input_paths = [Path(__file__), Path(frozen.__file__), Path(__import__('coverage_column_demand_r2').__file__),
                   Path(__import__('coverage_declarations').__file__), DESIGN, OBSERVED, SORT,
                   frozen.H / 'query_surface' / 'specification.py']
    result = dict(status='source_declared_candidate_pools_not_runtime_activation', query_executions=0,
        declaration_count=10000, union_count=len(all_matches), disjoint_buckets={k: v for k,v in sorted(masks.items())},
        intersection_sort_demand_ids=sorted(set(all_matches) & sort_ids),
        intersection_count=len(set(all_matches) & sort_ids),
        candidate_ids=sorted(all_matches), candidates=[all_matches[k] for k in sorted(all_matches)],
        source_identities={str(p): identity(p) for p in sorted(set(input_paths))},
        runtime_import_assertion=dict(native_loaded=any(n == 'shardloom._native' or n.startswith('shardloom._native.') for n in sys.modules),
            polars_runtime_loaded=any(n == '_polars_runtime' or n.startswith('_polars_runtime.') for n in sys.modules),
            asserted_absent=True),
        selection='Declaration structure only; no timing-based selection and no query execution.',
        interpretation='Candidate/control pools establish source-declared opportunity only. They do not prove runtime activation, source admission, correctness, or performance.')
    assert not result['runtime_import_assertion']['native_loaded'] and not result['runtime_import_assertion']['polars_runtime_loaded']
    result_path.write_text(json.dumps(result, indent=2) + '\n')
    lines = ['# Cardinality declaration candidate pools', '',
        f"- Frozen declarations enumerated: {len(design['cases'])}",
        f"- Union candidate count: {len(all_matches)}", f"- Sort cohort intersection: {result['intersection_count']}",
        '- Query executions: 0', '- Runtime imports: native and Polars runtime absent.', '',
        '## Disjoint declaration-shape buckets', '']
    lines += [f'- `{key}`: {len(ids)}' for key, ids in sorted(masks.items())]
    lines += ['', 'These are source-declared candidate/control pools only. Membership does not establish runtime activation or performance. See `cardinality-pools.json` for exact identities, descriptors, node paths, function arguments, source-field demand, observation counts, and input hashes.', '']
    markdown_path.write_text('\n'.join(lines))
    print(json.dumps(dict(status=result['status'], declarations=10000, union=len(all_matches),
        disjoint_buckets={k:len(v) for k,v in sorted(masks.items())}, sort_intersection=result['intersection_count'],
        output=str(result_path))))


if __name__ == '__main__':
    main()
