"""Run complete shared-runtime checks sequentially with unchanged supervision."""
import json
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
assert json.loads((OUT/'cardinality-native-clippy-r4.json').read_bytes())['status']=='passed'
CHECKS = [
    ('cardinality-fmt-r1',2400,['cargo','fmt','--all','--','--check']),
    ('cardinality-default-clippy-r1',2400,
     ['cargo','clippy','--offline','--locked','--workspace','--all-targets','--','-D','warnings']),
    ('cardinality-default-tests-r1',7200,
     ['cargo','test','--offline','--locked','--workspace','--all-targets']),
    ('cardinality-native-tests-r1',7200,
     ['cargo','test','--offline','--locked','--workspace','--all-targets',
      '--features','python-native,native-encoded-exchange-experiment']),
]
for name,timeout,command in CHECKS:
    print(name,flush=True)
    subprocess.run([sys.executable,'-B',str(OUT/'guard_checks.py'),'--name',name,
                    '--timeout',str(timeout),'--',*command],check=True)
