"""Inspect every saved candidate/control work and resource change, without queries."""
from collections import Counter, defaultdict
import base64
import gzip
import hashlib
import json
import math
from pathlib import Path
import re
import sqlite3
import sys
import zlib

OUT=Path(__file__).resolve().parent


def identity(path):
    with path.open('rb') as stream:
        return dict(bytes=path.stat().st_size,sha256=hashlib.file_digest(stream,'sha256').hexdigest())


def observation(blob):
    packet=json.loads(zlib.decompress(blob))
    file=packet['files']['one.stdout.json']
    raw=file['utf8'].encode() if 'utf8' in file else base64.b64decode(file['base64'],validate=True)
    assert len(raw)==file['bytes'] and hashlib.sha256(raw).hexdigest()==file['sha256']
    return json.loads(raw)['observation'],file['sha256']


def counters(fields):
    pairs=re.findall(r'(?:^|[ ;])([a-z][a-z0-9_]*)=([0-9]+)(?=$|[ ;])',
        fields['local_primitive_native_io_pushdown_proof_basis'])
    assert len(pairs)==len(dict(pairs))
    result={'proof.'+key:int(value) for key,value in pairs}
    for key,value in fields.items():
        if re.fullmatch(r'[0-9]+',str(value)):
            result['report.'+key]=int(value)
    return result


def main():
    label=sys.argv[1] if len(sys.argv)>1 else 'cardinality'
    assert label in {'sort','cardinality'}
    count=606 if label=='sort' else 213
    target=OUT/(label+'-cohort-r1')
    destination=OUT/(label+'-work-review-r1.json')
    certificates=target/'certificate-cases-r1.jsonl.gz'
    assert __debug__ and not destination.exists() and not certificates.exists()
    summary=json.loads((target/'verified-summary-r1.json').read_bytes())
    assert summary['successful_cases']==summary['attempted_cases']==count and summary['unsuccessful_cases']==0
    with gzip.open(target/'verified-cases-r1.jsonl.gz','rt') as stream:
        cases=[json.loads(line) for line in stream]
    inputs=[OUT/'full10k-r1/attempts.sqlite',target/'attempts.sqlite',
            target/'verified-summary-r1.json',target/'verified-cases-r1.jsonl.gz',
            OUT/(label+'-demand-cohort-r1.json'),Path(__file__)]
    before={str(path):identity(path) for path in inputs}
    assert before[str(target/'attempts.sqlite')]['sha256']==summary['ledger']['sha256']
    changes=Counter();groups=defaultdict(Counter);details=[];proofs=[]
    with sqlite3.connect(inputs[0].as_uri()+'?mode=ro',uri=True) as baseline, \
         sqlite3.connect(inputs[1].as_uri()+'?mode=ro',uri=True) as candidate:
        for row in cases:
            name=row['id'];group=row['comparison_group']
            seq,status,blob=candidate.execute('SELECT seq,status,packet FROM attempt WHERE id=?',(name,)).fetchone()
            old_seq,old_status,old_blob=baseline.execute('SELECT seq,status,packet FROM attempt WHERE id=?',(name,)).fetchone()
            assert status==old_status=='passed' and seq==row['seq'] and old_seq==row['original_ordinal']
            old,old_hash=observation(old_blob);now,new_hash=observation(blob)
            assert old['clocks']['engine_execution_seconds']==row['previous_engine_seconds']
            assert now['clocks']['engine_execution_seconds']==row['current']['engine_seconds']
            left,right=counters(old['fields']),counters(now['fields'])
            changed={key:[left.get(key),right.get(key)] for key in sorted(left.keys()|right.keys())
                     if left.get(key)!=right.get(key)}
            changes.update(changed.keys())
            for fields in (old['fields'],now['fields']):
                assert fields['fallback_attempted']==fields['external_engine_invoked']=='false'
                assert fields['execution_resource_observed_native_denied_reservations']=='0'
                assert fields['execution_resource_observed_spill_io_performed']=='false'
                assert fields['execution_resource_observed_spill_bytes']=='0'
            read_key='native_source_demand_data_read_bytes'
            work=row['current']['work'];previous=row['previous_work']
            reads=None
            if read_key in work and read_key in previous:
                old_read,new_read=int(previous[read_key]),int(work[read_key])
                direction='decreased' if new_read<old_read else 'increased' if new_read>old_read else 'unchanged'
                groups[group]['read_bytes_'+direction]+=1
                reads=dict(before=old_read,after=new_read,direction=direction)
            else:
                groups[group]['read_bytes_unavailable']+=1
            peak='execution_resource_observed_native_peak_reserved_bytes'
            reserve='execution_resource_observed_native_reserved_bytes'
            resource={key:dict(before=int(old['fields'][key]),after=int(now['fields'][key]),
                       delta=int(now['fields'][key])-int(old['fields'][key])) for key in (peak,reserve)}
            groups[group]['cases']+=1
            groups[group]['peak_reserved_increased']+=int(resource[peak]['delta']>0)
            groups[group]['retained_reserved_increased']+=int(resource[reserve]['delta']>0)
            details.append(dict(id=name,seq=seq,group=group,surface=row['surface'],native_format=row['native_format'],
                before_stdout_sha256=old_hash,after_stdout_sha256=new_hash,read_bytes=reads,
                resource=resource,counter_changes=changed))
            proofs.append(dict(seq=seq,id=name,status=status,raw_stdout_sha256=new_hash,
                engine_seconds=now['clocks']['engine_execution_seconds'],
                engine_timing_reported=now['clocks']['engine_timing_reported'],fields=now['fields']))
    assert len(details)==count
    with certificates.open('xb') as raw:
        with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as stream:
            for row in proofs:
                stream.write((json.dumps(row,separators=(',',':'),allow_nan=False)+'\n').encode())
    for name,expected in before.items():assert identity(Path(name))==expected
    result=dict(status='passed_saved_work_review',query_executions=0,source_commit=summary['source_commit'],
        cases=len(details),groups={name:dict(value) for name,value in groups.items()},
        changed_counter_occurrences=dict(changes),no_denied_reservations=True,no_spill=True,
        maximum_peak_reservation_increase=max(row['resource']['execution_resource_observed_native_peak_reserved_bytes']['delta'] for row in details),
        maximum_retained_reservation_increase=max(row['resource']['execution_resource_observed_native_reserved_bytes']['delta'] for row in details),
        details=details,source_identities=before,certificate_export=identity(certificates),
        limitation='Saved work counters have owner-specific scopes. Charged native credits do not measure process RSS; '
                   'unavailable Vortex read counts are not zero reads. One observation per runtime does not establish repeatability.')
    with destination.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps({key:result[key] for key in ('status','cases','groups','no_denied_reservations',
        'no_spill','maximum_peak_reservation_increase','maximum_retained_reservation_increase')}))


if __name__=='__main__':
    main()
