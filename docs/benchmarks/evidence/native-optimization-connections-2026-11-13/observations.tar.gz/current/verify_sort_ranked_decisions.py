"""Reconstruct existing ranked-read admission from saved declarations and footers."""
from collections import Counter
import gzip
import json
from pathlib import Path
import re
import sqlite3
import zlib

import pyarrow.parquet as parquet
import verify_sort_exposure as declared
from pipeline_runtime import identity, generation, ROOT

OUT = Path(__file__).resolve().parent


def metrics(fields):
    pairs = re.findall(r'(?:^|[ ;])([a-z][a-z0-9_]*)=([0-9]+)(?=$|[ ;])',
                       fields['local_primitive_native_io_pushdown_proof_basis'])
    assert len(pairs) == len(dict(pairs))
    return {key:int(value) for key,value in pairs}


def main():
    assert __debug__
    destination = OUT / 'sort-ranked-decision-review-r1.json'
    assert not destination.exists()
    cohort = json.loads((OUT/'sort-demand-cohort-r1.json').read_bytes())
    wanted = {row['declaration']['id']:row for row in cohort['cases'] if row['baseline_ranked_sources'] == 1}
    assert len(wanted) == 19
    with gzip.open(OUT/'full10k-r1/certificate-cases-r1.jsonl.gz','rt') as stream:
        before = {row['id']:row['fields'] for line in stream
                  if (row := json.loads(line))['id'] in wanted}
    definitions = {item.name:item for item in declared.spaces()}
    results, footers = [], {}
    with sqlite3.connect(f'file:{OUT}/sort-cohort-r1/attempts.sqlite?mode=ro',uri=True) as store:
        for name, selection in wanted.items():
            blob, = store.execute('SELECT packet FROM attempt WHERE id=?',(name,)).fetchone()
            packet = json.loads(zlib.decompress(blob))
            job = json.loads(packet['files']['one.job.json']['utf8'])
            response = json.loads(packet['files']['one.stdout.json']['utf8'])
            row = selection['declaration']
            item = declared.build(row,definitions)
            assert item.identity == row['case_identity'] and job['case'] == row
            assert row['archetype'] == 'rank_hidden_payload' and row['native_format'] == 'parquet'
            nodes = list(declared.nodes(item.relation))
            sorts = [node for node in nodes if node.op == 'sort']
            assert len(sorts) == 1
            sort = sorts[0]
            ranking = {key.column for key in sort.args}
            for node in declared.nodes(sort.inputs[0]):
                if node.op == 'filter':
                    ranking.update(node.args[0].columns())
                else:
                    assert node.op == 'scan'
            prefix = row['cell']['size'] + row['cell']['offset']
            paths = job['sources']['fact']
            assert len(paths) == 1
            path = Path(paths[0])
            if str(path) not in footers:
                before_generation = generation(path)
                with parquet.ParquetFile(path) as file:
                    metadata = file.metadata
                    names = set(file.schema_arrow.names)
                    groups = [dict(rows=metadata.row_group(index).num_rows,
                        leaves=[dict(root=metadata.row_group(index).column(col).path_in_schema.split('.')[0],
                                     bytes=metadata.row_group(index).column(col).total_compressed_size)
                                for col in range(metadata.num_columns)])
                              for index in range(metadata.num_row_groups)]
                assert generation(path) == before_generation
                footers[str(path)] = dict(generation=before_generation, names=sorted(names), groups=groups)
            footer = footers[str(path)]
            old, now = metrics(before[name]), metrics(response['observation']['fields'])
            assert len(footer['groups']) == int(selection['baseline_work']['native_source_demand_row_groups_read'])
            assert old['ranked_rank_columns'] == len(ranking)
            required = set(selection['required_scan_columns']['fact'])
            assert ranking <= required <= set(footer['names'])
            rank_bytes = sum(leaf['bytes'] for group in footer['groups'] for leaf in group['leaves']
                             if leaf['root'] in ranking)
            assert rank_bytes == old['ranked_rank_read_bytes']
            comparisons = {}
            for label, columns in [('before',set(footer['names'])),('after',required)]:
                payload = [sum(leaf['bytes'] for leaf in group['leaves'] if leaf['root'] in columns)
                           for group in footer['groups']]
                whole = sum(payload)
                worst = rank_bytes + sum(sorted(payload,reverse=True)[:prefix])
                comparisons[label] = dict(columns=sorted(columns), ordinary_read_bytes=whole,
                    ranking_read_bytes=rank_bytes, worst_case_rank_plus_payload_bytes=worst,
                    ranked_cost_admitted=worst<whole)
            assert comparisons['before']['ranked_cost_admitted'] is True
            observed_ranked = now.get('ranked_sources',0) == 1
            assert comparisons['after']['ranked_cost_admitted'] == observed_ranked
            results.append(dict(id=name, declaration_identity=item.identity, prefix=prefix,
                ranking_columns=sorted(ranking), before=comparisons['before'], after=comparisons['after'],
                observed_ranked_after=observed_ranked,
                actual_before_read_bytes=int(selection['baseline_work']['native_source_demand_data_read_bytes']),
                actual_after_read_bytes=int(response['observation']['fields']['native_source_demand_data_read_bytes'])))
    assert Counter(row['observed_ranked_after'] for row in results) == {True:11,False:8}
    for path, footer in footers.items():
        assert generation(Path(path)) == footer['generation']
    sources = [Path(__file__), OUT/'sort-demand-cohort-r1.json',
        OUT/'sort-cohort-r1/verified-summary-r1.json',
        ROOT/'shardloom-vortex/src/universal_format_io/demanded/ranked.rs',
        ROOT/'shardloom-vortex/src/local_primitive_relational_ranked.rs']
    result = dict(status='passed_metadata_reconstruction', query_executions=0,
        parquet_payload_rows_read=0, ranked_before=19, ranked_after=11, cost_declines_after=8,
        actual_read_increases=sum(row['actual_after_read_bytes']>row['actual_before_read_bytes'] for row in results),
        all_19_decisions_match_unchanged_native_cost_rule=True, cases=results, footer_facts=footers,
        source_identities={str(path):identity(path) for path in sources},
        limitation='This explains the current conservative selection rule, not optimality. Actual winning groups can make declined ranked reads cheaper; this remains an optimization-selection opportunity.')
    with destination.open('x') as stream:
        json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps({key:value for key,value in result.items() if key not in {'cases','footer_facts','source_identities'}}))


if __name__ == '__main__':
    main()
