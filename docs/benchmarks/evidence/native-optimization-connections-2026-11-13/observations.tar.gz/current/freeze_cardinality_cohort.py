"""Freeze all declared count/expansion cases and their unchanged saved baseline."""
from collections import Counter
import gzip
import hashlib
import json
import math
import re
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
I = OUT/'coverage-inventory-r1'
E = OUT.parent/'expanded-query-2026-11-03'
OLD = '9f4580c723f876f087d3e75fb56153b4b099ef20'
PREVIOUS = 'cac86e8b0a5fa5fa8bf4c900dbef7a703746bfa8'


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    return dict(path=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def main():
    destination = OUT/'cardinality-demand-cohort-r1.json'
    assert __debug__ and not destination.exists()
    proof = read(I/'cardinality-pools-primary.json')
    assert proof['status']=='passed' and proof['declaration_identities_verified']==10000
    assert proof['selected_count']==213 and proof['known_extra_column_cases']==96
    for name, expected in proof['source_identities'].items():
        actual = identity(Path(name))
        assert {key:actual[key] for key in ('bytes','sha256')} == expected
    pools = read(I/'cardinality-pools.json')
    static = {row['id']:row for row in pools['candidates']}
    assert len(static)==213
    sort = read(OUT/'sort-demand-cohort-r1.json')
    ancestors = read(OUT/'sort-ancestor-adversarial-r2.json')
    assert ancestors['status']=='passed_static_inventory'
    assert ancestors['declarations_verified']==10000
    assert ancestors['all_downstream_demand_shapes_in_frozen_cohort'] is True
    assert not set(static) & {row['declaration']['id'] for row in sort['cases']}
    changed = subprocess.check_output(['git','diff','--name-only',OLD,PREVIOUS],cwd=ROOT,text=True).splitlines()
    production = [path for path in changed if path.endswith('.rs') and not path.endswith('_tests.rs')]
    assert production==['shardloom-vortex/src/local_primitive_relational_scan_bind.rs'], production
    patch = subprocess.check_output(['git','diff',OLD,PREVIOUS,'--',*production],cwd=ROOT)
    reuse = dict(saved_runtime_commit=OLD,accepted_predecessor_commit=PREVIOUS,
        changed_production_files=production,production_patch_sha256=hashlib.sha256(patch).hexdigest(),
        exact_runtime_source_equality=False,
        reason='The only intervening production change connects downstream demand through owned-source Sort. '
               'The independent all-declaration ancestor audit proves all such opportunities are in the '
               '606-case Sort cohort; none of these 213 declarations belongs to that cohort. '
               'Original observations retain their 9f source identity; they are not relabeled as cac86 executions.')
    baseline = OUT/'full10k-r1'
    summary = read(baseline/'verified-summary-r1.json')
    assert summary['successful_cases']==summary['attempted_cases']==10000 and summary['source_commit']==OLD
    case_path = baseline/'verified-cases-r1.jsonl.gz'
    assert identity(case_path)['sha256']==summary['case_rows']['sha256']
    with gzip.open(case_path,'rt') as stream:
        saved = {row['id']:row for line in stream if (row:=json.loads(line))}
    cert_path = baseline/'certificate-cases-r1.jsonl.gz'
    cert_binding = read(baseline/'certificate-export-r1.json')
    assert identity(cert_path)['sha256']==cert_binding['output']['sha256']
    with gzip.open(cert_path,'rt') as stream:
        certs = {row['id']:row for line in stream if (row:=json.loads(line))}
    design = read(E/'design.json')
    cases,groups = [],Counter()
    for ordinal,descriptor in enumerate(design['cases']):
        if descriptor['id'] not in static:
            continue
        inferred,observed,certificate = static[descriptor['id']],saved[descriptor['id']],certs[descriptor['id']]
        assert inferred['descriptor']==descriptor and inferred['case_identity']==descriptor['case_identity']
        assert observed['seq']==certificate['seq']==ordinal
        assert observed['current']['status']==certificate['status']=='passed'
        seconds = observed['current']['engine_seconds']
        assert math.isfinite(seconds) and seconds>=0
        work = observed['current']['work']
        metadata_counts = re.findall(r'\bmetadata_count_sources=(\d+)\b',
            certificate['fields']['local_primitive_native_io_pushdown_proof_basis'])
        assert len(metadata_counts)<=1
        metadata_sources = int(metadata_counts[0]) if metadata_counts else 0
        reported = work.get('native_source_demand_projected_columns')
        before = int(reported) if reported is not None else None
        required = sum(map(len,inferred['source_fields_required_by_existing_demand'].values()))
        if descriptor['native_format']=='vortex':
            group,required = 'native_vortex_control',None
        elif metadata_sources:
            group,required = 'metadata_count_control',0
            assert before==0
        else:
            assert before is not None
            assert before>=required
            group = 'new_column_reduction' if before>required else 'already_narrowed'
        groups[group]+=1
        cases.append(dict(original_ordinal=ordinal,declaration=descriptor,
            comparison_group=group,baseline_engine_seconds=seconds,
            baseline_projected_columns=before,required_projected_columns=required,
            required_scan_columns=inferred['source_fields_required_by_existing_demand'],
            baseline_work=work,declaration_matches=inferred['declaration_matches']))
    assert len(cases)==213 and groups==dict(new_column_reduction=96,already_narrowed=38,
                                         metadata_count_control=1,native_vortex_control=78),groups
    paths = [Path(__file__), OUT/'cardinality-demand-design-r1.md',OUT/'cardinality-demand-design-r2.md',
        I/'cardinality-pools-primary.json',I/'cardinality-pools.json',I/'column-demand-candidates-r2.json',
        E/'design.json',OUT/'sort-demand-cohort-r1.json',OUT/'sort-ancestor-adversarial-r2.json',
        OUT/'sort-validation-r1.json',OUT/'sort-runtime-r1-identity.json',
        baseline/'verified-summary-r1.json',case_path,cert_path,baseline/'certificate-export-r1.json',
        OUT/'runtime-r1-identity.json',OUT/'validation-before-10k.json',
        OUT/'full10k-protocol-r1.json',OUT/'full10k-supervision-r1.json']
    record = dict(status='frozen_before_candidate_execution',query_executions=0,
        schema='shardloom.cardinality_source_demand_cohort.v1',case_count=213,
        selection='All 196 original explode declarations and all 17 scalar argument-free count declarations, across all five interfaces and all three formats; no timing selection.',
        attempts_per_case=1,warmups=0,repeats=0,primary_clock='engine_execution_seconds',
        baseline_engine_seconds=math.fsum(row['baseline_engine_seconds'] for row in cases),
        baseline_source_commit=OLD,baseline_queries_to_repeat=0,baseline_reuse= reuse,
        groups=dict(groups),source_identities=[identity(path) for path in paths],cases=cases)
    with destination.open('x') as stream:
        json.dump(record,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({key:record[key] for key in ('status','case_count','groups','baseline_engine_seconds')}))


if __name__=='__main__':
    main()
