# Cardinality and declared unary input demand — final candidate scope

This extends design-r1 after focused regression review, before any candidate
performance execution. Preserve r1 and every original failed check.

An owned scan's value-free consumer may use an already validated hidden predicate
column as its row carrier, including when the original scan output omitted that
field. It still reads the predicate and consumes real rows. Required COUNT(value)
columns, native/caller-owned validation scope and upstream computed errors remain.

All already-bound unary requests may propagate their explicitly required input
columns (keys, values, weights and predicates) to an owned child. This is separate
from consumer-driven removal of unary outputs: only ExplodeRows admits the latter,
and all its lists remain. Population-changing operators do not receive prefix
demand, and full-record distinct semantics are unchanged.

Narrowing exposed a composed-unary binder omission: it treated every attached
predicate as residual but retained only file-scan residual input fields. Bind all
original predicate fields for composed operations, preserving output projection
and predicate position. A distinct request with a hidden predicate and corrupt
unused payload is an additional regression control for this shared correction.

The 11 new native regressions pass, and the complete 120-test source-demand group
passes. Full workspace/native lint/tests and installed-artifact checks remain
required. The prospective frozen-corpus pool has 213 declarations: all 196 list
expansions and all 17 scalar argument-free counts. No column-free projection
exists in the original 10k; new constant/native tests supply that omitted axis.
The pool includes all five public routes, all three native input formats, 96
previous extra-column observations and 117 controls, with no intersection with
the prior 606 Sort cohort. These are declaration facts, not observed candidate
activation or a performance result. Independent primary verification and a frozen
protocol are required before execution.
