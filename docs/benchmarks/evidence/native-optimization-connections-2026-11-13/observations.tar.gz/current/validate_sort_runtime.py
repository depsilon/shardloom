"""Check complete suites and installed artifacts against the exact Sort release source."""
import json
from pathlib import Path
import re

from sort_runtime import CHECKS, MANIFEST, OUT, VALIDATION, fingerprint, identity, read, sources, verify

assert __debug__ and not VALIDATION.exists()
manifest = read(MANIFEST)
build = read(OUT / manifest['build_receipt'])
assert manifest['status'] == build['status'] == 'passed'
assert build['source_files'] == sources()
assert fingerprint(build['source_files']) == manifest['source_fingerprint_sha256']
checks = {}
for name in sorted(CHECKS):
    path = OUT / name
    check = read(path)
    assert check['status'] == 'passed' and check['returncode'] == 0, name
    assert check['sources_unchanged'] and check['process_group_drained'] and check['direct_child_reaped'], name
    assert check['source_files'] == build['source_files'], name
    checks[name] = identity(path)
counts = {}
for name in ('sort-default-tests-r1', 'sort-native-tests-r1'):
    text = (OUT / 'logs' / (name + '.log')).read_text()
    rows = [tuple(map(int, row)) for row in re.findall(
        r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored', text)]
    total = tuple(sum(row[i] for row in rows) for i in range(3))
    assert total[1] == 0
    if name == 'sort-default-tests-r1':
        assert total == (3325, 0, 0), total
    else:
        assert 'running 4191 tests' in text
        assert (4155, 0, 36) in rows, 'full native library inventory differs'
        assert '109 passed; 0 failed' not in text, 'focused group is not the complete suite'
        assert 'source_demand_tests::sort_tests::parquet_demand_sort_keeps_hidden_keys_and_skips_unused_corrupt_payload ... ok' in text
        assert 'source_demand_tests::sort_tests::parquet_demand_sort_rebinds_raw_vector_field_observation_after_pruning ... ok' in text
        assert total == (7128, 0, 39) and len(rows) == 120, total
    counts[name] = dict(passed=total[0], failed=total[1], ignored=total[2], test_binaries=len(rows))
installed = read(OUT / 'sort-installed-wheel-r1/report.json')
integration = read(OUT / 'sort-installed-wheel-r1/integration.json')
assert installed['status'] == integration['status'] == 'passed'
assert integration == dict(tests=442, failures=0, errors=0, skipped=0, status='passed')
assert installed['integrity']['native_library_sha256'] == identity(OUT/'sort-runtime-r1/_native.abi3.so')['sha256']
assert installed['integrity']['cli_sha256'] == identity(OUT/'sort-runtime-r1/shardloom')['sha256']
assert not installed['publication_attempted']
record = dict(status='passed', source_commit=manifest['source_commit'],
    source_tree=manifest['source_tree'], runtime=identity(MANIFEST), checks=checks,
    installed_checks={name:identity(OUT/name) for name in (
        'sort-installed-wheel-r1/report.json', 'sort-installed-wheel-r1/integration.json')},
    native_validation_scope='full_workspace_all_targets_default_and_native',
    full_native_library_suite_completed=True, test_counts=counts,
    installed_python_tests=integration, benchmark_executions=0)
with VALIDATION.open('x') as output:
    json.dump(record, output, indent=2); output.write('\n')
proof = verify()
print(json.dumps(dict(status='passed', source_commit=proof['head'], test_counts=counts)))
