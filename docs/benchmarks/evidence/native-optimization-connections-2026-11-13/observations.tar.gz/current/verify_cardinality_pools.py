"""Independently check declaration membership; no reference or native execution."""
from collections import Counter, defaultdict
import json
from pathlib import Path
import sys

import verify_sort_exposure as frozen
from coverage_column_demand_r2 import demand
from coverage_declarations import identity

OUT = Path(__file__).resolve().parent
I = OUT / 'coverage-inventory-r1'
target = I / 'cardinality-pools-primary.json'
assert __debug__ and not target.exists()
pool = json.loads((I/'cardinality-pools.json').read_bytes())
design = json.loads((frozen.E/'design.json').read_bytes())
for name, expected in pool['source_identities'].items():
    assert identity(Path(name)) == expected, name
records = {row['id']: row for row in pool['candidates']}
assert len(records) == len(pool['candidates']) == pool['union_count'] == 213
legacy = {case.id:case for case in frozen.corpus(interactions='all', include_pending=False)}
spaces = {space.name:space for space in frozen.spaces()}
selected = set()
groups, surfaces, formats, functions = Counter(), Counter(), Counter(), Counter()
for ordinal, descriptor in enumerate(design['cases']):
    case = frozen.build(descriptor,spaces) if 'cell' in descriptor else legacy[descriptor['id']]
    assert case.id == descriptor['id'] and case.identity == descriptor['case_identity']
    stack = [((),case.relation)]
    matches = set()
    while stack:
        path,node = stack.pop()
        if node.op == 'explode_case':
            matches.add(('explode_case',path))
        elif node.op == 'aggregate':
            keys,measures = node.args
            if len(keys) == 0 and not any(m.argument is not None for m in measures):
                matches.add(('scalar_aggregate_no_arguments',path))
                functions.update(m.function for m in measures)
        elif node.op == 'project' and not any(expr.columns() for _,expr in node.args):
            matches.add(('constant_or_column_free_project',path))
        stack.extend((path+(index,),child) for index,child in enumerate(node.inputs))
    assert bool(matches) == (case.id in records), case.id
    if not matches:
        continue
    record = records[case.id]
    assert record['case_identity'] == case.identity and record['descriptor'] == descriptor
    assert matches == {(x['kind'],tuple(x['path'])) for x in record['declaration_matches']}
    required = defaultdict(set)
    demand(case.relation, {name for name,_ in case.relation.schema}, required)
    assert {key:sorted(value) for key,value in required.items()} == record['source_fields_required_by_existing_demand']
    selected.add(case.id)
    groups.update({kind for kind,_ in matches})
    surfaces[descriptor['surface']] += 1
    formats[descriptor['native_format']] += 1
assert len(design['cases']) == 10000 and selected == set(records) == set(pool['candidate_ids'])
sort = json.loads((OUT/'sort-demand-cohort-r1.json').read_bytes())
assert not selected & {x['declaration']['id'] for x in sort['cases']}
screen = json.loads((I/'column-demand-candidates-r2.json').read_bytes())
missed = [row for row in screen['candidates'] if row['id'] in selected]
assert len(missed) == 96
assert groups == {'explode_case':196, 'scalar_aggregate_no_arguments':17}
assert functions == {'count':17}, functions
assert not any(name == 'shardloom._native' or name.startswith('_polars_runtime') for name in sys.modules)
loaded = {Path(module.__file__).resolve() for module in sys.modules.values()
          if getattr(module,'__file__',None) and str(frozen.H/'query_surface') in str(module.__file__)}
paths = {Path(__file__), I/'cardinality-pools.json', frozen.E/'design.json',
         OUT/'sort-demand-cohort-r1.json', I/'column-demand-candidates-r2.json',
         Path(frozen.__file__), OUT/'coverage_column_demand_r2.py', *loaded}
record = dict(status='passed', declaration_identities_verified=10000,
    selected_count=213, known_extra_column_cases=96, remaining_controls=117,
    groups=groups, surfaces=surfaces, formats=formats, scalar_functions=functions,
    sort_intersection=0, query_executions=0,
    source_identities={str(path):identity(path) for path in sorted(paths)},
    scope='Literal structure and dependency verification only; no runtime activation claim.')
with target.open('x') as stream:
    json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps({key:value for key,value in record.items() if key!='source_identities'}))
