"""Run the remaining shared-source checks sequentially under the established guard."""
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
CHECKS = [
    ('sort-fmt-r2', 2400, ['cargo', 'fmt', '--all', '--', '--check']),
    ('sort-default-clippy-r1', 2400,
     ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('sort-default-tests-r1', 7200,
     ['cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets']),
    ('sort-native-tests-r1', 7200,
     ['cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets',
      '--features', 'python-native,native-encoded-exchange-experiment']),
]
for name, timeout, command in CHECKS:
    print(name, flush=True)
    subprocess.run([sys.executable, '-B', str(OUT / 'guard_checks.py'), '--name', name,
                    '--timeout', str(timeout), '--', *command], check=True)
