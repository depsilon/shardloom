"""Export complete saved baseline certificates for the two disjoint fixed cohorts."""
import gzip
import json
from pathlib import Path
import sqlite3

from review_connection_work import OUT, identity, observation


def main():
    assert __debug__
    destination=OUT/'baseline-connection-certificates-r1.jsonl.gz'
    receipt=OUT/'baseline-connection-certificates-r1.json'
    assert not destination.exists() and not receipt.exists()
    baseline=OUT/'full10k-r1'
    summary=json.loads((baseline/'verified-summary-r1.json').read_bytes())
    ledger=baseline/'attempts.sqlite'
    initial=identity(ledger)
    assert initial['sha256']==summary['ledger']['sha256']
    declared={}
    for label in ('sort','cardinality'):
        cohort=json.loads((OUT/(label+'-demand-cohort-r1.json')).read_bytes())
        for row in cohort['cases']:
            name=row['declaration']['id']
            assert name not in declared
            declared[name]=row
    assert len(declared)==819
    certificates=[]
    with sqlite3.connect(ledger.as_uri()+'?mode=ro',uri=True) as db:
        for name,row in sorted(declared.items(),key=lambda item:item[1]['original_ordinal']):
            seq,status,blob=db.execute('SELECT seq,status,packet FROM attempt WHERE id=?',(name,)).fetchone()
            assert seq==row['original_ordinal'] and status=='passed'
            saved,raw_hash=observation(blob)
            assert saved['clocks']['engine_execution_seconds']==row['baseline_engine_seconds']
            certificates.append(dict(seq=seq,id=name,status=status,raw_stdout_sha256=raw_hash,
                engine_seconds=saved['clocks']['engine_execution_seconds'],
                engine_timing_reported=saved['clocks']['engine_timing_reported'],fields=saved['fields']))
    with destination.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
            for row in certificates:
                compressed.write((json.dumps(row,separators=(',',':'),allow_nan=False)+'\n').encode())
    assert identity(ledger)==initial
    record=dict(status='passed',query_executions=0,cases=819,source_commit=summary['source_commit'],
        ledger=initial,output=identity(destination),helper=identity(Path(__file__)),
        scope='Complete saved certificate fields for the exact disjoint 606/213 cohort union; no query execution.')
    with receipt.open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
    print(json.dumps(dict(status='passed',cases=819,query_executions=0)))


if __name__=='__main__':main()
