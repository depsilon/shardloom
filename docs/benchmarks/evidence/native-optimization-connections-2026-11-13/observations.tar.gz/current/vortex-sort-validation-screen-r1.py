"""Compare two bounded public Vortex sort forms on a required payload error."""
import gc
import hashlib
import json
import os
from pathlib import Path
import sys

ROOT=Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
OUT=Path(__file__).resolve().parent
TARGET=OUT/'vortex-sort-validation-screen-r1'
RUNTIME=OUT/'cardinality-runtime-r1/_native.abi3.so'
sys.path[:0]=[str(ROOT/'python/src'),str(ROOT/'python/tests')]
os.environ['SHARDLOOM_NATIVE_TEST_LIBRARY']=str(RUNTIME)
os.environ['SHARDLOOM_REQUIRE_NATIVE_PYTHON']='1'
from test_native_binding import _load_native


def identity(path):
    return dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def main():
    assert __debug__ and not TARGET.exists()
    native=_load_native()
    import pyarrow as pa
    manifest=json.loads((OUT/'cardinality-runtime-r1-identity.json').read_bytes())
    assert identity(RUNTIME)==manifest['files'][str(RUNTIME)]
    TARGET.mkdir()
    path=TARGET/'two-rows.vortex'
    schema=pa.schema([pa.field('rank',pa.int64(),nullable=False),
                      pa.field('payload',pa.float64(),nullable=False)])
    values=pa.Table.from_arrays([pa.array([0,1],pa.int64()),pa.array([1.0,float('nan')])],schema=schema)
    writer=native.Session(native.ExecutionResources(32<<20,1),float_policy='extended')
    source=writer.from_arrow(values)
    write_plan=writer.plan(native.Relation.scan('memory://validation-screen'),
                           sources=[('memory://validation-screen',source)])
    write_plan.write(path,'write_vortex')
    del write_plan,source
    writer.close()
    initial=identity(path)
    E=native.Expression
    results=[]
    for computed in [False,True]:
        session=native.Session(native.ExecutionResources(32<<20,1),float_policy='strict')
        relation=native.Relation.scan(str(path))
        if computed:
            relation=relation.project([('rank',E.column('rank')+E.literal(0)),
                                       ('payload',E.column('payload'))])
        relation=relation.sort([('rank',False,None)]).limit(1).project([('rank',E.column('rank'))])
        prepared=session.plan(relation)
        record=dict(form='computed_identity' if computed else 'direct',rows=None,error=None)
        try:
            result=prepared.collect()
            record['report']=result.report
            record['rows']=pa.RecordBatchReader.from_stream(result).read_all().to_pylist()
            del result
        except RuntimeError as error:
            record['error']=str(error)
        del prepared,relation
        gc.collect()
        session.close()
        record['closed_session_snapshot']=session.snapshot()
        results.append(record)
    assert identity(path)==initial
    same=(results[0]['rows'] is None)==(results[1]['rows'] is None)
    record=dict(status='observed_same_outcome' if same else 'observed_validation_disagreement',
        purpose='bounded correctness diagnostic, not a performance observation',query_executions=2,
        native_fixture_writes=1,source_commit=manifest['source_commit'],runtime=identity(RUNTIME),
        input=initial,helper=identity(Path(__file__)),observations=results)
    with (TARGET/'result.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
    print(json.dumps(dict(status=record['status'],observations=[{k:r[k] for k in ('form','rows','error')} for r in results])))


if __name__=='__main__':main()
