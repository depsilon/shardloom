"""Replay all saved count/expansion results and work without executing any query."""
from collections import Counter, defaultdict
from contextlib import ExitStack
import gzip
import json
import math
from pathlib import Path
import re

import run_cardinality_cohort as current
import cardinality_runtime
from query_timing_report import query_phase_timings
from query_surface.corpus import corpus
from query_surface.evidence import identity
from query_surface.expanded_catalog import build, spaces
from query_surface.expanded_freeze import read, unpack
from query_surface.expanded_report import raw_files, replay
from query_surface.expanded_run import closing_db, verify


def main():
    assert __debug__
    target = current.TARGET
    destination = target/'verified-summary-r1.json'
    cases_path = target/'verified-cases-r1.jsonl.gz'
    partial = target/'verified-cases-r1.partial.jsonl.gz'
    assert not any(path.exists() for path in (destination, cases_path, partial))
    design, inputs, frozen, admitted = current.updated_admission(current.E)
    selection, descriptors = current.cohort(design)
    selected = {row['declaration']['id']:row for row in selection['cases']}
    done, binding = read(target/'complete.json'), read(target/'binding.json')
    assert done['status'] == 'complete_observation' and done['stage'] == 'native'
    assert done['total'] == done['attempt_slots'] == 213
    assert done['attempts_per_case'] == 1 and done['requested_repeats'] == 0 and done['posthash_verified']
    assert done['updated'] == admitted
    assert binding['contract'] == {key:done[key] for key in ('frozen','stage','prerequisites','updated')}
    verify([done['ledger'], done['binding'], done['frozen']])
    prepared = read(current.E/'native-preparation/complete.json')
    originals = {item.id:item for item in corpus(interactions='all', include_pending=False)}
    definitions = {spec.name:spec for spec in spaces()}
    seen, engine, old_engine, failures = [], [], [], []
    outcomes, groups, work_counts = Counter(), defaultdict(list), Counter()
    with (target/'.cardinality-offline-replay.lock').open('x'):
        pass
    with ExitStack() as stack:
        store = stack.enter_context(closing_db(target/'attempts.sqlite', readonly=True))
        entries = iter(store.execute('SELECT seq,id,status,packet FROM attempt ORDER BY seq'))
        references = {profile:stack.enter_context(closing_db(
            current.E/('reference-'+profile)/'expectations.sqlite', readonly=True))
            for profile in {row['profile'] for row in descriptors}}
        output = stack.enter_context(gzip.open(partial,'wt',encoding='utf-8'))
        for ordinal, row in enumerate(descriptors):
            item = build(row,definitions) if 'cell' in row else originals[row['id']]
            expected_identity, expected_blob = references[row['profile']].execute(
                'SELECT identity,value FROM expected WHERE id=?',(item.id,)).fetchone()
            assert expected_identity == item.identity == row['case_identity']
            entry = next(entries,None)
            assert entry is not None and entry[:2] == (ordinal,item.id)
            record = replay(entry,row,'native',unpack(expected_blob),item,inputs,prepared,design['execution'])
            before = selected[item.id]
            outcomes[record['status']] += 1
            seen.append(item.id)
            old_engine.append(before['baseline_engine_seconds'])
            work, pipeline = {}, {}
            if record['status'] == 'passed':
                response = json.loads(raw_files(unpack(entry[3]))['one.stdout.json'])
                observation = response['observation']
                clocks = query_phase_timings(observation['fields'], observation['clocks']['complete_workflow_seconds'])
                seconds = clocks['engine_execution_seconds']
                assert type(seconds) in (int,float) and math.isfinite(seconds) and seconds >= 0
                assert seconds == record['engine_seconds'] == observation['clocks']['engine_execution_seconds']
                assert observation['clocks']['engine_timing_reported'] is True
                assert clocks['result_serialization_seconds'] == observation['clocks']['result_serialization_seconds']
                fields = observation['fields']
                assert fields['relational_provider_selection_reason'] == 'native_operator_pipeline'
                proof = fields['local_primitive_native_io_pushdown_proof_basis']
                assert 'native_execution_pipeline=native_operator_pipeline' in proof
                assert 'native_pipeline_catch_all_execution=false' in proof
                assert fields['fallback_attempted'] == fields['external_engine_invoked'] == 'false'
                counters = {}
                for key in ('native_pipeline_operator_invocations', 'native_pipeline_file_kernel_invocations'):
                    values = re.findall(r'\b'+re.escape(key)+r'=(\d+)\b',proof)
                    assert len(values) == 1
                    counters[key] = int(values[0])
                assert 0 <= counters['native_pipeline_file_kernel_invocations'] <= counters['native_pipeline_operator_invocations']
                assert counters['native_pipeline_operator_invocations'] > 0
                if before['required_projected_columns'] is not None:
                    assert fields['native_source_demand_prepared_input_bytes_written'] == '0'
                pipeline = dict(common_pipeline=True, catch_all=False, external_fallback=False, **counters)
                work_counts['common_native_pipeline_cases'] += 1
                engine.append(seconds)
                reported = record['work'].get('native_source_demand_projected_columns')
                actual = int(reported) if reported is not None else None
                prior = before['baseline_projected_columns']
                expected = before['required_projected_columns']
                comparable = expected is not None
                if comparable:
                    assert actual is not None and prior is not None
                    work = dict(before_columns=prior, after_columns=actual,
                        required_columns=expected, matches_dependency_demand=actual==expected,
                        narrowed=actual<prior, expanded=actual>prior,
                        scope='owned_demanded_source_columns')
                    work_counts['matches_required_columns'] += int(actual==expected)
                    work_counts['narrowed_columns'] += int(actual<prior)
                    work_counts['expanded_columns'] += int(actual>prior)
                    work_counts[before['comparison_group']+'_matching_columns'] += int(actual==expected)
                else:
                    assert row['native_format']=='vortex'
                    work = dict(before_columns=prior, after_columns=actual,
                        required_columns=None, matches_dependency_demand=None,
                        scope='native_vortex_no_comparable_per_source_column_counter')
                    work_counts['native_vortex_controls_completed'] += 1
                groups[before['comparison_group']].append(dict(id=item.id,
                    before_engine_seconds=before['baseline_engine_seconds'], after_engine_seconds=seconds,
                    before_columns=prior, after_columns=actual))
            else:
                failures.append(dict(id=item.id, status=record['status'], detail=record.get('failure_detail')))
            output.write(json.dumps(dict(seq=ordinal,id=item.id,case_identity=item.identity,
                original_ordinal=before['original_ordinal'], family=row['family'],profile=row['profile'],
                surface=row['surface'], native_format=row['native_format'],
                comparison_group=before['comparison_group'],current=record,
                previous_engine_seconds=before['baseline_engine_seconds'],
                previous_work=before['baseline_work'], demand_comparison=work,
                pipeline_evidence=pipeline),
                separators=(',',':'),allow_nan=False)+'\n')
        assert next(entries,None) is None
    assert seen == [row['id'] for row in descriptors] and len(set(seen)) == 213
    assert dict(outcomes) == done['outcomes']
    assert math.fsum(old_engine) == selection['baseline_engine_seconds']
    verify(frozen)
    assert identity(target/'attempts.sqlite') == done['ledger']
    partial.rename(cases_path)
    total = math.fsum(engine) if not failures else None
    result = dict(status='passed_offline_replay', query_executions=0,
        source_commit=admitted['head'], source_tree=admitted['source_tree'],
        attempted_cases=213,successful_cases=len(engine),unsuccessful_cases=len(failures),outcomes=dict(outcomes),
        primary_clock='engine_execution_seconds', baseline_engine_seconds=math.fsum(old_engine),
        successful_engine_seconds=math.fsum(engine), complete_cohort_engine_seconds=total,
        lower_complete_cohort_engine_time=total is not None and total<math.fsum(old_engine),
        work_counts=dict(work_counts), required_column_demand_matched=work_counts['matches_required_columns']==135,
        comparable_source_column_cases=135, native_vortex_column_coverage='unproved_by_this_counter',
        newly_narrowed_cases=work_counts['narrowed_columns'], groups={name:dict(cases=len(rows),
            baseline_engine_seconds=math.fsum(row['before_engine_seconds'] for row in rows),
            candidate_engine_seconds=math.fsum(row['after_engine_seconds'] for row in rows),
            cases_with_higher_engine_time=sum(row['after_engine_seconds']>row['before_engine_seconds'] for row in rows))
            for name,rows in groups.items()},
        failures=failures, attempts_per_case=1, repeated_baseline_queries=0,
        independent_complete_results_replayed=True,
        case_rows=identity(cases_path), ledger=identity(target/'attempts.sqlite'),
        protocol=identity(current.PROTOCOL), cohort=identity(current.COHORT), verifier=identity(Path(__file__)),
        limitation='One observation per runtime; inspect complete results, per-case work and resource/control regressions before retention. No repeatability or whole-engine coverage claim.')
    with destination.open('x') as stream:
        json.dump(result,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({key:result[key] for key in ('status','successful_cases','unsuccessful_cases',
        'baseline_engine_seconds','complete_cohort_engine_seconds','work_counts','groups')}),flush=True)


if __name__ == '__main__':
    main()

