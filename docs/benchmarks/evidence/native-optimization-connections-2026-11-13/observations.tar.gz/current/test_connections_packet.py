"""Relocate the compact packet and challenge its semantic and byte-integrity checks."""
import copy
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile

OUT = Path(__file__).resolve().parent
PACKET = OUT/'compact-connections-r3'
DESTINATION = OUT/'connections-corruption-controls-r3.json'


def identity(raw):
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def encoded(value):
    return (json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode()


def main():
    if not __debug__:
        raise RuntimeError('corruption controls require Python assertions')
    assert __debug__ and not DESTINATION.exists()
    original = {path.name:path.read_bytes() for path in PACKET.iterdir() if path.is_file()}
    manifest = json.loads(original['manifest.json'])
    with tarfile.open(fileobj=io.BytesIO(original['observations.tar.gz']),mode='r:gz') as archive:
        members = {item.name:archive.extractfile(item).read() for item in archive.getmembers()}
    spec = importlib.util.spec_from_file_location('connection_verifier',PACKET/'verify.py')
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    observations = []
    with tempfile.TemporaryDirectory(prefix='connections-relocated-',dir=OUT) as temp:
        root = Path(temp)
        for name,raw in original.items():
            (root/name).write_bytes(raw)
        relocated = verifier.verify(root)
        assert relocated['status']=='passed' and relocated['query_executions']==0
        optimized = subprocess.run([sys.executable,'-B','-O',str(root/'verify.py')],
            cwd=root,capture_output=True,text=True,timeout=30)
        assert optimized.returncode != 0 and 'do not use -O' in optimized.stderr
        observations.append(dict(control='optimized_python_disables_assertions',
                                 status='rejected',exception='RuntimeError'))

        def trial(label, mutate, byte_mode=None):
            changed = dict(members)
            current = copy.deepcopy(manifest)

            def json_change(name,transform):
                value=json.loads(changed[name]);transform(value);changed[name]=encoded(value)

            def row_change(name,transform,links):
                rows=[json.loads(line) for line in gzip.decompress(changed[name]).splitlines()]
                transform(rows)
                changed[name]=gzip.compress(b''.join(encoded(row) for row in rows),mtime=0)
                for target,key in links:
                    value=json.loads(changed[target])
                    value[key].update(identity(changed[name]))
                    changed[target]=encoded(value)

            mutate(json_change,row_change,changed)
            if byte_mode is None:
                raw=io.BytesIO()
                with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as zipped:
                    with tarfile.open(fileobj=zipped,mode='w') as archive:
                        for name,payload in sorted(changed.items()):
                            entry=tarfile.TarInfo(name);entry.size=len(payload);entry.mode=0o644
                            archive.addfile(entry,io.BytesIO(payload))
                packed=raw.getvalue()
                current['files']['observations.tar.gz']=identity(packed)
                current['archive_members']={name:dict(**identity(payload),origin='negative control')
                                            for name,payload in changed.items()}
                (root/'observations.tar.gz').write_bytes(packed)
                (root/'manifest.json').write_bytes(encoded(current))
            else:
                for name,raw in original.items():
                    (root/name).write_bytes(raw)
                if byte_mode=='archive':
                    raw=bytearray(original['observations.tar.gz']);raw[len(raw)//2]^=1
                    (root/'observations.tar.gz').write_bytes(raw)
                elif byte_mode=='extra':
                    (root/'unlisted.txt').write_text('not in manifest')
                elif byte_mode=='missing':
                    (root/'README.md').unlink()
                else:
                    raise AssertionError(byte_mode)
            caught=None
            try:
                verifier.verify(root)
            except (AssertionError,KeyError,ValueError,TypeError,OSError,tarfile.TarError) as error:
                caught=type(error).__name__
            finally:
                if (root/'unlisted.txt').exists():
                    (root/'unlisted.txt').unlink()
                for name,raw in original.items():
                    (root/name).write_bytes(raw)
            assert caught is not None, 'corruption accepted: '+label
            observations.append(dict(control=label,status='rejected',exception=caught))

        noop=lambda _j,_r,_m:None
        for name in ('archive','extra','missing'):
            trial('byte_integrity_'+name,noop,name)
        cohort='current/cardinality-cohort-r1/'
        rows=cohort+'verified-cases-r1.jsonl.gz'
        summary=cohort+'verified-summary-r1.json'
        certs=cohort+'certificate-cases-r1.jsonl.gz'
        review='current/cardinality-work-review-r1.json'
        row_links=[(summary,'case_rows')]
        cert_links=[(review,'certificate_export')]
        trial('negative_engine_clock',lambda _j,r,_m:r(rows,
            lambda a:a[0]['current'].__setitem__('engine_seconds',-1),row_links))
        trial('changed_declaration_identity',lambda _j,r,_m:r(rows,
            lambda a:a[0].__setitem__('case_identity','0'*64),row_links))
        trial('duplicated_case',lambda _j,r,_m:r(rows,
            lambda a:a.__setitem__(1,copy.deepcopy(a[0])),row_links))
        trial('changed_dependency_demand',lambda _j,r,_m:r(rows,
            lambda a:next(x for x in a if x['demand_comparison']['required_columns'] is not None)
                ['demand_comparison'].__setitem__('required_columns',999),row_links))
        trial('fake_pipeline_counter',lambda _j,r,_m:r(rows,
            lambda a:a[0]['pipeline_evidence'].__setitem__('native_pipeline_operator_invocations',99999),row_links))
        trial('external_fallback',lambda _j,r,_m:r(certs,
            lambda a:a[0]['fields'].__setitem__('external_engine_invoked','true'),cert_links))
        trial('denied_reservation',lambda _j,r,_m:r(certs,
            lambda a:a[0]['fields'].__setitem__('execution_resource_observed_native_denied_reservations','1'),cert_links))
        trial('incorrect_work_delta',lambda j,_r,_m:j(review,
            lambda a:a['details'][0]['resource']['execution_resource_observed_native_peak_reserved_bytes']
                .__setitem__('delta',-99999)))
        trial('incorrect_engine_total',lambda j,_r,_m:j(summary,
            lambda a:a.__setitem__('complete_cohort_engine_seconds',0)))
        trial('dropped_native_check',lambda j,_r,_m:j('current/cardinality-validation-r1.json',
            lambda a:a['checks'].pop('cardinality-native-tests-r1.json')))
        trial('incomplete_full_native_suite',lambda j,_r,_m:j('current/cardinality-validation-r1.json',
            lambda a:a.__setitem__('full_native_library_suite_completed',False)))
        trial('unverified_input_hashes',lambda j,_r,_m:j(cohort+'complete.json',
            lambda a:a.__setitem__('posthash_verified',False)))
        trial('extra_query_attempt',lambda j,_r,_m:j(cohort+'complete.json',
            lambda a:a.__setitem__('attempt_slots',214)))
        trial('unsafe_archive_name',lambda _j,_r,m:m.__setitem__('../escape',b'bad'))
        assert verifier.verify(root)==relocated
    for name,raw in original.items():
        assert (PACKET/name).read_bytes()==raw
    result=dict(status='passed',query_executions=0,relocated_replay=relocated,
        controls=observations,controls_rejected=len(observations),original_packet_unchanged=True,
        helper=identity(Path(__file__).read_bytes()),manifest=identity(original['manifest.json']))
    with DESTINATION.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps(dict(status='passed',controls_rejected=len(observations),query_executions=0)))


if __name__=='__main__':
    main()
