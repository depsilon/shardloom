"""Package the two independently observed source-demand connections; no query runs."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
DEST = OUT/'compact-connections-r3'
ORIGINAL = OUT.parent/'expanded-query-2026-11-03'
BASE = '9f4580c723f876f087d3e75fb56153b4b099ef20'
sys.path.insert(0,str(ROOT/'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def identity(raw):
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def main():
    assert __debug__ and not DEST.exists()
    require_local_path(DEST,Path.home(),sys.platform)
    check_budgets(OUT,DEST,OUT/'logs',min_free_bytes=12*GIB,reserve_bytes=128*MIB,
                  max_workspace_bytes=100*GIB,max_log_bytes=192*MIB)
    members = {}

    def add(path,name):
        assert path.is_file() and not path.is_symlink() and name not in members
        members[name] = (path.read_bytes(),str(path))

    heads = {}
    for label in ('sort','cardinality'):
        summary = json.loads((OUT/(label+'-cohort-r1/verified-summary-r1.json')).read_bytes())
        assert summary['status'] == 'passed_offline_replay' and summary['unsuccessful_cases'] == 0
        assert summary['required_column_demand_matched'] and summary['lower_complete_cohort_engine_time']
        heads[label] = summary['source_commit']
        for path in sorted(OUT.glob(label+'-*.json')):
            add(path,'current/'+path.name)
        for path in sorted(OUT.glob(label+'-*.log')):
            add(path,'current/'+path.name)
        for path in sorted((OUT/'logs').glob(label+'-*.log')):
            add(path,'current/logs/'+path.name)
        for path in sorted((OUT/(label+'-cohort-r1')).iterdir()):
            if path.suffix == '.json' or path.name in {'verified-cases-r1.jsonl.gz','certificate-cases-r1.jsonl.gz'}:
                add(path,'current/'+str(path.relative_to(OUT)))
        for path in sorted((OUT/(label+'-installed-wheel-r1')).iterdir()):
            if path.is_file() and path.suffix in {'.json','.log','.txt'}:
                add(path,'current/'+str(path.relative_to(OUT)))
    for pattern in ('*sort*.py','*cardinality*.py','*cardinality*.md'):
        for path in sorted(OUT.glob(pattern)):
            name='current/'+path.name
            if name not in members:
                add(path,name)
    for name in ('pipeline_runtime.py','guard_checks.py','connections-verify.py','package_connections.py',
                 'review_connection_work.py','test_connections_packet.py','export_connection_baseline.py',
                 'baseline-connection-certificates-r1.json','baseline-connection-certificates-r1.jsonl.gz',
                 'connections-verifier-failure-r1.json'):
        add(OUT/name,'current/'+name)
    for name in ('verified-summary-r1.json','verified-cases-r1.jsonl.gz',
                 'certificate-cases-r1.jsonl.gz','certificate-export-r1.json'):
        add(OUT/'full10k-r1'/name,'baseline/'+name)
    for name in ('design.json','inputs.json','frozen.json'):
        add(ORIGINAL/name,'original/'+name)
    add(OUT.parent/'native-pipeline-sql-minute-2026-11-13/guard_checks.py','helpers/check-supervisor.py')
    add(OUT.parent/'perf-all-20260906/bounded_build_process_resume_20260912.py','helpers/bounded-supervisor.py')
    for label,start in [('sort',BASE),('cardinality',heads['sort'])]:
        raw = subprocess.check_output(['git','diff','--binary',start,heads[label]],cwd=ROOT)
        members['source/'+label+'.patch'] = (raw,'git diff '+start+' '+heads[label])
    DEST.mkdir()
    shutil.copyfile(OUT/'connections-verify.py',DEST/'verify.py')
    (DEST/'README.md').write_text('''# Shared source-demand connection evidence

The Sort and cardinality/expansion cohorts are separate, source-bound observations.
They reuse their exact original 10k baseline cases and execute each candidate once.
Their engine totals must not be combined into a synthetic full10k result.

Run `python3 -B verify.py` from any location. The verifier checks all archived bytes,
exact declaration/order/identity joins, dependency counts, saved engine clocks,
pipeline evidence, source equality across checks/build/install, and cohort totals.
It runs no query and needs only Python's standard library.

Complete results were independently replayed locally against the original reference
ledgers. Raw answer/reference ledgers and large runtime binaries remain local; this
compact verifier does not independently repeat answer correctness checks. Original
failed checks and their logs are preserved, separately from the accepted check set.

Native Vortex controls lack the comparable generic per-source column counter used
for Parquet/IPC. No whole-engine coverage, repeatability or release claim is made.
''')
    archive_path=DEST/'observations.tar.gz'
    with archive_path.open('xb') as stream:
        with gzip.GzipFile(fileobj=stream,mode='wb',filename='',mtime=0) as compressed:
            with tarfile.open(fileobj=compressed,mode='w') as archive:
                for name,(raw,_) in sorted(members.items()):
                    entry=tarfile.TarInfo(name)
                    entry.size,entry.mode,entry.mtime=len(raw),0o644,0
                    archive.addfile(entry,io.BytesIO(raw))
    with tarfile.open(archive_path,'r:gz') as archive:
        assert set(archive.getnames())==set(members)
        for item in archive.getmembers():
            assert archive.extractfile(item).read()==members[item.name][0]
    manifest=dict(schema='shardloom.source_demand_connection_evidence.v1',
        source_commits=heads,query_executions_during_packaging=0,published=False,
        files={path.name:identity(path.read_bytes()) for path in sorted(DEST.iterdir())},
        archive_members={name:dict(**identity(raw),origin=origin)
                         for name,(raw,origin) in sorted(members.items())})
    with (DEST/'manifest.json').open('x') as stream:
        json.dump(manifest,stream,indent=2);stream.write('\n')
    print(json.dumps(dict(status='packaged_readback_verified',archive_members=len(members),
                         archive_bytes=archive_path.stat().st_size,source_commits=heads)))


if __name__=='__main__':
    main()
