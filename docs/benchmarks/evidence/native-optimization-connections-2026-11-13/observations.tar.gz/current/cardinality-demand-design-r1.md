# Shared cardinality and expansion column demand

The independently reconstructed 10,000 declarations expose 14 filtered COUNT(*)
and 82 explode/reduction cases with unnecessary source columns. The three new
regression tests fail on cac86e8b0: two projected columns instead of one for
filtered count, an unused corrupt first column is read, and three projected
columns instead of one for list expansion. Original failing receipts remain.

Use the existing source-demand binder and bound unary operator. An empty value
demand still needs a real row carrier; prefer an already required predicate
field within the admitted scan schema. Do not invent metadata row counts.

For owned demanded sources, propagate ExplodeRows input dependencies both when
the unary request is initially bound and when a downstream consumer narrows its
output. Keep every expanded list, even if its output is unused: it contributes
row cardinality, null behavior, zip-length checks and observable errors. Keep
the unary predicate, source-order limit, aliases, all upstream computations and
complete producer lifecycle. Caller-owned batches/memory keep their existing
validation scope. Rebind the existing BoundUnary before narrowing its child;
its named input fields remain valid if the child retains extra required fields.
Avoid rebuilding when every scalar output remains needed. Charge temporary
request/schema overlap through the current session; no new execution provider.

Vortex-first classification: use_vortex_native_provider through existing native
arrays, list coordinates, selection/take and demanded source projections. The
change connects ShardLoom relational dependencies to those existing owners; no
new kernel, source abstraction, Arrow execution boundary or dependency is added.
Native Vortex input/output and fallback_attempted=false remain required.

Acceptance includes before/after regressions, null/empty and aliased/nested lists,
hidden predicates, multi-list mismatch, late required-field/computation errors,
constant/count consumers, memory refunds/cancellation, source-demand/native and
workspace validation. Any performance cohort and decision must be frozen before
candidate execution, with complete independent results and source-bound controls.
