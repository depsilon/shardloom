"""Freeze the complete structurally selected Sort cohort and exact saved baseline."""
from collections import Counter
import gzip
import hashlib
import json
import math
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
E = OUT.parent / 'expanded-query-2026-11-03'


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def main():
    destination = OUT / 'sort-demand-cohort-r1.json'
    assert not destination.exists()
    proof = read(OUT / 'sort-demand-exposure-primary-r1.json')
    assert proof['status'] == 'passed' and proof['declarations_verified'] == 10000
    assert proof['shape_matches'] == 606 and proof['narrower_source_demand'] == 117
    static = {row['id']: row for row in proof['cases']}
    assert len(static) == 606
    baseline = OUT / 'full10k-r1'
    summary = read(baseline / 'verified-summary-r1.json')
    assert summary['successful_cases'] == summary['attempted_cases'] == 10000
    assert summary['source_commit'] == '9f4580c723f876f087d3e75fb56153b4b099ef20'
    case_path = baseline / 'verified-cases-r1.jsonl.gz'
    assert identity(case_path)['sha256'] == summary['case_rows']['sha256']
    with gzip.open(case_path, 'rt') as stream:
        saved = {row['id']:row for line in stream if (row := json.loads(line))}
    cert_path = baseline / 'certificate-cases-r1.jsonl.gz'
    cert_binding = read(baseline / 'certificate-export-r1.json')
    assert identity(cert_path)['sha256'] == cert_binding['output']['sha256']
    with gzip.open(cert_path, 'rt') as stream:
        certs = {row['id']:row for line in stream if (row := json.loads(line))}
    design = read(E / 'design.json')
    selected = []
    groups = Counter()
    for ordinal, descriptor in enumerate(design['cases']):
        if descriptor['id'] not in static:
            continue
        ident = descriptor['id']
        inference, observed, certificate = static[ident], saved[ident], certs[ident]
        assert inference['case_identity'] == descriptor['case_identity']
        assert observed['seq'] == certificate['seq'] == ordinal
        assert observed['current']['status'] == certificate['status'] == 'passed'
        seconds = observed['current']['engine_seconds']
        assert seconds == inference['saved_engine_seconds'] and math.isfinite(seconds) and seconds >= 0
        work = observed['current']['work']
        before = int(work['native_source_demand_projected_columns'])
        needed = sum(map(len, inference['after_scan_columns'].values()))
        assert needed <= before
        if inference['narrows_scan']:
            group = 'new_column_reduction' if before > needed else 'already_narrowed'
            assert before in (needed, 38)
        else:
            assert before == needed
            group = 'all_fields_required'
        tokens = re.findall(r'(?:^|[ ;])([a-z][a-z0-9_]*)=([0-9]+)(?=$|[ ;])',
                            certificate['fields']['local_primitive_native_io_pushdown_proof_basis'])
        assert len(tokens) == len(dict(tokens))
        metrics = dict(tokens)
        selected.append(dict(original_ordinal=ordinal, declaration=descriptor,
            comparison_group=group, baseline_engine_seconds=seconds,
            baseline_projected_columns=before, required_projected_columns=needed,
            required_scan_columns=inference['after_scan_columns'],
            baseline_ranked_sources=int(metrics.get('ranked_sources', 0)),
            baseline_work=work))
        groups[group] += 1
    assert len(selected) == len(static) == 606
    assert groups == {'new_column_reduction':98, 'already_narrowed':19, 'all_fields_required':489}
    assert all(row['declaration']['surface'] == 'typed_relation' for row in selected
               if row['comparison_group'] == 'already_narrowed')
    baseline_seconds = math.fsum(row['baseline_engine_seconds'] for row in selected)
    assert baseline_seconds == 85.218734162
    sources = [Path(__file__), OUT/'sort-demand-design-r1.md', E/'design.json',
               OUT/'sort-demand-exposure-primary-r1.json', OUT/'verify_sort_exposure.py',
               baseline/'verified-summary-r1.json', case_path, cert_path,
               baseline/'certificate-export-r1.json', OUT/'runtime-r1-identity.json',
               OUT/'validation-before-10k.json', OUT/'full10k-protocol-r1.json',
               OUT/'full10k-supervision-r1.json']
    record = dict(status='frozen_before_candidate_execution', query_executions=0,
        schema='shardloom.sort_source_demand_cohort.v1', case_count=606,
        selection='All structurally matched original Parquet/Arrow IPC downstream Project-through-Limit Sort declarations; no timing selection.',
        attempts_per_case=1, warmups=0, repeats=0,
        primary_clock='engine_execution_seconds', baseline_engine_seconds=baseline_seconds,
        baseline_source_commit=summary['source_commit'], baseline_queries_to_repeat=0,
        groups=dict(groups), source_identities=[identity(path) for path in sources], cases=selected)
    destination.write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
    print(json.dumps({key:record[key] for key in ('status','case_count','groups','baseline_engine_seconds')}))


if __name__ == '__main__':
    main()
