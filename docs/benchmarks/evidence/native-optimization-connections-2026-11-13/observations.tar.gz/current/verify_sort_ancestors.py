"""Check every admitted Sort ancestor in the fixed original declarations."""
from collections import Counter, defaultdict
import json
from pathlib import Path
import sys

import verify_sort_exposure as original
from pipeline_runtime import identity

OUT = Path(__file__).resolve().parent


def admitted(node):
    return node.op == 'scan' or (node.op in {
        'project', 'filter', 'limit', 'join', 'window', 'sort'
    } and all(admitted(child) for child in node.inputs))


def walk(node, ancestors=()):
    if node.op == 'sort' and admitted(node.inputs[0]):
        yield ancestors, node
    for child in node.inputs:
        yield from walk(child, ancestors + (node.op,))


def main():
    assert __debug__
    destination = OUT / 'sort-ancestor-adversarial-r2.json'
    assert not destination.exists()
    design_path = original.E / 'design.json'
    design = json.loads(design_path.read_bytes())
    legacy = {item.id:item for item in original.corpus(interactions='all', include_pending=False)}
    definitions = {item.name:item for item in original.spaces()}
    counts, ids, nested = Counter(), defaultdict(set), []
    verified = 0
    for descriptor in design['cases']:
        item = original.build(descriptor, definitions) if 'cell' in descriptor else legacy[descriptor['id']]
        assert item.identity == descriptor['case_identity']
        verified += 1
        if descriptor['native_format'] not in {'parquet', 'arrow-ipc'}:
            continue
        for ancestors, node in walk(item.relation):
            key = '/'.join(ancestors) or '<root>'
            counts[key] += 1
            ids[key].add(item.id)
            if any(child.op == 'sort' for child in original.nodes(node.inputs[0])):
                nested.append(item.id)
    cohort_path = OUT / 'sort-demand-cohort-r1.json'
    cohort = json.loads(cohort_path.read_bytes())
    assert verified == 10000 and dict(counts) == {'limit':60, 'project/limit':606}
    assert nested == []
    assert ids['project/limit'] == {row['declaration']['id'] for row in cohort['cases']}
    assert not ids['limit'] & ids['project/limit']
    assert not any(name == 'shardloom._native' or name.startswith('_polars_runtime') for name in sys.modules)
    paths = {Path(__file__), Path(original.__file__), design_path, cohort_path}
    for name, module in sys.modules.items():
        if name.startswith(('query_surface.', 'shardloom.')) and getattr(module, '__file__', None):
            paths.add(Path(module.__file__))
    result = dict(status='passed_static_inventory', query_executions=0,
        declarations_verified=verified, sort_ancestor_paths=dict(counts),
        ids_by_path={key:sorted(values) for key, values in ids.items()},
        nested_admitted_sort_ids=nested, all_downstream_demand_shapes_in_frozen_cohort=True,
        unchanged_other_shapes='The other 60 are root Limit over Sort, with no downstream field-selection consumer.',
        source_identities={str(path):identity(path) for path in sorted(paths)})
    with destination.open('x') as stream:
        json.dump(result, stream, indent=2); stream.write('\n')
    print(json.dumps({key:value for key,value in result.items() if key not in {'ids_by_path','source_identities'}}))


if __name__ == '__main__':
    main()
