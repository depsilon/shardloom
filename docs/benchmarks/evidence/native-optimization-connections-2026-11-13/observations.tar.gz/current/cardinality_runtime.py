"""Bind the cardinality demand runtime to complete default/native checks and install proof."""
from pipeline_runtime import OUT, ROOT, fingerprint, generation, git, identity, read, sources

MANIFEST = OUT / 'cardinality-runtime-r1-identity.json'
VALIDATION = OUT / 'cardinality-validation-r1.json'
CHECKS = {
    'cardinality-fmt-r1.json', 'cardinality-default-clippy-r1.json', 'cardinality-native-clippy-r4.json',
    'cardinality-default-tests-r1.json', 'cardinality-native-tests-r1.json', 'cardinality-installed-wheel-r1.json',
}


def source_revision():
    record = read(MANIFEST)
    return record['source_commit'], record['source_tree']


def verify():
    assert __debug__
    manifest, validation = read(MANIFEST), read(VALIDATION)
    assert manifest['status'] == validation['status'] == 'passed'
    assert identity(MANIFEST) == validation['runtime']
    assert manifest['source_commit'] == validation['source_commit'] == git('rev-parse', 'HEAD')
    assert manifest['source_tree'] == validation['source_tree'] == git('rev-parse', 'HEAD^{tree}')
    assert manifest['profile'] == 'release' and not git('status', '--porcelain')
    build_path = OUT / manifest['build_receipt']
    assert identity(build_path) == manifest['build_receipt_identity']
    build = read(build_path)
    assert build['status'] == 'passed' and build['returncode'] == 0
    assert build['sources_unchanged'] and build['process_group_drained'] and build['direct_child_reaped']
    assert build['source_files'] == sources()
    assert fingerprint(build['source_files']) == manifest['source_fingerprint_sha256']
    assert set(validation['checks']) == CHECKS
    assert validation['native_validation_scope'] == 'full_workspace_all_targets_default_and_native'
    assert validation['full_native_library_suite_completed'] is True
    proofs = [MANIFEST, VALIDATION, build_path]
    for name, expected in validation['checks'].items():
        path = OUT / name
        assert identity(path) == expected
        check = read(path)
        assert check['status'] == 'passed' and check['returncode'] == 0
        assert check['sources_unchanged'] and check['process_group_drained'] and check['direct_child_reaped']
        assert check['source_files'] == build['source_files']
        proofs.append(path)
    for name, expected in validation['installed_checks'].items():
        path = OUT / name
        assert identity(path) == expected and read(path)['status'] == 'passed'
        proofs.append(path)
    runtime = {}
    for key, name in [('binary', 'shardloom'), ('library', '_native.abi3.so')]:
        path = OUT / 'cardinality-runtime-r1' / name
        actual = identity(path)
        assert actual == manifest['files'][str(path)]
        runtime[key] = dict(path=str(path), **actual)
    assert identity(OUT/'cardinality-runtime-r1/lib_native.dylib') == identity(OUT/'cardinality-runtime-r1/_native.abi3.so')
    return dict(head=manifest['source_commit'], source_tree=manifest['source_tree'],
        source_root=str(ROOT), source_fingerprint_sha256=manifest['source_fingerprint_sha256'],
        runtime=runtime, proofs={str(path):identity(path) for path in proofs},
        native_validation_scope=validation['native_validation_scope'],
        full_native_library_suite_completed=True, locally_validated=True,
        published=False, runtime_rebuilt=True)

