"""One unchanged Full43 pass after PR 1559, with concurrent host observation."""
import datetime as dt
import gzip
import hashlib
import json
import os
from pathlib import Path
import platform
import stat
import subprocess
import sys
import threading
import time

from freeze_native_release_298 import ROOT, OUT, save, sha, sources
import run_compression_full43_457 as common

sys.path.insert(0, str(ROOT / 'scripts'))
from clickbench_reference_packet import load_reference_packet
from local_uat_storage import DEFAULT_MAX_LOG_MIB, DEFAULT_MAX_RUN_LOG_MIB, GIB, MIB, check_budgets, require_local_path
from native_workflow_protocol import extract_result, report_fields, strict_json
from query_timing_report import query_phase_timings, timing_totals
from run_clickbench_query_uat import clickbench_harness_paths, equivalent, read_json_log, score

NAME = 'postmerge-full43-504'
HEAD = 'ff9aa27338ca9f1ff5581f5a57603400f5aec926'
PR_HEAD = 'b698b1ba5728068c4b90a4194899f9aca5e6b8eb'
MANIFEST = OUT / 'native-release-artifacts-streamunary494.json'
SOURCE_MANIFEST = OUT / 'native-release-source-streamunary494.json'
UAT = common.UAT
INPUT = UAT / 'vortex/timed-native-461-a1.vortex'
BASELINE = UAT / 'logs/full43_20261015T090121385273Z'
REFERENCE, QUERIES, bound = common.REFERENCE, common.QUERIES, common.bound
CHANGED_NON_BUILD = ['python/tests/test_native_unary_binding.py',
    'scripts/check_user_surface_reference.py', 'scripts/native_streaming_unary_composition_cases.py',
    'scripts/run_native_streaming_input_uat.py']
ADDED_NON_BUILD = ['python/tests/test_native_streaming_uat_compression.py']


def frozen():
    build = strict_json(MANIFEST.read_text())
    original = strict_json(SOURCE_MANIFEST.read_text())
    assert build['status'] == 'passed' and build['build_profile'] == 'release'
    assert build['source_sha256'] == original['source_sha256']
    current = sources()
    assert sorted(p for p, digest in original['source_sha256'].items() if current.get(p) != digest) == CHANGED_NON_BUILD
    assert sorted(set(current) - set(original['source_sha256'])) == ADDED_NON_BUILD
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip()
    subprocess.run(['git', 'diff', '--exit-code', PR_HEAD, HEAD], cwd=ROOT, check=True)
    for kind in ('cli', 'binding'):
        artifact = build[kind]
        assert bound(artifact['path']) == {key: artifact[key] for key in ('path', 'bytes', 'sha256')}
        assert sha(artifact['build_receipt']) == artifact['build_receipt_sha256']
        receipt = strict_json(Path(artifact['build_receipt']).read_text())
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert receipt['head'] == build['head'] and '--release' in receipt['command']
        assert sha(artifact['build_log']) == receipt['log_sha256']
    return build, current


def capture_processes():
    output = subprocess.check_output(['ps', '-axo', 'pid=,ppid=,pgid=,%cpu=,rss=,comm='], text=True, timeout=10)
    rows = []
    for line in output.splitlines():
        fields = line.split(None, 5)
        if len(fields) == 6:
            rows.append(dict(pid=int(fields[0]), ppid=int(fields[1]), pgid=int(fields[2]),
                sampled_cpu_percent=float(fields[3]), rss_bytes=int(fields[4])*1024, executable=fields[5]))
    return rows


def host_state():
    keys = ['hw.model', 'hw.memsize', 'hw.physicalcpu', 'hw.logicalcpu',
        'hw.perflevel0.physicalcpu', 'hw.perflevel1.physicalcpu', 'machdep.cpu.brand_string']
    return dict(platform=platform.platform(), cpu_count=os.cpu_count(),
        sysctl=subprocess.check_output(['/usr/sbin/sysctl', *keys], text=True),
        power=subprocess.check_output(['/usr/bin/pmset', '-g', 'batt'], text=True),
        power_settings=subprocess.check_output(['/usr/bin/pmset', '-g', 'custom'], text=True))


class Observer:
    def __init__(self, old):
        self.old = old
        self.stop = threading.Event()
        self.thread = None
        self.samples = 0
        self.errors = []
        self.summary_path = None
        self.last_print = 0.0
        self.stream = None
        self.started = time.monotonic()
        self.owned = {os.getpid()}

    def sample(self):
        rows = capture_processes()
        while True:
            found = {r['pid'] for r in rows if r['ppid'] in self.owned}
            if found <= self.owned:
                break
            self.owned.update(found)
        native = [r for r in rows if Path(r['executable']).name == 'shardloom']
        conflicts = [r for r in rows if r['pid'] not in self.owned and
            (Path(r['executable']).name in {'cargo', 'rustc', 'shardloom', 'pytest', 'nextest',
                'plain_vortex_fixture', 'plain-vortex-fixture'} or
             Path(r['executable']).name.startswith(('shardloom-', 'compare-native-artifacts')))]
        external = [r for r in rows if r['pid'] not in self.owned]
        new = set((UAT / 'logs').glob('full43_*/summary.json')) - self.old
        completed, latest = None, None
        if len(new) == 1:
            self.summary_path = next(iter(new))
            try:
                report = json.loads(self.summary_path.read_text())
                completed = len(report['records'])
                if report['records']:
                    latest = {k: report['records'][-1].get(k) for k in
                        ('query', 'passed', 'engine_execution_seconds', 'seconds', 'user_cpu_seconds', 'system_cpu_seconds', 'native_peak_rss_bytes')}
            except (json.JSONDecodeError, OSError):
                pass  # The canonical runner rewrites its progress file in place.
        sample = dict(utc=dt.datetime.now(dt.timezone.utc).isoformat(), elapsed_seconds=time.monotonic()-self.started,
            process_count=len(rows), load_average=os.getloadavg(), native_processes=native,
            owned_processes=[r for r in rows if r['pid'] in self.owned], conflicting_workloads=conflicts,
            top_external_processes=sorted(external, key=lambda r:r['sampled_cpu_percent'], reverse=True)[:20],
            external_sampled_cpu_percent_sum=sum(r['sampled_cpu_percent'] for r in external),
            vm_stat=subprocess.check_output(['/usr/bin/vm_stat'], text=True, timeout=10),
            swapusage=subprocess.check_output(['/usr/sbin/sysctl', 'vm.swapusage'], text=True, timeout=10),
            completed_queries=completed, latest_query=latest)
        self.stream.write(json.dumps(sample, allow_nan=False)+'\n')
        self.stream.flush()
        self.samples += 1
        if time.monotonic()-self.last_print >= 20:
            print(json.dumps(dict(observation=self.samples, completed_queries=completed,
                native_cpu_percent=[r['sampled_cpu_percent'] for r in native],
                competing_workloads=len(conflicts), latest_query=latest)), flush=True)
            self.last_print = time.monotonic()

    def loop(self):
        while not self.stop.wait(5):
            try:
                self.sample()
            except BaseException as error:
                self.errors.append(type(error).__name__+': '+str(error))

    def __enter__(self):
        self.stream = (OUT/f'{NAME}-observations.jsonl').open('x')
        self.sample()
        self.thread = threading.Thread(target=self.loop, name='uat-resource-observer')
        self.thread.start()
        return self

    def __exit__(self, *exc):
        self.stop.set()
        self.thread.join()
        try:
            self.sample()
        finally:
            self.stream.close()


def main():
    build, source_map = frozen()
    for suffix in ('.json', '.log', '-admission.json', '-review.json', '-host.json', '-observations.jsonl'):
        assert not (OUT/f'{NAME}{suffix}').exists()
    input_receipt = json.loads((ROOT/'docs/benchmarks/evidence/native-query-timing-uat-2026-10-15.json').read_text())['datasets'][str(INPUT)]
    for path in (OUT, UAT, INPUT):
        require_local_path(path, Path.home(), sys.platform)
    before = common.generation(INPUT)
    assert stat.S_ISREG(INPUT.stat().st_mode) and before['st_flags'] == 0
    assert before['st_size'] == 15713610513 and before['st_blocks']*512 >= before['st_size']
    storage = check_budgets(UAT, INPUT, UAT/f'logs/{NAME}-admission', min_free_bytes=12*GIB,
        reserve_bytes=(4+DEFAULT_MAX_RUN_LOG_MIB)*MIB, max_workspace_bytes=100*GIB,
        max_log_bytes=DEFAULT_MAX_LOG_MIB*MIB, max_run_log_bytes=DEFAULT_MAX_RUN_LOG_MIB*MIB,
        reserve_log_bytes=DEFAULT_MAX_RUN_LOG_MIB*MIB)
    assert not (UAT/'.ingest-uat.lock').exists()
    input_identity = bound(INPUT)
    assert input_identity['sha256'] == input_receipt['sha256']
    assert common.generation(INPUT) == before
    assert sha(REFERENCE) == 'cb83c770674073f31ad0c4224f02faeb1ba557c512595a5c2d36f92bb2344b39'
    reference = load_reference_packet(REFERENCE, QUERIES)
    schemas, schema_sources = {}, []
    for query in range(1, 44):
        path = BASELINE/f'q{query:02d}_run1.stdout.json'
        envelope = read_json_log(path)
        assert equivalent(extract_result(envelope), reference['values'][query])
        fields = report_fields(envelope)
        schemas[query] = (fields['result_schema_format'], strict_json(fields['result_schema_json']))
        schema_sources.append(bound(path if path.exists() else path.with_suffix('.json.gz')))
    harness = [bound(path) for path in clickbench_harness_paths()]
    host = host_state()
    save(OUT/f'{NAME}-host.json', host)
    admission = dict(status='passed', merged_commit=HEAD, reviewed_pr_head=PR_HEAD,
        merged_tree_identical_to_reviewed_pr=True, build_manifest=bound(MANIFEST), source_manifest=bound(SOURCE_MANIFEST),
        source_sha256=source_map, post_build_changes=CHANGED_NON_BUILD, post_build_additions=ADDED_NON_BUILD,
        build_reuse_basis='All Rust, Cargo, vendor, runtime Python and Cargo configuration inputs are byte-identical; only listed verification scripts/tests differ.',
        input=input_identity, source_generation=before, source_resident_before_read=True, prior_input_receipt=input_receipt,
        reference=bound(REFERENCE), queries=bound(QUERIES), harness=harness, driver=bound(__file__),
        helpers=[bound(common.__file__), bound(OUT/'run_guarded.py'), bound('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py')],
        storage=storage, schema_sources=schema_sources, memory_gb=24, maximum_parallelism=12, repeats=1,
        log_budget_bytes=dict(retained=DEFAULT_MAX_LOG_MIB*MIB, active_run=DEFAULT_MAX_RUN_LOG_MIB*MIB),
        host=bound(OUT/f'{NAME}-host.json'), observation_interval_seconds=5,
        sampled_cpu_scope='ps CPU estimate, 100 percent is one logical CPU; not exclusive attribution',
        cache_state='prehashed; OS cache uncontrolled', performance_claim_allowed=False,
        reference_kind='retained_native_regression', no_new_ingest=True)
    admission_path = OUT/f'{NAME}-admission.json'
    save(admission_path, admission)
    old = set((UAT/'logs').glob('full43_*/summary.json'))
    command = [sys.executable, '-B', str(OUT/'run_guarded.py'), '--name', NAME, '--timeout', '2400', '--',
        sys.executable, '-B', str(ROOT/'scripts/run_clickbench_query_uat.py'), '--binary', build['cli']['path'],
        '--build-commit', HEAD, '--input', str(INPUT), '--uat-root', str(UAT), '--reference-packet', str(REFERENCE),
        '--queries', str(QUERIES), '--memory-gb', '24', '--max-parallelism', '12', '--timeout', '120',
        '--compress-logs', '--repeats', '1', '--max-log-mib', str(DEFAULT_MAX_LOG_MIB),
        '--max-run-log-mib', str(DEFAULT_MAX_RUN_LOG_MIB)]
    print(json.dumps(dict(status='starting_full43', merged_commit=HEAD, input_sha256=input_identity['sha256'],
        hardware=host['sysctl'], command=command)), flush=True)
    with Observer(old) as observer:
        subprocess.run(command, cwd=ROOT, check=True)
    receipt_path = OUT/f'{NAME}.json'
    receipt = strict_json(receipt_path.read_text())
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert sha(receipt_path.with_suffix('.log')) == receipt['log_sha256']
    new = set((UAT/'logs').glob('full43_*/summary.json'))-old
    assert len(new) == 1
    summary_path = new.pop()
    report = strict_json(summary_path.read_text())
    assert report['build_commit'] == HEAD and report['binary_sha256'] == build['cli']['sha256']
    for key in ('complete', 'full_result_validation', 'completed_identity_check', 'reference_packet_identity_verified', 'harness_identity_verified'):
        assert report[key] is True, key
    assert report['reference_kind'] == 'retained_native_regression'
    assert report['reference_packet']['sha256'] == admission['reference']['sha256']
    assert report['memory_gb'] == 24 and report['max_parallelism'] == 12
    assert report['log_budget_bytes'] == admission['log_budget_bytes']
    assert report['selected_query_ids'] == list(range(1,44)) and len(report['records']) == 43
    assert report['repeats'] == 1 and report['hot_total_seconds'] is None
    assert {(r['query'],r['run']) for r in report['records']} == {(q,1) for q in range(1,44)}
    rows, companions, envelopes, resources = 0, [], [], []
    for record in report['records']:
        query = record['query']
        assert record['passed'] and record['validation'] == 'complete_values'
        assert record['returncode'] == 0 and not record['guard_failures']
        assert record['command'][0] == build['cli']['path']
        prefix = summary_path.parent/f'q{query:02d}_run1'
        timing_path, pid_path = prefix.with_suffix('.timing.json'), prefix.with_suffix('.pid')
        timing = strict_json(timing_path.read_text())
        assert timing['returncode'] == 0
        for key in ('seconds','user_cpu_seconds','system_cpu_seconds'):
            assert timing[key] == record[key]
        assert timing['peak_rss_bytes'] == record['native_peak_rss_bytes']
        try:
            os.kill(int(pid_path.read_text()),0)
        except ProcessLookupError:
            pass
        else:
            raise AssertionError(f'native PID remains: {pid_path}')
        companions.extend([bound(timing_path),bound(pid_path)])
        envelope = None
        for archive in record['completed_log_archives']:
            packed = Path(archive['path']).read_bytes()
            assert len(packed) == archive['gzip_bytes'] and hashlib.sha256(packed).hexdigest() == archive['gzip_sha256']
            raw = gzip.decompress(packed)
            assert len(raw) == archive['raw_bytes'] and hashlib.sha256(raw).hexdigest() == archive['raw_sha256']
            envelopes.append(bound(archive['path']))
            if archive['path'].endswith('.stdout.json.gz'):
                assert envelope is None
                envelope = strict_json(raw.decode())
        assert envelope is not None
        fields = report_fields(envelope)
        for key,value in query_phase_timings(fields,timing['seconds']).items():
            assert record[key] == value, (query,key)
        assert fields['execution_resource_declared_memory_bytes'] == str(24*GIB)
        assert fields['execution_resource_declared_max_parallelism'] == '12'
        assert fields['execution_resource_whole_process_memory_limit_enforced'] == 'false'
        for key,value in fields.items():
            if key.endswith(('fallback_attempted','fallback_execution_allowed','external_engine_invoked')):
                assert value == 'false' or value is False, (query,key)
        assert any(c['kind']=='native_io_certificate' and c['status']=='available' for c in envelope['certificates'])
        actual = extract_result(envelope)
        assert equivalent(actual,reference['values'][query])
        assert hashlib.sha256(json.dumps(actual,sort_keys=True,allow_nan=False).encode()).hexdigest() == record['result_sha256']
        assert (fields['result_schema_format'],strict_json(fields['result_schema_json'])) == schemas[query]
        resources.append(dict(query=query,fields={k:v for k,v in fields.items() if 'resource' in k or 'parallel' in k or 'worker' in k or 'thread' in k}))
        rows += len(actual)
    for key,value in score(report['records'],43,repeats=1,timing_key='engine_execution_seconds').items():
        assert report[key] == value,key
    assert report['secondary_process_wall'] == score(report['records'],43,repeats=1)
    assert common.generation(INPUT) == before and bound(INPUT) == input_identity and common.generation(INPUT) == before
    assert frozen() == (build,source_map)
    for item in harness+schema_sources+admission['helpers']+[admission['reference'],admission['queries'],admission['driver'],admission['build_manifest'],admission['source_manifest']]:
        assert bound(item['path']) == item
    assert not (UAT/'.ingest-uat.lock').exists()
    samples = [json.loads(line) for line in (OUT/f'{NAME}-observations.jsonl').read_text().splitlines()]
    assert observer.samples == len(samples) and not observer.errors,observer.errors
    assert not any(s['conflicting_workloads'] for s in samples)
    result = dict(status='passed', merged_commit=HEAD, admission=bound(admission_path), receipt=bound(receipt_path),
        summary=bound(summary_path), queries=43, calls=43, repeats=1, complete_rows=rows,
        all_values_schemas_and_clocks_reopened=True, resources_no_fallback_native_certificates=True,
        native_children_absent=True, original_input_and_sources_unchanged=True, performance_claim_allowed=False,
        no_new_ingest=True, reference_kind='retained_native_regression', timing_totals=timing_totals(report['records']),
        supervised_suite_seconds=receipt['seconds'], companions=companions, envelopes=envelopes,
        timing_csv=bound(summary_path.parent/'query-timings.csv'), resources=resources,
        observations=bound(OUT/f'{NAME}-observations.jsonl'), observation_count=len(samples), observation_errors=observer.errors,
        no_competing_native_workloads_observed=True, host_after=host_state(), publication_attempted=False)
    save(OUT/f'{NAME}-review.json',result)
    print(json.dumps(dict(status='passed', calls=43, complete_rows=rows, summary=str(summary_path),
        timing_totals=result['timing_totals'], supervised_suite_seconds=receipt['seconds'], observations=len(samples))),flush=True)


if __name__ == '__main__':
    main()
