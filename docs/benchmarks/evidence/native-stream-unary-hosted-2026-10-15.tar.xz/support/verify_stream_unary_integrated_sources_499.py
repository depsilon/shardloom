"""Compare accepted unary source hashes with immutable Git trees."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import subprocess

import verify_stream_destination_integrated_sources_482 as immutable

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
HEAD = 'b698b1ba5728068c4b90a4194899f9aca5e6b8eb'
SYNTHETIC = 'ce1a5966dc007a779c3cc24c8a34b7d26396466c'
TREE = '9254d002c17151d16251cb7c72a32fb7e034bddd'
ACCEPTED = OUT / 'stream-unary-final-source-497.json'
ARTIFACTS = OUT / 'native-release-artifacts-streamunary494.json'
FREEZER = OUT / 'freeze_native_release_298.py'


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def selector_check():
    original = ast.parse(FREEZER.read_text())
    select = next(node.value for node in ast.walk(original)
                  if isinstance(node, ast.Assign)
                  and any(isinstance(target, ast.Name) and target.id == 'selected' for target in node.targets))
    other = ast.parse(Path(immutable.__file__).read_text())
    fn = next(node for node in other.body if isinstance(node, ast.FunctionDef) and node.name == 'selected')
    actual = fn.body[0].value

    class Normalize(ast.NodeTransformer):
        def visit_Name(self, node):
            return ast.copy_location(ast.Name(id='name' if node.id == 'path' else node.id, ctx=node.ctx), node)

    assert ast.dump(select, include_attributes=False) == ast.dump(Normalize().visit(actual), include_attributes=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--merged')
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    selector_check()
    revisions = dict(pr_head=HEAD, ci_merge=SYNTHETIC)
    if args.merged:
        revisions['merged'] = args.merged
    synthetic_path = OUT / 'stream-unary-hosted-498/synthetic-merge-499.json'
    synthetic = json.loads(synthetic_path.read_text())
    assert synthetic['sha'] == SYNTHETIC
    assert [p['sha'] for p in synthetic['parents']] == ['e859b3a8b9d323587cee9641f5ebacd21e7e799c', HEAD]
    trees = {key: (synthetic['tree']['sha'] if key == 'ci_merge' else
                  subprocess.check_output(['git', 'rev-parse', rev + '^{tree}'], cwd=ROOT, text=True).strip())
             for key, rev in revisions.items()}
    assert set(trees.values()) == {TREE}
    source, records = immutable.immutable_source_map(HEAD)
    accepted = json.loads(ACCEPTED.read_text())['source_sha256']
    assert len(source) == len(accepted) == 2283
    assert {path: row['sha256'] for path, row in source.items()} == accepted
    assert all(mode in ('100644', '100755') for _, _, mode in records)
    artifacts = json.loads(ARTIFACTS.read_text())
    binaries = {}
    for kind in ('cli', 'binding'):
        row = artifacts[kind]
        binaries[kind] = identity(row['path'])
        assert binaries[kind] == {key: row[key] for key in ('path', 'bytes', 'sha256')}
    prior = artifacts['source_sha256']
    added = sorted(accepted.keys() - prior.keys())
    assert added == ['python/tests/test_native_streaming_uat_compression.py']
    assert not (prior.keys() - accepted.keys())
    changes = [path for path in accepted.keys() & prior.keys() if accepted[path] != prior[path]]
    assert sorted(changes) == ['python/tests/test_native_unary_binding.py', 'scripts/check_user_surface_reference.py', 'scripts/native_streaming_unary_composition_cases.py', 'scripts/run_native_streaming_input_uat.py'], changes
    report = dict(schema_version='shardloom.native_stream_unary_integrated_sources.v1', status='passed',
        revisions=revisions, trees=trees, source_files=len(source), immutable_source=source,
        accepted=identity(ACCEPTED), artifact_manifest=identity(ARTIFACTS), binaries=binaries,
        changes_after_original_build=sorted(changes), added_after_original_build=added,
        synthetic_metadata=identity(synthetic_path), selector_ast_matches=True,
        helpers=[identity(__file__), identity(immutable.__file__), identity(FREEZER)],
        scope='Immutable source identity and retained binary identity only; local and hosted execution are separate evidence.')
    with Path(args.output).open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({key: report[key] for key in ('status', 'source_files', 'revisions', 'trees', 'changes_after_original_build')}))


if __name__ == '__main__':
    main()

