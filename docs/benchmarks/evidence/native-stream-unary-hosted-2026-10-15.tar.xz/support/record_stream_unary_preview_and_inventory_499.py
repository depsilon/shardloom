"""Record primary browser observations and verify bounded source citations."""
import hashlib
import json
from pathlib import Path
import subprocess
from datetime import datetime, timezone

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
HEAD = 'b698b1ba5728068c4b90a4194899f9aca5e6b8eb'


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True)
    source = OUT / 'stream-subquery-detachment-inventory-498.json'
    inventory = json.loads(source.read_text())
    assert len(inventory['evidence']) == inventory['evidence_count'] == 22
    assert len({row['id'] for row in inventory['evidence']}) == 22
    citations = []
    for row in inventory['evidence']:
        path = ROOT / row['path']
        raw = path.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == row['sha256']
        committed = subprocess.check_output(['git', 'show', HEAD + ':' + row['path']], cwd=ROOT)
        assert raw == committed
        lines = raw.decode().splitlines()
        a, b = row['line_start'], row['line_end']
        excerpt = '\n'.join(f'{i}: {lines[i - 1]}' for i in range(a, b + 1))
        assert excerpt == row['excerpt'], row['id']
        citations.append(dict(id=row['id'], path=row['path'], sha256=row['sha256'], start=a, end=b))
    source_report = dict(status='passed_source_provenance_only', head=HEAD,
        inventory=identity(source), helper=identity(Path(__file__)), citations=citations,
        source_facts_reviewed=['Credited recursive native payload detachment',
            'Recorder detaches before consuming and checking producer release',
            'Immutable callback API for completed resident/spilled replay',
            'Direct retention in selected sort/join/window build call sites'],
        unresolved=['Reentrant reads lack direct test proof',
            'No source excerpt establishes complete subquery admission correctness',
            'Outer/inner ownership, lazy guards, repeated correlated consumption and skipped-source completion require an implementation contract'],
        engine_executions=0, implementation_changed=False)
    (OUT / 'stream-subquery-detachment-inventory-primary-499.json').open('x').write(json.dumps(source_report, indent=2) + '\n')
    hosted = OUT / 'stream-unary-hosted-498'
    served_path = hosted / 'preview-served-499/report.json'
    served = json.loads(served_path.read_text())
    assert served['head'] == HEAD and served['status'] == 'passed'
    assert len(served['responses']) == 8
    assert all(row['raw_byte_identical'] and row['source_preserved'] for row in served['responses'])
    origin = served['origin']
    pages = []
    for route, title in [('benchmark-methodology', 'Benchmarks'), ('runtime-and-io', 'Runtime and I/O'),
                         ('limitations', 'Support and limitations'), ('python-surface', 'Python')]:
        pages.append(dict(url=origin + '/field-guide/' + route + '/', heading=title,
            observed_by='Primary agent using actual browser DOM and accessibility state',
            unary_scope_present=True, resident_state_limit_present=True,
            hosted_pending_status_present=True, viewport_width=1280, document_width=1280))
    report = dict(schema_version='shardloom.native_stream_unary_preview_browser.v1', status='passed',
        observed_at=datetime.now(timezone.utc).isoformat(), head=HEAD,
        served_source=identity(served_path), pages=pages,
        search=dict(query='unary membership', result_pages=4,
            titles=['Support and limitations', 'Runtime and I/O', 'Python', 'Benchmarks'],
            clicked='Current engineering evidence',
            final_url=origin + '/field-guide/benchmark-methodology/#current-engineering-evidence',
            heading='Current engineering evidence',
            acceptance_link='https://github.com/depsilon/shardloom/blob/main/docs/benchmarks/native-stream-unary-2026-10-15.md'),
        visual_observation='The evidence-section screenshot renders without overlap at the observed viewport. Four guide documents have no horizontal overflow. No mobile-layout or production observation is claimed here.',
        helper=identity(Path(__file__)),
        scope='Manual browser observations recorded after the actual interaction; this helper does not drive or simulate a browser.')
    (hosted / 'preview-browser-499.json').open('x').write(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(status='passed', source_citations=22, preview_pages=4, search_results=4, served_byte_identical=8)))


if __name__ == '__main__':
    main()
