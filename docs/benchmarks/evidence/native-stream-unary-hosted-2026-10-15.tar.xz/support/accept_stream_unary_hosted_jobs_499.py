"""Primary acceptance of immutable captured unary CI logs and installed wheels."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent / 'stream-unary-hosted-498'
LOGS = OUT / 'job-logs'
HEAD = 'b698b1ba5728068c4b90a4194899f9aca5e6b8eb'
BASE = 'e859b3a8b9d323587cee9641f5ebacd21e7e799c'
SYNTHETIC = 'ce1a5966dc007a779c3cc24c8a34b7d26396466c'
RUN = 38827642090
JOBS = {116738723807: 'Python test shard (core)',
        116738724188: 'Rust feature matrix (native_public_surface_tests)',
        116738724018: 'Native Python wheel (py313_macos)',
        116738724209: 'Native Python wheel (py313_ubuntu)',
        116738724249: 'Native Python wheel (py310_ubuntu)',
        116738724325: 'Rust feature matrix (native_vortex_tests)'}


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def checked(ref):
    path = (LOGS / ref['path']).resolve()
    assert LOGS.resolve() in path.parents
    actual = identity(path)
    assert actual['bytes'] == ref['bytes'] and actual['sha256'] == ref['sha256']
    return path


def normalized(path):
    return '\n'.join(re.sub(r'^\d{4}-\d{2}-\d{2}T\S+Z ', '', line)
                     for line in path.read_text().lstrip('\ufeff').splitlines())


def machine_report(text, schema):
    marker = '"schema_version": "' + schema + '"'
    assert text.count(marker) == 1
    offset = text.index(marker)
    start = text.rfind('\n{\n', 0, offset) + 1
    assert start > 0
    value, length = json.JSONDecoder().raw_decode(text[start:])
    assert value['schema_version'] == schema
    return value, dict(start=start, end=start + length)


def source(path):
    return subprocess.check_output(['git', 'show', HEAD + ':' + path], cwd=ROOT)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('snapshot')
    parser.add_argument('--require-complete', action='store_true')
    args = parser.parse_args()
    assert re.fullmatch(r'capture-\d{8}T\d{6}Z', args.snapshot)
    summary_path = LOGS / args.snapshot / 'summary.json'
    summary = json.loads(summary_path.read_text())
    assert summary['status'] in ('PARTIAL', 'COMPLETE') and not summary['errors']
    assert summary['expected_head_sha'] == HEAD and summary['run_id'] == RUN
    assert len(summary['jobs']) == 6 and {r['job_id']: r['expected_name'] for r in summary['jobs']} == JOBS
    assert all(command['exit_code'] == 0 for command in summary['commands'])
    helper_path = LOGS / 'capture_hosted_job_logs_498.py'
    assert identity(helper_path)['sha256'] == 'e8162c7f25d10849a2f77d6827070cb5beb91ca3cd2f210feb788526572b5585'
    run_path = checked(summary['run'])
    run = json.loads(run_path.read_text())
    assert run['id'] == RUN and run['head_sha'] == HEAD
    assert any(pr['number'] == 1559 and pr['head']['sha'] == HEAD and pr['base']['sha'] == BASE
               for pr in run['pull_requests'])
    synthetic_path = OUT / 'synthetic-merge-499.json'
    synthetic = json.loads(synthetic_path.read_text())
    assert synthetic['sha'] == SYNTHETIC
    assert [p['sha'] for p in synthetic['parents']] == [BASE, HEAD]
    tree = subprocess.check_output(['git', 'rev-parse', HEAD + '^{tree}'], cwd=ROOT, text=True).strip()
    assert synthetic['tree']['sha'] == tree
    native_sources = ['shardloom-vortex/src/local_primitive_relational_batch_unary' + suffix + '.rs'
                      for suffix in ('_tests', '_fault_tests', '_pressure_tests')]
    native_tests = []
    for path in native_sources:
        raw = source(path)
        for name in re.findall(r'#\[test\]\s*(?:#\[[^\n]+\]\s*)*fn (\w+)\(', raw.decode()):
            native_tests.append(dict(name=name, source=path, sha256=hashlib.sha256(raw).hexdigest()))
    assert len(native_tests) == len({r['name'] for r in native_tests}) == 8
    binding_sources, methods = [], 0
    for path in sorted((ROOT / 'python/tests').glob('test_native*binding.py')):
        relative = path.relative_to(ROOT).as_posix()
        raw = source(relative)
        names = [node.name for node in ast.walk(ast.parse(raw))
                 if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')]
        methods += len(names)
        binding_sources.append(dict(path=relative, sha256=hashlib.sha256(raw).hexdigest(), methods=names))
    assert methods == 91
    proof_source = source('scripts/prove_native_python_wheel.py').decode()
    assert 'pattern="test_native*binding.py"' in proof_source
    assert 'SHARDLOOM_REQUIRE_NATIVE_PYTHON="1"' in proof_source
    accepted, pending = [], []
    for row in summary['jobs']:
        metadata_path = checked(row['metadata'])
        metadata = json.loads(metadata_path.read_text())
        assert metadata['id'] == row['job_id'] and metadata['run_id'] == RUN
        assert metadata['head_sha'] == HEAD and metadata['name'] == JOBS[row['job_id']]
        if row['capture_state'] == 'pending':
            assert metadata['status'] != 'completed' and row['log'] is None
            pending.append(metadata['name'])
            continue
        assert row['capture_state'] == 'captured'
        assert metadata['status'] == 'completed' and metadata['conclusion'] == 'success'
        assert all(step['conclusion'] in ('success', 'skipped') for step in metadata['steps'])
        log_path = checked(row['log'])
        assert log_path.stat().st_size <= 12 * 1024 * 1024
        text = normalized(log_path)
        assert SYNTHETIC + ':refs/remotes/pull/1559/merge' in text
        assert text.splitlines()[-1].startswith('Cleaning up orphan processes')
        assert not re.search(r'^test .* \.\.\. FAILED$|^test result: FAILED', text, re.M)
        record = dict(job_id=row['job_id'], name=metadata['name'], raw=identity(log_path),
                      metadata=identity(metadata_path), synthetic_tree_matches_reviewed_tree=True)
        if metadata['name'].startswith('Native Python wheel'):
            result, offsets = machine_report(text, 'shardloom.native_python_wheel_proof.v1')
            assert result == row['analysis']['wheel_proof']
            assert result == json.loads(checked(row['analysis']['wheel_proof_file']).read_text())
            assert result['status'] == result['stage']['status'] == result['integrity']['status'] == 'passed'
            assert result['integration'] == dict(tests=91, failures=0, errors=0, skipped=0, status='passed')
            assert result['installed_load']['isolated_install'] and result['installed_load']['version'] == '0.6.0'
            assert result['uninstall_status'] == 'passed'
            assert result['publication_attempted'] is False and result['performance_claim'] is False
            assert all(step['returncode'] == 0 for step in result['steps'])
            steps = {step['name']: step for step in result['steps']}
            assert {'load', 'integration', 'install', 'uninstall', 'verify_uninstalled'} <= steps.keys()
            assert '-I' in steps['load']['command'] and '-I' in steps['integration']['command']
            assert result['integrity']['native_library_sha256'] in steps['load']['command']
            assert result['integrity']['cli_sha256'] in steps['load']['command']
            assert result['integrity']['load_verified'] is False
            if 'ubuntu' in metadata['name']:
                assert result['linux_audit']['status'] == 'passed' and result['integrity']['linux_audit_verified']
            assert result['installed_load']['python'].startswith('3.10.' if 'py310' in metadata['name'] else '3.13.')
            record.update(proof=result, normalized_offsets=offsets)
        elif row['job_id'] == 116738723807:
            result, offsets = machine_report(text, 'shardloom.python_test_shard_evidence.v1')
            assert result['status'] == 'passed' and result['test_count'] == 615 and result['skipped_count'] == 12
            assert result['failure_count'] == result['error_count'] == 0
            assert {'python.tests.test_native_unary_binding', 'python.tests.test_native_streaming_uat_compression'} <= set(result['modules'])
            assert 'Ran 524 tests in 22.838s' in text and 'OK (skipped=12)' in text
            record.update(proof=result, normalized_offsets=offsets, console_tests_run=524)
        else:
            groups = [tuple(map(int, r)) for r in re.findall(
                r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)]
            if row['job_id'] == 116738724188:
                assert groups == [(946, 0, 0), (0, 0, 0), (6, 0, 0), (65, 0, 0), (44, 0, 0), (15, 0, 0)]
            else:
                assert groups == [(2830, 0, 26), (10, 0, 0), (7, 0, 0), (7, 0, 0), (23, 0, 0), (4, 0, 0)], groups
                for test in native_tests:
                    matches = re.findall(r'^test (.*::' + re.escape(test['name']) + r') \.\.\. ok$', text, re.M)
                    assert len(matches) == 1, test['name']
                    test['observed_test_path'] = matches[0]
                ignored = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', text, re.M)
                assert len(ignored) == 26
                record.update(new_native_tests=native_tests, ignored_test_reasons=ignored)
            record.update(result_groups=groups, total_passed=sum(r[0] for r in groups))
        accepted.append(record)
    assert set(pending) == set(summary['pending_job_names'])
    if args.require_complete:
        assert len(accepted) == 6 and not pending and summary['status'] == 'COMPLETE'
    report = dict(schema_version='shardloom.native_stream_unary_primary_hosted_jobs.v1',
        status='passed_all_six' if not pending else 'passed_completed_subset', head=HEAD,
        synthetic=SYNTHETIC, tree=tree, synthetic_metadata=identity(synthetic_path),
        capture=identity(summary_path), run=identity(run_path), capture_helper=identity(helper_path),
        acceptance_helper=identity(Path(__file__)), jobs=accepted, pending=pending,
        wheel_binding_sources=binding_sources,
        interpretation={
            'integrity_load_verified_false': 'Archive-integrity verification does not load a library. The separate isolated load step verifies package location, runtime version and both native-library/CLI hashes.',
            'individual_binding_names': 'Wheel evidence embeds the aggregate 91-test report. Individual passing method names are not printed in the outer hosted log. Exact source discovery and zero skips provide the coverage linkage.',
            'core_skips': 'Hosted core records 12 skips, compared with 10 locally; both discover 615 and execute 524 tests. Installed native-wheel integration records zero skips.',
            'scope': 'Only the listed immutable job captures. Overall CI, review state, final merge and production deployment are separate checks.'})
    destination = OUT / ('primary-acceptance-499-' + args.snapshot + '.json')
    destination.open('x').write(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(status=report['status'], accepted_jobs=len(accepted), pending=pending,
        wheel_lanes=sum(r['name'].startswith('Native Python wheel') for r in accepted),
        report=str(destination))))


if __name__ == '__main__':
    main()
