"""Retain fresh read-only hosted metadata and actual production browser observations."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

OUT = Path(__file__).resolve().parent / 'stream-unary-hosted-498'
HEAD = 'b698b1ba5728068c4b90a4194899f9aca5e6b8eb'
MERGE = 'ff9aa27338ca9f1ff5581f5a57603400f5aec926'
GH = '/opt/homebrew/bin/gh'


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def api(name, arguments):
    completed = subprocess.run([GH, 'api', *arguments], capture_output=True, timeout=60)
    assert completed.returncode == 0, completed.stderr.decode()
    value = json.loads(completed.stdout)
    save(OUT / name, value)
    return value


def main():
    pr = api('pull-request-final-506.json', ['repos/depsilon/shardloom/pulls/1559'])
    checks = api('checks-final-506.json', [f'repos/depsilon/shardloom/commits/{HEAD}/check-runs?per_page=100'])
    statuses = api('statuses-final-506.json', [f'repos/depsilon/shardloom/commits/{HEAD}/status?per_page=100'])
    comments = api('issue-comments-final-506.json', ['repos/depsilon/shardloom/issues/1559/comments?per_page=100'])
    query = '''query { repository(owner:"depsilon", name:"shardloom") {
      pullRequest(number:1559) { number headRefOid merged mergeCommit { oid }
        reviews(first:100) { pageInfo { hasNextPage } nodes { id state commit { oid } } }
        reviewThreads(first:100) { pageInfo { hasNextPage } nodes { id isResolved } }
      } } }'''
    review = api('review-state-final-506.json', ['graphql', '-f', 'query=' + query])
    assert pr['number'] == 1559 and pr['head']['sha'] == HEAD
    assert pr['merged'] and pr['merge_commit_sha'] == MERGE
    assert checks['total_count'] == len(checks['check_runs']) == 44
    assert len({r['id'] for r in checks['check_runs']}) == 44
    assert all(r['head_sha'] == HEAD and r['status'] == 'completed' and r['conclusion'] == 'success'
               for r in checks['check_runs'])
    assert statuses['sha'] == HEAD and statuses['total_count'] == 0 and statuses['statuses'] == []
    assert len(comments) < 100
    bot = [r for r in comments if r['user']['login'] == 'chatgpt-codex-connector[bot]']
    assert len(bot) == 1
    state = json.loads(re.search(r'<!-- codex-review-state:v1 (.*?) -->', bot[0]['body']).group(1))['code_review']
    assert state == dict(commit_sha=HEAD, has_any_findings=False, has_unresolved_findings=False, status='completed')
    reviewed = review['data']['repository']['pullRequest']
    assert reviewed['number'] == 1559 and reviewed['headRefOid'] == HEAD
    assert reviewed['merged'] and reviewed['mergeCommit']['oid'] == MERGE
    for kind in ('reviews', 'reviewThreads'):
        assert reviewed[kind]['pageInfo']['hasNextPage'] is False
        assert reviewed[kind]['nodes'] == []
    served_path = OUT / 'production-served-499/report.json'
    served = json.loads(served_path.read_text())
    assert served['status'] == 'passed' and served['head'] == MERGE
    assert len(served['responses']) == 8 and all(r['source_preserved'] for r in served['responses'])
    pages = [dict(url='https://shardloom.io/field-guide/' + route + '/', heading=title,
                  unary_scope_present=True, resident_state_limit_present=True,
                  hosted_pending_status_present=True, viewport_width=1280, document_width=1265)
             for route, title in [('benchmark-methodology', 'Benchmarks'),
                                  ('runtime-and-io', 'Runtime and I/O'),
                                  ('limitations', 'Support and limitations'),
                                  ('python-surface', 'Python')]]
    browser = dict(schema_version='shardloom.native_stream_unary_production_browser.v1',
        status='passed', observed_at=datetime.now(timezone.utc).isoformat(),
        reviewed_head=HEAD, merged_revision=MERGE, served_source=identity(served_path),
        pages=pages, search=dict(query='unary membership', result_pages=4,
            titles=['Support and limitations', 'Runtime and I/O', 'Python', 'Benchmarks'],
            clicked='Current engineering evidence',
            final_url='https://shardloom.io/field-guide/benchmark-methodology/#current-engineering-evidence',
            heading='Current engineering evidence',
            acceptance_link='https://github.com/depsilon/shardloom/blob/main/docs/benchmarks/native-stream-unary-2026-10-15.md'),
        visual_observation='Evidence-section screenshot inspected inline: readable navigation and content without overlap. All four guide documents fit the observed desktop viewport. No mobile or cross-browser claim.',
        observation_limit='The deployed text correctly matches the merged PR, including its pre-integration pending statement. The subsequent closeout changes that statement; no browser observation of the later text is claimed.',
        helper=identity(Path(__file__)),
        scope='Primary agent observations from actual browser DOM, search, click and screenshot. This helper records those observations and does not drive or simulate a browser.')
    save(OUT / 'production-browser-506.json', browser)
    print(json.dumps(dict(status='passed', checks=44, review_findings=0,
                         production_pages=4, search_results=4)))


if __name__ == '__main__':
    main()
