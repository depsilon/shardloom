"""Verify and retain unary hosted closure and the completed postmerge query pass."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile

import accept_stream_unary_hosted_jobs_499 as jobs
import verify_stream_unary_integrated_sources_499 as sources

ROOT, OUT = sources.ROOT, sources.OUT
RAW = OUT / 'stream-unary-hosted-498'
HEAD, SYNTHETIC = sources.HEAD, sources.SYNTHETIC
MERGE = 'ff9aa27338ca9f1ff5581f5a57603400f5aec926'
sys.path.insert(0, str(ROOT / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def read(path):
    return json.loads(Path(path).read_text())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=digest(raw))


def check(record):
    actual = identity(record['path'])
    assert actual == {k: record[k] for k in ('path', 'bytes', 'sha256')}, record['path']


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def served(stage, revision):
    folder = RAW / (stage + '-served-499')
    report = read(folder / 'report.json')
    assert report['status'] == 'passed' and report['stage'] == stage
    assert report['head'] == revision and report['reviewed_head'] == HEAD
    check(dict(report['helper'], bytes=Path(report['helper']['path']).stat().st_size))
    checks = read(folder / 'deployment-checks.json')
    assert checks['total_count'] == len(checks['check_runs']) <= 100
    workers = [r for r in checks['check_runs'] if r['name'] == 'Workers Builds: shardloom']
    assert len(workers) == 1
    worker = workers[0]
    assert worker['head_sha'] == revision and worker['status'] == 'completed' and worker['conclusion'] == 'success'
    assert all(report['deployment'][k] == worker[k] for k in report['deployment'])
    versions = re.findall(r'Version ID: ([0-9a-f-]{36})', worker['output']['summary'])
    assert len(versions) == 1
    pr = read(folder / 'pull-request.json')
    assert pr['number'] == 1559 and pr['head']['sha'] == HEAD
    if stage == 'production':
        assert pr['merged'] and pr['merge_commit_sha'] == MERGE
    assert len(report['responses']) == len({r['source'] for r in report['responses']}) == 8
    for row in report['responses']:
        actual = (folder / row['response']).read_bytes()
        expected = subprocess.check_output(['git', 'show', revision + ':' + row['source']], cwd=ROOT)
        assert row['http_status'] == 200 and row['source_preserved']
        assert row['observed_bytes'] == len(actual) and row['observed_sha256'] == digest(actual)
        assert row['expected_bytes'] == len(expected) and row['expected_sha256'] == digest(expected)
        assert row['raw_byte_identical'] == (actual == expected)
        assert read(folder / (row['response'] + '.attempts.json')) == row['attempts']
        assert row['attempts'][-1]['status'] == 'passed' and 1 <= len(row['attempts']) <= 3
        if actual != expected:
            prefix = next(i for i, (a, b) in enumerate(zip(actual, expected)) if a != b)
            extra = len(actual) - len(expected)
            assert 0 < extra <= 16384 and row['source'].endswith('.html')
            inserted = actual[prefix:prefix + extra]
            assert actual[prefix + extra:] == expected[prefix:]
            assert b'/cdn-cgi/challenge-platform/' in inserted or b'static.cloudflareinsights.com/' in inserted
            assert row['insertion_bytes'] == extra and row['insertion_sha256'] == digest(inserted)
    return dict(report=report, deployment_version=versions[0])


def main():
    destination = require_local_path(OUT / 'stream-unary-hosted-packet-506', Path.home(), sys.platform)
    check_budgets(OUT, destination, OUT / 'logs', min_free_bytes=12*GIB,
                  reserve_bytes=128*MIB, max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
    assert not destination.exists()
    pr = read(RAW / 'pull-request-final-506.json')
    assert pr['head']['sha'] == HEAD and pr['merged'] and pr['merge_commit_sha'] == MERGE
    checks = read(RAW / 'checks-final-506.json')
    assert checks['total_count'] == len(checks['check_runs']) == 44
    assert len({r['id'] for r in checks['check_runs']}) == 44
    assert all(r['head_sha'] == HEAD and r['status'] == 'completed' and r['conclusion'] == 'success'
               for r in checks['check_runs'])
    statuses = read(RAW / 'statuses-final-506.json')
    assert statuses['sha'] == HEAD and statuses['total_count'] == 0 and statuses['statuses'] == []
    review = read(RAW / 'review-state-final-506.json')['data']['repository']['pullRequest']
    assert review['headRefOid'] == HEAD and review['merged'] and review['mergeCommit']['oid'] == MERGE
    for kind in ('reviews', 'reviewThreads'):
        assert not review[kind]['pageInfo']['hasNextPage'] and review[kind]['nodes'] == []
    comments = read(RAW / 'issue-comments-final-506.json')
    assert len(comments) < 100
    bot = [r for r in comments if r['user']['login'] == 'chatgpt-codex-connector[bot]']
    assert len(bot) == 1
    state = json.loads(re.search(r'<!-- codex-review-state:v1 (.*?) -->', bot[0]['body']).group(1))['code_review']
    assert state == dict(commit_sha=HEAD, has_any_findings=False, has_unresolved_findings=False, status='completed')

    sources.selector_check()
    source = read(RAW / 'merged-sources-505.json')
    immutable, records = sources.immutable.immutable_source_map(MERGE)
    accepted = read(sources.ACCEPTED)['source_sha256']
    assert source['status'] == 'passed' and source['selector_ast_matches']
    assert len(immutable) == len(accepted) == source['source_files'] == 2283
    assert {p: r['sha256'] for p, r in immutable.items()} == accepted
    assert source['immutable_source'] == immutable
    assert all(mode in ('100644', '100755') for _, _, mode in records)
    assert set(source['trees'].values()) == {sources.TREE}
    assert source['revisions'] == dict(pr_head=HEAD, ci_merge=SYNTHETIC, merged=MERGE)
    for record in [source['accepted'], source['artifact_manifest'], source['synthetic_metadata'],
                   *source['helpers'], *source['binaries'].values()]:
        check(record)

    runtime = read(RAW / 'primary-acceptance-499-capture-20261016T005418Z.json')
    assert runtime['status'] == 'passed_all_six' and runtime['pending'] == []
    assert runtime['head'] == HEAD and runtime['synthetic'] == SYNTHETIC and runtime['tree'] == sources.TREE
    for key in ('synthetic_metadata', 'capture', 'run', 'capture_helper', 'acceptance_helper'):
        check(runtime[key])
    assert len(runtime['jobs']) == 6
    assert {r['job_id']: r['name'] for r in runtime['jobs']} == jobs.JOBS
    wheel_lanes = []
    for row in runtime['jobs']:
        for key in ('raw', 'metadata'):
            check(row[key])
        metadata = read(row['metadata']['path'])
        assert metadata['head_sha'] == HEAD and metadata['status'] == 'completed' and metadata['conclusion'] == 'success'
        text = jobs.normalized(Path(row['raw']['path']))
        assert SYNTHETIC + ':refs/remotes/pull/1559/merge' in text
        assert text.splitlines()[-1].startswith('Cleaning up orphan processes')
        if row['name'].startswith('Native Python wheel'):
            proof, offsets = jobs.machine_report(text, 'shardloom.native_python_wheel_proof.v1')
            assert proof == row['proof'] and offsets == row['normalized_offsets']
            assert proof['integration'] == dict(tests=91, failures=0, errors=0, skipped=0, status='passed')
            assert proof['status'] == proof['stage']['status'] == proof['integrity']['status'] == proof['uninstall_status'] == 'passed'
            assert proof['installed_load']['isolated_install'] and proof['installed_load']['version'] == '0.6.0'
            assert all(r['returncode'] == 0 for r in proof['steps'])
            wheel_lanes.append(row['name'])
        elif row['job_id'] == 116738723807:
            proof, offsets = jobs.machine_report(text, 'shardloom.python_test_shard_evidence.v1')
            assert proof == row['proof'] and offsets == row['normalized_offsets']
            assert proof['status'] == 'passed' and proof['test_count'] == 615 and proof['skipped_count'] == 12
            assert row['console_tests_run'] == 524 and 'Ran 524 tests in 22.838s' in text
        else:
            groups = [list(map(int, r)) for r in re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)]
            expected = ([[946,0,0],[0,0,0],[6,0,0],[65,0,0],[44,0,0],[15,0,0]]
                        if row['job_id'] == 116738724188 else
                        [[2830,0,26],[10,0,0],[7,0,0],[7,0,0],[23,0,0],[4,0,0]])
            assert groups == row['result_groups'] == expected
            if row['job_id'] == 116738724325:
                assert row['total_passed'] == 2881 and len(row['new_native_tests']) == 8
                for test in row['new_native_tests']:
                    assert 'test ' + test['observed_test_path'] + ' ... ok' in text
                    assert digest(jobs.source(test['source'])) == test['sha256']
    assert len(wheel_lanes) == 3

    served_reports = dict(preview=served('preview', HEAD), production=served('production', MERGE))
    browsers = {stage: read(RAW / filename) for stage, filename in
                [('preview','preview-browser-499.json'),('production','production-browser-506.json')]}
    for stage, browser in browsers.items():
        assert browser['status'] == 'passed' and len(browser['pages']) == 4
        assert browser['search']['result_pages'] == 4 and browser['search']['query'] == 'unary membership'
        assert all(r['document_width'] <= r['viewport_width'] == 1280 and r['unary_scope_present']
                   and r['resident_state_limit_present'] and r['hosted_pending_status_present'] for r in browser['pages'])
        check(browser['served_source'])
    assert browsers['production']['reviewed_head'] == HEAD and browsers['production']['merged_revision'] == MERGE

    post = read(OUT / 'postmerge-full43-504-review.json')
    assert post['status'] == 'passed' and post['merged_commit'] == MERGE
    assert post['queries'] == post['calls'] == 43 and post['repeats'] == 1 and post['complete_rows'] == 381
    assert all(post[k] for k in ('all_values_schemas_and_clocks_reopened', 'resources_no_fallback_native_certificates',
                                'native_children_absent', 'original_input_and_sources_unchanged'))
    assert post['performance_claim_allowed'] is False
    post_refs = [post[k] for k in ('admission','receipt','summary','timing_csv','observations')]
    post_refs += post['companions'] + post['envelopes']
    for record in post_refs:
        check(record)
    for record in post['envelopes']:
        json.loads(gzip.decompress(Path(record['path']).read_bytes()))
    assert len(post['envelopes']) == 43 and len(post['companions']) == 86
    engine_seconds = post['timing_totals']['totals']['engine_execution_seconds']
    assert engine_seconds == 59.996640954

    report = dict(schema_version='shardloom.native_stream_unary_hosted_verification.v1', status='passed',
        recorded_at=datetime.now(timezone.utc).isoformat(), pr=1559, head=HEAD, merge=MERGE,
        synthetic=SYNTHETIC, trees=source['trees'], checks_passed=44,
        native_total=2881, native_manual_exclusions=26, new_native_tests=8,
        native_public_total=1076, wheel_lanes=wheel_lanes, wheel_tests_per_lane=91,
        core_discovered=615, core_run=524, core_skipped=12, source_files_verified=2283,
        source_changes_after_original_build=source['changes_after_original_build'],
        cli_and_binding_identity_verified=True, code_review=state, review_threads=0,
        served=served_reports, browsers=browsers, interpretation=runtime['interpretation'],
        postmerge_full43=dict(review=identity(OUT/'postmerge-full43-504-review.json'), queries=43,
            calls=43, repeats=1, complete_rows=381, engine_execution_seconds=engine_seconds,
            performance_claim_allowed=False),
        observation_limits=[
            'Production HTML retains the entire merged source around six bounded Cloudflare script insertions; JavaScript and the search entry are byte-identical.',
            'Actual browser checks prove the deployed pre-closeout wording, including its pending status; later closeout wording requires later deployment.',
            'Screenshots were inspected inline, not archived. No mobile or cross-browser matrix is claimed.',
            'The new Full43 observation uses the unchanged merged binary and prior native complete-result reference. It does not isolate a cause for earlier timing variation or establish a speedup.'],
        source_version='0.6.0', publication_attempted=False, performance_claim=False, driver=identity(__file__))
    save(RAW / 'verification-506.json', report)
    files = {'hosted/' + str(p.relative_to(RAW)):p for p in RAW.rglob('*') if p.is_file()}
    helpers = [Path(__file__), Path(jobs.__file__), Path(sources.__file__), Path(sources.immutable.__file__),
               sources.FREEZER, sources.ARTIFACTS, sources.ACCEPTED,
               OUT/'capture_stream_unary_served_499.py', OUT/'capture_stream_unary_closeout_506.py',
               OUT/'record_stream_unary_preview_and_inventory_499.py', ROOT/'scripts/local_uat_storage.py']
    for path in helpers:
        name = 'support/' + path.name
        assert name not in files
        files[name] = path
    for path in [OUT/'run_postmerge_full43_504.py', OUT/'postmerge-full43-504-review.json',
                 OUT/'postmerge-full43-504-host.json', OUT/'postmerge-full43-504-engine-times.md',
                 OUT/'postmerge-full43-504.log', *[Path(r['path']) for r in post_refs]]:
        name = 'postmerge-full43/' + path.name
        assert name not in files
        files[name] = path
    destination.mkdir(exist_ok=False)
    archive = destination/'native-stream-unary-hosted-2026-10-15.tar.xz'
    index = destination/'native-stream-unary-hosted-2026-10-15.json'
    members = []
    with tarfile.open(archive, 'x:xz') as stream:
        for name,path in sorted(files.items()):
            before = identity(path)
            payload = path.read_bytes()
            info = tarfile.TarInfo(name)
            info.size = len(payload)
            info.mode = 0o644
            stream.addfile(info, io.BytesIO(payload))
            assert identity(path) == before
            members.append(dict(name=name, bytes=len(payload), sha256=digest(payload)))
    with tarfile.open(archive,'r:xz') as stream:
        entries = stream.getmembers()
        assert len(entries) == len({r.name for r in entries}) == len(members)
        assert all(r.isfile() for r in entries) and {r.name for r in entries} == set(files)
        for member in members:
            payload = stream.extractfile(member['name']).read()
            assert len(payload) == member['bytes'] and digest(payload) == member['sha256']
            assert payload == files[member['name']].read_bytes()
    save(index, dict(schema_version='shardloom.native_stream_unary_hosted_packet.v1', status='passed',
        pr=1559, head=HEAD, merge=MERGE, synthetic=SYNTHETIC, checks_passed=44,
        native_total=2881, native_manual_exclusions=26, new_native_tests=8,
        native_public_total=1076, wheel_lanes=3, wheel_tests_per_lane=91,
        core_discovered=615, core_run=524, core_skipped=12, source_files_verified=2283,
        served_responses_verified=16, production_deployment_check_complete=True,
        production_deployment_check_id=served_reports['production']['report']['deployment']['id'],
        production_version=served_reports['production']['deployment_version'],
        postmerge_full43=report['postmerge_full43'], observation_limits=report['observation_limits'],
        archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=identity(archive)['sha256']),
        members_verified=len(members), members=members, publication_attempted=False, performance_claim=False))
    check_budgets(OUT,destination,OUT/'logs',min_free_bytes=12*GIB,
                  reserve_bytes=0,max_workspace_bytes=100*GIB,max_log_bytes=192*MIB)
    for path in (archive,index):
        target = ROOT/'docs/benchmarks/evidence'/path.name
        assert not target.exists()
        shutil.copy2(path,target)
        assert identity(path)['sha256'] == identity(target)['sha256']
    print(json.dumps(dict(status='passed',checks=44,wheel_lanes=3,sources=2283,
        served_responses=16,members=len(members),archive=identity(archive))))


if __name__ == '__main__':
    main()
