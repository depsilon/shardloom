# Follow-up evidence: branch provenance, failed jobs, and dependency contracts

Read-only addendum for the initial GitHub intake. Branch-specific PR lists used the GitHub pulls endpoint filtered by exact head and state=all, with pagination enabled. No repository or GitHub state was changed.

## Exact provenance for the 39 diverged tips

All 39 returned current tips have one exact SHA-matched PR head. Of those, 37 are closed and merged; the other two are the open Dependabot PRs #1513 and #1553. There were no exact-tip closed-unmerged or unmatched branches. The full table includes branch SHA, PR number, state, merged_at, closed_at, and merge_commit_sha in [diverged-branch-pr-provenance.md](diverged-branch-pr-provenance.md); machine-readable all-results and each raw paginated API response are in [diverged-branch-pr-provenance.json](diverged-branch-pr-provenance.json) and `branch-prs/`.

The merge commit SHA differs from the source branch tip for merged PRs, consistent with squash/rebase merges; source-tip exact-match plus merged_at and merge_commit_sha provides direct provenance for current heads. The two open entries are #1513 (head `9ceab1dc267aa8b7d6a1ca88e704fdb900d745bb`) and #1553 (head `689b35cea3372f292eacc3f0cb14d13d03e499e9`).

## Failed-job log evidence

Raw logs were retrieved from the four identified failed jobs and saved locally. Exact excerpts with source log line anchors are in [failed-job-excerpts.txt](failed-job-excerpts.txt).

- PR #1553 dependency/security, job `116197675804`: log lines 4321–4338 run `scripts/check_security_posture.py` and exit 1. Downloaded artifact `pr-1553-dependency-security-artifacts/security-posture-report.json` identifies the sole failed predicate: `scorecard_workflow.missing = ["ossf/scorecard-action@v2.4.4"]` (JSON lines 38–42); all other posture checks pass. The accompanying `dependency-audit-report.json` records cargo audit, cargo deny, advisory, license, and pip audit checks as passed. This is a stale exact-version contract following the PR's Scorecard action bump.
- PR #1553 release_scripts, job `116197675541`: raw log lines 262–270 show `test_security_posture_accepts_current_privileged_workflows` failing because `scorecard_workflow` expects `ossf/scorecard-action@v2.4.4`, which is absent after the proposed workflow update.
- PR #1513 release_user_surfaces, job `117413083766`: raw log lines 1801–1827 report multiple `arrow_array` versions (60.0.0 and 59.3.1) and that `ArrowReader<std::fs::File>` does not implement the expected `RecordBatchReader`; line 1848 reports `shardloom-vortex` failed after 45 errors.
- PR #1513 MSRV, job `117413083621`: raw log lines 3326–3345 show Arrow `DataType` mismatch and multiple `arrow_schema` versions (59.3.1 versus 60.0.0); lines 3843–3853 show Vortex's Arrow 58.4.0 type versus Arrow 60.0.0; line 3934 reports 96 lib-test errors. The error cluster is a split Arrow type graph across the update set, not an MSRV-only API issue.

## Current pin and version contract locations

### GitHub Actions update set

| Action repository | Current workflow locations / refs | Current checker or documentation contract |
|---|---|---|
| `actions/upload-artifact` | `.github/workflows/ci.yml` (14 `@v7` pins; e.g. lines 55, 209, 234, 275) and `.github/workflows/pypi-publish-draft.yml` (three pins at lines 139, 149, 160), digest `043fb46d1a93c77aae656e7c1c64a875d1fc6a0a`; PR updates 7.0.1→7.0.2 | `scripts/check_security_posture.py` verifies SHA pin shape for PyPI workflow only; tests cover pin-shape, not exact version. No exact 7.0.1 contract found. |
| `actions/download-artifact` | `.github/workflows/ci.yml` (14 `@v8` pins) and `.github/workflows/pypi-publish-draft.yml` (two pins at lines 176, 263), digest `3e5f45b2cfb9172054b4087a40e8e0b5a5461e7c`; PR updates 8.0.1→8.0.2 | `scripts/check_pre_5j_dependency_freshness.py:51–59` requires `@v8`, forbids `@v7`, expects 14 markers; `scripts/check_ci_gate_matrix.py:153,263,326,418` has `@v8` markers. These pin the major, not patch version. |
| `actions/setup-node` | `.github/workflows/ci.yml:842`, digest `820762786026740c76f36085b0efc47a31fe5020`; PR updates 7.0.0→7.1.0 | `docs/dependencies/github-actions-dependency-review.md:41–42` records exact 7.0.0 and digest. No exact version test found. |
| `github/codeql-action` | `.github/workflows/codeql-analysis.yml:32,38` and `.github/workflows/scorecard.yml:30`, digest `1c5b675653bb5c22dbe9b12b556ec555138e09fd`; PR updates 4.38.1→4.38.3 | `scripts/check_security_posture.py:95–109,111–123` requires `@v4` and SHA pins; `python/tests/test_release_scripts.py:4857–4883` tests SHA pin shape and posture acceptance. `docs/dependencies/github-actions-dependency-review.md:29–34` records the prior digest `cdf488f595d80d6e07e03d4674febd5ab45fa938` and only the major label. No exact patch version predicate found. |
| `ossf/scorecard-action` | `.github/workflows/scorecard.yml:24`, digest `2d1146689b8cda280b9bc96326124645441f03bc`; PR updates 2.4.4→2.5.0 | `scripts/check_security_posture.py:111–123` requires exact string `ossf/scorecard-action@v2.4.4`; `python/tests/test_release_scripts.py:4874–4883` runs this check. `docs/dependencies/github-actions-dependency-review.md:35–36` records 2.4.4 and the old digest. This exact version contract directly causes both #1553 failures. |

The PR changes four workflow files: `.github/workflows/ci.yml`, `codeql-analysis.yml`, `pypi-publish-draft.yml`, and `scorecard.yml`. Action comments in changed workflows carry version labels alongside full SHA pins. The security-posture checker enforces pin format and workflow structure; only Scorecard currently has a patch-version literal.

### Structured-format stack

- Direct Arrow and Parquet version authority: root `Cargo.toml` pins `arrow-array` 58.3.0 at line 38, `arrow-avro` at 39, `arrow-ipc` at 40, `arrow-pyarrow` exactly 58.3.0 at 41, `arrow-schema` at 42, and `parquet` at 47. The PR updates arrow-array/avro/ipc/schema and parquet; arrow-pyarrow remains 58.3.0.
- ORC direct constraints: `shardloom-cli/Cargo.toml:53` uses `orc-rust = 0.8.0` in dev dependencies; `shardloom-vortex/Cargo.toml:55` uses it as an optional runtime dependency. Workspace Arrow references are at `shardloom-cli/Cargo.toml:50–54` and `shardloom-vortex/Cargo.toml:48–56`. `Cargo.lock` resolves arrow-array at line 133, arrow-avro 152, arrow-ipc 235, arrow-pyarrow 289, arrow-schema 312, parquet 2109 (all 58.3.0), and orc-rust 2048 (0.8.0).
- Dependabot grouping: `.github/dependabot.yml:15–19` batches `arrow-*`, `parquet`, and `orc-rust` as `structured-format-stack`.
- Architectural compatibility contract: `docs/dependencies/structured-format-dependency-review.md:10–38` explicitly says Vortex 0.85 and orc-rust 0.8 require Arrow 58-compatible boundaries, defers Arrow/Parquet 59+ pending provider alignment/no-regression proof, and requests reviewing this grouped update once. `docs/dependencies/vortex-upstream-review.md:710–718` repeats the current structured-format versions and Arrow 58 compatibility requirement.
- No exact-version test for this stack surfaced in `python/tests` or scripts. Compile gates expose incompatibilities through the Cargo graph; #1513's feature and MSRV logs show the resulting duplicate-type errors. `python/tests/test_release_scripts.py` checks general workflow/security-posture behavior, not these crate version values.

The stale-action documentation/contract candidates are `scripts/check_security_posture.py`, its posture integration test, and the action dependency-review ledger. Any structured-format intake would also have to reconcile the existing compatibility rationale in `docs/dependencies/structured-format-dependency-review.md` with the new feature-gate evidence; this packet makes no recommendation or change.
