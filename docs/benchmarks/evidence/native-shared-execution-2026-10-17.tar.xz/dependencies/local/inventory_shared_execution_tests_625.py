import ast,hashlib,json,re,subprocess
from pathlib import Path
R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo');O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
call=lambda *args:subprocess.check_output(['git',*args],cwd=R,text=True).strip()
files=set(call('diff','--name-only','HEAD','--','*.rs').splitlines())|set(call('ls-files','--others','--exclude-standard','--','*.rs').splitlines())
pattern=re.compile(r'(?m)^\s*#\[test\]\s*(?:#\[[^\n]+\][^\n]*\n\s*)*fn\s+(\w+)\s*\(')
all_new=[]
for name in sorted(files):
 raw=(R/name).read_text()
 shown=subprocess.run(['git','show','HEAD:'+name],cwd=R,text=True,capture_output=True)
 old=shown.stdout if shown.returncode==0 else ''
 oldnames={m.group(1) for m in pattern.finditer(old)}
 for match in pattern.finditer(raw):
  test=match.group(1)
  if test in oldnames:continue
  line=raw[:raw.index('fn '+test+'(',match.start())].count('\n')+1
  all_new.append(dict(path=name,name=test,line=line,source_sha256=hashlib.sha256(raw.encode()).hexdigest()))
assert len(all_new)==12,all_new
log=(O/'native-shared-execution-native-gates-624.log').read_text()
for row in all_new:
 seen=re.findall(r'^test (.*::'+re.escape(row['name'])+r') \.\.\. ok$',log,re.M)
 assert len(seen)==1,row
 row['local_observed_test_path']=seen[0]
binding_paths=sorted((R/'python/tests').glob('test_native*binding.py'))
binding_count=sum(sum(isinstance(n,ast.FunctionDef) and n.name.startswith('test_') for n in ast.walk(ast.parse(p.read_text()))) for p in binding_paths)
release=R/'python/tests/test_release_scripts.py'
release_names=[n.name for n in ast.walk(ast.parse(release.read_text())) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
assert binding_count==100 and len(release_names)==164
report=dict(status='passed',base=call('rev-parse','HEAD'),native_new_tests=all_new,new_native_test_count=12,
            native_binding_method_count=binding_count,release_script_methods=release_names,
            native_suite_passed=2958,native_ignored=27,
            count_scope='Exact source inventory and observed newly added native methods; not additional test executions.')
target=O/'native-shared-execution-test-inventory-625.json';target.open('x').write(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(status='passed',new_native_tests=len(all_new),binding_methods=binding_count,release_methods=len(release_names))))

