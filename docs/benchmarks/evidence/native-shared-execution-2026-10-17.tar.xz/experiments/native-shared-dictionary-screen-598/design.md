<!-- SPDX-License-Identifier: Apache-2.0 -->

# Shared execution optimization after native text reconstruction

Status: implementation and measurement in progress under PERF-01/04/05/10.
The maintainer requests another material whole-workload improvement, with generic
runtime admission and complete validation through merge. The accepted starting
tree is PR #1567, merged at `5bcee25a`; its matched 43-query sum of per-query
two-sample means is 58.1389694790 engine seconds. A new comparison must measure
that accepted runtime again, rather than compare an unrelated later observation
with the historical number. All whole PERF owners and CG-1 through CG-23 remain
open, and immutable 0.6.0 packages are unchanged.

The expert comparator is an encoded-columnar maintainer checking physical work,
complete key equality, first-seen identities, native owner lifetimes, allocation
admission and measured complete-query cost. The ordinary SQL, Python, DataFrame
and CLI routes continue to share the same native execution families.

## Attribution and first mechanism

Nine serial diagnostic samples execute the accepted native binary for Q19,
Q23, Q29, Q34, Q35, Q10, Q16, Q28 and Q33. All complete results pass, all 2,411
selected source files match the accepted build, and the existing supervisor
reaps its children. Sampling is attribution only. In the Q29 sample,
`Utf8ChunkDictionary::intern_source` has 428 top-of-stack samples, alongside
native decompression, validation and domain parsing. Q19 also exercises that
shared dictionary and persistent partition-table growth. Counts across threads
or nested stacks do not establish exclusive stage timings or a speedup.

The first candidate changes only the shared chunk dictionary's lookup directory.
Its existing scalar linear probe stores a full cached hash and first-seen ID in
each bucket. Use the already pinned, permissively licensed `hashbrown` 0.17.1
`HashTable` to probe compact control groups before loading candidate entries.
Keep the full cached hash and exact byte equality in the equality closure;
control tags or hash equality never prove string identity. Growth continues to
reuse cached hashes without reading all value bytes again. Keep `FxHasher`,
stable IDs, the existing native values vector, miss-only ownership retention and
independent promotion of escaping strings. This introduces no dependency,
provider, encoding, query-name rule, new execution route or unsafe workspace code.

Use only safe table APIs. Reserve fallibly before insertion. Bounded preparation
workers reserve for the maximum row cardinality before starting and must not
grow during insertion. Their conservative allocation bound includes table
buckets, control/alignment storage, values, row IDs and null flags; check the
actual table allocation against that bound. This is container admission, not an
allocator-wide or RSS limit. The global interner's capacity policy and persistent
partition tables are unchanged. The earlier dropped dictionary-binding capacity
experiment and triple-sort replacement therefore remain dropped.

Vortex-first decision: `implement_shardloom_kernel` inside the existing chunk
dictionary consumer. Pinned Vortex 0.85 native views, validity and buffer owners
remain the source provider. Its dictionary representation does not replace this
consumer's first-seen content identities for canonical native text. Existing
feature gates, execution/Native I/O certificates and materialization boundaries
remain; `fallback_attempted=false` and `external_engine_invoked=false` are required.
The [safe hash table API](https://docs.rs/hashbrown/0.17.1/hashbrown/struct.HashTable.html)
and the exact pinned local source define lookup, fallible reservation, cached
rehashing and allocation-size inspection. No external implementation is copied.

Reuse map: `Utf8ChunkDictionary` feeds
`aggregate_utf8_accessor_from_canonical` in both ordinary aggregate preparation
and `DictionaryPrepareWorkers`. That accessor is already shared by grouped
COUNT, numeric/text keys, transformed dictionaries, DISTINCT and extrema.
No caller-specific directory or alternative array representation is added.
PulseWeave, capillary units and dynamic work admission keep their existing
grants. Metadata/pruning and encoded providers still run before this canonical
text boundary; late materialization and evidence-tier controls are unchanged.

## Acceptance and retain/drop rule

Prove exact IDs through complete hash collisions, duplicate and unique values,
empty/Unicode/NUL text, first-seen ordering, malformed UTF-8 rejection, failed
retention without publication, source-owner release and unchanged escaping
ownership. Check bounded table allocation across capacity boundaries and no
growth in row-bounded workers. Preserve existing nullable, cancellation,
one-worker/multi-worker and decoded-reference fixtures.

Each retained mechanism needs focused correctness and a frozen, unprofiled
complete-operation comparison. Preserve every attempt, failed gate and slower
sample. Related mechanisms may form one coherent batch, but individual focused
gains are not added into a whole-workload claim.

Final material acceptance uses the existing paired runner with all 43 queries,
two executions per query per build, counterbalanced ABBA/BAAB order, the same
resident native input, resource policy and complete results/schemas. The primary
score is the sum of per-query means of `engine_execution_seconds`. Require at
least 5% lower total, improvement in both paired totals, and no query whose mean
increase exceeds the larger of 10% and 0.15 engine seconds while both paired
deltas are positive. A smaller or inconsistent result requires a changed
mechanism or a drop, without changing that frozen rule. Retain all other clocks
and resource observations separately as diagnostics. No pacing, cache purge,
automatic retry or best-sample replacement is permitted.

At the batch boundary, run required workspace/native gates, direct bindings,
public workflow and format/oracle coverage, align documentation and generated
site content, and complete PR checks, final-head review, installed wheels and
production verification. Existing storage, workload and process-cleanup guards
remain required. No new benchmark/search framework or package release belongs
to this batch.
