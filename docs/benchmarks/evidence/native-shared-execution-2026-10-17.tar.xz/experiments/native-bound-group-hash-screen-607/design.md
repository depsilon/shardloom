<!-- SPDX-License-Identifier: Apache-2.0 -->

# Shared execution optimization after native text reconstruction

Status: implementation and measurement in progress under PERF-01/04/05/10.
The maintainer requests another material whole-workload improvement, with generic
runtime admission and complete validation through merge. The accepted starting
tree is PR #1567, merged at `5bcee25a`; its matched 43-query sum of per-query
two-sample means is 58.1389694790 engine seconds. A new comparison must measure
that accepted runtime again, rather than compare an unrelated later observation
with the historical number. All whole PERF owners and CG-1 through CG-23 remain
open, and immutable 0.6.0 packages are unchanged.

The expert comparator is an encoded-columnar maintainer checking physical work,
complete key equality, first-seen identities, native owner lifetimes, allocation
admission and measured complete-query cost. The ordinary SQL, Python, DataFrame
and CLI routes continue to share the same native execution families.

## Attribution and dropped directory screen

Nine serial diagnostic samples execute the accepted native binary for Q19,
Q23, Q29, Q34, Q35, Q10, Q16, Q28 and Q33. All complete results pass, all 2,411
selected source files match the accepted build, and the existing supervisor
reaps its children. Sampling is attribution only. In the Q29 sample,
`Utf8ChunkDictionary::intern_source` has 428 top-of-stack samples, alongside
native decompression, validation and domain parsing. Q19 also exercises that
shared dictionary and persistent partition-table growth. Counts across threads
or nested stacks do not establish exclusive stage timings or a speedup.

The first candidate replaced the shared chunk dictionary's scalar probe with
the already pinned `hashbrown` 0.17.1 `HashTable`. It retained cached full hashes,
exact byte equality, stable first-seen IDs, miss-only ownership and bounded
fallible allocation. Seven focused tests and all 48 complete public calls passed.
The frozen two-target sum of five-sample engine means increased from
10.3804950924 to 10.4340839922 seconds (0.5162% slower). Q19 improved in only
three of five pairs and Q29 in one of five; the 2% combined gain and four-positive
pairs per target requirements failed. The directory replacement is dropped.
Every source patch, build, sample, control, schema and failed gate is retained.
Single-worker and control observations do not override the failed target gate.

## Bind native access at the loop boundary

The same profiles show repeated typed access in text consumers and numeric
grouping. Q10/Q16 exercise `aggregate_direct_integer_key_part`, integer-width
getters and `NativeNumericOwner::integer_key`; Q34 also exposes erased-array
`as_any` calls. These are attribution signals, not accepted speedup measurements.

Vortex-first decision: reuse pinned Vortex 0.85 `Array::as_view`, `ArrayView`,
`VarBinViewData` and `VarBinViewArrayExt`. The owned array's data access performs
an erased-array downcast; its borrowed typed view already stores the checked
data reference. Bind that view once around dictionary preparation, plain text
counting, dictionary hashing, exact merge visits and DISTINCT union. Bind the
partial's native data once for partition reconciliation. No copied buffer table,
new array owner, alternate encoding or unchecked UTF-8 construction is needed.
Checked text access still uses the original provider receipt or validates a
generic builder's selected bytes. Native value retention and independent
promotion of escaping keys remain unchanged.

For single-integer grouped counting, reuse
`aggregate_direct_integer_key_slice` and its original-width typed iterator.
Move width selection outside the row loop, including explicit selections, and
reuse the same shared iterator for existing numeric/text consumers. Materialized
keys keep their existing row-checked path; nullable and unsupported admission,
signed/unsigned identity, exact counts, overflow and partial failure order remain.
There is no value-column copy, transformed-key rule or query-specific condition.

The complete 70-call screen passes every value and schema check. Numeric targets
Q10/Q16 reduce their sum of five-sample engine means from 5.1272616510 to
3.7355836432 seconds (27.14%), with all five paired totals improved; this binding
is retained for the batch. The text family increases from 23.2545347217 to
23.4655935560 seconds (0.91% slower) and fails its frozen 2% family gate. Remove
the text binding changes and retain their source, tests, calls and failed gate.
Single-worker observations do not override that decision. The exact mixed
candidate is not accepted, despite its seven-target combined gain of 4.16%.

## Compact complete numeric-pair records

The accepted Q33 profile attributes substantial work to complete-partition pair
sorting. The existing generic reducer retains two u64 value fields plus two
signedness bits in a naturally padded 24-byte key. The earlier
[complete-pair design](q33-exact-partition-reduction-2026-09-19.md) identifies
this storage cost; no prior compact-record comparison is reused as proof.

Test a 17-byte internal record containing the kind byte followed by both value
fields in big-endian order. Bytewise ordering must exactly equal the existing
`(key_kinds, first_bits, second_bits)` tuple order; full-key equality and final
signed result ordering remain unchanged. Store the complete kind byte per row:
the current worker accepts changes in integer width or signedness between
chunks and must not collapse distinct signed and unsigned keys. Reconstruct
the existing key only for routing or complete-group candidate selection.

Vortex-first decision: `implement_shardloom_kernel` within the existing shared
pair reducer. Pinned Vortex 0.85 primitive slices, validity, scan and session
providers stay in use. Vortex's crate-private fixed-width structural take/filter
trait is not an aggregate COUNT-ranked reconciliation provider. This internal
leased record changes no input array, persisted encoding or provider boundary.
Reuse the current 64 partitions, native unstable sort, jobs, sampling, admission,
late-measure pass and comparator; no new sort implementation, dependency,
unsafe access, query condition or alternate execution route is introduced.

Charge staging, persistent capacity and old-plus-new growth overlap using the
actual compact record size. Preserve cancellation, committed-denial failure,
lease lifetime, sample decline and same-source provider restoration. Prove
round-trip and tuple-order equivalence over all signedness combinations,
extremes and deterministic varied bits; compare mixed-width/mixed-sign chunks
with native serial results and verify exact memory charge and denial cleanup.
The focused retain gate requires at least 5% lower Q33 mean engine time and
four of five positive pairs, plus unchanged controls and independent numeric
binding revalidation. The final 5% whole-workload gate below is unchanged.

The complete 46-call screen passes values, schemas and its frozen gates. Q33
improves by 5.21% with five of five positive pairs; the single-worker control
also passes. Q10/Q16 retain 22.39% and 31.60% improvements over the accepted
baseline, with three of three positive pairs each. Retain both mechanisms for
the batch. These targeted observations do not establish a whole-workload gain.

## Bind group identities in the existing typed aggregate block

The accepted Q28 diagnostic attributes repeated work to
`grouped_key_for_direct_row`, `NativeNumericOwner::distinct_value` and group
metadata lookup while the existing AVG/COUNT block already binds measure type
and validity once. Test binding the admitted single integer group owner at that
same block boundary, retaining its original-width slice and validity mask.
Reuse the ordinary single-key identity and the existing shared group-state
insertion/update routine. A borrowed row-value kernel avoids re-reading group
metadata or re-downcasting the native array for each row. It must not cache
cross-block data, copy a value column or construct a parallel aggregate state.

Vortex-first decision: wrap the already admitted Vortex 0.85 primitive-slice
and mask providers inside `NativeNumericOwner`. The existing numeric block's
shape, lengths, measure order, nullable grouping, first-seen limits, HAVING,
failure order and evidence counters remain unchanged. Do not introduce a new
query route, query name, field name, dtype restriction or dependency. A single
small block-local borrowed closure follows the existing bound numeric kernels.

Compare complete calls with the retained compact-pair build as control so this
mechanism has independent attribution. Freeze Q28 at five pairs with an 8%
mean engine reduction and at least four positive pairs, plus two single-worker
pairs and unchanged-path controls. Preserve the existing 10%/0.15-second control,
CPU and RSS checks and every slower observation. At least the current focused
matrix must prove all original group widths, signed/unsigned extremes, native
validity/slices, reordered/duplicate selections, closed first-seen limits,
cross-block type changes and identical partial state on errors.

The complete 50-call screen passes every value and schema check. Q28 improves
by 29.84% with five positive pairs, and its single-worker control improves by
29.74%. However, unchanged-path Q10 increases from 2.0945095835 to
2.3091059380 mean engine seconds, exceeding the frozen 10%/0.15-second control
limit; both paired observations are slower. The complete candidate is dropped,
including its group binding code and tests; their frozen patch and evidence remain. No explanation
for that control difference is established, and the successful target does not
override the failed acceptance gate. All 2,411 selected source identities are
restored to the previously retained numeric-binding/compact-pair build.

## Store occupied string counts densely

The accepted Q34/Q35 profiles place substantial samples in canonical string
partial counting, zero initialization and the final occupied-entry compaction.
Test a dense first-seen vector of the existing `CountSlot<W>` records, with a
temporary `hashbrown::HashTable<W>` directory containing only vector ordinals.
Retain the existing native values owner, complete cached hashes and exact byte
equality; validate new UTF-8 keys before publication. Do not copy string payloads
or construct per-row dictionary IDs. Native Dict and Constant kernels stay intact.

Vortex-first decision: `implement_shardloom_kernel` inside the existing shared
string-count partial. Vortex 0.85 VarBinView, validity, execution-session and
encoded Dict providers remain the input boundaries; none provides this admitted
exact aggregate partial and its coordinator contract. Reuse the already pinned
hashbrown 0.17.1 public fallible reserve/find/insert APIs, with no dependency
change or copied implementation. The existing partition reducer, complete-key
merge, pressure handling and late output remain shared.

Keep the original `partial_bytes` admission and held lease. Before allocation,
bound dense records plus directory within that reservation. The directory bound
uses at least 16 buckets and the existing twice-row power-of-two bound, one
control byte per bucket, and 32 bytes for alignment/control suffix. This safely
exceeds the pinned provider's maximum 16-byte control groups and 7/8 load policy
for u32/u64 ordinals. Check actual reserved capacity/allocation size afterward.
If the combined bound does not fit for a small chunk, use the existing sparse
kernel before doing any count work. Both allocations are fallible and fully
pre-reserved; insertion cannot grow. Release the directory before handing off
the partial, but keep the original conservative capacity charge through merge.

Prove compact/wide equivalence, forced complete-hash collisions, Unicode/NUL and
empty keys, first-seen order after partitioning, capacity-bound edges, cancellation,
allocation denial and checked work-counter failure. Compare complete operations
against the retained numeric-binding/compact-pair build. Freeze five pairs each
for Q34/Q35: require at least 5% lower combined target engine mean, at least four
positive pairs for each target, and no target mean regression. Add two pairs each
for Q34/Q35 at one worker and unchanged-path controls Q2/Q10/Q16/Q19/Q23/Q28/Q29/Q33.
The existing 10%/0.15-engine-second control limit applies to all controls;
target CPU and every case's RSS retain their existing limits. Preserve every
failed/slower observation; the final whole-workload 5% gate remains unchanged.

The complete 60-call screen passes all results and schemas but fails retention.
The combined Q34/Q35 mean improves by 4.21%, below 5%; Q35 improves in only three
of five pairs. Q10's mean increases by 17.27%, exceeding its unchanged-path
control limit. All CPU/RSS checks pass. The candidate code and tests are removed;
its frozen source patch, design, binary and every measurement remain retained.
The repeated Q10 control difference requires investigation before another
candidate; no causal explanation or whole-workload improvement is established.

The follow-up inspection finds no differences in the recorded non-clock Q10
runtime fields, build command, package features, compiler profiles or dependency
artifacts. Three inspected numeric access functions have identical normalized
instruction sequences; the fourth differs in two constant-address offsets. This
limited inspection does not prove equivalent generated programs or identify a
timing cause. Both failed candidates remain dropped; no measurement is discarded
or reclassified as environmental noise.

## Keep integer group identity outside count-map entries

The next coherent numeric-group candidate changes the shared count table itself.
The current `(u64, bool)` key occupies 16 bytes; together with its u64 count,
each occupied entry requires 24 bytes before the existing hash-table overhead.
Separate signed and unsigned maps retain the same exact identity with a u64 key
and u64 count per entry. Bind the map once for an original-width native slice;
mixed materialized keys select their map explicitly. Preserve complete signed
and unsigned domains, checked counts, fallible growth, generic demotion, exact
winner selection and the existing admission boundaries. Per-key storage estimates
must describe the new representation without claiming allocator or RSS coverage.

This changed count-table mechanism is measured together with typed group binding
in the existing AVG/COUNT block. The prior group-binding candidate remains a
failed standalone observation; it is not reused as acceptance evidence. There
are no column names, values or query numbers in runtime admission. Row/measure
order, nullable semantics, source-order limits and partial failure state remain
unchanged. Native slices remain borrowed from their original Vortex owners.

Vortex-first decision: `implement_shardloom_kernel` in the existing native
aggregate state and numeric block. Pinned Vortex 0.85 primitive arrays, validity,
scan and execution-session providers remain the input boundary. Upstream array
providers do not supply ShardLoom's persistent count-ranked group state, mixed
signed-domain identity or late-measure winner contract. Reuse the existing
`FxHashMap`, fallible reservation helper, count workers and candidate comparator;
add no dependency, unsafe code, array copy or external executor.

Before execution, freeze five counterbalanced pairs each for Q10/Q16/Q28 at
twelve workers. Require at least 8% lower sum of their mean engine times, no
individual target mean regression and at least four positive pairs per target.
Q10 therefore receives five pairs and a stricter nonregression gate in this new
mechanism. Run two pairs per target at one worker and two pairs for unchanged
Q2/Q9/Q19/Q23/Q29/Q33/Q34/Q35 at twelve workers. All controls retain the existing
10%/0.15-engine-second limit; target CPU and all RSS limits are unchanged. Every
value, schema, native-provider and no-fallback check must pass. The final
whole-workload 5% rule below remains unchanged.

The complete 74-call screen passes every value and schema check but fails
retention. Combined target engine time improves by 12.44%; Q16 and Q28 improve
by 5.22% and 27.82%, respectively, in all five pairs. Q10 is nearly unchanged
(0.08% lower mean) and improves in only three pairs. Q34 and Q35 controls regress
by 17.22% and 11.94%, with both pairs slower. All CPU/RSS gates pass. Drop this
complete candidate, preserving its source, design, binary and all measurements.
The prepared Full43 comparison is not run. No whole-workload improvement is
established. Further work must change the mechanism; the existing aggregate
state representation is restored before another candidate is designed.

## Bind group preparation without changing aggregate-state layout

The next candidate preserves the existing single numeric count map, complete
`(bits, signed)` key, and aggregate-state field layout. Its internal hash folds
signedness into one u64 before invoking the pinned `rustc-hash` 2.1.3 hasher.
Unsigned bits pass unchanged; signed bits are XORed with one fixed domain tag.
Within each domain this is bijective. Cross-domain hash collisions remain
possible and must use complete key equality; this hash is neither persisted
nor an identity. Result ranking continues to use the explicit full-key
comparator. Test deliberate equal-hash pairs through counting, worker merge,
overflow, generic demotion and bounded ordered results.

Bind the integer group owner in the admitted AVG/COUNT block, but replace the
previous optional bound-key parameter with a generic key-preparation closure.
The ordinary path supplies its existing key/value preparation; the numeric
block supplies its borrowed typed key getter. Both instantiate the same group
admission and state-update body, with no runtime optional-key dispatch or
aggregate-state field added. Preserve nullable grouping, row/measure order,
closed first-seen limits, error ordering, chunk ownership and work counters.
The earlier failed group-binding and two-map candidates remain rejected.

Vortex-first decision: wrap the existing Vortex 0.85 primitive-slice and mask
providers for block-local access. ShardLoom still owns exact aggregate hashing,
group admission and result ranking. No upstream query-engine integration,
dependency, new input representation, column-sized copy or unsafe code is used.
The pinned hasher source confirms one arithmetic update per u64 write on the
local 64-bit target; its existing provider handles 32-bit targets normally.
No timing cause is inferred from the earlier control failures.

Freeze five counterbalanced pairs for Q16/Q28 at twelve workers, requiring an
8% reduction in their combined mean engine time, no individual mean regression
and at least four positive pairs per target. Their single-worker controls use
two pairs. Q10 uses the separate mixed-DISTINCT state, not the changed count-map
key; it is an unchanged-path control in this candidate, as are Q34/Q35. Give
each of these three controls five pairs, retaining the existing 10%/0.15-engine-
second limit. Q2/Q9/Q19/Q23/Q29/Q33 receive two control pairs. All 82 complete
calls must pass values, schemas, native-provider and no-fallback checks; target
CPU and all RSS gates remain. The independent 5% Full43 acceptance gate below
does not change. Preserve every sample, including failed/slower observations.

The focused suite passes 108 tests, including deliberately colliding signed and
unsigned keys, worker-weight failure order, generic demotion, ordered offsets,
all original integer widths, nullable and sliced groups, selected row order and
cross-block signed identity. Strict library Clippy and formatting checks pass.
The release source is frozen before the complete-operation screen; no measured
performance result is established by these correctness checks.

The feature gates, execution/Native I/O certificates and materialization
boundaries remain; `fallback_attempted=false` and `external_engine_invoked=false`
are required. PulseWeave, capillary units and dynamic admission keep their
existing grants. Metadata/pruning and encoded providers still run before these
canonical boundaries. Late materialization and evidence-tier controls remain.
The earlier dropped capacity and triple-sort experiments remain dropped.

## Acceptance and retain/drop rule

Prove borrowed typed access against owned native access for selected multi-buffer
inline/outlined, Unicode, NUL and empty text. Preserve exact IDs, hash-collision
checks, malformed UTF-8 rejection, source-owner release and escaping ownership.
Check original integer widths and extremes, signed/unsigned identity, reordered
and duplicate selections, empty input, nullable rejection, materialized selected
keys, mid-selection bounds errors and exact partial state on count overflow.
Retain compact/wide partial equivalence, cancellation, one/multi-worker and
decoded-reference fixtures.

Each retained mechanism needs focused correctness and a frozen, unprofiled
complete-operation comparison. Preserve every attempt, failed gate and slower
sample. Related mechanisms may form one coherent batch, but individual focused
gains are not added into a whole-workload claim.

Final material acceptance uses the existing paired runner with all 43 queries,
two executions per query per build, counterbalanced ABBA/BAAB order, the same
resident native input, resource policy and complete results/schemas. The primary
score is the sum of per-query means of `engine_execution_seconds`. Require at
least 5% lower total, improvement in both paired totals, and no query whose mean
increase exceeds the larger of 10% and 0.15 engine seconds while both paired
deltas are positive. A smaller or inconsistent result requires a changed
mechanism or a drop, without changing that frozen rule. Retain all other clocks
and resource observations separately as diagnostics. No pacing, cache purge,
automatic retry or best-sample replacement is permitted.

At the batch boundary, run required workspace/native gates, direct bindings,
public workflow and format/oracle coverage, align documentation and generated
site content, and complete PR checks, final-head review, installed wheels and
production verification. Existing storage, workload and process-cleanup guards
remain required. No new benchmark/search framework or package release belongs
to this batch.
