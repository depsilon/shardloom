<!-- SPDX-License-Identifier: Apache-2.0 -->

# Shared execution optimization after native text reconstruction

Status: implementation and measurement in progress under PERF-01/04/05/10.
The maintainer requests another material whole-workload improvement, with generic
runtime admission and complete validation through merge. The accepted starting
tree is PR #1567, merged at `5bcee25a`; its matched 43-query sum of per-query
two-sample means is 58.1389694790 engine seconds. A new comparison must measure
that accepted runtime again, rather than compare an unrelated later observation
with the historical number. All whole PERF owners and CG-1 through CG-23 remain
open, and immutable 0.6.0 packages are unchanged.

The expert comparator is an encoded-columnar maintainer checking physical work,
complete key equality, first-seen identities, native owner lifetimes, allocation
admission and measured complete-query cost. The ordinary SQL, Python, DataFrame
and CLI routes continue to share the same native execution families.

## Attribution and dropped directory screen

Nine serial diagnostic samples execute the accepted native binary for Q19,
Q23, Q29, Q34, Q35, Q10, Q16, Q28 and Q33. All complete results pass, all 2,411
selected source files match the accepted build, and the existing supervisor
reaps its children. Sampling is attribution only. In the Q29 sample,
`Utf8ChunkDictionary::intern_source` has 428 top-of-stack samples, alongside
native decompression, validation and domain parsing. Q19 also exercises that
shared dictionary and persistent partition-table growth. Counts across threads
or nested stacks do not establish exclusive stage timings or a speedup.

The first candidate replaced the shared chunk dictionary's scalar probe with
the already pinned `hashbrown` 0.17.1 `HashTable`. It retained cached full hashes,
exact byte equality, stable first-seen IDs, miss-only ownership and bounded
fallible allocation. Seven focused tests and all 48 complete public calls passed.
The frozen two-target sum of five-sample engine means increased from
10.3804950924 to 10.4340839922 seconds (0.5162% slower). Q19 improved in only
three of five pairs and Q29 in one of five; the 2% combined gain and four-positive
pairs per target requirements failed. The directory replacement is dropped.
Every source patch, build, sample, control, schema and failed gate is retained.
Single-worker and control observations do not override the failed target gate.

## Bind native access at the loop boundary

The same profiles show repeated typed access in text consumers and numeric
grouping. Q10/Q16 exercise `aggregate_direct_integer_key_part`, integer-width
getters and `NativeNumericOwner::integer_key`; Q34 also exposes erased-array
`as_any` calls. These are attribution signals, not accepted speedup measurements.

Vortex-first decision: reuse pinned Vortex 0.85 `Array::as_view`, `ArrayView`,
`VarBinViewData` and `VarBinViewArrayExt`. The owned array's data access performs
an erased-array downcast; its borrowed typed view already stores the checked
data reference. Bind that view once around dictionary preparation, plain text
counting, dictionary hashing, exact merge visits and DISTINCT union. Bind the
partial's native data once for partition reconciliation. No copied buffer table,
new array owner, alternate encoding or unchecked UTF-8 construction is needed.
Checked text access still uses the original provider receipt or validates a
generic builder's selected bytes. Native value retention and independent
promotion of escaping keys remain unchanged.

For single-integer grouped counting, reuse
`aggregate_direct_integer_key_slice` and its original-width typed iterator.
Move width selection outside the row loop, including explicit selections, and
reuse the same shared iterator for existing numeric/text consumers. Materialized
keys keep their existing row-checked path; nullable and unsupported admission,
signed/unsigned identity, exact counts, overflow and partial failure order remain.
There is no value-column copy, transformed-key rule or query-specific condition.

The feature gates, execution/Native I/O certificates and materialization
boundaries remain; `fallback_attempted=false` and `external_engine_invoked=false`
are required. PulseWeave, capillary units and dynamic admission keep their
existing grants. Metadata/pruning and encoded providers still run before these
canonical boundaries. Late materialization and evidence-tier controls remain.
The earlier dropped capacity and triple-sort experiments remain dropped.

## Acceptance and retain/drop rule

Prove borrowed typed access against owned native access for selected multi-buffer
inline/outlined, Unicode, NUL and empty text. Preserve exact IDs, hash-collision
checks, malformed UTF-8 rejection, source-owner release and escaping ownership.
Check original integer widths and extremes, signed/unsigned identity, reordered
and duplicate selections, empty input, nullable rejection, materialized selected
keys, mid-selection bounds errors and exact partial state on count overflow.
Retain compact/wide partial equivalence, cancellation, one/multi-worker and
decoded-reference fixtures.

Each retained mechanism needs focused correctness and a frozen, unprofiled
complete-operation comparison. Preserve every attempt, failed gate and slower
sample. Related mechanisms may form one coherent batch, but individual focused
gains are not added into a whole-workload claim.

Final material acceptance uses the existing paired runner with all 43 queries,
two executions per query per build, counterbalanced ABBA/BAAB order, the same
resident native input, resource policy and complete results/schemas. The primary
score is the sum of per-query means of `engine_execution_seconds`. Require at
least 5% lower total, improvement in both paired totals, and no query whose mean
increase exceeds the larger of 10% and 0.15 engine seconds while both paired
deltas are positive. A smaller or inconsistent result requires a changed
mechanism or a drop, without changing that frozen rule. Retain all other clocks
and resource observations separately as diagnostics. No pacing, cache purge,
automatic retry or best-sample replacement is permitted.

At the batch boundary, run required workspace/native gates, direct bindings,
public workflow and format/oracle coverage, align documentation and generated
site content, and complete PR checks, final-head review, installed wheels and
production verification. Existing storage, workload and process-cleanup guards
remain required. No new benchmark/search framework or package release belongs
to this batch.
