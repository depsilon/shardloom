# Native text preparation inside bounded workers

Predeclared design for the next shared execution candidate. The compact-directory
612 comparison is still running; its immutable source and design stay unchanged.
The candidate will use the retained runtime selected by that comparison, with
the rejected compact directory removed if its frozen gate fails.

The accepted-runtime Q29 profile places 1,086 of 1,820 main-thread stack samples
under `aggregate_canonical_utf8_chunk`, including 639 Zstd decoder samples. These
are overlapping stack samples, not exclusive timings. Source inspection shows
that `DictionaryPrepareWorkers` performs native canonicalization on the caller
before submitting dictionary construction to one background worker, regardless
of larger CPU grants. The same runtime already canonicalizes native text inside
bounded count-worker jobs using the admitted session and shared memory pool.

For an actual host-capped CPU grant of at least four, reserve one caller lane and
one native provider-progress lane, and use the remaining grant for dictionary
preparation workers. Move the existing native canonicalization into each job
before dictionary construction. Bound the outstanding queue to worker count plus
one. At grants two and three, preserve the existing caller canonicalization,
single preparation worker and two-chunk window. Single-worker execution remains
on its existing route. Admission stays based on the existing operator/type proof;
no query ID, SQL spelling, column name, data value or benchmark threshold selects
the runtime strategy.

Preserve ordered consumption and first-seen IDs across chunks, exact aggregate
update order, native Dict bypass after draining older jobs, max chunk rows,
source owners and independent escaping keys. Reuse `AggregateChunkJobs`, its
leases, cancellation, first-failure handling and worker teardown. Before job
admission, reserve the dictionary bound plus input native-byte estimate. Native
canonical buffers retain the same admitted provider allocator and memory pool.
If canonical bytes exceed the input estimate, grow the task lease before
allocating dictionary metadata; a post-admission failure aborts without replay.
Initial capacity denial drains and retires workers before the unchanged serial
consumer handles the untouched input. Keep the operation's native I/O scope and
provider driver alive until cancellation/error/success cleanup is complete.

Add an accurate summed provider-worker timing field; preserve the existing caller
field's meaning. Report actual worker count, window and CPU ceiling, and update
timing/CPU scope text without changing engine clocks or claiming exclusive CPU
time, an RSS bound or complete provider allocation coverage.

Vortex-first decision: `use_vortex_native_provider`. Reuse the pinned Vortex 0.85
session, ExecutionCtx, ArrayRef/VarBinView execution and registered native buffer
allocator inside the existing ShardLoom worker boundary. No new decoder, source,
scan, scheduler, Arrow execution boundary, dependency or external engine is added.
Metadata/pruning and encoded Dict admission still precede canonicalization.
Execution and Native I/O certificates, `fallback_attempted=false`,
`external_engine_invoked=false`, late materialization, PulseWeave/capillary CPU
grants and broader PERF/CG obligations remain unchanged.

Prove ordinary, prepared and owned complete values at grants one, two, three,
four and a larger host-capped request. Add a deterministic out-of-order worker
completion fixture whose ordered consumer equals the serial reference. Prove
provider allocation denial inside an admitted worker, no same-operation replay,
fresh-operation recovery and exact refund. Extend native pressure retirement,
active cancellation, committed source errors, native Dict interleaving and
zero-spare-credit metadata pruning to the new worker arrangement.

Freeze one unprofiled 98-call comparison: five Q29 pairs at twelve workers;
two Q29 control pairs at each of one, two, three and four workers; five control
pairs each for Q10/Q19/Q34/Q35 at twelve workers; and two control pairs each for
Q2/Q5/Q6/Q9/Q16/Q23/Q28/Q33 at twelve workers. Require at least 5% lower Q29 mean
engine time, four positive target pairs, no target mean regression, the existing
10%/0.15-engine-second control bounds, 10% target CPU bound and 25%/256-MiB RSS
bound. All complete values, schemas, native execution and source identities must
pass. Preserve every sample, with no pacing, cache purge, automatic retry or
best-sample substitution. Final all-43-query material acceptance remains at least
5% lower sum of two-sample per-query engine means, both paired totals improved,
and the unchanged material per-query regression rule.
