"""Execute the final guide example with its page's declared import."""
import ast
import contextlib
import hashlib
import io
import json
import os
import re
import campaign_common as c

original = c.read(c.OUT / "expression-candidate-1-source.json")
assert c.source_hashes() == original["source_hashes"]
build = c.read(c.OUT / "expression-candidate-1-build.json")
assert c.sha(build["binary"]) == build["binary_sha256"]
os.environ["SHARDLOOM_BIN"] = build["binary"]
checks = []
for line in (c.OUT / "documentation-refresh-checks-2.log").read_text().splitlines():
    if line.startswith('{"name":'):
        check = json.loads(line)
        assert check["returncode"] == 0 and c.sha(check["log"]) == check["log_sha256"]
        checks.append(check)
assert [check["name"] for check in checks] == ["user-surface-index", "public-status",
    "use-case-backlinks", "website-readiness", "diff-whitespace"]
prior = c.read(c.OUT / "documentation-checks-1/summary.json")
assert prior["status"] == "passed"
for example in prior["executed_examples"]:
    if example["name"] != "field-guide":
        assert c.sha(c.ROOT / example["source"]) == example["source_sha256"]
failed = c.read(c.OUT / "documentation-refresh-checks-2.json")
assert failed["status"] == "failed" and failed["process_group_drained"]
assert c.sha(c.OUT / "documentation-refresh-checks-2.log") == failed["log_sha256"]
assert "NameError: name 'sl' is not defined" in (c.OUT / "documentation-refresh-checks-2.log").read_text()
guide = c.ROOT / "website-src/src/content/docs/field-guide/python-surface.mdx"
page = guide.read_text()
setup = "import shardloom as sl"
assert re.search(r"```python\n(.*?)\n```", page, re.S).group(1).startswith(setup)
code = re.search(r"```python\n(.*?)\n```", page.split(
    "## Consume results in batches", 1)[1], re.S).group(1)
namespace = {}
try:
    exec(setup, namespace)
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        exec(compile(code, str(guide), "exec"), namespace)
    values = [value for line in output.getvalue().splitlines()
              for value in ast.literal_eval(line)]
    assert values == [{"order_id": 1, "amount": 12.5}, {"order_id": 2, "amount": None}]
    report = namespace["batches"].report
    assert report is not None and report.envelope.status == "success"
    assert report.fallback_attempted is False and report.external_engine_invoked is False
    example = {"name": "field-guide", "source": str(guide.relative_to(c.ROOT)),
               "source_sha256": c.sha(guide), "setup_from_same_page": setup,
               "code_sha256": hashlib.sha256(code.encode()).hexdigest(),
               "complete_rows": values, "envelope": report.envelope.raw}
finally:
    if "frame" in namespace:
        namespace["frame"].client.close()
assert c.source_hashes() == original["source_hashes"]
c.write(c.OUT / "documentation-final-examples-3.json", {
    "status": "passed", "source_identity_sha256": original["source_identity_sha256"],
    "runtime_source_assets_verified": len(original["source_hashes"]), "checks": checks,
    "executed_example": example, "binary_sha256": build["binary_sha256"],
    "prior_summary_sha256": c.sha(c.OUT / "documentation-checks-1/summary.json"),
    "refreshed_site_build_sha256": c.sha(c.OUT / "documentation-site-refresh-2.json"),
    "prior_attempt_scope": "Five final documentation gates passed; the verifier omitted the import declared earlier on the same page. The final execution includes that import. No published example or runtime correction was required.",
    "driver_sha256": c.sha(__file__)})
print(json.dumps({"status": "passed", "checks": len(checks), "examples": 1}), flush=True)
