"""Immutable source/build identities for serial hardware-informed experiments."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
BASE = OUT.parent/'native-composed-strategies-20261006'
PYTHON = '/opt/homebrew/opt/python@3.13/libexec/bin/python3'
RUSTUP = '/Users/dylan/.cargo/bin/rustup'

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def source_hashes():
    names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
    return {name: sha(ROOT/name) for name in sorted(set(names)) if name and (
        name.endswith(('.rs', '.py')) or Path(name).name in ('Cargo.toml', 'Cargo.lock')
        or name.startswith('vendor/'))}

def baseline():
    accepted_path = BASE/'bounded-accepted-commit-1.json'
    accepted = read(accepted_path)
    assert accepted['status'] == 'accepted_bytes_committed_locally'
    assert accepted['source_tree_clean_after_commit'] and not accepted['pushed']
    original = read(BASE/'bounded-source-2.json')
    build = read(BASE/'bounded-build-2.json')
    assert accepted['source_identity_sha256'] == original['source_identity_sha256'] == build['source_identity_sha256']
    assert sha(build['binary']) == build['binary_sha256']
    return accepted, original, build

def freeze(label, allowed):
    accepted, original, build = baseline()
    assert git('rev-parse', 'HEAD') == accepted['commit']
    hashes = source_hashes()
    changed = {name for name in set(hashes) | set(original['source_hashes'])
               if hashes.get(name) != original['source_hashes'].get(name)}
    assert changed == set(allowed), (changed, allowed)
    raw_status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True)
    status = raw_status.strip()
    assert {line[3:] for line in raw_status.splitlines()} == changed
    assert not any(name.startswith(('docs/', 'website', 'vendor/')) or name.endswith('Cargo.toml')
                   or name == 'Cargo.lock' for name in changed)
    contract = OUT/'campaign_contract.json'
    result = {'status': 'frozen_before_build', 'label': label, 'head': accepted['commit'],
        'source_hashes': hashes,
        'source_identity_sha256': hashlib.sha256(json.dumps(hashes, sort_keys=True).encode()).hexdigest(),
        'working_tree': status, 'changed_paths': sorted(changed),
        'changed_sources': {name: (ROOT/name).read_text() for name in sorted(changed)},
        'tracked_patch': git('diff', '--binary', 'HEAD'),
        'baseline_accepted_sha256': sha(BASE/'bounded-accepted-commit-1.json'),
        'baseline_binary_sha256': build['binary_sha256'],
        'campaign_contract_sha256': sha(contract), 'guard_sha256': sha(OUT/'run_guarded.py'),
        'helper_sha256': sha(__file__), 'documentation_updates_deferred': True}
    write(OUT/f'{label}-source.json', result)
    print(json.dumps({'label': label, 'source_identity_sha256': result['source_identity_sha256'],
                      'changed_paths': sorted(changed)}), flush=True)
    return result

def frozen(label):
    result = read(OUT/f'{label}-source.json')
    assert git('rev-parse', 'HEAD') == result['head']
    assert git('status', '--porcelain') == result['working_tree']
    assert source_hashes() == result['source_hashes']
    assert sha(OUT/'campaign_contract.json') == result['campaign_contract_sha256']
    assert sha(OUT/'run_guarded.py') == result['guard_sha256']
    assert sha(__file__) == result['helper_sha256']
    return result

def freeze_binary(label, receipt_name):
    source = frozen(label)
    receipt_path = OUT/(receipt_name + '.json')
    receipt = read(receipt_path)
    log = receipt_path.with_suffix('.log')
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['log_sha256'] == sha(log)
    assert receipt['head'] == source['head'] and receipt['working_tree'].strip() == source['working_tree']
    binaries = []
    for line in log.read_text().splitlines():
        try:
            item = json.loads(line)
        except ValueError:
            continue
        if item.get('reason') == 'compiler-artifact' and item.get('executable') and item['target']['name'] == 'shardloom':
            binaries.append(Path(item['executable']))
    assert len(binaries) == 1
    directory = OUT/'bin'
    directory.mkdir(exist_ok=True)
    target = directory/f'shardloom-{label}'
    with binaries[0].open('rb') as incoming, target.open('xb') as outgoing:
        shutil.copyfileobj(incoming, outgoing)
    target.chmod(0o555)
    assert sha(target) == sha(binaries[0])
    result = {'label': label, 'status': 'frozen_executable', 'binary': str(target),
        'binary_sha256': sha(target), 'binary_bytes': target.stat().st_size,
        'source_identity_sha256': source['source_identity_sha256'],
        'source_snapshot': str(OUT/f'{label}-source.json'),
        'source_snapshot_sha256': sha(OUT/f'{label}-source.json'),
        'build_receipt': str(receipt_path), 'build_receipt_sha256': sha(receipt_path),
        'build_command': receipt['command'], 'build_environment': receipt['environment']}
    frozen(label)
    write(OUT/f'{label}-build.json', result)
    print(json.dumps(result), flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='mode', required=True)
    source = sub.add_parser('freeze-source')
    source.add_argument('--label', required=True)
    source.add_argument('--allowed', nargs='*', default=[])
    check = sub.add_parser('check-source')
    check.add_argument('--label', required=True)
    binary = sub.add_parser('freeze-binary')
    binary.add_argument('--label', required=True)
    binary.add_argument('--receipt', required=True)
    args = parser.parse_args()
    assert args.label.replace('-', '').isalnum()
    if args.mode == 'freeze-source':
        freeze(args.label, args.allowed)
    elif args.mode == 'check-source':
        print(json.dumps({'status': 'passed', 'source_identity_sha256': frozen(args.label)['source_identity_sha256']}))
    else:
        freeze_binary(args.label, args.receipt)
