"""Validate source-linked documentation, examples and the generated local site."""
import ast
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import time

import campaign_common as c

OUT = c.OUT / "documentation-checks-1"
OUT.mkdir(exist_ok=False)
original = c.read(c.OUT / "expression-candidate-1-source.json")
assert c.source_hashes() == original["source_hashes"]
build = c.read(c.OUT / "expression-candidate-1-build.json")
assert c.sha(build["binary"]) == build["binary_sha256"]
os.environ["SHARDLOOM_BIN"] = build["binary"]
checks = []


def run(label, command, cwd=c.ROOT):
    path = OUT / (label + ".log")
    start = time.monotonic()
    with path.open("xb") as output:
        result = subprocess.run(command, cwd=cwd, stdout=output,
                                stderr=subprocess.STDOUT, timeout=300, check=False)
    receipt = {"name": label, "command": command, "cwd": str(cwd),
               "returncode": result.returncode, "seconds": time.monotonic() - start,
               "log": str(path), "log_sha256": c.sha(path)}
    checks.append(receipt)
    print(json.dumps(receipt), flush=True)
    assert result.returncode == 0, label


run("user-surface-index", [c.PYTHON, "-B", "scripts/check_user_surface_reference.py"])
run("public-status", [c.PYTHON, "-B", "scripts/check_public_status_docs.py",
                       "--output", str(OUT / "public-status.json")])
run("use-case-backlinks", [c.PYTHON, "-B", "scripts/check_use_case_backlinks.py"])
run("website-check", ["npm", "run", "check"], c.ROOT / "website-src")
run("website-build", ["npm", "run", "build"], c.ROOT / "website-src")
run("website-readiness", [c.PYTHON, "-B", "scripts/check_website_readiness.py",
                           "--output", str(OUT / "website-readiness.json")])
run("diff-whitespace", ["git", "diff", "--check"])

contract = c.ROOT / "docs/architecture/native-bounded-adapters-2026-10-06.md"
guide = c.ROOT / "website-src/src/content/docs/field-guide/python-surface.mdx"
readme = c.ROOT / "python/README.md"
pattern = re.compile(r"```python\n(.*?)\n```", re.S)
contract_code = pattern.search(contract.read_text()).group(1)
guide_code = pattern.search(guide.read_text().split("## Consume results in batches", 1)[1]).group(1)
readme_code = next(code for code in pattern.findall(readme.read_text())
                   if code.startswith("with workflow.iter_batches"))
namespace = {}
examples = []
for label, code, expected, path in (
    ("batch-contract", contract_code,
     [{"order_id": 1, "amount": 12.5}, {"order_id": 2, "amount": None},
      {"order_id": 3, "amount": 7.0}], contract),
    ("python-readme", readme_code,
     [{"order_id": 1, "amount": 12.5}, {"order_id": 2, "amount": None},
      {"order_id": 3, "amount": 7.0}], readme),
    ("field-guide", guide_code,
     [{"order_id": 1, "amount": 12.5}, {"order_id": 2, "amount": None}], guide),
):
    if label == "python-readme":
        namespace["workflow"] = namespace["frame"]
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        exec(compile(code, str(path), "exec"), namespace)
    values = [value for line in output.getvalue().splitlines()
              for value in ast.literal_eval(line)]
    assert values == expected, (label, values)
    report = namespace["batches"].report
    assert report is not None and report.status == "success"
    assert report.fallback_attempted is False
    examples.append({"name": label, "source": str(path.relative_to(c.ROOT)),
                     "source_sha256": c.sha(path),
                     "code_sha256": hashlib.sha256(code.encode()).hexdigest(),
                     "complete_rows": values, "status": report.status,
                     "fallback_attempted": report.fallback_attempted})
    namespace["frame"].client.close()

assert c.source_hashes() == original["source_hashes"]
result = {"status": "passed", "source_identity_sha256": original["source_identity_sha256"],
          "runtime_source_assets_verified": len(original["source_hashes"]),
          "checks": checks, "executed_examples": examples,
          "binary_sha256": build["binary_sha256"], "driver_sha256": c.sha(__file__),
          "browser_visual_qa": "pending", "hosted_integration": "pending"}
c.write(OUT / "summary.json", result)
print(json.dumps({"status": "passed", "checks": len(checks), "examples": len(examples)}), flush=True)
