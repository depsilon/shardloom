"""Retain final documentation checks, page identities and browser evidence."""
import hashlib
import io
import json
from pathlib import Path
import tarfile
import campaign_common as c

original = c.read(c.OUT / "expression-candidate-1-source.json")
assert c.source_hashes() == original["source_hashes"]
assert c.git("rev-parse", "HEAD") == "99e0a4b304c506a2b24f605eb5156859b356486a"
initial = c.read(c.OUT / "documentation-checks-1/summary.json")
final = c.read(c.OUT / "documentation-final-examples-3.json")
browser = c.read(c.OUT / "documentation-browser-final-2.json")
assert initial["status"] == final["status"] == browser["status"] == "passed"
assert len(initial["checks"]) == 7 and len(initial["executed_examples"]) == 3
assert len(final["checks"]) == 5
for check in initial["checks"] + final["checks"]:
    assert check["returncode"] == 0 and c.sha(check["log"]) == check["log_sha256"]
for name in ("documentation-examples-2", "documentation-site-refresh-2",
             "documentation-final-example-3", "documentation-preview-1",
             "documentation-preview-2"):
    receipt = c.read(c.OUT / (name + ".json"))
    assert receipt["status"] == "passed" and receipt["process_group_drained"]
    assert c.sha(c.OUT / (name + ".log")) == receipt["log_sha256"]
for measurement in browser["measurements"]:
    assert measurement["viewportWidth"] == measurement["bodyWidth"] == measurement["documentWidth"]
assert browser["search"]["resultCount"] == 1 and browser["search"]["headingPresent"]
assert browser["search"]["target"].endswith("/field-guide/python-surface/#consume-results-in-batches")
assert browser["warningAndErrorLogs"] == []
for example in initial["executed_examples"]:
    if example["name"] != "field-guide":
        assert c.sha(c.ROOT / example["source"]) == example["source_sha256"]
example = final["executed_example"]
assert c.sha(c.ROOT / example["source"]) == example["source_sha256"]

paths = {}
for path in c.OUT.glob("documentation*"):
    for item in sorted(path.rglob("*")) if path.is_dir() else [path]:
        if item.is_file():
            paths["proof/" + str(item.relative_to(c.OUT))] = item
for name in ("verify_documentation.py", "verify_documentation_examples.py",
             "verify_documentation_refresh.py", "verify_documentation_final_example.py",
             "preview_documentation.py", "preview_documentation_2.py",
             "campaign_common.py", "run_guarded.py", Path(__file__).name):
    paths["drivers/" + name] = c.OUT / name
names = c.git("diff", "--name-only", "HEAD").splitlines()
names += c.git("ls-files", "--others", "--exclude-standard").splitlines()
for name in sorted(set(names)):
    path = c.ROOT / name
    if path.is_file() and not name.startswith("docs/benchmarks/evidence/"):
        assert name.startswith(("docs/", "python/README.md", "website-src/", "website/")), name
        paths["source/" + name] = path
assert sum(path.stat().st_size for path in paths.values()) < 64 * 1024 * 1024
manifest = {name: {"bytes": path.stat().st_size, "sha256": c.sha(path)}
            for name, path in sorted(paths.items())}
manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
target = c.ROOT / "docs/benchmarks/evidence/native-documentation-acceptance-2026-10-06.tar.xz"
assert not target.exists()
with tarfile.open(target, "x:xz", preset=6) as archive:
    for name, path in sorted(paths.items()):
        info = tarfile.TarInfo(name)
        info.size = path.stat().st_size
        info.mode = 0o644
        with path.open("rb") as stream:
            archive.addfile(info, stream)
    info = tarfile.TarInfo("manifest.json")
    info.size = len(manifest_bytes)
    info.mode = 0o644
    archive.addfile(info, io.BytesIO(manifest_bytes))
with tarfile.open(target, "r:xz") as archive:
    members = archive.getmembers()
    assert {member.name for member in members} == set(manifest) | {"manifest.json"}
    assert len(members) == len(manifest) + 1
    assert archive.extractfile("manifest.json").read() == manifest_bytes
    for name, expected in manifest.items():
        with archive.extractfile(name) as stream:
            assert hashlib.file_digest(stream, "sha256").hexdigest() == expected["sha256"]
        assert archive.getmember(name).size == expected["bytes"]
assert c.source_hashes() == original["source_hashes"]
receipt = {
    "schema_version": "shardloom.native_documentation_acceptance.v1",
    "status": "passed_local_documentation_acceptance",
    "runtime_commit": c.git("rev-parse", "HEAD"),
    "source_identity_sha256": original["source_identity_sha256"],
    "runtime_source_assets_verified": len(original["source_hashes"]),
    "initial_documentation_gates": len(initial["checks"]),
    "final_selected_gates": len(final["checks"]),
    "executed_examples": 3,
    "final_changed_example_repeated": True,
    "browser": browser,
    "archive": {"path": str(target.relative_to(c.ROOT)), "bytes": target.stat().st_size,
                "sha256": c.sha(target), "members": len(manifest),
                "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
                "all_members_reopened_and_hash_checked": True},
    "source_files": {name.removeprefix("source/"): item for name, item in manifest.items()
                     if name.startswith("source/")},
    "preserved_failed_attempts": [
        {"attempt": "documentation-checks-1", "cause": "Verifier used report.status instead of report.envelope.status after all seven gates passed."},
        {"attempt": "documentation-refresh-checks-2", "cause": "Verifier omitted the import declared earlier on the guide page after all five gates passed."}],
    "claim_boundary": "Documentation and browser acceptance for these exact source/page bytes. This does not rerun or expand the accepted engine's runtime scope. Hosted integration and package publication are separate.",
    "temporary_servers_drained": True,
    "temporary_browser_closed_and_viewport_restored": True,
    "driver_sha256": c.sha(__file__)}
c.write(target.with_name("native-documentation-acceptance-2026-10-06.json"), receipt)
print(json.dumps({"status": "passed", "members": len(manifest), "bytes": target.stat().st_size,
                  "sha256": receipt["archive"]["sha256"]}), flush=True)
