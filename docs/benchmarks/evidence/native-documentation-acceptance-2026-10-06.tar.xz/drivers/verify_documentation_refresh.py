"""Verify the final generated guide and changed example without repeating engine gates."""
import ast
import contextlib
import hashlib
import io
import json
import os
import re
import subprocess
import time

import campaign_common as c

OUT = c.OUT / "documentation-refresh-checks-2"
OUT.mkdir(exist_ok=False)
original = c.read(c.OUT / "expression-candidate-1-source.json")
assert c.source_hashes() == original["source_hashes"]
prior = c.read(c.OUT / "documentation-checks-1/summary.json")
assert prior["status"] == "passed" and len(prior["checks"]) == 7
assert len(prior["executed_examples"]) == 3
for check in prior["checks"]:
    assert check["returncode"] == 0 and c.sha(check["log"]) == check["log_sha256"]
refresh = c.read(c.OUT / "documentation-site-refresh-2.json")
assert refresh["status"] == "passed" and refresh["process_group_drained"]
assert c.sha(c.OUT / "documentation-site-refresh-2.log") == refresh["log_sha256"]
build = c.read(c.OUT / "expression-candidate-1-build.json")
assert c.sha(build["binary"]) == build["binary_sha256"]
os.environ["SHARDLOOM_BIN"] = build["binary"]
checks = []

def run(label, command):
    path = OUT / (label + ".log")
    start = time.monotonic()
    with path.open("xb") as output:
        result = subprocess.run(command, cwd=c.ROOT, stdout=output,
                                stderr=subprocess.STDOUT, timeout=120, check=False)
    receipt = {"name": label, "command": command, "returncode": result.returncode,
               "seconds": time.monotonic() - start, "log": str(path),
               "log_sha256": c.sha(path)}
    checks.append(receipt)
    print(json.dumps(receipt), flush=True)
    assert result.returncode == 0, label

run("user-surface-index", [c.PYTHON, "-B", "scripts/check_user_surface_reference.py"])
run("public-status", [c.PYTHON, "-B", "scripts/check_public_status_docs.py",
                       "--output", str(OUT / "public-status.json")])
run("use-case-backlinks", [c.PYTHON, "-B", "scripts/check_use_case_backlinks.py"])
run("website-readiness", [c.PYTHON, "-B", "scripts/check_website_readiness.py",
                           "--output", str(OUT / "website-readiness.json")])
run("diff-whitespace", ["git", "diff", "--check"])

for example in prior["executed_examples"]:
    if example["name"] != "field-guide":
        assert c.sha(c.ROOT / example["source"]) == example["source_sha256"]
guide = c.ROOT / "website-src/src/content/docs/field-guide/python-surface.mdx"
code = re.search(r"```python\n(.*?)\n```", guide.read_text().split(
    "## Consume results in batches", 1)[1], re.S).group(1)
namespace = {}
try:
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        exec(compile(code, str(guide), "exec"), namespace)
    values = [value for line in output.getvalue().splitlines()
              for value in ast.literal_eval(line)]
    assert values == [{"order_id": 1, "amount": 12.5},
                      {"order_id": 2, "amount": None}]
    report = namespace["batches"].report
    assert report is not None and report.envelope.status == "success"
    assert report.fallback_attempted is False and report.external_engine_invoked is False
    example = {"name": "field-guide", "source": str(guide.relative_to(c.ROOT)),
               "source_sha256": c.sha(guide),
               "code_sha256": hashlib.sha256(code.encode()).hexdigest(),
               "complete_rows": values, "envelope": report.envelope.raw}
finally:
    if "frame" in namespace:
        namespace["frame"].client.close()

assert c.source_hashes() == original["source_hashes"]
c.write(OUT / "summary.json", {
    "status": "passed", "source_identity_sha256": original["source_identity_sha256"],
    "runtime_source_assets_verified": len(original["source_hashes"]), "checks": checks,
    "executed_example": example, "binary_sha256": build["binary_sha256"],
    "prior_summary_sha256": c.sha(c.OUT / "documentation-checks-1/summary.json"),
    "refreshed_site_build_sha256": c.sha(c.OUT / "documentation-site-refresh-2.json"),
    "driver_sha256": c.sha(__file__)})
print(json.dumps({"status": "passed", "checks": len(checks), "examples": 1}), flush=True)
