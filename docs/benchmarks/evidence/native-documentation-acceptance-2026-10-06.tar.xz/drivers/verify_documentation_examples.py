"""Check the new guide examples and retain prior successful documentation gates."""
import ast
import contextlib
import hashlib
import io
import json
import os
import re

import campaign_common as c

OUT = c.OUT / "documentation-checks-1"
original = c.read(c.OUT / "expression-candidate-1-source.json")
assert c.source_hashes() == original["source_hashes"]
build = c.read(c.OUT / "expression-candidate-1-build.json")
assert c.sha(build["binary"]) == build["binary_sha256"]
os.environ["SHARDLOOM_BIN"] = build["binary"]
checks = []
for line in (c.OUT / "documentation-checks-1.log").read_text().splitlines():
    if not line.startswith('{"name":'):
        continue
    item = json.loads(line)
    assert item["returncode"] == 0 and c.sha(item["log"]) == item["log_sha256"]
    checks.append(item)
assert [item["name"] for item in checks] == [
    "user-surface-index", "public-status", "use-case-backlinks", "website-check",
    "website-build", "website-readiness", "diff-whitespace"]
prior = c.read(c.OUT / "documentation-checks-1.json")
assert prior["status"] == "failed" and prior["returncode"] == 1 and prior["process_group_drained"]
assert c.sha(c.OUT / "documentation-checks-1.log") == prior["log_sha256"]
assert "AttributeError: 'PublicWorkflowExecution' object has no attribute 'status'" in (c.OUT / "documentation-checks-1.log").read_text()

contract = c.ROOT / "docs/architecture/native-bounded-adapters-2026-10-06.md"
guide = c.ROOT / "website-src/src/content/docs/field-guide/python-surface.mdx"
readme = c.ROOT / "python/README.md"
pattern = re.compile(r"```python\n(.*?)\n```", re.S)
contract_code = pattern.search(contract.read_text()).group(1)
guide_code = pattern.search(guide.read_text().split("## Consume results in batches", 1)[1]).group(1)
readme_code = next(code for code in pattern.findall(readme.read_text())
                   if code.startswith("with workflow.iter_batches"))
namespace = {}
examples = []
clients = []
try:
    for label, code, expected, path in (
        ("batch-contract", contract_code,
         [{"order_id": 1, "amount": 12.5}, {"order_id": 2, "amount": None},
          {"order_id": 3, "amount": 7.0}], contract),
        ("python-readme", readme_code,
         [{"order_id": 1, "amount": 12.5}, {"order_id": 2, "amount": None},
          {"order_id": 3, "amount": 7.0}], readme),
        ("field-guide", guide_code,
         [{"order_id": 1, "amount": 12.5}, {"order_id": 2, "amount": None}], guide),
    ):
        if label == "python-readme":
            namespace["workflow"] = namespace["frame"]
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            exec(compile(code, str(path), "exec"), namespace)
        values = [value for line in output.getvalue().splitlines()
                  for value in ast.literal_eval(line)]
        assert values == expected, (label, values)
        report = namespace["batches"].report
        assert report is not None and report.envelope.status == "success"
        assert report.fallback_attempted is False and report.external_engine_invoked is False
        examples.append({"name": label, "source": str(path.relative_to(c.ROOT)),
                         "source_sha256": c.sha(path),
                         "code_sha256": hashlib.sha256(code.encode()).hexdigest(),
                         "complete_rows": values, "envelope": report.envelope.raw})
        clients.append(namespace["frame"].client)
finally:
    for client in clients:
        client.close()

assert c.source_hashes() == original["source_hashes"]
result = {"status": "passed", "source_identity_sha256": original["source_identity_sha256"],
          "runtime_source_assets_verified": len(original["source_hashes"]),
          "checks": checks, "executed_examples": examples,
          "binary_sha256": build["binary_sha256"], "driver_sha256": c.sha(__file__),
          "prior_attempt": {"receipt": str(c.OUT / "documentation-checks-1.json"),
                            "sha256": c.sha(c.OUT / "documentation-checks-1.json"),
                            "scope": "Seven source/site gates passed; the example verifier used report.status instead of report.envelope.status. No engine or published example correction was needed."},
          "browser_visual_qa": "pending", "hosted_integration": "pending"}
c.write(OUT / "summary.json", result)
print(json.dumps({"status": "passed", "checks": len(checks), "examples": len(examples)}), flush=True)
