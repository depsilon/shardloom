"""Apply the compatible Sharp security patch and reproduce hosted website gates."""
import json
import subprocess
import time
import campaign_common as c

OUT = c.OUT / "site-dependency-repair-1"
OUT.mkdir(exist_ok=False)
site = c.ROOT / "website-src"
original = c.read(c.OUT / "expression-candidate-1-source.json")
assert c.source_hashes() == original["source_hashes"]
assert c.git("status", "--porcelain") == ""
before = c.read(site / "package-lock.json")
assert before["packages"]["node_modules/sharp"]["version"] == "0.35.4"
before_manifest = c.sha(site / "package.json")
c.write(OUT / "package-lock-before.json", before)
checks = []

def run(name, command, expected=0, cwd=site):
    log = OUT / (name + ".log")
    start = time.monotonic()
    with log.open("xb") as output:
        result = subprocess.run(command, cwd=cwd, stdout=output,
                                stderr=subprocess.STDOUT, timeout=300, check=False)
    item = {"name": name, "command": command, "returncode": result.returncode,
            "seconds": time.monotonic() - start, "log": str(log), "log_sha256": c.sha(log)}
    checks.append(item)
    print(json.dumps(item), flush=True)
    assert result.returncode == expected, (name, result.returncode, expected)
    return log

audit_path = run("audit-before", ["npm", "audit", "--json", "--audit-level=low"], expected=1)
audit_before = c.read(audit_path)
sharp = audit_before["vulnerabilities"]["sharp"]
assert sharp["severity"] == "high"
assert any(isinstance(via, dict) and via["url"] == "https://github.com/advisories/GHSA-wq5f-xc86-pv6w"
           for via in sharp["via"])
run("lock-update", ["npm", "update", "sharp", "--package-lock-only", "--ignore-scripts"])
after = c.read(site / "package-lock.json")
assert after["packages"]["node_modules/sharp"]["version"] == "0.35.5"
assert c.sha(site / "package.json") == before_manifest
changed = {key for key in before["packages"].keys() | after["packages"].keys()
           if before["packages"].get(key) != after["packages"].get(key)}
assert changed and all(key == "node_modules/sharp" or key.startswith("node_modules/@img/")
                       for key in changed), sorted(changed)
run("install", ["npm", "ci"])
audit_after_path = run("audit-after", ["npm", "audit", "--json", "--audit-level=low"])
audit_after = c.read(audit_after_path)
assert audit_after["metadata"]["vulnerabilities"]["total"] == 0
run("website-check", ["npm", "run", "check"])
run("website-build", ["npm", "run", "build"])
run("website-readiness", [c.PYTHON, "-B", "scripts/check_website_readiness.py", "--output",
                          str(OUT / "website-readiness.json")], cwd=c.ROOT)
run("diff-whitespace", ["git", "diff", "--check"], cwd=c.ROOT)
assert c.source_hashes() == original["source_hashes"]
assert c.git("diff", "--name-only").splitlines() == ["website-src/package-lock.json"]
doc = c.read(c.ROOT / "docs/benchmarks/evidence/native-documentation-acceptance-2026-10-06.json")
for name, identity in doc["source_files"].items():
    assert c.sha(c.ROOT / name) == identity["sha256"], name
receipt = {
    "status": "passed", "reason": "Hosted website audit reported GHSA-wq5f-xc86-pv6w for locked Sharp 0.35.4.",
    "advisory": "https://github.com/advisories/GHSA-wq5f-xc86-pv6w",
    "official_release": "https://github.com/lovell/sharp/releases/tag/v0.35.5",
    "old_sharp": "0.35.4", "new_sharp": "0.35.5", "changed_lock_packages": sorted(changed),
    "checks": checks, "audit_vulnerabilities_after": audit_after["metadata"]["vulnerabilities"],
    "engine_source_identity_sha256": original["source_identity_sha256"],
    "engine_assets_unchanged": len(original["source_hashes"]),
    "previously_reviewed_documentation_and_generated_page_hashes_unchanged": True,
    "package_version_unchanged": True,
    "before_lock_sha256": c.sha(OUT / "package-lock-before.json"),
    "after_lock_sha256": c.sha(site / "package-lock.json"),
    "driver_sha256": c.sha(__file__)}
c.write(OUT / "summary.json", receipt)
print(json.dumps({"status": "passed", "changed_lock_packages": len(changed),
                  "engine_assets_unchanged": len(original["source_hashes"])}), flush=True)
