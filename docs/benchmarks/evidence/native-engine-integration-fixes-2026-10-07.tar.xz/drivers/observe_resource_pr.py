"""Save bounded read-only snapshots of the accepted native-resource PR."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import json
import subprocess
import campaign_common as c

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--attempt", type=int, required=True)
args = parser.parse_args()
raw = subprocess.check_output([
    "/opt/homebrew/bin/gh", "pr", "view", "1526", "--repo", "depsilon/shardloom",
    "--json", "number,url,state,isDraft,headRefOid,baseRefName,mergeable,mergeStateStatus,reviewDecision,statusCheckRollup,reviews,comments,mergedAt,mergeCommit"],
    cwd=c.ROOT, text=True, timeout=60)
snapshot = json.loads(raw)
snapshot["observed_at"] = datetime.now(timezone.utc).isoformat()
snapshot["reader_sha256"] = c.sha(__file__)
path = c.OUT / f"resource-pr-snapshot-{args.attempt}.json"
c.write(path, snapshot)
counts = Counter()
pending = []
failed = []
for check in snapshot["statusCheckRollup"]:
    state = check.get("conclusion") or check.get("status") or check.get("state")
    counts[state] += 1
    if state in ("FAILURE", "ERROR", "CANCELLED", "TIMED_OUT", "ACTION_REQUIRED", "STARTUP_FAILURE"):
        failed.append({"name": check.get("name") or check.get("context"), "state": state,
                       "url": check.get("detailsUrl") or check.get("targetUrl")})
    elif state not in ("SUCCESS", "SKIPPED", "NEUTRAL"):
        pending.append(check.get("name") or check.get("context"))
print(json.dumps({"snapshot": str(path), "state": snapshot["state"],
    "head": snapshot["headRefOid"], "merge_state": snapshot["mergeStateStatus"],
    "review_decision": snapshot["reviewDecision"], "checks": dict(counts),
    "pending": pending, "failed": failed, "review_count": len(snapshot["reviews"]),
    "comments": [{"author": comment["author"]["login"], "body": comment["body"],
                  "url": comment["url"]} for comment in snapshot["comments"]]}), flush=True)
