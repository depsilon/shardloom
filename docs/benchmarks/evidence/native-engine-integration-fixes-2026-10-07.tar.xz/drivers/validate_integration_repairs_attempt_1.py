"""Validate the bounded CI repairs and bridge them to the accepted runtime snapshot."""
import hashlib
import json
import subprocess
import time
import campaign_common as c

original = c.read(c.OUT / "expression-candidate-1-source.json")
current = c.source_hashes()
changed = {name for name in original["source_hashes"].keys() | current.keys()
           if original["source_hashes"].get(name) != current.get(name)}
test_path = "shardloom-vortex/src/vortex_ingest_pipeline_pressure_tests.rs"
assert changed == {test_path}
module = (c.ROOT / "shardloom-vortex/src/vortex_ingest.rs").read_text()
assert '#[cfg(all(test, feature = "vortex-write", feature = "universal-format-io"))]\n#[path = "vortex_ingest_pipeline_pressure_tests.rs"]\nmod pipeline_pressure_tests;' in module
negative = c.read(c.OUT / "ci-cpu-capacity-reproducer-1.json")
positive = c.read(c.OUT / "ci-cpu-capacity-repaired-1.json")
assert negative["status"] == "failed" and negative["returncode"] == 101
assert positive["status"] == "passed" and positive["returncode"] == 0
for name, receipt in (("ci-cpu-capacity-reproducer-1", negative), ("ci-cpu-capacity-repaired-1", positive)):
    assert receipt["process_group_drained"]
    assert c.sha(c.OUT / (name + ".log")) == receipt["log_sha256"]
site = c.read(c.OUT / "site-dependency-repair-1/summary.json")
assert site["status"] == "passed" and site["audit_vulnerabilities_after"]["total"] == 0
OUT = c.OUT / "integration-repair-checks-1"
OUT.mkdir(exist_ok=False)
checks = []
for name, command in (
    ("fmt", [c.RUSTUP, "run", "1.99.0", "cargo", "fmt", "--all", "--", "--check"]),
    ("default-clippy", [c.RUSTUP, "run", "1.99.0", "cargo", "clippy", "--offline", "--locked",
                         "--workspace", "--all-targets", "--", "-D", "warnings"]),
    ("default-tests", [c.RUSTUP, "run", "1.99.0", "cargo", "test", "--offline", "--locked",
                        "--workspace", "--all-targets"]),
    ("native-clippy", [c.RUSTUP, "run", "1.99.0", "cargo", "clippy", "--offline", "--locked",
                        "-p", "shardloom-cli", "-p", "shardloom-vortex", "--all-targets",
                        "--features", "shardloom-cli/release-user-surfaces", "--", "-D", "warnings"]),
    ("diff-whitespace", ["git", "diff", "--check"]),
):
    log = OUT / (name + ".log")
    start = time.monotonic()
    with log.open("xb") as output:
        result = subprocess.run(command, cwd=c.ROOT, stdout=output, stderr=subprocess.STDOUT,
                                timeout=600, check=False)
    check = {"name": name, "command": command, "returncode": result.returncode,
             "seconds": time.monotonic() - start, "log": str(log), "log_sha256": c.sha(log)}
    checks.append(check)
    print(json.dumps(check), flush=True)
    assert result.returncode == 0, name
assert c.source_hashes() == current
assert set(c.git("diff", "--name-only").splitlines()) == {test_path, "website-src/package-lock.json"}
c.write(OUT / "summary.json", {
    "status": "passed", "accepted_runtime_commit": "99e0a4b304c506a2b24f605eb5156859b356486a",
    "accepted_source_identity_sha256": original["source_identity_sha256"],
    "integration_source_identity_sha256": hashlib.sha256(json.dumps(current, sort_keys=True).encode()).hexdigest(),
    "source_hashes": current, "source_assets": len(current), "changed_source_assets": sorted(changed),
    "changed_source_scope": "Only a cfg(test) fixture changes: expected CPU/report counts use the available process capacity and requests include one above that capacity.",
    "production_source_assets_unchanged": True, "local_red_reproducer": negative,
    "local_green_pressure_suite": positive, "checks": checks,
    "site_dependency_summary_sha256": c.sha(c.OUT / "site-dependency-repair-1/summary.json"),
    "prior_full_acceptance_scope": "The complete public/direct/format/batch/Full43 results and measured release binary remain acceptance for identical production code. They were not rerun for a test-only correction and a static-site lockfile patch.",
    "hosted_complete_checks": "pending_updated_head", "driver_sha256": c.sha(__file__)})
print(json.dumps({"status": "passed", "checks": len(checks), "changed_source_assets": sorted(changed)}), flush=True)
