"""Preserve CI counterevidence and the test-only source identity bridge."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import campaign_common as c

checked = c.read(c.OUT / "integration-repair-checks-2/summary.json")
site = c.read(c.OUT / "site-dependency-repair-1/summary.json")
assert checked["status"] == site["status"] == "passed"
assert c.source_hashes() == checked["source_hashes"]
test = "shardloom-vortex/src/vortex_ingest_pipeline_pressure_tests.rs"
lock = "website-src/package-lock.json"
assert checked["changed_source_assets"] == [test]
assert c.sha(c.ROOT / lock) == site["after_lock_sha256"]
for check in checked["checks"] + site["checks"]:
    assert c.sha(check["log"]) == check["log_sha256"]
    assert check["returncode"] == (1 if check["name"] == "audit-before" else 0)
for name, status in (
    ("ci-cpu-capacity-reproducer-1", "failed"),
    ("ci-cpu-capacity-repaired-1", "passed"),
    ("integration-repair-checks-1", "failed"),
    ("integration-repair-checks-2", "passed"),
    ("site-dependency-repair-1", "passed"),
):
    receipt = c.read(c.OUT / (name + ".json"))
    assert receipt["status"] == status and receipt["process_group_drained"]
    assert c.sha(c.OUT / (name + ".log")) == receipt["log_sha256"]
assert "11 passed; 0 failed" in (c.OUT / "ci-cpu-capacity-repaired-1.log").read_text()
assert "left: 10" in (c.OUT / "ci-cpu-capacity-reproducer-1.log").read_text()
assert "right: 11" in (c.OUT / "ci-cpu-capacity-reproducer-1.log").read_text()
assert site["audit_vulnerabilities_after"]["total"] == 0

paths = {}
for pattern in ("ci-cpu-capacity-*", "integration-repair-checks-*",
                "site-dependency-repair-*", "resource-ci-*", "resource-pr-snapshot-*.json"):
    for path in sorted(c.OUT.glob(pattern)):
        for item in sorted(path.rglob("*")) if path.is_dir() else [path]:
            if item.is_file():
                paths["proof/" + str(item.relative_to(c.OUT))] = item
for name in ("validate_integration_repairs.py", "validate_integration_repairs_attempt_1.py",
             "repair_site_dependency.py", "observe_resource_pr.py", "campaign_common.py",
             "run_guarded.py", Path(__file__).name):
    paths["drivers/" + name] = c.OUT / name
for name in (test, lock, "shardloom-exec/src/compute_pool.rs",
             "shardloom-vortex/src/vortex_ingest.rs", "website-src/package.json"):
    paths["source/" + name] = c.ROOT / name
original = c.read(c.OUT / "expression-candidate-1-source.json")
extras = {
    "original/source-hashes.json": (json.dumps(original["source_hashes"], indent=2, sort_keys=True) + "\n").encode(),
    "integration.patch": subprocess.check_output(["git", "diff", "--binary", "HEAD", "--", test, lock], cwd=c.ROOT),
}
for name in (test, lock):
    extras["original/" + name] = subprocess.check_output(["git", "show", "HEAD:" + name], cwd=c.ROOT)
assert sum(path.stat().st_size for path in paths.values()) + sum(map(len, extras.values())) < 32 * 1024 * 1024
manifest = {name: {"bytes": path.stat().st_size, "sha256": c.sha(path)}
            for name, path in sorted(paths.items())}
manifest.update({name: {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
                 for name, data in extras.items()})
manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
target = c.ROOT / "docs/benchmarks/evidence/native-engine-integration-fixes-2026-10-07.tar.xz"
assert not target.exists()
with tarfile.open(target, "x:xz", preset=6) as archive:
    for name, item in sorted(manifest.items()):
        info = tarfile.TarInfo(name)
        info.size = item["bytes"]
        info.mode = 0o644
        if name in paths:
            with paths[name].open("rb") as stream:
                archive.addfile(info, stream)
        else:
            archive.addfile(info, io.BytesIO(extras[name]))
    info = tarfile.TarInfo("manifest.json")
    info.size = len(manifest_bytes)
    info.mode = 0o644
    archive.addfile(info, io.BytesIO(manifest_bytes))
with tarfile.open(target, "r:xz") as archive:
    assert len(archive.getmembers()) == len(manifest) + 1
    assert {item.name for item in archive.getmembers()} == set(manifest) | {"manifest.json"}
    assert archive.extractfile("manifest.json").read() == manifest_bytes
    for name, expected in manifest.items():
        with archive.extractfile(name) as stream:
            assert hashlib.file_digest(stream, "sha256").hexdigest() == expected["sha256"]
        assert archive.getmember(name).size == expected["bytes"]
assert c.source_hashes() == checked["source_hashes"]
receipt = {
    "schema_version": "shardloom.native_engine_integration_adjustments.v1",
    "status": "passed_local_repairs_pending_hosted_checks",
    "pull_request": "https://github.com/depsilon/shardloom/pull/1526",
    "original_pr_head": c.git("rev-parse", "HEAD"),
    "accepted_runtime_commit": checked["accepted_runtime_commit"],
    "accepted_source_identity_sha256": checked["accepted_source_identity_sha256"],
    "integration_source_identity_sha256": checked["integration_source_identity_sha256"],
    "source_assets": checked["source_assets"],
    "unchanged_source_assets": checked["source_assets"] - 1,
    "changed_source_assets": checked["changed_source_assets"],
    "production_source_assets_unchanged": True,
    "cpu_test_correction": {
        "original_hosted_failure": "https://github.com/depsilon/shardloom/actions/runs/37564148025/job/112607915036",
        "cause": "Test expected requested parallelism 8 on a four-CPU runner; the native runtime correctly admitted only 4.",
        "local_reproduction": "The existing assertion failed for requested 11 on a ten-CPU host.",
        "correction": "Retain the requested count, assert the applied CPU cap and derived worker/lookahead counts, and always include a request above available capacity.",
        "pressure_tests_passed": 11,
        "test_module_gate": "cfg(all(test, feature = vortex-write, feature = universal-format-io))",
        "row_schema_memory_release_cleanup_assertions_preserved": True,
    },
    "website_dependency_correction": {
        "original_hosted_failure": "https://github.com/depsilon/shardloom/actions/runs/37564148025/job/112607915203",
        "advisory": site["advisory"], "official_release": site["official_release"],
        "sharp_before": site["old_sharp"], "sharp_after": site["new_sharp"],
        "changed_lock_packages": site["changed_lock_packages"],
        "new_package_keys_or_licenses": False,
        "audit_vulnerabilities_after": site["audit_vulnerabilities_after"],
        "package_version_unchanged": site["package_version_unchanged"],
        "generated_website_bytes_unchanged": True,
    },
    "local_checks": [item["name"] for item in checked["checks"]],
    "website_checks": [item["name"] for item in site["checks"] if item["name"] != "audit-before"],
    "preserved_counterevidence": ["two hosted failures", "local CPU-cap reproduction", "initial website audit", "initial formatting failure"],
    "prior_acceptance_boundary": checked["prior_full_acceptance_scope"],
    "hosted_complete_checks": "pending_updated_head",
    "archive": {"path": str(target.relative_to(c.ROOT)), "bytes": target.stat().st_size,
                "sha256": c.sha(target), "members": len(manifest),
                "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
                "all_members_reopened_and_hash_checked": True},
    "driver_sha256": c.sha(__file__),
}
before_lock = json.loads(extras["original/" + lock])
after_lock = json.loads((c.ROOT / lock).read_text())
assert before_lock["packages"].keys() == after_lock["packages"].keys()
assert all(before_lock["packages"][key].get("license") == value.get("license")
           for key, value in after_lock["packages"].items())
assert not c.git("diff", "--name-only", "HEAD", "--", "website", "website-src/src", "website-src/scripts")
c.write(target.with_name("native-engine-integration-fixes-2026-10-07.json"), receipt)
print(json.dumps({"status": "passed", "members": len(manifest), "bytes": target.stat().st_size,
                  "sha256": receipt["archive"]["sha256"]}), flush=True)
