//! Feature-gated local `vortex_ingest` lifecycle helpers.
//!
//! This module intentionally exposes a narrow local prepare-once path for flat
//! scalar rows. It writes a local Vortex artifact, reopens/scans the artifact
//! for row-count proof, and returns evidence fields that callers can surface as
//! a `VortexPreparedState`. It is not a broad Vortex writer, object-store sink,
//! table commit path, or query-engine integration.

use std::{
    collections::BTreeMap,
    fmt::Write as _,
    fs,
    io::Read as _,
    path::{Path, PathBuf},
    time::UNIX_EPOCH,
};

#[cfg(feature = "vortex-write")]
use std::{
    cell::{Cell, RefCell},
    collections::BTreeSet,
    sync::{
        Arc,
        atomic::{AtomicU64, Ordering},
    },
    time::Instant,
};

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
use std::sync::{OnceLock, atomic::AtomicUsize};

#[cfg(all(test, feature = "vortex-write", feature = "universal-format-io"))]
use std::sync::Mutex;

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
use shardloom_exec::{
    compute_pool::{CancellationToken, ComputePool, ComputeTask, WorkerContext},
    live_memory::{Budgeted, LiveMemoryPool, MemoryLease},
};

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
use arrow_array::{
    Array, ArrayRef as ArrowArrayRef, BinaryArray, BinaryViewArray, BooleanArray, Date32Array,
    Float32Array, Float64Array, Int8Array, Int16Array, Int32Array, Int64Array, LargeBinaryArray,
    LargeStringArray, RecordBatch, StringArray, StringViewArray, TimestampMicrosecondArray,
    UInt8Array, UInt16Array, UInt32Array, UInt64Array, cast::AsArray as _,
};
#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
use arrow_schema::DataType as ArrowDataType;
use sha2::Digest as _;
use shardloom_core::{
    LogicalDType, Result, ScalarValue, ShardLoomError, WorkspaceSafeLocalWriteReport,
};
use shardloom_exec::{
    OperatorMemoryClass, PulseWeaveInput, PulseWeaveReport, PulseWeaveTaskShape, plan_pulseweave,
};

#[path = "vortex_ingest_stage_timing.rs"]
mod stage_timing;
pub use stage_timing::VortexIngestStageReport;
#[cfg(feature = "vortex-write")]
use stage_timing::{IngestStageTimings, Stage};

#[cfg(feature = "vortex-write")]
#[path = "vortex_ingest_numeric_encoding.rs"]
mod numeric_encoding;

#[cfg(feature = "vortex-write")]
#[path = "vortex_ingest_nested_layout.rs"]
mod nested_layout;

#[cfg(all(test, feature = "vortex-write"))]
#[path = "vortex_ingest_text_stats_tests.rs"]
mod text_stats_tests;

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
use crate::universal_format_io::{
    FlatLocalColumnarSource, FlatLocalColumnarStreamSource, SourceIdentity,
};

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
#[path = "ingest_arrow_ownership.rs"]
mod arrow_ownership;
#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
#[path = "ingest_bounded_layout.rs"]
pub(crate) mod bounded_ingest_layout;
#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
#[path = "vortex_ingest_nested.rs"]
mod nested;

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
#[path = "vortex_ingest_column_layout.rs"]
mod column_layout;

#[cfg(all(test, feature = "vortex-write", feature = "universal-format-io"))]
#[path = "vortex_ingest_column_layout_tests.rs"]
mod column_layout_tests;

#[cfg(feature = "vortex-write")]
#[path = "vortex_ingest_dictionary_preservation.rs"]
mod dictionary_preservation;

#[cfg(all(
    test,
    feature = "vortex-write",
    feature = "universal-format-io",
    feature = "vortex-local-primitives",
    unix
))]
#[path = "vortex_ingest_text_codec_portfolio.rs"]
mod text_codec_portfolio;

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
#[derive(Clone)]
struct NativeIngestMemory {
    pool: LiveMemoryPool,
    session: vortex::session::VortexSession,
    max_chunks: usize,
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
impl NativeIngestMemory {
    #[cfg(test)]
    fn new(limit_bytes: u64) -> Result<Self> {
        Self::with_runtime(limit_bytes, None)
    }

    fn with_runtime(
        limit_bytes: u64,
        runtime: Option<&crate::ingest_runtime::IngestRuntime>,
    ) -> Result<Self> {
        use vortex::{
            VortexSessionDefault as _, array::memory::MemorySessionExt as _,
            io::runtime::BlockingRuntime as _, io::session::RuntimeSessionExt as _,
        };
        let pool = LiveMemoryPool::new(limit_bytes)?;
        let handle = runtime.map_or_else(
            || LOCAL_VORTEX_WRITE_CONTEXT.with(|context| context.borrow().runtime.handle()),
            |runtime| runtime.runtime().handle(),
        );
        // An artifact session shares its source/writer executor, with its own
        // allocator admission. Session clones must not mutate another artifact.
        let session = vortex::session::VortexSession::default()
            .with_handle(handle)
            .with_allocator(Arc::new(crate::owned_buffers::ReservedHostAllocator::new(
                pool.clone(),
            )));
        Ok(Self {
            pool,
            session,
            max_chunks: usize::try_from(
                limit_bytes
                    / u64::try_from(std::mem::size_of::<vortex::layout::LayoutRef>())
                        .unwrap_or(u64::MAX),
            )
            .unwrap_or(usize::MAX),
        })
    }

    fn reserve_input(&self, slots: usize) -> Result<MemoryLease> {
        let bytes =
            self.pool.snapshot().limit_bytes / 4 / u64::try_from(slots.max(1)).unwrap_or(u64::MAX);
        if bytes == 0 {
            return Err(ShardLoomError::InvalidOperation("native ingest budget cannot admit an input slot; no fallback execution was attempted".to_string()));
        }
        self.pool.reserve(bytes)
    }
}

/// Evidence schema emitted by the local Vortex preparation spine.
pub const VORTEX_PREPARATION_SPINE_SCHEMA_VERSION: &str = "shardloom.vortex_preparation_spine.v1";
/// Evidence schema emitted by scoped local differential Vortex preparation overlays.
pub const VORTEX_DIFFERENTIAL_PREPARATION_SCHEMA_VERSION: &str =
    "shardloom.vortex_differential_preparation.v1";
/// Evidence schema emitted by automatic append-only differential refinement manifests.
pub const VORTEX_DIFFERENTIAL_REFINEMENT_MANIFEST_SCHEMA_VERSION: &str =
    "shardloom.vortex_differential_refinement_manifest.v1";
/// Admission policy for automatic local append-only prepared-state refinement.
pub const VORTEX_DIFFERENTIAL_REFINEMENT_POLICY: &str =
    "artifact_adjacent_append_only_prepared_state_refinement.v1";
/// Evidence schema emitted by scoped local capillary cold-preparation task control.
pub const VORTEX_CAPILLARY_PREPARATION_SCHEMA_VERSION: &str =
    "shardloom.vortex_capillary_preparation.v1";
const VORTEX_CAPILLARY_ACTIVATION_POLICY: &str = "dynamic_size_complexity_gate.v1";
const VORTEX_CAPILLARY_ACTIVATION_THRESHOLD_BYTES: u64 = 64 * 1024 * 1024;
const VORTEX_CAPILLARY_ACTIVATION_THRESHOLD_ROWS: u64 = 1_000_000;
const VORTEX_CAPILLARY_ACTIVATION_THRESHOLD_SPLITS: usize = 8;
const VORTEX_CAPILLARY_ACTIVATION_THRESHOLD_COLUMNS: usize = 64;
const VORTEX_CAPILLARY_ACTIVATION_THRESHOLD_ROW_COLUMN_PRODUCT: u64 = 32_000_000;
const VORTEX_CAPILLARY_ACTIVATION_MEMORY_PRESSURE_DENOMINATOR: u64 = 4;
/// Evidence schema emitted by scoped local scout ingress and triage.
pub const VORTEX_SCOUT_INGRESS_SCHEMA_VERSION: &str = "shardloom.vortex_scout_ingress.v1";
/// Evidence schema emitted by product local layout/write advisor checks.
pub const VORTEX_LAYOUT_WRITE_ADVISOR_SCHEMA_VERSION: &str =
    "shardloom.vortex_layout_write_advisor.v1";
/// Evidence schema emitted by the writer physical-design planner that applies
/// admitted layout/write decisions to Vortex writer and streaming-feed knobs.
pub const VORTEX_WRITER_PHYSICAL_DESIGN_SCHEMA_VERSION: &str =
    "shardloom.vortex_writer_physical_design.v1";
/// Evidence schema emitted by the reusable segment-metadata primitive used by
/// prepared Vortex query planning.
pub const VORTEX_SEGMENT_METADATA_PRIMITIVE_SCHEMA_VERSION: &str =
    "shardloom.vortex_segment_metadata_primitive.v1";
/// Evidence schema emitted by product local copy-budget and buffer-lifecycle checks.
pub const VORTEX_COPY_BUDGET_SCHEMA_VERSION: &str = "shardloom.vortex_copy_budget.v1";
/// Evidence schema emitted by scoped local prepared-state reuse manifests.
pub const VORTEX_PREPARED_STATE_REUSE_SCHEMA_VERSION: &str =
    "shardloom.vortex_prepared_state_reuse_manifest.v1";
/// Evidence schema emitted by exact prepared OLAP state manifests.
pub const VORTEX_PREPARED_OLAP_STATE_SCHEMA_VERSION: &str =
    "shardloom.vortex_prepared_olap_state.v1";
/// Evidence schema emitted for the local prepared-state read-through index view.
pub const VORTEX_PREPARED_STATE_REUSE_INDEX_SCHEMA_VERSION: &str =
    "shardloom.vortex_prepared_state_reuse_index.v1";
/// Admission policy for artifact-adjacent prepared-state reuse manifests.
pub const VORTEX_PREPARED_STATE_REUSE_POLICY: &str =
    "artifact_adjacent_local_prepared_state_reuse.v1";
/// Evidence schema emitted when an existing local Vortex artifact is admitted
/// as a prepared state without compatibility source parsing.
pub const VORTEX_NATIVE_ARTIFACT_PREPARE_SCHEMA_VERSION: &str =
    "shardloom.vortex_native_artifact_prepare.v1";
/// Admission policy for generic OLAP layout/statistics evidence attached to a
/// single prepared Vortex artifact.
pub const VORTEX_PREPARED_OLAP_STATE_POLICY: &str =
    "single_vortex_artifact_embedded_olap_layout_statistics.v1";
/// Admission policy for the public local prepare-once Vortex writer route.
///
/// This is product runtime policy, not a benchmark or smoke-only route. Fixture
/// and smoke language stays on the lower-level diagnostic commands only.
pub const VORTEX_PRODUCT_LOCAL_INGEST_PREPARE_ONCE_ADMISSION_POLICY: &str =
    "product_local_vortex_ingest_prepare_once";
const VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_LAYOUT_POLICY: &str =
    "single_vortex_artifact_embedded_vortex_layout_statistics_v1";
const VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_SEGMENT_MAP_STATUS: &str =
    "embedded_vortex_layout_footer_statistics";
const VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_QUERY_TIME_CONTRACT: &str =
    "single_vortex_artifact_native_runtime_no_query_answer_sidecar";
const VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_MODEL: &str = "single_prepared_vortex_artifact";
const VORTEX_PREPARED_OLAP_METADATA_PRUNING_CONTRACT: &str =
    "metadata_first_when_vortex_layout_statistics_are_available_no_query_answer_cache";
const VORTEX_PREPARED_OLAP_QUERY_ANSWER_SIDECAR_STATUS: &str =
    "disabled_rejected_for_public_default_runtime";
const VORTEX_PREPARED_OLAP_WRITER_LAYOUT_STRATEGY: &str =
    "upstream_vortex_write_strategy_table_repartition_zoned_stats_dictionary_compressed_layout";
#[cfg(feature = "vortex-write")]
const VORTEX_PREPARED_OLAP_WRITER_DEFAULT_ROW_BLOCK_SIZE: usize = 8192;
#[cfg(feature = "vortex-write")]
const VORTEX_PREPARED_OLAP_WRITER_FINE_ROW_BLOCK_SIZE: usize = 4096;
#[cfg(feature = "vortex-write")]
const VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_BLOCK_SIZE: usize =
    crate::local_primitives::VortexLocalPrimitiveResourceEnvelope::DEFAULT_WRITER_ROW_BLOCK_TARGET_ROWS;
#[cfg(feature = "vortex-write")]
const VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_THRESHOLD: u64 = 10_000_000;
#[cfg(feature = "vortex-write")]
const VORTEX_PREPARED_OLAP_WRITER_ONE_MIB: u64 = 1 << 20;
#[cfg(feature = "vortex-write")]
const VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_BLOCK_TARGET_BYTES: u64 =
    VORTEX_PREPARED_OLAP_WRITER_ONE_MIB;
#[cfg(feature = "vortex-write")]
const VORTEX_PREPARED_OLAP_WRITER_FAST_LOAD_BLOCK_TARGET_BYTES: u64 =
    crate::local_primitives::VortexLocalPrimitiveResourceEnvelope::DEFAULT_WRITER_COALESCING_TARGET_BYTES
        as u64;
#[cfg(feature = "vortex-write")]
const VORTEX_PREPARED_OLAP_WRITER_LARGE_TEXT_COALESCED_SOURCE_BYTES: u64 =
    8 * 1024 * VORTEX_PREPARED_OLAP_WRITER_ONE_MIB;
#[cfg(feature = "vortex-write")]
const VORTEX_PREPARED_OLAP_WRITER_LARGE_TEXT_COALESCED_BLOCK_TARGET_BYTES: u64 =
    VORTEX_PREPARED_OLAP_WRITER_FAST_LOAD_BLOCK_TARGET_BYTES;
#[cfg(feature = "vortex-write")]
const VORTEX_PREPARED_OLAP_WRITER_DEFAULT_COMPRESSION_CONCURRENCY: usize = 0;
#[cfg(feature = "vortex-write")]
const VORTEX_PREPARED_OLAP_WRITER_FAST_LOAD_LARGE_SOURCE_COMPRESSION_CONCURRENCY: usize = 1;
#[cfg(feature = "vortex-write")]
const VORTEX_PREPARED_OLAP_WRITER_DEFAULT_STATS_CONCURRENCY: usize = 1;
#[cfg(feature = "vortex-write")]
const VORTEX_PREPARED_OLAP_WRITER_DEFAULT_COMPRESSION_POLICY: &str =
    "vortex_default_btrblocks_available_parallelism";
#[cfg(feature = "vortex-write")]
const VORTEX_PREPARED_OLAP_WRITER_FAST_LOAD_LARGE_SOURCE_COMPRESSION_POLICY: &str =
    "vortex_large_source_fast_load_numeric_btrblocks_uncompressed_statistics";
#[cfg(feature = "vortex-write")]
const VORTEX_PREPARED_OLAP_WRITER_BALANCED_LARGE_SOURCE_COMPRESSION_POLICY: &str =
    "vortex_large_source_balanced_zstd_layout_statistics";
#[cfg(feature = "vortex-write")]
const VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_LARGE_SOURCE_COMPRESSION_POLICY: &str =
    "vortex_large_source_text_fast_zstd_no_dict_numeric_btrblocks_layout_statistics";
#[cfg(feature = "vortex-write")]
const VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_ZSTD_FAST_LEVEL: i32 = -3;
#[cfg(feature = "vortex-write")]
const VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_ZSTD_VALUES_PER_FRAME: usize = 8_192;
#[cfg(feature = "vortex-write")]
const VORTEX_PREPARED_OLAP_LARGE_REOPEN_DEFER_BYTES: u64 =
    1024 * VORTEX_PREPARED_OLAP_WRITER_ONE_MIB;
const VORTEX_PREPARED_OLAP_LAYOUT_INVENTORY_DEFERRED_STATUS: &str =
    "writer_summary_single_vortex_artifact_layout_inventory_deferred";
#[cfg(feature = "vortex-write")]
const VORTEX_PREPARED_OLAP_REOPEN_DEFERRED_STATUS: &str =
    "writer_summary_row_count_verified_layout_inventory_deferred";
const VORTEX_PREPARED_OLAP_DICTIONARY_METADATA_POLICY: &str =
    "preserve_vortex_dictionary_and_encoding_metadata_when_writer_emits_it";
const VORTEX_SEGMENT_METADATA_NO_FALSE_NEGATIVE_POLICY: &str =
    "unknown_or_inconclusive_segments_are_read_no_false_negative_pruning";
const VORTEX_SEGMENT_METADATA_QUERY_USE_POLICY: &str = "metadata_first_pruning_uses_footer_statistics_only_when_admitted_else_read_or_open_query_footer";
#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
const VORTEX_STREAM_ARRAY_PREFETCH_MAX_WINDOW: usize = 4;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VortexPreparedOlapLayoutInventory {
    pub status: String,
    pub row_count: Option<u64>,
    pub segment_count: Option<usize>,
    pub statistics_status: String,
    pub encoding_layout_status: String,
    pub artifact_size_bytes: Option<u64>,
    pub approx_footer_bytes: Option<usize>,
    pub dtype_summary: String,
    pub root_layout_encoding: String,
    pub layout_encoding_inventory: String,
    pub per_column_metadata_contract: String,
    pub segment_membership_status: String,
    pub domain_dictionary_status: String,
    pub derived_layout_stats_status: String,
    pub row_position_locality_status: String,
    pub layout_reader_cache_status: String,
    pub metadata_persisted_in_artifact: bool,
    pub operator_selection_metadata_status: String,
    pub layout_size_attribution: String,
    pub inventory_digest: String,
}

impl VortexPreparedOlapLayoutInventory {
    #[must_use]
    fn unavailable(status: impl Into<String>) -> Self {
        let status = status.into();
        let inventory_digest =
            fnv64_digest_text(&format!("prepared_olap_layout_inventory|{status}"));
        Self {
            status,
            row_count: None,
            segment_count: None,
            statistics_status: "not_available".to_string(),
            encoding_layout_status: "not_available".to_string(),
            artifact_size_bytes: None,
            approx_footer_bytes: None,
            dtype_summary: "not_available".to_string(),
            root_layout_encoding: "not_available".to_string(),
            layout_encoding_inventory: "not_available".to_string(),
            per_column_metadata_contract: "not_available".to_string(),
            segment_membership_status: "not_available".to_string(),
            domain_dictionary_status: "not_available".to_string(),
            derived_layout_stats_status: "not_available".to_string(),
            row_position_locality_status: "not_available".to_string(),
            layout_reader_cache_status: "not_available".to_string(),
            metadata_persisted_in_artifact: false,
            operator_selection_metadata_status: "per_column_metadata_not_available".to_string(),
            layout_size_attribution: "not_available".to_string(),
            inventory_digest,
        }
    }

    #[cfg(feature = "vortex-write")]
    #[must_use]
    fn deferred_from_writer_summary(
        path: &Path,
        row_count: u64,
        bytes_written: u64,
        layout_write_decision: &VortexLayoutWriteRuntimeDecision,
    ) -> Self {
        let artifact_size_bytes = std::fs::metadata(path)
            .ok()
            .map_or(Some(bytes_written), |metadata| Some(metadata.len()));
        let writer_layout = vortex_writer_layout_strategy_applied(layout_write_decision);
        let writer_policy = vortex_writer_compression_policy(layout_write_decision);
        let layout_size_attribution = format!(
            "artifact_bytes_from_workspace_write;footer_inventory_deferred_until_query_open;writer_layout={writer_layout};compression_policy={writer_policy};single_vortex_artifact=true",
        );
        let inventory_digest = fnv64_digest_text(&format!(
            "prepared_olap_layout_inventory|{}|{}|{}|{}|{}|{}",
            VORTEX_PREPARED_OLAP_LAYOUT_INVENTORY_DEFERRED_STATUS,
            row_count,
            artifact_size_bytes.map_or_else(|| "unknown".to_string(), |value| value.to_string()),
            writer_layout,
            writer_policy,
            layout_write_decision.strategy_decision_digest
        ));
        Self {
            status: VORTEX_PREPARED_OLAP_LAYOUT_INVENTORY_DEFERRED_STATUS.to_string(),
            row_count: Some(row_count),
            segment_count: None,
            statistics_status: "deferred_until_query_open".to_string(),
            encoding_layout_status: "writer_strategy_recorded_inventory_deferred".to_string(),
            artifact_size_bytes,
            approx_footer_bytes: None,
            dtype_summary: "deferred_until_query_open".to_string(),
            root_layout_encoding: "deferred_until_query_open".to_string(),
            layout_encoding_inventory: writer_layout.to_string(),
            per_column_metadata_contract: "deferred_until_query_open".to_string(),
            segment_membership_status: "deferred_until_query_open".to_string(),
            domain_dictionary_status: "deferred_until_query_open".to_string(),
            derived_layout_stats_status: "writer_strategy_recorded_deferred_until_query_open"
                .to_string(),
            row_position_locality_status: "deferred_until_query_open".to_string(),
            layout_reader_cache_status: "deferred_for_large_artifact_public_prepare".to_string(),
            metadata_persisted_in_artifact: true,
            operator_selection_metadata_status: "deferred_until_query_open".to_string(),
            layout_size_attribution,
            inventory_digest,
        }
    }

    #[must_use]
    fn is_admitted(&self) -> bool {
        matches!(
            self.status.as_str(),
            "opened_single_vortex_artifact_footer"
                | VORTEX_PREPARED_OLAP_LAYOUT_INVENTORY_DEFERRED_STATUS
        )
    }

    #[must_use]
    pub fn row_count_field(&self) -> String {
        self.row_count
            .map_or_else(|| "unknown".to_string(), |value| value.to_string())
    }

    #[must_use]
    pub fn segment_count_field(&self) -> String {
        self.segment_count
            .map_or_else(|| "unknown".to_string(), |value| value.to_string())
    }

    #[must_use]
    pub fn approx_footer_bytes_field(&self) -> String {
        self.approx_footer_bytes
            .map_or_else(|| "unknown".to_string(), |value| value.to_string())
    }

    #[must_use]
    pub fn artifact_size_bytes_field(&self) -> String {
        self.artifact_size_bytes
            .map_or_else(|| "unknown".to_string(), |value| value.to_string())
    }
}

/// Query-family consumers supported by the prepared Vortex segment-metadata
/// primitive. These are admission categories, not external engine routes.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VortexSegmentMetadataQueryFamily {
    MetadataCount,
    PredicatePruning,
    GroupAggregation,
    TopKRowPosition,
    DictionaryDistinct,
}

impl VortexSegmentMetadataQueryFamily {
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::MetadataCount => "metadata_count",
            Self::PredicatePruning => "predicate_pruning",
            Self::GroupAggregation => "group_aggregation",
            Self::TopKRowPosition => "topk_row_position",
            Self::DictionaryDistinct => "dictionary_distinct",
        }
    }
}

/// Conservative segment-metadata contract derived from a prepared Vortex
/// artifact footer or from a deferred large-artifact writer summary.
#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct VortexSegmentMetadataPrimitiveReport {
    pub schema_version: &'static str,
    pub status: String,
    pub primitive_id: String,
    pub source: String,
    pub inventory_status: String,
    pub inventory_digest: String,
    pub writer_physical_design_digest: String,
    pub row_count: Option<u64>,
    pub segment_count: Option<usize>,
    pub row_count_proven: bool,
    pub segment_count_proven: bool,
    pub statistics_status: String,
    pub row_range_coverage: String,
    pub physical_byte_range_status: String,
    pub null_count_status: String,
    pub min_max_status: String,
    pub byte_length_bounds_status: String,
    pub dictionary_membership_status: String,
    pub domain_absence_status: String,
    pub cardinality_sketch_status: String,
    pub row_position_locality_status: String,
    pub encoded_layout_status: String,
    pub per_column_metadata_contract: String,
    pub metadata_read_plan: String,
    pub query_use_policy: String,
    pub predicate_pruning_admission: String,
    pub group_by_admission: String,
    pub topk_admission: String,
    pub dictionary_distinct_admission: String,
    pub metadata_count_admission: String,
    pub no_false_negative_policy: String,
    pub query_answer_sidecar_status: String,
    pub segment_metadata_digest: String,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

impl VortexSegmentMetadataPrimitiveReport {
    #[must_use]
    #[allow(clippy::too_many_lines)]
    pub fn from_inventory(
        inventory: &VortexPreparedOlapLayoutInventory,
        source: impl Into<String>,
        writer_physical_design_digest: impl Into<String>,
    ) -> Self {
        let source = source.into();
        let writer_physical_design_digest = writer_physical_design_digest.into();
        let row_count_proven = inventory.row_count.is_some();
        let segment_count_proven = inventory.segment_count.is_some();
        let statistics_admitted = inventory.statistics_status == "available";
        let inventory_deferred = inventory.status
            == VORTEX_PREPARED_OLAP_LAYOUT_INVENTORY_DEFERRED_STATUS
            || inventory.statistics_status == "deferred_until_query_open";
        let status = segment_metadata_primitive_status(inventory, statistics_admitted);
        let row_range_coverage = segment_metadata_row_range_coverage(inventory);
        let physical_byte_range_status =
            segment_metadata_physical_byte_range_status(inventory, inventory_deferred);
        let null_count_status =
            segment_metadata_null_count_status(inventory, statistics_admitted, inventory_deferred);
        let min_max_status =
            segment_metadata_min_max_status(inventory, statistics_admitted, inventory_deferred);
        let byte_length_bounds_status = segment_metadata_byte_length_bounds_status(
            inventory,
            statistics_admitted,
            inventory_deferred,
        );
        let dictionary_membership_status =
            segment_metadata_dictionary_membership_status(inventory, inventory_deferred);
        let domain_absence_status = segment_metadata_domain_absence_status(
            inventory,
            statistics_admitted,
            inventory_deferred,
        );
        let cardinality_sketch_status =
            segment_metadata_cardinality_sketch_status(inventory, statistics_admitted);
        let metadata_read_plan =
            segment_metadata_read_plan(inventory, statistics_admitted, inventory_deferred);
        let metadata_count_admission =
            segment_metadata_count_admission(inventory, row_count_proven);
        let predicate_pruning_admission =
            segment_metadata_predicate_pruning_admission(inventory, statistics_admitted);
        let group_by_admission =
            segment_metadata_group_by_admission(inventory, statistics_admitted);
        let topk_admission = segment_metadata_topk_admission(inventory);
        let dictionary_distinct_admission =
            segment_metadata_dictionary_distinct_admission(inventory);
        let segment_metadata_digest = fnv64_digest_text(&format!(
            "vortex_segment_metadata_primitive|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}",
            status,
            source,
            inventory.status,
            inventory.inventory_digest,
            writer_physical_design_digest,
            inventory.row_count_field(),
            inventory.segment_count_field(),
            inventory.statistics_status,
            row_range_coverage,
            physical_byte_range_status,
            null_count_status,
            min_max_status,
            byte_length_bounds_status,
            dictionary_membership_status,
            domain_absence_status,
            cardinality_sketch_status,
            metadata_read_plan,
            predicate_pruning_admission,
            group_by_admission,
            topk_admission,
        ));

        Self {
            schema_version: VORTEX_SEGMENT_METADATA_PRIMITIVE_SCHEMA_VERSION,
            status,
            primitive_id: format!("segment-metadata-primitive-{segment_metadata_digest}"),
            source,
            inventory_status: inventory.status.clone(),
            inventory_digest: inventory.inventory_digest.clone(),
            writer_physical_design_digest,
            row_count: inventory.row_count,
            segment_count: inventory.segment_count,
            row_count_proven,
            segment_count_proven,
            statistics_status: inventory.statistics_status.clone(),
            row_range_coverage,
            physical_byte_range_status,
            null_count_status,
            min_max_status,
            byte_length_bounds_status,
            dictionary_membership_status,
            domain_absence_status,
            cardinality_sketch_status,
            row_position_locality_status: inventory.row_position_locality_status.clone(),
            encoded_layout_status: inventory.encoding_layout_status.clone(),
            per_column_metadata_contract: inventory.per_column_metadata_contract.clone(),
            metadata_read_plan,
            query_use_policy: VORTEX_SEGMENT_METADATA_QUERY_USE_POLICY.to_string(),
            predicate_pruning_admission,
            group_by_admission,
            topk_admission,
            dictionary_distinct_admission,
            metadata_count_admission,
            no_false_negative_policy: VORTEX_SEGMENT_METADATA_NO_FALSE_NEGATIVE_POLICY.to_string(),
            query_answer_sidecar_status: VORTEX_PREPARED_OLAP_QUERY_ANSWER_SIDECAR_STATUS
                .to_string(),
            segment_metadata_digest,
            fallback_attempted: false,
            external_engine_invoked: false,
        }
    }

    #[must_use]
    pub fn row_count_field(&self) -> String {
        self.row_count
            .map_or_else(|| "unknown".to_string(), |value| value.to_string())
    }

    #[must_use]
    pub fn segment_count_field(&self) -> String {
        self.segment_count
            .map_or_else(|| "unknown".to_string(), |value| value.to_string())
    }

    #[must_use]
    pub fn is_metadata_count_admitted(&self) -> bool {
        self.metadata_count_admission
            .starts_with("admitted_metadata_count")
    }

    #[must_use]
    pub fn is_predicate_pruning_admitted(&self) -> bool {
        self.predicate_pruning_admission
            .starts_with("admitted_conservative")
    }

    #[must_use]
    pub fn requires_query_open(&self) -> bool {
        self.status.contains("deferred") || self.metadata_read_plan.contains("query_open")
    }

    #[must_use]
    pub fn must_read_inconclusive_segments(&self) -> bool {
        self.no_false_negative_policy == VORTEX_SEGMENT_METADATA_NO_FALSE_NEGATIVE_POLICY
    }

    #[must_use]
    pub fn admission_for_query_family(&self, family: VortexSegmentMetadataQueryFamily) -> &str {
        match family {
            VortexSegmentMetadataQueryFamily::MetadataCount => &self.metadata_count_admission,
            VortexSegmentMetadataQueryFamily::PredicatePruning => &self.predicate_pruning_admission,
            VortexSegmentMetadataQueryFamily::GroupAggregation => &self.group_by_admission,
            VortexSegmentMetadataQueryFamily::TopKRowPosition => &self.topk_admission,
            VortexSegmentMetadataQueryFamily::DictionaryDistinct => {
                &self.dictionary_distinct_admission
            }
        }
    }

    /// Return stable evidence fields for CLI/API surfaces.
    #[must_use]
    #[allow(clippy::too_many_lines)]
    pub fn evidence_fields(&self) -> Vec<(String, String)> {
        vec![
            (
                "vortex_segment_metadata_schema_version".to_string(),
                self.schema_version.to_string(),
            ),
            (
                "vortex_segment_metadata_status".to_string(),
                self.status.clone(),
            ),
            (
                "vortex_segment_metadata_primitive_id".to_string(),
                self.primitive_id.clone(),
            ),
            (
                "vortex_segment_metadata_source".to_string(),
                self.source.clone(),
            ),
            (
                "vortex_segment_metadata_inventory_status".to_string(),
                self.inventory_status.clone(),
            ),
            (
                "vortex_segment_metadata_inventory_digest".to_string(),
                self.inventory_digest.clone(),
            ),
            (
                "vortex_segment_metadata_writer_physical_design_digest".to_string(),
                self.writer_physical_design_digest.clone(),
            ),
            (
                "vortex_segment_metadata_row_count".to_string(),
                self.row_count_field(),
            ),
            (
                "vortex_segment_metadata_segment_count".to_string(),
                self.segment_count_field(),
            ),
            (
                "vortex_segment_metadata_row_count_proven".to_string(),
                self.row_count_proven.to_string(),
            ),
            (
                "vortex_segment_metadata_segment_count_proven".to_string(),
                self.segment_count_proven.to_string(),
            ),
            (
                "vortex_segment_metadata_statistics_status".to_string(),
                self.statistics_status.clone(),
            ),
            (
                "vortex_segment_metadata_row_range_coverage".to_string(),
                self.row_range_coverage.clone(),
            ),
            (
                "vortex_segment_metadata_physical_byte_range_status".to_string(),
                self.physical_byte_range_status.clone(),
            ),
            (
                "vortex_segment_metadata_null_count_status".to_string(),
                self.null_count_status.clone(),
            ),
            (
                "vortex_segment_metadata_min_max_status".to_string(),
                self.min_max_status.clone(),
            ),
            (
                "vortex_segment_metadata_byte_length_bounds_status".to_string(),
                self.byte_length_bounds_status.clone(),
            ),
            (
                "vortex_segment_metadata_dictionary_membership_status".to_string(),
                self.dictionary_membership_status.clone(),
            ),
            (
                "vortex_segment_metadata_domain_absence_status".to_string(),
                self.domain_absence_status.clone(),
            ),
            (
                "vortex_segment_metadata_cardinality_sketch_status".to_string(),
                self.cardinality_sketch_status.clone(),
            ),
            (
                "vortex_segment_metadata_row_position_locality_status".to_string(),
                self.row_position_locality_status.clone(),
            ),
            (
                "vortex_segment_metadata_encoded_layout_status".to_string(),
                self.encoded_layout_status.clone(),
            ),
            (
                "vortex_segment_metadata_per_column_contract".to_string(),
                self.per_column_metadata_contract.clone(),
            ),
            (
                "vortex_segment_metadata_read_plan".to_string(),
                self.metadata_read_plan.clone(),
            ),
            (
                "vortex_segment_metadata_query_use_policy".to_string(),
                self.query_use_policy.clone(),
            ),
            (
                "vortex_segment_metadata_metadata_count_admission".to_string(),
                self.metadata_count_admission.clone(),
            ),
            (
                "vortex_segment_metadata_predicate_pruning_admission".to_string(),
                self.predicate_pruning_admission.clone(),
            ),
            (
                "vortex_segment_metadata_group_by_admission".to_string(),
                self.group_by_admission.clone(),
            ),
            (
                "vortex_segment_metadata_topk_admission".to_string(),
                self.topk_admission.clone(),
            ),
            (
                "vortex_segment_metadata_dictionary_distinct_admission".to_string(),
                self.dictionary_distinct_admission.clone(),
            ),
            (
                "vortex_segment_metadata_no_false_negative_policy".to_string(),
                self.no_false_negative_policy.clone(),
            ),
            (
                "vortex_segment_metadata_query_answer_sidecar_status".to_string(),
                self.query_answer_sidecar_status.clone(),
            ),
            (
                "vortex_segment_metadata_digest".to_string(),
                self.segment_metadata_digest.clone(),
            ),
            (
                "vortex_segment_metadata_fallback_attempted".to_string(),
                self.fallback_attempted.to_string(),
            ),
            (
                "vortex_segment_metadata_external_engine_invoked".to_string(),
                self.external_engine_invoked.to_string(),
            ),
        ]
    }
}

fn segment_metadata_primitive_status(
    inventory: &VortexPreparedOlapLayoutInventory,
    statistics_admitted: bool,
) -> String {
    if statistics_admitted && inventory.segment_count.is_some() && inventory.row_count.is_some() {
        "admitted_footer_segment_metadata".to_string()
    } else if inventory.status == VORTEX_PREPARED_OLAP_LAYOUT_INVENTORY_DEFERRED_STATUS {
        "deferred_until_query_open_writer_summary_row_count_only".to_string()
    } else if inventory.row_count.is_some() {
        "admitted_row_count_only_segment_metadata".to_string()
    } else {
        "blocked_segment_metadata_unavailable".to_string()
    }
}

fn segment_metadata_row_range_coverage(inventory: &VortexPreparedOlapLayoutInventory) -> String {
    if inventory.row_count.is_some() && inventory.segment_count.is_some() {
        "footer_segment_map_row_ranges_cover_all_rows".to_string()
    } else if inventory.row_count.is_some() {
        "writer_summary_row_count_known_segment_ranges_deferred".to_string()
    } else {
        "row_range_coverage_not_available".to_string()
    }
}

fn segment_metadata_physical_byte_range_status(
    inventory: &VortexPreparedOlapLayoutInventory,
    inventory_deferred: bool,
) -> String {
    if inventory_deferred {
        "deferred_until_query_open".to_string()
    } else if inventory.artifact_size_bytes.is_some() && inventory.segment_count.is_some() {
        "artifact_size_known_segment_byte_ranges_governed_by_vortex_footer".to_string()
    } else if inventory.artifact_size_bytes.is_some() {
        "artifact_size_known_segment_byte_ranges_not_available".to_string()
    } else {
        "not_available".to_string()
    }
}

fn segment_metadata_null_count_status(
    inventory: &VortexPreparedOlapLayoutInventory,
    statistics_admitted: bool,
    inventory_deferred: bool,
) -> String {
    if inventory_deferred {
        "deferred_until_query_open".to_string()
    } else if statistics_admitted {
        format!(
            "available_through_vortex_statistics_contract:{}",
            inventory.per_column_metadata_contract
        )
    } else {
        "not_available".to_string()
    }
}

fn segment_metadata_min_max_status(
    inventory: &VortexPreparedOlapLayoutInventory,
    statistics_admitted: bool,
    inventory_deferred: bool,
) -> String {
    if inventory_deferred {
        "deferred_until_query_open".to_string()
    } else if statistics_admitted {
        format!(
            "available_for_orderable_columns_through_vortex_statistics_contract:{}",
            inventory.per_column_metadata_contract
        )
    } else {
        "not_available".to_string()
    }
}

fn segment_metadata_byte_length_bounds_status(
    inventory: &VortexPreparedOlapLayoutInventory,
    statistics_admitted: bool,
    inventory_deferred: bool,
) -> String {
    if inventory_deferred {
        "deferred_until_query_open".to_string()
    } else if statistics_admitted && segment_metadata_has_dictionary_layout(inventory) {
        "available_for_encoded_text_columns_when_vortex_statistics_or_dictionary_layout_expose_lengths"
            .to_string()
    } else if statistics_admitted {
        "available_only_for_columns_with_vortex_statistics_bounds".to_string()
    } else {
        "not_available".to_string()
    }
}

fn segment_metadata_dictionary_membership_status(
    inventory: &VortexPreparedOlapLayoutInventory,
    inventory_deferred: bool,
) -> String {
    if inventory_deferred {
        "deferred_until_query_open".to_string()
    } else {
        inventory.domain_dictionary_status.clone()
    }
}

fn segment_metadata_domain_absence_status(
    inventory: &VortexPreparedOlapLayoutInventory,
    statistics_admitted: bool,
    inventory_deferred: bool,
) -> String {
    if inventory_deferred {
        "deferred_until_query_open".to_string()
    } else if statistics_admitted && segment_metadata_has_dictionary_layout(inventory) {
        "admitted_when_segment_dictionary_or_minmax_excludes_literal_domain".to_string()
    } else if statistics_admitted {
        "admitted_for_numeric_temporal_minmax_absence_only".to_string()
    } else {
        "not_admitted_without_footer_statistics".to_string()
    }
}

fn segment_metadata_cardinality_sketch_status(
    inventory: &VortexPreparedOlapLayoutInventory,
    statistics_admitted: bool,
) -> String {
    if segment_metadata_has_dictionary_layout(inventory) {
        "dictionary_domain_cardinality_candidate_no_query_answer_sidecar".to_string()
    } else if statistics_admitted {
        "not_available_without_dictionary_or_explicit_cardinality_statistics".to_string()
    } else if inventory.status == VORTEX_PREPARED_OLAP_LAYOUT_INVENTORY_DEFERRED_STATUS {
        "deferred_until_query_open".to_string()
    } else {
        "not_available".to_string()
    }
}

fn segment_metadata_read_plan(
    inventory: &VortexPreparedOlapLayoutInventory,
    statistics_admitted: bool,
    inventory_deferred: bool,
) -> String {
    if inventory_deferred {
        "query_open_footer_inventory_before_pruning;data_read=false;decode=false".to_string()
    } else if statistics_admitted {
        "prepared_footer_metadata_only;data_read=false;decode=false".to_string()
    } else if inventory.row_count.is_some() {
        "prepared_footer_row_count_only;segment_pruning_not_admitted".to_string()
    } else {
        "not_available".to_string()
    }
}

fn segment_metadata_count_admission(
    inventory: &VortexPreparedOlapLayoutInventory,
    row_count_proven: bool,
) -> String {
    if row_count_proven {
        "admitted_metadata_count_from_prepared_footer_or_writer_summary".to_string()
    } else if inventory.status == VORTEX_PREPARED_OLAP_LAYOUT_INVENTORY_DEFERRED_STATUS {
        "deferred_until_query_open".to_string()
    } else {
        "blocked_no_row_count_metadata".to_string()
    }
}

fn segment_metadata_predicate_pruning_admission(
    inventory: &VortexPreparedOlapLayoutInventory,
    statistics_admitted: bool,
) -> String {
    if statistics_admitted && inventory.segment_count.is_some() {
        "admitted_conservative_metadata_pruning_for_predicate_ranges_and_domain_absence".to_string()
    } else if inventory.status == VORTEX_PREPARED_OLAP_LAYOUT_INVENTORY_DEFERRED_STATUS {
        "deferred_until_query_open".to_string()
    } else {
        "blocked_no_segment_statistics".to_string()
    }
}

fn segment_metadata_group_by_admission(
    inventory: &VortexPreparedOlapLayoutInventory,
    statistics_admitted: bool,
) -> String {
    if segment_metadata_has_dictionary_layout(inventory) {
        "candidate_dictionary_membership_for_group_partitioning_read_inconclusive_segments"
            .to_string()
    } else if statistics_admitted {
        "metadata_count_only_group_aggregate_still_requires_native_value_scan".to_string()
    } else if inventory.status == VORTEX_PREPARED_OLAP_LAYOUT_INVENTORY_DEFERRED_STATUS {
        "deferred_until_query_open".to_string()
    } else {
        "blocked_no_group_relevant_segment_metadata".to_string()
    }
}

fn segment_metadata_topk_admission(inventory: &VortexPreparedOlapLayoutInventory) -> String {
    if inventory
        .row_position_locality_status
        .starts_with("source_ordinals_")
        && inventory.segment_count.is_some()
    {
        "candidate_row_position_locality_for_bounded_topk_prefilter_residual_heap_required"
            .to_string()
    } else if inventory.status == VORTEX_PREPARED_OLAP_LAYOUT_INVENTORY_DEFERRED_STATUS {
        "deferred_until_query_open".to_string()
    } else {
        "not_admitted_topk_requires_ordered_residual_state".to_string()
    }
}

fn segment_metadata_dictionary_distinct_admission(
    inventory: &VortexPreparedOlapLayoutInventory,
) -> String {
    if segment_metadata_has_dictionary_layout(inventory) {
        "candidate_dictionary_union_distinct_no_exact_result_sidecar".to_string()
    } else if inventory.status == VORTEX_PREPARED_OLAP_LAYOUT_INVENTORY_DEFERRED_STATUS {
        "deferred_until_query_open".to_string()
    } else {
        "blocked_no_dictionary_segment_metadata".to_string()
    }
}

fn segment_metadata_has_dictionary_layout(inventory: &VortexPreparedOlapLayoutInventory) -> bool {
    inventory.domain_dictionary_status == "vortex_dictionary_layout_present"
}

/// Pinned upstream Vortex crate line used by the scoped local preparation spine.
pub const VORTEX_PREPARATION_SPINE_VORTEX_CRATE_VERSION: &str =
    crate::UPSTREAM_VORTEX_PROVIDER_VERSION;

/// Request used to decide whether an existing local Vortex prepared artifact can
/// be reused without re-running compatibility preparation.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VortexPreparedStateReuseRequest {
    pub source_path: PathBuf,
    pub manifest_path: PathBuf,
    pub prepared_artifact_path: PathBuf,
    pub source_format: String,
    pub source_content_digest: String,
    pub source_size_bytes: u64,
    pub source_mtime_ns: String,
    pub source_schema_digest: Option<String>,
    pub parse_decode_plan_digest: String,
    pub selected_columns: String,
    pub output_policy: String,
    pub provider_version: String,
    pub feature_gates: String,
    pub certification_level: String,
}

/// Evidence attached when writing a prepared-state reuse manifest after a
/// successful local Vortex preparation.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VortexPreparedStateReuseWriteEvidence {
    pub source_state_id: String,
    pub source_state_digest: String,
    pub source_schema_digest: String,
    pub source_row_count: u64,
    pub source_column_family_summary: String,
    pub prepared_state_id: String,
    pub prepared_state_digest: String,
    pub prepared_artifact_digest: String,
    pub certificate_refs: String,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

/// Result of a prepared-state reuse lookup or manifest write.
#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct VortexPreparedStateReuseReport {
    pub schema_version: &'static str,
    pub status: String,
    pub scope: String,
    pub manifest_path: PathBuf,
    pub policy: &'static str,
    pub hit: bool,
    pub reason: String,
    pub manifest_digest: String,
    pub invalidation_reason: String,
    pub manifest_written: bool,
    pub source_path: PathBuf,
    pub source_format: String,
    pub source_content_digest: String,
    pub source_size_bytes: u64,
    pub source_mtime_ns: String,
    pub source_schema_digest: String,
    pub source_row_count: u64,
    pub source_column_family_summary: String,
    pub parse_decode_plan_digest: String,
    pub selected_columns: String,
    pub output_policy: String,
    pub prepared_artifact_ref: PathBuf,
    pub prepared_artifact_digest: String,
    pub prepared_artifact_size_bytes: u64,
    pub provider_version: String,
    pub feature_gates: String,
    pub certification_level: String,
    pub source_state_id: String,
    pub source_state_digest: String,
    pub prepared_state_id: String,
    pub prepared_state_digest: String,
    pub certificate_refs: String,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

/// Request to admit an existing local `.vortex` artifact as a prepared Vortex
/// state without parsing a compatibility source or rewriting encoded layouts.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VortexNativeArtifactPrepareRequest {
    pub source_path: PathBuf,
    pub target_path: PathBuf,
    pub allow_overwrite: bool,
    pub provider_version: String,
    pub feature_gates: String,
    pub certification_level: String,
}

/// Evidence for the Universal Ingest Vortex-source lane.
#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct VortexNativeArtifactPrepareReport {
    pub schema_version: &'static str,
    pub status: String,
    pub policy: String,
    pub source_path: PathBuf,
    pub target_path: PathBuf,
    pub source_size_bytes: u64,
    pub source_mtime_ns: String,
    pub source_content_digest: String,
    pub source_digest_source: String,
    pub target_size_bytes: u64,
    pub target_content_digest: String,
    pub target_digest_source: String,
    pub row_count: u64,
    pub prepared_olap_layout_inventory: VortexPreparedOlapLayoutInventory,
    pub segment_metadata_primitive: VortexSegmentMetadataPrimitiveReport,
    pub source_state_id: String,
    pub source_state_digest: String,
    pub prepared_state_id: String,
    pub prepared_state_digest: String,
    pub encoded_layout_preserved: bool,
    pub reencode_performed: bool,
    pub workspace_copy_performed: bool,
    pub same_artifact_passthrough: bool,
    pub upstream_vortex_scan_called: bool,
    pub upstream_vortex_write_called: bool,
    pub layout_rewrite_status: String,
    pub copy_budget_status: String,
    pub workspace_write_report: Option<WorkspaceSafeLocalWriteReport>,
    pub prepare_once_micros: u128,
    pub metadata_open_micros: u128,
    pub byte_copy_micros: u128,
    pub provider_version: String,
    pub feature_gates: String,
    pub certification_level: String,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

/// Request to derive content-addressed prepared OLAP state evidence.
///
/// Product prepared OLAP state is attached to the single prepared `.vortex`
/// artifact. The `manifest_path` field is retained only for compatibility with
/// earlier request plumbing; public/default runtime must not create or require
/// an adjacent OLAP manifest.
#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct VortexPreparedOlapStateWriteRequest {
    pub source_state_id: String,
    pub source_state_digest: String,
    pub source_format: String,
    pub source_content_digest: String,
    pub source_size_bytes: u64,
    pub source_schema_digest: String,
    pub source_row_count: u64,
    pub prepared_artifact_path: PathBuf,
    pub manifest_path: PathBuf,
    pub prepared_layout_policy: String,
    pub segment_map_status: String,
    pub derived_column_manifest: String,
    pub substring_index_manifest: String,
    pub aggregate_summary_manifest: String,
    pub row_position_manifest: String,
    pub dictionary_union_manifest: String,
    pub feature_gates: String,
    pub certification_level: String,
    pub certificate_refs: String,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

/// Published exact OLAP prepared-state evidence for one prepared Vortex artifact.
#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct VortexPreparedOlapStateReport {
    pub schema_version: &'static str,
    pub status: String,
    pub policy: &'static str,
    pub manifest_path: PathBuf,
    pub manifest_digest: String,
    pub manifest_written: bool,
    pub state_id: String,
    pub state_digest: String,
    pub source_state_id: String,
    pub source_state_digest: String,
    pub source_format: String,
    pub source_content_digest: String,
    pub source_size_bytes: u64,
    pub source_schema_digest: String,
    pub source_row_count: u64,
    pub prepared_artifact_ref: PathBuf,
    pub prepared_artifact_digest: String,
    pub prepared_artifact_size_bytes: u64,
    pub artifact_model: String,
    pub prepared_layout_policy: String,
    pub segment_map_status: String,
    pub writer_layout_strategy: String,
    pub embedded_layout_statistics_contract: String,
    pub layout_inventory_status: String,
    pub layout_inventory_digest: String,
    pub layout_footer_row_count: String,
    pub layout_footer_segment_count: String,
    pub layout_footer_statistics_status: String,
    pub layout_footer_encoding_layout_status: String,
    pub layout_artifact_size_bytes: String,
    pub layout_footer_approx_bytes: String,
    pub layout_footer_dtype_summary: String,
    pub layout_root_encoding: String,
    pub layout_encoding_inventory: String,
    pub layout_per_column_metadata_contract: String,
    pub layout_segment_membership_status: String,
    pub layout_domain_dictionary_status: String,
    pub layout_derived_stats_status: String,
    pub layout_row_position_locality_status: String,
    pub layout_reader_cache_status: String,
    pub layout_metadata_persisted_in_artifact: bool,
    pub layout_operator_selection_metadata_status: String,
    pub layout_size_attribution: String,
    pub dictionary_metadata_policy: String,
    pub metadata_pruning_contract: String,
    pub query_answer_sidecar_status: String,
    pub derived_column_manifest: String,
    pub substring_index_manifest: String,
    pub aggregate_summary_manifest: String,
    pub row_position_manifest: String,
    pub dictionary_union_manifest: String,
    pub admitted_query_families: String,
    pub exact_sidecar_family_count: usize,
    pub query_time_contract: String,
    pub sub_second_candidate: bool,
    pub blocker_id: String,
    pub next_action: String,
    pub feature_gates: String,
    pub certification_level: String,
    pub certificate_refs: String,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

impl VortexPreparedStateReuseRequest {
    /// Create a local prepared-state reuse request and fingerprint the source
    /// path. The source content digest is the primary fail-closed invalidation
    /// key; mtime is reported as evidence but does not invalidate by itself.
    ///
    /// # Errors
    /// Returns [`ShardLoomError::InvalidOperation`] when the local source cannot
    /// be fingerprinted.
    #[allow(clippy::too_many_arguments)]
    pub fn new_local(
        source_path: impl AsRef<Path>,
        prepared_artifact_path: impl AsRef<Path>,
        manifest_path: impl Into<PathBuf>,
        source_format: impl Into<String>,
        source_schema_digest: Option<String>,
        parse_decode_plan_digest: impl Into<String>,
        selected_columns: impl Into<String>,
        output_policy: impl Into<String>,
        provider_version: impl Into<String>,
        feature_gates: impl Into<String>,
        certification_level: impl Into<String>,
    ) -> Result<Self> {
        let source_fingerprint = LocalReuseFileFingerprint::from_path(
            source_path.as_ref(),
            "prepared-state reuse source",
        )?;
        Ok(Self {
            source_path: source_fingerprint.path,
            manifest_path: absolute_local_path(manifest_path.into())?,
            prepared_artifact_path: absolute_local_path(prepared_artifact_path.as_ref())?,
            source_format: source_format.into(),
            source_content_digest: source_fingerprint.content_digest,
            source_size_bytes: source_fingerprint.size_bytes,
            source_mtime_ns: source_fingerprint.mtime_ns,
            source_schema_digest,
            parse_decode_plan_digest: parse_decode_plan_digest.into(),
            selected_columns: selected_columns.into(),
            output_policy: output_policy.into(),
            provider_version: provider_version.into(),
            feature_gates: feature_gates.into(),
            certification_level: certification_level.into(),
        })
    }

    /// Create a local prepared-state reuse request for a deterministic
    /// generated/source-free input. The generated source has no physical source
    /// file to fingerprint, so callers must provide the stable source digest
    /// and generated-source byte count that will fail-closed on source kind,
    /// schema, row, plan, or output-policy drift.
    ///
    /// # Errors
    /// Returns [`ShardLoomError::InvalidOperation`] when the generated source
    /// reference is empty or local artifact paths cannot be resolved.
    #[allow(clippy::too_many_arguments)]
    pub fn new_generated_local(
        generated_source_ref: impl Into<String>,
        prepared_artifact_path: impl AsRef<Path>,
        manifest_path: impl Into<PathBuf>,
        source_format: impl Into<String>,
        source_content_digest: impl Into<String>,
        source_size_bytes: u64,
        source_schema_digest: impl Into<String>,
        parse_decode_plan_digest: impl Into<String>,
        selected_columns: impl Into<String>,
        output_policy: impl Into<String>,
        provider_version: impl Into<String>,
        feature_gates: impl Into<String>,
        certification_level: impl Into<String>,
    ) -> Result<Self> {
        let generated_source_ref = generated_source_ref.into();
        if generated_source_ref.trim().is_empty() {
            return Err(ShardLoomError::InvalidOperation(
                "generated prepared-state reuse source reference must not be empty; no fallback execution was attempted"
                    .to_string(),
            ));
        }
        Ok(Self {
            source_path: PathBuf::from(generated_source_ref),
            manifest_path: absolute_local_path(manifest_path.into())?,
            prepared_artifact_path: absolute_local_path(prepared_artifact_path.as_ref())?,
            source_format: source_format.into(),
            source_content_digest: source_content_digest.into(),
            source_size_bytes,
            source_mtime_ns: "not_applicable_generated_source".to_string(),
            source_schema_digest: Some(source_schema_digest.into()),
            parse_decode_plan_digest: parse_decode_plan_digest.into(),
            selected_columns: selected_columns.into(),
            output_policy: output_policy.into(),
            provider_version: provider_version.into(),
            feature_gates: feature_gates.into(),
            certification_level: certification_level.into(),
        })
    }
}

impl VortexNativeArtifactPrepareRequest {
    /// Create a local native Vortex artifact preparation request.
    ///
    /// # Errors
    /// Returns [`ShardLoomError::InvalidOperation`] when source or target paths
    /// are empty, non-local, or not `.vortex` artifacts.
    pub fn new_local(
        source_path: impl AsRef<Path>,
        target_path: impl AsRef<Path>,
        allow_overwrite: bool,
        provider_version: impl Into<String>,
        feature_gates: impl Into<String>,
        certification_level: impl Into<String>,
    ) -> Result<Self> {
        let source_path = absolute_local_path(source_path.as_ref())?;
        let target_path = absolute_local_path(target_path.as_ref())?;
        ensure_native_vortex_artifact_extension(&source_path, "native Vortex source")?;
        ensure_native_vortex_artifact_extension(&target_path, "prepared Vortex target")?;
        Ok(Self {
            source_path,
            target_path,
            allow_overwrite,
            provider_version: provider_version.into(),
            feature_gates: feature_gates.into(),
            certification_level: certification_level.into(),
        })
    }
}

impl VortexNativeArtifactPrepareReport {
    #[must_use]
    pub fn summary(&self) -> String {
        format!(
            "native Vortex artifact prepared via {}; rows={}; target={}",
            self.policy,
            self.row_count,
            self.target_path.display()
        )
    }

    #[must_use]
    pub fn to_text(&self) -> String {
        format!(
            "{}\nsource={}\ntarget={}\nencoded_layout_preserved={}\nreencode_performed={}\nworkspace_copy_performed={}",
            self.summary(),
            self.source_path.display(),
            self.target_path.display(),
            self.encoded_layout_preserved,
            self.reencode_performed,
            self.workspace_copy_performed
        )
    }

    /// Return stable evidence fields for CLI/API surfaces.
    #[must_use]
    #[allow(clippy::too_many_lines)]
    pub fn evidence_fields(&self) -> Vec<(String, String)> {
        let prepare_once_millis = micros_to_millis_string(self.prepare_once_micros);
        let metadata_open_millis = micros_to_millis_string(self.metadata_open_micros);
        let byte_copy_millis = micros_to_millis_string(self.byte_copy_micros);
        let mut fields = vec![
            (
                "schema_version".to_string(),
                VORTEX_NATIVE_ARTIFACT_PREPARE_SCHEMA_VERSION.to_string(),
            ),
            (
                "vortex_native_artifact_prepare_schema_version".to_string(),
                VORTEX_NATIVE_ARTIFACT_PREPARE_SCHEMA_VERSION.to_string(),
            ),
            ("execution_mode".to_string(), "prepared_vortex".to_string()),
            (
                "selected_execution_mode".to_string(),
                "prepared_vortex".to_string(),
            ),
            ("engine_mode".to_string(), "batch".to_string()),
            ("runtime_execution".to_string(), "true".to_string()),
            (
                "support_status".to_string(),
                "local_workflow_runtime_supported".to_string(),
            ),
            ("source_io_performed".to_string(), "true".to_string()),
            (
                "output_io_performed".to_string(),
                self.workspace_copy_performed.to_string(),
            ),
            ("source_kind".to_string(), "local_vortex_file".to_string()),
            ("source_format".to_string(), "vortex".to_string()),
            (
                "source_format_inferred".to_string(),
                "declared_or_extension_vortex".to_string(),
            ),
            (
                "source_format_inference_kind".to_string(),
                "native_vortex_artifact".to_string(),
            ),
            (
                "source_adapter_id".to_string(),
                "native_vortex_artifact_input_adapter".to_string(),
            ),
            (
                "source_adapter_registry_entry_id".to_string(),
                "shardloom.local_input_adapter.vortex_native_artifact.v1".to_string(),
            ),
            (
                "source_adapter_status".to_string(),
                "production_admitted_local_workflow".to_string(),
            ),
            (
                "source_adapter_admitted_extensions".to_string(),
                "vortex,vtx".to_string(),
            ),
            (
                "source_adapter_feature_gate".to_string(),
                self.feature_gates.clone(),
            ),
            (
                "source_adapter_boundary".to_string(),
                "native_vortex_artifact_source_no_compatibility_parse".to_string(),
            ),
            (
                "source_adapter_selection_reason".to_string(),
                "input_is_already_native_vortex_artifact".to_string(),
            ),
            (
                "source_adapter_blocker_id".to_string(),
                "none_native_vortex_artifact".to_string(),
            ),
            (
                "local_workflow_input_row_cap".to_string(),
                "none_product_runtime".to_string(),
            ),
            (
                "local_workflow_synthetic_input_row_cap_enabled".to_string(),
                "false".to_string(),
            ),
            (
                "local_workflow_synthetic_output_row_cap_enabled".to_string(),
                "false".to_string(),
            ),
            (
                "local_workflow_synthetic_source_byte_cap_enabled".to_string(),
                "false".to_string(),
            ),
            (
                "local_workflow_synthetic_join_candidate_cap_enabled".to_string(),
                "false".to_string(),
            ),
            (
                "ingress_route".to_string(),
                "universal_ingest_vortex_native_artifact".to_string(),
            ),
            (
                "ingress_route_label".to_string(),
                "Universal Ingest native Vortex artifact lane".to_string(),
            ),
            (
                "ingress_status".to_string(),
                "native_vortex_artifact_admitted".to_string(),
            ),
            (
                "ingress_certification_level".to_string(),
                self.certification_level.clone(),
            ),
            ("vortex_ingest_performed".to_string(), "true".to_string()),
            ("vortex_ingest_status".to_string(), self.status.clone()),
            (
                "vortex_ingest_blocker_id".to_string(),
                "none_native_vortex_artifact".to_string(),
            ),
            (
                "vortex_ingest_requested_max_parallelism".to_string(),
                "not_applicable_native_vortex_artifact".to_string(),
            ),
            (
                "prepared_state_id".to_string(),
                self.prepared_state_id.clone(),
            ),
            (
                "prepared_state_digest".to_string(),
                self.prepared_state_digest.clone(),
            ),
            ("prepared_state_created".to_string(), "true".to_string()),
            (
                "prepared_state_reused".to_string(),
                self.same_artifact_passthrough.to_string(),
            ),
            (
                "prepared_state_reuse_allowed".to_string(),
                "true".to_string(),
            ),
            (
                "prepared_state_reuse_hit".to_string(),
                self.same_artifact_passthrough.to_string(),
            ),
            (
                "prepared_state_reuse_scope".to_string(),
                "single_vortex_artifact_no_sidecar".to_string(),
            ),
            (
                "prepared_state_reuse_policy".to_string(),
                "native_vortex_artifact_pass_through_or_workspace_safe_copy.v1".to_string(),
            ),
            (
                "prepared_state_reuse_reason".to_string(),
                "source_is_already_native_vortex_artifact".to_string(),
            ),
            (
                "execution_route_label".to_string(),
                "Prepared Vortex route".to_string(),
            ),
            (
                "certification_policy".to_string(),
                "native_vortex_artifact_prepare_no_fallback".to_string(),
            ),
            (
                "certification_status".to_string(),
                "certified_native_vortex_artifact_prepare".to_string(),
            ),
            (
                "certification_blocker_id".to_string(),
                "none_native_vortex_artifact".to_string(),
            ),
            (
                "source_path".to_string(),
                self.source_path.display().to_string(),
            ),
            (
                "source_bytes".to_string(),
                self.source_size_bytes.to_string(),
            ),
            (
                "source_digest".to_string(),
                self.source_content_digest.clone(),
            ),
            (
                "source_fingerprint_kind".to_string(),
                self.source_digest_source.clone(),
            ),
            ("source_state_id".to_string(), self.source_state_id.clone()),
            (
                "source_state_digest".to_string(),
                self.source_state_digest.clone(),
            ),
            (
                "source_state_contract_schema_version".to_string(),
                "shardloom.native_vortex_source_state.v1".to_string(),
            ),
            (
                "source_state_read_plan".to_string(),
                "metadata_footer_open_only".to_string(),
            ),
            (
                "source_state_read_plan_reason".to_string(),
                "native_vortex_artifact_layout_metadata_admission".to_string(),
            ),
            (
                "source_state_projection_pushdown_status".to_string(),
                "not_applicable_prepare_native_vortex_artifact".to_string(),
            ),
            (
                "source_state_materialization_layout".to_string(),
                "vortex_encoded_artifact_preserved".to_string(),
            ),
            (
                "source_state_parse_normalization".to_string(),
                "not_performed_native_vortex_artifact".to_string(),
            ),
            (
                "source_state_columnar_preserved".to_string(),
                "true".to_string(),
            ),
            (
                "source_state_dictionary_preservation_status".to_string(),
                "preserved_existing_vortex_artifact".to_string(),
            ),
            (
                "source_state_ingest_executor_status".to_string(),
                "not_applicable_native_vortex_artifact".to_string(),
            ),
            (
                "source_schema_digest".to_string(),
                self.prepared_olap_layout_inventory.inventory_digest.clone(),
            ),
            ("input_row_count".to_string(), self.row_count.to_string()),
            (
                "target_vortex_path".to_string(),
                self.target_path.display().to_string(),
            ),
            (
                "vortex_artifact_ref".to_string(),
                self.target_path.display().to_string(),
            ),
            (
                "vortex_artifact_digest".to_string(),
                self.target_content_digest.clone(),
            ),
            (
                "vortex_artifact_digest_source".to_string(),
                self.target_digest_source.clone(),
            ),
            (
                "prepared_artifact_ref".to_string(),
                self.target_path.display().to_string(),
            ),
            (
                "prepared_artifact_digest".to_string(),
                self.target_content_digest.clone(),
            ),
            (
                "prepared_artifact_reuse_eligible".to_string(),
                "true".to_string(),
            ),
            (
                "layout_summary".to_string(),
                self.prepared_olap_layout_inventory
                    .root_layout_encoding
                    .clone(),
            ),
            (
                "encoding_summary".to_string(),
                self.prepared_olap_layout_inventory
                    .layout_encoding_inventory
                    .clone(),
            ),
            (
                "statistics_summary".to_string(),
                self.prepared_olap_layout_inventory
                    .statistics_status
                    .clone(),
            ),
            (
                "prepared_olap_layout_inventory_summary".to_string(),
                format!(
                    "{};rows={};segments={}",
                    self.prepared_olap_layout_inventory.status,
                    self.prepared_olap_layout_inventory.row_count_field(),
                    self.prepared_olap_layout_inventory.segment_count_field()
                ),
            ),
            (
                "vortex_prepared_olap_layout_inventory_status".to_string(),
                self.prepared_olap_layout_inventory.status.clone(),
            ),
            (
                "vortex_prepared_olap_layout_inventory_digest".to_string(),
                self.prepared_olap_layout_inventory.inventory_digest.clone(),
            ),
            (
                "vortex_prepared_olap_layout_footer_row_count".to_string(),
                self.prepared_olap_layout_inventory.row_count_field(),
            ),
            (
                "vortex_prepared_olap_layout_footer_segment_count".to_string(),
                self.prepared_olap_layout_inventory.segment_count_field(),
            ),
            (
                "vortex_prepared_olap_layout_footer_statistics_status".to_string(),
                self.prepared_olap_layout_inventory
                    .statistics_status
                    .clone(),
            ),
            (
                "vortex_prepared_olap_layout_footer_encoding_layout_status".to_string(),
                self.prepared_olap_layout_inventory
                    .encoding_layout_status
                    .clone(),
            ),
            (
                "vortex_prepared_olap_layout_artifact_size_bytes".to_string(),
                self.prepared_olap_layout_inventory
                    .artifact_size_bytes_field(),
            ),
            (
                "vortex_prepared_olap_layout_footer_approx_bytes".to_string(),
                self.prepared_olap_layout_inventory
                    .approx_footer_bytes_field(),
            ),
            (
                "vortex_prepared_olap_layout_footer_dtype_summary".to_string(),
                self.prepared_olap_layout_inventory.dtype_summary.clone(),
            ),
            (
                "vortex_prepared_olap_layout_metadata_persisted_in_artifact".to_string(),
                self.prepared_olap_layout_inventory
                    .metadata_persisted_in_artifact
                    .to_string(),
            ),
            (
                "vortex_prepared_olap_layout_size_attribution".to_string(),
                self.prepared_olap_layout_inventory
                    .layout_size_attribution
                    .clone(),
            ),
            (
                "prepared_olap_state_allowed".to_string(),
                "true".to_string(),
            ),
            (
                "prepared_olap_state_status".to_string(),
                "embedded_in_single_vortex_artifact".to_string(),
            ),
            (
                "prepared_olap_state_evidence_persistence".to_string(),
                "single_vortex_artifact_no_sidecar".to_string(),
            ),
            (
                "prepared_olap_state_external_manifest_written".to_string(),
                "false".to_string(),
            ),
            (
                "prepared_olap_state_query_time_contract".to_string(),
                VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_QUERY_TIME_CONTRACT.to_string(),
            ),
            (
                "prepared_olap_state_artifact_model".to_string(),
                VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_MODEL.to_string(),
            ),
            (
                "prepared_olap_state_embedded_layout_statistics_contract".to_string(),
                VORTEX_PREPARED_OLAP_METADATA_PRUNING_CONTRACT.to_string(),
            ),
            (
                "prepared_olap_state_layout_inventory_status".to_string(),
                self.prepared_olap_layout_inventory.status.clone(),
            ),
            (
                "prepared_olap_state_layout_inventory_digest".to_string(),
                self.prepared_olap_layout_inventory.inventory_digest.clone(),
            ),
            (
                "prepared_olap_state_layout_footer_row_count".to_string(),
                self.prepared_olap_layout_inventory.row_count_field(),
            ),
            (
                "prepared_olap_state_layout_footer_segment_count".to_string(),
                self.prepared_olap_layout_inventory.segment_count_field(),
            ),
            (
                "prepared_olap_state_layout_metadata_persisted_in_artifact".to_string(),
                self.prepared_olap_layout_inventory
                    .metadata_persisted_in_artifact
                    .to_string(),
            ),
            (
                "prepared_olap_state_query_answer_sidecar_status".to_string(),
                VORTEX_PREPARED_OLAP_QUERY_ANSWER_SIDECAR_STATUS.to_string(),
            ),
            (
                "prepare_once_millis".to_string(),
                prepare_once_millis.clone(),
            ),
            ("vortex_write_millis".to_string(), byte_copy_millis.clone()),
            ("vortex_segment_write_millis".to_string(), "0".to_string()),
            (
                "vortex_workspace_stage_millis".to_string(),
                byte_copy_millis,
            ),
            ("vortex_digest_millis".to_string(), "0".to_string()),
            (
                "vortex_reopen_hot_path_status".to_string(),
                "metadata_footer_open_only".to_string(),
            ),
            (
                "vortex_reopen_verify_millis".to_string(),
                metadata_open_millis.clone(),
            ),
            (
                "vortex_copy_budget_status".to_string(),
                self.copy_budget_status.clone(),
            ),
            (
                "universal_ingest_timing_split_schema_version".to_string(),
                "shardloom.universal_ingest_timing_split.v2v.v1".to_string(),
            ),
            (
                "universal_ingest_timing_split_status".to_string(),
                "native_vortex_artifact_metadata_or_byte_copy_split_recorded".to_string(),
            ),
            (
                "universal_ingest_source_read_millis".to_string(),
                metadata_open_millis.clone(),
            ),
            (
                "universal_ingest_decode_derive_millis".to_string(),
                "0".to_string(),
            ),
            (
                "universal_ingest_arrow_to_vortex_convert_millis".to_string(),
                "0".to_string(),
            ),
            (
                "universal_ingest_encode_write_wall_millis".to_string(),
                micros_to_millis_string(self.byte_copy_micros),
            ),
            (
                "universal_ingest_footer_register_millis".to_string(),
                "0".to_string(),
            ),
            (
                "universal_ingest_reopen_verify_millis".to_string(),
                micros_to_millis_string(self.metadata_open_micros),
            ),
            ("vortex_to_vortex_policy".to_string(), self.policy.clone()),
            (
                "vortex_to_vortex_encoded_layout_preserved".to_string(),
                self.encoded_layout_preserved.to_string(),
            ),
            (
                "vortex_to_vortex_reencode_performed".to_string(),
                self.reencode_performed.to_string(),
            ),
            (
                "vortex_to_vortex_workspace_copy_performed".to_string(),
                self.workspace_copy_performed.to_string(),
            ),
            (
                "vortex_to_vortex_same_artifact_passthrough".to_string(),
                self.same_artifact_passthrough.to_string(),
            ),
            (
                "vortex_to_vortex_upstream_vortex_scan_called".to_string(),
                self.upstream_vortex_scan_called.to_string(),
            ),
            (
                "vortex_to_vortex_upstream_vortex_write_called".to_string(),
                self.upstream_vortex_write_called.to_string(),
            ),
            (
                "vortex_to_vortex_layout_rewrite_status".to_string(),
                self.layout_rewrite_status.clone(),
            ),
            (
                "vortex_to_vortex_source_digest_source".to_string(),
                self.source_digest_source.clone(),
            ),
            (
                "vortex_to_vortex_target_digest_source".to_string(),
                self.target_digest_source.clone(),
            ),
            ("fallback_attempted".to_string(), "false".to_string()),
            ("external_engine_invoked".to_string(), "false".to_string()),
            (
                "claim_gate_status".to_string(),
                "local_workflow_runtime_supported".to_string(),
            ),
        ];
        fields.extend(self.segment_metadata_primitive.evidence_fields());
        if let Some(write_report) = &self.workspace_write_report {
            fields.extend(write_report.evidence_fields("vortex_to_vortex_copy"));
        }
        fields
    }
}

impl VortexPreparedOlapStateWriteRequest {
    /// Create a local exact OLAP prepared-state manifest request.
    ///
    /// # Errors
    /// Returns [`ShardLoomError::InvalidOperation`] when local artifact paths
    /// cannot be resolved.
    #[allow(clippy::too_many_arguments)]
    pub fn new_local(
        source_state_id: impl Into<String>,
        source_state_digest: impl Into<String>,
        source_format: impl Into<String>,
        source_content_digest: impl Into<String>,
        source_size_bytes: u64,
        source_schema_digest: impl Into<String>,
        source_row_count: u64,
        prepared_artifact_path: impl AsRef<Path>,
        manifest_path: impl Into<PathBuf>,
    ) -> Result<Self> {
        Ok(Self {
            source_state_id: source_state_id.into(),
            source_state_digest: source_state_digest.into(),
            source_format: source_format.into(),
            source_content_digest: source_content_digest.into(),
            source_size_bytes,
            source_schema_digest: source_schema_digest.into(),
            source_row_count,
            prepared_artifact_path: absolute_local_path(prepared_artifact_path.as_ref())?,
            manifest_path: absolute_local_path(manifest_path.into())?,
            prepared_layout_policy: "not_declared".to_string(),
            segment_map_status: "not_declared".to_string(),
            derived_column_manifest: "none".to_string(),
            substring_index_manifest: "none".to_string(),
            aggregate_summary_manifest: "none".to_string(),
            row_position_manifest: "none".to_string(),
            dictionary_union_manifest: "none".to_string(),
            feature_gates: "vortex-write,vortex-local-primitives".to_string(),
            certification_level: "prepared_olap_contract_declared".to_string(),
            certificate_refs: "none".to_string(),
            fallback_attempted: false,
            external_engine_invoked: false,
        })
    }

    #[must_use]
    pub fn with_prepared_layout_policy(mut self, value: impl Into<String>) -> Self {
        self.prepared_layout_policy = value.into();
        self
    }

    #[must_use]
    pub fn with_segment_map_status(mut self, value: impl Into<String>) -> Self {
        self.segment_map_status = value.into();
        self
    }

    #[must_use]
    pub fn with_derived_column_manifest(mut self, value: impl Into<String>) -> Self {
        self.derived_column_manifest = value.into();
        self
    }

    #[must_use]
    pub fn with_substring_index_manifest(mut self, value: impl Into<String>) -> Self {
        self.substring_index_manifest = value.into();
        self
    }

    #[must_use]
    pub fn with_aggregate_summary_manifest(mut self, value: impl Into<String>) -> Self {
        self.aggregate_summary_manifest = value.into();
        self
    }

    #[must_use]
    pub fn with_row_position_manifest(mut self, value: impl Into<String>) -> Self {
        self.row_position_manifest = value.into();
        self
    }

    #[must_use]
    pub fn with_dictionary_union_manifest(mut self, value: impl Into<String>) -> Self {
        self.dictionary_union_manifest = value.into();
        self
    }

    #[must_use]
    pub fn with_feature_gates(mut self, value: impl Into<String>) -> Self {
        self.feature_gates = value.into();
        self
    }

    #[must_use]
    pub fn with_certification_level(mut self, value: impl Into<String>) -> Self {
        self.certification_level = value.into();
        self
    }

    #[must_use]
    pub fn with_certificate_refs(mut self, value: impl Into<String>) -> Self {
        self.certificate_refs = value.into();
        self
    }

    #[must_use]
    pub fn with_fallback_attempted(mut self, value: bool) -> Self {
        self.fallback_attempted = value;
        self
    }

    #[must_use]
    pub fn with_external_engine_invoked(mut self, value: bool) -> Self {
        self.external_engine_invoked = value;
        self
    }
}

impl VortexPreparedStateReuseReport {
    /// Return stable evidence fields for CLI/API surfaces.
    #[must_use]
    #[allow(clippy::too_many_lines)]
    pub fn evidence_fields(&self) -> Vec<(String, String)> {
        vec![
            (
                "vortex_prepared_state_reuse_schema_version".to_string(),
                self.schema_version.to_string(),
            ),
            (
                "vortex_prepared_state_reuse_status".to_string(),
                self.status.clone(),
            ),
            (
                "vortex_prepared_state_reuse_scope".to_string(),
                self.scope.clone(),
            ),
            (
                "vortex_prepared_state_reuse_manifest_path".to_string(),
                self.manifest_path.display().to_string(),
            ),
            (
                "vortex_prepared_state_reuse_policy".to_string(),
                self.policy.to_string(),
            ),
            (
                "vortex_prepared_state_reuse_hit".to_string(),
                self.hit.to_string(),
            ),
            (
                "vortex_prepared_state_reuse_reason".to_string(),
                self.reason.clone(),
            ),
            (
                "vortex_prepared_state_reuse_manifest_digest".to_string(),
                self.manifest_digest.clone(),
            ),
            (
                "vortex_prepared_state_reuse_manifest_digest_algorithm".to_string(),
                digest_algorithm(&self.manifest_digest).to_string(),
            ),
            (
                "vortex_prepared_state_reuse_index_schema_version".to_string(),
                VORTEX_PREPARED_STATE_REUSE_INDEX_SCHEMA_VERSION.to_string(),
            ),
            (
                "vortex_prepared_state_reuse_index_key".to_string(),
                self.index_key(),
            ),
            (
                "vortex_prepared_state_reuse_index_lookup_status".to_string(),
                self.index_lookup_status().to_string(),
            ),
            (
                "vortex_prepared_state_reuse_index_cache_scope".to_string(),
                "artifact_adjacent_manifest_read_through_cache".to_string(),
            ),
            (
                "vortex_prepared_state_reuse_index_repair_status".to_string(),
                self.index_repair_status().to_string(),
            ),
            (
                "vortex_prepared_state_reuse_role_scoped_repair_status".to_string(),
                self.role_scoped_repair_status().to_string(),
            ),
            (
                "vortex_prepared_state_reuse_invalidation_reason".to_string(),
                self.invalidation_reason.clone(),
            ),
            (
                "vortex_prepared_state_reuse_manifest_written".to_string(),
                self.manifest_written.to_string(),
            ),
            (
                "vortex_prepared_state_reuse_source_path".to_string(),
                self.source_path.display().to_string(),
            ),
            (
                "vortex_prepared_state_reuse_source_format".to_string(),
                self.source_format.clone(),
            ),
            (
                "vortex_prepared_state_reuse_source_content_digest".to_string(),
                self.source_content_digest.clone(),
            ),
            (
                "vortex_prepared_state_reuse_source_size_bytes".to_string(),
                self.source_size_bytes.to_string(),
            ),
            (
                "vortex_prepared_state_reuse_source_mtime_ns".to_string(),
                self.source_mtime_ns.clone(),
            ),
            (
                "vortex_prepared_state_reuse_source_schema_digest".to_string(),
                self.source_schema_digest.clone(),
            ),
            (
                "vortex_prepared_state_reuse_source_row_count".to_string(),
                self.source_row_count.to_string(),
            ),
            (
                "vortex_prepared_state_reuse_source_column_family_summary".to_string(),
                self.source_column_family_summary.clone(),
            ),
            (
                "vortex_prepared_state_reuse_parse_decode_plan_digest".to_string(),
                self.parse_decode_plan_digest.clone(),
            ),
            (
                "vortex_prepared_state_reuse_selected_columns".to_string(),
                self.selected_columns.clone(),
            ),
            (
                "vortex_prepared_state_reuse_output_policy".to_string(),
                self.output_policy.clone(),
            ),
            (
                "vortex_prepared_state_reuse_prepared_artifact_ref".to_string(),
                self.prepared_artifact_ref.display().to_string(),
            ),
            (
                "vortex_prepared_state_reuse_prepared_artifact_digest".to_string(),
                self.prepared_artifact_digest.clone(),
            ),
            (
                "vortex_prepared_state_reuse_prepared_artifact_size_bytes".to_string(),
                self.prepared_artifact_size_bytes.to_string(),
            ),
            (
                "vortex_prepared_state_reuse_provider_version".to_string(),
                self.provider_version.clone(),
            ),
            (
                "vortex_prepared_state_reuse_feature_gates".to_string(),
                self.feature_gates.clone(),
            ),
            (
                "vortex_prepared_state_reuse_certification_level".to_string(),
                self.certification_level.clone(),
            ),
            (
                "vortex_prepared_state_reuse_source_state_id".to_string(),
                self.source_state_id.clone(),
            ),
            (
                "vortex_prepared_state_reuse_source_state_digest".to_string(),
                self.source_state_digest.clone(),
            ),
            (
                "vortex_prepared_state_reuse_prepared_state_id".to_string(),
                self.prepared_state_id.clone(),
            ),
            (
                "vortex_prepared_state_reuse_prepared_state_digest".to_string(),
                self.prepared_state_digest.clone(),
            ),
            (
                "vortex_prepared_state_reuse_certificate_refs".to_string(),
                self.certificate_refs.clone(),
            ),
            (
                "vortex_prepared_state_reuse_fallback_attempted".to_string(),
                self.fallback_attempted.to_string(),
            ),
            (
                "vortex_prepared_state_reuse_external_engine_invoked".to_string(),
                self.external_engine_invoked.to_string(),
            ),
        ]
    }

    fn index_key(&self) -> String {
        let mut digest = sha2::Sha256::new();
        for value in [
            self.source_format.as_str(),
            self.source_content_digest.as_str(),
            self.source_schema_digest.as_str(),
            self.parse_decode_plan_digest.as_str(),
            self.selected_columns.as_str(),
            self.output_policy.as_str(),
            self.provider_version.as_str(),
            self.feature_gates.as_str(),
            self.certification_level.as_str(),
        ] {
            digest.update(value.as_bytes());
            digest.update(b"\0");
        }
        sha256_digest_string(digest.finalize())
    }

    fn index_lookup_status(&self) -> &'static str {
        if self.hit {
            "artifact_adjacent_manifest_read_through_hit"
        } else if self.manifest_written {
            "artifact_adjacent_manifest_created_after_miss"
        } else {
            "artifact_adjacent_manifest_read_through_miss"
        }
    }

    fn index_repair_status(&self) -> &'static str {
        if self.hit {
            "not_required_cache_hit"
        } else if self.manifest_written {
            "manifest_written_after_prepare"
        } else if self.reason == "prepared_artifact_missing" {
            "artifact_missing_recreate_required"
        } else {
            "not_required_fail_closed_miss"
        }
    }

    fn role_scoped_repair_status(&self) -> &'static str {
        if self.hit || self.manifest_written {
            "not_required_local_single_artifact"
        } else {
            "not_applicable_local_single_artifact_recreate_required"
        }
    }
}

impl VortexPreparedOlapStateReport {
    /// Return stable evidence fields for CLI/API surfaces.
    #[must_use]
    #[allow(clippy::too_many_lines)]
    pub fn evidence_fields(&self) -> Vec<(String, String)> {
        vec![
            (
                "vortex_prepared_olap_state_schema_version".to_string(),
                self.schema_version.to_string(),
            ),
            (
                "vortex_prepared_olap_state_status".to_string(),
                self.status.clone(),
            ),
            (
                "vortex_prepared_olap_state_policy".to_string(),
                self.policy.to_string(),
            ),
            (
                "vortex_prepared_olap_state_evidence_persistence".to_string(),
                "embedded_in_single_prepared_vortex_artifact".to_string(),
            ),
            (
                "vortex_prepared_olap_state_external_manifest_written".to_string(),
                "false".to_string(),
            ),
            (
                "vortex_prepared_olap_state_id".to_string(),
                self.state_id.clone(),
            ),
            (
                "vortex_prepared_olap_state_digest".to_string(),
                self.state_digest.clone(),
            ),
            (
                "vortex_prepared_olap_state_source_state_id".to_string(),
                self.source_state_id.clone(),
            ),
            (
                "vortex_prepared_olap_state_source_state_digest".to_string(),
                self.source_state_digest.clone(),
            ),
            (
                "vortex_prepared_olap_state_source_format".to_string(),
                self.source_format.clone(),
            ),
            (
                "vortex_prepared_olap_state_source_content_digest".to_string(),
                self.source_content_digest.clone(),
            ),
            (
                "vortex_prepared_olap_state_source_size_bytes".to_string(),
                self.source_size_bytes.to_string(),
            ),
            (
                "vortex_prepared_olap_state_source_schema_digest".to_string(),
                self.source_schema_digest.clone(),
            ),
            (
                "vortex_prepared_olap_state_source_row_count".to_string(),
                self.source_row_count.to_string(),
            ),
            (
                "vortex_prepared_olap_state_prepared_artifact_ref".to_string(),
                self.prepared_artifact_ref.display().to_string(),
            ),
            (
                "vortex_prepared_olap_state_prepared_artifact_digest".to_string(),
                self.prepared_artifact_digest.clone(),
            ),
            (
                "vortex_prepared_olap_state_prepared_artifact_size_bytes".to_string(),
                self.prepared_artifact_size_bytes.to_string(),
            ),
            (
                "vortex_prepared_olap_state_artifact_model".to_string(),
                self.artifact_model.clone(),
            ),
            (
                "vortex_prepared_olap_state_prepared_layout_policy".to_string(),
                self.prepared_layout_policy.clone(),
            ),
            (
                "vortex_prepared_olap_state_segment_map_status".to_string(),
                self.segment_map_status.clone(),
            ),
            (
                "vortex_prepared_olap_state_writer_layout_strategy".to_string(),
                self.writer_layout_strategy.clone(),
            ),
            (
                "vortex_prepared_olap_state_embedded_layout_statistics_contract".to_string(),
                self.embedded_layout_statistics_contract.clone(),
            ),
            (
                "vortex_prepared_olap_state_layout_inventory_status".to_string(),
                self.layout_inventory_status.clone(),
            ),
            (
                "vortex_prepared_olap_state_layout_inventory_digest".to_string(),
                self.layout_inventory_digest.clone(),
            ),
            (
                "vortex_prepared_olap_state_layout_footer_row_count".to_string(),
                self.layout_footer_row_count.clone(),
            ),
            (
                "vortex_prepared_olap_state_layout_footer_segment_count".to_string(),
                self.layout_footer_segment_count.clone(),
            ),
            (
                "vortex_prepared_olap_state_layout_footer_statistics_status".to_string(),
                self.layout_footer_statistics_status.clone(),
            ),
            (
                "vortex_prepared_olap_state_layout_footer_encoding_layout_status".to_string(),
                self.layout_footer_encoding_layout_status.clone(),
            ),
            (
                "vortex_prepared_olap_state_layout_artifact_size_bytes".to_string(),
                self.layout_artifact_size_bytes.clone(),
            ),
            (
                "vortex_prepared_olap_state_layout_footer_approx_bytes".to_string(),
                self.layout_footer_approx_bytes.clone(),
            ),
            (
                "vortex_prepared_olap_state_layout_footer_dtype_summary".to_string(),
                self.layout_footer_dtype_summary.clone(),
            ),
            (
                "vortex_prepared_olap_state_layout_root_encoding".to_string(),
                self.layout_root_encoding.clone(),
            ),
            (
                "vortex_prepared_olap_state_layout_encoding_inventory".to_string(),
                self.layout_encoding_inventory.clone(),
            ),
            (
                "vortex_prepared_olap_state_layout_per_column_metadata_contract".to_string(),
                self.layout_per_column_metadata_contract.clone(),
            ),
            (
                "vortex_prepared_olap_state_layout_segment_membership_status".to_string(),
                self.layout_segment_membership_status.clone(),
            ),
            (
                "vortex_prepared_olap_state_layout_domain_dictionary_status".to_string(),
                self.layout_domain_dictionary_status.clone(),
            ),
            (
                "vortex_prepared_olap_state_layout_derived_stats_status".to_string(),
                self.layout_derived_stats_status.clone(),
            ),
            (
                "vortex_prepared_olap_state_layout_row_position_locality_status".to_string(),
                self.layout_row_position_locality_status.clone(),
            ),
            (
                "vortex_prepared_olap_state_layout_reader_cache_status".to_string(),
                self.layout_reader_cache_status.clone(),
            ),
            (
                "vortex_prepared_olap_state_layout_metadata_persisted_in_artifact".to_string(),
                self.layout_metadata_persisted_in_artifact.to_string(),
            ),
            (
                "vortex_prepared_olap_state_layout_operator_selection_metadata_status".to_string(),
                self.layout_operator_selection_metadata_status.clone(),
            ),
            (
                "vortex_prepared_olap_state_layout_size_attribution".to_string(),
                self.layout_size_attribution.clone(),
            ),
            (
                "vortex_prepared_olap_state_dictionary_metadata_policy".to_string(),
                self.dictionary_metadata_policy.clone(),
            ),
            (
                "vortex_prepared_olap_state_metadata_pruning_contract".to_string(),
                self.metadata_pruning_contract.clone(),
            ),
            (
                "vortex_prepared_olap_state_query_answer_sidecar_status".to_string(),
                self.query_answer_sidecar_status.clone(),
            ),
            (
                "vortex_prepared_olap_state_derived_column_metadata_ref".to_string(),
                self.derived_column_manifest.clone(),
            ),
            (
                "vortex_prepared_olap_state_substring_index_metadata_ref".to_string(),
                self.substring_index_manifest.clone(),
            ),
            (
                "vortex_prepared_olap_state_aggregate_summary_metadata_ref".to_string(),
                self.aggregate_summary_manifest.clone(),
            ),
            (
                "vortex_prepared_olap_state_row_position_metadata_ref".to_string(),
                self.row_position_manifest.clone(),
            ),
            (
                "vortex_prepared_olap_state_dictionary_union_metadata_ref".to_string(),
                self.dictionary_union_manifest.clone(),
            ),
            (
                "vortex_prepared_olap_state_admitted_query_families".to_string(),
                self.admitted_query_families.clone(),
            ),
            (
                "vortex_prepared_olap_state_exact_sidecar_family_count".to_string(),
                self.exact_sidecar_family_count.to_string(),
            ),
            (
                "vortex_prepared_olap_state_query_time_contract".to_string(),
                self.query_time_contract.clone(),
            ),
            (
                "vortex_prepared_olap_state_sub_second_candidate".to_string(),
                self.sub_second_candidate.to_string(),
            ),
            (
                "vortex_prepared_olap_state_blocker_id".to_string(),
                self.blocker_id.clone(),
            ),
            (
                "vortex_prepared_olap_state_next_action".to_string(),
                self.next_action.clone(),
            ),
            (
                "vortex_prepared_olap_state_feature_gates".to_string(),
                self.feature_gates.clone(),
            ),
            (
                "vortex_prepared_olap_state_certification_level".to_string(),
                self.certification_level.clone(),
            ),
            (
                "vortex_prepared_olap_state_certificate_refs".to_string(),
                self.certificate_refs.clone(),
            ),
            (
                "vortex_prepared_olap_state_fallback_attempted".to_string(),
                self.fallback_attempted.to_string(),
            ),
            (
                "vortex_prepared_olap_state_external_engine_invoked".to_string(),
                self.external_engine_invoked.to_string(),
            ),
        ]
    }
}

/// Return the artifact-adjacent reuse manifest path for a local Vortex artifact.
///
/// # Errors
/// Returns [`ShardLoomError::InvalidOperation`] when the artifact path has no
/// file name.
pub fn vortex_prepared_state_reuse_manifest_path(
    prepared_artifact_path: impl AsRef<Path>,
) -> Result<PathBuf> {
    let path = absolute_local_path(prepared_artifact_path.as_ref())?;
    let Some(file_name) = path.file_name().and_then(|value| value.to_str()) else {
        return Err(ShardLoomError::InvalidOperation(format!(
            "prepared-state reuse manifest requires a local artifact file name for '{}'; no fallback execution was attempted",
            path.display()
        )));
    };
    let parent = path.parent().unwrap_or_else(|| Path::new("."));
    Ok(parent
        .join(".shardloom")
        .join(format!("{file_name}.prepared-state-reuse.manifest")))
}

/// Publish prepared OLAP state evidence for a single Vortex artifact.
///
/// Product prepared OLAP state is represented by the prepared `.vortex` file
/// and Vortex-native embedded layout/statistics evidence. This writer does not
/// create artifact-adjacent query-summary or exact-answer sidecars.
///
/// # Errors
/// Returns [`ShardLoomError::InvalidOperation`] when the prepared artifact
/// cannot be fingerprinted or the manifest cannot be written safely.
pub fn write_vortex_prepared_olap_state_bundle(
    mut request: VortexPreparedOlapStateWriteRequest,
) -> Result<VortexPreparedOlapStateReport> {
    if !prepared_olap_metadata_ref_declared(&request.prepared_layout_policy) {
        request.prepared_layout_policy =
            VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_LAYOUT_POLICY.to_string();
    }
    if !prepared_olap_metadata_ref_declared(&request.segment_map_status) {
        request.segment_map_status =
            VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_SEGMENT_MAP_STATUS.to_string();
    }
    request.derived_column_manifest = "none".to_string();
    request.substring_index_manifest = "none".to_string();
    request.aggregate_summary_manifest = "none".to_string();
    request.row_position_manifest = "none".to_string();
    request.dictionary_union_manifest = "none".to_string();
    publish_vortex_prepared_olap_single_artifact_state(&request)
}

/// Publish fail-closed, content-addressed OLAP evidence for one Vortex artifact.
///
/// No external prepared OLAP manifest or `.prepared-olap-state.d` directory is
/// created. The report state digest is derived from the prepared Vortex artifact
/// plus source/certificate evidence.
///
/// # Errors
/// Returns [`ShardLoomError::InvalidOperation`] when the prepared artifact
/// cannot be fingerprinted.
#[allow(clippy::too_many_lines)]
pub fn publish_vortex_prepared_olap_single_artifact_state(
    request: &VortexPreparedOlapStateWriteRequest,
) -> Result<VortexPreparedOlapStateReport> {
    let artifact_fingerprint = LocalReuseFileFingerprint::from_path(
        &request.prepared_artifact_path,
        "prepared OLAP state artifact",
    )?;
    Ok(prepared_olap_report_from_request(
        request,
        &artifact_fingerprint,
        prepared_olap_state_status(request, prepared_olap_exact_sidecar_family_count(request)),
        artifact_fingerprint.content_digest.clone(),
        false,
    ))
}

/// Evaluate existing single-artifact OLAP prepared-state evidence for
/// query-time admission.
///
/// This is a read-through admission gate, not a fallback path. It succeeds only
/// when the prepared artifact can be fingerprinted and the supplied source,
/// embedded-layout posture, and no-fallback evidence describe an admitted
/// single-artifact Vortex route.
///
/// # Errors
/// Returns [`ShardLoomError::InvalidOperation`] when the prepared artifact
/// cannot be fingerprinted.
#[allow(clippy::too_many_lines)]
pub fn evaluate_vortex_prepared_olap_single_artifact_state(
    request: &VortexPreparedOlapStateWriteRequest,
) -> Result<VortexPreparedOlapStateReport> {
    if !request.prepared_artifact_path.exists() {
        return Ok(prepared_olap_blocked_report(
            request,
            "blocked_prepared_olap_artifact_missing",
            "prepared_olap_state.prepared_artifact_missing",
            "recreate the prepared Vortex artifact before query-time prepared-state admission",
            "none",
            None,
        ));
    }
    let artifact_fingerprint = LocalReuseFileFingerprint::from_path(
        &request.prepared_artifact_path,
        "prepared OLAP state artifact",
    )?;
    let status =
        prepared_olap_state_status(request, prepared_olap_exact_sidecar_family_count(request));
    if status != "prepared_olap_state_ready" {
        return Ok(prepared_olap_report_from_request(
            request,
            &artifact_fingerprint,
            status,
            artifact_fingerprint.content_digest.clone(),
            false,
        ));
    }

    Ok(prepared_olap_report_from_request(
        request,
        &artifact_fingerprint,
        "prepared_olap_state_read_through_hit".to_string(),
        artifact_fingerprint.content_digest.clone(),
        false,
    ))
}

/// Evaluate whether a local prepared artifact can be reused.
///
/// # Errors
/// Returns [`ShardLoomError::InvalidOperation`] when the manifest exists but
/// cannot be read or parsed deterministically.
#[allow(clippy::too_many_lines)]
pub fn evaluate_vortex_prepared_state_reuse(
    request: &VortexPreparedStateReuseRequest,
) -> Result<VortexPreparedStateReuseReport> {
    if !request.manifest_path.exists() {
        return Ok(prepared_state_reuse_miss(
            request,
            "no_reuse_manifest",
            "none",
        ));
    }
    let fields = read_reuse_manifest_fields(&request.manifest_path)?;
    let manifest_digest = fields
        .get("manifest_digest")
        .cloned()
        .unwrap_or_else(|| "none".to_string());
    let expected_digest = reuse_manifest_digest(&fields);
    if manifest_digest != expected_digest {
        return Ok(prepared_state_reuse_miss_with_digest(
            request,
            "reuse_manifest_digest_mismatch",
            &manifest_digest,
        ));
    }
    if fields.get("schema_version").map(String::as_str)
        != Some(VORTEX_PREPARED_STATE_REUSE_SCHEMA_VERSION)
    {
        return Ok(prepared_state_reuse_miss_with_digest(
            request,
            "reuse_manifest_schema_mismatch",
            &manifest_digest,
        ));
    }
    if let Some(reason) = reuse_manifest_request_mismatch_reason(request, &fields) {
        return Ok(prepared_state_reuse_miss_with_digest(
            request,
            &reason,
            &manifest_digest,
        ));
    }
    if fields.get("fallback_attempted").map(String::as_str) != Some("false") {
        return Ok(prepared_state_reuse_miss_with_digest(
            request,
            "reuse_manifest_fallback_attempted",
            &manifest_digest,
        ));
    }
    if fields.get("external_engine_invoked").map(String::as_str) != Some("false") {
        return Ok(prepared_state_reuse_miss_with_digest(
            request,
            "reuse_manifest_external_engine_invoked",
            &manifest_digest,
        ));
    }
    if !request.prepared_artifact_path.exists() {
        return Ok(prepared_state_reuse_miss_with_digest(
            request,
            "prepared_artifact_missing",
            &manifest_digest,
        ));
    }
    let artifact_fingerprint = LocalReuseFileFingerprint::from_path(
        &request.prepared_artifact_path,
        "prepared-state reuse artifact",
    )?;
    if fields
        .get("prepared_artifact_size_bytes")
        .map(String::as_str)
        != Some(artifact_fingerprint.size_bytes.to_string().as_str())
    {
        return Ok(prepared_state_reuse_miss_with_digest(
            request,
            "prepared_artifact_size_changed",
            &manifest_digest,
        ));
    }
    if fields.get("prepared_artifact_digest").map(String::as_str)
        != Some(artifact_fingerprint.content_digest.as_str())
    {
        return Ok(prepared_state_reuse_miss_with_digest(
            request,
            "prepared_artifact_digest_changed",
            &manifest_digest,
        ));
    }
    for required in [
        "source_state_id",
        "source_state_digest",
        "prepared_state_id",
        "prepared_state_digest",
    ] {
        if fields.get(required).is_none_or(String::is_empty) {
            return Ok(prepared_state_reuse_miss_with_digest(
                request,
                &format!("reuse_manifest_missing_{required}"),
                &manifest_digest,
            ));
        }
    }
    Ok(VortexPreparedStateReuseReport {
        schema_version: VORTEX_PREPARED_STATE_REUSE_SCHEMA_VERSION,
        status: "prepared_state_reuse_hit".to_string(),
        scope: "artifact_adjacent_manifest_local_vortex_artifacts".to_string(),
        manifest_path: request.manifest_path.clone(),
        policy: VORTEX_PREPARED_STATE_REUSE_POLICY,
        hit: true,
        reason: "manifest_fingerprints_match".to_string(),
        manifest_digest,
        invalidation_reason: "none".to_string(),
        manifest_written: false,
        source_path: request.source_path.clone(),
        source_format: request.source_format.clone(),
        source_content_digest: request.source_content_digest.clone(),
        source_size_bytes: request.source_size_bytes,
        source_mtime_ns: request.source_mtime_ns.clone(),
        source_schema_digest: fields
            .get("source_schema_digest")
            .cloned()
            .unwrap_or_else(|| request.source_schema_digest.clone().unwrap_or_default()),
        source_row_count: fields
            .get("source_row_count")
            .and_then(|value| value.parse::<u64>().ok())
            .unwrap_or(0),
        source_column_family_summary: fields
            .get("source_column_family_summary")
            .cloned()
            .unwrap_or_default(),
        parse_decode_plan_digest: request.parse_decode_plan_digest.clone(),
        selected_columns: request.selected_columns.clone(),
        output_policy: request.output_policy.clone(),
        prepared_artifact_ref: request.prepared_artifact_path.clone(),
        prepared_artifact_digest: artifact_fingerprint.content_digest,
        prepared_artifact_size_bytes: artifact_fingerprint.size_bytes,
        provider_version: request.provider_version.clone(),
        feature_gates: request.feature_gates.clone(),
        certification_level: request.certification_level.clone(),
        source_state_id: fields.get("source_state_id").cloned().unwrap_or_default(),
        source_state_digest: fields
            .get("source_state_digest")
            .cloned()
            .unwrap_or_default(),
        prepared_state_id: fields.get("prepared_state_id").cloned().unwrap_or_default(),
        prepared_state_digest: fields
            .get("prepared_state_digest")
            .cloned()
            .unwrap_or_default(),
        certificate_refs: fields
            .get("certificate_refs")
            .cloned()
            .unwrap_or_else(|| "manifest_certificate_refs_missing".to_string()),
        fallback_attempted: false,
        external_engine_invoked: false,
    })
}

/// Write a fail-closed prepared-state reuse manifest after a successful local
/// Vortex preparation.
///
/// # Errors
/// Returns [`ShardLoomError::InvalidOperation`] when the prepared artifact
/// cannot be fingerprinted or the manifest cannot be written atomically.
#[allow(clippy::too_many_lines)]
pub fn write_vortex_prepared_state_reuse_manifest(
    request: &VortexPreparedStateReuseRequest,
    previous_decision: &VortexPreparedStateReuseReport,
    evidence: VortexPreparedStateReuseWriteEvidence,
) -> Result<VortexPreparedStateReuseReport> {
    let artifact_fingerprint = LocalReuseFileFingerprint::from_path(
        &request.prepared_artifact_path,
        "prepared-state reuse artifact",
    )?;
    if artifact_fingerprint.content_digest != evidence.prepared_artifact_digest {
        return Err(ShardLoomError::InvalidOperation(format!(
            "prepared-state reuse manifest artifact digest mismatch for '{}': writer reported {}, file fingerprint {}; no fallback execution was attempted",
            request.prepared_artifact_path.display(),
            evidence.prepared_artifact_digest,
            artifact_fingerprint.content_digest
        )));
    }
    let mut fields = BTreeMap::new();
    fields.insert(
        "schema_version".to_string(),
        VORTEX_PREPARED_STATE_REUSE_SCHEMA_VERSION.to_string(),
    );
    fields.insert(
        "policy".to_string(),
        VORTEX_PREPARED_STATE_REUSE_POLICY.to_string(),
    );
    fields.insert(
        "source_path".to_string(),
        request.source_path.display().to_string(),
    );
    fields.insert("source_format".to_string(), request.source_format.clone());
    fields.insert(
        "source_content_digest".to_string(),
        request.source_content_digest.clone(),
    );
    fields.insert(
        "source_size_bytes".to_string(),
        request.source_size_bytes.to_string(),
    );
    fields.insert(
        "source_mtime_ns".to_string(),
        request.source_mtime_ns.clone(),
    );
    fields.insert(
        "source_schema_digest".to_string(),
        evidence.source_schema_digest.clone(),
    );
    fields.insert(
        "source_row_count".to_string(),
        evidence.source_row_count.to_string(),
    );
    fields.insert(
        "source_column_family_summary".to_string(),
        evidence.source_column_family_summary.clone(),
    );
    fields.insert(
        "parse_decode_plan_digest".to_string(),
        request.parse_decode_plan_digest.clone(),
    );
    fields.insert(
        "selected_columns".to_string(),
        request.selected_columns.clone(),
    );
    fields.insert("output_policy".to_string(), request.output_policy.clone());
    fields.insert(
        "prepared_artifact_path".to_string(),
        request.prepared_artifact_path.display().to_string(),
    );
    fields.insert(
        "prepared_artifact_size_bytes".to_string(),
        artifact_fingerprint.size_bytes.to_string(),
    );
    fields.insert(
        "prepared_artifact_digest".to_string(),
        evidence.prepared_artifact_digest.clone(),
    );
    fields.insert(
        "provider_version".to_string(),
        request.provider_version.clone(),
    );
    fields.insert("feature_gates".to_string(), request.feature_gates.clone());
    fields.insert(
        "certification_level".to_string(),
        request.certification_level.clone(),
    );
    fields.insert(
        "source_state_id".to_string(),
        evidence.source_state_id.clone(),
    );
    fields.insert(
        "source_state_digest".to_string(),
        evidence.source_state_digest.clone(),
    );
    fields.insert(
        "prepared_state_id".to_string(),
        evidence.prepared_state_id.clone(),
    );
    fields.insert(
        "prepared_state_digest".to_string(),
        evidence.prepared_state_digest.clone(),
    );
    fields.insert(
        "certificate_refs".to_string(),
        evidence.certificate_refs.clone(),
    );
    fields.insert(
        "fallback_attempted".to_string(),
        evidence.fallback_attempted.to_string(),
    );
    fields.insert(
        "external_engine_invoked".to_string(),
        evidence.external_engine_invoked.to_string(),
    );
    let manifest_digest = reuse_manifest_digest(&fields);
    fields.insert("manifest_digest".to_string(), manifest_digest.clone());
    write_reuse_manifest_fields(&request.manifest_path, &fields)?;

    Ok(VortexPreparedStateReuseReport {
        schema_version: VORTEX_PREPARED_STATE_REUSE_SCHEMA_VERSION,
        status: "prepared_state_created_manifest_written".to_string(),
        scope: "artifact_adjacent_manifest_local_vortex_artifacts".to_string(),
        manifest_path: request.manifest_path.clone(),
        policy: VORTEX_PREPARED_STATE_REUSE_POLICY,
        hit: false,
        reason: format!("prepared_state_created_after_{}", previous_decision.reason),
        manifest_digest,
        invalidation_reason: previous_decision.invalidation_reason.clone(),
        manifest_written: true,
        source_path: request.source_path.clone(),
        source_format: request.source_format.clone(),
        source_content_digest: request.source_content_digest.clone(),
        source_size_bytes: request.source_size_bytes,
        source_mtime_ns: request.source_mtime_ns.clone(),
        source_schema_digest: evidence.source_schema_digest,
        source_row_count: evidence.source_row_count,
        source_column_family_summary: evidence.source_column_family_summary,
        parse_decode_plan_digest: request.parse_decode_plan_digest.clone(),
        selected_columns: request.selected_columns.clone(),
        output_policy: request.output_policy.clone(),
        prepared_artifact_ref: request.prepared_artifact_path.clone(),
        prepared_artifact_digest: artifact_fingerprint.content_digest,
        prepared_artifact_size_bytes: artifact_fingerprint.size_bytes,
        provider_version: request.provider_version.clone(),
        feature_gates: request.feature_gates.clone(),
        certification_level: request.certification_level.clone(),
        source_state_id: evidence.source_state_id,
        source_state_digest: evidence.source_state_digest,
        prepared_state_id: evidence.prepared_state_id,
        prepared_state_digest: evidence.prepared_state_digest,
        certificate_refs: evidence.certificate_refs,
        fallback_attempted: evidence.fallback_attempted,
        external_engine_invoked: evidence.external_engine_invoked,
    })
}

/// Decision for automatic append-only refinement of an existing prepared state.
#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct VortexPreparedStateAppendOnlyRefinementDecision {
    pub schema_version: &'static str,
    pub status: String,
    pub policy: &'static str,
    pub reason: String,
    pub blocker_id: String,
    pub automatic_detection_status: String,
    pub manifest_path: PathBuf,
    pub reuse_manifest_digest: String,
    pub source_path: PathBuf,
    pub source_format: String,
    pub base_source_content_digest: String,
    pub current_source_content_digest: String,
    pub base_source_size_bytes: u64,
    pub current_source_size_bytes: u64,
    pub delta_byte_start: u64,
    pub delta_byte_end: u64,
    pub changed_byte_range_refs: String,
    pub source_prefix_verification_status: String,
    pub base_source_state_id: String,
    pub base_source_state_digest: String,
    pub base_source_row_count: u64,
    pub base_source_schema_digest: String,
    pub base_source_column_family_summary: String,
    pub base_prepared_state_id: String,
    pub base_prepared_state_digest: String,
    pub prepared_artifact_ref: PathBuf,
    pub prepared_artifact_digest: String,
    pub prepared_artifact_size_bytes: u64,
    pub certificate_refs: String,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

impl VortexPreparedStateAppendOnlyRefinementDecision {
    /// Whether this decision admits automatic append-only refinement.
    #[must_use]
    pub fn is_admitted(&self) -> bool {
        self.status == "admitted_append_only_refinement"
    }

    /// Return stable evidence fields for CLI/API surfaces.
    #[must_use]
    pub fn evidence_fields(&self) -> Vec<(String, String)> {
        vec![
            (
                "vortex_differential_preparation_refinement_schema_version".to_string(),
                self.schema_version.to_string(),
            ),
            (
                "vortex_differential_preparation_refinement_mode".to_string(),
                "automatic_append_only_delta".to_string(),
            ),
            (
                "vortex_differential_preparation_refinement_status".to_string(),
                self.status.clone(),
            ),
            (
                "vortex_differential_preparation_refinement_policy".to_string(),
                self.policy.to_string(),
            ),
            (
                "vortex_differential_preparation_automatic_detection_status".to_string(),
                self.automatic_detection_status.clone(),
            ),
            (
                "vortex_differential_preparation_automatic_detection_reason".to_string(),
                self.reason.clone(),
            ),
            (
                "vortex_differential_preparation_blocker_id".to_string(),
                self.blocker_id.clone(),
            ),
            (
                "vortex_differential_preparation_base_source_content_digest".to_string(),
                self.base_source_content_digest.clone(),
            ),
            (
                "vortex_differential_preparation_current_source_content_digest".to_string(),
                self.current_source_content_digest.clone(),
            ),
            (
                "vortex_differential_preparation_base_source_size_bytes".to_string(),
                self.base_source_size_bytes.to_string(),
            ),
            (
                "vortex_differential_preparation_current_source_size_bytes".to_string(),
                self.current_source_size_bytes.to_string(),
            ),
            (
                "vortex_differential_preparation_delta_byte_start".to_string(),
                self.delta_byte_start.to_string(),
            ),
            (
                "vortex_differential_preparation_delta_byte_end".to_string(),
                self.delta_byte_end.to_string(),
            ),
            (
                "vortex_differential_preparation_source_prefix_verification_status".to_string(),
                self.source_prefix_verification_status.clone(),
            ),
            (
                "vortex_differential_preparation_reuse_manifest_path".to_string(),
                self.manifest_path.display().to_string(),
            ),
            (
                "vortex_differential_preparation_reuse_manifest_digest".to_string(),
                self.reuse_manifest_digest.clone(),
            ),
        ]
    }
}

/// Manifest write result for a scoped automatic differential refinement.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VortexDifferentialRefinementManifestReport {
    pub schema_version: &'static str,
    pub manifest_path: PathBuf,
    pub manifest_digest: String,
    pub manifest_written: bool,
    pub refined_prepared_state_id: String,
    pub refined_prepared_state_digest: String,
    pub overlay_consumer_family: String,
    pub overlay_consumer_status: String,
    pub overlay_consumer_correctness_digest: String,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

impl VortexDifferentialRefinementManifestReport {
    /// Return stable evidence fields for CLI/API surfaces.
    #[must_use]
    pub fn evidence_fields(&self) -> Vec<(String, String)> {
        vec![
            (
                "vortex_differential_preparation_refinement_manifest_schema_version".to_string(),
                self.schema_version.to_string(),
            ),
            (
                "vortex_differential_preparation_refinement_manifest_path".to_string(),
                self.manifest_path.display().to_string(),
            ),
            (
                "vortex_differential_preparation_refinement_manifest_digest".to_string(),
                self.manifest_digest.clone(),
            ),
            (
                "vortex_differential_preparation_refinement_manifest_written".to_string(),
                self.manifest_written.to_string(),
            ),
            (
                "vortex_differential_preparation_refined_prepared_state_id".to_string(),
                self.refined_prepared_state_id.clone(),
            ),
            (
                "vortex_differential_preparation_refined_prepared_state_digest".to_string(),
                self.refined_prepared_state_digest.clone(),
            ),
            (
                "vortex_differential_preparation_overlay_consumer_family".to_string(),
                self.overlay_consumer_family.clone(),
            ),
            (
                "vortex_differential_preparation_overlay_consumer_status".to_string(),
                self.overlay_consumer_status.clone(),
            ),
            (
                "vortex_differential_preparation_overlay_consumer_correctness_digest".to_string(),
                self.overlay_consumer_correctness_digest.clone(),
            ),
            (
                "vortex_differential_preparation_refinement_fallback_attempted".to_string(),
                self.fallback_attempted.to_string(),
            ),
            (
                "vortex_differential_preparation_refinement_external_engine_invoked".to_string(),
                self.external_engine_invoked.to_string(),
            ),
        ]
    }
}

/// Return the artifact-adjacent differential refinement manifest path.
///
/// # Errors
/// Returns [`ShardLoomError::InvalidOperation`] when the artifact path has no
/// local file name.
pub fn vortex_differential_refinement_manifest_path(
    prepared_artifact_path: impl AsRef<Path>,
) -> Result<PathBuf> {
    let path = absolute_local_path(prepared_artifact_path.as_ref())?;
    let Some(file_name) = path.file_name().and_then(|value| value.to_str()) else {
        return Err(ShardLoomError::InvalidOperation(format!(
            "differential refinement manifest requires a local artifact file name for '{}'; no fallback execution was attempted",
            path.display()
        )));
    };
    let parent = path.parent().unwrap_or_else(|| Path::new("."));
    Ok(parent
        .join(".shardloom")
        .join(format!("{file_name}.differential-refinement.manifest")))
}

/// Evaluate whether a prepared-state reuse miss can become an automatic
/// append-only refinement instead of a base reprepare.
///
/// # Errors
/// Returns [`ShardLoomError::InvalidOperation`] when the manifest exists but
/// cannot be read or parsed deterministically.
#[allow(clippy::too_many_lines)]
pub fn evaluate_vortex_prepared_state_append_only_refinement(
    request: &VortexPreparedStateReuseRequest,
) -> Result<VortexPreparedStateAppendOnlyRefinementDecision> {
    if !request.manifest_path.exists() {
        return Ok(append_only_refinement_blocked(
            request,
            "blocked_missing_base_manifest",
            "missing_base_manifest",
            "none",
            &BTreeMap::new(),
        ));
    }
    let fields = read_reuse_manifest_fields(&request.manifest_path)?;
    let manifest_digest = fields
        .get("manifest_digest")
        .cloned()
        .unwrap_or_else(|| "none".to_string());
    let expected_digest = reuse_manifest_digest(&fields);
    if manifest_digest != expected_digest {
        return Ok(append_only_refinement_blocked(
            request,
            "blocked_reuse_manifest_digest_mismatch",
            "reuse_manifest_digest_mismatch",
            &manifest_digest,
            &fields,
        ));
    }
    if fields.get("schema_version").map(String::as_str)
        != Some(VORTEX_PREPARED_STATE_REUSE_SCHEMA_VERSION)
    {
        return Ok(append_only_refinement_blocked(
            request,
            "blocked_reuse_manifest_schema_mismatch",
            "reuse_manifest_schema_mismatch",
            &manifest_digest,
            &fields,
        ));
    }
    if fields.get("fallback_attempted").map(String::as_str) != Some("false") {
        return Ok(append_only_refinement_blocked(
            request,
            "blocked_reuse_manifest_fallback_attempted",
            "reuse_manifest_fallback_attempted",
            &manifest_digest,
            &fields,
        ));
    }
    if fields.get("external_engine_invoked").map(String::as_str) != Some("false") {
        return Ok(append_only_refinement_blocked(
            request,
            "blocked_reuse_manifest_external_engine_invoked",
            "reuse_manifest_external_engine_invoked",
            &manifest_digest,
            &fields,
        ));
    }
    if let Some(reason) = append_only_refinement_static_mismatch_reason(request, &fields) {
        return Ok(append_only_refinement_blocked(
            request,
            &format!("blocked_{reason}"),
            &reason,
            &manifest_digest,
            &fields,
        ));
    }
    if !matches!(request.source_format.as_str(), "csv" | "jsonl") {
        return Ok(append_only_refinement_blocked(
            request,
            "blocked_changed_compression_or_format_posture",
            "changed_compression_or_format_posture",
            &manifest_digest,
            &fields,
        ));
    }

    let Some(base_source_digest) = fields.get("source_content_digest").cloned() else {
        return Ok(append_only_refinement_blocked(
            request,
            "blocked_missing_base_source_content_digest",
            "missing_base_source_content_digest",
            &manifest_digest,
            &fields,
        ));
    };
    let Some(base_source_size_bytes) = fields
        .get("source_size_bytes")
        .and_then(|value| value.parse::<u64>().ok())
    else {
        return Ok(append_only_refinement_blocked(
            request,
            "blocked_missing_base_source_size_bytes",
            "missing_base_source_size_bytes",
            &manifest_digest,
            &fields,
        ));
    };
    if request.source_size_bytes <= base_source_size_bytes {
        return Ok(append_only_refinement_blocked(
            request,
            "blocked_current_source_not_larger",
            "current_source_not_larger",
            &manifest_digest,
            &fields,
        ));
    }
    if request.source_content_digest == base_source_digest {
        return Ok(append_only_refinement_blocked(
            request,
            "blocked_no_source_change",
            "no_source_change",
            &manifest_digest,
            &fields,
        ));
    }
    let prefix_digest = sha256_file_prefix_digest(
        &request.source_path,
        base_source_size_bytes,
        "append-only refinement source prefix",
    )?;
    if prefix_digest != base_source_digest {
        return Ok(append_only_refinement_blocked(
            request,
            "blocked_source_prefix_digest_mismatch",
            "source_prefix_digest_mismatch",
            &manifest_digest,
            &fields,
        ));
    }
    let previous_terminal_byte = byte_at_offset(
        &request.source_path,
        base_source_size_bytes.saturating_sub(1),
        "append-only refinement source boundary",
    )?;
    if !matches!(previous_terminal_byte, b'\n' | b'\r') {
        return Ok(append_only_refinement_blocked(
            request,
            "blocked_append_boundary_not_line_aligned",
            "append_boundary_not_line_aligned",
            &manifest_digest,
            &fields,
        ));
    }
    if missing_refinement_manifest_field(&fields, "source_row_count")
        || missing_refinement_manifest_field(&fields, "source_column_family_summary")
        || missing_refinement_manifest_field(&fields, "source_schema_digest")
    {
        return Ok(append_only_refinement_blocked(
            request,
            "blocked_missing_base_refinement_manifest_fields",
            "missing_base_refinement_manifest_fields",
            &manifest_digest,
            &fields,
        ));
    }
    let Ok(artifact_fingerprint) = LocalReuseFileFingerprint::from_path(
        &request.prepared_artifact_path,
        "base prepared-state refinement artifact",
    ) else {
        return Ok(append_only_refinement_blocked(
            request,
            "blocked_missing_base_prepared_artifact",
            "missing_base_prepared_artifact",
            &manifest_digest,
            &fields,
        ));
    };
    if fields
        .get("prepared_artifact_size_bytes")
        .map(String::as_str)
        != Some(artifact_fingerprint.size_bytes.to_string().as_str())
    {
        return Ok(append_only_refinement_blocked(
            request,
            "blocked_base_prepared_artifact_size_changed",
            "base_prepared_artifact_size_changed",
            &manifest_digest,
            &fields,
        ));
    }
    if fields.get("prepared_artifact_digest").map(String::as_str)
        != Some(artifact_fingerprint.content_digest.as_str())
    {
        return Ok(append_only_refinement_blocked(
            request,
            "blocked_base_prepared_artifact_digest_changed",
            "base_prepared_artifact_digest_changed",
            &manifest_digest,
            &fields,
        ));
    }

    let delta_byte_start = base_source_size_bytes;
    let delta_byte_end = request.source_size_bytes;
    let changed_byte_range_refs = format!(
        "{}#bytes={}..{}",
        request.source_path.display(),
        delta_byte_start,
        delta_byte_end
    );
    Ok(VortexPreparedStateAppendOnlyRefinementDecision {
        schema_version: VORTEX_DIFFERENTIAL_REFINEMENT_MANIFEST_SCHEMA_VERSION,
        status: "admitted_append_only_refinement".to_string(),
        policy: VORTEX_DIFFERENTIAL_REFINEMENT_POLICY,
        reason: "source_prefix_verified_and_delta_bytes_detected".to_string(),
        blocker_id: "none".to_string(),
        automatic_detection_status: "append_only_delta_detected".to_string(),
        manifest_path: request.manifest_path.clone(),
        reuse_manifest_digest: manifest_digest,
        source_path: request.source_path.clone(),
        source_format: request.source_format.clone(),
        base_source_content_digest: base_source_digest,
        current_source_content_digest: request.source_content_digest.clone(),
        base_source_size_bytes,
        current_source_size_bytes: request.source_size_bytes,
        delta_byte_start,
        delta_byte_end,
        changed_byte_range_refs,
        source_prefix_verification_status: "verified_old_source_bytes_are_current_prefix"
            .to_string(),
        base_source_state_id: fields.get("source_state_id").cloned().unwrap_or_default(),
        base_source_state_digest: fields
            .get("source_state_digest")
            .cloned()
            .unwrap_or_default(),
        base_source_row_count: fields
            .get("source_row_count")
            .and_then(|value| value.parse::<u64>().ok())
            .unwrap_or(0),
        base_source_schema_digest: fields
            .get("source_schema_digest")
            .cloned()
            .unwrap_or_default(),
        base_source_column_family_summary: fields
            .get("source_column_family_summary")
            .cloned()
            .unwrap_or_default(),
        base_prepared_state_id: fields.get("prepared_state_id").cloned().unwrap_or_default(),
        base_prepared_state_digest: fields
            .get("prepared_state_digest")
            .cloned()
            .unwrap_or_default(),
        prepared_artifact_ref: request.prepared_artifact_path.clone(),
        prepared_artifact_digest: artifact_fingerprint.content_digest,
        prepared_artifact_size_bytes: artifact_fingerprint.size_bytes,
        certificate_refs: fields
            .get("certificate_refs")
            .cloned()
            .unwrap_or_else(|| "manifest_certificate_refs_missing".to_string()),
        fallback_attempted: false,
        external_engine_invoked: false,
    })
}

/// Write a digest-backed automatic differential refinement manifest.
///
/// # Errors
/// Returns [`ShardLoomError::InvalidOperation`] when the manifest path cannot
/// be written atomically.
#[allow(clippy::too_many_arguments, clippy::too_many_lines)]
pub fn write_vortex_differential_refinement_manifest(
    manifest_path: impl AsRef<Path>,
    decision: &VortexPreparedStateAppendOnlyRefinementDecision,
    differential: &VortexDifferentialPreparationReport,
    refined_prepared_state_id: impl Into<String>,
    refined_prepared_state_digest: impl Into<String>,
    overlay_consumer_family: impl Into<String>,
    overlay_consumer_status: impl Into<String>,
    overlay_consumer_correctness_digest: impl Into<String>,
) -> Result<VortexDifferentialRefinementManifestReport> {
    let manifest_path = absolute_local_path(manifest_path.as_ref())?;
    let refined_prepared_state_id = refined_prepared_state_id.into();
    let refined_prepared_state_digest = refined_prepared_state_digest.into();
    let overlay_consumer_family = overlay_consumer_family.into();
    let overlay_consumer_status = overlay_consumer_status.into();
    let overlay_consumer_correctness_digest = overlay_consumer_correctness_digest.into();
    let mut fields = BTreeMap::new();
    fields.insert(
        "schema_version".to_string(),
        VORTEX_DIFFERENTIAL_REFINEMENT_MANIFEST_SCHEMA_VERSION.to_string(),
    );
    fields.insert(
        "policy".to_string(),
        VORTEX_DIFFERENTIAL_REFINEMENT_POLICY.to_string(),
    );
    fields.insert("status".to_string(), differential.status.clone());
    fields.insert(
        "automatic_detection_status".to_string(),
        decision.automatic_detection_status.clone(),
    );
    fields.insert(
        "base_source_state_id".to_string(),
        differential.base_source_state_id.clone(),
    );
    fields.insert(
        "base_source_state_digest".to_string(),
        differential.base_source_state_digest.clone(),
    );
    fields.insert(
        "base_prepared_state_id".to_string(),
        differential.base_prepared_state_id.clone(),
    );
    fields.insert(
        "base_prepared_state_digest".to_string(),
        differential.base_prepared_state_digest.clone(),
    );
    fields.insert(
        "delta_source_state_id".to_string(),
        differential.delta_source_state_id.clone(),
    );
    fields.insert(
        "delta_source_state_digest".to_string(),
        differential.delta_source_state_digest.clone(),
    );
    fields.insert(
        "base_row_count".to_string(),
        differential.base_row_count.to_string(),
    );
    fields.insert(
        "delta_row_count".to_string(),
        differential.delta_row_count.to_string(),
    );
    fields.insert(
        "delta_manifest_digest".to_string(),
        differential.delta_manifest_digest.clone(),
    );
    fields.insert(
        "overlay_manifest_digest".to_string(),
        differential.overlay_manifest_digest.clone(),
    );
    fields.insert(
        "changed_byte_range_refs".to_string(),
        differential.changed_byte_range_refs.clone(),
    );
    fields.insert(
        "changed_row_range_refs".to_string(),
        differential.changed_row_range_refs.clone(),
    );
    fields.insert(
        "changed_segment_refs".to_string(),
        differential.changed_segment_refs.clone(),
    );
    fields.insert(
        "delta_artifact_ref".to_string(),
        differential.delta_artifact_ref.clone(),
    );
    fields.insert(
        "delta_artifact_digest".to_string(),
        differential.delta_artifact_digest.clone(),
    );
    fields.insert(
        "refined_prepared_state_id".to_string(),
        refined_prepared_state_id.clone(),
    );
    fields.insert(
        "refined_prepared_state_digest".to_string(),
        refined_prepared_state_digest.clone(),
    );
    fields.insert(
        "overlay_consumer_family".to_string(),
        overlay_consumer_family.clone(),
    );
    fields.insert(
        "overlay_consumer_status".to_string(),
        overlay_consumer_status.clone(),
    );
    fields.insert(
        "overlay_consumer_correctness_digest".to_string(),
        overlay_consumer_correctness_digest.clone(),
    );
    fields.insert(
        "fallback_attempted".to_string(),
        differential.fallback_attempted.to_string(),
    );
    fields.insert(
        "external_engine_invoked".to_string(),
        differential.external_engine_invoked.to_string(),
    );
    let manifest_digest = reuse_manifest_digest(&fields);
    fields.insert("manifest_digest".to_string(), manifest_digest.clone());
    write_key_value_manifest_fields(
        &manifest_path,
        &fields,
        "ShardLoom differential refinement manifest",
        "differential refinement manifest",
    )?;
    Ok(VortexDifferentialRefinementManifestReport {
        schema_version: VORTEX_DIFFERENTIAL_REFINEMENT_MANIFEST_SCHEMA_VERSION,
        manifest_path,
        manifest_digest,
        manifest_written: true,
        refined_prepared_state_id,
        refined_prepared_state_digest,
        overlay_consumer_family,
        overlay_consumer_status,
        overlay_consumer_correctness_digest,
        fallback_attempted: differential.fallback_attempted,
        external_engine_invoked: differential.external_engine_invoked,
    })
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct LocalReuseFileFingerprint {
    path: PathBuf,
    size_bytes: u64,
    mtime_ns: String,
    content_digest: String,
}

#[cfg(test)]
thread_local! {
    static LOCAL_FILE_FINGERPRINT_CALLS: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
}

impl LocalReuseFileFingerprint {
    fn from_path(path: &Path, label: &str) -> Result<Self> {
        #[cfg(test)]
        LOCAL_FILE_FINGERPRINT_CALLS.with(|calls| calls.set(calls.get() + 1));
        let path = absolute_local_path(path)?;
        let metadata = fs::metadata(&path).map_err(|error| {
            ShardLoomError::InvalidOperation(format!(
                "failed to stat {label} '{}': {error}; no fallback execution was attempted",
                path.display()
            ))
        })?;
        if !metadata.is_file() {
            return Err(ShardLoomError::InvalidOperation(format!(
                "{label} '{}' must be a local file for prepared-state reuse; no fallback execution was attempted",
                path.display()
            )));
        }
        let modified = metadata
            .modified()
            .ok()
            .and_then(|value| value.duration_since(UNIX_EPOCH).ok())
            .map_or_else(
                || "unknown".to_string(),
                |value| value.as_nanos().to_string(),
            );
        Ok(Self {
            content_digest: sha256_file_digest(&path, label)?,
            path,
            size_bytes: metadata.len(),
            mtime_ns: modified,
        })
    }
}

fn absolute_local_path(path: impl AsRef<Path>) -> Result<PathBuf> {
    let path = path.as_ref();
    if path.as_os_str().is_empty() {
        return Err(ShardLoomError::InvalidOperation(
            "prepared-state reuse local path must not be empty; no fallback execution was attempted"
                .to_string(),
        ));
    }
    if path.is_absolute() {
        Ok(path.to_path_buf())
    } else {
        std::env::current_dir()
            .map(|cwd| cwd.join(path))
            .map_err(|error| {
                ShardLoomError::InvalidOperation(format!(
                    "failed to resolve prepared-state reuse path '{}': {error}; no fallback execution was attempted",
                    path.display()
                ))
            })
    }
}

fn ensure_native_vortex_artifact_extension(path: &Path, label: &str) -> Result<()> {
    let extension = path
        .extension()
        .and_then(|value| value.to_str())
        .map(str::to_ascii_lowercase);
    if matches!(extension.as_deref(), Some("vortex" | "vtx")) {
        return Ok(());
    }
    Err(ShardLoomError::InvalidOperation(format!(
        "{label} '{}' must use a .vortex or .vtx extension; no fallback execution was attempted",
        path.display()
    )))
}

#[cfg(feature = "vortex-write")]
fn local_file_modified_ns(metadata: &fs::Metadata) -> String {
    metadata
        .modified()
        .ok()
        .and_then(|value| value.duration_since(UNIX_EPOCH).ok())
        .map_or_else(
            || "unknown".to_string(),
            |value| value.as_nanos().to_string(),
        )
}

fn micros_to_millis_string(micros: u128) -> String {
    let whole = micros / 1000;
    let frac = micros % 1000;
    if frac == 0 {
        whole.to_string()
    } else {
        format!("{whole}.{frac:03}")
    }
}

#[cfg(feature = "vortex-write")]
/// Admit an existing local `.vortex` artifact as prepared native Vortex state.
///
/// # Errors
///
/// Returns an error when the source or target is not a local `.vortex` file,
/// when source metadata/footer inspection fails, when the source lacks a footer
/// row count, or when the workspace-safe byte-preserving copy cannot be
/// completed. No fallback or external execution engine is invoked.
#[allow(clippy::too_many_lines)]
pub fn prepare_native_vortex_artifact(
    request: &VortexNativeArtifactPrepareRequest,
) -> Result<VortexNativeArtifactPrepareReport> {
    let prepare_start = Instant::now();
    ensure_native_vortex_artifact_extension(&request.source_path, "native Vortex source")?;
    ensure_native_vortex_artifact_extension(&request.target_path, "prepared Vortex target")?;
    let source_metadata = fs::metadata(&request.source_path).map_err(|error| {
        ShardLoomError::InvalidOperation(format!(
            "failed to stat native Vortex source '{}': {error}; no fallback execution was attempted",
            request.source_path.display()
        ))
    })?;
    if !source_metadata.is_file() {
        return Err(ShardLoomError::InvalidOperation(format!(
            "native Vortex source '{}' must be a local file; no fallback execution was attempted",
            request.source_path.display()
        )));
    }
    let source_size_bytes = source_metadata.len();
    let source_mtime_ns = local_file_modified_ns(&source_metadata);
    let source_canonical = fs::canonicalize(&request.source_path).map_err(|error| {
        ShardLoomError::InvalidOperation(format!(
            "failed to canonicalize native Vortex source '{}': {error}; no fallback execution was attempted",
            request.source_path.display()
        ))
    })?;
    let same_artifact_passthrough = if request.target_path == request.source_path {
        true
    } else {
        fs::canonicalize(&request.target_path)
            .is_ok_and(|target_canonical| target_canonical == source_canonical)
    };

    let metadata_open_start = Instant::now();
    let prepared_olap_layout_inventory =
        read_prepared_vortex_artifact_layout_inventory(&request.source_path)?;
    let metadata_open_micros = metadata_open_start.elapsed().as_micros();
    let row_count = prepared_olap_layout_inventory.row_count.ok_or_else(|| {
        ShardLoomError::InvalidOperation(format!(
            "native Vortex source '{}' did not expose a footer row count; no fallback execution was attempted",
            request.source_path.display()
        ))
    })?;

    let layout_digest = prepared_olap_layout_inventory.inventory_digest.clone();
    let metadata_fingerprint = fnv64_digest_text(&format!(
        "native_vortex_artifact|{}|{}|{}|{}|{}",
        source_canonical.display(),
        source_size_bytes,
        source_mtime_ns,
        row_count,
        layout_digest
    ));
    let mut workspace_write_report = None;
    let mut byte_copy_micros = 0;
    let (
        policy,
        status,
        target_size_bytes,
        target_content_digest,
        target_digest_source,
        source_content_digest,
        source_digest_source,
        copy_budget_status,
    ) = if same_artifact_passthrough {
        (
            "vortex_native_prepared_state_pass_through".to_string(),
            "native_vortex_artifact_admitted".to_string(),
            source_size_bytes,
            metadata_fingerprint.clone(),
            "native_vortex_metadata_footer_fingerprint_no_byte_read".to_string(),
            metadata_fingerprint.clone(),
            "native_vortex_metadata_footer_fingerprint_no_byte_read".to_string(),
            "no_copy_same_vortex_artifact".to_string(),
        )
    } else {
        let source_file = fs::File::open(&request.source_path).map_err(|error| {
            ShardLoomError::InvalidOperation(format!(
                "failed to open native Vortex source '{}' for workspace-safe copy: {error}; no fallback execution was attempted",
                request.source_path.display()
            ))
        })?;
        let workspace_root =
            shardloom_core::infer_local_output_workspace_root(&request.target_path)?;
        let copy_start = Instant::now();
        let (copied_bytes, write_report) =
            shardloom_core::write_workspace_safe_bytes_with_validated_producer(
                workspace_root,
                &request.target_path,
                request.allow_overwrite,
                "native vortex artifact workspace-safe copy",
                |writer| {
                    let mut reader = std::io::BufReader::new(source_file);
                    std::io::copy(&mut reader, writer).map_err(|error| {
                        ShardLoomError::InvalidOperation(format!(
                            "failed to copy native Vortex artifact '{}' to '{}': {error}; staging cleanup attempted; no fallback execution was attempted",
                            request.source_path.display(),
                            request.target_path.display()
                        ))
                    })
                },
                |copied_bytes| {
                    if *copied_bytes != source_size_bytes {
                        return Err(ShardLoomError::InvalidOperation(format!(
                            "native Vortex artifact copy byte count mismatch: copied {copied_bytes}, expected {source_size_bytes}; staging cleanup attempted; no fallback execution was attempted",
                        )));
                    }
                    Ok(())
                },
            )?;
        byte_copy_micros = copy_start.elapsed().as_micros();
        if copied_bytes != source_size_bytes {
            return Err(ShardLoomError::InvalidOperation(format!(
                "native Vortex artifact copy byte count mismatch after commit: copied {copied_bytes}, expected {source_size_bytes}; no fallback execution was attempted"
            )));
        }
        let digest = write_report.output_digest.clone();
        let size = write_report.bytes_written;
        workspace_write_report = Some(write_report);
        (
            "vortex_native_workspace_safe_byte_copy".to_string(),
            "native_vortex_artifact_copied".to_string(),
            size,
            digest.clone(),
            "workspace_safe_byte_copy_streaming_sha256_digest".to_string(),
            digest,
            "workspace_safe_byte_copy_streaming_sha256_digest".to_string(),
            "workspace_safe_byte_copy_encoded_layout_preserved".to_string(),
        )
    };
    let target_path = if same_artifact_passthrough {
        request.source_path.clone()
    } else {
        request.target_path.clone()
    };
    let source_state_digest = fnv64_digest_text(&format!(
        "native_vortex_source_state|{}|{}|{}|{}|{}",
        request.source_path.display(),
        source_size_bytes,
        source_mtime_ns,
        row_count,
        layout_digest
    ));
    let prepared_state_digest = fnv64_digest_text(&format!(
        "native_vortex_prepared_state|{}|{}|{}|{}|{}",
        target_path.display(),
        target_size_bytes,
        target_content_digest,
        row_count,
        layout_digest
    ));
    let segment_metadata_primitive = VortexSegmentMetadataPrimitiveReport::from_inventory(
        &prepared_olap_layout_inventory,
        "native_vortex_artifact_prepare",
        "not_applicable_native_vortex_artifact",
    );
    let prepare_once_micros = prepare_start.elapsed().as_micros();
    Ok(VortexNativeArtifactPrepareReport {
        schema_version: VORTEX_NATIVE_ARTIFACT_PREPARE_SCHEMA_VERSION,
        status,
        policy,
        source_path: request.source_path.clone(),
        target_path,
        source_size_bytes,
        source_mtime_ns,
        source_content_digest,
        source_digest_source,
        target_size_bytes,
        target_content_digest,
        target_digest_source,
        row_count,
        prepared_olap_layout_inventory,
        segment_metadata_primitive,
        source_state_id: format!("source_state:native_vortex:{source_state_digest}"),
        source_state_digest,
        prepared_state_id: format!("prepared_state:native_vortex:{prepared_state_digest}"),
        prepared_state_digest,
        encoded_layout_preserved: true,
        reencode_performed: false,
        workspace_copy_performed: !same_artifact_passthrough,
        same_artifact_passthrough,
        upstream_vortex_scan_called: false,
        upstream_vortex_write_called: false,
        layout_rewrite_status: "not_performed_layout_rewrite_requires_encoded_preserving_provider"
            .to_string(),
        copy_budget_status,
        workspace_write_report,
        prepare_once_micros,
        metadata_open_micros,
        byte_copy_micros,
        provider_version: request.provider_version.clone(),
        feature_gates: request.feature_gates.clone(),
        certification_level: request.certification_level.clone(),
        fallback_attempted: false,
        external_engine_invoked: false,
    })
}

#[cfg(not(feature = "vortex-write"))]
/// Admit an existing local `.vortex` artifact as prepared native Vortex state.
///
/// # Errors
///
/// Always returns an error when the binary is compiled without the
/// `vortex-write` feature gate. No fallback or external execution engine is
/// invoked.
pub fn prepare_native_vortex_artifact(
    _request: &VortexNativeArtifactPrepareRequest,
) -> Result<VortexNativeArtifactPrepareReport> {
    Err(ShardLoomError::NotImplemented(
        "vortex_ingest feature gate is not enabled".to_string(),
    ))
}

fn sha256_file_digest(path: &Path, label: &str) -> Result<String> {
    let mut file = fs::File::open(path).map_err(|error| {
        ShardLoomError::InvalidOperation(format!(
            "failed to open {label} '{}' for prepared-state reuse digest: {error}; no fallback execution was attempted",
            path.display()
        ))
    })?;
    let mut digest = sha2::Sha256::new();
    let mut buffer = [0_u8; 8192];
    loop {
        let read = file.read(&mut buffer).map_err(|error| {
            ShardLoomError::InvalidOperation(format!(
                "failed to read {label} '{}' for prepared-state reuse digest: {error}; no fallback execution was attempted",
                path.display()
            ))
        })?;
        if read == 0 {
            break;
        }
        digest.update(&buffer[..read]);
    }
    Ok(sha256_digest_string(digest.finalize()))
}

fn sha256_file_prefix_digest(path: &Path, prefix_len: u64, label: &str) -> Result<String> {
    let mut file = fs::File::open(path).map_err(|error| {
        ShardLoomError::InvalidOperation(format!(
            "failed to open {label} '{}' for digest: {error}; no fallback execution was attempted",
            path.display()
        ))
    })?;
    let mut digest = sha2::Sha256::new();
    let mut buffer = [0_u8; 8192];
    let mut remaining = prefix_len;
    while remaining > 0 {
        let to_read = usize::try_from(remaining.min(buffer.len() as u64)).map_err(|_| {
            ShardLoomError::InvalidOperation(
                "append-only refinement prefix length does not fit usize; no fallback execution was attempted"
                    .to_string(),
            )
        })?;
        let read = file.read(&mut buffer[..to_read]).map_err(|error| {
            ShardLoomError::InvalidOperation(format!(
                "failed to read {label} '{}' for digest: {error}; no fallback execution was attempted",
                path.display()
            ))
        })?;
        if read == 0 {
            return Err(ShardLoomError::InvalidOperation(format!(
                "{label} '{}' ended before expected prefix length {prefix_len}; no fallback execution was attempted",
                path.display()
            )));
        }
        remaining -= u64::try_from(read).map_err(|_| {
            ShardLoomError::InvalidOperation(
                "append-only refinement read length does not fit u64; no fallback execution was attempted"
                    .to_string(),
            )
        })?;
        digest.update(&buffer[..read]);
    }
    Ok(sha256_digest_string(digest.finalize()))
}

fn sha256_digest_string(digest: impl AsRef<[u8]>) -> String {
    let bytes = digest.as_ref();
    let mut encoded = String::with_capacity("sha256:".len() + bytes.len() * 2);
    encoded.push_str("sha256:");
    for byte in bytes {
        write!(&mut encoded, "{byte:02x}").expect("write sha256 hex digest");
    }
    encoded
}

fn digest_algorithm(value: &str) -> &'static str {
    match value.split_once(':').map(|(algorithm, _)| algorithm) {
        Some("sha256") => "sha256",
        Some("fnv64") => "fnv64",
        Some("fnv1a64") => "fnv1a64",
        Some("external_baseline_only") => "external_baseline_only",
        Some("none") | None => "not_available",
        Some(_) => "unknown",
    }
}

fn is_local_artifact_digest(value: &str) -> bool {
    matches!(digest_algorithm(value), "sha256" | "fnv64")
}

fn byte_at_offset(path: &Path, offset: u64, label: &str) -> Result<u8> {
    use std::io::{Seek as _, SeekFrom};

    let mut file = fs::File::open(path).map_err(|error| {
        ShardLoomError::InvalidOperation(format!(
            "failed to open {label} '{}' for boundary check: {error}; no fallback execution was attempted",
            path.display()
        ))
    })?;
    file.seek(SeekFrom::Start(offset)).map_err(|error| {
        ShardLoomError::InvalidOperation(format!(
            "failed to seek {label} '{}' to byte {offset}: {error}; no fallback execution was attempted",
            path.display()
        ))
    })?;
    let mut byte = [0_u8; 1];
    file.read_exact(&mut byte).map_err(|error| {
        ShardLoomError::InvalidOperation(format!(
            "failed to read {label} '{}' at byte {offset}: {error}; no fallback execution was attempted",
            path.display()
        ))
    })?;
    Ok(byte[0])
}

fn append_only_refinement_static_mismatch_reason(
    request: &VortexPreparedStateReuseRequest,
    fields: &BTreeMap<String, String>,
) -> Option<String> {
    let source_path = request.source_path.display().to_string();
    let prepared_artifact_path = request.prepared_artifact_path.display().to_string();
    for (key, expected) in [
        ("policy", VORTEX_PREPARED_STATE_REUSE_POLICY),
        ("source_path", source_path.as_str()),
        ("source_format", request.source_format.as_str()),
        (
            "parse_decode_plan_digest",
            request.parse_decode_plan_digest.as_str(),
        ),
        ("selected_columns", request.selected_columns.as_str()),
        ("output_policy", request.output_policy.as_str()),
        ("prepared_artifact_path", prepared_artifact_path.as_str()),
        ("provider_version", request.provider_version.as_str()),
        ("feature_gates", request.feature_gates.as_str()),
        ("certification_level", request.certification_level.as_str()),
    ] {
        if fields.get(key).map(String::as_str) != Some(expected) {
            return Some(format!("{key}_changed"));
        }
    }
    if let Some(schema_digest) = request.source_schema_digest.as_deref()
        && fields.get("source_schema_digest").map(String::as_str) != Some(schema_digest)
    {
        return Some("source_schema_digest_changed".to_string());
    }
    None
}

fn missing_refinement_manifest_field(fields: &BTreeMap<String, String>, key: &str) -> bool {
    fields.get(key).is_none_or(|value| value.trim().is_empty())
}

fn append_only_refinement_blocked(
    request: &VortexPreparedStateReuseRequest,
    status: &str,
    reason: &str,
    manifest_digest: &str,
    fields: &BTreeMap<String, String>,
) -> VortexPreparedStateAppendOnlyRefinementDecision {
    let base_source_size_bytes = fields
        .get("source_size_bytes")
        .and_then(|value| value.parse::<u64>().ok())
        .unwrap_or(0);
    VortexPreparedStateAppendOnlyRefinementDecision {
        schema_version: VORTEX_DIFFERENTIAL_REFINEMENT_MANIFEST_SCHEMA_VERSION,
        status: status.to_string(),
        policy: VORTEX_DIFFERENTIAL_REFINEMENT_POLICY,
        reason: reason.to_string(),
        blocker_id: reason.to_string(),
        automatic_detection_status: "blocked_before_append_only_delta_detection".to_string(),
        manifest_path: request.manifest_path.clone(),
        reuse_manifest_digest: manifest_digest.to_string(),
        source_path: request.source_path.clone(),
        source_format: request.source_format.clone(),
        base_source_content_digest: fields
            .get("source_content_digest")
            .cloned()
            .unwrap_or_else(|| "none".to_string()),
        current_source_content_digest: request.source_content_digest.clone(),
        base_source_size_bytes,
        current_source_size_bytes: request.source_size_bytes,
        delta_byte_start: base_source_size_bytes,
        delta_byte_end: request.source_size_bytes,
        changed_byte_range_refs: "none".to_string(),
        source_prefix_verification_status: "not_verified".to_string(),
        base_source_state_id: fields.get("source_state_id").cloned().unwrap_or_default(),
        base_source_state_digest: fields
            .get("source_state_digest")
            .cloned()
            .unwrap_or_default(),
        base_source_row_count: fields
            .get("source_row_count")
            .and_then(|value| value.parse::<u64>().ok())
            .unwrap_or(0),
        base_source_schema_digest: fields
            .get("source_schema_digest")
            .cloned()
            .unwrap_or_default(),
        base_source_column_family_summary: fields
            .get("source_column_family_summary")
            .cloned()
            .unwrap_or_default(),
        base_prepared_state_id: fields.get("prepared_state_id").cloned().unwrap_or_default(),
        base_prepared_state_digest: fields
            .get("prepared_state_digest")
            .cloned()
            .unwrap_or_default(),
        prepared_artifact_ref: request.prepared_artifact_path.clone(),
        prepared_artifact_digest: fields
            .get("prepared_artifact_digest")
            .cloned()
            .unwrap_or_else(|| "none".to_string()),
        prepared_artifact_size_bytes: fields
            .get("prepared_artifact_size_bytes")
            .and_then(|value| value.parse::<u64>().ok())
            .unwrap_or(0),
        certificate_refs: fields.get("certificate_refs").cloned().unwrap_or_default(),
        fallback_attempted: false,
        external_engine_invoked: false,
    }
}

fn prepared_state_reuse_miss(
    request: &VortexPreparedStateReuseRequest,
    reason: &str,
    manifest_digest: &str,
) -> VortexPreparedStateReuseReport {
    prepared_state_reuse_miss_with_digest(request, reason, manifest_digest)
}

fn prepared_state_reuse_miss_with_digest(
    request: &VortexPreparedStateReuseRequest,
    reason: &str,
    manifest_digest: &str,
) -> VortexPreparedStateReuseReport {
    VortexPreparedStateReuseReport {
        schema_version: VORTEX_PREPARED_STATE_REUSE_SCHEMA_VERSION,
        status: "prepared_state_reuse_miss".to_string(),
        scope: "artifact_adjacent_manifest_local_vortex_artifacts".to_string(),
        manifest_path: request.manifest_path.clone(),
        policy: VORTEX_PREPARED_STATE_REUSE_POLICY,
        hit: false,
        reason: reason.to_string(),
        manifest_digest: manifest_digest.to_string(),
        invalidation_reason: reason.to_string(),
        manifest_written: false,
        source_path: request.source_path.clone(),
        source_format: request.source_format.clone(),
        source_content_digest: request.source_content_digest.clone(),
        source_size_bytes: request.source_size_bytes,
        source_mtime_ns: request.source_mtime_ns.clone(),
        source_schema_digest: request.source_schema_digest.clone().unwrap_or_default(),
        source_row_count: 0,
        source_column_family_summary: String::new(),
        parse_decode_plan_digest: request.parse_decode_plan_digest.clone(),
        selected_columns: request.selected_columns.clone(),
        output_policy: request.output_policy.clone(),
        prepared_artifact_ref: request.prepared_artifact_path.clone(),
        prepared_artifact_digest: "none".to_string(),
        prepared_artifact_size_bytes: 0,
        provider_version: request.provider_version.clone(),
        feature_gates: request.feature_gates.clone(),
        certification_level: request.certification_level.clone(),
        source_state_id: String::new(),
        source_state_digest: String::new(),
        prepared_state_id: String::new(),
        prepared_state_digest: String::new(),
        certificate_refs: String::new(),
        fallback_attempted: false,
        external_engine_invoked: false,
    }
}

fn reuse_manifest_request_mismatch_reason(
    request: &VortexPreparedStateReuseRequest,
    fields: &BTreeMap<String, String>,
) -> Option<String> {
    let source_size_bytes = request.source_size_bytes.to_string();
    let source_path = request.source_path.display().to_string();
    let prepared_artifact_path = request.prepared_artifact_path.display().to_string();
    for (key, expected) in [
        ("policy", VORTEX_PREPARED_STATE_REUSE_POLICY),
        ("source_path", source_path.as_str()),
        ("source_format", request.source_format.as_str()),
        (
            "source_content_digest",
            request.source_content_digest.as_str(),
        ),
        ("source_size_bytes", source_size_bytes.as_str()),
        (
            "parse_decode_plan_digest",
            request.parse_decode_plan_digest.as_str(),
        ),
        ("selected_columns", request.selected_columns.as_str()),
        ("output_policy", request.output_policy.as_str()),
        ("prepared_artifact_path", prepared_artifact_path.as_str()),
        ("provider_version", request.provider_version.as_str()),
        ("feature_gates", request.feature_gates.as_str()),
        ("certification_level", request.certification_level.as_str()),
    ] {
        if fields.get(key).map(String::as_str) != Some(expected) {
            return Some(format!("{key}_changed"));
        }
    }
    if let Some(schema_digest) = request.source_schema_digest.as_deref()
        && fields.get("source_schema_digest").map(String::as_str) != Some(schema_digest)
    {
        return Some("source_schema_digest_changed".to_string());
    }
    None
}

fn prepared_olap_state_status(
    request: &VortexPreparedOlapStateWriteRequest,
    _exact_sidecar_family_count: usize,
) -> String {
    if request.fallback_attempted {
        "blocked_fallback_attempted".to_string()
    } else if request.external_engine_invoked {
        "blocked_external_engine_invoked".to_string()
    } else if request.source_state_id.trim().is_empty()
        || request.source_state_digest.trim().is_empty()
        || request.source_schema_digest.trim().is_empty()
    {
        "blocked_missing_source_state_evidence".to_string()
    } else if !is_local_artifact_digest(&request.source_content_digest) {
        "blocked_missing_source_content_digest".to_string()
    } else if !prepared_olap_metadata_ref_declared(&request.segment_map_status) {
        "blocked_missing_segment_map".to_string()
    } else if prepared_olap_query_answer_sidecar_declared(request) {
        "blocked_query_answer_sidecar_not_public_runtime".to_string()
    } else {
        "prepared_olap_state_ready".to_string()
    }
}

fn prepared_olap_blocker_id(
    request: &VortexPreparedOlapStateWriteRequest,
    exact_sidecar_family_count: usize,
) -> String {
    match prepared_olap_state_status(request, exact_sidecar_family_count).as_str() {
        "prepared_olap_state_ready" => "none".to_string(),
        "blocked_fallback_attempted" => "prepared_olap_state.fallback_attempted".to_string(),
        "blocked_external_engine_invoked" => {
            "prepared_olap_state.external_engine_invoked".to_string()
        }
        "blocked_missing_source_state_evidence" => {
            "prepared_olap_state.source_state_evidence_missing".to_string()
        }
        "blocked_missing_source_content_digest" => {
            "prepared_olap_state.source_content_digest_missing".to_string()
        }
        "blocked_missing_segment_map" => "prepared_olap_state.segment_map_missing".to_string(),
        "blocked_vortex_layout_footer_inventory_unavailable" => {
            "prepared_olap_state.layout_footer_inventory_unavailable".to_string()
        }
        "blocked_query_answer_sidecar_not_public_runtime" => {
            "prepared_olap_state.query_answer_sidecar_not_public_runtime".to_string()
        }
        _ => "prepared_olap_state.unknown_blocker".to_string(),
    }
}

fn prepared_olap_next_action(blocker_id: &str) -> String {
    match blocker_id {
        "none" => "run queries through native Vortex runtime over the single prepared .vortex artifact; query-answer sidecars are disabled".to_string(),
        "prepared_olap_state.segment_map_missing" => {
            "record embedded Vortex layout/footer statistics posture before prepared-state query admission".to_string()
        }
        "prepared_olap_state.layout_footer_inventory_unavailable" => {
            "recreate the prepared state as a valid single Vortex artifact so footer layout/statistics inventory can be read".to_string()
        }
        "prepared_olap_state.source_state_evidence_missing" => {
            "record SourceState id, digest, and schema digest before publishing prepared OLAP state".to_string()
        }
        "prepared_olap_state.source_content_digest_missing" => {
            "fingerprint the source bytes with a local digest before publishing prepared OLAP state".to_string()
        }
        "prepared_olap_state.query_answer_sidecar_not_public_runtime" => {
            "recreate prepared OLAP evidence from the single Vortex artifact with embedded layout/statistics posture; query-answer sidecars are not public runtime".to_string()
        }
        "prepared_olap_state.fallback_attempted" | "prepared_olap_state.external_engine_invoked" => {
            "rebuild the prepared state through ShardLoom/Vortex-native preparation without external execution".to_string()
        }
        _ => "inspect prepared OLAP single-artifact evidence and rebuild fail-closed".to_string(),
    }
}

fn prepared_olap_admitted_query_families(request: &VortexPreparedOlapStateWriteRequest) -> String {
    let mut families = Vec::new();
    if prepared_olap_metadata_ref_declared(&request.substring_index_manifest) {
        families.push("literal_substring_predicate");
    }
    if prepared_olap_metadata_ref_declared(&request.aggregate_summary_manifest) {
        if request
            .aggregate_summary_manifest
            .contains("aggregate-summary-global-count")
        {
            families.push("exact_global_count_summary");
        } else {
            families.push("exact_group_summary");
        }
    }
    if prepared_olap_metadata_ref_declared(&request.row_position_manifest) {
        families.push("bounded_topk_row_position_locality");
    }
    if prepared_olap_metadata_ref_declared(&request.dictionary_union_manifest) {
        families.push("dictionary_union_exact_distinct");
    }
    if prepared_olap_metadata_ref_declared(&request.derived_column_manifest) {
        families.push("exact_derived_column");
    }
    if families.is_empty() {
        if prepared_olap_metadata_ref_declared(&request.segment_map_status) {
            "native_vortex_runtime,zoned_statistics_pruning_candidate,metadata_count".to_string()
        } else {
            "none".to_string()
        }
    } else {
        families.join(",")
    }
}

fn prepared_olap_exact_sidecar_family_count(
    request: &VortexPreparedOlapStateWriteRequest,
) -> usize {
    [
        &request.substring_index_manifest,
        &request.aggregate_summary_manifest,
        &request.row_position_manifest,
        &request.dictionary_union_manifest,
        &request.derived_column_manifest,
    ]
    .into_iter()
    .filter(|value| prepared_olap_metadata_ref_declared(value))
    .count()
}

fn prepared_olap_query_answer_sidecar_declared(
    request: &VortexPreparedOlapStateWriteRequest,
) -> bool {
    [
        &request.substring_index_manifest,
        &request.aggregate_summary_manifest,
        &request.row_position_manifest,
        &request.dictionary_union_manifest,
        &request.derived_column_manifest,
    ]
    .into_iter()
    .any(|value| prepared_olap_sidecar_ref_declared(value))
}

fn prepared_olap_sidecar_ref_declared(value: &str) -> bool {
    let value = value.trim().to_ascii_lowercase();
    value == "sidecar" || value.starts_with("sidecar:") || value.starts_with("sidecar|")
}

fn prepared_olap_has_sub_second_candidate_family(
    _request: &VortexPreparedOlapStateWriteRequest,
) -> bool {
    false
}

fn prepared_olap_metadata_ref_declared(value: &str) -> bool {
    !matches!(
        value.trim(),
        "" | "none" | "not_declared" | "not_available" | "not_emitted" | "unsupported"
    )
}

fn prepared_olap_state_digest(
    request: &VortexPreparedOlapStateWriteRequest,
    artifact_fingerprint: &LocalReuseFileFingerprint,
    exact_sidecar_family_count: usize,
) -> String {
    let mut digest = sha2::Sha256::new();
    let source_row_count = request.source_row_count.to_string();
    let prepared_artifact_size_bytes = artifact_fingerprint.size_bytes.to_string();
    let exact_sidecar_family_count = exact_sidecar_family_count.to_string();
    for value in [
        VORTEX_PREPARED_OLAP_STATE_SCHEMA_VERSION,
        VORTEX_PREPARED_OLAP_STATE_POLICY,
        request.source_state_id.as_str(),
        request.source_state_digest.as_str(),
        request.source_format.as_str(),
        request.source_content_digest.as_str(),
        request.source_schema_digest.as_str(),
        source_row_count.as_str(),
        artifact_fingerprint.content_digest.as_str(),
        prepared_artifact_size_bytes.as_str(),
        request.prepared_layout_policy.as_str(),
        request.segment_map_status.as_str(),
        request.derived_column_manifest.as_str(),
        request.substring_index_manifest.as_str(),
        request.aggregate_summary_manifest.as_str(),
        request.row_position_manifest.as_str(),
        request.dictionary_union_manifest.as_str(),
        request.feature_gates.as_str(),
        request.certification_level.as_str(),
        exact_sidecar_family_count.as_str(),
    ] {
        digest.update(value.as_bytes());
        digest.update(b"\0");
    }
    sha256_digest_string(digest.finalize())
}

fn prepared_olap_embedded_layout_statistics_contract(
    request: &VortexPreparedOlapStateWriteRequest,
) -> String {
    if prepared_olap_metadata_ref_declared(&request.segment_map_status) {
        format!(
            "{};segment_map_status={}",
            VORTEX_PREPARED_OLAP_METADATA_PRUNING_CONTRACT, request.segment_map_status
        )
    } else {
        "not_admitted_missing_embedded_layout_statistics_status".to_string()
    }
}

fn prepared_olap_query_answer_sidecar_status(
    request: &VortexPreparedOlapStateWriteRequest,
) -> String {
    if prepared_olap_query_answer_sidecar_declared(request) {
        "rejected_declared_query_answer_sidecar_not_public_runtime".to_string()
    } else {
        VORTEX_PREPARED_OLAP_QUERY_ANSWER_SIDECAR_STATUS.to_string()
    }
}

#[allow(clippy::too_many_lines)]
fn prepared_olap_report_from_request(
    request: &VortexPreparedOlapStateWriteRequest,
    artifact_fingerprint: &LocalReuseFileFingerprint,
    mut status: String,
    manifest_digest: String,
    manifest_written: bool,
) -> VortexPreparedOlapStateReport {
    let exact_sidecar_family_count = prepared_olap_exact_sidecar_family_count(request);
    let layout_inventory =
        read_prepared_vortex_artifact_layout_inventory(&request.prepared_artifact_path)
            .unwrap_or_else(|_| {
                VortexPreparedOlapLayoutInventory::unavailable(
                    "blocked_vortex_layout_footer_open_failed",
                )
            });
    if matches!(
        status.as_str(),
        "prepared_olap_state_ready" | "prepared_olap_state_read_through_hit"
    ) && !layout_inventory.is_admitted()
    {
        status = "blocked_vortex_layout_footer_inventory_unavailable".to_string();
    }
    let blocker_id = if matches!(
        status.as_str(),
        "prepared_olap_state_ready" | "prepared_olap_state_read_through_hit"
    ) {
        "none".to_string()
    } else if status == "blocked_vortex_layout_footer_inventory_unavailable" {
        "prepared_olap_state.layout_footer_inventory_unavailable".to_string()
    } else {
        prepared_olap_blocker_id(request, exact_sidecar_family_count)
    };
    let query_time_contract = if blocker_id == "none" {
        VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_QUERY_TIME_CONTRACT.to_string()
    } else {
        "not_admitted_for_prepared_olap_query_time".to_string()
    };
    let sub_second_candidate =
        blocker_id == "none" && prepared_olap_has_sub_second_candidate_family(request);
    let state_digest =
        prepared_olap_state_digest(request, artifact_fingerprint, exact_sidecar_family_count);
    let state_id = format!(
        "prepared-olap-state-{}",
        state_digest
            .strip_prefix("sha256:")
            .unwrap_or(state_digest.as_str())
    );
    let layout_inventory_status = layout_inventory.status.clone();
    let layout_inventory_digest = layout_inventory.inventory_digest.clone();
    let layout_footer_row_count = layout_inventory.row_count_field();
    let layout_footer_segment_count = layout_inventory.segment_count_field();
    let layout_footer_statistics_status = layout_inventory.statistics_status.clone();
    let layout_footer_encoding_layout_status = layout_inventory.encoding_layout_status.clone();
    let layout_artifact_size_bytes = layout_inventory.artifact_size_bytes_field();
    let layout_footer_approx_bytes = layout_inventory.approx_footer_bytes_field();
    let layout_footer_dtype_summary = layout_inventory.dtype_summary.clone();
    let layout_root_encoding = layout_inventory.root_layout_encoding.clone();
    let layout_encoding_inventory = layout_inventory.layout_encoding_inventory.clone();
    let layout_per_column_metadata_contract = layout_inventory.per_column_metadata_contract.clone();
    let layout_segment_membership_status = layout_inventory.segment_membership_status.clone();
    let layout_domain_dictionary_status = layout_inventory.domain_dictionary_status.clone();
    let layout_derived_stats_status = layout_inventory.derived_layout_stats_status.clone();
    let layout_row_position_locality_status = layout_inventory.row_position_locality_status.clone();
    let layout_reader_cache_status = layout_inventory.layout_reader_cache_status.clone();
    let layout_operator_selection_metadata_status =
        layout_inventory.operator_selection_metadata_status.clone();
    let layout_size_attribution = layout_inventory.layout_size_attribution.clone();
    VortexPreparedOlapStateReport {
        schema_version: VORTEX_PREPARED_OLAP_STATE_SCHEMA_VERSION,
        status,
        policy: VORTEX_PREPARED_OLAP_STATE_POLICY,
        manifest_path: request.manifest_path.clone(),
        manifest_digest,
        manifest_written,
        state_id,
        state_digest,
        source_state_id: request.source_state_id.clone(),
        source_state_digest: request.source_state_digest.clone(),
        source_format: request.source_format.clone(),
        source_content_digest: request.source_content_digest.clone(),
        source_size_bytes: request.source_size_bytes,
        source_schema_digest: request.source_schema_digest.clone(),
        source_row_count: request.source_row_count,
        prepared_artifact_ref: request.prepared_artifact_path.clone(),
        prepared_artifact_digest: artifact_fingerprint.content_digest.clone(),
        prepared_artifact_size_bytes: artifact_fingerprint.size_bytes,
        artifact_model: VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_MODEL.to_string(),
        prepared_layout_policy: request.prepared_layout_policy.clone(),
        segment_map_status: request.segment_map_status.clone(),
        writer_layout_strategy: VORTEX_PREPARED_OLAP_WRITER_LAYOUT_STRATEGY.to_string(),
        embedded_layout_statistics_contract: prepared_olap_embedded_layout_statistics_contract(
            request,
        ),
        layout_inventory_status,
        layout_inventory_digest,
        layout_footer_row_count,
        layout_footer_segment_count,
        layout_footer_statistics_status,
        layout_footer_encoding_layout_status,
        layout_artifact_size_bytes,
        layout_footer_approx_bytes,
        layout_footer_dtype_summary,
        layout_root_encoding,
        layout_encoding_inventory,
        layout_per_column_metadata_contract,
        layout_segment_membership_status,
        layout_domain_dictionary_status,
        layout_derived_stats_status,
        layout_row_position_locality_status,
        layout_reader_cache_status,
        layout_metadata_persisted_in_artifact: layout_inventory.metadata_persisted_in_artifact,
        layout_operator_selection_metadata_status,
        layout_size_attribution,
        dictionary_metadata_policy: VORTEX_PREPARED_OLAP_DICTIONARY_METADATA_POLICY.to_string(),
        metadata_pruning_contract: VORTEX_PREPARED_OLAP_METADATA_PRUNING_CONTRACT.to_string(),
        query_answer_sidecar_status: prepared_olap_query_answer_sidecar_status(request),
        derived_column_manifest: request.derived_column_manifest.clone(),
        substring_index_manifest: request.substring_index_manifest.clone(),
        aggregate_summary_manifest: request.aggregate_summary_manifest.clone(),
        row_position_manifest: request.row_position_manifest.clone(),
        dictionary_union_manifest: request.dictionary_union_manifest.clone(),
        admitted_query_families: prepared_olap_admitted_query_families(request),
        exact_sidecar_family_count,
        query_time_contract,
        sub_second_candidate,
        next_action: prepared_olap_next_action(&blocker_id),
        blocker_id,
        feature_gates: request.feature_gates.clone(),
        certification_level: request.certification_level.clone(),
        certificate_refs: request.certificate_refs.clone(),
        fallback_attempted: request.fallback_attempted,
        external_engine_invoked: request.external_engine_invoked,
    }
}

#[allow(clippy::too_many_lines)]
fn prepared_olap_blocked_report(
    request: &VortexPreparedOlapStateWriteRequest,
    status: &str,
    blocker_id: &str,
    next_action: &str,
    manifest_digest: &str,
    artifact_fingerprint: Option<&LocalReuseFileFingerprint>,
) -> VortexPreparedOlapStateReport {
    let exact_sidecar_family_count = prepared_olap_exact_sidecar_family_count(request);
    let state_digest = artifact_fingerprint.map_or_else(
        || "none".to_string(),
        |fingerprint| prepared_olap_state_digest(request, fingerprint, exact_sidecar_family_count),
    );
    let state_id = state_digest.strip_prefix("sha256:").map_or_else(
        || "none".to_string(),
        |value| format!("prepared-olap-state-{value}"),
    );
    let layout_inventory = artifact_fingerprint.map_or_else(
        || VortexPreparedOlapLayoutInventory::unavailable(status),
        |_| {
            read_prepared_vortex_artifact_layout_inventory(&request.prepared_artifact_path)
                .unwrap_or_else(|_| {
                    VortexPreparedOlapLayoutInventory::unavailable(
                        "blocked_vortex_layout_footer_open_failed",
                    )
                })
        },
    );
    let layout_inventory_status = layout_inventory.status.clone();
    let layout_inventory_digest = layout_inventory.inventory_digest.clone();
    let layout_footer_row_count = layout_inventory.row_count_field();
    let layout_footer_segment_count = layout_inventory.segment_count_field();
    let layout_footer_statistics_status = layout_inventory.statistics_status.clone();
    let layout_footer_encoding_layout_status = layout_inventory.encoding_layout_status.clone();
    let layout_artifact_size_bytes = layout_inventory.artifact_size_bytes_field();
    let layout_footer_approx_bytes = layout_inventory.approx_footer_bytes_field();
    let layout_footer_dtype_summary = layout_inventory.dtype_summary.clone();
    let layout_root_encoding = layout_inventory.root_layout_encoding.clone();
    let layout_encoding_inventory = layout_inventory.layout_encoding_inventory.clone();
    let layout_per_column_metadata_contract = layout_inventory.per_column_metadata_contract.clone();
    let layout_segment_membership_status = layout_inventory.segment_membership_status.clone();
    let layout_domain_dictionary_status = layout_inventory.domain_dictionary_status.clone();
    let layout_derived_stats_status = layout_inventory.derived_layout_stats_status.clone();
    let layout_row_position_locality_status = layout_inventory.row_position_locality_status.clone();
    let layout_reader_cache_status = layout_inventory.layout_reader_cache_status.clone();
    let layout_operator_selection_metadata_status =
        layout_inventory.operator_selection_metadata_status.clone();
    let layout_size_attribution = layout_inventory.layout_size_attribution.clone();
    VortexPreparedOlapStateReport {
        schema_version: VORTEX_PREPARED_OLAP_STATE_SCHEMA_VERSION,
        status: status.to_string(),
        policy: VORTEX_PREPARED_OLAP_STATE_POLICY,
        manifest_path: request.manifest_path.clone(),
        manifest_digest: manifest_digest.to_string(),
        manifest_written: false,
        state_id,
        state_digest,
        source_state_id: request.source_state_id.clone(),
        source_state_digest: request.source_state_digest.clone(),
        source_format: request.source_format.clone(),
        source_content_digest: request.source_content_digest.clone(),
        source_size_bytes: request.source_size_bytes,
        source_schema_digest: request.source_schema_digest.clone(),
        source_row_count: request.source_row_count,
        prepared_artifact_ref: request.prepared_artifact_path.clone(),
        prepared_artifact_digest: artifact_fingerprint.map_or_else(
            || "none".to_string(),
            |fingerprint| fingerprint.content_digest.clone(),
        ),
        prepared_artifact_size_bytes: artifact_fingerprint
            .map_or(0, |fingerprint| fingerprint.size_bytes),
        artifact_model: VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_MODEL.to_string(),
        prepared_layout_policy: request.prepared_layout_policy.clone(),
        segment_map_status: request.segment_map_status.clone(),
        writer_layout_strategy: VORTEX_PREPARED_OLAP_WRITER_LAYOUT_STRATEGY.to_string(),
        embedded_layout_statistics_contract: prepared_olap_embedded_layout_statistics_contract(
            request,
        ),
        layout_inventory_status,
        layout_inventory_digest,
        layout_footer_row_count,
        layout_footer_segment_count,
        layout_footer_statistics_status,
        layout_footer_encoding_layout_status,
        layout_artifact_size_bytes,
        layout_footer_approx_bytes,
        layout_footer_dtype_summary,
        layout_root_encoding,
        layout_encoding_inventory,
        layout_per_column_metadata_contract,
        layout_segment_membership_status,
        layout_domain_dictionary_status,
        layout_derived_stats_status,
        layout_row_position_locality_status,
        layout_reader_cache_status,
        layout_metadata_persisted_in_artifact: layout_inventory.metadata_persisted_in_artifact,
        layout_operator_selection_metadata_status,
        layout_size_attribution,
        dictionary_metadata_policy: VORTEX_PREPARED_OLAP_DICTIONARY_METADATA_POLICY.to_string(),
        metadata_pruning_contract: VORTEX_PREPARED_OLAP_METADATA_PRUNING_CONTRACT.to_string(),
        query_answer_sidecar_status: prepared_olap_query_answer_sidecar_status(request),
        derived_column_manifest: request.derived_column_manifest.clone(),
        substring_index_manifest: request.substring_index_manifest.clone(),
        aggregate_summary_manifest: request.aggregate_summary_manifest.clone(),
        row_position_manifest: request.row_position_manifest.clone(),
        dictionary_union_manifest: request.dictionary_union_manifest.clone(),
        admitted_query_families: prepared_olap_admitted_query_families(request),
        exact_sidecar_family_count,
        query_time_contract: "not_admitted_for_prepared_olap_query_time".to_string(),
        sub_second_candidate: false,
        blocker_id: blocker_id.to_string(),
        next_action: next_action.to_string(),
        feature_gates: request.feature_gates.clone(),
        certification_level: request.certification_level.clone(),
        certificate_refs: request.certificate_refs.clone(),
        fallback_attempted: request.fallback_attempted,
        external_engine_invoked: request.external_engine_invoked,
    }
}

fn read_reuse_manifest_fields(path: &Path) -> Result<BTreeMap<String, String>> {
    let text = fs::read_to_string(path).map_err(|error| {
        ShardLoomError::InvalidOperation(format!(
            "failed to read prepared-state reuse manifest '{}': {error}; no fallback execution was attempted",
            path.display()
        ))
    })?;
    let mut fields = BTreeMap::new();
    for (line_index, line) in text.lines().enumerate() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        let Some((key, value)) = trimmed.split_once('=') else {
            return Err(ShardLoomError::InvalidOperation(format!(
                "prepared-state reuse manifest '{}' line {} is not key=value; no fallback execution was attempted",
                path.display(),
                line_index + 1
            )));
        };
        if key.trim().is_empty() {
            return Err(ShardLoomError::InvalidOperation(format!(
                "prepared-state reuse manifest '{}' line {} has an empty key; no fallback execution was attempted",
                path.display(),
                line_index + 1
            )));
        }
        fields.insert(
            key.trim().to_string(),
            unescape_manifest_value(value.trim())?,
        );
    }
    Ok(fields)
}

fn write_reuse_manifest_fields(path: &Path, fields: &BTreeMap<String, String>) -> Result<()> {
    write_key_value_manifest_fields(
        path,
        fields,
        "ShardLoom prepared-state reuse manifest",
        "prepared-state reuse manifest",
    )
}

fn write_key_value_manifest_fields(
    path: &Path,
    fields: &BTreeMap<String, String>,
    title: &str,
    error_label: &str,
) -> Result<()> {
    let mut content = String::new();
    writeln!(&mut content, "# {title}").map_err(|error| {
        ShardLoomError::InvalidOperation(format!(
            "failed to render {error_label} header: {error}; no fallback execution was attempted"
        ))
    })?;
    for (key, value) in fields {
        writeln!(&mut content, "{key}={}", escape_manifest_value(value)).map_err(|error| {
            ShardLoomError::InvalidOperation(format!(
                "failed to render {error_label} field '{key}': {error}; no fallback execution was attempted"
            ))
        })?;
    }
    let workspace_root = key_value_manifest_workspace_root(path)?;
    shardloom_core::write_workspace_safe_bytes(
        workspace_root,
        path,
        true,
        format!("{title} ({error_label})"),
        content.as_bytes(),
    )
    .map(|_| ())
    .map_err(|error| {
        ShardLoomError::InvalidOperation(format!(
            "failed to publish {error_label} '{}': {error}; no fallback execution was attempted",
            path.display()
        ))
    })
}

fn key_value_manifest_workspace_root(path: &Path) -> Result<PathBuf> {
    let Some(parent) = path.parent() else {
        return shardloom_core::infer_local_output_workspace_root(path);
    };
    if parent.file_name().and_then(std::ffi::OsStr::to_str) == Some(".shardloom")
        && let Some(artifact_parent) = parent.parent()
    {
        return Ok(artifact_parent.to_path_buf());
    }
    shardloom_core::infer_local_output_workspace_root(path)
}

fn reuse_manifest_digest(fields: &BTreeMap<String, String>) -> String {
    let mut digest = sha2::Sha256::new();
    for (key, value) in fields
        .iter()
        .filter(|(key, _)| !matches!(key.as_str(), "manifest_digest" | "sidecar_digest"))
    {
        digest.update(key.as_bytes());
        digest.update(b"=");
        digest.update(value.as_bytes());
        digest.update(b"\0");
    }
    sha256_digest_string(digest.finalize())
}

fn escape_manifest_value(value: &str) -> String {
    let mut escaped = String::with_capacity(value.len());
    for ch in value.chars() {
        match ch {
            '%' => escaped.push_str("%25"),
            '\n' => escaped.push_str("%0A"),
            '\r' => escaped.push_str("%0D"),
            '=' => escaped.push_str("%3D"),
            _ => escaped.push(ch),
        }
    }
    escaped
}

fn unescape_manifest_value(value: &str) -> Result<String> {
    let mut output = String::with_capacity(value.len());
    let mut chars = value.chars();
    while let Some(ch) = chars.next() {
        if ch != '%' {
            output.push(ch);
            continue;
        }
        let hi = chars.next().ok_or_else(invalid_manifest_escape)?;
        let lo = chars.next().ok_or_else(invalid_manifest_escape)?;
        match (hi, lo) {
            ('2', '5') => output.push('%'),
            ('0', 'A' | 'a') => output.push('\n'),
            ('0', 'D' | 'd') => output.push('\r'),
            ('3', 'D' | 'd') => output.push('='),
            _ => return Err(invalid_manifest_escape()),
        }
    }
    Ok(output)
}

fn invalid_manifest_escape() -> ShardLoomError {
    ShardLoomError::InvalidOperation(
        "prepared-state reuse manifest contains an invalid percent escape; no fallback execution was attempted"
            .to_string(),
    )
}

/// Request to write one flat scalar local source into a local Vortex artifact.
#[derive(Debug, Clone, PartialEq)]
pub struct VortexPreparedStateWriteRequest {
    pub target_path: PathBuf,
    pub columns: Vec<String>,
    pub column_dtypes: Vec<Option<LogicalDType>>,
    #[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
    pub column_arrow_dtypes: Vec<Option<ArrowDataType>>,
    pub rows: Vec<Vec<(String, ScalarValue)>>,
    pub allow_overwrite: bool,
    pub certification_level: VortexIngestCertificationLevel,
    pub layout_write_advisor: Option<VortexLayoutWriteAdvisorReport>,
    pub capillary_prewrite_input: Option<VortexCapillaryPreparationInput>,
}

/// Request to write one flat columnar local source into a Vortex artifact.
#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
#[derive(Debug, Clone, PartialEq)]
pub struct VortexPreparedStateColumnarWriteRequest {
    pub target_path: PathBuf,
    pub source: FlatLocalColumnarSource,
    pub allow_overwrite: bool,
    pub certification_level: VortexIngestCertificationLevel,
    pub layout_write_advisor: Option<VortexLayoutWriteAdvisorReport>,
    pub capillary_prewrite_input: Option<VortexCapillaryPreparationInput>,
}

/// Request to stream one flat columnar local source into a Vortex artifact.
#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
pub struct VortexPreparedStateColumnarStreamWriteRequest {
    pub target_path: PathBuf,
    pub source: FlatLocalColumnarStreamSource,
    pub allow_overwrite: bool,
    pub certification_level: VortexIngestCertificationLevel,
    pub layout_write_advisor: Option<VortexLayoutWriteAdvisorReport>,
    pub capillary_prewrite_input: Option<VortexCapillaryPreparationInput>,
    /// Opt into lifetime-owned imported buffers and the shared native allocator.
    /// Source-reader internals and native allocations bypassing that allocator
    /// remain outside the admitted scope.
    pub shared_native_memory_budget_bytes: Option<u64>,
    /// Optional single-artifact preparation provenance, validated before commit.
    pub prepared_source_binding: Option<String>,
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
impl VortexPreparedStateColumnarWriteRequest {
    /// Create a request for a columnar local `VortexPreparedState` artifact write.
    #[must_use]
    pub fn new(target_path: impl Into<PathBuf>, source: FlatLocalColumnarSource) -> Self {
        Self {
            target_path: target_path.into(),
            source,
            allow_overwrite: false,
            certification_level: VortexIngestCertificationLevel::IngestCertified,
            layout_write_advisor: None,
            capillary_prewrite_input: None,
        }
    }

    /// Allow overwriting an existing local target artifact.
    #[must_use]
    pub const fn allow_overwrite(mut self, allow_overwrite: bool) -> Self {
        self.allow_overwrite = allow_overwrite;
        self
    }

    /// Set the requested ingest certification depth.
    #[must_use]
    pub const fn certification_level(
        mut self,
        certification_level: VortexIngestCertificationLevel,
    ) -> Self {
        self.certification_level = certification_level;
        self
    }

    /// Attach pre-write capillary control input for the local cold-preparation route.
    #[must_use]
    pub fn capillary_prewrite_input(mut self, input: VortexCapillaryPreparationInput) -> Self {
        self.capillary_prewrite_input = Some(input);
        self
    }

    /// Attach the caller's layout/write advisor decision so the writer can
    /// fail closed before applying unsupported write behavior.
    #[must_use]
    pub fn layout_write_advisor(mut self, report: VortexLayoutWriteAdvisorReport) -> Self {
        self.layout_write_advisor = Some(report);
        self
    }
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
impl VortexPreparedStateColumnarStreamWriteRequest {
    /// Create a request for a streaming columnar local `VortexPreparedState`
    /// artifact write.
    #[must_use]
    pub fn new(target_path: impl Into<PathBuf>, source: FlatLocalColumnarStreamSource) -> Self {
        Self {
            target_path: target_path.into(),
            source,
            allow_overwrite: false,
            certification_level: VortexIngestCertificationLevel::IngestCertified,
            layout_write_advisor: None,
            capillary_prewrite_input: None,
            shared_native_memory_budget_bytes: None,
            prepared_source_binding: None,
        }
    }

    /// Share this budget across copied native input buffers, prefetch admission,
    /// and provider host allocations. All imported Arrow buffers are copied;
    /// original source/input owners and allocator-bypassing allocations remain
    /// outside this accounting. Uses bounded per-source-batch subtrees; native
    /// coalescing and dictionary domains do not cross source batches.
    #[must_use]
    pub const fn shared_native_memory_budget_bytes(mut self, bytes: u64) -> Self {
        self.shared_native_memory_budget_bytes = Some(bytes);
        self
    }

    /// Allow overwriting an existing local target artifact.
    #[must_use]
    pub const fn allow_overwrite(mut self, allow_overwrite: bool) -> Self {
        self.allow_overwrite = allow_overwrite;
        self
    }

    /// Set the requested ingest certification depth.
    #[must_use]
    pub const fn certification_level(
        mut self,
        certification_level: VortexIngestCertificationLevel,
    ) -> Self {
        self.certification_level = certification_level;
        self
    }

    /// Attach pre-write capillary control input for the local cold-preparation route.
    #[must_use]
    pub fn capillary_prewrite_input(mut self, input: VortexCapillaryPreparationInput) -> Self {
        self.capillary_prewrite_input = Some(input);
        self
    }

    /// Attach the caller's layout/write advisor decision so the writer can
    /// fail closed before applying unsupported write behavior.
    #[must_use]
    pub fn layout_write_advisor(mut self, report: VortexLayoutWriteAdvisorReport) -> Self {
        self.layout_write_advisor = Some(report);
        self
    }
}

impl VortexPreparedStateWriteRequest {
    /// Create a request for a local `VortexPreparedState` artifact write.
    #[must_use]
    pub fn new(
        target_path: impl Into<PathBuf>,
        columns: Vec<String>,
        rows: Vec<Vec<(String, ScalarValue)>>,
    ) -> Self {
        let column_dtypes = vec![None; columns.len()];
        #[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
        let column_arrow_dtypes = vec![None; columns.len()];
        Self {
            target_path: target_path.into(),
            columns,
            column_dtypes,
            #[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
            column_arrow_dtypes,
            rows,
            allow_overwrite: false,
            certification_level: VortexIngestCertificationLevel::IngestCertified,
            layout_write_advisor: None,
            capillary_prewrite_input: None,
        }
    }

    /// Attach logical dtype hints for flat scalar output columns.
    #[must_use]
    pub fn column_dtypes(mut self, column_dtypes: Vec<Option<LogicalDType>>) -> Self {
        self.column_dtypes = column_dtypes;
        self
    }

    /// Attach source-schema Arrow dtype hints for scoped typed nested output
    /// columns.
    #[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
    #[must_use]
    pub fn column_arrow_dtypes(mut self, column_arrow_dtypes: Vec<Option<ArrowDataType>>) -> Self {
        self.column_arrow_dtypes = column_arrow_dtypes;
        self
    }

    /// Allow overwriting an existing local target artifact.
    #[must_use]
    pub const fn allow_overwrite(mut self, allow_overwrite: bool) -> Self {
        self.allow_overwrite = allow_overwrite;
        self
    }

    /// Set the requested ingest certification depth.
    #[must_use]
    pub const fn certification_level(
        mut self,
        certification_level: VortexIngestCertificationLevel,
    ) -> Self {
        self.certification_level = certification_level;
        self
    }

    /// Attach pre-write capillary control input for the local cold-preparation route.
    #[must_use]
    pub fn capillary_prewrite_input(mut self, input: VortexCapillaryPreparationInput) -> Self {
        self.capillary_prewrite_input = Some(input);
        self
    }

    /// Attach the caller's layout/write advisor decision so the writer can
    /// fail closed before applying unsupported write behavior.
    #[must_use]
    pub fn layout_write_advisor(mut self, report: VortexLayoutWriteAdvisorReport) -> Self {
        self.layout_write_advisor = Some(report);
        self
    }
}

/// Certification depth for the scoped local `vortex_ingest` lifecycle.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VortexIngestCertificationLevel {
    /// Write a local artifact and report bytes/digest/writer evidence only.
    IngestMinimal,
    /// Write and reopen the artifact metadata for row-count proof.
    IngestCertified,
    /// Requires downstream result replay/output evidence, so this prepare-only helper blocks it.
    IngestFullReplay,
}

impl VortexIngestCertificationLevel {
    /// Parse a command/API certification-depth token.
    ///
    /// # Errors
    /// Returns an error when the value is not one of the admitted certification
    /// depth tokens.
    pub fn parse(value: &str) -> Result<Self> {
        match value.trim() {
            "ingest_minimal" => Ok(Self::IngestMinimal),
            "ingest_certified" => Ok(Self::IngestCertified),
            "ingest_full_replay" => Ok(Self::IngestFullReplay),
            other => Err(ShardLoomError::InvalidOperation(format!(
                "unknown vortex_ingest certification level '{other}'; expected ingest_minimal, ingest_certified, or ingest_full_replay; no fallback execution was attempted"
            ))),
        }
    }

    /// Return the canonical evidence token for this certification depth.
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::IngestMinimal => "ingest_minimal",
            Self::IngestCertified => "ingest_certified",
            Self::IngestFullReplay => "ingest_full_replay",
        }
    }
}

/// Source/sink/split evidence for the scoped local Vortex preparation spine.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VortexPreparationSpineReport {
    pub schema_version: &'static str,
    pub status: String,
    pub vortex_first_decision: String,
    pub provider_kind: String,
    pub provider_crate: String,
    pub provider_version: String,
    pub feature_gate: String,
    pub provider_api_surface: String,
    pub shardloom_admission_policy: String,
    pub source_surface: String,
    pub sink_surface: String,
    pub split_surface: String,
    pub split_ref_status: String,
    pub split_count: usize,
    pub projection_mask_status: String,
    pub filter_mask_status: String,
    pub write_provider_surface: String,
    pub reopen_provider_surface: String,
    pub materialization_boundary_status: String,
    pub decode_boundary_status: String,
    pub native_io_certificate_status: String,
    pub native_io_certificate_refs: String,
    pub claim_gate_status: String,
    pub claim_boundary: String,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

impl VortexPreparationSpineReport {
    /// Return stable evidence fields for CLI/API surfaces.
    #[must_use]
    pub fn evidence_fields(&self) -> Vec<(String, String)> {
        let mut fields = Vec::with_capacity(26);
        self.append_provider_evidence_fields(&mut fields);
        self.append_surface_evidence_fields(&mut fields);
        self.append_boundary_evidence_fields(&mut fields);
        fields.push((
            "vortex_preparation_spine_fallback_attempted".to_string(),
            self.fallback_attempted.to_string(),
        ));
        fields.push((
            "vortex_preparation_spine_external_engine_invoked".to_string(),
            self.external_engine_invoked.to_string(),
        ));
        fields
    }

    fn push_evidence_field(
        fields: &mut Vec<(String, String)>,
        key: &'static str,
        value: impl Into<String>,
    ) {
        fields.push((key.to_string(), value.into()));
    }

    fn append_provider_evidence_fields(&self, fields: &mut Vec<(String, String)>) {
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_schema_version",
            self.schema_version,
        );
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_status",
            self.status.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_vortex_first_decision",
            self.vortex_first_decision.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_provider_kind",
            self.provider_kind.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_provider_crate",
            self.provider_crate.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_provider_version",
            self.provider_version.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_feature_gate",
            self.feature_gate.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_provider_api_surface",
            self.provider_api_surface.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_shardloom_admission_policy",
            self.shardloom_admission_policy.as_str(),
        );
    }

    fn append_surface_evidence_fields(&self, fields: &mut Vec<(String, String)>) {
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_source_surface",
            self.source_surface.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_sink_surface",
            self.sink_surface.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_split_surface",
            self.split_surface.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_split_ref_status",
            self.split_ref_status.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_split_count",
            self.split_count.to_string(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_projection_mask_status",
            self.projection_mask_status.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_filter_mask_status",
            self.filter_mask_status.as_str(),
        );
    }

    fn append_boundary_evidence_fields(&self, fields: &mut Vec<(String, String)>) {
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_write_provider_surface",
            self.write_provider_surface.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_reopen_provider_surface",
            self.reopen_provider_surface.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_materialization_boundary_status",
            self.materialization_boundary_status.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_decode_boundary_status",
            self.decode_boundary_status.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_native_io_certificate_status",
            self.native_io_certificate_status.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_native_io_certificate_refs",
            self.native_io_certificate_refs.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_claim_gate_status",
            self.claim_gate_status.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_preparation_spine_claim_boundary",
            self.claim_boundary.as_str(),
        );
    }
}

/// Delta update modes accepted or blocked by scoped differential preparation.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VortexDifferentialUpdateMode {
    /// Append-only delta rows may be overlaid when base and delta schemas match.
    AppendOnly,
    /// In-place updates remain blocked until row identity and rewrite semantics are certified.
    Update,
    /// Deletes remain blocked until tombstone semantics and replay are certified.
    Delete,
    /// Mixed insert/update semantics remain blocked until conflict handling is certified.
    Upsert,
}

impl VortexDifferentialUpdateMode {
    /// Parse a differential-preparation update-mode token.
    ///
    /// # Errors
    /// Returns an error when the token is not one of the deterministic update-mode values.
    pub fn parse(value: &str) -> Result<Self> {
        match value.trim() {
            "append-only" | "append_only" => Ok(Self::AppendOnly),
            "update" => Ok(Self::Update),
            "delete" => Ok(Self::Delete),
            "upsert" => Ok(Self::Upsert),
            other => Err(ShardLoomError::InvalidOperation(format!(
                "unknown vortex_ingest differential update mode '{other}'; expected append-only, update, delete, or upsert; no fallback execution was attempted"
            ))),
        }
    }

    /// Return the canonical evidence token for this update mode.
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::AppendOnly => "append_only",
            Self::Update => "update",
            Self::Delete => "delete",
            Self::Upsert => "upsert",
        }
    }

    const fn is_append_only(self) -> bool {
        matches!(self, Self::AppendOnly)
    }
}

/// Inputs used to validate a scoped local differential Vortex preparation overlay.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VortexDifferentialPreparationInput {
    pub update_mode: VortexDifferentialUpdateMode,
    pub base_source_state_id: String,
    pub base_source_state_digest: String,
    pub base_prepared_state_id: String,
    pub base_prepared_state_digest: String,
    pub base_row_count: u64,
    pub base_schema_digest: String,
    pub base_column_family_summary: String,
    pub delta_source_state_id: String,
    pub delta_source_state_digest: String,
    pub delta_row_count: u64,
    pub delta_schema_digest: String,
    pub delta_column_family_summary: String,
    pub delta_manifest_digest: String,
    pub changed_byte_range_refs: String,
    pub changed_row_range_refs: String,
    pub changed_segment_refs: String,
    pub delta_artifact_ref: String,
    pub delta_artifact_digest: String,
    pub native_io_certificate_refs: String,
}

/// Evidence for a scoped local differential Vortex preparation overlay.
#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct VortexDifferentialPreparationReport {
    pub schema_version: &'static str,
    pub status: String,
    pub update_mode: VortexDifferentialUpdateMode,
    pub base_source_state_id: String,
    pub base_source_state_digest: String,
    pub base_prepared_state_id: String,
    pub base_prepared_state_digest: String,
    pub base_row_count: u64,
    pub delta_source_state_id: String,
    pub delta_source_state_digest: String,
    pub delta_row_count: u64,
    pub delta_manifest_digest: String,
    pub overlay_manifest_digest: String,
    pub changed_byte_range_refs: String,
    pub changed_row_range_refs: String,
    pub changed_segment_refs: String,
    pub schema_compatibility_status: String,
    pub update_mode_policy: String,
    pub tombstone_policy: String,
    pub delete_policy: String,
    pub update_policy: String,
    pub prepared_state_reuse_status: String,
    pub base_reprepare_performed: bool,
    pub delta_artifact_written: bool,
    pub delta_artifact_ref: String,
    pub delta_artifact_digest: String,
    pub overlay_applied: bool,
    pub replay_verification_status: String,
    pub correctness_digest: String,
    pub materialization_boundary_status: String,
    pub decode_boundary_status: String,
    pub native_io_certificate_status: String,
    pub native_io_certificate_refs: String,
    pub no_standalone_lane_status: String,
    pub claim_gate_status: String,
    pub claim_boundary: String,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

impl VortexDifferentialPreparationReport {
    /// Return stable evidence fields for CLI/API surfaces.
    #[must_use]
    pub fn evidence_fields(&self) -> Vec<(String, String)> {
        let mut fields = Vec::with_capacity(38);
        self.append_identity_evidence_fields(&mut fields);
        self.append_delta_manifest_evidence_fields(&mut fields);
        self.append_policy_evidence_fields(&mut fields);
        self.append_boundary_evidence_fields(&mut fields);
        Self::push_evidence_field(
            &mut fields,
            "vortex_differential_preparation_fallback_attempted",
            self.fallback_attempted.to_string(),
        );
        Self::push_evidence_field(
            &mut fields,
            "vortex_differential_preparation_external_engine_invoked",
            self.external_engine_invoked.to_string(),
        );
        fields
    }

    /// Whether this report admitted and applied the delta overlay.
    #[must_use]
    pub const fn is_admitted(&self) -> bool {
        self.overlay_applied
    }

    fn push_evidence_field(
        fields: &mut Vec<(String, String)>,
        key: &'static str,
        value: impl Into<String>,
    ) {
        fields.push((key.to_string(), value.into()));
    }

    fn append_identity_evidence_fields(&self, fields: &mut Vec<(String, String)>) {
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_schema_version",
            self.schema_version,
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_status",
            self.status.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_update_mode",
            self.update_mode.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_base_source_state_id",
            self.base_source_state_id.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_base_source_state_digest",
            self.base_source_state_digest.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_base_prepared_state_id",
            self.base_prepared_state_id.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_base_prepared_state_digest",
            self.base_prepared_state_digest.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_base_row_count",
            self.base_row_count.to_string(),
        );
    }

    fn append_delta_manifest_evidence_fields(&self, fields: &mut Vec<(String, String)>) {
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_delta_source_state_id",
            self.delta_source_state_id.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_delta_source_state_digest",
            self.delta_source_state_digest.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_delta_row_count",
            self.delta_row_count.to_string(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_delta_manifest_digest",
            self.delta_manifest_digest.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_overlay_manifest_digest",
            self.overlay_manifest_digest.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_changed_byte_range_refs",
            self.changed_byte_range_refs.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_changed_row_range_refs",
            self.changed_row_range_refs.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_changed_segment_refs",
            self.changed_segment_refs.as_str(),
        );
    }

    fn append_policy_evidence_fields(&self, fields: &mut Vec<(String, String)>) {
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_schema_compatibility_status",
            self.schema_compatibility_status.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_update_mode_policy",
            self.update_mode_policy.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_tombstone_policy",
            self.tombstone_policy.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_delete_policy",
            self.delete_policy.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_update_policy",
            self.update_policy.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_prepared_state_reuse_status",
            self.prepared_state_reuse_status.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_base_reprepare_performed",
            self.base_reprepare_performed.to_string(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_delta_artifact_written",
            self.delta_artifact_written.to_string(),
        );
    }

    fn append_boundary_evidence_fields(&self, fields: &mut Vec<(String, String)>) {
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_delta_artifact_ref",
            self.delta_artifact_ref.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_delta_artifact_digest",
            self.delta_artifact_digest.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_overlay_applied",
            self.overlay_applied.to_string(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_replay_verification_status",
            self.replay_verification_status.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_correctness_digest",
            self.correctness_digest.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_materialization_boundary_status",
            self.materialization_boundary_status.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_decode_boundary_status",
            self.decode_boundary_status.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_native_io_certificate_status",
            self.native_io_certificate_status.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_native_io_certificate_refs",
            self.native_io_certificate_refs.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_no_standalone_lane_status",
            self.no_standalone_lane_status.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_claim_gate_status",
            self.claim_gate_status.as_str(),
        );
        Self::push_evidence_field(
            fields,
            "vortex_differential_preparation_claim_boundary",
            self.claim_boundary.as_str(),
        );
    }
}

struct DifferentialPreparationEvaluation {
    status: &'static str,
    schema_compatibility_status: &'static str,
    update_mode_policy: &'static str,
    prepared_state_reuse_status: &'static str,
    replay_verification_status: &'static str,
    native_io_certificate_status: &'static str,
    delta_artifact_written: bool,
    overlay_applied: bool,
}

fn evaluate_differential_preparation_state(
    input: &VortexDifferentialPreparationInput,
) -> DifferentialPreparationEvaluation {
    let base_identity_complete = !input.base_source_state_id.is_empty()
        && !input.base_source_state_digest.is_empty()
        && !input.base_prepared_state_id.is_empty()
        && !input.base_prepared_state_digest.is_empty();
    let schema_compatible = input.base_schema_digest == input.delta_schema_digest
        && input.base_column_family_summary == input.delta_column_family_summary;
    let delta_artifact_written =
        input.delta_row_count > 0 && is_local_artifact_digest(&input.delta_artifact_digest);
    let overlay_applied = base_identity_complete
        && input.update_mode.is_append_only()
        && schema_compatible
        && delta_artifact_written;
    let status = if !base_identity_complete {
        "blocked_missing_base_identity"
    } else if !input.update_mode.is_append_only() {
        "blocked_update_mode_policy"
    } else if !schema_compatible {
        "blocked_schema_mismatch"
    } else if !delta_artifact_written {
        "blocked_empty_delta_manifest"
    } else {
        "admitted_append_only_delta_overlay"
    };

    DifferentialPreparationEvaluation {
        status,
        schema_compatibility_status: if schema_compatible {
            "compatible_source_schema_and_column_families"
        } else {
            "blocked_source_schema_or_column_family_mismatch"
        },
        update_mode_policy: if input.update_mode.is_append_only() {
            "append_only_overlay_admitted_when_fingerprints_match"
        } else {
            "update_delete_upsert_blocked_until_row_identity_and_rewrite_semantics_are_certified"
        },
        prepared_state_reuse_status: if overlay_applied {
            "base_prepared_state_reused_for_delta_overlay"
        } else {
            "blocked_before_prepared_state_reuse"
        },
        replay_verification_status: if overlay_applied {
            "delta_writer_and_reopen_row_count_verified"
        } else {
            "blocked_before_overlay_replay"
        },
        native_io_certificate_status: if overlay_applied {
            "certified_local_vortex_differential_preparation_overlay"
        } else {
            "blocked_before_differential_native_io_certificate"
        },
        delta_artifact_written,
        overlay_applied,
    }
}

fn differential_overlay_manifest_digest(
    input: &VortexDifferentialPreparationInput,
    status: &str,
) -> String {
    fnv64_digest_text(&format!(
        "{}|{}|{}|{}|{}|{}",
        input.base_prepared_state_digest,
        input.delta_manifest_digest,
        input.delta_artifact_digest,
        input.changed_row_range_refs,
        input.changed_segment_refs,
        status
    ))
}

fn differential_correctness_digest(
    input: &VortexDifferentialPreparationInput,
    overlay_manifest_digest: &str,
    replay_verification_status: &str,
) -> String {
    fnv64_digest_text(&format!(
        "{}|{}|{}|{}|{}|{}",
        input.base_source_state_digest,
        input.base_prepared_state_digest,
        input.delta_source_state_digest,
        input.delta_manifest_digest,
        overlay_manifest_digest,
        replay_verification_status
    ))
}

/// Validate and report a scoped local differential Vortex preparation overlay.
#[must_use]
pub fn evaluate_vortex_differential_preparation(
    input: VortexDifferentialPreparationInput,
) -> VortexDifferentialPreparationReport {
    let evaluation = evaluate_differential_preparation_state(&input);
    let overlay_manifest_digest = differential_overlay_manifest_digest(&input, evaluation.status);
    let correctness_digest = differential_correctness_digest(
        &input,
        &overlay_manifest_digest,
        evaluation.replay_verification_status,
    );

    VortexDifferentialPreparationReport {
        schema_version: VORTEX_DIFFERENTIAL_PREPARATION_SCHEMA_VERSION,
        status: evaluation.status.to_string(),
        update_mode: input.update_mode,
        base_source_state_id: input.base_source_state_id,
        base_source_state_digest: input.base_source_state_digest,
        base_prepared_state_id: input.base_prepared_state_id,
        base_prepared_state_digest: input.base_prepared_state_digest,
        base_row_count: input.base_row_count,
        delta_source_state_id: input.delta_source_state_id,
        delta_source_state_digest: input.delta_source_state_digest,
        delta_row_count: input.delta_row_count,
        delta_manifest_digest: input.delta_manifest_digest,
        overlay_manifest_digest,
        changed_byte_range_refs: input.changed_byte_range_refs,
        changed_row_range_refs: input.changed_row_range_refs,
        changed_segment_refs: input.changed_segment_refs,
        schema_compatibility_status: evaluation.schema_compatibility_status.to_string(),
        update_mode_policy: evaluation.update_mode_policy.to_string(),
        tombstone_policy: "tombstones_blocked_for_scoped_append_only_overlay".to_string(),
        delete_policy: "deletes_blocked_for_scoped_append_only_overlay".to_string(),
        update_policy: "updates_blocked_for_scoped_append_only_overlay".to_string(),
        prepared_state_reuse_status: evaluation.prepared_state_reuse_status.to_string(),
        base_reprepare_performed: false,
        delta_artifact_written: evaluation.delta_artifact_written,
        delta_artifact_ref: input.delta_artifact_ref,
        delta_artifact_digest: input.delta_artifact_digest,
        overlay_applied: evaluation.overlay_applied,
        replay_verification_status: evaluation.replay_verification_status.to_string(),
        correctness_digest,
        materialization_boundary_status: "delta_only_artifact_overlay_no_base_reprepare"
            .to_string(),
        decode_boundary_status: "delta_source_uses_existing_vortex_ingest_decode_boundary"
            .to_string(),
        native_io_certificate_status: evaluation.native_io_certificate_status.to_string(),
        native_io_certificate_refs: input.native_io_certificate_refs,
        no_standalone_lane_status:
            "funnelled_through_vortex_ingest_source_state_to_prepared_state_delta_overlay"
                .to_string(),
        claim_gate_status: "not_claim_grade".to_string(),
        claim_boundary: format!(
            "Scoped local differential preparation overlay only: status={}; append-only deltas may overlay an existing VortexPreparedState when source/prepared fingerprints and schemas match; no broad CDC, table transaction, object-store, update/delete/upsert, performance, production, or Spark-replacement claim",
            evaluation.status
        ),
        fallback_attempted: false,
        external_engine_invoked: false,
    }
}

/// Inputs used to expose scout ingress and source triage evidence.
#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct VortexScoutIngressInput {
    pub source_state_id: String,
    pub source_state_digest: String,
    pub source_format: String,
    pub source_path: String,
    pub source_schema_digest: String,
    pub row_count: u64,
    pub source_byte_count: u64,
    pub column_count: usize,
    pub read_plan: String,
    pub metadata_range_refs: String,
    pub sampled_row_range_refs: String,
    pub anomaly_count: u64,
    pub anomaly_families: String,
    pub malformed_row_refs: String,
    pub schema_drift_status: String,
    pub unsupported_shape_status: String,
    pub nullability_status: String,
    pub small_file_pathology_status: String,
    pub quarantine_required: bool,
    pub quarantine_output_plan_status: String,
    pub quarantine_output_ref: String,
    pub quarantine_output_digest: String,
    pub redaction_status: String,
    pub unsupported_diagnostic_code: String,
    pub correctness_policy: String,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

/// Evidence for the scoped local scout ingress and triage pass.
#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct VortexScoutIngressReport {
    pub schema_version: &'static str,
    pub status: String,
    pub route: String,
    pub source_state_id: String,
    pub source_state_digest: String,
    pub source_format: String,
    pub source_path: String,
    pub source_schema_digest_before: String,
    pub source_schema_digest_after: String,
    pub row_count: u64,
    pub source_byte_count: u64,
    pub column_count: usize,
    pub read_plan: String,
    pub metadata_range_refs: String,
    pub sampled_row_range_refs: String,
    pub anomaly_count: u64,
    pub anomaly_families: String,
    pub malformed_row_refs: String,
    pub schema_drift_status: String,
    pub unsupported_shape_status: String,
    pub nullability_status: String,
    pub small_file_pathology_status: String,
    pub quarantine_required: bool,
    pub quarantine_output_plan_status: String,
    pub quarantine_output_ref: String,
    pub quarantine_output_digest: String,
    pub redaction_status: String,
    pub unsupported_diagnostic_code: String,
    pub correctness_policy: String,
    pub no_standalone_lane_status: String,
    pub claim_gate_status: String,
    pub claim_boundary: String,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

impl VortexScoutIngressReport {
    /// Return stable evidence fields for CLI/API surfaces.
    #[must_use]
    #[allow(clippy::too_many_lines)]
    pub fn evidence_fields(&self) -> Vec<(String, String)> {
        let mut fields = Vec::with_capacity(36);
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_schema_version",
            self.schema_version,
        );
        Self::push_field(&mut fields, "vortex_scout_ingress_status", &self.status);
        Self::push_field(&mut fields, "vortex_scout_ingress_route", &self.route);
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_source_state_id",
            &self.source_state_id,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_source_state_digest",
            &self.source_state_digest,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_source_format",
            &self.source_format,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_source_path",
            &self.source_path,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_source_schema_digest_before",
            &self.source_schema_digest_before,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_source_schema_digest_after",
            &self.source_schema_digest_after,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_row_count",
            self.row_count.to_string(),
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_source_byte_count",
            self.source_byte_count.to_string(),
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_column_count",
            self.column_count.to_string(),
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_read_plan",
            &self.read_plan,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_metadata_range_refs",
            &self.metadata_range_refs,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_sampled_row_range_refs",
            &self.sampled_row_range_refs,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_anomaly_count",
            self.anomaly_count.to_string(),
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_anomaly_families",
            &self.anomaly_families,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_malformed_row_refs",
            &self.malformed_row_refs,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_schema_drift_status",
            &self.schema_drift_status,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_unsupported_shape_status",
            &self.unsupported_shape_status,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_nullability_status",
            &self.nullability_status,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_small_file_pathology_status",
            &self.small_file_pathology_status,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_quarantine_required",
            self.quarantine_required.to_string(),
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_quarantine_output_plan_status",
            &self.quarantine_output_plan_status,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_quarantine_output_ref",
            &self.quarantine_output_ref,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_quarantine_output_digest",
            &self.quarantine_output_digest,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_redaction_status",
            &self.redaction_status,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_unsupported_diagnostic_code",
            &self.unsupported_diagnostic_code,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_correctness_policy",
            &self.correctness_policy,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_no_standalone_lane_status",
            &self.no_standalone_lane_status,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_claim_gate_status",
            &self.claim_gate_status,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_claim_boundary",
            &self.claim_boundary,
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_fallback_attempted",
            self.fallback_attempted.to_string(),
        );
        Self::push_field(
            &mut fields,
            "vortex_scout_ingress_external_engine_invoked",
            self.external_engine_invoked.to_string(),
        );
        fields
    }

    fn push_field(fields: &mut Vec<(String, String)>, key: &'static str, value: impl Into<String>) {
        fields.push((key.to_string(), value.into()));
    }
}

/// Evaluate scout ingress and source triage evidence for a local preparation route.
#[must_use]
pub fn evaluate_vortex_scout_ingress(input: VortexScoutIngressInput) -> VortexScoutIngressReport {
    let status = scout_ingress_status(&input);
    VortexScoutIngressReport {
        schema_version: VORTEX_SCOUT_INGRESS_SCHEMA_VERSION,
        status: status.to_string(),
        route: "vortex_ingest_source_state_scout_triage".to_string(),
        source_state_id: input.source_state_id,
        source_state_digest: input.source_state_digest,
        source_format: input.source_format,
        source_path: input.source_path,
        source_schema_digest_before: input.source_schema_digest.clone(),
        source_schema_digest_after: input.source_schema_digest,
        row_count: input.row_count,
        source_byte_count: input.source_byte_count,
        column_count: input.column_count,
        read_plan: input.read_plan,
        metadata_range_refs: input.metadata_range_refs,
        sampled_row_range_refs: input.sampled_row_range_refs,
        anomaly_count: input.anomaly_count,
        anomaly_families: if input.anomaly_families.trim().is_empty() {
            "none".to_string()
        } else {
            input.anomaly_families
        },
        malformed_row_refs: if input.malformed_row_refs.trim().is_empty() {
            "none".to_string()
        } else {
            input.malformed_row_refs
        },
        schema_drift_status: input.schema_drift_status,
        unsupported_shape_status: input.unsupported_shape_status,
        nullability_status: input.nullability_status,
        small_file_pathology_status: input.small_file_pathology_status,
        quarantine_required: input.quarantine_required,
        quarantine_output_plan_status: input.quarantine_output_plan_status,
        quarantine_output_ref: input.quarantine_output_ref,
        quarantine_output_digest: input.quarantine_output_digest,
        redaction_status: input.redaction_status,
        unsupported_diagnostic_code: input.unsupported_diagnostic_code,
        correctness_policy: input.correctness_policy,
        no_standalone_lane_status:
            "funnelled_through_vortex_ingest_source_state_to_vortex_prepared_state".to_string(),
        claim_gate_status: "not_claim_grade".to_string(),
        claim_boundary: "Scoped local scout ingress and triage evidence only: malformed input, schema drift, unsupported shapes, nullability risk, small-file pathology, and quarantine planning are visible before vortex_ingest preparation; no data-quality product, automatic repair, production, broad SQL/DataFrame, performance, object-store, or Spark-replacement claim".to_string(),
        fallback_attempted: input.fallback_attempted,
        external_engine_invoked: input.external_engine_invoked,
    }
}

fn scout_ingress_status(input: &VortexScoutIngressInput) -> &'static str {
    if input.unsupported_diagnostic_code == "vortex_ingest.requires_vortex_write_feature" {
        "blocked_feature_gate"
    } else if input.unsupported_shape_status != "not_detected" {
        "blocked_unsupported_nested_shape"
    } else if input.malformed_row_refs != "none" || input.anomaly_families.contains("malformed") {
        "blocked_malformed_source"
    } else if input.schema_drift_status.starts_with("blocked") {
        "blocked_schema_drift"
    } else if input.quarantine_required {
        "quarantine_planned"
    } else {
        "admitted_scout_ingress_clean"
    }
}

/// Inputs used to expose cold-lane Vortex layout/write advisor evidence.
#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct VortexLayoutWriteAdvisorInput {
    pub source_state_id: String,
    pub source_state_digest: String,
    pub source_format: String,
    pub source_schema_digest: String,
    pub row_count: u64,
    pub source_byte_count: u64,
    pub column_count: usize,
    pub workload_constitution: String,
    pub source_statistics_status: String,
    pub requested_pushdown_requirements: String,
    pub sink_requirements: String,
    pub layout_strategy: String,
    pub chunking_strategy: String,
    pub segmentation_strategy: String,
    pub dictionary_strategy: String,
    pub statistics_policy: String,
    pub writer_provider_kind: String,
    pub writer_provider_surface: String,
    pub writer_admission_policy: String,
    pub writer_parallelism_budget: usize,
    pub writer_compression_candidate_fields: Vec<String>,
    pub write_reopen_verification_depth: String,
    pub materialization_boundary_status: String,
    pub decode_boundary_status: String,
    pub expected_read_tradeoff: String,
    pub expected_write_tradeoff: String,
    pub strategy_admitted: bool,
    pub unsupported_diagnostic_code: String,
    pub correctness_refs: String,
    pub benchmark_refs: String,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

/// Evidence for admitted local-product Vortex layout/write advisor checks.
#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct VortexLayoutWriteAdvisorReport {
    pub schema_version: &'static str,
    pub status: String,
    pub route: String,
    pub source_state_id: String,
    pub source_state_digest: String,
    pub source_format: String,
    pub source_schema_digest: String,
    pub row_count: u64,
    pub source_byte_count: u64,
    pub column_count: usize,
    pub workload_constitution: String,
    pub source_statistics_status: String,
    pub requested_pushdown_requirements: String,
    pub sink_requirements: String,
    pub layout_strategy: String,
    pub chunking_strategy: String,
    pub segmentation_strategy: String,
    pub dictionary_strategy: String,
    pub statistics_policy: String,
    pub writer_provider_kind: String,
    pub writer_provider_version: &'static str,
    pub writer_provider_surface: String,
    pub writer_admission_policy: String,
    pub writer_parallelism_budget: usize,
    pub writer_compression_candidate_fields: Vec<String>,
    pub write_reopen_verification_depth: String,
    pub materialization_boundary_status: String,
    pub decode_boundary_status: String,
    pub expected_read_tradeoff: String,
    pub expected_write_tradeoff: String,
    pub strategy_admitted: bool,
    pub runtime_decision_applied: bool,
    pub selected_strategy: String,
    pub strategy_decision_digest: String,
    pub provider_admitted: bool,
    pub blocker: String,
    pub unsupported_diagnostic_code: String,
    pub correctness_refs: String,
    pub benchmark_refs: String,
    pub no_standalone_lane_status: String,
    pub claim_gate_status: String,
    pub claim_boundary: String,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

#[cfg(feature = "vortex-write")]
#[derive(Debug, Clone, PartialEq, Eq)]
struct VortexWriterPhysicalDesignSourceInput {
    #[cfg(feature = "universal-format-io")]
    cpu_lanes: Option<crate::ingest_cpu_lanes::IngestCpuLanes>,
    source_kind: &'static str,
    source_stage_plan: String,
    derived_metadata_stage_plan: String,
    array_build_input_layout: &'static str,
    source_stream_batch_size: usize,
    source_stream_unit_count_hint: Option<usize>,
    source_stream_unit_hint_kind: String,
    source_stream_policy: String,
    source_ingest_executor_status: String,
    source_ingest_executor_kind: String,
    source_ingest_executor_requested_parallelism: usize,
    source_ingest_executor_applied_parallelism: usize,
    source_ingest_executor_unit_count_hint: Option<usize>,
}

#[cfg(feature = "vortex-write")]
impl VortexWriterPhysicalDesignSourceInput {
    fn scalar(row_count: u64) -> Self {
        let source_unit_count_hint = Some(usize::from(row_count > 0));
        Self {
            #[cfg(feature = "universal-format-io")]
            cpu_lanes: None,
            source_kind: "materialized_scalar_rows",
            source_stage_plan: "validated_flat_scalar_rows_already_materialized".to_string(),
            derived_metadata_stage_plan: "not_requested_for_scalar_row_writer".to_string(),
            array_build_input_layout: "flat_scalar_rows",
            source_stream_batch_size: 0,
            source_stream_unit_count_hint: source_unit_count_hint,
            source_stream_unit_hint_kind: "single_materialized_scalar_row_split".to_string(),
            source_stream_policy: "materialized_scalar_rows_no_stream".to_string(),
            source_ingest_executor_status: "not_applicable_materialized_scalar_rows".to_string(),
            source_ingest_executor_kind: "single_materialized_scalar_row_reader".to_string(),
            source_ingest_executor_requested_parallelism: 1,
            source_ingest_executor_applied_parallelism: 1,
            source_ingest_executor_unit_count_hint: source_unit_count_hint,
        }
    }

    #[cfg(feature = "universal-format-io")]
    fn buffered_columnar(record_batch_count: usize) -> Self {
        Self {
            #[cfg(feature = "universal-format-io")]
            cpu_lanes: None,
            source_kind: "buffered_arrow_record_batch_source_state",
            source_stage_plan: "validated_buffered_arrow_record_batches".to_string(),
            derived_metadata_stage_plan: "completed_before_vortex_writer".to_string(),
            array_build_input_layout: "arrow_record_batch_columnar_source_state",
            source_stream_batch_size: 0,
            source_stream_unit_count_hint: Some(record_batch_count),
            source_stream_unit_hint_kind: "buffered_record_batch_count".to_string(),
            source_stream_policy: "buffered_arrow_record_batches_no_stream_prefetch".to_string(),
            source_ingest_executor_status: "not_applicable_buffered_columnar_source".to_string(),
            source_ingest_executor_kind: "single_buffered_record_batch_reader".to_string(),
            source_ingest_executor_requested_parallelism: 1,
            source_ingest_executor_applied_parallelism: 1,
            source_ingest_executor_unit_count_hint: Some(record_batch_count),
        }
    }

    #[cfg(feature = "universal-format-io")]
    fn streaming_columnar(source: &FlatLocalColumnarStreamSource) -> Result<Self> {
        let source_workers = match source.ingest_executor_status.as_str() {
            "bounded_capillary_prefetch_active" => 1,
            "bounded_capillary_row_group_parallel_active"
            | "bounded_capillary_row_group_parallel_writer_budgeted" => {
                source.ingest_executor_applied_parallelism
            }
            _ => 0,
        };
        let requested = source.ingest_executor_requested_parallelism.max(1);
        let cpu_lanes = if let Some(runtime) = &source.ingest_runtime {
            if runtime.requested_parallelism() != requested || source_workers > 0 {
                return Err(ShardLoomError::InvalidOperation(
                    "ingest CPU lane admission: existing source runtime exceeds or differs from the requested grant; no fallback execution was attempted".to_string(),
                ));
            }
            crate::ingest_cpu_lanes::IngestCpuLanes::shared(requested, runtime.parallelism())?
        } else {
            crate::ingest_cpu_lanes::IngestCpuLanes::with_admitted_source(
                requested,
                source_workers,
            )?
        };
        Ok(Self {
            cpu_lanes: Some(cpu_lanes),
            source_kind: "streaming_arrow_record_batch_source_state",
            source_stage_plan: "bounded_streaming_source_reader_feeds_vortex_array_iterator"
                .to_string(),
            derived_metadata_stage_plan:
                "embedded_derived_metadata_built_during_source_batch_production".to_string(),
            array_build_input_layout: "streaming_arrow_record_batch_columnar_source_state",
            source_stream_batch_size: source.source_stream_batch_size,
            source_stream_unit_count_hint: source.source_stream_unit_count_hint,
            source_stream_unit_hint_kind: source.source_stream_unit_hint_kind.clone(),
            source_stream_policy: source.source_stream_policy.clone(),
            source_ingest_executor_status: source.ingest_executor_status.clone(),
            source_ingest_executor_kind: source.ingest_executor_kind.clone(),
            source_ingest_executor_requested_parallelism: source
                .ingest_executor_requested_parallelism,
            source_ingest_executor_applied_parallelism: source.ingest_executor_applied_parallelism,
            source_ingest_executor_unit_count_hint: source.ingest_executor_unit_count_hint,
        })
    }

    #[cfg(test)]
    fn writer_only() -> Self {
        Self {
            #[cfg(feature = "universal-format-io")]
            cpu_lanes: None,
            source_kind: "writer_only_runtime_decision",
            source_stage_plan: "not_attached_to_source_state".to_string(),
            derived_metadata_stage_plan: "not_attached_to_source_state".to_string(),
            array_build_input_layout: "not_attached_to_source_state",
            source_stream_batch_size: 0,
            source_stream_unit_count_hint: None,
            source_stream_unit_hint_kind: "unknown".to_string(),
            source_stream_policy: "not_attached_to_source_state".to_string(),
            source_ingest_executor_status: "unknown".to_string(),
            source_ingest_executor_kind: "unknown".to_string(),
            source_ingest_executor_requested_parallelism: 1,
            source_ingest_executor_applied_parallelism: 1,
            source_ingest_executor_unit_count_hint: None,
        }
    }
}

/// Writer physical-design plan applied to the native Vortex writer boundary.
#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct VortexWriterPhysicalDesignPlan {
    pub schema_version: &'static str,
    pub status: String,
    pub planner: String,
    pub selected_strategy: String,
    pub strategy_decision_digest: String,
    pub provider_decision: String,
    pub provider_kind: String,
    pub provider_surface: String,
    pub admission_policy: String,
    pub certification_level: String,
    pub source_stage_plan: String,
    pub derived_metadata_stage_plan: String,
    pub array_build_stage_plan: String,
    pub compression_layout_stage_plan: String,
    pub writer_feed_stage_plan: String,
    pub commit_stage_plan: String,
    pub source_format: String,
    pub source_stream_batch_size: usize,
    pub source_stream_unit_count_hint: Option<usize>,
    pub source_stream_unit_hint_kind: String,
    pub source_stream_policy: String,
    pub source_ingest_executor_status: String,
    pub source_ingest_executor_kind: String,
    pub source_ingest_executor_requested_parallelism: usize,
    pub source_ingest_executor_applied_parallelism: usize,
    pub source_ingest_executor_unit_count_hint: Option<usize>,
    pub array_build_prefetch_window: usize,
    pub array_build_worker_count: usize,
    pub array_build_input_layout: String,
    pub writer_row_block_size: usize,
    pub writer_block_target_bytes: u64,
    pub writer_compression_policy: String,
    pub writer_compression_field_names: Vec<String>,
    pub writer_compression_field_decisions: Vec<String>,
    pub writer_compression_concurrency: usize,
    pub writer_stats_concurrency: usize,
    pub writer_runtime_kind: String,
    pub writer_runtime_requested_parallelism: usize,
    pub writer_runtime_applied_parallelism: usize,
    pub writer_runtime_background_workers: usize,
    pub writer_queue_topology: String,
    pub writer_backpressure_policy: String,
    pub writer_profile_selection_reason: String,
    pub writer_profile_regression_guard: String,
    pub retained_ingest_baseline_seconds: u64,
    pub rejected_experimental_patch_seconds: u64,
    pub retention_status: String,
    pub no_fallback_policy: String,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

#[cfg(feature = "vortex-write")]
impl VortexWriterPhysicalDesignPlan {
    fn source_feed_default(
        blocker: &str,
        expected_provider_kind: &str,
        expected_provider_surface: &str,
        certification_level: VortexIngestCertificationLevel,
        source: VortexWriterPhysicalDesignSourceInput,
    ) -> Self {
        let array_build_prefetch_window = planned_array_build_prefetch_window(&source);
        let array_build_worker_count = planned_array_build_worker_count(&source);
        let (writer_runtime_requested_parallelism, writer_runtime_applied_parallelism) =
            planned_writer_runtime_parallelism(&source, 1);
        let writer_runtime_background_workers = writer_runtime_applied_parallelism - 1;
        let writer_runtime_kind =
            planned_writer_runtime_kind(&source, writer_runtime_background_workers);
        let array_build_stage_plan = planned_array_build_stage(
            &source,
            array_build_prefetch_window,
            array_build_worker_count,
        );
        let provider_decision = if expected_provider_kind == "vortex_array_kernel" {
            "use_vortex_native_provider"
        } else {
            "use_shardloom_native_kernel_then_vortex_writer"
        };
        let writer_queue_topology = planned_writer_queue_topology(
            &source,
            array_build_prefetch_window,
            array_build_worker_count,
            writer_runtime_background_workers,
        );
        let writer_backpressure_policy =
            planned_writer_backpressure_policy(&source, array_build_prefetch_window);
        let strategy_decision_digest = fnv64_digest_text(&format!(
            "vortex_writer_physical_design|source_feed_default|{blocker}|{}|{}|{}|{}|{}|{}|{}|{}|{}",
            expected_provider_kind,
            expected_provider_surface,
            certification_level.as_str(),
            source.source_kind,
            source.source_stream_batch_size,
            option_usize_evidence(source.source_stream_unit_count_hint),
            source.source_ingest_executor_requested_parallelism,
            array_build_prefetch_window,
            array_build_worker_count,
        ));
        Self {
            schema_version: VORTEX_WRITER_PHYSICAL_DESIGN_SCHEMA_VERSION,
            status: "source_feed_plan_applied_layout_write_advisor_not_attached".to_string(),
            planner: "shardloom_local_vortex_writer_physical_design".to_string(),
            selected_strategy: "upstream_vortex_default_writer_strategy".to_string(),
            strategy_decision_digest,
            provider_decision: provider_decision.to_string(),
            provider_kind: expected_provider_kind.to_string(),
            provider_surface: expected_provider_surface.to_string(),
            admission_policy: "layout_write_advisor_not_attached".to_string(),
            certification_level: certification_level.as_str().to_string(),
            source_stage_plan: source.source_stage_plan,
            derived_metadata_stage_plan: source.derived_metadata_stage_plan,
            array_build_stage_plan,
            compression_layout_stage_plan: "upstream_vortex_default_compression_layout".to_string(),
            writer_feed_stage_plan:
                "single_ordered_array_stream_into_vortex_session_write_options".to_string(),
            commit_stage_plan:
                "workspace_safe_validated_producer_then_single_vortex_artifact_commit".to_string(),
            source_format: "unknown_without_layout_write_advisor".to_string(),
            source_stream_batch_size: source.source_stream_batch_size,
            source_stream_unit_count_hint: source.source_stream_unit_count_hint,
            source_stream_unit_hint_kind: source.source_stream_unit_hint_kind,
            source_stream_policy: source.source_stream_policy,
            source_ingest_executor_status: source.source_ingest_executor_status,
            source_ingest_executor_kind: source.source_ingest_executor_kind,
            source_ingest_executor_requested_parallelism:
                source.source_ingest_executor_requested_parallelism,
            source_ingest_executor_applied_parallelism: source.source_ingest_executor_applied_parallelism,
            source_ingest_executor_unit_count_hint: source.source_ingest_executor_unit_count_hint,
            array_build_prefetch_window,
            array_build_worker_count,
            array_build_input_layout: source.array_build_input_layout.to_string(),
            writer_row_block_size: VORTEX_PREPARED_OLAP_WRITER_DEFAULT_ROW_BLOCK_SIZE,
            writer_block_target_bytes: 0,
            writer_compression_policy: VORTEX_PREPARED_OLAP_WRITER_DEFAULT_COMPRESSION_POLICY
                .to_string(),
            writer_compression_field_names: Vec::new(),
            writer_compression_field_decisions: Vec::new(),
            writer_compression_concurrency:
                VORTEX_PREPARED_OLAP_WRITER_DEFAULT_COMPRESSION_CONCURRENCY,
            writer_stats_concurrency: VORTEX_PREPARED_OLAP_WRITER_DEFAULT_STATS_CONCURRENCY,
            writer_runtime_kind: writer_runtime_kind.to_string(),
            writer_runtime_requested_parallelism,
            writer_runtime_applied_parallelism,
            writer_runtime_background_workers,
            writer_queue_topology,
            writer_backpressure_policy,
            writer_profile_selection_reason: "upstream_vortex_default_writer_profile".to_string(),
            writer_profile_regression_guard: "not_applicable".to_string(),
            retained_ingest_baseline_seconds: 301,
            rejected_experimental_patch_seconds: 360,
            retention_status:
                "source_feed_overlap_kept_without_layout_profile_tuning".to_string(),
            no_fallback_policy:
                "native_vortex_writer_provider_only_no_spark_datafusion_duckdb_polars_velox_fallback"
                    .to_string(),
            fallback_attempted: false,
            external_engine_invoked: false,
        }
    }

    #[allow(clippy::too_many_arguments, clippy::too_many_lines)]
    fn from_admitted_advisor(
        advisor: &VortexLayoutWriteAdvisorReport,
        target_path: &Path,
        expected_provider_kind: &str,
        expected_provider_surface: &str,
        certification_level: VortexIngestCertificationLevel,
        source: VortexWriterPhysicalDesignSourceInput,
    ) -> Self {
        let writer_row_block_size = admitted_layout_writer_row_block_size(advisor);
        let writer_block_target_bytes = admitted_layout_writer_block_target_bytes(advisor);
        let writer_compression_policy = admitted_layout_writer_compression_policy(advisor);
        let writer_compression_field_names =
            admitted_layout_writer_compression_field_names(advisor, writer_compression_policy);
        let writer_compression_field_decisions = admitted_layout_writer_compression_field_decisions(
            advisor,
            writer_compression_policy,
            &writer_compression_field_names,
        );
        let writer_compression_concurrency =
            admitted_layout_writer_compression_concurrency(advisor);
        let writer_stats_concurrency = admitted_layout_writer_stats_concurrency(advisor);
        let (writer_runtime_requested_parallelism, writer_runtime_applied_parallelism) =
            planned_writer_runtime_parallelism(
                &source,
                admitted_layout_writer_runtime_requested_parallelism(advisor),
            );
        let writer_runtime_background_workers =
            writer_runtime_applied_parallelism.saturating_sub(1);
        let writer_runtime_kind =
            planned_writer_runtime_kind(&source, writer_runtime_background_workers);
        let writer_profile_selection_reason =
            admitted_layout_writer_profile_selection_reason(advisor);
        let writer_profile_regression_guard =
            admitted_layout_writer_profile_regression_guard(advisor);
        let array_build_prefetch_window = planned_array_build_prefetch_window(&source);
        let array_build_worker_count = planned_array_build_worker_count(&source);
        let array_build_stage_plan = planned_array_build_stage(
            &source,
            array_build_prefetch_window,
            array_build_worker_count,
        );
        let compression_layout_stage_plan = planned_compression_layout_stage(
            writer_compression_policy,
            &writer_compression_field_names,
        );
        let writer_queue_topology = planned_writer_queue_topology(
            &source,
            array_build_prefetch_window,
            array_build_worker_count,
            writer_runtime_background_workers,
        );
        let writer_backpressure_policy =
            planned_writer_backpressure_policy(&source, array_build_prefetch_window);
        let provider_decision = if expected_provider_kind == "vortex_array_kernel" {
            "use_vortex_native_provider"
        } else {
            "use_shardloom_native_kernel_then_vortex_writer"
        };
        let selected_strategy = advisor.layout_strategy.clone();
        let strategy_decision_digest = fnv64_digest_text(&format!(
            "vortex_writer_physical_design|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}",
            advisor.schema_version,
            advisor.source_state_digest,
            advisor.source_schema_digest,
            selected_strategy,
            expected_provider_kind,
            expected_provider_surface,
            advisor.writer_admission_policy,
            certification_level.as_str(),
            source.source_kind,
            source.source_stream_batch_size,
            option_usize_evidence(source.source_stream_unit_count_hint),
            source.source_ingest_executor_requested_parallelism,
            source.source_ingest_executor_applied_parallelism,
            array_build_prefetch_window,
            array_build_worker_count,
            writer_row_block_size,
            writer_block_target_bytes,
            writer_compression_policy,
            writer_compression_field_names.join(","),
            writer_compression_field_decisions.join("|"),
            writer_compression_concurrency,
            writer_stats_concurrency,
            writer_runtime_requested_parallelism,
            writer_runtime_applied_parallelism,
            writer_runtime_background_workers,
            writer_profile_selection_reason,
            target_path.display()
        ));
        Self {
            schema_version: VORTEX_WRITER_PHYSICAL_DESIGN_SCHEMA_VERSION,
            status: "applied".to_string(),
            planner: "shardloom_local_vortex_writer_physical_design".to_string(),
            selected_strategy,
            strategy_decision_digest,
            provider_decision: provider_decision.to_string(),
            provider_kind: expected_provider_kind.to_string(),
            provider_surface: expected_provider_surface.to_string(),
            admission_policy: advisor.writer_admission_policy.clone(),
            certification_level: certification_level.as_str().to_string(),
            source_stage_plan: source.source_stage_plan,
            derived_metadata_stage_plan: source.derived_metadata_stage_plan,
            array_build_stage_plan,
            compression_layout_stage_plan,
            writer_feed_stage_plan:
                "single_ordered_array_stream_into_vortex_session_write_options".to_string(),
            commit_stage_plan:
                "workspace_safe_validated_producer_then_single_vortex_artifact_commit".to_string(),
            source_format: advisor.source_format.clone(),
            source_stream_batch_size: source.source_stream_batch_size,
            source_stream_unit_count_hint: source.source_stream_unit_count_hint,
            source_stream_unit_hint_kind: source.source_stream_unit_hint_kind,
            source_stream_policy: source.source_stream_policy,
            source_ingest_executor_status: source.source_ingest_executor_status,
            source_ingest_executor_kind: source.source_ingest_executor_kind,
            source_ingest_executor_requested_parallelism:
                source.source_ingest_executor_requested_parallelism,
            source_ingest_executor_applied_parallelism: source.source_ingest_executor_applied_parallelism,
            source_ingest_executor_unit_count_hint: source.source_ingest_executor_unit_count_hint,
            array_build_prefetch_window,
            array_build_worker_count,
            array_build_input_layout: source.array_build_input_layout.to_string(),
            writer_row_block_size,
            writer_block_target_bytes,
            writer_compression_policy: writer_compression_policy.to_string(),
            writer_compression_field_names,
            writer_compression_field_decisions,
            writer_compression_concurrency,
            writer_stats_concurrency,
            writer_runtime_kind: writer_runtime_kind.to_string(),
            writer_runtime_requested_parallelism,
            writer_runtime_applied_parallelism,
            writer_runtime_background_workers,
            writer_queue_topology,
            writer_backpressure_policy,
            writer_profile_selection_reason: writer_profile_selection_reason.to_string(),
            writer_profile_regression_guard: writer_profile_regression_guard.to_string(),
            retained_ingest_baseline_seconds: 301,
            rejected_experimental_patch_seconds: 360,
            retention_status:
                "restored_pre_experiment_defaults_pending_replacement_ingest_uat".to_string(),
            no_fallback_policy:
                "native_vortex_writer_provider_only_no_spark_datafusion_duckdb_polars_velox_fallback"
                    .to_string(),
            fallback_attempted: false,
            external_engine_invoked: false,
        }
    }
}

impl VortexWriterPhysicalDesignPlan {
    #[must_use]
    pub fn compression_field_names(&self) -> String {
        if self.writer_compression_field_names.is_empty() {
            "none".to_string()
        } else {
            self.writer_compression_field_names.join(",")
        }
    }

    #[must_use]
    pub fn compression_decisions(&self) -> String {
        if self.writer_compression_field_decisions.is_empty() {
            "none".to_string()
        } else {
            self.writer_compression_field_decisions.join("|")
        }
    }

    /// Return stable evidence fields for CLI/API surfaces.
    #[must_use]
    #[allow(clippy::too_many_lines)]
    pub fn evidence_fields(&self) -> Vec<(String, String)> {
        vec![
            (
                "vortex_writer_physical_design_schema_version".to_string(),
                self.schema_version.to_string(),
            ),
            (
                "vortex_writer_physical_design_status".to_string(),
                self.status.clone(),
            ),
            (
                "vortex_writer_physical_design_planner".to_string(),
                self.planner.clone(),
            ),
            (
                "vortex_writer_physical_design_selected_strategy".to_string(),
                self.selected_strategy.clone(),
            ),
            (
                "vortex_writer_physical_design_decision_digest".to_string(),
                self.strategy_decision_digest.clone(),
            ),
            (
                "vortex_writer_physical_design_provider_decision".to_string(),
                self.provider_decision.clone(),
            ),
            (
                "vortex_writer_physical_design_provider_kind".to_string(),
                self.provider_kind.clone(),
            ),
            (
                "vortex_writer_physical_design_provider_surface".to_string(),
                self.provider_surface.clone(),
            ),
            (
                "vortex_writer_physical_design_admission_policy".to_string(),
                self.admission_policy.clone(),
            ),
            (
                "vortex_writer_physical_design_certification_level".to_string(),
                self.certification_level.clone(),
            ),
            (
                "vortex_writer_physical_design_source_stage_plan".to_string(),
                self.source_stage_plan.clone(),
            ),
            (
                "vortex_writer_physical_design_derived_metadata_stage_plan".to_string(),
                self.derived_metadata_stage_plan.clone(),
            ),
            (
                "vortex_writer_physical_design_array_build_stage_plan".to_string(),
                self.array_build_stage_plan.clone(),
            ),
            (
                "vortex_writer_physical_design_compression_layout_stage_plan".to_string(),
                self.compression_layout_stage_plan.clone(),
            ),
            (
                "vortex_writer_physical_design_writer_feed_stage_plan".to_string(),
                self.writer_feed_stage_plan.clone(),
            ),
            (
                "vortex_writer_physical_design_commit_stage_plan".to_string(),
                self.commit_stage_plan.clone(),
            ),
            (
                "vortex_writer_physical_design_source_format".to_string(),
                self.source_format.clone(),
            ),
            (
                "vortex_writer_physical_design_source_stream_batch_size".to_string(),
                self.source_stream_batch_size.to_string(),
            ),
            (
                "vortex_writer_physical_design_source_stream_unit_count_hint".to_string(),
                option_usize_evidence(self.source_stream_unit_count_hint),
            ),
            (
                "vortex_writer_physical_design_source_stream_unit_hint_kind".to_string(),
                self.source_stream_unit_hint_kind.clone(),
            ),
            (
                "vortex_writer_physical_design_source_stream_policy".to_string(),
                self.source_stream_policy.clone(),
            ),
            (
                "vortex_writer_physical_design_source_executor_status".to_string(),
                self.source_ingest_executor_status.clone(),
            ),
            (
                "vortex_writer_physical_design_source_executor_kind".to_string(),
                self.source_ingest_executor_kind.clone(),
            ),
            (
                "vortex_writer_physical_design_source_executor_requested_parallelism".to_string(),
                self.source_ingest_executor_requested_parallelism
                    .to_string(),
            ),
            (
                "vortex_writer_physical_design_source_executor_applied_parallelism".to_string(),
                self.source_ingest_executor_applied_parallelism.to_string(),
            ),
            (
                "vortex_writer_physical_design_source_executor_unit_count_hint".to_string(),
                option_usize_evidence(self.source_ingest_executor_unit_count_hint),
            ),
            (
                "vortex_writer_physical_design_array_build_prefetch_window".to_string(),
                self.array_build_prefetch_window.to_string(),
            ),
            (
                "vortex_writer_physical_design_array_build_worker_count".to_string(),
                self.array_build_worker_count.to_string(),
            ),
            (
                "vortex_writer_physical_design_array_build_input_layout".to_string(),
                self.array_build_input_layout.clone(),
            ),
            (
                "vortex_writer_physical_design_writer_row_block_size".to_string(),
                self.writer_row_block_size.to_string(),
            ),
            (
                "vortex_writer_physical_design_writer_block_target_bytes".to_string(),
                self.writer_block_target_bytes.to_string(),
            ),
            (
                "vortex_writer_physical_design_writer_compression_policy".to_string(),
                self.writer_compression_policy.clone(),
            ),
            (
                "vortex_writer_physical_design_writer_compression_field_count".to_string(),
                self.writer_compression_field_names.len().to_string(),
            ),
            (
                "vortex_writer_physical_design_writer_compression_field_names".to_string(),
                self.compression_field_names(),
            ),
            (
                "vortex_writer_physical_design_writer_compression_decision_count".to_string(),
                self.writer_compression_field_decisions.len().to_string(),
            ),
            (
                "vortex_writer_physical_design_writer_compression_decisions".to_string(),
                self.compression_decisions(),
            ),
            (
                "vortex_writer_physical_design_writer_compression_concurrency".to_string(),
                self.writer_compression_concurrency.to_string(),
            ),
            (
                "vortex_writer_physical_design_writer_stats_concurrency".to_string(),
                self.writer_stats_concurrency.to_string(),
            ),
            (
                "vortex_writer_physical_design_writer_runtime_kind".to_string(),
                self.writer_runtime_kind.clone(),
            ),
            (
                "vortex_writer_physical_design_writer_runtime_requested_parallelism".to_string(),
                self.writer_runtime_requested_parallelism.to_string(),
            ),
            (
                "vortex_writer_physical_design_writer_runtime_applied_parallelism".to_string(),
                self.writer_runtime_applied_parallelism.to_string(),
            ),
            (
                "vortex_writer_physical_design_writer_runtime_background_workers".to_string(),
                self.writer_runtime_background_workers.to_string(),
            ),
            (
                "vortex_writer_physical_design_writer_queue_topology".to_string(),
                self.writer_queue_topology.clone(),
            ),
            (
                "vortex_writer_physical_design_writer_backpressure_policy".to_string(),
                self.writer_backpressure_policy.clone(),
            ),
            (
                "vortex_writer_physical_design_writer_profile_selection_reason".to_string(),
                self.writer_profile_selection_reason.clone(),
            ),
            (
                "vortex_writer_physical_design_writer_profile_regression_guard".to_string(),
                self.writer_profile_regression_guard.clone(),
            ),
            (
                "vortex_writer_physical_design_retained_ingest_baseline_seconds".to_string(),
                self.retained_ingest_baseline_seconds.to_string(),
            ),
            (
                "vortex_writer_physical_design_rejected_experimental_patch_seconds".to_string(),
                self.rejected_experimental_patch_seconds.to_string(),
            ),
            (
                "vortex_writer_physical_design_retention_status".to_string(),
                self.retention_status.clone(),
            ),
            (
                "vortex_writer_physical_design_no_fallback_policy".to_string(),
                self.no_fallback_policy.clone(),
            ),
            (
                "vortex_writer_physical_design_fallback_attempted".to_string(),
                self.fallback_attempted.to_string(),
            ),
            (
                "vortex_writer_physical_design_external_engine_invoked".to_string(),
                self.external_engine_invoked.to_string(),
            ),
        ]
    }
}

/// Runtime decision returned by the local Vortex writer after it validates an
/// admitted layout/write advisor strategy and applies it to the writer path.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VortexLayoutWriteRuntimeDecision {
    pub runtime_decision_applied: bool,
    pub selected_strategy: String,
    pub strategy_decision_digest: String,
    pub provider_admitted: bool,
    pub writer_row_block_size: usize,
    pub writer_block_target_bytes: u64,
    pub writer_compression_policy: String,
    pub writer_compression_field_names: Vec<String>,
    pub writer_compression_field_decisions: Vec<String>,
    pub writer_compression_concurrency: usize,
    pub writer_stats_concurrency: usize,
    pub writer_runtime_requested_parallelism: usize,
    pub writer_runtime_applied_parallelism: usize,
    pub writer_runtime_background_workers: usize,
    pub writer_profile_selection_reason: String,
    pub writer_profile_regression_guard: String,
    pub writer_physical_design: VortexWriterPhysicalDesignPlan,
    pub blocker: String,
}

#[cfg(feature = "vortex-write")]
impl VortexLayoutWriteRuntimeDecision {
    fn not_requested_for_source(
        expected_provider_kind: &str,
        expected_provider_surface: &str,
        certification_level: VortexIngestCertificationLevel,
        source: VortexWriterPhysicalDesignSourceInput,
    ) -> Self {
        let blocker = "layout_write_advisor_not_attached_to_writer".to_string();
        let writer_physical_design = VortexWriterPhysicalDesignPlan::source_feed_default(
            &blocker,
            expected_provider_kind,
            expected_provider_surface,
            certification_level,
            source,
        );
        Self {
            runtime_decision_applied: false,
            selected_strategy: "not_requested".to_string(),
            strategy_decision_digest: writer_physical_design.strategy_decision_digest.clone(),
            provider_admitted: false,
            writer_row_block_size: VORTEX_PREPARED_OLAP_WRITER_DEFAULT_ROW_BLOCK_SIZE,
            writer_block_target_bytes: 0,
            writer_compression_policy: VORTEX_PREPARED_OLAP_WRITER_DEFAULT_COMPRESSION_POLICY
                .to_string(),
            writer_compression_field_names: Vec::new(),
            writer_compression_field_decisions: Vec::new(),
            writer_compression_concurrency:
                VORTEX_PREPARED_OLAP_WRITER_DEFAULT_COMPRESSION_CONCURRENCY,
            writer_stats_concurrency: VORTEX_PREPARED_OLAP_WRITER_DEFAULT_STATS_CONCURRENCY,
            writer_runtime_requested_parallelism: writer_physical_design
                .writer_runtime_requested_parallelism,
            writer_runtime_applied_parallelism: writer_physical_design
                .writer_runtime_applied_parallelism,
            writer_runtime_background_workers: writer_physical_design
                .writer_runtime_background_workers,
            writer_profile_selection_reason: "not_requested".to_string(),
            writer_profile_regression_guard: "not_applicable".to_string(),
            writer_physical_design,
            blocker,
        }
    }

    #[cfg(test)]
    fn applied(
        advisor: &VortexLayoutWriteAdvisorReport,
        target_path: &Path,
        expected_provider_kind: &str,
        expected_provider_surface: &str,
        certification_level: VortexIngestCertificationLevel,
    ) -> Self {
        Self::applied_for_source(
            advisor,
            target_path,
            expected_provider_kind,
            expected_provider_surface,
            certification_level,
            VortexWriterPhysicalDesignSourceInput::writer_only(),
        )
    }

    fn applied_for_source(
        advisor: &VortexLayoutWriteAdvisorReport,
        target_path: &Path,
        expected_provider_kind: &str,
        expected_provider_surface: &str,
        certification_level: VortexIngestCertificationLevel,
        source: VortexWriterPhysicalDesignSourceInput,
    ) -> Self {
        let writer_physical_design = VortexWriterPhysicalDesignPlan::from_admitted_advisor(
            advisor,
            target_path,
            expected_provider_kind,
            expected_provider_surface,
            certification_level,
            source,
        );
        Self {
            runtime_decision_applied: true,
            selected_strategy: writer_physical_design.selected_strategy.clone(),
            strategy_decision_digest: writer_physical_design.strategy_decision_digest.clone(),
            provider_admitted: true,
            writer_row_block_size: writer_physical_design.writer_row_block_size,
            writer_block_target_bytes: writer_physical_design.writer_block_target_bytes,
            writer_compression_policy: writer_physical_design.writer_compression_policy.clone(),
            writer_compression_field_names: writer_physical_design
                .writer_compression_field_names
                .clone(),
            writer_compression_field_decisions: writer_physical_design
                .writer_compression_field_decisions
                .clone(),
            writer_compression_concurrency: writer_physical_design.writer_compression_concurrency,
            writer_stats_concurrency: writer_physical_design.writer_stats_concurrency,
            writer_runtime_requested_parallelism: writer_physical_design
                .writer_runtime_requested_parallelism,
            writer_runtime_applied_parallelism: writer_physical_design
                .writer_runtime_applied_parallelism,
            writer_runtime_background_workers: writer_physical_design
                .writer_runtime_background_workers,
            writer_profile_selection_reason: writer_physical_design
                .writer_profile_selection_reason
                .clone(),
            writer_profile_regression_guard: writer_physical_design
                .writer_profile_regression_guard
                .clone(),
            writer_physical_design,
            blocker: "none".to_string(),
        }
    }
}

fn option_usize_evidence(value: Option<usize>) -> String {
    value.map_or_else(|| "unknown".to_string(), |value| value.to_string())
}

#[cfg(feature = "vortex-write")]
fn planned_array_build_prefetch_window(source: &VortexWriterPhysicalDesignSourceInput) -> usize {
    #[cfg(feature = "universal-format-io")]
    {
        return source
            .cpu_lanes
            .map_or(0, crate::ingest_cpu_lanes::IngestCpuLanes::prefetch_slots);
    }
    #[allow(unreachable_code)]
    {
        let _ = source;
        0
    }
}

#[cfg(feature = "vortex-write")]
fn planned_array_build_worker_count(source: &VortexWriterPhysicalDesignSourceInput) -> usize {
    #[cfg(feature = "universal-format-io")]
    {
        return source.cpu_lanes.map_or(
            0,
            crate::ingest_cpu_lanes::IngestCpuLanes::conversion_task_limit,
        );
    }
    #[allow(unreachable_code)]
    {
        let _ = source;
        0
    }
}

#[cfg(feature = "vortex-write")]
fn planned_writer_runtime_parallelism(
    source: &VortexWriterPhysicalDesignSourceInput,
    requested: usize,
) -> (usize, usize) {
    #[cfg(feature = "universal-format-io")]
    if let Some(lanes) = source.cpu_lanes {
        return (lanes.requested(), 1 + lanes.provider_drivers());
    }
    let _ = source;
    (
        requested.max(1),
        shardloom_exec::compute_pool::bounded_cpu_parallelism(requested),
    )
}

#[cfg(feature = "vortex-write")]
fn writer_runtime_kind(background_workers: usize) -> &'static str {
    if background_workers > 0 {
        "vortex_current_thread_worker_pool"
    } else {
        "vortex_current_thread_runtime"
    }
}

#[cfg(feature = "vortex-write")]
fn planned_writer_runtime_kind(
    source: &VortexWriterPhysicalDesignSourceInput,
    background_workers: usize,
) -> &'static str {
    #[cfg(feature = "universal-format-io")]
    if source
        .cpu_lanes
        .is_some_and(crate::ingest_cpu_lanes::IngestCpuLanes::shares_runtime)
    {
        return "vortex_shared_ingest_runtime";
    }
    let _ = source;
    writer_runtime_kind(background_workers)
}

#[cfg(feature = "vortex-write")]
fn planned_array_build_stage(
    source: &VortexWriterPhysicalDesignSourceInput,
    prefetch_window: usize,
    worker_count: usize,
) -> String {
    match (source.source_kind, prefetch_window, worker_count) {
        ("streaming_arrow_record_batch_source_state", 1.., 2..) => {
            format!("ordered_morsel_array_build_prefetch_workers={worker_count}_before_writer_pull")
        }
        ("streaming_arrow_record_batch_source_state", 1.., _) => {
            "prefetch_streaming_arrow_record_batches_as_vortex_arrays_before_writer_pull"
                .to_string()
        }
        ("streaming_arrow_record_batch_source_state", _, _) => {
            "serial_streaming_arrow_record_batch_to_vortex_array_conversion".to_string()
        }
        ("buffered_arrow_record_batch_source_state", _, _) => {
            "single_buffered_arrow_record_batch_to_vortex_array_build".to_string()
        }
        ("materialized_scalar_rows", _, _) => {
            "single_scalar_row_batch_to_vortex_struct_build".to_string()
        }
        _ => "writer_only_array_build_not_attached_to_source_state".to_string(),
    }
}

#[cfg(feature = "vortex-write")]
fn planned_compression_layout_stage(
    writer_compression_policy: &str,
    writer_compression_field_names: &[String],
) -> String {
    if writer_compression_policy
        == VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_LARGE_SOURCE_COMPRESSION_POLICY
        && !writer_compression_field_names.is_empty()
    {
        format!(
            "field_level_fast_zstd_text_leaf_writers;field_count={};frame_values={};other_primitive_data=numeric_btrblocks",
            writer_compression_field_names.len(),
            VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_ZSTD_VALUES_PER_FRAME
        )
    } else if writer_compression_policy
        == VORTEX_PREPARED_OLAP_WRITER_FAST_LOAD_LARGE_SOURCE_COMPRESSION_POLICY
    {
        "fast_load_numeric_btrblocks_layout_statistics".to_string()
    } else {
        "upstream_vortex_default_compression_layout".to_string()
    }
}

#[cfg(feature = "vortex-write")]
fn planned_writer_queue_topology(
    source: &VortexWriterPhysicalDesignSourceInput,
    prefetch_window: usize,
    array_build_worker_count: usize,
    writer_background_workers: usize,
) -> String {
    let topology = format!(
        "source_executor_applied_parallelism={};array_prefetch_window={};array_build_workers={};writer_background_workers={};delivery=ordered_array_stream",
        source.source_ingest_executor_applied_parallelism,
        prefetch_window,
        array_build_worker_count,
        writer_background_workers
    );
    #[cfg(feature = "universal-format-io")]
    if let Some(lanes) = source.cpu_lanes {
        if lanes.shares_runtime() {
            return format!(
                "{topology};ingest_cpu_requested={};ingest_cpu_configured={};ingest_cpu_caller=1;ingest_cpu_source_drivers=0;ingest_cpu_conversion_drivers=0;ingest_cpu_provider_drivers={};ingest_cpu_scope=shardloom_owned_drivers_excludes_blocking_io_and_source_library_internal_threads;driver_lifetime=joined_before_artifact_call_returns;lane_reassignment=ready_source_conversion_and_provider_tasks_share_executor;array_build_workers_scope=concurrent_tasks_not_dedicated_threads",
                lanes.requested(),
                lanes.configured_cpu_lanes(),
                lanes.provider_drivers(),
            );
        }
        return format!(
            "{topology};ingest_cpu_requested={};ingest_cpu_configured={};ingest_cpu_caller=1;ingest_cpu_source_drivers={};ingest_cpu_conversion_drivers={};ingest_cpu_provider_drivers={};ingest_cpu_scope=shardloom_owned_drivers_excludes_blocking_io_and_source_library_internal_threads;driver_lifetime=joined_before_artifact_call_returns;lane_reassignment=none",
            lanes.requested(),
            lanes.configured_cpu_lanes(),
            lanes.source_workers(),
            lanes.conversion_workers(),
            lanes.provider_drivers()
        );
    }
    topology
}

#[cfg(feature = "vortex-write")]
fn planned_writer_backpressure_policy(
    source: &VortexWriterPhysicalDesignSourceInput,
    prefetch_window: usize,
) -> String {
    if source.source_kind == "streaming_arrow_record_batch_source_state" && prefetch_window > 0 {
        "reserved_inflight_window_bounds_queued_active_and_ordered_results".to_string()
    } else if source.source_kind == "streaming_arrow_record_batch_source_state" {
        "writer_pull_backpressures_source_reader_serially".to_string()
    } else {
        "no_stream_backpressure_materialized_before_writer".to_string()
    }
}

#[cfg(feature = "vortex-write")]
fn admitted_layout_writer_row_block_size(advisor: &VortexLayoutWriteAdvisorReport) -> usize {
    if advisor.row_count >= VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_THRESHOLD {
        VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_BLOCK_SIZE
    } else {
        VORTEX_PREPARED_OLAP_WRITER_FINE_ROW_BLOCK_SIZE
    }
}

#[cfg(feature = "vortex-write")]
fn admitted_layout_writer_block_target_bytes(advisor: &VortexLayoutWriteAdvisorReport) -> u64 {
    if advisor.row_count < VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_THRESHOLD {
        return VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_BLOCK_TARGET_BYTES;
    }
    if !layout_advisor_has_text_writer_profile(advisor)
        || !admitted_layout_writer_has_storage_compression_fields(advisor)
    {
        return VORTEX_PREPARED_OLAP_WRITER_FAST_LOAD_BLOCK_TARGET_BYTES;
    }
    if advisor.source_byte_count >= VORTEX_PREPARED_OLAP_WRITER_LARGE_TEXT_COALESCED_SOURCE_BYTES
        && layout_advisor_has_high_cardinality_profile(advisor)
    {
        VORTEX_PREPARED_OLAP_WRITER_LARGE_TEXT_COALESCED_BLOCK_TARGET_BYTES
    } else {
        VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_BLOCK_TARGET_BYTES
    }
}

#[cfg(feature = "vortex-write")]
fn admitted_layout_writer_compression_policy(
    advisor: &VortexLayoutWriteAdvisorReport,
) -> &'static str {
    if advisor.row_count >= VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_THRESHOLD {
        if layout_advisor_has_text_writer_profile(advisor)
            && admitted_layout_writer_has_storage_compression_fields(advisor)
        {
            VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_LARGE_SOURCE_COMPRESSION_POLICY
        } else {
            VORTEX_PREPARED_OLAP_WRITER_FAST_LOAD_LARGE_SOURCE_COMPRESSION_POLICY
        }
    } else {
        VORTEX_PREPARED_OLAP_WRITER_DEFAULT_COMPRESSION_POLICY
    }
}

#[cfg(feature = "vortex-write")]
fn admitted_layout_writer_compression_field_names(
    advisor: &VortexLayoutWriteAdvisorReport,
    writer_compression_policy: &str,
) -> Vec<String> {
    if writer_compression_policy
        != VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_LARGE_SOURCE_COMPRESSION_POLICY
    {
        return Vec::new();
    }
    advisor
        .writer_compression_candidate_fields
        .iter()
        .filter(|field| !field.trim().is_empty())
        .filter(|field| admitted_layout_writer_storage_compression_field(field))
        .cloned()
        .collect::<BTreeSet<_>>()
        .into_iter()
        .collect()
}

#[cfg(feature = "vortex-write")]
fn admitted_layout_writer_compression_field_decisions(
    advisor: &VortexLayoutWriteAdvisorReport,
    writer_compression_policy: &str,
    selected_fields: &[String],
) -> Vec<String> {
    let selected_fields = selected_fields.iter().cloned().collect::<BTreeSet<_>>();
    advisor
        .writer_compression_candidate_fields
        .iter()
        .filter(|field| !field.trim().is_empty())
        .cloned()
        .collect::<BTreeSet<_>>()
        .into_iter()
        .map(|field| {
            admitted_layout_writer_compression_field_decision(
                &field,
                writer_compression_policy,
                selected_fields.contains(&field),
            )
        })
        .collect::<Vec<_>>()
}

#[cfg(feature = "vortex-write")]
fn admitted_layout_writer_compression_field_decision(
    field: &str,
    writer_compression_policy: &str,
    selected: bool,
) -> String {
    let field_is_shardloom_derived = field.starts_with("__shardloom_derived_");
    let field_is_query_hot_domain = admitted_layout_writer_query_hot_domain_field(field);
    let field = compact_field_evidence_token(field);
    if field_is_shardloom_derived {
        return format!(
            "field={field};decision=skip;codec=none;level=none;reason=generated_derived_metadata;expected_byte_benefit=low;expected_cpu_cost=avoided;dictionary_posture=prefer_compact_dictionary_code_metadata;retain_drop_guard=never_compress_materialized_hidden_derivative"
        );
    }
    if writer_compression_policy
        != VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_LARGE_SOURCE_COMPRESSION_POLICY
    {
        return format!(
            "field={field};decision=skip;codec=none;level=none;reason={};expected_byte_benefit=policy_disabled;expected_cpu_cost=avoided;dictionary_posture=preserve_existing_encoding;retain_drop_guard=fast_load_or_default_policy",
            compact_metadata_token(writer_compression_policy)
        );
    }
    if selected {
        let reason = if field_is_query_hot_domain {
            "large_source_artifact_size_guard_query_hot_text"
        } else {
            "payload_text_storage_benefit"
        };
        return format!(
            "field={field};decision=compress;codec=zstd;level={VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_ZSTD_FAST_LEVEL};reason={reason};expected_byte_benefit=medium_to_high;expected_cpu_cost=high;dictionary_posture=preserve_source_dictionary_when_provider_exposes_it;retain_drop_guard=drop_or_revise_if_uat_lacks_artifact_or_query_benefit;frame_values={VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_ZSTD_VALUES_PER_FRAME}"
        );
    }
    if field_is_query_hot_domain {
        return format!(
            "field={field};decision=skip;codec=none;level=none;reason=query_hot_encoded_domain_preserved;expected_byte_benefit=unknown;expected_cpu_cost=avoided;dictionary_posture=preserve_dictionary_codes_for_predicates_grouping_and_topk;retain_drop_guard=drop_compression_if_uat_query_lanes_regress"
        );
    }
    format!(
        "field={field};decision=skip;codec=none;level=none;reason=field_level_profile_did_not_prove_compression_benefit;expected_byte_benefit=unknown;expected_cpu_cost=avoided;dictionary_posture=preserve_existing_encoding;retain_drop_guard=skip_until_field_level_evidence_supports_compression"
    )
}

#[cfg(feature = "vortex-write")]
fn admitted_layout_writer_compression_concurrency(
    advisor: &VortexLayoutWriteAdvisorReport,
) -> usize {
    if advisor.row_count >= VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_THRESHOLD
        && layout_advisor_has_text_writer_profile(advisor)
        && admitted_layout_writer_has_storage_compression_fields(advisor)
    {
        shardloom_exec::compute_pool::bounded_cpu_parallelism(advisor.writer_parallelism_budget)
    } else if advisor.row_count >= VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_THRESHOLD {
        VORTEX_PREPARED_OLAP_WRITER_FAST_LOAD_LARGE_SOURCE_COMPRESSION_CONCURRENCY
    } else {
        VORTEX_PREPARED_OLAP_WRITER_DEFAULT_COMPRESSION_CONCURRENCY
    }
}

#[cfg(feature = "vortex-write")]
fn admitted_layout_writer_stats_concurrency(advisor: &VortexLayoutWriteAdvisorReport) -> usize {
    if advisor.row_count >= VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_THRESHOLD {
        shardloom_exec::compute_pool::bounded_cpu_parallelism(advisor.writer_parallelism_budget)
    } else {
        VORTEX_PREPARED_OLAP_WRITER_DEFAULT_STATS_CONCURRENCY
    }
}

#[cfg(feature = "vortex-write")]
fn admitted_layout_writer_runtime_requested_parallelism(
    advisor: &VortexLayoutWriteAdvisorReport,
) -> usize {
    if advisor.row_count >= VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_THRESHOLD {
        advisor.writer_parallelism_budget.max(1)
    } else {
        1
    }
}

#[cfg(feature = "vortex-write")]
fn admitted_layout_writer_profile_selection_reason(
    advisor: &VortexLayoutWriteAdvisorReport,
) -> &'static str {
    if advisor.row_count < VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_THRESHOLD {
        "small_source_fine_row_blocks_default_writer_profile"
    } else if !layout_advisor_has_text_writer_profile(advisor) {
        "large_non_text_source_fast_load_numeric_btrblocks_layout_statistics"
    } else if !admitted_layout_writer_has_storage_compression_fields(advisor) {
        "large_text_source_fast_load_encoded_domain_preserved"
    } else if advisor.source_byte_count
        >= VORTEX_PREPARED_OLAP_WRITER_LARGE_TEXT_COALESCED_SOURCE_BYTES
        && layout_advisor_has_high_cardinality_profile(advisor)
    {
        "large_text_high_cardinality_source_coalesced_fast_zstd_profile"
    } else {
        "large_text_source_fast_zstd_profile"
    }
}

#[cfg(feature = "vortex-write")]
fn admitted_layout_writer_profile_regression_guard(
    advisor: &VortexLayoutWriteAdvisorReport,
) -> &'static str {
    if advisor.row_count < VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_THRESHOLD {
        "small_source_default_profile_preserves_fixture_latency"
    } else if !layout_advisor_has_text_writer_profile(advisor) {
        "non_text_large_source_numeric_btrblocks_requires_lifecycle_acceptance"
    } else if !admitted_layout_writer_has_storage_compression_fields(advisor) {
        "query_hot_text_domain_compression_disabled_until_uat_proves_benefit"
    } else {
        "text_zstd_policy_prior_uat_backed_numeric_btrblocks_requires_lifecycle_acceptance"
    }
}

#[cfg(feature = "vortex-write")]
fn layout_advisor_has_text_writer_profile(advisor: &VortexLayoutWriteAdvisorReport) -> bool {
    advisor
        .writer_compression_candidate_fields
        .iter()
        .any(|field| !field.trim().is_empty() && !field.starts_with("__shardloom_derived_"))
}

#[cfg(feature = "vortex-write")]
fn admitted_layout_writer_has_storage_compression_fields(
    advisor: &VortexLayoutWriteAdvisorReport,
) -> bool {
    advisor
        .writer_compression_candidate_fields
        .iter()
        .any(|field| admitted_layout_writer_storage_compression_field(field))
}

#[cfg(feature = "vortex-write")]
fn admitted_layout_writer_storage_compression_field(field: &str) -> bool {
    let lower = field.trim().to_ascii_lowercase();
    if lower.is_empty() || lower.starts_with("__shardloom_derived_") {
        return false;
    }
    true
}

#[cfg(feature = "vortex-write")]
fn admitted_layout_writer_query_hot_domain_field(field: &str) -> bool {
    let lower = field.trim().to_ascii_lowercase();
    if lower.is_empty() || lower.starts_with("__shardloom_derived_") {
        return false;
    }
    lower.contains("url")
        || lower.contains("referer")
        || lower.contains("referrer")
        || lower.contains("search")
        || lower.contains("phrase")
        || lower.contains("title")
        || lower.contains("useragent")
        || lower.contains("domain")
}

#[cfg(feature = "vortex-write")]
fn layout_advisor_has_high_cardinality_profile(advisor: &VortexLayoutWriteAdvisorReport) -> bool {
    advisor
        .workload_constitution
        .contains("key_profile=high_cardinality")
        || advisor.workload_constitution.contains("high_cardinality_")
}

impl VortexLayoutWriteAdvisorReport {
    /// Return stable evidence fields for CLI/API surfaces.
    #[must_use]
    #[allow(clippy::too_many_lines)]
    pub fn evidence_fields(&self) -> Vec<(String, String)> {
        let mut fields = Vec::with_capacity(64);
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_schema_version",
            self.schema_version,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_status",
            &self.status,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_route",
            &self.route,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_role",
            "universal_ingest_optimizer",
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_public_runtime_posture",
            "admitted_local_product_workflow_not_smoke",
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_single_artifact_required",
            "true",
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_query_answer_sidecar_allowed",
            "false",
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_metadata_payload_policy",
            "embedded_generic_layout_statistics_no_query_answer_sidecars",
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_compact_derived_metadata_policy",
            "dictionary_derived_metadata_preferred_over_full_hidden_columns",
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_membership_sketch_policy",
            "generic_segment_membership_only_not_query_result_cache",
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_row_position_locality_policy",
            "embedded_order_key_row_position_locality_when_available",
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_surface_unification_policy",
            "sql_python_dataframe_cli_share_vortex_normalized_physical_runtime",
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_source_state_id",
            &self.source_state_id,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_source_state_digest",
            &self.source_state_digest,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_source_format",
            &self.source_format,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_source_schema_digest",
            &self.source_schema_digest,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_row_count",
            self.row_count.to_string(),
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_source_byte_count",
            self.source_byte_count.to_string(),
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_column_count",
            self.column_count.to_string(),
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_workload_constitution",
            &self.workload_constitution,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_source_scale",
            workload_constitution_value(&self.workload_constitution, "scale"),
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_profile_family",
            workload_constitution_value(&self.workload_constitution, "profile"),
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_prepared_layout_family",
            workload_constitution_value(&self.workload_constitution, "layout_family"),
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_text_domain_columns",
            workload_constitution_value(&self.workload_constitution, "text_domain"),
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_time_bucket_columns",
            workload_constitution_value(&self.workload_constitution, "time_bucket"),
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_counter_columns",
            workload_constitution_value(&self.workload_constitution, "counter"),
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_key_profile",
            workload_constitution_value(&self.workload_constitution, "key_profile"),
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_dictionary_profile",
            workload_constitution_value(&self.workload_constitution, "dictionary"),
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_source_statistics_status",
            &self.source_statistics_status,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_requested_pushdown_requirements",
            &self.requested_pushdown_requirements,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_sink_requirements",
            &self.sink_requirements,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_layout_strategy",
            &self.layout_strategy,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_chunking_strategy",
            &self.chunking_strategy,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_segmentation_strategy",
            &self.segmentation_strategy,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_dictionary_strategy",
            &self.dictionary_strategy,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_statistics_policy",
            &self.statistics_policy,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_writer_provider_kind",
            &self.writer_provider_kind,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_writer_provider_version",
            self.writer_provider_version,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_writer_provider_surface",
            &self.writer_provider_surface,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_writer_admission_policy",
            &self.writer_admission_policy,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_writer_parallelism_budget",
            self.writer_parallelism_budget.to_string(),
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_writer_compression_candidate_field_count",
            self.writer_compression_candidate_fields.len().to_string(),
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_writer_compression_candidate_fields",
            if self.writer_compression_candidate_fields.is_empty() {
                "none".to_string()
            } else {
                self.writer_compression_candidate_fields.join(",")
            },
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_write_reopen_verification_depth",
            &self.write_reopen_verification_depth,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_materialization_boundary_status",
            &self.materialization_boundary_status,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_decode_boundary_status",
            &self.decode_boundary_status,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_expected_read_tradeoff",
            &self.expected_read_tradeoff,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_expected_write_tradeoff",
            &self.expected_write_tradeoff,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_strategy_admitted",
            self.strategy_admitted.to_string(),
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_runtime_decision_applied",
            self.runtime_decision_applied.to_string(),
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_selected_strategy",
            &self.selected_strategy,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_strategy_decision_digest",
            &self.strategy_decision_digest,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_provider_admitted",
            self.provider_admitted.to_string(),
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_blocker",
            &self.blocker,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_unsupported_diagnostic_code",
            &self.unsupported_diagnostic_code,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_correctness_refs",
            &self.correctness_refs,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_benchmark_refs",
            &self.benchmark_refs,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_no_standalone_lane_status",
            &self.no_standalone_lane_status,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_claim_gate_status",
            &self.claim_gate_status,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_claim_boundary",
            &self.claim_boundary,
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_fallback_attempted",
            self.fallback_attempted.to_string(),
        );
        Self::push_field(
            &mut fields,
            "vortex_layout_write_advisor_external_engine_invoked",
            self.external_engine_invoked.to_string(),
        );
        fields
    }

    fn push_field(fields: &mut Vec<(String, String)>, key: &'static str, value: impl Into<String>) {
        fields.push((key.to_string(), value.into()));
    }

    /// Attach a writer-validated runtime decision to the public advisor
    /// evidence after the writer path has actually applied or blocked it.
    #[must_use]
    pub fn with_runtime_decision(mut self, decision: &VortexLayoutWriteRuntimeDecision) -> Self {
        self.runtime_decision_applied = decision.runtime_decision_applied;
        self.selected_strategy
            .clone_from(&decision.selected_strategy);
        self.strategy_decision_digest
            .clone_from(&decision.strategy_decision_digest);
        self.provider_admitted = decision.provider_admitted;
        self.blocker.clone_from(&decision.blocker);
        self
    }
}

fn workload_constitution_value<'a>(workload_constitution: &'a str, key: &str) -> &'a str {
    workload_constitution
        .split(';')
        .filter_map(|part| part.split_once('='))
        .find_map(|(candidate, value)| (candidate == key).then_some(value))
        .unwrap_or("unknown")
}

/// Evaluate admitted local-product Vortex layout/write advisor evidence.
#[must_use]
pub fn evaluate_vortex_layout_write_advisor(
    input: VortexLayoutWriteAdvisorInput,
) -> VortexLayoutWriteAdvisorReport {
    let status = layout_write_advisor_status(&input);
    let provider_admitted = status == "admitted_local_layout_write_strategy";
    let selected_strategy = if provider_admitted {
        input.layout_strategy.clone()
    } else {
        "not_admitted".to_string()
    };
    let blocker = if provider_admitted {
        "pending_runtime_write_decision".to_string()
    } else if input.unsupported_diagnostic_code == "none" {
        status.to_string()
    } else {
        input.unsupported_diagnostic_code.clone()
    };
    let writer_parallelism_budget = input.writer_parallelism_budget.max(1);
    let strategy_decision_digest = fnv64_digest_text(&format!(
        "layout_write_advisor_evaluation|{}|{}|{}|{}|{}|{}|{}",
        input.source_state_digest,
        input.source_schema_digest,
        selected_strategy,
        input.writer_provider_kind,
        input.writer_admission_policy,
        writer_parallelism_budget,
        blocker
    ));
    VortexLayoutWriteAdvisorReport {
        schema_version: VORTEX_LAYOUT_WRITE_ADVISOR_SCHEMA_VERSION,
        status: status.to_string(),
        route: "vortex_ingest_layout_write_advisor".to_string(),
        source_state_id: input.source_state_id,
        source_state_digest: input.source_state_digest,
        source_format: input.source_format,
        source_schema_digest: input.source_schema_digest,
        row_count: input.row_count,
        source_byte_count: input.source_byte_count,
        column_count: input.column_count,
        workload_constitution: input.workload_constitution,
        source_statistics_status: input.source_statistics_status,
        requested_pushdown_requirements: input.requested_pushdown_requirements,
        sink_requirements: input.sink_requirements,
        layout_strategy: input.layout_strategy,
        chunking_strategy: input.chunking_strategy,
        segmentation_strategy: input.segmentation_strategy,
        dictionary_strategy: input.dictionary_strategy,
        statistics_policy: input.statistics_policy,
        writer_provider_kind: input.writer_provider_kind,
        writer_provider_version: VORTEX_PREPARATION_SPINE_VORTEX_CRATE_VERSION,
        writer_provider_surface: input.writer_provider_surface,
        writer_admission_policy: input.writer_admission_policy,
        writer_parallelism_budget,
        writer_compression_candidate_fields: input.writer_compression_candidate_fields,
        write_reopen_verification_depth: input.write_reopen_verification_depth,
        materialization_boundary_status: input.materialization_boundary_status,
        decode_boundary_status: input.decode_boundary_status,
        expected_read_tradeoff: input.expected_read_tradeoff,
        expected_write_tradeoff: input.expected_write_tradeoff,
        strategy_admitted: input.strategy_admitted,
        runtime_decision_applied: false,
        selected_strategy,
        strategy_decision_digest,
        provider_admitted,
        blocker,
        unsupported_diagnostic_code: input.unsupported_diagnostic_code,
        correctness_refs: input.correctness_refs,
        benchmark_refs: input.benchmark_refs,
        no_standalone_lane_status:
            "funnelled_through_vortex_ingest_source_state_to_vortex_prepared_state".to_string(),
        claim_gate_status: "not_claim_grade".to_string(),
        claim_boundary: "VortexLayoutWriteAdvisor evidence is admitted local-product layout/write admission: it records source statistics posture, pushdown/sink requirements, writer strategy, provider boundary, tradeoffs, verification depth, correctness refs, and benchmark-ref posture without proving performance, object-store/table layout, remote production, SQL/DataFrame breadth, or Spark-replacement readiness".to_string(),
        fallback_attempted: input.fallback_attempted,
        external_engine_invoked: input.external_engine_invoked,
    }
}

fn layout_write_advisor_status(input: &VortexLayoutWriteAdvisorInput) -> &'static str {
    if input.unsupported_diagnostic_code == "vortex_ingest.requires_vortex_write_feature" {
        "blocked_feature_gate"
    } else if input.writer_admission_policy
        != VORTEX_PRODUCT_LOCAL_INGEST_PREPARE_ONCE_ADMISSION_POLICY
    {
        "vortex_layout_write_advisor.unsupported_writer_admission_policy"
    } else if !input.strategy_admitted || input.unsupported_diagnostic_code != "none" {
        "blocked_layout_write_strategy"
    } else {
        "admitted_local_layout_write_strategy"
    }
}

#[cfg(feature = "vortex-write")]
fn admit_layout_write_runtime_decision_for_source(
    advisor: Option<&VortexLayoutWriteAdvisorReport>,
    expected_provider_kind: &str,
    expected_provider_surface: &str,
    target_path: &Path,
    certification_level: VortexIngestCertificationLevel,
    source: VortexWriterPhysicalDesignSourceInput,
) -> Result<VortexLayoutWriteRuntimeDecision> {
    let Some(advisor) = advisor else {
        return Ok(VortexLayoutWriteRuntimeDecision::not_requested_for_source(
            expected_provider_kind,
            expected_provider_surface,
            certification_level,
            source,
        ));
    };
    let blocker =
        layout_write_runtime_blocker(advisor, expected_provider_kind, expected_provider_surface);
    if blocker != "none" {
        return Err(ShardLoomError::InvalidOperation(format!(
            "local vortex_ingest layout/write advisor blocked writer strategy '{}': {}; no fallback execution was attempted",
            advisor.layout_strategy, blocker
        )));
    }
    Ok(VortexLayoutWriteRuntimeDecision::applied_for_source(
        advisor,
        target_path,
        expected_provider_kind,
        expected_provider_surface,
        certification_level,
        source,
    ))
}

#[cfg(feature = "vortex-write")]
fn layout_write_runtime_blocker(
    advisor: &VortexLayoutWriteAdvisorReport,
    expected_provider_kind: &str,
    expected_provider_surface: &str,
) -> String {
    if advisor.status != "admitted_local_layout_write_strategy" {
        return format!(
            "vortex_layout_write_advisor.status_not_admitted:{}",
            advisor.status
        );
    }
    if !advisor.strategy_admitted {
        return "vortex_layout_write_advisor.strategy_not_admitted".to_string();
    }
    if advisor.unsupported_diagnostic_code != "none" {
        return advisor.unsupported_diagnostic_code.clone();
    }
    if !matches!(
        advisor.layout_strategy.as_str(),
        "single_local_vortex_artifact" | "single_vortex_artifact_embedded_olap_layout_statistics"
    ) {
        return "vortex_layout_write_advisor.unsupported_layout_strategy".to_string();
    }
    if advisor.sink_requirements != "workspace_safe_local_vortex_file_sink" {
        return "vortex_layout_write_advisor.unsupported_sink_requirements".to_string();
    }
    if advisor.writer_admission_policy != VORTEX_PRODUCT_LOCAL_INGEST_PREPARE_ONCE_ADMISSION_POLICY
    {
        return "vortex_layout_write_advisor.unsupported_writer_admission_policy".to_string();
    }
    if !matches!(
        advisor.chunking_strategy.as_str(),
        "single_chunk_for_product_local_small_source"
            | "single_chunk_for_scoped_local_fixture"
            | "single_chunk_for_scoped_fixture"
            | "writer_default_chunking_no_performance_claim"
            | "upstream_vortex_writer_default_zoned_row_blocks"
    ) {
        return "vortex_layout_write_advisor.unsupported_chunking_strategy".to_string();
    }
    if !matches!(
        advisor.segmentation_strategy.as_str(),
        "single_segment_local_fixture"
            | "single_segment_fixture"
            | "upstream_vortex_writer_default_zoned_segments"
    ) {
        return "vortex_layout_write_advisor.unsupported_segmentation_strategy".to_string();
    }
    if !matches!(
        advisor.dictionary_strategy.as_str(),
        "writer_default_no_dictionary_claim"
            | "preserve_vortex_dictionary_and_encoding_metadata_when_writer_emits_it"
    ) {
        return "vortex_layout_write_advisor.unsupported_dictionary_strategy".to_string();
    }
    if !matches!(
        advisor.statistics_policy.as_str(),
        "writer_default_statistics_no_pruning_claim"
            | "preserve_vortex_layout_footer_statistics_for_metadata_pruning"
    ) {
        return "vortex_layout_write_advisor.unsupported_statistics_policy".to_string();
    }
    if advisor.writer_provider_kind != expected_provider_kind {
        return format!(
            "vortex_layout_write_advisor.provider_kind_mismatch:expected={expected_provider_kind};actual={}",
            advisor.writer_provider_kind
        );
    }
    if !advisor
        .writer_provider_surface
        .contains(expected_provider_surface)
    {
        return format!(
            "vortex_layout_write_advisor.provider_surface_mismatch:expected={expected_provider_surface}"
        );
    }
    if !advisor
        .writer_provider_surface
        .contains("VortexSession::write_options().write(ArrayStream)")
    {
        return "vortex_layout_write_advisor.missing_vortex_writer_surface".to_string();
    }
    "none".to_string()
}

/// Inputs used to expose cold-lane copy-budget and buffer-lifecycle evidence.
#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct VortexCopyBudgetInput {
    pub source_state_id: String,
    pub source_state_digest: String,
    pub prepared_state_id: String,
    pub prepared_state_digest: String,
    pub source_format: String,
    pub row_count: u64,
    pub source_byte_count: u64,
    pub column_count: usize,
    pub allocation_scope: String,
    pub copy_scope: String,
    pub measurement_status: String,
    pub source_read_copy_bytes: String,
    pub parse_normalization_copy_bytes: String,
    pub columnar_handoff_copy_bytes: String,
    pub vortex_array_build_copy_bytes: String,
    pub writer_buffer_bytes: String,
    pub reopen_verify_copy_bytes: String,
    pub evidence_render_copy_bytes: String,
    pub total_measured_copy_bytes: String,
    pub buffer_family: String,
    pub ownership_policy: String,
    pub writer_buffering_status: String,
    pub buffer_reuse_status: String,
    pub buffer_reuse_count: u64,
    pub unsafe_lifetime_shortcut_status: String,
    pub correctness_parity_refs: String,
    pub materialization_boundary_status: String,
    pub decode_boundary_status: String,
    pub unsupported_diagnostic_code: String,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

/// Evidence for scoped local copy-budget and buffer-lifecycle checks.
#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct VortexCopyBudgetReport {
    pub schema_version: &'static str,
    pub status: String,
    pub route: String,
    pub source_state_id: String,
    pub source_state_digest: String,
    pub prepared_state_id: String,
    pub prepared_state_digest: String,
    pub source_format: String,
    pub row_count: u64,
    pub source_byte_count: u64,
    pub column_count: usize,
    pub allocation_scope: String,
    pub copy_scope: String,
    pub measurement_status: String,
    pub source_read_copy_bytes: String,
    pub parse_normalization_copy_bytes: String,
    pub columnar_handoff_copy_bytes: String,
    pub vortex_array_build_copy_bytes: String,
    pub writer_buffer_bytes: String,
    pub reopen_verify_copy_bytes: String,
    pub evidence_render_copy_bytes: String,
    pub total_measured_copy_bytes: String,
    pub buffer_family: String,
    pub ownership_policy: String,
    pub writer_buffering_status: String,
    pub buffer_reuse_status: String,
    pub buffer_reuse_count: u64,
    pub unsafe_lifetime_shortcut_status: String,
    pub correctness_parity_refs: String,
    pub materialization_boundary_status: String,
    pub decode_boundary_status: String,
    pub unsupported_diagnostic_code: String,
    pub no_standalone_lane_status: String,
    pub claim_gate_status: String,
    pub claim_boundary: String,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

impl VortexCopyBudgetReport {
    /// Return stable evidence fields for CLI/API surfaces.
    #[must_use]
    #[allow(clippy::too_many_lines)]
    pub fn evidence_fields(&self) -> Vec<(String, String)> {
        let mut fields = Vec::with_capacity(38);
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_schema_version",
            self.schema_version,
        );
        Self::push_field(&mut fields, "vortex_copy_budget_status", &self.status);
        Self::push_field(&mut fields, "vortex_copy_budget_route", &self.route);
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_source_state_id",
            &self.source_state_id,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_source_state_digest",
            &self.source_state_digest,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_prepared_state_id",
            &self.prepared_state_id,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_prepared_state_digest",
            &self.prepared_state_digest,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_source_format",
            &self.source_format,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_row_count",
            self.row_count.to_string(),
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_source_byte_count",
            self.source_byte_count.to_string(),
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_column_count",
            self.column_count.to_string(),
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_allocation_scope",
            &self.allocation_scope,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_copy_scope",
            &self.copy_scope,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_measurement_status",
            &self.measurement_status,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_source_read_copy_bytes",
            &self.source_read_copy_bytes,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_parse_normalization_copy_bytes",
            &self.parse_normalization_copy_bytes,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_columnar_handoff_copy_bytes",
            &self.columnar_handoff_copy_bytes,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_vortex_array_build_copy_bytes",
            &self.vortex_array_build_copy_bytes,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_writer_buffer_bytes",
            &self.writer_buffer_bytes,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_reopen_verify_copy_bytes",
            &self.reopen_verify_copy_bytes,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_evidence_render_copy_bytes",
            &self.evidence_render_copy_bytes,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_total_measured_copy_bytes",
            &self.total_measured_copy_bytes,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_buffer_family",
            &self.buffer_family,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_ownership_policy",
            &self.ownership_policy,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_writer_buffering_status",
            &self.writer_buffering_status,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_buffer_reuse_status",
            &self.buffer_reuse_status,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_buffer_reuse_count",
            self.buffer_reuse_count.to_string(),
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_unsafe_lifetime_shortcut_status",
            &self.unsafe_lifetime_shortcut_status,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_correctness_parity_refs",
            &self.correctness_parity_refs,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_materialization_boundary_status",
            &self.materialization_boundary_status,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_decode_boundary_status",
            &self.decode_boundary_status,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_unsupported_diagnostic_code",
            &self.unsupported_diagnostic_code,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_no_standalone_lane_status",
            &self.no_standalone_lane_status,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_claim_gate_status",
            &self.claim_gate_status,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_claim_boundary",
            &self.claim_boundary,
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_fallback_attempted",
            self.fallback_attempted.to_string(),
        );
        Self::push_field(
            &mut fields,
            "vortex_copy_budget_external_engine_invoked",
            self.external_engine_invoked.to_string(),
        );
        fields
    }

    fn push_field(fields: &mut Vec<(String, String)>, key: &'static str, value: impl Into<String>) {
        fields.push((key.to_string(), value.into()));
    }
}

/// Evaluate scoped local copy-budget and buffer-lifecycle evidence.
#[must_use]
pub fn evaluate_vortex_copy_budget(input: VortexCopyBudgetInput) -> VortexCopyBudgetReport {
    let status = copy_budget_status(&input);
    VortexCopyBudgetReport {
        schema_version: VORTEX_COPY_BUDGET_SCHEMA_VERSION,
        status: status.to_string(),
        route: "vortex_ingest_copy_budget_buffer_lifecycle".to_string(),
        source_state_id: input.source_state_id,
        source_state_digest: input.source_state_digest,
        prepared_state_id: input.prepared_state_id,
        prepared_state_digest: input.prepared_state_digest,
        source_format: input.source_format,
        row_count: input.row_count,
        source_byte_count: input.source_byte_count,
        column_count: input.column_count,
        allocation_scope: input.allocation_scope,
        copy_scope: input.copy_scope,
        measurement_status: input.measurement_status,
        source_read_copy_bytes: input.source_read_copy_bytes,
        parse_normalization_copy_bytes: input.parse_normalization_copy_bytes,
        columnar_handoff_copy_bytes: input.columnar_handoff_copy_bytes,
        vortex_array_build_copy_bytes: input.vortex_array_build_copy_bytes,
        writer_buffer_bytes: input.writer_buffer_bytes,
        reopen_verify_copy_bytes: input.reopen_verify_copy_bytes,
        evidence_render_copy_bytes: input.evidence_render_copy_bytes,
        total_measured_copy_bytes: input.total_measured_copy_bytes,
        buffer_family: input.buffer_family,
        ownership_policy: input.ownership_policy,
        writer_buffering_status: input.writer_buffering_status,
        buffer_reuse_status: input.buffer_reuse_status,
        buffer_reuse_count: input.buffer_reuse_count,
        unsafe_lifetime_shortcut_status: input.unsafe_lifetime_shortcut_status,
        correctness_parity_refs: input.correctness_parity_refs,
        materialization_boundary_status: input.materialization_boundary_status,
        decode_boundary_status: input.decode_boundary_status,
        unsupported_diagnostic_code: input.unsupported_diagnostic_code,
        no_standalone_lane_status:
            "funnelled_through_vortex_ingest_source_state_to_vortex_prepared_state".to_string(),
        claim_gate_status: "not_claim_grade".to_string(),
        claim_boundary: "VortexCopyBudget evidence is scoped local cold-lane allocation/copy and buffer-lifecycle visibility only: it records measured or not-measured copy scopes, writer buffering, ownership policy, reuse blockers, unsafe-lifetime posture, correctness parity refs, and materialization/decode boundaries without proving memory efficiency, global buffer-pool behavior, performance, production, SQL/DataFrame, or Spark-replacement readiness".to_string(),
        fallback_attempted: input.fallback_attempted,
        external_engine_invoked: input.external_engine_invoked,
    }
}

fn copy_budget_status(input: &VortexCopyBudgetInput) -> &'static str {
    if input.unsupported_diagnostic_code == "vortex_ingest.requires_vortex_write_feature" {
        "blocked_feature_gate"
    } else if input.unsupported_diagnostic_code != "none" {
        "blocked_copy_budget"
    } else if input.unsafe_lifetime_shortcut_status != "blocked_no_unsafe_lifetime_shortcuts" {
        "blocked_unsafe_lifetime_shortcut"
    } else if input.buffer_reuse_status.starts_with("admitted")
        && input.measurement_status.contains("not_measured")
    {
        "admitted_scoped_buffer_reuse_with_unmeasured_segments"
    } else if input.buffer_reuse_status.starts_with("admitted") {
        "admitted_scoped_buffer_reuse"
    } else if input.measurement_status.contains("not_measured") {
        "reported_copy_budget_with_unmeasured_segments"
    } else {
        "reported_copy_budget"
    }
}

/// Inputs used to expose capillary cold-preparation task evidence.
#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct VortexCapillaryPreparationInput {
    pub source_state_id: String,
    pub source_state_digest: String,
    pub prepared_state_id: String,
    pub prepared_state_digest: String,
    pub source_surface: String,
    pub sink_surface: String,
    pub format_family: String,
    pub operation_class: String,
    pub certification_depth: String,
    pub row_count: u64,
    pub source_byte_count: u64,
    pub column_count: usize,
    pub source_split_refs: String,
    pub source_byte_range_refs: String,
    pub source_row_range_refs: String,
    pub projection_mask: String,
    pub filter_mask_status: String,
    pub prepared_artifact_ref: String,
    pub prepared_artifact_digest: String,
    pub prepared_artifact_segment_refs: String,
    pub writer_sink_refs: String,
    pub materialization_boundary_status: String,
    pub decode_boundary_status: String,
    pub native_io_certificate_status: String,
    pub native_io_certificate_refs: String,
    pub correctness_digest: String,
    pub memory_budget_bytes: u64,
    pub max_parallelism: usize,
    pub result_sink_requested: bool,
    pub result_sink_replay_verified: bool,
    pub capillary_claim_evidence_requested: bool,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct VortexCapillaryActivation {
    pub activated: bool,
    pub reason: &'static str,
    pub observed_split_count: usize,
    pub estimated_peak_memory_bytes: u64,
}

struct VortexCapillaryActivatedEvidence {
    task_manifest_digest: String,
    execution_certificate_id: String,
    execution_certificate_status: &'static str,
    task_count: usize,
    task_roles: String,
    task_ids: String,
    task_byte_range_refs: String,
    task_row_range_refs: String,
    vortex_segment_refs: String,
    execution_window_count: usize,
    execution_window_size: usize,
    execution_window_ids: String,
    execution_window_task_counts: String,
    execution_window_task_ids: String,
    execution_window_digests: String,
    scheduler_applied: bool,
    scheduler_application_reason: &'static str,
    peak_memory_bytes: u64,
    pulseweave_report: PulseWeaveReport,
    status: &'static str,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct VortexCapillaryPreparationTask {
    task_id: String,
    role: &'static str,
    operator_memory_class: OperatorMemoryClass,
    byte_range_ref: String,
    row_range_ref: String,
    vortex_segment_ref: String,
    writer_sink_ref: String,
    estimated_memory_bytes: u64,
}

impl VortexCapillaryPreparationTask {
    fn to_pulseweave_shape(&self) -> Result<PulseWeaveTaskShape> {
        PulseWeaveTaskShape::new(
            self.task_id.as_str(),
            self.role,
            self.operator_memory_class,
            self.estimated_memory_bytes,
        )
        .map(|shape| {
            shape
                .with_estimated_rows(1)
                .with_refs(
                    self.writer_sink_ref.clone(),
                    format!("capillary-task://{}", self.task_id),
                )
                .with_shape_permissions(true, true, true)
                .with_materialization_and_sink(
                    matches!(self.operator_memory_class, OperatorMemoryClass::Translation),
                    if matches!(self.operator_memory_class, OperatorMemoryClass::Sink) {
                        "workspace_safe_local_vortex_file_sink"
                    } else {
                        "none"
                    },
                )
        })
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct VortexCapillaryExecutionWindow {
    window_id: String,
    task_ids: Vec<String>,
    task_count: usize,
    window_digest: String,
}

/// Evidence for capillary cold-preparation task control.
#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct VortexCapillaryPreparationReport {
    pub schema_version: &'static str,
    pub status: String,
    pub route: String,
    pub activation_policy: String,
    pub activation_result: String,
    pub activation_reason: String,
    pub activation_threshold_bytes: u64,
    pub activation_threshold_rows: u64,
    pub activation_threshold_splits: usize,
    pub activation_threshold_columns: usize,
    pub activation_observed_bytes: u64,
    pub activation_observed_rows: u64,
    pub activation_observed_columns: usize,
    pub activation_observed_split_count: usize,
    pub activation_estimated_peak_memory_bytes: u64,
    pub activation_format_family: String,
    pub activation_operation_class: String,
    pub activation_certification_depth: String,
    pub activation_result_sink_replay_requested: bool,
    pub source_surface: String,
    pub sink_surface: String,
    pub source_state_id: String,
    pub source_state_digest: String,
    pub prepared_state_id: String,
    pub prepared_state_digest: String,
    pub task_manifest_id: String,
    pub task_manifest_digest: String,
    pub task_count: usize,
    pub task_roles: String,
    pub task_ids: String,
    pub execution_window_count: usize,
    pub execution_window_size: usize,
    pub execution_window_ids: String,
    pub execution_window_task_counts: String,
    pub execution_window_task_ids: String,
    pub execution_window_digests: String,
    pub scheduler_applied: bool,
    pub scheduler_application_reason: String,
    pub source_split_refs: String,
    pub read_chunk_byte_range_refs: String,
    pub row_range_refs: String,
    pub projection_mask: String,
    pub filter_mask_status: String,
    pub vortex_segment_refs: String,
    pub writer_sink_refs: String,
    pub memory_budget_bytes: u64,
    pub max_parallelism: usize,
    pub peak_memory_bytes: u64,
    pub memory_pressure_status: String,
    pub sink_pressure_status: String,
    pub retry_idempotency_status: String,
    pub materialization_boundary_status: String,
    pub decode_boundary_status: String,
    pub native_io_certificate_status: String,
    pub native_io_certificate_refs: String,
    pub execution_certificate_id: String,
    pub execution_certificate_status: String,
    pub pulseweave_report: PulseWeaveReport,
    pub correctness_refs: String,
    pub no_standalone_lane_status: String,
    pub claim_gate_status: String,
    pub claim_boundary: String,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

impl VortexCapillaryPreparationReport {
    /// Return stable evidence fields for CLI/API surfaces.
    #[must_use]
    pub fn evidence_fields(&self) -> Vec<(String, String)> {
        let mut fields = Vec::with_capacity(104);
        self.append_identity_fields(&mut fields);
        self.append_activation_fields(&mut fields);
        self.append_source_sink_fields(&mut fields);
        self.append_task_fields(&mut fields);
        self.append_policy_fields(&mut fields);
        fields.extend(
            self.pulseweave_report
                .fields()
                .into_iter()
                .map(|(key, value)| (format!("vortex_capillary_preparation_{key}"), value)),
        );
        fields
    }

    fn push_field(fields: &mut Vec<(String, String)>, key: &'static str, value: impl Into<String>) {
        fields.push((key.to_string(), value.into()));
    }

    fn append_identity_fields(&self, fields: &mut Vec<(String, String)>) {
        Self::push_field(
            fields,
            "vortex_capillary_preparation_schema_version",
            self.schema_version,
        );
        Self::push_field(fields, "vortex_capillary_preparation_status", &self.status);
        Self::push_field(fields, "vortex_capillary_preparation_route", &self.route);
    }

    fn append_activation_fields(&self, fields: &mut Vec<(String, String)>) {
        Self::push_field(
            fields,
            "vortex_capillary_preparation_activation_policy",
            &self.activation_policy,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_activation_result",
            &self.activation_result,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_activation_reason",
            &self.activation_reason,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_activation_threshold_bytes",
            self.activation_threshold_bytes.to_string(),
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_activation_threshold_rows",
            self.activation_threshold_rows.to_string(),
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_activation_threshold_splits",
            self.activation_threshold_splits.to_string(),
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_activation_threshold_columns",
            self.activation_threshold_columns.to_string(),
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_activation_observed_bytes",
            self.activation_observed_bytes.to_string(),
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_activation_observed_rows",
            self.activation_observed_rows.to_string(),
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_activation_observed_columns",
            self.activation_observed_columns.to_string(),
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_activation_observed_split_count",
            self.activation_observed_split_count.to_string(),
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_activation_estimated_peak_memory_bytes",
            self.activation_estimated_peak_memory_bytes.to_string(),
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_activation_format_family",
            &self.activation_format_family,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_activation_operation_class",
            &self.activation_operation_class,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_activation_certification_depth",
            &self.activation_certification_depth,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_activation_result_sink_replay_requested",
            self.activation_result_sink_replay_requested.to_string(),
        );
    }

    fn append_source_sink_fields(&self, fields: &mut Vec<(String, String)>) {
        Self::push_field(
            fields,
            "vortex_capillary_preparation_source_surface",
            &self.source_surface,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_sink_surface",
            &self.sink_surface,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_source_state_id",
            &self.source_state_id,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_source_state_digest",
            &self.source_state_digest,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_prepared_state_id",
            &self.prepared_state_id,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_prepared_state_digest",
            &self.prepared_state_digest,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_task_manifest_id",
            &self.task_manifest_id,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_task_manifest_digest",
            &self.task_manifest_digest,
        );
    }

    fn append_task_fields(&self, fields: &mut Vec<(String, String)>) {
        Self::push_field(
            fields,
            "vortex_capillary_preparation_task_count",
            self.task_count.to_string(),
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_task_roles",
            &self.task_roles,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_task_ids",
            &self.task_ids,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_execution_window_count",
            self.execution_window_count.to_string(),
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_execution_window_size",
            self.execution_window_size.to_string(),
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_execution_window_ids",
            &self.execution_window_ids,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_execution_window_task_counts",
            &self.execution_window_task_counts,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_execution_window_task_ids",
            &self.execution_window_task_ids,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_execution_window_digests",
            &self.execution_window_digests,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_scheduler_applied",
            self.scheduler_applied.to_string(),
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_scheduler_application_reason",
            &self.scheduler_application_reason,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_source_split_refs",
            &self.source_split_refs,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_read_chunk_byte_range_refs",
            &self.read_chunk_byte_range_refs,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_row_range_refs",
            &self.row_range_refs,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_projection_mask",
            &self.projection_mask,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_filter_mask_status",
            &self.filter_mask_status,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_vortex_segment_refs",
            &self.vortex_segment_refs,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_writer_sink_refs",
            &self.writer_sink_refs,
        );
    }

    fn append_policy_fields(&self, fields: &mut Vec<(String, String)>) {
        Self::push_field(
            fields,
            "vortex_capillary_preparation_memory_budget_bytes",
            self.memory_budget_bytes.to_string(),
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_max_parallelism",
            self.max_parallelism.to_string(),
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_peak_memory_bytes",
            self.peak_memory_bytes.to_string(),
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_memory_pressure_status",
            &self.memory_pressure_status,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_sink_pressure_status",
            &self.sink_pressure_status,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_retry_idempotency_status",
            &self.retry_idempotency_status,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_materialization_boundary_status",
            &self.materialization_boundary_status,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_decode_boundary_status",
            &self.decode_boundary_status,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_native_io_certificate_status",
            &self.native_io_certificate_status,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_native_io_certificate_refs",
            &self.native_io_certificate_refs,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_execution_certificate_id",
            &self.execution_certificate_id,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_execution_certificate_status",
            &self.execution_certificate_status,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_correctness_refs",
            &self.correctness_refs,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_no_standalone_lane_status",
            &self.no_standalone_lane_status,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_claim_gate_status",
            &self.claim_gate_status,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_claim_boundary",
            &self.claim_boundary,
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_fallback_attempted",
            self.fallback_attempted.to_string(),
        );
        Self::push_field(
            fields,
            "vortex_capillary_preparation_external_engine_invoked",
            self.external_engine_invoked.to_string(),
        );
    }
}

/// Pre-write capillary control evidence attached to local Vortex preparation.
#[allow(clippy::struct_excessive_bools)]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VortexCapillaryPreWriteControlReport {
    pub schema_version: &'static str,
    pub status: String,
    pub source_report_status: String,
    pub activation_result: String,
    pub activation_reason: String,
    pub scheduler_applied: bool,
    pub execution_window_count: usize,
    pub execution_window_size: usize,
    pub execution_window_ids: String,
    pub execution_window_task_ids: String,
    pub execution_window_digests: String,
    pub controlled_task_roles: String,
    pub plan_digest: String,
    pub source_split_discovery_gate_status: String,
    pub read_chunk_gate_status: String,
    pub array_build_gate_status: String,
    pub write_gate_status: String,
    pub reopen_gate_status: String,
    pub sink_evidence_gate_status: String,
    pub flow_inventory_wip_limit: usize,
    pub scarcity_ledger_selected_action: String,
    pub endopulse_adjustment_applied: bool,
    pub proofbound_pre_application_status: String,
    pub proofbound_post_application_status: String,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

#[cfg(feature = "vortex-write")]
impl VortexCapillaryPreWriteControlReport {
    fn not_requested(reason: impl Into<String>) -> Self {
        let reason = reason.into();
        Self {
            schema_version: VORTEX_CAPILLARY_PREPARATION_SCHEMA_VERSION,
            status: "not_requested".to_string(),
            source_report_status: "not_requested".to_string(),
            activation_result: "not_requested".to_string(),
            activation_reason: reason.clone(),
            scheduler_applied: false,
            execution_window_count: 0,
            execution_window_size: 0,
            execution_window_ids: "none".to_string(),
            execution_window_task_ids: "none".to_string(),
            execution_window_digests: "none".to_string(),
            controlled_task_roles: "none".to_string(),
            plan_digest: "none".to_string(),
            source_split_discovery_gate_status: "not_requested".to_string(),
            read_chunk_gate_status: "not_requested".to_string(),
            array_build_gate_status: "not_requested".to_string(),
            write_gate_status: "not_requested".to_string(),
            reopen_gate_status: "not_requested".to_string(),
            sink_evidence_gate_status: "not_requested".to_string(),
            flow_inventory_wip_limit: 0,
            scarcity_ledger_selected_action: "not_requested".to_string(),
            endopulse_adjustment_applied: false,
            proofbound_pre_application_status: "not_requested".to_string(),
            proofbound_post_application_status: "not_requested".to_string(),
            fallback_attempted: false,
            external_engine_invoked: false,
        }
    }

    fn from_preparation_report(report: &VortexCapillaryPreparationReport) -> Self {
        let status = if report.scheduler_applied {
            "applied_before_array_build"
        } else if report.activation_result == "skipped" {
            "not_requested_below_threshold"
        } else if report.status.starts_with("blocked")
            || report.status.starts_with("report_only_blocked")
        {
            "report_only_blocked_before_array_build"
        } else {
            "report_only_not_applied_before_array_build"
        };
        let plan_digest = fnv64_digest_text(&format!(
            "{}|{}|{}|{}|{}|{}",
            report.source_state_digest,
            report.task_manifest_digest,
            report.execution_window_count,
            report.execution_window_size,
            report.execution_window_ids,
            report.execution_window_task_ids
        ));
        Self {
            schema_version: VORTEX_CAPILLARY_PREPARATION_SCHEMA_VERSION,
            status: status.to_string(),
            source_report_status: report.status.clone(),
            activation_result: report.activation_result.clone(),
            activation_reason: report.activation_reason.clone(),
            scheduler_applied: report.scheduler_applied,
            execution_window_count: report.execution_window_count,
            execution_window_size: report.execution_window_size,
            execution_window_ids: report.execution_window_ids.clone(),
            execution_window_task_ids: report.execution_window_task_ids.clone(),
            execution_window_digests: report.execution_window_digests.clone(),
            controlled_task_roles: report.task_roles.clone(),
            plan_digest,
            source_split_discovery_gate_status: "pending".to_string(),
            read_chunk_gate_status: "pending".to_string(),
            array_build_gate_status: "pending".to_string(),
            write_gate_status: "pending".to_string(),
            reopen_gate_status: "pending".to_string(),
            sink_evidence_gate_status: "pending".to_string(),
            flow_inventory_wip_limit: report.pulseweave_report.flow_inventory.wip_limit,
            scarcity_ledger_selected_action: report
                .pulseweave_report
                .scarcity_ledger
                .selected_action
                .as_str()
                .to_string(),
            endopulse_adjustment_applied: report.pulseweave_report.endopulse.adjustment_applied,
            proofbound_pre_application_status: report
                .pulseweave_report
                .proofbound
                .pre_application_status
                .clone(),
            proofbound_post_application_status: report
                .pulseweave_report
                .proofbound
                .post_application_status
                .clone(),
            fallback_attempted: report.fallback_attempted,
            external_engine_invoked: report.external_engine_invoked,
        }
    }

    fn apply_task_role_gate(&mut self, role: &str, gate: &str) -> Result<()> {
        let status = if self.scheduler_applied {
            if capillary_role_list_contains(&self.controlled_task_roles, role) {
                "applied_prewrite_window"
            } else {
                return Err(ShardLoomError::InvalidOperation(format!(
                    "local vortex_ingest capillary pre-write scheduler applied, but task role '{role}' was missing before {gate}; no fallback execution was attempted"
                )));
            }
        } else {
            "not_applicable_scheduler_not_applied"
        };
        self.set_gate_status(gate, status);
        Ok(())
    }

    fn mark_task_role_not_performed(&mut self, role: &str, gate: &str) {
        let status = if self.scheduler_applied
            && capillary_role_list_contains(&self.controlled_task_roles, role)
        {
            "not_performed_by_certification_depth"
        } else {
            "not_applicable_scheduler_not_applied"
        };
        self.set_gate_status(gate, status);
    }

    fn set_gate_status(&mut self, gate: &str, status: &str) {
        match gate {
            "source_split_discovery" => {
                self.source_split_discovery_gate_status = status.to_string();
            }
            "read_chunk" => self.read_chunk_gate_status = status.to_string(),
            "array_build" => self.array_build_gate_status = status.to_string(),
            "write" => self.write_gate_status = status.to_string(),
            "reopen" => self.reopen_gate_status = status.to_string(),
            "sink_evidence" => self.sink_evidence_gate_status = status.to_string(),
            _ => {}
        }
    }
}

impl VortexCapillaryPreWriteControlReport {
    /// Return stable evidence fields for CLI/API surfaces.
    #[must_use]
    #[allow(clippy::too_many_lines)]
    pub fn evidence_fields(&self) -> Vec<(String, String)> {
        vec![
            (
                "vortex_capillary_preparation_prewrite_schema_version".to_string(),
                self.schema_version.to_string(),
            ),
            (
                "vortex_capillary_preparation_prewrite_status".to_string(),
                self.status.clone(),
            ),
            (
                "vortex_capillary_preparation_prewrite_source_report_status".to_string(),
                self.source_report_status.clone(),
            ),
            (
                "vortex_capillary_preparation_prewrite_activation_result".to_string(),
                self.activation_result.clone(),
            ),
            (
                "vortex_capillary_preparation_prewrite_activation_reason".to_string(),
                self.activation_reason.clone(),
            ),
            (
                "vortex_capillary_preparation_prewrite_scheduler_applied".to_string(),
                self.scheduler_applied.to_string(),
            ),
            (
                "vortex_capillary_preparation_prewrite_execution_window_count".to_string(),
                self.execution_window_count.to_string(),
            ),
            (
                "vortex_capillary_preparation_prewrite_execution_window_size".to_string(),
                self.execution_window_size.to_string(),
            ),
            (
                "vortex_capillary_preparation_prewrite_execution_window_ids".to_string(),
                self.execution_window_ids.clone(),
            ),
            (
                "vortex_capillary_preparation_prewrite_execution_window_task_ids".to_string(),
                self.execution_window_task_ids.clone(),
            ),
            (
                "vortex_capillary_preparation_prewrite_execution_window_digests".to_string(),
                self.execution_window_digests.clone(),
            ),
            (
                "vortex_capillary_preparation_prewrite_controlled_task_roles".to_string(),
                self.controlled_task_roles.clone(),
            ),
            (
                "vortex_capillary_preparation_prewrite_plan_digest".to_string(),
                self.plan_digest.clone(),
            ),
            (
                "vortex_capillary_preparation_prewrite_source_split_discovery_gate_status"
                    .to_string(),
                self.source_split_discovery_gate_status.clone(),
            ),
            (
                "vortex_capillary_preparation_prewrite_read_chunk_gate_status".to_string(),
                self.read_chunk_gate_status.clone(),
            ),
            (
                "vortex_capillary_preparation_prewrite_array_build_gate_status".to_string(),
                self.array_build_gate_status.clone(),
            ),
            (
                "vortex_capillary_preparation_prewrite_write_gate_status".to_string(),
                self.write_gate_status.clone(),
            ),
            (
                "vortex_capillary_preparation_prewrite_reopen_gate_status".to_string(),
                self.reopen_gate_status.clone(),
            ),
            (
                "vortex_capillary_preparation_prewrite_sink_evidence_gate_status".to_string(),
                self.sink_evidence_gate_status.clone(),
            ),
            (
                "vortex_capillary_preparation_prewrite_flow_inventory_wip_limit".to_string(),
                self.flow_inventory_wip_limit.to_string(),
            ),
            (
                "vortex_capillary_preparation_prewrite_scarcity_ledger_selected_action".to_string(),
                self.scarcity_ledger_selected_action.clone(),
            ),
            (
                "vortex_capillary_preparation_prewrite_endopulse_adjustment_applied".to_string(),
                self.endopulse_adjustment_applied.to_string(),
            ),
            (
                "vortex_capillary_preparation_prewrite_proofbound_pre_application_status"
                    .to_string(),
                self.proofbound_pre_application_status.clone(),
            ),
            (
                "vortex_capillary_preparation_prewrite_proofbound_post_application_status"
                    .to_string(),
                self.proofbound_post_application_status.clone(),
            ),
            (
                "vortex_capillary_preparation_prewrite_fallback_attempted".to_string(),
                self.fallback_attempted.to_string(),
            ),
            (
                "vortex_capillary_preparation_prewrite_external_engine_invoked".to_string(),
                self.external_engine_invoked.to_string(),
            ),
        ]
    }
}

/// Plan capillary cold-preparation task evidence and `PulseWeave` control.
///
/// # Errors
/// Returns an error when the `PulseWeave` task input is structurally invalid.
pub fn evaluate_vortex_capillary_preparation(
    input: VortexCapillaryPreparationInput,
) -> Result<VortexCapillaryPreparationReport> {
    let activation = should_activate_capillary(&input);
    if !activation.activated {
        return Ok(skipped_vortex_capillary_preparation_report(
            input, activation,
        ));
    }
    let tasks = capillary_preparation_tasks(&input);
    let task_roles = join_task_values(&tasks, |task| task.role.to_string());
    let task_ids = join_task_values(&tasks, |task| task.task_id.clone());
    let vortex_segment_refs = join_task_values(&tasks, |task| task.vortex_segment_ref.clone());
    let task_byte_range_refs = join_task_values(&tasks, |task| {
        format!("{}={}", task.role, task.byte_range_ref)
    });
    let task_row_range_refs = join_task_values(&tasks, |task| {
        format!("{}={}", task.role, task.row_range_ref)
    });
    let peak_memory_bytes = tasks
        .iter()
        .map(|task| task.estimated_memory_bytes)
        .sum::<u64>()
        .min(input.memory_budget_bytes);
    let execution_certificate_status = if missing_capillary_task_manifest(&input.source_split_refs)
    {
        "missing_capillary_task_manifest"
    } else {
        "certified"
    };
    let task_manifest_digest = fnv64_digest_text(&format!(
        "{}|{}|{}|{}|{}|{}",
        input.source_state_digest,
        input.prepared_state_digest,
        task_ids,
        task_roles,
        input.prepared_artifact_digest,
        input.correctness_digest
    ));
    let execution_certificate_id = format!(
        "vortex-capillary-preparation-{}",
        task_manifest_digest.replace(':', "-")
    );
    let pulseweave_report = capillary_pulseweave_report(
        &input,
        &tasks,
        peak_memory_bytes,
        &execution_certificate_id,
        execution_certificate_status,
    )?;
    let status = capillary_status(&input, &tasks, &pulseweave_report);
    let scheduler_applied = capillary_scheduler_applied(&input, &tasks, &pulseweave_report);
    let scheduler_application_reason =
        capillary_scheduler_application_reason(&input, &tasks, &pulseweave_report);
    let execution_window_size = if scheduler_applied {
        pulseweave_report.batch_window_size(input.max_parallelism)
    } else {
        0
    };
    let execution_windows =
        capillary_execution_windows(&tasks, scheduler_applied, execution_window_size);

    let evidence = VortexCapillaryActivatedEvidence {
        task_manifest_digest,
        execution_certificate_id,
        execution_certificate_status,
        task_count: tasks.len(),
        task_roles,
        task_ids,
        task_byte_range_refs,
        task_row_range_refs,
        vortex_segment_refs,
        execution_window_count: execution_windows.len(),
        execution_window_size,
        execution_window_ids: join_window_values(&execution_windows, |window| {
            window.window_id.clone()
        }),
        execution_window_task_counts: join_window_values(&execution_windows, |window| {
            format!("{}={}", window.window_id, window.task_count)
        }),
        execution_window_task_ids: join_window_values(&execution_windows, |window| {
            format!("{}={}", window.window_id, window.task_ids.join("|"))
        }),
        execution_window_digests: join_window_values(&execution_windows, |window| {
            format!("{}={}", window.window_id, window.window_digest)
        }),
        scheduler_applied,
        scheduler_application_reason,
        peak_memory_bytes,
        pulseweave_report,
        status,
    };
    Ok(activated_vortex_capillary_preparation_report(
        input, activation, evidence,
    ))
}

#[cfg(feature = "vortex-write")]
fn plan_capillary_prewrite_control(
    input: Option<&VortexCapillaryPreparationInput>,
) -> Result<VortexCapillaryPreWriteControlReport> {
    let Some(input) = input else {
        return Ok(VortexCapillaryPreWriteControlReport::not_requested(
            "no_capillary_prewrite_input",
        ));
    };
    if input.certification_depth != VortexIngestCertificationLevel::IngestCertified.as_str() {
        return Ok(VortexCapillaryPreWriteControlReport::not_requested(
            "certification_depth_does_not_request_reopen_verified_prewrite_control",
        ));
    }
    evaluate_vortex_capillary_preparation(input.clone())
        .map(|report| VortexCapillaryPreWriteControlReport::from_preparation_report(&report))
}

fn activated_vortex_capillary_preparation_report(
    input: VortexCapillaryPreparationInput,
    activation: VortexCapillaryActivation,
    evidence: VortexCapillaryActivatedEvidence,
) -> VortexCapillaryPreparationReport {
    VortexCapillaryPreparationReport {
        schema_version: VORTEX_CAPILLARY_PREPARATION_SCHEMA_VERSION,
        status: evidence.status.to_string(),
        route: "vortex_ingest_source_state_to_prepared_state".to_string(),
        activation_policy: VORTEX_CAPILLARY_ACTIVATION_POLICY.to_string(),
        activation_result: "activated".to_string(),
        activation_reason: activation.reason.to_string(),
        activation_threshold_bytes: VORTEX_CAPILLARY_ACTIVATION_THRESHOLD_BYTES,
        activation_threshold_rows: VORTEX_CAPILLARY_ACTIVATION_THRESHOLD_ROWS,
        activation_threshold_splits: VORTEX_CAPILLARY_ACTIVATION_THRESHOLD_SPLITS,
        activation_threshold_columns: VORTEX_CAPILLARY_ACTIVATION_THRESHOLD_COLUMNS,
        activation_observed_bytes: input.source_byte_count,
        activation_observed_rows: input.row_count,
        activation_observed_columns: input.column_count,
        activation_observed_split_count: activation.observed_split_count,
        activation_estimated_peak_memory_bytes: activation.estimated_peak_memory_bytes,
        activation_format_family: input.format_family,
        activation_operation_class: input.operation_class,
        activation_certification_depth: input.certification_depth,
        activation_result_sink_replay_requested: input.result_sink_requested
            || input.result_sink_replay_verified,
        source_surface: input.source_surface,
        sink_surface: input.sink_surface,
        source_state_id: input.source_state_id,
        source_state_digest: input.source_state_digest,
        prepared_state_id: input.prepared_state_id,
        prepared_state_digest: input.prepared_state_digest,
        task_manifest_id: format!(
            "vortex-capillary-task-manifest-{}",
            evidence.task_manifest_digest.replace(':', "-")
        ),
        task_manifest_digest: evidence.task_manifest_digest,
        task_count: evidence.task_count,
        task_roles: evidence.task_roles,
        task_ids: evidence.task_ids,
        execution_window_count: evidence.execution_window_count,
        execution_window_size: evidence.execution_window_size,
        execution_window_ids: evidence.execution_window_ids,
        execution_window_task_counts: evidence.execution_window_task_counts,
        execution_window_task_ids: evidence.execution_window_task_ids,
        execution_window_digests: evidence.execution_window_digests,
        scheduler_applied: evidence.scheduler_applied,
        scheduler_application_reason: evidence.scheduler_application_reason.to_string(),
        source_split_refs: input.source_split_refs,
        read_chunk_byte_range_refs: evidence.task_byte_range_refs,
        row_range_refs: evidence.task_row_range_refs,
        projection_mask: input.projection_mask,
        filter_mask_status: input.filter_mask_status,
        vortex_segment_refs: evidence.vortex_segment_refs,
        writer_sink_refs: input.writer_sink_refs,
        memory_budget_bytes: input.memory_budget_bytes,
        max_parallelism: input.max_parallelism,
        peak_memory_bytes: evidence.peak_memory_bytes,
        memory_pressure_status: "bounded_by_local_cold_preparation_memory_budget".to_string(),
        sink_pressure_status: if input.result_sink_requested {
            "bounded_by_result_sink_replay_requirement".to_string()
        } else {
            "workspace_safe_local_vortex_sink_only".to_string()
        },
        retry_idempotency_status: "task_ids_and_manifest_digest_are_replay_stable".to_string(),
        materialization_boundary_status: input.materialization_boundary_status,
        decode_boundary_status: input.decode_boundary_status,
        native_io_certificate_status: input.native_io_certificate_status,
        native_io_certificate_refs: input.native_io_certificate_refs,
        execution_certificate_id: evidence.execution_certificate_id,
        execution_certificate_status: evidence.execution_certificate_status.to_string(),
        pulseweave_report: evidence.pulseweave_report,
        correctness_refs: input.correctness_digest,
        no_standalone_lane_status:
            "funnelled_through_vortex_ingest_source_state_to_vortex_prepared_state".to_string(),
        claim_gate_status: "not_claim_grade".to_string(),
        claim_boundary: "Scoped local capillary cold-preparation evidence only: task boundaries and PulseWeave control are tied to vortex_ingest writer/reopen certificates; no object-store, distributed, broad parallel performance, production, SQL/DataFrame, or Spark-replacement claim".to_string(),
        fallback_attempted: input.fallback_attempted,
        external_engine_invoked: input.external_engine_invoked,
    }
}

#[must_use]
pub fn should_activate_capillary(
    input: &VortexCapillaryPreparationInput,
) -> VortexCapillaryActivation {
    let observed_split_count = capillary_source_split_count(&input.source_split_refs);
    let row_column_product = input.row_count.saturating_mul(input.column_count as u64);
    let estimated_peak_memory_bytes = input
        .source_byte_count
        .saturating_add(row_column_product.saturating_mul(8))
        .max(1);
    let memory_pressure_threshold = input
        .memory_budget_bytes
        .saturating_div(VORTEX_CAPILLARY_ACTIVATION_MEMORY_PRESSURE_DENOMINATOR)
        .max(1);
    let reason = if input.capillary_claim_evidence_requested {
        "capillary_claim_evidence_requested"
    } else if input.result_sink_requested || input.result_sink_replay_verified {
        "result_sink_replay_requested"
    } else if input.source_byte_count >= VORTEX_CAPILLARY_ACTIVATION_THRESHOLD_BYTES {
        "source_bytes_above_threshold"
    } else if input.row_count >= VORTEX_CAPILLARY_ACTIVATION_THRESHOLD_ROWS {
        "row_count_above_threshold"
    } else if observed_split_count >= VORTEX_CAPILLARY_ACTIVATION_THRESHOLD_SPLITS {
        "split_count_above_threshold"
    } else if input.column_count >= VORTEX_CAPILLARY_ACTIVATION_THRESHOLD_COLUMNS {
        "wide_source_above_threshold"
    } else if row_column_product >= VORTEX_CAPILLARY_ACTIVATION_THRESHOLD_ROW_COLUMN_PRODUCT {
        "row_column_product_above_threshold"
    } else if estimated_peak_memory_bytes >= memory_pressure_threshold {
        "memory_pressure_above_threshold"
    } else if capillary_complex_operation_class(&input.operation_class) {
        "operation_class_above_threshold"
    } else {
        "below_threshold_small_local_fixture"
    };
    VortexCapillaryActivation {
        activated: reason != "below_threshold_small_local_fixture",
        reason,
        observed_split_count,
        estimated_peak_memory_bytes,
    }
}

fn skipped_vortex_capillary_preparation_report(
    input: VortexCapillaryPreparationInput,
    activation: VortexCapillaryActivation,
) -> VortexCapillaryPreparationReport {
    VortexCapillaryPreparationReport {
        schema_version: VORTEX_CAPILLARY_PREPARATION_SCHEMA_VERSION,
        status: "not_requested_below_threshold".to_string(),
        route: "vortex_ingest_source_state_to_prepared_state".to_string(),
        activation_policy: VORTEX_CAPILLARY_ACTIVATION_POLICY.to_string(),
        activation_result: "skipped".to_string(),
        activation_reason: activation.reason.to_string(),
        activation_threshold_bytes: VORTEX_CAPILLARY_ACTIVATION_THRESHOLD_BYTES,
        activation_threshold_rows: VORTEX_CAPILLARY_ACTIVATION_THRESHOLD_ROWS,
        activation_threshold_splits: VORTEX_CAPILLARY_ACTIVATION_THRESHOLD_SPLITS,
        activation_threshold_columns: VORTEX_CAPILLARY_ACTIVATION_THRESHOLD_COLUMNS,
        activation_observed_bytes: input.source_byte_count,
        activation_observed_rows: input.row_count,
        activation_observed_columns: input.column_count,
        activation_observed_split_count: activation.observed_split_count,
        activation_estimated_peak_memory_bytes: activation.estimated_peak_memory_bytes,
        activation_format_family: input.format_family,
        activation_operation_class: input.operation_class,
        activation_certification_depth: input.certification_depth,
        activation_result_sink_replay_requested: input.result_sink_requested
            || input.result_sink_replay_verified,
        source_surface: input.source_surface,
        sink_surface: input.sink_surface,
        source_state_id: input.source_state_id,
        source_state_digest: input.source_state_digest,
        prepared_state_id: input.prepared_state_id,
        prepared_state_digest: input.prepared_state_digest,
        task_manifest_id: "none".to_string(),
        task_manifest_digest: "none".to_string(),
        task_count: 0,
        task_roles: "none".to_string(),
        task_ids: "none".to_string(),
        execution_window_count: 0,
        execution_window_size: 0,
        execution_window_ids: "none".to_string(),
        execution_window_task_counts: "none".to_string(),
        execution_window_task_ids: "none".to_string(),
        execution_window_digests: "none".to_string(),
        scheduler_applied: false,
        scheduler_application_reason: "not_requested_below_threshold".to_string(),
        source_split_refs: input.source_split_refs,
        read_chunk_byte_range_refs: "none".to_string(),
        row_range_refs: "none".to_string(),
        projection_mask: input.projection_mask,
        filter_mask_status: input.filter_mask_status,
        vortex_segment_refs: "none".to_string(),
        writer_sink_refs: input.writer_sink_refs,
        memory_budget_bytes: input.memory_budget_bytes,
        max_parallelism: input.max_parallelism,
        peak_memory_bytes: 0,
        memory_pressure_status: "not_requested_below_threshold".to_string(),
        sink_pressure_status: "not_requested_below_threshold".to_string(),
        retry_idempotency_status: "not_requested".to_string(),
        materialization_boundary_status: input.materialization_boundary_status,
        decode_boundary_status: input.decode_boundary_status,
        native_io_certificate_status: input.native_io_certificate_status,
        native_io_certificate_refs: input.native_io_certificate_refs,
        execution_certificate_id: "none".to_string(),
        execution_certificate_status: "not_requested".to_string(),
        pulseweave_report: PulseWeaveReport::not_requested(
            "vortex_cold_preparation_local_capillary_io",
            activation.reason,
            input.fallback_attempted,
            input.external_engine_invoked,
        ),
        correctness_refs: input.correctness_digest,
        no_standalone_lane_status:
            "not_requested_below_threshold_no_standalone_lane".to_string(),
        claim_gate_status: "not_claim_grade".to_string(),
        claim_boundary: "Scoped local capillary cold-preparation evidence was not required by the dynamic size/complexity gate; no PulseWeave planning, object-store, distributed, broad parallel performance, production, SQL/DataFrame, or Spark-replacement claim".to_string(),
        fallback_attempted: input.fallback_attempted,
        external_engine_invoked: input.external_engine_invoked,
    }
}

fn capillary_preparation_tasks(
    input: &VortexCapillaryPreparationInput,
) -> Vec<VortexCapillaryPreparationTask> {
    let source_bytes = input.source_byte_count.max(1);
    let write_bytes = input.prepared_artifact_digest.len() as u64 + source_bytes.min(64 * 1024);
    vec![
        capillary_task(
            "source-split-discovery",
            "source_split_discovery",
            OperatorMemoryClass::Scan,
            4 * 1024,
            input,
        ),
        capillary_task(
            "read-chunk",
            "read_chunk",
            OperatorMemoryClass::Scan,
            source_bytes,
            input,
        ),
        capillary_task(
            "columnarize-encode",
            "columnarize_encode",
            OperatorMemoryClass::Translation,
            source_bytes.saturating_add(input.row_count.saturating_mul(8)),
            input,
        ),
        capillary_task(
            "vortex-segment-write",
            "vortex_segment_write",
            OperatorMemoryClass::Sink,
            write_bytes,
            input,
        ),
        capillary_task(
            "reopen-verify",
            "reopen_verify",
            OperatorMemoryClass::Scan,
            write_bytes.saturating_div(2).max(1),
            input,
        ),
        capillary_task(
            "sink-evidence",
            "sink_evidence",
            OperatorMemoryClass::Sink,
            4 * 1024,
            input,
        ),
    ]
}

fn capillary_task(
    suffix: &str,
    role: &'static str,
    operator_memory_class: OperatorMemoryClass,
    estimated_memory_bytes: u64,
    input: &VortexCapillaryPreparationInput,
) -> VortexCapillaryPreparationTask {
    VortexCapillaryPreparationTask {
        task_id: format!("vortex-capillary-{suffix}"),
        role,
        operator_memory_class,
        byte_range_ref: input.source_byte_range_refs.clone(),
        row_range_ref: input.source_row_range_refs.clone(),
        vortex_segment_ref: input.prepared_artifact_segment_refs.clone(),
        writer_sink_ref: input.writer_sink_refs.clone(),
        estimated_memory_bytes: estimated_memory_bytes.max(1),
    }
}

fn capillary_pulseweave_report(
    input: &VortexCapillaryPreparationInput,
    tasks: &[VortexCapillaryPreparationTask],
    peak_memory_bytes: u64,
    execution_certificate_id: &str,
    execution_certificate_status: &str,
) -> Result<PulseWeaveReport> {
    let task_shapes = tasks
        .iter()
        .map(VortexCapillaryPreparationTask::to_pulseweave_shape)
        .collect::<Result<Vec<_>>>()?;
    let target_task_bytes = input.source_byte_count.max(
        input
            .row_count
            .saturating_mul(input.column_count as u64)
            .max(1),
    );
    let pulseweave_input = PulseWeaveInput::new(
        "vortex_ingest_cold_preparation",
        "vortex_cold_preparation_local_capillary_io",
        format!("vortex_ingest:{}", input.source_state_digest),
        task_shapes,
        input.memory_budget_bytes.max(1),
        input.max_parallelism.max(1),
        target_task_bytes,
    )?
    .with_task_byte_limits(4 * 1024, target_task_bytes.saturating_mul(4).max(4 * 1024))
    .with_boundaries(true, true)
    .with_result_sink(
        input.result_sink_requested,
        input.result_sink_replay_verified,
    )
    .with_correctness_and_output(&input.correctness_digest, &input.prepared_artifact_digest)
    .with_execution_certificate(execution_certificate_id, execution_certificate_status)
    .with_native_io_certificate_status(input.native_io_certificate_status.clone())
    .with_memory_observations(tasks.len(), tasks.len(), 0, peak_memory_bytes)
    .with_spill(false, false)
    .with_no_fallback_policy(
        false,
        input.fallback_attempted,
        input.external_engine_invoked,
    );
    plan_pulseweave(pulseweave_input)
}

fn capillary_status(
    input: &VortexCapillaryPreparationInput,
    tasks: &[VortexCapillaryPreparationTask],
    pulseweave_report: &PulseWeaveReport,
) -> &'static str {
    if tasks.is_empty() || missing_capillary_task_manifest(&input.source_split_refs) {
        "blocked_missing_capillary_task_manifest"
    } else if input.native_io_certificate_status != "certified" {
        "report_only_blocked_missing_native_io_certificate"
    } else if pulseweave_report.runtime_decision_applied {
        "applied_capillary_pulseweave_control"
    } else {
        "report_only_blocked_pulseweave_control"
    }
}

fn capillary_scheduler_applied(
    input: &VortexCapillaryPreparationInput,
    tasks: &[VortexCapillaryPreparationTask],
    pulseweave_report: &PulseWeaveReport,
) -> bool {
    !tasks.is_empty()
        && !missing_capillary_task_manifest(&input.source_split_refs)
        && input.native_io_certificate_status == "certified"
        && pulseweave_report.runtime_decision_applied
}

fn capillary_scheduler_application_reason(
    input: &VortexCapillaryPreparationInput,
    tasks: &[VortexCapillaryPreparationTask],
    pulseweave_report: &PulseWeaveReport,
) -> &'static str {
    if tasks.is_empty() {
        "no_capillary_tasks"
    } else if missing_capillary_task_manifest(&input.source_split_refs) {
        "blocked_missing_capillary_task_manifest"
    } else if input.native_io_certificate_status != "certified" {
        "blocked_missing_native_io_certificate"
    } else if pulseweave_report.runtime_decision_applied {
        "pulseweave_batch_window_applied_to_capillary_manifest"
    } else {
        "proofbound_or_resource_policy_blocked"
    }
}

fn capillary_execution_windows(
    tasks: &[VortexCapillaryPreparationTask],
    scheduler_applied: bool,
    execution_window_size: usize,
) -> Vec<VortexCapillaryExecutionWindow> {
    if !scheduler_applied || tasks.is_empty() || execution_window_size == 0 {
        return Vec::new();
    }

    tasks
        .chunks(execution_window_size.max(1))
        .enumerate()
        .map(|(index, window_tasks)| {
            let window_id = format!("vortex-capillary-window-{index:04}");
            let task_ids = window_tasks
                .iter()
                .map(|task| task.task_id.clone())
                .collect::<Vec<_>>();
            let window_digest = fnv64_digest_text(&format!(
                "{}|{}|{}",
                window_id,
                execution_window_size,
                task_ids.join("|")
            ));
            VortexCapillaryExecutionWindow {
                window_id,
                task_count: task_ids.len(),
                task_ids,
                window_digest,
            }
        })
        .collect()
}

fn missing_capillary_task_manifest(source_split_refs: &str) -> bool {
    let source_split_refs = source_split_refs.trim();
    source_split_refs.is_empty() || source_split_refs.eq_ignore_ascii_case("none")
}

fn capillary_source_split_count(source_split_refs: &str) -> usize {
    if missing_capillary_task_manifest(source_split_refs) {
        return 0;
    }
    source_split_refs
        .split(';')
        .filter(|value| {
            let value = value.trim();
            !value.is_empty() && !value.eq_ignore_ascii_case("none")
        })
        .count()
        .max(1)
}

fn capillary_complex_operation_class(operation_class: &str) -> bool {
    let operation_class = operation_class.to_ascii_lowercase();
    [
        "prepare-batch",
        "prepare_batch",
        "many-small-files",
        "many_small_files",
        "stress",
        "cdc",
        "shuffle",
        "join",
        "group",
        "window",
        "wide",
        "null-heavy",
        "null_heavy",
        "high-cardinality",
        "high_cardinality",
    ]
    .iter()
    .any(|needle| operation_class.contains(needle))
}

fn join_task_values(
    tasks: &[VortexCapillaryPreparationTask],
    mut value: impl FnMut(&VortexCapillaryPreparationTask) -> String,
) -> String {
    tasks.iter().map(&mut value).collect::<Vec<_>>().join(",")
}

fn join_window_values(
    windows: &[VortexCapillaryExecutionWindow],
    mut value: impl FnMut(&VortexCapillaryExecutionWindow) -> String,
) -> String {
    if windows.is_empty() {
        "none".to_string()
    } else {
        windows.iter().map(&mut value).collect::<Vec<_>>().join(";")
    }
}

#[cfg(feature = "vortex-write")]
fn capillary_role_list_contains(roles: &str, role: &str) -> bool {
    roles
        .split(',')
        .any(|candidate| candidate.trim().eq_ignore_ascii_case(role))
}

/// Evidence returned by the scoped local `vortex_ingest` helper.
#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct VortexPreparedStateWriteReport {
    pub target_path: PathBuf,
    pub row_count: u64,
    pub column_count: usize,
    pub column_families: Vec<(String, String)>,
    pub bytes_written: u64,
    pub artifact_digest: String,
    pub artifact_digest_source: String,
    pub digest_micros: u128,
    pub writer_row_count: u64,
    pub reopen_row_count: u64,
    pub array_build_micros: u128,
    pub stream_source_pull_micros: u128,
    pub stream_decode_micros: u128,
    pub stream_derived_metadata_build_micros: u128,
    pub stream_array_convert_micros: u128,
    pub stream_timing_split_status: String,
    pub stage_work: VortexIngestStageReport,
    pub shared_native_memory: Option<VortexIngestMemoryOwnershipReport>,
    pub write_micros: u128,
    pub writer_context_open_micros: u128,
    pub writer_context_reuse_status: String,
    pub writer_layout_strategy_applied: String,
    pub writer_coalescing_policy_status: String,
    pub writer_layout_row_block_size: usize,
    pub writer_layout_block_target_bytes: u64,
    pub writer_compression_policy: String,
    pub writer_compression_concurrency: usize,
    pub writer_stats_concurrency: usize,
    pub writer_runtime_kind: String,
    pub writer_runtime_requested_parallelism: usize,
    pub writer_runtime_applied_parallelism: usize,
    pub writer_runtime_background_workers: usize,
    pub writer_profile_selection_reason: String,
    pub writer_profile_regression_guard: String,
    pub vortex_segment_write_micros: u128,
    pub vortex_compression_micros: u128,
    pub vortex_encode_write_micros: u128,
    pub workspace_stage_micros: u128,
    pub vortex_final_commit_micros: u128,
    pub reopen_scan_micros: u128,
    pub reopen_verification_status: String,
    pub timing_scope: String,
    pub certification_level: String,
    pub preparation_included: bool,
    pub query_timing_starts_after_preparation: bool,
    pub upstream_vortex_write_called: bool,
    pub upstream_vortex_scan_called: bool,
    pub array_build_provider_kind: String,
    pub array_build_provider_surface: String,
    pub array_build_strategy: String,
    pub array_build_prefetch_window: usize,
    pub array_build_input_layout: String,
    pub array_build_record_batch_count: usize,
    pub manual_scalar_copy_avoided: bool,
    pub preparation_spine: VortexPreparationSpineReport,
    pub writer_physical_design: VortexWriterPhysicalDesignPlan,
    pub layout_write_decision: VortexLayoutWriteRuntimeDecision,
    pub capillary_prewrite_control: VortexCapillaryPreWriteControlReport,
    pub prepared_olap_layout_inventory: VortexPreparedOlapLayoutInventory,
    pub segment_metadata_primitive: VortexSegmentMetadataPrimitiveReport,
    pub workspace_write_report: WorkspaceSafeLocalWriteReport,
}

/// Scoped allocation ownership evidence, not a process-RSS or all-provider cap.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VortexIngestMemoryOwnershipReport {
    pub limit_bytes: u64,
    pub peak_reserved_bytes: u64,
    pub final_reserved_bytes: u64,
    pub denied_reservations: u64,
    /// Theoretical nonempty-batch upper bound if only root references occupied
    /// the shared budget. Native payloads and transient Vec growth also compete
    /// for that budget; empty batches do not consume a root reference.
    pub max_source_batches: usize,
}

impl VortexIngestMemoryOwnershipReport {
    #[must_use]
    pub fn evidence_fields(&self) -> Vec<(String, String)> {
        vec![
            ("vortex_shared_native_memory_scope".into(), "copied_native_input_buffers;prefetch_admission;native_host_allocator;root_layout_references".into()),
            ("vortex_shared_native_memory_exclusions".into(), "original_source_and_arrow_input_owners_until_conversion;source_reader_internals;codec_and_metadata_allocations_bypassing_host_allocator;process_rss".into()),
            ("vortex_shared_native_memory_limit_bytes".into(), self.limit_bytes.to_string()),
            ("vortex_shared_native_memory_peak_reserved_bytes".into(), self.peak_reserved_bytes.to_string()),
            ("vortex_shared_native_memory_final_reserved_bytes".into(), self.final_reserved_bytes.to_string()),
            ("vortex_shared_native_memory_denied_reservations".into(), self.denied_reservations.to_string()),
            ("vortex_shared_native_memory_max_source_batches".into(), self.max_source_batches.to_string()),
            ("vortex_opaque_arrow_owner_policy".into(), "all_imported_arrow_buffers_copy_referenced_regions_into_admitted_native_storage".into()),
            ("vortex_native_memory_physical_policy".into(), "one_source_batch_subtree_at_a_time;local_child_eof;no_cross_batch_coalescing_or_dictionary_domain".into()),
        ]
    }
}

impl VortexPreparedStateWriteReport {
    /// Return a stable comma-separated column family summary.
    #[must_use]
    pub fn column_family_summary(&self) -> String {
        self.column_families
            .iter()
            .map(|(column, family)| format!("{column}:{family}"))
            .collect::<Vec<_>>()
            .join(",")
    }

    /// Return a compact schema/layout summary for evidence fields.
    #[must_use]
    pub fn layout_summary(&self) -> String {
        format!(
            "local_flat_struct;columns={};rows={}",
            self.column_count, self.row_count
        )
    }

    /// Return a compact encoding summary for evidence fields.
    #[must_use]
    pub fn encoding_summary(&self) -> String {
        format!(
            "upstream_vortex_writer={};coalescing_policy={};physical_design_digest={};row_block_size={};block_target_bytes={};compression_policy={};compression_field_count={};compression_fields={};compression_decision_count={};compression_decisions={};compression_concurrency={};stats_concurrency={};writer_runtime={};writer_runtime_parallelism={};writer_runtime_workers={};profile_reason={};regression_guard={};{}",
            self.writer_layout_strategy_applied,
            self.writer_coalescing_policy_status,
            self.writer_physical_design.strategy_decision_digest,
            self.writer_layout_row_block_size,
            self.writer_layout_block_target_bytes,
            self.writer_compression_policy,
            self.writer_compression_field_count(),
            self.writer_compression_field_names(),
            self.writer_compression_decision_count(),
            self.writer_compression_decisions(),
            self.writer_compression_concurrency,
            self.writer_stats_concurrency,
            self.writer_runtime_kind,
            self.writer_runtime_applied_parallelism,
            self.writer_runtime_background_workers,
            self.writer_profile_selection_reason,
            self.writer_profile_regression_guard,
            self.column_family_summary()
        )
    }

    /// Return the number of source fields with an explicit compression override.
    #[must_use]
    #[cfg(feature = "vortex-write")]
    pub fn writer_compression_field_count(&self) -> usize {
        if vortex_writer_uses_large_source_text(&self.layout_write_decision) {
            self.layout_write_decision
                .writer_compression_field_names
                .len()
        } else {
            0
        }
    }

    /// Return the number of source fields with an explicit compression override.
    #[must_use]
    #[cfg(not(feature = "vortex-write"))]
    pub const fn writer_compression_field_count(&self) -> usize {
        0
    }

    /// Return a stable comma-separated list of source fields with compression overrides.
    #[must_use]
    #[cfg(feature = "vortex-write")]
    pub fn writer_compression_field_names(&self) -> String {
        if vortex_writer_uses_large_source_text(&self.layout_write_decision) {
            self.layout_write_decision
                .writer_compression_field_names
                .join(",")
        } else {
            "none".to_string()
        }
    }

    /// Return a stable comma-separated list of source fields with compression overrides.
    #[must_use]
    #[cfg(not(feature = "vortex-write"))]
    pub fn writer_compression_field_names(&self) -> String {
        "none".to_string()
    }

    /// Return the number of column compression decisions attached to the writer policy.
    #[must_use]
    #[cfg(feature = "vortex-write")]
    pub fn writer_compression_decision_count(&self) -> usize {
        if vortex_layout_write_strategy_applies(&self.layout_write_decision) {
            self.layout_write_decision
                .writer_compression_field_decisions
                .len()
        } else {
            0
        }
    }

    /// Return the number of column compression decisions attached to the writer policy.
    #[must_use]
    #[cfg(not(feature = "vortex-write"))]
    pub const fn writer_compression_decision_count(&self) -> usize {
        0
    }

    /// Return a stable list of per-column compression decisions for evidence.
    #[must_use]
    #[cfg(feature = "vortex-write")]
    pub fn writer_compression_decisions(&self) -> String {
        if vortex_layout_write_strategy_applies(&self.layout_write_decision)
            && !self
                .layout_write_decision
                .writer_compression_field_decisions
                .is_empty()
        {
            self.layout_write_decision
                .writer_compression_field_decisions
                .join("|")
        } else {
            "none".to_string()
        }
    }

    /// Return a stable list of per-column compression decisions for evidence.
    #[must_use]
    #[cfg(not(feature = "vortex-write"))]
    pub fn writer_compression_decisions(&self) -> String {
        "none".to_string()
    }

    /// Return a compact statistics summary for evidence fields.
    #[must_use]
    pub fn statistics_summary(&self) -> String {
        format!(
            "writer_row_count={};reopen_row_count={};reopen_verification_status={};bytes_written={};layout_inventory_status={};footer_statistics_status={};footer_segment_count={};layout_root={};layout_encodings={};domain_dictionary_status={}",
            self.writer_row_count,
            self.reopen_row_count,
            self.reopen_verification_status,
            self.bytes_written,
            self.prepared_olap_layout_inventory.status,
            self.prepared_olap_layout_inventory.statistics_status,
            self.prepared_olap_layout_inventory.segment_count_field(),
            self.prepared_olap_layout_inventory.root_layout_encoding,
            self.prepared_olap_layout_inventory
                .layout_encoding_inventory,
            self.prepared_olap_layout_inventory.domain_dictionary_status
        )
    }

    /// Return a compact single-artifact OLAP layout inventory summary.
    #[must_use]
    pub fn prepared_olap_layout_inventory_summary(&self) -> String {
        format!(
            "status={};row_count={};segment_count={};statistics={};encoding_layout={};artifact_bytes={};footer_bytes={};root_layout={};layout_encodings={};segment_membership={};domain_dictionary={};derived_stats={};row_position_locality={};layout_reader_cache={};persisted_in_artifact={};size_attribution={};digest={}",
            self.prepared_olap_layout_inventory.status,
            self.prepared_olap_layout_inventory.row_count_field(),
            self.prepared_olap_layout_inventory.segment_count_field(),
            self.prepared_olap_layout_inventory.statistics_status,
            self.prepared_olap_layout_inventory.encoding_layout_status,
            self.prepared_olap_layout_inventory
                .artifact_size_bytes_field(),
            self.prepared_olap_layout_inventory
                .approx_footer_bytes_field(),
            self.prepared_olap_layout_inventory.root_layout_encoding,
            self.prepared_olap_layout_inventory
                .layout_encoding_inventory,
            self.prepared_olap_layout_inventory
                .segment_membership_status,
            self.prepared_olap_layout_inventory.domain_dictionary_status,
            self.prepared_olap_layout_inventory
                .derived_layout_stats_status,
            self.prepared_olap_layout_inventory
                .row_position_locality_status,
            self.prepared_olap_layout_inventory
                .layout_reader_cache_status,
            self.prepared_olap_layout_inventory
                .metadata_persisted_in_artifact,
            self.prepared_olap_layout_inventory.layout_size_attribution,
            self.prepared_olap_layout_inventory.inventory_digest,
        )
    }
}

/// Whether local Vortex artifact writing is compiled into this crate.
#[must_use]
pub const fn vortex_ingest_write_feature_enabled() -> bool {
    cfg!(feature = "vortex-write")
}

/// Write flat scalar rows into a local Vortex artifact and reopen it for row-count proof.
///
/// # Errors
/// Returns [`ShardLoomError::InvalidOperation`] when the feature gate is not
/// enabled, row shape/family support is outside the scoped contract, the target
/// already exists without overwrite permission, or upstream Vortex write/reopen
/// APIs fail.
#[cfg(not(feature = "vortex-write"))]
pub fn write_flat_scalar_vortex_prepared_state(
    _request: VortexPreparedStateWriteRequest,
) -> Result<VortexPreparedStateWriteReport> {
    Err(ShardLoomError::InvalidOperation(
        "local vortex_ingest runtime requires building shardloom-cli with --features vortex-write; default builds expose vortex_ingest as a deterministic blocked prepare-once route"
            .to_string(),
    ))
}

/// Write flat scalar rows into a local Vortex artifact and reopen/scan it.
///
/// # Errors
/// Returns [`ShardLoomError::InvalidOperation`] when row shape/family support is
/// outside the scoped contract, the target already exists without overwrite
/// permission, or upstream Vortex write/reopen APIs fail.
#[cfg(feature = "vortex-write")]
pub fn write_flat_scalar_vortex_prepared_state(
    request: VortexPreparedStateWriteRequest,
) -> Result<VortexPreparedStateWriteReport> {
    if request.certification_level == VortexIngestCertificationLevel::IngestFullReplay {
        return Err(ShardLoomError::InvalidOperation(
            "local vortex_ingest ingest_full_replay requires downstream result replay/output evidence; use ingest_certified for prepare-once proof or run an output/replay workflow; no fallback execution was attempted"
                .to_string(),
        ));
    }

    let row_count = validate_flat_rows(&request.columns, &request.rows)?;
    let column_families =
        scalar_column_families(&request.columns, &request.column_dtypes, &request.rows)?;
    let typed_complex_output = scalar_column_families_include_typed_complex(&column_families);
    let (expected_provider_kind, expected_provider_surface) = if typed_complex_output {
        ("vortex_array_kernel", "ArrayRef::from_arrow(RecordBatch)")
    } else {
        ("shardloom_kernel", "shardloom_scalar_rows_to_vortex_struct")
    };
    let layout_write_decision = admit_layout_write_runtime_decision_for_source(
        request.layout_write_advisor.as_ref(),
        expected_provider_kind,
        expected_provider_surface,
        &request.target_path,
        request.certification_level,
        VortexWriterPhysicalDesignSourceInput::scalar(row_count),
    )?;
    prepare_vortex_target(&request.target_path, request.allow_overwrite)?;
    let mut capillary_prewrite_control =
        plan_capillary_prewrite_control(request.capillary_prewrite_input.as_ref())?;
    capillary_prewrite_control
        .apply_task_role_gate("source_split_discovery", "source_split_discovery")?;
    capillary_prewrite_control.apply_task_role_gate("read_chunk", "read_chunk")?;
    capillary_prewrite_control.apply_task_role_gate("columnarize_encode", "array_build")?;
    let array_build_start = Instant::now();
    let array_build = flat_rows_to_vortex_struct(
        &request.columns,
        &request.column_dtypes,
        #[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
        &request.column_arrow_dtypes,
        &request.rows,
        &column_families,
    )?;
    let array_build_micros = array_build_start.elapsed().as_micros();
    finalize_vortex_prepared_state_write(VortexPreparedStateFinalizeInput {
        target_path: request.target_path,
        column_count: request.columns.len(),
        column_families,
        row_count,
        array: &array_build.array,
        array_build_micros,
        certification_level: request.certification_level,
        allow_overwrite: request.allow_overwrite,
        array_build_provider_kind: array_build.provider_kind,
        array_build_provider_surface: array_build.provider_surface,
        array_build_strategy: array_build.strategy,
        array_build_prefetch_window: 0,
        array_build_input_layout: array_build.input_layout,
        array_build_record_batch_count: array_build.record_batch_count,
        manual_scalar_copy_avoided: array_build.manual_scalar_copy_avoided,
        capillary_prewrite_control,
        layout_write_decision,
        preparation_spine: VortexPreparationSpineFinalizeInput {
            vortex_first_decision: array_build.vortex_first_decision,
            feature_gate: array_build.feature_gate,
            source_surface: array_build.source_surface,
            split_surface: "single_materialized_scalar_row_split",
            split_count: usize::from(row_count > 0),
            projection_mask_status: "full_projection_materialized",
            filter_mask_status: "not_requested",
            materialization_boundary_status: array_build.materialization_boundary_status,
            decode_boundary_status: array_build.decode_boundary_status,
        },
    })
}

/// Write flat columnar Arrow batches into a local Vortex artifact and
/// reopen/scan it.
///
/// # Errors
/// Returns [`ShardLoomError::InvalidOperation`] when columnar support is outside
/// the scoped contract, the target already exists without overwrite
/// permission, or upstream Vortex write/reopen APIs fail.
#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
pub fn write_flat_columnar_vortex_prepared_state(
    request: VortexPreparedStateColumnarWriteRequest,
) -> Result<VortexPreparedStateWriteReport> {
    if request.certification_level == VortexIngestCertificationLevel::IngestFullReplay {
        return Err(ShardLoomError::InvalidOperation(
            "local vortex_ingest ingest_full_replay requires downstream result replay/output evidence; use ingest_certified for prepare-once proof or run an output/replay workflow; no fallback execution was attempted"
                .to_string(),
        ));
    }

    let source_shape = validate_flat_columnar_source_shape(&request.source)?;
    let (expected_provider_kind, expected_provider_surface) = if request.source.batches.is_empty() {
        (
            "shardloom_kernel",
            "shardloom_empty_columnar_struct_builder",
        )
    } else {
        ("vortex_array_kernel", "ArrayRef::from_arrow(RecordBatch)")
    };
    let layout_write_decision = admit_layout_write_runtime_decision_for_source(
        request.layout_write_advisor.as_ref(),
        expected_provider_kind,
        expected_provider_surface,
        &request.target_path,
        request.certification_level,
        VortexWriterPhysicalDesignSourceInput::buffered_columnar(request.source.batches.len()),
    )?;
    prepare_vortex_target(&request.target_path, request.allow_overwrite)?;
    let mut capillary_prewrite_control =
        plan_capillary_prewrite_control(request.capillary_prewrite_input.as_ref())?;
    capillary_prewrite_control
        .apply_task_role_gate("source_split_discovery", "source_split_discovery")?;
    capillary_prewrite_control.apply_task_role_gate("read_chunk", "read_chunk")?;
    capillary_prewrite_control.apply_task_role_gate("columnarize_encode", "array_build")?;
    let array_build_start = Instant::now();
    let array_build = flat_columnar_source_to_vortex_struct(&request.source, &source_shape)?;
    let array_build_micros = array_build_start.elapsed().as_micros();
    let row_count = usize_to_u64(request.source.row_count)?;
    let projection_mask_status =
        if request.source.materialized_columns.len() < request.source.header.len() {
            "columnar_projection_mask_applied"
        } else {
            "full_projection"
        };
    let (vortex_first_decision, materialization_boundary_status, decode_boundary_status) =
        if array_build.manual_scalar_copy_avoided {
            (
                "use_vortex_native_provider",
                "columnar_source_state_preserved_to_vortex_array_provider",
                "no_scalar_row_decode_for_non_empty_batches",
            )
        } else {
            (
                "implement_shardloom_kernel",
                "empty_columnar_schema_materialized_by_shardloom_kernel",
                "empty_source_no_data_decode",
            )
        };
    finalize_vortex_prepared_state_write(VortexPreparedStateFinalizeInput {
        target_path: request.target_path,
        column_count: request.source.materialized_columns.len(),
        column_families: array_build.column_families,
        row_count,
        array: &array_build.array,
        array_build_micros,
        certification_level: request.certification_level,
        allow_overwrite: request.allow_overwrite,
        array_build_provider_kind: array_build.provider_kind,
        array_build_provider_surface: array_build.provider_surface,
        array_build_strategy: array_build.strategy,
        array_build_prefetch_window: 0,
        array_build_input_layout: "arrow_record_batch_columnar_source_state",
        array_build_record_batch_count: request.source.batches.len(),
        manual_scalar_copy_avoided: array_build.manual_scalar_copy_avoided,
        capillary_prewrite_control,
        layout_write_decision,
        preparation_spine: VortexPreparationSpineFinalizeInput {
            vortex_first_decision,
            feature_gate: "vortex-write,universal-format-io",
            source_surface: "local_columnar_source_state_arrow_record_batches",
            split_surface: "arrow_record_batch_source_splits",
            split_count: request.source.batches.len(),
            projection_mask_status,
            filter_mask_status: "not_requested",
            materialization_boundary_status,
            decode_boundary_status,
        },
    })
}

/// Stream flat columnar Arrow batches into a local Vortex artifact and
/// reopen/scan it.
///
/// # Errors
/// Returns [`ShardLoomError::InvalidOperation`] when columnar support is outside
/// the scoped contract, the target already exists without overwrite
/// permission, or upstream Vortex write/reopen APIs fail.
#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
#[allow(clippy::too_many_lines)]
pub fn write_flat_columnar_vortex_prepared_state_streaming(
    request: VortexPreparedStateColumnarStreamWriteRequest,
) -> Result<VortexPreparedStateWriteReport> {
    if let Some(binding) = &request.prepared_source_binding {
        #[cfg(unix)]
        crate::prepared_source_binding::validate(binding)?;
        #[cfg(not(unix))]
        return Err(ShardLoomError::InvalidOperation(format!(
            "prepared source binding requires Unix generation admission ({} bytes); no fallback execution was attempted",
            binding.len()
        )));
    }
    if request.certification_level == VortexIngestCertificationLevel::IngestFullReplay {
        return Err(ShardLoomError::InvalidOperation(
            "local vortex_ingest ingest_full_replay requires downstream result replay/output evidence; use ingest_certified for prepare-once proof or run an output/replay workflow; no fallback execution was attempted"
                .to_string(),
        ));
    }

    let source_shape = validate_flat_columnar_stream_source_shape(&request.source)?;
    let column_families = columnar_column_families_from_schema(&source_shape)?;
    let mut writer_physical_design_source =
        VortexWriterPhysicalDesignSourceInput::streaming_columnar(&request.source)?;
    let ingest_runtime = request.source.ingest_runtime.clone();
    let _drivers = ingest_runtime
        .as_ref()
        .map(crate::ingest_runtime::IngestRuntime::start_drivers)
        .transpose()?;
    let native_memory = request
        .shared_native_memory_budget_bytes
        .map(|bytes| NativeIngestMemory::with_runtime(bytes, ingest_runtime.as_ref()))
        .transpose()?;
    let mut first_input_lease = native_memory
        .as_ref()
        .map(|memory| memory.reserve_input(1))
        .transpose()?;
    let mut capillary_prewrite_control =
        plan_capillary_prewrite_control(request.capillary_prewrite_input.as_ref())?;
    capillary_prewrite_control
        .apply_task_role_gate("source_split_discovery", "source_split_discovery")?;
    capillary_prewrite_control.apply_task_role_gate("read_chunk", "read_chunk")?;
    capillary_prewrite_control.apply_task_role_gate("columnarize_encode", "array_build")?;

    let embedded_derived_build_micros = Arc::clone(&request.source.embedded_derived_build_micros);
    let source_identities = request.source.source_identities;
    for identity in &source_identities {
        identity.validate()?;
    }
    let mut reader = request.source.reader;
    let array_build_start = Instant::now();
    let stream_timing = VortexStreamingIngestTiming::with_derived_metadata_build_micros(
        embedded_derived_build_micros,
    );
    let first_source_pull_start = Instant::now();
    let first_batch =
        match next_streaming_record_batch(reader.as_mut(), "streaming local columnar source")? {
            Some(batch) => batch,
            None if native_memory.is_some()
                || ingest_runtime.is_some()
                || !source_identities.is_empty()
                || request.prepared_source_binding.is_some()
                || reader.schema().fields().iter().any(|field| {
                    matches!(
                        field.data_type(),
                        ArrowDataType::List(_)
                            | ArrowDataType::LargeList(_)
                            | ArrowDataType::FixedSizeList(..)
                            | ArrowDataType::Struct(_)
                    )
                }) =>
            {
                RecordBatch::new_empty(reader.schema())
            }
            None => {
                stream_timing.add_source_pull_elapsed(first_source_pull_start.elapsed());
                let empty_source = FlatLocalColumnarSource {
                    header: request.source.header,
                    column_dtypes: request.source.column_dtypes,
                    column_arrow_dtypes: request.source.column_arrow_dtypes,
                    materialized_columns: request.source.materialized_columns,
                    reader_projection_columns: request.source.reader_projection_columns,
                    batches: Vec::new(),
                    row_count: 0,
                };
                let mut empty_request = VortexPreparedStateColumnarWriteRequest::new(
                    &request.target_path,
                    empty_source,
                )
                .allow_overwrite(request.allow_overwrite)
                .certification_level(request.certification_level);
                if let Some(report) = request.layout_write_advisor {
                    empty_request = empty_request.layout_write_advisor(report);
                }
                if let Some(input) = request.capillary_prewrite_input {
                    empty_request = empty_request.capillary_prewrite_input(input);
                }
                return write_flat_columnar_vortex_prepared_state(empty_request);
            }
        };
    stream_timing.add_source_pull_elapsed(first_source_pull_start.elapsed());
    let prefetch_memory_bytes = native_memory.as_ref().map_or_else(
        || {
            request
                .capillary_prewrite_input
                .as_ref()
                .map_or(1024 * 1024 * 1024, |input| {
                    (input.memory_budget_bytes / 4).max(1)
                })
        },
        |memory| (memory.pool.snapshot().limit_bytes / 4).max(1),
    );
    if let Some(lanes) = writer_physical_design_source.cpu_lanes.as_mut() {
        lanes.admit_conversion_memory(
            prefetch_memory_bytes,
            u64::try_from(first_batch.get_array_memory_size()).unwrap_or(u64::MAX),
            native_memory
                .as_ref()
                .map(|_| arrow_ownership::batch_copy_allocation_bytes(&first_batch))
                .transpose()?,
        );
    }
    let first_array_convert_start = Instant::now();
    validate_stream_record_batch_shape_profiled(
        &first_batch,
        &request.source.reader_projection_columns,
        &source_shape,
        1,
        &stream_timing.stages,
    )?;
    let expected_provider_kind = "vortex_array_kernel";
    let underlying_provider_surface = "ArrayRef::from_arrow(RecordBatch);streaming ArrayIterator";
    let layout_write_decision = admit_layout_write_runtime_decision_for_source(
        request.layout_write_advisor.as_ref(),
        expected_provider_kind,
        underlying_provider_surface,
        &request.target_path,
        request.certification_level,
        writer_physical_design_source,
    )?;
    let array_build_prefetch_window = layout_write_decision
        .writer_physical_design
        .array_build_prefetch_window;
    let array_build_worker_count = layout_write_decision
        .writer_physical_design
        .array_build_worker_count;
    let array_build_provider_surface = if array_build_prefetch_window > 0
        && array_build_worker_count > 1
    {
        "ArrayRef::from_arrow(RecordBatch);ordered_morsel_vortex_array_prefetch;streaming ArrayIterator"
    } else if array_build_prefetch_window > 0 {
        "ArrayRef::from_arrow(RecordBatch);capillary_vortex_array_prefetch_window;streaming ArrayIterator"
    } else {
        underlying_provider_surface
    };
    prepare_vortex_target(&request.target_path, request.allow_overwrite)?;
    let first_array = record_batch_to_vortex_from_arrow_provider_profiled_with_memory(
        &first_batch,
        &source_shape,
        &stream_timing.stages,
        native_memory.as_ref().zip(first_input_lease.as_mut()),
    )?;
    drop(first_batch);
    drop(first_input_lease);
    stream_timing.add_array_convert_elapsed(first_array_convert_start.elapsed());
    let dtype = first_array.dtype().clone();
    let batch_count = Arc::new(AtomicUsize::new(1));
    let array_build_strategy = if array_build_prefetch_window > 0 && array_build_worker_count > 1 {
        "ordered_morsel_vortex_array_prefetch_threadlocal_conversion_merge"
    } else if array_build_prefetch_window > 0 {
        "capillary_vortex_array_prefetch_window_from_arrow_record_batch_stream"
    } else {
        "vortex_from_arrow_record_batch_stream"
    };
    let mut stream_iter = StreamingColumnarVortexArrayIterator::with_runtime(
        dtype,
        first_array,
        reader,
        request.source.reader_projection_columns.clone(),
        source_shape.clone(),
        Arc::clone(&batch_count),
        stream_timing.clone(),
        2,
        array_build_prefetch_window,
        array_build_worker_count,
        prefetch_memory_bytes,
        native_memory.clone(),
        ingest_runtime.clone(),
    )?;
    let writer_input_lookahead = stream_iter.share_input_slot_with_writer(&layout_write_decision);
    let array_build_micros = array_build_start.elapsed().as_micros();
    let projection_mask_status =
        if request.source.materialized_columns.len() < request.source.header.len() {
            "columnar_projection_mask_applied"
        } else {
            "full_projection"
        };
    finalize_vortex_prepared_state_stream_write(VortexPreparedStateStreamFinalizeInput {
        target_path: request.target_path,
        prepared_source_binding: request.prepared_source_binding,
        column_count: request.source.materialized_columns.len(),
        column_families,
        row_count_hint: request
            .source
            .row_count_hint
            .map(usize_to_u64)
            .transpose()?,
        array_iterator: stream_iter,
        writer_input_lookahead,
        source_identities,
        native_memory,
        ingest_runtime,
        emitted_record_batch_count: batch_count,
        stream_timing,
        array_build_micros,
        certification_level: request.certification_level,
        allow_overwrite: request.allow_overwrite,
        array_build_provider_kind: expected_provider_kind,
        array_build_provider_surface,
        array_build_strategy,
        array_build_prefetch_window,
        array_build_input_layout: "streaming_arrow_record_batch_columnar_source_state",
        manual_scalar_copy_avoided: true,
        capillary_prewrite_control,
        layout_write_decision,
        preparation_spine: VortexPreparationSpineFinalizeInput {
            vortex_first_decision: "use_vortex_native_provider",
            feature_gate: "vortex-write,universal-format-io",
            source_surface: "streaming_local_columnar_source_state_arrow_record_batches",
            split_surface: "streaming_arrow_record_batch_source_splits",
            split_count: request.source.record_batch_count_hint.unwrap_or(0),
            projection_mask_status,
            filter_mask_status: "not_requested",
            materialization_boundary_status: "streaming_columnar_source_state_preserved_to_vortex_array_provider",
            decode_boundary_status: "no_scalar_row_decode_for_streamed_batches",
        },
    })
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
#[derive(Debug, Clone, PartialEq, Eq)]
struct ColumnarProjectedColumn {
    column: String,
    reader_index: usize,
    dtype_hint: Option<LogicalDType>,
    arrow_dtype_hint: Option<ArrowDataType>,
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
#[derive(Debug, Clone, PartialEq, Eq)]
struct FlatColumnarSourceShape {
    projected_columns: Vec<ColumnarProjectedColumn>,
}

#[cfg(feature = "vortex-write")]
fn prepare_vortex_target(target_path: &Path, allow_overwrite: bool) -> Result<()> {
    let workspace_root = shardloom_core::infer_local_output_workspace_root(target_path)?;
    shardloom_core::plan_workspace_safe_local_output(workspace_root, target_path, allow_overwrite)?;
    Ok(())
}

#[cfg(feature = "vortex-write")]
fn cleanup_legacy_prepared_olap_state_sidecars(target_path: &Path) -> Result<()> {
    let Some(parent) = target_path.parent() else {
        return Ok(());
    };
    let Some(file_name) = target_path.file_name().and_then(std::ffi::OsStr::to_str) else {
        return Ok(());
    };
    let shardloom_dir = parent.join(".shardloom");
    if !shardloom_dir.exists() {
        return Ok(());
    }
    cleanup_legacy_prepared_olap_path(
        &shardloom_dir.join(format!("{file_name}.prepared-olap-state.manifest")),
        "legacy prepared OLAP manifest",
    )?;
    cleanup_legacy_prepared_olap_path(
        &shardloom_dir.join(format!("{file_name}.prepared-olap-state.d")),
        "legacy prepared OLAP sidecar directory",
    )
}

#[cfg(feature = "vortex-write")]
fn cleanup_legacy_prepared_olap_path(path: &Path, label: &str) -> Result<()> {
    let metadata = match fs::symlink_metadata(path) {
        Ok(metadata) => metadata,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(()),
        Err(error) => {
            return Err(ShardLoomError::InvalidOperation(format!(
                "failed to inspect {label} '{}' during Vortex artifact replacement cleanup: {error}; no fallback execution was attempted",
                path.display()
            )));
        }
    };
    let file_type = metadata.file_type();
    let cleanup_result = if file_type.is_dir() && !file_type.is_symlink() {
        fs::remove_dir_all(path)
    } else {
        fs::remove_file(path)
    };
    cleanup_result.map_err(|error| {
        ShardLoomError::InvalidOperation(format!(
            "failed to remove {label} '{}' during Vortex artifact replacement cleanup: {error}; no fallback execution was attempted",
            path.display()
        ))
    })
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn validate_flat_columnar_source_shape(
    source: &FlatLocalColumnarSource,
) -> Result<FlatColumnarSourceShape> {
    validate_flat_columns(&source.materialized_columns)?;
    validate_flat_columns(&source.reader_projection_columns)?;
    if source.column_dtypes.len() != source.header.len() {
        return Err(ShardLoomError::InvalidOperation(format!(
            "local vortex_ingest columnar SourceState dtype hint count is {}, expected {}; no fallback execution was attempted",
            source.column_dtypes.len(),
            source.header.len()
        )));
    }

    let reader_positions = source
        .reader_projection_columns
        .iter()
        .enumerate()
        .map(|(index, column)| (column.as_str(), index))
        .collect::<BTreeMap<_, _>>();
    let projected_columns = source
        .materialized_columns
        .iter()
        .map(|column| {
            let reader_index = reader_positions.get(column.as_str()).ok_or_else(|| {
                ShardLoomError::InvalidOperation(format!(
                    "local vortex_ingest columnar SourceState is missing projected column '{column}'; no fallback execution was attempted"
                ))
            })?;
            let dtype_hint = source
                .header
                .iter()
                .position(|candidate| candidate == column)
                .and_then(|index| source.column_dtypes.get(index))
                .and_then(Clone::clone);
            let arrow_dtype_hint = source
                .header
                .iter()
                .position(|candidate| candidate == column)
                .and_then(|index| source.column_arrow_dtypes.get(index))
                .and_then(Clone::clone);
            Ok(ColumnarProjectedColumn {
                column: column.clone(),
                reader_index: *reader_index,
                dtype_hint,
                arrow_dtype_hint,
            })
        })
        .collect::<Result<Vec<_>>>()?;

    let mut row_count = 0usize;
    for (batch_index, batch) in source.batches.iter().enumerate() {
        let expected_column_count = source.reader_projection_columns.len();
        if batch.num_columns() != expected_column_count {
            return Err(ShardLoomError::InvalidOperation(format!(
                "local vortex_ingest columnar SourceState batch {} has {} projected columns, expected {}; no fallback execution was attempted",
                batch_index + 1,
                batch.num_columns(),
                expected_column_count
            )));
        }
        let schema = batch.schema();
        if schema.fields().len() != expected_column_count {
            return Err(ShardLoomError::InvalidOperation(format!(
                "local vortex_ingest columnar SourceState batch {} schema has {} projected fields, expected {}; no fallback execution was attempted",
                batch_index + 1,
                schema.fields().len(),
                expected_column_count
            )));
        }
        for (column_index, expected_column) in source.reader_projection_columns.iter().enumerate() {
            let actual_column = schema.field(column_index).name();
            if actual_column != expected_column {
                return Err(ShardLoomError::InvalidOperation(format!(
                    "local vortex_ingest columnar SourceState batch {} projected field {} is '{}', expected '{}'; no fallback execution was attempted",
                    batch_index + 1,
                    column_index + 1,
                    actual_column,
                    expected_column
                )));
            }
        }
        row_count = row_count.checked_add(batch.num_rows()).ok_or_else(|| {
            ShardLoomError::InvalidOperation(
                "local vortex_ingest columnar SourceState row count overflowed usize; no fallback execution was attempted"
                    .to_string(),
            )
        })?;
    }

    if row_count != source.row_count {
        return Err(ShardLoomError::InvalidOperation(format!(
            "local vortex_ingest columnar SourceState row count is {}, expected {}; no fallback execution was attempted",
            row_count, source.row_count
        )));
    }

    Ok(FlatColumnarSourceShape { projected_columns })
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn validate_flat_columnar_stream_source_shape(
    source: &FlatLocalColumnarStreamSource,
) -> Result<FlatColumnarSourceShape> {
    validate_flat_columns(&source.materialized_columns)?;
    validate_flat_columns(&source.reader_projection_columns)?;
    if source.column_dtypes.len() != source.header.len() {
        return Err(ShardLoomError::InvalidOperation(format!(
            "streaming local vortex_ingest columnar SourceState dtype hint count is {}, expected {}; no fallback execution was attempted",
            source.column_dtypes.len(),
            source.header.len()
        )));
    }
    if source.column_arrow_dtypes.len() != source.header.len() {
        return Err(ShardLoomError::InvalidOperation(format!(
            "streaming local vortex_ingest columnar SourceState Arrow dtype hint count is {}, expected {}; no fallback execution was attempted",
            source.column_arrow_dtypes.len(),
            source.header.len()
        )));
    }

    let reader_positions = source
        .reader_projection_columns
        .iter()
        .enumerate()
        .map(|(index, column)| (column.as_str(), index))
        .collect::<BTreeMap<_, _>>();
    let projected_columns = source
        .materialized_columns
        .iter()
        .map(|column| {
            let reader_index = reader_positions.get(column.as_str()).ok_or_else(|| {
                ShardLoomError::InvalidOperation(format!(
                    "streaming local vortex_ingest columnar SourceState is missing projected column '{column}'; no fallback execution was attempted"
                ))
            })?;
            let header_index = source
                .header
                .iter()
                .position(|candidate| candidate == column)
                .ok_or_else(|| {
                    ShardLoomError::InvalidOperation(format!(
                        "streaming local vortex_ingest columnar SourceState projected column '{column}' is not present in the source header; no fallback execution was attempted"
                    ))
                })?;
            Ok(ColumnarProjectedColumn {
                column: column.clone(),
                reader_index: *reader_index,
                dtype_hint: source.column_dtypes[header_index].clone(),
                arrow_dtype_hint: source.column_arrow_dtypes[header_index].clone(),
            })
        })
        .collect::<Result<Vec<_>>>()?;

    Ok(FlatColumnarSourceShape { projected_columns })
}

#[cfg(feature = "vortex-write")]
struct VortexPreparedStateFinalizeInput<'a> {
    target_path: PathBuf,
    column_count: usize,
    column_families: Vec<(String, String)>,
    row_count: u64,
    array: &'a vortex::array::ArrayRef,
    array_build_micros: u128,
    certification_level: VortexIngestCertificationLevel,
    allow_overwrite: bool,
    array_build_provider_kind: &'static str,
    array_build_provider_surface: &'static str,
    array_build_strategy: &'static str,
    array_build_prefetch_window: usize,
    array_build_input_layout: &'static str,
    array_build_record_batch_count: usize,
    manual_scalar_copy_avoided: bool,
    capillary_prewrite_control: VortexCapillaryPreWriteControlReport,
    layout_write_decision: VortexLayoutWriteRuntimeDecision,
    preparation_spine: VortexPreparationSpineFinalizeInput,
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
struct VortexPreparedStateStreamFinalizeInput<I>
where
    I: vortex::array::iter::ArrayIterator
        + futures::Stream<Item = vortex::error::VortexResult<vortex::array::ArrayRef>>
        + Unpin
        + Send
        + 'static,
{
    target_path: PathBuf,
    prepared_source_binding: Option<String>,
    column_count: usize,
    column_families: Vec<(String, String)>,
    row_count_hint: Option<u64>,
    array_iterator: I,
    writer_input_lookahead: Option<WriterInputLookahead>,
    source_identities: Vec<Arc<SourceIdentity>>,
    native_memory: Option<NativeIngestMemory>,
    ingest_runtime: Option<crate::ingest_runtime::IngestRuntime>,
    emitted_record_batch_count: Arc<AtomicUsize>,
    stream_timing: VortexStreamingIngestTiming,
    array_build_micros: u128,
    certification_level: VortexIngestCertificationLevel,
    allow_overwrite: bool,
    array_build_provider_kind: &'static str,
    array_build_provider_surface: &'static str,
    array_build_strategy: &'static str,
    array_build_prefetch_window: usize,
    array_build_input_layout: &'static str,
    manual_scalar_copy_avoided: bool,
    capillary_prewrite_control: VortexCapillaryPreWriteControlReport,
    layout_write_decision: VortexLayoutWriteRuntimeDecision,
    preparation_spine: VortexPreparationSpineFinalizeInput,
}

#[cfg(feature = "vortex-write")]
#[derive(Debug, Clone, Copy)]
struct VortexPreparationSpineFinalizeInput {
    vortex_first_decision: &'static str,
    feature_gate: &'static str,
    source_surface: &'static str,
    split_surface: &'static str,
    split_count: usize,
    projection_mask_status: &'static str,
    filter_mask_status: &'static str,
    materialization_boundary_status: &'static str,
    decode_boundary_status: &'static str,
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
#[derive(Debug, Default, Clone)]
struct VortexStreamingIngestTiming {
    source_pull: Arc<AtomicU64>,
    array_convert: Arc<AtomicU64>,
    derived_metadata_build: Arc<AtomicU64>,
    stages: IngestStageTimings,
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
impl VortexStreamingIngestTiming {
    fn with_derived_metadata_build_micros(derived_metadata_build_micros: Arc<AtomicU64>) -> Self {
        Self {
            source_pull: Arc::new(AtomicU64::new(0)),
            array_convert: Arc::new(AtomicU64::new(0)),
            derived_metadata_build: derived_metadata_build_micros,
            stages: IngestStageTimings::default(),
        }
    }

    fn add_source_pull_elapsed(&self, elapsed: std::time::Duration) {
        self.source_pull
            .fetch_add(duration_micros_u64(elapsed), Ordering::Relaxed);
    }

    fn add_array_convert_elapsed(&self, elapsed: std::time::Duration) {
        self.array_convert
            .fetch_add(duration_micros_u64(elapsed), Ordering::Relaxed);
    }

    fn source_pull_micros(&self) -> u128 {
        u128::from(self.source_pull.load(Ordering::Relaxed))
    }

    fn array_convert_micros(&self) -> u128 {
        u128::from(self.array_convert.load(Ordering::Relaxed))
    }

    fn derived_metadata_build_micros(&self) -> u128 {
        u128::from(self.derived_metadata_build.load(Ordering::Relaxed))
    }

    fn decode_without_derived_micros(&self) -> u128 {
        self.source_pull_micros()
            .saturating_sub(self.derived_metadata_build_micros())
    }
}

#[cfg(feature = "vortex-write")]
#[derive(Debug, Default, Clone)]
struct VortexWriterStageTiming {
    compression_micros: Arc<AtomicU64>,
    stages: IngestStageTimings,
    #[cfg(all(test, feature = "universal-format-io"))]
    codec_completion_gate: Option<Arc<pipeline_pressure_tests::CodecCompletionGate>>,
}

#[cfg(feature = "vortex-write")]
impl VortexWriterStageTiming {
    fn add_compression_elapsed(&self, elapsed: std::time::Duration) {
        self.compression_micros
            .fetch_add(duration_micros_u64(elapsed), Ordering::Relaxed);
    }

    fn compression_micros(&self) -> u128 {
        u128::from(self.compression_micros.load(Ordering::Relaxed))
    }
}

#[cfg(feature = "vortex-write")]
fn duration_micros_u64(elapsed: std::time::Duration) -> u64 {
    let micros = elapsed.as_micros();
    if micros == 0 && elapsed.as_nanos() > 0 {
        1
    } else {
        u64::try_from(micros).unwrap_or(u64::MAX)
    }
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
struct StreamingColumnarVortexArrayIterator {
    dtype: vortex::array::dtype::DType,
    first_array: Option<vortex::array::ArrayRef>,
    reader: Option<Box<dyn arrow_array::RecordBatchReader + Send>>,
    prefetch: Option<StreamingColumnarVortexPrefetch>,
    reader_projection_columns: Vec<String>,
    source_shape: FlatColumnarSourceShape,
    batch_count: Arc<AtomicUsize>,
    stream_timing: VortexStreamingIngestTiming,
    next_batch_index: usize,
    native_memory: Option<NativeIngestMemory>,
    stream_finished: bool,
}

/// Private handshake: the concrete producer lends one of its existing slots.
/// Generic streams cannot enable writer lookahead without this configuration.
#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
struct WriterInputLookahead;

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
impl StreamingColumnarVortexArrayIterator {
    #[cfg(test)]
    #[allow(clippy::too_many_arguments)]
    fn new(
        dtype: vortex::array::dtype::DType,
        first_array: vortex::array::ArrayRef,
        reader: Box<dyn arrow_array::RecordBatchReader + Send>,
        reader_projection_columns: Vec<String>,
        source_shape: FlatColumnarSourceShape,
        batch_count: Arc<AtomicUsize>,
        stream_timing: VortexStreamingIngestTiming,
        next_batch_index: usize,
        vortex_array_prefetch_window: usize,
        vortex_array_worker_count: usize,
        prefetch_memory_bytes: u64,
        native_memory: Option<NativeIngestMemory>,
    ) -> Result<Self> {
        Self::with_runtime(
            dtype,
            first_array,
            reader,
            reader_projection_columns,
            source_shape,
            batch_count,
            stream_timing,
            next_batch_index,
            vortex_array_prefetch_window,
            vortex_array_worker_count,
            prefetch_memory_bytes,
            native_memory,
            None,
        )
    }

    #[allow(clippy::too_many_arguments)]
    fn with_runtime(
        dtype: vortex::array::dtype::DType,
        first_array: vortex::array::ArrayRef,
        reader: Box<dyn arrow_array::RecordBatchReader + Send>,
        reader_projection_columns: Vec<String>,
        source_shape: FlatColumnarSourceShape,
        batch_count: Arc<AtomicUsize>,
        stream_timing: VortexStreamingIngestTiming,
        next_batch_index: usize,
        vortex_array_prefetch_window: usize,
        vortex_array_worker_count: usize,
        prefetch_memory_bytes: u64,
        native_memory: Option<NativeIngestMemory>,
        runtime: Option<crate::ingest_runtime::IngestRuntime>,
    ) -> Result<Self> {
        let max_window = runtime
            .as_ref()
            .map_or(VORTEX_STREAM_ARRAY_PREFETCH_MAX_WINDOW, |runtime| {
                runtime.parallelism()
            });
        if (vortex_array_prefetch_window == 0 && vortex_array_worker_count != 0)
            || (vortex_array_prefetch_window > 0
                && (!(1..=vortex_array_prefetch_window).contains(&vortex_array_worker_count)
                    || vortex_array_prefetch_window > max_window))
        {
            return Err(ShardLoomError::InvalidOperation(
                "native ingest conversion workers must match the admitted bounded queue; no fallback execution was attempted".to_string(),
            ));
        }
        let (reader, prefetch) = if vortex_array_prefetch_window > 0 {
            let window = vortex_array_prefetch_window;
            let task_bytes = prefetch_memory_bytes / u64::try_from(window).unwrap_or(u64::MAX);
            if task_bytes == 0 {
                return Err(ShardLoomError::InvalidOperation(
                    "Vortex prefetch memory budget cannot reserve every in-flight slot; no fallback execution was attempted".to_string(),
                ));
            }
            let memory = native_memory
                .as_ref()
                .map(|state| state.pool.clone())
                .map_or_else(|| LiveMemoryPool::new(prefetch_memory_bytes), Ok)?;
            let context = Arc::new(StreamingColumnarVortexArrayWorker {
                reader: Arc::new(futures::lock::Mutex::new(
                    StreamingColumnarVortexArraySharedReader {
                        reader,
                        next_batch_index,
                        stopped: false,
                    },
                )),
                reader_projection_columns: reader_projection_columns.clone(),
                source_shape: source_shape.clone(),
                dtype: dtype.clone(),
                batch_count: Arc::clone(&batch_count),
                stream_timing: stream_timing.clone(),
                native_memory: native_memory.clone(),
                failure: OnceLock::new(),
            });
            let mut prefetch = StreamingColumnarVortexPrefetch {
                pool: if let Some(runtime) = runtime {
                    shared_conversion::ConversionExecutor::Shared { runtime, memory }
                } else {
                    shared_conversion::ConversionExecutor::Dedicated(ComputePool::new(
                        vortex_array_worker_count,
                        window,
                        prefetch_memory_bytes,
                        memory,
                    )?)
                },
                context,
                tasks: std::collections::VecDeque::new(),
                pending: BTreeMap::new(),
                cancellation: CancellationToken::default(),
                window,
                task_bytes,
                exhausted: false,
                refill_after_handoff: true,
                handoff_wait_started: None,
            };
            prefetch.fill_window()?;
            (None, Some(prefetch))
        } else {
            (Some(reader), None)
        };
        Ok(Self {
            dtype,
            first_array: Some(first_array),
            reader,
            prefetch,
            reader_projection_columns,
            source_shape,
            batch_count,
            stream_timing,
            next_batch_index,
            native_memory,
            stream_finished: false,
        })
    }

    fn share_input_slot_with_writer(
        &mut self,
        decision: &VortexLayoutWriteRuntimeDecision,
    ) -> Option<WriterInputLookahead> {
        if self.native_memory.is_none()
            || self.first_array.is_none()
            || decision.writer_runtime_applied_parallelism <= 1
            || column_layout::DEFAULT_STREAM_FOOTER_LAYOUT
                != column_layout::StreamFooterLayout::RetainedRows
        {
            return None;
        }
        let prefetch = self.prefetch.as_mut()?;
        if !prefetch.refill_after_handoff {
            return None;
        }
        // Keep W slots and the original per-task credit. A yielded lookahead
        // occupies one of those slots until the prior child finishes. Only
        // the next pull refills it: child + lookahead + (W-1), not child + W+1.
        prefetch.refill_after_handoff = false;
        Some(WriterInputLookahead)
    }
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
impl Iterator for StreamingColumnarVortexArrayIterator {
    type Item = vortex::error::VortexResult<vortex::array::ArrayRef>;

    fn next(&mut self) -> Option<Self::Item> {
        if let Some(array) = self.first_array.take() {
            return Some(Ok(array));
        }
        if let Some(prefetch) = self.prefetch.as_mut() {
            let result = prefetch.next_array(self.next_batch_index);
            if result.is_some() {
                self.next_batch_index += 1;
            }
            if result.as_ref().is_none_or(std::result::Result::is_err) {
                self.prefetch.take();
            }
            return result.map(|result| result.map_err(vortex_stream_error));
        }
        let reader = self.reader.as_mut()?;
        let mut input_lease = match self
            .native_memory
            .as_ref()
            .map(|memory| memory.reserve_input(1))
            .transpose()
        {
            Ok(lease) => lease,
            Err(error) => {
                self.reader.take();
                return Some(Err(vortex_stream_error(error)));
            }
        };
        let source_pull_start = Instant::now();
        let batch = reader.next();
        self.stream_timing
            .add_source_pull_elapsed(source_pull_start.elapsed());
        let batch = match batch? {
            Ok(batch) => batch,
            Err(error) => {
                self.reader.take();
                return Some(Err(vortex_stream_error(error)));
            }
        };
        let batch_index = self.next_batch_index;
        self.next_batch_index += 1;
        let array_convert_start = Instant::now();
        let result = validate_stream_record_batch_shape_profiled(
            &batch,
            &self.reader_projection_columns,
            &self.source_shape,
            batch_index,
            &self.stream_timing.stages,
        )
        .and_then(|()| record_batch_to_vortex_from_arrow_provider_profiled_with_memory(
            &batch, &self.source_shape, &self.stream_timing.stages,
            self.native_memory.as_ref().zip(input_lease.as_mut()),
        ))
        .and_then(|array| {
            if array.dtype() != &self.dtype {
                return Err(ShardLoomError::InvalidOperation(format!(
                    "streaming local vortex_ingest batch {batch_index} produced dtype {}, expected {}; no fallback execution was attempted",
                    array.dtype(), self.dtype
                )));
            }
            self.batch_count.fetch_add(1, Ordering::Relaxed);
            Ok(array)
        });
        self.stream_timing
            .add_array_convert_elapsed(array_convert_start.elapsed());
        if result.is_err() {
            self.reader.take();
        }
        Some(result.map_err(vortex_stream_error))
    }
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
impl vortex::array::iter::ArrayIterator for StreamingColumnarVortexArrayIterator {
    fn dtype(&self) -> &vortex::array::dtype::DType {
        &self.dtype
    }
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
impl futures::Stream for StreamingColumnarVortexArrayIterator {
    type Item = vortex::error::VortexResult<vortex::array::ArrayRef>;

    fn poll_next(
        self: std::pin::Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
    ) -> std::task::Poll<Option<Self::Item>> {
        let this = self.get_mut();
        if this.stream_finished {
            return std::task::Poll::Ready(None);
        }
        if !this.prefetch.as_ref().is_some_and(|prefetch| {
            matches!(
                prefetch.pool,
                shared_conversion::ConversionExecutor::Shared { .. }
            )
        }) {
            return std::task::Poll::Ready(Iterator::next(this));
        }
        if let Some(array) = this.first_array.take() {
            return std::task::Poll::Ready(Some(Ok(array)));
        }
        let result = futures::ready!(
            this.prefetch
                .as_mut()
                .expect("shared prefetch checked above")
                .poll_next_array(this.next_batch_index, cx)
        );
        if result.is_some() {
            this.next_batch_index += 1;
        }
        if result.as_ref().is_none_or(std::result::Result::is_err) {
            // The outer operation owns teardown. A provider task must never
            // synchronously join a conversion task that may be driving it.
            this.stream_finished = true;
        }
        std::task::Poll::Ready(result.map(|result| result.map_err(vortex_stream_error)))
    }
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
type PrefetchedVortexArray = Option<(usize, vortex::array::ArrayRef)>;

/// Bounds the entire pre-writer window, including completed out-of-order arrays.
/// Legacy credits end at writer handoff. The explicitly admitted native-memory
/// route copies input buffers into allocator-owned storage before completion.
/// Original source/input owners, upstream codec allocations bypassing the
/// allocator and reader internals are a separate scope.
#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
struct StreamingColumnarVortexPrefetch {
    pool: shared_conversion::ConversionExecutor,
    context: Arc<StreamingColumnarVortexArrayWorker>,
    tasks: std::collections::VecDeque<shared_conversion::ConversionTask>,
    pending: BTreeMap<usize, Budgeted<vortex::array::ArrayRef>>,
    cancellation: CancellationToken,
    window: usize,
    task_bytes: u64,
    exhausted: bool,
    refill_after_handoff: bool,
    handoff_wait_started: Option<Instant>,
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
impl StreamingColumnarVortexPrefetch {
    fn fill_window(&mut self) -> Result<()> {
        while !self.exhausted
            && self.tasks.len() + self.pending.len() < self.window
            && self.context.failure.get().is_none()
        {
            let context = Arc::clone(&self.context);
            let lease = match self.pool.memory().reserve(self.task_bytes) {
                Ok(lease) => lease,
                Err(_) if self.context.failure.get().is_some() => break,
                Err(error) => return Err(error),
            };
            let task = self
                .pool
                .submit_read(context, lease, self.cancellation.clone());
            match task {
                Ok(task) => self.tasks.push_back(task),
                // A source failure can cancel submission while the initial
                // window is still filling. Deliver it from next_array, not
                // nondeterministically from iterator construction.
                Err(_) if self.context.failure.get().is_some() => break,
                Err(error) => return Err(error),
            }
        }
        Ok(())
    }

    fn next_array(&mut self, expected: usize) -> Option<Result<vortex::array::ArrayRef>> {
        use vortex::io::runtime::BlockingRuntime as _;

        let runtime = match &self.pool {
            shared_conversion::ConversionExecutor::Shared { runtime, .. } => Some(runtime.clone()),
            shared_conversion::ConversionExecutor::Dedicated(_) => None,
        };
        let next = futures::future::poll_fn(|cx| self.poll_next_array(expected, cx));
        if let Some(runtime) = runtime {
            runtime.runtime().block_on(next)
        } else {
            futures::executor::block_on(next)
        }
    }

    fn poll_next_array(
        &mut self,
        expected: usize,
        cx: &mut std::task::Context<'_>,
    ) -> std::task::Poll<Option<Result<vortex::array::ArrayRef>>> {
        use std::task::Poll;

        if let Some(error) = self.context.failure.get() {
            return Poll::Ready(Some(Err(error.clone())));
        }
        if let Err(error) = self.cancellation.check() {
            return Poll::Ready(Some(Err(self.context.primary_failure_or(error))));
        }
        if let Err(error) = self.fill_window() {
            return Poll::Ready(Some(Err(self.context.primary_failure_or(error))));
        }
        if let Some(error) = self.context.failure.get() {
            return Poll::Ready(Some(Err(error.clone())));
        }
        loop {
            if let Some(array) = self.pending.remove(&expected) {
                let (array, lease) = array.into_parts();
                // The Vortex writer now owns the array and its referenced buffers.
                drop(lease);
                if self.refill_after_handoff
                    && let Err(error) = self.fill_window()
                {
                    return Poll::Ready(Some(Err(self.context.primary_failure_or(error))));
                }
                if let Some(error) = self.context.failure.get() {
                    return Poll::Ready(Some(Err(error.clone())));
                }
                return Poll::Ready(Some(Ok(array)));
            }
            let Some(task) = self.tasks.front_mut() else {
                if self.pending.is_empty() {
                    return Poll::Ready(None);
                }
                return Poll::Ready(Some(Err(ShardLoomError::InvalidOperation(format!(
                    "ordered Vortex prefetch ended before batch {expected}; no fallback execution was attempted"
                )))));
            };
            let wait_started = *self.handoff_wait_started.get_or_insert_with(Instant::now);
            let result = match task {
                shared_conversion::ConversionTask::Shared(task) => {
                    let result = futures::ready!(task.poll_join(cx));
                    self.tasks.pop_front();
                    result.and_then(std::convert::identity)
                }
                shared_conversion::ConversionTask::Dedicated(_) => self
                    .tasks
                    .pop_front()
                    .expect("front task checked above")
                    .join(),
            };
            self.handoff_wait_started = None;
            self.context.stream_timing.stages.record(
                Stage::OrderedHandoffWait,
                wait_started.elapsed(),
                0,
                0,
                0,
            );
            match result {
                Ok(result) => {
                    let (result, lease) = result.into_parts();
                    match result {
                        Some((index, array)) => {
                            self.pending.insert(index, Budgeted::new(array, lease));
                        }
                        None => self.exhausted = true,
                    }
                }
                Err(error) => {
                    return Poll::Ready(Some(Err(self.context.primary_failure_or(error))));
                }
            }
        }
    }
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
impl Drop for StreamingColumnarVortexPrefetch {
    fn drop(&mut self) {
        self.cancellation.cancel();
        for task in self.tasks.drain(..) {
            let _ = task.join();
        }
        self.pending.clear();
    }
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
struct StreamingColumnarVortexArraySharedReader {
    reader: Box<dyn arrow_array::RecordBatchReader + Send>,
    next_batch_index: usize,
    stopped: bool,
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
struct StreamingColumnarVortexArrayWorker {
    reader: Arc<futures::lock::Mutex<StreamingColumnarVortexArraySharedReader>>,
    reader_projection_columns: Vec<String>,
    source_shape: FlatColumnarSourceShape,
    dtype: vortex::array::dtype::DType,
    batch_count: Arc<AtomicUsize>,
    stream_timing: VortexStreamingIngestTiming,
    native_memory: Option<NativeIngestMemory>,
    failure: OnceLock<ShardLoomError>,
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
impl StreamingColumnarVortexArrayWorker {
    fn remember_failure(&self, error: &ShardLoomError) {
        // Record the cause before ComputePool turns it into shared cancellation.
        // Cancellation checks must not replace this with a secondary error.
        let _ = self.failure.set(error.clone());
    }

    fn primary_failure_or(&self, secondary: ShardLoomError) -> ShardLoomError {
        self.failure.get().cloned().unwrap_or(secondary)
    }

    fn read_convert(
        &self,
        worker: &WorkerContext,
        lease: &mut MemoryLease,
    ) -> Result<PrefetchedVortexArray> {
        futures::executor::block_on(self.read_convert_checked(|| worker.check_cancelled(), lease))
    }

    async fn read_convert_checked(
        &self,
        check_cancelled: impl Fn() -> Result<()> + Send,
        lease: &mut MemoryLease,
    ) -> Result<PrefetchedVortexArray> {
        let (index, batch) = {
            let lock_started = Instant::now();
            let mut reader = self.reader.lock().await;
            self.stream_timing.stages.record(
                Stage::ReaderLockWait,
                lock_started.elapsed(),
                0,
                0,
                0,
            );
            check_cancelled()?;
            let Some(batch) = self.read_batch(&mut reader)? else {
                return Ok(None);
            };
            batch
        };
        check_cancelled()?;
        self.convert_batch(index, &batch, lease)
            .inspect_err(|error| self.remember_failure(error))
    }

    fn read_batch(
        &self,
        reader: &mut StreamingColumnarVortexArraySharedReader,
    ) -> Result<Option<(usize, RecordBatch)>> {
        if reader.stopped {
            return Ok(None);
        }
        let started = Instant::now();
        let batch = next_streaming_record_batch(reader.reader.as_mut(), "Vortex prefetch");
        self.stream_timing
            .add_source_pull_elapsed(started.elapsed());
        let batch = match batch {
            Ok(Some(batch)) => batch,
            Ok(None) => {
                reader.stopped = true;
                return Ok(None);
            }
            Err(error) => {
                reader.stopped = true;
                self.remember_failure(&error);
                return Err(error);
            }
        };
        let index = reader.next_batch_index;
        reader.next_batch_index += 1;
        Ok(Some((index, batch)))
    }

    fn convert_batch(
        &self,
        index: usize,
        batch: &RecordBatch,
        lease: &mut MemoryLease,
    ) -> Result<PrefetchedVortexArray> {
        // The owned route copies visible regions into its admitted allocator.
        // Arrow's backing capacities may count a shared IPC body repeatedly;
        // they do not size these copies or the excluded original reader owners.
        let input_bytes = if self.native_memory.is_some() {
            arrow_ownership::batch_copy_allocation_bytes(batch)?
        } else {
            u64::try_from(batch.get_array_memory_size()).unwrap_or(u64::MAX)
        };
        // Reserve conversion headroom before invoking the native provider. This
        // bounds admitted batches, not allocations hidden inside a source reader.
        if input_bytes > lease.bytes() / 2 {
            return Err(ShardLoomError::InvalidOperation(format!(
                "Vortex prefetch batch {index} needs conversion headroom for {input_bytes} input bytes, exceeding its {} byte reservation; reduce source batch size; no fallback execution was attempted",
                lease.bytes()
            )));
        }
        let started = Instant::now();
        let result = validate_stream_record_batch_shape_profiled(
            batch,
            &self.reader_projection_columns,
            &self.source_shape,
            index,
            &self.stream_timing.stages,
        )
        .and_then(|()| {
            record_batch_to_vortex_from_arrow_provider_profiled_with_memory(
                batch,
                &self.source_shape,
                &self.stream_timing.stages,
                self.native_memory
                    .as_ref()
                    .map(|memory| (memory, &mut *lease)),
            )
        });
        self.stream_timing
            .add_array_convert_elapsed(started.elapsed());
        let array = result?;
        if array.dtype() != &self.dtype {
            return Err(ShardLoomError::InvalidOperation(format!(
                "Vortex prefetch batch {index} dtype mismatch; no fallback execution was attempted"
            )));
        }
        if self.native_memory.is_none() && array.nbytes() > lease.bytes() {
            return Err(ShardLoomError::InvalidOperation(format!(
                "Vortex prefetch batch {index} exceeded its retained-array reservation; no fallback execution was attempted"
            )));
        }
        // Keep the admitted capacity until handoff. Array nbytes counts logical
        // buffers, not necessarily the capacity retained by shared Arrow owners.
        self.batch_count.fetch_add(1, Ordering::Relaxed);
        Ok(Some((index, array)))
    }
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
#[path = "vortex_ingest_shared_conversion.rs"]
mod shared_conversion;

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
#[path = "vortex_ingest_shared_stream.rs"]
mod shared_stream;

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn vortex_stream_error(error: impl std::fmt::Display) -> vortex::error::VortexError {
    vortex::error::vortex_err!("{error}")
}

#[cfg(all(test, feature = "vortex-write", feature = "universal-format-io"))]
#[path = "vortex_ingest_prefetch_tests.rs"]
mod prefetch_tests;

#[cfg(all(test, feature = "vortex-write", feature = "universal-format-io"))]
#[path = "vortex_ingest_owned_tests.rs"]
mod owned_ingest_tests;

#[cfg(all(test, feature = "vortex-write", feature = "universal-format-io"))]
#[path = "vortex_ingest_pipeline_pressure_tests.rs"]
mod pipeline_pressure_tests;

#[cfg(all(test, feature = "vortex-write", feature = "universal-format-io"))]
#[path = "vortex_ingest_writer_slot_tests.rs"]
mod writer_slot_tests;

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn next_streaming_record_batch(
    reader: &mut dyn arrow_array::RecordBatchReader,
    context: &str,
) -> Result<Option<RecordBatch>> {
    reader
        .next()
        .transpose()
        .map_err(|error| ShardLoomError::InvalidOperation(format!("{context} failed: {error}")))
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn validate_stream_record_batch_shape_profiled(
    batch: &RecordBatch,
    reader_projection_columns: &[String],
    source_shape: &FlatColumnarSourceShape,
    batch_index: usize,
    timing: &IngestStageTimings,
) -> Result<()> {
    let started = Instant::now();
    let result = validate_stream_record_batch_shape(
        batch,
        reader_projection_columns,
        source_shape,
        batch_index,
    );
    timing.record(
        Stage::Validation,
        started.elapsed(),
        usize_to_u64(batch.num_rows())?,
        0,
        0,
    );
    result
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn validate_stream_record_batch_shape(
    batch: &RecordBatch,
    reader_projection_columns: &[String],
    source_shape: &FlatColumnarSourceShape,
    batch_index: usize,
) -> Result<()> {
    let expected_column_count = reader_projection_columns.len();
    if batch.num_columns() != expected_column_count {
        return Err(ShardLoomError::InvalidOperation(format!(
            "streaming local vortex_ingest columnar SourceState batch {batch_index} has {} projected columns, expected {}; no fallback execution was attempted",
            batch.num_columns(),
            expected_column_count
        )));
    }
    let schema = batch.schema();
    if schema.fields().len() != expected_column_count {
        return Err(ShardLoomError::InvalidOperation(format!(
            "streaming local vortex_ingest columnar SourceState batch {batch_index} schema has {} projected fields, expected {}; no fallback execution was attempted",
            schema.fields().len(),
            expected_column_count
        )));
    }
    for (column_index, expected_column) in reader_projection_columns.iter().enumerate() {
        let actual_column = schema.field(column_index).name();
        if actual_column != expected_column {
            return Err(ShardLoomError::InvalidOperation(format!(
                "streaming local vortex_ingest columnar SourceState batch {batch_index} projected field {} is '{}', expected '{}'; no fallback execution was attempted",
                column_index + 1,
                actual_column,
                expected_column
            )));
        }
    }
    for projected_column in &source_shape.projected_columns {
        nested::validate_field(schema.field(projected_column.reader_index))?;
        let array = batch.column(projected_column.reader_index);
        let family = arrow_column_family(&projected_column.column, array.as_ref())?;
        if family == "float64" {
            reject_columnar_non_finite_floats(&projected_column.column, array.as_ref())?;
        }
    }
    Ok(())
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn arrow_record_batch_to_vortex_array(batch: RecordBatch) -> Result<vortex::array::ArrayRef> {
    use vortex::VortexSessionDefault as _;
    use vortex::arrow::ArrowSessionExt as _;

    let schema = batch.schema();
    let session = vortex::session::VortexSession::default();
    session
        .arrow()
        .from_arrow_record_batch(batch, schema.as_ref())
        .map_err(vortex_error)
}

#[cfg(all(test, feature = "vortex-write", feature = "universal-format-io"))]
fn record_batch_to_vortex_from_arrow_provider(
    batch: &RecordBatch,
    source_shape: &FlatColumnarSourceShape,
) -> Result<vortex::array::ArrayRef> {
    let (projected, _) = project_record_batch_for_vortex(batch, source_shape)?;
    arrow_record_batch_to_vortex_array(projected)
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn project_record_batch_for_vortex(
    batch: &RecordBatch,
    source_shape: &FlatColumnarSourceShape,
) -> Result<(RecordBatch, bool)> {
    // The reader already applied this projection. Reuse its schema and avoid the
    // projection-index vector; cloning the batch still clones its column Arc list.
    let identity = source_shape.projected_columns.len() == batch.num_columns()
        && source_shape
            .projected_columns
            .iter()
            .enumerate()
            .all(|(index, column)| column.reader_index == index);
    if identity {
        return Ok((batch.clone(), true));
    }
    let projection_indices = source_shape
        .projected_columns
        .iter()
        .map(|column| column.reader_index)
        .collect::<Vec<_>>();
    let projected = batch.project(&projection_indices).map_err(|error| {
        ShardLoomError::InvalidOperation(format!(
            "streaming local vortex_ingest Arrow RecordBatch projection failed: {error}; no fallback execution was attempted"
        ))
    })?;
    Ok((projected, false))
}

#[cfg(all(test, feature = "vortex-write", feature = "universal-format-io"))]
fn record_batch_to_vortex_from_arrow_provider_profiled(
    batch: &RecordBatch,
    source_shape: &FlatColumnarSourceShape,
    timing: &IngestStageTimings,
) -> Result<vortex::array::ArrayRef> {
    record_batch_to_vortex_from_arrow_provider_profiled_with_memory(
        batch,
        source_shape,
        timing,
        None,
    )
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn record_batch_to_vortex_from_arrow_provider_profiled_with_memory(
    batch: &RecordBatch,
    source_shape: &FlatColumnarSourceShape,
    timing: &IngestStageTimings,
    native_memory: Option<(&NativeIngestMemory, &mut MemoryLease)>,
) -> Result<vortex::array::ArrayRef> {
    let rows = usize_to_u64(batch.num_rows())?;
    let started = Instant::now();
    let projected = project_record_batch_for_vortex(batch, source_shape);
    timing.record(Stage::Projection, started.elapsed(), rows, 0, 0);
    let (projected, identity) = projected?;
    if identity {
        timing.identity_projection();
    }
    let input_bytes = u64::try_from(projected.get_array_memory_size()).unwrap_or(u64::MAX);
    let started = Instant::now();
    let result = if let Some((memory, lease)) = native_memory {
        use vortex::arrow::ArrowSessionExt as _;
        let admission_bytes = arrow_ownership::batch_copy_allocation_bytes(&projected)?;
        if admission_bytes > lease.bytes() / 2 {
            return Err(ShardLoomError::InvalidOperation(format!(
                "native ingest batch needs conversion headroom for {admission_bytes} native input copy allocation bytes, exceeding its {} byte reservation; reduce source batch size; no fallback execution was attempted",
                lease.bytes()
            )));
        }
        let retained = arrow_ownership::copy_batch(
            projected,
            &crate::owned_buffers::ReservedHostAllocator::new(memory.pool.clone()),
        )?;
        let schema = retained.schema();
        let result = memory
            .session
            .arrow()
            .from_arrow_record_batch(retained, schema.as_ref())
            .map_err(vortex_error);
        // Copied native input buffers and later allocator buffers hold their
        // own credits. Original Arrow owners are excluded from this accounting;
        // release the conversion admission headroom, not buffer credits.
        lease.resize(0)?;
        result
    } else {
        arrow_record_batch_to_vortex_array(projected)
    };
    timing.record(
        Stage::ArrowConversion,
        started.elapsed(),
        rows,
        input_bytes,
        result.as_ref().map_or(0, vortex::array::ArrayRef::nbytes),
    );
    result
}

#[cfg(all(test, feature = "vortex-write", feature = "universal-format-io"))]
#[path = "vortex_ingest_stage_tests.rs"]
mod stage_tests;

#[cfg(all(test, feature = "vortex-write", feature = "universal-format-io"))]
#[path = "vortex_ingest_cpu_lane_tests.rs"]
mod cpu_lane_tests;

#[cfg(all(test, feature = "vortex-write", feature = "universal-format-io", unix))]
#[path = "vortex_ingest_text_zone_tests.rs"]
mod text_zone_tests;

#[cfg(all(
    test,
    feature = "vortex-write",
    feature = "universal-format-io",
    feature = "vortex-local-primitives",
    unix
))]
#[path = "vortex_ingest_text_io_tests.rs"]
mod text_io_tests;

#[cfg(feature = "vortex-write")]
#[allow(clippy::too_many_lines)]
fn finalize_vortex_prepared_state_write(
    input: VortexPreparedStateFinalizeInput<'_>,
) -> Result<VortexPreparedStateWriteReport> {
    let mut capillary_prewrite_control = input.capillary_prewrite_control.clone();
    capillary_prewrite_control.apply_task_role_gate("vortex_segment_write", "write")?;
    let write_result = write_vortex_array(
        &input.target_path,
        input.array,
        input.allow_overwrite,
        &input.layout_write_decision,
    )?;
    cleanup_legacy_prepared_olap_state_sidecars(&input.target_path)?;

    let (
        reopen_row_count,
        reopen_scan_micros,
        reopen_verification_status,
        upstream_vortex_scan_called,
        prepared_olap_layout_inventory,
    ) = if input.certification_level == VortexIngestCertificationLevel::IngestCertified {
        capillary_prewrite_control.apply_task_role_gate("reopen_verify", "reopen")?;
        let (prepared_olap_layout_inventory, reopen_scan_micros, reopen_verification_status) =
            prepared_vortex_artifact_layout_inventory_after_write(
                &input.target_path,
                write_result.writer_row_count,
                write_result.bytes_written,
                &input.layout_write_decision,
            )?;
        let reopen_row_count = prepared_olap_layout_inventory.row_count.unwrap_or(0);
        if write_result.writer_row_count != input.row_count || reopen_row_count != input.row_count {
            return Err(ShardLoomError::InvalidOperation(format!(
                "local vortex_ingest row-count proof mismatch: source={} writer={} reopen={reopen_row_count}",
                input.row_count, write_result.writer_row_count
            )));
        }
        (
            reopen_row_count,
            reopen_scan_micros,
            reopen_verification_status,
            false,
            prepared_olap_layout_inventory,
        )
    } else {
        capillary_prewrite_control.mark_task_role_not_performed("reopen_verify", "reopen");
        let prepared_olap_layout_inventory =
            if should_defer_prepared_vortex_artifact_layout_inventory(
                write_result.writer_row_count,
                write_result.bytes_written,
                &input.layout_write_decision,
            ) {
                VortexPreparedOlapLayoutInventory::deferred_from_writer_summary(
                    &input.target_path,
                    write_result.writer_row_count,
                    write_result.bytes_written,
                    &input.layout_write_decision,
                )
            } else {
                read_prepared_vortex_artifact_layout_inventory(&input.target_path)?
            };
        if write_result.writer_row_count != input.row_count {
            return Err(ShardLoomError::InvalidOperation(format!(
                "local vortex_ingest writer row count mismatch: source={} writer={}; no fallback execution was attempted",
                input.row_count, write_result.writer_row_count
            )));
        }
        (
            prepared_olap_layout_inventory.row_count.unwrap_or(0),
            0,
            "not_performed_ingest_minimal".to_string(),
            false,
            prepared_olap_layout_inventory,
        )
    };
    capillary_prewrite_control.apply_task_role_gate("sink_evidence", "sink_evidence")?;
    let preparation_spine = preparation_spine_report(
        &input,
        upstream_vortex_scan_called,
        &reopen_verification_status,
    );
    let segment_metadata_primitive = VortexSegmentMetadataPrimitiveReport::from_inventory(
        &prepared_olap_layout_inventory,
        "vortex_ingest_writer_finalize",
        input
            .layout_write_decision
            .writer_physical_design
            .strategy_decision_digest
            .clone(),
    );

    Ok(VortexPreparedStateWriteReport {
        target_path: input.target_path,
        shared_native_memory: None,
        row_count: input.row_count,
        column_count: input.column_count,
        column_families: input.column_families,
        bytes_written: write_result.bytes_written,
        artifact_digest: write_result.artifact_digest,
        artifact_digest_source: write_result.artifact_digest_source,
        digest_micros: write_result.digest_micros,
        writer_row_count: write_result.writer_row_count,
        reopen_row_count,
        array_build_micros: input.array_build_micros,
        stream_source_pull_micros: 0,
        stream_decode_micros: 0,
        stream_derived_metadata_build_micros: 0,
        stream_array_convert_micros: 0,
        stream_timing_split_status: "not_streaming_buffered_or_scalar_vortex_prepare".to_string(),
        stage_work: write_result.stage_work,
        write_micros: write_result.write_micros,
        writer_context_open_micros: write_result.writer_context_open_micros,
        writer_context_reuse_status: write_result.writer_context_reuse_status,
        writer_layout_strategy_applied: write_result.writer_layout_strategy_applied,
        writer_coalescing_policy_status: write_result.writer_coalescing_policy_status,
        writer_layout_row_block_size: write_result.writer_layout_row_block_size,
        writer_layout_block_target_bytes: write_result.writer_layout_block_target_bytes,
        writer_compression_policy: write_result.writer_compression_policy,
        writer_compression_concurrency: write_result.writer_compression_concurrency,
        writer_stats_concurrency: write_result.writer_stats_concurrency,
        writer_runtime_kind: write_result.writer_runtime_kind,
        writer_runtime_requested_parallelism: write_result.writer_runtime_requested_parallelism,
        writer_runtime_applied_parallelism: write_result.writer_runtime_applied_parallelism,
        writer_runtime_background_workers: write_result.writer_runtime_background_workers,
        writer_profile_selection_reason: write_result.writer_profile_selection_reason,
        writer_profile_regression_guard: write_result.writer_profile_regression_guard,
        vortex_segment_write_micros: write_result.vortex_segment_write_micros,
        vortex_compression_micros: write_result.vortex_compression_micros,
        vortex_encode_write_micros: write_result.vortex_encode_write_micros,
        workspace_stage_micros: write_result.workspace_stage_micros,
        vortex_final_commit_micros: write_result.vortex_final_commit_micros,
        reopen_scan_micros,
        reopen_verification_status,
        timing_scope: "vortex_ingest_prepare_once".to_string(),
        certification_level: input.certification_level.as_str().to_string(),
        preparation_included: true,
        query_timing_starts_after_preparation: false,
        upstream_vortex_write_called: true,
        upstream_vortex_scan_called,
        array_build_provider_kind: input.array_build_provider_kind.to_string(),
        array_build_provider_surface: input.array_build_provider_surface.to_string(),
        array_build_strategy: input.array_build_strategy.to_string(),
        array_build_prefetch_window: input.array_build_prefetch_window,
        array_build_input_layout: input.array_build_input_layout.to_string(),
        array_build_record_batch_count: input.array_build_record_batch_count,
        manual_scalar_copy_avoided: input.manual_scalar_copy_avoided,
        preparation_spine,
        writer_physical_design: input.layout_write_decision.writer_physical_design.clone(),
        layout_write_decision: input.layout_write_decision,
        capillary_prewrite_control,
        prepared_olap_layout_inventory,
        segment_metadata_primitive,
        workspace_write_report: write_result.workspace_write_report,
    })
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
#[allow(clippy::too_many_lines)]
fn finalize_vortex_prepared_state_stream_write<I>(
    input: VortexPreparedStateStreamFinalizeInput<I>,
) -> Result<VortexPreparedStateWriteReport>
where
    I: vortex::array::iter::ArrayIterator
        + futures::Stream<Item = vortex::error::VortexResult<vortex::array::ArrayRef>>
        + Unpin
        + Send
        + 'static,
{
    let mut capillary_prewrite_control = input.capillary_prewrite_control.clone();
    capillary_prewrite_control.apply_task_role_gate("vortex_segment_write", "write")?;
    let target_path = input.target_path.clone();
    let certification_level = input.certification_level;
    let row_count_hint = input.row_count_hint;
    let array_build_provider_kind = input.array_build_provider_kind;
    let array_build_provider_surface = input.array_build_provider_surface;
    let mut preparation_spine_input = input.preparation_spine;
    let write_result = write_vortex_array_iterator(
        &target_path,
        input.array_iterator,
        input.allow_overwrite,
        &input.layout_write_decision,
        row_count_hint,
        input.native_memory.as_ref(),
        &input.source_identities,
        input.writer_input_lookahead,
        input.prepared_source_binding.as_deref(),
        input.ingest_runtime.as_ref(),
    )?;
    cleanup_legacy_prepared_olap_state_sidecars(&target_path)?;
    if let Some(expected_rows) = row_count_hint
        && write_result.writer_row_count != expected_rows
    {
        return Err(ShardLoomError::InvalidOperation(format!(
            "streaming local vortex_ingest writer row count mismatch: metadata={expected_rows} writer={}; no fallback execution was attempted",
            write_result.writer_row_count
        )));
    }

    let row_count = write_result.writer_row_count;
    let (
        reopen_row_count,
        reopen_scan_micros,
        reopen_verification_status,
        upstream_vortex_scan_called,
        prepared_olap_layout_inventory,
    ) = if certification_level == VortexIngestCertificationLevel::IngestCertified {
        capillary_prewrite_control.apply_task_role_gate("reopen_verify", "reopen")?;
        let (prepared_olap_layout_inventory, reopen_scan_micros, reopen_verification_status) =
            prepared_vortex_artifact_layout_inventory_after_write(
                &target_path,
                write_result.writer_row_count,
                write_result.bytes_written,
                &input.layout_write_decision,
            )?;
        let reopen_row_count = prepared_olap_layout_inventory.row_count.unwrap_or(0);
        if reopen_row_count != row_count {
            return Err(ShardLoomError::InvalidOperation(format!(
                "streaming local vortex_ingest row-count proof mismatch: writer={row_count} reopen={reopen_row_count}; no fallback execution was attempted"
            )));
        }
        (
            reopen_row_count,
            reopen_scan_micros,
            reopen_verification_status,
            false,
            prepared_olap_layout_inventory,
        )
    } else {
        capillary_prewrite_control.mark_task_role_not_performed("reopen_verify", "reopen");
        let prepared_olap_layout_inventory =
            if should_defer_prepared_vortex_artifact_layout_inventory(
                write_result.writer_row_count,
                write_result.bytes_written,
                &input.layout_write_decision,
            ) {
                VortexPreparedOlapLayoutInventory::deferred_from_writer_summary(
                    &target_path,
                    write_result.writer_row_count,
                    write_result.bytes_written,
                    &input.layout_write_decision,
                )
            } else {
                read_prepared_vortex_artifact_layout_inventory(&target_path)?
            };
        (
            prepared_olap_layout_inventory.row_count.unwrap_or(0),
            0,
            "not_performed_ingest_minimal".to_string(),
            false,
            prepared_olap_layout_inventory,
        )
    };
    capillary_prewrite_control.apply_task_role_gate("sink_evidence", "sink_evidence")?;
    let emitted_record_batch_count = input.emitted_record_batch_count.load(Ordering::Relaxed);
    preparation_spine_input.split_count = emitted_record_batch_count;
    let preparation_spine = preparation_spine_stream_report(
        array_build_provider_kind,
        array_build_provider_surface,
        preparation_spine_input,
        upstream_vortex_scan_called,
        &reopen_verification_status,
    );
    let segment_metadata_primitive = VortexSegmentMetadataPrimitiveReport::from_inventory(
        &prepared_olap_layout_inventory,
        "vortex_ingest_stream_writer_finalize",
        input
            .layout_write_decision
            .writer_physical_design
            .strategy_decision_digest
            .clone(),
    );

    Ok(VortexPreparedStateWriteReport {
        target_path,
        shared_native_memory: input.native_memory.as_ref().map(|memory| {
            let snapshot = memory.pool.snapshot();
            VortexIngestMemoryOwnershipReport {
                limit_bytes: snapshot.limit_bytes,
                peak_reserved_bytes: snapshot.peak_reserved_bytes,
                final_reserved_bytes: snapshot.reserved_bytes,
                denied_reservations: snapshot.denied_reservations,
                max_source_batches: memory.max_chunks,
            }
        }),
        row_count,
        column_count: input.column_count,
        column_families: input.column_families,
        bytes_written: write_result.bytes_written,
        artifact_digest: write_result.artifact_digest,
        artifact_digest_source: write_result.artifact_digest_source,
        digest_micros: write_result.digest_micros,
        writer_row_count: write_result.writer_row_count,
        reopen_row_count,
        array_build_micros: input.array_build_micros,
        stream_source_pull_micros: input.stream_timing.source_pull_micros(),
        stream_decode_micros: input.stream_timing.decode_without_derived_micros(),
        stream_derived_metadata_build_micros: input.stream_timing.derived_metadata_build_micros(),
        stream_array_convert_micros: input.stream_timing.array_convert_micros(),
        stream_timing_split_status:
            "streaming_source_pull_decode_derive_and_arrow_to_vortex_convert_timing_recorded"
                .to_string(),
        stage_work: write_result
            .stage_work
            .with_stream(&input.stream_timing.stages.snapshot()),
        write_micros: write_result.write_micros,
        writer_context_open_micros: write_result.writer_context_open_micros,
        writer_context_reuse_status: write_result.writer_context_reuse_status,
        writer_layout_strategy_applied: write_result.writer_layout_strategy_applied,
        writer_coalescing_policy_status: write_result.writer_coalescing_policy_status,
        writer_layout_row_block_size: write_result.writer_layout_row_block_size,
        writer_layout_block_target_bytes: write_result.writer_layout_block_target_bytes,
        writer_compression_policy: write_result.writer_compression_policy,
        writer_compression_concurrency: write_result.writer_compression_concurrency,
        writer_stats_concurrency: write_result.writer_stats_concurrency,
        writer_runtime_kind: write_result.writer_runtime_kind,
        writer_runtime_requested_parallelism: write_result.writer_runtime_requested_parallelism,
        writer_runtime_applied_parallelism: write_result.writer_runtime_applied_parallelism,
        writer_runtime_background_workers: write_result.writer_runtime_background_workers,
        writer_profile_selection_reason: write_result.writer_profile_selection_reason,
        writer_profile_regression_guard: write_result.writer_profile_regression_guard,
        vortex_segment_write_micros: write_result.vortex_segment_write_micros,
        vortex_compression_micros: write_result.vortex_compression_micros,
        vortex_encode_write_micros: write_result.vortex_encode_write_micros,
        workspace_stage_micros: write_result.workspace_stage_micros,
        vortex_final_commit_micros: write_result.vortex_final_commit_micros,
        reopen_scan_micros,
        reopen_verification_status,
        timing_scope: "vortex_ingest_prepare_once".to_string(),
        certification_level: certification_level.as_str().to_string(),
        preparation_included: true,
        query_timing_starts_after_preparation: false,
        upstream_vortex_write_called: true,
        upstream_vortex_scan_called,
        array_build_provider_kind: array_build_provider_kind.to_string(),
        array_build_provider_surface: array_build_provider_surface.to_string(),
        array_build_strategy: input.array_build_strategy.to_string(),
        array_build_prefetch_window: input.array_build_prefetch_window,
        array_build_input_layout: input.array_build_input_layout.to_string(),
        array_build_record_batch_count: emitted_record_batch_count,
        manual_scalar_copy_avoided: input.manual_scalar_copy_avoided,
        preparation_spine,
        writer_physical_design: input.layout_write_decision.writer_physical_design.clone(),
        layout_write_decision: input.layout_write_decision,
        capillary_prewrite_control,
        prepared_olap_layout_inventory,
        segment_metadata_primitive,
        workspace_write_report: write_result.workspace_write_report,
    })
}

#[cfg(feature = "vortex-write")]
fn preparation_spine_report(
    input: &VortexPreparedStateFinalizeInput<'_>,
    upstream_vortex_scan_called: bool,
    reopen_verification_status: &str,
) -> VortexPreparationSpineReport {
    let provider_is_vortex = input.array_build_provider_kind == "vortex_array_kernel";
    let provider_crate = if provider_is_vortex {
        "vortex".to_string()
    } else {
        "shardloom-vortex,vortex".to_string()
    };
    let provider_version = if provider_is_vortex {
        VORTEX_PREPARATION_SPINE_VORTEX_CRATE_VERSION.to_string()
    } else {
        format!(
            "shardloom-vortex={};vortex={}",
            env!("CARGO_PKG_VERSION"),
            VORTEX_PREPARATION_SPINE_VORTEX_CRATE_VERSION
        )
    };
    let reopen_provider_surface = if reopen_verification_uses_writer_summary(
        reopen_verification_status,
    ) {
        "VortexSession::write_options().write(ArrayStream).summary().row_count();layout_inventory_deferred_until_query_open"
    } else if reopen_verification_uses_metadata(reopen_verification_status) {
        "VortexSession::open_options().with_layout_reader_cache().open_path(...).row_count()"
    } else if upstream_vortex_scan_called {
        "VortexSession::open_options().open_buffer(...).scan().into_array_stream().read_all()"
    } else {
        "not_invoked_ingest_minimal"
    };
    let native_io_certificate_status =
        if reopen_verification_is_certified(reopen_verification_status) {
            "certified_local_vortex_preparation_spine"
        } else {
            "minimal_local_vortex_preparation_spine_digest_only"
        };
    let native_io_certificate_refs = if reopen_verification_uses_writer_summary(
        reopen_verification_status,
    ) {
        "source_split_refs,prepared_artifact_ref,writer_summary_row_count,artifact_digest,layout_inventory_deferred"
    } else if reopen_verification_uses_metadata(reopen_verification_status) {
        "source_split_refs,prepared_artifact_ref,reopen_metadata_row_count"
    } else if upstream_vortex_scan_called {
        "source_split_refs,prepared_artifact_ref,reopen_row_count_scan"
    } else {
        "source_split_refs,prepared_artifact_ref,artifact_digest"
    };

    VortexPreparationSpineReport {
        schema_version: VORTEX_PREPARATION_SPINE_SCHEMA_VERSION,
        status: "admitted_local_preparation_spine".to_string(),
        vortex_first_decision: input.preparation_spine.vortex_first_decision.to_string(),
        provider_kind: input.array_build_provider_kind.to_string(),
        provider_crate,
        provider_version,
        feature_gate: input.preparation_spine.feature_gate.to_string(),
        provider_api_surface: format!(
            "{};{};{}",
            input.array_build_provider_surface,
            "VortexSession::write_options().write(ArrayStream)",
            reopen_provider_surface
        ),
        shardloom_admission_policy: "scoped_local_vortex_ingest_source_sink_split_prepare_once"
            .to_string(),
        source_surface: input.preparation_spine.source_surface.to_string(),
        sink_surface: "workspace_safe_local_vortex_file_sink".to_string(),
        split_surface: input.preparation_spine.split_surface.to_string(),
        split_ref_status: "reported_by_cli_source_state_boundary".to_string(),
        split_count: input.preparation_spine.split_count,
        projection_mask_status: input.preparation_spine.projection_mask_status.to_string(),
        filter_mask_status: input.preparation_spine.filter_mask_status.to_string(),
        write_provider_surface: "VortexSession::write_options().write(ArrayStream)".to_string(),
        reopen_provider_surface: reopen_provider_surface.to_string(),
        materialization_boundary_status: input
            .preparation_spine
            .materialization_boundary_status
            .to_string(),
        decode_boundary_status: input.preparation_spine.decode_boundary_status.to_string(),
        native_io_certificate_status: native_io_certificate_status.to_string(),
        native_io_certificate_refs: native_io_certificate_refs.to_string(),
        claim_gate_status: "not_claim_grade".to_string(),
        claim_boundary: format!(
            "Scoped local Vortex preparation spine only: provider/admission/split/write/reopen evidence for flat local SourceState to VortexPreparedState; reopen_verification_status={reopen_verification_status}; no object-store, table, distributed, broad writer, encoded-operator, performance, production, or Spark-replacement claim"
        ),
        fallback_attempted: false,
        external_engine_invoked: false,
    }
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn preparation_spine_stream_report(
    array_build_provider_kind: &'static str,
    array_build_provider_surface: &'static str,
    preparation_spine: VortexPreparationSpineFinalizeInput,
    upstream_vortex_scan_called: bool,
    reopen_verification_status: &str,
) -> VortexPreparationSpineReport {
    let reopen_provider_surface = if reopen_verification_uses_writer_summary(
        reopen_verification_status,
    ) {
        "VortexSession::write_options().write(ArrayStream).summary().row_count();layout_inventory_deferred_until_query_open"
    } else if reopen_verification_uses_metadata(reopen_verification_status) {
        "VortexSession::open_options().with_layout_reader_cache().open_path(...).row_count()"
    } else if upstream_vortex_scan_called {
        "VortexSession::open_options().open_buffer(...).scan().into_array_stream().read_all()"
    } else {
        "not_invoked_ingest_minimal"
    };
    let native_io_certificate_status =
        if reopen_verification_is_certified(reopen_verification_status) {
            "certified_local_vortex_preparation_spine"
        } else {
            "minimal_local_vortex_preparation_spine_digest_only"
        };
    let native_io_certificate_refs = if reopen_verification_uses_writer_summary(
        reopen_verification_status,
    ) {
        "source_split_refs,prepared_artifact_ref,writer_summary_row_count,artifact_digest,layout_inventory_deferred"
    } else if reopen_verification_uses_metadata(reopen_verification_status) {
        "source_split_refs,prepared_artifact_ref,reopen_metadata_row_count"
    } else if upstream_vortex_scan_called {
        "source_split_refs,prepared_artifact_ref,reopen_row_count_scan"
    } else {
        "source_split_refs,prepared_artifact_ref,artifact_digest"
    };

    VortexPreparationSpineReport {
        schema_version: VORTEX_PREPARATION_SPINE_SCHEMA_VERSION,
        status: "admitted_local_preparation_spine".to_string(),
        vortex_first_decision: preparation_spine.vortex_first_decision.to_string(),
        provider_kind: array_build_provider_kind.to_string(),
        provider_crate: "vortex".to_string(),
        provider_version: VORTEX_PREPARATION_SPINE_VORTEX_CRATE_VERSION.to_string(),
        feature_gate: preparation_spine.feature_gate.to_string(),
        provider_api_surface: format!(
            "{};{};{}",
            array_build_provider_surface,
            "VortexSession::write_options().write(ArrayStream)",
            reopen_provider_surface
        ),
        shardloom_admission_policy: "scoped_local_vortex_ingest_source_sink_split_prepare_once"
            .to_string(),
        source_surface: preparation_spine.source_surface.to_string(),
        sink_surface: "workspace_safe_local_vortex_file_sink".to_string(),
        split_surface: preparation_spine.split_surface.to_string(),
        split_ref_status: "reported_by_streaming_record_batch_boundary".to_string(),
        split_count: preparation_spine.split_count,
        projection_mask_status: preparation_spine.projection_mask_status.to_string(),
        filter_mask_status: preparation_spine.filter_mask_status.to_string(),
        write_provider_surface: "VortexSession::write_options().write(ArrayStream)".to_string(),
        reopen_provider_surface: reopen_provider_surface.to_string(),
        materialization_boundary_status: preparation_spine
            .materialization_boundary_status
            .to_string(),
        decode_boundary_status: preparation_spine.decode_boundary_status.to_string(),
        native_io_certificate_status: native_io_certificate_status.to_string(),
        native_io_certificate_refs: native_io_certificate_refs.to_string(),
        claim_gate_status: "not_claim_grade".to_string(),
        claim_boundary: format!(
            "Scoped local Vortex preparation spine only: streaming provider/admission/split/write/reopen evidence for flat local SourceState to VortexPreparedState; reopen_verification_status={reopen_verification_status}; no object-store, table, distributed, broad writer, encoded-operator, performance, production, or Spark-replacement claim"
        ),
        fallback_attempted: false,
        external_engine_invoked: false,
    }
}

#[cfg(feature = "vortex-write")]
fn validate_flat_rows(columns: &[String], rows: &[Vec<(String, ScalarValue)>]) -> Result<u64> {
    validate_flat_columns(columns)?;
    for (row_index, row) in rows.iter().enumerate() {
        if row.len() != columns.len() {
            return Err(ShardLoomError::InvalidOperation(format!(
                "local vortex_ingest row {} has {} columns, expected {}; no fallback execution was attempted",
                row_index + 1,
                row.len(),
                columns.len()
            )));
        }
        for (column_index, (name, _value)) in row.iter().enumerate() {
            let expected = &columns[column_index];
            if name != expected {
                return Err(ShardLoomError::InvalidOperation(format!(
                    "local vortex_ingest row {} column {} is '{}', expected '{}'; no fallback execution was attempted",
                    row_index + 1,
                    column_index + 1,
                    name,
                    expected
                )));
            }
        }
    }
    usize_to_u64(rows.len())
}

#[cfg(feature = "vortex-write")]
fn validate_scalar_column_dtype_hints(
    columns: &[String],
    column_dtypes: &[Option<LogicalDType>],
) -> Result<()> {
    if column_dtypes.len() != columns.len() {
        return Err(ShardLoomError::InvalidOperation(format!(
            "local vortex_ingest declared {} column dtype hints for {} columns; no fallback execution was attempted",
            column_dtypes.len(),
            columns.len()
        )));
    }
    Ok(())
}

#[cfg(feature = "vortex-write")]
fn validate_flat_columns(columns: &[String]) -> Result<()> {
    if columns.is_empty() {
        return Err(ShardLoomError::InvalidOperation(
            "local vortex_ingest requires at least one column; no fallback execution was attempted"
                .to_string(),
        ));
    }
    let mut seen = BTreeSet::new();
    for column in columns {
        if column.trim().is_empty() {
            return Err(ShardLoomError::InvalidOperation(
                "local vortex_ingest column names must not be empty; no fallback execution was attempted"
                    .to_string(),
            ));
        }
        if !seen.insert(column) {
            return Err(ShardLoomError::InvalidOperation(format!(
                "local vortex_ingest contains duplicate column '{column}'; no fallback execution was attempted"
            )));
        }
    }
    Ok(())
}

#[cfg(feature = "vortex-write")]
fn scalar_column_families(
    columns: &[String],
    column_dtypes: &[Option<LogicalDType>],
    rows: &[Vec<(String, ScalarValue)>],
) -> Result<Vec<(String, String)>> {
    validate_scalar_column_dtype_hints(columns, column_dtypes)?;
    columns
        .iter()
        .enumerate()
        .map(|(column_index, column)| {
            let mut family = column_dtypes
                .get(column_index)
                .and_then(Option::as_ref)
                .map(|dtype| scalar_family_from_dtype_hint(column, dtype))
                .transpose()?
                .flatten();
            for row in rows {
                let value = &row[column_index].1;
                if matches!(value, ScalarValue::Null) {
                    continue;
                }
                let Some(candidate) = scalar_family(value) else {
                    return Err(ShardLoomError::InvalidOperation(format!(
                        "local vortex_ingest column '{column}' contains unsupported value {}; scoped Vortex ingest admits nullable boolean, int64, uint64, float64, utf8, binary, decimal128, date32, and timestamp_micros columns only when the column family is known; no fallback execution was attempted",
                        value.summary()
                    )));
                };
                if let Some(existing) = family {
                    if let Some(merged) = existing.merge(candidate) {
                        family = Some(merged);
                    } else {
                        let existing = existing.label();
                        let candidate = candidate.label();
                        return Err(ShardLoomError::InvalidOperation(format!(
                            "local vortex_ingest column '{column}' mixes scalar families {existing} and {candidate}; no fallback execution was attempted"
                        )));
                    }
                } else {
                    family = Some(candidate);
                }
            }
            Ok((
                column.clone(),
                family.unwrap_or(ScalarFamily::Utf8).label(),
            ))
        })
        .collect()
}

#[cfg(feature = "vortex-write")]
fn scalar_family_from_dtype_hint(
    column: &str,
    dtype: &LogicalDType,
) -> Result<Option<ScalarFamily>> {
    match dtype {
        LogicalDType::Boolean => Ok(Some(ScalarFamily::Boolean)),
        LogicalDType::Int64 => Ok(Some(ScalarFamily::Int64)),
        LogicalDType::UInt64 => Ok(Some(ScalarFamily::UInt64)),
        LogicalDType::Float64 => Ok(Some(ScalarFamily::Float64)),
        LogicalDType::Utf8 => Ok(Some(ScalarFamily::Utf8)),
        LogicalDType::Binary => Ok(Some(ScalarFamily::Binary)),
        LogicalDType::Date32 => Ok(Some(ScalarFamily::Date32)),
        LogicalDType::TimestampMicros => Ok(Some(ScalarFamily::TimestampMicros)),
        LogicalDType::Extension(value) if value.starts_with("decimal128") => {
            let (precision, scale) =
                scalar_decimal128_dtype_precision_scale(column, value)?.ok_or_else(|| {
                    ShardLoomError::InvalidOperation(format!(
                        "local vortex_ingest column '{column}' has invalid decimal128 dtype hint {value:?}; decimal hints must use decimal128(precision,scale) with 1 <= precision <= 38 and scale <= precision; no fallback execution was attempted"
                    ))
                })?;
            Ok(Some(ScalarFamily::Decimal128 { precision, scale }))
        }
        #[cfg(feature = "universal-format-io")]
        LogicalDType::List => Ok(Some(ScalarFamily::List)),
        #[cfg(feature = "universal-format-io")]
        LogicalDType::Struct => Ok(Some(ScalarFamily::Struct)),
        _ => Ok(None),
    }
}

#[cfg(feature = "vortex-write")]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum ScalarFamily {
    Boolean,
    Int64,
    UInt64,
    Float64,
    Utf8,
    Binary,
    Decimal128 {
        precision: u8,
        scale: u8,
    },
    Date32,
    TimestampMicros,
    #[cfg(feature = "universal-format-io")]
    List,
    #[cfg(feature = "universal-format-io")]
    Struct,
}

#[cfg(feature = "vortex-write")]
impl ScalarFamily {
    fn label(self) -> String {
        match self {
            Self::Boolean => "boolean".to_string(),
            Self::Int64 => "int64".to_string(),
            Self::UInt64 => "uint64".to_string(),
            Self::Float64 => "float64".to_string(),
            Self::Utf8 => "utf8".to_string(),
            Self::Binary => "binary".to_string(),
            Self::Decimal128 { precision, scale } => format!("decimal128({precision},{scale})"),
            Self::Date32 => "date32".to_string(),
            Self::TimestampMicros => "timestamp_micros".to_string(),
            #[cfg(feature = "universal-format-io")]
            Self::List => "list".to_string(),
            #[cfg(feature = "universal-format-io")]
            Self::Struct => "struct".to_string(),
        }
    }

    fn merge(self, candidate: Self) -> Option<Self> {
        if matches!(
            (self, candidate),
            (Self::Float64, Self::Int64 | Self::UInt64)
                | (Self::Int64 | Self::UInt64, Self::Float64)
                | (Self::Int64, Self::UInt64)
                | (Self::UInt64, Self::Int64)
        ) {
            return Some(Self::Float64);
        }
        if self.label_eq(candidate) {
            Some(self)
        } else {
            None
        }
    }

    fn label_eq(self, candidate: Self) -> bool {
        matches!(
            (self, candidate),
            (Self::Boolean, Self::Boolean)
                | (Self::Int64, Self::Int64)
                | (Self::UInt64, Self::UInt64)
                | (Self::Float64, Self::Float64)
                | (Self::Utf8, Self::Utf8)
                | (Self::Binary, Self::Binary)
                | (Self::Date32, Self::Date32)
                | (Self::TimestampMicros, Self::TimestampMicros)
        ) || matches!(
            (self, candidate),
            (
                Self::Decimal128 {
                    precision: left_precision,
                    scale: left_scale,
                },
                Self::Decimal128 {
                    precision: right_precision,
                    scale: right_scale,
                },
            ) if left_precision == right_precision && left_scale == right_scale
        ) || {
            #[cfg(feature = "universal-format-io")]
            {
                matches!(
                    (self, candidate),
                    (Self::List, Self::List) | (Self::Struct, Self::Struct)
                )
            }
            #[cfg(not(feature = "universal-format-io"))]
            {
                false
            }
        }
    }
}

#[cfg(feature = "vortex-write")]
fn scalar_family(value: &ScalarValue) -> Option<ScalarFamily> {
    match value {
        ScalarValue::Boolean(_) => Some(ScalarFamily::Boolean),
        ScalarValue::Int64(_) => Some(ScalarFamily::Int64),
        ScalarValue::UInt64(_) => Some(ScalarFamily::UInt64),
        ScalarValue::Float64(value) if value.is_finite() => Some(ScalarFamily::Float64),
        ScalarValue::Utf8(_) => Some(ScalarFamily::Utf8),
        ScalarValue::Binary(_) => Some(ScalarFamily::Binary),
        ScalarValue::Decimal128 {
            precision, scale, ..
        } if (1..=38).contains(precision) && scale <= precision => Some(ScalarFamily::Decimal128 {
            precision: *precision,
            scale: *scale,
        }),
        ScalarValue::Date32(_) => Some(ScalarFamily::Date32),
        ScalarValue::TimestampMicros(_) => Some(ScalarFamily::TimestampMicros),
        #[cfg(feature = "universal-format-io")]
        ScalarValue::List(_) => Some(ScalarFamily::List),
        #[cfg(feature = "universal-format-io")]
        ScalarValue::Struct(_) => Some(ScalarFamily::Struct),
        #[cfg(not(feature = "universal-format-io"))]
        ScalarValue::List(_) | ScalarValue::Struct(_) => None,
        ScalarValue::Null | ScalarValue::Decimal128 { .. } | ScalarValue::Float64(_) => None,
    }
}

#[cfg(feature = "vortex-write")]
fn scalar_column_families_include_typed_complex(column_families: &[(String, String)]) -> bool {
    column_families
        .iter()
        .any(|(_column, family)| matches!(family.as_str(), "list" | "struct"))
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
struct ColumnarVortexArrayBuild {
    array: vortex::array::ArrayRef,
    column_families: Vec<(String, String)>,
    provider_kind: &'static str,
    provider_surface: &'static str,
    strategy: &'static str,
    manual_scalar_copy_avoided: bool,
}

#[cfg(feature = "vortex-write")]
struct ScalarVortexArrayBuild {
    array: vortex::array::ArrayRef,
    provider_kind: &'static str,
    provider_surface: &'static str,
    strategy: &'static str,
    input_layout: &'static str,
    record_batch_count: usize,
    manual_scalar_copy_avoided: bool,
    vortex_first_decision: &'static str,
    feature_gate: &'static str,
    source_surface: &'static str,
    materialization_boundary_status: &'static str,
    decode_boundary_status: &'static str,
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn flat_columnar_source_to_vortex_struct(
    source: &FlatLocalColumnarSource,
    source_shape: &FlatColumnarSourceShape,
) -> Result<ColumnarVortexArrayBuild> {
    use vortex::array::IntoArray as _;
    use vortex::array::arrays::StructArray;
    use vortex::array::dtype::FieldNames;
    use vortex::array::validity::Validity;

    let column_families = columnar_column_families(source, source_shape)?;
    if !source.batches.is_empty() {
        let array = flat_columnar_source_to_vortex_from_arrow_provider(source, source_shape)?;
        return Ok(ColumnarVortexArrayBuild {
            array,
            column_families,
            provider_kind: "vortex_array_kernel",
            provider_surface: "ArrayRef::from_arrow(RecordBatch)",
            strategy: "vortex_from_arrow_record_batch",
            manual_scalar_copy_avoided: true,
        });
    }

    let fields = column_families
        .iter()
        .zip(&source_shape.projected_columns)
        .map(|((column, family), projected_column)| {
            if let Some(dtype) = projected_column.arrow_dtype_hint.as_ref()
                && nested::family(dtype)?.is_some()
            {
                return Err(ShardLoomError::InvalidOperation(
                    "empty nested columnar input requires an Arrow RecordBatch retaining field nullability; no fallback execution was attempted".into(),
                ));
            }
            let arrays = source
                .batches
                .iter()
                .map(|batch| batch.column(projected_column.reader_index).clone())
                .collect::<Vec<_>>();
            columnar_column_to_vortex_array(column, family, &arrays)
        })
        .collect::<Result<Vec<_>>>()?;
    let array = StructArray::try_new(
        FieldNames::from(
            source
                .materialized_columns
                .iter()
                .map(String::as_str)
                .collect::<Vec<_>>(),
        ),
        fields,
        source.row_count,
        Validity::NonNullable,
    )
    .map_err(vortex_error)?
    .into_array();
    Ok(ColumnarVortexArrayBuild {
        array,
        column_families,
        provider_kind: "shardloom_kernel",
        provider_surface: "shardloom_empty_columnar_struct_builder",
        strategy: "empty_columnar_schema_to_vortex_struct",
        manual_scalar_copy_avoided: false,
    })
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn flat_columnar_source_to_vortex_from_arrow_provider(
    source: &FlatLocalColumnarSource,
    source_shape: &FlatColumnarSourceShape,
) -> Result<vortex::array::ArrayRef> {
    use vortex::array::IntoArray as _;
    use vortex::array::arrays::ChunkedArray;

    let projection_indices = source_shape
        .projected_columns
        .iter()
        .map(|column| column.reader_index)
        .collect::<Vec<_>>();
    let chunks = source
        .batches
        .iter()
        .map(|batch| {
            let projected = batch.project(&projection_indices).map_err(|error| {
                ShardLoomError::InvalidOperation(format!(
                    "local vortex_ingest Arrow RecordBatch projection failed: {error}; no fallback execution was attempted"
                ))
            })?;
            arrow_record_batch_to_vortex_array(projected)
        })
        .collect::<Result<Vec<_>>>()?;
    match chunks.as_slice() {
        [single] => Ok(single.clone()),
        [] => Err(ShardLoomError::InvalidOperation(
            "local vortex_ingest columnar SourceState contained no RecordBatch chunks; no fallback execution was attempted"
                .to_string(),
        )),
        _ => {
            let dtype = chunks[0].dtype().clone();
            Ok(ChunkedArray::try_new(chunks, dtype)
                .map_err(vortex_error)?
                .into_array())
        }
    }
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn columnar_column_families(
    source: &FlatLocalColumnarSource,
    source_shape: &FlatColumnarSourceShape,
) -> Result<Vec<(String, String)>> {
    // No payload exists from which to infer a family. The buffered reader
    // retains canonical Arrow schema hints even when logical hints are absent.
    if source.batches.is_empty() {
        return columnar_column_families_from_schema(source_shape);
    }
    source_shape
        .projected_columns
        .iter()
        .map(|projected_column| {
            let mut family = None;
            for batch in &source.batches {
                nested::validate_field(batch.schema().field(projected_column.reader_index))?;
                let array = batch.column(projected_column.reader_index);
                let candidate = arrow_column_family(&projected_column.column, array.as_ref())?;
                if candidate == "float64" {
                    reject_columnar_non_finite_floats(&projected_column.column, array.as_ref())?;
                }
                if let Some(existing) = family.as_ref() {
                    if existing != &candidate {
                        return Err(ShardLoomError::InvalidOperation(format!(
                            "local vortex_ingest column '{}' mixes columnar families {existing} and {candidate}; no fallback execution was attempted",
                            projected_column.column
                        )));
                    }
                } else {
                    family = Some(candidate);
                }
            }
            Ok((
                projected_column.column.clone(),
                match family {
                    Some(family) => family,
                    None => columnar_family_from_dtype_hint(
                        &projected_column.column,
                        projected_column.dtype_hint.as_ref(),
                    )?,
                }
            ))
        })
        .collect()
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn columnar_column_families_from_schema(
    source_shape: &FlatColumnarSourceShape,
) -> Result<Vec<(String, String)>> {
    source_shape
        .projected_columns
        .iter()
        .map(|projected_column| {
            let family = if let Some(arrow_dtype) = projected_column.arrow_dtype_hint.as_ref() {
                columnar_family_from_arrow_dtype_hint(&projected_column.column, arrow_dtype)?
            } else {
                columnar_family_from_dtype_hint(
                    &projected_column.column,
                    projected_column.dtype_hint.as_ref(),
                )?
            };
            Ok((projected_column.column.clone(), family))
        })
        .collect()
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn columnar_family_from_arrow_dtype_hint(column: &str, dtype: &ArrowDataType) -> Result<String> {
    if let Some(family) = nested::family(dtype)? {
        return Ok(family.to_string());
    }
    if let Some(family) = dictionary_column_family(dtype) {
        return Ok(family.to_string());
    }
    if let Some(family) = decimal128_column_family(column, dtype)? {
        return Ok(family);
    }
    match dtype {
        ArrowDataType::Boolean => Ok("boolean".to_string()),
        ArrowDataType::Int8
        | ArrowDataType::Int16
        | ArrowDataType::Int32
        | ArrowDataType::Int64 => Ok("int64".to_string()),
        ArrowDataType::UInt8
        | ArrowDataType::UInt16
        | ArrowDataType::UInt32
        | ArrowDataType::UInt64 => Ok("uint64".to_string()),
        ArrowDataType::Float32 | ArrowDataType::Float64 => Ok("float64".to_string()),
        ArrowDataType::Utf8 | ArrowDataType::LargeUtf8 | ArrowDataType::Utf8View => {
            Ok("utf8".to_string())
        }
        ArrowDataType::Binary | ArrowDataType::LargeBinary | ArrowDataType::BinaryView => {
            Ok("binary".to_string())
        }
        ArrowDataType::Date32 => Ok("date32".to_string()),
        ArrowDataType::Timestamp(arrow_schema::TimeUnit::Microsecond, _) => {
            Ok("timestamp_micros".to_string())
        }
        _ => Err(ShardLoomError::InvalidOperation(format!(
            "streaming local vortex_ingest column '{column}' has unsupported Arrow type {dtype:?}; scoped Vortex ingest admits supported nullable scalar/dictionary columns and bounded static list/struct payloads with bool, integer, F32/F64, UTF8, binary, Decimal128, Date32 or timezone-free TimestampMicros leaves; no fallback execution was attempted"
        ))),
    }
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn columnar_family_from_dtype_hint(
    column: &str,
    dtype_hint: Option<&LogicalDType>,
) -> Result<String> {
    match dtype_hint {
        Some(LogicalDType::Boolean) => Ok("boolean".to_string()),
        Some(LogicalDType::Int64) => Ok("int64".to_string()),
        Some(LogicalDType::UInt64) => Ok("uint64".to_string()),
        Some(LogicalDType::Float64) => Ok("float64".to_string()),
        Some(LogicalDType::Utf8) | None => Ok("utf8".to_string()),
        Some(LogicalDType::Binary) => Ok("binary".to_string()),
        Some(LogicalDType::Date32) => Ok("date32".to_string()),
        Some(LogicalDType::TimestampMicros) => Ok("timestamp_micros".to_string()),
        Some(LogicalDType::Extension(value)) if value.starts_with("decimal128") => {
            let (precision, scale) =
                scalar_decimal128_dtype_precision_scale(column, value)?.ok_or_else(|| {
                    ShardLoomError::InvalidOperation(format!(
                        "local vortex_ingest column '{column}' has invalid decimal128 dtype hint {value:?}; decimal hints must use decimal128(precision,scale) with 1 <= precision <= 38 and scale <= precision; no fallback execution was attempted"
                    ))
                })?;
            Ok(format!("decimal128({precision},{scale})"))
        }
        Some(dtype) => Err(ShardLoomError::InvalidOperation(format!(
            "local vortex_ingest column '{column}' has unsupported dtype hint {}; scoped Vortex ingest admits supported nullable scalar/dictionary columns and bounded static list/struct payloads with bool, integer, F32/F64, UTF8, binary, Decimal128, Date32 or timezone-free TimestampMicros leaves; no fallback execution was attempted",
            dtype.as_str()
        ))),
    }
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn reject_columnar_non_finite_floats(column: &str, array: &dyn Array) -> Result<()> {
    if let Some(array) = array.as_any().downcast_ref::<Float32Array>() {
        for index in 0..array.len() {
            if array.is_null(index) {
                continue;
            }
            if !array.value(index).is_finite() {
                return Err(ShardLoomError::InvalidOperation(format!(
                    "local vortex_ingest column '{column}' contains non-finite float32; no fallback execution was attempted"
                )));
            }
        }
    } else if let Some(array) = array.as_any().downcast_ref::<Float64Array>() {
        for index in 0..array.len() {
            if array.is_null(index) {
                continue;
            }
            if !array.value(index).is_finite() {
                return Err(ShardLoomError::InvalidOperation(format!(
                    "local vortex_ingest column '{column}' contains non-finite float64; no fallback execution was attempted"
                )));
            }
        }
    }
    Ok(())
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn arrow_column_family(column: &str, array: &dyn Array) -> Result<String> {
    if let Some(family) = nested::family(array.data_type())? {
        nested::validate_values(column, array)?;
        return Ok(family.to_string());
    }
    if let Some(family) = dictionary_column_family(array.data_type()) {
        if family == "dictionary_float64" {
            reject_dictionary_non_finite_float_values(column, array)?;
        }
        return Ok(family.to_string());
    }
    if let Some(family) = decimal128_column_family(column, array.data_type())? {
        return Ok(family);
    }
    if array.as_any().is::<BooleanArray>() {
        return Ok("boolean".to_string());
    }
    if array.as_any().is::<Int8Array>()
        || array.as_any().is::<Int16Array>()
        || array.as_any().is::<Int32Array>()
        || array.as_any().is::<Int64Array>()
    {
        return Ok("int64".to_string());
    }
    if array.as_any().is::<UInt8Array>()
        || array.as_any().is::<UInt16Array>()
        || array.as_any().is::<UInt32Array>()
        || array.as_any().is::<UInt64Array>()
    {
        return Ok("uint64".to_string());
    }
    if array.as_any().is::<Float32Array>() || array.as_any().is::<Float64Array>() {
        return Ok("float64".to_string());
    }
    if array.as_any().is::<StringArray>()
        || array.as_any().is::<LargeStringArray>()
        || array.as_any().is::<StringViewArray>()
    {
        return Ok("utf8".to_string());
    }
    if array.as_any().is::<BinaryArray>()
        || array.as_any().is::<LargeBinaryArray>()
        || array.as_any().is::<BinaryViewArray>()
    {
        return Ok("binary".to_string());
    }
    if array.as_any().is::<Date32Array>() {
        return Ok("date32".to_string());
    }
    if array.as_any().is::<TimestampMicrosecondArray>() {
        return Ok("timestamp_micros".to_string());
    }
    Err(ShardLoomError::InvalidOperation(format!(
        "local vortex_ingest column '{column}' has unsupported Arrow type {:?}; scoped Vortex ingest admits supported nullable scalar/dictionary columns and bounded static list/struct payloads with bool, integer, F32/F64, UTF8, binary, Decimal128, Date32 or timezone-free TimestampMicros leaves; no fallback execution was attempted",
        array.data_type()
    )))
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn dictionary_column_family(dtype: &ArrowDataType) -> Option<&'static str> {
    let ArrowDataType::Dictionary(key_dtype, value_dtype) = dtype else {
        return None;
    };
    if !matches!(
        key_dtype.as_ref(),
        ArrowDataType::Int8
            | ArrowDataType::Int16
            | ArrowDataType::Int32
            | ArrowDataType::Int64
            | ArrowDataType::UInt8
            | ArrowDataType::UInt16
            | ArrowDataType::UInt32
            | ArrowDataType::UInt64
    ) {
        return None;
    }
    match value_dtype.as_ref() {
        ArrowDataType::Utf8 | ArrowDataType::LargeUtf8 | ArrowDataType::Utf8View => {
            Some("dictionary_utf8")
        }
        ArrowDataType::Binary | ArrowDataType::LargeBinary | ArrowDataType::BinaryView => {
            Some("dictionary_binary")
        }
        ArrowDataType::Int8
        | ArrowDataType::Int16
        | ArrowDataType::Int32
        | ArrowDataType::Int64 => Some("dictionary_int64"),
        ArrowDataType::UInt8
        | ArrowDataType::UInt16
        | ArrowDataType::UInt32
        | ArrowDataType::UInt64 => Some("dictionary_uint64"),
        ArrowDataType::Float32 | ArrowDataType::Float64 => Some("dictionary_float64"),
        _ => None,
    }
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn reject_dictionary_non_finite_float_values(column: &str, array: &dyn Array) -> Result<()> {
    let Some(dictionary) = array.as_any_dictionary_opt() else {
        return Ok(());
    };
    let values = dictionary.values();
    if let Some(values) = values.as_any().downcast_ref::<Float32Array>() {
        for index in 0..values.len() {
            if values.is_valid(index) && !values.value(index).is_finite() {
                return Err(dictionary_non_finite_float_error(column, index));
            }
        }
    }
    if let Some(values) = values.as_any().downcast_ref::<Float64Array>() {
        for index in 0..values.len() {
            if values.is_valid(index) && !values.value(index).is_finite() {
                return Err(dictionary_non_finite_float_error(column, index));
            }
        }
    }
    Ok(())
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn dictionary_non_finite_float_error(column: &str, value_index: usize) -> ShardLoomError {
    ShardLoomError::InvalidOperation(format!(
        "local vortex_ingest column '{column}' has non-finite dictionary float value at dictionary index {value_index}; scoped Vortex ingest rejects NaN and infinity before provider execution; no fallback execution was attempted"
    ))
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn decimal128_column_family(column: &str, dtype: &ArrowDataType) -> Result<Option<String>> {
    let ArrowDataType::Decimal128(precision, scale) = dtype else {
        return Ok(None);
    };
    let scale = u8::try_from(*scale).map_err(|_| {
        ShardLoomError::InvalidOperation(format!(
            "local vortex_ingest column '{column}' has unsupported negative decimal128 scale {scale}; scoped columnar decimal128 Vortex ingest requires 0 <= scale <= precision; no fallback execution was attempted"
        ))
    })?;
    if !(1..=38).contains(precision) || scale > *precision {
        return Err(ShardLoomError::InvalidOperation(format!(
            "local vortex_ingest column '{column}' has invalid decimal128({precision},{scale}) Arrow dtype; scoped columnar decimal128 Vortex ingest requires 1 <= precision <= 38 and scale <= precision; no fallback execution was attempted"
        )));
    }
    Ok(Some(format!("decimal128({precision},{scale})")))
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn columnar_column_to_vortex_array(
    column: &str,
    family: &str,
    arrays: &[ArrowArrayRef],
) -> Result<vortex::array::ArrayRef> {
    use vortex::array::IntoArray as _;
    use vortex::array::arrays::{BoolArray, PrimitiveArray, VarBinViewArray};
    use vortex::array::validity::Validity;
    use vortex::buffer::BitBuffer;

    match family {
        "boolean" => Ok(BoolArray::new(
            BitBuffer::from(columnar_boolean_values(column, arrays)?),
            Validity::NonNullable,
        )
        .into_array()),
        "int64" => Ok(columnar_int64_values(column, arrays)?
            .into_iter()
            .collect::<PrimitiveArray>()
            .into_array()),
        "uint64" => Ok(columnar_uint64_values(column, arrays)?
            .into_iter()
            .collect::<PrimitiveArray>()
            .into_array()),
        "float64" => Ok(columnar_float64_values(column, arrays)?
            .into_iter()
            .collect::<PrimitiveArray>()
            .into_array()),
        "utf8" => {
            let values = columnar_utf8_values(column, arrays)?;
            Ok(VarBinViewArray::from_iter_str(values.iter().map(String::as_str)).into_array())
        }
        "binary" => {
            let values = columnar_binary_values(column, arrays)?;
            Ok(VarBinViewArray::from_iter_bin(values.iter().map(Vec::as_slice)).into_array())
        }
        "date32" => Ok(columnar_date32_values(column, arrays)?
            .into_iter()
            .collect::<PrimitiveArray>()
            .into_array()),
        "timestamp_micros" => Ok(columnar_timestamp_micros_values(column, arrays)?
            .into_iter()
            .collect::<PrimitiveArray>()
            .into_array()),
        family if family.starts_with("decimal128(") => {
            empty_columnar_decimal128_to_vortex_array(column, family, arrays)
        }
        other => Err(ShardLoomError::InvalidOperation(format!(
            "local vortex_ingest column '{column}' has unsupported columnar family {other}; no fallback execution was attempted"
        ))),
    }
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn empty_columnar_decimal128_to_vortex_array(
    column: &str,
    family: &str,
    arrays: &[ArrowArrayRef],
) -> Result<vortex::array::ArrayRef> {
    use vortex::array::IntoArray as _;
    use vortex::array::dtype::{DecimalDType, Nullability};

    if !arrays.is_empty() {
        return Err(ShardLoomError::InvalidOperation(format!(
            "local vortex_ingest column '{column}' decimal128 columnar arrays must use the Arrow RecordBatch provider; no fallback execution was attempted"
        )));
    }
    let (precision, scale_u8) = scalar_decimal128_family_precision_scale(family)
        .ok_or_else(|| unexpected_vortex_ingest_family(column, family))?;
    let scale_i8 = i8::try_from(scale_u8).map_err(|_| {
        ShardLoomError::InvalidOperation(format!(
            "local vortex_ingest column '{column}' has unsupported decimal128 scale {scale_u8}; no fallback execution was attempted"
        ))
    })?;
    let mut builder = vortex::array::builders::DecimalBuilder::with_capacity::<i128>(
        0,
        DecimalDType::new(precision, scale_i8),
        Nullability::Nullable,
    );
    Ok(builder.finish_into_decimal().into_array())
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn columnar_boolean_values(column: &str, arrays: &[ArrowArrayRef]) -> Result<Vec<bool>> {
    let mut values = Vec::with_capacity(columnar_array_len(arrays));
    for array in arrays {
        if let Some(array) = array.as_any().downcast_ref::<BooleanArray>() {
            values.extend((0..array.len()).map(|index| array.value(index)));
        } else {
            return Err(unexpected_columnar_array(column, "boolean", array.as_ref()));
        }
    }
    Ok(values)
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn columnar_int64_values(column: &str, arrays: &[ArrowArrayRef]) -> Result<Vec<i64>> {
    let mut values = Vec::with_capacity(columnar_array_len(arrays));
    for array in arrays {
        if let Some(array) = array.as_any().downcast_ref::<Int8Array>() {
            values.extend((0..array.len()).map(|index| i64::from(array.value(index))));
        } else if let Some(array) = array.as_any().downcast_ref::<Int16Array>() {
            values.extend((0..array.len()).map(|index| i64::from(array.value(index))));
        } else if let Some(array) = array.as_any().downcast_ref::<Int32Array>() {
            values.extend((0..array.len()).map(|index| i64::from(array.value(index))));
        } else if let Some(array) = array.as_any().downcast_ref::<Int64Array>() {
            values.extend((0..array.len()).map(|index| array.value(index)));
        } else {
            return Err(unexpected_columnar_array(column, "int64", array.as_ref()));
        }
    }
    Ok(values)
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn columnar_uint64_values(column: &str, arrays: &[ArrowArrayRef]) -> Result<Vec<u64>> {
    let mut values = Vec::with_capacity(columnar_array_len(arrays));
    for array in arrays {
        if let Some(array) = array.as_any().downcast_ref::<UInt8Array>() {
            values.extend((0..array.len()).map(|index| u64::from(array.value(index))));
        } else if let Some(array) = array.as_any().downcast_ref::<UInt16Array>() {
            values.extend((0..array.len()).map(|index| u64::from(array.value(index))));
        } else if let Some(array) = array.as_any().downcast_ref::<UInt32Array>() {
            values.extend((0..array.len()).map(|index| u64::from(array.value(index))));
        } else if let Some(array) = array.as_any().downcast_ref::<UInt64Array>() {
            values.extend((0..array.len()).map(|index| array.value(index)));
        } else {
            return Err(unexpected_columnar_array(column, "uint64", array.as_ref()));
        }
    }
    Ok(values)
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn columnar_float64_values(column: &str, arrays: &[ArrowArrayRef]) -> Result<Vec<f64>> {
    let mut values = Vec::with_capacity(columnar_array_len(arrays));
    for array in arrays {
        if let Some(array) = array.as_any().downcast_ref::<Float32Array>() {
            for index in 0..array.len() {
                let value = array.value(index);
                if !value.is_finite() {
                    return Err(ShardLoomError::InvalidOperation(format!(
                        "local vortex_ingest column '{column}' contains non-finite float32; no fallback execution was attempted"
                    )));
                }
                values.push(f64::from(value));
            }
        } else if let Some(array) = array.as_any().downcast_ref::<Float64Array>() {
            for index in 0..array.len() {
                let value = array.value(index);
                if !value.is_finite() {
                    return Err(ShardLoomError::InvalidOperation(format!(
                        "local vortex_ingest column '{column}' contains non-finite float64; no fallback execution was attempted"
                    )));
                }
                values.push(value);
            }
        } else {
            return Err(unexpected_columnar_array(column, "float64", array.as_ref()));
        }
    }
    Ok(values)
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn columnar_utf8_values(column: &str, arrays: &[ArrowArrayRef]) -> Result<Vec<String>> {
    let mut values = Vec::with_capacity(columnar_array_len(arrays));
    for array in arrays {
        if let Some(array) = array.as_any().downcast_ref::<StringArray>() {
            values.extend((0..array.len()).map(|index| array.value(index).to_string()));
        } else if let Some(array) = array.as_any().downcast_ref::<LargeStringArray>() {
            values.extend((0..array.len()).map(|index| array.value(index).to_string()));
        } else if let Some(array) = array.as_any().downcast_ref::<StringViewArray>() {
            values.extend((0..array.len()).map(|index| array.value(index).to_string()));
        } else {
            return Err(unexpected_columnar_array(column, "utf8", array.as_ref()));
        }
    }
    Ok(values)
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn columnar_binary_values(column: &str, arrays: &[ArrowArrayRef]) -> Result<Vec<Vec<u8>>> {
    let mut values = Vec::with_capacity(columnar_array_len(arrays));
    for array in arrays {
        if let Some(array) = array.as_any().downcast_ref::<BinaryArray>() {
            values.extend((0..array.len()).map(|index| array.value(index).to_vec()));
        } else if let Some(array) = array.as_any().downcast_ref::<LargeBinaryArray>() {
            values.extend((0..array.len()).map(|index| array.value(index).to_vec()));
        } else if let Some(array) = array.as_any().downcast_ref::<BinaryViewArray>() {
            values.extend((0..array.len()).map(|index| array.value(index).to_vec()));
        } else {
            return Err(unexpected_columnar_array(column, "binary", array.as_ref()));
        }
    }
    Ok(values)
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn columnar_date32_values(column: &str, arrays: &[ArrowArrayRef]) -> Result<Vec<i32>> {
    let mut values = Vec::with_capacity(columnar_array_len(arrays));
    for array in arrays {
        if let Some(array) = array.as_any().downcast_ref::<Date32Array>() {
            values.extend((0..array.len()).map(|index| array.value(index)));
        } else {
            return Err(unexpected_columnar_array(column, "date32", array.as_ref()));
        }
    }
    Ok(values)
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn columnar_timestamp_micros_values(column: &str, arrays: &[ArrowArrayRef]) -> Result<Vec<i64>> {
    let mut values = Vec::with_capacity(columnar_array_len(arrays));
    for array in arrays {
        if let Some(array) = array.as_any().downcast_ref::<TimestampMicrosecondArray>() {
            values.extend((0..array.len()).map(|index| array.value(index)));
        } else {
            return Err(unexpected_columnar_array(
                column,
                "timestamp_micros",
                array.as_ref(),
            ));
        }
    }
    Ok(values)
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn columnar_array_len(arrays: &[ArrowArrayRef]) -> usize {
    arrays.iter().map(arrow_array::Array::len).sum()
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn unexpected_columnar_array(column: &str, family: &str, array: &dyn Array) -> ShardLoomError {
    ShardLoomError::InvalidOperation(format!(
        "local vortex_ingest column '{column}' expected {family}, found Arrow type {:?}; no fallback execution was attempted",
        array.data_type()
    ))
}

#[cfg(feature = "vortex-write")]
fn flat_rows_to_vortex_struct(
    columns: &[String],
    column_dtypes: &[Option<LogicalDType>],
    #[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
    column_arrow_dtypes: &[Option<ArrowDataType>],
    rows: &[Vec<(String, ScalarValue)>],
    column_families: &[(String, String)],
) -> Result<ScalarVortexArrayBuild> {
    use vortex::array::IntoArray as _;
    use vortex::array::arrays::StructArray;
    use vortex::array::dtype::FieldNames;
    use vortex::array::validity::Validity;

    if scalar_column_families_include_typed_complex(column_families) {
        let array = scalar_rows_to_vortex_from_arrow_provider(
            columns,
            column_dtypes,
            #[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
            column_arrow_dtypes,
            rows,
        )?;
        return Ok(ScalarVortexArrayBuild {
            array,
            provider_kind: "vortex_array_kernel",
            provider_surface: "ArrayRef::from_arrow(RecordBatch)",
            strategy: "scalar_rows_to_arrow_record_batch_to_vortex",
            input_layout: "materialized_rows_to_arrow_record_batch",
            record_batch_count: usize::from(!rows.is_empty()),
            manual_scalar_copy_avoided: false,
            vortex_first_decision: "use_vortex_native_provider",
            feature_gate: "vortex-write,universal-format-io",
            source_surface: "local_scalar_rows_with_inferable_typed_nested_values",
            materialization_boundary_status: "materialized_scalar_rows_to_arrow_record_batch_before_vortex_array_provider",
            decode_boundary_status: "no_external_decode_after_shardloom_scalar_result_batch_state",
        });
    }

    let fields = column_families
        .iter()
        .enumerate()
        .map(|(column_index, (_column, family))| {
            column_to_vortex_array(&columns[column_index], column_index, family, rows)
        })
        .collect::<Result<Vec<_>>>()?;

    let array = StructArray::try_new(
        FieldNames::from(columns.iter().map(String::as_str).collect::<Vec<_>>()),
        fields,
        rows.len(),
        Validity::NonNullable,
    )
    .map_err(vortex_error)?
    .into_array();
    Ok(ScalarVortexArrayBuild {
        array,
        provider_kind: "shardloom_kernel",
        provider_surface: "shardloom_scalar_rows_to_vortex_struct",
        strategy: "scalar_rows_to_vortex_struct",
        input_layout: "materialized_rows",
        record_batch_count: 0,
        manual_scalar_copy_avoided: false,
        vortex_first_decision: "implement_shardloom_kernel",
        feature_gate: "vortex-write",
        source_surface: "local_text_source_state_scalar_rows",
        materialization_boundary_status: "materialized_scalar_rows_before_vortex_write",
        decode_boundary_status: "text_source_decoded_by_shardloom_adapter",
    })
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
fn scalar_rows_to_vortex_from_arrow_provider(
    columns: &[String],
    column_dtypes: &[Option<LogicalDType>],
    column_arrow_dtypes: &[Option<ArrowDataType>],
    rows: &[Vec<(String, ScalarValue)>],
) -> Result<vortex::array::ArrayRef> {
    let batch = crate::universal_format_io::flat_rows_to_record_batch_with_dtypes(
        columns,
        column_dtypes,
        column_arrow_dtypes,
        rows,
        "local Vortex typed nested output",
    )?;
    arrow_record_batch_to_vortex_array(batch)
}

#[cfg(all(feature = "vortex-write", not(feature = "universal-format-io")))]
fn scalar_rows_to_vortex_from_arrow_provider(
    _columns: &[String],
    _column_dtypes: &[Option<LogicalDType>],
    _rows: &[Vec<(String, ScalarValue)>],
) -> Result<vortex::array::ArrayRef> {
    Err(ShardLoomError::InvalidOperation(
        "local vortex_ingest typed nested output requires --features vortex-write,universal-format-io; no fallback execution was attempted"
            .to_string(),
    ))
}

#[cfg(feature = "vortex-write")]
fn column_to_vortex_array(
    column: &str,
    column_index: usize,
    family: &str,
    rows: &[Vec<(String, ScalarValue)>],
) -> Result<vortex::array::ArrayRef> {
    match family {
        "boolean" => scalar_boolean_to_vortex_array(column, column_index, family, rows),
        "int64" => scalar_primitive_to_vortex_array(column_index, rows, |value| match value {
            ScalarValue::Int64(value) => Ok(*value),
            value => Err(unexpected_vortex_ingest_value(column, family, value)),
        }),
        "uint64" => scalar_primitive_to_vortex_array(column_index, rows, |value| match value {
            ScalarValue::UInt64(value) => Ok(*value),
            value => Err(unexpected_vortex_ingest_value(column, family, value)),
        }),
        "float64" => scalar_primitive_to_vortex_array(column_index, rows, |value| match value {
            ScalarValue::Float64(value) if value.is_finite() => Ok(*value),
            ScalarValue::Int64(value) => Ok(int64_to_float64_for_ingest(*value)),
            ScalarValue::UInt64(value) => Ok(uint64_to_float64_for_ingest(*value)),
            value => Err(unexpected_vortex_ingest_value(column, family, value)),
        }),
        "utf8" => scalar_utf8_to_vortex_array(column, column_index, family, rows),
        "binary" => scalar_binary_to_vortex_array(column, column_index, family, rows),
        "date32" => scalar_primitive_to_vortex_array(column_index, rows, |value| match value {
            ScalarValue::Date32(value) => Ok(*value),
            value => Err(unexpected_vortex_ingest_value(column, family, value)),
        }),
        "timestamp_micros" => {
            scalar_primitive_to_vortex_array(column_index, rows, |value| match value {
                ScalarValue::TimestampMicros(value) => Ok(*value),
                value => Err(unexpected_vortex_ingest_value(column, family, value)),
            })
        }
        family if family.starts_with("decimal128(") => {
            scalar_decimal128_to_vortex_array(column, column_index, family, rows)
        }
        other => Err(ShardLoomError::InvalidOperation(format!(
            "local vortex_ingest column '{column}' has unsupported scalar family {other}; no fallback execution was attempted"
        ))),
    }
}

#[cfg(feature = "vortex-write")]
#[allow(clippy::cast_precision_loss)]
fn int64_to_float64_for_ingest(value: i64) -> f64 {
    value as f64
}

#[cfg(feature = "vortex-write")]
#[allow(clippy::cast_precision_loss)]
fn uint64_to_float64_for_ingest(value: u64) -> f64 {
    value as f64
}

#[cfg(feature = "vortex-write")]
fn scalar_boolean_to_vortex_array(
    column: &str,
    column_index: usize,
    family: &str,
    rows: &[Vec<(String, ScalarValue)>],
) -> Result<vortex::array::ArrayRef> {
    use vortex::array::IntoArray as _;
    use vortex::array::arrays::BoolArray;

    if rows
        .iter()
        .any(|row| matches!(row[column_index].1, ScalarValue::Null))
    {
        let values = rows
            .iter()
            .map(|row| match &row[column_index].1 {
                ScalarValue::Boolean(value) => Ok(Some(*value)),
                ScalarValue::Null => Ok(None),
                value => Err(unexpected_vortex_ingest_value(column, family, value)),
            })
            .collect::<Result<Vec<_>>>()?;
        return Ok(BoolArray::from_iter(values).into_array());
    }

    let values = rows
        .iter()
        .map(|row| match &row[column_index].1 {
            ScalarValue::Boolean(value) => Ok(*value),
            value => Err(unexpected_vortex_ingest_value(column, family, value)),
        })
        .collect::<Result<Vec<_>>>()?;
    Ok(BoolArray::from_iter(values).into_array())
}

#[cfg(feature = "vortex-write")]
fn scalar_primitive_to_vortex_array<T>(
    column_index: usize,
    rows: &[Vec<(String, ScalarValue)>],
    value_from_scalar: impl Fn(&ScalarValue) -> Result<T>,
) -> Result<vortex::array::ArrayRef>
where
    T: vortex::array::dtype::NativePType,
{
    use vortex::array::IntoArray as _;
    use vortex::array::arrays::PrimitiveArray;

    if rows
        .iter()
        .any(|row| matches!(row[column_index].1, ScalarValue::Null))
    {
        let values = rows
            .iter()
            .map(|row| match &row[column_index].1 {
                ScalarValue::Null => Ok(None),
                value => value_from_scalar(value).map(Some),
            })
            .collect::<Result<Vec<_>>>()?;
        return Ok(PrimitiveArray::from_option_iter(values).into_array());
    }

    Ok(rows
        .iter()
        .map(|row| value_from_scalar(&row[column_index].1))
        .collect::<Result<Vec<_>>>()?
        .into_iter()
        .collect::<PrimitiveArray>()
        .into_array())
}

#[cfg(feature = "vortex-write")]
fn scalar_utf8_to_vortex_array(
    column: &str,
    column_index: usize,
    family: &str,
    rows: &[Vec<(String, ScalarValue)>],
) -> Result<vortex::array::ArrayRef> {
    use vortex::array::IntoArray as _;
    use vortex::array::arrays::VarBinViewArray;

    if rows
        .iter()
        .any(|row| matches!(row[column_index].1, ScalarValue::Null))
    {
        let values = rows
            .iter()
            .map(|row| match &row[column_index].1 {
                ScalarValue::Utf8(value) => Ok(Some(value.as_str())),
                ScalarValue::Null => Ok(None),
                value => Err(unexpected_vortex_ingest_value(column, family, value)),
            })
            .collect::<Result<Vec<_>>>()?;
        return Ok(VarBinViewArray::from_iter_nullable_str(values).into_array());
    }

    let values = rows
        .iter()
        .map(|row| match &row[column_index].1 {
            ScalarValue::Utf8(value) => Ok(value.as_str()),
            value => Err(unexpected_vortex_ingest_value(column, family, value)),
        })
        .collect::<Result<Vec<_>>>()?;
    Ok(VarBinViewArray::from_iter_str(values).into_array())
}

#[cfg(feature = "vortex-write")]
fn scalar_binary_to_vortex_array(
    column: &str,
    column_index: usize,
    family: &str,
    rows: &[Vec<(String, ScalarValue)>],
) -> Result<vortex::array::ArrayRef> {
    use vortex::array::IntoArray as _;
    use vortex::array::arrays::VarBinViewArray;

    if rows
        .iter()
        .any(|row| matches!(row[column_index].1, ScalarValue::Null))
    {
        let values = rows
            .iter()
            .map(|row| match &row[column_index].1 {
                ScalarValue::Binary(value) => Ok(Some(value.as_slice())),
                ScalarValue::Null => Ok(None),
                value => Err(unexpected_vortex_ingest_value(column, family, value)),
            })
            .collect::<Result<Vec<_>>>()?;
        return Ok(VarBinViewArray::from_iter_nullable_bin(values).into_array());
    }

    let values = rows
        .iter()
        .map(|row| match &row[column_index].1 {
            ScalarValue::Binary(value) => Ok(value.as_slice()),
            value => Err(unexpected_vortex_ingest_value(column, family, value)),
        })
        .collect::<Result<Vec<_>>>()?;
    Ok(VarBinViewArray::from_iter_bin(values).into_array())
}

#[cfg(feature = "vortex-write")]
fn scalar_decimal128_to_vortex_array(
    column: &str,
    column_index: usize,
    family: &str,
    rows: &[Vec<(String, ScalarValue)>],
) -> Result<vortex::array::ArrayRef> {
    use vortex::array::IntoArray as _;
    use vortex::array::builders::ArrayBuilder as _;
    use vortex::array::dtype::Nullability;

    let (precision, scale_u8) = scalar_decimal128_family_precision_scale(family)
        .ok_or_else(|| unexpected_vortex_ingest_family(column, family))?;
    let scale_i8 = i8::try_from(scale_u8).map_err(|_| {
        ShardLoomError::InvalidOperation(format!(
            "local vortex_ingest column '{column}' has unsupported decimal128 scale {scale_u8}; no fallback execution was attempted"
        ))
    })?;
    let nullability = if rows
        .iter()
        .any(|row| matches!(row[column_index].1, ScalarValue::Null))
    {
        Nullability::Nullable
    } else {
        Nullability::NonNullable
    };
    let mut builder = vortex::array::builders::DecimalBuilder::with_capacity::<i128>(
        rows.len(),
        vortex::array::dtype::DecimalDType::new(precision, scale_i8),
        nullability,
    );
    for row in rows {
        match &row[column_index].1 {
            ScalarValue::Decimal128 {
                value,
                precision: value_precision,
                scale: value_scale,
            } if *value_precision == precision && *value_scale == scale_u8 => {
                builder.append_value(*value);
            }
            ScalarValue::Null => builder.append_null(),
            value => return Err(unexpected_vortex_ingest_value(column, family, value)),
        }
    }
    Ok(builder.finish_into_decimal().into_array())
}

#[cfg(feature = "vortex-write")]
fn scalar_decimal128_dtype_precision_scale(column: &str, value: &str) -> Result<Option<(u8, u8)>> {
    if !value.starts_with("decimal128") {
        return Ok(None);
    }
    let invalid_decimal_hint = || {
        ShardLoomError::InvalidOperation(format!(
            "local vortex_ingest column '{column}' has invalid decimal128 dtype hint {value:?}; decimal hints must use decimal128(precision,scale) with 1 <= precision <= 38 and scale <= precision; no fallback execution was attempted"
        ))
    };
    let args = value
        .strip_prefix("decimal128(")
        .and_then(|rest| rest.strip_suffix(')'))
        .ok_or_else(invalid_decimal_hint)?;
    let (precision_raw, scale_raw) = args.split_once(',').ok_or_else(invalid_decimal_hint)?;
    let precision = precision_raw
        .trim()
        .parse::<u8>()
        .map_err(|_| invalid_decimal_hint())?;
    let scale = scale_raw
        .trim()
        .parse::<u8>()
        .map_err(|_| invalid_decimal_hint())?;
    if precision == 0 || precision > 38 || scale > precision {
        return Err(invalid_decimal_hint());
    }
    Ok(Some((precision, scale)))
}

#[cfg(feature = "vortex-write")]
fn scalar_decimal128_family_precision_scale(family: &str) -> Option<(u8, u8)> {
    let args = family
        .strip_prefix("decimal128(")
        .and_then(|value| value.strip_suffix(')'))?;
    let (precision, scale) = args.split_once(',')?;
    let precision = precision.parse::<u8>().ok()?;
    let scale = scale.parse::<u8>().ok()?;
    if !(1..=38).contains(&precision) || scale > precision {
        return None;
    }
    Some((precision, scale))
}

#[cfg(feature = "vortex-write")]
fn unexpected_vortex_ingest_family(column: &str, family: &str) -> ShardLoomError {
    ShardLoomError::InvalidOperation(format!(
        "local vortex_ingest column '{column}' has unsupported scalar family {family}; no fallback execution was attempted"
    ))
}

#[cfg(feature = "vortex-write")]
fn unexpected_vortex_ingest_value(
    column: &str,
    family: &str,
    value: &ScalarValue,
) -> ShardLoomError {
    ShardLoomError::InvalidOperation(format!(
        "local vortex_ingest column '{column}' expected {family}, found {}; no fallback execution was attempted",
        value.summary()
    ))
}

#[cfg(feature = "vortex-write")]
struct LocalVortexWriteResult {
    writer_row_count: u64,
    bytes_written: u64,
    artifact_digest: String,
    artifact_digest_source: String,
    digest_micros: u128,
    write_micros: u128,
    writer_context_open_micros: u128,
    writer_context_reuse_status: String,
    writer_layout_strategy_applied: String,
    writer_coalescing_policy_status: String,
    writer_layout_row_block_size: usize,
    writer_layout_block_target_bytes: u64,
    writer_compression_policy: String,
    writer_compression_concurrency: usize,
    writer_stats_concurrency: usize,
    writer_runtime_kind: String,
    writer_runtime_requested_parallelism: usize,
    writer_runtime_applied_parallelism: usize,
    writer_runtime_background_workers: usize,
    writer_profile_selection_reason: String,
    writer_profile_regression_guard: String,
    vortex_segment_write_micros: u128,
    vortex_compression_micros: u128,
    vortex_encode_write_micros: u128,
    workspace_stage_micros: u128,
    vortex_final_commit_micros: u128,
    stage_work: VortexIngestStageReport,
    workspace_write_report: WorkspaceSafeLocalWriteReport,
}

#[cfg(feature = "vortex-write")]
struct LocalVortexWriteContext {
    runtime: vortex::io::runtime::current::CurrentThreadRuntime,
    session: vortex::session::VortexSession,
    open_micros: u128,
    writes_started: Cell<u64>,
    shared_ingest_drivers: bool,
}

#[cfg(feature = "vortex-write")]
#[derive(Debug, Clone, PartialEq, Eq)]
struct LocalVortexWriterRuntimePolicy {
    kind: &'static str,
    requested_parallelism: usize,
    applied_parallelism: usize,
    background_workers: usize,
}

#[cfg(feature = "vortex-write")]
impl LocalVortexWriteContext {
    fn open() -> Self {
        use vortex::VortexSessionDefault as _;
        use vortex::io::runtime::BlockingRuntime as _;
        use vortex::io::runtime::current::CurrentThreadRuntime;
        use vortex::io::session::RuntimeSessionExt as _;
        use vortex::session::VortexSession;

        let open_start = Instant::now();
        let runtime = CurrentThreadRuntime::new();
        let session = VortexSession::default().with_handle(runtime.handle());
        Self {
            runtime,
            session,
            open_micros: open_start.elapsed().as_micros(),
            writes_started: Cell::new(0),
            shared_ingest_drivers: false,
        }
    }

    #[cfg(feature = "universal-format-io")]
    fn for_ingest(runtime: &crate::ingest_runtime::IngestRuntime) -> Self {
        use vortex::{
            VortexSessionDefault as _, io::runtime::BlockingRuntime as _,
            io::session::RuntimeSessionExt as _,
        };
        let started = Instant::now();
        let runtime = runtime.runtime().clone();
        let session = vortex::session::VortexSession::default().with_handle(runtime.handle());
        Self {
            runtime,
            session,
            open_micros: started.elapsed().as_micros(),
            writes_started: Cell::new(0),
            shared_ingest_drivers: true,
        }
    }

    fn next_reuse_status(&self) -> &'static str {
        if self.shared_ingest_drivers {
            return "artifact_source_conversion_writer_share_native_runtime";
        }
        let previous = self.writes_started.get();
        self.writes_started.set(previous.saturating_add(1));
        if previous == 0 {
            "thread_local_write_context_opened_for_first_artifact"
        } else {
            "thread_local_write_context_reused_for_artifact"
        }
    }

    fn apply_runtime_policy(
        &self,
        layout_write_decision: &VortexLayoutWriteRuntimeDecision,
    ) -> Result<(
        LocalVortexWriterRuntimePolicy,
        Option<crate::resident_worker_group::ResidentWorkerGroup>,
    )> {
        let requested_parallelism = layout_write_decision
            .writer_runtime_requested_parallelism
            .max(1);
        let applied_parallelism = layout_write_decision
            .writer_runtime_applied_parallelism
            .max(1);
        let background_workers = applied_parallelism.saturating_sub(1);
        let drivers = if self.shared_ingest_drivers {
            None
        } else {
            Some(crate::resident_worker_group::ResidentWorkerGroup::new(&self.runtime, background_workers)
            .map_err(|error| ShardLoomError::InvalidOperation(format!(
                "failed to start owned native ingest CPU drivers: {error}; all started drivers joined; no fallback execution was attempted"
            )))?)
        };
        Ok((
            LocalVortexWriterRuntimePolicy {
                kind: if self.shared_ingest_drivers {
                    "vortex_shared_ingest_runtime"
                } else {
                    writer_runtime_kind(background_workers)
                },
                requested_parallelism,
                applied_parallelism,
                background_workers,
            },
            drivers,
        ))
    }

    fn write_array(
        &self,
        path: &Path,
        array: &vortex::array::ArrayRef,
        allow_overwrite: bool,
        layout_write_decision: &VortexLayoutWriteRuntimeDecision,
        writer_context_reuse_status: impl Into<String>,
    ) -> Result<LocalVortexWriteResult> {
        let workspace_root = shardloom_core::infer_local_output_workspace_root(path)?;
        let write_start = Instant::now();
        let expected_rows = usize_to_u64(array.len())?;
        let mut vortex_segment_write_micros = 0;
        let mut writer_layout_strategy_applied =
            vortex_writer_layout_strategy_applied(layout_write_decision).to_string();
        let mut writer_coalescing_policy_status =
            vortex_writer_coalescing_policy_status(layout_write_decision).to_string();
        let writer_layout_row_block_size = vortex_writer_row_block_size(layout_write_decision);
        let writer_layout_block_target_bytes =
            vortex_writer_block_target_bytes(layout_write_decision);
        let mut writer_compression_policy =
            vortex_writer_compression_policy(layout_write_decision).to_string();
        let writer_compression_concurrency =
            vortex_writer_compression_concurrency(layout_write_decision);
        let writer_stats_concurrency = vortex_writer_stats_concurrency(layout_write_decision);
        let (writer_runtime_policy, _drivers) = self.apply_runtime_policy(layout_write_decision)?;
        let writer_profile_selection_reason =
            vortex_writer_profile_selection_reason(layout_write_decision).to_string();
        let writer_profile_regression_guard =
            vortex_writer_profile_regression_guard(layout_write_decision).to_string();
        let writer_stage_timing = VortexWriterStageTiming::default();
        nested_layout::append_evidence(
            array.dtype(),
            &mut writer_layout_strategy_applied,
            &mut writer_coalescing_policy_status,
            &mut writer_compression_policy,
        );
        let write_options = self.write_options_for_decision(
            layout_write_decision,
            &writer_stage_timing,
            array.dtype(),
        );
        let (summary, workspace_write_report) =
            shardloom_core::write_workspace_safe_bytes_with_validated_producer(
                workspace_root,
                path,
                allow_overwrite,
                "local vortex_ingest artifact",
                |writer| {
                    let segment_write_start = Instant::now();
                    let result = write_options
                        .blocking(&self.runtime)
                        .write(writer, array.to_array_iterator())
                        .map_err(vortex_error);
                    vortex_segment_write_micros = segment_write_start.elapsed().as_micros();
                    result
                },
                |summary| {
                    if summary.row_count() != expected_rows {
                        return Err(ShardLoomError::InvalidOperation(format!(
                            "local vortex_ingest writer row count mismatch: wrote {}, expected {}; staging cleanup attempted; no fallback execution was attempted",
                            summary.row_count(),
                            expected_rows
                        )));
                    }
                    Ok(())
                },
            )?;
        let bytes_written = workspace_write_report.bytes_written;
        let write_micros = write_start.elapsed().as_micros();
        let workspace_stage_micros = write_micros.saturating_sub(vortex_segment_write_micros);
        let vortex_compression_micros = writer_stage_timing.compression_micros();
        // Inclusive measured provider writer wall. Compression work spans can
        // overlap, so subtracting their sum cannot produce an elapsed duration.
        let vortex_encode_write_micros = vortex_segment_write_micros;
        Ok(LocalVortexWriteResult {
            writer_row_count: summary.row_count(),
            bytes_written,
            artifact_digest: workspace_write_report.output_digest.clone(),
            artifact_digest_source: "workspace_safe_streaming_sha256_digest".to_string(),
            digest_micros: 0,
            write_micros,
            writer_context_open_micros: self.open_micros,
            writer_context_reuse_status: writer_context_reuse_status.into(),
            writer_layout_strategy_applied,
            writer_coalescing_policy_status,
            writer_layout_row_block_size,
            writer_layout_block_target_bytes,
            writer_compression_policy,
            writer_compression_concurrency,
            writer_stats_concurrency,
            writer_runtime_kind: writer_runtime_policy.kind.to_string(),
            writer_runtime_requested_parallelism: writer_runtime_policy.requested_parallelism,
            writer_runtime_applied_parallelism: writer_runtime_policy.applied_parallelism,
            writer_runtime_background_workers: writer_runtime_policy.background_workers,
            writer_profile_selection_reason,
            writer_profile_regression_guard,
            vortex_segment_write_micros,
            vortex_compression_micros,
            vortex_encode_write_micros,
            workspace_stage_micros,
            vortex_final_commit_micros: workspace_stage_micros,
            stage_work: writer_stage_timing.stages.snapshot(),
            workspace_write_report,
        })
    }

    #[cfg(feature = "universal-format-io")]
    #[allow(clippy::too_many_arguments)]
    // Keep resource and source-generation admission explicit.
    // Source-generation validation and embedded provenance share this commit boundary.
    #[allow(clippy::too_many_lines)]
    fn write_array_iterator<I>(
        &self,
        path: &Path,
        iter: I,
        allow_overwrite: bool,
        layout_write_decision: &VortexLayoutWriteRuntimeDecision,
        expected_rows: Option<u64>,
        native_memory: Option<&NativeIngestMemory>,
        source_identities: &[Arc<SourceIdentity>],
        writer_input_lookahead: Option<WriterInputLookahead>,
        prepared_source_binding: Option<&str>,
    ) -> Result<LocalVortexWriteResult>
    where
        I: vortex::array::iter::ArrayIterator
            + futures::Stream<Item = vortex::error::VortexResult<vortex::array::ArrayRef>>
            + Unpin
            + Send
            + 'static,
    {
        let writer_context_reuse_status = self.next_reuse_status();
        let workspace_root = shardloom_core::infer_local_output_workspace_root(path)?;
        let write_start = Instant::now();
        let mut vortex_segment_write_micros = 0;
        let mut writer_layout_strategy_applied =
            vortex_writer_layout_strategy_applied(layout_write_decision).to_string();
        let mut writer_coalescing_policy_status =
            vortex_writer_coalescing_policy_status(layout_write_decision).to_string();
        let writer_layout_row_block_size = vortex_writer_row_block_size(layout_write_decision);
        let writer_layout_block_target_bytes =
            vortex_writer_block_target_bytes(layout_write_decision);
        let mut writer_compression_policy =
            vortex_writer_compression_policy(layout_write_decision).to_string();
        let writer_compression_concurrency =
            vortex_writer_compression_concurrency(layout_write_decision);
        let writer_stats_concurrency = vortex_writer_stats_concurrency(layout_write_decision);
        let (writer_runtime_policy, _drivers) = self.apply_runtime_policy(layout_write_decision)?;
        let writer_profile_selection_reason =
            vortex_writer_profile_selection_reason(layout_write_decision).to_string();
        let writer_profile_regression_guard =
            vortex_writer_profile_regression_guard(layout_write_decision).to_string();
        let writer_stage_timing = VortexWriterStageTiming::default();
        if native_memory.is_some() {
            writer_layout_strategy_applied.push_str(";bounded_source_batch_subtrees");
            writer_coalescing_policy_status =
                "native_within_source_batch_only;cross_batch_coalescing_disabled".to_string();
        }
        nested_layout::append_evidence(
            iter.dtype(),
            &mut writer_layout_strategy_applied,
            &mut writer_coalescing_policy_status,
            &mut writer_compression_policy,
        );
        let (write_options, footer_layout_evidence) = self.stream_write_options_for_decision(
            layout_write_decision,
            &writer_stage_timing,
            native_memory,
            iter.dtype(),
            writer_input_lookahead,
        )?;
        #[cfg(unix)]
        let write_options = if let Some(binding) = prepared_source_binding {
            write_options.with_metadata_segment(
                crate::prepared_source_binding::KEY,
                binding.as_bytes().to_vec(),
            )
        } else {
            write_options
        };
        #[cfg(not(unix))]
        let _ = prepared_source_binding;
        let (summary, workspace_write_report) =
            shardloom_core::write_workspace_safe_bytes_with_validated_producer(
                workspace_root,
                path,
                allow_overwrite,
                "streaming local vortex_ingest artifact",
                |writer| {
                    let segment_write_start = Instant::now();
                    let result = if self.shared_ingest_drivers {
                        shared_stream::write(&self.runtime, write_options, writer, iter)
                    } else {
                        write_options.blocking(&self.runtime).write(writer, iter)
                    }
                    .map_err(vortex_error);
                    vortex_segment_write_micros = segment_write_start.elapsed().as_micros();
                    result
                },
                |summary| {
                    if let Some(expected_rows) = expected_rows
                        && summary.row_count() != expected_rows
                    {
                        return Err(ShardLoomError::InvalidOperation(format!(
                            "streaming local vortex_ingest writer row count mismatch: wrote {}, expected {expected_rows}; staging cleanup attempted; no fallback execution was attempted",
                            summary.row_count()
                        )));
                    }
                    for identity in source_identities {
                        identity.validate()?;
                    }
                    #[cfg(unix)]
                    if let Some(binding) = prepared_source_binding {
                        crate::prepared_source_binding::validate(binding)?;
                    }
                    Ok(())
                },
            )?;
        footer_layout_evidence.append_to(&mut writer_layout_strategy_applied);
        let bytes_written = workspace_write_report.bytes_written;
        let write_micros = write_start.elapsed().as_micros();
        let workspace_stage_micros = write_micros.saturating_sub(vortex_segment_write_micros);
        let vortex_compression_micros = writer_stage_timing.compression_micros();
        // Keep the historical field name with an explicit corrected scope.
        let vortex_encode_write_micros = vortex_segment_write_micros;
        Ok(LocalVortexWriteResult {
            writer_row_count: summary.row_count(),
            bytes_written,
            artifact_digest: workspace_write_report.output_digest.clone(),
            artifact_digest_source: "workspace_safe_streaming_sha256_digest".to_string(),
            digest_micros: 0,
            write_micros,
            writer_context_open_micros: self.open_micros,
            writer_context_reuse_status: writer_context_reuse_status.into(),
            writer_layout_strategy_applied,
            writer_coalescing_policy_status,
            writer_layout_row_block_size,
            writer_layout_block_target_bytes,
            writer_compression_policy,
            writer_compression_concurrency,
            writer_stats_concurrency,
            writer_runtime_kind: writer_runtime_policy.kind.to_string(),
            writer_runtime_requested_parallelism: writer_runtime_policy.requested_parallelism,
            writer_runtime_applied_parallelism: writer_runtime_policy.applied_parallelism,
            writer_runtime_background_workers: writer_runtime_policy.background_workers,
            writer_profile_selection_reason,
            writer_profile_regression_guard,
            vortex_segment_write_micros,
            vortex_compression_micros,
            vortex_encode_write_micros,
            workspace_stage_micros,
            vortex_final_commit_micros: workspace_stage_micros,
            stage_work: writer_stage_timing.stages.snapshot(),
            workspace_write_report,
        })
    }

    #[cfg(feature = "universal-format-io")]
    fn stream_write_options_for_decision(
        &self,
        layout_write_decision: &VortexLayoutWriteRuntimeDecision,
        writer_stage_timing: &VortexWriterStageTiming,
        native_memory: Option<&NativeIngestMemory>,
        dtype: &vortex::array::dtype::DType,
        writer_input_lookahead: Option<WriterInputLookahead>,
    ) -> Result<(
        vortex::file::VortexWriteOptions,
        column_layout::StreamLayoutEvidence,
    )> {
        column_layout::stream_options(
            self,
            layout_write_decision,
            writer_stage_timing,
            native_memory,
            dtype,
            column_layout::DEFAULT_STREAM_FOOTER_LAYOUT,
            writer_input_lookahead,
        )
    }

    fn write_options_for_decision(
        &self,
        layout_write_decision: &VortexLayoutWriteRuntimeDecision,
        writer_stage_timing: &VortexWriterStageTiming,
        dtype: &vortex::array::dtype::DType,
    ) -> vortex::file::VortexWriteOptions {
        use vortex::file::WriteOptionsSessionExt as _;
        let options = self.session.write_options();
        if vortex_layout_write_strategy_applies(layout_write_decision)
            || nested_layout::has_fields(dtype)
        {
            options.with_strategy(self.strategy_for_decision(
                layout_write_decision,
                writer_stage_timing,
                &self.session,
                false,
                dtype,
            ))
        } else {
            options
        }
    }

    fn strategy_for_decision(
        &self,
        layout_write_decision: &VortexLayoutWriteRuntimeDecision,
        writer_stage_timing: &VortexWriterStageTiming,
        writer_session: &vortex::session::VortexSession,
        preserve_input_dictionaries: bool,
        dtype: &vortex::array::dtype::DType,
    ) -> Arc<dyn vortex::layout::LayoutStrategy> {
        use vortex::compressor::BtrBlocksCompressorBuilder;
        use vortex::file::WriteStrategyBuilder;

        let nested_fields = nested_layout::field_writers(dtype, writer_session);
        let mut builder = WriteStrategyBuilder::default();
        for (field, writer) in &nested_fields {
            builder = builder.with_field_writer(field.clone(), Arc::clone(writer));
        }

        if vortex_layout_write_strategy_applies(layout_write_decision) {
            let row_block_size = vortex_writer_row_block_size(layout_write_decision);
            let block_target_bytes = vortex_writer_block_target_bytes(layout_write_decision);
            let stats_concurrency = vortex_writer_stats_concurrency(layout_write_decision);
            if vortex_writer_uses_large_source_fast_load(layout_write_decision) {
                std::sync::Arc::new(
                    large_source_fast_load_table_strategy_with_dictionaries(
                        row_block_size,
                        block_target_bytes,
                        stats_concurrency,
                        writer_stage_timing,
                        writer_session,
                        preserve_input_dictionaries,
                    )
                    .with_field_writers(nested_fields),
                )
            } else if vortex_writer_uses_large_source_balanced(layout_write_decision) {
                builder
                    .with_row_block_size(row_block_size)
                    .with_btrblocks_builder(
                        BtrBlocksCompressorBuilder::default().only_cuda_compatible(),
                    )
                    .build()
            } else if vortex_writer_uses_large_source_text(layout_write_decision) {
                Arc::new(
                    large_source_text_vortex_write_strategy_with_dictionaries(
                        row_block_size,
                        block_target_bytes,
                        vortex_writer_compression_concurrency(layout_write_decision),
                        stats_concurrency,
                        &layout_write_decision.writer_compression_field_names,
                        writer_stage_timing,
                        writer_session,
                        preserve_input_dictionaries,
                    )
                    .with_field_writers(nested_fields),
                )
            } else {
                builder.with_row_block_size(row_block_size).build()
            }
        } else {
            use vortex::editions::{ComponentKind, EditionSessionExt as _};
            builder
                .with_allow_encodings(
                    self.session
                        .enabled_component_ids(ComponentKind::Array)
                        .into_iter()
                        .collect(),
                )
                .build()
        }
    }
}

#[cfg(feature = "vortex-write")]
fn vortex_layout_write_strategy_applies(decision: &VortexLayoutWriteRuntimeDecision) -> bool {
    decision.runtime_decision_applied
        && decision.provider_admitted
        && decision.selected_strategy == "single_vortex_artifact_embedded_olap_layout_statistics"
        && decision.blocker == "none"
}

#[cfg(feature = "vortex-write")]
fn vortex_writer_row_block_size(decision: &VortexLayoutWriteRuntimeDecision) -> usize {
    if vortex_layout_write_strategy_applies(decision) {
        decision.writer_row_block_size
    } else {
        VORTEX_PREPARED_OLAP_WRITER_DEFAULT_ROW_BLOCK_SIZE
    }
}

#[cfg(feature = "vortex-write")]
fn vortex_writer_block_target_bytes(decision: &VortexLayoutWriteRuntimeDecision) -> u64 {
    if vortex_layout_write_strategy_applies(decision) {
        decision.writer_block_target_bytes
    } else {
        0
    }
}

#[cfg(feature = "vortex-write")]
fn vortex_writer_coalescing_policy_status(
    decision: &VortexLayoutWriteRuntimeDecision,
) -> &'static str {
    if !vortex_layout_write_strategy_applies(decision) {
        return "upstream_vortex_default_writer_coalescing_policy";
    }
    if vortex_writer_block_target_bytes(decision) > 0 {
        "vortex_repartition_writer_coalescing_enabled_with_row_block_and_byte_target"
    } else {
        "vortex_row_block_writer_strategy_enabled_without_byte_target"
    }
}

#[cfg(feature = "vortex-write")]
fn vortex_writer_compression_policy(decision: &VortexLayoutWriteRuntimeDecision) -> &str {
    if vortex_layout_write_strategy_applies(decision) {
        &decision.writer_compression_policy
    } else {
        VORTEX_PREPARED_OLAP_WRITER_DEFAULT_COMPRESSION_POLICY
    }
}

#[cfg(feature = "vortex-write")]
fn vortex_writer_compression_concurrency(decision: &VortexLayoutWriteRuntimeDecision) -> usize {
    if vortex_layout_write_strategy_applies(decision) {
        decision.writer_compression_concurrency
    } else {
        VORTEX_PREPARED_OLAP_WRITER_DEFAULT_COMPRESSION_CONCURRENCY
    }
}

#[cfg(feature = "vortex-write")]
fn vortex_writer_stats_concurrency(decision: &VortexLayoutWriteRuntimeDecision) -> usize {
    if vortex_layout_write_strategy_applies(decision) {
        decision.writer_stats_concurrency.max(1)
    } else {
        VORTEX_PREPARED_OLAP_WRITER_DEFAULT_STATS_CONCURRENCY
    }
}

#[cfg(feature = "vortex-write")]
fn vortex_writer_profile_selection_reason(decision: &VortexLayoutWriteRuntimeDecision) -> &str {
    if vortex_layout_write_strategy_applies(decision) {
        &decision.writer_profile_selection_reason
    } else {
        "upstream_vortex_default_writer_profile"
    }
}

#[cfg(feature = "vortex-write")]
fn vortex_writer_profile_regression_guard(decision: &VortexLayoutWriteRuntimeDecision) -> &str {
    if vortex_layout_write_strategy_applies(decision) {
        &decision.writer_profile_regression_guard
    } else {
        "not_applicable"
    }
}

#[cfg(feature = "vortex-write")]
fn vortex_writer_uses_large_source_fast_load(decision: &VortexLayoutWriteRuntimeDecision) -> bool {
    vortex_layout_write_strategy_applies(decision)
        && decision.writer_compression_policy
            == VORTEX_PREPARED_OLAP_WRITER_FAST_LOAD_LARGE_SOURCE_COMPRESSION_POLICY
        && decision.writer_compression_concurrency
            == VORTEX_PREPARED_OLAP_WRITER_FAST_LOAD_LARGE_SOURCE_COMPRESSION_CONCURRENCY
}

#[cfg(feature = "vortex-write")]
fn vortex_writer_uses_large_source_balanced(decision: &VortexLayoutWriteRuntimeDecision) -> bool {
    vortex_layout_write_strategy_applies(decision)
        && decision.writer_compression_policy
            == VORTEX_PREPARED_OLAP_WRITER_BALANCED_LARGE_SOURCE_COMPRESSION_POLICY
        && decision.writer_compression_concurrency
            == VORTEX_PREPARED_OLAP_WRITER_DEFAULT_COMPRESSION_CONCURRENCY
}

#[cfg(feature = "vortex-write")]
fn vortex_writer_uses_large_source_text(decision: &VortexLayoutWriteRuntimeDecision) -> bool {
    vortex_layout_write_strategy_applies(decision)
        && decision.writer_compression_policy
            == VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_LARGE_SOURCE_COMPRESSION_POLICY
        && decision.writer_compression_concurrency > 0
        && !decision.writer_compression_field_names.is_empty()
}

#[cfg(all(test, feature = "vortex-write"))]
fn large_source_fast_load_vortex_write_strategy(
    row_block_size: usize,
    block_target_bytes: u64,
    stats_concurrency: usize,
    writer_stage_timing: &VortexWriterStageTiming,
    writer_session: &vortex::session::VortexSession,
) -> std::sync::Arc<dyn vortex::layout::LayoutStrategy> {
    std::sync::Arc::new(large_source_fast_load_table_strategy(
        row_block_size,
        block_target_bytes,
        stats_concurrency,
        writer_stage_timing,
        writer_session,
    ))
}

#[cfg(all(test, feature = "vortex-write"))]
fn large_source_fast_load_table_strategy(
    row_block_size: usize,
    block_target_bytes: u64,
    stats_concurrency: usize,
    writer_stage_timing: &VortexWriterStageTiming,
    writer_session: &vortex::session::VortexSession,
) -> vortex::layout::layouts::table::TableStrategy {
    large_source_fast_load_table_strategy_with_dictionaries(
        row_block_size,
        block_target_bytes,
        stats_concurrency,
        writer_stage_timing,
        writer_session,
        false,
    )
}

#[cfg(feature = "vortex-write")]
#[allow(clippy::too_many_lines)] // Keep the native strategy tree in one reviewable assembly.
fn large_source_fast_load_table_strategy_with_dictionaries(
    row_block_size: usize,
    block_target_bytes: u64,
    stats_concurrency: usize,
    writer_stage_timing: &VortexWriterStageTiming,
    writer_session: &vortex::session::VortexSession,
    preserve_input_dictionaries: bool,
) -> vortex::layout::layouts::table::TableStrategy {
    use std::num::NonZeroUsize;

    use vortex::editions::EditionSessionExt as _;
    use vortex::layout::layouts::buffered::BufferedStrategy;
    use vortex::layout::layouts::chunked::writer::ChunkedLayoutStrategy;
    use vortex::layout::layouts::collect::CollectStrategy;
    use vortex::layout::layouts::dict::writer::{DictLayoutOptions, DictStrategy};
    use vortex::layout::layouts::flat::writer::FlatLayoutStrategy;
    use vortex::layout::layouts::repartition::{RepartitionStrategy, RepartitionWriterOptions};
    use vortex::layout::layouts::table::TableStrategy;
    use vortex::layout::layouts::zoned::writer::{ZonedLayoutOptions, ZonedStrategy};
    let row_block_len = row_block_size.max(1);
    let row_block_size =
        NonZeroUsize::new(row_block_len).expect("row_block_len is clamped to at least one");
    let stats_concurrency = NonZeroUsize::new(stats_concurrency.max(1))
        .expect("stats_concurrency is clamped to at least one");
    // Preserve the original probe decision policy. The legacy array-only session
    // has no editions in 0.85, so this set is empty and the probe only supplies
    // built-in canonical/constant decisions. The probe adapter can omit work
    // for canonical primitives when Dict is excluded without changing its
    // layout decision. Enabling full text probing here would be a separate
    // physical-design experiment.
    let probe_encodings = vortex::array::legacy_session()
        .enabled_component_ids(vortex::editions::ComponentKind::Array)
        .into_iter()
        .collect();
    let probe_compressor =
        numeric_encoding::measured_probe(&probe_encodings, writer_stage_timing.stages.clone());
    let allowed_encodings =
        writer_session.enabled_component_ids(vortex::editions::ComponentKind::Array);
    let flat_base: std::sync::Arc<dyn vortex::layout::LayoutStrategy> =
        std::sync::Arc::new(FlatLayoutStrategy::default());
    let flat: std::sync::Arc<dyn vortex::layout::LayoutStrategy> =
        std::sync::Arc::new(vortex::layout::LayoutStrategyEncodingValidator::new(
            flat_base,
            allowed_encodings.into_iter().collect(),
        ));
    let chunked = ChunkedLayoutStrategy::new(std::sync::Arc::clone(&flat));
    let buffered = BufferedStrategy::new(
        chunked,
        vortex_writer_buffered_target_bytes(block_target_bytes),
    );
    let repartition_options = RepartitionWriterOptions {
        block_size_minimum: VORTEX_PREPARED_OLAP_WRITER_ONE_MIB,
        block_len_multiple: row_block_len,
        block_size_target: Some(block_target_bytes),
        canonicalize: true,
    };
    let coalescing = RepartitionStrategy::new(buffered.clone(), repartition_options.clone());
    // Dictionary codes, values and text retain their existing routes. Only
    // non-Dict numeric data is compressed, after the final canonicalizing step.
    let numeric_fallback = RepartitionStrategy::new(
        numeric_encoding::NumericDataStrategy::new(
            buffered,
            writer_stage_timing.stages.clone(),
            writer_session,
        ),
        repartition_options,
    );
    let dict = DictStrategy::new(
        coalescing,
        std::sync::Arc::clone(&flat),
        numeric_fallback,
        DictLayoutOptions::default(),
        probe_compressor,
    );
    let stats = ZonedStrategy::new(
        dict,
        std::sync::Arc::clone(&flat),
        ZonedLayoutOptions {
            block_size: row_block_size,
            concurrency: stats_concurrency,
            ..Default::default()
        },
    );
    let repartition = RepartitionStrategy::new(
        stats,
        RepartitionWriterOptions {
            block_size_minimum: 0,
            block_len_multiple: row_block_len,
            block_size_target: None,
            canonicalize: false,
        },
    );
    let validity_strategy = CollectStrategy::new(flat);
    let data: std::sync::Arc<dyn vortex::layout::LayoutStrategy> = if preserve_input_dictionaries {
        std::sync::Arc::new(dictionary_preservation::DictionaryPreservingStrategy::new(
            repartition,
            row_block_len,
            writer_stage_timing.stages.clone(),
            writer_session,
        ))
    } else {
        std::sync::Arc::new(repartition)
    };
    TableStrategy::new(std::sync::Arc::new(validity_strategy), data)
}

#[cfg(all(test, feature = "vortex-write"))]
fn large_source_text_vortex_write_strategy(
    row_block_size: usize,
    block_target_bytes: u64,
    compression_concurrency: usize,
    stats_concurrency: usize,
    compression_field_names: &[String],
    writer_stage_timing: &VortexWriterStageTiming,
    writer_session: &vortex::session::VortexSession,
) -> std::sync::Arc<dyn vortex::layout::LayoutStrategy> {
    Arc::new(large_source_text_vortex_write_strategy_with_dictionaries(
        row_block_size,
        block_target_bytes,
        compression_concurrency,
        stats_concurrency,
        compression_field_names,
        writer_stage_timing,
        writer_session,
        false,
    ))
}

#[cfg(feature = "vortex-write")]
#[allow(clippy::too_many_arguments)] // Existing writer controls plus bounded-input admission.
fn large_source_text_vortex_write_strategy_with_dictionaries(
    row_block_size: usize,
    block_target_bytes: u64,
    compression_concurrency: usize,
    stats_concurrency: usize,
    compression_field_names: &[String],
    writer_stage_timing: &VortexWriterStageTiming,
    writer_session: &vortex::session::VortexSession,
    preserve_input_dictionaries: bool,
) -> vortex::layout::layouts::table::TableStrategy {
    use vortex::array::dtype::FieldPath;

    let text_strategy = large_source_fast_zstd_text_leaf_strategy(
        row_block_size,
        compression_concurrency,
        writer_stage_timing,
    );
    let mut strategy = large_source_fast_load_table_strategy_with_dictionaries(
        row_block_size,
        block_target_bytes,
        stats_concurrency,
        writer_stage_timing,
        writer_session,
        preserve_input_dictionaries,
    );
    for field in compression_field_names {
        strategy = strategy.with_field_writer(
            FieldPath::from_name(field.as_str()),
            std::sync::Arc::clone(&text_strategy),
        );
    }
    strategy
}

#[cfg(feature = "vortex-write")]
fn vortex_writer_buffered_target_bytes(block_target_bytes: u64) -> u64 {
    if block_target_bytes <= VORTEX_PREPARED_OLAP_WRITER_ONE_MIB {
        2 * VORTEX_PREPARED_OLAP_WRITER_ONE_MIB
    } else {
        block_target_bytes
    }
}

/// Isolated text-zone candidate; ordinary source admission keeps its current writer.
#[cfg(all(test, feature = "vortex-write", feature = "universal-format-io", unix))]
fn zoned_source_text_vortex_write_strategy(
    row_block_size: usize,
    block_target_bytes: u64,
    compression_concurrency: usize,
    stats_concurrency: usize,
    compression_field_names: &[String],
    writer_stage_timing: &VortexWriterStageTiming,
    writer_session: &vortex::session::VortexSession,
) -> std::sync::Arc<dyn vortex::layout::LayoutStrategy> {
    use vortex::array::dtype::FieldPath;
    use vortex::layout::layouts::flat::writer::FlatLayoutStrategy;
    use vortex::layout::layouts::repartition::{RepartitionStrategy, RepartitionWriterOptions};
    use vortex::layout::layouts::zoned::writer::{ZonedLayoutOptions, ZonedStrategy};

    let text_values = large_source_fast_zstd_text_leaf_strategy(
        row_block_size,
        compression_concurrency,
        writer_stage_timing,
    );
    let zone_rows = row_block_size.max(1);
    let zoned = ZonedStrategy::new(
        text_values,
        FlatLayoutStrategy::default(),
        ZonedLayoutOptions {
            block_size: std::num::NonZeroUsize::new(zone_rows)
                .expect("text zone rows are clamped to at least one"),
            concurrency: std::num::NonZeroUsize::new(stats_concurrency.max(1))
                .expect("text statistics concurrency is clamped to at least one"),
            ..Default::default()
        },
    );
    // Field overrides bypass the default leaf. Give only the selected text
    // fields explicit zone boundaries/statistics, retaining their existing codec.
    let text_strategy: std::sync::Arc<dyn vortex::layout::LayoutStrategy> =
        std::sync::Arc::new(RepartitionStrategy::new(
            zoned,
            RepartitionWriterOptions {
                block_size_minimum: 0,
                block_len_multiple: zone_rows,
                block_size_target: None,
                canonicalize: false,
            },
        ));
    let mut strategy = large_source_fast_load_table_strategy(
        row_block_size,
        block_target_bytes,
        stats_concurrency,
        writer_stage_timing,
        writer_session,
    );
    for field in compression_field_names {
        strategy = strategy.with_field_writer(
            FieldPath::from_name(field.as_str()),
            std::sync::Arc::clone(&text_strategy),
        );
    }
    std::sync::Arc::new(strategy)
}

#[cfg(feature = "vortex-write")]
fn large_source_fast_zstd_text_leaf_strategy(
    row_block_size: usize,
    compression_concurrency: usize,
    writer_stage_timing: &VortexWriterStageTiming,
) -> std::sync::Arc<dyn vortex::layout::LayoutStrategy> {
    use vortex::array::Executable as _;
    use vortex::array::arrays::VarBinViewArray;
    use vortex::layout::layouts::chunked::writer::ChunkedLayoutStrategy;
    use vortex::layout::layouts::compressed::CompressingStrategy;
    use vortex::layout::layouts::flat::writer::FlatLayoutStrategy;

    let values_per_frame = row_block_size.clamp(
        1,
        VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_ZSTD_VALUES_PER_FRAME,
    );
    let writer_stage_timing = writer_stage_timing.clone();
    let compressor = move |chunk: &vortex::array::ArrayRef,
                           ctx: &mut vortex::array::ExecutionCtx| {
        if !chunk.dtype().is_utf8() {
            // A caller-selected non-text field is passed through unchanged,
            // so its original provider statistics remain persisted and useful.
            chunk.statistics().compute_all(
                &vortex::array::expr::stats::Stat::all().collect::<Vec<_>>(),
                ctx,
            )?;
            return Ok(chunk.clone());
        }
        let compression_start = Instant::now();
        let _active_scope = writer_stage_timing.stages.text_scope();
        let rows = u64::try_from(chunk.len()).unwrap_or(u64::MAX);
        let input_bytes = chunk.nbytes();
        let started = Instant::now();
        let canonical = VarBinViewArray::execute(chunk.clone(), ctx);
        writer_stage_timing.stages.record(
            Stage::TextCanonicalize,
            started.elapsed(),
            rows,
            input_bytes,
            canonical.as_ref().map_or(0, vortex::array::Array::nbytes),
        );
        let canonical = canonical?;
        let input_bytes = canonical.nbytes();
        let started = Instant::now();
        let varbin = canonical.compact_buffers(ctx);
        writer_stage_timing.stages.record(
            Stage::TextCompact,
            started.elapsed(),
            rows,
            input_bytes,
            varbin.as_ref().map_or(0, vortex::array::Array::nbytes),
        );
        let varbin = varbin?;
        let input_bytes = varbin.nbytes();
        let started = Instant::now();
        let compressed = vortex_zstd::Zstd::from_var_bin_view_without_dict(
            &varbin,
            VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_ZSTD_FAST_LEVEL,
            values_per_frame,
            ctx,
        )
        .map(vortex::array::IntoArray::into_array);
        writer_stage_timing.stages.record(
            Stage::TextZstd,
            started.elapsed(),
            rows,
            input_bytes,
            compressed
                .as_ref()
                .map_or(0, vortex::array::ArrayRef::nbytes),
        );
        let compressed = compressed?;
        #[cfg(all(test, feature = "universal-format-io"))]
        if let Some(gate) = &writer_stage_timing.codec_completion_gate {
            gate.checkpoint()?;
        }
        writer_stage_timing.add_compression_elapsed(compression_start.elapsed());
        Ok(compressed)
    };
    let chunked = ChunkedLayoutStrategy::new(FlatLayoutStrategy::default());
    std::sync::Arc::new(
        CompressingStrategy::new(chunked, compressor)
            // This fixed Zstd codec neither selects from nor inherits source
            // statistics. File pruning statistics are accumulated before the
            // layout writer; avoid rebuilding temporary views for unused stats.
            .with_stats(&[])
            .with_concurrency(compression_concurrency.max(1)),
    )
}

#[cfg(feature = "vortex-write")]
fn vortex_writer_layout_strategy_applied(
    decision: &VortexLayoutWriteRuntimeDecision,
) -> &'static str {
    if vortex_layout_write_strategy_applies(decision) {
        if vortex_writer_uses_large_source_fast_load(decision) {
            "vortex_write_strategy_row_block_262144_target_8mb_fast_load_numeric_btrblocks_embedded_olap_layout_statistics"
        } else if vortex_writer_uses_large_source_balanced(decision) {
            "vortex_write_strategy_row_block_262144_target_1mb_balanced_zstd_embedded_olap_layout_statistics"
        } else if vortex_writer_uses_large_source_text(decision) {
            if decision.writer_block_target_bytes
                == VORTEX_PREPARED_OLAP_WRITER_LARGE_TEXT_COALESCED_BLOCK_TARGET_BYTES
            {
                "vortex_write_strategy_row_block_262144_target_8mb_source_text_fast_zstd_no_dict_numeric_btrblocks_embedded_olap_layout_statistics"
            } else {
                "vortex_write_strategy_row_block_262144_target_1mb_source_text_fast_zstd_no_dict_numeric_btrblocks_embedded_olap_layout_statistics"
            }
        } else {
            match decision.writer_row_block_size {
                VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_BLOCK_SIZE => {
                    "vortex_write_strategy_row_block_262144_large_source_embedded_olap_layout_statistics"
                }
                VORTEX_PREPARED_OLAP_WRITER_FINE_ROW_BLOCK_SIZE => {
                    "vortex_write_strategy_row_block_4096_embedded_olap_layout_statistics"
                }
                _ => "vortex_write_strategy_row_block_dynamic_embedded_olap_layout_statistics",
            }
        }
    } else {
        "vortex_write_strategy_upstream_default"
    }
}

#[cfg(feature = "vortex-write")]
thread_local! {
    static LOCAL_VORTEX_WRITE_CONTEXT: RefCell<LocalVortexWriteContext> =
        RefCell::new(LocalVortexWriteContext::open());
}

#[cfg(feature = "vortex-write")]
fn write_vortex_array(
    path: &Path,
    array: &vortex::array::ArrayRef,
    allow_overwrite: bool,
    layout_write_decision: &VortexLayoutWriteRuntimeDecision,
) -> Result<LocalVortexWriteResult> {
    LOCAL_VORTEX_WRITE_CONTEXT.with(|context| {
        let context = context.borrow();
        let reuse_status = context.next_reuse_status();
        context.write_array(
            path,
            array,
            allow_overwrite,
            layout_write_decision,
            reuse_status,
        )
    })
}

#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
#[allow(clippy::too_many_arguments)] // Explicit generation, memory and producer-slot ownership.
fn write_vortex_array_iterator<I>(
    path: &Path,
    iter: I,
    allow_overwrite: bool,
    layout_write_decision: &VortexLayoutWriteRuntimeDecision,
    expected_rows: Option<u64>,
    native_memory: Option<&NativeIngestMemory>,
    source_identities: &[Arc<SourceIdentity>],
    writer_input_lookahead: Option<WriterInputLookahead>,
    prepared_source_binding: Option<&str>,
    ingest_runtime: Option<&crate::ingest_runtime::IngestRuntime>,
) -> Result<LocalVortexWriteResult>
where
    I: vortex::array::iter::ArrayIterator
        + futures::Stream<Item = vortex::error::VortexResult<vortex::array::ArrayRef>>
        + Unpin
        + Send
        + 'static,
{
    let write = |context: &LocalVortexWriteContext| {
        context.write_array_iterator(
            path,
            iter,
            allow_overwrite,
            layout_write_decision,
            expected_rows,
            native_memory,
            source_identities,
            writer_input_lookahead,
            prepared_source_binding,
        )
    };
    if let Some(runtime) = ingest_runtime {
        write(&LocalVortexWriteContext::for_ingest(runtime))
    } else {
        LOCAL_VORTEX_WRITE_CONTEXT.with(|context| write(&context.borrow()))
    }
}

#[cfg(feature = "vortex-write")]
fn collect_vortex_layout_encodings(
    layout: &dyn vortex::layout::DynLayout,
    encodings: &mut BTreeSet<String>,
) {
    encodings.insert(layout.encoding_id().to_string());
    if let Ok(children) = layout.children() {
        for child in children {
            collect_vortex_layout_encodings(child.as_ref(), encodings);
        }
    }
}

#[cfg(feature = "vortex-write")]
fn vortex_layout_encoding_inventory(layout: &dyn vortex::layout::DynLayout) -> (String, String) {
    let root_layout_encoding = layout.encoding_id().to_string();
    let mut encodings = BTreeSet::new();
    collect_vortex_layout_encodings(layout, &mut encodings);
    let layout_encoding_inventory = if encodings.is_empty() {
        "none".to_string()
    } else {
        encodings.into_iter().collect::<Vec<_>>().join(",")
    };
    (root_layout_encoding, layout_encoding_inventory)
}

#[cfg(feature = "vortex-write")]
fn vortex_domain_dictionary_status(dtype_summary: &str, layout_encoding_inventory: &str) -> String {
    let lower_encodings = layout_encoding_inventory.to_ascii_lowercase();
    let lower_dtype = dtype_summary.to_ascii_lowercase();
    if lower_encodings.contains("dict") || lower_encodings.contains("dictionary") {
        "vortex_dictionary_layout_present".to_string()
    } else if lower_dtype.contains("__shardloom_derived_url_domain_")
        && lower_dtype.contains("__shardloom_derived_utf8_len_")
    {
        "embedded_utf8_domain_columns_present_with_length_stats_dictionary_layout_not_observed"
            .to_string()
    } else if lower_dtype.contains("__shardloom_derived_url_domain_") {
        "embedded_utf8_domain_columns_present_dictionary_layout_not_observed".to_string()
    } else if lower_dtype.contains("__shardloom_derived_utf8_len_") {
        "embedded_utf8_length_columns_present_dictionary_layout_not_observed".to_string()
    } else if lower_dtype.contains("utf8") || lower_dtype.contains("string") {
        "utf8_domain_columns_present_dictionary_layout_not_observed".to_string()
    } else {
        "not_required_no_utf8_domain_columns".to_string()
    }
}

#[cfg(feature = "vortex-write")]
fn vortex_segment_membership_status(segment_count: usize, root_layout_encoding: &str) -> String {
    if segment_count > 0 {
        format!("segment_map_available;segments={segment_count};root_layout={root_layout_encoding}")
    } else {
        "segment_map_empty_or_unavailable".to_string()
    }
}

#[cfg(feature = "vortex-write")]
fn vortex_derived_layout_stats_status(statistics_status: &str) -> String {
    if statistics_status == "available" {
        "file_statistics_available_for_metadata_first_pruning".to_string()
    } else {
        "file_statistics_missing_requires_native_scan".to_string()
    }
}

#[cfg(feature = "vortex-write")]
fn vortex_row_position_locality_status(segment_count: usize) -> String {
    if segment_count > 0 {
        "source_ordinals_reopen_single_artifact_for_final_materialization".to_string()
    } else {
        "not_available_without_segment_map".to_string()
    }
}

#[cfg(feature = "vortex-write")]
fn vortex_per_column_metadata_contract(
    dtype: &vortex::array::dtype::DType,
    layout_encoding_inventory: &str,
    statistics_status: &str,
) -> String {
    use vortex::array::dtype::DType;

    let statistics_available = statistics_status == "available";
    match dtype {
        DType::Struct(fields, _) => fields
            .names()
            .iter()
            .map(|name| {
                let name = name.as_ref();
                let field_dtype = fields.field(name).unwrap_or_else(|| dtype.clone());
                vortex_column_metadata_contract(
                    name,
                    &field_dtype,
                    layout_encoding_inventory,
                    statistics_available,
                )
            })
            .collect::<Vec<_>>()
            .join(","),
        DType::Primitive(_, _) => vortex_column_metadata_contract(
            "value",
            dtype,
            layout_encoding_inventory,
            statistics_available,
        ),
        other => format!(
            "top_level:logical={}:encoding=not_admitted:derived=source:stats={}:roles=diagnostic_only",
            compact_metadata_token(&other.to_string()),
            if statistics_available {
                "file_stats_available"
            } else {
                "file_stats_missing"
            }
        ),
    }
}

#[cfg(feature = "vortex-write")]
fn vortex_column_metadata_contract(
    column: &str,
    dtype: &vortex::array::dtype::DType,
    layout_encoding_inventory: &str,
    statistics_available: bool,
) -> String {
    let derived_kind = shardloom_hidden_derived_column_kind(column);
    let stats = if statistics_available {
        "file_stats_available"
    } else {
        "file_stats_missing"
    };
    format!(
        "{}:logical={}:encoding={}:derived={}:stats={}:roles={}",
        compact_metadata_token(column),
        compact_metadata_token(&dtype.to_string()),
        vortex_column_encoding_status(dtype, layout_encoding_inventory),
        derived_kind.unwrap_or("source"),
        stats,
        vortex_column_metadata_roles(column, dtype, derived_kind)
    )
}

#[cfg(feature = "vortex-write")]
fn vortex_column_encoding_status(
    dtype: &vortex::array::dtype::DType,
    layout_encoding_inventory: &str,
) -> &'static str {
    let lower_dtype = dtype.to_string().to_ascii_lowercase();
    let lower_layout = layout_encoding_inventory.to_ascii_lowercase();
    if lower_dtype.contains("dict")
        || lower_dtype.contains("dictionary")
        || lower_layout.contains("dict")
        || lower_layout.contains("dictionary")
    {
        "dictionary_or_code_available"
    } else if lower_dtype.contains("utf8") || lower_dtype.contains("string") {
        "utf8_encoded_scan"
    } else {
        "typed_encoded_scan"
    }
}

#[cfg(feature = "vortex-write")]
fn vortex_column_metadata_roles(
    column: &str,
    dtype: &vortex::array::dtype::DType,
    derived_kind: Option<&'static str>,
) -> &'static str {
    match derived_kind {
        Some("utf8_length") => "pruning|encoded_execution|aggregate_measure|diagnostic",
        Some("url_domain") => "pruning|encoded_execution|group_key|aggregate_measure|diagnostic",
        Some("extract_minute" | "date_trunc_minute") => {
            "encoded_execution|group_key|aggregate_measure|diagnostic"
        }
        Some(_) => "diagnostic",
        None => {
            let lower_dtype = dtype.to_string().to_ascii_lowercase();
            if lower_dtype.contains("utf8") || lower_dtype.contains("string") {
                "predicate_candidate|group_key_candidate|late_materialization"
            } else if column.starts_with("__shardloom_derived_") {
                "diagnostic"
            } else {
                "statistics_pruning|encoded_execution|late_materialization"
            }
        }
    }
}

#[cfg(feature = "vortex-write")]
fn shardloom_hidden_derived_column_kind(column: &str) -> Option<&'static str> {
    if column.starts_with("__shardloom_derived_utf8_len_") {
        Some("utf8_length")
    } else if column.starts_with("__shardloom_derived_url_domain_") {
        Some("url_domain")
    } else if column.starts_with("__shardloom_derived_extract_minute_") {
        Some("extract_minute")
    } else if column.starts_with("__shardloom_derived_date_trunc_minute_") {
        Some("date_trunc_minute")
    } else if column.starts_with("__shardloom_derived_") {
        Some("unknown_shardloom_derived")
    } else {
        None
    }
}

#[cfg(feature = "vortex-write")]
fn vortex_operator_selection_metadata_status(per_column_contract: &str) -> String {
    if per_column_contract.contains("derived=utf8_length")
        || per_column_contract.contains("derived=url_domain")
        || per_column_contract.contains("derived=extract_minute")
        || per_column_contract.contains("derived=date_trunc_minute")
    {
        "per_column_embedded_metadata_available_for_operator_selection".to_string()
    } else if per_column_contract.contains("encoding=dictionary_or_code_available") {
        "per_column_dictionary_metadata_available_for_operator_selection".to_string()
    } else if per_column_contract.is_empty() || per_column_contract == "not_available" {
        "per_column_metadata_not_available".to_string()
    } else {
        "per_column_footer_metadata_available_for_diagnostic_and_pruning".to_string()
    }
}

#[cfg(feature = "vortex-write")]
fn vortex_layout_size_attribution(
    dtype: &vortex::array::dtype::DType,
    artifact_size_bytes: Option<u64>,
    approx_footer_bytes: Option<usize>,
    layout_encoding_inventory: &str,
    domain_dictionary_status: &str,
) -> String {
    let mut attribution = VortexLayoutSizeAttribution::default();
    attribution.visit_dtype(dtype, None);
    format!(
        "artifact_bytes={};footer_bytes={};source_columns={};derived_columns={};derived_utf8_length_columns={};derived_url_domain_columns={};derived_time_columns={};derived_unknown_columns={};source_utf8_columns={};source_numeric_columns={};dictionary_status={};layout_encodings={};column_byte_attribution={}",
        artifact_size_bytes.map_or_else(|| "unknown".to_string(), |value| value.to_string()),
        approx_footer_bytes.map_or_else(|| "unknown".to_string(), |value| value.to_string()),
        attribution.source_columns,
        attribution.derived_columns,
        attribution.derived_utf8_length_columns,
        attribution.derived_url_domain_columns,
        attribution.derived_time_columns,
        attribution.derived_unknown_columns,
        attribution.source_utf8_columns,
        attribution.source_numeric_columns,
        domain_dictionary_status,
        compact_metadata_token(layout_encoding_inventory),
        "not_available_from_current_vortex_footer"
    )
}

#[cfg(feature = "vortex-write")]
#[derive(Default)]
#[allow(clippy::struct_field_names)]
struct VortexLayoutSizeAttribution {
    source_columns: usize,
    derived_columns: usize,
    derived_utf8_length_columns: usize,
    derived_url_domain_columns: usize,
    derived_time_columns: usize,
    derived_unknown_columns: usize,
    source_utf8_columns: usize,
    source_numeric_columns: usize,
}

#[cfg(feature = "vortex-write")]
impl VortexLayoutSizeAttribution {
    fn visit_dtype(&mut self, dtype: &vortex::array::dtype::DType, field_name: Option<&str>) {
        use vortex::array::dtype::{DType, PType};

        match dtype {
            DType::Struct(fields, _) => {
                for name in fields.names().iter() {
                    let name = name.as_ref();
                    let field_dtype = fields.field(name).unwrap_or_else(|| dtype.clone());
                    self.visit_dtype(&field_dtype, Some(name));
                }
            }
            other => {
                let derived_kind = field_name.and_then(shardloom_hidden_derived_column_kind);
                if let Some(kind) = derived_kind {
                    self.derived_columns += 1;
                    match kind {
                        "utf8_length" => self.derived_utf8_length_columns += 1,
                        "url_domain" => self.derived_url_domain_columns += 1,
                        "extract_minute" | "date_trunc_minute" => self.derived_time_columns += 1,
                        _ => self.derived_unknown_columns += 1,
                    }
                    return;
                }
                self.source_columns += 1;
                match other {
                    DType::Utf8(_) => self.source_utf8_columns += 1,
                    DType::Primitive(
                        PType::U8
                        | PType::U16
                        | PType::U32
                        | PType::U64
                        | PType::I8
                        | PType::I16
                        | PType::I32
                        | PType::I64
                        | PType::F16
                        | PType::F32
                        | PType::F64,
                        _,
                    ) => self.source_numeric_columns += 1,
                    _ => {}
                }
            }
        }
    }
}

#[cfg(feature = "vortex-write")]
fn compact_metadata_token(value: &str) -> String {
    let mut out = String::new();
    let mut last_was_separator = false;
    for ch in value.chars() {
        if ch.is_ascii_alphanumeric() || matches!(ch, '_' | '-' | '.') {
            out.push(ch);
            last_was_separator = false;
        } else if !last_was_separator {
            out.push('_');
            last_was_separator = true;
        }
    }
    out.trim_matches('_').to_string()
}

#[cfg(feature = "vortex-write")]
fn compact_field_evidence_token(value: &str) -> String {
    let mut out = String::new();
    let mut last_was_separator = false;
    for ch in value.chars() {
        if ch.is_ascii_alphanumeric() || matches!(ch, '_' | '-' | '.') {
            out.push(ch);
            last_was_separator = false;
        } else if !last_was_separator {
            out.push('_');
            last_was_separator = true;
        }
    }
    if out.is_empty() {
        "unnamed".to_string()
    } else {
        out
    }
}

#[cfg(feature = "vortex-write")]
fn read_prepared_vortex_artifact_layout_inventory(
    path: &Path,
) -> Result<VortexPreparedOlapLayoutInventory> {
    use vortex::VortexSessionDefault as _;
    use vortex::file::OpenOptionsSessionExt as _;
    use vortex::io::runtime::BlockingRuntime as _;
    use vortex::io::runtime::single::SingleThreadRuntime;
    use vortex::io::session::RuntimeSessionExt as _;
    use vortex::session::VortexSession;

    let runtime = SingleThreadRuntime::default();
    let session = VortexSession::default().with_handle(runtime.handle());
    let file = runtime
        .block_on(
            session
                .open_options()
                .with_layout_reader_cache()
                .open_path(path),
        )
        .map_err(vortex_error)?;
    let footer = file.footer();
    let row_count = footer.row_count();
    let segment_count = footer.segment_map().len();
    let statistics_status = if footer.statistics().is_some() {
        "available"
    } else {
        "not_available"
    }
    .to_string();
    let encoding_layout_status = if segment_count > 0 {
        "segment_map_available"
    } else {
        "segment_map_empty_or_unavailable"
    }
    .to_string();
    let artifact_size_bytes = std::fs::metadata(path).ok().map(|metadata| metadata.len());
    let approx_footer_bytes = footer.approx_byte_size();
    // Debug includes lazy dtype session registries, not just the logical schema.
    let dtype_summary = footer.dtype().to_string();
    let (root_layout_encoding, layout_encoding_inventory) =
        vortex_layout_encoding_inventory(footer.layout().as_ref());
    let segment_membership_status =
        vortex_segment_membership_status(segment_count, &root_layout_encoding);
    let domain_dictionary_status =
        vortex_domain_dictionary_status(&dtype_summary, &layout_encoding_inventory);
    let derived_layout_stats_status = vortex_derived_layout_stats_status(&statistics_status);
    let row_position_locality_status = vortex_row_position_locality_status(segment_count);
    let layout_reader_cache_status = "enabled_for_local_metadata_open".to_string();
    let per_column_metadata_contract = vortex_per_column_metadata_contract(
        footer.dtype(),
        &layout_encoding_inventory,
        &statistics_status,
    );
    let operator_selection_metadata_status =
        vortex_operator_selection_metadata_status(&per_column_metadata_contract);
    let layout_size_attribution = vortex_layout_size_attribution(
        footer.dtype(),
        artifact_size_bytes,
        approx_footer_bytes,
        &layout_encoding_inventory,
        &domain_dictionary_status,
    );
    let inventory_digest = fnv64_digest_text(&format!(
        "prepared_olap_layout_inventory|opened_single_vortex_artifact_footer|{row_count}|{segment_count}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}",
        statistics_status,
        encoding_layout_status,
        artifact_size_bytes.map_or_else(|| "unknown".to_string(), |value| value.to_string()),
        approx_footer_bytes.map_or_else(|| "unknown".to_string(), |value| value.to_string()),
        dtype_summary,
        root_layout_encoding,
        layout_encoding_inventory,
        per_column_metadata_contract,
        segment_membership_status,
        domain_dictionary_status,
        derived_layout_stats_status,
        row_position_locality_status,
        operator_selection_metadata_status,
        layout_size_attribution
    ));
    Ok(VortexPreparedOlapLayoutInventory {
        status: "opened_single_vortex_artifact_footer".to_string(),
        row_count: Some(row_count),
        segment_count: Some(segment_count),
        statistics_status,
        encoding_layout_status,
        artifact_size_bytes,
        approx_footer_bytes,
        dtype_summary,
        root_layout_encoding,
        layout_encoding_inventory,
        per_column_metadata_contract,
        segment_membership_status,
        domain_dictionary_status,
        derived_layout_stats_status,
        row_position_locality_status,
        layout_reader_cache_status,
        metadata_persisted_in_artifact: true,
        operator_selection_metadata_status,
        layout_size_attribution,
        inventory_digest,
    })
}

#[cfg(feature = "vortex-write")]
fn should_defer_prepared_vortex_artifact_layout_inventory(
    row_count: u64,
    bytes_written: u64,
    layout_write_decision: &VortexLayoutWriteRuntimeDecision,
) -> bool {
    vortex_layout_write_strategy_applies(layout_write_decision)
        && (row_count >= VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_THRESHOLD
            || bytes_written >= VORTEX_PREPARED_OLAP_LARGE_REOPEN_DEFER_BYTES)
}

#[cfg(feature = "vortex-write")]
fn prepared_vortex_artifact_layout_inventory_after_write(
    path: &Path,
    row_count: u64,
    bytes_written: u64,
    layout_write_decision: &VortexLayoutWriteRuntimeDecision,
) -> Result<(VortexPreparedOlapLayoutInventory, u128, String)> {
    if should_defer_prepared_vortex_artifact_layout_inventory(
        row_count,
        bytes_written,
        layout_write_decision,
    ) {
        return Ok((
            VortexPreparedOlapLayoutInventory::deferred_from_writer_summary(
                path,
                row_count,
                bytes_written,
                layout_write_decision,
            ),
            0,
            VORTEX_PREPARED_OLAP_REOPEN_DEFERRED_STATUS.to_string(),
        ));
    }
    let reopen_start = Instant::now();
    let prepared_olap_layout_inventory = read_prepared_vortex_artifact_layout_inventory(path)?;
    let reopen_scan_micros = reopen_start.elapsed().as_micros();
    Ok((
        prepared_olap_layout_inventory,
        reopen_scan_micros,
        "reopen_metadata_row_count_verified".to_string(),
    ))
}

#[cfg(not(feature = "vortex-write"))]
#[allow(clippy::unnecessary_wraps)]
fn read_prepared_vortex_artifact_layout_inventory(
    _path: &Path,
) -> Result<VortexPreparedOlapLayoutInventory> {
    Ok(VortexPreparedOlapLayoutInventory::unavailable(
        "blocked_vortex_write_feature_disabled",
    ))
}

#[cfg(feature = "vortex-write")]
fn reopen_verification_is_certified(status: &str) -> bool {
    matches!(
        status,
        "reopen_row_count_verified"
            | "reopen_metadata_row_count_verified"
            | VORTEX_PREPARED_OLAP_REOPEN_DEFERRED_STATUS
    )
}

#[cfg(feature = "vortex-write")]
fn reopen_verification_uses_metadata(status: &str) -> bool {
    status == "reopen_metadata_row_count_verified"
}

#[cfg(feature = "vortex-write")]
fn reopen_verification_uses_writer_summary(status: &str) -> bool {
    status == VORTEX_PREPARED_OLAP_REOPEN_DEFERRED_STATUS
}

#[cfg(feature = "vortex-write")]
fn vortex_error(error: impl std::fmt::Display) -> ShardLoomError {
    ShardLoomError::InvalidOperation(format!(
        "local vortex_ingest upstream Vortex API failed: {error}; no fallback execution was attempted"
    ))
}

fn fnv64_digest_text(value: &str) -> String {
    let mut hash = 0xcbf2_9ce4_8422_2325_u64;
    for byte in value.as_bytes() {
        hash ^= u64::from(*byte);
        hash = hash.wrapping_mul(0x0000_0100_0000_01b3);
    }
    format!("fnv64:{hash:016x}")
}

#[cfg(feature = "vortex-write")]
fn usize_to_u64(value: usize) -> Result<u64> {
    u64::try_from(value).map_err(|_| {
        ShardLoomError::InvalidOperation(
            "local vortex_ingest value does not fit in u64".to_string(),
        )
    })
}

#[cfg(all(test, feature = "vortex-write"))]
#[allow(clippy::too_many_lines)]
mod tests {
    use super::*;

    #[test]
    fn reopened_inventory_schema_is_compact_and_digest_is_deterministic() {
        let path = std::env::temp_dir().join(format!(
            "shardloom-compact-inventory-{}.vortex",
            std::process::id()
        ));
        let request = VortexPreparedStateWriteRequest::new(
            &path,
            vec!["id".into(), "payload".into()],
            vec![vec![
                ("id".into(), ScalarValue::Int64(1)),
                ("payload".into(), ScalarValue::Utf8("alpha".into())),
            ]],
        );
        write_flat_scalar_vortex_prepared_state(request).unwrap();
        let first = read_prepared_vortex_artifact_layout_inventory(&path).unwrap();
        let second = read_prepared_vortex_artifact_layout_inventory(&path).unwrap();
        assert_eq!(first.dtype_summary, "{id=i64, payload=utf8}");
        assert!(first.dtype_summary.len() < 256);
        assert_eq!(first.inventory_digest, second.inventory_digest);
        assert_eq!(first.row_count, Some(1));
        std::fs::remove_file(path).unwrap();
    }

    #[cfg(feature = "universal-format-io")]
    fn reopen_vortex_artifact_as_arrow_struct(
        path: &Path,
        schema: &arrow_schema::Schema,
    ) -> arrow_array::ArrayRef {
        use vortex::VortexSessionDefault as _;
        use vortex::array::VortexSessionExecute as _;
        use vortex::array::stream::ArrayStreamExt as _;
        use vortex::arrow::ArrowSessionExt as _;
        use vortex::file::OpenOptionsSessionExt as _;
        use vortex::io::runtime::BlockingRuntime as _;
        use vortex::io::runtime::single::SingleThreadRuntime;
        use vortex::io::session::RuntimeSessionExt as _;
        use vortex::session::VortexSession;

        let bytes = std::fs::read(path).expect("read vortex artifact");
        let runtime = SingleThreadRuntime::default();
        let session = VortexSession::default().with_handle(runtime.handle());
        let file = session
            .open_options()
            .open_buffer(bytes)
            .expect("open vortex artifact");
        let array = runtime
            .block_on(
                file.scan()
                    .expect("scan vortex artifact")
                    .into_array_stream()
                    .expect("array stream")
                    .read_all(),
            )
            .expect("read vortex array");
        let mut ctx = session.create_execution_ctx();
        let target = arrow_schema::Field::new(
            "",
            arrow_schema::DataType::Struct(schema.fields.clone()),
            false,
        );
        session
            .arrow()
            .execute_arrow(array, Some(&target), &mut ctx)
            .expect("execute vortex artifact to arrow struct")
    }

    fn temp_test_root(name: &str) -> PathBuf {
        let mut root = std::env::temp_dir();
        let nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("system clock")
            .as_nanos();
        root.push(format!(
            "shardloom-vortex-ingest-{name}-{}-{nanos}",
            std::process::id()
        ));
        let _ = std::fs::remove_dir_all(&root);
        std::fs::create_dir_all(&root).expect("create temp root");
        root
    }

    fn legacy_prepared_olap_state_manifest_path(target: &Path) -> PathBuf {
        target
            .parent()
            .expect("target parent")
            .join(".shardloom")
            .join(format!(
                "{}.prepared-olap-state.manifest",
                target
                    .file_name()
                    .and_then(|value| value.to_str())
                    .expect("target file name")
            ))
    }

    fn legacy_prepared_olap_state_sidecar_dir(target: &Path) -> PathBuf {
        target
            .parent()
            .expect("target parent")
            .join(".shardloom")
            .join(format!(
                "{}.prepared-olap-state.d",
                target
                    .file_name()
                    .and_then(|value| value.to_str())
                    .expect("target file name")
            ))
    }

    fn write_test_prepared_vortex_artifact(
        target: &Path,
        seed: i64,
    ) -> VortexPreparedStateWriteReport {
        let seed_f64 = f64::from(i32::try_from(seed).expect("test seed fits f64 exactly"));
        let request = VortexPreparedStateWriteRequest::new(
            target,
            vec![
                "id".to_string(),
                "group_key".to_string(),
                "metric".to_string(),
            ],
            vec![
                vec![
                    ("id".to_string(), ScalarValue::Int64(seed)),
                    ("group_key".to_string(), ScalarValue::Int64(seed % 3)),
                    ("metric".to_string(), ScalarValue::Float64(seed_f64 + 0.5)),
                ],
                vec![
                    ("id".to_string(), ScalarValue::Int64(seed + 1)),
                    ("group_key".to_string(), ScalarValue::Int64((seed + 1) % 3)),
                    ("metric".to_string(), ScalarValue::Float64(seed_f64 + 1.5)),
                ],
            ],
        )
        .allow_overwrite(true);
        let report = write_flat_scalar_vortex_prepared_state(request).expect("write test vortex");
        assert_eq!(
            report.prepared_olap_layout_inventory.status,
            "opened_single_vortex_artifact_footer"
        );
        assert_eq!(report.prepared_olap_layout_inventory.row_count, Some(2));
        assert!(
            report
                .prepared_olap_layout_inventory
                .metadata_persisted_in_artifact
        );
        report
    }

    #[test]
    fn native_vortex_artifact_prepare_admits_same_artifact_without_rewrite() {
        let root = temp_test_root("native-vortex-pass-through");
        let source = root.join("prepared.vortex");
        let written = write_test_prepared_vortex_artifact(&source, 10);
        let request = VortexNativeArtifactPrepareRequest::new_local(
            &source,
            &source,
            false,
            "test-vortex-provider",
            "vortex-write",
            "ingest_certified",
        )
        .expect("native request");

        let report = prepare_native_vortex_artifact(&request).expect("native prepare report");

        assert_eq!(report.row_count, written.row_count);
        assert_eq!(report.status, "native_vortex_artifact_admitted");
        assert_eq!(report.policy, "vortex_native_prepared_state_pass_through");
        assert!(report.encoded_layout_preserved);
        assert!(report.same_artifact_passthrough);
        assert!(!report.workspace_copy_performed);
        assert!(!report.reencode_performed);
        assert!(!report.upstream_vortex_scan_called);
        assert!(!report.upstream_vortex_write_called);
        assert!(report.workspace_write_report.is_none());
        assert_eq!(
            report.target_digest_source,
            "native_vortex_metadata_footer_fingerprint_no_byte_read"
        );
        assert_eq!(
            report.segment_metadata_primitive.status,
            "admitted_footer_segment_metadata"
        );
        assert_eq!(
            report
                .segment_metadata_primitive
                .admission_for_query_family(VortexSegmentMetadataQueryFamily::MetadataCount),
            "admitted_metadata_count_from_prepared_footer_or_writer_summary"
        );
        assert!(
            report
                .segment_metadata_primitive
                .is_predicate_pruning_admitted()
        );
        assert!(
            report
                .segment_metadata_primitive
                .must_read_inconclusive_segments()
        );
        let fields = report.evidence_fields();
        assert_eq!(
            fields
                .iter()
                .find(|(key, _)| key == "vortex_to_vortex_reencode_performed")
                .map(|(_, value)| value.as_str()),
            Some("false")
        );
        assert!(!legacy_prepared_olap_state_manifest_path(&source).exists());
        std::fs::remove_dir_all(root).expect("remove temp root");
    }

    #[test]
    fn native_vortex_artifact_prepare_copies_bytes_without_scan_stream_rewrite() {
        let root = temp_test_root("native-vortex-copy");
        let source = root.join("prepared.vortex");
        let target = root.join("copied.vortex");
        write_test_prepared_vortex_artifact(&source, 20);
        let request = VortexNativeArtifactPrepareRequest::new_local(
            &source,
            &target,
            false,
            "test-vortex-provider",
            "vortex-write",
            "ingest_certified",
        )
        .expect("native request");

        let report = prepare_native_vortex_artifact(&request).expect("native prepare report");

        assert_eq!(report.status, "native_vortex_artifact_copied");
        assert_eq!(report.policy, "vortex_native_workspace_safe_byte_copy");
        assert!(report.encoded_layout_preserved);
        assert!(report.workspace_copy_performed);
        assert!(!report.same_artifact_passthrough);
        assert!(!report.reencode_performed);
        assert!(!report.upstream_vortex_scan_called);
        assert!(!report.upstream_vortex_write_called);
        assert!(report.workspace_write_report.is_some());
        assert_eq!(
            std::fs::read(&source).expect("read source"),
            std::fs::read(&target).expect("read target")
        );
        assert_eq!(
            report.source_size_bytes,
            report
                .workspace_write_report
                .as_ref()
                .unwrap()
                .bytes_written
        );
        assert_eq!(
            report.target_digest_source,
            "workspace_safe_byte_copy_streaming_sha256_digest"
        );
        assert!(!legacy_prepared_olap_state_manifest_path(&target).exists());
        std::fs::remove_dir_all(root).expect("remove temp root");
    }

    fn reuse_request_for_test(
        source: &Path,
        target: &Path,
        manifest_path: &Path,
    ) -> VortexPreparedStateReuseRequest {
        VortexPreparedStateReuseRequest::new_local(
            source,
            target,
            manifest_path.to_path_buf(),
            "csv",
            None,
            "fnv64:parse-plan",
            "all_columns",
            "caller_owned_local_vortex_artifact",
            "test-provider",
            "vortex-write",
            "ingest_certified",
        )
        .expect("reuse request")
    }

    #[test]
    #[allow(clippy::too_many_lines)]
    fn local_flat_scalar_rows_write_and_reopen_vortex_artifact() {
        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let request = VortexPreparedStateWriteRequest::new(
            &path,
            vec![
                "id".to_string(),
                "label".to_string(),
                "metric".to_string(),
                "active".to_string(),
            ],
            vec![
                vec![
                    ("id".to_string(), ScalarValue::Int64(1)),
                    ("label".to_string(), ScalarValue::Utf8("alpha".to_string())),
                    ("metric".to_string(), ScalarValue::Float64(1.5)),
                    ("active".to_string(), ScalarValue::Boolean(true)),
                ],
                vec![
                    ("id".to_string(), ScalarValue::Int64(2)),
                    ("label".to_string(), ScalarValue::Utf8("beta".to_string())),
                    ("metric".to_string(), ScalarValue::Float64(2.5)),
                    ("active".to_string(), ScalarValue::Boolean(false)),
                ],
            ],
        );

        let report = write_flat_scalar_vortex_prepared_state(request).expect("write report");

        assert_eq!(report.row_count, 2);
        assert_eq!(report.reopen_row_count, 2);
        assert_eq!(
            report.reopen_verification_status,
            "reopen_metadata_row_count_verified"
        );
        assert!(report.artifact_digest.starts_with("sha256:"));
        assert_eq!(
            report.artifact_digest_source,
            "workspace_safe_streaming_sha256_digest"
        );
        assert_eq!(report.digest_micros, 0);
        assert_eq!(
            report.workspace_write_report.bytes_written,
            report.bytes_written
        );
        assert!(
            report
                .workspace_write_report
                .output_digest
                .starts_with("sha256:")
        );
        assert_eq!(
            report.artifact_digest,
            report.workspace_write_report.output_digest
        );
        assert_eq!(report.workspace_write_report.commit_status, "committed");
        assert_eq!(
            report.workspace_write_report.commit_mode,
            "atomic_create_if_absent_hard_link_same_directory"
        );
        assert!(
            matches!(
                report.writer_context_reuse_status.as_str(),
                "thread_local_write_context_opened_for_first_artifact"
                    | "thread_local_write_context_reused_for_artifact"
            ),
            "unexpected writer context reuse status: {}",
            report.writer_context_reuse_status
        );
        assert!(report.write_micros >= report.vortex_segment_write_micros);
        assert_eq!(
            report.workspace_stage_micros,
            report
                .write_micros
                .saturating_sub(report.vortex_segment_write_micros)
        );
        assert!(!report.workspace_write_report.staging_path.exists());
        assert!(report.workspace_write_report.no_fallback_invariant_holds());
        assert_eq!(report.timing_scope, "vortex_ingest_prepare_once");
        assert_eq!(report.certification_level, "ingest_certified");
        assert_eq!(
            report.column_family_summary(),
            "id:int64,label:utf8,metric:float64,active:boolean"
        );
        assert!(report.preparation_included);
        assert!(!report.query_timing_starts_after_preparation);
        assert_eq!(report.array_build_provider_kind, "shardloom_kernel");
        assert_eq!(
            report.array_build_provider_surface,
            "shardloom_scalar_rows_to_vortex_struct"
        );
        assert_eq!(report.array_build_strategy, "scalar_rows_to_vortex_struct");
        assert_eq!(report.array_build_input_layout, "materialized_rows");
        assert_eq!(report.array_build_record_batch_count, 0);
        assert!(!report.manual_scalar_copy_avoided);
        assert!(!report.layout_write_decision.runtime_decision_applied);
        assert_eq!(
            report.layout_write_decision.blocker,
            "layout_write_advisor_not_attached_to_writer"
        );
        assert_eq!(
            report.preparation_spine.schema_version,
            VORTEX_PREPARATION_SPINE_SCHEMA_VERSION
        );
        assert_eq!(
            report.preparation_spine.status,
            "admitted_local_preparation_spine"
        );
        assert_eq!(
            report.preparation_spine.vortex_first_decision,
            "implement_shardloom_kernel"
        );
        assert_eq!(report.preparation_spine.provider_kind, "shardloom_kernel");
        assert_eq!(
            report.preparation_spine.source_surface,
            "local_text_source_state_scalar_rows"
        );
        assert_eq!(report.preparation_spine.split_count, 1);
        assert_eq!(
            report.preparation_spine.native_io_certificate_status,
            "certified_local_vortex_preparation_spine"
        );
        assert!(!report.preparation_spine.fallback_attempted);
        assert!(!report.preparation_spine.external_engine_invoked);
        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[test]
    fn local_vortex_write_removes_legacy_prepared_olap_sidecars_for_target() {
        let root = temp_test_root("legacy-sidecar-cleanup");
        let target = root.join("prepared.vortex");
        let legacy_manifest = legacy_prepared_olap_state_manifest_path(&target);
        let legacy_sidecar_dir = legacy_prepared_olap_state_sidecar_dir(&target);
        std::fs::create_dir_all(
            legacy_manifest
                .parent()
                .expect("legacy manifest parent exists"),
        )
        .expect("create legacy sidecar root");
        std::fs::write(&legacy_manifest, b"legacy exact sidecar manifest")
            .expect("write legacy manifest");
        std::fs::create_dir_all(&legacy_sidecar_dir).expect("create legacy sidecar dir");
        std::fs::write(legacy_sidecar_dir.join("query-summary.json"), b"{}")
            .expect("write legacy sidecar payload");

        let report = write_test_prepared_vortex_artifact(&target, 90);

        assert!(target.exists());
        assert_eq!(report.workspace_write_report.commit_status, "committed");
        assert!(
            !legacy_manifest.exists(),
            "legacy prepared OLAP manifest should be removed after successful artifact write"
        );
        assert!(
            !legacy_sidecar_dir.exists(),
            "legacy prepared OLAP sidecar directory should be removed after successful artifact write"
        );
        std::fs::remove_dir_all(root).expect("remove test root");
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    fn local_flat_scalar_binary_rows_write_reopens_exact_bytes() {
        use arrow_array::{BinaryArray, StructArray};
        use arrow_schema::{DataType, Field, Schema};

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-binary-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let columns = vec!["id".to_string(), "payload".to_string(), "label".to_string()];
        let request = VortexPreparedStateWriteRequest::new(
            &path,
            columns,
            vec![
                vec![
                    ("id".to_string(), ScalarValue::Int64(1)),
                    (
                        "payload".to_string(),
                        ScalarValue::Binary(vec![0x00, 0xff, 0x10]),
                    ),
                    ("label".to_string(), ScalarValue::Utf8("alpha".to_string())),
                ],
                vec![
                    ("id".to_string(), ScalarValue::Int64(2)),
                    ("payload".to_string(), ScalarValue::Binary(Vec::new())),
                    ("label".to_string(), ScalarValue::Utf8("empty".to_string())),
                ],
                vec![
                    ("id".to_string(), ScalarValue::Int64(3)),
                    ("payload".to_string(), ScalarValue::Binary(b"raw".to_vec())),
                    ("label".to_string(), ScalarValue::Utf8("omega".to_string())),
                ],
            ],
        );

        let report = write_flat_scalar_vortex_prepared_state(request).expect("write report");

        assert_eq!(report.row_count, 3);
        assert_eq!(report.reopen_row_count, 3);
        assert_eq!(
            report.column_family_summary(),
            "id:int64,payload:binary,label:utf8"
        );
        assert_eq!(report.array_build_provider_kind, "shardloom_kernel");
        assert_eq!(
            report.array_build_provider_surface,
            "shardloom_scalar_rows_to_vortex_struct"
        );
        assert!(report.upstream_vortex_write_called);
        assert!(!report.upstream_vortex_scan_called);

        let schema = Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("payload", DataType::Binary, false),
            Field::new("label", DataType::Utf8, false),
        ]);
        let arrow = reopen_vortex_artifact_as_arrow_struct(&path, &schema);
        let struct_array = arrow
            .as_any()
            .downcast_ref::<StructArray>()
            .expect("arrow struct");
        let payload = struct_array
            .column_by_name("payload")
            .expect("payload column")
            .as_any()
            .downcast_ref::<BinaryArray>()
            .expect("binary payload column");
        assert_eq!(payload.value(0), &[0x00, 0xff, 0x10]);
        assert_eq!(payload.value(1), &[] as &[u8]);
        assert_eq!(payload.value(2), b"raw");
        assert_eq!(payload.null_count(), 0);

        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[test]
    fn local_flat_scalar_leading_null_rows_infer_family_from_later_values() {
        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-leading-null-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let request = VortexPreparedStateWriteRequest::new(
            &path,
            vec!["id".to_string()],
            vec![
                vec![("id".to_string(), ScalarValue::Null)],
                vec![("id".to_string(), ScalarValue::Int64(42))],
            ],
        );

        let report = write_flat_scalar_vortex_prepared_state(request).expect("write report");

        assert_eq!(report.row_count, 2);
        assert_eq!(report.reopen_row_count, 2);
        assert_eq!(report.column_family_summary(), "id:int64");
        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[test]
    fn local_flat_scalar_all_null_rows_without_dtype_default_to_nullable_utf8() {
        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-default-null-utf8-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let request = VortexPreparedStateWriteRequest::new(
            &path,
            vec!["value".to_string()],
            vec![vec![("value".to_string(), ScalarValue::Null)]],
        );

        let report = write_flat_scalar_vortex_prepared_state(request).expect("write report");

        assert_eq!(report.row_count, 1);
        assert_eq!(report.reopen_row_count, 1);
        assert_eq!(report.column_family_summary(), "value:utf8");
        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[test]
    fn local_flat_scalar_mixed_integer_and_float_rows_promote_to_float64() {
        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-mixed-numeric-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let request = VortexPreparedStateWriteRequest::new(
            &path,
            vec!["metric".to_string()],
            vec![
                vec![("metric".to_string(), ScalarValue::Int64(1))],
                vec![("metric".to_string(), ScalarValue::Float64(2.5))],
                vec![("metric".to_string(), ScalarValue::UInt64(3))],
            ],
        );

        let report = write_flat_scalar_vortex_prepared_state(request).expect("write report");

        assert_eq!(report.row_count, 3);
        assert_eq!(report.reopen_row_count, 3);
        assert_eq!(report.column_family_summary(), "metric:float64");
        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    fn local_flat_scalar_all_null_binary_rows_write_reopens_binary() {
        use arrow_array::{Array as _, BinaryArray, StructArray};
        use arrow_schema::{DataType, Field, Schema};

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-binary-null-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let request = VortexPreparedStateWriteRequest::new(
            &path,
            vec!["payload".to_string()],
            vec![
                vec![("payload".to_string(), ScalarValue::Null)],
                vec![("payload".to_string(), ScalarValue::Null)],
            ],
        )
        .column_dtypes(vec![Some(LogicalDType::Binary)]);

        let report = write_flat_scalar_vortex_prepared_state(request).expect("write report");

        assert_eq!(report.row_count, 2);
        assert_eq!(report.reopen_row_count, 2);
        assert_eq!(report.column_family_summary(), "payload:binary");
        let schema = Schema::new(vec![Field::new("payload", DataType::Binary, true)]);
        let arrow = reopen_vortex_artifact_as_arrow_struct(&path, &schema);
        let struct_array = arrow
            .as_any()
            .downcast_ref::<StructArray>()
            .expect("arrow struct");
        let payload = struct_array
            .column_by_name("payload")
            .expect("payload column")
            .as_any()
            .downcast_ref::<BinaryArray>()
            .expect("binary payload column");
        assert_eq!(payload.len(), 2);
        assert!(payload.is_null(0));
        assert!(payload.is_null(1));
        assert_eq!(payload.null_count(), 2);

        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    #[allow(clippy::too_many_lines)]
    fn local_flat_scalar_all_null_typed_rows_write_reopens_nullable_scalars() {
        use arrow_array::{
            Array as _, BooleanArray, Date32Array, Float64Array, Int64Array, StringArray,
            StructArray, TimestampMicrosecondArray, UInt64Array,
        };
        use arrow_schema::{DataType, Field, Schema, TimeUnit};

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-scalar-null-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let columns = vec![
            "active".to_string(),
            "id".to_string(),
            "count".to_string(),
            "metric".to_string(),
            "label".to_string(),
            "event_day".to_string(),
            "event_ts".to_string(),
        ];
        let null_row = || {
            vec![
                ("active".to_string(), ScalarValue::Null),
                ("id".to_string(), ScalarValue::Null),
                ("count".to_string(), ScalarValue::Null),
                ("metric".to_string(), ScalarValue::Null),
                ("label".to_string(), ScalarValue::Null),
                ("event_day".to_string(), ScalarValue::Null),
                ("event_ts".to_string(), ScalarValue::Null),
            ]
        };
        let request =
            VortexPreparedStateWriteRequest::new(&path, columns, vec![null_row(), null_row()])
                .column_dtypes(vec![
                    Some(LogicalDType::Boolean),
                    Some(LogicalDType::Int64),
                    Some(LogicalDType::UInt64),
                    Some(LogicalDType::Float64),
                    Some(LogicalDType::Utf8),
                    Some(LogicalDType::Date32),
                    Some(LogicalDType::TimestampMicros),
                ]);

        let report = write_flat_scalar_vortex_prepared_state(request).expect("write report");

        assert_eq!(report.row_count, 2);
        assert_eq!(report.reopen_row_count, 2);
        assert_eq!(
            report.column_family_summary(),
            "active:boolean,id:int64,count:uint64,metric:float64,label:utf8,event_day:date32,event_ts:timestamp_micros"
        );
        let schema = Schema::new(vec![
            Field::new("active", DataType::Boolean, true),
            Field::new("id", DataType::Int64, true),
            Field::new("count", DataType::UInt64, true),
            Field::new("metric", DataType::Float64, true),
            Field::new("label", DataType::Utf8, true),
            Field::new("event_day", DataType::Date32, true),
            Field::new(
                "event_ts",
                DataType::Timestamp(TimeUnit::Microsecond, None),
                true,
            ),
        ]);
        let arrow = reopen_vortex_artifact_as_arrow_struct(&path, &schema);
        let struct_array = arrow
            .as_any()
            .downcast_ref::<StructArray>()
            .expect("arrow struct");

        assert_eq!(
            struct_array
                .column_by_name("active")
                .expect("active column")
                .as_any()
                .downcast_ref::<BooleanArray>()
                .expect("boolean column")
                .null_count(),
            2
        );
        assert_eq!(
            struct_array
                .column_by_name("id")
                .expect("id column")
                .as_any()
                .downcast_ref::<Int64Array>()
                .expect("int64 column")
                .null_count(),
            2
        );
        assert_eq!(
            struct_array
                .column_by_name("count")
                .expect("count column")
                .as_any()
                .downcast_ref::<UInt64Array>()
                .expect("uint64 column")
                .null_count(),
            2
        );
        assert_eq!(
            struct_array
                .column_by_name("metric")
                .expect("metric column")
                .as_any()
                .downcast_ref::<Float64Array>()
                .expect("float64 column")
                .null_count(),
            2
        );
        assert_eq!(
            struct_array
                .column_by_name("label")
                .expect("label column")
                .as_any()
                .downcast_ref::<StringArray>()
                .expect("utf8 column")
                .null_count(),
            2
        );
        assert_eq!(
            struct_array
                .column_by_name("event_day")
                .expect("event_day column")
                .as_any()
                .downcast_ref::<Date32Array>()
                .expect("date32 column")
                .null_count(),
            2
        );
        assert_eq!(
            struct_array
                .column_by_name("event_ts")
                .expect("event_ts column")
                .as_any()
                .downcast_ref::<TimestampMicrosecondArray>()
                .expect("timestamp_micros column")
                .null_count(),
            2
        );

        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    #[allow(clippy::too_many_lines)]
    fn local_flat_scalar_mixed_null_rows_write_reopens_nullable_scalars() {
        use arrow_array::{
            Array as _, BooleanArray, Date32Array, Float64Array, Int64Array, StringArray,
            StructArray, TimestampMicrosecondArray, UInt64Array,
        };
        use arrow_schema::{DataType, Field, Schema, TimeUnit};

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-scalar-mixed-null-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let request = VortexPreparedStateWriteRequest::new(
            &path,
            vec![
                "active".to_string(),
                "id".to_string(),
                "count".to_string(),
                "metric".to_string(),
                "label".to_string(),
                "event_day".to_string(),
                "event_ts".to_string(),
            ],
            vec![
                vec![
                    ("active".to_string(), ScalarValue::Boolean(true)),
                    ("id".to_string(), ScalarValue::Int64(-10)),
                    ("count".to_string(), ScalarValue::UInt64(7)),
                    ("metric".to_string(), ScalarValue::Float64(1.5)),
                    ("label".to_string(), ScalarValue::Utf8("alpha".to_string())),
                    ("event_day".to_string(), ScalarValue::Date32(20_000)),
                    (
                        "event_ts".to_string(),
                        ScalarValue::TimestampMicros(1_700_000_000_000_000),
                    ),
                ],
                vec![
                    ("active".to_string(), ScalarValue::Null),
                    ("id".to_string(), ScalarValue::Null),
                    ("count".to_string(), ScalarValue::Null),
                    ("metric".to_string(), ScalarValue::Null),
                    ("label".to_string(), ScalarValue::Null),
                    ("event_day".to_string(), ScalarValue::Null),
                    ("event_ts".to_string(), ScalarValue::Null),
                ],
                vec![
                    ("active".to_string(), ScalarValue::Boolean(false)),
                    ("id".to_string(), ScalarValue::Int64(20)),
                    ("count".to_string(), ScalarValue::UInt64(8)),
                    ("metric".to_string(), ScalarValue::Float64(2.5)),
                    ("label".to_string(), ScalarValue::Utf8("omega".to_string())),
                    ("event_day".to_string(), ScalarValue::Date32(20_001)),
                    (
                        "event_ts".to_string(),
                        ScalarValue::TimestampMicros(1_700_000_000_001_000),
                    ),
                ],
            ],
        );

        let report = write_flat_scalar_vortex_prepared_state(request).expect("write report");

        assert_eq!(report.row_count, 3);
        assert_eq!(report.reopen_row_count, 3);
        assert_eq!(
            report.column_family_summary(),
            "active:boolean,id:int64,count:uint64,metric:float64,label:utf8,event_day:date32,event_ts:timestamp_micros"
        );
        let schema = Schema::new(vec![
            Field::new("active", DataType::Boolean, true),
            Field::new("id", DataType::Int64, true),
            Field::new("count", DataType::UInt64, true),
            Field::new("metric", DataType::Float64, true),
            Field::new("label", DataType::Utf8, true),
            Field::new("event_day", DataType::Date32, true),
            Field::new(
                "event_ts",
                DataType::Timestamp(TimeUnit::Microsecond, None),
                true,
            ),
        ]);
        let arrow = reopen_vortex_artifact_as_arrow_struct(&path, &schema);
        let struct_array = arrow
            .as_any()
            .downcast_ref::<StructArray>()
            .expect("arrow struct");
        let active = struct_array
            .column_by_name("active")
            .expect("active column")
            .as_any()
            .downcast_ref::<BooleanArray>()
            .expect("boolean column");
        assert!(active.value(0));
        assert!(active.is_null(1));
        assert!(!active.value(2));
        assert_eq!(active.null_count(), 1);
        let id = struct_array
            .column_by_name("id")
            .expect("id column")
            .as_any()
            .downcast_ref::<Int64Array>()
            .expect("int64 column");
        assert_eq!(id.value(0), -10);
        assert!(id.is_null(1));
        assert_eq!(id.value(2), 20);
        let count = struct_array
            .column_by_name("count")
            .expect("count column")
            .as_any()
            .downcast_ref::<UInt64Array>()
            .expect("uint64 column");
        assert_eq!(count.value(0), 7);
        assert!(count.is_null(1));
        assert_eq!(count.value(2), 8);
        let metric = struct_array
            .column_by_name("metric")
            .expect("metric column")
            .as_any()
            .downcast_ref::<Float64Array>()
            .expect("float64 column");
        assert!((metric.value(0) - 1.5).abs() < f64::EPSILON);
        assert!(metric.is_null(1));
        assert!((metric.value(2) - 2.5).abs() < f64::EPSILON);
        let label = struct_array
            .column_by_name("label")
            .expect("label column")
            .as_any()
            .downcast_ref::<StringArray>()
            .expect("utf8 column");
        assert_eq!(label.value(0), "alpha");
        assert!(label.is_null(1));
        assert_eq!(label.value(2), "omega");
        let event_day = struct_array
            .column_by_name("event_day")
            .expect("event_day column")
            .as_any()
            .downcast_ref::<Date32Array>()
            .expect("date32 column");
        assert_eq!(event_day.value(0), 20_000);
        assert!(event_day.is_null(1));
        assert_eq!(event_day.value(2), 20_001);
        let event_ts = struct_array
            .column_by_name("event_ts")
            .expect("event_ts column")
            .as_any()
            .downcast_ref::<TimestampMicrosecondArray>()
            .expect("timestamp_micros column");
        assert_eq!(event_ts.value(0), 1_700_000_000_000_000);
        assert!(event_ts.is_null(1));
        assert_eq!(event_ts.value(2), 1_700_000_000_001_000);

        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    fn local_flat_scalar_decimal_rows_write_reopens_decimal128() {
        use arrow_array::{Decimal128Array, StructArray};
        use arrow_schema::{DataType, Field, Schema};

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-decimal-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let request = VortexPreparedStateWriteRequest::new(
            &path,
            vec!["id".to_string(), "amount".to_string()],
            vec![
                vec![
                    ("id".to_string(), ScalarValue::Int64(1)),
                    (
                        "amount".to_string(),
                        ScalarValue::Decimal128 {
                            value: 1234,
                            precision: 10,
                            scale: 2,
                        },
                    ),
                ],
                vec![
                    ("id".to_string(), ScalarValue::Int64(2)),
                    (
                        "amount".to_string(),
                        ScalarValue::Decimal128 {
                            value: -800,
                            precision: 10,
                            scale: 2,
                        },
                    ),
                ],
            ],
        );

        let report = write_flat_scalar_vortex_prepared_state(request).expect("write report");

        assert_eq!(report.row_count, 2);
        assert_eq!(report.reopen_row_count, 2);
        assert_eq!(
            report.column_family_summary(),
            "id:int64,amount:decimal128(10,2)"
        );
        assert_eq!(report.array_build_provider_kind, "shardloom_kernel");
        assert_eq!(
            report.array_build_provider_surface,
            "shardloom_scalar_rows_to_vortex_struct"
        );
        assert!(report.upstream_vortex_write_called);
        assert!(!report.upstream_vortex_scan_called);

        let schema = Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("amount", DataType::Decimal128(10, 2), false),
        ]);
        let arrow = reopen_vortex_artifact_as_arrow_struct(&path, &schema);
        let struct_array = arrow
            .as_any()
            .downcast_ref::<StructArray>()
            .expect("arrow struct");
        let amount = struct_array
            .column_by_name("amount")
            .expect("amount column")
            .as_any()
            .downcast_ref::<Decimal128Array>()
            .expect("decimal amount column");
        assert_eq!(amount.value(0), 1234);
        assert_eq!(amount.value(1), -800);
        assert_eq!(amount.null_count(), 0);

        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    fn local_flat_scalar_all_null_decimal_rows_write_reopens_decimal128() {
        use arrow_array::{Array as _, Decimal128Array, StructArray};
        use arrow_schema::{DataType, Field, Schema};

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-decimal-null-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let request = VortexPreparedStateWriteRequest::new(
            &path,
            vec!["amount".to_string()],
            vec![
                vec![("amount".to_string(), ScalarValue::Null)],
                vec![("amount".to_string(), ScalarValue::Null)],
            ],
        )
        .column_dtypes(vec![Some(LogicalDType::Extension(
            "decimal128(10,2)".to_string(),
        ))]);

        let report = write_flat_scalar_vortex_prepared_state(request).expect("write report");

        assert_eq!(report.row_count, 2);
        assert_eq!(report.reopen_row_count, 2);
        assert_eq!(report.column_family_summary(), "amount:decimal128(10,2)");
        let schema = Schema::new(vec![Field::new(
            "amount",
            DataType::Decimal128(10, 2),
            true,
        )]);
        let arrow = reopen_vortex_artifact_as_arrow_struct(&path, &schema);
        let struct_array = arrow
            .as_any()
            .downcast_ref::<StructArray>()
            .expect("arrow struct");
        let amount = struct_array
            .column_by_name("amount")
            .expect("amount column")
            .as_any()
            .downcast_ref::<Decimal128Array>()
            .expect("decimal amount column");
        assert_eq!(amount.len(), 2);
        assert!(amount.is_null(0));
        assert!(amount.is_null(1));
        assert_eq!(amount.null_count(), 2);

        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[test]
    fn local_flat_scalar_decimal_rows_reject_mixed_precision_scale() {
        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-decimal-mixed-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let request = VortexPreparedStateWriteRequest::new(
            &path,
            vec!["amount".to_string()],
            vec![
                vec![(
                    "amount".to_string(),
                    ScalarValue::Decimal128 {
                        value: 1234,
                        precision: 10,
                        scale: 2,
                    },
                )],
                vec![(
                    "amount".to_string(),
                    ScalarValue::Decimal128 {
                        value: 1234,
                        precision: 12,
                        scale: 2,
                    },
                )],
            ],
        );

        let error = write_flat_scalar_vortex_prepared_state(request)
            .expect_err("mixed decimal precision/scale should block");

        assert!(
            error.to_string().contains(
                "local vortex_ingest column 'amount' mixes scalar families decimal128(10,2) and decimal128(12,2)"
            ),
            "{error}"
        );
        assert!(!path.exists());
    }

    #[test]
    fn local_flat_scalar_rows_apply_layout_write_advisor_before_write() {
        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-layout-advisor-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let advisor = evaluate_vortex_layout_write_advisor(layout_advisor_input(true, "none"));
        let request = VortexPreparedStateWriteRequest::new(
            &path,
            vec!["id".to_string(), "label".to_string()],
            vec![vec![
                ("id".to_string(), ScalarValue::Int64(1)),
                ("label".to_string(), ScalarValue::Utf8("alpha".to_string())),
            ]],
        )
        .layout_write_advisor(advisor);

        let report = write_flat_scalar_vortex_prepared_state(request).expect("write report");

        assert!(report.layout_write_decision.runtime_decision_applied);
        assert_eq!(
            report.layout_write_decision.selected_strategy,
            "single_vortex_artifact_embedded_olap_layout_statistics"
        );
        assert!(
            report
                .layout_write_decision
                .strategy_decision_digest
                .starts_with("fnv64:")
        );
        assert!(report.layout_write_decision.provider_admitted);
        assert_eq!(
            report.layout_write_decision.strategy_decision_digest,
            report.writer_physical_design.strategy_decision_digest
        );
        assert_eq!(report.writer_physical_design.status, "applied");
        assert_eq!(
            report.writer_physical_design.provider_decision,
            "use_shardloom_native_kernel_then_vortex_writer"
        );
        assert_eq!(
            report.writer_physical_design.source_stage_plan,
            "validated_flat_scalar_rows_already_materialized"
        );
        assert_eq!(report.writer_physical_design.array_build_prefetch_window, 0);
        assert_eq!(
            report.writer_physical_design.writer_row_block_size,
            VORTEX_PREPARED_OLAP_WRITER_FINE_ROW_BLOCK_SIZE
        );
        assert_eq!(
            report.writer_physical_design.writer_block_target_bytes,
            VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_BLOCK_TARGET_BYTES
        );
        assert_eq!(
            report.writer_physical_design.no_fallback_policy,
            "native_vortex_writer_provider_only_no_spark_datafusion_duckdb_polars_velox_fallback"
        );
        assert_eq!(report.layout_write_decision.blocker, "none");
        assert_eq!(
            report.writer_layout_strategy_applied,
            "vortex_write_strategy_row_block_4096_embedded_olap_layout_statistics"
        );
        assert_eq!(
            report.writer_layout_row_block_size,
            VORTEX_PREPARED_OLAP_WRITER_FINE_ROW_BLOCK_SIZE
        );
        assert_eq!(
            report.writer_layout_block_target_bytes,
            VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_BLOCK_TARGET_BYTES
        );
        assert_eq!(
            report.writer_profile_selection_reason,
            "small_source_fine_row_blocks_default_writer_profile"
        );
        assert_eq!(
            report.writer_profile_regression_guard,
            "small_source_default_profile_preserves_fixture_latency"
        );
        assert_eq!(report.reopen_row_count, 1);
        assert_ne!(
            report.prepared_olap_layout_inventory.root_layout_encoding,
            "not_available"
        );
        assert_ne!(
            report
                .prepared_olap_layout_inventory
                .layout_encoding_inventory,
            "not_available"
        );
        assert!(
            report
                .prepared_olap_layout_inventory
                .segment_membership_status
                .starts_with("segment_map_available")
        );
        assert_eq!(
            report
                .prepared_olap_layout_inventory
                .layout_reader_cache_status,
            "enabled_for_local_metadata_open"
        );
        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[test]
    fn large_writer_summary_defers_layout_inventory_until_query_open() {
        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-large-deferred-inventory-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        std::fs::write(&path, b"placeholder").expect("write placeholder artifact");
        let mut advisor_input = layout_advisor_input(true, "none");
        advisor_input.row_count = VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_THRESHOLD;
        advisor_input.source_byte_count = VORTEX_PREPARED_OLAP_LARGE_REOPEN_DEFER_BYTES;
        advisor_input.writer_parallelism_budget = 2;
        advisor_input.workload_constitution =
            "product_vortex_prepare_once;format=parquet;scale=large_olap;adapter=streaming_columnar_source_state;profile=url_time_counter_olap;layout_family=url_time_counter_dictionary_stats_layout;text_domain=true;time_bucket=true;counter=true;key_profile=high_cardinality_numeric_text_time_keys;dictionary=source_dictionary_or_derived_dictionary_evidence"
                .to_string();
        let advisor = evaluate_vortex_layout_write_advisor(advisor_input);
        assert_eq!(
            advisor.writer_admission_policy,
            VORTEX_PRODUCT_LOCAL_INGEST_PREPARE_ONCE_ADMISSION_POLICY
        );
        let decision = VortexLayoutWriteRuntimeDecision::applied(
            &advisor,
            &path,
            "vortex_array_kernel",
            "ArrayRef::from_arrow(RecordBatch);streaming ArrayIterator",
            VortexIngestCertificationLevel::IngestCertified,
        );

        assert!(should_defer_prepared_vortex_artifact_layout_inventory(
            VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_THRESHOLD,
            VORTEX_PREPARED_OLAP_LARGE_REOPEN_DEFER_BYTES,
            &decision
        ));
        let inventory = VortexPreparedOlapLayoutInventory::deferred_from_writer_summary(
            &path,
            VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_THRESHOLD,
            VORTEX_PREPARED_OLAP_LARGE_REOPEN_DEFER_BYTES,
            &decision,
        );

        assert!(inventory.is_admitted());
        assert_eq!(
            inventory.status,
            VORTEX_PREPARED_OLAP_LAYOUT_INVENTORY_DEFERRED_STATUS
        );
        assert_eq!(
            inventory.row_count,
            Some(VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_THRESHOLD)
        );
        assert_eq!(
            inventory.layout_reader_cache_status,
            "deferred_for_large_artifact_public_prepare"
        );
        assert!(inventory.metadata_persisted_in_artifact);
        let primitive = VortexSegmentMetadataPrimitiveReport::from_inventory(
            &inventory,
            "test_large_writer_summary_deferred",
            decision
                .writer_physical_design
                .strategy_decision_digest
                .clone(),
        );
        assert_eq!(
            primitive.status,
            "deferred_until_query_open_writer_summary_row_count_only"
        );
        assert!(primitive.requires_query_open());
        assert!(primitive.is_metadata_count_admitted());
        assert!(!primitive.is_predicate_pruning_admitted());
        assert_eq!(
            primitive
                .admission_for_query_family(VortexSegmentMetadataQueryFamily::PredicatePruning),
            "deferred_until_query_open"
        );
        assert_eq!(primitive.segment_count_field(), "unknown");
        assert!(!primitive.fallback_attempted);
        assert!(!primitive.external_engine_invoked);
        assert!(reopen_verification_is_certified(
            VORTEX_PREPARED_OLAP_REOPEN_DEFERRED_STATUS
        ));
        assert!(reopen_verification_uses_writer_summary(
            VORTEX_PREPARED_OLAP_REOPEN_DEFERRED_STATUS
        ));

        std::fs::remove_file(path).expect("remove artifact");
    }

    #[test]
    fn source_text_large_source_writer_profile_uses_advisor_candidate_fields() {
        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-layout-advisor-field-list-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let mut advisor_input = layout_advisor_input(true, "none");
        advisor_input.row_count = VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_THRESHOLD;
        advisor_input.source_byte_count = 1_073_741_824;
        advisor_input.workload_constitution =
            "product_vortex_prepare_once;format=parquet;scale=large_olap;adapter=streaming_columnar_source_state;profile=url_time_counter_olap;layout_family=url_time_counter_dictionary_stats_layout;text_domain=true;time_bucket=true;counter=true;key_profile=high_cardinality_numeric_text_time_keys;dictionary=source_dictionary_or_derived_dictionary_evidence"
                .to_string();
        advisor_input.writer_compression_candidate_fields = vec![
            "URL".to_string(),
            "Title".to_string(),
            "__shardloom_derived_utf8_len_URL".to_string(),
            "Params".to_string(),
            "URL".to_string(),
        ];
        let advisor = evaluate_vortex_layout_write_advisor(advisor_input);
        assert_eq!(
            advisor.writer_admission_policy,
            VORTEX_PRODUCT_LOCAL_INGEST_PREPARE_ONCE_ADMISSION_POLICY
        );
        let decision = VortexLayoutWriteRuntimeDecision::applied(
            &advisor,
            &path,
            "vortex_array_kernel",
            "ArrayRef::from_arrow(RecordBatch);streaming ArrayIterator",
            VortexIngestCertificationLevel::IngestCertified,
        );

        assert_eq!(
            decision.writer_compression_field_names,
            vec!["Params".to_string(), "Title".to_string(), "URL".to_string()]
        );
        assert_eq!(decision.writer_compression_field_decisions.len(), 4);
        assert!(
            decision
                .writer_compression_field_decisions
                .iter()
                .any(|decision| decision.contains(
                    "field=URL;decision=compress;codec=zstd;level=-3;reason=large_source_artifact_size_guard_query_hot_text"
                ))
        );
        assert!(
            decision
                .writer_compression_field_decisions
                .iter()
                .any(|decision| decision.contains(
                    "field=Title;decision=compress;codec=zstd;level=-3;reason=large_source_artifact_size_guard_query_hot_text"
                ))
        );
        assert!(
            decision
                .writer_compression_field_decisions
                .iter()
                .any(|decision| decision.contains(
                    "field=Params;decision=compress;codec=zstd;level=-3;reason=payload_text_storage_benefit"
                ))
        );
        assert!(
            decision
                .writer_compression_field_decisions
                .iter()
                .any(|decision| decision
                    .contains("field=__shardloom_derived_utf8_len_URL;decision=skip;codec=none"))
        );
    }

    #[test]
    fn layout_writer_rejects_legacy_scoped_public_admission_policy() {
        let mut advisor_input = layout_advisor_input(true, "none");
        advisor_input.writer_admission_policy =
            "scoped_local_vortex_ingest_prepare_once".to_string();

        let advisor = evaluate_vortex_layout_write_advisor(advisor_input);

        assert_eq!(
            advisor.status,
            "vortex_layout_write_advisor.unsupported_writer_admission_policy"
        );
        assert_eq!(
            advisor.blocker,
            "vortex_layout_write_advisor.unsupported_writer_admission_policy"
        );
        assert!(!advisor.provider_admitted);
    }

    #[test]
    fn local_flat_scalar_rows_use_source_text_large_source_layout_row_blocks_when_advised() {
        let applied = shardloom_exec::compute_pool::bounded_cpu_parallelism(2);
        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-layout-advisor-large-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let mut advisor_input = layout_advisor_input(true, "none");
        advisor_input.row_count = VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_THRESHOLD;
        advisor_input.source_byte_count = 1_073_741_824;
        advisor_input.writer_parallelism_budget = 2;
        advisor_input.writer_compression_candidate_fields = vec!["payload".to_string()];
        advisor_input.workload_constitution =
            "product_vortex_prepare_once;format=parquet;scale=large_olap;adapter=streaming_columnar_source_state;profile=url_time_counter_olap;layout_family=url_time_counter_dictionary_stats_layout;text_domain=true;time_bucket=true;counter=true;key_profile=high_cardinality_numeric_text_time_keys;dictionary=source_dictionary_or_derived_dictionary_evidence"
                .to_string();
        let advisor = evaluate_vortex_layout_write_advisor(advisor_input);
        let request = VortexPreparedStateWriteRequest::new(
            &path,
            vec!["id".to_string(), "payload".to_string()],
            vec![vec![
                ("id".to_string(), ScalarValue::Int64(1)),
                (
                    "payload".to_string(),
                    ScalarValue::Utf8("alpha".to_string()),
                ),
            ]],
        )
        .layout_write_advisor(advisor);

        let report = write_flat_scalar_vortex_prepared_state(request).expect("write report");

        assert!(report.layout_write_decision.runtime_decision_applied);
        assert_eq!(
            report.layout_write_decision.writer_row_block_size,
            VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_BLOCK_SIZE
        );
        assert_eq!(
            report.layout_write_decision.writer_block_target_bytes,
            VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_BLOCK_TARGET_BYTES
        );
        assert_eq!(
            report.layout_write_decision.writer_compression_policy,
            VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_LARGE_SOURCE_COMPRESSION_POLICY
        );
        assert_eq!(
            report.layout_write_decision.writer_compression_concurrency,
            2
        );
        assert_eq!(report.layout_write_decision.writer_stats_concurrency, 2);
        assert_eq!(
            report.writer_layout_strategy_applied,
            "vortex_write_strategy_row_block_262144_target_1mb_source_text_fast_zstd_no_dict_numeric_btrblocks_embedded_olap_layout_statistics"
        );
        assert_eq!(
            report.writer_layout_row_block_size,
            VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_BLOCK_SIZE
        );
        assert_eq!(
            report.writer_layout_block_target_bytes,
            VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_BLOCK_TARGET_BYTES
        );
        assert_eq!(
            report.writer_compression_policy,
            VORTEX_PREPARED_OLAP_WRITER_SOURCE_TEXT_LARGE_SOURCE_COMPRESSION_POLICY
        );
        assert_eq!(report.writer_compression_field_count(), 1);
        assert_eq!(report.writer_compression_field_names(), "payload");
        assert_eq!(report.writer_compression_decision_count(), 1);
        assert!(
            report
                .writer_compression_decisions()
                .contains("field=payload;decision=compress;codec=zstd")
        );
        assert!(
            report
                .encoding_summary()
                .contains("compression_field_count=1")
        );
        assert!(
            report
                .encoding_summary()
                .contains("compression_decision_count=1")
        );
        assert_eq!(report.writer_runtime_requested_parallelism, 2);
        assert_eq!(report.writer_runtime_applied_parallelism, applied);
        assert_eq!(report.writer_runtime_background_workers, applied - 1);
        assert_eq!(report.writer_runtime_kind, writer_runtime_kind(applied - 1));
        assert_eq!(report.writer_compression_concurrency, applied);
        assert_eq!(report.writer_stats_concurrency, applied);
        assert_eq!(
            report.writer_profile_selection_reason,
            "large_text_source_fast_zstd_profile"
        );
        assert_eq!(
            report.writer_profile_regression_guard,
            "text_zstd_policy_prior_uat_backed_numeric_btrblocks_requires_lifecycle_acceptance"
        );
        assert_eq!(report.reopen_row_count, 1);
        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[test]
    fn local_flat_scalar_rows_coalesce_very_large_high_cardinality_text_blocks() {
        let applied = shardloom_exec::compute_pool::bounded_cpu_parallelism(2);
        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-layout-advisor-very-large-text-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let mut advisor_input = layout_advisor_input(true, "none");
        advisor_input.row_count = 100_000_000;
        advisor_input.source_byte_count =
            VORTEX_PREPARED_OLAP_WRITER_LARGE_TEXT_COALESCED_SOURCE_BYTES;
        advisor_input.writer_parallelism_budget = 2;
        advisor_input.writer_compression_candidate_fields = vec!["URL".to_string()];
        advisor_input.workload_constitution =
            "product_vortex_prepare_once;format=parquet;scale=large_olap;adapter=streaming_columnar_source_state;profile=url_time_counter_olap;layout_family=url_time_counter_dictionary_stats_layout;text_domain=true;time_bucket=true;counter=true;key_profile=high_cardinality_numeric_text_time_keys;dictionary=source_dictionary_or_derived_dictionary_evidence"
                .to_string();
        let advisor = evaluate_vortex_layout_write_advisor(advisor_input);
        let request = VortexPreparedStateWriteRequest::new(
            &path,
            vec!["id".to_string(), "URL".to_string()],
            vec![vec![
                ("id".to_string(), ScalarValue::Int64(1)),
                (
                    "URL".to_string(),
                    ScalarValue::Utf8("https://example.test".to_string()),
                ),
            ]],
        )
        .layout_write_advisor(advisor);

        let report = write_flat_scalar_vortex_prepared_state(request).expect("write report");

        assert_eq!(
            report.layout_write_decision.writer_row_block_size,
            VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_BLOCK_SIZE
        );
        assert_eq!(
            report.layout_write_decision.writer_block_target_bytes,
            VORTEX_PREPARED_OLAP_WRITER_FAST_LOAD_BLOCK_TARGET_BYTES
        );
        assert_eq!(
            report.writer_layout_strategy_applied,
            "vortex_write_strategy_row_block_262144_target_8mb_source_text_fast_zstd_no_dict_numeric_btrblocks_embedded_olap_layout_statistics"
        );
        assert_eq!(report.writer_compression_concurrency, applied);
        assert_eq!(report.writer_compression_field_count(), 1);
        assert_eq!(report.writer_compression_field_names(), "URL");
        assert!(
            report
                .writer_compression_decisions()
                .contains("field=URL;decision=compress;codec=zstd;level=-3;reason=large_source_artifact_size_guard_query_hot_text")
        );
        assert_eq!(report.writer_runtime_requested_parallelism, 2);
        assert_eq!(report.writer_runtime_applied_parallelism, applied);
        assert_eq!(report.writer_runtime_background_workers, applied - 1);
        assert_eq!(report.writer_stats_concurrency, applied);
        assert_eq!(
            report.writer_layout_block_target_bytes,
            VORTEX_PREPARED_OLAP_WRITER_FAST_LOAD_BLOCK_TARGET_BYTES
        );
        assert_eq!(
            report.writer_profile_selection_reason,
            "large_text_high_cardinality_source_coalesced_fast_zstd_profile"
        );
        assert_eq!(
            report.writer_profile_regression_guard,
            "text_zstd_policy_prior_uat_backed_numeric_btrblocks_requires_lifecycle_acceptance"
        );
        assert_eq!(report.reopen_row_count, 1);
        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[test]
    fn local_flat_scalar_rows_use_fast_load_large_source_layout_when_not_text_domain() {
        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-layout-advisor-large-numeric-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let mut advisor_input = layout_advisor_input(true, "none");
        advisor_input.row_count = VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_THRESHOLD;
        advisor_input.source_byte_count = 1_073_741_824;
        advisor_input.workload_constitution =
            "product_vortex_prepare_once;format=parquet;scale=large_olap;adapter=streaming_columnar_source_state;profile=counter_olap;layout_family=counter_typed_stats_layout;text_domain=false;time_bucket=false;counter=true;key_profile=high_cardinality_numeric_keys;dictionary=columnar_dictionary_status_provider_dependent"
                .to_string();
        let advisor = evaluate_vortex_layout_write_advisor(advisor_input);
        let request = VortexPreparedStateWriteRequest::new(
            &path,
            vec!["id".to_string(), "metric".to_string()],
            vec![vec![
                ("id".to_string(), ScalarValue::Int64(1)),
                ("metric".to_string(), ScalarValue::Float64(2.5)),
            ]],
        )
        .layout_write_advisor(advisor);

        let report = write_flat_scalar_vortex_prepared_state(request).expect("write report");

        assert!(report.layout_write_decision.runtime_decision_applied);
        assert_eq!(
            report.layout_write_decision.writer_row_block_size,
            VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_BLOCK_SIZE
        );
        assert_eq!(
            report.layout_write_decision.writer_block_target_bytes,
            VORTEX_PREPARED_OLAP_WRITER_FAST_LOAD_BLOCK_TARGET_BYTES
        );
        assert_eq!(
            report.layout_write_decision.writer_compression_policy,
            VORTEX_PREPARED_OLAP_WRITER_FAST_LOAD_LARGE_SOURCE_COMPRESSION_POLICY
        );
        assert_eq!(
            report.layout_write_decision.writer_compression_concurrency,
            VORTEX_PREPARED_OLAP_WRITER_FAST_LOAD_LARGE_SOURCE_COMPRESSION_CONCURRENCY
        );
        assert_eq!(
            report.writer_layout_strategy_applied,
            "vortex_write_strategy_row_block_262144_target_8mb_fast_load_numeric_btrblocks_embedded_olap_layout_statistics"
        );
        assert_eq!(
            report.writer_layout_block_target_bytes,
            VORTEX_PREPARED_OLAP_WRITER_FAST_LOAD_BLOCK_TARGET_BYTES
        );
        assert_eq!(
            report.writer_profile_selection_reason,
            "large_non_text_source_fast_load_numeric_btrblocks_layout_statistics"
        );
        assert_eq!(
            report.writer_profile_regression_guard,
            "non_text_large_source_numeric_btrblocks_requires_lifecycle_acceptance"
        );
        assert_eq!(report.reopen_row_count, 1);
        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[test]
    fn local_flat_scalar_rows_block_unsupported_layout_strategy_before_write() {
        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-layout-advisor-blocked-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let advisor = evaluate_vortex_layout_write_advisor(layout_advisor_input(
            false,
            "vortex_layout_write_advisor.unsupported_layout_strategy",
        ));
        let request = VortexPreparedStateWriteRequest::new(
            &path,
            vec!["id".to_string(), "label".to_string()],
            vec![vec![
                ("id".to_string(), ScalarValue::Int64(1)),
                ("label".to_string(), ScalarValue::Utf8("alpha".to_string())),
            ]],
        )
        .layout_write_advisor(advisor);

        let error = write_flat_scalar_vortex_prepared_state(request)
            .expect_err("unsupported layout strategy must block");

        assert!(error.to_string().contains(
            "vortex_layout_write_advisor.status_not_admitted:blocked_layout_write_strategy"
        ));
        assert!(
            !path.exists(),
            "blocked layout/write advisor must not create {}",
            path.display()
        );
    }

    #[test]
    fn local_flat_scalar_minimal_ingest_reads_layout_without_reopen_scan() {
        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-minimal-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let request = VortexPreparedStateWriteRequest::new(
            &path,
            vec!["id".to_string(), "label".to_string()],
            vec![vec![
                ("id".to_string(), ScalarValue::Int64(1)),
                ("label".to_string(), ScalarValue::Utf8("alpha".to_string())),
            ]],
        )
        .certification_level(VortexIngestCertificationLevel::IngestMinimal);

        let report = write_flat_scalar_vortex_prepared_state(request).expect("write report");

        assert_eq!(report.row_count, 1);
        assert_eq!(report.writer_row_count, 1);
        assert_eq!(report.reopen_row_count, 1);
        assert_eq!(report.reopen_scan_micros, 0);
        assert_eq!(
            report.reopen_verification_status,
            "not_performed_ingest_minimal"
        );
        assert_eq!(report.certification_level, "ingest_minimal");
        assert!(report.upstream_vortex_write_called);
        assert!(!report.upstream_vortex_scan_called);
        assert_ne!(
            report.prepared_olap_layout_inventory.root_layout_encoding,
            "not_available"
        );
        assert!(
            report
                .prepared_olap_layout_inventory
                .layout_reader_cache_status
                .contains("enabled")
        );
        assert_eq!(
            report.preparation_spine.native_io_certificate_status,
            "minimal_local_vortex_preparation_spine_digest_only"
        );
        assert_eq!(
            report.preparation_spine.reopen_provider_surface,
            "not_invoked_ingest_minimal"
        );
        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[test]
    fn local_flat_scalar_rows_apply_capillary_prewrite_control_before_write() {
        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-capillary-prewrite-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let request = VortexPreparedStateWriteRequest::new(
            &path,
            vec!["id".to_string(), "label".to_string()],
            vec![
                vec![
                    ("id".to_string(), ScalarValue::Int64(1)),
                    ("label".to_string(), ScalarValue::Utf8("alpha".to_string())),
                ],
                vec![
                    ("id".to_string(), ScalarValue::Int64(2)),
                    ("label".to_string(), ScalarValue::Utf8("beta".to_string())),
                ],
            ],
        )
        .capillary_prewrite_input(capillary_prewrite_test_input(&path, 2, 2));

        let report = write_flat_scalar_vortex_prepared_state(request).expect("write report");

        assert!(report.capillary_prewrite_control.scheduler_applied);
        assert_eq!(
            report.capillary_prewrite_control.status,
            "applied_before_array_build"
        );
        assert_eq!(
            report.capillary_prewrite_control.array_build_gate_status,
            "applied_prewrite_window"
        );
        assert_eq!(
            report.capillary_prewrite_control.write_gate_status,
            "applied_prewrite_window"
        );
        assert_eq!(
            report.capillary_prewrite_control.reopen_gate_status,
            "applied_prewrite_window"
        );
        assert_eq!(
            report.capillary_prewrite_control.sink_evidence_gate_status,
            "applied_prewrite_window"
        );
        assert!(report.capillary_prewrite_control.execution_window_count > 0);
        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    #[allow(clippy::too_many_lines)]
    fn local_flat_columnar_source_writes_and_reopens_vortex_artifact() {
        use std::sync::Arc;

        use arrow_array::{BooleanArray, Float64Array, Int64Array, RecordBatch, StringArray};
        use arrow_schema::{DataType, Field, Schema};

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-columnar-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let columns = vec![
            "id".to_string(),
            "label".to_string(),
            "metric".to_string(),
            "active".to_string(),
        ];
        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("label", DataType::Utf8, false),
            Field::new("metric", DataType::Float64, false),
            Field::new("active", DataType::Boolean, false),
        ]));
        let batch = RecordBatch::try_new(
            schema,
            vec![
                Arc::new(Int64Array::from(vec![1, 2])),
                Arc::new(StringArray::from(vec!["alpha", "beta"])),
                Arc::new(Float64Array::from(vec![1.5, 2.5])),
                Arc::new(BooleanArray::from(vec![true, false])),
            ],
        )
        .expect("record batch");
        let source = FlatLocalColumnarSource {
            header: columns.clone(),
            column_dtypes: vec![None; columns.len()],
            column_arrow_dtypes: vec![None; columns.len()],
            materialized_columns: columns.clone(),
            reader_projection_columns: columns,
            batches: vec![batch],
            row_count: 2,
        };
        let request = VortexPreparedStateColumnarWriteRequest::new(&path, source)
            .capillary_prewrite_input(capillary_prewrite_test_input(&path, 2, 4));

        let report = write_flat_columnar_vortex_prepared_state(request).expect("write report");

        assert_eq!(report.row_count, 2);
        assert_eq!(report.reopen_row_count, 2);
        assert_eq!(
            report.column_family_summary(),
            "id:int64,label:utf8,metric:float64,active:boolean"
        );
        assert_eq!(
            report.reopen_verification_status,
            "reopen_metadata_row_count_verified"
        );
        assert!(report.upstream_vortex_write_called);
        assert!(!report.upstream_vortex_scan_called);
        assert_eq!(report.array_build_provider_kind, "vortex_array_kernel");
        assert_eq!(
            report.array_build_provider_surface,
            "ArrayRef::from_arrow(RecordBatch)"
        );
        assert_eq!(
            report.array_build_strategy,
            "vortex_from_arrow_record_batch"
        );
        assert_eq!(
            report.array_build_input_layout,
            "arrow_record_batch_columnar_source_state"
        );
        assert_eq!(report.array_build_record_batch_count, 1);
        assert_eq!(report.stream_source_pull_micros, 0);
        assert_eq!(report.stream_array_convert_micros, 0);
        assert_eq!(
            report.stream_timing_split_status,
            "not_streaming_buffered_or_scalar_vortex_prepare"
        );
        assert_eq!(
            report.writer_coalescing_policy_status,
            "upstream_vortex_default_writer_coalescing_policy"
        );
        assert!(report.manual_scalar_copy_avoided);
        assert_eq!(
            report.preparation_spine.vortex_first_decision,
            "use_vortex_native_provider"
        );
        assert_eq!(
            report.preparation_spine.provider_kind,
            "vortex_array_kernel"
        );
        assert_eq!(report.preparation_spine.provider_crate, "vortex");
        assert_eq!(
            report.preparation_spine.provider_version,
            VORTEX_PREPARATION_SPINE_VORTEX_CRATE_VERSION
        );
        assert_eq!(
            report.preparation_spine.source_surface,
            "local_columnar_source_state_arrow_record_batches"
        );
        assert_eq!(report.preparation_spine.split_count, 1);
        assert_eq!(
            report.preparation_spine.materialization_boundary_status,
            "columnar_source_state_preserved_to_vortex_array_provider"
        );
        assert_eq!(
            report.preparation_spine.decode_boundary_status,
            "no_scalar_row_decode_for_non_empty_batches"
        );
        assert!(report.capillary_prewrite_control.scheduler_applied);
        assert_eq!(
            report.capillary_prewrite_control.array_build_gate_status,
            "applied_prewrite_window"
        );
        assert_eq!(
            report.capillary_prewrite_control.write_gate_status,
            "applied_prewrite_window"
        );
        assert_eq!(
            report.capillary_prewrite_control.reopen_gate_status,
            "applied_prewrite_window"
        );
        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    #[allow(clippy::too_many_lines)]
    fn local_flat_columnar_stream_source_writes_without_buffered_batch_source() {
        use std::collections::VecDeque;
        use std::sync::Arc;

        use arrow_array::{Int64Array, RecordBatch, StringArray};
        use arrow_schema::{DataType, Field, Schema, SchemaRef};

        struct TestRecordBatchReader {
            schema: SchemaRef,
            batches: VecDeque<RecordBatch>,
        }

        impl Iterator for TestRecordBatchReader {
            type Item = std::result::Result<RecordBatch, arrow_schema::ArrowError>;

            fn next(&mut self) -> Option<Self::Item> {
                self.batches.pop_front().map(Ok)
            }
        }

        impl arrow_array::RecordBatchReader for TestRecordBatchReader {
            fn schema(&self) -> SchemaRef {
                Arc::clone(&self.schema)
            }
        }

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-columnar-stream-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let columns = vec!["id".to_string(), "label".to_string()];
        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("label", DataType::Utf8, false),
        ]));
        let batch_1 = RecordBatch::try_new(
            Arc::clone(&schema),
            vec![
                Arc::new(Int64Array::from(vec![1, 2])),
                Arc::new(StringArray::from(vec!["alpha", "beta"])),
            ],
        )
        .expect("first record batch");
        let batch_2 = RecordBatch::try_new(
            Arc::clone(&schema),
            vec![
                Arc::new(Int64Array::from(vec![3])),
                Arc::new(StringArray::from(vec!["gamma"])),
            ],
        )
        .expect("second record batch");
        let reader = TestRecordBatchReader {
            schema,
            batches: VecDeque::from([batch_1, batch_2]),
        };
        let source = FlatLocalColumnarStreamSource {
            header: columns.clone(),
            column_dtypes: vec![None; columns.len()],
            column_arrow_dtypes: vec![Some(DataType::Int64), Some(DataType::Utf8)],
            materialized_columns: columns.clone(),
            reader_projection_columns: columns,
            row_count_hint: Some(3),
            record_batch_count_hint: Some(2),
            source_stream_batch_size: 0,
            source_stream_unit_count_hint: Some(2),
            source_stream_unit_row_ranges: Some(vec![(0, 2), (2, 3)]),
            source_stream_unit_hint_kind: "test_record_batch_count".to_string(),
            source_stream_policy: "test_source_defined_record_batches".to_string(),
            source_dictionary_preservation_status: "test_not_applicable".to_string(),
            ingest_executor_status: "serial_pull_reader".to_string(),
            ingest_executor_kind: "test_record_batch_reader".to_string(),
            ingest_executor_requested_parallelism: 1,
            ingest_executor_applied_parallelism: 1,
            ingest_executor_unit_count_hint: Some(2),
            source_identities: Vec::new(),
            #[cfg(feature = "vortex-write")]
            ingest_runtime: None,
            embedded_derived_build_micros:
                crate::universal_format_io::new_embedded_derived_build_micros_counter(),
            reader: Box::new(reader),
        };
        let request = VortexPreparedStateColumnarStreamWriteRequest::new(&path, source)
            .capillary_prewrite_input(capillary_prewrite_test_input(&path, 3, 2));

        let report =
            write_flat_columnar_vortex_prepared_state_streaming(request).expect("stream report");

        assert_eq!(report.row_count, 3);
        assert_eq!(report.reopen_row_count, 3);
        assert_eq!(report.array_build_record_batch_count, 2);
        let stage_fields: BTreeMap<_, _> =
            report.stage_work.evidence_fields().into_iter().collect();
        assert_eq!(stage_fields["vortex_ingest_stream_validation_calls"], "2");
        assert_eq!(
            stage_fields["vortex_ingest_stream_arrow_conversion_calls"],
            "2"
        );
        assert_eq!(
            stage_fields["vortex_ingest_stream_arrow_conversion_rows"],
            "3"
        );
        assert_eq!(
            stage_fields["vortex_ingest_identity_projection_batches"],
            "2"
        );
        assert_eq!(
            report.array_build_provider_surface,
            "ArrayRef::from_arrow(RecordBatch);streaming ArrayIterator"
        );
        assert_eq!(
            report.array_build_strategy,
            "vortex_from_arrow_record_batch_stream"
        );
        assert_eq!(report.array_build_prefetch_window, 0);
        assert_eq!(
            report.array_build_input_layout,
            "streaming_arrow_record_batch_columnar_source_state"
        );
        assert_eq!(
            report.stream_timing_split_status,
            "streaming_source_pull_decode_derive_and_arrow_to_vortex_convert_timing_recorded"
        );
        assert!(
            report.stream_source_pull_micros > 0,
            "streaming source pull timing should be recorded"
        );
        assert!(
            report.stream_array_convert_micros > 0,
            "streaming Arrow-to-Vortex conversion timing should be recorded"
        );
        assert_eq!(
            report.stream_derived_metadata_build_micros, 0,
            "no embedded derived columns were attached in this stream"
        );
        assert_eq!(
            report.writer_coalescing_policy_status,
            "upstream_vortex_default_writer_coalescing_policy"
        );
        assert_eq!(
            report.preparation_spine.source_surface,
            "streaming_local_columnar_source_state_arrow_record_batches"
        );
        assert_eq!(
            report.preparation_spine.split_surface,
            "streaming_arrow_record_batch_source_splits"
        );
        assert_eq!(report.preparation_spine.split_count, 2);
        assert_eq!(
            report.preparation_spine.materialization_boundary_status,
            "streaming_columnar_source_state_preserved_to_vortex_array_provider"
        );
        assert_eq!(
            report.preparation_spine.decode_boundary_status,
            "no_scalar_row_decode_for_streamed_batches"
        );
        assert_eq!(report.column_family_summary(), "id:int64,label:utf8");
        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    fn streaming_vortex_array_prefetch_window_is_bounded_by_parallelism() {
        use crate::ingest_cpu_lanes::IngestCpuLanes;
        for (requested, expected) in [(0, 0), (1, 0), (2, 0), (4, 3), (16, 4)] {
            let lanes = IngestCpuLanes::pipeline(requested, 8);
            assert_eq!(lanes.prefetch_slots(), expected);
            assert!(lanes.prefetch_slots() <= VORTEX_STREAM_ARRAY_PREFETCH_MAX_WINDOW);
            assert_eq!(lanes.configured_cpu_lanes(), requested.max(1));
        }
        assert_eq!(
            IngestCpuLanes::pipeline(2, 0).prefetch_slots(),
            1,
            "a synchronous source leaves one conversion lane"
        );
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    fn local_flat_columnar_stream_source_prefetches_vortex_arrays_when_parallelism_available() {
        use std::collections::VecDeque;
        use std::sync::Arc;

        use arrow_array::{Int64Array, RecordBatch, StringArray};
        use arrow_schema::{DataType, Field, Schema, SchemaRef};

        struct TestRecordBatchReader {
            schema: SchemaRef,
            batches: VecDeque<RecordBatch>,
        }

        impl Iterator for TestRecordBatchReader {
            type Item = std::result::Result<RecordBatch, arrow_schema::ArrowError>;

            fn next(&mut self) -> Option<Self::Item> {
                self.batches.pop_front().map(Ok)
            }
        }

        impl arrow_array::RecordBatchReader for TestRecordBatchReader {
            fn schema(&self) -> SchemaRef {
                Arc::clone(&self.schema)
            }
        }

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-columnar-stream-prefetch-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let columns = vec!["id".to_string(), "label".to_string()];
        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("label", DataType::Utf8, false),
        ]));
        let batch_1 = RecordBatch::try_new(
            Arc::clone(&schema),
            vec![
                Arc::new(Int64Array::from(vec![1, 2])),
                Arc::new(StringArray::from(vec!["alpha", "beta"])),
            ],
        )
        .expect("first record batch");
        let batch_2 = RecordBatch::try_new(
            Arc::clone(&schema),
            vec![
                Arc::new(Int64Array::from(vec![3])),
                Arc::new(StringArray::from(vec!["gamma"])),
            ],
        )
        .expect("second record batch");
        let source = FlatLocalColumnarStreamSource {
            header: columns.clone(),
            column_dtypes: vec![None; columns.len()],
            column_arrow_dtypes: vec![Some(DataType::Int64), Some(DataType::Utf8)],
            materialized_columns: columns.clone(),
            reader_projection_columns: columns,
            row_count_hint: Some(3),
            record_batch_count_hint: Some(2),
            source_stream_batch_size: 0,
            source_stream_unit_count_hint: Some(2),
            source_stream_unit_row_ranges: Some(vec![(0, 2), (2, 3)]),
            source_stream_unit_hint_kind: "test_record_batch_count".to_string(),
            source_stream_policy: "test_source_defined_record_batches".to_string(),
            source_dictionary_preservation_status: "test_not_applicable".to_string(),
            ingest_executor_status: "serial_pull_reader_writer_slot_reserved".to_string(),
            ingest_executor_kind: "single_source_record_batch_reader_with_writer_slot_reserved"
                .to_string(),
            ingest_executor_requested_parallelism: 2,
            ingest_executor_applied_parallelism: 1,
            ingest_executor_unit_count_hint: Some(2),
            source_identities: Vec::new(),
            #[cfg(feature = "vortex-write")]
            ingest_runtime: None,
            embedded_derived_build_micros:
                crate::universal_format_io::new_embedded_derived_build_micros_counter(),
            reader: Box::new(TestRecordBatchReader {
                schema,
                batches: VecDeque::from([batch_1, batch_2]),
            }),
        };
        let request = VortexPreparedStateColumnarStreamWriteRequest::new(&path, source)
            .capillary_prewrite_input(capillary_prewrite_test_input(&path, 3, 2));

        let report =
            write_flat_columnar_vortex_prepared_state_streaming(request).expect("stream report");

        assert_eq!(report.row_count, 3);
        assert_eq!(report.reopen_row_count, 3);
        assert_eq!(report.array_build_record_batch_count, 2);
        assert_eq!(
            report.array_build_provider_surface,
            "ArrayRef::from_arrow(RecordBatch);capillary_vortex_array_prefetch_window;streaming ArrayIterator"
        );
        assert_eq!(
            report.array_build_strategy,
            "capillary_vortex_array_prefetch_window_from_arrow_record_batch_stream"
        );
        assert_eq!(report.array_build_prefetch_window, 1);
        assert_eq!(
            report.writer_physical_design.provider_decision,
            "use_vortex_native_provider"
        );
        assert_eq!(
            report.writer_physical_design.source_stage_plan,
            "bounded_streaming_source_reader_feeds_vortex_array_iterator"
        );
        assert_eq!(
            report.writer_physical_design.array_build_stage_plan,
            "prefetch_streaming_arrow_record_batches_as_vortex_arrays_before_writer_pull"
        );
        assert_eq!(
            report.writer_physical_design.array_build_prefetch_window,
            report.array_build_prefetch_window
        );
        assert_eq!(
            report.writer_physical_design.writer_backpressure_policy,
            "reserved_inflight_window_bounds_queued_active_and_ordered_results"
        );
        assert!(report.writer_physical_design.evidence_fields().contains(&(
            "vortex_writer_physical_design_external_engine_invoked".to_string(),
            "false".to_string()
        )));
        assert_eq!(
            report.array_build_input_layout,
            "streaming_arrow_record_batch_columnar_source_state"
        );
        assert_eq!(report.column_family_summary(), "id:int64,label:utf8");
        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    fn streaming_vortex_write_preserves_compact_embedded_derived_columns() {
        use arrow_array::{
            Array as _, ArrayAccessor as _, DictionaryArray, StringArray, UInt8Array, UInt32Array,
            types::Int32Type,
        };
        use arrow_schema::DataType;

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-embedded-derived-stream-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let header = vec![
            "URL".to_string(),
            "Referer".to_string(),
            "SearchPhrase".to_string(),
            "EventTime".to_string(),
        ];
        let rows = vec![
            vec![
                (
                    "URL".to_string(),
                    ScalarValue::Utf8("https://shardloom.io/docs".to_string()),
                ),
                (
                    "Referer".to_string(),
                    ScalarValue::Utf8("http://www.google.com/search".to_string()),
                ),
                ("SearchPhrase".to_string(), ScalarValue::Utf8(String::new())),
                ("EventTime".to_string(), ScalarValue::UInt64(61)),
            ],
            vec![
                (
                    "URL".to_string(),
                    ScalarValue::Utf8("https://shardloom.io/blog".to_string()),
                ),
                (
                    "Referer".to_string(),
                    ScalarValue::Utf8("https://docs.rs/crate".to_string()),
                ),
                (
                    "SearchPhrase".to_string(),
                    ScalarValue::Utf8("rust".to_string()),
                ),
                ("EventTime".to_string(), ScalarValue::UInt64(120)),
            ],
        ];
        let source = crate::universal_format_io::stream_flat_text_rows_columnar_source(
            header.clone(),
            vec![None, None, None, None],
            vec![None, None, None, None],
            header.clone(),
            header,
            rows,
            64,
            "JSONL",
        )
        .expect("text stream with embedded derived columns");
        let schema = source.reader.schema();
        assert!(
            schema
                .field_with_name("__shardloom_derived_utf8_len_Referer")
                .is_ok()
        );
        assert_eq!(
            schema
                .field_with_name("__shardloom_derived_utf8_len_Referer")
                .expect("referer len")
                .data_type(),
            &DataType::Dictionary(Box::new(DataType::Int32), Box::new(DataType::UInt32))
        );
        assert_eq!(
            schema
                .field_with_name("__shardloom_derived_url_domain_Referer")
                .expect("referer domain")
                .data_type(),
            &DataType::Dictionary(Box::new(DataType::Int32), Box::new(DataType::Utf8))
        );
        assert_eq!(
            schema
                .field_with_name("__shardloom_derived_extract_minute_EventTime")
                .expect("event minute")
                .data_type(),
            &DataType::UInt8
        );
        assert_eq!(
            schema
                .field_with_name("__shardloom_derived_date_trunc_minute_EventTime")
                .expect("event minute bucket")
                .data_type(),
            &DataType::Int64
        );
        let request = VortexPreparedStateColumnarStreamWriteRequest::new(&path, source)
            .capillary_prewrite_input(capillary_prewrite_test_input(&path, 2, 1));

        let report =
            write_flat_columnar_vortex_prepared_state_streaming(request).expect("stream report");

        assert_eq!(report.row_count, 2);
        assert_eq!(report.reopen_row_count, 2);
        assert!(
            report.stream_derived_metadata_build_micros > 0,
            "embedded derived metadata build timing should be recorded"
        );
        assert_eq!(
            report
                .prepared_olap_layout_inventory
                .domain_dictionary_status,
            "embedded_utf8_domain_columns_present_with_length_stats_dictionary_layout_not_observed"
        );
        let arrow = reopen_vortex_artifact_as_arrow_struct(&path, schema.as_ref());
        let struct_array = arrow
            .as_any()
            .downcast_ref::<arrow_array::StructArray>()
            .expect("arrow struct");
        let referer_lengths = struct_array
            .column_by_name("__shardloom_derived_utf8_len_Referer")
            .expect("referer length column")
            .as_any()
            .downcast_ref::<DictionaryArray<Int32Type>>()
            .expect("referer length dictionary");
        let referer_lengths = referer_lengths
            .downcast_dict::<UInt32Array>()
            .expect("referer length dictionary values");
        assert_eq!(
            referer_lengths.value(0),
            u32::try_from("http://www.google.com/search".len()).expect("len")
        );
        assert_eq!(
            referer_lengths.value(1),
            u32::try_from("https://docs.rs/crate".len()).expect("len")
        );
        let referer_domains = struct_array
            .column_by_name("__shardloom_derived_url_domain_Referer")
            .expect("referer domain column")
            .as_any()
            .downcast_ref::<DictionaryArray<Int32Type>>()
            .expect("referer domain dictionary");
        let referer_domains = referer_domains
            .downcast_dict::<StringArray>()
            .expect("referer domain dictionary values");
        assert_eq!(referer_domains.value(0), "google.com");
        assert_eq!(referer_domains.value(1), "docs.rs");
        let event_minutes = struct_array
            .column_by_name("__shardloom_derived_extract_minute_EventTime")
            .expect("event minute column")
            .as_any()
            .downcast_ref::<UInt8Array>()
            .expect("event minute uint8");
        assert_eq!(event_minutes.value(0), 1);
        assert_eq!(event_minutes.value(1), 2);
        let event_minute_buckets = struct_array
            .column_by_name("__shardloom_derived_date_trunc_minute_EventTime")
            .expect("event minute bucket column")
            .as_any()
            .downcast_ref::<arrow_array::Int64Array>()
            .expect("event minute bucket int64");
        assert_eq!(event_minute_buckets.value(0), 60);
        assert_eq!(event_minute_buckets.value(1), 120);
        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    fn streaming_vortex_write_preserves_dictionary_backed_embedded_length_metadata() {
        use std::collections::VecDeque;
        use std::sync::Arc;

        use arrow_array::{
            Array as _, ArrayAccessor as _, ArrayRef, DictionaryArray, RecordBatch, StringArray,
            UInt32Array, builder::StringDictionaryBuilder, types::UInt8Type,
        };
        use arrow_schema::{DataType, Field, Schema, SchemaRef};

        struct TestRecordBatchReader {
            schema: SchemaRef,
            batches: VecDeque<RecordBatch>,
        }

        impl Iterator for TestRecordBatchReader {
            type Item = std::result::Result<RecordBatch, arrow_schema::ArrowError>;

            fn next(&mut self) -> Option<Self::Item> {
                self.batches.pop_front().map(Ok)
            }
        }

        impl arrow_array::RecordBatchReader for TestRecordBatchReader {
            fn schema(&self) -> SchemaRef {
                Arc::clone(&self.schema)
            }
        }

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-dictionary-derived-length-stream-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let mut builder = StringDictionaryBuilder::<UInt8Type>::new();
        builder
            .append("https://example.com/a")
            .expect("append example");
        builder
            .append("https://docs.rs/crate")
            .expect("append docs");
        builder
            .append("https://example.com/a")
            .expect("append example repeat");
        builder.append_null();
        let url_dictionary = Arc::new(builder.finish()) as ArrayRef;
        let schema = Arc::new(Schema::new(vec![Field::new(
            "URL",
            url_dictionary.data_type().clone(),
            true,
        )]));
        let batch = RecordBatch::try_new(Arc::clone(&schema), vec![url_dictionary])
            .expect("dictionary batch");
        let source = FlatLocalColumnarStreamSource {
            header: vec!["URL".to_string()],
            column_dtypes: vec![Some(shardloom_core::LogicalDType::Utf8)],
            column_arrow_dtypes: vec![Some(schema.field(0).data_type().clone())],
            materialized_columns: vec!["URL".to_string()],
            reader_projection_columns: vec!["URL".to_string()],
            row_count_hint: Some(4),
            record_batch_count_hint: Some(1),
            source_stream_batch_size: 4,
            source_stream_unit_count_hint: Some(1),
            source_stream_unit_row_ranges: Some(vec![(0, 4)]),
            source_stream_unit_hint_kind: "test_dictionary_record_batch".to_string(),
            source_stream_policy: "test_dictionary_source_native_units".to_string(),
            source_dictionary_preservation_status: "test_dictionary_preservation_available"
                .to_string(),
            ingest_executor_status: "serial_pull_reader".to_string(),
            ingest_executor_kind: "test_dictionary_record_batch_reader".to_string(),
            ingest_executor_requested_parallelism: 1,
            ingest_executor_applied_parallelism: 1,
            ingest_executor_unit_count_hint: Some(1),
            source_identities: Vec::new(),
            #[cfg(feature = "vortex-write")]
            ingest_runtime: None,
            embedded_derived_build_micros:
                crate::universal_format_io::new_embedded_derived_build_micros_counter(),
            reader: Box::new(TestRecordBatchReader {
                schema,
                batches: VecDeque::from([batch]),
            }),
        };
        let source =
            crate::universal_format_io::with_source_native_embedded_derived_columns_columnar_stream_source(source);
        let schema = source.reader.schema();
        assert_eq!(
            schema
                .field_with_name("__shardloom_derived_utf8_len_URL")
                .expect("length field")
                .data_type(),
            &DataType::Dictionary(Box::new(DataType::UInt8), Box::new(DataType::UInt32))
        );
        assert_eq!(
            schema
                .field_with_name("__shardloom_derived_url_domain_URL")
                .expect("domain field")
                .data_type(),
            &DataType::Dictionary(Box::new(DataType::UInt8), Box::new(DataType::Utf8))
        );
        let request = VortexPreparedStateColumnarStreamWriteRequest::new(&path, source)
            .capillary_prewrite_input(capillary_prewrite_test_input(&path, 2, 1));

        let report =
            write_flat_columnar_vortex_prepared_state_streaming(request).expect("stream report");

        assert_eq!(report.row_count, 4);
        assert_eq!(report.reopen_row_count, 4);
        let arrow = reopen_vortex_artifact_as_arrow_struct(&path, schema.as_ref());
        let struct_array = arrow
            .as_any()
            .downcast_ref::<arrow_array::StructArray>()
            .expect("arrow struct");
        let lengths = struct_array
            .column_by_name("__shardloom_derived_utf8_len_URL")
            .expect("length column")
            .as_any()
            .downcast_ref::<DictionaryArray<UInt8Type>>()
            .expect("u8 length dictionary");
        let lengths = lengths
            .downcast_dict::<UInt32Array>()
            .expect("length values");
        assert_eq!(
            lengths.value(0),
            u32::try_from("https://example.com/a".len()).expect("len")
        );
        assert_eq!(
            lengths.value(1),
            u32::try_from("https://docs.rs/crate".len()).expect("len")
        );
        assert_eq!(lengths.value(2), lengths.value(0));
        assert!(lengths.is_null(3));
        let domains = struct_array
            .column_by_name("__shardloom_derived_url_domain_URL")
            .expect("domain column")
            .as_any()
            .downcast_ref::<DictionaryArray<UInt8Type>>()
            .expect("u8 domain dictionary");
        let domains = domains
            .downcast_dict::<StringArray>()
            .expect("domain values");
        assert_eq!(domains.value(0), "example.com");
        assert_eq!(domains.value(1), "docs.rs");
        assert_eq!(domains.value(2), "example.com");
        assert!(domains.is_null(3));
        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    fn local_empty_flat_columnar_stream_source_uses_empty_writer_provider() {
        use std::collections::VecDeque;
        use std::sync::Arc;

        use arrow_array::RecordBatch;
        use arrow_schema::{DataType, Field, Schema, SchemaRef};

        struct TestRecordBatchReader {
            schema: SchemaRef,
            batches: VecDeque<RecordBatch>,
        }

        impl Iterator for TestRecordBatchReader {
            type Item = std::result::Result<RecordBatch, arrow_schema::ArrowError>;

            fn next(&mut self) -> Option<Self::Item> {
                self.batches.pop_front().map(Ok)
            }
        }

        impl arrow_array::RecordBatchReader for TestRecordBatchReader {
            fn schema(&self) -> SchemaRef {
                Arc::clone(&self.schema)
            }
        }

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-empty-columnar-stream-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let columns = vec!["id".to_string(), "label".to_string()];
        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("label", DataType::Utf8, false),
        ]));
        let reader = TestRecordBatchReader {
            schema,
            batches: VecDeque::new(),
        };
        let source = FlatLocalColumnarStreamSource {
            header: columns.clone(),
            column_dtypes: vec![None; columns.len()],
            column_arrow_dtypes: vec![Some(DataType::Int64), Some(DataType::Utf8)],
            materialized_columns: columns.clone(),
            reader_projection_columns: columns,
            row_count_hint: Some(0),
            record_batch_count_hint: Some(0),
            source_stream_batch_size: 0,
            source_stream_unit_count_hint: Some(0),
            source_stream_unit_row_ranges: Some(Vec::new()),
            source_stream_unit_hint_kind: "test_record_batch_count".to_string(),
            source_stream_policy: "test_source_defined_record_batches".to_string(),
            source_dictionary_preservation_status: "test_not_applicable".to_string(),
            ingest_executor_status: "serial_pull_reader".to_string(),
            ingest_executor_kind: "test_record_batch_reader".to_string(),
            ingest_executor_requested_parallelism: 1,
            ingest_executor_applied_parallelism: 1,
            ingest_executor_unit_count_hint: Some(0),
            source_identities: Vec::new(),
            #[cfg(feature = "vortex-write")]
            ingest_runtime: None,
            embedded_derived_build_micros:
                crate::universal_format_io::new_embedded_derived_build_micros_counter(),
            reader: Box::new(reader),
        };
        let mut advisor_input = layout_advisor_input(true, "none");
        advisor_input.row_count = 0;
        advisor_input.writer_provider_kind = "shardloom_kernel".to_string();
        advisor_input.writer_provider_surface =
            "shardloom_empty_columnar_struct_builder;VortexSession::write_options().write(ArrayStream)"
                .to_string();
        advisor_input.materialization_boundary_status =
            "empty_columnar_source_state_preserved_to_vortex_struct".to_string();
        advisor_input.decode_boundary_status =
            "no_scalar_row_decode_for_empty_columnar_source".to_string();
        let advisor = evaluate_vortex_layout_write_advisor(advisor_input);
        let request = VortexPreparedStateColumnarStreamWriteRequest::new(&path, source)
            .layout_write_advisor(advisor)
            .capillary_prewrite_input(capillary_prewrite_test_input(&path, 0, 0));

        let report =
            write_flat_columnar_vortex_prepared_state_streaming(request).expect("stream report");

        assert_eq!(report.row_count, 0);
        assert_eq!(report.reopen_row_count, 0);
        assert_eq!(report.array_build_record_batch_count, 0);
        assert_eq!(report.array_build_provider_kind, "shardloom_kernel");
        assert_eq!(
            report.array_build_provider_surface,
            "shardloom_empty_columnar_struct_builder"
        );
        assert_eq!(
            report.preparation_spine.source_surface,
            "local_columnar_source_state_arrow_record_batches"
        );
        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    fn local_flat_columnar_binary_source_writes_reopens_exact_bytes() {
        use std::sync::Arc;

        use arrow_array::{BinaryArray, Int64Array, RecordBatch, StructArray};
        use arrow_schema::{DataType, Field, Schema};
        use shardloom_core::LogicalDType;

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-columnar-binary-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let columns = vec!["id".to_string(), "payload".to_string()];
        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("payload", DataType::Binary, false),
        ]));
        let batch = RecordBatch::try_new(
            schema.clone(),
            vec![
                Arc::new(Int64Array::from(vec![1, 2, 3])),
                Arc::new(BinaryArray::from(vec![
                    Some(&[0x00, 0xff, 0x10][..]),
                    Some(&[][..]),
                    Some(&b"raw"[..]),
                ])),
            ],
        )
        .expect("record batch");
        let source = FlatLocalColumnarSource {
            header: columns.clone(),
            column_dtypes: vec![None, Some(LogicalDType::Binary)],
            column_arrow_dtypes: vec![None, Some(arrow_schema::DataType::Binary)],
            materialized_columns: columns.clone(),
            reader_projection_columns: columns,
            batches: vec![batch],
            row_count: 3,
        };
        let request = VortexPreparedStateColumnarWriteRequest::new(&path, source);

        let report = write_flat_columnar_vortex_prepared_state(request).expect("write report");

        assert_eq!(report.row_count, 3);
        assert_eq!(report.reopen_row_count, 3);
        assert_eq!(report.column_family_summary(), "id:int64,payload:binary");
        assert_eq!(report.array_build_provider_kind, "vortex_array_kernel");
        assert_eq!(
            report.array_build_provider_surface,
            "ArrayRef::from_arrow(RecordBatch)"
        );
        assert_eq!(
            report.preparation_spine.materialization_boundary_status,
            "columnar_source_state_preserved_to_vortex_array_provider"
        );
        assert_eq!(
            report.preparation_spine.decode_boundary_status,
            "no_scalar_row_decode_for_non_empty_batches"
        );
        assert!(report.manual_scalar_copy_avoided);

        let arrow = reopen_vortex_artifact_as_arrow_struct(&path, schema.as_ref());
        let struct_array = arrow
            .as_any()
            .downcast_ref::<StructArray>()
            .expect("arrow struct");
        let payload = struct_array
            .column_by_name("payload")
            .expect("payload column")
            .as_any()
            .downcast_ref::<BinaryArray>()
            .expect("binary payload column");
        assert_eq!(payload.value(0), &[0x00, 0xff, 0x10]);
        assert_eq!(payload.value(1), &[] as &[u8]);
        assert_eq!(payload.value(2), b"raw");
        assert_eq!(payload.null_count(), 0);

        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    #[allow(clippy::float_cmp, clippy::too_many_lines)]
    fn local_flat_columnar_nullable_source_writes_reopens_validity() {
        use std::sync::Arc;

        use arrow_array::{
            Array as _, BooleanArray, Float64Array, Int64Array, RecordBatch, StringArray,
            StructArray,
        };
        use arrow_schema::{DataType, Field, Schema};
        use shardloom_core::LogicalDType;

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-columnar-nullable-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let columns = vec![
            "id".to_string(),
            "label".to_string(),
            "metric".to_string(),
            "active".to_string(),
        ];
        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, true),
            Field::new("label", DataType::Utf8, true),
            Field::new("metric", DataType::Float64, true),
            Field::new("active", DataType::Boolean, true),
        ]));
        let batch = RecordBatch::try_new(
            schema.clone(),
            vec![
                Arc::new(Int64Array::from(vec![Some(1), None, Some(3)])),
                Arc::new(StringArray::from(vec![None::<&str>, None, None])),
                Arc::new(Float64Array::from(vec![Some(1.5), None, Some(2.5)])),
                Arc::new(BooleanArray::from(vec![Some(true), None, Some(false)])),
            ],
        )
        .expect("record batch");
        let source = FlatLocalColumnarSource {
            header: columns.clone(),
            column_dtypes: vec![
                Some(LogicalDType::Int64),
                Some(LogicalDType::Utf8),
                Some(LogicalDType::Float64),
                Some(LogicalDType::Boolean),
            ],
            column_arrow_dtypes: vec![
                Some(DataType::Int64),
                Some(DataType::Utf8),
                Some(DataType::Float64),
                Some(DataType::Boolean),
            ],
            materialized_columns: columns.clone(),
            reader_projection_columns: columns,
            batches: vec![batch],
            row_count: 3,
        };
        let request = VortexPreparedStateColumnarWriteRequest::new(&path, source);

        let report = write_flat_columnar_vortex_prepared_state(request).expect("write report");

        assert_eq!(report.row_count, 3);
        assert_eq!(report.reopen_row_count, 3);
        assert_eq!(
            report.column_family_summary(),
            "id:int64,label:utf8,metric:float64,active:boolean"
        );
        assert_eq!(report.array_build_provider_kind, "vortex_array_kernel");
        assert_eq!(
            report.array_build_provider_surface,
            "ArrayRef::from_arrow(RecordBatch)"
        );
        assert_eq!(
            report.preparation_spine.materialization_boundary_status,
            "columnar_source_state_preserved_to_vortex_array_provider"
        );
        assert_eq!(
            report.preparation_spine.decode_boundary_status,
            "no_scalar_row_decode_for_non_empty_batches"
        );
        assert!(report.manual_scalar_copy_avoided);
        assert!(!report.preparation_spine.fallback_attempted);
        assert!(!report.preparation_spine.external_engine_invoked);

        let arrow = reopen_vortex_artifact_as_arrow_struct(&path, schema.as_ref());
        let struct_array = arrow
            .as_any()
            .downcast_ref::<StructArray>()
            .expect("arrow struct");
        let id = struct_array
            .column_by_name("id")
            .expect("id column")
            .as_any()
            .downcast_ref::<Int64Array>()
            .expect("id int64 column");
        assert_eq!(id.value(0), 1);
        assert!(id.is_null(1));
        assert_eq!(id.value(2), 3);
        let label = struct_array
            .column_by_name("label")
            .expect("label column")
            .as_any()
            .downcast_ref::<StringArray>()
            .expect("label string column");
        assert_eq!(label.null_count(), 3);
        let metric = struct_array
            .column_by_name("metric")
            .expect("metric column")
            .as_any()
            .downcast_ref::<Float64Array>()
            .expect("metric float64 column");
        assert_eq!(metric.value(0), 1.5);
        assert!(metric.is_null(1));
        assert_eq!(metric.value(2), 2.5);
        let active = struct_array
            .column_by_name("active")
            .expect("active column")
            .as_any()
            .downcast_ref::<BooleanArray>()
            .expect("active bool column");
        assert!(active.value(0));
        assert!(active.is_null(1));
        assert!(!active.value(2));

        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    #[allow(clippy::too_many_lines)]
    fn local_flat_columnar_decimal_source_writes_reopens_precision_scale() {
        use std::sync::Arc;

        use arrow_array::{
            Array as _, Decimal128Array, Int64Array, RecordBatch, StructArray,
            builder::Decimal128Builder,
        };
        use arrow_schema::{DataType, Field, Schema};
        use shardloom_core::LogicalDType;

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-columnar-decimal-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let columns = vec!["id".to_string(), "amount".to_string()];
        let decimal_dtype = DataType::Decimal128(10, 2);
        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("amount", decimal_dtype.clone(), true),
        ]));
        let mut amount = Decimal128Builder::with_capacity(4);
        amount.append_value(1234);
        amount.append_null();
        amount.append_value(-800);
        amount.append_value(0);
        let amount = amount
            .finish()
            .with_precision_and_scale(10, 2)
            .expect("decimal precision and scale");
        let batch = RecordBatch::try_new(
            schema.clone(),
            vec![
                Arc::new(Int64Array::from(vec![1, 2, 3, 4])),
                Arc::new(amount),
            ],
        )
        .expect("record batch");
        let source = FlatLocalColumnarSource {
            header: columns.clone(),
            column_dtypes: vec![
                Some(LogicalDType::Int64),
                Some(LogicalDType::Extension("decimal128(10,2)".to_string())),
            ],
            column_arrow_dtypes: vec![Some(DataType::Int64), Some(decimal_dtype)],
            materialized_columns: columns.clone(),
            reader_projection_columns: columns,
            batches: vec![batch],
            row_count: 4,
        };
        let request = VortexPreparedStateColumnarWriteRequest::new(&path, source);

        let report = write_flat_columnar_vortex_prepared_state(request).expect("write report");

        assert_eq!(report.row_count, 4);
        assert_eq!(report.reopen_row_count, 4);
        assert_eq!(
            report.column_family_summary(),
            "id:int64,amount:decimal128(10,2)"
        );
        assert_eq!(report.array_build_provider_kind, "vortex_array_kernel");
        assert_eq!(
            report.array_build_provider_surface,
            "ArrayRef::from_arrow(RecordBatch)"
        );
        assert_eq!(
            report.preparation_spine.materialization_boundary_status,
            "columnar_source_state_preserved_to_vortex_array_provider"
        );
        assert_eq!(
            report.preparation_spine.decode_boundary_status,
            "no_scalar_row_decode_for_non_empty_batches"
        );
        assert!(report.manual_scalar_copy_avoided);
        assert!(!report.preparation_spine.fallback_attempted);
        assert!(!report.preparation_spine.external_engine_invoked);

        let arrow = reopen_vortex_artifact_as_arrow_struct(&path, schema.as_ref());
        let struct_array = arrow
            .as_any()
            .downcast_ref::<StructArray>()
            .expect("arrow struct");
        let amount = struct_array
            .column_by_name("amount")
            .expect("amount column")
            .as_any()
            .downcast_ref::<Decimal128Array>()
            .expect("decimal amount column");
        assert_eq!(amount.precision(), 10);
        assert_eq!(amount.scale(), 2);
        assert_eq!(amount.value(0), 1234);
        assert!(amount.is_null(1));
        assert_eq!(amount.value(2), -800);
        assert_eq!(amount.value(3), 0);
        assert_eq!(amount.null_count(), 1);

        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    fn local_empty_buffered_columnar_preserves_canonical_scalar_schema_hints() {
        use arrow_schema::DataType;
        use vortex::array::dtype::{DType, Nullability, PType};

        let cases = [
            (DataType::Boolean, DType::Bool(Nullability::NonNullable)),
            (
                DataType::Int64,
                DType::Primitive(PType::I64, Nullability::NonNullable),
            ),
            (
                DataType::UInt64,
                DType::Primitive(PType::U64, Nullability::NonNullable),
            ),
            (
                DataType::Float64,
                DType::Primitive(PType::F64, Nullability::NonNullable),
            ),
            (DataType::Utf8, DType::Utf8(Nullability::NonNullable)),
            (DataType::Binary, DType::Binary(Nullability::NonNullable)),
        ];
        let columns = (0..cases.len())
            .map(|index| format!("field_{index}"))
            .collect::<Vec<_>>();
        let source = FlatLocalColumnarSource {
            header: columns.clone(),
            column_dtypes: vec![None; columns.len()],
            column_arrow_dtypes: cases.iter().map(|(dtype, _)| Some(dtype.clone())).collect(),
            materialized_columns: columns.clone(),
            reader_projection_columns: columns,
            batches: Vec::new(),
            row_count: 0,
        };
        let shape = validate_flat_columnar_source_shape(&source).unwrap();
        let built = flat_columnar_source_to_vortex_struct(&source, &shape).unwrap();
        let DType::Struct(fields, Nullability::NonNullable) = built.array.dtype() else {
            panic!("empty columnar source must retain its native struct");
        };
        assert_eq!(built.array.len(), 0);
        for (actual, (_, expected)) in fields.fields().zip(cases) {
            assert_eq!(actual, expected);
        }
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    fn local_empty_flat_columnar_decimal_source_writes_reopens_schema() {
        use arrow_array::{Decimal128Array, StructArray};
        use arrow_schema::{DataType, Field, Schema};
        use shardloom_core::LogicalDType;

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-empty-columnar-decimal-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let columns = vec!["id".to_string(), "amount".to_string()];
        let decimal_dtype = DataType::Decimal128(12, 4);
        let schema = Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("amount", decimal_dtype.clone(), true),
        ]);
        let source = FlatLocalColumnarSource {
            header: columns.clone(),
            column_dtypes: vec![
                Some(LogicalDType::Int64),
                Some(LogicalDType::Extension("decimal128(12,4)".to_string())),
            ],
            column_arrow_dtypes: vec![Some(DataType::Int64), Some(decimal_dtype)],
            materialized_columns: columns.clone(),
            reader_projection_columns: columns,
            batches: Vec::new(),
            row_count: 0,
        };
        let request = VortexPreparedStateColumnarWriteRequest::new(&path, source);

        let report = write_flat_columnar_vortex_prepared_state(request).expect("write report");

        assert_eq!(report.row_count, 0);
        assert_eq!(report.reopen_row_count, 0);
        assert_eq!(
            report.column_family_summary(),
            "id:int64,amount:decimal128(12,4)"
        );
        assert_eq!(report.array_build_provider_kind, "shardloom_kernel");
        assert_eq!(
            report.array_build_provider_surface,
            "shardloom_empty_columnar_struct_builder"
        );
        assert_eq!(
            report.array_build_strategy,
            "empty_columnar_schema_to_vortex_struct"
        );
        assert_eq!(report.array_build_record_batch_count, 0);
        assert!(!report.manual_scalar_copy_avoided);
        assert_eq!(
            report.preparation_spine.vortex_first_decision,
            "implement_shardloom_kernel"
        );
        assert_eq!(
            report.preparation_spine.materialization_boundary_status,
            "empty_columnar_schema_materialized_by_shardloom_kernel"
        );
        assert_eq!(
            report.preparation_spine.decode_boundary_status,
            "empty_source_no_data_decode"
        );
        assert!(!report.preparation_spine.fallback_attempted);
        assert!(!report.preparation_spine.external_engine_invoked);

        let arrow = reopen_vortex_artifact_as_arrow_struct(&path, &schema);
        let struct_array = arrow
            .as_any()
            .downcast_ref::<StructArray>()
            .expect("arrow struct");
        assert_eq!(struct_array.len(), 0);
        let amount = struct_array
            .column_by_name("amount")
            .expect("amount column")
            .as_any()
            .downcast_ref::<Decimal128Array>()
            .expect("decimal amount column");
        assert_eq!(amount.precision(), 12);
        assert_eq!(amount.scale(), 4);
        assert_eq!(amount.len(), 0);

        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    #[allow(clippy::too_many_lines)]
    fn local_flat_columnar_dictionary_source_writes_reopens_values() {
        use std::sync::Arc;

        use arrow_array::{
            Array as _, ArrayAccessor as _, BinaryArray, DictionaryArray, Int32Array, Int64Array,
            RecordBatch, StringArray, StructArray, types::Int32Type,
        };
        use arrow_schema::{DataType, Field, Schema};
        use shardloom_core::LogicalDType;

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-columnar-dictionary-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let columns = vec![
            "id".to_string(),
            "category".to_string(),
            "payload".to_string(),
        ];
        let dictionary_utf8_dtype =
            DataType::Dictionary(Box::new(DataType::Int32), Box::new(DataType::Utf8));
        let dictionary_binary_dtype =
            DataType::Dictionary(Box::new(DataType::Int32), Box::new(DataType::Binary));
        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("category", dictionary_utf8_dtype.clone(), true),
            Field::new("payload", dictionary_binary_dtype.clone(), true),
        ]));
        let category = DictionaryArray::<Int32Type>::from_iter([
            Some("alpha"),
            Some("beta"),
            None,
            Some("alpha"),
        ]);
        let payload = DictionaryArray::<Int32Type>::try_new(
            Int32Array::from(vec![Some(0), Some(1), None, Some(0)]),
            Arc::new(BinaryArray::from(vec![
                Some(&b"raw"[..]),
                Some(&[0x00, 0xff][..]),
            ])),
        )
        .expect("binary dictionary");
        let batch = RecordBatch::try_new(
            schema.clone(),
            vec![
                Arc::new(Int64Array::from(vec![1, 2, 3, 4])),
                Arc::new(category),
                Arc::new(payload),
            ],
        )
        .expect("record batch");
        let source = FlatLocalColumnarSource {
            header: columns.clone(),
            column_dtypes: vec![
                Some(LogicalDType::Int64),
                Some(LogicalDType::Utf8),
                Some(LogicalDType::Binary),
            ],
            column_arrow_dtypes: vec![
                Some(DataType::Int64),
                Some(dictionary_utf8_dtype),
                Some(dictionary_binary_dtype),
            ],
            materialized_columns: columns.clone(),
            reader_projection_columns: columns,
            batches: vec![batch],
            row_count: 4,
        };
        let request = VortexPreparedStateColumnarWriteRequest::new(&path, source);

        let report = write_flat_columnar_vortex_prepared_state(request).expect("write report");

        assert_eq!(report.row_count, 4);
        assert_eq!(report.reopen_row_count, 4);
        assert_eq!(
            report.column_family_summary(),
            "id:int64,category:dictionary_utf8,payload:dictionary_binary"
        );
        assert_eq!(report.array_build_provider_kind, "vortex_array_kernel");
        assert_eq!(
            report.array_build_provider_surface,
            "ArrayRef::from_arrow(RecordBatch)"
        );
        assert_eq!(
            report.preparation_spine.materialization_boundary_status,
            "columnar_source_state_preserved_to_vortex_array_provider"
        );
        assert_eq!(
            report.preparation_spine.decode_boundary_status,
            "no_scalar_row_decode_for_non_empty_batches"
        );
        assert!(report.manual_scalar_copy_avoided);
        assert!(!report.preparation_spine.fallback_attempted);
        assert!(!report.preparation_spine.external_engine_invoked);

        let arrow = reopen_vortex_artifact_as_arrow_struct(&path, schema.as_ref());
        let struct_array = arrow
            .as_any()
            .downcast_ref::<StructArray>()
            .expect("arrow struct");
        let category = struct_array
            .column_by_name("category")
            .expect("category column")
            .as_any()
            .downcast_ref::<DictionaryArray<Int32Type>>()
            .expect("dictionary category column");
        let typed = category
            .downcast_dict::<StringArray>()
            .expect("utf8 dictionary values");
        assert_eq!(typed.value(0), "alpha");
        assert_eq!(typed.value(1), "beta");
        assert!(typed.is_null(2));
        assert_eq!(typed.value(3), "alpha");
        assert_eq!(category.null_count(), 1);
        let payload = struct_array
            .column_by_name("payload")
            .expect("payload column")
            .as_any()
            .downcast_ref::<DictionaryArray<Int32Type>>()
            .expect("dictionary payload column");
        let typed_payload = payload
            .downcast_dict::<BinaryArray>()
            .expect("binary dictionary values");
        assert_eq!(typed_payload.value(0), b"raw");
        assert_eq!(typed_payload.value(1), &[0x00, 0xff]);
        assert!(typed_payload.is_null(2));
        assert_eq!(typed_payload.value(3), b"raw");
        assert_eq!(payload.null_count(), 1);

        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    #[allow(clippy::too_many_lines)]
    fn local_flat_scalar_typed_nested_rows_write_via_vortex_arrow_provider() {
        use std::sync::Arc;

        use arrow_array::{Array as _, Int64Array, ListArray, StringArray, StructArray};
        use arrow_schema::{DataType, Field, Schema};
        use shardloom_core::{LogicalDType, ScalarValue};

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-scalar-nested-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let columns = vec![
            "id".to_string(),
            "values".to_string(),
            "payload".to_string(),
        ];
        let rows = vec![
            vec![
                ("id".to_string(), ScalarValue::Int64(1)),
                (
                    "values".to_string(),
                    ScalarValue::List(vec![ScalarValue::Int64(7), ScalarValue::Int64(8)]),
                ),
                (
                    "payload".to_string(),
                    ScalarValue::Struct(vec![
                        ("label".to_string(), ScalarValue::Utf8("alpha".to_string())),
                        ("amount".to_string(), ScalarValue::Int64(42)),
                    ]),
                ),
            ],
            vec![
                ("id".to_string(), ScalarValue::Int64(2)),
                (
                    "values".to_string(),
                    ScalarValue::List(vec![ScalarValue::Int64(9), ScalarValue::Null]),
                ),
                (
                    "payload".to_string(),
                    ScalarValue::Struct(vec![
                        ("label".to_string(), ScalarValue::Utf8("beta".to_string())),
                        ("amount".to_string(), ScalarValue::Null),
                    ]),
                ),
            ],
        ];
        let request = VortexPreparedStateWriteRequest::new(&path, columns.clone(), rows)
            .column_dtypes(vec![
                Some(LogicalDType::Int64),
                Some(LogicalDType::List),
                Some(LogicalDType::Struct),
            ]);

        let report = write_flat_scalar_vortex_prepared_state(request).expect("write report");

        assert_eq!(report.row_count, 2);
        assert_eq!(report.reopen_row_count, 2);
        assert_eq!(
            report.column_family_summary(),
            "id:int64,values:list,payload:struct"
        );
        assert_eq!(report.array_build_provider_kind, "vortex_array_kernel");
        assert_eq!(
            report.array_build_provider_surface,
            "ArrayRef::from_arrow(RecordBatch)"
        );
        assert_eq!(
            report.array_build_strategy,
            "scalar_rows_to_arrow_record_batch_to_vortex"
        );
        assert_eq!(
            report.array_build_input_layout,
            "materialized_rows_to_arrow_record_batch"
        );
        assert_eq!(report.array_build_record_batch_count, 1);
        assert!(!report.manual_scalar_copy_avoided);
        assert_eq!(
            report.preparation_spine.vortex_first_decision,
            "use_vortex_native_provider"
        );
        assert_eq!(
            report.preparation_spine.provider_kind,
            "vortex_array_kernel"
        );
        assert_eq!(
            report.preparation_spine.materialization_boundary_status,
            "materialized_scalar_rows_to_arrow_record_batch_before_vortex_array_provider"
        );

        let schema = Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new(
                "values",
                DataType::List(Arc::new(Field::new_list_field(DataType::Int64, true))),
                false,
            ),
            Field::new(
                "payload",
                DataType::Struct(
                    vec![
                        Field::new("label", DataType::Utf8, true),
                        Field::new("amount", DataType::Int64, true),
                    ]
                    .into(),
                ),
                false,
            ),
        ]);
        let arrow = reopen_vortex_artifact_as_arrow_struct(&path, &schema);
        let struct_array = arrow
            .as_any()
            .downcast_ref::<StructArray>()
            .expect("arrow struct");
        let values = struct_array
            .column_by_name("values")
            .expect("values column")
            .as_any()
            .downcast_ref::<ListArray>()
            .expect("values list column");
        assert_eq!(values.len(), 2);
        assert_eq!(values.value_length(0), 2);
        assert_eq!(values.value_length(1), 2);
        let second_values = values.value(1);
        let second_values = second_values
            .as_any()
            .downcast_ref::<Int64Array>()
            .expect("second list int values");
        assert_eq!(second_values.value(0), 9);
        assert!(second_values.is_null(1));

        let payload = struct_array
            .column_by_name("payload")
            .expect("payload column")
            .as_any()
            .downcast_ref::<StructArray>()
            .expect("payload struct column");
        let labels = payload
            .column_by_name("label")
            .expect("label field")
            .as_any()
            .downcast_ref::<StringArray>()
            .expect("label string field");
        let amounts = payload
            .column_by_name("amount")
            .expect("amount field")
            .as_any()
            .downcast_ref::<Int64Array>()
            .expect("amount int field");
        assert_eq!(labels.value(0), "alpha");
        assert_eq!(labels.value(1), "beta");
        assert_eq!(amounts.value(0), 42);
        assert!(amounts.is_null(1));

        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    #[allow(clippy::too_many_lines)]
    fn local_flat_columnar_dictionary_primitive_source_writes_reopens_values() {
        use std::sync::Arc;

        use arrow_array::{
            Array as _, ArrayAccessor as _, DictionaryArray, Float64Array, Int16Array, Int64Array,
            RecordBatch, StructArray, UInt8Array,
            types::{Int16Type, UInt8Type},
        };
        use arrow_schema::{DataType, Field, Schema};
        use shardloom_core::LogicalDType;

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-columnar-dictionary-primitive-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let columns = vec!["id".to_string(), "bucket".to_string(), "score".to_string()];
        let dictionary_int_dtype =
            DataType::Dictionary(Box::new(DataType::UInt8), Box::new(DataType::Int64));
        let dictionary_float_dtype =
            DataType::Dictionary(Box::new(DataType::Int16), Box::new(DataType::Float64));
        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("bucket", dictionary_int_dtype.clone(), true),
            Field::new("score", dictionary_float_dtype.clone(), true),
        ]));
        let bucket = DictionaryArray::<UInt8Type>::try_new(
            UInt8Array::from(vec![Some(0), Some(1), None, Some(0)]),
            Arc::new(Int64Array::from(vec![10, 20])),
        )
        .expect("int dictionary");
        let score = DictionaryArray::<Int16Type>::try_new(
            Int16Array::from(vec![Some(0), Some(1), Some(0), None]),
            Arc::new(Float64Array::from(vec![1.5, 2.25])),
        )
        .expect("float dictionary");
        let batch = RecordBatch::try_new(
            schema.clone(),
            vec![
                Arc::new(Int64Array::from(vec![1, 2, 3, 4])),
                Arc::new(bucket),
                Arc::new(score),
            ],
        )
        .expect("record batch");
        let source = FlatLocalColumnarSource {
            header: columns.clone(),
            column_dtypes: vec![
                Some(LogicalDType::Int64),
                Some(LogicalDType::Int64),
                Some(LogicalDType::Float64),
            ],
            column_arrow_dtypes: vec![
                Some(DataType::Int64),
                Some(dictionary_int_dtype),
                Some(dictionary_float_dtype),
            ],
            materialized_columns: columns.clone(),
            reader_projection_columns: columns,
            batches: vec![batch],
            row_count: 4,
        };
        let request = VortexPreparedStateColumnarWriteRequest::new(&path, source);

        let report = write_flat_columnar_vortex_prepared_state(request).expect("write report");

        assert_eq!(report.row_count, 4);
        assert_eq!(report.reopen_row_count, 4);
        assert_eq!(
            report.column_family_summary(),
            "id:int64,bucket:dictionary_int64,score:dictionary_float64"
        );
        assert_eq!(report.array_build_provider_kind, "vortex_array_kernel");
        assert_eq!(
            report.array_build_provider_surface,
            "ArrayRef::from_arrow(RecordBatch)"
        );
        assert!(report.manual_scalar_copy_avoided);
        assert!(!report.preparation_spine.fallback_attempted);
        assert!(!report.preparation_spine.external_engine_invoked);

        let arrow = reopen_vortex_artifact_as_arrow_struct(&path, schema.as_ref());
        let struct_array = arrow
            .as_any()
            .downcast_ref::<StructArray>()
            .expect("arrow struct");
        let bucket = struct_array
            .column_by_name("bucket")
            .expect("bucket column")
            .as_any()
            .downcast_ref::<DictionaryArray<UInt8Type>>()
            .expect("dictionary bucket column");
        let bucket_values = bucket
            .downcast_dict::<Int64Array>()
            .expect("int dictionary values");
        assert_eq!(bucket_values.value(0), 10);
        assert_eq!(bucket_values.value(1), 20);
        assert!(bucket_values.is_null(2));
        assert_eq!(bucket_values.value(3), 10);
        let score = struct_array
            .column_by_name("score")
            .expect("score column")
            .as_any()
            .downcast_ref::<DictionaryArray<Int16Type>>()
            .expect("dictionary score column");
        let score_values = score
            .downcast_dict::<Float64Array>()
            .expect("float dictionary values");
        assert_eq!(score_values.value(0).to_bits(), 1.5_f64.to_bits());
        assert_eq!(score_values.value(1).to_bits(), 2.25_f64.to_bits());
        assert_eq!(score_values.value(2).to_bits(), 1.5_f64.to_bits());
        assert!(score_values.is_null(3));
        assert!(path.exists());
        std::fs::remove_file(path).expect("remove artifact");
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    fn local_flat_columnar_dictionary_float_rejects_non_finite_values_before_provider_path() {
        use std::sync::Arc;

        use arrow_array::{
            DictionaryArray, Float64Array, Int64Array, RecordBatch, UInt8Array, types::UInt8Type,
        };
        use arrow_schema::{DataType, Field, Schema};
        use shardloom_core::LogicalDType;

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-columnar-dictionary-non-finite-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let columns = vec!["id".to_string(), "score".to_string()];
        let dictionary_float_dtype =
            DataType::Dictionary(Box::new(DataType::UInt8), Box::new(DataType::Float64));
        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("score", dictionary_float_dtype.clone(), true),
        ]));
        let score = DictionaryArray::<UInt8Type>::try_new(
            UInt8Array::from(vec![Some(0), Some(0)]),
            Arc::new(Float64Array::from(vec![1.5, f64::NAN])),
        )
        .expect("float dictionary");
        let batch = RecordBatch::try_new(
            schema,
            vec![Arc::new(Int64Array::from(vec![1, 2])), Arc::new(score)],
        )
        .expect("record batch");
        let source = FlatLocalColumnarSource {
            header: columns.clone(),
            column_dtypes: vec![Some(LogicalDType::Int64), Some(LogicalDType::Float64)],
            column_arrow_dtypes: vec![Some(DataType::Int64), Some(dictionary_float_dtype)],
            materialized_columns: columns.clone(),
            reader_projection_columns: columns,
            batches: vec![batch],
            row_count: 2,
        };
        let request = VortexPreparedStateColumnarWriteRequest::new(&path, source);

        let error = write_flat_columnar_vortex_prepared_state(request).expect_err("blocked");

        assert!(
            error
                .to_string()
                .contains("non-finite dictionary float value at dictionary index 1")
        );
        let _ = std::fs::remove_file(path);
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    fn local_flat_columnar_dictionary_boolean_blocks_before_provider_path() {
        use std::sync::Arc;

        use arrow_array::{
            BooleanArray, DictionaryArray, Int64Array, RecordBatch, UInt8Array, types::UInt8Type,
        };
        use arrow_schema::{DataType, Field, Schema};
        use shardloom_core::LogicalDType;

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-columnar-dictionary-boolean-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let columns = vec!["id".to_string(), "active".to_string()];
        let dictionary_bool_dtype =
            DataType::Dictionary(Box::new(DataType::UInt8), Box::new(DataType::Boolean));
        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("active", dictionary_bool_dtype.clone(), true),
        ]));
        let active = DictionaryArray::<UInt8Type>::try_new(
            UInt8Array::from(vec![Some(0), None]),
            Arc::new(BooleanArray::from(vec![true])),
        )
        .expect("boolean dictionary");
        let batch = RecordBatch::try_new(
            schema,
            vec![Arc::new(Int64Array::from(vec![1, 2])), Arc::new(active)],
        )
        .expect("record batch");
        let source = FlatLocalColumnarSource {
            header: columns.clone(),
            column_dtypes: vec![Some(LogicalDType::Int64), Some(LogicalDType::Boolean)],
            column_arrow_dtypes: vec![Some(DataType::Int64), Some(dictionary_bool_dtype)],
            materialized_columns: columns.clone(),
            reader_projection_columns: columns,
            batches: vec![batch],
            row_count: 2,
        };
        let request = VortexPreparedStateColumnarWriteRequest::new(&path, source);

        let error = write_flat_columnar_vortex_prepared_state(request)
            .expect_err("boolean dictionary blocked")
            .to_string();

        assert!(error.contains("unsupported Arrow type Dictionary(UInt8, Boolean)"));
        assert!(error.contains("no fallback execution was attempted"));
        let _ = std::fs::remove_file(path);
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    fn local_flat_columnar_record_batch_rejects_non_finite_float_before_provider_path() {
        use std::sync::Arc;

        use arrow_array::{Float64Array, Int64Array, RecordBatch};
        use arrow_schema::{DataType, Field, Schema};

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-columnar-non-finite-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let columns = vec!["id".to_string(), "metric".to_string()];
        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("metric", DataType::Float64, false),
        ]));
        let batch = RecordBatch::try_new(
            schema,
            vec![
                Arc::new(Int64Array::from(vec![1, 2])),
                Arc::new(Float64Array::from(vec![1.5, f64::NAN])),
            ],
        )
        .expect("record batch");
        let source = FlatLocalColumnarSource {
            header: columns.clone(),
            column_dtypes: vec![None; columns.len()],
            column_arrow_dtypes: vec![None; columns.len()],
            materialized_columns: columns.clone(),
            reader_projection_columns: columns,
            batches: vec![batch],
            row_count: 2,
        };
        let request = VortexPreparedStateColumnarWriteRequest::new(&path, source);

        let error = write_flat_columnar_vortex_prepared_state(request)
            .expect_err("non-finite float should be rejected");

        assert!(error.to_string().contains("non-finite float64"));
        assert!(!path.exists());
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    fn local_flat_columnar_stream_rejects_non_finite_float_before_provider_path() {
        use std::collections::VecDeque;
        use std::sync::Arc;

        use arrow_array::{Float64Array, Int64Array, RecordBatch};
        use arrow_schema::{DataType, Field, Schema, SchemaRef};

        struct TestRecordBatchReader {
            schema: SchemaRef,
            batches: VecDeque<RecordBatch>,
        }

        impl Iterator for TestRecordBatchReader {
            type Item = std::result::Result<RecordBatch, arrow_schema::ArrowError>;

            fn next(&mut self) -> Option<Self::Item> {
                self.batches.pop_front().map(Ok)
            }
        }

        impl arrow_array::RecordBatchReader for TestRecordBatchReader {
            fn schema(&self) -> SchemaRef {
                Arc::clone(&self.schema)
            }
        }

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-columnar-stream-non-finite-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let columns = vec!["id".to_string(), "metric".to_string()];
        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("metric", DataType::Float64, false),
        ]));
        let batch = RecordBatch::try_new(
            Arc::clone(&schema),
            vec![
                Arc::new(Int64Array::from(vec![1, 2])),
                Arc::new(Float64Array::from(vec![1.5, f64::NAN])),
            ],
        )
        .expect("record batch");
        let reader = TestRecordBatchReader {
            schema,
            batches: VecDeque::from([batch]),
        };
        let source = FlatLocalColumnarStreamSource {
            header: columns.clone(),
            column_dtypes: vec![None; columns.len()],
            column_arrow_dtypes: vec![None; columns.len()],
            materialized_columns: columns.clone(),
            reader_projection_columns: columns,
            row_count_hint: Some(2),
            record_batch_count_hint: Some(1),
            source_stream_batch_size: 0,
            source_stream_unit_count_hint: Some(1),
            source_stream_unit_row_ranges: Some(vec![(0, 2)]),
            source_stream_unit_hint_kind: "test_record_batch_count".to_string(),
            source_stream_policy: "test_source_defined_record_batches".to_string(),
            source_dictionary_preservation_status: "test_not_applicable".to_string(),
            ingest_executor_status: "serial_pull_reader".to_string(),
            ingest_executor_kind: "test_record_batch_reader".to_string(),
            ingest_executor_requested_parallelism: 1,
            ingest_executor_applied_parallelism: 1,
            ingest_executor_unit_count_hint: Some(1),
            source_identities: Vec::new(),
            #[cfg(feature = "vortex-write")]
            ingest_runtime: None,
            embedded_derived_build_micros:
                crate::universal_format_io::new_embedded_derived_build_micros_counter(),
            reader: Box::new(reader),
        };
        let request = VortexPreparedStateColumnarStreamWriteRequest::new(&path, source);

        let error = write_flat_columnar_vortex_prepared_state_streaming(request)
            .expect_err("non-finite streaming float should be rejected");

        assert!(error.to_string().contains("non-finite float64"));
        assert!(!path.exists());
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    fn local_flat_columnar_source_rejects_short_batches_before_column_access() {
        use std::sync::Arc;

        use arrow_array::{Int64Array, RecordBatch, StringArray};
        use arrow_schema::{DataType, Field, Schema};

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-columnar-short-batch-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("label", DataType::Utf8, false),
        ]));
        let batch = RecordBatch::try_new(
            schema,
            vec![
                Arc::new(Int64Array::from(vec![1, 2])),
                Arc::new(StringArray::from(vec!["alpha", "beta"])),
            ],
        )
        .expect("record batch");
        let columns = vec!["id".to_string(), "label".to_string(), "metric".to_string()];
        let source = FlatLocalColumnarSource {
            header: columns.clone(),
            column_dtypes: vec![None; columns.len()],
            column_arrow_dtypes: vec![None; columns.len()],
            materialized_columns: columns.clone(),
            reader_projection_columns: columns,
            batches: vec![batch],
            row_count: 2,
        };
        let request = VortexPreparedStateColumnarWriteRequest::new(&path, source);

        let error = write_flat_columnar_vortex_prepared_state(request)
            .expect_err("short batch must be rejected before column access");

        assert!(
            error
                .to_string()
                .contains("columnar SourceState batch 1 has 2 projected columns, expected 3")
        );
        assert!(
            error
                .to_string()
                .contains("no fallback execution was attempted")
        );
        assert!(!path.exists());
    }

    #[cfg(feature = "universal-format-io")]
    #[test]
    fn local_flat_columnar_source_rejects_row_count_mismatch() {
        use std::sync::Arc;

        use arrow_array::{Int64Array, RecordBatch, StringArray};
        use arrow_schema::{DataType, Field, Schema};

        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-columnar-row-count-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let columns = vec!["id".to_string(), "label".to_string()];
        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("label", DataType::Utf8, false),
        ]));
        let batch = RecordBatch::try_new(
            schema,
            vec![
                Arc::new(Int64Array::from(vec![1, 2])),
                Arc::new(StringArray::from(vec!["alpha", "beta"])),
            ],
        )
        .expect("record batch");
        let source = FlatLocalColumnarSource {
            header: columns.clone(),
            column_dtypes: vec![None; columns.len()],
            column_arrow_dtypes: vec![None; columns.len()],
            materialized_columns: columns.clone(),
            reader_projection_columns: columns,
            batches: vec![batch],
            row_count: 3,
        };
        let request = VortexPreparedStateColumnarWriteRequest::new(&path, source);

        let error = write_flat_columnar_vortex_prepared_state(request)
            .expect_err("row count mismatch must be rejected");

        assert!(
            error
                .to_string()
                .contains("columnar SourceState row count is 2, expected 3")
        );
        assert!(
            error
                .to_string()
                .contains("no fallback execution was attempted")
        );
        assert!(!path.exists());
    }

    #[test]
    fn local_flat_scalar_full_replay_is_blocked_without_output_replay() {
        let path = std::env::temp_dir().join(format!(
            "shardloom-vortex-ingest-full-replay-{}-{}.vortex",
            std::process::id(),
            1
        ));
        let _ = std::fs::remove_file(&path);
        let request = VortexPreparedStateWriteRequest::new(
            &path,
            vec!["id".to_string(), "label".to_string()],
            vec![vec![
                ("id".to_string(), ScalarValue::Int64(1)),
                ("label".to_string(), ScalarValue::Utf8("alpha".to_string())),
            ]],
        )
        .certification_level(VortexIngestCertificationLevel::IngestFullReplay);

        let error = write_flat_scalar_vortex_prepared_state(request)
            .expect_err("full replay requires downstream output evidence");

        assert!(
            error
                .to_string()
                .contains("ingest_full_replay requires downstream result replay/output evidence")
        );
        assert!(!path.exists());
    }

    #[test]
    fn differential_preparation_admits_append_only_delta_overlay() {
        let input = differential_input(VortexDifferentialUpdateMode::AppendOnly);

        let report = evaluate_vortex_differential_preparation(input);
        let fields = report.evidence_fields();

        assert!(report.is_admitted());
        assert_eq!(report.status, "admitted_append_only_delta_overlay");
        assert_eq!(
            report.schema_compatibility_status,
            "compatible_source_schema_and_column_families"
        );
        assert_eq!(
            report.prepared_state_reuse_status,
            "base_prepared_state_reused_for_delta_overlay"
        );
        assert_eq!(
            report.native_io_certificate_status,
            "certified_local_vortex_differential_preparation_overlay"
        );
        assert!(report.overlay_manifest_digest.starts_with("fnv64:"));
        assert!(report.correctness_digest.starts_with("fnv64:"));
        assert!(fields.contains(&(
            "vortex_differential_preparation_overlay_applied".to_string(),
            "true".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_differential_preparation_fallback_attempted".to_string(),
            "false".to_string()
        )));
    }

    #[test]
    fn capillary_preparation_applies_pulseweave_when_certified() {
        let input = capillary_input("certified");

        let report = evaluate_vortex_capillary_preparation(input).expect("capillary report");
        let fields = report.evidence_fields();

        assert_eq!(report.status, "applied_capillary_pulseweave_control");
        assert_eq!(report.task_count, 6);
        assert!(report.task_manifest_digest.starts_with("fnv64:"));
        assert_eq!(report.native_io_certificate_status, "certified");
        assert_eq!(report.pulseweave_report.status, "applied");
        assert!(report.pulseweave_report.runtime_decision_applied);
        assert!(report.scheduler_applied);
        assert_eq!(
            report.scheduler_application_reason,
            "pulseweave_batch_window_applied_to_capillary_manifest"
        );
        assert!(report.execution_window_size >= 1);
        assert_eq!(
            report.execution_window_count,
            report.task_count.div_ceil(report.execution_window_size)
        );
        assert_ne!(report.execution_window_ids, "none");
        assert_ne!(report.execution_window_task_ids, "none");
        assert_ne!(report.execution_window_digests, "none");
        assert_eq!(
            report.pulseweave_report.application_scope,
            "vortex_cold_preparation_local_capillary_io"
        );
        assert!(fields.contains(&(
            "vortex_capillary_preparation_task_roles".to_string(),
            "source_split_discovery,read_chunk,columnarize_encode,vortex_segment_write,reopen_verify,sink_evidence".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_capillary_preparation_pulseweave_runtime_decision_applied".to_string(),
            "true".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_capillary_preparation_scheduler_applied".to_string(),
            "true".to_string()
        )));
        assert!(fields.iter().any(|(key, value)| {
            key == "vortex_capillary_preparation_execution_window_count" && value != "0"
        }));
        assert!(fields.contains(&(
            "vortex_capillary_preparation_fallback_attempted".to_string(),
            "false".to_string()
        )));
    }

    #[test]
    fn capillary_preparation_skips_small_input_below_threshold() {
        let mut input = capillary_input("certified");
        input.capillary_claim_evidence_requested = false;

        let report = evaluate_vortex_capillary_preparation(input).expect("capillary report");
        let fields = report.evidence_fields();

        assert_eq!(report.status, "not_requested_below_threshold");
        assert_eq!(report.activation_result, "skipped");
        assert_eq!(
            report.activation_reason,
            "below_threshold_small_local_fixture"
        );
        assert_eq!(report.task_count, 0);
        assert_eq!(report.task_manifest_id, "none");
        assert_eq!(report.execution_window_count, 0);
        assert_eq!(report.execution_window_size, 0);
        assert_eq!(report.execution_window_ids, "none");
        assert!(!report.scheduler_applied);
        assert_eq!(
            report.scheduler_application_reason,
            "not_requested_below_threshold"
        );
        assert_eq!(report.pulseweave_report.status, "not_requested");
        assert!(!report.pulseweave_report.runtime_decision_applied);
        assert_eq!(report.execution_certificate_status, "not_requested");
        assert_eq!(report.claim_gate_status, "not_claim_grade");
        assert!(!report.fallback_attempted);
        assert!(!report.external_engine_invoked);
        assert!(fields.contains(&(
            "vortex_capillary_preparation_activation_policy".to_string(),
            "dynamic_size_complexity_gate.v1".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_capillary_preparation_activation_result".to_string(),
            "skipped".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_capillary_preparation_task_count".to_string(),
            "0".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_capillary_preparation_pulseweave_status".to_string(),
            "not_requested".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_capillary_preparation_scheduler_applied".to_string(),
            "false".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_capillary_preparation_execution_window_count".to_string(),
            "0".to_string()
        )));
    }

    #[test]
    fn capillary_preparation_activates_large_input_by_threshold() {
        let mut input = capillary_input("certified");
        input.capillary_claim_evidence_requested = false;
        input.source_byte_count = VORTEX_CAPILLARY_ACTIVATION_THRESHOLD_BYTES;

        let report = evaluate_vortex_capillary_preparation(input).expect("capillary report");

        assert_eq!(report.status, "applied_capillary_pulseweave_control");
        assert_eq!(report.activation_result, "activated");
        assert_eq!(report.activation_reason, "source_bytes_above_threshold");
        assert_eq!(report.task_count, 6);
        assert!(report.scheduler_applied);
        assert!(report.execution_window_count > 0);
        assert_eq!(report.pulseweave_report.status, "applied");
    }

    #[test]
    fn capillary_preparation_blocks_none_source_split_refs_as_missing_manifest() {
        let mut input = capillary_input("certified");
        input.source_split_refs = "none".to_string();

        let report = evaluate_vortex_capillary_preparation(input).expect("capillary report");

        assert_eq!(report.status, "blocked_missing_capillary_task_manifest");
        assert_eq!(
            report.execution_certificate_status,
            "missing_capillary_task_manifest"
        );
        assert_eq!(report.pulseweave_report.status, "blocked");
        assert!(!report.pulseweave_report.runtime_decision_applied);
        assert!(!report.scheduler_applied);
        assert_eq!(
            report.scheduler_application_reason,
            "blocked_missing_capillary_task_manifest"
        );
        assert_eq!(report.execution_window_count, 0);
        assert!(
            report
                .pulseweave_report
                .blocker
                .contains("execution_certificate")
        );
        assert!(!report.fallback_attempted);
        assert!(!report.external_engine_invoked);
    }

    #[test]
    fn scout_ingress_admits_clean_local_source() {
        let input = scout_input(0, "none", "not_detected", false);

        let report = evaluate_vortex_scout_ingress(input);
        let fields = report.evidence_fields();

        assert_eq!(report.status, "admitted_scout_ingress_clean");
        assert_eq!(
            report.no_standalone_lane_status,
            "funnelled_through_vortex_ingest_source_state_to_vortex_prepared_state"
        );
        assert!(!report.quarantine_required);
        assert_eq!(report.claim_gate_status, "not_claim_grade");
        assert!(fields.contains(&(
            "vortex_scout_ingress_anomaly_count".to_string(),
            "0".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_scout_ingress_fallback_attempted".to_string(),
            "false".to_string()
        )));
    }

    #[test]
    fn scout_ingress_blocks_nested_shapes_with_quarantine_plan() {
        let input = scout_input(
            1,
            "unsupported_nested_shape",
            "blocked_unsupported_nested_shape",
            true,
        );

        let report = evaluate_vortex_scout_ingress(input);

        assert_eq!(report.status, "blocked_unsupported_nested_shape");
        assert_eq!(report.anomaly_families, "unsupported_nested_shape");
        assert_eq!(
            report.unsupported_shape_status,
            "blocked_unsupported_nested_shape"
        );
        assert!(report.quarantine_required);
        assert_eq!(
            report.quarantine_output_plan_status,
            "planned_not_emitted_no_quarantine_sink_requested"
        );
        assert!(!report.fallback_attempted);
        assert!(!report.external_engine_invoked);
    }

    #[test]
    fn layout_write_advisor_admits_scoped_local_strategy() {
        let report = evaluate_vortex_layout_write_advisor(layout_advisor_input(true, "none"));
        let fields = report.evidence_fields();

        assert_eq!(report.status, "admitted_local_layout_write_strategy");
        assert!(report.strategy_admitted);
        assert!(!report.runtime_decision_applied);
        assert_eq!(
            report.selected_strategy,
            "single_vortex_artifact_embedded_olap_layout_statistics"
        );
        assert!(report.strategy_decision_digest.starts_with("fnv64:"));
        assert!(report.provider_admitted);
        assert_eq!(report.blocker, "pending_runtime_write_decision");
        assert_eq!(
            report.no_standalone_lane_status,
            "funnelled_through_vortex_ingest_source_state_to_vortex_prepared_state"
        );
        assert_eq!(report.claim_gate_status, "not_claim_grade");
        assert!(!report.fallback_attempted);
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_role".to_string(),
            "universal_ingest_optimizer".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_public_runtime_posture".to_string(),
            "admitted_local_product_workflow_not_smoke".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_single_artifact_required".to_string(),
            "true".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_query_answer_sidecar_allowed".to_string(),
            "false".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_surface_unification_policy".to_string(),
            "sql_python_dataframe_cli_share_vortex_normalized_physical_runtime".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_source_scale".to_string(),
            "unknown".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_profile_family".to_string(),
            "unknown".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_prepared_layout_family".to_string(),
            "unknown".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_key_profile".to_string(),
            "unknown".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_dictionary_profile".to_string(),
            "unknown".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_writer_parallelism_budget".to_string(),
            "1".to_string()
        )));
    }

    #[test]
    fn layout_write_advisor_exposes_source_profile_fields_for_large_text_olap() {
        let mut input = layout_advisor_input(true, "none");
        input.row_count = VORTEX_PREPARED_OLAP_WRITER_LARGE_SOURCE_ROW_THRESHOLD;
        input.source_byte_count = 1_073_741_824;
        input.workload_constitution =
            "product_vortex_prepare_once;format=parquet;scale=large_olap;adapter=streaming_columnar_source_state;profile=url_time_counter_olap;layout_family=url_time_counter_dictionary_stats_layout;text_domain=true;time_bucket=true;counter=true;key_profile=high_cardinality_numeric_text_time_keys;dictionary=source_dictionary_or_derived_dictionary_evidence"
                .to_string();
        input.expected_read_tradeoff =
            "prefer_metadata_pruning_dictionary_domain_length_and_time_bucket_execution"
                .to_string();
        input.expected_write_tradeoff =
            "prefer_column_family_fast_zstd_for_payload_text_and_embedded_layout_statistics"
                .to_string();

        let report = evaluate_vortex_layout_write_advisor(input);
        let fields = report.evidence_fields();

        assert_eq!(report.status, "admitted_local_layout_write_strategy");
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_writer_parallelism_budget".to_string(),
            "1".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_metadata_payload_policy".to_string(),
            "embedded_generic_layout_statistics_no_query_answer_sidecars".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_compact_derived_metadata_policy".to_string(),
            "dictionary_derived_metadata_preferred_over_full_hidden_columns".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_membership_sketch_policy".to_string(),
            "generic_segment_membership_only_not_query_result_cache".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_row_position_locality_policy".to_string(),
            "embedded_order_key_row_position_locality_when_available".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_source_scale".to_string(),
            "large_olap".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_profile_family".to_string(),
            "url_time_counter_olap".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_prepared_layout_family".to_string(),
            "url_time_counter_dictionary_stats_layout".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_text_domain_columns".to_string(),
            "true".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_time_bucket_columns".to_string(),
            "true".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_counter_columns".to_string(),
            "true".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_key_profile".to_string(),
            "high_cardinality_numeric_text_time_keys".to_string()
        )));
        assert!(fields.contains(&(
            "vortex_layout_write_advisor_dictionary_profile".to_string(),
            "source_dictionary_or_derived_dictionary_evidence".to_string()
        )));
        assert!(
            fields.contains(&(
                "vortex_layout_write_advisor_expected_read_tradeoff".to_string(),
                "prefer_metadata_pruning_dictionary_domain_length_and_time_bucket_execution"
                    .to_string()
            ))
        );
        assert!(
            fields.contains(&(
                "vortex_layout_write_advisor_expected_write_tradeoff".to_string(),
                "prefer_column_family_fast_zstd_for_payload_text_and_embedded_layout_statistics"
                    .to_string()
            ))
        );
    }

    #[test]
    fn layout_write_advisor_blocks_unsupported_strategy() {
        let report = evaluate_vortex_layout_write_advisor(layout_advisor_input(
            false,
            "vortex_layout_write_advisor.unsupported_layout_strategy",
        ));

        assert_eq!(report.status, "blocked_layout_write_strategy");
        assert!(!report.strategy_admitted);
        assert!(!report.runtime_decision_applied);
        assert_eq!(report.selected_strategy, "not_admitted");
        assert!(!report.provider_admitted);
        assert_eq!(
            report.blocker,
            "vortex_layout_write_advisor.unsupported_layout_strategy"
        );
        assert_eq!(
            report.unsupported_diagnostic_code,
            "vortex_layout_write_advisor.unsupported_layout_strategy"
        );
        assert!(!report.external_engine_invoked);
    }

    #[test]
    fn copy_budget_reports_unmeasured_segments_and_blocks_unsafe_reuse() {
        let report = evaluate_vortex_copy_budget(copy_budget_input(
            "reported_with_not_measured_segments",
            "blocked_no_unsafe_lifetime_shortcuts",
            "blocked_until_correctness_parity",
        ));

        assert_eq!(
            report.status,
            "reported_copy_budget_with_unmeasured_segments"
        );
        assert_eq!(report.buffer_reuse_count, 0);
        assert_eq!(report.claim_gate_status, "not_claim_grade");
        assert!(!report.fallback_attempted);

        let blocked = evaluate_vortex_copy_budget(copy_budget_input(
            "reported_with_not_measured_segments",
            "unsafe_lifetime_shortcut_requested",
            "blocked_unsafe_lifetime_shortcut",
        ));
        assert_eq!(blocked.status, "blocked_unsafe_lifetime_shortcut");

        let admitted = evaluate_vortex_copy_budget(copy_budget_input(
            "reported_with_not_measured_segments",
            "blocked_no_unsafe_lifetime_shortcuts",
            "admitted_read_once_source_buffer_carry_with_digest_and_row_count_proof",
        ));
        assert_eq!(
            admitted.status,
            "admitted_scoped_buffer_reuse_with_unmeasured_segments"
        );
    }

    #[test]
    fn capillary_preparation_blocks_pulseweave_without_native_io_certificate() {
        let input = capillary_input("missing");

        let report = evaluate_vortex_capillary_preparation(input).expect("capillary report");

        assert_eq!(
            report.status,
            "report_only_blocked_missing_native_io_certificate"
        );
        assert_eq!(report.execution_certificate_status, "certified");
        assert_eq!(report.pulseweave_report.status, "blocked");
        assert!(!report.pulseweave_report.runtime_decision_applied);
        assert!(!report.scheduler_applied);
        assert_eq!(
            report.scheduler_application_reason,
            "blocked_missing_native_io_certificate"
        );
        assert_eq!(report.execution_window_count, 0);
        assert!(
            report
                .pulseweave_report
                .blocker
                .contains("native_io_certificate")
        );
        assert!(!report.fallback_attempted);
        assert!(!report.external_engine_invoked);
    }

    #[test]
    fn differential_preparation_blocks_update_mode_without_overlay() {
        let input = differential_input(VortexDifferentialUpdateMode::Update);

        let report = evaluate_vortex_differential_preparation(input);

        assert!(!report.is_admitted());
        assert_eq!(report.status, "blocked_update_mode_policy");
        assert_eq!(
            report.update_mode_policy,
            "update_delete_upsert_blocked_until_row_identity_and_rewrite_semantics_are_certified"
        );
        assert_eq!(
            report.replay_verification_status,
            "blocked_before_overlay_replay"
        );
        assert!(!report.base_reprepare_performed);
        assert!(!report.fallback_attempted);
        assert!(!report.external_engine_invoked);
    }

    #[test]
    fn differential_preparation_blocks_schema_mismatch_without_overlay() {
        let mut input = differential_input(VortexDifferentialUpdateMode::AppendOnly);
        input.delta_schema_digest = "fnv64:other".to_string();

        let report = evaluate_vortex_differential_preparation(input);

        assert!(!report.is_admitted());
        assert_eq!(report.status, "blocked_schema_mismatch");
        assert_eq!(
            report.schema_compatibility_status,
            "blocked_source_schema_or_column_family_mismatch"
        );
        assert_eq!(
            report.prepared_state_reuse_status,
            "blocked_before_prepared_state_reuse"
        );
        assert!(report.delta_artifact_written);
        assert!(!report.overlay_applied);
    }

    #[test]
    fn append_only_refinement_admits_verified_source_prefix_delta() {
        let root = temp_test_root("append-only-refinement-admit");
        let source = root.join("input.csv");
        let target = root.join("prepared.vortex");
        std::fs::write(&source, "id,label\n1,alpha\n2,beta\n").expect("write base source");
        std::fs::write(&target, b"prepared-vortex-artifact").expect("write prepared artifact");
        let manifest_path =
            vortex_prepared_state_reuse_manifest_path(&target).expect("manifest path");
        let base_request = reuse_request_for_test(&source, &target, &manifest_path);
        let base_decision =
            evaluate_vortex_prepared_state_reuse(&base_request).expect("base reuse decision");
        let artifact_digest =
            sha256_file_digest(&target, "test artifact").expect("artifact digest");
        write_vortex_prepared_state_reuse_manifest(
            &base_request,
            &base_decision,
            VortexPreparedStateReuseWriteEvidence {
                source_state_id: "source-state-base".to_string(),
                source_state_digest: "fnv64:source-base".to_string(),
                source_schema_digest: "fnv64:schema".to_string(),
                source_row_count: 2,
                source_column_family_summary: "id:int64,label:utf8".to_string(),
                prepared_state_id: "prepared-base".to_string(),
                prepared_state_digest: "fnv64:prepared-base".to_string(),
                prepared_artifact_digest: artifact_digest,
                certificate_refs: "reopen_row_count_scan".to_string(),
                fallback_attempted: false,
                external_engine_invoked: false,
            },
        )
        .expect("write reuse manifest");

        std::fs::write(&source, "id,label\n1,alpha\n2,beta\n3,gamma\n").expect("append source");
        let current_request = reuse_request_for_test(&source, &target, &manifest_path);
        let decision = evaluate_vortex_prepared_state_append_only_refinement(&current_request)
            .expect("refinement decision");

        assert!(decision.is_admitted());
        assert_eq!(decision.status, "admitted_append_only_refinement");
        assert_eq!(
            decision.automatic_detection_status,
            "append_only_delta_detected"
        );
        assert_eq!(
            decision.source_prefix_verification_status,
            "verified_old_source_bytes_are_current_prefix"
        );
        assert_eq!(decision.base_source_row_count, 2);
        assert_eq!(
            decision.base_source_column_family_summary,
            "id:int64,label:utf8"
        );
        assert!(decision.changed_byte_range_refs.contains("#bytes="));
        assert!(!decision.fallback_attempted);
        assert!(!decision.external_engine_invoked);

        std::fs::remove_dir_all(root).expect("remove temp root");
    }

    #[test]
    fn prepared_state_reuse_missing_artifact_is_cache_miss_not_error() {
        let root = temp_test_root("reuse-manifest-missing-artifact");
        let source = root.join("input.csv");
        let target = root.join("prepared.vortex");
        std::fs::write(&source, "id,label\n1,alpha\n").expect("write source");
        std::fs::write(&target, b"prepared-vortex-artifact").expect("write prepared artifact");
        let manifest_path =
            vortex_prepared_state_reuse_manifest_path(&target).expect("manifest path");
        let request = reuse_request_for_test(&source, &target, &manifest_path);
        let first_decision =
            evaluate_vortex_prepared_state_reuse(&request).expect("first reuse decision");
        let artifact_digest =
            sha256_file_digest(&target, "test artifact").expect("artifact digest");
        write_vortex_prepared_state_reuse_manifest(
            &request,
            &first_decision,
            VortexPreparedStateReuseWriteEvidence {
                source_state_id: "source-state-base".to_string(),
                source_state_digest: "fnv64:source-base".to_string(),
                source_schema_digest: "fnv64:schema".to_string(),
                source_row_count: 1,
                source_column_family_summary: "id:int64,label:utf8".to_string(),
                prepared_state_id: "prepared-base".to_string(),
                prepared_state_digest: "fnv64:prepared-base".to_string(),
                prepared_artifact_digest: artifact_digest,
                certificate_refs: "reopen_row_count_scan".to_string(),
                fallback_attempted: false,
                external_engine_invoked: false,
            },
        )
        .expect("write reuse manifest");

        std::fs::remove_file(&target).expect("remove stale artifact");
        let decision =
            evaluate_vortex_prepared_state_reuse(&request).expect("missing artifact is a miss");
        assert!(!decision.hit);
        assert_eq!(decision.status, "prepared_state_reuse_miss");
        assert_eq!(decision.reason, "prepared_artifact_missing");
        assert_eq!(decision.invalidation_reason, "prepared_artifact_missing");
        assert!(!decision.fallback_attempted);
        assert!(!decision.external_engine_invoked);

        std::fs::remove_dir_all(root).expect("remove temp root");
    }

    #[test]
    #[allow(clippy::too_many_lines)]
    fn prepared_olap_state_report_admits_single_vortex_artifact_without_sidecars() {
        let root = temp_test_root("prepared-olap-single-artifact");
        let source = root.join("source.parquet");
        let target = root.join("prepared.vortex");
        std::fs::write(&source, b"source bytes").expect("write source");
        write_test_prepared_vortex_artifact(&target, 10);
        let source_digest = sha256_file_digest(&source, "test source").expect("source digest");
        let legacy_manifest_path = legacy_prepared_olap_state_manifest_path(&target);

        let request = VortexPreparedOlapStateWriteRequest::new_local(
            "source-state-hits",
            "sha256:source-state-digest",
            "parquet",
            source_digest,
            12,
            "sha256:schema-digest",
            2,
            &target,
            &target,
        )
        .expect("olap request")
        .with_prepared_layout_policy(VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_LAYOUT_POLICY)
        .with_segment_map_status(VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_SEGMENT_MAP_STATUS)
        .with_certification_level("single_vortex_artifact_olap_contract")
        .with_certificate_refs("local-prepared-olap-state-test");

        let report = publish_vortex_prepared_olap_single_artifact_state(&request)
            .expect("publish olap state");

        assert_eq!(report.status, "prepared_olap_state_ready");
        assert!(!legacy_manifest_path.exists());
        assert!(!report.manifest_written);
        assert!(report.manifest_digest.starts_with("sha256:"));
        assert!(report.state_digest.starts_with("sha256:"));
        assert_eq!(report.exact_sidecar_family_count, 0);
        assert!(!report.sub_second_candidate);
        assert_eq!(
            report.artifact_model,
            VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_MODEL
        );
        assert_eq!(
            report.writer_layout_strategy,
            VORTEX_PREPARED_OLAP_WRITER_LAYOUT_STRATEGY
        );
        assert_eq!(
            report.metadata_pruning_contract,
            VORTEX_PREPARED_OLAP_METADATA_PRUNING_CONTRACT
        );
        assert_eq!(
            report.query_answer_sidecar_status,
            VORTEX_PREPARED_OLAP_QUERY_ANSWER_SIDECAR_STATUS
        );
        assert_eq!(
            report.query_time_contract,
            VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_QUERY_TIME_CONTRACT
        );
        assert_eq!(
            report.layout_inventory_status,
            "opened_single_vortex_artifact_footer"
        );
        assert!(report.layout_inventory_digest.starts_with("fnv64:"));
        assert_eq!(report.layout_footer_row_count, "2");
        assert!(report.layout_footer_segment_count != "unknown");
        assert!(report.layout_artifact_size_bytes != "unknown");
        assert!(report.layout_footer_approx_bytes != "unknown");
        assert!(report.layout_size_attribution.contains("artifact_bytes="));
        assert!(report.layout_size_attribution.contains("source_columns="));
        assert!(report.layout_size_attribution.contains("derived_columns="));
        assert!(report.layout_size_attribution.contains("footer_bytes="));
        assert!(
            report
                .layout_size_attribution
                .contains("column_byte_attribution=not_available_from_current_vortex_footer")
        );
        assert!(report.layout_metadata_persisted_in_artifact);
        assert_eq!(report.blocker_id, "none");
        assert!(!report.fallback_attempted);
        assert!(!report.external_engine_invoked);
        assert!(
            report
                .admitted_query_families
                .contains("native_vortex_runtime")
        );

        let fields = report
            .evidence_fields()
            .into_iter()
            .collect::<BTreeMap<_, _>>();
        assert_eq!(
            fields
                .get("vortex_prepared_olap_state_schema_version")
                .map(String::as_str),
            Some(VORTEX_PREPARED_OLAP_STATE_SCHEMA_VERSION)
        );
        assert_eq!(
            fields
                .get("vortex_prepared_olap_state_query_time_contract")
                .map(String::as_str),
            Some(VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_QUERY_TIME_CONTRACT)
        );
        assert_eq!(
            fields
                .get("vortex_prepared_olap_state_artifact_model")
                .map(String::as_str),
            Some(VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_MODEL)
        );
        assert_eq!(
            fields
                .get("vortex_prepared_olap_state_metadata_pruning_contract")
                .map(String::as_str),
            Some(VORTEX_PREPARED_OLAP_METADATA_PRUNING_CONTRACT)
        );
        assert_eq!(
            fields
                .get("vortex_prepared_olap_state_query_answer_sidecar_status")
                .map(String::as_str),
            Some(VORTEX_PREPARED_OLAP_QUERY_ANSWER_SIDECAR_STATUS)
        );
        assert_eq!(
            fields
                .get("vortex_prepared_olap_state_evidence_persistence")
                .map(String::as_str),
            Some("embedded_in_single_prepared_vortex_artifact")
        );
        assert_eq!(
            fields
                .get("vortex_prepared_olap_state_external_manifest_written")
                .map(String::as_str),
            Some("false")
        );
        assert_eq!(
            fields
                .get("vortex_prepared_olap_state_layout_inventory_status")
                .map(String::as_str),
            Some("opened_single_vortex_artifact_footer")
        );
        assert_eq!(
            fields
                .get("vortex_prepared_olap_state_layout_footer_row_count")
                .map(String::as_str),
            Some("2")
        );
        assert_eq!(
            fields
                .get("vortex_prepared_olap_state_layout_metadata_persisted_in_artifact")
                .map(String::as_str),
            Some("true")
        );

        let hit = evaluate_vortex_prepared_olap_single_artifact_state(&request)
            .expect("evaluate olap state");
        assert_eq!(hit.status, "prepared_olap_state_read_through_hit");
        assert!(!hit.manifest_written);
        assert_eq!(hit.manifest_digest, report.manifest_digest);
        assert_eq!(hit.state_digest, report.state_digest);
        assert_eq!(hit.exact_sidecar_family_count, 0);
        assert_eq!(
            hit.metadata_pruning_contract,
            VORTEX_PREPARED_OLAP_METADATA_PRUNING_CONTRACT
        );
        assert_eq!(
            hit.query_answer_sidecar_status,
            VORTEX_PREPARED_OLAP_QUERY_ANSWER_SIDECAR_STATUS
        );
        assert_eq!(
            hit.query_time_contract,
            VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_QUERY_TIME_CONTRACT
        );
        assert_eq!(
            hit.layout_inventory_status,
            "opened_single_vortex_artifact_footer"
        );
        assert_eq!(hit.layout_footer_row_count, "2");
        assert!(hit.layout_metadata_persisted_in_artifact);
        assert_eq!(hit.blocker_id, "none");
        assert!(!hit.fallback_attempted);
        assert!(!hit.external_engine_invoked);

        std::fs::remove_dir_all(root).expect("remove temp root");
    }

    #[test]
    fn prepared_olap_state_artifact_report_updates_digest_without_external_manifest() {
        let root = temp_test_root("prepared-olap-artifact-drift");
        let source = root.join("source.parquet");
        let target = root.join("prepared.vortex");
        std::fs::write(&source, b"source bytes").expect("write source");
        write_test_prepared_vortex_artifact(&target, 20);
        let source_digest = sha256_file_digest(&source, "test source").expect("source digest");
        let legacy_manifest_path = legacy_prepared_olap_state_manifest_path(&target);
        let request = VortexPreparedOlapStateWriteRequest::new_local(
            "source-state-hits",
            "sha256:source-state-digest",
            "parquet",
            source_digest,
            12,
            "sha256:schema-digest",
            2,
            &target,
            &target,
        )
        .expect("olap request")
        .with_prepared_layout_policy(VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_LAYOUT_POLICY)
        .with_segment_map_status(VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_SEGMENT_MAP_STATUS);
        let initial = publish_vortex_prepared_olap_single_artifact_state(&request)
            .expect("publish olap state");
        std::thread::sleep(std::time::Duration::from_millis(5));
        write_test_prepared_vortex_artifact(&target, 30);

        let decision = evaluate_vortex_prepared_olap_single_artifact_state(&request)
            .expect("evaluate mutated olap artifact");

        assert_eq!(decision.status, "prepared_olap_state_read_through_hit");
        assert_eq!(decision.blocker_id, "none");
        assert_eq!(
            decision.query_time_contract,
            VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_QUERY_TIME_CONTRACT
        );
        assert!(!decision.manifest_written);
        assert!(!legacy_manifest_path.exists());
        assert!(!decision.fallback_attempted);
        assert!(!decision.external_engine_invoked);
        assert_ne!(
            decision.prepared_artifact_digest,
            initial.prepared_artifact_digest
        );
        assert_ne!(decision.state_digest, initial.state_digest);

        std::fs::remove_dir_all(root).expect("remove temp root");
    }

    #[test]
    fn prepared_olap_artifact_fingerprint_tracks_same_size_artifact_mutation() {
        let root = temp_test_root("prepared-olap-artifact-fingerprint");
        let source = root.join("source.parquet");
        let target = root.join("prepared.vortex");
        std::fs::write(&source, b"source bytes").expect("write source");
        write_test_prepared_vortex_artifact(&target, 40);
        let source_digest = sha256_file_digest(&source, "test source").expect("source digest");
        let request = VortexPreparedOlapStateWriteRequest::new_local(
            "source-state-hits",
            "sha256:source-state-digest",
            "parquet",
            source_digest,
            12,
            "sha256:schema-digest",
            2,
            &target,
            &target,
        )
        .expect("olap request")
        .with_prepared_layout_policy(VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_LAYOUT_POLICY)
        .with_segment_map_status(VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_SEGMENT_MAP_STATUS);
        let initial = publish_vortex_prepared_olap_single_artifact_state(&request)
            .expect("publish olap state");

        std::thread::sleep(std::time::Duration::from_millis(5));
        write_test_prepared_vortex_artifact(&target, 50);
        let current_digest = sha256_file_digest(&target, "test artifact").expect("current digest");
        assert_ne!(current_digest, initial.prepared_artifact_digest);

        let fingerprint =
            LocalReuseFileFingerprint::from_path(&target, "test artifact").expect("fingerprint");
        assert_eq!(fingerprint.content_digest, current_digest);
        assert_ne!(fingerprint.content_digest, initial.prepared_artifact_digest);

        std::fs::remove_dir_all(root).expect("remove temp root");
    }

    #[test]
    fn prepared_olap_state_admits_plain_vortex_artifact_with_embedded_layout_status() {
        let root = temp_test_root("prepared-olap-plain-single-artifact");
        let source = root.join("source.parquet");
        let target = root.join("prepared.vortex");
        std::fs::write(&source, b"source bytes").expect("write source");
        write_test_prepared_vortex_artifact(&target, 60);
        let source_digest = sha256_file_digest(&source, "test source").expect("source digest");
        let legacy_manifest_path = legacy_prepared_olap_state_manifest_path(&target);
        let request = VortexPreparedOlapStateWriteRequest::new_local(
            "source-state-hits",
            "sha256:source-state-digest",
            "parquet",
            source_digest,
            12,
            "sha256:schema-digest",
            2,
            &target,
            &target,
        )
        .expect("olap request")
        .with_prepared_layout_policy(VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_LAYOUT_POLICY)
        .with_segment_map_status(VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_SEGMENT_MAP_STATUS);

        let report = publish_vortex_prepared_olap_single_artifact_state(&request)
            .expect("publish ready state");

        assert_eq!(report.status, "prepared_olap_state_ready");
        assert!(!legacy_manifest_path.exists());
        assert!(!report.manifest_written);
        assert_eq!(report.exact_sidecar_family_count, 0);
        assert!(!report.sub_second_candidate);
        assert_eq!(
            report.query_time_contract,
            VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_QUERY_TIME_CONTRACT
        );
        assert_eq!(
            report.layout_inventory_status,
            "opened_single_vortex_artifact_footer"
        );
        assert_eq!(report.layout_footer_row_count, "2");
        assert_ne!(report.layout_artifact_size_bytes, "unknown");
        assert_ne!(report.layout_root_encoding, "not_available");
        assert_ne!(report.layout_encoding_inventory, "not_available");
        assert!(report.layout_size_attribution.contains("source_columns="));
        assert!(report.layout_size_attribution.contains("derived_columns="));
        assert!(
            report
                .layout_size_attribution
                .contains("dictionary_status=")
        );
        assert!(
            report
                .layout_per_column_metadata_contract
                .contains(":logical=")
        );
        assert!(
            report
                .layout_per_column_metadata_contract
                .contains("roles=")
        );
        assert_ne!(
            report.layout_operator_selection_metadata_status,
            "per_column_metadata_not_available"
        );
        assert!(
            report
                .layout_segment_membership_status
                .starts_with("segment_map_available")
        );
        assert_eq!(
            report.layout_reader_cache_status,
            "enabled_for_local_metadata_open"
        );
        assert!(report.layout_metadata_persisted_in_artifact);
        assert_eq!(report.blocker_id, "none");
        assert!(
            report
                .admitted_query_families
                .contains("native_vortex_runtime")
        );

        std::fs::remove_dir_all(root).expect("remove temp root");
    }

    #[test]
    fn prepared_olap_state_bundle_reports_single_artifact_without_adjacent_olap_files() {
        let root = temp_test_root("prepared-olap-bundle-single-artifact");
        let source = root.join("source.parquet");
        let target = root.join("prepared.vortex");
        std::fs::write(&source, b"source bytes").expect("write source");
        write_test_prepared_vortex_artifact(&target, 70);
        let source_digest = sha256_file_digest(&source, "test source").expect("source digest");
        let legacy_manifest_path = legacy_prepared_olap_state_manifest_path(&target);
        let request = VortexPreparedOlapStateWriteRequest::new_local(
            "source-state-hits",
            "sha256:source-state-digest",
            "parquet",
            source_digest,
            12,
            "sha256:schema-digest",
            2,
            &target,
            &target,
        )
        .expect("olap request")
        .with_prepared_layout_policy(VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_LAYOUT_POLICY)
        .with_segment_map_status(VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_SEGMENT_MAP_STATUS);

        let fingerprint_calls = LOCAL_FILE_FINGERPRINT_CALLS.with(std::cell::Cell::get);
        let report =
            write_vortex_prepared_olap_state_bundle(request.clone()).expect("write olap bundle");
        assert_eq!(
            LOCAL_FILE_FINGERPRINT_CALLS.with(std::cell::Cell::get) - fingerprint_calls,
            1,
            "publication must perform one complete artifact checksum, not two"
        );
        assert_eq!(
            report.prepared_artifact_digest,
            sha256_file_digest(&target, "published artifact").expect("artifact checksum")
        );

        assert_eq!(report.status, "prepared_olap_state_ready");
        assert!(!report.manifest_written);
        assert!(!legacy_manifest_path.exists());
        assert_eq!(report.exact_sidecar_family_count, 0);
        assert_eq!(
            report.artifact_model,
            VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_MODEL
        );
        assert_eq!(
            report.metadata_pruning_contract,
            VORTEX_PREPARED_OLAP_METADATA_PRUNING_CONTRACT
        );
        assert_eq!(
            report.layout_inventory_status,
            "opened_single_vortex_artifact_footer"
        );
        assert_eq!(report.layout_footer_row_count, "2");
        assert!(report.layout_metadata_persisted_in_artifact);
        assert!(
            report
                .admitted_query_families
                .contains("native_vortex_runtime")
        );
        let sidecar_dir = target
            .parent()
            .expect("target parent")
            .join(".shardloom")
            .join("prepared.vortex.prepared-olap-state.d");
        assert!(
            !sidecar_dir.exists(),
            "single-artifact prepared OLAP state must not create a .prepared-olap-state.d directory"
        );

        let hit = evaluate_vortex_prepared_olap_single_artifact_state(&request)
            .expect("evaluate olap bundle");
        assert_eq!(hit.status, "prepared_olap_state_read_through_hit");
        assert_eq!(hit.blocker_id, "none");
        assert_eq!(
            hit.query_answer_sidecar_status,
            VORTEX_PREPARED_OLAP_QUERY_ANSWER_SIDECAR_STATUS
        );
        assert!(!hit.fallback_attempted);
        assert!(!hit.external_engine_invoked);

        std::fs::remove_file(&target).expect("remove published artifact");
        assert!(
            write_vortex_prepared_olap_state_bundle(request)
                .expect_err("publication still requires a readable artifact")
                .to_string()
                .contains("failed to stat prepared OLAP state artifact")
        );
        std::fs::remove_dir_all(root).expect("remove temp root");
    }

    #[test]
    fn prepared_olap_state_bundle_rejects_then_clears_old_sidecar_request_fields() {
        let root = temp_test_root("prepared-olap-clears-sidecar-fields");
        let source = root.join("source.parquet");
        let target = root.join("prepared.vortex");
        std::fs::write(&source, b"source bytes").expect("write source");
        write_test_prepared_vortex_artifact(&target, 80);
        let source_digest = sha256_file_digest(&source, "test source").expect("source digest");
        let legacy_manifest_path = legacy_prepared_olap_state_manifest_path(&target);
        let request = VortexPreparedOlapStateWriteRequest::new_local(
            "source-state-hits",
            "sha256:source-state-digest",
            "parquet",
            source_digest,
            12,
            "sha256:schema-digest",
            2,
            &target,
            &target,
        )
        .expect("olap request")
        .with_prepared_layout_policy(VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_LAYOUT_POLICY)
        .with_segment_map_status(VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_SEGMENT_MAP_STATUS)
        .with_substring_index_manifest("sidecar:old-query-summary")
        .with_aggregate_summary_manifest("sidecar:old-aggregate-summary")
        .with_row_position_manifest("sidecar:old-row-position")
        .with_dictionary_union_manifest("sidecar:old-dictionary-union")
        .with_derived_column_manifest("sidecar|derived_column|sha256:copied|copied.sidecar");
        let blocked = publish_vortex_prepared_olap_single_artifact_state(&request)
            .expect("reject sidecar request");
        assert_eq!(
            blocked.status,
            "blocked_query_answer_sidecar_not_public_runtime"
        );
        assert_eq!(
            blocked.blocker_id,
            "prepared_olap_state.query_answer_sidecar_not_public_runtime"
        );
        assert_eq!(
            blocked.query_answer_sidecar_status,
            "rejected_declared_query_answer_sidecar_not_public_runtime"
        );
        assert_eq!(
            blocked.layout_inventory_status,
            "opened_single_vortex_artifact_footer"
        );

        let report =
            write_vortex_prepared_olap_state_bundle(request.clone()).expect("write olap bundle");

        let still_blocked = evaluate_vortex_prepared_olap_single_artifact_state(&request)
            .expect("evaluate original sidecar fields");
        let sanitized_request = request
            .clone()
            .with_substring_index_manifest("none")
            .with_aggregate_summary_manifest("none")
            .with_row_position_manifest("none")
            .with_dictionary_union_manifest("none")
            .with_derived_column_manifest("none");
        let decision = evaluate_vortex_prepared_olap_single_artifact_state(&sanitized_request)
            .expect("evaluate cleared sidecar fields");

        assert_eq!(report.status, "prepared_olap_state_ready");
        assert!(!report.manifest_written);
        assert!(!legacy_manifest_path.exists());
        assert_eq!(report.exact_sidecar_family_count, 0);
        assert_eq!(
            report.query_answer_sidecar_status,
            VORTEX_PREPARED_OLAP_QUERY_ANSWER_SIDECAR_STATUS
        );
        assert_eq!(
            report.layout_inventory_status,
            "opened_single_vortex_artifact_footer"
        );
        assert_eq!(
            still_blocked.status,
            "blocked_query_answer_sidecar_not_public_runtime"
        );
        assert_eq!(still_blocked.exact_sidecar_family_count, 5);
        assert_eq!(decision.status, "prepared_olap_state_read_through_hit");
        assert_eq!(decision.exact_sidecar_family_count, 0);
        assert_eq!(
            decision.query_time_contract,
            VORTEX_PREPARED_OLAP_SINGLE_ARTIFACT_QUERY_TIME_CONTRACT
        );
        assert!(!decision.fallback_attempted);
        assert!(!decision.external_engine_invoked);

        std::fs::remove_dir_all(root).expect("remove temp root");
    }

    #[cfg(unix)]
    #[test]
    fn prepared_state_reuse_manifest_rejects_symlink_sidecar_directory() {
        use std::os::unix::fs::symlink;

        let root = temp_test_root("reuse-manifest-symlink");
        let outside = temp_test_root("reuse-manifest-symlink-outside");
        let source = root.join("input.csv");
        let target = root.join("prepared.vortex");
        std::fs::write(&source, "id,label\n1,alpha\n").expect("write source");
        std::fs::write(&target, b"prepared-vortex-artifact").expect("write prepared artifact");
        symlink(&outside, root.join(".shardloom")).expect("sidecar symlink");
        let manifest_path =
            vortex_prepared_state_reuse_manifest_path(&target).expect("manifest path");
        let request = reuse_request_for_test(&source, &target, &manifest_path);
        let decision = evaluate_vortex_prepared_state_reuse(&request).expect("reuse decision");
        let artifact_digest =
            sha256_file_digest(&target, "test artifact").expect("artifact digest");

        let error = write_vortex_prepared_state_reuse_manifest(
            &request,
            &decision,
            VortexPreparedStateReuseWriteEvidence {
                source_state_id: "source-state-base".to_string(),
                source_state_digest: "fnv64:source-base".to_string(),
                source_schema_digest: "fnv64:schema".to_string(),
                source_row_count: 1,
                source_column_family_summary: "id:int64,label:utf8".to_string(),
                prepared_state_id: "prepared-base".to_string(),
                prepared_state_digest: "fnv64:prepared-base".to_string(),
                prepared_artifact_digest: artifact_digest,
                certificate_refs: "reopen_row_count_scan".to_string(),
                fallback_attempted: false,
                external_engine_invoked: false,
            },
        )
        .expect_err("workspace-safe manifest writer rejects symlink sidecars");

        assert!(error.to_string().contains("symlink"));
        assert!(
            !outside
                .join("prepared.vortex.prepared-state-reuse.manifest")
                .exists()
        );
        let _ = std::fs::remove_file(root.join(".shardloom"));
        let _ = std::fs::remove_dir_all(root);
        let _ = std::fs::remove_dir_all(outside);
    }

    #[test]
    fn append_only_refinement_blocks_prefix_mismatch() {
        let root = temp_test_root("append-only-refinement-prefix");
        let source = root.join("input.csv");
        let target = root.join("prepared.vortex");
        std::fs::write(&source, "id,label\n1,alpha\n2,beta\n").expect("write base source");
        std::fs::write(&target, b"prepared-vortex-artifact").expect("write prepared artifact");
        let manifest_path =
            vortex_prepared_state_reuse_manifest_path(&target).expect("manifest path");
        let base_request = reuse_request_for_test(&source, &target, &manifest_path);
        let base_decision =
            evaluate_vortex_prepared_state_reuse(&base_request).expect("base reuse decision");
        let artifact_digest =
            sha256_file_digest(&target, "test artifact").expect("artifact digest");
        write_vortex_prepared_state_reuse_manifest(
            &base_request,
            &base_decision,
            VortexPreparedStateReuseWriteEvidence {
                source_state_id: "source-state-base".to_string(),
                source_state_digest: "fnv64:source-base".to_string(),
                source_schema_digest: "fnv64:schema".to_string(),
                source_row_count: 2,
                source_column_family_summary: "id:int64,label:utf8".to_string(),
                prepared_state_id: "prepared-base".to_string(),
                prepared_state_digest: "fnv64:prepared-base".to_string(),
                prepared_artifact_digest: artifact_digest,
                certificate_refs: "reopen_row_count_scan".to_string(),
                fallback_attempted: false,
                external_engine_invoked: false,
            },
        )
        .expect("write reuse manifest");

        std::fs::write(&source, "id,label\n1,ALPHA\n2,beta\n3,gamma\n")
            .expect("rewrite and append source");
        let current_request = reuse_request_for_test(&source, &target, &manifest_path);
        let decision = evaluate_vortex_prepared_state_append_only_refinement(&current_request)
            .expect("refinement decision");

        assert!(!decision.is_admitted());
        assert_eq!(decision.status, "blocked_source_prefix_digest_mismatch");
        assert_eq!(decision.blocker_id, "source_prefix_digest_mismatch");
        assert!(!decision.fallback_attempted);
        assert!(!decision.external_engine_invoked);

        std::fs::remove_dir_all(root).expect("remove temp root");
    }

    #[test]
    fn differential_refinement_manifest_is_digest_backed() {
        let root = temp_test_root("append-only-refinement-manifest");
        let manifest_path = root.join("refinement.manifest");
        let decision = VortexPreparedStateAppendOnlyRefinementDecision {
            schema_version: VORTEX_DIFFERENTIAL_REFINEMENT_MANIFEST_SCHEMA_VERSION,
            status: "admitted_append_only_refinement".to_string(),
            policy: VORTEX_DIFFERENTIAL_REFINEMENT_POLICY,
            reason: "source_prefix_verified_and_delta_bytes_detected".to_string(),
            blocker_id: "none".to_string(),
            automatic_detection_status: "append_only_delta_detected".to_string(),
            manifest_path: root.join("reuse.manifest"),
            reuse_manifest_digest: "fnv64:reuse".to_string(),
            source_path: root.join("input.csv"),
            source_format: "csv".to_string(),
            base_source_content_digest: "fnv64:base-source".to_string(),
            current_source_content_digest: "fnv64:current-source".to_string(),
            base_source_size_bytes: 10,
            current_source_size_bytes: 20,
            delta_byte_start: 10,
            delta_byte_end: 20,
            changed_byte_range_refs: "input.csv#bytes=10..20".to_string(),
            source_prefix_verification_status: "verified_old_source_bytes_are_current_prefix"
                .to_string(),
            base_source_state_id: "source-state-base".to_string(),
            base_source_state_digest: "fnv64:source-base".to_string(),
            base_source_row_count: 2,
            base_source_schema_digest: "fnv64:schema".to_string(),
            base_source_column_family_summary: "id:int64,label:utf8".to_string(),
            base_prepared_state_id: "prepared-base".to_string(),
            base_prepared_state_digest: "fnv64:prepared-base".to_string(),
            prepared_artifact_ref: root.join("prepared.vortex"),
            prepared_artifact_digest: "fnv64:artifact".to_string(),
            prepared_artifact_size_bytes: 64,
            certificate_refs: "reopen_row_count_scan".to_string(),
            fallback_attempted: false,
            external_engine_invoked: false,
        };
        let differential = evaluate_vortex_differential_preparation(differential_input(
            VortexDifferentialUpdateMode::AppendOnly,
        ));

        let report = write_vortex_differential_refinement_manifest(
            &manifest_path,
            &decision,
            &differential,
            "refined-prepared",
            "fnv64:refined",
            "count",
            "admitted_base_manifest_plus_delta_reopen_row_count",
            "fnv64:consumer",
        )
        .expect("write refinement manifest");

        assert!(report.manifest_written);
        assert!(report.manifest_digest.starts_with("sha256:"));
        let manifest = std::fs::read_to_string(&manifest_path).expect("read manifest");
        assert!(
            manifest
                .contains("schema_version=shardloom.vortex_differential_refinement_manifest.v1")
        );
        assert!(manifest.contains("overlay_consumer_family=count"));
        assert!(manifest.contains("manifest_digest=sha256:"));

        std::fs::remove_dir_all(root).expect("remove temp root");
    }

    fn differential_input(
        update_mode: VortexDifferentialUpdateMode,
    ) -> VortexDifferentialPreparationInput {
        VortexDifferentialPreparationInput {
            update_mode,
            base_source_state_id: "local-csv-base".to_string(),
            base_source_state_digest: "fnv64:base-source".to_string(),
            base_prepared_state_id: "vortex-prepared-state-base".to_string(),
            base_prepared_state_digest: "fnv64:base-prepared".to_string(),
            base_row_count: 2,
            base_schema_digest: "fnv64:schema".to_string(),
            base_column_family_summary: "id:int64,label:utf8".to_string(),
            delta_source_state_id: "local-csv-delta".to_string(),
            delta_source_state_digest: "fnv64:delta-source".to_string(),
            delta_row_count: 1,
            delta_schema_digest: "fnv64:schema".to_string(),
            delta_column_family_summary: "id:int64,label:utf8".to_string(),
            delta_manifest_digest: "fnv64:delta-manifest".to_string(),
            changed_byte_range_refs: "local-csv-delta:split=1:bytes=0..32".to_string(),
            changed_row_range_refs: "local-csv-delta:split=1:rows=0..1".to_string(),
            changed_segment_refs: "vortex-prepared-state-delta:rows=0..1:digest=fnv64:delta"
                .to_string(),
            delta_artifact_ref: "target/delta.vortex".to_string(),
            delta_artifact_digest: "fnv64:delta-artifact".to_string(),
            native_io_certificate_refs: "base_prepared_state,delta_artifact,reopen_row_count_scan"
                .to_string(),
        }
    }

    fn scout_input(
        anomaly_count: u64,
        anomaly_families: &str,
        unsupported_shape_status: &str,
        quarantine_required: bool,
    ) -> VortexScoutIngressInput {
        VortexScoutIngressInput {
            source_state_id: "local-jsonl-source".to_string(),
            source_state_digest: "fnv64:source".to_string(),
            source_format: "jsonl".to_string(),
            source_path: "target/source.jsonl".to_string(),
            source_schema_digest: "fnv64:schema".to_string(),
            row_count: 2,
            source_byte_count: 128,
            column_count: 2,
            read_plan: "full_columns".to_string(),
            metadata_range_refs: "local-jsonl-source:split=1:bytes=0..128".to_string(),
            sampled_row_range_refs: "local-jsonl-source:split=1:rows=0..2".to_string(),
            anomaly_count,
            anomaly_families: anomaly_families.to_string(),
            malformed_row_refs: "none".to_string(),
            schema_drift_status: "not_detected_no_prior_schema_baseline".to_string(),
            unsupported_shape_status: unsupported_shape_status.to_string(),
            nullability_status: "nullable_fields_admitted_as_scalar_nulls".to_string(),
            small_file_pathology_status: "observed_tiny_local_fixture_not_blocking".to_string(),
            quarantine_required,
            quarantine_output_plan_status: "planned_not_emitted_no_quarantine_sink_requested"
                .to_string(),
            quarantine_output_ref: "not_emitted".to_string(),
            quarantine_output_digest: "not_emitted".to_string(),
            redaction_status: "malformed_row_refs_are_row_numbers_only".to_string(),
            unsupported_diagnostic_code: "none".to_string(),
            correctness_policy: "fail_closed_no_silent_repair_or_row_drop".to_string(),
            fallback_attempted: false,
            external_engine_invoked: false,
        }
    }

    pub(super) fn layout_advisor_input(
        strategy_admitted: bool,
        unsupported_diagnostic_code: &str,
    ) -> VortexLayoutWriteAdvisorInput {
        VortexLayoutWriteAdvisorInput {
            source_state_id: "local-csv-source".to_string(),
            source_state_digest: "fnv64:source".to_string(),
            source_format: "csv".to_string(),
            source_schema_digest: "fnv64:schema".to_string(),
            row_count: 2,
            source_byte_count: 128,
            column_count: 2,
            workload_constitution: "prepare_once_local_fixture".to_string(),
            source_statistics_status: "local_source_file_stats_only".to_string(),
            requested_pushdown_requirements: "none_prepare_once".to_string(),
            sink_requirements: "workspace_safe_local_vortex_file_sink".to_string(),
            layout_strategy: "single_vortex_artifact_embedded_olap_layout_statistics".to_string(),
            chunking_strategy: "upstream_vortex_writer_default_zoned_row_blocks".to_string(),
            segmentation_strategy: "upstream_vortex_writer_default_zoned_segments".to_string(),
            dictionary_strategy:
                "preserve_vortex_dictionary_and_encoding_metadata_when_writer_emits_it".to_string(),
            statistics_policy:
                "preserve_vortex_layout_footer_statistics_for_metadata_pruning".to_string(),
            writer_provider_kind: "shardloom_kernel".to_string(),
            writer_provider_surface:
                "shardloom_scalar_rows_to_vortex_struct;VortexSession::write_options().write(ArrayStream)"
                    .to_string(),
            writer_admission_policy: VORTEX_PRODUCT_LOCAL_INGEST_PREPARE_ONCE_ADMISSION_POLICY
                .to_string(),
            writer_parallelism_budget: 1,
            writer_compression_candidate_fields: Vec::new(),
            write_reopen_verification_depth: "writer_and_reopen_row_count".to_string(),
            materialization_boundary_status: "materialized_scalar_rows_before_write".to_string(),
            decode_boundary_status: "compatibility_parse_to_scalar_values".to_string(),
            expected_read_tradeoff: "not_claimed_fixture_layout".to_string(),
            expected_write_tradeoff: "not_claimed_fixture_layout".to_string(),
            strategy_admitted,
            unsupported_diagnostic_code: unsupported_diagnostic_code.to_string(),
            correctness_refs: "writer_reopen_row_count".to_string(),
            benchmark_refs: "not_claim_grade_no_benchmark_refresh".to_string(),
            fallback_attempted: false,
            external_engine_invoked: false,
        }
    }

    fn copy_budget_input(
        measurement_status: &str,
        unsafe_lifetime_shortcut_status: &str,
        buffer_reuse_status: &str,
    ) -> VortexCopyBudgetInput {
        VortexCopyBudgetInput {
            source_state_id: "local-csv-source".to_string(),
            source_state_digest: "fnv64:source".to_string(),
            prepared_state_id: "vortex-prepared-state-fnv64-prepared".to_string(),
            prepared_state_digest: "fnv64:prepared".to_string(),
            source_format: "csv".to_string(),
            row_count: 2,
            source_byte_count: 128,
            column_count: 2,
            allocation_scope: "vortex_ingest_local_prepare_once".to_string(),
            copy_scope: "source_read,parse_normalization,vortex_array_build,writer,reopen,evidence"
                .to_string(),
            measurement_status: measurement_status.to_string(),
            source_read_copy_bytes: "128".to_string(),
            parse_normalization_copy_bytes: "not_measured".to_string(),
            columnar_handoff_copy_bytes: "not_applicable_scalar_rows".to_string(),
            vortex_array_build_copy_bytes: "not_measured".to_string(),
            writer_buffer_bytes: "256".to_string(),
            reopen_verify_copy_bytes: "not_measured".to_string(),
            evidence_render_copy_bytes: "not_measured".to_string(),
            total_measured_copy_bytes: "384".to_string(),
            buffer_family: "source_bytes,scalar_rows,vortex_writer_buffer".to_string(),
            ownership_policy: "owned_buffers_no_borrowed_lifetime_reuse".to_string(),
            writer_buffering_status: "writer_buffer_bytes_reported".to_string(),
            buffer_reuse_status: buffer_reuse_status.to_string(),
            buffer_reuse_count: 0,
            unsafe_lifetime_shortcut_status: unsafe_lifetime_shortcut_status.to_string(),
            correctness_parity_refs: "writer_reopen_row_count".to_string(),
            materialization_boundary_status: "materialized_scalar_rows_before_write".to_string(),
            decode_boundary_status: "compatibility_parse_to_scalar_values".to_string(),
            unsupported_diagnostic_code: "none".to_string(),
            fallback_attempted: false,
            external_engine_invoked: false,
        }
    }

    fn capillary_input(native_io_certificate_status: &str) -> VortexCapillaryPreparationInput {
        VortexCapillaryPreparationInput {
            source_state_id: "local-csv-source".to_string(),
            source_state_digest: "fnv64:source".to_string(),
            prepared_state_id: "vortex-prepared-state-source".to_string(),
            prepared_state_digest: "fnv64:prepared".to_string(),
            source_surface: "local_text_source_state_scalar_rows".to_string(),
            sink_surface: "workspace_safe_local_vortex_file_sink".to_string(),
            format_family: "csv".to_string(),
            operation_class: "vortex_ingest_prepare_once".to_string(),
            certification_depth: "ingest_certified".to_string(),
            row_count: 4,
            source_byte_count: 128,
            column_count: 2,
            source_split_refs: "local-csv-source:split=0".to_string(),
            source_byte_range_refs: "local-csv-source:split=0:bytes=0..128".to_string(),
            source_row_range_refs: "local-csv-source:split=0:rows=0..4".to_string(),
            projection_mask: "id,label".to_string(),
            filter_mask_status: "none".to_string(),
            prepared_artifact_ref: "target/source.vortex".to_string(),
            prepared_artifact_digest: "fnv64:artifact".to_string(),
            prepared_artifact_segment_refs:
                "vortex-prepared-state-source:rows=0..4:digest=fnv64:artifact".to_string(),
            writer_sink_refs: "target/source.vortex".to_string(),
            materialization_boundary_status: "scalar_rows_materialized_before_vortex_array_build"
                .to_string(),
            decode_boundary_status: "local_text_parse_to_scalar_values".to_string(),
            native_io_certificate_status: native_io_certificate_status.to_string(),
            native_io_certificate_refs:
                "source_split_refs,prepared_artifact_ref,reopen_row_count_scan".to_string(),
            correctness_digest: "fnv64:correct".to_string(),
            memory_budget_bytes: 16 * 1024 * 1024,
            max_parallelism: 2,
            result_sink_requested: false,
            result_sink_replay_verified: false,
            capillary_claim_evidence_requested: true,
            fallback_attempted: false,
            external_engine_invoked: false,
        }
    }

    fn capillary_prewrite_test_input(
        target_path: &Path,
        row_count: u64,
        column_count: usize,
    ) -> VortexCapillaryPreparationInput {
        let mut input = capillary_input("certified");
        input.prepared_artifact_ref = target_path.display().to_string();
        input.prepared_artifact_digest =
            "prewrite_pending_until_vortex_writer_certificate".to_string();
        input.writer_sink_refs = target_path.display().to_string();
        input.row_count = row_count;
        input.column_count = column_count;
        input.certification_depth = VortexIngestCertificationLevel::IngestCertified
            .as_str()
            .to_string();
        input.capillary_claim_evidence_requested = true;
        input
    }
}
