"""Bind deployed preview/production text to immutable reviewed Git source."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import urllib.request

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010/native-roadmap-hosted-697')
HEAD = 'c7b8bdfbe2c934be93e3d88a9124e770396cfee6'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def api(endpoint):
    return subprocess.check_output(['/opt/homebrew/bin/gh', 'api', endpoint], timeout=45)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', choices=('preview', 'production'), required=True)
    parser.add_argument('--revision', required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(['git', 'rev-parse', args.revision], cwd=ROOT, text=True).strip()
    pr_raw = api('repos/depsilon/shardloom/pulls/1575')
    pr = json.loads(pr_raw)
    assert pr['head']['sha'] == HEAD
    if args.stage == 'preview':
        assert revision == HEAD
        comments = json.loads(api('repos/depsilon/shardloom/issues/1575/comments?per_page=100'))
        import re
        urls = [url for c in comments if HEAD[:8] in c['body']
                for url in re.findall(r"https://[0-9a-f]{8}-shardloom\.djheinrich\.workers\.dev", c['body'])]
        assert len(set(urls)) == 1
        origin = urls[0]
    else:
        assert pr['merged'] and pr['merge_commit_sha'] == revision
        origin = 'https://shardloom.io'
    checks_raw = api(f'repos/depsilon/shardloom/commits/{revision}/check-runs?per_page=100')
    checks = json.loads(checks_raw)
    assert checks['total_count'] == len(checks['check_runs']) <= 100
    workers = [c for c in checks['check_runs'] if c['name'] == 'Workers Builds: shardloom']
    assert len(workers) == 1
    worker = workers[0]
    assert worker['head_sha'] == revision and worker['status'] == 'completed' and worker['conclusion'] == 'success'
    destination = OUT / (args.stage + '-served-697')
    destination.mkdir(exist_ok=False)
    (destination / 'pull-request.json').write_bytes(pr_raw)
    (destination / 'deployment-checks.json').write_bytes(checks_raw)
    routes = ['field-guide/' + name + '/index.html' for name in (
        'benchmark-methodology', 'runtime-and-io', 'limitations', 'python-surface')]
    routes += ['benchmarks/index.html', 'benchmarks.html', 'assets/parallax-home.js', 'pagefind/pagefind-entry.json']
    records = []
    for route in routes:
        expected = subprocess.check_output(['git', 'show', revision + ':website/' + route], cwd=ROOT)
        url = origin + '/' + route.removesuffix('index.html')
        request = urllib.request.Request(url, headers={'User-Agent': 'ShardLoom-owned-site-verification'})
        filename = route.replace('/', '_')
        attempts = []
        for attempt in range(1, 4):
            try:
                with urllib.request.urlopen(request, timeout=30) as response:
                    actual = response.read((2 << 20) + 1)
                    assert response.status == 200 and len(actual) <= 2 << 20
                    final_url = response.url
                attempts.append(dict(attempt=attempt, status='passed', bytes=len(actual)))
            except (TimeoutError, OSError) as error:
                attempts.append(dict(attempt=attempt, status='failed',
                    error_type=type(error).__name__, error=str(error)))
            with (destination / (filename + '.attempts.json')).open('w') as stream:
                json.dump(attempts, stream, indent=2)
                stream.write('\n')
            if attempts[-1]['status'] == 'passed':
                break
        else:
            raise RuntimeError('Bounded response retries exhausted: ' + url)
        (destination / filename).write_bytes(actual)
        prefix = 0
        while prefix < min(len(actual), len(expected)) and actual[prefix] == expected[prefix]:
            prefix += 1
        extra = len(actual) - len(expected)
        insertion = b''
        preserved = actual == expected
        if not preserved and 0 < extra <= 16384 and route.endswith('.html'):
            insertion = actual[prefix:prefix + extra]
            preserved = actual[prefix + extra:] == expected[prefix:]
            preserved &= b'/cdn-cgi/challenge-platform/' in insertion or b'static.cloudflareinsights.com/' in insertion
        records.append(dict(source='website/' + route, response=filename, url=url, final_url=final_url,
            http_status=200, expected_bytes=len(expected), expected_sha256=sha(expected),
            observed_bytes=len(actual), observed_sha256=sha(actual), raw_byte_identical=actual == expected,
            source_preserved=bool(preserved), attempts=attempts, insertion_bytes=len(insertion),
            insertion_sha256=sha(insertion) if insertion else None))
    report = dict(schema_version='shardloom.native_roadmap_served_source.v1', stage=args.stage,
        status='passed' if all(row['source_preserved'] for row in records) else 'failed',
        observed_at=datetime.now(timezone.utc).isoformat(), head=revision, reviewed_head=HEAD,
        origin=origin, responses=records,
        deployment={key: worker[key] for key in ('id', 'head_sha', 'status', 'conclusion', 'details_url', 'completed_at')},
        helper=dict(path=str(Path(__file__).resolve()), sha256=sha(Path(__file__).read_bytes())),
        scope='HTTP source identity and completed deployment check; browser observations recorded separately.')
    with (destination / 'report.json').open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status=report['status'], stage=args.stage, responses=len(records),
        identical=sum(r['raw_byte_identical'] for r in records), deployment_status=worker['conclusion'])))
    assert report['status'] == 'passed'


if __name__ == '__main__':
    main()
