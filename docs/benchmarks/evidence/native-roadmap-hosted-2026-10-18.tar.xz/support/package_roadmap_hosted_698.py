"""Bind roadmap PR closure, deployment and browser observations to immutable sources."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
D=O/'native-roadmap-hosted-697'
sys.path[:0]=[str(O),str(R/'scripts')]
import verify_stream_destination_integrated_sources_482 as v
v.R=R
read=lambda p:json.loads(Path(p).read_text())
sha=lambda raw:hashlib.sha256(raw).hexdigest()
merge=sys.argv[1]
source=read(D/'pr-sources-697.json')
head=source['revisions']['pr_head'];synthetic=source['revisions']['ci_merge']
assert head=='c7b8bdfbe2c934be93e3d88a9124e770396cfee6'
mapping,_=v.immutable_source_map(merge)
assert len(mapping)==2416 and {p:r['sha256'] for p,r in mapping.items()}==source['source_sha256']
tree=v.git('rev-parse',merge+'^{tree}').decode().strip()
assert tree==source['trees']['pr_head']==source['trees']['ci_merge']
assert v.git('rev-list','--parents','-n','1',merge).decode().split()==[merge,source['revisions']['base'],head]
closeouts={}
for stage in ('premerge','postmerge'):
    path=D/(stage+'-697a1')/'report.json';report=read(path)
    assert report['status']=='passed' and report['checks_passed']==44
    assert report['head']==head and report['merge']==(merge if stage=='postmerge' else None)
    assert report['blocking_review_findings']==report['open_pr_code_scanning_alerts']==0
    assert report['code_review']==dict(commit_sha=head,has_any_findings=False,has_unresolved_findings=False,status='completed')
    for ref in report['metadata']+[report['source_verification'],report['helper']]:
        raw=Path(ref['path']).read_bytes();assert len(raw)==ref['bytes'] and sha(raw)==ref['sha256']
    closeouts[stage]=dict(file='hosted/'+path.relative_to(D).as_posix(),sha256=sha(path.read_bytes()))
served={};served_coverage={}
for stage,revision in [('preview',head),('production',merge)]:
    path=D/(stage+'-served-697')/'report.json';report=read(path)
    assert report['status']=='passed' and report['head']==revision and len(report['responses'])==8
    assert report['reviewed_head']==head and report['deployment']['conclusion']=='success'
    for row in report['responses']:
        actual=(path.parent/row['response']).read_bytes()
        expected=v.git('show',revision+':'+row['source'])
        assert sha(actual)==row['observed_sha256'] and sha(expected)==row['expected_sha256']
        assert row['source_preserved']
        if actual==expected:
            assert row['raw_byte_identical'] and row['insertion_bytes']==0
        else:
            assert not row['raw_byte_identical'] and row['source'].endswith('.html')
            extra=len(actual)-len(expected)
            assert 0<extra<=16384 and extra==row['insertion_bytes']
            prefix=0
            while prefix<min(len(actual),len(expected)) and actual[prefix]==expected[prefix]:
                prefix+=1
            insertion=actual[prefix:prefix+extra]
            assert sha(insertion)==row['insertion_sha256']
            assert actual[prefix+extra:]==expected[prefix:]
            assert b'/cdn-cgi/challenge-platform/scripts/jsd/main.js' in insertion
            assert b'https://static.cloudflareinsights.com/' in insertion
    served_coverage[stage]=dict(responses=len(report['responses']),
        raw_byte_identical=sum(r['raw_byte_identical'] for r in report['responses']),
        source_preserved_with_cloudflare_scripts=sum(not r['raw_byte_identical'] for r in report['responses']))
    served[stage]=dict(file='hosted/'+path.relative_to(D).as_posix(),sha256=sha(path.read_bytes()))
browser=read(D/'browser/production-report.json')
assert browser['status']=='passed' and browser['merge']==merge and browser['head']==head
assert browser['search_result_opened'] and browser['benchmark_engine_value']=='54.358'
assert browser['scope']=='Production in-app browser navigation and search; no cross-browser claim.'
bridge=dict(status='passed',base=source['revisions']['base'],head=head,synthetic=synthetic,merge=merge,
    tree=tree,runtime_source_files=2416,runtime_source_unchanged=False,test_only_changes=source['test_only_changes'],production_code_unchanged_by_exact_cfg_test_elision=True,source_sha256=source['source_sha256'])
bridge_path=D/'merged-sources-698.json'
bridge_path.open('x').write(json.dumps(bridge,indent=2)+'\n')
files={}
for path in sorted(D.rglob('*')):
    if path.is_file():
        assert not path.is_symlink();files['hosted/'+path.relative_to(D).as_posix()]=path.read_bytes()
for name in ['prepare_roadmap_hosted_697.py','prepare_roadmap_review_reader_685.py',
    'roadmap-storage-correction-682.json','package_roadmap_hosted_698.py',
    'freeze_native_release_298.py','verify_stream_destination_integrated_sources_482.py']:
    files['support/'+name]=(O/name).read_bytes()
files['support/local_uat_storage.py']=v.git('show',merge+':scripts/local_uat_storage.py')
for relative in ['docs/benchmarks/evidence/native-roadmap-documentation-validation-2026-10-18.json',
    'docs/benchmarks/evidence/native-roadmap-verification-contracts-2026-10-18.json',
    'docs/benchmarks/evidence/native-roadmap-fresh-uat-2026-10-18.json',
    'docs/architecture/native-roadmap-verification-contracts-2026-10-18.md',
    'docs/architecture/local-development-storage.md']:
    files['source/'+relative]=v.git('show',merge+':'+relative)
correction_path=R/'docs/benchmarks/evidence/native-roadmap-test-pressure-2026-10-18.json'
correction=read(correction_path)
assert correction['status']=='passed' and correction['production_code_unchanged_by_exact_cfg_test_elision']
assert correction['changes']==source['test_only_changes']
correction_archive=correction_path.parent/correction['archive']['file']
assert sha(correction_archive.read_bytes())==correction['archive']['sha256']
files['support/'+correction_path.name]=correction_path.read_bytes()
files['support/'+correction_archive.name]=correction_archive.read_bytes()
for label in ('test_only_correction','test_only_source_bridge','current_source'):
    ref=source[label];path=Path(ref['path']);raw=path.read_bytes()
    assert len(raw)==ref['bytes'] and sha(raw)==ref['sha256']
    files['support/'+path.name]=raw
files['support/closeout-review-685.py']=(O/'native-roadmap-hosted-684/closeout-review-685.py').read_bytes()
assert sum(map(len,files.values()))<24*1024*1024
evidence=R/'docs/benchmarks/evidence'
archive=evidence/'native-roadmap-hosted-2026-10-18.tar.xz'
index=archive.with_suffix('').with_suffix('.json')
assert not archive.exists() and not index.exists()
members=[]
with tarfile.open(archive,'x:xz') as bundle:
    for name,raw in sorted(files.items()):
        entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mode=0o644
        bundle.addfile(entry,io.BytesIO(raw));members.append(dict(name=name,bytes=len(raw),sha256=sha(raw)))
with tarfile.open(archive,'r:xz') as bundle:
    assert len(bundle.getmembers())==len(files)==len({m.name for m in bundle.getmembers()})
    for item in members:
        entry=bundle.getmember(item['name']);assert entry.isfile()
        assert bundle.extractfile(entry).read()==files[item['name']]
result=dict(schema_version='shardloom.native_roadmap_hosted_packet.v1',status='passed',
    pr=1575,head=head,merge=merge,synthetic=synthetic,checks_passed=44,
    runtime_source_files=2416,runtime_source_unchanged=False,test_only_changes=source['test_only_changes'],production_code_unchanged_by_exact_cfg_test_elision=True,
    blocking_review_findings=0,historical_source_findings_addressed=3,historical_threads_resolved_by_agent=False,
    closeouts=closeouts,served=served,served_responses_verified=16,served_coverage=served_coverage,
    production_browser='hosted/browser/production-report.json',version_bump='held',
    fresh_benchmark_run=False,performance_claim=False,
    archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes())),
    member_count=len(members),members=members,all_members_reopened=True,
    scope='Final PR checks and automated review, immutable source identity, confirmed merge, preserved preview/production HTTP source and production browser navigation/search. Raw byte identity is counted separately from six production HTML responses with identified Cloudflare challenge/analytics script insertions; removing each recorded insertion reproduces the exact committed bytes. The only selected-source change is the verified cfg(test) correction; exact production-code elision preserves the existing fresh UAT acceptance. No additional benchmark was run.')
index.open('x').write(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status='passed',index=str(index),members=len(members),archive_bytes=archive.stat().st_size)))
