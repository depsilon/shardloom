"""Account for an addressed review anchored to an unchanged neighboring line."""
import ast
import hashlib
import json
from pathlib import Path

D=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010/native-roadmap-hosted-684')
original=D/'closeout.py';target=D/'closeout-review-685.py'
text=original.read_text()
old="        assert thread['isOutdated'] or thread['isResolved'],thread\n"
assert text.count(old)==1;text=text.replace(old,'')
needle='    assert set(observed)==set(known)\n'
extra="""    review_comments=api('review-comments',['repos/depsilon/shardloom/pulls/1575/comments?per_page=100'])
    assert len(review_comments)==2 and {c['id'] for c in review_comments}==set(known)
    originals={4307076145:'a456b42ff6e9eb7a972d51c0c126bc5b41de7330',4307152814:'9aabef1a444f766223b0a2b62af8453256477c3e'}
    assert all(c['original_commit_id']==originals[c['id']] for c in review_comments)
"""
assert text.count(needle)==1;text=text.replace(needle,needle+extra)
text=text.replace("note='Both known comments are outdated or resolved and exact final-source corrections are verified. No unknown or current finding is accepted.'",
 "note='Both original findings have verified exact final-source corrections. One comment may remain anchored to the unchanged neighboring inventory line; UI resolution is recorded separately from source disposition. No additional finding is accepted.'")
ast.parse(text)
assert not target.exists();target.write_text(text)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record=dict(status='prepared',original=dict(file=original.name,sha256=sha(original)),
 replacement=dict(file=target.name,sha256=sha(target)),
 reason='The storage review was anchored to the new inventory line, not the stale following sentence that was corrected. GitHub can keep the original comment non-outdated despite the verified fix. Require the exact two original comment identities and source corrections; retain real thread and bot states without resolving them.',
 helper=dict(file=__file__,sha256=sha(Path(__file__))))
p=D/'review-reader-provenance-685.json';assert not p.exists();p.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(status='prepared',reader=str(target))))
