"""Capture exact PR/check/review state for the native worker lifetime correction."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

HEAD='29aa4cf068b6b75dd61543463f00683d70c8147f'
BASE='6780e7df564c55f3e256822be1d0383cfabff0c9'
DEST=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010/native-roadmap-hosted-684')


def identity(path):
    raw = Path(path).read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', choices=('premerge', 'postmerge'), required=True)
    parser.add_argument('--merged')
    parser.add_argument('--attempt', default='684')
    args = parser.parse_args()
    assert re.fullmatch(r'[a-z0-9-]+', args.attempt)
    assert (args.stage == 'postmerge') == bool(args.merged)
    if args.merged:
        assert re.fullmatch(r'[a-f0-9]{40}', args.merged)
    destination = DEST/(args.stage+'-'+args.attempt)
    destination.mkdir(exist_ok=False)
    records = []

    def api(name, arguments):
        completed = subprocess.run(['/opt/homebrew/bin/gh', 'api', *arguments],
            capture_output=True, timeout=60)
        assert completed.returncode == 0, completed.stderr.decode()
        assert len(completed.stdout) <= 8*1024*1024
        path = destination/(name+'.json')
        path.write_bytes(completed.stdout)
        records.append(identity(path))
        return json.loads(completed.stdout)

    pr = api('pull-request', ['repos/depsilon/shardloom/pulls/1575'])
    checks = api('checks', [f'repos/depsilon/shardloom/commits/{HEAD}/check-runs?per_page=100'])
    statuses = api('statuses', [f'repos/depsilon/shardloom/commits/{HEAD}/status?per_page=100'])
    comments = api('issue-comments', ['repos/depsilon/shardloom/issues/1575/comments?per_page=100'])
    query = '''query { repository(owner:"depsilon", name:"shardloom") {
      pullRequest(number:1575) { number headRefOid merged mergeCommit { oid }
        reviews(first:100) { pageInfo { hasNextPage } nodes { id state commit { oid } } }
        reviewThreads(first:100) { pageInfo { hasNextPage } nodes {
          id isResolved isOutdated path comments(first:100) {
            pageInfo { hasNextPage } nodes { id databaseId body url }
          }
        } }
      } } }'''
    review = api('review-state', ['graphql', '-f', 'query='+query])
    alerts = api('open-pr-code-scanning-alerts',
        ['repos/depsilon/shardloom/code-scanning/alerts?ref=refs/pull/1575/merge&state=open&per_page=100'])
    assert pr['number'] == 1575 and pr['head']['sha'] == HEAD
    if args.stage == 'premerge':
        assert pr['state'] == 'open' and not pr['merged'] and not pr['draft']
        assert pr['base']['sha'] == BASE and pr['mergeable'] and pr['mergeable_state'] == 'clean'
    else:
        assert pr['merged'] and pr['merge_commit_sha'] == args.merged
    assert checks['total_count'] == len(checks['check_runs']) == 44
    assert len({row['id'] for row in checks['check_runs']}) == 44
    assert all(row['head_sha'] == HEAD and row['status'] == 'completed'
        and row['conclusion'] == 'success' for row in checks['check_runs'])
    assert statuses['sha'] == HEAD and statuses['total_count'] == 0 and statuses['statuses'] == []
    assert len(comments) < 100
    bot = [row for row in comments if row['user']['login'] == 'chatgpt-codex-connector[bot]']
    assert len(bot) == 1
    marker = re.search(r'<!-- codex-review-state:v1 (.*?) -->', bot[0]['body'])
    assert marker
    state = json.loads(marker.group(1))['code_review']
    assert state['commit_sha']==HEAD and state['status']=='completed'
    assert isinstance(state['has_any_findings'],bool) and isinstance(state['has_unresolved_findings'],bool)
    assert not review.get('errors')
    reviewed = review['data']['repository']['pullRequest']
    assert reviewed['number'] == 1575 and reviewed['headRefOid'] == HEAD
    assert reviewed['merged'] == (args.stage == 'postmerge')
    if args.merged:
        assert reviewed['mergeCommit']['oid'] == args.merged
    for kind in ('reviews', 'reviewThreads'):
        assert reviewed[kind]['pageInfo']['hasNextPage'] is False
    assert all(row['state'] in ('COMMENTED', 'APPROVED', 'DISMISSED')
        for row in reviewed['reviews']['nodes'])
    threads = reviewed['reviewThreads']['nodes']
    assert alerts == []
    known={4307076145:'owner_verification_contracts',4307152814:'storage_inventory_wording'}
    observed={}
    for thread in threads:
        assert thread['comments']['pageInfo']['hasNextPage'] is False
        for comment in thread['comments']['nodes']:
            number=comment['databaseId'];assert number in known,comment
            assert number not in observed;observed[number]=known[number]
    assert set(observed)==set(known)
    review_comments=api('review-comments',['repos/depsilon/shardloom/pulls/1575/comments?per_page=100'])
    assert len(review_comments)==2 and {c['id'] for c in review_comments}==set(known)
    originals={4307076145:'a456b42ff6e9eb7a972d51c0c126bc5b41de7330',4307152814:'9aabef1a444f766223b0a2b62af8453256477c3e'}
    assert all(c['original_commit_id']==originals[c['id']] for c in review_comments)
    root=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
    def blob(name):
        return subprocess.check_output(['git','show',HEAD+':'+name],cwd=root)
    index=json.loads(blob('docs/benchmarks/evidence/native-roadmap-documentation-validation-2026-10-18.json'))
    follow=index['verification_contract_followup']
    follow_raw=blob('docs/benchmarks/evidence/'+follow['file'])
    assert hashlib.sha256(follow_raw).hexdigest()==follow['sha256']
    fixed=json.loads(follow_raw);assert fixed['status']=='passed' and len(fixed['owners'])==14
    for ref in fixed['source_identities']:
        assert hashlib.sha256(blob(ref['file'])).hexdigest()==ref['sha256']
    storage=index['storage_inventory_review_correction'];assert storage['status']=='passed'
    assert hashlib.sha256(blob(storage['source_file'])).hexdigest()==storage['source_sha256']
    primary_disposition=dict(status='addressed_in_final_source',findings=observed,
        verification_contract_packet_sha256=follow['sha256'],storage_source_sha256=storage['source_sha256'],
        historical_threads_resolved_by_agent=False,
        note='Both original findings have verified exact final-source corrections. One comment may remain anchored to the unchanged neighboring inventory line; UI resolution is recorded separately from source disposition. No additional finding is accepted.')
    source = DEST/'pr-sources-684.json'
    source_record = json.loads(source.read_text())
    assert source_record['status'] == 'passed' and source_record['source_files'] == 2416
    assert source_record['revisions']['pr_head'] == HEAD
    report = dict(schema_version='shardloom.native_roadmap_review_closeout.v1',
        status='passed', stage=args.stage, recorded_at=datetime.now(timezone.utc).isoformat(),
        head=HEAD, merge=args.merged, checks_passed=44, code_review=state,
        review_coverage=dict(automated_review_head=HEAD, final_head=HEAD,
            automated_review_covers_final_head=True),
        review_threads=len(threads), unresolved_review_threads=sum(not x['isResolved'] for x in threads), blocking_review_findings=0, primary_disposition=primary_disposition, open_pr_code_scanning_alerts=0,
        source_verification=identity(source), metadata=records, helper=identity(__file__))
    target = destination/'report.json'
    target.open('x').write(json.dumps(report, indent=2)+'\n')
    print(json.dumps(dict(status='passed', stage=args.stage, checks=44,
        review_threads=len(threads), blocking_review_findings=0, report=str(target))))


if __name__ == '__main__':
    main()
