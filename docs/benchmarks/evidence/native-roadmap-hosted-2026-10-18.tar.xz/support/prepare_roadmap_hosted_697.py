"""Bind the final test-only correction and existing production acceptance to PR 1575."""
import ast
import json
from pathlib import Path
import subprocess
import sys

R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
D=O/'native-roadmap-hosted-697'
HEAD='c7b8bdfbe2c934be93e3d88a9124e770396cfee6'
OLD='29aa4cf068b6b75dd61543463f00683d70c8147f'
BASE='6780e7df564c55f3e256822be1d0383cfabff0c9'
sys.path[:0]=[str(O),str(R/'scripts')]
import verify_stream_destination_integrated_sources_482 as v
from freeze_native_release_298 import save,sha
v.R=R
read=lambda p:json.loads(Path(p).read_text())
identity=lambda p:dict(path=str(p),bytes=Path(p).stat().st_size,sha256=sha(p))
validated=read(O/'dictionary-pressure-validation-692/validation.json')
bridge=read(O/'dictionary-pressure-validation-692/test-only-source-bridge.json')
assert validated['status']==bridge['status']=='passed'
assert validated['production_code_unchanged_by_exact_cfg_test_elision']
pr=json.loads(subprocess.check_output(['gh','api','repos/depsilon/shardloom/pulls/1575']))
assert pr['head']['sha']==HEAD and pr['base']['sha']==BASE
synthetic=v.git('rev-parse','refs/codex/pr1575-validation-697').decode().strip()
assert synthetic==pr['merge_commit_sha']
trees={};summaries={}
for label,revision in [('base',BASE),('pr_head',HEAD),('ci_merge',synthetic)]:
    mapping,_=v.immutable_source_map(revision)
    expected=bridge['accepted_runtime_source_sha256'] if label=='base' else bridge['source_sha256']
    assert len(mapping)==2416 and {p:r['sha256'] for p,r in mapping.items()}==expected
    trees[label]=v.git('rev-parse',revision+'^{tree}').decode().strip()
    summaries[label]=v.identity_summary(mapping)
assert trees['pr_head']==trees['ci_merge']
assert v.git('rev-list','--parents','-n','1',synthetic).decode().split()==[synthetic,BASE,HEAD]
assert not v.git('diff',OLD,HEAD,'--','website','website-src').strip()
assert not D.exists();D.mkdir()
save(D/'pr-sources-697.json',dict(status='passed',source_files=2416,
    source_sha256=bridge['source_sha256'],revisions=dict(base=BASE,pr_head=HEAD,ci_merge=synthetic),
    trees=trees,source_summaries=summaries,test_only_changes=bridge['changes'],
    production_code_unchanged_by_exact_cfg_test_elision=True,
    test_only_correction=identity(O/'dictionary-pressure-validation-692/validation.json'),
    test_only_source_bridge=identity(O/'dictionary-pressure-validation-692/test-only-source-bridge.json'),
    accepted_source=identity(O/'native-release-source-roadmap663.json'),
    current_source=identity(O/'native-release-source-pressure692.json'),
    website_unchanged_from=OLD,helper=identity(Path(__file__))))
programs={}
for label,original in [('closeout',O/'native-roadmap-hosted-684/closeout-review-685.py'),
    ('served',O/'native-roadmap-hosted-684/served.py')]:
    text=original.read_text().replace(OLD,HEAD).replace('native-roadmap-hosted-684','native-roadmap-hosted-697')
    text=text.replace('pr-sources-684.json','pr-sources-697.json').replace("default='684'","default='697'")
    text=text.replace('-served-684','-served-697')
    if label=='closeout':
        text=text.replace('Capture exact PR/check/review state for the native worker lifetime correction.',
            'Capture exact roadmap PR checks, review and test-only correction identity.')
        anchor="    assert source_record['revisions']['pr_head'] == HEAD\n"
        assert text.count(anchor)==1
        extra="""    assert source_record['production_code_unchanged_by_exact_cfg_test_elision']
    correction_path=Path(source_record['test_only_correction']['path'])
    assert identity(correction_path)==source_record['test_only_correction']
    correction=json.loads(correction_path.read_text())
    assert correction['status']=='passed' and correction['production_code_unchanged_by_exact_cfg_test_elision']
    for path,change in correction['changes'].items():
        assert hashlib.sha256(blob(path)).hexdigest()==change['after']
    assert len(correction['changes'])==1
"""
        text=text.replace(anchor,anchor+extra)
    if label=='closeout':
        text=text.replace("known={4307076145:'owner_verification_contracts',4307152814:'storage_inventory_wording'}",
            "known={4307076145:'owner_verification_contracts',4307152814:'storage_inventory_wording',4307343828:'test_pressure_source_evidence'}")
        text=text.replace("assert len(review_comments)==2", "assert len(review_comments)==3")
        text=text.replace("4307152814:'9aabef1a444f766223b0a2b62af8453256477c3e'}",
            "4307152814:'9aabef1a444f766223b0a2b62af8453256477c3e',4307343828:'3122328a9ed85a9aacc24337a2e4ef1486d89954'}")
        text=text.replace("    assert isinstance(state['has_any_findings'],bool) and isinstance(state['has_unresolved_findings'],bool)",
            "    assert state['has_any_findings'] is False and state['has_unresolved_findings'] is False")
        text=text.replace("Both original findings have verified exact final-source corrections.",
            "All three original findings have verified exact final-source corrections.")
        pressure_anchor="    primary_disposition=dict(status='addressed_in_final_source',findings=observed,"
        pressure_check="""    assert index['runtime_source_unchanged'] is fixed['runtime_source_unchanged'] is False
    assert index['test_pressure_followup']==fixed['test_pressure_followup']
    pressure_ref=index['test_pressure_followup']
    pressure_raw=blob('docs/benchmarks/evidence/'+pressure_ref['file'])
    assert hashlib.sha256(pressure_raw).hexdigest()==pressure_ref['sha256']
    pressure=json.loads(pressure_raw)
    assert pressure['status']=='passed' and pressure['focused_tests']==14
    assert pressure['production_code_unchanged_by_exact_cfg_test_elision']
    assert pressure['source_files']==2416 and len(pressure['changes'])==1
    assert pressure['changes']==pressure_ref['changes']
    assert {x['name'] for x in pressure['checks']}=={'format','workspace-clippy','workspace-tests'}
    assert all(x['returncode']==0 for x in pressure['checks'])
    for path,change in pressure['changes'].items():
        assert hashlib.sha256(blob(path)).hexdigest()==change['after']
    assert hashlib.sha256(blob('docs/benchmarks/evidence/'+pressure['archive']['file'])).hexdigest()==pressure['archive']['sha256']
"""
        assert text.count(pressure_anchor)==1
        text=text.replace(pressure_anchor,pressure_check+pressure_anchor)
        text=text.replace("verification_contract_packet_sha256=follow['sha256'],storage_source_sha256=storage['source_sha256'],",
            "verification_contract_packet_sha256=follow['sha256'],storage_source_sha256=storage['source_sha256'],test_pressure_packet_sha256=pressure_ref['sha256'],")
    ast.parse(text)
    target=D/(label+'.py');target.write_text(text)
    programs[label]=dict(original=identity(original),adapted=identity(target))
save(D/'helper-provenance-697.json',programs)
print(json.dumps(dict(status='passed',head=HEAD,synthetic=synthetic,source_files=2416,
    test_only_changes=len(bridge['changes']),production_code_unchanged=True)))
