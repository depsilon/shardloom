"""Bind hosted worker lifetime regressions, native suites and installed wheels to PR #1564."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess

from accept_stream_dynamic_subquery_hosted_jobs_corrected_528 import normalized, machine_report
from verify_stream_subquery_integrated_sources_513 import identity

ROOT = Path('/Users/dylan/.codex/worktrees/native-relational-workflows/shardloom-local-repo')
OUT = Path(__file__).resolve().parent / 'native-worker-drain-hosted-569'
LOGS = OUT / 'job-logs'
HEAD = '36f620a0e38cd13730cd769e8a7a45cad694c73c'
BASE = 'de408cb794640ac1756d3dfe25a2064e9cb95c64'
SYNTHETIC = 'fcc65224653cde938466a89cf9097322ab16828f'
TREE = 'fbe10a1f0232d5bd6ecd6bf405e90fda011ed9ae'
RUN = 39002559186
JOBS = {117308370635:'Python test shard (core)',
        117308370753:'Rust feature matrix (native_public_surface_tests)',
        117308370762:'Rust feature matrix (native_vortex_tests)',
        117308370412:'Native Python wheel (py310_ubuntu)',
        117308370479:'Native Python wheel (py313_ubuntu)',
        117308370494:'Native Python wheel (py313_macos)'}


def checked(ref):
    path = (LOGS/ref['path']).resolve()
    assert LOGS.resolve() in path.parents
    actual = identity(path)
    assert actual['bytes'] == ref['bytes'] and actual['sha256'] == ref['sha256']
    return path


def source(path):
    return subprocess.check_output(['git','show',HEAD+':'+path],cwd=ROOT)


def rust_tests(path, count):
    raw = source(path)
    names = re.findall(r'#\[test\]\s*fn (\w+)\(',raw.decode())
    assert len(names) == len(set(names)) == count
    return [dict(name=name,source=path,sha256=hashlib.sha256(raw).hexdigest()) for name in names]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('snapshot')
    args = parser.parse_args()
    assert re.fullmatch(r'capture-\d{8}T\d{6}Z',args.snapshot)
    summary_path = LOGS/args.snapshot/'summary.json'
    summary = json.loads(summary_path.read_text())
    assert summary['status'] == 'COMPLETE' and not summary['errors']
    assert summary['expected_head_sha'] == HEAD and summary['run_id'] == RUN
    assert len(summary['jobs']) == 6 and {r['job_id']:r['expected_name'] for r in summary['jobs']} == JOBS
    assert summary['pending_job_names'] == []
    assert all(command['exit_code'] == 0 for command in summary['commands'])
    run_path = checked(summary['run'])
    run = json.loads(run_path.read_text())
    assert run['id'] == RUN and run['head_sha'] == HEAD
    assert any(pr['number'] == 1564 and pr['head']['sha'] == HEAD and pr['base']['sha'] == BASE
               for pr in run['pull_requests'])
    source_record_path = OUT/'pr-sources-569.json'
    source_record = json.loads(source_record_path.read_text())
    assert source_record['status'] == 'passed' and source_record['source_files'] == 2373
    assert source_record['revisions'] == dict(pr_head=HEAD,ci_merge=SYNTHETIC)
    assert set(source_record['trees'].values()) == {TREE}
    native = []
    for filename,count in (
        ('native_provider_varbin_metadata_tests.rs',12),
        ('native_provider_varbin_construction_tests.rs',7),
        ('native_provider_varbin_deserialize_tests.rs',4),
        ('resident_memory_varbin_transfer_tests.rs',2),
        ('scheduler_bridge_lifetime_tests.rs',4),
        ('universal_format_io_parquet_startup_tests.rs',3)):
        native += rust_tests('shardloom-vortex/src/'+filename,count)
    assert len(native) == len({row['name'] for row in native}) == 32
    for parent,child,module in (
        ('native_provider_memory.rs','native_provider_varbin_metadata_tests.rs','varbin_metadata_tests'),
        ('native_provider_memory.rs','native_provider_varbin_construction_tests.rs','varbin_construction_tests'),
        ('native_provider_memory.rs','native_provider_varbin_deserialize_tests.rs','varbin_deserialize_tests'),
        ('resident_memory_encoded_transfer_tests.rs','resident_memory_varbin_transfer_tests.rs','varbin_metadata_tests'),
        ('scheduler_bridge.rs','scheduler_bridge_lifetime_tests.rs','lifetime_tests'),
        ('universal_format_io.rs','universal_format_io_parquet_startup_tests.rs','parquet_startup_tests')):
        assert '#[path = "'+child+'"]\nmod '+module+';' in source('shardloom-vortex/src/'+parent).decode()
    workflow = source('.github/workflows/ci.yml').decode()
    lane = workflow.split('- lane: native_vortex_tests\n',1)[1].split('          - lane:',1)[0]
    for provider in ('array','fsst','runend','zstd'):
        assert lane.count('cargo test --manifest-path vendor/vortex-'+provider+'/Cargo.toml') == 1
        assert lane.count('cargo clippy --manifest-path vendor/vortex-'+provider+'/Cargo.toml') == 1
    assert 'cargo test --manifest-path vendor/vortex-layout/Cargo.toml' in lane
    assert '--lib layouts::file_stats::tests::' in lane
    assert lane.count('--lib -- --test-threads=2') == 4
    assert lane.count('--lib -- -D warnings') == 4
    binding_sources = []
    for path in sorted((ROOT/'python/tests').glob('test_native*binding.py')):
        relative = path.relative_to(ROOT).as_posix()
        raw = source(relative)
        methods = [n.name for n in ast.walk(ast.parse(raw)) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
        binding_sources.append(dict(path=relative,sha256=hashlib.sha256(raw).hexdigest(),methods=methods))
    assert sum(len(r['methods']) for r in binding_sources) == 100
    proof_source = source('scripts/prove_native_python_wheel.py').decode()
    assert 'pattern="test_native*binding.py"' in proof_source and 'SHARDLOOM_REQUIRE_NATIVE_PYTHON="1"' in proof_source
    accepted = []
    for row in summary['jobs']:
        assert row['capture_state'] == 'captured'
        metadata_path = checked(row['metadata'])
        metadata = json.loads(metadata_path.read_text())
        assert metadata['id'] == row['job_id'] and metadata['run_id'] == RUN
        assert metadata['head_sha'] == HEAD and metadata['name'] == JOBS[row['job_id']]
        assert metadata['status'] == 'completed' and metadata['conclusion'] == 'success'
        assert all(step['conclusion'] in ('success','skipped') for step in metadata['steps'])
        log_path = checked(row['log'])
        assert log_path.stat().st_size <= 12*1024*1024
        text = normalized(log_path)
        assert SYNTHETIC+':refs/remotes/pull/1564/merge' in text
        assert text.splitlines()[-1].startswith('Cleaning up orphan processes')
        assert not re.search(r'^test .* \.\.\. FAILED$|^test result: FAILED',text,re.M)
        result = dict(job_id=row['job_id'],name=metadata['name'],raw=identity(log_path),metadata=identity(metadata_path))
        if metadata['name'].startswith('Native Python wheel'):
            proof, offsets = machine_report(text,'shardloom.native_python_wheel_proof.v1')
            assert proof == row['analysis']['wheel_proof']
            assert proof == json.loads(checked(row['analysis']['wheel_proof_file']).read_text())
            assert proof['status'] == proof['stage']['status'] == proof['integrity']['status'] == 'passed'
            assert proof['integration'] == dict(tests=100,failures=0,errors=0,skipped=0,status='passed')
            assert proof['installed_load']['isolated_install'] and proof['installed_load']['version'] == '0.6.0'
            assert proof['uninstall_status'] == 'passed'
            assert proof['publication_attempted'] is False and proof['performance_claim'] is False
            assert all(step['returncode'] == 0 for step in proof['steps'])
            steps = {s['name']:s for s in proof['steps']}
            assert {'load','integration','install','uninstall','verify_uninstalled'} <= steps.keys()
            assert '-I' in steps['load']['command'] and '-I' in steps['integration']['command']
            assert proof['integrity']['native_library_sha256'] in steps['load']['command']
            assert proof['integrity']['cli_sha256'] in steps['load']['command']
            assert proof['integrity']['load_verified'] is False
            if 'ubuntu' in metadata['name']:
                assert proof['linux_audit']['status'] == 'passed' and proof['integrity']['linux_audit_verified']
            assert proof['installed_load']['python'].startswith('3.10.' if 'py310' in metadata['name'] else '3.13.')
            result.update(proof=proof,normalized_offsets=offsets)
        elif row['job_id'] == 117308370635:
            proof, offsets = machine_report(text,'shardloom.python_test_shard_evidence.v1')
            assert proof['status'] == 'passed' and proof['test_count'] == 626 and proof['skipped_count'] == 14
            assert proof['failure_count'] == proof['error_count'] == 0 and proof['module_count'] == 57
            assert re.search(r'^Ran 526 tests in ',text,re.M)
            assert {'python.tests.test_native_subquery_binding','python.tests.test_native_dynamic_subquery_binding',
                    'python.tests.test_scalar_subquery_declarations','python.tests.test_native_streaming_uat_compression'} <= set(proof['modules'])
            result.update(proof=proof,normalized_offsets=offsets,console_tests_run=526)
        else:
            groups = [list(map(int,g)) for g in re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text,re.M)]
            expected = ([[949,0,0],[0,0,0],[6,0,0],[65,0,0],[44,0,0],[15,0,0]]
                        if row['job_id'] == 117308370753 else
                        [[2904,0,27],[3443,0,0],[91,0,0],[73,0,0],[7,0,0],[67,0,0]])
            assert groups == expected, (row['job_id'],groups)
            result.update(result_groups=groups,total_passed=sum(g[0] for g in groups))
            if row['job_id'] == 117308370762:
                for test in native:
                    matches = re.findall(r'^test (.*::'+re.escape(test['name'])+r') \.\.\. ok$',text,re.M)
                    assert len(matches) == 1,test['name']
                    test['observed_test_path'] = matches[0]
                ignored = re.findall(r'^test (.+) \.\.\. ignored, (.+)$',text,re.M)
                assert len(ignored) == 27
                result.update(source_checked_regressions=native,standalone_provider_groups=groups[1:],ignored_test_reasons=ignored)
        accepted.append(result)
    helper = LOGS/'capture_hosted_job_logs_569.py'
    assert helper.is_file()
    report = dict(schema_version='shardloom.native_worker_drain_primary_hosted_jobs.v1',status='passed_all_six',
        head=HEAD,synthetic=SYNTHETIC,tree=TREE,pending=[],jobs=accepted,source_verification=identity(source_record_path),
        capture=identity(summary_path),run=identity(run_path),capture_helper=identity(helper),
        acceptance_helper=identity(__file__),wheel_binding_sources=binding_sources,
        parser_helper=identity(Path(__file__).parent/'accept_stream_dynamic_subquery_hosted_jobs_corrected_528.py'),
        interpretation={
            'integrity_load_verified_false':'Archive integrity verification does not load a library; the separate isolated-load step validates location, version and native-library/CLI hashes.',
            'binding_method_coverage':'Each wheel records 100 passing tests with zero skips. Individual names are source-discovered; the outer log records aggregate results.',
            'core_skips':'626 tests discovered in 57 modules; console records 526 executed and 14 skips. Native-binding classes are skipped here; installed-wheel lanes execute their 100 methods with zero skips.',
            'native_groups':'The native job passes 2,904 ShardLoom library tests, 3,674 provider library tests and seven file-statistics tests. Its 27 ignored tests are explicitly retained with reasons; 25 retained VarBin and seven new worker-lifetime regression names are checked against immutable source and the complete log.',
            'scope':'The six listed jobs only. Overall checks, review, merge and deployment are separate acceptance records.'})
    destination = OUT/('primary-acceptance-569-'+args.snapshot+'.json')
    destination.open('x').write(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(status=report['status'],jobs=len(accepted),source_checked_regressions=32,new_worker_regressions=7,standalone_provider_tests=3674,
        native_total=6585,native_public_total=1079,wheel_tests_per_lane=100,report=str(destination))))


if __name__ == '__main__':
    main()
