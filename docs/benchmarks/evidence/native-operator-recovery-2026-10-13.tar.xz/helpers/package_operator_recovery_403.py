"""Validate and preserve the finite operator-recovery source and local evidence."""
import hashlib
import io
import json
import lzma
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import time

from freeze_native_release_298 import ROOT, OUT, save, sha, sources

DEST = OUT / 'operator-recovery-docs-403'
STEM = 'native-operator-recovery-2026-10-13'
DOCS = [
    'docs/architecture/native-operator-recovery-2026-10-13.md',
    'docs/architecture/phased-execution-plan.md',
    'docs/architecture/v1-local-resource-safety.md',
    'docs/benchmarks/native-operator-recovery-2026-10-13.md',
    'docs/release/v1-inclusion-scope-matrix.md',
]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def test_counts(path):
    matches = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', path.read_text())
    assert matches
    return dict(groups=len(matches), passed=sum(int(row[0]) for row in matches),
                failed=sum(int(row[1]) for row in matches), ignored=sum(int(row[2]) for row in matches))


def main():
    frozen_path = OUT / 'operator-recovery-source-402-2.json'
    frozen = json.loads(frozen_path.read_text())
    accepted_path = OUT / 'operator-recovery-acceptance-402-2.json'
    accepted = json.loads(accepted_path.read_text())
    assert accepted['status'] == 'passed' and accepted['source_identity_preserved']
    assert sha(frozen_path) == accepted['source_manifest_sha256']
    assert sources() == frozen['source_sha256'] and len(frozen['source_sha256']) == 2240
    assert len(accepted['checks']) == 6
    for check in accepted['checks']:
        path = Path(check['receipt'])
        value = json.loads(path.read_text())
        assert sha(path) == check['sha256']
        assert value['status'] == 'passed' and value['process_group_drained']
        assert sha(path.with_suffix('.log')) == value['log_sha256'] == check['log_sha256']
    counts = {name: test_counts(OUT / f'native-operator-recovery-{name}-402-2.log')
              for name in ['workspace-tests', 'focused-final']}
    assert counts['workspace-tests'] == dict(groups=106, passed=3219, failed=0, ignored=0)
    assert counts['focused-final'] == dict(groups=1, passed=35, failed=0, ignored=0)
    DEST.mkdir()
    checks = []
    commands = [
        ('user-surface-reference', [sys.executable, '-B', 'scripts/check_user_surface_reference.py']),
        ('public-status', [sys.executable, '-B', 'scripts/check_public_status_docs.py', '--output', str(DEST / 'public-status.json')]),
        ('use-case-backlinks', [sys.executable, '-B', 'scripts/check_use_case_backlinks.py']),
        ('contribution-governance', [sys.executable, '-B', 'scripts/check_contribution_governance.py', '--output', str(DEST / 'contribution-governance.json')]),
        ('diff-check', ['git', 'diff', '--check']),
    ]
    for name, command in commands:
        log = DEST / (name + '.log')
        started = time.monotonic()
        with log.open('xb') as stream:
            result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, timeout=180)
        check = dict(name=name, command=command, returncode=result.returncode,
                     seconds=time.monotonic() - started, log=log.name, log_sha256=sha(log))
        checks.append(check)
        print(json.dumps(check), flush=True)
        result.check_returncode()
    documentation = dict(status='passed', checks=checks, files={name: sha(ROOT / name) for name in DOCS},
                         website='No canonical guide, generated page or search asset changes in this unit.')
    save(DEST / 'summary.json', documentation)
    prior = json.loads((OUT / 'stream-composition-398-release.json').read_text())['source_sha256']
    changed = {name: value for name, value in frozen['source_sha256'].items() if prior.get(name) != value}
    assert len(changed) == 11 and not (prior.keys() - frozen['source_sha256'].keys())
    assert all(name.startswith('shardloom-vortex/src/') and name.endswith('.rs') for name in changed)
    payloads = {}

    def add(name, path):
        assert name not in payloads and path.is_file() and not path.is_symlink()
        payloads[name] = path.read_bytes()

    for name in changed:
        add('source-overlay/' + name, ROOT / name)
        assert digest(payloads['source-overlay/' + name]) == changed[name]
    for name in DOCS:
        add('reviewed-docs/' + name, ROOT / name)
    history = []
    for path in sorted(OUT.glob('native-operator-recovery-*.json')):
        value = json.loads(path.read_text())
        assert value['status'] in ('passed', 'failed') and value['process_group_drained']
        assert sha(path.with_suffix('.log')) == value['log_sha256']
        history.append(dict(receipt='receipts/' + path.name, status=value['status'],
                            log_sha256=value['log_sha256'], process_group_drained=True))
        add('receipts/' + path.name, path)
        add('receipts/' + path.with_suffix('.log').name, path.with_suffix('.log'))
    assert len(history) == 12 and sum(row['status'] == 'failed' for row in history) == 2
    for name in ['operator-recovery-source-402.json', 'operator-recovery-source-402-2.json',
                 'operator-recovery-acceptance-402-2.json']:
        add('acceptance/' + name, OUT / name)
    for name in ['run_operator_recovery_acceptance_402.py', 'run_operator_recovery_acceptance_402_first.py',
                 'freeze_native_release_298.py', 'run_guarded.py', Path(__file__).name,
                 'operator_recovery_test_support_402.rs', 'numeric_sort_recovery_tests_402.rs',
                 'weighted_count_recovery_tests_402.rs', 'exact_distinct_recovery_tests_402.rs']:
        add('helpers/' + name, OUT / name)
    add('helpers/release_validation_guard.py', Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'))
    add('helpers/bounded_build_process_resume_20260912.py', Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py'))
    for path in sorted(DEST.iterdir()):
        add('documentation/' + path.name, path)
    manifest = dict(schema_version='shardloom.operator_recovery_archive.v1',
        source_base_commit=frozen['base_head'], source_files=2240, source_overlay=changed,
        source_manifest='acceptance/' + frozen_path.name,
        local_acceptance='acceptance/' + accepted_path.name, counts=counts,
        history=history, documentation='documentation/summary.json',
        members={name: dict(bytes=len(data), sha256=digest(data)) for name, data in sorted(payloads.items())},
        limitations=['Only the final accepted source is fully frozen; initial draft helpers and failed logs are retained as counterevidence.',
                     'Bulk native inputs and test executables are regenerated from committed source; they are not archived.',
                     'Unix process-death and cooperative cancellation proof is not power-loss durability, process-RSS containment or execution resumption.',
                     'Hosted integration is pending. No performance or whole-PERF/CG-gate claim.'])
    manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
    archive = OUT / 'operator-recovery-evidence-403.tar.xz'
    with archive.open('xb') as output:
        with tarfile.open(fileobj=output, mode='w:xz', preset=6) as tar:
            for name, data in sorted(payloads.items()):
                item = tarfile.TarInfo(name)
                item.size = len(data)
                item.mode = 0o644
                tar.addfile(item, io.BytesIO(data))
    observed = set()
    with tarfile.open(archive, 'r:xz') as tar:
        for item in tar:
            assert item.isfile() and item.name in manifest['members'] and item.name not in observed
            data = tar.extractfile(item).read()
            assert data == payloads[item.name]
            observed.add(item.name)
    assert observed == payloads.keys()
    with (OUT / 'operator-recovery-evidence-403.manifest.json').open('xb') as output:
        output.write(manifest_bytes)
    destination = ROOT / 'docs/benchmarks/evidence'
    copied = destination / (STEM + '.tar.xz')
    with archive.open('rb') as source, copied.open('xb') as output:
        shutil.copyfileobj(source, output)
    assert sha(copied) == sha(archive)
    compressed_manifest = destination / (STEM + '.manifest.json.xz')
    with compressed_manifest.open('xb') as output:
        output.write(lzma.compress(manifest_bytes, preset=6))
    assert lzma.decompress(compressed_manifest.read_bytes()) == manifest_bytes
    assert sources() == frozen['source_sha256']
    assert documentation['files'] == {name: sha(ROOT / name) for name in DOCS}
    index = dict(schema_version='shardloom.operator_recovery_evidence.v1',
        status='local_acceptance_complete_hosted_pending',
        archive=dict(path=copied.name, bytes=copied.stat().st_size, sha256=sha(copied),
                     members=len(payloads), uncompressed_bytes=sum(len(data) for data in payloads.values()),
                     all_members_read_back_and_verified=True),
        manifest=dict(path=compressed_manifest.name, bytes=compressed_manifest.stat().st_size,
                      sha256=sha(compressed_manifest), uncompressed_sha256=digest(manifest_bytes)),
        source_identity=dict(base_commit=frozen['base_head'], selected_files=2240,
                             manifest_sha256=sha(frozen_path), changed_files=len(changed),
                             unchanged_before_and_after=True),
        counts=counts, final_local_gates=6, documentation_gates=len(checks),
        failed_historical_attempts=2, real_operator_process_death_cases=4,
        evidence_paths=dict(source_manifest=manifest['source_manifest'], local_acceptance=manifest['local_acceptance'],
                            documentation=manifest['documentation']), limitations=manifest['limitations'])
    save(destination / (STEM + '.json'), index)
    print(json.dumps(index, indent=2), flush=True)


if __name__ == '__main__':
    main()
