"""Serial scoped recovery acceptance and required workspace gates."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sha, sources, save


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', default='402')
    attempt = parser.parse_args().attempt
    assert attempt.replace('-', '').isalnum()
    frozen = dict(schema_version='shardloom.operator_recovery_sources.v1',
        base_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        source_sha256=sources())
    manifest = OUT / f'operator-recovery-source-{attempt}.json'
    save(manifest, frozen)
    checks = [
        ('fmt-check', 180, ['cargo', 'fmt', '--all', '--', '--check']),
        ('release-clippy', 1200, ['cargo', 'clippy', '--offline', '--locked', '-p', 'shardloom-vortex',
            '-p', 'shardloom-cli', '--all-targets', '--features', 'release-user-surfaces', '--', '-D', 'warnings']),
        ('read-clippy', 1200, ['cargo', 'clippy', '--offline', '--locked', '-p', 'shardloom-vortex',
            '-p', 'shardloom-cli', '--all-targets', '--features', 'vortex-local-primitives', '--', '-D', 'warnings']),
        ('workspace-clippy', 1200, ['cargo', 'clippy', '--workspace', '--all-targets', '--', '-D', 'warnings']),
        ('workspace-tests', 1800, ['cargo', 'test', '--workspace', '--all-targets', '--', '--test-threads=2']),
        ('focused-final', 1200, ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-vortex', '--lib',
            '--features', 'vortex-local-primitives,vortex-write,universal-format-io',
            'recovery', '--', '--test-threads=2']),
    ]
    completed = []
    for name, timeout, command in checks:
        assert sources() == frozen['source_sha256'], 'recovery sources changed during acceptance'
        guard_name = 'native-operator-recovery-' + name + '-' + attempt
        subprocess.run([sys.executable, '-B', str(OUT / 'run_guarded.py'), '--name', guard_name,
            '--timeout', str(timeout), '--', *command], cwd=ROOT, check=True)
        receipt = OUT / (guard_name + '.json')
        value = json.loads(receipt.read_text())
        assert value['status'] == 'passed' and value['process_group_drained']
        assert sha(OUT / (guard_name + '.log')) == value['log_sha256']
        completed.append(dict(name=name, receipt=str(receipt), sha256=sha(receipt),
            seconds=value['seconds'], command=command, log_sha256=value['log_sha256']))
    assert sources() == frozen['source_sha256']
    report = dict(schema_version='shardloom.operator_recovery_local_acceptance.v1', status='passed',
        source_manifest=str(manifest), source_manifest_sha256=sha(manifest),
        source_files=len(frozen['source_sha256']), source_identity_preserved=True, checks=completed,
        scope='Caller-controlled cleanup cancellation and actual operator crash/cleanup/fresh-restart proof plus required workspace gates. No performance or process-RSS claim; full-size UAT from the preceding composition unit remains separately bound.')
    save(OUT / f'operator-recovery-acceptance-{attempt}.json', report)
    print(json.dumps(report, indent=2), flush=True)


if __name__ == '__main__':
    main()
