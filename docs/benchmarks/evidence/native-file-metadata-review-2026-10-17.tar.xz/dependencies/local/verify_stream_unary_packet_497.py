"""Independently reopen the complete frozen unary archive and acceptance evidence."""
from __future__ import annotations

import csv
import gzip
import hashlib
import json
import lzma
import math
from pathlib import Path, PurePosixPath
import tarfile

REPO = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
DEST = REPO / 'docs/benchmarks/evidence'
STEM = 'native-stream-unary-2026-10-15'
BASE = 'e859b3a8b9d323587cee9641f5ebacd21e7e799c'
EXPECTED_MEMBERS = 14733
EXPECTED_RAW_BYTES = 90887120
EXPECTED_PUBLIC_CASES = 2601
EXPECTED_PUBLIC_FAMILIES = 27
EXPECTED_FULL43_ROWS = 381
EXPECTED_DECLARED_VALUES_SHA256 = 'd6f5b2fa6f66f69731bfebae38ac6dce6bbbd119f7607feb975676b143f0db4a'
DESIGN_PATH = 'preimplementation/native-stream-unary-design-492.json'
DESIGN_SHA256 = '93e4874ee9470b791da05e218ff72a5f4573da1abd88a96e435a61d784a4dc87'
CONTRACT_PATH = 'preimplementation/native-stream-unary-2026-10-15.md'
CONTRACT_SHA256 = 'b1455ca25c574f909b82eae05c462ae404df9e28909453f9590bbd833197dcdc'
OUTPUT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010/stream-unary-packet-audit-497.json')


class NeedsReasoning(ValueError):
    """Evidence is missing or inconsistent; do not report packet acceptance."""


def need(test: bool, message: str) -> None:
    if not test:
        raise NeedsReasoning(message)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def strict_json(data: bytes | str):
    def pairs(rows):
        value = {}
        for key, item in rows:
            need(key not in value, f'duplicate JSON key: {key}')
            value[key] = item
        return value

    def reject(value):
        raise NeedsReasoning(f'non-finite JSON number: {value}')

    return json.loads(data, object_pairs_hook=pairs, parse_constant=reject)


def safe_member(name: str) -> None:
    need(isinstance(name, str), 'archive path must be a string')
    path = PurePosixPath(name)
    need(isinstance(name, str) and name and '\\' not in name and
         not path.is_absolute() and path.as_posix() == name and
         all(part not in ('', '.', '..') for part in path.parts),
         f'unsafe archive path: {name!r}')


def canonical_hash(value) -> str:
    return digest(json.dumps(value, sort_keys=True, allow_nan=False).encode('utf-8'))


def equivalent(actual, expected) -> bool:
    if type(actual) is not type(expected):
        return False
    if isinstance(actual, dict):
        return actual.keys() == expected.keys() and all(equivalent(actual[k], expected[k]) for k in actual)
    if isinstance(actual, list):
        return len(actual) == len(expected) and all(equivalent(a, b) for a, b in zip(actual, expected))
    if isinstance(actual, float):
        return math.isfinite(actual) and math.isfinite(expected) and math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-12)
    return actual == expected


def report_fields(envelope: dict) -> dict:
    need(envelope.get('status') == 'success', 'complete result must have successful status')
    need(isinstance(envelope.get('fallback'), dict) and
         envelope['fallback'].get('attempted') is False and
         envelope['fallback'].get('allowed') is False and
         envelope['fallback'].get('engine') is None,
         'Full43 envelope contains missing or unsafe fallback evidence')
    rows = envelope.get('fields')
    need(isinstance(rows, list), 'envelope report fields are missing')
    fields = {}
    for row in rows:
        need(isinstance(row, dict) and isinstance(row.get('key'), str),
             'invalid report field')
        need(row['key'] not in fields, f'duplicate report field: {row["key"]}')
        fields[row['key']] = row.get('value')
    for key in ('public_workflow_fallback_attempted',
                'public_workflow_external_engine_invoked'):
        need(fields.get(key) is False or fields.get(key) == 'false',
             f'missing or unsafe no-fallback field: {key}')
    for key, value in fields.items():
        if key.endswith(('fallback_attempted', 'fallback_execution_allowed', 'external_engine_invoked')):
            need(value is False or value == 'false', f'unsafe execution field: {key}')
    return fields


def full_result(envelope: dict, fields: dict) -> list[dict]:
    payload_keys = [key for key in ('result_jsonl', 'result_values_json') if key in fields]
    need(len(payload_keys) == 1 and fields.get('result_payload_complete') in (True, 'true'),
         'Full43 result payload is not marked complete')
    key = payload_keys[0]
    raw = fields[key]
    need(isinstance(raw, str), f'invalid Full43 result payload: {key}')
    if key == 'result_jsonl':
        rows = [strict_json(line) for line in raw.splitlines()]
    else:
        rows = strict_json(raw)
    need(isinstance(rows, list) and all(isinstance(row, dict) for row in rows),
         'Full43 result rows are malformed')
    need(len(rows) == int(fields['output_row_count']), 'Full43 result row count differs from payload')
    return rows


def archived_identity(members: dict[str, bytes], path: str, expected: dict,
                      archive_path: str | None = None) -> None:
    key = archive_path or path
    need(key in members, f'identity target absent from archive: {key}')
    data = members[key]
    need(len(data) == expected.get('bytes') and digest(data) == expected.get('sha256'),
         f'archived identity mismatch: {key}')


def verify_public(members: dict[str, bytes], receipt_log: bytes,
                  expected_case_protocol: dict) -> dict:
    summary = strict_json(members['public/summary.json'])
    need(summary.get('status') == 'passed' and summary.get('compress_logs') is True,
         'public summary must pass and declare compressed logs')
    cases = summary.get('cases')
    need(isinstance(cases, list) and len(cases) == EXPECTED_PUBLIC_CASES,
         'public summary must contain exactly 2,601 cases')
    names = [case.get('name') for case in cases]
    need(len(set(names)) == EXPECTED_PUBLIC_CASES and
         names == expected_case_protocol.get('expected_public_names'),
         'ordered public names differ from the full predeclared case protocol')
    families = summary.get('families')
    need(len(families) == EXPECTED_PUBLIC_FAMILIES and
         families == expected_case_protocol.get('expected_public_families') and
         all(case.get('status') == 'passed' for case in cases),
         'public families or case outcomes differ from the accepted protocol')
    logged = [strict_json(line) for line in receipt_log.decode('utf-8').splitlines()
              if line.startswith('{')]
    need([row for row in logged if 'name' in row] == cases,
         'public process log does not contain the complete ordered case records')

    metadata = summary.get('compressed_json_files')
    need(isinstance(metadata, list), 'public compressed JSON metadata is missing')
    declared, logical, compressed_meta = set(), {}, {}
    for row in metadata:
        need(isinstance(row, dict), 'invalid compressed JSON metadata row')
        rel, raw_rel = row.get('path'), row.get('raw_path')
        need(isinstance(rel, str) and rel.startswith('logs/') and
             rel.endswith('.json.gz') and not rel.endswith('.jsonl.gz'),
             f'wrong compressed JSON path: {rel!r}')
        safe_member(rel)
        need(rel not in declared and raw_rel == rel[:-3] and raw_rel.endswith('.json'),
             f'duplicate or mismatched compressed JSON path: {rel}')
        declared.add(rel)
        packed_key = 'public/' + rel
        need(packed_key in members, f'compressed public JSON log is absent: {packed_key}')
        packed = members[packed_key]
        need(len(packed) == row.get('bytes') and digest(packed) == row.get('sha256'),
             f'compressed public JSON identity mismatch: {rel}')
        try:
            raw = gzip.decompress(packed)
        except (OSError, EOFError) as exc:
            raise NeedsReasoning(f'invalid compressed public JSON {rel}: {exc}') from exc
        need(len(raw) == row.get('raw_bytes') and digest(raw) == row.get('raw_sha256'),
             f'decompressed public JSON identity mismatch: {rel}')
        value = strict_json(raw.decode('utf-8'))
        need(raw_rel not in logical, f'duplicate logical JSON path: {raw_rel}')
        logical[raw_rel] = value
        compressed_meta[raw_rel] = row
    actual_gzip = {name.removeprefix('public/') for name in members
                   if name.startswith('public/logs/') and name.endswith('.json.gz')}
    need(actual_gzip == declared,
         'compressed JSON metadata does not equal archived public logs/*.json.gz')
    for name, data in members.items():
        if name.startswith('public/logs/') and name.endswith('.json'):
            rel = name.removeprefix('public/')
            need(rel not in logical, f'both compressed and raw JSON exist: {rel}')
            logical[rel] = strict_json(data)

    for rel, value in logical.items():
        if rel != 'logs/unary-predeclared-values.json' and Path(rel).name.endswith('-values.json'):
            need(isinstance(value, dict) and value.get('actual') == value.get('expected'),
                 f'public actual/expected JSON values differ: {rel}')
        if Path(rel).name.endswith('-envelope.json'):
            fallback = value.get('fallback', {})
            need(fallback.get('attempted') is False,
                 f'public result envelope attempted fallback: {rel}')
            fields = value.get('fields', [])
            if value.get('status') == 'success':
                report_fields(value)
                need(any(f.get('key') == 'public_workflow_external_engine_invoked' and
                         f.get('value') in (False, 'false') for f in fields),
                     f'public successful envelope lacks no-external-engine evidence: {rel}')
            else:
                field_map = {row['key']: row['value'] for row in fields}
                need(len(field_map) == len(fields) and value.get('diagnostics') and
                     field_map.get('result_payload_complete') != 'true',
                     f'failed public envelope lacks incomplete-result diagnostics: {rel}')

    # Preserve and compare the exact predeclared 39-entry literal matrix.
    raw_rel = 'logs/unary-predeclared-values.json'
    need(raw_rel in logical and isinstance(logical[raw_rel], list) and
         len(logical[raw_rel]) == 39,
         'public unary predeclared-values list must remain exactly 39 elements')
    need(canonical_hash(logical[raw_rel]) == EXPECTED_DECLARED_VALUES_SHA256,
         'public unary predeclared-values list differs from the exact frozen list')
    prior_key = 'predeclared-reference/logs/unary-predeclared-values.json'
    need(prior_key in members and strict_json(members[prior_key]) == logical[raw_rel],
         '39-entry public predeclared-values list differs from archived preimplementation values')
    need(len({(row['kind'], row['shape']) for row in logical[raw_rel]}) == 39,
         'predeclared unary kind/shape combinations are duplicated')

    pressure_files = pressure_rows = 0
    for case in cases:
        artifact = case.get('values') or case.get('complete_rows')
        if not isinstance(artifact, dict) or not str(artifact.get('path', '')).endswith('.jsonl.gz'):
            continue
        rel = artifact['path']
        safe_member(rel)
        key = 'public/' + rel
        need(key in members, f'public pressure JSONL evidence is absent: {key}')
        packed = members[key]
        need(len(packed) == artifact.get('bytes') and digest(packed) == artifact.get('sha256'),
             f'public pressure JSONL compressed identity mismatch: {rel}')
        try:
            decoded = gzip.decompress(packed)
        except (OSError, EOFError) as exc:
            raise NeedsReasoning(f'invalid public pressure JSONL {rel}: {exc}') from exc
        rows = [strict_json(line) for line in decoded.splitlines()]
        expected_count = case.get('rows_verified', case.get('complete_output_rows',
                                                            case.get('complete_rows')))
        expected_digest = case.get('expected_sha256', case.get('all_output_rows_sha256'))
        need(len(rows) == expected_count and digest(decoded) == expected_digest,
             f'public pressure row count/hash mismatch: {case.get("name")}')
        pressure_files += 1
        pressure_rows += len(rows)
    comparisons = [value for rel, value in logical.items()
                   if rel != 'logs/unary-predeclared-values.json' and Path(rel).name.endswith('-values.json')]
    envelope_count = sum(Path(rel).name.endswith('-envelope.json') for rel in logical)
    need(pressure_files == 45 and pressure_rows == 1578741 and len(comparisons) == 2497 and
         sum(len(value['expected']) for value in comparisons) == 29553 and envelope_count == 4029 and
         len(declared) == 6830 and sum(row['bytes'] for row in metadata) == 32355345 and
         sum(row['raw_bytes'] for row in metadata) == 304011169,
         'reopened public evidence counts differ from the complete accepted inspection')
    return {'cases': len(cases), 'families': len(families),
            'compressed_json_files': len(declared), 'value_files': len(comparisons),
            'expected_rows': 29553, 'envelopes': envelope_count,
            'pressure_files': pressure_files, 'pressure_rows': pressure_rows,
            'predeclared_value_entries': 39}


def verify_compressed_tree(members: dict[str, bytes], prefix: str) -> dict:
    """Reopen every compressed JSON log and value comparison in a UAT subtree."""
    summary_key = prefix + '/summary.json'
    need(summary_key in members, f'UAT summary is missing: {summary_key}')
    summary = strict_json(members[summary_key])
    metadata = summary.get('compressed_json_files')
    need(summary.get('compress_logs') is True and isinstance(metadata, list),
         f'{prefix} summary does not inventory compressed JSON logs')
    declared, logical = set(), {}
    for row in metadata:
        rel, raw_rel = row.get('path'), row.get('raw_path')
        need(isinstance(rel, str) and rel.startswith('logs/') and rel.endswith('.json.gz') and
             raw_rel == rel[:-3] and raw_rel.endswith('.json'),
             f'{prefix} has invalid compressed JSON metadata')
        safe_member(rel)
        need(rel not in declared, f'{prefix} repeats compressed JSON path: {rel}')
        declared.add(rel)
        key = prefix + '/' + rel
        need(key in members, f'{prefix} compressed JSON log is absent: {rel}')
        packed = members[key]
        need(len(packed) == row.get('bytes') and digest(packed) == row.get('sha256'),
             f'{prefix} compressed JSON identity mismatch: {rel}')
        try:
            raw = gzip.decompress(packed)
        except (OSError, EOFError) as exc:
            raise NeedsReasoning(f'{prefix} invalid gzip JSON {rel}: {exc}') from exc
        need(len(raw) == row.get('raw_bytes') and digest(raw) == row.get('raw_sha256'),
             f'{prefix} raw JSON size/hash mismatch: {rel}')
        logical[raw_rel] = strict_json(raw.decode('utf-8'))
        need(prefix + '/' + raw_rel not in members, f'{prefix} keeps both raw and compressed JSON')
    actual = {name.removeprefix(prefix + '/') for name in members
              if name.startswith(prefix + '/logs/') and name.endswith('.json.gz')}
    need(actual == declared, f'{prefix} compressed JSON metadata differs from archived logs')
    for rel, value in logical.items():
        if rel == 'logs/unary-predeclared-values.json':
            need(value == strict_json(members['predeclared-reference/logs/unary-predeclared-values.json']) and
                 len(value) == 39, f'{prefix} changes the predeclared unary values')
        elif Path(rel).name.endswith('-values.json'):
            need(isinstance(value, dict) and value.get('actual') == value.get('expected'),
                 f'{prefix} actual/expected values differ: {rel}')
    return {'compressed_json_files': len(declared), 'value_files': sum(
        Path(path).name.endswith('-values.json') and path != 'logs/unary-predeclared-values.json'
        for path in logical), 'status': summary['status'], 'cases': len(summary['cases'])}


def verify_full43(members: dict[str, bytes], full_review: dict,
                  admission: dict) -> dict:
    need(full_review.get('status') == 'passed' and full_review.get('queries') == 43 and
         full_review.get('calls') == 43 and full_review.get('repeats') == 1 and
         full_review.get('complete_rows') == EXPECTED_FULL43_ROWS and
         full_review.get('all_values_schemas_and_clocks_reopened') is True and
         full_review.get('resources_no_fallback_native_certificates') is True and
         full_review.get('native_children_absent') is True and
         full_review.get('original_input_and_sources_unchanged') is True and
         full_review.get('performance_claim_allowed') is False and
         full_review.get('reference_kind') == 'retained_native_regression' and
         full_review.get('no_new_ingest') is True,
         'Full43 primary review does not pass every required acceptance boundary')
    need(admission.get('status') == 'passed' and admission.get('no_new_ingest') is True and
         admission.get('source_resident_before_read') is True and
         admission.get('reference_kind') == 'retained_native_regression',
         'Full43 admission lacks the resident-input/no-ingest/reference boundary')
    ref_identity = admission['reference']
    ref_key = 'full43-inputs/' + Path(ref_identity['path']).name
    need(ref_key in members and len(members[ref_key]) == ref_identity['bytes'] and
         digest(members[ref_key]) == ref_identity['sha256'],
         'archived retained ClickBench reference identity mismatch')
    reference = strict_json(members[ref_key])
    need(len(reference.get('records', [])) == 43 and
         reference.get('reference_kind') == full_review.get('reference_kind'),
         'retained ClickBench reference must contain all 43 query records')
    reference_by_query = {row['query_id']: row for row in reference['records']}
    need(set(reference_by_query) == set(range(1, 44)), 'retained reference query IDs are incomplete')

    query_info = admission['queries']
    query_key = 'full43-inputs/' + Path(query_info['path']).name
    need(query_key in members and len(members[query_key]) == query_info['bytes'] and
         digest(members[query_key]) == query_info['sha256'], 'archived ClickBench query identity mismatch')
    query_text = members[query_key].decode('utf-8')
    statements = [part.strip() for part in '\n'.join(
        line for line in query_text.splitlines() if not line.lstrip().startswith('--')).split(';') if part.strip()]
    need(len(statements) == 43 and reference.get('queries_sha256') == query_info['sha256'],
         'ClickBench query file does not contain the bound 43 statements')

    summary_key = 'full43/summary.json'
    summary = strict_json(members[summary_key])
    need(summary.get('complete') is True and summary.get('runs_completed') == 43 and
         summary.get('runs_passed') == 43 and summary.get('queries_passed') == 43 and
         summary.get('repeats') == 1 and summary.get('full_result_validation') is True and
         summary.get('query_ids') == list(range(1, 44)) and len(summary.get('records', [])) == 43,
         'Full43 summary must contain one complete, passing result for every query')
    records = {row['query']: row for row in summary['records']}
    need(set(records) == set(range(1, 44)), 'Full43 summary query records are incomplete or duplicated')
    envelope_meta = {Path(row['path']).name: row for row in full_review.get('envelopes', [])}
    companion_meta = {Path(row['path']).name: row for row in full_review.get('companions', [])}
    need(len(envelope_meta) == 43 and len(companion_meta) == 86,
         'Full43 review must identify all 43 result envelopes and 86 companion files')
    csv_raw = members['full43/query-timings.csv']
    csv_rows = list(csv.DictReader(csv_raw.decode('utf-8').splitlines()))
    need(len(csv_rows) == 43, 'Full43 timing CSV must contain exactly 43 data rows')
    csv_by_query = {int(row['query']): row for row in csv_rows}
    need(set(csv_by_query) == set(range(1, 44)), 'Full43 timing CSV has missing or duplicate queries')

    complete_rows = 0
    for query in range(1, 44):
        stem = f'q{query:02d}_run1'
        envelope_name = stem + '.stdout.json.gz'
        timing_name = stem + '.timing.json'
        pid_name = stem + '.pid'
        stderr_name = stem + '.stderr.txt'
        need(envelope_name in envelope_meta and timing_name in companion_meta and
             pid_name in companion_meta and 'full43/' + stderr_name in members,
             f'Full43 query {query} evidence files are incomplete')
        for filename, index in ((envelope_name, envelope_meta),
                                (timing_name, companion_meta), (pid_name, companion_meta)):
            data = members['full43/' + filename]
            identity = index[filename]
            need(len(data) == identity['bytes'] and digest(data) == identity['sha256'],
                 f'Full43 archived identity mismatch: {filename}')
        record = records[query]
        need(record.get('run') == 1 and record.get('returncode') == 0 and
             record.get('passed') is True and record.get('validation') == 'complete_values' and
             record.get('engine_timing_reported') is True,
             f'Full43 q{query} record is incomplete or failed')
        need(record.get('query_statement') == statements[query - 1] and
             reference_by_query[query].get('statement') == statements[query - 1],
             f'Full43 q{query} statement differs from the archived predeclared query')
        try:
            envelope_raw = gzip.decompress(members['full43/' + envelope_name])
        except (OSError, EOFError) as exc:
            raise NeedsReasoning(f'invalid Full43 gzip result {envelope_name}: {exc}') from exc
        envelope = strict_json(envelope_raw.decode('utf-8'))
        archives = record.get('completed_log_archives')
        need(isinstance(archives, list) and len(archives) == 1 and
             archives[0].get('gzip_sha256') == digest(members['full43/' + envelope_name]) and
             archives[0].get('gzip_bytes') == len(members['full43/' + envelope_name]) and
             archives[0].get('raw_sha256') == digest(envelope_raw) and
             archives[0].get('raw_bytes') == len(envelope_raw),
             f'Full43 q{query} result log roundtrip differs from its complete summary record')
        fields = report_fields(envelope)
        actual = full_result(envelope, fields)
        expected = reference_by_query[query]['values']
        need(equivalent(actual, expected) and canonical_hash(expected) == reference_by_query[query]['values_sha256'] and
             record.get('result_sha256') == canonical_hash(actual),
             f'Full43 q{query} complete result differs from retained reference')
        complete_rows += len(actual)
        schema_format = fields.get('result_schema_format')
        schema_json = fields.get('result_schema_json')
        need(isinstance(schema_format, str) and schema_format and isinstance(schema_json, str),
             f'Full43 q{query} result schema is missing')
        schema = strict_json(schema_json)
        need(isinstance(schema, dict) and schema, f'Full43 q{query} result schema is invalid')
        schema_identity = admission['schema_sources'][query - 1]
        baseline_key = 'full43-baseline-schemas/' + Path(schema_identity['path']).name
        archived_identity(members, schema_identity['path'], schema_identity, baseline_key)
        baseline_raw = members[baseline_key]
        if baseline_key.endswith('.gz'):
            baseline_raw = gzip.decompress(baseline_raw)
        baseline_fields = report_fields(strict_json(baseline_raw))
        need(schema_format == baseline_fields['result_schema_format'] and
             schema == strict_json(baseline_fields['result_schema_json']),
             f'Full43 q{query} schema differs from the predeclared complete schema')
        need(fields['execution_resource_declared_memory_bytes'] == str(24 * 1024**3) and
             fields['execution_resource_declared_max_parallelism'] == '12' and
             fields['execution_resource_whole_process_memory_limit_enforced'] == 'false' and
             any(c['kind'] == 'native_io_certificate' and c['status'] == 'available'
                 for c in envelope['certificates']), f'Full43 q{query} resource/native evidence differs')
        struct = schema.get('Struct')
        if actual and isinstance(struct, list) and struct and isinstance(struct[0], dict):
            schema_names = struct[0].get('names')
            if isinstance(schema_names, list):
                need(all(list(row) == schema_names for row in actual),
                     f'Full43 q{query} result fields differ from its declared schema')

        timing = strict_json(members['full43/' + timing_name])
        csv_row = csv_by_query[query]
        need(timing.get('returncode') == 0 and
             timing.get('seconds') == record.get('process_wall_seconds') and
             timing.get('user_cpu_seconds') == record.get('user_cpu_seconds') and
             timing.get('system_cpu_seconds') == record.get('system_cpu_seconds') and
             float(csv_row['process_wall_seconds']) == record.get('process_wall_seconds') and
             float(csv_row['engine_execution_seconds']) == record.get('engine_execution_seconds') and
             float(csv_row['result_serialization_seconds']) == record.get('result_serialization_seconds'),
             f'Full43 q{query} timing clocks differ across result, companion, and CSV')
        need(int(fields['native_query_execution_nanos']) == round(record['engine_execution_seconds'] * 1e9) and
             int(fields['native_result_serialization_nanos']) == round(record['result_serialization_seconds'] * 1e9),
             f'Full43 q{query} native clock fields differ from complete timing record')
        need(fields['native_query_timing_reported'] == 'true' and
             fields['native_query_timing_clock'] == 'monotonic_wall_not_cpu' and
             fields['native_query_timing_boundary'] ==
             'prepared_native_execution_including_io_generation_validation_and_certification_excluding_result_serialization',
             f'Full43 q{query} native clock boundaries differ')
        need(record['process_other_seconds'] == max(0.0, record['process_wall_seconds'] -
             record['engine_execution_seconds'] - record['result_serialization_seconds']) and
             timing['peak_rss_bytes'] == record['native_peak_rss_bytes'],
             f'Full43 q{query} process remainder or RSS differs')
        for key, value in csv_row.items():
            original = record.get(key, '')
            if isinstance(original, (int, float)) and not isinstance(original, bool):
                need(float(value) == original, f'Full43 q{query} CSV differs for {key}')
            else:
                need(value == str(original), f'Full43 q{query} CSV differs for {key}')
    need(complete_rows == EXPECTED_FULL43_ROWS == full_review.get('complete_rows'),
         f'Full43 complete result rows differ: {complete_rows}')
    need(summary.get('timing_totals', {}).get('raw_calls') == 43 and
         summary.get('timing_totals', {}).get('calls_with_engine_timing') == 43,
         'Full43 timing summary must cover all 43 raw calls')
    need(summary['timing_totals'] == full_review['timing_totals'], 'Full43 timing totals differ')
    for key, value in summary['timing_totals']['totals'].items():
        need(value == sum(row[key] for row in summary['records']), f'Full43 raw timing sum differs: {key}')
    return {'queries': 43, 'calls': 43, 'repeats': 1,
            'complete_rows': complete_rows, 'envelopes': len(envelope_meta),
            'companions': len(companion_meta), 'timing_csv_rows': len(csv_rows)}


def main() -> dict:
    need(not OUTPUT.exists(), 'audit output already exists; preserve the earlier result')
    index_path = DEST / (STEM + '.json')
    archive_path = DEST / (STEM + '.tar.xz')
    compressed_manifest_path = DEST / (STEM + '.manifest.json.xz')
    index = strict_json(index_path.read_bytes())
    need(index.get('schema_version') == 'shardloom.native_stream_unary_evidence.v1' and
         index.get('status') == 'packaged_local_pending_acceptance_decision' and
         index.get('publication_attempted') is False,
         'portable evidence index has unexpected status or schema')
    for label, path in (('archive', archive_path), ('manifest', compressed_manifest_path)):
        row = index.get(label, {})
        expected_name = path.name
        need(row.get('file') == expected_name and path.is_file() and not path.is_symlink(),
             f'indexed {label} file is missing or unsafe')
        data = path.read_bytes()
        need(len(data) == row.get('bytes') and digest(data) == row.get('sha256'),
             f'indexed {label} byte count/hash mismatch')
    need(index.get('base_commit') == BASE and index.get('member_count') == EXPECTED_MEMBERS and
         index.get('raw_bytes') == EXPECTED_RAW_BYTES and index.get('all_members_reopened') is True,
         'portable index count/base/member reopening claims differ from fixed acceptance')
    compressed_manifest = compressed_manifest_path.read_bytes()
    try:
        manifest_raw = lzma.decompress(compressed_manifest)
    except lzma.LZMAError as exc:
        raise NeedsReasoning(f'invalid compressed evidence manifest: {exc}') from exc
    need(digest(manifest_raw) == index['manifest'].get('raw_sha256'),
         'raw evidence manifest hash differs from index')
    manifest = strict_json(manifest_raw)
    need(manifest.get('status') == 'passed_local_evidence_packaged' and
         manifest.get('base_commit') == BASE and manifest.get('all_members_reopened') is True and
         manifest.get('member_count') == EXPECTED_MEMBERS and
         manifest.get('raw_bytes') == EXPECTED_RAW_BYTES,
         'portable evidence manifest count/base/reopen claims mismatch')
    need(index.get('acceptance') == manifest.get('acceptance') and
         index.get('source_overlay') == manifest.get('source_overlay'),
         'index and manifest acceptance or source-overlay records differ')
    acceptance = manifest['acceptance']
    fixed_counts = {'workspace_tests': 3219, 'workspace_ignored': 0,
        'prior_native_tests': 4241, 'native_tests': 4249, 'native_ignored': 29,
        'native_manual_ignored': 26, 'native_platform_ignored': 3,
        'new_native_tests': 8, 'direct_methods': 91, 'direct_skips': 0,
        'new_direct_methods': 4, 'new_direct_subcases': 468,
        'harness_methods': 5, 'harness_skips': 0, 'focused_public_cases': 1564,
        'focused_new_public_cases': 1480, 'public_cases': EXPECTED_PUBLIC_CASES,
        'public_families': EXPECTED_PUBLIC_FAMILIES, 'full43_queries': 43,
        'full43_calls': 43, 'full43_repeats': 1, 'baseline_controls': 18,
        'baseline_streaming_refusals': 9, 'baseline_resident_controls': 9}
    for key, value in fixed_counts.items():
        need(acceptance.get(key) == value, f'fixed acceptance count mismatch: {key}')
    need(index.get('source_files') == 2283 and manifest.get('source_files') == 2283 and
         manifest.get('build_source_files') == 2282 and
         index.get('accepted_verification_source') == manifest.get('accepted_verification_source') and
         index.get('previous_verification_source') == manifest.get('previous_verification_source'),
         'build and accepted verification source counts/identities are not distinguished')

    rows = manifest.get('members')
    need(isinstance(rows, list) and len(rows) == EXPECTED_MEMBERS,
         'member manifest does not declare exactly 14,733 files')
    expected = {}
    for row in rows:
        name = row.get('archive_path')
        safe_member(name)
        need(name not in expected and type(row.get('bytes')) is int and row['bytes'] >= 0 and
             len(row.get('sha256', '')) == 64,
             f'duplicate or malformed member manifest entry: {name}')
        expected[name] = row
    member_bytes = {}
    seen, total = set(), 0
    try:
        with tarfile.open(archive_path, mode='r|xz') as archive:
            for entry in archive:
                safe_member(entry.name)
                need(entry.isfile() and entry.name in expected and entry.name not in seen,
                     f'archive member is non-regular, unexpected, or duplicate: {entry.name}')
                row = expected[entry.name]
                need(entry.size == row['bytes'], f'tar/member manifest size mismatch: {entry.name}')
                stream = archive.extractfile(entry)
                need(stream is not None, f'cannot read archive member: {entry.name}')
                data = stream.read()
                need(len(data) == entry.size and digest(data) == row['sha256'],
                     f'archive member hash/size mismatch: {entry.name}')
                seen.add(entry.name)
                total += len(data)
                member_bytes[entry.name] = data
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise NeedsReasoning(f'cannot reopen evidence archive: {exc}') from exc
    need(seen == set(expected) and total == EXPECTED_RAW_BYTES,
         'archive member set or total uncompressed bytes differ from manifest')

    # The preimplementation design and contract are pinned to their archived bytes,
    # so a later edited repository document cannot redefine the original gate.
    for name, sha in ((DESIGN_PATH, DESIGN_SHA256), (CONTRACT_PATH, CONTRACT_SHA256)):
        need(name in member_bytes and digest(member_bytes[name]) == sha,
             f'archived original design/contract identity mismatch: {name}')

    source_build = strict_json(member_bytes['manifests/native-release-source-streamunary494.json'])
    artifact_build = strict_json(member_bytes['manifests/native-release-artifacts-streamunary494.json'])
    archived_identity(member_bytes, manifest['source_manifest']['path'],
                      manifest['source_manifest'], 'manifests/native-release-source-streamunary494.json')
    archived_identity(member_bytes, manifest['artifact_manifest']['path'],
                      manifest['artifact_manifest'], 'manifests/native-release-artifacts-streamunary494.json')
    need(artifact_build.get('source_sha256') == source_build.get('source_sha256') and
         source_build.get('head') == BASE and artifact_build.get('head') == BASE,
         'frozen build source and artifact manifests differ from the declared base')
    accepted_identity = manifest['accepted_verification_source']
    previous_identity = manifest['previous_verification_source']
    need(accepted_identity['path'].endswith('stream-unary-verification-source-496.json') and
         previous_identity['path'].endswith('stream-unary-verification-source-495.json'),
         'accepted and prior verification source identities have unexpected paths')
    accepted_name = 'manifests/stream-unary-verification-source-496.json'
    previous_name = 'manifests/stream-unary-verification-source-495.json'
    archived_identity(member_bytes, accepted_identity['path'], accepted_identity, accepted_name)
    archived_identity(member_bytes, previous_identity['path'], previous_identity, previous_name)
    accepted = strict_json(member_bytes[accepted_name])
    previous = strict_json(member_bytes[previous_name])
    need(len(source_build.get('source_sha256', {})) == 2282 and
         len(accepted.get('source_sha256', {})) == 2283 and
         len(previous.get('source_sha256', {})) == 2283 and
         accepted.get('status') == 'frozen_for_verification' and
         accepted.get('previous_source', {}).get('sha256') == previous_identity['sha256'],
         'build source, previous verification source, and current accepted source are not distinguished')
    need(accepted.get('build_source', {}).get('sha256') == manifest['source_manifest']['sha256'] and
         accepted.get('artifacts', {}).get('sha256') == manifest['artifact_manifest']['sha256'],
         'accepted verification source is not bound to archived build source/artifact manifests')
    changed = ['python/tests/test_native_unary_binding.py',
               'scripts/native_streaming_unary_composition_cases.py',
               'scripts/run_native_streaming_input_uat.py']
    added = ['python/tests/test_native_streaming_uat_compression.py']
    old_map, accepted_map, previous_map = (source_build['source_sha256'],
                                            accepted['source_sha256'],
                                            previous['source_sha256'])
    need(sorted(name for name in old_map if accepted_map.get(name) != old_map[name]) == changed and
         sorted(set(accepted_map) - set(old_map)) == added and
         sorted(name for name in accepted_map if previous_map.get(name) != accepted_map[name]) ==
         ['scripts/native_streaming_unary_composition_cases.py'],
         'verification source transitions differ from the explicit accepted source history')
    overlay = manifest.get('source_overlay', [])
    need(set(changed + added).issubset(overlay),
         'accepted changed and added sources are not all in the archived source overlay')
    for rel in overlay:
        archive_key = 'source-overlay/' + rel
        need(rel in accepted_map and archive_key in member_bytes and
             digest(member_bytes[archive_key]) == accepted_map[rel],
             f'accepted source overlay hash mismatch: {rel}')
    # Reopen the complete current selected source map, including accepted overlays.
    for rel, sha in accepted_map.items():
        path = REPO / rel
        need(path.is_file() and not path.is_symlink() and digest(path.read_bytes()) == sha,
             f'base source differs from the accepted source map: {rel}')

    public_summary = strict_json(member_bytes['public/summary.json'])
    for source_path, sha in public_summary.get('sources', {}).items():
        basename = Path(source_path).name
        if basename.endswith(('.py', '.json')):
            snapshot_key = 'public/logs/' + basename
            need(snapshot_key in member_bytes and digest(member_bytes[snapshot_key]) == sha,
                 f'public archived source snapshot differs: {snapshot_key}')

    for name, identity in manifest.get('final_receipts', {}).items():
        key = 'receipts/' + Path(identity['path']).name
        archived_identity(member_bytes, identity['path'], identity, key)
        receipt = strict_json(member_bytes[key])
        need(receipt.get('status') == 'passed' and receipt.get('returncode') == 0 and
             receipt.get('head') == BASE and receipt.get('process_group_drained') is True and
             receipt.get('direct_child_reaped') is True and receipt.get('timed_out') is False and
             receipt.get('group_absence_unproved_at_cleanup') is False,
             f'final receipt is incomplete: {name}')
        log_key = str(PurePosixPath(key).with_suffix('.log'))
        need(digest(member_bytes[log_key]) == receipt['log_sha256'], f'final receipt log differs: {name}')
    public_protocol = strict_json(member_bytes['receipts/stream-unary-public-case-protocol-494.json'])
    public_receipt = strict_json(member_bytes['receipts/stream-unary-public-496.json'])
    need(public_receipt.get('status') == 'passed' and public_receipt.get('returncode') == 0 and
         public_receipt.get('process_group_drained') is True and
         public_receipt.get('direct_child_reaped') is True and
         public_receipt.get('timed_out') is False and
         public_receipt.get('group_absence_unproved_at_cleanup') is False,
         'public supervisor receipt lacks clean process completion evidence')
    public_log = member_bytes['receipts/stream-unary-public-496.log']
    need(digest(public_log) == public_receipt.get('log_sha256'),
         'public supervisor log hash differs from receipt')
    public_counts = verify_public(member_bytes, public_log, public_protocol)
    focused_counts = verify_compressed_tree(member_bytes, 'focused-public')
    failed_focused_counts = verify_compressed_tree(member_bytes, 'failed-focused-495')
    need(focused_counts['status'] == 'passed' and focused_counts['cases'] == 1564 and
         failed_focused_counts['status'] == 'failed' and failed_focused_counts['cases'] == 1080,
         'focused pass or retained failed-focused coverage differs')
    failed_cases = strict_json(member_bytes['failed-focused-495/summary.json'])['cases']
    need(sum(row['status'] == 'passed' for row in failed_cases) == 1079 and
         sum(row['status'] == 'failed' for row in failed_cases) == 1,
         'failed focused run must preserve 1,079 passes and its single original failure')

    full_review = strict_json(member_bytes['receipts/stream-unary-full43-review-496.json'])
    admission = strict_json(member_bytes['receipts/stream-unary-full43-admission-496.json'])
    full_receipt = strict_json(member_bytes['receipts/stream-unary-full43-496.json'])
    archived_identity(member_bytes, full_review['summary']['path'], full_review['summary'],
                      'full43/summary.json')
    archived_identity(member_bytes, full_review['timing_csv']['path'], full_review['timing_csv'],
                      'full43/query-timings.csv')
    archived_identity(member_bytes, full_review['receipt']['path'], full_review['receipt'],
                      'receipts/stream-unary-full43-496.json')
    archived_identity(member_bytes, full_review['admission']['path'], full_review['admission'],
                      'receipts/stream-unary-full43-admission-496.json')
    need(full_receipt.get('status') == 'passed' and full_receipt.get('returncode') == 0 and
         full_receipt.get('process_group_drained') is True and
         full_receipt.get('direct_child_reaped') is True and
         digest(member_bytes['receipts/stream-unary-full43-496.log']) == full_receipt.get('log_sha256'),
         'Full43 supervisor receipt/log does not prove clean successful completion')
    full_counts = verify_full43(member_bytes, full_review, admission)
    need(index.get('acceptance', {}).get('full43_calls') == full_counts['calls'] and
         index.get('acceptance', {}).get('full43_queries') == full_counts['queries'],
         'portable index Full43 counts differ from reopened result evidence')
    need(digest(index_path.read_bytes()) == digest(json.dumps(index, indent=2, sort_keys=True).encode() + b'\n'),
         'index changed during inspection or has unexpected encoding')
    for rel, sha in accepted_map.items():
        need(digest((REPO / rel).read_bytes()) == sha, f'source changed during audit: {rel}')
    result = {'status': 'passed',
            'archive_members': len(seen), 'raw_bytes': total,
            'accepted_source_files': len(accepted_map), 'build_source_files': len(old_map),
            'public': public_counts, 'focused_public': focused_counts,
            'failed_focused_495': failed_focused_counts, 'full43': full_counts,
            'preimplementation_contracts': [DESIGN_PATH, CONTRACT_PATH],
            'performance_claim_allowed': False, 'compiled_runtime_changed': False,
            'helper': {'path': str(Path(__file__).resolve()), 'bytes': Path(__file__).stat().st_size,
                       'sha256': digest(Path(__file__).read_bytes())},
            'index': {'path': str(index_path), 'bytes': index_path.stat().st_size,
                      'sha256': digest(index_path.read_bytes())},
            'archive': index['archive'], 'manifest': index['manifest'],
            'worker_draft': {'path': str(Path(__file__).with_name('draft_verify_stream_unary_packet_497.py')),
                             'sha256': digest(Path(__file__).with_name('draft_verify_stream_unary_packet_497.py').read_bytes())},
            'native_engine_executions': 0, 'hosted_acceptance': False}
    with OUTPUT.open('x') as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True) + '\n')
    return result


if __name__ == '__main__':
    print(json.dumps(main(), sort_keys=True))

