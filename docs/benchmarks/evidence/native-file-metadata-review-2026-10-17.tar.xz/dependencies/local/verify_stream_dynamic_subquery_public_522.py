"""Independently reopen the compressed, complete subquery public acceptance evidence."""
from __future__ import annotations

import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import sys
import zlib

O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
REPO = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
PUBLIC = O / 'stream-dynamic-subquery-public-521'
RUNTIME_PATH = O / 'stream-dynamic-subquery-public-acceptance-521.json'
RECEIPT_PATH = O / 'stream-dynamic-subquery-public-521.json'
BASELINE_PATH = O / 'stream-dynamic-subquery-acceptance-protocol-521.json'
OUTPUT = O / 'stream-dynamic-subquery-public-inspection-report-522.json'

sys.path.insert(0, str(O))
sys.path.insert(0, str(REPO / 'scripts'))
from run_stream_dynamic_subquery_acceptance_521 import (  # noqa: E402
    SOURCE as ACCEPTED_SOURCE, identity, load, unchanged,
)
from native_workflow_protocol import report_fields, strict_json  # noqa: E402


def need(test: bool, message: str) -> None:
    if not test:
        raise AssertionError(message)


def identity_bytes(path: Path, data: bytes) -> dict:
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def read_regular(path: Path) -> tuple[bytes, dict]:
    path = Path(path)
    need(path.is_file() and not path.is_symlink(), f'expected regular non-symlink file: {path}')
    before = path.stat()
    need(stat.S_ISREG(before.st_mode), f'expected regular file: {path}')
    data = path.read_bytes()
    after = path.stat()
    need((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
         (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
         f'file changed while reading: {path}')
    need(len(data) == after.st_size, f'file size changed while reading: {path}')
    return data, identity_bytes(path, data)


def bound(path: Path) -> dict:
    return read_regular(path)[1]


def safe_public_relative(relative: str, *, allow_missing_leaf: bool = False) -> Path:
    need(isinstance(relative, str) and relative and '\\' not in relative,
         f'unsafe public evidence path: {relative!r}')
    pure = PurePosixPath(relative)
    need(not pure.is_absolute() and pure.as_posix() == relative and
         all(part not in ('', '.', '..') for part in pure.parts),
         f'unsafe public evidence path: {relative!r}')
    need(len(pure.parts) >= 2 and pure.parts[0] in ('logs', 'outputs'),
         f'public evidence path must be under logs/ or outputs/: {relative!r}')
    root = PUBLIC
    need(root.is_dir() and not root.is_symlink(), f'public evidence root is missing or a symlink: {root}')
    root_resolved = root.resolve(strict=True)
    candidate = root
    for index, part in enumerate(pure.parts):
        candidate = candidate / part
        need(not candidate.is_symlink(), f'symlink in public evidence path: {candidate}')
        if allow_missing_leaf and index == len(pure.parts) - 1:
            need(not candidate.exists(), f'compressed source raw path must be absent: {candidate}')
            break
        need(candidate.exists(), f'public evidence path is missing: {candidate}')
    if not allow_missing_leaf:
        resolved = candidate.resolve(strict=True)
        need(resolved.is_relative_to(root_resolved), f'public evidence path escaped its root: {relative}')
    else:
        parent = candidate.parent.resolve(strict=True)
        need(parent.is_relative_to(root_resolved), f'public evidence path escaped its root: {relative}')
    return candidate


def main() -> None:
    runtime = strict_json(RUNTIME_PATH.read_text())
    need(runtime.get('status') == 'passed', 'public runtime receipt must pass before public review')
    unchanged()
    manifest = load()
    manifest_path = Path(runtime['manifest']['path'])
    manifest_identity = identity(manifest_path)
    need(manifest_identity == runtime['manifest'],
         'runtime artifact manifest hash mismatch')
    need(manifest == strict_json(manifest_path.read_text()),
         'acceptance source loader returned a different frozen artifact manifest')
    accepted_identity = identity(ACCEPTED_SOURCE)
    need(runtime.get('source') == accepted_identity,
         'runtime receipt is not bound to the accepted current source snapshot')
    need(identity(Path(manifest['cli']['path']))['sha256'] == manifest['cli']['sha256'],
         'frozen CLI binary hash mismatch')

    summary_path = PUBLIC / 'summary.json'
    summary_data, summary_identity = read_regular(summary_path)
    need(summary_identity == runtime['summary'],
         'public summary hash differs from the runtime receipt')
    summary = strict_json(summary_data.decode('utf-8'))
    need(summary.get('compress_logs') is True,
         'the public summary must declare lossless compressed JSON logs')
    baseline = strict_json(BASELINE_PATH.read_text())
    cases = summary['cases']
    names = [case['name'] for case in cases]
    need(len(names) == len(set(names)) == 4827,
         'public case names must be unique and total exactly 4,827')
    need(names == baseline['expected_public_names'],
         'ordered public case names differ from the frozen 521 case protocol')
    need(summary['families'] == baseline['expected_public_families'] and
         len(summary['families']) == 36,
         'public families differ from the frozen 521 case protocol')
    need(summary.get('status') == 'passed' and
         all(case.get('status') == 'passed' for case in cases),
         'every public case must pass')

    receipt_data, receipt_identity = read_regular(RECEIPT_PATH)
    receipt = strict_json(receipt_data.decode('utf-8'))
    need(receipt.get('status') == 'passed' and receipt.get('returncode') == 0 and
         receipt.get('process_group_drained') is True and receipt.get('direct_child_reaped') is True and
         receipt.get('timed_out') is False and receipt.get('group_absence_unproved_at_cleanup') is False,
         'public supervisor receipt must prove success and child cleanup')
    log_path = RECEIPT_PATH.with_suffix('.log')
    log_data, log_identity = read_regular(log_path)
    need(log_identity['sha256'] == receipt.get('log_sha256'),
         'public supervisor log hash differs from its receipt')
    logged = [strict_json(line) for line in log_data.decode('utf-8').splitlines()
              if line.startswith('{')]
    need([row for row in logged if 'name' in row] == cases,
         'supervisor case records differ from the complete summary case list')

    # The harness deletes each raw JSON log only after a byte-for-byte gzip readback.
    # Independently bind the metadata set to every stored logs/*.json.gz file and
    # reconstruct each original raw logical JSON identity without writing it.
    metadata = summary.get('compressed_json_files')
    need(isinstance(metadata, list), 'compressed_json_files must be a list')
    declared_paths, raw_paths, decoded_json = set(), set(), {}
    compressed_records, compressed_bytes, raw_bytes = [], 0, 0
    for record in metadata:
        need(isinstance(record, dict), 'compressed JSON metadata entries must be objects')
        compressed_rel = record.get('path')
        raw_rel = record.get('raw_path')
        need(isinstance(compressed_rel, str) and compressed_rel.startswith('logs/') and
             compressed_rel.endswith('.json.gz') and not compressed_rel.endswith('.jsonl.gz'),
             f'compressed JSON path has an unexpected suffix or root: {compressed_rel!r}')
        need(compressed_rel not in declared_paths,
             f'duplicate compressed JSON path in metadata: {compressed_rel}')
        declared_paths.add(compressed_rel)
        compressed_path = safe_public_relative(compressed_rel)
        need(compressed_path.parent == PUBLIC / 'logs',
             f'compressed JSON files must be direct logs children: {compressed_rel}')
        need(raw_rel == compressed_rel[:-3] and raw_rel.endswith('.json') and
             not raw_rel.endswith('.jsonl'),
             f'raw JSON path does not correspond to compressed JSON: {raw_rel!r}')
        need(raw_rel not in raw_paths, f'duplicate raw logical JSON path: {raw_rel}')
        raw_paths.add(raw_rel)
        raw_path = safe_public_relative(raw_rel, allow_missing_leaf=True)
        packed, stored_identity = read_regular(compressed_path)
        need(len(packed) == record.get('bytes') and stored_identity['sha256'] == record.get('sha256'),
             f'compressed JSON stored bytes/hash mismatch: {compressed_rel}')
        try:
            raw = gzip.decompress(packed)
        except (OSError, EOFError, zlib.error) as error:
            raise AssertionError(f'invalid gzip JSON evidence: {compressed_rel}: {error}') from error
        raw_digest = hashlib.sha256(raw).hexdigest()
        need(len(raw) == record.get('raw_bytes') and raw_digest == record.get('raw_sha256'),
             f'compressed JSON decoded bytes/hash mismatch: {compressed_rel}')
        try:
            decoded = strict_json(raw.decode('utf-8'))
        except (UnicodeDecodeError, ValueError) as error:
            raise AssertionError(f'decoded compressed JSON is invalid: {compressed_rel}: {error}') from error
        logical_identity = dict(path=raw_rel, bytes=len(raw), sha256=raw_digest)
        decoded_json[raw_rel] = decoded
        compressed_records.append(dict(path=compressed_rel, raw_path=raw_rel,
            stored_bytes=len(packed), stored_sha256=stored_identity['sha256'],
            raw_bytes=len(raw), raw_sha256=raw_digest,
            logical_identity=logical_identity))
        compressed_bytes += len(packed)
        raw_bytes += len(raw)

    actual_compressed = set()
    logs_dir = PUBLIC / 'logs'
    need(logs_dir.is_dir() and not logs_dir.is_symlink(), 'public logs directory is missing or a symlink')
    for path in logs_dir.glob('*.json.gz'):
        need(not path.is_symlink() and path.is_file(), f'unsafe compressed JSON log: {path}')
        actual_compressed.add(path.relative_to(PUBLIC).as_posix())
    need(actual_compressed == declared_paths,
         'compressed_json_files metadata must equal all actual logs/*.json.gz files')

    # Add untouched raw JSON logs and source snapshots to the same logical view.
    for path in sorted(logs_dir.glob('*.json')):
        need(not path.is_symlink() and path.is_file(), f'unsafe raw JSON log: {path}')
        relative = path.relative_to(PUBLIC).as_posix()
        need(relative not in decoded_json, f'raw and compressed JSON both exist for {relative}')
        data, _ = read_regular(path)
        decoded_json[relative] = strict_json(data.decode('utf-8'))

    for source_path, digest in summary['sources'].items():
        need(identity(Path(source_path))['sha256'] == digest,
             f'public run source snapshot changed: {source_path}')
        if Path(source_path).suffix in ('.py', '.json'):
            snapshot_path = logs_dir / Path(source_path).name
            need(identity(snapshot_path)['sha256'] == digest,
                 f'public run raw source snapshot differs: {snapshot_path}')

    records_by_raw = {item['raw_path']: item for item in compressed_records}
    references = {}
    def visit(value):
        if isinstance(value, dict):
            relative = value.get('path')
            if isinstance(relative, str) and relative.startswith(('logs/', 'outputs/')):
                if relative in decoded_json:
                    # For compressed logical JSON, use the original raw identity from its
                    # metadata; source snapshots use their physical identity above.
                    compressed = records_by_raw.get(relative)
                    if compressed is not None:
                        actual_identity = compressed['logical_identity']
                    else:
                        actual_identity = bound(PUBLIC / relative)
                else:
                    path = safe_public_relative(relative)
                    actual_identity = bound(path)
                for key, expected_key in (('bytes', 'bytes'), ('sha256', 'sha256')):
                    if key in value:
                        need(value[key] == actual_identity[expected_key],
                             f'case artifact identity differs: {relative}')
                if relative in references:
                    need(references[relative] == actual_identity,
                         f'case artifact is referenced with inconsistent identities: {relative}')
                references[relative] = actual_identity
            for child in value.values():
                visit(child)
        elif isinstance(value, list):
            for child in value:
                visit(child)
    visit(cases)

    comparisons, envelopes, predeclared_values = [], [], []
    for relative, payload in sorted(decoded_json.items()):
        filename = Path(relative).name
        if filename == 'unary-predeclared-values.json':
            original = O / 'stream-unary-candidate-declarations-493b/logs/unary-predeclared-values.json'
            original_data, original_identity = read_regular(original)
            need(isinstance(payload, list) and len(payload) == 39 and
                 payload == strict_json(original_data.decode('utf-8')),
                 'complete unary predeclared values changed from the pre-execution fixture')
            need(len({(item['kind'], item['shape']) for item in payload}) == 39,
                 'unary predeclared kind/shape combinations are incomplete or repeated')
            predeclared_values.append(dict(logical_path=relative, original=original_identity,
                                           complete_cases=len(payload),
                                           storage_path=records_by_raw[relative]['path']))
        elif filename == 'subquery-predeclared-results.json':
            original = O / 'stream-subquery-candidate-declarations-509/subqueries/logs/subquery-predeclared-results.json'
            original_data, original_identity = read_regular(original)
            need(isinstance(payload, dict) and len(payload) == 27 and
                 payload == strict_json(original_data.decode('utf-8')),
                 'subquery oracle differs from the pre-execution declarations')
            need(all(set(shapes) == {'mixed', 'empty-outer', 'empty-inner', 'all-null'}
                     for shapes in payload.values()),
                 'subquery oracle does not contain all declared shapes')
            predeclared_values.append(dict(logical_path=relative, original=original_identity,
                                           complete_cases=sum(len(shapes) for shapes in payload.values()),
                                           storage_path=records_by_raw[relative]['path']))
        elif filename == 'dynamic-subquery-predeclared-results.json':
            original = O / 'stream-dynamic-subquery-candidate-declarations-521/dynamic-subqueries/logs/dynamic-subquery-predeclared-results.json'
            original_data, original_identity = read_regular(original)
            need(isinstance(payload, dict) and len(payload) == 18 and
                 payload == strict_json(original_data.decode('utf-8')),
                 'dynamic subquery values differ from the frozen pre-execution declarations')
            need(all(set(shapes) == {'mixed', 'empty-outer', 'empty-inner', 'all-null'}
                     for shapes in payload.values()), 'dynamic predicate shape inventory is incomplete')
            predeclared_values.append(dict(logical_path=relative, original=original_identity,
                                           complete_cases=sum(len(shapes) for shapes in payload.values()),
                                           storage_path=records_by_raw[relative]['path']))
        elif filename.endswith('-values.json'):
            need(payload['actual'] == payload['expected'],
                 f'public JSON value reference mismatch: {relative}')
            compressed = records_by_raw.get(relative)
            logical = compressed['logical_identity'] if compressed else bound(PUBLIC / relative)
            comparisons.append(dict(**logical, rows=len(payload['actual']),
                                    storage_path=compressed['path'] if compressed else relative))
        if filename.endswith('-envelope.json'):
            need(payload['fallback']['attempted'] is False,
                 f'external fallback was attempted in envelope: {relative}')
            if payload['status'] == 'success':
                fields = report_fields(payload)
                need(fields['public_workflow_external_engine_invoked'] == 'false',
                     f'external engine was invoked in envelope: {relative}')
            else:
                entries = payload['fields']
                fields = {entry['key']: entry['value'] for entry in entries}
                need(len(fields) == len(entries) and payload['diagnostics'] and
                     fields.get('result_payload_complete') != 'true',
                     f'failed envelope lacks deterministic incomplete-result diagnostics: {relative}')
            compressed = records_by_raw.get(relative)
            envelope_identity = (compressed['logical_identity'] if compressed is not None
                                 else bound(PUBLIC / relative))
            envelopes.append(dict(**envelope_identity, status=payload['status'],
                                  storage_path=compressed['path'] if compressed else relative))

    pressure = []
    for case in cases:
        artifact = case.get('values') or case.get('complete_rows')
        if not isinstance(artifact, dict) or not artifact.get('path', '').endswith('.jsonl.gz'):
            continue
        path = safe_public_relative(artifact['path'])
        digest = hashlib.sha256()
        count = 0
        with gzip.open(path, 'rb') as stream:
            for line in stream:
                strict_json(line.decode('utf-8'))
                digest.update(line)
                count += 1
        expected_count = case.get('rows_verified', case.get('complete_output_rows', case.get('complete_rows')))
        expected_digest = case.get('expected_sha256', case.get('all_output_rows_sha256'))
        need(count == expected_count and digest.hexdigest() == expected_digest,
             f'pressure JSONL identity/value count mismatch: {case["name"]}')
        artifact_identity = bound(path)
        for key in ('bytes', 'sha256'):
            if key in artifact:
                need(artifact[key] == artifact_identity[key],
                     f'pressure artifact metadata mismatch: {case["name"]}')
        pressure.append(dict(name=case['name'], **artifact_identity,
                             rows=count, raw_sha256=digest.hexdigest()))
    need({Path(row['logical_path']).name for row in predeclared_values} ==
         {'unary-predeclared-values.json', 'subquery-predeclared-results.json', 'dynamic-subquery-predeclared-results.json'},
         'all three predeclared independent value inventories must be present')
    original_baseline = strict_json(Path(baseline['baseline']['path']).read_text())
    need(bound(Path(baseline['baseline']['path'])) == baseline['baseline'],
         'retained pre-change baseline identity differs')
    old_cases = {row['name']: row for row in original_baseline['cases']}
    baseline_controls = []
    for case in cases:
        name = case['name']
        if not name.startswith('dynamic-subquery-baseline-'):
            continue
        key, streaming = name.removeprefix('dynamic-subquery-baseline-').rsplit('-streaming-', 1)
        wanted = original_baseline['expected'][key]
        values = decoded_json['logs/' + name + '-values.json']
        declared = decoded_json['logs/' + name + '-declaration.json']
        need(values['actual'] == values['expected'] == declared['expected'] == wanted,
             'dynamic baseline complete values differ: ' + name)
        old = old_cases[name.replace('dynamic-subquery-baseline-', 'dynamic-inner-baseline-', 1)]
        need(old['status'] == 'passed' and case['status'] == 'passed', 'baseline control did not pass')
        if streaming == 'True':
            need(old['outcome'] == 'dynamic_inner_streaming_refusal' and old['producer_events'] == [] and
                 case['outcome'] == 'streaming_success', 'streaming baseline did not become native success')
        else:
            need(streaming == 'False' and case['outcome'] == 'resident_control_passed',
                 'resident baseline outcome changed')
        baseline_controls.append(dict(name=name, before=old['outcome'], after=case['outcome'],
                                      complete_rows=len(wanted), producer_events=case['producer_events']))
    need(len(baseline_controls) == 32, 'all original dynamic baseline controls are required')
    pressure_relative = 'logs/dynamic-subquery-pressure-fixtures.json'
    pressure_declaration = O / 'stream-dynamic-subquery-candidate-declarations-521/dynamic-subqueries-pressure/logs/dynamic-subquery-pressure-fixtures.json'
    declared_pressure = strict_json(pressure_declaration.read_text())
    observed_pressure = decoded_json[pressure_relative]
    need({key: value for key, value in declared_pressure.items() if key != 'spill'} ==
         {key: value for key, value in observed_pressure.items() if key != 'spill'} and
         {key: value for key, value in declared_pressure['spill'].items() if key != 'workspace'} ==
         {key: value for key, value in observed_pressure['spill'].items() if key != 'workspace'},
         'dynamic pressure fixture changed after declaration')
    need(comparisons and envelopes and pressure,
         'public evidence must contain value comparisons, envelopes, and pressure row artifacts')
    need(load() == manifest,
         'accepted source or frozen native artifacts changed during evidence inspection')
    need(not OUTPUT.exists(), f'public inspection output already exists: {OUTPUT}')

    compressed_totals = dict(files=len(compressed_records), stored_bytes=compressed_bytes,
                             decoded_raw_bytes=raw_bytes)
    result = dict(status='passed', cases=len(cases), families=len(summary['families']),
        summary=summary_identity, receipt=receipt_identity, runtime=bound(RUNTIME_PATH),
        helper=bound(__file__), complete_case_set_comparison=bound(BASELINE_PATH),
        accepted_source=accepted_identity, artifact_manifest=identity(manifest_path),
        complete_case_log_records_equal=True, frozen_sources_and_binary_unchanged=True,
        artifacts=list(references.values()), value_files=comparisons,
        predeclared_value_files=predeclared_values,
        retained_initial_failures=bound(O / 'stream-subquery-corrections-509/initial-failures.json'),
        corrected_source=bound(O / 'stream-subquery-corrections-509/corrections.json'),
        dynamic_initial_failures=bound(O / 'stream-dynamic-subquery-direct-new-tests-517.json'),
        dynamic_initial_diagnosis=bound(O / 'dynamic-subquery-direct-diagnosis-517.json'),
        dynamic_baseline_controls=baseline_controls, dynamic_baseline=baseline['baseline'],
        dynamic_pressure_predeclaration=bound(pressure_declaration),
        explicit_expected_value_rows=sum(item['rows'] for item in comparisons),
        envelopes=envelopes, pressure_files=pressure,
        pressure_rows=sum(item['rows'] for item in pressure),
        compressed_json_files=compressed_records, compressed_json_totals=compressed_totals,
        limitations=['Public output payload formats were reopened by the recorded UAT; this review independently verifies compressed and raw JSON log identities, every value comparison, envelope policy fields, and pressure rows.',
                     'The suite is finite local workflow acceptance, not a process RSS ceiling, all-platform claim or speedup measurement.'])
    with OUTPUT.open('x') as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(dict(status='passed', cases=len(cases), families=len(summary['families']),
        compressed_json_files=compressed_totals['files'],
        compressed_stored_bytes=compressed_bytes, decoded_raw_bytes=raw_bytes,
        value_files=len(comparisons), explicit_expected_value_rows=sum(item['rows'] for item in comparisons),
        envelopes=len(envelopes), pressure_files=len(pressure), pressure_rows=sum(item['rows'] for item in pressure))))


if __name__ == '__main__':
    main()
