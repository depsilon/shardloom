"""Reopen the unchanged complete public matrix from portable metadata evidence.

The original public verifier's fixed compressed/raw byte totals are intentionally
replaced by computed totals: envelope timing and ownership fields vary between
executions. Every original/compressed byte identity and all fixed semantic counts
remain checked, and the caller compares computed totals with the live inspection.
"""
import gzip
from pathlib import Path
from verify_stream_unary_packet_497 import (
    NeedsReasoning, need, digest, strict_json, safe_member, canonical_hash, report_fields,
)
EXPECTED_PUBLIC_CASES = 4827
EXPECTED_PUBLIC_FAMILIES = 36
EXPECTED_DECLARED_VALUES_SHA256 = 'd6f5b2fa6f66f69731bfebae38ac6dce6bbbd119f7607feb975676b143f0db4a'


def verify_public(members: dict[str, bytes], receipt_log: bytes,
                  expected_case_protocol: dict) -> dict:
    summary = strict_json(members['public/summary.json'])
    need(summary.get('status') == 'passed' and summary.get('compress_logs') is True,
         'public summary must pass and declare compressed logs')
    cases = summary.get('cases')
    need(isinstance(cases, list) and len(cases) == EXPECTED_PUBLIC_CASES,
         'public summary must contain exactly 4,827 cases')
    names = [case.get('name') for case in cases]
    need(len(set(names)) == EXPECTED_PUBLIC_CASES and
         names == expected_case_protocol.get('expected_public_names'),
         'ordered public names differ from the full predeclared case protocol')
    families = summary.get('families')
    need(len(families) == EXPECTED_PUBLIC_FAMILIES and
         families == expected_case_protocol.get('expected_public_families') and
         all(case.get('status') == 'passed' for case in cases),
         'public families or case outcomes differ from the accepted protocol')
    logged = [strict_json(line) for line in receipt_log.decode('utf-8').splitlines()
              if line.startswith('{')]
    need([row for row in logged if 'name' in row] == cases,
         'public process log does not contain the complete ordered case records')

    metadata = summary.get('compressed_json_files')
    need(isinstance(metadata, list), 'public compressed JSON metadata is missing')
    declared, logical, compressed_meta = set(), {}, {}
    for row in metadata:
        need(isinstance(row, dict), 'invalid compressed JSON metadata row')
        rel, raw_rel = row.get('path'), row.get('raw_path')
        need(isinstance(rel, str) and rel.startswith('logs/') and
             rel.endswith('.json.gz') and not rel.endswith('.jsonl.gz'),
             f'wrong compressed JSON path: {rel!r}')
        safe_member(rel)
        need(rel not in declared and raw_rel == rel[:-3] and raw_rel.endswith('.json'),
             f'duplicate or mismatched compressed JSON path: {rel}')
        declared.add(rel)
        packed_key = 'public/' + rel
        need(packed_key in members, f'compressed public JSON log is absent: {packed_key}')
        packed = members[packed_key]
        need(len(packed) == row.get('bytes') and digest(packed) == row.get('sha256'),
             f'compressed public JSON identity mismatch: {rel}')
        try:
            raw = gzip.decompress(packed)
        except (OSError, EOFError) as exc:
            raise NeedsReasoning(f'invalid compressed public JSON {rel}: {exc}') from exc
        need(len(raw) == row.get('raw_bytes') and digest(raw) == row.get('raw_sha256'),
             f'decompressed public JSON identity mismatch: {rel}')
        value = strict_json(raw.decode('utf-8'))
        need(raw_rel not in logical, f'duplicate logical JSON path: {raw_rel}')
        logical[raw_rel] = value
        compressed_meta[raw_rel] = row
    actual_gzip = {name.removeprefix('public/') for name in members
                   if name.startswith('public/logs/') and name.endswith('.json.gz')}
    need(actual_gzip == declared,
         'compressed JSON metadata does not equal archived public logs/*.json.gz')
    for name, data in members.items():
        if name.startswith('public/logs/') and name.endswith('.json'):
            rel = name.removeprefix('public/')
            need(rel not in logical, f'both compressed and raw JSON exist: {rel}')
            logical[rel] = strict_json(data)

    for rel, value in logical.items():
        if rel != 'logs/unary-predeclared-values.json' and Path(rel).name.endswith('-values.json'):
            need(isinstance(value, dict) and value.get('actual') == value.get('expected'),
                 f'public actual/expected JSON values differ: {rel}')
        if Path(rel).name.endswith('-envelope.json'):
            fallback = value.get('fallback', {})
            need(fallback.get('attempted') is False,
                 f'public result envelope attempted fallback: {rel}')
            fields = value.get('fields', [])
            if value.get('status') == 'success':
                report_fields(value)
                need(any(f.get('key') == 'public_workflow_external_engine_invoked' and
                         f.get('value') in (False, 'false') for f in fields),
                     f'public successful envelope lacks no-external-engine evidence: {rel}')
            else:
                field_map = {row['key']: row['value'] for row in fields}
                need(len(field_map) == len(fields) and value.get('diagnostics') and
                     field_map.get('result_payload_complete') != 'true',
                     f'failed public envelope lacks incomplete-result diagnostics: {rel}')

    # Preserve and compare the exact predeclared 39-entry literal matrix.
    raw_rel = 'logs/unary-predeclared-values.json'
    need(raw_rel in logical and isinstance(logical[raw_rel], list) and
         len(logical[raw_rel]) == 39,
         'public unary predeclared-values list must remain exactly 39 elements')
    need(canonical_hash(logical[raw_rel]) == EXPECTED_DECLARED_VALUES_SHA256,
         'public unary predeclared-values list differs from the exact frozen list')
    prior_key = 'predeclared-reference/unary-predeclared-values.json'
    need(prior_key in members and strict_json(members[prior_key]) == logical[raw_rel],
         '39-entry public predeclared-values list differs from archived preimplementation values')
    need(len({(row['kind'], row['shape']) for row in logical[raw_rel]}) == 39,
         'predeclared unary kind/shape combinations are duplicated')

    subquery_ref = 'logs/subquery-predeclared-results.json'
    need(subquery_ref in logical and isinstance(logical[subquery_ref], dict) and
         len(logical[subquery_ref]) == 27 and
         all(set(shapes) == {'mixed', 'empty-outer', 'empty-inner', 'all-null'}
             for shapes in logical[subquery_ref].values()),
         'subquery reference must retain all 27 kinds and four input shapes')
    prior_subquery = 'predeclared-reference/subquery-predeclared-results.json'
    need(prior_subquery in members and strict_json(members[prior_subquery]) == logical[subquery_ref],
         'subquery expected values changed after pre-execution declaration')
    dynamic_ref = 'logs/dynamic-subquery-predeclared-results.json'
    prior_dynamic = 'declarations-521/dynamic-subqueries/logs/dynamic-subquery-predeclared-results.json'
    need(dynamic_ref in logical and len(logical[dynamic_ref]) == 18 and
         all(set(shapes) == {'mixed', 'empty-outer', 'empty-inner', 'all-null'}
             for shapes in logical[dynamic_ref].values()) and
         strict_json(members[prior_dynamic]) == logical[dynamic_ref],
         'dynamic reference must retain all eighteen kinds and four predeclared shapes')
    baseline = strict_json(members['baseline/summary.json'])
    old_cases = {row['name']: row for row in baseline['cases']}
    controls = []
    for case in cases:
        name = case['name']
        if not name.startswith('dynamic-subquery-baseline-'):
            continue
        key, streaming = name.removeprefix('dynamic-subquery-baseline-').rsplit('-streaming-', 1)
        expected = baseline['expected'][key]
        values = logical['logs/' + name + '-values.json']
        declared_value = logical['logs/' + name + '-declaration.json']
        need(values['actual'] == values['expected'] == declared_value['expected'] == expected,
             'complete original baseline values differ: ' + name)
        old_case = old_cases[name.replace('dynamic-subquery-baseline-', 'dynamic-inner-baseline-', 1)]
        if streaming == 'True':
            need(old_case['outcome'] == 'dynamic_inner_streaming_refusal' and
                 old_case['producer_events'] == [] and case['outcome'] == 'streaming_success',
                 'baseline streaming refusal did not become exact native success')
        else:
            need(streaming == 'False' and old_case['outcome'] == case['outcome'] == 'resident_control_passed',
                 'resident baseline changed')
        controls.append(name)
    need(len(controls) == 32, 'original baseline case coverage differs')

    declared_pressure = strict_json(members['declarations-521/dynamic-subqueries-pressure/logs/dynamic-subquery-pressure-fixtures.json'])
    observed_pressure = logical['logs/dynamic-subquery-pressure-fixtures.json']
    need({key: value for key, value in declared_pressure.items() if key != 'spill'} ==
         {key: value for key, value in observed_pressure.items() if key != 'spill'} and
         {key: value for key, value in declared_pressure['spill'].items() if key != 'workspace'} ==
         {key: value for key, value in observed_pressure['spill'].items() if key != 'workspace'},
         'dynamic pressure fixture differs from its predeclared values')

    pressure_files = pressure_rows = 0
    for case in cases:
        artifact = case.get('values') or case.get('complete_rows')
        if not isinstance(artifact, dict) or not str(artifact.get('path', '')).endswith('.jsonl.gz'):
            continue
        rel = artifact['path']
        safe_member(rel)
        key = 'public/' + rel
        need(key in members, f'public pressure JSONL evidence is absent: {key}')
        packed = members[key]
        need(len(packed) == artifact.get('bytes') and digest(packed) == artifact.get('sha256'),
             f'public pressure JSONL compressed identity mismatch: {rel}')
        try:
            decoded = gzip.decompress(packed)
        except (OSError, EOFError) as exc:
            raise NeedsReasoning(f'invalid public pressure JSONL {rel}: {exc}') from exc
        rows = [strict_json(line) for line in decoded.splitlines()]
        expected_count = case.get('rows_verified', case.get('complete_output_rows',
                                                            case.get('complete_rows')))
        expected_digest = case.get('expected_sha256', case.get('all_output_rows_sha256'))
        need(len(rows) == expected_count and digest(decoded) == expected_digest,
             f'public pressure row count/hash mismatch: {case.get("name")}')
        pressure_files += 1
        pressure_rows += len(rows)
    comparisons = [value for rel, value in logical.items()
                   if rel != 'logs/unary-predeclared-values.json' and Path(rel).name.endswith('-values.json')]
    envelope_count = sum(Path(rel).name.endswith('-envelope.json') for rel in logical)
    need(pressure_files == 45 and pressure_rows == 1578741 and len(comparisons) == 4495 and
         sum(len(value['expected']) for value in comparisons) == 39979 and envelope_count == 6330 and
         len(declared) == 13004,
         'reopened public evidence counts differ from the complete accepted inspection')
    return {'cases': len(cases), 'families': len(families),
            'compressed_json_files': len(declared), 'value_files': len(comparisons),
            'compressed_stored_bytes': sum(row['bytes'] for row in metadata),
            'decoded_raw_bytes': sum(row['raw_bytes'] for row in metadata),
            'expected_rows': 39979, 'envelopes': envelope_count,
            'pressure_files': pressure_files, 'pressure_rows': pressure_rows,
            'predeclared_value_entries': 39, 'subquery_predeclared_kind_shapes': 108,
            'dynamic_predeclared_kind_shapes': 72, 'baseline_controls': 32}
