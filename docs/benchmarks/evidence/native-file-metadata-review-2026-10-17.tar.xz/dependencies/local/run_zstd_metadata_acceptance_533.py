"""Bind metadata ownership acceptance to its frozen builds and unchanged public matrix."""
import argparse
import json
import os
from pathlib import Path
import sys
import unittest

from freeze_native_release_298 import ROOT, OUT, sha, save, sources
from run_query_timing_runtime_461 import guarded, PYTHON_DEPS

SOURCE = OUT / 'native-release-source-zstdmetadata532.json'
MANIFEST = OUT / 'native-release-artifacts-zstdmetadata532.json'
PROTOCOL = OUT / 'zstd-metadata-acceptance-protocol-533.json'
PRIOR = OUT / 'stream-dynamic-subquery-acceptance-protocol-521.json'
PRIOR_DIRECT = OUT / 'stream-dynamic-subquery-direct-tests-521.json'
CHECKS = OUT / 'zstd-metadata-checks-532.json'
COST = OUT / 'zstd-metadata-cost-530/decision.json'
PUBLIC = OUT / 'zstd-metadata-public-533'
DIRECT = OUT / 'zstd-metadata-direct-tests-533.json'
PUBLIC_ACCEPTANCE = OUT / 'zstd-metadata-public-acceptance-533.json'
PYTHON = OUT / 'selected-view-python-468/bin/python'


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def unchanged():
    frozen = json.loads(SOURCE.read_text())
    assert sources() == frozen['source_sha256'], 'accepted source changed'
    return frozen


def receipt(path):
    path = Path(path)
    record = json.loads(path.read_text())
    assert record['status'] == 'passed' and record['returncode'] == 0
    assert record['process_group_drained'] and record['direct_child_reaped']
    assert not record['timed_out'] and not record['group_absence_unproved_at_cleanup']
    assert sha(path.with_suffix('.log')) == record['log_sha256']
    assert record['head'] == unchanged()['head']
    return record


def load():
    frozen = unchanged()
    manifest = json.loads(MANIFEST.read_text())
    assert manifest['status'] == 'passed' and manifest['build_profile'] == 'release'
    assert manifest['source_sha256'] == frozen['source_sha256']
    assert manifest['head'] == frozen['head']
    for key in ('cli', 'binding'):
        item = manifest[key]
        assert identity(item['path']) == {name: item[name] for name in ('path', 'bytes', 'sha256')}
        assert sha(item['build_receipt']) == item['build_receipt_sha256']
        record = receipt(item['build_receipt'])
        assert '--release' in record['command']
        assert sha(item['build_log']) == record['log_sha256']
    return manifest


def prerequisites():
    frozen = unchanged()
    checks = json.loads(CHECKS.read_text())
    assert checks['status'] == 'passed' and checks['source_identity_preserved']
    assert [row['stage'] for row in checks['completed']] == [
        'fmt', 'workspace-clippy', 'workspace-tests', 'read-clippy', 'release-clippy', 'native-tests']
    for row in checks['completed']:
        assert identity(row['receipt']['path']) == row['receipt']
        assert identity(row['log']['path']) == row['log']
        receipt(row['receipt']['path'])
    cost = json.loads(COST.read_text())
    assert cost['status'] == 'retained_pending_broad_acceptance' and not cost['repeated_breaches']
    assert not cost['performance_claim_allowed']
    import zstd_metadata_cost_532 as lifecycle
    lifecycle.verify(json.loads(Path(cost['protocol']['path']).read_text()))
    for key in ('protocol', 'forward', 'reverse'):
        if cost[key] is not None:
            assert identity(cost[key]['path']) == cost[key]
    assert unchanged() == frozen


def declare():
    prerequisites()
    manifest = load()
    prior = json.loads(PRIOR.read_text())
    direct = json.loads(PRIOR_DIRECT.read_text())
    assert prior['status'] == 'predeclared'
    assert direct['status'] == 'passed' and direct['tests'] == 100
    assert len(direct['test_names']) == len(set(direct['test_names'])) == 100
    sys.path[:0] = [str(ROOT / 'python/src'), str(ROOT / 'scripts')]
    from run_native_streaming_input_uat import FAMILIES
    families = prior['expected_public_families']
    names = prior['expected_public_names']
    assert list(FAMILIES) == families and len(families) == 36
    assert len(names) == len(set(names)) == 4827
    assert identity(prior['baseline']['path']) == prior['baseline']
    helpers = [Path(__file__), OUT / 'freeze_native_release_298.py',
        OUT / 'run_query_timing_runtime_461.py', OUT / 'run_guarded.py',
        OUT / 'verify_zstd_metadata_public_533.py',
        OUT / 'verify_stream_dynamic_subquery_public_522.py']
    save(PROTOCOL, dict(status='predeclared', native_engine_executions=0,
        source=identity(SOURCE), artifacts=identity(MANIFEST), helpers=[identity(p) for p in helpers],
        prior_protocol=identity(PRIOR), prior_direct=identity(PRIOR_DIRECT),
        expected_direct_tests=100, expected_direct_names=direct['test_names'],
        expected_public_names=names, expected_public_families=families,
        baseline=prior['baseline'], checks=identity(CHECKS), cost=identity(COST),
        contract=identity(ROOT / 'docs/architecture/native-zstd-metadata-resources-2026-10-16.md'),
        performance_claim=False, whole_process_memory_ceiling=False, installed_wheel_proof=False))
    assert load() == manifest
    print(json.dumps(dict(status='predeclared', direct_tests=100, public_cases=4827, families=36)))


def protocol():
    value = json.loads(PROTOCOL.read_text())
    for item in value['helpers'] + [value[key] for key in
            ('source', 'artifacts', 'prior_protocol', 'prior_direct', 'baseline', 'checks', 'cost', 'contract')]:
        assert identity(item['path']) == item
    return value


def direct():
    manifest = load()
    frozen = protocol()
    assert Path(sys.executable) == PYTHON
    sys.path[:0] = [str(ROOT / 'python/src'), str(PYTHON_DEPS)]
    import pyarrow
    import shardloom
    assert Path(shardloom.__file__).resolve() == ROOT / 'python/src/shardloom/__init__.py'
    os.environ.update(SHARDLOOM_NATIVE_TEST_LIBRARY=manifest['binding']['path'],
                      SHARDLOOM_REQUIRE_NATIVE_PYTHON='1', SHARDLOOM_BIN=manifest['cli']['path'])
    suite = unittest.defaultTestLoader.discover(str(ROOT / 'python/tests'), pattern='test_native*binding.py')
    def identifiers(value):
        return [name for child in value for name in identifiers(child)] if isinstance(value, unittest.TestSuite) else [value.id()]
    names = identifiers(suite)
    assert names == frozen['expected_direct_names'] and len(names) == 100
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    passed = result.wasSuccessful() and result.testsRun == 100 and not result.skipped
    save(DIRECT, dict(status='passed' if passed else 'failed', tests=result.testsRun,
        failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
        failure_details=[dict(test=str(test), traceback=detail) for test, detail in result.failures],
        error_details=[dict(test=str(test), traceback=detail) for test, detail in result.errors],
        test_names=names, artifact_manifest=identity(MANIFEST), source=identity(SOURCE),
        protocol=identity(PROTOCOL), helper=identity(__file__), interpreter=sys.executable,
        python_version=sys.version, pyarrow_version=pyarrow.__version__, pyarrow_file=pyarrow.__file__,
        package_source=shardloom.__file__, mode='direct_source_package_with_explicit_frozen_native_library',
        installed_wheel_proof=False))
    assert load() == manifest and protocol() == frozen and passed


def public():
    prerequisites()
    manifest = load()
    frozen = protocol()
    direct_result = json.loads(DIRECT.read_text())
    assert direct_result['status'] == 'passed' and direct_result['tests'] == 100
    receipt(OUT / 'zstd-metadata-direct-533.json')
    assert not PUBLIC.exists()
    families = frozen['expected_public_families']
    guarded('zstd-metadata-public-533', 7200,
        [sys.executable, '-B', ROOT / 'scripts/run_native_streaming_input_uat.py',
         '--binary', manifest['cli']['path'], '--uat-root', PUBLIC, '--operation-timeout', '600',
         '--compress-logs', '--families', *families])
    receipt(OUT / 'zstd-metadata-public-533.json')
    summary = json.loads((PUBLIC / 'summary.json').read_text())
    assert summary['status'] == 'passed' and summary['families'] == families and summary['compress_logs']
    assert [row['name'] for row in summary['cases']] == frozen['expected_public_names']
    assert all(row['status'] == 'passed' for row in summary['cases'])
    assert load() == manifest and protocol() == frozen
    save(PUBLIC_ACCEPTANCE, dict(status='passed', cases=4827, families=families,
        manifest=identity(MANIFEST), source=identity(SOURCE), protocol=identity(PROTOCOL),
        summary=identity(PUBLIC / 'summary.json'), direct=identity(DIRECT),
        source_identity_preserved=True, full43_pending=True))
    print(json.dumps(dict(status='passed', public_cases=4827, families=36)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('declare', 'direct', 'public'))
    args = parser.parse_args()
    {'declare': declare, 'direct': direct, 'public': public}[args.operation]()
