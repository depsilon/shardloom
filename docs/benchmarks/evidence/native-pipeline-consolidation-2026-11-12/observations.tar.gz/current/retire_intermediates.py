"""Retire only superseded pipeline builds and completed install environments."""
import argparse
import importlib.util
import json
import lzma
from pathlib import Path

OUT = Path(__file__).resolve().parent
TARGET = OUT / 'retirement-r1'
BASE = OUT.parent / 'expanded-query-2026-11-03/tools/retire_shared_intermediates_r2.py'
BASE_SHA = '19082efec1eaf8df1f894f5047f9efa3c58f1aed206424be3d04c28899b4482e'
import hashlib
assert hashlib.sha256(BASE.read_bytes()).hexdigest() == BASE_SHA
spec = importlib.util.spec_from_file_location('retirement_primitives', BASE)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.E = OUT
ROOTS = ('runtime-r1', 'runtime-r2',
         'installed-wheel-r1/package', 'installed-wheel-r1/venv', 'installed-wheel-r1/dist',
         'installed-wheel-r2/package', 'installed-wheel-r2/venv', 'installed-wheel-r2/dist',
         'installed-wheel-r3/package', 'installed-wheel-r3/venv', 'wheel-tools-r1/venv')
INPUT_PROOF = OUT.parent / 'direct-count-bridge-2026-11-12/baseline-missing-r1.json'
SOURCE_COMMIT = '3a861917ad6852e6a35ac8642d78c4d31451f29f'


def read(path):
    return json.loads(path.read_bytes())


def admission():
    summary = read(OUT / 'full10k-r1/verified-summary-r1.json')
    assert summary['status'] == 'passed_offline_replay'
    assert summary['source_commit'] == SOURCE_COMMIT
    assert summary['attempted_cases'] == summary['successful_cases'] == 10000
    assert summary['unsuccessful_cases'] == summary['query_executions_during_replay'] == 0
    for key in ('case_rows', 'complete', 'ledger', 'previous_summary', 'previous_case_rows', 'protocol', 'verifier'):
        value = summary[key]
        assert base.sha(Path(value['path'])) == value['sha256'], key
    supervision = read(OUT / 'full10k-supervision-r1.json')
    assert supervision['status'] == 'passed_capture' and supervision['returncode'] == 0
    assert supervision['process_group_drained'] and supervision['direct_child_reaped']
    assert supervision['runtime_and_source_unchanged']
    installed = read(OUT / 'installed-wheel-r3/report.json')
    assert installed['status'] == installed['uninstall_status'] == 'passed'
    assert installed['integration'] == dict(status='passed', tests=441, failures=0, errors=0, skipped=0)
    assert read(OUT / 'native-test-reconciliation-r3.json')['status'] == 'passed'
    assert read(OUT / 'full10k-r1/pipeline-certificate-audit-r1.json')['status'] == 'passed'
    runtime = read(OUT / 'runtime-r3-identity.json')
    for name, identity in runtime['files'].items():
        path = Path(name)
        assert path.stat().st_size == identity['bytes'] and base.sha(path) == identity['sha256']
    for name in ('runtime-r1', 'runtime-r2'):
        old = read(OUT / (name + '-identity.json'))
        assert old['status'] == 'passed'
        for file, identity in old['files'].items():
            path = Path(file)
            assert path.stat().st_size == identity['bytes'] and base.sha(path) == identity['sha256']


def inputs():
    expected = read(INPUT_PROOF)['input_generations']
    assert len(expected) == 220
    assert {name: base.generation(Path(name)) for name in expected} == expected
    return expected


def retained(roots):
    keep = {}
    def visit(path):
        if path == TARGET or path in roots:
            return
        assert not path.is_symlink(), path
        if path.is_dir():
            for child in sorted(path.iterdir()):
                visit(child)
        elif path.is_file():
            keep[str(path)] = base.sha(path)
        else:
            raise AssertionError(path)
    visit(OUT)
    prior = OUT.parent / 'current-state-uat-2026-11-12/full10k-r1'
    for name in ('attempts.sqlite', 'complete.json', 'verified-summary-r1.json', 'verified-cases-r1.jsonl.gz'):
        keep[str(prior / name)] = base.sha(prior / name)
    keep[str(BASE)] = BASE_SHA
    keep[str(INPUT_PROOF)] = base.sha(INPUT_PROOF)
    return keep


def plan():
    assert not TARGET.exists()
    admission()
    roots = [OUT / name for name in ROOTS]
    for root in roots:
        assert root.is_dir() and not root.is_symlink()
    rows = [row for root in roots for row in base.inventory(root)]
    keep, generations = retained(roots), inputs()
    assert not set(keep).intersection(row['path'] for row in rows)
    assert not set(generations).intersection(row['path'] for row in rows)
    TARGET.mkdir(mode=0o700)
    manifest = dict(roots=[str(root) for root in roots], entries=rows,
                    retained=keep, input_generations=generations,
                    regeneration='Rebuild superseded revisions from Git and retained build receipts; recreate install environments from the retained current wheel and wheelhouse.',
                    scope='Local intermediate retirement only; no hosted integration or prior accepted runtime retirement.')
    (TARGET / 'manifest.json.xz').write_bytes(lzma.compress(json.dumps(manifest, sort_keys=True).encode()))
    result = dict(status='planned_no_deletion', source_commit=SOURCE_COMMIT,
                  roots=len(roots), entries=len(rows),
                  regular_files=sum(row['kind'] == 'regular' for row in rows),
                  symlinks=sum(row['kind'] == 'symlink' for row in rows),
                  regular_bytes=sum(row['generation'][3] for row in rows if row['kind'] == 'regular'),
                  retained_files=len(keep), input_files=len(generations),
                  script_sha256=base.sha(Path(__file__)), helper_sha256=BASE_SHA,
                  manifest_sha256=base.sha(TARGET / 'manifest.json.xz'),
                  query_executions=0, published=False, payload_backup_created=False)
    (TARGET / 'plan.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


def apply():
    summary = read(TARGET / 'plan.json')
    assert summary['status'] == 'planned_no_deletion'
    assert summary['script_sha256'] == base.sha(Path(__file__))
    assert summary['manifest_sha256'] == base.sha(TARGET / 'manifest.json.xz')
    manifest = json.loads(lzma.decompress((TARGET / 'manifest.json.xz').read_bytes()))
    roots = [OUT / name for name in ROOTS]
    assert manifest['roots'] == [str(root) for root in roots]
    admission()
    assert retained(roots) == manifest['retained'] and inputs() == manifest['input_generations']
    for _ in range(2):
        assert [row for root in roots for row in base.inventory(root)] == manifest['entries']
        base.closed(manifest['roots'])
    receipt = dict(status='running', plan_sha256=base.sha(TARGET / 'plan.json'),
                   manifest_sha256=summary['manifest_sha256'], removed=0)
    destination = TARGET / 'receipt.json'
    assert not destination.exists()
    try:
        for row in sorted(manifest['entries'], key=lambda value: len(Path(value['path']).parts), reverse=True):
            base.unchanged(row, removing_children=True)
            path = Path(row['path'])
            if row['kind'] == 'directory':
                path.rmdir()
            else:
                path.unlink()
            receipt['removed'] += 1
        assert all(not root.exists() and not root.is_symlink() for root in roots)
        assert retained(roots) == manifest['retained'] and inputs() == manifest['input_generations']
        receipt.update(status='passed', retained_files_unchanged=True,
                       input_generations_unchanged=True, closed_handle_checks=2,
                       repeated_inventory_checks=2, query_executions=0,
                       regular_files=summary['regular_files'], regular_bytes=summary['regular_bytes'],
                       symlinks=summary['symlinks'], roots=summary['roots'],
                       payload_backup_created=False, storage_limits_changed=False)
    except BaseException as error:
        receipt.update(status='failed_partial', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        with destination.open('x') as stream:
            json.dump(receipt, stream, indent=2)
            stream.write('\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    assert __debug__
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('plan', 'apply'))
    args = parser.parse_args()
    plan() if args.mode == 'plan' else apply()
