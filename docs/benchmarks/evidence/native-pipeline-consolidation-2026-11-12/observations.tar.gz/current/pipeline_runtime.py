"""Verify the locally built pipeline runtime and its exact tested source snapshot."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
OUT = Path(__file__).resolve().parent


def sources():
    # Keep verification imports independent of the frozen benchmark's modules.
    paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others',
        '--exclude-standard', '-z'], cwd=ROOT).decode().split('\0')
    result = {}
    for name in sorted(set(paths) - {''}):
        if name.startswith(('docs/benchmarks/evidence/', 'docs/release/evidence/',
                            'docs/dependencies/evidence/')):
            continue
        path = ROOT / name
        if path.is_symlink():
            result[name] = {'symlink': os.readlink(path)}
        elif path.is_file():
            result[name] = identity(path)
        else:
            result[name] = {'absent': True}
    return result


def read(path):
    return json.loads(path.read_bytes())


def generation(path):
    stat = path.stat()
    return [stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns]


def identity(path):
    assert path.is_file() and not path.is_symlink(), path
    before = generation(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    assert generation(path) == before, path
    return dict(bytes=before[2], sha256=digest)


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True, timeout=90).strip()


def fingerprint(snapshot):
    return hashlib.sha256(json.dumps(snapshot, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def verify():
    assert __debug__, 'assertions required'
    manifest_path = OUT / 'runtime-r3-identity.json'
    validation_path = OUT / 'validation-before-10k.json'
    manifest, validation = read(manifest_path), read(validation_path)
    assert manifest['status'] == validation['status'] == 'passed'
    assert identity(manifest_path) == validation['runtime']
    assert manifest['source_commit'] == validation['source_commit']
    assert manifest['source_tree'] == validation['source_tree']
    assert manifest['profile'] == 'release'
    assert git('rev-parse', 'HEAD') == manifest['source_commit']
    assert git('rev-parse', 'HEAD^{tree}') == manifest['source_tree']
    assert not git('status', '--porcelain'), 'source must be frozen before capture'
    build_path = OUT / manifest['build_receipt']
    assert identity(build_path) == manifest['build_receipt_identity']
    build = read(build_path)
    assert build['status'] == 'passed' and build['returncode'] == 0
    assert build['sources_unchanged'] and build['process_group_drained'] and build['direct_child_reaped']
    assert build['source_files'] == sources()
    assert fingerprint(build['source_files']) == manifest['source_fingerprint_sha256']
    proofs = [manifest_path, build_path, validation_path]
    for name, expected in validation['checks'].items():
        path = OUT / name
        assert identity(path) == expected
        check = read(path)
        assert check['status'] == 'passed' and check['returncode'] == 0
        assert check['sources_unchanged'] and check['process_group_drained']
        assert check['source_files'] == build['source_files'], name
        proofs.append(path)
    for name, expected in validation['installed_checks'].items():
        path = OUT / name
        assert identity(path) == expected
        assert read(path)['status'] == 'passed'
        proofs.append(path)
    native = validation['native_suite_reconciliation']
    path = OUT / native['name']
    assert identity(path) == native['identity']
    reconciliation = read(path)
    assert reconciliation['status'] == 'passed'
    assert reconciliation['non_cli_production_source_unchanged']
    assert reconciliation['changed_native_cli_targets_rechecked']
    assert reconciliation['all_original_failures_passed_in_focused_rechecks']
    assert reconciliation['source_files'] == build['source_files']
    assert reconciliation['source_fingerprint_sha256'] == manifest['source_fingerprint_sha256']
    proofs.append(path)
    for name, expected in reconciliation['proofs'].items():
        path = OUT / name
        assert identity(path) == expected
        proofs.append(path)
    runtime = {}
    for key, name in [('binary', 'shardloom'), ('library', '_native.abi3.so')]:
        path = OUT / 'runtime-r3' / name
        assert identity(path) == manifest['files'][str(path)], name
        runtime[key] = dict(path=str(path), **identity(path))
    assert identity(OUT / 'runtime-r3/lib_native.dylib') == identity(OUT / 'runtime-r3/_native.abi3.so')
    return dict(head=manifest['source_commit'], source_tree=manifest['source_tree'],
        source_root=str(ROOT), source_fingerprint_sha256=manifest['source_fingerprint_sha256'],
        runtime=runtime, proofs={str(path): identity(path) for path in proofs},
        locally_validated=True, published=False, runtime_rebuilt=True)


def source_revision():
    record = read(OUT / 'runtime-r3-identity.json')
    return record['source_commit'], record['source_tree']
