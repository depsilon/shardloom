"""Bind the original native suite, its test repair and the final CLI/package rechecks."""
import json
import re
from pathlib import Path

from pipeline_runtime import OUT, fingerprint, identity, read, sources

assert __debug__
destination = OUT / 'native-test-reconciliation-r2.json'
assert not destination.exists()
previous_path = OUT / 'native-test-reconciliation-r1.json'
previous = read(previous_path)
assert previous['status'] == 'passed' and previous['production_source_unchanged']
assert previous['all_original_failures_passed_in_focused_rechecks']
proofs = dict(previous['proofs'])
for name, expected in proofs.items():
    assert identity(OUT / name) == expected, name
proofs[previous_path.name] = identity(previous_path)
snapshot = sources()
changed = {name for name in set(snapshot) | set(previous['source_files'])
           if snapshot.get(name) != previous['source_files'].get(name)}
expected = {
    'docs/architecture/native-pipeline-consolidation-2026-11-12.md',
    'python/tests/test_native_primitive_binding.py',
    'python/tests/test_native_wide_schema_binding.py',
    'shardloom-cli/src/public_relational_native_declaration.rs',
    'shardloom-cli/src/public_relational_sources.rs',
    'shardloom-cli/src/public_resident_relational.rs',
    'shardloom-cli/src/public_resident_sql.rs',
}
assert changed == expected, sorted(changed)
name = 'cli-pipeline-tests-r9'
path, log = OUT / (name + '.json'), OUT / 'logs' / (name + '.log')
check = read(path)
assert check['status'] == 'passed' and check['returncode'] == 0
assert check['sources_unchanged'] and check['process_group_drained'] and check['direct_child_reaped']
assert check['source_files'] == snapshot
assert check['command'] == ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-cli',
    '-p', 'shardloom-python', '--all-targets', '--features', 'release-user-surfaces']
text = log.read_text()
assert not re.search(r'^test .+ \.\.\. FAILED$', text, re.M)
summaries = [tuple(map(int, row)) for row in re.findall(
    r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)]
assert summaries and sum(row[0] for row in summaries) > 1086
assert sum(row[1] for row in summaries) == 0
for item in (path, log):
    proofs[str(item.relative_to(OUT))] = identity(item)
old_install = read(OUT / 'installed-wheel-r1/integration.json')
assert old_install == dict(tests=441, failures=13, errors=7, skipped=0, status='failed')
installed = read(OUT / 'installed-wheel-r2/report.json')
assert installed['status'] == installed['uninstall_status'] == 'passed'
assert installed['integration']['status'] == 'passed'
assert installed['integration']['tests'] == 441
assert installed['integration']['failures'] == installed['integration']['errors'] == installed['integration']['skipped'] == 0
for name in ('installed-wheel-r1.json', 'installed-wheel-r1/report.json',
             'installed-wheel-r1/integration.json', 'installed-wheel-r1/integration.log',
             'installed-wheel-r2.json', 'installed-wheel-r2/report.json',
             'installed-wheel-r2/integration.json', 'installed-wheel-r2/integration.log'):
    proofs[name] = identity(OUT / name)
proofs[Path(__file__).name] = identity(Path(__file__))
record = dict(status='passed', scope='original_complete_native_suite_plus_test_repair_and_changed_cli_package_rechecks',
    original_full_run_status=previous['original_full_run_status'],
    original_failures=previous['original_failures'], original_passed=previous['original_passed'],
    original_failed=previous['original_failed'], original_ignored=previous['original_ignored'],
    all_original_failures_passed_in_focused_rechecks=True,
    non_cli_production_source_unchanged=True, changed_native_cli_targets_rechecked=True,
    changed_files=sorted(changed), source_files=snapshot,
    source_fingerprint_sha256=fingerprint(snapshot), proofs=proofs,
    full_native_suite_repeated=False, final_native_cli_tests_passed=sum(row[0] for row in summaries),
    final_native_cli_tests_ignored=sum(row[2] for row in summaries),
    original_installed_result=old_install, final_installed_result=installed['integration'],
    rationale='The Vortex engine and every other non-CLI production input are byte-identical to the reconciled complete native run. Only CLI alias/report compatibility, two Python expectations and explanatory documentation changed. All native CLI/Python Rust targets and the complete isolated 441-test installed suite were rerun, with the final workspace lint/default checks recorded separately. Original failed observations remain failed and retained.',
    native_benchmark_queries_executed=0)
with destination.open('x') as stream:
    json.dump(record, stream, indent=2); stream.write('\n')
print(json.dumps({key: record[key] for key in ('status', 'non_cli_production_source_unchanged',
    'changed_native_cli_targets_rechecked', 'final_native_cli_tests_passed', 'final_installed_result')}))
