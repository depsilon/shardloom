"""Freeze the guarded release output without executing any query."""
import json
import shutil

from guard_checks import CACHE, OUT, sources
from pipeline_runtime import fingerprint, git, identity, read

build_path = OUT / 'release-build-r1.json'
build = read(build_path)
assert build['status'] == 'passed' and build['returncode'] == 0
assert build['sources_unchanged'] and build['process_group_drained'] and build['direct_child_reaped']
assert build['command'] == ['cargo', 'build', '--offline', '--locked', '--release', '--features',
    'release-user-surfaces', '-p', 'shardloom-cli', '-p', 'shardloom-python']
assert build['source_files'] == sources() and not git('status', '--porcelain')
destination = OUT / 'runtime-r1'
receipt = OUT / 'runtime-r1-identity.json'
assert not destination.exists() and not receipt.exists()
originals = {name: identity(CACHE / 'release' / name) for name in ('shardloom', 'lib_native.dylib')}
destination.mkdir()
files = {}
for target, original in [('shardloom', 'shardloom'), ('lib_native.dylib', 'lib_native.dylib'),
                         ('_native.abi3.so', 'lib_native.dylib')]:
    path = destination / target
    shutil.copy2(CACHE / 'release' / original, path)
    assert identity(path) == originals[original] == identity(CACHE / 'release' / original)
    files[str(path)] = identity(path)
assert build['source_files'] == sources()
record = dict(status='passed', profile='release', source_commit=git('rev-parse', 'HEAD'),
    source_tree=git('rev-parse', 'HEAD^{tree}'), source_fingerprint_sha256=fingerprint(build['source_files']),
    build_receipt=build_path.name, build_receipt_identity=identity(build_path), files=files,
    freezer=identity(__import__('pathlib').Path(__file__)), native_query_executions=0)
with receipt.open('x') as stream:
    json.dump(record, stream, indent=2); stream.write('\n')
print(json.dumps({key: record[key] for key in ('status', 'source_commit', 'native_query_executions')}))
