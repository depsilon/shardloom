"""Verify the final native completion-report compatibility correction."""
from pathlib import Path
import subprocess
import sys

out = Path(__file__).resolve().parent
checks = [
    ('fmt-final-r5', ['cargo', 'fmt', '--all', '--', '--check']),
    ('default-clippy-final-r5', ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('default-tests-final-r5', ['cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets']),
    ('native-clippy-final-r5', ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--features', 'shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment', '--', '-D', 'warnings']),
    ('cli-pipeline-tests-r10', ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-cli', '-p', 'shardloom-python', '--all-targets', '--features', 'release-user-surfaces']),
]
for name, command in checks:
    print(name, flush=True)
    subprocess.run([sys.executable, str(out / 'guard_checks.py'), '--name', name,
        '--timeout', '2400', '--', *command], check=True)
