"""Replay saved results and clocks, including every failure; execute no query."""
from collections import Counter, defaultdict
from contextlib import ExitStack
import gzip
import json
import math
from pathlib import Path

import pipeline_runtime
import run_10k as current
from query_timing_report import query_phase_timings
from query_surface.corpus import corpus
from query_surface.evidence import identity
from query_surface.expanded_catalog import build, spaces
from query_surface.expanded_freeze import read, unpack
from query_surface.expanded_report import raw_files, replay
from query_surface.expanded_run import closing_db, verify

PRIOR = current.OUT.parent / 'current-state-uat-2026-11-12/full10k-r1'
PRIOR_CASE_HASH = 'df556f111e16c44eec083f83e4a5f53f9d713bb8e62230d5a4e84ae40b77726d'


def verify_clock(entry, record):
    response = json.loads(raw_files(unpack(entry[3]))['one.stdout.json'])
    report = response['observation']
    fields = query_phase_timings(report['fields'], report['clocks']['complete_workflow_seconds'])
    value = fields['engine_execution_seconds']
    assert type(value) in (int, float) and math.isfinite(value) and value >= 0
    assert report['clocks']['engine_timing_reported'] is True
    assert value == record['engine_seconds'] == report['clocks']['engine_execution_seconds']
    assert fields['result_serialization_seconds'] == report['clocks']['result_serialization_seconds']


def main():
    assert __debug__
    target = current.TARGET
    destination = target / 'verified-summary-r1.json'
    cases_path = target / 'verified-cases-r1.jsonl.gz'
    partial = target / 'verified-cases-r1.partial.jsonl.gz'
    assert not any(path.exists() for path in (destination, cases_path, partial))
    design, inputs, frozen, admitted = current.updated_admission(current.E)
    done, binding = read(target / 'complete.json'), read(target / 'binding.json')
    assert done['status'] == 'complete_observation' and done['stage'] == 'native'
    assert done['total'] == done['attempt_slots'] == 10000
    assert done['attempts_per_case'] == 1 and done['requested_repeats'] == 0 and done['posthash_verified']
    assert done['updated'] == admitted
    assert binding['contract'] == {key: done[key] for key in ('frozen', 'stage', 'prerequisites', 'updated')}
    verify([done['ledger'], done['binding'], done['frozen']])
    prior_path = PRIOR / 'verified-summary-r1.json'
    prior = read(prior_path)
    assert prior['status'] == 'passed_complete_current_runtime_observation'
    assert prior['complete_results'] == 10000 and prior['all_engine_clocks_valid']
    assert prior['independent_expected_results_replayed'] and prior['native_no_fallback']
    assert prior['engine_execution_seconds'] == 1540.711839539
    prior_cases = PRIOR / 'verified-cases-r1.jsonl.gz'
    assert identity(prior_cases) == prior['case_rows']
    assert pipeline_runtime.identity(prior_cases)['sha256'] == PRIOR_CASE_HASH
    prepared = read(current.E / 'native-preparation/complete.json')
    originals = {item.id: item for item in corpus(interactions='all', include_pending=False)}
    definitions = {spec.name: spec for spec in spaces()}
    seen, successes, matched_old, failed_old, all_old = [], [], [], [], []
    outcomes, families = Counter(), defaultdict(lambda: defaultdict(list))
    rejected_old, other_failed_old = [], []
    failure_groups = defaultdict(lambda: dict(cases=0, previous_engine_seconds=[], examples=[]))
    lock = target / '.pipeline-offline-replay.lock'
    with lock.open('x'):
        pass
    with ExitStack() as stack:
        store = stack.enter_context(closing_db(target / 'attempts.sqlite', readonly=True))
        entries = iter(store.execute('SELECT seq,id,status,packet FROM attempt ORDER BY seq'))
        references = {profile: stack.enter_context(closing_db(
            current.E / ('reference-' + profile) / 'expectations.sqlite', readonly=True))
            for profile in {row['profile'] for row in design['cases']}}
        previous = iter(stack.enter_context(gzip.open(prior_cases, 'rt', encoding='utf-8')))
        output = stack.enter_context(gzip.open(partial, 'wt', encoding='utf-8'))
        for ordinal, row in enumerate(design['cases']):
            item = build(row, definitions) if 'cell' in row else originals[row['id']]
            expected_identity, expected_blob = references[row['profile']].execute(
                'SELECT identity,value FROM expected WHERE id=?', (item.id,)).fetchone()
            assert expected_identity == item.identity == row['case_identity']
            entry = next(entries, None)
            old = json.loads(next(previous))
            assert entry is not None and entry[:2] == (ordinal, item.id)
            assert (old['seq'], old['id']) == (ordinal, item.id)
            assert (old['family'], old['profile'], old['surface']) == (row['family'], row['profile'], row['surface'])
            assert old['current']['status'] == 'passed'
            old_time = old['current']['engine_seconds']
            assert type(old_time) in (int, float) and math.isfinite(old_time) and old_time >= 0
            record = replay(entry, row, 'native', unpack(expected_blob), item, inputs, prepared, design['execution'])
            seen.append(item.id)
            outcomes[record['status']] += 1
            all_old.append(old_time)
            if record['status'] == 'passed':
                verify_clock(entry, record)
                successes.append(record['engine_seconds'])
                matched_old.append(old_time)
                families[row['family']]['successful_engine_seconds'].append(record['engine_seconds'])
                families[row['family']]['previous_same_successful_cases_engine_seconds'].append(old_time)
            else:
                failed_old.append(old_time)
                (rejected_old if record['status'] == 'engine_rejected' else other_failed_old).append(old_time)
                families[row['family']]['previous_failed_cases_engine_seconds'].append(old_time)
                key = (record['status'], row['family'], str(record.get('failure_detail')))
                group = failure_groups[key]
                group['cases'] += 1
                group['previous_engine_seconds'].append(old_time)
                if len(group['examples']) < 5:
                    group['examples'].append(item.id)
            output.write(json.dumps(dict(seq=ordinal, id=item.id, family=row['family'], profile=row['profile'],
                surface=row['surface'], current=record, previous_engine_seconds=old_time),
                separators=(',', ':'), allow_nan=False) + '\n')
        assert next(entries, None) is None and next(previous, None) is None
    assert seen == [row['id'] for row in design['cases']] and len(set(seen)) == 10000
    assert dict(outcomes) == done['outcomes']
    assert math.fsum(all_old) == prior['engine_execution_seconds']
    verify(frozen)
    assert identity(target / 'attempts.sqlite') == done['ledger']
    assert identity(prior_cases) == prior['case_rows']
    partial.rename(cases_path)
    failures = [dict(status=status, family=family, detail=detail, cases=group['cases'],
        previous_engine_seconds=math.fsum(group['previous_engine_seconds']), examples=group['examples'])
        for (status, family, detail), group in sorted(failure_groups.items())]
    result = dict(status='passed_offline_replay', query_executions_during_replay=0,
        source_commit=current.MERGE, source_tree=current.TREE, attempted_cases=10000,
        successful_cases=len(successes), unsuccessful_cases=len(failed_old), outcomes=dict(outcomes),
        primary_clock='engine_execution_seconds', successful_engine_seconds=math.fsum(successes),
        previous_same_successful_cases_engine_seconds=math.fsum(matched_old),
        previous_unsuccessful_cases_engine_seconds=math.fsum(failed_old),
        previous_rejected_cases_engine_seconds=math.fsum(rejected_old),
        previous_other_unsuccessful_cases_engine_seconds=math.fsum(other_failed_old),
        previous_complete_engine_seconds=math.fsum(all_old),
        complete_10000_engine_seconds=math.fsum(successes) if len(successes) == 10000 else None,
        newly_rejected_cases=outcomes['engine_rejected'],
        other_unsuccessful_cases=sum(value for key, value in outcomes.items() if key not in ('passed', 'engine_rejected')),
        attempts_per_case=1, requested_repeats=0, all_successful_engine_clocks_valid=True,
        independent_expected_results_replayed=True, successful_native_no_fallback=True,
        failure_groups=failures,
        families={name: {key: dict(cases=len(values), engine_seconds=math.fsum(values))
            for key, values in sorted(groups.items())} for name, groups in sorted(families.items())},
        comparison_limitation='One original-order observation per runtime, same case IDs and engine clock; no repeatability or individual-change attribution claim.',
        missing_support_policy='Engine rejection is preserved as engine_rejected; engine errors, incorrect answers, resource limits and harness failures are reported separately.',
        case_rows=identity(cases_path), complete=identity(target / 'complete.json'), ledger=done['ledger'],
        previous_summary=identity(prior_path), previous_case_rows=prior['case_rows'],
        protocol=identity(current.PROTOCOL), verifier=identity(Path(__file__)))
    with destination.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False); stream.write('\n')
    lock.unlink()
    print(json.dumps({key: result[key] for key in ('status', 'successful_cases', 'unsuccessful_cases', 'outcomes',
        'successful_engine_seconds', 'previous_same_successful_cases_engine_seconds',
        'previous_unsuccessful_cases_engine_seconds', 'complete_10000_engine_seconds')}))


if __name__ == '__main__':
    main()
