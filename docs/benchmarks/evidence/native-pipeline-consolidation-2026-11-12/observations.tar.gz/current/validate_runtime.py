"""Admit the tested local runtime before the single original-case capture."""
import json

from pipeline_runtime import OUT, identity, read, verify

assert __debug__
destination = OUT / 'validation-before-10k.json'
assert not destination.exists()
build = read(OUT / 'release-build-r3.json')
runtime = read(OUT / 'runtime-r3-identity.json')
checks = [
    'fmt-final-r5.json',
    'default-clippy-final-r5.json',
    'default-tests-final-r5.json',
    'native-clippy-final-r5.json',
    'cli-pipeline-tests-r10.json',
    'installed-wheel-r3.json',
]
for name in checks:
    check = read(OUT / name)
    assert check['status'] == 'passed' and check['returncode'] == 0, name
    assert check['sources_unchanged'] and check['process_group_drained'], name
    assert check['source_files'] == build['source_files'], name
report = read(OUT / 'installed-wheel-r3/report.json')
reconciliation = read(OUT / 'native-test-reconciliation-r3.json')
assert reconciliation['status'] == 'passed'
assert reconciliation['non_cli_production_source_unchanged']
assert reconciliation['changed_native_cli_targets_rechecked']
assert reconciliation['all_original_failures_passed_in_focused_rechecks']
assert reconciliation['source_files'] == build['source_files']
assert report['status'] == 'passed' and report['installation_performed']
assert report['publication_attempted'] is False
assert report['uninstall_status'] == 'passed'
assert report['integration']['status'] == 'passed'
assert report['integration']['tests'] > 0
assert report['integration']['failures'] == report['integration']['errors'] == report['integration']['skipped'] == 0
assert report['integrity']['native_library_sha256'] == identity(OUT / 'runtime-r3/_native.abi3.so')['sha256']
assert report['integrity']['cli_sha256'] == identity(OUT / 'runtime-r3/shardloom')['sha256']
record = dict(status='passed', source_commit=runtime['source_commit'],
    source_tree=runtime['source_tree'], runtime=identity(OUT / 'runtime-r3-identity.json'),
    checks={name: identity(OUT / name) for name in checks},
    installed_checks={'installed-wheel-r3/report.json': identity(OUT / 'installed-wheel-r3/report.json')},
    native_suite_reconciliation={'name': 'native-test-reconciliation-r3.json',
        'identity': identity(OUT / 'native-test-reconciliation-r3.json')},
    installed_tests=report['integration'], native_query_observation_started=False,
    performance_claim=False, publication_attempted=False)
with destination.open('x') as stream:
    json.dump(record, stream, indent=2); stream.write('\n')
proof = verify()
print(json.dumps({key: proof[key] for key in ('head', 'locally_validated', 'published', 'runtime_rebuilt')}))
