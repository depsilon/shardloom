"""Bound compilation and correctness checks for the unified native pipeline."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
OUT = Path('/Users/dylan/LocalData/shardloom/native-pipeline-consolidation-2026-11-12')
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
sys.path[:0] = [str(ROOT / 'scripts'), '/Users/dylan/LocalData/shardloom/release-0.3.3-20260930']
from local_uat_storage import GIB, MIB, accounted_bytes, available_bytes, check_budgets, require_local_path
from release_validation_guard import WorkloadGuard

helper = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
assert hashlib.sha256(helper.read_bytes()).hexdigest() == '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97'
spec = importlib.util.spec_from_file_location('bounded_supervisor', helper)
supervisor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(supervisor)
ENV = dict(os.environ,
    PATH='/Users/dylan/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/Users/dylan/.cargo/bin:/opt/homebrew/opt/python@3.13/libexec/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
    CARGO_TARGET_DIR=str(CACHE), CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0',
    CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
    PYTHONPATH='python/src:scripts', PYTHONDONTWRITEBYTECODE='1', CARGO_TERM_COLOR='never',
    RUST_TEST_THREADS='4', PYO3_PYTHON='/opt/homebrew/opt/python@3.13/libexec/bin/python3')

def sources():
    paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=ROOT).decode().split('\0')
    result = {}
    for name in sorted(set(paths) - {''}):
        if name.startswith(('docs/benchmarks/evidence/', 'docs/release/evidence/', 'docs/dependencies/evidence/')):
            continue
        path = ROOT / name
        if path.is_symlink():
            result[name] = {'symlink': os.readlink(path)}
        elif path.is_file():
            with path.open('rb') as stream:
                result[name] = {'sha256': hashlib.file_digest(stream, 'sha256').hexdigest(), 'bytes': path.stat().st_size}
        else:
            result[name] = {'absent': True}
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--name', required=True)
    parser.add_argument('--timeout', type=float, default=2400)
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    assert __debug__ and args.name.replace('-', '').isalnum() and args.timeout > 0
    command = args.command[1:] if args.command[:1] == ['--'] else args.command
    assert command and not (OUT / (args.name + '.json')).exists()
    for path in (OUT, CACHE):
        require_local_path(path, Path.home(), sys.platform)
    (OUT / 'logs').mkdir(exist_ok=True)
    check_budgets(OUT, OUT / 'reserved-artifact', OUT / 'logs', min_free_bytes=12 * GIB,
                  reserve_bytes=128 * MIB, max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    workload = WorkloadGuard()
    workload.check()
    metadata = json.loads(subprocess.check_output(['cargo', 'metadata', '--offline', '--locked', '--no-deps', '--format-version', '1'], cwd=ROOT, env=ENV, timeout=30))
    assert metadata['target_directory'] == str(CACHE)
    before = sources()
    evidence = dict(command=command, cwd=str(ROOT), target_directory=str(CACHE),
                    source_files=before, status='running')
    evidence['head'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    evidence['source_tree'] = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip()
    evidence['working_tree'] = subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True)
    evidence['environment'] = {key: ENV[key] for key in (
        'PATH', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL',
        'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG', 'PYTHONPATH',
        'PYTHONDONTWRITEBYTECODE', 'CARGO_TERM_COLOR', 'RUST_TEST_THREADS', 'PYO3_PYTHON')}
    evidence['rustc_version'] = subprocess.check_output(
        ['rustc', '-vV'], env=ENV, text=True, timeout=30)
    evidence['cargo_version'] = subprocess.check_output(
        ['cargo', '-V'], env=ENV, text=True, timeout=30).strip()
    evidence['guard_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    last_inventory = [0.0]
    def guard():
        workload.check(evidence.get('pid'))
        if available_bytes(OUT) < 12 * GIB:
            raise RuntimeError('free storage below 12 GiB')
        if time.monotonic() - last_inventory[0] > 15:
            last_inventory[0] = time.monotonic()
            if accounted_bytes(CACHE) > 100 * GIB or accounted_bytes(OUT) > 100 * GIB:
                raise RuntimeError('generated workspace exceeds 100 GiB')
    rc = 1
    try:
        with (OUT / 'logs' / (args.name + '.log')).open('xb') as output:
            rc = supervisor.run(command, cwd=ROOT, env=ENV, output=output,
                                timeout=args.timeout, evidence=evidence, guard=guard)
        evidence['sources_unchanged'] = sources() == before
        assert evidence['sources_unchanged'], 'source changed during check'
        evidence['status'] = 'passed' if rc == 0 else 'failed'
    except BaseException as error:
        evidence.update(status='failed', supervisor_error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        (OUT / (args.name + '.json')).write_text(json.dumps(evidence, sort_keys=True, indent=2) + '\n')
        print(json.dumps({key: evidence.get(key) for key in ('status', 'returncode', 'sources_unchanged', 'process_group_drained')}), flush=True)
    return rc

if __name__ == '__main__':
    raise SystemExit(main())
