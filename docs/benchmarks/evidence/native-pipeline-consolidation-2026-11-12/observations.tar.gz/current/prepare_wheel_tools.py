"""Prepare a task-local, hash-pinned wheel proof environment; execute no queries."""
import json
from pathlib import Path
import subprocess
import sys

from guard_checks import ROOT, OUT, ENV, supervisor
from local_uat_storage import GIB, accounted_bytes, available_bytes, require_local_path
from pipeline_runtime import identity

assert __debug__
destination = OUT / 'wheel-tools-r1'
require_local_path(destination, Path.home(), sys.platform)
assert not destination.exists()
destination.mkdir()
wheelhouse = destination / 'wheelhouse'
wheelhouse.mkdir()
environment = destination / 'venv'
evidence = dict(status='running', native_query_executions=0,
    concurrent_native_correctness_tests=True, steps=[])

def storage_guard():
    assert available_bytes(OUT) >= 12 * GIB, 'free storage below 12 GiB'
    assert accounted_bytes(destination) <= GIB, 'tool environment exceeds 1 GiB'

commands = [
    ('download', [sys.executable, '-m', 'pip', 'download', '--disable-pip-version-check',
        '--no-cache-dir', '--only-binary=:all:', '--require-hashes', '--dest', str(wheelhouse),
        '-r', str(ROOT / '.github/requirements/ci-native-python-build.txt'),
        '-r', str(ROOT / '.github/requirements/ci-native-python.txt')]),
    ('create-environment', [sys.executable, '-m', 'venv', str(environment)]),
    ('install-build-tools', [str(environment / 'bin/python'), '-I', '-m', 'pip',
        'install', '--disable-pip-version-check', '--no-cache-dir', '--no-index',
        '--find-links', str(wheelhouse), '--only-binary=:all:', '--require-hashes',
        '-r', str(ROOT / '.github/requirements/ci-native-python-build.txt')]),
]
try:
    for name, command in commands:
        step = dict(name=name, command=command)
        evidence['steps'].append(step)
        with (destination / (name + '.log')).open('xb') as log:
            code = supervisor.run(command, cwd=destination, env=ENV, output=log,
                timeout=900, evidence=step, guard=storage_guard)
        assert code == 0 and step['process_group_drained'], name
        step['status'] = 'passed'
    evidence['wheels'] = {p.name: identity(p) for p in sorted(wheelhouse.glob('*.whl'))}
    evidence['status'] = 'passed'
except BaseException as error:
    evidence.update(status='failed', error=repr(error))
    raise
finally:
    (destination / 'report.json').write_text(json.dumps(evidence, indent=2) + '\n')
    print(json.dumps({k: evidence[k] for k in ('status', 'native_query_executions')}))
