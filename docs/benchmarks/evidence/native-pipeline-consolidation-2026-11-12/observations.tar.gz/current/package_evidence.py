"""Package compact immutable observations, excluding generated runtime payloads."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
DEST = ROOT / 'docs/benchmarks/evidence/native-pipeline-consolidation-2026-11-12'
PRIOR = OUT.parent / 'current-state-uat-2026-11-12/full10k-r1'
ORIGINAL = OUT.parent / 'expanded-query-2026-11-03'
HEAD = '3a861917ad6852e6a35ac8642d78c4d31451f29f'
BASE = '8b84361fe26afc816a9ad252ed95fffa1a7f99e8'


def identity(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    assert __debug__ and not (DEST / 'manifest.json').exists()
    assert (DEST / 'README.md').is_file() and (DEST / 'verify.py').is_file()
    direct = {
        'summary.json': OUT / 'full10k-r1/verified-summary-r1.json',
        'cases.jsonl.gz': OUT / 'full10k-r1/verified-cases-r1.jsonl.gz',
        'previous-summary.json': PRIOR / 'verified-summary-r1.json',
        'previous-cases.jsonl.gz': PRIOR / 'verified-cases-r1.jsonl.gz',
        'certificates.jsonl.gz': OUT / 'full10k-r1/certificate-cases-r1.jsonl.gz',
        'pipeline-audit.json': OUT / 'full10k-r1/pipeline-certificate-audit-r1.json',
        'validation-inventory.json': OUT / 'validation-inventory-r1.json',
    }
    origins = {}
    for name, path in direct.items():
        assert path.is_file() and not path.is_symlink()
        raw = path.read_bytes()
        with (DEST / name).open('xb') as stream:
            stream.write(raw)
        assert (DEST / name).read_bytes() == path.read_bytes()
        origins[name] = str(path)
    members = {}
    def add(path, name):
        assert path.is_file() and not path.is_symlink() and name not in members
        raw = path.read_bytes()
        members[name] = (raw, str(path))
    for path in sorted(OUT.iterdir()):
        if path.is_file() and path.suffix in {'.json', '.log', '.py', '.patch', '.txt'}:
            add(path, 'current/' + path.name)
    for name in ('logs', 'test-expectation-before-r1', 'retirement-r1'):
        for path in sorted((OUT / name).rglob('*')):
            if path.is_file():
                add(path, 'current/' + str(path.relative_to(OUT)))
    for name in ('installed-wheel-r1', 'installed-wheel-r2', 'installed-wheel-r3', 'wheel-tools-r1'):
        for path in sorted((OUT / name).iterdir()):
            if path.is_file():
                add(path, 'current/' + str(path.relative_to(OUT)))
    for name in ('complete.json', 'binding.json', 'certificate-export-r1.json'):
        add(OUT / 'full10k-r1' / name, 'current/full10k-r1/' + name)
    for name in ('design.json', 'inputs.json', 'frozen.json'):
        add(ORIGINAL / name, 'original/' + name)
    add(ORIGINAL / 'native-preparation/complete.json', 'original/native-preparation/complete.json')
    add(ORIGINAL / 'tools/retire_shared_intermediates_r2.py', 'helpers/retire_shared_intermediates_r2.py')
    patch = subprocess.check_output(['git', 'diff', '--binary', BASE, HEAD], cwd=ROOT)
    members['source/implementation.patch'] = (patch, 'git diff ' + BASE + ' ' + HEAD)
    metadata = dict(base=BASE, source_commit=HEAD,
                    source_tree=subprocess.check_output(['git', 'rev-parse', HEAD + '^{tree}'], cwd=ROOT, text=True).strip(),
                    publication_attempted=False,
                    implementation_commits=subprocess.check_output(['git', 'log', '--format=%H %s', BASE + '..' + HEAD], cwd=ROOT, text=True).splitlines())
    members['source/commits.json'] = ((json.dumps(metadata, indent=2) + '\n').encode(), 'local Git history')
    archive_path = DEST / 'observations.tar.gz'
    with archive_path.open('xb') as raw_stream:
        with gzip.GzipFile(fileobj=raw_stream, mode='wb', filename='', mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w') as archive:
                for name, (raw, _) in sorted(members.items()):
                    info = tarfile.TarInfo(name)
                    info.size, info.mode, info.mtime = len(raw), 0o644, 0
                    archive.addfile(info, io.BytesIO(raw))
    with tarfile.open(archive_path, 'r:gz') as archive:
        assert set(archive.getnames()) == set(members)
        for member in archive.getmembers():
            assert archive.extractfile(member).read() == members[member.name][0]
    files = {path.name: identity(path.read_bytes()) for path in sorted(DEST.iterdir()) if path.is_file()}
    manifest = dict(schema='shardloom.native_pipeline_compact_evidence.v1',
                    source_commit=HEAD, source_tree=metadata['source_tree'], files=files,
                    archive_members={name: dict(**identity(raw), origin=origin) for name, (raw, origin) in sorted(members.items())},
                    direct_origins=origins, query_executions_during_packaging=0,
                    full_correctness_replay='Completed against all original independent reference ledgers; raw result/reference ledgers remain local.',
                    compact_verification='Hashes, exact case/order matching, engine clocks, selected raw certificate fields and recorded validation history; not independent full-answer replay.',
                    published=False)
    with (DEST / 'manifest.json').open('x') as stream:
        json.dump(manifest, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status='packaged_readback_verified', packet_files=len(files),
                         archive_members=len(members), archive_bytes=archive_path.stat().st_size,
                         total_bytes=sum(value['bytes'] for value in files.values()), query_executions=0)))


if __name__ == '__main__':
    main()
