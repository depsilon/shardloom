"""Verify complete native coverage plus the isolated correction of four test expectations."""
import json
import re
from pathlib import Path

from pipeline_runtime import OUT, ROOT, fingerprint, identity, read, sources

assert __debug__
destination = OUT / 'native-test-reconciliation-r1.json'
assert not destination.exists()
full_path = OUT / 'native-tests-final.json'
full = read(full_path)
assert full['status'] == 'failed' and full['returncode'] == 101
assert full['sources_unchanged'] and full['process_group_drained'] and full['direct_child_reaped']
assert not full['timed_out'] and full['interrupted_signal'] is None
full_log = OUT / 'logs/native-tests-final.log'
text = full_log.read_text()
prefix = 'local_primitives::prepared_relational::tests::'
expected_failed = {
    prefix + 'expression_tests::identity_project_tests::native_identity_projection_keeps_reordered_renamed_subset_and_computed_fields',
    prefix + 'expression_tests::identity_project_tests::native_identity_projection_normalizes_nested_nullable_and_empty_input',
    prefix + 'provider_tests::prepared_file_prefix_requires_every_projected_integer_to_be_a_sort_key',
    prefix + 'provider_tests::shared_provider_file_filter_and_alias_projection_use_native_scan',
}
failed = re.findall(r'^test (.+) \.\.\. FAILED$', text, re.M)
assert len(failed) == 4 and set(failed) == expected_failed
summaries = [tuple(map(int, row)) for row in re.findall(
    r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)]
assert sum(row[1] for row in summaries) == 4
assert 'error: 1 target failed:' in text and '-p shardloom-vortex --lib' in text
snapshot = sources()
expected_changed = {
    'shardloom-vortex/src/local_primitive_relational_identity_project_tests.rs',
    'shardloom-vortex/src/local_primitive_relational_provider_tests.rs',
}
changed = {name for name in set(snapshot) | set(full['source_files'])
           if snapshot.get(name) != full['source_files'].get(name)}
assert changed == expected_changed, changed
for name in changed:
    assert identity(OUT / 'test-expectation-before-r1' / Path(name).name) == full['source_files'][name]
owner = (ROOT / 'shardloom-vortex/src/local_primitive_prepared_relational.rs').read_text()
assert '#[cfg(all(test, feature = "vortex-write"))]\n#[path = "local_primitive_relational_tests.rs"]\nmod tests;' in owner
proofs = {full_path.name: identity(full_path), str(full_log.relative_to(OUT)): identity(full_log)}
for path in (OUT / 'test-expectation-before-r1').iterdir():
    proofs[str(path.relative_to(OUT))] = identity(path)
passed = set()
focused_counts = {}
for name in ('native-tests-identity-r1', 'native-tests-provider-r1'):
    path, log = OUT / (name + '.json'), OUT / 'logs' / (name + '.log')
    check = read(path)
    assert check['status'] == 'passed' and check['returncode'] == 0, name
    assert check['sources_unchanged'] and check['process_group_drained'] and check['direct_child_reaped']
    assert check['source_files'] == snapshot
    assert check['command'][:8] == full['command'][:8]
    assert check['command'][8:] == [
        'identity_project_tests' if name == 'native-tests-identity-r1'
        else 'prepared_relational::tests::provider_tests']
    result = log.read_text()
    assert not re.search(r'^test .+ \.\.\. FAILED$', result, re.M)
    names = set(re.findall(r'^test (.+) \.\.\. ok$', result, re.M))
    assert names
    passed.update(names)
    focused_counts[name] = len(names)
    proofs[path.name] = identity(path)
    proofs[str(log.relative_to(OUT))] = identity(log)
assert expected_failed <= passed, sorted(expected_failed - passed)
patch = OUT / 'test-expectation-repair-r1.patch'
proofs[patch.name] = identity(patch)
proofs[Path(__file__).name] = identity(Path(__file__))
record = dict(status='passed', scope='full_native_run_plus_test_expectation_repair',
    original_full_run_status='failed', original_failures=sorted(failed),
    original_passed=sum(row[0] for row in summaries),
    original_failed=sum(row[1] for row in summaries),
    original_ignored=sum(row[2] for row in summaries),
    all_original_failures_passed_in_focused_rechecks=True,
    focused_passed=focused_counts, production_source_unchanged=True,
    changed_test_only_files=sorted(changed), source_files=snapshot,
    source_fingerprint_sha256=fingerprint(snapshot), proofs=proofs,
    full_native_suite_repeated=False,
    rationale='Only two cfg(test) files changed after the full run. Normalized declaration checks use semantic_kind; the prefix test checks both compiled and reference paths. Exact values, schema, null and ownership assertions remain. All other source inputs match the full run byte-for-byte.',
    native_benchmark_queries_executed=0)
with destination.open('x') as stream:
    json.dump(record, stream, indent=2); stream.write('\n')
print(json.dumps({key: record[key] for key in ('status', 'original_passed', 'original_failed',
    'original_ignored', 'focused_passed', 'production_source_unchanged')}))
