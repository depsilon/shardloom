"""Run the remaining checks sequentially against the unchanged final source."""
from pathlib import Path
import subprocess
import sys

out = Path(__file__).resolve().parent
checks = [
    ('fmt-final-r4', ['cargo', 'fmt', '--all', '--', '--check']),
    ('default-clippy-final-r4', ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('default-tests-final-r4', ['cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets']),
    ('cli-pipeline-tests-r9', ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-cli', '-p', 'shardloom-python', '--all-targets', '--features', 'release-user-surfaces']),
]
for name, command in checks:
    print(name, flush=True)
    subprocess.run([sys.executable, str(out / 'guard_checks.py'), '--name', name,
        '--timeout', '2400', '--', *command], check=True)
