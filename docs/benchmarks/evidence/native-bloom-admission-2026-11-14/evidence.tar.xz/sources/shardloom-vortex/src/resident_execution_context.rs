//! A borrowed operation boundary; nested operators use this grant directly.

use super::{
    CallClass, RuntimeOwner, SourceIdentity,
    io_ownership::{IoBudget, IoScope},
    resident_error,
    serving_admission::Permit,
};
use futures::FutureExt as _;
use shardloom_core::Result;
use shardloom_exec::{compute_pool::CancellationToken, live_memory::MemoryLease};
use std::{
    borrow::Cow,
    sync::{Arc, Mutex, MutexGuard, OnceLock},
    time::{Duration, Instant},
};
use vortex::array::scalar_fn::fns::binary::observation::{CompareWork, CompareWorkScope};
use vortex::{
    error::{SharedVortexResult, vortex_err},
    file::{
        OpenOptionsSessionExt as _, SegmentMap, VortexFile,
        segments::{FileSegmentSource, RequestMetrics},
    },
    io::runtime::BlockingRuntime as _,
    layout::segments::{SegmentFuture, SegmentId, SegmentSource, SharedSegmentSource},
    session::{SessionExt as _, VortexSession},
};

enum Gate<'a> {
    Exclusive(MutexGuard<'a, ()>, Duration),
    Serving(Permit),
}

/// Per-call native timings. Service includes generation checks and scoped I/O
/// drain, but excludes caller-side result conversion and admission-guard drop.
#[derive(Debug, Clone, Copy)]
pub struct ResidentCallTiming {
    pub queue: Duration,
    pub service: Duration,
}

/// Borrowed CPU, cancellation and I/O ownership for one admitted native operation.
/// It cannot be constructed or cloned by an operator. Nested operators borrow it
/// rather than reacquiring request admission. A callback must join its own compute
/// jobs before returning. Running OS reads drain before this grant is released.
pub struct NativeExecutionContext<'a> {
    owner: &'a RuntimeOwner,
    class: CallClass,
    operation: u64,
    cancellation: CancellationToken,
    io: OnceLock<Arc<IoScope>>,
    admitted: Instant,
    gate: Gate<'a>,
    opened_sources: Mutex<OpenedSources>,
    adaptive_work: Mutex<crate::native_work_sizing::Reports>,
    capability_decisions: Mutex<shardloom_core::native_io_decisions::NativeIoCapabilityDecisions>,
    variant_expression_work: Mutex<crate::native_variant::ExpressionWork>,
    dictionary_expression_work: Mutex<crate::native_dictionary_expression::Work>,
    #[cfg_attr(not(all(feature = "vortex-local-primitives", unix)), allow(dead_code))]
    compare_work: Option<CompareWorkScope>,
    join_work: Mutex<shardloom_core::native_join_work::NativeJoinWork>,
    count_partial_work: Mutex<shardloom_core::native_count_partial_work::NativeCountPartialWork>,
    #[cfg(all(feature = "vortex-local-primitives", unix))]
    file_evidence: Arc<Mutex<super::file_evidence::Evidence>>,
}

#[derive(Default)]
struct OpenedSources {
    // Held descriptors and their control credits survive all native reads.
    values: Vec<(Arc<SourceIdentity>, MemoryLease)>,
    capacity: Option<MemoryLease>,
}

impl RuntimeOwner {
    pub(super) fn enter(
        &self,
        class: CallClass,
        cancellation: CancellationToken,
    ) -> Result<NativeExecutionContext<'_>> {
        crate::application_batch::check_application_callback_reentry()?;
        cancellation.check()?;
        let queued = Instant::now();
        let gate = if let Some(admission) = &self.serving {
            Gate::Serving(admission.admit(class, 0, &cancellation)?)
        } else {
            let guard = self
                .admission
                .lock()
                .map_err(|_| resident_error("session admission poisoned"))?;
            Gate::Exclusive(guard, queued.elapsed())
        };
        let admitted = Instant::now();
        cancellation.check()?;
        let operation = self
            .next_operation
            .try_update(
                std::sync::atomic::Ordering::Relaxed,
                std::sync::atomic::Ordering::Relaxed,
                |value| value.checked_add(1),
            )
            .map_err(|_| resident_error("native operation identity overflow"))?;
        let io = if class == CallClass::General {
            self.io_budget
                .as_ref()
                .map(|budget| IoScope::new(Arc::clone(budget), &self.memory, cancellation.clone()))
                .transpose()?
        } else {
            None
        };
        let compare_work = if matches!(&gate, Gate::Exclusive(..)) {
            self.memory.reserve(256).ok().and_then(|credit| {
                self.session
                    .get_opt::<CompareWork>()?
                    .begin(Arc::new(credit))
            })
        } else {
            None
        };
        Ok(NativeExecutionContext {
            owner: self,
            class,
            operation,
            cancellation,
            io: io.map_or_else(OnceLock::new, OnceLock::from),
            admitted,
            gate,
            opened_sources: Mutex::new(OpenedSources::default()),
            adaptive_work: Mutex::default(),
            capability_decisions: Mutex::default(),
            variant_expression_work: Mutex::default(),
            dictionary_expression_work: Mutex::default(),
            compare_work,
            join_work: Mutex::default(),
            count_partial_work: Mutex::default(),
            #[cfg(all(feature = "vortex-local-primitives", unix))]
            file_evidence: Arc::default(),
        })
    }
}

impl NativeExecutionContext<'_> {
    /// Called by the terminal owner after execution and scoped I/O have drained.
    #[cfg(all(feature = "vortex-local-primitives", unix))]
    pub(crate) fn append_encoded_compare_certificate(
        &self,
        certificate: &mut shardloom_core::NativeIoCertificate,
    ) {
        use std::fmt::Write as _;
        let proof = &mut certificate.source_pushdown_report.proof_basis;
        let delta = self
            .compare_work
            .as_ref()
            .and_then(CompareWorkScope::snapshot);
        let Some(delta) = delta else {
            proof.push_str(" native_encoded_compare_scope=unavailable");
            return;
        };
        proof.push_str(" native_encoded_compare_scope=exclusive_operation;successful_adaptor_dispatches;logical_operand_rows;not_unique_rows;decoder_bytes_unobserved;vortex_0.93.0");
        for (family, counts) in ["alp", "bitpacked", "for"]
            .into_iter()
            .zip(delta.as_chunks::<2>().0)
        {
            write!(
                proof,
                " native_encoded_compare_{family}_calls={} native_encoded_compare_{family}_rows={}",
                counts[0], counts[1]
            )
            .expect("String writes cannot fail");
        }
    }

    #[cfg(unix)]
    pub(crate) fn complete_segment_reuse(&self) -> Result<()> {
        self.check_cancelled()?;
        self.owner
            .source_segments
            .complete_operation(self.operation)
    }

    #[cfg(all(feature = "vortex-local-primitives", unix))]
    fn native_file_read_evidence(
        &self,
        identity: &Arc<SourceIdentity>,
    ) -> Result<Arc<super::file_evidence::ReadWork>> {
        self.file_evidence
            .lock()
            .map_err(|_| resident_error("native file execution evidence poisoned"))?
            .source(identity, self.memory())
            .map(|(_, work)| work)
    }

    /// Record the completed logical contract at its execution owner. The caller
    /// credits temporary column vectors; this state credits retained metadata.
    #[cfg(all(feature = "vortex-local-primitives", unix))]
    pub(crate) fn record_native_file_scan(
        &self,
        source: &super::PreparedVortexSource,
        mut contract: shardloom_core::native_file_scan::NativeFileScanContract,
    ) -> Result<()> {
        let Some(identity) = &source.0.identity else {
            return Ok(());
        };
        let mut evidence = self
            .file_evidence
            .lock()
            .map_err(|_| resident_error("native file execution evidence poisoned"))?;
        contract.source = evidence.source(identity, self.memory())?.0;
        evidence.record(contract, self.memory())
    }

    /// Admit source provenance at an executed owner that records by its path,
    /// including a successful pruning decision that requests no data segments.
    #[cfg(all(feature = "vortex-local-primitives", unix))]
    pub(crate) fn register_native_file_scan_source(
        &self,
        source: &super::PreparedVortexSource,
    ) -> Result<()> {
        if let Some(identity) = &source.0.identity {
            self.native_file_read_evidence(identity)?;
        }
        Ok(())
    }

    #[cfg(all(feature = "vortex-local-primitives", unix))]
    pub(crate) fn begin_native_file_scan(
        &self,
        source: &super::PreparedVortexSource,
        mut contract: shardloom_core::native_file_scan::NativeFileScanContract,
    ) -> Result<usize> {
        let identity = source.0.identity.as_ref().ok_or_else(|| {
            resident_error("native file scan evidence requires a held source generation")
        })?;
        let mut evidence = self
            .file_evidence
            .lock()
            .map_err(|_| resident_error("native file execution evidence poisoned"))?;
        contract.source = evidence.source(identity, self.memory())?.0;
        evidence.begin(contract, self.memory())
    }

    #[cfg(all(feature = "vortex-local-primitives", unix))]
    pub(crate) fn begin_native_file_scan_path(
        &self,
        path: &std::path::Path,
        contract: shardloom_core::native_file_scan::NativeFileScanContract,
    ) -> Result<usize> {
        let _temporary = self.memory().reserve(
            (path.as_os_str().len() as u64)
                .checked_mul(4)
                .and_then(|bytes| bytes.checked_add(4096))
                .ok_or_else(|| resident_error("scan evidence path capacity overflow"))?,
        )?;
        let path = std::path::absolute(path).map_err(super::native_error)?;
        self.file_evidence
            .lock()
            .map_err(|_| resident_error("native file execution evidence poisoned"))?
            .begin_path(&path, contract, self.memory())
    }

    #[cfg(all(feature = "vortex-local-primitives", unix))]
    pub(crate) fn add_native_file_scan_rows(&self, index: usize, rows: u64) -> Result<()> {
        self.file_evidence
            .lock()
            .map_err(|_| resident_error("native file execution evidence poisoned"))?
            .add_rows(index, rows)
    }

    #[cfg(all(feature = "vortex-local-primitives", unix))]
    pub(crate) fn take_native_file_scan_evidence(
        &self,
    ) -> Result<(
        shardloom_core::native_file_scan::NativeFileScanEvidence,
        Option<MemoryLease>,
    )> {
        self.drain_io();
        self.check_cancelled()?;
        let (mut report, lease) = self
            .file_evidence
            .lock()
            .map(|mut evidence| evidence.take())
            .map_err(|_| resident_error("native file execution evidence poisoned"))?;
        report.session_segment_cache = Some(self.owner.source_segments.validate_evidence()?);
        Ok((report, lease))
    }

    /// Connect an existing provider path to the held reader in this operation.
    /// This never reopens a source to manufacture provenance.
    #[cfg(all(feature = "vortex-local-primitives", unix))]
    pub(crate) fn record_native_file_scan_path(
        &self,
        path: &std::path::Path,
        contract: shardloom_core::native_file_scan::NativeFileScanContract,
    ) -> Result<()> {
        let bytes = u64::try_from(path.as_os_str().len())
            .ok()
            .and_then(|bytes| bytes.checked_mul(4))
            .and_then(|bytes| bytes.checked_add(4096))
            .ok_or_else(|| resident_error("scan evidence path capacity overflow"))?;
        let _temporary = self.memory().reserve(bytes)?;
        let path = std::path::absolute(path).map_err(super::native_error)?;
        self.file_evidence
            .lock()
            .map_err(|_| resident_error("native file execution evidence poisoned"))?
            .record_path(&path, contract, self.memory())
    }

    pub(crate) fn record_variant_expression(
        &self,
        rows: u64,
        normalized: bool,
        format_bridge: bool,
    ) -> Result<()> {
        self.variant_expression_work
            .lock()
            .map_err(|_| resident_error("Variant expression evidence poisoned"))?
            .record(rows, normalized, format_bridge)
    }

    pub(crate) fn record_native_join_work(
        &self,
        work: shardloom_core::native_join_work::NativeJoinWork,
    ) -> Result<()> {
        self.join_work
            .lock()
            .map_err(|_| resident_error("native join work evidence poisoned"))?
            .merge(work)
    }

    pub(crate) fn record_native_count_partial_work(
        &self,
        work: shardloom_core::native_count_partial_work::NativeCountPartialWork,
    ) -> Result<()> {
        self.count_partial_work
            .lock()
            .map_err(|_| resident_error("native grouped COUNT partial evidence poisoned"))?
            .merge(work)
    }

    pub(crate) fn append_native_count_partial_work(
        &self,
        certificate: &mut shardloom_core::NativeIoCertificate,
    ) -> Result<()> {
        certificate.count_partial_work.merge(
            *self
                .count_partial_work
                .lock()
                .map_err(|_| resident_error("native grouped COUNT partial evidence poisoned"))?,
        )
    }

    pub(crate) fn append_native_join_work(
        &self,
        certificate: &mut shardloom_core::NativeIoCertificate,
    ) -> Result<()> {
        certificate.join_work.merge(
            *self
                .join_work
                .lock()
                .map_err(|_| resident_error("native join work evidence poisoned"))?,
        )
    }

    pub(crate) fn append_variant_expression_certificate(
        &self,
        certificate: &mut shardloom_core::NativeIoCertificate,
    ) -> Result<()> {
        self.variant_expression_work
            .lock()
            .map_err(|_| resident_error("Variant expression evidence poisoned"))?
            .append(certificate);
        Ok(())
    }

    pub(crate) fn record_dictionary_expression(
        &self,
        work: &crate::native_dictionary_expression::Work,
    ) -> Result<()> {
        self.dictionary_expression_work
            .lock()
            .map_err(|_| resident_error("dictionary expression evidence poisoned"))?
            .merge(work)
    }

    pub(crate) fn append_dictionary_expression_certificate(
        &self,
        certificate: &mut shardloom_core::NativeIoCertificate,
    ) -> Result<()> {
        self.dictionary_expression_work
            .lock()
            .map_err(|_| resident_error("dictionary expression evidence poisoned"))?
            .append(certificate);
        Ok(())
    }

    /// Aggregate at owner boundaries only. No input values or per-row trace survive.
    pub(crate) fn record_capability_decision(
        &self,
        capability: shardloom_core::native_io_decisions::NativeIoCapability,
        outcome: shardloom_core::native_io_decisions::NativeIoDecisionOutcome,
        reason: shardloom_core::native_io_decisions::NativeIoDecisionReason,
        observed: shardloom_core::native_io_decisions::NativeIoObservedWork,
    ) -> Result<()> {
        self.record_capability_decisions(capability, 1, outcome, reason, observed)
    }

    pub(crate) fn record_capability_decisions(
        &self,
        capability: shardloom_core::native_io_decisions::NativeIoCapability,
        count: u64,
        outcome: shardloom_core::native_io_decisions::NativeIoDecisionOutcome,
        reason: shardloom_core::native_io_decisions::NativeIoDecisionReason,
        observed: shardloom_core::native_io_decisions::NativeIoObservedWork,
    ) -> Result<()> {
        self.capability_decisions
            .lock()
            .map_err(|_| resident_error("native capability decision evidence poisoned"))?
            .record_many(capability, count, outcome, reason, observed)
    }

    pub(crate) fn capability_decisions(
        &self,
    ) -> Result<shardloom_core::native_io_decisions::NativeIoCapabilityDecisions> {
        self.capability_decisions
            .lock()
            .map(|decisions| *decisions)
            .map_err(|_| resident_error("native capability decision evidence poisoned"))
    }

    pub(crate) fn append_capability_decisions(
        &self,
        certificate: &mut shardloom_core::NativeIoCertificate,
    ) -> Result<()> {
        certificate
            .capability_decisions
            .merge(&self.capability_decisions()?)
    }

    pub(crate) fn record_adaptive_work(
        &self,
        owner: crate::native_work_sizing::Owner,
        shape: shardloom_exec::adaptive_work::WorkShape,
    ) {
        self.adaptive_work
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .record(owner, shape);
    }

    pub(crate) fn append_adaptive_work_certificate(&self, proof: &mut String) {
        self.adaptive_work
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .append_certificate(proof);
    }

    pub(crate) fn record_adaptive_work_decline(
        &self,
        owner: crate::native_work_sizing::Owner,
        denial: shardloom_exec::adaptive_work::WorkDenial,
    ) {
        self.adaptive_work
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .record_decline(owner, denial);
    }

    /// Immutable floating semantics of the admitted session, not a call override.
    #[must_use]
    pub fn float_policy(&self) -> shardloom_core::FloatPolicy {
        self.owner.float_policy
    }

    /// The fixed recursive-work bound of this admitted session.
    #[must_use]
    pub fn recursion_limit(&self) -> shardloom_core::RecursionLimit {
        self.owner.recursion_limit
    }

    /// Metadata-only admission cannot be expanded into scanning or construction.
    pub(crate) fn check_general_execution(&self) -> Result<()> {
        self.check_cancelled()?;
        if self.class != CallClass::General {
            return Err(resident_error(
                "native execution requires a general operation grant",
            ));
        }
        Ok(())
    }

    /// Effective CPU grant includes the calling thread.
    #[must_use]
    pub fn cpu_lanes(&self) -> usize {
        match &self.gate {
            Gate::Exclusive(guard, _) => {
                let () = &**guard;
                self.owner.cpu_limit()
            }
            Gate::Serving(permit) => permit.lanes,
        }
    }

    #[must_use]
    pub fn queue_time(&self) -> Duration {
        match &self.gate {
            Gate::Exclusive(_, queue) => *queue,
            Gate::Serving(permit) => permit.queue_time,
        }
    }

    #[must_use]
    pub fn timing(&self) -> ResidentCallTiming {
        ResidentCallTiming {
            queue: self.queue_time(),
            service: self.admitted.elapsed(),
        }
    }

    /// # Errors
    /// Returns the existing deterministic cooperative cancellation error.
    pub fn check_cancelled(&self) -> Result<()> {
        self.cancellation.check()
    }

    #[must_use]
    pub fn cancellation(&self) -> &CancellationToken {
        &self.cancellation
    }

    #[must_use]
    pub fn native_session(&self) -> &VortexSession {
        &self.owner.session
    }

    #[must_use]
    pub fn runtime(&self) -> &vortex::io::runtime::current::CurrentThreadRuntime {
        &self.owner.runtime
    }

    #[must_use]
    pub fn memory(&self) -> &shardloom_exec::live_memory::LiveMemoryPool {
        &self.owner.memory
    }

    pub(super) fn belongs_to(&self, owner: &RuntimeOwner) -> bool {
        std::ptr::eq(self.owner, owner)
    }

    pub(super) fn io_scope(&self) -> Option<Arc<IoScope>> {
        self.io.get().cloned()
    }

    pub(super) fn drain_io(&self) {
        if let Some(scope) = self.io.get() {
            scope.close_and_drain(&self.owner.runtime);
        }
    }

    fn capture_opened_source(&self, path: &std::path::Path) -> Result<Arc<SourceIdentity>> {
        self.check_general_execution()?;
        // A conservative control estimate, distinct from provider buffer
        // accounting. Reserve before opening or copying the local pathname.
        let bytes = u64::try_from(path.as_os_str().len())
            .ok()
            .and_then(|bytes| bytes.checked_mul(2))
            .and_then(|bytes| bytes.checked_add(4096))
            .ok_or_else(|| resident_error("source identity capacity overflow"))?;
        let ownership = self.owner.memory.reserve(bytes)?;
        let mut sources = self
            .opened_sources
            .lock()
            .map_err(|_| resident_error("source generation ownership poisoned"))?;
        let OpenedSources { values, capacity } = &mut *sources;
        if values.len() == values.capacity() {
            let target = values
                .capacity()
                .max(4)
                .checked_mul(2)
                .ok_or_else(|| resident_error("source generation capacity overflow"))?;
            let bytes = target
                .checked_mul(std::mem::size_of::<(Arc<SourceIdentity>, MemoryLease)>())
                .and_then(|bytes| u64::try_from(bytes).ok())
                .ok_or_else(|| resident_error("source generation capacity overflow"))?;
            let credit = capacity.get_or_insert(self.owner.memory.reserve(0)?);
            credit.resize(
                credit
                    .bytes()
                    .checked_add(bytes)
                    .ok_or_else(|| resident_error("source generation capacity overflow"))?,
            )?;
            values
                .try_reserve_exact(target - values.len())
                .map_err(|error| resident_error(&error.to_string()))?;
            if values.capacity() > target {
                return Err(resident_error(
                    "source generation allocation exceeded admission",
                ));
            }
            credit.resize(bytes)?;
        }
        self.check_cancelled()?;
        let identity = Arc::new(SourceIdentity::capture(path)?);
        values.push((Arc::clone(&identity), ownership));
        Ok(identity)
    }

    /// Synchronous primitive adapters can open another file under this same
    /// operation. Its generation stays held until the final I/O drain, without
    /// retaining every file's decoded footer or creating a second runtime.
    pub(crate) async fn open_local_file(
        &self,
        path: &std::path::Path,
    ) -> vortex::error::VortexResult<VortexFile> {
        let identity = self
            .capture_opened_source(path)
            .map_err(|error| vortex_err!("{error}"))?;
        let scope = self
            .file_io_scope()
            .map_err(|error| vortex_err!("{error}"))?;
        // Opening creates a provider read driver even for a footer-only count.
        // Track that driver's destruction before replacing its segment source;
        // the operation cannot return while it still owns the shared grant.
        let input = Arc::new(super::ResidentFileReadAt {
            identity: Arc::clone(&identity),
            allocator: self.owner.session.host_allocator(),
            handle: self.owner.runtime.handle(),
            concurrency: self.cpu_lanes(),
            scope: Some(Arc::clone(scope)),
            reader_owner: Some(
                scope
                    .retain_reader(&self.owner.memory)
                    .map_err(|error| vortex_err!("{error}"))?,
            ),
            #[cfg(all(feature = "vortex-local-primitives", unix))]
            evidence: Some(
                self.native_file_read_evidence(&identity)
                    .map_err(|error| vortex_err!("{error}"))?,
            ),
        });
        #[cfg(all(feature = "native-binary-objects", unix))]
        let footer = crate::binary_object::catalog::read_footer(Arc::clone(&identity), self)
            .map_err(|error| vortex_err!("{error}"))?;
        let options = self
            .owner
            .session
            .open_options()
            .with_coalescing_amplification_limit(super::COALESCING_AMPLIFICATION_LIMIT)
            .with_layout_reader_cache();
        #[cfg(all(feature = "native-binary-objects", unix))]
        let options = options.with_footer(footer);
        let file = options.open(input).await?;
        #[cfg(all(feature = "native-binary-objects", unix))]
        let objects = crate::binary_object::catalog::prepare(&file, &identity, self)
            .map_err(|error| vortex_err!("{error}"))?;
        self.check_cancelled()
            .map_err(|error| vortex_err!("{error}"))?;
        identity
            .validate()
            .map_err(|error| vortex_err!("{error}"))?;
        let view = self
            .file_view(&file, Some(&identity))
            .map(Cow::into_owned)
            .map_err(|error| vortex_err!("{error}"))?;
        drop(file);
        #[cfg(all(feature = "native-binary-objects", unix))]
        {
            // Metadata reads completed synchronously. Keep this I/O scope live
            // for the following table scan; the caller owns the final drain.
            identity
                .validate()
                .map_err(|error| vortex_err!("{error}"))?;
            crate::binary_object::Arena::get(self.native_session())
                .and_then(|arena| arena.insert_batch(objects.value(), self.cancellation()))
                .map_err(|error| vortex_err!("{error}"))?;
        }
        Ok(view)
    }

    pub(crate) fn finish_opened_sources(&self) -> Result<()> {
        self.drain_io();
        self.check_cancelled()?;
        let sources = self
            .opened_sources
            .lock()
            .map_err(|_| resident_error("source generation ownership poisoned"))?;
        for (identity, _) in &sources.values {
            self.check_cancelled()?;
            identity.validate()?;
        }
        Ok(())
    }

    /// Retain the already-bound compatibility generation through final delivery.
    /// Reader and range admission use the same operation as native file scans.
    #[cfg(all(feature = "vortex-write", feature = "universal-format-io", unix))]
    pub(crate) fn local_source_reader(
        &self,
        identity: Arc<SourceIdentity>,
        metrics: Arc<super::LocalReadMetrics>,
    ) -> Result<super::OwnedLocalRead> {
        self.check_general_execution()?;
        identity.validate()?;
        let ownership = self.memory().reserve(4096)?;
        let mut sources = self
            .opened_sources
            .lock()
            .map_err(|_| resident_error("source generation ownership poisoned"))?;
        let OpenedSources { values, capacity } = &mut *sources;
        if values.len() == values.capacity() {
            let target = values
                .len()
                .checked_add(1)
                .ok_or_else(|| resident_error("source generation capacity overflow"))?;
            let bytes = (target as u64)
                .checked_mul(std::mem::size_of::<(Arc<SourceIdentity>, MemoryLease)>() as u64)
                .ok_or_else(|| resident_error("source generation capacity overflow"))?;
            let credit = capacity.get_or_insert(self.memory().reserve(0)?);
            credit.resize(bytes)?;
            values
                .try_reserve_exact(1)
                .map_err(|error| resident_error(&error.to_string()))?;
            if values.capacity() > target {
                return Err(resident_error(
                    "source generation allocation exceeded admission",
                ));
            }
        }
        values.push((Arc::clone(&identity), ownership));
        drop(sources);
        super::OwnedLocalRead::new(
            identity,
            self.memory(),
            self.cancellation(),
            metrics,
            Some(Arc::clone(self.file_io_scope()?)),
        )
    }

    fn file_io_scope(&self) -> Result<&Arc<IoScope>> {
        if self.io.get().is_none() {
            // Ordinary calls need the same cancellation/drain boundary as
            // serving calls. Allocate it only for file execution: metadata and
            // retained in-memory results do not acquire an unused I/O owner.
            // Their reader concurrency and live allocator remain the limits;
            // this private budget adds lifetime tracking, not a serving policy.
            let budget = self
                .owner
                .io_budget
                .clone()
                .unwrap_or_else(|| IoBudget::new(usize::MAX, u64::MAX));
            let scope = IoScope::deferred(budget, &self.owner.memory, self.cancellation.clone())?;
            let _ = self.io.set(scope);
        }
        self.io
            .get()
            .ok_or_else(|| resident_error("native file execution has no I/O owner"))
    }

    pub(super) fn file_view<'a>(
        &self,
        file: &'a VortexFile,
        identity: Option<&Arc<SourceIdentity>>,
    ) -> Result<Cow<'a, VortexFile>> {
        let Some(identity) = identity else {
            return Ok(Cow::Borrowed(file));
        };
        self.check_general_execution()?;
        let scope = self.file_io_scope()?;
        // Keep the held descriptor, parsed footer and user metadata. A fresh
        // provider reader tree gives this operation an exact I/O lifetime; it
        // does not reopen the file or cache an answer. Batch readers are unchanged.
        let reader = super::ResidentFileReadAt {
            identity: Arc::clone(identity),
            allocator: self.owner.session.host_allocator(),
            handle: self.owner.runtime.handle(),
            concurrency: self.cpu_lanes(),
            scope: Some(Arc::clone(scope)),
            reader_owner: None,
            #[cfg(all(feature = "vortex-local-primitives", unix))]
            evidence: None,
        };
        let source = DeferredFileSegments {
            segments: file.footer().segment_map().clone(),
            reader,
            scope: Arc::clone(scope),
            memory: self.owner.memory.clone(),
            source: Arc::new(OnceLock::new()),
            operation: self.operation,
            cancellation: self.cancellation.clone(),
            #[cfg(unix)]
            cache: Arc::clone(&self.owner.source_segments),
            #[cfg(all(feature = "vortex-local-primitives", unix))]
            evidence: Arc::clone(&self.file_evidence),
            #[cfg(all(test, unix, feature = "vortex-write"))]
            observation: super::read_observer::operation_observation(),
        };
        let source: Arc<dyn SegmentSource> = Arc::new(LazySharedFileSegments {
            inner: source,
            shared: OnceLock::new(),
        });
        #[cfg(all(test, unix, feature = "vortex-write"))]
        let source = super::file_pruning_tests::observe_operation_segments(source);
        Ok(Cow::Owned(file.clone().with_segment_source(source)))
    }
}

/// Keep footer inspection and pruning ahead of reader admission. The first
/// actual segment request admits the existing native provider exactly once;
/// failures remain attached to this operation and never reopen/replay a source.
#[derive(Clone)]
struct DeferredFileSegments {
    segments: SegmentMap,
    reader: super::ResidentFileReadAt,
    scope: Arc<IoScope>,
    memory: shardloom_exec::live_memory::LiveMemoryPool,
    source: Arc<OnceLock<SharedVortexResult<AdmittedFileSegments>>>,
    operation: u64,
    cancellation: CancellationToken,
    #[cfg(unix)]
    cache: Arc<super::source_segment_cache::Store>,
    #[cfg(all(feature = "vortex-local-primitives", unix))]
    evidence: Arc<Mutex<super::file_evidence::Evidence>>,
    #[cfg(all(test, unix, feature = "vortex-write"))]
    observation: Option<super::read_observer::OperationObservation>,
}

struct AdmittedFileSegments {
    source: FileSegmentSource,
}

/// Register live sharing when a future is constructed, before its first poll.
/// Deferring registration until polling loses a still-live first request when
/// a second future is constructed before that first future is consumed.
struct LazySharedFileSegments {
    inner: DeferredFileSegments,
    shared: OnceLock<SharedSegmentSource<DeferredFileSegments>>,
}

impl SegmentSource for LazySharedFileSegments {
    fn request(&self, id: SegmentId) -> SegmentFuture {
        let request = self
            .shared
            .get_or_init(|| SharedSegmentSource::new(self.inner.clone()))
            .request(id);
        let source = self.inner.clone();
        async move {
            source
                .cancellation
                .check()
                .map_err(|error| vortex_err!("{error}"))?;
            #[cfg(all(feature = "vortex-local-primitives", unix))]
            source
                .evidence
                .lock()
                .map_err(|_| vortex_err!("native file evidence poisoned"))?
                .source(&source.reader.identity, &source.memory)
                .map_err(|error| vortex_err!("{error}"))?
                .1
                .segment_requested()
                .map_err(|error| vortex_err!("{error}"))?;
            request.await
        }
        .boxed()
    }
}

impl SegmentSource for DeferredFileSegments {
    fn request(&self, id: SegmentId) -> SegmentFuture {
        let source = self.clone();
        async move { source.read(id).await }.boxed()
    }
}

impl DeferredFileSegments {
    async fn read(
        &self,
        id: SegmentId,
    ) -> vortex::error::VortexResult<vortex::array::buffer::BufferHandle> {
        self.cancellation
            .check()
            .map_err(|error| vortex_err!("{error}"))?;
        #[cfg(all(feature = "vortex-local-primitives", unix))]
        let evidence = self
            .evidence
            .lock()
            .map_err(|_| vortex_err!("native file evidence poisoned"))?
            .source(&self.reader.identity, &self.memory)
            .map_err(|error| vortex_err!("{error}"))?
            .1;
        #[cfg(unix)]
        let epoch = match self
            .cache
            .lookup(&self.reader.identity, id, self.operation)?
        {
            super::source_segment_cache::Lookup::Disabled => None,
            super::source_segment_cache::Lookup::Hit { buffer, cross_call } => {
                self.cancellation
                    .check()
                    .map_err(|error| vortex_err!("{error}"))?;
                #[cfg(all(feature = "vortex-local-primitives", unix))]
                evidence
                    .cache_lookup(Some((buffer.len(), cross_call)))
                    .map_err(|error| vortex_err!("{error}"))?;
                #[cfg(not(feature = "vortex-local-primitives"))]
                let _ = cross_call;
                return Ok(vortex::array::buffer::BufferHandle::new_host(buffer));
            }
            super::source_segment_cache::Lookup::Miss { epoch } => {
                #[cfg(all(feature = "vortex-local-primitives", unix))]
                evidence
                    .cache_lookup(None)
                    .map_err(|error| vortex_err!("{error}"))?;
                Some(epoch)
            }
        };
        let source = self.source.get_or_init(|| {
            // Footer inspection may finish with no spare memory and no data
            // scan. Admit reader evidence only when a segment is requested.
            let reader = super::ResidentFileReadAt {
                reader_owner: Some(
                    self.scope
                        .retain_reader(&self.memory)
                        .map_err(|error| Arc::new(vortex_err!("{error}")))?,
                ),
                #[cfg(all(feature = "vortex-local-primitives", unix))]
                evidence: Some(Arc::clone(&evidence)),
                ..self.reader.clone()
            };
            #[cfg(all(test, unix, feature = "vortex-write"))]
            let reader =
                super::read_observer::observe_operation_reader(reader, self.observation.as_ref());
            // Live-request sharing wraps this lazy source, so it registers
            // requests before polling without admitting a reader prematurely.
            Ok(AdmittedFileSegments {
                source: FileSegmentSource::open_with_segments_and_coalescing_limit(
                    self.segments.clone(),
                    reader,
                    self.reader.handle.clone(),
                    RequestMetrics::new(
                        &vortex::metrics::DefaultMetricsRegistry::default(),
                        Vec::new(),
                    ),
                    super::COALESCING_AMPLIFICATION_LIMIT,
                ),
            })
        });
        let source = source.as_ref().map_err(vortex::error::VortexError::from)?;
        let result = source.source.request(id).await?;
        self.cancellation
            .check()
            .map_err(|error| vortex_err!("{error}"))?;
        #[cfg(unix)]
        if let Some(epoch) = epoch {
            let copied =
                self.cache
                    .retain(&self.reader.identity, id, self.operation, epoch, &result)?;
            #[cfg(all(feature = "vortex-local-primitives", unix))]
            evidence
                .cache_copy(copied.copied_bytes, copied.stored)
                .map_err(|error| vortex_err!("{error}"))?;
            #[cfg(not(feature = "vortex-local-primitives"))]
            let _ = copied;
        }
        self.cancellation
            .check()
            .map_err(|error| vortex_err!("{error}"))?;
        Ok(result)
    }
}

impl Drop for NativeExecutionContext<'_> {
    fn drop(&mut self) {
        self.drain_io();
        #[cfg(unix)]
        self.owner
            .source_segments
            .discard_uncompleted_operation(self.operation);
        #[cfg(unix)]
        if let Ok(sources) = self.opened_sources.get_mut() {
            for (identity, _) in &sources.values {
                self.owner
                    .source_segments
                    .invalidate_source(identity, false);
            }
        }
        // Release the observer before field destruction unlocks admission.
        // Otherwise the next exclusive call can see the prior weak scope alive.
        self.compare_work.take();
    }
}

use vortex::array::memory::HostMemorySessionExt as _;
