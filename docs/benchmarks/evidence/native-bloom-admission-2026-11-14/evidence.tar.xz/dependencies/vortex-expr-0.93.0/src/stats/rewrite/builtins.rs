// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright the Vortex contributors

use std::cmp::Ordering;

use vortex_array::aggregate_fn::AggregateFnRef;
use vortex_array::aggregate_fn::AggregateFnVTableExt;
use vortex_array::aggregate_fn::EmptyOptions as AggregateEmptyOptions;
use vortex_array::aggregate_fn::fns::all_nan::AllNan;
use vortex_array::aggregate_fn::fns::all_non_nan::AllNonNan;
use vortex_array::aggregate_fn::fns::all_non_null::AllNonNull;
use vortex_array::aggregate_fn::fns::all_null::AllNull;
use vortex_array::dtype::DType;
use vortex_array::expr::BoundExpression;
use vortex_array::expr::bound::and;
use vortex_array::expr::bound::and_collect;
use vortex_array::expr::bound::binary;
use vortex_array::expr::bound::cast;
use vortex_array::expr::bound::dynamic_with_options;
use vortex_array::expr::bound::eq;
use vortex_array::expr::bound::gt;
use vortex_array::expr::bound::gt_eq;
use vortex_array::expr::bound::lit;
use vortex_array::expr::bound::lt;
use vortex_array::expr::bound::lt_eq;
use vortex_array::expr::bound::or;
use vortex_array::expr::bound::or_collect;
use vortex_array::expr::stats::Stat;
use vortex_array::scalar::Scalar;
use vortex_array::scalar::StringLike;
use vortex_array::scalar_fn::EmptyOptions;
use vortex_array::scalar_fn::ScalarFnId;
use vortex_array::scalar_fn::ScalarFnVTable;
use vortex_array::scalar_fn::ScalarFnVTableExt;
use vortex_array::scalar_fn::fns::between::Between;
use vortex_array::scalar_fn::fns::binary::Binary;
use vortex_array::scalar_fn::fns::cast::Cast;
use vortex_array::scalar_fn::fns::dynamic::DynamicComparison;
use vortex_array::scalar_fn::fns::dynamic_expression::DynamicExpression;
use vortex_array::scalar_fn::fns::is_nan::IsNan;
use vortex_array::scalar_fn::fns::is_not_null::IsNotNull;
use vortex_array::scalar_fn::fns::is_null::IsNull;
use vortex_array::scalar_fn::fns::like::Like;
use vortex_array::scalar_fn::fns::list_contains::ListContains;
use vortex_array::scalar_fn::fns::literal::Literal;
use vortex_array::scalar_fn::fns::operators::CompareOperator;
use vortex_array::scalar_fn::fns::operators::Operator;
use vortex_array::scalar_fn::internal::row_count::RowCount;
use vortex_error::VortexExpect;
use vortex_error::VortexResult;
use vortex_session::VortexSession;

use crate::stats::bound::stat;
use crate::stats::rewrite::StatsRewriteRule;
use crate::stats::rewrite::dynamic_expression::StatsProof;
use crate::stats::rewrite::dynamic_expression::dynamic_stats_proof;
use crate::stats::rewrite::falsify;
use crate::stats::rewrite::like_variant::LikeVariant;
use crate::stats::session::StatsSession;

/// Register built-in stats rewrite rules.
pub(crate) fn register_builtins(session: &StatsSession) {
    session.register_rewrite(BinaryNanCountStatsRewrite);
    session.register_rewrite(BinaryAllNonNanStatsRewrite);
    session.register_rewrite(BetweenStatsRewrite);
    session.register_rewrite(LiteralStatsRewrite);
    session.register_rewrite(IsNullNullCountStatsRewrite);
    session.register_rewrite(IsNullAllNonNullStatsRewrite);
    session.register_rewrite(IsNullAllNullStatsRewrite);
    session.register_rewrite(IsNotNullNullCountStatsRewrite);
    session.register_rewrite(IsNotNullAllNullStatsRewrite);
    session.register_rewrite(IsNotNullAllNonNullStatsRewrite);
    session.register_rewrite(IsNanNaNCountStatsRewrite);
    session.register_rewrite(IsNanAllNonNanStatsRewrite);
    session.register_rewrite(IsNanAllNanStatsRewrite);
    session.register_rewrite(LikeStatsRewrite);
    session.register_rewrite(ListContainsNanCountStatsRewrite);
    session.register_rewrite(ListContainsAllNonNanStatsRewrite);
    session.register_rewrite(DynamicComparisonNanCountStatsRewrite);
    session.register_rewrite(DynamicComparisonAllNonNanStatsRewrite);
    session.register_rewrite(DynamicExpressionStatsRewrite);
}

fn row_count() -> BoundExpression {
    RowCount
        .try_new_bound_expr(EmptyOptions, [])
        .vortex_expect("row-count expressions are always well-typed")
}

#[derive(Debug)]
struct LiteralStatsRewrite;

impl StatsRewriteRule for LiteralStatsRewrite {
    fn scalar_fn_id(&self) -> ScalarFnId {
        Literal.id()
    }

    fn falsify(
        &self,
        expr: &BoundExpression,
        _session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        Ok(literal_truth(expr).map(|value| lit(!value)))
    }

    fn satisfy(
        &self,
        expr: &BoundExpression,
        _session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        Ok(literal_truth(expr).map(lit))
    }
}

/// Bool literal predicate value
fn literal_truth(expr: &BoundExpression) -> Option<bool> {
    expr.as_::<Literal>().as_bool_opt().and_then(|b| b.value())
}

#[derive(Debug)]
struct BinaryNanCountStatsRewrite;

impl StatsRewriteRule for BinaryNanCountStatsRewrite {
    fn scalar_fn_id(&self) -> ScalarFnId {
        Binary.id()
    }

    fn falsify(
        &self,
        expr: &BoundExpression,
        session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        binary_falsify::<NanCountProof>(expr, session)
    }
}

#[derive(Debug)]
struct BinaryAllNonNanStatsRewrite;

impl StatsRewriteRule for BinaryAllNonNanStatsRewrite {
    fn scalar_fn_id(&self) -> ScalarFnId {
        Binary.id()
    }

    fn falsify(
        &self,
        expr: &BoundExpression,
        session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        binary_falsify::<AllNonNanProof>(expr, session)
    }
}

fn binary_falsify<P: NonNanProof>(
    expr: &BoundExpression,
    session: &VortexSession,
) -> VortexResult<Option<BoundExpression>> {
    let operator = expr.as_::<Binary>();
    let lhs = expr.child(0);
    let rhs = expr.child(1);

    Ok(match operator {
        Operator::Eq => {
            let left = min(lhs).zip(max(rhs)).map(|(a, b)| gt(a, b));
            let right = min(rhs).zip(max(lhs)).map(|(a, b)| gt(a, b));
            or_collect(left.into_iter().chain(right))
                .map(|value_predicate| with_non_nan_guards::<P>([lhs, rhs], value_predicate))
                .transpose()?
                .flatten()
        }
        Operator::NotEq => min(lhs)
            .zip(max(rhs))
            .zip(max(lhs).zip(min(rhs)))
            .map(|((min_lhs, max_rhs), (max_lhs, min_rhs))| {
                with_non_nan_guards::<P>(
                    [lhs, rhs],
                    and(eq(min_lhs, max_rhs), eq(max_lhs, min_rhs)),
                )
            })
            .transpose()?
            .flatten(),
        Operator::Gt => max(lhs)
            .zip(min(rhs))
            .map(|(a, b)| with_non_nan_guards::<P>([lhs, rhs], lt_eq(a, b)))
            .transpose()?
            .flatten(),
        Operator::Gte => max(lhs)
            .zip(min(rhs))
            .map(|(a, b)| with_non_nan_guards::<P>([lhs, rhs], lt(a, b)))
            .transpose()?
            .flatten(),
        Operator::Lt => min(lhs)
            .zip(max(rhs))
            .map(|(a, b)| with_non_nan_guards::<P>([lhs, rhs], gt_eq(a, b)))
            .transpose()?
            .flatten(),
        Operator::Lte => min(lhs)
            .zip(max(rhs))
            .map(|(a, b)| with_non_nan_guards::<P>([lhs, rhs], gt(a, b)))
            .transpose()?
            .flatten(),
        Operator::And => {
            if !P::EMIT_UNGUARDED_REWRITES {
                return Ok(None);
            }

            let lhs_falsifier = falsify(lhs, session)?;
            let rhs_falsifier = falsify(rhs, session)?;
            or_collect(lhs_falsifier.into_iter().chain(rhs_falsifier))
        }
        Operator::Or => {
            // Check before recursing: falsifying the children first would repeat the
            // whole recursive rewrite once per registered `Binary` rule, which is
            // exponential in `Or`-nesting depth for chains like `a = 1 OR a = 2 OR ...`.
            if !P::EMIT_UNGUARDED_REWRITES {
                return Ok(None);
            }

            match (falsify(lhs, session)?, falsify(rhs, session)?) {
                (Some(lhs), Some(rhs)) => Some(and(lhs, rhs)),
                _ => None,
            }
        }
        Operator::Add | Operator::Sub | Operator::Mul | Operator::Div => None,
    })
}

#[derive(Debug)]
struct BetweenStatsRewrite;

impl StatsRewriteRule for BetweenStatsRewrite {
    fn scalar_fn_id(&self) -> ScalarFnId {
        Between.id()
    }

    fn falsify(
        &self,
        expr: &BoundExpression,
        session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        let options = expr.as_::<Between>();
        let arr = expr.child(0).clone();
        let lower = expr.child(1).clone();
        let upper = expr.child(2).clone();

        let lhs = binary(options.lower_strict.to_operator(), lower, arr.clone());
        let rhs = binary(options.upper_strict.to_operator(), arr, upper);
        falsify(&and(lhs, rhs), session)
    }
}

#[derive(Debug)]
struct IsNullNullCountStatsRewrite;

impl StatsRewriteRule for IsNullNullCountStatsRewrite {
    fn scalar_fn_id(&self) -> ScalarFnId {
        IsNull.id()
    }

    fn falsify(
        &self,
        expr: &BoundExpression,
        _session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        Ok(null_count(expr.child(0)).map(|null_count| eq(null_count, lit(0u64))))
    }

    fn satisfy(
        &self,
        expr: &BoundExpression,
        _session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        Ok(null_count(expr.child(0)).map(|null_count| eq(null_count, row_count())))
    }
}

#[derive(Debug)]
struct IsNullAllNonNullStatsRewrite;

impl StatsRewriteRule for IsNullAllNonNullStatsRewrite {
    fn scalar_fn_id(&self) -> ScalarFnId {
        IsNull.id()
    }

    fn falsify(
        &self,
        expr: &BoundExpression,
        _session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        Ok(Some(all_non_null(expr.child(0))))
    }
}

#[derive(Debug)]
struct IsNullAllNullStatsRewrite;

impl StatsRewriteRule for IsNullAllNullStatsRewrite {
    fn scalar_fn_id(&self) -> ScalarFnId {
        IsNull.id()
    }

    fn satisfy(
        &self,
        expr: &BoundExpression,
        _session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        Ok(Some(all_null(expr.child(0))))
    }
}

#[derive(Debug)]
struct IsNotNullNullCountStatsRewrite;

impl StatsRewriteRule for IsNotNullNullCountStatsRewrite {
    fn scalar_fn_id(&self) -> ScalarFnId {
        IsNotNull.id()
    }

    fn falsify(
        &self,
        expr: &BoundExpression,
        _session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        Ok(null_count(expr.child(0)).map(|null_count| eq(null_count, row_count())))
    }

    fn satisfy(
        &self,
        expr: &BoundExpression,
        _session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        Ok(null_count(expr.child(0)).map(|null_count| eq(null_count, lit(0u64))))
    }
}

#[derive(Debug)]
struct IsNotNullAllNullStatsRewrite;

impl StatsRewriteRule for IsNotNullAllNullStatsRewrite {
    fn scalar_fn_id(&self) -> ScalarFnId {
        IsNotNull.id()
    }

    fn falsify(
        &self,
        expr: &BoundExpression,
        _session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        Ok(Some(all_null(expr.child(0))))
    }
}

#[derive(Debug)]
struct IsNotNullAllNonNullStatsRewrite;

impl StatsRewriteRule for IsNotNullAllNonNullStatsRewrite {
    fn scalar_fn_id(&self) -> ScalarFnId {
        IsNotNull.id()
    }

    fn satisfy(
        &self,
        expr: &BoundExpression,
        _session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        Ok(Some(all_non_null(expr.child(0))))
    }
}

/// Rewrites `is_nan` using the `NaNCount` stat: the predicate is falsified when a zone
/// contains no NaN values, and satisfied when every row in the zone is NaN.
#[derive(Debug)]
struct IsNanNaNCountStatsRewrite;

impl StatsRewriteRule for IsNanNaNCountStatsRewrite {
    fn scalar_fn_id(&self) -> ScalarFnId {
        IsNan.id()
    }

    fn falsify(
        &self,
        expr: &BoundExpression,
        _session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        Ok(nan_count(expr.child(0)).map(|nan_count| eq(nan_count, lit(0u64))))
    }

    fn satisfy(
        &self,
        expr: &BoundExpression,
        _session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        Ok(nan_count(expr.child(0)).map(|nan_count| eq(nan_count, row_count())))
    }
}

/// Falsifies `is_nan` when the `AllNonNan` pruning stat proves that no value in the zone
/// is NaN.
#[derive(Debug)]
struct IsNanAllNonNanStatsRewrite;

impl StatsRewriteRule for IsNanAllNonNanStatsRewrite {
    fn scalar_fn_id(&self) -> ScalarFnId {
        IsNan.id()
    }

    fn falsify(
        &self,
        expr: &BoundExpression,
        _session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        Ok(Some(all_non_nan(expr.child(0))))
    }
}

/// Satisfies `is_nan` when the `AllNan` pruning stat proves that every value in the zone
/// is NaN.
#[derive(Debug)]
struct IsNanAllNanStatsRewrite;

impl StatsRewriteRule for IsNanAllNanStatsRewrite {
    fn scalar_fn_id(&self) -> ScalarFnId {
        IsNan.id()
    }

    fn satisfy(
        &self,
        expr: &BoundExpression,
        _session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        Ok(Some(all_nan(expr.child(0))))
    }
}

#[derive(Debug)]
struct LikeStatsRewrite;

impl StatsRewriteRule for LikeStatsRewrite {
    fn scalar_fn_id(&self) -> ScalarFnId {
        Like.id()
    }

    fn falsify(
        &self,
        expr: &BoundExpression,
        _session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        let like_options = expr.as_::<Like>();
        if like_options.negated || like_options.case_insensitive {
            return Ok(None);
        }

        let Some(pattern) = expr.child(1).as_opt::<Literal>() else {
            return Ok(None);
        };
        let Some(pattern) = pattern.as_utf8().value() else {
            return Ok(None);
        };

        let source = expr.child(0);
        Ok(match LikeVariant::from_str(pattern) {
            Some(LikeVariant::Exact(text)) => {
                min(source)
                    .zip(max(source))
                    .map(|(source_min, source_max)| {
                        or(
                            gt(source_min, lit(text.as_ref())),
                            lt(source_max, lit(text.as_ref())),
                        )
                    })
            }
            Some(LikeVariant::Prefix(prefix)) => {
                let Some(successor) = prefix.to_string().increment().ok() else {
                    return Ok(None);
                };
                min(source)
                    .zip(max(source))
                    .map(|(source_min, source_max)| {
                        or(
                            gt_eq(source_min, lit(successor)),
                            lt(source_max, lit(prefix.as_ref())),
                        )
                    })
            }
            None => None,
        })
    }
}

#[derive(Debug)]
struct ListContainsNanCountStatsRewrite;

impl StatsRewriteRule for ListContainsNanCountStatsRewrite {
    fn scalar_fn_id(&self) -> ScalarFnId {
        ListContains.id()
    }

    fn falsify(
        &self,
        expr: &BoundExpression,
        _session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        list_contains_falsify::<NanCountProof>(expr)
    }
}

#[derive(Debug)]
struct ListContainsAllNonNanStatsRewrite;

impl StatsRewriteRule for ListContainsAllNonNanStatsRewrite {
    fn scalar_fn_id(&self) -> ScalarFnId {
        ListContains.id()
    }

    fn falsify(
        &self,
        expr: &BoundExpression,
        _session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        list_contains_falsify::<AllNonNanProof>(expr)
    }
}

/// Lists with more elements falsify `needle IN list` with the bounds of the list rather than
/// with a test per element, which keeps the pruning expression, and its evaluation per zone,
/// small for the large lists of dynamic join filters.
const MAX_LIST_ELEMENT_FALSIFICATIONS: usize = 16;

/// The smallest and largest non-null elements, or `None` when there are none or two elements
/// are unordered.
fn non_null_bounds(elements: &[Scalar]) -> Option<(&Scalar, &Scalar)> {
    let mut non_null = elements.iter().filter(|element| !element.is_null());
    let first = non_null.next()?;
    non_null.try_fold((first, first), |(low, high), element| {
        let low = match element.partial_cmp(low)? {
            Ordering::Less => element,
            Ordering::Equal | Ordering::Greater => low,
        };
        let high = match element.partial_cmp(high)? {
            Ordering::Greater => element,
            Ordering::Equal | Ordering::Less => high,
        };
        Some((low, high))
    })
}

fn list_contains_falsify<P: NonNanProof>(
    expr: &BoundExpression,
) -> VortexResult<Option<BoundExpression>> {
    let list = expr.child(0);
    let needle = expr.child(1);

    let Some(list_scalar) = literal_stat(list, Stat::Min) else {
        return Ok(None);
    };
    let elements = list_scalar
        .as_opt::<Literal>()
        .and_then(|literal| literal.as_list_opt())
        .and_then(|list| list.elements());
    let Some(elements) = elements else {
        return Ok(None);
    };
    if elements.is_empty() {
        return Ok(P::EMIT_UNGUARDED_REWRITES.then(|| lit(true)));
    }

    let Some(value_max) = max(needle) else {
        return Ok(None);
    };
    let Some(value_min) = min(needle) else {
        return Ok(None);
    };

    let value_predicate = if elements.len() > MAX_LIST_ELEMENT_FALSIFICATIONS
        && let Some((low, high)) = non_null_bounds(&elements)
    {
        Some(or(
            lt(value_max, lit(low.clone())),
            gt(value_min, lit(high.clone())),
        ))
    } else {
        and_collect(elements.iter().map(|value| {
            or(
                lt(value_max.clone(), lit(value.clone())),
                gt(value_min.clone(), lit(value.clone())),
            )
        }))
    };
    value_predicate
        .map(|value_predicate| with_non_nan_guards::<P>([needle], value_predicate))
        .transpose()
        .map(Option::flatten)
}

#[derive(Debug)]
struct DynamicComparisonNanCountStatsRewrite;

impl StatsRewriteRule for DynamicComparisonNanCountStatsRewrite {
    fn scalar_fn_id(&self) -> ScalarFnId {
        DynamicComparison.id()
    }

    fn falsify(
        &self,
        expr: &BoundExpression,
        _session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        dynamic_comparison_falsify::<NanCountProof>(expr)
    }
}

#[derive(Debug)]
struct DynamicComparisonAllNonNanStatsRewrite;

impl StatsRewriteRule for DynamicComparisonAllNonNanStatsRewrite {
    fn scalar_fn_id(&self) -> ScalarFnId {
        DynamicComparison.id()
    }

    fn falsify(
        &self,
        expr: &BoundExpression,
        _session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        dynamic_comparison_falsify::<AllNonNanProof>(expr)
    }
}

fn dynamic_comparison_falsify<P: NonNanProof>(
    expr: &BoundExpression,
) -> VortexResult<Option<BoundExpression>> {
    let dynamic = expr.as_::<DynamicComparison>();
    let lhs = expr.child(0);

    let Some((operator, lhs_stat)) = (match dynamic.operator() {
        CompareOperator::Eq | CompareOperator::NotEq => None,
        CompareOperator::Gt => max(lhs).map(|lhs_stat| (CompareOperator::Lte, lhs_stat)),
        CompareOperator::Gte => max(lhs).map(|lhs_stat| (CompareOperator::Lt, lhs_stat)),
        CompareOperator::Lt => min(lhs).map(|lhs_stat| (CompareOperator::Gte, lhs_stat)),
        CompareOperator::Lte => min(lhs).map(|lhs_stat| (CompareOperator::Gt, lhs_stat)),
    }) else {
        return Ok(None);
    };

    let value_predicate = dynamic_with_options(
        dynamic.with_operator(operator, !dynamic.default()),
        lhs_stat,
    );
    with_non_nan_guards::<P>([lhs], value_predicate)
}

fn min(expr: &BoundExpression) -> Option<BoundExpression> {
    stat_expr(expr, Stat::Min)
}

fn max(expr: &BoundExpression) -> Option<BoundExpression> {
    stat_expr(expr, Stat::Max)
}

fn null_count(expr: &BoundExpression) -> Option<BoundExpression> {
    stat_expr(expr, Stat::NullCount)
}

fn nan_count(expr: &BoundExpression) -> Option<BoundExpression> {
    stat_expr(expr, Stat::NaNCount)
}

fn all_null(expr: &BoundExpression) -> BoundExpression {
    stat_fn(expr.clone(), AllNull.bind(AggregateEmptyOptions))
}

fn all_non_null(expr: &BoundExpression) -> BoundExpression {
    stat_fn(expr.clone(), AllNonNull.bind(AggregateEmptyOptions))
}

fn all_nan(expr: &BoundExpression) -> BoundExpression {
    stat_fn(expr.clone(), AllNan.bind(AggregateEmptyOptions))
}

fn all_non_nan(expr: &BoundExpression) -> BoundExpression {
    stat_fn(expr.clone(), AllNonNan.bind(AggregateEmptyOptions))
}

enum NanCheck {
    NotNeeded,
    Check(BoundExpression),
    Unavailable,
}

trait NonNanProof {
    const EMIT_UNGUARDED_REWRITES: bool;

    fn check(expr: &BoundExpression) -> VortexResult<NanCheck>;
}

struct NanCountProof;

impl NonNanProof for NanCountProof {
    const EMIT_UNGUARDED_REWRITES: bool = true;

    fn check(expr: &BoundExpression) -> VortexResult<NanCheck> {
        non_nan_check(expr, |expr| match stat_expr(expr, Stat::NaNCount) {
            Some(nan_count) => NanCheck::Check(eq(nan_count, lit(0u64))),
            None => NanCheck::Unavailable,
        })
    }
}

struct AllNonNanProof;

impl NonNanProof for AllNonNanProof {
    const EMIT_UNGUARDED_REWRITES: bool = false;

    fn check(expr: &BoundExpression) -> VortexResult<NanCheck> {
        non_nan_check(expr, |expr| {
            NanCheck::Check(stat_fn(expr.clone(), AllNonNan.bind(AggregateEmptyOptions)))
        })
    }
}

// Min/max do not order NaN values, so comparison rewrites are only sound when every
// candidate value is known to be non-NaN. Cast result dtypes are not enough: a cast
// from float to non-float still needs a proof about the float source values.
fn non_nan_check(
    expr: &BoundExpression,
    proof: impl FnOnce(&BoundExpression) -> NanCheck,
) -> VortexResult<NanCheck> {
    if let Some(scalar) = expr.as_opt::<Literal>() {
        if !scalar.dtype().is_float() {
            return Ok(NanCheck::NotNeeded);
        }
        return Ok(if scalar.as_primitive().is_nan() {
            NanCheck::Check(lit(false))
        } else {
            NanCheck::NotNeeded
        });
    }

    if expr.is::<Cast>() {
        if !has_nans(expr.child(0).dtype()) {
            return Ok(NanCheck::NotNeeded);
        }

        return non_nan_check(expr.child(0), proof);
    }

    if !has_nans(expr.dtype()) {
        return Ok(NanCheck::NotNeeded);
    }

    Ok(proof(expr))
}

fn has_nans(dtype: &DType) -> bool {
    dtype.is_float()
}

fn stat_expr(expr: &BoundExpression, stat: Stat) -> Option<BoundExpression> {
    if let Some(literal) = literal_stat(expr, stat) {
        return Some(literal);
    }

    // `literal_stat` handled every stat that is defined for literals. If it returned
    // `None`, the requested stat is not meaningful for this literal, such as
    // `NaNCount` over a non-float value, so do not manufacture `stat(literal, ...)`.
    if expr.is::<Literal>() {
        return None;
    }

    if let Some(dtype) = expr.as_opt::<Cast>() {
        return cast_stat(expr.child(0), dtype, stat);
    }

    let aggregate_fn = stat.aggregate_fn()?;
    // The aggregate may not support the expression's dtype, e.g. min/max over structs,
    // even when the predicate itself is well-typed. Such stats cannot be lowered later,
    // so do not reference them in the rewrite.
    aggregate_fn
        .return_dtype(expr.dtype())
        .is_some()
        .then(|| stat_fn(expr.clone(), aggregate_fn))
}

fn with_non_nan_guards<'a, P: NonNanProof>(
    exprs: impl IntoIterator<Item = &'a BoundExpression>,
    value_predicate: BoundExpression,
) -> VortexResult<Option<BoundExpression>> {
    let mut nan_checks = Vec::new();
    for expr in exprs {
        match P::check(expr)? {
            NanCheck::NotNeeded => {}
            NanCheck::Check(check) => nan_checks.push(check),
            NanCheck::Unavailable => return Ok(None),
        }
    }
    let nan_predicate = and_collect(nan_checks);

    Ok(match nan_predicate {
        Some(nan_check) => Some(and(nan_check, value_predicate)),
        // No possible NaN-bearing expression remains, so the value predicate is
        // already guarded. Only one registered rule emits this unguarded
        // rewrite so non-float comparisons are not duplicated.
        None if P::EMIT_UNGUARDED_REWRITES => Some(value_predicate),
        None => None,
    })
}

fn literal_stat(expr: &BoundExpression, stat: Stat) -> Option<BoundExpression> {
    let scalar = expr.as_opt::<Literal>()?;
    match stat {
        Stat::Min | Stat::Max => Some(lit(scalar.clone())),
        Stat::NullCount => Some(lit(if scalar.is_null() { 1u64 } else { 0u64 })),
        Stat::NaNCount => {
            let value = scalar.as_primitive_opt()?;
            if !value.ptype().is_float() {
                return None;
            }

            Some(lit(if value.is_nan() { 1u64 } else { 0u64 }))
        }
        Stat::IsConstant
        | Stat::IsSorted
        | Stat::IsStrictSorted
        | Stat::Sum
        | Stat::UncompressedSizeInBytes => None,
    }
}

fn cast_stat(expr: &BoundExpression, dtype: &DType, stat: Stat) -> Option<BoundExpression> {
    match stat {
        Stat::Min | Stat::Max => stat_expr(expr, stat).map(|stat| cast(stat, dtype.clone())),
        Stat::NaNCount | Stat::Sum | Stat::UncompressedSizeInBytes => stat_expr(expr, stat),
        Stat::NullCount | Stat::IsConstant | Stat::IsSorted | Stat::IsStrictSorted => None,
    }
}

fn stat_fn(expr: BoundExpression, aggregate_fn: AggregateFnRef) -> BoundExpression {
    stat(expr, aggregate_fn)
}

#[cfg(test)]
mod tests {
    use std::sync::Arc;
    use std::sync::LazyLock;
    use std::sync::atomic::AtomicUsize;
    use std::sync::atomic::Ordering;

    use vortex_array::aggregate_fn::AggregateFnRef;
    use vortex_array::aggregate_fn::AggregateFnVTableExt;
    use vortex_array::aggregate_fn::EmptyOptions as AggregateEmptyOptions;
    use vortex_array::aggregate_fn::fns::all_non_nan::AllNonNan;
    use vortex_array::dtype::DType;
    use vortex_array::dtype::Nullability;
    use vortex_array::dtype::PType;
    use vortex_array::dtype::StructFields;
    use vortex_array::expr::BoundExpression;
    use vortex_array::expr::Expression;
    use vortex_array::expr::and;
    use vortex_array::expr::between;
    use vortex_array::expr::cast;
    use vortex_array::expr::col;
    use vortex_array::expr::dynamic;
    use vortex_array::expr::eq;
    use vortex_array::expr::get_item;
    use vortex_array::expr::gt;
    use vortex_array::expr::gt_eq;
    use vortex_array::expr::is_nan;
    use vortex_array::expr::is_not_null;
    use vortex_array::expr::is_null;
    use vortex_array::expr::like;
    use vortex_array::expr::list_contains;
    use vortex_array::expr::lit;
    use vortex_array::expr::lt;
    use vortex_array::expr::lt_eq;
    use vortex_array::expr::or;
    use vortex_array::expr::stats::Stat;
    use vortex_array::scalar::Scalar;
    use vortex_array::scalar_fn::EmptyOptions;
    use vortex_array::scalar_fn::ScalarFnId;
    use vortex_array::scalar_fn::ScalarFnVTable;
    use vortex_array::scalar_fn::ScalarFnVTableExt;
    use vortex_array::scalar_fn::fns::between::BetweenOptions;
    use vortex_array::scalar_fn::fns::between::StrictComparison;
    use vortex_array::scalar_fn::fns::binary::Binary;
    use vortex_array::scalar_fn::fns::dynamic::DynamicComparison;
    use vortex_array::scalar_fn::fns::operators::CompareOperator;
    use vortex_array::scalar_fn::internal::row_count::RowCount;
    use vortex_error::VortexResult;
    use vortex_session::VortexSession;

    use crate::stats::expr::StatFn;
    use crate::stats::expr::StatOptions;
    use crate::stats::rewrite::BoundExpressionPruneExt;
    use crate::stats::rewrite::StatsRewriteRule;
    use crate::stats::session::StatsSessionExt;

    static SESSION: LazyLock<VortexSession> = LazyLock::new(VortexSession::empty);

    fn stat(expr: Expression, stat: Stat) -> Expression {
        let aggregate_fn = stat.aggregate_fn().expect("stat should have aggregate fn");
        stat_fn(expr, aggregate_fn)
    }

    fn stat_fn(expr: Expression, aggregate_fn: AggregateFnRef) -> Expression {
        StatFn.new_expr(StatOptions::new(aggregate_fn), [expr])
    }

    fn test_scope() -> DType {
        DType::Struct(
            StructFields::from_iter([
                ("a", DType::Primitive(PType::I32, Nullability::NonNullable)),
                ("b", DType::Primitive(PType::I32, Nullability::NonNullable)),
                ("f", DType::Primitive(PType::F32, Nullability::NonNullable)),
                ("s", DType::Utf8(Nullability::NonNullable)),
                ("t", DType::Utf8(Nullability::NonNullable)),
                ("n", nested_struct_dtype()),
            ]),
            Nullability::NonNullable,
        )
    }

    fn nested_struct_dtype() -> DType {
        DType::Struct(
            StructFields::from_iter([("x", DType::Primitive(PType::F32, Nullability::Nullable))]),
            Nullability::NonNullable,
        )
    }

    fn falsify(expr: &Expression) -> VortexResult<Option<BoundExpression>> {
        expr.bind(&test_scope())?.falsify(&SESSION)
    }

    fn satisfy(expr: &Expression) -> VortexResult<Option<BoundExpression>> {
        expr.bind(&test_scope())?.satisfy(&SESSION)
    }

    fn bind_expected(expr: Option<Expression>) -> VortexResult<Option<BoundExpression>> {
        expr.map(|expr| expr.bind(&test_scope())).transpose()
    }

    fn all_null(expr: &Expression) -> Expression {
        crate::stats::all_null(expr.clone())
    }

    fn all_non_null(expr: &Expression) -> Expression {
        crate::stats::all_non_null(expr.clone())
    }

    fn all_nan(expr: &Expression) -> Expression {
        crate::stats::all_nan(expr.clone())
    }

    fn all_non_nan(expr: &Expression) -> Expression {
        crate::stats::all_non_nan(expr.clone())
    }

    macro_rules! assert_rewrite_eq {
        ($actual:expr, $expected:expr) => {
            assert_eq!($actual, bind_expected($expected)?)
        };
    }

    fn nan_guarded(expr: Expression, value_predicate: Expression) -> Expression {
        or(
            and(
                eq(stat(expr.clone(), Stat::NaNCount), lit(0u64)),
                value_predicate.clone(),
            ),
            and(
                stat_fn(expr, AllNonNan.bind(AggregateEmptyOptions)),
                value_predicate,
            ),
        )
    }

    #[test]
    fn rewrites_comparison_falsifier() -> VortexResult<()> {
        let expr = gt(col("a"), lit(10));
        assert_rewrite_eq!(
            falsify(&expr)?,
            Some(lt_eq(stat(col("a"), Stat::Max), lit(10)))
        );

        let expr = eq(col("a"), col("b"));
        assert_rewrite_eq!(
            falsify(&expr)?,
            Some(or(
                gt(stat(col("a"), Stat::Min), stat(col("b"), Stat::Max)),
                gt(stat(col("b"), Stat::Min), stat(col("a"), Stat::Max)),
            ))
        );

        let expr = eq(col("s"), col("t"));
        assert_rewrite_eq!(
            falsify(&expr)?,
            Some(or(
                gt(stat(col("s"), Stat::Min), stat(col("t"), Stat::Max)),
                gt(stat(col("t"), Stat::Min), stat(col("s"), Stat::Max)),
            ))
        );
        Ok(())
    }

    #[test]
    fn rewrites_boolean_falsifiers() -> VortexResult<()> {
        let expr = and(gt(col("a"), lit(10)), lt(col("a"), lit(50)));
        assert_rewrite_eq!(
            falsify(&expr)?,
            Some(or(
                lt_eq(stat(col("a"), Stat::Max), lit(10)),
                gt_eq(stat(col("a"), Stat::Min), lit(50)),
            ))
        );

        let expr = or(gt(col("a"), lit(10)), lt(col("a"), lit(5)));
        assert_rewrite_eq!(
            falsify(&expr)?,
            Some(and(
                lt_eq(stat(col("a"), Stat::Max), lit(10)),
                gt_eq(stat(col("a"), Stat::Min), lit(5)),
            ))
        );
        Ok(())
    }

    /// Counts how many times the stats rewrite visits a `Binary` node.
    #[derive(Debug)]
    struct BinaryVisitCounter(Arc<AtomicUsize>);

    impl StatsRewriteRule for BinaryVisitCounter {
        fn scalar_fn_id(&self) -> ScalarFnId {
            Binary.id()
        }

        fn falsify(
            &self,
            _expr: &BoundExpression,
            _session: &VortexSession,
        ) -> VortexResult<Option<BoundExpression>> {
            self.0.fetch_add(1, Ordering::Relaxed);
            Ok(None)
        }
    }

    #[test]
    fn or_chain_falsify_visits_each_node_once() -> VortexResult<()> {
        let session = VortexSession::empty();
        let visits = Arc::new(AtomicUsize::new(0));
        session
            .stats()
            .register_rewrite(BinaryVisitCounter(Arc::clone(&visits)));

        let expr = (1..16).fold(eq(col("a"), lit(0)), |chain, i| {
            or(chain, eq(col("a"), lit(i)))
        });
        let falsifier = expr.bind(&test_scope())?.falsify(&session)?;
        assert!(falsifier.is_some());

        // One visit per `Binary` node: 16 comparisons plus 15 `or`s.
        assert_eq!(visits.load(Ordering::Relaxed), 31);
        Ok(())
    }

    #[test]
    fn rewrites_between_falsifier() -> VortexResult<()> {
        let expr = between(
            col("a"),
            lit(10),
            lit(50),
            BetweenOptions {
                lower_strict: StrictComparison::NonStrict,
                upper_strict: StrictComparison::NonStrict,
            },
        );

        assert_rewrite_eq!(
            falsify(&expr)?,
            Some(or(
                gt(lit(10), stat(col("a"), Stat::Max)),
                gt(stat(col("a"), Stat::Min), lit(50)),
            ))
        );
        Ok(())
    }

    #[test]
    fn rewrites_null_falsifiers() -> VortexResult<()> {
        assert_rewrite_eq!(
            falsify(&is_null(col("a")))?,
            Some(or(
                eq(stat(col("a"), Stat::NullCount), lit(0u64)),
                all_non_null(&col("a")),
            ))
        );

        assert_rewrite_eq!(
            falsify(&is_not_null(col("a")))?,
            Some(or(
                eq(
                    stat(col("a"), Stat::NullCount),
                    RowCount.new_expr(EmptyOptions, []),
                ),
                all_null(&col("a")),
            ))
        );
        Ok(())
    }

    #[test]
    fn rewrites_null_satisfiers() -> VortexResult<()> {
        assert_rewrite_eq!(
            satisfy(&is_null(col("a")))?,
            Some(or(
                eq(
                    stat(col("a"), Stat::NullCount),
                    RowCount.new_expr(EmptyOptions, []),
                ),
                all_null(&col("a")),
            ))
        );

        assert_rewrite_eq!(
            satisfy(&is_not_null(col("a")))?,
            Some(or(
                eq(stat(col("a"), Stat::NullCount), lit(0u64)),
                all_non_null(&col("a")),
            ))
        );
        Ok(())
    }

    #[test]
    fn rewrites_nan_falsifiers() -> VortexResult<()> {
        assert_rewrite_eq!(
            falsify(&is_nan(col("f")))?,
            Some(or(
                eq(stat(col("f"), Stat::NaNCount), lit(0u64)),
                all_non_nan(&col("f")),
            ))
        );

        // Nullable floats prune on nan_count just the same.
        assert_rewrite_eq!(
            falsify(&is_nan(get_item("x", col("n"))))?,
            Some(or(
                eq(stat(get_item("x", col("n")), Stat::NaNCount), lit(0u64)),
                all_non_nan(&get_item("x", col("n"))),
            ))
        );

        // NaN literals fold through the nan_count stat.
        assert_rewrite_eq!(
            falsify(&is_nan(lit(f32::NAN)))?,
            Some(or(eq(lit(1u64), lit(0u64)), all_non_nan(&lit(f32::NAN))))
        );
        Ok(())
    }

    #[test]
    fn rewrites_nan_satisfiers() -> VortexResult<()> {
        assert_rewrite_eq!(
            satisfy(&is_nan(col("f")))?,
            Some(or(
                eq(
                    stat(col("f"), Stat::NaNCount),
                    RowCount.new_expr(EmptyOptions, [])
                ),
                all_nan(&col("f")),
            ))
        );

        assert_rewrite_eq!(
            satisfy(&is_nan(lit(f32::NAN)))?,
            Some(or(
                eq(lit(1u64), RowCount.new_expr(EmptyOptions, [])),
                all_nan(&lit(f32::NAN)),
            ))
        );
        Ok(())
    }

    #[test]
    fn rewrites_list_contains_falsifier() -> VortexResult<()> {
        let list = Scalar::list(
            Arc::new(DType::Primitive(PType::I32, Nullability::NonNullable)),
            vec![1.into(), 2.into(), 3.into()],
            Nullability::NonNullable,
        );
        let expr = list_contains(lit(list), col("a"));

        assert_rewrite_eq!(
            falsify(&expr)?,
            Some(and(
                and(
                    or(
                        lt(stat(col("a"), Stat::Max), lit(1i32)),
                        gt(stat(col("a"), Stat::Min), lit(1i32)),
                    ),
                    or(
                        lt(stat(col("a"), Stat::Max), lit(2i32)),
                        gt(stat(col("a"), Stat::Min), lit(2i32)),
                    ),
                ),
                or(
                    lt(stat(col("a"), Stat::Max), lit(3i32)),
                    gt(stat(col("a"), Stat::Min), lit(3i32)),
                ),
            ))
        );
        Ok(())
    }

    #[test]
    fn rewrites_large_list_contains_falsifier_to_bounds() -> VortexResult<()> {
        let list = Scalar::list(
            Arc::new(DType::Primitive(PType::I32, Nullability::Nullable)),
            (0..20)
                .rev()
                .map(|value| Scalar::from(Some(value)))
                .chain([Scalar::null(DType::Primitive(
                    PType::I32,
                    Nullability::Nullable,
                ))])
                .collect(),
            Nullability::NonNullable,
        );
        let expr = list_contains(lit(list), col("a"));

        assert_rewrite_eq!(
            falsify(&expr)?,
            Some(or(
                lt(stat(col("a"), Stat::Max), lit(Scalar::from(Some(0i32)))),
                gt(stat(col("a"), Stat::Min), lit(Scalar::from(Some(19i32)))),
            ))
        );
        Ok(())
    }

    #[test]
    fn rewrites_like_falsifier() -> VortexResult<()> {
        let expr = like(col("s"), lit("prefix%"));
        assert_rewrite_eq!(
            falsify(&expr)?,
            Some(or(
                gt_eq(stat(col("s"), Stat::Min), lit("prefiy")),
                lt(stat(col("s"), Stat::Max), lit("prefix")),
            ))
        );

        let expr = like(col("s"), lit(r"\%%"));
        assert_rewrite_eq!(
            falsify(&expr)?,
            Some(or(
                gt_eq(stat(col("s"), Stat::Min), lit("&")),
                lt(stat(col("s"), Stat::Max), lit("%")),
            ))
        );

        let expr = like(col("s"), lit("pref%ix%"));
        assert_rewrite_eq!(
            falsify(&expr)?,
            Some(or(
                gt_eq(stat(col("s"), Stat::Min), lit("preg")),
                lt(stat(col("s"), Stat::Max), lit("pref")),
            ))
        );

        let expr = like(col("s"), lit("pref_ix_"));
        assert_rewrite_eq!(
            falsify(&expr)?,
            Some(or(
                gt_eq(stat(col("s"), Stat::Min), lit("preg")),
                lt(stat(col("s"), Stat::Max), lit("pref")),
            ))
        );

        let expr = like(col("s"), lit("exact"));
        assert_rewrite_eq!(
            falsify(&expr)?,
            Some(or(
                gt(stat(col("s"), Stat::Min), lit("exact")),
                lt(stat(col("s"), Stat::Max), lit("exact")),
            ))
        );

        let expr = like(col("s"), lit("%suffix"));
        assert_rewrite_eq!(falsify(&expr)?, None);
        Ok(())
    }

    #[test]
    fn rewrites_dynamic_comparison_falsifier() -> VortexResult<()> {
        let expr = dynamic(
            CompareOperator::Gt,
            || Some(10i32.into()),
            DType::Primitive(PType::I32, Nullability::NonNullable),
            true,
            col("a"),
        );
        let dynamic = expr.as_::<DynamicComparison>();

        assert_rewrite_eq!(
            falsify(&expr)?,
            Some(DynamicComparison.new_expr(
                dynamic.with_operator(CompareOperator::Lte, false),
                [stat(col("a"), Stat::Max)],
            ))
        );
        Ok(())
    }

    #[test]
    fn nan_guard_tracks_cast_source_dtype() -> VortexResult<()> {
        let dtype = DType::Primitive(PType::I32, Nullability::NonNullable);
        let expr = gt(cast(col("f"), dtype.clone()), lit(5i32));

        assert_rewrite_eq!(
            falsify(&expr)?,
            Some(nan_guarded(
                col("f"),
                lt_eq(cast(stat(col("f"), Stat::Max), dtype), lit(5i32)),
            ))
        );
        Ok(())
    }

    #[test]
    fn skips_falsifier_when_min_max_unsupported_for_dtype() -> VortexResult<()> {
        // Struct comparisons are valid predicates, but min/max aggregates do not
        // support struct inputs, so no stats-backed falsifier should be produced.
        let struct_scalar = Scalar::struct_(
            nested_struct_dtype(),
            vec![Scalar::primitive(1.0f32, Nullability::Nullable)],
        );
        assert_rewrite_eq!(falsify(&lt_eq(col("n"), lit(struct_scalar.clone())))?, None);
        assert_rewrite_eq!(falsify(&eq(col("n"), lit(struct_scalar)))?, None);
        Ok(())
    }

    #[test]
    fn forwards_min_max_through_safe_cast() -> VortexResult<()> {
        let dtype = DType::Primitive(PType::I64, Nullability::NonNullable);
        let expr = eq(cast(col("a"), dtype.clone()), lit(42i64));

        assert_rewrite_eq!(
            falsify(&expr)?,
            Some(or(
                gt(cast(stat(col("a"), Stat::Min), dtype.clone()), lit(42i64)),
                gt(lit(42i64), cast(stat(col("a"), Stat::Max), dtype)),
            ))
        );
        Ok(())
    }
}

#[derive(Debug)]
struct DynamicExpressionStatsRewrite;

impl StatsRewriteRule for DynamicExpressionStatsRewrite {
    fn scalar_fn_id(&self) -> ScalarFnId {
        DynamicExpression.id()
    }

    fn falsify(
        &self,
        expr: &BoundExpression,
        session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        dynamic_stats_proof(expr, session, StatsProof::Falsify)
    }

    fn satisfy(
        &self,
        expr: &BoundExpression,
        session: &VortexSession,
    ) -> VortexResult<Option<BoundExpression>> {
        dynamic_stats_proof(expr, session, StatsProof::Satisfy)
    }
}
