# Vortex 0.93.0 Bloom provider inventory

Status: bounded source inventory. This records provider APIs and semantics from
the requested Vortex files; it does not assess ShardLoom scan, writer, or resource
integration.

## Provider and API

The workspace patches `vortex-layout` to `vendor/vortex-layout`, where the crate
version is 0.93.0 ([root Cargo.toml:23-29](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/Cargo.toml:23>), [vendored Cargo.toml:12-18](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/Cargo.toml:12>)). The zoned aggregate module publicly exposes `bloom_filter`. Its public surface includes `BloomFilter`, `BloomOptions`, `BloomPartial`, and `HashFn`. `BloomOptions::new` takes a nonzero `u32` block count and a hash variant; `Default` selects 256 blocks and `XxHash3_64` ([bloom module:34-43, 85-135](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/mod.rs:34>)). Public `BloomPartial::insert` and `contains` operate on byte-like values ([partial module:178-202](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/partial/mod.rs:178>)).

`ZonedLayout::try_new` receives the aggregate function list from its caller ([zoned layout:379-410](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/mod.rs:379>)). The aggregate module itself says its Bloom writer interface is pending and allows dead code ([aggregates module:4-10](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/mod.rs:4>)). The default Bloom options are configuration defaults; the inspected files do not establish writer default inclusion.

## Configuration and partial format

Options metadata is two little-endian `u32` values, in order: block count, then hash-function ID. The only enum value is `XxHash3_64 = 0`; deserialization rejects invalid length, zero blocks, or unknown IDs ([Bloom options:49-57, 58-135](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/mod.rs:49>)). A filter block is 32 bytes containing eight little-endian `u32` splits. At 256 blocks the payload is 8,192 bytes (approximately 8 KiB) per zone ([Bloom format:244-268](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/mod.rs:244>), [partial serde:24-55](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/partial/serde.rs:24>)).

The aggregate identifier is `vortex.bloom_filter.sbbf`. The partial payload has no version field in these files; source comments explicitly warn that hash function, block layout, and salt order can change without a file-format version bump and say not to persist these partials in a Vortex file ([Bloom aggregate:264-290](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/mod.rs:264>)). The implementation hashes bytes with `XxHash3_64::oneshot` and uses a fixed eight-entry `SALT` array for block masks ([partial implementation:40-52, 204-215, 266-293](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/partial/mod.rs:40>)). No seed option is exposed. The exact dependency-level seed default is marked `NEEDS_REASONING` in the JSON companion.

## Dtypes, nulls, and membership

The dtype gate accepts Boolean, primitive (including floating-point), UTF8,
binary, and extension types whose storage dtype is accepted. Canonical accumulation
handles Boolean, primitive, varbin-view, and extension arrays; nulls are skipped.
Decimal, struct, list, fixed-size-list, variant, union, and map canonicals return
unsupported-type errors ([dtype gate](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/mod.rs:402>), [canonical dispatcher](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/canonical/mod.rs:21>)). Numeric values use their little-endian bytes, UTF8/binary use raw value bytes, Boolean values use `0x00`/`0x01`, and extension arrays delegate through storage ([primitive](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/canonical/primitive.rs:26>), [varbin](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/canonical/varbin.rs:22>), [Boolean](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/canonical/bool.rs:14>), [extension](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/canonical/extension.rs:12>)).

The SBBF membership contract permits false positives but not false negatives
when partials use compatible options ([Bloom documentation:144-152](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/mod.rs:144>)). The implementation has no finite-value filter; float values are hashed as bytes. A test shows distinct NaN bit patterns as distinct membership inputs ([primitive NaN test:241-280](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/canonical/primitive.rs:241>)). The source does not establish SQL comparison semantics for NaNs or signed zero, so that remains `NEEDS_REASONING`.

Null scalar insertions are skipped and scalar `contains_scalar(null)` returns false ([scalar helpers:81-105](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/partial/scalar.rs:81>)). In the scalar function, a null needle yields a null Boolean, and null filter rows propagate null validity ([BloomContains execution:121-141](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/scalar_fn.rs:121>)). Missing Bloom statistics are tested as inconclusive, with no regions selected for exclusion ([missing-stat test:392-412](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/scalar_fn.rs:392>)).

## Predicate surface and constraints

`BloomContains` takes a binary filter plus a Bloom-valid needle dtype and only
executes when the needle is constant ([scalar function:74-119](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/scalar_fn.rs:74>)). A private statistics rewrite recognizes equality between a root column and a non-null literal in either operand order, then creates a Bloom falsifier. The source comment says this rewrite is currently disabled ([rewrite:228-276](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/scalar_fn.rs:228>)). No `IN`, range, or inequality rewrite appears in the scoped Bloom files.

Partial union is bitwise OR and validates block count, but not hash-function identity. The source warns that merging different hash functions can introduce false negatives; loading a stored partial likewise assumes compatible hash options ([partial union:26-41](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/partial/aggregate.rs:26>), [partial-from-scalar:307-332](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/mod.rs:307>)).

## Indexed-reader test context

The indexed-layout tests define `FixedSupersetIndex` as a test-only stand-in that
ignores the expression and data and returns a fixed locator. The code comments
say real Bloom and n-gram indexes derive locators from data ([indexed tests:1471-1477](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/indexed/tests.rs:1471>)). `multiple_superset_claims_intersect` exercises intersection of two superset claims; `exact_claim_discards_a_preceding_superset_claim` checks that an exact claim supersedes a preceding superset mask ([indexed tests:409-447](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/indexed/tests.rs:409>), [indexed tests:449-480](</Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/indexed/tests.rs:449>)). These are reader-combination tests, not Bloom indexing correctness or Bloom-provider wiring. The JSON companion records their names and the file hash.

## Tests and unknowns

The JSON companion lists Bloom test names and file/line citations across aggregate,
scalar-function, partial serialization, canonical dtype, constant, zoned metadata,
and indexed-reader tests.

The companion also records these unresolved boundaries: writer-default selection,
IN support outside the specified source set, exact dependency seed semantics, and
higher-level non-finite comparison semantics. This source inventory makes no
performance claim and recommends no writer policy.
