# Pinned Bloom admission decision and executable review

This finite step evaluates production admission of the existing Vortex 0.93.0
`vortex.bloom_filter.sbbf` aggregate and its current equality rewrite. It precedes
the queued text-summary investigation. It does not introduce another Bloom
algorithm, persisted identifier, writer default, dependency upgrade or public API.

The expert acceptance standard is conservative zone exclusion: every value that
can satisfy the exact query must survive the summary test, and every retained
summary must have a stable, typed, resource-bounded source identity. An unsafe
provider does not reach a performance comparison merely because it can be wired.

## Prospective decision

The pinned native aggregate cannot currently be admitted for persisted zone
pruning. Its own source explicitly forbids persisting its partials under the
current identifier because hashing, salt order and block layout may change
without a format-version change. Default aggregate/scalar/stats registration
does not enable it. Its byte hashing also needs review against ShardLoom equality,
especially signed zero, typed literal conversion and extension semantics.

Classification: `blocked_until_vortex_or_shardloom_evidence` for this existing
unversioned persisted provider. This is a bounded admission decline, conditional
on verifying the cited source and executable witnesses below. It is not a claim
that all Bloom designs are unsuitable or slow. The broader predicate-summary
parent remains open, and independent ready work can proceed afterward.

A new versioned ShardLoom wrapper was considered. It would take ownership of a
persisted format, hash/equality semantics, registry rewrite, column-selection
policy, bounded writer accumulation and read-side metadata retention. Those are
real new contracts; a renamed upstream identifier or unchecked registration
toggle would not establish them. This finite provider intake does not invent
that format to bypass the upstream warning.

## Executable review

Add a temporary, feature-gated example using the locked public native aggregate
and session APIs. Build it through the existing bounded compilation supervisor
and resolved nonsynced Cargo cache. It performs only small in-memory provider
operations, writes one JSON result, never persists Bloom partials in a Vortex
file and does not execute public queries or measure performance.

Before execution, freeze the exact example, manifest change, base commit/tree,
provider source hashes, build command and expected checks. Preserve every failed
attempt under a new name. Test:

- Default aggregate registration and extension-default selection.
- Exact options round trip and malformed length, zero count and unknown hash ID.
- Maximum representable option size without constructing that allocation.
- Integer and UTF-8 membership through native aggregate accumulation, with
  empty/all-null controls and retained partial deserialization.
- F32 and F64 positive/negative zero in both directions, comparing ordinary
  numeric equality with the provider's actual membership answer.
- Null partial interpretation, malformed partial lengths, incompatible block
  options, same-option union and saturated-filter conservatism.

These checks demonstrate the exact pinned boundary. Byte-filter membership is
not promoted to SQL equality, a null partial is not promoted to missing-statistic
proof, and an accepted numeric option is not promoted to a memory reservation.
No false-positive rate, pruning/read saving or speed claim is made from these
small controls.

## Required evidence before a later persisted candidate

1. Stable versioned identity binds hash algorithm/seed, block/salt layout, dtype
   and value normalization; malformed and unknown identities refuse or remain
   inconclusive without suppressing valid rows.
2. Equality and IN rewrites prove necessary conditions for the admitted typed
   domain, including nulls, numeric conversions, zero/NaN policy and extensions.
3. Writer selection is explicit and bounded. Construction, final zone-table
   storage and read-side full-table retention have live resource owners and
   deterministic refusal; a per-filter size alone is insufficient.
4. Source-generation identity, missing/inexact summaries, complete exact residual
   results and native certificates pass through the real user execution path.
5. A separately frozen complete-operation comparison includes construction,
   persisted size, metadata reads, false positives, excluded regions and
   downstream work. It uses the standing complete-cohort engine-time gate.

The temporary probe is preserved as evidence and removed from the runtime source
after review. Source/tree equality against the accepted base must then pass.
The production runtime and its accepted C validation stay unchanged. The final
report must state which checks are fresh and which source reviews are reused.
