//! Finite in-memory review of the pinned, unadmitted Bloom provider.

use std::num::NonZeroU32;

use serde_json::{Value, json};
use vortex::{
    VortexSessionDefault as _,
    array::{
        ArrayRef, IntoArray as _, VortexSessionExecute as _,
        aggregate_fn::{
            Accumulator, AggregateDTypes, AggregateFnVTable as _, DynAccumulator as _,
            session::AggregateFnSessionExt as _,
        },
        arrays::{PrimitiveArray, VarBinViewArray},
        dtype::{DType, Nullability, PType},
        scalar::Scalar,
    },
    layout::layouts::zoned::aggregates::bloom_filter::{
        BloomFilter, BloomOptions, BloomPartial, HashFn,
    },
    session::VortexSession,
};

type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;

fn record(checks: &mut Vec<Value>, name: &str, passed: bool, observed: Value) {
    checks.push(json!({"name": name, "passed": passed, "observed": observed}));
}

fn accumulate(array: &ArrayRef, session: &VortexSession) -> Result<(BloomPartial, Scalar)> {
    let options = BloomOptions::default();
    let dtypes = AggregateDTypes::try_new(&BloomFilter, &options, array.dtype().clone())?;
    let mut state = Accumulator::try_new(BloomFilter, options.clone(), array.dtype().clone())?;
    state.accumulate(array, &mut session.create_execution_ctx())?;
    let scalar = state.finish()?;
    let partial = BloomFilter.partial_from_scalar(dtypes.args(&options), &scalar)?;
    Ok((partial, scalar))
}

fn options_and_registration(checks: &mut Vec<Value>, session: &VortexSession) -> Result<()> {
    let options = BloomOptions::default();
    let registered = session
        .aggregate_fns()
        .find_plugin(&BloomFilter.id())
        .is_some();
    record(
        checks,
        "default_aggregate_is_not_registered",
        !registered,
        json!(registered),
    );
    for dtype in [
        DType::Primitive(PType::I64, Nullability::Nullable),
        DType::Utf8(Nullability::Nullable),
    ] {
        let selected = session
            .aggregate_fns()
            .zone_stat_defaults(&dtype)
            .iter()
            .any(|function| function.id() == BloomFilter.id());
        record(
            checks,
            &format!("default_extension_selection_{dtype}"),
            !selected,
            json!(selected),
        );
    }
    let metadata = BloomFilter
        .serialize(&options)?
        .ok_or("missing options metadata")?;
    record(
        checks,
        "options_round_trip",
        BloomFilter.deserialize(&metadata, session)? == options,
        json!({"metadata_bytes": metadata, "block_count": options.blocks_count().get()}),
    );
    for (name, bytes) in [
        ("empty_options_rejected", vec![]),
        ("short_options_rejected", vec![0; 7]),
        ("long_options_rejected", vec![0; 9]),
        ("zero_blocks_rejected", vec![0; 8]),
        ("unknown_hash_rejected", vec![1, 0, 0, 0, 1, 0, 0, 0]),
    ] {
        let result = BloomFilter.deserialize(&bytes, session);
        record(
            checks,
            name,
            result.is_err(),
            json!(result.err().map(|error| error.to_string())),
        );
    }
    let mut maximum = u32::MAX.to_le_bytes().to_vec();
    maximum.extend_from_slice(&0_u32.to_le_bytes());
    let parsed = BloomFilter.deserialize(&maximum, session)?;
    record(
        checks,
        "maximum_option_acceptance_is_not_memory_admission",
        parsed.blocks_count().get() == u32::MAX,
        json!({"block_count": parsed.blocks_count().get(), "implied_payload_bytes": u64::from(u32::MAX) * 32,
            "partial_allocated": false}),
    );
    Ok(())
}

fn membership(checks: &mut Vec<Value>, session: &VortexSession) -> Result<Scalar> {
    let values = [
        Some(i64::MIN),
        Some(-1),
        Some(0),
        Some(42),
        Some(i64::MAX),
        None,
    ];
    let array = PrimitiveArray::from_option_iter(values).into_array();
    let (partial, scalar) = accumulate(&array, session)?;
    let present: Vec<_> = values
        .into_iter()
        .flatten()
        .map(|value| (value, partial.contains(value.to_le_bytes())))
        .collect();
    record(
        checks,
        "integer_accumulation_has_no_false_negatives",
        present.iter().all(|(_, contains)| *contains),
        json!(present),
    );
    record(
        checks,
        "integer_absent_control",
        !partial.contains(123_456_i64.to_le_bytes()),
        json!(partial.contains(123_456_i64.to_le_bytes())),
    );
    let controls: [(&str, Vec<Option<i64>>); 2] =
        [("empty", vec![]), ("all_null", vec![None, None])];
    for (name, values) in controls {
        let array = PrimitiveArray::from_option_iter(values).into_array();
        let (partial, state) = accumulate(&array, session)?;
        let bytes = state.as_binary().value().ok_or("null filter state")?.len();
        let any = [-1_i64, 0, 1]
            .into_iter()
            .any(|v| partial.contains(v.to_le_bytes()));
        record(
            checks,
            &format!("{name}_state_is_empty"),
            !any && bytes == 8192,
            json!({"any_control_present": any, "partial_bytes": bytes}),
        );
    }
    let text = [Some(""), Some("ID-☃"), Some("Case"), Some("case"), None];
    let array = VarBinViewArray::from_iter_nullable_str(text).into_array();
    let (partial, _) = accumulate(&array, session)?;
    let present: Vec<_> = text
        .into_iter()
        .flatten()
        .map(|v| (v, partial.contains(v.as_bytes())))
        .collect();
    record(
        checks,
        "utf8_accumulation_has_no_false_negatives",
        present.iter().all(|(_, contains)| *contains),
        json!(present),
    );
    Ok(scalar)
}

#[allow(clippy::float_cmp)] // The admission witness compares exact signed-zero equality.
fn signed_zeros(checks: &mut Vec<Value>, session: &VortexSession) -> Result<()> {
    for value in [0.0_f32, -0.0_f32] {
        let needle = -value;
        let array = PrimitiveArray::from_iter([value]).into_array();
        let (partial, _) = accumulate(&array, session)?;
        let exact = value == needle;
        let contains = partial.contains(needle.to_le_bytes());
        record(
            checks,
            &format!("f32_zero_bits_{}_require_equality_review", value.to_bits()),
            exact && !contains && partial.contains(value.to_le_bytes()),
            json!({"inserted_bits": value.to_bits(), "needle_bits": needle.to_bits(),
                "numeric_equality": exact, "bloom_membership": contains}),
        );
    }
    for value in [0.0_f64, -0.0_f64] {
        let needle = -value;
        let array = PrimitiveArray::from_iter([value]).into_array();
        let (partial, _) = accumulate(&array, session)?;
        let exact = value == needle;
        let contains = partial.contains(needle.to_le_bytes());
        record(
            checks,
            &format!("f64_zero_bits_{}_require_equality_review", value.to_bits()),
            exact && !contains && partial.contains(value.to_le_bytes()),
            json!({"inserted_bits": value.to_bits(), "needle_bits": needle.to_bits(),
                "numeric_equality": exact, "bloom_membership": contains}),
        );
    }
    Ok(())
}

fn partial_boundaries(checks: &mut Vec<Value>, scalar: &Scalar) -> Result<()> {
    let options = BloomOptions::default();
    let dtypes = AggregateDTypes::try_new(
        &BloomFilter,
        &options,
        DType::Primitive(PType::I64, Nullability::Nullable),
    )?;
    let null = Scalar::null(DType::Binary(Nullability::Nullable));
    let partial = BloomFilter.partial_from_scalar(dtypes.args(&options), &null)?;
    record(
        checks,
        "null_partial_is_empty_not_missing_statistics_proof",
        !partial.contains(42_i64.to_le_bytes()),
        json!({"contains_42": partial.contains(42_i64.to_le_bytes()), "inconclusive_marker": false}),
    );
    for length in [0, 31, 33, 8191, 8193] {
        let bad = Scalar::binary(vec![0_u8; length], Nullability::NonNullable);
        let result = BloomFilter.partial_from_scalar(dtypes.args(&options), &bad);
        record(
            checks,
            &format!("partial_length_{length}_rejected"),
            result.is_err(),
            json!(result.err().map(|error| error.to_string())),
        );
    }
    let smaller = BloomOptions::new(
        NonZeroU32::new(4).ok_or("zero block count")?,
        HashFn::XxHash3_64,
    );
    let result = BloomFilter.partial_from_scalar(dtypes.args(&smaller), scalar);
    record(
        checks,
        "incompatible_block_count_rejected",
        result.is_err(),
        json!(result.err().map(|error| error.to_string())),
    );
    let first = BloomFilter.partial_from_scalar(dtypes.args(&options), scalar)?;
    let mut second = BloomPartial::from(&options);
    second.insert(999_i64.to_le_bytes());
    let merged = BloomFilter.merge_partials(dtypes.args(&options), first, second)?;
    record(
        checks,
        "same_options_union_preserves_members",
        [i64::MIN, -1, 0, 42, i64::MAX, 999]
            .into_iter()
            .all(|v| merged.contains(v.to_le_bytes())),
        json!({"members": 6}),
    );
    let saturated = Scalar::binary(vec![u8::MAX; 8192], Nullability::NonNullable);
    let partial = BloomFilter.partial_from_scalar(dtypes.args(&options), &saturated)?;
    let all = [i64::MIN, -1, 0, 42, i64::MAX, 999]
        .into_iter()
        .all(|v| partial.contains(v.to_le_bytes()));
    record(
        checks,
        "saturated_partial_cannot_exclude",
        all && BloomFilter.is_saturated(dtypes.args(&options), &partial),
        json!({"all_controls_present": all}),
    );
    Ok(())
}

fn main() -> Result<()> {
    let session = VortexSession::default();
    let mut checks = Vec::new();
    options_and_registration(&mut checks, &session)?;
    let scalar = membership(&mut checks, &session)?;
    signed_zeros(&mut checks, &session)?;
    partial_boundaries(&mut checks, &scalar)?;
    let passed = checks.iter().all(|check| check["passed"] == true);
    println!(
        "{}",
        serde_json::to_string_pretty(&json!({
            "schema": "shardloom.bloom_admission_probe.v1", "passed": passed,
            "provider": "vortex-layout 0.93.0", "aggregate_id": BloomFilter.id().to_string(),
            "production_registration_changed": false, "persisted_bloom_files_written": 0,
            "public_queries_executed": 0, "performance_measured": false, "checks": checks,
        }))?
    );
    if !passed {
        return Err("pinned-provider admission observations changed; review required".into());
    }
    Ok(())
}
