"""Run bounded Bloom admission correctness checks with the established supervisor."""
import importlib.util
from pathlib import Path

path = Path('/Users/dylan/LocalData/shardloom/native-pipeline-sql-minute-2026-11-13/guard_checks.py')
spec = importlib.util.spec_from_file_location('bloom_admission_check_guard', path)
guard = importlib.util.module_from_spec(spec)
spec.loader.exec_module(guard)
guard.ROOT = Path('/Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree')
guard.OUT = Path(__file__).resolve().parent

if __name__ == '__main__':
    raise SystemExit(guard.main())
