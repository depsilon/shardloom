# Bloom resource inventory r1

Read-only inventory for pinned worktree `codex/native-predicate-zones` at `494b41cca98349b21dfabd09a129a205c6664ecb`. No design selected.

1. **bloom-option-bound** — BloomOptions::new takes NonZeroU32; metadata deserialize enforces the fixed 8-byte form, nonzero block count, and known HashFn ID. No upper bound on block count is visible in these checks. Documentation says 256-bit blocks and lists illustrative per-zone memory values.
   - `vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/mod.rs:59-78,85-116` (SHA-256 `6836cb12af344043609471412172890c01c844c6a9b767ce1f85daf06c1fe302`)
2. **bloom-allocation** — BloomPartial has Frozen(Buffer<Block>) and Thawed(BufferMut<Block>). Deserialize checks nonempty length, divisibility by BLOCK_SIZE, and block count fitting u32; aligned bytes are wrapped as Buffer, otherwise alignment may copy. From<&BloomOptions> creates a Thawed BufferMut with BufferMut::zeroed(blocks_count as usize). No direct ShardLoom credit call is visible at this boundary; credit/ownership coverage remains NEEDS_REASONING, and absence is not proof of absent ownership elsewhere.
   - `vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/partial/mod.rs:297-308` (SHA-256 `e08583325fdcde03dd6736087dda2a4644c399403c318b253394bd834aa4ee8e`)
   - `vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/partial/mod.rs:121-134,162-175` (SHA-256 `e08583325fdcde03dd6736087dda2a4644c399403c318b253394bd834aa4ee8e`)
   - `vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/partial/serde.rs:22-45,47-55` (SHA-256 `c2746175f20b6e5e3a89a9d7a3613a2928eafd71352eb6d44678cafce056df79`)
3. **writer-concurrency** — Writer maps each input item to spawn_cpu aggregate_partials and then .buffered(concurrency); each result retains sequence_id, original chunk, partial scalars until ordered accumulation. Stats accumulator stores per-zone builder outputs; fixed builder capacity is 1024. This bounds in-flight stream items by configured concurrency, not total retained zone rows.
   - `vendor/vortex-layout/src/layouts/zoned/writer.rs:153-184,186-197,214-232` (SHA-256 `973456f4d3628d54ddc3dbf5f8080d62468106c080881304cd21d11f3b5b9dca`)
   - `vendor/vortex-layout/src/layouts/zoned/builder.rs:31-52,139-153` (SHA-256 `724c5d83cfe29947ae89f448e0cf87107f30dacc93c16015b42106bb8aee3814`)
4. **stats-reader** — ZonedReader creates lazy child metadata for data and zones. Pruning zone_map requests projection over range 0..zone_count with root() and a true mask, executes the result as StructArray, then retains it in the shared zone-map future/cache. Thus it requests the full stats-table row range and all projected stats fields, not only a single predicate-specific field.
   - `vendor/vortex-layout/src/layouts/zoned/reader.rs:45-73` (SHA-256 `f24c631a7006985cf135ad3144aefc9a131ce18a8a06696f18d2704aec6aa1bd`)
   - `vendor/vortex-layout/src/layouts/zoned/pruning.rs:155-190` (SHA-256 `c253d0a84cfb4ecd933bfaddaa6e0f19a280d4582b8204eecfcce437b4e2949b`)
   - `vendor/vortex-layout/src/layouts/zoned/reader.rs:193-225` (SHA-256 `f24c631a7006985cf135ad3144aefc9a131ce18a8a06696f18d2704aec6aa1bd`)
5. **writer-credit-boundary** — ShardLoom buffered writer validates resource limits and reserves 4096 bytes of control plus buffered_scalar_conversion_bytes before row validation/construction. That is an explicit declared construction estimate/credit; it does not establish RSS ceiling or demonstrate a Bloom-specific reservation.
   - `shardloom-vortex/src/vortex_ingest.rs:10325-10348,10358-10402,10493-10507` (SHA-256 `0532b61d83b62a3089e81e6fd86d7fd09c8c7021313d79e81fbbd86354f93669`)
6. **reader-credit-boundary** — Resident session exposes shared memory pool and reserve_input_scratch, with lease retained by adapter contract; execution context documents separate temporary column vectors and retained metadata credits. Inspected generic code does not show a direct reservation surrounding zoned stats/Bloom child materialization: NEEDS_REASONING; do not infer none elsewhere.
   - `shardloom-vortex/src/resident_session.rs:210-235` (SHA-256 `6787dbc669ddac9404b79c3b4cd34d966f984b3af5f183e6a579a3975057dea8`)
   - `shardloom-vortex/src/resident_execution_context.rs:190-201` (SHA-256 `824e40a8f1830681570cfd9c78a0aae7772ea7cc39658025b44929006b98e37f`)
7. **summary-policy** — Ingest report/evidence names embedded Vortex layout/footer statistics and metadata-first policy. Advisor accepts only enumerated statistics policy strings; generic embedded layout statistics/no query-answer sidecars is named in tests/evidence. No Bloom-specific summary admission is established in this bounded source set.
   - `shardloom-vortex/src/vortex_ingest.rs:245-263,8240-8251,21170-21190` (SHA-256 `0532b61d83b62a3089e81e6fd86d7fd09c8c7021313d79e81fbbd86354f93669`)
8. **aggregate-malformed** — Bloom metadata rejects unknown HashFn IDs; Bloom serde rejects empty, non-block-multiple lengths and block count exceeding u32. Bloom union only checks block count and source comments warn different hash function can cause false negatives. Tests cover invalid options, invalid serde, aligned sharing and unaligned copying.
   - `vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/partial/mod.rs:64-81` (SHA-256 `e08583325fdcde03dd6736087dda2a4644c399403c318b253394bd834aa4ee8e`)
   - `vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/partial/serde.rs:22-45,87-133` (SHA-256 `c2746175f20b6e5e3a89a9d7a3613a2928eafd71352eb6d44678cafce056df79`)
   - `vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/partial/aggregate.rs:26-50` (SHA-256 `d2eba7b248afdaa58d08e0143ea1c935adb4d5f9519a08317a23ed81cbf56cb9`)
   - `vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/mod.rs:602-626` (SHA-256 `6836cb12af344043609471412172890c01c844c6a9b767ce1f85daf06c1fe302`)
9. **unsupported-stats** — Builder filters out aggregate state with variant dtype because no builder exists; resulting aggregates are those retained in builders. Writer fails if a retained aggregate is forbidden by context. This is distinct from a malformed Bloom partial and no claim is made that unsupported aggregate omission is always user-visible.
   - `vendor/vortex-layout/src/layouts/zoned/builder.rs:31-60` (SHA-256 `724c5d83cfe29947ae89f448e0cf87107f30dacc93c16015b42106bb8aee3814`)
   - `vendor/vortex-layout/src/layouts/zoned/writer.rs:157-165` (SHA-256 `973456f4d3628d54ddc3dbf5f8080d62468106c080881304cd21d11f3b5b9dca`)

## Existing tests

- `invalid_options_error` — `vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/mod.rs:616-626`
- `options_roundtrip` — `vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/mod.rs:592-603`
- `valid_serde` — `vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/partial/serde.rs:68-85`
- `invalid_serde` — `vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/partial/serde.rs:87-103`
- `deserialize_shares_aligned_bytes` — `vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/partial/serde.rs:105-116`
- `deserialize_copies_unaligned_bytes` — `vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/partial/serde.rs:118-134`

## Uncertainties / scope limits

- The creation call identifies BufferMut::zeroed with the configured block count; credit/ownership admission for that allocation is not established by this citation and remains unresolved.
- The observed resident and ingest credits do not prove RSS limits or cover every Vortex-internal allocation. No explicit reservation in these cited paths does not prove ownership is absent.
- Summary-policy wording is generic; no Bloom-specific admission decision is established here.
- No writer-default claim is made.
