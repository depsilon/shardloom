# Predicate-specific zone intake — source review only

This is preparation for the queued Bloom investigation, while source-facts C
validation is running. It adds no engine behavior, writer default, benchmark
observation or completion claim. The C comparison and integration checkpoint
remain the immediate work.

Source checkout: `/Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree`,
base `e5a3c344037d05276664ea04a00a266014a9788d` with the separately frozen C candidate.
Provider version: pinned Vortex 0.93.0. No external engine is a runtime provider.

## Source facts

- `shardloom-vortex/src/vortex_ingest.rs:15271` assembles the retained numeric
  writer with `ZonedStrategy` and `ZonedLayoutOptions { block_size, concurrency,
  ..Default::default() }`. It does not select a Bloom aggregate explicitly.
- `vendor/vortex-layout/src/layouts/zoned/writer.rs:318` selects ordinary defaults:
  min/max (bounded for text/binary), NaN count, null count, plus registered
  extension defaults. Bloom is not in that explicit ordinary list. The separate
  provider inventory must settle registry/default details before drawing a
  global enablement conclusion.
- `shardloom-vortex/src/vortex_ingest.rs:15435` retains the old text-zone candidate
  behind test-only configuration; the function comment explicitly preserves
  ordinary source admission. The previous unconditional text-zoning drop must
  remain intact.
- `shardloom-vortex/src/local_primitive_relational_scan.rs:120` owns the held-source
  scan. It checks whole-file pruning, then binds the admitted filter/projection
  into the upstream scan, with one bounded row range and task at a time.
- `vendor/vortex-layout/src/layouts/zoned/reader.rs:158` derives a per-zone pruning
  future, expands its mask to the requested rows, intersects it with the existing
  mask, and requests child pruning only when survivors remain. Exact filter
  evaluation still delegates to the data child.
- `vendor/vortex-layout/src/layouts/zoned/pruning.rs:44` owns expression-keyed
  pruning results, predicate caches, and a shared zone-map future. Its zone-map
  future reads the entire zone statistics child once per reader owner. This is
  relevant to both memory credit and metadata-read cost; it is not itself a
  claim about physical I/O or process RSS.
- `shardloom-vortex/src/local_primitives/native_file_scan_evidence.rs:186` records
  scan invocation, projected/filter/residual fields, delivered rows and whole-file
  checks/exclusions. It does not currently expose a Bloom-specific exclusion count.

## Decisions still required after C

Primary review found a stronger boundary than simple wiring. The pinned
`bloom_filter/mod.rs:264` explicitly calls the aggregate unstable and forbids
persisting its partials in a Vortex file; `scalar_fn.rs:228` keeps the equality
rewrite disabled. The referenced upstream PR 9413 is closed and unmerged as of
the retrieved GitHub metadata (saved in `upstream-pr9413-info-r1.json`), with
last update October 30. Do not toggle this into production or silently persist
its current identifier. The next investigation must resolve format identity,
registration and compatible typed semantics before any persisted candidate.
Upstream prototype instructions are evidence of instability, not authorization
to copy unreviewed code or change dependencies. This does not block the separate
C validation/comparison, and it does not change the queue order on its own.

Use the native provider rather than implement another Bloom format. Review the
provider inventory, registration, writer-context allow-list, serialization/hash
contract and resource owners before choosing a finite implementation unit.
Existing scan wiring alone does not prove admitted Bloom execution.

The investigation contract requires equality/IN on unclustered identifiers,
conservative exclusion, exact surviving evaluation, missing/inexact/unsupported
summary controls, source-generation identity, construction cost, persisted size,
metadata reads, false-positive rate, excluded regions and downstream work.
The ordinary writer must not acquire unconditional new summaries.

Open design questions: the existing explicit policy seam for selected summary
columns; preallocation/retention bounds for Bloom construction and read-side
statistics; a bounded way to prove actual Bloom dispatch/exclusion without
overstating unique rows or bytes; a complete-operation comparison that includes
summary construction and preserves current input/writer controls. These are
questions for primary review, not approved implementation choices.

## Upstream implementation versus integration status

Retrieved November 14 metadata distinguishes three changes. The core
[Bloom implementation PR 9398](https://github.com/vortex-data/vortex/pull/9398)
was merged September 3 at `dab1684b1b438d45c5edcf31c054933099cfc6f7`.
The earlier [opt-in skipping-index PR 8933](https://github.com/vortex-data/vortex/pull/8933)
was closed unmerged July 30, and the later
[integration PR 9413](https://github.com/vortex-data/vortex/pull/9413) was
closed unmerged October 30. Saved JSON records bind the retrieved status and
head/base identities. These are distinct pieces of work: merged Bloom primitives
do not establish admitted persisted indexes or writer/read-side integration.

The PR 9398 description mentions decimal accumulation, but the pinned local
`is_bloom_valid_dtype` and canonical dispatcher reject Decimal. Use the pinned
source and tests for the current dtype boundary; the PR description is historical
intent rather than an executable support contract. The upstream comparison in
PR 8933 uses another engine and is not ShardLoom performance evidence.

## Registration source supplement

The bounded registration inventory is verified separately in
`bloom-registration-primary-review-r1.json`: 22 file hashes, 36 finding ranges
and 15 named test blocks. Its omitted external-crate source is available in
the local Cargo cache. `bloom-session-source-check-r1.json` binds four inspected
files to byte-identical members of the original 0.93.0 crate archives, whose
SHA256 values equal Cargo.lock. The cache has no per-file checksum manifest;
the original locked archives supply that verification instead.

`vortex-0.93.0/src/lib.rs:328-372` defines the `VortexSessionDefault` extension
trait used by ShardLoom. It creates explicit dtype, array, kernel, layout,
scalar-function, stats, aggregate-function, memory, compression and runtime
session state, then initializes Arrow/UUID, editions and file encodings.
`vortex-session-0.93.0/src/session.rs:252-258` supplies a lazy per-type default
when a session variable is absent. This resolves the leaf inventory's question
about where the top-level default is composed.

`vortex-expr-0.93.0/src/stats/session.rs:28-35` installs the built-in stats
rewrites. The exact list in `src/stats/rewrite/builtins.rs:62-83` contains 19
binary, between, literal, null/NaN, LIKE, list-membership and dynamic-expression
rules, with no Bloom rewrite. The pinned Bloom module's aggregate/scalar/rewrite
triple is registered only in its test helper. Public aggregate availability,
optional `ZonedLayoutOptions.aggregate_fns`, writer policy permission and
read-side executable registration remain distinct admission boundaries.

No build, query, cache mutation, writer change or Bloom support claim results
from this source review.
