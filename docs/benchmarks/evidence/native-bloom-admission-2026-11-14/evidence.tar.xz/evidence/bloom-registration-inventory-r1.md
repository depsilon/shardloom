# Bloom registration and zoned writer inventory

**Scope:** read-only source inventory in `/Users/dylan/LocalData/shardloom/optimization-investigation-queue-worktree`, at HEAD `e5a3c3440`. The source worktree was already dirty; hashes in the JSON packet identify the observed working-tree bytes, not necessarily the committed HEAD bytes. No source-worktree files were edited.

## Findings

### Availability, registration, and selection are separate

- **Available:** `vortex-layout` publicly exposes the `bloom_filter` aggregate module, and `BloomFilter` is a public aggregate vtable with ID `vortex.bloom_filter.sbbf` ([aggregates/mod.rs:6-9](../optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/mod.rs), [bloom_filter/mod.rs:264-279](../optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/mod.rs)). `BloomContains` and `BloomEqRewrite` are private types in a private `scalar_fn` module ([scalar_fn.rs:32-35, 55-63](../optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/scalar_fn.rs)).
- **Default registered:** `AggregateFnSession::default` and `ScalarFnSession::default` have explicit built-in registration lists; neither lists BloomFilter nor BloomContains ([aggregate session:103-139](../optimization-investigation-queue-worktree/vendor/vortex-array/src/aggregate_fn/session.rs), [scalar session:63-99](../optimization-investigation-queue-worktree/vendor/vortex-array/src/scalar_fn/session.rs)). The full lists and order are recorded in the JSON.
- **Default selected for zone writing:** absent an override, the zoned writer selects bounded min/max for Utf8/Binary, otherwise skip-NaN max/min, then NanCount and NullCount; it appends registry plugins' `zone_stat_default(dtype)` values ([writer.rs:318-349](../optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/writer.rs)). The aggregate vtable default for `zone_stat_default` is `None` ([vtable.rs:167-176](../optimization-investigation-queue-worktree/vendor/vortex-array/src/aggregate_fn/vtable.rs)); BloomFilter does not override it in its implementation ([bloom_filter/mod.rs:272-400](../optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/mod.rs)). Thus the inspected default zoned writer does not select BloomFilter.

The writer override is the public `ZonedLayoutOptions.aggregate_fns: Option<Arc<[AggregateFnRef]>>`; `None` chooses defaults, while a supplied list is used in place of them ([writer.rs:57-77, 115-120](../optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/writer.rs)). After dtype filtering, aggregate policy rejects a selected disallowed aggregate with an error ([writer.rs:153-165](../optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/writer.rs)). `ZonedLayout::try_new` also accepts an explicit aggregate list when constructing a layout directly ([mod.rs:379-410](../optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/mod.rs)).

### Bloom's explicit registration path

The Bloom module's test-only helper explicitly registers all three pieces: `BloomFilter` in the aggregate registry, `BloomContains` in the scalar registry, and `BloomEqRewrite` in the stats rewrite registry ([scalar_fn.rs:280-328](../optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/scalar_fn.rs)). This does not establish a production/default registration path. The file comment says the equality rewrite is not enabled yet, and the module-level TODO says the dead-code allowance is temporary pending a writer-facing access point ([scalar_fn.rs:228-232](../optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/bloom_filter/scalar_fn.rs), [aggregates/mod.rs:4-9](../optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/aggregates/mod.rs)).

Zoned pruning calls `expr.falsify(session)` and proceeds only when it receives a predicate ([pruning.rs:141-155](../optimization-investigation-queue-worktree/vendor/vortex-layout/src/layouts/zoned/pruning.rs)). The registered rewrite's default registry contents are not in the inspected vendor tree.

### Session defaults and ShardLoom callers

`LayoutSession::default` registers the literal layout list `Chunked, Flat, Struct, Zoned, LegacyStats, Dict, List, Indexed` ([layout session:70-87](../optimization-investigation-queue-worktree/vendor/vortex-layout/src/session.rs)). The requested path `vendor/vortex-array/src/session.rs` is absent; the array-encoding session lives at `vendor/vortex-array/src/session/mod.rs:44-111`.

The inspected ShardLoom resident and ingest constructors call `VortexSession::default`, add runtime/allocator state, then invoke `native_extensions::register` ([resident_session.rs:686-697](../optimization-investigation-queue-worktree/shardloom-vortex/src/resident_session.rs), [vortex_ingest.rs:162-170](../optimization-investigation-queue-worktree/shardloom-vortex/src/vortex_ingest.rs)). The local native-extension dispatcher and its callees register dtype/encoding extension facilities; no Bloom aggregate, Bloom scalar, or Bloom rewrite registration appears in those inspected registration functions ([native_extensions.rs:1-12](../optimization-investigation-queue-worktree/shardloom-vortex/src/native_extensions.rs), and per-extension references listed in the JSON).

The VortexSession implementation/composition and stats rewrite registry's default are supplied by crates whose source is not present in the inspected vendor tree. Therefore these files prove the local `AggregateFnSession` and `ScalarFnSession` defaults, but do not prove the full `VortexSession::default` composition or default stats rewrite contents.

## Relevant existing test names

- `unrestricted_context_writes_the_default_aggregates`
- `a_nullable_ancestor_writes_no_zone_map`
- `a_permitted_set_covering_the_defaults_writes_them`
- `a_forbidden_aggregate_fails_the_write`
- `default_aggregates_bound_variable_length_min_max`
- `default_aggregates_keep_fixed_width_min_max_exact`
- `default_aggregates_never_record_sum`
- `test_metadata_serialization`
- `test_metadata_serialization_preserves_aggregate_options`
- `test_build_unknown_aggregate_disables_pruning_when_allowed`
- `test_build_unknown_aggregate_errors_without_allow_unknown`
- `bloom_rule_prunes_ok`
- `bloom_rule_is_inconclusive_for_nulls`
- `missing_bloom_stat_stays_inconclusive`
- `test_bloom_metadata`

Each name's exact source line range is in `relevant_tests` in the JSON packet. Tests were not run.

## Factual gaps

1. `vendor/vortex-array/src/session.rs` is absent; `session/mod.rs` is the actual module path.
2. The vendored tree lacks the `vortex-session` and `vortex-expr` source needed to establish the full `VortexSession::default` composition and default stats rewrite rules.
3. The no-Bloom-registration observation is scoped to the named ShardLoom call sites and their local extension registration dispatcher, not every possible repository or downstream caller.

The complete source hash inventory and exact line references are in [bloom-registration-inventory-r1.json](./bloom-registration-inventory-r1.json).
