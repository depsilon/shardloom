"""Compare retained pre-composition and current binaries with post-exit CPU counters."""
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
import statistics
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
UAT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
RUN = UAT / 'logs/performance-diagnostic-428b'
HEAD = '9dd328f5cbdae08fa396910e7c6ce747ff16dda1'
QUERY_IDS = [3, 23, 29, 34]
sys.path[:0] = [str(ROOT / 'scripts'), str(OUT)]
from clickbench_reference_packet import load_reference_packet
from freeze_native_release_298 import sources
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
from native_workflow_protocol import extract_result, public_workflow_command, report_fields
from native_host_counters_428 import host, provenance
from run_clickbench_paired_query_uat import generation, role_order
from run_clickbench_query_uat import equivalent, run_command


def read(path):
    return json.loads(Path(path).read_text())


def bound(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1 << 20), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def verify(item):
    assert bound(item['path']) == {k: item[k] for k in ('path', 'bytes', 'sha256')}


def save(path, value):
    with Path(path).open('x') as handle:
        json.dump(value, handle, indent=2, allow_nan=False)
        handle.write('\n')


def main():
    assert not RUN.exists()
    require_local_path(UAT, Path.home(), sys.platform)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD
    frozen = read(OUT / 'context-paired-frozen-426.json')
    old = read(OUT / 'composition-attribution-frozen-419.json')
    current_sources = sources()
    assert current_sources == frozen['active_workspace_sources']
    assert read(OUT / 'context-prepush-source-427.json')['head'] == HEAD
    binaries = dict(control=old['binaries']['control'], candidate=frozen['binaries']['candidate'])
    for item in binaries.values():
        verify(item)
    input_path = Path(frozen['source']['path'])
    require_local_path(input_path, Path.home(), sys.platform)
    original_generation = generation(input_path)
    assert original_generation == frozen['source_generation']
    assert input_path.stat().st_flags == 0
    assert input_path.stat().st_blocks * 512 >= input_path.stat().st_size
    reference = load_reference_packet(Path(frozen['reference']['path']), Path(frozen['queries']['path']))
    verify(frozen['reference'])
    verify(frozen['queries'])
    assert read(OUT / 'host-counter-self-checks-428/summary.json')['status'] == 'passed'

    def guard(reserve=0):
        assert generation(input_path) == original_generation
        return check_budgets(UAT, input_path, RUN, min_free_bytes=12 * GIB,
            reserve_bytes=reserve, max_workspace_bytes=100 * GIB,
            max_log_bytes=1024 * MIB, max_run_log_bytes=256 * MIB,
            reserve_log_bytes=reserve)

    initial_storage = guard(64 * MIB)
    lock = UAT / '.ingest-uat.lock'
    lock.mkdir()
    result = dict(status='running', records=[], complete_values=False)
    try:
        RUN.mkdir()
        # Full input identity is rechecked before any native diagnostic timing.
        verify(frozen['source'])
        assert generation(input_path) == original_generation
        first_host = host()
        assert first_host['thermal_state'] == 0 and not first_host['low_power_mode']
        assert first_host['battery_percent'] >= 35
        expected_power = first_host['power_source']
        helpers = [Path(__file__), OUT / 'native_host_counters_428.py',
            OUT / 'timed_native_diagnostic_428.py', OUT / 'run_guarded.py',
            OUT / 'host-counter-self-checks-428/summary.json',
            OUT / 'context-prepush-source-427.json', OUT / 'context-paired-frozen-426.json',
            OUT / 'composition-attribution-frozen-419.json']
        helpers += [ROOT / 'scripts' / name for name in ('run_clickbench_query_uat.py',
            'run_clickbench_paired_query_uat.py', 'native_workflow_protocol.py',
            'clickbench_reference_packet.py', 'local_uat_storage.py')]
        protocol = dict(schema='shardloom.performance_gap_diagnostic.v1', head=HEAD,
            binaries=binaries, source=frozen['source'], source_generation=original_generation,
            queries=frozen['queries'], reference=frozen['reference'], query_ids=QUERY_IDS,
            query_selection='Q3 scalar aggregate, Q23 selected aggregate, Q29 text grouping and Q34 grouping; diagnostic representatives, not Full43 acceptance',
            memory_gib=24, max_parallelism=12, orders=['forward', 'reverse'], pairs_per_query=3,
            complete_calls=48, helpers=[bound(p) for p in helpers],
            source_map_sha256=hashlib.sha256(json.dumps(current_sources, sort_keys=True).encode()).hexdigest(),
            initial_host=first_host, expected_power_source=expected_power,
            power_admission='at least 35 percent battery, nominal thermal state, low-power mode off, same power source before/after each call',
            counter_provenance=provenance(), storage=initial_storage,
            timing_scope='native process creation through full public output and exit; counter collection, host snapshots, hashes and validation excluded',
            interpretation='diagnostic comparison only; no engine speedup or final benchmark acceptance claim',
            prior_attempt=bound(UAT / 'logs/performance-diagnostic-428/result.json'),
            counter_accounting='wait4 supplies comparison CPU; proc_pid_rusage supplies instruction/cycle/QoS counters, with both CPU surfaces and their observed difference retained',
            cache='same prehashed resident Vortex file; OS cache shared, no forced purge')
        save(RUN / 'protocol.json', protocol)
        result['protocol'] = bound(RUN / 'protocol.json')
        expected_routes = read(OUT / 'composition-timing-primary-419.json')['cohorts']['pre_composition']['per_query']
        schemas = {}
        for reverse in (False, True):
            order = 'reverse' if reverse else 'forward'
            for query in QUERY_IDS:
                for run in range(1, 4):
                    for position, role in enumerate(role_order(query, run, reverse), 1):
                        before = host()
                        assert before['power_source'] == expected_power
                        assert before['battery_percent'] >= 35
                        assert before['thermal_state'] == 0 and not before['low_power_mode']
                        prefix = RUN / f'{order}-q{query:02d}-run{run}-{role}'
                        command = public_workflow_command(binaries[role]['path'],
                            reference['queries'][query - 1], input_path=input_path,
                            input_format='vortex', memory_gb=24, max_parallelism=12)
                        observed = [sys.executable, '-B', str(OUT / 'timed_native_diagnostic_428.py'),
                            '--timing', str(prefix.with_suffix('.timing.json')),
                            '--pid-file', str(prefix.with_suffix('.pid')), '--', *command]
                        outer = run_command(observed, prefix.with_suffix('.stdout.json'),
                            prefix.with_suffix('.stderr.txt'), 120, guard)
                        after = host()
                        timing = read(prefix.with_suffix('.timing.json'))
                        record = dict(order=order, query=query, run=run, role=role,
                            position=position, command=command, host_before=before, host_after=after,
                            outer=outer, timing=timing, passed=False,
                            raw=[bound(prefix.with_suffix(suffix)) for suffix in
                                ('.stdout.json', '.stderr.txt', '.timing.json', '.pid')])
                        result['records'].append(record)
                        assert outer['returncode'] == 0 and not outer['guard_failures']
                        assert timing['returncode'] == 0 and timing['direct_child_reaped']
                        assert timing['cleanup_child_reaped'] and timing['failure'] is None
                        assert prefix.with_suffix('.stderr.txt').stat().st_size == 0
                        envelope = read(prefix.with_suffix('.stdout.json'))
                        fields = report_fields(envelope)
                        assert envelope['status'] == 'success'
                        assert equivalent(extract_result(envelope), reference['values'][query])
                        assert fields['public_workflow_route_id'] == expected_routes[str(query)]['route']
                        assert fields['fallback_attempted'] == fields['external_engine_invoked'] == 'false'
                        assert fields['execution_resource_declared_memory_bytes'] == str(24 << 30)
                        assert fields['execution_resource_declared_max_parallelism'] == '12'
                        assert any(c['kind'] == 'native_io_certificate' and c['status'] == 'available'
                                   for c in envelope['certificates'])
                        schema = (fields['result_schema_format'], json.loads(fields['result_schema_json']))
                        assert schemas.setdefault(query, schema) == schema
                        assert after['power_source'] == expected_power and after['battery_percent'] >= 35
                        assert after['thermal_state'] == 0 and not after['low_power_mode']
                        assert timing['thermal_before']['thermal_state'] == timing['thermal_after']['thermal_state'] == 0
                        cpu = timing['user_cpu_seconds'] + timing['system_cpu_seconds']
                        usage = timing['darwin_rusage_v4']
                        scale = protocol['counter_provenance']['mach_timebase_numer'] / protocol['counter_provenance']['mach_timebase_denom'] / 1e9
                        cpu_counter = (usage['ri_user_time'] + usage['ri_system_time']) * scale
                        # Distinct OS accounting surfaces can differ at multithreaded exit.
                        # Keep both observations; no equality guarantee is assumed.
                        record['darwin_cpu_seconds'] = cpu_counter
                        record['darwin_minus_wait4_cpu_seconds'] = cpu_counter - cpu
                        assert usage['ri_instructions'] > 0 and usage['ri_cycles'] > 0
                        record.update(passed=True, cpu_seconds=cpu, instructions=usage['ri_instructions'],
                            cycles=usage['ri_cycles'], observed_cycles_per_cpu_second=usage['ri_cycles'] / cpu,
                            result_rows=len(extract_result(envelope)), route=fields['public_workflow_route_id'])
                        print(json.dumps(dict(order=order, query=query, run=run, role=role,
                            seconds=timing['seconds'], cpu_seconds=cpu, instructions=usage['ri_instructions'],
                            cycles=usage['ri_cycles'], battery=after['battery_percent'], passed=True)), flush=True)
        assert len(result['records']) == 48 and all(r['passed'] for r in result['records'])
        assert sources() == current_sources
        for item in protocol['helpers'] + list(binaries.values()):
            verify(item)
        guard()
        result.update(status='passed', complete_values=True, source_unchanged=True,
            per_query=[dict(order=order, query=q, role=role, **{
                key: statistics.median(r['timing']['seconds'] if key == 'seconds' else r[key]
                    for r in result['records'] if (r['order'], r['query'], r['role']) == (order, q, role))
                for key in ('seconds', 'cpu_seconds', 'instructions', 'cycles', 'observed_cycles_per_cpu_second')})
                for order in ('forward', 'reverse') for q in QUERY_IDS for role in ('control', 'candidate')])
    except BaseException as error:
        result.update(status='failed', failure=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        if RUN.exists():
            save(RUN / 'result.json', result)
        lock.rmdir()
    print(json.dumps(dict(status=result['status'], calls=len(result['records']), output=str(RUN))), flush=True)


if __name__ == '__main__':
    main()

