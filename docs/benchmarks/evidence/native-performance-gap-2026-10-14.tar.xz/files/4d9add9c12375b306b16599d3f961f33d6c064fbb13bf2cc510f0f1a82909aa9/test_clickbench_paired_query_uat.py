# SPDX-License-Identifier: Apache-2.0
import argparse
import contextlib
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

from local_uat_storage import StorageGuardError
import run_clickbench_paired_query_uat as paired_uat
from benchmark_host_guard import BenchmarkHostError
from run_clickbench_paired_query_uat import (
    archive_completed_logs,
    paired_scores,
    positive_finite,
    resolve_role_sources,
    role_order,
    source_generations,
    source_receipt,
    verify_source_generations,
)


class PairedQueryUatTests(unittest.TestCase):
    def _run_mocked_paired(self, root, observations=None):
        # Reuse the existing complete 43-query reference fixture.
        from test_clickbench_query_uat import ClickBenchUatTests
        query_path, packet_path, binary, source, uat_root = ClickBenchUatTests()._runner_fixture(root)
        nominal = {"platform": "darwin", "monitoring": "macos_power_and_thermal",
                   "power_source": "AC Power", "battery_percent": 80,
                   "thermal_state": 0, "low_power_mode": False}

        def fake_profile(command, prefix, timeout, guard):
            schema = {"Struct": [{"names": ["value"], "dtypes": [{"Primitive": ["i64", False]}]}, False]}
            fields = {
                "public_workflow_fallback_attempted": "false",
                "public_workflow_external_engine_invoked": "false",
                "result_values_json": '[{"value":1}]', "result_payload_complete": "true",
                "output_row_count": "1", "result_schema_json": json.dumps(schema),
                "result_schema_format": "vortex.dtype.serde.v1",
            }
            prefix.with_suffix(".stdout.json").write_text(json.dumps({
                "status": "success", "fallback": {"attempted": False, "allowed": False},
                "fields": [{"key": k, "value": v} for k, v in fields.items()]}))
            for suffix, content in ((".stderr.txt", ""), (".timing.json", "{}"), (".pid", "0")):
                prefix.with_suffix(suffix).write_text(content)
            guard()
            return {"returncode": 0, "guard_failures": [], "seconds": 0.1}

        argv = ["paired", "--control-binary", str(binary), "--candidate-binary", str(binary),
                "--control-commit", "old", "--candidate-commit", "new", "--input", str(source),
                "--uat-root", str(uat_root), "--queries", str(query_path),
                "--reference-packet", str(packet_path), "--query-ids", "1"]
        with (patch.object(sys, "argv", argv),
              patch.object(paired_uat, "check_budgets", return_value={}),
              patch.object(paired_uat, "host_snapshot", side_effect=lambda: {}),
              patch.object(paired_uat, "run_profiled_command", side_effect=fake_profile),
              patch("benchmark_host_guard.snapshot", side_effect=observations, return_value=nominal),
              contextlib.redirect_stdout(io.StringIO())):
            result = paired_uat.main()
        summaries = list((uat_root / "logs").glob("paired43_*/summary.json"))
        self.assertEqual(len(summaries), 1)
        self.assertFalse((uat_root / ".ingest-uat.lock").exists())
        return result, json.loads(summaries[0].read_text())

    def test_paired_runner_preserves_healthy_host_evidence_and_binds_guard(self):
        with tempfile.TemporaryDirectory() as directory:
            code, summary = self._run_mocked_paired(Path(directory))
        self.assertEqual(code, 0)
        self.assertTrue(summary["scores"]["complete"])
        self.assertEqual(len(summary["records"]), 6)
        self.assertEqual(summary["host_conditions"]["status"], "admitted")
        self.assertIn("benchmark_host_guard.py", {Path(p).name for p in summary["harness_sha256"]})

    def test_paired_runner_rejects_a_power_change_after_a_correct_result(self):
        nominal = {"platform": "darwin", "monitoring": "macos_power_and_thermal",
                   "power_source": "AC Power", "battery_percent": 80,
                   "thermal_state": 0, "low_power_mode": False}
        with tempfile.TemporaryDirectory() as directory:
            code, summary = self._run_mocked_paired(Path(directory),
                [nominal, dict(nominal, power_source="Battery Power")])
        self.assertEqual(code, 1)
        self.assertFalse(summary["scores"]["complete"])
        self.assertEqual(summary["host_conditions"]["status"], "rejected")
        self.assertFalse(summary["records"][0]["passed"])

    def test_paired_preflight_retains_failure_without_starting_a_query(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with self.assertRaisesRegex(BenchmarkHostError, "recharge"):
                self._run_mocked_paired(root, [{"platform": "darwin", "monitoring": "macos_power_and_thermal",
                    "power_source": "AC Power", "battery_percent": 2,
                    "thermal_state": 0, "low_power_mode": False}])
            summary = json.loads(next((root / "uat/logs").glob("paired43_*/summary.json")).read_text())
            self.assertFalse(summary["completed_identity_check"])
            self.assertEqual(summary["records"], [])
            self.assertIn("recharge", summary["failure"])
            self.assertFalse((root / "uat/.ingest-uat.lock").exists())

    def test_role_sources_default_to_control_and_receipt_freezes_both_roles(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            control = root / "control.vortex"
            candidate = root / "candidate.vortex"
            control.write_bytes(b"control generation")
            candidate.write_bytes(b"candidate generation")

            same_source = resolve_role_sources(control, home=root, platform="linux")
            self.assertEqual(same_source["control"], control.resolve())
            self.assertEqual(same_source["candidate"], control.resolve())
            same_receipt = source_receipt(same_source)
            self.assertEqual(same_receipt["control"]["path"], str(control.resolve()))
            self.assertEqual(same_receipt["candidate"], same_receipt["control"])

            role_sources = resolve_role_sources(control, candidate, home=root, platform="linux")
            frozen = source_generations(role_sources)
            receipt = source_receipt(role_sources, frozen)
            self.assertEqual(receipt["control"]["path"], str(control.resolve()))
            self.assertEqual(receipt["candidate"]["path"], str(candidate.resolve()))
            self.assertEqual(receipt["control"]["generation"], frozen["control"])
            self.assertEqual(receipt["candidate"]["generation"], frozen["candidate"])
            verify_source_generations(role_sources, frozen)

            candidate.write_bytes(b"changed candidate generation")
            with self.assertRaisesRegex(ValueError, "candidate"):
                verify_source_generations(role_sources, frozen)

    def test_max_workspace_limit_must_be_positive_and_finite(self):
        self.assertEqual(positive_finite("110"), 110)
        for value in ("0", "-1", "nan", "inf", "-inf", "not-a-number"):
            with self.subTest(value=value), self.assertRaises(argparse.ArgumentTypeError):
                positive_finite(value)

    def test_each_query_has_both_orders_and_adjacent_queries_balance(self):
        first_roles = []
        for query in (1, 2):
            orders = [role_order(query, run) for run in range(1, 4)]
            self.assertEqual({o[0] for o in orders}, {"control", "candidate"})
            for run, order in enumerate(orders, 1):
                self.assertEqual(set(order), {"control", "candidate"})
                self.assertEqual(role_order(query, run, True), tuple(reversed(order)))
                first_roles.append(order[0])
        self.assertEqual(first_roles.count("control"), 3)
        self.assertEqual(first_roles.count("candidate"), 3)

    def test_scoring_keeps_queries_roles_and_pairs_separate(self):
        records = []
        for query in (1, 2):
            for run in (1, 2, 3):
                for role in ("candidate", "control"):
                    seconds = (100 if query == 1 else 2) + (3 if role == "candidate" else 0) + run
                    records.append(dict(query=query, run=run, role=role, seconds=seconds, passed=True))
        result = paired_scores(list(reversed(records)), [1, 2])
        self.assertTrue(result["complete"])
        self.assertEqual(result["score_scope"], "targeted_only")
        self.assertEqual(result["roles"]["control"]["query_total_seconds"], 104)
        self.assertEqual(result["roles"]["candidate"]["query_total_seconds"], 110)
        self.assertEqual(result["per_query"][0]["median_seconds"], {"control": 102, "candidate": 105})
        self.assertEqual(result["per_query"][1]["paired_candidate_minus_control_seconds"], [3, 3, 3])
        self.assertFalse(paired_scores(records[:-1], [1, 2])["complete"])
        self.assertFalse(paired_scores(records[:-1] + [records[0]], [1, 2])["complete"])
        records[0]["passed"] = False
        self.assertFalse(paired_scores(records, [1, 2])["complete"])

    def test_archive_preserves_values_hashes_and_rejects_overwrite(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            data = {"result.json": b'{"values":[1,null,"Tokyo"]}', "stderr.txt": b""}
            paths = [root / name for name in data]
            for path in paths:
                path.write_bytes(data[path.name])
            reservations = []
            target = root / "completed.tar.xz"
            receipt = archive_completed_logs(paths, target, reservations.append)
            self.assertGreater(reservations[0], 0)
            self.assertEqual(reservations[-1], 0)
            with tarfile.open(target, "r:xz") as archive:
                for member in receipt["members"]:
                    raw = archive.extractfile(member["name"]).read()
                    self.assertEqual(raw, data[member["name"]])
                    self.assertEqual(hashlib.sha256(raw).hexdigest(), member["sha256"])
            self.assertTrue(all(not p.exists() for p in paths))
            for path in paths:
                path.write_bytes(b"competing evidence")
            with self.assertRaises(FileExistsError):
                archive_completed_logs(paths, target, lambda reserve: None)
            self.assertTrue(all(p.read_bytes() == b"competing evidence" for p in paths))

    def test_archive_denial_preserves_raw_and_rejects_unowned_paths(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / "result.json"
            path.write_bytes(b"complete")
            target = root / "completed.tar.xz"
            def deny(reserve):
                raise StorageGuardError("no temporary archive budget")
            with self.assertRaises(StorageGuardError):
                archive_completed_logs([path], target, deny)
            self.assertEqual(path.read_bytes(), b"complete")
            self.assertFalse(target.exists())
            with self.assertRaises(ValueError):
                archive_completed_logs([path, path], target, lambda reserve: None)
            with self.assertRaises(ValueError):
                archive_completed_logs([path], root / "nested" / "completed.tar.xz", lambda reserve: None)


if __name__ == "__main__":
    unittest.main()
