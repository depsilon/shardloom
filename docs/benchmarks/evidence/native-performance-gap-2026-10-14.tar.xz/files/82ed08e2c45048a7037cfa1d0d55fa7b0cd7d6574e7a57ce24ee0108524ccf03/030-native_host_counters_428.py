"""Read Darwin process counters without changing host power or scheduling policy."""
import ctypes
import datetime as dt
import errno
import hashlib
import os
from pathlib import Path
import re
import subprocess

SDK = Path('/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk')
HEADER = SDK / 'usr/include/sys/resource.h'
WAIT_HEADER = SDK / 'usr/include/sys/wait.h'
FOUNDATION_HEADER = SDK / 'System/Library/Frameworks/Foundation.framework/Headers/NSProcessInfo.h'
header_text = HEADER.read_text()
layout = re.search(r'struct rusage_info_v4 \{(.*?)\};', header_text, re.S).group(1)
COUNTERS = re.findall(r'uint64_t\s+(\w+);', layout)
assert len(COUNTERS) == 35 and COUNTERS[-6:] == [
    'ri_instructions', 'ri_cycles', 'ri_billed_energy', 'ri_serviced_energy',
    'ri_interval_max_phys_footprint', 'ri_runnable_time']


class Usage(ctypes.Structure):
    _fields_ = [('ri_uuid', ctypes.c_uint8 * 16)] + [(n, ctypes.c_uint64) for n in COUNTERS]


class Timebase(ctypes.Structure):
    _fields_ = [('numer', ctypes.c_uint32), ('denom', ctypes.c_uint32)]


LIB = ctypes.CDLL('/usr/lib/libproc.dylib', use_errno=True)
LIB.proc_pid_rusage.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_void_p]
LIB.proc_pid_rusage.restype = ctypes.c_int
SYSTEM = ctypes.CDLL(None, use_errno=True)
SYSTEM.waitid.argtypes = [ctypes.c_int, ctypes.c_uint, ctypes.c_void_p, ctypes.c_int]
SYSTEM.waitid.restype = ctypes.c_int
SYSTEM.mach_timebase_info.argtypes = [ctypes.POINTER(Timebase)]
SYSTEM.mach_timebase_info.restype = ctypes.c_int
TIMEBASE = Timebase()
assert SYSTEM.mach_timebase_info(ctypes.byref(TIMEBASE)) == 0 and TIMEBASE.denom > 0
ctypes.CDLL('/System/Library/Frameworks/Foundation.framework/Foundation')
OBJC = ctypes.CDLL('/usr/lib/libobjc.A.dylib')
OBJC.objc_getClass.argtypes = [ctypes.c_char_p]
OBJC.objc_getClass.restype = ctypes.c_void_p
OBJC.sel_registerName.argtypes = [ctypes.c_char_p]
OBJC.sel_registerName.restype = ctypes.c_void_p
SEND_PTR = ctypes.CFUNCTYPE(ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p)(('objc_msgSend', OBJC))
SEND_INT = ctypes.CFUNCTYPE(ctypes.c_long, ctypes.c_void_p, ctypes.c_void_p)(('objc_msgSend', OBJC))
PROCESS_INFO = SEND_PTR(OBJC.objc_getClass(b'NSProcessInfo'), OBJC.sel_registerName(b'processInfo'))


def thermal():
    state = SEND_INT(PROCESS_INFO, OBJC.sel_registerName(b'thermalState'))
    low = SEND_INT(PROCESS_INFO, OBJC.sel_registerName(b'isLowPowerModeEnabled'))
    assert state in range(4) and low in (0, 1)
    return dict(thermal_state=state, thermal_label=['nominal', 'fair', 'serious', 'critical'][state],
                low_power_mode=bool(low))


def host():
    power = subprocess.run(['/usr/bin/pmset', '-g', 'batt'], capture_output=True,
                           text=True, timeout=10, check=True).stdout
    source = re.search(r"Now drawing from '([^']+)'", power)
    percent = re.search(r'\b(\d+)%;', power)
    if not source or not percent:
        raise ValueError('power state could not be parsed')
    return dict(utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                power_source=source[1], battery_percent=int(percent[1]),
                power_raw=power, load_average=os.getloadavg(), **thermal())


def usage(pid):
    item = Usage()
    if LIB.proc_pid_rusage(pid, 4, ctypes.byref(item)) != 0:
        error = ctypes.get_errno()
        raise OSError(error, os.strerror(error))
    return {name: getattr(item, name) for name in COUNTERS}


def await_exit_without_reaping(pid):
    # SDK sys/wait.h: P_PID=1, WEXITED=0x4, WNOWAIT=0x20.
    # The 512-byte aligned buffer exceeds Darwin siginfo_t; fields are not read.
    info = (ctypes.c_uint64 * 64)()
    while SYSTEM.waitid(1, pid, ctypes.byref(info), 0x4 | 0x20) != 0:
        error = ctypes.get_errno()
        if error == errno.EINTR:
            continue
        raise OSError(error, os.strerror(error))


def provenance():
    return dict(rusage_flavor=4, rusage_struct_bytes=ctypes.sizeof(Usage),
        mach_timebase_numer=TIMEBASE.numer, mach_timebase_denom=TIMEBASE.denom,
        headers=[dict(path=str(p), sha256=hashlib.sha256(p.read_bytes()).hexdigest())
                 for p in (HEADER, WAIT_HEADER, FOUNDATION_HEADER)])
