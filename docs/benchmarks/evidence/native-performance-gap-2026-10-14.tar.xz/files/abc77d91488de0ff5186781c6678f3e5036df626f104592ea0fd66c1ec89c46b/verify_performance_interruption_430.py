"""Independently check the interrupted confirmation inventory against raw evidence."""
import hashlib
import json
import math
from pathlib import Path
import re
import statistics

OUT = Path(__file__).resolve().parent
RUN = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat/logs/performance-full43-429')


def read(path):
    return json.loads(path.read_text())


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def locate(value, locator):
    assert locator.startswith('result.json.')
    for key, index in re.findall(r'([A-Za-z_][A-Za-z_0-9]*)|\[(\d+)\]', locator[len('result.json.'):]):
        value = value[int(index)] if index else value[key]
    return value


def main():
    worker_path = OUT / 'performance-full43-interruption-429.json'
    worker, raw = read(worker_path), read(RUN / 'result.json')
    assert identity(RUN / 'protocol.json') == raw['protocol']
    assert all(worker['protocol_identity'][k] == v for k, v in identity(RUN / 'protocol.json').items())
    assert worker['result_identity'] == identity(RUN / 'result.json')
    assert worker['protocol'] == read(RUN / 'protocol.json')
    assert len(worker['samples']) == len(raw['records']) == 122
    assert raw['status'] == 'failed' and raw['complete_values'] is False
    assert worker['all_host_observations']['samples'] == raw['host_observations']
    assert len(raw['host_observations']) == worker['all_host_observations']['count'] == 85
    keys, hashes, fields = set(), 0, 0
    for i, sample in enumerate(worker['samples']):
        row = raw['records'][i]
        assert sample['source_locator'] == f'result.json.records[{i}]'
        key = tuple(sample[k] for k in ('order', 'query', 'run', 'role'))
        assert key not in keys
        keys.add(key)
        for field, locator in sample['field_source_locators'].items():
            try:
                expected = locate(raw, locator)
            except KeyError:
                assert i == 121 and field in ('route', 'result_rows')
                expected = None
            assert sample[field] == expected, (i, field)
            fields += 1
        assert sample['total_cpu_seconds'] == sample['user_cpu_seconds'] + sample['system_cpu_seconds']
        assert len(sample['raw_files']) == len(row['raw']) == 4
        for observation, expected in zip(sample['raw_files'], row['raw']):
            actual = identity(Path(expected['path']))
            assert actual == expected
            assert all(observation[k] == actual[k] for k in actual)
            assert observation['matches_expected'] is True
            hashes += 1
    expected_keys = {('forward', q, run, role) for q in range(1, 21)
                     for run in (1, 2, 3) for role in ('control', 'candidate')}
    expected_keys |= {('forward', 21, 1, role) for role in ('control', 'candidate')}
    assert keys == expected_keys
    metrics = ('elapsed_seconds', 'user_cpu_seconds', 'system_cpu_seconds', 'total_cpu_seconds')
    assert len(worker['completed_query_summaries']) == 20
    totals = {role: {metric: 0.0 for metric in metrics} for role in ('control', 'candidate')}
    for query in worker['completed_query_summaries']:
        q = query['query_id']
        for role, observed in query['role_summaries'].items():
            rows = [r for r in worker['samples'] if r['query'] == q and r['role'] == role]
            assert observed['call_count'] == len(rows) == 3 and all(r['passed'] for r in rows)
            for metric in metrics:
                assert observed['all_call_sums'][metric] == sum(r[metric] for r in rows)
                assert observed['medians'][metric] == statistics.median(r[metric] for r in rows)
                totals[role][metric] += observed['all_call_sums'][metric]
            assert observed['medians']['peak_rss_bytes'] == statistics.median(r['peak_rss_bytes'] for r in rows)
        rows = [r for r in worker['samples'] if r['query'] == q]
        # Inventory sums role totals; raw records alternate roles. Float addition
        # order differs by at most a few ulps, not a meaningful timing tolerance.
        assert all(math.isclose(query['both_role_all_call_sums'][m], math.fsum(r[m] for r in rows),
                                rel_tol=1e-14, abs_tol=1e-14) for m in metrics)
    final = raw['records'][-1]
    assert worker['result_summary']['outer_guard_failure_record'] == worker['samples'][-1]
    assert final['passed'] is False and final['outer']['returncode'] == 130
    assert final['host_before']['thermal_state'] == 0 and final['host_after']['thermal_state'] == 1
    assert worker['result_summary']['failure_exact'] == raw['failure']
    report = dict(status='passed', inventory=identity(worker_path), observed_calls=122,
                  successful_calls=sum(r['passed'] for r in raw['records']), verified_fields=fields,
                  verified_raw_files=hashes, verified_host_samples=85, complete_queries=20,
                  completed_query_totals=totals, whole_suite_confirmation=False,
                  verification='Primary compared source locators, complete key coverage, every bound raw byte/hash, host samples and all completed-query aggregates.')
    with (OUT / 'performance-interruption-primary-430.json').open('x') as handle:
        json.dump(report, handle, indent=2)
        handle.write('\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
