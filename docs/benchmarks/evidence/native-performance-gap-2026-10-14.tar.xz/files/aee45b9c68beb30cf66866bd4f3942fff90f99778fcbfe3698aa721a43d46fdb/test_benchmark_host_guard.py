# SPDX-License-Identifier: Apache-2.0
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch

from benchmark_host_guard import BenchmarkHostError, BenchmarkHostGuard, parse_macos_power, snapshot
from run_clickbench_query_uat import run_profiled_command


def nominal_host():
    return dict(platform="darwin", monitoring="macos_power_and_thermal", utc="test",
                power_source="Battery Power", battery_percent=70,
                thermal_state=0, low_power_mode=False)


def host_with(**changes):
    value = nominal_host()
    value.update(changes)
    return value


class BenchmarkHostGuardTests(unittest.TestCase):
    def test_power_parser_handles_laptop_and_desktop(self):
        for source in ("AC Power", "Battery Power"):
            for percent in (0, 35, 100):
                text = f"Now drawing from '{source}'\n -InternalBattery-0 (id=123)\t{percent}%; charging\n"
                self.assertEqual(parse_macos_power(text), dict(power_source=source, battery_percent=percent))
        self.assertEqual(parse_macos_power("Now drawing from 'AC Power'\n"),
                         dict(power_source="AC Power", battery_percent=None))

    def test_power_parser_rejects_unknown_ambiguous_and_invalid_data(self):
        samples = ["", "Now drawing from 'UPS Power'", "Now drawing from 'Battery Power'",
                   "Now drawing from 'AC Power'\nNow drawing from 'Battery Power'",
                   "Now drawing from 'AC Power'\nInternalBattery-0\t101%;",
                   "Now drawing from 'AC Power'\nInternalBattery-0\t-1%;",
                   "Now drawing from 'AC Power'\nInternalBattery-0\tunknown",
                   "Now drawing from 'AC Power'\nInternalBattery-0\t50%;\nInternalBattery-1\t50%;"]
        for sample in samples:
            with self.subTest(sample=sample), self.assertRaises(BenchmarkHostError):
                parse_macos_power(sample)

    def test_other_platforms_are_explicitly_unmonitored_without_probes(self):
        with patch("benchmark_host_guard.subprocess.run") as run, patch("benchmark_host_guard._darwin_process_info") as info:
            observation = snapshot(platform="linux")
        run.assert_not_called()
        info.assert_not_called()
        guard = BenchmarkHostGuard(observer=lambda: observation)
        self.assertEqual(guard.check(), observation)
        self.assertEqual(guard.report["status"], "unmonitored")

    def test_macos_capture_is_read_only_and_retains_raw_power(self):
        power = "Now drawing from 'Battery Power'\nInternalBattery-0\t60%; discharging;\n"
        info = Mock()
        info.read.return_value = dict(thermal_state=0, thermal_label="nominal", low_power_mode=False)
        with (patch("benchmark_host_guard.subprocess.run", return_value=subprocess.CompletedProcess([], 0, power, "")) as run,
              patch("benchmark_host_guard._darwin_process_info", return_value=info)):
            observed = snapshot(platform="darwin")
        self.assertEqual(run.call_args.args[0], ["/usr/bin/pmset", "-g", "batt"])
        self.assertEqual(observed["power_raw"], power)
        self.assertEqual(observed["battery_percent"], 60)
        self.assertFalse(observed["low_power_mode"])

    def test_mac_observation_failures_are_latched_with_original_reason(self):
        for error in (OSError("missing power tool"), subprocess.TimeoutExpired("pmset", 5),
                      BenchmarkHostError("bad output")):
            with self.subTest(error=type(error).__name__):
                observer = Mock(side_effect=error)
                guard = BenchmarkHostGuard(observer=observer)
                with self.assertRaisesRegex(BenchmarkHostError, "unavailable"):
                    guard.check()
                with self.assertRaises(BenchmarkHostError):
                    guard.check(force=True)
                self.assertEqual(observer.call_count, 1)
                self.assertEqual(guard.report["status"], "rejected")
                self.assertEqual(guard.report["observations"][0]["error"], str(error))

    def test_charge_floor_applies_even_while_charging_and_desktop_is_allowed(self):
        for source in ("AC Power", "Battery Power"):
            for charge in (2, 34):
                with self.subTest(source=source, charge=charge), self.assertRaisesRegex(BenchmarkHostError, "recharge"):
                    BenchmarkHostGuard(observer=lambda: host_with(power_source=source, battery_percent=charge)).check()
            guard = BenchmarkHostGuard(observer=lambda: host_with(power_source=source, battery_percent=35))
            guard.check()
            self.assertEqual(guard.report["status"], "admitted")
        guard = BenchmarkHostGuard(observer=lambda: host_with(power_source="AC Power", battery_percent=None))
        guard.check()
        self.assertEqual(guard.report["status"], "admitted")

    def test_pressure_low_power_and_unavailable_values_are_rejected(self):
        changes = [dict(thermal_state=state) for state in (1, 2, 3, None, False)]
        changes += [dict(low_power_mode=mode) for mode in (True, None, 0)]
        changes += [dict(battery_percent=charge) for charge in (None, -1, 101, True)]
        changes += [dict(monitoring="not_monitored_on_this_platform")]
        for change in changes:
            with self.subTest(change=change), self.assertRaises(BenchmarkHostError):
                BenchmarkHostGuard(observer=lambda: host_with(**change)).check()

    def test_source_change_rejection_is_sticky_after_recovery(self):
        observer = Mock(side_effect=[nominal_host(), host_with(power_source="AC Power"), nominal_host()])
        guard = BenchmarkHostGuard(observer=observer)
        guard.check(force=True)
        with self.assertRaisesRegex(BenchmarkHostError, "source changed"):
            guard.check(force=True)
        with self.assertRaisesRegex(BenchmarkHostError, "source changed"):
            guard.check(force=True)
        self.assertEqual(observer.call_count, 2)
        self.assertEqual(guard.report["failure_observation_index"], 1)
        self.assertEqual(guard.report["initial_power_source"], "Battery Power")

    def test_watchdog_sampling_is_bounded_but_call_boundaries_force_observation(self):
        now = [0.0]
        observer = Mock(side_effect=nominal_host)
        guard = BenchmarkHostGuard(observer=observer, clock=lambda: now[0])
        guard.check()
        now[0] = 1.9
        guard.check()
        self.assertEqual(observer.call_count, 1)
        guard.check(force=True)
        self.assertEqual(observer.call_count, 2)
        now[0] = 4.0
        guard.check()
        self.assertEqual(observer.call_count, 3)

    def test_thermal_rejection_stops_and_reaps_the_native_child(self):
        observer = Mock(side_effect=[nominal_host(), host_with(thermal_state=1)])
        guard = BenchmarkHostGuard(observer=observer)
        guard.check(force=True)
        with tempfile.TemporaryDirectory() as directory:
            prefix = Path(directory) / "thermal"
            with self.assertRaisesRegex(BenchmarkHostError, "thermal state"):
                run_profiled_command([sys.executable, "-c", "import time; time.sleep(30)"],
                                     prefix, 10, lambda: guard.check(force=True))
            timing = json.loads(prefix.with_suffix(".timing.json").read_text())
            self.assertEqual(timing["returncode"], 130)
            self.assertLess(timing["seconds"], 5)
            pid = int(prefix.with_suffix(".pid").read_text())
            with self.assertRaises(ProcessLookupError):
                os.kill(pid, 0)
        self.assertEqual(guard.report["status"], "rejected")


if __name__ == "__main__":
    unittest.main()
