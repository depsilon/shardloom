<!-- SPDX-License-Identifier: Apache-2.0 -->

# Historical query performance gap: investigation remains open

Status: the focused comparison is complete, but the new complete-suite
confirmation was interrupted by thermal admission. PR #1551, the version bump
and other breadth/ship-drop work remain paused. Needed capabilities are retained.
This report does not establish that every historical timing difference came
from the host, nor does it claim a new complete 177-second result.

## Question and measurement boundary

The earlier complete observations total 177.372562, 214.675706 and 211.784749
seconds across 129 query processes: all 43 queries, three calls each. They are
sums of complete native process times, not sums of query minima or elapsed
workflow time. Their original evidence remains in the
[composition investigation](native-composition-attribution-2026-10-14.md).
The later [context correction](native-admitted-context-2026-10-14.md) passes its
finite paired rule but records substantially slower absolute times. That does
not resolve the historical difference.

The diagnostic compares the exact retained executable from the 177-second
cohort with the current combined decoder/context correction:

| Role | Executable SHA-256 | Source |
| --- | --- | --- |
| Control | `490f00b2e29842b3a4b066245612a2243c8ce8da67a8decc29097e9bec4d0ff7` | Accepted pre-composition source `ed253d1ec74b724215f71f0b410123656e596696`. |
| Candidate | `fee87124c91b90f5f02ff1f9f00d9eaae7fd87724e152641a98bda2efb8725c9` | Frozen combined correction, subsequently committed as `9dd328f5`. |

Both use the same retained Vortex file: 99,997,497 rows, 15,713,610,513 bytes,
SHA-256 `004f9639fa0aa527b70f326c366c37b1173dceeacb92b50b2d8fd02957155c18`.
The host record is macOS 27 arm64, 10 logical CPUs and 16 GiB physical memory.
The public request declares 24 GiB and maximum parallelism 12; the native
resource envelope reports effective parallelism 10. The memory declaration
is neither physical RAM nor an enforced process-RSS limit.

Every call uses the public SQL workflow, includes process startup, complete
output and exit, and checks complete retained reference values and no-fallback
certificates. Reference values are retained native regression evidence, not a
fresh independent oracle. The input is prehashed; OS caches and ordinary
desktop activity remain uncontrolled. Input hashing, host snapshots and result
verification are outside the native process clock. The same observer is used
for both roles. No engine behavior changed during these observations.

## Focused comparison

Q3, Q23, Q29 and Q34 each run three alternating pairs in both starting orders:
48 complete calls. All results pass. Medians below preserve both orders; the
historical column is a separately observed cohort, not a matched estimate.

| Query | Historical median | Forward control | Forward candidate | Reverse control | Reverse candidate |
| --- | ---: | ---: | ---: | ---: | ---: |
| Q3 | 0.956776 | 0.937482 | 0.902804 | 1.031612 | 0.985775 |
| Q23 | 3.307699 | 3.217206 | 3.166795 | 3.394104 | 3.486621 |
| Q29 | 5.471411 | 5.446654 | 5.561070 | 5.711429 | 5.762420 |
| Q34 | 2.604848 | 2.347250 | 2.381942 | 3.129090 | 2.397176 |

Times are seconds. For Q3/Q23/Q29, candidate instruction-count medians differ
from control by less than 1% in both orders. The largest candidate increase in
elapsed median across these eight query/order comparisons is 2.73%; this is a
bounded diagnostic observation, not a general overhead bound. Q34's reverse
control is slower than its forward control and remains in the evidence.

The instrumentation keeps `wait4` CPU time separate from Darwin instruction
and cycle counters. An initial seven-call attempt stopped because the two CPU
accounting surfaces exceeded an incorrectly strict 0.2% equality check. That
failed attempt is retained. The corrected protocol uses `wait4` consistently
for comparative CPU time and preserves both surfaces and their difference.
It does not treat the two accounting APIs as interchangeable.

## Complete-suite attempt and observed host conditions

A fresh all-query paired attempt completed three calls per role for Q1–Q20:

| Scope | Control | Candidate |
| --- | ---: | ---: |
| Complete native calls | 60 | 60 |
| Sum of process times, seconds | 80.161570 | 79.552840 |
| Sum of process CPU time, seconds | 261.121638 | 259.457821 |

Q21 control run 1 also passed. During candidate run 1, macOS changed from
nominal thermal state to fair. The watchdog stopped the native process; its
return code is 130 and its incomplete output is not accepted. The attempt
retains 122 observed calls, 121 successful results, 85 sampled host observations
and all 488 bound raw files. Its supervised driver lasted 185.306339 seconds.
There is no complete Full43 total from this attempt, and its completed prefix
must not replace the declared complete cohort.

The run began on battery at 42% and ended at 39%, with Low Power Mode disabled.
Separately, the preserved OS power history records 3% battery at 09:23 local
and an AC attachment at 2% at 09:25, overlapping the earlier slow comparison.
This establishes a power-state confounder; it does not measure that cohort's
CPU frequency or prove how much of its duration the power state caused.
The new thermal interruption is directly observed. Historical cohorts lack
equivalent per-call power/thermal observations, so their full cause remains open.

## ShardLoom technique review

The candidate's actual outputs report these existing execution paths, which
were checked against their native implementations:

- Q3: direct dictionary/typed scalar aggregate updates.
- Q23: dictionary-code top-k with exact first-pass late measures; the reported
  late-measure second pass is false.
- Q29: transformed-dictionary chunk partials, dense accumulation and capillary
  top-k candidate selection.
- Q34: complete-key partition reconciliation and exact top-k; its report
  identifies second-scan avoidance.

The resource envelope retains 262,144-row capillary targets. Pressure-signal
labels alone do not prove that a scheduler adaptation occurred or would improve
these queries. This pass does not change PulseWeave scheduling, scan granularity,
encoding policy, native output, context ownership or decoder admission. Further
engine optimization must identify a measured missing opportunity below the
shared native boundary and preserve the needed capabilities.

## Benchmark harness correction and verification

Both maintained query runners now sample Mac power source, battery charge,
Low Power Mode and reported thermal state before/after native calls and through
the existing watchdog at roughly two-second intervals. They reject a changing
power source, charge below 35%, enabled/unknown Low Power Mode, unavailable
observations or a non-nominal thermal state. The 35% floor is a conservative
benchmark policy, not an Apple throttling threshold. Reported nominal state
does not establish fixed frequency, exclusive CPU use or a cold cache.

Admission failures remain latched, stop/reap the child through the existing
supervisor, release the owned UAT lock and retain a failure receipt plus raw
paths. Receipt/storage writes do not reapply the failed thermal gate. Other
platforms explicitly report that power/thermal monitoring is unavailable.
No host power setting or scheduling policy is changed.

All 52 harness/reference tests pass. Four negative integration regressions
fail against the original runner bodies and pass after the correction.
The exact CI discovery commands also pass, including the paired runner and
new host guard; the CI gate-matrix validator passes. A real Q1 smoke through
the updated paired runner completes all six native calls with admitted Mac
host observations, full-value equality and final identity checks. It verifies
the harness integration and does not supply full-suite performance acceptance.
Source comparison verifies
that the six changed Python files belong to the benchmark harness/tests and
that the other 2,241 selected source paths remain identical. The previously
passed Rust/native gates remain attached to the unchanged engine source;
they were not rerun for this benchmark-harness correction.

The [portable observations](evidence/native-performance-gap-2026-10-14.tar.xz),
[member manifest](evidence/native-performance-gap-2026-10-14.json.xz) and
[readback verification](evidence/native-performance-gap-2026-10-14.verification.json)
retain the protocols, raw calls, helper snapshots, counter checks, failed
attempts, primary verification and harness regression evidence. Large binaries
and the input dataset are identified by hash and remain outside the packet.

## Remaining acceptance

Complete a new frozen all-query comparison with enough battery headroom,
stable power and admitted thermal conditions, retaining both binaries, every
sample and any interruption. Any planned cooling intervals must be declared
before timing and included in workflow wall time; such an observation must not
be described as uninterrupted sustained throughput. Preserve the existing
median breach rule and reverse-order checks. Do not replace the paired result
with a faster single pass or remove guard failures to obtain a target number.

The full-suite performance gate remains unchecked. No merge, release, broad
capability closeout or performance-superiority claim follows from this report.
