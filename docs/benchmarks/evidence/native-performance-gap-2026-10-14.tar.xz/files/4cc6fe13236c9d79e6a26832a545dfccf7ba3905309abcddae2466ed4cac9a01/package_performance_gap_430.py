"""Package diagnostic observations without granting complete-suite acceptance."""
import hashlib
import io
import json
import lzma
from pathlib import Path
import sys
import tarfile

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
UAT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
SMOKE = UAT / 'logs/paired43_20261014T160130558775Z'
NAME = 'native-performance-gap-2026-10-14'
sys.path[:0] = [str(ROOT / 'scripts'), str(OUT)]
from freeze_native_release_298 import sources
from local_uat_storage import GIB, MIB, check_budgets
from native_workflow_protocol import report_fields


def read(path):
    return json.loads(Path(path).read_text())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    data = Path(path).read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def main():
    assert not (UAT / '.ingest-uat.lock').exists()
    storage = check_budgets(OUT, OUT / NAME, OUT / 'logs', min_free_bytes=12 * GIB,
                           reserve_bytes=96 * MIB, max_workspace_bytes=100 * GIB,
                           max_log_bytes=192 * MIB)
    assert sources() == read(OUT / 'benchmark-host-source-430.json')['current_source_sha256']
    snapshots = read(OUT / 'performance-frozen-helpers-429/manifest.json')
    replacements = {(row['original'], row['sha256']): Path(row['snapshot']) for row in snapshots['members']}
    entries, payloads = {}, {}

    def add(path, expected=None):
        path = Path(path)
        actual = path
        assert path.stat().st_size <= 16 * MIB, path
        data = path.read_bytes()
        if expected and digest(data) != expected['sha256']:
            actual = replacements[(str(path), expected['sha256'])]
            data = actual.read_bytes()
        if expected:
            assert digest(data) == expected['sha256'], path
            if 'bytes' in expected:
                assert len(data) == expected['bytes'], path
        sha = digest(data)
        member = f'files/{sha}/{path.name}'
        payloads.setdefault(member, data)
        entries[(str(path), sha)] = dict(original=str(path), captured_from=str(actual),
                                        member=member, bytes=len(data), sha256=sha)

    cohorts = []
    for name, expected_count, expected_status in (
            ('performance-diagnostic-428', 7, 'failed'),
            ('performance-diagnostic-428b', 48, 'passed'),
            ('performance-full43-429', 122, 'failed')):
        directory = UAT / 'logs' / name
        result, protocol = read(directory / 'result.json'), read(directory / 'protocol.json')
        assert len(result['records']) == expected_count and result['status'] == expected_status
        add(directory / 'result.json')
        add(directory / 'protocol.json', result['protocol'])
        for item in protocol['helpers']:
            add(item['path'], item)
        for item in protocol.get('counter_provenance', {}).get('headers', []):
            add(item['path'], item)
        for row in result['records']:
            for item in row['raw']:
                add(item['path'], item)
        cohorts.append(dict(name=name, calls=len(result['records']), status=result['status'],
                            complete_values=result['complete_values']))
    add(OUT / 'performance-frozen-helpers-429/manifest.json')
    for row in snapshots['members']:
        add(row['snapshot'], row)

    for stem in ('performance-gap-diagnostic-428', 'performance-gap-diagnostic-428b',
                 'performance-full43-429', 'benchmark-host-final-tests-429',
                 'benchmark-host-regression-429', 'benchmark-ci-clickbench-430',
                 'benchmark-ci-host-430', 'benchmark-host-native-smoke-430'):
        receipt = read(OUT / f'{stem}.json')
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        if stem.startswith('benchmark-'):
            assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        add(OUT / f'{stem}.json')
        add(OUT / f'{stem}.log', dict(sha256=receipt['log_sha256']))
    for name in ('performance-gap-observations-428.json', 'performance-gap-primary-428.json',
                 'performance-probe-observations-429.json', 'performance-probe-primary-429.json',
                 'performance-full43-interruption-429.json', 'performance-interruption-primary-430.json',
                 'performance-power-history-428.json', 'performance-power-history-428.log',
                 'benchmark-host-regression-proof-429.json', 'benchmark-host-source-430.json',
                 'benchmark-ci-matrix-430.json', 'verify_performance_interruption_430.py',
                 'prove_benchmark_host_regression_429.py', 'composition-timing-primary-419.json'):
        add(OUT / name)
    for path in sorted((OUT / 'host-counter-self-checks-428').iterdir()):
        assert path.is_file()
        add(path)
    add(Path(__file__))

    smoke = read(SMOKE / 'summary.json')
    assert smoke['complete_result_validation'] and smoke['completed_identity_check']
    assert len(smoke['records']) == 6 and all(r['passed'] for r in smoke['records'])
    assert smoke['host_conditions']['status'] == 'admitted'
    assert len(smoke['host_conditions']['observations']) >= 13
    add(SMOKE / 'summary.json')
    verified_smoke_members = 0
    for archive in smoke['archives']:
        add(archive['path'], archive)
        with tarfile.open(archive['path'], 'r:xz') as bundle:
            members = bundle.getmembers()
            assert {m.name for m in members} == {m['name'] for m in archive['members']}
            for expected in archive['members']:
                member = bundle.getmember(expected['name'])
                assert member.isfile()
                raw = bundle.extractfile(member).read()
                assert len(raw) == expected['bytes'] and digest(raw) == expected['sha256']
                verified_smoke_members += 1
    assert verified_smoke_members == 24
    for path, sha in smoke['harness_sha256'].items():
        add(path, dict(sha256=sha))
    for path in read(OUT / 'benchmark-host-source-430.json')['changed_source_paths']:
        add(ROOT / path)
    for path in ('.github/workflows/ci.yml', 'docs/benchmarks/native-performance-gap-2026-10-14.md',
                 'docs/architecture/phased-execution-plan.md',
                 'docs/architecture/native-admitted-context-2026-10-14.md',
                 'docs/architecture/local-development-storage.md'):
        add(ROOT / path)
    frozen = read(OUT / 'context-paired-frozen-426.json')
    for name in ('reference', 'queries'):
        add(frozen[name]['path'], frozen[name])

    # Preserve actual execution evidence rather than equating labels with adaptation.
    technique_rows = []
    probe = read(UAT / 'logs/performance-diagnostic-428b/result.json')
    for record in probe['records']:
        if record['role'] != 'candidate':
            continue
        source = next(item for item in record['raw'] if item['path'].endswith('.stdout.json'))
        fields = report_fields(read(source['path']))
        selected = {k: v for k, v in fields.items() if any(term in k for term in
                    ('strategy', 'capillary', 'pulseweave', 'late_measure_second_pass'))}
        technique_rows.append(dict(query=record['query'], run=record['run'], order=record['order'],
                                   source=source, fields=selected))
    technique_path = OUT / 'performance-native-techniques-430.json'
    save(technique_path, dict(scope='Observed native report fields; labels do not prove scheduler adaptation',
                             samples=technique_rows))
    add(technique_path)
    total_bytes = sum(len(data) for data in payloads.values())
    assert total_bytes < 96 * MIB
    manifest = dict(schema='shardloom.performance_gap_observations.v1', status='investigation_open',
                    complete_suite_confirmation=False, native_engine_changed=False,
                    scope='diagnostic evidence and benchmark-host guard verification; no release or performance acceptance',
                    cohorts=cohorts, harness_smoke_calls=6, harness_smoke_raw_members=24,
                    members=sorted(entries.values(), key=lambda x: (x['original'], x['sha256'])),
                    unique_payloads=len(payloads), uncompressed_bytes=total_bytes,
                    storage_preflight=storage,
                    omitted='large binaries and input dataset; identities and source manifests are retained')
    manifest_bytes = (json.dumps(manifest, indent=2, allow_nan=False) + '\n').encode()
    archive_path = OUT / f'{NAME}.tar.xz'
    with tarfile.open(archive_path, 'x:xz', preset=3) as bundle:
        for name, data in sorted(payloads.items()):
            item = tarfile.TarInfo(name)
            item.size, item.mode, item.mtime = len(data), 0o644, 0
            bundle.addfile(item, io.BytesIO(data))
        item = tarfile.TarInfo('manifest.json')
        item.size, item.mode, item.mtime = len(manifest_bytes), 0o644, 0
        bundle.addfile(item, io.BytesIO(manifest_bytes))
    with tarfile.open(archive_path, 'r:xz') as bundle:
        assert len(bundle.getmembers()) == len(payloads) + 1
        assert {m.name for m in bundle} == set(payloads) | {'manifest.json'}
        for item in bundle:
            assert item.isfile()
            expected = manifest_bytes if item.name == 'manifest.json' else payloads[item.name]
            assert bundle.extractfile(item).read() == expected
    manifest_path = OUT / f'{NAME}.json.xz'
    with manifest_path.open('xb') as stream:
        stream.write(lzma.compress(manifest_bytes, preset=3))
    assert lzma.decompress(manifest_path.read_bytes()) == manifest_bytes
    verification = dict(status='passed', scope='archive byte readback only; performance investigation remains open',
                        archive=identity(archive_path), manifest=identity(manifest_path),
                        bound_paths=len(entries), unique_payloads=len(payloads),
                        archive_members=len(payloads) + 1, diagnostic_calls=177,
                        harness_smoke_calls=6, verified_nested_smoke_members=24,
                        complete_suite_confirmation=False)
    save(OUT / f'{NAME}.verification.json', verification)
    print(json.dumps(verification), flush=True)


if __name__ == '__main__':
    main()
