# SPDX-License-Identifier: Apache-2.0
"""Observe Mac benchmark power/thermal conditions without changing host policy.

The charge floor is a conservative benchmark policy, not an Apple throttling
threshold. Reported nominal thermal state does not prove fixed CPU frequency or
an idle host. Other platforms are explicitly recorded as unmonitored.
"""
from __future__ import annotations

import ctypes
import datetime as dt
from functools import lru_cache
import os
import re
import subprocess
import sys
import threading
import time


MIN_BATTERY_PERCENT = 35
SAMPLE_INTERVAL_SECONDS = 2.0


class BenchmarkHostError(ValueError):
    """The benchmark cannot admit the observed host conditions."""


def parse_macos_power(text: str) -> dict:
    sources = re.findall(r"^Now drawing from '([^']+)'\s*$", text, re.MULTILINE)
    if len(sources) != 1 or sources[0] not in ("AC Power", "Battery Power"):
        raise BenchmarkHostError("benchmark host power source is missing or unsupported")
    source = sources[0]
    battery_lines = [line for line in text.splitlines() if "InternalBattery" in line]
    if len(battery_lines) > 1:
        raise BenchmarkHostError("benchmark host battery observation is ambiguous")
    percent = None
    if battery_lines:
        charge = re.search(r"(?:^|\s)([+-]?\d+)%;", battery_lines[0])
        if charge is None or not 0 <= int(charge[1]) <= 100:
            raise BenchmarkHostError("benchmark host battery charge is missing or invalid")
        percent = int(charge[1])
    if source == "Battery Power" and percent is None:
        raise BenchmarkHostError("benchmark host battery charge is unavailable on battery power")
    return {"power_source": source, "battery_percent": percent}


class _DarwinProcessInfo:
    """Call documented Foundation getters; no SDK, subprocess compiler or probe writes."""

    def __init__(self):
        self.foundation = ctypes.CDLL("/System/Library/Frameworks/Foundation.framework/Foundation")
        self.objc = ctypes.CDLL("/usr/lib/libobjc.A.dylib")
        self.objc.objc_getClass.argtypes = [ctypes.c_char_p]
        self.objc.objc_getClass.restype = ctypes.c_void_p
        self.objc.sel_registerName.argtypes = [ctypes.c_char_p]
        self.objc.sel_registerName.restype = ctypes.c_void_p
        pointer = ctypes.CFUNCTYPE(ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p)(
            ("objc_msgSend", self.objc))
        self.integer = ctypes.CFUNCTYPE(ctypes.c_long, ctypes.c_void_p, ctypes.c_void_p)(
            ("objc_msgSend", self.objc))
        self.boolean = ctypes.CFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)(
            ("objc_msgSend", self.objc))
        responds = ctypes.CFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p,
                                   ctypes.c_void_p)(("objc_msgSend", self.objc))
        process_class = self.objc.objc_getClass(b"NSProcessInfo")
        if not process_class:
            raise BenchmarkHostError("benchmark host Foundation process information is unavailable")
        self.info = pointer(process_class, self.objc.sel_registerName(b"processInfo"))
        self.thermal_selector = self.objc.sel_registerName(b"thermalState")
        self.low_power_selector = self.objc.sel_registerName(b"isLowPowerModeEnabled")
        responds_selector = self.objc.sel_registerName(b"respondsToSelector:")
        if not self.info or not all(responds(self.info, responds_selector, selector)
                                    for selector in (self.thermal_selector, self.low_power_selector)):
            raise BenchmarkHostError("benchmark host power/thermal getters are unavailable")

    def read(self) -> dict:
        state = self.integer(self.info, self.thermal_selector)
        if state not in range(4):
            raise BenchmarkHostError("benchmark host thermal state is invalid")
        return {"thermal_state": state,
                "thermal_label": ("nominal", "fair", "serious", "critical")[state],
                "low_power_mode": self.boolean(self.info, self.low_power_selector)}


@lru_cache(maxsize=1)
def _darwin_process_info():
    return _DarwinProcessInfo()


def snapshot(*, platform=None) -> dict:
    platform = sys.platform if platform is None else platform
    observation = {"utc": dt.datetime.now(dt.timezone.utc).isoformat(), "platform": platform,
                   "load_average": os.getloadavg() if hasattr(os, "getloadavg") else None}
    if platform != "darwin":
        return dict(observation, monitoring="not_monitored_on_this_platform")
    power = subprocess.run(["/usr/bin/pmset", "-g", "batt"], capture_output=True,
                           text=True, timeout=5, env=dict(os.environ, LC_ALL="C"))
    if power.returncode != 0:
        raise BenchmarkHostError(f"benchmark host power observation failed (exit {power.returncode})")
    if len(power.stdout) > 16_384:
        raise BenchmarkHostError("benchmark host power observation exceeded 16 KiB")
    return dict(observation, monitoring="macos_power_and_thermal",
                power_raw=power.stdout, **parse_macos_power(power.stdout),
                **_darwin_process_info().read())


class BenchmarkHostGuard:
    """Latch the first rejection and retain all observations for the run receipt.

    Call with force=True before and after each native call, and normally from
    the existing process watchdog. Summary/storage writes must not use this
    guard: failed host admission still needs to preserve its receipt.
    """

    def __init__(self, *, observer=None, clock=None):
        self._observer = snapshot if observer is None else observer
        self._clock = time.monotonic if clock is None else clock
        self._last_sample = None
        self._last_observation = None
        self._lock = threading.Lock()
        self.report = {
            "schema_version": "shardloom.benchmark.host_conditions.v1",
            "status": "not_checked",
            "policy": {
                "minimum_battery_percent": MIN_BATTERY_PERCENT,
                "sample_interval_seconds": SAMPLE_INTERVAL_SECONDS,
                "require_reported_nominal_thermal_state": True,
                "require_low_power_mode_disabled": True,
                "require_unchanged_power_source": True,
            },
            "scope": "Mac power and thermal admission; other platforms unmonitored; sampled conditions do not prove fixed CPU frequency, exclusive CPU use or cold cache",
            "initial_power_source": None,
            "observations": [],
            "failure": None,
        }

    def check(self, *, force=False) -> dict:
        with self._lock:
            if self.report["failure"] is not None:
                raise BenchmarkHostError(self.report["failure"])
            now = self._clock()
            if (not force and self._last_sample is not None
                    and now - self._last_sample < SAMPLE_INTERVAL_SECONDS):
                return self._last_observation
            try:
                observation = self._observer()
            except (OSError, ValueError, subprocess.SubprocessError) as error:
                observation = {"utc": dt.datetime.now(dt.timezone.utc).isoformat(),
                               "monitoring": "observation_failed", "error": str(error)}
            self._last_sample = now
            self._last_observation = observation
            self.report["observations"].append(observation)
            try:
                self._admit(observation)
            except BenchmarkHostError as error:
                self.report.update(status="rejected", failure=str(error),
                                   failure_observation_index=len(self.report["observations"]) - 1)
                raise
            return observation

    def _admit(self, observation):
        if not isinstance(observation, dict):
            raise BenchmarkHostError("benchmark host power/thermal observation is invalid")
        monitoring = observation.get("monitoring")
        if (monitoring == "not_monitored_on_this_platform"
                and observation.get("platform") not in (None, "darwin")):
            self.report["status"] = "unmonitored"
            return
        if monitoring != "macos_power_and_thermal" or observation.get("platform") != "darwin":
            raise BenchmarkHostError("benchmark host power/thermal observation is unavailable")
        source = observation.get("power_source")
        if source not in ("AC Power", "Battery Power"):
            raise BenchmarkHostError("benchmark host power source is missing or unsupported")
        charge = observation.get("battery_percent")
        if charge is not None and (type(charge) is not int or not 0 <= charge <= 100):
            raise BenchmarkHostError("benchmark host battery charge is invalid")
        if charge is None and source == "Battery Power":
            raise BenchmarkHostError("benchmark host battery charge is unavailable on battery power")
        if charge is not None and charge < MIN_BATTERY_PERCENT:
            raise BenchmarkHostError(f"benchmark host charge below {MIN_BATTERY_PERCENT} percent; recharge before timing")
        if type(observation.get("thermal_state")) is not int or observation["thermal_state"] != 0:
            raise BenchmarkHostError("benchmark host thermal state is not reported nominal; cool the host before timing")
        if observation.get("low_power_mode") is not False:
            raise BenchmarkHostError("benchmark host Low Power Mode is enabled or unavailable")
        initial_source = self.report["initial_power_source"]
        if initial_source is not None and source != initial_source:
            raise BenchmarkHostError("benchmark host power source changed during the cohort")
        self.report["initial_power_source"] = source
        self.report["status"] = "admitted"
