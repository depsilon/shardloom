"""Run four new host-admission regressions against the original runner bodies."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
sys.path.insert(0, str(ROOT / 'scripts'))
import test_clickbench_query_uat as single_tests
import test_clickbench_paired_query_uat as paired_tests

manifest = json.loads((OUT / 'performance-frozen-helpers-429/manifest.json').read_text())
old = {}
bindings = []
for key, name in [('single', 'run_clickbench_query_uat.py'), ('paired', 'run_clickbench_paired_query_uat.py')]:
    member = next(m for m in manifest['members'] if Path(m['original']).name == name)
    source = Path(member['snapshot'])
    assert hashlib.sha256(source.read_bytes()).hexdigest() == member['sha256']
    spec = importlib.util.spec_from_file_location('prior_' + key, source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # Preserve normal helper discovery for the mocked runner; execute old bodies.
    module.__file__ = str(ROOT / 'scripts' / name)
    old[key] = module
    bindings.append(member)

names = [
    (single_tests.ClickBenchUatTests, 'test_thermal_change_after_a_correct_result_rejects_the_single_run'),
    (single_tests.ClickBenchUatTests, 'test_low_charge_preflight_preserves_receipt_and_releases_lock'),
    (paired_tests.PairedQueryUatTests, 'test_paired_runner_rejects_a_power_change_after_a_correct_result'),
    (paired_tests.PairedQueryUatTests, 'test_paired_preflight_retains_failure_without_starting_a_query'),
]
suite = unittest.TestSuite(test(name) for test, name in names)
result = unittest.TestResult()
with patch.object(single_tests, 'query_uat', old['single']), patch.object(paired_tests, 'paired_uat', old['paired']):
    suite.run(result)
assert result.testsRun == 4 and len(result.failures) == 4 and not result.errors
report = dict(status='passed', scope='Four negative regressions reject the original runner behavior; native query execution is mocked.',
    tests=result.testsRun, expected_regression_failures=len(result.failures), errors=len(result.errors),
    old_source=bindings, failures=[dict(test=str(test), traceback=trace) for test, trace in result.failures],
    current_sources=[dict(path=str(p), sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in
        (ROOT / 'scripts' / name for name in ('benchmark_host_guard.py', 'run_clickbench_query_uat.py',
            'run_clickbench_paired_query_uat.py', 'test_clickbench_query_uat.py', 'test_clickbench_paired_query_uat.py'))])
with (OUT / 'benchmark-host-regression-proof-429.json').open('x') as handle:
    json.dump(report, handle, indent=2)
    handle.write('\n')
print(json.dumps(dict(status='passed', old_behavior_failures=4, errors=0)))
