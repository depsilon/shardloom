"""Complete paired confirmation against the executable from the 177-second run."""
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
UAT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
RUN = UAT / 'logs/performance-full43-429'
HEAD = '9dd328f5cbdae08fa396910e7c6ce747ff16dda1'
sys.path[:0] = [str(ROOT / 'scripts'), str(OUT)]
from clickbench_reference_packet import load_reference_packet
from freeze_native_release_298 import sources
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
from native_workflow_protocol import extract_result, public_workflow_command, report_fields
from native_host_counters_428 import host
from run_clickbench_paired_query_uat import generation, role_order
from run_clickbench_query_uat import equivalent, run_profiled_command


def read(path):
    return json.loads(Path(path).read_text())


def bound(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1 << 20), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def verify(item):
    assert bound(item['path']) == {k: item[k] for k in ('path', 'bytes', 'sha256')}


def save(path, value):
    with Path(path).open('x') as handle:
        json.dump(value, handle, indent=2, allow_nan=False)
        handle.write('\n')


def query_metrics(records, order, query):
    selected = [r for r in records if r['order'] == order and r['query'] == query]
    observed = {}
    for role in ('control', 'candidate'):
        rows = [r for r in selected if r['role'] == role]
        assert len(rows) == 3 and {r['run'] for r in rows} == {1, 2, 3}
        observed[role] = dict(elapsed=statistics.median(r['timing']['seconds'] for r in rows),
            cpu=statistics.median(r['timing']['user_cpu_seconds'] + r['timing']['system_cpu_seconds'] for r in rows),
            rss=statistics.median(r['timing']['peak_rss_bytes'] for r in rows))
    limits = dict(elapsed=(0.1, 0.005), cpu=(0.1, 0.005), rss=(0.25, 256 * MIB))
    breaches = {k: observed['candidate'][k] - observed['control'][k] > max(relative * observed['control'][k], absolute)
        for k, (relative, absolute) in limits.items()}
    return dict(query=query, order=order, medians=observed, breaches=breaches)


def main():
    started = time.monotonic()
    assert not RUN.exists()
    require_local_path(UAT, Path.home(), sys.platform)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD
    frozen = read(OUT / 'context-paired-frozen-426.json')
    old = read(OUT / 'composition-attribution-frozen-419.json')
    current_sources = sources()
    assert current_sources == frozen['active_workspace_sources']
    assert read(OUT / 'context-prepush-source-427.json')['head'] == HEAD
    assert read(UAT / 'logs/performance-diagnostic-428b/result.json')['status'] == 'passed'
    binaries = dict(control=old['binaries']['control'], candidate=frozen['binaries']['candidate'])
    for item in binaries.values():
        verify(item)
    input_path = Path(frozen['source']['path'])
    require_local_path(input_path, Path.home(), sys.platform)
    original_generation = generation(input_path)
    assert original_generation == frozen['source_generation']
    assert input_path.stat().st_flags == 0
    assert input_path.stat().st_blocks * 512 >= input_path.stat().st_size
    reference = load_reference_packet(Path(frozen['reference']['path']), Path(frozen['queries']['path']))
    verify(frozen['reference'])
    verify(frozen['queries'])
    expected_power = None
    last_host_sample = 0.0
    observations = []

    def check_host(item):
        if item['power_source'] != expected_power:
            raise ValueError('power source changed during the confirmation')
        if item['battery_percent'] < 35:
            raise ValueError('battery charge fell below the declared 35 percent floor')
        if item['thermal_state'] != 0 or item['low_power_mode']:
            raise ValueError('thermal pressure or low-power mode invalidates the confirmation')

    def guard(reserve=0):
        nonlocal last_host_sample
        if generation(input_path) != original_generation:
            raise ValueError('source generation changed')
        now = time.monotonic()
        if expected_power is not None and now - last_host_sample >= 2:
            observation = host()
            observations.append(observation)
            last_host_sample = now
            check_host(observation)
        return check_budgets(UAT, input_path, RUN, min_free_bytes=12 * GIB,
            reserve_bytes=reserve, max_workspace_bytes=100 * GIB,
            max_log_bytes=1024 * MIB, max_run_log_bytes=256 * MIB,
            reserve_log_bytes=reserve)

    initial_storage = guard(64 * MIB)
    lock = UAT / '.ingest-uat.lock'
    lock.mkdir()
    result = dict(status='running', records=[], complete_values=False, host_observations=observations)
    try:
        RUN.mkdir()
        verify(frozen['source'])
        assert generation(input_path) == original_generation
        first_host = host()
        expected_power = first_host['power_source']
        check_host(first_host)
        observations.append(first_host)
        helpers = [Path(__file__), OUT / 'native_host_counters_428.py', OUT / 'run_guarded.py',
            OUT / 'freeze_native_release_298.py', OUT / 'context-prepush-source-427.json',
            OUT / 'context-paired-frozen-426.json', OUT / 'composition-attribution-frozen-419.json',
            UAT / 'logs/performance-diagnostic-428b/result.json']
        helpers += [ROOT / 'scripts' / name for name in ('run_clickbench_query_uat.py',
            'run_clickbench_paired_query_uat.py', 'native_workflow_protocol.py',
            'timed_native_command.py', 'clickbench_reference_packet.py', 'local_uat_storage.py')]
        helpers += sorted((ROOT / 'python/src/shardloom').rglob('*.py'))
        protocol = dict(schema='shardloom.performance_gap_full43_confirmation.v1', head=HEAD,
            binaries=binaries, source=frozen['source'], source_generation=original_generation,
            queries=frozen['queries'], reference=frozen['reference'], query_ids=list(range(1, 44)),
            memory_gib=24, max_parallelism=12, complete_forward_calls=258,
            ordering='three alternating pairs per query in query order; reverse starting order for every query with any declared forward breach',
            recheck_selection='union of elapsed, CPU and RSS median breaches; decided by frozen thresholds, not manually selected',
            thresholds=dict(elapsed=dict(relative=0.1, absolute_seconds=0.005),
                cpu=dict(relative=0.1, absolute_seconds=0.005), rss=dict(relative=0.25, absolute_bytes=256 * MIB)),
            decision='Any same query and metric exceeding both order thresholds requires further diagnosis. Preserve every sample and single-order breach. Report full forward 129-call sums for both roles separately from conditional rechecks.',
            historical_totals_seconds=[177.372562, 214.675706, 211.784749],
            historical_comparison='Current retained old executable versus current candidate is paired; historical totals are separately observed cohorts, not paired causal estimates.',
            helpers=[bound(p) for p in helpers],
            source_map_sha256=hashlib.sha256(json.dumps(current_sources, sort_keys=True).encode()).hexdigest(),
            initial_host=first_host, expected_power_source=expected_power,
            host_admission='35 percent battery minimum, nominal thermal state, low-power mode off, same power source; before/after every call and sampled about every 2 seconds by the existing watchdog',
            storage=initial_storage, platform=frozen['platform'], logical_cpu_count=frozen['logical_cpu_count'],
            physical_memory_bytes=frozen['physical_memory_bytes'],
            timing_scope='unchanged repository timed_native_command.py: native process creation through full public output and exit; hashes, host observations, validation and summary writes excluded',
            timing_observer='same power sampler runs for both roles; it is not a quiet-host or cold-cache guarantee',
            cache='same prehashed resident Vortex file, shared uncontrolled OS cache, no purge',
            reference_scope='retained native full-value regression evidence; no fresh independent oracle',
            publication=False, engine_changes=False, superiority_claim=False)
        save(RUN / 'protocol.json', protocol)
        result['protocol'] = bound(RUN / 'protocol.json')
        expected_routes = read(OUT / 'composition-timing-primary-419.json')['cohorts']['pre_composition']['per_query']
        schemas = {}

        def cohort(order, query_ids):
            for query in query_ids:
                for run in range(1, 4):
                    for position, role in enumerate(role_order(query, run, order == 'reverse'), 1):
                        before = host()
                        check_host(before)
                        prefix = RUN / f'{order}-q{query:02d}-run{run}-{role}'
                        command = public_workflow_command(binaries[role]['path'],
                            reference['queries'][query - 1], input_path=input_path,
                            input_format='vortex', memory_gb=24, max_parallelism=12)
                        outer = run_profiled_command(command, prefix, 120, guard)
                        after = host()
                        timing = read(prefix.with_suffix('.timing.json'))
                        record = dict(order=order, query=query, run=run, role=role,
                            position=position, command=command, host_before=before, host_after=after,
                            outer=outer, timing=timing, passed=False,
                            raw=[bound(prefix.with_suffix(suffix)) for suffix in
                                ('.stdout.json', '.stderr.txt', '.timing.json', '.pid')])
                        result['records'].append(record)
                        assert outer['returncode'] == 0 and not outer['guard_failures']
                        assert timing['returncode'] == 0
                        assert prefix.with_suffix('.stderr.txt').stat().st_size == 0
                        envelope = read(prefix.with_suffix('.stdout.json'))
                        fields = report_fields(envelope)
                        assert envelope['status'] == 'success'
                        assert equivalent(extract_result(envelope), reference['values'][query])
                        assert fields['public_workflow_route_id'] == expected_routes[str(query)]['route']
                        assert fields['fallback_attempted'] == fields['external_engine_invoked'] == 'false'
                        assert fields['execution_resource_declared_memory_bytes'] == str(24 << 30)
                        assert fields['execution_resource_declared_max_parallelism'] == '12'
                        assert any(c['kind'] == 'native_io_certificate' and c['status'] == 'available'
                                   for c in envelope['certificates'])
                        schema = (fields['result_schema_format'], json.loads(fields['result_schema_json']))
                        assert schemas.setdefault(query, schema) == schema
                        check_host(after)
                        record.update(passed=True, result_rows=len(extract_result(envelope)),
                            route=fields['public_workflow_route_id'])
                        print(json.dumps(dict(order=order, query=query, run=run, role=role,
                            seconds=timing['seconds'], cpu_seconds=timing['user_cpu_seconds'] + timing['system_cpu_seconds'],
                            battery=after['battery_percent'], passed=True)), flush=True)
                metrics = query_metrics(result['records'], order, query)
                print(json.dumps(dict(query_complete=metrics)), flush=True)

        cohort('forward', list(range(1, 44)))
        forward_metrics = [query_metrics(result['records'], 'forward', q) for q in range(1, 44)]
        selected = [r['query'] for r in forward_metrics if any(r['breaches'].values())]
        result['forward_metrics'] = forward_metrics
        result['reverse_selected_queries'] = selected
        save(RUN / 'forward-complete.json', result)
        cohort('reverse', selected)
        reverse_metrics = [query_metrics(result['records'], 'reverse', q) for q in selected]
        result['reverse_metrics'] = reverse_metrics
        repeated = [dict(query=r['query'], metrics=[k for k, v in r['breaches'].items()
            if v and forward_metrics[r['query'] - 1]['breaches'][k]]) for r in reverse_metrics]
        repeated = [r for r in repeated if r['metrics']]
        assert len(result['records']) == 258 + 6 * len(selected) and all(r['passed'] for r in result['records'])
        assert sources() == current_sources
        for item in protocol['helpers'] + list(binaries.values()):
            verify(item)
        guard()
        totals = {}
        for role in ('control', 'candidate'):
            rows = [r for r in result['records'] if r['order'] == 'forward' and r['role'] == role]
            totals[role] = dict(calls=len(rows), all_call_seconds=sum(r['timing']['seconds'] for r in rows),
                median_sum_seconds=sum(statistics.median(r['timing']['seconds'] for r in rows if r['query'] == q) for q in range(1, 44)),
                minima_sum_seconds=sum(min(r['timing']['seconds'] for r in rows if r['query'] == q) for q in range(1, 44)),
                cpu_seconds=sum(r['timing']['user_cpu_seconds'] + r['timing']['system_cpu_seconds'] for r in rows),
                max_rss_bytes=max(r['timing']['peak_rss_bytes'] for r in rows))
        result.update(status='needs_diagnosis' if repeated else 'passed', complete_values=True,
            source_unchanged=True, forward_totals=totals, repeated_metric_increases=repeated)
    except BaseException as error:
        result.update(status='failed', failure=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        result['driver_seconds'] = time.monotonic() - started
        if RUN.exists():
            save(RUN / 'result.json', result)
        lock.rmdir()
    print(json.dumps(dict(status=result['status'], calls=len(result['records']),
        totals=result['forward_totals'], repeated=result['repeated_metric_increases'], output=str(RUN))), flush=True)
    assert not result['repeated_metric_increases'], 'repeated costs require diagnosis'


if __name__ == '__main__':
    main()
