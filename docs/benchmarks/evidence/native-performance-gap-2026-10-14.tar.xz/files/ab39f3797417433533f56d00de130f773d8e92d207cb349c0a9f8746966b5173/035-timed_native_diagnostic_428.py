"""Keep the complete native clock; read exact Darwin counters after exit, before reap."""
import argparse
import datetime as dt
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

from native_host_counters_428 import await_exit_without_reaping, usage, thermal, provenance


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--timing', type=Path, required=True)
    parser.add_argument('--pid-file', type=Path, required=True)
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ['--'] else args.command
    assert command and not args.timing.exists() and not args.pid_file.exists()

    def interrupted(_signal, _frame):
        raise KeyboardInterrupt

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    before = thermal()
    record = dict(schema='shardloom.native_process_diagnostic.v1', command=command,
                  utc_started=dt.datetime.now(dt.timezone.utc).isoformat(),
                  thermal_before=before, counter_provenance=provenance())
    started = time.perf_counter()
    # The caller's run_command owns this whole process group and its timeout.
    child = subprocess.Popen(command)
    code, failure = 130, None
    try:
        args.pid_file.write_text(str(child.pid))
        await_exit_without_reaping(child.pid)
        record['seconds'] = time.perf_counter() - started
        record['darwin_rusage_v4'] = usage(child.pid)
        pid, wait_status, native = os.wait4(child.pid, 0)
        assert pid == child.pid
        code = os.waitstatus_to_exitcode(wait_status)
        child.returncode = code
        record.update(peak_rss_bytes=int(native.ru_maxrss), user_cpu_seconds=native.ru_utime,
            system_cpu_seconds=native.ru_stime, minor_page_faults=native.ru_minflt,
            major_page_faults=native.ru_majflt, input_block_operations=native.ru_inblock,
            output_block_operations=native.ru_oublock, voluntary_context_switches=native.ru_nvcsw,
            involuntary_context_switches=native.ru_nivcsw, direct_child_reaped=True)
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        if child.returncode is None:
            child.terminate()
            try:
                child.wait(timeout=1)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait()
        record.update(returncode=code, pid=child.pid, thermal_after=thermal(), failure=failure,
            cleanup_child_reaped=child.returncode is not None,
            timing_boundary='native process creation through complete output and exit; Darwin reads and reap follow clock stop',
            diagnostic_scope='complete operation with extra post-exit counters; not final benchmark acceptance')
        with args.timing.open('x') as stream:
            json.dump(record, stream, indent=2, allow_nan=False)
            stream.write('\n')
    return code if code >= 0 else 128 - code


if __name__ == '__main__':
    raise SystemExit(main())
