# Sampling population closeout surface inventory

Read-only inventory for a later closeout. It records current source wording and validator
expectations; it does not determine acceptance or authorize changing the claims.

## Sampling contract and unary boundary

- `docs/architecture/native-sampling-population-spill-2026-10-19.md:3-8` — literal status:
  “implementation contract; acceptance is pending.” It scopes the unit to PERF-06
  membership/recovery/strategy with PERF-03 and PERF-07/11/12 obligations; CG-1 through CG-23
  retain their gates.
- `docs/architecture/native-sampling-population-spill-2026-10-19.md:12-27` — admitted branches:
  unknown-bound fractional sampling without replacement (weighted or unweighted), plus fixed-count
  or fractional replacement (weighted or unweighted, known or unknown bound). Fixed-count and
  known-bound fractional nonreplacement stay bounded top-k; legacy `PreparedVortexUnary` and older
  local row-export sampler stay resident; source replay is a separate owner; preserve no-spill
  denial.
- `docs/architecture/native-sampling-population-spill-2026-10-19.md:84-91` — “The broad
  `unary_state_spill` all-family flag stays false”; scoped sampling capability changes only after
  complete finite acceptance with explicit operation/bound restrictions. Logical state count may
  include native files; sampling counters are separate from run/merge/disk counters.
- `docs/architecture/native-sampling-population-spill-2026-10-19.md:100-125` — acceptance requires
  original 8,193-wide-row pressure fixtures at the unchanged 16-MiB grant, resident denial and
  bounded fixed-count control, independent complete-value oracles, all admitted type/failure and
  output cases, focused and workspace checks, and source-bound public/Full43/format evidence.
  Explicit no-throughput claim at lines 95-98; broader strategy, subquery, recovery and competitive
  gates remain open at lines 121-125.
- `docs/architecture/native-stream-unary-2026-10-15.md:72-85` — earlier global unary contract says
  unknown fractional populations and replacement may retain population state under the shared
  grant and “expose deterministic denial”; lines 82-85 say unary membership/population remain
  resident and “no new spill algorithm is proposed.” This is the old blanket boundary to reconcile
  with the newer scoped contract.
- `docs/architecture/native-stream-unary-2026-10-15.md:112-125` — earlier acceptance controls
  explicitly include deterministic denial for unknown sample population state with and without
  replay spill (lines 112-117). Lines 122-127 state references/pressure owners “now pass local
  runtime acceptance”; that statement predates the sampling-population spill contract and needs
  scope-aware reading.
- `docs/architecture/native-unary-membership-spill-2026-10-18.md:43-52` — the prior membership
  contract separates Python/SQL relational unary from legacy `PreparedVortexUnary` and says broad
  `unary_state_spill` remains false while “sampling populations retain their separate false flag.”
  That seven-operation membership scope is distinct from the sampling family.
- `docs/architecture/native-unary-membership-spill-2026-10-18.md:108-116` — old finite unary
  acceptance included “sampling-population denial with permission” as a control while accepting
  seven other variants.

## Public reference and validation expectations

- `docs/reference/shardloom-user-surface-index.json:220-234` — current machine keys are
  `unary_state_spill: false`, `unary_state_spill_scope: "all_unary_state_families"`,
  `unary_membership_spill: true`, its reference/operation list and
  `unary_membership_spill_acceptance_status: "locally_accepted_hosted_pending"`; the sampling key
  is currently `unary_sampling_population_spill: false` at line 234. No sampling reference,
  operation list or acceptance-status key is adjacent.
- `scripts/check_user_surface_reference.py:22-24` — validator schema/path constants are
  `SCHEMA_VERSION = "shardloom.user_surface_index.v1"`, plus the markdown and JSON paths.
  `scripts/check_user_surface_reference.py:59-94` lists required JSON pointers; it has no required
  pointer for the sampling-spill flag. The flag is instead hard-coded by the streaming tuple.
- `scripts/check_user_surface_reference.py:285-314` — reads
  `payload["native_python_batch_adapters"]["streaming_input"]`; exact nearby constraints include
  `("unary_state_spill", False)`, scope `"all_unary_state_families"`, membership `True`, and
  `("unary_sampling_population_spill", False)` at line 314. A true scoped sampling claim would
  conflict with this current expectation.
- `scripts/check_user_surface_reference.py:349-353` — membership has an allowed acceptance status
  set (`local_acceptance_in_progress` or `locally_accepted_hosted_pending`) and a dedicated
  diagnostic. There is no corresponding sampling-status check nearby.
- `scripts/check_user_surface_reference.py:600-606` — separate pivot contract requires
  `direct_prepared_unary_spill`, `execution_resume`, `total_rss_bound`, `performance_claim`,
  `fallback_attempted`, and `external_engine_invoked` to remain false. The sampling contract also
  keeps legacy direct prepared-unary spill resident.
- `docs/reference/shardloom-user-surface-index.md:205-213` — generated human index currently links
  distinct-set and unary-membership spill contracts and their finite acceptances, then stream
  destinations; no sampling-population spill entry is listed.
- `docs/reference/native-query-spill.md:157-175` — documents set spill and seven relational unary
  membership operations. At lines 170-173 it says sampling populations, subquery membership/index
  and legacy standalone unary “remain under their resident contracts,” and broad
  `unary_state_spill` remains false. Lines 174-175 point to the older finite unary contract for
  sampling and other operations.
- `docs/reference/resident-native-results.md:88-100` — similarly says sampling populations,
  subquery index state and legacy `PreparedVortexUnary` retain resident contracts; links set and
  unary-membership scopes. Adjacent typed-value scope at `:251-259` says sampling is among retained
  unary/nested operations and “Typed sampling weights remain unsupported” at line 258; this is an
  adjacent wording boundary, separate from the spill flag.
- `python/tests/test_public_api_reference.py:48-54` — checks generated reference files are
  deterministic and current. Lines 56-73 compare the index’s `application.python_symbols` to lazy
  package `__all__` discovery. The file has no occurrence/assertion for
  `unary_sampling_population_spill` or sampling spill status; it is not the validator for that
  machine capability field.

## PERF-06 ledger and verification contract

- `docs/architecture/phased-execution-plan.md:261-273` — set and unary membership are finite
  acceptances; lines 265-267 still list sampling populations, subquery indexes and broader recovery
  as open. Lines 269-273 identify the sampling contract as the next finite unit, “Implementation
  and acceptance are in progress,” and say it is not yet advertised.
- `docs/architecture/phased-execution-plan.md:327-341` — parent `PERF-06` remains unchecked.
  Lines 335-339 keep membership/population transition, recovery and automatic strategy required;
  rematerialization and merge-cost investigations are conditional. Line 341 points at the common
  PERF-06 verification contract.
- `docs/architecture/phased-execution-completed-ledger.md:20-54` — completed unary membership
  block records seven accepted variants and 5,126 public cases; lines 49-54 explicitly retain
  sampling populations, subquery indexes, legacy standalone unary and broader recovery as open.
  `:84-89` in the following set block independently repeats that broader membership/population and
  recovery remain open.
- `docs/architecture/native-roadmap-verification-contracts-2026-10-18.md:83-107` — PERF-06
  command list includes the existing selector
  `streaming_unary_membership_spills_at_the_original_grant_while_samples_remain_resident` at line
  98, plus unary identity, typed-key, payload, generation, quota, failure and recovery selectors.
  The selector’s “samples remain resident” name is stale for the new scoped sampling behavior.
- `docs/architecture/native-roadmap-verification-contracts-2026-10-18.md:109-111` — verification
  contract requires exact completion beyond grant with quota/skew/corruption/cancellation/recovery
  and cleanup, but explicitly says sampling population and subquery indexes retain separate
  resident boundaries (line 109). It records prior set/unary public counts, full Full43 and 704
  native workflows; neither finite acceptance closes broader PERF-06. Closeout evidence should
  preserve that boundary rather than imply the parent gate is complete.
- `docs/architecture/native-cpu-investigations-2026-10-18.md:72-80` — CPU package E says extend
  PERF-06 using existing partitioning/runs rather than a parallel spill subsystem; preserve actual
  seeded/weighted/order algorithms for sampling and future-dependent operations (line 76), prove
  skew progress, exact completion under grant, cancellation/quota/failure/corrupt runs/cleanup, and
  preserve no-spill refusal.
- `docs/architecture/performance-overhaul-2026-09-04.md:317-323` — original PERF-06 baseline
  requires memory-accounted runs/merge, ownership, cleanup and crash/cancellation behavior, with
  exact completion, no hidden external engine and bounded temporary storage; it is broader than
  this finite sampling unit.
