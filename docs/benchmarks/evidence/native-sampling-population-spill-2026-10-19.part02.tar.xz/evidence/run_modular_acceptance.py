"""Sequential format/lifecycle/output acceptance of the shared public harness."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

REPO = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
build_group = parser.add_mutually_exclusive_group(required=True)
build_group.add_argument('--build')
build_group.add_argument('--build-manifest', type=Path)
parser.add_argument('--repo', type=Path, default=REPO)
parser.add_argument('--prefix', default='modular-native')
parser.add_argument('--metadata-test-repair', type=Path)
parser.add_argument('--attempt', required=True)
parser.add_argument('--probe', action='store_true')
args = parser.parse_args()
REPO = args.repo.resolve(strict=True)
assert args.prefix and args.prefix.replace('-', '').isalnum()
if args.build is not None:
    assert args.build.isascii() and args.build.isdecimal()
    build_path = OUT/f'build-{args.build}.json'
else:
    build_path = args.build_manifest.resolve(strict=True)
assert args.attempt.isascii() and args.attempt.isdecimal()
sys.path[:0] = [str(REPO), str(REPO / 'scripts'), str(REPO / 'benchmarks/traditional_analytics')]
from benchmark_models import FORMAT_ORDER
from check_benchmark_artifact_completeness import validate_manifest
from run_clickbench_query_uat import file_sha256, run_profiled_command
from local_uat_storage import GIB, MIB, check_budgets

build = json.loads(build_path.read_text())
binary = Path(build['binary'])
assert file_sha256(binary) == build['binary_sha256']
core_sources = {name: digest for name, digest in build['source_hashes'].items()
                if name.endswith('.rs') or Path(name).name in ('Cargo.toml', 'Cargo.lock')
                or name.startswith('python/src/')}
changed = {name: {'accepted_sha256': digest, 'current_sha256': file_sha256(REPO/name)}
           for name, digest in core_sources.items() if file_sha256(REPO/name) != digest}
if args.metadata_test_repair is not None:
    repair = json.loads(args.metadata_test_repair.read_text())
    assert set(changed) == {'shardloom-contract-tests/tests/release_readiness_metadata.rs'}
    assert changed == repair['changed_metadata_test_only']
else:
    assert not changed
current_sources = {name: file_sha256(REPO/name) for name in core_sources}
assert core_sources
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip() == build['working_tree']
kind = 'probe' if args.probe else 'matrix'
name = f'{args.prefix}-{kind}-{args.attempt}'
destination = OUT / f'{name}-report.json'
assert not destination.exists()
workspace = OUT / name
assert not workspace.exists()
report = {'status': 'running', 'runtime_commit': build['source_commit'], 'harness_commit': head,
          'binary': str(binary), 'binary_sha256': build['binary_sha256'],
          'build_manifest_sha256': file_sha256(build_path),
          'driver_sha256': file_sha256(Path(__file__)), 'performance_claim': False,
          'complete_cartesian_input_output_coverage_claimed': False,
          'unchanged_compiled_and_python_runtime_sources': {
              name: digest for name, digest in core_sources.items() if name not in changed},
          'changed_metadata_test_only': changed,
          'metadata_test_repair_sha256': (file_sha256(args.metadata_test_repair)
                                           if args.metadata_test_repair is not None else None),
          'scope': ('JSON/Vortex, raw/prepared, four representative complete workflows' if args.probe else
                    'Eight inputs with collect, eight outputs with CSV input, raw/prepared, all 22 workflows'),
          'cohorts': []}

def interrupted(_signum, _frame):
    raise KeyboardInterrupt

signal.signal(signal.SIGTERM, interrupted)
signal.signal(signal.SIGINT, interrupted)

def guard():
    check_budgets(OUT, OUT / 'reserved-modular-proof', OUT / 'logs',
                  min_free_bytes=12 * GIB, reserve_bytes=128 * MIB,
                  max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)

started = time.monotonic()
try:
    cohorts = [(state, 'collect', ['json', 'vortex'] if args.probe else list(FORMAT_ORDER))
               for state in ('raw', 'prepared')]
    if not args.probe:
        cohorts += [(state, output, ['csv']) for state in ('raw', 'prepared')
                    for output in ('vortex', 'json', 'jsonl', 'csv', 'parquet', 'arrow_ipc', 'avro', 'orc')]
    for index, (state, output, formats) in enumerate(cohorts, 1):
        prefix = OUT / f'{name}-cohort-{index:02d}'
        command = [sys.executable, '-B', str(REPO / 'benchmarks/traditional_analytics/run.py'),
                   '--shardloom-binary', str(binary), '--workspace', str(workspace),
                   '--rows', '1000', '--dim-rows', '20', '--formats', *formats,
                   '--input-state', state, '--output-format', output,
                   '--engines', 'shardloom', 'pandas', '--reference-engine', 'pandas',
                   '--repeats', '1', '--timeout', '60', '--memory-gb', '1', '--max-parallelism', '2']
        if args.probe:
            command.extend(['--scenarios', 'csv/file ingest', 'hash join',
                            'many-small-files scan', 'small change over large base'])
        receipt = run_profiled_command(command, prefix, 900, guard)
        stdout = prefix.with_suffix('.stdout.json')
        item = {'command': command, 'input_state': state, 'formats': formats, 'output_format': output,
                'receipt': receipt, 'stdout': str(stdout), 'stdout_sha256': file_sha256(stdout),
                'stderr_sha256': file_sha256(prefix.with_suffix('.stderr.txt'))}
        report['cohorts'].append(item)
        assert receipt['returncode'] == 0 and not receipt['guard_failures'], item
        result = json.loads(stdout.read_text().splitlines()[-1])
        assert result['status'] == 'passed', result
        path = Path(result['report'])
        blockers, observed = validate_manifest(path)
        assert not blockers, blockers
        item.update(report=str(path), report_sha256=file_sha256(path),
                    observed_records=len(observed['records']),
                    native_records=sum(row['engine'] == 'shardloom' for row in observed['records']),
                    independently_reopened=True)
        expected = len(formats) * (4 if args.probe else 22) * 2
        assert item['observed_records'] == expected and item['native_records'] == expected // 2
        print(json.dumps({'cohort': index, 'state': state, 'output': output,
                          'inputs': formats, 'records': expected, 'status': 'passed'}), flush=True)
    assert all(file_sha256(REPO / name) == digest for name, digest in current_sources.items())
    assert file_sha256(binary) == build['binary_sha256']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == head
    assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip() == build['working_tree']
    report['status'] = 'passed'
    report['records'] = sum(item['observed_records'] for item in report['cohorts'])
    report['native_records'] = sum(item['native_records'] for item in report['cohorts'])
    assert report['records'] == (32 if args.probe else 1408)
except BaseException as error:
    report.update(status='failed', error=f'{type(error).__name__}: {error}')
    raise
finally:
    report['actual_supervised_wall_seconds'] = time.monotonic() - started
    with destination.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': report['status'], 'report': str(destination)}), flush=True)
