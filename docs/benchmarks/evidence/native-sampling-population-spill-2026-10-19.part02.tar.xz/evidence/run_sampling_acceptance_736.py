"""Run the declared acceptance serially; stop at the first failed gate."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PYTHON = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
BINDING_PYTHON = '/Users/dylan/LocalData/shardloom/native-python-surface-20261010/release-v0.6.0/local-package-release060-source-440/venv/bin/python'


def run(name, command, timeout=1800):
    print(json.dumps({'starting': name}), flush=True)
    subprocess.run([PYTHON, '-B', str(OUT / 'run_guarded.py'), '--name', name,
                    '--timeout', str(timeout), '--', *command], cwd=ROOT, check=True)


def verify(phase, receipt=None):
    command = [PYTHON, '-B', str(OUT / 'verify_sampling_acceptance.py'), phase]
    if receipt:
        command.extend(['--receipt', receipt])
    run('sampling-' + phase + '-verify-736', command)


source = json.loads((OUT / 'acceptance-source.json').read_text())
cli = json.loads((OUT / 'sampling-cli-build-736.json').read_text())
assert cli['status'] == 'passed' and cli['head'] == source['source_commit']
assert cli['process_group_drained'] and cli['working_tree'] == ''
assert hashlib.sha256((OUT / 'sampling-cli-build-736.log').read_bytes()).hexdigest() == cli['log_sha256']
run('sampling-binding-build-736', [PYTHON, '-B', 'scripts/build_native_python.py',
    '--output-dir', str(OUT / 'artifacts'), '--release', '--offline'])
run('sampling-artifact-freeze-736', [PYTHON, '-B', str(OUT / 'freeze_sampling_acceptance.py'),
    'artifacts', '--cli-build', 'sampling-cli-build-736', '--binding-build', 'sampling-binding-build-736'])
run('sampling-plan-freeze-736', [PYTHON, '-B', str(OUT / 'freeze_sampling_acceptance.py'), 'plan'])
plan = json.loads((OUT / 'acceptance-plan.json').read_text())
build = json.loads((OUT / 'acceptance-build.json').read_text())
run('sampling-workspace-fmt-736', ['cargo', 'fmt', '--all', '--', '--check'])
run('sampling-public-reference-736', [PYTHON, '-B', 'scripts/check_user_surface_reference.py'])
run('sampling-population-reference-736', [PYTHON, '-B', 'scripts/generate_native_sampling_population_reference.py', '--check'])
run('sampling-public-reference-tests-736', [PYTHON, '-B', '-m', 'unittest', 'discover',
    '-s', 'python/tests', '-p', 'test_public_api_reference.py', '-v'])
binding_env = ['/usr/bin/env', 'SHARDLOOM_NATIVE_TEST_LIBRARY=' + build['native_library']['path'],
               'SHARDLOOM_REQUIRE_NATIVE_PYTHON=1', BINDING_PYTHON, '-m', 'unittest', 'discover',
               '-s', 'python/tests']
run('sampling-direct-binding-tests-736', [*binding_env, '-p', 'test_native*binding.py', '-v'])
run('sampling-public-context-tests-736', [*binding_env, '-p', 'test_public_context.py', '-v'])
run('sampling-public-preflight-736', [PYTHON, '-B', 'scripts/run_native_streaming_input_uat.py',
    '--binary', build['binary'], '--uat-root', str(OUT / 'public-preflight'),
    '--operation-timeout', '600', '--compress-logs', '--families', 'sampling-population', 'unary-pressure'])
preflight = json.loads((OUT / 'public-preflight/summary.json').read_text())
declaration = json.loads((OUT / 'sampling-public-case-declaration.json').read_text())
assert preflight['status'] == 'passed' and len(preflight['cases']) == 417
assert sorted(item['name'] for item in preflight['cases']) == sorted(
    declaration['sampling-population'] + declaration['unary-pressure'])
assert all(item['status'] == 'passed' for item in preflight['cases'])
run('sampling-native-clippy-736', ['cargo', 'clippy', '--release', '--offline', '--locked',
    '-p', 'shardloom-vortex', '-p', 'shardloom-cli', '--all-targets', '--features',
    'release-user-surfaces', '--', '-D', 'warnings'])
run('sampling-workspace-clippy-736', ['cargo', 'clippy', '--offline', '--locked',
    '--workspace', '--all-targets', '--', '-D', 'warnings'])
run('sampling-workspace-tests-736', ['cargo', 'test', '--offline', '--locked',
    '--workspace', '--all-targets', '--', '--test-threads=1'])
run('sampling-native-vortex-tests-736', ['cargo', 'test', '--release', '--offline', '--locked',
    '-p', 'shardloom-vortex', '--features', 'release-user-surfaces', '--lib', '--', '--test-threads=1'])
run('sampling-native-cli-tests-736', ['cargo', 'test', '--offline', '--locked',
    '-p', 'shardloom-cli', '--lib', '--bin', 'shardloom', '--test', 'vortex_prepare',
    '--test', 'public_memory_inputs', '--test', 'public_workflow_route', '--test',
    'resident_worker', '--features', 'release-user-surfaces', '--', '--test-threads=1'])
verify('input')
run('sampling-public-matrix-736', plan['commands']['public'], timeout=14400)
verify('public', 'sampling-public-matrix-736')
run('sampling-full43-736', plan['commands']['full43'], timeout=14400)
verify('full43', 'sampling-full43-736')
run('sampling-modular-736', plan['commands']['modular'], timeout=14400)
verify('modular', 'sampling-modular-736')
verify('final')
run('sampling-owner-acceptance-736', [PYTHON, '-B', str(OUT / 'finalize_sampling_acceptance.py')])
print(json.dumps({'status': 'passed', 'scope': 'finite_sampling_population'}), flush=True)
