# Sampling closeout: additional surface inventory

Delta against `sampling-closeout-surface-inventory-736.md`. Read-only search of frozen source
`f363f289` in `/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo`; no acceptance
decision is made here. No repository files were changed.

## Additional current wording to reconcile by scope

- `docs/architecture/native-unary-composition-2026-10-02.md:34-38` — says
  “Unsupported unary state spill is still an explicit resource denial” and that a surrounding
  relational sort’s spill permission “does not give unary state an unimplemented spill path.” The
  new contract admits a specific shared-relational sampling population path under explicit native
  spill, so this generic statement needs to be qualified to other/unadmitted unary state. It does
  not imply legacy `PreparedVortexUnary` spill.
- `docs/architecture/native-unary-workflows-2026-10-01.md:58-64,108-120` — the older workflow
  contract says it does not “invent spill support for unary state” and names unary state spill as
  separate work (`:63-64`); its current scope paragraph says “unary state spill remain[s] separate
  work” (`:113-120`). These statements predate the sampled shared-relational exception and should
  be scoped to the older workflow/legacy and other unadmitted families if this doc remains a current
  contract. General nested/extension state remains outside the new sampling scope.

## Additional current script wiring and interpretation

- `scripts/native_streaming_unary_pressure_cases.py:123-129,191-230` — the existing combined
  pressure runner’s fixture now predeclares `"sampling_population_spill": True`; for each generated
  sample case it pairs an unspilled `denied(...)` control with a spill-enabled execution. The
  enabled branch asserts sampling-stage, population/output/draw/lookup, run, cleanup, quota, and
  no-replay counters (`:211-229`). Its `"sampling_population_spill": False` at `:206` describes
  the intentionally unspilled denial control, not the machine-index capability; retain that
  distinction when reconciling machine-readable fields. The replay entries’ `unary_state_spill:
  False` at `:144,309` are likewise per-case records for bounded-state or source-replay cases.
- `scripts/native_streaming_sampling_population_cases.py:62-137,140-160,180-290` — additional
  dedicated positive public runner, configured with 32 MiB memory and 128 MiB spill quota / 1 MiB
  buffer (`:20-21,62-68`). It uses the independent 54-case reference matrix, runs DataFrame and
  SQL through collect/batches (`:74-116`), then wide cases, writers/fanout, failure/recovery,
  early-close and replay controls (`:118-137,140-290`). It is evidence wiring, not by itself an
  acceptance result.
- `scripts/run_native_streaming_input_uat.py:45-60,63-82,244-252` — registers the dedicated
  `sampling-population` scenario separately from `unary-pressure`, imports both runners, and includes
  both source files plus the population reference generator/fixture in the source list. Preserve
  this separation in a closeout command/evidence map.

## Scope boundaries to keep; historical surfaces not proposed for edits

- `docs/reference/native-query-spill.md:407-410` — direct statement: “The direct prepared unary
  API remains resident.” This is the preserved legacy boundary; the new admitted surface is the
  shared relational route.
- `docs/architecture/phased-execution-completed-ledger.md:400-404` — the dated unary completion
  record says “Unary membership/population state remains resident under credits; replay spill does
  not spill that state.” Treat this as the original completion record, not a current general
  availability statement to rewrite. The newer scoped contract and active plan carry the current
  state.
- `docs/benchmarks/native-stream-unary-2026-10-15.md:12-17,123-130` — clearly dated historical
  report for PR #1559; it records unary spill outside that earlier finite unit and the old
  unknown-population denial controls. Keep as history, exclude from closeout edits.
- Search found no direct sampling-resident, `unary_state_spill`, or
  `unary_sampling_population_spill` assertion in `website-src`, `website-public`, or `website`
  (excluding generated dependencies/index assets). The matched `website/assets/data/compute-engine-flow-reference.md:408`
  only says general state spill remains open; that broader statement is still compatible with this
  finite scope.

## Search coverage

Searched `docs/reference`, `docs/architecture`, `scripts`, `website-src`, `website-public`, and
`website` for sampling/population with resident/spill, `unary_state_spill`,
`unary_sampling_population_spill`, `all_unary_state_families`, “all unary state,” and “samples
remain resident.” Reviewed all matching current source passages above and compared against the
previous inventory. Archived/evidence directories and the dated benchmark report were classified
as historical rather than proposed edits. No tests, builds, runtime commands, or network research
were run.
