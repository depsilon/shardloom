"""Freeze and accept the declared dynamic-subquery candidate without changing prior evidence."""
import ast
import json
import os
from pathlib import Path
import re
import sys
import unittest

from freeze_native_release_298 import ROOT, OUT, sha, save, sources
from run_query_timing_runtime_461 import guarded, PYTHON_DEPS
from run_stream_destination_review_checks_479 import CHECKS

SOURCE = OUT / 'native-release-source-streamdynamic518.json'
MANIFEST = OUT / 'native-release-artifacts-streamdynamic518.json'
DECLARATIONS = OUT / 'stream-dynamic-subquery-candidate-declarations-518'
PROTOCOL = OUT / 'stream-dynamic-subquery-acceptance-protocol-518.json'
PYTHON = OUT / 'selected-view-python-468/bin/python'
NEW_FAMILIES = ['dynamic-subqueries', 'dynamic-subqueries-reference',
                'dynamic-subqueries-composition', 'dynamic-subqueries-fault', 'dynamic-subqueries-pressure']


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def unchanged():
    frozen = json.loads(SOURCE.read_text())
    assert sources() == frozen['source_sha256'], 'accepted source changed'
    return frozen


def load():
    frozen = unchanged()
    manifest = json.loads(MANIFEST.read_text())
    assert manifest['status'] == 'passed' and manifest['source_sha256'] == frozen['source_sha256']
    for key in ('cli', 'binding'):
        assert identity(manifest[key]['path']) == {name: manifest[key][name] for name in ('path', 'bytes', 'sha256')}
    return manifest


class Declarations:
    def __init__(self, root):
        self.output, self.logs, self.names = root / 'outputs', root / 'logs', []
        self.output.mkdir()
        self.logs.mkdir()

    def case(self, name, _call):
        assert name not in self.names
        self.names.append(name)

    def json(self, path, value):
        save(path, value)


def declare():
    frozen = unchanged()
    sys.path[:0] = [str(ROOT / 'python/src'), str(ROOT / 'scripts')]
    from run_native_streaming_input_uat import FAMILIES
    from local_uat_storage import GIB, MIB, check_budgets, require_local_path
    require_local_path(DECLARATIONS, Path.home(), sys.platform)
    check_budgets(OUT, DECLARATIONS, OUT / 'logs', min_free_bytes=12 * GIB,
                  reserve_bytes=128 * MIB, max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    assert not DECLARATIONS.exists()
    DECLARATIONS.mkdir()
    families = []
    for name in NEW_FAMILIES:
        root = DECLARATIONS / name
        root.mkdir()
        harness = Declarations(root)
        FAMILIES[name](harness)
        families.append(dict(family=name, cases=len(harness.names), names=harness.names))
    declaration_path = DECLARATIONS / 'declarations.json'
    save(declaration_path, dict(status='declared_before_candidate_execution', native_engine_executions=0,
         source=identity(SOURCE), families=families, helper=identity(__file__)))
    prior_path = OUT / 'stream-subquery-public-509/summary.json'
    prior = json.loads(prior_path.read_text())
    assert prior['status'] == 'passed' and len(prior['cases']) == 3724 and len(prior['families']) == 31
    assert all(row['status'] == 'passed' for row in prior['cases'])
    old_names = [row['name'] for row in prior['cases']]
    added = [name for family in families for name in family['names']]
    names = old_names + added
    assert len(names) == len(set(names))
    old_direct_path = OUT / 'stream-subquery-direct-tests-509.json'
    old_direct = json.loads(old_direct_path.read_text())
    assert old_direct['status'] == 'passed' and old_direct['tests'] == 96
    test = ROOT / 'python/tests/test_native_dynamic_subquery_binding.py'
    methods = [node.name for node in ast.walk(ast.parse(test.read_text()))
               if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')]
    assert len(methods) == 4
    required = []
    files = sorted((ROOT / 'shardloom-vortex/src').glob('local_primitive_relational_batch_deferred*_tests.rs'))
    for path in files:
        required.extend(re.findall(r'fn\s+(streaming_dynamic_subqueries\w+)\(', path.read_text()))
    assert len(required) == len(set(required)) == 19, required
    required += [
        'relational_predicate_values_keep_explicit_bindings_in_scalar_positions',
        'native_relational_predicate_values_preserve_selected_case_and_coalesce_demand',
    ]
    old_protocol = OUT / 'stream-subquery-acceptance-protocol-509.json'
    old_required = json.loads(old_protocol.read_text())['native_required_tests']
    assert len(old_required) == 15
    baseline = OUT / 'stream-dynamic-inner-baseline-513/summary.json'
    baseline_primary = OUT / 'dynamic-subquery-baseline-primary-517.json'
    assert json.loads(baseline_primary.read_text())['status'] == 'passed'
    save(PROTOCOL, dict(status='predeclared', native_engine_executions=0,
        source=identity(SOURCE), declarations=identity(declaration_path), helper=identity(__file__),
        guard=identity(OUT / 'run_guarded.py'), original_public=identity(prior_path),
        original_direct=identity(old_direct_path), original_protocol=identity(old_protocol),
        expected_public_names=names, expected_public_families=prior['families'] + NEW_FAMILIES,
        new_public_names=added, new_families=families,
        expected_direct_tests=100, new_direct_methods=methods, direct_matrix_query_calls=288,
        native_required_tests=old_required + required, new_native_required_tests=required,
        required_checks=CHECKS, baseline=identity(baseline), baseline_primary=identity(baseline_primary),
        contract=identity(ROOT / 'docs/architecture/native-stream-dynamic-subqueries-2026-10-15.md'),
        initial_candidate_protocol=identity(OUT / 'stream-dynamic-subquery-acceptance-protocol-517.json'),
        initial_direct_counterevidence=identity(OUT / 'stream-dynamic-subquery-direct-new-tests-517.json'),
        initial_diagnosis=identity(OUT / 'dynamic-subquery-direct-diagnosis-517.json'),
        parser_before=identity(OUT / 'stream-dynamic-subquery-predicate-values-before-517.json'),
        parser_after=identity(OUT / 'stream-dynamic-subquery-predicate-values-after-518.json'),
        fixture_corrections=['unique compound columns n,s', 'one retained-output group per shared/kind pair'],
        no_vendor_changes=True, whole_process_memory_ceiling=False,
        performance_claim=False, full43_pending=True, installed_wheel_proof=False))
    assert unchanged() == frozen
    print(json.dumps(dict(status='predeclared', new_public_cases=len(added), public_cases=len(names),
                         direct_methods=100, native_required_tests=len(required) + len(old_required),
                         families=[(row['family'], row['cases']) for row in families])))


def tests(kind):
    manifest = load()
    assert Path(sys.executable) == PYTHON
    sys.path[:0] = [str(ROOT / 'python/src'), str(PYTHON_DEPS)]
    import pyarrow
    import shardloom
    assert Path(shardloom.__file__).resolve() == ROOT / 'python/src/shardloom/__init__.py'
    os.environ.update(SHARDLOOM_NATIVE_TEST_LIBRARY=manifest['binding']['path'],
                      SHARDLOOM_REQUIRE_NATIVE_PYTHON='1', SHARDLOOM_BIN=manifest['cli']['path'])
    new = kind == 'direct-new'
    suite = unittest.defaultTestLoader.discover(str(ROOT / 'python/tests'),
        pattern='test_native_dynamic_subquery_binding.py' if new else 'test_native*binding.py')

    def identifiers(value):
        return [name for child in value for name in identifiers(child)] if isinstance(value, unittest.TestSuite) else [value.id()]

    names = identifiers(suite)
    expected = 4 if new else 100
    assert len(names) == len(set(names)) == expected
    protocol = json.loads(PROTOCOL.read_text())
    new_names = {'test_native_dynamic_subquery_binding.NativeDynamicSubqueryBindingTests.' + name
                 for name in protocol['new_direct_methods']}
    assert new_names.issubset(names)
    if not new:
        old = json.loads(Path(protocol['original_direct']['path']).read_text())
        assert set(old['test_names']).issubset(names) and set(names) - set(old['test_names']) == new_names
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    passed = result.wasSuccessful() and result.testsRun == expected and not result.skipped
    save(OUT / f'stream-dynamic-subquery-{kind}-tests-518.json', dict(status='passed' if passed else 'failed',
        tests=result.testsRun, failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
        failure_details=[dict(test=str(test), traceback=detail) for test, detail in result.failures],
        error_details=[dict(test=str(test), traceback=detail) for test, detail in result.errors],
        test_names=names, artifact_manifest=identity(MANIFEST), source=identity(SOURCE),
        protocol=identity(PROTOCOL), helper=identity(__file__), interpreter=sys.executable,
        python_version=sys.version, pyarrow_version=pyarrow.__version__, pyarrow_file=pyarrow.__file__,
        package_source=shardloom.__file__, mode='direct_source_package_with_explicit_frozen_native_library',
        installed_wheel_proof=False))
    assert load() == manifest and passed


def public(kind):
    manifest = load()
    protocol = json.loads(PROTOCOL.read_text())
    root = OUT / f'stream-dynamic-subquery-{kind}-518'
    assert not root.exists()
    families = NEW_FAMILIES if kind == 'focused' else protocol['expected_public_families']
    guarded(f'stream-dynamic-subquery-{kind}-518', 7200,
        [sys.executable, '-B', ROOT / 'scripts/run_native_streaming_input_uat.py', '--binary', manifest['cli']['path'],
         '--uat-root', root, '--operation-timeout', '600', '--compress-logs', '--families', *families])
    summary = json.loads((root / 'summary.json').read_text())
    expected = protocol['new_public_names'] if kind == 'focused' else protocol['expected_public_names']
    assert summary['status'] == 'passed' and summary['families'] == families and summary['compress_logs']
    assert [row['name'] for row in summary['cases']] == expected
    assert all(row['status'] == 'passed' for row in summary['cases'])
    assert load() == manifest
    save(OUT / f'stream-dynamic-subquery-{kind}-acceptance-518.json', dict(status='passed', cases=len(expected),
        families=families, manifest=identity(MANIFEST), source=identity(SOURCE), protocol=identity(PROTOCOL),
        summary=identity(root / 'summary.json'), source_identity_preserved=True, full43_pending=True))


def checks():
    frozen = unchanged()
    protocol = json.loads(PROTOCOL.read_text())
    prior = json.loads((OUT / 'stream-subquery-checks-510.json').read_text())
    assert prior['status'] == 'passed' and prior['source_identity_preserved']
    ignored = next(row for row in prior['completed'] if row['stage'] == 'native-tests')['tests']['ignored_declarations']
    expected_ignored = sorted(tuple(row) for row in ignored)
    assert len(expected_ignored) == 29
    records, failure = [], None
    try:
        for label, timeout, command in CHECKS:
            assert unchanged() == frozen
            name = f'stream-dynamic-subquery-{label}-518'
            print(json.dumps(dict(stage=label, status='starting')), flush=True)
            guarded(name, timeout, command)
            path = OUT / (name + '.json')
            value, log = json.loads(path.read_text()), path.with_suffix('.log')
            assert value['status'] == 'passed' and value['returncode'] == 0
            assert value['process_group_drained'] and value['direct_child_reaped']
            assert not value['timed_out'] and not value['group_absence_unproved_at_cleanup']
            assert sha(log) == value['log_sha256'] and value['head'] == frozen['head']
            record = dict(stage=label, receipt=identity(path), log=identity(log))
            if label.endswith('tests'):
                raw = log.read_text()
                groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', raw)
                assert groups and all(int(row[1]) == int(row[3]) == int(row[4]) == 0 for row in groups)
                observed = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', raw, re.M)
                assert sum(int(row[2]) for row in groups) == len(observed)
                if label == 'native-tests':
                    assert sorted(observed) == expected_ignored
                    for name in protocol['native_required_tests']:
                        assert re.search(r'^test .*::' + name + r' \.\.\. ok$', raw, re.M), name
                else:
                    assert not observed
                record['tests'] = dict(passed=sum(int(row[0]) for row in groups), failed=0,
                                       ignored=len(observed), groups=len(groups), ignored_declarations=observed)
            records.append(record)
            print(json.dumps(dict(stage=label, status='passed', tests=record.get('tests', {}).get('passed'))), flush=True)
        assert unchanged() == frozen
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        save(OUT / 'stream-dynamic-subquery-checks-518.json', dict(status='passed' if failure is None else 'failed',
             failure=failure, completed=records, source=identity(SOURCE), protocol=identity(PROTOCOL),
             source_identity_preserved=sources() == frozen['source_sha256'], helper=identity(__file__)))


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'declare':
        declare()
    elif action.startswith('direct'):
        tests(action)
    elif action in ('focused', 'public'):
        public(action)
    else:
        assert action == 'checks'
        checks()

