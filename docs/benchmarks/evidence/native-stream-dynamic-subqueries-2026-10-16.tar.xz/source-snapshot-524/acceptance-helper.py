"""Verify the exact feature-only correction and run all six source checks."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import sys
import tomllib

from freeze_native_release_298 import ROOT, OUT, save, sources
from run_query_timing_runtime_461 import guarded
from run_stream_destination_review_checks_479 import CHECKS
from run_stream_dynamic_subquery_acceptance_521 import (
    SOURCE as EXECUTION_SOURCE, BUILD_SOURCE, MANIFEST, PROTOCOL, identity,
)

SOURCE = OUT / 'native-release-source-streamdynamic524.json'
TRANSITION = OUT / 'stream-dynamic-subquery-verification-corrections-524.json'
CHANGED = 'shardloom-vortex/src/relational_query.rs'
BEFORE = OUT / 'stream-dynamic-subquery-source-overlay-521/source' / CHANGED
AFTER = OUT / 'stream-dynamic-subquery-feature-gate-after-523.rs'
OLD = b'    pub(crate) sources: Option<std::sync::Arc<[DatasetUri]>>,\n'
NEW = b'    #[cfg(all(feature = "vortex-local-primitives", unix))]\n' + OLD
TEST_CHANGED = 'shardloom-cli/src/sql_scalar_expression.rs'
TEST_BEFORE = OUT / 'stream-dynamic-subquery-source-overlay-521/source' / TEST_CHANGED
TEST_AFTER = OUT / 'stream-dynamic-subquery-test-assertion-after-524.rs'
TEST_OLD = b'            assert!(parse(raw, "ordinary.value").unwrap().bindings.is_empty());'
TEST_NEW = b'\n'.join([
    b'            assert_eq!(', b'                parse(raw, "ordinary.value").unwrap().bindings,',
    b'                [] as [(ExprId, RelationalBinding); 0]', b'            );'])


def read(path):
    return json.loads(Path(path).read_text())


def unchanged():
    current, execution, built = read(SOURCE), read(EXECUTION_SOURCE), read(BUILD_SOURCE)
    assert sources() == current['source_sha256']
    assert current['head'] == execution['head'] == built['head']
    before_map, after_map = execution['source_sha256'], current['source_sha256']
    assert set(before_map) == set(after_map) and len(before_map) == 2303
    assert {name for name in before_map if before_map[name] != after_map[name]} == {CHANGED, TEST_CHANGED}
    before, after = BEFORE.read_bytes(), AFTER.read_bytes()
    assert before.count(OLD) == 1 and after == before.replace(OLD, NEW)
    assert hashlib.sha256(before).hexdigest() == before_map[CHANGED] == built['source_sha256'][CHANGED]
    assert hashlib.sha256(after).hexdigest() == after_map[CHANGED]
    assert (ROOT / CHANGED).read_bytes() == after
    test_before, test_after = TEST_BEFORE.read_bytes(), TEST_AFTER.read_bytes()
    assert test_before.count(TEST_OLD) == 1 and test_after == test_before.replace(TEST_OLD, TEST_NEW)
    assert test_before.index(TEST_OLD) > test_before.index(b'#[cfg(test)]\nmod tests {')
    assert hashlib.sha256(test_before).hexdigest() == before_map[TEST_CHANGED] == built['source_sha256'][TEST_CHANGED]
    assert hashlib.sha256(test_after).hexdigest() == after_map[TEST_CHANGED]
    assert (ROOT / TEST_CHANGED).read_bytes() == test_after
    assert {name for name in before_map if before_map[name] != built['source_sha256'][name]} == {
        'scripts/native_streaming_dynamic_subquery_cases.py',
        'scripts/native_streaming_dynamic_subquery_composition_cases.py',
        'python/src/shardloom/query.py', 'python/tests/test_scalar_subquery_declarations.py',
    }
    # The field's sole constructor is in the existing Unix native binder.
    declarations = (ROOT / 'shardloom-vortex/src/local_primitives.rs').read_text()
    assert ('#[cfg(all(feature = "vortex-local-primitives", unix))]\n'
            '#[path = "local_primitive_prepared_relational.rs"]\npub mod prepared_relational;') in declarations
    features = tomllib.loads((ROOT / 'shardloom-cli/Cargo.toml').read_text())['features']
    assert 'vortex-local-primitives' in features['release-user-surfaces']
    runtime_alias = tomllib.loads((ROOT / 'Cargo.toml').read_text())['workspace']['dependencies']['shardloom-runtime']
    assert runtime_alias['package'] == 'shardloom-cli' and runtime_alias['path'] == 'shardloom-cli'
    python_features = tomllib.loads((ROOT / 'shardloom-python/Cargo.toml').read_text())['features']
    assert 'shardloom-runtime/release-user-surfaces' in python_features['python-native']
    assert sys.platform == 'darwin'
    return current


def load():
    unchanged()
    artifacts, built = read(MANIFEST), read(BUILD_SOURCE)
    assert artifacts['status'] == 'passed' and artifacts['source_sha256'] == built['source_sha256']
    for key in ('cli', 'binding'):
        assert identity(artifacts[key]['path']) == {name: artifacts[key][name] for name in ('path', 'bytes', 'sha256')}
    return artifacts


def prepare():
    previous = read(EXECUTION_SOURCE)
    before, after = BEFORE.read_bytes(), (ROOT / CHANGED).read_bytes()
    assert after == before.replace(OLD, NEW) and before.count(OLD) == 1
    test_before, test_after = TEST_BEFORE.read_bytes(), (ROOT / TEST_CHANGED).read_bytes()
    assert test_after == test_before.replace(TEST_OLD, TEST_NEW) and test_before.count(TEST_OLD) == 1
    with TEST_AFTER.open('xb') as stream:
        stream.write(test_after)
    if AFTER.exists():
        assert AFTER.read_bytes() == after
    else:
        with AFTER.open('xb') as stream:
            stream.write(after)
    snapshot = dict(head=previous['head'], source_sha256=sources())
    if SOURCE.exists():
        assert read(SOURCE) == snapshot
    else:
        save(SOURCE, snapshot)
    unchanged()
    load()
    failed = OUT / 'stream-dynamic-subquery-workspace-clippy-521.json'
    assert read(failed)['status'] == 'failed' and read(failed)['returncode'] == 101
    assert 'field `sources` is never read' in failed.with_suffix('.log').read_text()
    failed_test = OUT / 'stream-dynamic-subquery-workspace-clippy-523.json'
    assert read(failed_test)['status'] == 'failed' and read(failed_test)['returncode'] == 101
    assert 'used `assert!` to check that a value is empty' in failed_test.with_suffix('.log').read_text()
    save(TRANSITION, dict(status='passed_exact_native_feature_and_test_corrections',
        before_source=identity(EXECUTION_SOURCE), after_source=identity(SOURCE),
        before=identity(BEFORE), after=identity(AFTER), changed_path=CHANGED,
        test_before=identity(TEST_BEFORE), test_after=identity(TEST_AFTER), test_changed_path=TEST_CHANGED,
        test_correction_outside_production_code=True,
        earlier_feature_transition=identity(OUT / 'stream-dynamic-subquery-feature-gate-correction-523.json'),
        retained_failed_test_gate=identity(failed_test), retained_failed_test_log=identity(failed_test.with_suffix('.log')),
        native_artifacts=identity(MANIFEST), compiled_source=identity(BUILD_SOURCE),
        retained_failed_gate=identity(failed), retained_failed_log=identity(failed.with_suffix('.log')),
        native_enabled_source_equivalence='Removing the added cfg attribute gives the exact accepted source; the field remains present for vortex-local-primitives on Unix.',
        public_and_direct_execution_reused=True, fresh_required_checks=CHECKS,
        helper=identity(__file__),
        preparation_correction=dict(original_helper=identity(OUT / 'run_stream_dynamic_subquery_checks_initial_523.py'),
            error='FileNotFoundError: shardloom-runtime/Cargo.toml; no checks launched',
            resolution='Resolve the workspace shardloom-runtime alias to package/path shardloom-cli; preserve and verify the already-created exact source snapshot.')))
    print(json.dumps(dict(status='prepared', source_files=2303, exact_changed_files=[CHANGED, TEST_CHANGED])))


def checks():
    frozen = unchanged()
    load()
    protocol = read(PROTOCOL)
    prior = read(OUT / 'stream-subquery-checks-510.json')
    expected_ignored = sorted(tuple(row) for row in next(
        row for row in prior['completed'] if row['stage'] == 'native-tests')['tests']['ignored_declarations'])
    assert len(expected_ignored) == 29
    records, failure = [], None
    try:
        for label, timeout, command in CHECKS:
            assert unchanged() == frozen
            name = f'stream-dynamic-subquery-{label}-524'
            print(json.dumps(dict(stage=label, status='starting')), flush=True)
            guarded(name, timeout, command)
            path = OUT / (name + '.json')
            value, log = read(path), path.with_suffix('.log')
            assert value['status'] == 'passed' and value['returncode'] == 0
            assert value['process_group_drained'] and value['direct_child_reaped']
            assert not value['timed_out'] and not value['group_absence_unproved_at_cleanup']
            assert identity(log)['sha256'] == value['log_sha256'] and value['head'] == frozen['head']
            record = dict(stage=label, receipt=identity(path), log=identity(log))
            if label.endswith('tests'):
                raw = log.read_text()
                groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', raw)
                assert groups and all(int(row[1]) == int(row[3]) == int(row[4]) == 0 for row in groups)
                observed = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', raw, re.M)
                assert sum(int(row[2]) for row in groups) == len(observed)
                if label == 'native-tests':
                    assert sorted(observed) == expected_ignored
                    for required in protocol['native_required_tests']:
                        assert re.search(r'^test .*::' + re.escape(required) + r' \.\.\. ok$', raw, re.M), required
                else:
                    assert not observed
                record['tests'] = dict(passed=sum(int(row[0]) for row in groups), failed=0,
                    ignored=len(observed), groups=len(groups), ignored_declarations=observed)
            records.append(record)
            print(json.dumps(dict(stage=label, status='passed', tests=record.get('tests', {}).get('passed'))), flush=True)
        assert unchanged() == frozen
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        save(OUT / 'stream-dynamic-subquery-checks-524.json', dict(status='passed' if failure is None else 'failed',
            failure=failure, completed=records, source=identity(SOURCE), execution_source=identity(EXECUTION_SOURCE),
            protocol=identity(PROTOCOL), source_transition=identity(TRANSITION),
            source_identity_preserved=sources() == frozen['source_sha256'], helper=identity(__file__)))


if __name__ == '__main__':
    {'prepare': prepare, 'checks': checks}[sys.argv[1]]()
