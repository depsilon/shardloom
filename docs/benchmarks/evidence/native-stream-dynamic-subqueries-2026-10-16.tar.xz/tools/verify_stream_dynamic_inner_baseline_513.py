"""Freeze dynamic-inner refusals and resident controls without changing the accepted PR."""
import json
from pathlib import Path
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sha, save, sources

sys.path.insert(0, str(ROOT / 'python/src'))
from run_native_streaming_input_uat import Harness
import shardloom as sl
from shardloom.errors import ShardLoomCommandError

HEAD = 'b6b585a45aadd144f6b90cc2053744544518897a'
DEST = OUT / 'stream-dynamic-inner-baseline-513'
SOURCE = OUT / 'stream-subquery-final-source-511.json'
ARTIFACTS = OUT / 'native-release-artifacts-streamsubquery509.json'
PROVENANCE = OUT / 'stream-subquery-hosted-512/pr-sources-513.json'
CONTRACT = ROOT / 'docs/architecture/native-stream-subqueries-2026-10-15.md'
SCHEMA = {'n': 'int64', 'metric': 'float64'}
LEFT = [{'n': n, 'metric': float(n * 10)} for n in range(1, 6)]
RIGHT = LEFT
KINDS = {
    'in': LEFT,
    'not-in': [],
    'exists': LEFT[1:],
    'not-exists': LEFT[:1],
    'any': LEFT[1:],
    'all': LEFT,
    'row-in': LEFT[:1],
    'empty-outer': [],
}
EXPECTED = {f'{kind}-shared-{shared}': rows for shared in (False, True)
            for kind, rows in KINDS.items()}


def declare(left, right, label):
    kind, shared = label.rsplit('-shared-', 1)
    if shared == 'True':
        right = left
    predicate = (sl.col('n') < sl.outer('n') if kind in ('exists', 'not-exists')
                 else sl.col('n') <= sl.outer('n'))
    inner = right.filter(predicate).select(
        'n AS entity',
        "CASE WHEN n <= 3 THEN 'a' ELSE 'b' END AS category",
        'metric AS amount',
    ).pivot_table(index='entity', columns='category', values='amount', aggfunc='sum')
    if kind == 'in':
        return left.filter(sl.col('n').isin_source(inner.agg(n='COUNT(*)'), 'n'))
    if kind == 'not-in':
        return left.filter(sl.col('n').not_in_source(inner.agg(n='COUNT(*)'), 'n'))
    if kind == 'exists':
        return left.filter(sl.exists_source(inner))
    if kind == 'not-exists':
        return left.filter(sl.not_exists_source(inner))
    if kind == 'any':
        return left.filter(sl.col('n').any_source('>', inner, 'entity'))
    if kind == 'all':
        return left.filter(sl.col('n').all_source('>=', inner, 'entity'))
    if kind == 'row-in':
        return left.filter(sl.row_in_source(['n', 'metric'],
            inner.agg(n='COUNT(*)', metric='SUM(pivot_a)'), ['n', 'metric']))
    assert kind == 'empty-outer'
    return left.limit(0).filter(sl.exists_source(inner))


def main():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD
    working_tree = subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True)
    assert all(line[3:] == 'AGENTS.md' or line[3:].startswith(('docs/', 'website-src/src/content/'))
               for line in working_tree.splitlines()), working_tree
    accepted = json.loads(SOURCE.read_text())['source_sha256']
    assert sources() == accepted
    artifacts = json.loads(ARTIFACTS.read_text())
    assert artifacts['status'] == 'passed'
    for key in ('cli', 'binding'):
        assert sha(artifacts[key]['path']) == artifacts[key]['sha256']
    provenance = json.loads(PROVENANCE.read_text())
    assert provenance['status'] == 'passed' and provenance['revisions']['pr_head'] == HEAD
    assert provenance['accepted']['sha256'] == sha(SOURCE)
    assert {name: row['sha256'] for name, row in provenance['immutable_source'].items()} == accepted
    assert not DEST.exists()
    harness = Harness(Path(artifacts['cli']['path']), DEST, 60)
    harness.guard()
    harness.logs.mkdir(parents=True)
    harness.output.mkdir()
    harness.json(harness.logs / 'predeclared-expectations.json', dict(
        rows_left=LEFT, rows_right=RIGHT, schema=SCHEMA, expected=EXPECTED,
        cases=32, streaming_refusals=16, resident_controls=16,
        head=HEAD, source_manifest_sha256=sha(SOURCE), artifacts_sha256=sha(ARTIFACTS),
        contract_sha256=sha(CONTRACT), provenance_sha256=sha(PROVENANCE),
        helper_sha256=sha(__file__), working_tree=working_tree,
        scope='Baseline admission and resident exact-value controls; no candidate execution or performance claim.'))
    status = 'failed'
    try:
        for streaming in (True, False):
            for kind, expected in EXPECTED.items():
                name = f'dynamic-inner-baseline-{kind}-streaming-{streaming}'
                def case(kind=kind, name=name, expected=expected, streaming=streaming):
                    events = []
                    def frame(label, rows):
                        def produce():
                            events.append([label, 'opened'])
                            try:
                                for batch in ([], rows[:1], rows[1:3], [], rows[3:]):
                                    yield batch
                                events.append([label, 'ended'])
                            finally:
                                events.append([label, 'closed'])
                        return harness.context.from_batches(produce, schema=SCHEMA, streaming=streaming)
                    left = frame('left', LEFT)
                    right = frame('right', RIGHT)
                    query = declare(left, right, kind)
                    assert events == []
                    harness.json(harness.logs / (name + '-declaration.json'), dict(
                        sql=query._relation_statement(), expected=expected, streaming=streaming))
                    try:
                        result = query.collect(check=True, memory_bytes=32 << 20, max_parallelism=1)
                    except ShardLoomCommandError as error:
                        assert streaming, error.envelope.raw
                        harness.envelope(name, error.envelope, success=False)
                        raw = json.dumps(error.envelope.raw)
                        assert 'SL-NATIVE-BATCH' in raw and 'dynamic schema' in raw
                        assert events == [], events
                        return dict(outcome='dynamic_inner_streaming_refusal', producer_events=events)
                    assert not streaming
                    harness.envelope(name, result.envelope)
                    harness.values(name, result.result_rows, expected)
                    labels = ['left'] if kind.endswith('-shared-True') else ['left', 'right']
                    for label in labels:
                        assert [event for source, event in events if source == label] == ['opened', 'ended', 'closed'], events
                    assert {source for source, _ in events} == set(labels)
                    return dict(outcome='resident_control_passed', producer_events=events,
                        schema=[(column, dtype.name, dtype.nullable) for column, dtype in result.result_schema])
                harness.case(name, case)
        assert len(harness.results) == 32 and all(row['status'] == 'passed' for row in harness.results)
        assert sources() == accepted and sha(artifacts['cli']['path']) == artifacts['cli']['sha256']
        status = 'passed'
    finally:
        harness.client.close()
        save(DEST / 'summary.json', dict(status=status, cases=harness.results, expected=EXPECTED,
            rows_left=LEFT, rows_right=RIGHT, binary=artifacts['cli'], head=HEAD,
            artifact_manifest=str(ARTIFACTS), artifact_manifest_sha256=sha(ARTIFACTS),
            accepted_source_manifest=str(SOURCE), accepted_source_manifest_sha256=sha(SOURCE),
            contract_sha256=sha(CONTRACT), provenance_sha256=sha(PROVENANCE),
            helper_sha256=sha(__file__), runtime_source_changed=False, performance_claim=False))
    print(json.dumps(dict(status=status, cases=32, streaming_refusals=16, resident_controls=16)))


if __name__ == '__main__':
    main()
