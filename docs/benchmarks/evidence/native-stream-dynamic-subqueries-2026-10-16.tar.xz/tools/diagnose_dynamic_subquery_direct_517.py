"""Separate retained-result pressure and guarded predicate parsing on the frozen candidate."""
import gc
import json
import os
import sys

from freeze_native_release_298 import ROOT, OUT, save, sha
from run_stream_dynamic_subquery_acceptance_517 import load, identity, MANIFEST
from run_query_timing_runtime_461 import PYTHON_DEPS

manifest = load()
sys.path[:0] = [str(ROOT / 'python/src'), str(ROOT / 'python/tests'), str(PYTHON_DEPS)]
os.environ.update(SHARDLOOM_NATIVE_TEST_LIBRARY=manifest['binding']['path'], SHARDLOOM_REQUIRE_NATIVE_PYTHON='1')
from test_native_dynamic_subquery_binding import declaration, statement, expected, LEFT, RIGHT, URIS, _load_native
import pyarrow as pa
native = _load_native()
session = native.Session(native.ExecutionResources(32 << 20, 1))
held = []
try:
    baseline = session.snapshot()['reserved_bytes']
    for execution in range(512):
        left, a = declaration(URIS[0], LEFT, False)
        right, b = declaration(URIS[1], RIGHT, False)
        plan = session.sql(statement('in'), batches=[left, right])
        try:
            result = plan.collect()
        except RuntimeError as error:
            assert 'reservation denied' in str(error), error
            denial = dict(execution=execution, error=str(error), snapshot=session.snapshot())
            break
        actual = pa.RecordBatchReader.from_stream(result).read_all()
        assert actual.to_pylist() == expected('in')
        held.append(actual)
    else:
        raise AssertionError('retention control did not exhaust the declared grant')
    assert len(held) > 100
    for table in held:
        assert table.to_pylist() == expected('in')
    del table, actual, result, plan
    held.clear()
    gc.collect()
    released = session.snapshot()
    assert released['reserved_bytes'] == baseline, (baseline, released)
    left, a = declaration(URIS[0], LEFT, False)
    right, b = declaration(URIS[1], RIGHT, False)
    result = session.sql(statement('in'), batches=[left, right]).collect()
    assert pa.RecordBatchReader.from_stream(result).read_all().to_pylist() == expected('in')
    del result
    gc.collect()
    assert session.snapshot()['reserved_bytes'] == baseline
    parsing = []
    for expression in ('EXISTS (SELECT value FROM range(1,2))', 'NOT EXISTS (SELECT value FROM range(1,2))',
                       'value IN (SELECT value FROM range(1,2))', 'value > ANY (SELECT value FROM range(1,2))'):
        sql = f'SELECT CASE WHEN FALSE THEN {expression} ELSE TRUE END AS answer FROM range(1,2)'
        try:
            session.sql(sql).collect()
        except RuntimeError as error:
            parsing.append(dict(sql=sql, error=str(error)))
        else:
            parsing.append(dict(sql=sql, outcome='passed'))
    save(OUT / 'dynamic-subquery-direct-diagnosis-517.json', dict(status='passed',
        artifact_manifest=identity(MANIFEST), helper=identity(__file__), retained_results=denial['execution'],
        pressure=denial, baseline_reserved_bytes=baseline, released_snapshot=released,
        fresh_query_passed=True, guarded_predicate_observations=parsing))
    print(json.dumps(dict(status='passed', retained_results=denial['execution'], refunded_to_baseline=True,
                         guarded_predicate_observations=parsing)))
finally:
    session.close()
