"""Verify shared streaming evidence storage without rerunning native workloads."""
import json
from pathlib import Path
import sys
import unittest

from freeze_native_release_298 import ROOT, OUT, save
from run_stream_dynamic_subquery_acceptance_521 import load, SOURCE, MANIFEST, identity


def main():
    manifest = load()
    sys.path[:0] = [str(ROOT / 'python/src'), str(ROOT / 'scripts')]
    suite = unittest.defaultTestLoader.discover(str(ROOT / 'python/tests'),
                                               pattern='test_native_streaming_uat_compression.py')

    def names(value):
        return ([name for child in value for name in names(child)]
                if isinstance(value, unittest.TestSuite) else [value.id()])

    declared = names(suite)
    assert len(declared) == len(set(declared)) == 5
    output = OUT / 'stream-dynamic-subquery-harness-tests-521.json'
    assert not output.exists()
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    passed = result.wasSuccessful() and result.testsRun == 5 and not result.skipped
    save(output, dict(status='passed' if passed else 'failed', test_names=declared,
        tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
        skipped=len(result.skipped), source=identity(SOURCE), manifest=identity(MANIFEST),
        helper=identity(__file__), mode='evidence_storage_unit_tests',
        original_source_and_binary_identity_preserved=load() == manifest))
    assert passed
    print(json.dumps(dict(status='passed', tests=5)))


if __name__ == '__main__':
    main()
