"""Primary verification of the read-only case-branch and CI test inventory."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess

from freeze_native_release_298 import ROOT, OUT, save
from run_stream_dynamic_subquery_acceptance_521 import identity


def main():
    path = OUT / 'dynamic-subquery-case-branch-inventory-521.json'
    inventory = json.loads(path.read_text())
    frozen = json.loads((OUT / 'native-release-source-streamdynamic520.json').read_text())
    rows, snippets, verified = [], 0, {}
    for name, record in inventory['source_files'].items():
        data = (ROOT / name).read_bytes()
        origin = 'current'
        if hashlib.sha256(data).hexdigest() != record['sha256']:
            data = subprocess.check_output(['git', 'cat-file', 'blob', frozen['head'] + ':' + name], cwd=ROOT)
            origin = frozen['head']
            assert frozen['source_sha256'][name] == record['sha256']
        assert len(data) == record['byte_size']
        assert hashlib.sha256(data).hexdigest() == record['sha256']
        verified[name] = data.decode()
        lines = data.decode().splitlines()
        for excerpt in record['excerpts']:
            first, last = excerpt['line_range_inclusive']
            assert '\n'.join(lines[first - 1:last]) == excerpt['text']
            snippets += 1
        rows.append(dict(file=name, sha256=record['sha256'], origin=origin, excerpts=len(record['excerpts'])))
    assert len(rows) == 9
    for group in inventory['test_inventory']:
        record = inventory['source_files'][group['file']]
        assert group['sha256'] == record['sha256']
        for test in group['tests']:
            matches = [node for node in ast.walk(ast.parse(verified[group['file']]))
                       if isinstance(node, ast.FunctionDef) and node.name == test['name']]
            assert len(matches) == 1 and test['lines'][0] <= matches[0].lineno <= test['lines'][1], test
    save(OUT / 'dynamic-subquery-case-branch-inventory-primary-521.json',
         dict(status='passed', inventory=identity(path), helper=identity(__file__),
              files=rows, excerpts=snippets, native_test_execution=False,
              semantic_and_runtime_acceptance_owned_separately=True))
    print(json.dumps(dict(status='passed', files=len(rows), excerpts=snippets)))


if __name__ == '__main__':
    main()
