"""Retain every selected source change against the frozen candidate's Git base."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sources, sha, save

sys.path.insert(0, str(ROOT / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def main():
    run = sys.argv[1]
    assert run.isdigit()
    frozen_path = OUT / f'native-release-source-streamdynamic{run}.json'
    frozen = json.loads(frozen_path.read_text())
    assert frozen['source_sha256'] == sources()
    destination = OUT / f'stream-dynamic-subquery-source-overlay-{run}'
    require_local_path(destination, Path.home(), sys.platform)
    check_budgets(OUT, destination, OUT / 'logs', min_free_bytes=12 * GIB,
                  reserve_bytes=128 * MIB, max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    assert not destination.exists()
    destination.mkdir()
    changed, unchanged = [], 0
    for name, digest in sorted(frozen['source_sha256'].items()):
        current = (ROOT / name).read_bytes()
        assert hashlib.sha256(current).hexdigest() == digest
        prior = subprocess.run(['git', 'cat-file', 'blob', frozen['head'] + ':' + name],
                               cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if prior.returncode == 0 and prior.stdout == current:
            unchanged += 1
            continue
        target = destination / 'source' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(current)
        assert target.read_bytes() == current
        changed.append(dict(source=name, archive_path=str(target.relative_to(destination)),
                            bytes=len(current), sha256=digest,
                            base_sha256=hashlib.sha256(prior.stdout).hexdigest() if prior.returncode == 0 else None))
    extras = {}
    for label, path in {
        'contract.md': ROOT / 'docs/architecture/native-stream-dynamic-subqueries-2026-10-15.md',
        'source-manifest.json': frozen_path,
        'acceptance-helper.py': OUT / 'run_stream_dynamic_subquery_checks_523.py',
        'protocol.json': OUT / 'stream-dynamic-subquery-acceptance-protocol-521.json',
        'source-transition.json': OUT / 'stream-dynamic-subquery-feature-gate-correction-523.json',
    }.items():
        target = destination / label
        with target.open('xb') as stream:
            stream.write(path.read_bytes())
        assert target.read_bytes() == path.read_bytes()
        extras[label] = identity(path)
    assert sources() == frozen['source_sha256']
    save(destination / 'overlay.json', dict(status='passed', base_commit=frozen['head'],
        source_manifest=identity(frozen_path), selected_source_files=len(frozen['source_sha256']),
        unchanged_files_verified_against_git=unchanged, changed_files=changed,
        overlay_bytes=sum(row['bytes'] for row in changed), snapshots=extras,
        helper=identity(__file__)))
    print(json.dumps(dict(status='passed', source_files=len(frozen['source_sha256']),
                         changed_files=len(changed), unchanged_files=unchanged)))


if __name__ == '__main__':
    main()
