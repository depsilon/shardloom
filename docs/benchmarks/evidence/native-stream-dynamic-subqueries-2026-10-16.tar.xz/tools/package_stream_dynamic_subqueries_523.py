"""Package complete dynamic-subquery acceptance, retaining every source transition and failure."""
from __future__ import annotations

import hashlib
import json
import lzma
from pathlib import Path
import re
import subprocess
import sys
import tarfile

from freeze_native_release_298 import ROOT, OUT, save, sha
from run_stream_dynamic_subquery_checks_524 import (
    SOURCE, EXECUTION_SOURCE, TRANSITION, AFTER, TEST_AFTER, BUILD_SOURCE, MANIFEST, PROTOCOL, identity, load, unchanged,
)
from package_selection_acceptance_409 import Members, verify, sha_stream, excluded_identity

sys.path.insert(0, str(ROOT / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
from native_workflow_protocol import strict_json

BASE = 'c30846afb0ab5abfff6fdb5d95ed20f1c10a9477'
PREFIX = 'native-stream-dynamic-subqueries-2026-10-16'
LOCAL = OUT / 'stream-dynamic-subquery-packet-523'
DEST = ROOT / 'docs/benchmarks/evidence'
PUBLIC = OUT / 'stream-dynamic-subquery-public-521'
CHECKS = OUT / 'stream-dynamic-subquery-checks-524.json'
FULL_REVIEW = OUT / 'stream-dynamic-subquery-full43-review-523.json'
MAX_RAW_BYTES = 256 * MIB


def read(path):
    return strict_json(Path(path).read_text())


def completed(path, head=BASE):
    receipt = read(path)
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0, path
    assert receipt['process_group_drained'] and receipt['direct_child_reaped'], path
    assert not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup'], path
    assert receipt['head'] == head and sha(Path(path).with_suffix('.log')) == receipt['log_sha256'], path
    return receipt


def main():
    assert not LOCAL.exists()
    assert all(not (DEST / (PREFIX + suffix)).exists() for suffix in ('.json', '.tar.xz', '.manifest.json.xz'))
    accepted, artifacts, built = unchanged(), load(), read(BUILD_SOURCE)
    assert accepted['head'] == built['head'] == BASE
    assert len(accepted['source_sha256']) == len(built['source_sha256']) == 2303
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
    protocol = read(PROTOCOL)
    assert protocol['expected_direct_tests'] == 100 and protocol['direct_matrix_query_calls'] == 288
    assert len(protocol['new_direct_methods']) == 4 and len(protocol['native_required_tests']) == 36
    assert len(protocol['new_native_required_tests']) == 21 and len(protocol['python_required_tests']) == 2
    declaration_path = OUT / 'stream-dynamic-subquery-candidate-declarations-521/declarations.json'
    declaration = read(declaration_path)
    assert declaration['status'] == 'declared_before_candidate_execution' and declaration['native_engine_executions'] == 0
    assert [row['cases'] for row in declaration['families']] == [716, 32, 153, 195, 7]
    frozen_contract = OUT / 'stream-dynamic-subquery-source-overlay-521/contract.md'
    assert sha(frozen_contract) == protocol['contract']['sha256']
    checks = read(CHECKS)
    assert checks['status'] == 'passed' and checks['source_identity_preserved'] and checks['source'] == identity(SOURCE)
    assert [row['stage'] for row in checks['completed']] == [
        'fmt', 'workspace-clippy', 'workspace-tests', 'read-clippy', 'release-clippy', 'native-tests']
    final_receipts = []
    for row in checks['completed']:
        for key in ('receipt', 'log'):
            assert identity(row[key]['path']) == row[key]
        completed(row['receipt']['path'])
        final_receipts.append(Path(row['receipt']['path']))
    counts = {row['stage']: row['tests'] for row in checks['completed'] if 'tests' in row}
    assert counts['workspace-tests']['passed'] >= 3220 and counts['workspace-tests']['ignored'] == 0
    assert counts['native-tests']['passed'] == 4285 and counts['native-tests']['ignored'] == 29
    prior_checks = read(OUT / 'stream-subquery-checks-510.json')
    prior_native = next(row['tests'] for row in prior_checks['completed'] if row['stage'] == 'native-tests')
    assert sorted(counts['native-tests']['ignored_declarations']) == sorted(prior_native['ignored_declarations'])
    native_log = Path(next(row['log']['path'] for row in checks['completed'] if row['stage'] == 'native-tests')).read_text()
    for name in protocol['native_required_tests']:
        assert re.search(r'^test .*::' + re.escape(name) + r' \.\.\. ok$', native_log, re.M), name
    direct_path = OUT / 'stream-dynamic-subquery-direct-tests-521.json'
    direct = read(direct_path)
    assert direct['status'] == 'passed' and direct['tests'] == 100
    assert direct['failures'] == direct['errors'] == direct['skipped'] == 0
    assert direct['source'] == identity(EXECUTION_SOURCE) and direct['artifact_manifest'] == identity(MANIFEST)
    harness = read(OUT / 'stream-dynamic-subquery-harness-tests-521.json')
    assert harness['status'] == 'passed' and harness['tests'] == 5 and harness['skipped'] == 0
    python_path = OUT / 'stream-dynamic-subquery-python-predicate-after-521.json'
    completed(python_path)
    python_log = python_path.with_suffix('.log').read_text()
    assert re.search(r'Ran 74 tests .*\n\nOK\s*$', python_log)
    for name in protocol['python_required_tests']:
        assert re.search(r'^' + re.escape(name) + r' .* \.\.\. ok$', python_log, re.M), name
    for kind, total in [('focused', 1103), ('public', 4827)]:
        value = read(OUT / f'stream-dynamic-subquery-{kind}-acceptance-521.json')
        assert value['status'] == 'passed' and value['cases'] == total
        assert value['manifest'] == identity(MANIFEST) and value['source'] == identity(EXECUTION_SOURCE)
        assert identity(value['summary']['path']) == value['summary']
    public = read(PUBLIC / 'summary.json')
    assert public['status'] == 'passed' and public['families'] == protocol['expected_public_families']
    assert [row['name'] for row in public['cases']] == protocol['expected_public_names']
    assert len(public['cases']) == 4827 and all(row['status'] == 'passed' for row in public['cases'])
    inspection_path = OUT / 'stream-dynamic-subquery-public-inspection-report-522.json'
    inspection = read(inspection_path)
    assert inspection['status'] == 'passed' and inspection['cases'] == 4827 and inspection['families'] == 36
    assert inspection['summary'] == identity(PUBLIC / 'summary.json')
    assert inspection['complete_case_log_records_equal'] and inspection['frozen_sources_and_binary_unchanged']
    full = read(FULL_REVIEW)
    assert full['status'] == 'passed' and full['calls'] == full['queries'] == 43 and full['repeats'] == 1
    assert full['complete_rows'] == 381 and full['accepted_source'] == identity(SOURCE)
    assert full['all_values_schemas_and_clocks_reopened'] and full['resources_no_fallback_native_certificates']
    assert full['native_children_absent'] and full['original_input_and_sources_unchanged']
    assert full['no_new_ingest'] and not full['performance_claim_allowed']
    admission = read(full['admission']['path'])
    assert admission['source_resident_before_read'] and admission['no_new_ingest']
    for row in full['companions'] + full['envelopes'] + [full['summary'], full['timing_csv'], full['receipt'], full['admission']]:
        assert identity(row['path']) == row
    baseline = read(OUT / 'stream-dynamic-inner-baseline-513/summary.json')
    assert baseline['status'] == 'passed' and len(baseline['cases']) == 32
    assert all(row['status'] == 'passed' for row in baseline['cases'])
    assert sum(row['outcome'] == 'dynamic_inner_streaming_refusal' for row in baseline['cases']) == 16
    assert sum(row['outcome'] == 'resident_control_passed' for row in baseline['cases']) == 16
    original_contract = subprocess.check_output(['git', 'cat-file', 'blob',
        baseline['head'] + ':docs/architecture/native-stream-subqueries-2026-10-15.md'], cwd=ROOT)
    assert hashlib.sha256(original_contract).hexdigest() == baseline['contract_sha256']
    for name in ['stream-dynamic-subquery-direct-521', 'stream-dynamic-subquery-focused-521',
                 'stream-dynamic-subquery-public-521', 'stream-dynamic-subquery-harness-521',
                 'stream-dynamic-subquery-full43-523', 'stream-dynamic-subquery-public-inspection-522',
                 'stream-dynamic-subquery-python-predicate-after-521',
                 'native-final-cli-release-build-streamdynamic518',
                 'native-final-python-release-build-streamdynamic518']:
        path = OUT / (name + '.json')
        completed(path)
        final_receipts.append(path)

    members, exclusions = Members(), []
    def add(path, name, role, digest=None):
        path = Path(path)
        root = ROOT if path.is_relative_to(ROOT) else OUT if path.is_relative_to(OUT) else path.parent
        members.add(path, name, root.name, root, role, digest)

    overlay = read(OUT / 'stream-dynamic-subquery-source-overlay-524/overlay.json')
    overlay_names = [row['source'] for row in overlay['changed_files']]
    assert overlay['status'] == 'passed' and overlay['base_commit'] == BASE
    assert overlay['source_manifest'] == identity(SOURCE)
    for row in overlay['changed_files']:
        add(ROOT / row['source'], 'source-overlay/' + row['source'],
            'accepted selected source overlay', accepted['source_sha256'][row['source']])
    for path, role in [(BUILD_SOURCE, 'compiled native source manifest'),
                       (MANIFEST, 'frozen CLI and binding build identities'),
                       (EXECUTION_SOURCE, 'public and direct accepted execution source manifest'),
                       (SOURCE, 'accepted verification source manifest')]:
        add(path, 'manifests/' + path.name, role)
    add(AFTER, 'source-transition/' + AFTER.name, 'exact source after conditional field gate')
    add(TEST_AFTER, 'source-transition/' + TEST_AFTER.name, 'exact test-only assertion correction')
    # The baseline contract is a verified Git blob; preserve its exact bytes before later status edits.
    original_path = OUT / 'dynamic-subquery-baseline-contract-523.md'
    assert not original_path.exists()
    with original_path.open('xb') as stream:
        stream.write(original_contract)
    add(original_path, 'preimplementation/baseline-contract.md', 'exact baseline contract from the baseline Git revision', baseline['contract_sha256'])
    for path in sorted(OUT.iterdir()):
        if (path.is_file() and re.search(r'(stream[-_]dynamic|dynamic[-_]subquery|streamdynamic)', path.name)
                and path.suffix in ('.json', '.log', '.py', '.diff', '.md')
                and path.name not in ('stream-dynamic-subquery-package-523.log', 'stream-dynamic-subquery-package-523.json')):
            add(path, ('tools/' if path.suffix == '.py' else 'receipts/') + path.name,
                'retained dynamic-subquery observation or helper; success requires its separate receipt')
    for folder, prefix in [
        ('stream-dynamic-inner-baseline-513', 'baseline'),
        *[(f'stream-dynamic-subquery-candidate-declarations-{run}', f'declarations-{run}') for run in (517, 518, 519, 520, 521)],
        *[(f'stream-dynamic-subquery-source-overlay-{run}', f'source-snapshot-{run}') for run in (517, 518, 519, 520, 521, 524)],
        *[(f'stream-dynamic-subquery-focused-{run}', f'failed-focused-{run}') for run in (518, 519, 520)],
        ('dynamic-subquery-metadata-diagnosis-519', 'metadata-diagnosis'),
        ('dynamic-subquery-remaining-diagnosis-520', 'remaining-diagnosis'),
        ('stream-dynamic-subquery-focused-521', 'focused-public'),
        ('stream-dynamic-subquery-public-521', 'public')]:
        members.tree(OUT / folder, prefix, prefix, 'complete compact dynamic-subquery evidence tree', exclusions, omit_outputs=True)
    for key in ('original_public', 'original_direct', 'original_protocol'):
        value = protocol[key]
        add(value['path'], 'prior-identities/' + Path(value['path']).name, 'prior exact case/method/protocol identity', value['sha256'])
    add(OUT / 'stream-subquery-checks-510.json', 'prior-identities/stream-subquery-checks-510.json', 'unchanged manual and platform exclusions')
    for path in [OUT / 'stream-unary-candidate-declarations-493b/logs/unary-predeclared-values.json',
                 OUT / 'stream-subquery-candidate-declarations-509/subqueries/logs/subquery-predeclared-results.json']:
        add(path, 'predeclared-reference/' + path.name, 'inherited complete pre-execution expected values')
    for key in ('artifact_manifest', 'accepted_source_manifest'):
        path = Path(baseline[key])
        add(path, 'prior-identities/' + path.name, 'baseline build/source provenance', baseline[key + '_sha256'])
    add(OUT / 'stream-subquery-hosted-512/pr-sources-513.json', 'prior-identities/pr-sources-513.json',
        'baseline accepted source and PR identity proof', baseline['provenance_sha256'])
    initial = read(OUT / 'native-release-artifacts-streamdynamic517.json')
    for artifact in [artifacts['cli'], artifacts['binding'], initial['cli'], initial['binding'], baseline['binary']]:
        assert identity(artifact['path']) == {key: artifact[key] for key in ('path', 'bytes', 'sha256')}
        exclusions.append(excluded_identity(Path(artifact['path']),
            'executables/' + Path(artifact['path']).parent.name + '/' + Path(artifact['path']).name,
            'frozen executable excluded; complete build provenance retained'))
        for key in ('build_receipt', 'build_log'):
            add(artifact[key], 'build-evidence/' + Path(artifact[key]).name, 'original build receipt or complete log')
    input_identity = admission['input']
    exclusions.append(dict(archive_path='resident-input/' + Path(input_identity['path']).name,
        original_absolute_path=input_identity['path'], byte_count=input_identity['bytes'], sha256=input_identity['sha256'],
        reason='large resident input excluded; before/after complete hash proof retained'))
    for item in [admission['reference'], admission['queries'], *admission['harness'], *admission['schema_sources']]:
        group = 'full43-baseline-schemas' if item in admission['schema_sources'] else 'full43-inputs'
        add(item['path'], group + '/' + Path(item['path']).name, 'predeclared Full43 reference, schema or harness input', item['sha256'])
    members.tree(Path(full['summary']['path']).parent, 'full43', 'full43', 'complete one-pass Full43 evidence', exclusions)

    dependencies = read(OUT / 'dynamic-subquery-helper-dependencies-522.json')
    dependency_acceptance = read(OUT / 'dynamic-subquery-helper-dependencies-primary-522.json')
    assert dependency_acceptance['status'] == 'passed_source_dependency_inventory'
    assert dependency_acceptance['inventory'] == identity(OUT / 'dynamic-subquery-helper-dependencies-522.json')
    for item in dependency_acceptance['package_files']:
        path = Path(item['path'])
        add(path, 'python-package/' + path.relative_to(ROOT / 'python/src').as_posix(),
            'complete accepted source Python package', item['sha256'])
    for item in dependencies['files'] + dependency_acceptance['additional_files']:
        path = Path(item['path'])
        relative = ('repository/' + path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT) else
                    'local/' + path.relative_to(OUT).as_posix() if path.is_relative_to(OUT) else
                    'external/' + path.parent.name + '/' + path.name)
        add(path, 'dependencies/' + relative, 'transitive local helper source', item['sha256'])
    for name in ('package_selection_acceptance_409.py', 'verify_stream_unary_packet_497.py'):
        add(OUT / name, 'tools/' + name, 'reused archive packaging or independent verification primitives')

    ordered = sorted(members.paths.values(), key=lambda item: item.name)
    raw_size = sum(item.size for item in ordered)
    assert raw_size <= MAX_RAW_BYTES, (raw_size, MAX_RAW_BYTES)
    require_local_path(LOCAL, Path.home(), sys.platform)
    storage = check_budgets(OUT, LOCAL, OUT / 'logs', min_free_bytes=12 * GIB,
        reserve_bytes=raw_size + 64 * MIB, max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    LOCAL.mkdir()
    archive_path = LOCAL / (PREFIX + '.tar.xz')
    with archive_path.open('xb') as target:
        with tarfile.open(fileobj=target, mode='w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
            for item in ordered:
                verify(item.path, item.digest, item.size)
                info = tarfile.TarInfo(item.name)
                info.size, info.mode, info.mtime = item.size, 0o644, 0
                with item.path.open('rb') as stream:
                    archive.addfile(info, stream)
    seen = set()
    with tarfile.open(archive_path, mode='r|xz') as archive:
        for entry in archive:
            assert entry.isfile() and entry.name in members.names and entry.name not in seen
            item = members.paths[members.names[entry.name]]
            with archive.extractfile(entry) as stream:
                assert sha_stream(stream) == (item.size, item.digest), entry.name
            seen.add(entry.name)
    assert seen == set(members.names)
    for item in ordered:
        verify(item.path, item.digest, item.size)
    assert unchanged() == accepted and load() == artifacts
    acceptance = dict(workspace_tests=counts['workspace-tests']['passed'], workspace_ignored=0,
        native_tests=4285, native_ignored=29, new_native_dynamic_tests=19, new_parser_tests=2,
        direct_methods=100, direct_skips=0, new_direct_methods=4, direct_matrix_query_calls=288,
        python_declaration_methods=74, new_python_declaration_methods=2, harness_methods=5,
        focused_public_cases=1103, public_cases=4827, public_families=36,
        full43_queries=43, full43_calls=43, full43_repeats=1, full43_complete_rows=381,
        baseline_controls=32, baseline_streaming_refusals=16, baseline_resident_controls=16)
    limits = ['Dynamic predicate subqueries require a finite declared source set; opaque callbacks and dynamic scalar output-schema inference remain inadmissible.',
              'Membership/index state remains resident; replay spill does not spill that state.',
              'One complete regression pass does not establish a speedup, whole-process memory ceiling, package release or all-platform readiness.',
              'Direct tests use the source Python package with the frozen native extension; installed-wheel and hosted integration are separate gates.']
    manifest = dict(status='passed_local_evidence_packaged', base_commit=BASE, source_files=2303,
        source_manifest=identity(BUILD_SOURCE), accepted_verification_source=identity(SOURCE), artifact_manifest=identity(MANIFEST),
        accepted_execution_source=identity(EXECUTION_SOURCE), source_transition=identity(TRANSITION),
        source_overlay=overlay_names, members=[dict(path=str(item.path), archive_path=item.name, bytes=item.size,
            sha256=item.digest, roles=item.roles) for item in ordered], member_count=len(ordered), raw_bytes=raw_size,
        all_members_reopened=True, storage=storage, exclusions=exclusions, acceptance=acceptance,
        final_receipts=[identity(path) for path in final_receipts], public_inspection=identity(inspection_path),
        full43_review=identity(FULL_REVIEW), original_contract=identity(frozen_contract),
        baseline_contract=identity(original_path), source_identity_preserved=True,
        native_enabled_code_unchanged_after_fixture_python_and_feature_gate_corrections=True,
        production_python_changes=['python/src/shardloom/query.py'], publication_attempted=False, limitations=limits)
    raw = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    packed = lzma.compress(raw, preset=6)
    assert lzma.decompress(packed) == raw
    manifest_path = LOCAL / (PREFIX + '.manifest.json.xz')
    with manifest_path.open('xb') as stream:
        stream.write(packed)
    index = dict(schema_version='shardloom.native_stream_dynamic_subqueries_evidence.v1',
        status='packaged_local_pending_acceptance_decision', base_commit=BASE, source_files=2303,
        member_count=len(seen), raw_bytes=raw_size, all_members_reopened=True, acceptance=acceptance,
        source_manifest=manifest['source_manifest'], accepted_verification_source=manifest['accepted_verification_source'],
        accepted_execution_source=manifest['accepted_execution_source'], source_transition=manifest['source_transition'],
        artifact_manifest=manifest['artifact_manifest'], source_overlay=overlay_names,
        archive=dict(file=archive_path.name, bytes=archive_path.stat().st_size, sha256=sha(archive_path)),
        manifest=dict(file=manifest_path.name, bytes=len(packed), sha256=sha(manifest_path), raw_sha256=hashlib.sha256(raw).hexdigest()),
        limitations=limits, publication_attempted=False, hosted_integration_complete=False)
    for path in (archive_path, manifest_path):
        target = DEST / path.name
        with target.open('xb') as stream:
            stream.write(path.read_bytes())
        assert sha(target) == sha(path)
    save(DEST / (PREFIX + '.json'), index)
    save(LOCAL / 'verification.json', dict(status='all_members_reopened', member_count=len(seen),
        archive=identity(archive_path), manifest=identity(manifest_path), index=identity(DEST / (PREFIX + '.json')),
        helper=identity(__file__)))
    print(json.dumps(dict(status=index['status'], members=len(seen), raw_bytes=raw_size)))


if __name__ == '__main__':
    main()
