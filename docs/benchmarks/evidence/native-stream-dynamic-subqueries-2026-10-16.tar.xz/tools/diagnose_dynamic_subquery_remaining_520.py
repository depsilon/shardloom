"""Inspect the still-unexecuted declared cases, retaining every failure for one repair pass."""
import json
import sys
import traceback

from freeze_native_release_298 import ROOT, OUT, save
from run_stream_dynamic_subquery_acceptance_520 import load, identity, SOURCE, MANIFEST, PROTOCOL

sys.path[:0] = [str(ROOT / 'python/src'), str(ROOT / 'scripts')]
from run_native_streaming_input_uat import FAMILIES, Harness


def main():
    manifest = load()
    prior_path = OUT / 'stream-dynamic-subquery-focused-520/summary.json'
    prior = json.loads(prior_path.read_text())
    skipped = {row['name'] for row in prior['cases'] if row['status'] == 'passed'}
    assert len(skipped) == 842
    protocol = json.loads(PROTOCOL.read_text())
    expected = [name for name in protocol['new_public_names'] if name not in skipped]
    assert len(expected) == 229
    root = OUT / 'dynamic-subquery-remaining-diagnosis-520'
    assert not root.exists()
    harness = Harness(manifest['cli']['path'], root, 600, compress_logs=True)
    harness.guard()
    harness.logs.mkdir(parents=True)
    harness.output.mkdir()
    save(root / 'protocol.json', dict(expected=expected, skipped=sorted(skipped),
        prior=identity(prior_path), acceptance_protocol=identity(PROTOCOL), source=identity(SOURCE),
        manifest=identity(MANIFEST), helper=identity(__file__), performance_claim=False))
    original_case, failures = harness.case, []

    def capture(name, call):
        if name in skipped:
            return
        assert name in expected
        try:
            original_case(name, call)
        except Exception as error:
            failures.append(dict(name=name, type=type(error).__name__, error=str(error),
                                 traceback=traceback.format_exc()))
            harness.guard()

    harness.case = capture
    try:
        for family in ('dynamic-subqueries-composition', 'dynamic-subqueries-fault', 'dynamic-subqueries-pressure'):
            FAMILIES[family](harness)
        assert [row['name'] for row in harness.results] == expected
        assert load() == manifest
    finally:
        harness.client.close()
        save(root / 'summary.json', dict(status='diagnostic_complete', cases=harness.results,
            failures=failures, compressed_json_files=harness.compressed_json_files,
            source=identity(SOURCE), manifest=identity(MANIFEST), protocol=identity(root / 'protocol.json')))
    print(json.dumps(dict(status='diagnostic_complete', cases=len(harness.results),
        passed=sum(row['status'] == 'passed' for row in harness.results), failures=len(failures))), flush=True)


if __name__ == '__main__':
    main()
