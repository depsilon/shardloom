"""One complete call per ClickBench query for frozen streaming subquery sources."""
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import stat
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, save, sha, sources
import run_compression_full43_457 as common
from run_stream_dynamic_subquery_checks_524 import (
    load, unchanged, SOURCE, EXECUTION_SOURCE, TRANSITION, identity,
)

ACCEPTED_SOURCE = SOURCE

sys.path.insert(0, str(ROOT / 'scripts'))
from clickbench_reference_packet import load_reference_packet
from local_uat_storage import (DEFAULT_MAX_LOG_MIB, DEFAULT_MAX_RUN_LOG_MIB,
    GIB, MIB, check_budgets, require_local_path)
from native_workflow_protocol import extract_result, report_fields, strict_json
from query_timing_report import query_phase_timings, timing_totals
from run_clickbench_query_uat import clickbench_harness_paths, equivalent, read_json_log, score

MANIFEST = OUT / 'native-release-artifacts-streamdynamic518.json'
SOURCE_MANIFEST = OUT / 'native-release-source-streamdynamic518.json'
UAT = common.UAT
INPUT = UAT / 'vortex/timed-native-461-a1.vortex'
BASELINE = UAT / 'logs/full43_20261015T090121385273Z'
REFERENCE = common.REFERENCE
QUERIES = common.QUERIES
bound = common.bound


def frozen():
    build = strict_json(MANIFEST.read_text())
    assert load() == build  # Also verifies the independently frozen reference JSON.
    source = strict_json(SOURCE_MANIFEST.read_text())
    assert build['status'] == 'passed' and build['build_profile'] == 'release'
    assert build['source_sha256'] == source['source_sha256']
    assert sources() == unchanged()['source_sha256']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == build['head'] == source['head']
    for kind in ('cli', 'binding'):
        artifact = build[kind]
        assert bound(artifact['path']) == {key: artifact[key] for key in ('path', 'bytes', 'sha256')}
        assert sha(artifact['build_receipt']) == artifact['build_receipt_sha256']
        receipt = strict_json(Path(artifact['build_receipt']).read_text())
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert receipt['head'] == build['head'] and '--release' in receipt['command']
        assert sha(artifact['build_log']) == receipt['log_sha256']
    return build


def main():
    build = frozen()
    for name in ('stream-dynamic-subquery-full43-523.json', 'stream-dynamic-subquery-full43-admission-523.json', 'stream-dynamic-subquery-full43-review-523.json'):
        assert not (OUT / name).exists(), name
    runtime_path = OUT / 'stream-dynamic-subquery-public-acceptance-521.json'
    runtime = json.loads(runtime_path.read_text())
    assert runtime['source'] == identity(EXECUTION_SOURCE)
    assert runtime['status'] == 'passed' and runtime['manifest'] == identity(MANIFEST)
    assert runtime['cases'] == 4827 and len(runtime['families']) == 36
    gates = {}
    for name in ('stream-dynamic-subquery-focused-acceptance-521.json',
                 'stream-dynamic-subquery-direct-tests-521.json', 'stream-dynamic-subquery-checks-524.json',
                 'stream-dynamic-subquery-harness-tests-521.json', 'stream-dynamic-subquery-public-inspection-report-522.json'):
        path = OUT / name
        value = strict_json(path.read_text())
        assert value['status'] == 'passed'
        gates[name] = bound(path)
    direct = strict_json((OUT / 'stream-dynamic-subquery-direct-tests-521.json').read_text())
    assert direct['tests'] == 100 and direct['skipped'] == direct['failures'] == direct['errors'] == 0
    assert direct['artifact_manifest'] == identity(MANIFEST) and direct['source'] == identity(EXECUTION_SOURCE)
    checks = strict_json((OUT / 'stream-dynamic-subquery-checks-524.json').read_text())
    assert checks['source_identity_preserved'] and checks['source'] == identity(ACCEPTED_SOURCE)
    assert len(checks['completed']) == 6
    for check in checks['completed']:
        for key in ('receipt', 'log'):
            assert bound(check[key]['path']) == check[key]
        receipt = strict_json(Path(check['receipt']['path']).read_text())
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    inspected = strict_json((OUT / 'stream-dynamic-subquery-public-inspection-report-522.json').read_text())
    assert inspected['cases'] == 4827 and inspected['families'] == 36
    assert inspected['accepted_source'] == identity(EXECUTION_SOURCE)
    assert inspected['summary'] == runtime['summary']
    accepted = json.loads((ROOT / 'docs/benchmarks/evidence/native-query-timing-uat-2026-10-15.json').read_text())
    input_receipt = accepted['datasets'][str(INPUT)]
    require_local_path(UAT, Path.home(), sys.platform)
    require_local_path(INPUT, Path.home(), sys.platform)
    before = common.generation(INPUT)
    assert stat.S_ISREG(INPUT.stat().st_mode) and before['st_flags'] == 0
    assert before['st_size'] == 15713610513 and before['st_blocks'] * 512 >= before['st_size']
    storage = check_budgets(UAT, INPUT, UAT / 'logs/stream-dynamic-subquery-full43-523-admission',
        min_free_bytes=12*GIB, reserve_bytes=(4+DEFAULT_MAX_RUN_LOG_MIB)*MIB,
        max_workspace_bytes=100*GIB, max_log_bytes=DEFAULT_MAX_LOG_MIB*MIB,
        max_run_log_bytes=DEFAULT_MAX_RUN_LOG_MIB*MIB,
        reserve_log_bytes=DEFAULT_MAX_RUN_LOG_MIB*MIB)
    assert not (UAT / '.ingest-uat.lock').exists()
    input_identity = bound(INPUT)
    assert input_identity['sha256'] == input_receipt['sha256']
    assert common.generation(INPUT) == before
    assert sha(REFERENCE) == 'cb83c770674073f31ad0c4224f02faeb1ba557c512595a5c2d36f92bb2344b39'
    reference = load_reference_packet(REFERENCE, QUERIES)
    schemas, schema_sources = {}, []
    for query in range(1, 44):
        path = BASELINE / f'q{query:02d}_run1.stdout.json'
        envelope = read_json_log(path)
        assert equivalent(extract_result(envelope), reference['values'][query])
        fields = report_fields(envelope)
        schemas[query] = (fields['result_schema_format'], strict_json(fields['result_schema_json']))
        schema_sources.append(bound(path if path.exists() else path.with_suffix('.json.gz')))
    harness = [bound(path) for path in clickbench_harness_paths()]
    admission_path = OUT / 'stream-dynamic-subquery-full43-admission-523.json'
    admission = dict(status='passed', manifest=bound(MANIFEST), source_manifest=bound(SOURCE_MANIFEST), input=input_identity,
        accepted_source=identity(ACCEPTED_SOURCE), execution_source=identity(EXECUTION_SOURCE),
        source_transition=identity(TRANSITION), source_generation=before, source_resident_before_read=True, prior_input_receipt=input_receipt,
        runtime=bound(runtime_path), case_protocol=runtime['protocol'], prerequisite_gates=gates,
        reference=bound(REFERENCE), queries=bound(QUERIES), harness=harness,
        driver=bound(__file__), reused_helper=bound(common.__file__), storage=storage,
        schema_sources=schema_sources, memory_gb=24, maximum_parallelism=12,
        repeats=1, log_budget_bytes=dict(retained=DEFAULT_MAX_LOG_MIB*MIB,
            active_run=DEFAULT_MAX_RUN_LOG_MIB*MIB),
        cache_state='prehashed; OS cache uncontrolled', performance_claim_allowed=False,
        reference_kind='retained_native_regression', no_new_ingest=True)
    save(admission_path, admission)
    old = set((UAT / 'logs').glob('full43_*/summary.json'))
    commit_label = build['head'] + '+stream-dynamic-subqueries-' + sha(MANIFEST)[:12]
    command = [sys.executable, '-B', str(OUT / 'run_guarded.py'), '--name', 'stream-dynamic-subquery-full43-523',
        '--timeout', '2400', '--', sys.executable, '-B', str(ROOT / 'scripts/run_clickbench_query_uat.py'),
        '--binary', build['cli']['path'], '--build-commit', commit_label,
        '--input', str(INPUT), '--uat-root', str(UAT), '--reference-packet', str(REFERENCE),
        '--queries', str(QUERIES), '--memory-gb', '24', '--max-parallelism', '12',
        '--timeout', '120', '--compress-logs', '--repeats', '1',
        '--max-log-mib', str(DEFAULT_MAX_LOG_MIB), '--max-run-log-mib', str(DEFAULT_MAX_RUN_LOG_MIB)]
    subprocess.run(command, cwd=ROOT, check=True)
    receipt_path = OUT / 'stream-dynamic-subquery-full43-523.json'
    receipt = strict_json(receipt_path.read_text())
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert sha(receipt_path.with_suffix('.log')) == receipt['log_sha256']
    new = set((UAT / 'logs').glob('full43_*/summary.json')) - old
    assert len(new) == 1
    summary_path = new.pop()
    report = strict_json(summary_path.read_text())
    assert report['build_commit'] == commit_label and report['binary_sha256'] == build['cli']['sha256']
    for key in ('complete', 'full_result_validation', 'completed_identity_check',
                'reference_packet_identity_verified', 'harness_identity_verified'):
        assert report[key] is True, key
    assert report['reference_kind'] == 'retained_native_regression'
    assert report['reference_packet']['sha256'] == admission['reference']['sha256']
    assert report['memory_gb'] == 24 and report['max_parallelism'] == 12
    assert report['log_budget_bytes'] == admission['log_budget_bytes']
    assert report['selected_query_ids'] == list(range(1, 44)) and len(report['records']) == 43
    assert report['repeats'] == 1 and report['hot_total_seconds'] is None and report['hot_geomean_seconds'] is None
    assert {(row['query'], row['run']) for row in report['records']} == {(q, 1) for q in range(1, 44)}
    rows, companions, envelopes = 0, [], []
    for record in report['records']:
        query = record['query']
        assert record['passed'] and record['validation'] == 'complete_values'
        assert record['returncode'] == 0 and not record['guard_failures']
        assert record['command'][0] == build['cli']['path']
        prefix = summary_path.parent / f'q{query:02d}_run1'
        timing_path = prefix.with_suffix('.timing.json')
        timing = strict_json(timing_path.read_text())
        assert timing['returncode'] == 0
        for key in ('seconds', 'user_cpu_seconds', 'system_cpu_seconds'):
            assert timing[key] == record[key]
        assert timing['peak_rss_bytes'] == record['native_peak_rss_bytes']
        pid_path = prefix.with_suffix('.pid')
        try:
            os.kill(int(pid_path.read_text()), 0)
        except ProcessLookupError:
            pass
        else:
            raise AssertionError(f'native PID remains: {pid_path}')
        companions.extend([bound(timing_path), bound(pid_path)])
        envelope = None
        for archive in record['completed_log_archives']:
            packed = Path(archive['path']).read_bytes()
            assert len(packed) == archive['gzip_bytes'] and hashlib.sha256(packed).hexdigest() == archive['gzip_sha256']
            raw = gzip.decompress(packed)
            assert len(raw) == archive['raw_bytes'] and hashlib.sha256(raw).hexdigest() == archive['raw_sha256']
            envelopes.append(bound(archive['path']))
            if archive['path'].endswith('.stdout.json.gz'):
                assert envelope is None
                envelope = strict_json(raw.decode())
        assert envelope is not None
        fields = report_fields(envelope)
        for key, value in query_phase_timings(fields, timing['seconds']).items():
            assert record[key] == value, (query, key)
        assert fields['execution_resource_declared_memory_bytes'] == str(24*GIB)
        assert fields['execution_resource_declared_max_parallelism'] == '12'
        assert fields['execution_resource_whole_process_memory_limit_enforced'] == 'false'
        for key, value in fields.items():
            if key.endswith(('fallback_attempted', 'fallback_execution_allowed', 'external_engine_invoked')):
                assert value == 'false' or value is False, (query, key)
        assert any(c['kind'] == 'native_io_certificate' and c['status'] == 'available' for c in envelope['certificates'])
        actual = extract_result(envelope)
        assert equivalent(actual, reference['values'][query])
        assert hashlib.sha256(json.dumps(actual, sort_keys=True, allow_nan=False).encode()).hexdigest() == record['result_sha256']
        assert (fields['result_schema_format'], strict_json(fields['result_schema_json'])) == schemas[query]
        rows += len(actual)
    for key, value in score(report['records'], 43, repeats=1, timing_key='engine_execution_seconds').items():
        assert report[key] == value, key
    assert report['secondary_process_wall'] == score(report['records'], 43, repeats=1)
    assert common.generation(INPUT) == before and bound(INPUT) == input_identity and common.generation(INPUT) == before
    assert bound(MANIFEST) == admission['manifest'] and frozen() == build
    assert bound(SOURCE_MANIFEST) == admission['source_manifest']
    assert all(bound(row['path']) == row for row in gates.values())
    assert bound(runtime_path) == admission['runtime']
    assert identity(ACCEPTED_SOURCE) == admission['accepted_source']
    assert identity(TRANSITION) == admission['source_transition']
    assert identity(EXECUTION_SOURCE) == admission['execution_source']
    for item in harness + schema_sources + [admission['reference'], admission['queries'], admission['driver'], admission['reused_helper']]:
        assert bound(item['path']) == item
    assert not (UAT / '.ingest-uat.lock').exists()
    result = dict(status='passed', admission=bound(admission_path), receipt=bound(receipt_path),
        accepted_source=identity(ACCEPTED_SOURCE), summary=bound(summary_path), manifest=admission['manifest'], queries=43, calls=43, repeats=1,
        complete_rows=rows, all_values_schemas_and_clocks_reopened=True,
        resources_no_fallback_native_certificates=True, native_children_absent=True,
        original_input_and_sources_unchanged=True, performance_claim_allowed=False, no_new_ingest=True,
        reference_kind='retained_native_regression', timing_totals=timing_totals(report['records']),
        supervised_suite_seconds=receipt['seconds'], companions=companions, envelopes=envelopes,
        timing_csv=bound(summary_path.parent / 'query-timings.csv'), publication_attempted=False)
    result_path = OUT / 'stream-dynamic-subquery-full43-review-523.json'
    save(result_path, result)
    print(json.dumps(dict(status='passed', calls=43, complete_rows=rows,
                         engine_execution_seconds=sum(row['engine_execution_seconds'] for row in report['records']))), flush=True)


if __name__ == '__main__':
    main()
