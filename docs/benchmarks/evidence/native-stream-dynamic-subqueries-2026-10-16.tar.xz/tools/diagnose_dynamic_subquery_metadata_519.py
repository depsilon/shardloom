"""Predeclared two-grant check for the unchanged nested SQL declaration."""
import gzip
import json
import re
import sys

from freeze_native_release_298 import ROOT, OUT, save
from run_stream_dynamic_subquery_acceptance_519 import load, identity, SOURCE, MANIFEST

sys.path[:0] = [str(ROOT / 'python/src'), str(ROOT / 'scripts')]
import shardloom as sl
from run_native_streaming_input_uat import Harness
from native_streaming_unary_cases import frame
from native_streaming_subquery_cases import LEFT, RIGHT, SCHEMA, POLICY
from native_streaming_dynamic_subquery_cases import apply, inner, oracle, consume, fields


def normalized(sql):
    names = {}
    def replace(match):
        return names.setdefault(match[0], 'source_' + str(len(names)))
    return re.sub(r'memory://batches/[0-9a-f]{32}', replace, sql)


def main():
    manifest = load()
    root = OUT / 'dynamic-subquery-metadata-diagnosis-519'
    assert not root.exists()
    root.mkdir()
    declarations = [dict(kind=kind, shared=shared, memory_bytes=mib << 20,
        expected_outcome='reservation_denied' if mib == 32 else 'complete_values',
        expected=oracle(kind, LEFT, [row for row in RIGHT if row['n'] is not None]))
        for shared in (True, False) for kind in ('in', 'exists', 'all-ge') for mib in (32, 64)]
    save(root / 'protocol.json', dict(cases=declarations, source=identity(SOURCE),
        artifacts=identity(MANIFEST), helper=identity(__file__), no_runtime_change=True))
    original = json.loads(gzip.decompress((OUT / 'stream-dynamic-subquery-focused-519/logs/dynamic-subquery-nested-shared-in-predeclared.json.gz').read_bytes()))
    observed = []
    for case in declarations:
        kind, shared, grant = case['kind'], case['shared'], case['memory_bytes']
        name = f'nested-{kind}-shared-{shared}-grant-{grant}'
        directory = root / name
        directory.mkdir()
        harness = Harness(manifest['cli']['path'], directory, 600, compress_logs=True)
        harness.logs.mkdir()
        harness.output.mkdir()
        try:
            left, a = frame(harness, LEFT, SCHEMA, width=1)
            right, b = frame(harness, RIGHT, SCHEMA, width=1)
            traces = [a, b]
            if shared:
                deepest = right
            else:
                deepest, c = frame(harness, [dict(n=1, s='deep')], SCHEMA)
                traces.append(c)
            right = right.with_column('keep', sl.exists_source(inner(deepest))).filter('keep').select('n', 's')
            query = apply(left, right, kind, 'sql')
            if shared and kind == 'in':
                assert normalized(query._relation_statement()) == normalized(original['sql'])
            harness.json(harness.logs / (name + '-declaration.json'), dict(case, sql=query._relation_statement()))
            before = set(harness.output.iterdir())
            try:
                report = consume(harness, name, query, case['expected'], fields(kind), traces,
                    requested=dict(POLICY, memory_bytes=grant), terminal='batches')
            except sl.ShardLoomCommandError as error:
                assert grant == 32 << 20
                harness.envelope(name, error.envelope, success=False)
                reason = '\n'.join(item.reason or item.message for item in error.envelope.diagnostics)
                match = re.search(r'memory reservation denied: requested=(\d+), reserved=(\d+), limit=(\d+)', reason)
                assert match, reason
                requested, reserved, limit = map(int, match.groups())
                assert requested + reserved > limit == grant
                outcome = dict(outcome='reservation_denied', requested=requested, reserved=reserved, limit=limit)
            else:
                assert grant == 64 << 20
                outcome = dict(outcome='complete_values', report=report.envelope.raw)
            assert set(harness.output.iterdir()) == before
            assert all(not trace['opened'] or trace['closed'] for trace in traces)
            observed.append(dict(case, **outcome, traces=traces))
        finally:
            harness.client.close()
    assert load() == manifest
    save(root / 'summary.json', dict(status='passed', cases=observed,
        source=identity(SOURCE), artifacts=identity(MANIFEST), protocol=identity(root / 'protocol.json'),
        original_failure=identity(OUT / 'stream-dynamic-subquery-focused-519/summary.json'),
        runtime_sources_unchanged=True))
    print(json.dumps(dict(status='passed', cases=len(observed),
        denials=sum(case['outcome'] == 'reservation_denied' for case in observed),
        complete_values=sum(case['outcome'] == 'complete_values' for case in observed))))


if __name__ == '__main__':
    main()
