//! Bind data-dependent schemas inside the existing admitted native execution.

use super::super::{
    ArrayRef, BATCH_ROWS, DynamicLowerer, Metrics, NativeExecutionContext,
    PreparedVortexRelational, RefCell, add,
};
use super::{Binder, BoundUnary, Node, NodeKind, Result, VortexRelationalPlan, failed};
use crate::relational_query::{VortexRelationalDeferredRef, VortexRelationalExecutionRef};

pub(super) struct ExecutionBinding<'a> {
    owner: &'a PreparedVortexRelational,
    context: &'a NativeExecutionContext<'a>,
    metrics: &'a Metrics<'a>,
    parameter: Option<&'a ArrayRef>,
}

impl<'a> Binder<'a> {
    pub(in crate::local_primitives::prepared_relational) fn for_execution(
        owner: &'a PreparedVortexRelational,
        context: &'a NativeExecutionContext<'a>,
        metrics: &'a Metrics<'a>,
        parameter: Option<&'a ArrayRef>,
    ) -> Result<Self> {
        let mut binder = Self::new_with_cancellation(&owner.session, context.cancellation())?;
        for (source, path) in owner.sources.iter().zip(&owner.source_paths) {
            binder.charge(
                path.as_os_str()
                    .len()
                    .checked_mul(8)
                    .ok_or_else(|| failed("source path metadata overflow"))?,
            )?;
            binder.sources.push(source.clone())?;
            binder.paths.push(path.clone())?;
        }
        for (uri, source) in &owner.memory_sources {
            binder.register_memory_source(uri.clone(), |_| Ok(source.clone()))?;
        }
        for source in &owner.batch_sources {
            binder.register_batch_source(source.uri.clone(), |_| Ok(source.schema.clone()))?;
            binder.require_batch_usage(binder.batch_sources.values.len() - 1, source.usage)?;
        }
        binder.execution = Some(ExecutionBinding {
            owner,
            context,
            metrics,
            parameter,
        });
        if let Some(parameter) = parameter {
            let fields = parameter
                .dtype()
                .as_struct_fields_opt()
                .ok_or_else(|| failed("outer parameter must have a native struct schema"))?;
            binder.charge_fields(fields.names().len())?;
            binder.outer_fields = Some(
                fields
                    .names()
                    .iter()
                    .zip(fields.fields())
                    .map(|(name, dtype)| (name.to_string(), dtype))
                    .collect(),
            );
        }
        Ok(binder)
    }

    pub(super) fn require_batch_replay(&mut self, index: usize) -> Result<()> {
        self.require_batch_usage(index, super::super::batch_input::Usage::replay())
    }

    pub(super) fn require_batch_usage(
        &mut self,
        index: usize,
        usage: super::super::batch_input::Usage,
    ) -> Result<()> {
        self.cancellation.check()?;
        if let Some(execution) = &self.execution {
            execution
                .metrics
                .input
                .ok_or_else(|| {
                    super::super::batch_input::failed(
                        "streaming source roles have no input provider",
                    )
                })?
                .require_usage(index, usage)?;
        }
        self.batch_sources.values[index].usage.extend(usage);
        Ok(())
    }

    pub(in crate::local_primitives::prepared_relational) fn declare_source_reuse(
        &mut self,
        uri: &shardloom_core::DatasetUri,
    ) -> Result<()> {
        self.cancellation.check()?;
        if self.source_scope.is_some() {
            self.input(uri)?;
        }
        if let Some(index) = self
            .batch_sources
            .values
            .iter()
            .position(|source| &source.uri == uri)
        {
            return self.require_batch_replay(index);
        }
        if self
            .memory_sources
            .values
            .iter()
            .any(|(source, _)| source == uri)
        {
            return Ok(());
        }
        if uri.as_str().len() <= 16_384
            && let Some(path) = super::super::super::local_vortex_path(
                uri,
                super::VortexQueryPrimitiveKind::ProjectColumns,
            )?
            && self
                .paths
                .values
                .contains(&std::path::absolute(path).map_err(super::vortex_error)?)
        {
            return Ok(());
        }
        Err(super::super::batch_input::failed(
            "source reuse requires a registered source declaration",
        ))
    }

    pub(in crate::local_primitives::prepared_relational) fn defer_subquery(
        &mut self,
        declaration_bytes: usize,
        sources: Option<&[shardloom_core::DatasetUri]>,
        lower: Box<DynamicLowerer>,
    ) -> Result<VortexRelationalPlan> {
        if self.execution.is_none() || declaration_bytes == 0 {
            return Err(failed(
                "deferred subquery requires admitted execution and metadata credits",
            ));
        }
        if self.deferred.values.len() >= 128 {
            return Err(failed("dynamic execution exceeds 128 deferred relations"));
        }
        self.charge(declaration_bytes)?;
        let (sources, source_scope, source_metadata) = match sources {
            Some(sources) => {
                let declared = self.declared_subquery_sources(sources)?;
                (
                    Some(declared.identities),
                    Some(declared.scope),
                    Some(declared.metadata),
                )
            }
            None => (
                None,
                self.source_scope.clone(),
                self.source_metadata.clone(),
            ),
        };
        let slot = self.deferred.values.len();
        self.deferred.push(Some(super::super::DeferredRelation {
            lower,
            source_scope,
            source_metadata: source_metadata.clone(),
        }))?;
        Ok(VortexRelationalPlan::DeferredSubquery(
            VortexRelationalDeferredRef {
                scope: self.scope.clone(),
                slot,
                sources,
                _source_metadata: source_metadata,
            },
        ))
    }

    pub(super) fn take_deferred(
        &mut self,
        reference: &VortexRelationalDeferredRef,
    ) -> Result<super::super::DeferredRelation> {
        if self.execution.is_none() || !std::sync::Arc::ptr_eq(&self.scope, &reference.scope) {
            return Err(failed("deferred relation belongs to a different execution"));
        }
        self.deferred
            .values
            .get_mut(reference.slot)
            .and_then(Option::take)
            .ok_or_else(|| failed("deferred relation is absent or was consumed twice"))
    }

    pub(in crate::local_primitives::prepared_relational) fn resolve_output(
        &mut self,
        plan: &VortexRelationalPlan,
    ) -> Result<(VortexRelationalPlan, Vec<String>)> {
        if self.execution.is_none() {
            return Err(failed(
                "dynamic schema resolution requires an admitted execution",
            ));
        }
        let node = self.bind(plan, 0)?;
        self.charge_fields(node.fields.len())?;
        let columns = node.fields.iter().map(|(name, _)| name.clone()).collect();
        let slot = self.resolved.values.len();
        self.resolved.push(Some(node))?;
        Ok((
            VortexRelationalPlan::ExecutionResult(VortexRelationalExecutionRef {
                scope: self.scope.clone(),
                slot,
            }),
            columns,
        ))
    }

    pub(in crate::local_primitives::prepared_relational) fn ensure_consumed(&self) -> Result<()> {
        if self.resolved.values.iter().any(Option::is_some)
            || self.deferred.values.iter().any(Option::is_some)
        {
            return Err(failed(
                "dynamic schema binding left an unconsumed native relation",
            ));
        }
        Ok(())
    }

    pub(super) fn take_resolved(
        &mut self,
        reference: &VortexRelationalExecutionRef,
    ) -> Result<Node> {
        if self.parameterized_binding {
            return Err(failed(
                "completed relation cannot be reused across correlated parameters; defer its declaration",
            ));
        }
        if self.execution.is_none() || !std::sync::Arc::ptr_eq(&self.scope, &reference.scope) {
            return Err(failed(
                "native relation reference belongs to a different execution",
            ));
        }
        self.resolved
            .values
            .get_mut(reference.slot)
            .and_then(Option::take)
            .ok_or_else(|| failed("native relation reference is absent or was consumed twice"))
    }

    pub(super) fn complete_pivot(&mut self, input: &Node, operation: BoundUnary) -> Result<Node> {
        let execution = self
            .execution
            .as_ref()
            .ok_or_else(|| failed("composed pivot requires execution-time schema binding"))?;
        if self.parameterized_binding
            || self.outer_fields.is_some() && execution.parameter.is_none()
        {
            return Err(failed(
                "correlated dynamic pivot requires per-parameter schema binding",
            ));
        }
        let result = operation.complete_relation_pivot(
            execution.context,
            #[cfg(all(feature = "vortex-write", unix))]
            execution.metrics.spill.as_ref(),
            |consume| {
                execution.owner.run(
                    input,
                    execution.context,
                    execution.metrics,
                    BATCH_ROWS,
                    execution.parameter,
                    consume,
                )
            },
        )?;
        let usage = result.usage();
        execution
            .metrics
            .record_unary(usage.items, usage.all_input_retained)?;
        execution
            .metrics
            .record_pivot_spill(result.spill_report())?;
        add(&execution.metrics.schema_discovery_stages, 1)?;
        super::validate_width(result.fields().len())?;
        self.charge_fields(result.fields().len())?;
        for (name, dtype) in result.fields() {
            super::validate_name(name)?;
            super::validate_key(dtype)?;
        }
        super::validate_unique(result.fields())?;
        self.charge(std::mem::size_of::<
            RefCell<Option<super::super::CompletedPivot>>,
        >())?;
        Ok(Node {
            fields: result.fields().to_vec(),
            kind: NodeKind::CompletedPivot {
                rows: result.rows(),
                operation: Box::new(operation),
                result: Box::new(RefCell::new(Some(result))),
            },
        })
    }
}
