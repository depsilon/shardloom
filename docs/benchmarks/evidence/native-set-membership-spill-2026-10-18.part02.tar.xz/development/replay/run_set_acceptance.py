"""Run the frozen native set acceptance stages serially; preserve every failure."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PYTHON = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
BINDING_PYTHON = '/Users/dylan/LocalData/shardloom/native-python-surface-20261010/release-v0.6.0/local-package-release060-source-440/venv/bin/python'
GUARD = OUT / 'run_guarded.py'

def checked_source():
    source = json.loads((OUT / 'acceptance-source.json').read_text())
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    assert source['source_commit'] == head
    assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True) == ''
    for name, digest in source['source_hashes'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    return source

def run(name, command, timeout=1800):
    source = checked_source()
    path = OUT / (name + '.json')
    if path.exists():
        prior = json.loads(path.read_text())
        assert prior['status'] == 'passed', f'Failed evidence retained; select a new attempt: {path}'
        assert prior['command'] == command and prior['head'] == source['source_commit']
        assert prior['working_tree'] == '' and prior['process_group_drained']
        assert prior['log_sha256'] == hashlib.sha256((OUT / (name + '.log')).read_bytes()).hexdigest()
        print(json.dumps({'stage': name, 'status': 'verified_previous_pass'}), flush=True)
        return
    print(json.dumps({'stage': name, 'status': 'starting'}), flush=True)
    subprocess.run([PYTHON, '-B', str(GUARD), '--name', name, '--timeout', str(timeout), '--', *command],
                   cwd=ROOT, check=True)
    checked_source()

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('phase', choices=('gates', 'build', 'bindings', 'matrix', 'final'))
args = parser.parse_args()
source = checked_source()
repair = json.loads((OUT / 'set-native-family-repair-725.json').read_text())
assert repair['status'] == 'passed' and repair['head'] == source['source_commit']
assert repair['process_group_drained'] and repair['working_tree'] == ''
assert repair['log_sha256'] == hashlib.sha256((OUT / 'set-native-family-repair-725.log').read_bytes()).hexdigest()
cargo = ['cargo']
if args.phase == 'gates':
    for name, command in [
        ('set-workspace-fmt-725', cargo + ['fmt', '--all', '--', '--check']),
        ('set-native-vortex-tests-725', cargo + ['test', '--release', '--offline', '--locked', '-p', 'shardloom-vortex', '--features', 'release-user-surfaces', '--lib', '--', '--test-threads=1']),
        ('set-workspace-clippy-725', cargo + ['clippy', '--offline', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings']),
        ('set-workspace-tests-725', cargo + ['test', '--offline', '--locked', '--workspace', '--all-targets', '--', '--test-threads=1']),
        ('set-native-clippy-725', cargo + ['clippy', '--release', '--offline', '--locked', '-p', 'shardloom-vortex', '-p', 'shardloom-cli', '--all-targets', '--features', 'release-user-surfaces', '--', '-D', 'warnings']),
        ('set-native-cli-tests-725', cargo + ['test', '--offline', '--locked', '-p', 'shardloom-cli', '--lib', '--bin', 'shardloom', '--test', 'vortex_prepare', '--test', 'public_memory_inputs', '--test', 'public_workflow_route', '--test', 'resident_worker', '--features', 'release-user-surfaces', '--', '--test-threads=1']),
    ]:
        run(name, command)
elif args.phase == 'build':
    run('set-cli-build-725', cargo + ['build', '--offline', '--locked', '--release', '-p', 'shardloom-cli', '--features', 'release-user-surfaces'])
    run('set-binding-build-725', [PYTHON, '-B', 'scripts/build_native_python.py', '--output-dir', str(OUT / 'artifacts'), '--release', '--offline'])
    run('set-freeze-artifacts-725', [PYTHON, '-B', str(OUT / 'freeze_set_acceptance.py'), 'artifacts', '--cli-build', 'set-cli-build-725', '--binding-build', 'set-binding-build-725'], 300)
    run('set-freeze-plan-725', [PYTHON, '-B', str(OUT / 'freeze_set_acceptance.py'), 'plan'], 300)
elif args.phase == 'bindings':
    env = ['/usr/bin/env', 'SHARDLOOM_NATIVE_TEST_LIBRARY=' + str(OUT / 'artifacts/_native.abi3.so'), 'SHARDLOOM_REQUIRE_NATIVE_PYTHON=1', BINDING_PYTHON]
    run('set-direct-binding-tests-725', env + ['-m', 'unittest', 'discover', '-s', 'python/tests', '-p', 'test_native*binding.py', '-v'])
    run('set-public-context-tests-725', env + ['-m', 'unittest', 'discover', '-s', 'python/tests', '-p', 'test_public_context.py', '-v'], 300)
elif args.phase == 'matrix':
    plan = json.loads((OUT / 'acceptance-plan.json').read_text())
    run('set-input-verify-725', [PYTHON, '-B', str(OUT / 'verify_set_acceptance.py'), 'input'], 600)
    for family, timeout in [('public', 3600), ('full43', 1800), ('modular', 3600)]:
        name = 'set-' + family + '-725'
        run(name, plan['commands'][family], timeout)
        run('set-' + family + '-verify-725', [PYTHON, '-B', str(OUT / 'verify_set_acceptance.py'), family, '--receipt', name], 900)
else:
    run('set-final-verify-725', [PYTHON, '-B', str(OUT / 'verify_set_acceptance.py'), 'final'], 900)
    run('set-owner-acceptance-725', [PYTHON, '-B', str(OUT / 'finalize_set_acceptance.py')], 300)
print(json.dumps({'phase': args.phase, 'status': 'passed'}), flush=True)

