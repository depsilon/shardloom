"""Bind the acceptance build and unchanged runners to one committed source tree."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
ARTIFACTS = OUT / 'artifacts'
PYTHON = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
sys.path.insert(0, str(ROOT / 'scripts'))
from run_clickbench_query_uat import clickbench_harness_paths


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    path = Path(path)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}


def save(name, record):
    with (OUT / name).open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def sources():
    names = git('ls-files', '-co', '--exclude-standard', '-z').split('\0')
    selected = {name for name in names if name and (
        name.endswith('.rs') or Path(name).name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml')
        or (name.startswith(('python/', 'scripts/', 'benchmarks/')) and
            Path(name).suffix in ('.py', '.pyi', '.sh', '.sql', '.toml', '.json')))}
    return {name: digest(ROOT / name) for name in sorted(selected) if (ROOT / name).is_file()}


def source_record():
    record = json.loads((OUT / 'acceptance-source.json').read_text())
    assert record['source_commit'] == git('rev-parse', 'HEAD')
    assert record['working_tree'] == git('status', '--porcelain') == ''
    assert record['source_hashes'] == sources()
    return record


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('phase', choices=('source', 'plan'))
parser.add_argument('--cli-build')
parser.add_argument('--binding-build')
args = parser.parse_args()
if args.phase == 'source':
    assert git('status', '--porcelain') == ''
    current = sources()
    save('acceptance-source.json', {
        'schema_version': 'shardloom.set_membership.source.v1',
        'source_commit': git('rev-parse', 'HEAD'), 'working_tree': '',
        'source_hashes': current,
        'base_commit': git('rev-parse', '5829e71c'),
        'contract': identity(ROOT / 'docs/architecture/native-set-membership-spill-2026-10-18.md'),
        'scope': ['distinct_union_membership', 'intersect_membership', 'except_membership'],
        'generator': identity(__file__),
    })
else:
    source = source_record()
    build = json.loads((OUT / 'acceptance-build.json').read_text())
    from reuse_set_acceptance import verify_reuse
    verify_reuse()
    assert digest(build['binary']) == build['binary_sha256']
    assert identity(build['native_library']['path']) == build['native_library']
    previous = json.loads(Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010/fresh-uat663-plan.json').read_text())
    full43 = previous['commands']['full43'].copy()
    for option, value in {'--binary': build['binary'], '--build-commit': build['source_commit'],
                          '--uat-root': str(OUT / 'full43')}.items():
        full43[full43.index(option) + 1] = value
    families = ['input', 'growth', 'typed-input', 'ordering', 'ordering-pressure', 'aggregate',
        'aggregate-pressure', 'join', 'join-pressure', 'window', 'window-pressure', 'protocol',
        'preparation', 'multiple', 'multiple-pressure', 'dynamic', 'dynamic-pressure', 'replay',
        'replay-pressure', 'destinations', 'sets', 'sets-pressure', 'unary', 'unary-reference',
        'unary-composition', 'unary-fault', 'unary-pressure', 'subqueries', 'subqueries-composition',
        'subqueries-fault', 'subqueries-pressure', 'dynamic-subqueries', 'dynamic-subqueries-reference',
        'dynamic-subqueries-composition', 'dynamic-subqueries-fault', 'dynamic-subqueries-pressure']
    assert len(families) == 36
    modular = previous['commands']['modular'].copy()
    original_modular = Path(previous['modular_runner']['path'])
    assert identity(original_modular) == previous['modular_runner']
    local_modular = OUT / original_modular.name
    assert not local_modular.exists()
    shutil.copy2(original_modular, local_modular)
    assert digest(local_modular) == digest(original_modular)
    modular[modular.index(str(original_modular))] = str(local_modular)
    for option, value in {'--repo': str(ROOT), '--build-manifest': str(OUT / 'acceptance-build.json'),
                          '--prefix': 'set-membership', '--attempt': '726'}.items():
        modular[modular.index(option) + 1] = value
    public = [PYTHON, '-B', 'scripts/run_native_streaming_input_uat.py',
              '--binary', build['binary'], '--uat-root', str(OUT / 'public-36'),
              '--operation-timeout', '600', '--compress-logs', '--families', *families]
    assert identity(previous['reference']['path']) == previous['reference']
    schema_path = Path(previous['schema_sources'][0]['path'])
    assert identity(schema_path) == previous['schema_sources'][0]
    source_file = Path(previous['target'])
    stat = source_file.stat()
    assert stat.st_size == 15713610513 and stat.st_blocks * 512 >= stat.st_size
    assert not stat.st_flags & 0x40000000
    generation = dict(device=stat.st_dev, inode=stat.st_ino, size_bytes=stat.st_size,
                      mtime_ns=stat.st_mtime_ns, ctime_ns=stat.st_ctime_ns)
    # Full hashing belongs to preflight and post-run verification, outside query timing.
    save('acceptance-plan.json', {
        'status': 'predeclared', 'source': identity(OUT / 'acceptance-source.json'),
        'build': identity(OUT / 'acceptance-build.json'),
        'commands': {'public': public, 'full43': full43, 'modular': modular},
        'expected': {'public_families': 36, 'public_cases': 4911, 'queries': 43,
                     'calls': 43, 'query_result_rows': 381, 'modular_cohorts': 18,
                     'native_workflows': 704, 'pandas_oracle_workflows': 704},
        'input': {'path': str(source_file), 'bytes': stat.st_size,
                  'sha256': '06f70eb6f118d11e4a5226eb641225d708fdb4ac1b3f45942872d5ef5df4fc22',
                  'generation': generation, 'resident': True},
        'reference': previous['reference'], 'schema_sources': previous['schema_sources'],
        'query_source': identity(ROOT / 'benchmarks/clickbench/queries.sql'),
        'query_harness': [identity(path) for path in clickbench_harness_paths()],
        'public_runner': identity(ROOT / 'scripts/run_native_streaming_input_uat.py'),
        'modular_runner': identity(local_modular),
        'unchanged_original_modular_runner': identity(original_modular),
        'guard': identity(OUT / 'run_guarded.py'),
        'resource_limits_changed': False, 'reingested': False,
        'reference_kind': 'retained_native_regression', 'performance_claim': False,
        'engine_clock': 'sum of engine_execution_seconds for one execution of Q01 through Q43',
    })
print(json.dumps({'status': 'passed', 'phase': args.phase}))


