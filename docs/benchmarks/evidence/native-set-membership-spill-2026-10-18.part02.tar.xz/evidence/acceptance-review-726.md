# Primary acceptance review — distinct-set membership

Status: the final frozen acceptance verifier passed and produced
`perf-06-acceptance.json` for finite local scope. All 4,911 public checks, 74 new
value archives, complete Full43 results and 18 modular cohorts passed. The
remaining documentation/archive closeout does not close a broader roadmap owner.

1. **Run-reader and replay overlap.** The first implementation kept the default
   1,024-row run size and failed the original constrained native grant. The first
   repair bounded set ordering at 256 rows; direct binding then exposed the same
   enlargement in fanout replay. Commit `7a55bc7f` bounds both the fanout handoff
   and replay blocks. The new native regression runs all three set operations
   through all eight writers under the unchanged 16-MiB producer grant, checks
   every result, one execution, actual replay/runs and refunded ownership.
   All 16 focused family tests and the full native suite pass on that revision.

2. **Independent readback is a separate allocation boundary.** Python delivery
   slices do not configure the underlying native file admission. The original
   16-MiB and attempted 32-MiB independent readback failures remain evidence.
   The direct-binding test retains 16 MiB for set execution and writers, with a
   separately declared 128-MiB verification client for file reopening. Native
   fanout coverage also keeps its independent reference reader outside the
   constrained producer grant. No smaller native-file allocation is inferred
   from `batch_rows=127`.

3. **Early input completion does not complete an abandoned output.** The prior
   public test assumed a spill-enabled set always leaves a producer unfinished
   after its first output. Ordered membership must complete both inputs before
   output; that assumption was stale. Commit `7831657a` checks both resident and
   spill strategies, retaining the process-exit, retained-value, no-final-report
   and cleanup assertions. All 427 focused set checks pass. The earlier stopped
   1,082-case public attempt is retained and is not complete-suite evidence.

4. **Build and source identities remain distinct.** The new commit changes only
   `scripts/native_streaming_set_boundary_cases.py`. The reuse proof compares
   every frozen source, exact Git diff, Cargo inputs, executable/library hashes,
   clean original gate receipts and their log hashes. The original build record
   is copied verbatim, retaining compiled commit `7a55bc7f`; the acceptance
   source is `7831657a`. Full43 records the actual compiled commit and modular
   output separately records runtime and harness commits. Runtime tests are
   reused only through this explicit equality proof. All public, Full43 and
   modular acceptance is fresh at the corrected harness.

5. **Complete values and scope determine acceptance.** Final verification must
   reopen all 74 new complete-value archives against an independent numeric
   domain oracle, every Full43 result/schema/clock, and all 704 native workflows
   against 704 independent pandas oracle workflows. Pandas is a test oracle only.
   The public suite must pass all 4,911 cases, including 83 new membership cases
   and four additional early-close controls. Full43 is one regression observation,
   not a speed gate. Unary membership, masks, populations, subquery indexes,
   general resume and generation-conditional publication remain separate work.

6. **Gate counts and skips remain literal.** The broad native suite has 29 ignored
   opt-in screens. Direct binding has 102 passing tests without skips. The public
   context suite has 17 passes and one named installed-package skip, because its
   required clean installed-package mode is not enabled. These suites overlap;
   their counts cannot be summed into an independent workload count. Local source
   acceptance does not close hosted, installed-wheel, other-platform or release
   gates.

Primary source checks: native membership destination/fault/recovery tests,
`native_streaming_set_boundary_cases.py`, native Python file streaming and file
admission, replay batching, the architecture contract, and the complete source
reuse verifier. The final verifier and package manifest retain executable checks
for the required claims and all previous failed observations.
