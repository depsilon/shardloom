"""Assemble the finite set-membership acceptance record after all frozen gates pass."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
DEVELOPMENT = Path('/Users/dylan/LocalData/shardloom/native-set-pressure-20261018')

def read(path):
    return json.loads(Path(path).read_text())

def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}

def check(ref):
    assert identity(ref['path']) == ref, ref['path']

def save(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

acceptance = read(OUT / 'acceptance-final-verified.json')
assert acceptance['status'] == 'passed' and acceptance['finite_family_acceptance_complete']
assert acceptance['broader_membership_population_owner_complete'] is False
assert acceptance['broader_recovery_owner_complete'] is False
assert acceptance['performance_claim'] is False
source = read(OUT / 'acceptance-source.json')
assert acceptance['source_commit'] == source['source_commit']
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head == source['source_commit']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True) == ''
for name, digest in source['source_hashes'].items():
    assert identity(ROOT / name)['sha256'] == digest, name
for group in ('gates', 'development_evidence'):
    for record in acceptance[group].values():
        check(record['receipt'])
        check(record['log'])
for ref in acceptance['phase_reports'].values():
    check(ref)
checks = {}
for name in ('set-full-key-tests-723', 'set-typed-key-tests-723', 'set-nested-key-tests-723'):
    record = read(DEVELOPMENT / (name + '.json'))
    assert record['status'] == 'passed' and record['process_group_drained']
    assert record['log_sha256'] == identity(DEVELOPMENT / (name + '.log'))['sha256']
    checks[name] = {'receipt': identity(DEVELOPMENT / (name + '.json')), 'log': identity(DEVELOPMENT / (name + '.log'))}
# Focused runs used the preceding test binary; the clean-source full native
# suite repeats these selectors. Retain the focused runs as development proof.
record = {
    'schema_version': 'shardloom.native_set_membership_acceptance.v1',
    'status': 'accepted_finite_local_scope',
    'source_commit': source['source_commit'],
    'base_commit': source['base_commit'],
    'compiled_source_commit': acceptance['compiled_source_commit'],
    'source_reuse_bridge': acceptance['source_reuse_bridge'],
    'scope': ['UNION DISTINCT', 'INTERSECT', 'EXCEPT'],
    'sources': ['native_files', 'resident_native_memory', 'finite_streaming_batches'],
    'source_manifest': identity(OUT / 'acceptance-source.json'),
    'build': identity(OUT / 'acceptance-build.json'),
    'plan': identity(OUT / 'acceptance-plan.json'),
    'runtime_acceptance': identity(OUT / 'acceptance-final-verified.json'),
    'development_focused_checks': checks,
    'test_counts': acceptance['test_counts'],
    'public_families': acceptance['public_families'],
    'public_cases': acceptance['public_cases'],
    'new_public_set_cases': 87,
    'membership_pressure_cases': 83,
    'additional_early_close_controls': 4,
    'new_set_complete_value_archives': 74,
    'full43': {'queries': 43, 'executions_per_query': 1, 'complete_result_rows': 381,
               'engine_execution_seconds': acceptance['engine_execution_seconds'],
               'reference_kind': 'retained_native_regression', 'performance_claim': False},
    'modular_cohorts': 18, 'native_workflows': 704, 'fresh_independent_pandas_oracle_workflows': 704,
    'completed_substeps': [],
    'accepted_finite_scope_within': ['PERF-06.membership', 'PERF-06.recovery', 'PERF-06.strategy'],
    'broader_owners_closed': [],
    'cross_cutting_owners': ['PERF-01', 'PERF-03', 'PERF-07', 'PERF-11', 'PERF-12'],
    'all_cg_1_through_cg_23_requirements_preserved': True,
    'crash_recovery': 'exact_owned_cleanup_followed_by_fresh_execution',
    'interrupted_execution_resume': False,
    'strategy': 'full_key_and_input_ordinal_native_ordering_with_bounded_group_reduction',
    'internal_run_block_maximum_rows': 256,
    'fanout_output_replay_block_maximum_rows': 256,
    'direct_binding_set_grant_bytes': 16 << 20,
    'direct_binding_independent_file_verification_grant_bytes': 128 << 20,
    'python_delivery_batch_rows_is_native_scan_bound': False,
    'whole_process_memory_ceiling': False,
    'fallback_attempted': False,
    'external_engine_invoked_as_runtime': False,
    'release_version_changed': False,
    'publication_attempted': False,
    'platform_scope': 'local macOS Unix; release-user-surfaces feature build',
    'claim_gate_status': 'not_claim_grade',
    'unresolved': [
        'Unary distinct/deduplication/mask keys and future-mask identities remain separately resident.',
        'Sampling populations and subquery indexes retain their existing explicit pressure boundaries.',
        'This family restarts after owned cleanup; general interrupted-execution resume is not established.',
        'Existing destinations remain rejected before input demand; generation-conditional replacement remains PERF-07 work.',
        'Hosted installed-wheel, other-platform, release and competitive claims retain their independent gates.',
        'Python delivery batch_rows slices an admitted native batch; it does not bound file-reader or Arrow admission.',
        'Managed reservations do not impose a whole-process RSS ceiling.',
    ],
    'generator': identity(__file__),
}
save('perf-06-acceptance.json', record)
print(json.dumps({'status': record['status'], 'public_cases': record['public_cases'],
                  'engine_execution_seconds': record['full43']['engine_execution_seconds']}))


