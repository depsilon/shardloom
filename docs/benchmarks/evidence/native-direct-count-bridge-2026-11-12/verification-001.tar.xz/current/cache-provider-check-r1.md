# B: exact existing cache path

Source check at main 3a0608b12, before any B query observation or candidate.
The broad preparation notes described the generic owner's inline cache. For
this proposed single numeric key, the more precise path is the existing
integer directory in native_relational_key_cache.rs, not the inline composite
cache. KeyLookupCache::for_columns returns Directory::new for a single numeric
key and does not try the inline form if that directory declines.

Directory admission requires at least 64 rows and an integer range fitting
min(16,384, rows/4) slots, including NULL. It scans the native numeric owner for
the bounded range, charges its real slot capacity, and requires that capacity
to fit one sixteenth of remaining grant. Each published slot identity was first
proved by the ordinary exact index. On later visits the ordinary aggregate
still writes one group ordinal and performs one COUNT update per contributing
row. Wide ranges can decline the directory even when many keys repeat.

This refines the prospective hypothesis; it does not establish a saving.
The existing grouped-cost preparation scope includes directory construction;
group interning excludes that nested preparation time. The new debug diagnostic
retains both directory/inline counters and exact-index probes, so actual cache
activation remains observable. No diagnostic runtime adds per-row release hooks.

count_numeric_values already reads a same-width native slice, sorts key/count
pairs in place, performs checked run reduction and keeps its full input-row
capacity lease after truncation. It does not avoid key preparation automatically.
Constant reduction is a separate existing metadata-preserving entry point.
Any bridge must charge its partial, reduced-key output and overlapping native
state rather than reporting truncated logical length as released allocation.
