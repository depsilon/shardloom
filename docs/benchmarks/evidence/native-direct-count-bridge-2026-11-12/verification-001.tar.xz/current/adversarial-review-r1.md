# Fixed COUNT candidate review

The candidate remains inside the existing grouped-aggregate callback, group
index, state storage, and finalizer. Existing native file providers still win
their normal admission. Upstream arrays are prepared through the existing
numeric key provider; there is no new execution engine, public cast, source
adapter, output mode, or fallback path.

The main semantic objection is changed group insertion order. Binding enables
the partial only for an immediate Sort whose keys include the sole nonnullable
integer group key. That key is unique in the result, so its inclusion provides
a total order even after other sort keys. Unsorted output and incomplete tie
proofs retain ordinary consumption. Grouping expansion, additional measures,
distinct/filter/secondary measure semantics, nullable key/argument schemas, and
nullable parent arrays are excluded. Existing spill admission occurs first.
Input projections and producers still execute normally; a late producer failure
is not converted into successful completion. No callback is replayed after
membership or aggregate-state mutation.

The ownership objection is optional scratch displacing required provider work
or losing its charge when a result is shortened. Required native key preparation
precedes optional partial storage. Partial capacity retains its full lease after
truncation. Reduced keys use the existing host allocator, and wrapper/name
metadata retains its own credit through escaped array children. All optional
allocations finish before group mutation. Only recognized capacity denial may
decline; cancellation, provider errors, arithmetic errors, and unrelated
allocation errors propagate. Ordinary, typed compact, and generic compact
COUNT state all use checked weighted addition.

The proof objection is a primitive win being mistaken for a complete request
win. Debug-only counters and the 19 fixed diagnostic requests establish physical
work and refunds; they do not provide production performance scores. Release
scoring must include all 2,543 fixed complete requests and independent expected
outputs, including 160 no-COUNT neighbors and paths where this candidate is
ineligible. Original request/reference identities stay fixed. The 159 potential
reuses require exact complete packet admission. The source/build/runtime and
installed-wheel proof are frozen before either new scored role. Full output,
schema, resource, no-fallback and engine-clock replay precedes the binary gain
or loss disposition.

The nine new regression tests exercise the native integer/encoding boundary,
checked state representations, nullable/unique/tiny/empty refusal, denied
scratch and actual aligned allocation, retained child ownership, cancellation,
sort/tie admission, late producer failure, and unchanged ordered spill cleanup.
Public I32 scalar casts remain unsupported and are not included in the public
cohort. The prior frozen I32 draft was never executed or scored. All new row
counters are compiled only for debug tests; production has no new per-row
instrumentation.

No unresolved in-scope source issue was identified in this pass. This is source
review, not a substitute for the still-required build, complete results,
performance disposition, portable replay, hosted checks, and storage closeout.
