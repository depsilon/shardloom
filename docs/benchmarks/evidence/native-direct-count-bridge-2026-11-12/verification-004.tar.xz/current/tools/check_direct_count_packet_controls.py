"""Challenge the COUNT checkpoint without executing native or reference queries."""
from __future__ import annotations

import argparse
import copy
import gzip
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile

import verify_direct_count_packet as verifier

T = Path(__file__).resolve().parents[1]
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
RAW_CONTROLS = {'baseline_engine_total_invented', 'baseline_case_omitted', 'baseline_reuse_corrupted',
    'failed_status_reclassified', 'composition_identity_changed', 'composition_reference_changed',
    'baseline_launcher_changed', 'sum_schema_failure_erased', 'unsigned_sql_failure_erased'}
DIAGNOSTIC_CONTROLS = {'partial_work_corrupted', 'owner_release_denied', 'complete_attribution_corrupted'}
INSTALLED_CONTROLS = {'installed_skipped_test', 'installed_runtime_mismatch', 'installed_publication_claim'}


def put(data, name, value):
    data[name] = (json.dumps(value, indent=2) + '\n').encode()


def change(data, name, update):
    value = json.loads(data[name])
    update(value)
    put(data, name, value)


def rebind(row, raw):
    row['sha256'] = verifier.digest(raw)
    if 'generation' in row:
        row['generation']['bytes'] = len(raw)
    if 'bytes' in row:
        row['bytes'] = len(raw)


def change_selected_bound(data, key, update):
    protocol = json.loads(data['current/baseline-protocol-r1.json'])
    result = json.loads(data['current/baseline-verified-r1.json'])
    name = 'current/' + Path(protocol[key]['path']).name
    change(data, name, update)
    for record in (protocol, result):
        rebind(record[key], data[name])
    put(data, 'current/baseline-protocol-r1.json', protocol)
    rebind(result['protocol'], data['current/baseline-protocol-r1.json'])
    put(data, 'current/baseline-verified-r1.json', result)


def mutate(name, report, data):
    receipt = 'current/count-partial-native-tests-r2.json'
    if name == 'native_test_failure':
        change(data, receipt, lambda row: row.update(status='failed', returncode=101))
    elif name == 'undrained_native_process':
        change(data, receipt, lambda row: row.update(process_group_drained=False))
    elif name == 'mutable_source_validation':
        change(data, receipt, lambda row: row.update(fixed_source_validation=False, allow_lockfile_update=True))
    elif name in ('count_source_changed', 'root_lock_changed'):
        path = 'Cargo.lock' if name == 'root_lock_changed' else 'shardloom-vortex/src/local_primitives/native_relational_aggregate_count_partial.rs'
        data['source-blobs/' + report['candidate_source_snapshot'][path]['sha256']] += b'\ncorruption-control\n'
    elif name == 'required_test_missing_with_rebound_log':
        required = verifier.declaration(data['current/tools/direct_count_proof.py'], 'REQUIRED_TESTS')[0]
        log = 'current/count-partial-native-tests-r2.log'
        lines = data[log].splitlines(keepends=True)
        selected = [i for i,line in enumerate(lines) if line.startswith(b'test ') and line.endswith(('::' + required + ' ... ok\n').encode())]
        assert len(selected) == 1
        del lines[selected[0]]
        data[log] = b''.join(lines)
        change(data, receipt, lambda row: row.update(log_sha256=verifier.digest(data[log])))
        def adjust(row):
            for path in row['files']:
                if path.endswith('/count-partial-native-tests-r2.log'):
                    row['files'][path] = verifier.identity(data[log])
                elif path.endswith('/count-partial-native-tests-r2.json'):
                    row['files'][path] = verifier.identity(data[receipt])
        change(data, 'current/candidate-ci-inventory-r1.json', adjust)
    elif name == 'ignored_ci_policy_changed':
        key = 'source-blobs/' + report['candidate_source_snapshot'][verifier.CI_POLICY_PATH]['sha256']
        change(data, key, lambda row: row['ignored_tests'].append('ordinary::correctness_test'))
    elif name == 'actual_ci_inventory_changed':
        change(data, 'current/candidate-ci-inventory-r1.json', lambda row: row['partitions'][0]['tests'].pop())
    elif name == 'runtime_library_mismatch':
        def alter(row):
            next(item for item in row['files'] if Path(item['path']).name == 'lib_native.dylib')['sha256'] = '0' * 64
        change(data, 'current/runtime-r1-identity.json', alter)
    elif name in DIAGNOSTIC_CONTROLS:
        result_path = 'current/candidate-debug-attribution-r1-result.json'
        result = json.loads(data[result_path])
        entry = next(row for row in result['observations'] if 'repeat-memory' in row['case_id'])
        path = report['locations'][entry['observation']['path']]
        observed = json.loads(data[path])
        if name == 'partial_work_corrupted':
            observed['counts']['aggregate_count_partial_groups'] += 1
        elif name == 'owner_release_denied':
            observed['final_reserved_bytes'] = 1
        else:
            observed['actual_rows'].append(['invented'])
        put(data, path, observed)
        rebind(entry['observation'], data[path])
        put(data, result_path, result)
    elif name in INSTALLED_CONTROLS:
        def alter(row):
            if name == 'installed_skipped_test':
                row['integration']['skipped'] = 1
                put(data, 'current/installed-proof-r1/integration.json', row['integration'])
            elif name == 'installed_runtime_mismatch':
                row['integrity']['native_library_sha256'] = '0' * 64
            else:
                row['publication_attempted'] = True
        change(data, 'current/installed-proof-r1/report.json', alter)
    elif name == 'baseline_engine_total_invented':
        change(data, 'current/baseline-verified-r1.json', lambda row: row.update(engine_execution_seconds=1.0))
        report['baseline']['engine_execution_seconds'] = report['engine_execution_seconds'] = 1.0
    elif name == 'baseline_case_omitted':
        path = 'current/baseline-cases-r1.jsonl.gz'
        rows = gzip.decompress(data[path]).splitlines(keepends=True)
        assert len(rows) == 2543
        data[path] = gzip.compress(b''.join(rows[:-1]), mtime=0)
        change(data, 'current/baseline-verified-r1.json', lambda row: rebind(row['case_rows'], data[path]))
    elif name == 'baseline_reuse_corrupted':
        def alter(row):
            next(item for item in row['requests'] if item['reused'])['result']['engine_seconds'] += 1.0
        change_selected_bound(data, 'reuse', alter)
    elif name == 'failed_status_reclassified':
        path = 'current/baseline-cases-r1.jsonl.gz'
        rows = [json.loads(line) for line in gzip.decompress(data[path]).splitlines()]
        next(row for row in rows if row['result']['status'] == 'incorrect')['result']['status'] = 'passed'
        data[path] = gzip.compress(b''.join((json.dumps(row) + '\n').encode() for row in rows), mtime=0)
        change(data, 'current/baseline-verified-r1.json', lambda row: rebind(row['case_rows'], data[path]))
    elif name == 'candidate_execution_claim':
        report['scored_candidate_query_executions'] = 2543
    elif name == 'candidate_admission_claim':
        report['candidate_admitted'] = True
    elif name == 'investigation_complete_claim':
        report['investigation_b_complete'] = True
    elif name == 'restored_source_corrupted':
        change(data, 'current/source-restoration-r1/receipt.json', lambda row: row.update(source_after_sha256='0' * 64))
    elif name == 'proposal_patch_corrupted':
        data['current/candidate-proposal-r1.patch'] += b'corruption-control\n'
    elif name == 'original_failure_omitted':
        report['original_failed_checks'].pop()
    elif name == 'full10k_claim':
        report['complete_10k_performance_claim'] = True
    elif name == 'full43_claim':
        report['full43_claim'] = True
    elif name == 'composition_identity_changed':
        def alter(row):
            next(item for item in row['cases'] if item['kind'] == 'composition')['case']['case_identity'] = '0' * 64
        change_selected_bound(data, 'selection', alter)
    elif name == 'composition_reference_changed':
        path = 'current/references-r1/expectations.sqlite'
        connection = sqlite3.connect(':memory:')
        try:
            connection.deserialize(data[path])
            connection.execute("UPDATE expected SET identity=? WHERE id=(SELECT id FROM expected ORDER BY id LIMIT 1)", ('0' * 64,))
            connection.commit()
            data[path] = connection.serialize()
        finally:
            connection.close()
    elif name == 'baseline_launcher_changed':
        change(data, 'current/baseline-missing-r1.json', lambda row: row.update(command=['unbound-launcher']))
    elif name in ('sum_schema_failure_erased', 'unsigned_sql_failure_erased'):
        category = 'new_mixed_sum_declared_result_dtype' if name == 'sum_schema_failure_erased' else 'frozen_adapter_unsigned_sql_spelling'
        def alter(row):
            row['failures'] = [item for item in row['failures'] if item['category'] != category]
            row['failure_categories'].pop(category)
        change(data, 'current/baseline-admission-failure-r1.json', alter)
    else:
        raise AssertionError('unknown corruption: ' + name)


def child(packet_path, name):
    report, data = verifier.read_archive(packet_path)
    if name == 'archive_byte_changed':
        with tempfile.TemporaryDirectory(prefix='direct-count-control-archive-', dir=T) as temporary:
            clone = Path(temporary) / 'packet'
            shutil.copytree(packet_path, clone)
            path = clone / report['archives'][0]['path']
            raw = bytearray(path.read_bytes())
            raw[-1] ^= 1
            path.write_bytes(raw)
            try:
                verifier.read_archive(clone)
            except AssertionError:
                return dict(name=name, outcome='rejected', boundary='archive_identity')
        raise AssertionError('corrupted archive was accepted')
    report, data = copy.deepcopy(report), dict(data)
    mutate(name, report, data)
    boundary = 'source_runtime_claim_binding'
    try:
        if name in RAW_CONTROLS:
            boundary = 'complete_saved_result_replay'
            with tempfile.TemporaryDirectory(prefix='direct-count-control-replay-', dir=T) as temporary:
                verifier.replay_saved(report, data, Path(temporary))
        elif name in DIAGNOSTIC_CONTROLS:
            boundary = 'diagnostic_work_invariants'
            verifier.verify_diagnostics(verifier.Packet(report, data))
        elif name in INSTALLED_CONTROLS:
            boundary = 'installed_package_proof'
            runtime = {Path(row['path']).name:row for row in json.loads(data['current/runtime-r1-identity.json'])['files']}
            verifier.verify_installed(verifier.Packet(report, data), report['candidate_source_snapshot'], runtime)
        elif name in ('restored_source_corrupted', 'proposal_patch_corrupted'):
            boundary = 'exact_source_restoration'
            verifier.verify_restoration(verifier.Packet(report, data))
        elif name in ('ignored_ci_policy_changed', 'actual_ci_inventory_changed', 'required_test_missing_with_rebound_log'):
            boundary = 'exact_ci_inventory'
            verifier.verify_ci(verifier.Packet(report, data), report['candidate_source_snapshot'])
        else:
            verifier.verify_sources(report, data)
    except (AssertionError, KeyError, ValueError) as error:
        return dict(name=name, outcome='rejected', boundary=boundary, failure_type=type(error).__name__)
    raise AssertionError('corruption was accepted at ' + boundary + ': ' + name)


def invoke(command, name, log_root):
    result = subprocess.run(command, cwd=T, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
        capture_output=True, text=True, timeout=300, check=False)
    (log_root / (name + '.stdout.log')).write_text(result.stdout)
    (log_root / (name + '.stderr.log')).write_text(result.stderr)
    assert result.returncode == 0, (name, result.stderr[-2000:])
    return json.loads(result.stdout)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--packet', type=Path, required=True)
    parser.add_argument('--child', choices=sorted(verifier.CONTROL_NAMES))
    parser.add_argument('--execution-name')
    args = parser.parse_args()
    assert __debug__ and args.packet.resolve().is_relative_to(T)
    if args.child:
        print(json.dumps(child(args.packet, args.child), sort_keys=True))
        return
    assert args.execution_name and re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', args.execution_name)
    log_root = T / args.execution_name
    assert not log_root.exists()
    log_root.mkdir()
    report, data = verifier.read_archive(args.packet)
    assert data['current/tools/check_direct_count_packet_controls.py'] == Path(__file__).read_bytes()
    destination = args.packet / 'corruption-controls.json'
    assert not destination.exists()
    accepted = verifier.identity((args.packet / 'acceptance.json').read_bytes())
    first = invoke([sys.executable, '-B', str(args.packet / 'verify.py'), '--repo-root', str(W)], 'source-bound', log_root)
    assert first['status'] == 'passed_source_bound_replay' and first['query_executions'] == 0
    controls = [dict(name='source_bound', outcome='passed')]
    for name in sorted(verifier.CONTROL_NAMES):
        result = invoke([sys.executable, '-B', str(Path(__file__).resolve()), '--packet', str(args.packet), '--child', name], name, log_root)
        assert result['name'] == name and result['outcome'] == 'rejected'
        controls.append(result)
    with tempfile.TemporaryDirectory(prefix='direct-count-control-relocated-', dir=T) as temporary:
        clone = Path(temporary) / 'packet'
        shutil.copytree(args.packet, clone)
        last = invoke([sys.executable, '-B', str(clone / 'verify.py')], 'relocated', log_root)
        assert last == first
    controls.append(dict(name='relocated_source_only', outcome='passed'))
    assert verifier.identity((args.packet / 'acceptance.json').read_bytes()) == accepted
    observations = args.packet / 'control-observations'
    assert not observations.exists()
    shutil.copytree(log_root, observations)
    result = dict(status='passed', query_executions=0, positive_controls=2,
        rejected_corruptions=len(verifier.CONTROL_NAMES), controls=controls,
        acceptance_manifest=accepted, archives=report['archives'],
        sources={name: verifier.identity(data['current/tools/' + name])
            for name in ('verify_direct_count_packet.py', 'check_direct_count_packet_controls.py')},
        observations=[dict(path='control-observations/' + path.name, **verifier.identity(path.read_bytes()))
            for path in sorted(log_root.iterdir())])
    with destination.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status='passed', query_executions=0, positive_controls=2,
        rejected_corruptions=len(verifier.CONTROL_NAMES)), sort_keys=True))


if __name__ == '__main__':
    main()
