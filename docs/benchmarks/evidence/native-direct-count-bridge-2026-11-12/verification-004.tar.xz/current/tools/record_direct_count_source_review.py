"""Record completed COUNT source review before either scored role starts."""
import json
from pathlib import Path
import subprocess
import sys

OUT = Path('/Users/dylan/LocalData/shardloom/direct-count-bridge-2026-11-12')
sys.path.insert(0, str(OUT / 'tools'))
import direct_count_proof as proof
from direct_count_common import CLOSEOUT, W, content, digest, read, write

assert __debug__
assert not any((OUT / name).exists() for name in (
    'baseline-protocol-r1.json', 'candidate-protocol-r1.json',
    'baseline-missing-r1', 'candidate-r1'))
sources = proof.source_inventory()
accepted = read(CLOSEOUT)['repository_source_snapshot']
changes = {name: dict(before=accepted.get(name), after=sources.get(name))
    for name in sorted(set(accepted) | set(sources)) if accepted.get(name) != sources.get(name)}
assert changes and all(name == '.github/ci-native-baseline.json'
    or name.startswith('shardloom-vortex/src/') for name in changes)
report = dict(schema='shardloom.direct_count_source_review.v1',
    status='completed_pre_score_source_review',
    source_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip(),
    source_fingerprint_sha256=digest(sources), accepted_repository=content(CLOSEOUT),
    reviewed_changed_files=changes,
    runtime_objections_reviewed=['total_sort_and_source_order',
        'checked_count_and_producer_error_semantics',
        'optional_capacity_admission_and_owner_lifetimes',
        'complete_request_and_no_fallback_proof'],
    unresolved_in_scope_findings=[], scored_query_executions=0,
    candidate_protocol_absent_at_review=True,
    review_document=content(OUT / 'adversarial-review-r1.md'))
assert proof.source_inventory() == sources
write(OUT / 'pre-score-source-review-r1.json', report)
print(json.dumps(dict(status=report['status'], changed_files=len(changes),
    source_fingerprint_sha256=report['source_fingerprint_sha256'], scored_query_executions=0)))
