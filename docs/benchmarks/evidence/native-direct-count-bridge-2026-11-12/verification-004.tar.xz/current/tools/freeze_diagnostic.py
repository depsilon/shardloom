"""Bind a copied test executable to one successful guarded no-run build."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

OUT = Path(__file__).resolve().parents[1]


def identity(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        return dict(bytes=path.stat().st_size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest())


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--build', required=True)
parser.add_argument('--name', required=True)
parser.add_argument('--profile', required=True, choices=('debug', 'release'))
args = parser.parse_args()
assert __debug__ and args.name.replace('-', '').isalnum()
assert Path(args.build).name == args.build
receipt_path = OUT / args.build
receipt = json.loads(receipt_path.read_bytes())
assert receipt['status'] == 'passed' and receipt['returncode'] == 0
assert receipt['process_group_drained'] and receipt['fixed_source_validation']
command = ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-vortex', '--lib',
    '--features', 'release-user-surfaces', '--no-run', '--message-format=json']
if args.profile == 'release':
    command.insert(2, '--release')
assert receipt['command'] == command
root = Path(receipt['cwd'])
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == receipt['head']
paths = set()
for argv in (['git', 'ls-files', '--cached', '-z'], ['git', 'ls-files', '--others', '--exclude-standard', '-z']):
    paths.update(name for name in subprocess.check_output(argv, cwd=root).decode().split('\0')
        if name and '.git' not in Path(name).parts and not name.startswith((
            '.git/', 'docs/benchmarks/evidence/', 'docs/release/evidence/', 'docs/dependencies/evidence/')))
actual_sources = {}
for name in sorted(paths):
    path = root / name
    if path.is_symlink():
        target = os.readlink(path)
        actual_sources[name] = dict(symlink=target, sha256=hashlib.sha256(os.fsencode(target)).hexdigest())
    elif path.is_file():
        actual_sources[name] = identity(path)
    elif not path.exists():
        actual_sources[name] = dict(absent=True)
    else:
        actual_sources[name] = dict(other_mode=path.lstat().st_mode)
assert actual_sources == receipt['build_sources'], 'source changed since diagnostic build'
for phase in ('pre_execution', 'post_execution'):
    verification = receipt['build_source_verification'][phase]
    assert verification['head_matches'] and verification['path_set_matches']
    assert not verification['changed_paths']
    assert verification['fingerprint_sha256'] == receipt['build_source_fingerprint_sha256']
log = receipt_path.with_suffix('.log')
assert identity(log)['sha256'] == receipt['log_sha256']
artifacts = []
for line in log.read_text().splitlines():
    if not line.startswith('{'):
        continue
    message = json.loads(line)
    if message.get('reason') == 'compiler-artifact' and message.get('executable'):
        if message['target']['name'] == 'shardloom_vortex':
            assert message['profile']['test']
            artifacts.append(message)
assert len(artifacts) == 1
source = Path(artifacts[0]['executable'])
assert source.parent == Path(receipt['environment']['CARGO_TARGET_DIR']) / args.profile / 'deps'
expected = identity(source)
destination = OUT / args.name
assert not destination.exists()
destination.mkdir()
binary = destination / 'shardloom-vortex-diagnostic'
shutil.copy2(source, binary)
assert identity(binary) == identity(source) == expected
record = dict(schema_version='shardloom.direct_count_diagnostic_build.v1', status='passed',
    profile=args.profile, build_receipt=dict(path=str(receipt_path), **identity(receipt_path)),
    original_executable=str(source), binary=dict(path=str(binary), **expected),
    build_source_fingerprint_sha256=receipt['build_source_fingerprint_sha256'],
    build_head=receipt['head'], build_command=command,
    native_query_executions=0, scored_production_runtime=False)
with (OUT / (args.name + '-identity.json')).open('x') as stream:
    json.dump(record, stream, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps(record, sort_keys=True))
