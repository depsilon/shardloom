"""Literal bounded COUNT compositions and independent integer-loop references.

Declaration/data calculation only. No native runtime, build or query imports.
The Rust fixture independently constructs the same declared input population.
"""
from __future__ import annotations

from collections import OrderedDict


def dtype(name='int64', nullable=False):
    return dict(name=name, nullable=nullable, parameters=[])


def expr(op, *args, value=None, name='int64', nullable=False):
    return dict(op=op, args=list(args), value=value, dtype=dtype(name, nullable))


def column(name, nullable=False):
    return expr('column', value=name, nullable=nullable)


def node(op, args, schema, parent=None):
    return dict(op=op, args=args, schema=schema, inputs=[] if parent is None else [parent])


def declarations():
    specifications = [
        ('repeat-memory', 'memory', 65_537, 17, False, False, False, False, 'key_asc', None),
        ('repeat-batch-project', 'batch', 65_537, 17, False, False, True, True, 'count_desc_key_desc', 31),
        ('unique-batch', 'batch', 8_193, 10_007, False, False, False, False, 'key_asc', 31),
        ('tiny-source-order', 'batch', 3, 2, False, False, False, False, 'source', None),
        ('empty-batch', 'batch', 0, 17, False, False, False, False, 'key_asc', None),
        ('nullable-count-source-order', 'batch', 8_193, 17, False, True, False, False, 'source', None),
        ('nullable-key-memory', 'memory', 8_193, 17, True, False, False, False, 'key_asc', None),
        ('constant-key-batch', 'batch', 32_769, 1, False, False, False, False, 'count_desc_key_desc', 31),
    ]
    jobs = []
    for label, fmt, rows, domain, nullable_key, nullable_value, selected, projected, ordering, cap in specifications:
        schema = [['row_id', dtype()], ['g', dtype(nullable=nullable_key)], ['n', dtype(nullable=nullable_value)]]
        plan = node('scan', ['fact'], schema)
        if selected:
            lower = expr('ge', column('row_id'), expr('literal', value=117), name='bool')
            upper = expr('lt', column('row_id'), expr('literal', value=64_000), name='bool')
            plan = node('filter', [expr('and', lower, upper, name='bool')], schema, plan)
        if projected:
            assert not nullable_key and not nullable_value
            schema = [['g', dtype()], ['value', dtype()]]
            plan = node('project', [['g', column('g')], ['value', expr('add', column('n'), column('g'))]], schema, plan)
        measure = dict(function='count', argument=column('value' if projected else 'n', nullable_value), alias='m_count', dtype=dtype('uint64'))
        schema = [['g', dtype(nullable=nullable_key)], ['m_count', dtype('uint64')]]
        plan = node('aggregate', [['g'], [measure]], schema, plan)
        if ordering != 'source':
            keys = [dict(column='g', descending=ordering == 'count_desc_key_desc', nulls='last')]
            if ordering == 'count_desc_key_desc':
                keys.insert(0, dict(column='m_count', descending=True, nulls='last'))
            plan = node('sort', keys, schema, plan)
        if cap is not None:
            plan = node('limit', [cap, 0], schema, plan)

        # A straightforward reference over every selected row, independent of
        # the native group cache, hash index, aggregation and sorting providers.
        counts = OrderedDict()
        selected_rows = 0
        present_rows = 0
        for row in range(rows):
            if selected and not 117 <= row < 64_000:
                continue
            selected_rows += 1
            key = None if nullable_key and row % 13 == 0 else (row * 37 + 11) % domain
            value = None if nullable_value and row % 7 == 0 else row % 19 - 9
            if projected:
                value += key
            counts.setdefault(key, 0)
            if value is not None:
                counts[key] += 1
                present_rows += 1
        values = [dict(g=key, m_count=count) for key, count in counts.items()]
        if ordering == 'key_asc':
            values.sort(key=lambda item: (item['g'] is None, item['g'] or 0))
        elif ordering == 'count_desc_key_desc':
            values.sort(key=lambda item: (-item['m_count'], item['g'] is None, -(item['g'] or 0)))
        values = values if cap is None else values[:cap]
        jobs.append(dict(schema_version='shardloom.direct_count_diagnostic_job.v1',
            case_id='direct_count_diagnostic_v2_' + label,
            origin='versioned_native_composition_not_saved_case',
            source=dict(format=fmt, rows=rows, domain=domain, nullable_key=nullable_key,
                nullable_value=nullable_value, batch_rows=1021 if selected else 1024,
                memory_intake='existing_native_batch_builder_2048_rows' if fmt == 'memory' else None),
            relation=plan, expected_rows=values,
            expected_selected_rows=selected_rows, expected_count_contributions=present_rows,
            expected_complete_groups=len(counts), reference='independent_complete_integer_loop'))
    assert len(jobs) == 8 and len({job['case_id'] for job in jobs}) == 8
    return jobs
