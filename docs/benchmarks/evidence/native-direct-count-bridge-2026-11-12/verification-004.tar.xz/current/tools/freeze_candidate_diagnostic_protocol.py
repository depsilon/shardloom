"""Freeze one debug-only work/ownership observation of the fixed COUNT candidate."""
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parents[1]


def content(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        return dict(bytes=path.stat().st_size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest())


def bound(path):
    return dict(path=str(path), **content(path))


def read(path):
    return json.loads(path.read_bytes())


def main():
    assert __debug__ and OUT == Path('/Users/dylan/LocalData/shardloom/direct-count-bridge-2026-11-12')
    destination = OUT / 'diagnostic-protocol-candidate-debug-r1.json'
    assert not destination.exists()
    identity_path = OUT / 'diagnostic-candidate-debug-r1-identity.json'
    build = read(identity_path)
    assert build['status'] == 'passed' and build['profile'] == 'debug'
    receipt_path = Path(build['build_receipt']['path'])
    assert bound(receipt_path) == build['build_receipt']
    receipt = read(receipt_path)
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['fixed_source_validation']
    assert receipt['build_source_fingerprint_sha256'] == build['build_source_fingerprint_sha256']
    assert content(Path(build['binary']['path'])) == {key: build['binary'][key] for key in ('bytes', 'sha256')}
    declaration = OUT / 'diagnostic-declarations-r3.json'
    assert read(declaration)['status'] == 'frozen' and read(declaration)['total_requests'] == 19
    feasibility = OUT / 'feasibility-attribution-r1.json'
    assert read(feasibility)['status'] == 'passed' and not read(feasibility)['production_performance_result']
    baseline = OUT / 'debug-attribution-r5-result.json'
    assert read(baseline)['status'] == 'passed'
    runner = OUT / 'tools/run_candidate_diagnostics.py'
    result = dict(schema_version='shardloom.direct_count_diagnostic_protocol.v1', status='frozen',
        profile='debug', run_name='candidate-debug-attribution-r1', scored=False,
        iterations_per_request=1, per_request_deadline_seconds=240,
        declarations=bound(declaration), build_identity=bound(identity_path), binary=build['binary'],
        source_fingerprint_sha256=build['build_source_fingerprint_sha256'], build_head=build['build_head'],
        purpose='fixed_candidate_debug_work_and_ownership', production_engine_timing_claim=False,
        public_surface_conformance_claim=False, candidate_selected=True,
        complete_cohort_decision=False, baseline_result=bound(baseline), feasibility=bound(feasibility),
        candidate_design=bound(OUT / 'candidate-design-r1.md'), runner=bound(runner),
        warmups=0, repeats=0, cache_manipulation=False,
        worker_state='all leaf work complete and every other task-owned job idle during queries',
        input_hashing='before first query and after final query only',
        active_output=str(OUT / 'candidate-debug-attribution-r1'))
    with destination.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps(dict(status='frozen', profile='debug', requests=19, scored=False,
        source_fingerprint_sha256=build['build_source_fingerprint_sha256'])))


if __name__ == '__main__':
    main()
