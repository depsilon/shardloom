"""Authored literal answers, schema and declaration controls without execution."""
import copy
import hashlib
import json
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parents[1]
FROZEN = Path('/Users/dylan/LocalData/shardloom/expanded-query-2026-11-03/investigation-original-harness-r1')
sys.path[:0] = [str(OUT / 'client'), str(FROZEN / 'python/src'),
    str(FROZEN / 'benchmarks/traditional_analytics')]
import direct_count_cases as declarations
from query_surface.adapters import relation_sql
from query_surface.semantics import compare, result_from_record, result_record


def identity(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    assert __debug__ and OUT == Path('/Users/dylan/LocalData/shardloom/direct-count-bridge-2026-11-12')
    cases = declarations.declarations()
    assert len(cases) == 285
    for case in cases:
        plan = declarations.validate(case)
        sql = relation_sql(plan, {'fact': [Path('/native-input/fact.parquet')]})
        assert 'COUNT(' in sql and 'INT32' not in sql and plan.sources() == {'fact'}
        assert len(plan.schema) == len({name for name, _ in plan.schema})
    facts = [dict(zip(declarations.INPUT_COLUMNS, values)) for values in (
        (97, 1, 20, -8, None), (0, 2, 10, 4, 7), (3, 1, 30, 9, -1),
        (1, 3, 20, -1000, 7), (2, 1, 10, 1000, None))]
    expected = {
        'int64_star': [dict(k=1, n=3), dict(k=2, n=1), dict(k=3, n=1)],
        'int64_column': [dict(k=1, n=3), dict(k=3, n=1), dict(k=2, n=1)],
        'int64_constant': [dict(k=7, n=5)],
        'int64_unique': [dict(k=key, n=1) for key in (0, 1, 2, 3, 97)],
        'int64_sparse_expression': [dict(k=6, n=1), dict(k=1, n=1)],
        'empty': [],
        'tiny': [dict(k=3, n=1), dict(k=2, n=1), dict(k=1, n=1)],
        'one': [dict(k=2, n=1)],
        'nullable_argument': [dict(k=3, n=1), dict(k=2, n=1), dict(k=1, n=1)],
        'nullable_key': [dict(k=7, n=2), dict(k=-1, n=1), dict(k=None, n=2)],
        'source_order': [dict(k=1, n=3), dict(k=2, n=1), dict(k=3, n=1)],
        'mixed_measure': [dict(k=1, n=3, total=1001), dict(k=2, n=1, total=4), dict(k=3, n=1, total=-1000)],
        'multiple_keys': [dict(k=3, k2=1, n=1), dict(k=2, k2=0, n=1), dict(k=1, k2=3, n=1), dict(k=1, k2=2, n=2)],
        'medium_key': [dict(k=20, n=2), dict(k=10, n=2), dict(k=30, n=1)],
    }
    for name, rows in list(expected.items()):
        if name.startswith('int64_'):
            expected[name.replace('int64_', 'uint64_', 1)] = rows
    assert len(expected) == 19
    answers, count = declarations.reference_grid(iter(facts))
    reversed_answers, reversed_count = declarations.reference_grid(reversed(facts))
    assert count == reversed_count == len(facts) == 5
    for case in cases:
        name = case['declaration']['scenario']['name']
        actual = answers[name]
        assert actual.rows == expected[name], name
        contract = declarations.contract(case)
        compare(actual, reversed_answers[name], contract)
        compare(actual, result_from_record(result_record(actual)), contract)
    empty_answers, count = declarations.reference_grid(iter(()))
    assert count == 0 and all(row.rows == [] for row in empty_answers.values())

    refused = []

    def refuse(label, action):
        try:
            action()
        except (ValueError, KeyError):
            refused.append(label)
        else:
            raise AssertionError('malformed declaration/reference accepted: ' + label)

    for key, value in (('id', 'changed'), ('surface', 'unknown'), ('profile', 'unknown'),
            ('native_format', 'unknown'), ('direct_count_version', True),
            ('family', 'different'), ('archetype', 'different'), ('surrogate', 'changed')):
        changed = copy.deepcopy(cases[0])
        changed[key] = value
        refuse('case_' + key, lambda: declarations.validate(changed))
    for key, value in (('relation_sha256', '0' * 64), ('output_schema', []),
            ('ordered', False), ('version', True), ('profile', 'unknown')):
        changed = copy.deepcopy(cases[0])
        changed['declaration'][key] = value
        changed['case_identity'] = declarations.digest(changed['declaration'])
        changed['id'] = changed['id'].rsplit('_', 1)[0] + '_' + changed['case_identity'][:12]
        if key == 'profile':
            changed[key] = value
        refuse('declaration_' + key, lambda: declarations.validate(changed))
    changed = copy.deepcopy(cases[0])
    changed['declaration']['scenario']['limit'] = 5000
    refuse('unknown_scenario', lambda: declarations.validate(changed))
    for key, value in (('row_id', -1), ('group_key', None), ('signed_value', 1001)):
        changed = dict(facts[1], **{key: value})
        refuse('reference_' + key, lambda: declarations.reference_grid(iter([changed])))
    assert len(refused) == 17
    assert not any(name == 'shardloom._native' or name.startswith('_polars_runtime') for name in sys.modules)
    files = [Path(__file__), OUT / 'client/direct_count_cases.py']
    result = dict(status='passed_declaration_and_literal_reference_controls',
        cases=len(cases), scenarios=19, literal_rows=5, complete_literal_outputs_verified=19,
        empty_outputs_verified=19, reversed_inputs_verified=True, refusal_controls=refused,
        query_executions=0, native_runtime_loaded=False,
        sources={str(path): identity(path) for path in files})
    with (OUT / 'declaration-controls-r2.json').open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({key: result[key] for key in ('status', 'cases', 'scenarios', 'query_executions')}))


if __name__ == '__main__':
    main()
