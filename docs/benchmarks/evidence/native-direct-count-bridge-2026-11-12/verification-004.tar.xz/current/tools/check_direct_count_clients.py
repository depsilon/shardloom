"""Build all public declarations with nonexistent paths; execute no query."""
import json
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(OUT / 'tools'))
import direct_count_common as common
from direct_count_common import CLIENT, CLOSEOUT, E, FROZEN, J, T, content, read, worker, write
from query_surface.adapters import relation_dataframe, relation_native, relation_sql
from query_surface.worker import load_native
import shardloom as sl


def main():
    assert __debug__ and OUT == Path('/Users/dylan/LocalData/shardloom/direct-count-bridge-2026-11-12')
    destination = OUT / 'client-check-r1.json'
    assert not destination.exists()
    controls_path = OUT / 'declaration-controls-r2.json'
    controls = read(controls_path)
    assert controls['status'] == 'passed_declaration_and_literal_reference_controls'
    assert controls['cases'] == 285 and controls['scenarios'] == 19
    assert len(controls['refusal_controls']) == 17
    assert controls['query_executions'] == 0 and not controls['native_runtime_loaded']
    sources = {Path(name) for name in controls['sources']}
    for name, expected in controls['sources'].items():
        assert content(Path(name)) == expected
    reader = OUT / 'tools/direct_count_reference_inputs.py'
    old_reader = J / 'tools/join_mapping_reference_inputs.py'
    assert reader.read_bytes() == old_reader.read_bytes()
    reader_path = J / 'reference-reader-controls-r1.json'
    reader_controls = read(reader_path)
    assert reader_controls['status'] == 'passed_draft_real_ipc_reference_transport'
    assert reader_controls['native_query_executions'] == 0 and not reader_controls['native_runtime_loaded']
    assert reader_controls['source_fixture_removed'] and not reader_controls['comparison_engine_loaded']
    for name, expected in reader_controls['sources'].items():
        path = Path(name) if Path(name).is_absolute() else J / name
        assert content(path) == expected
        sources.add(path)
    assert set(row['layout'] for row in reader_controls['records']) == {'sorted', 'shuffled'}
    assert all(row['source_rows'] == 29 and row['files_unchanged'] for row in reader_controls['records'])
    runtime, closed = common.accepted_runtime()
    sources.update([Path(__file__), Path(common.__file__), Path(worker.__file__),
        Path(worker.declarations.__file__), reader, old_reader, reader_path, controls_path,
        CLOSEOUT, T / 'shared-window-closeout-r1.json', T / 'candidate-protocol-r1.json',
        E / 'frozen.json', *(Path(item['path']) for item in runtime.values())])
    frozen = read(E / 'frozen.json')['harness']
    prefix = '/Users/dylan/.codex/worktrees/native-post-110-optimization/shardloom-local-repo/'
    assert len(frozen) == 65
    for item in frozen:
        assert item['path'].startswith(prefix)
        path = FROZEN / item['path'].removeprefix(prefix)
        assert content(path) == dict(bytes=item['generation']['bytes'], sha256=item['sha256'])
        sources.add(path)
    for module in tuple(sys.modules.values()):
        name = getattr(module, '__file__', None)
        if name:
            path = Path(name).resolve()
            if path.suffix == '.py' and path.is_relative_to(OUT.parent):
                sources.add(path)
    before = {str(path): content(path) for path in sorted(sources)}
    result = dict(status='failed', declarations=0, query_executions=0,
        native_library_loaded=True, client_backend_created=False, worker_process_started=False,
        source_bindings_unchanged=False, frozen_client_files=65,
        declaration_controls=dict(path=str(controls_path), **content(controls_path)),
        reference_reader_controls=dict(path=str(reader_path), **content(reader_path)),
        reference_transport_reused_byte_exact=True,
        accepted_runtime_source_fingerprint_sha256=closed['source_fingerprint_sha256'],
        public_i32_cast_coverage=False,
        i32_boundary='Native batch/primitive/dictionary/chunk/constant integration tests cover I32; frozen public data has no I32 column and public scalar I32 casts are unsupported. No cast capability is added.',
        sources=before)
    client = None
    try:
        native = load_native(Path(runtime['library']['path']))
        client = sl.ShardLoomClient(binary=runtime['binary']['path'], transport='native',
            use_persistent_worker=False, memory_bytes=1 << 30, max_parallelism=1, timeout=60)
        cases = worker.declarations.declarations()
        assert len(cases) == 285
        for case in cases:
            plan = worker.declarations.validate(case)
            suffix = {'parquet': '.parquet', 'vortex': '.vortex', 'arrow-ipc': '.arrow'}[case['native_format']]
            inputs = {'fact': ['/declared-only/fact' + suffix]}
            sql = relation_sql(plan, inputs)
            assert isinstance(sql, str) and 'COUNT(' in sql
            assert type(relation_native(plan, inputs, native)) is native.Relation
            frame = relation_dataframe(plan, inputs, sl, client)
            assert frame.client is client and client._native_backend is None
            assert client._worker_process is None and not client._active_processes
        result.update(status='passed_public_declaration_construction', declarations=len(cases),
            construction_surfaces=['sql', 'typed_relation', 'dataframe'])
    except BaseException as error:
        result['error'] = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        if client is not None:
            client.close()
            assert client._native_backend is None and client._worker_process is None and not client._active_processes
        changed = [name for name, expected in before.items() if content(Path(name)) != expected]
        result['source_bindings_unchanged'] = not changed
        if changed:
            result.update(status='failed', changed_sources=changed)
        write(destination, result)
        assert not changed
    print(json.dumps({key: result[key] for key in ('status', 'declarations', 'query_executions')}))


if __name__ == '__main__':
    main()
