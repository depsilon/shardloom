"""Admit the fixed COUNT candidate only with complete local/runtime proof."""
import copy
import json
from pathlib import Path

import direct_count_proof as proof
from direct_count_common import J, OUT, W, content, digest, read, write
from query_surface.evidence import identity
from query_surface.expanded_run import verify

PYTHON = proof.PYTHON
RUNTIME = OUT / 'runtime-r1'


def validate_observation(observed, old):
    for key in ('job', 'actual_rows', 'actual_schema', 'shared_aggregate',
            'provider_selection_reason', 'producer_calls', 'producer_ended',
            'producer_consumed_rows', 'scan_rows_delivered', 'source'):
        assert observed[key] == old[key], key
    assert observed['actual_rows'] == observed['job']['expected_rows']
    assert observed['debug_work_observation'] and observed['native_io_certified']
    assert not observed['fallback_attempted'] and not observed['external_engine_invoked']
    assert observed['final_reserved_bytes'] == observed['denied_reservations'] == 0
    assert 0 <= observed['after_prepared_reserved_bytes'] <= observed['after_result_reserved_bytes']
    if observed['job']['source']['format'] != 'vortex':
        assert observed['after_result_reserved_bytes'] == observed['initial_reserved_bytes']
        assert observed['retained_source_count'] == observed['after_prepared_reserved_bytes'] == 0
    else:
        assert observed['retained_source_count'] == 1
    assert observed['peak_reserved_bytes'] <= observed['memory_grant_bytes'] == 2 << 30
    counts, before = observed['counts'], old['counts']
    for key in ('aggregate_count_partial_input_rows', 'aggregate_count_partial_groups',
            'aggregate_count_partial_batches', 'aggregate_count_partial_capacity_declines'):
        assert type(counts[key]) is int and counts[key] >= 0
    removed = counts['aggregate_count_partial_input_rows'] - counts['aggregate_count_partial_groups']
    assert removed >= 0
    assert counts['aggregate_count_contributions'] == before['aggregate_count_contributions']
    assert counts['aggregate_count_updates'] == before['aggregate_count_updates'] - removed
    assert counts['group_ordinal_rows'] == before['group_ordinal_rows'] - removed
    assert counts['group_input_batches'] == before['group_input_batches']
    assert counts['aggregate_count_partial_capacity_declines'] == 0
    keys = counts['membership_key_preparations']
    assert len(keys) == counts['group_input_batches']
    assert sum(key['rows'] for key in keys) == counts['group_ordinal_rows']
    assert all(key['numeric'] for key in keys)
    if not observed['shared_aggregate']:
        assert counts['group_ordinal_rows'] == counts['aggregate_count_contributions'] == 0
        assert counts['aggregate_count_partial_batches'] == 0
    return removed


def diagnostics(sources):
    protocol_path = OUT / 'diagnostic-protocol-candidate-debug-r1.json'
    result_path = OUT / 'candidate-debug-attribution-r1-result.json'
    protocol, result = read(protocol_path), read(result_path)
    assert protocol['source_fingerprint_sha256'] == digest(sources)
    assert protocol['candidate_selected'] and not protocol['scored']
    assert result['status'] == 'passed' and result['before_inputs_verified'] and result['after_inputs_verified']
    assert not result['performance_result'] and result['profile'] == 'debug'
    assert result['protocol'] == dict(path=str(protocol_path), **content(protocol_path))
    record, _ = proof.guarded(OUT / 'candidate-debug-attribution-r1.json',
        [PYTHON, '-B', str(OUT / 'tools/run_candidate_diagnostics.py'),
            '--protocol', protocol_path.name, '--name', 'candidate-debug-attribution-r1'], sources, query=True)
    assert record['active_output'] == str(OUT / 'candidate-debug-attribution-r1')
    declaration = read(Path(protocol['declarations']['path']))
    baseline = read(OUT / 'debug-attribution-r5-result.json')
    old_rows = {row['case_id']: row for row in baseline['observations']}
    assert [row['case_id'] for row in result['observations']] == [row['case_id'] for row in declaration['jobs']]
    assert len(result['observations']) == len(old_rows) == 19
    files = [protocol_path, result_path, OUT / 'candidate-debug-attribution-r1.json',
        OUT / 'candidate-debug-attribution-r1.log', OUT / 'tools/run_candidate_diagnostics.py',
        OUT / 'tools/freeze_candidate_diagnostic_protocol.py', OUT / 'feasibility-attribution-r1.json',
        OUT / 'debug-attribution-r5-result.json', Path(protocol['declarations']['path'])]
    reductions, samples = [], []
    for entry in result['observations']:
        assert entry['status'] == 'passed' and entry['returncode'] == 0 and entry['child_completed']
        path, old_path = Path(entry['observation']['path']), Path(old_rows[entry['case_id']]['observation']['path'])
        assert dict(path=str(path), **content(path)) == entry['observation']
        assert dict(path=str(old_path), **content(old_path)) == entry['baseline_observation']
        observed, old = read(path), read(old_path)
        removed = validate_observation(observed, old)
        assert removed == entry['removed_ordinal_rows_and_count_updates']
        if 'repeat-memory' in entry['case_id'] or 'constant-key-batch' in entry['case_id']:
            assert removed > 0 and observed['counts']['aggregate_count_partial_batches'] > 0
        log = Path(entry['log'])
        assert content(log) == entry['log_identity']
        messages = [line.split('DIRECT_COUNT ', 1)[1] for line in log.read_text().splitlines() if 'DIRECT_COUNT ' in line]
        assert len(messages) == 1 and json.loads(messages[0]) == observed
        files.extend((path, old_path, log))
        reductions.append(dict(case_id=entry['case_id'], removed_updates=removed,
            input_rows=observed['counts']['aggregate_count_partial_input_rows'],
            partial_groups=observed['counts']['aggregate_count_partial_groups']))
        if removed:
            samples.append((observed, old))
    assert samples
    refused = []
    for label, mutate in (
        ('missing_complete_row', lambda row: row['actual_rows'].pop()),
        ('changed_schema', lambda row: row.__setitem__('actual_schema', {})),
        ('leaked_owner', lambda row: row.__setitem__('final_reserved_bytes', 1)),
        ('hidden_fallback', lambda row: row.__setitem__('fallback_attempted', True)),
        ('wrong_contribution', lambda row: row['counts'].__setitem__('aggregate_count_contributions', 0)),
        ('false_work_reduction', lambda row: row['counts'].__setitem__('aggregate_count_updates', 0)),
        ('boolean_count', lambda row: row['counts'].__setitem__('aggregate_count_partial_batches', True)),
        ('changed_input_consumption', lambda row: row.__setitem__('producer_consumed_rows', -1)),
    ):
        observed, old = samples[0]
        changed = copy.deepcopy(observed)
        mutate(changed)
        try:
            validate_observation(changed, old)
        except AssertionError:
            refused.append(label)
        else:
            raise AssertionError('invalid diagnostic accepted: ' + label)
    return files, reductions, refused


def main():
    assert __debug__ and Path(__file__).resolve() == OUT / 'tools/verify_direct_count_candidate.py'
    sources = proof.source_inventory()
    files, checks = [Path(__file__), Path(proof.__file__)], {}
    for name, (stem, command) in proof.CHECKS.items():
        path = OUT / (stem + '.json')
        _, log = proof.guarded(path, command, sources)
        checks[name] = dict(receipt=identity(path), result=proof.test_results(log) if name.endswith('tests') else 'passed')
        if name == 'native_tests':
            for required in proof.REQUIRED_TESTS:
                assert len([line for line in log.splitlines() if line.endswith('::' + required + ' ... ok')]) == 1
        files.extend((path, path.with_suffix('.log')))
    ci_path = OUT / 'candidate-ci-inventory-r1.json'
    ci = read(ci_path)
    assert ci['status'] == 'passed_actual_native_inventory'
    assert ci['source_fingerprint_sha256'] == digest(sources) and ci['test_count'] == 4144
    assert ci['exact_ignored_ownership'] and len(ci['ignored']) == 36 and ci['query_executions'] == 0
    assert ci['ignored'] == read(W / '.github/ci-native-baseline.json')['ignored_tests']
    files.append(ci_path)
    for name, expected in ci['files'].items():
        assert content(Path(name)) == expected
        files.append(Path(name))
    more, reductions, rejected = diagnostics(sources)
    files.extend(more)
    build_path = OUT / 'candidate-release-build-r1.json'
    build, _ = proof.guarded(build_path, proof.BUILD_COMMAND, sources)
    files.extend((build_path, build_path.with_suffix('.log')))
    frozen_path = OUT / 'runtime-r1-identity.json'
    frozen = read(frozen_path)
    assert frozen['status'] == 'passed' and frozen['profile'] == 'release'
    assert frozen['build_receipt'] == build_path.name and frozen['build_receipt_identity'] == content(build_path)
    assert frozen['build_source_fingerprint_sha256'] == digest(sources)
    assert frozen['native_query_executions'] == 0
    assert {Path(row['path']).name for row in frozen['files']} == {'shardloom', 'lib_native.dylib', '_native.abi3.so'}
    for row in frozen['files']:
        assert Path(row['path']).parent == RUNTIME and content(Path(row['path'])) == {key:row[key] for key in ('bytes', 'sha256')}
        files.append(Path(row['path']))
    assert content(RUNTIME / 'lib_native.dylib') == content(RUNTIME / '_native.abi3.so')
    files.extend((frozen_path, OUT / 'tools/freeze_runtime.py'))
    for stem, command in {
        'candidate-debug-freeze-r1': [PYTHON, '-B', str(OUT / 'tools/freeze_diagnostic.py'),
            '--build', 'candidate-debug-build-r1.json', '--name', 'diagnostic-candidate-debug-r1', '--profile', 'debug'],
        'candidate-ci-verification-r1': [PYTHON, '-B', str(OUT / 'tools/verify_direct_count_ci_inventory.py'),
            '--build', str(OUT / 'candidate-debug-build-r1.json'), '--output', str(ci_path)],
        'candidate-diagnostic-protocol-freeze-r1': [PYTHON, '-B', str(OUT / 'tools/freeze_candidate_diagnostic_protocol.py')],
        'candidate-freeze-runtime-r1': [PYTHON, '-B', str(OUT / 'tools/freeze_runtime.py'),
            '--build', 'candidate-release-build-r1.json', '--name', 'runtime-r1', '--profile', 'release'],
    }.items():
        path = OUT / (stem + '.json')
        proof.guarded(path, command, sources)
        files.extend((path, path.with_suffix('.log')))
    files.extend(installed_proof(sources))
    review_path = OUT / 'pre-score-source-review-r1.json'
    review = read(review_path)
    assert review['status'] == 'completed_pre_score_source_review'
    assert review['source_fingerprint_sha256'] == digest(sources)
    assert review['unresolved_in_scope_findings'] == [] and review['scored_query_executions'] == 0
    assert content(OUT / 'adversarial-review-r1.md') == review['review_document']
    files.extend((review_path, OUT / 'adversarial-review-r1.md'))
    identities = [identity(path) for path in sorted(set(files))]
    verify(identities)
    assert proof.source_inventory() == sources
    result = dict(schema='shardloom.direct_count_candidate_validation.v1', status='passed_fixed_candidate_validation',
        source_fingerprint_sha256=digest(sources), source_head=build['head'], build=identity(build_path),
        checks=checks, required_tests=proof.REQUIRED_TESTS, diagnostic_requests=19,
        native_test_count=4144, ignored_tests=36, reductions=reductions, rejected_corruptions=rejected,
        proof_files=identities, native_query_executions_during_verification=0,
        whole_process_memory_claim=False, scored_performance_claim=False, candidate_acceptance_claimed=False)
    write(OUT / 'candidate-validation-r1.json', result)
    print(json.dumps({key:result[key] for key in ('status', 'diagnostic_requests', 'native_test_count')}))


def installed_proof(sources):
    from direct_count_proof import guarded
    proof = OUT / 'installed-proof-r1'
    python = str(OUT / 'package-tools-r1/bin/python')
    requirements = W / '.github/requirements'
    commands = {
        'candidate-package-environment-r1': [PYTHON, '-m', 'venv', str(OUT / 'package-tools-r1')],
        'candidate-package-tools-r1': [python, '-I', '-m', 'pip', 'install', '--only-binary=:all:',
            '--require-hashes', '-r', str(requirements / 'ci-native-python-build.txt')],
        'candidate-installed-r1': [python, '-B', str(W / 'scripts/prove_native_python_wheel.py'),
            '--repo-root', str(W), '--output-dir', str(proof),
            '--native-library', str(RUNTIME / '_native.abi3.so'), '--cli-binary', str(RUNTIME / 'shardloom'),
            '--wheelhouse', str(J / 'wheelhouse-r1')],
    }
    files = []
    for stem, command in commands.items():
        path = OUT / (stem + '.json')
        guarded(path, command, sources)
        files.extend((path, path.with_suffix('.log')))
    path = proof / 'report.json'
    report = read(path)
    assert report['schema_version'] == 'shardloom.native_python_wheel_proof.v1'
    assert report['status'] == 'passed' and report['installation_performed']
    assert report['scope'] == 'current_host_native_wheel_install_and_binding_integration'
    assert not report['publication_attempted'] and not report['performance_claim']
    assert report['uninstall_status'] == 'passed'
    assert report['build_tools']['setuptools'] == '84.0.0'
    assert report['build_tools']['wheel'] == '0.48.0'
    assert report['build_tools']['pip']
    assert 'artifact_reuse' not in report
    library, binary = content(RUNTIME / '_native.abi3.so'), content(RUNTIME / 'shardloom')
    for key in ('stage', 'integrity'):
        item = report[key]
        assert item['status'] == 'passed'
        assert item['native_library_sha256'] == library['sha256']
        assert item['cli_sha256'] == binary['sha256']
    integrity = report['integrity']
    assert integrity['schema_version'] == 'shardloom.native_python_wheel_integrity.v1'
    assert integrity['tag'].startswith('cp310-abi3-macosx_') and not integrity['published']
    wheel = proof / 'dist' / integrity['wheel']
    assert wheel.parent == proof / 'dist' and wheel.suffix == '.whl'
    assert content(wheel) == {'bytes': integrity['wheel_bytes'], 'sha256': integrity['wheel_sha256']}
    integration = report['integration']
    assert integration == read(proof / 'integration.json')
    assert integration['status'] == 'passed' and type(integration['tests']) is int and integration['tests'] > 0
    assert integration['failures'] == integration['errors'] == integration['skipped'] == 0
    loaded = report['installed_load']
    assert loaded == read(proof / 'load.log') and loaded['isolated_install']
    for key in ('package', 'native_library', 'cli'):
        installed = Path(loaded[key])
        assert installed.is_relative_to(proof / 'venv') and not installed.exists()
    names = ['build', 'create_environment', 'install_optional_consumer', 'install', 'load',
        'integration', 'uninstall', 'verify_uninstalled']
    assert [step['name'] for step in report['steps']] == names
    for step in report['steps']:
        assert step['returncode'] == 0
        assert step['timeout_seconds'] == (1200 if step['name'] == 'integration' else 600)
        assert step['log'] == step['name'] + '.log'
        log = proof / step['log']
        assert content(log)['sha256'] == step['log_sha256']
        files.append(log)
    files.extend((path, proof / 'integration.json', wheel, W / 'scripts/prove_native_python_wheel.py'))
    return files


if __name__ == '__main__':
    main()
