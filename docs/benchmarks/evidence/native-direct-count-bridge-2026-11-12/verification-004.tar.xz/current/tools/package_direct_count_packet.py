"""Collect fixed COUNT evidence without copying runtime or input payloads."""
from __future__ import annotations

import argparse
import importlib.util
import io
import json
from pathlib import Path
import re
import shutil
import tarfile
import tempfile

from verify_direct_count_packet import (BASE, CHECKS, DOC_CHECKS, REPLAY_SUPPORT, digest,
    fingerprint, identity, replay_saved, rust_counts, verify, verify_diagnostics, verify_sources, STATUS_PROSE)

T = Path(__file__).resolve().parents[1]
J = T.parent / 'join-mapping-2026-11-11'
WINDOW = T.parent / 'shared-window-state-2026-11-11'
DISTINCT = T.parent / 'rolling-distinct-2026-11-11'
N = T.parent / 'shared-index-metadata-2026-11-10'
S = T.parent / 'shared-operator-state-2026-11-10'
D = T.parent / 'dictionary-execution-repair-2026-11-10'
K = T.parent / 'variant-expressions-2026-11-10'
E = T.parent / 'expanded-query-2026-11-03'
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')


def read(path):
    return json.loads(path.read_bytes())


def collect(execution_name):
    result = baseline = read(T / 'baseline-verified-r1.json')
    assert result['status'] == 'failed_baseline_cohort' and result['engine_execution_seconds'] is None
    assert not any((T / name).exists() for name in ('candidate-protocol-r1.json', 'candidate-r1', 'candidate-verified-r1.json'))
    assert baseline['selected_cases'] == 2543 and baseline['new_attempts'] == 2384 and baseline['reused_saved_cases'] == 159
    protocol = read(T / 'baseline-protocol-r1.json')
    candidate_sources = read(T / 'candidate-release-build-r1.json')['build_sources']
    closed = read(J / 'join-mapping-closeout-r1.json')
    accepted_sources = closed['repository_source_snapshot']
    data, locations, external = {}, {}, {}
    predecessor = None

    def prior_packet():
        nonlocal predecessor
        if predecessor is None:
            root = W / 'docs/benchmarks/evidence/native-join-payload-mapping-2026-11-12'
            spec = importlib.util.spec_from_file_location('accepted_join_packet', root / 'verify.py')
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            predecessor = module.read_archive(root)
        return predecessor

    def mapped(path):
        if path.parent.name == 'source-blobs' and re.fullmatch(r'[0-9a-f]{64}', path.name):
            return 'source-blobs/' + path.name
        if path.is_relative_to(E / 'investigation-original-harness-r1'):
            relative = path.relative_to(E / 'investigation-original-harness-r1').as_posix()
            if relative in REPLAY_SUPPORT:
                return 'protocol-support/' + relative
        for root, prefix in ((T, 'current'), (J, 'join'), (DISTINCT, 'distinct'), (WINDOW, 'window'),
                (N, 'index'), (S, 'preparation'), (D, 'repair'), (K, 'prior'),
                (E / 'investigation-original-harness-r1', 'harness'), (E, 'frozen'),
                (W / 'docs/benchmarks/evidence', 'prior-benchmark-packets'),
                (W / 'docs/release/evidence', 'prior-release-packets'), (W, 'source-imports')):
            if path.is_relative_to(root):
                return prefix + '/' + path.relative_to(root).as_posix()
        raise AssertionError('unclassified proof path: ' + str(path))

    def add(path, name=None):
        name = name or mapped(path)
        assert path.is_file() and not path.is_symlink(), path
        raw = path.read_bytes()
        assert name not in data or data[name] == raw
        assert str(path) not in locations or locations[str(path)] == name
        data[name], locations[str(path)] = raw, name
        return raw

    for path in sorted([*T.glob('*.json'), *T.glob('*.log'), *T.glob('*.md'), *T.glob('tools/*.py'), *T.glob('client/*.py')]):
        if path.name not in (execution_name + '.json', execution_name + '.log'):
            add(path)
    for pattern in ('debug-attribution-r*', 'release-attribution-r*', 'candidate-debug-attribution-r*',
            'diagnostic-declarations-r*', 'preparation-retirement-r1', 'source-restoration-r1'):
        for folder in sorted(T.glob(pattern)):
            if folder.is_dir():
                for path in sorted(folder.rglob('*')):
                    if path.is_file():
                        add(path)
    for previous in sorted(T.glob('packet-r[0-9]*')):
        if previous.is_dir():
            for name in ('acceptance.json', 'verify.py'):
                path = previous / name
                if path.is_file():
                    add(path)
    for pattern in ('installed-proof-r1/*.json', 'installed-proof-r1/*.log'):
        for path in sorted(T.glob(pattern)):
            add(path)
    add(T / 'candidate-proposal-r1.patch')
    for prefix in ('baseline-missing-r1',):
        for name in ('complete.json', 'binding.json', 'attempts.sqlite'):
            add(T / prefix / name)
    for path in sorted(T.glob('*-cases-r1.jsonl.gz')):
        add(path)
    add(T / 'baseline-reused-r1.sqlite')
    add(T / 'references-r1/complete.json')
    add(T / 'references-r1/expectations.sqlite')
    for row in protocol['runtime_binding']['proof_files']:
        path = Path(row['path'])
        wanted = dict(bytes=row['generation']['bytes'], sha256=row['sha256'])
        if path.parent in (WINDOW / 'runtime-r1', T / 'runtime-r1'):
            assert path.name in ('shardloom', 'lib_native.dylib', '_native.abi3.so')
            role = 'accepted_runtime_identity' if path.parent == WINDOW / 'runtime-r1' else 'candidate_runtime_identity'
        elif path.parent == T / 'installed-proof-r1/dist':
            installed = read(T / 'installed-proof-r1/report.json')['integrity']
            assert path.name == installed['wheel'] and wanted == dict(bytes=installed['wheel_bytes'], sha256=installed['wheel_sha256'])
            role = 'candidate_installed_wheel_identity'
        elif (path.is_relative_to(W / 'docs/release/evidence') or path.is_relative_to(W / 'docs/benchmarks/evidence')) and path.name.endswith('.tar.xz'):
            role = 'historical_committed_archive_identity'
        else:
            actual = identity(path.read_bytes()) if path.is_file() else None
            if actual == wanted:
                assert identity(add(path)) == wanted
            else:
                assert result['status'] == 'failed_baseline_cohort'
                assert path.is_relative_to(W)
                relative = path.relative_to(W).as_posix()
                assert candidate_sources[relative] == wanted
                assert relative in STATUS_PROSE or accepted_sources.get(relative) == actual
                raw = (T / 'source-blobs' / wanted['sha256']).read_bytes()
                assert identity(raw) == wanted
                name = mapped(path)
                assert name not in data and str(path) not in locations
                data[name], locations[str(path)] = raw, name
            continue
        import hashlib
        with path.open('rb') as stream:
            assert dict(bytes=path.stat().st_size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest()) == wanted
        external[str(path)] = dict(role=role, identity=wanted)
    for name, wanted in closed['retained_runtime'].items():
        path = Path(name)
        assert path.parent == WINDOW / 'runtime-r1'
        assert path.name in ('shardloom', 'lib_native.dylib', '_native.abi3.so')
        with path.open('rb') as stream:
            assert dict(bytes=path.stat().st_size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest()) == wanted
        item = dict(role='accepted_runtime_identity', identity=wanted)
        assert name not in external or external[name] == item
        external[name] = item
    reuse = read(T / 'baseline-reuse-r1.json')
    for pool in reuse['inspected_pools']:
        for key in ('protocol', 'result', 'case_rows', 'packet_acceptance'):
            row = pool[key]
            assert identity(add(Path(row['path']))) == dict(bytes=row['generation']['bytes'], sha256=row['sha256'])
    add(J / 'join-mapping-closeout-r1.json')
    add(WINDOW / 'candidate-release-build-r1.json')
    _, prior_data = prior_packet()
    for name in ('design.json', 'inputs.json', 'frozen.json', 'native-preparation/complete.json', 'investigation-original-harness-source-r1.json'):
        add(E / name)
    frozen = read(E / 'frozen.json')
    for row in frozen['references']:
        assert identity(add(Path(row['path']))) == dict(bytes=row['generation']['bytes'], sha256=row['sha256'])
    manifest = read(E / 'investigation-original-harness-source-r1.json')
    for relative, sha256 in manifest['harness_sha256'].items():
        path = E / 'investigation-original-harness-r1' / relative
        assert digest(add(path)) == sha256
        original = [row for row in frozen['harness'] if row['path'].endswith('/' + relative)]
        assert len(original) == 1 and original[0]['sha256'] == sha256
        locations[original[0]['path']] = 'harness/' + relative
    add(S / 'current-baseline-10k-r1/failed-observation-replay-r1.json')
    wanted = {item['sha256']:item for item in accepted_sources.values() if 'sha256' in item and 'symlink' not in item}
    for name, raw in list(data.items()):
        if not name.endswith('.json'):
            continue
        try:
            record = json.loads(raw)
        except (json.JSONDecodeError, UnicodeDecodeError):
            continue
        if not isinstance(record, dict):
            continue
        for key in ('build_sources', 'tool_source_inventory'):
            for item in record.get(key, {}).values():
                if 'sha256' in item and 'symlink' not in item:
                    assert item['sha256'] not in wanted or wanted[item['sha256']] == item
                    wanted[item['sha256']] = item
    existing_bytes, prior_bytes = ({digest(raw):raw for raw in group.values()} for group in (data, prior_data))
    for sha256, item in sorted(wanted.items()):
        roots = (T, J, DISTINCT, WINDOW, N, S, D, K)
        found = [root / 'source-blobs' / sha256 for root in roots if (root / 'source-blobs' / sha256).is_file()]
        if found:
            raw = add(found[0], 'source-blobs/' + sha256)
        elif sha256 in existing_bytes:
            raw = existing_bytes[sha256]
            data['source-blobs/' + sha256] = raw
        else:
            raw = prior_bytes[sha256]
            data['source-blobs/' + sha256] = raw
        assert identity(raw) == item
    dispositions = read(T / 'failure-dispositions-r1.json')
    failures = []
    for name, raw in sorted(data.items()):
        if name.startswith('current/') and name.count('/') == 1 and name.endswith('.json'):
            record = json.loads(raw)
            if isinstance(record, dict) and (str(record.get('status')).startswith('failed') or record.get('status') == 'interrupted'):
                key = name.removeprefix('current/')
                assert dispositions[key]
                failures.append(dict(receipt=name, identity=identity(raw), disposition=dispositions[key]))
    assert set(dispositions) == {row['receipt'].removeprefix('current/') for row in failures}
    ci = read(T / 'candidate-ci-inventory-r1.json')
    installed = read(T / 'installed-proof-r1/report.json')
    report = dict(schema='shardloom.direct_count_checkpoint.v1', status='local_invalid_baseline_checkpoint',
        source_base=BASE, candidate_source_snapshot=candidate_sources,
        candidate_source_fingerprint_sha256=fingerprint(candidate_sources),
        checks={name:dict(command=command, status='passed', rust_tests=rust_counts(data['current/' + name + '.log'])) for name,command in CHECKS.items()},
        documentation_checks={name:dict(command=command, status='passed', rust_tests=rust_counts(data['current/' + name + '.log'])) for name,command in DOC_CHECKS.items()},
        ci_inventory=dict(tests=ci['test_count'], ignored=len(ci['ignored']), partitions=len(ci['partitions'])),
        disposition='not_admitted_invalid_baseline', candidate_admitted=False, investigation_b_complete=False,
        scored_candidate_query_executions=0, engine_execution_seconds=None,
        installed_package=dict(integration_tests=installed['integration']['tests'], skipped=0, isolated_install=True, uninstall_status='passed'),
        original_failed_checks=failures,
        baseline=dict(cases=2543, reused_saved_cases=159, new_attempts=2384, outcomes=baseline['outcomes'],
            engine_execution_seconds=None, complete_performance_result_valid=False),
        candidate=dict(admitted=False, scored_query_executions=0, comparison_available=False, gain_loss_disposition=None),
        complete_10k_performance_claim=False, full43_claim=False, whole_query_memory_claim=False,
        whole_item_19_complete=False, whole_item_20_complete=False, publication_attempted=False,
        hosted_integration='pending',
        source_policy='Fixed prototype source and release runtime before the baseline. Invalid baseline prevented candidate admission; runtime/tests/ignored registration exactly restored to the accepted repository snapshot. Only named architecture/status prose advances.',
        limitations=result['limitations'] + ['All 60 failed baseline observations remain failed; no complete engine total or candidate comparison is available.',
            'Debug work counters and release diagnostic phase attribution are unscored, distinct observations.',
            'Native I32 is tested at the array boundary; public I32 scalar casts are not claimed.',
            'Runtime, wheel and input payloads remain identity-bound; no rollback payload copies are included.',
            'Hosted integration, retirement, remaining investigations, item19/item20/RFC0044 and CG1through23 are separate.'],
        identity_only_proof=dict(sorted(external.items())), locations=dict(sorted(locations.items())),
        members=[dict(path=name, **identity(raw)) for name,raw in sorted(data.items())])
    assert sum(len(raw) for raw in data.values()) < 512 << 20
    return report, data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destination', type=Path, required=True)
    parser.add_argument('--execution-name', required=True)
    parser.add_argument('--preflight-only', action='store_true')
    parser.add_argument('--replay-preflight', action='store_true')
    args = parser.parse_args()
    assert args.destination.resolve().is_relative_to(T) and not args.destination.exists()
    assert re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', args.execution_name)
    assert not args.replay_preflight or args.preflight_only
    report, data = collect(args.execution_name)
    packet = verify_sources(report, data, W)
    if args.preflight_only:
        replay = None
        if args.replay_preflight:
            verify_diagnostics(packet)
            with tempfile.TemporaryDirectory(prefix='direct-count-replay-preflight-', dir=T) as temporary:
                replay = replay_saved(report, data, Path(temporary))
        print(json.dumps(dict(status='passed_collection_preflight', query_executions=0,
            logical_files=len(data), logical_bytes=sum(map(len, data.values())), archives_written=0, replay=replay)))
        return
    destination = args.destination
    destination.mkdir()
    stored, assemblies = {}, []
    for name, raw in sorted(data.items()):
        if len(raw) <= 24 << 20:
            stored[name] = raw
        else:
            parts = []
            for offset in range(0, len(raw), 24 << 20):
                part = name + f'.part-{len(parts):04d}'
                assert part not in data and part not in stored
                stored[part] = raw[offset:offset + (24 << 20)]
                parts.append(part)
            assemblies.append(dict(path=name, parts=parts, **identity(raw)))
    groups, group, size = [], [], 0
    for name, raw in sorted(stored.items()):
        if group and size + len(raw) > 48 << 20:
            groups.append(group)
            group, size = [], 0
        group.append(name)
        size += len(raw)
    if group:
        groups.append(group)
    archives = []
    for index, names in enumerate(groups):
        path = destination / f'verification-{index + 1:03d}.tar.xz'
        with tarfile.open(path, 'w:xz', preset=6) as archive:
            for name in names:
                raw = stored[name]
                member = tarfile.TarInfo(name)
                member.size, member.mode, member.mtime = len(raw), 0o644, 0
                archive.addfile(member, io.BytesIO(raw))
        assert path.stat().st_size < 64 << 20
        archives.append(dict(path=path.name, members=names, **identity(path.read_bytes())))
    report.update(stored_members=[dict(path=name, **identity(raw)) for name,raw in sorted(stored.items())],
        assemblies=assemblies, archives=archives)
    (destination / 'acceptance.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    shutil.copyfile(T / 'tools/verify_direct_count_packet.py', destination / 'verify.py')
    print(json.dumps(verify(destination, W), indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
