"""Guard bounded direct-COUNT feasibility after the join-mapping closeout."""
import argparse
import hashlib
import importlib.util
import json
import lzma
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
OUT = Path('/Users/dylan/LocalData/shardloom/direct-count-bridge-2026-11-12')
WINDOW = OUT.parent / 'shared-window-state-2026-11-11'
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
REPAIR = OUT.parent / 'dictionary-execution-repair-2026-11-10'
STATE = OUT.parent / 'shared-operator-state-2026-11-10'
PRIOR_CLOSEOUT = OUT.parent / 'join-mapping-2026-11-11/join-mapping-closeout-r1.json'
PREDECESSOR = PRIOR_CLOSEOUT.parent
DESIGN = OUT / 'design-r1.md'
ACCEPTED_HEAD = '55d940e879a4567b21fe4c0c3d64a35ef35664d6'
ACCEPTED_TREE = 'ef1ebe017aaedcc858098106480f20c5ff82a102'
sys.path[:0] = [str(ROOT / 'scripts'), '/Users/dylan/LocalData/shardloom/release-0.3.3-20260930']
from release_validation_guard import WorkloadGuard
from local_uat_storage import GIB, MIB, accounted_bytes, available_bytes, check_budgets, require_local_path

if not __debug__:
    raise RuntimeError('experiment supervision requires Python assertion checks')
assert Path(__file__).resolve() == OUT / 'tools/guard_direct_count.py', 'unactivated draft cannot execute'

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--name', required=True)
parser.add_argument('--timeout', type=float, default=2400)
parser.add_argument('--query-workload', action='store_true',
                    help='Keep full evidence/cache inventories before/after queries; active output and free-space guards remain.')
parser.add_argument('--allow-lockfile-update', action='store_true',
                    help='Preparation mode: permit only root Cargo.lock content to change; this is not fixed-source validation.')
parser.add_argument('--preparation', action='store_true',
                    help='Label dependency/fixture preparation without relaxing repository source checks.')
parser.add_argument('--active-output', type=Path,
                    help='Required with --query-workload: only this active output subtree is inventoried during queries.')
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
assert args.name.replace('-', '').isalnum() and args.timeout > 0
assert not args.allow_lockfile_update and not args.preparation, 'experiment validation requires fixed source during each command'
if args.query_workload != (args.active_output is not None):
    parser.error('--query-workload and --active-output must be supplied together')
if args.active_output is not None:
    args.active_output = args.active_output.resolve()
    if args.active_output == OUT or not args.active_output.is_relative_to(OUT):
        parser.error('--active-output must be a strict descendant of this task output directory')
command = args.command[1:] if args.command[:1] == ['--'] else args.command
assert command
for path in (OUT, CACHE):
    require_local_path(path, Path.home(), sys.platform)
helper = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
assert hashlib.sha256(helper.read_bytes()).hexdigest() == '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97'
spec = importlib.util.spec_from_file_location('supervisor', helper)
supervisor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(supervisor)
env = dict(os.environ,
    PATH='/Users/dylan/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/Users/dylan/.cargo/bin:/opt/homebrew/opt/python@3.13/libexec/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
    CARGO_TARGET_DIR=str(CACHE), CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0',
    CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
    PYTHONPATH='python/src:scripts', PYTHONDONTWRITEBYTECODE='1', CARGO_TERM_COLOR='never')
prior_raw = PRIOR_CLOSEOUT.read_bytes()
assert hashlib.sha256(prior_raw).hexdigest() == 'e34f1128c33c78f634fdfd03e30cc1c5a53f328b060f011f1a53300bc2c64936'
prior = json.loads(prior_raw)
assert prior['schema'] == 'shardloom.join_mapping_closeout.v1'
assert prior['status'] == 'complete'
assert prior['pr_checks_passed'] == 58 and prior['main_checks_passed'] == 55
assert prior['pr_head'] == ACCEPTED_HEAD and prior['source_tree'] == ACCEPTED_TREE
ACCEPTED_MERGE = prior['merge_commit']
assert ACCEPTED_MERGE == '3a0608b12e40435fab1adc4afefbaa4173932737'
assert prior['runtime_sources_match_build'] and prior['source_bound_replay'] == 'passed'
assert prior['portable_replay_after_retirement'] == 'passed'
assert prior['working_tree_clean'] and prior['current_inputs_unchanged']
assert prior['review_findings'] is False
assert prior['disposition'] == 'drop_candidate_no_gain'
assert prior['candidate']['selected_cases'] == 940
assert prior['candidate']['outcomes'] == {'passed': 940}
assert prior['candidate']['engine_execution_seconds'] == 739.927898219
assert prior['baseline']['engine_execution_seconds'] == 653.057359901
assert prior['accepted_predecessor_runtime'] == 'preserved at ' + str(WINDOW / 'runtime-r1')
window_closeout_path = WINDOW / 'shared-window-closeout-r1.json'
window_closeout_raw = window_closeout_path.read_bytes()
window_closeout_identity = dict(bytes=len(window_closeout_raw),
    sha256=hashlib.sha256(window_closeout_raw).hexdigest())
assert prior['accepted_runtime_closeout'] == dict(path=str(window_closeout_path),
    identity=window_closeout_identity)
assert window_closeout_identity['sha256'] == '97b80163c9c91d1186acc86522e808fa8563c8d9dd88be9a4ff1b71e316768a0'
window_closeout = json.loads(window_closeout_raw)
assert prior['source_fingerprint_sha256'] == window_closeout['source_fingerprint_sha256']
assert prior['retained_runtime'] == window_closeout['retained_runtime']
assert not prior['complete_10k_performance_claim']
assert not prior['publication_attempted'] and not prior['storage_limits_changed']
assert not prior['payload_backup_created']
retirement = PREDECESSOR / 'join-mapping-retirement-r1'
retirement_plan = json.loads((retirement / 'plan.json').read_bytes())
retirement_raw = (retirement / 'manifest.json.xz').read_bytes()
assert hashlib.sha256(retirement_raw).hexdigest() == retirement_plan['manifest_sha256']
assert prior['receipts']['join-mapping-retirement-r1/manifest.json.xz'] == dict(
    bytes=len(retirement_raw), sha256=hashlib.sha256(retirement_raw).hexdigest())
input_generations = json.loads(lzma.decompress(retirement_raw))['input_generations']
assert len(input_generations) == prior['current_input_files'] == 220
# The runtime predates independently accepted CI cleanup and status prose.
# Preserve this explicit scope; never assert whole repository/build equality.
assert prior['complete_repository_source_equals_runtime_build'] is False
assert prior['repository_source_fingerprint_sha256'] == 'f3b5df1f92c9948a1aa5a3c3ab7655370fec7b807d942c19596ae586a2bfbbd5'
repository_snapshot = prior['repository_source_snapshot']
assert hashlib.sha256(json.dumps(repository_snapshot, sort_keys=True,
    separators=(',', ':')).encode()).hexdigest() == prior['repository_source_fingerprint_sha256']
runtime_differences = prior['repository_differences_from_runtime_build']
assert set(runtime_differences) == {
    'docs/architecture/local-development-storage.md',
    'docs/architecture/native-join-payload-mapping-2026-11-12.md',
    'docs/architecture/native-rolling-distinct-2026-11-11.md',
    'docs/architecture/native-shared-index-metadata-2026-11-10.md',
    'docs/architecture/native-shared-pipeline-investigations-2026-11-10.md',
    'docs/architecture/native-shared-window-state-2026-11-11.md',
    'docs/architecture/native-structural-work-investigations-2026-11-11.md',
    'docs/architecture/phased-execution-plan.md',
    'scripts/ci_native_tests.py', 'scripts/test_ci_native_tests.py'}
assert set(prior['independent_ci_cleanup_fix']) == {
    'scripts/ci_native_tests.py', 'scripts/test_ci_native_tests.py'}
for name, correction in prior['independent_ci_cleanup_fix'].items():
    assert correction['before'] == runtime_differences[name]['runtime']
    assert correction['after'] == runtime_differences[name]['repository'] == repository_snapshot[name]
protected = dict(prior['retained_runtime'])
assert {Path(name).name for name in protected} == {'shardloom', 'lib_native.dylib', '_native.abi3.so'}
assert all(Path(name).parent == WINDOW / 'runtime-r1' for name in protected)
protected[str(PRIOR_CLOSEOUT)] = dict(bytes=len(prior_raw),
    sha256=hashlib.sha256(prior_raw).hexdigest())
protected[str(window_closeout_path)] = window_closeout_identity
for name, expected in prior['receipts'].items():
    path = PREDECESSOR / name
    assert not Path(name).is_absolute() and path.resolve().is_relative_to(PREDECESSOR)
    protected[str(path)] = expected
for name, expected in prior['committed_evidence'].items():
    path = ROOT / name
    assert not Path(name).is_absolute() and path.resolve().is_relative_to(ROOT)
    protected[str(path)] = expected
FAILED = STATE / 'current-baseline-10k-r1'
failed_report = FAILED / 'failed-observation-replay-r1.json'
failed_raw = failed_report.read_bytes()
failed = json.loads(failed_raw)
assert failed['status'] == 'verified_failed_observation'
assert failed['verification_passed'] and not failed['complete_performance_result_valid']
assert failed['source_commit'] == '8f426b3d2e774be2a9d30a731c33b8c830378d99'
assert failed['observed_attempts'] == 10000 and failed['verified_correct_results'] == 9904
assert failed['original_outcomes'] == {'passed': 9904, 'crashed': 76, 'harness_error': 20}
assert failed['engine_execution_seconds'] is None
protected[str(failed_report)] = dict(bytes=len(failed_raw), sha256=hashlib.sha256(failed_raw).hexdigest())
# Raw old ledgers were retired only after their committed packets replayed.
# Protect the compact results and exact archive bytes; never recreate old runtimes.
for key in ('case_rows', 'complete', 'protocol'):
    item = failed[key]
    protected[item['path']] = dict(bytes=item['generation']['bytes'], sha256=item['sha256'])
old_packet = ROOT / 'docs/release/evidence/native-dictionary-execution-repair-2026-11-10/acceptance.json'
old_members = {row['path']: {key: row[key] for key in ('bytes', 'sha256')}
    for row in json.loads(old_packet.read_bytes())['members']}
for name, expected in list(protected.items()):
    path = Path(name)
    if path.is_relative_to(FAILED):
        assert old_members['original/' + path.relative_to(STATE).as_posix()] == expected
# Freeze the design and completed protocols/observations that already exist.
for path in [DESIGN, *sorted(OUT.glob('baseline-*.json*')),
             *sorted(OUT.glob('candidate-protocol-*.json')),
             *sorted(OUT.glob('diagnostic-protocol-*.json')),
             *sorted(OUT.glob('diagnostic-declarations-*.json')),
             *sorted(OUT.glob('diagnostic-*-identity.json')),
             *sorted(OUT.glob('*-attribution-*-result.json')),
             *sorted(OUT.glob('cohort-*.json*'))]:
    assert path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(OUT)
    with path.open('rb') as stream:
        protected[str(path)] = dict(bytes=path.stat().st_size,
            sha256=hashlib.file_digest(stream, 'sha256').hexdigest())

def generation(path):
    s = path.lstat()
    return [s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_nlink]

diagnostic_generations = {}
for path in sorted(OUT.glob('diagnostic-declarations-*.json')):
    declaration = json.loads(path.read_bytes())
    assert declaration['schema_version'] == 'shardloom.direct_count_diagnostic_declarations.v1'
    assert declaration['status'] == 'frozen'
    for group in ('input_files', 'reference_databases'):
        for name, item in declaration[group].items():
            if name in diagnostic_generations:
                assert diagnostic_generations[name] == item['generation']
            diagnostic_generations[name] = item['generation']
assert {name: generation(Path(name)) for name in diagnostic_generations} == diagnostic_generations

retained_generations = {}
for name, expected in protected.items():
    path = Path(name)
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        actual = {'bytes': path.stat().st_size, 'sha256': hashlib.file_digest(stream, 'sha256').hexdigest()}
    assert actual == expected, 'accepted runtime/wheel changed: ' + name
    retained_generations[name] = generation(path)
assert {name: generation(Path(name)) for name in input_generations} == input_generations
base = ACCEPTED_MERGE
assert len(base) == 40 and all(char in '0123456789abcdef' for char in base)
subprocess.run(['git', 'merge-base', '--is-ancestor', base, 'HEAD'], cwd=ROOT,
               check=True, timeout=30)
metadata = json.loads(subprocess.check_output(['cargo', 'metadata', '--offline', '--locked',
    '--no-deps', '--format-version', '1'], cwd=ROOT, env=env))
assert metadata['target_directory'] == str(CACHE)
check_budgets(OUT, OUT / 'reserved-artifact', OUT / 'logs',
    min_free_bytes=12 * GIB, reserve_bytes=128 * MIB,
    max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
workload = WorkloadGuard()
workload.check()
changed = set()
# Include incorporated proposal commits as well as later working-tree changes.
for argv in (['git', 'diff', '--no-renames', '--name-only', '-z', base],
             ['git', 'ls-files', '--others', '--exclude-standard', '-z']):
    changed.update(path for path in subprocess.check_output(argv, cwd=ROOT).decode().split('\0') if path)
source_inventory = {}
for relative in sorted(changed):
    path = ROOT / relative
    if path.is_symlink():
        source_inventory[relative] = {'symlink': os.readlink(path)}
    elif path.is_file():
        source_inventory[relative] = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                                      'bytes': path.stat().st_size}
        snapshot = OUT / 'source-blobs' / source_inventory[relative]['sha256']
        snapshot.parent.mkdir(exist_ok=True)
        if not snapshot.exists():
            shutil.copyfile(path, snapshot)
        assert hashlib.sha256(snapshot.read_bytes()).hexdigest() == source_inventory[relative]['sha256']
    else:
        source_inventory[relative] = {'absent': True}
BUILD_INPUT_EXCLUSIONS = ('docs/benchmarks/evidence/', 'docs/release/evidence/',
                          'docs/dependencies/evidence/')

def included_build_input(relative):
    parts = Path(relative).parts
    if relative.startswith(('.git/', *BUILD_INPUT_EXCLUSIONS)) or '.git' in parts:
        return False
    return True

def capture_build_sources(snapshot=False):
    paths = set()
    for argv in (['git', 'ls-files', '--cached', '-z'],
                 ['git', 'ls-files', '--others', '--exclude-standard', '-z']):
        paths.update(path for path in subprocess.check_output(argv, cwd=ROOT).decode().split('\0')
                     if path and included_build_input(path))
    inventory = {}
    for relative in sorted(paths):
        path = ROOT / relative
        if path.is_symlink():
            target = os.readlink(path)
            inventory[relative] = {'symlink': target,
                                   'sha256': hashlib.sha256(os.fsencode(target)).hexdigest()}
        elif path.is_file():
            raw = path.read_bytes()
            item = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
            inventory[relative] = item
            if snapshot:
                blob = OUT / 'source-blobs' / item['sha256']
                blob.parent.mkdir(parents=True, exist_ok=True)
                if not blob.exists():
                    blob.write_bytes(raw)
                assert blob.read_bytes() == raw
        elif not path.exists():
            inventory[relative] = {'absent': True}
        else:
            inventory[relative] = {'other_mode': path.lstat().st_mode}
    return inventory

def inventory_fingerprint(inventory):
    encoded = json.dumps(inventory, sort_keys=True, separators=(',', ':')).encode()
    return hashlib.sha256(encoded).hexdigest()

build_sources = capture_build_sources(snapshot=True)
build_source_fingerprint = inventory_fingerprint(build_sources)
root_lock_before = build_sources.get('Cargo.lock')
assert root_lock_before and 'sha256' in root_lock_before and 'symlink' not in root_lock_before
tool_sources = {}
tool_paths = [Path(__file__).resolve(), helper, Path(sys.modules[WorkloadGuard.__module__].__file__),
              Path(sys.modules['local_uat_storage'].__file__)]
tool_paths += sorted((OUT / 'tools').glob('*.py')) + sorted((OUT / 'client').glob('*.py'))
for argument in command:
    if argument.endswith('.py'):
        path = Path(argument)
        path = path if path.is_absolute() else ROOT / path
        if path.is_file():
            tool_paths.append(path)
for path in tool_paths:
    assert path.is_file() and not path.is_symlink()
    raw = path.read_bytes()
    item = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    tool_sources[str(path)] = item
    snapshot = OUT / 'source-blobs' / item['sha256']
    if not snapshot.exists():
        snapshot.write_bytes(raw)
    assert snapshot.read_bytes() == raw
record = {'status': 'running', 'command': command, 'cwd': str(ROOT),
    'protected_runtime_and_wheel': protected,
    'retained_generations': retained_generations, 'input_generations': input_generations,
    'diagnostic_input_and_reference_generations': diagnostic_generations,
    'base': base, 'prior_closeout_sha256': hashlib.sha256(prior_raw).hexdigest(),
    'accepted_join_mapping_closeout': {'path': str(PRIOR_CLOSEOUT), 'bytes': len(prior_raw),
        'sha256': hashlib.sha256(prior_raw).hexdigest()},
    'accepted_baseline_merge': ACCEPTED_MERGE,
    'accepted_runtime_build_source_fingerprint_sha256': prior['source_fingerprint_sha256'],
    'accepted_repository_source_fingerprint_sha256': prior['repository_source_fingerprint_sha256'],
    'accepted_repository_differences_from_runtime_build': runtime_differences,
    'independent_ci_cleanup_fix': prior['independent_ci_cleanup_fix'],
    'complete_accepted_repository_equals_runtime_build': False,
    'source_matches_accepted_repository': build_sources == repository_snapshot,
    'changes_from_accepted_repository': {
        name: {'accepted': repository_snapshot.get(name), 'current': build_sources.get(name)}
        for name in sorted(set(repository_snapshot) | set(build_sources))
        if repository_snapshot.get(name) != build_sources.get(name)},
    'baseline_main_acceptance_claimed': True,
    'candidate_acceptance_claimed': False,
    'fixed_design': {'path': str(DESIGN), **protected[str(DESIGN)]},
    'original_failed_observation': {'path': str(failed_report), 'sha256': hashlib.sha256(failed_raw).hexdigest(),
        'complete_performance_result_valid': False, 'observed_attempts': 10000,
        'verified_correct_results': 9904, 'failed_attempts': 96},
    'hosted_main_checks_passed': 55,
    'hosted_checks_prove_failed_cohort': False,
    'query_workload': args.query_workload,
    'build_inventory_policy': 'before_and_after_only' if args.query_workload else 'periodic',
    'evidence_inventory_policy': 'before_and_after_only' if args.query_workload else 'periodic',
    'active_output': str(args.active_output) if args.active_output else None,
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'working_tree': subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True),
    'changed_source_inventory': source_inventory,
    'build_sources': build_sources,
    'build_source_fingerprint_sha256': build_source_fingerprint,
    'build_source_path_count': len(build_sources),
    'build_source_scope_exclusions': [*BUILD_INPUT_EXCLUSIONS, '.git/**',
        'generated output paths ignored by git'],
    'allow_lockfile_update': args.allow_lockfile_update,
    'source_validation_mode': ('preparation_allow_root_cargo_lock_update' if args.allow_lockfile_update
                               else 'preparation_no_source_changes' if args.preparation
                               else 'fixed_source_validation'),
    'fixed_source_validation': not (args.allow_lockfile_update or args.preparation),
    'root_cargo_lock_hashes': {'path': 'Cargo.lock', 'allowed_to_change': args.allow_lockfile_update,
        'before_sha256': root_lock_before['sha256'], 'before_bytes': root_lock_before['bytes'],
        'after_sha256': root_lock_before['sha256'], 'after_bytes': root_lock_before['bytes'],
        'changed': False},
    'build_source_verification': {},
    'tool_source_inventory': tool_sources,
    'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'environment': {key: env.get(key) for key in ('CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL', 'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG', 'CLIPPY_CONF_DIR', 'SHARDLOOM_PIP_AUDIT_PYTHON')},
    'supervisor_sha256': hashlib.sha256(helper.read_bytes()).hexdigest()}

def verify_build_sources(phase):
    current_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    current = capture_build_sources(snapshot=phase == 'post_execution')
    fingerprint = inventory_fingerprint(current)
    path_set_matches = set(current) == set(build_sources)
    changed = []
    for relative in sorted(set(current) | set(build_sources)):
        before = build_sources.get(relative)
        after = current.get(relative)
        if relative == 'Cargo.lock' and args.allow_lockfile_update and phase == 'post_execution':
            if not (before and after and 'sha256' in before and 'sha256' in after
                    and 'symlink' not in before and 'symlink' not in after):
                changed.append(relative)
        elif before != after:
            changed.append(relative)
    lock_after = current.get('Cargo.lock')
    if lock_after and 'sha256' in lock_after:
        record['root_cargo_lock_hashes'].update(after_sha256=lock_after['sha256'],
                                               after_bytes=lock_after['bytes'],
                                               changed=lock_after['sha256'] != root_lock_before['sha256'])
    result = {'head': current_head, 'head_matches': current_head == record['head'],
        'path_set_matches': path_set_matches, 'path_count': len(current),
        'fingerprint_sha256': fingerprint, 'changed_paths': changed}
    record['build_source_verification'][phase] = result
    assert result['head_matches'], 'HEAD changed during guarded execution'
    assert path_set_matches, 'build input path set changed during guarded execution'
    assert not changed, 'build input changed during guarded execution: ' + ', '.join(changed)

driver_snapshot = OUT / 'source-blobs' / record['driver_sha256']
if not driver_snapshot.exists():
    shutil.copyfile(Path(__file__), driver_snapshot)
receipt = OUT / f'{args.name}.json'
assert not receipt.exists()
log = OUT / f'{args.name}.log'
last_storage = None

def guard(force_build=False):
    global last_storage
    assert PRIOR_CLOSEOUT.read_bytes() == prior_raw
    assert {name: generation(Path(name)) for name in retained_generations} == retained_generations
    if force_build:
        assert {name: generation(Path(name)) for name in input_generations} == input_generations
        assert {name: generation(Path(name)) for name in diagnostic_generations} == diagnostic_generations
        verify_build_sources('post_execution')
        for name, item in tool_sources.items():
            raw = Path(name).read_bytes()
            assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
    workload.check(record.get('pid'))
    assert available_bytes(CACHE) >= 12 * GIB, 'minimum free storage reached'
    if not force_build and last_storage is not None and time.monotonic() - last_storage < 30:
        return
    observations = {}
    paths = (('output', OUT), ('cargo', CACHE))
    if args.query_workload and record.get('pid') and not force_build:
        paths = (('active_output', args.active_output),)
    for label, path in paths:
        budget = record['active_output_workspace_budget_bytes'] if label == 'active_output' else 100 * GIB
        observations[label] = check_budgets(path, path / 'reserved-artifact', path / 'logs',
            min_free_bytes=12 * GIB, reserve_bytes=128 * MIB,
            max_workspace_bytes=budget, max_log_bytes=192 * MIB)
    if args.query_workload and not record.get('pid'):
        # The inactive evidence tree is fixed while the isolated query job runs.
        # Subtract it once so narrowing the active scan never raises the total cap.
        inactive = observations['output']['workspace_bytes'] - accounted_bytes(args.active_output)
        assert inactive >= 0
        record['inactive_output_bytes'] = inactive
        record['active_output_workspace_budget_bytes'] = 100 * GIB - inactive
    record['storage_last_observation'] = observations
    record.setdefault('storage_inventory_scopes', []).append(dict(
        scopes=list(observations), child_started=bool(record.get('pid')), forced=force_build))
    last_storage = time.monotonic()

try:
    verify_build_sources('pre_execution')
    guard()
    with log.open('xb') as stream:
        code = supervisor.run(command, cwd=ROOT, env=env, output=stream,
            timeout=args.timeout, evidence=record, guard=guard, max_output_bytes=8 << 20)
    record['status'] = 'passed' if code == 0 else 'failed'
    guard(force_build=True)
except BaseException as error:
    record.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    if log.exists():
        record['log_sha256'] = hashlib.sha256(log.read_bytes()).hexdigest()
    receipt.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({key: record.get(key) for key in ('status', 'returncode', 'seconds', 'process_group_drained', 'error')}), flush=True)
    print(str(receipt), flush=True)
raise SystemExit(code)

