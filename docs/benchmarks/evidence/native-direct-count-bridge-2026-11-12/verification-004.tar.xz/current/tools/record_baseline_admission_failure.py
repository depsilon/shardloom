"""Bind the failed COUNT baseline to exact adapter/declaration mismatches."""
from collections import Counter
import gzip
import json
from pathlib import Path
import sqlite3
import sys
import zlib

from direct_count_common import CLOSEOUT, FROZEN, OUT, W, Cases, content, digest, read, write
import direct_count_proof as proof
from query_surface import adapters
from query_surface.evidence import identity


def rust_function(raw, marker):
    text = raw.decode()
    start = text.index(marker)
    opening = text.index('{', start)
    depth = 1
    cursor = opening + 1
    while depth:
        depth += (text[cursor] == '{') - (text[cursor] == '}')
        cursor += 1
    return text[start:cursor]


def main():
    assert __debug__ and Path(__file__).resolve() == OUT / 'tools/record_baseline_admission_failure.py'
    assert not any((OUT / name).exists() for name in ('candidate-protocol-r1.json', 'candidate-r1', 'candidate-verified-r1.json'))
    sources = proof.source_inventory()
    assert digest(sources) == 'c317190e05e07cf2b824d1fccf70f432a65b809b2ef15b8a1ad13697b52171bf'
    closed = read(CLOSEOUT)
    source_paths = ('shardloom-cli/src/sql_local_source_runtime.rs',
        'shardloom-vortex/src/local_primitive_relational_aggregate_bind.rs')
    code = {}
    for name in source_paths:
        old = closed['repository_source_snapshot'][name]
        original = OUT / 'source-blobs' / old['sha256']
        assert content(original) == old
        code[name] = (original.read_bytes(), (W / name).read_bytes())
    parser = [rust_function(raw, 'fn parse_cast_target_dtype(') for raw in code[source_paths[0]]]
    assert parser[0] == parser[1]
    assert '"uint64" => Ok(LogicalDType::UInt64)' in parser[0] and 'ubigint' not in parser[0].lower()
    reducer = [rust_function(raw, 'pub(super) fn reduction_dtype(') for raw in code[source_paths[1]]]
    assert reducer[0] == reducer[1]
    assert 'Function::Sum | Function::Avg | Function::SumDistinct | Function::AvgDistinct' in reducer[0]
    assert 'Some(DType::Primitive(_, _)) => DType::Primitive(PType::F64, Nullability::Nullable)' in reducer[0]
    adapter_path = FROZEN / 'benchmarks/traditional_analytics/query_surface/adapters.py'
    assert '"uint64": "UBIGINT"' in adapter_path.read_text()
    protocol = read(OUT / 'baseline-protocol-r1.json')
    result = read(OUT / 'baseline-verified-r1.json')
    assert result['status'] == 'failed_baseline_cohort' and not result['complete_performance_result_valid']
    assert result['engine_execution_seconds'] is None and result['query_executions_during_replay'] == 0
    assert result['outcomes'] == {'passed':2483, 'engine_rejected':15, 'engine_error':30, 'incorrect':15}
    assert result['new_outcomes'] == {'passed':2324, 'engine_rejected':15, 'engine_error':30, 'incorrect':15}
    replay = read(OUT / 'baseline-replay-r1.json')
    assert replay['status'] == 'failed' and replay['returncode'] == 1
    assert replay['process_group_drained'] and replay['direct_child_reaped']
    assert replay['fixed_source_validation'] and replay['build_sources'] == sources
    assert 'failed observations preserved; no complete performance score admitted' in (OUT / 'baseline-replay-r1.log').read_text()
    proof.guarded(OUT / 'baseline-missing-r1.json', [proof.PYTHON, '-B', str(OUT / 'tools/run_direct_count.py'), '--role', 'baseline'], sources, query=True)
    cases = Cases()
    with gzip.open(OUT / 'baseline-cases-r1.jsonl.gz', 'rt') as stream:
        rows = [json.loads(line) for line in stream]
    assert len(rows) == 2543 and len({row['id'] for row in rows}) == 2543
    assert Counter(row['result']['status'] for row in rows if row['kind'] == 'original') == {'passed':2258}
    assert Counter(row['result']['status'] for row in rows if row['kind'] == 'composition') == {'passed':225, 'engine_rejected':15, 'engine_error':30, 'incorrect':15}
    compact = {row['id']:row for row in rows}
    observed, categories = [], Counter()
    db_path = OUT / 'baseline-missing-r1/attempts.sqlite'
    db = sqlite3.connect('file:' + str(db_path) + '?mode=ro', uri=True)
    try:
        db.execute('PRAGMA query_only=ON')
        assert db.execute('PRAGMA integrity_check').fetchone() == ('ok',)
        for seq, case_id, status, raw in db.execute("SELECT seq,id,status,packet FROM attempt WHERE status != 'passed' ORDER BY seq"):
            packet = json.loads(zlib.decompress(raw))
            job = json.loads(packet['files']['one.job.json']['utf8'])
            case = job['case']
            assert protocol['cases'][seq]['case'] == case and case['id'] == case_id
            assert compact[case_id]['result']['status'] == status == packet['classified_status']
            assert compact[case_id]['provenance']['packet'] == dict(bytes=len(raw), sha256=__import__('hashlib').sha256(raw).hexdigest())
            assert 'direct_count_version' in case
            record = dict(id=case_id, case_identity=case['case_identity'], baseline_seq=seq,
                cohort_ordinal=compact[case_id]['cohort_ordinal'], scenario=case['archetype'],
                surface=case['surface'], native_format=case['native_format'], profile=case['profile'],
                original_status=status, detail=packet['classification_detail'],
                packet=compact[case_id]['provenance']['packet'])
            if case['archetype'].startswith('uint64_'):
                assert case['surface'] in ('cli_sql', 'embedded_workflow', 'python_sql')
                assert status == ('engine_rejected' if case['surface'] == 'cli_sql' else 'engine_error')
                assert 'CAST target dtype must be' in record['detail']
                assert 'no fallback execution was attempted' in record['detail']
                sql = adapters.relation_sql(cases.item(case).relation, job['sources'])
                assert ' AS UBIGINT)' in sql
                record.update(category='frozen_adapter_unsigned_sql_spelling', regenerated_sql=sql,
                    admitted_engine_spelling='uint64', emitted_adapter_spelling='UBIGINT')
            else:
                assert case['archetype'] == 'mixed_measure' and status == 'incorrect'
                output = json.loads(packet['files']['one.stdout.json']['utf8'])
                actual, expected = output['actual'], job['expected']
                assert actual['schema'][:2] == expected['schema'][:2] and len(actual['schema']) == len(expected['schema']) == 3
                assert expected['schema'][2] == dict(name='total', type=dict(name='int64', nullable=True, parameters=[]))
                assert actual['schema'][2] == dict(name='total', type=dict(name='float64', nullable=True, parameters=[]))
                assert len(actual['rows']) == len(expected['rows'])
                for actual_row, expected_row in zip(actual['rows'], expected['rows'], strict=True):
                    assert actual_row.keys() == expected_row.keys() == {'k','n','total'}
                    assert actual_row['k'] == expected_row['k'] and actual_row['n'] == expected_row['n']
                    assert abs(expected_row['total']) < 2**53
                    assert float.fromhex(actual_row['total']) == expected_row['total']
                record.update(category='new_mixed_sum_declared_result_dtype', expected_dtype='int64',
                    native_dtype='float64', complete_numeric_values_match=True,
                    original_schema_mismatch_preserved=True)
            categories[record['category']] += 1
            observed.append(record)
    finally:
        db.close()
    assert len(observed) == 60 and categories == {'frozen_adapter_unsigned_sql_spelling':45, 'new_mixed_sum_declared_result_dtype':15}
    assert not any(name == 'shardloom._native' or name.startswith('shardloom._native.') for name in sys.modules)
    assert proof.source_inventory() == sources
    report = dict(schema='shardloom.direct_count_baseline_failure.v1', status='verified_invalid_baseline',
        source_fingerprint_sha256=digest(sources), accepted_repository=identity(CLOSEOUT),
        baseline_result=identity(OUT / 'baseline-verified-r1.json'), baseline_protocol=identity(OUT / 'baseline-protocol-r1.json'),
        baseline_ledger=identity(db_path), case_rows=identity(OUT / 'baseline-cases-r1.jsonl.gz'),
        original_controls=2258, original_controls_passed=2258, new_controls=285, new_controls_passed=225,
        outcomes=result['outcomes'], failures=observed, failure_categories=dict(categories),
        engine_execution_seconds=None, complete_performance_result_valid=False,
        scored_candidate_query_executions=0, candidate_protocol_present=False,
        native_queries_executed_by_audit=0, original_results_and_references_unchanged=True,
        failure_disposition='Preserve the invalid baseline and restore accepted runtime sources for a clean PR checkpoint; B remains pending a versioned harness correction and complete candidate comparison.',
        source_evidence={name:dict(accepted=closed['repository_source_snapshot'][name], current=sources[name],
            inspected_function='parse_cast_target_dtype' if name==source_paths[0] else 'reduction_dtype', relevant_function_unchanged=True) for name in source_paths},
        adapter=identity(adapter_path), candidate_validation=identity(OUT / 'candidate-validation-r1.json'),
        corrective_contract=['Keep all original failed packets and their invalid aggregate status.',
            'Version the unsigned native SQL spelling as uint64 without changing the intended typed relation or input population.',
            'Version mixed COUNT/SUM output as nullable Float64 with independently regenerated expected values.',
            'Prove literal unchanged-request and compatible-runtime reuse; no blanket reuse or silent repeat.',
            'Freeze the corrected protocol before new observations; preserve the single fixed runtime candidate and complete-cohort decision rule.'])
    write(OUT / 'baseline-admission-failure-r1.json', report)
    print(json.dumps({key:report[key] for key in ('status','outcomes','failure_categories','engine_execution_seconds','scored_candidate_query_executions')}))


if __name__ == '__main__':
    main()
