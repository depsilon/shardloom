"""Independent complete COUNT references from frozen IPC input rows."""
from collections import Counter
from contextlib import closing
import hashlib
import json
from pathlib import Path
import sqlite3
import sys

from direct_count_common import (CLIENT, E, FROZEN, OUT, REFERENCE, SELECTION,
    accepted_runtime, content, digest, inputs_and_client, read, worker, write)
from direct_count_reference_inputs import Inputs
from query_surface.evidence import identity
from query_surface.expanded_freeze import pack, unpack
from query_surface.expanded_run import verify
from query_surface.semantics import compare, result_from_record, result_record
from resources import BenchmarkGuard


def main():
    assert __debug__ and OUT == Path('/Users/dylan/LocalData/shardloom/direct-count-bridge-2026-11-12')
    assert not REFERENCE.parent.exists()
    _, closed = accepted_runtime()
    _, inputs, _, frozen, _ = inputs_and_client()
    selection = read(SELECTION)
    assert selection['selected_requests'] == len(selection['cases']) == 2543
    new = [row for row in selection['cases'] if row['kind'] == 'composition']
    assert len(new) == selection['new_declarations'] == 285
    checked_path = OUT / 'client-check-r1.json'
    checked = read(checked_path)
    assert checked['status'] == 'passed_public_declaration_construction'
    assert checked['declarations'] == 285 and checked['query_executions'] == 0
    assert checked['source_bindings_unchanged']
    for name, expected in checked['sources'].items():
        assert content(Path(name)) == expected
    paths = [Path(__file__), SELECTION, checked_path, OUT / 'tools/direct_count_common.py',
        OUT / 'tools/direct_count_reference_inputs.py', CLIENT / 'direct_count_cases.py',
        CLIENT / 'direct_count_worker.py', *(Path(name) for name in checked['sources'])]
    proof = {str(path): identity(path) for path in sorted(set(paths))}
    result = dict(schema='shardloom.direct_count_reference.v1', status='failed',
        selection=identity(SELECTION), generator=identity(Path(__file__)),
        accepted_runtime_source_fingerprint_sha256=closed['source_fingerprint_sha256'],
        independent_boundary='Frozen IPC input transport and exact Python integer grouping/count/sum; no native output or external query engine',
        native_query_executions=0, native_runtime_loaded=False,
        comparison_engine_benchmark_runs=0, profiles={}, rows=[])
    REFERENCE.parent.mkdir()
    try:
        with BenchmarkGuard(REFERENCE.parent, binary=Path('shardloom'), memory_gb=2) as guard, closing(sqlite3.connect(REFERENCE)) as db:
            db.execute('PRAGMA journal_mode=DELETE')
            db.execute('CREATE TABLE expected (id TEXT PRIMARY KEY, identity TEXT NOT NULL, value BLOB NOT NULL)')
            for profile in ('smoke', 'holdout', 'primary', 'scale'):
                group = [row for row in new if row['case']['profile'] == profile]
                assert len(group) == Counter(row['case']['profile'] for row in new)[profile]
                source = Inputs(inputs, profile, guard)
                answers, count = worker.declarations.reference_grid(source.rows('fact', worker.declarations.INPUT_COLUMNS))
                assert count == source.declared['spec']['fact_rows'] and len(answers) == 19
                blobs = {}
                for name, expected in answers.items():
                    document = result_record(expected)
                    blob = pack(document)
                    scenario = next(row for row in worker.declarations.scenarios() if row['name'] == name)
                    contract = worker.declarations.ResultContract(expected.schema, ordered=scenario['order'] != 'none')
                    compare(expected, result_from_record(unpack(blob)), contract)
                    blobs[name] = (expected, document, blob)
                for row in group:
                    case = row['case']
                    expected, document, blob = blobs[case['declaration']['scenario']['name']]
                    compare(expected, expected, worker.declarations.contract(case))
                    db.execute('INSERT INTO expected VALUES (?,?,?)', (case['id'], case['case_identity'], blob))
                    result['rows'].append(dict(ordinal=row['cohort_ordinal'], id=case['id'],
                        identity=case['case_identity'], origin='independent_python_count',
                        result_rows=len(expected.rows), document_sha256=digest(document),
                        blob_bytes=len(blob), blob_sha256=hashlib.sha256(blob).hexdigest()))
                db.commit()
                source.verify_generations()
                result['profiles'][profile] = dict(cases=len(group), independent_scenarios=len(answers),
                    input_rows=count, physical_layout=source.declared['layout'],
                    complete_fact_id_domain_verified=True, logical_identity=source.declared['logical_identity'])
                print(json.dumps(dict(reference_profile=profile, complete_cases=len(result['rows']), native_query_executions=0)), flush=True)
                del source, answers, blobs
            assert db.execute('PRAGMA integrity_check').fetchone() == ('ok',)
            assert db.execute('SELECT COUNT(*) FROM expected').fetchone() == (285,)
            assert len(result['rows']) == len({row['id'] for row in result['rows']}) == 285
            for row in result['rows']:
                entry = db.execute('SELECT identity,value FROM expected WHERE id=?', (row['id'],)).fetchone()
                assert entry[0] == row['identity'] and hashlib.sha256(entry[1]).hexdigest() == row['blob_sha256']
            guard.check()
            result['resource_observations'] = guard.samples
        verify(frozen)
        assert all(identity(Path(name)) == expected for name, expected in proof.items())
        assert not any(name == 'shardloom._native' or name.startswith('_polars_runtime') for name in sys.modules)
        result['rows'].sort(key=lambda row: row['ordinal'])
        assert {row['ordinal'] for row in result['rows']} == {row['cohort_ordinal'] for row in new}
        result.update(status='passed_independent_references', cases=285, new_cases=285,
            original_controls=2258, original_control_references='unchanged frozen per-profile references',
            expected=identity(REFERENCE), proof=proof, frozen_inputs_and_client=frozen,
            input_and_client_hashes_unchanged=True, complete_scoring_protocol_frozen=False)
    except BaseException as error:
        result['error'] = type(error).__name__ + ': ' + str(error)
        if 'guard' in locals():
            result['resource_observations'] = guard.samples
        raise
    finally:
        write(REFERENCE.parent / 'complete.json', result)
    print(json.dumps({key: result[key] for key in ('status', 'cases', 'new_cases', 'native_query_executions')}))


if __name__ == '__main__':
    main()
