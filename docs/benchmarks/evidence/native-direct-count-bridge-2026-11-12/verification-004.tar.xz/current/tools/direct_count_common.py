"""COUNT preparation/replay through the established request and result contracts."""
import json
from pathlib import Path
import sys
from types import SimpleNamespace

OUT = Path(__file__).resolve().parents[1]
J = Path('/Users/dylan/LocalData/shardloom/join-mapping-2026-11-11')
S = J.parent / 'shared-operator-state-2026-11-10'
T = J.parent / 'shared-window-state-2026-11-11'
D = J.parent / 'rolling-distinct-2026-11-11'
E = J.parent / 'expanded-query-2026-11-03'
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
FROZEN = E / 'investigation-original-harness-r1'
CLIENT = OUT / 'client'
SELECTION = OUT / 'cohort-selection-r1.json'
REFERENCE = OUT / 'references-r1/expectations.sqlite'
CLOSEOUT = J / 'join-mapping-closeout-r1.json'
CLOSEOUT_SHA256 = 'e34f1128c33c78f634fdfd03e30cc1c5a53f328b060f011f1a53300bc2c64936'
TREE = 'ef1ebe017aaedcc858098106480f20c5ff82a102'
MERGE = '3a0608b12e40435fab1adc4afefbaa4173932737'
sys.path[:0] = [str(CLIENT), str(J / 'tools')]
import join_mapping_common as predecessor
from join_mapping_common import content, database, digest, read
import direct_count_worker as worker
from query_surface import adapters
from query_surface.evidence import identity
from query_surface.expanded_run import verify

previous, old_proof = predecessor.previous, predecessor.old_proof


def accepted_runtime():
    runtime, prior = predecessor.accepted_runtime()
    assert content(CLOSEOUT)['sha256'] == CLOSEOUT_SHA256
    closed = read(CLOSEOUT)
    assert closed['schema'] == 'shardloom.join_mapping_closeout.v1'
    assert closed['status'] == 'complete'
    assert closed['merge_commit'] == MERGE and closed['source_tree'] == TREE
    assert closed['pr_head'] == '55d940e879a4567b21fe4c0c3d64a35ef35664d6'
    assert closed['pr_checks_passed'] == 58 and closed['main_checks_passed'] == 55
    assert closed['review_findings'] is False and closed['working_tree_clean']
    assert closed['runtime_sources_match_build'] and closed['current_inputs_unchanged']
    assert closed['source_bound_replay'] == closed['portable_replay_after_retirement'] == 'passed'
    assert closed['disposition'] == 'drop_candidate_no_gain'
    assert closed['predecessor_closeout'] == dict(path=str(predecessor.CLOSEOUT),
        identity=content(predecessor.CLOSEOUT))
    assert closed['retained_runtime'] == prior['retained_runtime']
    assert closed['source_fingerprint_sha256'] == prior['source_fingerprint_sha256']
    assert closed['complete_repository_source_equals_runtime_build'] is False
    assert closed['repository_source_fingerprint_sha256'] == 'f3b5df1f92c9948a1aa5a3c3ab7655370fec7b807d942c19596ae586a2bfbbd5'
    assert digest(closed['repository_source_snapshot']) == closed['repository_source_fingerprint_sha256']
    differences = closed['repository_differences_from_runtime_build']
    assert set(differences) == {
        'docs/architecture/local-development-storage.md',
        'docs/architecture/native-join-payload-mapping-2026-11-12.md',
        'docs/architecture/native-rolling-distinct-2026-11-11.md',
        'docs/architecture/native-shared-index-metadata-2026-11-10.md',
        'docs/architecture/native-shared-pipeline-investigations-2026-11-10.md',
        'docs/architecture/native-shared-window-state-2026-11-11.md',
        'docs/architecture/native-structural-work-investigations-2026-11-11.md',
        'docs/architecture/phased-execution-plan.md',
        'scripts/ci_native_tests.py', 'scripts/test_ci_native_tests.py'}
    for name, correction in closed['independent_ci_cleanup_fix'].items():
        assert correction['before'] == differences[name]['runtime']
        assert correction['after'] == differences[name]['repository'] == closed['repository_source_snapshot'][name]
    for name, expected in closed['retained_runtime'].items():
        assert content(Path(name)) == expected
    return runtime, closed


def inputs_and_client():
    return predecessor.inputs_and_client()


class Cases(old_proof.Cases):
    def item(self, case):
        if 'direct_count_version' in case:
            plan = worker.declarations.validate(case)
            return SimpleNamespace(identity=case['case_identity'], relation=plan,
                contract=worker.declarations.contract(case))
        return super().item(case)


def replay_case(entry, case, expected, item, inputs, prepared, policy):
    result = old_proof.replay(entry, case, 'native', expected, item, inputs, prepared, policy)
    if result['status'] == 'passed' or result['engine_seconds'] is not None:
        old_proof.verify_clock(entry, result)
    if result['status'] in {'passed', 'incorrect', 'comparison_inconclusive'} and not result.get('delivered_invalid_result'):
        raw = old_proof.raw_files(old_proof.unpack(entry[3]))
        job = json.loads(raw['one.job.json'])
        report = json.loads(raw['one.stdout.json'])['observation']
        assert report['sql_declaration'] == adapters.relation_sql(item.relation, job['sources'])
        assert report['sql_declaration_submitted'] == (case['surface'] in {'cli_sql', 'embedded_workflow', 'python_sql'})
        assert report['execution_mode'] == 'first_query_fresh_session'
    return result


def verify_capture():
    old_proof.verify_capture()
    template = S / 'window-tools-draft/capture_window_cohort.py'
    source = template.read_text()
    source = source[source.index('from __future__'):]
    before = 'TARGET_NAME = "window-baseline-missing-r1"'
    assert source.count(before) == 1 and source.count('"window_composition_version"') == 2
    wanted = source.replace(before, 'TARGET_NAME = "direct-count-baseline-missing-r1"')
    wanted = wanted.replace('"window_composition_version"', '"direct_count_version"')
    path = OUT / 'tools/capture_direct_count.py'
    actual = path.read_text()
    assert actual[actual.index('from __future__'):] == wanted
    return dict(original=identity(template), versioned=identity(path),
        capture_changes=['COUNT target label', 'COUNT composition marker for independent references'],
        per_query_supervision_unchanged=True, request_builder_unchanged=True,
        engine_clock_check_unchanged=True, cleanup_and_result_retention_unchanged=True)


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
