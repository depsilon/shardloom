"""Freeze and execute one accepted baseline / fixed COUNT candidate cohort."""
import argparse
from contextlib import ExitStack
import hashlib
import json
import os
from pathlib import Path
import sys

import direct_count_common as common
import direct_count_proof as proof
import capture_direct_count as capture
from audit_direct_count_reuse import references, case_reference
from direct_count_common import (CLIENT, CLOSEOUT, E, FROZEN, OUT, REFERENCE, SELECTION,
    W, Cases, accepted_runtime, content, digest, read, write)
from query_surface.evidence import identity
from query_surface.expanded_run import request, verify

PYTHON = proof.PYTHON
WORKER = CLIENT / 'direct_count_worker.py'
REUSE = OUT / 'baseline-reuse-r1.json'
VALIDATION = OUT / 'candidate-validation-r1.json'


def target(role):
    assert role in ('baseline', 'candidate')
    return OUT / ('baseline-missing-r1' if role == 'baseline' else 'candidate-r1')


def protocol_path(role):
    assert role in ('baseline', 'candidate')
    return OUT / (role + '-protocol-r1.json')


def context():
    runtime, closed = accepted_runtime()
    design, inputs, prepared, frozen, historical = common.inputs_and_client()
    selection = read(SELECTION)
    assert selection['status'] == 'frozen_before_scoring'
    assert selection['selected_requests'] == len(selection['cases']) == 2543
    assert selection['saved_count_requests'] == 2098 and selection['no_count_neighbors'] == 160
    assert selection['new_declarations'] == 285 and selection['query_executions'] == 0
    assert not selection['selection_uses_timing']
    assert len({row['case']['id'] for row in selection['cases']}) == 2543
    assert len({row['case']['case_identity'] for row in selection['cases']}) == 2543
    for ordinal, row in enumerate(selection['cases']):
        assert row['cohort_ordinal'] == ordinal
        if row['kind'] == 'original':
            assert row['case'] == design['cases'][row['original_seq']]
        else:
            assert row['kind'] == 'composition' and row['original_seq'] is None
            common.worker.declarations.validate(row['case'])
    references_done = read(REFERENCE.parent / 'complete.json')
    assert references_done['status'] == 'passed_independent_references'
    assert references_done['cases'] == references_done['new_cases'] == 285
    assert references_done['original_controls'] == 2258
    assert references_done['native_query_executions'] == 0 and not references_done['native_runtime_loaded']
    assert references_done['expected'] == identity(REFERENCE) and references_done['input_and_client_hashes_unchanged']
    verify(list(references_done['proof'].values()))
    client = read(OUT / 'client-check-r1.json')
    assert client['status'] == 'passed_public_declaration_construction'
    assert client['declarations'] == 285 and client['query_executions'] == 0
    assert client['source_bindings_unchanged'] and client['frozen_client_files'] == 65
    for name, expected in client['sources'].items():
        assert content(Path(name)) == expected
    reuse = read(REUSE)
    assert reuse['status'] == 'passed_exact_complete_reuse_audit'
    assert reuse['selection'] == identity(SELECTION) and reuse['runtime'] == runtime
    assert reuse['source_fingerprint_sha256'] == closed['source_fingerprint_sha256']
    assert reuse['complete_requests_verified'] == len(reuse['requests']) == 2543
    assert reuse['selected_reused_cases'] == 159 and reuse['missing_cases'] == 2384
    assert reuse['query_executions'] == 0 and reuse['original_observations_preserved']
    verify([reuse['reused_database'], *reuse['original_archive_files']])
    with ExitStack() as stack:
        refs, cases = references(stack, selection), Cases()
        next_missing = 0
        for selected, declared in zip(selection['cases'], reuse['requests'], strict=True):
            case = selected['case']
            assert selected['cohort_ordinal'] == declared['cohort_ordinal']
            assert declared['id'] == case['id'] and declared['case_identity'] == case['case_identity']
            _, reference, expected = case_reference(refs, selected, cases)
            assert hashlib.sha256(reference[1]).hexdigest() == declared['reference_blob_sha256']
            assert digest(request(case, 'native', dict(inputs, runtime=runtime), prepared,
                expected, design['execution'])) == declared['request_sha256']
            if declared['reused']:
                assert declared['reused_seq'] == selected['cohort_ordinal'] and declared['missing_seq'] is None
            else:
                assert declared['missing_seq'] == next_missing
                next_missing += 1
        assert next_missing == 2384
    validation = read(VALIDATION)
    assert validation['status'] == 'passed_fixed_candidate_validation'
    assert validation['diagnostic_requests'] == 19 and validation['native_test_count'] == 4144
    assert validation['ignored_tests'] == 36 and not validation['candidate_acceptance_claimed']
    assert not validation['scored_performance_claim'] and not validation['whole_process_memory_claim']
    sources = proof.source_inventory()
    assert validation['source_fingerprint_sha256'] == digest(sources)
    build, _ = proof.guarded(OUT / 'candidate-release-build-r1.json', proof.BUILD_COMMAND, sources)
    assert validation['build'] == identity(OUT / 'candidate-release-build-r1.json')
    assert validation['source_head'] == build['head']
    verify(validation['proof_files'])
    candidate_runtime = dict(binary=identity(OUT / 'runtime-r1/shardloom'),
        library=identity(OUT / 'runtime-r1/_native.abi3.so'))
    assert candidate_runtime['binary']['sha256'] != runtime['binary']['sha256']
    assert candidate_runtime['library']['sha256'] != runtime['library']['sha256']
    files = [SELECTION, REUSE, REFERENCE, REFERENCE.parent / 'complete.json', CLOSEOUT, VALIDATION,
        OUT / 'design-r1.md', OUT / 'candidate-design-r1.md', OUT / 'cohort-design-r1.md',
        OUT / 'client-check-r1.json', OUT / 'declaration-controls-r2.json',
        OUT / 'declaration-controls-r1-overwrite-clarification.json',
        OUT / 'count-cohort-pools-r1.json', OUT / 'count-cohort-pools-primary-verification-r1.json',
        Path(reuse['reused_database']['path']), CLIENT / 'direct_count_cases.py', WORKER]
    files.extend(OUT / 'tools' / name for name in (
        'guard_direct_count.py', 'direct_count_common.py', 'direct_count_proof.py',
        'capture_direct_count.py', 'run_direct_count.py', 'replay_direct_count.py',
        'plan_direct_count.py', 'check_direct_count_declarations.py', 'check_direct_count_clients.py',
        'prepare_direct_count_references.py', 'direct_count_reference_inputs.py',
        'audit_direct_count_reuse.py', 'verify_direct_count_candidate.py'))
    files.extend(Path(name) for name in client['sources'])
    files.extend(Path(item['path']) for item in validation['proof_files'])
    proof_files = [identity(path) for path in sorted(set(files))]
    unique = {}
    for item in [*frozen, *proof_files, *runtime.values(), *candidate_runtime.values()]:
        if item['path'] in unique:
            assert unique[item['path']] == item
        unique[item['path']] = item
    frozen = list(unique.values())
    verify(frozen)
    return dict(design=design, inputs=inputs, prepared=prepared, runtime=runtime,
        candidate_runtime=candidate_runtime, closeout=closed, selection=selection, reuse=reuse,
        validation=validation, build=build, frozen=frozen, proof_files=proof_files, historical=historical)


def admission(root, role, require_protocol=True):
    assert __debug__ and root == E
    ctx = context()
    selected = ctx['selection']['cases']
    cases = ([row for row, reused in zip(selected, ctx['reuse']['requests'], strict=True)
        if not reused['reused']] if role == 'baseline' else selected)
    assert len(cases) == (2384 if role == 'baseline' else 2543)
    runtime = ctx['runtime'] if role == 'baseline' else ctx['candidate_runtime']
    binding = dict(schema='shardloom.direct_count_runtime.v1', role=role,
        accepted_merge=ctx['closeout']['merge_commit'], source_root=str(W),
        source_head=ctx['build']['head'],
        source_fingerprint_sha256=(ctx['closeout']['source_fingerprint_sha256']
            if role == 'baseline' else ctx['build']['build_source_fingerprint_sha256']),
        candidate_source_fingerprint_sha256=ctx['build']['build_source_fingerprint_sha256'],
        accepted_closeout=identity(CLOSEOUT), runtime=runtime, proof_files=ctx['proof_files'],
        candidate_validation=identity(VALIDATION), candidate_runtime=ctx['candidate_runtime'],
        selection=identity(SELECTION), saved_reuse=identity(REUSE), target=str(target(role)),
        parent_interpreter=identity(Path(PYTHON).resolve()), versioned_worker=identity(WORKER),
        original_worker=identity(FROZEN / 'benchmarks/traditional_analytics/query_surface/expanded_worker.py'),
        composition_reference=identity(REFERENCE), frozen_harness_files=65,
        attempts_per_case=1, warmups=0, requested_repeats=0, fallback_allowed=False)
    protocol = dict(schema='shardloom.direct_count_protocol.v1', role=role,
        status='frozen_before_new_queries', selected_count=2543, original_controls=2258,
        saved_count_requests=2098, no_count_neighbors=160, new_compositions=285,
        reused_count=159 if role == 'baseline' else 0,
        new_attempts=len(cases), selection=identity(SELECTION), cases=cases,
        candidate_contract=dict(stage='source_and_release_runtime_fixed_before_any_new_scored_query',
            design=identity(OUT / 'design-r1.md'), candidate_design=identity(OUT / 'candidate-design-r1.md'),
            cohort=identity(OUT / 'cohort-design-r1.md'), validation=identity(VALIDATION),
            runtime=ctx['candidate_runtime'], source_fingerprint_sha256=ctx['validation']['source_fingerprint_sha256'],
            candidate_count=1, tuning='no case, eligibility, source, runtime, or constant changes after scoring'),
        design=identity(E / 'design.json'), inputs=identity(E / 'inputs.json'), frozen=identity(E / 'frozen.json'),
        execution=ctx['design']['execution'], runtime_binding=binding, reuse=identity(REUSE),
        primary_clock='engine_execution_seconds', attempts_per_case=1, warmups=0, requested_repeats=0,
        selection_uses_timing=False, complete_10k_performance_claim=False, full43_claim=False,
        capture_changes=common.verify_capture(),
        supervision_change='Closed predecessor and fixed COUNT declarations/references; per-query supervisor, limits, deadlines and cleanup unchanged.',
        isolation='All other task work and agents idle; no profiling, repeats, warmup, cache manipulation or pacing.',
        performance_decision='All 2543 correct with resource/ownership/no-fallback proof; strictly lower complete engine sum retains, equal/higher drops.')
    if role == 'candidate':
        base_path = protocol_path('baseline')
        baseline_protocol = read(base_path)
        assert baseline_protocol['candidate_contract'] == protocol['candidate_contract']
        baseline_path = OUT / 'baseline-verified-r1.json'
        baseline = read(baseline_path)
        assert baseline['status'] == 'passed_complete_baseline_cohort'
        assert baseline['selected_cases'] == 2543 and baseline['outcomes'] == {'passed': 2543}
        assert baseline['new_attempts'] == 2384 and baseline['reused_saved_cases'] == 159
        assert baseline['complete_performance_result_valid'] and baseline['all_selected_results_correct']
        assert baseline['all_engine_clocks_valid'] and baseline['native_no_fallback']
        assert baseline['protocol'] == identity(base_path) and baseline['selection'] == identity(SELECTION)
        verify([baseline[key] for key in ('case_rows', 'guard', 'complete', 'ledger', 'reuse', 'reused_database')])
        protocol.update(baseline_protocol=identity(base_path), baseline_result=identity(baseline_path))
        ctx['frozen'].extend([identity(base_path), identity(baseline_path), baseline['case_rows']])
    path = protocol_path(role)
    if require_protocol:
        assert read(path) == protocol
    else:
        assert not path.exists() and not target(role).exists()
        write(path, protocol)
    frozen = [*ctx['frozen'], identity(path)]
    verify(frozen)
    return ctx['design'], dict(ctx['inputs'], runtime=runtime), frozen, binding


def main():
    assert Path(__file__).resolve() == OUT / 'tools/run_direct_count.py'
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--role', choices=('baseline', 'candidate'), required=True)
    parser.add_argument('--plan', action='store_true')
    args = parser.parse_args()
    os.environ['POLARS_MAX_THREADS'] = '2'
    for path in (OUT, E):
        capture.require_local_path(path, Path.home(), sys.platform)
    if args.plan:
        admission(E, args.role, require_protocol=False)
        print(json.dumps(dict(status='frozen_before_new_queries', role=args.role,
            selected=2543, new_attempts=2384 if args.role == 'baseline' else 2543, query_executions=0)))
    else:
        protocol = read(protocol_path(args.role))
        capture.TARGET_NAME = str(target(args.role))
        capture.observe(E, False, lambda root: admission(root, args.role), common.previous.HistoricalSubset(),
            [row['case'] for row in protocol['cases']], worker=WORKER, composition_reference=REFERENCE)


if __name__ == '__main__':
    main()
