"""Retire superseded test binaries and reproducible completed release outputs."""
import argparse
import hashlib
import importlib.util
import json
import lzma
import os
from pathlib import Path
import stat
import subprocess

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
ROOTS = (CACHE / 'release', *(OUT / ('diagnostic-debug-r' + str(n)) for n in range(1, 5)),
    OUT / 'diagnostic-release-r1', OUT / 'diagnostic-release-r2')
DEST = OUT / 'preparation-retirement-r1'
HELPER = OUT.parent / 'expanded-query-2026-11-03/tools/retire_shared_intermediates_r2.py'
assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == '19082efec1eaf8df1f894f5047f9efa3c58f1aed206424be3d04c28899b4482e'
spec = importlib.util.spec_from_file_location('retention_primitives', HELPER)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    assert path.is_file() and not path.is_symlink()
    return dict(bytes=path.stat().st_size, sha256=base.sha(path))


def inventory():
    rows, links, hashes = [], {}, {}

    def visit(path):
        before = base.generation(path)
        assert path.lstat().st_uid == os.getuid()
        item = dict(path=str(path), generation=before)
        if stat.S_ISDIR(before[2]):
            rows.append(dict(item, kind='directory'))
            for child in sorted(path.iterdir()):
                visit(child)
        elif stat.S_ISREG(before[2]):
            key = tuple(before[:2])
            links.setdefault(key, []).append(path)
            if key not in hashes:
                hashes[key] = base.sha(path)
            rows.append(dict(item, kind='regular', sha256=hashes[key]))
        elif stat.S_ISLNK(before[2]):
            assert before[6] == 1
            rows.append(dict(item, kind='symlink', target=os.readlink(path)))
        else:
            raise AssertionError('unexpected generated entry: ' + str(path))
        assert base.generation(path) == before

    for root in ROOTS:
        assert root.is_dir() and not root.is_symlink() and root.resolve() == root
        visit(root)
    for paths in links.values():
        assert all(path.lstat().st_nlink == len(paths) for path in paths)
    return rows


def retained():
    observation = read(OUT / 'count-partial-native-tests-r1.json')
    assert observation['status'] == 'failed' and observation['returncode'] == -15
    assert observation['error'] == 'AssertionError: minimum free storage reached'
    assert observation['process_group_drained'] and observation['direct_child_reaped']
    assert observation['log_sha256'] == base.sha(OUT / 'count-partial-native-tests-r1.log')
    expected = dict(observation['protected_runtime_and_wheel'])
    for path in sorted(OUT.rglob('*')):
        if any(path == root or path.is_relative_to(root) for root in ROOTS) or path.is_relative_to(DEST):
            continue
        if path.is_file():
            assert not path.is_symlink()
            expected[str(path)] = identity(path)
    for name, item in expected.items():
        assert not any(Path(name).is_relative_to(root) for root in ROOTS)
        assert identity(Path(name)) == item
    for profile in ('debug', 'release'):
        frozen = read(OUT / f'diagnostic-{profile}-r5-identity.json')
        assert identity(Path(frozen['binary']['path'])) == {k: frozen['binary'][k] for k in ('bytes', 'sha256')}
    proof = read(OUT / 'feasibility-attribution-r1.json')
    assert proof['status'] == 'passed' and proof['queries_executed_by_verifier'] == 0
    for n in range(1, 5):
        assert read(OUT / f'debug-attribution-r{n}-result.json')['status'] == 'failed'
    inputs = observation['input_generations']
    assert len(inputs) == 220 and {name: base.generation(Path(name)) for name in inputs} == inputs
    sources = observation['build_sources']
    for name, item in sources.items():
        path = ROOT / name
        if 'symlink' in item:
            assert path.is_symlink() and os.readlink(path) == item['symlink']
        elif item.get('absent'):
            assert not path.exists()
        else:
            assert identity(path) == item
    debug = {str(path): base.generation(path) for path in sorted((CACHE / 'debug').rglob('*'))}
    env = dict(os.environ, CARGO_TARGET_DIR=str(CACHE))
    metadata = json.loads(subprocess.check_output(['cargo', 'metadata', '--offline', '--locked',
        '--no-deps', '--format-version', '1'], cwd=ROOT, env=env))
    assert metadata['target_directory'] == str(CACHE)
    return dict(files=expected, input_generations=inputs, debug_generations=debug,
        source_fingerprint_sha256=observation['build_source_fingerprint_sha256'])


def plan():
    assert not DEST.exists()
    base.closed(list(map(str, ROOTS)))
    rows = inventory()
    protected = retained()
    DEST.mkdir()
    manifest = dict(roots=list(map(str, ROOTS)), entries=rows, protected=protected)
    raw = lzma.compress(json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode(), preset=6)
    (DEST / 'manifest.json.xz').write_bytes(raw)
    assert json.loads(lzma.decompress(raw)) == manifest
    result = dict(status='planned_no_deletion', roots=list(map(str, ROOTS)), entries=len(rows),
        regular_files=sum(row['kind'] == 'regular' for row in rows),
        regular_bytes=sum(row['generation'][3] for row in rows if row['kind'] == 'regular'),
        symlinks=sum(row['kind'] == 'symlink' for row in rows),
        manifest_sha256=base.sha(DEST / 'manifest.json.xz'), script_sha256=base.sha(Path(__file__)),
        helper_sha256=base.sha(HELPER),
        reason='Native validation stopped at the unchanged free-space floor. Completed release attribution has frozen binaries outside the compiler cache; superseded failed/unexecuted diagnostic binary copies are no longer needed. Preserve every original observation, source snapshot, latest diagnostic binary, current debug cache and accepted production runtime.',
        regeneration='Locked Cargo sources and full source inventories remain. Rebuild completed release artifacts if required; do not rerun saved observations.',
        payload_backup_created=False, storage_limits_changed=False)
    (DEST / 'plan.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)


def apply():
    summary = read(DEST / 'plan.json')
    assert summary['status'] == 'planned_no_deletion' and summary['roots'] == list(map(str, ROOTS))
    assert summary['script_sha256'] == base.sha(Path(__file__)) and summary['helper_sha256'] == base.sha(HELPER)
    assert summary['manifest_sha256'] == base.sha(DEST / 'manifest.json.xz')
    manifest = json.loads(lzma.decompress((DEST / 'manifest.json.xz').read_bytes()))
    assert retained() == manifest['protected']
    base.closed(list(map(str, ROOTS)))
    assert inventory() == manifest['entries']
    base.closed(list(map(str, ROOTS)))
    receipt = dict(status='running', removed=0, manifest_sha256=summary['manifest_sha256'])
    assert not (DEST / 'receipt.json').exists()
    try:
        for row in sorted(manifest['entries'], key=lambda row: len(Path(row['path']).parts), reverse=True):
            path = Path(row['path'])
            assert any(path == root or path.is_relative_to(root) for root in ROOTS)
            actual = base.generation(path)
            if row['kind'] == 'directory':
                assert actual[:3] == row['generation'][:3]
                path.rmdir()
            else:
                assert actual[:5] == row['generation'][:5]
                if row['kind'] == 'regular':
                    assert base.sha(path) == row['sha256']
                else:
                    assert os.readlink(path) == row['target']
                path.unlink()
            receipt['removed'] += 1
        assert all(not root.exists() and not root.is_symlink() for root in ROOTS)
        assert retained() == manifest['protected']
        receipt.update(status='passed', regular_files=summary['regular_files'],
            regular_bytes=summary['regular_bytes'], symlinks=summary['symlinks'],
            accepted_runtime_and_latest_diagnostics_unchanged=True, input_generations_unchanged=True,
            every_original_observation_unchanged=True, debug_cache_unchanged=True,
            payload_backup_created=False, storage_limits_changed=False)
    except BaseException as error:
        receipt.update(status='failed_partial', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        (DEST / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    assert __debug__ and OUT == Path('/Users/dylan/LocalData/shardloom/direct-count-bridge-2026-11-12')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('plan', 'apply'))
    args = parser.parse_args()
    plan() if args.mode == 'plan' else apply()
