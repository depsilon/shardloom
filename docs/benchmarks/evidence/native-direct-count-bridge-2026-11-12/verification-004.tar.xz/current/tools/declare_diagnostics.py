"""Freeze exact saved requests plus versioned COUNT controls before observation."""
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import zlib

from diagnostic_controls import declarations

OUT = Path(__file__).resolve().parents[1]
TMP = Path('/Users/dylan/.codex/tmp')
E = OUT.parent / 'expanded-query-2026-11-03'


def content(path):
    assert path.is_file() and not path.is_symlink()
    before = generation(path)
    with path.open('rb') as stream:
        result = dict(bytes=path.stat().st_size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest())
    assert generation(path) == before
    return result


def generation(path):
    s = path.lstat()
    return [s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_nlink]


def read(path):
    return json.loads(path.read_bytes())


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')


assert __debug__
assert OUT == Path('/Users/dylan/LocalData/shardloom/direct-count-bridge-2026-11-12')
declaration_path = TMP / 'shardloom-direct-count-eleven.json'
lookup_path = TMP / 'shardloom-direct-count-eleven-sources.json'
assert content(declaration_path)['sha256'] == '3ca8a501a7d6fa4132edc33233ad1fdde2f8f8ddf2692b91c9a88882123628b7'
assert content(lookup_path)['sha256'] == 'e74cee35cfeda659bcdd16d29434bd85fae0bbe39424819d8e76057dd0c78e65'
selected = read(declaration_path)
lookup = read(lookup_path)
assert lookup['status'] == 'passed_source_and_reference_lookup' and not lookup['unresolved']
for name, digest in lookup['source_sha256'].items():
    assert content(Path(name))['sha256'] == digest
by_id = {row['case_id']: row for row in lookup['records']}
design = {case['id']: case for case in read(E / 'design.json')['cases']}
latest_generations = read(OUT / 'guard-preparation-r2.json')['input_generations']
binding_path = OUT.parent / 'shared-operator-state-2026-11-10/baseline-generation-binding-r1.json'
assert content(binding_path)['sha256'] == '6be6d1429fd5d0e25a5eea151dbd77925082740e09350b0bf625fae36dc824d5'
binding = read(binding_path)
assert binding['status'] == 'all_contents_and_non_device_generation_fields_equal'
assert binding['permitted_device_change'] == [16777233, 16777234]
historical = {item['historical']['path']: item for item in binding['files']}
assert len(historical) == len(binding['files']) == binding['unique_files']
root = OUT / 'diagnostic-declarations-r3'
assert not root.exists()
root.mkdir()
(root / 'jobs').mkdir()
(root / 'references').mkdir()
for source in (declaration_path, lookup_path,
        TMP / 'shardloom-direct-count-eleven.py', TMP / 'shardloom-direct-count-eleven-sources.py'):
    shutil.copyfile(source, root / source.name)
    assert content(source) == content(root / source.name)
input_files = {}
reference_databases = {}
jobs = []
references = []
for entry in selected['records']:
    saved = entry['saved_declaration']
    case_id = saved['case_id']
    found = by_id[case_id]
    fixed = design[case_id]
    assert saved['case_identity'] == found['case_identity'] == fixed['case_identity']
    for key in ('profile', 'native_format'):
        assert saved[key] == found[key] == fixed[key]
    assert saved['surface'] == fixed['surface']
    assert len(found['source_files']) == len(found['format_fact_source_paths']) == 1
    source = found['source_files'][0]
    path = Path(source['path'])
    assert str(path) == found['format_fact_source_paths'][0]
    if str(path) not in input_files:
        actual = content(path)
        assert actual == dict(bytes=source['declared_generation']['bytes'], sha256=source['declared_sha256'])
        bound = historical[str(path)]
        assert bound['historical'] == dict(path=str(path), generation=source['declared_generation'], sha256=source['declared_sha256'])
        assert bound['symlink_target'] is None
        stat = path.stat()
        assert bound['current'] == dict(path=str(path), sha256=actual['sha256'],
            generation=dict(device=stat.st_dev, inode=stat.st_ino, bytes=stat.st_size,
                mtime_ns=stat.st_mtime_ns, ctime_ns=stat.st_ctime_ns))
        if str(path) in latest_generations:
            assert generation(path) == latest_generations[str(path)]
        input_files[str(path)] = dict(**actual, generation=generation(path))
    reference = found['independent_reference']
    db_path = Path(reference['path'])
    if str(db_path) not in reference_databases:
        actual = content(db_path)
        assert actual['sha256'] == reference['database_sha256_from_closeout']
        reference_databases[str(db_path)] = dict(**actual, generation=generation(db_path))
    with sqlite3.connect(f'file:{db_path}?mode=ro', uri=True) as db:
        identity, blob = db.execute('SELECT identity,value FROM expected WHERE id=?', (case_id,)).fetchone()
    assert identity == saved['case_identity']
    assert len(blob) == reference['compressed_result_bytes']
    assert hashlib.sha256(blob).hexdigest() == reference['compressed_result_sha256']
    expected = json.loads(zlib.decompress(blob))
    assert expected['schema'] == entry['typed_relation_request']['contract']['schema'] == reference['schema']
    assert entry['typed_relation_request']['contract']['ordered'] is True
    relation = entry['typed_relation_request']['relation']
    assert expected['schema'] == [dict(name=name, type=dtype) for name, dtype in relation['schema']]
    blob_path = root / 'references' / (reference['compressed_result_sha256'] + '.zlib')
    if not blob_path.exists():
        blob_path.write_bytes(blob)
    assert blob_path.read_bytes() == blob
    references.append(dict(case_id=case_id, case_identity=identity, database=str(db_path),
        blob=dict(path=str(blob_path), **content(blob_path)), original_reference=reference))
    jobs.append(dict(schema_version='shardloom.direct_count_diagnostic_job.v1',
        case_id=case_id, case_identity=identity, origin='exact_saved_declaration_shared_native_diagnostic',
        original_surface=saved['surface'], diagnostic_surface='shared_prepared_relational',
        profile=saved['profile'], source=dict(format=saved['native_format'], path=str(path)),
        relation=relation, expected_rows=expected['rows'],
        expected_count_contributions='all_selected_rows_nonnullable_argument',
        reference=dict(path=str(blob_path), **content(blob_path))))
assert len(jobs) == 11 and len(by_id) == 11
jobs += declarations()
assert len(jobs) == len({job['case_id'] for job in jobs}) == 19
job_files = []
for job in jobs:
    path = root / 'jobs' / (job['case_id'] + '.json')
    write(path, job)
    assert path.stat().st_size <= 256 * 1024
    job_files.append(dict(case_id=job['case_id'], path=str(path), **content(path)))
manifest = dict(schema_version='shardloom.direct_count_diagnostic_declarations.v1', status='frozen',
    saved_cases=11, versioned_controls=8, total_requests=19, jobs=job_files,
    input_files=input_files, reference_databases=reference_databases, references=references,
    historical_generation_binding=dict(path=str(binding_path), **content(binding_path)),
    inherited_retirement_inventory_files=len(latest_generations),
    inputs_outside_inherited_retirement_inventory=sorted(set(input_files)-set(latest_generations)),
    declaration_inventory=dict(path=str(root / declaration_path.name), **content(root / declaration_path.name)),
    source_lookup_inventory=dict(path=str(root / lookup_path.name), **content(root / lookup_path.name)),
    control_definition=dict(path=str(OUT / 'tools/diagnostic_controls.py'), **content(OUT / 'tools/diagnostic_controls.py')),
    diagnostic_surface='shared_prepared_relational', public_surface_conformance_claim=False,
    query_executions=0, scored=False,
    constraints=['one execution per job per declared observation profile',
        'debug counters are not release timings', 'release attribution is not a scored production baseline',
        'no candidate has been selected', 'independent complete results and ordered schemas required',
        'full source and input hashing only outside active queries',
        'all other task-owned jobs and agents idle during query execution'])
write(OUT / 'diagnostic-declarations-r3.json', manifest)
print(json.dumps(dict(status='frozen', jobs=len(jobs), input_files=len(input_files),
    reference_databases=len(reference_databases), queries=0)))
