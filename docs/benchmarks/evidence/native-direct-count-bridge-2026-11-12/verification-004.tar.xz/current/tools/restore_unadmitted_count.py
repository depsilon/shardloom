"""Restore only the byte-identified COUNT proposal after its invalid baseline."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

from direct_count_common import CLOSEOUT, OUT, W, content, digest, read, write
import direct_count_proof as proof

DESTINATION = OUT / 'source-restoration-r1'
PATCH = OUT / 'candidate-proposal-r1.patch'


def generation(path):
    item = path.lstat()
    return [item.st_dev, item.st_ino, item.st_mode, item.st_size, item.st_mtime_ns, item.st_ctime_ns, item.st_nlink]


def fixed():
    closed = read(CLOSEOUT)
    candidate = read(OUT / 'candidate-release-build-r1.json')
    failure = read(OUT / 'baseline-admission-failure-r1.json')
    assert candidate['status'] == 'passed' and candidate['returncode'] == 0
    assert failure['status'] == 'verified_invalid_baseline' and failure['engine_execution_seconds'] is None
    assert failure['scored_candidate_query_executions'] == 0 and not failure['candidate_protocol_present']
    assert failure['outcomes'] == {'passed':2483, 'engine_rejected':15, 'engine_error':30, 'incorrect':15}
    assert not any((OUT / name).exists() for name in ('candidate-protocol-r1.json', 'candidate-r1', 'candidate-verified-r1.json'))
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip() == closed['merge_commit']
    before, after = candidate['build_sources'], closed['repository_source_snapshot']
    assert digest(before) == failure['source_fingerprint_sha256'] == candidate['build_source_fingerprint_sha256']
    assert digest(after) == closed['repository_source_fingerprint_sha256']
    changes = {name:dict(before=before.get(name), after=after.get(name))
        for name in sorted(set(before) | set(after)) if before.get(name) != after.get(name)}
    reviewed = read(OUT / 'pre-score-source-review-r1.json')['reviewed_changed_files']
    assert changes == {name:dict(before=item['after'], after=item['before']) for name,item in reviewed.items()}
    assert len(changes) == 19
    assert all(name == '.github/ci-native-baseline.json' or name.startswith('shardloom-vortex/src/') for name in changes)
    for item in changes.values():
        for version in item.values():
            if version is not None:
                assert content(OUT / 'source-blobs' / version['sha256']) == version
    inputs = read(OUT / 'baseline-missing-r1.json')['input_generations']
    assert len(inputs) == 220 and {name:generation(Path(name)) for name in inputs} == inputs
    protected = dict(closed['retained_runtime'])
    for item in read(OUT / 'runtime-r1-identity.json')['files']:
        protected[item['path']] = {key:item[key] for key in ('bytes','sha256')}
    for name in ('baseline-protocol-r1.json','baseline-verified-r1.json','baseline-cases-r1.jsonl.gz',
            'baseline-admission-failure-r1.json','candidate-release-build-r1.json','candidate-validation-r1.json'):
        protected[str(OUT / name)] = content(OUT / name)
    assert {name:content(Path(name)) for name in protected} == protected
    return before, after, changes, inputs, protected


def plan():
    assert not DESTINATION.exists() and not PATCH.exists()
    before, after, changes, inputs, protected = fixed()
    assert proof.source_inventory() == before
    tracked = subprocess.check_output(['git', 'diff', '--binary', '--no-ext-diff', 'HEAD', '--', *changes], cwd=W)
    parts = [tracked]
    untracked = [name for name,item in changes.items() if item['after'] is None]
    assert len(untracked) == 4
    for name in untracked:
        result = subprocess.run(['git', 'diff', '--binary', '--no-index', '--', '/dev/null', name], cwd=W, capture_output=True)
        assert result.returncode == 1 and not result.stderr
        parts.append(result.stdout)
    raw = b''.join(parts)
    assert raw.count(b'diff --git ') == len(changes)
    PATCH.write_bytes(raw)
    DESTINATION.mkdir()
    report = dict(schema='shardloom.direct_count_source_restoration.v1', status='planned_no_restoration',
        helper=content(Path(__file__)), source_before_sha256=digest(before), source_after_sha256=digest(after),
        changes=changes, input_generations=inputs, protected=protected, candidate_patch=content(PATCH),
        reason='Invalid fixed baseline; no candidate query or complete gain/loss decision. Preserve proposal and observations; restore accepted sources for requested PR checkpoint.',
        candidate_admitted=False, investigation_b_complete=False, query_executions=0)
    write(DESTINATION / 'plan.json', report)
    print(json.dumps(dict(status=report['status'], paths=len(changes), created_prototype_patch=True)))


def apply():
    plan_path = DESTINATION / 'plan.json'
    record = read(plan_path)
    assert record['status'] == 'planned_no_restoration' and record['helper'] == content(Path(__file__))
    assert record['candidate_patch'] == content(PATCH)
    assert not (DESTINATION / 'receipt.json').exists()
    before, after, changes, inputs, protected = fixed()
    assert proof.source_inventory() == before
    assert record['changes'] == changes and record['input_generations'] == inputs and record['protected'] == protected
    restored = []
    for name,item in changes.items():
        path = W / name
        assert path.is_file() and not path.is_symlink() and content(path) == item['before']
        if item['after'] is None:
            path.unlink()
        else:
            raw = (OUT / 'source-blobs' / item['after']['sha256']).read_bytes()
            assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) == item['after']
            path.write_bytes(raw)
        restored.append(name)
    assert proof.source_inventory() == after
    assert {name:generation(Path(name)) for name in inputs} == inputs
    assert {name:content(Path(name)) for name in protected} == protected
    subprocess.run(['git', 'apply', '--check', str(PATCH)], cwd=W, check=True)
    assert proof.source_inventory() == after
    write(DESTINATION / 'receipt.json', dict(schema=record['schema'], status='passed_exact_source_restoration',
        plan=content(plan_path), restored=restored, source_before_sha256=digest(before), source_after_sha256=digest(after),
        accepted_repository=content(CLOSEOUT), candidate_patch=content(PATCH), candidate_patch_reapplication_check='passed',
        protected_files_unchanged=True, current_inputs_unchanged=True, query_executions=0,
        candidate_admitted=False, investigation_b_complete=False,
        working_tree=subprocess.check_output(['git','status','--porcelain'],cwd=W,text=True)))
    print(json.dumps(dict(status='passed_exact_source_restoration', restored_paths=len(restored), query_executions=0)))


if __name__ == '__main__':
    assert __debug__ and Path(__file__).resolve() == OUT / 'tools/restore_unadmitted_count.py'
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=('plan','apply'))
    globals()[parser.parse_args().action]()
