"""Replay exact accepted-runtime observations before admitting baseline reuse."""
from contextlib import ExitStack, closing
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3

import direct_count_common as common
from direct_count_common import (D, E, J, OUT, REFERENCE, SELECTION, T, W,
    Cases, accepted_runtime, content, database, digest, read, replay_case, write)
from query_surface.evidence import identity
from query_surface.expanded_freeze import unpack
from query_surface.expanded_report import raw_files
from query_surface.expanded_run import request, verify
import verify_join_mapping_packet as archived_join


def references(stack, selection):
    result = {profile: stack.enter_context(database(E / ('reference-' + profile) / 'expectations.sqlite'))
        for profile in {row['case']['profile'] for row in selection['cases']}}
    result['composition'] = stack.enter_context(database(REFERENCE))
    return result


def case_reference(refs, selected, cases):
    case = selected['case']
    item = cases.item(case)
    key = 'composition' if selected['kind'] == 'composition' else case['profile']
    row = refs[key].execute('SELECT identity,value FROM expected WHERE id=?', (case['id'],)).fetchone()
    assert row and row[0] == case['case_identity'] == item.identity
    return item, row, unpack(row[1])


def main():
    assert __debug__ and OUT == Path('/Users/dylan/LocalData/shardloom/direct-count-bridge-2026-11-12')
    destination = OUT / 'baseline-reuse-r1.json'
    reused_db = OUT / 'baseline-reused-r1.sqlite'
    assert not destination.exists() and not reused_db.exists()
    runtime, closed = accepted_runtime()
    design, inputs, prepared, frozen, _ = common.inputs_and_client()
    inputs = dict(inputs, runtime=runtime)
    selection = read(SELECTION)
    assert selection['selected_requests'] == len(selection['cases']) == 2543
    assert selection['saved_count_requests'] == 2098 and selection['no_count_neighbors'] == 160
    assert selection['new_declarations'] == 285 and not selection['selection_uses_timing']
    refs_done = read(REFERENCE.parent / 'complete.json')
    assert refs_done['status'] == 'passed_independent_references' and refs_done['cases'] == 285
    assert refs_done['expected'] == identity(REFERENCE) and refs_done['input_and_client_hashes_unchanged']
    verify(list(refs_done['proof'].values()))
    target = {row['case']['id']: row for row in selection['cases']}
    fields = ('id', 'case_identity', 'profile', 'surface', 'native_format')
    pools, available = [], {}
    definitions = (
        (T, 'candidate', 1212, 'native-shared-window-state-2026-11-11'),
        (D, 'baseline', 1090, 'native-rolling-distinct-2026-11-11'),
        (J, 'baseline', 940, 'native-join-payload-mapping-2026-11-12'))
    for root, role, expected_count, packet_name in definitions:
        packet = W / 'docs/benchmarks/evidence' / packet_name
        acceptance = read(packet / 'acceptance.json')
        members = {row['path']: {key: row[key] for key in ('bytes', 'sha256')} for row in acceptance['members']}
        protocol_path = root / f'{role}-protocol-r1.json'
        result_path = root / f'{role}-verified-r1.json'
        rows_path = root / f'{role}-cases-r1.jsonl.gz'
        for path in (protocol_path, result_path, rows_path):
            assert content(path) == members['current/' + path.name]
        protocol, result = read(protocol_path), read(result_path)
        assert protocol['runtime_binding']['runtime'] == runtime
        assert protocol['runtime_binding']['source_fingerprint_sha256'] == closed['source_fingerprint_sha256']
        assert result['selected_cases'] == expected_count and result['outcomes'] == {'passed': expected_count}
        assert result['complete_performance_result_valid'] and result['case_rows'] == identity(rows_path)
        with gzip.open(rows_path, 'rt') as stream:
            rows = [json.loads(line) for line in stream]
        assert len(rows) == len({row['id'] for row in rows}) == expected_count
        matches = []
        for source_ordinal, row in enumerate(rows):
            if row['id'] not in target:
                continue
            selected = target[row['id']]
            assert all(row[key] == selected['case'][key] for key in fields)
            assert row['id'] not in available and row['result']['status'] == 'passed'
            # Only J intersects this fixed cohort; no inferred reuse from
            # rejected candidate runtimes or older accepted predecessors.
            assert root == J and role == 'baseline'
            available[row['id']] = dict(compact=row, source_ordinal=source_ordinal)
            matches.append(row['id'])
        pools.append(dict(root=str(root), role=role, observed_cases=expected_count,
            protocol=identity(protocol_path), result=identity(result_path), case_rows=identity(rows_path),
            packet_acceptance=identity(packet / 'acceptance.json'), matching_ids=matches))
    assert [len(row['matching_ids']) for row in pools] == [0, 0, 159]
    packet_root = W / 'docs/benchmarks/evidence/native-join-payload-mapping-2026-11-12'
    assert content(packet_root / 'acceptance.json') == closed['committed_evidence'][(packet_root / 'acceptance.json').relative_to(W).as_posix()]
    archived, data = archived_join.read_archive(packet_root)
    packet = archived_join.Packet(archived, data)
    old_protocol = packet.read('current/baseline-protocol-r1.json')
    old_done = packet.read('current/baseline-missing-r1/complete.json')
    old_result = packet.read('current/baseline-verified-r1.json')
    assert old_done['outcomes'] == {'passed': 940} and old_done['posthash_verified']
    assert old_done['updated'] == old_protocol['runtime_binding'] == old_result['runtime_binding']
    assert old_protocol['runtime_binding']['runtime'] == runtime
    assert old_protocol['execution'] == design['execution']
    packet.guard('current/baseline-missing-r1')
    original_bytes = packet.bound(old_done['ledger'])
    assert original_bytes == data['current/baseline-missing-r1/attempts.sqlite']
    requests, reused = [], []
    with ExitStack() as stack:
        refs, cases = references(stack, selection), Cases()
        old_db = stack.enter_context(closing(sqlite3.connect(':memory:')))
        old_db.deserialize(original_bytes)
        old_db.execute('PRAGMA query_only=ON')
        assert old_db.execute('PRAGMA integrity_check').fetchone() == ('ok',)
        assert old_db.execute('SELECT COUNT(*) FROM attempt').fetchone() == (940,)
        out_db = stack.enter_context(closing(sqlite3.connect(reused_db)))
        out_db.execute('PRAGMA journal_mode=DELETE')
        out_db.execute('CREATE TABLE attempt (seq INTEGER PRIMARY KEY, id TEXT UNIQUE NOT NULL, status TEXT NOT NULL, packet BLOB NOT NULL)')
        missing = 0
        for ordinal, selected in enumerate(selection['cases']):
            case = selected['case']
            assert selected['cohort_ordinal'] == ordinal
            item, ref, expected = case_reference(refs, selected, cases)
            job = request(case, 'native', inputs, prepared, expected, design['execution'])
            row = dict(cohort_ordinal=ordinal, id=case['id'], case_identity=case['case_identity'],
                request_sha256=digest(job), reference_blob_sha256=hashlib.sha256(ref[1]).hexdigest())
            saved = available.get(case['id'])
            if saved is None:
                row.update(reused=False, missing_seq=missing)
                missing += 1
            else:
                compact = saved['compact']
                provenance = compact['provenance']
                entry = old_db.execute('SELECT seq,id,status,packet FROM attempt WHERE seq=?',
                    (provenance['source_seq'],)).fetchone()
                assert entry and entry[1:3] == (case['id'], 'passed')
                assert old_protocol['missing_cases'][entry[0]]['case'] == case
                assert provenance['ledger'] == old_done['ledger']['path']
                assert dict(bytes=len(entry[3]), sha256=hashlib.sha256(entry[3]).hexdigest()) == provenance['packet']
                files = raw_files(unpack(entry[3]))
                assert digest(json.loads(files['one.job.json'])) == row['request_sha256']
                assert hashlib.sha256(files['one.job.json']).hexdigest() == provenance['job_sha256']
                assert provenance['independent_expected_blob_sha256'] == row['reference_blob_sha256']
                observed = replay_case(entry, case, expected, item, inputs, prepared, design['execution'])
                assert observed == compact['result'] and observed['status'] == 'passed'
                out_db.execute('INSERT INTO attempt VALUES (?,?,?,?)', (ordinal, *entry[1:]))
                row.update(reused=True, missing_seq=None, reused_seq=ordinal,
                    source_role='accepted_join_mapping_baseline', source_seq=entry[0],
                    source_cohort_ordinal=compact['cohort_ordinal'], packet=provenance['packet'],
                    result=observed, original_provenance=provenance)
                reused.append(ordinal)
            requests.append(row)
        out_db.commit()
        assert out_db.execute('PRAGMA integrity_check').fetchone() == ('ok',)
        assert out_db.execute('SELECT COUNT(*) FROM attempt').fetchone() == (159,)
    assert len(requests) == 2543 and len(reused) == 159 and missing == 2384
    verify(frozen)
    result = dict(schema='shardloom.direct_count_reuse.v1', status='passed_exact_complete_reuse_audit',
        query_executions=0, complete_requests_verified=2543, selected_reused_cases=159,
        missing_cases=2384, inspected_pools=pools, runtime=runtime,
        source_fingerprint_sha256=closed['source_fingerprint_sha256'], selection=identity(SELECTION),
        reused_database=identity(reused_db), requests=requests,
        original_observations_preserved=True, original_ledgers_recreated=False,
        archive_read_boundary='Immutable J archive verified in full; its SQLite ledger deserialized read-only in memory; exact selected packets copied into a new 159-case evidence subset.',
        original_archive_files=[identity(packet_root / row['path']) for row in archived['archives']],
        archive_verifier=identity(Path(archived_join.__file__)), verifier=identity(Path(__file__)))
    write(destination, result)
    print(json.dumps({key: result[key] for key in ('status', 'complete_requests_verified',
        'selected_reused_cases', 'missing_cases', 'query_executions')}))


if __name__ == '__main__':
    main()
