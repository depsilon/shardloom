"""Fixed-source validation shared by COUNT preparation and scored admission."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

from direct_count_common import OUT, W as ROOT, MERGE as BASE, content, digest, read

PYTHON = '/opt/homebrew/opt/python@3.13/libexec/bin/python3'
FEATURES = 'shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment'
BUILD_COMMAND = ['env', 'PYO3_PYTHON=' + PYTHON, 'cargo', 'build', '--offline', '--locked',
    '--release', '--features', 'release-user-surfaces', '-p', 'shardloom-cli', '-p', 'shardloom-python']
DIAGNOSTIC_BUILD_COMMAND = ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-vortex',
    '--lib', '--features', 'release-user-surfaces', '--no-run', '--message-format=json']
REQUIRED_TESTS = [
    'count_partial_prepared_admission_preserves_total_sort_and_source_ties',
    'count_partial_keeps_late_producer_failure_and_does_not_replay',
    'count_partial_keeps_ordered_spill_on_its_existing_owner',
    'count_partial_preserves_every_integer_group_across_physical_inputs',
    'count_partial_checked_weights_reach_all_state_representations',
    'count_partial_declines_nullability_unique_tiny_and_empty_without_state_change',
    'count_partial_optional_capacity_denial_precedes_state_mutation',
    'count_partial_reduced_buffer_denial_and_surviving_child_keep_exact_credits',
    'count_partial_cancellation_does_not_consume_input_or_hide_refunds',
]
CHECKS = {
    'format': ('count-partial-format-r1', ['cargo', 'fmt', '--all', '--', '--check']),
    'default_clippy': ('count-partial-default-clippy-r1', ['cargo', 'clippy', '--offline', '--locked',
        '--workspace', '--all-targets', '--', '-D', 'warnings']),
    'default_tests': ('count-partial-default-tests-r1', ['cargo', 'test', '--offline', '--locked',
        '--workspace', '--all-targets']),
    'native_clippy': ('count-partial-workspace-native-clippy-r1', ['cargo', 'clippy', '--offline', '--locked',
        '--workspace', '--all-targets', '--features', FEATURES, '--', '-D', 'warnings']),
    'native_tests': ('count-partial-native-tests-r2', ['env', 'RUST_TEST_THREADS=4', 'cargo', 'test',
        '--offline', '--locked', '--workspace', '--all-targets', '--features', FEATURES]),
}


def source_inventory():
    paths = set()
    for command in (['git', 'ls-files', '--cached', '-z'], ['git', 'ls-files', '--others', '--exclude-standard', '-z']):
        paths.update(value for value in subprocess.check_output(command, cwd=ROOT).decode().split('\0')
            if value and not value.startswith(('.git/', 'docs/benchmarks/evidence/',
                'docs/release/evidence/', 'docs/dependencies/evidence/')) and '.git' not in Path(value).parts)
    result = {}
    for relative in sorted(paths):
        path = ROOT / relative
        if path.is_symlink():
            target = os.readlink(path)
            result[relative] = dict(symlink=target, sha256=hashlib.sha256(os.fsencode(target)).hexdigest())
        elif path.is_file():
            result[relative] = content(path)
        else:
            assert not path.exists(), relative
            result[relative] = dict(absent=True)
    return result


def validate_guard(record, command, sources, *, query=False):
    assert record['status'] == 'passed' and record['returncode'] == 0
    assert record['command'] == command and record['cwd'] == str(ROOT)
    assert record['head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    assert record['base'] == record['accepted_baseline_merge'] == BASE
    assert record['fixed_source_validation'] and not record['allow_lockfile_update']
    assert record['process_group_drained'] and record['direct_child_reaped']
    assert record['query_workload'] is query
    assert record['build_sources'] == sources
    assert record['build_source_fingerprint_sha256'] == digest(sources)
    for stage in ('pre_execution', 'post_execution'):
        item = record['build_source_verification'][stage]
        assert item['head_matches'] and item['path_set_matches'] and not item['changed_paths']
        assert item['fingerprint_sha256'] == digest(sources)
    driver = OUT / 'tools/guard_direct_count.py'
    assert record['driver_sha256'] == content(driver)['sha256']
    assert record['tool_source_inventory'][str(driver)] == content(driver)
    if query:
        assert record['build_inventory_policy'] == record['evidence_inventory_policy'] == 'before_and_after_only'


def guarded(path, command, sources, *, query=False):
    assert path.parent == OUT
    record = read(path)
    validate_guard(record, command, sources, query=query)
    assert record['log_sha256'] == content(path.with_suffix('.log'))['sha256']
    return record, path.with_suffix('.log').read_text()


def test_results(log):
    summaries = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log, re.MULTILINE)
    assert summaries and all(failed == '0' for _, failed, _ in summaries)
    assert not re.search(r'^test .* \.\.\. FAILED$|^test result: FAILED\.', log, re.MULTILINE)
    return dict(passed=sum(int(row[0]) for row in summaries), ignored=sum(int(row[2]) for row in summaries))


def diagnostic_executable(build_path, sources):
    record, log = guarded(build_path, DIAGNOSTIC_BUILD_COMMAND, sources)
    artifacts = [json.loads(line) for line in log.splitlines() if line.startswith('{')]
    artifacts = [row for row in artifacts if row.get('reason') == 'compiler-artifact'
        and row.get('executable') and row['target']['name'] == 'shardloom_vortex']
    assert len(artifacts) == 1 and artifacts[0]['profile']['test']
    binary = Path(artifacts[0]['executable'])
    assert binary.parent == Path(record['environment']['CARGO_TARGET_DIR']) / 'debug/deps'
    return binary
