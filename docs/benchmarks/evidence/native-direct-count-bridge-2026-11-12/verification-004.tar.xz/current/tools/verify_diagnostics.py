"""Verify immutable complete diagnostic observations and summarize attribution.

No runtime imports or query executions. Instrumented costs are not a scored
baseline, candidate result, cross-profile comparison, or attainable speedup.
"""
from collections import Counter
import hashlib
import json
from pathlib import Path

OUT = Path('/Users/dylan/LocalData/shardloom/direct-count-bridge-2026-11-12')


def identity(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        return dict(bytes=path.stat().st_size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest())


def verified(item):
    path = Path(item['path'])
    assert identity(path) == {key: item[key] for key in ('bytes', 'sha256')}
    return json.loads(path.read_bytes())


def read(name):
    return json.loads((OUT / name).read_bytes())


assert __debug__
profiles = {}
for profile in ('debug', 'release'):
    path = OUT / f'{profile}-attribution-r5-result.json'
    report = read(path.name)
    guard = read(f'{profile}-attribution-r5.json')
    assert guard['status'] == report['status'] == 'passed'
    assert guard['returncode'] == 0 and guard['process_group_drained']
    assert report['before_inputs_verified'] and report['after_inputs_verified']
    assert not report['performance_result'] and not report['complete_10k_claim'] and not report['full43_claim']
    protocol = verified(report['protocol'])
    assert protocol['profile'] == profile and protocol['scored'] is False
    assert protocol['iterations_per_request'] == 1 and protocol['warmups'] == protocol['repeats'] == 0
    declarations = verified(protocol['declarations'])
    build = verified(protocol['build_identity'])
    assert protocol['source_fingerprint_sha256'] == build['build_source_fingerprint_sha256']
    assert identity(Path(protocol['binary']['path'])) == {key: protocol['binary'][key] for key in ('bytes', 'sha256')}
    assert len(report['observations']) == declarations['total_requests'] == 19
    rows = []
    for item, declared in zip(report['observations'], declarations['jobs'], strict=True):
        assert item['case_id'] == declared['case_id'] and item['job'] == declared
        assert item['status'] == 'passed' and item['child_completed'] and item['returncode'] == 0
        assert identity(Path(item['log'])) == item['log_identity']
        observed = verified(item['observation'])
        job = verified(declared)
        assert observed['job'] == job and observed['actual_rows'] == job['expected_rows']
        assert observed['native_io_certified'] and not observed['fallback_attempted'] and not observed['external_engine_invoked']
        assert observed['final_reserved_bytes'] == observed['denied_reservations'] == 0
        assert observed['peak_reserved_bytes'] <= observed['memory_grant_bytes'] == 2 << 30
        assert 0 <= observed['after_prepared_reserved_bytes'] <= observed['after_result_reserved_bytes']
        if job['source']['format'] != 'vortex':
            assert observed['after_result_reserved_bytes'] == observed['initial_reserved_bytes']
            assert observed['retained_source_count'] == observed['after_prepared_reserved_bytes'] == 0
        else:
            assert observed['retained_source_count'] == 1
        phases = {value['phase']: value['exclusive_nanos'] for value in observed['phases']}
        assert len(phases) == len(observed['phases']) == 10
        assert sum(value['exclusive_nanos'] for value in observed['phases'] if value['engine_classified']) == observed['classified_engine_ns']
        assert observed['classified_engine_ns'] + observed['unclassified_engine_ns'] == observed['engine_execution_ns']
        row = dict(case_id=item['case_id'], origin=job['origin'], source=job['source'],
            shared_aggregate=observed['shared_aggregate'],
            provider_selection_reason=observed['provider_selection_reason'],
            observation=item['observation'], complete_output_rows=len(observed['actual_rows']),
            instrumented_engine_execution_ns=observed['engine_execution_ns'],
            phases_exclusive_ns=phases,
            after_result_minus_initial_bytes=observed['after_result_reserved_bytes']-observed['initial_reserved_bytes'],
            after_prepared_reserved_bytes=observed['after_prepared_reserved_bytes'],
            final_reserved_bytes=observed['final_reserved_bytes'],
            interning_and_update_share=(phases['group_interning'] + phases['typed_updates'] + phases['other_updates']) / observed['engine_execution_ns'])
        if profile == 'debug':
            counts = observed['counts']
            assert observed['debug_work_observation']
            if not observed['shared_aggregate']:
                assert job['source']['format'] == 'vortex'
                assert observed['provider_selection_reason'] == 'equivalent_bound_native_file_provider_selected'
                assert counts['group_ordinal_rows'] == counts['aggregate_count_contributions'] == 0
            elif job.get('expected_selected_rows') is not None:
                assert counts['group_ordinal_rows'] == job['expected_selected_rows']
                assert counts['aggregate_count_contributions'] == job['expected_count_contributions']
            else:
                assert job['expected_count_contributions'] == 'all_selected_rows_nonnullable_argument'
                assert counts['aggregate_count_contributions'] == counts['group_ordinal_rows']
            assert counts['aggregate_count_updates'] == counts['aggregate_count_contributions']
            keys = counts['membership_key_preparations']
            assert len(keys) == counts['group_input_batches']
            assert sum(value['rows'] for value in keys) == counts['group_ordinal_rows']
            assert all(value['numeric'] for value in keys)
            row['work'] = {key: counts[key] for key in (
                'group_ordinal_rows', 'group_input_batches', 'key_cache_batches', 'key_cache_hits',
                'key_inline_cache_batches', 'key_inline_cache_hits', 'key_exact_lookups',
                'row_index_lookups', 'row_index_equality_calls', 'aggregate_count_updates',
                'aggregate_count_contributions')}
            row['key_input_encodings_by_batches'] = dict(Counter(value['input_encoding'] for value in keys))
            row['key_dtypes_by_batches'] = dict(Counter(value['dtype'] for value in keys))
        else:
            assert observed['counts'] is None and not observed['debug_work_observation']
        rows.append(row)
    profiles[profile] = dict(run=dict(path=str(path), **identity(path)),
        source_fingerprint_sha256=protocol['source_fingerprint_sha256'],
        rows=rows, passed=len(rows))
assert profiles['debug']['source_fingerprint_sha256'] == profiles['release']['source_fingerprint_sha256']
assert [row['case_id'] for row in profiles['debug']['rows']] == [row['case_id'] for row in profiles['release']['rows']]
for debug, release in zip(profiles['debug']['rows'], profiles['release']['rows'], strict=True):
    for field in ('source', 'origin', 'shared_aggregate', 'provider_selection_reason', 'complete_output_rows'):
        assert debug[field] == release[field], (debug['case_id'], field)
result = dict(schema_version='shardloom.direct_count_feasibility_attribution.v1', status='passed',
    profiles=profiles, source_fingerprint_sha256=profiles['debug']['source_fingerprint_sha256'],
    original_failed_debug_results=[dict(path=str(OUT / f'debug-attribution-{prior}-result.json'),
        **identity(OUT / f'debug-attribution-{prior}-result.json')) for prior in ('r1','r2','r3','r4')],
    queries_executed_by_verifier=0, production_performance_result=False,
    limitations=['instrumented caller-thread exclusive scopes',
        'interning plus update share is cost exposure, not predicted removable cost or speedup',
        'debug work counts and release instrumentation are separate observations',
        'saved declarations enter shared prepared native owner; public surface conformance is separate',
        'source-held reservation growth is recorded; exact lazy allocation attribution is not claimed'])
path = OUT / 'feasibility-attribution-r1.json'
with path.open('x') as stream:
    json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False)
    stream.write('\n')
print(json.dumps(dict(status='passed', requests_per_profile=19, queries=0, output=str(path))))
