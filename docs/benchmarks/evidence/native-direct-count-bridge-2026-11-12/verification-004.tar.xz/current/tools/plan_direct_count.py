"""Freeze complete saved COUNT exposure and declaration-selected neighbors."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parents[1]
E = Path('/Users/dylan/LocalData/shardloom/expanded-query-2026-11-03')
FROZEN = E / 'investigation-original-harness-r1'
sys.path[:0] = [str(OUT / 'client'), str(FROZEN / 'python/src'),
    str(FROZEN / 'benchmarks/traditional_analytics')]
import direct_count_cases as declarations
from query_surface.corpus import corpus
from query_surface.expanded_catalog import build, spaces


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    assert __debug__ and OUT == Path('/Users/dylan/LocalData/shardloom/direct-count-bridge-2026-11-12')
    destination = OUT / 'cohort-selection-r1.json'
    assert not destination.exists()
    pool_path = OUT / 'count-cohort-pools-r1.json'
    pool = json.loads(pool_path.read_bytes())
    assert identity(pool_path)['sha256'] == 'd4aab1dd2cb7a3a28e5efd3ce4e22d0246c98d5c0ea506b9f662e2f6f54d571a'
    original_path = E / 'design.json'
    assert identity(original_path)['sha256'] == pool['design_sha256'] == 'fd0a2604c9abc888a7a24ba75078569fc33e354b16cc98372977c15306a39216'
    design = json.loads(original_path.read_bytes())
    originals = {item.id: item for item in corpus(interactions='all', include_pending=False)}
    definitions = {row.name: row for row in spaces()}
    records, count_ids, neighbors, aggregated = [], set(), {}, set()
    count_rows = {row['case_id']: row for row in pool['count_any_measure_any_route']['cases']}
    no_rows = {row['case_id']: row
        for family in pool['no_count_aggregate_cases_by_family_surface'].values()
        for bucket in family['by_surface'].values() for row in bucket['cases']}
    for ordinal, case in enumerate(design['cases']):
        item = build(case, definitions) if 'cell' in case else originals[case['id']]
        assert item.id == case['id'] and item.identity == case['case_identity']
        stack, functions = [item.relation], []
        while stack:
            node = stack.pop()
            if node.op == 'aggregate':
                functions += [measure.function.lower() for measure in node.args[1]]
            stack.extend(node.inputs)
        if not functions:
            assert case['id'] not in count_rows and case['id'] not in no_rows
            continue
        aggregated.add(case['id'])
        pool_row = (count_rows if 'count' in functions else no_rows)[case['id']]
        assert pool_row['design_ordinal'] == ordinal and pool_row['case_identity'] == case['case_identity']
        assert pool_row['aggregate_function_multiset'] == dict(Counter(functions))
        if 'count' in functions:
            count_ids.add(case['id'])
        else:
            # First original design ordinal in each extant family/surface/format
            # bucket, independent of outcomes, clocks, or candidate eligibility.
            neighbors.setdefault((case['family'], case['surface'], case['native_format']), ordinal)
    assert len(aggregated) == 7828 and count_ids == set(count_rows) and len(count_ids) == 2098
    assert len(neighbors) == 160 and set(count_rows).isdisjoint(no_rows)
    neighbor_ordinals = set(neighbors.values())
    assert len(neighbor_ordinals) == 160
    for ordinal, case in enumerate(design['cases']):
        if case['id'] not in count_ids and ordinal not in neighbor_ordinals:
            continue
        records.append(dict(cohort_ordinal=len(records), kind='original', original_seq=ordinal,
            role='saved_count' if case['id'] in count_ids else 'no_count_neighbor', case=case))
    new_cases = declarations.declarations()
    assert len(records) == 2258 and len(new_cases) == 285
    old_ids = {case['id'] for case in design['cases']}
    old_identities = {case['case_identity'] for case in design['cases']}
    assert len(old_ids) == len(old_identities) == 10000
    for case in new_cases:
        declarations.validate(case)
        assert case['id'] not in old_ids and case['case_identity'] not in old_identities
        records.append(dict(cohort_ordinal=len(records), kind='composition', original_seq=None,
            role='versioned_count_control', case=case))
    assert len(records) == len({row['case']['id'] for row in records}) == len({row['case']['case_identity'] for row in records}) == 2543
    for relative, expected in pool['loaded_frozen_source_sha256'].items():
        assert identity(FROZEN / relative)['sha256'] == expected
    assert not any(name == 'shardloom._native' or name.startswith('_polars_runtime') for name in sys.modules)
    result = dict(schema='shardloom.direct_count_selection.v1', status='frozen_before_scoring',
        selected_requests=2543, saved_count_requests=2098, no_count_neighbors=160, new_declarations=285,
        original_design=identity(original_path), pool=identity(pool_path),
        pool_primary_verification=identity(OUT / 'count-cohort-pools-primary-verification-r1.json'),
        client_module=identity(OUT / 'client/direct_count_cases.py'),
        design=identity(OUT / 'design-r1.md'), candidate_design=identity(OUT / 'candidate-design-r1.md'),
        cohort_design=identity(OUT / 'cohort-design-r1.md'), generator=identity(Path(__file__)),
        frozen_loaded_sources=pool['loaded_frozen_source_sha256'], query_executions=0,
        native_imports=False, selection_uses_timing=False,
        neighbor_rule='lowest original design ordinal in every extant no-COUNT aggregate family/surface/native-format bucket',
        neighbor_buckets=[dict(family=key[0], surface=key[1], native_format=key[2], original_seq=value)
            for key, value in sorted(neighbors.items())],
        coverage=declarations.coverage([row['case'] for row in records]),
        complete_10k_performance_claim=False, full43_claim=False, cases=records)
    with destination.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({key: result[key] for key in ('status', 'selected_requests',
        'saved_count_requests', 'no_count_neighbors', 'new_declarations', 'coverage')}))


if __name__ == '__main__':
    main()
