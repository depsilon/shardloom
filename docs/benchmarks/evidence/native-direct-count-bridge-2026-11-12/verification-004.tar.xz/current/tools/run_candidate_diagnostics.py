"""One isolated debug observation of the fixed candidate's 19 COUNT requests."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

OUT = Path(__file__).resolve().parents[1]
TEST = 'local_primitives::prepared_relational::tests::direct_count_tests::native_direct_count_attribution'


def content(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        return dict(bytes=path.stat().st_size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest())


def generation(path):
    s = path.lstat()
    return [s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_nlink]


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')


def verify_inputs(declaration):
    # Called only before the first child and after every child has exited.
    for group in ('input_files', 'reference_databases'):
        for name, expected in declaration[group].items():
            path = Path(name)
            assert generation(path) == expected['generation']
            assert content(path) == {key: expected[key] for key in ('bytes', 'sha256')}
            assert generation(path) == expected['generation']


def run_one(command, env, log, timeout):
    started = time.monotonic()
    # Inherit the outer proven supervisor's process group. An outer failure can
    # drain this driver and every native descendant; no child creates a session.
    with log.open('xb') as stream:
        child = subprocess.Popen(command, env=env, stdout=stream, stderr=subprocess.STDOUT)
        try:
            while True:
                if time.monotonic() - started > timeout:
                    raise TimeoutError('declared COUNT diagnostic query deadline')
                if log.stat().st_size > 8 << 20:
                    raise RuntimeError('declared COUNT diagnostic output cap')
                try:
                    return child.wait(timeout=0.25)
                except subprocess.TimeoutExpired:
                    pass
        finally:
            if child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.wait(timeout=5)


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--protocol', required=True)
parser.add_argument('--name', required=True)
args = parser.parse_args()
assert __debug__ and Path(args.protocol).name == args.protocol
assert args.name.replace('-', '').isalnum()
protocol_path = OUT / args.protocol
protocol = json.loads(protocol_path.read_bytes())
assert protocol['schema_version'] == 'shardloom.direct_count_diagnostic_protocol.v1'
assert protocol['status'] == 'frozen' and protocol['scored'] is False
assert protocol['candidate_selected'] is True and protocol['profile'] == 'debug'
assert protocol['run_name'] == args.name and protocol['iterations_per_request'] == 1
profile = protocol['profile']
assert profile in ('debug', 'release')
declaration_path = Path(protocol['declarations']['path'])
assert content(declaration_path) == {key: protocol['declarations'][key] for key in ('bytes', 'sha256')}
declaration = json.loads(declaration_path.read_bytes())
assert declaration['total_requests'] == len(declaration['jobs']) == 19
assert declaration['saved_cases'] == 11 and declaration['versioned_controls'] == 8
baseline_path = OUT / 'debug-attribution-r5-result.json'
assert content(baseline_path) == {key: protocol['baseline_result'][key] for key in ('bytes', 'sha256')}
baseline = json.loads(baseline_path.read_bytes())
assert baseline['status'] == 'passed' and len(baseline['observations']) == 19
baseline_by_id = {row['case_id']: row for row in baseline['observations']}
binary_path = Path(protocol['binary']['path'])
assert content(binary_path) == {key: protocol['binary'][key] for key in ('bytes', 'sha256')}
root = OUT / args.name
assert not root.exists()
root.mkdir()
(root / 'logs').mkdir()
record = dict(schema_version='shardloom.direct_count_diagnostic_run.v1', status='running',
    protocol=dict(path=str(protocol_path), **content(protocol_path)), profile=profile,
    observations=[], before_inputs_verified=False, after_inputs_verified=False,
    performance_result=False, full43_claim=False, complete_10k_claim=False)
try:
    verify_inputs(declaration)
    record['before_inputs_verified'] = True
    for index, item in enumerate(declaration['jobs']):
        job_path = Path(item['path'])
        assert content(job_path) == {key: item[key] for key in ('bytes', 'sha256')}
        job = json.loads(job_path.read_bytes())
        command = [str(binary_path), '--exact', TEST, '--ignored', '--nocapture', '--test-threads=1']
        env = dict(os.environ, SHARDLOOM_DIRECT_COUNT_JOB=str(job_path), RUST_BACKTRACE='1')
        log = root / 'logs' / (str(index).zfill(2) + '.log')
        entry = dict(case_id=item['case_id'], job=item, command=command,
            log=str(log), status='started', child_completed=False)
        record['observations'].append(entry)
        code = run_one(command, env, log, protocol['per_request_deadline_seconds'])
        entry.update(returncode=code, child_completed=True, log_identity=content(log))
        assert code == 0, 'COUNT diagnostic failed: ' + item['case_id']
        lines = log.read_text().splitlines()
        messages = [line.split('DIRECT_COUNT ', 1)[1] for line in lines if 'DIRECT_COUNT ' in line]
        assert len(messages) == 1
        observed = json.loads(messages[0])
        assert observed['schema_version'] == 'shardloom.direct_count_diagnostic_observation.v1'
        assert observed['job'] == job and observed['actual_rows'] == job['expected_rows']
        assert observed['debug_work_observation'] == (profile == 'debug')
        assert isinstance(observed['shared_aggregate'], bool)
        assert isinstance(observed['provider_selection_reason'], str) and observed['provider_selection_reason']
        if not observed['shared_aggregate']:
            assert job['source']['format'] == 'vortex'
            assert observed['provider_selection_reason'] == 'equivalent_bound_native_file_provider_selected'
        assert observed['native_io_certified'] and not observed['fallback_attempted']
        assert observed['external_engine_invoked'] is False
        assert observed['final_reserved_bytes'] == observed['denied_reservations'] == 0
        assert 0 <= observed['after_prepared_reserved_bytes'] <= observed['after_result_reserved_bytes']
        if job['source']['format'] != 'vortex':
            assert observed['after_result_reserved_bytes'] == observed['initial_reserved_bytes']
            assert observed['retained_source_count'] == observed['after_prepared_reserved_bytes'] == 0
        else:
            assert observed['retained_source_count'] == 1
        assert observed['peak_reserved_bytes'] <= observed['memory_grant_bytes'] == 2 << 30
        assert observed['classified_engine_ns'] + observed['unclassified_engine_ns'] == observed['engine_execution_ns']
        phases = observed['phases']
        assert len(phases) == 10
        assert sum(phase['exclusive_nanos'] for phase in phases if phase['engine_classified']) == observed['classified_engine_ns']
        saved = baseline_by_id[item['case_id']]['observation']
        saved_path = Path(saved['path'])
        assert content(saved_path) == {key: saved[key] for key in ('bytes', 'sha256')}
        old = json.loads(saved_path.read_bytes())
        for name in ('job', 'actual_rows', 'actual_schema', 'shared_aggregate',
                'provider_selection_reason', 'producer_calls', 'producer_ended',
                'producer_consumed_rows', 'scan_rows_delivered', 'source'):
            assert observed[name] == old[name], name
        counts, old_counts = observed['counts'], old['counts']
        removed = counts['aggregate_count_partial_input_rows'] - counts['aggregate_count_partial_groups']
        assert removed >= 0
        assert counts['aggregate_count_contributions'] == old_counts['aggregate_count_contributions']
        assert counts['aggregate_count_updates'] == old_counts['aggregate_count_updates'] - removed
        assert counts['group_ordinal_rows'] == old_counts['group_ordinal_rows'] - removed
        assert counts['group_input_batches'] == old_counts['group_input_batches']
        keys = counts['membership_key_preparations']
        assert len(keys) == counts['group_input_batches']
        assert sum(key['rows'] for key in keys) == counts['group_ordinal_rows']
        assert all(key['numeric'] for key in keys)
        assert counts['aggregate_count_partial_capacity_declines'] == 0
        if not observed['shared_aggregate']:
            assert counts['group_ordinal_rows'] == counts['aggregate_count_contributions'] == 0
            assert counts['aggregate_count_partial_batches'] == 0
        elif 'repeat-memory' in item['case_id'] or 'constant-key-batch' in item['case_id']:
            assert counts['aggregate_count_partial_batches'] > 0 and removed > 0
        entry['removed_ordinal_rows_and_count_updates'] = removed
        entry['baseline_observation'] = saved
        output = root / (str(index).zfill(2) + '.json')
        write(output, observed)
        entry.update(status='passed', observation=dict(path=str(output), **content(output)))
        print(json.dumps(dict(case_id=item['case_id'], status='passed', profile=profile)), flush=True)
    verify_inputs(declaration)
    record['after_inputs_verified'] = True
    assert content(binary_path) == {key: protocol['binary'][key] for key in ('bytes', 'sha256')}
    assert content(protocol_path) == {key: record['protocol'][key] for key in ('bytes', 'sha256')}
    assert len(record['observations']) == 19
    record['status'] = 'passed'
except BaseException as error:
    record.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    write(OUT / (args.name + '-result.json'), record)
    print(json.dumps(dict(status=record['status'], profile=profile,
        observed=len(record['observations']), passed=sum(row['status'] == 'passed' for row in record['observations']))), flush=True)
