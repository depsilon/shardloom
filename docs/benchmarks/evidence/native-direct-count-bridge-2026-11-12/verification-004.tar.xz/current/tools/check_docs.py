"""Check public references against the retained runtime at the COUNT checkpoint."""
import json
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parents[1]
failure = json.loads((OUT / 'baseline-admission-failure-r1.json').read_bytes())
restored = json.loads((OUT / 'source-restoration-r1/receipt.json').read_bytes())
assert failure['status'] == 'verified_invalid_baseline' and failure['scored_candidate_query_executions'] == 0
assert restored['status'] == 'passed_exact_source_restoration' and not restored['candidate_admitted']
runtime = OUT.parent / 'shared-window-state-2026-11-11/runtime-r1'
commands = [
    ['scripts/write_native_function_reference.py', '--check', '--native-library', str(runtime / 'lib_native.dylib')],
    ['scripts/write_public_api_reference.py', '--check', '--binary', str(runtime / 'shardloom')],
    ['scripts/write_python_api_exports.py', '--check'],
    ['scripts/check_user_surface_reference.py'],
    ['scripts/check_python_license_bundle.py'],
    ['scripts/check_public_status_docs.py', '--output', str(OUT / 'public-status-docs-r1.json')],
    ['scripts/check_contribution_governance.py', '--output', str(OUT / 'contribution-governance-r1.json')],
]
for command in commands:
    print('Checking ' + command[0], flush=True)
    subprocess.run([sys.executable, '-B', *command], check=True, timeout=120)
