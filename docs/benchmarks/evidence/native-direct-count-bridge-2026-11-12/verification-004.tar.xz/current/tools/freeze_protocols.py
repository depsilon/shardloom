"""Freeze separate work-count and release-cost observations, never scored runs."""
import argparse
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parents[1]


def content(path):
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        return dict(bytes=path.stat().st_size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest())


def read(path):
    return json.loads(path.read_bytes())


assert __debug__
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--revision', required=True, choices=('r5',))
parser.add_argument('--profile', required=True, choices=('debug', 'release'))
args = parser.parse_args()
revision = args.revision
declaration = OUT / 'diagnostic-declarations-r3.json'
assert read(declaration)['status'] == 'frozen'
assert read(declaration)['total_requests'] == 19
fingerprints = set()
for profile in (args.profile,):
    identity_path = OUT / f'diagnostic-{profile}-{revision}-identity.json'
    build = read(identity_path)
    assert build['status'] == 'passed' and build['profile'] == profile
    assert build['native_query_executions'] == 0 and build['scored_production_runtime'] is False
    receipt_path = Path(build['build_receipt']['path'])
    assert content(receipt_path) == {key: build['build_receipt'][key] for key in ('bytes', 'sha256')}
    receipt = read(receipt_path)
    assert receipt['status'] == 'passed' and receipt['process_group_drained']
    assert receipt['build_source_fingerprint_sha256'] == build['build_source_fingerprint_sha256']
    fingerprints.add(build['build_source_fingerprint_sha256'])
    other = 'release' if profile == 'debug' else 'debug'
    other_path = OUT / f'diagnostic-{other}-{revision}-identity.json'
    if other_path.exists():
        assert read(other_path)['build_source_fingerprint_sha256'] == build['build_source_fingerprint_sha256']
    assert content(Path(build['binary']['path'])) == {key: build['binary'][key] for key in ('bytes', 'sha256')}
    protocol = dict(schema_version='shardloom.direct_count_diagnostic_protocol.v1', status='frozen',
        profile=profile, run_name=f'{profile}-attribution-{revision}', scored=False,
        iterations_per_request=1, per_request_deadline_seconds=240,
        declarations=dict(path=str(declaration), **content(declaration)),
        build_identity=dict(path=str(identity_path), **content(identity_path)),
        binary=build['binary'], source_fingerprint_sha256=build['build_source_fingerprint_sha256'],
        build_head=build['build_head'],
        purpose='debug_semantics_and_work_counts' if profile == 'debug' else 'instrumented_release_cost_attribution',
        production_engine_timing_claim=False, public_surface_conformance_claim=False,
        worker_state='all leaf assignments completed; no other task work during query execution',
        warmups=0, repeats=0, cache_manipulation=False,
        input_hashing='before first query and after final query only',
        active_output=str(OUT / f'{profile}-attribution-{revision}'),
        diagnostic_revision_reason='version 2 controls use existing bounded native batch intake and supported producer sizes; full populations retained; no production runtime change',
        prior_failed_debug_observations=[dict(path=str(OUT / f'debug-attribution-{prior}-result.json'),
            **content(OUT / f'debug-attribution-{prior}-result.json')) for prior in ('r1','r2','r3','r4')],
        candidate_selected=False, complete_cohort_decision=False)
    path = OUT / f'diagnostic-protocol-{profile}-{revision}.json'
    with path.open('x') as stream:
        json.dump(protocol, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
assert len(fingerprints) == 1, 'debug/release diagnostic source differs'
print(json.dumps(dict(status='frozen', profiles=[args.profile], requests_per_profile=19,
    source_fingerprint_sha256=next(iter(fingerprints)), queries=0, scored=False)))
