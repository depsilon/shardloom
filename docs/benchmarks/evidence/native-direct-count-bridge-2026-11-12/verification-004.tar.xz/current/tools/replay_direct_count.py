"""Replay complete COUNT results, exact requests, reuse and engine clocks."""
import argparse
from collections import Counter, defaultdict
from contextlib import ExitStack
import gzip
import hashlib
import json
import math
from pathlib import Path

import run_direct_count as current
import direct_count_proof as proof
from direct_count_common import (OUT, SELECTION, Cases, content, database, digest,
    read, replay_case, write)
from query_surface.evidence import identity
from query_surface.expanded_freeze import unpack
from query_surface.expanded_report import raw_files
from query_surface.expanded_run import request, verify


def capture_receipts(role, binding):
    target = current.target(role)
    total = 2384 if role == 'baseline' else 2543
    done, captured = read(target / 'complete.json'), read(target / 'binding.json')
    assert done['status'] == 'complete_observation' and done['stage'] == 'native'
    assert done['total'] == done['attempt_slots'] == total and done['posthash_verified']
    assert done['attempts_per_case'] == 1 and done['requested_repeats'] == 0
    assert done['updated'] == binding
    assert captured['contract'] == {key:done[key] for key in ('frozen', 'stage', 'prerequisites', 'updated')}
    assert done['ledger']['path'] == str(target / 'attempts.sqlite')
    assert done['binding']['path'] == str(target / 'binding.json')
    verify([done['ledger'], done['binding'], done['frozen']])
    path = OUT / (target.name + '.json')
    sources = proof.source_inventory()
    guard, _ = proof.guarded(path, [current.PYTHON, '-B', str(OUT / 'tools/run_direct_count.py'),
        '--role', role], sources, query=True)
    assert guard['active_output'] == str(target)
    assert guard['build_source_fingerprint_sha256'] == binding['candidate_source_fingerprint_sha256']
    assert guard['head'] == binding['source_head'] and guard['base'] == binding['accepted_merge']
    assert binding['parent_interpreter'] == identity(Path(current.PYTHON).resolve())
    assert guard['accepted_join_mapping_closeout']['sha256'] == identity(current.CLOSEOUT)['sha256']
    assert guard['accepted_runtime_build_source_fingerprint_sha256'] == read(current.CLOSEOUT)['source_fingerprint_sha256']
    return done, path


def main():
    assert __debug__ and Path(__file__).resolve() == OUT / 'tools/replay_direct_count.py'
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--role', choices=('baseline', 'candidate'), required=True)
    role = parser.parse_args().role
    destination = OUT / (role + '-verified-r1.json')
    records = OUT / (role + '-cases-r1.jsonl.gz')
    partial = OUT / (role + '-cases-r1.partial.jsonl.gz')
    lock = OUT / ('.' + role + '-replay-r1.lock')
    assert not any(path.exists() for path in (destination, records, partial, lock))
    design, inputs, frozen, binding = current.admission(current.E, role)
    protocol = read(current.protocol_path(role))
    selection, reuse = read(SELECTION), read(current.REUSE)
    assert len(selection['cases']) == len(reuse['requests']) == 2543
    assert Counter(row['kind'] for row in selection['cases']) == {'original':2258, 'composition':285}
    done, guard_path = capture_receipts(role, binding)
    prepared = read(current.E / 'native-preparation/complete.json')
    baseline = read(OUT / 'baseline-verified-r1.json') if role == 'candidate' else None
    outcomes, new_outcomes, families, values, failures = Counter(), Counter(), defaultdict(list), [], []
    with lock.open('x'):
        pass
    with ExitStack() as stack:
        db = stack.enter_context(database(Path(done['ledger']['path'])))
        reused_db = stack.enter_context(database(Path(reuse['reused_database']['path'])))
        assert db.execute('PRAGMA integrity_check').fetchone() == reused_db.execute('PRAGMA integrity_check').fetchone() == ('ok',)
        assert db.execute('SELECT COUNT(*) FROM attempt').fetchone() == (protocol['new_attempts'],)
        assert reused_db.execute('SELECT COUNT(*) FROM attempt').fetchone() == (159,)
        entries = iter(db.execute('SELECT seq,id,status,packet FROM attempt ORDER BY seq'))
        refs, cases = current.references(stack, selection), Cases()
        output = stack.enter_context(gzip.open(partial, 'wt', encoding='utf-8'))
        prior_stream = stack.enter_context(gzip.open(baseline['case_rows']['path'], 'rt')) if baseline else None
        reused_count = 0
        for ordinal, (selected, declared) in enumerate(zip(selection['cases'], reuse['requests'], strict=True)):
            case = selected['case']
            assert selected['cohort_ordinal'] == declared['cohort_ordinal'] == ordinal
            assert declared['id'] == case['id'] and declared['case_identity'] == case['case_identity']
            item, reference, expected = current.case_reference(refs, selected, cases)
            expected_hash = hashlib.sha256(reference[1]).hexdigest()
            assert expected_hash == declared['reference_blob_sha256']
            reused = role == 'baseline' and declared['reused']
            if reused:
                entry = reused_db.execute('SELECT seq,id,status,packet FROM attempt WHERE seq=?', (ordinal,)).fetchone()
                assert entry and entry[:2] == (ordinal, case['id'])
                assert entry[2] == 'passed'
                reused_count += 1
            else:
                seq = declared['missing_seq'] if role == 'baseline' else ordinal
                entry = next(entries, None)
                assert entry and entry[:2] == (seq, case['id'])
                assert protocol['cases'][seq] == selected
            observed = replay_case(entry, case, expected, item, inputs, prepared, design['execution'])
            assert observed['status'] == entry[2]
            files = raw_files(unpack(entry[3])) if entry[3] is not None else {}
            packet = dict(bytes=len(entry[3]), sha256=hashlib.sha256(entry[3]).hexdigest()) if entry[3] is not None else None
            if files:
                job = json.loads(files['one.job.json'])
                assert job == request(case, 'native', inputs, prepared, expected, design['execution'])
                if role == 'baseline':
                    assert digest(job) == declared['request_sha256']
            if reused:
                assert packet == declared['packet'] and observed == declared['result']
                assert hashlib.sha256(files['one.job.json']).hexdigest() == declared['original_provenance']['job_sha256']
            else:
                new_outcomes[observed['status']] += 1
            prior = json.loads(next(prior_stream)) if prior_stream else None
            if prior:
                assert prior['cohort_ordinal'] == ordinal and prior['kind'] == selected['kind']
                assert prior['original_seq'] == selected['original_seq']
                assert all(prior[key] == case[key] for key in ('id', 'case_identity', 'family', 'profile', 'surface', 'native_format'))
                assert prior['result']['status'] == 'passed'
                assert prior['provenance']['independent_expected_blob_sha256'] == expected_hash
            outcomes[observed['status']] += 1
            if observed['status'] == 'passed':
                seconds = observed['engine_seconds']
                assert type(seconds) in (int, float) and math.isfinite(seconds) and seconds >= 0
                values.append(seconds)
                families[case['family']].append(seconds)
            else:
                failures.append(dict(cohort_ordinal=ordinal, id=case['id'], status=observed['status'],
                    detail=observed.get('failure_detail')))
            provenance = dict(source='accepted_reused_baseline' if reused else 'new_' + role,
                ledger=reuse['reused_database']['path'] if reused else done['ledger']['path'],
                source_seq=entry[0], packet=packet,
                job_sha256=hashlib.sha256(files['one.job.json']).hexdigest() if files else None,
                independent_expected_blob_sha256=expected_hash)
            if reused:
                provenance['original_provenance'] = declared['original_provenance']
            row = dict(cohort_ordinal=ordinal, original_seq=selected['original_seq'], kind=selected['kind'],
                id=case['id'], case_identity=case['case_identity'], family=case['family'],
                profile=case['profile'], surface=case['surface'], native_format=case['native_format'],
                provenance=provenance, result=observed)
            if prior:
                row['baseline_engine_seconds'] = prior['result']['engine_seconds']
            output.write(json.dumps(row, separators=(',', ':'), allow_nan=False) + '\n')
        assert next(entries, None) is None and (prior_stream is None or next(prior_stream, None) is None)
        assert reused_count == (159 if role == 'baseline' else 0)
    assert sum(outcomes.values()) == 2543
    assert dict(new_outcomes) == done['outcomes'] and sum(new_outcomes.values()) == protocol['new_attempts']
    verify([*frozen, done['ledger'], done['binding'], done['frozen'], reuse['reused_database']])
    partial.rename(records)
    passed = outcomes == {'passed':2543}
    seconds = math.fsum(values) if passed else None
    result = dict(schema='shardloom.direct_count_cohort.v1', role=role,
        status=('passed_complete_' + role + '_cohort') if passed else ('failed_' + role + '_cohort'),
        query_executions_during_replay=0, accepted_merge=binding['accepted_merge'], selected_cases=2543,
        original_controls=2258, saved_count_requests=2098, no_count_neighbors=160, new_compositions=285,
        new_attempts=protocol['new_attempts'], reused_saved_cases=reused_count,
        outcomes=dict(outcomes), new_outcomes=dict(new_outcomes), attempts_per_case=1,
        warmups=0, requested_repeats=0, primary_clock='engine_execution_seconds',
        engine_execution_seconds=seconds, complete_performance_result_valid=passed,
        all_selected_results_correct=passed, all_engine_clocks_valid=passed, native_no_fallback=passed,
        failures=failures, families={name:dict(cases=len(times), engine_execution_seconds=math.fsum(times))
            for name,times in sorted(families.items())}, protocol=identity(current.protocol_path(role)),
        selection=identity(SELECTION), reuse=identity(current.REUSE), reused_database=reuse['reused_database'],
        complete=identity(current.target(role) / 'complete.json'), ledger=done['ledger'], guard=identity(guard_path),
        case_rows=identity(records), verifier=identity(Path(__file__)), runtime_binding=binding,
        performance_claim=False, complete_10k_performance_claim=False, full43_claim=False,
        limitations=['One observation per exact request; baseline/candidate sessions and reuse dates differ.',
            '159 exact accepted-runtime baseline observations reused; 2384 missing baseline requests measured once.',
            'Fixed 2543-case cohort; not a complete 10k or Full43, and no statistical confidence claim.',
            'Auxiliary debug work/ownership evidence does not establish a whole-process memory bound.'])
    if baseline:
        base_seconds = baseline['engine_execution_seconds']
        disposition = ('retain_candidate' if seconds < base_seconds else 'drop_candidate_no_gain') if passed else 'drop_candidate_invalid_cohort'
        result.update(baseline_result=identity(OUT / 'baseline-verified-r1.json'),
            baseline_engine_execution_seconds=base_seconds,
            engine_seconds_saved=base_seconds - seconds if passed else None,
            observed_engine_reduction_percent=100 * (base_seconds - seconds) / base_seconds if passed else None,
            frozen_rule_disposition=disposition, final_integration_accepted=False)
        assert result['families'].keys() == baseline['families'].keys()
        for family, row in result['families'].items():
            assert row['cases'] == baseline['families'][family]['cases']
            row['baseline_engine_execution_seconds'] = baseline['families'][family]['engine_execution_seconds']
    write(destination, result)
    lock.unlink()
    print(json.dumps({key:result[key] for key in ('status', 'selected_cases', 'outcomes', 'engine_execution_seconds')}))
    assert passed, 'failed observations preserved; no complete performance score admitted'


if __name__ == '__main__':
    main()
