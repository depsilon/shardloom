"""Versioned grouped COUNT requests and independent literal row references.

Import only after the unchanged frozen declaration client. No native runtime
is imported here; the reference consumes actual independent input rows.
"""
from collections import Counter
import hashlib
import json

from query_surface.semantics import ResultContract, ResultType, TypedResult, schema_record
from query_surface.specification import Expression, Measure, Order, Relation, SURFACES

FORMATS = ('parquet', 'vortex', 'arrow-ipc')
PROFILES = ('smoke', 'primary', 'holdout', 'scale')
INPUT_COLUMNS = ('row_id', 'group_key', 'medium_key', 'signed_value', 'optional_value')


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
        ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def scenarios():
    rows = []

    def add(name, **changes):
        row = dict(name=name, key='group', dtype='int64', value='star',
            population='all', order='key_asc', limit=31, extra='none')
        row.update(changes)
        rows.append(row)

    for dtype in ('int64', 'uint64'):
        add(dtype + '_star', dtype=dtype)
        add(dtype + '_column', dtype=dtype, value='column', order='count_desc')
    for dtype in ('int64', 'uint64'):
        add(dtype + '_constant', dtype=dtype, key='constant', order='key_desc')
    for dtype in ('int64', 'uint64'):
        add(dtype + '_unique', dtype=dtype, key='unique', value='column', population='first_4096')
    for dtype in ('int64', 'uint64'):
        add(dtype + '_sparse_expression', dtype=dtype, key='expression', population='sparse', order='count_desc')
    add('empty', population='empty')
    add('tiny', population='first_3', value='column', order='key_desc')
    add('one', population='first_1')
    add('nullable_argument', value='nullable', order='count_desc')
    add('nullable_key', key='nullable', value='column', order='key_desc')
    add('source_order', order='none', limit=None)
    add('mixed_measure', value='column', extra='sum')
    add('multiple_keys', value='column', extra='key', order='key_desc', limit=None)
    add('medium_key', key='medium', order='count_desc')
    assert len(rows) == len({row['name'] for row in rows}) == 19
    return rows


def checked_scenario(scenario):
    if digest(scenario) not in {digest(row) for row in scenarios()}:
        raise ValueError('unknown grouped COUNT scenario')
    return scenario


def relation(scenario):
    checked_scenario(scenario)
    source = Relation.scan('fact')
    population = scenario['population']
    if population == 'sparse':
        source = source.where(source.col('row_id').binary('mod', 97).binary('eq', 0))
    elif population != 'all':
        threshold = {'empty': 0, 'first_1': 1, 'first_3': 3, 'first_4096': 4096}[population]
        source = source.where(source.col('row_id').binary('lt', threshold))
    mode = scenario['key']
    if mode == 'constant':
        key = Expression.literal(7)
    elif mode == 'expression':
        key = source.col('signed_value').binary('add', 1000).binary('mod', 17)
    else:
        key = source.col({'group': 'group_key', 'unique': 'row_id',
            'nullable': 'optional_value', 'medium': 'medium_key'}[mode])
    if mode != 'nullable':
        key = key.cast(ResultType(scenario['dtype'], False))
    projection = [('k', key)]
    if scenario['value'] != 'star':
        value = source.col('optional_value') if scenario['value'] == 'nullable' else (
            source.col('row_id').cast(ResultType(scenario['dtype'], False)))
        projection.append(('v', value))
    if scenario['extra'] == 'sum':
        projection.append(('s', source.col('signed_value')))
    if scenario['extra'] == 'key':
        projection.append(('k2', source.col('row_id').binary('mod', 5)))
    selected = source.project(*projection)
    keys = ('k', 'k2') if scenario['extra'] == 'key' else ('k',)
    measures = [Measure('count', None if scenario['value'] == 'star' else selected.col('v'),
        'n', ResultType('uint64', False))]
    if scenario['extra'] == 'sum':
        measures.append(Measure('sum', selected.col('s'), 'total', ResultType('int64', True)))
    result = selected.aggregate(keys, measures)
    order = scenario['order']
    if order != 'none':
        ordering = ([Order('n', True, 'last')] if order == 'count_desc' else [])
        ordering += [Order(name, order != 'key_asc', 'last') for name in keys]
        result = result.order(*ordering)
    return result if scenario['limit'] is None else result.take(scenario['limit'])


def contract(case):
    plan = validate(case)
    return ResultContract(plan.schema, ordered=case['declaration']['ordered'])


def declarations():
    cases = []
    for index, scenario in enumerate(scenarios()):
        plan = relation(scenario)
        for surface_index, surface in enumerate(SURFACES):
            for format_index, native_format in enumerate(FORMATS):
                profile = PROFILES[(index + surface_index + 2 * format_index) % len(PROFILES)]
                declaration = dict(version=1, scenario=scenario, profile=profile,
                    surface=surface, native_format=native_format, relation_sha256=digest(plan.record()),
                    output_schema=schema_record(plan.schema), ordered=scenario['order'] != 'none')
                identity = digest(declaration)
                cases.append(dict(id=f'direct_count_v1_{index:02}_{surface_index}_{format_index}_{identity[:12]}',
                    case_identity=identity, direct_count_version=1, declaration=declaration,
                    profile=profile, surface=surface, native_format=native_format,
                    family='direct_count_' + scenario['key'], archetype=scenario['name'],
                    partition='held_out' if profile == 'holdout' else 'development', surrogate=None))
    assert len(cases) == len({row['id'] for row in cases}) == 285
    return cases


def validate(case):
    declaration = case['declaration']
    if (type(case['direct_count_version']) is not int or case['direct_count_version'] != 1
            or type(declaration['version']) is not int or declaration['version'] != 1):
        raise ValueError('unknown grouped COUNT declaration version')
    if set(declaration) != {'version', 'scenario', 'profile', 'surface', 'native_format',
            'relation_sha256', 'output_schema', 'ordered'}:
        raise ValueError('grouped COUNT declaration fields changed')
    scenario = checked_scenario(declaration['scenario'])
    if declaration['ordered'] is not (scenario['order'] != 'none'):
        raise ValueError('grouped COUNT result ordering changed')
    if digest(declaration) != case['case_identity']:
        raise ValueError('grouped COUNT declaration identity changed')
    if any(case[key] != declaration[key] for key in ('profile', 'surface', 'native_format')):
        raise ValueError('grouped COUNT route changed')
    index = [digest(row) for row in scenarios()].index(digest(scenario))
    si, fi = SURFACES.index(case['surface']), FORMATS.index(case['native_format'])
    profile = PROFILES[(index + si + 2 * fi) % len(PROFILES)]
    expected_id = f'direct_count_v1_{index:02}_{si}_{fi}_{case["case_identity"][:12]}'
    if (case['id'] != expected_id or case['profile'] != profile
            or case['family'] != 'direct_count_' + scenario['key']
            or case['archetype'] != scenario['name']
            or case['partition'] != ('held_out' if profile == 'holdout' else 'development')
            or case['surrogate'] is not None):
        raise ValueError('grouped COUNT fixed coverage schedule changed')
    plan = relation(scenario)
    if digest(plan.record()) != declaration['relation_sha256'] or schema_record(plan.schema) != declaration['output_schema']:
        raise ValueError('grouped COUNT output contract changed')
    return plan


def selected(scenario, row):
    population = scenario['population']
    if population == 'all':
        return True
    if population == 'sparse':
        return row['row_id'] % 97 == 0
    return row['row_id'] < {'empty': 0, 'first_1': 1, 'first_3': 3, 'first_4096': 4096}[population]


def reference_key(scenario, row):
    mode = scenario['key']
    if mode == 'constant':
        value = 7
    elif mode == 'expression':
        # Actual fixture values are in [-1000, 1000], so Python and native
        # remainder domains agree. Refuse, rather than guess, changed inputs.
        if type(row['signed_value']) is not int or not -1000 <= row['signed_value'] <= 1000:
            raise ValueError('independent signed input domain changed')
        value = (row['signed_value'] + 1000) % 17
    else:
        value = row[{'group': 'group_key', 'unique': 'row_id',
            'nullable': 'optional_value', 'medium': 'medium_key'}[mode]]
    if value is not None:
        bounds = {'int32': (-(1 << 31), (1 << 31) - 1),
            'int64': (-(1 << 63), (1 << 63) - 1), 'uint64': (0, (1 << 64) - 1)}
        lo, hi = bounds[scenario['dtype']]
        if type(value) is not int or not lo <= value <= hi:
            raise ValueError('independent key cast exceeds declared integer domain')
    elif mode != 'nullable':
        raise ValueError('independent nonnullable key is NULL')
    return (value, row['row_id'] % 5) if scenario['extra'] == 'key' else (value,)


def reference_grid(fact_rows):
    """One independent row stream, shared exact answers for dtype-equivalent cells.

    This is only reference preparation, outside query timing. It does not use
    ShardLoom output or implement a runtime dispatch path.
    """
    variants = scenarios()
    semantic = lambda row: (row['key'], row['value'], row['population'], row['extra'])
    representatives = {semantic(row): row for row in variants}
    states = {key: {} for key in representatives}
    seen = 0
    for fact in fact_rows:
        if type(fact['row_id']) is not int or fact['row_id'] < 0:
            raise ValueError('independent row identity must be a nonnegative integer')
        seen += 1
        for group, scenario in representatives.items():
            if not selected(scenario, fact):
                continue
            key = reference_key(scenario, fact)
            state = states[group].setdefault(key, [0, 0])
            value = fact['optional_value'] if scenario['value'] == 'nullable' else fact['row_id']
            if scenario['value'] == 'star' or value is not None:
                state[0] += 1
            if scenario['extra'] == 'sum':
                if type(fact['signed_value']) is not int:
                    raise ValueError('independent nonnullable SUM input changed')
                state[1] += fact['signed_value']
            if len(states[group]) > 4096:
                raise ValueError('independent COUNT result domain exceeds fixed bound')
    answers = {}
    for scenario in variants:
        rows = []
        for key, (count, total) in states[semantic(scenario)].items():
            row = dict(k=key[0], n=count)
            if scenario['extra'] == 'key':
                row['k2'] = key[1]
            if scenario['extra'] == 'sum':
                row['total'] = total
            rows.append(row)
        if scenario['order'] != 'none':
            names = ('k', 'k2') if scenario['extra'] == 'key' else ('k',)
            descending = scenario['order'] != 'key_asc'

            def key(row):
                order = (-row['n'],) if scenario['order'] == 'count_desc' else ()
                for name in names:
                    value = row[name]
                    order += (value is None, 0 if value is None else -value if descending else value)
                return order

            rows.sort(key=key)
        if scenario['limit'] is not None:
            rows = rows[:scenario['limit']]
        plan = relation(scenario)
        answers[scenario['name']] = TypedResult(plan.schema, rows)
    return answers, seen


def coverage(cases):
    return {key: dict(Counter(row[key] for row in cases))
        for key in ('profile', 'surface', 'native_format', 'family')}
