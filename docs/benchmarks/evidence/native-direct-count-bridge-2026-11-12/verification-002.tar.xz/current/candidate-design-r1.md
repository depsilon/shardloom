# B: one bounded integer COUNT partial candidate

The feasibility gate passed on November 12, 2026. The immutable
`feasibility-attribution-r1.json` verifies all 19 complete requests in separate
debug and optimized diagnostic observations at source fingerprint
`6b59ac4f76202b74528103ce3c66d3b5f57058aa384a7d7d33148ac8d1ccab0c`.
Nine saved declarations use the shared aggregate; two already select the native
file provider and provide no shared-path cost attribution. All complete results,
schemas, certificates, final reservation refunds and input identities pass.
The four earlier failed debug attempts remain unchanged.

The saved medium-key Parquet request performs 374,616 exact lookups and COUNT
updates across 489 callbacks; interning plus updates occupy 41.28% of its
instrumented engine clock. Its within-callback reduction is not yet known.
The saved repeated-key IPC request performs 349,721 ordinal writes and updates,
although the existing cache reduces exact lookups to 2,450. The repeated native
memory control similarly performs 65,537 writes/updates with 545 exact lookups.
These establish removable per-row work and substantial cost in some requests,
not attainable speedup. Sorting, native key copying and overlapping credits are
additional work, and unique/tiny/cache-efficient cases may lose.

## Fixed implementation hypothesis before scoring

Reuse `numeric_count_partial` inside the existing shared Aggregate callback.
Keep its producer, projection/filter/error work, source demand and completion,
RowSet membership, finalizer and native output. No worker pool, source wrapper,
whole-input retention, external engine or file-layout capability is added.

Binding may mark only an immediate Sort over a single grouped COUNT when the
sort includes the unique group key. Both directions are allowed. One
nonnullable I32/I64/U64 key, one COUNT(*) or COUNT of a nonnullable I32/I64/U64
column, and no expansion/filter/distinct/secondary or specialized measure are
admitted. Count argument validity remains observed at the ordinary measure
stage. Nullable parents and unproved input schemas retain the ordinary route.
Spill always stays on its existing path; unsorted output retains first-seen order.

For an admitted nonempty batch with more than one row, reserve the complete
partial capacity before allocation, prepare the same selected native numeric
key domain, and invoke the existing partial kernel inline. Preserve physical
constant dispatch before row expansion. A complete unique partial may decline
before membership mutation. Build reduced keys in native credited storage and
intern them through the existing RowSet. Reserve the existing aggregate state
from the original input schema, perform the original COUNT field/parent-validity
observation, then add checked weights to ordinary, typed compact or generic
compact count storage. Never replay a callback after membership/state mutation.

Only recognized capacity denial of optional scratch may decline before state
mutation. Provider errors, cancellation and arithmetic failures propagate.
Reduced-key allocation keeps the typed owned-denial identity before diagnostic
conversion; unrelated allocation failures do not authorize suppressing errors.
Partial allocation capacity remains fully charged after truncation. Reduced
keys, schema wrappers, ordinals and destination state retain overlapping
credits until their actual owners drop. No process-RSS claim follows.

## Acceptance obligations

Before scored execution, freeze exact candidate source/build/runtime identities,
the complete affected saved-case inventory and neighbors, independently checked
versioned controls, and the baseline reuse/missing-case map. Do not tune this
candidate after the first scored execution. Tests cover all three count state
representations and overflow; signed/unsigned/constant/unique keys; both sort
directions and absent/insufficient sort proof; nullability, parent validity,
transforms, multiple callbacks, late errors, cancellation, denied scratch and
ownership release. Prepared diagnostic work and five public surfaces are
different proof boundaries. Pressure/spill controls remain explicit.

The previously declared binary complete-cohort engine-time gate is unchanged.
No new Full43 or full10k run, package publication or completion claim is added.
