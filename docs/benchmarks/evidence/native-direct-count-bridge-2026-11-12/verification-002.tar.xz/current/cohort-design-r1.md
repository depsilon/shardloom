# Direct grouped COUNT complete-cohort contract

Frozen before any new scored query. This cohort implements investigation B's
fixed candidate contract; it does not authorize a second candidate or tuning
after results. The expert comparison is complete analytical request behavior,
including admission, ownership, errors, and observable output ordering.

The selected set contains 2,543 requests: all 2,098 original declarations that
contain COUNT at any aggregate node; 160 no-COUNT aggregation neighbors; and
285 versioned controls. Each neighbor is the lowest original design ordinal
in an extant no-COUNT aggregate family/surface/native-format bucket. Selection
uses declarations only, without timing, outcome, or candidate-eligibility filters.
The original 2,258 request identities and independent reference blobs stay exact.
This includes COUNT with scalar, multiple-key, mixed-measure, nullable, join,
set, CTE, and membership surroundings, whether or not the optimization applies.

Nineteen new scenarios each cover five public interfaces and three native input
formats, with the fixed profile rotation in direct_count_cases.py. They cover
I64 and U64 COUNT(*) and COUNT(column), constant and unique keys, sparse derived
keys, empty/tiny/one-row populations, nullable arguments and keys, source-order
output, mixed COUNT/SUM, multiple keys, and the medium-key domain. Ordered cases
include complete group-key tie breakers. Unordered cases compare complete
multiplicity; native tests separately verify first-seen ordering. Output limits
are part of the declarations, never a substitute for complete selected output.
The unchanged public API has no I32 scalar cast and frozen data has no I32 field;
I32 is therefore tested at the native array/aggregate boundary, not claimed as a
new public cast capability. The earlier unactivated 24-scenario draft was reduced
to these 19 scenarios before selection freezing or query execution.

New expected results come from complete original IPC input rows and independent
Python integer grouping/count/sum. The byte-exact previously verified IPC reader
transports rows without an external engine query. Literal-answer, schema,
reverse-order, empty-input, and malformed-declaration controls must pass before
reference generation. Native outputs never supply expected values.

The accepted runtime is the retained shared-window runtime. The join-mapping
closeout proves that the intervening rejected candidate left runtime sources
unchanged; its separate CI cleanup and status-document differences remain
explicit. Audit all available exact accepted-runtime observations. Current
declaration inventory finds 159 possible J-baseline matches and no T/D matches;
reuse is admitted only after complete packet, job, input, reference, schema,
output, resource, ownership, runtime, and engine-clock verification. Measure
only the remaining 2,384 baseline requests if that audit passes.

Before any scored baseline or candidate request, freeze candidate source,
release-build and runtime identities after default/native validation, native
test discovery, debug-only work/ownership attribution, and installed-package
proof. Then execute the missing baseline requests once and the full candidate
cohort once. Keep all other task work and agents idle during execution. No
warmups, repeats, profiling, cache manipulation, or pacing are added. Preserve
the existing per-request supervisor, memory/storage limits, deadlines, process
cleanup, full-result checks, and before/after hashing. Preparation and replay
are separate from engine execution.

After complete correctness, resource, ownership, and no-fallback proof, strictly
lower total engine_execution_seconds retains the candidate; equal or higher
drops it. There is no minimum percentage gain. Preserve every individual and
family regression, failed observation, and single-observation limitation.
No Full43, complete 10k, superiority, package publication, or whole-process
memory claim follows from this investigation.
