# B: bounded direct grouped COUNT investigation

November 12, 2026. Status: feasibility only; no runtime candidate or scored
protocol is admitted by this declaration. Existing RFC 0044 aggregate, source,
resource and output owners remain authoritative. The expert comparator is a
columnar-engine maintainer checking semantics, physical work and allocation
lifetimes together.

## Starting point and retained observations

Start from accepted main `3a0608b12e40435fab1adc4afefbaa4173932737`, tree
`ef1ebe017aaedcc858098106480f20c5ff82a102`, after A/PR #1681 completed all
58 PR checks, 55 exact-main checks, clear review, retirement and replay.
A's fixed 940-case candidate was rejected. Its 653.057359901 baseline and
739.927898219 candidate engine seconds and every failure remain unchanged.
The retained runtime is shared-window-state-2026-11-11/runtime-r1, built from
source fingerprint `51e9a408564dd45e5507782727348da0204a05142a6cc1d28647abb83ea9285a`.
The accepted repository fingerprint is
`f3b5df1f92c9948a1aa5a3c3ab7655370fec7b807d942c19596ae586a2bfbbd5`.
Eight named status documents and two independently verified CI cleanup scripts
differ from that runtime's build. The prior closeout records every before/after
identity; complete-repository equality is explicitly false. Runtime source
equality excludes exactly those named paths. Protect all 220 current inputs,
accepted runtime/wheel identities, prior compact evidence and original failures.

## Provider check and prospective mechanism

Pinned Vortex CountGroupedKernel consumes already grouped lists and ranges;
it does not group a flat key stream. Its default NaN and unchecked partial
addition policies do not replace ShardLoom's checked COUNT semantics.
The prospective decision is implement_shardloom_kernel by reusing existing
count_numeric_values/count_numeric_constant and shared Aggregate state.
No new source, grouped-list engine, Arrow execution route or external fallback
is proposed. Preserve native selected numeric buffers, validity, certificates
and the existing producer and output owner.

The hypothesis is that a per-batch numeric partial can reduce repeated key
interning, ordinal production and count updates. The existing ordinary path
already caches inline keys and reads only COUNT argument validity; neither a
source-format decline nor fewer ordinals proves a saving. Sorting/copying and
overlapping credits may cost more than the work removed.

Prospective admission is one nonnullable I32/I64/U64 group key and one COUNT,
with a nonnullable column argument when present, no expansion, distinct,
measure filter or secondary argument, and an immediate total sort containing
the unique group key. No-sort output retains first-encounter order. Original
projection, selection, COUNT parent-validity and error ordering remain owed.
Optional scratch denial precedes any mutation; errors after mutation cannot
replay input. Ordinary, typed compact and generic compact states require exact
checked weights. All input-row-capacity partials, reduced key buffers, ordinals,
state and overlapping owners retain actual credits until payload release.
Do not infer allocation or unique backing from logical lengths.

## Unscored feasibility observations

Before each observation freeze its exact request, input identities, expected
complete output and diagnostic source/build identity. Preserve failed attempts.
No production candidate is selected until actual physical exposure and useful
removable work are established.

1. Reconstruct and retain the eleven saved direct grouped declarations with one
   nonnullable I64 key and COUNT(nonnullable I64). Preserve every transform,
   filter, ordering direction, cap, profile, format, surface and identity.
   These comprise six Parquet, two IPC and three Vortex declarations. Source
   declarations alone are not measured activation. Nine transform their input;
   all nine count-order declarations also require descending key ties.
2. Add a bounded COUNT-only diagnostic through the existing shared prepared
   owner. Cover direct Parquet/IPC, prepared Vortex and native memory or an
   actual native intermediate; include repeated, unique, empty and tiny keys,
   transformed selections, nullable controls and ordinary source-order output.
   Version missing compositions instead of relabelling saved declarations.
3. In debug tests record aggregate input batch/row counts, physical key encoding,
   prepared numeric domain, group ordinals, exact lookups/cache hits and actual
   COUNT updates. Existing aggregate_row_updates omits COUNT(column); do not use
   it as complete COUNT attribution. Validate complete rows, schema, consumption,
   certificates, output ownership and final memory refund.
4. Separately use the existing release-only disjoint grouped-cost scopes on
   declared COUNT-only requests. No per-row debug instrumentation is compiled
   into release attribution or a future scored runtime. Record complete engine
   time and source/group-preparation/interning/state/measure/update/finalizer
   scopes with downstream excluded. Do not treat diagnostic instrumentation as
   the production engine timing or a baseline/candidate result.

Use the proven task guard with the unchanged 12-GiB free-space floor,
100-GiB workspace ceilings, 192-MiB log allowance, 8-MiB per-command output cap,
deadlines and process-group cleanup. Cargo output is resolved by metadata and
stays in /Users/dylan/.cache/shardloom/cargo-target. Keep full input hashes and
source/evidence inventories outside query execution; active output and workload
checks remain. No other task-owned jobs, builds or agents run during queries.

## Later decision gate

If feasibility supports an implementation, freeze one candidate and complete
cohort/reuse map before scoring. Include all affected saved COUNT requests,
neighbors, formats and five public surfaces, source-order and sort directions,
nullable keys/arguments, mixed measures, pressure/spill, cancellation, denied
scratch and owner-release controls. Version missing compositions and validate
them against independent references. Every baseline observation must match its
exact source/runtime/input/request identity; missing cases execute once under
a predefined baseline protocol.

Correctness, resource, ownership and no-fallback proof precede the binary gate:
strictly lower complete-cohort engine time retains the fixed candidate; equal
or higher drops it. No minimum gain, repeat-to-win loop, post-score tuning,
Full43, full10k repeat, publication or new fallback is authorized here. Keep
original limitations and failures visible. A full decision includes required
local/default/native/installed checks, portable evidence with corruption controls,
ready PR, hosted review/checks, merge, exact-main checks and verified retirement.
This does not close the remaining investigations, item 19/20 or CG-1 through CG-23.
