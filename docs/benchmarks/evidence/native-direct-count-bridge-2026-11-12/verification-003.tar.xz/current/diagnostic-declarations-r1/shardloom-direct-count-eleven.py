#!/usr/bin/env python3
"""Extract and identity-check the frozen eleven direct grouped COUNT declarations.

Declaration-only: imports the frozen query-surface model/builders, but never imports
ShardLoom runtime/native code or submits a query. Writes only the paired JSON/TXT outputs.
"""
from __future__ import annotations

import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

BASE = Path("/Users/dylan/LocalData/shardloom/expanded-query-2026-11-03")
FROZEN = BASE / "investigation-original-harness-r1"
INPUT = Path("/Users/dylan/.codex/tmp/shardloom-direct-count-capabilities-inventory.json")
REFERENCE = Path("/Users/dylan/.codex/tmp/shardloom-direct-count-capabilities-inventory.py")
DESIGN = BASE / "design.json"
OUT = Path("/Users/dylan/.codex/tmp/shardloom-direct-count-eleven")
sys.path[:0] = [str(FROZEN / "python/src"), str(FROZEN / "benchmarks/traditional_analytics")]

from query_surface.corpus import corpus  # noqa: E402
from query_surface.expanded_catalog import build, spaces  # noqa: E402


I64_NONNULL = {"name": "int64", "nullable": False, "parameters": []}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    inventory = json.loads(INPUT.read_text())
    design = json.loads(DESIGN.read_text())
    assert inventory["status"] == "passed"
    assert inventory["runtime_queries_native_imports_builds_or_timing"] is False
    design_rows = {row["id"]: row for row in design["cases"]}
    original_cases = {case.id: case for case in corpus(interactions="all", include_pending=False)}
    definitions = {space.name: space for space in spaces()}

    selected = []
    for row in inventory["records"]:
        groups = row["group_keys"]
        arg = row["count_argument"]
        if not (
            len(groups) == 1
            and groups[0]["dtype"] == I64_NONNULL
            and arg is not None
            and arg["op"] == "column"
            and row["count_argument_dtype"] == I64_NONNULL
        ):
            continue
        selected.append(row)
    assert len(selected) == 11, f"expected exact frozen cohort of 11, got {len(selected)}"
    assert len({row["case_id"] for row in selected}) == 11

    records = []
    for saved in selected:
        case_id = saved["case_id"]
        frozen = design_rows[case_id]
        case = build(frozen, definitions) if "cell" in frozen else original_cases[case_id]
        assert case.id == case_id
        assert case.identity == frozen["case_identity"] == saved["case_identity"]
        assert case.relation is not None
        # Source-provided serializer: Case.record() recursively serializes the full
        # typed relation tree, schema, result contract, and declared surfaces.
        typed_request = case.record()
        assert typed_request["id"] == case_id
        assert typed_request["relation"] == case.relation.record()
        # Keep each saved declaration byte-for-value; the typed request is an
        # additional faithful serialization, never a replacement or normalization.
        records.append({
            "saved_declaration": saved,
            "typed_relation_request": typed_request,
        })

    counts = {
        "records": len(records),
        "native_format": dict(sorted(Counter(r["saved_declaration"]["native_format"] for r in records).items())),
        "polars_format": dict(sorted(Counter(r["saved_declaration"]["polars_format"] for r in records).items())),
        "profile": dict(sorted(Counter(r["saved_declaration"]["profile"] for r in records).items())),
        "surface": dict(sorted(Counter(r["saved_declaration"]["surface"] for r in records).items())),
    }
    # Verify each saved format/profile/surface is faithfully carried into the
    # source serializer where it has a counterpart (surfaces are serialized as
    # the complete supported surface set, so the requested surface stays in the
    # preserved saved declaration).
    assert counts["records"] == 11
    hashes = {
        "extractor_script": sha(Path(__file__).resolve()),
        "capabilities_inventory_json": sha(INPUT),
        "declaration_only_reference_script": sha(REFERENCE),
        "design_json": sha(DESIGN),
        "frozen_imported_sources": {},
        "provenance_hashes_from_capabilities_inventory": inventory["source_sha256"],
    }
    for module in sys.modules.values():
        filename = getattr(module, "__file__", None)
        if filename:
            path = Path(filename).resolve()
            if path.is_relative_to(FROZEN) and path.is_file():
                hashes["frozen_imported_sources"][str(path.relative_to(FROZEN))] = sha(path)
    hashes["frozen_imported_sources"] = dict(sorted(hashes["frozen_imported_sources"].items()))

    report = {
        "status": "passed",
        "scope": "literal_frozen_declaration_extraction_only",
        "runtime_queries_native_imports_builds_or_timing": False,
        "selection": {
            "source_inventory": str(INPUT),
            "predicate": "exactly one nonnullable int64 group key; COUNT(column) argument is a nonnullable int64 column",
            "selected_count": 11,
        },
        "counts": counts,
        "typed_relation_request_serializer": "query_surface.specification.Case.record() including Relation.record()",
        "declaration_integrity": {
            "saved_declarations_copied_without_field_changes": True,
            "case_identity_reconstructed_from_frozen_harness": True,
            "all_identities_match_saved_inventory_and_design": True,
            "saved_declaration_field_names": sorted(selected[0].keys()),
        },
        "source_sha256": hashes,
        "records": records,
    }
    OUT.with_suffix(".json").write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n")

    lines = [
        "Frozen direct grouped COUNT declaration cohort",
        "Status: passed (declaration extraction only; no runtime queries, native imports, builds, or timing)",
        "Selection: exactly one nonnullable I64 group key and COUNT(nonnullable I64 column)",
        "Typed request: frozen source serializer Case.record() / Relation.record()",
        f"Records: {counts['records']}",
        f"Native formats: {json.dumps(counts['native_format'], sort_keys=True)}",
        f"Polars formats: {json.dumps(counts['polars_format'], sort_keys=True)}",
        f"Profiles: {json.dumps(counts['profile'], sort_keys=True)}",
        f"Surfaces: {json.dumps(counts['surface'], sort_keys=True)}",
        "",
        "case_id | identity | profile | surface | native_format | polars_format | group_key | count_argument",
    ]
    for entry in records:
        row = entry["saved_declaration"]
        lines.append(" | ".join([
            row["case_id"], row["case_identity"], row["profile"], row["surface"],
            row["native_format"], row["polars_format"], row["group_keys"][0]["column_name"],
            row["count_argument"]["value"],
        ]))
    lines.extend(["", "SHA256 sources:"])
    for label in ("extractor_script", "capabilities_inventory_json", "declaration_only_reference_script", "design_json"):
        lines.append(f"{label}: {hashes[label]}")
    lines.append("Frozen imported sources:")
    lines.extend(f"  {name}: {digest}" for name, digest in hashes["frozen_imported_sources"].items())
    lines.append("Inherited inventory provenance source hashes:")
    provenance = hashes["provenance_hashes_from_capabilities_inventory"]
    for label in ("old_inventory_py", "old_inventory_json", "design_json"):
        lines.append(f"  {label}: {provenance[label]}")
    lines.extend(f"  {name}: {digest}" for name, digest in provenance["loaded_frozen_sources"].items())
    lines.append("")
    lines.append("No admission, execution, performance, or diagnostic conclusions are represented.")
    OUT.with_suffix(".txt").write_text("\n".join(lines) + "\n")
    print(json.dumps({"status": "passed", "records": len(records), "counts": counts}, sort_keys=True))


if __name__ == "__main__":
    main()
