#!/usr/bin/env python3
"""Link the exact saved eleven declarations to retained input/reference sources.

This performs read-only metadata and saved-reference lookups. It does not hash large
input payloads, import runtime/native libraries, or execute declarations.
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
import zlib
from pathlib import Path

E = Path("/Users/dylan/LocalData/shardloom/expanded-query-2026-11-03")
S = Path("/Users/dylan/LocalData/shardloom/shared-operator-state-2026-11-10")
J = Path("/Users/dylan/LocalData/shardloom/join-mapping-2026-11-11")
DECLARATIONS = Path("/Users/dylan/.codex/tmp/shardloom-direct-count-eleven.json")
OUT = Path("/Users/dylan/.codex/tmp/shardloom-direct-count-eleven-sources")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def generation(path: Path) -> dict:
    stat = path.stat()
    return {
        "device": stat.st_dev,
        "inode": stat.st_ino,
        "bytes": stat.st_size,
        "mtime_ns": stat.st_mtime_ns,
        "ctime_ns": stat.st_ctime_ns,
    }


def expected_schema(doc: dict) -> list:
    return doc["schema"]


def main() -> None:
    declarations = json.loads(DECLARATIONS.read_text())
    assert declarations["status"] == "passed" and len(declarations["records"]) == 11
    inputs_path = E / "inputs.json"
    inputs = json.loads(inputs_path.read_text())
    preparation_index_path = E / "native-preparation/complete.json"
    preparation_index = json.loads(preparation_index_path.read_text())
    operator_index_path = S / "index-cohort-selection-r1.json"
    operator_index = json.loads(operator_index_path.read_text())
    index_cases = {row["case"]["id"]: row["case"] for row in operator_index["cases"]}
    indexed_files = {row["path"]: row for row in inputs["files"]}

    sources = []
    expected_artifacts = {}
    for entry in declarations["records"]:
        saved = entry["saved_declaration"]
        case_id = saved["case_id"]
        identity = saved["case_identity"]
        profile = saved["profile"]
        native_format = saved["native_format"]
        index_case = index_cases.get(case_id)
        if index_case is not None:
            assert index_case["case_identity"] == identity, f"operator-state identity mismatch: {case_id}"

        profile_input = inputs["profiles"][profile]
        format_tables = profile_input["sources"].get(native_format)
        source_state = "unresolved"
        source_paths = []
        source_manifest_path = Path(profile_input["dataset"]) / "dataset.json"
        source_manifest_identity = None
        if format_tables and format_tables.get("fact"):
            source_paths = format_tables["fact"]
            manifest_ok = False
            if source_manifest_path.is_file():
                manifest = json.loads(source_manifest_path.read_text())
                source_manifest_identity = {
                    "path": str(source_manifest_path),
                    "logical_identity": manifest.get("logical_identity"),
                    "layout": manifest.get("layout"),
                    "spec": manifest.get("spec"),
                }
                manifest_ok = (
                    manifest.get("logical_identity") == profile_input["logical_identity"]
                    and manifest.get("layout") == profile_input["layout"]
                    and manifest.get("spec") == profile_input["spec"]
                )
            file_rows = []
            for raw_path in source_paths:
                path = Path(raw_path)
                row = indexed_files.get(str(path))
                if row is None:
                    file_rows.append({"path": str(path), "status": "missing_from_input_file_index"})
                    continue
                exists = path.is_file() and not path.is_symlink()
                observed_generation = generation(path) if exists else None
                file_rows.append({
                    "path": str(path),
                    "exists_regular_file": exists,
                    "declared_sha256": row["sha256"],
                    "declared_generation": row["generation"],
                    "observed_generation": observed_generation,
                    "generation_matches": (
                        all(observed_generation[key] == row["generation"][key]
                            for key in ("inode", "bytes", "mtime_ns", "ctime_ns"))
                        if exists else False
                    ),
                    "device_matches": observed_generation.get("device") == row["generation"].get("device") if exists else False,
                    "payload_hashed": False,
                })
            if (manifest_ok and file_rows and all(
                    row.get("exists_regular_file") and row.get("generation_matches")
                    for row in file_rows)):
                source_state = ("resolved_by_profile_manifest_and_input_file_identity_device_id_differs"
                                if any(not row["device_matches"] for row in file_rows)
                                else "resolved_by_profile_manifest_and_input_file_identity")
            else:
                source_state = "unresolved_source_identity_or_generation_mismatch"
            sources.append({
                "case_id": case_id,
                "case_identity": identity,
            "operator_state_index_status": "present_identity_matches" if index_case else "not_selected_in_operator_state_index",
                "profile": profile,
                "native_format": native_format,
                "profile_logical_identity": profile_input["logical_identity"],
                "profile_dataset": profile_input["dataset"],
                "profile_layout": profile_input["layout"],
                "profile_spec": profile_input["spec"],
                "format_fact_source_paths": source_paths,
                "source_dataset_manifest": source_manifest_identity,
                "source_files": file_rows,
                "status": source_state,
            })
        elif native_format == "vortex":
            prepared_path = E / "native-preparation" / profile / "prepared.json"
            if prepared_path.is_file():
                prepared = json.loads(prepared_path.read_text())
                fact_items = [row for row in prepared.get("inputs", [])
                              if Path(row["path"]).name.startswith("fact-")]
                source_paths = [row["path"] for row in fact_items]
                prepared_rows = []
                for declared in fact_items:
                    path = Path(declared["path"])
                    exists = path.is_file() and not path.is_symlink()
                    observed = generation(path) if exists else None
                    saved_gen = declared["generation"]
                    same_stable_generation = exists and all(
                        observed[key] == saved_gen[key]
                        for key in ("inode", "bytes", "mtime_ns", "ctime_ns")
                    )
                    prepared_rows.append({
                        "path": str(path),
                        "exists_regular_file": exists,
                        "declared_sha256": declared["sha256"],
                        "declared_generation": saved_gen,
                        "observed_generation": observed,
                        "generation_matches_except_device": same_stable_generation,
                        "device_matches": observed.get("device") == saved_gen.get("device") if exists else False,
                        "payload_hashed": False,
                    })
                identity_matches = prepared.get("logical_identity") == profile_input["logical_identity"]
                independent_readback = prepared.get("complete_independent_readback") is True
                index_entry = preparation_index.get("profiles", {}).get(profile, {}).get("manifest", {})
                manifest_hash_matches_index = bool(index_entry and index_entry.get("sha256") == sha(prepared_path))
                valid = bool(prepared_rows and identity_matches and independent_readback
                             and manifest_hash_matches_index
                             and all(row["generation_matches_except_device"] for row in prepared_rows))
                state = (
                    "resolved_by_native_preparation_manifest_and_independent_readback_device_id_differs"
                    if valid and any(not row["device_matches"] for row in prepared_rows)
                    else "resolved_by_native_preparation_manifest_and_independent_readback"
                    if valid else "unresolved_native_preparation_manifest_or_generation_mismatch"
                )
                sources.append({
                    "case_id": case_id,
                    "case_identity": identity,
                    "operator_state_index_status": "present_identity_matches" if index_case else "not_selected_in_operator_state_index",
                    "profile": profile,
                    "native_format": native_format,
                    "profile_logical_identity": profile_input["logical_identity"],
                    "format_fact_source_paths": source_paths,
                    "native_preparation_manifest": str(prepared_path),
                    "native_preparation_manifest_sha256": sha(prepared_path),
                    "native_preparation_index": str(preparation_index_path),
                    "native_preparation_index_sha256": sha(preparation_index_path),
                    "native_preparation_manifest_matches_index": manifest_hash_matches_index,
                    "native_preparation_identity_matches": identity_matches,
                    "complete_independent_readback": independent_readback,
                    "source_files": prepared_rows,
                    "status": state,
                })
            else:
                sources.append({
                    "case_id": case_id,
                    "case_identity": identity,
                    "profile": profile,
                    "native_format": native_format,
                    "profile_logical_identity": profile_input["logical_identity"],
                    "format_fact_source_paths": [],
                    "status": "unresolved_no_native_preparation_manifest",
                })
        else:
            sources.append({
                "case_id": case_id,
                "case_identity": identity,
                "profile": profile,
                "native_format": native_format,
                "profile_logical_identity": profile_input["logical_identity"],
                "format_fact_source_paths": source_paths,
                "status": "unresolved_no_source_for_declared_native_format_profile",
            })

        ref_dir = E / f"reference-{profile}"
        complete_path = ref_dir / "complete.json"
        ref_inputs_path = ref_dir / "inputs.json"
        db_path = ref_dir / "expectations.sqlite"
        ref_status = "unresolved"
        expected_artifacts[case_id] = None
        if complete_path.is_file() and ref_inputs_path.is_file() and db_path.is_file():
            complete = json.loads(complete_path.read_text())
            ref_inputs = json.loads(ref_inputs_path.read_text())
            expected_meta = complete.get("expectations", {})
            db_hash_from_closeout = expected_meta.get("sha256")
            if (complete.get("status") == "passed"
                    and expected_meta.get("path") == str(db_path)
                    and ref_inputs.get("logical_identity") == profile_input["logical_identity"]):
                uri = f"file:{db_path}?mode=ro"
                with sqlite3.connect(uri, uri=True) as db:
                    row = db.execute(
                        "SELECT identity, value FROM expected WHERE id=?", (case_id,)
                    ).fetchone()
                if row is not None and row[0] == identity:
                    blob = bytes(row[1])
                    document = json.loads(zlib.decompress(blob))
                    request_contract = entry["typed_relation_request"]["contract"]
                    schema_matches = document.get("schema") == expected_schema(request_contract)
                    expected_artifacts[case_id] = {
                        "path": str(db_path),
                        "member": f"expected[id={case_id!r}]",
                        "case_identity": row[0],
                        "compressed_result_sha256": hashlib.sha256(blob).hexdigest(),
                        "compressed_result_bytes": len(blob),
                        "result_row_count": len(document.get("rows", [])),
                        "schema": document.get("schema"),
                        "schema_matches_typed_contract": schema_matches,
                        "ordered": request_contract["ordered"],
                        "expected_ordering": saved["outer_sort_limit_chain_outer_to_inner"],
                        "reference_profile_closeout": str(complete_path),
                        "reference_profile_closeout_sha256": sha(complete_path),
                        "reference_profile_inputs": str(ref_inputs_path),
                        "reference_profile_inputs_sha256": sha(ref_inputs_path),
                        "database_sha256_from_closeout": db_hash_from_closeout,
                        "database_payload_rehashed": False,
                    }
                    ref_status = "resolved_saved_independent_reference"
                    assert schema_matches, f"expected schema differs from typed contract: {case_id}"
                elif row is None:
                    ref_status = "unresolved_case_id_absent_from_profile_reference"
                else:
                    ref_status = "unresolved_case_identity_mismatch_in_profile_reference"
            else:
                ref_status = "unresolved_profile_or_reference_closeout_binding_mismatch"
        sources[-1]["independent_reference_status"] = ref_status
        sources[-1]["independent_reference"] = expected_artifacts[case_id]
        sources[-1]["current_runtime_result_status"] = "not_searched_or_inferred_in_this_read_only_lookup"

    assert len(sources) == 11 and len({row["case_id"] for row in sources}) == 11
    coverage = {
        "records": len(sources),
        "source_status": {},
        "reference_status": {},
        "profiles": {},
        "native_formats": {},
        "operator_state_index_matches": 0,
        "all_reference_identities_match": all(
            row["independent_reference"] is not None
            and row["independent_reference"]["case_identity"] == row["case_identity"]
            for row in sources
        ),
        "all_reference_schemas_match_contract": all(
            row["independent_reference"] is not None
            and row["independent_reference"]["schema_matches_typed_contract"]
            for row in sources
        ),
        "all_source_files_resolved": all(row["status"].startswith("resolved_by_") for row in sources),
    }
    for row in sources:
        if row.get("operator_state_index_status") == "present_identity_matches":
            coverage["operator_state_index_matches"] += 1
        coverage["source_status"][row["status"]] = coverage["source_status"].get(row["status"], 0) + 1
        ref_status = row["independent_reference_status"]
        coverage["reference_status"][ref_status] = coverage["reference_status"].get(ref_status, 0) + 1
        coverage["profiles"][row["profile"]] = coverage["profiles"].get(row["profile"], 0) + 1
        coverage["native_formats"][row["native_format"]] = coverage["native_formats"].get(row["native_format"], 0) + 1

    small_sources = [
        DECLARATIONS,
        E / "inputs.json",
        E / "design.json",
        E / "native-preparation/holdout/prepared.json",
        E / "native-preparation/scale/prepared.json",
        E / "native-preparation/smoke/prepared.json",
        E / "native-preparation/complete.json",
        E / "reference-primary/inputs.json", E / "reference-primary/complete.json",
        E / "reference-holdout/inputs.json", E / "reference-holdout/complete.json",
        E / "reference-scale/inputs.json", E / "reference-scale/complete.json",
        E / "investigation-original-harness-r1/benchmarks/traditional_analytics/query_surface/expanded_freeze.py",
        E / "investigation-original-harness-r1/benchmarks/traditional_analytics/query_surface/specification.py",
        S / "index-cohort-selection-r1.json",
        S / "saved-exposure-r1.json",
        J / "tools/join_mapping_common.py",
        J / "tools/join_mapping_reference_inputs.py",
        J / "tools/check_join_mapping_reference_inputs.py",
        J / "tools/prepare_join_mapping_references.py",
    ]
    source_hashes = {str(path): sha(path) for path in small_sources if path.is_file()}
    report = {
        "status": "passed_source_and_reference_lookup" if all(coverage[k] for k in (
            "all_reference_identities_match", "all_reference_schemas_match_contract", "all_source_files_resolved")) else "needs_reasoning",
        "scope": "read_only_source_and_original_reference_inventory",
        "result_distinction": {
            "original_independent_references": "available and identity-linked for all 11 declarations",
            "current_runtime_results": "not searched or inferred in this read-only lookup",
        },
        "input_payload_hashing": "large source payloads were not hashed; file SHA256 values are cited from E/inputs.json and guarded by recorded file-generation checks",
        "reference_payload_hashing": "full SQLite files were not rehashed; closeout-provided database SHA256 is cited and each selected compressed result BLOB was hashed",
        "coverage": coverage,
        "source_sha256": source_hashes,
        "records": sources,
        "unresolved": [
            {"case_id": row["case_id"], "case_identity": row["case_identity"],
             "source_status": row["status"], "reference_status": row["independent_reference_status"]}
            for row in sources
            if not row["status"].startswith("resolved_by_")
            or row["independent_reference_status"] != "resolved_saved_independent_reference"
        ],
        "navigation_note": "S index-cohort-selection-r1.json contains these exact IDs/identities and historical declarations. E inputs.json and per-profile reference complete/inputs manifests bind physical sources and independent expectations. J helper sources identify the E datasets/reference boundary; they do not supply results for these eleven declarations.",
    }
    OUT.with_suffix(".json").write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n")
    lines = [
        "Direct grouped COUNT source and original-reference lookup",
        f"Status: {report['status']}",
        "Current runtime results: not used or inferred.",
        f"Original independent reference records: {coverage['reference_status'].get('resolved_saved_independent_reference', 0)} available; current-runtime outcomes were not searched or inferred.",
        "Source resolution counts: " + json.dumps(coverage["source_status"], sort_keys=True),
        "Independent original reference counts: " + json.dumps(coverage["reference_status"], sort_keys=True),
        "Profiles: " + json.dumps(coverage["profiles"], sort_keys=True),
        "Native formats: " + json.dumps(coverage["native_formats"], sort_keys=True),
        "",
    ]
    for row in sources:
        ref = row["independent_reference"]
        lines.extend([
            f"{row['case_id']} | {row['case_identity']}",
            f"  profile/format: {row['profile']} / {row['native_format']}",
            f"  source: {row['status']}",
            f"  paths: {', '.join(row['format_fact_source_paths']) or '[unresolved]'}",
            f"  independent reference: {row['independent_reference_status']}",
            f"  result: {ref['path']} member {ref['member']}" if ref else "  result: UNRESOLVED",
            f"  rows/schema/order: {ref['result_row_count']} / {json.dumps(ref['schema'], sort_keys=True)} / ordered={ref['ordered']}; sort={json.dumps(ref['expected_ordering'], sort_keys=True)}" if ref else "  expected schema/order: unresolved",
            "",
        ])
    lines.append("SHA256 for small declaration/reference/index sources:")
    lines.extend(f"  {path}: {digest}" for path, digest in source_hashes.items())
    lines.append("Large input and complete SQLite payload files were not rehashed.")
    OUT.with_suffix(".txt").write_text("\n".join(lines) + "\n")
    print(json.dumps({"status": report["status"], "coverage": coverage, "unresolved": report["unresolved"]}, sort_keys=True))


if __name__ == "__main__":
    main()
