#!/usr/bin/env python3
"""Fail-closed analyzer for the frozen PERF-02.builder cohort samples."""

from __future__ import annotations

import argparse
from functools import lru_cache
import importlib.util
import json
import re
import statistics
import sys
from fractions import Fraction
from pathlib import Path
from typing import Any


SCHEMA = "shardloom.conditional_builder_samples.v1"
PHASES = {"warmup", "matrix", "churn"}
ROWS = (0, 64, 4096)
WIDTHS = (4, 12)
FAMILIES = (
    "computed_filter_project", "group_aggregate", "left_join",
    "stacked_limit", "union_distinct", "projection_sort",
)
ROLES = ("sql", "typed")
CALLS = (1, 8)
COSTS = (
    "source_setup", "frontend", "prepare", "execute", "consume", "release",
    "complete_workflow",
)
PHASE_FIELDS = {"phase", "rows", "width", "family", "calls", "role", "sample"}
HASH_FIELDS = (
    "protocol_sha256", "artifact_identity_sha256", "harness_sha256", "analyzer_sha256",
)
HASH_RE = re.compile(r"[0-9a-f]{64}\Z")
EXPECTED_MEMORY = 67_108_864
PROTOCOL_SHA256 = 'f0a6bb4250d0f4039403d5270b9c4a41c95b027de59f757a8068f3d4db6dd02e'
_SPEC = importlib.util.spec_from_file_location(
    'builder_oracle', Path(__file__).with_name('run_builder_756.py'))
oracle = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(oracle)


class AnalysisError(ValueError):
    """Input evidence is incomplete or inconsistent with the frozen protocol."""


def _integer(value: Any, label: str, *, minimum: int = 0) -> int:
    if type(value) is not int or value < minimum:
        raise AnalysisError(f"{label} must be an integer >= {minimum}")
    return value


def _hash(value: Any, label: str) -> str:
    if not isinstance(value, str) or not HASH_RE.fullmatch(value):
        raise AnalysisError(f"{label} must be a lowercase SHA-256 hex digest")
    return value


def _coverage() -> dict[str, set[tuple[Any, ...]]]:
    expected: dict[str, set[tuple[Any, ...]]] = {"warmup": set(), "matrix": set(), "churn": set()}
    for role in ROLES:
        expected["warmup"].add((64, 4, "computed_filter_project", 1, role, -1))
    for phase, rows_values, calls_values in (
        ("matrix", ROWS, CALLS), ("churn", (64,), (8,)),
    ):
        for rows in rows_values:
            for width in WIDTHS:
                for family in FAMILIES:
                    for calls in calls_values:
                        for role in ROLES:
                            for sample in range(5):
                                expected[phase].add((rows, width, family, calls, role, sample))
    return expected


EXPECTED = _coverage()


def _witness(values, fields, reused):
    return {'rows': len(values), 'values_sha256': oracle.digest(values),
            'schema_sha256': oracle.digest(oracle.schema(fields)),
            'declaration_reused': reused, 'fallback_attempted': False,
            'external_engine_invoked': False}


@lru_cache(maxsize=None)
def semantic_witnesses(phase, rows, width, family, calls):
    values, fields, right, right_fields = oracle.fixture(rows, width)
    parameters = range(calls) if phase == 'churn' else [0] * calls
    outputs = [_witness(*oracle.oracle(values, fields, right, family, parameter), True)
               for parameter in parameters]
    inputs = [_witness(values, fields, False)]
    if family == 'left_join':
        inputs.append(_witness(right, right_fields, False))
    return {'source_fixture_sha256': oracle.digest(
                [values, fields, right if family == 'left_join' else []]),
            'input_witnesses': inputs, 'output_witnesses': outputs}


def _load(path: str | Path, cohort: str) -> dict[str, Any]:
    try:
        raw = json.loads(Path(path).read_text(encoding="utf-8"), parse_constant=lambda x: (_ for _ in ()).throw(AnalysisError(f"non-finite JSON constant {x}")))
    except (OSError, json.JSONDecodeError) as exc:
        raise AnalysisError(f"cannot read {cohort} cohort JSON: {exc}") from exc
    if not isinstance(raw, dict) or raw.get("schema_version") != SCHEMA:
        raise AnalysisError(f"{cohort}: schema_version must be {SCHEMA!r}")
    if raw.get("cohort") != cohort:
        raise AnalysisError(f"{cohort}: cohort label mismatch")
    for name in HASH_FIELDS:
        _hash(raw.get(name), f"{cohort}.{name}")
    if raw['protocol_sha256'] != PROTOCOL_SHA256:
        raise AnalysisError(f'{cohort}: frozen protocol identity mismatch')
    if raw.get('status') != 'passed' or raw.get('validation_only') is not False:
        raise AnalysisError(f'{cohort}: requires a completed comparative cohort')
    records = raw.get("records")
    if not isinstance(records, list):
        raise AnalysisError(f"{cohort}.records must be an array")
    actual: dict[str, dict[tuple[Any, ...], dict[str, Any]]] = {p: {} for p in PHASES}
    for index, record in enumerate(records):
        label = f"{cohort}.records[{index}]"
        if not isinstance(record, dict):
            raise AnalysisError(f"{label} must be an object")
        phase = record.get("phase")
        if phase not in PHASES:
            raise AnalysisError(f"{label}.phase is invalid")
        rows = _integer(record.get("rows"), f"{label}.rows")
        width = _integer(record.get("width"), f"{label}.width", minimum=1)
        calls = _integer(record.get("calls"), f"{label}.calls", minimum=1)
        role = record.get("role")
        family = record.get("family")
        sample = record.get("sample")
        if role not in ROLES or not isinstance(family, str):
            raise AnalysisError(f"{label}: role/family invalid")
        if type(sample) is not int:
            raise AnalysisError(f"{label}.sample must be an integer")
        key = (rows, width, family, calls, role, sample)
        if key in actual[phase]:
            raise AnalysisError(f"{label}: duplicate {phase} cell {key}")
        if key not in EXPECTED[phase]:
            raise AnalysisError(f"{label}: unexpected {phase} cell {key}")
        costs = record.get("costs_nanos")
        if not isinstance(costs, dict) or set(costs) != set(COSTS):
            raise AnalysisError(f"{label}.costs_nanos must contain exactly {COSTS}")
        parsed_costs = {name: _integer(costs[name], f"{label}.costs_nanos.{name}") for name in COSTS}
        if parsed_costs["complete_workflow"] != sum(parsed_costs[k] for k in COSTS[:-1]):
            raise AnalysisError(f"{label}: complete_workflow does not equal the six component costs")
        if parsed_costs['complete_workflow'] == 0:
            raise AnalysisError(f'{label}: complete workflow clock must be positive')
        proof = record.get("proof")
        if not isinstance(proof, dict):
            raise AnalysisError(f"{label}.proof must be an object")
        for flag in ("complete_values", "complete_schema", "source_values", "no_fallback", "all_operations_completed"):
            if proof.get(flag) is not True:
                raise AnalysisError(f"{label}.proof.{flag} must be true")
        limit = _integer(proof.get("memory_limit_bytes"), f"{label}.proof.memory_limit_bytes", minimum=1)
        if limit != EXPECTED_MEMORY:
            raise AnalysisError(f"{label}.proof.memory_limit_bytes must equal {EXPECTED_MEMORY}")
        peak = _integer(proof.get("peak_reserved_bytes"), f"{label}.proof.peak_reserved_bytes")
        if peak > limit:
            raise AnalysisError(f"{label}: peak reservation exceeds memory grant")
        if _integer(proof.get("final_reserved_bytes"), f"{label}.proof.final_reserved_bytes") != 0:
            raise AnalysisError(f"{label}: final reservations must be zero")
        if _integer(proof.get("cpu_lanes"), f"{label}.proof.cpu_lanes", minimum=1) != 1:
            raise AnalysisError(f"{label}.proof.cpu_lanes must equal 1")
        expected_ops = _integer(proof.get("expected_operations"), f"{label}.proof.expected_operations", minimum=1)
        observed_ops = _integer(proof.get("observed_operations"), f"{label}.proof.observed_operations", minimum=1)
        if expected_ops != calls or observed_ops != calls:
            raise AnalysisError(f"{label}: expected/observed operations must equal calls")
        expected_semantics = semantic_witnesses(phase, rows, width, family, calls)
        for name, expected_value in expected_semantics.items():
            # JSON representation preserves integer/boolean distinctions that
            # Python equality would otherwise erase (0 == False, for example).
            if json.dumps(record.get(name), sort_keys=True) != json.dumps(expected_value, sort_keys=True):
                raise AnalysisError(f'{label}: complete {name} differs from the independent fixture/oracle')
        actual[phase][key] = {"costs_nanos": parsed_costs, "proof": proof}
    for phase in PHASES:
        missing = EXPECTED[phase] - actual[phase].keys()
        if missing:
            raise AnalysisError(f"{cohort}: missing {len(missing)} {phase} records; first={sorted(missing)[:1]}")
    raw["_cases"] = actual
    return raw


def _medians(cohort: dict[str, Any], phase: str) -> dict[tuple[Any, ...], int]:
    values: dict[tuple[Any, ...], list[int]] = {}
    for rows, width, family, calls, role, sample in EXPECTED[phase]:
        key = (rows, width, family, calls, role)
        value = cohort["_cases"][phase][(*key, sample)]["costs_nanos"]["complete_workflow"]
        values.setdefault(key, []).append(value)
    return {key: int(statistics.median(samples)) for key, samples in values.items()}


def _ratio(sql: int, typed: int) -> Fraction:
    return Fraction(typed, sql) if sql else (Fraction(1) if typed == 0 else Fraction(10**100))


def _cohort_result(cohort: dict[str, Any]) -> dict[str, Any]:
    med = {phase: _medians(cohort, phase) for phase in ("matrix", "churn", "warmup")}
    matrix = med["matrix"]
    sums = {
        role: sum(value for (*_key, role_value), value in matrix.items() if role_value == role)
        for role in ROLES
    }
    aggregate_ratio = _ratio(sums["sql"], sums["typed"])
    material = []
    for (rows, width, family, calls, role), typed_value in matrix.items():
        if role != "typed" or calls != 1:
            continue
        sql_value = matrix[(rows, width, family, calls, "sql")]
        if sql_value and Fraction(typed_value, sql_value) <= Fraction(9, 10):
            material.append({"rows": rows, "width": width, "family": family,
                             "sql_median_nanos": sql_value, "typed_median_nanos": typed_value})
    controls = []
    for phase in ("matrix", "churn"):
        for (rows, width, family, calls, role), typed_value in med[phase].items():
            if role != "typed":
                continue
            is_control = phase == "churn" or calls == 8 or family == "projection_sort"
            if not is_control:
                continue
            sql_value = med[phase][(rows, width, family, calls, "sql")]
            delta = typed_value - sql_value
            failed = delta > 0 and Fraction(delta, max(sql_value, 1)) > Fraction(1, 20) and delta > 1_000_000
            controls.append({"phase": phase, "rows": rows, "width": width,
                             "family": family, "calls": calls,
                             "sql_median_nanos": sql_value, "typed_median_nanos": typed_value,
                             "regression": failed})
    aggregate_pass = aggregate_ratio <= Fraction(97, 100)
    material_families = {cell["family"] for cell in material}
    material_pass = len(material_families) >= 2
    controls_pass = not any(row["regression"] for row in controls)
    return {
        "cohort": cohort["cohort"],
        "aggregate": {"sql_sum_medians_nanos": sums["sql"],
                      "typed_sum_medians_nanos": sums["typed"],
                      "typed_over_sql": f"{aggregate_ratio.numerator}/{aggregate_ratio.denominator}",
                      "required_max_ratio": "97/100", "passed": aggregate_pass},
        "material_cells": sorted(material, key=lambda x: (x["family"], x["rows"], x["width"])),
        "material_families": sorted(material_families),
        "material_cells_passed": material_pass,
        "controls": controls,
        "controls_passed": controls_pass,
        "medians": {phase: [
            {"rows": key[0], "width": key[1], "family": key[2], "calls": key[3],
             "role": key[4], "complete_workflow_nanos": value}
            for key, value in sorted(med[phase].items())
        ] for phase in ("matrix", "churn", "warmup")},
    }


def analyze(path_a: str | Path, path_b: str | Path) -> dict[str, Any]:
    a, b = _load(path_a, "a"), _load(path_b, "b")
    for name in HASH_FIELDS:
        if a[name] != b[name]:
            raise AnalysisError(f"cohort identity mismatch for {name}")
    results = [_cohort_result(a), _cohort_result(b)]
    material_by_key = []
    for result in results:
        material_by_key.append({
            (row["rows"], row["width"], row["family"]): row
            for row in result["material_cells"]
        })
    shared_material = [
        {"rows": key[0], "width": key[1], "family": key[2],
         "cohort_a": material_by_key[0][key], "cohort_b": material_by_key[1][key]}
        for key in sorted(material_by_key[0].keys() & material_by_key[1].keys())
    ]
    shared_families = {row["family"] for row in shared_material}
    shared_material_pass = len(shared_families) >= 2
    passed = all(
        result["aggregate"]["passed"] and result["material_cells_passed"] and result["controls_passed"]
        for result in results
    ) and shared_material_pass
    return {
        "schema_version": "shardloom.conditional_builder_analysis.v1",
        "protocol_sha256": a["protocol_sha256"],
        "artifact_identity_sha256": a["artifact_identity_sha256"],
        "harness_sha256": a["harness_sha256"],
        "analyzer_sha256": a["analyzer_sha256"],
        "complete_semantic_witnesses_verified": True,
        "verified_workflows": len(a['records']) + len(b['records']),
        "cohorts": results,
        "shared_material_cells": shared_material,
        "shared_material_families": sorted(shared_families),
        "shared_material_cells_passed": shared_material_pass,
        "decision": "retain_frontend_opportunity" if passed else "reject_current_typed_builder_under_frozen_workload",
        "passed": passed,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("cohort_a", type=Path)
    parser.add_argument("cohort_b", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args(argv)
    try:
        result = analyze(args.cohort_a, args.cohort_b)
        args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    except (AnalysisError, OSError) as exc:
        print(f"builder analysis failed: {exc}", file=sys.stderr)
        return 2
    print(f"decision={result['decision']} output={args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
