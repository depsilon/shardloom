"""Package the finite rejected builder-frontends experiment as a portable packet."""
from pathlib import Path
import hashlib
import io
import json
import lzma
import shutil
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
DEST = ROOT / 'builder-portable-packet-758'
NAME = 'native-builder-frontends-2026-10-19'
sys.path.insert(0, str(REPO / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def add_file(members, archive_name, path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), f'not a regular file: {path}'
    assert archive_name not in members, f'duplicate member: {archive_name}'
    members[archive_name] = path


# Check the original timing/preflight admission inputs before constructing the packet.
preflight = json.loads((ROOT / 'builder-preflight-758.json').read_text())
admission_path = ROOT / 'builder-timing-admission-758.json'
admission = json.loads(admission_path.read_text())
for entry in preflight['inputs']:
    assert digest(Path(entry['path']).read_bytes()) == entry['sha256'], entry['path']
for entry in admission['inputs']:
    assert digest(Path(entry['path']).read_bytes()) == entry['sha256'], entry['path']
for entry in admission['sources']:
    assert digest((REPO / entry['path']).read_bytes()) == entry['sha256'], entry['path']
freeze_path = ROOT / 'physical-retention-final-758-source-freeze.json'
freeze = json.loads(freeze_path.read_text())
for entry in freeze['sources']:
    assert digest((REPO / entry['path']).read_bytes()) == entry['sha256'], entry['path']
assert freeze['head'] == '030e615ef38bdfc2bb558698c20b5736d66547c4'

# The original validation failures and the exact historical harnesses are retained.
historical_harnesses = {
    'builder-preflight-original-757.py':
        'a61c88267b864c9610e4427242c62d673441f7ab81ccb70fe3505200cc3685e1',
    'builder-preflight-before-limits-758.py':
        'e7d9a536b3412adcbb5200fe5a982eabcfae0207de8f859440e9fb910c3526d4',
}
for filename, expected in historical_harnesses.items():
    path = ROOT / filename
    assert digest(path.read_bytes()) == expected, filename

assert preflight['status'] == 'passed'
assert preflight['failed_preflights_preserved'] == [
    'builder-validation-757.json', 'builder-validation-758.json']
assert preflight['comparative_execution_started'] is False
assert preflight['protocol_changed'] is False
assert preflight['decision_thresholds_changed'] is False
analysis = json.loads((ROOT / 'builder-analysis-758.json').read_text())
assert analysis['decision'] == 'reject_current_typed_builder_under_frozen_workload'
assert analysis['passed'] is False
assert analysis['complete_semantic_witnesses_verified'] is True
assert analysis['shared_material_cells_passed'] is True
assert [row['cohort'] for row in analysis['cohorts']] == ['a', 'b']
assert all(row['aggregate']['passed'] is False for row in analysis['cohorts'])
assert all(row['aggregate']['typed_over_sql'] for row in analysis['cohorts'])
assert all(row['aggregate']['required_max_ratio'] == '97/100'
           for row in analysis['cohorts'])

artifact_record = json.loads((ROOT / 'builder-public-artifact-758.json').read_text())
omitted_artifact = artifact_record['artifact']
omitted_path = Path(omitted_artifact['path'])
assert omitted_path.is_file()
assert omitted_path.stat().st_size == omitted_artifact['bytes']
assert digest(omitted_path.read_bytes()) == omitted_artifact['sha256']
assert artifact_record['publication_attempted'] is False
assert artifact_record['installed_wheel_proof'] is False

require_local_path(DEST, Path.home(), sys.platform)
check_budgets(ROOT, DEST, ROOT / 'logs', min_free_bytes=12 * GIB,
              reserve_bytes=128 * MIB, max_workspace_bytes=100 * GIB,
              max_log_bytes=192 * MIB)
assert not DEST.exists(), 'unique packet destination required'

members = {}
for pattern in ('builder*.json', 'builder*.log'):
    for path in sorted(ROOT.glob(pattern)):
        if path.is_file():
            add_file(members, 'evidence/' + path.name, path)
for filename in (
    'run_builder_756.py', 'analyze_builder_756.py',
    'test_analyze_builder_756.py', 'run_frozen_comparison_758.py',
    'run_guarded_observed_757.py', 'package_builder_evidence_758.py',
    'builder-preflight-original-757.py', 'builder-preflight-before-limits-758.py',
    'physical-retention-final-758-source-freeze.json',
    'physical-retention-final-758-tracked.patch',
    'physical-retention-python-staged-build-758.json',
    'physical-retention-python-staged-build-758.log',
):
    add_file(members, 'evidence/' + filename, ROOT / filename)
extra_root = ROOT / 'physical-retention-final-758-extra-sources'
assert extra_root.is_dir() and not extra_root.is_symlink()
extra_files = sorted(p for p in extra_root.rglob('*') if p.is_file())
assert extra_files and all(not p.is_symlink() for p in extra_files)
for path in extra_files:
    add_file(members, 'evidence/physical-retention-final-758-extra-sources/' +
             str(path.relative_to(extra_root)), path)

tools = {
    'tools/local_uat_storage.py': REPO / 'scripts/local_uat_storage.py',
    'tools/run_clickbench_paired_query_uat.py':
        REPO / 'scripts/run_clickbench_paired_query_uat.py',
    'tools/run_clickbench_query_uat.py': REPO / 'scripts/run_clickbench_query_uat.py',
    'tools/native_workflow_protocol.py': REPO / 'scripts/native_workflow_protocol.py',
    'tools/query_timing_report.py': REPO / 'scripts/query_timing_report.py',
    'tools/clickbench_reference_packet.py': REPO / 'scripts/clickbench_reference_packet.py',
    'tools/release_validation_guard.py':
        Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'),
    'tools/bounded_build_process_resume_20260912.py':
        Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py'),
}
for name, path in tools.items():
    add_file(members, name, path)
assert digest(tools['tools/bounded_build_process_resume_20260912.py'].read_bytes()) == (
    '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97')

required_samples = {
    'evidence/builder-cohort-a-samples-758.json',
    'evidence/builder-cohort-b-samples-758.json',
}
assert required_samples <= members.keys(), 'raw samples missing from archive input'
for name, path in sorted(members.items()):
    if name.startswith('evidence/builder') and name.endswith('.json'):
        value = json.loads(path.read_text())
        if isinstance(value, dict) and 'command' in value and 'status' in value:
            assert value['process_group_drained'] is True, name
            assert value['status'] in ('passed', 'failed'), name
            log = path.with_suffix('.log')
            assert log.is_file() and digest(log.read_bytes()) == value['log_sha256'], name

inventory = [{'path': name, 'bytes': path.stat().st_size,
              'sha256': digest(path.read_bytes())} for name, path in sorted(members.items())]
uncompressed_bytes = sum(row['bytes'] for row in inventory)
assert uncompressed_bytes < 32 * MIB, f'evidence packet exceeds 32 MiB: {uncompressed_bytes}'
assert len([n for n in members if n.startswith('evidence/builder-cohort-') and
            n.endswith('-samples-758.json')]) == 2

DEST.mkdir()
archive = DEST / (NAME + '.tar.xz')
with tarfile.open(archive, mode='w:xz', format=tarfile.PAX_FORMAT, preset=6) as output:
    for row in inventory:
        data = members[row['path']].read_bytes()
        assert len(data) == row['bytes'] and digest(data) == row['sha256']
        info = tarfile.TarInfo(row['path'])
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        output.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:xz') as source:
    assert source.getnames() == [row['path'] for row in inventory]
    for row in inventory:
        entry = source.getmember(row['path'])
        assert entry.isfile()
        data = source.extractfile(entry).read()
        assert len(data) == row['bytes'] and digest(data) == row['sha256']
        assert digest(members[row['path']].read_bytes()) == row['sha256']

manifest = DEST / (NAME + '.manifest.json.xz')
manifest_data = {'schema_version': 'shardloom.evidence_member_manifest.v1',
                 'all_members_reopened': True, 'members': inventory}
manifest.write_bytes(lzma.compress(encode(manifest_data), preset=6))
assert json.loads(lzma.decompress(manifest.read_bytes())) == manifest_data

index = {
    'schema_version': 'shardloom.native_builder_frontends_investigation.v1',
    'status': 'completed_drop',
    'decision': 'reject_existing_typed_builder_substitution_under_frozen_aggregate_gates',
    'investigated_substeps': ['PERF-02.builder'],
    'completed_substeps': [],
    'broader_owners_closed': [],
    'investigation_remains_open': True,
    'base_head': freeze['head'],
    'acceptance': '../../architecture/native-builder-frontends-2026-10-19.md',
    'archive': {'file': archive.name, 'bytes': archive.stat().st_size,
                'sha256': digest(archive.read_bytes())},
    'manifest': {'file': manifest.name, 'bytes': manifest.stat().st_size,
                 'sha256': digest(manifest.read_bytes())},
    'member_count': len(inventory), 'uncompressed_bytes': uncompressed_bytes,
    'all_members_reopened': True,
    'source_freeze': 'evidence/physical-retention-final-758-source-freeze.json',
    'tracked_patch': 'evidence/physical-retention-final-758-tracked.patch',
    'extra_sources': 'evidence/physical-retention-final-758-extra-sources',
    'replay': 'Start from base_head, apply the included tracked patch, then add the included extra source tree; the resulting source identity is recorded in source_freeze.',
    'frozen_admission_hashes_verified': {
        'builder_preflight_inputs': len(preflight['inputs']),
        'timing_admission_inputs': len(admission['inputs']),
        'timing_admission_sources': len(admission['sources']),
        'source_freeze_sources': len(freeze['sources']),
    },
    'failed_preflights_preserved': preflight['failed_preflights_preserved'],
    'historical_harnesses': [
        {'path': 'evidence/' + name, 'sha256': sha}
        for name, sha in historical_harnesses.items()],
    'candidate_result': {
        'complete_semantic_witnesses_verified': analysis['complete_semantic_witnesses_verified'],
        'shared_material_cells_passed': analysis['shared_material_cells_passed'],
        'aggregate_gate_passed': False,
        'required_max_ratio': '97/100',
        'cohort_typed_over_sql': [row['aggregate']['typed_over_sql']
                                  for row in analysis['cohorts']],
        'cohorts': [row['cohort'] for row in analysis['cohorts']],
        'production_routing_changes': False,
        'typed_api_changes': False,
        'candidate_to_remove': False,
    },
    'frozen_native_module_omitted': {
        'path': omitted_artifact['path'], 'bytes': omitted_artifact['bytes'],
        'sha256': omitted_artifact['sha256'],
        'reason': 'large frozen local executable is retained locally; portable source patch and build receipts are archived',
    },
    'installed_wheel_claim': False,
    'engine_or_full43_claim': False,
    'platform_scope': 'local macOS arm64',
}
index_path = DEST / (NAME + '.json')
index_path.write_bytes(encode(index))
check_budgets(ROOT, DEST, ROOT / 'logs', min_free_bytes=12 * GIB,
              reserve_bytes=0, max_workspace_bytes=100 * GIB,
              max_log_bytes=192 * MIB)
print(json.dumps({'status': 'passed', 'members': len(inventory),
                  'uncompressed_bytes': uncompressed_bytes,
                  'archive_bytes': index['archive']['bytes'],
                  'manifest_bytes': index['manifest']['bytes'],
                  'all_members_reopened': True, 'output': str(index_path)}))
