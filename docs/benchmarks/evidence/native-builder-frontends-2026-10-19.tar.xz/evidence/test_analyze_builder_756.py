from __future__ import annotations

import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest


ANALYZER_PATH = Path(__file__).with_name("analyze_builder_756.py")
SPEC = importlib.util.spec_from_file_location("analyze_builder_756", ANALYZER_PATH)
assert SPEC and SPEC.loader
analyzer = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(analyzer)


HASHES = {
    name: (f"{ord(name[0]):02x}" * 32)
    for name in analyzer.HASH_FIELDS
}
HASHES['protocol_sha256'] = analyzer.PROTOCOL_SHA256


def make_cohort(cohort: str) -> dict:
    records = []
    for phase, cells in analyzer.EXPECTED.items():
        for rows, width, family, calls, role, sample in sorted(cells):
            sql_cost = 10_000_000
            typed_cost = 9_500_000
            if phase == "churn":
                sql_cost = typed_cost = 10_000_000
            if phase == "matrix" and calls == 1 and family in {"computed_filter_project", "left_join"}:
                typed_cost = 8_900_000
            cost = sql_cost if role == "sql" else typed_cost
            if phase == "warmup":
                cost = 1_000_000
            costs = {
                "source_setup": 1_000_000,
                "frontend": cost - 5_000_000,
                "prepare": 1_000_000,
                "execute": 1_000_000,
                "consume": 1_000_000,
                "release": 1_000_000,
            }
            if costs["frontend"] < 0:
                costs["frontend"] = 0
            # Keep exact sum while allowing deterministic synthetic costs.
            costs["complete_workflow"] = sum(costs.values())
            records.append({
                "phase": phase, "rows": rows, "width": width, "family": family,
                "calls": calls, "role": role, "sample": sample,
                "costs_nanos": costs,
                **copy.deepcopy(analyzer.semantic_witnesses(phase, rows, width, family, calls)),
                "proof": {
                    "complete_values": True, "complete_schema": True, "source_values": True,
                    "no_fallback": True, "all_operations_completed": True,
                    "final_reserved_bytes": 0, "peak_reserved_bytes": 16_000_000,
                    "memory_limit_bytes": analyzer.EXPECTED_MEMORY, "cpu_lanes": 1,
                    "expected_operations": calls, "observed_operations": calls,
                },
            })
    payload = {"schema_version": analyzer.SCHEMA, "cohort": cohort,
               'status': 'passed', 'validation_only': False,
               **HASHES, "records": records}
    return payload


class AnalyzerTests(unittest.TestCase):
    def test_complete_semantic_witnesses_are_required_and_exact(self):
        valid = make_cohort('a')
        for field in ('source_fixture_sha256', 'input_witnesses', 'output_witnesses'):
            with self.subTest(missing=field), tempfile.TemporaryDirectory() as directory:
                broken = copy.deepcopy(valid)
                del broken['records'][0][field]
                path = Path(directory) / 'cohort.json'
                path.write_text(json.dumps(broken))
                with self.assertRaises(analyzer.AnalysisError):
                    analyzer._load(path, 'a')
        for field, value in (('values_sha256', 'f' * 64), ('schema_sha256', 'f' * 64),
                             ('rows', 999999), ('fallback_attempted', 0)):
            with self.subTest(changed=field), tempfile.TemporaryDirectory() as directory:
                broken = copy.deepcopy(valid)
                broken['records'][0]['output_witnesses'][0][field] = value
                path = Path(directory) / 'cohort.json'
                path.write_text(json.dumps(broken))
                with self.assertRaises(analyzer.AnalysisError):
                    analyzer._load(path, 'a')

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.a = make_cohort("a")
        self.b = make_cohort("b")

    def tearDown(self):
        self.temp.cleanup()

    def paths(self):
        pa, pb = self.root / "a.json", self.root / "b.json"
        pa.write_text(json.dumps(self.a), encoding="utf-8")
        pb.write_text(json.dumps(self.b), encoding="utf-8")
        return pa, pb

    def record(self, cohort, phase, key):
        return next(r for r in cohort["records"] if r["phase"] == phase and
                    (r["rows"], r["width"], r["family"], r["calls"], r["role"], r["sample"]) == key)

    def set_total(self, record, total):
        record["costs_nanos"]["frontend"] = total - sum(
            record["costs_nanos"][key] for key in analyzer.COSTS[:-1] if key != "frontend"
        )
        record["costs_nanos"]["complete_workflow"] = total

    def test_positive_full_coverage_retains_scope_and_warmup(self):
        a, b = self.paths()
        result = analyzer.analyze(a, b)
        self.assertTrue(result["passed"])
        self.assertEqual(result["decision"], "retain_frontend_opportunity")
        self.assertEqual(len(result["cohorts"][0]["medians"]["matrix"]), 144)
        self.assertEqual(len(result["cohorts"][0]["medians"]["churn"]), 24)
        self.assertEqual(len(result["cohorts"][0]["medians"]["warmup"]), 2)

    def test_aggregate_gate_failure(self):
        for cohort in (self.a, self.b):
            for record in cohort["records"]:
                if record["phase"] == "matrix" and record["role"] == "typed":
                    self.set_total(record, 10_000_000)
        a, b = self.paths()
        result = analyzer.analyze(a, b)
        self.assertFalse(result["cohorts"][0]["aggregate"]["passed"])

    def test_same_family_material_cells_do_not_pass(self):
        for cohort in (self.a, self.b):
            for record in cohort["records"]:
                if record["phase"] == "matrix" and record["role"] == "typed" and record["calls"] == 1:
                    self.set_total(record, 8_000_000 if record["family"] == "computed_filter_project" else 9_500_000)
        a, b = self.paths()
        result = analyzer.analyze(a, b)
        self.assertFalse(result["cohorts"][0]["material_cells_passed"])

    def test_control_boundary_is_strictly_both_over_five_percent_and_one_ms(self):
        key = (64, 4, "projection_sort", 8, "typed", 0)
        sql_key = (64, 4, "projection_sort", 8, "sql", 0)
        for sql, typed in [(10_000_000, 11_000_000), (100_000_000, 105_000_000)]:
            with self.subTest(sql=sql, typed=typed):
                for cohort in (self.a, self.b):
                    for sample in range(5):
                        self.set_total(self.record(cohort, "matrix", (*key[:-1], sample)), typed)
                        self.set_total(self.record(cohort, "matrix", (*sql_key[:-1], sample)), sql)
                a, b = self.paths()
                result = analyzer.analyze(a, b)
                self.assertTrue(result["cohorts"][0]["controls_passed"])

    def test_control_rejects_regression_only_when_both_limits_are_exceeded(self):
        key = (64, 4, "projection_sort", 8, "typed", 0)
        for cohort in (self.a, self.b):
            for sample in range(5):
                self.set_total(self.record(cohort, "matrix", (*key[:-1], sample)), 11_000_001)
        a, b = self.paths()
        result = analyzer.analyze(a, b)
        self.assertFalse(result["cohorts"][0]["controls_passed"])

    def test_duplicate_missing_bad_proof_and_identity_mismatch_fail_closed(self):
        self.a["records"].append(copy.deepcopy(self.a["records"][0]))
        a, b = self.paths()
        with self.assertRaises(analyzer.AnalysisError):
            analyzer.analyze(a, b)

        self.a = make_cohort("a")
        self.a["records"].pop()
        a, b = self.paths()
        with self.assertRaises(analyzer.AnalysisError):
            analyzer.analyze(a, b)
        self.a = make_cohort("a")
        self.a["records"][0]["proof"]["complete_schema"] = False
        a, b = self.paths()
        with self.assertRaises(analyzer.AnalysisError):
            analyzer.analyze(a, b)
        self.a = make_cohort("a")
        self.b = make_cohort("b")
        self.b["artifact_identity_sha256"] = "ff" * 32
        a, b = self.paths()
        with self.assertRaises(analyzer.AnalysisError):
            analyzer.analyze(a, b)

    def test_failed_validation_only_and_wrong_protocol_are_not_measurements(self):
        for key, value in [('status', 'failed'), ('validation_only', True),
                           ('protocol_sha256', 'ab' * 32)]:
            with self.subTest(key=key):
                self.a = make_cohort('a')
                self.a[key] = value
                a, b = self.paths()
                with self.assertRaises(analyzer.AnalysisError):
                    analyzer.analyze(a, b)

    def test_material_cells_must_match_between_cohorts(self):
        for cohort, selected_rows in [(self.a, 0), (self.b, 64)]:
            for record in cohort['records']:
                if record['phase'] == 'matrix' and record['role'] == 'typed' and record['calls'] == 1:
                    self.set_total(record, 8_000_000 if record['rows'] == selected_rows else 9_500_000)
        result = analyzer.analyze(*self.paths())
        self.assertTrue(all(value['material_cells_passed'] for value in result['cohorts']))
        self.assertFalse(result['shared_material_cells_passed'])
        self.assertFalse(result['passed'])


if __name__ == "__main__":
    unittest.main()
