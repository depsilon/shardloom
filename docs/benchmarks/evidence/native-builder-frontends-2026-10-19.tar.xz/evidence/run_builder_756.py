"""Matched real native SQL/typed workflows under builder-existing-frontends-755-v1."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
PROTOCOL = OUT / 'builder-protocol-755.json'
PROTOCOL_HASH = 'f0a6bb4250d0f4039403d5270b9c4a41c95b027de59f757a8068f3d4db6dd02e'
GRANT = 64 << 20
FAMILIES = ('computed_filter_project', 'group_aggregate', 'left_join',
            'stacked_limit', 'union_distinct', 'projection_sort')
COSTS = ('source_setup', 'frontend', 'prepare', 'execute', 'consume', 'release')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=True, sort_keys=True,
                                    separators=(',', ':')).encode()).hexdigest()


def dtype(kind, nullable=False):
    return {'Utf8': nullable} if kind == 'utf8' else {'Primitive': [kind, nullable]}


def schema(fields):
    return {'Struct': [{'names': [name for name, _ in fields],
                        'dtypes': [value for _, value in fields]}, False]}


def fixture(rows, width):
    fields = [('id', dtype('i64')), ('grp', dtype('i64', True)),
              ('value', dtype('i64', True)), ('text', dtype('utf8', True))]
    fields += [(f'extra_{index:02}', dtype('i64', True)) for index in range(4, width)]
    labels = ['plain', "single'quote", 'double"quote', 'caf\u00e9\u96ea', 'nul\x00value', '']
    values = []
    for row in range(rows):
        value = {'id': row, 'grp': None if row % 11 == 0 else row % 7,
                 'value': None if row % 13 == 0 else row % 37 - 19,
                 'text': None if row % 17 == 0 else labels[row % len(labels)] + str(row % 9)}
        value.update({f'extra_{index:02}': None if row % (index + 7) == 0 else
                      row % (index + 11) - index for index in range(4, width)})
        values.append(value)
    right = [{'grp': key, 'label': f'lookup:{key}'} for key in range(5)]
    right.append({'grp': None, 'label': 'never-joined'})
    right_fields = [('grp', dtype('i64', True)), ('label', dtype('utf8'))]
    return values, fields, right, right_fields


def null_last(value):
    return value is None, value if value is not None else 0


def oracle(values, fields, right, family, parameter):
    selected = [row for row in values if row['id'] >= parameter]
    if family == 'computed_filter_project':
        names = [name for name, _ in fields]
        output = []
        for row in selected:
            if row['value'] is None or row['value'] >= 0:
                output.append({('adjusted' if name == 'value' else name):
                               (None if row[name] is None else row[name] + 7)
                               if name == 'value' else row[name] for name in names})
        return output, [(('adjusted' if name == 'value' else name), kind) for name, kind in fields]
    if family == 'group_aggregate':
        groups = {}
        for row in selected:
            groups.setdefault(row['grp'], []).append(row['value'])
        result = []
        for key in sorted(groups, key=null_last):
            nonnull = [value for value in groups[key] if value is not None]
            result.append({'grp': key, 'total': float(sum(nonnull)) if nonnull else None,
                           'n': len(groups[key]), 'present': len(nonnull),
                           'smallest': min(nonnull) if nonnull else None})
        # Both native frontends use the established nullable f64 SUM contract.
        return result, [('grp', dtype('i64', True)), ('total', dtype('f64', True)),
                        ('n', dtype('u64')), ('present', dtype('u64')),
                        ('smallest', dtype('i64', True))]
    if family == 'left_join':
        lookup = {row['grp']: row['label'] for row in right if row['grp'] is not None}
        return [dict(row, label=lookup.get(row['grp'])) for row in selected], fields + [('label', dtype('utf8', True))]
    if family == 'stacked_limit':
        return selected[2:25][3:12], fields
    if family == 'union_distinct':
        tuples = {(row['grp'], row['value'], row['text']) for row in selected
                  if row['id'] % 2 == 0 or row['id'] % 3 == 0}
        ordered = sorted(tuples, key=lambda row: tuple(null_last(value) for value in row))
        return [dict(zip(('grp', 'value', 'text'), row)) for row in ordered], fields[1:4]
    if family == 'projection_sort':
        return sorted(selected, key=lambda row: (row['value'] is None,
                      -row['value'] if row['value'] is not None else 0, row['id'])), fields
    raise AssertionError(family)


def sql_statement(fields, family, parameter):
    names = [name for name, _ in fields]
    base = f"SELECT * FROM 'memory://left' WHERE id >= {parameter}"
    if family == 'computed_filter_project':
        columns = ', '.join('value + 7 AS adjusted' if name == 'value' else name for name in names)
        return f'SELECT {columns} FROM ({base}) AS s WHERE value >= 0 OR value IS NULL ORDER BY id'
    if family == 'group_aggregate':
        return (f'SELECT grp, SUM(value) AS total, COUNT(*) AS n, COUNT(value) AS present, '
                f'MIN(value) AS smallest FROM ({base}) AS s GROUP BY grp ORDER BY grp NULLS LAST')
    if family == 'left_join':
        columns = ', '.join(f'l.{name} AS {name}' for name in names)
        return (f"SELECT {columns}, r.label AS label FROM ({base}) AS l LEFT JOIN 'memory://right' AS r "
                'ON l.grp = r.grp ORDER BY id')
    if family == 'stacked_limit':
        # The native SQL surface accepts OFFSET at the outer query. The same
        # two-limit plan is constructed in both frontends; [2:25][3:12] is
        # exactly [:25][5:14], including empty and short inputs.
        return f'SELECT * FROM ({base} ORDER BY id LIMIT 25) AS s ORDER BY id LIMIT 9 OFFSET 5'
    if family == 'union_distinct':
        return (f'SELECT grp, value, text FROM ({base}) AS l WHERE id % 2 = 0 UNION '
                f'SELECT grp, value, text FROM ({base}) AS r WHERE id % 3 = 0 '
                'ORDER BY grp NULLS LAST, value NULLS LAST, text NULLS LAST')
    if family == 'projection_sort':
        return f'SELECT {", ".join(names)} FROM ({base}) AS s ORDER BY value DESC NULLS LAST, id'
    raise AssertionError(family)


def typed_relation(native, fields, family, parameter):
    expr, relation = native.Expression, native.Relation
    col, lit = expr.column, expr.literal
    base = relation.scan('memory://left').filter(col('id') >= lit(parameter))
    names = [name for name, _ in fields]
    if family == 'computed_filter_project':
        return base.filter((col('value') >= lit(0)) | col('value').is_null()).project([
            ('adjusted', col(name) + lit(7)) if name == 'value' else (name, col(name))
            for name in names]).sort([('id', False, None)])
    if family == 'group_aggregate':
        return base.aggregate(['grp'], [('sum', 'value', 'total'), ('count', None, 'n'),
                    ('count', 'value', 'present'), ('min', 'value', 'smallest')]).sort([('grp', False, 'last')])
    if family == 'left_join':
        return base.join(relation.scan('memory://right'), [('grp', 'grp')],
                         [('left', name, name) for name in names] + [('right', 'label', 'label')],
                         kind='left').sort([('id', False, None)])
    if family == 'stacked_limit':
        return base.sort([('id', False, None)]).limit(25).sort([('id', False, None)]).limit(9, offset=5)
    if family == 'union_distinct':
        projected = [(name, col(name)) for name in ('grp', 'value', 'text')]
        left = base.filter((col('id') % lit(2)) == lit(0)).project(projected)
        right = base.filter((col('id') % lit(3)) == lit(0)).project(projected)
        return left.set_operation(right, kind='union_distinct').sort([
            (name, False, 'last') for name in ('grp', 'value', 'text')])
    if family == 'projection_sort':
        return base.project([(name, col(name)) for name in names]).sort([
            ('value', True, 'last'), ('id', False, None)])
    raise AssertionError(family)


def check_result(result, rows, observation, expected, fields, reused=True):
    assert digest(rows) == digest(expected), ('complete values or types differ', rows[:3], expected[:3])
    assert all(list(row) == [name for name, _ in fields] for row in rows)
    assert result.row_count == len(expected)
    actual_schema = json.loads(result.schema_json)
    assert actual_schema == schema(fields), ('schema mismatch', actual_schema, schema(fields))
    report = result.report
    for name in ('fallback_attempted', 'external_engine_invoked'):
        assert report[name] == 'false', (name, report.get(name))
    assert report['resident_relational_declaration_reused'] == str(reused).lower()
    assert report['runtime_execution'] == 'true'
    assert observation['complete'] is True and observation['python_rows_constructed'] is True
    assert observation['output_rows'] == len(expected)
    return {'rows': len(rows), 'values_sha256': digest(rows), 'schema_sha256': digest(actual_schema),
            'declaration_reused': reused, 'fallback_attempted': False, 'external_engine_invoked': False}


def verify_source(native, session, reference, source, values, fields):
    assert source.row_count == len(values) and json.loads(source.schema_json) == schema(fields)
    plan = session.plan(native.Relation.scan(reference), sources=[(reference, source)])
    result = plan.collect()
    rows, observation = result.row_export()
    witness = check_result(result, rows, observation, values, fields, reused=False)
    del rows, observation, result
    plan.release_prepared()
    del plan
    return witness


def workflow(native, phase, rows, width, family, calls, role, sample):
    values, fields, right, right_fields = fixture(rows, width)
    parameters = list(range(calls)) if phase == 'churn' else [0]
    expected = {p: oracle(values, fields, right, family, p) for p in parameters}
    declarations = [(name, json.dumps(kind, separators=(',', ':'))) for name, kind in fields]
    right_declarations = [(name, json.dumps(kind, separators=(',', ':'))) for name, kind in right_fields]
    costs = {name: 0 for name in COSTS}
    started = time.perf_counter_ns()
    resources = native.ExecutionResources(GRANT, 1)
    session = native.Session(resources)
    left = session.from_rows(values, fields=declarations)
    bindings = [('memory://left', left)]
    right_source = None
    if family == 'left_join':
        right_source = session.from_rows(right, fields=right_declarations)
        bindings.append(('memory://right', right_source))
    costs['source_setup'] += time.perf_counter_ns() - started
    witnesses = []
    before = session.snapshot()
    completed_before = before['completed_executions']
    for parameter in parameters:
        started = time.perf_counter_ns()
        declaration = (sql_statement(fields, family, parameter) if role == 'sql'
                       else typed_relation(native, fields, family, parameter))
        plan = (session.sql(declaration, sources=bindings) if role == 'sql'
                else session.plan(declaration, sources=bindings))
        costs['frontend'] += time.perf_counter_ns() - started
        started = time.perf_counter_ns()
        plan.prepare()
        costs['prepare'] += time.perf_counter_ns() - started
        for _ in range(1 if phase == 'churn' else calls):
            started = time.perf_counter_ns()
            result = plan.collect()
            costs['execute'] += time.perf_counter_ns() - started
            started = time.perf_counter_ns()
            output, observation = result.row_export()
            costs['consume'] += time.perf_counter_ns() - started
            wanted, output_fields = expected[parameter]
            witnesses.append(check_result(result, output, observation, wanted, output_fields))
            started = time.perf_counter_ns()
            del output, observation, result
            costs['release'] += time.perf_counter_ns() - started
        started = time.perf_counter_ns()
        plan.release_prepared()
        del plan, declaration
        costs['release'] += time.perf_counter_ns() - started
    after = session.snapshot()
    assert after['completed_executions'] - completed_before == calls
    assert after['prepared_source_opens'] == before['prepared_source_opens'] == 0
    # Full input verification is a separate native validation operation after
    # timed calls; it cannot warm those calls or leave a preparation owner.
    input_witnesses = [verify_source(native, session, 'memory://left', left, values, fields)]
    if right_source is not None:
        input_witnesses.append(verify_source(native, session, 'memory://right', right_source, right, right_fields))
    started = time.perf_counter_ns()
    del bindings, left, right_source
    costs['release'] += time.perf_counter_ns() - started
    final = session.snapshot()
    assert final['reserved_bytes'] == 0, final
    assert final['memory_limit_bytes'] == GRANT and final['admitted_max_parallelism'] == 1
    assert final['peak_reserved_bytes'] <= GRANT and final['denied_reservations'] == 0
    started = time.perf_counter_ns()
    session.close()
    del session, resources
    costs['release'] += time.perf_counter_ns() - started
    costs['complete_workflow'] = sum(costs.values())
    return dict(phase=phase, rows=rows, width=width, family=family, calls=calls, role=role, sample=sample,
                costs_nanos=costs, output_witnesses=witnesses, input_witnesses=input_witnesses,
                source_fixture_sha256=digest([values, fields, right if family == 'left_join' else []]),
                proof=dict(complete_values=True, complete_schema=True, source_values=True,
                           no_fallback=True, all_operations_completed=True, final_reserved_bytes=0,
                           peak_reserved_bytes=final['peak_reserved_bytes'], memory_limit_bytes=GRANT,
                           cpu_lanes=1, expected_operations=calls, observed_operations=len(witnesses)))


def verify_identity(identity_path):
    identity = json.loads(identity_path.read_text())
    assert sha(PROTOCOL) == PROTOCOL_HASH
    for item in identity['sources'] + identity['python_sources']:
        assert sha(ROOT / item['path']) == item['sha256'], item['path']
    library = Path(identity['artifact']['path'])
    assert sha(library) == identity['artifact']['sha256']
    return library


def load_native(identity_path):
    library = verify_identity(identity_path)
    sys.path.insert(0, str(ROOT / 'python/src'))
    import shardloom
    spec = importlib.util.spec_from_file_location('shardloom._native', library)
    assert spec is not None and spec.loader is not None
    native = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = native
    spec.loader.exec_module(native)
    return native


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--artifact-identity', required=True, type=Path)
    parser.add_argument('--cohort', required=True, choices=('a', 'b'))
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--validate-only', action='store_true')
    args = parser.parse_args()
    assert not args.output.exists()
    native = load_native(args.artifact_identity)
    output = dict(schema_version='shardloom.conditional_builder_samples.v1', cohort=args.cohort,
                  protocol_sha256=sha(PROTOCOL), artifact_identity_sha256=sha(args.artifact_identity),
                  harness_sha256=sha(__file__), analyzer_sha256=sha(OUT / 'analyze_builder_756.py'),
                  validation_only=args.validate_only, records=[])
    cases = list(itertools.product((0, 64, 4096), (4, 12), FAMILIES, (1, 8)))
    churn = [(64, width, family, 8) for width, family in itertools.product((4, 12), FAMILIES)]
    if args.cohort == 'b':
        cases.reverse()
        churn.reverse()
    try:
        for role in (('sql', 'typed') if args.cohort == 'a' else ('typed', 'sql')):
            output['records'].append(workflow(native, 'warmup', 64, 4, FAMILIES[0], 1, role, -1))
        for phase, selected in (('matrix', cases), ('churn', churn)):
            for case_index, (rows, width, family, calls) in enumerate(selected):
                for sample in range(1 if args.validate_only else 5):
                    roles = ['sql', 'typed']
                    if (case_index + sample + (args.cohort == 'b')) % 2:
                        roles.reverse()
                    for role in roles:
                        output['records'].append(workflow(native, phase, rows, width, family, calls, role, sample))
                print(json.dumps({'phase': phase, 'case': case_index + 1, 'status': 'passed'}), flush=True)
        verify_identity(args.artifact_identity)
        output['status'] = 'passed'
    except BaseException as error:
        output.update(status='failed', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        args.output.write_text(json.dumps(output, ensure_ascii=True, indent=2) + '\n')


if __name__ == '__main__':
    main()
