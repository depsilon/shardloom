"""Verify final support artifacts and bind their acceptance to the engine index."""
import json
from pathlib import Path
import subprocess
import time

import join_support_common as c


def main():
    _, _, annotation = c.checked_runtime()
    evidence = c.ROOT / 'docs/benchmarks/evidence'
    receipt_path = evidence / 'native-join-support-2026-10-08.json'
    receipt = c.read(receipt_path)
    assert receipt['status'] == 'passed_local_documentation_acceptance'
    assert receipt['runtime_provenance'] == annotation
    assert 'final_selected_checks' not in receipt
    for name, expected in receipt['source_files'].items():
        path = c.ROOT / name
        assert path.stat().st_size == expected['bytes'] and c.sha(path) == expected['sha256'], name
    archive = c.ROOT / receipt['archive']['path']
    assert c.sha(archive) == receipt['archive']['sha256']
    guard_path = c.OUT / 'join-docarchive-1.json'
    guard = c.read(guard_path)
    assert guard['status'] == 'passed' and guard['returncode'] == 0
    assert guard['process_group_drained'] and guard['direct_child_reaped']
    assert guard['log_sha256'] == c.sha(guard_path.with_suffix('.log'))
    out = c.OUT / 'join-support-final-1'
    out.mkdir(exist_ok=False)
    checks = []
    for name, command in (
        ('user-surface-index', [c.PYTHON, '-B', 'scripts/check_user_surface_reference.py']),
        ('use-case-backlinks', [c.PYTHON, '-B', 'scripts/check_use_case_backlinks.py']),
        ('public-status', [c.PYTHON, '-B', 'scripts/check_public_status_docs.py',
                           '--output', str(out / 'public-status-report.json')]),
        ('website-readiness', [c.PYTHON, '-B', 'scripts/check_website_readiness.py',
                               '--output', str(out / 'website-readiness-report.json')]),
        ('diff-whitespace', ['git', 'diff', '--check']),
    ):
        assert c.checked_runtime()[2] == annotation
        path = out / f'{name}.log'
        start = time.monotonic()
        with path.open('xb') as stream:
            result = subprocess.run(command, cwd=c.ROOT, stdout=stream,
                                    stderr=subprocess.STDOUT, timeout=60, check=False)
        row = {'name': name, 'command': command, 'returncode': result.returncode,
               'seconds': time.monotonic() - start, 'log_sha256': c.sha(path),
               'log_text': path.read_text()}
        checks.append(row)
        assert c.checked_runtime()[2] == annotation
        assert result.returncode == 0, row
    for name, expected in receipt['source_files'].items():
        assert c.sha(c.ROOT / name) == expected['sha256'], name
    receipt.update(final_selected_checks=checks, documentation_archive_guard=guard,
                   finalization_driver={'sha256': c.sha(__file__), 'text': Path(__file__).read_text()})
    receipt_path.write_text(c.portable(receipt))
    index_path = evidence / 'native-join-pressure-2026-10-08.json'
    index = c.read(index_path)
    assert index['documentation_updates_complete'] is False
    assert index['runtime_commit'] == annotation['accepted_runtime_commit']
    assert c.sha(c.ROOT / index['acceptance']['packet']) == index['acceptance']['packet_sha256']
    index.update(documentation_updates_complete=True,
                 documentation_acceptance=str(receipt_path.relative_to(c.ROOT)),
                 documentation_acceptance_sha256=c.sha(receipt_path),
                 support_alignment_runtime_provenance=annotation)
    index_path.write_text(c.portable(index))
    result = {'status': 'passed', 'selected_checks': len(checks),
              'documentation_acceptance_sha256': c.sha(receipt_path),
              'index_sha256': c.sha(index_path), 'runtime_provenance': annotation}
    c.write(out / 'summary.json', result)
    print(json.dumps({'status': 'passed', 'selected_checks': len(checks),
                      'assets_byte_identical': annotation['assets_byte_identical'],
                      'all_accepted_source_assets_byte_identical': True}), flush=True)


if __name__ == '__main__':
    main()

