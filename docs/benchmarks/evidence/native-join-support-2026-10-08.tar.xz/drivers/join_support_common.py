"""Keep all accepted executable sources fixed while aligning support artifacts."""
import json

import join_acceptance_common as c

ROOT, OUT, PYTHON = c.ROOT, c.OUT, c.PYTHON
read, sha, write = c.read, c.sha, c.write


def checked_runtime():
    snapshot = read(OUT / 'join-source-1.json')
    build = read(OUT / 'join-acceptance-build-1.json')
    actual = c.source_hashes()
    assert actual == snapshot['source_hashes'] == build['source_hashes']
    assert build['source_identity_sha256'] == snapshot['source_identity_sha256']
    assert sha(build['binary']) == build['binary_sha256']
    annotation = {'accepted_runtime_commit': snapshot['head'],
        'accepted_source_identity_sha256': snapshot['source_identity_sha256'],
        'assets_byte_identical': len(actual), 'asset_count_unchanged': len(actual),
        'executable_behavior_changed': False, 'binary_sha256': build['binary_sha256']}
    return snapshot, build, annotation


def portable(value):
    text = json.dumps(value, indent=2, allow_nan=False)
    for original, replacement in ((str(ROOT), '<repo>'), (str(OUT), '<join-uat>'), (str(ROOT.home()), '<home>')):
        text = text.replace(original, replacement)
    return text + '\n'
