"""Check new declarations and reopen the development matrix's complete results."""
import hashlib
import json
from pathlib import Path

from native_workflow_protocol import strict_json, report_fields
from verify_subquery_public import verify

OUT = Path(__file__).resolve().parent


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


root = OUT / 'public-preflight-diagnostic-fixed-742'
summary = strict_json((root / 'summary.json').read_text())
declaration = strict_json((OUT / 'subquery-public-case-declaration.json').read_text())
assert summary['status'] == 'passed' and len(summary['cases']) == 445
pressure = declaration['replacement_pressure_case_names'] + [
    'subquery-large-bounded-inner-skipped-False', 'subquery-large-bounded-inner-skipped-True',
    'subquery-shared-replay-spilled-False', 'subquery-shared-replay-spilled-True',
    'subquery-prefill-quota-denial']
assert set(pressure).issubset(declaration['expected_public_case_names'])
assert sorted(case['name'] for case in summary['cases']) == sorted(
    declaration['subquery-membership'] + pressure)
assert all(case['status'] == 'passed' for case in summary['cases'])
result = verify(root, summary, identity, strict_json, report_fields)
with (OUT / 'preflight-values-verified-742.json').open('x') as stream:
    json.dump(result, stream, indent=2)
print(json.dumps(dict(status='passed', public_cases=445,
    complete_value_archives=len(result['subquery_complete_value_archives']),
    complete_rows=result['subquery_rows_independently_reopened'])))
