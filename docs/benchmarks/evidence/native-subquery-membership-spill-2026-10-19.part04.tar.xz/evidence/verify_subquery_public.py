"""Reopen complete predicate values, state counters and failed publications."""
import gzip
import json

from native_streaming_subquery_cases import fixture, oracle as static_oracle
from native_streaming_dynamic_subquery_cases import KINDS as SMALL, oracle as deferred_oracle

KINDS = ('in', 'row-in', 'exists', 'any', 'all', 'hot-in')
FORMATS = ('vortex', 'parquet', 'arrow_ipc', 'avro', 'orc', 'json', 'jsonl', 'csv')
ANSWERS = {
    'in': [True, None, True, None, True],
    'row-in': [True, None, None, None, None],
    'exists': [True, False, True, False, True],
    'any': [True, None, False, None, None],
    'all': [False, None, True, None, None],
    'hot-in': [True, False, False, False, False],
}


def text(index):
    return f'{index:08d}' + 'p' * 2048


def wide(kind, negated=False):
    rows = [dict(n=n, s=s) for n, s in (
        (1, text(0)), (4, text(1025)), (None, text(1)), (2, None), (0, text(512)))]
    return [dict(row, answer=not value if negated and value is not None else value)
            for row, value in zip(rows, ANSWERS[kind], strict=True)]


def verify(root, summary, identity, strict_json, report_fields):
    cases = {case['name']: case for case in summary['cases']}
    assert len(cases) == len(summary['cases'])
    values, envelopes, failures = [], [], []

    def saved(name):
        path = root / 'logs' / (name + '.json.gz')
        return path, strict_json(gzip.decompress(path.read_bytes()).decode())

    def complete(name, expected):
        path, record = saved(name + '-values')
        assert record['actual'] == record['expected'] == expected, name
        values.append({'name': name, 'rows': len(expected), 'values': identity(path)})

    def completion(name, *, stages=1, runs=False, population=None, probes=None, replay=0, spilled=False, grant=8 << 20):
        path, envelope = saved(name + '-envelope')
        assert envelope['status'] == 'success' and not envelope['fallback']['attempted'], name
        assert not envelope['fallback']['allowed']
        fields = report_fields(envelope)
        assert fields['native_input_end_observed'] == 'true', name
        assert fields['native_input_output_ownership_detached'] == 'true', name
        assert fields['resident_completed_executions'] == '1', name
        assert int(fields['resident_peak_reserved_buffer_bytes']) <= grant, name
        assert fields['relational_spill_owned_cleanup_completed'] == 'true', name
        assert int(fields['relational_spill_peak_disk_bytes']) <= 128 << 20
        assert int(fields['relational_spillable_subquery_stages']) == stages, name
        assert (int(fields['relational_spilled_subquery_stages']) > 0) == spilled, name
        if runs is not None:
            assert (int(fields['relational_spill_runs_written']) > 0) == runs, name
        if population is not None:
            assert int(fields['native_input_replay_sources']) == replay, name
            assert int(fields['native_input_replay_spilled_sources']) == replay, name
            assert int(fields['relational_spillable_subquery_input_rows']) == population, name
            assert int(fields['relational_spillable_subquery_indexed_rows']) == population, name
        if probes is not None:
            assert int(fields['relational_spillable_subquery_probe_rows']) == probes, name
        if runs:
            assert int(fields['relational_spill_runs_written']) > 2, name
            assert int(fields['relational_spill_merge_passes']) > 0, name
            assert int(fields['relational_spillable_subquery_lookup_blocks']) > 0, name
        envelopes.append(identity(path))
        return fields

    for mode, kinds, oracle in (
        ('small', (*SMALL, 'parameterized-in', 'parameterized-exists', 'correlated-exists'), static_oracle),
        ('deferred', SMALL, deferred_oracle),
    ):
        for kind in kinds:
            for shape in ('mixed', 'empty-outer', 'empty-inner', 'all-null'):
                left, right = fixture(shape)
                expected = oracle(kind, left, right)
                for surface in ('dataframe', 'sql'):
                    name = f'subquery-membership-{mode}-{kind}-{shape}-{surface}'
                    assert cases[name]['complete_rows'] == len(expected), name
                    complete(name, expected)
                    stages = len(left) if mode == 'deferred' or kind.startswith('parameterized-') or kind == 'correlated-exists' else 1
                    fields = completion(name, stages=stages, runs=None if mode == 'deferred' else False,
                                        grant=(32 if mode == 'deferred' else 8) << 20)
                    if mode == 'deferred':
                        assert int(fields.get('relational_dynamic_schema_stages', '0')) == stages

    _, declared = saved('subquery-membership-wide-predeclared')
    assert (declared['rows'], declared['width'], declared['grant']) == (1025, 2048, 8 << 20)
    assert declared['expected'] == {kind: wide(kind) for kind in KINDS}
    for kind in KINDS:
        population = {'in': 1025, 'row-in': 1025, 'exists': 4, 'any': 757, 'all': 757, 'hot-in': 946}[kind]
        parameterized = kind not in ('in', 'row-in')
        counters = dict(runs=True, population=population, probes=5,
                        stages=5 if parameterized else 1, replay=int(parameterized), spilled=kind != 'exists')
        for surface in ('dataframe', 'sql'):
            for terminal in ('collect', 'batches'):
                for negated in (False, True):
                    name = f'subquery-membership-wide-{kind}-{surface}-{terminal}-negated-{negated}'
                    complete(name, wide(kind, negated))
                    completion(name, **counters)
        for destination in (*FORMATS, 'fanout'):
            name = f'subquery-membership-{kind}-write-{destination}'
            fields = completion(name, **counters)
            formats = FORMATS if destination == 'fanout' else (destination,)
            if destination == 'fanout':
                for suffix, count in [('execution_count', 1), ('target_count', 8), ('replay_count', 8)]:
                    assert int(fields['native_vortex_result_export_' + suffix]) == count
            artifacts = cases[name]['artifacts']
            assert len(artifacts) == len(formats)
            for artifact in artifacts:
                observed = identity(root / artifact['path'])
                assert (observed['bytes'], observed['sha256']) == (artifact['bytes'], artifact['sha256'])
            for extension in formats:
                expected = wide(kind)
                if extension == 'csv':
                    expected = [{key: '' if value is None else str(value).lower() if isinstance(value, bool)
                                 else str(value) for key, value in row.items()} for row in expected]
                complete(name + '-' + extension, expected)

        for failure in ('producer', 'corrupt', 'quota', 'existing'):
            name = f'subquery-membership-{kind}-{failure}'
            case = cases[name]
            assert case['failure'] == failure and case['fresh_complete_rows'] == 5
            trace = case['trace']
            assert trace['opened'] == int(failure != 'existing')
            assert trace['closed'] == (failure != 'existing')
            assert trace['fault'] == (failure in ('producer', 'corrupt'))
            if failure in ('producer', 'corrupt'):
                assert trace['saw_run']
            if failure != 'producer':
                _, error = saved(name + '-envelope')
                assert error['status'] == 'error' and not error['fallback']['attempted']
                message = json.dumps(error).lower()
                assert ('quota' in message if failure == 'quota' else
                        'already exists and overwrite is disabled' in message if failure == 'existing' else
                        'byte length changed' in message or 'prepared source changed' in message)
            for extension in ('vortex', 'jsonl'):
                target = root / 'outputs' / (name + '.' + extension)
                if failure == 'existing':
                    assert target.read_bytes() == b'preserve existing predicate target'
                else:
                    assert not target.exists()
            complete(name + '-restart', wide(kind))
            completion(name + '-restart', **counters)
            failures.append(name)

    pressure = 'subquery-membership-original-pressure-spill-'
    denied = cases[pressure + 'False']
    assert denied['resident_state_denied'] and denied['fresh_completed']
    assert denied['grant'] == 8 << 20 and denied['traces'][0]['opened'] == 0
    assert 0 < denied['traces'][1]['rows'] < 8193
    _, error = saved(pressure + 'False-envelope')
    assert error['status'] == 'error' and 'reservation denied' in json.dumps(error)
    expected = [dict(n=0, s='00000000' + 'p' * 4096, answer=True)]
    complete(pressure + 'True-reopened', expected)
    completion(pressure + 'True', runs=True, population=8193, probes=1, spilled=True)
    for state in ('False', 'True'):
        complete(pressure + state + '-fresh', [dict(n=1, s='small', answer=True)])
    workspace = root / 'outputs/subquery-membership-spill'
    assert [path.name for path in workspace.iterdir()] == ['foreign']
    assert (workspace / 'foreign').read_bytes() == b'preserve'
    assert len(values) == 483, len(values)
    assert len(failures) == 24
    assert len([name for name in cases if name.startswith('subquery-membership-')]) == 440
    return {'subquery_membership_public_cases': 438, 'subquery_original_pressure_cases': 2,
            'subquery_complete_value_archives': values, 'subquery_completion_envelopes': envelopes,
            'subquery_publication_failure_cases': failures,
            'subquery_existing_destination_denials': 6, 'subquery_incomplete_execution_failures': 18,
            'subquery_rows_independently_reopened': sum(value['rows'] for value in values)}
