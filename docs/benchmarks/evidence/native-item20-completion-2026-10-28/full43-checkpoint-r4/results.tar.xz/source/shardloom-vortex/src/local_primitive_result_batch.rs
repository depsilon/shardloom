//! Construct final scalar columns in allocator-owned Vortex buffers.
//!
//! Values come from completed operator state, not a source replay or a JSON
//! table. The caller bounds the batch and retains its schema/array metadata.
//! Payload and validity credits live inside the buffers, including cloned slices.

use std::borrow::Cow;

use shardloom_core::{Result, ShardLoomError, StatValue};
use vortex::{
    array::{
        ArrayRef, IntoArray as _, VortexSessionExecute as _,
        arrays::{DecimalArray, ExtensionArray, PrimitiveArray, StructArray, VarBinArray},
        dtype::{DType, DecimalDType, FieldNames, PType},
        memory::{HostAllocatorRef, HostMemorySessionExt as _, WritableHostBuffer},
        validity::Validity,
    },
    buffer::{Alignment, BitBuffer, Buffer, ByteBuffer},
};

use super::vortex_error;
use crate::owned_buffers::{bool_array_with_retained_buffer, retain_empty_array_credit};

#[path = "local_primitive_variant_result.rs"]
mod variant;

#[cfg(unix)]
#[path = "local_primitive_result_numeric.rs"]
mod numeric;

#[cfg(unix)]
#[path = "local_primitive_result_variable.rs"]
mod variable;
#[cfg(unix)]
pub(super) use variable::VariableValues;

#[cfg(unix)]
#[path = "local_primitive_result_expression_variable.rs"]
mod expression_variable;

#[cfg(all(test, unix))]
#[path = "local_primitive_result_batch_prefix_tests.rs"]
mod prefix_tests;

/// Borrow text from a completed key/state whenever it already exists there.
#[derive(Clone)]
pub(super) enum Value<'a> {
    Null,
    Bool(bool),
    Int(i64),
    UInt(u64),
    Float(f64),
    Text(Cow<'a, str>),
    SharedText(vortex::buffer::BufferString),
    Binary(Cow<'a, [u8]>),
    SharedBinary(ByteBuffer),
    Decimal(i128, DecimalDType),
}

impl Value<'_> {
    fn as_text(&self) -> Option<&str> {
        match self {
            Self::Text(value) => Some(value.as_ref()),
            Self::SharedText(value) => Some(value.as_str()),
            _ => None,
        }
    }

    fn variable_bytes(&self) -> Option<&[u8]> {
        match self {
            Self::Text(value) => Some(value.as_bytes()),
            Self::SharedText(value) => Some(value.as_str().as_bytes()),
            Self::Binary(value) => Some(value.as_ref()),
            Self::SharedBinary(value) => Some(value.as_ref()),
            _ => None,
        }
    }

    pub(super) fn integer(bits: u64, signed: bool) -> Self {
        if signed {
            Self::Int(i64::from_ne_bytes(bits.to_ne_bytes()))
        } else {
            Self::UInt(bits)
        }
    }

    pub(super) fn into_json(self) -> Result<serde_json::Value> {
        Ok(match self {
            Self::Null => serde_json::Value::Null,
            Self::Bool(value) => value.into(),
            Self::Int(value) => value.into(),
            Self::UInt(value) => value.into(),
            Self::Float(value) => super::json_number_from_f64(value)?,
            Self::Text(value) => value.into_owned().into(),
            Self::SharedText(value) => value.as_str().into(),
            Self::Binary(value) => super::binary_to_hex(&value).into(),
            Self::SharedBinary(value) => super::binary_to_hex(&value).into(),
            Self::Decimal(value, dtype) => format!(
                "decimal128({},{}):{value}",
                dtype.precision(),
                dtype.scale()
            )
            .into(),
        })
    }
}

/// Read only a selected native value at an explicit result boundary. Text keeps
/// its native buffer owner; this does not build a decoded row table.
#[cfg(unix)]
pub(super) fn scalar_value(
    array: &ArrayRef,
    row: usize,
    context: &mut vortex::array::ExecutionCtx,
) -> Result<Value<'static>> {
    use vortex::array::scalar::ScalarValue;
    let scalar = scalar(array, row, context)?;
    Ok(match scalar.value() {
        None => Value::Null,
        Some(ScalarValue::Bool(value)) => Value::Bool(*value),
        Some(ScalarValue::Primitive(value)) => Value::from(
            super::vortex_pvalue_to_stat_value(*value)
                .ok_or_else(|| failed("unsupported primitive result dtype"))?,
        ),
        Some(ScalarValue::Utf8(value)) => Value::SharedText(value.clone()),
        Some(ScalarValue::Binary(value)) => Value::SharedBinary(value.clone()),
        Some(ScalarValue::Decimal(value)) => {
            let DType::Decimal(dtype, _) = scalar.dtype() else {
                return Err(failed("decimal scalar lost its declared dtype"));
            };
            if !crate::native_payload_schema::admitted_decimal(*dtype) {
                return Err(failed(
                    "decimal payload exceeds admitted precision or scale",
                ));
            }
            Value::Decimal(
                value
                    .cast::<i128>()
                    .ok_or_else(|| failed("decimal payload exceeds signed 128-bit storage"))?,
                *dtype,
            )
        }
        _ => {
            return Err(failed(
                "native scalar result requires an admitted flat dtype",
            ));
        }
    })
}

/// Keep invalid decimal data on the Result path: the provider's convenience
/// scalar constructor panics when a selected value exceeds its precision.
#[cfg(unix)]
pub(super) fn scalar(
    array: &ArrayRef,
    row: usize,
    context: &mut vortex::array::ExecutionCtx,
) -> Result<vortex::array::scalar::Scalar> {
    use vortex::array::{
        arrays::{VarBinView, decimal::DecimalArrayExt as _, varbinview::VarBinViewArrayExt as _},
        scalar::{DecimalValue, Scalar, ScalarValue},
    };
    if row >= array.len() {
        return Err(failed("selected scalar exceeds its source domain"));
    }
    let array = scalar_storage(array, context)?;
    if matches!(array.dtype(), DType::Utf8(_))
        && let Some(text) = array.as_opt::<VarBinView>()
    {
        // Provider scalar extraction assumes text was validated at construction.
        // Serialized or selected views can instead carry an unvalidated domain.
        // Check observed bytes before constructing a BufferString, including when
        // the output prefix discards this row and has no final text to validate.
        let value = if array
            .validity()
            .map_err(vortex_error)?
            .execute_is_valid(row, context)
            .map_err(vortex_error)?
        {
            Some(ScalarValue::Utf8(
                text.utf8_buffer_at(row).map_err(vortex_error)?,
            ))
        } else {
            None
        };
        return Scalar::try_new(array.dtype().clone(), value).map_err(vortex_error);
    }
    if let DType::Decimal(dtype, _) = array.dtype() {
        if !crate::native_payload_schema::admitted_decimal(*dtype) {
            return Err(failed(
                "decimal payload exceeds admitted precision or scale",
            ));
        }
        let decimal = array
            .clone()
            .execute::<DecimalArray>(context)
            .map_err(vortex_error)?;
        let value = if decimal
            .validity()
            .map_err(vortex_error)?
            .execute_is_valid(row, context)
            .map_err(vortex_error)?
        {
            Some(vortex::array::match_each_decimal_value_type!(
                decimal.values_type(),
                |D| { DecimalValue::from(decimal.buffer::<D>()[row]).into() }
            ))
        } else {
            None
        };
        return Scalar::try_new(array.dtype().clone(), value).map_err(vortex_error);
    }
    array.execute_scalar(row, context).map_err(vortex_error)
}

/// Read the native integer storage of an admitted temporal payload. Constructing
/// provider timestamp scalars can panic outside its calendar formatting range;
/// payload transport and terminal integer encoding do not need that conversion.
#[cfg(unix)]
pub(super) fn scalar_storage(
    array: &ArrayRef,
    context: &mut vortex::array::ExecutionCtx,
) -> Result<ArrayRef> {
    use vortex::array::arrays::extension::ExtensionArrayExt as _;
    if matches!(array.dtype(), DType::Extension(_)) {
        if crate::native_payload_schema::temporal_storage(array.dtype()).is_none() {
            return Err(failed(
                "extension payload requires Date32 or timezone-free TimestampMicros",
            ));
        }
        return array
            .clone()
            .execute::<ExtensionArray>(context)
            .map(|array| array.storage_array().clone())
            .map_err(vortex_error);
    }
    Ok(array.clone())
}

/// Reports serialize values only at their terminal delivery boundary. Native
/// consumers instead receive arrays and a null values field in the descriptor.
pub(super) struct Rows {
    count: usize,
    pub(super) values: serde_json::Value,
}

pub(super) fn window<T>(values: &[T], offset: usize, count: usize) -> &[T] {
    let start = offset.min(values.len());
    &values[start..values.len().min(start.saturating_add(count))]
}

pub(super) const VISITOR_ROWS: usize = 2048;

impl Rows {
    pub(super) fn streamed(count: usize) -> Self {
        Self {
            count,
            values: serde_json::Value::Null,
        }
    }
    pub(super) const fn len(&self) -> usize {
        self.count
    }

    /// Visit completed, globally selected state without retaining a second full
    /// selection. The caller reserves these bounded references; native buffers
    /// acquire their own leases while each batch is synchronously consumed.
    pub(super) fn from_visitor<'a, T>(
        output: Option<&mut super::completed_result::CompletedRows>,
        columns: &[String],
        visit: impl FnOnce(&mut dyn FnMut(T) -> Result<()>) -> Result<()>,
        mut value: impl FnMut(&T, usize) -> Result<Value<'a>>,
    ) -> Result<Self> {
        match output {
            Some(output) if output.is_streaming() => {
                let mut batch = Vec::with_capacity(VISITOR_ROWS);
                let mut count = 0;
                visit(&mut |row| {
                    batch.push(row);
                    if batch.len() == VISITOR_ROWS {
                        output.push_values(columns, batch.len(), |row, column| {
                            value(&batch[row], column)
                        })?;
                        count = add(count, batch.len())?;
                        batch.clear();
                    }
                    Ok(())
                })?;
                if !batch.is_empty() || count == 0 {
                    output.push_values(columns, batch.len(), |row, column| {
                        value(&batch[row], column)
                    })?;
                    count = add(count, batch.len())?;
                }
                output.finish_stream()?;
                Ok(Self::streamed(count))
            }
            output => {
                let mut selected = Vec::new();
                visit(&mut |row| {
                    selected.push(row);
                    Ok(())
                })?;
                Self::from_fn(output, columns, selected.len(), |row, column| {
                    value(&selected[row], column)
                })
            }
        }
    }

    pub(super) fn from_fn<'a>(
        output: Option<&mut super::completed_result::CompletedRows>,
        columns: &[String],
        count: usize,
        mut value: impl FnMut(usize, usize) -> Result<Value<'a>>,
    ) -> Result<Self> {
        let values = if let Some(output) = output {
            output.finish_values(columns, count, value)?;
            serde_json::Value::Null
        } else {
            let mut rows = Vec::with_capacity(count);
            for row in 0..count {
                let mut values = serde_json::Map::new();
                for (column, name) in columns.iter().enumerate() {
                    values.insert(name.clone(), value(row, column)?.into_json()?);
                }
                rows.push(serde_json::Value::Object(values));
            }
            serde_json::Value::Array(rows)
        };
        Ok(Self { count, values })
    }
}

impl<'a> From<&'a StatValue> for Value<'a> {
    fn from(value: &'a StatValue) -> Self {
        match value {
            StatValue::Null => Self::Null,
            StatValue::Boolean(value) => Self::Bool(*value),
            StatValue::Int64(value) => Self::Int(*value),
            StatValue::UInt64(value) => Self::UInt(*value),
            StatValue::Float64(value) => Self::Float(*value),
            StatValue::Utf8(value) => Self::Text(Cow::Borrowed(value)),
        }
    }
}

impl From<StatValue> for Value<'_> {
    fn from(value: StatValue) -> Self {
        match value {
            StatValue::Null => Self::Null,
            StatValue::Boolean(value) => Self::Bool(value),
            StatValue::Int64(value) => Self::Int(value),
            StatValue::UInt64(value) => Self::UInt(value),
            StatValue::Float64(value) => Self::Float(value),
            StatValue::Utf8(value) => Self::Text(Cow::Owned(value)),
        }
    }
}

fn failed(reason: &str) -> ShardLoomError {
    ShardLoomError::InvalidOperation(format!(
        "native result batch: {reason}; no fallback execution was attempted"
    ))
}

pub(super) fn add(left: usize, right: usize) -> Result<usize> {
    left.checked_add(right)
        .ok_or_else(|| failed("buffer size overflow"))
}

fn multiply(left: usize, right: usize) -> Result<usize> {
    left.checked_mul(right)
        .ok_or_else(|| failed("buffer size overflow"))
}

pub(super) fn width(dtype: &DType) -> Result<usize> {
    match dtype {
        DType::Bool(_) => Ok(0),
        DType::Utf8(_) | DType::Binary(_) => Ok(8),
        DType::Primitive(ptype, _) if *ptype != PType::F16 => Ok(ptype.byte_width()),
        DType::Decimal(dtype, _) if crate::native_payload_schema::admitted_decimal(*dtype) => {
            Ok(16)
        }
        DType::Extension(_) => crate::native_payload_schema::temporal_storage(dtype)
            .map(|ptype| ptype.byte_width())
            .ok_or_else(|| failed("unsupported temporal output dtype")),
        _ => Err(failed("output requires a declared flat scalar dtype")),
    }
}

/// Compute the logical buffer footprint before allocating any payload, including
/// the conservative metadata grant needed by native heterogeneous scalar columns.
/// The repeatable accessor reads completed state only; UTF8 bytes are copied
/// once, during construction. Provider alignment slack is charged by the allocator.
pub(super) fn buffer_bytes<'a>(
    fields: &[(String, DType)],
    rows: usize,
    value: &mut impl FnMut(usize, usize) -> Result<Value<'a>>,
) -> Result<usize> {
    let mut bytes = 0;
    for (column, (_, dtype)) in fields.iter().enumerate() {
        if matches!(dtype, DType::Variant(_)) {
            bytes = add(
                bytes,
                variant::footprint(rows, &mut |row| value(row, column))?,
            )?;
            continue;
        }
        let stride = width(dtype)?;
        bytes = add(
            bytes,
            if matches!(dtype, DType::Bool(_)) {
                rows.div_ceil(8)
            } else {
                multiply(
                    add(
                        rows,
                        usize::from(matches!(dtype, DType::Utf8(_) | DType::Binary(_))),
                    )?,
                    stride,
                )?
            },
        )?;
        if dtype.is_nullable() {
            bytes = add(bytes, rows.div_ceil(8))?;
        }
        if matches!(dtype, DType::Utf8(_) | DType::Binary(_)) {
            for row in 0..rows {
                match value(row, column)? {
                    Value::Text(text) => bytes = add(bytes, text.len())?,
                    Value::SharedText(text) => bytes = add(bytes, text.len())?,
                    Value::Binary(value) => bytes = add(bytes, value.len())?,
                    Value::SharedBinary(value) => bytes = add(bytes, value.len())?,
                    Value::Null if dtype.is_nullable() => {}
                    _ => return Err(failed("UTF8 value differs from the declared dtype")),
                }
            }
        }
    }
    Ok(bytes)
}

/// Build one independently owned native batch. No row or JSON objects are kept.
pub(super) fn build<'a>(
    fields: &[(String, DType)],
    rows: usize,
    max_bytes: usize,
    allocator: &HostAllocatorRef,
    memory: &shardloom_exec::live_memory::LiveMemoryPool,
    mut value: impl FnMut(usize, usize) -> Result<Value<'a>>,
) -> Result<ArrayRef> {
    if buffer_bytes(fields, rows, &mut value)? > max_bytes {
        return Err(failed(
            "complete batch exceeds its native buffer byte bound",
        ));
    }
    let mut arrays = Vec::with_capacity(fields.len());
    for (column, (_, dtype)) in fields.iter().enumerate() {
        arrays.push(if matches!(dtype, DType::Variant(_)) {
            variant::build(dtype, rows, allocator, memory, &mut |row| {
                value(row, column)
            })?
        } else {
            build_column(dtype, rows, allocator, |row| value(row, column))?
        });
    }
    StructArray::try_new(
        fields
            .iter()
            .map(|(name, _)| name.as_str())
            .collect::<FieldNames>(),
        arrays,
        rows,
        Validity::NonNullable,
    )
    .map(vortex::array::IntoArray::into_array)
    .map_err(vortex_error)
}

fn allocate(
    allocator: &HostAllocatorRef,
    bytes: usize,
    alignment: usize,
) -> Result<WritableHostBuffer> {
    let mut buffer = allocator
        .allocate(bytes, Alignment::new(alignment))
        .map_err(vortex_error)?;
    buffer.as_mut_slice().fill(0);
    Ok(buffer)
}

fn set_bit(buffer: &mut WritableHostBuffer, row: usize) {
    buffer.as_mut_slice()[row / 8] |= 1 << (row % 8);
}

fn copy_bytes(buffer: &mut WritableHostBuffer, start: usize, value: &[u8]) -> Result<usize> {
    let next = add(start, value.len())?;
    let destination = buffer
        .as_mut_slice()
        .get_mut(start..next)
        .ok_or_else(|| failed("completed text changed during construction"))?;
    destination.copy_from_slice(value);
    Ok(next)
}

pub(super) fn build_column<'a>(
    dtype: &DType,
    rows: usize,
    allocator: &HostAllocatorRef,
    value: impl FnMut(usize) -> Result<Value<'a>>,
) -> Result<ArrayRef> {
    build_column_prefix_inner::<false>(dtype, rows, rows, allocator, value)
}

/// Bound expression callbacks can construct expensive owned scalars. Evaluate
/// variable values once; completed-state and prefix visitors retain their
/// existing sizing/validation contract.
#[cfg(unix)]
pub(super) fn build_expression_column<'a>(
    dtype: &DType,
    rows: usize,
    allocator: &HostAllocatorRef,
    value: impl FnMut(usize) -> Result<Value<'a>>,
) -> Result<ArrayRef> {
    if matches!(dtype, DType::Utf8(_) | DType::Binary(_)) {
        expression_variable::build_once(dtype, rows, allocator, value)
    } else {
        build_column(dtype, rows, allocator, value)
    }
}

#[cfg(unix)]
pub(super) fn build_numeric_column<
    T: vortex::array::dtype::NativePType + vortex::array::memory::HostBufferElement,
>(
    dtype: &DType,
    rows: usize,
    allocator: &HostAllocatorRef,
    value: impl FnMut(usize) -> Result<Option<T>>,
) -> Result<ArrayRef> {
    numeric::build_column(dtype, rows, allocator, value)
}

#[cfg(unix)]
pub(super) fn validate_finite_numeric_output(value: f64) -> Result<()> {
    numeric::finite(value.is_finite())
}

/// Copy already selected numeric storage into independently credited buffers.
/// Selection/casting and owner preparation remain the caller's responsibility.
#[cfg(unix)]
pub(super) fn copy_numeric_column(
    dtype: &DType,
    values: &PrimitiveArray,
    valid: &vortex::mask::Mask,
    allocator: &HostAllocatorRef,
    check_cancelled: impl FnMut() -> Result<()>,
) -> Result<ArrayRef> {
    numeric::copy_column(dtype, values, valid, allocator, check_cancelled)
}

/// Validate the complete typed domain without constructing an output column.
#[cfg(unix)]
pub(super) fn validate_numeric_column(
    dtype: &DType,
    values: &PrimitiveArray,
    valid: &vortex::mask::Mask,
    allocator: &HostAllocatorRef,
    check_cancelled: impl FnMut() -> Result<()>,
) -> Result<()> {
    numeric::validate_column(dtype, values, valid, allocator, check_cancelled)
}

/// Construct a prefix while preserving validation of every scalar in its
/// original order. The caller still supplies the complete selected input;
/// discarded rows use the same typed writes against bounded stack scratch.
#[cfg(unix)]
pub(super) fn build_column_prefix<'a>(
    dtype: &DType,
    rows: usize,
    retained: usize,
    allocator: &HostAllocatorRef,
    value: impl FnMut(usize) -> Result<Value<'a>>,
) -> Result<ArrayRef> {
    if retained > rows {
        return Err(failed("output prefix exceeds the selected row count"));
    }
    build_column_prefix_inner::<true>(dtype, rows, retained, allocator, value)
}

#[allow(clippy::too_many_lines)] // Both consumers share the exact validation and value visitation order.
fn build_column_prefix_inner<'a, const PREFIX: bool>(
    dtype: &DType,
    rows: usize,
    retained: usize,
    allocator: &HostAllocatorRef,
    mut value: impl FnMut(usize) -> Result<Value<'a>>,
) -> Result<ArrayRef> {
    let stride = width(dtype)?;
    let boolean = matches!(dtype, DType::Bool(_));
    let text = matches!(dtype, DType::Utf8(_) | DType::Binary(_));
    let mut validity = dtype
        .is_nullable()
        .then(|| allocate(allocator, retained.div_ceil(8), 1))
        .transpose()?;
    let mut data = allocate(
        allocator,
        if boolean {
            retained.div_ceil(8)
        } else {
            multiply(add(retained, usize::from(text))?, stride)?
        },
        stride.max(1),
    )?;
    let mut text_bytes = 0;
    let mut retained_text_bytes = 0;
    if text {
        for row in 0..rows {
            let bytes = value(row)?.variable_bytes().map_or(0, <[u8]>::len);
            text_bytes = add(text_bytes, bytes)?;
            if PREFIX && row < retained {
                retained_text_bytes = add(retained_text_bytes, bytes)?;
            }
        }
    }
    let mut text_data = text
        .then(|| {
            allocate(
                allocator,
                if PREFIX {
                    retained_text_bytes
                } else {
                    text_bytes
                },
                1,
            )
        })
        .transpose()?;
    let mut text_end = 0;
    let mut observed_text_end = 0;
    let mut discarded = [0_u8; 16];
    for row in 0..rows {
        let value = value(row)?;
        let keep = !PREFIX || row < retained;
        if matches!(value, Value::Null) {
            if !dtype.is_nullable() {
                return Err(failed("null in a nonnullable output column"));
            }
        } else {
            if keep && let Some(validity) = validity.as_mut() {
                set_bit(validity, row);
            }
            match (dtype, value) {
                (DType::Bool(_), Value::Bool(value)) => {
                    if keep && value {
                        set_bit(&mut data, row);
                    }
                }
                (DType::Utf8(_), value @ (Value::Text(_) | Value::SharedText(_)))
                | (DType::Binary(_), value @ (Value::Binary(_) | Value::SharedBinary(_))) => {
                    let bytes = value.variable_bytes().expect("variable variant matched");
                    if PREFIX {
                        observed_text_end = add(observed_text_end, bytes.len())?;
                        if observed_text_end > text_bytes {
                            return Err(failed("completed text changed during construction"));
                        }
                    }
                    if keep {
                        text_end = copy_bytes(
                            text_data.as_mut().expect("variable buffer allocated"),
                            text_end,
                            bytes,
                        )?;
                    }
                }
                (DType::Primitive(ptype, _), value) => {
                    write_primitive(
                        *ptype,
                        value,
                        if keep {
                            &mut data.as_mut_slice()[row * stride..(row + 1) * stride]
                        } else {
                            &mut discarded[..stride]
                        },
                    )?;
                }
                (DType::Extension(_), value) => {
                    let Value::Int(ticks) = &value else {
                        return Err(failed("temporal output requires signed integer ticks"));
                    };
                    crate::native_temporal::validate_ticks(dtype, *ticks)?;
                    write_primitive(
                        crate::native_payload_schema::temporal_storage(dtype)
                            .ok_or_else(|| failed("unsupported temporal output dtype"))?,
                        value,
                        if keep {
                            &mut data.as_mut_slice()[row * stride..(row + 1) * stride]
                        } else {
                            &mut discarded[..stride]
                        },
                    )?;
                }
                (DType::Decimal(dtype, _), Value::Decimal(value, actual))
                    if *dtype == actual
                        && value.unsigned_abs() < 10_u128.pow(u32::from(dtype.precision())) =>
                {
                    if keep {
                        data.as_mut_slice()[row * stride..(row + 1) * stride]
                            .copy_from_slice(&value.to_ne_bytes());
                    }
                }
                _ => return Err(failed("value differs from the declared output dtype")),
            }
        }
        if text {
            // Check the full observed offset even when no output retains it.
            let observed = u64::try_from(if PREFIX { observed_text_end } else { text_end })
                .map_err(vortex_error)?;
            if keep {
                data.as_mut_slice()[(row + 1) * 8..(row + 2) * 8]
                    .copy_from_slice(&observed.to_ne_bytes());
            }
        }
    }
    let validity = validity
        .map(|buffer| finish_validity(buffer.freeze(), retained, allocator))
        .transpose()?
        .unwrap_or(Validity::NonNullable);
    if (if PREFIX { observed_text_end } else { text_end }) != text_bytes
        || (PREFIX && text_end != retained_text_bytes)
    {
        return Err(failed(
            "completed variable payload changed during construction",
        ));
    }
    finish_column(
        dtype,
        retained,
        data.freeze(),
        validity,
        text_data.map(WritableHostBuffer::freeze),
        allocator,
    )
}

fn finish_validity(
    buffer: ByteBuffer,
    rows: usize,
    allocator: &HostAllocatorRef,
) -> Result<Validity> {
    let array =
        bool_array_with_retained_buffer(BitBuffer::new(buffer, rows), Validity::NonNullable)
            .map_err(vortex_error)?
            .into_array();
    retain_empty_array_credit(array, allocator)
        .map(Validity::Array)
        .map_err(vortex_error)
}

fn finish_column(
    dtype: &DType,
    rows: usize,
    data: ByteBuffer,
    validity: Validity,
    variable: Option<ByteBuffer>,
    allocator: &HostAllocatorRef,
) -> Result<ArrayRef> {
    let array = match dtype {
        DType::Bool(_) => bool_array_with_retained_buffer(BitBuffer::new(data, rows), validity)
            .map(vortex::array::IntoArray::into_array)
            .map_err(vortex_error),
        DType::Primitive(ptype, _) => primitive(*ptype, data, validity),
        DType::Decimal(decimal, _) => {
            DecimalArray::try_new(Buffer::<i128>::from_byte_buffer(data), *decimal, validity)
                .map(vortex::array::IntoArray::into_array)
                .map_err(vortex_error)
        }
        DType::Extension(extension) => ExtensionArray::try_new(
            extension.clone(),
            retain_empty_array_credit(
                primitive(
                    crate::native_payload_schema::temporal_storage(dtype)
                        .ok_or_else(|| failed("unsupported temporal output dtype"))?,
                    data,
                    validity,
                )?,
                allocator,
            )
            .map_err(vortex_error)?,
        )
        .map(vortex::array::IntoArray::into_array)
        .map_err(vortex_error),
        DType::Utf8(_) | DType::Binary(_) => VarBinArray::try_new(
            PrimitiveArray::new(Buffer::<u64>::from_byte_buffer(data), Validity::NonNullable)
                .into_array(),
            variable.expect("variable buffer allocated"),
            dtype.clone(),
            validity,
            &mut vortex::array::array_session()
                .with_host_allocator(allocator.clone())
                .create_execution_ctx(),
        )
        .map(vortex::array::IntoArray::into_array)
        .map_err(vortex_error),
        _ => Err(failed("output dtype changed during construction")),
    }?;
    retain_empty_array_credit(array, allocator).map_err(vortex_error)
}

#[allow(clippy::cast_possible_truncation)]
fn write_primitive(ptype: PType, value: Value<'_>, output: &mut [u8]) -> Result<()> {
    macro_rules! integer {
        ($t:ty, $value:expr) => {
            output.copy_from_slice(&<$t>::try_from($value).map_err(vortex_error)?.to_ne_bytes())
        };
    }
    match (ptype, value) {
        (PType::I8, Value::Int(value)) => integer!(i8, value),
        (PType::I16, Value::Int(value)) => integer!(i16, value),
        (PType::I32, Value::Int(value)) => integer!(i32, value),
        (PType::I64, Value::Int(value)) => output.copy_from_slice(&value.to_ne_bytes()),
        (PType::U8, Value::UInt(value)) => integer!(u8, value),
        (PType::U16, Value::UInt(value)) => integer!(u16, value),
        (PType::U32, Value::UInt(value)) => integer!(u32, value),
        (PType::U64, Value::UInt(value)) => output.copy_from_slice(&value.to_ne_bytes()),
        (PType::F32, Value::Float(value))
            if value.is_finite() && f64::from(value as f32).to_bits() == value.to_bits() =>
        {
            output.copy_from_slice(&(value as f32).to_ne_bytes());
        }
        (PType::F64, Value::Float(value)) if value.is_finite() => {
            output.copy_from_slice(&value.to_ne_bytes());
        }
        _ => {
            return Err(failed(
                "numeric value differs from its finite declared dtype",
            ));
        }
    }
    Ok(())
}

fn primitive(ptype: PType, data: ByteBuffer, validity: Validity) -> Result<ArrayRef> {
    macro_rules! array {
        ($t:ty) => {
            PrimitiveArray::new(Buffer::<$t>::from_byte_buffer(data), validity).into_array()
        };
    }
    Ok(match ptype {
        PType::I8 => array!(i8),
        PType::I16 => array!(i16),
        PType::I32 => array!(i32),
        PType::I64 => array!(i64),
        PType::U8 => array!(u8),
        PType::U16 => array!(u16),
        PType::U32 => array!(u32),
        PType::U64 => array!(u64),
        PType::F32 => array!(f32),
        PType::F64 => array!(f64),
        PType::F16 => return Err(failed("float16 results are not admitted")),
    })
}
