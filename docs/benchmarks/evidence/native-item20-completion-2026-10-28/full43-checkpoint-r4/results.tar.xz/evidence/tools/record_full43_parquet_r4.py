"""Independently replay a complete single-pass direct-Parquet Full43 observation."""
import gzip
import hashlib
import json
import math
from pathlib import Path
import sys

REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(REPO / 'scripts'), str(REPO / 'python/src')]
from clickbench_reference_packet import load_reference_packet
from native_workflow_protocol import extract_result, report_fields
from run_clickbench_query_uat import equivalent


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def read(path):
    return json.loads(Path(path).read_text())


driver_path = OUT / 'full43-parquet-r4-driver.json'
driver = read(driver_path)
assert driver['status'] == 'passed' and driver['returncode'] == 0
assert driver['native_process_cleanup_verified'] and driver['process_group_drained'] and driver['direct_child_reaped']
assert not driver['timed_out'] and driver['interrupted_signal'] is None
assert driver['input_before'] == driver['input_after'] and driver['ingest_performed'] is False
assert len(driver['summaries']) == 1
freeze_path = Path(driver['freeze']['path'])
assert identity(freeze_path) == driver['freeze']
frozen = read(freeze_path)
assert frozen['queries'] == 43 and frozen['repeats'] == 1 and frozen['input_format'] == 'parquet'
assert frozen['memory_gb'] == 24 and frozen['max_parallelism'] == 12 and frozen['per_query_deadline_seconds'] == 120
assert frozen['source'] == driver['input_before'] and frozen['exact_source_commit_binding_verified'] is True
for key in ('runtime', 'helpers'):
    assert [identity(item['path']) for item in frozen[key]] == frozen[key]
summary_path = Path(driver['summaries'][0]['path'])
assert identity(summary_path) == driver['summaries'][0]
summary = read(summary_path)
assert summary['complete'] and summary['runs_passed'] == summary['runs_completed'] == 43
assert summary['selected_query_ids'] == list(range(1, 44)) and summary['repeats'] == 1
assert summary['score_scope'] == 'full_43' and summary['input_format'] == 'parquet'
assert summary['timing_available'] and summary['full_result_validation']
assert summary['completed_identity_check'] and summary['reference_packet_identity_verified'] and summary['harness_identity_verified']
assert summary['build_commit'] == driver['source_revision'] == frozen['source_revision']
binary = next(item for item in frozen['runtime'] if Path(item['path']).name == 'shardloom')
assert summary['binary_sha256'] == binary['sha256']
reference_path = Path(summary['reference_packet']['path'])
reference = load_reference_packet(reference_path, REPO / 'benchmarks/clickbench/queries.sql')
assert reference['packet'] == summary['reference_packet'] and identity(reference_path) == frozen['reference']
assert len(reference['queries']) == len(reference['values']) == len(summary['records']) == 43
rows = []
for record in summary['records']:
    query = record['query']
    assert record['passed'] and record['run'] == 1
    archive = record['completed_log_archives'][0]
    path = Path(archive['path'])
    assert identity(path)['sha256'] == archive['gzip_sha256']
    raw = gzip.decompress(path.read_bytes())
    assert len(raw) == archive['raw_bytes'] and hashlib.sha256(raw).hexdigest() == archive['raw_sha256']
    envelope = json.loads(raw)
    assert envelope['fallback']['attempted'] is False
    fields = report_fields(envelope)
    actual = extract_result(envelope)
    assert equivalent(actual, reference['values'][query])
    assert fields['native_input_end_observed'] == 'true'
    assert fields['native_input_output_ownership_detached'] == 'true'
    assert fields['native_source_demand_prepared_input_bytes_written'] == '0'
    assert all(value in (False, 'false') for name, value in fields.items()
               if name in ('fallback_attempted', 'external_engine_invoked',
                           'public_workflow_fallback_attempted', 'public_workflow_external_engine_invoked'))
    seconds = record['engine_execution_seconds']
    assert isinstance(seconds, (int, float)) and math.isfinite(seconds) and seconds >= 0
    rows.append(dict(query=query, complete_result_rows=len(actual), engine_execution_seconds=seconds,
        raw_output_sha256=archive['raw_sha256'], archive=identity(path)))
assert [row['query'] for row in rows] == list(range(1, 44))
engine_sum = sum(row['engine_execution_seconds'] for row in rows)
assert math.isclose(engine_sum, summary['query_total_seconds'], rel_tol=0, abs_tol=1e-9)
assert sum(row['complete_result_rows'] for row in rows) == 381
record = dict(schema_version=1, status='passed', valid_full43=True,
    source_revision=summary['build_commit'], source_tree=frozen['source_tree'],
    runtime=binary, input_format='parquet', ingest_performed=False,
    driver=identity(driver_path), freeze=identity(freeze_path), summary=identity(summary_path),
    reference=identity(reference_path), prior_failed_attempts=[identity(OUT / name) for name in (
        'full43-parquet-r1-driver.json', 'full43-direct-parquet-incomplete-r2.json',
        'full43-direct-parquet-incomplete-r3.json')],
    complete_queries=43, repetitions=1, full43_engine_seconds=engine_sum,
    timing_metric='sum_engine_execution_seconds_one_execution_per_query',
    completed_result_rows=381, completed_results_independently_replayed=True, rows=rows,
    source_identity_verified_before_and_after=True, process_cleanup_verified=True,
    no_prepared_input_artifacts=True, fallback_attempted=False, external_engine_invoked=False,
    historical_vortex_comparison='Different input boundary; no matched speedup/regression ratio.',
    limitation='One isolated direct-Parquet Full43 observation. Remaining item20, installed-package, portable combined and hosted acceptance are separate.',
    replay_helper=identity(__file__))
target = OUT / 'full43-direct-parquet-accepted-r4.json'
with target.open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: record[key] for key in ('status', 'complete_queries', 'completed_result_rows', 'full43_engine_seconds')}))
