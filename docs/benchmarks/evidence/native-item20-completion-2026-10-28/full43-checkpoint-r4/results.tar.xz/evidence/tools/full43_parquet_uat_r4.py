"""Run one isolated direct-Parquet Full43; no ingest or preparation command."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import stat
import subprocess
import sys

REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
RUN = OUT / 'full43-parquet-r4'
RUNTIME = OUT / 'candidate-compact-group-release-r1'
SOURCE = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat/sources/hits.parquet')
REFERENCE = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022/independent-full43-948/reference.json')
SUPERVISOR = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
GUARD = Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/native_workload_guard_816.py')
FROZEN = OUT / 'full43-parquet-r4-freeze.json'
RECEIPT = OUT / 'full43-parquet-r4-driver.json'
LOG = OUT / 'full43-parquet-r4-driver.log'
sys.path[:0] = [str(REPO / 'scripts'), str(REPO / 'python/src')]
from clickbench_reference_packet import load_reference_packet
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
from run_clickbench_query_uat import clickbench_harness_paths


def need(value, message):
    if not value:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text())


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)


def generation(path):
    info = path.stat()
    return dict(device=info.st_dev, inode=info.st_ino, bytes=info.st_size,
                mtime_ns=info.st_mtime_ns, ctime_ns=info.st_ctime_ns)


def resident_source():
    info = SOURCE.lstat()
    need(stat.S_ISREG(info.st_mode) and not SOURCE.is_symlink()
         and not getattr(info, 'st_flags', 0) & getattr(stat, 'SF_DATALESS', 0x40000000)
         and info.st_blocks * 512 >= info.st_size, 'original Parquet must already be resident')
    before = generation(SOURCE)
    value = identity(SOURCE)
    need(value['sha256'] == 'a390f6cb782f6aaef278c72fc1dd86c4f30bc843ebab3c159e9bd4d45ddb079f'
         and value['bytes'] == 14779976446 and generation(SOURCE) == before,
         'original Parquet identity changed')
    return dict(**value, generation=before)


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def freeze():
    need(not any(path.exists() for path in (RUN, FROZEN, RECEIPT, LOG)), 'Full43 run already exists')
    need(not git('status', '--porcelain'), 'commit the accepted checkpoint before Full43 binding')
    for relative in ('full43-parquet-shape-preflight-r4/summary.json',
                     'full43-parquet-values-preflight-r1/summary.json',
                     'e296-full43-final-harness-tests.json'):
        need(read(OUT / relative)['status'] == 'passed', 'harness correction proof failed')
    need(read(OUT / 'full43-parquet-r3-driver.json')['status'] == 'failed', 'latest failed attempt missing')
    disposition_path = OUT / 'compact-group-disposition.json'
    disposition = read(disposition_path)
    need(disposition['decision'] in (
             'retained_for_combined_item20_acceptance',
             'retained_resource_correction_without_performance_gain',
         ) and disposition['correctness_gate_passed'] is True
         and disposition['resource_correction_retained'] is True,
         'compact-group checkpoint is not accepted')
    public = read(OUT / 'compact-group-public-checks-r1.json')
    need(public['status'] == 'passed' and public['tests'] == 7, 'compact-group public checks did not pass')
    heldout = read(OUT / 'compact-group-heldout-r1-replay.json')
    need(heldout['status'] == 'passed' and heldout['observations'] == 160,
         'compact-group held-out correctness did not pass')
    q33_path = OUT / 'compact-group-q33-r1-acceptance.json'
    q33 = read(q33_path)
    need(q33['status'] == 'passed' and q33['valid_full43'] is False
         and q33['full43_engine_seconds'] is None,
         'compact-group Q33 diagnostic gate did not pass')
    need(len(q33['summaries']) == 1, 'compact-group Q33 summary count changed')
    q33_summary_record = q33['summaries'][0]
    q33_summary_path = Path(q33_summary_record['path'])
    need(identity(q33_summary_path) == q33_summary_record,
         'compact-group Q33 summary identity changed')
    manifest_path = RUNTIME / 'manifest.json'
    manifest = read(manifest_path)
    build_path = OUT / manifest['build_receipt']
    build = read(build_path)
    need(manifest['profile'] == 'release' and build['status'] == 'passed'
         and identity(build_path)['sha256'] == manifest['build_receipt_sha256'], 'build identity changed')
    for relative, item in disposition['release_source_linkage']['source_snapshot'].items():
        actual = identity(REPO / relative)
        need(actual['sha256'] == item['sha256'] and actual['bytes'] == item['bytes'],
             'accepted source differs from current commit: ' + relative)
    code_changes = git('diff', '--name-only', build['head'], 'HEAD').splitlines()
    for relative in code_changes:
        if relative.endswith(('.rs', '.toml', '.lock')):
            need(relative in build['changed_source_inventory'],
                 'committed runtime source not covered by measured build: ' + relative)
            item = build['changed_source_inventory'][relative]
            actual = identity(REPO / relative)
            need(actual['sha256'] == item['sha256'] and actual['bytes'] == item['bytes'],
                 'committed runtime source differs from measured build')
    runtime = [identity(RUNTIME / name) for name in ('shardloom', '_native.abi3.so')]
    for item in runtime:
        need({key: item[key] for key in ('bytes', 'sha256')} == manifest['files'][Path(item['path']).name],
             'accepted runtime changed')
    for path in (SOURCE, RUN):
        require_local_path(path, Path.home(), sys.platform)
    need(not (SOURCE.parent / '.shardloom').exists(), 'unexpected prepared-source artifact directory')
    source = resident_source()
    reference = identity(REFERENCE)
    need(reference['sha256'] == 'fc5780da415dc33bd06ed0879db07fc040db5dd419e3c37ecde7cd40a315696b'
         and reference['bytes'] == 454630, 'independent reference changed')
    packet = load_reference_packet(REFERENCE, REPO / 'benchmarks/clickbench/queries.sql')
    need(len(packet['queries']) == len(packet['values']) == 43, 'reference is not Full43')
    helpers = list(dict.fromkeys([Path(__file__), SUPERVISOR, GUARD, disposition_path,
        manifest_path, build_path, OUT / 'full43-parquet-r1-driver.json',
        OUT / 'full43-direct-parquet-incomplete-r2.json', OUT / 'full43-parquet-r2-driver.json',
        OUT / 'full43-direct-parquet-incomplete-r3.json', OUT / 'full43-parquet-r3-driver.json',
        OUT / 'compact-group-q33-r1-driver.json', q33_path, q33_summary_path,
        OUT / 'compact-group-protocol-r1.json',
        OUT / 'full43-parquet-shape-preflight-r4/summary.json',
        OUT / 'full43-parquet-values-preflight-r1/summary.json',
        OUT / 'e296-full43-final-harness-tests.json', OUT / 'compact-group-candidate-source-r1.json',
        OUT / 'compact-group-candidate-r1.patch',
        OUT / 'compact-group-public-checks-r1.json',
        OUT / 'compact-group-heldout-r1-replay.json', REFERENCE, *clickbench_harness_paths()]))
    frozen_helpers = [identity(path) for path in helpers]
    need(identity(SUPERVISOR)['sha256'] == '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97'
         and identity(GUARD)['sha256'] == 'ce56dd25bd4e55c8c7b8929140c2f2228f27f42d79ceea5645d50db320407b76',
         'standard supervision changed')
    storage = check_budgets(OUT, SOURCE, RUN / 'logs', min_free_bytes=12 * GIB,
                           reserve_bytes=128 * MIB, max_workspace_bytes=100 * GIB,
                           max_log_bytes=1024 * MIB, max_run_log_bytes=256 * MIB)
    record = dict(schema_version=1, status='frozen_before_full43', source=source, runtime=runtime,
        source_revision=git('rev-parse', 'HEAD'), source_tree=git('rev-parse', 'HEAD^{tree}'),
        original_build_revision=build['head'], exact_source_commit_binding_verified=True,
        continuation_reason='r3 passed Q1-32, then Q33 failed its reservation. Compact grouping storage passed the focused original Q33 check; a fresh complete pass is now required.',
        prior_failed_attempt=identity(OUT / 'full43-parquet-r3-driver.json'),
        source_manifest=disposition['release_source_linkage']['source_snapshot'],
        build=identity(build_path), accepted_checkpoint=identity(disposition_path),
        helpers=frozen_helpers, reference=reference, storage_before=storage,
        queries=43, repeats=1, input_format='parquet', ingest_performed=False,
        memory_gb=24, max_parallelism=12, per_query_deadline_seconds=120,
        no_prepared_input_artifacts=True,
        timing='sum of engine_execution_seconds for exactly one execution of each query',
        input_boundary='original Parquet consumed on demand by ShardLoom native operators; no ingest',
        historical_vortex_full43=dict(engine_seconds=46.973255495,
            comparison='separate input boundary; no matched speedup/regression ratio'),
        cache_context='full source hash before queries; uncontrolled OS cache; no manipulation',
        execution_policy='one sequential execution per query; all other task work and agents idle',
        recursive_inventory_during_execution=False,
        host=dict(platform=platform.platform(), machine=platform.machine(), python=sys.version,
                  cpu_count=os.cpu_count(), physical_memory_bytes=int(subprocess.check_output(
                      ['sysctl', '-n', 'hw.memsize'], text=True))))
    with FROZEN.open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status='frozen', input_format='parquet', queries=43, repeats=1,
                          ingest_performed=False, freeze=identity(FROZEN))), flush=True)


def run():
    frozen = read(FROZEN)
    need(frozen['status'] == 'frozen_before_full43' and not frozen['ingest_performed']
         and not any(path.exists() for path in (RUN, RECEIPT, LOG)), 'Full43 state is not fresh')
    def verify_source_and_helpers():
        need(git('rev-parse', 'HEAD') == frozen['source_revision']
             and not git('status', '--porcelain'), 'committed source changed')
        need([identity(Path(item['path'])) for item in frozen['helpers']] == frozen['helpers'],
             'frozen Full43 harness/build changed')
        need([identity(Path(item['path'])) for item in frozen['runtime']] == frozen['runtime'],
             'frozen Full43 runtime changed')
    verify_source_and_helpers()
    need(generation(SOURCE) == frozen['source']['generation'], 'source generation changed before queries')
    supervisor = load('item20_full43_supervisor', SUPERVISOR)
    workload_module = load('item20_full43_workload_guard', GUARD)
    workload = workload_module.WorkloadGuard()
    command = [sys.executable, '-B', 'scripts/run_clickbench_query_uat.py',
               '--binary', str(RUNTIME / 'shardloom'), '--input', str(SOURCE),
               '--input-format', 'parquet', '--uat-root', str(RUN),
               '--reference-packet', str(REFERENCE), '--build-commit', frozen['source_revision'],
               '--memory-gb', '24', '--max-parallelism', '12', '--timeout', '120',
               '--repeats', '1', '--compress-logs']
    evidence = dict(status='running', command=command, cwd=str(REPO), freeze=identity(FROZEN),
        input_before=frozen['source'], source_revision=frozen['source_revision'],
        input_format='parquet', ingest_performed=False, recursive_inventory_during_execution=False,
        guard='existing lightweight workload/free-space guard; standard runner storage/deadlines/cleanup')
    def guard():
        workload.check(evidence.get('pid'))
        need(shutil.disk_usage(OUT).free >= 12 * GIB, 'minimum free storage reached')
    code = 1
    try:
        guard()
        print('starting_one_isolated_direct_parquet_full43_no_ingest', flush=True)
        with LOG.open('xb') as stream:
            code = supervisor.run(command, cwd=REPO,
                env=dict(os.environ, PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1'),
                output=stream, timeout=3600, evidence=evidence, guard=guard, max_output_bytes=8 << 20)
        print('queries_finished_verifying_source_and_cleanup', flush=True)
        need(evidence['direct_child_reaped'] and evidence['process_group_drained'], 'process cleanup failed')
        workload_module.WorkloadGuard().check()
        need(not (RUN / '.ingest-uat.lock').exists(), 'query lock remains')
        need(not (SOURCE.parent / '.shardloom').exists(), 'prepared input artifacts appeared')
        verify_source_and_helpers()
        evidence['input_after'] = resident_source()
        need(evidence['input_after'] == evidence['input_before'], 'source changed across Full43')
        evidence['summaries'] = [identity(path) for path in RUN.glob('logs/*/summary.json')]
        need(len(evidence['summaries']) == 1, 'wrong Full43 summary count')
        evidence['native_process_cleanup_verified'] = True
        evidence['status'] = 'passed' if code == 0 else 'failed'
    except BaseException as error:
        evidence.update(status='failed', failure=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        evidence['log'] = identity(LOG) if LOG.exists() else None
        with RECEIPT.open('x') as stream:
            json.dump(evidence, stream, indent=2)
            stream.write('\n')
        print(json.dumps({key: evidence.get(key) for key in ('status', 'returncode', 'failure')}), flush=True)
    return code


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=('freeze', 'run'))
    args = parser.parse_args()
    sys.exit(run() if args.stage == 'run' else freeze())

