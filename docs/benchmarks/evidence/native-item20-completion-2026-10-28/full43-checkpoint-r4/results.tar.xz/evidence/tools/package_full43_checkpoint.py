"""Retain current UAT results and check logs; no query or native code executes."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import math
import re
import tarfile
import sys

REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
DEST = OUT / 'full43-checkpoint-r4'
sys.path[:0] = [str(REPO / 'scripts'), str(REPO / 'python/src')]
from native_workflow_protocol import extract_result, report_fields, strict_json
from run_clickbench_query_uat import equivalent
from clickbench_reference_packet import load_reference_packet
from query_timing_report import query_phase_timings


def need(value, reason):
    if not value:
        raise ValueError(reason)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return strict_json(Path(path).read_bytes())


files = {}
paths = {}


def add(path, name=None):
    path = Path(path)
    need(path.is_file() and not path.is_symlink(), 'expected regular evidence: ' + str(path))
    data = path.read_bytes()
    need(len(data) < 16 << 20, 'evidence member exceeds bound')
    name = name or 'evidence/' + path.relative_to(OUT).as_posix()
    need(not name.startswith('/') and '..' not in PurePosixPath(name).parts, 'unsafe evidence name')
    need(name not in files or files[name] == data, 'evidence name conflict')
    files[name] = data
    paths[str(path)] = name
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def checked(record, name=None):
    actual = add(record['path'], name)
    need(actual['sha256'] == record['sha256']
         and actual['bytes'] == record.get('bytes', actual['bytes']), 'linked evidence changed')
    return read(record['path'])


need(not DEST.exists(), 'checkpoint already exists')
accepted = read(OUT / 'full43-direct-parquet-accepted-r4.json')
add(OUT / 'full43-direct-parquet-accepted-r4.json')
driver = checked(accepted['driver'])
frozen = checked(accepted['freeze'])
summary = checked(accepted['summary'])
reference_path = Path(accepted['reference']['path'])
checked(accepted['reference'], 'reference/independent-full43.json')
reference = load_reference_packet(reference_path, REPO / 'benchmarks/clickbench/queries.sql')
add(REPO / 'benchmarks/clickbench/queries.sql', 'reference/queries.sql')
need(driver['status'] == 'passed' and driver['returncode'] == 0
     and driver['direct_child_reaped'] and driver['process_group_drained']
     and driver['native_process_cleanup_verified']
     and driver['input_before'] == driver['input_after'] == frozen['source'], 'Full43 driver failed')
need(summary['complete'] and summary['full_result_validation'] and summary['repeats'] == 1
     and summary['runs_completed'] == summary['runs_passed'] == 43
     and summary['selected_query_ids'] == list(range(1, 44))
     and summary['input_format'] == 'parquet' and not driver['ingest_performed'], 'Full43 incomplete')
need(accepted['source_revision'] == summary['build_commit'] == frozen['source_revision'],
     'Full43 source attribution changed')
rows = 0
for item, observation in zip(accepted['rows'], summary['records'], strict=True):
    query = item['query']
    need(query == observation['query'] and observation['run'] == 1 and observation['passed']
         and observation['returncode'] == 0 and not observation['guard_failures']
         and observation['validation'] == 'complete_values', 'query failed or was repeated')
    packed = Path(item['archive']['path'])
    add(packed)
    need(sha(packed.read_bytes()) == item['archive']['sha256'], 'raw result archive changed')
    with gzip.GzipFile(fileobj=io.BytesIO(packed.read_bytes())) as stream:
        raw = stream.read((16 << 20) + 1)
    need(len(raw) <= 16 << 20 and sha(raw) == item['raw_output_sha256'], 'raw result changed')
    envelope = strict_json(raw)
    fields = report_fields(envelope)
    actual = extract_result(envelope)
    need(equivalent(actual, reference['values'][query]), 'complete result differs')
    need(len(actual) == item['complete_result_rows'], 'complete result rows changed')
    need(fields['native_input_end_observed'] == fields['native_input_output_ownership_detached'] == 'true'
         and fields['native_source_demand_prepared_input_bytes_written'] == '0', 'input ownership differs')
    timing = query_phase_timings(fields, observation['process_wall_seconds'], allow_missing=False)
    need(timing['engine_execution_seconds'] == item['engine_execution_seconds']
         == observation['engine_execution_seconds'], 'engine timing differs from raw output')
    rows += len(actual)
total = sum(item['engine_execution_seconds'] for item in accepted['rows'])
need(rows == 381 and math.isclose(total, 651.558161209, rel_tol=0, abs_tol=1e-9)
     and total == summary['query_total_seconds'], 'Full43 total differs')

for relative, expected in frozen['source_manifest'].items():
    value = add(REPO / relative, 'source/' + relative)
    need({key: value[key] for key in ('bytes', 'sha256')} == expected, 'measured source changed')
gates = ('e331b-compact-native-clippy', 'e332-compact-native-suite', 'e333-compact-format-check',
         'e334-compact-workspace-clippy', 'e335-compact-workspace-tests',
         'e336-compact-group-release', 'e350-full43-r4-replay', 'e351-current-installed-wheel')
for name in gates:
    receipt = read(OUT / (name + '.json'))
    need(receipt['status'] == 'passed' and receipt['returncode'] == 0
         and receipt['direct_child_reaped'] and receipt['process_group_drained']
         and receipt['timed_out'] is False and receipt['interrupted_signal'] is None,
         'required check failed: ' + name)
    add(OUT / (name + '.json'))
    need(add(OUT / (name + '.log'))['sha256'] == receipt['log_sha256'], 'check log changed')
for name, expected in (('e332-compact-native-suite', (5057, 0, 35)),
                       ('e335-compact-workspace-tests', (3274, 0, 0))):
    matches = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',
                        (OUT / (name + '.log')).read_text())
    need(matches and tuple(sum(int(row[i]) for row in matches) for i in range(3)) == expected,
         'complete test totals differ')
package_root = OUT / 'installed-wheel-current-r1'
package = read(package_root / 'report.json')
need(package['status'] == package['uninstall_status'] == 'passed'
     and package['integration'] == dict(tests=207, failures=0, errors=0, skipped=0, status='passed')
     and package['publication_attempted'] is False, 'installed package proof failed')
runtime = {Path(item['path']).name: item for item in frozen['runtime']}
need(package['integrity']['cli_sha256'] == summary['binary_sha256'] == runtime['shardloom']['sha256']
     and package['integrity']['native_library_sha256'] == runtime['_native.abi3.so']['sha256'],
     'installed package differs from measured runtime')
for step in package['steps']:
    need(step['returncode'] == 0 and add(package_root / step['log'])['sha256'] == step['log_sha256'],
         'installed package step changed')
for name in ('report.json', 'integration.json'):
    add(package_root / name)
for name in ('compact-group-disposition.json', 'compact-group-protocol-r1.json',
             'compact-group-public-checks-r1.json', 'compact-group-heldout-r1-replay.json',
             'broad-compact-group-r1-comparison.json', 'full43-direct-parquet-incomplete-r2.json',
             'full43-direct-parquet-incomplete-r3.json', 'full43-parquet-r1-driver.json',
             'compact-group-q33-r1-acceptance.json', 'candidate-compact-group-release-r1/manifest.json'):
    add(OUT / name)
for helper in ('record_full43_parquet_r4.py', 'full43_parquet_uat_r4.py', 'package_full43_checkpoint.py'):
    add(OUT / 'tools' / helper)
for relative in ('scripts/run_clickbench_query_uat.py', 'scripts/clickbench_native_sql.py',
                 'scripts/clickbench_reference_packet.py', 'scripts/native_workflow_protocol.py',
                 'scripts/query_timing_report.py', 'scripts/prove_native_python_wheel.py'):
    add(REPO / relative, 'source/' + relative)

DEST.mkdir()
archive_path = DEST / 'results.tar.xz'
with tarfile.open(archive_path, 'w:xz') as archive:
    for name, data in sorted(files.items()):
        item = tarfile.TarInfo(name)
        item.size = len(data)
        item.mode = 0o644
        archive.addfile(item, io.BytesIO(data))
with tarfile.open(archive_path, 'r:xz') as archive:
    members = archive.getmembers()
    need(len(members) == len(files) and {item.name for item in members} == set(files), 'archive inventory differs')
    for item in members:
        need(item.isfile() and archive.extractfile(item).read() == files[item.name], 'archive readback differs')
inventory = {name: dict(bytes=len(data), sha256=sha(data)) for name, data in sorted(files.items())}
record = dict(schema_version=1, status='passed', scope='current_host_full43_and_installed_package_checkpoint',
    source_revision=accepted['source_revision'], source_tree=accepted['source_tree'],
    runtime=frozen['runtime'], original_source=frozen['source'],
    full43=dict(queries=43, repeats=1, complete_result_rows=381, engine_seconds=total,
                input_format='parquet', ingest_performed=False, raw_values_and_engine_clocks_replayed=True),
    source_tests=dict(native_passed=5057, native_ignored=35, workspace_passed=3274,
                      format='passed', native_clippy='passed', workspace_clippy='passed'),
    installed_package=dict(tests=207, skipped=0, uninstall='passed',
        wheel_sha256=package['integrity']['wheel_sha256'], runtime_matches_full43=True),
    raw_archive=dict(path='results.tar.xz', bytes=archive_path.stat().st_size,
                     sha256=sha(archive_path.read_bytes())),
    file_count=len(files), expanded_file_bytes=sum(map(len, files.values())),
    files=inventory, original_path_map=paths,
    archive_readback_verified=True, query_reexecutions=0, publication_attempted=False,
    item_20_complete=False, hosted_acceptance='separate',
    limitations=['Source identities and saved outcomes are internally checked, not signed provenance.',
        'The archive retains raw Full43 results, reference, source snapshots and current check/install logs.',
        '347-query and held-out outcomes are linked summaries; their full local replay is recorded in the disposition.',
        'Large input, executable and wheel payloads are excluded; their exact identities are retained.',
        'Whole-item20 combined portable acceptance and remaining capabilities are not claimed.'])
(DEST / 'checkpoint.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ('status', 'scope', 'full43', 'installed_package',
                                             'file_count', 'expanded_file_bytes', 'raw_archive')}))
