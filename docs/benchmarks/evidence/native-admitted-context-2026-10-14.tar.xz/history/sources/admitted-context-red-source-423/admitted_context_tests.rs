//! The helper must keep both the allocator and provider registry of its caller.

use super::{aggregate_column_accessor_in_context, aggregate_direct_stat_value};
use crate::owned_buffers::ReservedHostAllocator;
use shardloom_core::StatValue;
use shardloom_exec::live_memory::LiveMemoryPool;
use std::sync::Arc;
use vortex::{
    VortexSessionDefault as _,
    array::{
        ArrayRef, IntoArray as _, VortexSessionExecute as _,
        arrays::{BoolArray, ChunkedArray, DictArray, PrimitiveArray, VarBinViewArray},
        memory::MemorySessionExt as _,
        validity::Validity,
    },
    buffer::BitBuffer,
    encodings::zstd::{Zstd, ZstdData},
    session::VortexSession,
};

fn session(memory: &LiveMemoryPool) -> VortexSession {
    let session = VortexSession::default()
        .with_allocator(Arc::new(ReservedHostAllocator::new(memory.clone())));
    crate::native_provider_memory::install(&session, memory.clone());
    session
}

fn compressed(values: &PrimitiveArray) -> ArrayRef {
    let data = ZstdData::from_primitive_without_dict(
        values,
        0,
        8,
        &mut VortexSession::default().create_execution_ctx(),
    )
    .unwrap();
    Zstd::try_new(values.dtype().clone(), data, values.validity().unwrap())
        .unwrap()
        .into_array()
}

fn encoded_validity(codes: &[u32]) -> Validity {
    // A scalar validity lookup must decode the codes. A chunked canonical Bool
    // fixture alone would select a child without allocating and miss the defect.
    Validity::Array(
        DictArray::try_new(
            compressed(&PrimitiveArray::from_iter(codes.iter().copied())),
            BoolArray::from_iter([true, false]).into_array(),
        )
        .unwrap()
        .into_array(),
    )
}

fn dictionary(codes: ArrayRef, values: ArrayRef) -> ArrayRef {
    DictArray::try_new(codes, values).unwrap().into_array()
}

fn assert_aggregate_admission(input: &ArrayRef, expected: &[StatValue]) {
    let budget = 16 << 20;
    let memory = LiveMemoryPool::new(budget).unwrap();
    let mut ctx = session(&memory).create_execution_ctx();
    let pressure = memory.reserve(budget - 1).unwrap();
    let error = aggregate_column_accessor_in_context("renamed_value", input, &mut ctx)
        .err()
        .expect("native helper must refuse execution with one byte available");
    assert!(
        error.to_string().contains("memory reservation denied"),
        "{error}"
    );
    assert!(memory.snapshot().denied_reservations > 0);
    assert_eq!(memory.snapshot().reserved_bytes, budget - 1);
    drop(pressure);
    assert_eq!(memory.snapshot().reserved_bytes, 0);

    // Retry the same array and execution context after competing work releases
    // credit. A cached failure or a replaced session must not affect the result.
    let (accessor, _) =
        aggregate_column_accessor_in_context("renamed_value", input, &mut ctx).unwrap();
    let actual = (0..input.len())
        .map(|row| aggregate_direct_stat_value(&accessor, row).unwrap())
        .collect::<Vec<_>>();
    assert_eq!(actual, expected);
    drop(accessor);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}

#[test]
fn admitted_context_boolean_materialization_refuses_and_retries() {
    let first = BoolArray::from_iter([true, false]).into_array();
    let dtype = first.dtype().clone();
    let input = ChunkedArray::try_new(
        vec![first, BoolArray::from_iter([false, true]).into_array()],
        dtype,
    )
    .unwrap()
    .into_array();
    assert_aggregate_admission(&input, &[true, false, false, true].map(StatValue::Boolean));
}

#[test]
fn admitted_context_numeric_dictionary_values_refuse_and_retry() {
    let input = dictionary(
        PrimitiveArray::from_iter([1u32, 0, 1, 0]).into_array(),
        compressed(&PrimitiveArray::from_iter([11i64, -7])),
    );
    assert_aggregate_admission(&input, &[-7, 11, -7, 11].map(StatValue::Int64));
}

#[test]
fn admitted_context_numeric_dictionary_codes_refuse_and_retry() {
    let input = dictionary(
        compressed(&PrimitiveArray::from_iter([1u32, 0, 1, 0])),
        PrimitiveArray::from_iter([11i64, -7]).into_array(),
    );
    assert_aggregate_admission(&input, &[-7, 11, -7, 11].map(StatValue::Int64));
}

#[test]
fn admitted_context_utf8_dictionary_codes_refuse_and_retry() {
    let input = dictionary(
        compressed(&PrimitiveArray::from_iter([1u32, 0, 1, 0])),
        VarBinViewArray::from_iter_str(["first", "λ-second"]).into_array(),
    );
    assert_aggregate_admission(
        &input,
        &["λ-second", "first", "λ-second", "first"].map(|s| StatValue::Utf8(s.into())),
    );
}

#[test]
fn admitted_context_dictionary_value_validity_refuses_and_retries() {
    let input = dictionary(
        PrimitiveArray::from_iter([1u32, 0, 1, 0]).into_array(),
        PrimitiveArray::new(vec![11i64, -7], encoded_validity(&[0, 1])).into_array(),
    );
    assert_aggregate_admission(
        &input,
        &[
            StatValue::Null,
            StatValue::Int64(11),
            StatValue::Null,
            StatValue::Int64(11),
        ],
    );
}

#[test]
fn admitted_context_dictionary_code_validity_refuses_and_retries() {
    let input = dictionary(
        PrimitiveArray::new(vec![1u32, 0, 1, 0], encoded_validity(&[0, 1, 0, 0])).into_array(),
        PrimitiveArray::from_iter([11i64, -7]).into_array(),
    );
    assert_aggregate_admission(
        &input,
        &[
            StatValue::Int64(-7),
            StatValue::Null,
            StatValue::Int64(-7),
            StatValue::Int64(11),
        ],
    );
}

#[test]
fn admitted_context_boolean_validity_refuses_and_retries() {
    let input = BoolArray::new(BitBuffer::new_set(4), encoded_validity(&[0, 1, 0, 0])).into_array();
    assert_aggregate_admission(
        &input,
        &[
            StatValue::Boolean(true),
            StatValue::Null,
            StatValue::Boolean(true),
            StatValue::Boolean(true),
        ],
    );
}

#[test]
fn admitted_context_native_numeric_validity_keeps_existing_admission() {
    let input =
        PrimitiveArray::new(vec![1i64, -2, 3, -4], encoded_validity(&[0, 1, 0, 0])).into_array();
    assert_aggregate_admission(
        &input,
        &[
            StatValue::Int64(1),
            StatValue::Null,
            StatValue::Int64(3),
            StatValue::Int64(-4),
        ],
    );
}
