"""Prepare a mechanical patch for the explicitly selected private helper graph."""
import difflib
import re
from pathlib import Path

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
PATH = ROOT / 'shardloom-vortex/src/local_primitives.rs'


def masked(text):
    out = list(text)
    i = 0
    raw_pattern = re.compile(r'(?:br|r)(#*)"')
    char_pattern = re.compile(r"(?:b)?'(?:\\(?:u\{[0-9a-fA-F_]+\}|x[0-9a-fA-F]{2}|.)|[^'\\\n])'")
    while i < len(text):
        start = i
        if text.startswith('//', i):
            i = text.find('\n', i)
            if i < 0:
                i = len(text)
        elif text.startswith('/*', i):
            i += 2
            depth = 1
            while depth and i < len(text):
                if text.startswith('/*', i):
                    depth += 1; i += 2
                elif text.startswith('*/', i):
                    depth -= 1; i += 2
                else:
                    i += 1
            assert depth == 0
        else:
            raw = raw_pattern.match(text, i)
            char = char_pattern.match(text, i)
            if raw:
                end = text.find('"' + raw[1], raw.end())
                assert end >= 0
                i = end + 1 + len(raw[1])
            elif text[i] == '"' or text.startswith('b"', i):
                i += 1 if text[i] == '"' else 2
                while i < len(text):
                    if text[i] == '\\':
                        i += 2
                    elif text[i] == '"':
                        i += 1; break
                    else:
                        i += 1
            elif char:
                i = char.end()
            else:
                i += 1
                continue
        for j in range(start, i):
            if out[j] != '\n':
                out[j] = ' '
    return ''.join(out)


def close(source, at, opening='(', closing=')'):
    assert source[at] == opening
    depth = 1
    for i in range(at + 1, len(source)):
        if source[i] == opening: depth += 1
        if source[i] == closing: depth -= 1
        if depth == 0: return i
    raise ValueError('unclosed delimiter')


NEW = set('''
fast_count_matches_in_chunk fast_candidate_row_indices_in_chunk
fast_exact_candidate_row_indices_in_chunk filter_column_scoped_candidate_row_indices_in_chunk
filter_materialized_candidate_row_indices_in_chunk filter_candidate_row_indices_by_single_column
residual_candidate_row_indices_for_chunk row_key_columns_from_chunk explode_columns_from_chunk
fast_null_count_from_chunk fast_null_row_indices_from_chunk
fast_compare_count_from_chunk fast_compare_row_indices_from_chunk
fast_in_list_count_from_chunk fast_in_list_row_indices_from_chunk
fast_utf8_contains_count_from_chunk fast_utf8_contains_row_indices_from_chunk
fast_utf8_contains_count_from_array fast_utf8_contains_row_indices_from_array
fast_utf8_contains_count_from_filtered_array fast_utf8_contains_row_indices_from_filtered_array
fast_utf8_contains_count_from_masked_array fast_utf8_contains_row_indices_from_masked_array
fast_utf8_contains_count_from_masked_dictionary_array fast_utf8_contains_row_indices_from_masked_dictionary_array
fast_utf8_contains_count_from_fsst_array fast_utf8_contains_row_indices_from_fsst_array
fast_utf8_contains_count_from_masked_fsst_array fast_utf8_contains_row_indices_from_masked_fsst_array
fast_utf8_contains_fsst_matches fast_utf8_contains_count_from_dictionary_array
fast_utf8_contains_row_indices_from_dictionary_array fast_utf8_contains_dictionary_matches_and_codes
aggregate_direct_column_accessor aggregate_direct_utf8_chunk_dictionary_accessor
aggregate_direct_utf8_dictionary_accessor
'''.split())
EXISTING = set('''
row_export_columns_from_chunk row_export_selected_columns_from_chunk
row_export_values_from_vortex_array row_export_selected_values_from_vortex_array
list_element_rows_from_vortex_array scalar_values_from_vortex_array struct_scalar_values_from_vortex_array
row_key_values_from_vortex_array list_row_key_values_from_vortex_array struct_row_key_values_from_vortex_array
stat_values_from_vortex_array selected_stat_values_from_vortex_array
direct_non_nullable_stat_values_from_vortex_array direct_selected_dictionary_stat_values_from_vortex_array
primitive_stat_values_from_vortex_array primitive_stat_values_from_primitive_array
stat_values_with_validity utf8_stat_values_from_vortex_array direct_non_nullable_utf8_stat_values_from_vortex_array
bool_stat_values_from_vortex_array direct_u32_codes_with_nulls_from_vortex_array primitive_u32_codes_with_nulls
aggregate_column_accessor_in_context aggregate_direct_numeric_dictionary_accessor
aggregate_direct_numeric_dictionary_accessor_from_primitive aggregate_direct_utf8_dictionary_accessor_in_context
direct_bool_aggregate_column_accessor bool_aggregate_column_accessor_from_array
aggregate_direct_primitive_row_nulls aggregate_direct_row_nulls_from_validity
'''.split())


def functions(text, code):
    rows=[]
    for m in re.finditer(r'\bfn\s+(\w+)\s*(?:<[^\n]*>)?\s*\(', code):
        left=m.end()-1
        right=close(code,left)
        body=code.find('{',right)
        semicolon=code.find(';',right)
        if semicolon>=0 and semicolon<body:
            continue
        end=close(code,body,'{','}')
        rows.append(dict(name=m[1],start=m.start(),left=left,right=right,body=body,end=end))
    return rows


def append_argument(text, left, right, arg):
    inside=text[left+1:right]
    stripped=inside.rstrip()
    if re.search(r'\bctx\s*,?$', stripped): return None
    if stripped.endswith(','):
        return right, right, arg + ','
    return right, right, (', ' if stripped else '') + arg


def main():
    text=PATH.read_text(); code=masked(text)
    rows=functions(text,code)
    edits=[]; declarations={}
    for row in rows:
        if row['name'] in NEW:
            assert row['name'] not in declarations, row['name']
            declarations[row['name']]=row
            assert 'ctx:' not in text[row['left']:row['right']]
            edits.append(append_argument(text,row['left'],row['right'],'ctx: &mut vortex::array::ExecutionCtx'))
    assert set(declarations)==NEW, NEW-set(declarations)
    signature_starts={r['left'] for r in rows}
    targets=NEW|EXISTING
    count=0
    for match in re.finditer(r'\b('+'|'.join(sorted(targets))+r')\s*\(', code):
        left=match.end()-1
        if left in signature_starts: continue
        owners=[r for r in rows if r['body'] < left < r['end']]
        if not owners: continue
        owner=min(owners,key=lambda r:r['end']-r['body'])
        if owner['name'] not in targets: continue
        right=close(code,left)
        edit=append_argument(text,left,right,'ctx')
        if edit: edits.append(edit); count+=1
    assert None not in edits
    updated=text
    for start,end,replacement in sorted(edits,reverse=True):
        updated=updated[:start]+replacement+updated[end:]
    diff=list(difflib.unified_diff(text.splitlines(True),updated.splitlines(True),n=3))
    print('*** Begin Patch\n*** Update File: '+str(PATH))
    print(''.join(diff[2:]),end='')
    print('*** End Patch')


if __name__=='__main__': main()
