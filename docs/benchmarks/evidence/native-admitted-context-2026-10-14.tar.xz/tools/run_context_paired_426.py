"""Freeze and compare the complete correction with the retained merged-main CLI."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import stat
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
UAT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
BASE = '22b2cde04973ce4462517d73fe67b5f7a1e8177c'
PLAN = OUT / 'context-paired-plan-426.json'
FROZEN = OUT / 'context-paired-frozen-426.json'
sys.path[:0] = [str(ROOT / 'scripts'), str(OUT)]
from freeze_native_release_298 import sources
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
from run_clickbench_paired_query_uat import generation
from review_context_paired_426 import review_order


def read(path):
    return json.loads(Path(path).read_text())


def bound(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def verify(item):
    assert bound(item['path']) == {key: item[key] for key in ('path', 'bytes', 'sha256')}


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def freeze():
    assert not FROZEN.exists()
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
    acceptance = OUT / 'context-after-runtime-426.json'
    assert read(acceptance)['status'] == 'passed' and read(acceptance)['runtime_source_unchanged']
    checks_path = OUT / 'context-checks-425.json'
    checks = read(checks_path)
    assert checks['status'] == 'passed' and checks['runtime_source_unchanged']
    check_source = Path(checks['source_manifest'])
    assert bound(check_source)['sha256'] == checks['source_manifest_sha256']
    runtime = read(OUT / 'context-runtime-425.json')
    assert runtime['status'] == 'passed' and runtime['source_identity_preserved']
    assert runtime['public_cases'] == 757 and len(runtime['public_families']) == 19
    native_manifest = read(runtime['manifest'])
    assert bound(runtime['manifest'])['sha256'] == runtime['manifest_sha256']
    assert bound(runtime['direct_summary'])['sha256'] == runtime['direct_summary_sha256']
    direct = read(runtime['direct_summary'])
    assert direct['status'] == 'passed' and direct['tests'] == 80 and direct['skipped'] == 0
    public_review = read(OUT / 'context-public-review-425.json')
    assert public_review['status'] == 'passed' and public_review['cases'] == 757
    assert public_review['families'] == 19 and public_review['frozen_sources_and_binary_unchanged']
    assert public_review['runtime'] == bound(OUT / 'context-runtime-425.json')
    current_sources = sources()
    assert current_sources == native_manifest['source_sha256'] == read(check_source)['source_sha256']
    delta = read(OUT / 'context-source-delta-426.json')
    assert delta['status'] == 'passed' and delta['source_unchanged'] and delta['base_commit'] == BASE
    assert delta['frozen_source']['sha256'] == bound(check_source)['sha256']
    for item in delta['changed_source_paths']:
        assert current_sources[item['path']] == item['sha256']
        verify(dict(path=item['snapshot'], bytes=item['bytes'], sha256=item['sha256']))
    verify(delta['tracked_patch'])
    plan = read(PLAN)
    assert plan['workload']['query_ids'] == list(range(1, 44))
    assert plan['workload']['orders'] == ['forward', 'reverse']
    assert plan['workload']['pairs_per_query_per_order'] == 3
    assert plan['workload']['total_complete_calls'] == 516
    assert plan['workload']['memory_gib'] == 24 and plan['workload']['maximum_parallelism'] == 12
    source = Path(plan['workload']['source'])
    require_local_path(UAT, Path.home(), sys.platform)
    require_local_path(source, Path.home(), sys.platform)
    source_stat = source.stat()
    assert stat.S_ISREG(source_stat.st_mode) and not source.is_symlink()
    assert source_stat.st_flags == 0 and source_stat.st_blocks * 512 >= source_stat.st_size
    assert source_stat.st_size == plan['workload']['source_bytes']
    assert not (UAT / '.ingest-uat.lock').exists()
    storage = check_budgets(UAT, source, UAT / 'logs/context-paired-426-admission',
        min_free_bytes=12 * GIB, reserve_bytes=256 * MIB, max_workspace_bytes=100 * GIB,
        max_log_bytes=1024 * MIB, max_run_log_bytes=256 * MIB, reserve_log_bytes=256 * MIB)
    before = generation(source)
    source_identity = bound(source)
    assert source_identity['sha256'] == plan['workload']['source_sha256']
    assert generation(source) == before
    proof_path = OUT / 'context-control-source-426.json'
    proof = read(proof_path)
    assert proof['status'] == 'passed' and proof['accepted_commit'] == BASE
    assert proof['exact_selected_path_set_matches_git_tree'] and proof['all_native_blobs_match']
    assert proof['binary_matches_manifest'] and not proof['mismatches']
    assert proof['selected_native_path_count'] == proof['git_native_path_count'] == proof['checked_native_file_count'] == 1762
    for item in (proof['manifest'], proof['source_manifest']['observed'],
                 proof['build_receipt']['observed'], proof['build_log']['observed'], proof['verifier']):
        verify(item)
    binaries, manifests, build_evidence = {}, {}, {}
    for role in ('control', 'candidate'):
        manifest_path = OUT / plan[role]['manifest']
        manifest = read(manifest_path)
        assert manifest['status'] == 'passed' and manifest['build_profile'] == 'release'
        source_path = Path(manifest['source_manifest']['path'])
        assert bound(source_path)['sha256'] == manifest['source_manifest']['sha256']
        assert read(source_path)['source_sha256'] == manifest['source_sha256']
        build_path = Path(manifest['cli']['build_receipt'])
        assert bound(build_path)['sha256'] == manifest['cli']['build_receipt_sha256']
        build = read(build_path)
        assert build['status'] == 'passed' and build['returncode'] == 0
        assert build['process_group_drained'] and build['direct_child_reaped']
        assert '--release' in build['command'] and 'release-user-surfaces' in build['command']
        log = Path(manifest['cli']['build_log'])
        assert bound(log)['sha256'] == build['log_sha256']
        binary = bound(manifest['cli']['path'])
        assert binary == {key: manifest['cli'][key] for key in ('path', 'bytes', 'sha256')}
        assert plan[role]['source_base_commit'] == BASE
        if role == 'control':
            assert bound(manifest_path) == proof['manifest']
            assert binary == proof['observed_binary'] == proof['recorded_binary']
        else:
            assert manifest['head'] == BASE and manifest['source_sha256'] == current_sources
            assert binary == {key: native_manifest['cli'][key] for key in ('path', 'bytes', 'sha256')}
        binaries[role] = dict(binary, source_base_commit=BASE,
            source_status='merged_main_native_sources' if role == 'control' else 'uncommitted_correction_bound_by_complete_source_manifest')
        manifests[role] = bound(manifest_path)
        build_evidence[role] = dict(source=bound(source_path), receipt=bound(build_path), log=bound(log))
    reference = bound(plan['workload']['reference'])
    assert reference['sha256'] == plan['workload']['reference_sha256']
    queries = bound(ROOT / 'benchmarks/clickbench/queries.sql')
    paths = [Path(__file__), OUT / 'review_context_paired_426.py', OUT / 'run_guarded.py',
        OUT / 'freeze_native_release_298.py', OUT / 'verify_context_control_source_426.py',
        Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py'),
        Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py')]
    paths += [ROOT / 'scripts' / name for name in ('run_clickbench_paired_query_uat.py',
        'run_clickbench_query_uat.py', 'clickbench_reference_packet.py', 'native_workflow_protocol.py',
        'timed_native_command.py', 'local_uat_storage.py')]
    paths += sorted((ROOT / 'python/src/shardloom').rglob('*.py'))
    helpers = {str(path): bound(path) for path in paths}
    prerequisites = {name: bound(OUT / name) for name in (
        'context-after-runtime-426.json', 'context-runtime-protocol-426.json',
        'context-checks-425.json', 'context-check-source-425.json',
        'context-runtime-425.json', 'context-native-artifacts-425.json',
        'context-direct-425.json', 'context-public-review-425.json', 'context-source-delta-426.json')}
    assert sources() == current_sources
    save(FROZEN, dict(status='frozen_before_any_correction_timing', plan=bound(PLAN),
        source_proof=bound(proof_path), route_reference=bound(OUT / 'composition-timing-primary-419.json'),
        prerequisites=prerequisites, binaries=binaries, manifests=manifests, build_evidence=build_evidence,
        source=source_identity, source_generation=before, reference=reference, queries=queries,
        helpers=helpers, active_workspace_sources=current_sources, storage=storage,
        platform=platform.platform(), logical_cpu_count=os.cpu_count(),
        physical_memory_bytes=os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES'),
        cache_state='Input prehashed; shared OS cache and ordinary host activity uncontrolled',
        native_comparison_executed=False))
    print(json.dumps(dict(status='frozen', calls=516, source=source_identity['sha256'])), flush=True)


def unchanged(frozen, include_input=False):
    bindings = list(frozen['helpers'].values()) + list(frozen['manifests'].values())
    bindings += list(frozen['prerequisites'].values())
    bindings += [item for role in frozen['build_evidence'].values() for item in role.values()]
    bindings += [frozen[key] for key in ('plan', 'source_proof', 'route_reference', 'reference', 'queries')]
    for item in bindings:
        verify(item)
    for item in frozen['binaries'].values():
        verify(item)
    assert sources() == frozen['active_workspace_sources']
    assert generation(Path(frozen['source']['path'])) == frozen['source_generation']
    if include_input:
        verify(frozen['source'])


def run():
    frozen = read(FROZEN)
    assert frozen['status'] == 'frozen_before_any_correction_timing'
    unchanged(frozen, include_input=True)
    for order in ('forward', 'reverse'):
        assert not (OUT / f'context-paired-{order}-426.json').exists()
        assert not (OUT / f'context-paired-{order}-review-426.json').exists()
    assert not (OUT / 'context-paired-result-426.json').exists()
    frozen_identity = bound(FROZEN)
    completed, schemas, failure = [], {}, None
    try:
        for order in ('forward', 'reverse'):
            unchanged(frozen)
            verify(frozen_identity)
            before = set((UAT / 'logs').glob('paired43_*/summary.json'))
            command = [sys.executable, '-B', str(OUT / 'run_guarded.py'),
                '--name', f'context-paired-{order}-426', '--timeout', '2400', '--',
                sys.executable, '-B', str(ROOT / 'scripts/run_clickbench_paired_query_uat.py')]
            for role in ('control', 'candidate'):
                command += [f'--{role}-binary', frozen['binaries'][role]['path'],
                    f'--{role}-commit', frozen['binaries'][role]['source_base_commit']]
            command += ['--input', frozen['source']['path'], '--uat-root', str(UAT),
                '--reference-packet', frozen['reference']['path'], '--queries', frozen['queries']['path'],
                '--memory-gb', '24', '--max-parallelism', '12', '--timeout', '120',
                '--max-workspace-gib', '100', '--max-log-mib', '1024', '--max-run-log-mib', '256']
            if order == 'reverse':
                command.append('--reverse-order')
            print(json.dumps(dict(stage=order, status='starting', calls=258)), flush=True)
            subprocess.run(command, cwd=ROOT, check=True)
            new = set((UAT / 'logs').glob('paired43_*/summary.json')) - before
            assert len(new) == 1
            summary = new.pop()
            unchanged(frozen, include_input=True)
            verify(frozen_identity)
            assert not (UAT / '.ingest-uat.lock').exists()
            review = review_order(order, summary, OUT / f'context-paired-{order}-426.json', frozen, schemas)
            save(OUT / f'context-paired-{order}-review-426.json', review)
            completed.append(review)
            print(json.dumps(dict(stage=order, status='passed', totals=review['totals'])), flush=True)
        repeated = []
        for forward, reverse in zip(completed[0]['per_query'], completed[1]['per_query'], strict=True):
            assert forward['query'] == reverse['query']
            metrics = [key for key in ('elapsed', 'cpu', 'rss') if forward['breaches'][key] and reverse['breaches'][key]]
            if metrics:
                repeated.append(dict(query=forward['query'], metrics=metrics))
        unchanged(frozen, include_input=True)
        outcome = 'repeatable_cost_increases_require_diagnosis' if repeated else 'passed_declared_cost_tolerances'
        save(OUT / 'context-paired-result-426.json', dict(status='needs_diagnosis' if repeated else 'passed',
            frozen=frozen_identity, cohorts=completed, total_complete_calls=516,
            candidate_complete_calls=258, candidate_complete_result_rows=sum(row['complete_result_rows'] // 2 for row in completed),
            repeated_metric_increases=repeated, outcome=outcome,
            interpretation='Final combined correction versus merged-main native sources on the same retained input. Both starting orders are retained. Complete paired candidate results also supply final Full43 acceptance; this is not another historical-composition attribution experiment.',
            limitations='Shared OS cache and ordinary desktop activity are uncontrolled. Threshold non-breach does not prove zero overhead, a speedup, an independent correctness oracle or the historical composition cause.',
            publication_attempted=False))
        print(json.dumps(dict(status='needs_diagnosis' if repeated else 'passed', outcome=outcome, repeated_metric_increases=repeated)), flush=True)
        assert not repeated, 'Repeated costs require diagnosis before accepting the correction'
    except BaseException as error:
        failure = f'{type(error).__name__}: {error}'
        raise
    finally:
        save(OUT / 'context-paired-driver-426.json', dict(status='passed' if failure is None else 'failed',
            failure=failure, frozen=frozen_identity, completed_orders=[r['order'] for r in completed]))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=['freeze', 'run'])
    args = parser.parse_args()
    freeze() if args.operation == 'freeze' else run()
