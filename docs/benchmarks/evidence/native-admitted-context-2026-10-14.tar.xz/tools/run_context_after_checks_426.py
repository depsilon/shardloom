"""Build the frozen correction and run its existing complete public acceptance."""
import json
from pathlib import Path
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sources, sha

BASE = '22b2cde04973ce4462517d73fe67b5f7a1e8177c'
HELPERS = ('run_context_after_checks_426.py', 'freeze_query_cli_368.py',
    'freeze_native_release_298.py', 'run_guarded.py', 'run_context_runtime_425.py',
    'verify_context_public_425.py')


def bound(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    with Path(path).open('x') as output:
        json.dump(value, output, indent=2, allow_nan=False)
        output.write('\n')


def main():
    checks_path = OUT / 'context-checks-425.json'
    checks = read(checks_path)
    assert checks['status'] == 'passed' and checks['runtime_source_unchanged']
    assert [row['name'] for row in checks['completed']] == [
        'fmt', 'read-clippy', 'release-clippy', 'workspace-clippy', 'workspace-tests', 'native-tests']
    source_path = Path(checks['source_manifest'])
    assert sha(source_path) == checks['source_manifest_sha256']
    source = read(source_path)
    assert source['head'] == BASE
    frozen = dict(checks=bound(checks_path), source=bound(source_path),
        helpers={name: bound(OUT / name) for name in HELPERS},
        scope='Final combined decoder/context source; sequential guarded release CLI, binding, 80 direct tests and 757 public cases. Paired Full43 follows separately.')
    def unchanged():
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
        assert sources() == source['source_sha256']
        for item in [frozen['checks'], frozen['source'], *frozen['helpers'].values()]:
            assert bound(item['path']) == item
    unchanged()
    save(OUT / 'context-runtime-protocol-426.json', frozen)
    completed, failure = [], None
    def stage(name, command):
        unchanged()
        print(json.dumps(dict(stage=name, status='starting')), flush=True)
        subprocess.run(command, cwd=ROOT, check=True)
        unchanged()
        completed.append(name)
        print(json.dumps(dict(stage=name, status='passed')), flush=True)
    try:
        stage('prepare-cli', [sys.executable, '-B', str(OUT / 'freeze_query_cli_368.py'),
            'prepare', '--name', 'context-resources-425'])
        stage('build-cli', [sys.executable, '-B', str(OUT / 'run_guarded.py'),
            '--name', 'native-context-release-build-425', '--timeout', '2100', '--',
            'cargo', 'build', '--offline', '--locked', '--release', '-p', 'shardloom-cli',
            '--bin', 'shardloom', '--features', 'release-user-surfaces', '--message-format=json'])
        stage('freeze-cli', [sys.executable, '-B', str(OUT / 'freeze_query_cli_368.py'),
            'freeze', '--name', 'context-resources-425', '--build-receipt',
            str(OUT / 'native-context-release-build-425.json')])
        stage('runtime', [sys.executable, '-B', str(OUT / 'run_context_runtime_425.py')])
        stage('public-review', [sys.executable, '-B', str(OUT / 'run_guarded.py'),
            '--name', 'native-context-public-review-426', '--timeout', '300', '--',
            sys.executable, '-B', str(OUT / 'verify_context_public_425.py')])
        assert read(OUT / 'context-public-review-425.json')['status'] == 'passed'
        assert read(OUT / 'context-runtime-425.json')['status'] == 'passed'
        unchanged()
    except BaseException as error:
        failure = f'{type(error).__name__}: {error}'
        raise
    finally:
        save(OUT / 'context-after-runtime-426.json', dict(status='passed' if failure is None else 'failed',
            protocol=bound(OUT / 'context-runtime-protocol-426.json'), completed=completed, failure=failure,
            runtime_source_unchanged=sources() == source['source_sha256']))


if __name__ == '__main__':
    main()
