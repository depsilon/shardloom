"""Reopen the complete finite public acceptance evidence for admitted native helper context."""
import gzip
import hashlib
import json
from pathlib import Path
import sys

from freeze_native_release_298 import ROOT, OUT, sha, sources, save
sys.path.insert(0, str(ROOT / 'scripts'))
from native_workflow_protocol import report_fields, strict_json

PUBLIC = OUT / 'context-public-425'


def bound(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def main():
    runtime = strict_json((OUT / 'context-runtime-425.json').read_text())
    assert runtime['status'] == 'passed'
    manifest = strict_json(Path(runtime['manifest']).read_text())
    assert sha(runtime['manifest']) == runtime['manifest_sha256']
    assert sources() == manifest['source_sha256']
    assert sha(manifest['cli']['path']) == manifest['cli']['sha256']
    summary_path = PUBLIC / 'summary.json'
    assert sha(summary_path) == runtime['public_summary_sha256']
    summary = strict_json(summary_path.read_text())
    baseline_path = OUT / 'stream-composition-public-398/summary.json'
    baseline = strict_json(baseline_path.read_text())
    cases = summary['cases']
    names = [case['name'] for case in cases]
    assert len(names) == len(set(names)) == 757
    assert names == [case['name'] for case in baseline['cases']]
    assert summary['families'] == baseline['families'] and len(summary['families']) == 19
    assert summary['status'] == 'passed' and all(case['status'] == 'passed' for case in cases)
    receipt_path = OUT / 'native-context-public-425.json'
    receipt = strict_json(receipt_path.read_text())
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    log_path = receipt_path.with_suffix('.log')
    assert sha(log_path) == receipt['log_sha256']
    logged = [strict_json(line) for line in log_path.read_text().splitlines() if line.startswith('{')]
    assert [row for row in logged if 'name' in row] == cases
    for path, digest in summary['sources'].items():
        assert sha(path) == digest
        if Path(path).suffix == '.py':
            assert sha(PUBLIC / 'logs' / Path(path).name) == digest
    references = {}
    def visit(value):
        if isinstance(value, dict):
            relative = value.get('path')
            if isinstance(relative, str) and relative.startswith(('logs/', 'outputs/')):
                path = PUBLIC / relative
                assert path.resolve().is_relative_to(PUBLIC.resolve())
                identity = bound(path)
                for key in ('bytes', 'sha256'):
                    if key in value:
                        assert value[key] == identity[key], relative
                if relative in references:
                    assert references[relative] == identity
                references[relative] = identity
            for child in value.values():
                visit(child)
        elif isinstance(value, list):
            for child in value:
                visit(child)
    visit(cases)
    comparisons = []
    envelopes = []
    for path in sorted((PUBLIC / 'logs').glob('*-values.json')):
        payload = strict_json(path.read_text())
        assert payload['actual'] == payload['expected'], path.name
        comparisons.append(dict(**bound(path), rows=len(payload['actual'])))
    for path in sorted((PUBLIC / 'logs').glob('*-envelope.json')):
        envelope = strict_json(path.read_text())
        assert envelope['fallback']['attempted'] is False
        if envelope['status'] == 'success':
            fields = report_fields(envelope)
            assert fields['public_workflow_external_engine_invoked'] == 'false'
        else:
            entries = envelope['fields']
            fields = {entry['key']: entry['value'] for entry in entries}
            assert len(fields) == len(entries)
            assert envelope['diagnostics'] and fields.get('result_payload_complete') != 'true'
        envelopes.append(dict(**bound(path), status=envelope['status']))
    pressure = []
    for case in cases:
        artifact = case.get('values') or case.get('complete_rows')
        if not isinstance(artifact, dict) or not artifact.get('path', '').endswith('.jsonl.gz'):
            continue
        path = PUBLIC / artifact['path']
        digest = hashlib.sha256()
        count = 0
        with gzip.open(path, 'rb') as stream:
            for line in stream:
                strict_json(line)
                digest.update(line)
                count += 1
        expected_count = case.get('rows_verified', case.get('complete_output_rows', case.get('complete_rows')))
        expected_digest = case.get('expected_sha256', case.get('all_output_rows_sha256'))
        assert count == expected_count and digest.hexdigest() == expected_digest, case['name']
        pressure.append(dict(name=case['name'], **bound(path), rows=count, raw_sha256=digest.hexdigest()))
    assert comparisons and envelopes and pressure
    assert sources() == manifest['source_sha256']
    output = OUT / 'context-public-review-425.json'
    assert not output.exists()
    save(output, dict(status='passed', cases=len(cases), families=len(summary['families']),
         summary=bound(summary_path), receipt=bound(receipt_path), runtime=bound(OUT / 'context-runtime-425.json'),
         helper=bound(__file__), complete_case_set_comparison=bound(baseline_path),
         complete_case_log_records_equal=True, frozen_sources_and_binary_unchanged=True,
         artifacts=list(references.values()), value_files=comparisons,
         explicit_expected_value_rows=sum(item['rows'] for item in comparisons),
         envelopes=envelopes, pressure_files=pressure,
         pressure_rows=sum(item['rows'] for item in pressure),
         limitations=['Public output payload formats were reopened by the recorded UAT; this review hashes their bytes and independently checks the recorded value and pressure files.',
                     'The suite is finite local workflow acceptance, not a process RSS ceiling, all-platform claim or speedup measurement.']))
    print(json.dumps(dict(status='passed', cases=len(cases), families=len(summary['families']),
        value_files=len(comparisons), explicit_expected_value_rows=sum(item['rows'] for item in comparisons),
        envelopes=len(envelopes), pressure_files=len(pressure), pressure_rows=sum(item['rows'] for item in pressure))))


if __name__ == '__main__':
    main()
