"""Check the complete lexical inventory against the frozen acceptance source."""
import hashlib
import json
from pathlib import Path
import re

from freeze_native_release_298 import ROOT, OUT, sha, save


def bound(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


worker_path = OUT / 'admitted-context-occurrences-425.json'
worker = json.loads(worker_path.read_text())
frozen_path = OUT / 'context-check-source-425.json'
frozen = json.loads(frozen_path.read_text())['source_sha256']
expected_paths = sorted(str(p.relative_to(ROOT)) for p in (ROOT / 'shardloom-vortex/src').rglob('*.rs'))
rows = worker['files']
assert len({r['relative_path'] for r in rows}) == len(rows)
assert sorted(r['relative_path'] for r in rows) == expected_paths
patterns = worker['patterns']
assert patterns == ['legacy_session', 'VortexSession::default', 'VortexSession::new', 'VortexSession::empty', 'create_execution_ctx']
current, updated = [], []
counts = dict.fromkeys(patterns, 0)
old_counts = dict.fromkeys(patterns, 0)
old_lines = 0
for row in rows:
    name = row['relative_path']
    path = ROOT / name
    assert not path.is_symlink()
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    assert digest == frozen[name] == sha(path)
    matches = []
    for number, line in enumerate(raw.decode().splitlines(), 1):
        literals = {pattern: len(re.findall(r'\b' + re.escape(pattern) + r'\b', line)) for pattern in patterns}
        literals = {pattern: count for pattern, count in literals.items() if count}
        if literals:
            matches.append(dict(line=number, text=line, matching_patterns=list(literals), literal_counts=literals))
            for pattern, n in literals.items():
                counts[pattern] += n
    for old in row['matching_lines']:
        assert old['matching_patterns'] == [p for p in patterns if p in old['text']]
        assert old['literal_counts'] == {p: old['text'].count(p) for p in old['matching_patterns']}
        for pattern, n in old['literal_counts'].items():
            old_counts[pattern] += n
    old_lines += len(row['matching_lines'])
    if digest == row['sha256']:
        assert len(raw) == row['size_bytes'] and matches == row['matching_lines'], name
    else:
        updated.append(dict(path=name, original_sha256=row['sha256'], current_sha256=digest))
    current.append(dict(relative_path=name, sha256=digest, size_bytes=len(raw), matching_lines=matches))
assert {r['path'] for r in updated} == {
    'shardloom-vortex/src/local_primitives.rs',
    'shardloom-vortex/src/local_primitives/admitted_context_tests.rs',
}
assert worker['totals'] == dict(source_file_count=len(rows), matching_line_count=old_lines, literal_occurrence_counts=old_counts)
result = dict(status='passed', worker_inventory=bound(worker_path), frozen_source=bound(frozen_path),
    unchanged_files_verified=len(rows) - len(updated), updated_after_worker=updated,
    update_reason='Primary added a private codes/nulls alias and completed FSST/test-helper cases; these two current files are fully re-enumerated and match the frozen gate source.',
    totals=dict(source_file_count=len(current), matching_line_count=sum(len(r['matching_lines']) for r in current), literal_occurrence_counts=counts),
    files=current, helper=bound(__file__),
    token_boundary='Whole identifier matches; ResidentVortexSession::new is not VortexSession::new.',
    limit='Literal complete-source evidence only. Production ownership classifications require the separately recorded primary source review; not a global allocation guarantee.')
save(OUT / 'admitted-context-inventory-primary-425.json', result)
print(json.dumps(dict(status='passed', totals=result['totals'], updated=updated)))
