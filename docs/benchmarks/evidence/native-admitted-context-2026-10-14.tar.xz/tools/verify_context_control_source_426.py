"""Read-only proof binding the selected native-source manifest to one Git tree."""
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
MANIFEST_NAME = 'selection-resources-409-release.json'
ACCEPTED_COMMIT = '22b2cde04973ce4462517d73fe67b5f7a1e8177c'
OUTPUT_NAME = 'context-control-source-426.json'
CHUNK_BYTES = 1024 * 1024


def sha256_file(path):
    """Hash a file incrementally; callers use this read-only for the retained binary."""
    digest = hashlib.sha256()
    size = 0
    with Path(path).open('rb') as source:
        while True:
            chunk = source.read(CHUNK_BYTES)
            if not chunk:
                break
            size += len(chunk)
            digest.update(chunk)
    return dict(path=str(path), bytes=size, sha256=digest.hexdigest())


def read_json(path):
    return json.loads(Path(path).read_text())


def is_native_source(path):
    # Keep the original 419 native-source selector exactly.
    return (
        path.endswith('.rs')
        or path.endswith('Cargo.toml')
        or path == 'Cargo.lock'
        or path.startswith(('.cargo/', 'vendor/'))
    )


def git_native_paths(commit):
    output = subprocess.check_output(
        ['git', 'ls-tree', '-r', '--name-only', commit],
        cwd=ROOT,
    )
    return {
        path.decode('utf-8')
        for path in output.splitlines()
        if is_native_source(path.decode('utf-8'))
    }


def check_git_blobs(commit, paths, expected_by_path):
    """Hash each selected Git blob via cat-file --batch without retaining blob contents."""
    process = subprocess.Popen(
        ['git', 'cat-file', '--batch'],
        cwd=ROOT,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    checked = []
    mismatches = []
    try:
        for path in sorted(paths):
            process.stdin.write(f'{commit}:{path}\n'.encode('utf-8'))
            process.stdin.flush()
            header = process.stdout.readline().decode('ascii', errors='replace').strip().split()
            if len(header) != 3 or header[1] != 'blob':
                mismatches.append(dict(path=path, error='missing or non-blob', header=header))
                continue
            git_blob, _kind, size_text = header
            size = int(size_text)
            digest = hashlib.sha256()
            remaining = size
            while remaining:
                chunk = process.stdout.read(min(CHUNK_BYTES, remaining))
                if not chunk:
                    raise AssertionError(f'truncated cat-file blob for {path}')
                digest.update(chunk)
                remaining -= len(chunk)
            if process.stdout.read(1) != b'\n':
                raise AssertionError(f'missing cat-file delimiter for {path}')
            actual = digest.hexdigest()
            record = dict(
                path=path,
                git_blob=git_blob,
                bytes=size,
                sha256=actual,
                manifest_sha256=expected_by_path.get(path),
                matches_manifest=actual == expected_by_path.get(path),
            )
            checked.append(record)
            if not record['matches_manifest']:
                mismatches.append(dict(
                    path=path,
                    expected=expected_by_path.get(path),
                    observed=actual,
                    bytes=size,
                    git_blob=git_blob,
                ))
    finally:
        process.stdin.close()
        stderr = process.stderr.read().decode('utf-8', errors='replace')
        returncode = process.wait(timeout=120)
    if returncode != 0:
        mismatches.append(dict(error='git cat-file failed', returncode=returncode, stderr=stderr))
    return checked, mismatches


def main():
    manifest_path = OUT / MANIFEST_NAME
    manifest = read_json(manifest_path)
    assert manifest['status'] == 'passed'
    assert manifest['build_profile'] == 'release'

    source_binding = manifest['source_manifest']
    source_manifest_path = Path(source_binding['path'])
    source_manifest_identity = sha256_file(source_manifest_path)
    assert source_manifest_identity['sha256'] == source_binding['sha256']
    source_manifest = read_json(source_manifest_path)
    assert source_manifest['head'] == manifest['head']
    source_map = source_manifest['source_sha256']
    assert source_map == manifest['source_sha256']

    build_receipt_path = Path(manifest['cli']['build_receipt'])
    build_receipt_identity = sha256_file(build_receipt_path)
    assert build_receipt_identity['sha256'] == manifest['cli']['build_receipt_sha256']
    build_receipt = read_json(build_receipt_path)
    assert build_receipt['status'] == 'passed'
    assert build_receipt['returncode'] == 0
    assert build_receipt['process_group_drained'] is True
    assert build_receipt['direct_child_reaped'] is True
    assert build_receipt['timed_out'] is False
    assert build_receipt['interrupted_signal'] is None
    assert build_receipt['group_absence_unproved_at_cleanup'] is False
    command = build_receipt['command']
    assert command[:2] == ['cargo', 'build']
    assert '--release' in command and '--locked' in command and '--offline' in command
    assert 'release-user-surfaces' in command
    assert build_receipt['head'] == manifest['head']
    build_log_path = Path(manifest['cli']['build_log'])
    build_log_identity = sha256_file(build_log_path)
    assert build_log_identity['sha256'] == build_receipt['log_sha256']

    binary_path = Path(manifest['cli']['path'])
    # This is a read-only 75 MB digest; the verifier never executes the binary.
    observed_binary = sha256_file(binary_path)
    recorded_binary = {
        'path': manifest['cli']['path'],
        'bytes': manifest['cli']['bytes'],
        'sha256': manifest['cli']['sha256'],
    }
    binary_matches_manifest = (
        observed_binary['bytes'] == recorded_binary['bytes']
        and observed_binary['sha256'] == recorded_binary['sha256']
    )

    selected = {
        path: digest for path, digest in source_map.items() if is_native_source(path)
    }
    git_paths = git_native_paths(ACCEPTED_COMMIT)
    selected_paths = set(selected)
    selected_paths_not_in_git_tree = sorted(selected_paths - git_paths)
    git_paths_missing_from_manifest = sorted(git_paths - selected_paths)
    checked, blob_mismatches = check_git_blobs(
        ACCEPTED_COMMIT,
        selected_paths,
        selected,
    )
    path_set_matches = not selected_paths_not_in_git_tree and not git_paths_missing_from_manifest
    all_blobs_match = not blob_mismatches and len(checked) == len(selected)
    passed = path_set_matches and all_blobs_match and binary_matches_manifest

    excluded_nonnative_paths = sorted(
        path for path in source_map if not is_native_source(path)
    )
    result = dict(
        status='passed' if passed else 'mismatch',
        accepted_commit=ACCEPTED_COMMIT,
        accepted_tree=subprocess.check_output(
            ['git', 'rev-parse', ACCEPTED_COMMIT + '^{tree}'],
            cwd=ROOT,
            text=True,
        ).strip(),
        manifest=sha256_file(manifest_path),
        source_manifest=dict(
            recorded_sha256=source_binding['sha256'],
            observed=source_manifest_identity,
            source_file_count=len(source_map),
            source_head=source_manifest['head'],
        ),
        build_receipt=dict(
            recorded_sha256=manifest['cli']['build_receipt_sha256'],
            observed=build_receipt_identity,
            status=build_receipt['status'],
            command=command,
            returncode=build_receipt['returncode'],
            process_group_drained=build_receipt['process_group_drained'],
            direct_child_reaped=build_receipt['direct_child_reaped'],
            timed_out=build_receipt['timed_out'],
            interrupted_signal=build_receipt['interrupted_signal'],
            group_absence_unproved_at_cleanup=build_receipt['group_absence_unproved_at_cleanup'],
            seconds=build_receipt['seconds'],
        ),
        build_log=dict(
            path=str(build_log_path),
            receipt_sha256=build_receipt['log_sha256'],
            observed=build_log_identity,
        ),
        recorded_binary=recorded_binary,
        observed_binary=observed_binary,
        binary_matches_manifest=binary_matches_manifest,
        native_selector='path.endswith(".rs") or path.endswith("Cargo.toml") or path == "Cargo.lock" or path.startswith((".cargo/", "vendor/"))',
        selected_native_path_count=len(selected_paths),
        git_native_path_count=len(git_paths),
        exact_selected_path_set_matches_git_tree=path_set_matches,
        selected_paths_not_in_git_tree=selected_paths_not_in_git_tree,
        git_native_paths_missing_from_manifest=git_paths_missing_from_manifest,
        checked_native_file_count=len(checked),
        all_native_blobs_match=all_blobs_match,
        native_source_files=checked,
        mismatches=blob_mismatches,
        excluded_nonnative_manifest_paths=excluded_nonnative_paths,
        scope='Native-source identity proof against one accepted Git tree. It does not establish whole-Python or whole-manifest equality.',
        native_workload_executed=False,
        verifier=sha256_file(__file__),
    )

    output_path = OUT / OUTPUT_NAME
    with output_path.open('x') as output:
        json.dump(result, output, indent=2)
        output.write('\n')

    print(json.dumps(dict(
        status=result['status'],
        accepted_commit=ACCEPTED_COMMIT,
        selected_native_path_count=len(selected_paths),
        checked_native_file_count=len(checked),
        exact_selected_path_set_matches_git_tree=path_set_matches,
        all_native_blobs_match=all_blobs_match,
        binary_matches_manifest=binary_matches_manifest,
        mismatch_count=len(blob_mismatches),
        native_workload_executed=False,
    )))
    assert passed, 'context-control source proof found a mismatch'


if __name__ == '__main__':
    main()

