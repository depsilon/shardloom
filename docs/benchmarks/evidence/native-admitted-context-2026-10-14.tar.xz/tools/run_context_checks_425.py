"""Freeze source and run the required sequential native helper acceptance gates."""
import json
from pathlib import Path
import re
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sources, sha, save

BASE = '22b2cde04973ce4462517d73fe67b5f7a1e8177c'
SOURCE = OUT / 'context-check-source-425.json'
PRIOR = OUT / 'decoder-checks-418.json'
HELPERS = ('run_context_checks_425.py', 'run_guarded.py', 'freeze_native_release_298.py')
CHECKS = [
    ('fmt', 180, ['cargo', 'fmt', '--all', '--', '--check']),
    ('read-clippy', 1200, ['cargo', 'clippy', '--offline', '--locked', '-p', 'shardloom-vortex',
        '-p', 'shardloom-cli', '--all-targets', '--features', 'vortex-local-primitives', '--', '-D', 'warnings']),
    ('release-clippy', 1200, ['cargo', 'clippy', '--offline', '--locked', '-p', 'shardloom-vortex',
        '-p', 'shardloom-cli', '--all-targets', '--features', 'release-user-surfaces', '--', '-D', 'warnings']),
    ('workspace-clippy', 1200, ['cargo', 'clippy', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('workspace-tests', 1800, ['cargo', 'test', '--workspace', '--all-targets', '--', '--test-threads=2']),
    ('native-tests', 3600, ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-vortex',
        '-p', 'shardloom-cli', '--all-targets', '--features',
        'vortex-local-primitives,vortex-write,universal-format-io', '--', '--test-threads=2']),
]


def bound(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def read(path):
    return json.loads(Path(path).read_text())


def head():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()


def unchanged(frozen):
    assert head() == frozen['head'] == BASE
    assert sources() == frozen['source_sha256'], 'source changed during acceptance'
    assert all(bound(OUT / name) == identity for name, identity in frozen['helpers'].items())
    assert bound(PRIOR) == frozen['prior_decoder_acceptance']
    assert sha(ROOT / '.github/workflows/ci.yml') == frozen['workflow_sha256']


def inspect_tests(item, native, frozen):
    raw = Path(item['log']['path']).read_text()
    groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', raw)
    assert groups and all(int(row[1]) == int(row[3]) == int(row[4]) == 0 for row in groups)
    ignored = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', raw, re.M)
    expected = []
    if native:
        prior = read(PRIOR)
        assert prior['status'] == 'passed' and prior['runtime_source_unchanged']
        native_gate, = [row for row in prior['completed'] if row['name'] == 'native-tests']
        expected = native_gate['tests']['ignored_evidence']
    assert sum(int(row[2]) for row in groups) == len(ignored)
    assert sorted(ignored) == sorted((row['test'], row['reason']) for row in expected)
    evidence = []
    for test, reason in ignored:
        entry, = [row for row in expected if (row['test'], row['reason']) == (test, reason)]
        name = entry['source']
        assert sha(ROOT / name) == frozen['source_sha256'][name]
        lines = (ROOT / name).read_text().splitlines()
        positions = [i for i, line in enumerate(lines) if re.search(r'\bfn ' + re.escape(test.split('::')[-1]) + r'\(', line)]
        position, = positions
        declaration = lines[max(0, position - 6):position + 1]
        assert any(reason in line for line in declaration) and any('ignore' in line for line in declaration)
        evidence.append(dict(test=test, reason=reason, source=name, line=position + 1,
            source_sha256=frozen['source_sha256'][name], declaration=declaration))
    item['tests'] = dict(passed=sum(int(row[0]) for row in groups), failed=0,
        ignored=len(ignored), groups=len(groups), ignored_evidence=evidence)


def main():
    assert head() == BASE
    assert not SOURCE.exists()
    frozen = dict(head=BASE, source_sha256=sources(),
        helpers={name: bound(OUT / name) for name in HELPERS},
        prior_decoder_acceptance=bound(PRIOR),
        workflow_sha256=sha(ROOT / '.github/workflows/ci.yml'))
    save(SOURCE, frozen)
    unchanged(frozen)
    save(OUT / 'context-check-protocol-425.json', dict(
        checks=CHECKS, source=bound(SOURCE), prior_exclusions=bound(PRIOR),
        scope='Final combined decoder/context source; no vendor or dependency edit. All gates sequential and guarded.'))
    completed, failure = [], None
    try:
        for label, timeout, command in CHECKS:
            unchanged(frozen)
            name = f'native-context-{label}-425'
            print(json.dumps(dict(stage=label, status='starting')), flush=True)
            subprocess.run([sys.executable, '-B', str(OUT / 'run_guarded.py'), '--name', name,
                '--timeout', str(timeout), '--', *command], cwd=ROOT, check=True)
            path = OUT / (name + '.json')
            value = read(path)
            log = path.with_suffix('.log')
            assert value['status'] == 'passed' and value['returncode'] == 0
            assert value['process_group_drained'] and value['direct_child_reaped']
            assert value['head'] == BASE and value['cwd'] == str(ROOT)
            assert value['command'] == command and value['log_sha256'] == sha(log)
            item = dict(name=label, command=command, receipt=bound(path), log=bound(log), seconds=value['seconds'])
            if label.endswith('tests'):
                inspect_tests(item, label == 'native-tests', frozen)
            completed.append(item)
            unchanged(frozen)
            print(json.dumps(dict(stage=label, status='passed', tests=item.get('tests', {}).get('passed'))), flush=True)
    except BaseException as error:
        failure = f'{type(error).__name__}: {error}'
        raise
    finally:
        save(OUT / 'context-checks-425.json', dict(status='passed' if failure is None else 'failed',
            source_manifest=str(SOURCE), source_manifest_sha256=sha(SOURCE),
            source_files=len(frozen['source_sha256']), runtime_source_unchanged=sources() == frozen['source_sha256'],
            completed=completed, failure=failure))
    print(json.dumps(dict(status='passed', gates=len(completed), tests=[
        dict(name=row['name'], **{key:value for key,value in row['tests'].items() if key != 'ignored_evidence'})
        for row in completed if 'tests' in row])), flush=True)


if __name__ == '__main__':
    main()
