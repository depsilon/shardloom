"""Copy verified completed packets and losslessly compress their manifest bytes."""
import hashlib
import json
import lzma
from pathlib import Path
import shutil

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
DEST = ROOT / 'docs/benchmarks/evidence'
PACKETS = (
    ('decoder-rejected-evidence-418', 'native-decoder-rejected-2026-10-14', 7874,
     '128bf08a15be2c5bd1f586041d4ee8447ce2a8f008cd599fa89019d1ede1419f',
     '95bbdff7648e7a890edf60c2aa2aeca7c1d034d283f8113c51a7af81db3a0438'),
    ('decoder-resources-evidence-421', 'native-decoder-scratch-2026-10-14', 10351,
     'e2e9c4137680c1373679745c82fb562668bca3c4fb42cef37589b048782a7d49',
     '3dfe0e16dec46fe47d99c3ace8b81fe42d5913333658d818aad934369eaa3854'),
    ('composition-attribution-evidence-423', 'native-composition-attribution-2026-10-14', 1725,
     '7d5c2fb482f81532093e48aab5bafafec2602dfd865c5f8736c25b8c534d73b6',
     'dc902131894c1476d6360e5fca90abc00d09ad0dc06543c6aec244a749588c6f'),
)


def identity(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def write(path, raw):
    with path.open('xb') as stream:
        stream.write(raw)
    assert path.read_bytes() == raw
    return identity(path)


def main():
    assert shutil.disk_usage(DEST).free >= 12 * (1 << 30)
    assert str(DEST).startswith('/Users/dylan/.codex/worktrees/')
    assert not (OUT / 'completed-evidence-copy-426.json').exists()
    packets, total = [], 0
    for source, destination, count, archive_sha, manifest_sha in PACKETS:
        for suffix in ('.tar.xz', '.manifest.json.xz', '.verification.json'):
            assert not (DEST / (destination + suffix)).exists()
        archive = OUT / (source + '.tar.xz')
        manifest = OUT / (source + '.manifest.json')
        verification = OUT / (source + '.verification.json')
        original = {name: identity(path) for name, path in (
            ('archive', archive), ('manifest', manifest), ('verification', verification))}
        assert original['archive']['sha256'] == archive_sha
        assert original['manifest']['sha256'] == manifest_sha
        checked = json.loads(verification.read_text())
        inventory = json.loads(manifest.read_text())
        assert checked['status'] == inventory['status'] == 'passed'
        assert checked['all_members_reopened'] is True
        assert checked['member_count'] == inventory['member_count'] == len(inventory['members']) == count
        assert checked['archive_sha256'] == archive_sha and checked['manifest_sha256'] == manifest_sha
        assert checked['archive_bytes'] == original['archive']['bytes']
        raw_manifest = manifest.read_bytes()
        assert len(raw_manifest) < 8 * (1 << 20)
        compressed = lzma.compress(raw_manifest, preset=6)
        assert lzma.decompress(compressed) == raw_manifest
        copied = dict(
            archive=write(DEST / (destination + '.tar.xz'), archive.read_bytes()),
            manifest=write(DEST / (destination + '.manifest.json.xz'), compressed),
            verification=write(DEST / (destination + '.verification.json'), verification.read_bytes()))
        assert copied['archive']['sha256'] == archive_sha
        assert copied['verification']['sha256'] == original['verification']['sha256']
        assert lzma.decompress(Path(copied['manifest']['path']).read_bytes()) == raw_manifest
        assert all(identity(item['path']) == item for item in original.values())
        total += sum(item['bytes'] for item in copied.values())
        assert total < 20 * (1 << 20)
        packets.append(dict(name=destination, originals=original, copied=copied,
            members=count, original_manifest_bytes_preserved=True,
            archive_verification='Prior complete member reopening remains bound to unchanged archive and manifest hashes. This copy verifies every copied archive byte without rerunning native workloads.'))
    result = dict(status='passed', packets=packets, copied_bytes=total, helper=identity(__file__),
        native_workload_executed=False, originals_removed=False)
    write(OUT / 'completed-evidence-copy-426.json', (json.dumps(result, indent=2) + '\n').encode())
    print(json.dumps(dict(status='passed', packets=len(packets), copied_bytes=total)))


if __name__ == '__main__':
    main()
