"""Prepare explicit session bindings for the already inspected caller roots."""
import difflib
import re
from prepare_context_signatures_423 import PATH, NEW, EXISTING, masked, functions, close, append_argument

OWNED = set('''
execute_vortex_local_primitive_row_export_enabled
execute_vortex_local_structured_binary_row_export_enabled
execute_vortex_local_pivot_row_export_enabled
read_local_vortex_scan read_local_vortex_partitioned_scan
read_local_vortex_distinct_scan read_local_vortex_drop_duplicate_scan
read_local_vortex_duplicate_mask_scan read_local_vortex_sample_scan
read_local_vortex_expression_project_scan read_local_vortex_melt_scan
read_local_vortex_pivot_scan read_local_vortex_explode_scan
read_local_vortex_rolling_window_scan read_local_vortex_sort_rows_partitioned_scan
'''.split())
BORROWED={'read_opened_local_vortex_sort_rows_scan_with_output',
          'materialize_opened_vortex_sort_output_rows_by_source_ordinals'}
SCALAR={'read_lowered_vortex_simple_aggregate_scan', 'read_local_vortex_simple_aggregate_partitioned_scan'}
PARAMETER={'update_grouped_exact_states_from_chunk'}


def main():
    text=PATH.read_text(); code=masked(text); rows=functions(text,code)
    edits=[]; bindings={}; targets=NEW|EXISTING|PARAMETER
    for row in rows:
        name=row['name']; body=text[row['body']:row['end']]
        if name in OWNED:
            session=re.search(r'(?m)^(\s*)let \(session, (?:_control_memory|control_memory)\) = [^;]+;\n',body)
            if not session:
                assert name=='read_local_vortex_scan' and 'prepared_scan::read(' in body
                continue
            assert 'let mut ctx =' not in body
            at=row['body']+session.end()
            edits.append((at,at,session[1]+'let mut ctx = native_numeric_execution_ctx(&session);\n'))
            bindings[row['start']]='&mut ctx'
        elif name in BORROWED:
            assert 'session: &vortex::session::VortexSession' in text[row['left']:row['right']]
            at=row['body']+1
            edits.append((at,at,'\n    let mut ctx = native_numeric_execution_ctx(session);'))
            bindings[row['start']]='&mut ctx'
        elif name in SCALAR:
            assert 'let mut scalar_execution_ctx =' in body
            bindings[row['start']]='&mut scalar_execution_ctx'
        elif name in PARAMETER:
            assert 'ctx: &mut vortex::array::ExecutionCtx' in text[row['left']:row['right']]
            bindings[row['start']]='ctx'
    starts={r['left'] for r in rows}
    for m in re.finditer(r'\b('+'|'.join(sorted(targets))+r')\s*\(', code):
        left=m.end()-1
        if left in starts: continue
        owners=[r for r in rows if r['body']<left<r['end']]
        if not owners: continue
        row=min(owners,key=lambda r:r['end']-r['body'])
        arg=bindings.get(row['start'])
        if not arg: continue
        right=close(code,left)
        assert not re.search(r'\b(?:ctx|scalar_execution_ctx)\s*,?$',text[left+1:right].rstrip())
        edits.append(append_argument(text,left,right,arg))
    updated=text
    for start,end,replacement in sorted(edits,reverse=True):
        updated=updated[:start]+replacement+updated[end:]
    diff=''.join(list(difflib.unified_diff(text.splitlines(True),updated.splitlines(True),n=3))[2:])
    diff=re.sub(r'^@@ -\d+(?:,\d+)? \+\d+(?:,\d+)? @@$', '@@', diff, flags=re.M)
    print('*** Begin Patch\n*** Update File: '+str(PATH)+'\n'+diff+'*** End Patch')


if __name__=='__main__': main()
