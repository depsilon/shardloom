"""Package the final combined correction after all declared acceptance gates pass."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile

from package_selection_acceptance_409 import Members, need, receipt_pair, sha_file, sha_stream, verify
from freeze_native_release_298 import sources

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
BASE = '22b2cde04973ce4462517d73fe67b5f7a1e8177c'
OUTPUTS = tuple(OUT / ('context-resources-evidence-426.' + suffix)
                for suffix in ('tar.xz', 'manifest.json', 'verification.json'))
LIMIT = 192 << 20


def read(path):
    return json.loads(Path(path).read_text())


def bound(path):
    size, digest = verify(Path(path))
    return dict(path=str(path), bytes=size, sha256=digest)


def add_bound(members, item, prefix, role):
    path = Path(item['path'])
    relative = (path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT)
                else path.relative_to(OUT).as_posix() if path.is_relative_to(OUT)
                else path.name)
    members.add(path, prefix + '/' + relative, 'evidence', path.parent,
                role, item['sha256'], item.get('bytes'))


def main():
    partials = tuple(path.with_name('.' + path.name + '.partial') for path in OUTPUTS)
    for path in (*OUTPUTS, *partials):
        need(not path.exists() and not path.is_symlink(), f'output exists: {path}')
    required = [
        'context-after-runtime-426.json', 'context-checks-425.json',
        'context-resources-425-release.json', 'context-native-artifacts-425.json',
        'context-direct-425.json', 'context-runtime-425.json', 'context-public-review-425.json',
        'context-paired-result-426.json', 'context-paired-driver-426.json',
        'context-control-source-426.json', 'context-source-delta-426.json',
        'admitted-context-inventory-primary-425.json', 'completed-evidence-copy-426.json',
    ]
    reports = {name: read(OUT / name) for name in required}
    need(all(value['status'] == 'passed' for value in reports.values()), 'acceptance incomplete')
    source_path = OUT / 'context-check-source-425.json'
    source = read(source_path)
    accepted = source['source_sha256']
    need(source['head'] == BASE and len(accepted) == 2245, 'unexpected source scope')
    need(sources() == accepted, 'current source changed after acceptance')
    release = reports['context-resources-425-release.json']
    native = reports['context-native-artifacts-425.json']
    need(release['source_sha256'] == native['source_sha256'] == accepted,
         'builds disagree with frozen source')
    checks = reports['context-checks-425.json']
    need(checks['runtime_source_unchanged'] and len(checks['completed']) == 6,
         'required validation gates incomplete')
    test_counts = {row['name']: row['tests'] for row in checks['completed'] if 'tests' in row}
    need(test_counts['workspace-tests']['passed'] == 3219 and test_counts['workspace-tests']['ignored'] == 0,
         'workspace test scope changed')
    need(test_counts['native-tests']['passed'] == 4200 and test_counts['native-tests']['ignored'] == 28,
         'native test scope changed')
    direct = reports['context-direct-425.json']
    need(direct['tests'] == 80 and direct['failures'] == direct['errors'] == direct['skipped'] == 0,
         'direct binding acceptance incomplete')
    runtime = reports['context-runtime-425.json']
    need(runtime['public_cases'] == 757 and len(runtime['public_families']) == 19,
         'public workflow coverage incomplete')
    public = reports['context-public-review-425.json']
    need(public['cases'] == 757 and public['families'] == 19
         and public['complete_case_log_records_equal'], 'public evidence not reopened')
    paired = reports['context-paired-result-426.json']
    need(paired['total_complete_calls'] == 516 and paired['candidate_complete_calls'] == 258
         and paired['candidate_complete_result_rows'] == 2286 and not paired['repeated_metric_increases'],
         'complete paired acceptance missing or cost threshold repeated')
    frozen = read(OUT / 'context-paired-frozen-426.json')
    need(paired['frozen'] == bound(OUT / 'context-paired-frozen-426.json'), 'paired freeze changed')
    need(frozen['active_workspace_sources'] == accepted, 'paired source differs from gates')
    need([row['order'] for row in paired['cohorts']] == ['forward', 'reverse'], 'both orders required')
    need(all(row['status'] == 'passed' and row['complete_calls'] == 258
         and row['complete_result_rows'] == 2286 for row in paired['cohorts']), 'incomplete paired cohort')
    control = reports['context-control-source-426.json']
    need(control['accepted_commit'] == BASE and control['exact_selected_path_set_matches_git_tree']
         and control['all_native_blobs_match'] and control['binary_matches_manifest'], 'control source unproven')

    members, exclusions = Members(), []
    for name in required + [
        'context-check-protocol-425.json', 'context-check-source-425.json',
        'context-resources-425-source.json', 'context-runtime-protocol-426.json',
        'context-paired-plan-426.json', 'context-paired-frozen-426.json',
        'context-paired-forward-review-426.json', 'context-paired-reverse-review-426.json',
    ]:
        members.add(OUT / name, 'acceptance/' + name, 'evidence', OUT, 'acceptance or source record')
    for name in ('context-check-source-425.json', 'context-runtime-protocol-426.json'):
        for item in read(OUT / name)['helpers'].values():
            add_bound(members, item, 'tools', 'frozen executed helper')
    for item in frozen['helpers'].values():
        add_bound(members, item, 'tools', 'frozen paired helper')
    for item in frozen['prerequisites'].values():
        add_bound(members, item, 'acceptance', 'paired prerequisite')
    for item in frozen['manifests'].values():
        add_bound(members, item, 'builds', 'frozen executable manifest')
    for item in (frozen['source_proof'], frozen['route_reference'], frozen['plan'],
                 frozen['reference'], frozen['queries']):
        add_bound(members, item, 'paired-inputs', 'frozen query or source proof')
    for role in frozen['build_evidence'].values():
        for item in role.values():
            add_bound(members, item, 'builds', 'frozen source/build evidence')
    for item in checks['completed']:
        add_bound(members, item['receipt'], 'guards', 'source-bound broad receipt')
        add_bound(members, item['log'], 'guards', 'source-bound broad log')
        receipt_pair(Path(item['receipt']['path']), members, 'guards', 'passed')
    for record in (release['cli'], native['binding'], frozen['binaries']['control']):
        verify(Path(record['path']), record['sha256'], record['bytes'])
        exclusions.append(dict(**record, reason='verified executable identity; bulk binary payload excluded'))
    exclusions.append(dict(**frozen['source'], reason='retained Vortex input; fully hashed by closed comparison, not copied or rehashed by this packaging step'))

    history = sorted(path for path in OUT.glob('admitted-context-*.json')
                     if re.search(r'-(423|424|425)\.json$', path.name))
    need(len(history) >= 20, 'context development evidence is incomplete')
    for path in history:
        report = read(path)
        if 'process_group_drained' in report and 'command' in report:
            receipt_pair(path, members, 'history')
        else:
            members.add(path, 'history/' + path.name, 'evidence', OUT, 'development history or source inventory')
    for name, key in (('admitted-context-red-source-423.json', 'snapshot'),
                      ('admitted-context-nested-red-source-424.json', 'snapshots')):
        for item in read(OUT / name)[key]:
            path = Path(item['snapshot'])
            members.add(path, 'history/sources/' + path.relative_to(OUT).as_posix(),
                        'evidence', OUT, 'frozen regression source before correction', item['sha256'], item['bytes'])
    delta = reports['context-source-delta-426.json']
    need(delta['base_commit'] == BASE and delta['source_unchanged'], 'final source overlay missing')
    names = sorted(item['path'] for item in delta['changed_source_paths'])
    changed = subprocess.check_output(['git', 'diff', '--name-only', BASE], cwd=ROOT, text=True).splitlines()
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=ROOT, text=True).splitlines()
    need(names == sorted(set(changed + untracked) & set(accepted)), 'final source overlay path set differs')
    for item in delta['changed_source_paths']:
        need(item['sha256'] == accepted[item['path']], 'source overlay digest differs')
        verify(ROOT / item['path'], item['sha256'], item['bytes'])
        members.add(Path(item['snapshot']), 'source-overlay/' + item['path'],
                    'evidence', OUT, 'complete accepted source overlay', item['sha256'], item['bytes'])
    add_bound(members, delta['tracked_patch'], 'source-overlay', 'tracked diff; new files separately retained')
    for name in ('prepare_context_roots_423.py', 'prepare_context_signatures_423.py',
                 'verify_admitted_context_inventory_425.py', 'copy_completed_evidence_426.py',
                 'package_selection_acceptance_409.py', 'package_context_acceptance_426.py'):
        members.add(OUT / name, 'tools/' + name, 'support', OUT, 'development or packaging helper')
    for pattern in ('native-context-*.json', 'context-paired-forward-426.json',
                    'context-paired-reverse-426.json', 'completed-evidence-copy-run-426.json'):
        for path in sorted(OUT.glob(pattern)):
            report = read(path)
            if 'process_group_drained' in report and 'command' in report:
                receipt_pair(path, members, 'guards', 'passed')

    members.tree(OUT / 'context-public-425', 'public', 'public',
                 'complete public logs, summaries and value evidence', exclusions, omit_outputs=True)
    for key in ('artifacts', 'value_files', 'envelopes', 'pressure_files'):
        for item in public[key]:
            verify(Path(item['path']), item['sha256'], item['bytes'])
    add_bound(members, public['complete_case_set_comparison'], 'public-inputs', 'unchanged public case inventory')
    for order in paired['cohorts']:
        for item in (order['summary'], order['receipt'], *order['reopened_archives']):
            verify(Path(item['path']), item['sha256'], item['bytes'])
        members.tree(Path(order['summary']['path']).parent, 'paired/' + order['order'],
                     'paired', 'complete paired raw results, metrics and companions', exclusions)
    companions = []
    for item in reports['completed-evidence-copy-426.json']['packets']:
        for key, identity in item['copied'].items():
            verify(Path(identity['path']), identity['sha256'], identity['bytes'])
        companions.append(dict(name=item['name'], members=item['members'], files=item['copied'],
            scope='Separately committed immutable decoder-only or historical-composition packet; not duplicated inside this archive'))

    ordered = sorted(members.paths.values(), key=lambda item: item.name)
    raw_bytes = sum(item.size for item in ordered)
    need(raw_bytes <= LIMIT, 'archive exceeds 192 MiB raw-input budget')
    sys.path.insert(0, str(ROOT / 'scripts'))
    from local_uat_storage import GIB, MIB, check_budgets, require_local_path
    require_local_path(OUT, Path.home(), sys.platform)
    storage = check_budgets(OUT, OUTPUTS[0], OUT / 'logs', min_free_bytes=12 * GIB,
        reserve_bytes=raw_bytes + 64 * MIB, max_workspace_bytes=100 * GIB, max_log_bytes=1024 * MIB)
    created, published = [], []
    try:
        with partials[0].open('xb') as output:
            created.append(partials[0])
            with tarfile.open(fileobj=output, mode='w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
                for item in ordered:
                    verify(item.path, item.digest, item.size)
                    info = tarfile.TarInfo(item.name)
                    info.size, info.mode, info.mtime = item.size, 0o644, 0
                    with item.path.open('rb') as stream:
                        archive.addfile(info, stream)
                    verify(item.path, item.digest, item.size)
        seen = set()
        with tarfile.open(partials[0], mode='r|xz') as archive:
            for entry in archive:
                need(entry.isfile() and entry.name in members.names and entry.name not in seen,
                     f'invalid member: {entry.name}')
                item = members.paths[members.names[entry.name]]
                stream = archive.extractfile(entry)
                need(stream is not None, 'missing member bytes')
                need(sha_stream(stream) == (item.size, item.digest), f'archive mismatch: {entry.name}')
                seen.add(entry.name)
        need(seen == set(members.names), 'incomplete archive membership')
        for item in ordered:
            verify(item.path, item.digest, item.size)
        need(sources() == accepted, 'runtime source changed while packaging')
        size, digest = sha_file(partials[0])
        manifest = dict(status='passed', kind='native_admitted_context_and_decoder_acceptance', base_commit=BASE,
            source_manifest=bound(source_path), source_files=len(accepted), changed_source_paths=names,
            archive=dict(path=str(OUTPUTS[0]), bytes=size, sha256=digest),
            members=[dict(path=str(item.path), archive_path=item.name, bytes=item.size,
                          sha256=item.digest, roles=item.roles) for item in ordered],
            member_count=len(ordered), raw_bytes=raw_bytes, raw_limit_bytes=LIMIT, exclusions=exclusions,
            companion_packets=companions,
            acceptance=dict(focused_context_regressions=22, broad_gates=6, workspace_tests=3219,
                native_tests=4200, native_ignored=28, direct_tests=80, public_cases=757, public_families=19,
                paired_complete_calls=516, candidate_full43_calls=258, candidate_full43_rows=2286,
                repeated_cost_breaches=0, prior_decoder_and_composition_evidence_preserved=True),
            order_totals={row['order']: row['totals'] for row in paired['cohorts']},
            storage=storage, all_members_reopened=True, performance_claim_allowed=False,
            hosted_integration_complete=False, publication_attempted=False,
            limitations='Finite local source-package/native acceptance. No installed-wheel, general allocation, process-RSS ceiling, cross-platform, superiority or release-readiness claim. Earlier historical composition cause remains unproven.')
        encoded = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
        verification = dict(status='passed', all_members_reopened=True, member_count=len(seen),
            archive_bytes=size, archive_sha256=digest, manifest_sha256=hashlib.sha256(encoded).hexdigest())
        for temporary, value in zip(partials[1:], (encoded, (json.dumps(verification, indent=2, sort_keys=True) + '\n').encode()), strict=True):
            with temporary.open('xb') as stream:
                created.append(temporary)
                stream.write(value)
        for temporary, output in zip(partials, OUTPUTS, strict=True):
            os.link(temporary, output)
            published.append(output)
            temporary.unlink()
            created.remove(temporary)
        print(json.dumps(dict(status='passed', archive=str(OUTPUTS[0]), members=len(seen),
                             archive_bytes=size, archive_sha256=digest, raw_bytes=raw_bytes)), flush=True)
    except BaseException:
        for path in published:
            path.unlink(missing_ok=True)
        raise
    finally:
        for path in created:
            path.unlink(missing_ok=True)


if __name__ == '__main__':
    main()
