"""Run the frozen merge-tail attribution gates sequentially and preserve each step."""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
DRIVER = OUT / 'merge_tail_driver_771.py'
GUARD = OUT / 'run_guarded_observed_757.py'
ORACLE = OUT / 'analyze_merge_tail_771.py'
PROTOCOL = OUT / 'merge-tail-attribution-protocol-771.json'
PROTOCOL_FREEZE = OUT / 'merge-tail-protocol-freeze-771.json'
LABEL = 'merge-tail-attribution-771-a1'
BUILD = 'merge-tail-build-771-a1'
DATA = OUT / LABEL
BINARY = OUT / f'{LABEL}-test'
PYTHON = sys.executable
ROLES = ('off', 'on')
COHORT_ORDER = (('A', ('off', 'on')), ('B', ('on', 'off')))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def run_step(name, command, freeze_path):
    output = OUT / f'{name}-sequence-output.log'
    record = {'step': name, 'command': command, 'source_freeze_sha256': sha(freeze_path),
              'protocol_sha256': sha(PROTOCOL)}
    print(f'START {name}', flush=True)
    try:
        with output.open('x') as stream:
            code = subprocess.call(command, cwd=REPO, stdout=stream, stderr=subprocess.STDOUT)
        record['returncode'] = code
        record['output_sha256'] = sha(output)
        if code:
            raise RuntimeError(f'{name} failed with exit {code}; see {output}')
    finally:
        save(OUT / f'{name}-sequence-step.json', record)
    print(f'PASS {name}', flush=True)


def guarded(name, command):
    return [PYTHON, '-B', str(GUARD), '--name', name, '--timeout', '1800', '--', *command]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.parse_args()

    freeze_path = OUT / f'{LABEL}-source-freeze.json'
    build_path = OUT / f'{BUILD}.json'
    build = json.loads(build_path.read_text())
    assert build['status'] == 'passed' and build['returncode'] == 0
    assert build['process_group_drained'] is True
    assert sha(OUT / f'{BUILD}.log') == build['log_sha256']
    assert not DATA.exists() and not BINARY.exists()

    identity = {
        'sequence_sha256': sha(__file__), 'driver_sha256': sha(DRIVER),
        'guard_sha256': sha(GUARD), 'oracle_sha256': sha(ORACLE),
        'protocol_sha256': sha(PROTOCOL), 'protocol_freeze_sha256': sha(PROTOCOL_FREEZE),
        'source_freeze_sha256': sha(freeze_path), 'build_receipt_sha256': sha(build_path),
        'label': LABEL, 'build': BUILD,
        'preflight_roles': list(ROLES),
        'cohort_order': [{'cohort': cohort, 'roles': list(roles)} for cohort, roles in COHORT_ORDER],
        'decision_policy': 'Complete and independently validate preflight first; finish both measured cohorts before decision analysis.',
    }
    identity_path = OUT / f'{LABEL}-sequence-identity.json'
    preflight_path = OUT / f'{LABEL}-preflight-verification.json'
    decision_path = OUT / f'{LABEL}-decision.json'
    completion_path = OUT / f'{LABEL}-sequence-completion.json'
    assert not identity_path.exists() and not preflight_path.exists()
    assert not decision_path.exists() and not completion_path.exists()
    save(identity_path, identity)

    name = 'merge-tail-bind-771-a1'
    run_step(name, guarded(name, [PYTHON, '-B', str(DRIVER), 'bind',
                                  '--label', LABEL, '--build', BUILD]), freeze_path)

    # Keep the focused lifecycle/correctness guard separate from attribution.
    # It uses the already-bound frozen binary and runs serially under the same
    # process/resource guard as the other bounded checks.
    inventory_path = OUT / f'{LABEL}-test-inventory.txt'
    inventory = inventory_path.read_text().splitlines()
    spill_tests = [line for line in inventory
                   if line.startswith('local_primitives::prepared_relational::tests::spill_tests::')
                   and line.endswith(': test')]
    assert len(spill_tests) == 9, f'expected 9 focused spill tests, got {len(spill_tests)}'
    name = 'merge-tail-focused-spill-771-a1'
    spill_log = OUT / f'{name}.log'
    spill_command = guarded(name, [
        str(BINARY),
        'local_primitives::prepared_relational::tests::spill_tests::', '--nocapture',
        '--test-threads=1'])
    run_step(name, spill_command, freeze_path)
    assert 'test result: ok. 9 passed; 0 failed; 0 ignored;' in spill_log.read_text()

    for role in ROLES:
        name = f'merge-tail-preflight-{role}-771-a1'
        run_step(name, [PYTHON, '-B', str(DRIVER), 'run', '--label', LABEL, '--name', name,
                        '--mode', 'preflight', '--role', role, '--cohort', 'preflight',
                        '--data', LABEL], freeze_path)

    name = 'merge-tail-preflight-check-771-a1'
    run_step(name, guarded(name, [PYTHON, '-B', str(ORACLE), 'preflight',
                                  '--data', str(DATA), '--output', str(preflight_path)]), freeze_path)
    preflight = json.loads(preflight_path.read_text())
    assert preflight['protocol_sha256'] == sha(PROTOCOL)
    assert preflight['preflight_passed'] is True
    assert sum(row['workflows'] for row in preflight['streams'].values()) == 40
    assert sum(row['operations'] for row in preflight['streams'].values()) == 40

    # Cohort B reverses cell order inside the native protocol. Each role is a
    # separate process. No comparative analysis occurs until all four finish.
    for cohort, roles in COHORT_ORDER:
        for role in roles:
            name = f'merge-tail-measure-{cohort}-{role}-771-a1'
            run_step(name, [PYTHON, '-B', str(DRIVER), 'run', '--label', LABEL, '--name', name,
                            '--mode', 'measure', '--role', role, '--cohort', cohort,
                            '--data', LABEL], freeze_path)

    name = 'merge-tail-decision-771-a1'
    run_step(name, guarded(name, [PYTHON, '-B', str(ORACLE), 'decision',
                                  '--data', str(DATA), '--output', str(decision_path)]), freeze_path)
    decision = json.loads(decision_path.read_text())
    assert decision['protocol_sha256'] == sha(PROTOCOL)
    assert decision['scope_result'] in ('material_signal', 'no_signal')

    name = 'merge-tail-final-binding-771-a1'
    run_step(name, [PYTHON, '-B', str(DRIVER), 'verify', '--label', LABEL], freeze_path)
    for key, path in (
        ('sequence_sha256', Path(__file__)), ('driver_sha256', DRIVER), ('guard_sha256', GUARD),
        ('oracle_sha256', ORACLE), ('protocol_sha256', PROTOCOL),
        ('protocol_freeze_sha256', PROTOCOL_FREEZE),
    ):
        assert sha(path) == identity[key]
    completion = {'status': 'completed', 'identity_sha256': sha(identity_path),
                  'decision_sha256': sha(decision_path),
                  'decision_scope_result': decision['scope_result'],
                  'production_optimization': False}
    save(completion_path, completion)
    print('COMPLETE frozen merge-tail attribution sequence.', flush=True)


if __name__ == '__main__':
    main()
