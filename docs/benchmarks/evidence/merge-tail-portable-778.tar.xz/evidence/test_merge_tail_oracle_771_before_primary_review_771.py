import importlib.util
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

SCRIPT = Path(__file__).with_name("analyze_merge_tail_771.py")
SPEC = importlib.util.spec_from_file_location("merge_oracle", SCRIPT)
oracle = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(oracle)


def snap(live, peak, written, validated):
    return {"live_disk_bytes": live, "peak_disk_bytes": peak, "runs_written": written, "runs_validated": validated}


def one_merge_trace(reverse_parents=False, bad_live=False):
    base = snap(0, 0, 0, 0)
    s1 = snap(32868, 32868, 1, 1)
    s2 = snap(32968, 32968, 2, 2)
    sw = snap(33118 + (1 if bad_live else 0), 33118, 3, 3)
    sr = snap(32918, 33118, 3, 3)
    st = snap(32768, 33118, 3, 3)
    zero = snap(0, 33118, 3, 3)
    events = [
        {"event": "owner", "owner": 1, "buffer_bytes": 131072, "block_rows": 4096, "reader_work_bytes": 131072},
        {"event": "leaf", "owner": 1, "run": {"id": "L", "rows": 4096, "bytes": 100, "level": 0, "start": 0, "end": 4096, "block_rows": 4096}, "before": base, "after_write": s1, "elapsed_ns": 1, "readers": 0},
        {"event": "leaf", "owner": 1, "run": {"id": "R", "rows": 4096, "bytes": 100, "level": 0, "start": 4096, "end": 8192, "block_rows": 4096}, "before": s1, "after_write": s2, "elapsed_ns": 2, "readers": 0},
        {"event": "merge", "owner": 1, "phase": "ingest", "left": "R" if reverse_parents else "L", "right": "L" if reverse_parents else "R", "output": {"id": "M", "rows": 8192, "bytes": 150, "level": 1, "start": 0, "end": 8192, "block_rows": 4096}, "before": s2, "after_write": sw, "after_removal": sr, "elapsed_ns": 3, "readers_during_write": 2, "readers_after_removal": 0},
        {"event": "frontier", "owner": 1, "run_ids": ["M"], "snapshot": sr, "readers": 0},
        {"event": "terminal_removal", "owner": 1, "run_id": "M", "before": sr, "after_removal": st, "readers": 0},
        {"event": "cleanup", "before": st, "after": zero, "readers": 0},
    ]
    record = {"role": "on", "spill": True, "rows": 8192, "engine_execution_ns": 100}
    report = {"peak_disk_bytes": 33118, "runs_written": 3, "runs_validated": 3, "merge_passes": 1, "max_open_runs": 2, "run_block_rows": 4096}
    return record, {"enabled": True, "event_limit": 4096, "marker_bytes": 32768, "events": events}, report


def brute_cost(weights):
    if len(weights) <= 1: return 0
    total = sum(weights)
    return total + min(brute_cost(weights[:k + 1]) + brute_cost(weights[k + 1:]) for k in range(len(weights) - 1))


class MergeTailOracleTests(unittest.TestCase):
    def test_protocol_hash_cells_and_profiles(self):
        self.assertEqual(oracle.digest(oracle.PROTOCOL.read_bytes()), oracle.PROTOCOL_SHA256)
        self.assertEqual(len(oracle.matrix()), 16)
        self.assertEqual(oracle.width_for(32767, "quarters_up", 0), 24)
        self.assertEqual(oracle.width_for(32767, "quarters_up", 32766), 512)
        self.assertEqual(oracle.width_for(32767, "wide_head", 0), 512)
        self.assertEqual(oracle.width_for(32767, "wide_tail", 32766), 512)

    def test_interval_dp_matches_enumeration_and_rightmost_direction(self):
        for weights in ([1], [1, 1], [1, 1, 1], [1, 10, 100], [3, 7, 2, 9], [4, 1, 8, 2, 5]):
            tree, cost, right, right_cost = oracle._merge_tree_and_cost(list(weights))
            self.assertEqual(cost, brute_cost(list(weights)))
            self.assertEqual(right_cost, self.rightmost_brute(list(weights)))
            self.assertEqual(cost <= right_cost, True)
        self.assertEqual(oracle._merge_tree_and_cost([100, 10, 1])[2:], ([0, [1, 2]], 122))
        self.assertEqual(oracle._merge_tree_and_cost([1, 10, 100])[:2], ([[0, 1], 2], 122))
        self.assertEqual(oracle._merge_tree_and_cost([1, 1, 1])[:2], ([0, [1, 2]], 5))

    @staticmethod
    def rightmost_brute(weights):
        if len(weights) <= 1: return 0
        return sum(weights) + MergeTailOracleTests.rightmost_brute(weights[1:])

    def test_synthetic_lineage_and_disk_accounting(self):
        rec, obs, report = one_merge_trace()
        rec["observation"] = obs
        trace = oracle.validate_trace(rec, report)
        self.assertEqual(trace["runs_written"], 3)
        self.assertEqual(trace["frontier"][0]["interval"], [0, 8192])
        self.assertEqual(trace["actual_tree"], "M")
        rec, obs, report = one_merge_trace(reverse_parents=True)
        rec["observation"] = obs
        with self.assertRaises(oracle.Invalid): oracle.validate_trace(rec, report)
        rec, obs, report = one_merge_trace(bad_live=True)
        rec["observation"] = obs
        with self.assertRaises(oracle.Invalid): oracle.validate_trace(rec, report)

    def test_bad_witness_identity_hash_and_decoded_content(self):
        with tempfile.TemporaryDirectory() as td:
            data = Path(td)
            (data / "witnesses").mkdir()
            raw = b"[{\"ordinal\":1}]"
            h = hashlib.sha256(raw).hexdigest()
            (data / "witnesses" / f"{h}.json").write_bytes(raw)
            self.assertEqual(oracle.witness(data, h, [{"ordinal": 1}], "ok"), [{"ordinal": 1}])
            with self.assertRaises(oracle.Invalid): oracle.witness(data, h, [{"ordinal": 2}], "wrong value")
            with self.assertRaises(oracle.Invalid): oracle.witness(data, "x" * 64, [], "wrong bytes")
            with self.assertRaises(oracle.Invalid): oracle.witness(data, "not-hash", [], "malformed identity")

    def test_empty_off_and_resident_traces_require_no_events(self):
        record = {"role": "off", "spill": True, "rows": 17, "engine_execution_ns": 10}
        record["observation"] = {"enabled": False, "event_limit": 4096, "marker_bytes": 32768, "events": []}
        self.assertEqual(oracle.validate_trace(record, {"peak_disk_bytes": 0, "runs_written": 0, "runs_validated": 0, "merge_passes": 0, "max_open_runs": 0, "run_block_rows": 0}), {"frontier": [], "dp_tree": None, "dp_cost": 0, "rightmost_tree": None, "rightmost_cost": 0, "tail_time_ns": 0, "tail_input_bytes": 0, "leaf_merge_time_ns": 0})
        record["observation"] = {"enabled": False, "event_limit": 4096, "marker_bytes": 32768, "events": [{"event": "owner"}]}
        with self.assertRaises(oracle.Invalid): oracle.validate_trace(record, {})


if __name__ == "__main__": unittest.main()
