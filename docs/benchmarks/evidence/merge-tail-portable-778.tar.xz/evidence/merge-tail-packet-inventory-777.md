# Merge-tail V4 packet inventory 777

Status: NEEDS_REASONING. This is read-only inventory evidence, not an experiment decision or packaging implementation. Existing V1/V2/V3 evidence is not credited as V4 completion.

## Draft-to-V4 delta

`package_merge_tail_775.py` explicitly packages V1/V2 failures, V3 successful workflow evidence, and historical source reconstruction for 771/773/774. Its claim boundary says “V3 finite attribution only”; the V4 freeze/protocol and debug smoke are absent from its allowlist. `verify_merge_tail_packet_776.py` reconstructs only 771/773/774 and asserts those three frozen source sets. It is not a V4 verifier.

Add V4 protocol and freeze, V4 source freeze and tracked patch, V4 helper set, V4 debug-smoke orchestration/identity/build/artifact/test-inventory/completion/preflight receipts, 40 preflight workflow outputs and sequence records, plus finalized release build/preflight/192 measurement/4 warmup/decision/completion evidence once available. Keep the 776 release build log and all later release-measurement outputs pending until finalized; do not hash as final. V4 debug completion is `passed`, 40 workflows/operations, 9 focused spill tests, zero measured workflows, no decision credit. It establishes only the permitted smoke stage.

## Prior attempts and partial workflows

- V1/771: `merge-tail-protocol-admission-failure-772.json` documents preflight admission failure. `merge-tail-build-771-a1` and the retained focused-spill/preflight attempts are not successful attribution; zero completed workflows and zero decision credit.
- V2/773: `merge-tail-collector-admission-failure-773.json` records the collector cap failure and deliberate build interruption. Zero completed workflows and zero decision credit.
- V3/774: `merge-tail-source-accounting-failure-775.json` records one returned native public operation passing output/schema/certificate checks before a harness accounting assertion; no completed record or measured sample. `merge-tail-storage-admission-failure-775.json` records a separate refusal before child launch. Continuation/review records do not turn either into a completed V3 success packet. Preserve both failure records and prior frozen V1/V2 artifacts.
- Partial workflow files include the 771 bind/focused-spill/preflight attempt; V3 bind, focused-spill a1/a2, preflight-off/on/check, measurement A/B on/off, decision and final binding sequence files; V5 continuation/resume-binding files; and V4 debug bind/build/focused-spill/preflight-off/on/check/final-binding sequence files. The V4 debug artifacts are not the later release experiment.

## V4 frozen helper mapping

The V4 freeze records 39 helpers: 24 investigation-local files and 15 external/worktree files. All 39 literal paths currently exist. The local helpers comprise protocol/freeze, driver, sequence runner, guarded observer, analyzer, oracle test, primary review and oracle log; V1/771 protocol/freeze/failure/preserved V1 design; V2/773 protocol/freeze/failure/preserved V2 design; V3/774 protocol/freeze/source-accounting failure/preserved V3 design; V3 storage refusal; and V4 debug-smoke runner and verifier. The V3 preserved design copy is `merge-tail-design-v3-preserved-776.md`.

The 15 external helpers are the current worktree native merge-tail design; `local_uat_storage.py`; ClickBench paired-query and query UAT runners; `native_workflow_protocol.py`; `query_timing_report.py`; `clickbench_reference_packet.py`; and Python package `__init__.py`, `_exports.py`, `_result_schema.py`, `errors.py`, `_compat.py`, `models.py`; plus the historical release guard and bounded-build-resume helper under LocalData. V4 freeze hashes these helper identities; do not substitute the historical V1/V2/V3 design snapshots for the current worktree design helper. The package’s previous V1/V2/V3 source reconstructions remain historical design copies, distinct from the V4 current frozen helper list.

## Identity and size evidence

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `package_merge_tail_775.py` | 50,930 | `cb21f050fb8554af85a05f4f4e8e16aaeff663dd444fbf1bdff4b161babe9956` |
| `verify_merge_tail_packet_776.py` | 9,641 | `f3d95d621775830f3b8967c4949db283df5e1ba6f826b260023a1a11b8041a80` |
| V4 protocol | 17,254 | `111f66f588ae5f388170ce8b906f80fff21ba64d20e41e59eb7bf3df467fccf7` |
| V4 protocol freeze | 546 | `a020fcb395b7bd3bb54d1b80ee701ef3705878355718a2e8963dfad87defb833` |
| V4 source freeze | 367,098 | `17b8bae4db4247b81b0c130c270b3a600da644ddda12b5aee8a6826086b1e362` |
| V4 debug smoke completion | 667 | `40336610664c8e829fc18572b76236e2513ff12fe59e12c0bcd850f10c945176` |
| V3 source-accounting failure | 6,783 | `585d47be147f4c64b3cd9ac2a924ec017b4b960fb40516eea096186f5dff4b71` |
| V3 storage-admission failure | 3,828 | `2b8cde922bab615d4f2cd7389b1c1f8001c1d753ce4b9a2e529111a82a4d9a65` |

Accepted base identity: `merge-tail-accepted-base-774.json`, 1,899 source rows; corresponding source directory contains 1,899 files / 36,040,004 bytes. V4 frozen source inventory contains 1,901 Rust/Cargo entries. Massive source trees and binary artifacts were not individually enumerated here. V4 local data tree `merge-tail-attribution-776-a1` is presently empty (0 members); do not infer successful workflows from an empty directory.

V4 debug output tree currently has 36 regular files / 136,996,384 bytes. The principal smoke binary is 384,883,552 bytes and must be excluded as compiled artifact; its inventory/receipt may identify it. The current `merge-tail-build-776-a1.log` is explicitly pending and excluded from finalized evidence hashes; future release outputs are pending as well.

## Uncertainties to resolve before packaging

The V4 freeze includes historical helper identities outside the investigation directory and current-worktree helper identities; the package needs a deterministic policy for embedding or referencing those files while preserving their frozen hashes. The package’s old explicit allowlist is not itself a complete inventory of all extant partial workflow outputs. A full literal-reference walk and identity list for every non-sourcebase regular file is still required before claiming packet completeness. No literal references were found missing among the 39 frozen helper paths. Release build and measurement status remains pending; do not infer experiment outcome.
