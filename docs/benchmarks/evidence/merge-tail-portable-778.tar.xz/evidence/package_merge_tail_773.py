"""Create a portable V2 packet for completed merge-tail attribution evidence.

Packaging only: requires the accepted V2 verifier receipt, retains the failed
V1 attempt without giving it result credit, and never rebuilds or reruns code.
"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import lzma
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019')
REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
LOCALDATA = Path('/Users/dylan/LocalData/shardloom')
DEST = ROOT / 'merge-tail-portable-773'
NAME = 'merge-tail-portable-773'
V1_LABEL = 'merge-tail-attribution-771-a1'
V1_BUILD = 'merge-tail-build-771-a1'
V2_LABEL = 'merge-tail-attribution-773-a1'
V2_BUILD = 'merge-tail-build-773-a1'
V1_PROTOCOL = ROOT / 'merge-tail-attribution-protocol-771.json'
V1_FREEZE_RECEIPT = ROOT / 'merge-tail-protocol-freeze-771.json'
V1_SOURCE_FREEZE = ROOT / f'{V1_LABEL}-source-freeze.json'
V1_ARTIFACT_RECEIPT = ROOT / f'{V1_LABEL}-artifact.json'
V1_ARTIFACT = ROOT / f'{V1_LABEL}-test'
V1_BUILD_RECEIPT = ROOT / f'{V1_BUILD}.json'
V1_DATA = ROOT / V1_LABEL
V1_FAILURE = ROOT / 'merge-tail-protocol-admission-failure-772.json'
V2_PROTOCOL = ROOT / 'merge-tail-attribution-protocol-773.json'
V2_FREEZE_RECEIPT = ROOT / 'merge-tail-protocol-freeze-773.json'
V2_SOURCE_FREEZE = ROOT / f'{V2_LABEL}-source-freeze.json'
V2_ARTIFACT_RECEIPT = ROOT / f'{V2_LABEL}-artifact.json'
V2_ARTIFACT = ROOT / f'{V2_LABEL}-test'
V2_BUILD_RECEIPT = ROOT / f'{V2_BUILD}.json'
V2_DATA = ROOT / V2_LABEL
V2_DECISION = ROOT / f'{V2_LABEL}-decision.json'
V2_SEQUENCE_IDENTITY = ROOT / f'{V2_LABEL}-sequence-identity.json'
V2_SEQUENCE_COMPLETION = ROOT / f'{V2_LABEL}-sequence-completion.json'
V2_VERIFICATION = ROOT / 'merge-tail-verification-773.json'
EXPECTED_HEAD = 'd732d7889207e7d8fc0de8d746de1623174c1dcf'
V1_PROTOCOL_SHA = 'e2ffc917bf17d64bffdc0f27943e86f12345ceaeb29a65ee69d290279eaa6a72'
V2_PROTOCOL_SHA = '081a46278f799945e00a4f1d87fb5c316e2408cfd613c38998acad1c8f190865'
V1_EXPECTED_STEPS = (
    'merge-tail-bind-771-a1', 'merge-tail-focused-spill-771-a1',
    'merge-tail-preflight-off-771-a1',
)
V2_EXPECTED_STEPS = (
    'merge-tail-bind-773-a1', 'merge-tail-focused-spill-773-a1',
    'merge-tail-preflight-off-773-a1', 'merge-tail-preflight-on-773-a1',
    'merge-tail-preflight-check-773-a1', 'merge-tail-measure-A-off-773-a1',
    'merge-tail-measure-A-on-773-a1', 'merge-tail-measure-B-on-773-a1',
    'merge-tail-measure-B-off-773-a1', 'merge-tail-decision-773-a1',
    'merge-tail-final-binding-773-a1',
)
V2_STREAMS = (
    'preflight-preflight-off.jsonl', 'preflight-preflight-on.jsonl',
    'measure-A-off.jsonl', 'measure-A-on.jsonl',
    'measure-B-off.jsonl', 'measure-B-on.jsonl',
)
V1_STREAMS = ('preflight-preflight-off.jsonl',)
V1_EMPTY_DIRECTORIES = ('spill-0-uniform24-spill-off-preflight-0-false',)

# These exact mutable packet outputs are intentionally excluded. Every other
# merge-tail-prefixed file must belong to the fixed inclusion inventory.
EXCLUDED_EVIDENCE = {
    f'{V1_LABEL}-test': 'V1 compiled test executable; invalid attempt, identity retained only.',
    f'{V2_LABEL}-test': 'V2 compiled test executable; reproduction identity retained, binary omitted.',
    'merge-tail-package-772.json': 'Mutable V1 packaging receipt, excluded from immutable evidence.',
    'merge-tail-package-772.log': 'Mutable V1 packaging log, excluded from immutable evidence.',
    'merge-tail-package-772-driver.log': 'Mutable V1 packaging driver log, excluded from immutable evidence.',
    'merge-tail-packet-verification-772.json': 'Mutable V1 packet reopen receipt.',
    'verify-merge-tail-packet-772.log': 'Mutable V1 packet reopen log.',
    'merge-tail-package-773.json': 'Mutable V2 packaging receipt, excluded from immutable evidence.',
    'merge-tail-package-773.log': 'Mutable V2 packaging log, excluded from immutable evidence.',
    'merge-tail-package-773-driver.log': 'Mutable V2 packaging driver log, excluded from immutable evidence.',
    'merge-tail-packet-verification-773.json': 'Mutable V2 packet reopen receipt.',
    'verify-merge-tail-packet-773.log': 'Mutable V2 packet reopen log.',
}

V1_TOP_LEVEL = {
    V1_PROTOCOL.name, V1_FREEZE_RECEIPT.name, V1_FAILURE.name,
    V1_SOURCE_FREEZE.name, f'{V1_LABEL}-tracked.patch',
    f'{V1_LABEL}-artifact.json', f'{V1_LABEL}-test-inventory.txt',
    f'{V1_BUILD}.json', f'{V1_BUILD}.log', 'merge-tail-build-771-a1-driver.log',
    f'{V1_LABEL}-sequence-identity.json', 'run_merge_tail_sequence_771.py',
    'run_merge_tail_sequence_before_primary_review_771.py', 'merge_tail_driver_771.py',
    'analyze_merge_tail_771.py', 'analyze_merge_tail_771_before_primary_review_771.py',
    'test_merge_tail_oracle_771.py', 'test_merge_tail_oracle_771_before_primary_review_771.py',
    'merge-tail-focused-spill-771-a1.json', 'merge-tail-focused-spill-771-a1.log',
    'merge-tail-primary-review-772.json', 'merge-tail-oracle-final-tests-772.log',
    'merge-tail-oracle-initial-tests-771.log', 'merge-tail-oracle-expanded-tests-772.log',
    'verify_merge_tail_772.py', 'package_merge_tail_772.py',
    'package_merge_tail_before_primary_review_772.py', 'merge-tail-design-v1-preserved-773.md',
    'merge-tail-investigation-design-draft-769.md',
}
V2_TOP_LEVEL = {
    V2_PROTOCOL.name, V2_FREEZE_RECEIPT.name, V2_SOURCE_FREEZE.name,
    f'{V2_LABEL}-tracked.patch', f'{V2_LABEL}-artifact.json',
    f'{V2_LABEL}-test-inventory.txt', f'{V2_BUILD}.json', f'{V2_BUILD}.log',
    'merge-tail-build-773-a1-driver.log', f'{V2_LABEL}-sequence-identity.json',
    f'{V2_LABEL}-sequence-completion.json', f'{V2_LABEL}-decision.json',
    f'{V2_LABEL}-preflight-verification.json', V2_VERIFICATION.name,
    'merge-tail-primary-review-773.json', 'merge-tail-oracle-final-tests-773.log',
    'merge-tail-sequence-773-driver.log', 'merge-tail-verifier-773.json',
    'merge-tail-verifier-773.log', 'merge-tail-verifier-773-driver.log',
    'merge_tail_driver_773.py', 'run_merge_tail_sequence_773.py',
    'analyze_merge_tail_773.py', 'test_merge_tail_oracle_773.py',
    'verify_merge_tail_773.py',
}
V1_PARTIAL_STEP_FILES = {
    name for step in V1_EXPECTED_STEPS
    for name in (f'{step}-sequence-step.json', f'{step}-sequence-output.log',
                 f'{step}.json', f'{step}.log')
} | {'merge-tail-preflight-off-771-a1-link.json'}
V2_STEP_FILES = {
    name for step in V2_EXPECTED_STEPS
    for name in (f'{step}-sequence-step.json', f'{step}-sequence-output.log')
} | {
    name for step in V2_EXPECTED_STEPS[:-1] for name in (f'{step}.json', f'{step}.log')
} | {
    f'{step}-link.json' for step in (
        'merge-tail-preflight-off-773-a1', 'merge-tail-preflight-on-773-a1',
        'merge-tail-measure-A-off-773-a1', 'merge-tail-measure-A-on-773-a1',
        'merge-tail-measure-B-on-773-a1', 'merge-tail-measure-B-off-773-a1')
}
TOP_LEVEL_ALLOWLIST = V1_TOP_LEVEL | V2_TOP_LEVEL | V1_PARTIAL_STEP_FILES | V2_STEP_FILES

sys.path.insert(0, str(REPO / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for part in iter(lambda: stream.read(1 << 20), b''):
            digest.update(part)
    return digest.hexdigest()


def identity(path: Path) -> dict[str, object]:
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha_file(path)}


def read_json(path: Path) -> dict:
    assert path.is_file() and not path.is_symlink(), path
    value = json.loads(path.read_text())
    assert isinstance(value, dict), path
    return value


def encode_json(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def add_file(members: dict[str, Path], member: str, source: Path) -> None:
    source = Path(source)
    assert source.is_file() and not source.is_symlink(), source
    assert member and not member.startswith('/') and '..' not in Path(member).parts, member
    assert '\\' not in member and '\x00' not in member
    prior = members.get(member)
    assert prior is None or prior.resolve() == source.resolve(), f'duplicate archive path {member}'
    members[member] = source


def archive_path(path: Path) -> str:
    path = Path(path).resolve(strict=True)
    if path.is_relative_to(ROOT):
        return 'evidence/' + path.relative_to(ROOT).as_posix()
    if path.is_relative_to(REPO):
        return 'repo/' + path.relative_to(REPO).as_posix()
    if path.is_relative_to(LOCALDATA):
        return 'local/' + path.relative_to(LOCALDATA).as_posix()
    raise AssertionError(f'input outside approved local roots: {path}')


def add_tree(members: dict[str, Path], root: Path, member_root: str) -> list[Path]:
    assert root.is_dir() and not root.is_symlink(), root
    files = []
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_dir():
            continue
        assert path.is_file(), path
        add_file(members, f'{member_root}/{path.relative_to(root).as_posix()}', path)
        files.append(path)
    return files


def verify_source_freeze(freeze_path: Path, expected_sha: str, expected_helpers: int,
                         *, current_sources: bool) -> dict:
    freeze = read_json(freeze_path)
    assert freeze.get('head') == EXPECTED_HEAD
    assert freeze.get('protocol_sha256') == expected_sha
    assert len(freeze.get('helpers', [])) == expected_helpers
    assert len(freeze.get('sources', [])) == 1901
    patch = ROOT / f"{freeze_path.name.removesuffix('-source-freeze.json')}-tracked.patch"
    assert patch.is_file() and not patch.is_symlink()
    assert sha_file(patch) == freeze.get('patch_sha256')
    extra_root = ROOT / f"{freeze_path.name.removesuffix('-source-freeze.json')}-extra-sources"
    assert extra_root.is_dir() and not extra_root.is_symlink()
    declared = set(freeze.get('extra_sources', []))
    actual = set()
    for path in extra_root.rglob('*'):
        assert not path.is_symlink(), path
        if path.is_file():
            actual.add(path.relative_to(extra_root).as_posix())
    assert actual == declared
    source_rows = {row['path']: row for row in freeze['sources']}
    assert declared <= source_rows.keys()
    for relative in sorted(declared):
        copied = extra_root / relative
        row = source_rows[relative]
        assert copied.stat().st_size == row['bytes'] and sha_file(copied) == row['sha256']
    for helper in freeze['helpers']:
        path = Path(helper['path'])
        assert path.is_file() and not path.is_symlink(), path
        assert path.stat().st_size == helper['bytes'] and sha_file(path) == helper['sha256'], path
    if current_sources:
        head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
        assert head == EXPECTED_HEAD
        paths = subprocess.check_output(
            ['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=REPO, text=True
        ).splitlines()
        paths = sorted(p for p in set(paths) if p.endswith('.rs') or
                       Path(p).name in ('Cargo.toml', 'Cargo.toml.orig', 'Cargo.lock'))
        assert paths == [row['path'] for row in freeze['sources']]
        for row in freeze['sources']:
            path = REPO / row['path']
            assert path.is_file() and not path.is_symlink(), path
            assert path.stat().st_size == row['bytes'] and sha_file(path) == row['sha256'], path
    return freeze


def validate_v1() -> tuple[dict, dict, list[Path], list[str]]:
    protocol = read_json(V1_PROTOCOL)
    assert protocol.get('protocol_id') == 'merge-tail-attribution-771-v1'
    assert sha_file(V1_PROTOCOL) == V1_PROTOCOL_SHA
    failure = read_json(V1_FAILURE)
    assert failure.get('status') == 'invalid_protocol_admission_no_workflow_executed'
    assert failure.get('label') == V1_LABEL and failure.get('protocol_sha256') == V1_PROTOCOL_SHA
    assert failure.get('completed_workflows') == 0 and failure.get('measured_workflows') == 0
    assert failure.get('engine_measurement_available') is False
    assert failure.get('process_group_drained') is True
    assert failure.get('retained_empty_directories') == [f'{V1_LABEL}/{V1_EMPTY_DIRECTORIES[0]}']
    freeze_receipt = read_json(V1_FREEZE_RECEIPT)
    assert freeze_receipt.get('sha256') == V1_PROTOCOL_SHA
    assert freeze_receipt.get('status') == 'frozen_before_observer_harness_and_measurement'
    freeze = verify_source_freeze(V1_SOURCE_FREEZE, V1_PROTOCOL_SHA, 23, current_sources=False)
    artifact_receipt = read_json(V1_ARTIFACT_RECEIPT)
    build = read_json(V1_BUILD_RECEIPT)
    evidence = failure.get('evidence', {})
    for name, row in evidence.items():
        path = ROOT / name
        assert path.is_file() and not path.is_symlink(), path
        assert path.stat().st_size == row['bytes'] and sha_file(path) == row['sha256'], path
    assert artifact_receipt.get('artifact') == str(V1_ARTIFACT)
    assert artifact_receipt.get('source_freeze_sha256') == sha_file(V1_SOURCE_FREEZE)
    assert artifact_receipt.get('artifact_sha256') == sha_file(V1_ARTIFACT)
    assert artifact_receipt.get('bytes') == V1_ARTIFACT.stat().st_size
    assert build.get('status') == 'passed' and build.get('process_group_drained') is True
    assert sha_file(V1_BUILD_RECEIPT.with_suffix('.log')) == build.get('log_sha256')

    files, directories = validate_failed_v1_data(failure)
    for step in V1_EXPECTED_STEPS:
        step_record = read_json(ROOT / f'{step}-sequence-step.json')
        assert step_record.get('step') == step
        assert step_record.get('source_freeze_sha256') == sha_file(V1_SOURCE_FREEZE)
        assert step_record.get('protocol_sha256') == V1_PROTOCOL_SHA
        assert sha_file(ROOT / f'{step}-sequence-output.log') == step_record.get('output_sha256')
        guard = read_json(ROOT / f'{step}.json')
        assert guard.get('head') == EXPECTED_HEAD
        assert guard.get('driver_sha256') == sha_file(ROOT / 'run_guarded_observed_757.py')
        assert sha_file(ROOT / f'{step}.log') == guard.get('log_sha256')
    off_link = read_json(ROOT / 'merge-tail-preflight-off-771-a1-link.json')
    assert off_link.get('returncode') != 0 and off_link.get('protocol_sha256') == V1_PROTOCOL_SHA
    assert off_link.get('output') == str(V1_DATA / V1_STREAMS[0])
    sequence = read_json(ROOT / f'{V1_LABEL}-sequence-identity.json')
    assert sequence.get('label') == V1_LABEL and sequence.get('protocol_sha256') == V1_PROTOCOL_SHA
    assert sequence.get('source_freeze_sha256') == sha_file(V1_SOURCE_FREEZE)
    return freeze, artifact_receipt, files, directories


def validate_failed_v1_data(failure: dict) -> tuple[list[Path], list[str]]:
    assert V1_DATA.is_dir() and not V1_DATA.is_symlink()
    expected_rows = failure.get('failed_data_files', [])
    expected = {row['path'].removeprefix(f'{V1_LABEL}/'): row for row in expected_rows}
    actual_files, actual_dirs = [], []
    for path in V1_DATA.rglob('*'):
        assert not path.is_symlink(), path
        if path.is_dir():
            actual_dirs.append(path.relative_to(V1_DATA).as_posix())
        elif path.is_file():
            actual_files.append(path)
        else:
            raise AssertionError(f'non-regular V1 evidence path: {path}')
    assert {p.relative_to(V1_DATA).as_posix() for p in actual_files} == set(expected)
    assert set(actual_dirs) == {'witnesses', *V1_EMPTY_DIRECTORIES}
    for path in actual_files:
        row = expected[path.relative_to(V1_DATA).as_posix()]
        assert path.stat().st_size == row['bytes'] and sha_file(path) == row['sha256']
        if path.parent == V1_DATA / 'witnesses':
            assert sha_file(path) == path.stem
    empty_path = V1_DATA / V1_EMPTY_DIRECTORIES[0]
    assert empty_path.is_dir() and not any(empty_path.iterdir())
    return actual_files, [str(empty_path)]


def validate_v2() -> tuple[dict, dict, dict]:
    protocol = read_json(V2_PROTOCOL)
    assert protocol.get('protocol_id') == 'merge-tail-attribution-773-v2'
    assert protocol.get('production_commit') == EXPECTED_HEAD
    assert sha_file(V2_PROTOCOL) == V2_PROTOCOL_SHA
    assert protocol.get('correction', {}).get('completed_prior_workflows') == 0
    assert protocol.get('resources', {}) == {} or protocol.get('workload', {}).get('resources', {}).get('spill_buffer_bytes') == 1048576
    receipt = read_json(V2_FREEZE_RECEIPT)
    assert receipt.get('protocol') == str(V2_PROTOCOL)
    assert receipt.get('sha256') == V2_PROTOCOL_SHA and receipt.get('bytes') == V2_PROTOCOL.stat().st_size
    assert receipt.get('production_commit') == EXPECTED_HEAD
    assert receipt.get('status') == 'frozen_before_corrected_harness_and_any_completed_workflow'
    freeze = verify_source_freeze(V2_SOURCE_FREEZE, V2_PROTOCOL_SHA, 28, current_sources=True)

    review = read_json(ROOT / 'merge-tail-primary-review-773.json')
    assert review.get('status') == 'primary_review_passed_before_v2_source_freeze'
    assert review.get('protocol', {}).get('sha256') == V2_PROTOCOL_SHA
    assert review.get('test_count') == 14
    test_log = ROOT / 'merge-tail-oracle-final-tests-773.log'
    assert sha_file(test_log) == review.get('test_log', {}).get('sha256')
    for item in review.get('helpers', []):
        path = ROOT / Path(item['path']).name
        assert path.is_file() and not path.is_symlink()
        assert path.stat().st_size == item['bytes'] and sha_file(path) == item['sha256']

    build = read_json(V2_BUILD_RECEIPT)
    assert build.get('status') == 'passed' and build.get('returncode') == 0
    assert build.get('process_group_drained') is True
    assert sha_file(V2_BUILD_RECEIPT.with_suffix('.log')) == build.get('log_sha256')
    artifact = read_json(ROOT / f'{V2_LABEL}-artifact.json')
    assert artifact.get('artifact') == str(V2_ARTIFACT)
    assert V2_ARTIFACT.is_file() and not V2_ARTIFACT.is_symlink()
    assert artifact.get('bytes') == V2_ARTIFACT.stat().st_size
    assert artifact.get('artifact_sha256') == sha_file(V2_ARTIFACT)
    assert artifact.get('source_freeze_sha256') == sha_file(V2_SOURCE_FREEZE)
    assert artifact.get('build_receipt_sha256') == sha_file(V2_BUILD_RECEIPT)

    verify = read_json(V2_VERIFICATION)
    assert verify.get('schema_version') == 'shardloom.merge_tail_attribution_verification.v1'
    assert verify.get('status') == 'passed' and verify.get('label') == V2_LABEL
    assert verify.get('protocol_sha256') == V2_PROTOCOL_SHA
    assert verify.get('production_head') == EXPECTED_HEAD
    assert verify.get('production_optimization') is False
    assert verify.get('total_workflows') == 236 and verify.get('total_operations') == 236
    assert verify.get('preflight_workflows') == 40 and verify.get('measured_workflows') == 192
    assert verify.get('warmup_workflows') == 4 and verify.get('stream_count') == 6
    assert verify.get('scope_result') in ('material_signal', 'no_signal')
    assert verify.get('verifier') == identity(ROOT / 'verify_merge_tail_773.py')
    assert verify.get('source_binding') == identity(V2_SOURCE_FREEZE)
    assert verify.get('artifact_binding') == identity(ROOT / f'{V2_LABEL}-artifact.json')
    assert verify.get('decision_binding') == identity(V2_DECISION)
    assert verify.get('sequence_identity') == identity(V2_SEQUENCE_IDENTITY)
    return freeze, artifact, verify


def validate_v2_sequence(verify: dict) -> tuple[dict, dict]:
    identity_value = read_json(V2_SEQUENCE_IDENTITY)
    completion = read_json(V2_SEQUENCE_COMPLETION)
    decision = read_json(V2_DECISION)
    assert identity_value.get('label') == V2_LABEL and identity_value.get('build') == V2_BUILD
    assert identity_value.get('protocol_sha256') == V2_PROTOCOL_SHA
    assert identity_value.get('source_freeze_sha256') == sha_file(V2_SOURCE_FREEZE)
    assert identity_value.get('build_receipt_sha256') == sha_file(V2_BUILD_RECEIPT)
    assert completion == {
        'status': 'completed', 'identity_sha256': sha_file(V2_SEQUENCE_IDENTITY),
        'decision_sha256': sha_file(V2_DECISION),
        'decision_scope_result': decision.get('scope_result'),
        'production_optimization': False,
    }
    assert decision.get('scope_result') == verify.get('scope_result')
    assert decision.get('production_optimization') is False
    assert decision.get('actual_schedule_speedup') is False

    for key, name in (
        ('sequence_sha256', 'run_merge_tail_sequence_773.py'),
        ('driver_sha256', 'merge_tail_driver_773.py'),
        ('guard_sha256', 'run_guarded_observed_757.py'),
        ('oracle_sha256', 'analyze_merge_tail_773.py'),
        ('protocol_sha256', V2_PROTOCOL.name),
        ('protocol_freeze_sha256', V2_FREEZE_RECEIPT.name),
    ):
        assert identity_value.get(key) == sha_file(ROOT / name), name

    for step in V2_EXPECTED_STEPS:
        step_receipt = read_json(ROOT / f'{step}-sequence-step.json')
        assert step_receipt.get('step') == step and step_receipt.get('returncode') == 0
        assert step_receipt.get('source_freeze_sha256') == sha_file(V2_SOURCE_FREEZE)
        assert step_receipt.get('protocol_sha256') == V2_PROTOCOL_SHA
        assert sha_file(ROOT / f'{step}-sequence-output.log') == step_receipt.get('output_sha256')
        if step == V2_EXPECTED_STEPS[-1]:
            continue
        guard = read_json(ROOT / f'{step}.json')
        assert guard.get('status') == 'passed' and guard.get('returncode') == 0
        assert guard.get('process_group_drained') is True
        assert sha_file(ROOT / f'{step}.log') == guard.get('log_sha256')
        if 'preflight-' in step and step.endswith(('-off-773-a1', '-on-773-a1')) or 'measure-' in step:
            link = read_json(ROOT / f'{step}-link.json')
            assert link.get('returncode') == 0 and link.get('sources_and_artifact_unchanged') is True
            assert link.get('artifact_sha256') == sha_file(V2_ARTIFACT)

    preflight = read_json(ROOT / f'{V2_LABEL}-preflight-verification.json')
    assert preflight.get('preflight_passed') is True
    assert preflight.get('protocol_sha256') == V2_PROTOCOL_SHA
    assert sum(item['workflows'] for item in preflight['streams'].values()) == 40
    assert sum(item['operations'] for item in preflight['streams'].values()) == 40
    return decision, identity_value


def verify_v1_step_evidence(members: dict[str, Path]) -> None:
    failure = read_json(V1_FAILURE)
    for step in V1_EXPECTED_STEPS:
        guard_path = ROOT / f'{step}.json'
        guard = read_json(guard_path)
        assert guard.get('status') == ('passed' if step != 'merge-tail-preflight-off-771-a1' else 'failed')
        assert guard.get('process_group_drained') is True
        for suffix in ('.json', '.log'):
            path = ROOT / f'{step}{suffix}'
            assert path.is_file() and not path.is_symlink()
    for name, row in failure['evidence'].items():
        assert identity(ROOT / name) == {'path': str(ROOT / name),
                                         'bytes': row['bytes'], 'sha256': row['sha256']}


def build_members(v1_freeze: dict, v2_freeze: dict,
                  v1_data_files: list[Path], v1_dirs: list[str]) -> tuple[dict[str, Path], list[str], dict]:
    members: dict[str, Path] = {}
    names = set(TOP_LEVEL_ALLOWLIST)
    related = {p.name for p in ROOT.iterdir() if p.is_file() and
               (p.name.startswith(('merge-tail', 'merge_tail', 'package_merge_tail')) or
                p.name.startswith('verify-merge-tail'))}
    assert related <= names | set(EXCLUDED_EVIDENCE), (
        f'unallowlisted merge-tail files: {sorted(related - names - set(EXCLUDED_EVIDENCE))}')
    for name in EXCLUDED_EVIDENCE:
        assert not (ROOT / name).is_symlink(), ROOT / name
    for name in sorted(names):
        add_file(members, 'evidence/' + name, ROOT / name)

    for freeze in (v1_freeze, v2_freeze):
        for helper in freeze['helpers']:
            path = Path(helper['path'])
            assert path.stat().st_size == helper['bytes'] and sha_file(path) == helper['sha256']
            add_file(members, archive_path(path), path)
        label = V1_LABEL if freeze['protocol_sha256'] == V1_PROTOCOL_SHA else V2_LABEL
        extra_root = ROOT / f'{label}-extra-sources'
        paths = add_tree(members, extra_root, f'sources/{label}-extra')
        assert len(paths) == len(freeze['extra_sources'])

    v1_rows = read_json(V1_FAILURE)['failed_data_files']
    expected_v1 = {r['path'].removeprefix(f'{V1_LABEL}/'): r for r in v1_rows}
    assert {p.relative_to(V1_DATA).as_posix() for p in v1_data_files} == set(expected_v1)
    for path in v1_data_files:
        rel = path.relative_to(V1_DATA).as_posix()
        add_file(members, f'failed-v1/{rel}', path)

    assert V2_DATA.is_dir() and not V2_DATA.is_symlink()
    v2_files = []
    for path in V2_DATA.rglob('*'):
        assert not path.is_symlink(), path
        if path.is_dir():
            assert path == V2_DATA / 'witnesses', path
        else:
            assert path.is_file(), path
            v2_files.append(path)
    streams = sorted(p for p in v2_files if p.parent == V2_DATA and p.suffix == '.jsonl')
    assert {p.name for p in streams} == set(V2_STREAMS)
    witnesses = sorted(p for p in v2_files if p.parent == V2_DATA / 'witnesses' and p.suffix == '.json')
    assert len(witnesses) == len([p for p in v2_files if p.parent == V2_DATA / 'witnesses'])
    for path in witnesses:
        assert len(path.stem) == 64 and all(c in '0123456789abcdef' for c in path.stem)
        assert sha_file(path) == path.stem
    assert set(v2_files) == set(streams + witnesses)
    for path in sorted(v2_files):
        add_file(members, 'raw-v2/' + path.relative_to(V2_DATA).as_posix(), path)

    empty_members = [f'failed-v1/{V1_EMPTY_DIRECTORIES[0]}/']
    return members, empty_members, {
        'top_level_included': sorted(names),
        'top_level_excluded': [{'name': name, 'reason': reason}
                               for name, reason in sorted(EXCLUDED_EVIDENCE.items())],
        'v1_failed_raw_files': [str(p) for p in sorted(v1_data_files)],
        'v1_retained_empty_directories': v1_dirs,
        'v1_frozen_helpers': [h['path'] for h in v1_freeze['helpers']],
        'v2_frozen_helpers': [h['path'] for h in v2_freeze['helpers']],
        'v2_raw_streams': [str(p) for p in streams],
        'v2_content_addressed_witnesses': [str(p) for p in witnesses],
        'v2_witness_count': len(witnesses),
    }


def main() -> None:
    argparse.ArgumentParser(description=__doc__).parse_args()
    assert not DEST.exists(), f'refusing to overwrite destination {DEST}'
    require_local_path(ROOT, Path.home(), sys.platform)
    require_local_path(DEST, Path.home(), sys.platform)
    v1_freeze, v1_artifact_receipt, v1_data_files, v1_dirs = validate_v1()
    v2_freeze, v2_artifact, verification = validate_v2()
    decision, sequence_identity = validate_v2_sequence(verification)
    assert len(v1_freeze['helpers']) == 23 and len(v2_freeze['helpers']) == 28

    members, empty_directories, coverage = build_members(
        v1_freeze, v2_freeze, v1_data_files, v1_dirs)
    verify_v1_step_evidence(members)
    inventory = []
    frozen = {}
    for member_name, source in sorted(members.items()):
        data = source.read_bytes()
        row = {'path': member_name, 'original_path': str(source),
               'bytes': len(data), 'sha256': sha_bytes(data)}
        inventory.append(row)
        frozen[member_name] = (row['bytes'], row['sha256'])
    directory_inventory = [{'path': path, 'type': 'empty_directory'}
                           for path in empty_directories]

    storage_before = check_budgets(ROOT, DEST, ROOT, min_free_bytes=12 * GIB,
                                   reserve_bytes=128 * MIB, max_workspace_bytes=100 * GIB,
                                   max_log_bytes=192 * MIB)
    assert not DEST.exists()
    DEST.mkdir()
    archive_out = DEST / f'{NAME}.tar.xz'
    archive_members = sorted([*inventory, *directory_inventory], key=lambda row: row['path'])
    with tarfile.open(archive_out, mode='x:xz', format=tarfile.PAX_FORMAT, preset=6) as archive:
        for row in archive_members:
            if row.get('type') == 'empty_directory':
                info = tarfile.TarInfo(row['path'])
                info.type = tarfile.DIRTYPE
                info.mode = 0o755
                info.size = 0
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                info.mtime = 0
                archive.addfile(info)
                continue
            source = members[row['path']]
            data = source.read_bytes()
            assert (len(data), sha_bytes(data)) == (row['bytes'], row['sha256']), source
            info = tarfile.TarInfo(row['path'])
            info.size, info.mode = len(data), 0o644
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            info.mtime = 0
            archive.addfile(info, io.BytesIO(data))

    with tarfile.open(archive_out, mode='r:xz') as archive:
        assert archive.getnames() == [row['path'] for row in archive_members]
        for row in archive_members:
            member = archive.getmember(row['path'])
            if row.get('type') == 'empty_directory':
                assert member.isdir() and member.size == 0
            else:
                assert member.isfile() and member.size == row['bytes']
                content = archive.extractfile(member).read()
                assert (len(content), sha_bytes(content)) == (row['bytes'], row['sha256'])
    for member_name, source in members.items():
        assert (source.stat().st_size, sha_file(source)) == frozen[member_name]

    manifest = {
        'schema_version': 'shardloom.evidence_member_manifest.v1',
        'all_members_reopened': True, 'members': inventory,
        'directories': directory_inventory,
    }
    manifest_out = DEST / f'{NAME}.manifest.json.xz'
    with manifest_out.open('xb') as stream:
        stream.write(lzma.compress(encode_json(manifest), preset=6))
    assert json.loads(lzma.decompress(manifest_out.read_bytes())) == manifest

    index = {
        'schema_version': 'shardloom.merge_tail_portable_packet.v2',
        'status': 'passed', 'primary_protocol_id': 'merge-tail-attribution-773-v2',
        'scope_result': verification['scope_result'], 'production_optimization': False,
        'claim_boundary': 'V2 finite attribution only. V1 is preserved as an invalid zero-workflow admission failure and receives no decision credit.',
        'production_head': EXPECTED_HEAD,
        'v2_protocol': identity(V2_PROTOCOL), 'v2_protocol_freeze': identity(V2_FREEZE_RECEIPT),
        'v2_verification': identity(V2_VERIFICATION), 'v2_source_freeze': identity(V2_SOURCE_FREEZE),
        'v2_artifact_receipt': identity(V2_ARTIFACT_RECEIPT),
        'v2_build_receipt': identity(V2_BUILD_RECEIPT),
        'v2_tracked_patch': identity(ROOT / f'{V2_LABEL}-tracked.patch'),
        'v2_decision': identity(V2_DECISION),
        'v2_sequence_identity': identity(V2_SEQUENCE_IDENTITY),
        'v2_sequence_completion': identity(V2_SEQUENCE_COMPLETION),
        'v2_measured_scope': {key: verification[key] for key in (
            'total_workflows', 'total_operations', 'preflight_workflows',
            'measured_workflows', 'warmup_workflows', 'scope_result')},
        'v2_source_inventory': {
            'source_count': len(v2_freeze['sources']),
            'source_freeze': identity(V2_SOURCE_FREEZE),
            'extra_source_count': len(v2_freeze['extra_sources']),
            'tracked_patch_sha256': v2_freeze['patch_sha256'],
            'frozen_helper_count': len(v2_freeze['helpers']),
        },
        'v1_invalid_attempt': {
            'receipt': identity(V1_FAILURE), 'protocol': identity(V1_PROTOCOL),
            'source_freeze': identity(V1_SOURCE_FREEZE),
            'tracked_patch': identity(ROOT / f'{V1_LABEL}-tracked.patch'),
            'artifact_receipt': identity(V1_ARTIFACT_RECEIPT),
            'compiled_artifact_omitted': {
                'path': str(V1_ARTIFACT), 'bytes': v1_artifact_receipt['bytes'],
                'sha256': v1_artifact_receipt['artifact_sha256'],
                'reason': EXCLUDED_EVIDENCE[V1_ARTIFACT.name],
            },
            'completed_workflows': 0, 'measured_workflows': 0,
            'engine_measurement_available': False,
            'decision_credit': False,
            'failed_data_files': [str(path) for path in v1_data_files],
            'empty_owned_directory_member': empty_directories[0],
            'frozen_helper_count': len(v1_freeze['helpers']),
        },
        'coverage': coverage,
        'v2_compiled_artifact_omitted': {
            'path': str(V2_ARTIFACT), 'bytes': v2_artifact['bytes'],
            'sha256': v2_artifact['artifact_sha256'],
            'reason': EXCLUDED_EVIDENCE[V2_ARTIFACT.name],
            'build_command': read_json(V2_BUILD_RECEIPT).get('command'),
        },
        'storage_check': {
            'guard': 'local_uat_storage.require_local_path and check_budgets',
            'before_write': storage_before,
            'limits': {'minimum_free_bytes': 12 * GIB, 'candidate_reserve_bytes': 128 * MIB,
                       'maximum_workspace_bytes': 100 * GIB, 'maximum_log_bytes': 192 * MIB},
        },
        'member_count': len(inventory), 'uncompressed_bytes': sum(x['bytes'] for x in inventory),
        'all_members_reopened': True,
        'archive': {'file': archive_out.name, 'bytes': archive_out.stat().st_size,
                    'sha256': sha_file(archive_out)},
        'manifest': {'file': manifest_out.name, 'bytes': manifest_out.stat().st_size,
                     'sha256': sha_file(manifest_out)},
    }
    with (DEST / f'{NAME}.json').open('xb') as stream:
        stream.write(encode_json(index))
    check_budgets(ROOT, DEST, ROOT, min_free_bytes=12 * GIB, reserve_bytes=0,
                  max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    print(json.dumps({'status': 'passed', 'members': len(inventory),
                      'v1_completed_workflows': 0, 'v2_scope_result': verification['scope_result'],
                      'archive': index['archive'], 'manifest': index['manifest'],
                      'index': str(DEST / f'{NAME}.json'), 'all_members_reopened': True}))


if __name__ == '__main__':
    main()
