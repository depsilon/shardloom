"""Reopen and bind every completed merge-tail attribution proof before packaging."""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
LABEL = 'merge-tail-attribution-774-a1'
BUILD = 'merge-tail-build-774-a1'
HEAD = 'd732d7889207e7d8fc0de8d746de1623174c1dcf'
PROTOCOL_SHA = '2db26a89965125f7deb44e644dd28852c475add5944089e486bf8fa8d6aa38bc'


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for part in iter(lambda: stream.read(1 << 20), b''): value.update(part)
    return value.hexdigest()


def read(name):
    path = ROOT / name
    assert path.is_file() and not path.is_symlink(), path
    return json.loads(path.read_text())


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def main():
    output = ROOT / 'merge-tail-verification-775.json'
    assert not output.exists()
    oracle = module('merge_oracle_final', ROOT / 'analyze_merge_tail_774.py')
    driver = module('merge_driver_final', ROOT / 'merge_tail_driver_774.py')
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == HEAD
    freeze_path = ROOT / f'{LABEL}-source-freeze.json'
    freeze = read(freeze_path.name)
    assert freeze['head'] == HEAD and freeze['protocol_sha256'] == PROTOCOL_SHA
    driver.verify_sources(freeze)
    driver.historical_sources(LABEL, freeze)
    patch = ROOT / f'{LABEL}-tracked.patch'
    assert subprocess.check_output(['git', 'diff', 'HEAD', '--binary'], cwd=REPO) == patch.read_bytes()
    freeze_sha = sha(freeze_path)
    artifact_path = ROOT / f'{LABEL}-artifact.json'
    artifact = read(artifact_path.name)
    binary = ROOT / f'{LABEL}-test'
    assert artifact['artifact'] == str(binary)
    assert artifact['bytes'] == binary.stat().st_size and artifact['artifact_sha256'] == sha(binary)
    assert artifact['source_freeze_sha256'] == freeze_sha
    assert artifact['selector'] == driver.SELECTOR
    assert artifact['build'] == BUILD
    assert artifact['build_receipt_sha256'] == sha(ROOT / f'{BUILD}.json')
    assert artifact['build_log_sha256'] == sha(ROOT / f'{BUILD}.log')
    assert artifact['inventory_sha256'] == sha(ROOT / f'{LABEL}-test-inventory.txt')
    compiler = artifact['compiler_artifact']
    assert compiler['reason'] == 'compiler-artifact' and compiler['target']['name'] == 'shardloom_vortex'
    assert compiler['profile']['test'] is True and compiler['fresh'] is False
    assert compiler['executable']
    assert compiler['features'] and 'release-user-surfaces' in compiler['features']
    messages = [json.loads(line) for line in (ROOT / f'{BUILD}.log').read_text().splitlines() if line.startswith('{')]
    assert compiler in messages
    build = read(f'{BUILD}.json')
    assert build['command'] == ['/Users/dylan/.cargo/bin/rustup', 'run', '1.99.0', 'cargo', 'test', '--offline', '--locked', '--release', '-p', 'shardloom-vortex', '--features', 'release-user-surfaces', '--lib', '--no-run', '--message-format=json']

    sequence_identity_path = ROOT / f'{LABEL}-sequence-identity.json'
    sequence_identity = read(sequence_identity_path.name)
    assert sequence_identity['label'] == LABEL and sequence_identity['build'] == BUILD
    assert sequence_identity['source_freeze_sha256'] == freeze_sha
    assert sequence_identity['build_receipt_sha256'] == sha(ROOT / f'{BUILD}.json')
    assert sequence_identity['preflight_roles'] == ['off', 'on']
    assert sequence_identity['cohort_order'] == [{'cohort': 'A', 'roles': ['off', 'on']}, {'cohort': 'B', 'roles': ['on', 'off']}]
    for key, name in (
        ('sequence_sha256', 'run_merge_tail_sequence_774.py'),
        ('driver_sha256', 'merge_tail_driver_774.py'),
        ('guard_sha256', 'run_guarded_observed_757.py'),
        ('oracle_sha256', 'analyze_merge_tail_774.py'),
        ('protocol_sha256', 'merge-tail-attribution-protocol-774.json'),
        ('protocol_freeze_sha256', 'merge-tail-protocol-freeze-774.json'),
    ):
        assert sequence_identity[key] == sha(ROOT / name), name
    assert sequence_identity['protocol_sha256'] == PROTOCOL_SHA
    continuation_path = ROOT / 'merge-tail-continuation-identity-775.json'
    continuation = read(continuation_path.name)
    assert continuation['status'] == 'bound_before_retry_of_never_launched_native_step'
    assert continuation['original_sequence_identity_sha256'] == sha(sequence_identity_path)
    assert continuation['source_freeze_sha256'] == freeze_sha
    assert continuation['protocol_sha256'] == PROTOCOL_SHA
    assert continuation['artifact_sha256'] == artifact['artifact_sha256']
    assert continuation['completed_workflows_before_continuation'] == 0
    assert continuation['native_comparison_changed'] is False
    assert continuation['failed_step'] == 'merge-tail-focused-spill-774-a1'
    assert continuation['replacement_step'] == 'merge-tail-focused-spill-774-a2'
    assert [Path(r['path']).name for r in continuation['extra_helpers']] == ['resume_merge_tail_sequence_775.py', 'verify_merge_tail_775.py']
    for row in continuation['extra_helpers']:
        assert sha(row['path']) == row['sha256']
    failure_path = ROOT / 'merge-tail-storage-admission-failure-775.json'
    assert continuation['storage_failure_sha256'] == sha(failure_path)
    failure = read(failure_path.name)
    assert failure['completed_workflows'] == failure['measured_workflows'] == 0
    assert failure['no_child_launched'] is True and failure['cleanup_performed'] is False
    for row in failure['evidence']:
        assert identity(row['path']) == row
    failed = read('merge-tail-focused-spill-774-a1.json')
    assert failed['status'] == 'failed' and failed.get('pid') is None and failed.get('returncode') is None
    assert failed['error'].startswith('StorageGuardError: insufficient free disk:')
    assert not (ROOT / 'merge-tail-focused-spill-774-a1.log').exists()
    resume_binding = read('merge-tail-resume-binding-775-sequence-step.json')
    assert resume_binding['returncode'] == 0 and resume_binding['source_freeze_sha256'] == freeze_sha
    assert resume_binding['protocol_sha256'] == PROTOCOL_SHA
    assert resume_binding['output_sha256'] == sha(ROOT / 'merge-tail-resume-binding-775-sequence-output.log')
    steps = [
        'merge-tail-bind-774-a1', 'merge-tail-focused-spill-774-a2',
        'merge-tail-preflight-off-774-a1', 'merge-tail-preflight-on-774-a1',
        'merge-tail-preflight-check-774-a1',
        'merge-tail-measure-A-off-774-a1', 'merge-tail-measure-A-on-774-a1',
        'merge-tail-measure-B-on-774-a1', 'merge-tail-measure-B-off-774-a1',
        'merge-tail-decision-774-a1', 'merge-tail-final-binding-774-a1',
    ]
    step_receipts = []
    for name in steps:
        receipt = read(f'{name}-sequence-step.json')
        assert receipt['step'] == name and receipt['returncode'] == 0
        assert receipt['source_freeze_sha256'] == freeze_sha
        assert receipt['protocol_sha256'] == PROTOCOL_SHA
        assert receipt['output_sha256'] == sha(ROOT / f'{name}-sequence-output.log')
        step_receipts.append(identity(ROOT / f'{name}-sequence-step.json'))
    guards = [BUILD, *steps[:-1]]
    guard_receipts = []
    for name in guards:
        receipt = read(f'{name}.json')
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] is True and not receipt.get('error')
        assert receipt['head'] == HEAD and receipt['cwd'] == str(REPO)
        assert receipt['driver_sha256'] == sha(ROOT / 'run_guarded_observed_757.py')
        assert receipt['log_sha256'] == sha(ROOT / f'{name}.log')
        assert receipt['environment']['CARGO_TARGET_DIR'] == '/Users/dylan/.cache/shardloom/cargo-target'
        guard_receipts.append(identity(ROOT / f'{name}.json'))
    inventory = (ROOT / f'{LABEL}-test-inventory.txt').read_text().splitlines()
    focused = [line.removesuffix(': test') for line in inventory if line.startswith('local_primitives::prepared_relational::tests::spill_tests::') and line.endswith(': test')]
    log = (ROOT / 'merge-tail-focused-spill-774-a2.log').read_text()
    assert len(focused) == 9
    assert set(re.findall(r'^test (\S+) \.\.\. ok$', log, re.M)) == set(focused)
    assert 'test result: ok. 9 passed; 0 failed; 0 ignored;' in log

    data = ROOT / LABEL
    stream_names, all_records = [], []
    links = []
    runs = [('preflight', role, 'preflight') for role in ('off', 'on')]
    runs += [('measure', role, cohort) for cohort, roles in (('A', ('off', 'on')), ('B', ('on', 'off'))) for role in roles]
    for mode, role, cohort in runs:
        name = f'merge-tail-preflight-{role}-774-a1' if mode == 'preflight' else f'merge-tail-measure-{cohort}-{role}-774-a1'
        link = read(f'{name}-link.json')
        assert link['role'] == role and link['mode'] == mode and link['cohort'] == cohort
        assert link['artifact_sha256'] == artifact['artifact_sha256']
        assert link['source_freeze_sha256'] == freeze_sha and link['protocol_sha256'] == PROTOCOL_SHA
        assert link['protocol_freeze_sha256'] == sequence_identity['protocol_freeze_sha256']
        assert link['driver_sha256'] == sequence_identity['driver_sha256']
        assert link['guard_sha256'] == sequence_identity['guard_sha256']
        assert link['sources_and_artifact_unchanged'] is True and link['returncode'] == 0
        stream = data / f'{mode}-{cohort}-{role}.jsonl'
        assert link['output'] == str(stream) and link['output_sha256'] == sha(stream)
        assert link['output_bytes'] == stream.stat().st_size
        guard = read(f'{name}.json')
        assert guard['command'] == link['command'][link['command'].index('--') + 1:]
        assert guard['command'][-5:] == [driver.SELECTOR, '--exact', '--ignored', '--nocapture', '--test-threads=1']
        stream_names.append(stream.name)
        all_records.extend(json.loads(line) for line in stream.read_text().splitlines())
        links.append(identity(ROOT / f'{name}-link.json'))
    assert len(all_records) == 236
    assert sum(r['warmup'] for r in all_records) == 4
    assert sum(r['cohort'] == 'preflight' for r in all_records) == 40
    assert sum(not r['warmup'] and r['cohort'] != 'preflight' for r in all_records) == 192
    witnesses = {r[key] for r in all_records for key in ('source_rows_witness', 'source_schema_witness', 'expected_rows_witness', 'expected_schema_witness', 'actual_rows_witness', 'actual_schema_witness')}
    expected_files = set(stream_names) | {f'witnesses/{h}.json' for h in witnesses}
    actual_files = set()
    for path in data.rglob('*'):
        assert not path.is_symlink(), path
        if path.is_dir():
            assert path == data / 'witnesses', path
        else:
            assert path.is_file(), path
            actual_files.add(path.relative_to(data).as_posix())
    assert actual_files == expected_files

    decision_path = ROOT / f'{LABEL}-decision.json'
    decision = read(decision_path.name)
    recomputed = oracle.analyze(data)
    assert oracle.typed_equal(decision, recomputed), 'independently recomputed decision changed'
    assert decision['preflight_passed'] is True
    assert decision['production_optimization'] is False and decision['actual_schedule_speedup'] is False
    assert sum(s['workflows'] for s in decision['streams'].values()) == 236
    assert sum(s['operations'] for s in decision['streams'].values()) == 236
    preflight = read(f'{LABEL}-preflight-verification.json')
    expected_preflight = {'protocol_id': oracle.PROTOCOL_ID, 'protocol_sha256': PROTOCOL_SHA, 'validator_sha256': sha(ROOT / 'analyze_merge_tail_774.py'), 'streams': {r: decision['streams'][f'preflight-{r}'] for r in ('off', 'on')}, 'preflight_passed': True, 'production_optimization': False}
    assert oracle.typed_equal(preflight, expected_preflight)
    completion = read(f'{LABEL}-sequence-completion.json')
    assert completion == {'status': 'completed', 'identity_sha256': sha(sequence_identity_path), 'decision_sha256': sha(decision_path), 'decision_scope_result': decision['scope_result'], 'production_optimization': False, 'continuation_identity_sha256': sha(continuation_path)}
    driver.verify_sources(freeze)
    assert artifact['artifact_sha256'] == sha(binary)
    report = {
        'schema_version': 'shardloom.merge_tail_attribution_verification.v1',
        'status': 'passed', 'label': LABEL, 'protocol_sha256': PROTOCOL_SHA,
        'production_head': HEAD, 'total_workflows': 236, 'total_operations': 236,
        'preflight_workflows': 40, 'measured_workflows': 192, 'warmup_workflows': 4,
        'production_optimization': False, 'actual_schedule_speedup': False,
        'scope_result': decision['scope_result'],
        'qualifying_spill_cells': decision['qualifying_spill_cells'],
        'full_content_witnesses': len(witnesses), 'stream_count': len(stream_names),
        'runtime_inputs': len(freeze['sources']), 'helper_inputs': len(freeze['helpers']),
        'focused_spill_tests': focused,
        'source_binding': identity(freeze_path), 'artifact_binding': identity(artifact_path),
        'decision_binding': identity(decision_path), 'sequence_identity': identity(sequence_identity_path),
        'guard_receipts': guard_receipts, 'sequence_steps': step_receipts, 'run_links': links,
        'verifier': identity(Path(__file__)),
        'continuation': identity(continuation_path),
        'storage_admission_refusal': identity(failure_path),
        'comparison_unchanged_across_storage_admission_retry': True,
        'all_complete_values_types_traces_and_decisions_recomputed': True,
        'all_frozen_sources_and_helpers_unchanged': True,
        'all_native_process_groups_drained': True,
        'owned_spill_directories_removed': True,
        'claims': 'Finite attribution only; estimates do not establish executed schedule savings, accepted runtime behavior, Full43 performance or broader owner completion.'
    }
    with output.open('x') as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps({'status': 'passed', 'total_workflows': 236, 'witnesses': len(witnesses), 'scope_result': decision['scope_result'], 'qualifying_spill_cells': decision['qualifying_spill_cells'], 'output': output.name}))


if __name__ == '__main__': main()
