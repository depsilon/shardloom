# Next merge investigation — primary source-grounded draft

Status: design preparation only. No protocol is frozen, no merge observation has
run, and no runtime change is authorized by this draft. The current predicate
candidate retains its independent source freeze and measurement sequence.

## Observed production boundary

`shardloom-vortex/src/local_primitives/native_relational_spill.rs` uses ordinary
`Ordering::flush` (lines 312–347) to create a level-zero sorted run, then merges
the rightmost pair when their levels are equal. `complete_run` (438–450) drains
the remaining stack by repeatedly merging its rightmost adjacent pair. Each
`NativeQueryRun` already records actual rows and serialized bytes. `Merge::winner`
(553–584) chooses the left run on equal keys, so every alternative must merge
adjacent source intervals and preserve their left/right order.

The current `State` owns one query-local store and actual disk quota; each
`Ordering` owns a 128-KiB work lease for two readers. Outputs are written before
the two input runs are removed. A different schedule cannot treat those inputs
as free disk or invent a larger reader/memory grant. Existing spill tests cover
complete stable results, nested quota sharing, overlap refusal, cancellation,
corruption, cleanup and pressure. Their aggregate counters do not reconstruct
the actual run-size vector or stable merge lineage.

## Finite candidate to assess first

Investigate cost-aware scheduling of the already-held final run stack only.
Leave all ingestion-time equal-level merges unchanged. This avoids inventing an
unbounded initial-run collection, a new merge fan-in, or speculative disk space.
For a small bounded tail, an original dynamic program can compute the least
estimated sum of adjacent merged input weights using the existing runs' actual
serialized bytes. An unchanged/rightmost schedule remains the control.

This is a proposed cost estimator, not a claim that file bytes exactly predict
CPU or that merged output encodings are additive. Actual completed candidate
operations would still need engine and complete-workflow comparison. The final
candidate must bound the DP metadata, charge it before allocation, preserve
stable ties, check cancellation and retain all actual store reservations.

## Missing prerequisite and planned evidence

First freeze an attribution protocol on the production source accepted after
the predicate decision. A temporary test-only observer should record each
ordering owner, original run ID/extent, actual rows/bytes, parent IDs, merge phase
(ingestion/final tail), input/output bytes, elapsed merge spans, reader counts,
and existing memory/disk snapshots. Capture the complete final-tail frontier
before its first merge. Every full result, dtype, stable source ordinal, native
certificate and cleanup result must be independently verified.

Use the real prepared relational Sort and collect_jsonl path on bounded complete
results, not a fake merge loop. Include uniform and variable-width payloads,
both width directions, isolated wide head/tail regions, ties/NULLs and an
unspilled control. Freeze row counts, payload formulas, buffer/memory/disk grants,
all cases, warmup, sample order and both cohort orders before any observation.
Compare observer off/on so instrumentation does not become an unacknowledged
cost. No timing or run-size result has selected the eventual thresholds.

The independent checker must reconstruct the baseline adjacent tree from actual
lineage, validate full leaf coverage without overlap/gaps, distinguish measured
merges from the estimated alternative, and account for input/output disk overlap.
Only a predeclared useful tail-cost signal permits candidate implementation.
If the bounded frontier has no useful opportunity, reject that finite mechanism
with the trace; do not claim that all possible merge scheduling is disproved.

## Scope boundaries

The separate numeric query-sort spill implementation has a 2/4/8-reader admission
contract and is outside this first candidate. Derived-owner rematerialization,
automatic spill-strategy selection, crash resume and additional providers remain
separate obligations. Preserve Vortex-native providers, ordinary exact native
execution, and no external engine fallback. A passing candidate comparison is
provisional until the applicable integration acceptance on final sources.
