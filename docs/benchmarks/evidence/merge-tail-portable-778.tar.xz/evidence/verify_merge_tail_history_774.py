"""Reconstruct all frozen Rust/Cargo inputs for the three merge-tail attempts."""
from __future__ import annotations

import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
HEAD = 'd732d7889207e7d8fc0de8d746de1623174c1dcf'
BASE = ROOT / 'merge-tail-accepted-base-sources-774'
OUTPUT = ROOT / 'merge-tail-history-verification-774.json'
VERSIONS = (
    ('771', 23, 'e2ffc917bf17d64bffdc0f27943e86f12345ceaeb29a65ee69d290279eaa6a72'),
    ('773', 28, '081a46278f799945e00a4f1d87fb5c316e2408cfd613c38998acad1c8f190865'),
    ('774', 32, '2db26a89965125f7deb44e644dd28852c475add5944089e486bf8fa8d6aa38bc'),
)
sys.path.insert(0, str(REPO / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for part in iter(lambda: stream.read(1 << 20), b''): value.update(part)
    return value.hexdigest()


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def load(path):
    identity(path)
    return json.loads(Path(path).read_text())


def gate():
    return check_budgets(ROOT, ROOT / 'reserved-artifact', ROOT / 'logs',
                         min_free_bytes=12 * GIB, reserve_bytes=128 * MIB,
                         max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)


def source_name(name):
    return name.endswith('.rs') or Path(name).name in ('Cargo.toml', 'Cargo.toml.orig', 'Cargo.lock')


def check_row(path, row):
    got = identity(path)
    assert got['bytes'] == row['bytes'] and got['sha256'] == row['sha256'], path


def main():
    require_local_path(ROOT, Path.home(), sys.platform)
    assert not BASE.exists() and not OUTPUT.exists()
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == HEAD
    before = gate()
    names = sorted(n for n in subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', HEAD], cwd=REPO, text=True).splitlines() if source_name(n))
    assert len(names) == 1899
    raw = subprocess.check_output(['git', 'archive', '--format=tar', HEAD, '--', *names], cwd=REPO)
    assert len(raw) <= 64 * MIB
    BASE.mkdir()
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:') as archive:
        members = archive.getmembers()
        files = [m for m in members if m.isfile()]
        assert len({m.name for m in files}) == len(files) and sorted(m.name for m in files) == names
        assert all(m.isdir() or m.isfile() for m in members)
        for m in files:
            assert not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
            path = BASE / m.name
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('xb') as stream: stream.write(archive.extractfile(m).read())
    base_rows = [dict(path=n, bytes=(BASE / n).stat().st_size, sha256=sha(BASE / n)) for n in names]
    base_inventory = ROOT / 'merge-tail-accepted-base-774.json'
    assert not base_inventory.exists()
    with base_inventory.open('x') as stream:
        json.dump(dict(head=HEAD, sources=base_rows, git_archive_sha256=hashlib.sha256(raw).hexdigest()), stream, indent=2)
        stream.write('\n')
    del raw
    versions = []
    for version, helper_count, protocol_sha in VERSIONS:
        gate()
        label = f'merge-tail-attribution-{version}-a1'
        freeze_path = ROOT / f'{label}-source-freeze.json'
        freeze = load(freeze_path)
        assert freeze['head'] == HEAD and freeze['protocol_sha256'] == protocol_sha
        assert len(freeze['sources']) == 1901 and len(freeze['helpers']) == helper_count
        patch = ROOT / f'{label}-tracked.patch'
        assert sha(patch) == freeze['patch_sha256']
        allowed = set(names)
        patch_paths = []
        for line in patch.read_text().splitlines():
            if line.startswith('diff --git '):
                fields = line.split()
                assert len(fields) == 4 and fields[2].startswith('a/') and fields[3].startswith('b/')
                left, right = fields[2][2:], fields[3][2:]
                assert left == right and left in allowed
                patch_paths.append(left)
        assert set(patch_paths) == ({'shardloom-vortex/src/local_primitive_relational_tests.rs', 'shardloom-vortex/src/local_primitives/native_relational_spill.rs'} | ({'shardloom-vortex/src/local_primitive_prepared_relational.rs'} if version == '774' else set()))
        extra_root = ROOT / f'{label}-extra-sources'
        extras = sorted(p.relative_to(extra_root).as_posix() for p in extra_root.rglob('*') if p.is_file())
        assert not any(p.is_symlink() for p in extra_root.rglob('*'))
        assert extras == sorted(freeze['extra_sources']) and set(extras).isdisjoint(names)
        assert set(names) | set(extras) == {r['path'] for r in freeze['sources']}
        with tempfile.TemporaryDirectory(prefix=f'merge-history-{version}-', dir=ROOT) as tmp:
            stage = Path(tmp) / 'source'
            shutil.copytree(BASE, stage)
            subprocess.run(['git', 'apply', '--check', '--', str(patch)], cwd=stage, check=True, capture_output=True)
            subprocess.run(['git', 'apply', '--whitespace=nowarn', '--', str(patch)], cwd=stage, check=True, capture_output=True)
            for name in extras:
                target = stage / name
                assert not target.exists()
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(extra_root / name, target)
            actual = sorted(p.relative_to(stage).as_posix() for p in stage.rglob('*') if p.is_file())
            assert actual == sorted(r['path'] for r in freeze['sources'])
            for row in freeze['sources']: check_row(stage / row['path'], row)
        helpers = []
        for row in freeze['helpers']:
            original = Path(row['path'])
            path = original
            if version == '773' and original == REPO / 'docs/architecture/native-merge-tail-design-2026-10-19.md':
                path = ROOT / 'merge-tail-design-v2-preserved-773.md'
            check_row(path, row)
            helpers.append(dict(original_path=str(original), retained=identity(path)))
        versions.append(dict(label=label, source_freeze=identity(freeze_path), patch=identity(patch), runtime_inputs=1901, all_runtime_inputs_reconstructed_from_accepted_base_patch_and_extras=True, helpers=helpers))
    failures = []
    for filename in ('merge-tail-protocol-admission-failure-772.json', 'merge-tail-collector-admission-failure-773.json'):
        path = ROOT / filename
        record = load(path)
        assert record['completed_workflows'] == record['measured_workflows'] == 0
        assert record['engine_measurement_available'] is False and record['process_group_drained'] is True
        for name, row in record['evidence'].items(): check_row(ROOT / name, row)
        for row in record.get('failed_data_files', []): check_row(ROOT / row['path'], row)
        for name in record.get('retained_empty_directories', []):
            directory = ROOT / name
            assert directory.is_dir() and not directory.is_symlink() and not any(directory.iterdir())
        failures.append(identity(path))
    result = dict(schema_version='shardloom.merge_tail_history_verification.v1', status='passed', production_head=HEAD, base=identity(base_inventory), base_directory=str(BASE), versions=versions, invalid_attempts=failures, failed_attempts_receive_no_workflow_or_decision_credit=True, verifier=identity(Path(__file__)), storage_before=before, storage_after=gate())
    with OUTPUT.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    gate()
    print(json.dumps(dict(status='passed', base_sources=len(names), reconstructed_versions=len(versions), runtime_inputs_per_version=1901, retained_failed_attempts=2, output=str(OUTPUT))))


if __name__ == '__main__': main()
