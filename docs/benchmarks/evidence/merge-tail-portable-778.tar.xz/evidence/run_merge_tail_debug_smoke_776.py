"""Validate both complete debug preflight roles without performance decision credit."""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    spec = importlib.util.spec_from_file_location('merge_sequence', ROOT / 'run_merge_tail_sequence_776.py')
    seq = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(seq)
    label = 'merge-tail-debug-smoke-776-a1'
    build_name = 'merge-tail-debug-build-776-a1'
    freeze = ROOT / f'{seq.LABEL}-source-freeze.json'
    build_path = ROOT / f'{build_name}.json'
    build = json.loads(build_path.read_text())
    assert build['status'] == 'passed' and build['returncode'] == 0 and build['process_group_drained'] is True
    assert seq.sha(ROOT / f'{build_name}.log') == build['log_sha256']
    assert '--release' not in build['command'] and '--no-run' in build['command']
    data = ROOT / label
    assert not data.exists() and not (ROOT / f'{label}-test').exists()
    identity = dict(protocol_sha256=seq.sha(seq.PROTOCOL), source_freeze_sha256=seq.sha(freeze),
                    sequence_sha256=seq.sha(__file__), build_receipt_sha256=seq.sha(build_path),
                    label=label, decision_credit=False, role_order=['off', 'on'])
    identity_path = ROOT / f'{label}-identity.json'
    seq.save(identity_path, identity)
    name = 'merge-tail-debug-bind-776-a1'
    seq.run_step(name, seq.guarded(name, [seq.PYTHON, '-B', str(seq.DRIVER), 'bind',
                 '--label', label, '--build', build_name]), freeze)
    binary = ROOT / f'{label}-test'
    name = 'merge-tail-debug-focused-spill-776-a1'
    seq.run_step(name, seq.guarded(name, [str(binary),
                 'local_primitives::prepared_relational::tests::spill_tests::',
                 '--nocapture', '--test-threads=1']), freeze)
    assert 'test result: ok. 9 passed; 0 failed; 0 ignored;' in (ROOT / f'{name}.log').read_text()
    for role in ('off', 'on'):
        name = f'merge-tail-debug-preflight-{role}-776-a1'
        seq.run_step(name, [seq.PYTHON, '-B', str(seq.DRIVER), 'run', '--label', label,
                     '--name', name, '--mode', 'preflight', '--role', role,
                     '--cohort', 'preflight', '--data', label], freeze)
    checked = ROOT / f'{label}-preflight-verification.json'
    name = 'merge-tail-debug-preflight-check-776-a1'
    seq.run_step(name, seq.guarded(name, [seq.PYTHON, '-B', str(seq.ORACLE), 'preflight',
                 '--data', str(data), '--output', str(checked)]), freeze)
    report = json.loads(checked.read_text())
    assert report['preflight_passed'] is True and report['protocol_sha256'] == identity['protocol_sha256']
    assert sum(r['workflows'] for r in report['streams'].values()) == 40
    assert sum(r['operations'] for r in report['streams'].values()) == 40
    name = 'merge-tail-debug-final-binding-776-a1'
    seq.run_step(name, [seq.PYTHON, '-B', str(seq.DRIVER), 'verify', '--label', label], freeze)
    assert seq.sha(__file__) == identity['sequence_sha256']
    seq.save(ROOT / f'{label}-completion.json', dict(status='passed',
             identity_sha256=seq.sha(identity_path), preflight_verification_sha256=seq.sha(checked),
             protocol_sha256=identity['protocol_sha256'], source_freeze_sha256=identity['source_freeze_sha256'],
             artifact_receipt_sha256=seq.sha(ROOT / f'{label}-artifact.json'),
             total_workflows=40, total_operations=40, focused_spill_tests=9,
             measured_workflows=0, decision_credit=False, production_optimization=False))
    print('PASS complete debug preflight; no timing comparison or decision credit.', flush=True)


if __name__ == '__main__': main()
