"""Package the completed merge-tail attribution evidence without rerunning it."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import lzma
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019')
REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
LOCALDATA = Path('/Users/dylan/LocalData/shardloom')
DEST = ROOT / 'merge-tail-portable-772'
NAME = 'merge-tail-portable-772'
LABEL = 'merge-tail-attribution-771-a1'
BUILD = 'merge-tail-build-771-a1'
PROTOCOL = ROOT / 'merge-tail-attribution-protocol-771.json'
PROTOCOL_FREEZE = ROOT / 'merge-tail-protocol-freeze-771.json'
SOURCE_FREEZE = ROOT / f'{LABEL}-source-freeze.json'
ARTIFACT_RECEIPT = ROOT / f'{LABEL}-artifact.json'
ARTIFACT = ROOT / f'{LABEL}-test'
BUILD_RECEIPT = ROOT / f'{BUILD}.json'
SEQUENCE_IDENTITY = ROOT / f'{LABEL}-sequence-identity.json'
SEQUENCE_COMPLETION = ROOT / f'{LABEL}-sequence-completion.json'
DECISION = ROOT / f'{LABEL}-decision.json'
DATA = ROOT / LABEL
VERIFICATION = ROOT / 'merge-tail-verification-772.json'
EXPECTED_HEAD = 'd732d7889207e7d8fc0de8d746de1623174c1dcf'
EXPECTED_PROTOCOL_SHA256 = 'e2ffc917bf17d64bffdc0f27943e86f12345ceaeb29a65ee69d290279eaa6a72'
EXPECTED_STEPS = (
    'merge-tail-bind-771-a1', 'merge-tail-focused-spill-771-a1',
    'merge-tail-preflight-off-771-a1', 'merge-tail-preflight-on-771-a1',
    'merge-tail-preflight-check-771-a1', 'merge-tail-measure-A-off-771-a1',
    'merge-tail-measure-A-on-771-a1', 'merge-tail-measure-B-on-771-a1',
    'merge-tail-measure-B-off-771-a1', 'merge-tail-decision-771-a1',
    'merge-tail-final-binding-771-a1',
)
RAW_STREAMS = (
    'preflight-preflight-off.jsonl', 'preflight-preflight-on.jsonl',
    'measure-A-off.jsonl', 'measure-A-on.jsonl',
    'measure-B-off.jsonl', 'measure-B-on.jsonl',
)

sys.path.insert(0, str(REPO / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def encode_json(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def identity(path: Path) -> dict[str, object]:
    path = Path(path)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha256_file(path)}


def read_json(path: Path) -> dict:
    assert path.is_file() and not path.is_symlink(), path
    value = json.loads(path.read_text())
    assert isinstance(value, dict), path
    return value


def add_file(members: dict[str, Path], name: str, source: Path) -> None:
    source = Path(source)
    assert source.is_file() and not source.is_symlink(), source
    assert name and not name.startswith('/') and '..' not in Path(name).parts, name
    old = members.get(name)
    assert old is None or old.resolve() == source.resolve(), f'duplicate member {name}'
    members[name] = source


def archive_path(path: Path) -> str:
    path = Path(path).resolve(strict=True)
    if path.is_relative_to(ROOT):
        return 'evidence/' + path.relative_to(ROOT).as_posix()
    if path.is_relative_to(REPO):
        return 'repo/' + path.relative_to(REPO).as_posix()
    if path.is_relative_to(LOCALDATA):
        return 'local/' + path.relative_to(LOCALDATA).as_posix()
    raise AssertionError(f'path outside approved roots: {path}')


def add_tree(members: dict[str, Path], root: Path, member_root: str) -> list[Path]:
    assert root.is_dir() and not root.is_symlink(), root
    paths = []
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_dir():
            continue
        assert path.is_file(), path
        relative = path.relative_to(root).as_posix()
        add_file(members, f'{member_root}/{relative}', path)
        paths.append(path)
    return paths


def validate_verification() -> tuple[dict, dict, dict]:
    protocol = read_json(PROTOCOL)
    freeze_receipt = read_json(PROTOCOL_FREEZE)
    verification = read_json(VERIFICATION)
    assert protocol.get('schema_version') == 'shardloom.merge_tail_attribution_protocol.v1'
    assert protocol.get('protocol_id') == 'merge-tail-attribution-771-v1'
    assert protocol.get('production_commit') == EXPECTED_HEAD
    assert sha256_file(PROTOCOL) == EXPECTED_PROTOCOL_SHA256
    assert freeze_receipt == {
        'protocol': str(PROTOCOL), 'sha256': EXPECTED_PROTOCOL_SHA256,
        'bytes': PROTOCOL.stat().st_size, 'production_commit': EXPECTED_HEAD,
        'status': 'frozen_before_observer_harness_and_measurement',
    }
    assert verification.get('status') == 'passed'
    assert verification.get('label') == LABEL
    assert verification.get('protocol_sha256') == EXPECTED_PROTOCOL_SHA256
    for key, value in {
        'total_workflows': 236, 'total_operations': 236,
        'preflight_workflows': 40, 'measured_workflows': 192,
        'warmup_workflows': 4, 'production_optimization': False,
    }.items():
        assert verification.get(key) == value, (key, verification.get(key))
    assert verification.get('scope_result') in ('material_signal', 'no_signal')
    review = read_json(ROOT / 'merge-tail-primary-review-772.json')
    test_log = ROOT / 'merge-tail-oracle-final-tests-772.log'
    assert review.get('status') == 'reviewed_before_source_freeze_build_or_measurement'
    assert review.get('protocol_sha256') == EXPECTED_PROTOCOL_SHA256
    assert sha256_file(test_log) == review.get('checks', {}).get('test_log_sha256')
    for name, expected in review.get('reviewed_files', {}).items():
        path = ROOT / name
        assert path.is_file() and not path.is_symlink(), path
        assert path.stat().st_size == expected['bytes']
        assert sha256_file(path) == expected['sha256']
    for name, expected in review.get('preserved_worker_drafts', {}).items():
        path = ROOT / name
        assert path.is_file() and not path.is_symlink(), path
        assert path.stat().st_size == expected['bytes']
        assert sha256_file(path) == expected['sha256']
    return protocol, freeze_receipt, verification


def validate_frozen_inputs() -> tuple[dict, dict, dict]:
    freeze = read_json(SOURCE_FREEZE)
    artifact_receipt = read_json(ARTIFACT_RECEIPT)
    build = read_json(BUILD_RECEIPT)
    assert freeze.get('head') == EXPECTED_HEAD
    assert freeze.get('protocol_sha256') == EXPECTED_PROTOCOL_SHA256
    assert freeze.get('protocol_freeze_sha256') == sha256_file(PROTOCOL_FREEZE)
    assert artifact_receipt.get('build') == BUILD
    assert artifact_receipt.get('build_receipt_sha256') == sha256_file(BUILD_RECEIPT)
    assert artifact_receipt.get('source_freeze_sha256') == sha256_file(SOURCE_FREEZE)
    assert artifact_receipt.get('artifact') == str(ARTIFACT)
    assert artifact_receipt.get('bytes') == ARTIFACT.stat().st_size
    assert artifact_receipt.get('artifact_sha256') == sha256_file(ARTIFACT)
    assert build.get('status') == 'passed' and build.get('returncode') == 0
    assert build.get('process_group_drained') is True
    assert sha256_file(BUILD_RECEIPT.with_suffix('.log')) == build.get('log_sha256')

    patch = ROOT / f'{LABEL}-tracked.patch'
    assert sha256_file(patch) == freeze.get('patch_sha256')
    declared = set(freeze.get('extra_sources', []))
    extra_root = ROOT / f'{LABEL}-extra-sources'
    assert extra_root.is_dir() and not extra_root.is_symlink()
    actual = set()
    for path in extra_root.rglob('*'):
        assert not path.is_symlink(), path
        if path.is_file():
            actual.add(path.relative_to(extra_root).as_posix())
    assert actual == declared
    source_rows = {row['path']: row for row in freeze.get('sources', [])}
    assert declared <= source_rows.keys()
    for relative in sorted(declared):
        path = extra_root / relative
        row = source_rows[relative]
        assert path.stat().st_size == row['bytes'] and sha256_file(path) == row['sha256']

    current_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    assert current_head == EXPECTED_HEAD
    current_sources = subprocess.check_output(
        ['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=REPO, text=True
    ).splitlines()
    current_sources = sorted(path for path in set(current_sources)
                             if path.endswith('.rs') or Path(path).name in
                             ('Cargo.toml', 'Cargo.toml.orig', 'Cargo.lock'))
    assert current_sources == [row['path'] for row in freeze.get('sources', [])]
    for row in freeze['sources']:
        path = REPO / row['path']
        assert path.is_file() and not path.is_symlink()
        assert path.stat().st_size == row['bytes'] and sha256_file(path) == row['sha256']
    for helper in freeze.get('helpers', []):
        path = Path(helper['path'])
        assert path.is_file() and not path.is_symlink()
        assert path.stat().st_size == helper['bytes'] and sha256_file(path) == helper['sha256']
    assert len(freeze.get('helpers', [])) == 23
    return freeze, artifact_receipt, build


def expected_top_level() -> set[str]:
    names = {
        PROTOCOL.name, PROTOCOL_FREEZE.name, SOURCE_FREEZE.name,
        ARTIFACT_RECEIPT.name, f'{LABEL}-test-inventory.txt', f'{LABEL}-tracked.patch',
        BUILD_RECEIPT.name, BUILD_RECEIPT.with_suffix('.log').name,
        SEQUENCE_IDENTITY.name, SEQUENCE_COMPLETION.name, DECISION.name,
        f'{LABEL}-preflight-verification.json', VERIFICATION.name,
        'merge-tail-primary-review-772.json', 'merge-tail-oracle-final-tests-772.log',
        'merge_tail_driver_771.py', 'run_merge_tail_sequence_771.py',
        'run_merge_tail_sequence_before_primary_review_771.py',
        'analyze_merge_tail_771.py', 'analyze_merge_tail_771_before_primary_review_771.py',
        'test_merge_tail_oracle_771.py', 'test_merge_tail_oracle_771_before_primary_review_771.py',
        'package_merge_tail_772.py', 'verify_merge_tail_772.py',
    }
    for step in EXPECTED_STEPS:
        names.update((f'{step}-sequence-step.json', f'{step}-sequence-output.log'))
        if step != 'merge-tail-final-binding-771-a1':
            names.update((f'{step}.json', f'{step}.log'))
        if step.startswith(('merge-tail-preflight-off-', 'merge-tail-preflight-on-',
                            'merge-tail-measure-')):
            names.add(f'{step}-link.json')
    return names


def build_members(freeze: dict) -> tuple[dict[str, Path], dict[str, object]]:
    members: dict[str, Path] = {}
    top_names = expected_top_level()
    related_top_level = {path.name for path in ROOT.iterdir()
                         if path.is_file() and path.name.startswith(('merge-tail', 'merge_tail'))}
    assert related_top_level <= top_names, (
        'unallowlisted merge-tail evidence files present: '
        f'{sorted(related_top_level - top_names)}')
    for name in sorted(top_names):
        path = ROOT / name
        add_file(members, archive_path(path), path)

    # The receipt's helper closure is authoritative, and carries all 14 guard
    # transitive dependency files at the frozen paths and hashes.
    for row in freeze.get('helpers', []):
        path = Path(row['path'])
        assert path.stat().st_size == row['bytes'] and sha256_file(path) == row['sha256']
        add_file(members, archive_path(path), path)
    add_file(members, archive_path(Path(__file__)), Path(__file__))

    extra_root = ROOT / f'{LABEL}-extra-sources'
    extras = add_tree(members, extra_root, 'sources/extra')
    assert len(extras) == len(freeze['extra_sources'])

    assert DATA.is_dir() and not DATA.is_symlink()
    data_files = []
    for path in DATA.rglob('*'):
        assert not path.is_symlink(), path
        if path.is_dir():
            continue
        assert path.is_file(), path
        data_files.append(path)
    streams = sorted(path for path in data_files if path.parent == DATA and path.suffix == '.jsonl')
    assert {path.name for path in streams} == set(RAW_STREAMS)
    witness_root = DATA / 'witnesses'
    assert witness_root.is_dir() and not witness_root.is_symlink()
    witnesses = sorted(path for path in data_files if path.parent == witness_root and path.suffix == '.json')
    assert len(witnesses) == len([p for p in data_files if p.parent == witness_root])
    for path in witnesses:
        digest = path.stem
        assert len(digest) == 64 and all(c in '0123456789abcdef' for c in digest)
        assert sha256_file(path) == digest, path
    expected_data_files = set(streams + witnesses)
    assert set(data_files) == expected_data_files, 'unknown data file in raw evidence tree'
    for path in sorted(expected_data_files):
        add_file(members, 'raw-evidence/' + path.relative_to(DATA).as_posix(), path)

    return members, {
        'top_level_allowlist': sorted(top_names),
        'extra_source_files': [str(path) for path in extras],
        'raw_streams': [str(path) for path in streams],
        'content_addressed_witnesses': [str(path) for path in witnesses],
        'witness_count': len(witnesses),
        'frozen_helpers': [row['path'] for row in freeze['helpers']],
    }


def validate_sequence() -> dict:
    identity_value = read_json(SEQUENCE_IDENTITY)
    completion = read_json(SEQUENCE_COMPLETION)
    assert completion.get('status') == 'completed'
    assert completion.get('production_optimization') is False
    assert completion.get('identity_sha256') == sha256_file(SEQUENCE_IDENTITY)
    assert completion.get('decision_sha256') == sha256_file(DECISION)
    decision = read_json(DECISION)
    assert decision.get('scope_result') in ('material_signal', 'no_signal')
    assert decision.get('production_optimization') is False
    assert identity_value.get('label') == LABEL and identity_value.get('build') == BUILD
    assert identity_value.get('protocol_sha256') == EXPECTED_PROTOCOL_SHA256
    assert identity_value.get('source_freeze_sha256') == sha256_file(SOURCE_FREEZE)
    for key, path in (
        ('sequence_sha256', ROOT / 'run_merge_tail_sequence_771.py'),
        ('driver_sha256', ROOT / 'merge_tail_driver_771.py'),
        ('guard_sha256', ROOT / 'run_guarded_observed_757.py'),
        ('oracle_sha256', ROOT / 'analyze_merge_tail_771.py'),
        ('protocol_freeze_sha256', PROTOCOL_FREEZE),
    ):
        assert identity_value.get(key) == sha256_file(path), key
    for step in EXPECTED_STEPS:
        step_receipt = read_json(ROOT / f'{step}-sequence-step.json')
        assert step_receipt.get('returncode') == 0
        assert step_receipt.get('protocol_sha256') == EXPECTED_PROTOCOL_SHA256
        output = ROOT / f'{step}-sequence-output.log'
        assert sha256_file(output) == step_receipt.get('output_sha256')
        if step == 'merge-tail-final-binding-771-a1':
            continue
        guard_receipt_path = ROOT / f'{step}.json'
        guard_receipt = read_json(guard_receipt_path)
        assert guard_receipt.get('status') == 'passed' and guard_receipt.get('returncode') == 0
        assert guard_receipt.get('process_group_drained') is True
        assert sha256_file(guard_receipt_path.with_suffix('.log')) == guard_receipt.get('log_sha256')
        if step.endswith(('-off-771-a1', '-on-771-a1')) and ('preflight' in step or 'measure-' in step):
            link = read_json(ROOT / f'{step}-link.json')
            assert link.get('returncode') == 0 and link.get('sources_and_artifact_unchanged') is True
            assert link.get('artifact_sha256') == sha256_file(ARTIFACT)
    preflight = read_json(ROOT / f'{LABEL}-preflight-verification.json')
    assert preflight.get('preflight_passed') is True
    assert preflight.get('protocol_sha256') == EXPECTED_PROTOCOL_SHA256
    assert sum(row['workflows'] for row in preflight['streams'].values()) == 40
    assert sum(row['operations'] for row in preflight['streams'].values()) == 40
    return decision


def main() -> None:
    argparse.ArgumentParser(description=__doc__).parse_args()
    assert not DEST.exists(), f'refusing to overwrite destination {DEST}'
    require_local_path(ROOT, Path.home(), sys.platform)
    require_local_path(DEST, Path.home(), sys.platform)
    _, _, verification = validate_verification()
    freeze, artifact_receipt, build = validate_frozen_inputs()
    decision = validate_sequence()
    assert decision['scope_result'] == verification['scope_result']

    # Reject symlinks and unknown files in the exact frozen extra-source and
    # raw-evidence trees; unrelated concurrent evidence directories remain untouched.
    members, coverage = build_members(freeze)
    inventory = []
    frozen = {}
    for member_name, source in sorted(members.items()):
        data = source.read_bytes()
        row = {'path': member_name, 'original_path': str(source),
               'bytes': len(data), 'sha256': sha256_bytes(data)}
        inventory.append(row)
        frozen[member_name] = (row['bytes'], row['sha256'])
    assert inventory
    assert str(ARTIFACT) not in {row['original_path'] for row in inventory}

    storage_before = check_budgets(ROOT, DEST, ROOT,
                                   min_free_bytes=12 * GIB, reserve_bytes=128 * MIB,
                                   max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    assert not DEST.exists()
    DEST.mkdir()
    archive_path_out = DEST / f'{NAME}.tar.xz'
    with tarfile.open(archive_path_out, mode='x:xz', format=tarfile.PAX_FORMAT, preset=6) as archive:
        for row in inventory:
            source = members[row['path']]
            data = source.read_bytes()
            assert (len(data), sha256_bytes(data)) == (row['bytes'], row['sha256'])
            info = tarfile.TarInfo(row['path'])
            info.size, info.mode = len(data), 0o644
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            info.mtime = 0
            archive.addfile(info, io.BytesIO(data))
    with tarfile.open(archive_path_out, mode='r:xz') as archive:
        assert archive.getnames() == [row['path'] for row in inventory]
        for row in inventory:
            member = archive.extractfile(row['path'])
            assert member is not None
            content = member.read()
            assert (len(content), sha256_bytes(content)) == (row['bytes'], row['sha256'])
    for member_name, source in members.items():
        assert (source.stat().st_size, sha256_file(source)) == frozen[member_name]

    manifest = {'schema_version': 'shardloom.evidence_member_manifest.v1',
                'all_members_reopened': True, 'members': inventory}
    manifest_out = DEST / f'{NAME}.manifest.json.xz'
    with manifest_out.open('xb') as stream:
        stream.write(lzma.compress(encode_json(manifest), preset=6))
    assert json.loads(lzma.decompress(manifest_out.read_bytes())) == manifest
    index = {
        'schema_version': 'shardloom.merge_tail_portable_packet.v1', 'status': 'passed',
        'scope_result': verification['scope_result'], 'production_optimization': False,
        'claim_boundary': 'Merge-tail attribution evidence only; no production optimization or actual schedule speedup claim.',
        'head': EXPECTED_HEAD, 'protocol': identity(PROTOCOL),
        'protocol_freeze': identity(PROTOCOL_FREEZE), 'verification': identity(VERIFICATION),
        'source_freeze': identity(SOURCE_FREEZE), 'artifact_receipt': identity(ARTIFACT_RECEIPT),
        'build_receipt': identity(BUILD_RECEIPT), 'tracked_patch': identity(ROOT / f'{LABEL}-tracked.patch'),
        'sequence_identity': identity(SEQUENCE_IDENTITY), 'sequence_completion': identity(SEQUENCE_COMPLETION),
        'decision': identity(DECISION), 'preflight': identity(ROOT / f'{LABEL}-preflight-verification.json'),
        'measured_scope': {key: verification[key] for key in
                           ('total_workflows', 'total_operations', 'preflight_workflows',
                            'measured_workflows', 'warmup_workflows', 'scope_result')},
        'coverage': coverage, 'artifact_omitted': {'path': str(ARTIFACT),
            'bytes': artifact_receipt['bytes'], 'sha256': artifact_receipt['artifact_sha256'],
            'reason': 'compiled native executable excluded; reproduction evidence retained',
            'build_command': build.get('command')},
        'storage_check': {'guard': 'local_uat_storage.require_local_path and check_budgets',
            'before_write': storage_before, 'limits': {'minimum_free_bytes': 12 * GIB,
                'candidate_reserve_bytes': 128 * MIB, 'maximum_workspace_bytes': 100 * GIB,
                'maximum_log_bytes': 192 * MIB}},
        'member_count': len(inventory), 'uncompressed_bytes': sum(row['bytes'] for row in inventory),
        'all_members_reopened': True,
        'archive': {'file': archive_path_out.name, 'bytes': archive_path_out.stat().st_size,
                    'sha256': sha256_file(archive_path_out)},
        'manifest': {'file': manifest_out.name, 'bytes': manifest_out.stat().st_size,
                     'sha256': sha256_file(manifest_out)},
    }
    with (DEST / f'{NAME}.json').open('xb') as stream:
        stream.write(encode_json(index))
    check_budgets(ROOT, DEST, ROOT, min_free_bytes=12 * GIB, reserve_bytes=0,
                  max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    print(json.dumps({'status': 'passed', 'members': len(inventory),
                      'scope_result': verification['scope_result'],
                      'archive': index['archive'], 'manifest': index['manifest'],
                      'index': str(DEST / f'{NAME}.json'), 'all_members_reopened': True}))


if __name__ == '__main__':
    main()
