#!/usr/bin/env python3
"""Independent offline validator and interval-DP analyzer for merge-tail protocol 776."""
from __future__ import annotations

import argparse
import functools
import hashlib
import json
import statistics
from pathlib import Path
from typing import Any

ROOT = Path(__file__).parent
PROTOCOL = ROOT / "merge-tail-attribution-protocol-776.json"
PROTOCOL_SHA256 = "111f66f588ae5f388170ce8b906f80fff21ba64d20e41e59eb7bf3df467fccf7"
PROTOCOL_ID = "merge-tail-attribution-776-v4"
ROWS = (16383, 32767)
PROFILES = ("uniform24", "uniform256", "quarters_up", "quarters_down", "wide_head", "wide_tail", "alternating")
SAMPLES = (0, 1, 2)
MARKER_BYTES = 32768
MEMORY_LIMIT = 67108864
DISK_QUOTA = 134217728
SPILL_BUFFER = 1048576
READER_WORK = 131072
MAX_READERS = 2
SOURCE_SCHEMA = {"Struct": [{"names": ["k", "tie", "ordinal", "payload"], "dtypes": [{"Primitive": ["i64", True]}, {"Primitive": ["i64", True]}, {"Primitive": ["i64", False]}, {"Utf8": True}]}, False]}


class Invalid(ValueError):
    pass


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def need(condition: bool, message: str) -> None:
    if not condition:
        raise Invalid(message)


def integer(value: Any, label: str, minimum: int = 0) -> int:
    need(type(value) is int and value >= minimum, f"{label} must be an integer >= {minimum}")
    return value


def typed_equal(a: Any, b: Any) -> bool:
    if type(a) is not type(b): return False
    if isinstance(b, dict): return a.keys() == b.keys() and all(typed_equal(a[k], b[k]) for k in b)
    if isinstance(b, list): return len(a) == len(b) and all(typed_equal(x, y) for x, y in zip(a, b))
    return a == b


def matrix() -> list[tuple[int, str, bool]]:
    return [(n, p, True) for n in ROWS for p in PROFILES] + [(8192, "uniform24", False), (32767, "uniform24", False)]


def cell_id(rows: int, profile: str, spill: bool) -> str:
    return f"{rows}-{profile}-{'spill' if spill else 'resident'}"


def width_for(rows: int, profile: str, r: int) -> int:
    if profile == "uniform24": return 24
    if profile == "uniform256": return 256
    if profile in ("quarters_up", "quarters_down"):
        idx = min(3, 4 * r // rows)
        return ([24, 64, 256, 512] if profile == "quarters_up" else [512, 256, 64, 24])[idx]
    if profile == "wide_head": return 512 if r < rows // 16 else 24
    if profile == "wide_tail": return 512 if r >= rows - rows // 16 else 24
    if profile == "alternating": return 24 if (r // 1024) % 2 == 0 else 512
    raise Invalid(f"unknown profile {profile}")


def source_rows(rows: int, profile: str) -> list[dict[str, Any]]:
    result = []
    for r in range(rows):
        key = None if r % 17 == 0 else (37 * r % 257) - 128
        tie = None if r % 13 == 0 else r % 7
        payload = None
        if r % 31 != 0:
            payload = f"{r:08}:" + chr(ord("a") + r % 23) * (width_for(rows, profile, r) - 9)
        result.append({"k": key, "tie": tie, "ordinal": r, "payload": payload})
    return result


def cmp_nullable(a: int | None, b: int | None, descending: bool, nulls_first: bool) -> int:
    if a is None and b is None: return 0
    if a is None: return -1 if nulls_first else 1
    if b is None: return 1 if nulls_first else -1
    cmp = (a > b) - (a < b)
    return -cmp if descending else cmp


def expected_output(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    def cmp(a: dict[str, Any], b: dict[str, Any]) -> int:
        first = cmp_nullable(a["k"], b["k"], False, False)
        return first or cmp_nullable(a["tie"], b["tie"], True, True)
    return sorted(rows, key=functools.cmp_to_key(cmp))  # Python's stable sort preserves source ordinal ties.


def witness(data: Path, ref: Any, expected: Any, label: str) -> Any:
    need(isinstance(ref, str) and len(ref) == 64 and all(c in "0123456789abcdef" for c in ref), f"malformed witness identity: {label}")
    p = data / "witnesses" / f"{ref}.json"
    need(p.is_file() and not p.is_symlink(), f"missing or linked witness: {label}")
    raw = p.read_bytes()
    need(digest(raw) == ref, f"witness raw SHA-256 mismatch: {label}")
    try: actual = json.loads(raw)
    except Exception as e: raise Invalid(f"invalid witness JSON {label}: {e}") from e
    need(typed_equal(actual, expected), f"witness values or types differ: {label}")
    return actual


def _snap(value: Any, label: str) -> dict[str, int]:
    keys = {"live_disk_bytes", "peak_disk_bytes", "runs_written", "runs_validated"}
    need(isinstance(value, dict) and value.keys() == keys, f"{label}: malformed store snapshot")
    return {k: integer(value[k], f"{label}.{k}") for k in keys}


def _snapshot_matches(actual: dict[str, int], expected: dict[str, int], label: str) -> None:
    for key in ("live_disk_bytes", "peak_disk_bytes", "runs_written"):
        need(actual[key] == expected[key], f"{label}.{key} differs from replay")
    # Validation may advance while readers open or validate runs between trace events.
    need(actual["runs_validated"] >= expected["runs_validated"], f"{label}.runs_validated decreased")


def _run(value: Any, label: str, source_rows: int, block_rows: int) -> dict[str, Any]:
    keys = {"id", "rows", "bytes", "level", "start", "end", "block_rows"}
    need(isinstance(value, dict) and value.keys() == keys, f"{label}: malformed run descriptor")
    need(isinstance(value["id"], str) and value["id"], f"{label}: invalid run id")
    for key in ("rows", "bytes", "block_rows"):
        integer(value[key], f"{label}.{key}", 1)
    for key in ("level", "start", "end"):
        integer(value[key], f"{label}.{key}")
    need(value["start"] < value["end"] <= source_rows and value["end"] - value["start"] == value["rows"], f"{label}: invalid source interval")
    need(value["level"] <= 63 and value["block_rows"] == block_rows, f"{label}: level/block bounds mismatch")
    return value


def _merge_tree_and_cost(weights: list[int]) -> tuple[Any, int, Any, int]:
    """Return optimal leftmost-tie DP tree/cost and rightmost tree/cost."""
    n = len(weights)
    need(n <= 64, "frontier exceeds bounded binary-carry depth")
    for w in weights: integer(w, "frontier weight", 1)
    if not n: return None, 0, None, 0
    prefix = [0]
    for w in weights: prefix.append(prefix[-1] + w)
    cost = [[0] * n for _ in range(n)]
    split = [[None] * n for _ in range(n)]
    for length in range(2, n + 1):
        for i in range(n - length + 1):
            j = i + length - 1
            best = None
            for k in range(i, j):
                candidate = cost[i][k] + cost[k + 1][j]
                if best is None or candidate < best:
                    best, split[i][j] = candidate, k
            cost[i][j] = prefix[j + 1] - prefix[i] + best
    def opt(i: int, j: int) -> Any:
        return i if i == j else [opt(i, split[i][j]), opt(split[i][j] + 1, j)]
    def right(i: int, j: int) -> Any:
        return i if i == j else [i, right(i + 1, j)]
    def right_cost(i: int, j: int) -> int:
        return 0 if i == j else prefix[j + 1] - prefix[i] + right_cost(i + 1, j)
    return opt(0, n - 1), cost[0][n - 1], right(0, n - 1), right_cost(0, n - 1)


def validate_trace(record: dict[str, Any], spill_report: dict[str, Any] | None) -> dict[str, Any]:
    obs = record.get("observation")
    need(isinstance(obs, dict) and obs.keys() == {"enabled", "event_limit", "marker_bytes", "events", "synchronous_sink_ns", "synchronous_sink_batches"}, "malformed observation object")
    integer(obs["synchronous_sink_ns"], "observation.synchronous_sink_ns")
    need(integer(obs["synchronous_sink_batches"], "observation.synchronous_sink_batches") <= 1024, "too many synchronous sink batches")
    role, spill, rows = record["role"], record["spill"], record["rows"]
    enabled = role == "on"
    need(obs["enabled"] is enabled and obs["event_limit"] == 4096 and obs["marker_bytes"] == MARKER_BYTES, "observation flags/limits mismatch")
    events = obs["events"]
    need(isinstance(events, list) and len(events) <= 4096 and all(isinstance(e, dict) for e in events), "invalid or oversized event list")
    if not enabled or not spill:
        need(events == [], "observer-off and resident controls must have no events")
        if spill_report is None: return {"frontier": [], "dp_tree": None, "dp_cost": 0, "rightmost_tree": None, "rightmost_cost": 0, "tail_time_ns": 0, "tail_input_bytes": 0, "leaf_merge_time_ns": 0}
    if not enabled:
        need(spill_report is not None, "spill report missing for spill-enabled workflow")
        return {"frontier": [], "dp_tree": None, "dp_cost": 0, "rightmost_tree": None, "rightmost_cost": 0, "tail_time_ns": 0, "tail_input_bytes": 0, "leaf_merge_time_ns": 0}
    need(spill, "resident workflow cannot contain enabled events")
    if spill_report is None: raise Invalid("spill-enabled workflow has no report")
    if rows in (0, 17):
        # These shapes may create a spill owner and cleanup snapshot, but must not flush a run.
        need(all(e.get("event") in ("owner", "cleanup") for e in events), "small/empty spill case emitted run events")
        need(sum(e.get("event") == "owner" for e in events) == 1 and sum(e.get("event") == "cleanup" for e in events) == 1, "small/empty spill owner/cleanup trace incomplete")
    kinds = [e.get("event") for e in events]
    need(kinds and kinds[0] == "owner" and kinds[-1] == "cleanup", "trace must start with owner and end with cleanup")
    need(kinds.count("owner") == 1 and kinds.count("cleanup") == 1, "duplicate owner/cleanup event")
    owner = events[0].get("owner")
    integer(owner, "trace.owner", 1)
    block_rows = integer(events[0].get("block_rows"), "owner.block_rows", 1)
    need(events[0].get("buffer_bytes") == SPILL_BUFFER and block_rows <= 1024 and events[0].get("reader_work_bytes") == READER_WORK, "owner resource contract mismatch")
    initial = {"live_disk_bytes": 0, "peak_disk_bytes": 0, "runs_written": 0, "runs_validated": 0}
    current = dict(initial)
    nodes: dict[str, dict[str, Any]] = {}
    consumed: set[str] = set()
    stack: list[str] = []
    next_row = 0
    frontier: list[str] | None = None
    tail_trees: dict[str, Any] = {}
    tail = False
    terminal_seen = False
    cleanup_seen = False
    max_readers = 0
    leaf_merge_ns = 0
    tail_ns = 0
    tail_inputs = 0
    for e in events[1:]:
        kind = e.get("event")
        if kind in ("leaf", "merge", "frontier", "terminal_removal"):
            need(type(e.get("owner")) is int and e["owner"] == owner, f"event owner mismatch at {kind}")
        carry_pending = frontier is None and len(stack) >= 2 and nodes[stack[-1]]["level"] == nodes[stack[-2]]["level"]
        if carry_pending:
            need(kind == "merge" and e.get("phase") == "ingest", "binary-carry merge missing or reordered")
        if kind == "leaf":
            need(frontier is None and not tail, "leaf after final frontier")
            run = _run(e.get("run"), "leaf", rows, block_rows)
            rid = run.get("id")
            integer(run.get("rows"), "leaf.rows", 1)
            integer(run.get("bytes"), "leaf.bytes", 1)
            need(run.get("level") == 0 and run.get("start") == next_row and run.get("end") == next_row + run["rows"], "leaf intervals are not contiguous")
            need(run.get("block_rows") == events[0]["block_rows"], "leaf block_rows differs from owner")
            need(isinstance(rid, str) and rid and rid not in nodes, "invalid or duplicate leaf id")
            before, after = _snap(e.get("before"), "leaf.before"), _snap(e.get("after_write"), "leaf.after_write")
            _snapshot_matches(before, current, "leaf.before")
            current = before
            marker = MARKER_BYTES if current["live_disk_bytes"] == 0 and current["runs_written"] == 0 else 0
            live = current["live_disk_bytes"] + marker + run["bytes"]
            expected = {"live_disk_bytes": live, "peak_disk_bytes": max(current["peak_disk_bytes"], live), "runs_written": current["runs_written"] + 1, "runs_validated": current["runs_validated"] + 1}
            _snapshot_matches(after, expected, "leaf.after_write")
            need(after["runs_validated"] >= current["runs_validated"] + 1, "leaf output validation count did not advance")
            current = after
            nodes[rid] = {"id": rid, "start": next_row, "end": run["end"], "rows": run["rows"], "bytes": run["bytes"], "level": 0, "tree": rid}
            next_row = run["end"]
            stack.append(rid)
            leaf_merge_ns += integer(e.get("elapsed_ns"), "leaf.elapsed_ns")
            readers = integer(e.get("readers"), "leaf.readers")
            need(readers == 0, "leaf write unexpectedly overlaps a run reader")
            max_readers = max(max_readers, readers)
            continue
        if kind == "merge":
            phase = e.get("phase")
            need(phase in ("ingest", "final_tail"), "invalid merge phase")
            if phase == "ingest": need(frontier is None and not tail, "ingest merge after frontier")
            else:
                need(frontier is not None and tail and not terminal_seen, "tail merge outside tail")
            left_id, right_id = e.get("left"), e.get("right")
            need(isinstance(left_id, str) and isinstance(right_id, str), "merge parent ids must be strings")
            need(left_id in nodes and right_id in nodes and left_id != right_id, "merge references absent/duplicate parent")
            need(left_id not in consumed and right_id not in consumed, "run parent used more than once")
            left, right = nodes[left_id], nodes[right_id]
            need(left["end"] == right["start"], "merge parents are not adjacent left-to-right")
            if phase == "ingest":
                need(len(stack) >= 2 and stack[-2:] == [left_id, right_id] and left["level"] == right["level"], "ingest merge violates rightmost equal-level binary carry")
            else:
                need(len(stack) >= 2 and stack[-2:] == [left_id, right_id], "final tail merge violates rightmost stack order")
            output = _run(e.get("output"), "merge.output", rows, block_rows)
            out_id = output.get("id")
            need(isinstance(out_id, str) and out_id and out_id not in nodes, "duplicate merge output id")
            need(output.get("start") == left["start"] and output.get("end") == right["end"] and output.get("rows") == left["rows"] + right["rows"], "merge output interval/row conservation mismatch")
            level = max(left["level"], right["level"]) + 1
            need(output.get("level") == level and output.get("block_rows") == events[0]["block_rows"], "merge level/block mismatch")
            integer(output.get("bytes"), "merge.output.bytes", 1)
            before = _snap(e.get("before"), "merge.before")
            after_write = _snap(e.get("after_write"), "merge.after_write")
            after_remove = _snap(e.get("after_removal"), "merge.after_removal")
            _snapshot_matches(before, current, "merge.before")
            current = before
            live_overlap = current["live_disk_bytes"] + output["bytes"]
            written = {"live_disk_bytes": live_overlap, "peak_disk_bytes": max(current["peak_disk_bytes"], live_overlap), "runs_written": current["runs_written"] + 1, "runs_validated": current["runs_validated"] + 1}
            _snapshot_matches(after_write, written, "merge.after_write")
            need(after_write["runs_validated"] >= current["runs_validated"] + 1, "merge output validation count did not advance")
            live_after = live_overlap - left["bytes"] - right["bytes"]
            removed = {"live_disk_bytes": live_after, "peak_disk_bytes": written["peak_disk_bytes"], "runs_written": written["runs_written"], "runs_validated": after_write["runs_validated"]}
            _snapshot_matches(after_remove, removed, "merge.after_removal")
            current = after_remove
            consumed.update((left_id, right_id))
            stack[-2:] = [out_id]
            nodes[out_id] = {"id": out_id, "start": left["start"], "end": right["end"], "rows": left["rows"] + right["rows"], "bytes": output["bytes"], "level": level, "tree": [left["tree"], right["tree"]]}
            if phase == "final_tail": tail_trees[out_id] = [tail_trees[left_id], tail_trees[right_id]]
            elapsed = integer(e.get("elapsed_ns"), "merge.elapsed_ns")
            leaf_merge_ns += elapsed
            readers_write = integer(e.get("readers_during_write"), "merge.readers_during_write")
            readers_remove = integer(e.get("readers_after_removal"), "merge.readers_after_removal")
            max_readers = max(max_readers, readers_write, readers_remove)
            need(readers_write == MAX_READERS and readers_remove == 0, "merge reader limit/cleanup mismatch")
            if phase == "final_tail":
                tail_ns += elapsed
                tail_inputs += left["bytes"] + right["bytes"]
            continue
        if kind == "frontier":
            need(frontier is None and not tail and stack, "duplicate/empty frontier")
            need(not (len(stack) >= 2 and nodes[stack[-1]]["level"] == nodes[stack[-2]]["level"]), "frontier contains unmerged equal-level tail")
            need(e.get("run_ids") == stack, "captured frontier order differs from reconstructed stack")
            levels = [nodes[rid]["level"] for rid in stack]
            need(all(a > b for a, b in zip(levels, levels[1:])), "frontier levels do not descend after binary carry")
            snap = _snap(e.get("snapshot"), "frontier.snapshot")
            need(snap == current and integer(e.get("readers"), "frontier.readers") == 0, "frontier snapshot/readers mismatch")
            frontier = list(stack)
            tail_trees = {rid: rid for rid in frontier}
            tail = True
            continue
        if kind == "terminal_removal":
            need(e.get("owner") == owner, "terminal owner mismatch")
            need(frontier is not None and tail and len(stack) == 1 and not terminal_seen, "terminal removal in invalid trace position")
            rid = e.get("run_id")
            need(rid == stack[0] and rid not in consumed, "terminal run mismatch")
            before, after = _snap(e.get("before"), "terminal.before"), _snap(e.get("after_removal"), "terminal.after_removal")
            _snapshot_matches(before, current, "terminal.before")
            current = before
            removed = {"live_disk_bytes": current["live_disk_bytes"] - nodes[rid]["bytes"], "peak_disk_bytes": current["peak_disk_bytes"], "runs_written": current["runs_written"], "runs_validated": current["runs_validated"]}
            _snapshot_matches(after, removed, "terminal.after_removal")
            current = after
            consumed.add(rid)
            stack.pop()
            terminal_seen = True
            need(integer(e.get("readers"), "terminal.readers") == 0, "terminal run reader still open")
            need(integer(e.get("readers_during_read"), "terminal.readers_during_read") == 1, "terminal run was not read with exactly one reader")
            max_readers = max(max_readers, 1)
            continue
        if kind == "cleanup":
            need(not cleanup_seen and (terminal_seen or not stack), "cleanup before completed terminal trace")
            before, after = _snap(e.get("before"), "cleanup.before"), _snap(e.get("after"), "cleanup.after")
            _snapshot_matches(before, current, "cleanup.before")
            need(integer(e.get("readers"), "cleanup.readers") == 0, "cleanup before snapshot/readers mismatch")
            current = before
            expected_after = {"live_disk_bytes": 0, "peak_disk_bytes": current["peak_disk_bytes"], "runs_written": current["runs_written"], "runs_validated": current["runs_validated"]}
            _snapshot_matches(after, expected_after, "cleanup.after")
            current = after
            cleanup_seen = True
            continue
        raise Invalid(f"unknown trace event {kind!r}")
    need(cleanup_seen and current["live_disk_bytes"] == 0, "trace lacks complete zero-live cleanup")
    if nodes:
        need(next_row == rows and frontier is not None and terminal_seen and not stack, "source rows not fully covered by terminal run")
    else:
        need(next_row == 0 and frontier is None and not terminal_seen, "no-run source has a terminal run or frontier")
        need(kinds == ["owner", "cleanup"], "no-run source must have only owner and cleanup")
        need(all(value == 0 for value in current.values()), "no-run source reports store work")
    need(max_readers <= MAX_READERS, "too many simultaneous readers")
    need(leaf_merge_ns <= record["engine_execution_ns"], "leaf/merge spans exceed engine time")
    frontier_nodes = [nodes[rid] for rid in (frontier or [])]
    weights = [r["bytes"] for r in frontier_nodes]
    dp_tree_idx, dp_cost, right_tree_idx, right_cost = _merge_tree_and_cost(weights)
    def relabel(tree: Any) -> Any:
        return frontier_nodes[tree]["id"] if isinstance(tree, int) else [relabel(tree[0]), relabel(tree[1])] if tree is not None else None
    dp_tree, right_tree = relabel(dp_tree_idx), relabel(right_tree_idx)
    actual_tree = tail_trees[events[-2]["run_id"]] if terminal_seen else None
    if frontier is not None:
        need(typed_equal(actual_tree, right_tree), "actual final-tail tree differs from modeled rightmost tree")
    need(spill_report["peak_disk_bytes"] == current["peak_disk_bytes"], "spill report peak differs from trace replay")
    need(spill_report["runs_written"] == current["runs_written"] and spill_report["runs_validated"] == current["runs_validated"], "spill report run counts differ from trace")
    merge_count = sum(e.get("event") == "merge" for e in events)
    need(spill_report["merge_passes"] == merge_count, "spill report merge-pass count differs from trace")
    need(spill_report["max_open_runs"] == max_readers and max_readers <= MAX_READERS, "spill report reader count differs from trace")
    run_blocks = [e["run"]["block_rows"] for e in events if e.get("event") == "leaf"] + [e["output"]["block_rows"] for e in events if e.get("event") == "merge"]
    block_rows = max(run_blocks, default=0)
    need(spill_report["run_block_rows"] == block_rows, "spill report run block rows differ from trace")
    return {"frontier": [{"id": n["id"], "bytes": n["bytes"], "rows": n["rows"], "interval": [n["start"], n["end"]], "level": n["level"]} for n in frontier_nodes], "dp_tree": dp_tree, "dp_cost": dp_cost, "rightmost_tree": right_tree, "rightmost_cost": right_cost, "actual_tree": actual_tree, "tail_time_ns": tail_ns, "tail_input_bytes": tail_inputs, "leaf_merge_time_ns": leaf_merge_ns, "peak_disk_bytes": spill_report["peak_disk_bytes"], "runs_written": spill_report["runs_written"], "merge_passes": merge_count, "max_open_runs": max_readers}


def validate_record(data: Path, rec: dict[str, Any], mode: str, role: str, cohort: str, sample: int, spec: tuple[int, str, bool], warmup: bool) -> dict[str, Any]:
    rows, profile, spill = spec
    cid = cell_id(rows, profile, spill)
    expected_meta = {"cell_id": cid, "rows": rows, "profile": profile, "spill": spill, "role": role, "cohort": cohort, "sample": sample, "warmup": warmup}
    for k, v in expected_meta.items(): need(type(rec.get(k)) is type(v) and rec.get(k) == v, f"{cid}: incorrect {k}")
    source = source_rows(rows, profile)
    expected = expected_output(source)
    witness(data, rec.get("source_rows_witness"), source, f"{cid} source rows")
    witness(data, rec.get("source_schema_witness"), SOURCE_SCHEMA, f"{cid} source schema")
    witness(data, rec.get("expected_rows_witness"), expected, f"{cid} expected rows")
    witness(data, rec.get("expected_schema_witness"), SOURCE_SCHEMA, f"{cid} expected schema")
    witness(data, rec.get("actual_rows_witness"), expected, f"{cid} actual rows")
    witness(data, rec.get("actual_schema_witness"), SOURCE_SCHEMA, f"{cid} actual schema")
    delivery = rec.get("result_delivery")
    need(isinstance(delivery, dict), f"{cid}: missing batch delivery evidence")
    for key, value in {"api": "for_each_json_batch", "batch_rows_limit": 2048, "batch_bytes_limit": 2097152, "total_bytes_limit": 16777216, "batch_count_limit": 1024}.items():
        need(typed_equal(delivery.get(key), value), f"{cid}: incorrect delivery {key}")
    batches = delivery.get("batches")
    need(isinstance(batches, list) and 1 <= len(batches) <= 1024, f"{cid}: invalid delivery batch count")
    delivered_rows = delivered_bytes = 0
    for batch in batches:
        need(isinstance(batch, dict) and set(batch) == {"rows", "bytes"}, f"{cid}: invalid delivery batch")
        count = integer(batch["rows"], f"{cid}.batch.rows")
        size = integer(batch["bytes"], f"{cid}.batch.bytes", 2)
        need(count <= 2048 and size <= 2097152 and delivered_rows + count <= rows, f"{cid}: delivery batch limit exceeded")
        need(count > 0 or (rows == 0 and len(batches) == 1), f"{cid}: unexpected empty result batch")
        exact_size = len(json.dumps(expected[delivered_rows:delivered_rows + count], ensure_ascii=False, separators=(",", ":")).encode())
        need(size == exact_size, f"{cid}: delivery bytes differ from complete rows")
        delivered_rows += count
        delivered_bytes += size
    need(delivered_rows == rows and delivered_bytes <= 16777216, f"{cid}: incomplete or oversized delivery")
    need(typed_equal(delivery.get("total_json_bytes"), delivered_bytes), f"{cid}: total delivery bytes mismatch")
    for key in ("preparation_ns", "engine_execution_ns", "result_serialization_ns", "execution_and_consumption_ns", "output_release_ns", "destruction_ns", "complete_workflow_ns"):
        integer(rec.get(key), f"{cid}.{key}")
    need(rec["engine_execution_ns"] + rec["result_serialization_ns"] == rec["execution_and_consumption_ns"], f"{cid}: engine/serialization partition differs from consumption")
    need(rec["complete_workflow_ns"] == sum(rec[k] for k in ("preparation_ns", "execution_and_consumption_ns", "output_release_ns", "destruction_ns")), f"{cid}: complete clock mismatch")
    need(typed_equal(rec["observation"].get("synchronous_sink_ns"), rec["result_serialization_ns"]), f"{cid}: synchronous sink clock mismatch")
    need(typed_equal(rec["observation"].get("synchronous_sink_batches"), len(batches)), f"{cid}: synchronous sink batch count mismatch")
    cert = rec.get("native_io_certificate")
    need(isinstance(cert, dict) and cert.get("certified") is True and cert.get("fallback_attempted") is False and isinstance(cert.get("complete_debug"), str) and cert["complete_debug"].strip() and type(cert.get("spill_io_performed")) is bool, f"{cid}: invalid native certificate")
    need(cert.get("sink_supports_streaming") is True and typed_equal(cert.get("sink_max_chunk_rows"), 2048), f"{cid}: native streaming certificate mismatch")
    report = rec.get("spill_report")
    need((report is not None) is spill, f"{cid}: spill report presence mismatch")
    if report is not None:
        need(isinstance(report, dict), f"{cid}: malformed spill report")
        for k, v in {"quota_bytes": DISK_QUOTA, "buffer_bytes": SPILL_BUFFER, "owned_cleanup_completed": True}.items(): need(typed_equal(rec["spill_report"].get(k), v), f"{cid}: spill report {k} mismatch")
        for k in ("peak_disk_bytes", "runs_written", "runs_validated", "merge_passes", "max_open_runs", "run_block_rows"): integer(report.get(k), f"{cid}.spill_report.{k}")
        expected_workspace = data / f"spill-{cid}-{role}-{cohort}-{sample}-{str(warmup).lower()}"
        need(report.get("workspace") == str(expected_workspace), f"{cid}: incorrect spill workspace")
        need(report["peak_disk_bytes"] <= DISK_QUOTA and report["max_open_runs"] <= MAX_READERS, f"{cid}: spill quota/reader limit exceeded")
    expected_spill_io = bool(report and report.get("runs_written", 0) > 0)
    need(cert["spill_io_performed"] is expected_spill_io, f"{cid}: certificate spill I/O status mismatch")
    for k, v in {"completed_executions": 1, "prepared_source_opens": 0, "resident_source_preparations": 1, "prepared_sources": 1, "prepared_file_sources": 0, "admitted_max_parallelism": 1, "provider_background_workers": 0, "reserved_after_cleanup": 0, "denied_reservations": 0, "owned_spill_directory_empty": True}.items():
        need(type(rec.get(k)) is type(v) and rec.get(k) == v, f"{cid}: resource/completion mismatch {k}")
    integer(rec.get("peak_reserved_bytes"), f"{cid}.peak_reserved_bytes")
    need(rec["peak_reserved_bytes"] <= MEMORY_LIMIT, f"{cid}: memory budget exceeded")
    trace_summary = validate_trace(rec, report)
    return trace_summary


def stream_path(data: Path, mode: str, role: str, cohort: str) -> Path:
    return data / f"{mode}-{cohort}-{role}.jsonl"


def read(data: Path | str, mode: str, role: str, cohort: str) -> dict[str, Any]:
    data = Path(data)
    need(digest(PROTOCOL.read_bytes()) == PROTOCOL_SHA256, "frozen protocol SHA-256 mismatch")
    need(mode in ("preflight", "measure") and role in ("off", "on") and cohort in ("preflight", "A", "B"), "invalid stream selector")
    need((mode == "preflight") == (cohort == "preflight"), "mode/cohort mismatch")
    path = stream_path(data, mode, role, cohort)
    need(path.is_file(), f"missing stream {path.name}")
    raw = path.read_bytes()
    try: records = [json.loads(line) for line in raw.splitlines()]
    except Exception as e: raise Invalid(f"invalid JSONL in {path.name}: {e}") from e
    need(all(isinstance(r, dict) for r in records), f"{path.name}: record must be an object")
    expected: list[tuple[tuple[int, str, bool], int, bool]] = []
    if mode == "preflight":
        expected.extend([((0, "uniform24", True), 0, False), ((17, "uniform24", True), 0, False), ((0, "uniform24", False), 0, False), ((17, "uniform24", False), 0, False)])
        ordered = matrix()
        for spec in (list(reversed(ordered)) if cohort == "B" else ordered): expected.append((spec, 0, False))
    else:
        expected.append(((8192, "uniform24", False), 0, True))
        ordered = matrix()
        for spec in (list(reversed(ordered)) if cohort == "B" else ordered):
            for sample in SAMPLES: expected.append((spec, sample, False))
    need(len(records) == len(expected), f"{path.name}: expected {len(expected)} workflows, got {len(records)}")
    traces = []
    for r, (spec, sample, warm) in zip(records, expected):
        traces.append(validate_record(data, r, mode, role, cohort, sample, spec, warm))
    ops = len(records)
    need(ops == (20 if mode == "preflight" else 49), f"{path.name}: workflow/operation total mismatch")
    return {"records": records, "trace_summaries": traces, "summary": {"stream": path.name, "sha256": digest(raw), "bytes": len(raw), "workflows": len(records), "operations": ops}}


def _decision_cell(cohort: str, off: list[dict[str, Any]], on: list[dict[str, Any]], off_trace: list[dict[str, Any]], on_trace: list[dict[str, Any]]) -> dict[str, Any]:
    off_engine = statistics.median(r["engine_execution_ns"] for r in off)
    on_engine = statistics.median(r["engine_execution_ns"] for r in on)
    off_complete = statistics.median(r["complete_workflow_ns"] for r in off)
    on_complete = statistics.median(r["complete_workflow_ns"] for r in on)
    ineligible = any(on_v * 10 > off_v * 11 and on_v - off_v > 1_000_000 for off_v, on_v in ((off_engine, on_engine), (off_complete, on_complete)))
    savings = [a["rightmost_cost"] - a["dp_cost"] for a in on_trace]
    bases = [a["rightmost_cost"] for a in on_trace]
    tail_times = [a["tail_time_ns"] for a in on_trace]
    enabled_engine_median = on_engine
    median_saving = statistics.median(savings)
    median_base = statistics.median(bases)
    median_tail = statistics.median(tail_times)
    sample_distinct_lower = [a["rightmost_tree"] != a["dp_tree"] and a["dp_cost"] < a["rightmost_cost"] for a in on_trace]
    distinct_lower = median_saving > 0 and any(sample_distinct_lower)
    byte_gate = distinct_lower and median_saving * 10 >= median_base and median_saving >= 1_048_576
    time_gate = median_tail * 5 >= enabled_engine_median and median_tail >= 2_000_000
    reasons = []
    if ineligible: reasons.append("observer_ineligible")
    if not distinct_lower: reasons.append("no_distinct_lower_cost_tree")
    if distinct_lower and not byte_gate: reasons.append("insufficient_estimated_byte_saving")
    if not time_gate: reasons.append("insufficient_observed_tail_time")
    return {"cohort": cohort, "median_off_engine_ns": off_engine, "median_on_engine_ns": on_engine, "median_off_complete_ns": off_complete, "median_on_complete_ns": on_complete, "observer_eligible": not ineligible, "sample_estimated_savings_bytes": savings, "median_estimated_saving_bytes": median_saving, "median_baseline_weighted_tail_cost_bytes": median_base, "median_estimated_saving_fraction": median_saving / median_base if median_base else 0.0, "sample_distinct_lower_cost_tree": sample_distinct_lower, "distinct_lower_cost_tree_at_positive_median": distinct_lower, "byte_cost_gate": byte_gate, "sample_final_tail_merge_time_ns": tail_times, "median_final_tail_merge_time_ns": median_tail, "median_enabled_engine_ns": enabled_engine_median, "tail_work_gate": time_gate, "qualifies": not ineligible and byte_gate and time_gate, "reason_codes": reasons}


def analyze(data: Path | str) -> dict[str, Any]:
    data = Path(data)
    loaded = {(c, r): read(data, "measure", r, c) for c in ("A", "B") for r in ("off", "on")}
    preflight = {r: read(data, "preflight", r, "preflight") for r in ("off", "on")}
    by: dict[tuple[str, str], dict[tuple[str, int], tuple[dict[str, Any], dict[str, Any]]]] = {}
    for key, bundle in loaded.items():
        entries = {}
        for rec, trace in zip(bundle["records"], bundle["trace_summaries"]):
            if rec["warmup"]: continue
            entries[(rec["cell_id"], rec["sample"])] = (rec, trace)
        need(len(entries) == 48, f"{key}: measured identity coverage mismatch")
        by[key] = entries
    report_keys = ("quota_bytes", "buffer_bytes", "peak_disk_bytes", "runs_written", "runs_validated", "merge_passes", "max_open_runs", "run_block_rows", "owned_cleanup_completed")
    for cohort in ("A", "B"):
        for spec in matrix():
            cid = cell_id(*spec)
            for sample in SAMPLES:
                off = by[(cohort, "off")][(cid, sample)][0]
                on = by[(cohort, "on")][(cid, sample)][0]
                need(off["source_rows_witness"] == on["source_rows_witness"] and off["actual_rows_witness"] == on["actual_rows_witness"] and off["actual_schema_witness"] == on["actual_schema_witness"], f"{cohort}/{cid}/sample{sample}: role witness mismatch")
                ro, rn = off.get("spill_report"), on.get("spill_report")
                need((ro is None) == (rn is None), f"{cohort}/{cid}/sample{sample}: role spill report presence mismatch")
                if ro is not None:
                    need(all(ro.get(k) == rn.get(k) for k in report_keys), f"{cohort}/{cid}/sample{sample}: off/on native spill reports differ")
    results = []
    for spec in matrix():
        cid = cell_id(*spec)
        cohorts = {}
        for cohort in ("A", "B"):
            pairs_off = [by[(cohort, "off")][(cid, s)] for s in SAMPLES]
            pairs_on = [by[(cohort, "on")][(cid, s)] for s in SAMPLES]
            cohorts[cohort] = _decision_cell(cohort, [x[0] for x in pairs_off], [x[0] for x in pairs_on], [x[1] for x in pairs_off], [x[1] for x in pairs_on])
        same = spec[2] and cohorts["A"]["qualifies"] and cohorts["B"]["qualifies"]
        results.append({"cell_id": cid, "spill": spec[2], "cohorts": cohorts, "same_cell_qualifies_both_cohorts": same})
    qualified = [x["cell_id"] for x in results if x["same_cell_qualifies_both_cohorts"]]
    all_streams = {f"{c}-{r}": b for (c, r), b in loaded.items()} | {f"preflight-{r}": b for r, b in preflight.items()}
    trace_evidence = {name: [{"cell_id": rec["cell_id"], "sample": rec["sample"], "warmup": rec["warmup"], "trace_summary": summary} for rec, summary in zip(bundle["records"], bundle["trace_summaries"])] for name, bundle in all_streams.items()}
    return {"protocol_id": PROTOCOL_ID, "protocol_sha256": digest(PROTOCOL.read_bytes()), "validator_sha256": digest(Path(__file__).read_bytes()), "preflight_passed": True, "streams": {name: b["summary"] for name, b in all_streams.items()}, "trace_evidence": trace_evidence, "cells": results, "qualifying_spill_cells": qualified, "scope_result": "material_signal" if qualified else "no_signal", "no_signal_reasons": {x["cell_id"]: {c: v["reason_codes"] for c, v in x["cohorts"].items()} for x in results if x["spill"] and not x["same_cell_qualifies_both_cohorts"]}, "production_optimization": False, "actual_schedule_speedup": False}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("preflight", "decision"))
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.mode == "preflight":
        loaded = {role: read(args.data, "preflight", role, "preflight") for role in ("off", "on")}
        report = {"protocol_id": PROTOCOL_ID, "protocol_sha256": digest(PROTOCOL.read_bytes()), "validator_sha256": digest(Path(__file__).read_bytes()), "streams": {r: b["summary"] for r, b in loaded.items()}, "preflight_passed": True, "production_optimization": False}
    else:
        report = analyze(args.data)
    text = json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with args.output.open("x", encoding="utf-8") as f: f.write(text)
    else: print(text, end="")


if __name__ == "__main__": main()
