"""Package complete V3 merge-tail evidence and preserve invalid V1/V2 attempts.

Packaging only: validates frozen identities and the V3 verifier receipt; it does
not build, run tests, execute native code, or assign V1/V2 decision credit.
"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import lzma
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019')
REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
LOCALDATA = Path('/Users/dylan/LocalData/shardloom')
DEST = ROOT / 'merge-tail-portable-774'
NAME = 'merge-tail-portable-774'
HEAD = 'd732d7889207e7d8fc0de8d746de1623174c1dcf'

V1 = 'merge-tail-attribution-771-a1'
V1_BUILD = 'merge-tail-build-771-a1'
V1_PROTOCOL_SHA = 'e2ffc917bf17d64bffdc0f27943e86f12345ceaeb29a65ee69d290279eaa6a72'
V1_DATA = ROOT / V1
V1_FAILURE = ROOT / 'merge-tail-protocol-admission-failure-772.json'
V1_FREEZE = ROOT / f'{V1}-source-freeze.json'
V1_ARTIFACT_RECEIPT = ROOT / f'{V1}-artifact.json'
V1_ARTIFACT = ROOT / f'{V1}-test'
V1_BUILD_RECEIPT = ROOT / f'{V1_BUILD}.json'
V1_PROTOCOL = ROOT / 'merge-tail-attribution-protocol-771.json'
V1_PROTOCOL_FREEZE = ROOT / 'merge-tail-protocol-freeze-771.json'

V2 = 'merge-tail-attribution-773-a1'
V2_BUILD = 'merge-tail-build-773-a1'
V2_PROTOCOL_SHA = '081a46278f799945e00a4f1d87fb5c316e2408cfd613c38998acad1c8f190865'
V2_FAILURE = ROOT / 'merge-tail-collector-admission-failure-773.json'
V2_FREEZE = ROOT / f'{V2}-source-freeze.json'
V2_BUILD_RECEIPT = ROOT / f'{V2_BUILD}.json'
V2_PROTOCOL = ROOT / 'merge-tail-attribution-protocol-773.json'
V2_PROTOCOL_FREEZE = ROOT / 'merge-tail-protocol-freeze-773.json'
V2_DESIGN_PRESERVED = ROOT / 'merge-tail-design-v2-preserved-773.md'

V3 = 'merge-tail-attribution-774-a1'
V3_BUILD = 'merge-tail-build-774-a1'
V3_PROTOCOL_SHA = '2db26a89965125f7deb44e644dd28852c475add5944089e486bf8fa8d6aa38bc'
V3_PROTOCOL = ROOT / 'merge-tail-attribution-protocol-774.json'
V3_PROTOCOL_FREEZE = ROOT / 'merge-tail-protocol-freeze-774.json'
V3_FREEZE = ROOT / f'{V3}-source-freeze.json'
V3_ARTIFACT_RECEIPT = ROOT / f'{V3}-artifact.json'
V3_ARTIFACT = ROOT / f'{V3}-test'
V3_BUILD_RECEIPT = ROOT / f'{V3_BUILD}.json'
V3_DATA = ROOT / V3
V3_DECISION = ROOT / f'{V3}-decision.json'
V3_SEQUENCE_IDENTITY = ROOT / f'{V3}-sequence-identity.json'
V3_SEQUENCE_COMPLETION = ROOT / f'{V3}-sequence-completion.json'
V3_VERIFICATION = ROOT / 'merge-tail-verification-774.json'

V1_STEPS = ('merge-tail-bind-771-a1', 'merge-tail-focused-spill-771-a1',
            'merge-tail-preflight-off-771-a1')
V3_STEPS = (
    'merge-tail-bind-774-a1', 'merge-tail-focused-spill-774-a1',
    'merge-tail-preflight-off-774-a1', 'merge-tail-preflight-on-774-a1',
    'merge-tail-preflight-check-774-a1', 'merge-tail-measure-A-off-774-a1',
    'merge-tail-measure-A-on-774-a1', 'merge-tail-measure-B-on-774-a1',
    'merge-tail-measure-B-off-774-a1', 'merge-tail-decision-774-a1',
    'merge-tail-final-binding-774-a1',
)
V1_EMPTY_DIR = 'spill-0-uniform24-spill-off-preflight-0-false'
V1_STREAMS = ('preflight-preflight-off.jsonl',)
V3_STREAMS = (
    'preflight-preflight-off.jsonl', 'preflight-preflight-on.jsonl',
    'measure-A-off.jsonl', 'measure-A-on.jsonl',
    'measure-B-off.jsonl', 'measure-B-on.jsonl',
)

EXCLUDED = {
    f'{V1}-test': 'Compiled V1 binary; invalid admission attempt, identity only.',
    f'{V3}-test': 'Compiled V3 native test binary; identity retained in index, bytes omitted.',
    'merge-tail-package-772.json': 'Mutable V1 packaging receipt.',
    'merge-tail-package-772.log': 'Mutable V1 packaging log.',
    'merge-tail-package-772-driver.log': 'Mutable V1 packaging driver log.',
    'merge-tail-packet-verification-772.json': 'Mutable V1 packet reopen receipt.',
    'verify-merge-tail-packet-772.log': 'Mutable V1 packet reopen log.',
    'merge-tail-package-773.json': 'Mutable V2 packaging receipt.',
    'merge-tail-package-773.log': 'Mutable V2 packaging log.',
    'merge-tail-package-773-driver.log': 'Mutable V2 packaging driver log.',
    'merge-tail-packet-verification-773.json': 'Mutable V2 packet reopen receipt.',
    'verify-merge-tail-packet-773.log': 'Mutable V2 packet reopen log.',
    'merge-tail-package-774.json': 'Mutable V3 packaging receipt.',
    'merge-tail-package-774.log': 'Mutable V3 packaging log.',
    'merge-tail-package-774-driver.log': 'Mutable V3 packaging driver log.',
    'merge-tail-packet-verification-774.json': 'Mutable V3 packet reopen receipt.',
    'verify-merge-tail-packet-774.log': 'Mutable V3 packet reopen log.',
}

V1_FILES = {
    V1_PROTOCOL.name, V1_PROTOCOL_FREEZE.name, V1_FAILURE.name,
    V1_FREEZE.name, f'{V1}-tracked.patch', f'{V1}-artifact.json',
    f'{V1}-test-inventory.txt', f'{V1_BUILD}.json', f'{V1_BUILD}.log',
    'merge-tail-build-771-a1-driver.log', f'{V1}-sequence-identity.json',
    'merge_tail_driver_771.py', 'run_merge_tail_sequence_771.py',
    'run_merge_tail_sequence_before_primary_review_771.py',
    'analyze_merge_tail_771.py', 'analyze_merge_tail_771_before_primary_review_771.py',
    'test_merge_tail_oracle_771.py', 'test_merge_tail_oracle_771_before_primary_review_771.py',
    'merge-tail-primary-review-772.json', 'merge-tail-oracle-final-tests-772.log',
    'merge-tail-oracle-initial-tests-771.log', 'merge-tail-oracle-expanded-tests-772.log',
    'verify_merge_tail_772.py', 'package_merge_tail_772.py',
    'package_merge_tail_before_primary_review_772.py',
    'merge-tail-design-v1-preserved-773.md', 'merge-tail-investigation-design-draft-769.md',
    'merge-tail-focused-spill-771-a1.json', 'merge-tail-focused-spill-771-a1.log',
    'merge-tail-sequence-772-driver.log',
}
V2_FILES = {
    V2_PROTOCOL.name, V2_PROTOCOL_FREEZE.name, V2_FAILURE.name, V2_FREEZE.name,
    f'{V2}-tracked.patch', 'merge-tail-primary-review-773.json',
    'merge-tail-oracle-final-tests-773.log', 'merge-tail-build-773-a1-driver.log',
    f'{V2_BUILD}.json', f'{V2_BUILD}.log', V2_DESIGN_PRESERVED.name,
    'merge_tail_driver_773.py', 'run_merge_tail_sequence_773.py',
    'analyze_merge_tail_773.py', 'test_merge_tail_oracle_773.py', 'verify_merge_tail_773.py',
    'package_merge_tail_773.py',
}
V3_FILES = {
    V3_PROTOCOL.name, V3_PROTOCOL_FREEZE.name, V3_FREEZE.name,
    f'{V3}-tracked.patch', f'{V3}-artifact.json', f'{V3}-test-inventory.txt',
    f'{V3_BUILD}.json', f'{V3_BUILD}.log', 'merge-tail-build-774-a1-driver.log',
    f'{V3}-sequence-identity.json', f'{V3}-sequence-completion.json',
    f'{V3}-decision.json', f'{V3}-preflight-verification.json', V3_VERIFICATION.name,
    'merge-tail-primary-review-774.json', 'merge-tail-oracle-final-tests-774.log',
    'merge-tail-oracle-pre-review-tests-774.log', 'merge-tail-sequence-774-driver.log',
    'merge-tail-verifier-774.json', 'merge-tail-verifier-774.log',
    'merge-tail-verifier-774-driver.log', 'merge_tail_driver_774.py',
    'run_merge_tail_sequence_774.py', 'analyze_merge_tail_774.py',
    'test_merge_tail_oracle_774.py', 'verify_merge_tail_774.py',
}
V1_STEP_FILES = {
    item for step in V1_STEPS for item in
    (f'{step}-sequence-step.json', f'{step}-sequence-output.log', f'{step}.json', f'{step}.log')
} | {'merge-tail-preflight-off-771-a1-link.json'}
V3_STEP_FILES = {
    item for step in V3_STEPS for item in
    (f'{step}-sequence-step.json', f'{step}-sequence-output.log')
} | {
    item for step in V3_STEPS[:-1] for item in (f'{step}.json', f'{step}.log')
} | {
    f'{step}-link.json' for step in (
        'merge-tail-preflight-off-774-a1', 'merge-tail-preflight-on-774-a1',
        'merge-tail-measure-A-off-774-a1', 'merge-tail-measure-A-on-774-a1',
        'merge-tail-measure-B-on-774-a1', 'merge-tail-measure-B-off-774-a1')
}
INCLUDED = V1_FILES | V2_FILES | V3_FILES | V1_STEP_FILES | V3_STEP_FILES | {
    'merge-tail-protocol-freeze-773.json', 'merge-tail-primary-review-772.json',
    'merge-tail-primary-review-773.json', 'merge-tail-primary-review-774.json',
    'package_merge_tail_772.py', 'package_merge_tail_773.py',
    'package_merge_tail_before_primary_review_772.py', 'package_merge_tail_774.py',
}

sys.path.insert(0, str(REPO / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_file(path: Path) -> str:
    hasher = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            hasher.update(chunk)
    return hasher.hexdigest()


def identity(path: Path) -> dict[str, object]:
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha_file(path)}


def read_json(path: Path) -> dict:
    assert path.is_file() and not path.is_symlink(), path
    value = json.loads(path.read_text())
    assert isinstance(value, dict), path
    return value


def encode_json(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def add_file(members: dict[str, Path], member: str, source: Path) -> None:
    source = Path(source)
    assert source.is_file() and not source.is_symlink(), source
    assert member and not member.startswith('/') and '..' not in Path(member).parts, member
    assert '\\' not in member and '\x00' not in member
    prior = members.get(member)
    assert prior is None or prior.resolve() == source.resolve(), f'duplicate archive member {member}'
    members[member] = source


def archive_path(path: Path) -> str:
    path = Path(path).resolve(strict=True)
    if path.is_relative_to(ROOT):
        return 'evidence/' + path.relative_to(ROOT).as_posix()
    if path.is_relative_to(REPO):
        return 'repo/' + path.relative_to(REPO).as_posix()
    if path.is_relative_to(LOCALDATA):
        return 'local/' + path.relative_to(LOCALDATA).as_posix()
    raise AssertionError(f'input outside approved roots: {path}')


def add_tree(members: dict[str, Path], root: Path, member_root: str) -> list[Path]:
    assert root.is_dir() and not root.is_symlink(), root
    paths = []
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_dir():
            continue
        assert path.is_file(), path
        add_file(members, f'{member_root}/{path.relative_to(root).as_posix()}', path)
        paths.append(path)
    return paths


def verify_freeze(path: Path, protocol_sha: str, helper_count: int,
                  *, compare_workspace: bool, design_copy: Path | None = None) -> dict:
    freeze = read_json(path)
    assert freeze.get('head') == HEAD and freeze.get('protocol_sha256') == protocol_sha
    assert len(freeze.get('sources', [])) == 1901
    assert len(freeze.get('helpers', [])) == helper_count
    prefix = path.name.removesuffix('-source-freeze.json')
    patch = ROOT / f'{prefix}-tracked.patch'
    assert patch.is_file() and not patch.is_symlink()
    assert sha_file(patch) == freeze.get('patch_sha256')
    extra_root = ROOT / f'{prefix}-extra-sources'
    assert extra_root.is_dir() and not extra_root.is_symlink()
    declared = set(freeze.get('extra_sources', []))
    actual = set()
    for source in extra_root.rglob('*'):
        assert not source.is_symlink(), source
        if source.is_file():
            actual.add(source.relative_to(extra_root).as_posix())
    assert actual == declared
    source_rows = {row['path']: row for row in freeze['sources']}
    assert declared <= source_rows.keys()
    for relative in sorted(declared):
        copied = extra_root / relative
        row = source_rows[relative]
        assert copied.stat().st_size == row['bytes'] and sha_file(copied) == row['sha256']
    helper_workspace_mismatches = []
    for helper in freeze['helpers']:
        source = Path(helper['path'])
        actual_source = design_copy if design_copy and source == REPO / 'docs/architecture/native-merge-tail-design-2026-10-19.md' else source
        assert actual_source.is_file() and not actual_source.is_symlink(), actual_source
        assert actual_source.stat().st_size == helper['bytes'] and sha_file(actual_source) == helper['sha256']
        if design_copy and actual_source != source:
            helper_workspace_mismatches.append(str(source))
    workspace_match_count = None
    workspace_mismatches = []
    if compare_workspace:
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == HEAD
        source_names = subprocess.check_output(
            ['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=REPO, text=True
        ).splitlines()
        source_names = sorted(n for n in set(source_names) if n.endswith('.rs') or
                              Path(n).name in ('Cargo.toml', 'Cargo.toml.orig', 'Cargo.lock'))
        assert source_names == [row['path'] for row in freeze['sources']]
        for row in freeze['sources']:
            source = REPO / row['path']
            assert source.is_file() and not source.is_symlink(), source
            assert source.stat().st_size == row['bytes'] and sha_file(source) == row['sha256'], source
        workspace_match_count = len(source_names)
    else:
        for row in freeze['sources']:
            source = REPO / row['path']
            if not source.exists():
                workspace_mismatches.append(row['path'])
                continue
            assert not source.is_symlink(), source
            if source.is_file() and source.stat().st_size == row['bytes'] and sha_file(source) == row['sha256']:
                continue
            workspace_mismatches.append(row['path'])
    return {'freeze': freeze, 'workspace_match_count': workspace_match_count,
            'workspace_mismatches': workspace_mismatches,
            'historical_design_path_mapped_to_archive': helper_workspace_mismatches}


def validate_v1() -> tuple[dict, dict, dict, list[Path], list[str]]:
    failure = read_json(V1_FAILURE)
    assert failure.get('status') == 'invalid_protocol_admission_no_workflow_executed'
    assert failure.get('protocol_sha256') == V1_PROTOCOL_SHA
    assert failure.get('completed_workflows') == failure.get('measured_workflows') == 0
    assert failure.get('engine_measurement_available') is False
    assert failure.get('process_group_drained') is True
    protocol = read_json(V1_PROTOCOL)
    assert protocol.get('protocol_id') == 'merge-tail-attribution-771-v1'
    assert sha_file(V1_PROTOCOL) == V1_PROTOCOL_SHA
    receipt = read_json(V1_PROTOCOL_FREEZE)
    assert receipt.get('sha256') == V1_PROTOCOL_SHA
    assert receipt.get('status') == 'frozen_before_observer_harness_and_measurement'
    freeze_info = verify_freeze(V1_FREEZE, V1_PROTOCOL_SHA, 23, compare_workspace=False)
    artifact_receipt = read_json(V1_ARTIFACT_RECEIPT)
    binary = V1_ARTIFACT
    assert binary.is_file() and not binary.is_symlink()
    assert artifact_receipt.get('artifact') == str(binary)
    assert artifact_receipt.get('source_freeze_sha256') == sha_file(V1_FREEZE)
    assert artifact_receipt.get('bytes') == binary.stat().st_size
    assert artifact_receipt.get('artifact_sha256') == sha_file(binary)
    build = read_json(V1_BUILD_RECEIPT)
    assert build.get('status') == 'passed' and build.get('returncode') == 0
    assert build.get('process_group_drained') is True
    assert sha_file(V1_BUILD_RECEIPT.with_suffix('.log')) == build.get('log_sha256')
    for name, item in failure.get('evidence', {}).items():
        path = ROOT / name
        assert path.is_file() and not path.is_symlink()
        assert path.stat().st_size == item['bytes'] and sha_file(path) == item['sha256']
    historical_review = read_json(ROOT / 'merge-tail-primary-review-772.json')
    for field in ('reviewed_files', 'preserved_worker_drafts'):
        for name, expected in historical_review.get(field, {}).items():
            assert identity(ROOT / name) == {
                'path': str(ROOT / name), 'bytes': expected['bytes'], 'sha256': expected['sha256']}
    data_files, empty_dirs = validate_v1_data(failure)
    for step in V1_STEPS:
        step_receipt = read_json(ROOT / f'{step}-sequence-step.json')
        assert step_receipt.get('step') == step
        assert step_receipt.get('protocol_sha256') == V1_PROTOCOL_SHA
        assert step_receipt.get('source_freeze_sha256') == sha_file(V1_FREEZE)
        expected_code = 101 if step == 'merge-tail-preflight-off-771-a1' else 0
        assert step_receipt.get('returncode') == expected_code
        assert sha_file(ROOT / f'{step}-sequence-output.log') == step_receipt.get('output_sha256')
        guard = read_json(ROOT / f'{step}.json')
        expected_status = 'failed' if step == 'merge-tail-preflight-off-771-a1' else 'passed'
        assert guard.get('status') == expected_status and guard.get('process_group_drained') is True
        assert guard.get('returncode') == expected_code
        assert sha_file(ROOT / f'{step}.log') == guard.get('log_sha256')
    off_link = read_json(ROOT / 'merge-tail-preflight-off-771-a1-link.json')
    assert off_link.get('returncode') != 0 and off_link.get('protocol_sha256') == V1_PROTOCOL_SHA
    assert off_link.get('output') == str(V1_DATA / V1_STREAMS[0])
    sequence = read_json(ROOT / f'{V1}-sequence-identity.json')
    assert sequence.get('label') == V1 and sequence.get('protocol_sha256') == V1_PROTOCOL_SHA
    assert sequence.get('source_freeze_sha256') == sha_file(V1_FREEZE)
    assert not (ROOT / f'{V1}-sequence-completion.json').exists()
    assert not (ROOT / f'{V1}-decision.json').exists()
    assert not (ROOT / f'{V1}-preflight-verification.json').exists()
    return freeze_info, artifact_receipt, build, data_files, empty_dirs


def validate_v1_data(failure: dict) -> tuple[list[Path], list[str]]:
    assert V1_DATA.is_dir() and not V1_DATA.is_symlink()
    expected_rows = failure.get('failed_data_files', [])
    expected = {row['path'].removeprefix(f'{V1}/'): row for row in expected_rows}
    files, dirs = [], []
    for path in V1_DATA.rglob('*'):
        assert not path.is_symlink(), path
        if path.is_dir():
            dirs.append(path.relative_to(V1_DATA).as_posix())
        elif path.is_file():
            files.append(path)
        else:
            raise AssertionError(path)
    assert {path.relative_to(V1_DATA).as_posix() for path in files} == set(expected)
    assert set(dirs) == {'witnesses', V1_EMPTY_DIR}
    assert failure.get('retained_empty_directories') == [f'{V1}/{V1_EMPTY_DIR}']
    for path in files:
        relative = path.relative_to(V1_DATA).as_posix()
        row = expected[relative]
        assert path.stat().st_size == row['bytes'] and sha_file(path) == row['sha256']
        if path.parent == V1_DATA / 'witnesses':
            assert sha_file(path) == path.stem
    empty = V1_DATA / V1_EMPTY_DIR
    assert empty.is_dir() and not any(empty.iterdir())
    return files, [str(empty)]


def validate_v2() -> tuple[dict, dict, dict]:
    failure = read_json(V2_FAILURE)
    assert failure.get('status') == 'invalid_collector_protocol_stopped_before_workflow'
    assert failure.get('label') == V2 and failure.get('completed_workflows') == 0
    assert failure.get('measured_workflows') == 0 and failure.get('engine_measurement_available') is False
    assert failure.get('process_group_drained') is True
    assert not (ROOT / f'{V2}-sequence-identity.json').exists()
    assert not (ROOT / f'{V2}-sequence-completion.json').exists()
    assert not (ROOT / f'{V2}-decision.json').exists()
    assert not (ROOT / f'{V2}-artifact.json').exists()
    assert not (ROOT / f'{V2}-test-inventory.txt').exists()
    assert not (ROOT / f'{V2}-test').exists()
    assert not (ROOT / V2).exists()
    protocol = read_json(V2_PROTOCOL)
    assert sha_file(V2_PROTOCOL) == V2_PROTOCOL_SHA
    assert protocol.get('correction', {}).get('completed_prior_workflows') == 0
    assert protocol.get('workload', {}).get('resources', {}).get('spill_buffer_bytes') == 1048576
    v2_freeze_receipt = read_json(V2_PROTOCOL_FREEZE)
    assert v2_freeze_receipt.get('sha256') == V2_PROTOCOL_SHA
    assert v2_freeze_receipt.get('status') == 'frozen_before_corrected_harness_and_any_completed_workflow'
    freeze_info = verify_freeze(V2_FREEZE, V2_PROTOCOL_SHA, 28, compare_workspace=False,
                               design_copy=V2_DESIGN_PRESERVED)
    build = read_json(V2_BUILD_RECEIPT)
    assert build.get('status') == 'failed' and build.get('returncode') == -15
    assert build.get('process_group_drained') is True
    assert sha_file(V2_BUILD_RECEIPT.with_suffix('.log')) == build.get('log_sha256')
    evidence = failure.get('evidence', {})
    for name, row in evidence.items():
        path = ROOT / name
        assert path.is_file() and not path.is_symlink(), path
        assert path.stat().st_size == row['bytes'] and sha_file(path) == row['sha256'], path
    for evidence_name in (V2_BUILD_RECEIPT.name, V2_BUILD_RECEIPT.with_suffix('.log').name,
                          'merge-tail-build-773-a1-driver.log'):
        row = evidence.get(evidence_name)
        path = ROOT / evidence_name
        assert row is not None and path.stat().st_size == row['bytes']
        assert sha_file(path) == row['sha256']
    return freeze_info, build, failure


def validate_v3() -> tuple[dict, dict, dict, dict]:
    protocol = read_json(V3_PROTOCOL)
    assert protocol.get('protocol_id') == 'merge-tail-attribution-774-v3'
    assert protocol.get('production_commit') == HEAD and sha_file(V3_PROTOCOL) == V3_PROTOCOL_SHA
    assert protocol.get('correction', {}).get('completed_prior_workflows') == 0
    receipt = read_json(V3_PROTOCOL_FREEZE)
    assert receipt.get('protocol') == str(V3_PROTOCOL)
    assert receipt.get('sha256') == V3_PROTOCOL_SHA and receipt.get('bytes') == V3_PROTOCOL.stat().st_size
    assert receipt.get('status') == 'frozen_before_streaming_consumer_repair_and_any_completed_workflow'
    freeze_info = verify_freeze(V3_FREEZE, V3_PROTOCOL_SHA, 32, compare_workspace=True)

    review = read_json(ROOT / 'merge-tail-primary-review-774.json')
    assert review.get('status') == 'primary_review_passed_before_v3_source_freeze'
    assert review.get('protocol', {}).get('sha256') == V3_PROTOCOL_SHA
    assert review.get('completed_workflows_before_freeze') == 0 and review.get('test_count') == 16
    for row in review.get('prior_invalid_attempts', []):
        path = ROOT / Path(row['path']).name
        assert identity(path) == row
    for row in review.get('prior_primary_reviews', []):
        assert identity(ROOT / Path(row['path']).name) == row
    assert review.get('prior_frozen_helpers_unchanged_except_design_with_exact_archived_copy') is True
    final_log = ROOT / 'merge-tail-oracle-final-tests-774.log'
    initial_log = ROOT / 'merge-tail-oracle-pre-review-tests-774.log'
    assert identity(final_log) == review.get('test_log')
    assert identity(initial_log) == review.get('preserved_initial_test_failure')
    for row in review.get('helpers', []):
        assert identity(ROOT / Path(row['path']).name) == row

    build = read_json(V3_BUILD_RECEIPT)
    assert build.get('status') == 'passed' and build.get('returncode') == 0
    assert build.get('process_group_drained') is True
    assert sha_file(V3_BUILD_RECEIPT.with_suffix('.log')) == build.get('log_sha256')
    artifact = read_json(V3_ARTIFACT_RECEIPT)
    assert artifact.get('artifact') == str(V3_ARTIFACT)
    assert V3_ARTIFACT.is_file() and not V3_ARTIFACT.is_symlink()
    assert artifact.get('bytes') == V3_ARTIFACT.stat().st_size
    assert artifact.get('artifact_sha256') == sha_file(V3_ARTIFACT)
    assert artifact.get('source_freeze_sha256') == sha_file(V3_FREEZE)
    assert artifact.get('build_receipt_sha256') == sha_file(V3_BUILD_RECEIPT)

    verification = read_json(V3_VERIFICATION)
    assert verification.get('schema_version') == 'shardloom.merge_tail_attribution_verification.v1'
    assert verification.get('status') == 'passed' and verification.get('label') == V3
    assert verification.get('protocol_sha256') == V3_PROTOCOL_SHA
    assert verification.get('production_head') == HEAD
    assert verification.get('total_workflows') == 236 and verification.get('total_operations') == 236
    assert verification.get('preflight_workflows') == 40 and verification.get('measured_workflows') == 192
    assert verification.get('warmup_workflows') == 4 and verification.get('stream_count') == 6
    assert verification.get('production_optimization') is False
    assert verification.get('runtime_inputs') == 1901 and verification.get('helper_inputs') == 32
    assert verification.get('scope_result') in ('material_signal', 'no_signal')
    assert verification.get('actual_schedule_speedup') is False
    assert verification.get('all_complete_values_types_traces_and_decisions_recomputed') is True
    assert verification.get('all_frozen_sources_and_helpers_unchanged') is True
    assert verification.get('all_native_process_groups_drained') is True
    assert verification.get('owned_spill_directories_removed') is True
    assert verification.get('verifier') == identity(ROOT / 'verify_merge_tail_774.py')
    assert verification.get('source_binding') == identity(V3_FREEZE)
    assert verification.get('artifact_binding') == identity(V3_ARTIFACT_RECEIPT)
    assert verification.get('decision_binding') == identity(V3_DECISION)
    assert verification.get('sequence_identity') == identity(V3_SEQUENCE_IDENTITY)
    return freeze_info, artifact, build, verification


def validate_v3_sequence(verification: dict) -> tuple[dict, dict]:
    sequence_identity = read_json(V3_SEQUENCE_IDENTITY)
    completion = read_json(V3_SEQUENCE_COMPLETION)
    decision = read_json(V3_DECISION)
    assert sequence_identity.get('label') == V3 and sequence_identity.get('build') == V3_BUILD
    assert sequence_identity.get('protocol_sha256') == V3_PROTOCOL_SHA
    assert sequence_identity.get('source_freeze_sha256') == sha_file(V3_FREEZE)
    assert sequence_identity.get('build_receipt_sha256') == sha_file(V3_BUILD_RECEIPT)
    assert completion == {
        'status': 'completed', 'identity_sha256': sha_file(V3_SEQUENCE_IDENTITY),
        'decision_sha256': sha_file(V3_DECISION),
        'decision_scope_result': decision.get('scope_result'),
        'production_optimization': False,
    }
    assert decision.get('scope_result') == verification.get('scope_result')
    assert decision.get('production_optimization') is False
    assert decision.get('actual_schedule_speedup') is False
    for key, name in (
        ('sequence_sha256', 'run_merge_tail_sequence_774.py'),
        ('driver_sha256', 'merge_tail_driver_774.py'),
        ('guard_sha256', 'run_guarded_observed_757.py'),
        ('oracle_sha256', 'analyze_merge_tail_774.py'),
        ('protocol_sha256', V3_PROTOCOL.name),
        ('protocol_freeze_sha256', V3_PROTOCOL_FREEZE.name),
    ):
        assert sequence_identity.get(key) == sha_file(ROOT / name), name
    for step in V3_STEPS:
        receipt = read_json(ROOT / f'{step}-sequence-step.json')
        assert receipt.get('step') == step and receipt.get('returncode') == 0
        assert receipt.get('source_freeze_sha256') == sha_file(V3_FREEZE)
        assert receipt.get('protocol_sha256') == V3_PROTOCOL_SHA
        assert sha_file(ROOT / f'{step}-sequence-output.log') == receipt.get('output_sha256')
        if step == V3_STEPS[-1]:
            continue
        guard = read_json(ROOT / f'{step}.json')
        assert guard.get('status') == 'passed' and guard.get('returncode') == 0
        assert guard.get('process_group_drained') is True
        assert sha_file(ROOT / f'{step}.log') == guard.get('log_sha256')
        if step.startswith(('merge-tail-preflight-off-', 'merge-tail-preflight-on-', 'merge-tail-measure-')):
            link = read_json(ROOT / f'{step}-link.json')
            assert link.get('returncode') == 0 and link.get('sources_and_artifact_unchanged') is True
            assert link.get('artifact_sha256') == sha_file(V3_ARTIFACT)
    preflight = read_json(ROOT / f'{V3}-preflight-verification.json')
    assert preflight.get('preflight_passed') is True
    assert preflight.get('protocol_sha256') == V3_PROTOCOL_SHA
    assert sum(x['workflows'] for x in preflight['streams'].values()) == 40
    assert sum(x['operations'] for x in preflight['streams'].values()) == 40
    return decision, sequence_identity


def related_file_names() -> set[str]:
    return {path.name for path in ROOT.iterdir() if path.is_file() and
            (path.name.startswith(('merge-tail', 'merge_tail', 'package_merge_tail',
                                  'analyze_merge_tail', 'test_merge_tail_oracle',
                                  'run_merge_tail_sequence', 'verify_merge_tail')) or
             path.name.startswith('verify-merge-tail'))}


def collect_members(v1_info: dict, v2_info: dict, v3_info: dict,
                    v1_data_files: list[Path], v1_empty: list[str]) -> tuple[dict[str, Path], list[dict], dict]:
    assert related_file_names() <= INCLUDED | set(EXCLUDED), (
        'unallowlisted merge-tail files: '
        f'{sorted(related_file_names() - INCLUDED - set(EXCLUDED))}')
    for name in EXCLUDED:
        assert not (ROOT / name).is_symlink(), ROOT / name
    members: dict[str, Path] = {}
    for name in sorted(INCLUDED):
        add_file(members, f'evidence/{name}', ROOT / name)

    for item in (v1_info, v2_info, v3_info):
        freeze = item['freeze']
        label = freeze['protocol_sha256']
        if label == V1_PROTOCOL_SHA:
            source_label = V1
        elif label == V2_PROTOCOL_SHA:
            source_label = V2
        else:
            source_label = V3
        for helper in freeze['helpers']:
            path = Path(helper['path'])
            if source_label == V2 and path == REPO / 'docs/architecture/native-merge-tail-design-2026-10-19.md':
                path = V2_DESIGN_PRESERVED
            assert path.is_file() and not path.is_symlink(), path
            assert path.stat().st_size == helper['bytes'] and sha_file(path) == helper['sha256'], path
            member = ('evidence/merge-tail-design-v2-preserved-773.md'
                      if source_label == V2 and path == V2_DESIGN_PRESERVED
                      else archive_path(Path(helper['path'])))
            add_file(members, member, path)
        extra_root = ROOT / f'{source_label}-extra-sources'
        extra = add_tree(members, extra_root, f'sources/{source_label}-extra')
        assert len(extra) == len(freeze['extra_sources'])

    for path in v1_data_files:
        add_file(members, f'failed-v1/{path.relative_to(V1_DATA).as_posix()}', path)
    v3_files = []
    assert V3_DATA.is_dir() and not V3_DATA.is_symlink()
    for path in V3_DATA.rglob('*'):
        assert not path.is_symlink(), path
        if path.is_dir():
            assert path == V3_DATA / 'witnesses', path
        elif path.is_file():
            v3_files.append(path)
        else:
            raise AssertionError(path)
    streams = sorted(p for p in v3_files if p.parent == V3_DATA and p.suffix == '.jsonl')
    witnesses = sorted(p for p in v3_files if p.parent == V3_DATA / 'witnesses' and p.suffix == '.json')
    assert {p.name for p in streams} == set(V3_STREAMS)
    assert len(witnesses) == len([p for p in v3_files if p.parent == V3_DATA / 'witnesses'])
    for path in witnesses:
        assert len(path.stem) == 64 and all(c in '0123456789abcdef' for c in path.stem)
        assert sha_file(path) == path.stem
    assert set(v3_files) == set(streams + witnesses)
    for path in sorted(v3_files):
        add_file(members, f'raw-v3/{path.relative_to(V3_DATA).as_posix()}', path)
    records = [json.loads(line) for stream in streams for line in stream.read_text().splitlines()]
    assert len(records) == 236
    assert sum(record.get('cohort') == 'preflight' for record in records) == 40
    assert sum(bool(record.get('warmup')) for record in records) == 4
    assert sum(record.get('cohort') != 'preflight' and not record.get('warmup')
               for record in records) == 192
    referenced_witnesses = {
        record[key] for record in records for key in (
            'source_rows_witness', 'source_schema_witness', 'expected_rows_witness',
            'expected_schema_witness', 'actual_rows_witness', 'actual_schema_witness')
    }
    assert referenced_witnesses == {path.stem for path in witnesses}

    dirs = [{'path': f'failed-v1/{Path(path).name}/', 'type': 'empty_directory',
             'original_path': path} for path in v1_empty]
    coverage = {
        'strict_top_level_inclusions': sorted(INCLUDED),
        'strict_top_level_exclusions': [{'name': k, 'reason': v} for k, v in sorted(EXCLUDED.items())],
        'v1_partial_step_evidence': list(V1_STEPS),
        'v1_failed_raw_data': [str(p) for p in sorted(v1_data_files)],
        'v1_empty_owned_directories': v1_empty,
        'v1_frozen_helper_count': len(v1_info['freeze']['helpers']),
        'v2_frozen_helper_count': len(v2_info['freeze']['helpers']),
        'v3_frozen_helper_count': len(v3_info['freeze']['helpers']),
        'v3_raw_streams': [str(p) for p in streams],
        'v3_content_addressed_witnesses': [str(p) for p in witnesses],
        'v3_witness_count': len(witnesses),
        'v2_historical_design_source_mapped_to_preserved_copy':
            v2_info['historical_design_path_mapped_to_archive'],
        'v3_raw_record_count': len(records),
    }
    return members, dirs, coverage


def source_reconstruction_status(infos: list[dict]) -> list[dict]:
    result = []
    for label, info in zip((V1, V2, V3), infos):
        freeze = info['freeze']
        mismatches = info['workspace_mismatches']
        result.append({
            'label': label, 'base_commit': HEAD,
            'source_rows': len(freeze['sources']),
            'tracked_patch': str(ROOT / f'{label}-tracked.patch'),
            'extra_sources': str(ROOT / f'{label}-extra-sources'),
            'current_workspace_matching_rows': info['workspace_match_count'],
            'current_workspace_mismatch_paths': mismatches,
            'complete_base_snapshot_embedded': False,
            'reconstruction_requirement': 'Exact base commit object plus the frozen tracked patch and recorded extra-source copies.',
            'limitation': 'The portable packet contains source identity inventory and patch/extras, not a complete tracked base-tree snapshot.',
        })
    return result


def main() -> None:
    argparse.ArgumentParser(description=__doc__).parse_args()
    assert not DEST.exists(), f'refusing to overwrite {DEST}'
    require_local_path(ROOT, Path.home(), sys.platform)
    require_local_path(DEST, Path.home(), sys.platform)
    v1_info, v1_artifact, v1_build, v1_data_files, v1_empty = validate_v1()
    v2_info, v2_build, v2_failure = validate_v2()
    v3_info, v3_artifact, v3_build, verification = validate_v3()
    decision, sequence_identity = validate_v3_sequence(verification)
    assert (len(v1_info['freeze']['helpers']), len(v2_info['freeze']['helpers']),
            len(v3_info['freeze']['helpers'])) == (23, 28, 32)

    members, directories, coverage = collect_members(
        v1_info, v2_info, v3_info, v1_data_files, v1_empty)
    assert coverage['v3_witness_count'] == verification.get('full_content_witnesses')
    inventory, frozen = [], {}
    for member, source in sorted(members.items()):
        data = source.read_bytes()
        row = {'path': member, 'original_path': str(source), 'bytes': len(data),
               'sha256': sha_bytes(data)}
        inventory.append(row)
        frozen[member] = (row['bytes'], row['sha256'])

    archive_records = sorted([*inventory, *directories], key=lambda row: row['path'])
    storage = check_budgets(ROOT, DEST, ROOT, min_free_bytes=12 * GIB,
                            reserve_bytes=128 * MIB, max_workspace_bytes=100 * GIB,
                            max_log_bytes=192 * MIB)
    assert not DEST.exists()
    DEST.mkdir()
    archive_path_out = DEST / f'{NAME}.tar.xz'
    with tarfile.open(archive_path_out, mode='x:xz', format=tarfile.PAX_FORMAT, preset=6) as archive:
        for row in archive_records:
            if row.get('type') == 'empty_directory':
                info = tarfile.TarInfo(row['path'])
                info.type = tarfile.DIRTYPE
                info.mode, info.size = 0o755, 0
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                info.mtime = 0
                archive.addfile(info)
                continue
            source = members[row['path']]
            data = source.read_bytes()
            assert (len(data), sha_bytes(data)) == (row['bytes'], row['sha256'])
            info = tarfile.TarInfo(row['path'])
            info.size, info.mode = len(data), 0o644
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            info.mtime = 0
            archive.addfile(info, io.BytesIO(data))
    with tarfile.open(archive_path_out, mode='r:xz') as archive:
        assert archive.getnames() == [row['path'] for row in archive_records]
        for row in archive_records:
            member = archive.getmember(row['path'])
            if row.get('type') == 'empty_directory':
                assert member.isdir() and member.size == 0
            else:
                assert member.isfile() and member.size == row['bytes']
                payload = archive.extractfile(member).read()
                assert (len(payload), sha_bytes(payload)) == (row['bytes'], row['sha256'])
    for member, source in members.items():
        assert (source.stat().st_size, sha_file(source)) == frozen[member]

    manifest = {'schema_version': 'shardloom.evidence_member_manifest.v1',
                'all_members_reopened': True, 'members': inventory,
                'directories': directories}
    manifest_out = DEST / f'{NAME}.manifest.json.xz'
    with manifest_out.open('xb') as stream:
        stream.write(lzma.compress(encode_json(manifest), preset=6))
    assert json.loads(lzma.decompress(manifest_out.read_bytes())) == manifest

    index = {
        'schema_version': 'shardloom.merge_tail_portable_packet.v3',
        'status': 'passed', 'scope_result': verification['scope_result'],
        'production_optimization': False, 'actual_schedule_speedup': False,
        'claim_boundary': 'V3 finite attribution only; V1 and V2 are preserved invalid zero-workflow attempts and receive no decision credit.',
        'production_head': HEAD,
        'v3_protocol': identity(V3_PROTOCOL), 'v3_protocol_freeze': identity(V3_PROTOCOL_FREEZE),
        'v3_verification': identity(V3_VERIFICATION), 'v3_source_freeze': identity(V3_FREEZE),
        'v3_artifact_receipt': identity(V3_ARTIFACT_RECEIPT),
        'v3_build_receipt': identity(V3_BUILD_RECEIPT),
        'v3_tracked_patch': identity(ROOT / f'{V3}-tracked.patch'),
        'v3_decision': identity(V3_DECISION),
        'v3_sequence_identity': identity(V3_SEQUENCE_IDENTITY),
        'v3_sequence_completion': identity(V3_SEQUENCE_COMPLETION),
        'v3_measured_scope': {key: verification[key] for key in (
            'total_workflows', 'total_operations', 'preflight_workflows',
            'measured_workflows', 'warmup_workflows', 'scope_result')},
        'invalid_attempts': [
            {'label': V1, 'receipt': identity(V1_FAILURE), 'protocol_sha256': V1_PROTOCOL_SHA,
             'completed_workflows': 0, 'measured_workflows': 0,
             'engine_measurement_available': False, 'decision_credit': False,
             'source_freeze': identity(V1_FREEZE), 'tracked_patch': identity(ROOT / f'{V1}-tracked.patch'),
             'failed_data_files': [str(p) for p in v1_data_files],
             'empty_owned_directory': directories[0]['path']},
            {'label': V2, 'receipt': identity(V2_FAILURE), 'protocol_sha256': V2_PROTOCOL_SHA,
             'completed_workflows': 0, 'measured_workflows': 0,
             'engine_measurement_available': False, 'decision_credit': False,
             'source_freeze': identity(V2_FREEZE), 'tracked_patch': identity(ROOT / f'{V2}-tracked.patch'),
             'build_receipt': identity(V2_BUILD_RECEIPT), 'build_returncode': v2_build['returncode']},
        ],
        'compiled_artifacts_omitted': [
            {'path': str(V1_ARTIFACT), 'bytes': v1_artifact['bytes'],
             'sha256': v1_artifact['artifact_sha256'], 'reason': EXCLUDED[V1_ARTIFACT.name]},
            {'path': str(V3_ARTIFACT), 'bytes': v3_artifact['bytes'],
             'sha256': v3_artifact['artifact_sha256'], 'reason': EXCLUDED[V3_ARTIFACT.name]},
        ],
        'coverage': coverage,
        'historical_source_reconstruction': source_reconstruction_status(
            [v1_info, v2_info, v3_info]),
        'storage_check': {'guard': 'local_uat_storage.require_local_path and check_budgets',
            'before_write': storage,
            'limits': {'minimum_free_bytes': 12 * GIB, 'candidate_reserve_bytes': 128 * MIB,
                       'maximum_workspace_bytes': 100 * GIB, 'maximum_log_bytes': 192 * MIB}},
        'member_count': len(inventory), 'uncompressed_bytes': sum(row['bytes'] for row in inventory),
        'all_members_reopened': True,
        'archive': {'file': archive_path_out.name, 'bytes': archive_path_out.stat().st_size,
                    'sha256': sha_file(archive_path_out)},
        'manifest': {'file': manifest_out.name, 'bytes': manifest_out.stat().st_size,
                     'sha256': sha_file(manifest_out)},
    }
    with (DEST / f'{NAME}.json').open('xb') as stream:
        stream.write(encode_json(index))
    check_budgets(ROOT, DEST, ROOT, min_free_bytes=12 * GIB, reserve_bytes=0,
                  max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    print(json.dumps({'status': 'passed', 'members': len(inventory),
                      'invalid_prior_workflows': 0, 'v3_scope_result': verification['scope_result'],
                      'archive': index['archive'], 'manifest': index['manifest'],
                      'index': str(DEST / f'{NAME}.json'), 'all_members_reopened': True}))


if __name__ == '__main__':
    main()
