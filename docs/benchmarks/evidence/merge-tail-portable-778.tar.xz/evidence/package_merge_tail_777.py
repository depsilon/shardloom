"""Archive verified V4 attribution, debug checks, and all three invalid attempts.

No native execution or experiment decision occurs here. Earlier drafts remain
immutable; only their checked identity and archive utility functions are reused.
"""
from __future__ import annotations

import argparse
import io
import json
import lzma
from pathlib import Path
import subprocess
import sys
import tarfile

import package_merge_tail_775 as prior

ROOT, REPO, HEAD = prior.ROOT, prior.REPO, prior.HEAD
NAME = 'merge-tail-portable-777'
DEST = ROOT / NAME
V4 = 'merge-tail-attribution-776-a1'
DEBUG = 'merge-tail-debug-smoke-776-a1'
PROTOCOL_SHA = '111f66f588ae5f388170ce8b906f80fff21ba64d20e41e59eb7bf3df467fccf7'
FAILURE = ROOT / 'merge-tail-source-accounting-failure-775.json'
DESIGN = REPO / 'docs/architecture/native-merge-tail-design-2026-10-19.md'
VERSION_ROWS = (
    ('771', prior.V1_PROTOCOL_SHA, 23, None),
    ('773', prior.V2_PROTOCOL_SHA, 28, ROOT / 'merge-tail-design-v2-preserved-773.md'),
    ('774', prior.V3_PROTOCOL_SHA, 32, ROOT / 'merge-tail-design-v3-preserved-776.md'),
    ('776', PROTOCOL_SHA, 39, None),
)
RELEASE_STEPS = (
    'merge-tail-bind-776-a1', 'merge-tail-focused-spill-776-a1',
    'merge-tail-preflight-off-776-a1', 'merge-tail-preflight-on-776-a1',
    'merge-tail-preflight-check-776-a1',
    'merge-tail-measure-A-off-776-a1', 'merge-tail-measure-A-on-776-a1',
    'merge-tail-measure-B-on-776-a1', 'merge-tail-measure-B-off-776-a1',
    'merge-tail-decision-776-a1', 'merge-tail-final-binding-776-a1',
)
DEBUG_STEPS = (
    'merge-tail-debug-bind-776-a1', 'merge-tail-debug-focused-spill-776-a1',
    'merge-tail-debug-preflight-off-776-a1', 'merge-tail-debug-preflight-on-776-a1',
    'merge-tail-debug-preflight-check-776-a1', 'merge-tail-debug-final-binding-776-a1',
)


def step_files(steps):
    result = {s + suffix for s in steps for suffix in
              ('-sequence-step.json', '-sequence-output.log')}
    result |= {s + suffix for s in steps[:-1] for suffix in ('.json', '.log')}
    result |= {s + '-link.json' for s in steps if
               '-preflight-off-' in s or '-preflight-on-' in s or '-measure-' in s}
    return result


# The earlier draft anticipated these files. V3 stopped at the first preflight;
# they must remain absent, rather than being treated as passed or omitted samples.
NEVER_CREATED = {n for n in prior.V3_STEP_FILES
                 if any(n.startswith(s) for s in prior.V3_STEPS[3:])} | {
    f'{prior.V3}-decision.json', f'{prior.V3}-preflight-verification.json',
    f'{prior.V3}-sequence-completion.json', 'merge-tail-verification-775.json',
    'merge-tail-verifier-775.json', 'merge-tail-verifier-775.log',
    'merge-tail-verifier-775-driver.log', 'merge-tail-package-primary-review-776.json',
}
INCLUDED = (prior.INCLUDED - NEVER_CREATED) | step_files(RELEASE_STEPS) | step_files(DEBUG_STEPS) | {
    'merge-tail-attribution-protocol-776.json', 'merge-tail-protocol-freeze-776.json',
    f'{V4}-source-freeze.json', f'{V4}-tracked.patch', f'{V4}-artifact.json',
    f'{V4}-test-inventory.txt', f'{V4}-sequence-identity.json',
    f'{V4}-sequence-completion.json', f'{V4}-decision.json',
    f'{V4}-preflight-verification.json', 'merge-tail-verification-776.json',
    f'{DEBUG}-artifact.json', f'{DEBUG}-test-inventory.txt', f'{DEBUG}-identity.json',
    f'{DEBUG}-completion.json', f'{DEBUG}-preflight-verification.json',
    'merge-tail-debug-smoke-776-driver.log', 'merge-tail-sequence-776-driver.log',
    'merge-tail-design-v3-preserved-776.md', FAILURE.name,
    'merge-tail-primary-review-776.json', 'merge-tail-oracle-final-tests-776.log',
    'merge-tail-oracle-initial-tests-776.log', 'merge_tail_driver_776.py',
    'run_merge_tail_sequence_776.py', 'run_merge_tail_debug_smoke_776.py',
    'analyze_merge_tail_776.py', 'test_merge_tail_oracle_776.py', 'verify_merge_tail_776.py',
    'merge-tail-packet-inventory-777.json', 'merge-tail-packet-inventory-777.md',
    'package_merge_tail_777.py', 'verify_merge_tail_packet_777.py',
    'merge-tail-package-primary-review-777.json',
} | {s + suffix for s in (
    'merge-tail-build-776-a1', 'merge-tail-debug-build-776-a1',
    'merge-tail-debug-independent-776', 'merge-tail-verifier-776', 'merge-tail-package-preflight-777')
     for suffix in ('.json', '.log', '-driver.log')}
EXCLUDED = dict(prior.EXCLUDED)
EXCLUDED.update({
    f'{V4}-test': 'Release test executable; identity and compiler provenance retained, binary omitted.',
    f'{DEBUG}-test': 'Debug test executable; identity and compiler provenance retained, binary omitted.',
})
EXCLUDED.update({n: 'Produced by or after this archive; independently bound by the closeout evidence.'
                 for n in (
                     'merge-tail-package-777.json', 'merge-tail-package-777.log',
                     'merge-tail-package-777-driver.log', 'merge-tail-packet-verification-777.json',
                     'merge-tail-restoration-plan-777.json', 'merge-tail-packet-verify-777.json',
                     'merge-tail-packet-verify-777.log', 'merge-tail-packet-verify-777-driver.log')})
sha_file, identity, read_json = prior.sha_file, prior.identity, prior.read_json


def related_names():
    prefixes = ('merge-tail', 'merge_tail', 'package_merge_tail', 'analyze_merge_tail',
                'test_merge_tail_oracle', 'run_merge_tail_sequence', 'run_merge_tail_debug_smoke',
                'resume_merge_tail', 'verify_merge_tail', 'verify-merge-tail')
    return {p.name for p in ROOT.iterdir() if p.is_file() and p.name.startswith(prefixes)}


def checked_guard(name, status='passed', code=0):
    row = read_json(ROOT / f'{name}.json')
    assert row['status'] == status and row['returncode'] == code
    assert row['process_group_drained'] is True
    assert row['head'] == HEAD and row['cwd'] == str(REPO)
    assert row['driver_sha256'] == sha_file(ROOT / 'run_guarded_observed_757.py')
    assert row['log_sha256'] == sha_file(ROOT / f'{name}.log')
    return row


def checked_artifact(label, freeze_label):
    row = read_json(ROOT / f'{label}-artifact.json')
    binary = ROOT / f'{label}-test'
    assert row['artifact'] == str(binary)
    assert row['bytes'] == binary.stat().st_size and row['artifact_sha256'] == sha_file(binary)
    assert row['source_freeze_sha256'] == sha_file(ROOT / f'{freeze_label}-source-freeze.json')
    assert row['build_receipt_sha256'] == sha_file(ROOT / f"{row['build']}.json")
    assert row['build_log_sha256'] == sha_file(ROOT / f"{row['build']}.log")
    checked_guard(row['build'])
    return row


def checked_history():
    history = read_json(prior.HISTORY_VERIFICATION)
    assert history['status'] == 'passed' and history['production_head'] == HEAD
    assert history['base'] == identity(prior.BASE_INVENTORY)
    assert history['verifier'] == identity(ROOT / 'verify_merge_tail_history_774.py')
    assert history['invalid_attempts'] == [identity(prior.V1_FAILURE), identity(prior.V2_FAILURE)]
    checked_guard('merge-tail-history-verify-774')
    assert len(history['versions']) == 3
    for row, (version, _, count, design_copy) in zip(history['versions'], VERSION_ROWS[:3]):
        label = f'merge-tail-attribution-{version}-a1'
        assert row['label'] == label and row['runtime_inputs'] == 1901
        assert row['source_freeze'] == identity(ROOT / f'{label}-source-freeze.json')
        assert row['patch'] == identity(ROOT / f'{label}-tracked.patch')
        assert row['all_runtime_inputs_reconstructed_from_accepted_base_patch_and_extras'] is True
        assert len(row['helpers']) == count
        for h in row['helpers']:
            path = Path(h['retained']['path'])
            actual_path = design_copy if design_copy and path == DESIGN else path
            actual = identity(actual_path)
            assert (actual['bytes'], actual['sha256']) == (h['retained']['bytes'], h['retained']['sha256'])
    base = read_json(prior.BASE_INVENTORY)
    assert base['head'] == HEAD and len(base['sources']) == 1899
    paths = [p for p in prior.BASE.rglob('*') if p.is_file()]
    assert not any(p.is_symlink() for p in prior.BASE.rglob('*'))
    assert sorted(p.relative_to(prior.BASE).as_posix() for p in paths) == [r['path'] for r in base['sources']]
    for row in base['sources']:
        actual = identity(prior.BASE / row['path'])
        assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256'])
    return history, base


def checked_v3_failure():
    failure = read_json(FAILURE)
    assert failure['status'] == 'invalid_resident_source_counter_assertion'
    assert failure['label'] == prior.V3 and failure['protocol_sha256'] == prior.V3_PROTOCOL_SHA
    assert failure['completed_recorded_workflows'] == failure['measured_workflows'] == failure['engine_samples_emitted'] == 0
    assert failure['engine_measurement_available'] is False
    assert failure['public_native_operations_completed_before_harness_assertion'] == 1
    assert failure['completed_execution_counter_observed'] == 1
    assert failure['output_schema_and_certificate_checks_before_assertion_passed'] is True
    assert failure['final_cleanup_assertions_reached'] is False and failure['process_group_drained'] is True
    assert failure['production_bug_established'] is False
    for row in failure['evidence']:
        assert identity(Path(row['path'])) == row
    for row in failure['source_evidence']:
        relative = Path(row['path']).relative_to(REPO)
        extra = ROOT / f'{prior.V3}-extra-sources' / relative
        path = extra if extra.exists() else prior.BASE / relative
        actual = identity(path)
        assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256'])
    guard = checked_guard('merge-tail-preflight-off-774-a1', 'failed', 101)
    assert 'left: 0' in (ROOT / 'merge-tail-preflight-off-774-a1.log').read_text()
    assert guard['command'][-5:] == ['local_primitives::prepared_relational::tests::merge_cost_tests::native_merge_tail_attribution', '--exact', '--ignored', '--nocapture', '--test-threads=1']
    checked_guard('merge-tail-focused-spill-774-a2')
    assert 'test result: ok. 9 passed; 0 failed; 0 ignored;' in (ROOT / 'merge-tail-focused-spill-774-a2.log').read_text()
    prior.validate_continuation()
    paths = [Path(row['path']) for row in failure['failed_data_files']]
    assert set(paths) == {p for p in prior.V3_DATA.rglob('*') if p.is_file()}
    for row in failure['failed_data_files']:
        assert identity(Path(row['path'])) == row
    empty = [Path(p) for p in failure['retained_empty_directories']]
    assert len(empty) == 1 and empty[0].parent == prior.V3_DATA
    assert {p for p in prior.V3_DATA.rglob('*') if p.is_dir()} == {prior.V3_DATA / 'witnesses', *empty}
    assert all(not p.is_symlink() for p in prior.V3_DATA.rglob('*'))
    assert all(not any(p.iterdir()) for p in empty)
    assert (prior.V3_DATA / 'preflight-preflight-off.jsonl').stat().st_size == 0
    return failure, paths, empty


def checked_v4():
    verification = read_json(ROOT / 'merge-tail-verification-776.json')
    assert verification['status'] == 'passed' and verification['label'] == V4
    assert verification['protocol_sha256'] == PROTOCOL_SHA and verification['production_head'] == HEAD
    assert verification['total_workflows'] == verification['total_operations'] == 236
    assert verification['preflight_workflows'] == 40 and verification['measured_workflows'] == 192
    assert verification['warmup_workflows'] == 4 and verification['stream_count'] == 6
    assert verification['runtime_inputs'] == 1901 and verification['helper_inputs'] == 39
    assert verification['production_optimization'] is verification['actual_schedule_speedup'] is False
    for field in ('all_complete_values_types_traces_and_decisions_recomputed',
                  'all_frozen_sources_and_helpers_unchanged', 'all_native_process_groups_drained',
                  'owned_spill_directories_removed'):
        assert verification[field] is True
    assert verification['verifier'] == identity(ROOT / 'verify_merge_tail_776.py')
    checked_guard('merge-tail-verifier-776')
    checked_guard('merge-tail-debug-independent-776')
    debug = read_json(ROOT / f'{DEBUG}-completion.json')
    assert debug['status'] == 'passed' and debug['total_workflows'] == debug['total_operations'] == 40
    assert debug['measured_workflows'] == 0 and debug['focused_spill_tests'] == 9
    assert debug['decision_credit'] is debug['production_optimization'] is False
    assert debug['protocol_sha256'] == PROTOCOL_SHA
    assert debug['source_freeze_sha256'] == sha_file(ROOT / f'{V4}-source-freeze.json')
    assert verification['debug_smoke_completion'] == identity(ROOT / f'{DEBUG}-completion.json')
    assert verification['debug_preflight_workflows_without_decision_credit'] == 40
    for key, filename in (
        ('source_binding', f'{V4}-source-freeze.json'), ('artifact_binding', f'{V4}-artifact.json'),
        ('decision_binding', f'{V4}-decision.json'), ('sequence_identity', f'{V4}-sequence-identity.json')):
        assert verification[key] == identity(ROOT / filename)
    decision = read_json(ROOT / f'{V4}-decision.json')
    assert decision['scope_result'] == verification['scope_result'] in ('material_signal', 'no_signal')
    review = read_json(ROOT / 'merge-tail-primary-review-776.json')
    assert review['test_count'] == 18 and review['completed_recorded_workflows_before_freeze'] == 0
    assert review['test_log'] == identity(ROOT / 'merge-tail-oracle-final-tests-776.log')
    for row in review['helpers']:
        assert identity(Path(row['path'])) == row
    return verification, debug


def add_complete_data(members, label, member_root, workflows, stream_names):
    root = ROOT / label
    paths = [p for p in root.rglob('*') if p.is_file()]
    assert not any(p.is_symlink() for p in root.rglob('*'))
    assert {p for p in root.rglob('*') if p.is_dir()} == {root / 'witnesses'}
    streams = sorted(p for p in paths if p.parent == root)
    assert {p.name for p in streams} == set(stream_names)
    records = [json.loads(line) for p in streams for line in p.read_text().splitlines()]
    assert len(records) == workflows
    witnesses = {r[key] for r in records for key in (
        'source_rows_witness', 'source_schema_witness', 'expected_rows_witness',
        'expected_schema_witness', 'actual_rows_witness', 'actual_schema_witness')}
    expected = {root / 'witnesses' / f'{h}.json' for h in witnesses}
    assert set(paths) == set(streams) | expected
    for path in expected:
        assert sha_file(path) == path.stem
    for path in sorted(paths):
        prior.add_file(members, f'{member_root}/{path.relative_to(root).as_posix()}', path)
    return dict(workflows=workflows, streams=len(streams), witnesses=len(witnesses),
                complete_files=len(paths), member_root=member_root)


def main():
    argparse.ArgumentParser(description=__doc__).parse_args()
    assert not DEST.exists()
    prior.require_local_path(ROOT, Path.home(), sys.platform)
    prior.require_local_path(DEST, Path.home(), sys.platform)
    assert not any((ROOT / n).exists() for n in NEVER_CREATED)
    assert related_names() <= INCLUDED | set(EXCLUDED), sorted(related_names() - INCLUDED - set(EXCLUDED))
    assert not any((ROOT / n).is_symlink() for n in EXCLUDED)
    v1_info, _, _, v1_files, v1_empty = prior.validate_v1()
    v2_info, _, _ = prior.validate_v2()
    v3_info = prior.verify_freeze(prior.V3_FREEZE, prior.V3_PROTOCOL_SHA, 32,
                                compare_workspace=False, design_copy=VERSION_ROWS[2][3])
    v4_info = prior.verify_freeze(ROOT / f'{V4}-source-freeze.json', PROTOCOL_SHA, 39,
                                compare_workspace=True)
    history, base = checked_history()
    failure, v3_files, v3_empty = checked_v3_failure()
    verification, debug = checked_v4()
    checked_guard('merge-tail-package-preflight-777')
    artifacts = [(label, checked_artifact(label, freeze_label)) for label, freeze_label in (
        (prior.V1, prior.V1), (prior.V3, prior.V3), (V4, V4), (DEBUG, V4))]
    members = {}
    for name in sorted(INCLUDED):
        prior.add_file(members, f'evidence/{name}', ROOT / name)
    infos = [v1_info, v2_info, v3_info, v4_info]
    for (version, _, count, design_copy), info in zip(VERSION_ROWS, infos):
        label = f'merge-tail-attribution-{version}-a1'
        assert len(info['freeze']['helpers']) == count
        for helper in info['freeze']['helpers']:
            path = Path(helper['path'])
            retained = design_copy if design_copy and path == DESIGN else path
            actual = identity(retained)
            assert (actual['bytes'], actual['sha256']) == (helper['bytes'], helper['sha256'])
            prior.add_file(members, prior.archive_path(retained), retained)
        extra = prior.add_tree(members, ROOT / f'{label}-extra-sources', f'sources/{label}-extra')
        assert len(extra) == len(info['freeze']['extra_sources']) == 2
    assert len(prior.add_tree(members, prior.BASE, 'sources/accepted-base')) == len(base['sources']) == 1899
    directories = []
    for label, paths, empty, prefix in ((prior.V1, v1_files, v1_empty, 'failed-v1'),
                                      (prior.V3, v3_files, v3_empty, 'failed-v3')):
        for path in paths:
            prior.add_file(members, f'{prefix}/{path.relative_to(ROOT / label).as_posix()}', path)
        for directory in empty:
            directories.append(dict(path=f'{prefix}/{Path(directory).name}/', type='empty_directory',
                                    original_path=str(directory)))
    coverage = dict(
        release=add_complete_data(members, V4, 'raw-v4', 236, prior.V3_STREAMS),
        debug=add_complete_data(members, DEBUG, 'debug-v4', 40, prior.V3_STREAMS[:2]),
        accepted_base_files=1899, frozen_source_files_per_version=1901,
        helper_counts=[23, 28, 32, 39], strict_top_level_inclusions=sorted(INCLUDED),
        strict_top_level_exclusions=[dict(name=n, reason=r) for n, r in sorted(EXCLUDED.items())],
        never_created_v3_success_files=sorted(NEVER_CREATED),
        inventory_worker_result='partial; all member selection and verification completed by primary',
    )
    assert coverage['release']['witnesses'] == verification['full_content_witnesses']
    inventory = [dict(path=member, original_path=str(path), bytes=path.stat().st_size,
                      sha256=sha_file(path)) for member, path in sorted(members.items())]
    rows = sorted([*inventory, *directories], key=lambda row: row['path'])
    storage = prior.check_budgets(ROOT, DEST, ROOT, min_free_bytes=12 * prior.GIB,
                                 reserve_bytes=128 * prior.MIB, max_workspace_bytes=100 * prior.GIB,
                                 max_log_bytes=192 * prior.MIB)
    DEST.mkdir()
    archive_path = DEST / f'{NAME}.tar.xz'
    with tarfile.open(archive_path, mode='x:xz', format=tarfile.PAX_FORMAT, preset=6) as archive:
        for row in rows:
            info = tarfile.TarInfo(row['path'])
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            info.mtime = 0
            if row.get('type') == 'empty_directory':
                info.type, info.mode, info.size = tarfile.DIRTYPE, 0o755, 0
                archive.addfile(info)
            else:
                data = members[row['path']].read_bytes()
                assert (len(data), prior.sha_bytes(data)) == (row['bytes'], row['sha256'])
                info.mode, info.size = 0o644, len(data)
                archive.addfile(info, io.BytesIO(data))
    with tarfile.open(archive_path, 'r:xz') as archive:
        assert archive.getnames() == [r['path'] for r in rows]
        for row in rows:
            item = archive.getmember(row['path'])
            if row.get('type') == 'empty_directory':
                assert item.isdir() and item.size == 0
            else:
                assert item.isfile() and item.size == row['bytes']
                data = archive.extractfile(item).read()
                assert (len(data), prior.sha_bytes(data)) == (row['bytes'], row['sha256'])
                assert identity(members[row['path']]) == {
                    'path': row['original_path'], 'bytes': row['bytes'], 'sha256': row['sha256']}
    manifest = dict(schema_version='shardloom.evidence_member_manifest.v1',
                    all_members_reopened=True, members=inventory, directories=directories)
    manifest_path = DEST / f'{NAME}.manifest.json.xz'
    with manifest_path.open('xb') as stream:
        stream.write(lzma.compress(prior.encode_json(manifest), preset=6))
    assert json.loads(lzma.decompress(manifest_path.read_bytes())) == manifest
    index = dict(
        schema_version='shardloom.merge_tail_portable_packet.v5', status='passed',
        production_head=HEAD, production_optimization=False, actual_schedule_speedup=False,
        scope_result=verification['scope_result'],
        claim_boundary='V4 finite attribution only. V1/V2/V3 invalid attempts and debug preflight have no decision credit. V3 completed one public operation before its harness assertion but emitted no complete workflow or timing sample.',
        v4_verification=identity(ROOT / 'merge-tail-verification-776.json'),
        v4_protocol=identity(ROOT / 'merge-tail-attribution-protocol-776.json'),
        v4_source_freeze=identity(ROOT / f'{V4}-source-freeze.json'),
        v4_decision=identity(ROOT / f'{V4}-decision.json'),
        release_workflows=236, release_preflight_workflows=40, measured_workflows=192,
        warmup_workflows=4, debug_workflows_without_decision_credit=40,
        invalid_attempts=[dict(label=label, failure=identity(receipt), completed_recorded_workflows=0,
                               measured_workflows=0, public_operations_completed_before_failure=operations,
                               engine_measurement_available=False, decision_credit=False)
                          for label, receipt, operations in ((prior.V1, prior.V1_FAILURE, 0),
                              (prior.V2, prior.V2_FAILURE, 0), (prior.V3, FAILURE, 1))],
        debug_completion=identity(ROOT / f'{DEBUG}-completion.json'),
        compiled_artifacts_omitted=[dict(path=row['artifact'], bytes=row['bytes'],
            sha256=row['artifact_sha256'], reason=EXCLUDED[f'{label}-test']) for label, row in artifacts],
        accepted_base_inventory=identity(prior.BASE_INVENTORY),
        historical_reconstruction_proof=identity(prior.HISTORY_VERIFICATION),
        source_reconstruction=dict(versions=['771', '773', '774', '776'],
            verification='Independent packet verifier must reconstruct all four versions before observer removal.',
            limitation='Rust/Cargo source inputs are embedded; dependencies and compiled executables are not vendored.'),
        storage_admission_refusal=identity(prior.STORAGE_REFUSAL),
        continuation=identity(prior.CONTINUATION), storage_retry_changed_native_comparison=False,
        coverage=coverage, all_members_reopened=True, member_count=len(inventory),
        empty_directory_count=len(directories), uncompressed_bytes=sum(r['bytes'] for r in inventory),
        storage_check=dict(before_write=storage, minimum_free_bytes=12 * prior.GIB,
                           candidate_reserve_bytes=128 * prior.MIB, maximum_workspace_bytes=100 * prior.GIB,
                           maximum_log_bytes=192 * prior.MIB),
        archive=dict(file=archive_path.name, bytes=archive_path.stat().st_size, sha256=sha_file(archive_path)),
        manifest=dict(file=manifest_path.name, bytes=manifest_path.stat().st_size, sha256=sha_file(manifest_path)),
    )
    with (DEST / f'{NAME}.json').open('xb') as stream:
        stream.write(prior.encode_json(index))
    prior.check_budgets(ROOT, DEST, ROOT, min_free_bytes=12 * prior.GIB, reserve_bytes=0,
                        max_workspace_bytes=100 * prior.GIB, max_log_bytes=192 * prior.MIB)
    print(json.dumps(dict(status='passed', members=len(inventory), release_workflows=236,
                         debug_workflows_without_decision_credit=40, invalid_recorded_workflows=0,
                         scope_result=verification['scope_result'], index=str(DEST / f'{NAME}.json'))))


if __name__ == '__main__':
    main()
