"""Continue the unchanged V3 sequence after storage refused to launch its test child."""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    seq = module('frozen_merge_sequence', ROOT / 'run_merge_tail_sequence_774.py')
    driver = module('frozen_merge_driver', seq.DRIVER)
    freeze_path = ROOT / f'{seq.LABEL}-source-freeze.json'
    freeze = json.loads(freeze_path.read_text())
    driver.verify_sources(freeze)
    driver.historical_sources(seq.LABEL, freeze)
    original_identity_path = ROOT / f'{seq.LABEL}-sequence-identity.json'
    original = json.loads(original_identity_path.read_text())
    assert original['sequence_sha256'] == seq.sha(ROOT / 'run_merge_tail_sequence_774.py')
    assert original['source_freeze_sha256'] == seq.sha(freeze_path)
    artifact = json.loads((ROOT / f'{seq.LABEL}-artifact.json').read_text())
    assert seq.sha(seq.BINARY) == artifact['artifact_sha256']
    failed_name = 'merge-tail-focused-spill-774-a1'
    failure_path = ROOT / 'merge-tail-storage-admission-failure-775.json'
    failure = json.loads(failure_path.read_text())
    guard = json.loads((ROOT / f'{failed_name}.json').read_text())
    assert failure['completed_workflows'] == failure['measured_workflows'] == 0
    assert failure['no_child_launched'] is True and failure['cleanup_performed'] is False
    assert guard['status'] == 'failed' and guard.get('pid') is None and guard.get('returncode') is None
    assert guard['error'].startswith('StorageGuardError: insufficient free disk:')
    assert not (ROOT / f'{failed_name}.log').exists()
    assert not seq.DATA.exists()
    for row in failure['evidence']:
        path = Path(row['path'])
        assert path.stat().st_size == row['bytes'] and seq.sha(path) == row['sha256']
    for name in (f'{seq.LABEL}-sequence-completion.json', f'{seq.LABEL}-decision.json', f'{seq.LABEL}-preflight-verification.json'):
        assert not (ROOT / name).exists()
    identity_path = ROOT / 'merge-tail-continuation-identity-775.json'
    identity = dict(
        status='bound_before_retry_of_never_launched_native_step',
        original_sequence_identity_sha256=seq.sha(original_identity_path),
        source_freeze_sha256=seq.sha(freeze_path), protocol_sha256=seq.sha(seq.PROTOCOL),
        artifact_sha256=artifact['artifact_sha256'], storage_failure_sha256=seq.sha(failure_path),
        failed_step=failed_name, replacement_step='merge-tail-focused-spill-774-a2',
        completed_workflows_before_continuation=0, native_comparison_changed=False,
        extra_helpers=[dict(path=str(ROOT / name), sha256=seq.sha(ROOT / name))
                       for name in ('resume_merge_tail_sequence_775.py', 'verify_merge_tail_775.py')])
    seq.save(identity_path, identity)
    seq.run_step('merge-tail-resume-binding-775',
                 [seq.PYTHON, '-B', str(seq.DRIVER), 'verify', '--label', seq.LABEL], freeze_path)
    name = identity['replacement_step']
    seq.run_step(name, seq.guarded(name, [str(seq.BINARY),
                 'local_primitives::prepared_relational::tests::spill_tests::',
                 '--nocapture', '--test-threads=1']), freeze_path)
    assert 'test result: ok. 9 passed; 0 failed; 0 ignored;' in (ROOT / f'{name}.log').read_text()
    for role in seq.ROLES:
        name = f'merge-tail-preflight-{role}-774-a1'
        seq.run_step(name, [seq.PYTHON, '-B', str(seq.DRIVER), 'run', '--label', seq.LABEL,
                     '--name', name, '--mode', 'preflight', '--role', role,
                     '--cohort', 'preflight', '--data', seq.LABEL], freeze_path)
    preflight_path = ROOT / f'{seq.LABEL}-preflight-verification.json'
    name = 'merge-tail-preflight-check-774-a1'
    seq.run_step(name, seq.guarded(name, [seq.PYTHON, '-B', str(seq.ORACLE), 'preflight',
                 '--data', str(seq.DATA), '--output', str(preflight_path)]), freeze_path)
    preflight = json.loads(preflight_path.read_text())
    assert preflight['protocol_sha256'] == seq.sha(seq.PROTOCOL) and preflight['preflight_passed'] is True
    assert sum(r['workflows'] for r in preflight['streams'].values()) == 40
    assert sum(r['operations'] for r in preflight['streams'].values()) == 40
    for cohort, roles in seq.COHORT_ORDER:
        for role in roles:
            name = f'merge-tail-measure-{cohort}-{role}-774-a1'
            seq.run_step(name, [seq.PYTHON, '-B', str(seq.DRIVER), 'run', '--label', seq.LABEL,
                         '--name', name, '--mode', 'measure', '--role', role,
                         '--cohort', cohort, '--data', seq.LABEL], freeze_path)
    decision_path = ROOT / f'{seq.LABEL}-decision.json'
    name = 'merge-tail-decision-774-a1'
    seq.run_step(name, seq.guarded(name, [seq.PYTHON, '-B', str(seq.ORACLE), 'decision',
                 '--data', str(seq.DATA), '--output', str(decision_path)]), freeze_path)
    decision = json.loads(decision_path.read_text())
    assert decision['protocol_sha256'] == seq.sha(seq.PROTOCOL)
    assert decision['scope_result'] in ('material_signal', 'no_signal')
    seq.run_step('merge-tail-final-binding-774-a1',
                 [seq.PYTHON, '-B', str(seq.DRIVER), 'verify', '--label', seq.LABEL], freeze_path)
    for row in identity['extra_helpers']:
        assert seq.sha(row['path']) == row['sha256']
    assert seq.sha(original_identity_path) == identity['original_sequence_identity_sha256']
    completion = dict(status='completed', identity_sha256=seq.sha(original_identity_path),
                      decision_sha256=seq.sha(decision_path), decision_scope_result=decision['scope_result'],
                      production_optimization=False, continuation_identity_sha256=seq.sha(identity_path))
    seq.save(ROOT / f'{seq.LABEL}-sequence-completion.json', completion)
    print('COMPLETE unchanged V3 sequence after recorded storage admission retry.', flush=True)


if __name__ == '__main__': main()
