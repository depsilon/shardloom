import importlib.util
import hashlib
import json
import tempfile
import unittest
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch

SCRIPT = Path(__file__).with_name("analyze_merge_tail_771.py")
SPEC = importlib.util.spec_from_file_location("merge_oracle", SCRIPT)
oracle = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(oracle)


def snap(live, peak, written, validated):
    return {"live_disk_bytes": live, "peak_disk_bytes": peak, "runs_written": written, "runs_validated": validated}


def one_merge_trace(reverse_parents=False, bad_live=False):
    base = snap(0, 0, 0, 0)
    s1 = snap(32868, 32868, 1, 1)
    s2 = snap(32968, 32968, 2, 2)
    sw = snap(33118 + (1 if bad_live else 0), 33118, 3, 3)
    sr = snap(32918, 33118, 3, 3)
    st = snap(32768, 33118, 3, 3)
    zero = snap(0, 33118, 3, 3)
    events = [
        {"event": "owner", "owner": 1, "buffer_bytes": 131072, "block_rows": 1024, "reader_work_bytes": 131072},
        {"event": "leaf", "owner": 1, "run": {"id": "L", "rows": 4096, "bytes": 100, "level": 0, "start": 0, "end": 4096, "block_rows": 1024}, "before": base, "after_write": s1, "elapsed_ns": 1, "readers": 0},
        {"event": "leaf", "owner": 1, "run": {"id": "R", "rows": 4096, "bytes": 100, "level": 0, "start": 4096, "end": 8192, "block_rows": 1024}, "before": s1, "after_write": s2, "elapsed_ns": 2, "readers": 0},
        {"event": "merge", "owner": 1, "phase": "ingest", "left": "R" if reverse_parents else "L", "right": "L" if reverse_parents else "R", "output": {"id": "M", "rows": 8192, "bytes": 150, "level": 1, "start": 0, "end": 8192, "block_rows": 1024}, "before": s2, "after_write": sw, "after_removal": sr, "elapsed_ns": 3, "readers_during_write": 2, "readers_after_removal": 0},
        {"event": "frontier", "owner": 1, "run_ids": ["M"], "snapshot": sr, "readers": 0},
        {"event": "terminal_removal", "owner": 1, "run_id": "M", "before": sr, "after_removal": st, "readers": 0, "readers_during_read": 1},
        {"event": "cleanup", "before": st, "after": zero, "readers": 0},
    ]
    record = {"role": "on", "spill": True, "rows": 8192, "engine_execution_ns": 100}
    report = {"peak_disk_bytes": 33118, "runs_written": 3, "runs_validated": 3, "merge_passes": 1, "max_open_runs": 2, "run_block_rows": 1024}
    return record, {"enabled": True, "event_limit": 4096, "marker_bytes": 32768, "events": events}, report


def brute_cost(weights):
    if len(weights) <= 1: return 0
    total = sum(weights)
    return total + min(brute_cost(weights[:k + 1]) + brute_cost(weights[k + 1:]) for k in range(len(weights) - 1))


def seven_leaf_trace():
    events = [{"event": "owner", "owner": 1, "buffer_bytes": 131072, "block_rows": 1024, "reader_work_bytes": 131072}]
    current = snap(0, 0, 0, 0)
    stack = []
    merge_count = 0

    def write(size):
        nonlocal current
        before = dict(current)
        live = before["live_disk_bytes"] + size + (32768 if not before["runs_written"] else 0)
        current = snap(live, max(live, before["peak_disk_bytes"]), before["runs_written"] + 1, before["runs_validated"] + 1)
        return before, dict(current)

    def merge(phase):
        nonlocal current, merge_count
        right, left = stack.pop(), stack.pop()
        merge_count += 1
        output = {"id": f"M{merge_count}", "rows": left["rows"] + right["rows"], "bytes": left["bytes"] + right["bytes"] - 7, "level": max(left["level"], right["level"]) + 1, "start": left["start"], "end": right["end"], "block_rows": 1024}
        current["runs_validated"] += 2  # Actual run validation can precede the write event.
        before, after_write = write(output["bytes"])
        current["live_disk_bytes"] -= left["bytes"] + right["bytes"]
        events.append({"event": "merge", "owner": 1, "phase": phase, "left": left["id"], "right": right["id"], "output": output, "before": before, "after_write": after_write, "after_removal": dict(current), "elapsed_ns": 10, "readers_during_write": 2, "readers_after_removal": 0})
        stack.append(output)

    for i in range(7):
        run = {"id": f"L{i}", "rows": 2048, "bytes": 100 + 20 * i, "level": 0, "start": 2048 * i, "end": 2048 * (i + 1), "block_rows": 1024}
        before, after = write(run["bytes"])
        events.append({"event": "leaf", "owner": 1, "run": run, "before": before, "after_write": after, "elapsed_ns": 2, "readers": 0})
        stack.append(run)
        while len(stack) > 1 and stack[-1]["level"] == stack[-2]["level"]:
            merge("ingest")
    events.append({"event": "frontier", "owner": 1, "run_ids": [r["id"] for r in stack], "snapshot": dict(current), "readers": 0})
    while len(stack) > 1:
        merge("final_tail")
    last = stack.pop()
    current["runs_validated"] += 1
    before = dict(current)
    current["live_disk_bytes"] -= last["bytes"]
    events.append({"event": "terminal_removal", "owner": 1, "run_id": last["id"], "before": before, "after_removal": dict(current), "readers": 0, "readers_during_read": 1})
    before = dict(current)
    current["live_disk_bytes"] = 0
    events.append({"event": "cleanup", "before": before, "after": dict(current), "readers": 0})
    report = {"peak_disk_bytes": current["peak_disk_bytes"], "runs_written": current["runs_written"], "runs_validated": current["runs_validated"], "merge_passes": merge_count, "max_open_runs": 2, "run_block_rows": 1024}
    return {"role": "on", "spill": True, "rows": 14336, "engine_execution_ns": 1000, "observation": {"enabled": True, "event_limit": 4096, "marker_bytes": 32768, "events": events}}, report


def small_record(data, rows, spill, role):
    def store(value):
        raw = json.dumps(value, separators=(",", ":")).encode()
        h = oracle.digest(raw)
        p = data / "witnesses" / f"{h}.json"
        p.parent.mkdir(exist_ok=True)
        p.write_bytes(raw)
        return h
    source = oracle.source_rows(rows, "uniform24")
    sr, out, schema = store(source), store(oracle.expected_output(source)), store(oracle.SOURCE_SCHEMA)
    cid = oracle.cell_id(rows, "uniform24", spill)
    report = None
    events = []
    if spill:
        report = {"workspace": str(data / f"spill-{cid}-{role}-preflight-0-false"), "quota_bytes": 134217728, "buffer_bytes": 131072, "peak_disk_bytes": 0, "runs_written": 0, "runs_validated": 0, "merge_passes": 0, "max_open_runs": 0, "run_block_rows": 0, "owned_cleanup_completed": True}
        if role == "on":
            events = [{"event": "owner", "owner": 1, "buffer_bytes": 131072, "block_rows": 1024, "reader_work_bytes": 131072}, {"event": "cleanup", "before": snap(0, 0, 0, 0), "after": snap(0, 0, 0, 0), "readers": 0}]
    return {"cell_id": cid, "rows": rows, "profile": "uniform24", "spill": spill, "role": role, "cohort": "preflight", "sample": 0, "warmup": False, "source_rows_witness": sr, "source_schema_witness": schema, "expected_rows_witness": out, "expected_schema_witness": schema, "actual_rows_witness": out, "actual_schema_witness": schema, "preparation_ns": 2, "engine_execution_ns": 10, "result_serialization_ns": 3, "execution_and_consumption_ns": 14, "output_release_ns": 1, "destruction_ns": 3, "complete_workflow_ns": 20, "native_io_certificate": {"certified": True, "fallback_attempted": False, "spill_io_performed": False, "complete_debug": "test certificate"}, "spill_report": report, "completed_executions": 1, "prepared_source_opens": 1, "admitted_max_parallelism": 1, "provider_background_workers": 0, "peak_reserved_bytes": 100, "reserved_after_cleanup": 0, "denied_reservations": 0, "owned_spill_directory_empty": True, "observation": {"enabled": role == "on", "event_limit": 4096, "marker_bytes": 32768, "events": events}}


class MergeTailOracleTests(unittest.TestCase):
    def test_protocol_hash_cells_and_profiles(self):
        self.assertEqual(oracle.digest(oracle.PROTOCOL.read_bytes()), oracle.PROTOCOL_SHA256)
        self.assertEqual(len(oracle.matrix()), 16)
        self.assertEqual(oracle.width_for(32767, "quarters_up", 0), 24)
        self.assertEqual(oracle.width_for(32767, "quarters_up", 32766), 512)
        self.assertEqual(oracle.width_for(32767, "wide_head", 0), 512)
        self.assertEqual(oracle.width_for(32767, "wide_tail", 32766), 512)

    def test_interval_dp_matches_enumeration_and_rightmost_direction(self):
        for weights in ([1], [1, 1], [1, 1, 1], [1, 10, 100], [3, 7, 2, 9], [4, 1, 8, 2, 5]):
            tree, cost, right, right_cost = oracle._merge_tree_and_cost(list(weights))
            self.assertEqual(cost, brute_cost(list(weights)))
            self.assertEqual(right_cost, self.rightmost_brute(list(weights)))
            self.assertEqual(cost <= right_cost, True)
        self.assertEqual(oracle._merge_tree_and_cost([100, 10, 1])[2:], ([0, [1, 2]], 122))
        self.assertEqual(oracle._merge_tree_and_cost([1, 10, 100])[:2], ([[0, 1], 2], 122))
        self.assertEqual(oracle._merge_tree_and_cost([1, 1, 1])[:2], ([0, [1, 2]], 5))

    @staticmethod
    def rightmost_brute(weights):
        if len(weights) <= 1: return 0
        return sum(weights) + MergeTailOracleTests.rightmost_brute(weights[1:])

    def test_synthetic_lineage_and_disk_accounting(self):
        rec, obs, report = one_merge_trace()
        rec["observation"] = obs
        trace = oracle.validate_trace(rec, report)
        self.assertEqual(trace["runs_written"], 3)
        self.assertEqual(trace["frontier"][0]["interval"], [0, 8192])
        self.assertEqual(trace["actual_tree"], "M")
        rec, obs, report = one_merge_trace(reverse_parents=True)
        rec["observation"] = obs
        with self.assertRaises(oracle.Invalid): oracle.validate_trace(rec, report)
        rec, obs, report = one_merge_trace(bad_live=True)
        rec["observation"] = obs
        with self.assertRaises(oracle.Invalid): oracle.validate_trace(rec, report)

    def test_bad_witness_identity_hash_and_decoded_content(self):
        with tempfile.TemporaryDirectory() as td:
            data = Path(td)
            (data / "witnesses").mkdir()
            raw = b"[{\"ordinal\":1}]"
            h = hashlib.sha256(raw).hexdigest()
            (data / "witnesses" / f"{h}.json").write_bytes(raw)
            self.assertEqual(oracle.witness(data, h, [{"ordinal": 1}], "ok"), [{"ordinal": 1}])
            with self.assertRaises(oracle.Invalid): oracle.witness(data, h, [{"ordinal": 2}], "wrong value")
            with self.assertRaises(oracle.Invalid): oracle.witness(data, "x" * 64, [], "wrong bytes")
            with self.assertRaises(oracle.Invalid): oracle.witness(data, "not-hash", [], "malformed identity")
            original = data / "witnesses" / f"{h}.json"
            backing = data / "backing.json"
            original.rename(backing)
            original.symlink_to(backing)
            with self.assertRaises(oracle.Invalid): oracle.witness(data, h, [{"ordinal": 1}], "linked witness")

    def test_empty_off_and_resident_traces_require_no_events(self):
        record = {"role": "off", "spill": True, "rows": 17, "engine_execution_ns": 10}
        record["observation"] = {"enabled": False, "event_limit": 4096, "marker_bytes": 32768, "events": []}
        self.assertEqual(oracle.validate_trace(record, {"peak_disk_bytes": 0, "runs_written": 0, "runs_validated": 0, "merge_passes": 0, "max_open_runs": 0, "run_block_rows": 0}), {"frontier": [], "dp_tree": None, "dp_cost": 0, "rightmost_tree": None, "rightmost_cost": 0, "tail_time_ns": 0, "tail_input_bytes": 0, "leaf_merge_time_ns": 0})
        record["observation"] = {"enabled": False, "event_limit": 4096, "marker_bytes": 32768, "events": [{"event": "owner"}]}
        with self.assertRaises(oracle.Invalid): oracle.validate_trace(record, {})

    def test_seven_leaves_tail_and_reader_validation_advances(self):
        record, report = seven_leaf_trace()
        result = oracle.validate_trace(record, report)
        self.assertEqual([r["level"] for r in result["frontier"]], [2, 1, 0])
        self.assertEqual(result["actual_tree"], ["M3", ["M4", "L6"]])
        self.assertEqual(result["rightmost_tree"], result["actual_tree"])
        self.assertEqual(result["tail_time_ns"], 20)
        self.assertEqual(result["runs_written"], 13)
        self.assertEqual(result["merge_passes"], 6)
        self.assertEqual(report["runs_validated"], 26)

    def test_adversarial_trace_mutations(self):
        original, report = seven_leaf_trace()
        changes = [
            (1, "owner", 2), (1, "readers", 1), (1, "run.rows", True),
            (1, "run.start", 1), (1, "run.level", False),
            (3, "left", "L1"), (3, "output.rows", 4095),
            (3, "phase", "final_tail"), (3, "readers_during_write", 3),
            (3, "readers_after_removal", 1),
            (3, "after_removal.runs_validated", 2),
            (3, "after_write.live_disk_bytes", 0),
            (-2, "owner", 2), (-2, "readers_during_read", 0),
            (-2, "readers_during_read", True), (-2, "readers", 1),
            (-1, "after.live_disk_bytes", 1), (-1, "readers", 1),
            (0, "block_rows", 1025),
        ]
        for index, key, value in changes:
            with self.subTest(index=index, key=key, value=value):
                record = deepcopy(original)
                dest = record["observation"]["events"][index]
                parts = key.split(".")
                for part in parts[:-1]: dest = dest[part]
                dest[parts[-1]] = value
                with self.assertRaises(oracle.Invalid): oracle.validate_trace(record, report)
        for index in (3, -2, -1):
            record = deepcopy(original)
            del record["observation"]["events"][index]
            with self.assertRaises(oracle.Invalid): oracle.validate_trace(record, report)

    def test_dp_rejects_invalid_weights_and_oversized_frontier(self):
        for weights in ([True], [0], [-1], [1.0], [1] * 65):
            with self.assertRaises(oracle.Invalid): oracle._merge_tree_and_cost(weights)
        self.assertEqual(oracle._merge_tree_and_cost([]), (None, 0, None, 0))

    def test_nullable_key_order_and_stable_ties(self):
        source = [{"k": k, "tie": tie, "ordinal": i} for i, (k, tie) in enumerate([(None, 2), (1, 2), (1, None), (1, 3), (1, 3), (None, None), (-1, 2)])]
        self.assertEqual([r["ordinal"] for r in oracle.expected_output(source)], [6, 2, 3, 4, 1, 5, 0])

    def test_complete_empty_and_small_records_and_failures(self):
        with tempfile.TemporaryDirectory() as td:
            data = Path(td)
            for rows in (0, 17):
                for spill in (False, True):
                    for role in ("off", "on"):
                        rec = small_record(data, rows, spill, role)
                        oracle.validate_record(data, rec, "preflight", role, "preflight", 0, (rows, "uniform24", spill), False)
            original = small_record(data, 17, True, "on")
            changes = [("complete_workflow_ns", 21), ("execution_and_consumption_ns", 12), ("completed_executions", True), ("prepared_source_opens", 2), ("provider_background_workers", 1), ("reserved_after_cleanup", 1), ("denied_reservations", 1), ("peak_reserved_bytes", 67108865), ("actual_rows_witness", original["source_rows_witness"]), ("native_io_certificate.fallback_attempted", True), ("native_io_certificate.spill_io_performed", True), ("spill_report.workspace", "wrong"), ("spill_report.owned_cleanup_completed", 1), ("spill_report.runs_written", 1)]
            for key, value in changes:
                with self.subTest(key=key):
                    rec = deepcopy(original)
                    dest = rec
                    parts = key.split(".")
                    for part in parts[:-1]: dest = dest[part]
                    dest[parts[-1]] = value
                    with self.assertRaises(oracle.Invalid): oracle.validate_record(data, rec, "preflight", "on", "preflight", 0, (17, "uniform24", True), False)

    def test_stream_counts_identity_and_reverse_order(self):
        def metadata(data, rec, mode, role, cohort, sample, spec, warm):
            oracle.need(rec == [list(spec), sample, warm], "incorrect stream order")
            return {}
        # This isolates sequencing; the independent real-record test above validates values.
        with tempfile.TemporaryDirectory() as td:
            data = Path(td)
            for mode, role, cohort in (("preflight", "on", "preflight"), ("measure", "off", "A"), ("measure", "on", "B")):
                records = []
                if mode == "preflight":
                    records.extend([[n, "uniform24", spill], 0, False] for spill in (True, False) for n in (0, 17))
                else: records.append([[8192, "uniform24", False], 0, True])
                cells = list(reversed(oracle.matrix())) if cohort == "B" else oracle.matrix()
                records.extend([list(spec), sample, False] for spec in cells for sample in ((0,) if mode == "preflight" else (0, 1, 2)))
                # Actual streams contain objects; metadata wrapper retains that envelope.
                envelopes = [{"identity": r} for r in records]
                def wrapped(*args):
                    args = list(args)
                    args[1] = args[1]["identity"]
                    return metadata(*args)
                path = oracle.stream_path(data, mode, role, cohort)
                def save(items): path.write_text("".join(json.dumps(r) + "\n" for r in items))
                with patch.object(oracle, "validate_record", side_effect=wrapped):
                    save(envelopes)
                    self.assertEqual(oracle.read(data, mode, role, cohort)["summary"]["workflows"], 20 if mode == "preflight" else 49)
                    save(envelopes[:-1])
                    with self.assertRaises(oracle.Invalid): oracle.read(data, mode, role, cohort)
                    swapped = deepcopy(envelopes)
                    swapped[-1], swapped[-2] = swapped[-2], swapped[-1]
                    save(swapped)
                    with self.assertRaises(oracle.Invalid): oracle.read(data, mode, role, cohort)

    def test_frozen_gate_boundaries_and_sample_medians(self):
        off = [{"engine_execution_ns": 10_000_000, "complete_workflow_ns": 20_000_000}] * 3
        on = deepcopy(off)
        trace = {"rightmost_cost": 10_485_760, "dp_cost": 9_437_184, "rightmost_tree": [0, [1, 2]], "dp_tree": [[0, 1], 2], "tail_time_ns": 2_000_000}
        traces = [deepcopy(trace) for _ in range(3)]
        decide = lambda: oracle._decision_cell("A", off, on, [], traces)
        self.assertTrue(decide()["qualifies"])
        for r in on: r["engine_execution_ns"] = 11_000_000
        self.assertTrue(decide()["observer_eligible"])  # Exactly 10% and 1 ms is eligible.
        for r in on: r["engine_execution_ns"] += 1
        self.assertFalse(decide()["observer_eligible"])
        on = deepcopy(off)
        for r in on: r["complete_workflow_ns"] = 22_000_001
        self.assertFalse(decide()["observer_eligible"])
        on = deepcopy(off)
        for t in traces: t["tail_time_ns"] -= 1
        self.assertFalse(decide()["tail_work_gate"])
        traces = [deepcopy(trace) for _ in range(3)]
        for t in traces: t["dp_cost"] += 1
        self.assertFalse(decide()["byte_cost_gate"])
        traces = [deepcopy(trace) for _ in range(3)]
        traces[0]["dp_cost"] = traces[0]["rightmost_cost"]
        traces[0]["dp_tree"] = traces[0]["rightmost_tree"]
        self.assertTrue(decide()["qualifies"])  # Protocol uses medians, not all-three acceptance.
        self.assertEqual(decide()["sample_distinct_lower_cost_tree"], [False, True, True])
        traces[1] = deepcopy(traces[0])
        self.assertFalse(decide()["qualifies"])

    def test_material_signal_requires_the_same_cell_in_both_cohorts(self):
        target_b = 1
        def read_bundle(data, mode, role, cohort):
            if mode == "preflight": return {"records": [], "trace_summaries": [], "summary": {"workflows": 20}}
            records, summaries = [], []
            for index, spec in enumerate(oracle.matrix()):
                cid = oracle.cell_id(*spec)
                for sample in (0, 1, 2):
                    records.append({"cell_id": cid, "sample": sample, "warmup": False, "engine_execution_ns": 10_000_000, "complete_workflow_ns": 20_000_000, "source_rows_witness": "same-source", "actual_rows_witness": "same-output", "actual_schema_witness": "same-schema", "spill_report": {} if spec[2] else None})
                    good = role == "on" and index == (0 if cohort == "A" else target_b)
                    summaries.append({"rightmost_cost": 10_485_760, "dp_cost": 9_437_184 if good else 10_485_760, "rightmost_tree": [0, [1, 2]], "dp_tree": [[0, 1], 2] if good else [0, [1, 2]], "tail_time_ns": 2_000_000})
            return {"records": records, "trace_summaries": summaries, "summary": {"workflows": 49}}
        with patch.object(oracle, "read", side_effect=read_bundle):
            result = oracle.analyze(Path("unused"))
            self.assertEqual(result["scope_result"], "no_signal")
            self.assertEqual(result["qualifying_spill_cells"], [])
            target_b = 0
            result = oracle.analyze(Path("unused"))
            self.assertEqual(result["scope_result"], "material_signal")
            self.assertEqual(result["qualifying_spill_cells"], [oracle.cell_id(*oracle.matrix()[0])])


if __name__ == "__main__": unittest.main()
