"""Freeze, bind, verify, and supervise native merge-tail attribution runs."""

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PROTOCOL = OUT / 'merge-tail-attribution-protocol-771.json'
PROTOCOL_FREEZE = OUT / 'merge-tail-protocol-freeze-771.json'
PROTOCOL_SHA = 'e2ffc917bf17d64bffdc0f27943e86f12345ceaeb29a65ee69d290279eaa6a72'
PRODUCTION_HEAD = 'd732d7889207e7d8fc0de8d746de1623174c1dcf'
GUARD = OUT / 'run_guarded_observed_757.py'
SELECTOR = 'local_primitives::prepared_relational::tests::merge_cost_tests::native_merge_tail_attribution'
LABEL = 'merge-tail-attribution-771-a1'
BUILD_NAME = 'merge-tail-build-771-a1'
SEQUENCE = OUT / 'run_merge_tail_sequence_771.py'
ANALYZER = OUT / 'analyze_merge_tail_771.py'
ORACLE_TEST = OUT / 'test_merge_tail_oracle_771.py'

# Imports used by run_guarded_observed_757.py. Hash them into the freeze so
# its execution environment is bound along with the direct helpers.
GUARD_DEPENDENCY_SOURCES = (
    ('repo', 'scripts/local_uat_storage.py'),
    ('repo', 'scripts/run_clickbench_paired_query_uat.py'),
    ('repo', 'scripts/native_workflow_protocol.py'),
    ('repo', 'scripts/query_timing_report.py'),
    ('repo', 'scripts/clickbench_reference_packet.py'),
    ('repo', 'scripts/run_clickbench_query_uat.py'),
    ('repo', 'python/src/shardloom/__init__.py'),
    ('repo', 'python/src/shardloom/_exports.py'),
    ('repo', 'python/src/shardloom/_result_schema.py'),
    ('repo', 'python/src/shardloom/errors.py'),
    ('repo', 'python/src/shardloom/_compat.py'),
    ('repo', 'python/src/shardloom/models.py'),
    ('local', 'release-0.3.3-20260930/release_validation_guard.py'),
    ('local', 'perf-all-20260906/bounded_build_process_resume_20260912.py'),
)
GUARD_DEPENDENCIES = [
    REPO / relative if origin == 'repo' else Path('/Users/dylan/LocalData/shardloom') / relative
    for origin, relative in GUARD_DEPENDENCY_SOURCES
]
HELPERS = [PROTOCOL, PROTOCOL_FREEZE, Path(__file__), SEQUENCE, GUARD, ANALYZER, ORACLE_TEST,
           OUT / 'merge-tail-primary-review-772.json', OUT / 'merge-tail-oracle-final-tests-772.log',
           *GUARD_DEPENDENCIES]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def source_paths():
    names = subprocess.check_output(
        ['git', 'ls-files', '--cached', '--others', '--exclude-standard'],
        cwd=REPO, text=True).splitlines()
    return sorted(path for path in set(names) if path.endswith('.rs') or
                  Path(path).name in ('Cargo.toml', 'Cargo.toml.orig', 'Cargo.lock'))


def verify_protocol_freeze():
    receipt = json.loads(PROTOCOL_FREEZE.read_text())
    assert receipt['protocol'] == str(PROTOCOL)
    assert receipt['sha256'] == PROTOCOL_SHA == sha(PROTOCOL)
    assert receipt['bytes'] == PROTOCOL.stat().st_size
    assert receipt['production_commit'] == PRODUCTION_HEAD
    assert receipt['status'] == 'frozen_before_observer_harness_and_measurement'


def verify_sources(freeze):
    verify_protocol_freeze()
    assert source_paths() == [row['path'] for row in freeze['sources']]
    for row in freeze['sources']:
        path = REPO / row['path']
        assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], row['path']
    for row in freeze['helpers']:
        path = Path(row['path'])
        assert path.is_file() and not path.is_symlink()
        assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], row['path']


def historical_sources(label, freeze):
    patch = OUT / f'{label}-tracked.patch'
    assert sha(patch) == freeze['patch_sha256']
    source_by_path = {row['path']: row for row in freeze['sources']}
    extra_root = OUT / f'{label}-extra-sources'
    declared = set(freeze['extra_sources'])
    actual = {path.relative_to(extra_root).as_posix()
              for path in extra_root.rglob('*') if path.is_file() and not path.is_symlink()}
    assert actual == declared
    for relative in sorted(declared):
        copied = extra_root / relative
        assert copied.is_file() and not copied.is_symlink()
        expected = source_by_path[relative]
        assert copied.stat().st_size == expected['bytes'] and sha(copied) == expected['sha256'], relative


def make_run_command(binary, name, mode, role, cohort, data):
    assert mode in ('preflight', 'measure')
    assert role in ('off', 'on')
    assert cohort in ('preflight', 'A', 'B')
    assert (mode == 'preflight') == (cohort == 'preflight')
    data = Path(data)
    assert data.parent == OUT and data.name.startswith('merge-tail-')
    data.mkdir(exist_ok=True)
    return [sys.executable, str(GUARD), '--name', name, '--timeout', '1800', '--', '/usr/bin/env',
            f'SHARDLOOM_MERGE_ROOT={data}', f'SHARDLOOM_MERGE_MODE={mode}',
            f'SHARDLOOM_MERGE_ROLE={role}', f'SHARDLOOM_MERGE_COHORT={cohort}',
            str(binary), SELECTOR, '--exact', '--ignored', '--nocapture', '--test-threads=1']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['freeze', 'bind', 'verify', 'run'])
    parser.add_argument('--label', required=True)
    parser.add_argument('--build')
    parser.add_argument('--name')
    parser.add_argument('--mode', choices=['preflight', 'measure'])
    parser.add_argument('--role', choices=['off', 'on'])
    parser.add_argument('--cohort', default='preflight', choices=['preflight', 'A', 'B'])
    parser.add_argument('--data', default='merge-tail-attribution-771-a1')
    args = parser.parse_args()
    assert args.label == LABEL
    verify_protocol_freeze()
    freeze_path = OUT / f'{args.label}-source-freeze.json'
    artifact_path = OUT / f'{args.label}-artifact.json'

    if args.action == 'freeze':
        head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
        assert head == PRODUCTION_HEAD
        paths = source_paths()
        sources = [dict(path=path, bytes=(REPO / path).stat().st_size, sha256=sha(REPO / path))
                   for path in paths]
        patch = OUT / f'{args.label}-tracked.patch'
        with patch.open('xb') as stream:
            stream.write(subprocess.check_output(['git', 'diff', 'HEAD', '--binary'], cwd=REPO))
        untracked = subprocess.check_output(
            ['git', 'ls-files', '--others', '--exclude-standard'], cwd=REPO, text=True).splitlines()
        extras = [path for path in untracked if path in paths]
        for relative in extras:
            target = OUT / f'{args.label}-extra-sources' / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            assert not target.exists()
            shutil.copyfile(REPO / relative, target)
        helpers = []
        seen = set()
        for helper in HELPERS:
            helper = Path(helper).resolve(strict=True)
            if helper in seen:
                continue
            seen.add(helper)
            helpers.append(dict(path=str(helper), bytes=helper.stat().st_size, sha256=sha(helper)))
        save(freeze_path, dict(head=head, sources=sources, extra_sources=extras,
                               patch_sha256=sha(patch), protocol_sha256=PROTOCOL_SHA,
                               protocol_freeze_sha256=sha(PROTOCOL_FREEZE), helpers=helpers))
        print(json.dumps(dict(source_freeze=str(freeze_path), sha256=sha(freeze_path),
                              runtime_inputs=len(sources), helper_inputs=len(helpers))))
        return

    freeze = json.loads(freeze_path.read_text())
    assert freeze['head'] == PRODUCTION_HEAD and freeze['protocol_sha256'] == PROTOCOL_SHA
    assert freeze['protocol_freeze_sha256'] == sha(PROTOCOL_FREEZE)
    historical_sources(args.label, freeze)
    verify_sources(freeze)

    if args.action == 'bind':
        assert args.build == BUILD_NAME
        build_path = OUT / f'{args.build}.json'
        build = json.loads(build_path.read_text())
        assert build['status'] == 'passed' and build['process_group_drained'] is True
        assert build['returncode'] == 0
        build_log = OUT / f'{args.build}.log'
        assert sha(build_log) == build['log_sha256']
        artifacts = []
        for line in build_log.read_text().splitlines():
            if not line.startswith('{'):
                continue
            item = json.loads(line)
            if (item.get('reason') == 'compiler-artifact' and
                    item.get('target', {}).get('name') == 'shardloom_vortex' and
                    item.get('profile', {}).get('test')):
                artifacts.append(item)
        assert len(artifacts) == 1 and artifacts[0]['executable'] and not artifacts[0]['fresh']
        compiler_artifact = artifacts[0]
        source_binary = Path(compiler_artifact['executable'])
        binary = OUT / f'{args.label}-test'
        assert source_binary.is_file() and not binary.exists()
        shutil.copy2(source_binary, binary)
        assert binary.stat().st_size == source_binary.stat().st_size and sha(binary) == sha(source_binary)
        inventory = subprocess.check_output([str(binary), '--list'], text=True)
        assert f'{SELECTOR}: test' in inventory
        inventory_path = OUT / f'{args.label}-test-inventory.txt'
        with inventory_path.open('x') as stream:
            stream.write(inventory)
        save(artifact_path, dict(artifact=str(binary), artifact_sha256=sha(binary),
                                 bytes=binary.stat().st_size, source_freeze_sha256=sha(freeze_path),
                                 build=args.build, build_receipt_sha256=sha(build_path),
                                 build_log_sha256=sha(build_log), compiler_artifact=compiler_artifact,
                                 selector=SELECTOR, inventory_sha256=sha(inventory_path)))
        print(json.dumps(dict(artifact=str(binary), sha256=sha(binary))))
        return

    artifact = json.loads(artifact_path.read_text())
    binary = Path(artifact['artifact'])
    assert binary.stat().st_size == artifact['bytes'] and sha(binary) == artifact['artifact_sha256']
    assert sha(freeze_path) == artifact['source_freeze_sha256']
    assert artifact['selector'] == SELECTOR
    if args.action == 'verify':
        print(json.dumps(dict(workspace_sources_unchanged=True,
                              artifact_and_historical_source_binding_unchanged=True)))
        return

    assert args.name and args.mode and args.role
    data = OUT / args.data
    command = make_run_command(binary, args.name, args.mode, args.role, args.cohort, data)
    record = dict(command=command, role=args.role, mode=args.mode, cohort=args.cohort,
                  artifact_sha256=sha(binary), source_freeze_sha256=sha(freeze_path),
                  protocol_sha256=PROTOCOL_SHA, protocol_freeze_sha256=sha(PROTOCOL_FREEZE),
                  driver_sha256=sha(__file__), guard_sha256=sha(GUARD), returncode=None)
    try:
        code = subprocess.call(command, cwd=REPO)
        record['returncode'] = code
        verify_sources(freeze)
        historical_sources(args.label, freeze)
        assert sha(binary) == artifact['artifact_sha256']
        record['sources_and_artifact_unchanged'] = True
        output = data / f'{args.mode}-{args.cohort}-{args.role}.jsonl'
        if output.exists():
            record.update(output=str(output), output_sha256=sha(output), output_bytes=output.stat().st_size)
    finally:
        save(OUT / f'{args.name}-link.json', record)
    raise SystemExit(code)


if __name__ == '__main__':
    main()
