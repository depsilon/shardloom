"""Validate the test-only admission-pressure correction and production-source equivalence."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
D=O/'dictionary-pressure-validation-692'
sys.path.insert(0,str(O))
from freeze_native_release_298 import sources,save,sha
read=lambda p:json.loads(Path(p).read_text())
assert not D.exists();D.mkdir()
before=read(O/'native-release-source-roadmap663.json')['source_sha256']
after=sources()
path='shardloom-vortex/src/local_primitives/dictionary_prepare_workers.rs'
changed={p:dict(before=before[p],after=digest) for p,digest in after.items() if before[p]!=digest}
assert len(before)==len(after)==2416 and set(changed)=={path}
old=subprocess.check_output(['git','show','29aa4cf068b6b75dd61543463f00683d70c8147f:'+path],cwd=R).decode()
new=(R/path).read_text()
old_block='''        #[cfg(test)]
        let _test_pressure = SUBMIT_TEST_PRESSURE.with(std::cell::Cell::take).then(|| {
            self.jobs
                .memory()
                .reserve(self.available_bytes().saturating_sub(1024))
                .unwrap()
        });
'''
new_block='''        #[cfg(test)]
        let bytes = if SUBMIT_TEST_PRESSURE.with(std::cell::Cell::take) {
            // Exercise worker admission retirement without exhausting the shared
            // grant: an active provider may still need to reserve read buffers.
            // Real allocation denial and retry are covered separately.
            u64::MAX
        } else {
            bytes
        };
'''
assert old.count(old_block)==new.count(new_block)==1
assert old.replace(old_block,'')==new.replace(new_block,'')
assert hashlib.sha256(old.encode()).hexdigest()==before[path]
assert hashlib.sha256(new.encode()).hexdigest()==after[path]
save(D/'test-only-source-bridge.json',dict(status='passed',source_files=2416,changes=changed,
    production_code_unchanged_by_exact_cfg_test_elision=True,source_sha256=after,
    accepted_runtime_source_sha256=before))
(D/'before.rs').write_text(old);(D/'after.rs').write_text(new)
receipt=read(O/'dictionary-pressure-regressions-691a2.json')
assert receipt['status']=='passed' and receipt['returncode']==0 and receipt['process_group_drained']
log=(O/'dictionary-pressure-regressions-691a2.log').read_text()
counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
assert len(counts)==1 and int(counts[0][0])>=10 and counts[0][1:]==('0','0'),counts
assert 'dictionary_preparation_numeric_native_ordinary_prepared_owned_and_pressure ... ok' in log
assert 'aggregate_utf8_context_dictionary_preparation_refuses_and_retries ... ok' in log
assert 'dictionary_preparation_preserves_chunk_order_and_drains_before_pressure_retirement ... ok' in log
assert 'dictionary_preparation_native_pressure_restores_provider_only_after_pool_retirement ... ok' in log
checks=[]
for name,command in [
    ('format',['cargo','fmt','--all','--','--check']),
    ('workspace-clippy',['cargo','clippy','--offline','--locked','--workspace','--all-targets','--','-D','warnings']),
    ('workspace-tests',['cargo','test','--offline','--locked','--workspace','--all-targets'])]:
    output=D/(name+'.log')
    with output.open('xb') as stream:
        result=subprocess.run(command,cwd=R,stdout=stream,stderr=subprocess.STDOUT)
    checks.append(dict(name=name,command=command,returncode=result.returncode,
        log=dict(file=output.name,bytes=output.stat().st_size,sha256=sha(output))))
    assert result.returncode==0,(name,output.read_text()[-3000:])
    print(json.dumps(dict(check=name,status='passed')),flush=True)
assert sources()==after
report=dict(status='passed',changes=changed,source_files=2416,
    production_code_unchanged_by_exact_cfg_test_elision=True,
    focused_tests=int(counts[0][0]),focused_log=dict(path=str(O/'dictionary-pressure-regressions-691a2.log'),sha256=sha(O/'dictionary-pressure-regressions-691a2.log')),
    checks=checks,source_bridge=dict(file='test-only-source-bridge.json',sha256=sha(D/'test-only-source-bridge.json')),
    original_failure=dict(ci_run=39130883999,job=117685968840,head='29aa4cf068b6b75dd61543463f00683d70c8147f',
        log_sha256=sha(O/'pr1575-native-failure-690.log'),passed=2967,failed=1,ignored=28,
        failing_test='local_primitives::dictionary_prepare_workers_tests::dictionary_preparation_numeric_native_ordinary_prepared_owned_and_pressure'),
    cause='The test-only hook retained all but 1024 bytes of the shared grant; a concurrent provider requested 11320 bytes while 67107840 of 67108864 bytes were reserved. The denied read was correct; the synthetic worker-admission stimulus starved an unrelated owner.',
    correction='Under cfg(test) only, inflate this worker task admission request to u64::MAX. The unchanged production retirement path is exercised without reserving the provider grant. Existing separate fixtures retain real memory denial, retry, ordered drain and cleanup coverage.',
    benchmark_run=False,version_bump='held',hosted_validation='Final changed head requires fresh CI; previous failed observation is retained.')
save(D/'validation.json',report)
save(O/'native-release-source-pressure692.json',dict(status='passed',source_sha256=after,
    production_code_unchanged_by_exact_cfg_test_elision=True,accepted_runtime_source=before,changes=changed))
print(json.dumps(dict(status='passed',focused_tests=report['focused_tests'],baseline_checks=len(checks))))
