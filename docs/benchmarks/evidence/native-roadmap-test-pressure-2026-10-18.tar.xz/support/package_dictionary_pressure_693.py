"""Preserve the failed CI observation and verified test-only correction."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
D=O/'dictionary-pressure-validation-692'
read=lambda p:json.loads(Path(p).read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
result=read(D/'validation.json')
receipt=read(O/'dictionary-pressure-gates-692.json')
assert result['status']==receipt['status']=='passed' and receipt['process_group_drained']
assert len(result['checks'])==3 and all(c['returncode']==0 for c in result['checks'])
assert result['production_code_unchanged_by_exact_cfg_test_elision']
for path,change in result['changes'].items():assert sha((R/path).read_bytes())==change['after']
files={}
for path in sorted(D.rglob('*')):
    if path.is_file():files['validation/'+path.relative_to(D).as_posix()]=path.read_bytes()
for name in ['pr1575-native-failure-690.log','dictionary-pressure-regressions-691.json',
    'dictionary-pressure-regressions-691.log','dictionary-pressure-regressions-691a2.json',
    'dictionary-pressure-regressions-691a2.log','dictionary-pressure-gates-692.json',
    'dictionary-pressure-gates-692.log','run_dictionary_pressure_gates_692.py',
    'run_guarded.py','native-release-source-pressure692.json','package_dictionary_pressure_693.py']:
    files['support/'+name]=(O/name).read_bytes()
assert sum(map(len,files.values()))<8*1024*1024
evidence=R/'docs/benchmarks/evidence'
archive=evidence/'native-roadmap-test-pressure-2026-10-18.tar.xz'
index=archive.with_suffix('').with_suffix('.json')
assert not archive.exists() and not index.exists()
members=[]
with tarfile.open(archive,'x:xz') as bundle:
    for name,raw in sorted(files.items()):
        entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mode=0o644
        bundle.addfile(entry,io.BytesIO(raw));members.append(dict(name=name,bytes=len(raw),sha256=sha(raw)))
with tarfile.open(archive,'r:xz') as bundle:
    assert len(bundle.getmembers())==len(files)==len({m.name for m in bundle.getmembers()})
    for member in members:
        entry=bundle.getmember(member['name']);assert entry.isfile()
        assert bundle.extractfile(entry).read()==files[member['name']]
report=dict(schema_version='shardloom.native_roadmap_test_pressure_correction.v1',**result,
    archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes())),
    members=members,member_count=len(members),all_members_reopened=True,
    initial_local_attempt='The first local invocation used a CI lane label as a Cargo feature and ran no tests. It is retained separately; the corrected release-user-surfaces invocation is the accepted focused run.')
index.open('x').write(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(status='passed',index=str(index),focused_tests=result['focused_tests'],members=len(members))))
