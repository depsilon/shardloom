use std::{
    fs,
    path::{Path, PathBuf},
    process::Command,
};

#[cfg(unix)]
use std::os::unix::fs as unix_fs;

fn run_object_store_write_smoke_json(args: &[String]) -> (bool, String, String) {
    let mut command = Command::new(env!("CARGO_BIN_EXE_shardloom"));
    command.args(args);
    if matches!(
        args.first().map(String::as_str),
        Some("object-store-write-smoke" | "object-store-write-recovery-smoke")
    ) {
        command.args(["--memory-gb", "4", "--max-parallelism", "2"]);
    }
    let output = command
        .arg("--format")
        .arg("json")
        .output()
        .expect("object-store-write-smoke command runs");

    (
        output.status.success(),
        String::from_utf8(output.stdout).expect("stdout is utf8"),
        String::from_utf8(output.stderr).expect("stderr is utf8"),
    )
}

fn run_object_store_write_recovery_smoke_json(args: &[String]) -> (bool, String, String) {
    let mut command = Command::new(env!("CARGO_BIN_EXE_shardloom"));
    command.args(args);
    if matches!(
        args.first().map(String::as_str),
        Some("object-store-write-smoke" | "object-store-write-recovery-smoke")
    ) {
        command.args(["--memory-gb", "4", "--max-parallelism", "2"]);
    }
    let output = command
        .arg("--format")
        .arg("json")
        .output()
        .expect("object-store-write-recovery-smoke command runs");

    (
        output.status.success(),
        String::from_utf8(output.stdout).expect("stdout is utf8"),
        String::from_utf8(output.stderr).expect("stderr is utf8"),
    )
}

fn field(key: &str, value: &str) -> String {
    format!("{{\"key\":\"{key}\",\"value\":\"{value}\"}}")
}

fn field_key(key: &str) -> String {
    format!("\"key\":\"{key}\"")
}

fn assert_json_fields(output: &str, expected_fields: &[(&str, &str)]) {
    for (key, value) in expected_fields {
        assert!(
            output.contains(&field(key, value)),
            "missing field {key}={value} in output: {output}"
        );
    }
}

fn assert_json_field_keys(output: &str, expected_keys: &[&str]) {
    for key in expected_keys {
        assert!(
            output.contains(&field_key(key)),
            "missing field {key} in output: {output}"
        );
    }
}

fn assert_local_write_commit_evidence_fields(output: &str) {
    assert_json_fields(
        output,
        &[
            ("object_store_write_request_count", "2"),
            ("object_store_commit_manifest_write_request_count", "1"),
            ("object_store_payload_bytes_written", "14"),
            (
                "object_store_write_bounded_status",
                "bounded_payload_and_manifest_under_fixture_budget",
            ),
            (
                "object_store_multipart_write_status",
                "not_required_single_object_local_emulator_commit",
            ),
            ("object_store_multipart_part_count", "0"),
            (
                "object_store_write_retry_policy_status",
                "not_required_single_attempt_local_emulator_commit",
            ),
            ("object_store_write_retry_attempt_count", "0"),
            (
                "object_store_write_rate_limit_policy_status",
                "not_required_local_emulator_no_network",
            ),
            ("object_store_rollback_cleanup_request_count", "0"),
            (
                "object_store_ambiguous_commit_status",
                "not_observed_local_commit_manifest_written",
            ),
            (
                "object_store_idempotency_scope",
                "single_object_target_payload_digest",
            ),
            ("object_store_write_cache_hit_count", "0"),
            ("object_store_write_cache_miss_count", "0"),
        ],
    );
    assert_json_field_keys(
        output,
        &[
            "object_store_commit_manifest_bytes_written",
            "object_store_total_bytes_written",
        ],
    );
}

fn assert_write_recovery_replay_evidence_fields(output: &str) {
    assert_json_fields(
        output,
        &[
            ("object_store_recovery_read_request_count", "2"),
            ("object_store_recovery_object_bytes_read", "19"),
            (
                "object_store_recovery_retry_policy_status",
                "not_required_single_attempt_local_emulator_recovery",
            ),
            ("object_store_recovery_retry_attempt_count", "0"),
            (
                "object_store_recovery_rate_limit_policy_status",
                "not_required_local_emulator_no_network",
            ),
            (
                "object_store_recovery_ambiguous_commit_status",
                "replay_matched_sidecar_manifest",
            ),
        ],
    );
    assert_json_field_keys(
        output,
        &[
            "object_store_recovery_manifest_bytes_read",
            "object_store_recovery_total_bytes_read",
        ],
    );
}

fn sidecar_path(target: &Path) -> PathBuf {
    PathBuf::from(format!(
        "{}.shardloom-commit.json",
        target.to_string_lossy()
    ))
}

fn temp_case_dir(name: &str) -> PathBuf {
    std::env::temp_dir().join(format!(
        "shardloom-object-store-write-smoke-{name}-{}",
        std::process::id()
    ))
}

#[test]
fn local_emulator_write_commits_payload_and_manifest_evidence() {
    let temp_dir = temp_case_dir("commit");
    let _ = fs::remove_dir_all(&temp_dir);
    fs::create_dir_all(&temp_dir).expect("temp dir");
    let source = temp_dir.join("payload.bin");
    let target = temp_dir.join("object.bin");
    fs::write(&source, b"object payload").expect("fixture write");
    let args = vec![
        "object-store-write-smoke".to_string(),
        source.to_string_lossy().into_owned(),
        target.to_string_lossy().into_owned(),
        "--profile".to_string(),
        "local-emulator".to_string(),
        "--idempotency-key".to_string(),
        "orders-batch-001".to_string(),
    ];

    let (success, output, stderr) = run_object_store_write_smoke_json(&args);

    assert!(success, "stdout={output} stderr={stderr}");
    assert!(stderr.is_empty(), "stderr={stderr}");
    assert_eq!(
        fs::read(&target).expect("target payload"),
        b"object payload"
    );
    assert!(sidecar_path(&target).exists(), "commit manifest exists");
    assert!(output.contains("\"command\":\"object-store-write-smoke\""));
    assert!(output.contains("\"status\":\"success\""));
    assert!(output.contains(&field(
        "schema_version",
        "shardloom.object_store_write_smoke.v1"
    )));
    assert!(output.contains(&field("provider_profile", "local-emulator")));
    assert!(output.contains(&field(
        "provider_admission_report_id",
        "shardloom.object_store_provider_admission.v1"
    )));
    assert!(output.contains(&field("provider_admission_operation", "write")));
    assert!(output.contains(&field(
        "provider_admission_status",
        "admitted_local_emulator"
    )));
    assert!(output.contains(&field(
        "provider_admission_classification",
        "use_shardloom_local_emulator_provider"
    )));
    assert!(output.contains(&field("request_signing_allowed", "false")));
    assert!(output.contains(&field("request_signing_performed", "false")));
    assert!(output.contains(&field(
        "request_signing_status",
        "not_required_local_emulator"
    )));
    assert!(output.contains(&field("object_store_write_status", "committed")));
    assert!(output.contains(&field("write_staging_status", "performed_local_emulator")));
    assert!(output.contains(&field("commit_protocol_status", "committed")));
    assert!(output.contains(&field("commit_status", "committed_local_emulator_object")));
    assert!(output.contains(&field("rollback_status", "not_requested")));
    assert!(output.contains(&field("idempotency_key", "orders-batch-001")));
    assert!(output.contains(&field("idempotency_status", "caller_supplied")));
    assert_local_write_commit_evidence_fields(&output);
    assert!(output.contains(&field("object_store_io", "true")));
    assert!(output.contains(&field("object_store_write_io", "true")));
    assert!(output.contains(&field("write_io", "true")));
    assert!(output.contains(&field("table_commit_allowed", "false")));
    assert!(output.contains(&field("native_io_certificate_status", "fixture_smoke_only")));
    assert!(output.contains(&field("claim_gate_status", "fixture_smoke_only")));
    assert!(output.contains(&field("fallback_attempted", "false")));
    assert!(output.contains(&field("external_engine_invoked", "false")));

    fs::remove_dir_all(&temp_dir).expect("fixture cleanup");
}

#[test]
fn local_emulator_write_recovery_replays_commit_manifest_evidence() {
    let temp_dir = temp_case_dir("recovery-success");
    let _ = fs::remove_dir_all(&temp_dir);
    fs::create_dir_all(&temp_dir).expect("temp dir");
    let source = temp_dir.join("payload.bin");
    let target = temp_dir.join("object.bin");
    fs::write(&source, b"recoverable payload").expect("fixture write");
    let write_args = vec![
        "object-store-write-smoke".to_string(),
        source.to_string_lossy().into_owned(),
        target.to_string_lossy().into_owned(),
        "--profile".to_string(),
        "local-emulator".to_string(),
        "--idempotency-key".to_string(),
        "recover-001".to_string(),
    ];
    let (write_success, write_output, write_stderr) =
        run_object_store_write_smoke_json(&write_args);
    assert!(write_success, "stdout={write_output} stderr={write_stderr}");

    let recovery_args = vec![
        "object-store-write-recovery-smoke".to_string(),
        target.to_string_lossy().into_owned(),
        "--profile".to_string(),
        "local-emulator".to_string(),
        "--idempotency-key".to_string(),
        "recover-001".to_string(),
    ];
    let (success, output, stderr) = run_object_store_write_recovery_smoke_json(&recovery_args);

    assert!(success, "stdout={output} stderr={stderr}");
    assert!(stderr.is_empty(), "stderr={stderr}");
    assert!(output.contains("\"command\":\"object-store-write-recovery-smoke\""));
    assert!(output.contains("\"status\":\"success\""));
    assert!(output.contains(&field(
        "schema_version",
        "shardloom.object_store_write_recovery_smoke.v1"
    )));
    assert!(output.contains(&field("mode", "object_store_write_recovery_smoke")));
    assert!(output.contains(&field("provider_admission_operation", "write_recovery")));
    assert!(output.contains(&field(
        "provider_admission_status",
        "admitted_local_emulator"
    )));
    assert!(output.contains(&field("request_signing_performed", "false")));
    assert!(output.contains(&field(
        "request_signing_status",
        "not_required_local_emulator"
    )));
    assert!(output.contains(&field("object_store_write_recovery_status", "recovered")));
    assert!(output.contains(&field(
        "recovery_replay_status",
        "recovered_local_emulator_sidecar"
    )));
    assert!(output.contains(&field(
        "commit_manifest_replay_status",
        "recovered_local_emulator_sidecar"
    )));
    assert!(output.contains(&field("target_digest_matched", "true")));
    assert!(output.contains(&field("payload_digest_matched", "true")));
    assert!(output.contains(&field("payload_bytes_matched", "true")));
    assert!(output.contains(&field("target_path_matched", "true")));
    assert!(output.contains(&field("commit_manifest_shape_matched", "true")));
    assert!(output.contains(&field("expected_idempotency_key", "recover-001")));
    assert!(output.contains(&field("recovered_idempotency_key", "recover-001")));
    assert!(output.contains(&field(
        "idempotency_status",
        "recovered_from_commit_manifest"
    )));
    assert_write_recovery_replay_evidence_fields(&output);
    assert!(output.contains(&field("native_io_certificate_status", "fixture_smoke_only")));
    assert!(output.contains(&field("claim_gate_status", "fixture_smoke_only")));
    assert!(output.contains(&field("object_store_io", "true")));
    assert!(output.contains(&field("object_store_read_io", "true")));
    assert!(output.contains(&field("object_store_write_io", "false")));
    assert!(output.contains(&field("write_io", "false")));
    assert!(output.contains(&field("table_commit_allowed", "false")));
    assert!(output.contains(&field("fallback_attempted", "false")));
    assert!(output.contains(&field("external_engine_invoked", "false")));

    fs::remove_dir_all(&temp_dir).expect("fixture cleanup");
}

#[test]
fn write_recovery_blocks_tampered_object_without_fallback() {
    let temp_dir = temp_case_dir("recovery-tamper");
    let _ = fs::remove_dir_all(&temp_dir);
    fs::create_dir_all(&temp_dir).expect("temp dir");
    let source = temp_dir.join("payload.bin");
    let target = temp_dir.join("object.bin");
    fs::write(&source, b"original payload").expect("fixture write");
    let write_args = vec![
        "object-store-write-smoke".to_string(),
        source.to_string_lossy().into_owned(),
        target.to_string_lossy().into_owned(),
        "--profile".to_string(),
        "local-emulator".to_string(),
        "--idempotency-key".to_string(),
        "tamper-001".to_string(),
    ];
    let (write_success, write_output, write_stderr) =
        run_object_store_write_smoke_json(&write_args);
    assert!(write_success, "stdout={write_output} stderr={write_stderr}");
    fs::write(&target, b"tampered payload").expect("tamper target object");

    let recovery_args = vec![
        "object-store-write-recovery-smoke".to_string(),
        target.to_string_lossy().into_owned(),
        "--profile".to_string(),
        "local-emulator".to_string(),
        "--idempotency-key".to_string(),
        "tamper-001".to_string(),
    ];
    let (success, output, stderr) = run_object_store_write_recovery_smoke_json(&recovery_args);

    assert!(!success, "stdout={output} stderr={stderr}");
    assert!(stderr.is_empty(), "stderr={stderr}");
    assert!(output.contains("\"status\":\"unsupported\""));
    assert!(output.contains("\"code\":\"SL_COMMIT_NOT_ATOMIC\""));
    assert!(output.contains("target_digest_mismatch"));
    assert!(output.contains(&field(
        "object_store_write_recovery_status",
        "blocked_recovery_mismatch"
    )));
    assert!(output.contains(&field("target_digest_matched", "false")));
    assert!(output.contains(&field("payload_digest_matched", "false")));
    assert_json_fields(
        &output,
        &[
            ("object_store_recovery_read_request_count", "2"),
            (
                "object_store_recovery_retry_policy_status",
                "not_retried_recovery_evidence_mismatch",
            ),
            (
                "object_store_recovery_rate_limit_policy_status",
                "not_required_local_emulator_no_network",
            ),
            (
                "object_store_recovery_ambiguous_commit_status",
                "blocked_recovery_mismatch",
            ),
        ],
    );
    assert!(output.contains(&field("object_store_io", "false")));
    assert!(output.contains(&field("object_store_read_io", "false")));
    assert!(output.contains(&field("object_store_write_io", "false")));
    assert!(output.contains(&field("fallback_attempted", "false")));
    assert!(output.contains(&field("external_engine_invoked", "false")));
    assert!(output.contains(&field("claim_gate_status", "not_claim_grade")));

    fs::remove_dir_all(&temp_dir).expect("fixture cleanup");
}

#[test]
fn remote_recovery_target_is_blocked_without_probe_or_read() {
    let args = vec![
        "object-store-write-recovery-smoke".to_string(),
        "s3://bucket/object.bin".to_string(),
    ];

    let (success, output, stderr) = run_object_store_write_recovery_smoke_json(&args);

    assert!(!success, "stdout={output} stderr={stderr}");
    assert!(stderr.is_empty(), "stderr={stderr}");
    assert!(output.contains("\"status\":\"unsupported\""));
    assert!(output.contains("\"code\":\"SL_OBJECT_STORE_UNSUPPORTED\""));
    assert!(output.contains(&field(
        "object_store_write_recovery_status",
        "blocked_remote_provider"
    )));
    assert!(output.contains(&field("provider_admission_operation", "write_recovery")));
    assert!(output.contains(&field(
        "provider_admission_status",
        "blocked_live_provider_no_probe"
    )));
    assert!(output.contains(&field(
        "credential_policy_status",
        "credential_policy_required_not_admitted"
    )));
    assert!(output.contains(&field("credential_resolution_performed", "false")));
    assert!(output.contains(&field("request_signing_allowed", "false")));
    assert!(output.contains(&field("request_signing_performed", "false")));
    assert!(output.contains(&field("request_signing_status", "blocked_not_invoked")));
    assert!(output.contains(&field("network_probe_performed", "false")));
    assert!(output.contains(&field("provider_probe_performed", "false")));
    assert_json_fields(
        &output,
        &[
            ("object_store_recovery_read_request_count", "0"),
            ("object_store_recovery_object_bytes_read", "0"),
            ("object_store_recovery_manifest_bytes_read", "0"),
            ("object_store_recovery_total_bytes_read", "0"),
            (
                "object_store_recovery_retry_policy_status",
                "blocked_before_retry",
            ),
            (
                "object_store_recovery_rate_limit_policy_status",
                "blocked_before_rate_limit_policy",
            ),
            (
                "object_store_recovery_ambiguous_commit_status",
                "blocked_before_recovery_replay",
            ),
        ],
    );
    assert!(output.contains(&field("object_store_io", "false")));
    assert!(output.contains(&field("object_store_read_io", "false")));
    assert!(output.contains(&field("object_store_write_io", "false")));
    assert!(output.contains(&field("write_io", "false")));
    assert!(output.contains(&field("fallback_attempted", "false")));
    assert!(output.contains(&field("external_engine_invoked", "false")));
    assert!(output.contains(&field("claim_gate_status", "not_claim_grade")));
}

#[test]
fn rollback_after_commit_cleans_target_and_manifest_with_evidence() {
    let temp_dir = temp_case_dir("rollback");
    let _ = fs::remove_dir_all(&temp_dir);
    fs::create_dir_all(&temp_dir).expect("temp dir");
    let source = temp_dir.join("payload.bin");
    let target = temp_dir.join("object.bin");
    fs::write(&source, b"rollback payload").expect("fixture write");
    let args = vec![
        "object-store-write-smoke".to_string(),
        source.to_string_lossy().into_owned(),
        target.to_string_lossy().into_owned(),
        "--profile".to_string(),
        "local-emulator".to_string(),
        "--idempotency-key".to_string(),
        "rollback-001".to_string(),
        "--rollback-after-commit".to_string(),
    ];

    let (success, output, stderr) = run_object_store_write_smoke_json(&args);

    assert!(success, "stdout={output} stderr={stderr}");
    assert!(stderr.is_empty(), "stderr={stderr}");
    assert!(!target.exists(), "target object was rolled back");
    assert!(!sidecar_path(&target).exists(), "manifest was rolled back");
    assert!(output.contains(&field("object_store_write_status", "rolled_back")));
    assert!(output.contains(&field("commit_protocol_status", "rolled_back")));
    assert!(output.contains(&field("commit_status", "committed_then_rolled_back")));
    assert!(output.contains(&field(
        "rollback_status",
        "performed_local_emulator_cleanup"
    )));
    assert!(output.contains(&field("cleanup_deleted_count", "2")));
    assert_json_fields(
        &output,
        &[
            ("object_store_write_request_count", "2"),
            ("object_store_commit_manifest_write_request_count", "1"),
            ("object_store_payload_bytes_written", "16"),
            (
                "object_store_write_bounded_status",
                "bounded_payload_and_manifest_under_fixture_budget",
            ),
            (
                "object_store_multipart_write_status",
                "not_required_single_object_local_emulator_commit",
            ),
            ("object_store_rollback_cleanup_request_count", "2"),
            (
                "object_store_ambiguous_commit_status",
                "rollback_cleanup_completed",
            ),
        ],
    );
    assert!(output.contains(&field("commit_manifest_present", "false")));
    assert!(output.contains(&field("target_exists_after_commit", "false")));
    assert!(output.contains(&field("object_store_write_io", "true")));
    assert!(output.contains(&field("fallback_attempted", "false")));
    assert!(output.contains(&field("external_engine_invoked", "false")));

    fs::remove_dir_all(&temp_dir).expect("fixture cleanup");
}

#[test]
fn no_overwrite_rejects_existing_target_without_clobbering_payload() {
    let temp_dir = temp_case_dir("no-overwrite-existing");
    let _ = fs::remove_dir_all(&temp_dir);
    fs::create_dir_all(&temp_dir).expect("temp dir");
    let source = temp_dir.join("payload.bin");
    let target = temp_dir.join("object.bin");
    fs::write(&source, b"new payload").expect("fixture write");
    fs::write(&target, b"original payload").expect("target write");
    let args = vec![
        "object-store-write-smoke".to_string(),
        source.to_string_lossy().into_owned(),
        target.to_string_lossy().into_owned(),
        "--profile".to_string(),
        "local-emulator".to_string(),
    ];

    let (success, output, stderr) = run_object_store_write_smoke_json(&args);

    assert!(!success, "stdout={output} stderr={stderr}");
    assert!(stderr.is_empty(), "stderr={stderr}");
    assert_eq!(
        fs::read(&target).expect("target payload"),
        b"original payload"
    );
    assert!(output.contains(&field("object_store_write_status", "blocked_target_exists")));
    assert!(output.contains(&field("object_store_write_io", "false")));
    assert!(output.contains(&field("fallback_attempted", "false")));
    assert!(output.contains(&field("external_engine_invoked", "false")));

    fs::remove_dir_all(&temp_dir).expect("fixture cleanup");
}

#[test]
fn allow_overwrite_replaces_existing_target_after_staging() {
    let temp_dir = temp_case_dir("overwrite-existing");
    let _ = fs::remove_dir_all(&temp_dir);
    fs::create_dir_all(&temp_dir).expect("temp dir");
    let source = temp_dir.join("payload.bin");
    let target = temp_dir.join("object.bin");
    fs::write(&source, b"replacement payload").expect("fixture write");
    fs::write(&target, b"original payload").expect("target write");
    let args = vec![
        "object-store-write-smoke".to_string(),
        source.to_string_lossy().into_owned(),
        target.to_string_lossy().into_owned(),
        "--profile".to_string(),
        "local-emulator".to_string(),
        "--allow-overwrite".to_string(),
    ];

    let (success, output, stderr) = run_object_store_write_smoke_json(&args);

    assert!(success, "stdout={output} stderr={stderr}");
    assert!(stderr.is_empty(), "stderr={stderr}");
    assert_eq!(
        fs::read(&target).expect("target payload"),
        b"replacement payload"
    );
    assert!(sidecar_path(&target).exists(), "commit manifest exists");
    assert!(output.contains(&field("object_store_write_status", "committed")));
    assert!(output.contains(&field("allow_overwrite", "true")));
    assert!(output.contains(&field("commit_status", "committed_local_emulator_object")));
    assert!(output.contains(&field("object_store_write_io", "true")));
    assert!(output.contains(&field("fallback_attempted", "false")));
    assert!(output.contains(&field("external_engine_invoked", "false")));

    fs::remove_dir_all(&temp_dir).expect("fixture cleanup");
}

#[cfg(unix)]
#[test]
fn allow_overwrite_rejects_symlink_target_without_clobbering_destination() {
    let temp_dir = temp_case_dir("symlink-target");
    let _ = fs::remove_dir_all(&temp_dir);
    fs::create_dir_all(&temp_dir).expect("temp dir");
    let source = temp_dir.join("payload.bin");
    let target = temp_dir.join("object.bin");
    let outside = temp_dir.join("outside-object.bin");
    fs::write(&source, b"replacement payload").expect("fixture write");
    fs::write(&outside, b"outside sentinel").expect("outside sentinel");
    unix_fs::symlink(&outside, &target).expect("target symlink");
    let args = vec![
        "object-store-write-smoke".to_string(),
        source.to_string_lossy().into_owned(),
        target.to_string_lossy().into_owned(),
        "--profile".to_string(),
        "local-emulator".to_string(),
        "--allow-overwrite".to_string(),
    ];

    let (success, output, stderr) = run_object_store_write_smoke_json(&args);

    assert!(!success, "stdout={output} stderr={stderr}");
    assert!(stderr.is_empty(), "stderr={stderr}");
    assert_eq!(
        fs::read(&outside).expect("outside sentinel"),
        b"outside sentinel"
    );
    assert!(
        fs::symlink_metadata(&target)
            .expect("target symlink metadata")
            .file_type()
            .is_symlink(),
        "target symlink was not replaced"
    );
    assert!(output.contains(&field("object_store_write_status", "blocked_write_error")));
    assert!(output.contains("output target is a symlink"));
    assert!(output.contains(&field("object_store_write_io", "false")));
    assert!(output.contains(&field("fallback_attempted", "false")));
    assert!(output.contains(&field("external_engine_invoked", "false")));

    fs::remove_dir_all(&temp_dir).expect("fixture cleanup");
}

#[cfg(unix)]
#[test]
fn sidecar_symlink_is_rejected_without_clobbering_destination() {
    let temp_dir = temp_case_dir("symlink-sidecar");
    let _ = fs::remove_dir_all(&temp_dir);
    fs::create_dir_all(&temp_dir).expect("temp dir");
    let source = temp_dir.join("payload.bin");
    let target = temp_dir.join("object.bin");
    let sidecar = sidecar_path(&target);
    let outside = temp_dir.join("outside-sidecar.json");
    fs::write(&source, b"sidecar payload").expect("fixture write");
    fs::write(&outside, b"outside sidecar sentinel").expect("outside sentinel");
    unix_fs::symlink(&outside, &sidecar).expect("sidecar symlink");
    let args = vec![
        "object-store-write-smoke".to_string(),
        source.to_string_lossy().into_owned(),
        target.to_string_lossy().into_owned(),
        "--profile".to_string(),
        "local-emulator".to_string(),
    ];

    let (success, output, stderr) = run_object_store_write_smoke_json(&args);

    assert!(!success, "stdout={output} stderr={stderr}");
    assert!(stderr.is_empty(), "stderr={stderr}");
    assert_eq!(
        fs::read(&outside).expect("outside sentinel"),
        b"outside sidecar sentinel"
    );
    assert!(
        !target.exists(),
        "target write was rolled back after sidecar rejection"
    );
    assert!(
        fs::symlink_metadata(&sidecar)
            .expect("sidecar symlink metadata")
            .file_type()
            .is_symlink(),
        "sidecar symlink was not replaced"
    );
    assert!(output.contains(&field("object_store_write_status", "blocked_write_error")));
    assert!(output.contains("output target is a symlink"));
    assert!(output.contains(&field("commit_manifest_present", "false")));
    assert!(output.contains(&field("fallback_attempted", "false")));
    assert!(output.contains(&field("external_engine_invoked", "false")));

    fs::remove_dir_all(&temp_dir).expect("fixture cleanup");
}

#[test]
fn remote_target_is_blocked_without_write_or_probe() {
    let temp_dir = temp_case_dir("remote");
    let _ = fs::remove_dir_all(&temp_dir);
    fs::create_dir_all(&temp_dir).expect("temp dir");
    let source = temp_dir.join("payload.bin");
    fs::write(&source, b"remote payload").expect("fixture write");
    let args = vec![
        "object-store-write-smoke".to_string(),
        source.to_string_lossy().into_owned(),
        "s3://bucket/object.bin".to_string(),
    ];

    let (success, output, stderr) = run_object_store_write_smoke_json(&args);

    assert!(!success, "stdout={output} stderr={stderr}");
    assert!(stderr.is_empty(), "stderr={stderr}");
    assert!(output.contains("\"status\":\"unsupported\""));
    assert!(output.contains("\"code\":\"SL_OBJECT_STORE_UNSUPPORTED\""));
    assert!(output.contains(&field(
        "object_store_write_status",
        "blocked_remote_provider"
    )));
    assert!(output.contains(&field("provider_admission_operation", "write")));
    assert!(output.contains(&field(
        "provider_admission_status",
        "blocked_live_provider_no_probe"
    )));
    assert!(output.contains(&field(
        "provider_admission_boundary",
        "blocked_before_credentials_signing_provider_or_network_probe"
    )));
    assert!(output.contains(&field(
        "credential_policy_status",
        "credential_policy_required_not_admitted"
    )));
    assert!(output.contains(&field("credential_resolution_performed", "false")));
    assert!(output.contains(&field("request_signing_allowed", "false")));
    assert!(output.contains(&field("request_signing_performed", "false")));
    assert!(output.contains(&field("request_signing_status", "blocked_not_invoked")));
    assert!(output.contains(&field("network_probe_performed", "false")));
    assert!(output.contains(&field("provider_probe_performed", "false")));
    assert_json_fields(
        &output,
        &[
            ("object_store_write_request_count", "0"),
            ("object_store_commit_manifest_write_request_count", "0"),
            ("object_store_payload_bytes_written", "0"),
            ("object_store_commit_manifest_bytes_written", "0"),
            ("object_store_total_bytes_written", "0"),
            ("object_store_write_bounded_status", "not_performed_blocked"),
            (
                "object_store_multipart_write_status",
                "not_performed_blocked",
            ),
            (
                "object_store_write_retry_policy_status",
                "blocked_before_retry",
            ),
            (
                "object_store_write_rate_limit_policy_status",
                "blocked_before_rate_limit_policy",
            ),
            (
                "object_store_ambiguous_commit_status",
                "blocked_before_commit_claim",
            ),
        ],
    );
    assert!(output.contains(&field("object_store_io", "false")));
    assert!(output.contains(&field("object_store_write_io", "false")));
    assert!(output.contains(&field("write_io", "false")));
    assert!(output.contains(&field("fallback_attempted", "false")));
    assert!(output.contains(&field("external_engine_invoked", "false")));
    assert!(output.contains(&field("claim_gate_status", "not_claim_grade")));

    fs::remove_dir_all(&temp_dir).expect("fixture cleanup");
}
