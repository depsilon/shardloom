//! Whole-document JSON construction without retained named scalar rows.
//!
//! Input text and typed columns remain whole-document allocations. Only writer
//! batches are bounded; this is not a streaming JSON parser or an RSS bound.

use super::{
    Arc, BTreeMap, CancellationToken, ColumnarSourceScoutEvidence, Instant,
    LocalInputAdapterSelection, LocalSourceFormat, LocalSourceReadPlan, RecordBatch, ScalarValue,
    Schema, ShardLoomError, VortexIngestReport, VortexIngestRequest, VortexIngestSourceData,
    decode_local_text_source, enforce_local_source_row_budget,
    finish_text_streaming_vortex_prepare, fnv64_digest, fnv64_digest_bytes_controlled,
    read_local_source_bytes_with_budget_report_controlled, text_stream_record_batch_size,
    unsupported_sql_error, visit_json_source_rows_with_plan_controlled,
};
use arrow_array::RecordBatchIterator;
use shardloom_vortex::universal_format_io::InferredTextColumnBuilder;

const CONTEXT: &str = "JSON Universal Ingest typed text RecordBatch";

#[allow(clippy::too_many_lines)]
pub(super) fn prepare(
    request: VortexIngestRequest,
    source_adapter: LocalInputAdapterSelection,
) -> Result<VortexIngestReport, ShardLoomError> {
    request.cancellation.check()?;
    let prepare_start = Instant::now();
    let limits = request.runtime_profile.read_limits();
    let byte_read = read_local_source_bytes_with_budget_report_controlled(
        &request.source_path,
        "JSON",
        limits.source_bytes,
        &request.cancellation,
    )?;
    let read_millis = byte_read.total_read_millis();
    let scout = ColumnarSourceScoutEvidence {
        bytes: u64::try_from(byte_read.bytes.len())
            .map_err(|_| unsupported_sql_error("JSON source length does not fit in u64"))?,
        digest: fnv64_digest_bytes_controlled(&byte_read.bytes, &request.cancellation)?,
        fingerprint_kind: "local_file_content_digest".to_string(),
        fingerprint_policy: "content_digest".to_string(),
        identity_source: "local_file_explicit_proof_digest".to_string(),
        content_fingerprint_requested: true,
        content_fingerprint_performed: true,
        metadata_scout_millis: byte_read.source_metadata_scout_millis,
        byte_acquisition_millis: byte_read.source_byte_acquisition_millis,
        full_body_millis: byte_read.source_full_body_millis,
    };
    let build_start = Instant::now();
    let content = decode_local_text_source(
        &request.source_path,
        LocalSourceFormat::Json,
        byte_read.bytes,
    )?;
    let batch_size = text_stream_record_batch_size(limits.input_rows);
    let batches = parse_controlled(
        &content,
        limits.input_rows,
        batch_size,
        &request.cancellation,
    )?;
    drop(content);
    let batch = &batches[0];
    let header = batch
        .schema()
        .fields()
        .iter()
        .map(|field| field.name().clone())
        .collect::<Vec<_>>();
    // Source schema identity excludes the writer's derived metadata columns.
    let source_schema_digest = fnv64_digest(&header.join(","));
    let column_arrow_dtypes = batch
        .schema()
        .fields()
        .iter()
        .map(|field| Some(field.data_type().clone()))
        .collect::<Vec<_>>();
    let schema = batch.schema();
    let rows = batches.iter().map(RecordBatch::num_rows).sum::<usize>();
    let batch_count = batches.len();
    let reader = RecordBatchIterator::new(batches.into_iter().map(Ok), schema);
    let columnar_source = shardloom_vortex::FlatLocalColumnarStreamSource {
        column_dtypes: vec![None; header.len()],
        column_arrow_dtypes,
        materialized_columns: header.clone(),
        reader_projection_columns: header.clone(),
        header,
        row_count_hint: Some(rows),
        record_batch_count_hint: Some(batch_count),
        source_stream_batch_size: batch_size,
        source_stream_unit_count_hint: Some(batch_count),
        source_stream_unit_row_ranges: Some(
            (0..rows)
                .step_by(batch_size)
                .map(|start| (start, start + batch_size.min(rows - start)))
                .collect(),
        ),
        source_stream_unit_hint_kind: "text_record_batch_count".to_string(),
        source_stream_policy: format!(
            "whole_json_typed_columns_writer_batch_size_{batch_size}_rows"
        ),
        source_dictionary_preservation_status: "json_typed_builders_no_source_dictionary"
            .to_string(),
        ingest_executor_status: "whole_json_typed_columns_ready".to_string(),
        ingest_executor_kind: "whole_json_typed_columns_to_record_batch_reader".to_string(),
        ingest_executor_requested_parallelism: 1,
        ingest_executor_applied_parallelism: 1,
        ingest_executor_unit_count_hint: Some(batch_count),
        source_identities: Vec::new(),
        #[cfg(feature = "vortex-write")]
        ingest_runtime: None,
        embedded_derived_build_micros: shardloom_vortex::new_embedded_derived_build_micros_counter(
        ),
        reader: Box::new(reader),
    };
    let columnar_source =
        shardloom_vortex::universal_format_io::with_embedded_derived_columns_columnar_stream_source(
            columnar_source,
        );
    let columnar_source = shardloom_vortex::universal_format_io::with_capillary_prefetch_columnar_stream_source_controlled(
        columnar_source,
        request.resources.max_parallelism(),
        &request.cancellation,
    )?;
    let mut source = VortexIngestSourceData::from_columnar_stream_source(
        source_adapter,
        &columnar_source,
        scout,
        read_millis,
        build_start.elapsed().as_millis(),
    );
    source.read_plan = LocalSourceReadPlan::full("whole_json_typed_vortex_ingest_source_state");
    source.projection_pushdown_status =
        LocalSourceFormat::Json.projection_pushdown_status(&source.read_plan);
    source.materialization_layout = "whole_json_typed_columns_with_batched_writer";
    source.parse_normalization = "json_adapter_to_whole_typed_columns";
    finish_text_streaming_vortex_prepare(
        request,
        source,
        columnar_source,
        source_schema_digest,
        prepare_start,
    )
}

#[cfg(test)]
fn parse(
    content: &str,
    max_rows: Option<usize>,
    batch_size: usize,
) -> Result<Vec<RecordBatch>, ShardLoomError> {
    parse_controlled(content, max_rows, batch_size, &CancellationToken::default())
}

fn parse_controlled(
    content: &str,
    max_rows: Option<usize>,
    batch_size: usize,
    cancellation: &CancellationToken,
) -> Result<Vec<RecordBatch>, ShardLoomError> {
    cancellation.check()?;
    let batch_size = batch_size.clamp(
        1,
        shardloom_vortex::universal_format_io::PRODUCT_COLUMNAR_LARGE_STREAM_RECORD_BATCH_ROWS,
    );
    let read_plan = LocalSourceReadPlan::full("whole_json_typed_columns");
    let mut indices = BTreeMap::<String, usize>::new();
    let mut values = Vec::<ScalarValue>::new();
    let mut builders = Vec::<InferredTextColumnBuilder>::new();
    let mut row_count = 0;
    visit_json_source_rows_with_plan_controlled(content, &read_plan, cancellation, |fields| {
        cancellation.check()?;
        row_count += 1;
        enforce_local_source_row_budget(row_count, max_rows, "JSON")?;
        values.fill(ScalarValue::Null);
        for (name, value) in fields {
            cancellation.check()?;
            let index = if let Some(&index) = indices.get(&name) {
                index
            } else {
                let index = builders.len();
                builders.push(InferredTextColumnBuilder::new(
                    &name,
                    row_count - 1,
                    batch_size,
                    CONTEXT,
                )?);
                values.push(ScalarValue::Null);
                indices.insert(name, index);
                index
            };
            values[index] = value;
        }
        for (builder, value) in builders.iter_mut().zip(&values) {
            cancellation.check()?;
            builder.append(value)?;
        }
        Ok(())
    })?;
    if row_count == 0 {
        return Err(unsupported_sql_error(
            "JSON source must include at least one object row",
        ));
    }
    let (fields, columns): (Vec<_>, Vec<_>) = builders
        .into_iter()
        .map(|builder| {
            cancellation.check()?;
            builder.finish()
        })
        .collect::<Result<Vec<_>, _>>()?
        .into_iter()
        .unzip();
    let schema = Arc::new(Schema::new(fields));
    let mut batches = (0..row_count.div_ceil(batch_size))
        .map(|_| Vec::with_capacity(columns.len()))
        .collect::<Vec<_>>();
    for column in columns {
        cancellation.check()?;
        if column.len() != batches.len() {
            return Err(unsupported_sql_error(
                "JSON typed column batch counts differ",
            ));
        }
        for (batch, array) in batches.iter_mut().zip(column) {
            cancellation.check()?;
            batch.push(array);
        }
    }
    batches
        .into_iter()
        .map(|arrays| {
            cancellation.check()?;
            RecordBatch::try_new(Arc::clone(&schema), arrays).map_err(|error| {
                unsupported_sql_error(&format!("{CONTEXT} failed to construct columns: {error}"))
            })
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::super::{ordered_source_rows, parse_json_source_content};
    use super::*;

    #[test]
    fn whole_json_controlled_preparation_stops_before_io_and_between_rows() {
        let token = CancellationToken::default();
        token.cancel();
        let error = read_local_source_bytes_with_budget_report_controlled(
            std::path::Path::new("must-not-be-opened.json"),
            "JSON",
            None,
            &token,
        )
        .unwrap_err();
        assert!(error.to_string().contains("cancel"), "{error}");
        assert!(
            parse_controlled("invalid JSON", None, 1, &token)
                .unwrap_err()
                .to_string()
                .contains("cancel")
        );
        let token = CancellationToken::default();
        let mut rows = 0;
        let error = visit_json_source_rows_with_plan_controlled(
            r#"[{"id":1},{"id":2},{"id":3}]"#,
            &LocalSourceReadPlan::full("controlled_json_test"),
            &token,
            |_| {
                rows += 1;
                token.cancel();
                Ok(())
            },
        )
        .unwrap_err();
        assert!(error.to_string().contains("cancel"), "{error}");
        assert_eq!(rows, 1);
    }

    #[test]
    fn whole_json_controlled_digest_preserves_bytes_and_parent_deadline_scope() {
        let parent = CancellationToken::default();
        let bytes = "東京🙂\\n".repeat(8193).into_bytes();
        assert_eq!(
            fnv64_digest_bytes_controlled(&bytes, &parent).unwrap(),
            super::super::fnv64_digest_bytes(&bytes),
        );
        let child = parent.with_deadline(std::time::Instant::now());
        assert!(
            fnv64_digest_bytes_controlled(&bytes, &child)
                .unwrap_err()
                .to_string()
                .contains("deadline")
        );
        assert!(
            parse_controlled(r#"{"id":1}"#, None, 1, &child)
                .unwrap_err()
                .to_string()
                .contains("deadline")
        );
        parent.check().unwrap();
    }

    fn reference(content: &str) -> Result<RecordBatch, ShardLoomError> {
        let (header, rows) = parse_json_source_content(content)?;
        let rows = ordered_source_rows(&header, &rows)?;
        let mut source =
            shardloom_vortex::universal_format_io::stream_flat_text_rows_columnar_source(
                header.clone(),
                vec![None; header.len()],
                vec![None; header.len()],
                header.clone(),
                header,
                rows,
                262_144,
                "JSON",
            )?;
        source
            .reader
            .next()
            .expect("nonempty source")
            .map_err(|error| unsupported_sql_error(&error.to_string()))
    }

    #[test]
    fn whole_json_typed_preserves_complete_values_schema_and_duplicates() {
        for content in [
            "\u{feff}{\"id\":9,\"label\":\"東京🙂\\n\",\"n\":null}",
            r#"[{"id":"overwritten","id":1,"n":null},{"n":null,"late":true,"id":2},{"id":3,"late":null,}]"#,
            r#"[{"first":null},{"second":null,"first":"value"},{"first":null,"second":7},]"#,
            r#"[{"x":9223372036854775807,"f":1.25,"obj":{"b":[1,null],"a":"λ"}},{"x":-9223372036854775808,"f":-0.0,"obj":[{},true]}]"#,
            r#"[{"n":null},{"n":null}]"#,
            r#"{"id":18446744073709551615}"#,
        ] {
            let reference = reference(content).unwrap();
            for size in [1, 2, 3, 65_536] {
                let actual = parse(content, None, size).unwrap();
                assert_eq!(actual.len(), reference.num_rows().div_ceil(size));
                for (i, batch) in actual.iter().enumerate() {
                    assert_eq!(
                        batch,
                        &reference.slice(i * size, size.min(reference.num_rows() - i * size)),
                        "{content}"
                    );
                }
            }
        }
    }

    #[test]
    fn whole_json_typed_rejects_legacy_invalid_and_unstable_types() {
        for content in [
            "",
            "[]",
            "{}",
            "[{}]",
            "[1]",
            "null",
            "{\"x\":1} {}",
            "[{\"x\":1}] []",
            "[{\"x\":1}",
            "[{\"x\":1} {\"x\":2}]",
            r#"{"x":falsee,"x":1}"#,
            r#"{"bad name":1}"#,
            r#"{"x":{"a":1,}}"#,
            r#"{"x":"\uZZZZ"}"#,
            r#"[{"x":1},{"x":1.25}]"#,
            r#"[{"x":true},{"x":"true"}]"#,
        ] {
            assert!(reference(content).is_err(), "reference admits {content}");
            assert!(
                parse(content, None, 2).is_err(),
                "candidate admits {content}"
            );
        }
        assert!(
            parse(r#"[{"x":1},{"x":2}]"#, Some(1), 1)
                .unwrap_err()
                .to_string()
                .contains("at most 1")
        );
        assert!(parse(r#"{"x":1}"#, Some(0), 1).is_err());
    }
}
