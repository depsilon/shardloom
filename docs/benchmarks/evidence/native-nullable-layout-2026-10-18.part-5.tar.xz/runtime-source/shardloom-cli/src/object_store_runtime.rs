//! Provider/profile-scoped object-store runtime smoke handlers.
//!
//! The runtime path in this module is deliberately narrow: it admits explicit
//! local-emulator reads/writes and a public no-credential fixture read profile.
//! The public fixture profile parses S3/GCS/ADLS URIs and reads caller-supplied
//! local fixture bytes only; it never resolves credentials, probes providers,
//! opens a network connection, writes cache entries, commits tables, or invokes
//! external query engines.

use std::{
    collections::BTreeSet,
    fmt::Write as _,
    fs,
    path::{Path, PathBuf},
    process::ExitCode,
    time::UNIX_EPOCH,
};

use shardloom_core::{
    CommandStatus, Diagnostic, DiagnosticCategory, DiagnosticCode, DiagnosticSeverity,
    FallbackStatus, OutputFormat, ShardLoomError,
};
use shardloom_exec::live_memory::{Budgeted, LiveMemoryPool, MemoryLease};

use crate::{
    cli_output::{emit, emit_error},
    cli_unknown_arg_error,
    fixture_io::JsonEscaped,
};

const OBJECT_STORE_READ_SMOKE_COMMAND: &str = "object-store-read-smoke";
const OBJECT_STORE_READ_SMOKE_SCHEMA_VERSION: &str = "shardloom.object_store_read_smoke.v1";
const OBJECT_STORE_WRITE_SMOKE_COMMAND: &str = "object-store-write-smoke";
const OBJECT_STORE_WRITE_SMOKE_SCHEMA_VERSION: &str = "shardloom.object_store_write_smoke.v1";
const OBJECT_STORE_WRITE_RECOVERY_SMOKE_COMMAND: &str = "object-store-write-recovery-smoke";
const OBJECT_STORE_WRITE_RECOVERY_SMOKE_SCHEMA_VERSION: &str =
    "shardloom.object_store_write_recovery_smoke.v1";
const OBJECT_STORE_PARTITION_DISCOVERY_SMOKE_COMMAND: &str =
    "object-store-partition-discovery-smoke";
const OBJECT_STORE_PARTITION_DISCOVERY_SMOKE_SCHEMA_VERSION: &str =
    "shardloom.object_store_partition_discovery_smoke.v1";
const LOCAL_EMULATOR_PROFILE: &str = "local-emulator";
const PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE: &str = "public-no-credential-fixture";
const DEFAULT_PROFILE: &str = LOCAL_EMULATOR_PROFILE;
const MAX_OBJECT_STORE_FIXTURE_BYTES: u64 = 128 * 1024 * 1024;
const MAX_OBJECT_STORE_COMMIT_MANIFEST_BYTES: u64 = 1024 * 1024;
const MAX_OBJECT_STORE_PARTITION_DISCOVERY_DEPTH: usize = 16;
const MAX_OBJECT_STORE_PARTITION_DISCOVERY_DIRECTORIES: usize = 4096;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ObjectStoreReadSmokeStatus {
    Succeeded,
    BlockedRemoteProvider,
    BlockedUnsupportedProfile,
    BlockedInvalidUri,
    BlockedMissingFixturePath,
    BlockedMissingObject,
    BlockedInvalidRange,
    BlockedReadError,
}

impl ObjectStoreReadSmokeStatus {
    const fn as_str(self) -> &'static str {
        match self {
            Self::Succeeded => "succeeded",
            Self::BlockedRemoteProvider => "blocked_remote_provider",
            Self::BlockedUnsupportedProfile => "blocked_unsupported_profile",
            Self::BlockedInvalidUri => "blocked_invalid_uri",
            Self::BlockedMissingFixturePath => "blocked_missing_fixture_path",
            Self::BlockedMissingObject => "blocked_missing_object",
            Self::BlockedInvalidRange => "blocked_invalid_range",
            Self::BlockedReadError => "blocked_read_error",
        }
    }

    const fn is_error(self) -> bool {
        !matches!(self, Self::Succeeded)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ReadMode {
    FullFile,
    ByteRange,
}

impl ReadMode {
    const fn as_str(self) -> &'static str {
        match self {
            Self::FullFile => "full_file",
            Self::ByteRange => "byte_range",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct RequestedRange {
    offset: u64,
    length: u64,
}

#[derive(Debug)]
enum LocalEmulatorMetadataError {
    NotRegularFile,
    StatFailed(std::io::Error),
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct ObjectStoreReadSmokeReport {
    status: ObjectStoreReadSmokeStatus,
    diagnostics: Vec<Diagnostic>,
    provider_profile: String,
    object_store_provider: String,
    object_store_bucket: String,
    object_store_key: String,
    requested_uri: String,
    local_path: Option<PathBuf>,
    fixture_listing_requested: bool,
    read_mode: ReadMode,
    requested_range: Option<RequestedRange>,
    object_size_bytes: u64,
    object_mtime_millis: Option<u128>,
    bytes_read: usize,
    read_digest: String,
    source_state_id: String,
    source_state_digest: String,
    source_content_digest: String,
    source_fingerprint_kind: &'static str,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct ObjectStoreReadBlockerContext {
    provider_profile: String,
    requested_uri: String,
    object_store_provider: String,
    object_store_bucket: String,
    object_store_key: String,
    fixture_listing_requested: bool,
    read_mode: ReadMode,
    requested_range: Option<RequestedRange>,
}

impl ObjectStoreReadBlockerContext {
    fn new(
        source: &str,
        profile: &str,
        read_mode: ReadMode,
        requested_range: Option<RequestedRange>,
        fixture_listing_requested: bool,
    ) -> Self {
        Self {
            provider_profile: profile.to_string(),
            requested_uri: source.to_string(),
            object_store_provider: provider_for_source_or_profile(source, profile).to_string(),
            object_store_bucket: "not_available".to_string(),
            object_store_key: "not_available".to_string(),
            fixture_listing_requested,
            read_mode,
            requested_range,
        }
    }

    fn with_redacted_uri(mut self, source: &str) -> Self {
        self.requested_uri = redact_object_store_uri(source);
        self
    }
}

#[derive(Debug)]
struct ObjectStoreReadSuccessInput<'a> {
    source: &'a str,
    profile: &'a str,
    object_store_provider: String,
    object_store_bucket: String,
    object_store_key: String,
    local_path: PathBuf,
    fixture_listing_requested: bool,
    read_mode: ReadMode,
    metadata: &'a fs::Metadata,
    requested_range: Option<RequestedRange>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ObjectStoreAdmissionOperation {
    Read,
    Write,
    WriteRecovery,
    PartitionDiscovery,
}

impl ObjectStoreAdmissionOperation {
    const fn as_str(self) -> &'static str {
        match self {
            Self::Read => "read",
            Self::Write => "write",
            Self::WriteRecovery => "write_recovery",
            Self::PartitionDiscovery => "partition_discovery",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct ObjectStoreListingPolicy<'a> {
    allowed: bool,
    status: &'a str,
    object_count: usize,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ObjectStoreOperationOutcome {
    Performed,
    Blocked,
}

impl ObjectStoreOperationOutcome {
    const fn from_errors(has_errors: bool) -> Self {
        if has_errors {
            Self::Blocked
        } else {
            Self::Performed
        }
    }

    const fn has_errors(self) -> bool {
        matches!(self, Self::Blocked)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ObjectStoreRemoteProviderRequest {
    Requested,
    NotRequested,
}

impl ObjectStoreRemoteProviderRequest {
    const fn from_bool(requested: bool) -> Self {
        if requested {
            Self::Requested
        } else {
            Self::NotRequested
        }
    }

    const fn requested(self) -> bool {
        matches!(self, Self::Requested)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ObjectStoreUriRedactionRequirement {
    Required,
    NotRequired,
}

impl ObjectStoreUriRedactionRequirement {
    const fn from_bool(required: bool) -> Self {
        if required {
            Self::Required
        } else {
            Self::NotRequired
        }
    }

    const fn required(self) -> bool {
        matches!(self, Self::Required)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ObjectStorePublicFixtureProfile {
    Yes,
    No,
}

impl ObjectStorePublicFixtureProfile {
    const fn from_bool(enabled: bool) -> Self {
        if enabled { Self::Yes } else { Self::No }
    }

    const fn enabled(self) -> bool {
        matches!(self, Self::Yes)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct ObjectStoreProviderAdmission<'a> {
    operation: ObjectStoreAdmissionOperation,
    provider_profile: &'a str,
    operation_status: &'a str,
    outcome: ObjectStoreOperationOutcome,
    remote_provider_request: ObjectStoreRemoteProviderRequest,
    uri_redaction_requirement: ObjectStoreUriRedactionRequirement,
    listing_policy: ObjectStoreListingPolicy<'a>,
    local_cache_status: &'a str,
    public_fixture_profile: ObjectStorePublicFixtureProfile,
}

impl ObjectStoreProviderAdmission<'_> {
    fn provider_profile_status(&self) -> &'static str {
        if self.provider_profile == LOCAL_EMULATOR_PROFILE {
            "admitted_local_emulator_profile"
        } else if self.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
            "admitted_public_no_credential_fixture_profile"
        } else {
            "blocked_unknown_provider_profile"
        }
    }

    fn provider_admission_status(&self) -> &'static str {
        if self.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
            if self.outcome.has_errors() {
                "blocked_public_fixture_requirements"
            } else {
                "admitted_public_no_credential_fixture"
            }
        } else if self.provider_profile != LOCAL_EMULATOR_PROFILE {
            "blocked_unsupported_profile"
        } else if self.remote_provider_request.requested() {
            "blocked_live_provider_no_probe"
        } else if self.outcome.has_errors() {
            "blocked_local_emulator_validation"
        } else {
            "admitted_local_emulator"
        }
    }

    fn provider_admission_classification(&self) -> &'static str {
        if self.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE
            && !self.outcome.has_errors()
        {
            "wrap_public_no_credential_fixture"
        } else if self.provider_profile == LOCAL_EMULATOR_PROFILE
            && !self.remote_provider_request.requested()
            && !self.outcome.has_errors()
        {
            "use_shardloom_local_emulator_provider"
        } else {
            "blocked_until_vortex_or_shardloom_evidence"
        }
    }

    fn provider_admission_boundary(&self) -> &'static str {
        if self.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE
            && !self.outcome.has_errors()
        {
            "uri_shape_plus_explicit_local_fixture_only_no_live_provider"
        } else if self.provider_profile == LOCAL_EMULATOR_PROFILE
            && !self.remote_provider_request.requested()
            && !self.outcome.has_errors()
        {
            "caller_owned_local_emulator_paths_only"
        } else if self.remote_provider_request.requested() {
            "blocked_before_credentials_signing_provider_or_network_probe"
        } else {
            "blocked_before_effects_or_provider_probe"
        }
    }

    fn credential_policy_status(&self) -> &'static str {
        if self.remote_provider_request.requested() {
            "credential_policy_required_not_admitted"
        } else if self.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE
            && !self.outcome.has_errors()
        {
            "public_no_credential_fixture_admitted"
        } else if self.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
            "public_no_credential_fixture_blocked"
        } else if self.provider_profile == LOCAL_EMULATOR_PROFILE {
            "not_required_local_emulator"
        } else {
            "credential_policy_blocked_unsupported_profile"
        }
    }

    fn network_effect_status(&self) -> &'static str {
        if self.remote_provider_request.requested() {
            "network_effect_blocked_no_live_provider_policy"
        } else if self.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
            "disabled_public_fixture"
        } else if self.provider_profile == LOCAL_EMULATOR_PROFILE {
            "not_required_local_emulator"
        } else {
            "network_effect_blocked_unsupported_profile"
        }
    }

    fn request_signing_status(&self) -> &'static str {
        if self.remote_provider_request.requested() {
            "blocked_not_invoked"
        } else if self.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
            "not_required_public_no_credential_fixture"
        } else if self.provider_profile == LOCAL_EMULATOR_PROFILE {
            "not_required_local_emulator"
        } else {
            "blocked_unsupported_profile"
        }
    }

    fn request_signing_boundary(&self) -> &'static str {
        if self.remote_provider_request.requested() {
            "blocked_before_request_signing"
        } else if self.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
            "no_remote_request_to_sign_public_fixture_reads_local_bytes"
        } else if self.provider_profile == LOCAL_EMULATOR_PROFILE {
            "no_remote_request_to_sign_local_emulator"
        } else {
            "profile_not_admitted_for_signing"
        }
    }

    fn uri_redaction_policy_status(&self) -> &'static str {
        if self.uri_redaction_requirement.required() {
            "applied"
        } else {
            "not_required"
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct ParsedObjectStoreUri {
    provider: &'static str,
    bucket: String,
    key: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ObjectStoreWriteSmokeStatus {
    Committed,
    RolledBack,
    BlockedRemoteProvider,
    BlockedUnsupportedProfile,
    BlockedMissingSource,
    BlockedInvalidTarget,
    BlockedTargetExists,
    BlockedWriteError,
}

impl ObjectStoreWriteSmokeStatus {
    const fn as_str(self) -> &'static str {
        match self {
            Self::Committed => "committed",
            Self::RolledBack => "rolled_back",
            Self::BlockedRemoteProvider => "blocked_remote_provider",
            Self::BlockedUnsupportedProfile => "blocked_unsupported_profile",
            Self::BlockedMissingSource => "blocked_missing_source",
            Self::BlockedInvalidTarget => "blocked_invalid_target",
            Self::BlockedTargetExists => "blocked_target_exists",
            Self::BlockedWriteError => "blocked_write_error",
        }
    }

    const fn is_error(self) -> bool {
        !matches!(self, Self::Committed | Self::RolledBack)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ObjectStoreWriteRecoveryStatus {
    Recovered,
    BlockedRemoteProvider,
    BlockedUnsupportedProfile,
    BlockedInvalidTarget,
    BlockedMissingObject,
    BlockedMissingCommitManifest,
    BlockedReadError,
    BlockedRecoveryMismatch,
}

impl ObjectStoreWriteRecoveryStatus {
    const fn as_str(self) -> &'static str {
        match self {
            Self::Recovered => "recovered",
            Self::BlockedRemoteProvider => "blocked_remote_provider",
            Self::BlockedUnsupportedProfile => "blocked_unsupported_profile",
            Self::BlockedInvalidTarget => "blocked_invalid_target",
            Self::BlockedMissingObject => "blocked_missing_object",
            Self::BlockedMissingCommitManifest => "blocked_missing_commit_manifest",
            Self::BlockedReadError => "blocked_read_error",
            Self::BlockedRecoveryMismatch => "blocked_recovery_mismatch",
        }
    }

    const fn is_error(self) -> bool {
        !matches!(self, Self::Recovered)
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct ObjectStoreWriteSmokeReport {
    status: ObjectStoreWriteSmokeStatus,
    diagnostics: Vec<Diagnostic>,
    provider_profile: String,
    source_uri: String,
    target_uri: String,
    source_path: Option<PathBuf>,
    target_path: Option<PathBuf>,
    staging_path: Option<PathBuf>,
    commit_manifest_path: Option<PathBuf>,
    idempotency_key: String,
    idempotency_status: &'static str,
    allow_overwrite: bool,
    rollback_after_commit: bool,
    payload_bytes: usize,
    written_bytes: usize,
    commit_manifest_bytes: usize,
    cleanup_deleted_count: usize,
    payload_digest: String,
    target_content_digest: String,
    commit_manifest_digest: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
struct ObjectStoreWriteRecoveryReport {
    status: ObjectStoreWriteRecoveryStatus,
    diagnostics: Vec<Diagnostic>,
    provider_profile: String,
    target_uri: String,
    target_path: Option<PathBuf>,
    commit_manifest_path: Option<PathBuf>,
    expected_idempotency_key: Option<String>,
    recovered_idempotency_key: String,
    idempotency_status: &'static str,
    object_bytes: usize,
    recorded_payload_bytes: usize,
    object_digest: String,
    recorded_payload_digest: String,
    recorded_target_content_digest: String,
    commit_manifest_bytes: usize,
    commit_manifest_digest: String,
    target_digest_matched: bool,
    payload_digest_matched: bool,
    payload_bytes_matched: bool,
    target_path_matched: bool,
    manifest_shape_matched: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ObjectStorePartitionDiscoveryStatus {
    Succeeded,
    BlockedRemoteProvider,
    BlockedUnsupportedProfile,
    BlockedMissingRoot,
    BlockedInvalidRoot,
    BlockedListingError,
    BlockedNoPartitions,
    BlockedPartitionColumnMismatch,
}

impl ObjectStorePartitionDiscoveryStatus {
    const fn as_str(self) -> &'static str {
        match self {
            Self::Succeeded => "succeeded",
            Self::BlockedRemoteProvider => "blocked_remote_provider",
            Self::BlockedUnsupportedProfile => "blocked_unsupported_profile",
            Self::BlockedMissingRoot => "blocked_missing_root",
            Self::BlockedInvalidRoot => "blocked_invalid_root",
            Self::BlockedListingError => "blocked_listing_error",
            Self::BlockedNoPartitions => "blocked_no_partitions",
            Self::BlockedPartitionColumnMismatch => "blocked_partition_column_mismatch",
        }
    }

    const fn is_error(self) -> bool {
        !matches!(self, Self::Succeeded)
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct ObjectStorePartitionDiscoveryReport {
    status: ObjectStorePartitionDiscoveryStatus,
    diagnostics: Vec<Diagnostic>,
    provider_profile: String,
    requested_uri: String,
    root_path: Option<PathBuf>,
    requested_partition_columns: Vec<String>,
    discovered_partition_columns: Vec<String>,
    discovered_partition_values: Vec<String>,
    partition_directory_count: usize,
    listing_directory_count: usize,
    max_partition_depth: usize,
}

impl ObjectStorePartitionDiscoveryReport {
    fn blocked(
        status: ObjectStorePartitionDiscoveryStatus,
        profile: impl Into<String>,
        requested_uri: impl Into<String>,
        requested_partition_columns: Vec<String>,
        diagnostic: Diagnostic,
    ) -> Self {
        Self {
            status,
            diagnostics: vec![diagnostic],
            provider_profile: profile.into(),
            requested_uri: requested_uri.into(),
            root_path: None,
            requested_partition_columns,
            discovered_partition_columns: vec![],
            discovered_partition_values: vec![],
            partition_directory_count: 0,
            listing_directory_count: 0,
            max_partition_depth: 0,
        }
    }

    fn has_errors(&self) -> bool {
        self.status.is_error()
            || self.diagnostics.iter().any(|diagnostic| {
                matches!(
                    diagnostic.severity,
                    DiagnosticSeverity::Error | DiagnosticSeverity::Fatal
                )
            })
    }

    fn to_human_text(&self) -> String {
        let claim_gate_status = if self.has_errors() {
            "not_claim_grade"
        } else {
            "fixture_smoke_only"
        };
        format!(
            "object_store_partition_discovery_smoke(status={}, profile={}, partition_directories={}, discovered_columns={}, object_store_listing_io={}, fallback_attempted=false, external_engine_invoked=false, claim_gate_status={})",
            self.status.as_str(),
            self.provider_profile,
            self.partition_directory_count,
            self.discovered_partition_columns.len(),
            !self.has_errors(),
            claim_gate_status
        )
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct LocalEmulatorWriteCommit {
    status: ObjectStoreWriteSmokeStatus,
    staging_path: PathBuf,
    written_bytes: usize,
    cleanup_deleted_count: usize,
    target_content_digest: String,
    commit_manifest_bytes: usize,
    commit_manifest_digest: String,
}

impl ObjectStoreWriteSmokeReport {
    fn blocked(
        status: ObjectStoreWriteSmokeStatus,
        provider_profile: impl Into<String>,
        source_uri: impl Into<String>,
        target_uri: impl Into<String>,
        allow_overwrite: bool,
        rollback_after_commit: bool,
        diagnostic: Diagnostic,
    ) -> Self {
        Self {
            status,
            diagnostics: vec![diagnostic],
            provider_profile: provider_profile.into(),
            source_uri: source_uri.into(),
            target_uri: target_uri.into(),
            source_path: None,
            target_path: None,
            staging_path: None,
            commit_manifest_path: None,
            idempotency_key: "not_emitted_blocked".to_string(),
            idempotency_status: "not_emitted_blocked",
            allow_overwrite,
            rollback_after_commit,
            payload_bytes: 0,
            written_bytes: 0,
            commit_manifest_bytes: 0,
            cleanup_deleted_count: 0,
            payload_digest: "not_emitted_no_object_write".to_string(),
            target_content_digest: "not_emitted_no_object_write".to_string(),
            commit_manifest_digest: "not_emitted_no_commit_manifest".to_string(),
        }
    }

    fn has_errors(&self) -> bool {
        self.status.is_error()
            || self.diagnostics.iter().any(|diagnostic| {
                matches!(
                    diagnostic.severity,
                    DiagnosticSeverity::Error | DiagnosticSeverity::Fatal
                )
            })
    }

    fn to_human_text(&self) -> String {
        let claim_gate_status = if self.has_errors() {
            "not_claim_grade"
        } else {
            "fixture_smoke_only"
        };
        format!(
            "object_store_write_smoke(status={}, profile={}, bytes_written={}, rollback_status={}, object_store_io={}, fallback_attempted=false, external_engine_invoked=false, claim_gate_status={})",
            self.status.as_str(),
            self.provider_profile,
            self.written_bytes,
            rollback_status(self.status, self.rollback_after_commit),
            !self.has_errors(),
            claim_gate_status
        )
    }
}

impl ObjectStoreWriteRecoveryReport {
    fn blocked(
        status: ObjectStoreWriteRecoveryStatus,
        provider_profile: impl Into<String>,
        target_uri: impl Into<String>,
        expected_idempotency_key: Option<String>,
        diagnostic: Diagnostic,
    ) -> Self {
        Self {
            status,
            diagnostics: vec![diagnostic],
            provider_profile: provider_profile.into(),
            target_uri: target_uri.into(),
            target_path: None,
            commit_manifest_path: None,
            expected_idempotency_key,
            recovered_idempotency_key: "not_emitted_blocked".to_string(),
            idempotency_status: "not_emitted_blocked",
            object_bytes: 0,
            recorded_payload_bytes: 0,
            object_digest: "not_emitted_no_object_recovery".to_string(),
            recorded_payload_digest: "not_emitted_no_commit_manifest".to_string(),
            recorded_target_content_digest: "not_emitted_no_commit_manifest".to_string(),
            commit_manifest_bytes: 0,
            commit_manifest_digest: "not_emitted_no_commit_manifest".to_string(),
            target_digest_matched: false,
            payload_digest_matched: false,
            payload_bytes_matched: false,
            target_path_matched: false,
            manifest_shape_matched: false,
        }
    }

    fn has_errors(&self) -> bool {
        self.status.is_error()
            || self.diagnostics.iter().any(|diagnostic| {
                matches!(
                    diagnostic.severity,
                    DiagnosticSeverity::Error | DiagnosticSeverity::Fatal
                )
            })
    }

    fn to_human_text(&self) -> String {
        let claim_gate_status = if self.has_errors() {
            "not_claim_grade"
        } else {
            "fixture_smoke_only"
        };
        format!(
            "object_store_write_recovery_smoke(status={}, profile={}, object_bytes={}, target_digest_matched={}, payload_digest_matched={}, object_store_io={}, fallback_attempted=false, external_engine_invoked=false, claim_gate_status={})",
            self.status.as_str(),
            self.provider_profile,
            self.object_bytes,
            self.target_digest_matched,
            self.payload_digest_matched,
            !self.has_errors(),
            claim_gate_status
        )
    }
}

impl ObjectStoreReadSmokeReport {
    fn blocked(
        status: ObjectStoreReadSmokeStatus,
        context: ObjectStoreReadBlockerContext,
        diagnostic: Diagnostic,
    ) -> Self {
        Self {
            status,
            diagnostics: vec![diagnostic],
            provider_profile: context.provider_profile,
            requested_uri: context.requested_uri,
            object_store_provider: context.object_store_provider,
            object_store_bucket: context.object_store_bucket,
            object_store_key: context.object_store_key,
            local_path: None,
            fixture_listing_requested: context.fixture_listing_requested,
            read_mode: context.read_mode,
            requested_range: context.requested_range,
            object_size_bytes: 0,
            object_mtime_millis: None,
            bytes_read: 0,
            read_digest: "not_emitted_no_object_read".to_string(),
            source_state_id: "not_emitted_no_object_read".to_string(),
            source_state_digest: "not_emitted_no_object_read".to_string(),
            source_content_digest: "not_emitted_no_object_read".to_string(),
            source_fingerprint_kind: "not_emitted_no_object_read",
        }
    }

    fn has_errors(&self) -> bool {
        self.status.is_error()
            || self.diagnostics.iter().any(|diagnostic| {
                matches!(
                    diagnostic.severity,
                    DiagnosticSeverity::Error | DiagnosticSeverity::Fatal
                )
            })
    }

    fn to_human_text(&self) -> String {
        let claim_gate_status = read_claim_gate_status(self);
        format!(
            "object_store_read_smoke(status={}, profile={}, read_mode={}, bytes_read={}, object_store_io={}, fallback_attempted=false, external_engine_invoked=false, claim_gate_status={})",
            self.status.as_str(),
            self.provider_profile,
            self.read_mode.as_str(),
            self.bytes_read,
            !self.has_errors(),
            claim_gate_status
        )
    }
}

#[allow(clippy::too_many_lines)] // Keep admission and the existing fixture report in the same boundary.
pub(crate) fn handle_object_store_read_smoke(
    args: impl Iterator<Item = String>,
    format: OutputFormat,
    context: &crate::command_context::CommandContext<'_>,
) -> ExitCode {
    let (mut args, resources) = match crate::execution_resources::require_for_command(
        args,
        format,
        "object-store-read-smoke",
        &["--profile", "--public-fixture-path", "--range"],
        context,
    ) {
        Ok(admitted) => admitted,
        Err(code) => return code,
    };
    let Some(source) = args.next() else {
        return emit_error(
            OBJECT_STORE_READ_SMOKE_COMMAND,
            format,
            "object-store read smoke failed",
            &ShardLoomError::InvalidOperation(
                "object-store-read-smoke requires <local-object-path>".to_string(),
            ),
        );
    };

    let mut profile = DEFAULT_PROFILE.to_string();
    let mut requested_range = None;
    let mut public_fixture_path: Option<String> = None;
    let mut fixture_listing_requested = false;
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "--profile" => {
                let Some(value) = args.next() else {
                    return emit_error(
                        OBJECT_STORE_READ_SMOKE_COMMAND,
                        format,
                        "object-store read smoke failed",
                        &ShardLoomError::InvalidOperation(
                            "missing value for --profile".to_string(),
                        ),
                    );
                };
                profile = value;
            }
            "--public-fixture-path" => {
                let Some(value) = args.next() else {
                    return emit_error(
                        OBJECT_STORE_READ_SMOKE_COMMAND,
                        format,
                        "object-store read smoke failed",
                        &ShardLoomError::InvalidOperation(
                            "missing value for --public-fixture-path".to_string(),
                        ),
                    );
                };
                public_fixture_path = Some(value);
            }
            "--fixture-listing" => {
                fixture_listing_requested = true;
            }
            "--range" => {
                let Some(value) = args.next() else {
                    return emit_error(
                        OBJECT_STORE_READ_SMOKE_COMMAND,
                        format,
                        "object-store read smoke failed",
                        &ShardLoomError::InvalidOperation("missing value for --range".to_string()),
                    );
                };
                requested_range = match parse_requested_range(&value) {
                    Ok(range) => Some(range),
                    Err(error) => {
                        return emit_blocked_range_parse(
                            format, &source, &profile, &error, resources,
                        );
                    }
                };
            }
            value => {
                return emit_error(
                    OBJECT_STORE_READ_SMOKE_COMMAND,
                    format,
                    "object-store read smoke failed",
                    &cli_unknown_arg_error(OBJECT_STORE_READ_SMOKE_COMMAND, value),
                );
            }
        }
    }

    let pool = match crate::fixture_io::owner_for_command(
        resources,
        OBJECT_STORE_READ_SMOKE_COMMAND,
        format,
        context,
    ) {
        Ok(pool) => pool,
        Err(code) => return code,
    };
    let report = execute_object_store_read_smoke(
        &source,
        &profile,
        requested_range,
        public_fixture_path.as_deref(),
        fixture_listing_requested,
        &pool,
    );
    emit_object_store_read_smoke_report(format, &report, resources, Some(&pool))
}

#[allow(clippy::too_many_lines)] // Keep argument validation before resource admission and I/O.
pub(crate) fn handle_object_store_write_smoke(
    args: impl Iterator<Item = String>,
    format: OutputFormat,
    context: &crate::command_context::CommandContext<'_>,
) -> ExitCode {
    let (mut args, resources) = match crate::execution_resources::require_for_command(
        args,
        format,
        "object-store-write-smoke",
        &["--profile", "--idempotency-key"],
        context,
    ) {
        Ok(admitted) => admitted,
        Err(code) => return code,
    };
    let Some(source) = args.next() else {
        return emit_error(
            OBJECT_STORE_WRITE_SMOKE_COMMAND,
            format,
            "object-store write smoke failed",
            &ShardLoomError::InvalidOperation(
                "object-store-write-smoke requires <source-local-path> <target-local-object-path>"
                    .to_string(),
            ),
        );
    };
    let Some(target) = args.next() else {
        return emit_error(
            OBJECT_STORE_WRITE_SMOKE_COMMAND,
            format,
            "object-store write smoke failed",
            &ShardLoomError::InvalidOperation(
                "object-store-write-smoke requires <source-local-path> <target-local-object-path>"
                    .to_string(),
            ),
        );
    };

    let mut profile = DEFAULT_PROFILE.to_string();
    let mut idempotency_key: Option<String> = None;
    let mut allow_overwrite = false;
    let mut rollback_after_commit = false;
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "--profile" => {
                let Some(value) = args.next() else {
                    return emit_error(
                        OBJECT_STORE_WRITE_SMOKE_COMMAND,
                        format,
                        "object-store write smoke failed",
                        &ShardLoomError::InvalidOperation(
                            "missing value for --profile".to_string(),
                        ),
                    );
                };
                profile = value;
            }
            "--idempotency-key" => {
                let Some(value) = args.next() else {
                    return emit_error(
                        OBJECT_STORE_WRITE_SMOKE_COMMAND,
                        format,
                        "object-store write smoke failed",
                        &ShardLoomError::InvalidOperation(
                            "missing value for --idempotency-key".to_string(),
                        ),
                    );
                };
                let value = value.trim().to_string();
                if value.is_empty() {
                    return emit_error(
                        OBJECT_STORE_WRITE_SMOKE_COMMAND,
                        format,
                        "object-store write smoke failed",
                        &ShardLoomError::InvalidOperation(
                            "idempotency key must not be empty".to_string(),
                        ),
                    );
                }
                idempotency_key = Some(value);
            }
            "--allow-overwrite" => allow_overwrite = true,
            "--rollback-after-commit" => rollback_after_commit = true,
            value => {
                return emit_error(
                    OBJECT_STORE_WRITE_SMOKE_COMMAND,
                    format,
                    "object-store write smoke failed",
                    &cli_unknown_arg_error(OBJECT_STORE_WRITE_SMOKE_COMMAND, value),
                );
            }
        }
    }

    let pool = match crate::fixture_io::owner_for_command(
        resources,
        OBJECT_STORE_WRITE_SMOKE_COMMAND,
        format,
        context,
    ) {
        Ok(pool) => pool,
        Err(code) => return code,
    };
    let report = execute_object_store_write_smoke(
        &source,
        &target,
        &profile,
        idempotency_key.as_deref(),
        allow_overwrite,
        rollback_after_commit,
        &pool,
    );
    emit_object_store_write_smoke_report(format, &report, resources, &pool)
}

pub(crate) fn handle_object_store_write_recovery_smoke(
    args: impl Iterator<Item = String>,
    format: OutputFormat,
    context: &crate::command_context::CommandContext<'_>,
) -> ExitCode {
    let (mut args, resources) = match crate::execution_resources::require_for_command(
        args,
        format,
        "object-store-write-recovery-smoke",
        &["--profile", "--idempotency-key"],
        context,
    ) {
        Ok(admitted) => admitted,
        Err(code) => return code,
    };
    let Some(target) = args.next() else {
        return emit_error(
            OBJECT_STORE_WRITE_RECOVERY_SMOKE_COMMAND,
            format,
            "object-store write recovery smoke failed",
            &ShardLoomError::InvalidOperation(
                "object-store-write-recovery-smoke requires <target-local-object-path>".to_string(),
            ),
        );
    };

    let mut profile = DEFAULT_PROFILE.to_string();
    let mut idempotency_key: Option<String> = None;
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "--profile" => {
                let Some(value) = args.next() else {
                    return emit_error(
                        OBJECT_STORE_WRITE_RECOVERY_SMOKE_COMMAND,
                        format,
                        "object-store write recovery smoke failed",
                        &ShardLoomError::InvalidOperation(
                            "missing value for --profile".to_string(),
                        ),
                    );
                };
                profile = value;
            }
            "--idempotency-key" => {
                let Some(value) = args.next() else {
                    return emit_error(
                        OBJECT_STORE_WRITE_RECOVERY_SMOKE_COMMAND,
                        format,
                        "object-store write recovery smoke failed",
                        &ShardLoomError::InvalidOperation(
                            "missing value for --idempotency-key".to_string(),
                        ),
                    );
                };
                let value = value.trim().to_string();
                if value.is_empty() {
                    return emit_error(
                        OBJECT_STORE_WRITE_RECOVERY_SMOKE_COMMAND,
                        format,
                        "object-store write recovery smoke failed",
                        &ShardLoomError::InvalidOperation(
                            "idempotency key must not be empty".to_string(),
                        ),
                    );
                }
                idempotency_key = Some(value);
            }
            value => {
                return emit_error(
                    OBJECT_STORE_WRITE_RECOVERY_SMOKE_COMMAND,
                    format,
                    "object-store write recovery smoke failed",
                    &cli_unknown_arg_error(OBJECT_STORE_WRITE_RECOVERY_SMOKE_COMMAND, value),
                );
            }
        }
    }

    let pool = match crate::fixture_io::owner_for_command(
        resources,
        OBJECT_STORE_WRITE_RECOVERY_SMOKE_COMMAND,
        format,
        context,
    ) {
        Ok(pool) => pool,
        Err(code) => return code,
    };
    let report = execute_object_store_write_recovery_smoke(
        &target,
        &profile,
        idempotency_key.as_deref(),
        &pool,
    );
    emit_object_store_write_recovery_smoke_report(format, &report, resources, &pool)
}

pub(crate) fn handle_object_store_partition_discovery_smoke(
    args: impl Iterator<Item = String>,
    format: OutputFormat,
    context: &crate::command_context::CommandContext<'_>,
) -> ExitCode {
    let (mut args, resources) = match crate::execution_resources::require_for_command(
        args,
        format,
        "object-store-partition-discovery-smoke",
        &["--profile", "--partition-columns"],
        context,
    ) {
        Ok(admitted) => admitted,
        Err(code) => return code,
    };
    let Some(root) = args.next() else {
        return emit_error(
            OBJECT_STORE_PARTITION_DISCOVERY_SMOKE_COMMAND,
            format,
            "object-store partition discovery smoke failed",
            &ShardLoomError::InvalidOperation(
                "object-store-partition-discovery-smoke requires <local-partition-root>"
                    .to_string(),
            ),
        );
    };

    let mut profile = DEFAULT_PROFILE.to_string();
    let mut partition_columns: Vec<String> = vec![];
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "--profile" => {
                let Some(value) = args.next() else {
                    return emit_error(
                        OBJECT_STORE_PARTITION_DISCOVERY_SMOKE_COMMAND,
                        format,
                        "object-store partition discovery smoke failed",
                        &ShardLoomError::InvalidOperation(
                            "missing value for --profile".to_string(),
                        ),
                    );
                };
                profile = value;
            }
            "--partition-columns" => {
                let Some(value) = args.next() else {
                    return emit_error(
                        OBJECT_STORE_PARTITION_DISCOVERY_SMOKE_COMMAND,
                        format,
                        "object-store partition discovery smoke failed",
                        &ShardLoomError::InvalidOperation(
                            "missing value for --partition-columns".to_string(),
                        ),
                    );
                };
                partition_columns = parse_partition_columns(&value);
                if partition_columns.is_empty() {
                    return emit_error(
                        OBJECT_STORE_PARTITION_DISCOVERY_SMOKE_COMMAND,
                        format,
                        "object-store partition discovery smoke failed",
                        &ShardLoomError::InvalidOperation(
                            "partition columns must not be empty".to_string(),
                        ),
                    );
                }
            }
            value => {
                return emit_error(
                    OBJECT_STORE_PARTITION_DISCOVERY_SMOKE_COMMAND,
                    format,
                    "object-store partition discovery smoke failed",
                    &cli_unknown_arg_error(OBJECT_STORE_PARTITION_DISCOVERY_SMOKE_COMMAND, value),
                );
            }
        }
    }

    let pool = match crate::fixture_io::owner_for_command(
        resources,
        OBJECT_STORE_PARTITION_DISCOVERY_SMOKE_COMMAND,
        format,
        context,
    ) {
        Ok(pool) => pool,
        Err(code) => return code,
    };
    let report = match execute_object_store_partition_discovery_smoke(
        &root,
        &profile,
        partition_columns,
        &pool,
    ) {
        Ok(report) => report,
        Err(error) => {
            return crate::cli_output::emit_error_with_fields(
                OBJECT_STORE_PARTITION_DISCOVERY_SMOKE_COMMAND,
                format,
                "partition discovery resource admission failed",
                &error,
                crate::fixture_io::with_observation_fields(Vec::new(), resources, &pool),
            );
        }
    };
    emit_object_store_partition_discovery_smoke_report(format, report.value(), resources, &pool)
}

fn emit_blocked_range_parse(
    format: OutputFormat,
    source: &str,
    profile: &str,
    error: &ShardLoomError,
    resources: shardloom_core::ExecutionResources,
) -> ExitCode {
    let report = ObjectStoreReadSmokeReport::blocked(
        ObjectStoreReadSmokeStatus::BlockedInvalidRange,
        ObjectStoreReadBlockerContext::new(source, profile, ReadMode::ByteRange, None, false),
        Diagnostic::invalid_input(
            "object_store_read_range",
            error.to_string(),
            "Use --range offset:length with a positive length.",
        ),
    );
    emit_object_store_read_smoke_report(format, &report, resources, None)
}

fn emit_object_store_read_smoke_report(
    format: OutputFormat,
    report: &ObjectStoreReadSmokeReport,
    resources: shardloom_core::ExecutionResources,
    pool: Option<&LiveMemoryPool>,
) -> ExitCode {
    let has_errors = report.has_errors();
    let status = if has_errors {
        CommandStatus::Unsupported
    } else {
        CommandStatus::Success
    };
    emit(
        OBJECT_STORE_READ_SMOKE_COMMAND,
        format,
        status,
        object_store_read_summary(&report.provider_profile).to_string(),
        report.to_human_text(),
        report.diagnostics.clone(),
        pool.map_or_else(
            || {
                crate::execution_resources::with_declaration_fields(
                    object_store_read_smoke_fields(report),
                    resources,
                )
            },
            |pool| {
                crate::fixture_io::with_observation_fields(
                    object_store_read_smoke_fields(report),
                    resources,
                    pool,
                )
            },
        ),
    );
    if has_errors {
        ExitCode::from(1)
    } else {
        ExitCode::SUCCESS
    }
}

fn emit_object_store_write_smoke_report(
    format: OutputFormat,
    report: &ObjectStoreWriteSmokeReport,
    resources: shardloom_core::ExecutionResources,
    pool: &LiveMemoryPool,
) -> ExitCode {
    let has_errors = report.has_errors();
    let status = if has_errors {
        CommandStatus::Unsupported
    } else {
        CommandStatus::Success
    };
    emit(
        OBJECT_STORE_WRITE_SMOKE_COMMAND,
        format,
        status,
        "object-store local-emulator write smoke".to_string(),
        report.to_human_text(),
        report.diagnostics.clone(),
        crate::fixture_io::with_observation_fields(
            object_store_write_smoke_fields(report),
            resources,
            pool,
        ),
    );
    if has_errors {
        ExitCode::from(1)
    } else {
        ExitCode::SUCCESS
    }
}

fn emit_object_store_write_recovery_smoke_report(
    format: OutputFormat,
    report: &ObjectStoreWriteRecoveryReport,
    resources: shardloom_core::ExecutionResources,
    pool: &LiveMemoryPool,
) -> ExitCode {
    let has_errors = report.has_errors();
    let status = if has_errors {
        CommandStatus::Unsupported
    } else {
        CommandStatus::Success
    };
    emit(
        OBJECT_STORE_WRITE_RECOVERY_SMOKE_COMMAND,
        format,
        status,
        "object-store local-emulator write recovery smoke".to_string(),
        report.to_human_text(),
        report.diagnostics.clone(),
        crate::fixture_io::with_observation_fields(
            object_store_write_recovery_smoke_fields(report),
            resources,
            pool,
        ),
    );
    if has_errors {
        ExitCode::from(1)
    } else {
        ExitCode::SUCCESS
    }
}

fn emit_object_store_partition_discovery_smoke_report(
    format: OutputFormat,
    report: &ObjectStorePartitionDiscoveryReport,
    resources: shardloom_core::ExecutionResources,
    pool: &LiveMemoryPool,
) -> ExitCode {
    let has_errors = report.has_errors();
    let status = if has_errors {
        CommandStatus::Unsupported
    } else {
        CommandStatus::Success
    };
    emit(
        OBJECT_STORE_PARTITION_DISCOVERY_SMOKE_COMMAND,
        format,
        status,
        "object-store local-emulator partition discovery smoke".to_string(),
        report.to_human_text(),
        report.diagnostics.clone(),
        crate::fixture_io::with_observation_fields(
            object_store_partition_discovery_smoke_fields(report),
            resources,
            pool,
        ),
    );
    if has_errors {
        ExitCode::from(1)
    } else {
        ExitCode::SUCCESS
    }
}

fn execute_object_store_read_smoke(
    source: &str,
    profile: &str,
    requested_range: Option<RequestedRange>,
    public_fixture_path: Option<&str>,
    fixture_listing_requested: bool,
    pool: &LiveMemoryPool,
) -> ObjectStoreReadSmokeReport {
    let read_mode = read_mode_for(requested_range);
    if let Some(report) = early_profile_blocker(
        source,
        profile,
        read_mode,
        requested_range,
        public_fixture_path,
        fixture_listing_requested,
    ) {
        return report;
    }
    if profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
        return execute_public_fixture_read_smoke(
            source,
            profile,
            requested_range,
            public_fixture_path.expect("checked by early_profile_blocker"),
            fixture_listing_requested,
            pool,
        );
    }

    let local_path = match normalize_local_emulator_path(source) {
        Ok(path) => path,
        Err(error) => {
            return local_path_blocker(
                source,
                profile,
                read_mode,
                requested_range,
                fixture_listing_requested,
                &error,
            );
        }
    };
    let metadata = match local_emulator_metadata(&local_path) {
        Ok(metadata) => metadata,
        Err(error) => {
            return local_metadata_blocker(
                source,
                profile,
                read_mode,
                requested_range,
                fixture_listing_requested,
                &error,
            );
        }
    };
    if let Some(report) = range_blocker(
        source,
        profile,
        read_mode,
        requested_range,
        metadata.len(),
        fixture_listing_requested,
    ) {
        return report;
    }

    let bytes = match read_local_emulator_bytes(&local_path, requested_range, metadata.len(), pool)
    {
        Ok(bytes) => bytes,
        Err(error) => {
            return read_error_blocker(
                source,
                profile,
                read_mode,
                requested_range,
                fixture_listing_requested,
                &error,
            );
        }
    };
    successful_object_store_read_report(
        ObjectStoreReadSuccessInput {
            source,
            profile,
            object_store_provider: "local_emulator".to_string(),
            object_store_bucket: "not_applicable".to_string(),
            object_store_key: "not_applicable".to_string(),
            local_path,
            fixture_listing_requested: false,
            read_mode,
            metadata: &metadata,
            requested_range,
        },
        bytes.value(),
    )
}

fn execute_public_fixture_read_smoke(
    source: &str,
    profile: &str,
    requested_range: Option<RequestedRange>,
    public_fixture_path: &str,
    fixture_listing_requested: bool,
    pool: &LiveMemoryPool,
) -> ObjectStoreReadSmokeReport {
    let read_mode = read_mode_for(requested_range);
    let parsed = match parse_object_store_uri(source) {
        Ok(parsed) => parsed,
        Err(error) => {
            return public_fixture_uri_blocker(
                source,
                profile,
                read_mode,
                requested_range,
                fixture_listing_requested,
                &error,
            );
        }
    };
    let local_path = match normalize_local_emulator_path(public_fixture_path) {
        Ok(path) => path,
        Err(error) => {
            return public_fixture_path_blocker(
                source,
                profile,
                read_mode,
                requested_range,
                fixture_listing_requested,
                &error,
            );
        }
    };
    let metadata = match local_emulator_metadata(&local_path) {
        Ok(metadata) => metadata,
        Err(error) => {
            return local_metadata_blocker(
                source,
                profile,
                read_mode,
                requested_range,
                fixture_listing_requested,
                &error,
            );
        }
    };
    if let Some(report) = range_blocker(
        source,
        profile,
        read_mode,
        requested_range,
        metadata.len(),
        fixture_listing_requested,
    ) {
        return report;
    }
    let bytes = match read_local_emulator_bytes(&local_path, requested_range, metadata.len(), pool)
    {
        Ok(bytes) => bytes,
        Err(error) => {
            return read_error_blocker(
                source,
                profile,
                read_mode,
                requested_range,
                fixture_listing_requested,
                &error,
            );
        }
    };
    successful_object_store_read_report(
        ObjectStoreReadSuccessInput {
            source,
            profile,
            object_store_provider: parsed.provider.to_string(),
            object_store_bucket: parsed.bucket,
            object_store_key: parsed.key,
            local_path,
            fixture_listing_requested,
            read_mode,
            metadata: &metadata,
            requested_range,
        },
        bytes.value(),
    )
}

fn execute_object_store_write_smoke(
    source: &str,
    target: &str,
    profile: &str,
    idempotency_key: Option<&str>,
    allow_overwrite: bool,
    rollback_after_commit: bool,
    pool: &LiveMemoryPool,
) -> ObjectStoreWriteSmokeReport {
    if let Some(report) = early_write_profile_blocker(
        source,
        target,
        profile,
        allow_overwrite,
        rollback_after_commit,
    ) {
        return report;
    }

    let (source_path, target_path, payload) = match prepare_local_emulator_write_inputs(
        source,
        target,
        profile,
        allow_overwrite,
        rollback_after_commit,
        pool,
    ) {
        Ok(inputs) => inputs,
        Err(report) => return *report,
    };
    let payload_bytes = payload.value().len();
    let payload_digest = fnv64_digest_bytes(payload.value());
    let (idempotency_key, idempotency_status) =
        resolved_idempotency_key(idempotency_key, source, target, &payload_digest);
    let staging_path = staging_object_path(&target_path, &idempotency_key);
    let commit_manifest_path = commit_manifest_sidecar_path(&target_path);
    let commit_result = perform_local_emulator_write_commit(
        source,
        target,
        &source_path,
        &target_path,
        &staging_path,
        &commit_manifest_path,
        &idempotency_key,
        &payload_digest,
        payload,
        allow_overwrite,
        rollback_after_commit,
        pool,
    );

    match commit_result {
        Ok(commit) => ObjectStoreWriteSmokeReport {
            status: commit.status,
            diagnostics: vec![],
            provider_profile: profile.to_string(),
            source_uri: source.to_string(),
            target_uri: target.to_string(),
            source_path: Some(source_path),
            target_path: Some(target_path),
            staging_path: Some(commit.staging_path),
            commit_manifest_path: Some(commit_manifest_path),
            idempotency_key,
            idempotency_status,
            allow_overwrite,
            rollback_after_commit,
            payload_bytes,
            written_bytes: commit.written_bytes,
            commit_manifest_bytes: commit.commit_manifest_bytes,
            cleanup_deleted_count: commit.cleanup_deleted_count,
            payload_digest,
            target_content_digest: commit.target_content_digest,
            commit_manifest_digest: commit.commit_manifest_digest,
        },
        Err(error) => write_error_blocker(
            source,
            target,
            profile,
            allow_overwrite,
            rollback_after_commit,
            &error,
        ),
    }
}

#[allow(clippy::too_many_lines)]
fn execute_object_store_write_recovery_smoke(
    target: &str,
    profile: &str,
    expected_idempotency_key: Option<&str>,
    pool: &LiveMemoryPool,
) -> ObjectStoreWriteRecoveryReport {
    let expected_idempotency_key = expected_idempotency_key.map(str::to_string);
    if profile != DEFAULT_PROFILE {
        return ObjectStoreWriteRecoveryReport::blocked(
            ObjectStoreWriteRecoveryStatus::BlockedUnsupportedProfile,
            profile,
            target,
            expected_idempotency_key,
            Diagnostic::object_store_blocked(
                "object_store_write_recovery_profile",
                format!("profile {profile} is not admitted for object-store write recovery"),
                "Use --profile local-emulator with a committed local object path.",
            ),
        );
    }
    if is_remote_object_store_uri(target) {
        return ObjectStoreWriteRecoveryReport::blocked(
            ObjectStoreWriteRecoveryStatus::BlockedRemoteProvider,
            profile,
            target,
            expected_idempotency_key,
            Diagnostic::object_store_blocked(
                "object_store_write_recovery_remote_target",
                "real S3/GCS/ADLS recovery remains blocked; no credential, provider, or network probe was performed",
                "Use a committed local-emulator object and sidecar commit manifest for this recovery smoke.",
            ),
        );
    }

    let target_path = match normalize_local_emulator_path(target) {
        Ok(path) => path,
        Err(error) => {
            return write_recovery_target_blocker(
                ObjectStoreWriteRecoveryStatus::BlockedInvalidTarget,
                target,
                profile,
                expected_idempotency_key,
                error.to_string(),
            );
        }
    };
    if target_path.is_dir() {
        return write_recovery_target_blocker(
            ObjectStoreWriteRecoveryStatus::BlockedInvalidTarget,
            target,
            profile,
            expected_idempotency_key,
            "local-emulator recovery target is a directory, not an object path",
        );
    }
    let commit_manifest_path = commit_manifest_sidecar_path(&target_path);
    let object_size_bytes = target_path.metadata().map_or(0, |metadata| metadata.len());
    let object_bytes = match read_local_emulator_bytes(&target_path, None, object_size_bytes, pool)
    {
        Ok(bytes) => bytes,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
            return ObjectStoreWriteRecoveryReport::blocked(
                ObjectStoreWriteRecoveryStatus::BlockedMissingObject,
                profile,
                target,
                expected_idempotency_key,
                Diagnostic::new(
                    DiagnosticCode::InvalidInput,
                    DiagnosticSeverity::Error,
                    DiagnosticCategory::InvalidInput,
                    "Object-store write recovery target object is missing.",
                    Some("object_store_write_recovery_object".to_string()),
                    Some("committed local-emulator object could not be found".to_string()),
                    Some(
                        "Run object-store-write-smoke without rollback before recovery."
                            .to_string(),
                    ),
                    FallbackStatus::disabled_by_policy(),
                ),
            );
        }
        Err(error) => {
            return write_recovery_read_error_blocker(
                target,
                profile,
                expected_idempotency_key,
                "object_store_write_recovery_object",
                &error,
            );
        }
    };
    let object_digest = fnv64_digest_bytes(object_bytes.value());
    let object_length = object_bytes.value().len();
    drop(object_bytes);
    let commit_manifest = match crate::fixture_io::read_utf8(
        &commit_manifest_path,
        MAX_OBJECT_STORE_COMMIT_MANIFEST_BYTES,
        "object-store write recovery commit manifest",
        pool,
    ) {
        Ok(content) => content,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
            return ObjectStoreWriteRecoveryReport::blocked(
                ObjectStoreWriteRecoveryStatus::BlockedMissingCommitManifest,
                profile,
                target,
                expected_idempotency_key,
                Diagnostic::new(
                    DiagnosticCode::CommitNotAtomic,
                    DiagnosticSeverity::Error,
                    DiagnosticCategory::Execution,
                    "Object-store write recovery sidecar manifest is missing.",
                    Some("object_store_write_recovery_commit_manifest".to_string()),
                    Some("sidecar commit manifest could not be found".to_string()),
                    Some("Recover only from an object-store-write-smoke commit with its sidecar manifest."
                        .to_string()),
                    FallbackStatus::disabled_by_policy(),
                ),
            );
        }
        Err(error) => {
            return write_recovery_read_error_blocker(
                target,
                profile,
                expected_idempotency_key,
                "object_store_write_recovery_commit_manifest",
                &error,
            );
        }
    };

    let commit_manifest = commit_manifest.value();
    let commit_manifest_bytes = commit_manifest.len();
    let commit_manifest_digest = fnv64_digest(commit_manifest);
    let recorded_payload_digest = extract_json_string_field(commit_manifest, "payload_digest")
        .unwrap_or_else(|| "missing_payload_digest".to_string());
    let recorded_target_content_digest =
        extract_json_string_field(commit_manifest, "target_content_digest")
            .unwrap_or_else(|| "missing_target_content_digest".to_string());
    let recovered_idempotency_key = extract_json_string_field(commit_manifest, "idempotency_key")
        .unwrap_or_else(|| "missing_idempotency_key".to_string());
    let recorded_target_path = extract_json_string_field(commit_manifest, "local_target_path")
        .unwrap_or_else(|| "missing_local_target_path".to_string());
    let recorded_payload_bytes =
        extract_json_usize_field(commit_manifest, "payload_bytes").unwrap_or(0);
    let target_digest_matched = recorded_target_content_digest == object_digest;
    let payload_digest_matched = recorded_payload_digest == object_digest;
    let payload_bytes_matched = recorded_payload_bytes == object_length;
    let target_path_matched = recorded_target_path == target_path.to_string_lossy().as_ref();
    let idempotency_matched = expected_idempotency_key
        .as_deref()
        .is_none_or(|expected| expected == recovered_idempotency_key);
    let manifest_shape_matched = commit_manifest
        .contains("\"schema_version\": \"shardloom.object_store_write_commit_manifest.v1\"")
        && commit_manifest.contains("\"commit_protocol\": \"local_emulator_sidecar_manifest\"")
        && commit_manifest.contains("\"write_mode\": \"single_object_staged_commit\"")
        && commit_manifest.contains("\"fallback_attempted\": false")
        && commit_manifest.contains("\"external_engine_invoked\": false");

    if !target_digest_matched
        || !payload_digest_matched
        || !payload_bytes_matched
        || !target_path_matched
        || !idempotency_matched
        || !manifest_shape_matched
    {
        let mut detail = vec![];
        if !target_digest_matched {
            detail.push("target_digest_mismatch");
        }
        if !payload_digest_matched {
            detail.push("payload_digest_mismatch");
        }
        if !payload_bytes_matched {
            detail.push("payload_bytes_mismatch");
        }
        if !target_path_matched {
            detail.push("target_path_mismatch");
        }
        if !idempotency_matched {
            detail.push("idempotency_key_mismatch");
        }
        if !manifest_shape_matched {
            detail.push("commit_manifest_shape_mismatch");
        }
        return ObjectStoreWriteRecoveryReport {
            status: ObjectStoreWriteRecoveryStatus::BlockedRecoveryMismatch,
            diagnostics: vec![Diagnostic::new(
                DiagnosticCode::CommitNotAtomic,
                DiagnosticSeverity::Error,
                DiagnosticCategory::Execution,
                "Object-store write recovery evidence did not match the committed local object.",
                Some("object_store_write_recovery_evidence".to_string()),
                Some(detail.join(",")),
                Some("Recover only from the sidecar manifest emitted by object-store-write-smoke for the same object and idempotency key."
                    .to_string()),
                FallbackStatus::disabled_by_policy(),
            )],
            provider_profile: profile.to_string(),
            target_uri: target.to_string(),
            target_path: Some(target_path),
            commit_manifest_path: Some(commit_manifest_path),
            expected_idempotency_key,
            recovered_idempotency_key,
            idempotency_status: "recovered_mismatch",
            object_bytes: object_length,
            recorded_payload_bytes,
            object_digest,
            recorded_payload_digest,
            recorded_target_content_digest,
            commit_manifest_bytes,
            commit_manifest_digest,
            target_digest_matched,
            payload_digest_matched,
            payload_bytes_matched,
            target_path_matched,
            manifest_shape_matched,
        };
    }

    ObjectStoreWriteRecoveryReport {
        status: ObjectStoreWriteRecoveryStatus::Recovered,
        diagnostics: vec![],
        provider_profile: profile.to_string(),
        target_uri: target.to_string(),
        target_path: Some(target_path),
        commit_manifest_path: Some(commit_manifest_path),
        expected_idempotency_key,
        recovered_idempotency_key,
        idempotency_status: "recovered_from_commit_manifest",
        object_bytes: object_length,
        recorded_payload_bytes,
        object_digest,
        recorded_payload_digest,
        recorded_target_content_digest,
        commit_manifest_bytes,
        commit_manifest_digest,
        target_digest_matched,
        payload_digest_matched,
        payload_bytes_matched,
        target_path_matched,
        manifest_shape_matched,
    }
}

fn execute_object_store_partition_discovery_smoke(
    root: &str,
    profile: &str,
    requested_partition_columns: Vec<String>,
    pool: &LiveMemoryPool,
) -> shardloom_core::Result<Budgeted<ObjectStorePartitionDiscoveryReport>> {
    let mut lease = pool.reserve(0)?;
    let report = execute_partition_discovery_with_owner(
        root,
        profile,
        requested_partition_columns,
        &mut lease,
    );
    Ok(Budgeted::new(report, lease))
}

#[allow(clippy::too_many_lines)]
fn execute_partition_discovery_with_owner(
    root: &str,
    profile: &str,
    requested_partition_columns: Vec<String>,
    lease: &mut MemoryLease,
) -> ObjectStorePartitionDiscoveryReport {
    if profile != DEFAULT_PROFILE {
        return ObjectStorePartitionDiscoveryReport::blocked(
            if is_remote_object_store_uri(root) {
                ObjectStorePartitionDiscoveryStatus::BlockedRemoteProvider
            } else {
                ObjectStorePartitionDiscoveryStatus::BlockedUnsupportedProfile
            },
            profile,
            redact_object_store_uri(root),
            requested_partition_columns,
            Diagnostic::object_store_blocked(
                "object_store_partition_discovery_profile",
                format!("profile {profile} is not admitted for partition discovery runtime"),
                "Use --profile local-emulator with a caller-owned local partition directory.",
            ),
        );
    }
    if is_remote_object_store_uri(root) {
        return ObjectStorePartitionDiscoveryReport::blocked(
            ObjectStorePartitionDiscoveryStatus::BlockedRemoteProvider,
            profile,
            redact_object_store_uri(root),
            requested_partition_columns,
            Diagnostic::object_store_blocked(
                "object_store_partition_discovery_remote_provider",
                "live S3/GCS/ADLS partition listing remains blocked; no credential or network probe was performed",
                "Use a local-emulator partition directory for fixture proof, or keep live provider discovery gated.",
            ),
        );
    }

    let root_path = match normalize_local_emulator_path(root) {
        Ok(path) => path,
        Err(error) => {
            return ObjectStorePartitionDiscoveryReport::blocked(
                ObjectStorePartitionDiscoveryStatus::BlockedMissingRoot,
                profile,
                root,
                requested_partition_columns,
                Diagnostic::invalid_input(
                    "object_store_partition_discovery_root",
                    error.to_string(),
                    "Use a local path or file:// path with no remote provider.",
                ),
            );
        }
    };
    let metadata = match fs::metadata(&root_path) {
        Ok(metadata) => metadata,
        Err(error) => {
            return ObjectStorePartitionDiscoveryReport::blocked(
                ObjectStorePartitionDiscoveryStatus::BlockedMissingRoot,
                profile,
                root,
                requested_partition_columns,
                Diagnostic::object_store_blocked(
                    "object_store_partition_discovery_root",
                    format!("partition discovery root could not be statted: {error}"),
                    "Create the local-emulator partition root and retry.",
                ),
            );
        }
    };
    if !metadata.is_dir() {
        return ObjectStorePartitionDiscoveryReport::blocked(
            ObjectStorePartitionDiscoveryStatus::BlockedInvalidRoot,
            profile,
            root,
            requested_partition_columns,
            Diagnostic::invalid_input(
                "object_store_partition_discovery_root",
                "partition discovery root is not a directory",
                "Use a directory containing key=value partition folders.",
            ),
        );
    }

    match discover_local_partition_directories(&root_path, lease) {
        Ok(discovery) if discovery.partition_directory_count > 0 => {
            if !requested_partition_columns.is_empty()
                && !partition_column_sets_match(
                    &requested_partition_columns,
                    &discovery.partition_columns,
                )
            {
                return ObjectStorePartitionDiscoveryReport::blocked(
                    ObjectStorePartitionDiscoveryStatus::BlockedPartitionColumnMismatch,
                    profile,
                    root,
                    requested_partition_columns,
                    Diagnostic::object_store_blocked(
                        "object_store_partition_discovery_requested_columns",
                        format!(
                            "requested partition columns do not match discovered key=value columns: discovered {}",
                            joined_or_none(&discovery.partition_columns)
                        ),
                        "Use --partition-columns with the complete discovered key set, or fix the local-emulator partition layout.",
                    ),
                );
            }
            ObjectStorePartitionDiscoveryReport {
                status: ObjectStorePartitionDiscoveryStatus::Succeeded,
                diagnostics: vec![],
                provider_profile: profile.to_string(),
                requested_uri: root.to_string(),
                root_path: Some(root_path),
                requested_partition_columns,
                discovered_partition_columns: discovery.partition_columns,
                discovered_partition_values: discovery.partition_values,
                partition_directory_count: discovery.partition_directory_count,
                listing_directory_count: discovery.listing_directory_count,
                max_partition_depth: discovery.max_partition_depth,
            }
        }
        Ok(_) => ObjectStorePartitionDiscoveryReport::blocked(
            ObjectStorePartitionDiscoveryStatus::BlockedNoPartitions,
            profile,
            root,
            requested_partition_columns,
            Diagnostic::object_store_blocked(
                "object_store_partition_discovery_empty",
                "no key=value partition directories were discovered",
                "Create at least one key=value directory under the local-emulator root.",
            ),
        ),
        Err(error) => ObjectStorePartitionDiscoveryReport::blocked(
            ObjectStorePartitionDiscoveryStatus::BlockedListingError,
            profile,
            root,
            requested_partition_columns,
            Diagnostic::object_store_blocked(
                "object_store_partition_discovery_listing",
                format!("partition discovery listing failed: {error}"),
                "Ensure the local-emulator partition tree can be listed without elevated permissions.",
            ),
        ),
    }
}

type LocalEmulatorWriteInputs = (PathBuf, PathBuf, Budgeted<Vec<u8>>);

fn prepare_local_emulator_write_inputs(
    source: &str,
    target: &str,
    profile: &str,
    allow_overwrite: bool,
    rollback_after_commit: bool,
    pool: &LiveMemoryPool,
) -> Result<LocalEmulatorWriteInputs, Box<ObjectStoreWriteSmokeReport>> {
    let source_path = normalize_local_emulator_path(source).map_err(|error| {
        Box::new(write_source_path_blocker(
            source,
            target,
            profile,
            allow_overwrite,
            rollback_after_commit,
            &error,
        ))
    })?;
    let target_path = normalize_local_emulator_path(target).map_err(|error| {
        Box::new(write_target_path_blocker(
            ObjectStoreWriteSmokeStatus::BlockedInvalidTarget,
            source,
            target,
            profile,
            allow_overwrite,
            rollback_after_commit,
            error.to_string(),
        ))
    })?;
    if let Err((status, message)) =
        validate_local_emulator_write_target(&target_path, allow_overwrite)
    {
        return Err(Box::new(write_target_path_blocker(
            status,
            source,
            target,
            profile,
            allow_overwrite,
            rollback_after_commit,
            message,
        )));
    }
    let source_metadata = match local_emulator_metadata(&source_path) {
        Ok(metadata) => metadata,
        Err(error) => {
            return Err(Box::new(write_source_metadata_blocker(
                source,
                target,
                profile,
                allow_overwrite,
                rollback_after_commit,
                &error,
            )));
        }
    };
    let payload = read_local_emulator_bytes(&source_path, None, source_metadata.len(), pool)
        .map_err(|error| {
            Box::new(write_error_blocker(
                source,
                target,
                profile,
                allow_overwrite,
                rollback_after_commit,
                &error,
            ))
        })?;
    Ok((source_path, target_path, payload))
}

fn read_mode_for(requested_range: Option<RequestedRange>) -> ReadMode {
    if requested_range.is_some() {
        ReadMode::ByteRange
    } else {
        ReadMode::FullFile
    }
}

fn early_profile_blocker(
    source: &str,
    profile: &str,
    read_mode: ReadMode,
    requested_range: Option<RequestedRange>,
    public_fixture_path: Option<&str>,
    fixture_listing_requested: bool,
) -> Option<ObjectStoreReadSmokeReport> {
    if profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
        if let Err(error) = parse_object_store_uri(source) {
            return Some(public_fixture_uri_blocker(
                source,
                profile,
                read_mode,
                requested_range,
                fixture_listing_requested,
                &error,
            ));
        }
        if public_fixture_path.map(str::trim).is_none_or(str::is_empty) {
            return Some(ObjectStoreReadSmokeReport::blocked(
                ObjectStoreReadSmokeStatus::BlockedMissingFixturePath,
                ObjectStoreReadBlockerContext::new(
                    source,
                    profile,
                    read_mode,
                    requested_range,
                    fixture_listing_requested,
                ),
                Diagnostic::invalid_input(
                    "object_store_public_fixture_path",
                    "public-no-credential-fixture profile requires --public-fixture-path",
                    "Provide an explicit local fixture file; ShardLoom will not probe the provider or network.",
                ),
            ));
        }
        return None;
    }
    if profile != DEFAULT_PROFILE {
        return Some(ObjectStoreReadSmokeReport::blocked(
            ObjectStoreReadSmokeStatus::BlockedUnsupportedProfile,
            ObjectStoreReadBlockerContext::new(
                source,
                profile,
                read_mode,
                requested_range,
                fixture_listing_requested,
            ),
            Diagnostic::object_store_blocked(
                "object_store_read_profile",
                format!("profile {profile} is not admitted for object-store read runtime"),
                "Use --profile local-emulator with a local fixture path, or --profile public-no-credential-fixture with a supported object URI and --public-fixture-path.",
            ),
        ));
    }
    if is_remote_object_store_uri(source) {
        return Some(ObjectStoreReadSmokeReport::blocked(
            ObjectStoreReadSmokeStatus::BlockedRemoteProvider,
            ObjectStoreReadBlockerContext::new(
                source,
                profile,
                read_mode,
                requested_range,
                fixture_listing_requested,
            ),
            Diagnostic::object_store_blocked(
                "object_store_remote_read",
                "real S3/GCS/ADLS providers remain blocked; no credential or network probe was performed",
                "Use --profile public-no-credential-fixture with --public-fixture-path for the approved public fixture read proof, or a local-emulator fixture path.",
            ),
        ));
    }
    None
}

fn public_fixture_uri_blocker(
    source: &str,
    profile: &str,
    read_mode: ReadMode,
    requested_range: Option<RequestedRange>,
    fixture_listing_requested: bool,
    error: &ShardLoomError,
) -> ObjectStoreReadSmokeReport {
    ObjectStoreReadSmokeReport::blocked(
        ObjectStoreReadSmokeStatus::BlockedInvalidUri,
        ObjectStoreReadBlockerContext::new(
            source,
            profile,
            read_mode,
            requested_range,
            fixture_listing_requested,
        )
        .with_redacted_uri(source),
        Diagnostic::invalid_input(
            "object_store_public_fixture_uri",
            error.to_string(),
            "Use a supported s3://, gs://, gcs://, abfs://, or abfss:// object URI with a bucket/container and object key.",
        ),
    )
}

fn public_fixture_path_blocker(
    source: &str,
    profile: &str,
    read_mode: ReadMode,
    requested_range: Option<RequestedRange>,
    fixture_listing_requested: bool,
    error: &ShardLoomError,
) -> ObjectStoreReadSmokeReport {
    ObjectStoreReadSmokeReport::blocked(
        ObjectStoreReadSmokeStatus::BlockedReadError,
        ObjectStoreReadBlockerContext::new(
            source,
            profile,
            read_mode,
            requested_range,
            fixture_listing_requested,
        )
        .with_redacted_uri(source),
        Diagnostic::invalid_input(
            "object_store_public_fixture_path",
            error.to_string(),
            "Use a local path or file:// path for the public fixture bytes; remote fixture paths are not admitted.",
        ),
    )
}

fn local_path_blocker(
    source: &str,
    profile: &str,
    read_mode: ReadMode,
    requested_range: Option<RequestedRange>,
    fixture_listing_requested: bool,
    error: &ShardLoomError,
) -> ObjectStoreReadSmokeReport {
    ObjectStoreReadSmokeReport::blocked(
        ObjectStoreReadSmokeStatus::BlockedReadError,
        ObjectStoreReadBlockerContext::new(
            source,
            profile,
            read_mode,
            requested_range,
            fixture_listing_requested,
        )
        .with_redacted_uri(source),
        Diagnostic::invalid_input(
            "object_store_local_emulator_path",
            error.to_string(),
            "Use a local path or file:// path with no remote provider.",
        ),
    )
}

fn local_emulator_metadata(local_path: &Path) -> Result<fs::Metadata, LocalEmulatorMetadataError> {
    match fs::metadata(local_path) {
        Ok(metadata) if metadata.is_file() => Ok(metadata),
        Ok(_) => Err(LocalEmulatorMetadataError::NotRegularFile),
        Err(error) => Err(LocalEmulatorMetadataError::StatFailed(error)),
    }
}

fn local_metadata_blocker(
    source: &str,
    profile: &str,
    read_mode: ReadMode,
    requested_range: Option<RequestedRange>,
    fixture_listing_requested: bool,
    error: &LocalEmulatorMetadataError,
) -> ObjectStoreReadSmokeReport {
    match error {
        LocalEmulatorMetadataError::NotRegularFile => ObjectStoreReadSmokeReport::blocked(
            ObjectStoreReadSmokeStatus::BlockedMissingObject,
            ObjectStoreReadBlockerContext::new(
                source,
                profile,
                read_mode,
                requested_range,
                fixture_listing_requested,
            )
            .with_redacted_uri(source),
            Diagnostic::object_store_blocked(
                object_store_read_object_feature(profile),
                "object-store read fixture source is not a regular file",
                "Use a regular local fixture file for the admitted profile.",
            ),
        ),
        LocalEmulatorMetadataError::StatFailed(error) => ObjectStoreReadSmokeReport::blocked(
            ObjectStoreReadSmokeStatus::BlockedMissingObject,
            ObjectStoreReadBlockerContext::new(
                source,
                profile,
                read_mode,
                requested_range,
                fixture_listing_requested,
            )
            .with_redacted_uri(source),
            Diagnostic::object_store_blocked(
                object_store_read_object_feature(profile),
                format!("object-store read fixture could not be statted: {error}"),
                "Create the local fixture file and retry.",
            ),
        ),
    }
}

fn range_blocker(
    source: &str,
    profile: &str,
    read_mode: ReadMode,
    requested_range: Option<RequestedRange>,
    object_size_bytes: u64,
    fixture_listing_requested: bool,
) -> Option<ObjectStoreReadSmokeReport> {
    let range = requested_range?;
    if range.length > 0 && range.offset.saturating_add(range.length) <= object_size_bytes {
        return None;
    }
    Some(ObjectStoreReadSmokeReport::blocked(
        ObjectStoreReadSmokeStatus::BlockedInvalidRange,
        ObjectStoreReadBlockerContext::new(
            source,
            profile,
            read_mode,
            requested_range,
            fixture_listing_requested,
        )
        .with_redacted_uri(source),
        Diagnostic::invalid_input(
            "object_store_read_range",
            format!(
                "range {}:{} is outside object size {}",
                range.offset, range.length, object_size_bytes
            ),
            "Choose a byte range inside the local-emulator object.",
        ),
    ))
}

fn read_error_blocker(
    source: &str,
    profile: &str,
    read_mode: ReadMode,
    requested_range: Option<RequestedRange>,
    fixture_listing_requested: bool,
    error: &std::io::Error,
) -> ObjectStoreReadSmokeReport {
    ObjectStoreReadSmokeReport::blocked(
        ObjectStoreReadSmokeStatus::BlockedReadError,
        ObjectStoreReadBlockerContext::new(
            source,
            profile,
            read_mode,
            requested_range,
            fixture_listing_requested,
        )
        .with_redacted_uri(source),
        Diagnostic::new(
            DiagnosticCode::ObjectStoreUnsupported,
            DiagnosticSeverity::Error,
            DiagnosticCategory::ObjectStore,
            "Object-store local-emulator read failed.",
            Some("object_store_local_emulator_read".to_string()),
            Some(error.to_string()),
            Some("Retry with a readable local fixture file.".to_string()),
            FallbackStatus::disabled_by_policy(),
        ),
    )
}

fn early_write_profile_blocker(
    source: &str,
    target: &str,
    profile: &str,
    allow_overwrite: bool,
    rollback_after_commit: bool,
) -> Option<ObjectStoreWriteSmokeReport> {
    if profile != DEFAULT_PROFILE {
        return Some(ObjectStoreWriteSmokeReport::blocked(
            ObjectStoreWriteSmokeStatus::BlockedUnsupportedProfile,
            profile,
            source,
            target,
            allow_overwrite,
            rollback_after_commit,
            Diagnostic::object_store_blocked(
                "object_store_write_profile",
                format!("profile {profile} is not admitted for object-store write runtime"),
                "Use --profile local-emulator with local fixture paths.",
            ),
        ));
    }
    if is_remote_object_store_uri(source) || is_remote_object_store_uri(target) {
        return Some(ObjectStoreWriteSmokeReport::blocked(
            ObjectStoreWriteSmokeStatus::BlockedRemoteProvider,
            profile,
            source,
            target,
            allow_overwrite,
            rollback_after_commit,
            Diagnostic::object_store_blocked(
                "object_store_remote_write",
                "real S3/GCS/ADLS providers remain blocked; no credential, network, or provider probe was performed",
                "Use local-emulator fixture paths for this staged write smoke.",
            ),
        ));
    }
    None
}

fn write_source_path_blocker(
    source: &str,
    target: &str,
    profile: &str,
    allow_overwrite: bool,
    rollback_after_commit: bool,
    error: &ShardLoomError,
) -> ObjectStoreWriteSmokeReport {
    ObjectStoreWriteSmokeReport::blocked(
        ObjectStoreWriteSmokeStatus::BlockedMissingSource,
        profile,
        source,
        target,
        allow_overwrite,
        rollback_after_commit,
        Diagnostic::invalid_input(
            "object_store_write_source_path",
            error.to_string(),
            "Use a readable regular local source file or file:// path.",
        ),
    )
}

fn write_target_path_blocker(
    status: ObjectStoreWriteSmokeStatus,
    source: &str,
    target: &str,
    profile: &str,
    allow_overwrite: bool,
    rollback_after_commit: bool,
    message: impl Into<String>,
) -> ObjectStoreWriteSmokeReport {
    ObjectStoreWriteSmokeReport::blocked(
        status,
        profile,
        source,
        target,
        allow_overwrite,
        rollback_after_commit,
        Diagnostic::invalid_input(
            "object_store_write_target_path",
            message.into(),
            "Use a local target path whose parent directory exists; pass --allow-overwrite to replace an existing object.",
        ),
    )
}

fn write_recovery_target_blocker(
    status: ObjectStoreWriteRecoveryStatus,
    target: &str,
    profile: &str,
    expected_idempotency_key: Option<String>,
    message: impl Into<String>,
) -> ObjectStoreWriteRecoveryReport {
    ObjectStoreWriteRecoveryReport::blocked(
        status,
        profile,
        target,
        expected_idempotency_key,
        Diagnostic::invalid_input(
            "object_store_write_recovery_target_path",
            message.into(),
            "Use a committed local object path emitted by object-store-write-smoke.",
        ),
    )
}

fn write_recovery_read_error_blocker(
    target: &str,
    profile: &str,
    expected_idempotency_key: Option<String>,
    feature: &str,
    error: &std::io::Error,
) -> ObjectStoreWriteRecoveryReport {
    ObjectStoreWriteRecoveryReport::blocked(
        ObjectStoreWriteRecoveryStatus::BlockedReadError,
        profile,
        target,
        expected_idempotency_key,
        Diagnostic::new(
            DiagnosticCode::ObjectStoreUnsupported,
            DiagnosticSeverity::Error,
            DiagnosticCategory::ObjectStore,
            "Object-store local-emulator write recovery failed.",
            Some(feature.to_string()),
            Some(error.to_string()),
            Some(
                "Retry with readable local-emulator object and sidecar manifest paths.".to_string(),
            ),
            FallbackStatus::disabled_by_policy(),
        ),
    )
}

fn write_source_metadata_blocker(
    source: &str,
    target: &str,
    profile: &str,
    allow_overwrite: bool,
    rollback_after_commit: bool,
    error: &LocalEmulatorMetadataError,
) -> ObjectStoreWriteSmokeReport {
    let detail = match error {
        LocalEmulatorMetadataError::NotRegularFile => {
            "local-emulator write source is not a regular file".to_string()
        }
        LocalEmulatorMetadataError::StatFailed(error) => {
            format!("local-emulator write source could not be statted: {error}")
        }
    };
    ObjectStoreWriteSmokeReport::blocked(
        ObjectStoreWriteSmokeStatus::BlockedMissingSource,
        profile,
        source,
        target,
        allow_overwrite,
        rollback_after_commit,
        Diagnostic::object_store_blocked(
            "object_store_write_source",
            detail,
            "Create a readable regular local source file and retry.",
        ),
    )
}

fn write_error_blocker(
    source: &str,
    target: &str,
    profile: &str,
    allow_overwrite: bool,
    rollback_after_commit: bool,
    error: &std::io::Error,
) -> ObjectStoreWriteSmokeReport {
    ObjectStoreWriteSmokeReport::blocked(
        ObjectStoreWriteSmokeStatus::BlockedWriteError,
        profile,
        source,
        target,
        allow_overwrite,
        rollback_after_commit,
        Diagnostic::new(
            DiagnosticCode::ObjectStoreUnsupported,
            DiagnosticSeverity::Error,
            DiagnosticCategory::ObjectStore,
            "Object-store local-emulator write failed.",
            Some("object_store_local_emulator_write".to_string()),
            Some(error.to_string()),
            Some("Retry with writable local fixture paths and no remote provider.".to_string()),
            FallbackStatus::disabled_by_policy(),
        ),
    )
}

fn validate_local_emulator_write_target(
    target_path: &Path,
    allow_overwrite: bool,
) -> Result<(), (ObjectStoreWriteSmokeStatus, String)> {
    let Some(parent) = target_path.parent() else {
        return Err((
            ObjectStoreWriteSmokeStatus::BlockedInvalidTarget,
            "local-emulator target must have a parent directory".to_string(),
        ));
    };
    if !parent.as_os_str().is_empty() && !parent.is_dir() {
        return Err((
            ObjectStoreWriteSmokeStatus::BlockedInvalidTarget,
            format!(
                "local-emulator target parent does not exist or is not a directory: {}",
                parent.to_string_lossy()
            ),
        ));
    }
    if target_path.is_dir() {
        return Err((
            ObjectStoreWriteSmokeStatus::BlockedInvalidTarget,
            "local-emulator target is a directory, not an object path".to_string(),
        ));
    }
    if target_path.exists() && !allow_overwrite {
        return Err((
            ObjectStoreWriteSmokeStatus::BlockedTargetExists,
            "local-emulator target already exists".to_string(),
        ));
    }
    Ok(())
}

fn resolved_idempotency_key(
    idempotency_key: Option<&str>,
    source: &str,
    target: &str,
    payload_digest: &str,
) -> (String, &'static str) {
    if let Some(key) = idempotency_key {
        return (key.to_string(), "caller_supplied");
    }
    (
        fnv64_digest(&format!("{source}|{target}|{payload_digest}")),
        "derived_from_payload_digest",
    )
}

fn staging_object_path(target_path: &Path, idempotency_key: &str) -> PathBuf {
    let parent = target_path
        .parent()
        .filter(|path| !path.as_os_str().is_empty())
        .unwrap_or_else(|| Path::new("."));
    let file_name = target_path
        .file_name()
        .map_or_else(|| "object".into(), |name| name.to_string_lossy());
    parent.join(".shardloom-object-store-staging").join(format!(
        "{}.{}.tmp",
        file_name,
        sanitize_idempotency_key(idempotency_key)
    ))
}

fn backup_object_path(target_path: &Path, idempotency_key: &str) -> PathBuf {
    let parent = target_path
        .parent()
        .filter(|path| !path.as_os_str().is_empty())
        .unwrap_or_else(|| Path::new("."));
    let file_name = target_path
        .file_name()
        .map_or_else(|| "object".into(), |name| name.to_string_lossy());
    parent.join(".shardloom-object-store-staging").join(format!(
        "{}.{}.backup",
        file_name,
        sanitize_idempotency_key(idempotency_key)
    ))
}

fn commit_manifest_sidecar_path(target_path: &Path) -> PathBuf {
    PathBuf::from(format!(
        "{}.shardloom-commit.json",
        target_path.to_string_lossy()
    ))
}

struct LocalEmulatorWriteBackups {
    target_backup_path: PathBuf,
    manifest_backup_path: PathBuf,
    target_taken: bool,
    manifest_taken: bool,
}

impl LocalEmulatorWriteBackups {
    fn new(target_path: &Path, commit_manifest_path: &Path, idempotency_key: &str) -> Self {
        Self {
            target_backup_path: backup_object_path(target_path, idempotency_key),
            manifest_backup_path: backup_object_path(commit_manifest_path, idempotency_key),
            target_taken: false,
            manifest_taken: false,
        }
    }

    fn restore(&self, target_path: &Path, commit_manifest_path: &Path) {
        if self.target_taken {
            let _ = fs::rename(&self.target_backup_path, target_path);
        }
        if self.manifest_taken {
            let _ = fs::rename(&self.manifest_backup_path, commit_manifest_path);
        }
    }

    fn restore_required(
        &self,
        target_path: &Path,
        commit_manifest_path: &Path,
    ) -> std::io::Result<()> {
        if self.target_taken {
            fs::rename(&self.target_backup_path, target_path)?;
        }
        if self.manifest_taken {
            fs::rename(&self.manifest_backup_path, commit_manifest_path)?;
        }
        Ok(())
    }

    fn discard(self) -> std::io::Result<()> {
        if self.target_taken {
            remove_file_if_exists(&self.target_backup_path)?;
        }
        if self.manifest_taken {
            remove_file_if_exists(&self.manifest_backup_path)?;
        }
        Ok(())
    }
}

fn prepare_local_emulator_write_backups(
    target_path: &Path,
    commit_manifest_path: &Path,
    idempotency_key: &str,
    allow_overwrite: bool,
) -> std::io::Result<LocalEmulatorWriteBackups> {
    let mut backups =
        LocalEmulatorWriteBackups::new(target_path, commit_manifest_path, idempotency_key);
    if !allow_overwrite {
        return Ok(backups);
    }
    remove_file_if_exists(&backups.target_backup_path)?;
    remove_file_if_exists(&backups.manifest_backup_path)?;
    if target_path.exists() {
        fs::rename(target_path, &backups.target_backup_path)?;
        backups.target_taken = true;
    }
    if commit_manifest_path.exists() {
        match fs::rename(commit_manifest_path, &backups.manifest_backup_path) {
            Ok(()) => backups.manifest_taken = true,
            Err(error) => {
                backups.restore(target_path, commit_manifest_path);
                return Err(error);
            }
        }
    }
    Ok(backups)
}

#[allow(clippy::too_many_arguments)]
#[allow(clippy::too_many_lines)] // Keep commit, recovery, and reservation lifetimes together.
fn perform_local_emulator_write_commit(
    source_uri: &str,
    target_uri: &str,
    source_path: &Path,
    target_path: &Path,
    staging_path: &Path,
    commit_manifest_path: &Path,
    idempotency_key: &str,
    payload_digest: &str,
    payload: Budgeted<Vec<u8>>,
    allow_overwrite: bool,
    rollback_after_commit: bool,
    pool: &LiveMemoryPool,
) -> std::io::Result<LocalEmulatorWriteCommit> {
    let workspace_root = workspace_root_for_local_output(target_path)?;
    validate_workspace_safe_output(&workspace_root, target_path, allow_overwrite)?;
    validate_workspace_safe_output(&workspace_root, commit_manifest_path, true)?;

    let (backups, committed_staging_path) = if allow_overwrite {
        let staging_write_report = crate::fixture_io::write_bytes(
            &workspace_root,
            staging_path,
            true,
            "object-store local-emulator staged object",
            &payload,
            pool,
        )?;
        let backups = prepare_local_emulator_write_backups(
            target_path,
            commit_manifest_path,
            idempotency_key,
            allow_overwrite,
        )?;
        if let Err(error) = fs::rename(staging_path, target_path) {
            let _ = remove_file_if_exists(staging_path);
            backups.restore(target_path, commit_manifest_path);
            return Err(error);
        }
        (backups, staging_write_report.target_path)
    } else {
        let target_write_report = crate::fixture_io::write_bytes(
            &workspace_root,
            target_path,
            false,
            "object-store local-emulator object",
            &payload,
            pool,
        )?;
        (
            LocalEmulatorWriteBackups::new(target_path, commit_manifest_path, idempotency_key),
            target_write_report.staging_path,
        )
    };

    let payload_bytes = payload.value().len();
    // The write is complete. Reuse its credits for verification instead of
    // retaining a second full object alongside an unused source buffer.
    drop(payload);
    let target_bytes = match read_local_emulator_bytes(
        target_path,
        None,
        u64::try_from(payload_bytes).unwrap_or(u64::MAX),
        pool,
    ) {
        Ok(bytes) => bytes,
        Err(error) => {
            let _ = remove_workspace_safe_file_if_exists(&workspace_root, target_path);
            backups.restore(target_path, commit_manifest_path);
            return Err(error);
        }
    };
    let target_content_digest = fnv64_digest_bytes(target_bytes.value());
    drop(target_bytes);
    let manifest = match build_commit_manifest(
        source_uri,
        target_uri,
        source_path,
        target_path,
        idempotency_key,
        payload_bytes,
        payload_digest,
        &target_content_digest,
        pool,
    ) {
        Ok(manifest) => manifest,
        Err(error) => {
            let _ = remove_workspace_safe_file_if_exists(&workspace_root, target_path);
            backups.restore(target_path, commit_manifest_path);
            return Err(error);
        }
    };
    let commit_manifest_digest = fnv64_digest(manifest.value());
    let commit_manifest_bytes = manifest.value().len();
    if let Err(error) = crate::fixture_io::write_bytes(
        &workspace_root,
        commit_manifest_path,
        true,
        "object-store local-emulator commit manifest",
        &manifest,
        pool,
    ) {
        let _ = remove_workspace_safe_file_if_exists(&workspace_root, target_path);
        backups.restore(target_path, commit_manifest_path);
        return Err(error);
    }

    let mut cleanup_deleted_count = 0;
    let status = if rollback_after_commit {
        cleanup_deleted_count += usize::from(remove_workspace_safe_file_if_exists(
            &workspace_root,
            target_path,
        )?);
        cleanup_deleted_count += usize::from(remove_workspace_safe_file_if_exists(
            &workspace_root,
            commit_manifest_path,
        )?);
        backups.restore_required(target_path, commit_manifest_path)?;
        ObjectStoreWriteSmokeStatus::RolledBack
    } else {
        backups.discard()?;
        ObjectStoreWriteSmokeStatus::Committed
    };

    Ok(LocalEmulatorWriteCommit {
        status,
        staging_path: committed_staging_path,
        written_bytes: payload_bytes,
        cleanup_deleted_count,
        target_content_digest,
        commit_manifest_bytes,
        commit_manifest_digest,
    })
}

fn remove_file_if_exists(path: &Path) -> std::io::Result<bool> {
    match fs::remove_file(path) {
        Ok(()) => Ok(true),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(false),
        Err(error) => Err(error),
    }
}

fn workspace_root_for_local_output(path: &Path) -> std::io::Result<PathBuf> {
    shardloom_core::infer_local_output_workspace_root(path).map_err(shardloom_error_to_io_error)
}

fn validate_workspace_safe_output(
    workspace_root: &Path,
    path: &Path,
    allow_overwrite: bool,
) -> std::io::Result<()> {
    shardloom_core::plan_workspace_safe_local_output(workspace_root, path, allow_overwrite)
        .map(|_| ())
        .map_err(shardloom_error_to_io_error)
}

fn remove_workspace_safe_file_if_exists(
    workspace_root: &Path,
    path: &Path,
) -> std::io::Result<bool> {
    validate_workspace_safe_output(workspace_root, path, true)?;
    remove_file_if_exists(path)
}

fn shardloom_error_to_io_error(error: ShardLoomError) -> std::io::Error {
    std::io::Error::other(error)
}

#[allow(clippy::too_many_arguments)]
fn build_commit_manifest(
    source_uri: &str,
    target_uri: &str,
    source_path: &Path,
    target_path: &Path,
    idempotency_key: &str,
    payload_bytes: usize,
    payload_digest: &str,
    target_content_digest: &str,
    pool: &LiveMemoryPool,
) -> std::io::Result<Budgeted<String>> {
    let mut manifest = crate::fixture_io::Text::new(pool).map_err(shardloom_error_to_io_error)?;
    let _ = write!(
        manifest,
        concat!(
            "{{\n",
            "  \"schema_version\": \"shardloom.object_store_write_commit_manifest.v1\",\n",
            "  \"commit_protocol\": \"local_emulator_sidecar_manifest\",\n",
            "  \"write_mode\": \"single_object_staged_commit\",\n",
            "  \"source_uri\": \"{}\",\n",
            "  \"target_uri\": \"{}\",\n",
            "  \"local_source_path\": \"{}\",\n",
            "  \"local_target_path\": \"{}\",\n",
            "  \"idempotency_key\": \"{}\",\n",
            "  \"payload_bytes\": {},\n",
            "  \"payload_digest\": \"{}\",\n",
            "  \"target_content_digest\": \"{}\",\n",
            "  \"fallback_attempted\": false,\n",
            "  \"external_engine_invoked\": false\n",
            "}}\n"
        ),
        JsonEscaped(source_uri),
        JsonEscaped(target_uri),
        JsonEscaped(source_path.display()),
        JsonEscaped(target_path.display()),
        JsonEscaped(idempotency_key),
        payload_bytes,
        JsonEscaped(payload_digest),
        JsonEscaped(target_content_digest),
    );
    manifest.finish().map_err(shardloom_error_to_io_error)
}

fn extract_json_string_field(source: &str, field: &str) -> Option<String> {
    let marker = format!("\"{field}\": \"");
    let value_start = source.find(&marker)? + marker.len();
    let mut value = String::new();
    let mut escaped = false;
    for character in source[value_start..].chars() {
        if escaped {
            value.push(match character {
                '"' => '"',
                '\\' => '\\',
                'n' => '\n',
                'r' => '\r',
                't' => '\t',
                other => other,
            });
            escaped = false;
        } else if character == '\\' {
            escaped = true;
        } else if character == '"' {
            return Some(value);
        } else {
            value.push(character);
        }
    }
    None
}

fn extract_json_usize_field(source: &str, field: &str) -> Option<usize> {
    let marker = format!("\"{field}\": ");
    let value_start = source.find(&marker)? + marker.len();
    let digits: String = source[value_start..]
        .chars()
        .take_while(char::is_ascii_digit)
        .collect();
    digits.parse().ok()
}

fn sanitize_idempotency_key(idempotency_key: &str) -> String {
    let sanitized: String = idempotency_key
        .chars()
        .take(64)
        .map(|character| {
            if character.is_ascii_alphanumeric() || matches!(character, '-' | '_') {
                character
            } else {
                '_'
            }
        })
        .collect();
    if sanitized.is_empty() {
        "idempotency".to_string()
    } else {
        sanitized
    }
}

fn successful_object_store_read_report(
    input: ObjectStoreReadSuccessInput<'_>,
    bytes: &[u8],
) -> ObjectStoreReadSmokeReport {
    let read_digest = fnv64_digest_bytes(bytes);
    let mtime_millis = input.metadata.modified().ok().and_then(|mtime| {
        mtime
            .duration_since(UNIX_EPOCH)
            .ok()
            .map(|duration| duration.as_millis())
    });
    let source_content_digest = read_digest.clone();
    let fingerprint_material = format!(
        "{}|{}|{}|{}|{}|{}",
        input.source,
        input.metadata.len(),
        mtime_millis.unwrap_or_default(),
        input.read_mode.as_str(),
        input.requested_range.map_or(0, |range| range.offset),
        read_digest
    );
    let source_state_digest = fnv64_digest(&fingerprint_material);
    let source_state_prefix = if input.profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
        "object-store-public-fixture"
    } else {
        "object-store-local-emulator"
    };
    let source_state_id = format!(
        "{}-{}",
        source_state_prefix,
        source_state_digest.replace(':', "-")
    );

    ObjectStoreReadSmokeReport {
        status: ObjectStoreReadSmokeStatus::Succeeded,
        diagnostics: vec![],
        provider_profile: input.profile.to_string(),
        object_store_provider: input.object_store_provider,
        object_store_bucket: input.object_store_bucket,
        object_store_key: input.object_store_key,
        requested_uri: input.source.to_string(),
        local_path: Some(input.local_path),
        fixture_listing_requested: input.fixture_listing_requested,
        read_mode: input.read_mode,
        requested_range: input.requested_range,
        object_size_bytes: input.metadata.len(),
        object_mtime_millis: mtime_millis,
        bytes_read: bytes.len(),
        read_digest: source_content_digest.clone(),
        source_state_id,
        source_state_digest,
        source_content_digest,
        source_fingerprint_kind: if input.profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
            "public_no_credential_fixture_uri_metadata_range_digest"
        } else if input.requested_range.is_some() {
            "local_emulator_metadata_plus_range_digest"
        } else {
            "local_emulator_content_digest"
        },
    }
}

fn object_store_read_smoke_fields(report: &ObjectStoreReadSmokeReport) -> Vec<(String, String)> {
    let mut fields = vec![];
    push_object_store_identity_fields(&mut fields, report);
    push_object_store_read_fields(&mut fields, report);
    push_object_store_source_state_fields(&mut fields, report);
    push_object_store_policy_fields(&mut fields, report);
    push_object_store_claim_fields(&mut fields, report);
    fields
}

fn push_object_store_identity_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStoreReadSmokeReport,
) {
    let local_emulator_path = report.local_path.as_ref().map_or_else(
        || "not_applicable".to_string(),
        |path| {
            if report.provider_profile == LOCAL_EMULATOR_PROFILE {
                path.to_string_lossy().into_owned()
            } else {
                "not_applicable".to_string()
            }
        },
    );
    push_field(
        fields,
        "schema_version",
        OBJECT_STORE_READ_SMOKE_SCHEMA_VERSION,
    );
    push_field(fields, "mode", "object_store_read_smoke");
    push_field(
        fields,
        "runtime_enablement",
        read_runtime_enablement(&report.provider_profile),
    );
    push_field(fields, "provider_profile", &report.provider_profile);
    push_field(
        fields,
        "object_store_provider",
        &report.object_store_provider,
    );
    push_field(fields, "object_store_bucket", &report.object_store_bucket);
    push_field(fields, "object_store_key", &report.object_store_key);
    push_field(
        fields,
        "object_store_uri_parse_status",
        object_store_uri_parse_status(report),
    );
    push_field(
        fields,
        "requested_uri",
        &redact_object_store_uri(&report.requested_uri),
    );
    push_field(
        fields,
        "requested_uri_redaction_status",
        requested_uri_redaction_status(&report.requested_uri),
    );
    push_field(fields, "local_emulator_path", &local_emulator_path);
    push_field(
        fields,
        "public_fixture_path",
        &public_fixture_path_field(report),
    );
    push_field(fields, "object_store_read_status", report.status.as_str());
}

fn push_object_store_read_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStoreReadSmokeReport,
) {
    let has_errors = report.has_errors();
    push_field(fields, "read_mode", report.read_mode.as_str());
    push_field(
        fields,
        "byte_range_read_status",
        byte_range_read_status(report, has_errors),
    );
    push_field(
        fields,
        "full_file_read_status",
        full_file_read_status(report, has_errors),
    );
    push_field(
        fields,
        "streaming_read_status",
        streaming_read_status(report, has_errors),
    );
    push_u64_field(
        fields,
        "read_range_offset",
        report.requested_range.map_or(0, |range| range.offset),
    );
    push_u64_field(
        fields,
        "read_range_length",
        report.requested_range.map_or(0, |range| range.length),
    );
    push_count_field(fields, "bytes_read", report.bytes_read);
    push_u64_field(fields, "object_size_bytes", report.object_size_bytes);
    push_field(
        fields,
        "object_mtime_millis",
        &report
            .object_mtime_millis
            .map_or_else(|| "not_available".to_string(), |value| value.to_string()),
    );
    push_object_store_object_identity_fields(fields, report);
    push_object_store_integrity_fields(fields, report);
    push_object_store_request_evidence_fields(fields, report);
}

fn push_object_store_object_identity_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStoreReadSmokeReport,
) {
    push_field(fields, "object_etag", &object_etag(report));
    push_field(fields, "object_etag_status", object_etag_status(report));
    push_field(fields, "object_version", &object_version(report));
    push_field(
        fields,
        "object_version_status",
        object_version_status(report),
    );
}

fn push_object_store_integrity_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStoreReadSmokeReport,
) {
    push_field(fields, "read_digest", &report.read_digest);
    push_field(
        fields,
        "object_store_checksum_validation_status",
        object_store_checksum_validation_status(report),
    );
    push_field(
        fields,
        "object_store_checksum_algorithm",
        object_store_checksum_algorithm(report),
    );
    push_field(
        fields,
        "object_store_checksum_scope",
        object_store_checksum_scope(report),
    );
}

fn push_object_store_request_evidence_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStoreReadSmokeReport,
) {
    push_count_field(
        fields,
        "object_store_request_count",
        object_store_request_count(report),
    );
    push_u64_field(
        fields,
        "object_store_bytes_requested",
        object_store_bytes_requested(report),
    );
    push_count_field(fields, "object_store_bytes_read", report.bytes_read);
    push_field(
        fields,
        "object_store_bounded_read_status",
        object_store_bounded_read_status(report),
    );
    push_u64_field(
        fields,
        "object_store_bounded_read_budget_bytes",
        MAX_OBJECT_STORE_FIXTURE_BYTES,
    );
    push_field(
        fields,
        "object_store_request_coalescing_status",
        object_store_request_coalescing_status(report),
    );
    push_count_field(
        fields,
        "object_store_coalesced_request_count",
        object_store_coalesced_request_count(report),
    );
    push_field(
        fields,
        "object_store_prefetch_status",
        object_store_prefetch_status(report),
    );
    push_field(
        fields,
        "object_store_retry_policy_status",
        object_store_retry_policy_status(report),
    );
    push_count_field(
        fields,
        "object_store_retry_attempt_count",
        object_store_retry_attempt_count(report),
    );
    push_field(
        fields,
        "object_store_rate_limit_policy_status",
        object_store_rate_limit_policy_status(report),
    );
    push_count_field(fields, "object_store_cache_hit_count", 0);
    push_count_field(fields, "object_store_cache_miss_count", 0);
}

fn push_object_store_source_state_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStoreReadSmokeReport,
) {
    let has_errors = report.has_errors();
    push_field(fields, "source_state_id", &report.source_state_id);
    push_field(fields, "source_state_digest", &report.source_state_digest);
    push_field(fields, "source_format", "object_store_object");
    push_field(
        fields,
        "source_location",
        &redact_object_store_uri(&report.requested_uri),
    );
    push_field(
        fields,
        "source_fingerprint_kind",
        report.source_fingerprint_kind,
    );
    push_field(
        fields,
        "source_content_digest",
        &report.source_content_digest,
    );
    push_bool_field(fields, "row_count_known", false);
    push_count_field(fields, "file_count", usize::from(!has_errors));
    push_u64_field(fields, "byte_size", report.object_size_bytes);
    push_field(fields, "partition_columns", "");
    push_field(fields, "compression", "unknown");
}

fn push_object_store_policy_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStoreReadSmokeReport,
) {
    let has_errors = report.has_errors();
    push_object_store_provider_admission_fields(
        fields,
        &ObjectStoreProviderAdmission {
            operation: ObjectStoreAdmissionOperation::Read,
            provider_profile: &report.provider_profile,
            operation_status: report.status.as_str(),
            outcome: ObjectStoreOperationOutcome::from_errors(has_errors),
            remote_provider_request: ObjectStoreRemoteProviderRequest::from_bool(
                is_remote_object_store_uri(&report.requested_uri)
                    && report.provider_profile != PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE,
            ),
            uri_redaction_requirement: ObjectStoreUriRedactionRequirement::from_bool(
                redaction_required(&report.requested_uri),
            ),
            listing_policy: ObjectStoreListingPolicy {
                allowed: report.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE
                    && report.fixture_listing_requested
                    && !has_errors,
                status: listing_status(report),
                object_count: listing_object_count(report),
            },
            local_cache_status: local_cache_status(report),
            public_fixture_profile: ObjectStorePublicFixtureProfile::from_bool(
                report.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE,
            ),
        },
    );
}

fn push_object_store_provider_admission_fields(
    fields: &mut Vec<(String, String)>,
    admission: &ObjectStoreProviderAdmission<'_>,
) {
    push_field(
        fields,
        "provider_admission_report_id",
        "shardloom.object_store_provider_admission.v1",
    );
    push_field(
        fields,
        "provider_admission_operation",
        admission.operation.as_str(),
    );
    push_field(
        fields,
        "provider_profile_status",
        admission.provider_profile_status(),
    );
    push_field(
        fields,
        "provider_admission_status",
        admission.provider_admission_status(),
    );
    push_field(
        fields,
        "provider_admission_classification",
        admission.provider_admission_classification(),
    );
    push_field(
        fields,
        "provider_admission_boundary",
        admission.provider_admission_boundary(),
    );
    push_field(
        fields,
        "provider_operation_status",
        admission.operation_status,
    );
    push_field(
        fields,
        "credential_policy_status",
        admission.credential_policy_status(),
    );
    push_field(
        fields,
        "network_effect_status",
        admission.network_effect_status(),
    );
    push_bool_field(fields, "credential_resolution_allowed", false);
    push_bool_field(fields, "credential_resolution_performed", false);
    push_bool_field(fields, "network_probe_allowed", false);
    push_bool_field(fields, "network_probe_performed", false);
    push_bool_field(fields, "provider_probe_allowed", false);
    push_bool_field(fields, "provider_probe_performed", false);
    push_bool_field(fields, "request_signing_allowed", false);
    push_bool_field(fields, "request_signing_performed", false);
    push_field(
        fields,
        "request_signing_status",
        admission.request_signing_status(),
    );
    push_field(
        fields,
        "request_signing_boundary",
        admission.request_signing_boundary(),
    );
    push_field(
        fields,
        "uri_redaction_policy_status",
        admission.uri_redaction_policy_status(),
    );
    push_field(
        fields,
        "explain_estimate_doctor_probe_policy",
        "static_no_provider_probe_default",
    );
    push_field(
        fields,
        "capability_discovery_probe_policy",
        "static_capability_report_no_provider_probe",
    );
    push_bool_field(fields, "listing_allowed", admission.listing_policy.allowed);
    push_field(fields, "listing_status", admission.listing_policy.status);
    push_count_field(
        fields,
        "listing_object_count",
        admission.listing_policy.object_count,
    );
    push_bool_field(fields, "cache_write_allowed", false);
    push_field(fields, "local_cache_status", admission.local_cache_status);
    push_bool_field(
        fields,
        "public_no_credential_fixture_profile",
        admission.public_fixture_profile.enabled(),
    );
    push_bool_field(fields, "live_provider_network_read_allowed", false);
    push_bool_field(fields, "live_provider_network_write_allowed", false);
}

fn push_object_store_claim_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStoreReadSmokeReport,
) {
    let has_errors = report.has_errors();
    push_field(
        fields,
        "native_io_certificate_id",
        native_io_certificate_id(&report.provider_profile),
    );
    push_field(
        fields,
        "native_io_certificate_status",
        read_certificate_status(report),
    );
    push_field(fields, "claim_gate_status", read_claim_gate_status(report));
    push_field(
        fields,
        "object_store_read_claim_gate_status",
        read_claim_gate_status(report),
    );
    push_field(
        fields,
        "claim_boundary",
        read_claim_boundary(&report.provider_profile),
    );
    push_bool_field(fields, "object_store_runtime_supported", !has_errors);
    push_bool_field(
        fields,
        "public_no_credential_fixture_claim_allowed",
        !has_errors && report.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE,
    );
    push_bool_field(fields, "public_object_store_claim_allowed", false);
    push_bool_field(fields, "production_object_store_claim_allowed", false);
    push_bool_field(fields, "object_store_io", !has_errors);
    push_bool_field(fields, "object_store_read_io", !has_errors);
    push_bool_field(fields, "object_store_write_io", false);
    push_bool_field(fields, "write_io", false);
    push_bool_field(fields, "data_read", !has_errors);
    push_bool_field(fields, "fallback_attempted", false);
    push_bool_field(fields, "fallback_execution_allowed", false);
    push_bool_field(fields, "external_engine_invoked", false);
    push_field(
        fields,
        "execution",
        if has_errors { "blocked" } else { "performed" },
    );
    push_bool_field(fields, "plan_only", false);
}

fn object_store_write_smoke_fields(report: &ObjectStoreWriteSmokeReport) -> Vec<(String, String)> {
    let mut fields = vec![];
    push_object_store_write_identity_fields(&mut fields, report);
    push_object_store_write_commit_fields(&mut fields, report);
    push_object_store_write_policy_fields(&mut fields, report);
    push_object_store_write_claim_fields(&mut fields, report);
    fields
}

fn object_store_write_recovery_smoke_fields(
    report: &ObjectStoreWriteRecoveryReport,
) -> Vec<(String, String)> {
    let mut fields = vec![];
    push_object_store_write_recovery_identity_fields(&mut fields, report);
    push_object_store_write_recovery_replay_fields(&mut fields, report);
    push_object_store_write_recovery_digest_fields(&mut fields, report);
    push_object_store_write_recovery_policy_fields(&mut fields, report);
    push_object_store_write_recovery_claim_fields(&mut fields, report);
    fields
}

fn push_object_store_write_identity_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStoreWriteSmokeReport,
) {
    push_field(
        fields,
        "schema_version",
        OBJECT_STORE_WRITE_SMOKE_SCHEMA_VERSION,
    );
    push_field(fields, "mode", "object_store_write_smoke");
    push_field(
        fields,
        "runtime_enablement",
        "local_emulator_object_store_write_commit",
    );
    push_field(fields, "provider_profile", &report.provider_profile);
    push_field(fields, "object_store_provider", "local_emulator");
    push_field(
        fields,
        "source_uri",
        &redact_object_store_uri(&report.source_uri),
    );
    push_field(
        fields,
        "target_uri",
        &redact_object_store_uri(&report.target_uri),
    );
    push_field(
        fields,
        "source_uri_redaction_status",
        requested_uri_redaction_status(&report.source_uri),
    );
    push_field(
        fields,
        "target_uri_redaction_status",
        requested_uri_redaction_status(&report.target_uri),
    );
    push_field(
        fields,
        "local_source_path",
        &path_field(report.source_path.as_deref()),
    );
    push_field(
        fields,
        "local_emulator_target_path",
        &path_field(report.target_path.as_deref()),
    );
    push_field(fields, "object_store_write_status", report.status.as_str());
}

fn push_object_store_write_commit_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStoreWriteSmokeReport,
) {
    let has_errors = report.has_errors();
    push_field(fields, "write_mode", "single_object_staged_commit");
    push_field(
        fields,
        "write_staging_status",
        write_staging_status(report.status),
    );
    push_field(fields, "commit_protocol", "local_emulator_sidecar_manifest");
    push_field(
        fields,
        "commit_protocol_status",
        commit_protocol_status(report.status),
    );
    push_field(fields, "commit_status", commit_status(report.status));
    push_field(
        fields,
        "rollback_status",
        rollback_status(report.status, report.rollback_after_commit),
    );
    push_field(
        fields,
        "cleanup_status",
        cleanup_status(report.status, report.rollback_after_commit),
    );
    push_count_field(
        fields,
        "cleanup_deleted_count",
        report.cleanup_deleted_count,
    );
    push_field(fields, "idempotency_key", &report.idempotency_key);
    push_field(fields, "idempotency_status", report.idempotency_status);
    push_bool_field(fields, "allow_overwrite", report.allow_overwrite);
    push_bool_field(fields, "rollback_requested", report.rollback_after_commit);
    push_field(
        fields,
        "staged_object_path",
        &path_field(report.staging_path.as_deref()),
    );
    push_field(
        fields,
        "committed_object_path",
        &path_field(report.target_path.as_deref()),
    );
    push_field(
        fields,
        "committed_manifest_path",
        &path_field(report.commit_manifest_path.as_deref()),
    );
    push_bool_field(fields, "commit_manifest_written", !has_errors);
    push_bool_field(
        fields,
        "commit_manifest_present",
        matches!(report.status, ObjectStoreWriteSmokeStatus::Committed),
    );
    push_bool_field(
        fields,
        "target_exists_after_commit",
        matches!(report.status, ObjectStoreWriteSmokeStatus::Committed),
    );
    push_count_field(fields, "payload_bytes", report.payload_bytes);
    push_count_field(fields, "written_bytes", report.written_bytes);
    push_field(fields, "payload_digest", &report.payload_digest);
    push_field(
        fields,
        "target_content_digest",
        &report.target_content_digest,
    );
    push_field(
        fields,
        "commit_manifest_digest",
        &report.commit_manifest_digest,
    );
    push_object_store_write_native_io_evidence_fields(fields, report);
}

fn push_object_store_write_native_io_evidence_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStoreWriteSmokeReport,
) {
    push_count_field(
        fields,
        "object_store_write_request_count",
        object_store_write_request_count(report),
    );
    push_count_field(
        fields,
        "object_store_commit_manifest_write_request_count",
        object_store_commit_manifest_write_request_count(report),
    );
    push_count_field(
        fields,
        "object_store_payload_bytes_written",
        report.written_bytes,
    );
    push_count_field(
        fields,
        "object_store_commit_manifest_bytes_written",
        report.commit_manifest_bytes,
    );
    push_count_field(
        fields,
        "object_store_total_bytes_written",
        object_store_total_bytes_written(report),
    );
    push_field(
        fields,
        "object_store_write_bounded_status",
        object_store_write_bounded_status(report),
    );
    push_field(
        fields,
        "object_store_multipart_write_status",
        object_store_multipart_write_status(report),
    );
    push_count_field(fields, "object_store_multipart_part_count", 0);
    push_field(
        fields,
        "object_store_write_retry_policy_status",
        object_store_write_retry_policy_status(report),
    );
    push_count_field(fields, "object_store_write_retry_attempt_count", 0);
    push_field(
        fields,
        "object_store_write_rate_limit_policy_status",
        object_store_write_rate_limit_policy_status(report),
    );
    push_count_field(
        fields,
        "object_store_rollback_cleanup_request_count",
        report.cleanup_deleted_count,
    );
    push_field(
        fields,
        "object_store_ambiguous_commit_status",
        object_store_ambiguous_commit_status(report),
    );
    push_field(
        fields,
        "object_store_idempotency_scope",
        object_store_idempotency_scope(report),
    );
    push_count_field(fields, "object_store_write_cache_hit_count", 0);
    push_count_field(fields, "object_store_write_cache_miss_count", 0);
}

fn push_object_store_write_policy_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStoreWriteSmokeReport,
) {
    let has_errors = report.has_errors();
    push_object_store_provider_admission_fields(
        fields,
        &ObjectStoreProviderAdmission {
            operation: ObjectStoreAdmissionOperation::Write,
            provider_profile: &report.provider_profile,
            operation_status: report.status.as_str(),
            outcome: ObjectStoreOperationOutcome::from_errors(has_errors),
            remote_provider_request: ObjectStoreRemoteProviderRequest::from_bool(
                is_remote_object_store_uri(&report.source_uri)
                    || is_remote_object_store_uri(&report.target_uri),
            ),
            uri_redaction_requirement: ObjectStoreUriRedactionRequirement::from_bool(
                redaction_required(&report.source_uri) || redaction_required(&report.target_uri),
            ),
            listing_policy: ObjectStoreListingPolicy {
                allowed: false,
                status: "not_performed_local_emulator_single_object",
                object_count: 0,
            },
            local_cache_status: "not_performed",
            public_fixture_profile: ObjectStorePublicFixtureProfile::No,
        },
    );
    push_bool_field(fields, "remote_write_allowed", false);
    push_bool_field(fields, "local_emulator_write_allowed", !has_errors);
    push_bool_field(fields, "write_staging_allowed", !has_errors);
}

fn push_object_store_write_claim_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStoreWriteSmokeReport,
) {
    let has_errors = report.has_errors();
    push_field(
        fields,
        "native_io_certificate_id",
        "gar-runtime-impl-4o.local_emulator_object_store_write.native_io",
    );
    push_field(
        fields,
        "native_io_certificate_status",
        if has_errors {
            "blocked"
        } else {
            "fixture_smoke_only"
        },
    );
    push_field(
        fields,
        "claim_gate_status",
        if has_errors {
            "not_claim_grade"
        } else {
            "fixture_smoke_only"
        },
    );
    push_field(
        fields,
        "claim_boundary",
        "local-emulator staged object write/commit smoke only; no S3/GCS/ADLS, credential, network, production, table/lakehouse commit, distributed, performance, or Spark-replacement claim",
    );
    push_bool_field(fields, "object_store_runtime_supported", !has_errors);
    push_bool_field(fields, "object_store_write_runtime_supported", !has_errors);
    push_bool_field(fields, "public_object_store_claim_allowed", false);
    push_bool_field(fields, "production_object_store_claim_allowed", false);
    push_bool_field(fields, "table_runtime_supported", false);
    push_bool_field(fields, "table_commit_allowed", false);
    push_bool_field(fields, "object_store_io", !has_errors);
    push_bool_field(fields, "object_store_read_io", false);
    push_bool_field(fields, "object_store_write_io", !has_errors);
    push_bool_field(fields, "write_io", !has_errors);
    push_bool_field(fields, "data_read", !has_errors);
    push_bool_field(fields, "source_io_performed", !has_errors);
    push_bool_field(fields, "table_metadata_read_performed", false);
    push_bool_field(fields, "table_commit_performed", false);
    push_bool_field(fields, "fallback_attempted", false);
    push_bool_field(fields, "fallback_execution_allowed", false);
    push_bool_field(fields, "external_engine_invoked", false);
    push_field(
        fields,
        "execution",
        if has_errors { "blocked" } else { "performed" },
    );
    push_bool_field(fields, "plan_only", false);
}

fn push_object_store_write_recovery_identity_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStoreWriteRecoveryReport,
) {
    push_field(
        fields,
        "schema_version",
        OBJECT_STORE_WRITE_RECOVERY_SMOKE_SCHEMA_VERSION,
    );
    push_field(fields, "mode", "object_store_write_recovery_smoke");
    push_field(
        fields,
        "runtime_enablement",
        "local_emulator_object_store_write_recovery_replay",
    );
    push_field(
        fields,
        "report_id",
        "gar-runtime-impl-6d.object_store_write_recovery_smoke",
    );
    push_field(fields, "provider_profile", &report.provider_profile);
    push_field(fields, "object_store_provider", "local_emulator");
    push_field(
        fields,
        "target_uri",
        &redact_object_store_uri(&report.target_uri),
    );
    push_field(
        fields,
        "target_uri_redaction_status",
        requested_uri_redaction_status(&report.target_uri),
    );
    push_field(
        fields,
        "local_emulator_target_path",
        &path_field(report.target_path.as_deref()),
    );
    push_field(
        fields,
        "committed_manifest_path",
        &path_field(report.commit_manifest_path.as_deref()),
    );
    push_field(
        fields,
        "object_store_write_recovery_status",
        report.status.as_str(),
    );
}

fn push_object_store_write_recovery_replay_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStoreWriteRecoveryReport,
) {
    let has_errors = report.has_errors();
    push_field(
        fields,
        "recovery_replay_status",
        if has_errors {
            "blocked"
        } else {
            "recovered_local_emulator_sidecar"
        },
    );
    push_field(
        fields,
        "commit_manifest_replay_status",
        if has_errors {
            "blocked"
        } else {
            "recovered_local_emulator_sidecar"
        },
    );
    push_bool_field(fields, "recovery_replay_performed", !has_errors);
    push_bool_field(fields, "committed_object_read_performed", !has_errors);
    push_bool_field(fields, "commit_manifest_read_performed", !has_errors);
}

fn push_object_store_write_recovery_digest_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStoreWriteRecoveryReport,
) {
    push_bool_field(
        fields,
        "target_digest_matched",
        report.target_digest_matched,
    );
    push_bool_field(
        fields,
        "payload_digest_matched",
        report.payload_digest_matched,
    );
    push_bool_field(
        fields,
        "payload_bytes_matched",
        report.payload_bytes_matched,
    );
    push_bool_field(fields, "target_path_matched", report.target_path_matched);
    push_bool_field(
        fields,
        "commit_manifest_shape_matched",
        report.manifest_shape_matched,
    );
    push_field(
        fields,
        "expected_idempotency_key",
        report
            .expected_idempotency_key
            .as_deref()
            .unwrap_or("not_requested"),
    );
    push_field(
        fields,
        "recovered_idempotency_key",
        &report.recovered_idempotency_key,
    );
    push_field(fields, "idempotency_status", report.idempotency_status);
    push_count_field(fields, "object_bytes", report.object_bytes);
    push_count_field(
        fields,
        "recorded_payload_bytes",
        report.recorded_payload_bytes,
    );
    push_field(fields, "object_digest", &report.object_digest);
    push_field(
        fields,
        "recorded_payload_digest",
        &report.recorded_payload_digest,
    );
    push_field(
        fields,
        "recorded_target_content_digest",
        &report.recorded_target_content_digest,
    );
    push_field(
        fields,
        "commit_manifest_digest",
        &report.commit_manifest_digest,
    );
    push_object_store_write_recovery_native_io_evidence_fields(fields, report);
}

fn push_object_store_write_recovery_native_io_evidence_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStoreWriteRecoveryReport,
) {
    push_count_field(
        fields,
        "object_store_recovery_read_request_count",
        object_store_recovery_read_request_count(report),
    );
    push_count_field(
        fields,
        "object_store_recovery_object_bytes_read",
        report.object_bytes,
    );
    push_count_field(
        fields,
        "object_store_recovery_manifest_bytes_read",
        report.commit_manifest_bytes,
    );
    push_count_field(
        fields,
        "object_store_recovery_total_bytes_read",
        report.object_bytes + report.commit_manifest_bytes,
    );
    push_field(
        fields,
        "object_store_recovery_retry_policy_status",
        object_store_recovery_retry_policy_status(report),
    );
    push_count_field(fields, "object_store_recovery_retry_attempt_count", 0);
    push_field(
        fields,
        "object_store_recovery_rate_limit_policy_status",
        object_store_recovery_rate_limit_policy_status(report),
    );
    push_field(
        fields,
        "object_store_recovery_ambiguous_commit_status",
        object_store_recovery_ambiguous_commit_status(report),
    );
}

fn push_object_store_write_recovery_policy_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStoreWriteRecoveryReport,
) {
    let has_errors = report.has_errors();
    push_object_store_provider_admission_fields(
        fields,
        &ObjectStoreProviderAdmission {
            operation: ObjectStoreAdmissionOperation::WriteRecovery,
            provider_profile: &report.provider_profile,
            operation_status: report.status.as_str(),
            outcome: ObjectStoreOperationOutcome::from_errors(has_errors),
            remote_provider_request: ObjectStoreRemoteProviderRequest::from_bool(
                is_remote_object_store_uri(&report.target_uri),
            ),
            uri_redaction_requirement: ObjectStoreUriRedactionRequirement::from_bool(
                redaction_required(&report.target_uri),
            ),
            listing_policy: ObjectStoreListingPolicy {
                allowed: false,
                status: "not_performed_local_emulator_single_object_recovery",
                object_count: 0,
            },
            local_cache_status: "not_performed",
            public_fixture_profile: ObjectStorePublicFixtureProfile::No,
        },
    );
    push_bool_field(fields, "remote_recovery_allowed", false);
    push_bool_field(fields, "local_emulator_recovery_allowed", !has_errors);
    push_bool_field(fields, "write_staging_allowed", false);
}

fn push_object_store_write_recovery_claim_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStoreWriteRecoveryReport,
) {
    let has_errors = report.has_errors();
    push_field(
        fields,
        "native_io_certificate_id",
        "gar-runtime-impl-6d.local_emulator_object_store_write_recovery.native_io",
    );
    push_field(
        fields,
        "native_io_certificate_status",
        if has_errors {
            "blocked"
        } else {
            "fixture_smoke_only"
        },
    );
    push_field(
        fields,
        "claim_gate_status",
        if has_errors {
            "not_claim_grade"
        } else {
            "fixture_smoke_only"
        },
    );
    push_field(
        fields,
        "claim_boundary",
        "local-emulator staged object write recovery proof only; no S3/GCS/ADLS, credential, network, production, table/lakehouse commit, remote result delivery, distributed, performance, or Spark-replacement claim",
    );
    push_bool_field(fields, "object_store_runtime_supported", !has_errors);
    push_bool_field(
        fields,
        "object_store_write_recovery_runtime_supported",
        !has_errors,
    );
    push_bool_field(
        fields,
        "local_emulator_write_recovery_runtime_supported",
        !has_errors,
    );
    push_bool_field(
        fields,
        "live_provider_write_recovery_runtime_supported",
        false,
    );
    push_bool_field(fields, "remote_result_delivery_supported", false);
    push_bool_field(fields, "public_object_store_claim_allowed", false);
    push_bool_field(fields, "production_object_store_claim_allowed", false);
    push_bool_field(fields, "table_runtime_supported", false);
    push_bool_field(fields, "table_commit_allowed", false);
    push_bool_field(fields, "object_store_io", !has_errors);
    push_bool_field(fields, "object_store_read_io", !has_errors);
    push_bool_field(fields, "object_store_write_io", false);
    push_bool_field(fields, "write_io", false);
    push_bool_field(fields, "data_read", !has_errors);
    push_bool_field(fields, "source_io_performed", false);
    push_bool_field(fields, "table_metadata_read_performed", false);
    push_bool_field(fields, "table_commit_performed", false);
    push_bool_field(fields, "fallback_attempted", false);
    push_bool_field(fields, "fallback_execution_allowed", false);
    push_bool_field(fields, "external_engine_invoked", false);
    push_field(
        fields,
        "execution",
        if has_errors { "blocked" } else { "performed" },
    );
    push_bool_field(fields, "plan_only", false);
}

fn object_store_partition_discovery_smoke_fields(
    report: &ObjectStorePartitionDiscoveryReport,
) -> Vec<(String, String)> {
    let mut fields = vec![];
    push_partition_discovery_identity_fields(&mut fields, report);
    push_partition_discovery_listing_fields(&mut fields, report);
    push_partition_discovery_policy_fields(&mut fields, report);
    push_partition_discovery_claim_fields(&mut fields, report);
    fields
}

fn push_partition_discovery_identity_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStorePartitionDiscoveryReport,
) {
    let has_errors = report.has_errors();
    push_field(
        fields,
        "schema_version",
        OBJECT_STORE_PARTITION_DISCOVERY_SMOKE_SCHEMA_VERSION,
    );
    push_field(fields, "mode", "object_store_partition_discovery_smoke");
    push_field(
        fields,
        "runtime_enablement",
        "local_emulator_partition_discovery",
    );
    push_field(fields, "provider_profile", &report.provider_profile);
    push_field(fields, "object_store_provider", "local_emulator");
    push_field(
        fields,
        "requested_uri",
        &redact_object_store_uri(&report.requested_uri),
    );
    push_field(
        fields,
        "local_partition_root_path",
        &path_field(report.root_path.as_deref()),
    );
    push_field(fields, "partition_discovery_status", report.status.as_str());
    push_field(
        fields,
        "partition_listing_status",
        if has_errors {
            "blocked"
        } else {
            "performed_local_emulator"
        },
    );
}

fn push_partition_discovery_listing_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStorePartitionDiscoveryReport,
) {
    push_count_field(
        fields,
        "partition_directory_count",
        report.partition_directory_count,
    );
    push_count_field(
        fields,
        "listing_directory_count",
        report.listing_directory_count,
    );
    push_count_field(
        fields,
        "partition_key_count",
        report.discovered_partition_columns.len(),
    );
    push_count_field(
        fields,
        "partition_value_count",
        report.discovered_partition_values.len(),
    );
    push_count_field(fields, "max_partition_depth", report.max_partition_depth);
    push_field(
        fields,
        "requested_partition_columns",
        &joined_or_none(&report.requested_partition_columns),
    );
    push_field(
        fields,
        "discovered_partition_columns",
        &joined_or_none(&report.discovered_partition_columns),
    );
    push_field(
        fields,
        "discovered_partition_values",
        &joined_or_none(&report.discovered_partition_values),
    );
}

fn push_partition_discovery_policy_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStorePartitionDiscoveryReport,
) {
    let has_errors = report.has_errors();
    push_object_store_provider_admission_fields(
        fields,
        &ObjectStoreProviderAdmission {
            operation: ObjectStoreAdmissionOperation::PartitionDiscovery,
            provider_profile: &report.provider_profile,
            operation_status: report.status.as_str(),
            outcome: ObjectStoreOperationOutcome::from_errors(has_errors),
            remote_provider_request: ObjectStoreRemoteProviderRequest::from_bool(
                is_remote_object_store_uri(&report.requested_uri),
            ),
            uri_redaction_requirement: ObjectStoreUriRedactionRequirement::from_bool(
                redaction_required(&report.requested_uri),
            ),
            listing_policy: ObjectStoreListingPolicy {
                allowed: !has_errors,
                status: if has_errors {
                    "blocked"
                } else {
                    "performed_local_emulator_partition_listing"
                },
                object_count: report.partition_directory_count,
            },
            local_cache_status: "not_performed",
            public_fixture_profile: ObjectStorePublicFixtureProfile::No,
        },
    );
    push_field(
        fields,
        "native_io_certificate_id",
        "gar-runtime-impl-6d.local_emulator_partition_discovery.native_io",
    );
    push_field(
        fields,
        "native_io_certificate_status",
        if has_errors {
            "blocked"
        } else {
            "fixture_smoke_only"
        },
    );
}

fn push_partition_discovery_claim_fields(
    fields: &mut Vec<(String, String)>,
    report: &ObjectStorePartitionDiscoveryReport,
) {
    let has_errors = report.has_errors();
    push_field(
        fields,
        "claim_gate_status",
        if has_errors {
            "not_claim_grade"
        } else {
            "fixture_smoke_only"
        },
    );
    push_field(
        fields,
        "claim_boundary",
        "local-emulator partition discovery over caller-owned key=value directories only; no live S3/GCS/ADLS listing, credential resolution, catalog integration, table commit, remote result delivery, production, performance, or Spark-replacement claim",
    );
    push_bool_field(fields, "object_store_runtime_supported", !has_errors);
    push_bool_field(fields, "partition_discovery_runtime_supported", !has_errors);
    push_bool_field(fields, "live_provider_partition_discovery_supported", false);
    push_bool_field(fields, "catalog_integration_supported", false);
    push_bool_field(fields, "remote_result_delivery_supported", false);
    push_bool_field(fields, "object_store_io", !has_errors);
    push_bool_field(fields, "object_store_listing_io", !has_errors);
    push_bool_field(fields, "object_store_read_io", false);
    push_bool_field(fields, "object_store_write_io", false);
    push_bool_field(fields, "write_io", false);
    push_bool_field(fields, "data_read", false);
    push_bool_field(fields, "source_io_performed", false);
    push_bool_field(fields, "table_metadata_read_performed", false);
    push_bool_field(fields, "table_commit_performed", false);
    push_bool_field(fields, "credential_resolution_performed", false);
    push_bool_field(fields, "network_probe_performed", false);
    push_bool_field(fields, "provider_probe_performed", false);
    push_bool_field(fields, "fallback_attempted", false);
    push_bool_field(fields, "fallback_execution_allowed", false);
    push_bool_field(fields, "external_engine_invoked", false);
    push_field(
        fields,
        "execution",
        if has_errors { "blocked" } else { "performed" },
    );
    push_bool_field(fields, "plan_only", false);
}

fn write_staging_status(status: ObjectStoreWriteSmokeStatus) -> &'static str {
    if status.is_error() {
        "blocked"
    } else {
        "performed_local_emulator"
    }
}

fn commit_protocol_status(status: ObjectStoreWriteSmokeStatus) -> &'static str {
    match status {
        ObjectStoreWriteSmokeStatus::Committed => "committed",
        ObjectStoreWriteSmokeStatus::RolledBack => "rolled_back",
        _ => "blocked",
    }
}

fn commit_status(status: ObjectStoreWriteSmokeStatus) -> &'static str {
    match status {
        ObjectStoreWriteSmokeStatus::Committed => "committed_local_emulator_object",
        ObjectStoreWriteSmokeStatus::RolledBack => "committed_then_rolled_back",
        _ => "blocked",
    }
}

fn rollback_status(
    status: ObjectStoreWriteSmokeStatus,
    rollback_after_commit: bool,
) -> &'static str {
    match (status, rollback_after_commit) {
        (ObjectStoreWriteSmokeStatus::RolledBack, true) => "performed_local_emulator_cleanup",
        (_, true) if status.is_error() => "blocked",
        _ => "not_requested",
    }
}

fn cleanup_status(
    status: ObjectStoreWriteSmokeStatus,
    rollback_after_commit: bool,
) -> &'static str {
    match (status, rollback_after_commit) {
        (ObjectStoreWriteSmokeStatus::Committed, _) => "staging_object_removed",
        (ObjectStoreWriteSmokeStatus::RolledBack, true) => "rollback_cleanup_performed",
        _ => "not_performed_blocked",
    }
}

fn object_store_write_request_count(report: &ObjectStoreWriteSmokeReport) -> usize {
    if report.has_errors() { 0 } else { 2 }
}

fn object_store_commit_manifest_write_request_count(report: &ObjectStoreWriteSmokeReport) -> usize {
    usize::from(!report.has_errors())
}

fn object_store_total_bytes_written(report: &ObjectStoreWriteSmokeReport) -> usize {
    report
        .written_bytes
        .saturating_add(report.commit_manifest_bytes)
}

fn object_store_write_bounded_status(report: &ObjectStoreWriteSmokeReport) -> &'static str {
    if report.has_errors() {
        "not_performed_blocked"
    } else {
        "bounded_payload_and_manifest_under_fixture_budget"
    }
}

fn object_store_multipart_write_status(report: &ObjectStoreWriteSmokeReport) -> &'static str {
    if report.has_errors() {
        "not_performed_blocked"
    } else {
        "not_required_single_object_local_emulator_commit"
    }
}

fn object_store_write_retry_policy_status(report: &ObjectStoreWriteSmokeReport) -> &'static str {
    if report.has_errors() {
        "blocked_before_retry"
    } else {
        "not_required_single_attempt_local_emulator_commit"
    }
}

fn object_store_write_rate_limit_policy_status(
    report: &ObjectStoreWriteSmokeReport,
) -> &'static str {
    if report.has_errors() {
        "blocked_before_rate_limit_policy"
    } else {
        "not_required_local_emulator_no_network"
    }
}

fn object_store_ambiguous_commit_status(report: &ObjectStoreWriteSmokeReport) -> &'static str {
    match report.status {
        ObjectStoreWriteSmokeStatus::Committed => "not_observed_local_commit_manifest_written",
        ObjectStoreWriteSmokeStatus::RolledBack => "rollback_cleanup_completed",
        _ => "blocked_before_commit_claim",
    }
}

fn object_store_idempotency_scope(report: &ObjectStoreWriteSmokeReport) -> &'static str {
    if report.has_errors() {
        "not_emitted_blocked"
    } else {
        "single_object_target_payload_digest"
    }
}

fn object_store_recovery_read_request_count(report: &ObjectStoreWriteRecoveryReport) -> usize {
    if report.object_bytes > 0 || report.commit_manifest_bytes > 0 {
        2
    } else {
        0
    }
}

fn object_store_recovery_retry_policy_status(
    report: &ObjectStoreWriteRecoveryReport,
) -> &'static str {
    match report.status {
        ObjectStoreWriteRecoveryStatus::Recovered => {
            "not_required_single_attempt_local_emulator_recovery"
        }
        ObjectStoreWriteRecoveryStatus::BlockedRecoveryMismatch => {
            "not_retried_recovery_evidence_mismatch"
        }
        _ => "blocked_before_retry",
    }
}

fn object_store_recovery_rate_limit_policy_status(
    report: &ObjectStoreWriteRecoveryReport,
) -> &'static str {
    match report.status {
        ObjectStoreWriteRecoveryStatus::Recovered
        | ObjectStoreWriteRecoveryStatus::BlockedRecoveryMismatch => {
            "not_required_local_emulator_no_network"
        }
        _ => "blocked_before_rate_limit_policy",
    }
}

fn object_store_recovery_ambiguous_commit_status(
    report: &ObjectStoreWriteRecoveryReport,
) -> &'static str {
    match report.status {
        ObjectStoreWriteRecoveryStatus::Recovered => "replay_matched_sidecar_manifest",
        ObjectStoreWriteRecoveryStatus::BlockedRecoveryMismatch => "blocked_recovery_mismatch",
        _ => "blocked_before_recovery_replay",
    }
}

fn path_field(path: Option<&Path>) -> String {
    path.map_or_else(
        || "not_applicable".to_string(),
        |path| path.to_string_lossy().into_owned(),
    )
}

fn byte_range_read_status(report: &ObjectStoreReadSmokeReport, has_errors: bool) -> &'static str {
    if report.read_mode == ReadMode::ByteRange && !has_errors {
        if report.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
            "performed_public_no_credential_fixture"
        } else {
            "performed_local_emulator"
        }
    } else if report.read_mode == ReadMode::ByteRange {
        "blocked"
    } else {
        "not_requested"
    }
}

fn full_file_read_status(report: &ObjectStoreReadSmokeReport, has_errors: bool) -> &'static str {
    if report.read_mode == ReadMode::FullFile && !has_errors {
        if report.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
            "performed_public_no_credential_fixture"
        } else {
            "performed_local_emulator"
        }
    } else if report.read_mode == ReadMode::FullFile {
        "blocked"
    } else {
        "not_requested"
    }
}

fn streaming_read_status(report: &ObjectStoreReadSmokeReport, has_errors: bool) -> &'static str {
    if report.read_mode == ReadMode::FullFile && !has_errors {
        if report.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
            "performed_public_fixture_full_file_stream"
        } else {
            "performed_local_emulator_full_file_stream"
        }
    } else {
        "not_performed"
    }
}

fn object_store_read_summary(profile: &str) -> &'static str {
    if profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
        "object-store public fixture read smoke"
    } else {
        "object-store local-emulator read smoke"
    }
}

fn read_runtime_enablement(profile: &str) -> &'static str {
    if profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
        "public_no_credential_fixture_object_store_read"
    } else {
        "local_emulator_object_store_read"
    }
}

fn object_store_uri_parse_status(report: &ObjectStoreReadSmokeReport) -> &'static str {
    if report.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE && !report.has_errors() {
        "parsed_public_no_credential_fixture_uri"
    } else if report.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
        "blocked_public_no_credential_fixture_uri"
    } else {
        "not_requested_local_emulator"
    }
}

fn listing_status(report: &ObjectStoreReadSmokeReport) -> &'static str {
    if report.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE
        && report.fixture_listing_requested
        && !report.has_errors()
    {
        "performed_public_fixture_single_object"
    } else if report.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
        "not_requested_public_fixture"
    } else {
        "not_performed_local_emulator_single_object"
    }
}

fn listing_object_count(report: &ObjectStoreReadSmokeReport) -> usize {
    usize::from(
        report.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE
            && report.fixture_listing_requested
            && !report.has_errors(),
    )
}

fn local_cache_status(report: &ObjectStoreReadSmokeReport) -> &'static str {
    if report.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
        "not_performed_public_fixture_read_through"
    } else {
        "not_performed"
    }
}

fn native_io_certificate_id(profile: &str) -> &'static str {
    if profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
        "gar-runtime-impl-5k.public_no_credential_fixture_read.native_io"
    } else {
        "gar-runtime-impl-4n.local_emulator_object_store_read.native_io"
    }
}

fn read_certificate_status(report: &ObjectStoreReadSmokeReport) -> &'static str {
    if report.has_errors() {
        "blocked"
    } else if report.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
        "public_fixture_smoke_only"
    } else {
        "fixture_smoke_only"
    }
}

fn read_claim_gate_status(report: &ObjectStoreReadSmokeReport) -> &'static str {
    if report.has_errors() {
        "not_claim_grade"
    } else if report.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
        "public_fixture_smoke_only"
    } else {
        "fixture_smoke_only"
    }
}

fn read_claim_boundary(profile: &str) -> &'static str {
    if profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
        "public no-credential object-store fixture read smoke only; URI parsing, SourceState, byte-range/full-file fixture bytes, optional fixture listing, Native I/O evidence, and no-fallback fields are admitted without credentials or network probes; live S3/GCS/ADLS provider reads, authenticated reads, cache writes, cloud writes, table commits, distributed runtime, production use, performance, and Spark-replacement claims remain blocked"
    } else {
        "local-emulator object-store read smoke only; no S3/GCS/ADLS, credential, network, production, table, commit, distributed, performance, or Spark-replacement claim"
    }
}

fn public_fixture_path_field(report: &ObjectStoreReadSmokeReport) -> String {
    if report.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
        path_field(report.local_path.as_deref())
    } else {
        "not_applicable".to_string()
    }
}

fn object_etag(report: &ObjectStoreReadSmokeReport) -> String {
    if report.has_errors() {
        "not_emitted_no_object_read".to_string()
    } else if report.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
        format!("public-fixture-{}", report.read_digest.replace(':', "-"))
    } else {
        format!(
            "local-emulator-fingerprint-{}",
            report.source_state_digest.replace(':', "-")
        )
    }
}

fn object_etag_status(report: &ObjectStoreReadSmokeReport) -> &'static str {
    if report.has_errors() {
        "not_emitted_no_object_read"
    } else if report.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
        "derived_public_fixture_read_digest"
    } else {
        "derived_local_emulator_metadata_range_fingerprint"
    }
}

fn object_version(report: &ObjectStoreReadSmokeReport) -> String {
    if report.has_errors() {
        "not_emitted_no_object_read".to_string()
    } else if report.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
        format!(
            "public-fixture-mtime-{}",
            report.object_mtime_millis.unwrap_or_default()
        )
    } else {
        format!(
            "local-emulator-mtime-{}",
            report.object_mtime_millis.unwrap_or_default()
        )
    }
}

fn object_version_status(report: &ObjectStoreReadSmokeReport) -> &'static str {
    if report.has_errors() {
        "not_emitted_no_object_read"
    } else if report.object_mtime_millis.is_none() {
        "object_mtime_not_available"
    } else if report.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
        "derived_public_fixture_mtime"
    } else {
        "derived_local_emulator_mtime"
    }
}

fn object_store_checksum_validation_status(report: &ObjectStoreReadSmokeReport) -> &'static str {
    if report.has_errors() {
        "not_emitted_no_object_read"
    } else {
        "validated_requested_bytes_digest"
    }
}

fn object_store_checksum_algorithm(report: &ObjectStoreReadSmokeReport) -> &'static str {
    if report.has_errors() {
        "not_emitted_no_object_read"
    } else {
        "fnv64_non_crypto_fixture_digest"
    }
}

fn object_store_checksum_scope(report: &ObjectStoreReadSmokeReport) -> &'static str {
    if report.has_errors() {
        "not_emitted_no_object_read"
    } else if report.requested_range.is_some() {
        "requested_byte_range"
    } else {
        "full_object"
    }
}

fn object_store_request_count(report: &ObjectStoreReadSmokeReport) -> usize {
    usize::from(!report.has_errors())
}

fn object_store_bytes_requested(report: &ObjectStoreReadSmokeReport) -> u64 {
    if report.has_errors() {
        0
    } else {
        report
            .requested_range
            .map_or(report.object_size_bytes, |range| range.length)
    }
}

fn object_store_bounded_read_status(report: &ObjectStoreReadSmokeReport) -> &'static str {
    if report.has_errors() {
        "not_performed_blocked"
    } else if report.requested_range.is_some() {
        "bounded_byte_range_with_fixture_budget"
    } else {
        "bounded_full_object_under_fixture_budget"
    }
}

fn object_store_request_coalescing_status(report: &ObjectStoreReadSmokeReport) -> &'static str {
    if report.has_errors() {
        "not_performed_blocked"
    } else if report.requested_range.is_some() {
        "not_required_single_byte_range_request"
    } else {
        "not_required_single_full_object_request"
    }
}

fn object_store_coalesced_request_count(report: &ObjectStoreReadSmokeReport) -> usize {
    usize::from(!report.has_errors())
}

fn object_store_prefetch_status(report: &ObjectStoreReadSmokeReport) -> &'static str {
    if report.has_errors() {
        "not_performed_blocked"
    } else {
        "not_required_single_bounded_request"
    }
}

fn object_store_retry_policy_status(report: &ObjectStoreReadSmokeReport) -> &'static str {
    if report.has_errors() {
        "blocked_before_retry"
    } else if report.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
        "not_required_single_attempt_public_fixture"
    } else {
        "not_required_single_attempt_local_emulator"
    }
}

fn object_store_retry_attempt_count(_report: &ObjectStoreReadSmokeReport) -> usize {
    0
}

fn object_store_rate_limit_policy_status(report: &ObjectStoreReadSmokeReport) -> &'static str {
    if report.has_errors() {
        "blocked_before_rate_limit_policy"
    } else if report.provider_profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
        "not_required_public_fixture_no_network"
    } else {
        "not_required_local_emulator_no_network"
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct LocalPartitionDiscovery {
    partition_columns: Vec<String>,
    partition_values: Vec<String>,
    partition_directory_count: usize,
    listing_directory_count: usize,
    max_partition_depth: usize,
}

fn discover_local_partition_directories(
    root: &Path,
    lease: &mut MemoryLease,
) -> Result<LocalPartitionDiscovery, std::io::Error> {
    let mut columns = Vec::new();
    let mut values = Vec::new();
    let mut partition_directory_count = 0usize;
    let mut listing_directory_count = 0usize;
    let mut max_partition_depth = 0usize;
    discover_local_partition_directories_inner(
        root,
        0,
        &mut columns,
        &mut values,
        &mut partition_directory_count,
        &mut listing_directory_count,
        &mut max_partition_depth,
        lease,
    )?;
    Ok(LocalPartitionDiscovery {
        partition_columns: columns,
        partition_values: values,
        partition_directory_count,
        listing_directory_count,
        max_partition_depth,
    })
}

#[allow(clippy::too_many_arguments)]
fn discover_local_partition_directories_inner(
    path: &Path,
    depth: usize,
    columns: &mut Vec<String>,
    values: &mut Vec<String>,
    partition_directory_count: &mut usize,
    listing_directory_count: &mut usize,
    max_partition_depth: &mut usize,
    lease: &mut MemoryLease,
) -> Result<(), std::io::Error> {
    if depth > MAX_OBJECT_STORE_PARTITION_DISCOVERY_DEPTH {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            format!(
                "partition discovery depth exceeded scoped limit {MAX_OBJECT_STORE_PARTITION_DISCOVERY_DEPTH}"
            ),
        ));
    }
    *listing_directory_count += 1;
    if *listing_directory_count > MAX_OBJECT_STORE_PARTITION_DISCOVERY_DIRECTORIES {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            format!(
                "partition discovery directory listing count exceeded scoped limit {MAX_OBJECT_STORE_PARTITION_DISCOVERY_DIRECTORIES}"
            ),
        ));
    }
    for entry in fs::read_dir(path)? {
        let entry = entry?;
        let file_type = entry.file_type()?;
        if !file_type.is_dir() || file_type.is_symlink() {
            continue;
        }
        let file_name = entry.file_name();
        let name = file_name.to_string_lossy();
        let child_depth = depth + 1;
        if let Some((key, value)) = parse_partition_directory_name(&name) {
            if let Err(index) = columns.binary_search_by(|column| column.as_str().cmp(key)) {
                crate::fixture_io::reserve_additional(columns, 1, lease)
                    .map_err(std::io::Error::other)?;
                columns.insert(
                    index,
                    crate::fixture_io::copy_text(key, lease).map_err(std::io::Error::other)?,
                );
            }
            let mut text =
                crate::fixture_io::Text::new(lease.pool()).map_err(std::io::Error::other)?;
            let _ = write!(text, "{key}={value}");
            let text = text.finish().map_err(std::io::Error::other)?;
            if let Err(index) = values.binary_search(text.value()) {
                crate::fixture_io::reserve_additional(values, 1, lease)
                    .map_err(std::io::Error::other)?;
                let (text, mut text_lease) = text.into_parts();
                lease
                    .absorb(&mut text_lease)
                    .map_err(std::io::Error::other)?;
                values.insert(index, text);
            }
            *partition_directory_count += 1;
            *max_partition_depth = (*max_partition_depth).max(child_depth);
        }
        discover_local_partition_directories_inner(
            &entry.path(),
            child_depth,
            columns,
            values,
            partition_directory_count,
            listing_directory_count,
            max_partition_depth,
            lease,
        )?;
    }
    Ok(())
}

fn parse_partition_directory_name(name: &str) -> Option<(&str, &str)> {
    let (key, value) = name.split_once('=')?;
    let key = key.trim();
    let value = value.trim();
    if key.is_empty() || value.is_empty() {
        None
    } else {
        Some((key, value))
    }
}

fn read_local_emulator_bytes(
    local_path: &Path,
    requested_range: Option<RequestedRange>,
    object_size_bytes: u64,
    pool: &LiveMemoryPool,
) -> std::io::Result<Budgeted<Vec<u8>>> {
    let max_bytes = MAX_OBJECT_STORE_FIXTURE_BYTES;
    match requested_range {
        Some(range) if range.length > max_bytes => {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidData,
                format!(
                    "object-store fixture byte range {}:{} exceeds scoped read budget {max_bytes} bytes",
                    range.offset, range.length
                ),
            ));
        }
        None if object_size_bytes > max_bytes => {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidData,
                format!(
                    "object-store fixture {} is {object_size_bytes} bytes; scoped full-object reads admit at most {max_bytes} bytes",
                    local_path.display()
                ),
            ));
        }
        _ => {}
    }
    crate::fixture_io::read_bytes(
        local_path,
        requested_range.map(|range| (range.offset, range.length)),
        object_size_bytes,
        pool,
    )
}

fn parse_requested_range(raw: &str) -> Result<RequestedRange, ShardLoomError> {
    let Some((offset, length)) = raw.split_once(':') else {
        return Err(ShardLoomError::InvalidOperation(
            "range must use offset:length syntax".to_string(),
        ));
    };
    let offset = offset.parse::<u64>().map_err(|_| {
        ShardLoomError::InvalidOperation("range offset must be an unsigned integer".to_string())
    })?;
    let length = length.parse::<u64>().map_err(|_| {
        ShardLoomError::InvalidOperation("range length must be an unsigned integer".to_string())
    })?;
    if length == 0 {
        return Err(ShardLoomError::InvalidOperation(
            "range length must be greater than zero".to_string(),
        ));
    }
    Ok(RequestedRange { offset, length })
}

fn parse_partition_columns(raw: &str) -> Vec<String> {
    raw.split(',')
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .map(ToString::to_string)
        .collect()
}

fn partition_column_sets_match(requested: &[String], discovered: &[String]) -> bool {
    requested.iter().collect::<BTreeSet<_>>() == discovered.iter().collect::<BTreeSet<_>>()
}

fn is_remote_object_store_uri(source: &str) -> bool {
    let Some((scheme, _)) = source.split_once("://") else {
        return false;
    };
    matches!(
        scheme.to_ascii_lowercase().as_str(),
        "s3" | "gs" | "gcs" | "abfs" | "abfss"
    )
}

fn parse_object_store_uri(source: &str) -> Result<ParsedObjectStoreUri, ShardLoomError> {
    let (scheme, rest) = source.split_once("://").ok_or_else(|| {
        ShardLoomError::InvalidOperation("object-store URI must include a scheme".to_string())
    })?;
    let scheme = scheme.to_ascii_lowercase();
    let provider = match scheme.as_str() {
        "s3" => "s3",
        "gs" | "gcs" => "gcs",
        "abfs" | "abfss" => "adls",
        _ => {
            return Err(ShardLoomError::InvalidOperation(format!(
                "unsupported object-store URI scheme: {scheme}"
            )));
        }
    };
    if rest.contains('?') || rest.contains('#') {
        return Err(ShardLoomError::InvalidOperation(
            "public fixture object URI must not include query strings or fragments".to_string(),
        ));
    }
    let Some((bucket, key)) = rest.split_once('/') else {
        return Err(ShardLoomError::InvalidOperation(
            "object-store URI must include bucket/container and object key".to_string(),
        ));
    };
    if bucket.trim().is_empty() || key.trim().is_empty() {
        return Err(ShardLoomError::InvalidOperation(
            "object-store URI bucket/container and object key must be non-empty".to_string(),
        ));
    }
    validate_object_store_authority(scheme.as_str(), bucket, key)?;
    Ok(ParsedObjectStoreUri {
        provider,
        bucket: bucket.to_string(),
        key: key.to_string(),
    })
}

fn validate_object_store_authority(
    scheme: &str,
    authority: &str,
    key: &str,
) -> Result<(), ShardLoomError> {
    if key.contains('@') {
        return Err(ShardLoomError::InvalidOperation(
            "object-store URI object key must not include credentials or userinfo".to_string(),
        ));
    }
    if matches!(scheme, "abfs" | "abfss") {
        if authority.matches('@').count() > 1 {
            return Err(ShardLoomError::InvalidOperation(
                "ADLS object-store URI authority must contain at most one container/account separator".to_string(),
            ));
        }
        if let Some((container, account)) = authority.split_once('@') {
            if container.trim().is_empty() || account.trim().is_empty() {
                return Err(ShardLoomError::InvalidOperation(
                    "ADLS object-store URI container and account authority must be non-empty"
                        .to_string(),
                ));
            }
            if container.contains(':') {
                return Err(ShardLoomError::InvalidOperation(
                    "object-store URI must not include credentials or userinfo".to_string(),
                ));
            }
        }
        return Ok(());
    }
    if authority.contains('@') {
        return Err(ShardLoomError::InvalidOperation(
            "object-store URI must not include credentials or userinfo".to_string(),
        ));
    }
    Ok(())
}

fn provider_for_source_or_profile(source: &str, profile: &str) -> &'static str {
    if profile == LOCAL_EMULATOR_PROFILE {
        return "local_emulator";
    }
    parse_object_store_uri(source).map_or("unknown", |parsed| parsed.provider)
}

fn object_store_read_object_feature(profile: &str) -> &'static str {
    if profile == PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE {
        "object_store_public_fixture_object"
    } else {
        "object_store_local_emulator_object"
    }
}

fn redact_object_store_uri(source: &str) -> String {
    let without_query = source.split(['?', '#']).next().unwrap_or(source);
    let Some((scheme, rest)) = without_query.split_once("://") else {
        return without_query.to_string();
    };
    if object_store_uri_has_userinfo(scheme, rest) {
        let tail = rest.rsplit_once('@').map_or(rest, |(_, tail)| tail);
        format!("{scheme}://<redacted>@{tail}")
    } else {
        without_query.to_string()
    }
}

fn requested_uri_redaction_status(source: &str) -> &'static str {
    if source.contains('?') || source.contains('#') {
        return "redacted";
    }
    let Some((scheme, rest)) = source.split_once("://") else {
        return "not_required";
    };
    if object_store_uri_has_userinfo(scheme, rest) {
        "redacted"
    } else {
        "not_required"
    }
}

fn redaction_required(source: &str) -> bool {
    requested_uri_redaction_status(source) == "redacted"
}

fn object_store_uri_has_userinfo(scheme: &str, rest: &str) -> bool {
    let authority = rest.split('/').next().unwrap_or(rest);
    let scheme = scheme.to_ascii_lowercase();
    if matches!(scheme.as_str(), "abfs" | "abfss") {
        authority.matches('@').count() > 1
            || authority
                .split_once('@')
                .is_some_and(|(container, _)| container.contains(':'))
    } else {
        authority.contains('@')
    }
}

fn normalize_local_emulator_path(raw: &str) -> Result<PathBuf, ShardLoomError> {
    if raw.trim().is_empty() {
        return Err(ShardLoomError::InvalidOperation(
            "local-emulator object path must not be empty".to_string(),
        ));
    }
    if let Some((scheme, rest)) = raw.split_once("://") {
        if !scheme.eq_ignore_ascii_case("file") {
            return Err(ShardLoomError::InvalidOperation(format!(
                "unsupported URI scheme for local-emulator object-store path: {raw}"
            )));
        }
        if rest.is_empty() {
            return Err(ShardLoomError::InvalidOperation(
                "file:// path must include a local path".to_string(),
            ));
        }
        return Ok(local_file_uri_path(rest));
    }
    Ok(PathBuf::from(raw))
}

fn local_file_uri_path(rest: &str) -> PathBuf {
    let local_rest = if let Some(path) = rest.strip_prefix("localhost/") {
        format!("/{path}")
    } else {
        rest.to_string()
    };
    if local_rest.len() >= 3 && local_rest.as_bytes()[0] == b'/' && local_rest.as_bytes()[2] == b':'
    {
        PathBuf::from(&local_rest[1..])
    } else {
        PathBuf::from(local_rest)
    }
}

fn fnv64_digest(value: &str) -> String {
    fnv64_digest_bytes(value.as_bytes())
}

fn fnv64_digest_bytes(value: &[u8]) -> String {
    let mut hash = 0xcbf2_9ce4_8422_2325_u64;
    for byte in value {
        hash ^= u64::from(*byte);
        hash = hash.wrapping_mul(0x0000_0100_0000_01b3);
    }
    format!("fnv64:{hash:016x}")
}

fn push_field(fields: &mut Vec<(String, String)>, key: &str, value: &str) {
    fields.push((key.to_string(), value.to_string()));
}

fn joined_or_none(values: &[String]) -> String {
    if values.is_empty() {
        "none".to_string()
    } else {
        values.join(",")
    }
}

fn push_count_field(fields: &mut Vec<(String, String)>, key: &str, value: usize) {
    push_field(fields, key, &value.to_string());
}

fn push_u64_field(fields: &mut Vec<(String, String)>, key: &str, value: u64) {
    push_field(fields, key, &value.to_string());
}

fn push_bool_field(fields: &mut Vec<(String, String)>, key: &str, value: bool) {
    push_field(fields, key, &value.to_string());
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs::File;

    fn execute_object_store_read_smoke(
        source: &str,
        profile: &str,
        range: Option<RequestedRange>,
        fixture: Option<&str>,
        listing: bool,
    ) -> ObjectStoreReadSmokeReport {
        let pool = LiveMemoryPool::new(16 << 20).unwrap();
        super::execute_object_store_read_smoke(source, profile, range, fixture, listing, &pool)
    }

    fn execute_object_store_write_smoke(
        source: &str,
        target: &str,
        profile: &str,
        key: Option<&str>,
        overwrite: bool,
        rollback: bool,
    ) -> ObjectStoreWriteSmokeReport {
        let pool = LiveMemoryPool::new(16 << 20).unwrap();
        super::execute_object_store_write_smoke(
            source, target, profile, key, overwrite, rollback, &pool,
        )
    }

    fn execute_object_store_write_recovery_smoke(
        target: &str,
        profile: &str,
        key: Option<&str>,
    ) -> ObjectStoreWriteRecoveryReport {
        let pool = LiveMemoryPool::new(16 << 20).unwrap();
        super::execute_object_store_write_recovery_smoke(target, profile, key, &pool)
    }

    #[test]
    fn object_store_reads_enforce_the_same_exact_pool_for_both_profiles() {
        let fixture = std::env::temp_dir().join(format!(
            "shardloom-object-store-shared-read-{}.bin",
            std::process::id()
        ));
        fs::write(&fixture, b"abcdef").unwrap();
        let path = fixture.to_str().unwrap();
        for (source, profile, fixture_path) in [
            (path, LOCAL_EMULATOR_PROFILE, None),
            (
                "s3://bucket/object",
                PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE,
                Some(path),
            ),
        ] {
            let pool = LiveMemoryPool::new(6).unwrap();
            let retained = pool.reserve(4).unwrap();
            let denied = super::execute_object_store_read_smoke(
                source,
                profile,
                Some(RequestedRange {
                    offset: 1,
                    length: 3,
                }),
                fixture_path,
                false,
                &pool,
            );
            assert_eq!(denied.status, ObjectStoreReadSmokeStatus::BlockedReadError);
            assert_eq!(denied.bytes_read, 0);
            assert!(
                denied
                    .diagnostics
                    .iter()
                    .any(|d| format!("{d:?}").contains("memory reservation denied"))
            );
            assert_eq!(pool.snapshot().reserved_bytes, 4);
            drop(retained);
            let read = super::execute_object_store_read_smoke(
                source,
                profile,
                None,
                fixture_path,
                false,
                &pool,
            );
            assert!(!read.has_errors());
            assert_eq!(read.bytes_read, 6);
            assert_eq!(pool.snapshot().peak_reserved_bytes, 6);
            assert_eq!(pool.snapshot().reserved_bytes, 0);
        }
        let pool = LiveMemoryPool::new(1).unwrap();
        let denied = super::execute_object_store_read_smoke(
            path,
            LOCAL_EMULATOR_PROFILE,
            None,
            None,
            false,
            &pool,
        );
        assert_eq!(denied.status, ObjectStoreReadSmokeStatus::BlockedReadError);
        assert_eq!(pool.snapshot().peak_reserved_bytes, 0);
        fs::remove_file(fixture).unwrap();
    }

    #[test]
    fn object_store_write_denial_preserves_targets_and_recovery_has_its_own_admission() {
        let root = std::env::temp_dir().join(format!(
            "shardloom-object-store-shared-write-{}",
            std::process::id()
        ));
        fs::create_dir(&root).unwrap();
        let source = root.join("source.bin");
        let target = root.join("target.bin");
        fs::write(&source, b"new-payload").unwrap();
        fs::write(&target, b"preserve").unwrap();
        let small = LiveMemoryPool::new(64).unwrap();
        let denied = super::execute_object_store_write_smoke(
            source.to_str().unwrap(),
            target.to_str().unwrap(),
            LOCAL_EMULATOR_PROFILE,
            Some("budget"),
            true,
            false,
            &small,
        );
        assert!(denied.has_errors());
        assert_eq!(fs::read(&target).unwrap(), b"preserve");
        assert_eq!(fs::read_dir(&root).unwrap().count(), 2);
        assert_eq!(small.snapshot().reserved_bytes, 0);

        let pool = LiveMemoryPool::new(16 << 20).unwrap();
        let written = super::execute_object_store_write_smoke(
            source.to_str().unwrap(),
            target.to_str().unwrap(),
            LOCAL_EMULATOR_PROFILE,
            Some("budget"),
            true,
            false,
            &pool,
        );
        assert!(!written.has_errors());
        assert!(
            pool.snapshot().peak_reserved_bytes
                >= 11 + shardloom_core::WorkspaceSafeLocalStagingWriter::buffer_capacity_bytes()
        );
        assert_eq!(pool.snapshot().reserved_bytes, 0);
        let denied = super::execute_object_store_write_recovery_smoke(
            target.to_str().unwrap(),
            LOCAL_EMULATOR_PROFILE,
            Some("budget"),
            &LiveMemoryPool::new(1).unwrap(),
        );
        assert!(denied.has_errors());
        let recovered = super::execute_object_store_write_recovery_smoke(
            target.to_str().unwrap(),
            LOCAL_EMULATOR_PROFILE,
            Some("budget"),
            &pool,
        );
        assert!(!recovered.has_errors());
        assert_eq!(fs::read(&target).unwrap(), b"new-payload");
        assert_eq!(pool.snapshot().reserved_bytes, 0);
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn generated_object_manifest_denial_restores_prior_objects_and_sidecars() {
        let root = std::env::temp_dir().join(format!(
            "shardloom-object-manifest-admission-{}",
            std::process::id()
        ));
        fs::create_dir(&root).unwrap();
        let source = root.join("source.bin");
        fs::write(&source, b"x").unwrap();
        let limit = shardloom_core::WorkspaceSafeLocalStagingWriter::buffer_capacity_bytes() + 1;
        // Small text fits on its own but not beside staging. Escaped control
        // text exceeds the grant during construction, before any manifest write.
        for (index, key) in ["small".to_string(), "\u{0001}".repeat(65_536)]
            .iter()
            .enumerate()
        {
            for overwrite in [false, true] {
                let target = root.join(format!("target-{index}-{overwrite}.bin"));
                let sidecar = commit_manifest_sidecar_path(&target);
                if overwrite {
                    fs::write(&target, b"prior-object").unwrap();
                    fs::write(&sidecar, b"prior-manifest").unwrap();
                }
                let pool = LiveMemoryPool::new(limit).unwrap();
                let report = super::execute_object_store_write_smoke(
                    source.to_str().unwrap(),
                    target.to_str().unwrap(),
                    LOCAL_EMULATOR_PROFILE,
                    Some(key),
                    overwrite,
                    false,
                    &pool,
                );
                assert_eq!(
                    report.status,
                    ObjectStoreWriteSmokeStatus::BlockedWriteError
                );
                assert!(format!("{:?}", report.diagnostics).contains("memory reservation denied"));
                assert_eq!(pool.snapshot().reserved_bytes, 0);
                assert_eq!(pool.snapshot().denied_reservations, 1);
                assert!(pool.snapshot().peak_reserved_bytes <= limit);
                if overwrite {
                    assert_eq!(fs::read(&target).unwrap(), b"prior-object");
                    assert_eq!(fs::read(&sidecar).unwrap(), b"prior-manifest");
                } else {
                    assert!(!target.exists());
                    assert!(!sidecar.exists());
                }
                assert!(!staging_object_path(&target, key).exists());
                assert!(!backup_object_path(&target, key).exists());
                assert!(!backup_object_path(&sidecar, key).exists());
            }
        }
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn generated_object_manifest_reports_escaped_owned_capacity_and_recovers() {
        let root = std::env::temp_dir().join(format!(
            "shardloom-object-manifest-accounted-{}",
            std::process::id()
        ));
        fs::create_dir(&root).unwrap();
        let source = root.join("source.bin");
        let target = root.join("target.bin");
        fs::write(&source, b"x").unwrap();
        let key = "Unicode-λ-quote\"-slash\\-line\n".repeat(256);
        let pool = LiveMemoryPool::new(2 << 20).unwrap();
        let report = super::execute_object_store_write_smoke(
            source.to_str().unwrap(),
            target.to_str().unwrap(),
            LOCAL_EMULATOR_PROFILE,
            Some(&key),
            false,
            false,
            &pool,
        );
        assert!(!report.has_errors(), "{report:?}");
        let sidecar = fs::read(commit_manifest_sidecar_path(&target)).unwrap();
        let json: serde_json::Value = serde_json::from_slice(&sidecar).unwrap();
        assert_eq!(json["idempotency_key"], key);
        assert_eq!(report.commit_manifest_bytes, sidecar.len());
        assert!(
            pool.snapshot().peak_reserved_bytes
                >= sidecar.len() as u64
                    + shardloom_core::WorkspaceSafeLocalStagingWriter::buffer_capacity_bytes()
        );
        assert_eq!(pool.snapshot().reserved_bytes, 0);
        assert_eq!(pool.snapshot().denied_reservations, 0);
        let recovered = super::execute_object_store_write_recovery_smoke(
            target.to_str().unwrap(),
            LOCAL_EMULATOR_PROFILE,
            Some(&key),
            &pool,
        );
        assert!(!recovered.has_errors(), "{recovered:?}");
        assert_eq!(pool.snapshot().reserved_bytes, 0);
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn object_store_write_reuses_source_credits_for_readback() {
        let root = std::env::temp_dir().join(format!(
            "shardloom-object-store-readback-credits-{}",
            std::process::id()
        ));
        fs::create_dir(&root).unwrap();
        let source = root.join("source.bin");
        let target = root.join("target.bin");
        let payload = vec![173_u8; 1 << 20];
        fs::write(&source, &payload).unwrap();
        let limit = payload.len() as u64
            + shardloom_core::WorkspaceSafeLocalStagingWriter::buffer_capacity_bytes();
        assert!(limit < 2 * payload.len() as u64);
        let pool = LiveMemoryPool::new(limit).unwrap();
        let written = super::execute_object_store_write_smoke(
            source.to_str().unwrap(),
            target.to_str().unwrap(),
            LOCAL_EMULATOR_PROFILE,
            Some("reuse"),
            true,
            false,
            &pool,
        );
        assert!(!written.has_errors(), "{written:?}");
        assert_eq!(fs::read(&target).unwrap(), payload);
        assert_eq!(pool.snapshot().peak_reserved_bytes, limit);
        assert_eq!(pool.snapshot().reserved_bytes, 0);
        assert_eq!(pool.snapshot().denied_reservations, 0);
        let recovered = super::execute_object_store_write_recovery_smoke(
            target.to_str().unwrap(),
            LOCAL_EMULATOR_PROFILE,
            Some("reuse"),
            &pool,
        );
        assert!(!recovered.has_errors());
        assert_eq!(pool.snapshot().reserved_bytes, 0);
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn local_emulator_range_read_emits_source_state_and_no_fallback_fields() {
        let fixture = std::env::temp_dir().join(format!(
            "shardloom-object-store-read-smoke-{}.bin",
            std::process::id()
        ));
        fs::write(&fixture, b"abcdef").expect("fixture write");

        let report = execute_object_store_read_smoke(
            fixture.to_string_lossy().as_ref(),
            DEFAULT_PROFILE,
            Some(RequestedRange {
                offset: 1,
                length: 3,
            }),
            None,
            false,
        );
        let fields = object_store_read_smoke_fields(&report);
        fs::remove_file(&fixture).expect("fixture cleanup");

        assert!(!report.has_errors());
        assert_eq!(report.bytes_read, 3);
        assert_eq!(
            output_field(&fields, "byte_range_read_status"),
            "performed_local_emulator"
        );
        assert_eq!(
            output_field(&fields, "object_etag_status"),
            "derived_local_emulator_metadata_range_fingerprint"
        );
        assert_eq!(
            output_field(&fields, "object_version_status"),
            "derived_local_emulator_mtime"
        );
        assert_eq!(
            output_field(&fields, "object_store_checksum_validation_status"),
            "validated_requested_bytes_digest"
        );
        assert_eq!(
            output_field(&fields, "object_store_checksum_scope"),
            "requested_byte_range"
        );
        assert_eq!(output_field(&fields, "object_store_request_count"), "1");
        assert_eq!(output_field(&fields, "object_store_bytes_requested"), "3");
        assert_eq!(output_field(&fields, "object_store_bytes_read"), "3");
        assert_eq!(
            output_field(&fields, "object_store_bounded_read_status"),
            "bounded_byte_range_with_fixture_budget"
        );
        assert_eq!(
            output_field(&fields, "object_store_request_coalescing_status"),
            "not_required_single_byte_range_request"
        );
        assert_eq!(
            output_field(&fields, "object_store_coalesced_request_count"),
            "1"
        );
        assert_eq!(
            output_field(&fields, "object_store_retry_policy_status"),
            "not_required_single_attempt_local_emulator"
        );
        assert_eq!(
            output_field(&fields, "object_store_rate_limit_policy_status"),
            "not_required_local_emulator_no_network"
        );
        assert_eq!(
            output_field(&fields, "credential_resolution_performed"),
            "false"
        );
        assert_eq!(output_field(&fields, "network_probe_performed"), "false");
        assert_eq!(output_field(&fields, "fallback_attempted"), "false");
        assert_eq!(output_field(&fields, "external_engine_invoked"), "false");
        assert_eq!(
            output_field(&fields, "claim_gate_status"),
            "fixture_smoke_only"
        );
        assert!(
            output_field(&fields, "source_state_id").starts_with("object-store-local-emulator-")
        );
    }

    #[test]
    fn remote_provider_is_blocked_without_probe_or_io() {
        let report = execute_object_store_read_smoke(
            "s3://bucket/object.vortex",
            DEFAULT_PROFILE,
            None,
            None,
            false,
        );
        let fields = object_store_read_smoke_fields(&report);

        assert!(report.has_errors());
        assert_eq!(
            report.status,
            ObjectStoreReadSmokeStatus::BlockedRemoteProvider
        );
        assert_eq!(output_field(&fields, "object_store_io"), "false");
        assert_eq!(output_field(&fields, "object_store_request_count"), "0");
        assert_eq!(output_field(&fields, "object_store_bytes_requested"), "0");
        assert_eq!(output_field(&fields, "object_store_bytes_read"), "0");
        assert_eq!(
            output_field(&fields, "object_store_bounded_read_status"),
            "not_performed_blocked"
        );
        assert_eq!(
            output_field(&fields, "object_store_retry_policy_status"),
            "blocked_before_retry"
        );
        assert_eq!(
            output_field(&fields, "credential_resolution_performed"),
            "false"
        );
        assert_eq!(output_field(&fields, "network_probe_performed"), "false");
        assert_eq!(output_field(&fields, "fallback_attempted"), "false");
        assert_eq!(
            report.diagnostics[0].code,
            DiagnosticCode::ObjectStoreUnsupported
        );
    }

    #[test]
    fn public_no_credential_fixture_reads_remote_uri_shape_without_network() {
        let fixture = std::env::temp_dir().join(format!(
            "shardloom-object-store-public-fixture-{}.bin",
            std::process::id()
        ));
        fs::write(&fixture, b"abcdef").expect("fixture write");

        let report = execute_object_store_read_smoke(
            "s3://public-bucket/orders.vortex",
            PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE,
            Some(RequestedRange {
                offset: 2,
                length: 2,
            }),
            Some(fixture.to_string_lossy().as_ref()),
            true,
        );
        let fields = object_store_read_smoke_fields(&report);
        fs::remove_file(&fixture).expect("fixture cleanup");

        assert!(!report.has_errors());
        assert_eq!(report.object_store_provider, "s3");
        assert_eq!(report.object_store_bucket, "public-bucket");
        assert_eq!(report.object_store_key, "orders.vortex");
        assert_eq!(
            output_field(&fields, "object_store_uri_parse_status"),
            "parsed_public_no_credential_fixture_uri"
        );
        assert_eq!(
            output_field(&fields, "byte_range_read_status"),
            "performed_public_no_credential_fixture"
        );
        assert_eq!(
            output_field(&fields, "object_etag_status"),
            "derived_public_fixture_read_digest"
        );
        assert_eq!(output_field(&fields, "object_store_request_count"), "1");
        assert_eq!(output_field(&fields, "object_store_bytes_requested"), "2");
        assert_eq!(output_field(&fields, "object_store_bytes_read"), "2");
        assert_eq!(
            output_field(&fields, "object_store_retry_policy_status"),
            "not_required_single_attempt_public_fixture"
        );
        assert_eq!(
            output_field(&fields, "credential_policy_status"),
            "public_no_credential_fixture_admitted"
        );
        assert_eq!(output_field(&fields, "network_probe_performed"), "false");
        assert_eq!(output_field(&fields, "provider_probe_performed"), "false");
        assert_eq!(
            output_field(&fields, "listing_status"),
            "performed_public_fixture_single_object"
        );
        assert_eq!(
            output_field(&fields, "native_io_certificate_status"),
            "public_fixture_smoke_only"
        );
        assert_eq!(
            output_field(&fields, "claim_gate_status"),
            "public_fixture_smoke_only"
        );
        assert_eq!(
            output_field(&fields, "public_no_credential_fixture_claim_allowed"),
            "true"
        );
        assert_eq!(output_field(&fields, "fallback_attempted"), "false");
        assert_eq!(output_field(&fields, "external_engine_invoked"), "false");
        assert!(
            output_field(&fields, "source_state_id").starts_with("object-store-public-fixture-")
        );
    }

    #[test]
    fn public_fixture_accepts_adls_container_account_authority() {
        let fixture = std::env::temp_dir().join(format!(
            "shardloom-object-store-public-adls-fixture-{}.bin",
            std::process::id()
        ));
        fs::write(&fixture, b"abcdef").expect("fixture write");

        let report = execute_object_store_read_smoke(
            "abfss://public-container@storageacct.dfs.core.windows.net/orders.vortex",
            PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE,
            None,
            Some(fixture.to_string_lossy().as_ref()),
            false,
        );
        let fields = object_store_read_smoke_fields(&report);
        fs::remove_file(&fixture).expect("fixture cleanup");

        assert!(!report.has_errors());
        assert_eq!(report.object_store_provider, "adls");
        assert_eq!(
            report.object_store_bucket,
            "public-container@storageacct.dfs.core.windows.net"
        );
        assert_eq!(report.object_store_key, "orders.vortex");
        assert_eq!(
            output_field(&fields, "requested_uri_redaction_status"),
            "not_required"
        );
    }

    #[test]
    fn local_emulator_full_object_read_emits_bounded_request_evidence() {
        let fixture = std::env::temp_dir().join(format!(
            "shardloom-object-store-full-read-{}.bin",
            std::process::id()
        ));
        fs::write(&fixture, b"abcdef").expect("fixture write");

        let report = execute_object_store_read_smoke(
            fixture.to_string_lossy().as_ref(),
            DEFAULT_PROFILE,
            None,
            None,
            false,
        );
        let fields = object_store_read_smoke_fields(&report);
        fs::remove_file(&fixture).expect("fixture cleanup");

        assert!(!report.has_errors());
        assert_eq!(
            output_field(&fields, "full_file_read_status"),
            "performed_local_emulator"
        );
        assert_eq!(
            output_field(&fields, "streaming_read_status"),
            "performed_local_emulator_full_file_stream"
        );
        assert_eq!(
            output_field(&fields, "object_store_checksum_scope"),
            "full_object"
        );
        assert_eq!(output_field(&fields, "object_store_request_count"), "1");
        assert_eq!(output_field(&fields, "object_store_bytes_requested"), "6");
        assert_eq!(output_field(&fields, "object_store_bytes_read"), "6");
        assert_eq!(
            output_field(&fields, "object_store_bounded_read_status"),
            "bounded_full_object_under_fixture_budget"
        );
        assert_eq!(
            output_field(&fields, "object_store_request_coalescing_status"),
            "not_required_single_full_object_request"
        );
        assert_eq!(
            output_field(&fields, "object_store_prefetch_status"),
            "not_required_single_bounded_request"
        );
    }

    #[test]
    fn uri_redaction_keeps_valid_adls_authority_visible() {
        assert_eq!(
            redact_object_store_uri("abfss://container@account.dfs.core.windows.net/path.vortex"),
            "abfss://container@account.dfs.core.windows.net/path.vortex"
        );
        assert_eq!(
            requested_uri_redaction_status(
                "abfss://container@account.dfs.core.windows.net/path.vortex"
            ),
            "not_required"
        );
        assert_eq!(
            redact_object_store_uri("s3://user@bucket/path.vortex?token=secret"),
            "s3://<redacted>@bucket/path.vortex"
        );
        assert_eq!(
            requested_uri_redaction_status("s3://user@bucket/path.vortex"),
            "redacted"
        );
    }

    #[test]
    fn read_source_location_redacts_credential_bearing_uri() {
        let fixture = std::env::temp_dir().join(format!(
            "shardloom-object-store-redacted-public-fixture-{}.bin",
            std::process::id()
        ));
        fs::write(&fixture, b"abcdef").expect("fixture write");

        let report = execute_object_store_read_smoke(
            "s3://user@public-bucket/orders.vortex?token=secret",
            PUBLIC_NO_CREDENTIAL_FIXTURE_PROFILE,
            None,
            Some(fixture.to_string_lossy().as_ref()),
            false,
        );
        let fields = object_store_read_smoke_fields(&report);
        fs::remove_file(&fixture).expect("fixture cleanup");

        assert_eq!(
            output_field(&fields, "requested_uri"),
            "s3://<redacted>@public-bucket/orders.vortex"
        );
        assert_eq!(
            output_field(&fields, "source_location"),
            "s3://<redacted>@public-bucket/orders.vortex"
        );
        assert_eq!(
            output_field(&fields, "requested_uri_redaction_status"),
            "redacted"
        );
        assert_no_field_value_contains(&fields, "token=secret");
        assert_no_field_value_contains(&fields, "user@public-bucket");
    }

    #[test]
    fn write_evidence_redacts_credential_bearing_uris() {
        let report = ObjectStoreWriteSmokeReport::blocked(
            ObjectStoreWriteSmokeStatus::BlockedRemoteProvider,
            DEFAULT_PROFILE,
            "s3://user@source-bucket/input.vortex?token=secret",
            "s3://writer@target-bucket/output.vortex?sig=secret",
            false,
            false,
            Diagnostic::invalid_input(
                "object_store_write_smoke",
                "blocked remote provider",
                "Use the local-emulator profile for this smoke.",
            ),
        );
        let fields = object_store_write_smoke_fields(&report);

        assert_eq!(
            output_field(&fields, "source_uri"),
            "s3://<redacted>@source-bucket/input.vortex"
        );
        assert_eq!(
            output_field(&fields, "target_uri"),
            "s3://<redacted>@target-bucket/output.vortex"
        );
        assert_eq!(
            output_field(&fields, "source_uri_redaction_status"),
            "redacted"
        );
        assert_eq!(
            output_field(&fields, "target_uri_redaction_status"),
            "redacted"
        );
        assert_no_field_value_contains(&fields, "token=secret");
        assert_no_field_value_contains(&fields, "sig=secret");
        assert_no_field_value_contains(&fields, "user@source-bucket");
        assert_no_field_value_contains(&fields, "writer@target-bucket");
    }

    #[test]
    fn write_recovery_evidence_redacts_credential_bearing_target_uri() {
        let report = ObjectStoreWriteRecoveryReport::blocked(
            ObjectStoreWriteRecoveryStatus::BlockedRemoteProvider,
            DEFAULT_PROFILE,
            "s3://writer@target-bucket/output.vortex?sig=secret",
            None,
            Diagnostic::invalid_input(
                "object_store_write_recovery_smoke",
                "blocked remote provider",
                "Use the local-emulator profile for this smoke.",
            ),
        );
        let fields = object_store_write_recovery_smoke_fields(&report);

        assert_eq!(
            output_field(&fields, "target_uri"),
            "s3://<redacted>@target-bucket/output.vortex"
        );
        assert_eq!(
            output_field(&fields, "target_uri_redaction_status"),
            "redacted"
        );
        assert_no_field_value_contains(&fields, "sig=secret");
        assert_no_field_value_contains(&fields, "writer@target-bucket");
    }

    #[test]
    fn local_file_uri_normalization_strips_localhost_authority() {
        assert_eq!(
            normalize_local_emulator_path("file://localhost/tmp/orders.vortex").unwrap(),
            PathBuf::from("/tmp/orders.vortex")
        );
        assert_eq!(
            normalize_local_emulator_path("FILE:///C:/tmp/orders.vortex").unwrap(),
            PathBuf::from("C:/tmp/orders.vortex")
        );
    }

    #[test]
    fn full_object_read_rejects_fixture_over_byte_budget() {
        let fixture = std::env::temp_dir().join(format!(
            "shardloom-object-store-oversized-read-{}.bin",
            std::process::id()
        ));
        let file = File::create(&fixture).expect("create sparse fixture");
        file.set_len(MAX_OBJECT_STORE_FIXTURE_BYTES + 1)
            .expect("set sparse fixture length");

        let report = execute_object_store_read_smoke(
            fixture.to_string_lossy().as_ref(),
            DEFAULT_PROFILE,
            None,
            None,
            false,
        );
        fs::remove_file(&fixture).expect("fixture cleanup");

        assert_eq!(report.status, ObjectStoreReadSmokeStatus::BlockedReadError);
        assert!(report.has_errors());
        assert!(
            report.diagnostics[0]
                .reason
                .as_deref()
                .unwrap_or_default()
                .contains("scoped full-object reads admit at most"),
            "{:?}",
            report.diagnostics
        );
    }

    #[test]
    fn write_smoke_rejects_source_over_byte_budget() {
        let source = std::env::temp_dir().join(format!(
            "shardloom-object-store-oversized-write-source-{}.bin",
            std::process::id()
        ));
        let target = std::env::temp_dir().join(format!(
            "shardloom-object-store-oversized-write-target-{}.bin",
            std::process::id()
        ));
        let file = File::create(&source).expect("create sparse write source");
        file.set_len(MAX_OBJECT_STORE_FIXTURE_BYTES + 1)
            .expect("set sparse write source length");

        let report = execute_object_store_write_smoke(
            source.to_string_lossy().as_ref(),
            target.to_string_lossy().as_ref(),
            DEFAULT_PROFILE,
            None,
            false,
            false,
        );
        let _ = fs::remove_file(&source);
        let _ = fs::remove_file(&target);

        assert_eq!(
            report.status,
            ObjectStoreWriteSmokeStatus::BlockedWriteError
        );
        assert!(report.has_errors());
        assert!(
            report.diagnostics[0]
                .reason
                .as_deref()
                .unwrap_or_default()
                .contains("scoped full-object reads admit at most"),
            "{:?}",
            report.diagnostics
        );
    }

    #[test]
    fn recovery_smoke_rejects_object_over_byte_budget() {
        let target = std::env::temp_dir().join(format!(
            "shardloom-object-store-oversized-recovery-target-{}.bin",
            std::process::id()
        ));
        let file = File::create(&target).expect("create sparse recovery target");
        file.set_len(MAX_OBJECT_STORE_FIXTURE_BYTES + 1)
            .expect("set sparse recovery target length");

        let report = execute_object_store_write_recovery_smoke(
            target.to_string_lossy().as_ref(),
            DEFAULT_PROFILE,
            None,
        );
        let _ = fs::remove_file(&target);
        let _ = fs::remove_file(commit_manifest_sidecar_path(&target));

        assert_eq!(
            report.status,
            ObjectStoreWriteRecoveryStatus::BlockedReadError
        );
        assert!(report.has_errors());
        assert!(
            report.diagnostics[0]
                .reason
                .as_deref()
                .unwrap_or_default()
                .contains("scoped full-object reads admit at most"),
            "{:?}",
            report.diagnostics
        );
    }

    #[test]
    fn partition_discovery_rejects_depth_over_budget() {
        let root = std::env::temp_dir().join(format!(
            "shardloom-object-store-partition-depth-{}",
            std::process::id()
        ));
        let mut current = root.clone();
        for index in 0..=MAX_OBJECT_STORE_PARTITION_DISCOVERY_DEPTH + 1 {
            current.push(format!("p{index}=v{index}"));
            fs::create_dir_all(&current).expect("create nested partition directory");
        }

        let report = execute_object_store_partition_discovery_smoke(
            root.to_string_lossy().as_ref(),
            DEFAULT_PROFILE,
            vec![],
            &LiveMemoryPool::new(16 << 20).unwrap(),
        )
        .unwrap();
        let report = report.value();
        let _ = fs::remove_dir_all(&root);

        assert_eq!(
            report.status,
            ObjectStorePartitionDiscoveryStatus::BlockedListingError
        );
        assert!(report.has_errors());
        assert!(
            report.diagnostics[0]
                .reason
                .as_deref()
                .unwrap_or_default()
                .contains("partition discovery depth exceeded scoped limit"),
            "{:?}",
            report.diagnostics
        );
    }

    #[test]
    fn partition_discovery_keeps_sorted_unique_names_with_their_credits() {
        let root = std::env::temp_dir().join(format!(
            "shardloom-partition-resources-{}",
            std::process::id()
        ));
        for suffix in [
            "year=2025/country=US",
            "year=2026/country=US",
            "year=2026/country=CA",
        ] {
            fs::create_dir_all(root.join(suffix)).unwrap();
        }
        let tiny = LiveMemoryPool::new(1).unwrap();
        let denied = execute_object_store_partition_discovery_smoke(
            root.to_str().unwrap(),
            DEFAULT_PROFILE,
            vec![],
            &tiny,
        )
        .unwrap();
        assert!(denied.value().has_errors());
        assert_eq!(tiny.snapshot().reserved_bytes, 0);
        let pool = LiveMemoryPool::new(65536).unwrap();
        let report = execute_object_store_partition_discovery_smoke(
            root.to_str().unwrap(),
            DEFAULT_PROFILE,
            vec![],
            &pool,
        )
        .unwrap();
        assert!(!report.value().has_errors());
        assert_eq!(
            report.value().discovered_partition_columns,
            ["country", "year"]
        );
        assert_eq!(
            report.value().discovered_partition_values,
            ["country=CA", "country=US", "year=2025", "year=2026"]
        );
        assert!(pool.snapshot().reserved_bytes > 0);
        drop(report);
        assert_eq!(pool.snapshot().reserved_bytes, 0);
        fs::remove_dir_all(root).unwrap();
    }

    fn output_field<'a>(fields: &'a [(String, String)], key: &str) -> &'a str {
        fields
            .iter()
            .find(|(field_key, _)| field_key == key)
            .map_or("", |(_, value)| value.as_str())
    }

    fn assert_no_field_value_contains(fields: &[(String, String)], needle: &str) {
        for (key, value) in fields {
            assert!(
                !value.contains(needle),
                "field {key} leaked {needle}: {value}"
            );
        }
    }
}
