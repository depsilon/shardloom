//! Release engineering, API compatibility, and packaging planning domain.
//!
//! This module is planning/reporting only. It does not build, sign, publish,
//! or create release artifacts. Publishing always requires explicit human approval.

#![allow(
    clippy::missing_errors_doc,
    clippy::missing_panics_doc,
    clippy::must_use_candidate,
    clippy::return_self_not_must_use,
    clippy::struct_excessive_bools,
    clippy::semicolon_if_nothing_returned
)]

use crate::{Diagnostic, Result, ShardLoomError};

fn validate_non_empty(value: impl Into<String>, field: &str) -> Result<String> {
    let value = value.into();
    if value.trim().is_empty() {
        return Err(ShardLoomError::InvalidOperation(format!(
            "{field} must not be empty"
        )));
    }
    Ok(value)
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ProjectVersion {
    pub major: u32,
    pub minor: u32,
    pub patch: u32,
    pub pre_release: Option<String>,
}
impl ProjectVersion {
    pub fn new(major: u32, minor: u32, patch: u32) -> Self {
        Self {
            major,
            minor,
            patch,
            pre_release: None,
        }
    }
    pub fn current_crate() -> Self {
        let raw = env!("CARGO_PKG_VERSION");
        let core = raw.split('-').next().unwrap_or("0.1.0");
        let mut it = core.split('.');
        let major = it.next().and_then(|v| v.parse().ok()).unwrap_or(0);
        let minor = it.next().and_then(|v| v.parse().ok()).unwrap_or(1);
        let patch = it.next().and_then(|v| v.parse().ok()).unwrap_or(0);
        Self::new(major, minor, patch)
    }
    pub fn with_pre_release(mut self, pre_release: impl Into<String>) -> Result<Self> {
        self.pre_release = Some(validate_non_empty(pre_release, "pre_release")?);
        Ok(self)
    }
    pub fn is_zero_series(&self) -> bool {
        self.major == 0
    }
    pub fn summary(&self) -> String {
        match &self.pre_release {
            Some(p) => format!("{}.{}.{}-{}", self.major, self.minor, self.patch, p),
            None => format!("{}.{}.{}", self.major, self.minor, self.patch),
        }
    }
}

macro_rules! as_str_enum {($name:ident{$($v:ident=>$s:literal),* $(,)?})=>{impl $name{pub const fn as_str(&self)->&'static str{match self{$(Self::$v=>$s),*}}}}}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ReleaseChannel {
    Development,
    Experimental,
    Alpha,
    Beta,
    Stable,
    LongTermSupport,
}
as_str_enum!(ReleaseChannel{Development=>"development",Experimental=>"experimental",Alpha=>"alpha",Beta=>"beta",Stable=>"stable",LongTermSupport=>"long_term_support"});
impl ReleaseChannel {
    pub const fn is_stable(&self) -> bool {
        matches!(self, Self::Stable | Self::LongTermSupport)
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ApiStabilityTier {
    Internal,
    Experimental,
    Stable,
    Deprecated,
    Removed,
}
as_str_enum!(ApiStabilityTier{Internal=>"internal",Experimental=>"experimental",Stable=>"stable",Deprecated=>"deprecated",Removed=>"removed"});
impl ApiStabilityTier {
    pub const fn is_publicly_supported(&self) -> bool {
        matches!(self, Self::Stable | Self::Deprecated)
    }
    pub const fn allows_breaking_changes(&self) -> bool {
        matches!(self, Self::Internal | Self::Experimental)
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PublicSurfaceKind {
    RustCrate,
    Cli,
    PythonPackage,
    TypeScriptPackage,
    DockerImage,
    GhcrImage,
    MachineReadableSchema,
    Documentation,
    BenchmarkArtifact,
    ExtensionManifest,
    PlanIrSchema,
    DiagnosticSchema,
    Unknown,
}
as_str_enum!(PublicSurfaceKind{RustCrate=>"rust_crate",Cli=>"cli",PythonPackage=>"python_package",TypeScriptPackage=>"typescript_package",DockerImage=>"docker_image",GhcrImage=>"ghcr_image",MachineReadableSchema=>"machine_readable_schema",Documentation=>"documentation",BenchmarkArtifact=>"benchmark_artifact",ExtensionManifest=>"extension_manifest",PlanIrSchema=>"plan_ir_schema",DiagnosticSchema=>"diagnostic_schema",Unknown=>"unknown"});
impl PublicSurfaceKind {
    pub const fn is_machine_readable(&self) -> bool {
        matches!(
            self,
            Self::MachineReadableSchema
                | Self::ExtensionManifest
                | Self::PlanIrSchema
                | Self::DiagnosticSchema
        )
    }
    pub const fn is_package_artifact(&self) -> bool {
        matches!(
            self,
            Self::RustCrate
                | Self::PythonPackage
                | Self::TypeScriptPackage
                | Self::DockerImage
                | Self::GhcrImage
        )
    }
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PublicSurface {
    pub kind: PublicSurfaceKind,
    pub name: String,
    pub stability: ApiStabilityTier,
    pub version: ProjectVersion,
}
impl PublicSurface {
    pub fn new(
        kind: PublicSurfaceKind,
        name: impl Into<String>,
        stability: ApiStabilityTier,
        version: ProjectVersion,
    ) -> Result<Self> {
        Ok(Self {
            kind,
            name: validate_non_empty(name, "public surface name")?,
            stability,
            version,
        })
    }
    pub const fn is_stable(&self) -> bool {
        matches!(
            self.stability,
            ApiStabilityTier::Stable | ApiStabilityTier::Deprecated
        )
    }
    pub const fn allows_breaking_changes(&self) -> bool {
        self.stability.allows_breaking_changes()
    }
    pub fn summary(&self) -> String {
        format!(
            "{} {} ({}, v{})",
            self.kind.as_str(),
            self.name,
            self.stability.as_str(),
            self.version.summary()
        )
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SchemaStability {
    Unversioned,
    ExperimentalVersioned,
    StableVersioned,
    Deprecated,
}
as_str_enum!(SchemaStability{Unversioned=>"unversioned",ExperimentalVersioned=>"experimental_versioned",StableVersioned=>"stable_versioned",Deprecated=>"deprecated"});
impl SchemaStability {
    pub const fn is_versioned(&self) -> bool {
        matches!(self, Self::ExperimentalVersioned | Self::StableVersioned)
    }
    pub const fn is_stable(&self) -> bool {
        matches!(self, Self::StableVersioned)
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MachineReadableSchemaKind {
    Diagnostics,
    Capabilities,
    ExplainReport,
    EstimateReport,
    DoctorReport,
    TranslationReport,
    BenchmarkReport,
    ExtensionManifest,
    PlanIr,
    OutputEnvelope,
    Unknown,
}
as_str_enum!(MachineReadableSchemaKind{Diagnostics=>"diagnostics",Capabilities=>"capabilities",ExplainReport=>"explain_report",EstimateReport=>"estimate_report",DoctorReport=>"doctor_report",TranslationReport=>"translation_report",BenchmarkReport=>"benchmark_report",ExtensionManifest=>"extension_manifest",PlanIr=>"plan_ir",OutputEnvelope=>"output_envelope",Unknown=>"unknown"});
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SchemaCompatibilityPlan {
    pub kind: MachineReadableSchemaKind,
    pub stability: SchemaStability,
    pub version: Option<ProjectVersion>,
    pub breaking_change_allowed: bool,
}
impl SchemaCompatibilityPlan {
    pub fn experimental(kind: MachineReadableSchemaKind) -> Self {
        Self {
            kind,
            stability: SchemaStability::ExperimentalVersioned,
            version: None,
            breaking_change_allowed: true,
        }
    }
    pub fn stable(kind: MachineReadableSchemaKind, version: ProjectVersion) -> Self {
        Self {
            kind,
            stability: SchemaStability::StableVersioned,
            version: Some(version),
            breaking_change_allowed: false,
        }
    }
    pub const fn allows_breaking_change(&self) -> bool {
        self.breaking_change_allowed
    }
    pub fn summary(&self) -> String {
        format!(
            "{} {} breaking_change_allowed={}",
            self.kind.as_str(),
            self.stability.as_str(),
            self.breaking_change_allowed
        )
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PackageTargetKind {
    CratesIo,
    PyPi,
    Npm,
    DockerHub,
    Ghcr,
    GitHubRelease,
    DocumentationSite,
    LocalArtifact,
    Unknown,
}
as_str_enum!(PackageTargetKind{CratesIo=>"crates_io",PyPi=>"pypi",Npm=>"npm",DockerHub=>"docker_hub",Ghcr=>"ghcr",GitHubRelease=>"github_release",DocumentationSite=>"documentation_site",LocalArtifact=>"local_artifact",Unknown=>"unknown"});
impl PackageTargetKind {
    pub const fn requires_external_publish(&self) -> bool {
        matches!(
            self,
            Self::CratesIo
                | Self::PyPi
                | Self::Npm
                | Self::DockerHub
                | Self::Ghcr
                | Self::GitHubRelease
                | Self::DocumentationSite
        )
    }
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PackageTarget {
    pub kind: PackageTargetKind,
    pub name: String,
    pub enabled: bool,
    pub publish_allowed: bool,
}
impl PackageTarget {
    pub fn planned(kind: PackageTargetKind, name: impl Into<String>) -> Result<Self> {
        Ok(Self {
            kind,
            name: validate_non_empty(name, "package target name")?,
            enabled: true,
            publish_allowed: false,
        })
    }
    pub fn disabled(kind: PackageTargetKind, name: impl Into<String>) -> Result<Self> {
        Ok(Self {
            kind,
            name: validate_non_empty(name, "package target name")?,
            enabled: false,
            publish_allowed: false,
        })
    }
    pub fn allow_publish(mut self, value: bool) -> Self {
        self.publish_allowed = value;
        self
    }
    pub const fn requires_human_approval(&self) -> bool {
        self.kind.requires_external_publish()
    }
    pub fn summary(&self) -> String {
        format!(
            "{} {} enabled={} publish_allowed={}",
            self.kind.as_str(),
            self.name,
            self.enabled,
            self.publish_allowed
        )
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ReleaseArtifactKind {
    RustCrate,
    PythonWheel,
    SourceTarball,
    ContainerImage,
    CliBinary,
    Documentation,
    BenchmarkReport,
    Sbom,
    Checksum,
    Signature,
    ProvenanceAttestation,
    Unknown,
}
as_str_enum!(ReleaseArtifactKind{RustCrate=>"rust_crate",PythonWheel=>"python_wheel",SourceTarball=>"source_tarball",ContainerImage=>"container_image",CliBinary=>"cli_binary",Documentation=>"documentation",BenchmarkReport=>"benchmark_report",Sbom=>"sbom",Checksum=>"checksum",Signature=>"signature",ProvenanceAttestation=>"provenance_attestation",Unknown=>"unknown"});
impl ReleaseArtifactKind {
    pub const fn is_supply_chain_artifact(&self) -> bool {
        matches!(
            self,
            Self::Sbom | Self::Checksum | Self::Signature | Self::ProvenanceAttestation
        )
    }
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ReleaseArtifactPlan {
    pub kind: ReleaseArtifactKind,
    pub name: String,
    pub target: Option<PackageTargetKind>,
    pub built: bool,
    pub published: bool,
}
impl ReleaseArtifactPlan {
    pub fn planned(kind: ReleaseArtifactKind, name: impl Into<String>) -> Result<Self> {
        Ok(Self {
            kind,
            name: validate_non_empty(name, "artifact name")?,
            target: None,
            built: false,
            published: false,
        })
    }
    pub fn with_target(mut self, target: PackageTargetKind) -> Self {
        self.target = Some(target);
        self
    }
    pub fn mark_built(mut self, built: bool) -> Self {
        self.built = built;
        self
    }
    pub fn mark_published(mut self, published: bool) -> Self {
        self.published = published;
        self
    }
    pub fn summary(&self) -> String {
        format!(
            "{} {} built={} published={}",
            self.kind.as_str(),
            self.name,
            self.built,
            self.published
        )
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DependencyLicenseClass {
    Apache2,
    Mit,
    Bsd,
    Isc,
    Zlib,
    UnicodeLike,
    Mpl2ReviewRequired,
    UnknownReviewRequired,
    Incompatible,
}
as_str_enum!(DependencyLicenseClass{Apache2=>"apache2",Mit=>"mit",Bsd=>"bsd",Isc=>"isc",Zlib=>"zlib",UnicodeLike=>"unicode_like",Mpl2ReviewRequired=>"mpl2_review_required",UnknownReviewRequired=>"unknown_review_required",Incompatible=>"incompatible"});
impl DependencyLicenseClass {
    pub const fn is_apache_compatible_candidate(&self) -> bool {
        matches!(
            self,
            Self::Apache2 | Self::Mit | Self::Bsd | Self::Isc | Self::Zlib | Self::UnicodeLike
        )
    }
    pub const fn requires_review(&self) -> bool {
        matches!(
            self,
            Self::Mpl2ReviewRequired | Self::UnknownReviewRequired | Self::Incompatible
        )
    }
    pub const fn is_incompatible(&self) -> bool {
        matches!(self, Self::Incompatible)
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DependencyReviewStatus {
    NotNeeded,
    Pending,
    Approved,
    Rejected,
    RequiresLegalReview,
    Unknown,
}
as_str_enum!(DependencyReviewStatus{NotNeeded=>"not_needed",Pending=>"pending",Approved=>"approved",Rejected=>"rejected",RequiresLegalReview=>"requires_legal_review",Unknown=>"unknown"});
impl DependencyReviewStatus {
    pub const fn is_blocking(&self) -> bool {
        matches!(
            self,
            Self::Rejected | Self::RequiresLegalReview | Self::Pending | Self::Unknown
        )
    }
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DependencyReview {
    pub name: String,
    pub license: DependencyLicenseClass,
    pub status: DependencyReviewStatus,
    pub notes: Option<String>,
}
impl DependencyReview {
    pub fn new(name: impl Into<String>, license: DependencyLicenseClass) -> Result<Self> {
        Ok(Self {
            name: validate_non_empty(name, "dependency name")?,
            license,
            status: DependencyReviewStatus::Pending,
            notes: None,
        })
    }
    pub fn with_status(mut self, status: DependencyReviewStatus) -> Self {
        self.status = status;
        self
    }
    pub fn with_notes(mut self, notes: impl Into<String>) -> Self {
        self.notes = Some(notes.into());
        self
    }
    pub const fn is_blocking(&self) -> bool {
        self.status.is_blocking() || self.license.is_incompatible()
    }
    pub fn summary(&self) -> String {
        format!(
            "{} {} {}",
            self.name,
            self.license.as_str(),
            self.status.as_str()
        )
    }
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NoFallbackReleaseCheck {
    pub spark_dependency_present: bool,
    pub datafusion_dependency_present: bool,
    pub duckdb_polars_velox_fallback_present: bool,
    pub fallback_execution_allowed: bool,
    pub docs_imply_fallback: bool,
}
impl NoFallbackReleaseCheck {
    pub const fn clean() -> Self {
        Self {
            spark_dependency_present: false,
            datafusion_dependency_present: false,
            duckdb_polars_velox_fallback_present: false,
            fallback_execution_allowed: false,
            docs_imply_fallback: false,
        }
    }
    pub const fn is_clean(&self) -> bool {
        !self.spark_dependency_present
            && !self.datafusion_dependency_present
            && !self.duckdb_polars_velox_fallback_present
            && !self.fallback_execution_allowed
            && !self.docs_imply_fallback
    }
    pub fn summary(&self) -> String {
        if self.is_clean() {
            "no-fallback check clean; fallback execution disabled".to_string()
        } else {
            "no-fallback check has policy violations".to_string()
        }
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ReleaseChecklistItemKind {
    TestsPass,
    FormattingPasses,
    ClippyPasses,
    DocsUpdated,
    LicenseMetadataCorrect,
    NoticeUpdated,
    DependencyLicensesReviewed,
    SecurityReview,
    NoFallbackDependency,
    VersionBumped,
    ReleaseNotesWritten,
    BenchmarkClaimsVerified,
    PackagesBuilt,
    ChecksumsGenerated,
    ArtifactsSigned,
    HumanApproval,
    Unknown,
}
as_str_enum!(ReleaseChecklistItemKind{TestsPass=>"tests_pass",FormattingPasses=>"formatting_passes",ClippyPasses=>"clippy_passes",DocsUpdated=>"docs_updated",LicenseMetadataCorrect=>"license_metadata_correct",NoticeUpdated=>"notice_updated",DependencyLicensesReviewed=>"dependency_licenses_reviewed",SecurityReview=>"security_review",NoFallbackDependency=>"no_fallback_dependency",VersionBumped=>"version_bumped",ReleaseNotesWritten=>"release_notes_written",BenchmarkClaimsVerified=>"benchmark_claims_verified",PackagesBuilt=>"packages_built",ChecksumsGenerated=>"checksums_generated",ArtifactsSigned=>"artifacts_signed",HumanApproval=>"human_approval",Unknown=>"unknown"});
impl ReleaseChecklistItemKind {
    pub const fn is_required_before_publish(&self) -> bool {
        matches!(
            self,
            Self::HumanApproval
                | Self::TestsPass
                | Self::FormattingPasses
                | Self::ClippyPasses
                | Self::LicenseMetadataCorrect
                | Self::DependencyLicensesReviewed
                | Self::NoFallbackDependency
                | Self::VersionBumped
        )
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ChecklistStatus {
    NotStarted,
    Passed,
    Failed,
    Waived,
    NotApplicable,
}
as_str_enum!(ChecklistStatus{NotStarted=>"not_started",Passed=>"passed",Failed=>"failed",Waived=>"waived",NotApplicable=>"not_applicable"});
impl ChecklistStatus {
    pub const fn is_blocking(&self) -> bool {
        matches!(self, Self::NotStarted | Self::Failed)
    }
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ReleaseChecklistItem {
    pub kind: ReleaseChecklistItemKind,
    pub status: ChecklistStatus,
    pub notes: Option<String>,
}
impl ReleaseChecklistItem {
    pub const fn new(kind: ReleaseChecklistItemKind) -> Self {
        Self {
            kind,
            status: ChecklistStatus::NotStarted,
            notes: None,
        }
    }
    pub fn with_status(mut self, status: ChecklistStatus) -> Self {
        self.status = status;
        self
    }
    pub fn with_notes(mut self, notes: impl Into<String>) -> Self {
        self.notes = Some(notes.into());
        self
    }
    pub const fn is_blocking(&self) -> bool {
        self.kind.is_required_before_publish() && self.status.is_blocking()
    }
    pub fn summary(&self) -> String {
        format!("{} {}", self.kind.as_str(), self.status.as_str())
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ReleaseReadinessStatus {
    Draft,
    Blocked,
    ReadyForReview,
    ReadyForRelease,
    Released,
    Unsupported,
}
as_str_enum!(ReleaseReadinessStatus{Draft=>"draft",Blocked=>"blocked",ReadyForReview=>"ready_for_review",ReadyForRelease=>"ready_for_release",Released=>"released",Unsupported=>"unsupported"});
impl ReleaseReadinessStatus {
    pub const fn allows_publish(&self) -> bool {
        matches!(self, Self::ReadyForRelease)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ReleaseEvidenceRequirementKind {
    SchemaVersion,
    ApiStability,
    DependencyLicense,
    Sbom,
    ProvenanceAttestation,
    ReproducibleBuild,
    ReleaseNotes,
    BenchmarkAccountability,
    NoFallback,
    HumanApproval,
}
as_str_enum!(ReleaseEvidenceRequirementKind{SchemaVersion=>"schema_version",ApiStability=>"api_stability",DependencyLicense=>"dependency_license",Sbom=>"sbom",ProvenanceAttestation=>"provenance_attestation",ReproducibleBuild=>"reproducible_build",ReleaseNotes=>"release_notes",BenchmarkAccountability=>"benchmark_accountability",NoFallback=>"no_fallback",HumanApproval=>"human_approval"});

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ReleaseEvidenceRequirementStatus {
    Present,
    Planned,
    Missing,
    Blocked,
    NotApplicable,
}
as_str_enum!(ReleaseEvidenceRequirementStatus{Present=>"present",Planned=>"planned",Missing=>"missing",Blocked=>"blocked",NotApplicable=>"not_applicable"});
impl ReleaseEvidenceRequirementStatus {
    pub const fn satisfies_release_gate(&self) -> bool {
        matches!(self, Self::Present | Self::NotApplicable)
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ReleaseEvidenceRequirement {
    pub kind: ReleaseEvidenceRequirementKind,
    pub status: ReleaseEvidenceRequirementStatus,
    pub required_before_publication: bool,
    pub evidence_ref: Option<String>,
    pub diagnostic: Option<String>,
}
impl ReleaseEvidenceRequirement {
    pub fn new(
        kind: ReleaseEvidenceRequirementKind,
        status: ReleaseEvidenceRequirementStatus,
        required_before_publication: bool,
    ) -> Self {
        Self {
            kind,
            status,
            required_before_publication,
            evidence_ref: None,
            diagnostic: None,
        }
    }
    pub fn with_evidence_ref(mut self, evidence_ref: impl Into<String>) -> Self {
        self.evidence_ref = Some(evidence_ref.into());
        self
    }
    pub fn with_diagnostic(mut self, diagnostic: impl Into<String>) -> Self {
        self.diagnostic = Some(diagnostic.into());
        self
    }
    pub const fn is_blocking(&self) -> bool {
        self.required_before_publication && !self.status.satisfies_release_gate()
    }
    pub fn summary(&self) -> String {
        format!(
            "{} {} required_before_publication={}",
            self.kind.as_str(),
            self.status.as_str(),
            self.required_before_publication
        )
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct ReleasePublicationApiSchemaGateRow {
    pub gate_id: &'static str,
    pub current_status: &'static str,
    pub required_evidence: &'static str,
    pub evidence_ref: &'static str,
    pub blocker: &'static str,
    pub required_before_publication: bool,
    pub public_release_claim_allowed: bool,
    pub public_package_claim_allowed: bool,
    pub package_publication_performed: bool,
    pub tag_created: bool,
    pub signing_key_used: bool,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

impl ReleasePublicationApiSchemaGateRow {
    const fn blocked(
        gate_id: &'static str,
        current_status: &'static str,
        required_evidence: &'static str,
        evidence_ref: &'static str,
        blocker: &'static str,
    ) -> Self {
        Self {
            gate_id,
            current_status,
            required_evidence,
            evidence_ref,
            blocker,
            required_before_publication: true,
            public_release_claim_allowed: false,
            public_package_claim_allowed: false,
            package_publication_performed: false,
            tag_created: false,
            signing_key_used: false,
            fallback_attempted: false,
            external_engine_invoked: false,
        }
    }

    pub fn is_blocking(&self) -> bool {
        self.required_before_publication
            && (self.current_status != "present")
            && (self.current_status != "not_applicable")
    }

    pub fn side_effect_free(&self) -> bool {
        !self.public_release_claim_allowed
            && !self.public_package_claim_allowed
            && !self.package_publication_performed
            && !self.tag_created
            && !self.signing_key_used
            && !self.fallback_attempted
            && !self.external_engine_invoked
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct ReleasePublicationApiSchemaGateReport {
    pub schema_version: &'static str,
    pub report_id: &'static str,
    pub docs_ref: &'static str,
    pub source_refs: &'static str,
    pub gate_status: &'static str,
    pub claim_gate_status: &'static str,
    pub rows: Vec<ReleasePublicationApiSchemaGateRow>,
    pub api_schema_stability_claim_allowed: bool,
    pub public_release_claim_allowed: bool,
    pub public_package_claim_allowed: bool,
    pub package_publication_performed: bool,
    pub tag_created: bool,
    pub signing_key_used: bool,
    pub checksum_manifest_publication_grade: bool,
    pub sbom_publication_grade: bool,
    pub runtime_execution: bool,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

impl ReleasePublicationApiSchemaGateReport {
    pub fn foundation() -> Self {
        let rows = vec![
            ReleasePublicationApiSchemaGateRow::blocked(
                "api_compatibility_window",
                "blocked",
                "published API stability tiers, compatibility window, deprecation policy, breaking-change approval",
                "ReleasePlan.public_surfaces; docs/rfcs/0024-release-engineering-api-compatibility-packaging.md",
                "current CLI/Rust/Python surfaces are experimental and do not have a public compatibility window",
            ),
            ReleasePublicationApiSchemaGateRow::blocked(
                "schema_compatibility_window",
                "blocked",
                "schema version registry, compatibility window, migration notes, golden fixtures",
                "ReleasePlan.schemas; typed-envelope contract fixtures",
                "machine-readable schemas are versioned/experimental but not approved as stable public contracts",
            ),
            ReleasePublicationApiSchemaGateRow::blocked(
                "package_identity_approval",
                "approved_pending_channel_proof",
                "approved package identities, channel ownership, naming, install/uninstall/rollback proof",
                "docs/release/package-channel-readiness-matrix.json",
                "GitHub/TestPyPI/PyPI/Homebrew are approved for v0.1.0 but still lack publication and install proof",
            ),
            ReleasePublicationApiSchemaGateRow::blocked(
                "signing_policy_decision",
                "blocked",
                "artifact signing policy, maintainer approval, key custody, signing workflow evidence",
                "docs/release/release-provenance-dry-run.md",
                "no signing key may be used and no signing mechanism is approved before publication",
            ),
            ReleasePublicationApiSchemaGateRow::blocked(
                "checksum_manifest",
                "dry_run_only",
                "publication-grade checksum manifest tied to release artifacts and source revision",
                "target/release-provenance-dry-run/checksums.sha256",
                "local dry-run checksum evidence exists, but publication-grade checksums are not attached",
            ),
            ReleasePublicationApiSchemaGateRow::blocked(
                "sbom_bundle",
                "dry_run_only",
                "publication-grade Rust, Python, CLI, and optional image SBOM bundle",
                "docs/release/sbom-generation-plan.md",
                "local dry-run SBOM evidence exists, but publication-grade SBOM approval is missing",
            ),
            ReleasePublicationApiSchemaGateRow::blocked(
                "publication_approval",
                "approved_pending_channel_proof",
                "explicit maintainer approval, release notes, tag approval, package-channel gate pass",
                "docs/release/hard-release-readiness-gate.md",
                "maintainer approval exists for the v0.1.0 GitHub, TestPyPI, PyPI, and Homebrew sequence; channel publication, install proof, and post-release verification remain pending",
            ),
        ];
        Self {
            schema_version: "shardloom.publication_api_schema_stability_gate.v1",
            report_id: "gar-0024-a.publication_api_schema_stability_gate",
            docs_ref: "docs/release/publication-api-schema-stability-gate.md",
            source_refs: "RFC 0024; release readiness gate; package-channel matrix; provenance dry run",
            gate_status: "blocked",
            claim_gate_status: "not_claim_grade",
            rows,
            api_schema_stability_claim_allowed: false,
            public_release_claim_allowed: false,
            public_package_claim_allowed: false,
            package_publication_performed: false,
            tag_created: false,
            signing_key_used: false,
            checksum_manifest_publication_grade: false,
            sbom_publication_grade: false,
            runtime_execution: false,
            fallback_attempted: false,
            external_engine_invoked: false,
        }
    }

    pub fn blocking_row_count(&self) -> usize {
        self.rows.iter().filter(|row| row.is_blocking()).count()
    }

    pub fn row_ids(&self) -> Vec<&'static str> {
        self.rows.iter().map(|row| row.gate_id).collect()
    }

    pub fn fails_closed(&self) -> bool {
        self.gate_status == "blocked"
            && self.claim_gate_status == "not_claim_grade"
            && self.blocking_row_count() > 0
            && !self.api_schema_stability_claim_allowed
            && !self.public_release_claim_allowed
            && !self.public_package_claim_allowed
    }

    pub fn side_effect_free(&self) -> bool {
        !self.package_publication_performed
            && !self.tag_created
            && !self.signing_key_used
            && !self.runtime_execution
            && !self.fallback_attempted
            && !self.external_engine_invoked
            && self
                .rows
                .iter()
                .all(ReleasePublicationApiSchemaGateRow::side_effect_free)
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct PerClaimEvidenceAttachmentRow {
    pub claim_id: &'static str,
    pub claim_family: &'static str,
    pub public_claim_language: &'static str,
    pub support_status: &'static str,
    pub required_test_evidence: &'static str,
    pub required_benchmark_evidence: &'static str,
    pub required_certificate_evidence: &'static str,
    pub required_native_io_evidence: &'static str,
    pub required_security_evidence: &'static str,
    pub required_provenance_evidence: &'static str,
    pub required_unsupported_path_evidence: &'static str,
    pub required_no_fallback_evidence: &'static str,
    pub required_release_approval: &'static str,
    pub current_attachment_ref: &'static str,
    pub missing_evidence: &'static str,
    pub attachment_status: &'static str,
    pub claim_gate_status: &'static str,
    pub test_evidence_attached: bool,
    pub benchmark_evidence_attached: bool,
    pub certificate_evidence_attached: bool,
    pub native_io_evidence_attached: bool,
    pub security_evidence_attached: bool,
    pub provenance_evidence_attached: bool,
    pub unsupported_path_evidence_attached: bool,
    pub no_fallback_evidence_attached: bool,
    pub release_approval_attached: bool,
    pub public_claim_allowed: bool,
    pub runtime_execution_performed: bool,
    pub benchmark_rerun_performed: bool,
    pub package_publication_performed: bool,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
    pub claim_boundary: &'static str,
}

impl PerClaimEvidenceAttachmentRow {
    #[allow(clippy::too_many_arguments)]
    const fn blocked(
        claim_id: &'static str,
        claim_family: &'static str,
        public_claim_language: &'static str,
        required_test_evidence: &'static str,
        required_benchmark_evidence: &'static str,
        required_certificate_evidence: &'static str,
        required_native_io_evidence: &'static str,
        required_security_evidence: &'static str,
        required_provenance_evidence: &'static str,
        required_unsupported_path_evidence: &'static str,
        required_no_fallback_evidence: &'static str,
        required_release_approval: &'static str,
        current_attachment_ref: &'static str,
        missing_evidence: &'static str,
        claim_boundary: &'static str,
    ) -> Self {
        Self {
            claim_id,
            claim_family,
            public_claim_language,
            support_status: "blocked",
            required_test_evidence,
            required_benchmark_evidence,
            required_certificate_evidence,
            required_native_io_evidence,
            required_security_evidence,
            required_provenance_evidence,
            required_unsupported_path_evidence,
            required_no_fallback_evidence,
            required_release_approval,
            current_attachment_ref,
            missing_evidence,
            attachment_status: "missing_required_evidence",
            claim_gate_status: "not_claim_grade",
            test_evidence_attached: false,
            benchmark_evidence_attached: false,
            certificate_evidence_attached: false,
            native_io_evidence_attached: false,
            security_evidence_attached: false,
            provenance_evidence_attached: false,
            unsupported_path_evidence_attached: false,
            no_fallback_evidence_attached: false,
            release_approval_attached: false,
            public_claim_allowed: false,
            runtime_execution_performed: false,
            benchmark_rerun_performed: false,
            package_publication_performed: false,
            fallback_attempted: false,
            external_engine_invoked: false,
            claim_boundary,
        }
    }

    pub fn missing_required_attachment_count(&self) -> usize {
        [
            self.test_evidence_attached,
            self.benchmark_evidence_attached,
            self.certificate_evidence_attached,
            self.native_io_evidence_attached,
            self.security_evidence_attached,
            self.provenance_evidence_attached,
            self.unsupported_path_evidence_attached,
            self.no_fallback_evidence_attached,
            self.release_approval_attached,
        ]
        .into_iter()
        .filter(|attached| !*attached)
        .count()
    }

    pub fn all_required_categories_named(&self) -> bool {
        [
            self.required_test_evidence,
            self.required_benchmark_evidence,
            self.required_certificate_evidence,
            self.required_native_io_evidence,
            self.required_security_evidence,
            self.required_provenance_evidence,
            self.required_unsupported_path_evidence,
            self.required_no_fallback_evidence,
            self.required_release_approval,
        ]
        .into_iter()
        .all(|value| !value.trim().is_empty())
    }

    pub fn is_blocking(&self) -> bool {
        self.claim_gate_status == "not_claim_grade"
            || self.missing_required_attachment_count() > 0
            || !self.public_claim_allowed
    }

    pub fn side_effect_free(&self) -> bool {
        !self.public_claim_allowed
            && !self.runtime_execution_performed
            && !self.benchmark_rerun_performed
            && !self.package_publication_performed
            && !self.fallback_attempted
            && !self.external_engine_invoked
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct PerClaimEvidenceAttachmentMatrixReport {
    pub schema_version: &'static str,
    pub report_id: &'static str,
    pub docs_ref: &'static str,
    pub source_refs: &'static str,
    pub support_status: &'static str,
    pub claim_gate_status: &'static str,
    pub rows: Vec<PerClaimEvidenceAttachmentRow>,
    pub test_evidence_required: bool,
    pub benchmark_evidence_required: bool,
    pub certificate_evidence_required: bool,
    pub native_io_evidence_required: bool,
    pub security_evidence_required: bool,
    pub provenance_evidence_required: bool,
    pub unsupported_path_evidence_required: bool,
    pub no_fallback_evidence_required: bool,
    pub release_approval_required: bool,
    pub public_release_claim_allowed: bool,
    pub public_package_claim_allowed: bool,
    pub performance_claim_allowed: bool,
    pub superiority_claim_allowed: bool,
    pub spark_displacement_claim_allowed: bool,
    pub production_claim_allowed: bool,
    pub package_publication_performed: bool,
    pub runtime_execution_performed: bool,
    pub benchmark_rerun_performed: bool,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

impl PerClaimEvidenceAttachmentMatrixReport {
    pub fn fail_closed() -> Self {
        Self {
            schema_version: "shardloom.per_claim_evidence_attachment_matrix.v1",
            report_id: "gar-0041-a.per_claim_evidence_attachment_matrix",
            docs_ref: "docs/release/per-claim-evidence-attachment-matrix.md",
            source_refs: "RFC 0041; workspace feature build matrix; release security gate; hard release readiness gate; engine replacement claim inventory",
            support_status: "blocked",
            claim_gate_status: "not_claim_grade",
            rows: per_claim_evidence_attachment_rows(),
            test_evidence_required: true,
            benchmark_evidence_required: true,
            certificate_evidence_required: true,
            native_io_evidence_required: true,
            security_evidence_required: true,
            provenance_evidence_required: true,
            unsupported_path_evidence_required: true,
            no_fallback_evidence_required: true,
            release_approval_required: true,
            public_release_claim_allowed: false,
            public_package_claim_allowed: false,
            performance_claim_allowed: false,
            superiority_claim_allowed: false,
            spark_displacement_claim_allowed: false,
            production_claim_allowed: false,
            package_publication_performed: false,
            runtime_execution_performed: false,
            benchmark_rerun_performed: false,
            fallback_attempted: false,
            external_engine_invoked: false,
        }
    }

    pub fn row_ids(&self) -> Vec<&'static str> {
        self.rows.iter().map(|row| row.claim_id).collect()
    }

    pub fn blocking_row_count(&self) -> usize {
        self.rows.iter().filter(|row| row.is_blocking()).count()
    }

    pub fn total_missing_attachment_count(&self) -> usize {
        self.rows
            .iter()
            .map(PerClaimEvidenceAttachmentRow::missing_required_attachment_count)
            .sum()
    }

    pub fn all_required_categories_named(&self) -> bool {
        self.rows
            .iter()
            .all(PerClaimEvidenceAttachmentRow::all_required_categories_named)
    }

    pub fn all_claims_blocked(&self) -> bool {
        self.claim_gate_status == "not_claim_grade"
            && !self.public_release_claim_allowed
            && !self.public_package_claim_allowed
            && !self.performance_claim_allowed
            && !self.superiority_claim_allowed
            && !self.spark_displacement_claim_allowed
            && !self.production_claim_allowed
            && self.rows.iter().all(|row| !row.public_claim_allowed)
    }

    pub fn side_effect_free(&self) -> bool {
        !self.package_publication_performed
            && !self.runtime_execution_performed
            && !self.benchmark_rerun_performed
            && !self.fallback_attempted
            && !self.external_engine_invoked
            && self
                .rows
                .iter()
                .all(PerClaimEvidenceAttachmentRow::side_effect_free)
    }
}

pub fn plan_per_claim_evidence_attachment_matrix() -> PerClaimEvidenceAttachmentMatrixReport {
    PerClaimEvidenceAttachmentMatrixReport::fail_closed()
}

#[allow(clippy::too_many_lines)]
fn per_claim_evidence_attachment_rows() -> Vec<PerClaimEvidenceAttachmentRow> {
    vec![
        PerClaimEvidenceAttachmentRow::blocked(
            "public_release_claim",
            "release",
            "ShardLoom public release is ready",
            "workspace validation command evidence and release readiness tests",
            "benchmark smoke and benchmark artifact completeness evidence",
            "release readiness certificate and command-envelope contract snapshots",
            "Native I/O source/sink certificate refs for released workflows",
            "release security gate, dependency audit, vulnerability response, CodeQL/Scorecard posture",
            "SBOM, checksum, provenance dry run, package-channel provenance",
            "known unsupported paths and global architecture claim gate",
            "fallback_attempted=false and external_engine_invoked=false release fields",
            "maintainer approval and release notes",
            "docs/release/hard-release-readiness-gate.md",
            "release_validation,benchmark_smoke,certificates,native_io,security,provenance,unsupported_paths,approval",
            "No public release-readiness claim is allowed until every release gate row has attached passing evidence.",
        ),
        PerClaimEvidenceAttachmentRow::blocked(
            "public_package_claim",
            "package",
            "ShardLoom packages are publicly ready",
            "clean install, uninstall, rollback/yank, and smoke tests per package channel",
            "package-channel smoke benchmark evidence",
            "package artifact certificate and install transcript",
            "source/sink Native I/O evidence for packaged CLI/Python smoke paths",
            "dependency audit, package metadata audit, and trusted publishing posture",
            "SBOM, checksums, OIDC/Trusted Publisher, attestation refs",
            "known unsupported package/runtime paths",
            "no fallback runtime dependency and no external engine dependency evidence",
            "human channel approval for PyPI/TestPyPI/Homebrew/Scoop/winget/conda/GHCR",
            "docs/release/package-channel-readiness-matrix.json",
            "channel_clean_install,channel_smoke,sbom,checksums,provenance,rollback,human_approval",
            "Package access does not imply production readiness, and no public package claim is allowed without channel proof.",
        ),
        PerClaimEvidenceAttachmentRow::blocked(
            "performance_superiority_claim",
            "benchmark",
            "ShardLoom is faster or superior",
            "workload-specific correctness and regression tests",
            "claim-grade full-local benchmark profile with complete competitor lanes and versions",
            "execution certificate and materialization/decode certificate refs",
            "Native I/O certificate refs for every measured source and sink",
            "benchmark artifact safety and release security refs",
            "artifact provenance, environment fingerprint, and reproducible command refs",
            "unsupported scenario rows and unavailable competitor lane reasons",
            "external baselines are comparison-only and never fallback",
            "human approval for exact claim language",
            "docs/architecture/benchmark-competitive-claim-evidence.md",
            "claim_grade_benchmark,environment,competitor_lanes,correctness,certificates,native_io,approval",
            "Performance and superiority claims remain blocked; benchmark pages are evidence, not leaderboards.",
        ),
        PerClaimEvidenceAttachmentRow::blocked(
            "spark_displacement_claim",
            "spark_displacement",
            "ShardLoom replaces Spark",
            "Spark-displacement semantic correctness, scale, and workload tests",
            "full_local_plus_spark benchmark profile with Spark default/tuned lanes",
            "scale, execution, materialization, and output certificates",
            "Native I/O certificate refs for local, object-store, table, and output paths",
            "release security gate and dependency audit evidence",
            "benchmark manifest provenance and reproducibility refs",
            "explicit unsupported distributed/object-store/table/Foundry rows",
            "Spark rows are external_baseline_only and never fallback",
            "maintainer approval for exact non-displacement wording",
            "docs/architecture/spark-displacement-benchmark-evidence-matrix.md",
            "spark_profile,scale_runtime,shuffle_spill_commit,object_store_table_runtime,per_claim_approval",
            "Spark replacement or displacement language is blocked.",
        ),
        PerClaimEvidenceAttachmentRow::blocked(
            "engine_replacement_claim",
            "engine_replacement",
            "ShardLoom replaces existing engines generally",
            "broad local runtime, SQL/DataFrame, adapter, output, and session tests",
            "full competitor registry artifact and workload-scoped benchmark profiles",
            "execution envelope, capability, and workload certificates",
            "Native I/O certificate refs for every claimed adapter/source/sink",
            "security, effect, dependency, and unsupported-path gates",
            "release/package provenance and benchmark artifact provenance",
            "capability matrix rows for unsupported adapters and operators",
            "no external engine fallback and external baselines comparison-only",
            "release gate and claim-language approval",
            "docs/architecture/engine-replacement-claim-inventory.md",
            "runtime_surface,adapters,outputs,benchmarks,certificates,native_io,release_gate",
            "General engine-replacement language remains blocked until exact workload evidence exists.",
        ),
        PerClaimEvidenceAttachmentRow::blocked(
            "production_sql_dataframe_claim",
            "sql_dataframe",
            "ShardLoom has production SQL/DataFrame support",
            "parser, binder, planner, optimizer, operator, type/null, and API tests",
            "SQL/DataFrame benchmark profile and scenario coverage",
            "SQL/DataFrame execution certificates and plan digest refs",
            "Native I/O certificate refs for SQL/DataFrame input and output paths",
            "release security gate and API compatibility refs",
            "package/API provenance and schema stability refs",
            "unsupported SQL/DataFrame diagnostics and capability matrix rows",
            "no external SQL/DataFrame engine fallback",
            "production claim approval and compatibility window",
            "docs/architecture/global-architecture-review.md#rfc-0032---world-class-sqloperatorsfunctionsadaptersuser-capability",
            "sql_dataframe_runtime,semantic_conformance,operator_coverage,api_stability,release_gate",
            "Production SQL/DataFrame claims remain blocked.",
        ),
        PerClaimEvidenceAttachmentRow::blocked(
            "object_store_lakehouse_claim",
            "object_store_lakehouse",
            "ShardLoom supports production object-store or lakehouse runtime",
            "credential, network, byte-range, write, commit, retry, and table-format tests",
            "object_store_optional and table_runtime benchmark/scale evidence",
            "object-store/table execution, commit, rollback, and idempotency certificates",
            "object-store/table Native I/O certificate refs",
            "credential policy, network effect, secret redaction, and security refs",
            "artifact provenance, commit manifest, and rollback evidence",
            "blocked/report-only rows for unsupported stores and table operations",
            "no fallback engine and no hidden external query service",
            "human approval for exact object-store/table support claim",
            "docs/architecture/scale-readiness-contract.md",
            "object_store_read_write,table_commit,credential_policy,network_policy,scale_evidence",
            "Object-store and lakehouse production claims remain blocked.",
        ),
        PerClaimEvidenceAttachmentRow::blocked(
            "foundry_platform_claim",
            "foundry",
            "ShardLoom is Foundry-ready or managed-platform certified",
            "real Foundry/dev-stack transform, package resolution, and output dataset tests",
            "Foundry proof and managed-platform benchmark profile evidence",
            "Foundry execution, generated-source, output, and evidence-dataset certificates",
            "Foundry input/output Native I/O or platform dataset certificate refs",
            "credential, governance, secret, package, and platform security evidence",
            "package/channel provenance and platform environment fingerprint",
            "blocked rows for Spark/Foundry compute, S3 shortcuts, Marketplace, and F10",
            "foundry_spark_invoked=false and external_engine_invoked=false evidence",
            "human approval for exact Foundry/platform wording",
            "docs/foundry/proof-of-use-certification.md",
            "foundry_runtime_proof,output_dataset,evidence_dataset,package_resolution,platform_approval",
            "Foundry and managed platforms remain validation targets only; no production or endorsement claim is allowed.",
        ),
    ]
}

#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct EngineReplacementClaimInventoryRow {
    pub claim_id: &'static str,
    pub claim_family: &'static str,
    pub claim_language: &'static str,
    pub support_status: &'static str,
    pub required_runtime_evidence: &'static str,
    pub required_output_evidence: &'static str,
    pub required_correctness_evidence: &'static str,
    pub required_benchmark_evidence: &'static str,
    pub required_execution_certificate_evidence: &'static str,
    pub required_native_io_evidence: &'static str,
    pub required_no_fallback_evidence: &'static str,
    pub release_gate_ref: &'static str,
    pub dependency_gate_refs: &'static str,
    pub missing_evidence: &'static str,
    pub claim_gate_status: &'static str,
    pub public_claim_allowed: bool,
    pub evidence_complete: bool,
    pub runtime_execution_performed: bool,
    pub benchmark_rerun_performed: bool,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
    pub claim_boundary: &'static str,
}

impl EngineReplacementClaimInventoryRow {
    #[allow(clippy::too_many_arguments)]
    const fn blocked(
        claim_id: &'static str,
        claim_family: &'static str,
        claim_language: &'static str,
        required_runtime_evidence: &'static str,
        required_output_evidence: &'static str,
        required_correctness_evidence: &'static str,
        required_benchmark_evidence: &'static str,
        required_execution_certificate_evidence: &'static str,
        required_native_io_evidence: &'static str,
        release_gate_ref: &'static str,
        dependency_gate_refs: &'static str,
        missing_evidence: &'static str,
        claim_boundary: &'static str,
    ) -> Self {
        Self {
            claim_id,
            claim_family,
            claim_language,
            support_status: "blocked",
            required_runtime_evidence,
            required_output_evidence,
            required_correctness_evidence,
            required_benchmark_evidence,
            required_execution_certificate_evidence,
            required_native_io_evidence,
            required_no_fallback_evidence: "no_fallback_policy,external_engine_invoked_false,fallback_attempted_false,external_baseline_only_boundary",
            release_gate_ref,
            dependency_gate_refs,
            missing_evidence,
            claim_gate_status: "not_claim_grade",
            public_claim_allowed: false,
            evidence_complete: false,
            runtime_execution_performed: false,
            benchmark_rerun_performed: false,
            fallback_attempted: false,
            external_engine_invoked: false,
            claim_boundary,
        }
    }

    #[must_use]
    pub fn not_claim_grade(&self) -> bool {
        self.claim_gate_status == "not_claim_grade"
    }

    #[must_use]
    pub fn side_effect_free(&self) -> bool {
        !self.public_claim_allowed
            && !self.evidence_complete
            && !self.runtime_execution_performed
            && !self.benchmark_rerun_performed
            && !self.fallback_attempted
            && !self.external_engine_invoked
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct EngineReplacementClaimInventoryReport {
    pub schema_version: &'static str,
    pub report_id: &'static str,
    pub docs_ref: &'static str,
    pub source_refs: &'static str,
    pub support_status: &'static str,
    pub claim_gate_status: &'static str,
    pub rows: Vec<EngineReplacementClaimInventoryRow>,
    pub public_engine_replacement_claim_allowed: bool,
    pub spark_displacement_claim_allowed: bool,
    pub performance_superiority_claim_allowed: bool,
    pub best_default_claim_allowed: bool,
    pub production_platform_claim_allowed: bool,
    pub release_gate_required: bool,
    pub runtime_execution_performed: bool,
    pub benchmark_rerun_performed: bool,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

impl EngineReplacementClaimInventoryReport {
    #[must_use]
    pub fn report_only() -> Self {
        Self {
            schema_version: "shardloom.engine_replacement_claim_inventory.v1",
            report_id: "gar-0001b-a.engine_replacement_claim_inventory",
            docs_ref: "docs/architecture/engine-replacement-claim-inventory.md",
            source_refs: "docs/rfcs/0001-architecture.md,docs/rfcs/0025-competitive-engine-track-no-fallback-replacement.md,docs/architecture/benchmark-competitive-claim-evidence.md,docs/architecture/best-default-certification-gate.md,docs/architecture/workspace-feature-build-matrix.md",
            support_status: "report_only",
            claim_gate_status: "not_claim_grade",
            rows: engine_replacement_claim_inventory_rows(),
            public_engine_replacement_claim_allowed: false,
            spark_displacement_claim_allowed: false,
            performance_superiority_claim_allowed: false,
            best_default_claim_allowed: false,
            production_platform_claim_allowed: false,
            release_gate_required: true,
            runtime_execution_performed: false,
            benchmark_rerun_performed: false,
            fallback_attempted: false,
            external_engine_invoked: false,
        }
    }

    #[must_use]
    pub fn row_order(&self) -> Vec<&'static str> {
        self.rows.iter().map(|row| row.claim_id).collect()
    }

    #[must_use]
    pub fn claim_families(&self) -> Vec<&'static str> {
        self.rows.iter().map(|row| row.claim_family).collect()
    }

    #[must_use]
    pub fn missing_evidence(&self) -> Vec<&'static str> {
        self.rows.iter().map(|row| row.missing_evidence).collect()
    }

    #[must_use]
    pub fn dependency_gate_refs(&self) -> Vec<&'static str> {
        self.rows
            .iter()
            .map(|row| row.dependency_gate_refs)
            .collect()
    }

    #[must_use]
    pub fn all_rows_not_claim_grade(&self) -> bool {
        self.rows
            .iter()
            .all(EngineReplacementClaimInventoryRow::not_claim_grade)
    }

    #[must_use]
    pub fn all_rows_side_effect_free(&self) -> bool {
        self.rows
            .iter()
            .all(EngineReplacementClaimInventoryRow::side_effect_free)
    }

    #[must_use]
    pub fn all_engine_replacement_claims_blocked(&self) -> bool {
        !self.public_engine_replacement_claim_allowed
            && !self.spark_displacement_claim_allowed
            && !self.performance_superiority_claim_allowed
            && !self.best_default_claim_allowed
            && !self.production_platform_claim_allowed
            && self.claim_gate_status == "not_claim_grade"
            && self.all_rows_not_claim_grade()
    }

    #[must_use]
    pub fn side_effect_free(&self) -> bool {
        !self.runtime_execution_performed
            && !self.benchmark_rerun_performed
            && !self.fallback_attempted
            && !self.external_engine_invoked
            && self.all_rows_side_effect_free()
    }
}

#[must_use]
pub fn plan_engine_replacement_claim_inventory() -> EngineReplacementClaimInventoryReport {
    EngineReplacementClaimInventoryReport::report_only()
}

#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct CompetitiveReplacementSufficiencyGateRow {
    pub evidence_id: &'static str,
    pub evidence_family: &'static str,
    pub status: &'static str,
    pub required_evidence: &'static str,
    pub current_evidence_ref: &'static str,
    pub blocker: &'static str,
    pub claim_gate_status: &'static str,
    pub evidence_complete: bool,
    pub public_claim_allowed: bool,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

impl CompetitiveReplacementSufficiencyGateRow {
    const fn blocked(
        evidence_id: &'static str,
        evidence_family: &'static str,
        required_evidence: &'static str,
        current_evidence_ref: &'static str,
        blocker: &'static str,
    ) -> Self {
        Self {
            evidence_id,
            evidence_family,
            status: "blocked",
            required_evidence,
            current_evidence_ref,
            blocker,
            claim_gate_status: "not_claim_grade",
            evidence_complete: false,
            public_claim_allowed: false,
            fallback_attempted: false,
            external_engine_invoked: false,
        }
    }

    pub fn is_blocking(&self) -> bool {
        self.status != "present" || !self.evidence_complete || !self.public_claim_allowed
    }

    pub fn not_claim_grade(&self) -> bool {
        self.claim_gate_status == "not_claim_grade"
    }

    pub fn side_effect_free(&self) -> bool {
        !self.evidence_complete
            && !self.public_claim_allowed
            && !self.fallback_attempted
            && !self.external_engine_invoked
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
#[allow(clippy::struct_excessive_bools)]
pub struct CompetitiveReplacementSufficiencyGateReport {
    pub schema_version: &'static str,
    pub report_id: &'static str,
    pub docs_ref: &'static str,
    pub source_refs: &'static str,
    pub support_status: &'static str,
    pub claim_gate_status: &'static str,
    pub rows: Vec<CompetitiveReplacementSufficiencyGateRow>,
    pub correctness_sufficient: bool,
    pub benchmark_sufficient: bool,
    pub native_io_sufficient: bool,
    pub execution_certificate_sufficient: bool,
    pub capability_coverage_sufficient: bool,
    pub no_fallback_sufficient: bool,
    pub release_evidence_sufficient: bool,
    pub public_engine_replacement_claim_allowed: bool,
    pub spark_displacement_claim_allowed: bool,
    pub superiority_claim_allowed: bool,
    pub production_platform_claim_allowed: bool,
    pub runtime_execution_performed: bool,
    pub benchmark_rerun_performed: bool,
    pub fallback_attempted: bool,
    pub external_engine_invoked: bool,
}

impl CompetitiveReplacementSufficiencyGateReport {
    pub fn report_only() -> Self {
        Self {
            schema_version: "shardloom.competitive_replacement_sufficiency_gate.v1",
            report_id: "gar-0025-a.competitive_replacement_sufficiency_gate",
            docs_ref: "docs/architecture/competitive-replacement-sufficiency-gate.md",
            source_refs: "RFC 0025; RFC 0029; RFC 0041; engine replacement claim inventory; spark displacement benchmark evidence matrix",
            support_status: "blocked",
            claim_gate_status: "not_claim_grade",
            rows: competitive_replacement_sufficiency_rows(),
            correctness_sufficient: false,
            benchmark_sufficient: false,
            native_io_sufficient: false,
            execution_certificate_sufficient: false,
            capability_coverage_sufficient: false,
            no_fallback_sufficient: false,
            release_evidence_sufficient: false,
            public_engine_replacement_claim_allowed: false,
            spark_displacement_claim_allowed: false,
            superiority_claim_allowed: false,
            production_platform_claim_allowed: false,
            runtime_execution_performed: false,
            benchmark_rerun_performed: false,
            fallback_attempted: false,
            external_engine_invoked: false,
        }
    }

    pub fn row_ids(&self) -> Vec<&'static str> {
        self.rows.iter().map(|row| row.evidence_id).collect()
    }

    pub fn blocking_row_count(&self) -> usize {
        self.rows.iter().filter(|row| row.is_blocking()).count()
    }

    pub fn all_rows_not_claim_grade(&self) -> bool {
        self.rows
            .iter()
            .all(CompetitiveReplacementSufficiencyGateRow::not_claim_grade)
    }

    pub fn all_claims_blocked(&self) -> bool {
        !self.public_engine_replacement_claim_allowed
            && !self.spark_displacement_claim_allowed
            && !self.superiority_claim_allowed
            && !self.production_platform_claim_allowed
            && self.claim_gate_status == "not_claim_grade"
            && self.all_rows_not_claim_grade()
    }

    pub fn side_effect_free(&self) -> bool {
        !self.runtime_execution_performed
            && !self.benchmark_rerun_performed
            && !self.fallback_attempted
            && !self.external_engine_invoked
            && self
                .rows
                .iter()
                .all(CompetitiveReplacementSufficiencyGateRow::side_effect_free)
    }
}

pub fn plan_competitive_replacement_sufficiency_gate() -> CompetitiveReplacementSufficiencyGateReport
{
    CompetitiveReplacementSufficiencyGateReport::report_only()
}

fn competitive_replacement_sufficiency_rows() -> Vec<CompetitiveReplacementSufficiencyGateRow> {
    vec![
        CompetitiveReplacementSufficiencyGateRow::blocked(
            "correctness_evidence",
            "correctness",
            "CG-5 semantic conformance, differential fixtures, fuzz/property coverage, edge-case fixtures, decoded-reference linkage",
            "docs/architecture/correctness-differential-harness.md; GAR-0015-A string-property gap",
            "current correctness evidence is scoped and still has deferred fixture families",
        ),
        CompetitiveReplacementSufficiencyGateRow::blocked(
            "benchmark_evidence",
            "benchmark",
            "CG-6 full benchmark profile, complete competitor lane artifact, reproducible environment, workload-scoped timing and coverage rows",
            "docs/architecture/spark-displacement-benchmark-evidence-matrix.md; benchmarks/traditional_analytics",
            "current benchmark evidence is local/pre-release and not claim-grade for replacement language",
        ),
        CompetitiveReplacementSufficiencyGateRow::blocked(
            "native_io_evidence",
            "native_io",
            "CG-19 source/sink Native I/O certificates for every claimed input/output path",
            "docs/architecture/compute-engine-flow-reference.md; docs/architecture/global-architecture-review.md",
            "Native I/O coverage is scoped and does not cover broad local, object-store, lakehouse, or platform paths",
        ),
        CompetitiveReplacementSufficiencyGateRow::blocked(
            "execution_certificate_evidence",
            "execution_certificate",
            "CG-16 execution certificates with plan/input/output hashes, segment traces, side-effect manifest, and reproducibility metadata",
            "docs/rfcs/0029-correctness-benchmarks-execution-certificates-stateful-reuse.md",
            "execution-certificate evidence is not complete across replacement claim workloads",
        ),
        CompetitiveReplacementSufficiencyGateRow::blocked(
            "capability_coverage_evidence",
            "capability_coverage",
            "CG-20 capability coverage for SQL, operators, functions, adapters, Python/DataFrame, user workflow, and blocked unsupported paths",
            "docs/architecture/global-architecture-review.md; docs/use-cases/use-case-index.yml",
            "capability coverage is mixed ready/smoke/report-only/blocked and cannot support broad replacement claims",
        ),
        CompetitiveReplacementSufficiencyGateRow::blocked(
            "no_fallback_policy_evidence",
            "no_fallback",
            "no-fallback policy, external-baseline-only classification, dependency audit, and release no-fallback checks",
            "docs/architecture/engine-replacement-claim-inventory.md; scripts/check_release_readiness.py",
            "no-fallback policy is represented, but it cannot compensate for missing claim-grade workload evidence",
        ),
        CompetitiveReplacementSufficiencyGateRow::blocked(
            "release_publication_evidence",
            "release",
            "hard release gate, package-channel readiness, API/schema stability gate, provenance, SBOM, checksum, signing, and human approval",
            "docs/release/hard-release-readiness-gate.md; docs/release/publication-api-schema-stability-gate.md",
            "public release/package and API/schema stability gates remain blocked",
        ),
    ]
}

fn engine_replacement_claim_inventory_rows() -> Vec<EngineReplacementClaimInventoryRow> {
    vec![
        spark_displacement_claim_inventory_row(),
        performance_superiority_claim_inventory_row(),
        EngineReplacementClaimInventoryRow::blocked(
            "general_engine_replacement_claim",
            "engine_replacement",
            "general engine-replacement language is blocked",
            "broad_local_runtime,sql_dataframe_runtime,input_adapter_runtime,output_writer_runtime,session_runtime",
            "multi_format_local_outputs,prepared_vortex_outputs,compatibility_outputs,replay_verified_sinks",
            "operator_semantics,sql_dataframe_semantics,adapter_correctness,materialization_boundaries",
            "full_local_profile,competitor_registry,artifact_completeness,reproducible_runs",
            "execution_certificate,workload_dossier,claim_gate_certificate",
            "native_io_certificate,adapter_fidelity_certificate,source_sink_certificate",
            "GAR-0001B-A,GAR-0009-A,GAR-0041-A",
            "GAR-BENCH-PUB-1; GAR-COMPAT-1; GAR-RUNTIME-IMPL-4D through 4M",
            "runtime_evidence,compatibility_evidence,benchmark_artifact_completeness,release_claim_approval",
            "Engine-replacement language remains blocked until scoped runtime and benchmark evidence proves the exact workload.",
        ),
        EngineReplacementClaimInventoryRow::blocked(
            "best_default_engine_claim",
            "best_default",
            "best-default engine language is blocked",
            "broad_user_workflow_runtime,api_surface_runtime,installer_smoke_runtime,diagnostic_quality_runtime",
            "common_output_formats,claim_safe_website_docs,package_install_outputs",
            "workload_constitution,semantic_conformance,correctness_differential_harness",
            "best_choice_scorecard,benchmark_claim_evidence,public_benchmark_manifest",
            "execution_certificate,capability_snapshot,release_readiness_certificate",
            "native_io_certificate,no_fallback_certificate,materialization_certificate",
            "GAR-0032-E,GAR-0041-A",
            "best-default certification gate; world-class sufficiency; package-channel readiness",
            "best_choice_scorecard,best_default_dossier,benchmark_evidence,release_security,ux_install_docs",
            "Best-default language remains blocked by the existing certification gate.",
        ),
        EngineReplacementClaimInventoryRow::blocked(
            "production_sql_dataframe_claim",
            "sql_dataframe_replacement",
            "production SQL/DataFrame replacement language is blocked",
            "sql_parser_binder_planner_runtime,dataframe_runtime,optimizer_runtime,operator_runtime",
            "sql_dataframe_write_paths,local_and_prepared_vortex_outputs",
            "sql_semantics,dataframe_semantics,type_coercion,null_semantics,join_aggregate_window_correctness",
            "sql_dataframe_benchmark_profile,scenario_coverage,baseline_context",
            "sql_execution_certificate,dataframe_execution_certificate",
            "input_output_native_io_certificate,materialization_decode_certificate",
            "GAR-0032-A,GAR-0032-B,GAR-0041-A",
            "GAR-RUNTIME-IMPL-4D; GAR-RUNTIME-IMPL-4E; GAR-RUNTIME-IMPL-4K",
            "parser_binder_planner_runtime,operator_runtime,semantic_conformance,benchmark_evidence",
            "Production SQL/DataFrame replacement claims remain blocked.",
        ),
        EngineReplacementClaimInventoryRow::blocked(
            "object_store_lakehouse_replacement_claim",
            "object_store_lakehouse",
            "object-store/lakehouse replacement language is blocked",
            "object_store_read_runtime,object_store_write_runtime,table_runtime,commit_protocol_runtime",
            "object_store_output_commit,table_append_merge_update_delete,rollback_recovery",
            "table_semantics,delete_tombstone_cdc_correctness,commit_recovery_correctness",
            "object_store_optional_profile,table_runtime_profile,scale_profile",
            "object_store_execution_certificate,table_commit_certificate",
            "object_store_native_io_certificate,table_metadata_certificate",
            "GAR-0001A-B,GAR-0041-A,GAR-SCALE-1",
            "GAR-RUNTIME-IMPL-4N; GAR-RUNTIME-IMPL-4O; GAR-SCALE-1E",
            "credential_policy,network_policy,object_store_io,commit_semantics,table_correctness,scale_evidence",
            "Object-store/lakehouse replacement claims remain blocked until read/write/commit runtime proof exists.",
        ),
        EngineReplacementClaimInventoryRow::blocked(
            "managed_platform_replacement_claim",
            "managed_platform",
            "managed-platform replacement language is blocked",
            "managed_platform_proof,foundry_runtime_proof,distributed_orchestration,governance_runtime",
            "platform_output_dataset,evidence_dataset,package_channel_artifacts",
            "platform_semantic_proof,foundry_dev_stack_proof,enterprise_evidence_export_validation",
            "managed_platform_profile,foundry_scale_proof,environment_fingerprint",
            "platform_execution_certificate,foundry_execution_certificate",
            "platform_native_io_certificate,output_dataset_certificate",
            "GAR-SCALE-1H,GAR-COMMERCIAL-1E,GAR-0041-A",
            "Foundry proof boundary; package proof boundary; distributed report-only protocol",
            "real_platform_invocation,governance_evidence,output_dataset_evidence,scale_proof",
            "Managed-platform replacement claims remain blocked; Foundry and managed platforms are validation targets only.",
        ),
    ]
}

fn spark_displacement_claim_inventory_row() -> EngineReplacementClaimInventoryRow {
    EngineReplacementClaimInventoryRow::blocked(
        "spark_displacement_claim",
        "spark_displacement",
        "Spark-displacement language is blocked",
        "production_batch_runtime,larger_than_memory_local,split_parallel_local,shuffle_join_groupby_window,object_store_table_scale_runtime",
        "local_and_object_store_outputs,table_commit_semantics,result_sink_replay,output_fanout_evidence",
        "semantic_conformance,differential_oracle_correctness,fuzz_property_coverage,edge_case_fixtures",
        "claim_grade_full_local_plus_spark,scale_benchmark_profile,reproducible_environment,baseline_versions",
        "execution_certificate,operator_certificate,scale_certificate",
        "source_native_io_certificate,output_native_io_certificate,materialization_decode_certificate",
        "GAR-0009-A,GAR-0041-A,P8.4 hard release readiness",
        "GAR-0009-A Spark-displacement benchmark evidence matrix; GAR-0041-A per-claim evidence attachment matrix; GAR-SCALE-1 scale contract; GAR-RUNTIME-IMPL runtime queue",
        "runtime_evidence,output_evidence,correctness_evidence,benchmark_evidence,execution_certificate,native_io_certificate,no_fallback_evidence,release_gate",
        "No Spark-displacement or Spark-replacement claim is allowed; external Spark rows are baselines/oracles only.",
    )
}

fn performance_superiority_claim_inventory_row() -> EngineReplacementClaimInventoryRow {
    EngineReplacementClaimInventoryRow::blocked(
        "performance_superiority_claim",
        "benchmark",
        "performance-superiority language is blocked",
        "claim-grade runtime coverage for the exact workload, execution mode, and evidence level being compared",
        "result-sink proof, output certificate refs, and materialization/decode boundaries for measured workloads",
        "workload-specific correctness tests and differential/reference evidence for every measured scenario",
        "complete benchmark profile with expected lanes, versions, environment fingerprint, and reproducible command",
        "execution certificates and benchmark claim certificates for each measured ShardLoom row",
        "Native I/O certificate refs for every measured ShardLoom source and sink",
        "GAR-0041-A,P8.4 hard release readiness",
        "GAR-BENCH-PUB-1; GAR-PERF-1; GAR-PERF-2; GAR-RUNTIME-IMPL-4M",
        "claim_grade_benchmark,correctness_evidence,execution_certificate,native_io_certificate,no_fallback_evidence,release_gate",
        "Performance and superiority language remains blocked; benchmark pages are evidence dashboards, not leaderboards.",
    )
}

#[derive(Debug, Clone, PartialEq)]
pub struct ReleasePlan {
    pub version: ProjectVersion,
    pub channel: ReleaseChannel,
    pub readiness: ReleaseReadinessStatus,
    pub public_surfaces: Vec<PublicSurface>,
    pub schemas: Vec<SchemaCompatibilityPlan>,
    pub package_targets: Vec<PackageTarget>,
    pub artifacts: Vec<ReleaseArtifactPlan>,
    pub dependency_reviews: Vec<DependencyReview>,
    pub no_fallback_check: NoFallbackReleaseCheck,
    pub checklist: Vec<ReleaseChecklistItem>,
    pub diagnostics: Vec<Diagnostic>,
}
impl ReleasePlan {
    pub fn draft(version: ProjectVersion) -> Self {
        Self {
            version,
            channel: ReleaseChannel::Experimental,
            readiness: ReleaseReadinessStatus::Draft,
            public_surfaces: vec![],
            schemas: vec![],
            package_targets: vec![],
            artifacts: vec![],
            dependency_reviews: vec![],
            no_fallback_check: NoFallbackReleaseCheck::clean(),
            checklist: vec![],
            diagnostics: vec![],
        }
    }
    pub fn default_foundation_plan() -> Self {
        let version = ProjectVersion::current_crate();
        let mut p = Self::draft(version.clone());
        p.add_public_surface(
            PublicSurface::new(
                PublicSurfaceKind::Cli,
                "shardloom",
                ApiStabilityTier::Experimental,
                version.clone(),
            )
            .expect("valid"),
        );
        p.add_public_surface(
            PublicSurface::new(
                PublicSurfaceKind::RustCrate,
                "shardloom-core",
                ApiStabilityTier::Experimental,
                version,
            )
            .expect("valid"),
        );
        p.add_schema(SchemaCompatibilityPlan::experimental(
            MachineReadableSchemaKind::OutputEnvelope,
        ));
        p.add_schema(SchemaCompatibilityPlan::experimental(
            MachineReadableSchemaKind::Diagnostics,
        ));
        p.add_package_target(
            PackageTarget::planned(PackageTargetKind::CratesIo, "crates.io").expect("valid"),
        );
        p.add_package_target(
            PackageTarget::planned(PackageTargetKind::GitHubRelease, "github-releases")
                .expect("valid"),
        );
        for k in [
            ReleaseChecklistItemKind::HumanApproval,
            ReleaseChecklistItemKind::TestsPass,
            ReleaseChecklistItemKind::FormattingPasses,
            ReleaseChecklistItemKind::ClippyPasses,
            ReleaseChecklistItemKind::LicenseMetadataCorrect,
            ReleaseChecklistItemKind::DependencyLicensesReviewed,
            ReleaseChecklistItemKind::NoFallbackDependency,
            ReleaseChecklistItemKind::VersionBumped,
        ] {
            p.add_checklist_item(ReleaseChecklistItem::new(k));
        }
        p
    }
    pub fn unsupported(feature: impl Into<String>, reason: impl Into<String>) -> Self {
        let mut p = Self::draft(ProjectVersion::current_crate());
        p.readiness = ReleaseReadinessStatus::Unsupported;
        p.add_diagnostic(Diagnostic::unsupported(
            crate::DiagnosticCode::NotImplemented,
            feature,
            "Release planning feature unsupported",
            Some(reason.into()),
        ));
        p
    }
    pub fn add_public_surface(&mut self, s: PublicSurface) {
        self.public_surfaces.push(s)
    }
    pub fn add_schema(&mut self, s: SchemaCompatibilityPlan) {
        self.schemas.push(s)
    }
    pub fn add_package_target(&mut self, t: PackageTarget) {
        self.package_targets.push(t)
    }
    pub fn add_artifact(&mut self, a: ReleaseArtifactPlan) {
        self.artifacts.push(a)
    }
    pub fn add_dependency_review(&mut self, r: DependencyReview) {
        self.dependency_reviews.push(r)
    }
    pub fn add_checklist_item(&mut self, i: ReleaseChecklistItem) {
        self.checklist.push(i)
    }
    pub fn add_diagnostic(&mut self, d: Diagnostic) {
        self.diagnostics.push(d)
    }
    pub fn has_blockers(&self) -> bool {
        self.checklist.iter().any(ReleaseChecklistItem::is_blocking)
            || self
                .dependency_reviews
                .iter()
                .any(DependencyReview::is_blocking)
            || !self.no_fallback_check.is_clean()
    }
    pub fn publish_allowed(&self) -> bool {
        self.readiness.allows_publish()
            && !self.has_blockers()
            && !self.has_errors()
            && self
                .package_targets
                .iter()
                .filter(|t| t.enabled && t.kind.requires_external_publish())
                .all(|t| t.publish_allowed)
    }
    pub fn release_readiness_evidence(&self) -> ReleaseReadinessEvidenceReport {
        ReleaseReadinessEvidenceReport::from_plan(self)
    }
    pub fn publication_boundary_report(&self) -> ReleasePublicationBoundaryReport {
        ReleasePublicationBoundaryReport::from_plan(self)
    }
    pub fn publication_api_schema_stability_gate(&self) -> ReleasePublicationApiSchemaGateReport {
        ReleasePublicationApiSchemaGateReport::foundation()
    }
    pub fn conda_build_install_certification(&self) -> CondaBuildInstallCertificationReport {
        CondaBuildInstallCertificationReport::foundation()
    }
    pub fn has_errors(&self) -> bool {
        self.diagnostics.iter().any(|d| {
            matches!(
                d.severity,
                crate::DiagnosticSeverity::Error | crate::DiagnosticSeverity::Fatal
            )
        })
    }
    pub fn to_human_text(&self) -> String {
        format!(
            "release plan\nversion: {}\nchannel: {}\nreadiness: {}\npublish allowed: {}\nfallback execution disabled: {}\nblockers: {}\npackage targets: {}\ndiagnostics: {}",
            self.version.summary(),
            self.channel.as_str(),
            self.readiness.as_str(),
            self.publish_allowed(),
            !self.no_fallback_check.fallback_execution_allowed,
            self.has_blockers(),
            self.package_targets
                .iter()
                .map(PackageTarget::summary)
                .collect::<Vec<_>>()
                .join(", "),
            self.diagnostics.len()
        )
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct ReleaseReadinessEvidenceReport {
    pub schema_version: &'static str,
    pub report_id: &'static str,
    pub release_version: String,
    pub release_channel: ReleaseChannel,
    pub release_readiness: ReleaseReadinessStatus,
    pub requirements: Vec<ReleaseEvidenceRequirement>,
    pub public_release_claim_allowed: bool,
    pub public_package_claim_allowed: bool,
    pub runtime_execution: bool,
    pub external_publish_performed: bool,
    pub fallback_attempted: bool,
    pub fallback_execution_allowed: bool,
    pub diagnostics: Vec<Diagnostic>,
}
impl ReleaseReadinessEvidenceReport {
    pub fn from_plan(plan: &ReleasePlan) -> Self {
        let mut requirements = vec![
            ReleaseEvidenceRequirement::new(
                ReleaseEvidenceRequirementKind::SchemaVersion,
                schema_version_status(plan),
                true,
            )
            .with_evidence_ref("ReleasePlan.schemas"),
            ReleaseEvidenceRequirement::new(
                ReleaseEvidenceRequirementKind::ApiStability,
                api_stability_status(plan),
                true,
            )
            .with_evidence_ref("ReleasePlan.public_surfaces"),
            ReleaseEvidenceRequirement::new(
                ReleaseEvidenceRequirementKind::DependencyLicense,
                dependency_license_status(plan),
                true,
            )
            .with_evidence_ref("ReleasePlan.dependency_reviews"),
            ReleaseEvidenceRequirement::new(
                ReleaseEvidenceRequirementKind::Sbom,
                artifact_status(plan, ReleaseArtifactKind::Sbom),
                true,
            )
            .with_evidence_ref("ReleasePlan.artifacts"),
            ReleaseEvidenceRequirement::new(
                ReleaseEvidenceRequirementKind::ProvenanceAttestation,
                artifact_status(plan, ReleaseArtifactKind::ProvenanceAttestation),
                true,
            )
            .with_evidence_ref("ReleasePlan.artifacts.provenance_attestation"),
            ReleaseEvidenceRequirement::new(
                ReleaseEvidenceRequirementKind::ReproducibleBuild,
                ReleaseEvidenceRequirementStatus::Missing,
                true,
            )
            .with_evidence_ref("release build provenance"),
            ReleaseEvidenceRequirement::new(
                ReleaseEvidenceRequirementKind::ReleaseNotes,
                checklist_status(plan, ReleaseChecklistItemKind::ReleaseNotesWritten),
                true,
            )
            .with_evidence_ref("ReleasePlan.checklist"),
            ReleaseEvidenceRequirement::new(
                ReleaseEvidenceRequirementKind::BenchmarkAccountability,
                checklist_status(plan, ReleaseChecklistItemKind::BenchmarkClaimsVerified),
                true,
            )
            .with_evidence_ref("ReleasePlan.checklist"),
            ReleaseEvidenceRequirement::new(
                ReleaseEvidenceRequirementKind::NoFallback,
                no_fallback_status(plan),
                true,
            )
            .with_evidence_ref("ReleasePlan.no_fallback_check"),
            ReleaseEvidenceRequirement::new(
                ReleaseEvidenceRequirementKind::HumanApproval,
                checklist_status(plan, ReleaseChecklistItemKind::HumanApproval),
                true,
            )
            .with_evidence_ref("ReleasePlan.checklist"),
        ];
        for requirement in &mut requirements {
            if requirement.is_blocking() && requirement.diagnostic.is_none() {
                requirement.diagnostic = Some(format!(
                    "{} evidence is required before public release claims",
                    requirement.kind.as_str()
                ));
            }
        }
        let public_claim_allowed = plan.publish_allowed()
            && requirements
                .iter()
                .all(|requirement| !requirement.is_blocking());
        Self {
            schema_version: "shardloom.release_readiness_evidence.v1",
            report_id: "release-readiness-foundation",
            release_version: plan.version.summary(),
            release_channel: plan.channel,
            release_readiness: plan.readiness,
            requirements,
            public_release_claim_allowed: public_claim_allowed,
            public_package_claim_allowed: public_claim_allowed,
            runtime_execution: false,
            external_publish_performed: false,
            fallback_attempted: false,
            fallback_execution_allowed: plan.no_fallback_check.fallback_execution_allowed,
            diagnostics: plan.diagnostics.clone(),
        }
    }
    pub fn blocking_requirement_count(&self) -> usize {
        self.requirements
            .iter()
            .filter(|requirement| requirement.is_blocking())
            .count()
    }
    pub fn status_for(
        &self,
        kind: ReleaseEvidenceRequirementKind,
    ) -> ReleaseEvidenceRequirementStatus {
        self.requirements
            .iter()
            .find(|requirement| requirement.kind == kind)
            .map_or(ReleaseEvidenceRequirementStatus::Missing, |requirement| {
                requirement.status
            })
    }
    pub fn blocking_requirement_names(&self) -> Vec<&'static str> {
        self.requirements
            .iter()
            .filter(|requirement| requirement.is_blocking())
            .map(|requirement| requirement.kind.as_str())
            .collect()
    }
    pub fn to_human_text(&self) -> String {
        format!(
            "release readiness evidence\nschema_version: {}\nrelease_version: {}\nblocking requirements: {}\npublic release claim allowed: {}\nexternal publish performed: {}\nfallback attempted: {}\nfallback execution allowed: {}",
            self.schema_version,
            self.release_version,
            self.blocking_requirement_names().join(", "),
            self.public_release_claim_allowed,
            self.external_publish_performed,
            self.fallback_attempted,
            self.fallback_execution_allowed
        )
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum WorkspaceFeatureBuildMatrixFeatureSet {
    DefaultFeatures,
    AllFeatures,
    NoDefaultFeatures,
    UpstreamVortex,
    VortexFileIo,
    VortexLocalPrimitives,
    VortexEncodedReadSpike,
    PackagingDeployment,
    ReleaseUserSurfaces,
    FutureFoundryOptional,
}
as_str_enum!(WorkspaceFeatureBuildMatrixFeatureSet{DefaultFeatures=>"default_features",AllFeatures=>"all_features",NoDefaultFeatures=>"no_default_features",UpstreamVortex=>"upstream_vortex",VortexFileIo=>"vortex_file_io",VortexLocalPrimitives=>"vortex_local_primitives",VortexEncodedReadSpike=>"vortex_encoded_read_spike",PackagingDeployment=>"packaging_deployment",ReleaseUserSurfaces=>"release_user_surfaces",FutureFoundryOptional=>"future_foundry_optional"});

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum WorkspaceFeatureBuildMatrixRowStatus {
    Required,
    Passed,
    Blocked,
    NotApplicableYet,
}
as_str_enum!(WorkspaceFeatureBuildMatrixRowStatus{Required=>"required",Passed=>"passed",Blocked=>"blocked",NotApplicableYet=>"not_applicable_yet"});

impl WorkspaceFeatureBuildMatrixRowStatus {
    pub const fn satisfies_release_claim(&self) -> bool {
        matches!(self, Self::Passed | Self::NotApplicableYet)
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct WorkspaceFeatureBuildMatrixRow {
    pub workspace_crate: &'static str,
    pub feature_set: WorkspaceFeatureBuildMatrixFeatureSet,
    pub command: &'static str,
    pub status: WorkspaceFeatureBuildMatrixRowStatus,
    pub docs_report_only_commands_compile_required: bool,
    pub feature_disabled_unsupported_diagnostics_required: bool,
    pub public_release_claim_allowed: bool,
    pub external_engine_invoked: bool,
    pub fallback_attempted: bool,
}

impl WorkspaceFeatureBuildMatrixRow {
    pub const fn required(
        workspace_crate: &'static str,
        feature_set: WorkspaceFeatureBuildMatrixFeatureSet,
        command: &'static str,
        feature_disabled_unsupported_diagnostics_required: bool,
    ) -> Self {
        Self {
            workspace_crate,
            feature_set,
            command,
            status: WorkspaceFeatureBuildMatrixRowStatus::Required,
            docs_report_only_commands_compile_required: true,
            feature_disabled_unsupported_diagnostics_required,
            public_release_claim_allowed: false,
            external_engine_invoked: false,
            fallback_attempted: false,
        }
    }

    pub const fn not_applicable_yet(
        workspace_crate: &'static str,
        feature_set: WorkspaceFeatureBuildMatrixFeatureSet,
        command: &'static str,
    ) -> Self {
        Self {
            workspace_crate,
            feature_set,
            command,
            status: WorkspaceFeatureBuildMatrixRowStatus::NotApplicableYet,
            docs_report_only_commands_compile_required: true,
            feature_disabled_unsupported_diagnostics_required: true,
            public_release_claim_allowed: false,
            external_engine_invoked: false,
            fallback_attempted: false,
        }
    }

    pub const fn fallback_free(&self) -> bool {
        !self.external_engine_invoked && !self.fallback_attempted
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct WorkspaceFeatureBuildMatrixReport {
    pub schema_version: &'static str,
    pub report_id: &'static str,
    pub rows: Vec<WorkspaceFeatureBuildMatrixRow>,
    pub public_release_claim_blocked_until_matrix_passes: bool,
    pub public_package_claim_blocked_until_matrix_passes: bool,
    pub docs_report_only_commands_must_compile_without_runtime_features: bool,
    pub feature_disabled_execution_commands_require_unsupported_diagnostics: bool,
    pub package_publication_performed: bool,
    pub dependency_expansion_performed: bool,
    pub runtime_expansion_performed: bool,
    pub external_engine_invoked: bool,
    pub fallback_attempted: bool,
}

impl WorkspaceFeatureBuildMatrixReport {
    pub fn required_release_readiness_matrix() -> Self {
        Self {
            schema_version: "shardloom.workspace_feature_build_matrix.v1",
            report_id: "priority_3_5.workspace_feature_build_matrix.required",
            rows: workspace_feature_build_matrix_rows(),
            public_release_claim_blocked_until_matrix_passes: true,
            public_package_claim_blocked_until_matrix_passes: true,
            docs_report_only_commands_must_compile_without_runtime_features: true,
            feature_disabled_execution_commands_require_unsupported_diagnostics: true,
            package_publication_performed: false,
            dependency_expansion_performed: false,
            runtime_expansion_performed: false,
            external_engine_invoked: false,
            fallback_attempted: false,
        }
    }

    pub fn has_required_feature_coverage(&self) -> bool {
        self.has_feature_set(WorkspaceFeatureBuildMatrixFeatureSet::DefaultFeatures)
            && self.has_feature_set(WorkspaceFeatureBuildMatrixFeatureSet::AllFeatures)
            && self.has_feature_set(WorkspaceFeatureBuildMatrixFeatureSet::NoDefaultFeatures)
            && self.has_feature_set(WorkspaceFeatureBuildMatrixFeatureSet::UpstreamVortex)
            && self.has_feature_set(WorkspaceFeatureBuildMatrixFeatureSet::VortexFileIo)
            && self.has_feature_set(WorkspaceFeatureBuildMatrixFeatureSet::VortexLocalPrimitives)
            && self.has_feature_set(WorkspaceFeatureBuildMatrixFeatureSet::VortexEncodedReadSpike)
            && self.has_feature_set(WorkspaceFeatureBuildMatrixFeatureSet::PackagingDeployment)
            && self.has_feature_set(WorkspaceFeatureBuildMatrixFeatureSet::ReleaseUserSurfaces)
            && self.has_feature_set(WorkspaceFeatureBuildMatrixFeatureSet::FutureFoundryOptional)
    }

    pub fn release_claims_remain_blocked(&self) -> bool {
        self.public_release_claim_blocked_until_matrix_passes
            && self.public_package_claim_blocked_until_matrix_passes
            && !self.required_matrix_rows_all_passed()
    }

    pub fn required_matrix_rows_all_passed(&self) -> bool {
        self.rows
            .iter()
            .filter(|row| row.status != WorkspaceFeatureBuildMatrixRowStatus::NotApplicableYet)
            .all(|row| row.status == WorkspaceFeatureBuildMatrixRowStatus::Passed)
    }

    pub fn no_runtime_or_fallback_expansion(&self) -> bool {
        !self.package_publication_performed
            && !self.dependency_expansion_performed
            && !self.runtime_expansion_performed
            && !self.external_engine_invoked
            && !self.fallback_attempted
            && self
                .rows
                .iter()
                .all(WorkspaceFeatureBuildMatrixRow::fallback_free)
    }

    fn has_feature_set(&self, feature_set: WorkspaceFeatureBuildMatrixFeatureSet) -> bool {
        self.rows.iter().any(|row| row.feature_set == feature_set)
    }
}

pub fn plan_workspace_feature_build_matrix() -> WorkspaceFeatureBuildMatrixReport {
    WorkspaceFeatureBuildMatrixReport::required_release_readiness_matrix()
}

fn workspace_feature_build_matrix_rows() -> Vec<WorkspaceFeatureBuildMatrixRow> {
    vec![
        WorkspaceFeatureBuildMatrixRow::required(
            "workspace",
            WorkspaceFeatureBuildMatrixFeatureSet::DefaultFeatures,
            "cargo check --workspace",
            true,
        ),
        WorkspaceFeatureBuildMatrixRow::required(
            "workspace",
            WorkspaceFeatureBuildMatrixFeatureSet::AllFeatures,
            "cargo check --workspace --all-features",
            true,
        ),
        WorkspaceFeatureBuildMatrixRow::required(
            "workspace",
            WorkspaceFeatureBuildMatrixFeatureSet::NoDefaultFeatures,
            "cargo check --workspace --no-default-features",
            true,
        ),
        WorkspaceFeatureBuildMatrixRow::required(
            "shardloom-vortex",
            WorkspaceFeatureBuildMatrixFeatureSet::UpstreamVortex,
            "cargo check -p shardloom-vortex --features upstream-vortex",
            false,
        ),
        WorkspaceFeatureBuildMatrixRow::required(
            "shardloom-vortex",
            WorkspaceFeatureBuildMatrixFeatureSet::VortexFileIo,
            "cargo check -p shardloom-vortex --features vortex-file-io",
            false,
        ),
        WorkspaceFeatureBuildMatrixRow::required(
            "shardloom-vortex",
            WorkspaceFeatureBuildMatrixFeatureSet::VortexLocalPrimitives,
            "cargo check -p shardloom-vortex --features vortex-local-primitives",
            true,
        ),
        WorkspaceFeatureBuildMatrixRow::required(
            "shardloom-vortex",
            WorkspaceFeatureBuildMatrixFeatureSet::VortexEncodedReadSpike,
            "cargo check -p shardloom-vortex --features vortex-encoded-read-spike",
            true,
        ),
        WorkspaceFeatureBuildMatrixRow::required(
            "shardloom-contract-tests",
            WorkspaceFeatureBuildMatrixFeatureSet::PackagingDeployment,
            "cargo test -p shardloom-contract-tests --test conda_packaging_recipes",
            false,
        ),
        WorkspaceFeatureBuildMatrixRow::required(
            "shardloom-vortex",
            WorkspaceFeatureBuildMatrixFeatureSet::ReleaseUserSurfaces,
            "cargo check -p shardloom-vortex --features release-user-surfaces",
            true,
        ),
        WorkspaceFeatureBuildMatrixRow::not_applicable_yet(
            "shardloom-foundry",
            WorkspaceFeatureBuildMatrixFeatureSet::FutureFoundryOptional,
            "future optional package; no crate exists yet",
        ),
    ]
}

fn schema_version_status(plan: &ReleasePlan) -> ReleaseEvidenceRequirementStatus {
    if plan.schemas.is_empty() {
        ReleaseEvidenceRequirementStatus::Missing
    } else if plan
        .schemas
        .iter()
        .all(|schema| schema.stability.is_versioned())
    {
        ReleaseEvidenceRequirementStatus::Present
    } else {
        ReleaseEvidenceRequirementStatus::Blocked
    }
}

fn api_stability_status(plan: &ReleasePlan) -> ReleaseEvidenceRequirementStatus {
    if plan.public_surfaces.is_empty() {
        ReleaseEvidenceRequirementStatus::Missing
    } else {
        ReleaseEvidenceRequirementStatus::Present
    }
}

fn dependency_license_status(plan: &ReleasePlan) -> ReleaseEvidenceRequirementStatus {
    if plan.dependency_reviews.is_empty() {
        ReleaseEvidenceRequirementStatus::Missing
    } else if plan
        .dependency_reviews
        .iter()
        .any(DependencyReview::is_blocking)
    {
        ReleaseEvidenceRequirementStatus::Blocked
    } else {
        ReleaseEvidenceRequirementStatus::Present
    }
}

fn artifact_status(
    plan: &ReleasePlan,
    kind: ReleaseArtifactKind,
) -> ReleaseEvidenceRequirementStatus {
    let mut matching_artifacts = plan
        .artifacts
        .iter()
        .filter(|artifact| artifact.kind == kind)
        .peekable();
    if matching_artifacts.peek().is_none() {
        ReleaseEvidenceRequirementStatus::Missing
    } else if matching_artifacts.all(|artifact| artifact.built) {
        ReleaseEvidenceRequirementStatus::Present
    } else {
        ReleaseEvidenceRequirementStatus::Planned
    }
}

fn checklist_status(
    plan: &ReleasePlan,
    kind: ReleaseChecklistItemKind,
) -> ReleaseEvidenceRequirementStatus {
    plan.checklist.iter().find(|item| item.kind == kind).map_or(
        ReleaseEvidenceRequirementStatus::Missing,
        |item| match item.status {
            ChecklistStatus::Passed | ChecklistStatus::Waived | ChecklistStatus::NotApplicable => {
                ReleaseEvidenceRequirementStatus::Present
            }
            ChecklistStatus::Failed => ReleaseEvidenceRequirementStatus::Blocked,
            ChecklistStatus::NotStarted => ReleaseEvidenceRequirementStatus::Missing,
        },
    )
}

fn no_fallback_status(plan: &ReleasePlan) -> ReleaseEvidenceRequirementStatus {
    if plan.no_fallback_check.is_clean() {
        ReleaseEvidenceRequirementStatus::Present
    } else {
        ReleaseEvidenceRequirementStatus::Blocked
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ReleasePublicationBoundaryKind {
    LocalDevelopment,
    PublicPackage,
    GitHubRelease,
    ContainerImage,
    ServerMode,
    BenchmarkExtras,
    FoundryArtifact,
}
as_str_enum!(ReleasePublicationBoundaryKind{LocalDevelopment=>"local_development",PublicPackage=>"public_package",GitHubRelease=>"github_release",ContainerImage=>"container_image",ServerMode=>"server_mode",BenchmarkExtras=>"benchmark_extras",FoundryArtifact=>"foundry_artifact"});

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ReleasePublicationBoundaryStatus {
    Enabled,
    Planned,
    Disabled,
    Blocked,
}
as_str_enum!(ReleasePublicationBoundaryStatus{Enabled=>"enabled",Planned=>"planned",Disabled=>"disabled",Blocked=>"blocked"});

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ReleasePublicationBoundary {
    pub kind: ReleasePublicationBoundaryKind,
    pub status: ReleasePublicationBoundaryStatus,
    pub role: &'static str,
    pub publish_allowed: bool,
    pub requires_human_approval: bool,
    pub runtime_execution_allowed: bool,
    pub benchmark_extras_dependency: bool,
    pub fallback_dependency_allowed: bool,
}
impl ReleasePublicationBoundary {
    pub const fn new(
        kind: ReleasePublicationBoundaryKind,
        status: ReleasePublicationBoundaryStatus,
        role: &'static str,
    ) -> Self {
        Self {
            kind,
            status,
            role,
            publish_allowed: false,
            requires_human_approval: false,
            runtime_execution_allowed: false,
            benchmark_extras_dependency: false,
            fallback_dependency_allowed: false,
        }
    }
    pub const fn with_publish_boundary(mut self, requires_human_approval: bool) -> Self {
        self.requires_human_approval = requires_human_approval;
        self
    }
    pub const fn with_benchmark_extras_dependency(mut self, value: bool) -> Self {
        self.benchmark_extras_dependency = value;
        self
    }
    pub fn summary(&self) -> String {
        format!(
            "{} {} publish_allowed={} runtime_execution_allowed={} fallback_dependency_allowed={}",
            self.kind.as_str(),
            self.status.as_str(),
            self.publish_allowed,
            self.runtime_execution_allowed,
            self.fallback_dependency_allowed
        )
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ReleasePublicationBoundaryReport {
    pub schema_version: &'static str,
    pub report_id: &'static str,
    pub boundaries: Vec<ReleasePublicationBoundary>,
    pub local_development_available: bool,
    pub package_publication_distinct_from_local_development: bool,
    pub container_publication_distinct_from_local_development: bool,
    pub server_publication_distinct_from_local_development: bool,
    pub benchmark_extras_optional: bool,
    pub benchmark_extras_comparison_only: bool,
    pub external_publish_performed: bool,
    pub fallback_attempted: bool,
    pub fallback_dependency_allowed: bool,
}
impl ReleasePublicationBoundaryReport {
    pub fn from_plan(plan: &ReleasePlan) -> Self {
        let public_package_status = if plan.package_targets.iter().any(|target| {
            target.enabled
                && matches!(
                    target.kind,
                    PackageTargetKind::CratesIo | PackageTargetKind::PyPi | PackageTargetKind::Npm
                )
        }) {
            ReleasePublicationBoundaryStatus::Planned
        } else {
            ReleasePublicationBoundaryStatus::Disabled
        };
        let github_release_status = if plan
            .package_targets
            .iter()
            .any(|target| target.enabled && target.kind == PackageTargetKind::GitHubRelease)
        {
            ReleasePublicationBoundaryStatus::Planned
        } else {
            ReleasePublicationBoundaryStatus::Disabled
        };
        let boundaries = vec![
            ReleasePublicationBoundary::new(
                ReleasePublicationBoundaryKind::LocalDevelopment,
                ReleasePublicationBoundaryStatus::Enabled,
                "local build, tests, CLI, source-tree Python, and docs without public artifact publication",
            ),
            ReleasePublicationBoundary::new(
                ReleasePublicationBoundaryKind::PublicPackage,
                public_package_status,
                "public package channels such as crates.io, PyPI, npm, or Conda",
            )
            .with_publish_boundary(true),
            ReleasePublicationBoundary::new(
                ReleasePublicationBoundaryKind::GitHubRelease,
                github_release_status,
                "GitHub release artifacts, checksums, SBOMs, attestations, and changelog bundles",
            )
            .with_publish_boundary(true),
            ReleasePublicationBoundary::new(
                ReleasePublicationBoundaryKind::ContainerImage,
                ReleasePublicationBoundaryStatus::Disabled,
                "OCI/GHCR image publication remains separate from local development support",
            )
            .with_publish_boundary(true),
            ReleasePublicationBoundary::new(
                ReleasePublicationBoundaryKind::ServerMode,
                ReleasePublicationBoundaryStatus::Disabled,
                "server/API deployment remains separate from CLI/package publication",
            ),
            ReleasePublicationBoundary::new(
                ReleasePublicationBoundaryKind::BenchmarkExtras,
                ReleasePublicationBoundaryStatus::Planned,
                "optional comparison-only benchmark extras, never core install dependencies",
            )
            .with_benchmark_extras_dependency(true),
        ];
        Self {
            schema_version: "shardloom.release_publication_boundaries.v1",
            report_id: "release-publication-boundaries-foundation",
            boundaries,
            local_development_available: true,
            package_publication_distinct_from_local_development: true,
            container_publication_distinct_from_local_development: true,
            server_publication_distinct_from_local_development: true,
            benchmark_extras_optional: true,
            benchmark_extras_comparison_only: true,
            external_publish_performed: false,
            fallback_attempted: false,
            fallback_dependency_allowed: false,
        }
    }
    pub fn status_for(
        &self,
        kind: ReleasePublicationBoundaryKind,
    ) -> ReleasePublicationBoundaryStatus {
        self.boundaries
            .iter()
            .find(|boundary| boundary.kind == kind)
            .map_or(ReleasePublicationBoundaryStatus::Disabled, |boundary| {
                boundary.status
            })
    }
    pub fn to_human_text(&self) -> String {
        format!(
            "release publication boundaries\nschema_version: {}\nlocal development available: {}\nbenchmark extras optional: {}\nexternal publish performed: {}\nfallback dependency allowed: {}",
            self.schema_version,
            self.local_development_available,
            self.benchmark_extras_optional,
            self.external_publish_performed,
            self.fallback_dependency_allowed
        )
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CondaPackageKind {
    CliBinary,
    PythonWrapper,
    Metapackage,
}
as_str_enum!(CondaPackageKind{CliBinary=>"cli_binary",PythonWrapper=>"python_wrapper",Metapackage=>"metapackage"});

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CondaPackageBuildInstallEntry {
    pub kind: CondaPackageKind,
    pub package_name: &'static str,
    pub recipe_path: &'static str,
    pub recipe_scaffolded: bool,
    pub clean_build_certified: bool,
    pub clean_install_certified: bool,
    pub publish_allowed: bool,
    pub fallback_dependency_allowed: bool,
}
impl CondaPackageBuildInstallEntry {
    pub const fn scaffolded(
        kind: CondaPackageKind,
        package_name: &'static str,
        recipe_path: &'static str,
    ) -> Self {
        Self {
            kind,
            package_name,
            recipe_path,
            recipe_scaffolded: true,
            clean_build_certified: false,
            clean_install_certified: false,
            publish_allowed: false,
            fallback_dependency_allowed: false,
        }
    }

    pub const fn is_certified(&self) -> bool {
        self.recipe_scaffolded
            && self.clean_build_certified
            && self.clean_install_certified
            && !self.fallback_dependency_allowed
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct CondaBuildInstallCertificationReport {
    pub schema_version: &'static str,
    pub report_id: &'static str,
    pub entries: Vec<CondaPackageBuildInstallEntry>,
    pub tagged_archive_required: bool,
    pub source_hash_required: bool,
    pub version_alignment_required: bool,
    pub provenance_attestation_required: bool,
    pub human_approval_required: bool,
    pub tagged_archive_present: bool,
    pub source_hash_verified: bool,
    pub version_alignment_verified: bool,
    pub provenance_attestation_present: bool,
    pub human_approval_present: bool,
    pub clean_build_certified: bool,
    pub clean_install_certified: bool,
    pub package_publication_allowed: bool,
    pub conda_build_invoked: bool,
    pub conda_install_invoked: bool,
    pub external_publish_performed: bool,
    pub fallback_attempted: bool,
    pub fallback_dependency_allowed: bool,
    pub diagnostics: Vec<Diagnostic>,
}
impl CondaBuildInstallCertificationReport {
    pub fn foundation() -> Self {
        Self {
            schema_version: "shardloom.conda_build_install_certification.v1",
            report_id: "conda-build-install-certification-foundation",
            entries: vec![
                CondaPackageBuildInstallEntry::scaffolded(
                    CondaPackageKind::CliBinary,
                    "shardloom-cli",
                    "packaging/conda/shardloom-cli/meta.yaml",
                ),
                CondaPackageBuildInstallEntry::scaffolded(
                    CondaPackageKind::PythonWrapper,
                    "shardloom-python",
                    "packaging/conda/shardloom-python/meta.yaml",
                ),
                CondaPackageBuildInstallEntry::scaffolded(
                    CondaPackageKind::Metapackage,
                    "shardloom",
                    "packaging/conda/shardloom/meta.yaml",
                ),
            ],
            tagged_archive_required: true,
            source_hash_required: true,
            version_alignment_required: true,
            provenance_attestation_required: true,
            human_approval_required: true,
            tagged_archive_present: false,
            source_hash_verified: false,
            version_alignment_verified: false,
            provenance_attestation_present: false,
            human_approval_present: false,
            clean_build_certified: false,
            clean_install_certified: false,
            package_publication_allowed: false,
            conda_build_invoked: false,
            conda_install_invoked: false,
            external_publish_performed: false,
            fallback_attempted: false,
            fallback_dependency_allowed: false,
            diagnostics: Vec::new(),
        }
    }

    pub fn package_count(&self) -> usize {
        self.entries.len()
    }

    pub fn recipe_scaffold_count(&self) -> usize {
        self.entries
            .iter()
            .filter(|entry| entry.recipe_scaffolded)
            .count()
    }

    pub fn certified_package_count(&self) -> usize {
        self.entries
            .iter()
            .filter(|entry| entry.is_certified())
            .count()
    }

    pub const fn release_gate_blocking_count(&self) -> usize {
        (!self.tagged_archive_present as usize)
            + (!self.source_hash_verified as usize)
            + (!self.version_alignment_verified as usize)
            + (!self.provenance_attestation_present as usize)
            + (!self.human_approval_present as usize)
            + (!self.clean_build_certified as usize)
            + (!self.clean_install_certified as usize)
            + (!self.package_publication_allowed as usize)
    }

    pub const fn release_gated(&self) -> bool {
        self.release_gate_blocking_count() > 0
            || !self.clean_build_certified
            || !self.clean_install_certified
            || !self.package_publication_allowed
    }

    pub const fn is_side_effect_free(&self) -> bool {
        !self.conda_build_invoked
            && !self.conda_install_invoked
            && !self.external_publish_performed
            && !self.fallback_attempted
            && !self.fallback_dependency_allowed
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct ReleaseReport {
    pub plan: ReleasePlan,
    pub published: bool,
    pub artifacts_published: usize,
    pub diagnostics: Vec<Diagnostic>,
    pub notes: Vec<String>,
}
impl ReleaseReport {
    pub fn not_published(plan: ReleasePlan) -> Self {
        Self {
            plan,
            published: false,
            artifacts_published: 0,
            diagnostics: vec![],
            notes: vec![],
        }
    }
    pub fn from_plan(plan: ReleasePlan) -> Self {
        Self::not_published(plan)
    }
    pub fn add_diagnostic(&mut self, d: Diagnostic) {
        self.diagnostics.push(d)
    }
    pub fn add_note(&mut self, n: impl Into<String>) {
        self.notes.push(n.into())
    }
    pub fn has_errors(&self) -> bool {
        self.plan.has_errors()
            || self.diagnostics.iter().any(|d| {
                matches!(
                    d.severity,
                    crate::DiagnosticSeverity::Error | crate::DiagnosticSeverity::Fatal
                )
            })
    }
    pub fn to_human_text(&self) -> String {
        format!(
            "{}\npublished: {}\nartifacts_published: {}\nfallback execution disabled: {}\nno publish occurred",
            self.plan.to_human_text(),
            self.published,
            self.artifacts_published,
            !self.plan.no_fallback_check.fallback_execution_allowed
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn t1() {
        assert!(ProjectVersion::new(0, 1, 0).with_pre_release(" ").is_err());
        assert!(ProjectVersion::new(0, 1, 0).is_zero_series());
        assert!(ReleaseChannel::Stable.is_stable());
        assert!(!ApiStabilityTier::Stable.allows_breaking_changes());
        assert!(ApiStabilityTier::Experimental.allows_breaking_changes());
        assert!(
            PublicSurface::new(
                PublicSurfaceKind::Cli,
                "",
                ApiStabilityTier::Experimental,
                ProjectVersion::new(0, 1, 0)
            )
            .is_err()
        );
        assert!(PublicSurfaceKind::DiagnosticSchema.is_machine_readable());
        assert!(
            SchemaStability::StableVersioned.is_versioned()
                && SchemaStability::StableVersioned.is_stable()
        );
        assert!(
            SchemaCompatibilityPlan::experimental(MachineReadableSchemaKind::Diagnostics)
                .allows_breaking_change()
        );
        assert!(
            !SchemaCompatibilityPlan::stable(
                MachineReadableSchemaKind::Diagnostics,
                ProjectVersion::new(1, 0, 0)
            )
            .allows_breaking_change()
        );
        assert!(
            !PackageTarget::planned(PackageTargetKind::CratesIo, "c")
                .unwrap()
                .publish_allowed
        );
        assert!(
            PackageTarget::planned(PackageTargetKind::CratesIo, "c")
                .unwrap()
                .requires_human_approval()
        );
        assert!(ReleaseArtifactPlan::planned(ReleaseArtifactKind::RustCrate, " ").is_err());
        assert!(DependencyLicenseClass::Apache2.is_apache_compatible_candidate());
        assert!(DependencyLicenseClass::Mpl2ReviewRequired.requires_review());
        assert!(DependencyReview::new("", DependencyLicenseClass::Mit).is_err());
        assert!(
            DependencyReview::new("x", DependencyLicenseClass::Mit)
                .unwrap()
                .with_status(DependencyReviewStatus::Pending)
                .is_blocking()
        );
        assert!(NoFallbackReleaseCheck::clean().is_clean());
        assert!(
            !NoFallbackReleaseCheck {
                spark_dependency_present: true,
                ..NoFallbackReleaseCheck::clean()
            }
            .is_clean()
        );
        assert!(ReleaseChecklistItemKind::HumanApproval.is_required_before_publish());
        assert!(ChecklistStatus::NotStarted.is_blocking());
        let p = ReleasePlan::default_foundation_plan();
        assert!(p.has_blockers());
        assert!(!p.publish_allowed());
        assert!(p.no_fallback_check.is_clean());
        let u = ReleasePlan::unsupported("x", "y");
        assert!(u.has_errors());
        assert!(!u.diagnostics[0].fallback.attempted);
        assert!(p.to_human_text().contains("fallback execution disabled"));
        let r = ReleaseReport::from_plan(p);
        assert!(!r.published && r.artifacts_published == 0);
        assert!(r.to_human_text().contains("no publish occurred"));
    }

    #[test]
    fn dependency_review_incompatible_license_is_always_blocking() {
        let review = DependencyReview::new("bad-dep", DependencyLicenseClass::Incompatible)
            .expect("dependency should be created")
            .with_status(DependencyReviewStatus::Approved);
        assert!(review.is_blocking());
    }

    #[test]
    fn publish_allowed_ignores_disabled_external_targets() {
        let mut plan = ReleasePlan::draft(ProjectVersion::new(1, 0, 0));
        plan.readiness = ReleaseReadinessStatus::ReadyForRelease;
        plan.add_package_target(
            PackageTarget::planned(PackageTargetKind::CratesIo, "crates")
                .expect("valid target")
                .allow_publish(true),
        );
        plan.add_package_target(
            PackageTarget::disabled(PackageTargetKind::GitHubRelease, "gh-release")
                .expect("valid target"),
        );
        plan.add_checklist_item(
            ReleaseChecklistItem::new(ReleaseChecklistItemKind::HumanApproval)
                .with_status(ChecklistStatus::Passed),
        );
        plan.add_checklist_item(
            ReleaseChecklistItem::new(ReleaseChecklistItemKind::TestsPass)
                .with_status(ChecklistStatus::Passed),
        );
        plan.add_checklist_item(
            ReleaseChecklistItem::new(ReleaseChecklistItemKind::FormattingPasses)
                .with_status(ChecklistStatus::Passed),
        );
        plan.add_checklist_item(
            ReleaseChecklistItem::new(ReleaseChecklistItemKind::ClippyPasses)
                .with_status(ChecklistStatus::Passed),
        );
        plan.add_checklist_item(
            ReleaseChecklistItem::new(ReleaseChecklistItemKind::LicenseMetadataCorrect)
                .with_status(ChecklistStatus::Passed),
        );
        plan.add_checklist_item(
            ReleaseChecklistItem::new(ReleaseChecklistItemKind::DependencyLicensesReviewed)
                .with_status(ChecklistStatus::Passed),
        );
        plan.add_checklist_item(
            ReleaseChecklistItem::new(ReleaseChecklistItemKind::NoFallbackDependency)
                .with_status(ChecklistStatus::Passed),
        );
        plan.add_checklist_item(
            ReleaseChecklistItem::new(ReleaseChecklistItemKind::VersionBumped)
                .with_status(ChecklistStatus::Passed),
        );

        assert!(plan.publish_allowed());
    }

    #[test]
    fn release_readiness_evidence_blocks_public_claims_without_required_artifacts() {
        let plan = ReleasePlan::default_foundation_plan();
        let evidence = plan.release_readiness_evidence();

        assert_eq!(
            evidence.schema_version,
            "shardloom.release_readiness_evidence.v1"
        );
        assert_eq!(
            evidence.status_for(ReleaseEvidenceRequirementKind::SchemaVersion),
            ReleaseEvidenceRequirementStatus::Present
        );
        assert_eq!(
            evidence.status_for(ReleaseEvidenceRequirementKind::NoFallback),
            ReleaseEvidenceRequirementStatus::Present
        );
        assert_eq!(
            evidence.status_for(ReleaseEvidenceRequirementKind::Sbom),
            ReleaseEvidenceRequirementStatus::Missing
        );
        assert_eq!(
            evidence.status_for(ReleaseEvidenceRequirementKind::ProvenanceAttestation),
            ReleaseEvidenceRequirementStatus::Missing
        );
        assert!(evidence.blocking_requirement_count() > 0);
        assert!(!evidence.public_release_claim_allowed);
        assert!(!evidence.external_publish_performed);
        assert!(!evidence.fallback_attempted);
    }

    #[test]
    fn publication_api_schema_gate_fails_closed_without_publication_evidence() {
        let plan = ReleasePlan::default_foundation_plan();
        let report = plan.publication_api_schema_stability_gate();

        assert_eq!(
            report.schema_version,
            "shardloom.publication_api_schema_stability_gate.v1"
        );
        assert_eq!(
            report.report_id,
            "gar-0024-a.publication_api_schema_stability_gate"
        );
        assert_eq!(report.gate_status, "blocked");
        assert_eq!(report.claim_gate_status, "not_claim_grade");
        assert_eq!(report.rows.len(), 7);
        assert_eq!(report.blocking_row_count(), 7);
        assert!(report.fails_closed());
        assert!(report.side_effect_free());
        assert!(report.row_ids().contains(&"api_compatibility_window"));
        assert!(report.row_ids().contains(&"schema_compatibility_window"));
        assert!(report.row_ids().contains(&"package_identity_approval"));
        assert!(report.row_ids().contains(&"signing_policy_decision"));
        assert!(report.row_ids().contains(&"checksum_manifest"));
        assert!(report.row_ids().contains(&"sbom_bundle"));
        assert!(report.row_ids().contains(&"publication_approval"));
        assert!(!report.api_schema_stability_claim_allowed);
        assert!(!report.public_release_claim_allowed);
        assert!(!report.public_package_claim_allowed);
        assert!(!report.package_publication_performed);
        assert!(!report.tag_created);
        assert!(!report.signing_key_used);
        assert!(!report.checksum_manifest_publication_grade);
        assert!(!report.sbom_publication_grade);
        assert!(!report.runtime_execution);
        assert!(!report.fallback_attempted);
        assert!(!report.external_engine_invoked);
        assert!(
            report
                .rows
                .iter()
                .all(ReleasePublicationApiSchemaGateRow::side_effect_free)
        );
    }

    #[test]
    fn per_claim_evidence_attachment_matrix_blocks_public_claims_without_evidence() {
        let report = plan_per_claim_evidence_attachment_matrix();

        assert_eq!(
            report.schema_version,
            "shardloom.per_claim_evidence_attachment_matrix.v1"
        );
        assert_eq!(
            report.report_id,
            "gar-0041-a.per_claim_evidence_attachment_matrix"
        );
        assert_eq!(report.support_status, "blocked");
        assert_eq!(report.claim_gate_status, "not_claim_grade");
        assert_eq!(report.rows.len(), 8);
        assert_eq!(report.blocking_row_count(), 8);
        assert_eq!(report.total_missing_attachment_count(), 72);
        assert!(report.all_required_categories_named());
        assert!(report.all_claims_blocked());
        assert!(report.side_effect_free());
        assert!(report.row_ids().contains(&"public_release_claim"));
        assert!(report.row_ids().contains(&"public_package_claim"));
        assert!(report.row_ids().contains(&"performance_superiority_claim"));
        assert!(report.row_ids().contains(&"spark_displacement_claim"));
        assert!(report.row_ids().contains(&"engine_replacement_claim"));
        assert!(report.row_ids().contains(&"production_sql_dataframe_claim"));
        assert!(report.row_ids().contains(&"object_store_lakehouse_claim"));
        assert!(report.row_ids().contains(&"foundry_platform_claim"));
        assert!(report.test_evidence_required);
        assert!(report.benchmark_evidence_required);
        assert!(report.certificate_evidence_required);
        assert!(report.native_io_evidence_required);
        assert!(report.security_evidence_required);
        assert!(report.provenance_evidence_required);
        assert!(report.unsupported_path_evidence_required);
        assert!(report.no_fallback_evidence_required);
        assert!(report.release_approval_required);
        assert!(!report.public_release_claim_allowed);
        assert!(!report.public_package_claim_allowed);
        assert!(!report.performance_claim_allowed);
        assert!(!report.superiority_claim_allowed);
        assert!(!report.spark_displacement_claim_allowed);
        assert!(!report.production_claim_allowed);
        assert!(!report.package_publication_performed);
        assert!(!report.runtime_execution_performed);
        assert!(!report.benchmark_rerun_performed);
        assert!(!report.fallback_attempted);
        assert!(!report.external_engine_invoked);
        assert!(report.rows.iter().all(|row| {
            row.is_blocking()
                && row.all_required_categories_named()
                && row.missing_required_attachment_count() == 9
                && row.claim_gate_status == "not_claim_grade"
                && !row.public_claim_allowed
                && !row.fallback_attempted
                && !row.external_engine_invoked
        }));
    }

    #[test]
    fn engine_replacement_claim_inventory_blocks_displacement_claims_without_evidence() {
        let report = plan_engine_replacement_claim_inventory();

        assert_eq!(
            report.schema_version,
            "shardloom.engine_replacement_claim_inventory.v1"
        );
        assert_eq!(report.claim_gate_status, "not_claim_grade");
        assert_eq!(report.support_status, "report_only");
        assert_eq!(report.rows.len(), 7);
        assert!(report.release_gate_required);
        assert!(report.all_rows_not_claim_grade());
        assert!(report.all_rows_side_effect_free());
        assert!(report.all_engine_replacement_claims_blocked());
        assert!(report.side_effect_free());
        assert!(!report.public_engine_replacement_claim_allowed);
        assert!(!report.spark_displacement_claim_allowed);
        assert!(!report.performance_superiority_claim_allowed);
        assert!(!report.best_default_claim_allowed);
        assert!(!report.production_platform_claim_allowed);
        assert!(!report.runtime_execution_performed);
        assert!(!report.benchmark_rerun_performed);
        assert!(!report.fallback_attempted);
        assert!(!report.external_engine_invoked);
        assert!(report.row_order().contains(&"spark_displacement_claim"));
        assert!(
            report
                .row_order()
                .contains(&"performance_superiority_claim")
        );
        assert!(
            report
                .dependency_gate_refs()
                .iter()
                .any(|refs| refs.contains("GAR-0041-A"))
        );
        assert!(report.rows.iter().all(|row| {
            row.claim_gate_status == "not_claim_grade"
                && !row.public_claim_allowed
                && !row.fallback_attempted
                && !row.external_engine_invoked
                && row.claim_language.contains("blocked")
        }));
    }

    #[test]
    fn competitive_replacement_sufficiency_gate_blocks_claims_without_evidence() {
        let report = plan_competitive_replacement_sufficiency_gate();

        assert_eq!(
            report.schema_version,
            "shardloom.competitive_replacement_sufficiency_gate.v1"
        );
        assert_eq!(
            report.report_id,
            "gar-0025-a.competitive_replacement_sufficiency_gate"
        );
        assert_eq!(report.support_status, "blocked");
        assert_eq!(report.claim_gate_status, "not_claim_grade");
        assert_eq!(report.rows.len(), 7);
        assert_eq!(report.blocking_row_count(), 7);
        assert!(report.all_rows_not_claim_grade());
        assert!(report.all_claims_blocked());
        assert!(report.side_effect_free());
        assert!(report.row_ids().contains(&"correctness_evidence"));
        assert!(report.row_ids().contains(&"benchmark_evidence"));
        assert!(report.row_ids().contains(&"native_io_evidence"));
        assert!(report.row_ids().contains(&"execution_certificate_evidence"));
        assert!(report.row_ids().contains(&"capability_coverage_evidence"));
        assert!(report.row_ids().contains(&"no_fallback_policy_evidence"));
        assert!(report.row_ids().contains(&"release_publication_evidence"));
        assert!(!report.correctness_sufficient);
        assert!(!report.benchmark_sufficient);
        assert!(!report.native_io_sufficient);
        assert!(!report.execution_certificate_sufficient);
        assert!(!report.capability_coverage_sufficient);
        assert!(!report.no_fallback_sufficient);
        assert!(!report.release_evidence_sufficient);
        assert!(!report.public_engine_replacement_claim_allowed);
        assert!(!report.spark_displacement_claim_allowed);
        assert!(!report.superiority_claim_allowed);
        assert!(!report.production_platform_claim_allowed);
        assert!(!report.runtime_execution_performed);
        assert!(!report.benchmark_rerun_performed);
        assert!(!report.fallback_attempted);
        assert!(!report.external_engine_invoked);
    }

    #[test]
    fn release_readiness_evidence_does_not_treat_signature_as_provenance_attestation() {
        let mut plan = ReleasePlan::default_foundation_plan();
        plan.add_artifact(
            ReleaseArtifactPlan::planned(ReleaseArtifactKind::Signature, "release.sig")
                .expect("signature artifact")
                .mark_built(true),
        );
        let signature_only = plan.release_readiness_evidence();

        assert_eq!(
            signature_only.status_for(ReleaseEvidenceRequirementKind::ProvenanceAttestation),
            ReleaseEvidenceRequirementStatus::Missing
        );

        plan.add_artifact(
            ReleaseArtifactPlan::planned(
                ReleaseArtifactKind::ProvenanceAttestation,
                "release.intoto.jsonl",
            )
            .expect("provenance artifact")
            .mark_built(true),
        );
        let with_provenance = plan.release_readiness_evidence();

        assert_eq!(
            with_provenance.status_for(ReleaseEvidenceRequirementKind::ProvenanceAttestation),
            ReleaseEvidenceRequirementStatus::Present
        );
    }

    #[test]
    fn release_readiness_evidence_aggregates_duplicate_artifact_kinds() {
        let mut plan = ReleasePlan::default_foundation_plan();
        plan.add_artifact(
            ReleaseArtifactPlan::planned(ReleaseArtifactKind::Sbom, "sbom.spdx.json")
                .expect("sbom artifact")
                .mark_built(true),
        );
        plan.add_artifact(
            ReleaseArtifactPlan::planned(ReleaseArtifactKind::Sbom, "sbom.cyclonedx.json")
                .expect("second sbom artifact"),
        );

        let evidence = plan.release_readiness_evidence();

        assert_eq!(
            evidence.status_for(ReleaseEvidenceRequirementKind::Sbom),
            ReleaseEvidenceRequirementStatus::Planned
        );
    }

    #[test]
    fn release_readiness_evidence_blocks_no_fallback_policy_violations() {
        let mut plan = ReleasePlan::default_foundation_plan();
        plan.no_fallback_check = NoFallbackReleaseCheck {
            fallback_execution_allowed: true,
            ..NoFallbackReleaseCheck::clean()
        };
        let evidence = plan.release_readiness_evidence();

        assert_eq!(
            evidence.status_for(ReleaseEvidenceRequirementKind::NoFallback),
            ReleaseEvidenceRequirementStatus::Blocked
        );
        assert!(evidence.fallback_execution_allowed);
        assert!(!evidence.public_package_claim_allowed);
    }

    #[test]
    fn publication_boundary_report_separates_local_dev_publication_and_bench_extras() {
        let plan = ReleasePlan::default_foundation_plan();
        let report = plan.publication_boundary_report();

        assert_eq!(
            report.schema_version,
            "shardloom.release_publication_boundaries.v1"
        );
        assert_eq!(
            report.status_for(ReleasePublicationBoundaryKind::LocalDevelopment),
            ReleasePublicationBoundaryStatus::Enabled
        );
        assert_eq!(
            report.status_for(ReleasePublicationBoundaryKind::PublicPackage),
            ReleasePublicationBoundaryStatus::Planned
        );
        assert_eq!(
            report.status_for(ReleasePublicationBoundaryKind::ContainerImage),
            ReleasePublicationBoundaryStatus::Disabled
        );
        assert_eq!(
            report.status_for(ReleasePublicationBoundaryKind::ServerMode),
            ReleasePublicationBoundaryStatus::Disabled
        );
        assert_eq!(
            report.status_for(ReleasePublicationBoundaryKind::BenchmarkExtras),
            ReleasePublicationBoundaryStatus::Planned
        );
        assert!(report.package_publication_distinct_from_local_development);
        assert!(report.container_publication_distinct_from_local_development);
        assert!(report.server_publication_distinct_from_local_development);
        assert!(report.benchmark_extras_optional);
        assert!(report.benchmark_extras_comparison_only);
        assert!(!report.external_publish_performed);
        assert!(!report.fallback_dependency_allowed);
    }

    #[test]
    fn conda_build_install_certification_keeps_publication_release_gated() {
        let plan = ReleasePlan::default_foundation_plan();
        let report = plan.conda_build_install_certification();

        assert_eq!(
            report.schema_version,
            "shardloom.conda_build_install_certification.v1"
        );
        assert_eq!(report.package_count(), 3);
        assert_eq!(report.recipe_scaffold_count(), 3);
        assert_eq!(report.certified_package_count(), 0);
        assert_eq!(report.release_gate_blocking_count(), 8);
        assert!(report.tagged_archive_required);
        assert!(report.source_hash_required);
        assert!(report.version_alignment_required);
        assert!(report.provenance_attestation_required);
        assert!(report.human_approval_required);
        assert!(!report.tagged_archive_present);
        assert!(!report.source_hash_verified);
        assert!(!report.version_alignment_verified);
        assert!(!report.provenance_attestation_present);
        assert!(!report.human_approval_present);
        assert!(!report.clean_build_certified);
        assert!(!report.clean_install_certified);
        assert!(!report.package_publication_allowed);
        assert!(!report.conda_build_invoked);
        assert!(!report.conda_install_invoked);
        assert!(!report.external_publish_performed);
        assert!(!report.fallback_attempted);
        assert!(!report.fallback_dependency_allowed);
        assert!(report.release_gated());
        assert!(report.is_side_effect_free());
    }

    #[test]
    fn workspace_feature_build_matrix_declares_required_release_checks_without_runtime_expansion() {
        let report = plan_workspace_feature_build_matrix();

        assert_eq!(
            report.schema_version,
            "shardloom.workspace_feature_build_matrix.v1"
        );
        assert!(report.has_required_feature_coverage());
        assert!(report.release_claims_remain_blocked());
        assert!(report.no_runtime_or_fallback_expansion());
        assert!(report.rows.iter().any(|row| {
            row.feature_set == WorkspaceFeatureBuildMatrixFeatureSet::AllFeatures
                && row.command == "cargo check --workspace --all-features"
        }));
        assert!(report.rows.iter().any(|row| {
            row.feature_set == WorkspaceFeatureBuildMatrixFeatureSet::FutureFoundryOptional
                && row.status == WorkspaceFeatureBuildMatrixRowStatus::NotApplicableYet
        }));
        assert!(
            report
                .rows
                .iter()
                .all(|row| !row.public_release_claim_allowed)
        );
    }

    #[test]
    fn workspace_feature_build_matrix_blocks_claims_until_every_required_row_passes() {
        let mut report = plan_workspace_feature_build_matrix();
        report.rows[0].status = WorkspaceFeatureBuildMatrixRowStatus::Passed;

        assert!(!report.required_matrix_rows_all_passed());
        assert!(report.release_claims_remain_blocked());

        for row in &mut report.rows {
            if row.status != WorkspaceFeatureBuildMatrixRowStatus::NotApplicableYet {
                row.status = WorkspaceFeatureBuildMatrixRowStatus::Passed;
            }
        }

        assert!(report.required_matrix_rows_all_passed());
        assert!(!report.release_claims_remain_blocked());
    }
}
