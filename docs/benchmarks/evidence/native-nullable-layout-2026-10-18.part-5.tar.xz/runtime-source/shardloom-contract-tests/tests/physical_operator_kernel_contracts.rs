use shardloom_core::{
    BenchmarkEvidenceState, BenchmarkFallbackState, KernelKind, OperatorCertificationStatus,
    OperatorMemoryCertification, PhysicalKernelAdmissionReport, PhysicalKernelAdmissionStatus,
    PhysicalKernelRegistryPlan, PhysicalKernelRequirement, PhysicalKernelRequirementStatus,
    PhysicalKernelSelectionReport, PhysicalKernelSelectionStatus, PhysicalOperatorContract,
    PhysicalOperatorExecutionLevel, PhysicalOperatorExecutionProfileMatrix, PhysicalOperatorKind,
    PhysicalOperatorPlan, PhysicalOperatorPlanningCertificate,
    PhysicalOperatorPlanningCertificateStatus, PhysicalOperatorReadinessStatus,
};

fn safe_streaming_memory() -> OperatorMemoryCertification {
    OperatorMemoryCertification {
        streaming: true,
        bounded_memory: true,
        spillable: false,
        requires_full_materialization: false,
        requires_shuffle: false,
        oom_safe: true,
    }
}

fn ready_filter_plan() -> PhysicalOperatorPlan {
    let operator = PhysicalOperatorContract::new(
        "cg7.synthetic.filter",
        PhysicalOperatorKind::Filter,
        PhysicalOperatorExecutionLevel::EncodedNative,
        vec![
            PhysicalKernelRequirement::present(KernelKind::Metadata),
            PhysicalKernelRequirement::present(KernelKind::Encoded),
        ],
    )
    .expect("valid operator");
    let mut plan = PhysicalOperatorPlan {
        schema_version: "shardloom.physical_operator_plan.v1",
        plan_id: "cg7.synthetic-ready".to_string(),
        operators: vec![operator],
        diagnostics: Vec::new(),
    };
    plan.refresh_diagnostics();
    plan
}

#[test]
fn cg7_foundation_plan_declares_initial_operator_kernel_blockers() {
    let plan = PhysicalOperatorPlan::cg7_foundation();

    assert_eq!(plan.schema_version, "shardloom.physical_operator_plan.v1");
    assert!(plan.has_operator_kind(PhysicalOperatorKind::Filter));
    assert!(plan.has_operator_kind(PhysicalOperatorKind::Project));
    assert!(plan.has_operator_kind(PhysicalOperatorKind::CountAggregate));
    assert_eq!(plan.ready_for_native_planning_count(), 0);
    assert_eq!(plan.missing_kernel_count(), 3);
    assert_eq!(plan.unsupported_count(), 0);
    assert!(!plan.all_ready_for_native_planning());
    assert!(!plan.fallback_execution_allowed());
    assert!(!plan.diagnostics.is_empty());
    assert!(
        plan.to_human_text()
            .contains("schema_version: shardloom.physical_operator_plan.v1")
    );
    assert!(plan.to_human_text().contains("missing kernels: 3"));

    for operator in &plan.operators {
        assert_eq!(
            operator.readiness_status,
            PhysicalOperatorReadinessStatus::MissingKernel
        );
        assert_eq!(
            operator.certification_status,
            OperatorCertificationStatus::Planned
        );
        assert_eq!(operator.memory, OperatorMemoryCertification::unsupported());
        assert!(!operator.can_plan_native());
        assert!(!operator.fallback_execution_allowed());
        assert!(
            operator
                .to_human_text()
                .contains("fallback execution: disabled")
        );
    }
}

#[test]
fn current_runtime_plan_promotes_supported_operator_families_and_keeps_blockers_explicit() {
    let plan = PhysicalOperatorPlan::current_runtime();

    assert_eq!(plan.schema_version, "shardloom.physical_operator_plan.v1");
    assert_eq!(
        plan.plan_id,
        "runtime.5g-f1-physical-operator-kernel-coverage"
    );
    for kind in [
        PhysicalOperatorKind::Scan,
        PhysicalOperatorKind::Filter,
        PhysicalOperatorKind::Project,
        PhysicalOperatorKind::Limit,
        PhysicalOperatorKind::CountAggregate,
        PhysicalOperatorKind::Aggregate,
        PhysicalOperatorKind::Join,
        PhysicalOperatorKind::TopK,
        PhysicalOperatorKind::Sort,
        PhysicalOperatorKind::Window,
    ] {
        assert!(plan.has_operator_kind(kind), "missing {}", kind.as_str());
    }
    assert_eq!(plan.operators.len(), 12);
    assert_eq!(plan.ready_for_native_planning_count(), 10);
    assert_eq!(plan.missing_kernel_count(), 0);
    assert_eq!(plan.unsupported_count(), 2);
    assert!(!plan.all_ready_for_native_planning());
    assert!(!plan.fallback_execution_allowed());

    let filter = plan
        .operators
        .iter()
        .find(|operator| operator.kind == PhysicalOperatorKind::Filter)
        .expect("filter operator");
    assert_eq!(
        filter.readiness_status,
        PhysicalOperatorReadinessStatus::ReadyForNativePlanning
    );
    assert_eq!(
        filter.certification_status,
        OperatorCertificationStatus::EncodedCapable
    );
    assert!(filter.can_plan_native());
    assert_eq!(filter.kernel_requirements.len(), 2);

    let join = plan
        .operators
        .iter()
        .find(|operator| operator.kind == PhysicalOperatorKind::Join)
        .expect("join operator");
    assert_eq!(
        join.execution_level,
        PhysicalOperatorExecutionLevel::HybridNative
    );
    assert_eq!(
        join.certification_status,
        OperatorCertificationStatus::NativeDecoded
    );
    assert!(!join.memory.oom_safe);
    assert!(join.can_plan_native());

    for kind in [
        PhysicalOperatorKind::Repartition,
        PhysicalOperatorKind::Write,
    ] {
        let blocked = plan
            .operators
            .iter()
            .find(|operator| operator.kind == kind)
            .expect("blocked operator");
        assert_eq!(
            blocked.readiness_status,
            PhysicalOperatorReadinessStatus::Unsupported
        );
        assert_eq!(
            blocked.certification_status,
            OperatorCertificationStatus::Unsupported
        );
        assert!(!blocked.can_plan_native());
        assert!(!blocked.diagnostics.is_empty());
    }
}

#[test]
fn reference_only_kernel_requirement_cannot_satisfy_native_operator() {
    let requirement = PhysicalKernelRequirement::present(KernelKind::DecodedReference);

    assert_eq!(
        requirement.status,
        PhysicalKernelRequirementStatus::ReferenceOnlyRejected
    );
    assert!(!requirement.is_satisfied());

    let unsupported_requirement = PhysicalKernelRequirement::present(KernelKind::Unsupported);
    assert_eq!(
        unsupported_requirement.status,
        PhysicalKernelRequirementStatus::Missing
    );
    assert!(!unsupported_requirement.is_satisfied());
    assert_eq!(PhysicalOperatorKind::Unsupported.operator_family(), None);
}

#[test]
fn cg7_kernel_registry_plan_names_required_missing_kernel_slots() {
    let registry = PhysicalKernelRegistryPlan::cg7_foundation();

    assert_eq!(
        registry.schema_version,
        "shardloom.physical_kernel_registry_plan.v1"
    );
    assert_eq!(
        registry.registry_id,
        "cg7.1-physical-operator-foundation.kernel-registry"
    );
    assert_eq!(registry.required_slot_count(), 6);
    assert_eq!(registry.present_slot_count(), 0);
    assert_eq!(registry.missing_slot_count(), 6);
    assert_eq!(registry.reference_only_rejected_count(), 0);
    assert!(!registry.all_required_slots_satisfied());
    assert!(!registry.fallback_execution_allowed());
    assert!(!registry.runtime_execution_allowed());
    assert!(!registry.diagnostics.is_empty());
    assert!(
        registry
            .required_slots
            .iter()
            .any(|slot| slot.slot_id == "cg7.1.filter.kernel.metadata")
    );
    assert!(
        registry
            .required_slots
            .iter()
            .all(|slot| !slot.fallback_execution_allowed())
    );
    assert!(registry.to_human_text().contains("missing slots: 6"));
    assert!(
        registry
            .to_human_text()
            .contains("runtime execution: disabled")
    );
}

#[test]
fn current_runtime_registry_tracks_present_slots_and_unsupported_blocker_slots() {
    let plan = PhysicalOperatorPlan::current_runtime();
    let registry = PhysicalKernelRegistryPlan::from_operator_plan(&plan);

    assert_eq!(
        registry.registry_id,
        "runtime.5g-f1-physical-operator-kernel-coverage.kernel-registry"
    );
    assert_eq!(registry.required_slot_count(), 24);
    assert_eq!(registry.present_slot_count(), 22);
    assert_eq!(registry.missing_slot_count(), 2);
    assert_eq!(registry.reference_only_rejected_count(), 0);
    assert!(!registry.all_required_slots_satisfied());
    assert!(registry.required_slots.iter().any(|slot| {
        slot.slot_id == "runtime.5g-f1.filter.kernel.encoded"
            && slot.status == PhysicalKernelRequirementStatus::Present
    }));
    assert!(registry.required_slots.iter().any(|slot| {
        slot.slot_id == "runtime.5g-f1.join.kernel.encoded"
            && slot.status == PhysicalKernelRequirementStatus::Present
    }));
    assert!(registry.required_slots.iter().any(|slot| {
        slot.slot_id == "runtime.5g-f1.write.kernel.unsupported"
            && slot.status == PhysicalKernelRequirementStatus::Missing
    }));
}

#[test]
fn physical_kernel_admission_blocks_reference_fallback_and_missing_evidence() {
    let registry = PhysicalKernelRegistryPlan::cg7_foundation();
    let slot = registry
        .required_slots
        .iter()
        .find(|slot| slot.slot_id == "cg7.1.filter.kernel.metadata")
        .expect("slot exists");

    let reference = PhysicalKernelAdmissionReport::evaluate(
        slot,
        KernelKind::DecodedReference,
        BenchmarkEvidenceState::Present,
        BenchmarkEvidenceState::Present,
        safe_streaming_memory(),
        BenchmarkFallbackState::NotAttempted,
    );
    assert_eq!(
        reference.status,
        PhysicalKernelAdmissionStatus::BlockedReferenceOnlyKernel
    );
    assert_eq!(
        reference.schema_version,
        "shardloom.physical_kernel_admission.v1"
    );
    assert!(!reference.can_mark_kernel_present());

    let mismatch = PhysicalKernelAdmissionReport::evaluate(
        slot,
        KernelKind::Encoded,
        BenchmarkEvidenceState::Present,
        BenchmarkEvidenceState::Present,
        safe_streaming_memory(),
        BenchmarkFallbackState::NotAttempted,
    );
    assert_eq!(
        mismatch.status,
        PhysicalKernelAdmissionStatus::BlockedKernelKindMismatch
    );

    let fallback = PhysicalKernelAdmissionReport::evaluate(
        slot,
        KernelKind::Metadata,
        BenchmarkEvidenceState::Present,
        BenchmarkEvidenceState::Present,
        safe_streaming_memory(),
        BenchmarkFallbackState::Attempted,
    );
    assert_eq!(
        fallback.status,
        PhysicalKernelAdmissionStatus::BlockedFallbackAttempted
    );
    assert!(fallback.fallback_attempted());
    assert!(!fallback.fallback_execution_allowed());

    let missing_correctness = PhysicalKernelAdmissionReport::evaluate(
        slot,
        KernelKind::Metadata,
        BenchmarkEvidenceState::Missing,
        BenchmarkEvidenceState::Present,
        safe_streaming_memory(),
        BenchmarkFallbackState::NotAttempted,
    );
    assert_eq!(
        missing_correctness.status,
        PhysicalKernelAdmissionStatus::BlockedMissingCorrectness
    );
    assert!(!missing_correctness.diagnostics.is_empty());

    let unsafe_memory = PhysicalKernelAdmissionReport::evaluate(
        slot,
        KernelKind::Metadata,
        BenchmarkEvidenceState::Present,
        BenchmarkEvidenceState::Present,
        OperatorMemoryCertification::unsupported(),
        BenchmarkFallbackState::NotAttempted,
    );
    assert_eq!(
        unsafe_memory.status,
        PhysicalKernelAdmissionStatus::BlockedMissingMemorySafety
    );
}

#[test]
fn physical_kernel_admission_allows_registry_before_production_claims() {
    let registry = PhysicalKernelRegistryPlan::cg7_foundation();
    let slot = registry
        .required_slots
        .iter()
        .find(|slot| slot.slot_id == "cg7.1.filter.kernel.metadata")
        .expect("slot exists");

    let registry_ready = PhysicalKernelAdmissionReport::evaluate(
        slot,
        KernelKind::Metadata,
        BenchmarkEvidenceState::Present,
        BenchmarkEvidenceState::Missing,
        safe_streaming_memory(),
        BenchmarkFallbackState::NotAttempted,
    );
    assert_eq!(
        registry_ready.status,
        PhysicalKernelAdmissionStatus::RegistryReady
    );
    assert!(registry_ready.can_mark_kernel_present());
    assert!(!registry_ready.can_satisfy_production_claim());
    assert!(registry_ready.diagnostics.is_empty());
    assert!(
        registry_ready
            .to_human_text()
            .contains("fallback execution: disabled")
    );

    let production_ready = PhysicalKernelAdmissionReport::evaluate(
        slot,
        KernelKind::Metadata,
        BenchmarkEvidenceState::Present,
        BenchmarkEvidenceState::Present,
        safe_streaming_memory(),
        BenchmarkFallbackState::NotAttempted,
    );
    assert_eq!(
        production_ready.status,
        PhysicalKernelAdmissionStatus::ProductionReady
    );
    assert!(production_ready.can_mark_kernel_present());
    assert!(production_ready.can_satisfy_production_claim());
}

#[test]
fn physical_operator_execution_profiles_declare_native_levels_without_materialization() {
    let matrix = PhysicalOperatorExecutionProfileMatrix::cg7_foundation();

    assert_eq!(
        matrix.schema_version,
        "shardloom.physical_operator_execution_profiles.v1"
    );
    assert_eq!(matrix.profile_count(), 3);
    assert_eq!(matrix.native_execution_level_count(), 4);
    assert_eq!(
        matrix.allowed_level_count(PhysicalOperatorExecutionLevel::MetadataOnly),
        3
    );
    assert_eq!(
        matrix.allowed_level_count(PhysicalOperatorExecutionLevel::EncodedNative),
        3
    );
    assert_eq!(
        matrix.allowed_level_count(PhysicalOperatorExecutionLevel::HybridNative),
        3
    );
    assert_eq!(
        matrix.allowed_level_count(PhysicalOperatorExecutionLevel::NativeDecoded),
        3
    );
    assert_eq!(matrix.reference_only_allowed_count(), 0);
    assert_eq!(matrix.unsupported_allowed_count(), 0);
    assert_eq!(matrix.row_materialization_allowed_count(), 0);
    assert_eq!(matrix.arrow_conversion_allowed_count(), 0);
    assert_eq!(matrix.fallback_allowed_count(), 0);

    for operator_kind in [
        PhysicalOperatorKind::Filter,
        PhysicalOperatorKind::Project,
        PhysicalOperatorKind::CountAggregate,
    ] {
        let profile = matrix
            .profile_for(operator_kind)
            .expect("foundation operator profile exists");
        assert_eq!(
            profile.preferred_level,
            PhysicalOperatorExecutionLevel::EncodedNative
        );
        assert!(profile.allows_level(PhysicalOperatorExecutionLevel::MetadataOnly));
        assert!(profile.allows_level(PhysicalOperatorExecutionLevel::EncodedNative));
        assert!(profile.allows_level(PhysicalOperatorExecutionLevel::HybridNative));
        assert!(profile.allows_level(PhysicalOperatorExecutionLevel::NativeDecoded));
        assert!(!profile.allows_reference_only());
        assert!(!profile.fallback_execution_allowed);
    }

    assert!(matrix.to_human_text().contains("reference-only allowed: 0"));
}

#[test]
fn current_runtime_profile_matrix_declares_supported_and_blocked_levels() {
    let matrix = PhysicalOperatorExecutionProfileMatrix::current_runtime();

    assert_eq!(
        matrix.schema_version,
        "shardloom.physical_operator_execution_profiles.v1"
    );
    assert_eq!(matrix.matrix_id, "runtime-5g-f1-execution-profile-matrix");
    assert_eq!(matrix.profile_count(), 12);
    assert_eq!(matrix.native_execution_level_count(), 4);
    assert_eq!(
        matrix.allowed_level_count(PhysicalOperatorExecutionLevel::MetadataOnly),
        4
    );
    assert_eq!(
        matrix.allowed_level_count(PhysicalOperatorExecutionLevel::EncodedNative),
        3
    );
    assert_eq!(
        matrix.allowed_level_count(PhysicalOperatorExecutionLevel::HybridNative),
        5
    );
    assert_eq!(
        matrix.allowed_level_count(PhysicalOperatorExecutionLevel::NativeDecoded),
        8
    );
    assert_eq!(matrix.reference_only_allowed_count(), 0);
    assert_eq!(matrix.unsupported_allowed_count(), 2);
    assert_eq!(matrix.fallback_allowed_count(), 0);

    let top_k = matrix
        .profile_for(PhysicalOperatorKind::TopK)
        .expect("top-k profile");
    assert_eq!(
        top_k.preferred_level,
        PhysicalOperatorExecutionLevel::NativeDecoded
    );
    assert!(top_k.allows_level(PhysicalOperatorExecutionLevel::NativeDecoded));
    assert!(!top_k.allows_level(PhysicalOperatorExecutionLevel::EncodedNative));

    let write = matrix
        .profile_for(PhysicalOperatorKind::Write)
        .expect("write profile");
    assert!(write.allows_unsupported());
    assert!(!write.allows_reference_only());
}

#[test]
fn physical_kernel_selection_blocks_missing_slots_and_rejected_levels() {
    let profiles = PhysicalOperatorExecutionProfileMatrix::cg7_foundation();
    let registry = PhysicalKernelRegistryPlan::cg7_foundation();

    let missing = PhysicalKernelSelectionReport::evaluate(
        PhysicalOperatorKind::Filter,
        PhysicalOperatorExecutionLevel::EncodedNative,
        &profiles,
        &registry,
    );
    assert_eq!(
        missing.schema_version,
        "shardloom.physical_kernel_selection.v1"
    );
    assert_eq!(
        missing.status,
        PhysicalKernelSelectionStatus::RequiredKernelMissing
    );
    assert_eq!(missing.missing_slot_ids.len(), 2);
    assert!(!missing.can_select_kernel());
    assert!(!missing.runtime_execution_allowed());
    assert!(!missing.fallback_execution_allowed());
    assert!(!missing.diagnostics.is_empty());

    let empty_registry = PhysicalKernelRegistryPlan {
        schema_version: "shardloom.physical_kernel_registry_plan.v1",
        registry_id: "cg7.empty.kernel-registry".to_string(),
        required_slots: Vec::new(),
        diagnostics: Vec::new(),
    };
    let absent_slots = PhysicalKernelSelectionReport::evaluate(
        PhysicalOperatorKind::Filter,
        PhysicalOperatorExecutionLevel::EncodedNative,
        &profiles,
        &empty_registry,
    );
    assert_eq!(
        absent_slots.status,
        PhysicalKernelSelectionStatus::RequiredKernelMissing
    );
    assert_eq!(absent_slots.missing_slot_ids.len(), 2);
    assert!(
        absent_slots
            .missing_slot_ids
            .iter()
            .all(|slot_id| slot_id.ends_with(".missing"))
    );

    let rejected_level = PhysicalKernelSelectionReport::evaluate(
        PhysicalOperatorKind::Filter,
        PhysicalOperatorExecutionLevel::TestReferenceOnly,
        &profiles,
        &registry,
    );
    assert_eq!(
        rejected_level.status,
        PhysicalKernelSelectionStatus::ExecutionLevelRejected
    );
    assert!(!rejected_level.can_select_kernel());

    let missing_profile = PhysicalKernelSelectionReport::evaluate(
        PhysicalOperatorKind::Join,
        PhysicalOperatorExecutionLevel::EncodedNative,
        &profiles,
        &registry,
    );
    assert_eq!(
        missing_profile.status,
        PhysicalKernelSelectionStatus::OperatorProfileMissing
    );
}

#[test]
fn current_runtime_kernel_selection_selects_ready_families_and_blocks_unsupported_slots() {
    let plan = PhysicalOperatorPlan::current_runtime();
    let registry = PhysicalKernelRegistryPlan::from_operator_plan(&plan);
    let profiles = PhysicalOperatorExecutionProfileMatrix::current_runtime();

    let filter_selection = PhysicalKernelSelectionReport::evaluate(
        PhysicalOperatorKind::Filter,
        PhysicalOperatorExecutionLevel::EncodedNative,
        &profiles,
        &registry,
    );
    assert_eq!(
        filter_selection.status,
        PhysicalKernelSelectionStatus::ReadyForAdmissionReview
    );
    assert!(filter_selection.can_select_kernel());
    assert!(filter_selection.missing_slot_ids.is_empty());

    let join_selection = PhysicalKernelSelectionReport::evaluate(
        PhysicalOperatorKind::Join,
        PhysicalOperatorExecutionLevel::HybridNative,
        &profiles,
        &registry,
    );
    assert_eq!(
        join_selection.status,
        PhysicalKernelSelectionStatus::ReadyForAdmissionReview
    );
    assert_eq!(
        join_selection.required_kernel_kinds,
        vec![
            KernelKind::Metadata,
            KernelKind::Encoded,
            KernelKind::PartialDecode
        ]
    );
    assert!(join_selection.can_select_kernel());

    let top_k_selection = PhysicalKernelSelectionReport::evaluate(
        PhysicalOperatorKind::TopK,
        PhysicalOperatorExecutionLevel::NativeDecoded,
        &profiles,
        &registry,
    );
    assert_eq!(
        top_k_selection.status,
        PhysicalKernelSelectionStatus::ReadyForAdmissionReview
    );
    assert!(top_k_selection.can_select_kernel());

    let write_selection = PhysicalKernelSelectionReport::evaluate(
        PhysicalOperatorKind::Write,
        PhysicalOperatorExecutionLevel::Unsupported,
        &profiles,
        &registry,
    );
    assert_eq!(
        write_selection.status,
        PhysicalKernelSelectionStatus::RequiredKernelMissing
    );
    assert!(!write_selection.can_select_kernel());
    assert_eq!(
        write_selection.missing_slot_ids,
        vec!["runtime.5g-f1.write.kernel.unsupported".to_string()]
    );
}

#[test]
fn physical_kernel_selection_can_reach_admission_review_without_execution() {
    let profiles = PhysicalOperatorExecutionProfileMatrix::cg7_foundation();
    let plan = ready_filter_plan();
    let registry = PhysicalKernelRegistryPlan::from_operator_plan(&plan);

    let selection = PhysicalKernelSelectionReport::evaluate(
        PhysicalOperatorKind::Filter,
        PhysicalOperatorExecutionLevel::EncodedNative,
        &profiles,
        &registry,
    );

    assert_eq!(
        selection.status,
        PhysicalKernelSelectionStatus::ReadyForAdmissionReview
    );
    assert!(selection.can_select_kernel());
    assert!(selection.diagnostics.is_empty());
    assert!(selection.to_human_text().contains("missing slots: 0"));
    assert!(!selection.runtime_execution_allowed());
    assert!(!selection.fallback_execution_allowed());
}

#[test]
fn physical_kernel_selection_uses_execution_level_specific_requirements() {
    let profiles = PhysicalOperatorExecutionProfileMatrix::cg7_foundation();
    let metadata_operator = PhysicalOperatorContract::new(
        "cg7.synthetic.metadata-filter",
        PhysicalOperatorKind::Filter,
        PhysicalOperatorExecutionLevel::MetadataOnly,
        vec![PhysicalKernelRequirement::present(KernelKind::Metadata)],
    )
    .expect("valid operator");
    let mut metadata_plan = PhysicalOperatorPlan {
        schema_version: "shardloom.physical_operator_plan.v1",
        plan_id: "cg7.synthetic-metadata-ready".to_string(),
        operators: vec![metadata_operator],
        diagnostics: Vec::new(),
    };
    metadata_plan.refresh_diagnostics();
    let metadata_registry = PhysicalKernelRegistryPlan::from_operator_plan(&metadata_plan);

    let metadata_selection = PhysicalKernelSelectionReport::evaluate(
        PhysicalOperatorKind::Filter,
        PhysicalOperatorExecutionLevel::MetadataOnly,
        &profiles,
        &metadata_registry,
    );
    assert_eq!(
        metadata_selection.status,
        PhysicalKernelSelectionStatus::ReadyForAdmissionReview
    );
    assert_eq!(
        metadata_selection.required_kernel_kinds,
        vec![KernelKind::Metadata]
    );
    assert!(metadata_selection.missing_slot_ids.is_empty());

    let encoded_selection = PhysicalKernelSelectionReport::evaluate(
        PhysicalOperatorKind::Filter,
        PhysicalOperatorExecutionLevel::EncodedNative,
        &profiles,
        &metadata_registry,
    );
    assert_eq!(
        encoded_selection.status,
        PhysicalKernelSelectionStatus::RequiredKernelMissing
    );
    assert_eq!(
        encoded_selection.required_kernel_kinds,
        vec![KernelKind::Metadata, KernelKind::Encoded]
    );
    assert!(
        encoded_selection
            .missing_slot_ids
            .iter()
            .any(|slot_id| slot_id.contains(".encoded.missing"))
    );

    let encoded_plan = ready_filter_plan();
    let encoded_registry = PhysicalKernelRegistryPlan::from_operator_plan(&encoded_plan);
    let hybrid_selection = PhysicalKernelSelectionReport::evaluate(
        PhysicalOperatorKind::Filter,
        PhysicalOperatorExecutionLevel::HybridNative,
        &profiles,
        &encoded_registry,
    );
    assert_eq!(
        hybrid_selection.status,
        PhysicalKernelSelectionStatus::RequiredKernelMissing
    );
    assert_eq!(
        hybrid_selection.required_kernel_kinds,
        vec![
            KernelKind::Metadata,
            KernelKind::Encoded,
            KernelKind::PartialDecode
        ]
    );
    assert!(
        hybrid_selection
            .missing_slot_ids
            .iter()
            .any(|slot_id| slot_id.contains(".partial_decode.missing"))
    );
}

#[test]
fn physical_operator_planning_certificate_blocks_foundation_missing_kernels() {
    let plan = PhysicalOperatorPlan::cg7_foundation();
    let profiles = PhysicalOperatorExecutionProfileMatrix::cg7_foundation();

    let certificate = PhysicalOperatorPlanningCertificate::evaluate(
        &plan,
        &profiles,
        BenchmarkEvidenceState::Missing,
        BenchmarkEvidenceState::Missing,
        OperatorMemoryCertification::unsupported(),
        BenchmarkFallbackState::NotAttempted,
    );

    assert_eq!(
        certificate.schema_version,
        "shardloom.physical_operator_planning_certificate.v1"
    );
    assert_eq!(
        certificate.status,
        PhysicalOperatorPlanningCertificateStatus::OperatorPlanBlocked
    );
    assert_eq!(certificate.operator_count, 3);
    assert_eq!(certificate.ready_operator_count, 0);
    assert_eq!(certificate.missing_kernel_operator_count, 3);
    assert_eq!(certificate.required_slot_count, 6);
    assert_eq!(certificate.missing_slot_count, 6);
    assert_eq!(certificate.selection_blocked_count, 3);
    assert_eq!(certificate.admission_blocked_count, 6);
    assert!(!certificate.can_plan_native());
    assert!(!certificate.can_satisfy_production_claim());
    assert!(!certificate.runtime_execution_allowed());
    assert!(!certificate.fallback_execution_allowed());
    assert!(!certificate.fallback_attempted);
    assert!(!certificate.diagnostics.is_empty());
}

#[test]
fn physical_operator_planning_certificate_reaches_native_planning_without_runtime() {
    let plan = ready_filter_plan();
    let profiles = PhysicalOperatorExecutionProfileMatrix::cg7_foundation();

    let certificate = PhysicalOperatorPlanningCertificate::evaluate(
        &plan,
        &profiles,
        BenchmarkEvidenceState::Present,
        BenchmarkEvidenceState::Missing,
        safe_streaming_memory(),
        BenchmarkFallbackState::NotAttempted,
    );

    assert_eq!(
        certificate.status,
        PhysicalOperatorPlanningCertificateStatus::ReadyForNativePlanning
    );
    assert_eq!(certificate.operator_count, 1);
    assert_eq!(certificate.ready_operator_count, 1);
    assert_eq!(certificate.required_slot_count, 2);
    assert_eq!(certificate.missing_slot_count, 0);
    assert_eq!(certificate.selection_blocked_count, 0);
    assert_eq!(certificate.admission_blocked_count, 0);
    assert_eq!(certificate.registry_ready_slot_count, 2);
    assert_eq!(certificate.production_ready_slot_count, 0);
    assert!(certificate.can_plan_native());
    assert!(!certificate.can_satisfy_production_claim());
    assert!(!certificate.runtime_execution_allowed());
    assert!(!certificate.fallback_execution_allowed());
    assert!(certificate.diagnostics.is_empty());
    assert!(
        certificate
            .to_human_text()
            .contains("runtime execution: disabled")
    );
}

#[test]
fn physical_operator_planning_certificate_separates_production_and_fallback_blockers() {
    let plan = ready_filter_plan();
    let profiles = PhysicalOperatorExecutionProfileMatrix::cg7_foundation();

    let production = PhysicalOperatorPlanningCertificate::evaluate(
        &plan,
        &profiles,
        BenchmarkEvidenceState::Present,
        BenchmarkEvidenceState::Present,
        safe_streaming_memory(),
        BenchmarkFallbackState::NotAttempted,
    );
    assert_eq!(
        production.status,
        PhysicalOperatorPlanningCertificateStatus::ProductionCertified
    );
    assert_eq!(production.production_ready_slot_count, 2);
    assert!(production.can_satisfy_production_claim());
    assert!(!production.runtime_execution_allowed());
    assert!(!production.fallback_execution_allowed());

    let fallback_blocked = PhysicalOperatorPlanningCertificate::evaluate(
        &plan,
        &profiles,
        BenchmarkEvidenceState::Present,
        BenchmarkEvidenceState::Present,
        safe_streaming_memory(),
        BenchmarkFallbackState::Attempted,
    );
    assert_eq!(
        fallback_blocked.status,
        PhysicalOperatorPlanningCertificateStatus::KernelAdmissionBlocked
    );
    assert_eq!(fallback_blocked.admission_blocked_count, 2);
    assert!(fallback_blocked.fallback_attempted);
    assert!(!fallback_blocked.can_plan_native());
    assert!(!fallback_blocked.fallback_execution_allowed());
    assert!(!fallback_blocked.diagnostics.is_empty());
}

#[test]
fn native_kernel_requirements_can_reach_planning_ready_without_execution() {
    let operator = PhysicalOperatorContract::new(
        "cg7.synthetic.filter",
        PhysicalOperatorKind::Filter,
        PhysicalOperatorExecutionLevel::EncodedNative,
        vec![
            PhysicalKernelRequirement::present(KernelKind::Metadata),
            PhysicalKernelRequirement::present(KernelKind::Encoded),
        ],
    )
    .expect("valid operator");

    assert_eq!(
        operator.readiness_status,
        PhysicalOperatorReadinessStatus::ReadyForNativePlanning
    );
    assert!(operator.can_plan_native());
    assert!(operator.diagnostics.is_empty());
    assert!(!operator.fallback_execution_allowed());
}

#[test]
fn unsupported_operator_level_blocks_native_planning() {
    let operator = PhysicalOperatorContract::new(
        "cg7.synthetic.reference",
        PhysicalOperatorKind::Filter,
        PhysicalOperatorExecutionLevel::TestReferenceOnly,
        vec![PhysicalKernelRequirement::present(
            KernelKind::DecodedReference,
        )],
    )
    .expect("valid operator");

    assert_eq!(
        operator.readiness_status,
        PhysicalOperatorReadinessStatus::Unsupported
    );
    assert!(!operator.can_plan_native());
    assert!(!operator.diagnostics[0].fallback.attempted);
}
