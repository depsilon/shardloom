use super::*;
use std::io::BufRead as _;
use std::process::{Child, Command, Stdio};
use std::time::{Duration, Instant};

const CHILD_WORKSPACE: &str = "SHARDLOOM_RUN_RECOVERY_CHILD_WORKSPACE";
const CHILD_NAMESPACE: &str = "SHARDLOOM_RUN_RECOVERY_CHILD_NAMESPACE";
const READY: &str = "SHARDLOOM_RECOVERY_DIRECTORY=";

fn policy(workspace: &Path, namespace: &str) -> QueryRunStorePolicy {
    let cancel = Arc::new(AtomicBool::new(false));
    match namespace {
        "count" => QueryRunStorePolicy::weighted_utf8_count(workspace.into(), 32 << 20, cancel),
        "distinct" => {
            QueryRunStorePolicy::exact_integer_distinct(workspace.into(), 32 << 20, cancel)
        }
        "sort" => QueryRunStorePolicy::numeric_sort(
            &crate::VortexSortSpillPolicy::new(workspace, 32 << 20, 4 << 20).unwrap(),
        ),
        "relational_order" => QueryRunStorePolicy::relational_order(
            &crate::relational_query::VortexRelationalSpillPolicy::new(
                workspace,
                32 << 20,
                1 << 20,
            )
            .unwrap(),
            CancellationToken::default(),
        ),
        _ => panic!("unknown recovery test namespace"),
    }
}

// A real process exit bypasses Rust destructors, unlike dropping a test fixture.
#[test]
fn recovery_process_child() {
    let Some(workspace) = std::env::var_os(CHILD_WORKSPACE) else {
        return;
    };
    let namespace = std::env::var(CHILD_NAMESPACE).unwrap();
    let memory = LiveMemoryPool::new(8 << 20).unwrap();
    let runtime = local_vortex_runtime(
        VortexLocalPrimitiveExecutionPolicy::new_with_memory_gb(1, 4)
            .expect("explicit fixture allocation"),
    );
    let session = VortexSession::default().with_handle(runtime.handle());
    let work = Arc::new(memory.reserve(1 << 20).unwrap());
    let mut store = QueryRunStore::new(
        policy(Path::new(&workspace), &namespace),
        memory.clone(),
        memory.reserve(128 << 10).unwrap(),
    )
    .unwrap();
    for values in [[i32::MIN, 0], [17, i32::MAX]] {
        store
            .write_arrays(&spec(2), arrays(&values), &runtime, &session, &work)
            .unwrap();
    }
    println!("{READY}{}", store.directory().display());
    std::io::stdout().flush().unwrap();
    let mut command = [0];
    std::io::Read::read_exact(&mut std::io::stdin(), &mut command).unwrap();
    assert_eq!(command, [b'x']);
    std::process::exit(71);
}

struct ChildOwner(Child);
impl Drop for ChildOwner {
    fn drop(&mut self) {
        let _ = self.0.kill();
        let _ = self.0.wait();
    }
}

#[test]
fn directory_owner_releases_lock_while_inherited_descriptor_remains_open() {
    let workspace = Workspace::new();
    let owner = lock_directory(&workspace.0).unwrap();
    let inherited = owner.file.try_clone().unwrap();
    assert!(lock_directory(&workspace.0).is_err());
    drop(owner);
    let replacement = lock_directory(&workspace.0)
        .expect("finished ownership must release the lock before inherited descriptors close");
    drop(inherited);
    assert!(lock_directory(&workspace.0).is_err());
    drop(replacement);
    drop(lock_directory(&workspace.0).unwrap());
    workspace.assert_empty();
}

#[test]
fn all_namespaces_reject_live_recovery_and_clean_after_process_exit() {
    for namespace in ["sort", "distinct", "count", "relational_order"] {
        let workspace = Workspace::new();
        let mut child = ChildOwner(
            Command::new(std::env::current_exe().unwrap())
                .args(["recovery_process_child", "--nocapture", "--test-threads=1"])
                .env(CHILD_WORKSPACE, &workspace.0)
                .env(CHILD_NAMESPACE, namespace)
                .stdin(Stdio::piped())
                .stdout(Stdio::piped())
                .stderr(Stdio::inherit())
                .spawn()
                .unwrap(),
        );
        let stdout = child.0.stdout.take().unwrap();
        let (send, receive) = std::sync::mpsc::sync_channel(1);
        let reader = std::thread::spawn(move || {
            for line in std::io::BufReader::new(stdout).lines() {
                let line = line.unwrap();
                if let Some((_, path)) = line.split_once(READY) {
                    let _ = send.send(PathBuf::from(path));
                    break;
                }
            }
        });
        let directory = receive.recv_timeout(Duration::from_secs(20)).unwrap();
        reader.join().unwrap();
        let policy = policy(&workspace.0, namespace);
        let marker_before = fs::read(directory.join(OWNERSHIP_MARKER)).unwrap();
        assert!(
            recover(&policy, &directory)
                .unwrap_err()
                .to_string()
                .contains("workspace is active")
        );
        assert_eq!(
            fs::read(directory.join(OWNERSHIP_MARKER)).unwrap(),
            marker_before
        );
        assert_eq!(fs::read_dir(&directory).unwrap().count(), 3);
        child.0.stdin.as_mut().unwrap().write_all(b"x").unwrap();
        let deadline = Instant::now() + Duration::from_secs(10);
        loop {
            if let Some(status) = child.0.try_wait().unwrap() {
                assert_eq!(status.code(), Some(71));
                break;
            }
            assert!(Instant::now() < deadline, "recovery child did not exit");
            std::thread::sleep(Duration::from_millis(10));
        }
        recover(&policy, &directory).unwrap();
        workspace.assert_empty();
    }
}

#[test]
#[allow(clippy::too_many_lines)] // Keep cancellation, inherited locks, marker preservation and retry in one scope.
fn cancelled_recovery_preserves_marker_and_can_be_retried() {
    for (namespace, run_count) in ["sort", "distinct", "count", "relational_order"]
        .into_iter()
        .flat_map(|namespace| [(namespace, 1), (namespace, 2)])
    {
        let workspace = Workspace::new();
        let memory = LiveMemoryPool::new(4 << 20).unwrap();
        let mut store = QueryRunStore::new(
            policy(&workspace.0, namespace),
            memory.clone(),
            memory.reserve(128 << 10).unwrap(),
        )
        .unwrap();
        let runtime = local_vortex_runtime(
            VortexLocalPrimitiveExecutionPolicy::new_with_memory_gb(1, 4)
                .expect("explicit fixture allocation"),
        );
        let session = VortexSession::default().with_handle(runtime.handle());
        let work = Arc::new(memory.reserve(1 << 20).unwrap());
        for values in [[1, 2], [3, 4]].into_iter().take(run_count) {
            store
                .write_arrays(&spec(2), arrays(&values), &runtime, &session, &work)
                .unwrap();
        }
        let directory = store.directory().to_path_buf();
        // A concurrent fork can briefly retain the same open file description
        // until exec. Model it deterministically without relying on scheduling.
        let inherited_owner = store
            .directory_owner
            .as_ref()
            .unwrap()
            .file
            .try_clone()
            .unwrap();
        store.abandon_for_recovery_test();
        let marker = fs::read(directory.join(OWNERSHIP_MARKER)).unwrap();
        let sort = crate::VortexSortSpillPolicy::new(&workspace.0, 32 << 20, 4 << 20).unwrap();
        let aggregate =
            crate::VortexAggregateSpillPolicy::new(&workspace.0, 32 << 20, 4 << 20).unwrap();
        let relational = crate::relational_query::VortexRelationalSpillPolicy::new(
            &workspace.0,
            32 << 20,
            1 << 20,
        )
        .unwrap();
        let token = CancellationToken::default();
        let stale_sort = sort.clone();
        let stale_aggregate = aggregate.clone();
        let stale_token = token.clone();
        let inherited_recovery = std::rc::Rc::new(std::cell::RefCell::new(None));
        let retained = std::rc::Rc::clone(&inherited_recovery);
        AFTER_RECOVERY_LOCK.with(|hook| {
            *hook.borrow_mut() = Some(Box::new(move |owner| {
                *retained.borrow_mut() = Some(owner.try_clone().unwrap());
            }));
        });
        AFTER_RECOVERY_REMOVE.with(|hook| {
            *hook.borrow_mut() = Some(Box::new(move || {
                stale_sort.cancel();
                stale_aggregate.cancel();
                stale_token.cancel();
            }));
        });
        let cleanup = |sort: &crate::VortexSortSpillPolicy,
                       aggregate: &crate::VortexAggregateSpillPolicy,
                       token: &CancellationToken| {
            match namespace {
                "sort" => sort.cleanup_abandoned(&directory),
                "distinct" => aggregate.cleanup_abandoned(&directory),
                "count" => aggregate.cleanup_abandoned_weighted_count(&directory),
                "relational_order" => relational.cleanup_abandoned_controlled(&directory, token),
                _ => unreachable!(),
            }
        };
        let error = cleanup(&sort, &aggregate, &token).unwrap_err();
        assert!(
            error.to_string().contains("cancelled"),
            "{namespace}: {error}"
        );
        assert!(AFTER_RECOVERY_REMOVE.with(|hook| hook.borrow().is_none()));
        assert!(AFTER_RECOVERY_LOCK.with(|hook| hook.borrow().is_none()));
        assert!(inherited_recovery.borrow().is_some());
        // Keep the marker even when cancellation follows the last run deletion.
        assert_eq!(fs::read_dir(&directory).unwrap().count(), run_count);
        assert_eq!(fs::read(directory.join(OWNERSHIP_MARKER)).unwrap(), marker);
        assert!(cleanup(&sort, &aggregate, &token).is_err());
        let renewed_sort = sort.renew_cancellation().unwrap();
        let renewed_aggregate = aggregate.renew_cancellation().unwrap();
        assert_eq!(renewed_sort.workspace, sort.workspace);
        assert_eq!(renewed_sort.quota_bytes, sort.quota_bytes);
        assert_eq!(renewed_sort.memory_bytes, sort.memory_bytes);
        assert_eq!(renewed_aggregate.workspace, aggregate.workspace);
        assert_eq!(renewed_aggregate.quota_bytes, aggregate.quota_bytes);
        assert_eq!(renewed_aggregate.memory_bytes, aggregate.memory_bytes);
        sort.cancel();
        aggregate.cancel();
        token.cancel();
        cleanup(
            &renewed_sort,
            &renewed_aggregate,
            &CancellationToken::default(),
        )
        .unwrap();
        drop(inherited_recovery);
        drop(inherited_owner);
        drop(store);
        drop(work);
        assert_eq!(memory.snapshot().reserved_bytes, 0);
        workspace.assert_empty();
    }
}

#[test]
fn relational_recovery_cancellation_precedes_filesystem_access() {
    let workspace = Workspace::new();
    let missing = workspace.0.join("missing");
    let policy =
        crate::relational_query::VortexRelationalSpillPolicy::new(&missing, 32 << 20, 1 << 20)
            .unwrap();
    let explicit = CancellationToken::default();
    explicit.cancel();
    let parent = CancellationToken::default();
    let child = parent.with_deadline(Instant::now() + Duration::from_secs(60));
    parent.cancel();
    let expired = CancellationToken::default().with_deadline(Instant::now());
    for token in [explicit, child, expired] {
        let error = policy
            .cleanup_abandoned_controlled(
                &missing.join("shardloom-query-relational-order-0"),
                &token,
            )
            .unwrap_err();
        assert!(error.to_string().contains("cancelled"), "{error}");
        assert!(!missing.exists());
    }
    workspace.assert_empty();
}
