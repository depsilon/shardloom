//! Report the native providers, explicit materialization and observation limits.

use super::{ExecutedVortexBatchInput, Metrics, Result};
use shardloom_core::{
    NativeIoAdapterFidelityReport, NativeIoCertificate, NativeIoMaterializationBoundaryReport,
    NativeIoRepresentationTransition, NativeIoSideEffectReport, NativeIoSinkRequirementReport,
    NativeIoSourceCapabilityReport, NativeIoSourcePushdownReport, RepresentationState,
};

#[allow(clippy::too_many_lines)] // One declarative certificate covers the same execution.
pub(super) fn certificate(
    metrics: &Metrics<'_>,
    rows: u64,
    batch_rows: usize,
    sources: usize,
    memory_sources: usize,
    input: Option<&ExecutedVortexBatchInput>,
    spill: Option<&crate::relational_query::VortexRelationalSpillReport>,
) -> Result<NativeIoCertificate> {
    let file_sources = sources;
    let batch_sources = input.map_or(0, |input| input.sources);
    let sources = file_sources + memory_sources + batch_sources;
    let data_work = metrics.data_scans.get() > 0;
    let spilled = spill.is_some_and(|report| report.runs_written > 0);
    let replay_proof = input.map_or_else(String::new, |input| format!(
        "streaming_replay_sources={} streaming_replay_passes={} streaming_replay_rows={} streaming_replay_batches_detached={} streaming_replay_rows_detached={} streaming_replay_buffer_bytes_copied={} streaming_replay_spilled_sources={} streaming_replay_prefilled_sources={}",
        input.replay_sources, input.replay_passes, input.replay_rows,
        input.replay_batches_detached, input.replay_rows_detached,
        input.replay_buffer_bytes_copied, input.replay_spilled_sources,
        input.replay_prefilled_sources,
    ));
    let subquery_proof = input.map_or_else(String::new, |input| format!(
        "streaming_subquery_outer_batches_detached={} streaming_subquery_outer_rows_detached={} streaming_subquery_build_batches_detached={} streaming_subquery_build_rows_detached={} streaming_subquery_validation_sources={} streaming_subquery_validation_batches={} streaming_subquery_validation_rows={}",
        input.subquery_outer_batches_detached, input.subquery_outer_rows_detached,
        input.subquery_build_batches_detached, input.subquery_build_rows_detached,
        input.subquery_validation_sources, input.subquery_validation_batches,
        input.subquery_validation_rows,
    ));
    let pivot_proof = format!(
        "spilled_pivot_stages={} spilled_pivot_input_rows={} spilled_pivot_index_rows={} spilled_pivot_domains={} spilled_pivot_cells={} spilled_pivot_lookup_blocks={} spilled_pivot_reader_opens={}",
        metrics.spilled_pivot_stages.get(),
        metrics.spilled_pivot_input_rows.get(),
        metrics.spilled_pivot_index_rows.get(),
        metrics.spilled_pivot_domains.get(),
        metrics.spilled_pivot_cells.get(),
        metrics.spilled_pivot_lookup_blocks.get(),
        metrics.spilled_pivot_reader_opens.get(),
    );
    NativeIoCertificate::new(
        "native_relational.execution.v1",
        "native_vortex_sources_to_relational_batches",
        NativeIoSourceCapabilityReport {
            source_kind: "vortex".into(),
            adapter_id: "shardloom.native_relational.vortex_0_85".into(),
            schema_discovery_status: if metrics.schema_discovery_stages.get() == 0 {
                format!("bound_before_execution_sources={sources}")
            } else {
                format!(
                    "source_schemas_prepared_before_execution_sources={sources};dynamic_schemas_bound_in_execution={}",
                    metrics.schema_discovery_stages.get()
                )
            },
            statistics_availability: if batch_sources > 0 {
                format!(
                    "completion_aware_native_batch_sources={batch_sources};batch_global_statistics_unavailable;held_native_file_metadata_sources={file_sources};immutable_native_array_sources={memory_sources}"
                )
            } else {
                format!(
                    "held_native_file_metadata_sources={file_sources};immutable_native_array_sources={memory_sources}"
                )
            },
            pushdown_capabilities: "bound_projection_and_native_predicates".into(),
            encoded_representation_preserved: true,
            range_read_capability: file_sources > 0,
            streaming_capability: true,
            object_store_capability: false,
            fallback_attempted: false,
        },
        NativeIoSourcePushdownReport {
            accepted_operations: vec!["native_bound_scan".into()],
            rejected_operations: vec![],
            guarantee: if input.is_some() {
                "declared_types_checked_each_batch;single_use_source_end_observed;all_input_buffer_owners_released_before_next_demand;declared_replay_native_owners_released_before_certification;output_ownership_detached;bound_file_generations_checked_before_and_after_final_consumer".into()
            } else {
                "bound_types_and_generation_checked_before_and_after_final_consumer".into()
            },
            proof_basis: format!(
                "scans_started={} scans_metadata_pruned={} native_batches={} delivered_scan_rows={} unary_stages={} unary_retained_state_items={} unary_stages_retaining_complete_population={} dynamic_schema_stages={} streaming_ordering_batches_detached={} streaming_ordering_rows_detached={} streaming_join_build_batches_detached={} streaming_join_build_rows_detached={} ordered_aggregate_stages={} ordered_aggregate_input_rows={} ordered_aggregate_distinct_rows={} ordered_join_stages={} ordered_join_build_rows={} ordered_join_probe_rows={} ordered_join_candidate_rows={} ordered_join_match_records={} ordered_join_lookup_blocks={} ordered_window_stages={} ordered_window_input_rows={} ordered_window_groups={} ordered_window_partitions={} ordered_window_peer_records={} ordered_window_bounds_rows={} ordered_window_distinct_intervals={} ordered_window_distinct_events={} ordered_window_extrema_summary_rows={} ordered_window_lookup_blocks={} streaming_window_batches_detached={} streaming_window_rows_detached={} {pivot_proof} {replay_proof} {subquery_proof}",
                metrics.scans_started.get(),
                metrics.scans_pruned.get(),
                metrics.scan_batches.get(),
                metrics.scan_rows.get(),
                metrics.unary_stages.get(),
                metrics.unary_state_items.get(),
                metrics.unary_population_retention.get(),
                metrics.schema_discovery_stages.get(),
                metrics.ordering_batches_detached.get(),
                metrics.ordering_rows_detached.get(),
                metrics.join_build_batches_detached.get(),
                metrics.join_build_rows_detached.get(),
                metrics.ordered_aggregate_stages.get(),
                metrics.ordered_aggregate_input_rows.get(),
                metrics.ordered_aggregate_distinct_rows.get(),
                metrics.ordered_join_stages.get(),
                metrics.ordered_join_build_rows.get(),
                metrics.ordered_join_probe_rows.get(),
                metrics.ordered_join_candidate_rows.get(),
                metrics.ordered_join_match_records.get(),
                metrics.ordered_join_lookup_blocks.get(),
                metrics.ordered_window_stages.get(),
                metrics.ordered_window_input_rows.get(),
                metrics.ordered_window_groups.get(),
                metrics.ordered_window_partitions.get(),
                metrics.ordered_window_peer_records.get(),
                metrics.ordered_window_bounds_rows.get(),
                metrics.ordered_window_distinct_intervals.get(),
                metrics.ordered_window_distinct_events.get(),
                metrics.ordered_window_extrema_summary_rows.get(),
                metrics.ordered_window_lookup_blocks.get(),
                metrics.window_batches_detached.get(),
                metrics.window_rows_detached.get()
            ),
            residual_expression: (metrics.residual_batches.get() > 0).then(|| {
                format!(
                    "bound ShardLoom native residual evaluation; batches={}",
                    metrics.residual_batches.get()
                )
            }),
            conservative_false_positive_policy: true,
            unsafe_rejected_reason: None,
            fallback_attempted: false,
        },
        if data_work {
            vec![NativeIoRepresentationTransition::new(
                RepresentationState::VortexEncoded,
                RepresentationState::DecodedColumnar,
                true,
            )]
        } else {
            vec![]
        },
        NativeIoSinkRequirementReport {
            target_format: "native_relational_result_batches".into(),
            accepts_encoded: false,
            requires_decoded_columnar: true,
            requires_rows: false,
            preserves_metadata: false,
            requires_ordering: true,
            requires_partitioning: false,
            requires_commit: false,
            supports_streaming: true,
            max_chunk_size: Some(batch_rows as u64),
            backpressure_policy: "synchronous_consumer_controls_next_batch".into(),
        },
        NativeIoAdapterFidelityReport {
            adapter_id: "shardloom.native_relational.vortex_0_85".into(),
            source_kind: "vortex".into(),
            sink_kind: "native_relational_result_batches".into(),
            metadata_preserved: false,
            statistics_preserved: false,
            encoded_representation_preserved: false,
            materialization_required: data_work,
            fidelity_loss: "none_for_bound_native_values_schema_and_nulls".into(),
            metadata_loss: "computed_columns_do_not_inherit_source_layouts_or_statistics".into(),
            fallback_attempted: false,
        },
        if data_work {
            vec![NativeIoMaterializationBoundaryReport {
                boundary_id: "native_relational.keys_and_selected_payload".into(),
                from_state: RepresentationState::VortexEncoded,
                to_state: RepresentationState::DecodedColumnar,
                required_by: "typed_keys_and_bounded_native_result_consumption".into(),
                reason: format!(
                    "native key execution and native take followed by explicit compact output copies; streaming ordering input is separately compacted before retention; declared repeated streaming sources retain compact full-schema native replay under the same grant and optional query spill policy; {replay_proof}; ordered aggregate stages={} compact typed base/distinct records, retained group keys and completed results through the same query owner; ordered join stages={} compact build/candidate/output records with exact key and ON evaluation; ordered window stages={} compact typed input, peer/frame records, exact DISTINCT interval events, extrema summaries and completed results through the same query owner; unary scalar access and retained row state use the shared operation kernels and native output builder; unary stages retaining the complete population={}; native ordering run materialization performed={spilled}; physical decoder bytes are unobserved, so the legacy numeric bytes field is not a zero-decode claim; final output buffer bytes are reported separately; reservations exclude upstream provider scratch and are not an RSS bound",
                    metrics.ordered_aggregate_stages.get(),
                    metrics.ordered_join_stages.get(),
                    metrics.ordered_window_stages.get(),
                    metrics.unary_population_retention.get()
                ),
                bytes_decoded: 0,
                rows_materialized: rows,
                fidelity_loss: "none_for_bound_scalar_values".into(),
                fallback_attempted: false,
            }]
        } else {
            vec![]
        },
        NativeIoSideEffectReport {
            data_read: data_work,
            data_decoded: data_work,
            data_materialized: data_work,
            row_read: data_work,
            arrow_converted: false,
            object_store_io: false,
            write_io: spilled,
            spill_io_performed: spilled,
            external_effects_executed: false,
            fallback_attempted: false,
            fallback_execution_allowed: false,
        },
        vec![],
    )
}
