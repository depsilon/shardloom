"""Lint and build the reviewed projected-text reuse candidate sequentially."""
import subprocess
from campaign_common import W, N, PYTHON

stages = [
    ('g3-text-reviewed-1024', ['cargo', 'test', '-p', 'shardloom-vortex', '--features', 'release-user-surfaces', '--lib', 'text_scan', '--', '--nocapture']),
    ('g3-native-final-clippy-1024', ['cargo', 'clippy', '--workspace', '--all-targets', '--features', 'shardloom-vortex/release-user-surfaces,shardloom-cli/release-user-surfaces', '--', '-D', 'warnings']),
    ('g3-cli-build-1024', ['cargo', 'build', '--release', '-p', 'shardloom-cli', '--bin', 'shardloom', '--features', 'release-user-surfaces']),
]
for label, command in stages:
    print('Starting ' + label, flush=True)
    subprocess.run([PYTHON, '-B', str(N / 'run_validation.py'), label, *command], cwd=W, check=True)
print('G3 lint and release build passed.', flush=True)
