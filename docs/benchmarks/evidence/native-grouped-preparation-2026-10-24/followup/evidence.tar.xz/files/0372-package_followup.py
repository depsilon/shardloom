"""Preserve the complete final comparison evidence, including rejected G3."""
import hashlib
import io
from pathlib import Path
import shutil
import subprocess
import tarfile

from campaign_common import W, N, identity, read, save, git

parent = W / 'docs/benchmarks/evidence/native-grouped-preparation-2026-10-24'
root = parent / 'followup'
assert not root.exists(), 'preserve earlier packaging outcomes'
assert read(N / 'final-full43-receipt.json')['status'] == 'passed'
assert read(N / 'g2-comparison/decision.json')['retained'] is True
assert read(N / 'g3-comparison/decision.json')['retained'] is False
assert read(N / 'g3-restoration.json')['source_equals_retained_g2'] is True
full_plan = read(N / 'final-full43-plan.json')
assert git('rev-parse', 'HEAD') == full_plan['source_commit'] and not git('status', '--porcelain')
plans = {key: read(N / (key + '-comparison/plan.json')) for key in ('g2', 'g3')}
entries = {}


def add(path, data=None, expected=None, origin=None):
    path = Path(path)
    if data is None:
        assert path.is_file() and not path.is_symlink(), path
        data = path.read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    if expected is not None:
        assert sha == expected['sha256'], path
        assert 'bytes' not in expected or len(data) == expected['bytes'], path
    key = (str(path), sha)
    if key in entries:
        assert entries[key]['data'] == data
    else:
        entries[key] = dict(data=data, origin=origin or 'recorded_local_file')


def add_ref(ref, commit=None):
    path = Path(ref['path'])
    current = path.read_bytes() if path.is_file() else None
    if current is not None and hashlib.sha256(current).hexdigest() == ref['sha256']:
        add(path, current, ref)
        return
    assert commit is not None and path.is_relative_to(W), ('historical identity absent', ref)
    relative = path.relative_to(W).as_posix()
    data = subprocess.check_output(['git', 'show', f'{commit}:{relative}'], cwd=W)
    add(path, data, ref, origin={'git_commit': commit, 'path': relative})


for path in sorted(N.iterdir()):
    if path.is_file() and path.suffix in {'.py', '.json', '.log', '.patch'}:
        add(path)
for folder in ('g2-comparison', 'g3-comparison', 'final-full43'):
    for path in sorted((N / folder).rglob('*')):
        if path.is_file():
            add(path)
for key, plan in plans.items():
    for ref in [*plan['harness'].values(), *plan['helpers'].values(), plan['protocol'],
                plan['queries'], plan['reference'], plan['oracle_acceptance'],
                plan['activation_test'], plan['activation_test_log']]:
        add_ref(ref, plan['source_commit'])
    for ref in plan['builds'].values():
        add_ref(ref)
        build = read(ref['path'])
        add_ref(dict(path=str(Path(ref['path']).with_suffix('.log')), sha256=build['log_sha256']))
    patch = subprocess.check_output(['git', 'diff', '--no-ext-diff', plan['baseline_commit'], plan['source_commit'],
                                     '--', 'shardloom-vortex/src'], cwd=W)
    add(N / (key + '-runtime-source.patch'), patch, origin={'base': plan['baseline_commit'], 'head': plan['source_commit']})
add_ref(full_plan['prior_summary'])
for ref in full_plan['schema_sources'].values():
    add_ref(dict(path=ref['path'], sha256=ref['gzip_sha256'], bytes=ref['gzip_bytes']))
for key in ('helper', 'common_helper', 'supervisor', 'workload_guard', 'native_clippy'):
    add_ref(full_plan[key])
shared_verifier = identity(parent / 'verify_packet.py')
add_ref(shared_verifier)
files, payloads = [], {}
for index, ((path, sha), value) in enumerate(sorted(entries.items())):
    data = value['data']
    member = f'files/{index:04d}-{Path(path).name}'
    files.append(dict(path=path, sha256=sha, bytes=len(data), member=member, origin=value['origin']))
    payloads[member] = data
assert sum(row['bytes'] for row in files) <= 64 * (1 << 20)
root.mkdir()
archive_path = root / 'evidence.tar.xz'
with archive_path.open('xb') as output:
    with tarfile.open(fileobj=output, mode='w:xz') as archive:
        for row in files:
            item = tarfile.TarInfo(row['member'])
            item.size, item.mtime, item.mode = row['bytes'], 0, 0o644
            archive.addfile(item, io.BytesIO(payloads[row['member']]))
with tarfile.open(archive_path, 'r:xz') as archive:
    assert archive.getnames() == [row['member'] for row in files]
    for row in files:
        assert archive.extractfile(row['member']).read() == payloads[row['member']]
shutil.copyfile(N / 'verify_followup.py', root / 'verify_packet.py')
manifest = dict(schema='shardloom.grouped_preparation.followup.packet.v1',
    source_commit=full_plan['source_commit'], source_tree=full_plan['source_tree'],
    archive=archive_path.name, archive_sha256=identity(archive_path)['sha256'],
    archive_bytes=archive_path.stat().st_size, complete_byte_readback=True,
    verifier_sha256=identity(root / 'verify_packet.py')['sha256'], shared_verifier=shared_verifier,
    files=files, comparisons=[dict(id=key, **{name: identity(N / (key + '-comparison') / (name + '.json'))
        for name in ('plan', 'outcome', 'decision')}) for key in ('g2', 'g3')],
    restoration=identity(N / 'g3-restoration.json'),
    full43_plan=identity(N / 'final-full43-plan.json'), full43_receipt=identity(N / 'final-full43-receipt.json'),
    validation=identity(N / 'final-required-validation.json'),
    omitted_regenerable_payloads={'input': plans['g2']['input'],
        'binaries': {key: plan['binary'] for key, plan in plans.items()},
        'reason': 'Complete results, failures, protocols and exact source/build/input identities retained. Current input and accepted G2 executable remain local; superseded binaries and compiler caches are disposable.'})
save(root / 'manifest.json', manifest)
save(N / 'followup-packaging.json', dict(status='passed', manifest=identity(root / 'manifest.json'),
    archive=identity(archive_path), verifier=identity(root / 'verify_packet.py'), files=len(files),
    raw_bytes=sum(row['bytes'] for row in files), complete_byte_readback=True))
print({'status': 'passed', 'files': len(files), 'archive_bytes': archive_path.stat().st_size})
