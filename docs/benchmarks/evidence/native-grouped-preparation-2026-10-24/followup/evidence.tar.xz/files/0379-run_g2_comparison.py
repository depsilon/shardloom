"""Frozen 52-call G2 cohort, using the standard counterbalanced query runner."""
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

from campaign_common import (W, N, OLD, PR, CACHE, BASE_COMMIT, PYTHON, SUPERVISOR,
                            GUARD, identity, read, save, generation, git, load,
                            source_identity, verify_git_sources, verify_build)

sys.path.insert(0, str(W / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

BASE_COMMIT = '9ca3cbda5f8527c4f948b0aafed6626f3b6fb2fd'
root = N / 'g2-comparison'
assert not root.exists(), 'preserve previous cohort evidence'
bounded = load('bounded', SUPERVISOR)
guards = load('guards', GUARD)
base_build_path = N / 'g1-cli-build-1024.json'
candidate_build_path = N / 'g2-cli-final-build-1024.json'
base_build = verify_build(base_build_path, require_compile=True)
candidate_build = verify_build(candidate_build_path, require_compile=True)
assert not git('status', '--porcelain'), 'freeze a clean candidate before queries'
commit = git('rev-parse', 'HEAD')
source_tree = git('rev-parse', 'HEAD^{tree}')
source = source_identity()
assert source == candidate_build['source_after']
baseline_revision = verify_git_sources(BASE_COMMIT, base_build['source_after'])
candidate_revision = verify_git_sources(commit, source)
prior_run = dict(read(N / 'g1-full43-plan.json'), **read(N / 'g1-full43-receipt.json'))
assert prior_run['status'] == 'passed' and prior_run['result_rows'] == 381
baseline = identity(N / 'shardloom-g1')
candidate = identity(N / 'shardloom-g2')
assert baseline == prior_run['binary']
assert identity(base_build_path) == prior_run['build']
assert candidate['sha256'] != baseline['sha256']
assert candidate == read(N / 'g2-binary-1024.json')['binary']
reference = identity(PR / 'independent-full43-948/reference.json')
assert reference == prior_run['reference']
oracle_path = PR / 'independent-full43-948/acceptance.json'
oracle = read(oracle_path)
assert oracle['status'] == 'passed' and oracle['independent_correctness_oracle'] is True
assert oracle['native_runtime_invoked'] is False and oracle['reference'] == reference
queries = identity(W / 'benchmarks/clickbench/queries.sql')
input_path = Path(prior_run['input']['path'])
input_generation = generation(input_path)
print('Verifying input identity before the targeted cohort.', flush=True)
input_identity = identity(input_path)
assert input_identity == prior_run['input'] and generation(input_path) == input_generation
protocol = identity(W / 'docs/architecture/native-grouped-preparation-2026-10-24.md')
helpers = {str(path): identity(path) for path in
           [Path(__file__), N / 'campaign_common.py', N / 'score_g2.py', SUPERVISOR, GUARD]}
harness_paths = [W / 'scripts' / name for name in [
    'run_clickbench_paired_query_uat.py', 'run_clickbench_query_uat.py',
    'clickbench_reference_packet.py', 'clickbench_native_sql.py',
    'native_workflow_protocol.py', 'timed_native_command.py',
    'query_timing_report.py', 'local_uat_storage.py']]
harness_paths += sorted((W / 'python/src/shardloom').rglob('*.py'))
harness = {str(path): identity(path) for path in harness_paths}

def storage_snapshot():
    snapshots = {}
    for label, path in [('task', N), ('cargo', CACHE), ('previous', OLD)]:
        require_local_path(path, Path.home(), sys.platform)
        snapshots[label] = check_budgets(path, path / 'reserved-artifact', path / 'logs',
            min_free_bytes=12 * GIB, reserve_bytes=128 * MIB,
            max_workspace_bytes=100 * GIB, max_log_bytes=1024 * MIB)
    return snapshots

cells = [('target', [28], 12, 5), ('single', [28], 1, 3),
         ('controls', [17, 19, 23, 29, 34, 35], 12, 3)]
commands = []
for label, selected, parallelism, repeats in cells:
    commands.append([PYTHON, '-B', str(W / 'scripts/run_clickbench_paired_query_uat.py'),
        '--control-binary', baseline['path'], '--candidate-binary', candidate['path'],
        '--control-commit', BASE_COMMIT, '--candidate-commit', commit,
        '--input', str(input_path), '--uat-root', str(root / label),
        '--reference-packet', reference['path'], '--queries', queries['path'],
        '--query-ids', ','.join(map(str, selected)), '--repeats', str(repeats),
        '--memory-gb', '24', '--max-parallelism', str(parallelism),
        '--timeout', '120', '--max-log-mib', '1024', '--max-run-log-mib', '256'])
plan = dict(schema='shardloom.grouped_preparation.g2.v1', status='predeclared',
    source_commit=commit, source_tree=source_tree, baseline_commit=BASE_COMMIT,
    baseline_runtime_source_commit=prior_run['source_commit'],
    baseline_revision=baseline_revision, candidate_revision=candidate_revision,
    binary={'control': baseline, 'candidate': candidate},
    builds={'control': identity(base_build_path), 'candidate': identity(candidate_build_path)},
    prior_full43=identity(N / 'g1-full43-receipt.json'),
    activation_test=identity(N / 'g2-compact-final-1024.json'),
    activation_test_log=identity(N / 'g2-compact-final-1024.log'),
    input=input_identity, input_generation=input_generation, reference=reference,
    oracle_acceptance=identity(oracle_path), queries=queries, protocol=protocol,
    harness=harness, helpers=helpers, cells=cells, commands=commands, expected_calls=52,
    memory_gb=24, host={'platform': platform.platform(), 'logical_cpus': os.cpu_count(),
        'physical_ram_bytes': int(subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.memsize'], text=True))},
    gates={'target_median_improves': True, 'target_paired_median_saving_positive': True,
           'target_positive_pairs_minimum': 4, 'control_relative_allowance': .05,
           'control_absolute_allowance_seconds': .005, 'target_cpu_relative_allowance': .05,
           'rss_relative_allowance': .25, 'rss_absolute_allowance_bytes': 256 * MIB,
           'complete_values_schema_no_fallback': True, 'wider_block_activation_tests': True},
    methodology='Five alternating Q28/12 pairs; three Q28/1 pairs; three pairs each Q17/Q19/Q23/Q29/Q34/Q35 at 12 lanes. Standard guarded public CLI runner and independent reference. No cache manipulation, pacing, concurrent task work or profiling. Full input hashes and recursive source/build/storage inventories occur outside the entire cohort. Wider block activation is proven by focused direct-consumer tests; relational reports omit that counter. This is not a timing-boundary or frontend-normalization change.',
    storage_before=storage_snapshot())
root.mkdir(exist_ok=False)
save(root / 'plan.json', plan)
record = dict(status='running', plan=identity(root / 'plan.json'), operations=[])
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1',
           PYTHONPATH=str(W / 'python/src') + ':' + str(W / 'scripts'))
try:
    print('Preparation complete; starting the frozen targeted cohort.', flush=True)
    for (label, selected, parallelism, repeats), command in zip(cells, commands):
        work = guards.WorkloadGuard()
        work.check()
        operation = dict(label=label, queries=selected, max_parallelism=parallelism,
                         repeats=repeats, command=command, host_samples=[])
        record['operations'].append(operation)
        last_sample = [0.0]
        def guard():
            work.check(operation.get('pid'))
            assert shutil.disk_usage(N).free >= 12 * GIB
            if time.monotonic() - last_sample[0] >= 2:
                rows = subprocess.check_output(['ps', '-axo', 'pid=,ppid=,pgid=,pcpu=,rss=,comm='], text=True, timeout=10)
                samples = []
                for line in rows.splitlines():
                    fields = line.strip().split(None, 5)
                    if len(fields) == 6 and (int(fields[0]) in work.owned or float(fields[3]) >= 1):
                        samples.append(dict(pid=int(fields[0]), parent=int(fields[1]), group=int(fields[2]),
                            cpu_percent=float(fields[3]), rss_bytes=int(fields[4]) * 1024,
                            executable=Path(fields[5]).name))
                operation['host_samples'].append(dict(load_average=list(os.getloadavg()), processes=samples))
                last_sample[0] = time.monotonic()
        log = root / (label + '.log')
        with log.open('xb') as output:
            result = bounded.run(command, cwd=W, env=env, output=output, timeout=900,
                                 evidence=operation, guard=guard, max_output_bytes=8 << 20)
        operation['log'] = identity(log)
        assert result == 0 and operation['process_group_drained'] and operation['direct_child_reaped']
        summaries = list((root / label).glob('logs/*/summary.json'))
        assert len(summaries) == 1
        summary = read(summaries[0])
        assert summary['scores']['complete'] and summary['scores']['timing_available']
        assert summary['complete_result_validation'] and summary['completed_identity_check']
        assert summary['reference_packet_identity_verified']
        assert len(summary['records']) == len(selected) * repeats * 2
        assert not (root / label / '.ingest-uat.lock').exists()
        operation['summary'] = identity(summaries[0])
        operation['status'] = 'passed'
    print('Targeted queries complete; verifying identities before scoring.', flush=True)
    assert generation(input_path) == input_generation
    assert identity(input_path) == input_identity and generation(input_path) == input_generation
    assert source_identity() == source and git('rev-parse', 'HEAD') == commit
    assert not git('status', '--porcelain')
    for value in [baseline, candidate, reference, queries, protocol, *helpers.values(), *harness.values()]:
        assert identity(value['path']) == value, value['path']
    guards.WorkloadGuard().check()
    record.update(status='passed', input_hashes_verified=True, source_unchanged=True,
                  frozen_identities_verified=True, storage_after=storage_snapshot(), calls=52)
except BaseException as error:
    record.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    save(root / 'outcome.json', record)
print('Frozen targeted cohort verified; no retention decision has been substituted for scoring.', flush=True)
