"""Run the retained candidate's remaining required checks sequentially."""
import re
import subprocess
import sys
from campaign_common import N, PYTHON, W, identity, read, save

stages = [
    ('g1-final-format-1024', ['cargo', 'fmt', '--all', '--', '--check']),
    ('g1-default-clippy-1024', ['cargo', 'clippy', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('g1-default-tests-1024', ['cargo', 'test', '--workspace', '--all-targets']),
    ('g1-native-tests-1024', ['cargo', 'test', '--workspace', '--all-targets', '--features',
                           'shardloom-vortex/release-user-surfaces,shardloom-cli/release-user-surfaces']),
]
results = []
try:
    for label, command in stages:
        print('Starting ' + label, flush=True)
        result = subprocess.run([PYTHON, '-B', str(N / 'run_validation.py'), label, *command], cwd=W)
        receipt = read(N / (label + '.json'))
        assert result.returncode == 0 and receipt['status'] == 'passed', label
        assert receipt['process_group_drained'] and receipt['source_before'] == receipt['source_after']
        counts = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',
                            (N / (label + '.log')).read_text())
        results.append(dict(label=label, receipt=identity(N / (label + '.json')),
            passed=sum(int(row[0]) for row in counts), failed=sum(int(row[1]) for row in counts),
            ignored=sum(int(row[2]) for row in counts)))
    save(N / 'g1-required-validation.json', dict(status='passed', stages=results))
except BaseException as error:
    save(N / 'g1-required-validation-failure.json', dict(status='failed', stages=results,
        error=type(error).__name__ + ': ' + str(error)))
    raise
print('Required sequential validation passed.', flush=True)
