"""Freeze the reviewed release build only after all selected checks pass."""
import shutil
from campaign_common import W, N, CACHE, identity, read, save, git, verify_build, source_identity, verify_git_sources

for label in ['g3-text-reviewed-1024', 'g3-native-final-clippy-1024']:
    receipt = read(N / (label + '.json'))
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['source_before'] == receipt['source_after']
    assert receipt['source_after'] == source_identity()
build_path = N / 'g3-cli-build-1024.json'
build = verify_build(build_path, require_compile=True)
assert not git('status', '--porcelain') and source_identity() == build['source_after']
revision = verify_git_sources(git('rev-parse', 'HEAD'), build['source_after'])
binary = N / 'shardloom-g3'
assert not binary.exists() and not (N / 'g3-binary-1024.json').exists()
shutil.copyfile(CACHE / 'release/shardloom', binary)
binary.chmod(0o755)
frozen = identity(binary)
assert frozen['sha256'] != identity(N / 'shardloom-g2')['sha256']
save(N / 'g3-binary-1024.json', dict(binary=frozen, build=identity(build_path),
    source_commit=git('rev-parse', 'HEAD'), revision=revision))
print({'status':'frozen', 'binary_sha256':frozen['sha256'], 'source_commit':revision['commit']})
