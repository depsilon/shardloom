"""Validate the reviewed owner correction and build the single G2 candidate."""
import subprocess
from campaign_common import W, N, PYTHON

stages = [
    ('g2-compact-final-1024', ['cargo', 'test', '-p', 'shardloom-vortex', '--features', 'release-user-surfaces', '--lib', 'compact_numeric_block', '--', '--nocapture']),
    ('g2-triple-final-1024', ['cargo', 'test', '-p', 'shardloom-vortex', '--features', 'release-user-surfaces', '--lib', 'triple_', '--', '--nocapture']),
    ('g2-native-final-clippy-1024', ['cargo', 'clippy', '--workspace', '--all-targets', '--features', 'shardloom-vortex/release-user-surfaces,shardloom-cli/release-user-surfaces', '--', '-D', 'warnings']),
    ('g2-cli-final-build-1024', ['cargo', 'build', '--release', '-p', 'shardloom-cli', '--bin', 'shardloom', '--features', 'release-user-surfaces']),
]
for label, command in stages:
    print('Starting ' + label, flush=True)
    subprocess.run([PYTHON, '-B', str(N / 'run_validation.py'), label, *command], cwd=W, check=True)
print('Reviewed G2 validation and build passed.', flush=True)
