"""Identity and source verification shared by this finite local campaign."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
N = Path('/Users/dylan/LocalData/shardloom/native-grouped-preparation-20261024')
OLD = Path('/Users/dylan/LocalData/shardloom/native-engine-optimization-20261023')
PR = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022')
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
BASE_COMMIT = 'e1af0d685e3d5d6c2dbb1e816b89f4320db2bfd9'
PYTHON = '/opt/homebrew/opt/python@3.13/bin/python3.13'
SUPERVISOR = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
GUARD = Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/native_workload_guard_816.py')

def identity(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())

def read(path):
    return json.loads(Path(path).read_text())

def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

def generation(path):
    s = Path(path).stat()
    return dict(device=s.st_dev, inode=s.st_ino, size_bytes=s.st_size,
                mtime_ns=s.st_mtime_ns, ctime_ns=s.st_ctime_ns)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=W, text=True).strip()

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def source_identity():
    return {str(p.relative_to(W)): identity(p)['sha256']
            for p in sorted(W.rglob('*')) if p.is_file() and 'target' not in p.parts
            and (p.suffix == '.rs' or p.name in ('Cargo.toml', 'Cargo.lock'))}

def verify_git_sources(commit, expected):
    """Check all runtime files from the build against the named Git revision."""
    files = git('ls-tree', '-r', '--name-only', commit).splitlines()
    paths = [p for p in files if p.endswith('.rs') or Path(p).name in ('Cargo.toml', 'Cargo.lock')]
    ignored = {'vendor/vortex-file/Cargo.lock', 'vendor/vortex-layout/Cargo.lock'}
    assert set(paths) | ignored == set(expected), 'runtime source inventory differs'
    request = ''.join(f'{commit}:{p}\n' for p in paths).encode()
    result = subprocess.run(['git', 'cat-file', '--batch'], input=request, cwd=W,
                            capture_output=True, check=True).stdout
    position = 0
    for path in paths:
        end = result.index(b'\n', position)
        header = result[position:end].split()
        assert len(header) == 3 and header[1] == b'blob', path
        size = int(header[2])
        position = end + 1
        data = result[position:position + size]
        assert hashlib.sha256(data).hexdigest() == expected[path], path
        position += size
        assert result[position:position + 1] == b'\n'
        position += 1
    assert position == len(result)
    for path in ignored:
        assert identity(W / path)['sha256'] == expected[path], path
    return dict(commit=commit, tracked_runtime_files=len(paths),
                ignored_vendor_lockfiles={p: expected[p] for p in sorted(ignored)},
                all_build_source_hashes_match=True)

def verify_build(path, require_compile=False):
    build = read(path)
    assert build['status'] == 'passed' and build['returncode'] == 0
    assert build['process_group_drained'] and build['direct_child_reaped']
    assert build['source_before'] == build['source_after']
    assert build['target'] == str(CACHE)
    assert build['command'] == ['cargo', 'build', '--release', '-p', 'shardloom-cli',
                                '--bin', 'shardloom', '--features', 'release-user-surfaces']
    log = Path(path).with_suffix('.log')
    assert identity(log)['sha256'] == build['log_sha256']
    if require_compile:
        for package in ['shardloom-vortex', 'shardloom-cli']:
            assert f'Compiling {package} ' in log.read_text(), package
    return build
