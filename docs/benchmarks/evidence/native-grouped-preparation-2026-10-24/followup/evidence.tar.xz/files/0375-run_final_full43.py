"""One isolated standard Full43 after the final finite decision and broad validation."""
import gzip
import hashlib
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

from campaign_common import (W, N, OLD, PR, CACHE, PYTHON, SUPERVISOR, GUARD,
    identity, read, save, generation, git, load, source_identity, verify_build, verify_git_sources)

sys.path[:0] = [str(W / 'scripts'), str(W / 'python/src')]
from clickbench_reference_packet import load_reference_packet
from native_workflow_protocol import extract_result, report_fields, strict_json
from run_clickbench_query_uat import equivalent
from query_timing_report import query_phase_timings

g3_decision = read(N / 'g3-comparison/decision.json')
assert g3_decision['status'] in ('retained', 'dropped')
selected = 'g3' if g3_decision['retained'] else 'g2'
plan = read(N / (selected + '-comparison/plan.json'))
decision = read(N / (selected + '-comparison/decision.json'))
assert decision['retained'] and all(decision['gates'].values())
validation_path = N / 'final-required-validation.json'
assert read(validation_path)['status'] == 'passed'
native_clippy_path = N / ('g3-native-final-clippy-1024.json' if selected == 'g3' else 'g2-native-final-clippy-1024.json')
native_clippy = read(native_clippy_path)
assert native_clippy['status'] == 'passed'
assert not git('status', '--porcelain')
commit, source_tree = git('rev-parse', 'HEAD'), git('rev-parse', 'HEAD^{tree}')
build_path = Path(plan['builds']['candidate']['path'])
assert identity(build_path) == plan['builds']['candidate']
build = verify_build(build_path, require_compile=True)
assert source_identity() == build['source_after'] == native_clippy['source_after']
revision = verify_git_sources(commit, build['source_after'])
for stage in read(validation_path)['stages']:
    receipt = read(stage['receipt']['path'])
    assert receipt['source_before'] == receipt['source_after'] == build['source_after']
binary = identity(N / ('shardloom-' + selected))
assert binary == plan['binary']['candidate']
input_path = Path(plan['input']['path'])
input_generation = generation(input_path)
assert input_generation == plan['input_generation']
print('Verifying the retained runtime and input before Full43.', flush=True)
assert identity(input_path) == plan['input'] and generation(input_path) == input_generation
reference = identity(plan['reference']['path'])
assert reference == plan['reference']
queries = identity(plan['queries']['path'])
assert queries == plan['queries']
def storage_snapshot():
    sizes = {str(root): sum(p.stat().st_size for p in root.rglob('*') if p.is_file() and not p.is_symlink())
             for root in [N, OLD, PR, CACHE]}
    assert sum(sizes.values()) <= 100 * (1 << 30), 'active artifact ceiling exceeded'
    free = shutil.disk_usage(N).free
    assert free >= 12 * (1 << 30)
    return dict(logical_bytes=sizes, free_bytes=free)
storage_before = storage_snapshot()
for value in plan['harness'].values():
    assert identity(value['path']) == value
expected = load_reference_packet(Path(reference['path']), Path(queries['path']))
prior = read(OLD / 'full43-pr1594-run-1022.json')
assert identity(prior['summary']['path']) == prior['summary']
prior_summary = read(prior['summary']['path'])
schemas, schema_sources = {}, {}
for row in prior_summary['records']:
    archived, = row['completed_log_archives']
    assert identity(archived['path'])['sha256'] == archived['gzip_sha256']
    raw = gzip.decompress(Path(archived['path']).read_bytes())
    assert hashlib.sha256(raw).hexdigest() == archived['raw_sha256']
    fields = report_fields(strict_json(raw.decode()))
    schemas[row['query']] = [fields['result_schema_format'], strict_json(fields['result_schema_json'])]
    schema_sources[row['query']] = archived
root = N / 'final-full43'
assert not root.exists()
command = [PYTHON, '-B', str(W / 'scripts/run_clickbench_query_uat.py'),
    '--binary', binary['path'], '--input', str(input_path), '--uat-root', str(root),
    '--reference-packet', reference['path'], '--build-commit', commit,
    '--memory-gb', '24', '--max-parallelism', '12', '--repeats', '1', '--compress-logs',
    '--max-log-mib', '1024', '--max-run-log-mib', '256']
bounded = load('bounded', SUPERVISOR)
guards = load('guards', GUARD)
work = guards.WorkloadGuard()
work.check()
receipt_path = N / 'final-full43-receipt.json'
log = N / 'final-full43.log'
assert not receipt_path.exists() and not log.exists()
run_plan = dict(schema='shardloom.grouped_preparation.full43.v1', status='predeclared',
    decision=identity(N / (selected + '-comparison/decision.json')), source_commit=commit,
    source_tree=source_tree, comparison_source_commit=plan['source_commit'],
    retained_candidate_id=selected, source_revision=revision,
    build=identity(build_path), binary=binary,
    input=plan['input'], input_generation=input_generation, reference=reference, queries=queries,
    harness=plan['harness'], supervisor=identity(SUPERVISOR), workload_guard=identity(GUARD),
    helper=identity(__file__), common_helper=identity(N / 'campaign_common.py'),
    validation=identity(validation_path),
    native_clippy=identity(native_clippy_path),
    storage_before=storage_before,
    prior_summary=prior['summary'], expected_schemas=schemas, schema_sources=schema_sources,
    command=command, query_ids=list(range(1, 44)), repeats=1, expected_calls=43,
    methodology='One isolated standard single pass after the retained grouped-preparation candidates and broad validation. Same binary as the paired cohort. Full input hashes and source/harness inventories before/after execution only; standard runner storage, deadlines, complete-value checks and cleanup plus lightweight workload guard. No task agents, builds, profiling, packaging, other task work, pacing or cache manipulation during queries. Prior schemas and independent values remain unchanged.')
save(N / 'final-full43-plan.json', run_plan)
record = dict(status='running', plan=identity(N / 'final-full43-plan.json'), host_samples=[])
last_sample = [0.0]
def guard():
    work.check(record.get('pid'))
    assert shutil.disk_usage(N).free >= 12 * (1 << 30)
    if time.monotonic() - last_sample[0] >= 2:
        rows = subprocess.check_output(['ps', '-axo', 'pid=,ppid=,pgid=,pcpu=,rss=,comm='], text=True, timeout=10)
        samples = []
        for line in rows.splitlines():
            fields = line.strip().split(None, 5)
            if len(fields) == 6 and (int(fields[0]) in work.owned or float(fields[3]) >= 1):
                samples.append(dict(pid=int(fields[0]), parent=int(fields[1]), group=int(fields[2]),
                    cpu_percent=float(fields[3]), rss_bytes=int(fields[4]) * 1024,
                    executable=Path(fields[5]).name))
        record['host_samples'].append(dict(load_average=list(os.getloadavg()), processes=samples))
        last_sample[0] = time.monotonic()
try:
    print('Preparation complete; starting one isolated standard Full43 pass.', flush=True)
    with log.open('xb') as output:
        result = bounded.run(command, cwd=W,
            env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1',
                     PYTHONPATH=str(W / 'python/src') + ':' + str(W / 'scripts')),
            output=output, timeout=900, evidence=record, guard=guard, max_output_bytes=8 << 20)
    assert result == 0 and record['process_group_drained'] and record['direct_child_reaped']
    print('Full43 execution complete; validating results, schemas and identities.', flush=True)
    summaries = list(root.glob('logs/*/summary.json'))
    assert len(summaries) == 1
    summary = read(summaries[0])
    assert summary['complete'] and summary['full_result_validation'] and summary['completed_identity_check']
    assert summary['harness_identity_verified'] and summary['reference_packet_identity_verified']
    assert summary['repeats'] == 1 and summary['score_scope'] == 'full_43'
    assert summary['reference_kind'] == 'independent_reference'
    assert summary['binary_sha256'] == binary['sha256'] and summary['build_commit'] == commit
    assert [(row['query'], row['run']) for row in summary['records']] == [(q, 1) for q in range(1, 44)]
    result_rows, witnesses = 0, []
    for row in summary['records']:
        assert row['passed'] and row['validation'] == 'complete_values'
        assert row['returncode'] == 0 and not row['guard_failures']
        archived, = row['completed_log_archives']
        assert identity(archived['path'])['sha256'] == archived['gzip_sha256']
        raw = gzip.decompress(Path(archived['path']).read_bytes())
        assert hashlib.sha256(raw).hexdigest() == archived['raw_sha256']
        envelope = strict_json(raw.decode())
        fields = report_fields(envelope)
        values = extract_result(envelope)
        assert equivalent(values, expected['values'][row['query']])
        assert [fields['result_schema_format'], strict_json(fields['result_schema_json'])] == schemas[row['query']]
        phases = query_phase_timings(fields, row['seconds'], allow_missing=False)
        assert row['engine_timing_reported'] and row['engine_execution_seconds'] == phases['engine_execution_seconds']
        assert math.isfinite(row['engine_execution_seconds']) and row['engine_execution_seconds'] >= 0
        result_rows += len(values)
        witnesses.append(dict(query=row['query'], rows=len(values), complete_values=True,
                              schema_matches_accepted=True, raw_sha256=archived['raw_sha256']))
    assert result_rows == 381
    total = sum(row['engine_execution_seconds'] for row in summary['records'])
    assert total == summary['timing_totals']['totals']['engine_execution_seconds']
    assert generation(input_path) == input_generation and identity(input_path) == plan['input']
    assert generation(input_path) == input_generation and source_identity() == build['source_after']
    for value in [binary, reference, queries, *plan['harness'].values()]:
        assert identity(value['path']) == value
    assert git('rev-parse', 'HEAD') == commit and not git('status', '--porcelain')
    assert not (root / '.ingest-uat.lock').exists()
    guards.WorkloadGuard().check()
    record.update(status='passed', summary=identity(summaries[0]),
        query_timings=identity(summaries[0].parent / 'query-timings.csv'),
        engine_execution_seconds=total, queries=43, executions_per_query=1,
        result_rows=result_rows, witnesses=witnesses, source_unchanged=True,
        input_hashes_verified=True, schemas_verified=True, uat_lock_released=True,
        storage_after=storage_snapshot())
except BaseException as error:
    record.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    record['log'] = identity(log) if log.exists() else None
    save(receipt_path, record)
print({'status':'passed', 'queries':43, 'executions_per_query':1,
       'result_rows':381, 'engine_execution_seconds':total}, flush=True)
