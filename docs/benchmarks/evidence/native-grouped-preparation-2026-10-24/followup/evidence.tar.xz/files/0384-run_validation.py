"""Bounded native validation with source, storage and process receipts."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
N = Path('/Users/dylan/LocalData/shardloom/native-grouped-preparation-20261024')
PREVIOUS = Path('/Users/dylan/LocalData/shardloom/native-engine-optimization-20261023')
PR = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022')
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
UAT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

bounded = load('bounded', '/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
guards = load('guards', '/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/native_workload_guard_816.py')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def identity():
    paths = sorted(p for p in W.rglob('*') if p.is_file() and
                   ('target' not in p.parts) and (p.suffix == '.rs' or p.name in ('Cargo.toml', 'Cargo.lock')))
    return {str(p.relative_to(W)): digest(p) for p in paths}

def byte_count(path):
    return sum(p.stat().st_size for p in path.rglob('*') if p.is_file() and not p.is_symlink()) if path.exists() else 0

label, *command = sys.argv[1:]
assert command and label.replace('-', '').replace('_', '').isalnum()
log = N / (label + '.log')
receipt = N / (label + '.json')
assert not log.exists() and not receipt.exists(), 'preserve previous observations'
env = dict(os.environ, CARGO_TARGET_DIR=str(CACHE), CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', TMPDIR=str(N / 'tmp'))
Path(env['TMPDIR']).mkdir(exist_ok=True)
metadata = json.loads(subprocess.check_output(['cargo', 'metadata', '--offline', '--no-deps', '--format-version', '1'], cwd=W, env=env))
assert Path(metadata['target_directory']) == CACHE
before = identity()
evidence = {'command': command, 'cwd': str(W), 'target': str(CACHE), 'source_before': before,
            'supervisor_sha256': digest(Path(__file__)), 'supervisor': str(Path(__file__)),
            'toolchain': subprocess.check_output(['rustc', '-Vv'], text=True).strip()}
work = guards.WorkloadGuard()
last_storage = 0

def guard():
    global last_storage
    work.check(evidence.get('pid'))
    assert shutil.disk_usage(N).free >= 12 * (1 << 30), 'minimum free storage reached'
    if time.monotonic() - last_storage >= 20:
        last_storage = time.monotonic()
        sizes = {'uat': byte_count(UAT), 'target_and_active_tasks': sum(byte_count(p) for p in (CACHE, N, PREVIOUS, PR))}
        evidence['last_storage_bytes'] = sizes
        assert max(sizes.values()) <= 100 * (1 << 30), 'workspace storage ceiling reached'

status = 1
try:
    guard()
    with log.open('xb') as output:
        status = bounded.run(command, cwd=W, env=env, output=output, timeout=3600,
                             evidence=evidence, guard=guard, max_output_bytes=8 << 20)
    evidence['source_after'] = identity()
    assert evidence['source_after'] == before, 'source changed during validation'
    evidence['status'] = 'passed' if status == 0 else 'failed'
except BaseException as error:
    evidence['status'] = 'failed'
    evidence['failure'] = type(error).__name__ + ': ' + str(error)
    raise
finally:
    evidence['log_sha256'] = digest(log) if log.exists() else None
    receipt.write_text(json.dumps(evidence, indent=2) + '\n')
    print(json.dumps({key: evidence.get(key) for key in ('status', 'returncode', 'process_group_drained', 'failure')}), flush=True)
sys.exit(status)
