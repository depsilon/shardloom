"""Replay every result/schema/identity and apply the predeclared G1 gates."""
import hashlib
import math
from pathlib import Path
import statistics
import sys
import tarfile

from campaign_common import W, N, identity, read, save

sys.path[:0] = [str(W / 'scripts'), str(W / 'python/src')]
from clickbench_reference_packet import load_reference_packet
from clickbench_native_sql import native_query_statements
from native_workflow_protocol import extract_result, report_fields, strict_json
from query_timing_report import query_phase_timings
from run_clickbench_query_uat import equivalent
from run_clickbench_paired_query_uat import role_order

def finite(value):
    assert isinstance(value, (float, int)) and not isinstance(value, bool)
    assert math.isfinite(value) and value >= 0
    return value

def score_cell(observations, target):
    times = {role: [finite(r['engine_execution_seconds']) for r in rows]
             for role, rows in observations.items()}
    cpu = {role: [finite(r['user_cpu_seconds']) + finite(r['system_cpu_seconds']) for r in rows]
           for role, rows in observations.items()}
    rss = {role: [finite(r['native_peak_rss_bytes']) for r in rows]
           for role, rows in observations.items()}
    medians = {role: statistics.median(values) for role, values in times.items()}
    cpu_medians = {role: statistics.median(values) for role, values in cpu.items()}
    rss_medians = {role: statistics.median(values) for role, values in rss.items()}
    savings = [b - c for b, c in zip(times['control'], times['candidate'], strict=True)]
    engine_ceiling = medians['control'] + max(.05 * medians['control'], .005)
    rss_ceiling = rss_medians['control'] + max(.25 * rss_medians['control'], 256 * (1 << 20))
    benefit = (medians['candidate'] < medians['control']
               and statistics.median(savings) > 0 and sum(s > 0 for s in savings) >= 4)
    return dict(engine_seconds=times, engine_medians=medians,
        paired_savings_seconds=savings, median_paired_saving_seconds=statistics.median(savings),
        positive_pairs=sum(s > 0 for s in savings),
        engine_ratio=medians['candidate'] / medians['control'],
        engine_gate=benefit if target else medians['candidate'] <= engine_ceiling,
        engine_ceiling_seconds=None if target else engine_ceiling,
        cpu_seconds=cpu, cpu_medians=cpu_medians,
        cpu_gate=(cpu_medians['candidate'] <= cpu_medians['control'] * 1.05) if target else None,
        rss_bytes=rss, rss_medians=rss_medians, rss_ceiling_bytes=rss_ceiling,
        rss_gate=rss_medians['candidate'] <= rss_ceiling)

def main():
    root = N / 'g1-comparison'
    plan = read(root / 'plan.json')
    outcome = read(root / 'outcome.json')
    assert outcome['status'] == 'passed' and outcome['calls'] == 52
    assert outcome['source_unchanged'] and outcome['input_hashes_verified'] and outcome['frozen_identities_verified']
    assert outcome['plan'] == identity(root / 'plan.json')
    assert plan['helpers'][str(Path(__file__))] == identity(__file__)
    assert plan['gates'] == {'target_median_improves': True, 'target_paired_median_saving_positive': True,
        'target_positive_pairs_minimum': 4, 'control_relative_allowance': .05,
        'control_absolute_allowance_seconds': .005, 'target_cpu_relative_allowance': .05,
        'rss_relative_allowance': .25, 'rss_absolute_allowance_bytes': 256 * (1 << 20),
        'complete_values_schema_no_fallback': True, 'positive_target_activation': True}
    expected = load_reference_packet(Path(plan['reference']['path']), Path(plan['queries']['path']))
    submitted, dialect = native_query_statements(expected['queries'], plan['queries']['sha256'])
    cases, witnesses, activation = [], [], []
    assert [operation['label'] for operation in outcome['operations']] == ['target', 'single', 'controls']
    calls = 0
    for operation, (label, selected, parallelism, repeats) in zip(outcome['operations'], plan['cells'], strict=True):
        assert operation['status'] == 'passed' and operation['returncode'] == 0
        assert operation['process_group_drained'] and operation['direct_child_reaped']
        assert identity(operation['summary']['path']) == operation['summary']
        summary = read(operation['summary']['path'])
        assert summary['selected_query_ids'] == selected and summary['repeats'] == repeats
        assert summary['max_parallelism'] == parallelism and summary['memory_gb'] == 24
        assert summary['complete_result_validation'] and summary['completed_identity_check']
        assert summary['reference_packet_identity_verified'] and summary['reference_kind'] == 'independent_reference'
        assert summary['reference_packet']['sha256'] == plan['reference']['sha256']
        assert summary['queries_sha256'] == plan['queries']['sha256']
        assert summary['query_dialect'] == dialect
        assert summary['source_generation'] == plan['input_generation']
        for role in ['control', 'candidate']:
            assert summary['binaries'][role]['sha256'] == plan['binary'][role]['sha256']
        schedule = [(query, run, role) for query in selected for run in range(1, repeats + 1)
                    for role in role_order(query, run)]
        assert [(r['query'], r['run'], r['role']) for r in summary['records']] == schedule
        members = {}
        for archived in summary['archives']:
            path = Path(archived['path'])
            assert identity(path)['sha256'] == archived['sha256']
            with tarfile.open(path, 'r:xz') as archive:
                assert archive.getnames() == [m['name'] for m in archived['members']]
                for member in archived['members']:
                    data = archive.extractfile(member['name']).read()
                    assert len(data) == member['bytes']
                    assert hashlib.sha256(data).hexdigest() == member['sha256']
                    assert member['name'] not in members
                    members[member['name']] = data
        for query in selected:
            observations = {role: [r for r in summary['records'] if r['query'] == query and r['role'] == role]
                            for role in ['control', 'candidate']}
            schemas = []
            for role, rows in observations.items():
                assert len(rows) == repeats
                for row in rows:
                    assert row['passed'] and row['validation'] == 'complete_values'
                    assert row['returncode'] == 0 and not row['guard_failures']
                    name = f'q{query:02d}_run{row["run"]}_{role}.stdout.json'
                    envelope = strict_json(members[name].decode())
                    fields = report_fields(envelope)
                    assert row['query_statement'] == expected['queries'][query - 1]
                    assert row['executed_query_statement'] == submitted[query - 1]
                    assert row['command'][row['command'].index('--sql') + 1] == submitted[query - 1]
                    assert row['command'][0] == plan['binary'][role]['path']
                    phases = query_phase_timings(fields, row['seconds'], allow_missing=False)
                    assert row['engine_timing_reported'] and phases['engine_execution_seconds'] == row['engine_execution_seconds']
                    timing = strict_json(members[f'q{query:02d}_run{row["run"]}_{role}.timing.json'].decode())
                    assert timing['returncode'] == 0 and timing['seconds'] == row['seconds']
                    assert timing['peak_rss_bytes'] == row['native_peak_rss_bytes']
                    for counter in ['user_cpu_seconds', 'system_cpu_seconds']:
                        assert timing[counter] == row[counter]
                    actual = extract_result(envelope)
                    assert equivalent(actual, expected['values'][query]), name
                    schema = (fields['result_schema_format'], strict_json(fields['result_schema_json']))
                    schemas.append(schema)
                    witnesses.append(dict(case=label, query=query, run=row['run'], role=role,
                        stdout_sha256=hashlib.sha256(members[name]).hexdigest(), rows=len(actual),
                        complete_values=True, complete_schema=True, no_fallback=True))
                    if query == 19:
                        lines = [line for line in envelope['human_text'].splitlines()
                                 if line.startswith('result summary:')]
                        assert len(lines) == 1
                        details = strict_json(lines[0].split(' values=', 1)[1])
                        if role == 'candidate':
                            assert details['aggregate_workers_triple_worker_routed_chunks'] > 0
                            assert details['aggregate_workers_triple_worker_routed_chunks'] == details['aggregate_workers_submitted_chunks']
                            assert details['aggregate_workers_triple_retained_input_peak_bytes'] > 0
                        activation.append(dict(case=label, run=row['run'], role=role,
                            diagnostics={k: v for k, v in details.items() if k.startswith('aggregate_workers_triple_')
                                and not isinstance(v, list)}))
                    calls += 1
            assert all(schema == schemas[0] for schema in schemas), (label, query, 'schema changed')
            cell = score_cell(observations, label == 'target')
            cases.append(dict(case=label, query=query, max_parallelism=parallelism, repeats=repeats, **cell))
    assert calls == 52 and len(cases) == 8
    target, = [case for case in cases if case['case'] == 'target']
    controls = [case for case in cases if case['case'] != 'target']
    gates = dict(target_engine=target['engine_gate'], controls=all(c['engine_gate'] for c in controls),
                 target_cpu=target['cpu_gate'], rss=all(c['rss_gate'] for c in cases),
                 complete_values_schemas_no_fallback=True, positive_target_activation=True)
    decision = dict(schema='shardloom.grouped_preparation.g1.decision.v1',
        status='retained' if all(gates.values()) else 'dropped', retained=all(gates.values()),
        plan=identity(root / 'plan.json'), outcome=identity(root / 'outcome.json'), scorer=identity(__file__),
        calls=calls, gates=gates, cells=cases, witnesses=witnesses, activation=activation,
        source_commit=plan['source_commit'], source_tree=plan['source_tree'],
        baseline_commit=plan['baseline_commit'], binaries=plan['binary'],
        claim='Finite paired complete-query decision; no Full43 or general superiority inference.')
    save(root / 'decision.json', decision)
    print({key: decision[key] for key in ['status', 'calls', 'gates']})
    for case in cases:
        print({key: case[key] for key in ['case', 'query', 'max_parallelism', 'engine_medians', 'engine_gate']})

if __name__ == '__main__':
    main()
