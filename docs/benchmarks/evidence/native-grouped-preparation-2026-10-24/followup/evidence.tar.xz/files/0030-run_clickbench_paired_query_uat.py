#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Counterbalanced old/new native queries using the existing guarded UAT clock.

Both roles run once per query by default; explicit repeats add paired trials.
Role order alternates at each pair and query.
This controls temporal drift better than comparing suites from separate days; it
does not flush the OS cache or claim cold-storage, production or official rank.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import io
import json
import math
import os
from pathlib import Path
import platform
import re
import signal
import statistics
import subprocess
import sys
import tarfile
import time

from local_uat_storage import GIB, MIB, add_log_budget_arguments, check_budgets, require_local_path
from native_workflow_protocol import public_workflow_command, report_fields
from query_timing_report import query_phase_timings, timing_totals, write_timing_csv
from clickbench_reference_packet import load_reference_packet, query_statements
from clickbench_native_sql import native_query_statements
from run_clickbench_query_uat import correctness_boundary, equivalent, extract_reference_result, extract_result, file_sha256, read_json_log, run_profiled_command, score


def role_order(query, run, reverse=False):
    return ("control", "candidate") if (query + run + int(reverse)) % 2 == 0 else ("candidate", "control")


def generation(path):
    s = path.stat()
    return {"device": s.st_dev, "inode": s.st_ino, "size_bytes": s.st_size,
            "mtime_ns": s.st_mtime_ns, "ctime_ns": s.st_ctime_ns}


def resolve_role_sources(control_input, candidate_input=None, *, home=None, platform=None):
    home = Path.home() if home is None else home
    platform = sys.platform if platform is None else platform
    candidate_input = control_input if candidate_input is None else candidate_input
    return {
        "control": require_local_path(Path(control_input), home, platform),
        "candidate": require_local_path(Path(candidate_input), home, platform),
    }


def source_generations(sources):
    return {role: generation(path) for role, path in sources.items()}


def source_receipt(sources, frozen_generations=None):
    frozen_generations = source_generations(sources) if frozen_generations is None else frozen_generations
    return {role: {"path": str(path), "generation": frozen_generations[role]}
            for role, path in sources.items()}


def verify_source_generations(sources, expected):
    current = source_generations(sources)
    changed = [role for role in sources if current[role] != expected[role]]
    if changed:
        raise ValueError("source generation changed for role(s): " + ", ".join(changed))


def positive_finite(value):
    try:
        number = float(value)
    except ValueError as error:
        raise argparse.ArgumentTypeError("expected a positive finite number") from error
    if not math.isfinite(number) or number <= 0:
        raise argparse.ArgumentTypeError("expected a positive finite number")
    return number


def host_snapshot():
    """Outside native timing; VM deltas are host-wide, not query attribution."""
    result = {"utc": dt.datetime.now(dt.timezone.utc).isoformat(), "load_average": os.getloadavg()}
    if sys.platform == "darwin":
        completed = subprocess.run(["vm_stat"], capture_output=True, text=True, timeout=10)
        if completed.returncode:
            result["vm_stat_error"] = completed.stderr
        else:
            wanted = {"Pages free", "Pages inactive", "Pages reactivated", "File-backed pages",
                      "Anonymous pages", "Pages occupied by compressor", "Compressions",
                      "Decompressions", "Pageins", "Pageouts", "Swapins", "Swapouts"}
            result["vm_stat"] = {m[0]: int(m[1]) for m in re.findall(r'^([^:\n]+):\s+(\d+)\.', completed.stdout, re.MULTILINE) if m[0] in wanted}
            page = re.search(r'page size of (\d+) bytes', completed.stdout)
            result["vm_page_size_bytes"] = int(page[1]) if page else None
    return result


def archive_completed_logs(paths, target, guard):
    """Archive only caller-owned closed files; verify every byte before removal."""
    if not paths or len({p.name for p in paths}) != len(paths):
        raise ValueError("archive requires nonempty unique filenames")
    if any(p.parent != target.parent or p == target for p in paths):
        raise ValueError("archive must own only sibling run files")
    raw = {p.name: p.read_bytes() for p in paths}
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode="w:xz") as archive:
        for name, data in raw.items():
            item = tarfile.TarInfo(name)
            item.size = len(data)
            archive.addfile(item, io.BytesIO(data))
    packed = buffer.getvalue()
    block = max(4096, os.statvfs(target.parent).f_frsize)
    guard(math.ceil(len(packed) / block) * block)
    with target.open("xb") as stream:
        stream.write(packed)
    with tarfile.open(target, "r:xz") as archive:
        if archive.getnames() != list(raw):
            raise ValueError("archive member set changed")
        for name, data in raw.items():
            if archive.extractfile(name).read() != data:
                raise ValueError("archive does not preserve completed evidence")
    guard(0)
    for path in paths:
        if path.read_bytes() != raw[path.name]:
            raise ValueError("completed log changed before archival")
    receipt = {"path": str(target), "sha256": file_sha256(target),
               "members": [{"name": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
                           for name, data in raw.items()]}
    for path in paths:
        path.unlink()
    guard(0)
    return receipt


def paired_scores(records, selected, *, repeats=1):
    if any(r.get("role") not in ("control", "candidate") for r in records):
        raise ValueError("unknown paired role")
    result = paired_clock_scores(records, selected, repeats=repeats, timing_key="engine_execution_seconds")
    result["secondary_process_wall"] = paired_clock_scores(records, selected, repeats=repeats, timing_key="seconds")
    return result


def paired_clock_scores(records, selected, *, repeats, timing_key):
    scores = {role: score([r for r in records if r["role"] == role], 43, selected,
                          repeats=repeats, timing_key=timing_key)
              for role in ("control", "candidate")}
    complete = all(s["complete"] for s in scores.values())
    available = all(s["timing_available"] for s in scores.values())
    result = {"complete": complete, "roles": scores,
              "timing_metric": scores["control"]["timing_metric"],
              "timing_available": available, "per_query": None,
              "score_scope": "full_43" if selected == list(range(1, 44)) else "targeted_only"}
    if available:
        result["per_query"] = []
        for query in selected:
            by_role = {role: sorted((r for r in records if r["role"] == role and r["query"] == query), key=lambda r: r["run"])
                       for role in scores}
            times = {role: [r[timing_key] for r in runs] for role, runs in by_role.items()}
            result["per_query"].append({"query": query, "seconds": times,
                "median_seconds": {role: statistics.median(t) for role, t in times.items()},
                "paired_candidate_minus_control_seconds": [c - b for c, b in zip(times["candidate"], times["control"])]})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for role in ("control", "candidate"):
        parser.add_argument(f"--{role}-binary", type=Path, required=True)
        parser.add_argument(f"--{role}-commit", required=True)
    for name in ("input", "uat-root"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    reference_group = parser.add_mutually_exclusive_group(required=True)
    reference_group.add_argument("--reference-dir", type=Path)
    reference_group.add_argument("--reference-packet", type=Path)
    parser.add_argument("--candidate-input", type=Path,
                        help="candidate Vortex input (defaults to --input)")
    parser.add_argument("--queries", type=Path, default=Path(__file__).resolve().parents[1] / "benchmarks/clickbench/queries.sql")
    parser.add_argument("--query-ids")
    parser.add_argument("--repeats", type=int, default=1,
                        help="paired executions per query (default: 1); repeated trials require an explicit value")
    parser.add_argument("--memory-gb", type=int, default=24)
    parser.add_argument("--max-parallelism", type=int, default=12)
    parser.add_argument("--timeout", type=float, default=120)
    parser.add_argument("--allow-missing-engine-timing", action="store_true",
                        help="historical binary comparison only; missing engine clocks remain unavailable")
    parser.add_argument("--max-workspace-gib", type=positive_finite, default=100)
    add_log_budget_arguments(parser)
    parser.add_argument("--reverse-order", action="store_true")
    args = parser.parse_args()
    if args.memory_gb <= 0 or args.max_parallelism <= 0 or not math.isfinite(args.timeout) or args.timeout <= 0:
        parser.error("memory, parallelism and timeout must be positive")
    try:
        selected = [int(q) for q in args.query_ids.split(",")] if args.query_ids else list(range(1, 44))
        score([], 43, selected, repeats=args.repeats)
    except ValueError as error:
        parser.error(str(error))
    root = require_local_path(args.uat_root, Path.home(), sys.platform)
    sources = resolve_role_sources(args.input, args.candidate_input)
    source = sources["control"]
    logs = root / "logs" / ("paired43_" + dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S%fZ"))

    def guard(reserve=0):
        return check_budgets(root, source, logs, min_free_bytes=12*GIB, reserve_bytes=reserve,
                             max_workspace_bytes=math.floor(args.max_workspace_gib * GIB),
                             max_log_bytes=math.floor(args.max_log_mib * MIB),
                             max_run_log_bytes=math.floor(args.max_run_log_mib * MIB),
                             reserve_log_bytes=reserve)

    storage_preflight = guard()
    root.mkdir(parents=True, exist_ok=True)
    lock = root / ".ingest-uat.lock"
    lock.mkdir()
    summary = {}

    def save():
        current_records = summary.get("records", [])
        summary["timing_totals"] = {
            role: timing_totals([record for record in current_records if record.get("role") == role])
            for role in ("control", "candidate")
        }
        summary["timing_csv"] = str(logs / "query-timings.csv")
        write_timing_csv(logs / "query-timings.csv", current_records)
        data = json.dumps(summary, separators=(",", ":"), allow_nan=False).encode() + b"\n"
        block = max(4096, os.statvfs(logs).f_frsize)
        guard(math.ceil(len(data) / block) * block)
        pending = logs / "summary.pending.json"
        with pending.open("xb") as stream:
            stream.write(data)
        pending.replace(logs / "summary.json")
        guard()

    try:
        logs.mkdir(parents=True)
        packet_receipt = None
        if args.reference_packet is not None:
            loaded_packet = load_reference_packet(args.reference_packet, args.queries)
            queries = loaded_packet["queries"]
            queries_sha256 = loaded_packet["packet"]["queries_sha256"]
            references = {q: loaded_packet["values"][q] for q in selected}
            packet_receipt = loaded_packet["packet"]
        else:
            query_bytes, queries = query_statements(args.queries)
            queries_sha256 = hashlib.sha256(query_bytes).hexdigest()
            reference_paths = {q: args.reference_dir / f"q{q:02d}_run1.stdout.json" for q in selected}
            references = {q: extract_reference_result(read_json_log(path)) for q, path in reference_paths.items()}
        submitted_queries, query_dialect = native_query_statements(queries, queries_sha256)
        binaries = {role: getattr(args, role + "_binary").resolve() for role in ("control", "candidate")}
        identities = {role: {"path": str(path), "sha256": file_sha256(path), "commit": getattr(args, role + "_commit")}
                      for role, path in binaries.items()}
        script = Path(__file__).resolve()
        harness_paths = [
            script,
            *(script.with_name(name) for name in (
                "run_clickbench_query_uat.py",
                "clickbench_reference_packet.py",
                "clickbench_native_sql.py",
                "native_workflow_protocol.py",
                "timed_native_command.py",
                "query_timing_report.py",
                "local_uat_storage.py",
            )),
            *sorted((script.parents[1] / "python" / "src" / "shardloom").rglob("*.py")),
        ]
        harness = {str(path.resolve()): file_sha256(path) for path in harness_paths}
        original_generations = source_generations(sources)
        frozen_sources = source_receipt(sources, original_generations)
        reference_kind = (
            packet_receipt["reference_kind"]
            if packet_receipt is not None else "retained_native_regression"
        )
        records = []
        summary = {"schema_version": "shardloom.clickbench.counterbalanced_pairs.v2", "binaries": identities,
                   "harness_sha256": harness,
                   "source": str(source), "source_generation": original_generations["control"],
                   "sources": frozen_sources, "queries_sha256": queries_sha256,
                   "query_dialect": query_dialect,
                   "reference_dir": str(args.reference_dir) if args.reference_dir is not None else None,
                   "reference_packet": packet_receipt,
                   "reference_kind": reference_kind,
                   "memory_gb": args.memory_gb, "max_parallelism": args.max_parallelism,
                   "repeats": args.repeats,
                   "max_workspace_gib": args.max_workspace_gib,
                   "storage_preflight": storage_preflight,
                   "log_budget_bytes": {"retained": math.floor(args.max_log_mib * MIB),
                                        "active_run": math.floor(args.max_run_log_mib * MIB)},
                   "platform": platform.platform(), "cpu_count": os.cpu_count(), "selected_query_ids": selected,
                   "queries": {str(q): queries[q-1] for q in selected},
                   "command_template": public_workflow_command(
                       "{binary}", "{sql}", input_path="{role_source}",
                       input_format="vortex", memory_gb=args.memory_gb,
                       max_parallelism=args.max_parallelism,
                   ),
                   "reference_values_sha256": {str(q): hashlib.sha256(json.dumps(v, sort_keys=True, allow_nan=False).encode()).hexdigest() for q, v in references.items()},
                   "timing_boundary": "native process creation through complete public CLI output and exit; host snapshots and archival excluded",
                   "engine_timing_required": not args.allow_missing_engine_timing,
                   "cache_policy": "fresh process per operation; OS cache shared and uncontrolled; no answer cache or forced purge",
                   "order_policy": "alternate role order at each pair and query", "reverse_order": args.reverse_order,
                   "host_counter_scope": "host-wide VM observations, not unique query traffic or exclusive attribution",
                   "correctness_boundary": correctness_boundary(reference_kind),
                   "records": records, "archives": [],
                   "scores": paired_scores(records, selected, repeats=args.repeats)}
        save()
        for query in selected:
            closed = []
            for run in range(1, args.repeats + 1):
                for position, role in enumerate(role_order(query, run, args.reverse_order), 1):
                    prefix = logs / f"q{query:02d}_run{run}_{role}"
                    verify_source_generations(sources, original_generations)
                    command = public_workflow_command(
                        binaries[role], submitted_queries[query-1], input_path=sources[role],
                        input_format="vortex", memory_gb=args.memory_gb,
                        max_parallelism=args.max_parallelism,
                    )
                    before = host_snapshot()
                    try:
                        record = run_profiled_command(command, prefix, args.timeout, guard)
                    finally:
                        verify_source_generations(sources, original_generations)
                    record.update(query=query, run=run, role=role, pair_position=position, command=command,
                                  query_statement=queries[query-1],
                                  executed_query_statement=submitted_queries[query-1],
                                  host_before=before, host_after=host_snapshot(), passed=False)
                    validation_started = time.perf_counter()
                    try:
                        if record["returncode"] or record["guard_failures"]:
                            raise ValueError("native command or watchdog failed")
                        envelope = read_json_log(prefix.with_suffix(".stdout.json"))
                        record.update(query_phase_timings(report_fields(envelope), record["seconds"],
                                                          allow_missing=args.allow_missing_engine_timing))
                        actual = extract_result(envelope)
                        if not equivalent(actual, references[query]):
                            raise ValueError("complete result differs from retained reference")
                        record.update(passed=True, validation="complete_values",
                                      result_sha256=hashlib.sha256(json.dumps(actual, sort_keys=True, allow_nan=False).encode()).hexdigest())
                    except (ValueError, OSError) as error:
                        record["failure"] = str(error)
                    record["validation_seconds"] = time.perf_counter() - validation_started
                    closed.extend(prefix.with_suffix(suffix) for suffix in (".stdout.json", ".stderr.txt", ".timing.json", ".pid"))
                    records.append(record)
                    summary["scores"] = paired_scores(records, selected, repeats=args.repeats)
                    save()
                    print(json.dumps({k: record.get(k) for k in (
                        "query", "run", "role", "pair_position", "engine_execution_seconds",
                        "process_wall_seconds", "seconds", "passed")}), flush=True)
                    if not record["passed"]:
                        return 1
            summary["archives"].append(archive_completed_logs(closed, logs / f"q{query:02d}_completed.tar.xz", guard))
            save()
        packet_unchanged = (
            packet_receipt is None
            or file_sha256(Path(packet_receipt["path"])) == packet_receipt["sha256"]
        )
        summary["reference_packet_identity_verified"] = packet_unchanged
        if (any(file_sha256(path) != identities[role]["sha256"] for role, path in binaries.items())
                or file_sha256(args.queries) != summary["queries_sha256"]
                or not packet_unchanged
                or any(file_sha256(Path(path)) != digest for path, digest in harness.items())):
            raise ValueError("binary, query file, reference packet or harness changed")
        verify_source_generations(sources, original_generations)
        summary["complete_result_validation"] = all(r.get("validation") == "complete_values" and r["passed"] for r in records)
        summary["completed_identity_check"] = True
        save()
        return 0
    except BaseException as error:
        if summary:
            summary["failure"] = str(error) or type(error).__name__
            summary["completed_identity_check"] = False
            summary["complete_result_validation"] = False
            # Preserve the last atomic summary if storage admission itself failed.
            try:
                save()
            except (OSError, ValueError):
                pass
        raise
    finally:
        lock.rmdir()
        print(f"UAT evidence: {logs}", flush=True)


if __name__ == "__main__":
    def interrupted(_signum, _frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, interrupted)
    raise SystemExit(main())
