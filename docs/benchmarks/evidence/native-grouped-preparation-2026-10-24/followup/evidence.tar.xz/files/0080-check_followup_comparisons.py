"""Check the independent comparison replay before final archive assembly."""
import importlib.util
from pathlib import Path
import subprocess
from campaign_common import W, N, identity, read, save

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result

core = module('shared', W / 'docs/benchmarks/evidence/native-grouped-preparation-2026-10-24/verify_packet.py')
verifier = module('followup', N / 'verify_followup.py')
plans = [read(N / (key + '-comparison/plan.json')) for key in ('g2', 'g3')]

class LocalPacket:
    def data(self, ref):
        path = Path(ref['path'])
        data = path.read_bytes()
        if core.digest(data) != ref['sha256']:
            for plan in plans:
                if ref == plan['protocol']:
                    data = subprocess.check_output(['git', 'show', plan['source_commit'] + ':' + path.relative_to(W).as_posix()], cwd=W)
                    break
        assert core.digest(data) == ref['sha256'] and ('bytes' not in ref or len(data) == ref['bytes'])
        return data
    def read(self, ref):
        return core.strict(self.data(ref))

results = []
for key in ('g2', 'g3'):
    item = dict(id=key, **{name: identity(N / (key + '-comparison') / (name + '.json')) for name in ('plan', 'outcome', 'decision')})
    results.append(verifier.comparison(LocalPacket(), core, item)['summary'])
save(N / 'followup-comparison-replay.json', dict(status='passed', comparisons=results,
    verifier=identity(N / 'verify_followup.py'), engine_executed=False))
print({'status': 'passed', 'comparisons': results, 'engine_executed': False})
