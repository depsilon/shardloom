"""Preserve complete compact evidence and source identities, excluding large payloads."""
import hashlib
import io
from pathlib import Path
import shutil
import subprocess
import tarfile

from campaign_common import W, N, OLD, PR, identity, read, save, git

assert read(N / 'g1-full43-receipt.json')['status'] == 'passed'
assert read(N / 'g1-comparison/decision.json')['retained']
root = W / 'docs/benchmarks/evidence/native-grouped-preparation-2026-10-24'
assert not root.exists()
plan = read(N / 'g1-comparison/plan.json')
full_plan = read(N / 'g1-full43-plan.json')
assert git('rev-parse', 'HEAD') == plan['source_commit'] and not git('status', '--porcelain')
patch = subprocess.check_output(['git', 'show', '--format=fuller', '--binary', plan['source_commit']], cwd=W)
with (N / 'candidate.patch').open('xb') as stream:
    stream.write(patch)
paths = {p for p in N.iterdir() if p.is_file() and p.suffix in {'.py', '.json', '.log', '.patch'}}
for folder in ['g1-comparison', 'g1-full43']:
    paths.update(p for p in (N / folder).rglob('*') if p.is_file())
paths.update(Path(value['path']) for value in plan['harness'].values())
paths.update(Path(value['path']) for value in plan['helpers'].values())
paths.update([Path(plan['protocol']['path']), Path(plan['queries']['path']),
              Path(plan['reference']['path']), Path(plan['oracle_acceptance']['path']),
              Path(full_plan['prior_summary']['path']), OLD / 'full43-pr1594-run-1022.json',
              OLD / 'join-cli-build-1020.json', OLD / 'join-cli-build-1020.log'])
paths.update(Path(value['path']) for value in full_plan['schema_sources'].values())
for relative in git('diff', '--name-only', plan['source_commit'] + '^', plan['source_commit']).splitlines():
    paths.add(W / relative)
paths = sorted(paths)
assert all(path.is_file() and not path.is_symlink() for path in paths)
assert all(path.name not in ['shardloom-g1', 'shardloom-join-full43-1020'] for path in paths)
files, payloads = [], {}
for index, path in enumerate(paths):
    data = path.read_bytes()
    member = f'files/{index:04d}-{path.name}'
    item = dict(path=str(path), member=member, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    files.append(item)
    payloads[member] = data
assert sum(item['bytes'] for item in files) <= 64 * (1 << 20)
root.mkdir(parents=True)
archive_path = root / 'evidence.tar.xz'
with archive_path.open('xb') as output:
    with tarfile.open(fileobj=output, mode='w:xz') as archive:
        for row in files:
            item = tarfile.TarInfo(row['member'])
            item.size, item.mtime, item.mode = row['bytes'], 0, 0o644
            archive.addfile(item, io.BytesIO(payloads[row['member']]))
with tarfile.open(archive_path, 'r:xz') as archive:
    assert archive.getnames() == [row['member'] for row in files]
    for row in files:
        assert archive.extractfile(row['member']).read() == payloads[row['member']]
for row in files:
    assert identity(row['path'])['sha256'] == row['sha256'], row['path']
shutil.copyfile(N / 'verify_packet.py', root / 'verify_packet.py')
manifest = dict(schema='shardloom.grouped_preparation.packet.v1',
    source_commit=plan['source_commit'], source_tree=plan['source_tree'],
    archive=archive_path.name, archive_sha256=identity(archive_path)['sha256'],
    archive_bytes=archive_path.stat().st_size, complete_byte_readback=True,
    verifier_sha256=identity(root / 'verify_packet.py')['sha256'], files=files,
    comparison_plan=identity(N / 'g1-comparison/plan.json'),
    comparison_outcome=identity(N / 'g1-comparison/outcome.json'),
    comparison_decision=identity(N / 'g1-comparison/decision.json'),
    full43_plan=identity(N / 'g1-full43-plan.json'), full43_receipt=identity(N / 'g1-full43-receipt.json'),
    validation=identity(N / 'g1-required-validation.json'),
    omitted_regenerable_payloads={'input':plan['input'], 'binaries':plan['binary'],
        'reason':'Compact results, failures, exact source/build identities and protocol retained. Original input and latest tested executable remain local; superseded binaries and compiler caches are disposable.'})
save(root / 'manifest.json', manifest)
save(N / 'packet-packaging.json', dict(status='passed', manifest=identity(root / 'manifest.json'),
    archive=identity(archive_path), verifier=identity(root / 'verify_packet.py'), files=len(files),
    raw_bytes=sum(row['bytes'] for row in files), complete_byte_readback=True))
print({'status':'passed','files':len(files),'archive_bytes':archive_path.stat().st_size})
