"""Bind checkpoint Python gates and rebuilt installed artifacts to final sources."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PYTHON = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
BUILD_PYTHON = '/Users/dylan/LocalData/shardloom/native-python-surface-20261010/release-v0.6.0/build-env/bin/python'
GUARD = OUT / 'run_guarded_checkpoint_783.py'
SOURCE = OUT / 'checkpoint-final-source-784.json'
BUILD = OUT / 'checkpoint-build-784.json'
ARTIFACTS = OUT / 'artifacts/checkpoint-784'
PROOF = OUT / 'checkpoint-installed-python-784'
WHEELHOUSE = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010/native-wheelhouse-267')
CARGO = ['/Users/dylan/.cargo/bin/rustup', 'run', '1.99.0', 'cargo']


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def save(path, value):
    with Path(path).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def source_hashes():
    accepted = json.loads((ROOT / 'docs/benchmarks/evidence/compact-index-acceptance-source-764.json').read_text())['source_hashes']
    paths = set(accepted)
    for name in git('ls-files', '-co', '--exclude-standard', '-z').split('\0'):
        if name and Path(name).suffix in ('.rs', '.toml', '.lock', '.py', '.pyi', '.sh', '.sql', '.json', '.yml', '.yaml'):
            if name.startswith(('shardloom-', 'python/', 'scripts/', 'benchmarks/', '.github/', '.cargo/')) or name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'):
                paths.add(name)
    return {name: sha(ROOT / name) for name in sorted(paths) if (ROOT / name).is_file()}


def verify():
    source = json.loads(SOURCE.read_text())
    assert source['source_hashes'] == source_hashes(), 'checkpoint sources changed'
    assert source['driver'] == identity(__file__)
    assert source['guard'] == identity(GUARD)
    return source


def verify_build():
    verify()
    build = json.loads(BUILD.read_text())
    assert build['source_manifest'] == identity(SOURCE)
    assert build['binary_sha256'] == sha(build['binary'])
    assert build['native_library'] == identity(build['native_library']['path'])
    return build


def run(name, command, timeout=1800):
    verify()
    subprocess.run([PYTHON, '-B', str(GUARD), '--name', name, '--timeout', str(timeout), '--', *command], cwd=ROOT, check=True)
    verify()
    receipt_path = OUT / (name + '.json')
    log = OUT / (name + '.log')
    receipt = json.loads(receipt_path.read_text())
    assert receipt['status'] == 'passed' and receipt['process_group_drained']
    assert receipt['log_sha256'] == sha(log)
    return dict(receipt=identity(receipt_path), log=identity(log))


def installed():
    build = verify_build()
    dependency_inputs = [ROOT / '.github/requirements/ci-native-python.txt',
                         ROOT / '.github/requirements/ci-native-python-build.txt',
                         ROOT / '.github/requirements/ci-python-build.txt']
    dependency_inputs += sorted(WHEELHOUSE.glob('*.whl'))
    assert len(dependency_inputs) > 3 and not PROOF.exists()
    dependencies = [identity(path) for path in dependency_inputs]
    command = [BUILD_PYTHON, '-B', 'scripts/prove_native_python_wheel.py', '--repo-root', str(ROOT),
               '--output-dir', str(PROOF), '--native-library', build['native_library']['path'],
               '--cli-binary', build['binary'], '--wheelhouse', str(WHEELHOUSE)]
    save(OUT / 'checkpoint-installed-python-plan-784.json', dict(status='predeclared',
         source_manifest=identity(SOURCE), build=identity(BUILD), dependencies=dependencies,
         command=command, expected='All native binding and installed public-context tests, zero failures/errors/skips, installed native/CLI hashes must match the rebuilt artifacts.',
         publication_attempted=False, performance_claim=False))
    proof_receipt = run('checkpoint-wheel-proof-784', command, 3600)
    report = json.loads((PROOF / 'report.json').read_text())
    assert report['status'] == 'passed' and report['uninstall_status'] == 'passed'
    assert report['integration']['tests'] > 0
    assert all(report['integration'][key] == 0 for key in ('failures', 'errors', 'skipped'))
    assert report['publication_attempted'] is False
    assert report['integrity']['native_library_sha256'] == build['native_library']['sha256']
    assert report['integrity']['cli_sha256'] == build['binary_sha256']
    for step in report['steps']:
        assert step['returncode'] == 0 and step['log_sha256'] == sha(PROOF / step['log'])
    wheels = list((PROOF / 'dist').glob('*.whl'))
    assert len(wheels) == 1 and sha(wheels[0]) == report['integrity']['wheel_sha256']
    python = str(PROOF / 'venv/bin/python')
    reinstall = run('checkpoint-wheel-reinstall-784', [python, '-I', '-m', 'pip', 'install', '--no-index', '--no-deps', str(wheels[0])])
    context_code = r'''
import hashlib, json, pathlib, sys, unittest
import shardloom
from shardloom import _native, ShardLoomClient
root = pathlib.Path(sys.prefix).resolve()
package = pathlib.Path(shardloom.__file__).resolve()
native = pathlib.Path(_native.__file__).resolve()
assert root in package.parents and root in native.parents
assert hashlib.sha256(native.read_bytes()).hexdigest() == sys.argv[3]
client = ShardLoomClient()
binary = pathlib.Path(client.binary_command()[0]).resolve()
assert root in binary.parents
assert hashlib.sha256(binary.read_bytes()).hexdigest() == sys.argv[4]
client.close()
suite = unittest.defaultTestLoader.discover(sys.argv[1], pattern='test_public_context.py')
expected = suite.countTestCases()
result = unittest.TextTestRunner(verbosity=2).run(suite)
passed = result.wasSuccessful() and result.testsRun == expected and expected > 0 and not result.skipped
report = dict(status='passed' if passed else 'failed', expected_tests=expected, tests=result.testsRun,
    failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
    package=str(package), native=str(native), binary=str(binary), isolated_install=True)
pathlib.Path(sys.argv[2]).write_text(json.dumps(report, indent=2) + '\n')
raise SystemExit(0 if passed else 1)
'''
    context = run('checkpoint-installed-context-784', ['/usr/bin/env', '-u', 'SHARDLOOM_NATIVE_TEST_LIBRARY',
        '-u', 'SHARDLOOM_BIN', '-u', 'SHARDLOOM_REPO_ROOT', 'SHARDLOOM_REQUIRE_NATIVE_PYTHON=1',
        'SHARDLOOM_TEST_INSTALLED_QUICKSTART=1', python, '-I', '-c', context_code,
        str(ROOT / 'python/tests'), str(PROOF / 'public-context.json'),
        build['native_library']['sha256'], build['binary_sha256']])
    context_result = json.loads((PROOF / 'public-context.json').read_text())
    assert context_result['status'] == 'passed' and all(context_result[key] == 0 for key in ('errors', 'failures', 'skipped'))
    uninstall = run('checkpoint-wheel-final-uninstall-784', [python, '-I', '-m', 'pip', 'uninstall', '--yes', 'shardloom'])
    absence = run('checkpoint-wheel-final-absence-784', [python, '-I', '-c',
        "import importlib.util,pathlib,sys; assert importlib.util.find_spec('shardloom') is None; assert all(not pathlib.Path(p).exists() for p in sys.argv[1:])",
        context_result['package'], context_result['native'], context_result['binary']])
    assert [identity(path) for path in dependency_inputs] == dependencies
    assert verify_build() == build
    save(OUT / 'checkpoint-installed-python-784.json', dict(status='passed',
        source_manifest=identity(SOURCE), build=identity(BUILD), driver=identity(__file__),
        proof=identity(PROOF / 'report.json'), context=identity(PROOF / 'public-context.json'), wheel=identity(wheels[0]),
        native_binding_tests=report['integration']['tests'], installed_context_tests=context_result['tests'],
        failures=0, errors=0, skipped=0, sources_unchanged=True, artifacts_unchanged=True,
        receipts=dict(proof=proof_receipt, reinstall=reinstall, context=context, uninstall=uninstall, absence=absence),
        final_uninstall_verified=True, publication_attempted=False, performance_claim=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=['source', 'checks', 'build', 'installed', 'verify'])
    args = parser.parse_args()
    if args.phase == 'source':
        initial = json.loads((OUT / 'checkpoint-source-freeze-783.json').read_text())
        complete = json.loads((OUT / 'checkpoint-sequence-completion-783.json').read_text())
        assert complete['status'] == 'passed' and len(complete['steps']) == 11
        current = source_hashes()
        changed = [name for name, digest in initial['source_hashes'].items() if current[name] != digest]
        assert sorted(changed) == ['python/tests/test_release_scripts.py', 'scripts/check_pre_5j_dependency_freshness.py'], changed
        save(SOURCE, dict(schema_version='shardloom.conditional_checkpoint_source.v1',
            head=git('rev-parse', 'HEAD'), working_tree=git('status', '--porcelain'), source_hashes=current,
            initial_native_gate_source=identity(OUT / 'checkpoint-source-freeze-783.json'),
            initial_native_gates=identity(OUT / 'checkpoint-sequence-completion-783.json'),
            changed_since_native_gates=changed, unchanged_runtime_and_dependency_graph=True,
            driver=identity(__file__), guard=identity(GUARD)))
    elif args.phase == 'checks':
        receipt = run('checkpoint-release-scripts-784', [PYTHON, '-B', 'scripts/run_python_test_shard.py',
            '--shard', 'release_scripts', '--output-dir', str(OUT / 'checkpoint-python-shards-784')])
        result_path = OUT / 'checkpoint-python-shards-784/release_scripts.json'
        result = json.loads(result_path.read_text())
        assert result['status'] == 'passed' and result['test_count'] > 0
        assert all(result[key] == 0 for key in ('failure_count', 'error_count', 'skipped_count'))
        governance_path = OUT / 'checkpoint-contribution-governance-report-784.json'
        governance = run('checkpoint-contribution-governance-784', [PYTHON, '-B',
            'scripts/check_contribution_governance.py', '--output', str(governance_path)])
        assert json.loads(governance_path.read_text())['status'] == 'passed'
        save(OUT / 'checkpoint-python-checks-784.json', dict(status='passed', source_manifest=identity(SOURCE),
            receipt=receipt, result=identity(result_path), governance=governance,
            governance_report=identity(governance_path)))
    elif args.phase == 'build':
        verify()
        ARTIFACTS.mkdir(parents=True, exist_ok=False)
        name = 'checkpoint-release-cli-build-784'
        cli = run(name, CARGO + ['build', '--release', '--offline', '--locked', '-p', 'shardloom-cli',
            '--features', 'release-user-surfaces', '--message-format=json-render-diagnostics'], 3600)
        messages = [json.loads(line) for line in (OUT / (name + '.log')).read_text().splitlines() if line.startswith('{')]
        artifacts = [row for row in messages if row.get('reason') == 'compiler-artifact'
            and row.get('target', {}).get('name') == 'shardloom' and row.get('executable')]
        assert len(artifacts) == 1
        executable = Path(artifacts[0]['executable'])
        metadata = json.loads(subprocess.check_output(CARGO + ['metadata', '--offline', '--locked', '--no-deps', '--format-version', '1'],
            cwd=ROOT, env=dict(os.environ, CARGO_TARGET_DIR='/Users/dylan/.cache/shardloom/cargo-target')))
        assert executable.is_relative_to(Path(metadata['target_directory']))
        binary = ARTIFACTS / 'shardloom'
        shutil.copy2(executable, binary)
        assert sha(binary) == sha(executable)
        name = 'checkpoint-release-binding-build-784'
        binding_receipt = run(name, [BUILD_PYTHON, '-B', 'scripts/build_native_python.py', '--release', '--offline', '--output-dir', str(ARTIFACTS)], 3600)
        content = (OUT / (name + '.log')).read_text()
        start = content.index('{\n  "schema_version": "shardloom.native_python_build.v1"')
        binding = json.loads(content[start:])
        assert binding['status'] == 'passed' and not binding['installed'] and not binding['published']
        assert binding['library_sha256'] == sha(binding['library'])
        verify()
        save(BUILD, dict(source_manifest=identity(SOURCE), binary=str(binary), binary_sha256=sha(binary),
            native_library=identity(binding['library']), native_build=binding, cli_compiler_artifact=artifacts[0],
            build_receipts=dict(cli=cli, binding=binding_receipt), publication_attempted=False))
    elif args.phase == 'installed':
        installed()
    else:
        verify()
    print(json.dumps(dict(status='passed', phase=args.phase)), flush=True)


if __name__ == '__main__':
    main()
