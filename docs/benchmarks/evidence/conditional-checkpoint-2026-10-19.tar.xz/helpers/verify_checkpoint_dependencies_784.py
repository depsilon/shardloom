"""Verify the exact two-package intake and original bundled license bytes."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import tomllib

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
BASE = 'ac08d39198cfe3922e0f5f560376edbb0e8517f8'
EXPECTED = {'serde_json': ('1.0.151', '1.0.154'), 'sha2': ('0.11.0', '0.11.1')}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def original(path):
    return subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=ROOT)


def main():
    old_lock = tomllib.loads(original('Cargo.lock').decode())
    lock = tomllib.loads((ROOT / 'Cargo.lock').read_text())
    assert old_lock.keys() == lock.keys() and len(old_lock['package']) == len(lock['package'])
    changed = []
    for old, new in zip(old_lock['package'], lock['package'], strict=True):
        if old == new:
            continue
        name = new['name']
        assert (old['version'], new['version']) == EXPECTED[name]
        assert {k: v for k, v in old.items() if k not in ('version', 'checksum')} == {k: v for k, v in new.items() if k not in ('version', 'checksum')}
        changed.append(name)
    assert sorted(changed) == sorted(EXPECTED)
    manifest_path = ROOT / 'python/THIRD_PARTY_LICENSES/manifest.json'
    manifest = json.loads(manifest_path.read_text())
    old_manifest = json.loads(original('python/THIRD_PARTY_LICENSES/manifest.json'))
    assert manifest.keys() == old_manifest.keys()
    assert all(manifest[key] == old_manifest[key] for key in manifest if key != 'components')
    assert len(manifest['components']) == len(old_manifest['components'])
    changed_notices = []
    for old, new in zip(old_manifest['components'], manifest['components'], strict=True):
        if old == new:
            continue
        name = new['name']
        assert (old['version'], new['version']) == EXPECTED[name]
        assert {k: v for k, v in old.items() if k not in ('version', 'crate_checksum_sha256')} == {k: v for k, v in new.items() if k not in ('version', 'crate_checksum_sha256')}
        changed_notices.append(name)
    assert sorted(changed_notices) == sorted(EXPECTED)
    compiler_floor = tomllib.loads((ROOT / 'Cargo.toml').read_text())['workspace']['package']['rust-version']
    components = []
    for name, (_, version) in EXPECTED.items():
        archives = list((Path.home() / '.cargo/registry/cache').glob('*/' + name + '-' + version + '.crate'))
        assert len(archives) == 1
        path = archives[0]
        raw = path.read_bytes()
        entry = next(row for row in lock['package'] if row['name'] == name and row['version'] == version)
        notice = next(row for row in manifest['components'] if row['name'] == name and row['version'] == version)
        assert digest(raw) == entry['checksum'] == notice['crate_checksum_sha256']
        with tarfile.open(path, 'r:gz') as archive:
            prefix = name + '-' + version + '/'
            cargo = archive.extractfile(prefix + 'Cargo.toml').read()
            package = tomllib.loads(cargo.decode())['package']
            assert package['license'] == notice['license'] == 'MIT OR Apache-2.0'
            assert tuple(map(int, package['rust-version'].split('.'))) <= tuple(map(int, compiler_floor.split('.')))
            files = []
            for item in notice['files']:
                license_bytes = archive.extractfile(prefix + item['crate_path']).read()
                bundled_path = manifest_path.parent / item['text']
                assert license_bytes == bundled_path.read_bytes()
                assert digest(license_bytes) == item['sha256'] and len(license_bytes) == item['bytes']
                files.append(dict(item, original_bytes_preserved=True))
        components.append(dict(name=name, version=version, license=package['license'],
            rust_version=package['rust-version'], crate=dict(path=str(path), bytes=len(raw), sha256=digest(raw)),
            upstream_cargo_manifest_sha256=digest(cargo), license_files=files))
    result = dict(status='passed', base=BASE, changed_packages=changed, changed_notice_components=changed_notices,
        dependency_edges_unchanged=True, other_lock_entries_unchanged=True, compiler_floor=compiler_floor,
        components=components, four_license_texts_byte_identical=True,
        lock_sha256=digest((ROOT/'Cargo.lock').read_bytes()), notice_manifest_sha256=digest(manifest_path.read_bytes()),
        verifier_sha256=digest(Path(__file__).read_bytes()))
    with (OUT / 'checkpoint-dependency-provenance-784.json').open('x') as stream:
        stream.write(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(status='passed', changed_packages=changed, license_texts=4)))


if __name__ == '__main__':
    main()
