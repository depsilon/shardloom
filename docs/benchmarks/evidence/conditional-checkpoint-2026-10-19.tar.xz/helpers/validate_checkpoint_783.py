"""Run the checkpoint's lockfile-bound acceptance gates sequentially."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PYTHON = Path('/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3')
GUARD = OUT / 'run_guarded_checkpoint_783.py'
CARGO = ['/Users/dylan/.cargo/bin/rustup', 'run', '1.99.0', 'cargo']

manifest = ROOT / 'docs/benchmarks/evidence/compact-index-acceptance-source-764.json'
accepted = json.loads(manifest.read_text())['source_hashes']
current = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in accepted}
changed = [name for name in accepted if accepted[name] != current[name]]
assert sorted(changed) == ['Cargo.lock', 'python/THIRD_PARTY_LICENSES/manifest.json'], changed
freeze = {
    'schema_version': 'shardloom.conditional_checkpoint_source.v1',
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'working_tree': subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True),
    'accepted_manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest(),
    'accepted_source_count': len(accepted), 'changed_accepted_sources': changed,
    'source_hashes': current,
    'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'guard_sha256': hashlib.sha256(GUARD.read_bytes()).hexdigest(),
}
freeze_path = OUT / 'checkpoint-source-freeze-783.json'
assert not freeze_path.exists()
freeze_path.write_text(json.dumps(freeze, indent=2) + '\n')

steps = [
    ('license', [str(PYTHON), 'scripts/check_python_license_bundle.py'], 300),
    ('license-tests', [str(PYTHON), '-m', 'unittest', 'scripts.test_python_license_bundle'], 300),
    ('format', CARGO + ['fmt', '--all', '--', '--check'], 300),
    ('workspace-lint', CARGO + ['clippy', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings'], 1800),
    ('workspace-tests', CARGO + ['test', '--locked', '--workspace', '--all-targets', '--', '--test-threads=2'], 1800),
    ('native-lint', CARGO + ['clippy', '--locked', '-p', 'shardloom-cli', '-p', 'shardloom-vortex', '--all-targets', '--features', 'release-user-surfaces', '--', '-D', 'warnings'], 1800),
    ('native-tests', CARGO + ['test', '--locked', '-p', 'shardloom-vortex', '--lib', '--features', 'release-user-surfaces', '--', '--test-threads=2'], 1800),
    ('native-cli-tests', CARGO + ['test', '--locked', '-p', 'shardloom-cli', '--lib', '--bin', 'shardloom', '--test', 'vortex_prepare', '--test', 'public_memory_inputs', '--test', 'public_workflow_route', '--test', 'resident_worker', '--features', 'release-user-surfaces', '--', '--test-threads=2'], 1800),
    ('user-surface-reference', [str(PYTHON), 'scripts/check_user_surface_reference.py'], 300),
    ('golden-workflows', [str(PYTHON), 'scripts/check_golden_workflows.py'], 300),
    ('public-status', [str(PYTHON), 'scripts/check_public_status_docs.py'], 300),
]
completion = {'status': 'running', 'source_freeze': str(freeze_path), 'steps': []}
try:
    for name, command, timeout in steps:
        assert all(hashlib.sha256((ROOT / key).read_bytes()).hexdigest() == value for key, value in current.items()), 'source changed during validation'
        print('START ' + name, flush=True)
        result = subprocess.run([str(PYTHON), str(GUARD), '--name', 'checkpoint-' + name + '-783', '--timeout', str(timeout), '--', *command], cwd=ROOT, check=False)
        entry = {'name': name, 'command': command, 'returncode': result.returncode,
                 'receipt': str(OUT / ('checkpoint-' + name + '-783.json'))}
        completion['steps'].append(entry)
        if result.returncode:
            raise RuntimeError('checkpoint gate failed: ' + name)
    assert all(hashlib.sha256((ROOT / key).read_bytes()).hexdigest() == value for key, value in current.items()), 'source changed after validation'
    completion['status'] = 'passed'
except BaseException as error:
    completion.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    (OUT / 'checkpoint-sequence-completion-783.json').write_text(json.dumps(completion, indent=2) + '\n')
    print(json.dumps({'status': completion['status'], 'completed_steps': len(completion['steps'])}), flush=True)
