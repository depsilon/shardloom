"""Independently reopen the checkpoint packet and reconstruct its five-file patch."""
import hashlib
import json
import lzma
from pathlib import Path
import re
import subprocess
import tarfile
import tempfile

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PACK = ROOT / 'docs/benchmarks/evidence'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    index_path = PACK / 'conditional-checkpoint-2026-10-19.json'
    index = json.loads(index_path.read_text())
    assert index['status'] == 'passed' and index['retained_runtime_matches_original_acceptance']
    assert not index['performance_claim'] and not index['package_publication_attempted']
    for key in ('archive', 'manifest'):
        record = index[key]
        raw = (PACK / record['file']).read_bytes()
        assert len(raw) == record['bytes'] and sha(raw) == record['sha256']
    manifest = json.loads(lzma.decompress((PACK / index['manifest']['file']).read_bytes()))
    rows = manifest['members']
    names = [row['path'] for row in rows]
    assert len(names) == len(set(names)) == index['member_count']
    contents = {}
    with tarfile.open(PACK / index['archive']['file'], 'r:xz') as archive:
        assert archive.getnames() == names
        for row in rows:
            member = archive.getmember(row['path'])
            assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            raw = archive.extractfile(member).read()
            assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
            if not row['original'].startswith('generated:'):
                assert raw == Path(row['original']).read_bytes()
            contents[member.name] = raw
    final = json.loads(contents['evidence/checkpoint-final-source-784.json'])
    initial = json.loads(contents['evidence/checkpoint-source-freeze-783.json'])
    accepted = json.loads(contents['source/accepted-source-map.json'])['source_hashes']
    assert all(sha((ROOT / name).read_bytes()) == value for name, value in final['source_hashes'].items())
    changed = sorted(name for name, value in accepted.items() if final['source_hashes'][name] != value)
    assert changed == index['changes_since_original_acceptance'] == [
        'Cargo.lock', 'python/THIRD_PARTY_LICENSES/manifest.json',
        'python/tests/test_release_scripts.py', 'scripts/check_pre_5j_dependency_freshness.py']
    changed_after = sorted(name for name, value in initial['source_hashes'].items() if final['source_hashes'][name] != value)
    assert changed_after == sorted(index['source_changes_after_fresh_native_gates']) == [
        'python/tests/test_release_scripts.py', 'scripts/check_pre_5j_dependency_freshness.py']
    runtime = {name.removeprefix('source/accepted-runtime/'): raw
               for name, raw in contents.items() if name.startswith('source/accepted-runtime/')}
    assert len(runtime) == 8 and all(sha(raw) == accepted[name] for name, raw in runtime.items())
    current = {name.removeprefix('source/current/'): raw
               for name, raw in contents.items() if name.startswith('source/current/')}
    assert len(current) == 5
    base = index['base_commit']
    with tempfile.TemporaryDirectory(prefix='checkpoint-reconstruction-', dir=OUT) as directory:
        stage = Path(directory)
        for name in current:
            path = stage / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(subprocess.check_output(['git', 'show', base + ':' + name], cwd=ROOT))
        patch = contents['source/patch-from-' + base + '.diff']
        subprocess.run(['git', 'apply', '--check', '-'], input=patch, cwd=stage, check=True)
        subprocess.run(['git', 'apply', '-'], input=patch, cwd=stage, check=True)
        assert all((stage / name).read_bytes() == raw for name, raw in current.items())
    completion = json.loads(contents['evidence/checkpoint-sequence-completion-783.json'])
    assert completion['status'] == 'passed' and len(completion['steps']) == 11
    guards = 0
    for name, raw in contents.items():
        if name.startswith('evidence/') and name.endswith('.json'):
            row = json.loads(raw)
            if 'process_group_drained' in row and 'log_sha256' in row:
                assert row['status'] == 'passed' and row['process_group_drained']
                log = name.removesuffix('.json') + '.log'
                assert row['log_sha256'] == sha(contents[log])
                guards += 1
    for name, expected in index['test_counts'].items():
        log = contents['evidence/checkpoint-' + name + '-783.log'].decode()
        observed = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored', log)
        actual = dict(targets=len(observed), passed=sum(int(row[0]) for row in observed),
                      failed=sum(int(row[1]) for row in observed), ignored=sum(int(row[2]) for row in observed))
        assert actual == expected
    report = json.loads(contents['installed/report.json'])
    assert report['status'] == 'passed' and report['uninstall_status'] == 'passed'
    for step in report['steps']:
        assert step['returncode'] == 0 and step['log_sha256'] == sha(contents['installed/' + step['log']])
    assert report['integration']['tests'] == index['installed_binding_tests']
    assert all(report['integration'][key] == 0 for key in ('failures', 'errors', 'skipped'))
    context = json.loads(contents['installed/public-context.json'])
    assert context['status'] == 'passed' and context['tests'] == index['installed_context_tests']
    assert all(context[key] == 0 for key in ('failures', 'errors', 'skipped'))
    release = json.loads(contents['installed/release_scripts.json'])
    assert release == index['python_release_tests'] and release['status'] == 'passed'
    assert all(release[key] == 0 for key in ('failure_count', 'error_count', 'skipped_count'))
    result = dict(status='passed', archive_sha256=index['archive']['sha256'], manifest_sha256=index['manifest']['sha256'],
        index_sha256=sha(index_path.read_bytes()), members=len(rows), all_members_and_originals_reopened=True,
        source_files_verified=len(final['source_hashes']), accepted_runtime_sources_verified=len(runtime),
        exact_patch_reconstructed_files=len(current), guard_receipts_and_logs_verified=guards,
        native_test_counts=index['test_counts'], installed_proof_logs=len(report['steps']),
        installed_binding_tests=report['integration']['tests'],
        installed_context_tests=context['tests'], release_script_tests=release['test_count'],
        original_benchmark_scope_preserved=True, verifier_sha256=sha(Path(__file__).read_bytes()))
    target = PACK / 'conditional-checkpoint-packet-verification-2026-10-19.json'
    with target.open('x') as stream:
        stream.write(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
