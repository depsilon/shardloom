"""Package source-bound correctness proof without relabeling earlier benchmarks."""
import hashlib
import io
import json
import lzma
from pathlib import Path
import re
import subprocess
import tarfile

import checkpoint_driver_784 as driver

ROOT, OUT = driver.ROOT, driver.OUT
DEST = ROOT / 'docs/benchmarks/evidence'
BASE = 'ac08d39198cfe3922e0f5f560376edbb0e8517f8'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def test_counts(path):
    rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored', path.read_text())
    assert rows
    result = dict(targets=len(rows), passed=sum(int(row[0]) for row in rows),
                  failed=sum(int(row[1]) for row in rows), ignored=sum(int(row[2]) for row in rows))
    assert result['passed'] > 0 and result['failed'] == 0
    return result


def main():
    source = driver.verify()
    build = driver.verify_build()
    installed = json.loads((OUT / 'checkpoint-installed-python-784.json').read_text())
    python = json.loads((OUT / 'checkpoint-python-checks-784.json').read_text())
    initial = json.loads((OUT / 'checkpoint-source-freeze-783.json').read_text())
    completion = json.loads((OUT / 'checkpoint-sequence-completion-783.json').read_text())
    provenance = json.loads((OUT / 'checkpoint-dependency-provenance-784.json').read_text())
    assert all(row['status'] == 'passed' for row in (installed, python, completion, provenance))
    assert installed['source_manifest'] == python['source_manifest'] == driver.identity(driver.SOURCE)
    assert provenance['lock_sha256'] == driver.sha(ROOT / 'Cargo.lock')
    assert provenance['notice_manifest_sha256'] == driver.sha(ROOT / 'python/THIRD_PARTY_LICENSES/manifest.json')
    assert len(completion['steps']) == 11 and all(row['returncode'] == 0 for row in completion['steps'])
    receipts = []
    for step in completion['steps']:
        path = Path(step['receipt'])
        row = json.loads(path.read_text())
        assert row['status'] == 'passed' and row['process_group_drained']
        assert row['log_sha256'] == driver.sha(path.with_suffix('.log'))
        receipts.append(driver.identity(path))
    accepted = json.loads((ROOT / 'docs/benchmarks/evidence/compact-index-acceptance-source-764.json').read_text())['source_hashes']
    changed = sorted(name for name, sha in accepted.items() if driver.sha(ROOT / name) != sha)
    expected = ['Cargo.lock', 'python/THIRD_PARTY_LICENSES/manifest.json',
                'python/tests/test_release_scripts.py', 'scripts/check_pre_5j_dependency_freshness.py']
    assert changed == expected
    assert all(initial['source_hashes'][name] == source['source_hashes'][name]
               for name in accepted if name not in source['changed_since_native_gates'])
    assert driver.git('rev-parse', BASE + '^{tree}') == driver.git('rev-parse', 'f95490279ce06a91b27d0dc44a3b9ecf41b1d0d6^{tree}')
    counts = {name: test_counts(OUT / ('checkpoint-' + name + '-783.log'))
              for name in ('workspace-tests', 'native-tests', 'native-cli-tests')}
    assert counts['workspace-tests'] == dict(targets=107, passed=3235, failed=0, ignored=0)
    assert counts['native-tests'] == dict(targets=1, passed=3030, failed=0, ignored=30)
    assert counts['native-cli-tests'] == dict(targets=6, passed=1087, failed=0, ignored=0)
    members = {}

    def add(name, path):
        assert name not in members and not name.startswith('/') and '..' not in Path(name).parts
        path = Path(path)
        assert path.is_file() and not path.is_symlink()
        raw = path.read_bytes()
        members[name] = dict(raw=raw, original=str(path), bytes=len(raw), sha256=digest(raw))

    excluded = ('checkpoint-package-', 'checkpoint-packet-verification-')
    for path in sorted(OUT.glob('checkpoint-*')):
        if path.is_file() and path.suffix in ('.json', '.log') and not path.name.startswith(excluded):
            add('evidence/' + path.name, path)
    for name in ('open-pr-checks-782', 'dependency-intake-inventory-782', 'dependency-patch-failures-783'):
        for suffix in ('.json', '.md'):
            add('intake/' + name + suffix, OUT / (name + suffix))
    for suffix in ('.json', '.md'):
        add('source/conditional-checkpoint-source-proof-783' + suffix,
            OUT / ('conditional-checkpoint-source-proof-783' + suffix))
    for path in sorted((OUT / 'dependency-patch-failure-logs-783').glob('*')):
        if path.is_file():
            add('intake/raw/' + path.name, path)
    for path in sorted(driver.PROOF.glob('*')):
        if path.is_file() and path.suffix in ('.json', '.log'):
            add('installed/' + path.name, path)
    add('installed/release_scripts.json', OUT / 'checkpoint-python-shards-784/release_scripts.json')
    helpers = ('validate_checkpoint_783.py', 'run_guarded_checkpoint_783.py', 'checkpoint_driver_784.py',
               'verify_checkpoint_dependencies_784.py', 'package_checkpoint_784.py',
               'verify_checkpoint_packet_784.py')
    for name in helpers:
        add('helpers/' + name, OUT / name)
    add('helpers/release_validation_guard.py', '/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py')
    add('helpers/bounded_build_process_resume_20260912.py', '/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
    patch_paths = expected + ['docs/dependencies/json-digest-dependency-review.md']
    patch = subprocess.check_output(['git', 'diff', '--binary', BASE, '--', *patch_paths], cwd=ROOT)
    assert patch
    members['source/patch-from-' + BASE + '.diff'] = dict(raw=patch, original='generated:git-diff', bytes=len(patch), sha256=digest(patch))
    for name in patch_paths:
        add('source/current/' + name, ROOT / name)
    runtime = [name for name in driver.git('diff', '--name-only', 'origin/main...' + BASE, '--', 'shardloom-vortex').splitlines() if name.endswith('.rs')]
    assert len(runtime) == 8
    for name in runtime:
        assert driver.sha(ROOT / name) == accepted[name]
        add('source/accepted-runtime/' + name, ROOT / name)
    add('source/accepted-source-map.json', ROOT / 'docs/benchmarks/evidence/compact-index-acceptance-source-764.json')
    names = sorted(members)
    archive_path = DEST / 'conditional-checkpoint-2026-10-19.tar.xz'
    manifest_path = DEST / 'conditional-checkpoint-2026-10-19.manifest.json.xz'
    index_path = DEST / 'conditional-checkpoint-2026-10-19.json'
    assert not any(path.exists() for path in (archive_path, manifest_path, index_path))
    with archive_path.open('xb') as stream:
        with tarfile.open(fileobj=stream, mode='w:xz', preset=6) as archive:
            for name in names:
                info = tarfile.TarInfo(name)
                info.size = members[name]['bytes']
                info.mode = 0o644
                archive.addfile(info, io.BytesIO(members[name]['raw']))
    rows = [dict(path=name, **{key: value for key, value in members[name].items() if key != 'raw'}) for name in names]
    with tarfile.open(archive_path, 'r:xz') as archive:
        assert archive.getnames() == names
        for row in rows:
            raw = archive.extractfile(row['path']).read()
            assert len(raw) == row['bytes'] and digest(raw) == row['sha256']
            if not row['original'].startswith('generated:'):
                assert raw == Path(row['original']).read_bytes()
    manifest = dict(status='passed', all_members_and_originals_reopened=True, members=rows)
    raw = (json.dumps(manifest, indent=2) + '\n').encode()
    with manifest_path.open('xb') as stream:
        stream.write(lzma.compress(raw))
    assert lzma.decompress(manifest_path.read_bytes()) == raw
    assert driver.verify() == source and driver.verify_build() == build
    result = dict(schema_version='shardloom.conditional_checkpoint.v1', status='passed',
        base_commit=BASE, unchanged_tree_from_completed_eight='f95490279ce06a91b27d0dc44a3b9ecf41b1d0d6',
        accepted_source_count=len(accepted), changes_since_original_acceptance=changed,
        source_changes_after_fresh_native_gates=source['changed_since_native_gates'],
        retained_runtime_matches_original_acceptance=True,
        current_source=driver.identity(driver.SOURCE), native_gate_source=driver.identity(OUT / 'checkpoint-source-freeze-783.json'),
        native_gate_completion=driver.identity(OUT / 'checkpoint-sequence-completion-783.json'),
        native_gate_receipts=receipts, test_counts=counts,
        python_release_tests=json.loads((OUT / 'checkpoint-python-shards-784/release_scripts.json').read_text()),
        installed_binding_tests=installed['native_binding_tests'], installed_context_tests=installed['installed_context_tests'],
        clean_install_and_uninstall_verified=True, dependency_provenance=driver.identity(OUT / 'checkpoint-dependency-provenance-784.json'),
        build=driver.identity(driver.BUILD), omitted_built_artifacts=[driver.identity(build['binary']), build['native_library'], installed['wheel']],
        benchmark_scope='Earlier compact-index, Public39, Full43 and modular records retain their original compiled dependency graph. No benchmark was rerun or relabeled for this patch intake.',
        performance_claim=False, package_publication_attempted=False, member_count=len(rows),
        archive=dict(file=archive_path.name, bytes=archive_path.stat().st_size, sha256=driver.sha(archive_path)),
        manifest=dict(file=manifest_path.name, bytes=manifest_path.stat().st_size, sha256=driver.sha(manifest_path)),
        all_members_and_originals_reopened=True, generator=driver.identity(__file__))
    driver.save(index_path, result)
    print(json.dumps(dict(status='passed', members=len(rows), archive_sha256=result['archive']['sha256'])))


if __name__ == '__main__':
    main()
