# Open dependency PR intake inventory

Snapshot time: 2026-10-19T23:51:30.907779+00:00. Source: [depsilon/shardloom open PRs](https://github.com/depsilon/shardloom/pulls) and GitHub PR files API.

Open Dependabot PRs: **4**. Every changed-file unified diff is preserved in the JSON evidence. Compatibility flags below are literal diff observations only.

| PR | Title | Head SHA | Changed files | Checks (pass/fail/pending/skipped) | Check eligibility |
|---:|---|---|---|---:|---|
| [#1570](https://github.com/depsilon/shardloom/pull/1570) | Bump serde_json from 1.0.151 to 1.0.154 | `fd5d40b1180b174635b2bbdfc3bfb83d986a3902` | Cargo.lock | 38/6/0/0 | ineligible_from_observed_checks |
| [#1569](https://github.com/depsilon/shardloom/pull/1569) | Bump sha2 from 0.11.0 to 0.11.1 | `4639d3ce5d6ec9a0934e93783b12ecf965500a4c` | Cargo.lock | 38/6/0/0 | ineligible_from_observed_checks |
| [#1568](https://github.com/depsilon/shardloom/pull/1568) | Bump pyo3-build-config from 0.29.3 to 0.30.1 | `6c4304f87402d5b58c6073dd2a565b166431b2b1` | Cargo.lock, Cargo.toml | 40/4/0/0 | ineligible_from_observed_checks |
| [#1513](https://github.com/depsilon/shardloom/pull/1513) | Bump the structured-format-stack group across 1 directory with 6 updates | `de0ee9676198e185641e303a7843eb29e7250f13` | Cargo.lock, Cargo.toml, shardloom-cli/Cargo.toml, shardloom-vortex/Cargo.toml | 29/13/0/2 | ineligible_from_observed_checks |

## Literal package version changes

### [#1570](https://github.com/depsilon/shardloom/pull/1570)

- `serde_json`: `1.0.151` → `1.0.154` (PR title and Cargo.lock diff).

### [#1569](https://github.com/depsilon/shardloom/pull/1569)

- `sha2`: `0.11.0` → `0.11.1` (PR title and Cargo.lock diff).

### [#1568](https://github.com/depsilon/shardloom/pull/1568)

- `pyo3-build-config`: `0.29.3` → `0.30.1` (PR title and Cargo.toml/Cargo.lock diff).

Observed from diff: Root Cargo.toml changes pyo3-build-config to =0.30.1 while pyo3 remains pinned at =0.29.3; Cargo.lock adds/updates pyo3-build-config 0.30.1. Literal version relationship only; no compatibility conclusion.

### [#1513](https://github.com/depsilon/shardloom/pull/1513)

- `arrow-array`: `58.3.0` → `60.0.0` (root Cargo.toml diff).
- `arrow-avro`: `58.3.0` → `60.0.0` (root Cargo.toml diff).
- `arrow-ipc`: `58.3.0` → `60.0.0` (root Cargo.toml diff).
- `arrow-schema`: `58.3.0` → `60.0.0` (root Cargo.toml diff).
- `parquet`: `58.3.0` → `59.3.1` (root Cargo.toml diff).
- `orc-rust`: `0.8.0` → `0.9.0` (shardloom-cli and shardloom-vortex Cargo.toml diffs).

Observed from diff: Root Cargo.toml changes arrow-array, arrow-avro, arrow-ipc and arrow-schema to 60.0.0, while arrow-pyarrow remains pinned at =58.3.0; parquet moves from 58.3.0 to 59.3.1. Cargo.lock diff contains Arrow package entries at 58.3.0, 58.4.0, 59.3.1 and 60.0.0. Literal diff observations only; no compatibility conclusion.

This inventory records changed manifests, lockfiles, and literal versions. It does not assess package safety, compatibility, licenses, or recommend whether changes should be combined.

