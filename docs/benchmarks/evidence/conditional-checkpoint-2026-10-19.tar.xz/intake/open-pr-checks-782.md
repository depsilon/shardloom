# Open PR and check inventory

Snapshot time: 2026-10-19T23:51:30.907779+00:00. Source: GitHub CLI and REST API for [depsilon/shardloom](https://github.com/depsilon/shardloom).

Open PRs: **4**; PR check results: **176**; exact-SHA commit check runs: **176**.

| PR | Head SHA | Base SHA | Pass | Fail | Pending | Skipped | Cancelled | Actions and SHA-bound check-run match | Check eligibility |
|---:|---|---|---:|---:|---:|---:|---:|---|---|
| [#1570](https://github.com/depsilon/shardloom/pull/1570) | `fd5d40b1180b174635b2bbdfc3bfb83d986a3902` | `5bcee25ac3e41d7c509ca19cc59c51e0c2e58d96` | 38 | 6 | 0 | 0 | 0 | true | **ineligible_from_observed_checks** |
| [#1569](https://github.com/depsilon/shardloom/pull/1569) | `4639d3ce5d6ec9a0934e93783b12ecf965500a4c` | `5bcee25ac3e41d7c509ca19cc59c51e0c2e58d96` | 38 | 6 | 0 | 0 | 0 | true | **ineligible_from_observed_checks** |
| [#1568](https://github.com/depsilon/shardloom/pull/1568) | `6c4304f87402d5b58c6073dd2a565b166431b2b1` | `5bcee25ac3e41d7c509ca19cc59c51e0c2e58d96` | 40 | 4 | 0 | 0 | 0 | true | **ineligible_from_observed_checks** |
| [#1513](https://github.com/depsilon/shardloom/pull/1513) | `de0ee9676198e185641e303a7843eb29e7250f13` | `5bcee25ac3e41d7c509ca19cc59c51e0c2e58d96` | 29 | 13 | 0 | 2 | 0 | true | **ineligible_from_observed_checks** |

The required-check query returned “no required checks reported” for every Dependabot branch, so required-only eligibility is unavailable. The reported current-head check sets contain failures for every PR. All Actions run metadata and each commit check-run record are tied to the listed current head SHA. No PR meets the all-reported-checks-passing, nonpending, exact-head assessment.

The JSON preserves raw PR checks, each SHA-specific commit check run and conclusion, linked Actions run metadata, the required-check query result, and exact PR metadata.

