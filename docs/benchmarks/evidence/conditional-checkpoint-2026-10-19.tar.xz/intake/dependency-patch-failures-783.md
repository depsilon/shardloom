# Dependency patch failed-check evidence

Fetched 2026-10-19T23:55:28.575844+00:00 for [depsilon/shardloom](https://github.com/depsilon/shardloom). Source head SHAs are from `open-pr-checks-782.json`; each Actions run head was verified against its PR head.

Failed check mappings: **12** across **12** distinct run/job logs. All preserved logs are bounded to 160,000 characters and complete within that limit.

| PR | Check | Source head SHA | Run / job | Failing command | Log |
|---:|---|---|---|---|---|
| [#1570](https://github.com/depsilon/shardloom/pull/1570) | Release readiness reports | `fd5d40b1180b174635b2bbdfc3bfb83d986a3902` | [run 39078227011 / job 117539237295](https://github.com/depsilon/shardloom/actions/runs/39078227011/job/117539237295) | `exit 1` | [raw log](dependency-patch-failure-logs-783/pr-1570-run-39078227011-job-117539237295-release-readiness-reports.log) |
| [#1570](https://github.com/depsilon/shardloom/pull/1570) | Python tests | `fd5d40b1180b174635b2bbdfc3bfb83d986a3902` | [run 39078227011 / job 117535217634](https://github.com/depsilon/shardloom/actions/runs/39078227011/job/117535217634) | `python scripts/merge_python_test_shard_evidence.py` | [raw log](dependency-patch-failure-logs-783/pr-1570-run-39078227011-job-117535217634-python-tests.log) |
| [#1570](https://github.com/depsilon/shardloom/pull/1570) | Python test shard (release_scripts) | `fd5d40b1180b174635b2bbdfc3bfb83d986a3902` | [run 39078227011 / job 117529702801](https://github.com/depsilon/shardloom/actions/runs/39078227011/job/117529702801) | `python scripts/run_python_test_shard.py --shard release_scripts` | [raw log](dependency-patch-failure-logs-783/pr-1570-run-39078227011-job-117529702801-python-test-shard-release_scripts.log) |
| [#1570](https://github.com/depsilon/shardloom/pull/1570) | Native Python wheel (py310_ubuntu) | `fd5d40b1180b174635b2bbdfc3bfb83d986a3902` | [run 39078227011 / job 117529702865](https://github.com/depsilon/shardloom/actions/runs/39078227011/job/117529702865) | `python -B -m unittest discover -s scripts -p test_python_license_bundle.py -v` | [raw log](dependency-patch-failure-logs-783/pr-1570-run-39078227011-job-117529702865-native-python-wheel-py310_ubuntu.log) |
| [#1570](https://github.com/depsilon/shardloom/pull/1570) | Native Python wheel (py313_ubuntu) | `fd5d40b1180b174635b2bbdfc3bfb83d986a3902` | [run 39078227011 / job 117529702830](https://github.com/depsilon/shardloom/actions/runs/39078227011/job/117529702830) | `python -B -m unittest discover -s scripts -p test_python_license_bundle.py -v` | [raw log](dependency-patch-failure-logs-783/pr-1570-run-39078227011-job-117529702830-native-python-wheel-py313_ubuntu.log) |
| [#1570](https://github.com/depsilon/shardloom/pull/1570) | Native Python wheel (py313_macos) | `fd5d40b1180b174635b2bbdfc3bfb83d986a3902` | [run 39078227011 / job 117529702834](https://github.com/depsilon/shardloom/actions/runs/39078227011/job/117529702834) | `python -B -m unittest discover -s scripts -p test_python_license_bundle.py -v` | [raw log](dependency-patch-failure-logs-783/pr-1570-run-39078227011-job-117529702834-native-python-wheel-py313_macos.log) |
| [#1569](https://github.com/depsilon/shardloom/pull/1569) | Release readiness reports | `4639d3ce5d6ec9a0934e93783b12ecf965500a4c` | [run 39078218406 / job 117539348784](https://github.com/depsilon/shardloom/actions/runs/39078218406/job/117539348784) | `exit 1` | [raw log](dependency-patch-failure-logs-783/pr-1569-run-39078218406-job-117539348784-release-readiness-reports.log) |
| [#1569](https://github.com/depsilon/shardloom/pull/1569) | Python tests | `4639d3ce5d6ec9a0934e93783b12ecf965500a4c` | [run 39078218406 / job 117533457841](https://github.com/depsilon/shardloom/actions/runs/39078218406/job/117533457841) | `python scripts/merge_python_test_shard_evidence.py` | [raw log](dependency-patch-failure-logs-783/pr-1569-run-39078218406-job-117533457841-python-tests.log) |
| [#1569](https://github.com/depsilon/shardloom/pull/1569) | Python test shard (release_scripts) | `4639d3ce5d6ec9a0934e93783b12ecf965500a4c` | [run 39078218406 / job 117529680133](https://github.com/depsilon/shardloom/actions/runs/39078218406/job/117529680133) | `python scripts/run_python_test_shard.py --shard release_scripts` | [raw log](dependency-patch-failure-logs-783/pr-1569-run-39078218406-job-117529680133-python-test-shard-release_scripts.log) |
| [#1569](https://github.com/depsilon/shardloom/pull/1569) | Native Python wheel (py310_ubuntu) | `4639d3ce5d6ec9a0934e93783b12ecf965500a4c` | [run 39078218406 / job 117529680259](https://github.com/depsilon/shardloom/actions/runs/39078218406/job/117529680259) | `python -B -m unittest discover -s scripts -p test_python_license_bundle.py -v` | [raw log](dependency-patch-failure-logs-783/pr-1569-run-39078218406-job-117529680259-native-python-wheel-py310_ubuntu.log) |
| [#1569](https://github.com/depsilon/shardloom/pull/1569) | Native Python wheel (py313_macos) | `4639d3ce5d6ec9a0934e93783b12ecf965500a4c` | [run 39078218406 / job 117529680125](https://github.com/depsilon/shardloom/actions/runs/39078218406/job/117529680125) | `python -B -m unittest discover -s scripts -p test_python_license_bundle.py -v` | [raw log](dependency-patch-failure-logs-783/pr-1569-run-39078218406-job-117529680125-native-python-wheel-py313_macos.log) |
| [#1569](https://github.com/depsilon/shardloom/pull/1569) | Native Python wheel (py313_ubuntu) | `4639d3ce5d6ec9a0934e93783b12ecf965500a4c` | [run 39078218406 / job 117529680142](https://github.com/depsilon/shardloom/actions/runs/39078218406/job/117529680142) | `python -B -m unittest discover -s scripts -p test_python_license_bundle.py -v` | [raw log](dependency-patch-failure-logs-783/pr-1569-run-39078218406-job-117529680142-native-python-wheel-py313_ubuntu.log) |

## PR #1570 failed checks

### Release readiness reports

- Check: [Release readiness reports](https://github.com/depsilon/shardloom/actions/runs/39078227011/job/117539237295)
- Source head: `fd5d40b1180b174635b2bbdfc3bfb83d986a3902`; Actions run head: `fd5d40b1180b174635b2bbdfc3bfb83d986a3902`; job conclusion: `failure`.
- Failing command: `exit 1`.
- Raw log: [/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/dependency-patch-failure-logs-783/pr-1570-run-39078227011-job-117539237295-release-readiness-reports.log](dependency-patch-failure-logs-783/pr-1570-run-39078227011-job-117539237295-release-readiness-reports.log) (14655 bytes; SHA-256 `e71a57b4087c994093c02482d626153446fedfc00e8874d60dd6102953352585`).
- Diagnostic excerpt (generic_exit_only):
```text
Release readiness reports	UNKNOWN STEP	2026-10-18T00:06:12.4281363Z ##[group]Run exit 1
Release readiness reports	UNKNOWN STEP	2026-10-18T00:06:12.4281929Z ^[[36;1mexit 1^[[0m
Release readiness reports	UNKNOWN STEP	2026-10-18T00:06:12.4709064Z ##[error]Process completed with exit code 1.
Release readiness reports	UNKNOWN STEP	2026-10-18T00:06:12.5025892Z   path: target/dependency-audit-report.json
Release readiness reports	UNKNOWN STEP	2026-10-18T00:06:12.6729394Z No files were found with the provided path: target/dependency-audit-report.json
Release readiness reports	UNKNOWN STEP	2026-10-18T00:06:12.6772535Z target/finished-product-readiness-report.json. No artifacts will be uploaded.
```
- Diagnostic detail availability: The job log shows only the explicit `exit 1` command and generic process-exit annotation; no more specific diagnostic text was present in this job log.
- Check annotations:
```json
[
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/fd5d40b1180b174635b2bbdfc3bfb83d986a3902/.github",
    "start_line": 8,
    "start_column": null,
    "end_line": 8,
    "end_column": null,
    "annotation_level": "failure",
    "title": "",
    "message": "Process completed with exit code 1.",
    "raw_details": ""
  },
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/fd5d40b1180b174635b2bbdfc3bfb83d986a3902/.github",
    "start_line": 1,
    "start_column": null,
    "end_line": 1,
    "end_column": null,
    "annotation_level": "notice",
    "title": "",
    "message": "\"The ubuntu-latest label will migrate to Ubuntu 26 beginning October 19, 2026. For more information, see https://github.com/actions/runner-images/issues/14748\"",
    "raw_details": ""
  }
]
```

### Python tests

- Check: [Python tests](https://github.com/depsilon/shardloom/actions/runs/39078227011/job/117535217634)
- Source head: `fd5d40b1180b174635b2bbdfc3bfb83d986a3902`; Actions run head: `fd5d40b1180b174635b2bbdfc3bfb83d986a3902`; job conclusion: `failure`.
- Failing command: `python scripts/merge_python_test_shard_evidence.py`.
- Raw log: [/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/dependency-patch-failure-logs-783/pr-1570-run-39078227011-job-117535217634-python-tests.log](dependency-patch-failure-logs-783/pr-1570-run-39078227011-job-117535217634-python-tests.log) (77249 bytes; SHA-256 `514f48e575676c91ed2190647ae0802a6281db7ed2735b2a7a59e00d8be0b001`).
- Diagnostic excerpt (generic_exit_only):
```text
Python tests	UNKNOWN STEP	2026-10-17T23:50:22.5502653Z ##[group]Run python scripts/merge_python_test_shard_evidence.py
Python tests	UNKNOWN STEP	2026-10-17T23:50:22.5503187Z ^[[36;1mpython scripts/merge_python_test_shard_evidence.py^[[0m
Python tests	UNKNOWN STEP	2026-10-17T23:50:22.6447842Z /home/runner/work/shardloom/shardloom/target/python-test-evidence.json
Python tests	UNKNOWN STEP	2026-10-17T23:50:22.6543548Z ##[error]Process completed with exit code 1.
Python tests	UNKNOWN STEP	2026-10-17T23:50:22.6632788Z   path: target/python-test-evidence.json
```
- Diagnostic detail availability: The job log shows the evidence-merger command, output path, and generic exit-code annotation; no more specific diagnostic text was present in this job log. The release_scripts shard has a separate failed-check mapping with its own test diagnostics.
- Check annotations:
```json
[
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/fd5d40b1180b174635b2bbdfc3bfb83d986a3902/.github",
    "start_line": 15,
    "start_column": null,
    "end_line": 15,
    "end_column": null,
    "annotation_level": "failure",
    "title": "",
    "message": "Process completed with exit code 1.",
    "raw_details": ""
  },
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/fd5d40b1180b174635b2bbdfc3bfb83d986a3902/.github",
    "start_line": 1,
    "start_column": null,
    "end_line": 1,
    "end_column": null,
    "annotation_level": "notice",
    "title": "",
    "message": "\"The ubuntu-latest label will migrate to Ubuntu 26 beginning October 19, 2026. For more information, see https://github.com/actions/runner-images/issues/14748\"",
    "raw_details": ""
  }
]
```

### Python test shard (release_scripts)

- Check: [Python test shard (release_scripts)](https://github.com/depsilon/shardloom/actions/runs/39078227011/job/117529702801)
- Source head: `fd5d40b1180b174635b2bbdfc3bfb83d986a3902`; Actions run head: `fd5d40b1180b174635b2bbdfc3bfb83d986a3902`; job conclusion: `failure`.
- Failing command: `python scripts/run_python_test_shard.py --shard release_scripts`.
- Raw log: [/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/dependency-patch-failure-logs-783/pr-1570-run-39078227011-job-117529702801-python-test-shard-release_scripts.log](dependency-patch-failure-logs-783/pr-1570-run-39078227011-job-117529702801-python-test-shard-release_scripts.log) (46153 bytes; SHA-256 `e0ea83a8a24bdcd9c1b7e865892240e99a0e9928eca972374df35c10933cf41b`).
- Diagnostic excerpt (specific_failure_detail_in_log):
```text
Python test shard (release_scripts)	UNKNOWN STEP	2026-10-17T23:24:25.9581275Z FAIL: test_pre_5j_dependency_freshness_accepts_current_dependabot_prs (python.tests.test_release_scripts.ReleaseScriptTests.test_pre_5j_dependency_freshness_accepts_current_dependabot_prs)
Python test shard (release_scripts)	UNKNOWN STEP	2026-10-17T23:24:25.9589424Z AssertionError: 'blocked' != 'passed'
Python test shard (release_scripts)	UNKNOWN STEP	2026-10-17T23:24:25.9589989Z  : ["PR #1151: Cargo.lock serde_json='1.0.154'"]
Python test shard (release_scripts)	UNKNOWN STEP	2026-10-17T23:24:25.9590999Z FAIL: test_pre_5j_dependency_freshness_without_live_check_keeps_benchmark_blocked (python.tests.test_release_scripts.ReleaseScriptTests.test_pre_5j_dependency_freshness_without_live_check_keeps_benchmark_blocked)
Python test shard (release_scripts)	UNKNOWN STEP	2026-10-17T23:24:25.9593689Z AssertionError: 'blocked' != 'passed'
Python test shard (release_scripts)	UNKNOWN STEP	2026-10-17T23:24:25.9594219Z  : ["PR #1151: Cargo.lock serde_json='1.0.154'"]
Python test shard (release_scripts)	UNKNOWN STEP	2026-10-17T23:24:25.9595627Z   "command": "python scripts/run_python_test_shard.py --shard release_scripts",
Python test shard (release_scripts)	UNKNOWN STEP	2026-10-17T23:24:25.9596801Z   "failure_count": 2,
Python test shard (release_scripts)	UNKNOWN STEP	2026-10-17T23:24:26.0103431Z ##[error]Process completed with exit code 1.
```
- Check annotations:
```json
[
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/fd5d40b1180b174635b2bbdfc3bfb83d986a3902/.github",
    "start_line": 62,
    "start_column": null,
    "end_line": 62,
    "end_column": null,
    "annotation_level": "failure",
    "title": "",
    "message": "Process completed with exit code 1.",
    "raw_details": ""
  },
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/fd5d40b1180b174635b2bbdfc3bfb83d986a3902/.github",
    "start_line": 1,
    "start_column": null,
    "end_line": 1,
    "end_column": null,
    "annotation_level": "notice",
    "title": "",
    "message": "\"The ubuntu-latest label will migrate to Ubuntu 26 beginning October 19, 2026. For more information, see https://github.com/actions/runner-images/issues/14748\"",
    "raw_details": ""
  }
]
```

### Native Python wheel (py310_ubuntu)

- Check: [Native Python wheel (py310_ubuntu)](https://github.com/depsilon/shardloom/actions/runs/39078227011/job/117529702865)
- Source head: `fd5d40b1180b174635b2bbdfc3bfb83d986a3902`; Actions run head: `fd5d40b1180b174635b2bbdfc3bfb83d986a3902`; job conclusion: `failure`.
- Failing command: `python -B -m unittest discover -s scripts -p test_python_license_bundle.py -v`.
- Raw log: [/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/dependency-patch-failure-logs-783/pr-1570-run-39078227011-job-117529702865-native-python-wheel-py310_ubuntu.log](dependency-patch-failure-logs-783/pr-1570-run-39078227011-job-117529702865-native-python-wheel-py310_ubuntu.log) (96377 bytes; SHA-256 `a7df308b81956ae0b6bcc46406414209c216d571f45fcb5dc69aaa17e1e56f1b`).
- Diagnostic excerpt (specific_failure_detail_in_log):
```text
Native Python wheel (py310_ubuntu)	UNKNOWN STEP	2026-10-17T23:19:22.5802857Z ERROR: test_checked_in_bundle_covers_every_locked_registry_package (test_python_license_bundle.PythonLicenseBundleTests)
Native Python wheel (py310_ubuntu)	UNKNOWN STEP	2026-10-17T23:19:22.5804099Z Traceback (most recent call last):
Native Python wheel (py310_ubuntu)	UNKNOWN STEP	2026-10-17T23:19:22.5813113Z     raise ValueError("notice bundle does not exactly cover the registry lockfile")
Native Python wheel (py310_ubuntu)	UNKNOWN STEP	2026-10-17T23:19:22.5813766Z ValueError: notice bundle does not exactly cover the registry lockfile
Native Python wheel (py310_ubuntu)	UNKNOWN STEP	2026-10-17T23:19:22.5961570Z ##[error]Process completed with exit code 1.
Native Python wheel (py310_ubuntu)	UNKNOWN STEP	2026-10-17T23:19:22.7500502Z ##[error]No files were found with the provided path: /home/runner/work/_temp/native-python-j9ankqly/build.json
```
- Check annotations:
```json
[
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/fd5d40b1180b174635b2bbdfc3bfb83d986a3902/.github",
    "start_line": 32,
    "start_column": null,
    "end_line": 32,
    "end_column": null,
    "annotation_level": "failure",
    "title": "",
    "message": "No files were found with the provided path: /home/runner/work/_temp/native-python-j9ankqly/build.json\n/home/runner/work/_temp/native-python-j9ankqly/proof/report.json\n/home/runner/work/_temp/native-python-j9ankqly/proof/integration.json\n/home/runner/work/_temp/native-python-j9ankqly/proof/*.log\n/home/runner/work/_temp/native-python-j9ankqly/proof/dist/*.whl. No artifacts will be uploaded.",
    "raw_details": ""
  },
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/fd5d40b1180b174635b2bbdfc3bfb83d986a3902/.github",
    "start_line": 40,
    "start_column": null,
    "end_line": 40,
    "end_column": null,
    "annotation_level": "failure",
    "title": "",
    "message": "Process completed with exit code 1.",
    "raw_details": ""
  }
]
```

### Native Python wheel (py313_ubuntu)

- Check: [Native Python wheel (py313_ubuntu)](https://github.com/depsilon/shardloom/actions/runs/39078227011/job/117529702830)
- Source head: `fd5d40b1180b174635b2bbdfc3bfb83d986a3902`; Actions run head: `fd5d40b1180b174635b2bbdfc3bfb83d986a3902`; job conclusion: `failure`.
- Failing command: `python -B -m unittest discover -s scripts -p test_python_license_bundle.py -v`.
- Raw log: [/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/dependency-patch-failure-logs-783/pr-1570-run-39078227011-job-117529702830-native-python-wheel-py313_ubuntu.log](dependency-patch-failure-logs-783/pr-1570-run-39078227011-job-117529702830-native-python-wheel-py313_ubuntu.log) (97251 bytes; SHA-256 `e4fb289ef9a02ecfa80c4699ea48a80787fd24fd5980bc6c77dc3ff9acaf0d98`).
- Diagnostic excerpt (specific_failure_detail_in_log):
```text
Native Python wheel (py313_ubuntu)	UNKNOWN STEP	2026-10-17T23:18:23.3328063Z ERROR: test_checked_in_bundle_covers_every_locked_registry_package (test_python_license_bundle.PythonLicenseBundleTests.test_checked_in_bundle_covers_every_locked_registry_package)
Native Python wheel (py313_ubuntu)	UNKNOWN STEP	2026-10-17T23:18:23.3329547Z Traceback (most recent call last):
Native Python wheel (py313_ubuntu)	UNKNOWN STEP	2026-10-17T23:18:23.3338735Z     raise ValueError("notice bundle does not exactly cover the registry lockfile")
Native Python wheel (py313_ubuntu)	UNKNOWN STEP	2026-10-17T23:18:23.3339405Z ValueError: notice bundle does not exactly cover the registry lockfile
Native Python wheel (py313_ubuntu)	UNKNOWN STEP	2026-10-17T23:18:23.3528048Z ##[error]Process completed with exit code 1.
Native Python wheel (py313_ubuntu)	UNKNOWN STEP	2026-10-17T23:18:23.5018023Z ##[error]No files were found with the provided path: /home/runner/work/_temp/native-python-7cswu7lh/build.json
```
- Check annotations:
```json
[
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/fd5d40b1180b174635b2bbdfc3bfb83d986a3902/.github",
    "start_line": 32,
    "start_column": null,
    "end_line": 32,
    "end_column": null,
    "annotation_level": "failure",
    "title": "",
    "message": "No files were found with the provided path: /home/runner/work/_temp/native-python-7cswu7lh/build.json\n/home/runner/work/_temp/native-python-7cswu7lh/proof/report.json\n/home/runner/work/_temp/native-python-7cswu7lh/proof/integration.json\n/home/runner/work/_temp/native-python-7cswu7lh/proof/*.log\n/home/runner/work/_temp/native-python-7cswu7lh/proof/dist/*.whl. No artifacts will be uploaded.",
    "raw_details": ""
  },
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/fd5d40b1180b174635b2bbdfc3bfb83d986a3902/.github",
    "start_line": 40,
    "start_column": null,
    "end_line": 40,
    "end_column": null,
    "annotation_level": "failure",
    "title": "",
    "message": "Process completed with exit code 1.",
    "raw_details": ""
  }
]
```

### Native Python wheel (py313_macos)

- Check: [Native Python wheel (py313_macos)](https://github.com/depsilon/shardloom/actions/runs/39078227011/job/117529702834)
- Source head: `fd5d40b1180b174635b2bbdfc3bfb83d986a3902`; Actions run head: `fd5d40b1180b174635b2bbdfc3bfb83d986a3902`; job conclusion: `failure`.
- Failing command: `python -B -m unittest discover -s scripts -p test_python_license_bundle.py -v`.
- Raw log: [/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/dependency-patch-failure-logs-783/pr-1570-run-39078227011-job-117529702834-native-python-wheel-py313_macos.log](dependency-patch-failure-logs-783/pr-1570-run-39078227011-job-117529702834-native-python-wheel-py313_macos.log) (96476 bytes; SHA-256 `429af45700a27a9363bbb4752bb36f83980248c949918c0f542083f1491d6889`).
- Diagnostic excerpt (specific_failure_detail_in_log):
```text
Native Python wheel (py313_macos)	UNKNOWN STEP	2026-10-17T23:17:52.6209910Z ERROR: test_checked_in_bundle_covers_every_locked_registry_package (test_python_license_bundle.PythonLicenseBundleTests.test_checked_in_bundle_covers_every_locked_registry_package)
Native Python wheel (py313_macos)	UNKNOWN STEP	2026-10-17T23:17:52.6211490Z Traceback (most recent call last):
Native Python wheel (py313_macos)	UNKNOWN STEP	2026-10-17T23:17:52.6220880Z     raise ValueError("notice bundle does not exactly cover the registry lockfile")
Native Python wheel (py313_macos)	UNKNOWN STEP	2026-10-17T23:17:52.6221420Z ValueError: notice bundle does not exactly cover the registry lockfile
Native Python wheel (py313_macos)	UNKNOWN STEP	2026-10-17T23:17:52.6354840Z ##[error]Process completed with exit code 1.
Native Python wheel (py313_macos)	UNKNOWN STEP	2026-10-17T23:17:52.8300300Z ##[error]No files were found with the provided path: /Users/runner/work/_temp/native-python-vsm63pw_/build.json
```
- Check annotations:
```json
[
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/fd5d40b1180b174635b2bbdfc3bfb83d986a3902/.github",
    "start_line": 31,
    "start_column": null,
    "end_line": 31,
    "end_column": null,
    "annotation_level": "failure",
    "title": "",
    "message": "No files were found with the provided path: /Users/runner/work/_temp/native-python-vsm63pw_/build.json\n/Users/runner/work/_temp/native-python-vsm63pw_/proof/report.json\n/Users/runner/work/_temp/native-python-vsm63pw_/proof/integration.json\n/Users/runner/work/_temp/native-python-vsm63pw_/proof/*.log\n/Users/runner/work/_temp/native-python-vsm63pw_/proof/dist/*.whl. No artifacts will be uploaded.",
    "raw_details": ""
  },
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/fd5d40b1180b174635b2bbdfc3bfb83d986a3902/.github",
    "start_line": 39,
    "start_column": null,
    "end_line": 39,
    "end_column": null,
    "annotation_level": "failure",
    "title": "",
    "message": "Process completed with exit code 1.",
    "raw_details": ""
  },
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/fd5d40b1180b174635b2bbdfc3bfb83d986a3902/.github",
    "start_line": 1,
    "start_column": null,
    "end_line": 1,
    "end_column": null,
    "annotation_level": "notice",
    "title": "",
    "message": "Due to capacity constraints, jobs targeting macOS arm64 runners may experience longer queue times.",
    "raw_details": ""
  }
]
```


## PR #1569 failed checks

### Release readiness reports

- Check: [Release readiness reports](https://github.com/depsilon/shardloom/actions/runs/39078218406/job/117539348784)
- Source head: `4639d3ce5d6ec9a0934e93783b12ecf965500a4c`; Actions run head: `4639d3ce5d6ec9a0934e93783b12ecf965500a4c`; job conclusion: `failure`.
- Failing command: `exit 1`.
- Raw log: [/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/dependency-patch-failure-logs-783/pr-1569-run-39078218406-job-117539348784-release-readiness-reports.log](dependency-patch-failure-logs-783/pr-1569-run-39078218406-job-117539348784-release-readiness-reports.log) (14650 bytes; SHA-256 `e9491ef4570ea7ea4b36225e1db92f337796fab57f2eaf313cc401b9b6a99386`).
- Diagnostic excerpt (generic_exit_only):
```text
Release readiness reports	UNKNOWN STEP	2026-10-18T00:06:48.4005501Z ##[group]Run exit 1
Release readiness reports	UNKNOWN STEP	2026-10-18T00:06:48.4006149Z ^[[36;1mexit 1^[[0m
Release readiness reports	UNKNOWN STEP	2026-10-18T00:06:48.4478079Z ##[error]Process completed with exit code 1.
Release readiness reports	UNKNOWN STEP	2026-10-18T00:06:48.4832139Z   path: target/dependency-audit-report.json
Release readiness reports	UNKNOWN STEP	2026-10-18T00:06:48.6607977Z No files were found with the provided path: target/dependency-audit-report.json
Release readiness reports	UNKNOWN STEP	2026-10-18T00:06:48.6664546Z target/finished-product-readiness-report.json. No artifacts will be uploaded.
```
- Diagnostic detail availability: The job log shows only the explicit `exit 1` command and generic process-exit annotation; no more specific diagnostic text was present in this job log.
- Check annotations:
```json
[
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/4639d3ce5d6ec9a0934e93783b12ecf965500a4c/.github",
    "start_line": 8,
    "start_column": null,
    "end_line": 8,
    "end_column": null,
    "annotation_level": "failure",
    "title": "",
    "message": "Process completed with exit code 1.",
    "raw_details": ""
  },
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/4639d3ce5d6ec9a0934e93783b12ecf965500a4c/.github",
    "start_line": 1,
    "start_column": null,
    "end_line": 1,
    "end_column": null,
    "annotation_level": "notice",
    "title": "",
    "message": "\"The ubuntu-latest label will migrate to Ubuntu 26 beginning October 19, 2026. For more information, see https://github.com/actions/runner-images/issues/14748\"",
    "raw_details": ""
  }
]
```

### Python tests

- Check: [Python tests](https://github.com/depsilon/shardloom/actions/runs/39078218406/job/117533457841)
- Source head: `4639d3ce5d6ec9a0934e93783b12ecf965500a4c`; Actions run head: `4639d3ce5d6ec9a0934e93783b12ecf965500a4c`; job conclusion: `failure`.
- Failing command: `python scripts/merge_python_test_shard_evidence.py`.
- Raw log: [/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/dependency-patch-failure-logs-783/pr-1569-run-39078218406-job-117533457841-python-tests.log](dependency-patch-failure-logs-783/pr-1569-run-39078218406-job-117533457841-python-tests.log) (77252 bytes; SHA-256 `40fd61a05b15b6aa37033a800ebced98061cb7b158aa0717179d16a55879bf49`).
- Diagnostic excerpt (generic_exit_only):
```text
Python tests	UNKNOWN STEP	2026-10-17T23:55:26.7582134Z ##[group]Run python scripts/merge_python_test_shard_evidence.py
Python tests	UNKNOWN STEP	2026-10-17T23:55:26.7582636Z ^[[36;1mpython scripts/merge_python_test_shard_evidence.py^[[0m
Python tests	UNKNOWN STEP	2026-10-17T23:55:26.8469050Z /home/runner/work/shardloom/shardloom/target/python-test-evidence.json
Python tests	UNKNOWN STEP	2026-10-17T23:55:26.8560073Z ##[error]Process completed with exit code 1.
Python tests	UNKNOWN STEP	2026-10-17T23:55:26.8633536Z   path: target/python-test-evidence.json
```
- Diagnostic detail availability: The job log shows the evidence-merger command, output path, and generic exit-code annotation; no more specific diagnostic text was present in this job log. The release_scripts shard has a separate failed-check mapping with its own test diagnostics.
- Check annotations:
```json
[
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/4639d3ce5d6ec9a0934e93783b12ecf965500a4c/.github",
    "start_line": 15,
    "start_column": null,
    "end_line": 15,
    "end_column": null,
    "annotation_level": "failure",
    "title": "",
    "message": "Process completed with exit code 1.",
    "raw_details": ""
  },
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/4639d3ce5d6ec9a0934e93783b12ecf965500a4c/.github",
    "start_line": 1,
    "start_column": null,
    "end_line": 1,
    "end_column": null,
    "annotation_level": "notice",
    "title": "",
    "message": "\"The ubuntu-latest label will migrate to Ubuntu 26 beginning October 19, 2026. For more information, see https://github.com/actions/runner-images/issues/14748\"",
    "raw_details": ""
  }
]
```

### Python test shard (release_scripts)

- Check: [Python test shard (release_scripts)](https://github.com/depsilon/shardloom/actions/runs/39078218406/job/117529680133)
- Source head: `4639d3ce5d6ec9a0934e93783b12ecf965500a4c`; Actions run head: `4639d3ce5d6ec9a0934e93783b12ecf965500a4c`; job conclusion: `failure`.
- Failing command: `python scripts/run_python_test_shard.py --shard release_scripts`.
- Raw log: [/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/dependency-patch-failure-logs-783/pr-1569-run-39078218406-job-117529680133-python-test-shard-release_scripts.log](dependency-patch-failure-logs-783/pr-1569-run-39078218406-job-117529680133-python-test-shard-release_scripts.log) (46247 bytes; SHA-256 `d2b8103b7125f30b90d6993dba16163dd2862608d4a626d0958f4cc13824e2f0`).
- Diagnostic excerpt (specific_failure_detail_in_log):
```text
Python test shard (release_scripts)	UNKNOWN STEP	2026-10-17T23:34:03.9706232Z FAIL: test_pre_5j_dependency_freshness_accepts_current_dependabot_prs (python.tests.test_release_scripts.ReleaseScriptTests.test_pre_5j_dependency_freshness_accepts_current_dependabot_prs)
Python test shard (release_scripts)	UNKNOWN STEP	2026-10-17T23:34:03.9714653Z AssertionError: 'blocked' != 'passed'
Python test shard (release_scripts)	UNKNOWN STEP	2026-10-17T23:34:03.9716775Z FAIL: test_pre_5j_dependency_freshness_without_live_check_keeps_benchmark_blocked (python.tests.test_release_scripts.ReleaseScriptTests.test_pre_5j_dependency_freshness_without_live_check_keeps_benchmark_blocked)
Python test shard (release_scripts)	UNKNOWN STEP	2026-10-17T23:34:03.9720505Z AssertionError: 'blocked' != 'passed'
Python test shard (release_scripts)	UNKNOWN STEP	2026-10-17T23:34:03.9723216Z   "command": "python scripts/run_python_test_shard.py --shard release_scripts",
Python test shard (release_scripts)	UNKNOWN STEP	2026-10-17T23:34:03.9724657Z   "failure_count": 2,
Python test shard (release_scripts)	UNKNOWN STEP	2026-10-17T23:34:04.0107630Z ##[error]Process completed with exit code 1.
```
- Check annotations:
```json
[
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/4639d3ce5d6ec9a0934e93783b12ecf965500a4c/.github",
    "start_line": 62,
    "start_column": null,
    "end_line": 62,
    "end_column": null,
    "annotation_level": "failure",
    "title": "",
    "message": "Process completed with exit code 1.",
    "raw_details": ""
  },
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/4639d3ce5d6ec9a0934e93783b12ecf965500a4c/.github",
    "start_line": 1,
    "start_column": null,
    "end_line": 1,
    "end_column": null,
    "annotation_level": "notice",
    "title": "",
    "message": "\"The ubuntu-latest label will migrate to Ubuntu 26 beginning October 19, 2026. For more information, see https://github.com/actions/runner-images/issues/14748\"",
    "raw_details": ""
  }
]
```

### Native Python wheel (py310_ubuntu)

- Check: [Native Python wheel (py310_ubuntu)](https://github.com/depsilon/shardloom/actions/runs/39078218406/job/117529680259)
- Source head: `4639d3ce5d6ec9a0934e93783b12ecf965500a4c`; Actions run head: `4639d3ce5d6ec9a0934e93783b12ecf965500a4c`; job conclusion: `failure`.
- Failing command: `python -B -m unittest discover -s scripts -p test_python_license_bundle.py -v`.
- Raw log: [/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/dependency-patch-failure-logs-783/pr-1569-run-39078218406-job-117529680259-native-python-wheel-py310_ubuntu.log](dependency-patch-failure-logs-783/pr-1569-run-39078218406-job-117529680259-native-python-wheel-py310_ubuntu.log) (96376 bytes; SHA-256 `316a9cc46d90f1387b3386c7a3d14e58dc168ec85bdf9a9578db846983d55d15`).
- Diagnostic excerpt (specific_failure_detail_in_log):
```text
Native Python wheel (py310_ubuntu)	UNKNOWN STEP	2026-10-17T23:19:11.3267725Z ERROR: test_checked_in_bundle_covers_every_locked_registry_package (test_python_license_bundle.PythonLicenseBundleTests)
Native Python wheel (py310_ubuntu)	UNKNOWN STEP	2026-10-17T23:19:11.3270161Z Traceback (most recent call last):
Native Python wheel (py310_ubuntu)	UNKNOWN STEP	2026-10-17T23:19:11.3278648Z     raise ValueError("notice bundle does not exactly cover the registry lockfile")
Native Python wheel (py310_ubuntu)	UNKNOWN STEP	2026-10-17T23:19:11.3279199Z ValueError: notice bundle does not exactly cover the registry lockfile
Native Python wheel (py310_ubuntu)	UNKNOWN STEP	2026-10-17T23:19:11.3434595Z ##[error]Process completed with exit code 1.
Native Python wheel (py310_ubuntu)	UNKNOWN STEP	2026-10-17T23:19:11.5039052Z ##[error]No files were found with the provided path: /home/runner/work/_temp/native-python-h8lo0ifr/build.json
```
- Check annotations:
```json
[
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/4639d3ce5d6ec9a0934e93783b12ecf965500a4c/.github",
    "start_line": 32,
    "start_column": null,
    "end_line": 32,
    "end_column": null,
    "annotation_level": "failure",
    "title": "",
    "message": "No files were found with the provided path: /home/runner/work/_temp/native-python-h8lo0ifr/build.json\n/home/runner/work/_temp/native-python-h8lo0ifr/proof/report.json\n/home/runner/work/_temp/native-python-h8lo0ifr/proof/integration.json\n/home/runner/work/_temp/native-python-h8lo0ifr/proof/*.log\n/home/runner/work/_temp/native-python-h8lo0ifr/proof/dist/*.whl. No artifacts will be uploaded.",
    "raw_details": ""
  },
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/4639d3ce5d6ec9a0934e93783b12ecf965500a4c/.github",
    "start_line": 40,
    "start_column": null,
    "end_line": 40,
    "end_column": null,
    "annotation_level": "failure",
    "title": "",
    "message": "Process completed with exit code 1.",
    "raw_details": ""
  }
]
```

### Native Python wheel (py313_macos)

- Check: [Native Python wheel (py313_macos)](https://github.com/depsilon/shardloom/actions/runs/39078218406/job/117529680125)
- Source head: `4639d3ce5d6ec9a0934e93783b12ecf965500a4c`; Actions run head: `4639d3ce5d6ec9a0934e93783b12ecf965500a4c`; job conclusion: `failure`.
- Failing command: `python -B -m unittest discover -s scripts -p test_python_license_bundle.py -v`.
- Raw log: [/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/dependency-patch-failure-logs-783/pr-1569-run-39078218406-job-117529680125-native-python-wheel-py313_macos.log](dependency-patch-failure-logs-783/pr-1569-run-39078218406-job-117529680125-native-python-wheel-py313_macos.log) (96507 bytes; SHA-256 `db663aba60cb371258dbfe2189072adc60c65ed52bae90bb05672ab888066a6e`).
- Diagnostic excerpt (specific_failure_detail_in_log):
```text
Native Python wheel (py313_macos)	UNKNOWN STEP	2026-10-17T23:17:48.5098600Z ERROR: test_checked_in_bundle_covers_every_locked_registry_package (test_python_license_bundle.PythonLicenseBundleTests.test_checked_in_bundle_covers_every_locked_registry_package)
Native Python wheel (py313_macos)	UNKNOWN STEP	2026-10-17T23:17:48.5100480Z Traceback (most recent call last):
Native Python wheel (py313_macos)	UNKNOWN STEP	2026-10-17T23:17:48.5110170Z     raise ValueError("notice bundle does not exactly cover the registry lockfile")
Native Python wheel (py313_macos)	UNKNOWN STEP	2026-10-17T23:17:48.5110610Z ValueError: notice bundle does not exactly cover the registry lockfile
Native Python wheel (py313_macos)	UNKNOWN STEP	2026-10-17T23:17:48.5234090Z ##[error]Process completed with exit code 1.
Native Python wheel (py313_macos)	UNKNOWN STEP	2026-10-17T23:17:48.6964630Z ##[error]No files were found with the provided path: /Users/runner/work/_temp/native-python-zeq7nd2p/build.json
```
- Check annotations:
```json
[
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/4639d3ce5d6ec9a0934e93783b12ecf965500a4c/.github",
    "start_line": 31,
    "start_column": null,
    "end_line": 31,
    "end_column": null,
    "annotation_level": "failure",
    "title": "",
    "message": "No files were found with the provided path: /Users/runner/work/_temp/native-python-zeq7nd2p/build.json\n/Users/runner/work/_temp/native-python-zeq7nd2p/proof/report.json\n/Users/runner/work/_temp/native-python-zeq7nd2p/proof/integration.json\n/Users/runner/work/_temp/native-python-zeq7nd2p/proof/*.log\n/Users/runner/work/_temp/native-python-zeq7nd2p/proof/dist/*.whl. No artifacts will be uploaded.",
    "raw_details": ""
  },
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/4639d3ce5d6ec9a0934e93783b12ecf965500a4c/.github",
    "start_line": 39,
    "start_column": null,
    "end_line": 39,
    "end_column": null,
    "annotation_level": "failure",
    "title": "",
    "message": "Process completed with exit code 1.",
    "raw_details": ""
  },
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/4639d3ce5d6ec9a0934e93783b12ecf965500a4c/.github",
    "start_line": 1,
    "start_column": null,
    "end_line": 1,
    "end_column": null,
    "annotation_level": "notice",
    "title": "",
    "message": "Due to capacity constraints, jobs targeting macOS arm64 runners may experience longer queue times.",
    "raw_details": ""
  }
]
```

### Native Python wheel (py313_ubuntu)

- Check: [Native Python wheel (py313_ubuntu)](https://github.com/depsilon/shardloom/actions/runs/39078218406/job/117529680142)
- Source head: `4639d3ce5d6ec9a0934e93783b12ecf965500a4c`; Actions run head: `4639d3ce5d6ec9a0934e93783b12ecf965500a4c`; job conclusion: `failure`.
- Failing command: `python -B -m unittest discover -s scripts -p test_python_license_bundle.py -v`.
- Raw log: [/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/dependency-patch-failure-logs-783/pr-1569-run-39078218406-job-117529680142-native-python-wheel-py313_ubuntu.log](dependency-patch-failure-logs-783/pr-1569-run-39078218406-job-117529680142-native-python-wheel-py313_ubuntu.log) (97251 bytes; SHA-256 `8192062fc82241201b3831600137b2d5fb1551173de6a4d8e8d5894a161954fa`).
- Diagnostic excerpt (specific_failure_detail_in_log):
```text
Native Python wheel (py313_ubuntu)	UNKNOWN STEP	2026-10-17T23:15:45.2647022Z ERROR: test_checked_in_bundle_covers_every_locked_registry_package (test_python_license_bundle.PythonLicenseBundleTests.test_checked_in_bundle_covers_every_locked_registry_package)
Native Python wheel (py313_ubuntu)	UNKNOWN STEP	2026-10-17T23:15:45.2648517Z Traceback (most recent call last):
Native Python wheel (py313_ubuntu)	UNKNOWN STEP	2026-10-17T23:15:45.2656222Z     raise ValueError("notice bundle does not exactly cover the registry lockfile")
Native Python wheel (py313_ubuntu)	UNKNOWN STEP	2026-10-17T23:15:45.2656805Z ValueError: notice bundle does not exactly cover the registry lockfile
Native Python wheel (py313_ubuntu)	UNKNOWN STEP	2026-10-17T23:15:45.2819102Z ##[error]Process completed with exit code 1.
Native Python wheel (py313_ubuntu)	UNKNOWN STEP	2026-10-17T23:15:45.4066383Z ##[error]No files were found with the provided path: /home/runner/work/_temp/native-python-i8e2yemd/build.json
```
- Check annotations:
```json
[
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/4639d3ce5d6ec9a0934e93783b12ecf965500a4c/.github",
    "start_line": 32,
    "start_column": null,
    "end_line": 32,
    "end_column": null,
    "annotation_level": "failure",
    "title": "",
    "message": "No files were found with the provided path: /home/runner/work/_temp/native-python-i8e2yemd/build.json\n/home/runner/work/_temp/native-python-i8e2yemd/proof/report.json\n/home/runner/work/_temp/native-python-i8e2yemd/proof/integration.json\n/home/runner/work/_temp/native-python-i8e2yemd/proof/*.log\n/home/runner/work/_temp/native-python-i8e2yemd/proof/dist/*.whl. No artifacts will be uploaded.",
    "raw_details": ""
  },
  {
    "path": ".github",
    "blob_href": "https://github.com/depsilon/shardloom/blob/4639d3ce5d6ec9a0934e93783b12ecf965500a4c/.github",
    "start_line": 40,
    "start_column": null,
    "end_line": 40,
    "end_column": null,
    "annotation_level": "failure",
    "title": "",
    "message": "Process completed with exit code 1.",
    "raw_details": ""
  }
]
```

## Deduplication and coverage

Each run/job log is stored once by `runId/jobId`; every failed PR check remains a separate mapping. All 12 failed checks have an exact run ID, job ID, URL, source SHA, matching Actions run SHA, log file, and retrieved annotations. The log files contain the available complete failed logs, within the configured bound.

