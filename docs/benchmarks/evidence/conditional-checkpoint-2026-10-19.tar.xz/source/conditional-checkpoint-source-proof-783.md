# Conditional checkpoint source proof 783

## Checkpoint and source manifest

- Checkpoint: f95490279ce06a91b27d0dc44a3b9ecf41b1d0d6; compared with 99f4b93bd8043699704578f8a637fab5bbae922a (origin/main at inventory time).
- Manifest: /Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo/docs/benchmarks/evidence/compact-index-acceptance-source-764.json; schema shardloom.compact_index_public_source.v1, source commit 89f56e360dc8dc0af1255f5c200c713b90107291, 2217 accepted source entries, 282897 bytes, SHA-256 021867bd6eb39bcc77e9285106249e214fa92e2b4cf6d0f7b88967e12d23f000.
- Git object comparison at checkpoint: 2217 matches, 0 mismatches, 0 missing. JSON lists every matched path with accepted and checkpoint SHA-256; mismatch and missing arrays are explicit.
- Dirty checkout files were excluded; no working-tree source contents were used.

## Added or changed Rust/Python/Cargo files

The complete diff list and each manifest binding appear in JSON. Production source/build files: 8 Rust files, all bound to the accepted source map; no Python or Cargo files. The full two-tree diff also adds 10 Python evidence-support tools; those are listed separately and are unbound by the accepted-source map.

## Portable packet and closeout validations

- Portable packet: /Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo/docs/benchmarks/evidence/compact-index-portable-765.json; recorded status accepted_candidate_evidence_packet, production accepted True, all members reopened True, 17113 members. Archive, manifest, source lineage, and claim limits are copied into JSON.
- Independent reopen: /Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo/docs/benchmarks/evidence/compact-index-packet-verification-766.json; recorded status passed, all members/originals reopened True, accepted source files unchanged 2217. Timing fields are omitted.
- Source closeout: /Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo/docs/benchmarks/evidence/compact-index-closeout-source-766.json; recorded status passed, accepted source count 2217, contents unchanged True, whitespace passed, native runs repeated False. Raw validation fields and evidence references are in JSON.

## Repository reference checks

- CI Rust baseline in /Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo/.github/workflows/ci.yml: cargo fmt --all -- --check; cargo clippy --workspace --all-targets -- -D warnings; cargo test --workspace --all-targets.
- scripts/check_release_readiness.py records those Rust gates and python scripts/check_golden_workflows.py among release checks.
- Adjacent evidence verifier: /Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo/docs/benchmarks/evidence/verify_rematerialization_closeout_780.py. These are reference contracts, not commands rerun for this proof.

No builds, native tests, or queries were run; no external writes were made.

