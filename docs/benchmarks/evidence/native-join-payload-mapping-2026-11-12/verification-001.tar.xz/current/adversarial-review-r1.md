# Join payload mapping: source review before scoring

Reviewed source: `e10fc31e4ada819038711dd3a4658c3ad10a91f0` plus the candidate
snapshot `0304c24e95c4d1bc963a6ce1d16fff58b2bc9a7aa16890ef50483fd44c151024`.

## Eligibility and alias semantics

`map_join_payloads` proves two ordinary inner/left joins through direct projections
before annotating either. The prefix is 1..16384 and sorting must validate all values.
Runtime mapping requires a complete ordinary insert-built `RowIndex` without
duplicate links. Duplicate admission is per edge; ASOF and conditions stop the
chain, and spill uses the original compact wrapper. `source_name` canonicalizes
duplicate source projections and join output aliases so ranking and later join
keys stay excluded. Prepared tests cover aliases, reorder, duplicates, hidden
next keys, all join pairs, zero/one/two active edges and every declared barrier.
No unresolved finding remains in this scope.

## Validation and publication order

One field-major flush loop remains. A retained mapped column validates the entire
selected domain before `DictArray::try_new` and publication. Dropped fields still
call `validate_column`; all-missing build sides retain typed defaults. Regression
tests compare all four mapped/compact edge combinations and parent masks. A late
selected invalid row beyond the retained prefix still errors before successful
completion. File source validation remains earlier and unchanged. No new error
waiver was introduced.

## Owner and reservation lifetime

The selection dictionary retains original payload and index owners plus one
admitted wrapper/schema credit. `mapping_source` reserves replacement chunk slots
and offsets while temporary `ReservedVec` credit remains live. The new offset
child and raw buffer retain the same Arc credit; escaping either cannot refund it
early. Sparse selection tests deliberately pin a large backing allocation, count
it once, and prove shutdown, clone and final release. Cancellation, memory denial,
consumer failure, spill cleanup and next-probe source release are covered. Payload
buffer measurements do not establish lower whole-process memory or absent provider
scratch. No unresolved lifetime finding remains in the reviewed scope.

## Independent CI cleanup correction

Two actual inventory checks failed when a macOS orphan cleanup signal raised
`PermissionError` and masked the original child-leak refusal. The correction keeps
the original error and receipt, records cleanup errors, bounds both direct-child
waits, and refuses to accept a previously passing partition when cleanup fails.
Aggregation also rejects cleanup errors after a status-only rewrite. The new
deterministic injection fails against the original runner and passes with the
correction. All 20 CI-runner tests pass. This change affects two CI scripts only;
the benchmark supervisor and native runtime are unchanged by this correction.
It will be retained independently of the join mapping score, as declared before
any candidate benchmark query executes.

The same source passed formatting, default and native strict lint, 3,323 default
tests, 7,108 native tests, all 102 attribution fixtures, actual CI discovery of
4,151 tests with 36 declared ignored tests, and the final diagnostic verifier.
No scored candidate query has executed. The fresh release build and installed
package proof remain required before scoring. Performance acceptance is still
unproven; the fixed 940-case cohort and strict total-engine-time rule decide it.
No post-score tuning or routine repeats are authorized by this review.
