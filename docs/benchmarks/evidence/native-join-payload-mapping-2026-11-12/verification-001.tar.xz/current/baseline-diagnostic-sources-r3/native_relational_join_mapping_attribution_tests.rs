//! Draft native two-join/ranking attribution, not yet integrated or executed.
//!
//! This measures logical output, compact payload buffers and mapped backing
//! separately. It retains no intermediate samples in the pipeline lifetime test.

use super::*;
use crate::{
    local_primitives::{
        collect::JsonRows,
        native_payload::CopyPolicy,
        native_relational_sort::{self as ordering, StreamingPrefix},
    },
    relational_query::{VortexRelationalNullOrder, VortexRelationalOrderKey},
    resident_memory_source::{MemoryColumn, MemoryColumnValues, ResidentMemorySource},
};
use serde::Serialize;
use serde_json::{Value as Json, json};
use shardloom_core::ColumnRef;
use shardloom_exec::live_memory::MemoryLease;
use std::sync::Weak;
use vortex::array::arrays::Dict;

#[derive(Clone, Copy, Debug, Serialize)]
enum Payload {
    Narrow,
    Wide,
    Rich,
}

#[derive(Clone, Copy, Debug, Serialize)]
struct Case {
    products_first: bool,
    entity_left: bool,
    product_left: bool,
    payload: Payload,
    rows: usize,
    batch_rows: usize,
    cap: usize,
}

#[derive(Default, Debug, Serialize)]
struct Stage {
    rows: u64,
    batches: u64,
    logical_cells: u64,
    materialized_payload_cells: u64,
    materialized_payload_buffer_bytes: u64,
    mapped_payload_cells: u64,
    mapped_referenced_buffer_bytes: u64,
}

impl Stage {
    fn record(&mut self, array: &ArrayRef) -> Result<()> {
        self.rows += array.len() as u64;
        self.batches += 1;
        let fields = array.dtype().as_struct_fields();
        self.logical_cells += (array.len() * fields.nfields()) as u64;
        for name in fields.names().iter() {
            let column = logical_field_from_native_array(array, name.as_ref())?;
            if !matches!(
                column.dtype(),
                DType::Utf8(_) | DType::Binary(_) | DType::List(..) | DType::Struct(..)
            ) {
                continue;
            }
            if column.is::<Dict>() {
                self.mapped_payload_cells += column.len() as u64;
                // Includes referenced backing; deliberately not called copied bytes.
                self.mapped_referenced_buffer_bytes += column.nbytes();
            } else {
                self.materialized_payload_cells += column.len() as u64;
                // The current join builder compacts every retained payload.
                // Count its output buffers, not provider scratch or all writes.
                self.materialized_payload_buffer_bytes += column.nbytes();
            }
        }
        Ok(())
    }
}

#[derive(Debug, Serialize)]
#[allow(clippy::struct_excessive_bools)] // Independent verified lifecycle obligations, not runtime modes.
struct Report {
    case: Case,
    stages: [Stage; 2],
    ranked_output_rows: usize,
    ranked_output_buffer_bytes: u64,
    probe_batches_released: usize,
    build_batches_released: usize,
    peak_credited_bytes: u64,
    probe_sources_released_before_next_batch: bool,
    build_sources_released_after_join_teardown: bool,
    complete_results_verified: bool,
    complete_schema_verified: bool,
    final_output_readable_after_session_close: bool,
    final_output_credits_released: bool,
    whole_process_memory_claim: bool,
    actual: Vec<Json>,
}

fn fact(id: usize, payload: Payload) -> Json {
    let number = i64::try_from(id).unwrap();
    let mut row = json!({
        "id":number,
        "e":(!id.is_multiple_of(29)).then_some((number * 17 + 43) % 137),
        "p":(!id.is_multiple_of(31)).then_some((number * 7 + 23) % 71),
        "v":(!id.is_multiple_of(11)).then_some((number * 13 + 19) % 101 - 50)
    });
    if !matches!(payload, Payload::Narrow) {
        row["t"] = if id.is_multiple_of(23) {
            Json::Null
        } else {
            json!(format!("μλ:{id:05}:{}", "AbÇ".repeat(32)))
        };
    }
    if matches!(payload, Payload::Wide) {
        for name in ["t2", "t3", "t4"] {
            row[name] = json!(format!("{name}:{id}:{}", "猫\0xy".repeat(16)));
        }
    }
    if matches!(payload, Payload::Rich) {
        row["items"] = if id.is_multiple_of(7) {
            Json::Null
        } else if id.is_multiple_of(5) {
            json!([])
        } else {
            json!([number, null, -number])
        };
        row["detail"] = if id.is_multiple_of(13) {
            Json::Null
        } else {
            json!({"score":(!id.is_multiple_of(3)).then_some(number-41), "label":format!("λ\0猫:{id}")})
        };
    }
    row
}

fn dimensions(products: bool) -> Vec<Json> {
    let mut rows = vec![json!({"k":null,"code":777,"label":"unmatchable-null"})];
    for key in (0..if products { 61_i64 } else { 127 }).rev() {
        rows.push(json!({"k":key,"code":(key % 17 != 0).then_some(key % 7),
            "label":format!("{}:{key}:{}",if products { "product" } else { "entity" },"αλ".repeat(12))}));
    }
    // Ordinary equality ignores both NULL keys. The matchable domain is unique.
    rows.push(json!({"k":null,"code":888,"label":"second-unmatchable-null"}));
    rows
}

fn source(
    session: &ResidentVortexSession,
    rows: &[Json],
    payload: Payload,
    dimension: Option<bool>,
) -> Result<ResidentMemorySource> {
    let integer_names = if dimension.is_some() {
        vec!["k", "code"]
    } else {
        vec!["id", "e", "p", "v"]
    };
    let integer_values: Vec<Vec<Option<i64>>> = integer_names
        .iter()
        .map(|name| rows.iter().map(|row| row[*name].as_i64()).collect())
        .collect();
    let mut columns: Vec<_> = integer_names
        .iter()
        .zip(&integer_values)
        .map(|(name, values)| MemoryColumn {
            name,
            values: MemoryColumnValues::Int64(values),
        })
        .collect();
    let text_names = if dimension.is_some() {
        if matches!(payload, Payload::Narrow) {
            vec![]
        } else {
            vec!["label"]
        }
    } else {
        match payload {
            Payload::Narrow => vec![],
            Payload::Wide => vec!["t", "t2", "t3", "t4"],
            Payload::Rich => vec!["t"],
        }
    };
    let text_values: Vec<Vec<Option<&str>>> = text_names
        .iter()
        .map(|name| rows.iter().map(|row| row[*name].as_str()).collect())
        .collect();
    columns.extend(
        text_names
            .iter()
            .zip(&text_values)
            .map(|(name, values)| MemoryColumn {
                name,
                values: MemoryColumnValues::Utf8(values),
            }),
    );
    let items: Vec<_> = rows.iter().map(|row| row["items"].to_string()).collect();
    let item_values: Vec<_> = items.iter().map(|value| Some(value.as_str())).collect();
    let details: Vec<_> = rows.iter().map(|row| row["detail"].to_string()).collect();
    let detail_values: Vec<_> = details.iter().map(|value| Some(value.as_str())).collect();
    if dimension.is_none() && matches!(payload, Payload::Rich) {
        columns.extend([
            MemoryColumn { name:"items", values:MemoryColumnValues::TypedJson {
                dtype_json:r#"{"List":[{"Primitive":["i64",true]},true]}"#, values:&item_values } },
            MemoryColumn { name:"detail", values:MemoryColumnValues::TypedJson {
                dtype_json:r#"{"Struct":[{"names":["score","label"],"dtypes":[{"Primitive":["i64",true]},{"Utf8":false}]},true]}"#,
                values:&detail_values } },
        ]);
    }
    ResidentMemorySource::from_batch_columns(session, &columns)
}

fn fields(source: &ResidentMemorySource) -> Vec<(String, DType)> {
    let fields = source.dtype().as_struct_fields();
    fields
        .names()
        .iter()
        .zip(fields.fields())
        .map(|(name, dtype)| (name.to_string(), dtype))
        .collect()
}

fn join_spec(case: Case, first: bool, input: &[(String, DType)]) -> Spec {
    let products = if first {
        case.products_first
    } else {
        !case.products_first
    };
    let consumed = if products { "p" } else { "e" };
    let mut fields: Vec<_> = input
        .iter()
        .filter(|(name, _)| name != consumed)
        .cloned()
        .collect();
    let mut columns: Vec<_> = fields
        .iter()
        .map(|(name, _)| (Side::Left, name.clone()))
        .collect();
    fields.push((
        if products { "c" } else { "r" }.into(),
        DType::Primitive(PType::I64, Nullability::Nullable),
    ));
    columns.push((Side::Right, "code".into()));
    if !matches!(case.payload, Payload::Narrow) {
        fields.push((
            if products { "ct" } else { "rt" }.into(),
            DType::Utf8(Nullability::Nullable),
        ));
        columns.push((Side::Right, "label".into()));
    }
    Spec {
        kind: if if products {
            case.product_left
        } else {
            case.entity_left
        } {
            Kind::Left
        } else {
            Kind::Inner
        },
        asof: None,
        left_keys: vec![consumed.into()],
        right_keys: vec!["k".into()],
        right_key_fields: vec![(
            "k".into(),
            DType::Primitive(PType::I64, Nullability::Nullable),
        )],
        fields,
        columns,
        retained: None,
        condition: None,
    }
}

fn reference(case: Case) -> (Vec<Json>, [u64; 2]) {
    let entities = dimensions(false);
    let products = dimensions(true);
    let mut result = Vec::new();
    let mut stages = [0_u64; 2];
    for start in (0..case.rows).step_by(case.batch_rows) {
        for id in (start..(start + case.batch_rows).min(case.rows)).rev() {
            let fact = fact(id, case.payload);
            let matching = |product: bool| {
                let key = fact[if product { "p" } else { "e" }].as_i64();
                let table = if product { &products } else { &entities };
                let found: Vec<_> = table
                    .iter()
                    .filter(|row| key.is_some() && row["k"].as_i64() == key)
                    .collect();
                assert!(found.len() <= 1);
                if found.is_empty()
                    && if product {
                        case.product_left
                    } else {
                        case.entity_left
                    }
                {
                    vec![None]
                } else {
                    found.into_iter().map(Some).collect()
                }
            };
            let first = matching(case.products_first);
            let second = matching(!case.products_first);
            stages[0] += first.len() as u64;
            stages[1] += (first.len() * second.len()) as u64;
            for left in &first {
                for right in &second {
                    let mut row = fact.as_object().unwrap().clone();
                    row.remove("e");
                    row.remove("p");
                    for (product, matched) in
                        [(case.products_first, left), (!case.products_first, right)]
                    {
                        row.insert(
                            if product { "c" } else { "r" }.into(),
                            matched.map_or(Json::Null, |v| v["code"].clone()),
                        );
                        if !matches!(case.payload, Payload::Narrow) {
                            row.insert(
                                if product { "ct" } else { "rt" }.into(),
                                matched.map_or(Json::Null, |v| v["label"].clone()),
                            );
                        }
                    }
                    result.push(Json::Object(row));
                }
            }
        }
    }
    result.sort_by(|left, right| {
        left["v"]
            .as_i64()
            .cmp(&right["v"].as_i64())
            .then_with(|| left["id"].as_i64().cmp(&right["id"].as_i64()))
    });
    result.truncate(case.cap);
    (result, stages)
}

fn json_rows(array: &ArrayRef, context: &NativeExecutionContext<'_>) -> Result<Vec<Json>> {
    let mut sink = JsonRows::new(context.memory(), 8 << 20, false)?;
    sink.append_native(array, context)?;
    serde_json::from_str(sink.finish()?.value()).map_err(vortex_error)
}

fn verify_schema(array: &ArrayRef, wanted: &[(String, DType)]) {
    assert_eq!(array.dtype().nullability(), Nullability::NonNullable);
    let actual = array.dtype().as_struct_fields();
    assert_eq!(actual.nfields(), wanted.len());
    for (index, (name, dtype)) in wanted.iter().enumerate() {
        assert_eq!(actual.names()[index].as_ref(), name);
        assert_eq!(actual.field(name).as_ref(), Some(dtype));
    }
}

#[allow(clippy::too_many_lines)] // Input, operators, output and release witnesses form one diagnostic.
fn exercise(case: Case) -> Result<Report> {
    assert!(case.batch_rows > 0 && case.batch_rows <= 2048 && case.cap > 0 && case.cap <= 16384);
    let (expected, wanted_stages) = reference(case);
    let session = ResidentVortexSession::new(64 << 20, 1)?;
    let memory = session.memory().clone();
    let cancellation = CancellationToken::default();
    let template = source(&session, &[], case.payload, None)?;
    let first_spec = join_spec(case, true, &fields(&template));
    drop(template);
    let second_spec = join_spec(case, false, &first_spec.fields);
    let sort_spec = ordering::Spec {
        fields: second_spec.fields.clone(),
        names: vec!["v".into(), "id".into()],
        keys: ["v", "id"]
            .into_iter()
            .map(|name| VortexRelationalOrderKey {
                column: ColumnRef::new(name).unwrap(),
                descending: false,
                nulls: Some(VortexRelationalNullOrder::First),
            })
            .collect(),
        copy_policy: CopyPolicy::ValidateValues,
        unobserved_fields: vec![],
    };
    let mut stages = [Stage::default(), Stage::default()];
    let mut probe_witnesses: Vec<Weak<MemoryLease>> = Vec::new();
    let mut build_witnesses: Vec<Weak<MemoryLease>> = Vec::new();
    let mut retained = Vec::new();
    let mut actual = Vec::new();
    let mut output_bytes = 0;
    let execution = session.with_native_execution_context(&cancellation, |context| {
        let mut first = Join::new(&first_spec, &memory)?;
        let mut second = Join::new(&second_spec, &memory)?;
        for (join, products) in [
            (&mut first, case.products_first),
            (&mut second, !case.products_first),
        ] {
            for rows in dimensions(products).chunks(17) {
                let source = source(&session, rows, case.payload, Some(products))?;
                build_witnesses.push(source.batch_release_witness()?);
                let array = source.batch_array(context)?.clone();
                drop(source);
                join.build(array, context, case.batch_rows)?;
            }
        }
        assert!(build_witnesses.iter().all(|w| w.strong_count() > 0));
        let mut sort = StreamingPrefix::try_new(&sort_spec, Some(case.cap), context)?.unwrap();
        for start in (0..case.rows).step_by(case.batch_rows) {
            assert!(probe_witnesses.iter().all(|w| w.strong_count() == 0));
            let rows: Vec<_> = (start..(start + case.batch_rows).min(case.rows))
                .rev()
                .map(|id| fact(id, case.payload))
                .collect();
            let source = source(&session, &rows, case.payload, None)?;
            probe_witnesses.push(source.batch_release_witness()?);
            let array = source.batch_array(context)?.clone();
            drop(source);
            first.consume(array, context, case.batch_rows, &mut |array| {
                verify_schema(&array, &first_spec.fields);
                stages[0].record(&array)?;
                second
                    .consume(array, context, case.batch_rows, &mut |array| {
                        verify_schema(&array, &second_spec.fields);
                        stages[1].record(&array)?;
                        sort.build(array, context).map(|_| ())
                    })
                    .map(|_| ())
            })?;
            assert_eq!(probe_witnesses.last().unwrap().strong_count(), 0);
            assert!(build_witnesses.iter().all(|w| w.strong_count() > 0));
        }
        sort.finish(context, case.batch_rows, &mut |array| {
            verify_schema(&array, &sort_spec.fields);
            output_bytes += array.nbytes();
            actual.extend(json_rows(&array, context)?);
            retained.push(array);
            Ok(())
        })?;
        drop(sort);
        drop(second);
        drop(first);
        assert!(build_witnesses.iter().all(|w| w.strong_count() == 0));
        Ok(())
    });
    if let Err(error) = execution {
        retained.clear();
        drop(session);
        assert_eq!(memory.snapshot().reserved_bytes, 0);
        return Err(error);
    }
    assert_eq!(actual, expected, "{case:?}");
    assert_eq!([stages[0].rows, stages[1].rows], wanted_stages);
    let peak = memory.snapshot().peak_reserved_bytes;
    drop(session);
    if !retained.is_empty() {
        assert!(memory.snapshot().reserved_bytes > 0);
    }
    let verifier = ResidentVortexSession::new(16 << 20, 1)?;
    verifier.with_native_execution_context(&CancellationToken::default(), |context| {
        let mut after_close = Vec::new();
        for array in &retained {
            after_close.extend(json_rows(array, context)?);
        }
        assert_eq!(after_close, expected);
        Ok(())
    })?;
    drop(verifier);
    let alias = retained.last().cloned();
    drop(retained);
    if alias.is_some() {
        assert!(memory.snapshot().reserved_bytes > 0);
    }
    drop(alias);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    Ok(Report {
        case,
        stages,
        ranked_output_rows: actual.len(),
        ranked_output_buffer_bytes: output_bytes,
        probe_batches_released: probe_witnesses.len(),
        build_batches_released: build_witnesses.len(),
        peak_credited_bytes: peak,
        probe_sources_released_before_next_batch: true,
        build_sources_released_after_join_teardown: true,
        complete_results_verified: true,
        complete_schema_verified: true,
        final_output_readable_after_session_close: true,
        final_output_credits_released: true,
        whole_process_memory_claim: false,
        actual,
    })
}

#[test]
fn successive_join_ranked_payloads_release_sources_and_match_independent_rows() {
    for payload in [Payload::Narrow, Payload::Wide, Payload::Rich] {
        for products_first in [false, true] {
            let report = exercise(Case {
                products_first,
                entity_left: true,
                product_left: false,
                payload,
                rows: 257,
                batch_rows: 17,
                cap: 31,
            })
            .unwrap();
            assert!(report.stages[1].rows > report.ranked_output_rows as u64);
        }
    }
}

#[test]
#[ignore = "opt-in complete internal join/ranking work-attribution matrix; no performance score"]
fn successive_join_ranked_payload_work_attribution_matrix() {
    let mut ordinal = 0;
    for products_first in [false, true] {
        for entity_left in [false, true] {
            for product_left in [false, true] {
                for payload in [Payload::Narrow, Payload::Wide, Payload::Rich] {
                    for rows in [0, 17, 257, 8191] {
                        let report = exercise(Case {
                            products_first,
                            entity_left,
                            product_left,
                            payload,
                            rows,
                            batch_rows: [17, 257, 2048][ordinal % 3],
                            cap: [1, 31, 1024][(ordinal / 3) % 3],
                        })
                        .unwrap();
                        println!(
                            "JOIN_RANKING_ATTRIBUTION {}",
                            serde_json::to_string(&report).unwrap()
                        );
                        ordinal += 1;
                    }
                }
            }
        }
    }
    assert_eq!(ordinal, 96);
}
