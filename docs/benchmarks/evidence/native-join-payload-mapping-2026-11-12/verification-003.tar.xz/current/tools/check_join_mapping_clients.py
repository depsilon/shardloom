"""Check declared join-mapping client construction without executing a query."""
import json
from pathlib import Path
import sys

J = Path('/Users/dylan/LocalData/shardloom/join-mapping-2026-11-11')
S = Path('/Users/dylan/LocalData/shardloom/shared-operator-state-2026-11-10')
E = Path('/Users/dylan/LocalData/shardloom/expanded-query-2026-11-03')
FROZEN = E / 'investigation-original-harness-r1'
assert Path(__file__).resolve() == J / 'tools/check_join_mapping_clients.py', 'unactivated draft cannot execute'
sys.path[:0] = [str(J / 'tools'), str(J / 'client'), str(S / 'window-tools-draft'),
    str(FROZEN / 'python/src'), str(FROZEN / 'benchmarks/traditional_analytics')]

import join_mapping_common as common
import join_mapping_worker as worker
from query_surface.adapters import relation_dataframe, relation_native, relation_sql
from query_surface.worker import load_native

import shardloom as sl

OUT = common.OUT
DEST = OUT / 'client-check-r1.json'
DECLARATION_CONTROLS = OUT / 'declaration-controls-r1.json'
REFERENCE_CONTROLS = OUT / 'reference-reader-controls-r1.json'
CASES = common.CLIENT / 'join_mapping_cases.py'
WORKER = common.CLIENT / 'join_mapping_worker.py'
assert __debug__ and not DEST.exists()


def checked_receipt(path, status):
    receipt = common.read(path)
    assert receipt['status'] == status
    if 'query_executions' in receipt:
        assert receipt['query_executions'] == 0
    sources = receipt['sources']
    assert isinstance(sources, dict) and sources
    resolved = {}
    for name, expected in sources.items():
        source = Path(name)
        if not source.is_absolute():
            source = OUT / source
        actual = common.content(source)
        assert actual == expected, f'control source identity changed: {source}'
        resolved[str(source)] = actual
    assert str(CASES) in resolved, 'control receipt does not bind the copied declarations module'
    return receipt, resolved


declaration_receipt, declaration_sources = checked_receipt(
    DECLARATION_CONTROLS, 'passed_draft_declaration_and_literal_reference_controls')
assert declaration_receipt['cases'] == 360
assert declaration_receipt['scenarios'] == 24
assert declaration_receipt['refusal_controls'] == 17
assert declaration_receipt['native_runtime_loaded'] is False
assert declaration_receipt['query_executions'] == 0

reader_receipt, reader_sources = checked_receipt(
    REFERENCE_CONTROLS, 'passed_draft_real_ipc_reference_transport')
records = {row['layout']: row for row in reader_receipt['records']}
assert len(reader_receipt['records']) == len(records) == 2
assert set(records) == {'sorted', 'shuffled'}
assert all(row['scenarios'] == 24 and row['source_rows'] == 29 and row['files_unchanged'] for row in records.values())
assert sum(row['hydration_refusals'] for row in records.values()) + reader_receipt['duplicate_id_refusals'] == 9
assert reader_receipt['native_query_executions'] == 0
assert reader_receipt['native_runtime_loaded'] is False
assert reader_receipt['comparison_engine_loaded'] is False
assert reader_receipt['source_fixture_removed'] is True

runtime, closeout = common.accepted_runtime()
cases = worker.declarations.declarations()
assert len(cases) == 360
assert len({row['id'] for row in cases}) == len(cases)
assert len({row['case_identity'] for row in cases}) == len(cases)
source_paths = {
    Path(__file__), CASES, WORKER, Path(common.__file__),
    Path(worker.__file__), common.CLOSEOUT, E/'frozen.json',
    common.T/'shared-window-closeout-r1.json', common.T/'candidate-protocol-r1.json',
    Path(runtime['binary']['path']), Path(runtime['library']['path']),
    DECLARATION_CONTROLS, REFERENCE_CONTROLS,
    *(Path(name) for name in declaration_sources), *(Path(name) for name in reader_sources),
}
old_root = '/Users/dylan/.codex/worktrees/native-post-110-optimization/shardloom-local-repo/'
frozen_harness = common.read(E/'frozen.json')['harness']
assert len(frozen_harness) == 65
for row in frozen_harness:
    assert row['path'].startswith(old_root)
    path = FROZEN/row['path'].removeprefix(old_root)
    assert common.content(path) == dict(bytes=row['generation']['bytes'], sha256=row['sha256'])
    source_paths.add(path)
source_paths.update((Path(common.previous.__file__), Path(common.old_proof.__file__),
    Path(common.old_proof.worker.__file__), Path(common.old_proof.worker.declarations.__file__)))
for module in tuple(sys.modules.values()):
    name = getattr(module, '__file__', None)
    if name:
        path = Path(name).resolve()
        if path.suffix == '.py' and path.is_relative_to(OUT.parent):
            source_paths.add(path)
before_sources = {str(path):common.content(path) for path in sorted(source_paths)}
native = load_native(Path(runtime['library']['path']))
frozen_dependencies = {}
for module in tuple(sys.modules.values()):
    module_path = getattr(module, '__file__', None)
    if module_path:
        path = Path(module_path).resolve()
        if path.is_file() and path.is_relative_to(FROZEN):
            frozen_dependencies[str(path)] = common.content(path)
client = None
result = dict(status='failed', query_executions=0, declarations=0,
    native_library_loaded=True, client_backend_created=False,
    worker_process_started=False, active_process_count=0,
    declaration_controls=dict(path=str(DECLARATION_CONTROLS), identity=common.content(DECLARATION_CONTROLS),
        inputs_only=True, cases=declaration_receipt['cases'], scenarios=declaration_receipt['scenarios'],
        refusal_controls=declaration_receipt['refusal_controls'], sources=declaration_sources),
    reference_reader_controls=dict(path=str(REFERENCE_CONTROLS), identity=common.content(REFERENCE_CONTROLS),
        inputs_only=True, records=reader_receipt['records'], duplicate_id_refusals=reader_receipt['duplicate_id_refusals'],
        native_query_executions=reader_receipt['native_query_executions'], sources=reader_sources),
    accepted_runtime=dict(runtime=runtime, closeout=common.content(common.CLOSEOUT),
        predecessor_closeout=common.content(common.T / 'shared-window-closeout-r1.json'),
        runtime_protocol=common.content(common.T / 'candidate-protocol-r1.json'),
        source_fingerprint_sha256=closeout['source_fingerprint_sha256']),
    frozen_client_dependencies=frozen_dependencies)
try:
    client = sl.ShardLoomClient(binary=runtime['binary']['path'], transport='native',
        use_persistent_worker=False, memory_bytes=1 << 30, max_parallelism=1, timeout=60)
    path_suffix = {'parquet': '.parquet', 'vortex': '.vortex', 'arrow-ipc': '.arrow'}
    for case in cases:
        plan = worker.declarations.validate(case)
        suffix = path_suffix[case['native_format']]
        sources = {name: [f'/declared-only/{name}{suffix}'] for name in ('fact', 'entities', 'products')}
        sql = relation_sql(plan, sources)
        assert isinstance(sql, str) and sql
        native_relation = relation_native(plan, sources, native)
        assert type(native_relation) is native.Relation
        frame = relation_dataframe(plan, sources, sl, client)
        assert frame.client is client
        assert client._native_backend is None
        assert client._worker_process is None and not client._active_processes
    result.update(status='passed_declaration_and_reference_controls', declarations=len(cases),
        query_executions=0, client_backend_created=False, worker_process_started=False,
        active_process_count=0, construction_surfaces=['sql', 'typed_relation', 'dataframe'],
        source_paths='declared_only_nonexistent_paths_matching_native_format',
        declaration_controls_are_inputs_only=True, reference_reader_controls_are_inputs_only=True)
except BaseException as error:
    result['error'] = type(error).__name__ + ': ' + str(error)
    raise
finally:
    if client is not None:
        client.close()
        assert client._native_backend is None
        assert client._worker_process is None and not client._active_processes
    changed = [name for name, expected in before_sources.items() if common.content(Path(name)) != expected]
    result['sources'] = before_sources
    result['source_bindings_unchanged'] = not changed
    result['frozen_client_files'] = 65
    if changed:
        result.update(status='failed', changed_sources=changed, error='client source changed during construction')
    with DEST.open('x') as output:
        json.dump(result, output, indent=2, allow_nan=False)
        output.write('\n')
    assert not changed, changed
print(json.dumps({key: result[key] for key in ('status', 'declarations', 'query_executions',
    'client_backend_created', 'worker_process_started')}))
