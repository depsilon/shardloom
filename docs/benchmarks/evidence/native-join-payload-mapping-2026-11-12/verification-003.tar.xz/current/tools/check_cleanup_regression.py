"""Prove the injected cleanup regression fails on the preserved original runner."""
import hashlib
import io
import json
from pathlib import Path
import sys
import types
import unittest

OUT = Path(__file__).resolve().parents[1]
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
assert __debug__ and OUT == Path('/Users/dylan/LocalData/shardloom/join-mapping-2026-11-11')
sys.path.insert(0, str(ROOT / 'scripts'))
import test_ci_native_tests as tests


def content(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    output = OUT / 'ci-cleanup-regression-r1.json'
    assert not output.exists()
    original_guard = OUT / 'candidate-ci-verification-r2.json'
    guard = json.loads(original_guard.read_text())
    assert guard['status'] == 'failed' and guard['process_group_drained'] and guard['direct_child_reaped']
    identity = guard['build_sources']['scripts/ci_native_tests.py']
    original = OUT / 'source-blobs' / identity['sha256']
    assert content(original) == identity
    log = original_guard.with_suffix('.log')
    assert content(log)['sha256'] == guard['log_sha256']
    assert 'PermissionError: [Errno 1] Operation not permitted' in log.read_text()
    old = types.ModuleType('preserved_ci_native_tests')
    old.__file__ = str(original)
    exec(compile(original.read_bytes(), str(original), 'exec'), old.__dict__)
    tests.native = old
    case = tests.ProcessAndEvidenceTests('test_signal_error_preserves_original_leak_refusal_and_receipt')
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(unittest.TestSuite([case]))
    observed = stream.getvalue()
    print(observed)
    assert result.testsRun == 1 and len(result.errors) == 1
    assert not result.failures and not result.skipped and not result.wasSuccessful()
    assert 'PermissionError: injected final signal denial' in observed
    record = dict(status='passed_regression_control', native_query_executions=0,
        original_runner=identity, original_failure_guard=content(original_guard),
        original_failure_log=content(log), regression_tests=content(Path(tests.__file__)),
        original_runner_rejects_regression=True, expected_test_errors=1,
        observation_sha256=hashlib.sha256(observed.encode()).hexdigest())
    with output.open('x') as target:
        json.dump(record, target, indent=2); target.write('\n')
    print(json.dumps(record))


if __name__ == '__main__':
    main()
