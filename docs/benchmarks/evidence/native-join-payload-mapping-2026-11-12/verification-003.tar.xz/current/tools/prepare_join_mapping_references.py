"""Draft independent reference preparation; activation requires the closed predecessor."""
from contextlib import closing
import hashlib
import json
from pathlib import Path
import sqlite3
import sys

from join_mapping_common import (CLIENT, E, FROZEN, OUT, REFERENCE, SELECTION,
    accepted_runtime, content, digest, inputs_and_client, read, worker)
from join_mapping_reference_inputs import Inputs
from query_surface.evidence import identity
from query_surface.expanded_freeze import pack, unpack
from query_surface.expanded_run import verify
from query_surface.semantics import ResultContract, compare, result_from_record, result_record
from resources import BenchmarkGuard

KEY_PARTS = ('entity_kind', 'product_kind', 'population', 'limit', 'descending', 'order_key')


def main():
    assert __debug__ and OUT == Path('/Users/dylan/LocalData/shardloom/join-mapping-2026-11-11')
    assert not REFERENCE.parent.exists()
    _, closeout = accepted_runtime()
    _, inputs, _, frozen, _ = inputs_and_client()
    selection = read(SELECTION)
    rows = selection['cases']
    new = [row for row in rows if row['kind'] == 'composition']
    assert len(rows) == 940 and len(new) == 360
    assert all(row['case']['join_mapping_version'] == 1 for row in new)
    for row in new:
        worker.declarations.validate(row['case'])
    checked_path = OUT / 'client-check-r1.json'
    checked = read(checked_path)
    assert checked['status'] == 'passed_declaration_and_reference_controls'
    assert checked['declarations'] == 360 and checked['query_executions'] == 0
    for path, expected in checked['sources'].items():
        assert content(Path(path)) == expected
    paths = [Path(__file__), SELECTION, checked_path,
        OUT/'tools/join_mapping_common.py', OUT/'tools/join_mapping_reference_inputs.py',
        CLIENT/'join_mapping_cases.py', CLIENT/'join_mapping_worker.py']
    proof = {str(path): identity(path) for path in paths}
    result = dict(schema='shardloom.join_mapping_reference.v1', status='failed',
        selection=identity(SELECTION), generator=identity(Path(__file__)),
        accepted_runtime_source_fingerprint_sha256=closeout['source_fingerprint_sha256'],
        independent_boundary='Arrow input transport, Python equality and bounded ranking, complete selected payloads',
        native_query_executions=0, native_runtime_loaded=False,
        comparison_engine_benchmark_runs=0, profiles={}, rows=[])
    REFERENCE.parent.mkdir()
    try:
        with BenchmarkGuard(REFERENCE.parent, binary=Path('shardloom'), memory_gb=2) as guard, closing(sqlite3.connect(REFERENCE)) as db:
            db.execute('PRAGMA journal_mode=DELETE')
            db.execute('CREATE TABLE expected (id TEXT PRIMARY KEY, identity TEXT NOT NULL, value BLOB NOT NULL)')
            for profile in ('smoke', 'holdout', 'primary', 'scale'):
                group = [row for row in new if row['case']['profile'] == profile]
                assert len(group) == 90
                source = Inputs(inputs, profile, guard)
                entities = worker.declarations.unique_dimension(source.rows('entities',
                    ('entity_id','region','entity_label')), 'entities')
                products = worker.declarations.unique_dimension(source.rows('products',
                    ('product_id','product_category')), 'products')
                ranked = {}
                scenarios = {row['case']['declaration']['scenario']['name']:
                    row['case']['declaration']['scenario'] for row in group}
                assert len(scenarios) == 24
                for scenario in scenarios.values():
                    key = tuple(scenario[name] for name in KEY_PARTS)
                    if key in ranked:
                        continue
                    names = ('row_id','entity_id','product_id',scenario['order_key'])
                    selected = worker.declarations.selected_facts(scenario,
                        source.rows('fact', names), entities, products)
                    ranked[key] = [row['row_id'] for row in selected]
                    guard.check()
                assert len(ranked) == 14
                selected_ids = {row_id for ids in ranked.values() for row_id in ids}
                names = tuple(dict.fromkeys(('row_id','entity_id','product_id',
                    *(name for scenario in scenarios.values() for name in worker.declarations.fact_columns(scenario)))))
                hydrated = source.hydrate(selected_ids, names)
                answers = {}
                for name, scenario in scenarios.items():
                    ids = ranked[tuple(scenario[key] for key in KEY_PARTS)]
                    expected = worker.declarations.reference(scenario,
                        (hydrated[row_id] for row_id in sorted(ids)), entities, products)
                    prefix = 'out_' if scenario['projection'] == 'both' else ''
                    assert [row[prefix+'row_id'] for row in expected.rows] == ids
                    document = result_record(expected)
                    blob = pack(document)
                    compare(expected, result_from_record(unpack(blob)),
                        ResultContract(expected.schema, ordered=True))
                    answers[name] = (expected, document, blob)
                for row in group:
                    case = row['case']
                    expected, document, blob = answers[case['declaration']['scenario']['name']]
                    compare(expected, expected, ResultContract(worker.declarations.validate(case).schema, ordered=True))
                    db.execute('INSERT INTO expected VALUES (?,?,?)', (case['id'],case['case_identity'],blob))
                    result['rows'].append(dict(ordinal=row['cohort_ordinal'], id=case['id'],
                        identity=case['case_identity'], origin='independent_python_join_rank',
                        result_rows=len(expected.rows), document_sha256=digest(document),
                        blob_bytes=len(blob), blob_sha256=hashlib.sha256(blob).hexdigest()))
                db.commit()
                source.verify_generations()
                result['profiles'][profile] = dict(cases=len(group), independent_scenarios=len(answers),
                    unique_rank_selections=len(ranked), input_rows=source.declared['spec']['fact_rows'],
                    physical_layout=source.declared['layout'], hydrated_rows=len(hydrated),
                    entity_rows=len(entities), product_rows=len(products), complete_fact_id_domain_verified=True,
                    logical_identity=source.declared['logical_identity'])
                print(json.dumps(dict(reference_profile=profile, complete_cases=len(result['rows']),
                    native_query_executions=0)), flush=True)
                del source, entities, products, ranked, hydrated, answers
            assert db.execute('PRAGMA integrity_check').fetchone() == ('ok',)
            assert db.execute('SELECT COUNT(*) FROM expected').fetchone() == (360,)
            assert len(result['rows']) == len({row['id'] for row in result['rows']}) == 360
            for row in result['rows']:
                entry = db.execute('SELECT identity,value FROM expected WHERE id=?',(row['id'],)).fetchone()
                assert entry[0] == row['identity'] and hashlib.sha256(entry[1]).hexdigest() == row['blob_sha256']
            guard.check()
            result['resource_observations'] = guard.samples
        verify(frozen)
        assert all(identity(Path(path)) == expected for path, expected in proof.items())
        assert not any(name == 'shardloom._native' or name.startswith('_polars_runtime') for name in sys.modules)
        result['rows'].sort(key=lambda row: row['ordinal'])
        assert {row['ordinal'] for row in result['rows']} == {row['cohort_ordinal'] for row in new}
        result.update(status='passed_independent_references', cases=360, new_cases=360,
            original_controls=580, original_control_references='unchanged frozen per-profile references',
            expected=identity(REFERENCE), proof=proof, frozen_inputs_and_client=frozen,
            input_and_client_hashes_unchanged=True, complete_scoring_protocol_frozen=False)
    except BaseException as error:
        result['error'] = type(error).__name__+': '+str(error)
        if 'guard' in locals():
            result['resource_observations'] = guard.samples
        raise
    finally:
        with (REFERENCE.parent/'complete.json').open('x') as output:
            json.dump(result,output,indent=2,allow_nan=False)
            output.write('\n')
    print(json.dumps({key:result[key] for key in ('status','cases','new_cases','native_query_executions')}))


if __name__ == '__main__':
    main()
