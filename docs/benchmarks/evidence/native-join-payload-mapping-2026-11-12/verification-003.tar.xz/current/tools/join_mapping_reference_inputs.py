"""Unactivated draft: bounded Arrow input transport for independent A answers.

Call only inside the investigation guard after complete frozen-input validation.
No native runtime, native result, or comparison query engine is imported here.
"""
from contextlib import ExitStack
import json
from pathlib import Path

from query_surface.datasets import SCHEMAS
from query_surface.semantics import arrow_schema


class Inputs:
    def __init__(self, inputs, profile, guard):
        import pyarrow as pa
        if pa.__version__ != '25.0.1':
            raise ValueError('reference Arrow transport version changed')
        self.pa, self.guard = pa, guard
        self.declared = inputs['profiles'][profile]
        self.dataset = Path(self.declared['dataset']).resolve()
        self.manifest_path = self.dataset / 'dataset.json'
        self.manifest = json.loads(self.manifest_path.read_bytes())
        if (self.manifest['spec'] != self.declared['spec']
                or self.manifest['layout'] != self.declared['layout']
                or self.manifest['logical_identity'] != self.declared['logical_identity']):
            raise ValueError('reference dataset generation changed')
        self.known = {row['path']: row for row in inputs['files']}
        self.paths = {}
        self.generations = {}
        self._record(self.manifest_path)
        for table in ('fact', 'entities', 'products'):
            parts = self.manifest['tables'][table]['files']
            paths = [self.dataset / part['path'] for part in parts]
            if list(map(str, paths)) != self.declared['sources']['arrow-ipc'][table]:
                raise ValueError('reference table paths changed')
            for path, part in zip(paths, parts, strict=True):
                if path.is_symlink() or not path.resolve().is_relative_to(self.dataset):
                    raise ValueError('reference table escapes its frozen dataset')
                recorded = self.known[str(path)]
                if (recorded['sha256'] != part['sha256']
                        or recorded['generation']['bytes'] != part['bytes']):
                    raise ValueError('reference part identity differs from frozen inputs')
                self._record(path)
            self.paths[table] = paths

    def _record(self, path):
        if not path.is_file() or path.is_symlink():
            raise ValueError('reference input must be a regular file')
        stat = path.stat()
        generation = (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)
        if str(path) in self.generations and self.generations[str(path)] != generation:
            raise ValueError('reference input changed during preparation')
        self.generations[str(path)] = generation

    def _batches(self, table, names):
        """Complete source batches with independently checked fact identity."""
        names = tuple(names)
        schema = dict(SCHEMAS[table])
        if not names or len(set(names)) != len(names) or any(name not in schema for name in names):
            raise ValueError('invalid independent-reference projection')
        if table == 'fact' and 'row_id' not in names:
            raise ValueError('fact references must check fact row identity')
        total = 0
        expected_rows = self.manifest['tables'][table]['rows']
        seen_ids = bytearray(expected_rows) if table == 'fact' else None
        parts = self.manifest['tables'][table]['files']
        for path, part in zip(self.paths[table], parts, strict=True):
            self.guard.check()
            self._record(path)
            observed = 0
            with ExitStack() as stack:
                memory = stack.enter_context(self.pa.memory_map(str(path), 'r'))
                full = self.pa.ipc.open_file(memory)
                if arrow_schema(full.schema) != SCHEMAS[table]:
                    raise ValueError('reference source schema changed')
                options = self.pa.ipc.IpcReadOptions(use_threads=False,
                    included_fields=[full.schema.get_field_index(name) for name in names])
                reader = self.pa.ipc.open_file(memory, options=options)
                for batch_index in range(reader.num_record_batches):
                    batch = reader.get_batch(batch_index).select(names)
                    if dict(arrow_schema(batch.schema)) != {name: schema[name] for name in names}:
                        raise ValueError('reference projection schema changed')
                    if table == 'fact':
                        row_ids = batch.column('row_id')
                        for start in range(0, batch.num_rows, 2048):
                            self.guard.check()
                            ids = row_ids.slice(start, min(2048, batch.num_rows-start)).to_pylist()
                            for row_id in ids:
                                if type(row_id) is not int or not 0 <= row_id < expected_rows or seen_ids[row_id]:
                                    raise ValueError('facts do not have exact unique in-range row IDs')
                                seen_ids[row_id] = 1
                    yield batch, total
                    total += batch.num_rows
                    observed += batch.num_rows
                    del batch
            self._record(path)
            if observed != part['rows']:
                raise ValueError('reference part row count changed')
        if total != self.manifest['tables'][table]['rows']:
            raise ValueError('reference complete table row count changed')
        if table == 'fact' and total != self.declared['spec']['fact_rows']:
            raise ValueError('reference fact count differs from frozen generation')

    def rows(self, table, names):
        """Complete physical row order; at most 2048 Python rows at a time."""
        for batch, _ in self._batches(table, names):
            for start in range(0, batch.num_rows, 2048):
                self.guard.check()
                yield from batch.slice(start, min(2048, batch.num_rows-start)).to_pylist()

    def hydrate(self, row_ids, names):
        """Read full payload but convert only the bounded row-id union to Python."""
        row_ids = list(row_ids)
        limit = self.declared['spec']['fact_rows']
        if len(row_ids) > 24 * 4096 or any(type(row) is not int or not 0 <= row < limit for row in row_ids):
            raise ValueError('reference hydration domain exceeds its declared bound')
        row_ids = set(row_ids)
        result = {}
        for batch, _ in self._batches('fact', names):
            positions = []
            for start in range(0, batch.num_rows, 2048):
                self.guard.check()
                ids = batch.column('row_id').slice(start, min(2048, batch.num_rows-start)).to_pylist()
                positions.extend(start+index for index, row_id in enumerate(ids) if row_id in row_ids)
            if positions:
                indices = self.pa.array(positions, type=self.pa.int64())
                selected = batch.take(indices)
                for begin in range(0, selected.num_rows, 2048):
                    self.guard.check()
                    for row in selected.slice(begin, min(2048, selected.num_rows-begin)).to_pylist():
                        result[row['row_id']] = row
        if set(result) != row_ids:
            raise ValueError('reference hydration missed selected rows')
        return result

    def verify_generations(self):
        for name in tuple(self.generations):
            self._record(Path(name))
