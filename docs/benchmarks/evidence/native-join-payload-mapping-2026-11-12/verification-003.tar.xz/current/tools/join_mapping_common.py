"""Unactivated A preparation and replay helpers; importing executes no queries."""
import importlib.util
import json
from pathlib import Path
import sys
from types import SimpleNamespace

OUT = Path(__file__).resolve().parents[1]
S = OUT.parent / 'shared-operator-state-2026-11-10'
T = OUT.parent / 'shared-window-state-2026-11-11'
D = OUT.parent / 'rolling-distinct-2026-11-11'
E = OUT.parent / 'expanded-query-2026-11-03'
W = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
FROZEN = E / 'investigation-original-harness-r1'
CLIENT = OUT / 'client'
SELECTION = OUT / 'cohort-selection-r1.json'
REFERENCE = OUT / 'references-r1/expectations.sqlite'
CLOSEOUT = D / 'rolling-distinct-closeout-r1.json'
CLOSEOUT_SHA256 = '47fc3ef54aeb45222f6e15be47a4deb0ce4bd81108de9157655b3b9da08a5b6b'
TREE = '0d8991d11b2decca87d60f7b25a3f06672cb341f'
sys.path[:0] = [str(CLIENT), str(S / 'window-tools-draft')]
import window_admission as previous
import window_replay as old_proof
from window_replay import content, database, digest, read
import join_mapping_worker as worker
from query_surface import adapters
from query_surface.evidence import identity
from query_surface.expanded_run import verify
from query_surface.semantics import ResultContract


def accepted_runtime():
    assert content(CLOSEOUT)['sha256'] == CLOSEOUT_SHA256
    closeout = read(CLOSEOUT)
    assert closeout['schema'] == 'shardloom.rolling_distinct_closeout.v1'
    assert closeout['status'] == 'complete'
    assert closeout['pr_head'] == '11a83e0ab8948a5986ec093c414bdf76b0076591'
    assert closeout['source_tree'] == TREE
    assert closeout['pr_checks_passed'] == 58 and closeout['main_checks_passed'] == 55
    assert not closeout['review_findings'] and closeout['portable_replay_after_retirement'] == 'passed'
    assert closeout['current_inputs_unchanged'] and closeout['runtime_sources_match_build']
    assert closeout['source_bound_replay'] == 'passed' and closeout['working_tree_clean']
    assert closeout['disposition'] == 'drop_candidate_no_gain'
    assert closeout['baseline']['engine_execution_seconds'] == 310.690303040
    assert closeout['candidate']['engine_execution_seconds'] == 311.414365730
    assert closeout['candidate']['selected_cases'] == 1090
    assert closeout['candidate']['outcomes'] == {'passed': 1090}
    predecessor_path = T / 'shared-window-closeout-r1.json'
    assert content(predecessor_path)['sha256'] == '97b80163c9c91d1186acc86522e808fa8563c8d9dd88be9a4ff1b71e316768a0'
    predecessor = read(predecessor_path)
    assert closeout['predecessor_closeout'] == dict(path=str(predecessor_path), identity=content(predecessor_path))
    assert closeout['retained_runtime'] == predecessor['retained_runtime']
    assert closeout['source_fingerprint_sha256'] == predecessor['source_fingerprint_sha256']
    for name, expected in closeout['retained_runtime'].items():
        assert content(Path(name)) == expected
    protocol_path = T / 'candidate-protocol-r1.json'
    packet = W / 'docs/benchmarks/evidence/native-shared-window-state-2026-11-11/acceptance.json'
    assert content(packet) == closeout['committed_evidence'][packet.relative_to(W).as_posix()]
    expected = next(row for row in read(packet)['members'] if row['path'] == 'current/candidate-protocol-r1.json')
    assert content(protocol_path) == {key: expected[key] for key in ('bytes', 'sha256')}
    runtime = read(protocol_path)['runtime_binding']['runtime']
    assert runtime['binary']['path'] == str(T / 'runtime-r1/shardloom')
    assert runtime['library']['path'] == str(T / 'runtime-r1/_native.abi3.so')
    assert all(content(Path(row['path'])) == closeout['retained_runtime'][row['path']] for row in runtime.values())
    verify(list(runtime.values()))
    return runtime, closeout


def inputs_and_client():
    return previous.inputs_and_client()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class Cases(old_proof.Cases):
    def item(self, case):
        if 'join_mapping_version' in case:
            plan = worker.declarations.validate(case)
            return SimpleNamespace(identity=case['case_identity'], relation=plan,
                contract=ResultContract(plan.schema, ordered=True))
        return super().item(case)


def replay_case(entry, case, expected, item, inputs, prepared, policy):
    result = old_proof.replay(entry, case, 'native', expected, item, inputs, prepared, policy)
    if result['status'] == 'passed' or result['engine_seconds'] is not None:
        old_proof.verify_clock(entry, result)
    if result['status'] in {'passed', 'incorrect', 'comparison_inconclusive'} and not result.get('delivered_invalid_result'):
        raw = old_proof.raw_files(old_proof.unpack(entry[3]))
        job = json.loads(raw['one.job.json'])
        report = json.loads(raw['one.stdout.json'])['observation']
        plan = (worker.declarations.validate(case) if 'join_mapping_version' in case
            else item.relation)
        assert report['sql_declaration'] == adapters.relation_sql(plan, job['sources'])
        assert report['sql_declaration_submitted'] == (case['surface'] in {'cli_sql', 'embedded_workflow', 'python_sql'})
        assert report['execution_mode'] == 'first_query_fresh_session'
    return result


def verify_capture():
    """Preserve the exact established supervisor, with A labels and case dispatch."""
    old_proof.verify_capture()
    template = S / 'window-tools-draft/capture_window_cohort.py'
    source = template.read_text()
    source = source[source.index('from __future__'):]
    before = 'TARGET_NAME = "window-baseline-missing-r1"'
    assert source.count(before) == 1 and source.count('"window_composition_version"') == 2
    wanted = source.replace(before, 'TARGET_NAME = "join-mapping-baseline-missing-r1"')
    wanted = wanted.replace('"window_composition_version"', '"join_mapping_version"')
    path = OUT / 'tools/capture_join_mapping.py'
    actual = path.read_text()
    assert actual[actual.index('from __future__'):] == wanted
    return dict(original=identity(template), versioned=identity(path),
        capture_changes=['A target label', 'A composition marker for independent reference selection'],
        per_query_supervision_unchanged=True, request_builder_unchanged=True,
        engine_clock_check_unchanged=True, cleanup_and_result_retention_unchanged=True)
