"""Complete replay; r2 binds the recorded launcher and retains frozen r1 unchanged."""
from collections import Counter, defaultdict
from contextlib import ExitStack
import gzip
import hashlib
import json
import math
from pathlib import Path

assert Path(__file__).resolve() == Path('/Users/dylan/LocalData/shardloom/join-mapping-2026-11-11/tools/replay_join_mapping_baseline_r2.py')
import run_join_mapping_baseline as current
from join_mapping_common import Cases, content, database, digest, read, replay_case
from query_surface.evidence import identity
from query_surface.expanded_freeze import unpack
from query_surface.expanded_report import raw_files
from query_surface.expanded_run import verify


def capture_receipts(binding):
    done = read(current.TARGET/'complete.json'); observed = read(current.TARGET/'binding.json')
    assert done['status'] == 'complete_observation' and done['stage'] == 'native'
    assert done['total'] == done['attempt_slots'] == 940 and done['posthash_verified']
    assert done['attempts_per_case'] == 1 and done['requested_repeats'] == 0
    assert done['updated'] == binding
    assert observed['contract'] == {key:done[key] for key in ('frozen', 'stage', 'prerequisites', 'updated')}
    assert done['ledger']['path'] == str(current.TARGET/'attempts.sqlite')
    assert done['binding']['path'] == str(current.TARGET/'binding.json')
    verify([done['ledger'], done['binding'], done['frozen']])
    path = current.OUT/'baseline-missing-r1.json'; guard = read(path)
    assert guard['status'] == 'passed' and guard['returncode'] == 0
    assert guard['process_group_drained'] and guard['direct_child_reaped'] and guard['query_workload']
    assert guard['head'] == guard['base'] == binding['accepted_merge']
    assert guard['active_output'] == str(current.TARGET) and guard['fixed_source_validation']
    assert guard['build_inventory_policy'] == guard['evidence_inventory_policy'] == 'before_and_after_only'
    assert guard['accepted_rolling_distinct_closeout']['sha256'] == identity(current.CLOSEOUT)['sha256']
    assert guard['accepted_baseline_source_fingerprint_sha256'] == binding['source_fingerprint_sha256']
    clarification = read(current.OUT/'baseline-replay-command-clarification-r1.json')
    assert clarification['status'] == 'static_verifier_expectation_mismatch'
    assert clarification['queries_repeated'] == 0
    assert clarification['candidate_requires_same_interpreter_path']
    assert not clarification['native_runtime_changed'] and not clarification['query_results_changed']
    verify([clarification['original_verifier'], clarification['baseline_guard']])
    assert clarification['original_verifier']['path'] == str(current.OUT/'tools/replay_join_mapping_baseline.py')
    assert clarification['baseline_guard']['path'] == str(path)
    assert guard['command'] == clarification['observed_parent_command'] == [
        '/opt/homebrew/opt/python@3.13/libexec/bin/python3',
        str(current.OUT/'tools/run_join_mapping_baseline.py')]
    interpreters = clarification['interpreters']
    assert [item['path'] for item in interpreters] == [
        '/Users/dylan/.cache/shardloom/query-surface-polars-2.1.0/bin/python', guard['command'][0]]
    assert interpreters[0]['resolved'] == interpreters[1]['resolved']
    assert interpreters[0]['content'] == interpreters[1]['content']
    for item in interpreters:
        assert str(Path(item['path']).resolve()) == item['resolved']
        assert content(Path(item['resolved'])) == item['content']
    assert guard['log_sha256'] == content(path.with_suffix('.log'))['sha256']
    return done, path


def main():
    destination = current.OUT/'baseline-verified-r1.json'
    records = current.OUT/'baseline-cases-r1.jsonl.gz'
    partial = current.OUT/'baseline-cases-r1.partial.jsonl.gz'
    assert __debug__ and not any(path.exists() for path in (destination, records, partial))
    design, inputs, frozen, binding = current.admission(current.E)
    protocol, selection, reuse = (read(path) for path in (current.PROTOCOL, current.SELECTION, current.REUSE))
    assert protocol['selected_count'] == protocol['missing_count'] == 940
    assert protocol['reused_count'] == reuse['selected_reused_cases'] == 0
    assert protocol['original_controls'] == 580 and protocol['new_compositions'] == 360
    assert reuse['status'] == 'verified_no_matching_saved_cases'
    assert len(reuse['requests']) == reuse['complete_requests_verified'] == 940
    assert protocol['missing_cases'] == selection['cases']
    assert Counter(row['kind'] for row in selection['cases']) == {'original':580, 'composition':360}
    done, guard_path = capture_receipts(binding)
    prepared = read(current.E/'native-preparation/complete.json')
    outcomes, families, values, failures = Counter(), defaultdict(list), [], []
    with ExitStack() as stack:
        db = stack.enter_context(database(current.TARGET/'attempts.sqlite'))
        assert db.execute('PRAGMA integrity_check').fetchone() == ('ok',)
        entries = iter(db.execute('SELECT seq,id,status,packet FROM attempt ORDER BY seq'))
        refs, cases = current.references(stack, selection), Cases()
        output = stack.enter_context(gzip.open(partial, 'wt', encoding='utf-8'))
        for ordinal, (selected, declaration) in enumerate(zip(selection['cases'], reuse['requests'], strict=True)):
            case = selected['case']; item, reference, expected = current.case_reference(refs, selected, cases)
            assert selected['cohort_ordinal'] == declaration['cohort_ordinal'] == ordinal
            assert declaration['reference_blob_sha256'] == hashlib.sha256(reference[1]).hexdigest()
            assert declaration['id'] == case['id'] and declaration['case_identity'] == case['case_identity']
            entry = next(entries, None)
            assert entry and entry[:2] == (ordinal, case['id'])
            result = replay_case(entry, case, expected, item, inputs, prepared, design['execution'])
            assert result['status'] == entry[2]
            files = raw_files(unpack(entry[3])) if entry[3] is not None else {}
            packet = dict(bytes=len(entry[3]), sha256=hashlib.sha256(entry[3]).hexdigest()) if entry[3] is not None else None
            job_sha = hashlib.sha256(files['one.job.json']).hexdigest() if files else None
            if files:
                assert digest(json.loads(files['one.job.json'])) == declaration['request_sha256']
            outcomes[result['status']] += 1
            if result['status'] == 'passed':
                elapsed = result['engine_seconds']
                assert type(elapsed) in (int, float) and math.isfinite(elapsed) and elapsed >= 0
                values.append(elapsed); families[case['family']].append(elapsed)
            else:
                failures.append(dict(cohort_ordinal=ordinal, id=case['id'],
                    status=result['status'], detail=result.get('failure_detail')))
            output.write(json.dumps(dict(cohort_ordinal=ordinal, original_seq=selected['original_seq'],
                kind=selected['kind'], id=case['id'], case_identity=case['case_identity'], family=case['family'],
                profile=case['profile'], surface=case['surface'], native_format=case['native_format'],
                provenance=dict(source='new_missing_baseline', ledger=done['ledger']['path'],
                    source_seq=ordinal, packet=packet, job_sha256=job_sha,
                    independent_expected_blob_sha256=declaration['reference_blob_sha256']),
                result=result), separators=(',', ':'), allow_nan=False)+'\n')
        assert next(entries, None) is None
    assert dict(outcomes) == done['outcomes'] and sum(outcomes.values()) == 940
    verify([*frozen, done['ledger'], done['binding'], done['frozen']])
    partial.rename(records); passed = outcomes == {'passed':940}
    result = dict(schema='shardloom.join_mapping_baseline.v1',
        status='passed_complete_baseline_cohort' if passed else 'failed_baseline_cohort',
        query_executions_during_replay=0, accepted_merge=binding['accepted_merge'], accepted_tree=current.TREE,
        selected_cases=940, original_controls=580, new_compositions=360,
        reused_saved_cases=0, new_attempts=940, outcomes=dict(outcomes), new_outcomes=dict(outcomes),
        attempts_per_case=1, warmups=0, requested_repeats=0,
        primary_clock='engine_execution_seconds', engine_execution_seconds=math.fsum(values) if passed else None,
        complete_performance_result_valid=passed, all_selected_results_correct=passed,
        all_engine_clocks_valid=passed, native_no_fallback=passed, failures=failures,
        families={name:dict(cases=len(times), engine_execution_seconds=math.fsum(times))
            for name,times in sorted(families.items())},
        protocol=identity(current.PROTOCOL), selection=identity(current.SELECTION), reuse=identity(current.REUSE),
        complete=identity(current.TARGET/'complete.json'), ledger=done['ledger'], guard=identity(guard_path),
        case_rows=identity(records), verifier=identity(Path(__file__)), runtime_binding=binding,
        replay_command_clarification=identity(current.OUT/'baseline-replay-command-clarification-r1.json'),
        performance_claim=False, complete_10k_performance_claim=False, full43_claim=False,
        limitations=['One observation per exact request; baseline and candidate occur in separate sessions.',
            'Fixed 940-case cohort, not a complete 10k or Full43; the original failed 10k remains invalid.',
            'Auxiliary ownership/work attribution is separate; no whole-process memory or statistical confidence claim.'])
    with destination.open('x') as output:
        json.dump(result, output, indent=2, allow_nan=False); output.write('\n')
    print(json.dumps({key:result[key] for key in ('status', 'selected_cases', 'outcomes', 'engine_execution_seconds')}))
    assert passed, 'baseline has failed observations; preserve all observations'


if __name__ == '__main__':
    main()

