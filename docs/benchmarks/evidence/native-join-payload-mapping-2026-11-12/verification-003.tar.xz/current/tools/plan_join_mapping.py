"""Draft a fixed structural cohort from original aggregate barriers and join declarations."""
from collections import Counter
import importlib.util
import json
from pathlib import Path
import hashlib
import sys

OUT = Path(__file__).resolve().parents[1]
DESIGN_SOURCE = Path('/Users/dylan/LocalData/shardloom/expanded-query-2026-11-03/design.json')
FROZEN_CLIENT = Path('/Users/dylan/LocalData/shardloom/expanded-query-2026-11-03/investigation-original-harness-r1')
INVENTORY = OUT / 'exposure-inventory-r1.json'
CLIENT = OUT / 'client/join_mapping_cases.py'
FIXED_DESIGN = OUT / 'design-r1.md'
COHORT_DESIGN = OUT / 'cohort-design-r1.md'
SELECTION = OUT / 'cohort-selection-r1.json'

assert OUT == Path('/Users/dylan/LocalData/shardloom/join-mapping-2026-11-11'), 'unactivated draft cannot execute'
assert Path(__file__).resolve() == OUT/'tools/plan_join_mapping.py'
assert __debug__ and not SELECTION.exists()


def identity(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def read(path):
    return json.loads(path.read_bytes())


inventory = read(INVENTORY)
design = read(DESIGN_SOURCE)
assert identity(INVENTORY)['sha256'] == '07f93f6d20be292eac8c5c97ec81375144f2e2e33bd783776d3da89b082f57b0'
assert identity(DESIGN_SOURCE)['sha256'] == inventory['design_sha256'] == 'fd0a2604c9abc888a7a24ba75078569fc33e354b16cc98372977c15306a39216'
for relative, expected in inventory['frozen_loaded_sources'].items():
    assert not Path(relative).is_absolute() and '..' not in Path(relative).parts
    assert identity(FROZEN_CLIENT/relative)['sha256'] == expected
assert inventory['status'] == 'passed'
assert inventory['scope'] == 'declaration_inventory_only'
assert inventory['native_imports'] is False and inventory['queries_or_builds'] is False
assert inventory['timing'] is False
assert inventory['unique_case_ids'] == 10000
assert design['version'] == 'analytical-10000-v2' and design['count'] == 10000

target_rows = inventory['aggregate_barrier_controls']
assert len(target_rows) == inventory['join_chain_count'] == 580
assert inventory['target_count'] == 0
target_identities = [row['identity'] for row in target_rows]
assert len(set(target_identities)) == len(target_identities)
target_by_identity = {row['identity']: row for row in target_rows}

original_cases = design['cases']
assert len(original_cases) == design['count']
original_identities = [row['case_identity'] for row in original_cases]
original_ids = [row['id'] for row in original_cases]
assert len(set(original_identities)) == len(original_identities)
assert len(set(original_ids)) == len(original_ids)
original_by_identity = {row['case_identity']: (ordinal, row) for ordinal, row in enumerate(original_cases)}
sys.path[:0] = [str(FROZEN_CLIENT/'scripts'), str(FROZEN_CLIENT/'python/src'),
    str(FROZEN_CLIENT/'benchmarks/traditional_analytics')]
from query_surface.corpus import corpus
from query_surface.expanded_catalog import build, spaces
definitions = {row.name: row for row in spaces()}
originals = {row.id: row for row in corpus(interactions='all', include_pending=False)}
for case in original_cases:
    item = build(case, definitions) if 'cell' in case else originals[case['id']]
    assert item.identity == case['case_identity'], 'reconstructed original declaration changed'
unknown = set(target_identities) - set(original_by_identity)
assert not unknown, 'inventory contains unknown original case identities'
assert set(target_identities) <= set(original_identities)

original_selection = []
for ordinal, case in enumerate(original_cases):
    case_identity = case['case_identity']
    if case_identity not in target_by_identity:
        continue
    inventory_row = target_by_identity[case_identity]
    assert inventory_row['identity'] == case_identity
    assert inventory_row['id'] == case['id'], 'inventory/original case ID mismatch'
    original_selection.append(dict(cohort_ordinal=len(original_selection),
        kind='original', original_seq=ordinal, case=case,
        inventory_identity=case_identity))
assert len(original_selection) == 580
assert [row['case']['case_identity'] for row in original_selection] == [
    case['case_identity'] for case in original_cases if case['case_identity'] in target_by_identity]

spec = importlib.util.spec_from_file_location('join_mapping_cases', CLIENT)
declarations = importlib.util.module_from_spec(spec)
spec.loader.exec_module(declarations)
new_cases = declarations.declarations()
assert len(new_cases) == 360
assert len({row['id'] for row in new_cases}) == len(new_cases)
assert len({row['case_identity'] for row in new_cases}) == len(new_cases)
for case in new_cases:
    declarations.validate(case)
    assert case['case_identity'] not in set(original_identities), 'new case collides with original identity'
    assert 'window_composition_version' not in case

cases = original_selection + [dict(cohort_ordinal=len(original_selection) + index,
    kind='composition', original_seq=None, case=case, inventory_identity=None)
    for index, case in enumerate(new_cases)]
assert len(cases) == 940
assert len({row['case']['id'] for row in cases}) == 940
assert len({row['case']['case_identity'] for row in cases}) == 940
assert [row['cohort_ordinal'] for row in cases] == list(range(940))
assert not any(name == 'shardloom._native' or name.startswith('_polars_runtime') for name in sys.modules)

result = dict(schema='shardloom.join_mapping_selection.v1',
    status='frozen_structural_selection_before_candidate_or_scoring',
    selected_requests=940, original_aggregate_barrier_controls=580,
    new_declarations=360, query_executions=0, native_imports=False,
    selection_uses_timing=False,
    exposure_inventory=identity(INVENTORY), original_design=identity(DESIGN_SOURCE),
    frozen_client_root=str(FROZEN_CLIENT), client_module=identity(CLIENT),
    frozen_loaded_sources=inventory['frozen_loaded_sources'],
    generator=identity(Path(__file__)), fixed_design=identity(FIXED_DESIGN),
    cohort_design=identity(COHORT_DESIGN),
    identity_checks=dict(inventory_targets=580, original_design_cases=10000,
        new_case_identities=360,
        duplicate_or_unknown_original_identities=(len(target_identities) - len(set(target_identities)) + len(unknown)),
        missing_or_mutated_original_case_identities=(580 - len(original_selection))),
    families=dict(Counter(row['case']['family'] for row in cases)),
    cases=cases, complete_10k_performance_claim=False, full43_claim=False)
with SELECTION.open('x') as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps({key: result[key] for key in ('status', 'selected_requests',
    'original_aggregate_barrier_controls', 'new_declarations', 'families')}))
