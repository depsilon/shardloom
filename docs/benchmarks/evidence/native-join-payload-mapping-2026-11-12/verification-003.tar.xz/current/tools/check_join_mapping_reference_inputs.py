"""Small real-IPC transport checks; no native import or benchmark execution."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import time

TMP = Path('/Users/dylan/LocalData/shardloom/join-mapping-2026-11-11')
FROZEN = Path('/Users/dylan/LocalData/shardloom/expanded-query-2026-11-03/investigation-original-harness-r1')
sys.path[:0] = [str(FROZEN/'scripts'), str(FROZEN/'python/src'),
    str(FROZEN/'benchmarks/traditional_analytics')]
from query_surface.datasets import DatasetSpec, SCHEMAS, write_dataset
from query_surface.evidence import identity


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, TMP/filename)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


declarations = module('join_declarations_draft', 'client/join_mapping_cases.py')
transport = module('join_inputs_draft', 'tools/join_mapping_reference_inputs.py')


class Guard:
    def __init__(self, root):
        self.root, self.started, self.checks = root, time.monotonic(), 0

    def check(self):
        assert time.monotonic()-self.started < 60
        assert sum(path.stat().st_size for path in self.root.rglob('*') if path.is_file()) < 4 << 20
        self.checks += 1


records = []
with tempfile.TemporaryDirectory(prefix='join-mapping-reader-check-', dir=TMP) as scratch:
    root = Path(scratch)
    guard = Guard(root)
    spec = DatasetSpec(fact_rows=29, entity_rows=7, product_rows=3,
        relationship_rows=11, calendar_rows=5, profile='null_heavy')
    for layout in ('sorted', 'shuffled'):
        dataset = root/layout
        manifest = write_dataset(dataset, spec, layout, guard=guard.check, batch_rows=7)
        declared = dict(dataset=str(dataset), spec=manifest['spec'], layout=layout,
            logical_identity=manifest['logical_identity'], sources={'arrow-ipc': {
                name: [str(dataset/part['path']) for part in table['files']]
                for name, table in manifest['tables'].items()}})
        inputs = dict(profiles={'test': declared},
            files=[identity(path) for path in sorted(dataset.iterdir())])
        source = transport.Inputs(inputs, 'test', guard)
        all_facts = list(source.rows('fact', tuple(dict(SCHEMAS['fact']))))
        assert sorted(row['row_id'] for row in all_facts) == list(range(29))
        assert ([row['row_id'] for row in all_facts] == list(range(29))) == (layout == 'sorted')
        entities = declarations.unique_dimension(source.rows('entities',
            ('entity_id', 'region', 'entity_label')), 'entities')
        products = declarations.unique_dimension(source.rows('products',
            ('product_id', 'product_category')), 'products')
        for scenario in declarations.scenarios():
            keys = ('row_id','entity_id','product_id',scenario['order_key'])
            chosen = declarations.selected_facts(scenario, source.rows('fact', keys), entities, products)
            payloads = source.hydrate([row['row_id'] for row in chosen], tuple(dict(SCHEMAS['fact'])))
            expected = declarations.reference(scenario, all_facts, entities, products)
            actual = declarations.reference(scenario, payloads.values(), entities, products)
            assert actual == expected, (layout, scenario['name'])
        for bad in ([True], [-1], [29], [1, True]):
            try:
                source.hydrate(bad, ('row_id',))
            except ValueError:
                pass
            else:
                raise AssertionError('invalid hydration domain was accepted')
        source.verify_generations()
        records.append(dict(layout=layout, source_rows=len(all_facts), scenarios=24,
            hydration_refusals=4, files_unchanged=all(identity(Path(row['path'])) == row for row in inputs['files'])))
    # Real malformed IPC with a matching manifest hash must still fail the ID proof.
    import pyarrow as pa
    fact_path = Path(declared['sources']['arrow-ipc']['fact'][0])
    with pa.memory_map(str(fact_path), 'r') as mapped:
        table = pa.ipc.open_file(mapped).read_all()
        values = table.to_pylist()
        schema = table.schema
    del table
    values[-1]['row_id'] = values[0]['row_id']
    with pa.OSFile(str(fact_path), 'wb') as output:
        with pa.ipc.new_file(output, schema) as writer:
            writer.write_batch(pa.RecordBatch.from_pylist(values, schema=schema))
    part = manifest['tables']['fact']['files'][0]
    part.update(bytes=fact_path.stat().st_size, sha256=hashlib.sha256(fact_path.read_bytes()).hexdigest())
    (dataset/'dataset.json').write_text(json.dumps(manifest))
    inputs['files'] = [identity(path) for path in sorted(dataset.iterdir())]
    bad_source = transport.Inputs(inputs, 'test', guard)
    try:
        list(bad_source.rows('fact', ('row_id',)))
    except ValueError as error:
        assert 'unique in-range' in str(error)
    else:
        raise AssertionError('duplicate IDs with valid input hashes were accepted')
    checks = guard.checks

assert not any(name == 'shardloom._native' or name.startswith('_polars_runtime') for name in sys.modules)
print(json.dumps(dict(status='passed_draft_real_ipc_reference_transport',
    records=records, duplicate_id_refusals=1, guard_checks=checks,
    native_query_executions=0, native_runtime_loaded=False, comparison_engine_loaded=False,
    source_fixture_removed=True, sources={str(path):dict(bytes=path.stat().st_size,
        sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for path in (
        Path(__file__), TMP/'tools/join_mapping_reference_inputs.py',
        TMP/'client/join_mapping_cases.py')}), indent=2))
