"""Verify complete join-mapping attribution and exact fixed-source checks.

Read saved test observations only. No query timing or whole-process memory
acceptance is inferred from payload-buffer counts.
"""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

from join_mapping_common import OUT, W as ROOT, content, digest, read, accepted_runtime
import verify_join_mapping_attribution as baseline

BASE = 'e10fc31e4ada819038711dd3a4658c3ad10a91f0'
FEATURES = 'shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment'
REQUIRED_TESTS = [
    "join_payload_mapping_cancel_denial_consumer_error_and_fresh_action_release_state",
    "join_payload_mapping_chunk_metadata_reserves_overlap_and_survives_offset_child_escape",
    "join_payload_mapping_composes_repeated_nullable_text_binary_and_nested_selections",
    "join_payload_mapping_denied_wrapper_cancelled_and_invalid_selection_release_credit",
    "join_payload_mapping_invalid_selected_tail_after_ranked_prefix_still_fails",
    "join_payload_mapping_mask_matches_nested_decimal_errors_and_outer_selections",
    "join_payload_mapping_one_row_retains_large_backing_once_through_children_and_clones",
    "join_payload_mapping_ordinary_index_checks_exact_equality_before_duplicate_links",
    "join_payload_mapping_prepared_annotations_follow_alias_keys_and_prefix_boundaries",
    "join_payload_mapping_prepared_conditioned_and_asof_edges_stop_both_annotations",
    "join_payload_mapping_prepared_file_build_validation_and_dropped_fields_keep_errors",
    "join_payload_mapping_prepared_observable_stages_stop_whole_chain_admission",
    "join_payload_mapping_prepared_spill_declines_views_and_cleans_complete_output",
    "join_payload_mapping_prepared_two_edges_preserve_full_values_ties_and_release",
    "join_payload_mapping_preserves_selected_nested_errors_parent_masks_and_error_order",
    "join_payload_mapping_zero_one_two_edges_keep_duplicates_nulls_and_empty_builds",
    "successive_join_ranked_payloads_release_sources_and_match_independent_rows"
]
ATTRIBUTION_TESTS = {
    'successive_join_ranked_payloads_release_sources_and_match_independent_rows',
    'successive_join_ranked_payload_work_attribution_matrix',
}
ATTRIBUTION = ['cargo','test','--offline','--locked','--workspace','--lib','--features',
    FEATURES,'successive_join_ranked_payload','--','--include-ignored','--show-output','--test-threads=1']
CHECKS = {
    'format': ('candidate-format-r2',['cargo','fmt','--all','--','--check']),
    'default_clippy': ('candidate-default-clippy-r2',['cargo','clippy','--offline','--locked',
        '--workspace','--all-targets','--','-D','warnings']),
    'default_tests': ('candidate-default-tests-r2',['env','RUST_TEST_THREADS=4','cargo','test',
        '--offline','--locked','--workspace','--all-targets']),
    'native_clippy': ('candidate-native-clippy-r3',['cargo','clippy','--offline','--locked',
        '--workspace','--all-targets','--features',FEATURES,'--','-D','warnings']),
    'native_tests': ('candidate-native-tests-r2',['env','RUST_TEST_THREADS=4','cargo','test',
        '--offline','--locked','--workspace','--all-targets','--features',FEATURES]),
    'attribution': ('candidate-attribution-r4',ATTRIBUTION),
    'ci_cleanup_tests': ('candidate-ci-cleanup-tests-r1',[
        '/opt/homebrew/opt/python@3.13/libexec/bin/python3','-B','scripts/test_ci_native_tests.py']),
    'ci_cleanup_regression': ('candidate-ci-cleanup-regression-r1',[
        '/opt/homebrew/opt/python@3.13/libexec/bin/python3','-B',str(OUT/'tools/check_cleanup_regression.py')]),
}


def source_inventory():
    paths = set()
    for command in (['git','ls-files','--cached','-z'],['git','ls-files','--others','--exclude-standard','-z']):
        paths.update(value for value in subprocess.check_output(command,cwd=ROOT).decode().split('\0')
            if value and not value.startswith(('.git/','docs/benchmarks/evidence/',
                'docs/release/evidence/','docs/dependencies/evidence/')) and '.git' not in Path(value).parts)
    result = {}
    for relative in sorted(paths):
        path = ROOT/relative
        if path.is_symlink():
            target = os.readlink(path)
            result[relative] = dict(symlink=target,sha256=hashlib.sha256(os.fsencode(target)).hexdigest())
        elif path.is_file():
            result[relative] = content(path)
        else:
            assert not path.exists(),relative
            result[relative] = dict(absent=True)
    return result


def validate_guard(record,command,sources):
    assert record['status']=='passed' and record['returncode']==0
    assert record['command']==command and record['cwd']==str(ROOT)
    assert record['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    assert record['base']==record['accepted_baseline_merge']==BASE
    assert record['fixed_source_validation'] and not record['allow_lockfile_update']
    assert record['process_group_drained'] and record['direct_child_reaped']
    assert not record['query_workload']
    assert record['build_sources']==sources
    assert record['build_source_fingerprint_sha256']==digest(sources)
    for stage in ('pre_execution','post_execution'):
        item=record['build_source_verification'][stage]
        assert item['head_matches'] and item['path_set_matches'] and not item['changed_paths']
        assert item['fingerprint_sha256']==digest(sources)
    driver=OUT/'tools/guard_join_mapping.py'
    assert record['driver_sha256']==content(driver)['sha256']
    assert record['tool_source_inventory'][str(driver)]==content(driver)


def guarded(path,command,sources):
    assert path.parent==OUT and path.name.startswith('candidate-')
    record=read(path)
    validate_guard(record,command,sources)
    assert record['log_sha256']==content(path.with_suffix('.log'))['sha256']
    return record,path.with_suffix('.log').read_text()


def passed_tests(log):
    names=re.findall(r'^test (\S+) \.\.\. ok$',log,re.MULTILINE)
    assert names and len(names)==len(set(names))
    assert not re.search(r'^test .* \.\.\. FAILED$|^test result: FAILED\.',log,re.MULTILINE)
    return names


def validate_attribution(observations,old):
    assert [row['case'] for row in observations]==baseline.expected_cases()
    assert len(observations)==len(old['observations'])==96
    payloads={'Narrow':(0,0),'Wide':(5,6),'Rich':(4,5)}
    widths={'Narrow':(4,4),'Wide':(9,10),'Rich':(8,9)}
    for row,previous in zip(observations,old['observations'],strict=True):
        case=row['case']
        assert row['case']==previous['case']
        assert all(row[name] is True for name in (
            'probe_sources_released_before_next_batch','build_sources_released_after_join_teardown',
            'complete_results_verified','complete_schema_verified',
            'final_output_readable_after_session_close','final_output_credits_released'))
        assert row['whole_process_memory_claim'] is False
        for name in ('ranked_output_rows','ranked_output_buffer_bytes','probe_batches_released',
                'build_batches_released','peak_credited_bytes'):
            assert type(row[name]) is int and row[name]>=0,name
        assert row['peak_credited_bytes']>0
        expected,populations=baseline.reference(case)
        assert row['actual']==previous['actual']==expected
        assert row['ranked_output_rows']==previous['ranked_output_rows']==min(populations[1],case['cap'])
        assert row['probe_batches_released']==previous['probe_batches_released']==(case['rows']+case['batch_rows']-1)//case['batch_rows']
        assert row['build_batches_released']==previous['build_batches_released']==(127+2+16)//17+(61+2+16)//17
        assert len(row['stages'])==2
        for index,(stage,before) in enumerate(zip(row['stages'],previous['stages'],strict=True)):
            assert stage.keys()==before.keys()
            assert all(type(value) is int and value>=0 for value in stage.values())
            for key in ('rows','batches','logical_cells'):
                assert stage[key]==before[key]
            assert stage['rows']==populations[index]
            assert stage['logical_cells']==stage['rows']*widths[case['payload']][index]
            assert stage['mapped_payload_cells']==before['materialized_payload_cells']==stage['rows']*payloads[case['payload']][index]
            assert stage['materialized_payload_cells']==stage['materialized_payload_buffer_bytes']==0
            assert (stage['mapped_referenced_buffer_bytes']>0)==(stage['mapped_payload_cells']>0)
            assert (stage['batches']==0)==(stage['rows']==0)


def corruptions(observations,old,guard,sources):
    result=[]
    def refuse(name,mutate):
        rows=copy.deepcopy(observations)
        mutate(rows)
        try:
            validate_attribution(rows,old)
        except AssertionError:
            result.append(name)
        else:
            raise AssertionError('corruption accepted: '+name)
    refuse('missing_matrix_case',lambda rows: rows.pop())
    refuse('duplicate_matrix_case',lambda rows: rows.__setitem__(1,rows[0]))
    refuse('probe_owner_not_released',lambda rows: rows[0].__setitem__('probe_sources_released_before_next_batch',False))
    refuse('build_owner_not_released',lambda rows: rows[0].__setitem__('build_sources_released_after_join_teardown',False))
    refuse('unverified_schema',lambda rows: rows[0].__setitem__('complete_schema_verified',False))
    refuse('leaked_final_credit',lambda rows: rows[0].__setitem__('final_output_credits_released',False))
    refuse('whole_process_claim',lambda rows: rows[0].__setitem__('whole_process_memory_claim',True))
    refuse('inconsistent_complete_output',lambda rows: rows[1]['actual'].append({'invented':True}))
    refuse('compact_payload_cells_remain',lambda rows: rows[0]['stages'][0].__setitem__('materialized_payload_cells',1))
    refuse('compact_payload_buffers_remain',lambda rows: rows[0]['stages'][0].__setitem__('materialized_payload_buffer_bytes',1))
    refuse('narrow_control_mapped',lambda rows: rows[0]['stages'][0].__setitem__('mapped_payload_cells',1))
    def backing_missing(rows):
        item=next(row for row in rows if row['stages'][0]['mapped_payload_cells'])
        item['stages'][0]['mapped_referenced_buffer_bytes']=0
    refuse('mapped_backing_missing',backing_missing)
    def population(rows):
        item=next(row for row in rows if row['case']['payload']=='Wide' and row['stages'][0]['rows'])
        item['stages'][0]['rows']-=1
        item['stages'][0]['logical_cells']-=9
        item['stages'][0]['mapped_payload_cells']-=5
    refuse('internally_consistent_false_population',population)
    refuse('boolean_peak_bytes',lambda rows: rows[0].__setitem__('peak_credited_bytes',True))
    for name,mutate in (
        ('guard_process_not_drained',lambda item:item.__setitem__('process_group_drained',False)),
        ('guard_source_changed',lambda item:item['build_source_verification']['post_execution'].__setitem__('changed_paths',['invented.rs'])),
        ('guard_wrong_command',lambda item:item.__setitem__('command',[])),
    ):
        bad=copy.deepcopy(guard); mutate(bad)
        try:
            validate_guard(bad,ATTRIBUTION,sources)
        except AssertionError:
            result.append(name)
        else:
            raise AssertionError('corruption accepted: '+name)
    assert len(result)==17
    return result


def main():
    assert __debug__ and Path(__file__).resolve()==OUT/'tools/verify_join_mapping_diagnostics.py'
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    assert args.output.parent==OUT and not args.output.exists()
    _,closeout=accepted_runtime()
    assert closeout['merge_commit']==BASE
    sources=source_inventory()
    files={str(Path(__file__)):content(Path(__file__))}
    checks={}
    logs={}
    guards={}
    for key,(stem,command) in CHECKS.items():
        path=OUT/(stem+'.json')
        guards[key],logs[key]=guarded(path,command,sources)
        checks[key]=str(path)
        for item in (path,path.with_suffix('.log')):
            files[str(item)]=content(item)
    names=passed_tests(logs['native_tests'])
    assert re.search(r'Ran 20 tests in [\d.]+s\n\nOK\n',logs['ci_cleanup_tests'])
    cleanup=OUT/'ci-cleanup-regression-r1.json'
    cleanup_result=read(cleanup)
    assert cleanup_result['status']=='passed_regression_control'
    assert cleanup_result['original_runner_rejects_regression'] and cleanup_result['expected_test_errors']==1
    assert cleanup_result['native_query_executions']==0
    assert cleanup_result['regression_tests']==content(ROOT/'scripts/test_ci_native_tests.py')
    for item in (cleanup,OUT/'tools/check_cleanup_regression.py'):
        files[str(item)]=content(item)
    assert all(sum(name.endswith('::'+required) for name in names)==1 for required in REQUIRED_TESTS)
    attributed=passed_tests(logs['attribution'])
    assert len(attributed)==2 and {name.rsplit('::',1)[-1] for name in attributed}==ATTRIBUTION_TESTS
    old_path=OUT/'baseline-attribution-observations-r1.json'
    assert content(old_path)['sha256']=='d3ad390c2e99560f76aa717611480a42e1ae56af5a310224fb96baa9d68e54a1'
    old=read(old_path)
    assert old['status']=='passed_baseline_attribution' and old['internal_native_fixtures']==102
    baseline.validate_observations(old['observations'])
    prefix='JOIN_RANKING_ATTRIBUTION '
    observations=[json.loads(line[len(prefix):]) for line in logs['attribution'].splitlines() if line.startswith(prefix)]
    validate_attribution(observations,old)
    rejected=corruptions(observations,old,guards['attribution'],sources)
    for item in (old_path,Path(baseline.__file__)):
        files[str(item)]=content(item)
    ci_path=OUT/'candidate-ci-inventory-r1.json'
    ci=read(ci_path)
    assert ci['schema']=='shardloom.join_mapping_ci_inventory.v1'
    assert ci['status']=='passed_actual_native_inventory' and ci['exact_ignored_ownership']
    assert ci['source_fingerprint_sha256']==digest(sources) and ci['query_executions']==0
    assert len(ci['ignored'])==36 and ci['ignored']==read(ROOT/'.github/ci-native-baseline.json')['ignored_tests']
    for name,expected in ci['files'].items():
        assert content(Path(name))==expected
        files[name]=expected
    files[str(ci_path)]=content(ci_path)
    original_failures={}
    for path in sorted(OUT.glob('candidate-*.json')):
        item=read(path)
        if item.get('status')=='failed':
            assert item['process_group_drained'] and item['direct_child_reaped']
            assert content(path.with_suffix('.log'))['sha256']==item['log_sha256']
            original_failures[path.name]=dict(receipt=content(path),log=content(path.with_suffix('.log')))
    assert source_inventory()==sources
    result=dict(schema='shardloom.join_mapping_candidate_diagnostics.v1',
        status='passed_candidate_diagnostics',native_query_executions_during_verification=0,
        candidate_acceptance_claimed=False,engine_timing_claimed=False,whole_process_memory_claim=False,
        diagnostic_source_fingerprint_sha256=digest(sources),required_tests=REQUIRED_TESTS,
        ignored_ci_registered=True,checks=checks,files=files,original_failures_preserved=original_failures,
        attribution=dict(internal_native_fixtures=102,matrix_cases=96,ordinary_regression_cases=6,
            complete_results_verified=True,complete_schema_verified=True,all_owner_checks_passed=True,
            baseline_materialized_payload_cells=old['materialized_payload_cells'],
            baseline_materialized_payload_buffer_bytes=old['materialized_payload_buffer_bytes'],
            candidate_mapped_payload_cells=sum(stage['mapped_payload_cells'] for row in observations for stage in row['stages']),
            candidate_materialized_payload_cells=0,candidate_materialized_payload_buffer_bytes=0,
            byte_measurement='Emitted payload buffers and referenced mapped backing; excludes scratch, decode work and other provider writes.'),
        observations=observations,rejected_corruptions=rejected)
    with args.output.open('x') as stream:
        json.dump(result,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({key:result[key] for key in ('status','attribution','rejected_corruptions')}))


if __name__=='__main__':
    main()
