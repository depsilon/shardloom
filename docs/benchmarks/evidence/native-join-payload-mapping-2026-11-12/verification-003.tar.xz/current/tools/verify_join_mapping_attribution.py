"""Unactivated verifier for the accepted runtime's internal join/ranking attribution."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

OUT = Path(__file__).resolve().parents[1]
assert OUT == Path('/Users/dylan/LocalData/shardloom/join-mapping-2026-11-11')
assert Path(__file__).resolve() == OUT/'tools/verify_join_mapping_attribution.py'
import join_mapping_common as common
from query_surface.evidence import identity

W = common.W
DEST = OUT/'baseline-attribution-observations-r1.json'
GUARD = OUT/'baseline-attribution-r3.json'
LOG = GUARD.with_suffix('.log')
SOURCES = OUT/'baseline-diagnostic-sources-r3'
FIXTURE = 'shardloom-vortex/src/local_primitives/native_relational_join_mapping_attribution_tests.rs'
PARENT = 'shardloom-vortex/src/local_primitives/native_relational_join_tests.rs'
FEATURES = 'shardloom-python/python-native,shardloom-vortex/native-encoded-exchange-experiment'
COMMAND = ['cargo', 'test', '--offline', '--locked', '--workspace', '--lib',
    '--features', FEATURES, 'successive_join_ranked_payload', '--',
    '--include-ignored', '--show-output', '--test-threads=1']
TESTS = {'successive_join_ranked_payloads_release_sources_and_match_independent_rows',
    'successive_join_ranked_payload_work_attribution_matrix'}


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=W, text=True, timeout=90).strip()


def expected_cases():
    result = []
    for products_first in (False, True):
        for entity_left in (False, True):
            for product_left in (False, True):
                for payload in ('Narrow', 'Wide', 'Rich'):
                    for rows in (0, 17, 257, 8191):
                        ordinal = len(result)
                        result.append(dict(products_first=products_first, entity_left=entity_left,
                            product_left=product_left, payload=payload, rows=rows,
                            batch_rows=(17, 257, 2048)[ordinal % 3],
                            cap=(1, 31, 1024)[(ordinal // 3) % 3]))
    assert len(result) == 96
    return result


def reference(case):
    """Complete independent result from literal input identities, not native output."""
    rows = []
    stage_rows = [0, 0]
    for number in range(case['rows']):
        entity = None if number % 29 == 0 else (number * 17 + 43) % 137
        product = None if number % 31 == 0 else (number * 7 + 23) % 71
        matched_entity = entity is not None and entity < 127
        matched_product = product is not None and product < 61
        entity_survives = matched_entity or case['entity_left']
        product_survives = matched_product or case['product_left']
        first_survives = product_survives if case['products_first'] else entity_survives
        stage_rows[0] += int(first_survives)
        stage_rows[1] += int(entity_survives and product_survives)
        if not (entity_survives and product_survives):
            continue
        row = dict(id=number, v=None if number % 11 == 0 else (number * 13 + 19) % 101 - 50,
            r=entity % 7 if matched_entity and entity % 17 else None,
            c=product % 7 if matched_product and product % 17 else None)
        if case['payload'] != 'Narrow':
            row['t'] = None if number % 23 == 0 else f'μλ:{number:05}:' + 'AbÇ' * 32
            row['rt'] = f'entity:{entity}:' + 'αλ' * 12 if matched_entity else None
            row['ct'] = f'product:{product}:' + 'αλ' * 12 if matched_product else None
        if case['payload'] == 'Wide':
            for name in ('t2', 't3', 't4'):
                row[name] = f'{name}:{number}:' + '猫\0xy' * 16
        if case['payload'] == 'Rich':
            row['items'] = None if number % 7 == 0 else [] if number % 5 == 0 else [number, None, -number]
            row['detail'] = None if number % 13 == 0 else dict(
                score=None if number % 3 == 0 else number - 41, label=f'λ\0猫:{number}')
        rows.append(row)
    rows.sort(key=lambda row: (row['v'] is not None, row['v'] or 0, row['id']))
    return rows[:case['cap']], stage_rows


def validate_observations(observations):
    assert [row['case'] for row in observations] == expected_cases()
    payloads = {'Narrow': (0, 0), 'Wide': (5, 6), 'Rich': (4, 5)}
    widths = {'Narrow': (4, 4), 'Wide': (9, 10), 'Rich': (8, 9)}
    for row in observations:
        case = row['case']
        assert len(row['stages']) == 2
        assert all(row[key] is True for key in ('probe_sources_released_before_next_batch',
            'build_sources_released_after_join_teardown', 'complete_results_verified',
            'complete_schema_verified',
            'final_output_readable_after_session_close', 'final_output_credits_released'))
        assert row['whole_process_memory_claim'] is False
        expected, stage_rows = reference(case)
        assert row['actual'] == expected
        assert [stage['rows'] for stage in row['stages']] == stage_rows
        assert row['ranked_output_rows'] == len(row['actual']) == min(row['stages'][1]['rows'], case['cap'])
        assert row['probe_batches_released'] == (case['rows'] + case['batch_rows'] - 1)//case['batch_rows']
        # Both dimension populations include two unmatchable NULL keys.
        assert row['build_batches_released'] == (127 + 2 + 16)//17 + (61 + 2 + 16)//17
        assert row['peak_credited_bytes'] > 0
        assert row['ranked_output_buffer_bytes'] >= 0
        assert case['rows'] >= row['stages'][0]['rows'] >= row['stages'][1]['rows'] >= 0
        for index, stage in enumerate(row['stages']):
            assert stage['logical_cells'] == stage['rows']*widths[case['payload']][index]
            assert stage['mapped_payload_cells'] == stage['mapped_referenced_buffer_bytes'] == 0
            assert stage['materialized_payload_cells'] == stage['rows']*payloads[case['payload']][index]
            assert (stage['batches'] == 0) == (stage['rows'] == 0)
            if stage['materialized_payload_cells']:
                assert stage['materialized_payload_buffer_bytes'] > 0
            else:
                assert stage['materialized_payload_buffer_bytes'] == 0


def main():
    assert not DEST.exists()
    runtime, closeout = common.accepted_runtime()
    assert git('merge-base', '--is-ancestor', closeout['merge_commit'], 'HEAD') == ''
    changed = git('diff', '--name-only', closeout['merge_commit']).splitlines()
    changed += git('ls-files', '--others', '--exclude-standard').splitlines()
    assert all(name.startswith('docs/') for name in changed), changed
    guard = read(GUARD)
    assert guard['status'] == 'passed' and guard['returncode'] == 0
    assert guard['fixed_source_validation'] and not guard['allow_lockfile_update']
    assert guard['direct_child_reaped'] and guard['process_group_drained']
    assert guard['command'] == COMMAND and guard['cwd'] == str(W)
    assert guard['log_sha256'] == digest(LOG)
    assert guard['base'] == closeout['merge_commit']
    assert not guard['query_workload']
    changed_sources = {name for name in guard['changed_source_inventory'] if not name.startswith('docs/')}
    assert changed_sources == {PARENT, FIXTURE}
    proof = {name: identity(path) for name, path in (
        ('guard', GUARD), ('log', LOG), ('verifier', Path(__file__)),
        ('accepted_closeout', common.CLOSEOUT), ('common', Path(common.__file__)))}
    for name, relative in (('fixture', FIXTURE), ('parent', PARENT)):
        path = SOURCES/Path(relative).name
        item = identity(path)
        assert dict(bytes=item['generation']['bytes'], sha256=item['sha256']) == guard['build_sources'][relative]
        assert guard['changed_source_inventory'][relative] == guard['build_sources'][relative]
        proof[name] = item
    parent_before = subprocess.check_output(['git', 'show', closeout['merge_commit']+':'+PARENT], cwd=W)
    parent_after = (SOURCES/Path(PARENT).name).read_bytes()
    expected_addition = b'\n#[path = "native_relational_join_mapping_attribution_tests.rs"]\nmod mapping_attribution_tests;\n'
    assert parent_after == parent_before + expected_addition
    assert (W/PARENT).read_bytes() == parent_before and not (W/FIXTURE).exists()
    log = LOG.read_text()
    passed = re.findall(r'^test (\S+) \.\.\. ok$', log, re.MULTILINE)
    assert len(passed) == 2 and {name.rsplit('::', 1)[-1] for name in passed} == TESTS
    assert 'test result: FAILED' not in log
    summaries = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log, re.MULTILINE)
    assert summaries and sum(int(row[0]) for row in summaries) == 2
    assert all(int(row[1]) == int(row[2]) == 0 for row in summaries)
    prefix = 'JOIN_RANKING_ATTRIBUTION '
    observations = [json.loads(line[len(prefix):]) for line in log.splitlines() if line.startswith(prefix)]
    validate_observations(observations)
    # Prove the parser refuses missing/duplicated rows, altered resource evidence,
    # unexpected mapped output in the baseline, and inconsistent complete results.
    controls = []
    def reject(label, mutate):
        rows = json.loads(json.dumps(observations)); mutate(rows)
        try:
            validate_observations(rows)
        except AssertionError:
            controls.append(label)
        else:
            raise AssertionError('corruption accepted: '+label)
    reject('missing_matrix_row', lambda rows: rows.pop())
    reject('duplicate_matrix_row', lambda rows: rows.__setitem__(1, rows[0]))
    reject('probe_owner_not_released', lambda rows: rows[0].__setitem__('probe_sources_released_before_next_batch', False))
    reject('build_owner_not_released', lambda rows: rows[0].__setitem__('build_sources_released_after_join_teardown', False))
    reject('mapped_baseline', lambda rows: rows[0]['stages'][0].__setitem__('mapped_payload_cells', 1))
    reject('fabricated_count', lambda rows: rows[0]['stages'][0].__setitem__('materialized_payload_cells', 1))
    def shrink_intermediate(rows):
        item = next(row for row in rows if row['case']['payload'] == 'Wide'
            and row['stages'][0]['rows'] > row['stages'][1]['rows'])
        stage = item['stages'][0]
        stage['rows'] -= 1
        stage['logical_cells'] -= 9
        stage['materialized_payload_cells'] -= 5
    reject('internally_consistent_false_stage_population', shrink_intermediate)
    reject('inconsistent_complete_output', lambda rows: rows[1]['actual'].append({'invented': True}))
    reject('leaked_final_credit', lambda rows: rows[0].__setitem__('final_output_credits_released', False))
    reject('whole_process_claim', lambda rows: rows[0].__setitem__('whole_process_memory_claim', True))
    reject('unverified_schema', lambda rows: rows[0].__setitem__('complete_schema_verified', False))
    result = dict(schema='shardloom.join_mapping_baseline_attribution.v1',
        status='passed_baseline_attribution', scored_query_executions=0,
        internal_native_fixtures=102, matrix_cases=96, ordinary_regression_cases=6,
        complete_results_verified=True, complete_schema_verified=True,
        probe_sources_released_before_next_batch=True,
        build_sources_released_after_join_teardown=True, candidate_runtime_enabled=False,
        accepted_sources_restored=True, whole_process_memory_claim=False,
        source_root=str(W), accepted_merge=closeout['merge_commit'], runtime=runtime,
        source_fingerprint_sha256=closeout['source_fingerprint_sha256'],
        materialized_payload_cells=sum(stage['materialized_payload_cells'] for row in observations for stage in row['stages']),
        materialized_payload_buffer_bytes=sum(stage['materialized_payload_buffer_bytes'] for row in observations for stage in row['stages']),
        byte_measurement='Buffers of emitted compact payload columns only; excludes scratch and does not count every provider write.',
        mapped_payload_cells=0, tests=passed, rejected_corruptions=controls,
        observations=observations, proof=proof)
    with DEST.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps({key:result[key] for key in ('status', 'internal_native_fixtures',
        'materialized_payload_cells', 'materialized_payload_buffer_bytes', 'scored_query_executions')}))


if __name__ == '__main__':
    main()
