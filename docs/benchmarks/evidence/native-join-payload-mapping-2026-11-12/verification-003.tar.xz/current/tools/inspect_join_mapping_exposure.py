"""Read-only inventory of frozen 10k declarations for join-to-ranking shapes."""
import hashlib
import json
import sys
from pathlib import Path

FROZEN = Path('/Users/dylan/LocalData/shardloom/expanded-query-2026-11-03/investigation-original-harness-r1')
DESIGN = Path('/Users/dylan/LocalData/shardloom/expanded-query-2026-11-03/design.json')
REPO = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
sys.path[:0] = [str(FROZEN / 'python/src'), str(FROZEN / 'benchmarks/traditional_analytics')]
from query_surface.corpus import corpus
from query_surface.expanded_catalog import build, spaces


def walk(node, path='root', ancestors=()):
    yield node, path, ancestors
    for i, child in enumerate(node.inputs):
        yield from walk(child, f'{path}/{i}', (node,) + ancestors)


def through(node, allowed):
    chain = []
    while node.op in allowed and len(node.inputs) == 1:
        if node.op == 'project' and not all(expression.op == 'column'
                                           for _, expression in node.args):
            break
        chain.append(node)
        node = node.inputs[0]
    return node, chain


def schemas(node):
    return [{'name': n, 'type': t.name, 'nullable': t.nullable,
             'parameters': list(t.parameters)} for n, t in node.schema]


def main():
    design = json.loads(DESIGN.read_text())
    assert hashlib.sha256(DESIGN.read_bytes()).hexdigest() == 'fd0a2604c9abc888a7a24ba75078569fc33e354b16cc98372977c15306a39216'
    assert len(design['cases']) == 10000
    defs = {s.name: s for s in spaces()}
    originals = {c.id: c for c in corpus(interactions='all', include_pending=False)}
    cases, chains, strict, star = [], [], [], []
    for row in design['cases']:
        item = build(row, defs) if 'cell' in row else originals[row['id']]
        assert item.identity == row['case_identity'], row['id']
        nodes = list(walk(item.relation))
        join_nodes = [(n, p) for n, p, _ in nodes if n.op == 'join']
        if item.archetype.startswith('star_'):
            if len(join_nodes) >= 2:
                agg_nodes = [(n, p) for n, p, _ in nodes if n.op == 'aggregate']
                star.append({'id': item.id, 'identity': item.identity,
                             'join_kinds': [n.args[2] for n, _ in join_nodes],
                             'join_widths': [len(n.schema) for n, _ in join_nodes],
                             'result_width': len(item.relation.schema),
                             'result_schema': schemas(item.relation),
                             'aggregate_barrier_paths': [p for _, p in agg_nodes],
                             'sort_count': sum(n.op == 'sort' for n, _, _ in nodes),
                             'limit_count': sum(n.op == 'limit' for n, _, _ in nodes)})
        # Chains are maximal join sequences where each next join consumes the prior
        # join through only direct projects. Filters are separately recorded and
        # never satisfy the strict direct-project predicate.
        for node, path, ancestors in nodes:
            if node.op != 'join':
                continue
            child_info = []
            for i, child in enumerate(node.inputs):
                base, wrappers = through(child, {'project', 'filter'})
                if base.op == 'join':
                    kinds = [n.args[2] for n in [base, node]]
                    child_info.append((i, base, wrappers, kinds))
            if child_info:
                assert len(child_info) == 1, 'branching join tree requires explicit inventory'
                i, base, wrappers, kinds = child_info[0]
                wrapper_ops = [n.op for n in wrappers]
                record = {'id': item.id, 'identity': item.identity, 'outer_join_path': path,
                          'inner_join_path': path + '/' + str(i) + '/0' * len(wrappers), 'join_kinds': kinds,
                          'wrapper_ops_outer_to_inner': wrapper_ops,
                          'direct_project_only': all(op == 'project' for op in wrapper_ops),
                          'filter_present': 'filter' in wrapper_ops,
                          'widths': {'inner_join': len(base.schema), 'outer_join': len(node.schema)},
                          'inner_schema': schemas(base), 'outer_schema': schemas(node),
                          'ancestor_operators': [n.op for n in ancestors],
                          'aggregate_barrier': any(n.op == 'aggregate' for n in ancestors)}
                chains.append(record)
        # identify sort+finite-limit with only direct projections between ranking
        for lim, lpath, _ in nodes:
            if lim.op != 'limit':
                continue
            assert len(lim.args) == 2 and all(type(v) is int and v >= 0 for v in lim.args)
            if lim.args[0] == 0:
                continue
            sort, projwrap = through(lim.inputs[0], {'project'})
            if sort.op != 'sort':
                continue
            src, srcwrap = through(sort.inputs[0], {'project'})
            # Filters intentionally stop the strict path. Any join chain anywhere
            # beneath the sort's immediate input is reported separately only if
            # direct project wrappers expose it.
            if src.op == 'join':
                base, parents = src, []
                while True:
                    candidates = [(i, c) for i, c in enumerate(base.inputs)
                                  if through(c, {'project'})[0].op == 'join']
                    if not candidates:
                        break
                    i, child = candidates[0]
                    child_base, wrappers = through(child, {'project'})
                    parents.append({'kind': base.args[2], 'width': len(base.schema),
                                    'schema': schemas(base), 'path': lpath})
                    base = child_base
                if len(parents) >= 1:
                    strict.append({'id': item.id, 'identity': item.identity,
                                   'limit_path': lpath, 'join_levels': len(parents)+1,
                                   'outer_to_inner': parents})
        cases.append(item.id)
    assert len(cases) == len(set(cases)) == 10000
    assert not any(name in sys.modules for name in ('shardloom._native', 'polars', 'duckdb'))
    replay = REPO / 'scripts/shared_followthrough_join_replay.py'
    lines = replay.read_text().splitlines()
    source_rows = {str(n): lines[n-1].strip() for n in range(8, 17)}
    source_rows.update({'fixture_shape': lines[5:14]})
    report = {
        'status': 'passed', 'scope': 'declaration_inventory_only',
        'native_imports': False, 'queries_or_builds': False, 'timing': False,
        'design': str(DESIGN), 'design_sha256': hashlib.sha256(DESIGN.read_bytes()).hexdigest(),
        'inventory_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'frozen_loaded_sources': {str(path.relative_to(FROZEN)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted({Path(module.__file__).resolve() for module in sys.modules.values()
                                if getattr(module, '__file__', None)
                                and Path(module.__file__).resolve().is_relative_to(FROZEN)})
            if path.is_file()},
        'design_case_count': len(cases), 'unique_case_ids': len(set(cases)),
        'identity_verification': 'each reconstructed declaration identity equals design case_identity',
        'target_predicate': 'limit -> sort -> (zero or more direct project nodes) -> join; a second join must feed the first join through zero or more direct project nodes; filters are excluded',
        'target_count': len(strict), 'target_cases': strict,
        'join_chain_count': len(chains), 'join_chains': chains,
        'aggregate_barrier_controls': star,
        'followthrough_replay_case_grid': {
            'declarations_at_source_lines_9_10_12': [
                {'source_line': 9, 'name': 'star_entity_first', 'products_first': False,
                 'report': False, 'wide': False, 'outer': False},
                {'source_line': 10, 'name': 'star_product_first', 'products_first': True,
                 'report': False, 'wide': False, 'outer': False},
                {'source_line': 12, 'name': 'wide_outer_star', 'products_first': False,
                 'report': False, 'wide': True, 'outer': True}],
            'source_lines': source_rows,
            'payload_and_output': {
                'literal_payload_generator': "text = f'μλ:{row:05}:' + 'AbÇ' * 24 if row % 23 else None",
                'genuine_wide_text': True,
                'wide_group_key': 't (nullable Unicode text; each non-null value contains 24 repetitions of AbÇ plus the row label)',
                'wide_output_fields': ['r', 'c', 't', 'count', 'sum'],
                'wide_output_width': 5,
                'wide_output_types_from_literal_reference': {'r': 'nullable integer group key', 'c': 'nullable integer group key', 't': 'nullable utf8 text', 'count': 'integer count', 'sum': 'nullable float64 after exact integer sum conversion'},
                'ordinary_output_fields': ['r', 'c', 'count', 'sum'],
                'ordinary_output_width': 4,
                'report_output_fields': ['r', 'count', 'sum'],
                'report_output_width': 3,
                'report_intermediate_width': 2
            },
            'interpretation': 'Replay validates complete grouped results, not ranking. Source lines 9/10/12 name the two star orders and wide outer-star controls. Each has four row/batch regimes. The wide outer-star shape carries generated Unicode text as a grouping key and has five output fields. Its dimensions deliberately contain duplicates, so they cannot stand in for a completed unique-dimension build proof.'
        },
        'limitations': [
            'The reconstructed AST declares schemas, not runtime values, row counts, uniqueness proofs, activation, or costs.',
            'Physical types of replay fixture values are inferred only where literal Python constructors make them explicit; no external schema is declared for those generated rows.',
            'Replay has no sort or limit; ranking relationship is absent.',
            'No selection of a final cohort or semantic/performance judgment is made.'
        ]
    }
    out = Path('/Users/dylan/.codex/tmp/shardloom-join-mapping-case-inventory.json')
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': report['status'], 'cases': len(cases), 'identity_unique': len(set(cases)),
                      'target_count': len(strict), 'join_chain_count': len(chains), 'output': str(out)}))


if __name__ == '__main__':
    main()
