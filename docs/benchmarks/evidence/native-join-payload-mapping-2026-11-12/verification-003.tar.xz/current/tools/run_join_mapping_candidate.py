"""Admit the single fixed 940-request release candidate after exact local proof.

No request, worker, reference, capture loop, resource limit or timing rule changes.
Planning binds the release runtime and sources before any candidate request runs.
"""
import argparse
import gzip
import json
import math
import os
from pathlib import Path
import sys

import run_join_mapping_baseline as baseline
import verify_join_mapping_diagnostics as diagnostics
from join_mapping_common import E, OUT, W, content, digest, read
import replay_join_mapping_baseline_r2 as baseline_replay

BASE = diagnostics.BASE
from query_surface.evidence import identity
from query_surface.expanded_run import verify

TARGET = OUT / 'candidate-r1'
PROTOCOL = OUT / 'candidate-protocol-r1.json'
BASELINE_RESULT = OUT / 'baseline-verified-r1.json'
RUNTIME = OUT / 'runtime-r1'
BUILD = OUT / 'candidate-release-build-r1.json'
DIAGNOSTICS = OUT / 'candidate-diagnostics-r1.json'
CI = OUT / 'candidate-ci-inventory-r1.json'
PYTHON = '/opt/homebrew/opt/python@3.13/libexec/bin/python3'
BUILD_COMMAND = ['env', 'PYO3_PYTHON=' + PYTHON, 'cargo', 'build', '--offline', '--locked',
    '--release', '--features', 'release-user-surfaces', '-p', 'shardloom-cli', '-p', 'shardloom-python']


def baseline_proof():
    assert content(baseline.PROTOCOL)['sha256'] == '29165122564ca6442f5ecb2caf76164c42307973063e7fbe3c0676bcf00a29c8'
    assert content(BASELINE_RESULT)['sha256'] == '9899c58304e985e6b467279f6b5d66bdd68ef4690225eb6c0e5cedd6e1a1bd8d'
    clarification = OUT / 'baseline-replay-command-clarification-r1.json'
    assert content(clarification)['sha256'] == '7e44110c6fe280e22a9e384570dae154b8040778e339354219223161c1f34c36'
    design, inputs, frozen, binding = baseline.admission(E)
    protocol, result = read(baseline.PROTOCOL), read(BASELINE_RESULT)
    assert result['status'] == 'passed_complete_baseline_cohort'
    assert result['accepted_merge'] == BASE
    assert result['selected_cases'] == result['new_attempts'] == 940 and result['reused_saved_cases'] == 0
    assert result['original_controls'] == 580 and result['new_compositions'] == 360
    assert result['outcomes'] == result['new_outcomes'] == {'passed': 940}
    assert result['complete_performance_result_valid'] and result['all_selected_results_correct']
    assert result['all_engine_clocks_valid'] and result['native_no_fallback']
    assert result['primary_clock'] == 'engine_execution_seconds'
    assert not result['complete_10k_performance_claim'] and not result['full43_claim']
    assert result['protocol'] == identity(baseline.PROTOCOL)
    assert result['runtime_binding'] == binding == protocol['runtime_binding']
    assert result['selection'] == protocol['selection'] == identity(baseline.SELECTION)
    assert result['verifier'] == identity(Path(baseline_replay.__file__))
    assert result['replay_command_clarification'] == identity(clarification)
    done, guard_path = baseline_replay.capture_receipts(binding)
    assert result['complete'] == identity(baseline.TARGET / 'complete.json')
    assert result['guard'] == identity(guard_path) and result['ledger'] == done['ledger']
    verify([result[key] for key in ('case_rows', 'guard', 'complete', 'ledger', 'reuse', 'replay_command_clarification')])
    selected = read(baseline.SELECTION)['cases']
    with gzip.open(result['case_rows']['path'], 'rt') as stream:
        rows = [json.loads(line) for line in stream]
    assert len(rows) == len(selected) == 940
    for ordinal, (row, case) in enumerate(zip(rows, selected, strict=True)):
        assert row['cohort_ordinal'] == ordinal and row['original_seq'] == case['original_seq']
        assert row['kind'] == case['kind']
        assert row['id'] == case['case']['id'] and row['case_identity'] == case['case']['case_identity']
        assert row['result']['status'] == 'passed'
        seconds = row['result']['engine_seconds']
        assert type(seconds) in (int, float) and math.isfinite(seconds) and seconds >= 0
    assert math.fsum(row['result']['engine_seconds'] for row in rows) == result['engine_execution_seconds'] == 653.057359901
    replay = baseline.passed_guard('baseline-replay-r2')
    assert replay['command'] == [PYTHON, str(Path(baseline_replay.__file__))]
    files = [baseline.PROTOCOL, BASELINE_RESULT, baseline.REUSE, clarification, Path(baseline_replay.__file__),
        OUT / 'baseline-cases-r1.jsonl.gz', OUT / 'baseline-replay-r2.json', OUT / 'baseline-replay-r2.log',
        OUT / 'baseline-missing-r1.json', OUT / 'baseline-missing-r1.log',
        OUT / 'baseline-missing-r1/complete.json', OUT / 'baseline-missing-r1/binding.json',
        OUT / 'baseline-missing-r1/attempts.sqlite']
    files.extend(Path(item['path']) for item in binding['proof_files'])
    return protocol, result, design, inputs, frozen, files


def runtime_proof():
    sources = diagnostics.source_inventory()
    build, _ = diagnostics.guarded(BUILD, BUILD_COMMAND, sources)
    report = read(DIAGNOSTICS)
    assert report['schema'] == 'shardloom.join_mapping_candidate_diagnostics.v1'
    assert report['status'] == 'passed_candidate_diagnostics'
    assert report['diagnostic_source_fingerprint_sha256'] == digest(sources)
    assert report['native_query_executions_during_verification'] == 0
    assert report['ignored_ci_registered'] and not report['candidate_acceptance_claimed']
    assert report['required_tests'] == diagnostics.REQUIRED_TESTS
    files = [BUILD, BUILD.with_suffix('.log'), DIAGNOSTICS, CI]
    files.extend(source_review_proof(sources))
    for name, (stem, command) in diagnostics.CHECKS.items():
        path = OUT / (stem + '.json')
        assert report['checks'][name] == str(path)
        diagnostics.guarded(path, command, sources)
        files.extend((path, path.with_suffix('.log')))
    for name, expected in report['files'].items():
        assert content(Path(name)) == expected
        files.append(Path(name))
    old = read(OUT / 'baseline-attribution-observations-r1.json')
    observations = report['observations']
    attribution_guard = read(OUT / 'candidate-attribution-r4.json')
    diagnostics.validate_attribution(observations, old)
    assert diagnostics.corruptions(observations, old, attribution_guard, sources) == report['rejected_corruptions']
    attribution = report['attribution']
    assert attribution['internal_native_fixtures'] == 102 and attribution['matrix_cases'] == 96
    assert attribution['ordinary_regression_cases'] == 6
    assert attribution['complete_results_verified'] and attribution['complete_schema_verified']
    assert attribution['all_owner_checks_passed']
    assert attribution['baseline_materialized_payload_cells'] == old['materialized_payload_cells'] == 1214090
    assert attribution['baseline_materialized_payload_buffer_bytes'] == old['materialized_payload_buffer_bytes'] == 104059054
    assert attribution['candidate_mapped_payload_cells'] == sum(stage['mapped_payload_cells'] for row in observations for stage in row['stages']) == 1214090
    assert attribution['candidate_materialized_payload_cells'] == attribution['candidate_materialized_payload_buffer_bytes'] == 0
    assert not report['engine_timing_claimed'] and not report['whole_process_memory_claim']
    ci = read(CI)
    assert ci['schema'] == 'shardloom.join_mapping_ci_inventory.v1'
    assert ci['status'] == 'passed_actual_native_inventory' and ci['exact_ignored_ownership']
    assert ci['query_executions'] == 0 and ci['source_fingerprint_sha256'] == digest(sources)
    assert len(ci['ignored']) == 36 and ci['ignored'] == read(W / '.github/ci-native-baseline.json')['ignored_tests']
    for name, expected in ci['files'].items():
        assert content(Path(name)) == expected
        files.append(Path(name))
    checks = {
        'candidate-ci-verification-r3': [PYTHON, '-B', str(OUT / 'tools/verify_join_mapping_ci_inventory.py'),
            '--build', str(OUT / 'candidate-ci-build-r2.json'), '--output', str(CI)],
        'candidate-diagnostics-verification-r1': [PYTHON, '-B', str(OUT / 'tools/verify_join_mapping_diagnostics.py'),
            '--output', str(DIAGNOSTICS)],
        'candidate-freeze-runtime-r1': [PYTHON, '-B', str(OUT / 'tools/freeze_runtime.py'),
            '--build', BUILD.name, '--name', 'runtime-r1', '--profile', 'release'],
    }
    for stem, command in checks.items():
        path = OUT / (stem + '.json')
        diagnostics.guarded(path, command, sources)
        files.extend((path, path.with_suffix('.log')))
    freeze = OUT / 'runtime-r1-identity.json'
    record = read(freeze)
    assert record['status'] == 'passed' and record['profile'] == 'release'
    assert record['build_receipt'] == BUILD.name and record['build_receipt_identity'] == content(BUILD)
    assert record['build_source_fingerprint_sha256'] == digest(sources)
    assert record['native_query_executions'] == 0
    members = {Path(item['path']).name: item for item in record['files']}
    assert set(members) == {'shardloom', 'lib_native.dylib', '_native.abi3.so'}
    for name, item in members.items():
        assert Path(item['path']) == RUNTIME / name
        assert content(Path(item['path'])) == {key: item[key] for key in ('bytes', 'sha256')}
    assert content(RUNTIME / 'lib_native.dylib') == content(RUNTIME / '_native.abi3.so')
    files.extend((freeze, OUT / 'tools/freeze_runtime.py'))
    files.extend(installed_proof(sources))
    return build, files


def source_review_proof(sources):
    original = read(OUT / 'baseline-missing-r1.json')['build_sources']
    correction_path = OUT / 'ci-cleanup-correction-r1.json'
    correction = read(correction_path)
    assert correction['schema'] == 'shardloom.join_mapping_ci_cleanup_correction.v1'
    assert correction['status'] == 'verified_ci_evidence_fix_before_candidate_queries'
    assert correction['benchmark_queries_executed'] == 0
    assert correction['retain_independently_of_mapping_decision']
    assert correction['native_runtime_changed_by_fix'] is False
    assert correction['benchmark_supervisor_changed'] is False
    assert correction['candidate_source_fingerprint_sha256'] == digest(sources)
    paths = {'scripts/ci_native_tests.py', 'scripts/test_ci_native_tests.py'}
    assert set(correction['source_changes']) == paths
    for name, change in correction['source_changes'].items():
        assert change == dict(before=original[name], after=sources[name])
    regression = OUT / 'ci-cleanup-regression-r1.json'
    assert correction['regression_control'] == content(regression)
    control = read(regression)
    assert control['status'] == 'passed_regression_control'
    assert control['original_runner_rejects_regression'] and control['expected_test_errors'] == 1
    assert control['native_query_executions'] == 0
    assert control['original_runner'] == original['scripts/ci_native_tests.py']
    assert control['regression_tests'] == sources['scripts/test_ci_native_tests.py']
    review_path = OUT / 'pre-score-source-review-r1.json'
    review = read(review_path)
    assert review['schema'] == 'shardloom.join_mapping_source_review.v1'
    assert review['status'] == 'completed_pre_score_source_review'
    assert review['source_head'] == BASE and review['source_fingerprint_sha256'] == digest(sources)
    assert review['reviewed_changed_files'] == {name:item for name,item in sources.items()
        if original.get(name) != item}
    assert review['runtime_objections_reviewed'] == ['eligibility_and_alias_semantics',
        'validation_and_publication_order', 'owner_and_reservation_lifetime']
    assert review['ci_cleanup_reviewed'] and review['unresolved_in_scope_findings'] == []
    assert review['benchmark_queries_executed'] == 0 and review['candidate_protocol_absent_at_review']
    document = OUT / 'adversarial-review-r1.md'
    assert review['review_document'] == content(document)
    assert review['independent_ci_cleanup_correction'] == content(correction_path)
    return [correction_path, review_path, document, regression]


def installed_proof(sources):
    proof = OUT / 'installed-proof-r1'
    python = str(OUT / 'package-tools-r1/bin/python')
    requirements = W / '.github/requirements'
    commands = {
        'candidate-package-environment-r1': [PYTHON, '-m', 'venv', str(OUT / 'package-tools-r1')],
        'candidate-package-tools-r1': [python, '-I', '-m', 'pip', 'install', '--only-binary=:all:',
            '--require-hashes', '-r', str(requirements / 'ci-native-python-build.txt')],
        'candidate-wheelhouse-r1': [python, '-I', '-m', 'pip', 'download', '--only-binary=:all:',
            '--require-hashes', '-r', str(requirements / 'ci-native-python.txt'),
            '--dest', str(OUT / 'wheelhouse-r1')],
        'candidate-installed-r1': [python, '-B', str(W / 'scripts/prove_native_python_wheel.py'),
            '--repo-root', str(W), '--output-dir', str(proof),
            '--native-library', str(RUNTIME / '_native.abi3.so'), '--cli-binary', str(RUNTIME / 'shardloom'),
            '--wheelhouse', str(OUT / 'wheelhouse-r1')],
    }
    files = []
    for stem, command in commands.items():
        path = OUT / (stem + '.json')
        diagnostics.guarded(path, command, sources)
        files.extend((path, path.with_suffix('.log')))
    path = proof / 'report.json'
    report = read(path)
    assert report['schema_version'] == 'shardloom.native_python_wheel_proof.v1'
    assert report['status'] == 'passed' and report['installation_performed']
    assert report['scope'] == 'current_host_native_wheel_install_and_binding_integration'
    assert not report['publication_attempted'] and not report['performance_claim']
    assert report['uninstall_status'] == 'passed'
    assert report['build_tools']['setuptools'] == '84.0.0'
    assert report['build_tools']['wheel'] == '0.48.0'
    assert report['build_tools']['pip']
    assert 'artifact_reuse' not in report
    library, binary = content(RUNTIME / '_native.abi3.so'), content(RUNTIME / 'shardloom')
    for key in ('stage', 'integrity'):
        item = report[key]
        assert item['status'] == 'passed'
        assert item['native_library_sha256'] == library['sha256']
        assert item['cli_sha256'] == binary['sha256']
    integrity = report['integrity']
    assert integrity['schema_version'] == 'shardloom.native_python_wheel_integrity.v1'
    assert integrity['tag'].startswith('cp310-abi3-macosx_') and not integrity['published']
    wheel = proof / 'dist' / integrity['wheel']
    assert wheel.parent == proof / 'dist' and wheel.suffix == '.whl'
    assert content(wheel) == {'bytes': integrity['wheel_bytes'], 'sha256': integrity['wheel_sha256']}
    integration = report['integration']
    assert integration == read(proof / 'integration.json')
    assert integration['status'] == 'passed' and type(integration['tests']) is int and integration['tests'] > 0
    assert integration['failures'] == integration['errors'] == integration['skipped'] == 0
    loaded = report['installed_load']
    assert loaded == read(proof / 'load.log') and loaded['isolated_install']
    for key in ('package', 'native_library', 'cli'):
        installed = Path(loaded[key])
        assert installed.is_relative_to(proof / 'venv') and not installed.exists()
    names = ['build', 'create_environment', 'install_optional_consumer', 'install', 'load',
        'integration', 'uninstall', 'verify_uninstalled']
    assert [step['name'] for step in report['steps']] == names
    for step in report['steps']:
        assert step['returncode'] == 0
        assert step['timeout_seconds'] == (1200 if step['name'] == 'integration' else 600)
        assert step['log'] == step['name'] + '.log'
        log = proof / step['log']
        assert content(log)['sha256'] == step['log_sha256']
        files.append(log)
    files.extend((path, proof / 'integration.json', wheel, W / 'scripts/prove_native_python_wheel.py'))
    return files


def context():
    original, result, design, inputs, frozen, files = baseline_proof()
    build, current_files = runtime_proof()
    files.extend(current_files)
    files.extend(OUT / 'tools' / name for name in ('run_join_mapping_candidate.py',
        'replay_join_mapping_candidate.py', 'verify_join_mapping_diagnostics.py', 'verify_join_mapping_ci_inventory.py'))
    proof_files = [identity(path) for path in sorted(set(files))]
    runtime = dict(binary=identity(RUNTIME / 'shardloom'), library=identity(RUNTIME / '_native.abi3.so'))
    unique = {}
    for item in [*frozen, *proof_files, *runtime.values()]:
        if item['path'] in unique:
            assert unique[item['path']] == item
        unique[item['path']] = item
    frozen = list(unique.values()); verify(frozen)
    return dict(original=original, result=result, design=design, inputs=dict(inputs, runtime=runtime),
        selected=read(baseline.SELECTION), runtime=runtime, build=build, frozen=frozen, proof_files=proof_files)


def admission(root, require_protocol=True):
    assert root == E and __debug__
    ctx = context()
    binding = dict(schema='shardloom.join_mapping_candidate_runtime.v1', role='single_fixed_cohort_candidate',
        accepted_base=BASE, source_root=str(W), source_head=ctx['build']['head'],
        source_fingerprint_sha256=ctx['build']['build_source_fingerprint_sha256'],
        runtime=ctx['runtime'], proof_files=ctx['proof_files'], selection=identity(baseline.SELECTION),
        baseline_protocol=identity(baseline.PROTOCOL), target=str(TARGET),
        parent_interpreter=identity(Path(PYTHON).resolve()),
        baseline_replay_command_clarification=identity(OUT / 'baseline-replay-command-clarification-r1.json'),
        original_worker=ctx['original']['runtime_binding']['original_worker'],
        versioned_worker=identity(baseline.WORKER), composition_reference=identity(baseline.REFERENCE),
        frozen_harness_files=65, attempts_per_case=1, warmups=0, requested_repeats=0, fallback_allowed=False)
    protocol = dict(schema='shardloom.join_mapping_candidate_protocol.v1', status='frozen_before_candidate_queries',
        selected_count=940, original_controls=580, new_compositions=360,
        candidate_contract=ctx['original']['candidate_contract'],
        baseline_protocol=identity(baseline.PROTOCOL), baseline_result=identity(BASELINE_RESULT),
        selection=identity(baseline.SELECTION), design=identity(E / 'design.json'),
        inputs=identity(E / 'inputs.json'), frozen=identity(E / 'frozen.json'),
        execution=ctx['design']['execution'], runtime_binding=binding, cases=ctx['selected']['cases'],
        primary_clock='engine_execution_seconds', attempts_per_case=1, warmups=0, requested_repeats=0,
        selection_uses_timing=False, complete_10k_performance_claim=False, full43_claim=False,
        baseline_observations=dict(reused=0, newly_measured=940, result=identity(BASELINE_RESULT)),
        capture_changes='Unchanged capture loop, workers, requests, references, clocks, guards and cleanup; 940 fixed requests execute once.',
        supervision_change='Same join-mapping guard, resource limits and before/after-only full inventories; candidate source/build admission follows complete local validation.',
        isolation=ctx['original']['isolation'], performance_decision=ctx['original']['performance_decision'])
    if require_protocol:
        assert read(PROTOCOL) == protocol
    else:
        assert not PROTOCOL.exists() and not TARGET.exists()
        with PROTOCOL.open('x') as stream:
            json.dump(protocol, stream, indent=2, allow_nan=False); stream.write('\n')
    frozen = [*ctx['frozen'], identity(PROTOCOL)]; verify(frozen)
    return ctx['design'], ctx['inputs'], frozen, binding


def main():
    assert Path(__file__).resolve() == OUT / 'tools/run_join_mapping_candidate.py'
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', action='store_true')
    args = parser.parse_args()
    os.environ['POLARS_MAX_THREADS'] = '2'
    for path in (OUT, E):
        baseline.capture.require_local_path(path, Path.home(), sys.platform)
    if args.plan:
        admission(E, require_protocol=False)
        print(json.dumps(dict(status='frozen_before_candidate_queries', selected=940, query_executions=0)))
    else:
        protocol = read(PROTOCOL)
        baseline.capture.TARGET_NAME = str(TARGET)
        baseline.capture.observe(E, False, admission, baseline.common.previous.HistoricalSubset(),
            [row['case'] for row in protocol['cases']], worker=baseline.WORKER,
            composition_reference=baseline.REFERENCE)


if __name__ == '__main__':
    main()
