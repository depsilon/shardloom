"""Declaration and literal reference controls only; never load native execution."""
import hashlib
import importlib.util
import copy
import json
from pathlib import Path
import sys

FROZEN = Path('/Users/dylan/LocalData/shardloom/expanded-query-2026-11-03/investigation-original-harness-r1')
SOURCE = Path('/Users/dylan/LocalData/shardloom/join-mapping-2026-11-11/client/join_mapping_cases.py')
sys.path[:0] = [str(FROZEN/'python/src'), str(FROZEN/'benchmarks/traditional_analytics')]
spec = importlib.util.spec_from_file_location('mapping_draft', SOURCE)
draft = importlib.util.module_from_spec(spec)
spec.loader.exec_module(draft)
from query_surface.adapters import relation_sql
from query_surface.semantics import compare, result_from_record, result_record


cases = draft.declarations()
for case in cases:
    relation = draft.validate(case)
    sql = relation_sql(relation, {name: [Path('/native-input/'+name+'.parquet')]
        for name in relation.sources()})
    assert sql.count(' JOIN ') == 2 and relation.sources() == {'fact','entities','products'}
    assert len(relation.schema) == len({name for name, _ in relation.schema})

facts = []
for row_id, entity, product, signed, optional in (
    (0,1,10,4,None), (1,2,99,-2,7), (2,None,10,1,-3), (3,4,11,-5,7), (4,1,11,-2,None),
):
    facts.append(dict(row_id=row_id, entity_id=entity, product_id=product,
        signed_value=signed, optional_value=optional,
        long_text='λ-long-'+str(row_id), unique_text='unique-'+str(row_id),
        unicode_text='μ雪'+str(row_id), optional_text=None if row_id==2 else 'optional',
        items=None if row_id==2 else [None,row_id],
        detail=None if row_id==2 else dict(score=None if row_id==3 else row_id,label='α')))
entities = draft.unique_dimension([
    dict(entity_id=1,region='north',entity_label='one'),
    dict(entity_id=2,region='south',entity_label='two')], 'entities')
products = draft.unique_dimension([
    dict(product_id=10,product_category='ten'),
    dict(product_id=11,product_category='eleven')], 'products')

# Literal expected ordering for the five authored facts; no AST evaluator or
# native result supplies these expectations. Dimension order must not change it.
orders = {
    'wide_0_inner_inner': [4,0], 'wide_0_inner_left': [1,4,0],
    'wide_0_left_inner': [3,4,2,0], 'wide_0_left_left': [3,1,4,2,0],
    'wide_1_inner_inner': [4,0], 'wide_1_inner_left': [1,4,0],
    'wide_1_left_inner': [3,4,2,0], 'wide_1_left_left': [3,1,4,2,0],
    'rich_0': [3,1,4,2,0], 'rich_1': [3,1,4,2,0],
    'narrow_0': [4,0], 'narrow_1': [4,0], 'wide_one': [1],
    'rich_1024': [3,2,4,0], 'rich_tiny': [0,4], 'wide_tiny_one': [0],
    'wide_full_0': [4,0], 'wide_full_1': [4,0],
    'rich_full_0': [3,1,4,2,0], 'rich_full_1': [3,1,4,2,0],
    'wide_aliases': [2,1,3,0,4], 'rich_aliases': [0,4],
    'rich_empty': [], 'narrow_zero': [],
}
assert set(orders) == {scenario['name'] for scenario in draft.scenarios()}
for scenario in draft.scenarios():
    result = draft.reference(scenario, iter(facts), entities, products)
    alias = 'out_' if scenario['projection']=='both' else ''
    assert [row[alias+'row_id'] for row in result.rows] == orders[scenario['name']], scenario['name']
    keys = [{name: row[name] for name in ('row_id', 'entity_id', 'product_id', scenario['order_key'])}
        for row in facts]
    selected = draft.selected_facts(scenario, iter(keys), entities, products)
    assert [row['row_id'] for row in selected] == orders[scenario['name']]
    hydrated = (facts[row_id] for row_id in sorted(row['row_id'] for row in selected))
    assert draft.reference(scenario, hydrated, entities, products) == result
    assert draft.reference(scenario, reversed(facts), entities, products) == result
    compare(result, result_from_record(result_record(result)),
        draft.ResultContract(result.schema, ordered=True))
    for row in result.rows:
        fact = facts[row[alias+'row_id']]
        for name in draft.PAYLOAD[scenario['payload']]:
            assert row[alias+name] == fact[name]
        assert row[alias+'matched_entity_id'] == (fact['entity_id'] if fact['entity_id'] in entities else None)
        assert row[alias+'matched_product_id'] == (fact['product_id'] if fact['product_id'] in products else None)
        if scenario['projection']=='both':
            name = 'long_text' if scenario['payload']=='wide' else 'items'
            assert row['duplicate_payload'] == fact[name]

controls = 0
for field, value in (('id','altered'),('profile','missing'),('join_mapping_version',True)):
    altered = copy.deepcopy(cases[0])
    altered[field] = value
    try:
        draft.validate(altered)
    except ValueError:
        controls += 1
    else:
        raise AssertionError('changed case declaration accepted')
for field, value, message in (
    ('relation_sha256','0'*64,'output contract changed'),
    ('ordered',False,'declaration fields changed'),
    ('version',True,'unknown join mapping declaration version'),
    ('output_schema',[],'output contract changed'),
    ('profile','missing','fixed coverage schedule changed'),
):
    altered = copy.deepcopy(cases[0])
    altered['declaration'][field] = value
    altered['case_identity'] = draft.digest(altered['declaration'])
    altered['id'] = altered['id'].rsplit('_',1)[0] + '_' + altered['case_identity'][:12]
    if field=='profile':
        altered['profile'] = value
    try:
        draft.validate(altered)
    except ValueError as error:
        assert message in str(error), (field,str(error))
        controls += 1
    else:
        raise AssertionError('changed internally rehashed declaration accepted')
for table in ('entities','products'):
    key = draft.DIMENSIONS[table][0]
    for rows in ([{key:1},{key:1}], [{key:None}], [{key:True}]):
        try:
            draft.unique_dimension(rows, table)
        except ValueError:
            controls += 1
        else:
            raise AssertionError('invalid dimension proof was accepted')
for rows in ([facts[0],facts[0]], [facts[0],facts[1],facts[0]], [{**facts[0], 'row_id': -1}]):
    try:
        draft.reference(draft.scenarios()[0], rows, entities, products)
    except ValueError:
        controls += 1
    else:
        raise AssertionError('duplicate/reordered reference row proof was accepted')
assert not any(name == 'shardloom._native' or name.startswith('shardloom._native.') for name in sys.modules)
print(json.dumps(dict(status='passed_draft_declaration_and_literal_reference_controls',
    cases=len(cases), scenarios=len(orders), refusal_controls=controls,
    coverage=draft.coverage(cases), native_runtime_loaded=False, query_executions=0,
    sources={str(path):dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        for path in (SOURCE,Path(__file__))}), indent=2))
