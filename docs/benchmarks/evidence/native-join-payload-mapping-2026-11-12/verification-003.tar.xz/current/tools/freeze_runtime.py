"""Freeze all three runtime files from the guarded release build, without queries."""
import argparse
import json
from pathlib import Path
import shutil

import verify_join_mapping_diagnostics as diagnostics
from join_mapping_common import OUT, content, digest

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--build', required=True)
parser.add_argument('--name', required=True)
parser.add_argument('--profile', choices=('release',), required=True)
args = parser.parse_args()
assert __debug__ and Path(__file__).resolve() == OUT / 'tools/freeze_runtime.py'
assert args.name == 'runtime-r1' and args.build == 'candidate-release-build-r1.json'
command = ['env', 'PYO3_PYTHON=/opt/homebrew/opt/python@3.13/libexec/bin/python3',
    'cargo', 'build', '--offline', '--locked', '--release', '--features', 'release-user-surfaces',
    '-p', 'shardloom-cli', '-p', 'shardloom-python']
sources = diagnostics.source_inventory()
build_path = OUT / args.build
build, _ = diagnostics.guarded(build_path, command, sources)
source = Path(build['environment']['CARGO_TARGET_DIR']) / args.profile
destination = OUT / args.name
record_path = OUT / (args.name + '-identity.json')
assert not destination.exists() and not record_path.exists()
originals = {name: content(source / name) for name in ('shardloom', 'lib_native.dylib')}
destination.mkdir()
record = dict(status='passed', profile=args.profile, build_receipt=args.build,
    build_receipt_identity=content(build_path), build_source_fingerprint_sha256=digest(sources),
    files=[], native_query_executions=0)
for target_name, source_name in (('shardloom', 'shardloom'), ('lib_native.dylib', 'lib_native.dylib'),
        ('_native.abi3.so', 'lib_native.dylib')):
    original, copied = source / source_name, destination / target_name
    shutil.copy2(original, copied)
    assert content(copied) == content(original) == originals[source_name]
    record['files'].append(dict(path=str(copied), **originals[source_name]))
assert diagnostics.source_inventory() == sources
with record_path.open('x') as stream:
    json.dump(record, stream, indent=2, allow_nan=False); stream.write('\n')
print(json.dumps(record))
