"""Unactivated baseline protocol: exact saved-case audit, then 940 requests once."""
from contextlib import ExitStack
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parents[1]
assert OUT == Path('/Users/dylan/LocalData/shardloom/join-mapping-2026-11-11')
assert Path(__file__).resolve() == OUT/'tools/run_join_mapping_baseline.py'
import join_mapping_common as common
from join_mapping_common import (CLIENT, CLOSEOUT, D, E, FROZEN, REFERENCE, S,
    SELECTION, T, TREE, W, Cases, accepted_runtime, content, database, digest, read)
import capture_join_mapping as capture
from query_surface.evidence import identity
from query_surface.expanded_freeze import unpack
from query_surface.expanded_run import request, verify

TARGET = OUT/'baseline-missing-r1'
PROTOCOL = OUT/'baseline-protocol-r1.json'
REUSE = OUT/'baseline-reuse-r1.json'
WORKER = CLIENT/'join_mapping_worker.py'
ATTRIBUTION = OUT/'baseline-attribution-observations-r1.json'
ATTRIBUTION_SHA256 = 'd3ad390c2e99560f76aa717611480a42e1ae56af5a310224fb96baa9d68e54a1'
PACKET = W/'docs/benchmarks/evidence/native-shared-window-state-2026-11-11'


def references(stack, selection):
    result = {profile: stack.enter_context(database(E/('reference-'+profile)/'expectations.sqlite'))
        for profile in {row['case']['profile'] for row in selection['cases']}}
    result['composition'] = stack.enter_context(database(REFERENCE))
    return result


def case_reference(refs, row, cases):
    case = row['case']; item = cases.item(case)
    ref = refs['composition' if row['kind'] == 'composition' else case['profile']].execute(
        'SELECT identity,value FROM expected WHERE id=?', (case['id'],)).fetchone()
    assert ref and ref[0] == case['case_identity'] == item.identity
    return item, ref, unpack(ref[1])


def passed_guard(name):
    path = OUT/(name+'.json'); receipt = read(path)
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert receipt['fixed_source_validation'] and not receipt['allow_lockfile_update']
    assert receipt['log_sha256'] == content(path.with_suffix('.log'))['sha256']
    return receipt


def context():
    runtime, closeout = accepted_runtime()
    design, inputs, prepared, frozen, historical = common.inputs_and_client()
    inputs = dict(inputs, runtime=runtime)
    selection = read(SELECTION)
    assert selection['selected_requests'] == len(selection['cases']) == 940
    assert selection['original_aggregate_barrier_controls'] == 580
    assert selection['new_declarations'] == 360
    assert not selection['selection_uses_timing'] and selection['query_executions'] == 0
    assert len({row['case']['id'] for row in selection['cases']}) == 940
    assert len({row['case']['case_identity'] for row in selection['cases']}) == 940
    for ordinal, row in enumerate(selection['cases']):
        assert row['cohort_ordinal'] == ordinal
        if row['kind'] == 'original':
            assert row['case'] == design['cases'][row['original_seq']]
        else:
            assert row['kind'] == 'composition' and row['original_seq'] is None
            common.worker.declarations.validate(row['case'])
    reference = read(REFERENCE.parent/'complete.json')
    assert reference['status'] == 'passed_independent_references'
    assert reference['cases'] == reference['new_cases'] == 360
    assert reference['original_controls'] == 580
    assert reference['native_query_executions'] == 0 and not reference['native_runtime_loaded']
    assert reference['expected'] == identity(REFERENCE) and reference['input_and_client_hashes_unchanged']
    verify(list(reference['proof'].values()))
    declarations = read(OUT/'client-check-r1.json')
    assert declarations['status'] == 'passed_declaration_and_reference_controls'
    assert declarations['declarations'] == 360 and declarations['query_executions'] == 0
    assert declarations['source_bindings_unchanged'] and declarations['frozen_client_files'] == 65
    for name, expected in declarations['sources'].items():
        assert content(Path(name)) == expected
    # This gate remains deliberately unactivated until the diagnostic is run,
    # reviewed and restored to the accepted runtime source before any scoring.
    assert content(ATTRIBUTION)['sha256'] == ATTRIBUTION_SHA256
    diagnostic = read(ATTRIBUTION)
    assert diagnostic['status'] == 'passed_baseline_attribution'
    assert diagnostic['scored_query_executions'] == 0
    assert diagnostic['internal_native_fixtures'] > 0
    assert diagnostic['complete_results_verified']
    assert diagnostic['complete_schema_verified']
    assert diagnostic['probe_sources_released_before_next_batch']
    assert diagnostic['build_sources_released_after_join_teardown']
    assert diagnostic['candidate_runtime_enabled'] is False
    assert diagnostic['accepted_sources_restored'] is True
    assert not diagnostic['whole_process_memory_claim']
    verify(list(diagnostic['proof'].values()))
    for name in ('baseline-attribution-r3', 'client-preflight-r1', 'references-r1'):
        passed_guard(name)
    common.verify_capture()
    sources = [SELECTION, REFERENCE, REFERENCE.parent/'complete.json', CLOSEOUT,
        OUT/'design-r1.md', OUT/'cohort-design-r1.md', OUT/'client-check-r1.json',
        OUT/'declaration-controls-r1.json', OUT/'reference-reader-controls-r1.json',
        ATTRIBUTION, S/'window-tools-draft/capture_window_cohort.py',
        S/'window-tools-draft/window_replay.py', S/'window-tools-draft/window_admission.py',
        T/'candidate-protocol-r1.json', D/'baseline-protocol-r1.json',
        W/'docs/benchmarks/evidence/native-rolling-distinct-2026-11-11/acceptance.json',
        PACKET/'acceptance.json', PACKET/'verify.py']
    sources += [OUT/(name+suffix) for name in
        ('baseline-attribution-r3', 'client-preflight-r1', 'references-r1')
        for suffix in ('.json', '.log')]
    sources += [OUT/'tools'/name for name in ('join_mapping_common.py',
        'capture_join_mapping.py', 'run_join_mapping_baseline.py',
        'replay_join_mapping_baseline.py', 'prepare_join_mapping_references.py',
        'check_join_mapping_clients.py', 'plan_join_mapping.py',
        'join_mapping_reference_inputs.py', 'guard_join_mapping.py')]
    sources += [CLIENT/'join_mapping_cases.py', WORKER]
    sources += [Path(name) for name in declarations['sources']]
    sources += [Path(item['path']) for item in diagnostic['proof'].values()]
    proof = [identity(path) for path in sorted(set(sources))]
    unique = {}
    for item in [*frozen, *proof, *runtime.values()]:
        if item['path'] in unique:
            assert unique[item['path']] == item
        unique[item['path']] = item
    frozen = list(unique.values()); verify(frozen)
    return dict(design=design, inputs=inputs, prepared=prepared, runtime=runtime,
        closeout=closeout, selection=selection, frozen=frozen, proof_files=proof,
        historical=historical)


def verify_saved_availability(ctx):
    # T's accepted candidate and D's accepted-runtime baseline are the two
    # source-bound observation sets on this runtime. D's candidate is rejected
    # and differs from this runtime; older observations use predecessor builds.
    pools = [(T/'candidate-protocol-r1.json', PACKET, 'cases', 1212),
        (D/'baseline-protocol-r1.json',
            W/'docs/benchmarks/evidence/native-rolling-distinct-2026-11-11', 'missing_cases', 436)]
    saved_cases, observations = {}, []
    for path, packet, key, count in pools:
        accepted = read(packet/'acceptance.json')
        member = next(row for row in accepted['members'] if row['path'] == 'current/'+path.name)
        assert content(path) == {name:member[name] for name in ('bytes', 'sha256')}
        protocol = read(path)
        binding = protocol['runtime_binding']
        assert binding['runtime'] == ctx['runtime']
        assert binding['source_fingerprint_sha256'] == ctx['closeout']['source_fingerprint_sha256']
        assert len(protocol[key]) == count
        for row in protocol[key]:
            case = row['case']
            assert case['id'] not in saved_cases
            saved_cases[case['id']] = case['case_identity']
        observations.append(dict(protocol=identity(path), packet_acceptance=identity(packet/'acceptance.json'),
            selected_key=key, cases=count))
    assert len(saved_cases) == 1648
    selected = ctx['selection']['cases']
    assert not {row['case']['id'] for row in selected} & saved_cases.keys()
    assert not {row['case']['case_identity'] for row in selected} & set(saved_cases.values())
    requests = []
    with ExitStack() as stack:
        refs, cases = references(stack, ctx['selection']), Cases()
        for row in selected:
            case = row['case']; _, reference, expected = case_reference(refs, row, cases)
            job = request(case, 'native', ctx['inputs'], ctx['prepared'], expected, ctx['design']['execution'])
            requests.append(dict(cohort_ordinal=row['cohort_ordinal'], id=case['id'],
                case_identity=case['case_identity'], request_sha256=digest(job),
                reference_blob_sha256=hashlib.sha256(reference[1]).hexdigest()))
    verify(ctx['frozen'])
    return dict(schema='shardloom.join_mapping_reuse.v1', status='verified_no_matching_saved_cases',
        query_executions=0, selected_reused_cases=0, complete_requests_verified=940,
        eligible_runtime_case_pool=1648, inspected_pools=observations,
        runtime=ctx['runtime'], source_fingerprint_sha256=ctx['closeout']['source_fingerprint_sha256'],
        selection=identity(SELECTION), requests=requests,
        original_observations_preserved=True, original_ledgers_recreated=False)


def admission(root, require_protocol=True):
    assert __debug__ and root == E
    ctx = context()
    if require_protocol:
        reuse = read(REUSE)
    else:
        assert not any(path.exists() for path in (PROTOCOL, REUSE, TARGET))
        reuse = verify_saved_availability(ctx)
        with REUSE.open('x') as output:
            json.dump(reuse, output, indent=2, allow_nan=False); output.write('\n')
    assert reuse['status'] == 'verified_no_matching_saved_cases'
    assert reuse['runtime'] == ctx['runtime'] and reuse['selection'] == identity(SELECTION)
    assert reuse['selected_reused_cases'] == 0 and len(reuse['requests']) == 940
    binding = dict(schema='shardloom.join_mapping_baseline_runtime.v1',
        role='accepted_baseline_missing_cases', accepted_merge=ctx['closeout']['merge_commit'],
        accepted_tree=TREE, source_root=str(W),
        source_fingerprint_sha256=ctx['closeout']['source_fingerprint_sha256'],
        accepted_closeout=identity(CLOSEOUT), runtime=ctx['runtime'],
        proof_files=ctx['proof_files'], selection=identity(SELECTION), saved_reuse=identity(REUSE),
        target=str(TARGET), versioned_worker=identity(WORKER),
        original_worker=identity(FROZEN/'benchmarks/traditional_analytics/query_surface/expanded_worker.py'),
        composition_reference=identity(REFERENCE), frozen_harness_files=65,
        attempts_per_case=1, warmups=0, requested_repeats=0, fallback_allowed=False)
    protocol = dict(schema='shardloom.join_mapping_baseline_protocol.v1',
        status='frozen_before_new_queries', selected_count=940, original_controls=580,
        new_compositions=360, reused_count=0, missing_count=940, selection=identity(SELECTION),
        candidate_contract=dict(stage='fixed_before_candidate_implementation_and_scoring',
            design=identity(OUT/'design-r1.md'), cohort=identity(OUT/'cohort-design-r1.md'),
            eligibility='two resident inner/left equality edges into validated StreamingPrefix; K 1..16384; direct projections; unused UTF8/Binary/List/Struct payloads',
            uniqueness='completed ordinary RowIndex duplicate-link proof per annotated edge; NULL build keys do not match',
            ownership='original backing credits; freshly admitted retained view/chunk metadata; detach before next probe batch',
            validation='original complete selected domain at each field-major join boundary',
            candidate_count=1, tuning='no changed cases, eligibility or constants after scored observations'),
        design=identity(E/'design.json'), inputs=identity(E/'inputs.json'), frozen=identity(E/'frozen.json'),
        execution=ctx['design']['execution'], runtime_binding=binding,
        missing_cases=ctx['selection']['cases'], reuse=identity(REUSE),
        primary_clock='engine_execution_seconds', attempts_per_case=1, warmups=0, requested_repeats=0,
        selection_uses_timing=False, complete_10k_performance_claim=False, full43_claim=False,
        capture_changes=common.verify_capture(),
        supervision_change='Closed predecessor admission and versioned join declarations/references; per-query supervisor, guards, deadlines and cleanup unchanged.',
        isolation='All other task work and agents idle; no profiling, repeats, warmup, cache manipulation or pacing.',
        performance_decision='All 940 correct with resource/ownership/no-fallback proof; strictly lower complete engine sum retains, equal/higher drops.')
    if require_protocol:
        assert read(PROTOCOL) == protocol
    else:
        with PROTOCOL.open('x') as output:
            json.dump(protocol, output, indent=2, allow_nan=False); output.write('\n')
    frozen = [*ctx['frozen'], identity(REUSE), identity(PROTOCOL)]
    verify(frozen)
    return ctx['design'], ctx['inputs'], frozen, binding


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', action='store_true')
    args = parser.parse_args()
    _, closeout = accepted_runtime()
    changed = subprocess.check_output(['git', 'diff', '--name-only', closeout['merge_commit']], cwd=W, text=True).splitlines()
    changed += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=W, text=True).splitlines()
    assert all(name.startswith('docs/') for name in changed), changed
    os.environ['POLARS_MAX_THREADS'] = '2'
    if args.plan:
        admission(E, require_protocol=False)
        print(json.dumps(dict(status='frozen_before_new_queries', selected=940,
            reused=0, missing=940, query_executions=0)))
    else:
        protocol = read(PROTOCOL); capture.TARGET_NAME = str(TARGET)
        capture.observe(E, False, admission, common.previous.HistoricalSubset(),
            [row['case'] for row in protocol['missing_cases']], worker=WORKER,
            composition_reference=REFERENCE)


if __name__ == '__main__':
    main()
