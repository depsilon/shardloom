Investigation A: fixed scope and evidence design before execution
Worktree: /Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo
Current accepted runtime: shared-window-state-2026-11-11/runtime-r1, source fingerprint
51e9a408564dd45e5507782727348da0204a05142a6cc1d28647abb83ea9285a.
Rolling DISTINCT PR1680 has documentation/evidence only; its exact-main closeout
and verified retirement are complete before this experiment is activated.

Historical rejection distinction
PR1657's rejected selection/retention candidate shared decoded validation coordinates
within each output batch and side; it still constructed retained join output payloads.
This proposal instead carries actual native selections across TWO join boundaries into
the existing ranked consumer, postponing repeated payload reconstruction. Its wide
output workflows do not occur in the original 10k catalog. The earlier rejection and
its full-cohort observations remain unchanged; none of its components is promoted here.

Decision boundary
Use existing native DictArray selections across the two resident join boundaries,
not a parallel joined-ranking executor or tuple-table IR. Direct projections preserve
selections. Existing StreamingPrefix validates and copies its retained output before
the next producer batch. Runtime code remains untouched until the protocol is grounded.

Fixed first scope
- Two consecutive left-deep unconditioned ordinary INNER/LEFT equijoins, allowing direct-column projections
  between joins and between the second join and bounded sorting. No intervening
  computed projection, filter, limit, aggregate, window, application, observation,
  retained or recursive boundary. The source below the first join keeps its own rules.
- Existing stable bounded prefix, K in 1..=16384, ValidateValues, no unobserved-field waiver.
- Only UTF8/Binary/List/Struct payload columns not needed by any downstream join or sort
  key are candidates for selection carriage. Key preparation and narrow fields remain
  compact. No implicit child type conversion. Original selected-domain validation at
  each join remains field-major and complete before the consumer sees the batch.
- Prove each build's ordinary equality uniqueness from RowIndex duplicate links only
  after all build batches complete. RowIndex insert_unique cannot supply that proof.
  The ordinary resident Join uses insert; NULL keys are excluded from ordinary matches.
  Conditioned or ASOF joins stop admission for the complete two-join chain; spill
  keeps its current materialization route. Uniqueness admission is per annotated
  edge: a duplicate build keeps that edge's materialization,
  while a unique adjacent edge may carry a selection. No chain-wide uniqueness claim
  follows. Diagnostics must separately prove zero/one/two admitted edges and all
  duplicate matches, including across build batches. No dropped row or cap is allowed.
- Null extension remains nullable selection coordinates over original native values.
  Missing-all right sides keep typed defaults. Do not optimize away selected validation.
- Binder annotation must survive subsequent source-demand narrowing. Prefer stable
  bound field identities/names or apply it after narrowing; no stale positional masks.

Ownership details to verify
- DictArray::try_new without eager optimize preserves the selected native owner. Attach
  schema/wrapper metadata credit to each new view before publication. Original child
  buffers keep original allocator credit; never charge payload a second time.
- A retained ChunkedArray constructed for right-side gathering allocates NEW slot,
  offset-vector and offset-buffer storage. Reserve that storage before construction;
  hold overlap with the transient ReservedVec; release that Vec credit once it is gone.
  Merely retaining the old Vec credit is insufficient. Attach retained wrapper credit.
  Pinned source: vendor/vortex-array/src/arrays/chunked/array.rs:158-216 constructs
  n+1 slots, n+1 usize offsets, and a separate u64 offset buffer. ArraySlots is a
  SmallVec of Option<ArrayRef> with four inline slots (array/mod.rs:64). BufferMut
  adds its actual alignment to requested bytes (vortex-buffer/src/buffer_mut.rs:132).
  Proposed checked bound before construction: schema credit plus 4096 wrapper bytes
  plus (n+1)*(size_of<Option<ArrayRef>> + size_of<usize> + size_of<u64>), covering
  the buffer alignment in the fixed allowance. Keep old Vec credit concurrently.
  Verify the provider uses the exact-size Vec iterator; no unknown size_hint growth.
  native_payload_schema::reserve_metadata counts 1024 bytes per dtype node, with
  separate name allowances; it is not a flat 4096-byte charge per node.
- A view can pin more original bytes than its selected values. Report/prove this peak,
  then verify the ranked consumer retains no probe/fact-source view after its callback.
  Dimension owners remain live in build state for the join lifetime; ranked output must
  not prolong that lifetime past join/query teardown.
- Direct field extraction from a physical nonnullable Struct returns a child handle;
  buffer ownership must therefore reside with the child, not only the parent wrapper.
  Test clones/extracted fields, cancellation, denied metadata, producer release and
  output lifetime after session shutdown. No whole-process RSS claim follows.

Fixed versioned public cohort
- Use the same frozen input generations and unchanged 65-file public client. Generic
  relation APIs express joins/direct projection/order/limit on every public surface.
- Four existing dataset labels: smoke/balanced/257, primary/balanced/1000000,
  holdout/null_heavy/100003, scale/skewed/5000000. High-cardinality is a generator option,
  NOT a fifth or existing frozen profile. Use actual Arrow reference input rows.
  The holdout layout is shuffled; the other three are sorted. Fact row IDs are
  unique identity values, not physical positions. Validate the complete in-range
  ID domain regardless of order, and hydrate selected payloads by ID. Both ranking
  keys are declared explicitly, so changing physical order cannot change expected
  ties. Diagnostic tests without the second key separately prove stable ordering.
- Deterministic 15-cell surface x format schedule per new scenario, with
  profile chosen by a fixed Latin rotation independent of timings. Freeze exact cells
  and coverage counts before running. All five surfaces and three source formats occur.
- Cover both star orders and all four INNER/LEFT combinations for wide output, genuine
  nullable List/Struct output, narrow controls, K=1/31/1024, nullable and signed ordering
  keys, direct alias/reorder/duplicate projection, bounded full-output controls and
  empty/tiny populations. No full output over millions of rows.
- Preserve original 580 two-inner-join aggregate controls with exact current-runtime
  baselines measured only where missing. They do not activate this candidate. Reuse
  saved observations only if request, expected output, runtime and source identities
  match exactly. An older pre-window runtime is not the current baseline.
- Independent reference: verify actual dimension IDs and ordinary NULL equality;
  select fact population independently, compute join matches with native Python data
  structures, stable rank on requested key plus unique row_id, then emit every selected
  text/list/struct value with the declared nested schema. Arrow is reference input only.
  Stream reference batches, bound retained rank state, and preserve complete outputs.
  Select reference row ids from keys before hydrating intact payloads; that preparation
  is outside native query execution and all 24 small literal results remain independent.
- Candidate correctness/default/native/installed-public checks and diagnostic ownership
  proof precede one isolated scored execution per case. No warmups, repeats, competitor
  rerun, Full43 or full10k. Compare only complete engine_execution_seconds sums; lower
  retains, unchanged/higher drops. Preserve every failed/refused attempt separately.

Separate unscored regression/diagnostic contracts
- Duplicate build keys including cross-batch duplicates and real hash collisions;
  missing matches/NULL keys/nullable parents; reordering and repeated selections;
  stable ties across producer batches; empty dimensions and zero output.
- Hidden next-join and ranking keys, alias collisions forbidden by ordinary binding,
  same source projected twice with one key alias and one payload alias.
- Malformed selected nested values/strict nonfinite children beyond the final prefix
  still fail at the original boundary; excluded rows preserve lazy-error behavior.
- Spill and cancellation use existing routes and release exact owned resources.
- Debug-only work counters prove fewer materialized wide payload cells/bytes, preserved
  validation and final writes, mappings/metadata charged, and all source owners released.
  No diagnostic instrumentation in ordinary release measurements.

Execution prerequisites
The exact scenario matrix, candidate boundary and metadata bounds are fixed above.
Adapter/reference controls and baseline removable-work attribution must pass
before scoring. No speed claim follows from this design.
