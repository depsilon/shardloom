"""Prospective public join/ranking declarations; no native runtime execution.

This draft is not an activated benchmark protocol. Import the original frozen
query_surface client before this module. The reference consumes independent
input rows, never ShardLoom output or a native join/sort implementation.
"""
from collections import Counter
import hashlib
import heapq
import json

from query_surface.semantics import ResultContract, TypedResult, schema_record
from query_surface.specification import Order, Relation, SURFACES


FORMATS = ('parquet', 'vortex', 'arrow-ipc')
PROFILES = ('smoke', 'primary', 'holdout', 'scale')
PAYLOAD = {
    'narrow': (),
    'wide': ('long_text', 'unique_text', 'unicode_text', 'optional_text'),
    'rich': ('long_text', 'items', 'detail'),
}
DIMENSIONS = {
    'entities': ('entity_id', 'matched_entity_id', ('region', 'entity_label')),
    'products': ('product_id', 'matched_product_id', ('product_category',)),
}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
        ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def scenarios():
    result = []

    def add(name, **changes):
        row = dict(name=name, products_first=False, entity_kind='inner',
            product_kind='inner', payload='wide', population='population',
            limit=31, descending=False, order_key='signed_value', projection='plain')
        row.update(changes)
        result.append(row)

    for products_first in (False, True):
        for entity_kind in ('inner', 'left'):
            for product_kind in ('inner', 'left'):
                add(f'wide_{int(products_first)}_{entity_kind}_{product_kind}',
                    products_first=products_first, entity_kind=entity_kind,
                    product_kind=product_kind)
    for payload in ('rich', 'narrow'):
        for products_first in (False, True):
            add(f'{payload}_{int(products_first)}', payload=payload,
                products_first=products_first,
                entity_kind='left' if payload == 'rich' else 'inner',
                product_kind='left' if payload == 'rich' else 'inner')
    add('wide_one', entity_kind='inner', product_kind='left',
        population='first_4096', limit=1)
    add('rich_1024', products_first=True, entity_kind='left', payload='rich',
        population='first_4096', limit=1024, descending=True, order_key='optional_value')
    add('rich_tiny', payload='rich', population='prefix_17', order_key='optional_value')
    add('wide_tiny_one', products_first=True, entity_kind='left', product_kind='left',
        population='prefix_17', limit=1, descending=True)
    for payload in ('wide', 'rich'):
        for products_first in (False, True):
            add(f'{payload}_full_{int(products_first)}', payload=payload,
                products_first=products_first, population='first_4096', limit=None,
                entity_kind='left' if payload == 'rich' else 'inner',
                product_kind='left' if payload == 'rich' else 'inner')
    add('wide_aliases', entity_kind='left', product_kind='left',
        order_key='optional_value', projection='both')
    add('rich_aliases', products_first=True, payload='rich', population='first_4096',
        descending=True, projection='both')
    add('rich_empty', payload='rich', entity_kind='left', product_kind='left',
        population='empty')
    add('narrow_zero', payload='narrow', products_first=True, limit=0)
    if len(result) != 24 or len({row['name'] for row in result}) != 24:
        raise AssertionError('prospective scenario grid changed')
    return result


def population(source, name):
    if name == 'population':
        return source
    threshold = {'first_4096': 4096, 'prefix_17': 17, 'empty': 0}[name]
    return source.where(source.col('row_id').binary('lt', threshold))


def fact_columns(scenario):
    return tuple(dict.fromkeys(('row_id', scenario['order_key'], *PAYLOAD[scenario['payload']])))


def dimension_columns(table, payload):
    key, alias, text = DIMENSIONS[table]
    return [(key, alias), *((name, name) for name in text if payload != 'narrow')]


def relation(scenario):
    if digest(scenario) not in {digest(row) for row in scenarios()}:
        raise ValueError('unknown prospective scenario')
    source = population(Relation.scan('fact'), scenario['population'])
    order = ('products', 'entities') if scenario['products_first'] else ('entities', 'products')
    first, second = order
    second_key = DIMENSIONS[second][0]
    left_columns = (*fact_columns(scenario), second_key)
    first_output = dimension_columns(first, scenario['payload'])
    first_kind = scenario['product_kind' if first == 'products' else 'entity_kind']
    joined = source.join(Relation.scan(first),
        ((DIMENSIONS[first][0], DIMENSIONS[first][0]),),
        (*(('left', name, name) for name in left_columns),
         *(('right', name, alias) for name, alias in first_output)), first_kind)
    between = scenario['projection'] == 'both'
    if between:
        joined = joined.project(*(('mid_' + name, joined.col(name))
            for name, _ in reversed(joined.schema)))
    prefix = 'mid_' if between else ''
    second_kind = scenario['product_kind' if second == 'products' else 'entity_kind']
    # Restore a common final field order independent of join order. This is
    # declaration only; reference joins do not traverse this expression tree.
    columns = [('left', prefix + name, name) for name in fact_columns(scenario)]
    for table in ('entities', 'products'):
        columns += [('left' if table == first else 'right',
            prefix + alias if table == first else name, alias)
            for name, alias in dimension_columns(table, scenario['payload'])]
    joined = joined.join(Relation.scan(second), ((prefix + second_key, second_key),),
        tuple(columns), second_kind)
    if between:
        duplicate = 'long_text' if scenario['payload'] == 'wide' else 'items'
        joined = joined.project(*(('out_' + name, joined.col(name))
            for name, _ in reversed(joined.schema)),
            ('duplicate_payload', joined.col(duplicate)))
    prefix = 'out_' if between else ''
    keys = tuple(dict.fromkeys((prefix + scenario['order_key'], prefix + 'row_id')))
    joined = joined.order(*(Order(name, scenario['descending'], 'last') for name in keys))
    return joined if scenario['limit'] is None else joined.take(scenario['limit'])


def declarations():
    result = []
    for index, scenario in enumerate(scenarios()):
        plan = relation(scenario)
        for surface_index, surface in enumerate(SURFACES):
            for format_index, native_format in enumerate(FORMATS):
                profile = PROFILES[(index + surface_index + 2 * format_index) % len(PROFILES)]
                declaration = dict(version=1, scenario=scenario, profile=profile,
                    surface=surface, native_format=native_format, relation_sha256=digest(plan.record()),
                    output_schema=schema_record(plan.schema), ordered=True)
                identity = digest(declaration)
                result.append(dict(id=f'join_mapping_v1_{index:02}_{surface_index}_{format_index}_{identity[:12]}',
                    case_identity=identity, join_mapping_version=1, declaration=declaration,
                    profile=profile, surface=surface, native_format=native_format,
                    family='join_mapping_' + scenario['payload'], archetype=scenario['name'],
                    partition='held_out' if profile == 'holdout' else 'development', surrogate=None))
    if len(result) != 360 or len({row['id'] for row in result}) != 360:
        raise AssertionError('prospective public cell grid changed')
    return result


def validate(case):
    declaration = case['declaration']
    if (type(case['join_mapping_version']) is not int or case['join_mapping_version'] != 1
            or type(declaration['version']) is not int or declaration['version'] != 1):
        raise ValueError('unknown join mapping declaration version')
    if set(declaration) != {'version','scenario','profile','surface','native_format',
            'relation_sha256','output_schema','ordered'} or declaration['ordered'] is not True:
        raise ValueError('join mapping declaration fields changed')
    if digest(declaration) != case['case_identity']:
        raise ValueError('join mapping declaration identity changed')
    if any(case[key] != declaration[key] for key in ('profile', 'surface', 'native_format')):
        raise ValueError('join mapping route changed')
    index = [digest(row) for row in scenarios()].index(digest(declaration['scenario']))
    surface_index = SURFACES.index(declaration['surface'])
    format_index = FORMATS.index(declaration['native_format'])
    profile = PROFILES[(index + surface_index + 2 * format_index) % len(PROFILES)]
    expected_id = f'join_mapping_v1_{index:02}_{surface_index}_{format_index}_{case["case_identity"][:12]}'
    if (case['id'] != expected_id or declaration['profile'] != profile
            or case['family'] != 'join_mapping_' + declaration['scenario']['payload']
            or case['archetype'] != declaration['scenario']['name']
            or case['partition'] != ('held_out' if profile == 'holdout' else 'development')
            or case['surrogate'] is not None):
        raise ValueError('join mapping case identity or fixed coverage schedule changed')
    plan = relation(declaration['scenario'])
    if digest(plan.record()) != declaration['relation_sha256'] or schema_record(plan.schema) != declaration['output_schema']:
        raise ValueError('join mapping output contract changed')
    return plan


def unique_dimension(rows, table):
    key = DIMENSIONS[table][0]
    result = {}
    for row in rows:
        value = row[key]
        if value is None or type(value) is not int or value in result:
            raise ValueError('reference dimension is not a unique nonnullable integer domain')
        result[value] = row
    return result


def selected_facts(scenario, fact_rows, entities, products):
    """Rank independent input rows before constructing the declared output.

    A reference transport may supply only keys on a first pass, then hydrate
    the selected fact row IDs. This routine never reads native results.
    """
    if digest(scenario) not in {digest(row) for row in scenarios()}:
        raise ValueError('unknown reference scenario')
    limit = scenario['limit']
    if limit == 0:
        return []
    threshold = {'population': None, 'first_4096': 4096, 'prefix_17': 17, 'empty': 0}[scenario['population']]
    descending = scenario['descending']

    def values():
        seen_row_ids = set()
        for fact in fact_rows:
            row_id = fact['row_id']
            if (type(row_id) is not int or row_id < 0
                    or row_id in seen_row_ids):
                raise ValueError('reference facts must have unique nonnegative integer row IDs')
            seen_row_ids.add(row_id)
            if threshold is not None and row_id >= threshold:
                continue
            entity = entities.get(fact['entity_id']) if fact['entity_id'] is not None else None
            product = products.get(fact['product_id']) if fact['product_id'] is not None else None
            if (entity is None and scenario['entity_kind'] == 'inner'
                    or product is None and scenario['product_kind'] == 'inner'):
                continue
            value = fact[scenario['order_key']]
            if value is not None and type(value) is not int:
                raise ValueError('reference ordering expects an exact integer or NULL')
            key = (value is None, 0 if value is None else -value if descending else value,
                -row_id if descending else row_id)
            yield key, fact

    ordered = sorted(values(), key=lambda value: value[0]) if limit is None else heapq.nsmallest(
        limit, values(), key=lambda value: value[0])
    if len(ordered) > 4096:
        raise ValueError('reference output exceeds prospective bounded result contract')
    return [row for _, row in ordered]


def reference(scenario, fact_rows, entities, products):
    """Independent equality, NULL extension, stable ranking and intact payloads."""
    selected = selected_facts(scenario, fact_rows, entities, products)
    output_rows = []
    for fact in selected:
        entity = entities.get(fact['entity_id']) if fact['entity_id'] is not None else None
        product = products.get(fact['product_id']) if fact['product_id'] is not None else None
        output = {name: fact[name] for name in fact_columns(scenario)}
        for table, row in (('entities', entity), ('products', product)):
            for name, alias in dimension_columns(table, scenario['payload']):
                output[alias] = None if row is None else row[name]
        if scenario['projection'] == 'both':
            duplicate = 'long_text' if scenario['payload'] == 'wide' else 'items'
            output = {**{'out_' + name: item for name, item in output.items()},
                'duplicate_payload': output[duplicate]}
        output_rows.append(output)
    return TypedResult(relation(scenario).schema, output_rows)


def coverage(cases):
    return {key: dict(Counter(row[key] for row in cases))
        for key in ('profile', 'surface', 'native_format', 'family')}
