"""Draft public-request transport; activation requires the frozen A protocol.

The unchanged original client supplies all five execution adapters. This module
declares requests and compares complete results; it implements no join or sort.
"""
import argparse
import json
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parents[1]
FROZEN = OUT.parent / 'expanded-query-2026-11-03/investigation-original-harness-r1'
sys.path[:0] = [str(FROZEN / 'scripts'), str(FROZEN / 'python/src'),
    str(FROZEN / 'benchmarks/traditional_analytics')]
import join_mapping_cases as declarations
from query_surface import adapters, expanded_worker
from query_surface.evidence import no_fallback
from query_surface.semantics import (
    ComparisonLimit, ResultContract, ResultMismatch, compare, result_from_record,
    result_record,
)
from query_surface.worker import failure, load_native


def request(job):
    if job['engine'] != 'native':
        raise ValueError('this investigation permits only native query execution')
    case = job['case']
    if 'join_mapping_version' not in case:
        return expanded_worker.request(job)
    relation = declarations.validate(case)
    if job['surface'] != case['surface']:
        raise ValueError('join mapping public surface differs from the declaration')
    wanted = result_from_record(job['expected'])
    contract = ResultContract(relation.schema, ordered=True)
    compare(wanted, wanted, contract)
    native = load_native(job['runtime']['library']['path'])
    actual, report = adapters.execute(relation, job['sources'], job['surface'],
        native=native, binary=job['runtime']['binary']['path'],
        memory_bytes=job['memory_bytes'], parallelism=job['parallelism'],
        timeout=job['timeout'], time_public_request_only=True)
    no_fallback(report['fields'])
    if report.pop('public_declaration') != relation.record():
        raise ValueError('public adapter submitted a different declaration')
    outcome = dict(status='passed', id=case['id'], case_identity=case['case_identity'],
        execution_engine='native', observation=report)
    try:
        outcome['actual'] = result_record(actual)
    except ResultMismatch as error:
        outcome.update(status='incorrect', detail=str(error), invalid_public_result=True,
            observed_rows=repr(actual.rows), observed_schema=repr(actual.schema))
        return outcome
    try:
        compare(wanted, actual, contract)
    except ResultMismatch as error:
        outcome.update(status='incorrect', detail=str(error))
    except ComparisonLimit as error:
        outcome.update(status='comparison_inconclusive', detail=str(error))
    return outcome


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--job', type=Path, required=True)
    args = parser.parse_args()
    job = json.loads(args.job.read_bytes())
    try:
        outcome = request(job)
    except Exception as error:
        outcome = failure(error)
        outcome.update(id=job['case']['id'], case_identity=job['case']['case_identity'],
            execution_engine=job['engine'], comparison_engine_invoked=False)
    print(json.dumps(outcome, allow_nan=False, separators=(',', ':')))


if __name__ == '__main__':
    main()
