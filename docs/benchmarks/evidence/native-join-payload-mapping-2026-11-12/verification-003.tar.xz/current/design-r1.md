# Investigation A: native join payload mappings

Activated after the rolling DISTINCT closeout, exact-main checks and verified
retirement. This fixes the candidate boundary before attribution, baseline
queries or candidate implementation. It does not assert a measured benefit.

## Problem and existing owners

The ordinary resident join constructs every retained output payload at each
join boundary. In a two-dimension star query feeding bounded ranking, wide text
and nested payloads can therefore be rebuilt twice before ranking copies its
small output. The existing native join, table gather, selection and ranked
consumer already own the necessary values, row coordinates and lifecycle.

This experiment changes the native payload representation between these owners.
It adds no joined-ranking executor, new query frontend, external engine, provider
dependency, query-specific dispatch or source-format-specific execution family.
Vortex remains native input/output. Unsupported shapes retain their previously
admitted ShardLoom behavior; no external fallback is permitted.

The November 4 selection-retention candidate remains rejected. That experiment
shared validation coordinates inside a join batch while still constructing its
retained output. This proposal carries actual payload selections through two
join boundaries into an existing consumer. Its new output-producing cases are
versioned separately and do not alter historical denominators.

## Fixed candidate boundary

- Two successive left-deep resident, unconditioned ordinary INNER/LEFT equality joins feeding the
  existing StreamingPrefix consumer, with a finite prefix from 1 through
  16,384. The prefix includes an admitted offset. A zero output demand and a
  larger/full ordering use their existing rules.
- Direct column projections may rename, reorder, remove or duplicate fields
  between the two joins and between the second join and ordering. Computed
  projections, filters, ranges, aggregates, windows, recursive/retained owners,
  applications and observations between these operators stop admission. The
  producer below the first join retains its ordinary semantics.
- Carry only UTF8, Binary, List and Struct payloads whose bound child types are
  unchanged and whose values are not required as downstream join/ranking keys.
  Translate key exclusions backwards through direct aliases. Key preparation,
  narrow fields and final retained output construction keep their current owner.
- The sort must validate values and have no unobserved-field waiver. Static
  annotations use stable bound output names so later source-demand narrowing
  cannot turn an index mask into a different field policy.
- Each annotated edge separately proves matchable-key uniqueness from the
  completed ordinary RowIndex build. Every ordinary duplicate creates a link;
  no links after all build batches proves uniqueness for that index. NULL build
  keys are unmatchable under ordinary equality. Hashes still require equality.
  An insert_unique caller cannot supply this proof.
- A duplicate build keeps that edge's original payload construction. An adjacent
  annotated unique edge may still map. Evidence must identify zero, one and two
  active edges; there is no global uniqueness claim. A conditioned or ASOF join
  stops admission for this two-join chain. Spill uses the existing execution
  route, where no new mapping is activated.
- Keep the change in ordinary resident Join.flush and bounded Gather helpers.
  Shared Spec.flush_with_right callers for stored/ASOF joins remain compact.
  The existing execution dispatcher selects spill before constructing a resident
  join, and selects spilled ordering before StreamingPrefix.

These boundaries are frozen before scoring, including the per-edge policy.
Pre-score fixes may correct implementation or proof errors with retained
receipts. A scored result does not authorize retuning or changing the cohort.

## Provider and selected-domain contract

Use the pinned Vortex 0.93 DictArray::try_new constructor to retain selection
codes and native values without immediately optimizing the payload. Generic
ArrayRef.take immediately optimizes and is not the new retained-view boundary.
The existing Dict TakeExecute selects codes and retains values when observed;
native selection composition does not need a second implementation or unsafe
ShardLoom constructor. At most two new join-selection layers are introduced.

Reuse Gather's bounded touched-segment set and coordinate array for build-side
payloads. Construct retained ChunkedArray metadata only for touched chunks.
Missing-all right selections keep the existing typed defaults. Preserve exact
declared nullability, nullable parent masks, repeated selections and row order.

Before publishing each output batch, preserve the original field-major checks
over every selected value, including fields dropped by later source demand.
Use the shared selected-payload validator; no trusted flag skips validation.
Invalid selected nested values and strict nonfinite children beyond the final K
must still fail. Excluded values keep their existing lazy-error behavior.

The validator can allocate provider scratch and resolve selected values. This
experiment claims only an attempted reduction in retained payload construction,
not zero decoding, zero allocation or elimination of every provider copy.

## Memory and lifetime contract

Original buffers retain their existing allocator credits, counted once per
allocation. Selection codes retain their own credit. Each new view/schema
wrapper receives a retained metadata lease before publication. Attach that
lease while its native node has unique ownership.

Pinned ChunkedArray::try_new allocates new ArraySlots, usize offset workspace
and an independent u64 offset buffer. Admit replacement metadata before
construction while the old ReservedVec lease is still live. The checked bound
is the schema allowance plus 4,096 wrapper/alignment bytes plus
`(chunks + 1) * (size_of<Option<ArrayRef>> + size_of<usize> + size_of<u64>)`.
The pinned SmallVec uses exact requested capacity for this constructor. Release
the old vector lease only when that temporary allocation is gone; attach the
new lease to the retained ChunkedArray. Merely retaining the old lease is not
sufficient accounting for these new allocations.

A small selection may retain a large original allocation. Keep that cost in
the shared memory pool and diagnostics. StreamingPrefix must finish its
validation and independently retain its compact pending/output values before
the next probe-source batch. Build/dimension owners live for their join's
lifetime and must release after join/query teardown. Extracted children and
clones must preserve required credits after source/session shutdown; the final
clone must release them. Cancellation and denied metadata reservations must
leave no query-local allocation or temporary spill file.

## Evidence before the candidate

The frozen 10,000-declaration audit contains no two-join ranked-output target.
It contains 580 two-inner-join aggregate-barrier controls. Keep those requests
unchanged. Add 360 requests from 24 declared semantic scenarios crossed with
the five existing interfaces and three formats. Use the four existing input
labels through the fixed Latin rotation: smoke/balanced, primary/balanced,
holdout/null-heavy and scale/skewed. There is no existing high-cardinality
profile in this generation. Holdout rows are shuffled; row_id is a logical
identity and must never be used as an assumed physical file offset.

The new requests cover both join orders, all INNER/LEFT combinations, wide
text, nullable List/Struct, narrow controls, K=1/31/1024, aliases/reordering/
duplicate projection, empty/tiny populations and bounded full-output controls.
Independent references read the existing IPC inputs, verify complete identity
domains and dimension uniqueness, rank selected keys with explicit row_id ties,
then hydrate every retained payload. Reference work is outside query execution.
Separate literal fixtures prove the oracle on sorted and shuffled input, plus
schema, identity and declaration corruption refusals.

Audit exact current-runtime saved observations before reuse. The existing
accepted window candidate (1,212) and later rolling baseline additions (436)
contain 1,648 unique compatible observations and none of these 940 requests.
Older observations use a different runtime. The proposed baseline therefore
executes all 940 requests once; no saved value is silently substituted.

Before that baseline, use a temporary test-only native fixture for removable-work
attribution: six ordinary regressions and a 96-case internal matrix covering
both orders, four join-kind pairs, three payload shapes and four row sizes.
Capture exact test sources, complete results, per-stage compact buffer counts,
mapped backing counts, memory-pool peak and source-release witnesses. The
fixture retains only final ranked outputs. Verify the complete matrix and its
negative controls, then restore accepted source bytes before scoring. These
internal executions are unscored and do not modify the accepted release runtime.

## Candidate verification and decision

Prove binder admission and barriers; key aliases; duplicate keys within and
across build batches; equal-hash distinct keys; NULL and empty builds; 0/1/2
mapped edges; malformed selected tails; strict floats; nullable nested values;
stable ties across producer batches; denied reservations; cancellation; spill
decline; clone/child ownership; and complete final output after session closure.
Prepared public-route tests must establish actual activation through the shared
binding/execution path. The unchanged five public clients must deliver complete
results with both no-fallback fields on all declared formats.

Run the repository's required default/native checks, installed public-surface
checks and a fresh release provenance check before the candidate score. Keep
debug attribution outside the ordinary release runtime. Baseline and candidate
use the same frozen requests, expectations, input generations and engine clock.
Each executes once in isolation with the unchanged supervisor, storage limits,
deadlines, output checks and process cleanup. Full hashing/inventories remain
outside active query execution. All other task work and agents stay idle.

The complete 940-case sum of engine_execution_seconds decides after correctness,
resource, ownership and no-fallback gates pass: strictly lower retains; equal
or higher drops. Counter reductions alone cannot ship it. No warmup, repeated
trial, cache manipulation, post-score tuning, competitor rerun, Full43 or new
full10k run is included. Preserve every failure and family regression, exact
source/request/result identities, portable replay and hosted closeout. This
experiment cannot complete item 19, item 20, RFC 0044 or CG-1 through CG-23.
