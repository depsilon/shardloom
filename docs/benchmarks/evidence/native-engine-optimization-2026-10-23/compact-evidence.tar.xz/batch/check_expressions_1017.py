import subprocess
import sys

binary = '/Users/dylan/.cache/shardloom/cargo-target/debug/deps/shardloom_vortex-26af6ca4771ea8fd'
for selected in ['expression_reuse_', 'pure_predicate_', 'predicate_filter_mask_',
                 'expression_tests::', 'native_nested_parent_validity_']:
    print('selected=' + selected, flush=True)
    result = subprocess.run([binary, selected, '--nocapture', '--test-threads=1'])
    if result.returncode:
        sys.exit(result.returncode)
