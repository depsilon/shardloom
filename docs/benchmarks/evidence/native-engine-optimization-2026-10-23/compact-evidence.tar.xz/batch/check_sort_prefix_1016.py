import subprocess
import sys

binary = '/Users/dylan/.cache/shardloom/cargo-target/debug/deps/shardloom_vortex-26af6ca4771ea8fd'
for selected in ['native_result_prefix_', 'native_relational_sort_prefix_',
                 'native_relational_order_', 'streamed_ordering_prefix_',
                 'streamed_ordering_limit_barriers_']:
    print('selected=' + selected, flush=True)
    result = subprocess.run([binary, selected, '--nocapture', '--test-threads=1'])
    if result.returncode:
        sys.exit(result.returncode)
