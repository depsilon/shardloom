"""Preserve compact observations and protocol sources, excluding obsolete runtimes."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
N = Path('/Users/dylan/LocalData/shardloom/native-engine-optimization-20261023')
DEST = W / 'docs/benchmarks/evidence/native-engine-optimization-2026-10-23'
ARCHIVE = N / 'compact-evidence-1020.tar.xz'
MANIFEST = N / 'compact-evidence-manifest-1020.json'
RECEIPT = N / 'compact-evidence-package-1020.json'
EXTENSIONS = {'.json', '.jsonl', '.ndjson', '.log', '.py', '.txt', '.pid',
              '.csv', '.gz', '.rs', '.sql', '.vortex'}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def generation(path):
    stat = path.stat()
    return (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)


def main():
    assert not any(p.exists() for p in (ARCHIVE, MANIFEST, RECEIPT))
    assert not (N / '.engine-cost.lock').exists()
    assert shutil.disk_usage(N).free >= 12 << 30
    sources = {}
    excluded = []
    # Measured harness files are protocol evidence. Do not preserve an entire
    # generated source checkout or package environment as a rollback bundle.
    measured_harnesses = set()
    for summary in N.glob('full43-*/logs/*/summary.json'):
        value = json.loads(summary.read_text())
        measured_harnesses.update(Path(p) for p in value.get('harness_sha256', {}))
    for path in sorted(N.rglob('*')):
        if not path.is_file() or path.is_symlink():
            continue
        relative = path.relative_to(N)
        keep = path.suffix in EXTENSIONS
        keep &= relative.parts[0] != 'tmp' and '__pycache__' not in relative.parts
        if relative.parts[0] == 'clickbench-harness-1011':
            keep &= path in measured_harnesses or path.suffix == '.sql'
        if path.suffix == '.vortex':
            keep &= path.stat().st_size < 1 << 20
        if keep:
            sources['batch/' + relative.as_posix()] = path
        else:
            excluded.append({'path': str(path), 'bytes': path.stat().st_size})
    extra = {
        'protocol/reference.json': Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022/independent-full43-948/reference.json'),
        'protocol/bounded_build_process_resume_20260912.py': Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py'),
        'protocol/native_workload_guard_816.py': Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/native_workload_guard_816.py'),
    }
    sources.update(extra)
    members = {}
    identities = {}
    for name, path in sources.items():
        before = generation(path)
        data = path.read_bytes()
        assert generation(path) == before, path
        identities[name] = before
        members[name] = {'source': str(path), 'bytes': len(data), 'sha256': digest(data)}
    manifest = {
        'schema_version': 'shardloom.native_engine_optimization.compact_evidence.v1',
        'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip(),
        'members': members, 'excluded_generated_artifacts': excluded,
        'policy': 'Preserve complete results and failures; no executable, compiler-cache or environment backup.',
    }
    raw_manifest = (json.dumps(manifest, indent=2) + '\n').encode()
    with MANIFEST.open('xb') as output:
        output.write(raw_manifest)
    with tarfile.open(ARCHIVE, 'x:xz') as archive:
        for name, path in sources.items():
            data = path.read_bytes()
            assert generation(path) == identities[name] and digest(data) == members[name]['sha256'], path
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(data))
        info = tarfile.TarInfo('manifest.json')
        info.size = len(raw_manifest)
        info.mode = 0o644
        archive.addfile(info, io.BytesIO(raw_manifest))
    seen = set()
    with tarfile.open(ARCHIVE, 'r:xz') as archive:
        for entry in archive:
            assert entry.isfile() and entry.name not in seen
            seen.add(entry.name)
            data = archive.extractfile(entry).read()
            if entry.name == 'manifest.json':
                assert data == raw_manifest
            else:
                expected = members[entry.name]
                assert len(data) == expected['bytes'] and digest(data) == expected['sha256']
                assert sources[entry.name].read_bytes() == data
                assert generation(sources[entry.name]) == identities[entry.name]
    assert seen == set(members) | {'manifest.json'}
    for source, name in [(ARCHIVE, 'compact-evidence.tar.xz'), (MANIFEST, 'compact-evidence-manifest.json')]:
        target = DEST / name
        with source.open('rb') as inp, target.open('xb') as out:
            shutil.copyfileobj(inp, out)
        assert digest(source.read_bytes()) == digest(target.read_bytes())
    receipt = {
        'status': 'passed', 'members': len(members),
        'raw_member_bytes': sum(v['bytes'] for v in members.values()),
        'archive_bytes': ARCHIVE.stat().st_size, 'archive_sha256': digest(ARCHIVE.read_bytes()),
        'manifest_sha256': digest(raw_manifest), 'all_member_bytes_read_back': True,
        'all_original_generations_unchanged': True, 'excluded_generated_artifacts': len(excluded),
    }
    with RECEIPT.open('x') as out:
        json.dump(receipt, out, indent=2)
        out.write('\n')
    with (DEST / 'compact-evidence-package.json').open('x') as out:
        json.dump(receipt, out, indent=2)
        out.write('\n')
    print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    main()
