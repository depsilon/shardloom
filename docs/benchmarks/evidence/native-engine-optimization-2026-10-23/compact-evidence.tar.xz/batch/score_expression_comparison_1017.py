import hashlib
import json
from pathlib import Path
import statistics

root = Path('/Users/dylan/LocalData/shardloom/native-engine-optimization-20261023/expression-comparison-1017')
cases = ['expression_shared', 'expression_unique', 'predicate_projected',
         'predicate_filter', 'predicate_single', 'value_numeric']
cells = [(case, rows) for case in cases for rows in [65536, 257]]
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
outcome = json.loads((root / 'outcome.json').read_text())
assert outcome['complete'] and len(outcome['calls']) == 72
assert outcome['source_before'] == outcome['source_after']
assert outcome['runtime_manifests']['baseline']['harnesses'] == outcome['runtime_manifests']['candidate']['harnesses']
schedule = [(case, rows, pair, role) for case, rows in cells for pair in [1, 2, 3]
            for role in (['candidate', 'baseline'] if pair == 2 else ['baseline', 'candidate'])]
assert outcome['schedule'] == [list(call) for call in schedule]
assert [(call['case'], call['rows'], call['sample'], call['role']) for call in outcome['calls']] == schedule
records = {}
members = {}
for call in outcome['calls']:
    assert call['status'] == 'passed' and call['returncode'] == 0
    assert call['process_group_drained'] and call['direct_child_reaped']
    name = f"measure-{call['case']}-{call['rows']}-{call['role']}-{call['sample']}.json"
    path = root / name
    assert digest(path) == call['record_sha256']
    members[name] = digest(path)
    record = json.loads(path.read_text())
    assert record['protocol'] == 'native-engine-cost-v3'
    assert record['complete_values_match'] and record['complete_schema_match']
    assert record['denied_reservations'] == record['reserved_after_cleanup'] == 0
    assert record['expected_rows_witness'] == record['actual_rows_witness']
    for field in ['actual_rows_witness', 'expected_rows_witness', 'schema_witness']:
        witness = root / 'witnesses' / (record[field] + '.json')
        assert digest(witness) == record[field]
    records[(call['case'], call['rows'], call['role'], call['sample'])] = record

summaries = []
for case, rows in cells:
    observations = {role: [records[(case, rows, role, sample)] for sample in [1, 2, 3]]
                    for role in ['baseline', 'candidate']}
    reference = observations['baseline'][0]
    for role_records in observations.values():
        for record in role_records:
            for field in ['input', 'right_input', 'partitions', 'expected_rows_witness', 'schema_witness',
                          'producer_calls', 'producer_completed', 'memory_grant_bytes']:
                assert record[field] == reference[field], (case, rows, field)
    times = {role: [record['engine_execution_ns'] / 1e9 for record in role_records]
             for role, role_records in observations.items()}
    medians = {role: statistics.median(values) for role, values in times.items()}
    ceiling = medians['baseline'] + max(medians['baseline'] * 0.1, 0.0001)
    summaries.append(dict(case=case, rows=rows, engine_seconds=times, engine_medians=medians,
                          ratio=medians['candidate'] / medians['baseline'],
                          timing_ceiling_seconds=ceiling,
                          timing_ceiling_passed=medians['candidate'] <= ceiling,
                          peak_reserved_bytes={role: max(record['peak_reserved_bytes'] for record in role_records)
                                               for role, role_records in observations.items()}))

target, = [cell for cell in summaries if cell['case'] == 'expression_shared' and cell['rows'] == 65536]
benefit = target['ratio'] <= 0.95
controls = all(cell['timing_ceiling_passed'] for cell in summaries)
decision = dict(protocol='native-engine-cost-v3',
                source_commit=outcome['runtime_manifests']['candidate']['revision'],
                baseline_commit=outcome['runtime_manifests']['baseline']['revision'],
                scorer_sha256=digest(Path(__file__)), outcome_sha256=digest(root / 'outcome.json'),
                record_sha256=members, calls=72, cells=summaries,
                target_engine_ratio=target['ratio'], benefit_gate=benefit, control_gate=controls,
                complete_semantics_and_cleanup_pass=True, retained=benefit and controls)
with (root / 'decision.json').open('x') as out:
    json.dump(decision, out, indent=2)
    out.write('\n')
print(json.dumps({key: decision[key] for key in ['target_engine_ratio', 'benefit_gate', 'control_gate', 'retained']}))
for cell in summaries:
    print(json.dumps({key: cell[key] for key in ['case', 'rows', 'engine_medians', 'ratio', 'timing_ceiling_passed']}))
