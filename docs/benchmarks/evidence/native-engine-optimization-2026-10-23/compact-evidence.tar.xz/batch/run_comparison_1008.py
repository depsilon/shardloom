"""Frozen v2 decision screen: three alternating pairs per complete workload."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
N = Path('/Users/dylan/LocalData/shardloom/native-engine-optimization-20261023')
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
PR = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022')
UAT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
TEST = 'local_primitives::prepared_relational::tests::engine_cost_tests::native_engine_optimization_cost_screen'
CASES = ('value_text', 'value_numeric', 'aggregate_text', 'aggregate_numeric',
         'aggregate_interleaved', 'aggregate_count', 'aggregate_distinct',
         'sort_many', 'sort_single', 'sort_limit', 'predicate_filter',
         'predicate_projected', 'predicate_single', 'join_semi_duplicate',
         'join_anti_duplicate', 'join_semi_unique', 'join_anti_unique')
CELLS = [(case, rows) for case in CASES for rows in (65536, 257)
         if case != 'sort_single' or rows == 257]
HARNESSES = ('shardloom-vortex/src/local_primitive_relational_engine_cost_tests.rs',
             'shardloom-vortex/src/local_primitive_relational_engine_cost_data.rs')


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def byte_count(path):
    return sum(p.stat().st_size for p in path.rglob('*')
               if p.is_file() and not p.is_symlink()) if path.exists() else 0


def source_identity():
    return {str(p.relative_to(W)): digest(p) for p in sorted(W.rglob('*'))
            if p.is_file() and 'target' not in p.parts
            and (p.suffix == '.rs' or p.name in ('Cargo.toml', 'Cargo.lock'))}


def write_new(path, value):
    with path.open('x') as output:
        json.dump(value, output, indent=2)
        output.write('\n')


def main():
    baseline_path, candidate_path, result_path = map(Path, sys.argv[1:])
    assert result_path.is_absolute() and result_path.parent == N
    result_path.mkdir()  # A previous result is never overwritten or resumed.
    (result_path / 'witnesses').mkdir()
    manifests = {'baseline': json.loads(baseline_path.read_text()),
                 'candidate': json.loads(candidate_path.read_text())}
    for role, manifest in manifests.items():
        assert digest(manifest['binary']) == manifest['binary_sha256'], role
        assert manifest['profile'] == 'release'
        assert manifest['features'] == ['release-user-surfaces']
        assert manifest['harnesses'] == {name: digest(W / name) for name in HARNESSES}
    assert manifests['baseline']['harnesses'] == manifests['candidate']['harnesses']
    assert manifests['baseline']['toolchain'] == manifests['candidate']['toolchain']
    bounded_path = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
    guard_path = Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/native_workload_guard_816.py')
    bounded = module('bounded', bounded_path)
    guards = module('guards', guard_path)
    before = source_identity()
    # Full inventories belong outside the active execution supervisor.
    sizes = {'uat': byte_count(UAT),
             'target_and_tasks': byte_count(CACHE) + byte_count(PR) + byte_count(N)}
    assert max(sizes.values()) <= 100 * (1 << 30)
    schedule = [(case, rows, pair, role) for case, rows in CELLS
                for pair in range(1, 4)
                for role in (('candidate', 'baseline') if pair == 2 else ('baseline', 'candidate'))]
    packet = {'protocol': 'native-engine-cost-v2', 'driver_sha256': digest(__file__),
              'helpers': {str(p): digest(p) for p in (bounded_path, guard_path)},
              'runtime_manifests': manifests, 'source_before': before,
              'storage_before': sizes, 'schedule': schedule,
              'active_result_limit_bytes': 200 << 20, 'complete': False, 'calls': []}
    write_new(result_path / 'protocol.json', packet)
    lock_path = N / '.engine-cost.lock'
    lock = os.open(lock_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    os.write(lock, str(os.getpid()).encode())
    lock_inode = os.fstat(lock).st_ino
    os.close(lock)
    try:
        for case, rows, sample, role in schedule:
            label = f'{case}-{rows}-{role}-{sample}'
            evidence = {'case': case, 'rows': rows, 'sample': sample, 'role': role}
            work = guards.WorkloadGuard()
            env = dict(os.environ, SHARDLOOM_ENGINE_COST_ROOT=str(result_path),
                       SHARDLOOM_ENGINE_COST_CASE=case, SHARDLOOM_ENGINE_COST_ROWS=str(rows),
                       SHARDLOOM_ENGINE_COST_ROLE=role, SHARDLOOM_ENGINE_COST_SAMPLE=str(sample))
            command = [manifests[role]['binary'], TEST, '--exact', '--ignored',
                       '--nocapture', '--test-threads=1']
            evidence['command'] = command

            def guard():
                work.check(evidence.get('pid'))
                assert shutil.disk_usage(N).free >= 12 * (1 << 30)
                # This inventory is limited to this small active result packet.
                assert byte_count(result_path) <= 200 << 20

            log = result_path / (label + '.log')
            try:
                with log.open('xb') as output:
                    status = bounded.run(command, cwd=W, env=env, output=output,
                                         timeout=300, evidence=evidence, guard=guard,
                                         max_output_bytes=8 << 20)
                assert status == 0, label
                record_path = result_path / ('measure-' + label + '.json')
                record = json.loads(record_path.read_text())
                assert record['protocol'] == 'native-engine-cost-v2'
                assert record['complete_values_match'] and record['complete_schema_match']
                assert not record['observation_enabled'] and record['observations'] is None
                assert record['memory_grant_bytes'] == 128 << 20
                assert record['denied_reservations'] == record['reserved_after_cleanup'] == 0
                evidence['record_sha256'] = digest(record_path)
                evidence['status'] = 'passed'
            except BaseException as error:
                evidence['status'] = 'failed'
                evidence['failure'] = type(error).__name__ + ': ' + str(error)
                raise
            finally:
                evidence['log_sha256'] = digest(log) if log.exists() else None
                write_new(result_path / ('supervision-' + label + '.json'), evidence)
                packet['calls'].append(evidence)
                print(json.dumps({k: evidence.get(k) for k in
                                  ('case', 'rows', 'sample', 'role', 'status')}), flush=True)
        packet['source_after'] = source_identity()
        assert before == packet['source_after'], 'source changed during comparison'
        for manifest in manifests.values():
            assert digest(manifest['binary']) == manifest['binary_sha256']
        packet['storage_after'] = {'uat': byte_count(UAT),
                                  'target_and_tasks': byte_count(CACHE) + byte_count(PR) + byte_count(N)}
        assert max(packet['storage_after'].values()) <= 100 * (1 << 30)
        packet['complete'] = True
    finally:
        write_new(result_path / 'outcome.json', packet)
        assert lock_path.stat().st_ino == lock_inode
        lock_path.unlink()


if __name__ == '__main__':
    main()
