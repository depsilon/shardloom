"""Declared sort-only cells of the unchanged native-engine-cost-v2 screen."""
import importlib.util
import hashlib
from pathlib import Path

driver = Path(__file__).with_name('run_comparison_1015.py')
assert hashlib.sha256(driver.read_bytes()).hexdigest() == '84dec0da9890a844043cd9c8255ce54c78d5836acc25e2a65acb2ea8095c6dd8'
spec = importlib.util.spec_from_file_location('comparison', driver)
comparison = importlib.util.module_from_spec(spec)
spec.loader.exec_module(comparison)
comparison.CELLS = [('sort_many', 65536), ('sort_limit', 65536),
                    ('sort_many', 257), ('sort_single', 257), ('sort_limit', 257)]
# The wrapper pins the common driver above; the receipt hashes this wrapper.
comparison.__file__ = __file__
comparison.main()
