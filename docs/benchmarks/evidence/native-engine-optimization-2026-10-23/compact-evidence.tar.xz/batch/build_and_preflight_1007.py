from pathlib import Path
import subprocess
import sys

N = Path('/Users/dylan/LocalData/shardloom/native-engine-optimization-20261023')
commands = [
    ['harness-debug-build-1007c', 'cargo', 'test', '-p', 'shardloom-vortex', '--lib', '--features',
     'release-user-surfaces', 'native_engine_optimization_cost_screen', '--no-run'],
    ['harness-large-preflight-1007', 'python3', str(N / 'preflight_large_1007.py')],
]
for command in commands:
    result = subprocess.run(['python3', str(N / 'run_validation_1007.py'), *command])
    if result.returncode:
        sys.exit(result.returncode)
