import subprocess
import sys

binary = '/Users/dylan/.cache/shardloom/cargo-target/debug/deps/shardloom_vortex-26af6ca4771ea8fd'
names = [line.removesuffix(': test') for line in subprocess.check_output([binary, '--list'], text=True).splitlines() if line.endswith(': test')]
selectors = ['native_relational_aggregate::', 'native_numeric', 'bound_numeric_updates::',
             'compact_numeric_block::', 'numeric_aggregate_sum::',
             'native_relational_keys::', 'aggregate_tests::']
selected = set()
for selector in selectors:
    found = {name for name in names if selector in name}
    assert found, selector
    assert not selected.intersection(found), selector
    selected.update(found)
    print('selected=' + selector + ' count=' + str(len(found)), flush=True)
    result = subprocess.run([binary, selector, '--nocapture', '--test-threads=1'])
    if result.returncode:
        sys.exit(result.returncode)
print('selected_total=' + str(len(selected)), flush=True)
