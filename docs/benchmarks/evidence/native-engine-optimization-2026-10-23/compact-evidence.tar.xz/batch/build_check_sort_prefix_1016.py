import subprocess
import sys

result = subprocess.run(['cargo', 'test', '-p', 'shardloom-vortex', '--lib',
                         '--features', 'release-user-surfaces', 'native_result_prefix_', '--no-run'])
if result.returncode:
    sys.exit(result.returncode)
sys.exit(subprocess.run([sys.executable, '-B', '/Users/dylan/LocalData/shardloom/native-engine-optimization-20261023/check_sort_prefix_1016.py']).returncode)
