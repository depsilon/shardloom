"""Frozen H1 complete-query comparison; all observations survive failures."""
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import sys

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
N = Path('/Users/dylan/LocalData/shardloom/native-engine-optimization-20261023')
ROOT = N / 'hotspots-1011/conjunct-comparison-1012'
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
sys.path.insert(0, str(W / 'scripts'))
from clickbench_reference_packet import load_reference_packet, query_statements
from clickbench_native_sql import native_query_statements
from native_workflow_protocol import extract_result, report_fields, public_workflow_command, strict_json
from query_timing_report import query_phase_timings
from run_clickbench_query_uat import equivalent
from local_uat_storage import check_budgets, GIB, MIB

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

SUPERVISOR = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
GUARD = Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/native_workload_guard_816.py')
bounded = load('bounded', SUPERVISOR)
guards = load('guards', GUARD)

def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)

def generation(path):
    value = Path(path).stat()
    return [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns]

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

def read(path):
    return strict_json(Path(path).read_text())

def storage():
    return {str(path): check_budgets(path, path / 'reserved-artifact', path / 'logs',
        min_free_bytes=12*GIB, reserve_bytes=64*MIB,
        max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
        for path in (N, CACHE)}

def main():
    baseline = read(N / 'full43-merged-run-1011.json')
    old_build = read(N / 'merged-full43-build-1011.json')
    build_path = N / 'text-conjunct-release-build-1012.json'
    build = read(build_path)
    assert baseline['status'] == old_build['status'] == build['status'] == 'passed'
    assert build['source_before'] == build['source_after']
    assert build['process_group_drained'] and build['direct_child_reaped']
    assert build['toolchain'] == old_build['toolchain']
    assert build['command'] == old_build['command']
    assert build['target'] == str(CACHE)
    log = N / 'text-conjunct-release-build-1012.log'
    assert identity(log)['sha256'] == build['log_sha256']
    assert 'Compiling shardloom-vortex ' in log.read_text()
    assert 'Compiling shardloom-cli ' in log.read_text()
    changed = sorted(k for k in old_build['source_after']
                     if old_build['source_after'][k] != build['source_after'].get(k))
    assert set(build['source_after']) == set(old_build['source_after'])
    assert changed == ['shardloom-vortex/src/local_primitives/text_scan_reuse.rs',
                       'shardloom-vortex/src/native_provider_text_scan_reuse_tests.rs'], changed
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=W,text=True).strip()
    head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()
    root_before = storage()
    ROOT.mkdir()
    candidate = N / 'shardloom-text-conjunct-1012'
    assert not candidate.exists()
    built = identity(CACHE / 'release/shardloom')
    shutil.copy2(built['path'], candidate)
    binaries = {'baseline': baseline['binary'], 'candidate': identity(candidate)}
    assert binaries['candidate']['sha256'] == built['sha256']
    source, reference = baseline['input'], baseline['reference']
    source_generation = generation(source['path'])
    queries = W / 'benchmarks/clickbench/queries.sql'
    raw, originals = query_statements(queries)
    submitted, dialect = native_query_statements(originals, hashlib.sha256(raw).hexdigest())
    expected = load_reference_packet(Path(reference['path']), queries)
    cases = [(23,12,5),(23,1,3),(22,12,3),(19,12,3),(29,12,3)]
    schedule = [(q,p,pair,role) for q,p,count in cases for pair in range(1,count+1)
        for role in (('baseline','candidate') if pair % 2 else ('candidate','baseline'))]
    def verify():
        for item in [*binaries.values(),source,reference]:
            assert identity(item['path']) == item
        assert generation(source['path']) == source_generation
        for name,digest in build['source_after'].items():
            assert identity(W / name)['sha256'] == digest, name
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip() == head
        assert not subprocess.check_output(['git','status','--porcelain'],cwd=W,text=True).strip()
    print('Verifying immutable inputs and runtimes before targeted queries.',flush=True)
    verify()
    packet = dict(status='predeclared', source_commit=head, source_manifest=build['source_after'],
        baseline_commit=baseline['source_commit'], binaries=binaries, build=identity(build_path),
        baseline_build=identity(N/'merged-full43-build-1011.json'), changed_sources=changed,
        driver=identity(__file__), supervisor=identity(SUPERVISOR), workload_guard=identity(GUARD),
        contract=identity(W/'docs/architecture/native-query-hotspots-2026-10-23.md'),
        timing_helper=identity(W/'scripts/timed_native_command.py'),
        input=source, input_generation=source_generation, reference=reference,
        queries=identity(queries), query_dialect=dialect, schedule=schedule,
        storage_before=root_before, active_limit_bytes=200*MIB,
        full_hashing='before_and_after_comparison_only', parallel_work=False,
        cache_state='uncontrolled; no manipulation or artificial pacing', calls=[])
    save(ROOT/'plan.json',packet)
    lock = N / '.query-hotspots.lock'
    lock.mkdir()
    schemas = {}
    completed_bytes = 0
    try:
        for q,parallelism,pair,role in schedule:
            label=f'q{q:02d}-p{parallelism}-{pair}-{role}'
            prefix=ROOT/label
            stdout=prefix.with_suffix('.stdout.json')
            stderr=prefix.with_suffix('.stderr.log')
            timing=prefix.with_suffix('.timing.json')
            pid=prefix.with_suffix('.pid')
            native=public_workflow_command(binaries[role]['path'],submitted[q-1],
                input_path=source['path'],input_format='vortex',memory_gb=24,max_parallelism=parallelism)
            command=[sys.executable,str(W/'scripts/timed_native_command.py'),'--timing',str(timing),
                '--pid-file',str(pid),'--shared-process-group','--',*native]
            row=dict(query=q,parallelism=parallelism,pair=pair,role=role,command=command,passed=False)
            packet['calls'].append(row)
            work=guards.WorkloadGuard()
            def guard():
                work.check(row.get('pid'))
                assert shutil.disk_usage(N).free >= 12*GIB
                active=sum(p.stat().st_size for p in (stdout,stderr,timing,pid) if p.exists())
                assert completed_bytes+active <= 200*MIB
                assert generation(source['path']) == source_generation
            with stdout.open('xb') as out,stderr.open('xb') as err:
                code=bounded.run(command,cwd=W,env=dict(os.environ),output=out,error_output=err,
                    timeout=180,evidence=row,guard=guard,max_output_bytes=8*MIB)
            assert code == 0 and row['process_group_drained'] and row['direct_child_reaped'],label
            native_time=read(timing)
            assert native_time['returncode'] == 0
            envelope=read(stdout)
            fields=report_fields(envelope)
            values=extract_result(envelope)
            assert equivalent(values,expected['values'][q]),label
            assert fields['execution_resource_declared_memory_bytes'] == str(24*GIB)
            assert fields['execution_resource_declared_max_parallelism'] == str(parallelism)
            schema=[fields['result_schema_format'],strict_json(fields['result_schema_json'])]
            assert schemas.setdefault(q,schema) == schema,label
            row.update(query_phase_timings(fields,native_time['seconds']))
            row.update(native_time)
            row['cpu_seconds']=native_time['user_cpu_seconds']+native_time['system_cpu_seconds']
            assert math.isfinite(row['engine_execution_seconds']) and row['engine_execution_seconds']>=0
            row.update(passed=True,result=values,schema=schema,output=identity(stdout),timing=identity(timing),
                provider_evidence={k:v for k,v in fields.items() if k.startswith('aggregate_text_scan_')})
            completed_bytes+=sum(p.stat().st_size for p in (stdout,stderr,timing,pid))
            save(prefix.with_suffix('.receipt.json'),row)
            print(f'{label}: complete values passed; engine {row["engine_execution_seconds"]:.6f}s',flush=True)
        verify()
        decisions=[]
        for q,p,count in cases:
            calls=[r for r in packet['calls'] if (r['query'],r['parallelism']) == (q,p)]
            by_role={role:[r for r in calls if r['role']==role] for role in binaries}
            medians={role:{key:statistics.median(r[key] for r in rows)
                for key in ('engine_execution_seconds','cpu_seconds','peak_rss_bytes')}
                for role,rows in by_role.items()}
            a,b=medians['baseline'],medians['candidate']
            savings=[next(r['engine_execution_seconds'] for r in calls if r['pair']==i and r['role']=='baseline')-
                     next(r['engine_execution_seconds'] for r in calls if r['pair']==i and r['role']=='candidate')
                     for i in range(1,count+1)]
            target=(q,p)==(23,12)
            engine=(b['engine_execution_seconds'] < a['engine_execution_seconds'] and
                    statistics.median(savings)>0 and sum(v>0 for v in savings)>=4) if target else (
                    b['engine_execution_seconds'] <= a['engine_execution_seconds']+max(.005,.05*a['engine_execution_seconds']))
            cpu=not target or b['cpu_seconds']<=a['cpu_seconds']*1.05
            rss=b['peak_rss_bytes']<=a['peak_rss_bytes']+max(256*MIB,.25*a['peak_rss_bytes'])
            decisions.append(dict(query=q,parallelism=p,medians=medians,paired_savings=savings,
                engine_gate=engine,cpu_gate=cpu,rss_gate=rss,passed=engine and cpu and rss))
        packet.update(status='passed',identities_unchanged=True,decisions=decisions,
            retained=all(r['passed'] for r in decisions),storage_after=storage())
    except BaseException as error:
        packet.update(status='failed',error=type(error).__name__+': '+str(error),retained=False)
        raise
    finally:
        save(ROOT/'outcome.json',packet)
        lock.rmdir()
    print(json.dumps({k:packet[k] for k in ('status','retained','decisions')}),flush=True)

if __name__=='__main__':
    main()
