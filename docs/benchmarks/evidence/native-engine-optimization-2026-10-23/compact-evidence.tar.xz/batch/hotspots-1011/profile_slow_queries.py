"""Two bounded diagnostic samples; profiled clocks are not speed comparisons."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
N = Path('/Users/dylan/LocalData/shardloom/native-engine-optimization-20261023')
ROOT = N / 'hotspots-1011'
sys.path.insert(0, str(W / 'scripts'))
from clickbench_reference_packet import load_reference_packet, query_statements
from clickbench_native_sql import native_query_statements
from native_workflow_protocol import extract_result, public_workflow_command, strict_json
from run_clickbench_query_uat import equivalent
from local_uat_storage import check_budgets, GIB, MIB

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

SUPERVISOR = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
GUARD = Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/native_workload_guard_816.py')
bounded = load('bounded', SUPERVISOR)
guards = load('guards', GUARD)

def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)

def save(path, payload):
    with path.open('x') as stream:
        json.dump(payload, stream, indent=2, allow_nan=False)
        stream.write('\n')

def read(path):
    return strict_json(Path(path).read_text())

def storage():
    return {str(path): check_budgets(path, path / 'reserved-artifact', path / 'logs',
        min_free_bytes=12*GIB, reserve_bytes=64*MIB,
        max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
        for path in (N, Path('/Users/dylan/.cache/shardloom/cargo-target'))}

baseline = read(N / 'full43-merged-run-1011.json')
build = read(N / 'merged-full43-build-1011.json')
assert baseline['status'] == build['status'] == 'passed'
binary = baseline['binary']
source = baseline['input']
reference = baseline['reference']
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()
assert head.startswith('959ed9ba')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=W,text=True).strip()

def verify():
    for item in (binary, source, reference):
        assert identity(item['path']) == item
    for relative, digest in build['source_after'].items():
        assert identity(W / relative)['sha256'] == digest, relative
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip() == head
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=W,text=True).strip()

queries = W / 'benchmarks/clickbench/queries.sql'
raw, original = query_statements(queries)
submitted, dialect = native_query_statements(original, hashlib.sha256(raw).hexdigest())
expected = load_reference_packet(Path(reference['path']), queries)
plan = ROOT / 'profiles-plan.json'
receipt = ROOT / 'profiles-receipt.json'
assert not plan.exists() and not receipt.exists()
verify()
record = dict(status='preparing', source_commit=baseline['source_commit'],
    harness_commit=head, binary=binary, input=source, reference=reference,
    baseline_receipt=identity(N / 'full43-merged-run-1011.json'),
    helper=identity(__file__), supervisor=identity(SUPERVISOR), workload_guard=identity(GUARD),
    query_dialect=dialect, queries=[19,23], observations=[], storage_before=storage(),
    purpose='Trace actual Q19 grouping and Q23 column-preparation stacks before selecting a runtime candidate.',
    interpretation='One diagnostic execution per selected query; sample overhead invalidates all speed comparisons. No Full43 score. Complete values remain required.',
    sampling=dict(duration_seconds=2, interval_milliseconds=1),
    input_hashing='Complete before and after the diagnostic set; cache state uncontrolled.',
    parallel_work=False)
save(plan, record)
workload = guards.WorkloadGuard()
workload.check()
try:
    for query in record['queries']:
        prefix = ROOT / f'q{query:02d}-profile'
        stdout = prefix.with_suffix('.stdout.json')
        stderr = prefix.with_suffix('.stderr.log')
        sample = prefix.with_suffix('.sample.txt')
        sample_log = prefix.with_suffix('.sample.log')
        assert not any(path.exists() for path in (stdout, stderr, sample, sample_log))
        command = public_workflow_command(binary['path'], submitted[query-1],
            input_path=source['path'], input_format='vortex', memory_gb=24, max_parallelism=12)
        row = dict(query=query, command=command, passed=False)
        record['observations'].append(row)
        sampler = None
        sampler_stream = None
        def guard():
            global sampler, sampler_stream
            workload.check(row.get('pid'))
            assert shutil.disk_usage(N).free >= 12*GIB
            if row.get('pid') and sampler is None:
                sampler_stream = sample_log.open('xb')
                sample_command = ['/usr/bin/sample',str(row['pid']),'2','1','-mayDie','-file',str(sample)]
                sampler = subprocess.Popen(sample_command,stdin=subprocess.DEVNULL,
                    stdout=sampler_stream,stderr=subprocess.STDOUT,start_new_session=True)
                row['sample_command'] = sample_command
                row['sample_pid'] = sampler.pid
            for path in (sample, sample_log):
                assert not path.exists() or path.stat().st_size <= 16*MIB
        print(f'Profiling Q{query}; this execution is diagnostic only.',flush=True)
        try:
            with stdout.open('xb') as out, stderr.open('xb') as err:
                status = bounded.run(command,cwd=W,env=dict(os.environ),output=out,
                    error_output=err,timeout=120,evidence=row,guard=guard,max_output_bytes=8*MIB)
            assert status == 0
            assert sampler is not None
            sampler.wait(timeout=15)
            assert sampler.returncode == 0
            assert sample.exists() and sample.stat().st_size > 0
            values = extract_result(read(stdout))
            assert equivalent(values, expected['values'][query])
            row.update(passed=True, validation='complete_values',
                output=identity(stdout), sample=identity(sample), sample_log=identity(sample_log))
        finally:
            if sampler is not None:
                row['sampler_cleanup'] = {}
                bounded._drain(sampler,row['sampler_cleanup'],3.0)
                row['sample_returncode'] = sampler.returncode
            if sampler_stream is not None:
                sampler_stream.close()
        print(f'Q{query} complete values and diagnostic sample passed.',flush=True)
    verify()
    workload.check()
    record.update(status='passed', identities_unchanged=True, storage_after=storage())
except BaseException as error:
    record.update(status='failed', error=type(error).__name__ + ': ' + str(error))
    raise
finally:
    save(receipt, record)
print(json.dumps(dict(status=record['status'], sampled_queries=record['queries'])),flush=True)
