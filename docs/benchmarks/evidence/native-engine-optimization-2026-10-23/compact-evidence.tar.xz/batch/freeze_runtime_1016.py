import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
N = Path('/Users/dylan/LocalData/shardloom/native-engine-optimization-20261023')
label, receipt_name = sys.argv[1:]
assert label.replace('-', '').isalnum()
receipt_path = N / (receipt_name + '.json')
receipt = json.loads(receipt_path.read_text())
digest = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert receipt['status'] == 'passed' and receipt['returncode'] == 0
assert receipt['process_group_drained'] and receipt['direct_child_reaped']
assert receipt['source_before'] == receipt['source_after']
assert receipt['command'] == ['cargo', 'test', '-p', 'shardloom-vortex', '--lib', '--features', 'release-user-surfaces', '--release', 'native_engine_optimization_cost_screen', '--no-run']
log_path = N / (receipt_name + '.log')
assert digest(log_path) == receipt['log_sha256']
log = log_path.read_text()
assert 'Compiling shardloom-vortex ' in log
executable, = re.findall(r'Executable unittests src/lib.rs \(([^)]+)\)', log)
source = Path(executable)
assert source.is_file() and source.parent == Path(receipt['target']) / 'release/deps'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=W, text=True).strip()
for path, expected in receipt['source_after'].items():
    assert digest(W / path) == expected, path
assert shutil.disk_usage(N).free >= (12 << 30) + source.stat().st_size
assert receipt['last_storage_bytes']['target_and_active_tasks'] + source.stat().st_size < 100 << 30
target = N / ('shardloom-engine-cost-' + label)
with source.open('rb') as inp, target.open('xb') as out:
    shutil.copyfileobj(inp, out)
target.chmod(source.stat().st_mode)
assert digest(source) == digest(target)
harnesses = ['shardloom-vortex/src/local_primitive_relational_engine_cost_tests.rs',
             'shardloom-vortex/src/local_primitive_relational_engine_cost_data.rs']
manifest = dict(revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip(),
    binary=str(target), binary_sha256=digest(target), profile='release', features=['release-user-surfaces'],
    harnesses={p:digest(W / p) for p in harnesses}, toolchain=receipt['toolchain'],
    build_receipt=str(receipt_path), build_receipt_sha256=digest(receipt_path),
    freeze_script_sha256=digest(__file__), source_manifest=receipt['source_after'])
manifest_path = N / (label + '-runtime.json')
with manifest_path.open('x') as out:
    json.dump(manifest, out, indent=2)
    out.write('\n')
print(json.dumps({k:manifest[k] for k in ['revision','binary','binary_sha256']}))
