"""Small Unicode reproduction and byte-dialect validation, with frozen runtime."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
N = Path('/Users/dylan/LocalData/shardloom/native-engine-optimization-20261023')
ROOT = N / 'clickbench-dialect-unicode-1010'
ROOT.mkdir(exist_ok=False)
sys.path[:0] = [str(W / 'scripts'), str(W / 'python/src')]
from clickbench_reference_packet import query_statements
from clickbench_native_sql import native_query_statements
from native_workflow_protocol import extract_result, public_workflow_command, report_fields, strict_json

def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

binary = N / 'shardloom-current-1010'
binary_before = identity(binary)
assert binary_before == json.loads((N / 'full43-current-run-1010.json').read_text())['binary']
library = Path('/Users/dylan/.cache/shardloom/cargo-target/debug/lib_native.dylib')
library_before = identity(library)
link = ROOT / 'fixture-writer.abi3.so'
os.link(library, link)
import shardloom
spec = importlib.util.spec_from_file_location('shardloom._native', link)
native = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = native
spec.loader.exec_module(native)
import pyarrow as pa

rows = [
    dict(CounterID=1, URL='é☃', Referer='https://www.a.test/é'),
    dict(CounterID=1, URL='a', Referer='https://www.a.test/☃'),
    dict(CounterID=2, URL='😀', Referer='https://b.test/😀'),
    dict(CounterID=2, URL='abcd', Referer='https://b.test/ab'),
    dict(CounterID=3, URL='', Referer=''),
]
schema = pa.schema([pa.field('CounterID', pa.int32(), nullable=False),
                    pa.field('URL', pa.string(), nullable=False),
                    pa.field('Referer', pa.string(), nullable=False)])
input_path = ROOT / 'unicode.vortex'
session = native.Session(native.ExecutionResources(128 << 20, 2))
try:
    source = session.from_arrow(pa.Table.from_pylist(rows, schema=schema))
    result = session.plan(native.Relation.scan('memory://fixture'),
                          sources=[('memory://fixture', source)]).write(input_path, 'write_vortex')
finally:
    session.close()
assert input_path.is_file()
raw, statements = query_statements(W / 'benchmarks/clickbench/queries.sql')
submitted, dialect = native_query_statements(statements, hashlib.sha256(raw).hexdigest())

def expected(query_id, byte_length):
    groups = {}
    for row in rows:
        value = row['URL' if query_id == 28 else 'Referer']
        if not value:
            continue
        key = row['CounterID'] if query_id == 28 else re.sub(r'^https?://(?:www\.)?([^/]+)/.*$', r'\1', value)
        groups.setdefault(key, []).append(value)
    out = []
    for key, values in groups.items():
        if len(values) <= 1:
            continue
        mean = sum(len(value.encode('utf-8')) if byte_length else len(value) for value in values) / len(values)
        result = dict(l=mean, c=len(values))
        result['CounterID' if query_id == 28 else 'k'] = key
        if query_id == 29:
            result['min_Referer_3'] = min(values)
        out.append(result)
    return sorted(out, key=lambda row: (-row['l'], row.get('CounterID', row.get('k'))))[:25]

checks = []
for query_id in (28, 29):
    for role, sql, byte_length in [('original_character_sql', statements[query_id - 1], False),
                                   ('explicit_byte_sql', submitted[query_id - 1], True)]:
        # A smaller HAVING threshold exercises both groups on this five-row input.
        sql = sql.replace('COUNT(*) > 100000', 'COUNT(*) > 1')
        command = public_workflow_command(binary, sql, input_path=input_path, input_format='vortex',
                                          memory_gb=1, max_parallelism=2)
        completed = subprocess.run(command, capture_output=True, timeout=30)
        output = ROOT / f'q{query_id}-{role}.json'
        output.write_bytes(completed.stdout)
        (ROOT / f'q{query_id}-{role}.stderr.txt').write_bytes(completed.stderr)
        assert completed.returncode == 0, completed.stderr.decode()
        envelope = strict_json(completed.stdout.decode())
        actual = extract_result(envelope)
        fields = report_fields(envelope)
        wanted = expected(query_id, byte_length)
        assert actual == wanted, (query_id, role, actual, wanted)
        assert fields['fallback_attempted'] == 'false' and fields['external_engine_invoked'] == 'false'
        if byte_length:
            assert fields['local_primitive_report_present'] == 'true'
            assert fields['local_primitive_native_io_certificate_path_id'] == 'native_vortex_source_to_scalar_aggregate_result'
        checks.append(dict(query=query_id, role=role, command=command, expected=wanted, actual=actual,
                           output=identity(output), passed=True,
                           primitive_provider=fields.get('local_primitive_report_present') == 'true'))
assert identity(binary) == binary_before and identity(library) == library_before
receipt = dict(status='passed', input=identity(input_path), input_rows=rows, binary=binary_before,
               fixture_writer=library_before, helper=identity(__file__), query_dialect=dialect,
               reduced_having_threshold=1, expected_calculation='Python Unicode code-point count or UTF-8 encoded byte count over explicit fixture rows',
               observations=checks)
(ROOT / 'receipt.json').write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + '\n')
print(json.dumps(dict(status='passed', observations=len(checks),
                      byte_provider_checks=sum(row['primitive_provider'] for row in checks))))
