"""Sequential whole-batch validation under the unchanged storage/process guard."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
N = Path('/Users/dylan/LocalData/shardloom/native-engine-optimization-20261023')
PYTHON = '/opt/homebrew/opt/python@3.13/bin/python3.13'
SUPERVISOR = N / 'run_validation_1007.py'
binary = Path(sys.argv[1])
assert binary.is_file() and binary.parent == N
features = 'shardloom-vortex/release-user-surfaces,shardloom-cli/release-user-surfaces'
steps = [
    ('final-format-1019', ['cargo', 'fmt', '--all', '--', '--check']),
    ('final-default-clippy-1019', ['cargo', 'clippy', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('final-default-tests-1019', ['cargo', 'test', '--workspace', '--all-targets']),
    ('final-native-clippy-1019', ['cargo', 'clippy', '--workspace', '--all-targets', '--features', features, '--', '-D', 'warnings']),
    ('final-native-tests-1019', ['cargo', 'test', '--workspace', '--all-targets', '--features', features]),
    ('final-all-features-1019', ['cargo', 'check', '--workspace', '--all-features']),
    ('final-clickbench-protocol-1020', [PYTHON, '-B', '-m', 'unittest', 'discover',
        '-s', 'scripts', '-p', 'test_clickbench_*.py']),
    ('final-admitted-semantics-1019', [PYTHON, '-B', 'scripts/check_admitted_semantics_matrix.py',
        '--repo-root', str(W), '--binary', str(binary), '--skip-build',
        '--work-dir', str(N / 'final-admitted-semantics-1019'),
        '--output', str(N / 'final-admitted-semantics-report-1019.json')]),
]
for label, _ in steps:
    assert not any((N / (label + suffix)).exists() for suffix in ['.json', '.log'])
assert not (N / 'final-admitted-semantics-1019').exists()
assert not (N / 'final-admitted-semantics-report-1019.json').exists()
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest = {
    'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip(),
    'driver_sha256': digest(Path(__file__)), 'supervisor_sha256': digest(SUPERVISOR),
    'binary': str(binary), 'binary_sha256': digest(binary),
    'commands': steps, 'completed': [], 'status': 'running',
}
with (N / 'final-validation-plan-1019.json').open('x') as out:
    json.dump(manifest, out, indent=2)
    out.write('\n')
status = 1
try:
    for label, command in steps:
        print(json.dumps({'starting': label, 'command': command}), flush=True)
        status = subprocess.call([PYTHON, '-B', str(SUPERVISOR), label, *command], cwd=W)
        receipt = N / (label + '.json')
        manifest['completed'].append({'label': label, 'returncode': status,
                                      'receipt_sha256': digest(receipt) if receipt.exists() else None})
        assert status == 0, label
        record = json.loads(receipt.read_text())
        assert record['status'] == 'passed' and record['process_group_drained'] and record['direct_child_reaped']
        assert record['source_before'] == record['source_after']
    assert digest(binary) == manifest['binary_sha256']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip() == manifest['source_commit']
    manifest['status'] = 'passed'
except BaseException as error:
    manifest['status'] = 'failed'
    manifest['failure'] = type(error).__name__ + ': ' + str(error)
    raise
finally:
    with (N / 'final-validation-outcome-1019.json').open('x') as out:
        json.dump(manifest, out, indent=2)
        out.write('\n')
print(json.dumps({'status': manifest['status'], 'steps': len(manifest['completed'])}), flush=True)
