import subprocess
import sys

binary = '/Users/dylan/.cache/shardloom/cargo-target/debug/deps/shardloom_vortex-26af6ca4771ea8fd'
filters = [
    'pure_predicate_',
    'predicate_filter_mask_',
    'local_primitives::native_relational_sort::tests::',
    'streamed_ordering_',
    'local_primitives::prepared_relational::tests::expression_tests::',
    'compact_local_selection_',
]
for selected in filters:
    print('selected=' + selected, flush=True)
    result = subprocess.run([binary, selected, '--nocapture', '--test-threads=1'])
    if result.returncode:
        sys.exit(result.returncode)
