import subprocess
import sys

result = subprocess.run(['cargo', 'test', '-p', 'shardloom-vortex', '--lib',
                         '--features', 'release-user-surfaces', 'composed_numeric_consumer_', '--no-run'])
if result.returncode:
    sys.exit(result.returncode)
sys.exit(subprocess.run([sys.executable, '-B', '/Users/dylan/LocalData/shardloom/native-engine-optimization-20261023/check_aggregates_1018.py']).returncode)
