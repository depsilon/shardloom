from pathlib import Path
import subprocess
import sys

binary = '/Users/dylan/.cache/shardloom/cargo-target/debug/deps/shardloom_vortex-26af6ca4771ea8fd'
filters = [
    'local_primitives::native_relational_keys::',
    'aggregate_reuse_',
    'local_primitives::prepared_relational::tests::aggregate_tests::',
    'streamed_ordering_',
]
for selected in filters:
    print('selected=' + selected, flush=True)
    result = subprocess.run([binary, selected, '--nocapture', '--test-threads=1'])
    if result.returncode:
        sys.exit(result.returncode)
