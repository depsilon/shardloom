# SPDX-License-Identifier: Apache-2.0
"""Retire completed generated artifacts after exact compact-record readback."""
import hashlib
import importlib.util
import json
import lzma
import os
from pathlib import Path
import shutil
import stat
import subprocess
import tarfile

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
N = Path('/Users/dylan/LocalData/shardloom/native-engine-optimization-20261023')
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
DEST = W / 'docs/benchmarks/evidence/native-engine-optimization-2026-10-23'
KEEP = {'shardloom-join-full43-1020', 'shardloom-engine-cost-join-revision-1020',
        'full43-join-plan-1020.json', 'full43-join-run-1020.json', 'full43-join-run-1020.log',
        'join-revision-1020-runtime.json', 'join-revision-release-build-1020.json',
        'join-revision-release-build-1020.log', 'join-cli-build-1020.json', 'join-cli-build-1020.log',
        'final-validation-plan-1019.json', 'final-validation-outcome-1019.json',
        'final-admitted-semantics-report-1019.json'}
RETIRE_DIRS = (
    'aggregate-comparison-1018', 'clickbench-dialect-unicode-1010',
    'clickbench-harness-1011', 'composed-comparison-1015',
    'expression-comparison-1017', 'expression-preflight-1017',
    'full43-aggregate-1018', 'full43-composed-1015', 'full43-current-1010',
    'full43-expression-1017', 'full43-merged-1011', 'full43-scan-text-1014',
    'full43-sort-prefix-1016', 'hotspots-1011', 'join-comparison-1019',
    'join-comparison-1020', 'preflight-1007', 'preflight-large-1007',
    'preflight-v2-1007', 'sort-prefix-comparison-1016', 'source-stage-1008',
    'tmp', 'witnesses', 'final-admitted-semantics-1019',
)


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}


def generation(path):
    value = path.lstat()
    return [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns]


def write_json(path, value):
    with path.open('x') as out:
        json.dump(value, out, indent=2)
        out.write('\n')


def closed(path, directory):
    command = ['/usr/sbin/lsof', '-nP']
    command += ['+D', str(path)] if directory else [str(path)]
    result = subprocess.run(command, capture_output=True, text=True)
    assert result.returncode == 1 and not result.stdout.strip() and not result.stderr.strip(), (
        path, result.returncode, result.stdout, result.stderr)


def main():
    assert not (DEST / 'cleanup.json').exists()
    final = json.loads((N / 'final-validation-outcome-1019.json').read_text())
    assert final['status'] == 'passed' and len(final['completed']) == 8
    build = json.loads((N / 'join-cli-build-1020.json').read_text())
    for step in final['completed']:
        path = N / (step['label'] + '.json')
        assert digest(path) == step['receipt_sha256'] and step['returncode'] == 0
        receipt = json.loads(path.read_text())
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert receipt['source_before'] == receipt['source_after'] == build['source_after']
    run = json.loads((N / 'full43-join-run-1020.json').read_text())
    assert run['status'] == 'passed' and run['result_rows'] == 381
    runtime = json.loads((N / 'join-revision-1020-runtime.json').read_text())
    retained = [identity(N / 'shardloom-join-full43-1020'), identity(Path(runtime['binary']))]
    assert retained[0] == run['binary'] and retained[0]['sha256'] == final['binary_sha256']
    assert retained[1]['sha256'] == runtime['binary_sha256']
    packet = json.loads((DEST / 'compact-evidence-package.json').read_text())
    archive = DEST / 'compact-evidence.tar.xz'
    manifest_path = DEST / 'compact-evidence-manifest.json'
    assert packet['status'] == 'passed' and packet['all_member_bytes_read_back']
    assert digest(archive) == packet['archive_sha256']
    assert digest(manifest_path) == packet['manifest_sha256']
    manifest = json.loads(manifest_path.read_text())
    preserved = {value['source']: value for value in manifest['members'].values()}
    # Recheck every archived byte before any retirement, without extracting it.
    seen = set()
    with tarfile.open(archive, 'r:xz') as packed:
        for member in packed:
            assert member.isfile() and member.name not in seen
            seen.add(member.name)
            data = packed.extractfile(member).read()
            if member.name == 'manifest.json':
                assert data == manifest_path.read_bytes()
            else:
                expected = manifest['members'][member.name]
                assert len(data) == expected['bytes']
                assert hashlib.sha256(data).hexdigest() == expected['sha256']
    assert seen == set(manifest['members']) | {'manifest.json'}
    assert len(manifest['members']) == packet['members']
    metadata = json.loads(subprocess.check_output(
        ['cargo', 'metadata', '--offline', '--no-deps', '--format-version', '1'], cwd=W,
        env=dict(os.environ, CARGO_TARGET_DIR=str(CACHE))))
    assert Path(metadata['target_directory']) == CACHE
    guard_path = Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/native_workload_guard_816.py')
    spec = importlib.util.spec_from_file_location('cleanup_guard', guard_path)
    guards = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(guards)
    guards.WorkloadGuard().check()
    protected = [Path(run['input']['path']), Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat/sources/hits.parquet')]
    protected_generations = {str(path): generation(path) for path in protected}
    roots = [CACHE / name for name in ('debug', 'release') if (CACHE / name).exists()]
    roots += [N / name for name in RETIRE_DIRS if (N / name).exists()]
    files = [path for path in sorted(N.iterdir()) if path.is_file() and path.name not in KEEP
             and path.suffix != '.py' and not path.name.startswith('final-')
             and path.name not in ('compact-evidence-package-1020.json',)]
    assert not (N / '.engine-cost.lock').exists()
    for root in roots:
        assert not root.is_symlink() and (root.parent == N or root.parent == CACHE)
        assert all(not Path(item['path']).is_relative_to(root) for item in retained)
        closed(root, True)
    for path in files:
        assert path.parent == N and not path.is_symlink()
        assert path.name.startswith('shardloom-') or str(path) in preserved or path in (
            N / 'compact-evidence-1020.tar.xz', N / 'compact-evidence-manifest-1020.json'), path
        closed(path, False)
    inventory = []
    candidates = list(files)
    for root in roots:
        for parent, directories, names in os.walk(root, followlinks=False):
            candidates += [Path(parent) / name for name in directories + names
                           if not (Path(parent) / name).is_dir() or (Path(parent) / name).is_symlink()]
    for path in candidates:
        before = generation(path)
        info = path.lstat()
        if stat.S_ISLNK(info.st_mode):
            row = {'path': str(path), 'kind': 'symlink', 'target': os.readlink(path)}
        else:
            assert stat.S_ISREG(info.st_mode), path
            row = identity(path) | {'kind': 'file'}
            if str(path) in preserved:
                expected = preserved[str(path)]
                assert row['bytes'] == expected['bytes'] and row['sha256'] == expected['sha256'], path
                row['basis'] = 'exact_record_in_verified_compact_packet'
            else:
                if path.is_relative_to(N / 'clickbench-harness-1011'):
                    relative = str(path.relative_to(N / 'clickbench-harness-1011'))
                    expected = run['harness_files'][relative]
                    assert row['bytes'] == expected['bytes'] and row['sha256'] == expected['sha256']
                if path == N / 'compact-evidence-1020.tar.xz':
                    assert row['sha256'] == packet['archive_sha256']
                if path == N / 'compact-evidence-manifest-1020.json':
                    assert row['sha256'] == packet['manifest_sha256']
                row['basis'] = 'completed_generated_artifact_regenerable_from_recorded_source_build_and_protocol'
        assert generation(path) == before, path
        row['generation'] = before
        inventory.append(row)
    raw = json.dumps({'roots': list(map(str, roots)), 'files': list(map(str, files)), 'entries': inventory}, sort_keys=True).encode()
    compressed = lzma.compress(raw)
    assert lzma.decompress(compressed) == raw
    inventory_path = DEST / 'cleanup-inventory.json.xz'
    with inventory_path.open('xb') as out:
        out.write(compressed)
    plan = {'status': 'planned', 'inventory': identity(inventory_path), 'retained': retained,
            'verified_packet': packet, 'helper': identity(Path(__file__)),
            'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip(),
            'protected_input_generations': protected_generations, 'active_handles_found': False,
            'payload_backups_created': False}
    write_json(N / 'retirement-plan-1020.json', plan)
    guards.WorkloadGuard().check()
    for row in inventory:
        path = Path(row['path'])
        assert generation(path) == row['generation'], path
        if row['kind'] == 'symlink':
            assert os.readlink(path) == row['target']
    for root in roots:
        closed(root, True)
    for path in files:
        closed(path, False)
    for root in roots:
        shutil.rmtree(root)
        assert not root.exists()
    for path in files:
        path.unlink()
    assert [identity(Path(row['path'])) for row in retained] == retained
    assert {str(path): generation(path) for path in protected} == protected_generations
    result = plan | {'status': 'passed', 'retired_entries': len(inventory),
                     'retired_regular_bytes': sum(row.get('bytes', 0) for row in inventory),
                     'original_parquet_and_current_vortex_input_untouched': True,
                     'runtime_or_benchmark_executed': False, 'storage_limits_changed': False,
                     'obsolete_compiler_outputs_removed': True}
    write_json(DEST / 'cleanup.json', result)
    write_json(N / 'retirement-outcome-1020.json', result)
    print(json.dumps({key: result[key] for key in ('status', 'retired_entries', 'retired_regular_bytes')}), flush=True)


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        failure = {'status': 'failed', 'error': type(error).__name__ + ': ' + str(error),
                   'plan_exists': (N / 'retirement-plan-1020.json').exists(),
                   'completed_receipt_exists': (DEST / 'cleanup.json').exists(),
                   'note': 'Inspect the exact saved plan and surviving paths before any continuation; do not repeat deletion blindly.'}
        write_json(N / 'retirement-failure-1020.json', failure)
        raise
