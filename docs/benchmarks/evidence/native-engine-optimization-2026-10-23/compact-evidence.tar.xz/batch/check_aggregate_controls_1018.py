import subprocess
import sys

binary = '/Users/dylan/.cache/shardloom/cargo-target/debug/deps/shardloom_vortex-26af6ca4771ea8fd'
names = [line.removesuffix(': test') for line in subprocess.check_output([binary, '--list'], text=True).splitlines() if line.endswith(': test')]
# The preceding receipt passed the first five selectors; its overlap assertion
# stopped before these controls. Preserve that observation and finish coverage.
for selector in ['native_relational_keys::', 'aggregate_tests::']:
    found = [name for name in names if selector in name]
    assert found, selector
    print('selected=' + selector + ' count=' + str(len(found)), flush=True)
    result = subprocess.run([binary, selector, '--nocapture', '--test-threads=1'])
    if result.returncode:
        sys.exit(result.returncode)
