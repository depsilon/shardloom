import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

N = Path('/Users/dylan/LocalData/shardloom/native-engine-optimization-20261023')
root = N / 'expression-preflight-1017'
assert not root.exists()
(root / 'witnesses').mkdir(parents=True)
binary = Path('/Users/dylan/.cache/shardloom/cargo-target/debug/deps/shardloom_vortex-26af6ca4771ea8fd')
test = 'local_primitives::prepared_relational::tests::engine_cost_tests::native_engine_optimization_cost_screen'
cases = [(case, rows) for rows in (257, 65536) for case in ('expression_shared', 'expression_unique')]
receipt = dict(protocol='native-engine-cost-v3', cases=cases, binary=str(binary),
               binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
               driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               complete=False, results=[])
try:
    for case, rows in cases:
        env = dict(os.environ, SHARDLOOM_ENGINE_COST_ROOT=str(root), SHARDLOOM_ENGINE_COST_CASE=case,
                   SHARDLOOM_ENGINE_COST_ROWS=str(rows), SHARDLOOM_ENGINE_COST_ROLE='baseline',
                   SHARDLOOM_ENGINE_COST_SAMPLE='0')
        result = subprocess.run([str(binary), test, '--ignored', '--exact', '--nocapture', '--test-threads=1'], env=env)
        receipt['results'].append(dict(case=case, rows=rows, returncode=result.returncode))
        if result.returncode:
            sys.exit(result.returncode)
        record = json.loads((root / f'observe-{case}-{rows}-baseline-0.json').read_text())
        assert record['protocol'] == 'native-engine-cost-v3'
        assert record['complete_values_match'] and record['complete_schema_match']
        assert record['reserved_after_cleanup'] == record['denied_reservations'] == 0
    receipt['complete'] = True
finally:
    with (root / 'preflight.json').open('x') as out:
        json.dump(receipt, out, indent=2)
        out.write('\n')
print(json.dumps(dict(complete=True, cases=len(cases))), flush=True)
