import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

N = Path('/Users/dylan/LocalData/shardloom/native-engine-optimization-20261023')
root = N / 'preflight-v2-1007'
assert not root.exists(), 'preserve earlier preflights'
(root / 'witnesses').mkdir(parents=True)
binary = Path('/Users/dylan/.cache/shardloom/cargo-target/debug/deps/shardloom_vortex-26af6ca4771ea8fd')
test = 'local_primitives::prepared_relational::tests::engine_cost_tests::native_engine_optimization_cost_screen'
cases = [(case,65536) for case in ['sort_many','sort_limit','predicate_filter','predicate_projected',
         'predicate_single','join_semi_duplicate','join_anti_duplicate','join_semi_unique','join_anti_unique']]
cases.append(('sort_single',257))
receipt = {'cases': cases, 'binary': str(binary),
           'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
           'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'unchanged_large_value_aggregate_cases': str(N / 'preflight-large-1007' / 'preflight.json'),
           'results': []}
for case,rows in cases:
    env = dict(os.environ, SHARDLOOM_ENGINE_COST_ROOT=str(root), SHARDLOOM_ENGINE_COST_CASE=case,
               SHARDLOOM_ENGINE_COST_ROWS=str(rows), SHARDLOOM_ENGINE_COST_ROLE='baseline',
               SHARDLOOM_ENGINE_COST_SAMPLE='0')
    result = subprocess.run([str(binary), test, '--ignored', '--exact', '--nocapture', '--test-threads=1'], env=env)
    receipt['results'].append({'case': case, 'rows': rows, 'returncode': result.returncode})
    (root / 'preflight.json').write_text(json.dumps(receipt, indent=2) + '\n')
    if result.returncode:
        sys.exit(result.returncode)
assert len(receipt['results']) == len(cases)
print(json.dumps({'complete': True, 'cases': len(cases)}), flush=True)
