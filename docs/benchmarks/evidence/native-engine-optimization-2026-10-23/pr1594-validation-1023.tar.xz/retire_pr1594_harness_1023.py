"""Retire only the completed PR observation's reconstructed harness checkout."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

N = Path('/Users/dylan/LocalData/shardloom/native-engine-optimization-20261023')
W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
H = N / 'clickbench-harness-pr1594-1022'
PLAN = N / 'pr1594-harness-cleanup-plan-1023.json'
RESULT = N / 'pr1594-harness-cleanup-1023.json'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def generation(path):
    value = path.stat()
    return [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns]


def main():
    assert not PLAN.exists() and not RESULT.exists()
    assert H.is_dir() and not H.is_symlink() and H.resolve().parent == N
    core = json.loads((N / 'pr1594-python-core-1023.json').read_text())
    assert core['status'] == 'passed' and core['process_group_drained']
    run = json.loads((N / 'full43-pr1594-run-1022.json').read_text())
    assert run['status'] == 'passed' and run['process_group_drained'] and run['uat_lock_released']
    assert run['harness_commit'] == 'cf286144cf502e322f6265192da4a29ca871d99e'
    evidence = W / 'docs/benchmarks/evidence/native-engine-optimization-2026-10-23'
    packet = json.loads((evidence / 'full43-pr1594-1022.json').read_text())
    manifest_raw = (evidence / packet['manifest']).read_bytes()
    members = json.loads(manifest_raw)['members']
    archive_path = evidence / packet['archive']
    assert sha(archive_path.read_bytes()) == packet['archive_sha256']
    assert sha(manifest_raw) == packet['manifest_sha256']
    seen = set()
    with tarfile.open(archive_path, 'r:xz') as archive:
        for entry in archive:
            assert entry.isfile() and entry.name not in seen
            seen.add(entry.name)
            raw = archive.extractfile(entry).read()
            if entry.name == 'manifest.json':
                assert raw == manifest_raw
            else:
                expected = members[entry.name]
                assert len(raw) == expected['bytes'] and sha(raw) == expected['sha256']
                assert raw == Path(expected['source']).read_bytes()
    assert seen == set(members) | {'manifest.json'}
    sources = run['harness_files']
    paths = list(H.rglob('*'))
    assert not any(p.is_symlink() for p in paths)
    files = {p.relative_to(H).as_posix(): p for p in paths if p.is_file()}
    assert len(files) == len(sources) == 246 and files.keys() == sources.keys()
    inventory = {}
    for name, path in sorted(files.items()):
        state = generation(path)
        raw = path.read_bytes()
        expected = sources[name]
        assert expected['path'] == str(path) and expected['bytes'] == len(raw)
        assert expected['sha256'] == sha(raw) and generation(path) == state
        restored = subprocess.check_output(['git', 'show', run['harness_commit'] + ':' + name], cwd=W)
        assert restored == raw, 'Git regeneration does not reproduce measured bytes'
        inventory[name] = dict(expected, generation=state)
    handles = subprocess.run(['/usr/sbin/lsof', '-nP', '+D', str(H)], capture_output=True, text=True)
    assert handles.returncode == 1 and not handles.stdout and not handles.stderr, handles.stdout + handles.stderr
    plan = {'status': 'verified_before_retirement', 'root': str(H),
            'regeneration_commit': run['harness_commit'], 'all_git_source_bytes_verified': True,
            'source_receipt': str(N / 'full43-pr1594-run-1022.json'),
            'source_receipt_sha256': sha((N / 'full43-pr1594-run-1022.json').read_bytes()),
            'entries': inventory, 'regular_file_count': len(inventory),
            'regular_file_bytes': sum(x['bytes'] for x in inventory.values()),
            'closed_handles_verified': True, 'runtime_and_inputs_preserved': True,
            'full43_output_packet_preserved': True, 'fresh_observation_archive_verified': True,
            'archive_members_verified': len(members), 'backup_created': False}
    PLAN.write_text(json.dumps(plan, indent=2) + '\n')
    for name, path in files.items():
        assert generation(path) == inventory[name]['generation']
        assert sha(path.read_bytes()) == inventory[name]['sha256']
    for path in files.values():
        path.unlink()
    for path in sorted((p for p in paths if p.is_dir()), key=lambda p: len(p.parts), reverse=True):
        path.rmdir()
    H.rmdir()
    assert not H.exists()
    result = {k: v for k, v in plan.items() if k != 'entries'}
    result.update(status='completed', plan=str(PLAN), plan_sha256=sha(PLAN.read_bytes()),
                  root_absent=True, program_sha256=sha(Path(__file__).read_bytes()))
    RESULT.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('status', 'regular_file_count', 'regular_file_bytes', 'root_absent')}))


if __name__ == '__main__':
    main()
