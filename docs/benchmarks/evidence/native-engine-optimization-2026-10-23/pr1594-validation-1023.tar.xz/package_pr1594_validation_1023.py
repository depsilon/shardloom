"""Preserve the PR follow-up's local validation and original hosted failures."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

N = Path('/Users/dylan/LocalData/shardloom/native-engine-optimization-20261023')
W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
DEST = W / 'docs/benchmarks/evidence/native-engine-optimization-2026-10-23'
ARCHIVE = DEST / 'pr1594-validation-1023.tar.xz'
MANIFEST = DEST / 'pr1594-validation-manifest-1023.json'
SUMMARY = DEST / 'pr1594-validation-1023.json'
LABELS = ('pr1594-website-install-1022', 'pr1594-website-audit-1022',
          'pr1594-website-build-1022', 'pr1594-website-types-1022',
          'pr1594-public-status-1022', 'pr1594-website-links-1022',
          'pr1594-readiness-1022', 'pr1594-static-assets-1022',
          'pr1594-matrix-reproduce-1023', 'pr1594-matrix-repaired-1023',
          'pr1594-python-core-1023')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def generation(path):
    value = path.stat()
    return [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns]


def main():
    assert not any(p.exists() for p in (ARCHIVE, MANIFEST, SUMMARY))
    assert shutil.disk_usage(N).free >= 12 * (1 << 30)
    run = json.loads((N / 'full43-pr1594-run-1022.json').read_text())
    build = json.loads(Path(run['build']['path']).read_text())
    compiled = build['source_after']
    assert build['source_before'] == compiled and len(compiled) == 1941
    current = {str(p.relative_to(W)): sha(p.read_bytes()) for p in W.rglob('*')
               if p.is_file() and 'target' not in p.parts
               and (p.suffix == '.rs' or p.name in ('Cargo.toml', 'Cargo.lock'))}
    assert current == compiled
    checks = []
    sources = {}
    for label in LABELS:
        receipt = N / (label + '.json')
        log = N / (label + '.log')
        record = json.loads(receipt.read_text())
        expected_failure = label == 'pr1594-matrix-reproduce-1023'
        assert record['status'] == ('failed' if expected_failure else 'passed')
        assert record['returncode'] == (1 if expected_failure else 0)
        assert record['process_group_drained'] and record['source_before'] == record['source_after']
        assert record['log_sha256'] == sha(log.read_bytes())
        checks.append({'label': label, 'command': record['command'], 'status': record['status'],
                       'returncode': record['returncode'], 'expected_reproduction_failure': expected_failure,
                       'process_group_drained': True, 'receipt': receipt.name,
                       'receipt_sha256': sha(receipt.read_bytes()), 'log': log.name,
                       'log_sha256': record['log_sha256']})
        sources[receipt.name] = receipt
        sources[log.name] = log
    for name in ('pr1594-hosted-failures-1023.json', 'pr1594-public-status-report-1022.json',
                 'pr1594-readiness-report-1022.json', 'pr1594-harness-cleanup-plan-1023.json',
                 'pr1594-harness-cleanup-1023.json', 'retire_pr1594_harness_1023.py',
                 'package_pr1594_validation_1023.py', 'run_validation_1007.py'):
        sources[name] = N / name
    core = N / 'pr1594-python-core-report-1023/core.json'
    sources['python-core-report.json'] = core
    core_result = json.loads(core.read_text())
    assert core_result['status'] == 'passed' and core_result['error_count'] == core_result['failure_count'] == 0
    cleanup = json.loads((N / 'pr1594-harness-cleanup-1023.json').read_text())
    assert cleanup['status'] == 'completed' and cleanup['root_absent']
    audit = json.loads((N / 'pr1594-website-audit-1022.log').read_text())
    assert not any(audit['metadata']['vulnerabilities'].values())
    lock_path = 'website-src/package-lock.json'
    original = json.loads(subprocess.check_output(['git', 'show', run['source_commit'] + ':' + lock_path], cwd=W))
    updated = json.loads((W / lock_path).read_text())
    assert original.keys() == updated.keys()
    assert {k: v for k, v in original.items() if k != 'packages'} == {k: v for k, v in updated.items() if k != 'packages'}
    assert original['packages'].keys() == updated['packages'].keys()
    changes = []
    for name, before in original['packages'].items():
        after = updated['packages'][name]
        if before != after:
            fields = [k for k in before.keys() | after.keys() if before.get(k) != after.get(k)]
            assert set(fields) == {'version', 'resolved', 'integrity'}
            changes.append({'package': name, 'before': before['version'], 'after': after['version'],
                            'license': after['license'], 'changed_fields': sorted(fields)})
    assert {x['package'] for x in changes} == {'node_modules/fast-uri', 'node_modules/undici'}
    assert (W / 'website-src/package.json').read_bytes() == subprocess.check_output(
        ['git', 'show', run['source_commit'] + ':website-src/package.json'], cwd=W)
    inputs = ('website-src/package.json', lock_path,
              'docs/benchmarks/evidence/native-independent-full43-2026-10-22/matrix-manifest.json',
              'docs/benchmarks/evidence/native-independent-full43-2026-10-22/verify_matrix_packet_951.py',
              'docs/benchmarks/evidence/native-independent-full43-2026-10-22/test_matrix_packet_951.py',
              'python/tests/test_independent_full43_evidence.py')
    input_hashes = {name: sha((W / name).read_bytes()) for name in inputs}
    members = {}
    for name, path in sources.items():
        state = generation(path)
        raw = path.read_bytes()
        assert generation(path) == state
        members[name] = {'source': str(path), 'bytes': len(raw), 'sha256': sha(raw), 'generation': state}
    assert sum(x['bytes'] for x in members.values()) < 32 * (1 << 20)
    manifest = {'schema_version': 'shardloom.pr_followup_validation_packet.v1', 'members': members}
    manifest_raw = (json.dumps(manifest, indent=2) + '\n').encode()
    with MANIFEST.open('xb') as stream:
        stream.write(manifest_raw)
    with tarfile.open(ARCHIVE, 'x:xz') as archive:
        for name, path in sources.items():
            raw = path.read_bytes()
            assert sha(raw) == members[name]['sha256'] and generation(path) == members[name]['generation']
            entry = tarfile.TarInfo(name)
            entry.size, entry.mode = len(raw), 0o644
            archive.addfile(entry, io.BytesIO(raw))
        entry = tarfile.TarInfo('manifest.json')
        entry.size, entry.mode = len(manifest_raw), 0o644
        archive.addfile(entry, io.BytesIO(manifest_raw))
    seen = set()
    with tarfile.open(ARCHIVE, 'r:xz') as archive:
        for entry in archive:
            assert entry.isfile() and entry.name not in seen
            seen.add(entry.name)
            raw = archive.extractfile(entry).read()
            if entry.name == 'manifest.json':
                assert raw == manifest_raw
            else:
                expected = members[entry.name]
                assert sha(raw) == expected['sha256'] and len(raw) == expected['bytes']
                assert raw == sources[entry.name].read_bytes() and generation(sources[entry.name]) == expected['generation']
    assert seen == set(members) | {'manifest.json'}
    result = {'status': 'passed_local_followup_validation',
              'pull_request': 'https://github.com/depsilon/shardloom/pull/1594',
              'initial_head': run['source_commit'], 'source_inputs': input_hashes,
              'compiled_source_files': len(compiled), 'compiled_sources_unchanged': True,
              'full43_engine_execution_seconds': run['engine_execution_seconds'],
              'full43_repeated_for_ci_repair': False, 'website_package_changes': changes,
              'website_manifest_and_dependency_ranges_unchanged': True,
              'npm_audit_vulnerabilities': audit['metadata']['vulnerabilities'],
              'local_versions': {'node': subprocess.check_output(['/opt/homebrew/bin/node', '--version'], text=True).strip(),
                                 'npm': subprocess.check_output(['/opt/homebrew/bin/npm', '--version'], text=True).strip(),
                                 'python': subprocess.check_output(['/opt/homebrew/bin/python3.13', '--version'], text=True).strip()},
              'hosted_version_boundary': 'CI uses Node 22 and Python 3.11; hosted confirmation is separate.',
              'historical_replay_tests': {'outer_tests': 2, 'full43_controls': 18, 'matrix_controls': 22,
                                          'original_measurement_packets_unchanged': True},
              'core_report': core_result, 'checks': checks, 'harness_cleanup': cleanup,
              'archive': ARCHIVE.name, 'archive_sha256': sha(ARCHIVE.read_bytes()),
              'archive_bytes': ARCHIVE.stat().st_size, 'manifest': MANIFEST.name,
              'manifest_sha256': sha(manifest_raw), 'member_count': len(members),
              'complete_byte_readback': True, 'hosted_checks_passed_claimed': False}
    with SUMMARY.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: result[k] for k in ('status', 'archive_bytes', 'member_count', 'compiled_sources_unchanged')}))


if __name__ == '__main__':
    main()
