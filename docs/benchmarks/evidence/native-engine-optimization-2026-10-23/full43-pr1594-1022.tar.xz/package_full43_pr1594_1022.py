"""Preserve the requested PR Full43 observation with complete member readback."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

N = Path('/Users/dylan/LocalData/shardloom/native-engine-optimization-20261023')
W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
DEST = W / 'docs/benchmarks/evidence/native-engine-optimization-2026-10-23'
ARCHIVE = DEST / 'full43-pr1594-1022.tar.xz'
MANIFEST = DEST / 'full43-pr1594-manifest-1022.json'
RECEIPT = DEST / 'full43-pr1594-1022.json'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def generation(path):
    value = path.stat()
    return [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns]


def main():
    assert not any(path.exists() for path in (ARCHIVE, MANIFEST, RECEIPT))
    record = json.loads((N / 'full43-pr1594-run-1022.json').read_text())
    assert record['status'] == 'passed' and record['result_rows'] == 381
    assert record['source_unchanged'] and record['process_group_drained']
    assert record['direct_child_reaped'] and record['uat_lock_released']
    assert record['pre_input_hash_verified'] and record['post_input_hash_verified']
    summary = json.loads(Path(record['summary']['path']).read_text())
    assert summary['repeats'] == 1 and summary['queries_passed'] == 43
    assert sum(row['engine_execution_seconds'] for row in summary['records']) == record['engine_execution_seconds']
    sources = {path.relative_to(N).as_posix(): path for path in (N / 'full43-pr1594-1022').rglob('*') if path.is_file()}
    for name in ('full43-pr1594-plan-1022.json', 'full43-pr1594-run-1022.json',
                 'full43-pr1594-run-1022.log', 'run_full43_pr1594_1022.py',
                 'package_full43_pr1594_1022.py', 'join-cli-build-1020.json',
                 'join-cli-build-1020.log', 'full43-join-run-1020.json',
                 'pr-contribution-governance-1022.json'):
        sources[name] = N / name
    for path in map(Path, summary['harness_sha256']):
        sources[path.relative_to(N).as_posix()] = path
    queries = N / 'clickbench-harness-pr1594-1022/benchmarks/clickbench/queries.sql'
    sources[queries.relative_to(N).as_posix()] = queries
    plan = json.loads((N / 'full43-pr1594-plan-1022.json').read_text())
    for field in ('reference', 'oracle_acceptance', 'supervisor', 'workload_guard'):
        path = Path(plan[field]['path'])
        sources['protocol/' + path.name] = path
    members = {}
    for name, path in sources.items():
        before = generation(path)
        content = path.read_bytes()
        assert generation(path) == before
        members[name] = {'source': str(path), 'bytes': len(content), 'sha256': digest(content), 'generation': before}
    manifest = {'schema_version': 'shardloom.full43.compact_observation.v1',
                'source_commit': record['source_commit'], 'members': members}
    raw_manifest = (json.dumps(manifest, indent=2) + '\n').encode()
    with MANIFEST.open('xb') as out:
        out.write(raw_manifest)
    with tarfile.open(ARCHIVE, 'x:xz') as archive:
        for name, path in sources.items():
            data = path.read_bytes()
            assert generation(path) == members[name]['generation'] and digest(data) == members[name]['sha256']
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            entry.mode = 0o644
            archive.addfile(entry, io.BytesIO(data))
        entry = tarfile.TarInfo('manifest.json')
        entry.size = len(raw_manifest)
        entry.mode = 0o644
        archive.addfile(entry, io.BytesIO(raw_manifest))
    seen = set()
    with tarfile.open(ARCHIVE, 'r:xz') as archive:
        for entry in archive:
            assert entry.isfile() and entry.name not in seen
            seen.add(entry.name)
            data = archive.extractfile(entry).read()
            if entry.name == 'manifest.json':
                assert data == raw_manifest
            else:
                expected = members[entry.name]
                assert len(data) == expected['bytes'] and digest(data) == expected['sha256']
                assert sources[entry.name].read_bytes() == data
                assert generation(sources[entry.name]) == expected['generation']
    assert seen == set(members) | {'manifest.json'}
    result = {key: record[key] for key in ('status', 'source_commit', 'source_tree', 'pull_request',
              'binary', 'binary_reused', 'input', 'reference', 'engine_execution_seconds',
              'result_rows', 'pre_input_hash_verified', 'post_input_hash_verified',
              'source_unchanged', 'process_group_drained', 'direct_child_reaped', 'uat_lock_released')}
    result.update(queries=43, executions_per_query=1, archive=ARCHIVE.name,
                  archive_sha256=digest(ARCHIVE.read_bytes()), archive_bytes=ARCHIVE.stat().st_size,
                  manifest=MANIFEST.name, manifest_sha256=digest(raw_manifest),
                  preserved_members=len(members), complete_byte_readback=True,
                  runtime_rebuilt=False, comparison_claim=False)
    with RECEIPT.open('x') as out:
        json.dump(result, out, indent=2)
        out.write('\n')
    print(json.dumps({key: result[key] for key in ('status', 'engine_execution_seconds', 'preserved_members', 'archive_bytes')}))


if __name__ == '__main__':
    main()
