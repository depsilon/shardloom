#!/usr/bin/env python3
"""Capture immutable GitHub Actions job metadata and complete logs for PR #1558."""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent
REPO = "depsilon/shardloom"
RUN_ID = 38808692838
EXPECTED_HEAD = "42440f5fb6585accb0553add4dad065820171cab"
GH = "/opt/homebrew/bin/gh"
JOBS = {
    116676671380: "Native Python wheel (py310_ubuntu)",
    116676671314: "Native Python wheel (py313_ubuntu)",
    116676671470: "Native Python wheel (py313_macos)",
    116676671203: "Rust feature matrix (native_public_surface_tests)",
    116676672971: "Python test shard (core)",
}


def call(args: list[str]) -> tuple[bytes, bytes, int]:
    p = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    return p.stdout, p.stderr, p.returncode


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    evidence: dict = {
        "schema": "shardloom.github_job_log_capture.v1",
        "captured_at_utc": datetime.now(timezone.utc).isoformat(),
        "repository": REPO,
        "run_id": RUN_ID,
        "expected_pr": 1558,
        "expected_head_sha": EXPECTED_HEAD,
        "capture_method": "GitHub REST API through gh api; logs endpoint response retained as exact UTF-8 log bytes",
        "commands": [],
        "run": {},
        "jobs": [],
        "errors": [],
    }
    run_cmd = [GH, "api", f"repos/{REPO}/actions/runs/{RUN_ID}"]
    run_bytes, run_err, rc = call(run_cmd)
    evidence["commands"].append({"argv": run_cmd, "exit_code": rc, "stderr": run_err.decode("utf-8", "replace")})
    if rc:
        evidence["errors"].append(f"run metadata command exit {rc}")
        run_obj = {}
    else:
        (OUT / f"run-{RUN_ID}.json").write_bytes(run_bytes)
        run_obj = json.loads(run_bytes)
        evidence["run"] = {
            "path": f"run-{RUN_ID}.json",
            "bytes": len(run_bytes),
            "sha256": sha(run_bytes),
            "id": run_obj.get("id"),
            "event": run_obj.get("event"),
            "status_at_capture": run_obj.get("status"),
            "conclusion_at_capture": run_obj.get("conclusion"),
            "run_attempt": run_obj.get("run_attempt"),
            "head_branch": run_obj.get("head_branch"),
            "head_sha": run_obj.get("head_sha"),
            "pull_requests": [
                {
                    "number": pr.get("number"),
                    "base_sha": pr.get("base", {}).get("sha"),
                    "head_sha": pr.get("head", {}).get("sha"),
                    "head_ref": pr.get("head", {}).get("ref"),
                }
                for pr in run_obj.get("pull_requests", [])
            ],
            "matches_expected_run_and_pr_head": (
                run_obj.get("id") == RUN_ID
                and any(
                    pr.get("number") == 1558
                    and pr.get("head", {}).get("sha") == EXPECTED_HEAD
                    for pr in run_obj.get("pull_requests", [])
                )
            ),
        }
    evidence["commands"].append({
        "argv": run_cmd,
        "exit_code": rc,
        "purpose": "fetch workflow-run metadata",
    })

    for job_id, expected_name in JOBS.items():
        metadata_cmd = [GH, "api", f"repos/{REPO}/actions/jobs/{job_id}"]
        metadata_bytes, metadata_err, metadata_rc = call(metadata_cmd)
        evidence["commands"].append({
            "argv": metadata_cmd,
            "exit_code": metadata_rc,
            "stderr": metadata_err.decode("utf-8", "replace"),
        })
        if metadata_rc:
            evidence["errors"].append(f"job {job_id} metadata command exit {metadata_rc}")
            continue
        metadata_path = OUT / f"job-{job_id}.json"
        metadata_path.write_bytes(metadata_bytes)
        job = json.loads(metadata_bytes)
        log_cmd = [GH, "api", f"repos/{REPO}/actions/jobs/{job_id}/logs"]
        log_bytes, log_err, log_rc = call(log_cmd)
        evidence["commands"].append({
            "argv": log_cmd,
            "exit_code": log_rc,
            "stderr": log_err.decode("utf-8", "replace"),
        })
        log_path = OUT / f"job-{job_id}.log"
        if log_rc == 0:
            log_path.write_bytes(log_bytes)
        else:
            evidence["errors"].append(f"job {job_id} logs command exit {log_rc}")
        log_text = log_bytes.decode("utf-8-sig", "replace") if log_rc == 0 else ""
        lines = log_text.splitlines()
        wheel_proof = None
        if expected_name.startswith("Native Python wheel"):
            marker = '"schema_version": "shardloom.native_python_wheel_proof.v1"'
            marker_line = next((i for i, line in enumerate(lines) if marker in line), None)
            if marker_line is not None:
                start_line = next(
                    (i for i in range(marker_line - 1, -1, -1) if lines[i].endswith("Z {")),
                    None,
                )
                try:
                    if start_line is None:
                        raise ValueError("opening JSON log line not found")
                    json_lines = []
                    for offset, line in enumerate(lines[start_line:]):
                        if "Z " not in line:
                            break
                        json_lines.append(line.split("Z ", 1)[1])
                        next_line = lines[start_line + offset + 1] if start_line + offset + 1 < len(lines) else ""
                        if json_lines[-1] == "}" and "##[group]" in next_line:
                            break
                    wheel_proof = json.loads("\n".join(json_lines))
                except (ValueError, json.JSONDecodeError) as exc:
                    evidence["errors"].append(f"job {job_id} embedded wheel proof JSON parse failed: {exc}")
                if wheel_proof is not None:
                    proof_path = OUT / f"wheel-proof-{job_id}.json"
                    proof_path.write_text(json.dumps(wheel_proof, indent=2, sort_keys=True) + "\n", encoding="utf-8")
            else:
                evidence["errors"].append(f"job {job_id} has no embedded wheel proof JSON marker")
        synthetic = []
        for i, line in enumerate(lines):
            if "HEAD is now at " in line or re.fullmatch(r"[0-9a-f]{40}", line.strip()):
                synthetic.append({"line": i + 1, "text": line})
        summaries = []
        for i, line in enumerate(lines):
            if (("Ran " in line and " test" in line)
                    or line.endswith("Z OK")
                    or "OK (skipped=" in line
                    or "test_count" in line
                    or "skipped_count" in line
                    or "failure_count" in line
                    or "error_count" in line
                    or "pytest" in line):
                summaries.append({"line": i + 1, "text": line})
        rust_results = [
            {"line": i + 1, "text": line}
            for i, line in enumerate(lines)
            if "test result:" in line
        ]
        set_test_mentions = [
            {"line": i + 1, "text": line}
            for i, line in enumerate(lines)
            if "test_" in line.lower()
            and any(term in line.lower() for term in ("stream_set", "set_stream", "set_union", "set_intersect", "set_except"))
        ]
        relevant = []
        needles = (
            ".whl", "Successfully installed", "Installing collected packages",
            "native binding", "native extension", "native CLI", "installed wheel",
            "site-packages", "extension module", "imported", "binding tests",
            "wheel install", "Installed", "Import", "native_library", "isolated_install",
        )
        for i, line in enumerate(lines):
            if any(n.lower() in line.lower() for n in needles):
                relevant.append({"line": i + 1, "text": line})
        job_record = {
            "job_id": job_id,
            "expected_name": expected_name,
            "metadata_path": metadata_path.name,
            "metadata_bytes": len(metadata_bytes),
            "metadata_sha256": sha(metadata_bytes),
            "metadata": {
                k: job.get(k) for k in (
                    "id", "name", "status", "conclusion", "run_id", "head_sha",
                    "head_branch", "started_at", "completed_at", "html_url",
                )
            },
            "metadata_matches_requested_run_head_and_job": (
                job.get("id") == job_id
                and job.get("run_id") == RUN_ID
                and job.get("head_sha") == EXPECTED_HEAD
                and job.get("name") == expected_name
                and job.get("status") == "completed"
                and job.get("conclusion") == "success"
            ),
            "steps": [
                {
                    k: step.get(k)
                    for k in ("name", "number", "status", "conclusion", "started_at", "completed_at")
                }
                for step in job.get("steps", [])
            ],
            "log_path": log_path.name,
            "log_bytes": len(log_bytes) if log_rc == 0 else None,
            "log_sha256": sha(log_bytes) if log_rc == 0 else None,
            "log_complete_final_marker": bool(lines and (
                "Cleaning up orphan processes" in lines[-1]
                or "Post job cleanup." in lines[-1]
                or "Complete job" in lines[-1]
            )),
            "synthetic_checkout_revision_lines": synthetic,
            "test_summary_lines": summaries,
            "rust_test_result_lines": rust_results,
            "python_native_set_test_name_mentions": set_test_mentions,
            "wheel_proof": ({
                "path": f"wheel-proof-{job_id}.json",
                "status": wheel_proof.get("status"),
                "python": wheel_proof.get("python"),
                "integration": wheel_proof.get("integration"),
                "installed_load": wheel_proof.get("installed_load"),
                "integrity": wheel_proof.get("integrity"),
                "unaudited_integrity": wheel_proof.get("unaudited_integrity"),
                "linux_audit": wheel_proof.get("linux_audit"),
                "step_results": [
                    {
                        "name": step.get("name"),
                        "returncode": step.get("returncode"),
                        "log": step.get("log"),
                        "log_sha256": step.get("log_sha256"),
                    }
                    for step in wheel_proof.get("steps", [])
                ],
            } if wheel_proof is not None else None),
            "native_install_and_library_evidence_lines": relevant,
        }
        evidence["jobs"].append(job_record)
    evidence["status"] = "COMPLETE" if (
        not evidence["errors"]
        and evidence.get("run", {}).get("matches_expected_run_and_pr_head")
        and len(evidence["jobs"]) == len(JOBS)
        and all(j["metadata_matches_requested_run_head_and_job"] for j in evidence["jobs"])
        and all(j["log_complete_final_marker"] for j in evidence["jobs"])
    ) else "NEEDS_REASONING"
    summary_path = OUT / "job-log-capture-summary-490.json"
    summary_path.write_text(json.dumps(evidence, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": evidence["status"],
        "summary": str(summary_path),
        "errors": evidence["errors"],
        "jobs": [
            {
                "job_id": j["job_id"],
                "name": j["metadata"].get("name"),
                "metadata_matches": j["metadata_matches_requested_run_head_and_job"],
                "log_bytes": j["log_bytes"],
                "log_sha256": j["log_sha256"],
                "synthetic": j["synthetic_checkout_revision_lines"][:3],
                "test_summary": j["test_summary_lines"][-10:],
                "install_evidence_count": len(j["native_install_and_library_evidence_lines"]),
            }
            for j in evidence["jobs"]
        ],
    }, indent=2))
    return 0 if evidence["status"] == "COMPLETE" else 1


if __name__ == "__main__":
    raise SystemExit(main())
