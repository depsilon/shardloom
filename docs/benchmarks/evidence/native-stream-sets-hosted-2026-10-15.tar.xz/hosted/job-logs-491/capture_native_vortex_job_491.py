#!/usr/bin/env python3
"""Capture the completed native_vortex_tests GitHub Actions job and test evidence."""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent
REPO = "depsilon/shardloom"
RUN_ID = 38808692838
JOB_ID = 116676671084
EXPECTED_HEAD = "42440f5fb6585accb0553add4dad065820171cab"
EXPECTED_MERGE = "f3c5c327db36c57de8ddf61f6675cdae53ae372c"
GH = "/opt/homebrew/bin/gh"
ROOT = Path("/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo")
SOURCE_FILES = [
    "shardloom-vortex/src/local_primitive_relational_tests.rs",
    "shardloom-vortex/src/local_primitive_relational_batch_input_tests.rs",
    "shardloom-vortex/src/local_primitive_relational_batch_set_tests.rs",
    "shardloom-vortex/src/local_primitive_relational_batch_set_pressure_tests.rs",
    "shardloom-vortex/src/local_primitive_relational_batch_set_fault_tests.rs",
]
EXPECTED_MODULE_FILES = [
    "shardloom-vortex/src/local_primitive_relational_batch_input_set_tests.rs",
    "shardloom-vortex/src/local_primitive_relational_batch_input_set_pressure_tests.rs",
    "shardloom-vortex/src/local_primitive_relational_batch_input_set_fault_tests.rs",
]


def call(args: list[str]) -> tuple[bytes, bytes, int]:
    p = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    return p.stdout, p.stderr, p.returncode


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    data: dict = {
        "schema": "shardloom.native_vortex_hosted_job_capture.v1",
        "captured_at_utc": datetime.now(timezone.utc).isoformat(),
        "repository": REPO,
        "run_id": RUN_ID,
        "job_id": JOB_ID,
        "expected_pr": 1558,
        "expected_head_sha": EXPECTED_HEAD,
        "expected_synthetic_checkout_sha": EXPECTED_MERGE,
        "commands": [],
        "errors": [],
    }

    def capture_json(label: str, endpoint: str, filename: str) -> dict | None:
        argv = [GH, "api", endpoint]
        raw, err, code = call(argv)
        data["commands"].append({
            "label": label,
            "argv": argv,
            "exit_code": code,
            "stderr": err.decode("utf-8", "replace"),
        })
        if code:
            data["errors"].append(f"{label} command failed with exit {code}")
            return None
        path = OUT / filename
        path.write_bytes(raw)
        return {
            "path": filename,
            "bytes": len(raw),
            "sha256": digest(raw),
            "value": json.loads(raw),
        }

    run = capture_json("final_run_metadata", f"repos/{REPO}/actions/runs/{RUN_ID}", f"run-{RUN_ID}.json")
    job = capture_json("job_metadata", f"repos/{REPO}/actions/jobs/{JOB_ID}", f"job-{JOB_ID}.json")
    log_argv = [GH, "api", f"repos/{REPO}/actions/jobs/{JOB_ID}/logs"]
    log_bytes, log_err, log_rc = call(log_argv)
    data["commands"].append({
        "label": "complete_job_log_bytes",
        "argv": log_argv,
        "exit_code": log_rc,
        "stderr": log_err.decode("utf-8", "replace"),
    })
    if log_rc:
        data["errors"].append(f"job log command failed with exit {log_rc}")
        log_text = ""
    else:
        log_path = OUT / f"job-{JOB_ID}.log"
        log_path.write_bytes(log_bytes)
        log_text = log_bytes.decode("utf-8-sig", "replace")
        lines = log_text.splitlines()
        data["log"] = {
            "path": log_path.name,
            "bytes": len(log_bytes),
            "sha256": digest(log_bytes),
            "line_count": len(lines),
            "first_line": lines[0] if lines else None,
            "last_line": lines[-1] if lines else None,
            "complete_cleanup_marker": bool(lines and lines[-1].endswith("Cleaning up orphan processes")),
        }
    lines = log_text.splitlines()
    data["run"] = None
    if run:
        value = run["value"]
        data["run"] = {
            "path": run["path"], "bytes": run["bytes"], "sha256": run["sha256"],
            "id": value.get("id"), "event": value.get("event"), "status": value.get("status"),
            "conclusion": value.get("conclusion"), "run_attempt": value.get("run_attempt"),
            "head_branch": value.get("head_branch"), "head_sha": value.get("head_sha"),
            "pull_requests": [
                {
                    "number": p.get("number"),
                    "base_sha": p.get("base", {}).get("sha"),
                    "head_sha": p.get("head", {}).get("sha"),
                    "head_ref": p.get("head", {}).get("ref"),
                }
                for p in value.get("pull_requests", [])
            ],
        }
    data["job"] = None
    if job:
        value = job["value"]
        data["job"] = {
            "path": job["path"], "bytes": job["bytes"], "sha256": job["sha256"],
            "id": value.get("id"), "name": value.get("name"), "status": value.get("status"),
            "conclusion": value.get("conclusion"), "run_id": value.get("run_id"),
            "head_branch": value.get("head_branch"), "head_sha": value.get("head_sha"),
            "started_at": value.get("started_at"), "completed_at": value.get("completed_at"),
            "steps": value.get("steps", []),
        }
    data["synthetic_checkout_lines"] = [
        {"line": i + 1, "text": line}
        for i, line in enumerate(lines)
        if "HEAD is now at " in line
    ]
    revision_lines = [
        {"line": i + 1, "text": line}
        for i, line in enumerate(lines)
        if line.endswith(f"Z {EXPECTED_MERGE}")
    ]
    data["full_checkout_revision_lines"] = revision_lines
    data["cargo_invocation_lines"] = [
        {"line": i + 1, "text": line}
        for i, line in enumerate(lines)
        if "##[group]Run cargo " in line or "cargo test" in line or "cargo nextest" in line
    ]
    data["vendor_related_lines"] = [
        {"line": i + 1, "text": line}
        for i, line in enumerate(lines)
        if "vendor" in line.lower()
    ]
    data["test_result_groups"] = [
        {
            "line": i + 1,
            "text": line,
            "context_before": lines[max(0, i - 3):i],
        }
        for i, line in enumerate(lines)
        if "test result:" in line
    ]
    vendor_commands = []
    for i, line in enumerate(lines):
        cleaned = re.sub(r"\x1b\[[0-9;]*m", "", line)
        payload = cleaned.split("Z ", 1)[-1]
        if not payload.startswith("cargo test --manifest-path vendor/"):
            continue
        command_lines = [payload]
        j = i + 1
        while j < len(lines):
            continuation = re.sub(r"\x1b\[[0-9;]*m", "", lines[j]).split("Z ", 1)[-1]
            if not continuation.strip().startswith("--"):
                break
            command_lines.append(continuation)
            if not continuation.rstrip().endswith("\\"):
                break
            j += 1
        vendor_commands.append({
            "command_start_line": i + 1,
            "command_lines": command_lines,
            "outcome_group": None,
        })
    for i, command in enumerate(vendor_commands):
        group_index = i + 1
        if group_index < len(data["test_result_groups"]):
            command["outcome_group"] = data["test_result_groups"][group_index]
    data["vendor_cargo_test_command_outcomes"] = vendor_commands
    data["test_failure_marker_lines"] = [
        {"line": i + 1, "text": line}
        for i, line in enumerate(lines)
        if " ... FAILED" in line
        or "test result: FAILED" in line
        or "error: test failed" in line.lower()
    ]
    data["test_result_groups_all_ok"] = all(
        "test result: ok." in group["text"] and "0 failed" in group["text"]
        for group in data["test_result_groups"]
    )

    source_rows = []
    source_test_map: dict[str, dict] = {}
    module_edges = []
    module_targets = (
        "local_primitive_relational_batch_input_tests.rs",
        "local_primitive_relational_batch_set_tests.rs",
        "local_primitive_relational_batch_set_pressure_tests.rs",
        "local_primitive_relational_batch_set_fault_tests.rs",
    )
    for relative in SOURCE_FILES:
        source_lines = (ROOT / relative).read_text(encoding="utf-8").splitlines()
        for i, line in enumerate(source_lines):
            if any(target in line for target in module_targets):
                module_edges.append({"path": relative, "line": i + 1, "text": line})
            elif re.match(r"\s*mod\s+(batch_input_tests|set_tests|pressure_tests|fault_tests);", line):
                module_edges.append({"path": relative, "line": i + 1, "text": line})
    for relative in SOURCE_FILES:
        path = ROOT / relative
        raw = path.read_bytes()
        source_lines = raw.decode("utf-8").splitlines()
        tests = []
        for i, line in enumerate(source_lines):
            match = re.match(r"\s*fn\s+(streaming_[A-Za-z0-9_]+)\s*\(", line)
            if match and any(
                source_lines[j].strip() == "#[test]"
                for j in range(max(0, i - 3), i)
            ):
                name = match.group(1)
                entry = {
                    "name": name,
                    "source_path": relative,
                    "line": i + 1,
                    "test_attribute_line": i,
                    "outcomes": [
                        {"line": j + 1, "text": logline}
                        for j, logline in enumerate(lines)
                        if name in logline and (" ... ok" in logline or " ... FAILED" in logline or " ... ignored" in logline)
                    ],
                }
                tests.append(entry)
                source_test_map[name] = entry
        source_rows.append({
            "path": relative,
            "bytes": len(raw),
            "sha256": digest(raw),
            "streaming_test_names": tests,
        })
    data["source_files"] = source_rows
    data["test_module_chain"] = module_edges
    data["expected_old_pattern_paths_absent"] = [
        {"path": rel, "exists": (ROOT / rel).exists()}
        for rel in EXPECTED_MODULE_FILES
    ]
    test_names = list(source_test_map.values())
    data["streaming_set_test_coverage"] = {
        "source_test_count": len(test_names),
        "matched_log_outcome_count": sum(len(t["outcomes"]) for t in test_names),
        "tests": test_names,
        "all_nine_names_have_logged_outcome": len(test_names) == 9 and all(t["outcomes"] for t in test_names),
    }

    expected_pr_match = bool(run and run["value"].get("id") == RUN_ID and any(
        p.get("number") == 1558 and p.get("head", {}).get("sha") == EXPECTED_HEAD
        for p in run["value"].get("pull_requests", [])
    ))
    expected_job_match = bool(job and job["value"].get("id") == JOB_ID
        and job["value"].get("run_id") == RUN_ID
        and job["value"].get("head_sha") == EXPECTED_HEAD
        and job["value"].get("status") == "completed"
        and job["value"].get("conclusion") == "success")
    synthetic_match = bool(revision_lines and any(
        "git log -1 --format=%H" in lines[x["line"] - 2]
        for x in revision_lines if x["line"] >= 2
    ))
    data["identity_checks"] = {
        "run_pr_head_match": expected_pr_match,
        "job_run_head_status_conclusion_match": expected_job_match,
        "synthetic_checkout_matches_expected_merge": synthetic_match,
    }
    data["status"] = "COMPLETE" if (
        not data["errors"] and expected_pr_match and expected_job_match and synthetic_match
        and data.get("log", {}).get("complete_cleanup_marker")
        and len(data["test_result_groups"]) > 0
        and data["test_result_groups_all_ok"]
        and not data["test_failure_marker_lines"]
        and data["streaming_set_test_coverage"]["all_nine_names_have_logged_outcome"]
        and len(vendor_commands) == 5
    ) else "NEEDS_REASONING"
    report_path = OUT / "native-vortex-job-audit-491.json"
    report_path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": data["status"],
        "report": str(report_path),
        "errors": data["errors"],
        "run": data["run"],
        "job": {k: data["job"].get(k) for k in ("id", "name", "status", "conclusion", "run_id", "head_sha", "started_at", "completed_at")} if data["job"] else None,
        "log": data.get("log"),
        "test_result_groups": data["test_result_groups"],
        "streaming_set_test_coverage": data["streaming_set_test_coverage"],
        "vendor_related_lines": data["vendor_related_lines"],
        "identity_checks": data["identity_checks"],
    }, indent=2))
    return 0 if data["status"] == "COMPLETE" else 1


if __name__ == "__main__":
    raise SystemExit(main())
