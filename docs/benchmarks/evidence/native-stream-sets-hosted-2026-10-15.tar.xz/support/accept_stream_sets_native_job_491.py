"""Primary acceptance of the final immutable native Vortex job capture."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent / 'stream-sets-hosted-488/job-logs-491'
HEAD = '42440f5fb6585accb0553add4dad065820171cab'
SYNTHETIC = 'f3c5c327db36c57de8ddf61f6675cdae53ae372c'


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    audit_path = OUT / 'native-vortex-job-audit-491.json'
    audit = json.loads(audit_path.read_text())
    assert audit['status'] == 'COMPLETE' and not audit['errors']
    assert len(audit['commands']) == 3 and all(row['exit_code'] == 0 for row in audit['commands'])
    assert all(audit['identity_checks'].values())
    for label in ('run', 'job', 'log'):
        row = audit[label]
        actual = identity(OUT / row['path'])
        assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256']
    run = json.loads((OUT / audit['run']['path']).read_text())
    job = json.loads((OUT / audit['job']['path']).read_text())
    assert run['id'] == job['run_id'] == 38808692838 and job['id'] == 116676671084
    assert all(row['head_sha'] == HEAD and row['status'] == 'completed' and row['conclusion'] == 'success'
               for row in (run, job))
    assert any(pr['number'] == 1558 and pr['head']['sha'] == HEAD for pr in run['pull_requests'])
    raw_lines = (OUT / audit['log']['path']).read_text().lstrip('\ufeff').splitlines()
    plain = '\n'.join(re.sub(r'^\d{4}-\d{2}-\d{2}T\S+Z ', '', line) for line in raw_lines)
    assert SYNTHETIC + ':refs/remotes/pull/1558/merge' in plain
    assert plain.splitlines()[-1] == 'Cleaning up orphan processes'
    groups = [tuple(map(int, row)) for row in re.findall(
        r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', plain, re.M)]
    assert groups == [(2822, 0, 26), (10, 0, 0), (7, 0, 0), (7, 0, 0), (23, 0, 0), (4, 0, 0)]
    assert not re.search(r'^test .* \.\.\. FAILED$|^test result: FAILED', plain, re.M)
    ignored = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', plain, re.M)
    assert len(ignored) == 26
    tests = []
    for source in audit['source_files']:
        raw = subprocess.check_output(['git', 'show', HEAD + ':' + source['path']], cwd=ROOT)
        assert len(raw) == source['bytes'] and hashlib.sha256(raw).hexdigest() == source['sha256']
        actual = re.findall(r'#\[test\]\s*(?:#\[[^\n]+\][^\n]*\n\s*)*fn (streaming_\w+)\(', raw.decode())
        expected = [row['name'] for row in source['streaming_test_names']]
        assert sorted(actual) == sorted(expected), source['path']
        lines = raw.decode().splitlines()
        for test in source['streaming_test_names']:
            assert lines[test['line'] - 1].strip().startswith('fn ' + test['name'] + '(')
            assert len(test['outcomes']) == 1
            outcome = test['outcomes'][0]
            assert raw_lines[outcome['line'] - 1] == outcome['text']
            assert outcome['text'].endswith('::' + test['name'] + ' ... ok')
            tests.append(test)
    assert len(tests) == len({row['name'] for row in tests}) == 9
    assert len(audit['vendor_cargo_test_command_outcomes']) == 5
    for index, command in enumerate(audit['vendor_cargo_test_command_outcomes'], 1):
        line = raw_lines[command['command_start_line'] - 1]
        assert command['command_lines'][0] in line
        group = command['outcome_group']
        assert group == audit['test_result_groups'][index]
        assert raw_lines[group['line'] - 1] == group['text']
    report = dict(schema_version='shardloom.native_stream_sets_primary_native_job.v1', status='passed',
        head=HEAD, synthetic=SYNTHETIC, run=identity(OUT / audit['run']['path']),
        job=identity(OUT / audit['job']['path']), raw_log=identity(OUT / audit['log']['path']),
        capture_audit=identity(audit_path), capture_helper=identity(OUT / 'capture_native_vortex_job_491.py'),
        acceptance_helper=identity(Path(__file__)), result_groups=groups,
        total_passed=sum(group[0] for group in groups), ignored_test_reasons=ignored,
        new_tests=tests, vendor_commands=audit['vendor_cargo_test_command_outcomes'],
        verifier_correction='The first source-name regex omitted an intervening allow attribute on the fault test. The corrected source parser includes it; no engine test was rerun.')
    (OUT / 'primary-acceptance-491.json').open('x').write(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(status='passed', total_passed=report['total_passed'], new_set_tests=9,
                          ignored=26, result_groups=groups)))


if __name__ == '__main__':
    main()
