"""Primary acceptance of complete captured wheel, core and public-runtime logs."""
import hashlib
import json
from pathlib import Path
import re

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent / 'stream-sets-hosted-488/job-logs-490'
HEAD = '42440f5fb6585accb0553add4dad065820171cab'
SYNTHETIC = 'f3c5c327db36c57de8ddf61f6675cdae53ae372c'


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def normalize(path):
    return '\n'.join(re.sub(r'^\d{4}-\d{2}-\d{2}T\S+Z ', '', line)
                     for line in path.read_text().lstrip('\ufeff').splitlines())


def proof(text, schema):
    marker = '"schema_version": "' + schema + '"'
    assert text.count(marker) == 1
    offset = text.index(marker)
    start = text.rfind('\n{\n', 0, offset) + 1
    assert start > 0
    result, end = json.JSONDecoder().raw_decode(text[start:])
    assert result['schema_version'] == schema
    return result, dict(start=start, end=start + end)


def main():
    summary_path = OUT / 'job-log-capture-summary-490.json'
    summary = json.loads(summary_path.read_text())
    assert summary['status'] == 'COMPLETE' and not summary['errors']
    assert summary['expected_head_sha'] == HEAD and summary['run_id'] == 38808692838
    assert len(summary['jobs']) == 5 and all(command['exit_code'] == 0 for command in summary['commands'])
    run_path = OUT / summary['run']['path']
    assert identity(run_path)['sha256'] == summary['run']['sha256']
    run = json.loads(run_path.read_text())
    assert run['id'] == 38808692838 and run['head_sha'] == HEAD
    assert any(pr['number'] == 1558 and pr['head']['sha'] == HEAD for pr in run['pull_requests'])
    wheels, parsed = [], {}
    for row in summary['jobs']:
        metadata_path = OUT / row['metadata_path']
        log_path = OUT / row['log_path']
        for path, prefix in ((metadata_path, 'metadata'), (log_path, 'log')):
            ident = identity(path)
            assert ident['bytes'] == row[prefix + '_bytes'] and ident['sha256'] == row[prefix + '_sha256']
        metadata = json.loads(metadata_path.read_text())
        assert metadata['id'] == row['job_id'] and metadata['run_id'] == 38808692838
        assert metadata['head_sha'] == HEAD and metadata['name'] == row['expected_name']
        assert metadata['status'] == 'completed' and metadata['conclusion'] == 'success'
        text = normalize(log_path)
        assert SYNTHETIC + ':refs/remotes/pull/1558/merge' in text
        assert text.splitlines()[-1].startswith('Cleaning up orphan processes')
        assert not re.search(r'^test .* \.\.\. FAILED$', text, re.M)
        if metadata['name'].startswith('Native Python wheel'):
            result, offsets = proof(text, 'shardloom.native_python_wheel_proof.v1')
            assert result == json.loads((OUT / row['wheel_proof']['path']).read_text())
            assert result['status'] == result['stage']['status'] == result['integrity']['status'] == 'passed'
            assert result['integration'] == dict(tests=87, failures=0, errors=0, skipped=0, status='passed')
            assert result['installed_load']['isolated_install'] and result['installed_load']['version'] == '0.6.0'
            assert result['uninstall_status'] == 'passed'
            assert result['publication_attempted'] is False and result['performance_claim'] is False
            assert all(step['returncode'] == 0 for step in result['steps'])
            steps = {step['name']: step for step in result['steps']}
            assert {'load', 'integration', 'install', 'uninstall', 'verify_uninstalled'} <= steps.keys()
            assert '-I' in steps['load']['command'] and '-I' in steps['integration']['command']
            assert result['integrity']['native_library_sha256'] in steps['load']['command']
            assert result['integrity']['cli_sha256'] in steps['load']['command']
            assert result['integrity']['load_verified'] is False
            if 'ubuntu' in metadata['name']:
                assert result['linux_audit']['status'] == 'passed' and result['integrity']['linux_audit_verified']
            wheels.append(dict(job_id=row['job_id'], name=metadata['name'], raw=identity(log_path),
                proof=result, normalized_offsets=offsets))
        else:
            parsed[row['job_id']] = (text, identity(log_path))
    assert len(wheels) == 3
    core_text, core_raw = parsed[116676672971]
    core, core_offsets = proof(core_text, 'shardloom.python_test_shard_evidence.v1')
    assert core['status'] == 'passed' and core['test_count'] == 606 and core['skipped_count'] == 11
    assert core['failure_count'] == core['error_count'] == 0
    assert 'python.tests.test_native_set_binding' in core['modules']
    assert 'Ran 519 tests in 19.537s' in core_text and 'OK (skipped=11)' in core_text
    public_text, public_raw = parsed[116676671203]
    groups = [tuple(map(int, row)) for row in re.findall(
        r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', public_text, re.M)]
    assert groups == [(946, 0, 0), (0, 0, 0), (6, 0, 0), (65, 0, 0), (44, 0, 0), (15, 0, 0)]
    report = dict(schema_version='shardloom.native_stream_sets_primary_hosted_jobs.v1', status='passed',
        head=HEAD, ci_merge=SYNTHETIC, capture=identity(summary_path),
        capture_helper=identity(OUT / 'capture_job_logs_490.py'), acceptance_helper=identity(Path(__file__)),
        wheel_lanes=wheels, core=dict(raw=core_raw, machine_report=core, normalized_offsets=core_offsets,
            console_tests_run=519, discovered=606, skipped=11),
        public_runtime=dict(raw=public_raw, result_groups=groups),
        interpretation={
            'integrity_load_verified_false': 'The packaging integrity function does not load libraries; the separate isolated load step checks installation paths, library/CLI hashes and runtime versions and passes on all three lanes.',
            'individual_test_names': 'The hosted wheel log embeds the 87-test integration result, not the individual test transcript; no individual name observation is claimed.',
            'command_records': 'The capture helper records the one run-metadata command twice. There are 12 command records, representing 11 distinct read commands.',
            'core_skips': 'Hosted core has 11 skip records; local core had 9. Both report 606 discovered and 519 run. All wheel integration lanes have zero skips.',
            'scope': 'Five completed jobs only. Overall CI and native Vortex completion must be verified separately.'})
    with (OUT / 'primary-acceptance-490.json').open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status='passed', wheel_lanes=3, tests_per_wheel=87,
        core_discovered=606, core_run=519, core_skipped=11, public_result_groups=groups)))


if __name__ == '__main__':
    main()
