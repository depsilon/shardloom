"""Verify and package complete PR1558 hosted evidence without rerunning tests."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile

import accept_stream_sets_hosted_jobs_490 as jobs
import verify_stream_sets_integrated_sources_490 as sources

ROOT = sources.ROOT
OUT = sources.OUT
RAW = OUT / 'stream-sets-hosted-488'
HEAD = sources.HEAD
SYNTHETIC = sources.SYNTHETIC
MERGE = 'e859b3a8b9d323587cee9641f5ebacd21e7e799c'
sys.path.insert(0, str(ROOT / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def read(path):
    return json.loads(Path(path).read_text())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


def match_identity(record):
    assert identity(record['path']) == {k: record[k] for k in ('path', 'bytes', 'sha256')}


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def result_groups(path, expected):
    text = jobs.normalize(path)
    assert SYNTHETIC + ':refs/remotes/pull/1558/merge' in text
    assert text.splitlines()[-1].startswith('Cleaning up orphan processes')
    actual = [list(map(int, row)) for row in re.findall(
        r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)]
    assert actual == expected, actual
    assert not re.search(r'^test .* \.\.\. FAILED$|^test result: FAILED', text, re.M)
    return text


def served(stage, revision):
    folder = RAW / (stage + '-served-490')
    report = read(folder / 'report.json')
    assert report['status'] == 'passed' and report['stage'] == stage
    assert report['head'] == revision and report['reviewed_head'] == HEAD
    match_identity(dict(report['helper'], bytes=Path(report['helper']['path']).stat().st_size))
    checks = read(folder / 'deployment-checks.json')
    assert checks['total_count'] == len(checks['check_runs']) <= 100
    workers = [row for row in checks['check_runs'] if row['name'] == 'Workers Builds: shardloom']
    assert len(workers) == 1
    worker = workers[0]
    assert worker['head_sha'] == revision and worker['status'] == 'completed' and worker['conclusion'] == 'success'
    assert all(report['deployment'][key] == worker[key] for key in report['deployment'])
    versions = re.findall(r'Version ID: ([0-9a-f-]{36})', worker['output']['summary'])
    assert len(versions) == 1
    pr = read(folder / 'pull-request.json')
    assert pr['number'] == 1558 and pr['head']['sha'] == HEAD
    if stage == 'production':
        assert pr['merged'] and pr['merge_commit_sha'] == MERGE
    assert len(report['responses']) == len({r['source'] for r in report['responses']}) == 8
    for row in report['responses']:
        actual = (folder / row['response']).read_bytes()
        expected = subprocess.check_output(['git', 'show', revision + ':' + row['source']], cwd=ROOT)
        assert row['http_status'] == 200 and row['source_preserved']
        assert row['observed_bytes'] == len(actual) and row['observed_sha256'] == digest(actual)
        assert row['expected_bytes'] == len(expected) and row['expected_sha256'] == digest(expected)
        assert row['raw_byte_identical'] == (actual == expected)
        assert read(folder / (row['response'] + '.attempts.json')) == row['attempts']
        assert row['attempts'][-1]['status'] == 'passed' and 1 <= len(row['attempts']) <= 3
        if actual != expected:
            prefix = next(i for i, (a, b) in enumerate(zip(actual, expected)) if a != b)
            extra = len(actual) - len(expected)
            assert 0 < extra <= 16384 and row['source'].endswith('.html')
            inserted = actual[prefix:prefix + extra]
            assert actual[prefix + extra:] == expected[prefix:]
            assert b'/cdn-cgi/challenge-platform/' in inserted or b'static.cloudflareinsights.com/' in inserted
            assert row['insertion_bytes'] == extra and row['insertion_sha256'] == digest(inserted)
    return dict(report=report, deployment_version=versions[0])


def main():
    destination = require_local_path(OUT / 'stream-sets-hosted-packet-492', Path.home(), sys.platform)
    check_budgets(OUT, destination, OUT / 'logs', min_free_bytes=12*GIB,
                  reserve_bytes=128*MIB, max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
    assert not destination.exists()
    checks = read(RAW / 'checks-final-491.json')['structuredContent']
    assert checks['headRevision'] == HEAD and not checks['hasMore'] and not checks['statuses']
    assert len(checks['checks']) == len({row['id'] for row in checks['checks']}) == 44
    assert all(row['head_sha'] == HEAD and row['status'] == 'completed' and row['conclusion'] == 'success'
               for row in checks['checks'])
    merge = read(RAW / 'merge-491.json')['structuredContent']
    assert merge['merged'] and merge['sha'] == MERGE
    review = read(RAW / 'review-state-final-491.json')['data']['repository']['pullRequest']
    assert review['headRefOid'] == HEAD and review['number'] == 1558
    for kind in ('reviews', 'reviewThreads'):
        assert not review[kind]['pageInfo']['hasNextPage'] and review[kind]['nodes'] == []
    comments = read(RAW / 'issue-comments-final-491.json')['structuredContent']['comments']
    bot = [r for r in comments if r['user']['login'] == 'chatgpt-codex-connector[bot]']
    assert len(bot) == 1
    state = json.loads(re.search(r'<!-- codex-review-state:v1 (.*?) -->', bot[0]['body']).group(1))['code_review']
    assert state == dict(commit_sha=HEAD, has_any_findings=False, has_unresolved_findings=False, status='completed')

    sources.selector_check()
    source = read(RAW / 'integrated-sources-491.json')
    assert source['status'] == 'passed' and source['selector_ast_matches']
    immutable, records = sources.immutable.immutable_source_map(MERGE)
    accepted = read(sources.ACCEPTED)['source_sha256']
    assert len(immutable) == len(accepted) == source['source_files'] == 2272
    assert {p: row['sha256'] for p, row in immutable.items()} == accepted
    assert source['immutable_source'] == immutable
    assert all(mode in ('100644', '100755') for _, _, mode in records)
    trees = {revision: subprocess.check_output(['git', 'rev-parse', revision + '^{tree}'], cwd=ROOT, text=True).strip()
             for revision in (HEAD, SYNTHETIC, MERGE)}
    assert set(trees.values()) == {sources.TREE}
    for record in [source['accepted'], source['artifact_manifest'], *source['helpers'], *source['binaries'].values()]:
        match_identity(record)

    native = read(RAW / 'job-logs-491/primary-acceptance-491.json')
    assert native['status'] == 'passed' and native['head'] == HEAD and native['synthetic'] == SYNTHETIC
    for key in ('run', 'job', 'raw_log', 'capture_audit', 'capture_helper', 'acceptance_helper'):
        match_identity(native[key])
    for key in ('run', 'job'):
        metadata = read(native[key]['path'])
        assert metadata['head_sha'] == HEAD and metadata['status'] == 'completed' and metadata['conclusion'] == 'success'
    groups = [[2822, 0, 26], [10, 0, 0], [7, 0, 0], [7, 0, 0], [23, 0, 0], [4, 0, 0]]
    text = result_groups(Path(native['raw_log']['path']), groups)
    assert native['result_groups'] == groups and native['total_passed'] == 2873
    assert [list(r) for r in re.findall(r'^test (.+) \.\.\. ignored, (.+)$', text, re.M)] == native['ignored_test_reasons']
    assert len(native['new_tests']) == len({r['name'] for r in native['new_tests']}) == 9
    assert all('::' + r['name'] + ' ... ok' in text for r in native['new_tests'])

    runtime = read(RAW / 'job-logs-490/primary-acceptance-490.json')
    assert runtime['status'] == 'passed' and runtime['head'] == HEAD and runtime['ci_merge'] == SYNTHETIC
    for key in ('capture', 'capture_helper', 'acceptance_helper'):
        match_identity(runtime[key])
    assert len(runtime['wheel_lanes']) == 3
    for wheel in runtime['wheel_lanes']:
        match_identity(wheel['raw'])
        text = jobs.normalize(Path(wheel['raw']['path']))
        assert SYNTHETIC + ':refs/remotes/pull/1558/merge' in text
        proof, offsets = jobs.proof(text, 'shardloom.native_python_wheel_proof.v1')
        assert proof == wheel['proof'] and offsets == wheel['normalized_offsets']
        assert proof['integration'] == dict(tests=87, failures=0, errors=0, skipped=0, status='passed')
        assert proof['status'] == proof['stage']['status'] == proof['integrity']['status'] == proof['uninstall_status'] == 'passed'
        assert proof['installed_load']['isolated_install'] and proof['installed_load']['version'] == '0.6.0'
        assert all(row['returncode'] == 0 for row in proof['steps'])
        assert proof['publication_attempted'] is False and proof['performance_claim'] is False
        metadata = read(RAW / ('job-logs-490/job-' + str(wheel['job_id']) + '.json'))
        assert metadata['head_sha'] == HEAD and metadata['status'] == 'completed' and metadata['conclusion'] == 'success'
    public = runtime['public_runtime']
    match_identity(public['raw'])
    result_groups(Path(public['raw']['path']), [[946, 0, 0], [0, 0, 0], [6, 0, 0], [65, 0, 0], [44, 0, 0], [15, 0, 0]])
    assert sum(r[0] for r in public['result_groups']) == 1076
    core = runtime['core']
    match_identity(core['raw'])
    text = jobs.normalize(Path(core['raw']['path']))
    core_proof, offsets = jobs.proof(text, 'shardloom.python_test_shard_evidence.v1')
    assert core_proof == core['machine_report'] and offsets == core['normalized_offsets']
    assert core_proof['status'] == 'passed' and core_proof['test_count'] == core['discovered'] == 606
    assert core_proof['skipped_count'] == core['skipped'] == 11 and core['console_tests_run'] == 519
    assert 'Ran 519 tests in 19.537s' in text and 'OK (skipped=11)' in text

    served_reports = dict(preview=served('preview', HEAD), production=served('production', MERGE))
    browsers = {stage: read(RAW / filename) for stage, filename in
                [('preview', 'preview-browser-490.json'), ('production', 'production-browser-492.json')]}
    expected_guides = {'benchmark-methodology', 'runtime-and-io', 'limitations', 'python-surface'}
    for stage, browser in browsers.items():
        assert browser['status'] == 'passed' and browser['stage'] == stage and browser['reviewed_head'] == HEAD
        assert set(browser['guides']) == expected_guides
        assert browser['viewport_css_width'] == browser['document_scroll_width_each'] == 1265
    assert browsers['production']['merged_revision'] == MERGE
    report = dict(schema_version='shardloom.native_stream_sets_hosted_verification.v1', status='passed',
        recorded_at=datetime.now(timezone.utc).isoformat(), pr=1558, head=HEAD, merge=MERGE,
        synthetic=SYNTHETIC, trees=trees, checks_passed=44, native_test_groups=groups,
        native_total=2873, native_manual_exclusions=26, native_public_total=1076,
        wheel_lanes=3, wheel_tests_per_lane=87, core_discovered=606, core_run=519, core_skipped=11,
        source_files_verified=2272, cli_and_binding_identity_verified=True,
        source_changes_after_original_build=source['changes_after_original_build'],
        code_review=state, review_threads=0, served=served_reports, browsers=browsers,
        interpretation=runtime['interpretation'],
        preserved_capture_issues=[
            'The first Python core job failed to import the new test module by its package name; the final PR adds package/discovery-compatible imports and the corrected hosted job passes.',
            'The first preview capture retained four guide responses before an HTTP timeout; the unchanged source was later verified through bounded response retries.',
            'The native source-name verifier initially omitted an intervening allow attribute. Its corrected parser checks all nine passing test names; no engine test was rerun.',
            'Six production HTML responses contain Cloudflare-injected scripts. Each original source is exactly preserved around one bounded insertion; the JavaScript and search entry are byte-identical.',
            'Browser screenshots were inspected inline and are not retained as files; the packet preserves manual observations and independently captured HTTP bytes.'],
        source_version='0.6.0', publication_attempted=False, performance_claim=False, driver=identity(__file__))
    save(RAW / 'verification-492.json', report)
    files = {'hosted/' + str(p.relative_to(RAW)): p for p in RAW.rglob('*') if p.is_file()}
    helpers = [Path(__file__), Path(jobs.__file__), Path(sources.__file__), Path(sources.immutable.__file__),
               sources.FREEZER, sources.ARTIFACTS, OUT / 'accept_stream_sets_native_job_491.py',
               OUT / 'capture_stream_sets_served_489.py', OUT / 'capture_stream_sets_served_490.py',
               ROOT / 'scripts/local_uat_storage.py']
    for path in helpers:
        name = 'support/' + path.name
        assert name not in files
        files[name] = path
    files['support/accepted-source-protocol.json'] = sources.ACCEPTED
    destination.mkdir(exist_ok=False)
    archive = destination / 'native-stream-sets-hosted-2026-10-15.tar.xz'
    index = destination / 'native-stream-sets-hosted-2026-10-15.json'
    members = []
    with tarfile.open(archive, 'x:xz') as stream:
        for name, path in sorted(files.items()):
            before = identity(path)
            payload = path.read_bytes()
            info = tarfile.TarInfo(name)
            info.size = len(payload)
            info.mode = 0o644
            stream.addfile(info, io.BytesIO(payload))
            assert identity(path) == before
            members.append(dict(name=name, bytes=before['bytes'], sha256=before['sha256']))
    with tarfile.open(archive, 'r:xz') as stream:
        entries = stream.getmembers()
        assert len(entries) == len({r.name for r in entries}) == len(members)
        assert all(r.isfile() for r in entries) and {r.name for r in entries} == set(files)
        for member in members:
            payload = stream.extractfile(member['name']).read()
            assert len(payload) == member['bytes'] and digest(payload) == member['sha256']
            assert payload == files[member['name']].read_bytes()
    save(index, dict(schema_version='shardloom.native_stream_sets_hosted_packet.v1', status='passed',
        pr=1558, head=HEAD, merge=MERGE, synthetic=SYNTHETIC, checks_passed=44,
        native_test_groups=groups, native_total=2873, native_manual_exclusions=26,
        native_public_total=1076, wheel_lanes=3, wheel_tests_per_lane=87,
        core_discovered=606, core_run=519, core_skipped=11, source_files_verified=2272,
        served_responses_verified=16, production_deployment_check_complete=True,
        production_deployment_check_id=served_reports['production']['report']['deployment']['id'],
        production_version=served_reports['production']['deployment_version'],
        browser_scope='Preview and production guides/search/navigation inspected in the actual browser. Screenshots inspected inline, not archived; no cross-browser or responsive matrix claim.',
        archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=identity(archive)['sha256']),
        members_verified=len(members), members=members, publication_attempted=False, performance_claim=False))
    check_budgets(OUT, destination, OUT / 'logs', min_free_bytes=12*GIB,
                  reserve_bytes=0, max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
    for path in (archive, index):
        target = ROOT / 'docs/benchmarks/evidence' / path.name
        assert not target.exists()
        shutil.copy2(path, target)
        assert identity(path)['sha256'] == identity(target)['sha256']
    print(json.dumps(dict(status='passed', checks=44, wheel_lanes=3, sources=2272,
        served_responses=16, members=len(members), archive=identity(archive))))


if __name__ == '__main__':
    main()
