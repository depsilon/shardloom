"""Compile and exercise new public coverage before freezing broad acceptance."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PYTHON = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
BINDING_PYTHON = '/Users/dylan/LocalData/shardloom/native-python-surface-20261010/release-v0.6.0/local-package-release060-source-440/venv/bin/python'


def run(name, command, timeout=1800):
    print(json.dumps({'starting': name}), flush=True)
    subprocess.run([PYTHON, '-B', str(OUT / 'run_guarded.py'), '--name', name,
                    '--timeout', str(timeout), '--', *command], cwd=ROOT, check=True)


run('subquery-cli-preflight-build-741', ['cargo', 'build', '--release', '--offline', '--locked',
    '-p', 'shardloom-cli', '--features', 'release-user-surfaces'])
artifacts = OUT / 'preflight-artifacts'
artifacts.mkdir(exist_ok=False)
cli = artifacts / 'shardloom'
shutil.copy2('/Users/dylan/.cache/shardloom/cargo-target/release/shardloom', cli)
run('subquery-binding-preflight-build-741', [PYTHON, '-B', 'scripts/build_native_python.py',
    '--output-dir', str(artifacts), '--release', '--offline'])
with (OUT / 'preflight-build-identities-741.json').open('x') as stream:
    json.dump({str(path): hashlib.sha256(path.read_bytes()).hexdigest()
               for path in artifacts.iterdir() if path.is_file()}, stream, indent=2)
run('subquery-direct-binding-preflight-741', ['/usr/bin/env',
    'SHARDLOOM_NATIVE_TEST_LIBRARY=' + str(artifacts / '_native.abi3.so'),
    'SHARDLOOM_REQUIRE_NATIVE_PYTHON=1', BINDING_PYTHON, '-m', 'unittest', 'discover',
    '-s', 'python/tests', '-p', 'test_native_subquery_membership_binding.py', '-v'])
run('subquery-public-preflight-741', [PYTHON, '-B', 'scripts/run_native_streaming_input_uat.py',
    '--binary', str(cli), '--uat-root', str(OUT / 'public-preflight-741'),
    '--operation-timeout', '600', '--compress-logs', '--families',
    'subquery-membership', 'subqueries-pressure'], timeout=7200)
summary = json.loads((OUT / 'public-preflight-741/summary.json').read_text())
assert summary['status'] == 'passed' and all(case['status'] == 'passed' for case in summary['cases'])
print(json.dumps({'status': 'passed', 'public_cases': len(summary['cases'])}), flush=True)
