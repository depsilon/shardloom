"""Freeze clean sources, rebuild and run the declared acceptance serially."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PYTHON = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
BINDING_PYTHON = '/Users/dylan/LocalData/shardloom/native-python-surface-20261010/release-v0.6.0/local-package-release060-source-440/venv/bin/python'


def run(name, command, timeout=1800):
    print(json.dumps({'starting': name}), flush=True)
    subprocess.run([PYTHON, '-B', str(OUT / 'run_guarded.py'), '--name', name,
                    '--timeout', str(timeout), '--', *command], cwd=ROOT, check=True)


def verify(phase, receipt=None):
    command = [PYTHON, '-B', str(OUT / 'verify_subquery_acceptance.py'), phase]
    if receipt:
        command.extend(['--receipt', receipt])
    run('subquery-' + phase + '-verify-742', command)


assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True) == ''
run('subquery-source-freeze-742', [PYTHON, '-B', str(OUT / 'freeze_subquery_acceptance.py'), 'source'])
# Invalidate these packages' local compiler fingerprints without changing a
# source byte. The build freezer also requires fresh compiler log entries.
touched = []
for name in ('shardloom-vortex/src/lib.rs', 'shardloom-cli/src/lib.rs', 'shardloom-python/src/lib.rs'):
    path = ROOT / name
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    prior = path.stat().st_mtime_ns
    path.touch()
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
    touched.append(dict(path=str(path), sha256=digest, before_mtime_ns=prior,
                        after_mtime_ns=path.stat().st_mtime_ns))
with (OUT / 'build-freshness-trigger-742.json').open('x') as stream:
    json.dump(touched, stream, indent=2)
run('subquery-cli-build-742', ['cargo', 'build', '--release', '--offline', '--locked',
    '-p', 'shardloom-cli', '--features', 'release-user-surfaces'])
run('subquery-binding-build-742', [PYTHON, '-B', 'scripts/build_native_python.py',
    '--output-dir', str(OUT / 'artifacts'), '--release', '--offline'])
run('subquery-artifact-freeze-742', [PYTHON, '-B', str(OUT / 'freeze_subquery_acceptance.py'),
    'artifacts', '--cli-build', 'subquery-cli-build-742', '--binding-build', 'subquery-binding-build-742'])
run('subquery-plan-freeze-742', [PYTHON, '-B', str(OUT / 'freeze_subquery_acceptance.py'), 'plan'])
plan = json.loads((OUT / 'acceptance-plan.json').read_text())
build = json.loads((OUT / 'acceptance-build.json').read_text())
run('subquery-workspace-fmt-742', ['cargo', 'fmt', '--all', '--', '--check'])
run('subquery-public-reference-742', [PYTHON, '-B', 'scripts/check_user_surface_reference.py'])
run('subquery-sampling-reference-742', [PYTHON, '-B', 'scripts/generate_native_sampling_population_reference.py', '--check'])
run('subquery-public-reference-tests-742', [PYTHON, '-B', '-m', 'unittest', 'discover',
    '-s', 'python/tests', '-p', 'test_public_api_reference.py', '-v'])
binding_env = ['/usr/bin/env', 'SHARDLOOM_NATIVE_TEST_LIBRARY=' + build['native_library']['path'],
               'SHARDLOOM_REQUIRE_NATIVE_PYTHON=1', BINDING_PYTHON, '-m', 'unittest', 'discover',
               '-s', 'python/tests']
run('subquery-direct-binding-tests-742', [*binding_env, '-p', 'test_native*binding.py', '-v'])
run('subquery-public-context-tests-742', [*binding_env, '-p', 'test_public_context.py', '-v'])
run('subquery-native-clippy-742', ['cargo', 'clippy', '--release', '--offline', '--locked',
    '-p', 'shardloom-vortex', '-p', 'shardloom-cli', '--all-targets', '--features',
    'release-user-surfaces', '--', '-D', 'warnings'])
run('subquery-workspace-clippy-742', ['cargo', 'clippy', '--offline', '--locked',
    '--workspace', '--all-targets', '--', '-D', 'warnings'])
run('subquery-workspace-tests-742', ['cargo', 'test', '--offline', '--locked',
    '--workspace', '--all-targets', '--', '--test-threads=1'])
run('subquery-native-vortex-tests-742', ['cargo', 'test', '--release', '--offline', '--locked',
    '-p', 'shardloom-vortex', '--features', 'release-user-surfaces', '--lib', '--', '--test-threads=1'])
run('subquery-native-cli-tests-742', ['cargo', 'test', '--offline', '--locked',
    '-p', 'shardloom-cli', '--lib', '--bin', 'shardloom', '--test', 'vortex_prepare',
    '--test', 'public_memory_inputs', '--test', 'public_workflow_route', '--test',
    'resident_worker', '--features', 'release-user-surfaces', '--', '--test-threads=1'])
verify('input')
run('subquery-public-matrix-742', plan['commands']['public'], timeout=14400)
verify('public', 'subquery-public-matrix-742')
run('subquery-full43-742', plan['commands']['full43'], timeout=14400)
verify('full43', 'subquery-full43-742')
run('subquery-modular-742', plan['commands']['modular'], timeout=14400)
verify('modular', 'subquery-modular-742')
verify('final')
run('subquery-owner-acceptance-742', [PYTHON, '-B', str(OUT / 'finalize_subquery_acceptance.py')])
print(json.dumps({'status': 'passed', 'scope': 'finite_subquery_predicate_state'}), flush=True)
