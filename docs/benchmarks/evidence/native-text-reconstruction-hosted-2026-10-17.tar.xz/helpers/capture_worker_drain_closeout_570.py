"""Capture exact PR/check/review state for the native worker lifetime correction."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

from verify_worker_drain_integrated_sources_569 import HEAD, BASE, DEST


def identity(path):
    raw = Path(path).read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', choices=('premerge', 'postmerge'), required=True)
    parser.add_argument('--merged')
    parser.add_argument('--attempt', default='570')
    args = parser.parse_args()
    assert re.fullmatch(r'[a-z0-9-]+', args.attempt)
    assert (args.stage == 'postmerge') == bool(args.merged)
    if args.merged:
        assert re.fullmatch(r'[a-f0-9]{40}', args.merged)
    destination = DEST/(args.stage+'-'+args.attempt)
    destination.mkdir(exist_ok=False)
    records = []

    def api(name, arguments):
        completed = subprocess.run(['/opt/homebrew/bin/gh', 'api', *arguments],
            capture_output=True, timeout=60)
        assert completed.returncode == 0, completed.stderr.decode()
        assert len(completed.stdout) <= 8*1024*1024
        path = destination/(name+'.json')
        path.write_bytes(completed.stdout)
        records.append(identity(path))
        return json.loads(completed.stdout)

    pr = api('pull-request', ['repos/depsilon/shardloom/pulls/1564'])
    checks = api('checks', [f'repos/depsilon/shardloom/commits/{HEAD}/check-runs?per_page=100'])
    statuses = api('statuses', [f'repos/depsilon/shardloom/commits/{HEAD}/status?per_page=100'])
    comments = api('issue-comments', ['repos/depsilon/shardloom/issues/1564/comments?per_page=100'])
    query = '''query { repository(owner:"depsilon", name:"shardloom") {
      pullRequest(number:1564) { number headRefOid merged mergeCommit { oid }
        reviews(first:100) { pageInfo { hasNextPage } nodes { id state commit { oid } } }
        reviewThreads(first:100) { pageInfo { hasNextPage } nodes {
          id isResolved path comments(first:100) {
            pageInfo { hasNextPage } nodes { id databaseId body url }
          }
        } }
      } } }'''
    review = api('review-state', ['graphql', '-f', 'query='+query])
    alerts = api('open-pr-code-scanning-alerts',
        ['repos/depsilon/shardloom/code-scanning/alerts?ref=refs/pull/1564/merge&state=open&per_page=100'])
    assert pr['number'] == 1564 and pr['head']['sha'] == HEAD
    if args.stage == 'premerge':
        assert pr['state'] == 'open' and not pr['merged'] and not pr['draft']
        assert pr['base']['sha'] == BASE and pr['mergeable'] and pr['mergeable_state'] == 'clean'
    else:
        assert pr['merged'] and pr['merge_commit_sha'] == args.merged
    assert checks['total_count'] == len(checks['check_runs']) == 44
    assert len({row['id'] for row in checks['check_runs']}) == 44
    assert all(row['head_sha'] == HEAD and row['status'] == 'completed'
        and row['conclusion'] == 'success' for row in checks['check_runs'])
    assert statuses['sha'] == HEAD and statuses['total_count'] == 0 and statuses['statuses'] == []
    assert len(comments) < 100
    bot = [row for row in comments if row['user']['login'] == 'chatgpt-codex-connector[bot]']
    assert len(bot) == 1
    marker = re.search(r'<!-- codex-review-state:v1 (.*?) -->', bot[0]['body'])
    assert marker
    state = json.loads(marker.group(1))['code_review']
    assert state == dict(commit_sha=HEAD, has_any_findings=False,
        has_unresolved_findings=False, status='completed')
    assert not review.get('errors')
    reviewed = review['data']['repository']['pullRequest']
    assert reviewed['number'] == 1564 and reviewed['headRefOid'] == HEAD
    assert reviewed['merged'] == (args.stage == 'postmerge')
    if args.merged:
        assert reviewed['mergeCommit']['oid'] == args.merged
    for kind in ('reviews', 'reviewThreads'):
        assert reviewed[kind]['pageInfo']['hasNextPage'] is False
    assert all(row['state'] in ('COMMENTED', 'APPROVED', 'DISMISSED')
        for row in reviewed['reviews']['nodes'])
    threads = reviewed['reviewThreads']['nodes']
    assert threads == [] and alerts == []
    source = DEST/'pr-sources-569.json'
    source_record = json.loads(source.read_text())
    assert source_record['status'] == 'passed' and source_record['source_files'] == 2373
    assert source_record['revisions']['pr_head'] == HEAD
    report = dict(schema_version='shardloom.native_worker_drain_review_closeout.v1',
        status='passed', stage=args.stage, recorded_at=datetime.now(timezone.utc).isoformat(),
        head=HEAD, merge=args.merged, checks_passed=44, code_review=state,
        review_coverage=dict(automated_review_head=HEAD, final_head=HEAD,
            automated_review_covers_final_head=True),
        review_threads=0, unresolved_review_threads=0, open_pr_code_scanning_alerts=0,
        source_verification=identity(source), metadata=records, helper=identity(__file__))
    target = destination/'report.json'
    target.open('x').write(json.dumps(report, indent=2)+'\n')
    print(json.dumps(dict(status='passed', stage=args.stage, checks=44,
        review_threads=0, report=str(target))))


if __name__ == '__main__':
    main()
