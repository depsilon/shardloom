"""Bind the accepted worker lifetime correction to immutable PR/merge sources."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

import freeze_native_release_298 as freeze
import verify_stream_destination_integrated_sources_482 as immutable
from verify_stream_subquery_integrated_sources_513 import selector_check, identity

ROOT = Path('/Users/dylan/.codex/worktrees/native-relational-workflows/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
DEST = OUT/'native-worker-drain-hosted-569'
HEAD = '36f620a0e38cd13730cd769e8a7a45cad694c73c'
BASE = 'de408cb794640ac1756d3dfe25a2064e9cb95c64'
SYNTHETIC = 'fcc65224653cde938466a89cf9097322ab16828f'
TREE = 'fbe10a1f0232d5bd6ecd6bf405e90fda011ed9ae'


def read(path):
    return json.loads(Path(path).read_text())


def git(*args):
    return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--merged')
    args = parser.parse_args()
    freeze.ROOT = ROOT
    immutable.R = ROOT
    selector_check()
    integration_path = OUT/'native-worker-drain-integration-568/report.json'
    integration = read(integration_path)
    assert integration['status'] == 'passed_local'
    accepted = integration['source_sha256']
    assert len(accepted) == 2373 and freeze.sources() == accepted
    assert git('rev-parse','HEAD') == HEAD and not git('status','--porcelain')
    revisions = dict(pr_head=HEAD,ci_merge=SYNTHETIC)
    if args.merged:
        revisions['merged'] = args.merged
    trees = {key:git('rev-parse',rev+'^{tree}') for key,rev in revisions.items()}
    assert set(trees.values()) == {TREE}
    assert git('show','-s','--format=%P',SYNTHETIC).split() == [BASE,HEAD]
    mapping, records = immutable.immutable_source_map(HEAD)
    assert {p:r['sha256'] for p,r in mapping.items()} == accepted
    assert all(mode in ('100644','100755') for _,_,mode in records)
    packet_path = ROOT/'docs/benchmarks/evidence/native-worker-drain-2026-10-16.json'
    packet = read(packet_path)
    assert packet['status'] == 'passed_local' and packet['checks_passed'] == 7
    archive = packet_path.parent/packet['archive']['file']
    assert identity(archive)['sha256'] == packet['archive']['sha256']
    assert identity(packet_path) == integration['accepted_worker_packet']
    assert identity(archive) == integration['accepted_worker_archive']
    paths = git('diff','--name-only',BASE,HEAD).splitlines()
    assert len(paths) == 34
    changed_source = [p for p in paths if immutable.selected(p)]
    assert set(changed_source) == set(packet['source_sha256'])
    assert len(changed_source) == 4
    checks_path = OUT/'native-worker-drain-acceptance-566b.json'
    checks = read(checks_path)
    assert checks['source_sha256'] == packet['source_sha256'] and len(checks['checks']) == 7
    for check in checks['checks']:
        receipt = read(check['receipt'])
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup']
        assert identity(check['receipt'])['sha256'] == check['receipt_sha256']
        assert identity(check['log'])['sha256'] == check['log_sha256'] == receipt['log_sha256']
    DEST.mkdir(exist_ok=True)
    metadata_path = DEST/'synthetic-merge-569.json'
    if not metadata_path.exists():
        raw = subprocess.check_output(['/opt/homebrew/bin/gh','api',
            'repos/depsilon/shardloom/git/commits/'+SYNTHETIC],timeout=45)
        metadata_path.open('xb').write(raw)
    metadata = read(metadata_path)
    assert metadata['sha'] == SYNTHETIC and metadata['tree']['sha'] == TREE
    assert [p['sha'] for p in metadata['parents']] == [BASE,HEAD]
    report = dict(schema_version='shardloom.native_worker_drain_integrated_sources.v1',
        status='passed',revisions=revisions,trees=trees,source_files=len(mapping),
        selector_ast_matches=True,all_selected_sources_match=True,immutable_source=mapping,
        source_sha256=accepted,accepted_integration=identity(integration_path),
        accepted_packet=identity(packet_path),accepted_archive=identity(archive),
        accepted_checks=identity(checks_path),source_changes=changed_source,
        synthetic_metadata=identity(metadata_path),
        helpers=[identity(__file__),identity(immutable.__file__),
            identity(OUT/'verify_stream_subquery_integrated_sources_513.py'),identity(freeze.__file__)],
        scope='Source and seven completed local check identities only; hosted runtime, reviews, merge and deployment have separate receipts.')
    target = DEST/('merged-sources-569.json' if args.merged else 'pr-sources-569.json')
    target.open('x').write(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(status='passed',source_files=len(mapping),trees=trees,report=str(target))))


if __name__ == '__main__':
    main()
