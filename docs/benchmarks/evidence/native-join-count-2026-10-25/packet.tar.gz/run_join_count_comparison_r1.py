"""Run the frozen native join/count measure or observation comparison."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path('/Users/dylan/LocalData/shardloom/workflow-work-elimination-20261025')
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
TEST = ('local_primitives::prepared_relational::tests::'
        'join_count_cost_tests::native_join_count_cost_screen')
HARNESS = 'shardloom-vortex/src/local_primitive_relational_join_count_cost_tests.rs'
CASES = (
    'duplicate_numeric', 'composite_text', 'skew', 'unique_match',
    'unique_no_match', 'tiny', 'ineligible_count_column',
)
GIB = 1 << 30
MIB = 1 << 20
MAX_WORKSPACE = 100 * GIB
ACTIVE_PACKET = 192 * MIB
PROTOCOL_DOCUMENT = W / 'docs/architecture/native-join-count-work-elimination-2026-10-25.md'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def tree_bytes(path):
    return sum(p.stat().st_size for p in path.rglob('*')
               if p.is_file() and not p.is_symlink()) if path.exists() else 0


def current_source_inventory(manifest):
    inventory = manifest['source_inventory']
    assert isinstance(inventory, dict) and inventory
    actual = {}
    for relative, expected in sorted(inventory.items()):
        path = W / relative
        assert path.is_file() and not path.is_symlink(), relative
        value = digest(path)
        assert value == expected, relative
        actual[relative] = value
    return actual


def schedule(mode):
    if mode == 'observe':
        return [(case, role, 0, 0) for case in CASES
                for role in ('baseline', 'candidate')]
    result = []
    for cohort in (1, 2):
        for case in CASES:
            for sample in (1, 2, 3):
                baseline_first = (sample != 2) if cohort == 1 else (sample == 2)
                roles = ('baseline', 'candidate') if baseline_first else ('candidate', 'baseline')
                result.extend((case, role, cohort, sample) for role in roles)
    return result


def main():
    if len(sys.argv) != 5 or sys.argv[4] not in ('measure', 'observe'):
        raise SystemExit('usage: run_join_count_comparison_r1.py BASELINE.json CANDIDATE.json NEW_RESULT_DIR measure|observe')
    baseline_path, candidate_path, result_path = map(Path, sys.argv[1:4])
    mode = sys.argv[4]
    assert result_path.is_absolute() and result_path.parent == OUT
    assert result_path != OUT
    result_path.mkdir()
    (result_path / 'witnesses').mkdir()
    lock_path = OUT / '.join-count-comparison.lock'
    lock_fd = os.open(lock_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    lock_stat = os.fstat(lock_fd)
    os.write(lock_fd, str(os.getpid()).encode())
    os.close(lock_fd)
    lock_identity = (lock_stat.st_dev, lock_stat.st_ino)
    packet = {'protocol': 'native-join-count-v1', 'mode': mode,
              'driver_sha256': digest(__file__), 'complete': False, 'calls': []}
    try:
        manifests = {'baseline': json.loads(baseline_path.read_text()),
                     'candidate': json.loads(candidate_path.read_text())}
        expected_profile = 'release' if mode == 'measure' else 'ci-native'
        for role, manifest in manifests.items():
            assert digest(manifest['binary']) == manifest['binary_sha256'], role
            assert manifest['profile'] == expected_profile, role
            assert manifest['features'] == ['release-user-surfaces'], role
            assert manifest['harnesses'] == {HARNESS: digest(W / HARNESS)}, role
            assert isinstance(manifest['toolchain'], str) and manifest['toolchain']
            assert isinstance(manifest['revision'], str) and manifest['revision']
            assert isinstance(manifest['source_inventory'], dict)
            for source_path, source_hash in manifest['source_inventory'].items():
                assert isinstance(source_path, str) and source_path
                assert isinstance(source_hash, str) and len(source_hash) == 64
        assert manifests['baseline']['harnesses'] == manifests['candidate']['harnesses']
        assert manifests['baseline']['toolchain'] == manifests['candidate']['toolchain']
        assert manifests['baseline']['features'] == manifests['candidate']['features']
        helper_path = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
        guard_path = Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py')
        supervisor = module('bounded_join_count', helper_path)
        guard_module = module('join_count_workload_guard', guard_path)
        source_before = current_source_inventory(manifests['candidate'])
        storage_before = {'cache_bytes': tree_bytes(CACHE), 'task_bytes': tree_bytes(OUT)}
        assert sum(storage_before.values()) <= MAX_WORKSPACE
        assert shutil.disk_usage(OUT).free >= 12 * GIB
        planned = schedule(mode)
        expected_count = 84 if mode == 'measure' else 14
        assert len(planned) == expected_count
        packet.update(runtime_manifests=manifests, helpers={
            str(p): digest(p) for p in (helper_path, guard_path)},
            source_inventory_before=source_before, storage_before=storage_before,
            binary_sha256_before={role: digest(manifest['binary'])
                                  for role, manifest in manifests.items()},
            schedule=[list(row) for row in planned], active_packet_limit_bytes=ACTIVE_PACKET)
        protocol_bytes = PROTOCOL_DOCUMENT.read_bytes()
        packet['frozen_protocol'] = {
            'source': str(PROTOCOL_DOCUMENT.relative_to(W)),
            'text': protocol_bytes.decode('utf-8'),
            'sha256': hashlib.sha256(protocol_bytes).hexdigest(),
        }
        packet['scorer_sha256'] = digest(OUT / 'score_join_count_comparison_r1.py')
        write_new(result_path / 'protocol.json', packet)

        for index, (case, role, cohort, sample) in enumerate(planned):
            label = f'{mode}-{case}-{role}-{cohort}-{sample}'
            record_path = result_path / f'{label}.json'
            log_path = result_path / f'{label}.log'
            assert not record_path.exists() and not log_path.exists()
            evidence = {'mode': mode, 'case': case, 'role': role,
                        'cohort': cohort, 'sample': sample,
                        'sequence': index + 1, 'status': 'running'}
            packet['calls'].append(evidence)
            work = guard_module.WorkloadGuard()
            env = dict(os.environ,
                SHARDLOOM_JOIN_COUNT_ROOT=str(result_path),
                SHARDLOOM_JOIN_COUNT_CASE=case,
                SHARDLOOM_JOIN_COUNT_ROLE=role,
                SHARDLOOM_JOIN_COUNT_COHORT=str(cohort),
                SHARDLOOM_JOIN_COUNT_SAMPLE=str(sample))
            command = [manifests[role]['binary'], TEST, '--exact', '--ignored',
                       '--nocapture', '--test-threads=1']
            evidence['command'] = command
            fixed_bytes = sum(p.stat().st_size for p in result_path.iterdir()
                              if p.is_file() and not p.is_symlink())

            def guard():
                work.check(evidence.get('pid'))
                assert shutil.disk_usage(OUT).free >= 12 * GIB
                active = sum(p.stat().st_size for p in (log_path, record_path) if p.exists())
                witness_bytes = sum(p.stat().st_size for p in
                                    (result_path / 'witnesses').iterdir()
                                    if p.is_file() and not p.is_symlink())
                assert fixed_bytes + active + witness_bytes <= ACTIVE_PACKET

            try:
                with log_path.open('xb') as output:
                    status = supervisor.run(command, cwd=W, env=env, output=output,
                        timeout=120, evidence=evidence, guard=guard,
                        max_output_bytes=8 * MIB)
                assert status == 0, label
                assert evidence.get('direct_child_reaped') and evidence.get('process_group_drained'), label
                assert record_path.is_file(), label
                record = json.loads(record_path.read_text())
                assert record['protocol'] == 'native-join-count-v1'
                assert (record['case'], record['role'], record['cohort'], record['sample']) == (case, role, cohort, sample)
                assert record['observation_enabled'] is (mode == 'observe')
                assert record['complete_values_match'] and record['complete_schema_match']
                assert record['expected_rows_witness'] == record['actual_rows_witness']
                assert record['reserved_after_cleanup'] == 0 and record['denied_reservations'] == 0
                assert record['memory_grant_bytes'] == 128 * MIB
                if mode == 'measure':
                    assert record['observations'] is None
                    for key in ('engine_execution_ns', 'preparation_ns'):
                        assert isinstance(record[key], int) and record[key] >= 0
                else:
                    assert isinstance(record['observations'], dict)
                for key in ('input_witnesses', 'expected_rows_witness',
                            'actual_rows_witness', 'schema_witness'):
                    values = record[key] if key == 'input_witnesses' else [record[key]]
                    for identity in values:
                        witness_path = result_path / 'witnesses' / f'{identity}.json'
                        assert len(identity) == 64 and digest(witness_path) == identity
                evidence['record_sha256'] = digest(record_path)
                evidence['returncode'] = status
                evidence['status'] = 'passed'
            except BaseException as error:
                evidence['status'] = 'failed'
                evidence['failure'] = type(error).__name__ + ': ' + str(error)
                raise
            finally:
                evidence['log_sha256'] = digest(log_path) if log_path.exists() else None
                evidence_path = result_path / f'supervision-{label}.json'
                write_new(evidence_path, evidence)
                # Progress intentionally excludes all clocks and resource values.
                print(json.dumps({'case': case, 'role': role,
                                  'status': evidence['status']}), flush=True)

        source_after = current_source_inventory(manifests['candidate'])
        assert source_before == source_after
        binary_after = {}
        for role, manifest in manifests.items():
            assert digest(manifest['binary']) == manifest['binary_sha256'], role
            binary_after[role] = digest(manifest['binary'])
        storage_after = {'cache_bytes': tree_bytes(CACHE), 'task_bytes': tree_bytes(OUT)}
        assert sum(storage_after.values()) <= MAX_WORKSPACE
        packet.update(source_inventory_after=source_after,
                      binary_sha256_after=binary_after, storage_after=storage_after,
                      complete=True)
    finally:
        packet['complete'] = bool(packet.get('complete'))
        outcome_path = result_path / 'outcome.json'
        if not outcome_path.exists():
            write_new(outcome_path, packet)
        current_lock = lock_path.stat()
        assert (current_lock.st_dev, current_lock.st_ino) == lock_identity
        lock_path.unlink()


if __name__ == '__main__':
    main()
