"""Freeze the exact candidate test executable and reconstructible source identity."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
P = Path(__file__).resolve().parent
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
HARNESS = 'shardloom-vortex/src/local_primitive_relational_join_count_cost_tests.rs'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    assert len(sys.argv) == 3
    profile, receipt_name = sys.argv[1:]
    assert profile in ('release', 'ci-native')
    receipt_path = P / receipt_name
    assert receipt_path.parent == P and receipt_path.is_file()
    receipt = json.loads(receipt_path.read_text())
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert not receipt['timed_out'] and receipt['interrupted_signal'] is None
    assert digest(receipt_path.with_suffix('.log')) == receipt['log_sha256']
    command = receipt['command']
    assert command[:4] == ['cargo', 'test', '--offline', '--locked']
    assert command[command.index('--features') + 1] == 'release-user-surfaces'
    assert command[command.index('-p') + 1] == 'shardloom-vortex'
    assert '--lib' in command
    if profile == 'release':
        assert '--release' in command and '--no-run' in command
    else:
        assert command[command.index('--profile') + 1] == 'ci-native'
    revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
    assert revision == receipt['head']
    baseline = json.loads((P / 'baseline-runtime' / 'release-manifest.json').read_text())
    assert revision == baseline['revision']
    names = subprocess.check_output(
        ['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=W
    ).decode().split('\0')
    sources = sorted({name for name in names if name and
                      (name.endswith('.rs') or Path(name).name in ('Cargo.toml', 'Cargo.lock'))})
    inventory = {name: digest(W / name) for name in sources}
    assert set(baseline['source_inventory']) <= set(inventory)
    assert inventory[HARNESS] == baseline['harnesses'][HARNESS]
    # Every compiled change must be the one captured before this build/test.
    changed_names = set()
    for argv in (['git', 'diff', '--name-only', '-z', 'HEAD'],
                 ['git', 'ls-files', '--others', '--exclude-standard', '-z']):
        changed_names.update(subprocess.check_output(argv, cwd=W).decode().split('\0'))
    changed = {name: identity for name, identity in inventory.items() if name in changed_names}
    for name, identity in changed.items():
        assert receipt['changed_source_inventory'][name]['sha256'] == identity, name
    toolchain = subprocess.check_output([
        '/Users/dylan/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin/rustc', '-Vv'
    ], text=True)
    assert toolchain == baseline['toolchain']
    executable_name = ('shardloom_vortex-9fdcfb051cec6fea' if profile == 'release'
                       else 'shardloom_vortex-03f2a038481284e4')
    source_binary = CACHE / profile / 'deps' / executable_name
    assert source_binary.is_file() and not source_binary.is_symlink()
    assert os.access(source_binary, os.X_OK)
    assert shutil.disk_usage(P).free >= 12 * (1 << 30)
    output = P / 'candidate-runtime-r1'
    output.mkdir(exist_ok=True)
    label = 'release' if profile == 'release' else 'observe'
    destination = output / f'shardloom-join-count-{label}'
    assert not destination.exists()
    shutil.copy2(source_binary, destination)
    assert digest(destination) == digest(source_binary)
    overlay = output / f'{label}-source-overlay.tar.gz'
    with tarfile.open(overlay, 'x:gz') as archive:
        for name in sorted(changed):
            archive.add(W / name, arcname=name, recursive=False)
    with tarfile.open(overlay, 'r:gz') as archive:
        assert sorted(archive.getnames()) == sorted(changed)
        for member in archive.getmembers():
            assert member.isfile()
            assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == changed[member.name]
    manifest = {
        'binary': str(destination), 'binary_sha256': digest(destination),
        'profile': profile, 'features': ['release-user-surfaces'],
        'toolchain': toolchain, 'revision': revision,
        'harnesses': {HARNESS: inventory[HARNESS]}, 'source_inventory': inventory,
        'build_receipt': {'path': str(receipt_path), 'sha256': digest(receipt_path)},
        'source_overlay': {'path': str(overlay), 'sha256': digest(overlay), 'members': changed},
    }
    manifest_path = output / f'{label}-manifest.json'
    with manifest_path.open('x') as stream:
        json.dump(manifest, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'manifest': str(manifest_path), 'binary_sha256': manifest['binary_sha256'],
                      'source_files': len(inventory), 'overlay_files': len(changed)}))


if __name__ == '__main__':
    main()
