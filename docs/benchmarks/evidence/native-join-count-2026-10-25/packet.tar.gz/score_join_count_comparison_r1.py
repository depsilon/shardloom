"""Independently verify and score a complete native join/count measure run."""
import hashlib
import json
from pathlib import Path
import statistics
import sys
from collections import Counter

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path('/Users/dylan/LocalData/shardloom/workflow-work-elimination-20261025')
HARNESS = 'shardloom-vortex/src/local_primitive_relational_join_count_cost_tests.rs'
CASES = (
    'duplicate_numeric', 'composite_text', 'skew', 'unique_match',
    'unique_no_match', 'tiny', 'ineligible_count_column',
)
ROWS = {
    'duplicate_numeric': (8192, 16384),
    'composite_text': (4096, 8192),
    'skew': (1024, 2048),
    'unique_match': (32768, 32768),
    'unique_no_match': (32768, 32768),
    'tiny': (17, 23),
    'ineligible_count_column': (8192, 8192),
}
TARGETS = ('duplicate_numeric', 'composite_text', 'skew')
EXPECTED_SCHEMA = {'Struct': [{'names': ['rows'], 'dtypes': [{'Primitive': ['u64', False]}]}, False]}
MIB = 1 << 20
GIB = 1 << 30


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def expected_schedule():
    result = []
    for cohort in (1, 2):
        for case in CASES:
            for sample in (1, 2, 3):
                baseline_first = (sample != 2) if cohort == 1 else (sample == 2)
                roles = ('baseline', 'candidate') if baseline_first else ('candidate', 'baseline')
                result.extend((case, role, cohort, sample) for role in roles)
    return result


def write_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    if len(sys.argv) != 2:
        raise SystemExit('usage: score_join_count_comparison_r1.py COMPLETED_MEASURE_DIR')
    root = Path(sys.argv[1])
    assert root.is_absolute() and root.parent == OUT and root.is_dir()
    outcome_path = root / 'outcome.json'
    protocol_path = root / 'protocol.json'
    outcome = json.loads(outcome_path.read_text())
    protocol = json.loads(protocol_path.read_text())
    assert outcome['complete'] and outcome['protocol'] == protocol['protocol'] == 'native-join-count-v1'
    assert protocol['mode'] == outcome['mode'] == 'measure'
    assert outcome['schedule'] == [list(row) for row in expected_schedule()]
    assert len(outcome['calls']) == 84
    assert protocol['schedule'] == outcome['schedule']
    assert outcome['source_inventory_before'] == outcome['source_inventory_after']
    manifests = outcome['runtime_manifests']
    assert protocol['runtime_manifests'] == manifests
    assert protocol['source_inventory_before'] == outcome['source_inventory_before']
    assert set(manifests) == {'baseline', 'candidate'}
    for role, manifest in manifests.items():
        assert digest(manifest['binary']) == manifest['binary_sha256'], role
        assert manifest['profile'] == 'release'
        assert manifest['features'] == ['release-user-surfaces']
        assert manifest['harnesses'] == {HARNESS: digest(W / HARNESS)}
        assert isinstance(manifest['source_inventory'], dict)
        for relative, expected in manifest['source_inventory'].items():
            assert isinstance(relative, str) and relative
            assert isinstance(expected, str) and len(expected) == 64
    baseline = manifests['baseline']
    candidate = manifests['candidate']
    assert baseline['harnesses'] == candidate['harnesses']
    assert baseline['toolchain'] == candidate['toolchain']
    assert baseline['features'] == candidate['features']
    candidate_source = {}
    for relative, expected in sorted(candidate['source_inventory'].items()):
        path = W / relative
        assert path.is_file() and not path.is_symlink(), relative
        actual = digest(path)
        assert actual == expected, relative
        candidate_source[relative] = actual
    assert candidate_source == outcome['source_inventory_before']
    assert outcome['binary_sha256_before'] == {
        role: manifest['binary_sha256'] for role, manifest in manifests.items()}
    assert outcome['binary_sha256_after'] == outcome['binary_sha256_before']
    helper_paths = [Path(path) for path in outcome['helpers']]
    assert len(helper_paths) == 2
    assert protocol['helpers'] == outcome['helpers']
    for path in helper_paths:
        assert digest(path) == outcome['helpers'][str(path)]
    assert protocol['driver_sha256'] == outcome['driver_sha256']
    assert protocol['driver_sha256'] == digest(OUT / 'run_join_count_comparison_r1.py')
    assert protocol['scorer_sha256'] == outcome['scorer_sha256'] == digest(__file__)
    assert protocol['frozen_protocol'] == outcome['frozen_protocol']
    frozen = outcome['frozen_protocol']
    assert hashlib.sha256(frozen['text'].encode('utf-8')).hexdigest() == frozen['sha256']
    assert protocol['active_packet_limit_bytes'] == 192 * MIB
    assert sum(outcome['storage_before'].values()) <= 100 * GIB
    assert sum(outcome['storage_after'].values()) <= 100 * GIB

    records = {}
    witness_members = {}
    expected_names = {'protocol.json', 'outcome.json', 'witnesses'}
    schedule = expected_schedule()
    for index, (call, expected_call) in enumerate(zip(outcome['calls'], schedule), 1):
        case, role, cohort, sample = expected_call
        assert (call['case'], call['role'], call['cohort'], call['sample']) == expected_call
        assert call['mode'] == 'measure' and call['sequence'] == index
        assert call['status'] == 'passed' and call['returncode'] == 0
        assert call['direct_child_reaped'] and call['process_group_drained']
        label = f'measure-{case}-{role}-{cohort}-{sample}'
        record_path = root / f'{label}.json'
        log_path = root / f'{label}.log'
        supervision_path = root / f'supervision-{label}.json'
        expected_names.update((record_path.name, log_path.name, supervision_path.name))
        assert record_path.is_file() and log_path.is_file() and supervision_path.is_file()
        assert digest(record_path) == call['record_sha256']
        assert digest(log_path) == call['log_sha256']
        receipt = json.loads(supervision_path.read_text())
        assert receipt == call, label
        for field in ('mode', 'case', 'role', 'cohort', 'sample', 'sequence',
                      'status', 'returncode', 'record_sha256', 'log_sha256',
                      'direct_child_reaped', 'process_group_drained'):
            assert receipt[field] == call[field], (label, field)
        assert receipt['status'] == 'passed'
        expected_command = [manifests[role]['binary'],
            'local_primitives::prepared_relational::tests::join_count_cost_tests::native_join_count_cost_screen',
            '--exact', '--ignored', '--nocapture', '--test-threads=1']
        assert call['command'] == expected_command
        assert call['timeout_seconds'] == 120 and call['output_limit_bytes'] == 8 * MIB
        assert call['timed_out'] is False and call['interrupted_signal'] is None
        assert not call.get('error') and not call.get('cleanup_error')
        record = json.loads(record_path.read_text())
        assert record['protocol'] == 'native-join-count-v1'
        assert (record['case'], record['role'], record['cohort'], record['sample']) == expected_call
        assert record['observation_enabled'] is False and record['observations'] is None
        assert record['complete_values_match'] is True and record['complete_schema_match'] is True
        assert record['expected_rows_witness'] == record['actual_rows_witness']
        assert record['reserved_after_cleanup'] == 0 and record['denied_reservations'] == 0
        assert record['memory_grant_bytes'] == 128 * MIB
        assert 0 <= record['peak_reserved_bytes'] <= record['memory_grant_bytes']
        assert record['left_rows'] > 0 and record['right_rows'] > 0
        assert (record['left_rows'], record['right_rows']) == ROWS[case]
        for field in ('engine_execution_ns', 'preparation_ns', 'result_serialization_ns'):
            assert type(record[field]) is int and record[field] >= 0
        for field in ('input_witnesses',):
            assert len(record[field]) == 2
        for field in ('input_witnesses', 'expected_rows_witness',
                      'actual_rows_witness', 'schema_witness'):
            identities = record[field] if field == 'input_witnesses' else [record[field]]
            for identity in identities:
                assert isinstance(identity, str) and len(identity) == 64
                path = root / 'witnesses' / f'{identity}.json'
                assert path.is_file() and digest(path) == identity
                witness_members[path.name] = identity
        expected_values = json.loads((root / 'witnesses' /
            f"{record['expected_rows_witness']}.json").read_text())
        actual_values = json.loads((root / 'witnesses' /
            f"{record['actual_rows_witness']}.json").read_text())
        assert expected_values == actual_values
        assert isinstance(expected_values, list) and len(expected_values) == 1
        assert set(expected_values[0]) == {'rows'} and isinstance(expected_values[0]['rows'], int)
        assert 0 <= expected_values[0]['rows'] <= (1 << 64) - 1
        records[(case, role, cohort, sample)] = record

    # Each frozen case must carry identical inputs and schema in all 12 runs.
    for case in CASES:
        cell_records = [records[(case, role, cohort, sample)]
                        for cohort in (1, 2) for sample in (1, 2, 3)
                        for role in ('baseline', 'candidate')]
        reference = cell_records[0]
        for record in cell_records[1:]:
            assert record['input_witnesses'] == reference['input_witnesses'], case
            assert record['schema_witness'] == reference['schema_witness'], case
            assert (record['left_rows'], record['right_rows']) == (reference['left_rows'], reference['right_rows'])
        assert len({record['expected_rows_witness'] for record in cell_records}) == 1
        # Recompute the complete answer from the retained literal source values,
        # independently of both native strategies and the Rust harness oracle.
        inputs = [json.loads((root / 'witnesses' / f'{identity}.json').read_text())
                  for identity in reference['input_witnesses']]
        def keys(data, expected_rows, side):
            assert set(data) == {'n', 's', 'id'}
            assert len(data['n']) == len(data['id']) == expected_rows
            assert data['id'] == list(range(expected_rows))
            assert all(type(value) is int for value in data['n'])
            assert len(data['s']) == (expected_rows if case == 'composite_text' else 0)
            numbers = []
            for row in range(expected_rows):
                if case == 'duplicate_numeric': value = row % 64
                elif case == 'composite_text': value = row % 32
                elif case == 'skew': value = 0 if row % 10 != 9 else row + 1
                elif case == 'tiny': value = row % 7
                elif case == 'unique_no_match' and side == 1: value = row + expected_rows
                else: value = row
                numbers.append(value)
            assert data['n'] == numbers, (case, side)
            if case == 'composite_text':
                assert data['s'] == [f'clé-東京-{value}' for value in numbers]
            return [(value, data['s'][row] if data['s'] else None)
                    for row, value in enumerate(data['n'])]
        left_keys, right_keys = [keys(data, rows, side)
                                for side, (data, rows) in enumerate(zip(inputs, ROWS[case]))]
        right_counts = Counter(right_keys)
        independently_expected = sum(right_counts[key] for key in left_keys)
        expected_values = json.loads((root / 'witnesses' /
            f"{reference['expected_rows_witness']}.json").read_text())
        assert expected_values == [{'rows': independently_expected}], case
        schema = json.loads((root / 'witnesses' /
            f"{reference['schema_witness']}.json").read_text())
        assert schema == EXPECTED_SCHEMA, case

    actual_names = {path.name for path in root.iterdir()}
    assert actual_names == expected_names
    assert {path.name for path in (root / 'witnesses').iterdir()} == set(witness_members)

    case_results = []
    timing_gates = []
    for cohort in (1, 2):
        for case in CASES:
            by_role = {
                role: [records[(case, role, cohort, sample)] for sample in (1, 2, 3)]
                for role in ('baseline', 'candidate')
            }
            engine = {role: [item['engine_execution_ns'] for item in items]
                      for role, items in by_role.items()}
            complete = {role: [item['preparation_ns'] + item['engine_execution_ns']
                               for item in items] for role, items in by_role.items()}
            medians = {role: statistics.median(engine[role]) for role in engine}
            complete_medians = {role: statistics.median(complete[role]) for role in complete}
            allowance = 50_000 if case == 'tiny' else 0
            engine_limit = max(medians['baseline'] * 1.05,
                               medians['baseline'] + allowance)
            complete_limit = max(complete_medians['baseline'] * 1.05,
                                 complete_medians['baseline'] + allowance)
            engine_pass = (medians['candidate'] * 100 <= medians['baseline'] * 105 or
                           (case == 'tiny' and medians['candidate'] <= medians['baseline'] + allowance))
            complete_pass = (complete_medians['candidate'] * 100 <= complete_medians['baseline'] * 105 or
                             (case == 'tiny' and complete_medians['candidate'] <= complete_medians['baseline'] + allowance))
            target_pass = (case not in TARGETS or
                           medians['candidate'] * 100 <= medians['baseline'] * 98)
            timing_gates.append(engine_pass and complete_pass and target_pass)
            case_results.append({
                'case': case, 'cohort': cohort,
                'engine_execution_ns': engine,
                'engine_medians_ns': medians,
                'engine_candidate_over_baseline': (medians['candidate'] / medians['baseline']
                    if medians['baseline'] else None),
                'preparation_plus_engine_ns': complete,
                'preparation_plus_engine_medians_ns': complete_medians,
                'preparation_plus_engine_candidate_over_baseline': (
                    complete_medians['candidate'] / complete_medians['baseline']
                    if complete_medians['baseline'] else None),
                'engine_limit_ns': engine_limit,
                'preparation_plus_engine_limit_ns': complete_limit,
                'engine_gate_passed': engine_pass,
                'preparation_plus_engine_gate_passed': complete_pass,
                'target_two_percent_gate_passed': target_pass,
                'timing_gate_passed': engine_pass and complete_pass and target_pass,
            })
    target_gates = []
    for cohort in (1, 2):
        for case in TARGETS:
            row = next(item for item in case_results
                       if item['case'] == case and item['cohort'] == cohort)
            target_gates.append(row['target_two_percent_gate_passed'])
    timing_pass = all(timing_gates) and all(target_gates)
    decision = {
        'protocol': 'native-join-count-v1',
        'mode': 'measure',
        'source_revision': candidate['revision'],
        'baseline_revision': baseline['revision'],
        'driver_sha256': outcome['driver_sha256'],
        'scorer_sha256': digest(__file__),
        'outcome_sha256': digest(outcome_path),
        'protocol_sha256': digest(protocol_path),
        'record_sha256': {call['case'] + '-' + call['role'] + '-' +
                          str(call['cohort']) + '-' + str(call['sample']): call['record_sha256']
                          for call in outcome['calls']},
        'witness_sha256': witness_members,
        'calls': 84,
        'cohorts': [1, 2],
        'samples_per_case_role_cohort': 3,
        'cases': case_results,
        'all_targets_passed_in_both_cohorts': all(target_gates),
        'all_case_engine_and_complete_workload_gates_passed': all(timing_gates),
        'timing_gate_passed': timing_pass,
        'retention_basis': 'timing_gate_passed',
    }
    decision_path = root / 'decision.json'
    write_new(decision_path, decision)
    # Keep stdout limited to engine-clock values and their timing decisions.
    print(json.dumps({
        'timing_gate_passed': timing_pass,
        'target_engine_medians_ns': [
            {'case': row['case'], 'cohort': row['cohort'],
             'baseline': row['engine_medians_ns']['baseline'],
             'candidate': row['engine_medians_ns']['candidate'],
             'passed': row['target_two_percent_gate_passed']}
            for row in case_results if row['case'] in TARGETS],
    }))


if __name__ == '__main__':
    main()
