"""Synthetic boundary/corruption tests; this script executes no query engine."""
from collections import Counter
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parent


def load(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


driver = load('run_join_count_comparison_r1')
scorer = load('score_join_count_comparison_r1')
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    with path.open('x') as output:
        json.dump(value, output, ensure_ascii=False)


def make_inputs(case, rows, side):
    numbers = list(range(rows))
    if case == 'duplicate_numeric': numbers = [value % 64 for value in numbers]
    elif case == 'composite_text': numbers = [value % 32 for value in numbers]
    elif case == 'skew': numbers = [value + 1 if value % 10 == 9 else 0 for value in numbers]
    elif case == 'tiny': numbers = [value % 7 for value in numbers]
    elif case == 'unique_no_match' and side: numbers = [value + rows for value in numbers]
    return {'n': numbers, 's': [f'clé-東京-{value}' for value in numbers] if case == 'composite_text' else [], 'id': list(range(rows))}


def fixture(root, label, binary):
    root.mkdir()
    witnesses = root / 'witnesses'
    witnesses.mkdir()
    def witness(value):
        data = json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()
        digest = hashlib.sha256(data).hexdigest()
        path = witnesses / f'{digest}.json'
        if path.exists(): assert path.read_bytes() == data
        else: path.write_bytes(data)
        return digest
    source = {driver.HARNESS: sha(driver.W / driver.HARNESS)}
    manifest = {'binary': str(binary), 'binary_sha256': sha(binary), 'profile': 'release',
                'features': ['release-user-surfaces'], 'toolchain': 'synthetic', 'revision': 'synthetic',
                'harnesses': source, 'source_inventory': source}
    helpers = [Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py'),
               Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py')]
    text = driver.PROTOCOL_DOCUMENT.read_text()
    packet = {'synthetic_validation': True, 'protocol': 'native-join-count-v1', 'mode': 'measure',
              'complete': False, 'runtime_manifests': {'baseline': manifest, 'candidate': manifest},
              'schedule': [list(value) for value in driver.schedule('measure')], 'calls': [],
              'source_inventory_before': source, 'source_inventory_after': source,
              'binary_sha256_before': {role: sha(binary) for role in ('baseline', 'candidate')},
              'binary_sha256_after': {role: sha(binary) for role in ('baseline', 'candidate')},
              'helpers': {str(path): sha(path) for path in helpers},
              'driver_sha256': sha(Path(driver.__file__)), 'scorer_sha256': sha(Path(scorer.__file__)),
              'frozen_protocol': {'text': text, 'sha256': hashlib.sha256(text.encode()).hexdigest()},
              'active_packet_limit_bytes': 192 << 20, 'storage_before': {'synthetic': 0}, 'storage_after': {'synthetic': 0}}
    write(root / 'protocol.json', packet)
    for index, (case, role, cohort, sample) in enumerate(driver.schedule('measure'), 1):
        data = [make_inputs(case, rows, side) for side, rows in enumerate(scorer.ROWS[case])]
        if label == 'wrong_inputs' and case == 'tiny': data[0]['n'][0] = 100
        keys = [[(number, values['s'][row] if values['s'] else None)
                 for row, number in enumerate(values['n'])] for values in data]
        counts = Counter(keys[1])
        expected = sum(counts[key] for key in keys[0]) + int(label == 'wrong_values')
        schema = scorer.EXPECTED_SCHEMA if label != 'wrong_schema' else {'Struct': [{'names': ['rows'], 'dtypes': [{'Primitive': ['u32', False]}]}, False]}
        engine = 9_800_000 if role == 'candidate' and case in scorer.TARGETS else 10_000_000
        preparation = 10_000_000
        if role == 'candidate' and cohort == 2:
            if label == 'target_second_cohort_fail' and case == 'skew': engine = 9_800_001
            if label == 'engine_control_fail' and case == 'unique_no_match': engine = 10_500_001
            if label == 'setup_control_fail' and case == 'unique_match': preparation = 11_000_001
        if label.startswith('tiny_allowance') and case == 'tiny':
            preparation = 1000
            engine = 1000 if role == 'baseline' else (51_000 if label.endswith('pass') else 51_001)
        name = f'measure-{case}-{role}-{cohort}-{sample}'
        expected_hash = witness([{'rows': expected}])
        record = {'synthetic_validation': True, 'protocol': packet['protocol'], 'case': case, 'role': role,
                  'cohort': cohort, 'sample': sample, 'observation_enabled': False, 'observations': None,
                  'complete_values_match': True, 'complete_schema_match': True,
                  'input_witnesses': [witness(value) for value in data],
                  'expected_rows_witness': expected_hash, 'actual_rows_witness': expected_hash,
                  'schema_witness': witness(schema), 'reserved_after_cleanup': 0, 'denied_reservations': 0,
                  'memory_grant_bytes': 128 << 20, 'peak_reserved_bytes': 1000,
                  'left_rows': scorer.ROWS[case][0], 'right_rows': scorer.ROWS[case][1],
                  'engine_execution_ns': engine, 'preparation_ns': preparation, 'result_serialization_ns': 1}
        write(root / f'{name}.json', record)
        (root / f'{name}.log').write_text('Synthetic scorer fixture; no engine was executed.\n')
        call = {'synthetic_validation': True, 'mode': 'measure', 'case': case, 'role': role, 'cohort': cohort,
                'sample': sample, 'sequence': index, 'status': 'passed', 'returncode': 0,
                'direct_child_reaped': label != 'unreaped_process', 'process_group_drained': True,
                'record_sha256': sha(root / f'{name}.json'), 'log_sha256': sha(root / f'{name}.log'),
                'command': [str(binary), driver.TEST, '--exact', '--ignored', '--nocapture', '--test-threads=1'],
                'timeout_seconds': 120, 'output_limit_bytes': 8 << 20, 'timed_out': False, 'interrupted_signal': None}
        if label == 'wrong_command': call['command'][-1] = '--test-threads=8'
        write(root / f'supervision-{name}.json', call)
        packet['calls'].append(call)
    if label == 'missing_call': packet['calls'].pop()
    if label == 'bad_witness': next(witnesses.iterdir()).write_text('corrupted')
    packet['complete'] = True
    write(root / 'outcome.json', packet)


def main():
    report = ROOT / 'scorer-validation-r1.json'
    assert not report.exists()
    binary = ROOT / 'tmp' / 'synthetic-scorer-binary-r1.txt'
    with binary.open('x') as output: output.write('synthetic metadata only; never executable')
    assert len(driver.schedule('measure')) == 84 and len(driver.schedule('observe')) == 14
    assert driver.schedule('measure') == scorer.expected_schedule()
    assert driver.schedule('measure')[:6] == [
        ('duplicate_numeric', 'baseline', 1, 1), ('duplicate_numeric', 'candidate', 1, 1),
        ('duplicate_numeric', 'candidate', 1, 2), ('duplicate_numeric', 'baseline', 1, 2),
        ('duplicate_numeric', 'baseline', 1, 3), ('duplicate_numeric', 'candidate', 1, 3)]
    results = []
    expected = {'pass': True, 'target_second_cohort_fail': False, 'engine_control_fail': False,
                'setup_control_fail': False, 'tiny_allowance_pass': True, 'tiny_allowance_fail': False,
                'missing_call': 'rejected', 'bad_witness': 'rejected', 'wrong_schema': 'rejected',
                'wrong_values': 'rejected', 'wrong_command': 'rejected', 'unreaped_process': 'rejected',
                'wrong_inputs': 'rejected'}
    try:
        for label, wanted in expected.items():
            root = ROOT / ('synthetic-scorer-r1-' + label)
            fixture(root, label, binary)
            outcome = 'rejected'
            try:
                sys.argv = [scorer.__file__, str(root)]
                with contextlib.redirect_stdout(io.StringIO()): scorer.main()
                outcome = json.loads((root / 'decision.json').read_text())['timing_gate_passed']
            except AssertionError:
                pass
            assert outcome == wanted, (label, wanted, outcome)
            members = {str(path.relative_to(root)): sha(path) for path in sorted(root.rglob('*')) if path.is_file()}
            assert all(not path.is_symlink() for path in root.rglob('*'))
            results.append({'case': label, 'expected': wanted, 'actual': outcome,
                            'verified_files': len(members), 'member_inventory_sha256': hashlib.sha256(json.dumps(members, sort_keys=True).encode()).hexdigest()})
            shutil.rmtree(root)
        write(report, {'status': 'passed', 'synthetic_only': True, 'engine_executions': 0,
                       'driver_sha256': sha(Path(driver.__file__)), 'scorer_sha256': sha(Path(scorer.__file__)),
                       'validator_sha256': sha(Path(__file__)), 'checks': results,
                       'generated_fixture_payloads_retired': True})
        print(json.dumps({'status': 'passed', 'checks': len(results), 'engine_executions': 0}))
    finally:
        assert binary.read_text() == 'synthetic metadata only; never executable'
        binary.unlink()


if __name__ == '__main__': main()
