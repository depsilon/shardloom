"""Create the immutable native join/count mechanism evidence packet."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile

P = Path('/Users/dylan/LocalData/shardloom/workflow-work-elimination-20261025')
W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
DEST = W / 'docs/benchmarks/evidence/native-join-count-2026-10-25'
MAX_RAW_BYTES = 16 * 1024 * 1024

ROOT_FILES = (
    'build_join_count_packet_r1.py',
    'run_join_count_comparison_r1.py',
    'score_join_count_comparison_r1.py',
    'verify_join_count_observations_r1.py',
    'validate_join_count_scorer_r1.py',
    'validate_join_count_observations_r1.py',
    'freeze_join_count_candidate_r1.py',
    'run_guarded.py',
    'scorer-validation-r1.json',
    'observation-verifier-validation-r1.json',
    'join-count-correctness-r1.json',
)
RUNTIME_FILES = (
    'baseline-runtime/release-manifest.json',
    'baseline-runtime/observe-manifest.json',
    'baseline-runtime/source-overlay.tar.gz',
    'candidate-runtime-r1/release-manifest.json',
    'candidate-runtime-r1/observe-manifest.json',
    'candidate-runtime-r1/release-source-overlay.tar.gz',
    'candidate-runtime-r1/observe-source-overlay.tar.gz',
)
RUN_PREFIXES = (
    'join-count-baseline-release-build-r1',
    'join-count-baseline-observe-build-r1',
    'join-count-focused-native-r1',
    'join-count-focused-native-r2',
    'join-count-focused-native-r3',
    'join-count-native-clippy-r1',
    'join-count-native-suite-r1',
    'join-count-native-suite-r2',
    'join-count-candidate-release-build-r1',
)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def require_regular(path):
    assert path.is_file() and not path.is_symlink(), f'not a regular non-symlink file: {path}'
    assert stat.S_ISREG(path.stat().st_mode), f'not regular: {path}'


def include(path, members):
    require_regular(path)
    relative = path.relative_to(P).as_posix()
    assert relative not in members, f'duplicate member: {relative}'
    members[relative] = path.read_bytes()


def include_result_directory(name, members):
    root = P / name
    assert root.is_dir() and not root.is_symlink(), name
    for child in sorted(root.iterdir()):
        assert not child.is_symlink(), f'symlink rejected: {child}'
        if child.name == 'witnesses':
            assert child.is_dir()
            for witness in sorted(child.iterdir()):
                assert not witness.is_symlink(), f'symlink rejected: {witness}'
                assert witness.is_file() and witness.suffix == '.json'
                include(witness, members)
        else:
            assert child.is_file() and child.suffix in ('.json', '.log'), child
            include(child, members)


def pack(members):
    raw_bytes = sum(len(payload) for payload in members.values())
    assert raw_bytes <= MAX_RAW_BYTES, f'raw evidence exceeds 16 MiB: {raw_bytes}'
    archive_buffer = io.BytesIO()
    with gzip.GzipFile(fileobj=archive_buffer, mode='wb', filename='',
                       mtime=0, compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode='w',
                          format=tarfile.USTAR_FORMAT) as archive:
            for name, payload in sorted(members.items()):
                prefix, _, leaf = name.rpartition('/')
                assert len(leaf.encode('utf-8')) <= 100
                assert len(prefix.encode('utf-8')) <= 155, f'USTAR path too long: {name}'
                entry = tarfile.TarInfo(name)
                entry.size = len(payload)
                entry.uid = 0
                entry.gid = 0
                entry.uname = ''
                entry.gname = ''
                entry.mode = 0o644
                entry.mtime = 0
                entry.type = tarfile.REGTYPE
                archive.addfile(entry, io.BytesIO(payload))
    return archive_buffer.getvalue(), raw_bytes


def verify_archive(archive_bytes, members):
    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:gz') as archive:
        entries = archive.getmembers()
        expected_names = sorted(members)
        assert [entry.name for entry in entries] == expected_names
        for entry in entries:
            assert entry.isfile() and entry.uid == entry.gid == entry.mtime == 0
            assert entry.mode == 0o644 and entry.uname == entry.gname == ''
            extracted = archive.extractfile(entry)
            assert extracted is not None
            assert extracted.read() == members[entry.name], entry.name
    assert archive_bytes[4:8] == b'\0\0\0\0', 'gzip timestamp must be zero'


def main():
    assert not DEST.exists(), f'destination already exists: {DEST}'
    members = {}
    include_result_directory('join-count-comparison-r1', members)
    include_result_directory('join-count-observations-r1', members)
    for relative in ROOT_FILES + RUNTIME_FILES:
        include(P / relative, members)
    for prefix in RUN_PREFIXES:
        for suffix in ('.json', '.log'):
            include(P / (prefix + suffix), members)

    archive_bytes, raw_bytes = pack(members)
    verify_archive(archive_bytes, members)
    baseline_release = json.loads((P / 'baseline-runtime/release-manifest.json').read_text())
    baseline_observe = json.loads((P / 'baseline-runtime/observe-manifest.json').read_text())
    assert baseline_release['revision'] == baseline_observe['revision']

    DEST.mkdir(parents=True, exist_ok=False)
    archive_path = DEST / 'packet.tar.gz'
    with archive_path.open('xb') as stream:
        stream.write(archive_bytes)
        stream.flush()
        os.fsync(stream.fileno())
    disk_archive = archive_path.read_bytes()
    assert disk_archive == archive_bytes
    verify_archive(disk_archive, members)
    manifest = {
        'schema_version': 'shardloom.native_join_count.packet.v1',
        'archive': {
            'path': 'packet.tar.gz',
            'sha256': sha256(disk_archive),
            'bytes': len(disk_archive),
        },
        'files': [
            {'path': name, 'sha256': sha256(payload), 'bytes': len(payload)}
            for name, payload in sorted(members.items())
        ],
        'baseline_head': baseline_release['revision'],
        'status': 'mechanism_comparison_passed_package_acceptance_pending',
        'notes': (
            'Native validation recorded 3312 passing tests and 33 ignored tests. '
            'This packet does not claim package acceptance, Full43 completion, or PR completion.'
        ),
        'raw_member_bytes': raw_bytes,
    }
    manifest_path = DEST / 'manifest.json'
    with manifest_path.open('x') as stream:
        json.dump(manifest, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())

    print(json.dumps({
        'archive': str(archive_path),
        'manifest': str(manifest_path),
        'archive_sha256': manifest['archive']['sha256'],
        'archive_bytes': manifest['archive']['bytes'],
        'member_count': len(members),
        'raw_member_bytes': raw_bytes,
        'readback_verified': True,
    }))


if __name__ == '__main__':
    main()
