"""Verify the fixed debug-observation run for native join/count elimination."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path('/Users/dylan/LocalData/shardloom/workflow-work-elimination-20261025')
HARNESS = 'shardloom-vortex/src/local_primitive_relational_join_count_cost_tests.rs'
CASES = (
    'duplicate_numeric', 'composite_text', 'skew', 'unique_match',
    'unique_no_match', 'tiny', 'ineligible_count_column',
)
ROWS = {
    'duplicate_numeric': (8192, 16384),
    'composite_text': (4096, 8192),
    'skew': (1024, 2048),
    'unique_match': (32768, 32768),
    'unique_no_match': (32768, 32768),
    'tiny': (17, 23),
    'ineligible_count_column': (8192, 8192),
}
DISTINCT_RIGHT = {
    'duplicate_numeric': 64,
    'composite_text': 32,
    'skew': 205,
    'unique_match': 32768,
    'unique_no_match': 32768,
    'tiny': 7,
    'ineligible_count_column': 8192,
}
COUNT_FIELDS = (
    'counted_join_stages', 'counted_join_build_rows',
    'counted_join_probe_rows', 'counted_join_represented_pairs',
)
EXPECTED_SCHEMA = {
    'Struct': [{'names': ['rows'], 'dtypes': [{'Primitive': ['u64', False]}]}, False]
}
MIB = 1 << 20
GIB = 1 << 30


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def expected_schedule():
    return [(case, role, 0, 0) for case in CASES
            for role in ('baseline', 'candidate')]


def main():
    if len(sys.argv) != 2:
        raise SystemExit('usage: verify_join_count_observations_r1.py NEW_OBSERVE_DIR')
    root = Path(sys.argv[1])
    assert root.is_absolute() and root.parent == OUT and root.is_dir()
    outcome_path = root / 'outcome.json'
    protocol_path = root / 'protocol.json'
    outcome = json.loads(outcome_path.read_text())
    protocol = json.loads(protocol_path.read_text())
    assert outcome['complete']
    assert outcome['protocol'] == protocol['protocol'] == 'native-join-count-v1'
    assert protocol['mode'] == outcome['mode'] == 'observe'
    schedule = expected_schedule()
    assert outcome['schedule'] == [list(row) for row in schedule]
    assert protocol['schedule'] == outcome['schedule']
    assert len(outcome['calls']) == 14
    assert outcome['source_inventory_before'] == outcome['source_inventory_after']
    manifests = outcome['runtime_manifests']
    assert protocol['runtime_manifests'] == manifests
    assert protocol['source_inventory_before'] == outcome['source_inventory_before']
    assert set(manifests) == {'baseline', 'candidate'}
    for role, manifest in manifests.items():
        assert digest(manifest['binary']) == manifest['binary_sha256'], role
        assert manifest['profile'] == 'ci-native'
        assert manifest['features'] == ['release-user-surfaces']
        assert manifest['harnesses'] == {HARNESS: digest(W / HARNESS)}
        assert isinstance(manifest['toolchain'], str) and manifest['toolchain']
        assert isinstance(manifest['revision'], str) and manifest['revision']
        assert isinstance(manifest['source_inventory'], dict)
        for relative, expected in manifest['source_inventory'].items():
            assert isinstance(relative, str) and relative
            assert isinstance(expected, str) and len(expected) == 64
    baseline = manifests['baseline']
    candidate = manifests['candidate']
    assert baseline['harnesses'] == candidate['harnesses']
    assert baseline['toolchain'] == candidate['toolchain']
    assert baseline['features'] == candidate['features']

    candidate_source = {}
    for relative, expected in sorted(candidate['source_inventory'].items()):
        path = W / relative
        assert path.is_file() and not path.is_symlink(), relative
        actual = digest(path)
        assert actual == expected, relative
        candidate_source[relative] = actual
    assert candidate_source == outcome['source_inventory_before']
    assert outcome['binary_sha256_before'] == {
        role: manifest['binary_sha256'] for role, manifest in manifests.items()}
    assert outcome['binary_sha256_after'] == outcome['binary_sha256_before']

    helper_paths = [Path(path) for path in outcome['helpers']]
    assert len(helper_paths) == 2
    assert protocol['helpers'] == outcome['helpers']
    for path in helper_paths:
        assert digest(path) == outcome['helpers'][str(path)]
    assert protocol['driver_sha256'] == outcome['driver_sha256']
    assert protocol['driver_sha256'] == digest(OUT / 'run_join_count_comparison_r1.py')
    # The runner records the measurement scorer's identity in both modes.
    assert protocol['scorer_sha256'] == outcome['scorer_sha256']
    assert protocol['scorer_sha256'] == digest(OUT / 'score_join_count_comparison_r1.py')
    assert protocol['frozen_protocol'] == outcome['frozen_protocol']
    frozen = outcome['frozen_protocol']
    assert hashlib.sha256(frozen['text'].encode('utf-8')).hexdigest() == frozen['sha256']
    frozen_path = W / frozen['source']
    assert frozen_path.is_file() and digest(frozen_path) == frozen['sha256']
    assert protocol['active_packet_limit_bytes'] == 192 * MIB
    assert sum(outcome['storage_before'].values()) <= 100 * GIB
    assert sum(outcome['storage_after'].values()) <= 100 * GIB

    records = {}
    witness_members = {}
    expected_names = {'protocol.json', 'outcome.json', 'witnesses'}
    for index, (call, expected_call) in enumerate(zip(outcome['calls'], schedule), 1):
        case, role, cohort, sample = expected_call
        assert (call['case'], call['role'], call['cohort'], call['sample']) == expected_call
        assert call['mode'] == 'observe' and call['sequence'] == index
        assert call['status'] == 'passed' and call['returncode'] == 0
        assert call['direct_child_reaped'] and call['process_group_drained']
        label = f'observe-{case}-{role}-{cohort}-{sample}'
        record_path = root / f'{label}.json'
        log_path = root / f'{label}.log'
        supervision_path = root / f'supervision-{label}.json'
        expected_names.update((record_path.name, log_path.name, supervision_path.name))
        assert record_path.is_file() and log_path.is_file() and supervision_path.is_file()
        assert digest(record_path) == call['record_sha256']
        assert digest(log_path) == call['log_sha256']
        receipt = json.loads(supervision_path.read_text())
        assert receipt == call, label
        expected_command = [
            manifests[role]['binary'],
            'local_primitives::prepared_relational::tests::join_count_cost_tests::native_join_count_cost_screen',
            '--exact', '--ignored', '--nocapture', '--test-threads=1',
        ]
        assert call['command'] == expected_command
        assert call['timeout_seconds'] == 120 and call['output_limit_bytes'] == 8 * MIB
        assert call['timed_out'] is False and call['interrupted_signal'] is None
        assert not call.get('error') and not call.get('cleanup_error')

        record = json.loads(record_path.read_text())
        assert record['protocol'] == 'native-join-count-v1'
        assert (record['case'], record['role'], record['cohort'], record['sample']) == expected_call
        assert record['observation_enabled'] is True
        assert record['complete_values_match'] is True and record['complete_schema_match'] is True
        assert record['expected_rows_witness'] == record['actual_rows_witness']
        assert record['reserved_after_cleanup'] == 0 and record['denied_reservations'] == 0
        assert record['memory_grant_bytes'] == 128 * MIB
        assert type(record['peak_reserved_bytes']) is int
        assert 0 <= record['peak_reserved_bytes'] <= record['memory_grant_bytes']
        assert (record['left_rows'], record['right_rows']) == ROWS[case]
        assert isinstance(record['observations'], dict)
        for field in ('engine_execution_ns', 'preparation_ns', 'result_serialization_ns'):
            assert type(record[field]) is int and record[field] >= 0
        for key in ('input_witnesses', 'expected_rows_witness',
                    'actual_rows_witness', 'schema_witness'):
            identities = record[key] if key == 'input_witnesses' else [record[key]]
            if key == 'input_witnesses':
                assert len(identities) == 2
            for identity in identities:
                assert isinstance(identity, str) and len(identity) == 64
                path = root / 'witnesses' / f'{identity}.json'
                assert path.is_file() and digest(path) == identity
                witness_members[path.name] = identity

        observations = record['observations']
        required_observation_fields = ('join_retained_right_rows',
                                       'join_output_rows_constructed')
        assert all(type(observations[field]) is int and observations[field] >= 0
                   for field in required_observation_fields)
        if role == 'candidate':
            assert all(type(observations[field]) is int and observations[field] >= 0
                       for field in COUNT_FIELDS)
        else:
            assert all(type(observations[field]) is int and observations[field] == 0
                       for field in COUNT_FIELDS if field in observations)
        records[(case, role)] = record

    case_results = []
    for case in CASES:
        baseline_record = records[(case, 'baseline')]
        candidate_record = records[(case, 'candidate')]
        assert baseline_record['input_witnesses'] == candidate_record['input_witnesses']
        assert baseline_record['schema_witness'] == candidate_record['schema_witness']
        assert baseline_record['expected_rows_witness'] == candidate_record['expected_rows_witness']
        assert baseline_record['actual_rows_witness'] == candidate_record['actual_rows_witness']
        for record in (baseline_record, candidate_record):
            assert (record['left_rows'], record['right_rows']) == ROWS[case]
            assert record['expected_rows_witness'] == record['actual_rows_witness']
            expected_path = root / 'witnesses' / f"{record['expected_rows_witness']}.json"
            actual_path = root / 'witnesses' / f"{record['actual_rows_witness']}.json"
            expected_values = json.loads(expected_path.read_text())
            actual_values = json.loads(actual_path.read_text())
            assert expected_values == actual_values
            assert isinstance(expected_values, list) and len(expected_values) == 1
            assert set(expected_values[0]) == {'rows'}
            assert type(expected_values[0]['rows']) is int
            assert 0 <= expected_values[0]['rows'] <= (1 << 64) - 1
            schema_path = root / 'witnesses' / f"{record['schema_witness']}.json"
            assert json.loads(schema_path.read_text()) == EXPECTED_SCHEMA
        schema_path = root / 'witnesses' / f"{baseline_record['schema_witness']}.json"
        assert hashlib.sha256(schema_path.read_bytes()).hexdigest() == baseline_record['schema_witness']

        # Recreate the complete input rows and answer using Python values,
        # independently of the native implementation and Rust harness oracle.
        input_values = [json.loads((root / 'witnesses' / f'{identity}.json').read_text())
                        for identity in baseline_record['input_witnesses']]

        def make_keys(data, expected_rows, side):
            assert set(data) == {'n', 's', 'id'}
            assert len(data['n']) == len(data['id']) == expected_rows
            assert data['id'] == list(range(expected_rows))
            assert all(type(value) is int for value in data['n'])
            assert len(data['s']) == (expected_rows if case == 'composite_text' else 0)
            numbers = []
            for row in range(expected_rows):
                if case == 'duplicate_numeric':
                    value = row % 64
                elif case == 'composite_text':
                    value = row % 32
                elif case == 'skew':
                    value = 0 if row % 10 != 9 else row + 1
                elif case == 'tiny':
                    value = row % 7
                elif case == 'unique_no_match' and side == 1:
                    value = row + expected_rows
                else:
                    value = row
                numbers.append(value)
            assert data['n'] == numbers, (case, side)
            if case == 'composite_text':
                assert data['s'] == [f'clé-東京-{value}' for value in numbers]
            return [(value, data['s'][row] if data['s'] else None)
                    for row, value in enumerate(data['n'])]

        left_keys, right_keys = [
            make_keys(data, rows, side)
            for side, (data, rows) in enumerate(zip(input_values, ROWS[case]))
        ]
        right_counts = Counter(right_keys)
        expected_pairs = sum(right_counts[key] for key in left_keys)
        unique_right_keys = len(right_counts)
        assert unique_right_keys == DISTINCT_RIGHT[case]
        expected_values = json.loads((root / 'witnesses' /
            f"{baseline_record['expected_rows_witness']}.json").read_text())
        assert expected_values == [{'rows': expected_pairs}], case

        baseline_obs = baseline_record['observations']
        candidate_obs = candidate_record['observations']
        if case == 'ineligible_count_column':
            for role, obs in (('baseline', baseline_obs), ('candidate', candidate_obs)):
                assert obs['join_output_rows_constructed'] == expected_pairs == 8192
                assert obs['join_retained_right_rows'] == ROWS[case][1] == 8192
                for field in COUNT_FIELDS:
                    assert obs.get(field, 0) == 0, (case, role, field)
        else:
            assert baseline_obs['join_output_rows_constructed'] == expected_pairs
            assert baseline_obs['join_retained_right_rows'] == ROWS[case][1]
            for field in COUNT_FIELDS:
                assert baseline_obs.get(field, 0) == 0, (case, field)
            assert candidate_obs['join_output_rows_constructed'] == 0
            assert candidate_obs['join_retained_right_rows'] == unique_right_keys
            assert candidate_obs['counted_join_stages'] == 1
            assert candidate_obs['counted_join_build_rows'] == ROWS[case][1]
            assert candidate_obs['counted_join_probe_rows'] == ROWS[case][0]
            assert candidate_obs['counted_join_represented_pairs'] == expected_pairs

        case_results.append({
            'case': case,
            'left_rows': ROWS[case][0],
            'right_rows': ROWS[case][1],
            'expected_matching_pairs': expected_pairs,
            'unique_right_keys': unique_right_keys,
            'baseline_observations': {
                'join_output_rows_constructed': baseline_obs['join_output_rows_constructed'],
                'join_retained_right_rows': baseline_obs['join_retained_right_rows'],
                'counted_fields': {field: baseline_obs.get(field, 0) for field in COUNT_FIELDS},
            },
            'candidate_observations': {
                'join_output_rows_constructed': candidate_obs['join_output_rows_constructed'],
                'join_retained_right_rows': candidate_obs['join_retained_right_rows'],
                'counted_fields': {field: candidate_obs[field] for field in COUNT_FIELDS},
            },
            'baseline_values_and_schema_match': baseline_record['complete_values_match'] and
                                               baseline_record['complete_schema_match'],
            'candidate_values_and_schema_match': candidate_record['complete_values_match'] and
                                                 candidate_record['complete_schema_match'],
            'resource_cleanup_passed': all(
                record['reserved_after_cleanup'] == record['denied_reservations'] == 0
                for record in (baseline_record, candidate_record)),
            'mechanism_gate_passed': True,
            'record_identities': {
                'baseline': digest(root / f"observe-{case}-baseline-0-0.json"),
                'candidate': digest(root / f"observe-{case}-candidate-0-0.json"),
            },
        })

    assert {path.name for path in root.iterdir()} == expected_names
    assert {path.name for path in (root / 'witnesses').iterdir()} == set(witness_members)
    result = {
        'protocol': 'native-join-count-v1',
        'mode': 'observe',
        'verifier_sha256': digest(__file__),
        'measurement_scorer_sha256': protocol['scorer_sha256'],
        'outcome_sha256': digest(outcome_path),
        'protocol_sha256': digest(protocol_path),
        'calls_verified': 14,
        'schedule_verified': True,
        'all_complete_values_and_schemas_match': True,
        'all_mechanism_assertions_passed': True,
        'all_resource_cleanup_checks_passed': True,
        'timing_scored': False,
        'cases': case_results,
        'record_sha256': {
            f'{case}-{role}': digest(root / f'observe-{case}-{role}-0-0.json')
            for case in CASES for role in ('baseline', 'candidate')
        },
        'witness_sha256': witness_members,
    }
    write_new(root / 'observation-verification.json', result)
    print(json.dumps({
        'calls_verified': result['calls_verified'],
        'all_mechanism_assertions_passed': result['all_mechanism_assertions_passed'],
        'cases': [
            {'case': item['case'], 'expected_matching_pairs': item['expected_matching_pairs'],
             'unique_right_keys': item['unique_right_keys'],
             'candidate_output_rows_constructed': item['candidate_observations']['join_output_rows_constructed'],
             'candidate_counted_join_stages': item['candidate_observations']['counted_fields']['counted_join_stages']}
            for item in case_results
        ],
    }))


if __name__ == '__main__':
    main()
