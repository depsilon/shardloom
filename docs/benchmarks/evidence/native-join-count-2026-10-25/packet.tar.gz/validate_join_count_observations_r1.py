"""Synthetic observer-verifier checks; never executes an engine."""
from collections import Counter
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import sys

P = Path(__file__).resolve().parent


def load(name):
    spec = importlib.util.spec_from_file_location(name, P / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


fixture_module = load('validate_join_count_scorer_r1')
verifier = load('verify_join_count_observations_r1')
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value))


def main():
    binary = P / 'tmp' / 'synthetic-observer-binary-r1.txt'
    with binary.open('x') as stream:
        stream.write('synthetic observation metadata; never executable')
    checks = []
    labels = ['pass', 'pairs_constructed', 'wrong_retention', 'short_input',
              'wrong_cardinality', 'missing_candidate_field', 'ineligible_activation',
              'baseline_activation', 'unreaped_process']
    try:
        for label in labels:
            root = P / f'synthetic-observer-r1-{label}'
            fixture_module.fixture(root, 'pass', binary)
            packet = json.loads((root / 'outcome.json').read_text())
            records = {}
            for call in packet['calls']:
                old = f"measure-{call['case']}-{call['role']}-{call['cohort']}-{call['sample']}"
                if call['cohort'] == call['sample'] == 1:
                    records[(call['case'], call['role'])] = (
                        json.loads((root / f'{old}.json').read_text()), call)
                for name in (f'{old}.json', f'{old}.log', f'supervision-{old}.json'):
                    (root / name).unlink()
            packet['mode'] = 'observe'
            packet['schedule'] = [list(row) for row in verifier.expected_schedule()]
            packet['frozen_protocol']['source'] = str(
                fixture_module.driver.PROTOCOL_DOCUMENT.relative_to(verifier.W))
            for manifest in packet['runtime_manifests'].values():
                manifest['profile'] = 'ci-native'
            packet['calls'] = []
            for index, (case, role, cohort, sample) in enumerate(verifier.expected_schedule(), 1):
                record, call = records[(case, role)]
                expected = json.loads((root / 'witnesses' /
                    f"{record['expected_rows_witness']}.json").read_text())[0]['rows']
                eligible = case != 'ineligible_count_column'
                activated = role == 'candidate' and eligible
                observations = {
                    'join_output_rows_constructed': 0 if activated else expected,
                    'join_retained_right_rows': (verifier.DISTINCT_RIGHT[case]
                        if activated else verifier.ROWS[case][1]),
                }
                if role == 'candidate':
                    observations.update(counted_join_stages=int(activated),
                        counted_join_build_rows=verifier.ROWS[case][1] if activated else 0,
                        counted_join_probe_rows=verifier.ROWS[case][0] if activated else 0,
                        counted_join_represented_pairs=expected if activated else 0)
                if case == 'duplicate_numeric' and role == 'candidate':
                    if label == 'pairs_constructed': observations['join_output_rows_constructed'] = 1
                    if label == 'wrong_retention': observations['join_retained_right_rows'] += 1
                    if label == 'short_input': observations['counted_join_build_rows'] -= 1
                    if label == 'wrong_cardinality': observations['counted_join_represented_pairs'] -= 1
                    if label == 'missing_candidate_field': observations.pop('counted_join_probe_rows')
                if case == 'ineligible_count_column' and role == 'candidate' and label == 'ineligible_activation':
                    observations['counted_join_stages'] = 1
                if case == 'tiny' and role == 'baseline' and label == 'baseline_activation':
                    observations['counted_join_stages'] = 1
                record.update(cohort=cohort, sample=sample, observations=observations,
                              observation_enabled=True)
                name = f'observe-{case}-{role}-0-0'
                write(root / f'{name}.json', record)
                (root / f'{name}.log').write_text('Synthetic observer fixture, no engine execution.\n')
                call.update(mode='observe', cohort=0, sample=0, sequence=index,
                    record_sha256=digest(root / f'{name}.json'),
                    log_sha256=digest(root / f'{name}.log'),
                    direct_child_reaped=label != 'unreaped_process')
                write(root / f'supervision-{name}.json', call)
                packet['calls'].append(call)
            write(root / 'outcome.json', packet)
            write(root / 'protocol.json', packet)
            accepted = False
            try:
                sys.argv = [verifier.__file__, str(root)]
                with contextlib.redirect_stdout(io.StringIO()):
                    verifier.main()
                accepted = True
            except (AssertionError, KeyError):
                pass
            assert accepted == (label == 'pass'), (label, accepted)
            members = {str(path.relative_to(root)): digest(path)
                       for path in sorted(root.rglob('*')) if path.is_file()}
            assert all(not path.is_symlink() for path in root.rglob('*'))
            checks.append({'case': label, 'accepted': accepted,
                'member_inventory_sha256': hashlib.sha256(json.dumps(members, sort_keys=True).encode()).hexdigest()})
            shutil.rmtree(root)
        report = {'status': 'passed', 'synthetic_only': True, 'engine_executions': 0,
            'verifier_sha256': digest(Path(verifier.__file__)),
            'validator_sha256': digest(Path(__file__)), 'checks': checks,
            'generated_fixture_payloads_retired': True}
        with (P / 'observation-verifier-validation-r1.json').open('x') as stream:
            json.dump(report, stream, indent=2)
        print(json.dumps({'status': 'passed', 'checks': len(checks), 'engine_executions': 0}))
    finally:
        assert binary.read_text() == 'synthetic observation metadata; never executable'
        binary.unlink()


if __name__ == '__main__':
    main()
