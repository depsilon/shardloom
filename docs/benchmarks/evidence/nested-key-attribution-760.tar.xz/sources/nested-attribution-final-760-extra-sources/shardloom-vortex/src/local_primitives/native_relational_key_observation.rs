//! Temporary test-only attribution. The exact opt-in serial harness owns enablement.
//! Root spans are disjoint even when a struct recursively visits nested children.

use std::{
    cell::Cell,
    marker::PhantomData,
    rc::Rc,
    sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering},
    time::Instant,
};

static ENABLED: AtomicBool = AtomicBool::new(false);
static SESSION: AtomicBool = AtomicBool::new(false);
static ACTIVE: AtomicUsize = AtomicUsize::new(0);
static MAX_ACTIVE: AtomicUsize = AtomicUsize::new(0);
static NANOS: [AtomicU64; 4] = [const { AtomicU64::new(0) }; 4];
static CALLS: [AtomicU64; 4] = [const { AtomicU64::new(0) }; 4];
thread_local! { static DEPTH: Cell<usize> = const { Cell::new(0) }; }

#[derive(Clone, Copy)]
pub(in crate::local_primitives) enum Stage {
    Construction,
    Hash,
    Compare,
    Exact,
}

pub(in crate::local_primitives) struct Span {
    root: Option<(Instant, Stage)>,
    // Depth belongs to this thread; a guard must never move to another worker.
    _same_thread: PhantomData<Rc<()>>,
}

pub(in crate::local_primitives) fn enter(stage: Stage) -> Option<Span> {
    if !ENABLED.load(Ordering::Relaxed) {
        return None;
    }
    let root = DEPTH.with(|depth| {
        let old = depth.get();
        depth.set(old + 1);
        (old == 0).then(|| {
            let started = Instant::now();
            let active = ACTIVE.fetch_add(1, Ordering::SeqCst) + 1;
            MAX_ACTIVE.fetch_max(active, Ordering::Relaxed);
            (started, stage)
        })
    });
    Some(Span {
        root,
        _same_thread: PhantomData,
    })
}

impl Drop for Span {
    fn drop(&mut self) {
        DEPTH.with(|depth| {
            assert!(depth.get() > 0, "unbalanced key observation");
            depth.set(depth.get() - 1);
        });
        if let Some((started, stage)) = self.root {
            let nanos = u64::try_from(started.elapsed().as_nanos()).unwrap();
            NANOS[stage as usize].fetch_add(nanos, Ordering::Relaxed);
            CALLS[stage as usize].fetch_add(1, Ordering::Relaxed);
            assert!(ACTIVE.fetch_sub(1, Ordering::SeqCst) > 0);
        }
    }
}

pub(in crate::local_primitives) struct Session;

impl Session {
    pub(in crate::local_primitives) fn start(enabled: bool) -> Self {
        assert!(!SESSION.swap(true, Ordering::SeqCst), "serial harness only");
        assert!(!ENABLED.load(Ordering::SeqCst));
        assert_eq!(ACTIVE.load(Ordering::SeqCst), 0);
        DEPTH.with(|depth| assert_eq!(depth.get(), 0));
        for metric in NANOS.iter().chain(CALLS.iter()) {
            metric.store(0, Ordering::Relaxed);
        }
        MAX_ACTIVE.store(0, Ordering::Relaxed);
        ENABLED.store(enabled, Ordering::SeqCst);
        Self
    }

    pub(in crate::local_primitives) fn finish(self) -> serde_json::Value {
        ENABLED.store(false, Ordering::SeqCst);
        assert_eq!(ACTIVE.load(Ordering::SeqCst), 0, "key roots must drain");
        DEPTH.with(|depth| assert_eq!(depth.get(), 0));
        let names = [
            "key_owner_construction",
            "nested_hash",
            "nested_compare",
            "nested_exact_serialization",
        ];
        let stages = names
            .into_iter()
            .enumerate()
            .map(|(i, name)| {
                (
                    name.to_owned(),
                    serde_json::json!({
                        "root_calls": CALLS[i].load(Ordering::Relaxed),
                        "nanoseconds": NANOS[i].load(Ordering::Relaxed),
                    }),
                )
            })
            .collect::<serde_json::Map<_, _>>();
        let result = serde_json::json!({
            "stages": stages,
            "active_roots_after_drain": ACTIVE.load(Ordering::SeqCst),
            "maximum_simultaneous_roots": MAX_ACTIVE.load(Ordering::Relaxed),
        });
        drop(self);
        result
    }
}

impl Drop for Session {
    fn drop(&mut self) {
        ENABLED.store(false, Ordering::SeqCst);
        SESSION.store(false, Ordering::SeqCst);
    }
}
