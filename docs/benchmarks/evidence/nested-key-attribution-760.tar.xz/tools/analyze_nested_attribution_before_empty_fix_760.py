"""Independent complete-value oracle and frozen nested-key attribution decision."""
import argparse
from collections import OrderedDict, defaultdict
import hashlib
import itertools
import json
from pathlib import Path
import statistics

OUT = Path(__file__).resolve().parent
STAGES = ['key_owner_construction', 'nested_hash', 'nested_compare', 'nested_exact_serialization']
CONSUMERS = ['group_count', 'count_distinct', 'left_join', 'unary_distinct']
SHAPES = ['list_i64', 'struct_list_i64']
REPS = ['plain', 'parent_dictionary']
PROTOCOL_SHA = 'dcab70000481b36a88db907139805762bce91339a268a52007adaa826133febc'

def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def specs():
    for values in itertools.product([128,4096], SHAPES, ['eight','unique'], REPS, CONSUMERS, [1,4]):
        yield dict(zip(['rows','shape','domain','representation','consumer','calls'],values))

def controls():
    for rows, shape, representation, consumer in itertools.product([0,32],SHAPES,REPS,CONSUMERS):
        yield dict(rows=rows,shape=shape,domain='all_null',representation=representation,consumer=consumer,calls=1)

def cell_id(spec):
    return '-'.join(str(spec[k]) for k in ['rows','shape','domain','representation','consumer','calls'])

def ids(spec):
    return [0 if spec['domain']=='all_null' else r%8 if spec['domain']=='eight' else r for r in range(spec['rows'])]

def key(shape, d):
    if d==0:
        return None
    children=[] if d==1 else [None if (d+j)%5==0 else d*32+j-100 for j in range(16+d%3)]
    return children if shape=='list_i64' else dict(items=None if d==2 else children,tag=None if d%5==0 else d-20)

def right_ids(spec):
    return [d for d in sorted(set(ids(spec))) if d%3==0 for _ in range(2)]

def expected_rows(spec):
    left=[key(spec['shape'],d) for d in ids(spec)]
    groups=OrderedDict()
    for value in left:
        identity=encoded(value)
        if identity not in groups: groups[identity]=[value,0]
        groups[identity][1]+=1
    consumer=spec['consumer']
    if consumer=='group_count': return [dict(key=k,rows=n) for k,n in groups.values()]
    if consumer=='count_distinct': return [dict(distinct=sum(k is not None for k,_ in groups.values()))]
    if consumer=='unary_distinct': return [dict(key=k) for k,_ in groups.values()]
    assert consumer=='left_join'
    lookup=defaultdict(list)
    for ordinal,d in enumerate(right_ids(spec)):
        value=key(spec['shape'],d)
        if value is not None: lookup[encoded(value)].append(ordinal)
    return [dict(ordinal=i,key=value,right_ordinal=right)
            for i,value in enumerate(left)
            for right in (lookup[encoded(value)] if value is not None and encoded(value) in lookup else [None])]

def struct(names,types,nullable=False):
    return {'Struct':[{'names':names,'dtypes':types},nullable]}

def primitive(name,nullable=False):
    return {'Primitive':[name,nullable]}

def key_dtype(shape):
    dtype={'List':[primitive('i64',True),True]}
    return dtype if shape=='list_i64' else struct(['items','tag'],[dtype,primitive('i64',True)],True)

def schema(spec,source=False):
    dtype=key_dtype(spec['shape'])
    if source: return struct(['ordinal','key'],[primitive('u64'),dtype])
    return {
        'group_count':struct(['key','rows'],[dtype,primitive('u64')]),
        'count_distinct':struct(['distinct'],[primitive('u64')]),
        'unary_distinct':struct(['key'],[dtype]),
        'left_join':struct(['ordinal','key','right_ordinal'],[primitive('u64'),dtype,primitive('u64',True)]),
    }[spec['consumer']]

class Witnesses:
    def __init__(self,root):
        self.root=root
        self.seen={}
    def load(self,identity):
        assert isinstance(identity,str) and len(identity)==64 and all(c in '0123456789abcdef' for c in identity)
        data=(self.root/'witnesses'/f'{identity}.json').read_bytes()
        assert digest(data)==identity
        self.seen[identity]={'bytes':len(data),'sha256':identity}
        return json.loads(data)
    def check(self,identity,expected):
        assert identity==digest(encoded(expected)), 'independent expected witness mismatch'
        if identity not in self.seen:
            assert self.load(identity)==expected

def validate_record(record,spec,expected_profile,sample,warmup,cohort,witnesses):
    for name,value in spec.items(): assert record[name]==value,(name,record.get(name),value)
    assert record['cell_id']==cell_id(spec)
    assert (record['profile'],record['sample'],record['warmup'],record['cohort'])==(expected_profile,sample,warmup,cohort)
    expected=expected_rows(spec)
    dtype=schema(spec)
    witnesses.check(record['expected_rows_witness'],expected)
    witnesses.check(record['expected_schema_witness'],dtype)
    assert record['reserved_after_cleanup']==record['denied_reservations']==0
    assert 0<record['peak_reserved_bytes']<=128<<20
    assert record['admitted_max_parallelism']==1
    assert record['completed_executions']==spec['calls']
    assert record['prepared_source_opens']==(2 if spec['consumer']=='left_join' else 1)
    assert record['provider_background_workers']==0
    assert len(record['operations'])==spec['calls']
    complete=record['preparation_ns']+record['destruction_ns']
    assert record['preparation_ns']>0 and record['destruction_ns']>0
    for i,operation in enumerate(record['operations']):
        assert operation['call']==i and operation['completed_executions']==i+1
        assert operation['rows']==len(expected)
        witnesses.check(operation['actual_rows_witness'],expected)
        witnesses.check(operation['actual_schema_witness'],dtype)
        for clock in ['engine_execution_ns','result_serialization_ns','execution_and_consumption_ns','output_release_ns']:
            assert isinstance(operation[clock],int) and operation[clock]>=0
        assert operation['execution_and_consumption_ns']>=operation['engine_execution_ns']+operation['result_serialization_ns']
        complete+=operation['execution_and_consumption_ns']+operation['output_release_ns']
        certificate=operation['native_io_certificate']
        assert certificate['certified'] is True and certificate['fallback_attempted'] is False
        assert 'NativeIoCertificate' in certificate['complete_debug'] and 'fallback_attempted: false' in certificate['complete_debug']
    assert record['complete_workflow_ns']==complete
    observed=record['observation']
    assert set(observed['stages'])==set(STAGES)
    assert observed['active_roots_after_drain']==0
    assert observed['maximum_simultaneous_roots']<=1
    key_cost=0
    for stage in observed['stages'].values():
        assert set(stage)=={'root_calls','nanoseconds'}
        assert stage['root_calls']>=0 and stage['nanoseconds']>=0
        if expected_profile=='disabled': assert stage['root_calls']==stage['nanoseconds']==0
        key_cost+=stage['nanoseconds']
    if expected_profile=='disabled': assert observed['maximum_simultaneous_roots']==0
    elif spec['rows'] and spec['domain']!='all_null':
        assert observed['maximum_simultaneous_roots']==1
        assert observed['stages']['key_owner_construction']['root_calls']>0
        assert sum(stage['root_calls'] for stage in observed['stages'].values())>0 and key_cost>0
    assert key_cost<=complete, 'nested spans exceed complete disjoint workflow clock'

def fixture_validation(root,witnesses):
    records=json.loads((root/'fixtures.json').read_text())
    unique={}
    for spec in itertools.chain(specs(),controls()):
        unique['-'.join(str(spec[k]) for k in ['rows','shape','domain','representation'])]=spec
    assert len(unique)==24 and len(records)==48
    seen=set()
    for record in records:
        identity=(record['fixture_id'],record['side'])
        assert identity not in seen and record['side'] in ('left','right')
        seen.add(identity)
        spec=unique[record['fixture_id']]
        domains=ids(spec) if record['side']=='left' else right_ids(spec)
        expected=[dict(ordinal=i,key=key(spec['shape'],d)) for i,d in enumerate(domains)]
        assert record['rows']==len(domains)
        witnesses.check(record['actual_rows_witness'],expected)
        witnesses.check(record['schema_witness'],schema(spec,source=True))
        assert record['length']<=16<<20 and record['chunk_rows']==257
        assert record['compression']=='none' and record['file_statistics'] is False and record['reserved_after_cleanup']==0
        path=Path(record['path'])
        assert path.is_relative_to(root/'fixtures')
        assert path.stat().st_size==record['length'] and digest(path.read_bytes())==record['sha256']
        physical=witnesses.load(record['physical_file_witness'])
        assert physical['complete_flat_inspection'] and physical['all_referenced_segments_are_flat']
        assert not physical['fallback_attempted'] and not physical['external_engine_invoked']
        assert physical['non_flat_segment_references_not_inspected']==[]
        assert sum(flat['rows'] for flat in physical['flat_references'])==len(domains)
        assert len(physical['flat_references'])==max(1,(len(domains)+256)//257)
        for flat in physical['flat_references']:
            assert flat['rows']<=257
            assert flat['layout_path']==['vortex.chunked','vortex.flat']
            encodings={node['encoding_id'] for node in flat['stored_array_nodes']}
            if spec['representation']=='parent_dictionary' and domains: assert 'vortex.dict' in encodings
            if spec['representation']=='plain': assert 'vortex.dict' not in encodings
    assert seen==set(itertools.product(unique,['left','right']))
    return {'fixtures':len(records),'manifest_sha256':digest((root/'fixtures.json').read_bytes())}

def read_cohort(root,mode,cohort,witnesses):
    path=root/f'{mode}-{cohort}.jsonl'
    records=[json.loads(line) for line in path.read_text().splitlines()]
    expected=[]
    matrix=list(specs())
    if mode=='measure':
        for profile in ['disabled','enabled']: expected.append((matrix[0],profile,0,True))
    for index,spec in enumerate(matrix):
        for sample in range(3 if mode=='measure' else 1):
            first=((index+sample)%2==0) ^ (cohort=='B')
            for enabled in [not first,first]: expected.append((spec,'enabled' if enabled else 'disabled',sample,False))
    if mode=='preflight':
        for spec in controls():
            for profile in ['disabled','enabled']: expected.append((spec,profile,0,False))
    assert len(records)==len(expected)==(770 if mode=='measure' else 320)
    for record,(spec,profile,sample,warmup) in zip(records,expected):
        validate_record(record,spec,profile,sample,warmup,cohort,witnesses)
    operations=sum(len(record['operations']) for record in records)
    assert operations==(1922 if mode=='measure' else 704)
    return records,{'file':str(path),'sha256':digest(path.read_bytes()),'workflows':len(records),'operations':operations}

def score(disabled,enabled):
    baseline=statistics.median(r['complete_workflow_ns'] for r in disabled)
    measured=statistics.median(r['complete_workflow_ns'] for r in enabled)
    key_cost=statistics.median(sum(s['nanoseconds'] for s in r['observation']['stages'].values()) for r in enabled)
    overhead=max(0,measured-baseline)
    eligible=not (measured*100>baseline*105 and overhead>1_000_000)
    conservative=max(0,key_cost-overhead)
    return dict(disabled_median_complete_ns=baseline,enabled_median_complete_ns=measured,
        enabled_median_key_stage_ns=key_cost,charged_positive_overhead_ns=overhead,
        overhead_eligible=eligible,conservative_key_cost_ns=conservative,
        conservative_key_fraction=conservative/baseline,
        material=eligible and conservative>=1_000_000 and conservative*10>=baseline)

def analysis(cohorts):
    scores={}
    for cohort,records in cohorts.items():
        grouped=defaultdict(lambda:defaultdict(list))
        for record in records:
            if not record['warmup']: grouped[record['cell_id']][record['profile']].append(record)
        assert len(grouped)==128
        scores[cohort]={}
        for identity,profiles in grouped.items():
            assert len(profiles['disabled'])==len(profiles['enabled'])==3
            scores[cohort][identity]=score(profiles['disabled'],profiles['enabled'])
    common=[spec for spec in specs() if spec['domain']=='eight' and all(scores[c][cell_id(spec)]['material'] for c in ['A','B'])]
    positive=len(common)>=2 and len({spec['shape'] for spec in common})>=2
    unavailable=[{'cohort':c,'cell_id':identity} for c in scores for identity,score_ in scores[c].items() if not score_['overhead_eligible']]
    outcome='material_attribution_only' if positive else 'observer_overhead_prevents_complete_attribution' if unavailable else 'no_material_signal_in_frozen_workload'
    return dict(outcome=outcome,optimization_accepted=False,identity_candidate_admitted_for_design=positive,
        scores=scores,common_material_eight_domain_cells=common,
        observed_qualifying_consumers=sorted({spec['consumer'] for spec in common}),
        overhead_ineligible_cells=unavailable,
        scope='Attribution is not improvement, production acceptance or broader PERF-05 closure.')

def self_test():
    assert key('list_i64',0) is None and key('list_i64',1)==[]
    assert key('struct_list_i64',2)=={'items':None,'tag':-18}
    assert key('list_i64',3)[2] is None
    spec=dict(rows=8,shape='list_i64',domain='eight',representation='plain',consumer='left_join',calls=1)
    result=expected_rows(spec)
    assert [(r['ordinal'],r['right_ordinal']) for r in result]==[(0,None),(1,None),(2,None),(3,2),(3,3),(4,None),(5,None),(6,4),(6,5),(7,None)]
    def row(total,cost): return {'complete_workflow_ns':total,'observation':{'stages':{'stage':{'nanoseconds':cost}}}}
    assert score([row(10_000_000,0)]*3,[row(10_000_000,1_000_000)]*3)['material']
    assert not score([row(10_000_000,0)]*3,[row(10_000_000,999_999)]*3)['material']
    assert score([row(10_000_000,0)]*3,[row(11_000_000,2_000_000)]*3)['overhead_eligible']
    assert not score([row(10_000_000,0)]*3,[row(11_000_001,8_000_000)]*3)['overhead_eligible']
    assert score([row(40_000_000,0)]*3,[row(42_000_000,8_000_000)]*3)['overhead_eligible']
    assert score([row(10_000_000,0)]*3,[row(10_900_000,1_500_000)]*3)['conservative_key_cost_ns']==600_000

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=OUT/'nested-key-attribution-760-a1')
    parser.add_argument('--preflight',action='store_true')
    parser.add_argument('--cohort',default='preflight')
    parser.add_argument('--output',type=Path)
    parser.add_argument('--self-test-only',action='store_true')
    args=parser.parse_args()
    self_test()
    assert digest((OUT/'nested-key-attribution-protocol-759.json').read_bytes())==PROTOCOL_SHA
    if args.self_test_only:
        print('independent oracle and exact gate boundary tests passed')
        return
    witnesses=Witnesses(args.root)
    fixtures=fixture_validation(args.root,witnesses)
    if args.preflight:
        _,receipt=read_cohort(args.root,'preflight',args.cohort,witnesses)
        result={'outcome':'preflight_semantics_resources_and_observer_validated','receipt':receipt}
    else:
        cohorts={}
        receipts=[]
        for name in ['A','B']:
            cohorts[name],receipt=read_cohort(args.root,'measure',name,witnesses)
            receipts.append(receipt)
        result=analysis(cohorts)
        result['cohorts']=receipts
    result.update(protocol_sha256=PROTOCOL_SHA,analyzer_sha256=digest(Path(__file__).read_bytes()),
        fixtures=fixtures,verified_witnesses=list(witnesses.seen.values()))
    assert args.output
    with args.output.open('x') as stream:
        json.dump(result,stream,indent=2)
        stream.write('\n')
    print(json.dumps({'outcome':result['outcome'],'witnesses_verified':len(witnesses.seen),'output':str(args.output)}))

if __name__=='__main__': main()
