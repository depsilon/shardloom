"""Create an indexed, verified packet for the completed nested-key attribution."""
from pathlib import Path
import hashlib
import io
import json
import lzma
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
DEST = ROOT / 'nested-attribution-portable-760'
NAME = 'nested-key-attribution-760'
sys.path.insert(0, str(REPO / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

PROTOCOL_SHA = 'dcab70000481b36a88db907139805762bce91339a268a52007adaa826133febc'
FINAL_TEST_SHA = '978a3af734edf9a13211314a486e7d50721576aa02a76ca9ce4465181985ac94'
PREFLIGHT_TEST_SHA = '5c45e2459b7fa89eeea58e6a4b5af2ef37cee7803e937ff6d1cf2affdf3609d0'
SUPERVISOR_SHA = '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97'


def digest_file(path):
    hasher = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            hasher.update(chunk)
    return hasher.hexdigest()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def add_file(members, archive_name, path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), f'not a regular file: {path}'
    assert archive_name not in members, f'duplicate member: {archive_name}'
    members[archive_name] = path


def verify_freeze(path, expected_protocol):
    record = json.loads(path.read_text())
    assert record['protocol_sha256'] == expected_protocol
    assert record['sources']
    return record


protocol_path = ROOT / 'nested-key-attribution-protocol-759.json'
analysis_path = ROOT / 'nested-attribution-analysis-760.json'
preflight_analysis_path = ROOT / 'nested-attribution-preflight-analysis-fixed-760.json'
analysis = json.loads(analysis_path.read_text())
protocol = json.loads(protocol_path.read_text())
assert digest_file(protocol_path) == PROTOCOL_SHA
assert protocol['owner'] == 'PERF-05.nested_identity'
assert analysis['protocol_sha256'] == PROTOCOL_SHA
assert analysis['outcome'] == 'material_attribution_only'
assert analysis['optimization_accepted'] is False
assert len(analysis['common_material_eight_domain_cells']) == 20
assert set(analysis['observed_qualifying_consumers']) == {
    'group_count', 'count_distinct', 'unary_distinct'}
assert len(analysis['overhead_ineligible_cells']) == 7
assert not any('join' in consumer.lower()
               for consumer in analysis['observed_qualifying_consumers'])
assert analysis['scope'] == (
    'Attribution is not improvement, production acceptance or broader PERF-05 closure.')

preflight = json.loads(preflight_analysis_path.read_text())
assert preflight['protocol_sha256'] == PROTOCOL_SHA
assert preflight['outcome'] == 'preflight_semantics_resources_and_observer_validated'
assert preflight['receipt']['workflows'] == 320
assert preflight['receipt']['operations'] == 704
assert preflight['analyzer_sha256'] == analysis['analyzer_sha256']

cohorts = []
for label in ('a', 'b'):
    receipt = json.loads((ROOT / f'nested-attribution-cohort-{label}-760.json').read_text())
    assert receipt['status'] == 'passed' and receipt['process_group_drained'] is True
    measured = next(row for row in analysis['cohorts'] if row['file'].endswith(
        f'measure-{label.upper()}.jsonl'))
    assert measured['workflows'] == 770 and measured['operations'] == 1922
    assert digest_file(Path(measured['file'])) == measured['sha256']
    cohorts.append({'cohort': label.upper(), 'status': receipt['status'],
                    'workflows': measured['workflows'],
                    'operations': measured['operations'],
                    'jsonl': measured['file'], 'sha256': measured['sha256']})

regressions = {}
for kind, count in (('key', 6), ('relational', 38)):
    receipt = json.loads((ROOT / f'nested-attribution-{kind}-regressions-760.json').read_text())
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    regressions[kind] = {'status': receipt['status'], 'tests': count,
                         'receipt': f'evidence/nested-attribution-{kind}-regressions-760.json',
                         'log': f'evidence/nested-attribution-{kind}-regressions-760.log'}
lint = json.loads((ROOT / 'nested-attribution-clippy-fixed-760.json').read_text())
assert lint['status'] == 'passed' and lint['returncode'] == 0
analyzer_tests = json.loads((ROOT / 'nested-attribution-analyzer-tests-760.json').read_text())
assert analyzer_tests['status'] == 'passed'
assert analyzer_tests['analyzer_sha256'] == analysis['analyzer_sha256']

artifact_records = []
for name, expected_sha in (
    ('nested-attribution-preflight-760-artifact.json', PREFLIGHT_TEST_SHA),
    ('nested-attribution-final-760-artifact.json', FINAL_TEST_SHA),
):
    record = json.loads((ROOT / name).read_text())
    binary = Path(record['artifact'])
    assert binary.is_file() and digest_file(binary) == expected_sha == record['artifact_sha256']
    assert binary.stat().st_size == record['bytes']
    artifact_records.append({'artifact_record': f'evidence/{name}',
                             'path': str(binary), 'bytes': record['bytes'],
                             'sha256': expected_sha})

preflight_freeze = verify_freeze(
    ROOT / 'nested-attribution-preflight-760-source-freeze.json', PROTOCOL_SHA)
final_freeze = verify_freeze(
    ROOT / 'nested-attribution-final-760-source-freeze.json', PROTOCOL_SHA)
assert preflight_freeze['head'] == final_freeze['head']
assert (ROOT / 'nested-attribution-preflight-760-tracked.patch').is_file()
assert (ROOT / 'nested-attribution-final-760-tracked.patch').is_file()

# All scope-matched receipts, logs, patches, source freezes, test inventories,
# analyzer validation and failed initial attempts are included by suffix. This
# preserves failures alongside the later fixed and accepted attribution run.
members = {}
allowed_suffixes = {'.json', '.log', '.patch', '.txt'}
root_records = sorted(
    p for p in ROOT.glob('nested-attribution*760*')
    if p.is_file() and not p.is_symlink()
    and p.suffix.lower() in allowed_suffixes)
assert len(root_records) >= 35
for path in root_records:
    add_file(members, 'evidence/' + path.name, path)
add_file(members, 'evidence/nested-key-attribution-protocol-759.json', protocol_path)

# Preserve raw A2 preflight/A/B measurement records and every witness JSON from
# both generations. The failed A1 fixtures and full A2 fixtures are inventoried
# below, not copied into the portable packet.
data_dirs = [ROOT / 'nested-key-attribution-760-a1', ROOT / 'nested-key-attribution-760-a2']
assert all(p.is_dir() and not p.is_symlink() for p in data_dirs)
witness_counts = {}
for directory in data_dirs:
    witnesses = sorted((directory / 'witnesses').glob('*.json'))
    assert witnesses
    witness_counts[directory.name] = len(witnesses)
    for path in witnesses:
        add_file(members, str(Path('evidence') / path.relative_to(ROOT)), path)
a2 = ROOT / 'nested-key-attribution-760-a2'
for name in ('fixtures.json', 'preflight-preflight.jsonl', 'measure-A.jsonl', 'measure-B.jsonl'):
    add_file(members, str(Path('evidence') / (a2 / name).relative_to(ROOT)), a2 / name)
assert witness_counts == {'nested-key-attribution-760-a1': 3,
                          'nested-key-attribution-760-a2': 95}
fixture_manifest = json.loads((a2 / 'fixtures.json').read_text())
assert len(fixture_manifest) == 48
for row in fixture_manifest:
    fixture_path = Path(row['path'])
    assert fixture_path.is_relative_to(a2 / 'fixtures')
    assert fixture_path.is_file() and fixture_path.stat().st_size == row['length']
    assert digest_file(fixture_path) == row['sha256']

# Include both source-freeze extra-source trees because they contain the exact
# observed code and test source, in addition to each tracked patch.
extra_dirs = [ROOT / 'nested-attribution-preflight-760-extra-sources',
              ROOT / 'nested-attribution-final-760-extra-sources']
for directory in extra_dirs:
    assert directory.is_dir() and not directory.is_symlink()
    for path in sorted(directory.rglob('*')):
        if not path.is_file():
            continue
        assert not path.is_symlink()
        add_file(members, str(Path('sources') / path.relative_to(ROOT)), path)

required_tools = {
    'nested_attribution_driver_760.py',
    'analyze_nested_attribution_760.py',
    'analyze_nested_attribution_before_empty_fix_760.py',
    'test_nested_attribution_analyzer_760.py',
    'run_nested_cohorts_760.py',
    'run_guarded_observed_757.py',
    'package_nested_attribution_760.py',
}
assert all((ROOT / name).is_file() for name in required_tools)
for name in sorted(required_tools):
    add_file(members, 'tools/' + name, ROOT / name)

# Compact supervision/import closure for the unchanged 757 guard. Keep the
# pinned supervisor bytes and the host-snapshot/query helpers it imports.
repo_scripts = REPO / 'scripts'
external_tools = {
    'tools/local_uat_storage.py': repo_scripts / 'local_uat_storage.py',
    'tools/run_clickbench_paired_query_uat.py': repo_scripts / 'run_clickbench_paired_query_uat.py',
    'tools/run_clickbench_query_uat.py': repo_scripts / 'run_clickbench_query_uat.py',
    'tools/native_workflow_protocol.py': repo_scripts / 'native_workflow_protocol.py',
    'tools/query_timing_report.py': repo_scripts / 'query_timing_report.py',
    'tools/clickbench_reference_packet.py': repo_scripts / 'clickbench_reference_packet.py',
    'tools/release_validation_guard.py':
        Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'),
    'tools/bounded_build_process_resume_20260912.py':
        Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py'),
}
for archive_name, source_path in external_tools.items():
    add_file(members, archive_name, source_path)
assert digest_file(external_tools['tools/bounded_build_process_resume_20260912.py']) == SUPERVISOR_SHA

# Inventory every excluded fixture payload, both copied test executables, and
# every compiler-artifact path reported by this investigation's Cargo logs.
# Only paths directly referenced by the scoped build logs are enumerated; no
# Cargo output directory is traversed or copied.
omitted = []
omitted_state = {}


def record_omission(path, category, reproduction):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), f'missing omitted artifact: {path}'
    row = {'path': str(path), 'bytes': path.stat().st_size,
           'sha256': digest_file(path), 'copied': False,
           'category': category, 'source_reproduction': reproduction}
    omitted.append(row)
    omitted_state[str(path)] = (row['bytes'], row['sha256'])
    return row


artifact_for_root = {
    'nested-key-attribution-760-a1':
        'evidence/nested-attribution-preflight-760-artifact.json',
    'nested-key-attribution-760-a2':
        'evidence/nested-attribution-final-760-artifact.json',
}
fixture_omissions = []
for directory in data_dirs:
    fixtures = sorted((directory / 'fixtures').glob('*.vortex'))
    assert fixtures
    for path in fixtures:
        fixture_omissions.append(record_omission(
            path, 'vortex_fixture_payload',
            {'driver': 'tools/nested_attribution_driver_760.py',
             'fixture_receipt': ('evidence/nested-attribution-fixtures-760.json'
                                 if directory.name.endswith('-a1') else
                                 'evidence/nested-attribution-fixtures-fixed-760.json'),
             'source_freeze': ('evidence/nested-attribution-preflight-760-source-freeze.json'
                               if directory.name.endswith('-a1') else
                               'evidence/nested-attribution-final-760-source-freeze.json'),
             'artifact_record': artifact_for_root[directory.name],
             'mode': 'fixtures', 'data_directory': directory.name}))

for record_path in (ROOT / 'nested-attribution-preflight-760-test',
                    ROOT / 'nested-attribution-final-760-test'):
    record = json.loads((ROOT / ('nested-attribution-preflight-760-artifact.json'
                                 if 'preflight' in record_path.name else
                                 'nested-attribution-final-760-artifact.json')).read_text())
    binary = Path(record['artifact'])
    assert binary == record_path
    record_omission(binary, 'copied_test_executable', {
        'artifact_record': ('evidence/nested-attribution-preflight-760-artifact.json'
                            if 'preflight' in binary.name else
                            'evidence/nested-attribution-final-760-artifact.json'),
        'build_receipt': 'evidence/' + record['build'] + '.json',
        'build_log': 'evidence/' + record['build'] + '.log',
        'source_freeze': 'evidence/' + Path(record['source_freeze']).name,
        'test_inventory': 'evidence/' + binary.name + '-inventory.txt',
        'reproduction': 'cargo test --release --offline --locked -p shardloom-vortex --features release-user-surfaces,universal-format-io,upstream-vortex,vortex-encoded-read-executor,vortex-encoded-read-spike,vortex-file-io,vortex-local-primitives,vortex-write --lib --no-run'} )

cargo_logs = sorted(p for p in ROOT.glob('nested-attribution*760.log') if p.is_file())
cargo_outputs = {}
for log_path in cargo_logs:
    for line in log_path.open(errors='replace'):
        if not line.startswith('{'):
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get('reason') != 'compiler-artifact':
            continue
        targets = list(event.get('filenames', []))
        if event.get('executable'):
            targets.append(event['executable'])
        for target in targets:
            resolved = Path(target)
            assert resolved.is_absolute() and str(resolved).startswith(
                '/Users/dylan/.cache/shardloom/cargo-target/'), resolved
            cargo_outputs.setdefault(str(resolved), set()).add(log_path.name)
assert cargo_outputs
cargo_output_inventory = []
for target, log_names in sorted(cargo_outputs.items()):
    row = record_omission(Path(target), 'cargo_compiler_output', {
        'compiler_artifact_logs': ['evidence/' + name for name in sorted(log_names)],
        'build_source_freezes': [
            'evidence/nested-attribution-preflight-760-source-freeze.json',
            'evidence/nested-attribution-final-760-source-freeze.json'],
        'source_reproduction': 'tools/run_nested_cohorts_760.py'} )
    cargo_output_inventory.append(row)

# Inputs are snapshotted before archive creation and rechecked after reopening.
members_before = {}
manifest_members = []
for archive_name, source_path in sorted(members.items()):
    data = source_path.read_bytes()
    row = {'path': archive_name, 'original_path': str(source_path),
           'bytes': len(data), 'sha256': digest(data)}
    members_before[archive_name] = (row['bytes'], row['sha256'])
    manifest_members.append(row)
uncompressed_bytes = sum(row['bytes'] for row in manifest_members)
assert uncompressed_bytes < 128 * MIB
assert any(row['path'].endswith('preflight-preflight.jsonl') for row in manifest_members)
assert any(row['path'].endswith('measure-A.jsonl') for row in manifest_members)
assert any(row['path'].endswith('measure-B.jsonl') for row in manifest_members)
assert sum(1 for row in manifest_members if '/witnesses/' in row['path']) == 98
assert all(row['path'].endswith('.vortex') for row in fixture_omissions)

require_local_path(DEST, Path.home(), sys.platform)
check_budgets(ROOT, DEST, ROOT / 'logs', min_free_bytes=12 * GIB,
              reserve_bytes=128 * MIB, max_workspace_bytes=100 * GIB,
              max_log_bytes=192 * MIB)
assert not DEST.exists(), f'unique packet destination required: {DEST}'
DEST.mkdir()
archive = DEST / (NAME + '.tar.xz')
with tarfile.open(archive, mode='w:xz', format=tarfile.PAX_FORMAT, preset=6) as output:
    for row in manifest_members:
        data = members[row['path']].read_bytes()
        assert len(data) == row['bytes'] and digest(data) == row['sha256']
        info = tarfile.TarInfo(row['path'])
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        output.addfile(info, io.BytesIO(data))

with tarfile.open(archive, 'r:xz') as source:
    assert source.getnames() == [row['path'] for row in manifest_members]
    for row in manifest_members:
        data = source.extractfile(row['path']).read()
        assert len(data) == row['bytes'] and digest(data) == row['sha256']

for archive_name, source_path in members.items():
    data = source_path.read_bytes()
    assert (len(data), digest(data)) == members_before[archive_name], source_path
for path_text, expected in omitted_state.items():
    path = Path(path_text)
    assert (path.stat().st_size, digest_file(path)) == expected, path

manifest_data = {'schema_version': 'shardloom.evidence_member_manifest.v1',
                 'all_members_reopened': True, 'members': manifest_members}
manifest_path = DEST / (NAME + '.manifest.json.xz')
manifest_path.write_bytes(lzma.compress(encode(manifest_data), preset=6))
assert json.loads(lzma.decompress(manifest_path.read_bytes())) == manifest_data

index = {
    'schema_version': 'shardloom.nested_key_attribution_packet.v1',
    'scope': 'completed nested-key ATTRIBUTION only; not candidate acceptance or PERF-05 closure',
    'owner': 'PERF-05.nested_identity',
    'outcome': 'material_attribution_only',
    'optimization_accepted': False,
    'candidate_implemented': False,
    'identity_candidate_admitted_for_design': True,
    'nested_key_attribution_substep_complete': True,
    'broader_owner_substep_remains_open': True,
    'protocol': {'path': 'evidence/nested-key-attribution-protocol-759.json',
                 'sha256': PROTOCOL_SHA},
    'preflight': {'workflows': 320, 'operations': 704,
                  'outcome': preflight['outcome']},
    'cohorts': cohorts,
    'common_material_eight_domain_cells': 20,
    'qualifying_consumers': ['group_count', 'count_distinct', 'unary_distinct'],
    'joins_qualified': False,
    'overhead_exclusions': analysis['overhead_ineligible_cells'],
    'overhead_exclusion_count': len(analysis['overhead_ineligible_cells']),
    'native_regressions': regressions,
    'strict_native_lint': {'status': lint['status'],
                           'receipt': 'evidence/nested-attribution-clippy-fixed-760.json',
                           'log': 'evidence/nested-attribution-clippy-fixed-760.log'},
    'analyzer_validation': {'status': analyzer_tests['status'],
                            'analyzer_sha256': analyzer_tests['analyzer_sha256'],
                            'receipt': 'evidence/nested-attribution-analyzer-tests-760.json'},
    'preflight_test_sha256': PREFLIGHT_TEST_SHA,
    'final_test_sha256': FINAL_TEST_SHA,
    'excluded_compiled_test_artifacts': artifact_records,
    'excluded_vortex_fixtures': fixture_omissions,
    'excluded_cargo_outputs': cargo_output_inventory,
    'excluded_artifact_count': len(omitted),
    'excluded_artifact_inventory': omitted,
    'witness_counts': witness_counts,
    'raw_a2_jsonl_files': [
        'evidence/nested-key-attribution-760-a2/preflight-preflight.jsonl',
        'evidence/nested-key-attribution-760-a2/measure-A.jsonl',
        'evidence/nested-key-attribution-760-a2/measure-B.jsonl'],
    'failed_initial_attempt_evidence_preserved': True,
    'binary_and_fixture_payloads_copied': False,
    'member_count': len(manifest_members),
    'uncompressed_bytes': uncompressed_bytes,
    'all_members_reopened': True,
    'archive': {'file': archive.name, 'bytes': archive.stat().st_size,
                'sha256': digest_file(archive)},
    'manifest': {'file': manifest_path.name, 'bytes': manifest_path.stat().st_size,
                 'sha256': digest_file(manifest_path)},
}
index_path = DEST / (NAME + '.json')
index_path.write_bytes(encode(index))
check_budgets(ROOT, DEST, ROOT / 'logs', min_free_bytes=12 * GIB,
              reserve_bytes=0, max_workspace_bytes=100 * GIB,
              max_log_bytes=192 * MIB)
print(json.dumps({'status': 'passed', 'members': len(manifest_members),
                  'uncompressed_bytes': uncompressed_bytes,
                  'archive_bytes': index['archive']['bytes'],
                  'manifest_bytes': index['manifest']['bytes'],
                  'excluded_artifacts': len(omitted),
                  'cargo_outputs': len(cargo_output_inventory),
                  'vortex_fixtures': len(fixture_omissions),
                  'all_members_reopened': True, 'output': str(index_path)}))
