"""Reject corrupted evidence without rerunning or modifying native measurements."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

OUT=Path(__file__).resolve().parent
path=OUT/'analyze_nested_attribution_760.py'
spec=importlib.util.spec_from_file_location('analysis',path)
a=importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
root=OUT/'nested-key-attribution-760-a2'
records=[json.loads(line) for line in (root/'preflight-preflight.jsonl').read_text().splitlines()]
original=records[1]
assert original['profile']=='enabled'
cell=next(a.specs())
a.validate_record(original,cell,'enabled',0,False,'preflight',a.Witnesses(root))

def set_path(value,keys,replacement):
    for key in keys[:-1]: value=value[key]
    value[keys[-1]]=replacement

cases=[
    ('wrong_actual_values',['operations',0,'actual_rows_witness'],'0'*64),
    ('wrong_expected_values',['expected_rows_witness'],'0'*64),
    ('wrong_schema',['operations',0,'actual_schema_witness'],'0'*64),
    ('remaining_reservation',['reserved_after_cleanup'],1),
    ('overlapping_roots',['observation','maximum_simultaneous_roots'],2),
    ('undrained_root',['observation','active_roots_after_drain'],1),
    ('wrong_call_count',['completed_executions'],2),
    ('wrong_sample',['sample'],1),
    ('fallback',['operations',0,'native_io_certificate','fallback_attempted'],True),
    ('uncertified',['operations',0,'native_io_certificate','certified'],False),
    ('no_construction_observation',['observation','stages','key_owner_construction','root_calls'],0),
    ('double_counted_durations',['observation','stages','nested_hash','nanoseconds'],original['complete_workflow_ns']*2),
    ('incomplete_workflow_clock',['complete_workflow_ns'],1),
]
passed=[]
for name,keys,replacement in cases:
    bad=copy.deepcopy(original)
    set_path(bad,keys,replacement)
    try: a.validate_record(bad,cell,'enabled',0,False,'preflight',a.Witnesses(root))
    except (AssertionError,KeyError): passed.append(name)
    else: raise AssertionError(f'corrupt case accepted: {name}')
a.self_test()
result={'status':'passed','corruption_cases_rejected':passed,'frozen_gate_boundary_tests':'passed',
    'positive_record':'preflight-preflight.jsonl record 1 (zero-based)',
    'analyzer_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
    'test_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
with (OUT/'nested-attribution-analyzer-tests-760.json').open('x') as stream:
    json.dump(result,stream,indent=2)
    stream.write('\n')
print(json.dumps(result))
