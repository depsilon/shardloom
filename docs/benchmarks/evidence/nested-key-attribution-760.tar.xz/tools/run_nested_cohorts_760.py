"""Freeze all validated inputs, finish both fresh cohorts, then apply the original gate."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

OUT=Path(__file__).resolve().parent
DATA=OUT/'nested-key-attribution-760-a2'
DRIVER=OUT/'nested_attribution_driver_760.py'
ANALYZER=OUT/'analyze_nested_attribution_760.py'
LABEL='nested-attribution-final-760'

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def run(command):
    subprocess.run(command,check=True)

run([sys.executable,str(DRIVER),'verify','--label',LABEL])
receipts=['nested-attribution-final-build-760','nested-attribution-fixtures-fixed-760',
    'nested-attribution-preflight-run-760','nested-attribution-key-regressions-760',
    'nested-attribution-relational-regressions-760','nested-attribution-clippy-fixed-760']
for name in receipts:
    value=json.loads((OUT/f'{name}.json').read_text())
    assert value['status']=='passed' and value['process_group_drained']
preflight=json.loads((OUT/'nested-attribution-preflight-analysis-fixed-760.json').read_text())
assert preflight['outcome']=='preflight_semantics_resources_and_observer_validated'
assert preflight['receipt']['workflows']==320 and preflight['receipt']['operations']==704
assert preflight['analyzer_sha256']==sha(ANALYZER)
tests=json.loads((OUT/'nested-attribution-analyzer-tests-760.json').read_text())
assert tests['status']=='passed' and tests['analyzer_sha256']==sha(ANALYZER)
members=[OUT/f'{name}.json' for name in receipts]+[
    OUT/f'{LABEL}-source-freeze.json',OUT/f'{LABEL}-artifact.json',
    OUT/'nested-key-attribution-protocol-759.json',DATA/'fixtures.json',
    OUT/'nested-attribution-preflight-analysis-fixed-760.json',
    OUT/'nested-attribution-analyzer-tests-760.json',DRIVER,ANALYZER,Path(__file__),
    OUT/'test_nested_attribution_analyzer_760.py',OUT/'run_guarded_observed_757.py']
freeze={'schema_version':'nested_key_attribution_measurement_freeze_v1',
    'members':[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in members],
    'cohorts':['A','B'],'workflows_per_cohort':770,'operations_per_cohort':1922,
    'correctness_and_empty_controls':'320 complete workflows / 704 operations; independent oracle passed',
    'regressions':'6 native key and 38 relational nested tests passed',
    'decision_rule':'unchanged protocol 759; no comparative inspection before both cohorts finish'}
with (OUT/'nested-attribution-measurement-freeze-760.json').open('x') as stream:
    json.dump(freeze,stream,indent=2)
    stream.write('\n')
for cohort in ['A','B']:
    for member in freeze['members']: assert sha(member['path'])==member['sha256']
    run([sys.executable,str(DRIVER),'run','--label',LABEL,'--name',f'nested-attribution-cohort-{cohort.lower()}-760',
        '--mode','measure','--cohort',cohort,'--data',DATA.name])
for member in freeze['members']: assert sha(member['path'])==member['sha256']
run([sys.executable,str(ANALYZER),'--root',str(DATA),'--output',str(OUT/'nested-attribution-analysis-760.json')])
run([sys.executable,str(DRIVER),'verify','--label',LABEL])
