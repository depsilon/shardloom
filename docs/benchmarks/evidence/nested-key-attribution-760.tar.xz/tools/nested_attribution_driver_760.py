"""Freeze and supervise one unchanged nested-key attribution artifact."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PROTOCOL = OUT / 'nested-key-attribution-protocol-759.json'
PROTOCOL_SHA = 'dcab70000481b36a88db907139805762bce91339a268a52007adaa826133febc'
GUARD = OUT / 'run_guarded_observed_757.py'
SELECTOR = 'local_primitives::prepared_relational::tests::nested_key_cost_tests::native_nested_key_attribution_screen'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def paths():
    names = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=REPO, text=True).splitlines()
    return sorted(p for p in set(names) if p.endswith('.rs') or Path(p).name in ('Cargo.toml', 'Cargo.toml.orig', 'Cargo.lock'))

def verify_sources(freeze):
    assert sha(PROTOCOL) == PROTOCOL_SHA
    assert paths() == [s['path'] for s in freeze['sources']], 'source inventory changed'
    for source in freeze['sources']:
        path = REPO / source['path']
        assert path.stat().st_size == source['bytes'] and sha(path) == source['sha256'], source['path']

def verify_fixtures(data):
    manifest = data / 'fixtures.json'
    for member in json.loads(manifest.read_text()):
        path = Path(member['path'])
        assert path.is_relative_to(data / 'fixtures')
        assert path.stat().st_size == member['length'] and sha(path) == member['sha256']
    return sha(manifest)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['freeze', 'bind', 'run', 'verify'])
    parser.add_argument('--label', required=True)
    parser.add_argument('--build')
    parser.add_argument('--name')
    parser.add_argument('--mode', choices=['fixtures', 'preflight', 'measure'])
    parser.add_argument('--cohort', default='preflight')
    parser.add_argument('--data', default='nested-key-attribution-760-a1')
    args = parser.parse_args()
    assert args.label.replace('-', '').isalnum()
    freeze_path = OUT / f'{args.label}-source-freeze.json'
    artifact_path = OUT / f'{args.label}-artifact.json'
    assert sha(PROTOCOL) == PROTOCOL_SHA
    if args.action == 'freeze':
        sources = [{'path':p, 'bytes':(REPO/p).stat().st_size, 'sha256':sha(REPO/p)} for p in paths()]
        patch = OUT / f'{args.label}-tracked.patch'
        patch.write_bytes(subprocess.check_output(['git', 'diff', '--binary'], cwd=REPO))
        extras = subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=REPO,text=True).splitlines()
        for p in extras:
            target = OUT / f'{args.label}-extra-sources' / p
            target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(REPO/p,target)
        save(freeze_path, {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
            'protocol_sha256':PROTOCOL_SHA,'driver_sha256':sha(__file__),'sources':sources,'patch_sha256':sha(patch),
            'extra_sources':extras})
        print(json.dumps({'source_freeze':str(freeze_path),'sha256':sha(freeze_path),'count':len(sources)}))
        return
    freeze = json.loads(freeze_path.read_text())
    verify_sources(freeze)
    if args.action == 'bind':
        build = json.loads((OUT/f'{args.build}.json').read_text())
        assert build['status']=='passed' and build['process_group_drained']
        artifacts=[]
        for line in (OUT/f'{args.build}.log').read_text().splitlines():
            if not line.startswith('{'): continue
            item=json.loads(line)
            if item.get('reason')=='compiler-artifact' and item.get('target',{}).get('name')=='shardloom_vortex' and item.get('profile',{}).get('test'):
                artifacts.append(item)
        assert len(artifacts)==1 and artifacts[0]['executable'] and not artifacts[0]['fresh']
        source=Path(artifacts[0]['executable'])
        binary=OUT/f'{args.label}-test'
        assert not binary.exists()
        shutil.copy2(source,binary)
        assert sha(binary)==sha(source)
        inventory=subprocess.check_output([str(binary),'--list'],text=True)
        assert f'{SELECTOR}: test' in inventory, SELECTOR
        (OUT/f'{args.label}-test-inventory.txt').write_text(inventory)
        save(artifact_path,{'artifact':str(binary),'artifact_sha256':sha(binary),'bytes':binary.stat().st_size,
            'source_freeze':str(freeze_path),'source_freeze_sha256':sha(freeze_path),'build':args.build,
            'build_receipt_sha256':sha(OUT/f'{args.build}.json'),'compiler_artifact':artifacts[0]})
        print(json.dumps({'artifact':str(binary),'sha256':sha(binary)}))
        return
    artifact=json.loads(artifact_path.read_text())
    binary=Path(artifact['artifact'])
    assert sha(binary)==artifact['artifact_sha256'] and sha(freeze_path)==artifact['source_freeze_sha256']
    if args.action=='verify':
        print(json.dumps({'sources_unchanged':True,'artifact_unchanged':True}))
        return
    assert args.name and args.mode
    data=OUT/args.data
    assert data.parent==OUT and data.name.startswith('nested-key-attribution-')
    data.mkdir(exist_ok=True)
    fixture_identity=None if args.mode=='fixtures' else verify_fixtures(data)
    command=[sys.executable,str(GUARD),'--name',args.name,'--timeout','1800','--','/usr/bin/env',
        f'SHARDLOOM_NESTED_KEY_ROOT={data}',f'SHARDLOOM_NESTED_KEY_MODE={args.mode}',f'SHARDLOOM_NESTED_KEY_COHORT={args.cohort}',
        str(binary),SELECTOR,'--exact','--ignored','--nocapture','--test-threads=1']
    record={'mode':args.mode,'cohort':args.cohort,'artifact_sha256':sha(binary),'source_freeze_sha256':sha(freeze_path),
        'protocol_sha256':PROTOCOL_SHA,'driver_sha256':sha(__file__),'guard_sha256':sha(GUARD),'command':command,
        'fixture_manifest_sha256_before':fixture_identity}
    try:
        code=subprocess.call(command,cwd=REPO)
        record['returncode']=code
        verify_sources(freeze)
        assert sha(binary)==artifact['artifact_sha256']
        record['sources_and_artifact_unchanged']=True
        if fixture_identity is not None:
            record['fixture_manifest_sha256_after']=verify_fixtures(data)
            assert fixture_identity==record['fixture_manifest_sha256_after']
        if args.mode!='fixtures':
            output=data/f'{args.mode}-{args.cohort}.jsonl'
            if output.exists(): record.update(output=str(output),output_sha256=sha(output),output_bytes=output.stat().st_size)
    finally:
        save(OUT/f'{args.name}-link.json',record)
    raise SystemExit(code)

if __name__=='__main__': main()
