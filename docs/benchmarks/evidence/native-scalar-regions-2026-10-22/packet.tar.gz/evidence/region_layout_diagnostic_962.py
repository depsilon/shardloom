"""Read only bounded footer metadata to diagnose scalar-region admission.

Original diagnostic parser, grounded in the pinned Vortex 0.85.0 FlatBuffers
schemas. This does not deserialize data arrays or execute a native query.
"""
import collections
import hashlib
import json
from pathlib import Path
import struct

N = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022')
protocol = json.loads((N / 'region-scalar-protocol-959.json').read_text())
path = Path(protocol['full43_input']['file']['path'])


def generation():
    s = path.stat()
    return dict(device=s.st_dev, inode=s.st_ino, size_bytes=s.st_size,
                mtime_ns=s.st_mtime_ns, ctime_ns=s.st_ctime_ns)


class Buffer:
    def __init__(self, raw):
        self.raw = raw

    def number(self, code, offset):
        assert 0 <= offset <= len(self.raw) - struct.calcsize('<' + code)
        return struct.unpack_from('<' + code, self.raw, offset)[0]

    def target(self, location):
        result = location + self.number('I', location)
        assert location < result < len(self.raw)
        return result

    def field(self, table, index):
        vtable = table - self.number('i', table)
        length = self.number('H', vtable)
        entry = 4 + 2 * index
        if entry >= length:
            return None
        relative = self.number('H', vtable + entry)
        return table + relative if relative else None

    def scalar(self, table, index, code):
        field = self.field(table, index)
        return self.number(code, field) if field is not None else 0

    def table(self, parent, index):
        field = self.field(parent, index)
        assert field is not None
        return self.target(field)

    def tables(self, parent, index):
        field = self.field(parent, index)
        if field is None:
            return []
        vector = self.target(field)
        length = self.number('I', vector)
        assert length <= 1_000_000 and vector + 4 + 4 * length <= len(self.raw)
        return [self.target(vector + 4 + 4 * i) for i in range(length)]

    def string(self, parent, index):
        start = self.table(parent, index)
        length = self.number('I', start)
        assert start + 4 + length < len(self.raw) and self.raw[start + 4 + length] == 0
        return self.raw[start + 4:start + 4 + length].decode()


before = generation()
assert before == protocol['full43_input']['generation']
reads = []
with path.open('rb') as stream:
    def bounded_read(offset, length, label):
        assert 0 <= offset <= before['size_bytes'] - length
        assert 0 < length <= 64 << 20
        stream.seek(offset)
        raw = stream.read(length)
        assert len(raw) == length
        reads.append(dict(label=label, offset=offset, bytes=length, sha256=hashlib.sha256(raw).hexdigest()))
        return raw

    end = bounded_read(before['size_bytes'] - 8, 8, 'end_marker')
    version, ps_length = struct.unpack('<HH', end[:4])
    assert version == 1 and end[4:] == b'VTXF'
    postscript = Buffer(bounded_read(before['size_bytes'] - 8 - ps_length, ps_length, 'postscript'))
    ps_root = postscript.number('I', 0)
    def segment(index, label):
        locator = postscript.table(ps_root, index)
        assert postscript.field(locator, 3) is None and postscript.field(locator, 4) is None
        return Buffer(bounded_read(postscript.scalar(locator, 0, 'Q'),
                                   postscript.scalar(locator, 1, 'I'), label))
    layout = segment(1, 'layout_flatbuffer')
    footer = segment(3, 'footer_registry_flatbuffer')
    encodings = [footer.string(item, 0) for item in footer.tables(footer.number('I', 0), 1)]
    root = layout.number('I', 0)
    stack = [(root, ())]
    inventory = collections.Counter()
    first_decline = None
    visits = 0
    maximum_depth = 0
    known = {'vortex.flat', 'vortex.chunked', 'vortex.struct', 'vortex.zoned', 'vortex.dict'}
    while stack:
        node, ancestry = stack.pop()
        visits += 1
        assert visits <= 1_000_000
        code = layout.scalar(node, 0, 'H')
        assert code < len(encodings)
        encoding = encodings[code]
        depth = len(ancestry) + 1
        maximum_depth = max(maximum_depth, depth)
        inventory[encoding] += 1
        children = layout.tables(node, 3)
        reason = ('unknown_layout' if encoding not in known else
                  'node_bound' if visits > 262_144 else
                  'depth_bound' if depth > 64 else
                  'child_bound' if len(children) > 262_144 else None)
        if reason and first_decline is None:
            first_decline = dict(reason=reason, physical_visit=visits, depth=depth,
                                 encoding=encoding, ancestry=list(ancestry), children=len(children))
        stack.extend((child, ancestry + (encoding,)) for child in reversed(children))
assert generation() == before
result = dict(status='passed', scope='Read-only physical footer tree; source-schema offsets from pinned 0.85.0; no data segment reads or native query execution.',
    input=protocol['full43_input']['file'], generation=before, reads=reads,
    row_count=layout.scalar(root, 1, 'Q'), root_encoding=encodings[layout.scalar(root, 0, 'H')],
    encoding_registry=encodings, physical_layout_nodes=visits, maximum_depth=maximum_depth,
    encoding_counts=dict(inventory), first_physical_admission_rejection=first_decline,
    note='Physical children are not asserted identical to every logical slot. An encoding outside the allowlist is sufficient to explain rejection when visited by the complete footer walk.',
    native_query_calls=0, array_payload_bytes_read=0, input_generation_unchanged=True)
with (N / 'region-layout-diagnostic-962.json').open('x') as output:
    json.dump(result, output, indent=2)
    output.write('\n')
print(json.dumps(result, indent=2))
