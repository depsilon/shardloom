#!/usr/bin/env python3
"""Prospective region comparison: unchanged paired Full43 and held-out calls.

This program never builds, changes source, generates input, or repeats a failed
stage. All identities and thresholds come from the separately frozen protocol.
"""
import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
N = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022')
PYTHON = '/opt/homebrew/opt/python@3.13/bin/python3.13'
sys.path[:0] = [str(W / 'scripts'), str(W / 'python/src')]
from native_workflow_protocol import extract_result, public_workflow_command, report_fields, strict_json
from query_timing_report import query_phase_timings
from run_clickbench_paired_query_uat import generation, role_order
from local_uat_storage import GIB, MIB, accounted_bytes, require_local_path


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read(path):
    return strict_json(Path(path).read_text())


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)


def check_identity(expected):
    assert identity(expected['path']) == expected, expected['path']


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def exact_values(actual, expected):
    # The held-out arithmetic is exactly prescribed, including the unchanged
    # fused floating control. Do not import Full43's general float tolerance.
    if type(actual) is not type(expected):
        return False
    if isinstance(actual, dict):
        return actual.keys() == expected.keys() and all(exact_values(actual[k], expected[k]) for k in actual)
    if isinstance(actual, list):
        return len(actual) == len(expected) and all(exact_values(a, b) for a, b in zip(actual, expected))
    if isinstance(actual, float):
        return math.isfinite(actual) and actual.hex() == expected.hex()
    return actual == expected


def score_pair(baseline, candidate, multiplier, allowance):
    return dict(baseline_engine_seconds=baseline['engine_execution_seconds'],
                candidate_engine_seconds=candidate['engine_execution_seconds'],
                timing_passed=candidate['engine_execution_seconds'] <= baseline['engine_execution_seconds'] * multiplier + allowance,
                rss_passed=candidate['native_peak_rss_bytes'] <= baseline['native_peak_rss_bytes'] * 1.25 + 128 * MIB)


def check_activation(case, role, fields):
    key = 'local_primitive_aggregate_source_region_execution'
    active = fields.get(key) in (True, 'true')
    if role == 'control':
        assert not active
        return
    if case['role'] == 'target':
        assert active, 'required original-region consumer did not activate'
    if case['id'] in ('c_small', 'c_metadata', 'c_large_integer', 'c_floating', 'c_dictionary', 'c_wide_text'):
        assert not active, 'excluded control started region execution'
    if active:
        prefix = 'local_primitive_aggregate_source_region_'
        assert fields[prefix + 'coverage_complete'] in (True, 'true')
        assert int(fields[prefix + 'outstanding']) == 0
        assert int(fields['local_primitive_aggregate_provider_background_workers']) == 0
        assert int(fields[prefix + 'completed']) == int(fields[prefix + 'submitted'])


def score_stage(records, kind, cases):
    expected_ids = list(range(1, 44)) if kind == 'full43' else [x['id'] for x in cases]
    assert len(records) == 2 * len(expected_ids)
    lookup = {(r['case'], r['role']): r for r in records}
    assert len(lookup) == len(records)
    assert set(lookup) == {(case, role) for case in expected_ids for role in ('control', 'candidate')}
    assert all(r['passed'] and r['engine_timing_reported'] for r in records)
    target_ids = expected_ids if kind == 'full43' else [x['id'] for x in cases if x['role'] == 'target']
    sums = {role: sum(lookup[(case, role)]['engine_execution_seconds'] for case in target_ids)
            for role in ('control', 'candidate')}
    result = dict(kind=kind, raw_calls=len(records), target_engine_sums=sums,
                  aggregate_passed=sums['candidate'] <= sums['control'] * (0.98 if kind == 'full43' else 0.80), pairs=[])
    for case in expected_ids:
        multiplier, allowance = (1.10, 0.020) if kind == 'full43' else ((0.95, 0.002) if case in target_ids else (1.05, 0.002))
        result['pairs'].append(dict(case=case, **score_pair(lookup[(case, 'control')], lookup[(case, 'candidate')], multiplier, allowance)))
    result['passed'] = result['aggregate_passed'] and all(p['timing_passed'] and p['rss_passed'] for p in result['pairs'])
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--protocol', type=Path, required=True)
    parser.add_argument('--runtime', type=Path, required=True)
    parser.add_argument('--stage', choices=['full43-A', 'full43-B', 'heldout-A', 'heldout-B'], required=True)
    args = parser.parse_args()
    protocol = read(args.protocol)
    assert protocol['status'] == 'frozen_before_runtime_implementation'
    for item in protocol['harness_sources']:
        check_identity(item)
    amendment_path = N / 'region-collection-amendment-963.json'
    amendment = read(amendment_path)
    assert amendment['protocol'] == identity(args.protocol)
    assert amendment['original_driver'] in protocol['harness_sources']
    check_identity(amendment['original_driver'])
    assert amendment['corrected_driver'] == identity(__file__)
    check_identity(amendment['failed_launch'])
    failed = read(amendment['failed_launch']['path'])
    assert failed['status'] == 'failed' and failed['records'] == []
    assert failed['active_call']['returncode'] == 2 and failed['active_call']['process_group_drained']
    assert amendment['native_query_calls_in_failed_launch'] == 0
    runtime = read(args.runtime)
    assert runtime['status'] == 'passed'
    check_identity(runtime['build'])
    build = read(runtime['build']['path'])
    assert build['status'] == 'passed' and build['process_group_drained']
    assert build['source_before'] == build['source_after']
    assert build['target'] == str(N / 'release-target-947')
    assert build['command'] == protocol['candidate_build_command']
    assert runtime['executable']['sha256'] != protocol['baseline']['executable']['sha256']
    binaries = dict(control=protocol['baseline']['executable'], candidate=runtime['executable'])
    for binary in binaries.values():
        check_identity(binary)
    def verify_candidate_sources():
        for relative, digest in build['source_after'].items():
            assert identity(W / relative)['sha256'] == digest, relative
    verify_candidate_sources()
    bounded = load_module('region_bounded', protocol['supervisor']['path'])
    guard_module = load_module('region_workload', protocol['workload_guard']['path'])
    work = guard_module.WorkloadGuard()
    kind, cohort = args.stage.split('-')
    fixtures = {r['id']: r for r in protocol['fixtures']}
    selected_inputs = [protocol['full43_input']] if kind == 'full43' else list(fixtures.values())
    for item in selected_inputs:
        assert generation(Path(item['file']['path'])) == item['generation']
        check_identity(item['file'])
        assert generation(Path(item['file']['path'])) == item['generation']
    root = N / ('region-comparison-' + args.stage + '-963')
    require_local_path(root, Path.home(), sys.platform)
    assert not root.exists(), 'preserve every earlier attempt'
    assert shutil.disk_usage(N).free >= 12 * GIB
    assert accounted_bytes(N) + accounted_bytes(Path('/Users/dylan/.cache/shardloom/cargo-target')) <= 100 * GIB
    work.check()
    root.mkdir()
    record = dict(status='prepared', stage=args.stage, protocol=identity(args.protocol),
                  collection_amendment=identity(amendment_path),
                  runtime=identity(args.runtime), binaries=binaries, records=[],
                  cache_policy='Shared uncontrolled OS cache; prehash before this stage; no purge, pacing or repeats.', host_samples=[])
    active = {}
    last_sample = 0.0
    def guard():
        nonlocal last_sample
        work.check(active.get('pid'))
        assert shutil.disk_usage(N).free >= 12 * GIB
        assert accounted_bytes(root) <= 256 * MIB
        for item in selected_inputs:
            assert generation(Path(item['file']['path'])) == item['generation']
        if time.monotonic() - last_sample >= 2:
            processes = subprocess.check_output(['ps', '-axo', 'pid=,ppid=,pgid=,pcpu=,rss=,comm='], text=True, timeout=10)
            rows = []
            for line in processes.splitlines():
                parts = line.strip().split(None, 5)
                if len(parts) == 6 and (int(parts[0]) in work.owned or float(parts[3]) >= 1):
                    rows.append(dict(pid=int(parts[0]), parent=int(parts[1]), group=int(parts[2]), cpu_percent=float(parts[3]), rss_bytes=int(parts[4]) * 1024, executable=Path(parts[5]).name))
            record['host_samples'].append(dict(load_average=list(os.getloadavg()), processes=rows))
            last_sample = time.monotonic()
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(W / 'python/src') + ':' + str(W / 'scripts'))
    lock = root / '.ingest-uat.lock'
    try:
        if kind == 'full43':
            command = [PYTHON, '-B', 'scripts/run_clickbench_paired_query_uat.py',
                '--control-binary', binaries['control']['path'], '--control-commit', protocol['baseline']['source_commit'],
                '--candidate-binary', binaries['candidate']['path'], '--candidate-commit', runtime['source_commit'],
                '--input', protocol['full43_input']['file']['path'], '--uat-root', str(root),
                '--reference-packet', protocol['full43_reference']['path'], '--memory-gb', '24',
                '--max-parallelism', '12', '--repeats', '1', '--max-log-mib', '1024', '--max-run-log-mib', '256']
            if cohort == 'B':
                command.append('--reverse-order')
            active = dict(command=command)
            record['active_call'] = active
            with (root / 'driver.log').open('xb') as output:
                status = bounded.run(command, cwd=W, env=env, output=output, timeout=1800,
                                     evidence=active, guard=guard, max_output_bytes=8 * MIB)
            assert status == 0 and active['process_group_drained']
            summaries = list(root.glob('logs/*/summary.json'))
            assert len(summaries) == 1
            summary = read(summaries[0])
            assert summary['completed_identity_check'] and summary['reference_packet_identity_verified'] and summary['complete_result_validation']
            assert summary['reference_kind'] == 'independent_reference' and summary['selected_query_ids'] == list(range(1, 44))
            assert summary['repeats'] == 1 and summary['reverse_order'] == (cohort == 'B')
            record['summary'] = identity(summaries[0])
            record['records'] = [dict(r, case=r['query']) for r in summary['records']]
        else:
            lock.mkdir()
            reference = read(protocol['heldout_reference']['path'])
            expected = {x['id']: x for x in reference['cases']}
            for index, case in enumerate(protocol['heldout']['cases'], 1):
                policy = case.get('policy', protocol['heldout']['default_policy'])
                for role in role_order(index, 1, cohort == 'B'):
                    name = case['id'] + '-' + role
                    prefix = root / name
                    command = public_workflow_command(binaries[role]['path'], expected[case['id']]['statement'],
                        input_path=fixtures[case['dataset']]['file']['path'], input_format='vortex',
                        memory_gb=policy['memory_gb'], max_parallelism=policy['requested_parallelism'])
                    wrapped = [PYTHON, '-B', str(W / 'scripts/timed_native_command.py'),
                               '--timing', str(prefix) + '.timing.json', '--pid-file', str(prefix) + '.pid',
                               '--shared-process-group', '--', *command]
                    active = dict(case=case['id'], role=role, command=command, passed=False)
                    record['records'].append(active)
                    with Path(str(prefix) + '.stdout.json').open('xb') as output, Path(str(prefix) + '.stderr.txt').open('xb') as errors:
                        status = bounded.run(wrapped, cwd=W, env=env, output=output, error_output=errors,
                            timeout=120, evidence=active, guard=guard, max_output_bytes=8 * MIB)
                    assert status == 0 and active['process_group_drained']
                    timing = read(str(prefix) + '.timing.json')
                    assert timing['returncode'] == 0
                    envelope = read(str(prefix) + '.stdout.json')
                    fields = report_fields(envelope)
                    assert fields.get('fallback_attempted') == 'false' and fields.get('external_engine_invoked') == 'false'
                    actual = extract_result(envelope)
                    assert exact_values(actual, expected[case['id']]['values']), case['id']
                    check_activation(case, role, fields)
                    active.update(query_phase_timings(fields, timing['seconds']))
                    active.update(passed=True, native_peak_rss_bytes=timing['peak_rss_bytes'], actual=actual,
                                  fields=fields, native_timing=timing,
                                  stdout=identity(str(prefix) + '.stdout.json'), stderr=identity(str(prefix) + '.stderr.txt'))
                    print(json.dumps(dict(case=case['id'], role=role, passed=True, engine_execution_seconds=active['engine_execution_seconds'])), flush=True)
            lock.rmdir()
        record['score'] = score_stage(record['records'], kind, protocol['heldout']['cases'])
        record['status'] = 'complete'
        record['retention_gate_passed'] = record['score']['passed']
        # Post-run verification is separate from native execution.
        for item in selected_inputs:
            assert generation(Path(item['file']['path'])) == item['generation']
            check_identity(item['file'])
            assert generation(Path(item['file']['path'])) == item['generation']
        for binary in binaries.values():
            check_identity(binary)
        verify_candidate_sources()
        for item in protocol['harness_sources']:
            check_identity(item)
        assert not lock.exists()
        work.check()
        assert amendment['corrected_driver'] == identity(__file__)
        assert record['collection_amendment'] == identity(amendment_path)
        record['identities_unchanged'] = True
    except BaseException as error:
        record.update(status='failed', failure=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        if kind == 'heldout' and lock.exists() and active.get('process_group_drained', True):
            lock.rmdir()
        save(root / 'receipt.json', record)
    print(json.dumps(dict(stage=args.stage, status=record['status'], retention_gate_passed=record['retention_gate_passed'])), flush=True)


if __name__ == '__main__':
    main()
