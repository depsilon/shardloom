#!/usr/bin/env python3
"""Independent values from the fixed input construction; never run an engine."""
from __future__ import annotations
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022')


def periodic_values(rows, period, value, selected=lambda _: True):
    cycles, tail = divmod(rows, period)
    counts = Counter()
    selected_rows = 0
    for i in range(period):
        weight = cycles + (i < tail)
        if weight and selected(i):
            selected_rows += weight
            item = value(i)
            if item is not None:
                counts[item] += weight
    count = sum(counts.values())
    total = sum(item * weight for item, weight in counts.items())
    return dict(sum_integer=total, count=count, rows=selected_rows,
                min=min(counts, default=None), max=max(counts, default=None))


def scalar(values):
    count = values['count']
    total = float(values['sum_integer'])
    return dict(sx=total if count else None, ax=total / count if count else None,
                nx=values['min'], mx=values['max'], cx=count, n=values['rows'])


def signed(rows):
    x = periodic_values(rows, 2048, lambda i: i - 1024)
    y = periodic_values(rows, 4096, lambda i: (i * 17) % 4096 - 2048)
    result = scalar(x)
    result.update(sy=float(y['sum_integer']), ay=float(y['sum_integer']) / y['count'])
    return [result]


def expected():
    rows = 4_194_304
    result = {}
    result['signed'] = signed(rows)
    result['skewed'] = signed(rows)
    result['small'] = signed(4096)
    x = periodic_values(rows, 65521, lambda i: i)
    y = periodic_values(rows, 257, lambda i: (i * 13) % 257)
    unsigned = scalar(x)
    unsigned.update(sy=float(y['sum_integer']), ay=float(y['sum_integer']) / y['count'])
    result['unsigned'] = [unsigned]
    nullable = periodic_values(rows, 7 * 997 * 5,
        lambda i: None if i % 7 == 0 else (i % 997) - 498,
        lambda i: i % 5 == 2)
    result['nullable'] = [scalar(nullable)]
    large = periodic_values(1_048_576, 1024,
        lambda i: (i - 512) * 18_014_398_509_481_984)
    result['large_integer'] = [scalar(large)]
    # The established fused SUM/AVG route sums each original native batch in
    # order, then adds that partial to the running total in batch order. Every
    # persisted 65536-row chunk is smaller than the unchanged 100000-row split
    # ceiling. This explicitly preserves that existing floating policy.
    float_total = 0.0
    float_partials = []
    for _ in range(16):
        partial = 0.0
        for i in range(65_536):
            partial += (1e16, 1.0, -1e16, 0.1)[i % 4]
        float_partials.append(partial)
        float_total += partial
    result['floating'] = [dict(sx=float_total, ax=float_total / 1_048_576, n=1_048_576)]
    dictionary = periodic_grouped(1_048_576, 257, lambda i: f'key-é-{(i * 17) % 257:03}')
    result['dictionary'] = dictionary
    result['wide_text'] = periodic_grouped(262_144, 257, lambda i: f'{i % 257:03}' + 'x' * 125)
    counts = Counter({-17: 32 * 65_536, -5: 32 * 16_384,
                      7: 32 * 16_384, 29: 32 * 16_384})
    encoded = dict(sum_integer=sum(v * n for v, n in counts.items()),
                   count=sum(counts.values()), rows=rows, min=-17, max=29)
    result['encoded'] = [scalar(encoded)]
    result['metadata'] = [dict(n=rows)]
    assert result['signed'][0]['sx'] == -2_097_152.0
    assert result['signed'][0]['ax'] == -0.5
    assert result['signed'][0]['sy'] == -2_097_152.0
    assert result['large_integer'][0]['sx'] == float(-(1 << 73))
    assert result['large_integer'][0]['nx'] == -(1 << 63)
    assert result['encoded'][0]['cx'] == 3_670_016
    assert result['encoded'][0]['sx'] == -19_398_656.0
    assert float_partials == [0.1] * 16 and float_total.hex() == '0x1.999999999999bp+0'
    assert sum(row['n'] for row in dictionary) == 1_048_576 and len(dictionary) == 257
    assert sum(row['n'] for row in result['wide_text']) == 262_144
    return result


def periodic_grouped(rows, period, key):
    cycles, tail = divmod(rows, period)
    counts = Counter()
    for i in range(period):
        counts[key(i)] += cycles + (i < tail)
    return [dict(k=k, n=n) for k, n in sorted(counts.items()) if n]


def main():
    matrix_path = ROOT / 'region-heldout-draft-957.json'
    matrix = json.loads(matrix_path.read_text())
    values = expected()
    cases = []
    for case in matrix['cases']:
        key = 'metadata' if case['query'] == 'metadata' else case['dataset']
        cases.append(dict(id=case['id'], dataset=case['dataset'],
                          statement=matrix['queries'][case['query']],
                          values=values[key]))
    assert len(cases) == 13 and len({case['id'] for case in cases}) == 13
    output = dict(schema='shardloom.region_scalar_reference.v1',
        reference_kind='independent_construction', engine_invoked=False,
        source=dict(path=str(Path(__file__)),
                    sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),
        input_specification=dict(path=str(matrix_path),
                    sha256=hashlib.sha256(matrix_path.read_bytes()).hexdigest()),
        floating_policy='Ordered IEEE-754 sum within each unchanged original 65536-row batch; ordered addition of the sixteen partials; divide once for AVG. Native fused SUM/AVG semantics; this control is excluded from the candidate.',
        integer_policy='Exact integer weighted totals from input periods; one conversion to f64 and one division for AVG. No baseline answer is used.',
        cases=cases)
    destination = ROOT / 'region-scalar-reference-958.json'
    with destination.open('x') as stream:
        json.dump(output, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write('\n')
    print(json.dumps(dict(status='passed', cases=len(cases), path=str(destination),
                         sha256=hashlib.sha256(destination.read_bytes()).hexdigest())))


if __name__ == '__main__':
    main()
