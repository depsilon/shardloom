"""Archive the completed frozen experiment, with a portable original-path map."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

N = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022')
W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
TARGET = N / 'region-comparison-evidence-962.tar.gz'


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def read(path):
    return json.loads(Path(path).read_text())


assert not TARGET.exists()
assert shutil.disk_usage(N).free >= 12 * (1 << 30)
paths = {}


def add(path, expected=None):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    assert path.stat().st_size <= 32 * (1 << 20)
    observed = identity(path)
    if expected:
        assert observed['sha256'] == expected['sha256']
        assert observed['bytes'] == expected.get('bytes', observed['bytes'])
    if path.is_relative_to(W):
        member = 'repo/' + path.relative_to(W).as_posix()
    elif path.is_relative_to(N):
        member = 'evidence/' + path.relative_to(N).as_posix()
    else:
        member = 'external/' + observed['sha256'][:16] + '/' + path.name
    if str(path) in paths:
        assert paths[str(path)] == dict(original_path=str(path), member=member,
                                       bytes=observed['bytes'], sha256=observed['sha256'])
    paths[str(path)] = dict(original_path=str(path), member=member,
                           bytes=observed['bytes'], sha256=observed['sha256'])
    return observed


protocol_ref = add(N / 'region-scalar-protocol-959.json')
protocol = read(protocol_ref['path'])
assert protocol_ref['sha256'] == '5fdd1589bb3ec01799ba55b2a7f42c759ce84ac39d9a9cba82e1f0d2294507ab'
for entry in protocol['harness_sources'] + protocol['design_sources']:
    add(entry['path'], entry)
for key in ('heldout_reference', 'full43_reference', 'full43_queries'):
    add(protocol[key]['path'], protocol[key])
runtime_ref = add(N / 'native-runtime-region-962.json')
runtime = read(runtime_ref['path'])
assert runtime['status'] == 'passed'
for reference in [runtime['build'], runtime['build_plan'], *runtime['checks']]:
    add(reference['path'], reference)
    log = Path(reference['path']).with_suffix('.log')
    if log.exists():
        add(log)
for reference in (protocol['baseline']['build'], protocol['baseline']['build_plan']):
    add(reference['path'], reference)
for path in (N / 'region-final-focused-961.json', N / 'region-final-focused-961.log',
             N / 'region-test-coverage-inventory-961b.json', N / 'region-doc-check-inventory-962.json',
             N / 'region-adversarial-review-962.json', N / 'region-test-corrections-960.json',
             N / 'region-public-report-correction-962.json',
             N / 'region-replay-negative-plan-962.json',
             N / 'region-standard-deviation-review-962.json', N / 'region-layout-diagnostic-962.json',
             N / 'region_layout_diagnostic_962.py',
             N / 'region-collection-amendment-963.json', N / 'run_region_comparison_963.py',
             N / 'region-failure-closeout-963.json',
             N / 'region-comparison-full43-A-959/receipt.json',
             N / 'region-comparison-full43-A-959/driver.log',
             N / 'region-architecture-tracker-962.json', N / 'region-runtime-gap-962.json',
             N / 'region_build_962.py', N / 'run_full43_region_962.py',
             N / 'region-release-build-961.json', N / 'region-release-build-961.log',
             N / 'region-public-report-test-962.json', N / 'region-public-report-test-962.log',
             N / 'verify_region_comparison_962.py', Path(__file__)):
    add(path)
standard_ref = add(N / 'full43-region-run-962.json')
standard = read(standard_ref['path'])
assert standard['status'] == 'passed'
for reference in (standard['summary'], standard['plan'], standard['log']):
    add(reference['path'], reference)
single_root = Path(standard['summary']['path']).parent
for path in sorted(single_root.iterdir()):
    if path.is_file():
        add(path)
stage_refs = {}
for name in ('full43-A', 'full43-B', 'heldout-A'):
    stage_root = N / ('region-comparison-' + name + '-963')
    stage_ref = add(stage_root / 'receipt.json')
    stage = read(stage_ref['path'])
    if name == 'heldout-A':
        assert stage['status'] == 'failed' and len(stage['records']) == 11
    else:
        assert stage['status'] == 'complete' and stage['identities_unchanged']
    stage_refs[name] = stage_ref
    for path in sorted(stage_root.rglob('*')):
        if path.is_file():
            add(path)
changed = subprocess.check_output(['git', 'diff', '--name-only',
    protocol['integrated_source_commit'], runtime['source_commit'], '--', 'shardloom-vortex', 'shardloom-cli'],
    cwd=W, text=True).splitlines()
assert len(changed) == 10
candidate_sources = [dict(relative_path=relative, identity=add(W / relative)) for relative in changed]
manifest = dict(schema='shardloom.scalar_region_experiment_archive.v1',
    protocol=protocol_ref, runtime=runtime_ref, standard=standard_ref, stages=stage_refs,
    collection_amendment=identity(N / 'region-collection-amendment-963.json'),
    failure_closeout=identity(N / 'region-failure-closeout-963.json'),
    experiment_status='rejected_after_heldout_activation_failure', planned_calls=267,
    executed_calls=226, unexecuted_calls=41, heldout_b_not_started=True,
    candidate_sources=candidate_sources, files=list(paths.values()),
    note='Raw saved experiment only. Large source data and native executable bytes are intentionally external; their recorded identities remain in frozen receipts. No native workload runs during packaging or replay.')
assert len({x['member'] for x in paths.values()}) == len(paths)
with TARGET.open('xb') as output:
    with tarfile.open(fileobj=output, mode='w:gz') as archive:
        for member, raw in [('manifest.json', (json.dumps(manifest, indent=2) + '\n').encode()),
                            *((x['member'], Path(x['original_path']).read_bytes()) for x in paths.values())]:
            info = tarfile.TarInfo(member)
            info.size = len(raw)
            info.mode = 0o644
            info.mtime = 0
            archive.addfile(info, io.BytesIO(raw))
assert TARGET.stat().st_size <= 32 * (1 << 20)
print(json.dumps(dict(packet=identity(TARGET), members=len(paths) + 1), indent=2))
