"""Prepare and freeze the source-bound scalar-region comparison runtime."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
N = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022')
T = N / 'release-target-947'
PROTOCOL = N / 'region-scalar-protocol-959.json'
PLAN = N / 'region-release-plan-962.json'
BUILD = N / 'region-release-build-962.json'
CHECKS = ['region-fmt-962b', 'region-native-clippy-962b', 'region-native-tests-961',
          'region-workspace-clippy-962b', 'region-workspace-tests-962b', 'region-public-tests-962b']


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=W, text=True).strip()


def check_evidence():
    receipts = []
    expected = None
    for label in CHECKS:
        path = N / (label + '.json')
        value = json.loads(path.read_text())
        assert value['status'] == 'passed' and value['returncode'] == 0
        assert value['process_group_drained'] and value['source_before'] == value['source_after']
        assert identity(N / (label + '.log'))['sha256'] == value['log_sha256']
        if expected is None:
            expected = value['source_after']
        if label == 'region-native-tests-961':
            assert set(value['source_after']) == set(expected)
            changed = {p for p in expected if value['source_after'][p] != expected[p]}
            assert changed == {'shardloom-cli/src/public_workflow_route.rs'}
        else:
            assert value['source_after'] == expected
        receipts.append(identity(path))
    for relative, digest in expected.items():
        assert identity(W / relative)['sha256'] == digest, relative
    log = (N / 'region-native-tests-961.log').read_text()
    import re
    test_names = []
    for relative in ('scalar_region_workers_tests.rs', 'scalar_region_workers_lifecycle_tests.rs',
                     'scalar_region_workers_layout_tests.rs'):
        source = W / 'shardloom-vortex/src/local_primitives' / relative
        names = re.findall(r'#\[test\]\s*fn ([A-Za-z0-9_]+)\(', source.read_text())
        test_names.extend(names)
    assert len(test_names) == 15 and len(set(test_names)) == 15
    for name in test_names:
        assert re.search(r'^test .*::' + re.escape(name) + r' \.\.\. ok$', log, re.M), name
    public_log = (N / 'region-public-tests-962b.log').read_text()
    assert 'source_region_observations_survive_public_summary_without_invented_counters ... ok' in public_log
    return receipts, expected, test_names


assert len(sys.argv) == 2 and sys.argv[1] in ('prepare', 'freeze')
assert git('status', '--porcelain') == ''
assert identity(PROTOCOL)['sha256'] == '5fdd1589bb3ec01799ba55b2a7f42c759ce84ac39d9a9cba82e1f0d2294507ab'
protocol = json.loads(PROTOCOL.read_text())
checks, sources, names = check_evidence()
if sys.argv[1] == 'prepare':
    prior = N / 'region-release-build-961.json'
    previous = json.loads(prior.read_text())
    assert previous['status'] == 'passed' and previous['process_group_drained']
    assert previous['cwd'] == str(W) and previous['target'] == str(T)
    env = dict(os.environ, CARGO_TARGET_DIR=str(T), CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2',
               CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0')
    metadata = json.loads(subprocess.check_output(
        ['cargo', 'metadata', '--offline', '--no-deps', '--format-version', '1'], cwd=W, env=env))
    assert Path(metadata['target_directory']) == T and T.is_dir()
    save(PLAN, dict(schema='shardloom.source_bound_native_build.v1', status='predeclared',
        source_commit=git('rev-parse', 'HEAD'), source_tree=git('rev-parse', 'HEAD^{tree}'),
        target=str(T), target_did_not_exist=False, reused_target_build=identity(prior),
        target_scope='Existing dedicated target for this exact worktree; reuse dependencies and rebuild changed native code. Not a fresh empty target.',
        command=protocol['candidate_build_command'], protocol=identity(PROTOCOL), checks=checks,
        source= sources, role_distinguishing_unit_tests=names,
        selected_environment={key: os.environ.get(key) for key in (
            'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER',
            'CARGO_BUILD_RUSTFLAGS', 'CARGO_TARGET_AARCH64_APPLE_DARWIN_RUSTFLAGS',
            'CARGO_PROFILE_RELEASE_LTO', 'CARGO_PROFILE_RELEASE_CODEGEN_UNITS')},
        explicit_environment={key: env[key] for key in ('CARGO_TARGET_DIR', 'CARGO_INCREMENTAL',
            'CARGO_BUILD_JOBS', 'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG')},
        supervisor=identity(N / 'run_validation_947.py'), helper=identity(__file__)))
    print('Scalar-region source-bound build plan recorded.', flush=True)
else:
    plan = json.loads(PLAN.read_text())
    build = json.loads(BUILD.read_text())
    assert plan['source_commit'] == git('rev-parse', 'HEAD')
    assert plan['source_tree'] == git('rev-parse', 'HEAD^{tree}')
    assert build['status'] == 'passed' and build['returncode'] == 0 and build['process_group_drained']
    assert build['source_before'] == build['source_after'] == plan['source'] == sources
    assert build['command'] == plan['command'] == protocol['candidate_build_command']
    assert build['target'] == plan['target'] == str(T)
    log = N / 'region-release-build-962.log'
    assert identity(log)['sha256'] == build['log_sha256']
    assert f'Compiling shardloom-cli v0.7.0 ({W / "shardloom-cli"})' in log.read_text()
    previous = json.loads((N / 'region-release-build-961.json').read_text())
    assert previous['status'] == 'passed' and previous['source_before'] == previous['source_after']
    assert {p for p in sources if sources[p] != previous['source_after'][p]} == {'shardloom-cli/src/public_workflow_route.rs'}
    assert f'Compiling shardloom-vortex v0.7.0 ({W / "shardloom-vortex"})' in (N / 'region-release-build-961.log').read_text()
    artifact = N / 'artifacts/native-scalar-regions-962'
    artifact.mkdir()
    binary = artifact / 'shardloom'
    for destination in (binary,):
        source = T / 'release' / destination.name
        before = identity(source)
        shutil.copy2(source, destination)
        assert identity(destination)['sha256'] == before['sha256']
    assert identity(binary)['sha256'] != protocol['baseline']['executable']['sha256']
    save(N / 'native-runtime-region-962.json', dict(status='passed',
        source_commit=plan['source_commit'], source_tree=plan['source_tree'],
        build=identity(BUILD), build_plan=identity(PLAN), executable=identity(binary),
        protocol=identity(PROTOCOL), checks=checks, role_distinguishing_unit_tests=names,
        script=identity(__file__), query_calls=0,
        validation_reuse=dict(native_tests='region-native-tests-961',
            changed_source_only='shardloom-cli/src/public_workflow_route.rs',
            justification='Native engine, dependency and test sources exactly unchanged; CLI reporting change verified by its new regression and refreshed public/workspace checks.'),
        scope='Source-bound release CLI after the frozen CLI/library build, all required checks and 15 region tests. No candidate timed query or additional role probe has run.'))
    print('Candidate CLI frozen; every required check and all 15 region tests verified.', flush=True)
