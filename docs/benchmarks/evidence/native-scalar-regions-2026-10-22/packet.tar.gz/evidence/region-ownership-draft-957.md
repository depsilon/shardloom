# Scalar region ownership — prospective source review

This is a design draft, not runtime implementation or acceptance. It binds the
native provider inventory `region-directory-source-inventory-957.json` (SHA256
`5dbac10550de0c93563ae7425f3e888bf72e566d31490c50186ae3fdf53984ef`). All sixteen
source hashes were independently checked against the current checkout. The
existing test-fixture inventory's eleven source hashes were also checked.

## Finite provider admission

The first consumer admits held native file sources and the pinned persisted
`vortex.flat`, `vortex.chunked`, `vortex.struct`, `vortex.zoned` and `vortex.dict`
layouts only. Unknown layout providers, list layouts, row-index projections,
nullable struct roots and owned-array sources decline before execution. The
source schema must give every projected measure a primitive integer dtype.
Predicates in this first mechanism are absent or one exact native comparison of
a top-level primitive integer column with a scalar literal. Compound, transformed
and residual predicates keep their existing route. This still covers the named
filtered-count and nullable target without inventing a general mask proof.

Keep the sixteen projected-column/measure limits. Projection references each
selected field once, and the admitted predicate adds at most one field mask.
The preallocation proof therefore uses the conservative maximum M = 17. A root
`All` mask visits each child once and does not increase that bound. The pinned
provider's `referenced_field_masks` output and actual discovery must be checked
against this limit; neither a changed provider nor a larger shape is silently
admitted.

## Directory credit before discovery

Walk native footer layout slots with the existing bounded iterative traversal
pattern. Keep only the ancestor stack, limit its depth to 64 and the complete
walk to 262144 layout nodes, and reserve the stack's capacity before allocation.
Do not build a second layout tree or retain a node inventory in the query.
Unsupported providers or exceeded finite limits decline before input tasks.
Malformed layout metadata remains an error. Lazy native reader/metadata ownership
keeps its existing provider contract and exclusions; this is not a new whole-
process memory guarantee.

For N visited nodes, at most M visits per node are possible under the admitted
mask shape. Flat and Struct emit at most one terminal boundary per visit;
Chunked emits one boundary per visited child edge and may recurse; Zoned and
Dictionary delegate to one data/codes child. A conservative raw boundary upper
bound is B = max(128, 2*N*M + 1). Include chunked reservations in that bound and
test it against the actual capacity, not only final unique-boundary length.
The provider's native subdivision inserts at most R = ceil(rows/100000)
additional boundaries: its source-pinned maximum span is 100000. It does not
remove or move original boundaries. Reserve `(5*B + 3*R)*size_of(u64)` before
calling `full_file_splits`; this covers simultaneous old/new Vec capacities and
the subsequent Vec-to-Arc copy. Arithmetic is checked. Reservation failure
declines before any input registration, while an observed bound violation fails
explicitly and is never replayed through another route.

Validate the returned boundaries are unique, strictly increasing and cover
exactly 0..source_rows. Empty input is handled before worker admission. Convert
the provider's sequence into one shared Arc without changing it. After temporary
vectors are gone, reduce the lease to actual retained capacity plus Arc/control
overhead; retain it until all jobs, the prepared scan and its directory are gone.
The source-pinned constant and traversal proof require review on provider changes.
They are not a promise about arbitrary LayoutReader implementations.

## Job and state credit

Reserve shared immutable recipe/template storage before cloning it. Include
actual alias/column/path string capacities, dtype/rendered-evidence bounds and
state/control structures, with checked totals. Each admitted job obtains its
own fixed scalar-partial lease before cloning state or registering provider
work. The allowed identity integer states retain no distinct sets, strings,
representative rows or input arrays after their local reduction. Account for the
partial and its observed split metadata while it waits for ordered merge.

Use existing native allocation owners for provider reads, decode, selection and
accessor buffers. Keep their current explicit exclusions. The existing report's
reader-split evidence vector remains the same report owner; do not relabel its
bytes or process RSS as newly covered native credits. Report new directory,
recipe and outstanding-partial capacities separately and preserve all existing
resource evidence. Initial/state-growth denial, no hidden second CPU pool and
zero leaked credits after success/error/cancellation are mandatory tests.

## Execution and drain

Create AggregateChunkJobs with P-1 workers plus the existing caller and an
outstanding window of 2*P. No provider background drivers may coexist with
these jobs. Clone the existing CurrentThreadRuntime, never create a new native
runtime per range. A job first checks cancellation, obtains conservative native
pruning for its original range, and only registers RepeatedScan execution if
the range is not completely pruned. Partial pruning is not a skipped region.
The exact original range must produce at most one native task; await it directly
instead of using execute_stream and its separate task fanout. Reduce through
the existing scalar update implementation before returning compact state.

Check cancellation around pruning, native task completion and local reduction.
Stop new admission on failure; cancel and join every owned job before the held
source's validation gate can return. Task drop alone is not drain proof. The
existing bounded native batch size limits cancellation granularity; the design
does not promise instruction-level preemption. P1 performs the same work on the
caller and must make progress without background drivers.

Merge in original range order using existing checked scalar merge arithmetic.
Preserve direct/fused update evidence and numeric/encoded representation counts;
assert excluded distinct/text/partition state cannot appear. Metadata-only
answers and full-file pruning remain before region admission. Actual filtered
rows, executed arrays, original coverage and metadata-pruned regions remain
distinct observations. No error after input starts can select another route.

## Required proof before measurement

Check the capacity bound on flat, multi-column, nested physical chunking, zoned
and dictionary files, including duplicate boundaries and large-gap subdivision.
Reject arbitrary and unknown providers rather than generalizing the proof.
Use an injected skewed first job to prove overlap and ordered delivery; preserve
natural batches and exact full-source coverage in ordinary and prepared entry
points. Exercise source replacement, cancel, provider failure, initial and
state-growth denial, count overflow, empty/all-null/all-pruned input and exact
integer sum-bound edges. Confirm an actual caller-only session and unchanged
provider allocation exclusions in the resulting evidence.

The held-out draft is `region-heldout-draft-957.json`: four numeric targets and
nine controls, 52 paired calls. Constant/RunEnd is a control because existing
encoded work avoidance does not imply a parallel opportunity. The current
49.953164785-second Full43 observation is not a candidate result or a forecast.
No optional worker family, text-preparation path, provider patch, external engine,
package release or relaxed comparison gate is authorized by this draft.
