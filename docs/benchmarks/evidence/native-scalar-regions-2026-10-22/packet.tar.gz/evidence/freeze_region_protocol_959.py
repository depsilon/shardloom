#!/usr/bin/env python3
"""Freeze existing inputs, independent references, source scope and decisions."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
N = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022')

def read(path):
    return json.loads(Path(path).read_text())

def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
assert head == '3d07013fb12cf21e6040adb03f9e97e995996875'
baseline = read(N / 'native-runtime-950.json')
assert identity(baseline['executable']['path']) == baseline['executable']
assert identity(baseline['build']['path']) == baseline['build']
build = read(baseline['build']['path'])
assert build['source_before'] == build['source_after']
source_matches = {}
for relative, expected in build['source_after'].items():
    observed = identity(W / relative)['sha256']
    if observed != expected:
        # Only a test-only module inclusion has been added in this worktree.
        assert relative == 'shardloom-vortex/src/local_primitives.rs', relative
        original = subprocess.check_output(['git', 'show', 'HEAD:' + relative], cwd=W)
        assert hashlib.sha256(original).hexdigest() == expected
    source_matches[relative] = expected
fixtures = read(N / 'region-fixtures-result-958b.json')
assert fixtures['status'] == 'passed' and fixtures['query_calls'] == 0
assert len(fixtures['records']) == 10 and all(x['status'] == 'passed' and x['process_group_drained'] for x in fixtures['records'])
for item in fixtures['records']:
    assert identity(item['file']['path']) == item['file']
full43 = read(N / 'full43-plan-950.json')
heldout = read(N / 'region-heldout-draft-957.json')
heldout['status'] = 'frozen_before_runtime_implementation'
heldout['datasets'][6]['oracle_policy'] = read(N / 'region-scalar-reference-958.json')['floating_policy']
heldout.pop('still_required_before_freeze')
heldout['source_construction']['identity'] = 'Exact file identities and generations are bound below; pre/post verification is mandatory.'
protocol = read(N / 'region-scalar-intake-draft-956.json')
protocol.update(status='frozen_before_runtime_implementation', frozen_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    integrated_source_commit=head, baseline=baseline, baseline_runtime_sources=source_matches,
    fixture_result=identity(N / 'region-fixtures-result-958b.json'),
    fixtures=[dict(id=x['id'], file=x['file'], generation=x['generation']) for x in fixtures['records']],
    heldout=heldout, heldout_reference=identity(N / 'region-scalar-reference-958.json'),
    full43_input=dict(file=full43['input'], generation=full43['input_generation']),
    full43_reference=full43['reference'], full43_queries=full43['queries'],
    current_attribution=identity(N / 'current-attribution-evidence-958.tar.gz'),
    current_attribution_replay=identity(N / 'current-attribution-replay-958.json'),
    supervisor=full43['supervisor'], workload_guard=full43['workload_guard'],
    candidate_build_command=['cargo', 'build', '--release', '--offline', '-p', 'shardloom-cli', '--features', 'release-user-surfaces', '--bin', 'shardloom', '--lib'],
    candidate_build_policy='Use this same worktree and its dedicated release-target-947 with recorded toolchain/environment and source-before=source-after. Freeze candidate executable/build/source receipt before query execution, verify source equality, and require a distinct executable and role-distinguishing unit evidence. Reuse dependencies; do not claim a fresh target.',
    stage_order=['unit/lifecycle/coverage/ownership correctness and required broad validation', 'one isolated standard Full43, 43 calls', 'full43-A, 86 calls', 'full43-B, 86 calls', 'heldout-A, 26 calls', 'heldout-B, 26 calls', 'replay complete retained evidence and decide'],
    safety='Each stage is isolated from other task work. Keep standard locks, storage ceilings, 12 GiB free-space floor, active-output 256 MiB ceiling, native deadlines and process-group drain. Hash and inspect complete sources/build caches only outside query execution. Retain all failures; do not restart a failed stage unchanged.',
    decision='Retain only with every semantic/activation/ownership gate and all four cohort timing/RSS gates. A failed benefit gate drops the candidate. A failed correctness/ownership prerequisite records no admitted timing comparison. Never lower gates, replace controls, widen scope or discard observations after candidate execution.',
    exact_heldout_float_policy='Bit-exact F64 values against independently constructed prescribed arithmetic; Full43 retains its frozen independent reference reader tolerance.',
    candidate_observations_collected=0)
protocol['production_admission']['predicate'] = 'Absent or one top-level primitive-integer column versus scalar literal exact native comparison; no compound/transformed/residual predicate.'
protocol['ownership']['directory'] = 'Pinned known flat/chunked/struct/zoned/dict footer graph only; at most 262144 nodes, depth64. Precredit ancestor stack; bound M17 field masks, B=max(128,2*N*M+1), R=ceil(rows/100000). Reserve (5*B+3*R)*8 before provider split discovery. Validate measured Vec capacity and final boundaries; checked overflow or unsupported metadata declines before tasks. Existing provider metadata allocations remain excluded.'
protocol['ownership']['recipe_and_partial'] = 'Precredit immutable recipe strings/state template and each fixed scalar partial plus exact range/split metadata before cloning or execution. Keep partial credit through ordered consumption. Existing provider read/decode and report-vector ownership/exclusions remain explicit.'
protocol['ownership']['detailed_source_review'] = identity(N / 'region-ownership-draft-957.md')
protocol['separate_prospective_comparison'].pop('remaining_before_freeze')
protocol['separate_prospective_comparison']['heldout_target_families'] = [x['id'] for x in heldout['cases'] if x['role'] == 'target']
protocol['separate_prospective_comparison']['heldout_control_families'] = [x['id'] for x in heldout['cases'] if x['role'] == 'control']
protocol['separate_prospective_comparison']['heldout_call_count'] = 52
protocol['separate_prospective_comparison']['total_native_calls_including_standard_pass'] = 267
paths = [N / 'run_region_comparison_959.py', Path(__file__), N / 'region_scalar_reference_958.py',
         N / 'region-scalar-reference-958.json', Path(full43['reference']['path']), Path(full43['queries']['path']),
         Path(full43['supervisor']['path']), Path(full43['workload_guard']['path'])]
paths += [W / 'scripts' / name for name in ['run_clickbench_paired_query_uat.py', 'run_clickbench_query_uat.py',
          'native_workflow_protocol.py', 'query_timing_report.py', 'clickbench_reference_packet.py', 'timed_native_command.py', 'local_uat_storage.py']]
paths += sorted((W / 'python/src/shardloom').rglob('*.py'))
protocol['harness_sources'] = [identity(path) for path in paths]
protocol['design_sources'] = [identity(N / name) for name in ['native-region-consumer-design-956.md',
    'region-ownership-draft-957.md', 'region-directory-source-inventory-957.json', 'region-worker-test-inventory-959.json',
    'region-heldout-draft-957.json', 'generate_region_fixtures_958b.py']]
protocol['design_sources'].append(identity(W / 'shardloom-vortex/src/local_primitive_region_fixture_harness.rs'))
output = N / 'region-scalar-protocol-959.json'
with output.open('x') as stream:
    json.dump(protocol, stream, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps(dict(status=protocol['status'], identity=identity(output), required_standard_calls=43, separate_paired_calls=224, engine_candidate_implemented=False)))
