# Native region consumers — prospective design

Status: source review draft. No runtime candidate or timing comparison has run.
The prerequisite correctness PR is #1589 at
`18c06f7a7abfa839facf7915a90819c347e7601e`; integration and the current attribution
review precede implementation. This refines PERF-03.regions / PERF-04.semantics
under RFC 0044. Optional worker/state families remain deferred.

## Opportunity and mechanism

The frozen current-source diagnostic used the corrected executable whose SHA-256
is `d692fa57c957aab63fdcafc86755a17ef36666e257cb6b9374335af61bdce870`.
Q3 has a serial numeric-consumer stack while its sampled provider driver is
predominantly blocked. Q23 repeatedly executes native UTF8 canonicalization and
ZSTD decompression underneath the serial aggregate accessor constructor. The
raw samples are all-thread wall observations, not function instruction counts
or exclusive CPU percentages. They justify investigating moving actual consumer
work into independently admitted native regions; they do not establish a gain.

The rejected September mechanism changed job grouping while returning the same
arrays to unchanged serial consumers. The new mechanism must perform useful
consumer work before its region completion: initially a compact scalar partial,
or a prepared accessor batch consumed in the original source order. It must not
relabel split descriptors or repeat the old coalescing experiment.

Vortex-first decision: use_vortex_native_provider. Pinned Vortex 0.85.0 already
provides ScanBuilder::full_file_splits, with_natural_splits, prepare, and
RepeatedScan::execute(Some(range)). Each job owns exactly one original natural
range. Use the original boundary sequence, not a worker-count-derived partition
or byte offset. ScanBuilder::map is available but does not carry a range; an
outer job can retain the exact range without modifying the provider API.
Execute the resulting native task directly and finish its consumer inside that
same job. Do not create a second provider pool or detached scan stream.

## Ownership and lifecycle

Enter the existing held-source generation gate once around discovery, admission,
all work, ordered consumption and drain. Use one caller-only resident session,
its CurrentThreadRuntime clones and AggregateChunkJobs: P-1 compute workers plus
the caller, a bounded outstanding window including queued/active/completed/
merging results, and existing shared memory leases. The legacy runtime or a
session with an existing provider pool must decline this candidate before input.
No thread is created per region. No new scheduler or source-generation model is
needed.

Keep metadata completion and whole-file pruning before worker admission. For a
predicate, obtain conservative original-range pruning proof before execute()
registers projection requests. An all-false result after execution is an executed
region, not metadata-pruned work. Missing statistics keep the range.

Every task must retain its original range and ordinal; its reported filtered row
count is distinct from source coverage. Validate boundaries are ordered, unique,
in range and cover the complete source. Empty input is valid. Completion merges
in original range order. Cancellation stops admission and checks at task and
consumer boundaries; errors cancel and join every owned job before escaping.
Dropping a Vortex Task alone is not a drain guarantee. No retry onto another
execution route follows a candidate error. Initial admission decline may retain
the existing route only before any candidate input is processed.

Reserve adapter recipes, directories and compact state before retaining them;
keep leases through ordered consumption. Existing provider read/decode owners
retain the same admitted session. Identify excluded provider allocation classes
explicitly; an array nbytes estimate is not unique retained memory or an RSS
limit. A text-accessor candidate additionally needs a conservative preallocation
bound and proof for dictionary construction and retained canonical buffers before
it can be admitted. Do not infer this proof from the scalar candidate.

## First bounded consumer

Investigate scalar identity COUNT, SUM, AVG, MIN and MAX over primitive integer
columns, with no distinct state, argument offset, grouping, spill, source-order
input limit or residual predicate. Native exact pushdown predicates are allowed.
Metadata-only cases retain their existing answer. Admit SUM/AVG only when the
full-source row bound multiplied by the dtype's maximum absolute value is at
most 2^53, computed with checked integer arithmetic before scanning. This
conservative condition makes every input conversion and every partial addition
exact in the existing F64 representation; count division occurs once at the
existing finalizer. It does not change the large-integer compensated policy.
Large-integer totals outside this proof and all floating SUM/AVG retain their
existing ordered route. MIN/MAX preserve the original typed integer values.

Reuse SimpleAggregateStates, its encoded Constant/RunEnd path, native accessors
and checked merge. Preserve original native batches. Each result carries only
the compact states, actual representation-work evidence and source identity;
numeric input arrays are released before the completion becomes mergeable.
Merge all state flags/evidence, not just result values. Shape admission is based
on types/operators/resources, never benchmark query IDs or column names.

The Q3 profile supplies the initial numeric opportunity. The baseline Q3 engine
observation is a workload share, not a forecast. A narrow scope with insufficient
complete-operation benefit must be rejected rather than widened after results.

## Separate text-preparation decision

The Q23 opportunity is serial aggregate accessor preparation. Existing
aggregate_direct_column_accessors_from_chunk and the original profiled consumer
already separate preparation from updates. A later candidate could move that
same preparation into region work while retaining the original central aggregate
updates and exact key/NULL/tie behavior. It needs its own admitted shape,
dictionary/array ownership bound, original array boundary proof, conservative
failure behavior and prospective comparison. Do not force native dictionaries
into expanded text, bypass source-order admission, or promote all grouped worker
families. This draft does not yet admit that candidate.

## Acceptance that must be frozen before implementation

Pin the final candidate shape, source/binary identities, directory and queue
limits, exactness matrix and comparison protocol in a machine-readable intake.
First prove actual independent range execution, overlap with P>1, P=1 progress,
complete coverage and original batch boundaries on skewed/empty/pruned inputs.
Test NULL and all-null inputs, every admitted signed/unsigned width, boundary
sum admission and rejection, exact counts/extrema/averages, constant/run-end and
ordinary encodings, predicate selection, changed source, cancellation, provider
failure, initial/state-growth denial and complete drain. Check public ordinary
and prepared entry points use the same admission; excluded cases retain their
existing route without starting candidate work.

After a coherent runtime implementation, perform the maintainer-required one
isolated standard Full43 pass (43 calls, one per query) using the current complete
independent reference, storage limits, lightweight concurrency guard, deadlines
and cleanup. Hash/inventory before and after, never inside active supervision.
Preserve every result. Investigate a material unexplained deviation before
continuing. This is distinct from any prospectively authorized paired study.

A separate prospective complete-workload comparison must specify two balanced
role-order cohorts, all 43 complete results plus independent held-out small,
large-numeric, nullable, dictionary/run-end, skew, no-benefit and constrained-
memory controls. Freeze material aggregate benefit, per-query regression,
control and memory gates before collecting candidate results. Do not substitute
a favorable subset or lower gates after observing results. A failed gate drops
the implementation and leaves dependent ordered/preparation/topology work
explicitly unadmitted. No compiler, writer, codec, artifact format, external
engine, public API or release change is included.
