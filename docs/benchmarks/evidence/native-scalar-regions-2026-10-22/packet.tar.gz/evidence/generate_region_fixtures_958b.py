#!/usr/bin/env python3
"""Construct the ten declared held-out inputs; no query execution or timing."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
N = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022')
T = Path('/Users/dylan/.cache/shardloom/cargo-target')
OUT = N / 'region-fixtures-958b'
sys.path[:0] = [str(W / 'scripts'), '/Users/dylan/LocalData/shardloom/conditional-investigations-20261019']
from local_uat_storage import GIB, MIB, accounted_bytes, require_local_path
from native_workload_guard_816 import WorkloadGuard

SUPERVISOR = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
spec = importlib.util.spec_from_file_location('bounded', SUPERVISOR)
bounded = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bounded)


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha)


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


build_path = N / 'region-fixture-compile-958b.json'
build = json.loads(build_path.read_text())
assert build['status'] == 'passed' and build['process_group_drained']
assert build['source_before'] == build['source_after']
for name, sha in build['source_after'].items():
    assert identity(W / name)['sha256'] == sha, name
matrix_path = N / 'region-heldout-draft-957.json'
matrix = json.loads(matrix_path.read_text())
binary = T / 'debug/deps/shardloom_vortex-ffc63d480fe84db0'
binary_identity = identity(binary)
work = WorkloadGuard()
work.check()
for path in [N, T]:
    require_local_path(path, Path.home(), sys.platform)
assert accounted_bytes(N) + accounted_bytes(T) + 512 * MIB <= 100 * GIB
assert shutil.disk_usage(N).free >= 12 * GIB + 512 * MIB
OUT.mkdir()
record = dict(status='running', build=identity(build_path), binary=binary_identity,
              specification=identity(matrix_path), generator=identity(__file__),
              query_calls=0, records=[])


def guard():
    work.check(call.get('pid'))
    assert shutil.disk_usage(N).free >= 12 * GIB
    assert accounted_bytes(OUT) <= 512 * MIB, 'combined fixture budget exceeded'


try:
    for dataset in matrix['datasets']:
        name = dataset['id']
        command = [str(binary), 'local_primitives::region_fixture_harness::region_scalar_fixture_generate',
                   '--exact', '--ignored', '--nocapture', '--test-threads=1']
        call = dict(id=name, command=command)
        stdout_path, stderr_path = OUT / f'{name}.stdout.txt', OUT / f'{name}.stderr.txt'
        with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
            code = bounded.run(command, cwd=W,
                env=dict(os.environ, SHARDLOOM_REGION_FIXTURE_ROOT=str(OUT), SHARDLOOM_REGION_FIXTURE_ID=name),
                output=stdout, error_output=stderr, timeout=120, evidence=call,
                guard=guard, max_output_bytes=2 * MIB)
        assert code == 0 and call['process_group_drained'] and call['direct_child_reaped']
        text = stdout_path.read_text()
        assert 'test result: ok. 1 passed;' in text
        lines = []
        for line in text.splitlines():
            at = line.find('{')
            if at >= 0:
                try:
                    value = json.loads(line[at:])
                except ValueError:
                    continue
                if value.get('id') == name:
                    lines.append(value)
        assert len(lines) == 1
        value = lines[0]
        path = OUT / f'{name}.vortex'
        assert value['rows'] == dataset['rows'] and value['path'] == str(path)
        actual = identity(path)
        assert actual['bytes'] == value['bytes']
        stat = path.stat()
        call.update(status='passed', writer=value, file=actual,
            generation=dict(device=stat.st_dev, inode=stat.st_ino, size_bytes=stat.st_size,
                            mtime_ns=stat.st_mtime_ns, ctime_ns=stat.st_ctime_ns),
            stdout=identity(stdout_path), stderr=identity(stderr_path))
        record['records'].append(call)
        save(OUT / f'{name}.receipt.json', call)
        print('Created fixed fixture ' + name, flush=True)
    assert identity(binary) == binary_identity
    for name, sha in build['source_after'].items():
        assert identity(W / name)['sha256'] == sha, name
    assert len(record['records']) == 10
    record.update(status='passed', total_fixture_bytes=sum(row['file']['bytes'] for row in record['records']),
                  sources_unchanged=True, expected_reference=identity(N / 'region-scalar-reference-958.json'))
except BaseException as error:
    record.update(status='failed', failure=type(error).__name__ + ': ' + str(error), active_call=call)
    raise
finally:
    save(N / 'region-fixtures-result-958b.json', record)
print(json.dumps(dict(status=record['status'], fixtures=len(record['records']), query_calls=0)), flush=True)
