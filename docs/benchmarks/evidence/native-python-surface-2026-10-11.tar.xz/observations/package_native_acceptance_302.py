"""Preserve native Python acceptance bytes in a independently checked packet."""
from __future__ import annotations

import hashlib
import io
import json
from pathlib import Path
import tarfile

from freeze_native_release_298 import ROOT, OUT, sha, sources


def main():
    frozen = json.loads((OUT / 'native-release-source-300.json').read_text())
    assert sources() == frozen['source_sha256']
    runtime = json.loads((OUT / 'native-final-runtime-test-results-301.json').read_text())
    assert runtime['status'] == 'passed' and runtime['source_unchanged']
    guard = json.loads((OUT / 'native-final-runtime-tests-301.json').read_text())
    assert guard['status'] == 'passed' and guard['process_group_drained']
    assert sha(OUT / 'native-final-runtime-tests-301.log') == guard['log_sha256']
    for name in ['native-final-source-gate-results-300.json',
                 'native-final-feature-gate-results-300.json',
                 'native-final-python-check-results-300.json',
                 'native-surface-verification-300c-results.json',
                 'native-wheel-proof-300b/report.json']:
        assert json.loads((OUT / name).read_text())['status'] == 'passed', name

    selected = {}
    def add(path, name):
        assert path.is_file() and not path.is_symlink(), path
        assert name not in selected and '..' not in Path(name).parts
        selected[name] = path

    # All small original development receipts, including failed attempts, are
    # kept. Binary builds/wheels/archives stay local with their recorded hashes.
    for path in sorted(OUT.iterdir()):
        if (path.is_file() and path.suffix in {'.json', '.log', '.py', '.patch'}
                and not path.name.startswith(('native-python-packet-',
                                               'native-python-archive-'))):
            add(path, 'observations/' + path.name)
    for name in ['native-surface-measurement-299', 'native-surface-measurement-300',
                 'native-surface-measurement-300b', 'native-surface-measurement-300c']:
        for path in sorted((OUT / name).rglob('*')):
            if path.is_file():
                add(path, 'observations/' + str(path.relative_to(OUT)))
    for directory in sorted(OUT.glob('native-wheel-proof-*')):
        if not directory.is_dir():
            continue
        for path in sorted(directory.iterdir()):
            if path.is_file() and path.suffix in {'.json', '.log'}:
                add(path, 'observations/' + str(path.relative_to(OUT)))
    for name in ['native-python-packet-302.json', 'native-python-packet-302.log']:
        add(OUT / name, 'assembly-attempts/' + name)
    for name, digest in frozen['source_sha256'].items():
        path = ROOT / name
        assert sha(path) == digest
        add(path, 'frozen-source/' + name)
    for name in ['rust-toolchain.toml', 'deny.toml', 'LICENSE', 'NOTICE',
                 '.github/requirements/ci-native-python.txt',
                 '.github/requirements/ci-native-python-build.txt',
                 '.github/workflows/ci.yml']:
        path = ROOT / name
        if path.is_file() and 'frozen-source/' + name not in selected:
            add(path, 'supporting-source/' + name)
    for path in [Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'),
                 Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')]:
        add(path, 'supervision/' + path.name)

    records = {name: {'bytes': path.stat().st_size, 'sha256': sha(path),
                      'original_path': str(path)} for name, path in selected.items()}
    index = {'schema_version': 'shardloom.native_python_acceptance_packet.v1',
             'accepted_cohort': 'observations/native-surface-measurement-300c',
             'accepted_wheel_proof': 'observations/native-wheel-proof-300b',
             'accepted_build_manifest': 'observations/native-release-artifacts-300.json',
             'frozen_source_files': len(frozen['source_sha256']),
             'frozen_source_head': frozen['head'],
             'sources_include_uncommitted_native_implementation': True,
             'binary_artifacts_included': False,
             'original_absolute_paths_retained_as_provenance': True,
             'members': records}
    index_bytes = (json.dumps(index, indent=2) + '\n').encode()
    archive = OUT / 'native-python-packet-302.tar.xz'
    assert not archive.exists()
    with archive.open('xb') as raw, tarfile.open(fileobj=raw, mode='w:xz', preset=1) as tar:
        for name, path in selected.items():
            before = path.stat()
            assert before.st_size == records[name]['bytes']
            info = tarfile.TarInfo(name)
            info.size = before.st_size
            info.mode = 0o644
            with path.open('rb') as stream:
                tar.addfile(info, stream)
            after = path.stat()
            assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (
                after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), path
            assert sha(path) == records[name]['sha256'], path
        info = tarfile.TarInfo('index.json')
        info.size = len(index_bytes)
        info.mode = 0o644
        tar.addfile(info, io.BytesIO(index_bytes))

    # Reopen every original byte through the completed compressed archive.
    seen = set()
    with tarfile.open(archive, 'r:xz') as tar:
        for member in tar:
            assert member.isfile() and member.name not in seen
            seen.add(member.name)
            stream = tar.extractfile(member)
            if member.name == 'index.json':
                assert stream.read() == index_bytes
                continue
            expected = records[member.name]
            assert member.size == expected['bytes']
            digest = hashlib.sha256()
            for block in iter(lambda: stream.read(1 << 20), b''):
                digest.update(block)
            assert digest.hexdigest() == expected['sha256'], member.name
    assert seen == set(records) | {'index.json'}
    assert sources() == frozen['source_sha256']
    result = {'schema_version': 'shardloom.native_python_acceptance_archive.v1',
              'status': 'passed', 'archive': str(archive),
              'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
              'index_sha256': hashlib.sha256(index_bytes).hexdigest(),
              'verified_members': len(seen),
              'original_payload_bytes': sum(row['bytes'] for row in records.values()),
              'frozen_source_files': len(frozen['source_sha256']),
              'source_unchanged': True, 'originals_deleted': False}
    with (OUT / 'native-python-archive-302.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
