"""Retain the exact Cargo-reported executable for native package acceptance."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            value.update(block)
    return value.hexdigest()

receipt = json.loads((OUT / 'native-final-cli-build-297.json').read_text())
assert receipt['status'] == 'passed' and receipt['process_group_drained']
log = OUT / 'native-final-cli-build-297.log'
assert sha(log) == receipt['log_sha256']
artifacts = [json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
paths = {entry['executable'] for entry in artifacts
         if entry.get('reason') == 'compiler-artifact'
         and entry.get('target', {}).get('name') == 'shardloom'
         and entry.get('executable')}
assert len(paths) == 1
source = Path(paths.pop())
assert source.is_file() and not source.is_symlink()
destination = require_local_path(OUT / 'native-cli-debug-297', Path.home(), sys.platform)
assert not destination.exists()
check_budgets(OUT, destination, OUT / 'logs', min_free_bytes=12 * GIB,
              reserve_bytes=source.stat().st_size + 128 * MIB,
              max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
identity = sha(source)
destination.mkdir()
target = destination / 'shardloom'
shutil.copy2(source, target)
assert sha(source) == sha(target) == identity
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others',
                                 '--exclude-standard', '-z'], cwd=ROOT).split(b'\0')
sources = {}
for raw in paths:
    name = raw.decode()
    if name and (name.endswith('.rs') or name.endswith('Cargo.toml')
                 or name == 'Cargo.lock' or name.startswith('.cargo/')):
        path = ROOT / name
        if path.is_file():
            sources[name] = sha(path)
record = {'status': 'passed', 'build_receipt': str(OUT / 'native-final-cli-build-297.json'),
          'cargo_executable': str(source), 'frozen_executable': str(target),
          'sha256': identity, 'source_sha256': sources}
(destination / 'identity.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'status': 'passed', 'executable': str(target),
                  'sha256': identity, 'rust_source_files': len(sources)}))
