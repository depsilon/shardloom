import json
from pathlib import Path
import shardloom as sl

root = Path(__file__).resolve().parent
proof = json.loads((root / 'native-wheel-proof-299/report.json').read_text())
fixture = root / 'native-surface-measurement-299/short.vortex'
rows = []
for transport in ('subprocess', 'native'):
    client = sl.ShardLoomClient(binary=proof['installed_load']['cli'], transport=transport,
        use_persistent_worker=True if transport == 'subprocess' else None,
        memory_bytes=1 << 30, max_parallelism=2)
    try:
        context = sl.context(client=client, memory_bytes=1 << 30, max_parallelism=2)
        result = context.sql(f"SELECT SUM(value) AS total FROM '{fixture}'").collect(check=True)
        table = result.to_arrow()
        row = {'transport': transport, 'schema': str(table.schema),
               'values': table.to_pydict(), 'result_schema': result.envelope.field('result_schema_json')}
        rows.append(row)
        print(json.dumps(row))
    finally:
        client.close()
(root / 'aggregate-schema-300.json').write_text(json.dumps(rows, indent=2) + '\n')
