"""Recheck the complete native Rust profiles against the frozen release source."""
import json
from pathlib import Path
import subprocess
import time
from freeze_native_release_298 import sha, sources

ROOT = Path(__file__).resolve().parent
manifest = ROOT / 'native-release-source-300.json'
frozen = json.loads(manifest.read_text())['source_sha256']
assert sources() == frozen
command = ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-cli',
           '-p', 'shardloom-vortex', '--all-targets', '--features', 'release-user-surfaces']
start = time.perf_counter()
completed = subprocess.run(command, check=False)
unchanged = sources() == frozen
record = {'status': 'passed' if completed.returncode == 0 and unchanged else 'failed',
          'command': command, 'returncode': completed.returncode,
          'seconds': time.perf_counter() - start, 'source_unchanged': unchanged,
          'source_manifest': str(manifest), 'source_manifest_sha256': sha(manifest)}
with (ROOT / 'native-final-runtime-test-results-301.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record), flush=True)
raise SystemExit(0 if record['status'] == 'passed' else 1)
