import pyarrow as pa
from shardloom.native import ExecutionResources, Relation, Session, col, lit

resources = ExecutionResources(256 << 20, 2)
session = Session(resources)
source = session.from_range("value", 0, 1, 100)
relation = (
    Relation.scan("memory://values")
    .filter(col("value") >= lit(10))
    .project([("value", col("value"))])
)
plan = session.plan(relation, sources=[("memory://values", source)])
result = plan.collect()
session.close()

# A completed result retains its native owner and remains exportable after close.
table = pa.RecordBatchReader.from_stream(result).read_all()
assert table.column_names == ['value']
assert table.to_pydict() == {'value': list(range(10, 100))}
assert pa.types.is_int64(table.schema.field(0).type)
print('README example: all 90 values exported after session.close(); exact int64 schema verified')
