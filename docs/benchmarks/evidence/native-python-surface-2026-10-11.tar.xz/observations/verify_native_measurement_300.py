#!/usr/bin/env python3
"""Independently verify one completed native Python measurement cohort.

This verifier reads receipts and Arrow IPC outputs only. It does not import or
execute the cohort driver. It always records discovered verification failures
in a new JSON output; an existing output path is never replaced.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import statistics
import sys
from pathlib import Path
from typing import Any

import pyarrow as pa
import pyarrow.ipc as ipc


WORKLOADS = (
    "columnar_input",
    "columnar_output",
    "retained_chain",
    "short_repeated_calls",
    "wide_typed_plan",
    "file_small_result",
)
TRANSPORTS = ("native", "subprocess")
EXPECTED_PAIRS = (-1, 0, 1, 2, 3, 4)
EXPECTED_MEMORY_BYTES = 1 << 30
EXPECTED_PARALLELISM = 2


class Verifier:
    def __init__(self, cohort: Path) -> None:
        self.cohort = cohort.resolve()
        self.errors: list[str] = []
        self.failures: list[str] = []
        self.sample_results: list[dict[str, Any]] = []
        self.tables: dict[tuple[str, int, str], pa.Table] = {}
        self.entries: dict[tuple[str, int, str], dict[str, Any]] = {}

    def fail(self, message: str) -> None:
        self.failures.append(message)

    def error(self, message: str) -> None:
        self.errors.append(message)

    @staticmethod
    def sha256(path: Path) -> str:
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(block)
        return digest.hexdigest()

    def resolve_inside(self, relative: Any, label: str) -> Path | None:
        if not isinstance(relative, str) or not relative:
            self.error(f"{label}: missing relative path")
            return None
        candidate = (self.cohort / relative).resolve()
        if not candidate.is_relative_to(self.cohort):
            self.error(f"{label}: path escapes cohort: {relative!r}")
            return None
        if not candidate.is_file():
            self.error(f"{label}: file is missing: {relative}")
            return None
        return candidate

    def read_json(self, path: Path, label: str) -> dict[str, Any] | None:
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:  # Keep verifying other independent samples.
            self.error(f"{label}: cannot read JSON ({type(exc).__name__}: {exc})")
            return None
        if not isinstance(value, dict):
            self.error(f"{label}: expected a JSON object")
            return None
        return value

    def require_equal(self, actual: Any, expected: Any, message: str) -> None:
        if actual != expected:
            self.fail(f"{message}: observed {actual!r}; expected {expected!r}")

    def collect_flags_and_grants(self, value: Any, location: str) -> None:
        """Check explicit no-fallback flags and declared resource grants."""
        if isinstance(value, dict):
            for key, item in value.items():
                normalized = str(key).lower()
                if normalized.endswith(("fallback_attempted", "fallback_execution_allowed", "external_engine_invoked")):
                    if self.is_true(item):
                        self.fail(f"{location}.{key}: prohibited true flag {item!r}")
                if normalized in {
                    "execution_resource_declared_memory_bytes",
                    "execution_resource_admitted_memory_bytes",
                }:
                    self.require_equal(
                        self.parse_int(item),
                        EXPECTED_MEMORY_BYTES,
                        f"{location}.{key} declared memory bytes",
                    )
                elif normalized == "execution_resource_declared_max_parallelism":
                    self.require_equal(
                        self.parse_int(item),
                        EXPECTED_PARALLELISM,
                        f"{location}.{key} declared parallelism",
                    )
                elif normalized in {
                    "execution_resource_declared_memory_gb",
                    "execution_resource_admitted_memory_gb",
                    "public_workflow_memory_gb",
                }:
                    try:
                        memory_bytes = int(float(item) * (1 << 30))
                    except (TypeError, ValueError, OverflowError):
                        memory_bytes = None
                    self.require_equal(
                        memory_bytes,
                        EXPECTED_MEMORY_BYTES,
                        f"{location}.{key} declared memory grant",
                    )
                elif normalized in {
                    "execution_resource_declared_max_parallelism",
                    "execution_resource_admitted_max_parallelism",
                    "public_workflow_max_parallelism",
                    "public_workflow_requested_max_parallelism",
                }:
                    self.require_equal(
                        self.parse_int(item),
                        EXPECTED_PARALLELISM,
                        f"{location}.{key} declared parallelism",
                    )
                self.collect_flags_and_grants(item, f"{location}.{key}")
        elif isinstance(value, list):
            for index, item in enumerate(value):
                self.collect_flags_and_grants(item, f"{location}[{index}]")

    def validate_evidence_fields(self, fields: Any, location: str) -> None:
        if not isinstance(fields, dict) or not fields:
            self.fail(f"{location}: execution fields are empty or missing")
            return
        for key in ("fallback_attempted", "external_engine_invoked"):
            self.require_equal(fields.get(key), "false", f"{location}.{key}")
        for key, expected in (
            ("execution_resource_declared_memory_bytes", EXPECTED_MEMORY_BYTES),
            ("execution_resource_admitted_memory_bytes", EXPECTED_MEMORY_BYTES),
            ("execution_resource_declared_max_parallelism", EXPECTED_PARALLELISM),
            ("execution_resource_admitted_max_parallelism", EXPECTED_PARALLELISM),
        ):
            self.require_equal(self.parse_int(fields.get(key)), expected, f"{location}.{key}")
        self.collect_flags_and_grants(fields, location)

    @staticmethod
    def parse_int(value: Any) -> int | None:
        try:
            if isinstance(value, bool):
                return None
            return int(value)
        except (TypeError, ValueError, OverflowError):
            return None

    @staticmethod
    def is_true(value: Any) -> bool:
        if value is True:
            return True
        if isinstance(value, str):
            return value.strip().lower() in {"true", "yes", "1"}
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return value == 1
        return False

    def expected_table(self, workload: str) -> pa.Table:
        if workload == "columnar_input":
            ids = list(range(1024, 131073))
            arrays = [
                pa.array(ids, type=pa.int64()),
                pa.array([3 * value for value in ids], type=pa.int64()),
                pa.array(
                    [None if value % 7 == 0 else f"label-{value % 31}" for value in ids],
                    type=pa.string(),
                ),
            ]
            names = ["id", "value", "label"]
        elif workload == "columnar_output":
            arrays = [pa.array(range(131073), type=pa.int64())]
            names = ["value"]
        elif workload == "retained_chain":
            arrays = [
                pa.array([value + 7 for value in range(32769) if value % 2 == 0], type=pa.int64())
            ]
            names = ["plus"]
        elif workload == "short_repeated_calls":
            arrays = [pa.array([496.0] * 101, type=pa.float64())]
            names = ["total"]
        elif workload == "wide_typed_plan":
            names = [f"c{index}" for index in range(257)]
            arrays = [
                pa.array([value + index for value in range(32)], type=pa.int64())
                for index in range(257)
            ]
        elif workload == "file_small_result":
            total = float(1000017 * 1000016 // 2)
            arrays = [pa.array([total], type=pa.float64())]
            names = ["total"]
        else:
            raise ValueError(f"unknown workload {workload!r}")
        return pa.Table.from_arrays(arrays, names=names)

    def open_arrow(self, path: Path) -> pa.Table:
        try:
            with path.open("rb") as source:
                try:
                    reader = ipc.open_file(source)
                except pa.ArrowInvalid:
                    source.seek(0)
                    reader = ipc.open_stream(source)
                return reader.read_all()
        except Exception as exc:
            raise RuntimeError(f"cannot read complete Arrow IPC result ({type(exc).__name__}: {exc})") from exc

    def validate_expected_schema_and_values(
        self, table: pa.Table, workload: str, key: tuple[str, int, str]
    ) -> None:
        expected = self.expected_table(workload)
        actual_names = table.schema.names
        if actual_names != expected.schema.names:
            self.fail(f"{key}: field order/names {actual_names!r} != {expected.schema.names!r}")
            return
        for index, (actual_field, expected_field) in enumerate(zip(table.schema, expected.schema)):
            if actual_field.type != expected_field.type:
                self.fail(
                    f"{key}: field {actual_field.name!r} logical type {actual_field.type} "
                    f"!= {expected_field.type}"
                )
        # Compare each complete column while leaving standalone nullability
        # unspecified; paired schemas below must still match exactly.
        for index, name in enumerate(expected.schema.names):
            if not table.column(index).equals(expected.column(index)):
                self.fail(f"{key}: column {name!r} differs from prescribed complete values")

    def validate_sample(self, entry: dict[str, Any]) -> None:
        workload = entry.get("workload")
        transport = entry.get("transport")
        pair = entry.get("pair")
        sample_id = entry.get("sample_id")
        key = (workload, pair, transport)
        if not isinstance(workload, str) or workload not in WORKLOADS:
            self.error(f"sample {sample_id!r}: unknown workload {workload!r}")
            return
        if (transport not in TRANSPORTS or isinstance(pair, bool) or not isinstance(pair, int)
                or pair not in EXPECTED_PAIRS):
            self.error(f"sample {sample_id!r}: invalid transport/pair {transport!r}/{pair!r}")
            return
        expected_id = f"{workload}-{'preflight' if pair == -1 else pair}-{transport}"
        self.require_equal(sample_id, expected_id, f"sample key {key}")
        if key in self.entries:
            self.error(f"duplicate sample tuple: {key!r}")
            return
        self.entries[key] = entry
        receipt_path = self.resolve_inside(f"samples/{sample_id}.json", f"{key} receipt")
        if receipt_path is None:
            return
        entry_receipt_hash = entry.get("receipt_sha256")
        receipt_hash = self.sha256(receipt_path)
        self.require_equal(receipt_hash, entry_receipt_hash, f"{key} receipt SHA-256")
        receipt = self.read_json(receipt_path, f"{key} receipt")
        if receipt is None:
            return
        for field, expected in (("status", "passed"), ("complete_values_verified", True),
                                ("sample_id", sample_id), ("workload", workload),
                                ("transport", transport)):
            self.require_equal(receipt.get(field), expected, f"{key} receipt {field}")
        self.require_equal(receipt.get("workflow_ns"), entry.get("workflow_ns"), f"{key} workflow_ns")
        if entry.get("returncode") != 0:
            self.fail(f"{key}: report returncode is {entry.get('returncode')!r}")

        host_path = self.resolve_inside(entry.get("host_observations"), f"{key} host observations")
        if host_path is not None:
            host_hash = self.sha256(host_path)
            self.require_equal(host_hash, entry.get("host_observations_sha256"), f"{key} host SHA-256")
            try:
                host_data = json.loads(host_path.read_text(encoding="utf-8"))
            except Exception as exc:
                self.error(f"{key}: cannot read host observation JSON ({type(exc).__name__}: {exc})")
                host_data = None
            if not isinstance(host_data, list):
                self.fail(f"{key}: host observations must be a nonempty JSON array")
            elif not host_data:
                self.fail(f"{key}: host observations array is empty")

        result_path = self.resolve_inside(receipt.get("result_file"), f"{key} Arrow result")
        result_hash = None
        result_bytes = None
        schema_record: list[dict[str, Any]] | None = None
        if result_path is not None:
            result_hash = self.sha256(result_path)
            result_bytes = result_path.stat().st_size
            self.require_equal(result_hash, receipt.get("result_sha256"), f"{key} result SHA-256")
            self.require_equal(result_bytes, receipt.get("result_bytes"), f"{key} result byte size")
            try:
                table = self.open_arrow(result_path)
                self.tables[key] = table
                self.validate_expected_schema_and_values(table, workload, key)
                schema_record = [
                    {"name": field.name, "type": str(field.type), "nullable": field.nullable}
                    for field in table.schema
                ]
                self.require_equal(str(table.schema), receipt.get("result_schema"), f"{key} receipt schema")
                if table.num_rows != receipt.get("rows"):
                    self.fail(f"{key}: Arrow row count {table.num_rows} != receipt {receipt.get('rows')!r}")
                if table.num_columns != receipt.get("columns"):
                    self.fail(f"{key}: Arrow column count {table.num_columns} != receipt {receipt.get('columns')!r}")
            except Exception as exc:
                self.error(f"{key}: {exc}")

        evidence = receipt.get("operation_evidence", [])
        expected_evidence = (0 if workload == "wide_typed_plan" and transport == "native"
                             else 101 if workload == "short_repeated_calls"
                             else 3 if workload == "retained_chain" else 1)
        if isinstance(evidence, list):
            self.require_equal(len(evidence), expected_evidence, f"{key} operation evidence count")
        if not isinstance(evidence, list):
            self.fail(f"{key}: operation_evidence is not an array")
        else:
            for index, item in enumerate(evidence):
                fields = item.get("fields") if isinstance(item, dict) else None
                self.validate_evidence_fields(fields, f"{key}.operation_evidence[{index}].fields")
        if workload == "wide_typed_plan":
            native_plan = receipt.get("native_plan_report")
            if isinstance(native_plan, dict):
                self.validate_evidence_fields(native_plan, f"{key}.native_plan_report")
            elif transport == "native":
                self.fail(f"{key}: native_plan_report is missing")

        self.sample_results.append(
            {
                "sample_id": sample_id,
                "workload": workload,
                "pair": pair,
                "transport": transport,
                "receipt_sha256": receipt_hash,
                "host_observations_sha256": self.sha256(host_path) if host_path else None,
                "result_sha256": result_hash,
                "result_bytes": result_bytes,
                "schema": schema_record,
            }
        )

    def compare_pairs(self) -> None:
        for workload in WORKLOADS:
            for pair in EXPECTED_PAIRS:
                native_key = (workload, pair, "native")
                subprocess_key = (workload, pair, "subprocess")
                native = self.tables.get(native_key)
                subprocess = self.tables.get(subprocess_key)
                if native is None or subprocess is None:
                    self.error(f"{workload} pair {pair}: one or both Arrow tables are unavailable")
                    continue
                if not native.schema.equals(subprocess.schema, check_metadata=True):
                    self.fail(f"{workload} pair {pair}: native/subprocess schemas differ (including nullability/metadata)")
                if not native.equals(subprocess):
                    self.fail(f"{workload} pair {pair}: native/subprocess Arrow tables differ")

    def validate_summary(self, report: dict[str, Any]) -> dict[str, Any]:
        computed: dict[str, Any] = {}
        summary = report.get("summary")
        if not isinstance(summary, dict):
            self.error("report.summary is missing or not an object")
            return computed
        for workload in WORKLOADS:
            timings: dict[str, list[int]] = {transport: [] for transport in TRANSPORTS}
            for transport in TRANSPORTS:
                for pair in range(5):
                    entry = self.entries.get((workload, pair, transport))
                    if entry is None:
                        self.error(f"summary {workload}: missing {transport} pair {pair}")
                        continue
                    value = entry.get("workflow_ns")
                    if isinstance(value, bool) or not isinstance(value, int):
                        self.error(f"summary {workload}: invalid workflow_ns for {transport} pair {pair}: {value!r}")
                        continue
                    if value <= 0:
                        self.fail(f"summary {workload}: nonpositive workflow_ns for {transport} pair {pair}: {value}")
                        continue
                    timings[transport].append(value)
            if any(len(values) != 5 for values in timings.values()):
                continue
            medians = {transport: statistics.median(values) / 1_000_000_000 for transport, values in timings.items()}
            ratios = [n / s for n, s in zip(timings["native"], timings["subprocess"])]
            reported = summary.get(workload)
            if not isinstance(reported, dict):
                self.error(f"report.summary.{workload} is missing or not an object")
                continue
            reported_medians = reported.get("median_seconds")
            if not isinstance(reported_medians, dict):
                self.error(f"report.summary.{workload}.median_seconds is missing")
            else:
                for transport, actual in medians.items():
                    self.compare_float(
                        reported_medians.get(transport), actual,
                        f"report.summary.{workload}.median_seconds.{transport}",
                    )
            reported_ratios = reported.get("paired_native_over_subprocess")
            if not isinstance(reported_ratios, list) or len(reported_ratios) != 5:
                self.fail(f"report.summary.{workload}.paired_native_over_subprocess must contain 5 paired values")
            else:
                for pair, (reported_ratio, actual_ratio) in enumerate(zip(reported_ratios, ratios)):
                    self.compare_float(
                        reported_ratio, actual_ratio,
                        f"report.summary.{workload}.paired_native_over_subprocess[{pair}]",
                    )
            computed[workload] = {
                "median_seconds": medians,
                "paired_native_over_subprocess": ratios,
                "sample_pairs_used": [0, 1, 2, 3, 4],
            }
        return computed

    def compare_float(self, observed: Any, expected: float, label: str) -> None:
        try:
            value = float(observed)
        except (TypeError, ValueError, OverflowError):
            self.fail(f"{label}: nonnumeric report value {observed!r}")
            return
        if not math.isclose(value, expected, rel_tol=1e-12, abs_tol=1e-15):
            self.fail(f"{label}: report {value!r} != independently computed {expected!r}")

    def run(self) -> dict[str, Any]:
        manifest_path = self.cohort / "manifest.json"
        report_path = self.cohort / "report.json"
        manifest = self.read_json(manifest_path, "manifest") if manifest_path.is_file() else None
        report = self.read_json(report_path, "report") if report_path.is_file() else None
        if manifest is None:
            self.error("manifest.json is missing or unreadable")
        if report is None:
            self.error("report.json is missing or unreadable")
        if manifest is not None:
            self.require_equal(manifest.get("repetitions"), 5, "manifest repetitions")
            driver_path = self.cohort / "driver.py"
            if not driver_path.is_file():
                self.error("driver.py is missing")
            else:
                self.require_equal(self.sha256(driver_path), manifest.get("driver_sha256"), "driver.py SHA-256")
            self.require_equal(manifest.get("workloads"), list(WORKLOADS), "manifest workload order")
        if report is not None:
            self.require_equal(report.get("status"), "passed", "report status")
            samples = report.get("samples")
            if not isinstance(samples, list):
                self.error("report.samples is missing or not an array")
                samples = []
            if len(samples) != 72:
                self.fail(f"report must contain exactly 72 sample entries; found {len(samples)}")
            seen_ids: set[str] = set()
            for entry in samples:
                if not isinstance(entry, dict):
                    self.error("report.samples contains a non-object entry")
                    continue
                sample_id = entry.get("sample_id")
                if not isinstance(sample_id, str) or sample_id in seen_ids:
                    self.fail(f"report sample_id is missing or duplicated: {sample_id!r}")
                else:
                    seen_ids.add(sample_id)
                self.validate_sample(entry)
            expected_keys = {
                (workload, pair, transport)
                for workload in WORKLOADS
                for pair in EXPECTED_PAIRS
                for transport in TRANSPORTS
            }
            observed_keys = set(self.entries)
            if observed_keys != expected_keys:
                self.fail(
                    f"sample tuple coverage differs: missing={sorted(expected_keys-observed_keys)!r}; "
                    f"extra={sorted(observed_keys-expected_keys)!r}"
                )
            self.compare_pairs()
            computed_summary = self.validate_summary(report)
        else:
            computed_summary = {}
        result = {
            "schema_version": "shardloom.native_python_measurement_verification.v1",
            "status": "passed" if not self.errors and not self.failures else "failed",
            "cohort": str(self.cohort),
            "manifest_sha256": self.sha256(manifest_path) if manifest_path.is_file() else None,
            "report_sha256": self.sha256(report_path) if report_path.is_file() else None,
            "counts": {
                "report_entries": len(report.get("samples", [])) if report and isinstance(report.get("samples"), list) else 0,
                "unique_sample_ids": len({
                    item.get("sample_id") for item in report.get("samples", [])
                    if isinstance(item, dict) and isinstance(item.get("sample_id"), str)
                } if report and isinstance(report.get("samples"), list) else set()),
                "validated_sample_receipts": len(self.sample_results),
                "validated_arrow_results": sum(item.get("result_sha256") is not None for item in self.sample_results),
                "paired_tables_compared": sum(
                    (workload, pair, "native") in self.tables and (workload, pair, "subprocess") in self.tables
                    for workload in WORKLOADS for pair in EXPECTED_PAIRS
                ),
                "failures": len(self.failures),
                "errors": len(self.errors),
            },
            "independent_summary": computed_summary,
            "sample_results": self.sample_results,
            "failures": self.failures,
            "errors": self.errors,
        }
        return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cohort", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    output = args.output.expanduser().resolve()
    if output.exists():
        print(f"refusing to overwrite existing output: {output}", file=sys.stderr)
        return 2
    verifier = Verifier(args.cohort)
    result = verifier.run()
    try:
        with output.open("x", encoding="utf-8") as stream:
            json.dump(result, stream, indent=2, sort_keys=True)
            stream.write("\n")
    except FileExistsError:
        print(f"refusing to overwrite existing output: {output}", file=sys.stderr)
        return 2
    except Exception as exc:
        print(f"could not write new output {output}: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2
    print(json.dumps({
        "status": result["status"],
        "output": str(output),
        "counts": result["counts"],
        "failures": result["failures"],
        "errors": result["errors"],
    }, sort_keys=True))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
