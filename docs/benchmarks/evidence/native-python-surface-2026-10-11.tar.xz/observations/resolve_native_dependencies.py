"""Resolve the explicitly selected native Python provider graph once."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tomllib

root = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
out = Path(__file__).resolve().parent
before = out / 'native-dependencies-before-1.lock'
with before.open('xb') as stream:
    stream.write((root / 'Cargo.lock').read_bytes())
path = out / 'native-dependencies-metadata-1.json'
with path.open('x') as stream:
    code = subprocess.call(['/Users/dylan/.cargo/bin/rustup', 'run', '1.99.0',
        'cargo', 'metadata', '--all-features', '--format-version', '1'],
        cwd=root, stdout=stream)
if code:
    raise SystemExit(code)
metadata = json.loads(path.read_text())
assert metadata['target_directory'] == '/Users/dylan/.cache/shardloom/cargo-target'
old = tomllib.loads(before.read_text())['package']
new = tomllib.loads((root / 'Cargo.lock').read_text())['package']
identity = lambda value: (value['name'], value['version'], value.get('source'))
old_ids = {identity(value) for value in old}
new_ids = {identity(value) for value in new}
removed = sorted(old_ids - new_ids)
assert not removed, removed
added = sorted(new_ids - old_ids)
nodes = []
for value in metadata['packages']:
    if identity(value) in added:
        nodes.append({key: value.get(key) for key in
            ('name', 'version', 'source', 'license', 'license_file', 'repository', 'rust_version', 'manifest_path')})
assert len(nodes) == len(added)
report = {'status': 'resolved_pending_license_review', 'removed': removed,
    'added': nodes, 'metadata_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
    'before_lock_sha256': hashlib.sha256(before.read_bytes()).hexdigest(),
    'after_lock_sha256': hashlib.sha256((root / 'Cargo.lock').read_bytes()).hexdigest(),
    'fallback_engine_added': False, 'license_review_complete': False}
with (out / 'native-dependencies-resolution-1.json').open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps(report), flush=True)
