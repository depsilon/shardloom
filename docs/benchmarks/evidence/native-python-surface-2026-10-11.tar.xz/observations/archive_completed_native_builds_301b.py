"""Losslessly retain superseded task-local debug libraries before packaging."""
from pathlib import Path
import hashlib
import json
import os
import stat
import subprocess
import sys
import time
import zipfile

ROOT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
sys.path.insert(0, '/Users/dylan/LocalData/shardloom/release-0.3.3-20260930')
sys.path.insert(0, '/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo/scripts')
from release_validation_guard import WorkloadGuard
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

ARCHIVE = ROOT / 'completed-native-bindings-301b.zip'
RECEIPT = ROOT / 'completed-native-bindings-301b.json'
PARTIAL = ROOT / 'completed-native-bindings-301b.zip.partial'
PATHS = [ROOT / f'native-binding-debug-{n}/_native.abi3.so'
         for n in [1, 2, 7, 8]]
assert all(not path.exists() for path in [ARCHIVE, RECEIPT, PARTIAL])
for index, run in [(1, 'native-python-library-build-1'), (2, 'native-python-library-build-2'), (7, 'native-python-build-267'), (8, 'native-python-build-272')]:
    completion = json.loads((ROOT / f'{run}.json').read_text())
    log = (ROOT / f'{run}.log').read_bytes()
    assert completion['status'] == 'passed' and completion['process_group_drained']
    assert hashlib.sha256(log).hexdigest() == completion['log_sha256']
    content = log.decode()
    build = json.loads(content[content.index('{\n  "schema_version": "shardloom.native_python_build.v1"'):])
    path = ROOT / f'native-binding-debug-{index}/_native.abi3.so'
    assert build['status'] == 'passed' and Path(build['library']) == path
    assert hashlib.sha256(path.read_bytes()).hexdigest() == build['library_sha256']
require_local_path(ROOT, Path.home(), sys.platform)
workload = WorkloadGuard()
workload.check()
last_check = 0.0

def guard():
    global last_check
    if time.monotonic() - last_check < 2:
        return
    workload.check()
    check_budgets(ROOT, ROOT / 'reserved-artifact', ROOT / 'logs',
                  min_free_bytes=12 * GIB, reserve_bytes=128 * MIB,
                  max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    last_check = time.monotonic()

def identity(path):
    value = path.lstat()
    assert stat.S_ISREG(value.st_mode) and value.st_nlink == 1
    return [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns,
            stat.S_IMODE(value.st_mode), value.st_blocks * 512]

def digest(stream):
    sha = hashlib.sha256()
    count = 0
    while block := stream.read(1 << 20):
        guard()
        sha.update(block)
        count += len(block)
    return sha.hexdigest(), count

opened = subprocess.run(['/usr/sbin/lsof', '-F', 'pfn', '--', *map(str, PATHS)],
                        text=True, capture_output=True)
assert opened.returncode in (0, 1) and not opened.stdout, opened.stdout
record = {'status': 'running', 'archive': str(ARCHIVE),
          'scope': 'superseded completed debug-1, debug-2, debug-7 and debug-8 libraries retained byte-for-byte in archive; current release-300 remains directly available',
          'free_bytes_before': os.statvfs(ROOT).f_bavail * os.statvfs(ROOT).f_frsize,
          'open_handle_check': 'no_open_handles', 'files': [],
          'restoration': 'Extract each recorded member to its original absolute path and restore its recorded mode; verify SHA-256.'}
try:
    with zipfile.ZipFile(PARTIAL, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
        for path in PATHS:
            guard()
            before = identity(path)
            member = path.relative_to(ROOT).as_posix()
            sha = hashlib.sha256()
            size = 0
            with path.open('rb') as source, archive.open(member, 'w', force_zip64=True) as target:
                while block := source.read(1 << 20):
                    guard()
                    target.write(block)
                    sha.update(block)
                    size += len(block)
            assert size == before[2] and identity(path) == before
            record['files'].append({'path': str(path), 'member': member,
                                    'identity': before, 'sha256': sha.hexdigest(), 'removed': False})
    with zipfile.ZipFile(PARTIAL) as archive:
        assert archive.namelist() == [entry['member'] for entry in record['files']]
        for entry in record['files']:
            with archive.open(entry['member']) as source:
                sha, size = digest(source)
            assert sha == entry['sha256'] and size == entry['identity'][2]
            assert identity(Path(entry['path'])) == entry['identity']
    os.replace(PARTIAL, ARCHIVE)
    with ARCHIVE.open('rb') as source:
        record['archive_sha256'], record['archive_bytes'] = digest(source)
    record['status'] = 'verified'
    RECEIPT.write_text(json.dumps(record, indent=2) + '\n')
    for entry in record['files']:
        guard()
        path = Path(entry['path'])
        assert identity(path) == entry['identity']
        path.unlink()
        entry['removed'] = True
        RECEIPT.write_text(json.dumps(record, indent=2) + '\n')
    record['status'] = 'passed'
finally:
    record['free_bytes_after'] = os.statvfs(ROOT).f_bavail * os.statvfs(ROOT).f_frsize
    RECEIPT.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ('status', 'free_bytes_before', 'free_bytes_after')}))
