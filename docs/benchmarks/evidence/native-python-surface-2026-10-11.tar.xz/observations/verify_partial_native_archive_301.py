"""Recover verified members of an interrupted archive without changing that archive."""
import hashlib
import json
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import zipfile

ROOT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
ARCHIVE = ROOT / 'completed-native-bindings-301b.zip.partial'
SOURCE_RECEIPT = ROOT / 'completed-native-bindings-301b.json'
RECEIPT = ROOT / 'completed-native-bindings-301b-recovery.json'
assert not RECEIPT.exists()
sys.path.insert(0, '/Users/dylan/LocalData/shardloom/release-0.3.3-20260930')
from release_validation_guard import WorkloadGuard
WorkloadGuard().check()

def digest(stream):
    sha = hashlib.sha256()
    count = 0
    while block := stream.read(1 << 20):
        sha.update(block)
        count += len(block)
    return sha.hexdigest(), count

def identity(path):
    value = path.lstat()
    assert stat.S_ISREG(value.st_mode) and value.st_nlink == 1
    return [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns,
            stat.S_IMODE(value.st_mode), value.st_blocks * 512]

source = json.loads(SOURCE_RECEIPT.read_text())
assert source['status'] == 'running' and len(source['files']) == 2
entries = source['files']
assert [entry['path'] for entry in entries] == [
    str(ROOT / f'native-binding-debug-{n}/_native.abi3.so') for n in (1, 2)]
assert all(not entry['removed'] for entry in entries)
archive_identity = identity(ARCHIVE)
with ARCHIVE.open('rb') as stream:
    archive_sha, archive_bytes = digest(stream)
with zipfile.ZipFile(ARCHIVE) as archive:
    assert archive.namelist() == [entry['member'] for entry in entries]
    for entry in entries:
        path = Path(entry['path'])
        assert identity(path) == entry['identity']
        with path.open('rb') as stream:
            assert digest(stream) == (entry['sha256'], entry['identity'][2])
        with archive.open(entry['member']) as stream:
            assert digest(stream) == (entry['sha256'], entry['identity'][2])
        assert identity(path) == entry['identity']
handles = subprocess.run(['/usr/sbin/lsof', '-n', '-P', str(ARCHIVE),
                          *[entry['path'] for entry in entries]],
                         text=True, capture_output=True)
assert handles.returncode == 1 and not handles.stdout and not handles.stderr
record = {
    'status': 'verified', 'archive': str(ARCHIVE), 'archive_sha256': archive_sha,
    'archive_bytes': archive_bytes, 'original_receipt': str(SOURCE_RECEIPT),
    'original_receipt_sha256': hashlib.sha256(SOURCE_RECEIPT.read_bytes()).hexdigest(),
    'interruption': 'The prior archive stopped before debug-7 because that source has six hardlinks; no originals were removed. Its closed two-member ZIP and original receipt remain unchanged.',
    'files': entries, 'open_handle_check': 'no_open_handles',
    'free_bytes_before': shutil.disk_usage(ROOT).free,
    'restoration': 'Extract the recorded member from the unchanged ZIP partial to its original path and restore the recorded mode; verify SHA-256.',
}
RECEIPT.write_text(json.dumps(record, indent=2) + '\n')
for entry in entries:
    WorkloadGuard().check()
    path = Path(entry['path'])
    assert identity(ARCHIVE) == archive_identity
    assert identity(path) == entry['identity']
    path.unlink()
    entry['removed'] = True
    RECEIPT.write_text(json.dumps(record, indent=2) + '\n')
with ARCHIVE.open('rb') as stream:
    assert digest(stream) == (archive_sha, archive_bytes)
record.update(status='passed', recovered_allocated_bytes=sum(entry['identity'][5] for entry in entries),
              free_bytes_after=shutil.disk_usage(ROOT).free)
RECEIPT.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ('status', 'recovered_allocated_bytes', 'free_bytes_before', 'free_bytes_after')}))
