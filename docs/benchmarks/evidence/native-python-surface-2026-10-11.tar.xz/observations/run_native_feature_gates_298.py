"""Check feature combinations and the declared minimum Rust version serially."""
import json
import argparse
from pathlib import Path
import subprocess
import time
from freeze_native_release_298 import sources

OUT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--run-id', default='298')
args = parser.parse_args()
assert args.run_id.isalnum()
frozen = json.loads((OUT / f'native-release-source-{args.run_id}.json').read_text())['source_sha256']
commands = [
    ('native-clippy', ['cargo', 'clippy', '--offline', '--locked', '--workspace',
       '--all-targets', '--features', 'release-user-surfaces', '--', '-D', 'warnings']),
    ('native-without-write', ['cargo', 'clippy', '--offline', '--locked', '-p',
       'shardloom-cli', '-p', 'shardloom-vortex', '--all-targets', '--no-default-features',
       '--features', 'shardloom-cli/vortex-local-primitives', '--', '-D', 'warnings']),
    ('write-only', ['cargo', 'check', '--offline', '--locked', '-p', 'shardloom-vortex',
       '--lib', '--no-default-features', '--features', 'vortex-write']),
    ('lean-workspace', ['cargo', 'check', '--offline', '--locked', '--workspace',
       '--no-default-features']),
    ('all-features', ['cargo', 'check', '--offline', '--locked', '--workspace', '--all-features']),
    ('msrv-lean', ['/Users/dylan/.cargo/bin/rustup', 'run', '1.96.0', 'cargo', 'check',
       '--offline', '--locked', '--workspace', '--no-default-features']),
    ('msrv-native', ['/Users/dylan/.cargo/bin/rustup', 'run', '1.96.0', 'cargo', 'check',
       '--offline', '--locked', '--workspace', '--all-targets', '--features',
       'release-user-surfaces']),
]
results = []
passed = False
try:
    assert sources() == frozen
    for name, command in commands:
        print(json.dumps({'gate': name, 'command': command}), flush=True)
        start = time.perf_counter()
        result = subprocess.run(command, check=False)
        results.append({'name': name, 'command': command, 'returncode': result.returncode,
                        'seconds': time.perf_counter() - start})
        print(json.dumps(results[-1]), flush=True)
        assert sources() == frozen
        if result.returncode:
            raise SystemExit(result.returncode)
    passed = True
finally:
    with (OUT / f'native-final-feature-gate-results-{args.run_id}.json').open('x') as stream:
        json.dump({'status': 'passed' if passed else 'failed', 'gates': results}, stream, indent=2)
        stream.write('\n')
