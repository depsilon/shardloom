"""Check that explicit row declarations retain the native chain's exact schema."""
import shardloom as sl

tables = {}
schema = {'value': {'type': 'int64', 'nullable': False}}
for transport in ('subprocess', 'native'):
    client = sl.ShardLoomClient(transport=transport, memory_bytes=1 << 30,
                               max_parallelism=2)
    try:
        ctx = sl.context(client=client, memory_bytes=1 << 30, max_parallelism=2)
        first = ctx.range(0, 33).collect(check=True)
        frame = (ctx.from_arrow_table(first, schema=schema, check=True) if transport == 'native'
                 else ctx.from_rows(first.python_objects, schema=schema))
        second = frame.filter('value % 2 = 0').collect(check=True)
        frame = (ctx.from_arrow_table(second, schema=schema, check=True) if transport == 'native'
                 else ctx.from_rows(second.python_objects, schema=schema))
        tables[transport] = frame.select('value + 7 AS plus').collect(check=True).to_arrow()
    finally:
        client.close()
    assert tables[transport].to_pydict() == {'plus': list(range(7, 40, 2))}
    assert not tables[transport].schema.field('plus').nullable
assert tables['native'].schema.equals(tables['subprocess'].schema, check_metadata=True)
assert tables['native'].equals(tables['subprocess'])
print('Both complete chains preserve the nonnullable int64 schema and all 17 values.')
