"""Verify Python source and packaging contracts against frozen native artifacts.

This is source/native-wheel acceptance, not publication of a new version. The
existing full release dry-run, registry-channel and finished-product aggregation
gates retain their own prerequisites and remain required by their CI/release lanes.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import unittest
from freeze_native_release_298 import sha, sources

OUT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--run-id', required=True)
args = parser.parse_args()
assert args.run_id.isalnum()
build_path = OUT / f'native-release-artifacts-{args.run_id}.json'
build = json.loads(build_path.read_text())
assert build['status'] == 'passed' and build['build_profile'] == 'release'
library = build['binding']['path']
assert os.environ['SHARDLOOM_REQUIRE_NATIVE_PYTHON'] == '1'
assert os.environ['SHARDLOOM_NATIVE_TEST_LIBRARY'] == library
assert sha(library) == build['binding']['sha256']
frozen = build['source_sha256']
results = []
passed = False
try:
    assert sources() == frozen
    for name, directory, pattern in [
        ('python-all', 'python/tests', 'test_*.py'),
        ('native-package-tools', 'scripts', 'test_*native_python*.py'),
        ('license-bundle-tools', 'scripts', 'test_python_license_bundle.py'),
    ]:
        start = time.perf_counter()
        suite = unittest.TestLoader().discover(directory, pattern=pattern)
        result = unittest.TextTestRunner(verbosity=2).run(suite)
        entry = {'name': name, 'directory': directory, 'pattern': pattern,
                 'tests': result.testsRun, 'failures': len(result.failures),
                 'errors': len(result.errors), 'skipped': len(result.skipped),
                 'seconds': time.perf_counter() - start}
        results.append(entry)
        print(json.dumps(entry), flush=True)
        assert result.wasSuccessful() and result.testsRun > 0 and not result.skipped, name
        assert sources() == frozen
    for name, command in [
        ('license-bundle', [sys.executable, '-B', 'scripts/check_python_license_bundle.py']),
        ('version-sources', [sys.executable, '-B', 'scripts/check_workspace_version_sources.py',
                            '--output', str(OUT / f'native-version-report-{args.run_id}.json')]),
        ('channel-source-contract', [sys.executable, '-B', 'scripts/check_package_channel_readiness.py',
             '--self-test', '--output', str(OUT / f'native-channel-source-report-{args.run_id}.json'),
             '--dependency-audit-report', str(OUT / 'native-dependency-report-299b.json')]),
        ('diff', ['git', 'diff', '--check']),
    ]:
        start = time.perf_counter()
        completed = subprocess.run(command, check=False)
        entry = {'name': name, 'command': command, 'returncode': completed.returncode,
                 'seconds': time.perf_counter() - start}
        results.append(entry)
        print(json.dumps(entry), flush=True)
        assert completed.returncode == 0, name
        assert sources() == frozen
    assert sha(library) == build['binding']['sha256']
    passed = True
finally:
    with (OUT / f'native-final-python-check-results-{args.run_id}.json').open('x') as stream:
        json.dump({'status': 'passed' if passed else 'failed', 'gates': results,
                   'build_evidence': str(build_path), 'build_evidence_sha256': sha(build_path),
                   'scope': 'native Python source, packaging tools and source contracts',
                   'publication_attempted': False, 'public_release_readiness_claim': False,
                   'separate_gates': {
                       'installed_native_wheel': 'required separately through prove_native_python_wheel.py',
                       'release_local_evidence': 'not asserted; uses full release dry-run and audit prerequisites',
                       'finished_product': 'not asserted; aggregates the broader v1 product evidence',
                       'ci_source': '.github/workflows/ci.yml',
                       'implementation_contract': 'docs/architecture/native-python-surface-2026-10-10.md',
                   }}, stream, indent=2)
        stream.write('\n')
