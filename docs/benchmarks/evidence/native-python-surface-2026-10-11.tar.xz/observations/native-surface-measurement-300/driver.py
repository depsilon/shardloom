#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Paired public Python workflows from one verified native wheel.

Run with that wheel's isolated interpreter under run_guarded.py. This driver
never publishes, changes a storage ceiling, or treats debug timings as release
measurements. All result values and every sample are retained, including failed
preflight observations. Pure kernel time is not inferred from a boundary clock.
"""

from __future__ import annotations

import argparse
import datetime as dt
import gc
import hashlib
import json
import os
from pathlib import Path
import platform
import resource
import statistics
import subprocess
import sys
import time


bootstrap = argparse.ArgumentParser(add_help=False)
bootstrap.add_argument('--repo-root', type=Path, required=True)
ROOT = bootstrap.parse_known_args()[0].repo_root.resolve(strict=True)
sys.path.insert(0, str(ROOT / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

MEMORY_BYTES = 1 << 30
PARALLELISM = 2
SIZES = dict(input_rows=131_073, output_rows=131_073, chain_rows=32_769,
             file_rows=1_000_017, short_calls=101, wide_columns=257, batch_rows=2048)
WORKLOADS = ('columnar_input', 'columnar_output', 'retained_chain',
             'short_repeated_calls', 'wide_typed_plan', 'file_small_result')


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def guard(output, reserve=128 * MIB):
    return check_budgets(output.parent, output / 'reserved-artifact', output / 'logs',
        min_free_bytes=12 * GIB, reserve_bytes=reserve,
        max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)


def load_install(proof_path):
    import pyarrow as pa
    import shardloom as sl
    from shardloom import _native as extension
    from shardloom import native

    proof = json.loads((proof_path / 'report.json').read_text())
    assert proof['status'] == 'passed' and proof['integration']['status'] == 'passed'
    assert proof['integration']['tests'] > 0 and proof['integration']['skipped'] == 0
    prefix = Path(sys.prefix).resolve()
    assert prefix == (proof_path / 'venv').resolve()
    assert prefix in Path(sl.__file__).resolve().parents
    library = Path(extension.__file__).resolve()
    binary = Path(proof['installed_load']['cli']).resolve()
    assert prefix in library.parents and prefix in binary.parents
    assert sha(library) == proof['integrity']['native_library_sha256']
    assert sha(binary) == proof['integrity']['cli_sha256']
    return sl, pa, native, binary, proof


def build_evidence(path, proof):
    record = json.loads(path.read_text())
    assert record['status'] == 'passed' and record['build_profile'] == 'release'
    for kind, proof_key in [('cli', 'cli_sha256'), ('binding', 'native_library_sha256')]:
        artifact = record[kind]
        assert sha(artifact['path']) == artifact['sha256'] == proof['integrity'][proof_key]
        receipt = json.loads(Path(artifact['build_receipt']).read_text())
        assert receipt['status'] == 'passed' and receipt['process_group_drained']
        assert '--release' in receipt['command']
        assert sha(artifact['build_receipt']) == artifact['build_receipt_sha256']
        assert sha(artifact['build_log']) == receipt['log_sha256']
    for name, digest in record['source_sha256'].items():
        assert sha(ROOT / name) == digest, name
    return {'path': str(path), 'sha256': sha(path), **record}


def observations():
    result = {'utc': dt.datetime.now(dt.timezone.utc).isoformat(),
              'load_average': os.getloadavg()}
    for name, who in [('self', resource.RUSAGE_SELF), ('children', resource.RUSAGE_CHILDREN)]:
        usage = resource.getrusage(who)
        result[name] = {
            'user_seconds': usage.ru_utime, 'system_seconds': usage.ru_stime,
            'lifetime_peak_rss_bytes': usage.ru_maxrss * (1 if sys.platform == 'darwin' else 1024),
            'minor_faults': usage.ru_minflt, 'major_faults': usage.ru_majflt,
        }
    return result


def host_sample(root_pid):
    rows = []
    output = subprocess.check_output(
        ['/bin/ps', '-axo', 'pid=,ppid=,pcpu=,rss=,comm='], text=True)
    for line in output.splitlines():
        values = line.split(None, 4)
        if len(values) != 5:
            continue
        pid, parent, cpu, rss, command = values
        rows.append({'pid': int(pid), 'parent_pid': int(parent), 'cpu_percent': float(cpu),
                     'rss_bytes': int(rss) * 1024, 'command': Path(command).name})
    descendants = {root_pid}
    while True:
        expanded = descendants | {row['pid'] for row in rows
                                  if row['parent_pid'] in descendants}
        if expanded == descendants:
            break
        descendants = expanded
    return {'utc': dt.datetime.now(dt.timezone.utc).isoformat(),
            'load_average': os.getloadavg(),
            'host_reported_cpu_percent_sum': sum(row['cpu_percent'] for row in rows),
            'host_reported_rss_sum_bytes': sum(row['rss_bytes'] for row in rows),
            'host_process_count': len(rows),
            'sample_processes': [row for row in rows if row['pid'] in descendants]}


def measured_process(command, output, env, log):
    process = subprocess.Popen(command, cwd=output, env=env,
                               stdout=log, stderr=subprocess.STDOUT)
    started = time.perf_counter()
    samples = []
    try:
        while True:
            samples.append(host_sample(process.pid))
            code = process.poll()
            if code is not None:
                return code, samples
            if time.perf_counter() - started > 180:
                raise subprocess.TimeoutExpired(command, 180)
            time.sleep(0.5)
    except BaseException:
        process.kill()
        process.wait()
        raise


def expected(workload):
    if workload == 'columnar_input':
        values = range(1024, SIZES['input_rows'])
        return {'id': list(values), 'value': [3 * i for i in values],
                'label': [None if i % 7 == 0 else f'label-{i % 31}' for i in values]}
    if workload == 'columnar_output':
        return {'value': list(range(SIZES['output_rows']))}
    if workload == 'retained_chain':
        return {'plus': [i + 7 for i in range(0, SIZES['chain_rows'], 2)]}
    if workload == 'short_repeated_calls':
        return {'total': [496.0] * SIZES['short_calls']}
    if workload == 'wide_typed_plan':
        return {f'c{i}': [value + i for value in range(32)]
                for i in range(SIZES['wide_columns'])}
    if workload == 'file_small_result':
        n = SIZES['file_rows']
        # The existing simple-aggregate contract returns nullable Float64.
        # This independently generated integer is exactly representable.
        total = n * (n - 1) // 2
        assert total < (1 << 53)
        return {'total': [float(total)]}
    raise ValueError(workload)


def evidence(report):
    envelope = report.envelope
    assert envelope.status == 'success'
    assert not report.fallback_attempted and not report.external_engine_invoked
    # Preserve execution evidence without duplicating full results inside JSON.
    # Complete values are saved independently as Arrow IPC after timing stops.
    fields = {field.key: field.value for field in envelope.fields
              if not (field.key.endswith(('_json', '_jsonl'))
                      or field.key in {'human_text', 'result_jsonl', 'result_values_json'})}
    return {'status': envelope.status, 'fields': fields}


def native_evidence(report):
    assert report['fallback_attempted'] == 'false'
    assert report['external_engine_invoked'] == 'false'
    return report


def result_table(frame, pa, stages, reports):
    start = time.perf_counter_ns()
    result = frame.collect(check=True)
    collected = time.perf_counter_ns()
    table = result.to_arrow()
    end = time.perf_counter_ns()
    stages['collection_ns'] += collected - start
    stages['arrow_export_ns'] += end - collected
    reports.append(result)
    return result, table


def streamed_table(frame, pa, stages, reports):
    start = time.perf_counter_ns()
    tables = []
    with frame.iter_batches(batch_rows=SIZES['batch_rows']) as stream:
        for batch in stream:
            tables.append(batch.to_arrow())
        assert stream.report is not None
        reports.append(stream.report)
    table = pa.concat_tables(tables)
    stages['stream_execution_delivery_export_ns'] += time.perf_counter_ns() - start
    return table


def sample(output, proof_path, workload, transport, sample_id):
    sl, pa, native, binary, _ = load_install(proof_path)
    manifest = json.loads((output / 'manifest.json').read_text())
    assert sha(__file__) == manifest['driver_sha256'], 'measurement driver changed'
    fixtures = {name: output / description['path'] for name, description in manifest['fixtures'].items()}
    for name, path in fixtures.items():
        assert sha(path) == manifest['fixtures'][name]['sha256']
    before = observations()
    direct_typed_plan = workload == 'wide_typed_plan' and transport == 'native'
    client = None if direct_typed_plan else sl.ShardLoomClient(
        binary=str(binary), transport=transport,
        use_persistent_worker=True if transport == 'subprocess' else None,
        memory_bytes=MEMORY_BYTES, max_parallelism=PARALLELISM, timeout=120)
    ctx = None if client is None else sl.context(
        client=client, memory_bytes=MEMORY_BYTES, max_parallelism=PARALLELISM)
    native_session = None
    reports = []
    tables = []
    stages = dict(input_conversion_admission_ns=0, plan_construction_ns=0,
                  collection_ns=0, arrow_export_ns=0, stream_execution_delivery_export_ns=0)
    setup_started = time.perf_counter_ns()
    row = {'status': 'running', 'workload': workload, 'transport': transport,
           'sample_id': sample_id, 'before': before, 'stages': stages,
           'pure_native_kernel_ns': None,
           'kernel_timing_scope': 'not separately observable through both public boundaries'}
    try:
        # Exclude interpreter/library loading and retained-worker startup from
        # the workflow clock; this comparison is not fresh-process vs embedding.
        if client is not None:
            assert client.status().status == 'success'
        input_table = None
        if workload == 'columnar_input':
            n = SIZES['input_rows']
            input_table = pa.table({
                'id': pa.array(range(n), type=pa.int64()),
                'value': pa.array((i * 3 for i in range(n)), type=pa.int64()),
                'label': pa.array((None if i % 7 == 0 else f'label-{i % 31}' for i in range(n)),
                                  type=pa.string()),
            })
            row['caller_input_bytes'] = input_table.nbytes
        if workload == 'short_repeated_calls':
            statement = f"SELECT SUM(value) AS total FROM '{fixtures['short']}'"
            retained_plan = ctx.sql(statement)
            warm = retained_plan.collect(check=True)
            assert warm.to_arrow().to_pydict() == {'total': [496]}
            del warm
        if direct_typed_plan:
            native_session = native.Session(native.ExecutionResources(MEMORY_BYTES, PARALLELISM))
        gc.collect()
        row['setup_ns'] = time.perf_counter_ns() - setup_started
        started = time.perf_counter_ns()
        if workload == 'columnar_input':
            step = time.perf_counter_ns()
            if transport == 'native':
                frame = ctx.from_arrow_table(input_table, check=True)
                row['input_api'] = 'from_arrow_table; native columnar import'
            else:
                def batches():
                    for batch in input_table.to_batches(max_chunksize=SIZES['batch_rows']):
                        yield batch.to_pylist()
                frame = ctx.from_batches(batches,
                    schema={'id': 'int64', 'value': 'int64', 'label': 'utf8'})
                row['input_api'] = 'from_batches; columnar-to-row conversion occurs during execution'
            stages['input_conversion_admission_ns'] += time.perf_counter_ns() - step
            step = time.perf_counter_ns()
            frame = frame.filter(sl.col('id') >= 1024).select('id', 'value', 'label')
            stages['plan_construction_ns'] += time.perf_counter_ns() - step
            tables.append(streamed_table(frame, pa, stages, reports))
        elif workload == 'columnar_output':
            step = time.perf_counter_ns()
            frame = ctx.range(0, SIZES['output_rows'])
            stages['plan_construction_ns'] += time.perf_counter_ns() - step
            tables.append(streamed_table(frame, pa, stages, reports))
        elif workload == 'retained_chain':
            step = time.perf_counter_ns()
            frame = ctx.range(0, SIZES['chain_rows'])
            stages['plan_construction_ns'] += time.perf_counter_ns() - step
            step = time.perf_counter_ns()
            first = frame.collect(check=True)
            stages['collection_ns'] += time.perf_counter_ns() - step
            reports.append(first)
            step = time.perf_counter_ns()
            frame = (ctx.from_arrow_table(first, check=True) if transport == 'native'
                     else ctx.from_rows(first.python_objects))
            stages['input_conversion_admission_ns'] += time.perf_counter_ns() - step
            step = time.perf_counter_ns()
            frame = frame.filter('value % 2 = 0')
            stages['plan_construction_ns'] += time.perf_counter_ns() - step
            step = time.perf_counter_ns()
            second = frame.collect(check=True)
            stages['collection_ns'] += time.perf_counter_ns() - step
            reports.append(second)
            step = time.perf_counter_ns()
            frame = (ctx.from_arrow_table(second, check=True) if transport == 'native'
                     else ctx.from_rows(second.python_objects))
            stages['input_conversion_admission_ns'] += time.perf_counter_ns() - step
            step = time.perf_counter_ns()
            frame = frame.select('value + 7 AS plus')
            stages['plan_construction_ns'] += time.perf_counter_ns() - step
            _, table = result_table(frame, pa, stages, reports)
            tables.append(table)
            row['chain_intermediates'] = ('retained native result owners' if transport == 'native'
                                          else 'explicit Python row objects')
        elif workload == 'short_repeated_calls':
            for _ in range(SIZES['short_calls']):
                _, table = result_table(retained_plan, pa, stages, reports)
                tables.append(table)
        elif workload == 'wide_typed_plan':
            step = time.perf_counter_ns()
            if transport == 'native':
                expression = native.Expression
                relation = native.Relation.scan(str(fixtures['short'])).project([
                    (f'c{i}', expression.column('value') + expression.literal(i))
                    for i in range(SIZES['wide_columns'])])
                plan = native_session.plan(relation)
                stages['plan_construction_ns'] += time.perf_counter_ns() - step
                step = time.perf_counter_ns()
                result = plan.collect()
                stages['collection_ns'] += time.perf_counter_ns() - step
                step = time.perf_counter_ns()
                table = pa.RecordBatchReader.from_stream(result).read_all()
                stages['arrow_export_ns'] += time.perf_counter_ns() - step
                row['native_plan_report'] = native_evidence(result.report)
            else:
                projection = ', '.join(f'value + {i} AS c{i}' for i in range(SIZES['wide_columns']))
                plan = ctx.sql(f"SELECT {projection} FROM '{fixtures['short']}'")
                stages['plan_construction_ns'] += time.perf_counter_ns() - step
                _, table = result_table(plan, pa, stages, reports)
            tables.append(table)
        elif workload == 'file_small_result':
            step = time.perf_counter_ns()
            plan = ctx.sql(f"SELECT SUM(value) AS total FROM '{fixtures['large']}'")
            stages['plan_construction_ns'] += time.perf_counter_ns() - step
            _, table = result_table(plan, pa, stages, reports)
            tables.append(table)
        else:
            raise ValueError(workload)
        returned = pa.concat_tables(tables)
        row['workflow_ns'] = time.perf_counter_ns() - started
        row['operation_evidence'] = [evidence(report) for report in reports]
        wanted = expected(workload)
        row['result_schema'] = str(returned.schema)
        assert returned.column_names == list(wanted)
        assert returned.to_pydict() == wanted, 'complete result differs from independent generator'
        for field in returned.schema:
            required_type = (pa.float64() if workload in ('short_repeated_calls', 'file_small_result')
                             else pa.string() if field.name == 'label' else pa.int64())
            assert field.type == required_type, (workload, field.name, field.type, required_type)
        result_path = output / 'results' / f'{sample_id}.arrow'
        with result_path.open('xb') as stream:
            with pa.ipc.new_file(stream, returned.schema) as writer:
                writer.write_table(returned)
        with result_path.open('rb') as stream:
            assert pa.ipc.open_file(stream).read_all().equals(returned)
        row.update(status='passed', complete_values_verified=True, rows=returned.num_rows,
            columns=returned.num_columns, arrow_logical_bytes=returned.nbytes,
            result_schema=str(returned.schema), result_file=str(result_path.relative_to(output)),
            result_sha256=sha(result_path), result_bytes=result_path.stat().st_size)
    except BaseException as error:
        row.update(status='failed', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        if client is not None:
            client.close()
        if native_session is not None:
            native_session.close()
        row['after_close'] = observations()
        row['os_counter_scope'] = ('sample process lifetime includes imports, setup, validation and cleanup; '
                                   'child peaks are separate maxima, not additive simultaneous RSS')
        save(output / 'samples' / f'{sample_id}.json', row)


def fixtures(output, native, pa):
    result = {}
    for name, rows in [('short', 32), ('large', SIZES['file_rows'])]:
        session = native.Session(native.ExecutionResources(MEMORY_BYTES, PARALLELISM))
        try:
            source = session.from_range('value', 0, 1, rows)
            plan = session.plan(native.Relation.scan('memory://fixture'),
                                sources=[('memory://fixture', source)])
            path = output / f'{name}.vortex'
            report = plan.write(path, 'write_vortex')
            reopened = session.plan(native.Relation.scan(str(path))).collect()
            table = pa.RecordBatchReader.from_stream(reopened).read_all()
            assert table.column_names == ['value'] and table.num_rows == rows
            assert table.column(0).to_pylist() == list(range(rows))
            assert pa.types.is_int64(table.schema.field(0).type)
            result[name] = {'path': path.name, 'rows': rows, 'sha256': sha(path),
                            'bytes': path.stat().st_size, 'write_report': report,
                            'reopen_report': native_evidence(reopened.report),
                            'complete_values_verified': True}
        finally:
            session.close()
    return result


def run(output, proof_path, build_path, repetitions):
    output = require_local_path(output.resolve(), Path.home(), sys.platform)
    assert not output.exists(), 'measurement output must be a new directory'
    guard(output)
    _, pa, native, _, proof = load_install(proof_path)
    builds = build_evidence(build_path, proof)
    output.mkdir()
    (output / 'samples').mkdir()
    (output / 'results').mkdir()
    (output / 'logs').mkdir()
    (output / 'driver.py').write_bytes(Path(__file__).read_bytes())
    lock = output.parent / '.native-python-measurement.lock'
    lock.mkdir()
    report = {'status': 'running', 'samples': [], 'publication_attempted': False}
    begin = time.perf_counter()
    try:
        physical = subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.memsize'], text=True).strip()
        model = subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.model'], text=True).strip()
        manifest = {
            'schema_version': 'shardloom.native_python_surface_measurement.v1',
            'created_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
            'python': sys.version, 'pyarrow': pa.__version__, 'platform': platform.platform(),
            'hardware_model': model, 'physical_ram_bytes': int(physical),
            'memory_allocation_bytes': MEMORY_BYTES, 'max_parallelism': PARALLELISM,
            'sizes': SIZES, 'workloads': WORKLOADS, 'repetitions': repetitions,
            'build_profile': 'release', 'wheel_proof': str(proof_path),
            'build_evidence': builds,
            'wheel_integrity': proof['integrity'], 'driver_sha256': sha(__file__),
            'baseline': 'same-source persistent CLI worker and admitted row-batch input/output',
            'candidate': 'same-source native owners; explicit typed plan in wide_typed_plan',
            'cache_policy': 'fixtures prehashed in each sample; OS cache uncontrolled, no cold-cache claim',
            'host_observation_policy': ('ps process-tree CPU/RSS observations every 0.5 seconds '
                'during each supervised child, identically for both sides; host RSS sums are '
                'reported process counters and can double-count shared pages'),
            'timing_boundary': ('workflow includes necessary input conversion/admission, declaration, execution, '
                'transport and Arrow return; excludes imports, client/worker startup, fixture creation, '
                'hashing, correctness verification, evidence writes and close'),
            'stage_boundary': ('collection includes execution and transport; streaming execution/delivery/export '
                'interleave and are timed together; stages are measured components, not an exhaustive '
                'partition of the workflow clock; no separate pure-kernel clock is inferred'),
            'order': 'one complete preflight pair, then five complete pairs; sides alternate per pair/workload',
            'fixtures': fixtures(output, native, pa),
        }
        save(output / 'manifest.json', manifest)
        env = {key: value for key, value in os.environ.items()
               if not key.startswith('SHARDLOOM_') and key not in {'PYTHONPATH', 'PYTHONHOME'}}
        for index, workload in enumerate(WORKLOADS):
            for pair in range(-1, repetitions):
                sides = ('subprocess', 'native') if (index + pair) % 2 == 0 else ('native', 'subprocess')
                for transport in sides:
                    guard(output)
                    sample_id = f'{workload}-{"preflight" if pair == -1 else pair}-{transport}'
                    command = [sys.executable, '-I', str(Path(__file__).resolve()),
                        '--repo-root', str(ROOT),
                        '--output-dir', str(output), '--wheel-proof', str(proof_path),
                        '--build-evidence', str(build_path),
                        '--sample', workload, '--transport', transport, '--sample-id', sample_id]
                    started = time.perf_counter()
                    with (output / 'logs' / f'{sample_id}.log').open('xb') as log:
                        returncode, host = measured_process(command, output, env, log)
                    host_path = output / 'samples' / f'{sample_id}-host.json'
                    save(host_path, host)
                    path = output / 'samples' / f'{sample_id}.json'
                    entry = {'sample_id': sample_id, 'pair': pair, 'workload': workload,
                             'transport': transport, 'returncode': returncode,
                             'supervised_sample_seconds': time.perf_counter() - started,
                             'host_observations': str(host_path.relative_to(output)),
                             'host_observations_sha256': sha(host_path)}
                    report['samples'].append(entry)
                    assert returncode == 0 and path.is_file(), sample_id
                    data = json.loads(path.read_text())
                    assert data['status'] == 'passed' and data['complete_values_verified']
                    entry['workflow_ns'] = data['workflow_ns']
                    entry['receipt_sha256'] = sha(path)
                    guard(output)
        report['summary'] = {}
        for workload in WORKLOADS:
            values = {side: [row['workflow_ns'] for row in report['samples']
                           if row['workload'] == workload and row['transport'] == side and row['pair'] >= 0]
                      for side in ('subprocess', 'native')}
            assert all(len(items) == repetitions for items in values.values())
            report['summary'][workload] = {
                'median_seconds': {side: statistics.median(items) / 1e9 for side, items in values.items()},
                'paired_native_over_subprocess': [n / p for n, p in zip(values['native'], values['subprocess'])],
            }
        for name, description in manifest['fixtures'].items():
            assert sha(output / description['path']) == description['sha256'], name
        assert build_evidence(build_path, proof) == builds
        assert sha(__file__) == manifest['driver_sha256'], 'measurement driver changed'
        report['status'] = 'passed'
    except BaseException as error:
        report.update(status='failed', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        report['complete_supervised_work_seconds'] = time.perf_counter() - begin
        save(output / 'report.json', report)
        lock.rmdir()
    print(json.dumps({'status': report['status'], 'summary': report['summary']}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo-root', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--wheel-proof', type=Path, required=True)
    parser.add_argument('--build-evidence', type=Path, required=True)
    parser.add_argument('--repetitions', type=int, default=5)
    parser.add_argument('--sample', choices=WORKLOADS)
    parser.add_argument('--transport', choices=('subprocess', 'native'))
    parser.add_argument('--sample-id')
    args = parser.parse_args()
    assert args.repetitions == 5, 'the declared protocol retains five complete pairs'
    if args.sample is None:
        run(args.output_dir, args.wheel_proof.resolve(), args.build_evidence.resolve(),
            args.repetitions)
    else:
        assert args.transport and args.sample_id
        sample(args.output_dir.resolve(), args.wheel_proof.resolve(), args.sample,
               args.transport, args.sample_id)


if __name__ == '__main__':
    main()
