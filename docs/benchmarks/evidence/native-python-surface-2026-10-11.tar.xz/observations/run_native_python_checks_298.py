"""Require complete Python and native packaging tests against frozen source."""
import json
import argparse
from pathlib import Path
import subprocess
import sys
import time
import unittest
from freeze_native_release_298 import sources

OUT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--run-id', default='298')
args = parser.parse_args()
assert args.run_id.isalnum()
frozen = json.loads((OUT / f'native-release-source-{args.run_id}.json').read_text())['source_sha256']
results = []
passed = False
try:
    assert sources() == frozen
    for name, directory, pattern in [
        ('python-all', 'python/tests', 'test_*.py'),
        ('native-package-tools', 'scripts', 'test_*native_python*.py'),
        ('license-bundle-tools', 'scripts', 'test_python_license_bundle.py'),
    ]:
        start = time.perf_counter()
        suite = unittest.TestLoader().discover(directory, pattern=pattern)
        result = unittest.TextTestRunner(verbosity=2).run(suite)
        entry = {'name': name, 'directory': directory, 'pattern': pattern,
                 'tests': result.testsRun, 'failures': len(result.failures),
                 'errors': len(result.errors), 'skipped': len(result.skipped),
                 'seconds': time.perf_counter() - start}
        results.append(entry)
        print(json.dumps(entry), flush=True)
        assert result.wasSuccessful() and result.testsRun > 0 and not result.skipped, name
        assert sources() == frozen
    for name, command in [
        ('license-bundle', [sys.executable, '-B', 'scripts/check_python_license_bundle.py']),
        ('version-sources', [sys.executable, '-B', 'scripts/check_workspace_version_sources.py']),
        ('channel-readiness', [sys.executable, '-B', 'scripts/check_package_channel_readiness.py',
                               '--require-local-evidence']),
        ('finished-product-contract', [sys.executable, '-B', 'scripts/check_finished_product_readiness.py']),
        ('diff', ['git', 'diff', '--check']),
    ]:
        start = time.perf_counter()
        completed = subprocess.run(command, check=False)
        entry = {'name': name, 'command': command, 'returncode': completed.returncode,
                 'seconds': time.perf_counter() - start}
        results.append(entry)
        print(json.dumps(entry), flush=True)
        assert completed.returncode == 0, name
        assert sources() == frozen
    passed = True
finally:
    with (OUT / f'native-final-python-check-results-{args.run_id}.json').open('x') as stream:
        json.dump({'status': 'passed' if passed else 'failed', 'gates': results}, stream, indent=2)
        stream.write('\n')
