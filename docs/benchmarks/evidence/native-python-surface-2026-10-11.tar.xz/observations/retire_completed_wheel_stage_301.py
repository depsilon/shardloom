"""Retire exact redundant files from one completed wheel proof; retain the wheel."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
PROOF = ROOT / 'native-wheel-proof-300b'
RECEIPT = ROOT / 'completed-wheel-stage-retirement-301.json'
assert not RECEIPT.exists()
sys.path.insert(0, '/Users/dylan/LocalData/shardloom/release-0.3.3-20260930')
from release_validation_guard import WorkloadGuard
WorkloadGuard().check()
report = json.loads((PROOF / 'report.json').read_text())
supervision = json.loads((ROOT / 'native-wheel-proof-300b.json').read_text())
assert report['status'] == supervision['status'] == 'passed'
assert supervision['process_group_drained'] and supervision['returncode'] == 0
wheel = PROOF / 'dist' / report['integrity']['wheel']

def digest(stream):
    result = hashlib.sha256()
    for block in iter(lambda: stream.read(1 << 20), b''):
        result.update(block)
    return result.hexdigest()

def file_hash(path):
    with path.open('rb') as stream:
        return digest(stream)

def identity(path):
    stat = path.lstat()
    assert path.is_file() and not path.is_symlink()
    return [stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_blocks * 512]

wheel_identity = identity(wheel)
assert file_hash(wheel) == report['integrity']['wheel_sha256']
roots = [PROOF / 'package/src',
         PROOF / 'package/build/lib.macosx-11.0-arm64-cpython-312']
members = [('shardloom/_native.abi3.so', report['integrity']['native_library_sha256']),
           ('shardloom/bin/macos-aarch64/shardloom', report['integrity']['cli_sha256'])]
entries = []
with zipfile.ZipFile(wheel) as archive:
    for member, expected in members:
        with archive.open(member) as stream:
            assert digest(stream) == expected
        for root in roots:
            path = root / member
            before = identity(path)
            assert file_hash(path) == expected and identity(path) == before
            entries.append(dict(path=str(path), identity=before, sha256=expected,
                                retained_wheel_member=member, removed=False))
paths = [entry['path'] for entry in entries]
handles = subprocess.run(['/usr/sbin/lsof', '-n', '-P', *paths], capture_output=True, text=True)
assert handles.returncode == 1 and not handles.stdout and not handles.stderr, handles
record = dict(status='verified', retained_wheel=str(wheel), wheel_identity=wheel_identity,
              wheel_sha256=report['integrity']['wheel_sha256'], files=entries,
              source_report_sha256=file_hash(PROOF / 'report.json'),
              supervisor_receipt_sha256=file_hash(ROOT / 'native-wheel-proof-300b.json'),
              open_handle_check='no_open_handles', free_bytes_before=shutil.disk_usage(ROOT).free,
              restoration='Extract each recorded member from the retained wheel to its original path; the retired stage requires restoration to rebuild; the successful installed virtual environment remains unchanged.')
RECEIPT.write_text(json.dumps(record, indent=2) + '\n')
for entry in entries:
    assert identity(wheel) == wheel_identity
    path = Path(entry['path'])
    assert identity(path) == entry['identity']
    path.unlink()
    entry['removed'] = True
    RECEIPT.write_text(json.dumps(record, indent=2) + '\n')
assert file_hash(wheel) == record['wheel_sha256']
record.update(status='passed', recovered_allocated_bytes=sum(e['identity'][4] for e in entries),
              free_bytes_after=shutil.disk_usage(ROOT).free)
RECEIPT.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ['status', 'recovered_allocated_bytes', 'free_bytes_before', 'free_bytes_after']}))
