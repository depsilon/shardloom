"""Compare accepted subquery source hashes with immutable Git trees."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import subprocess

import verify_stream_destination_integrated_sources_482 as immutable

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
HEAD = 'b6b585a45aadd144f6b90cc2053744544518897a'
SYNTHETIC = '4c4e47e105945cf13e6af9b289f88e0c93906caa'
TREE = 'f0154e68ad78a9693f603e1b18172dae70a45712'
ACCEPTED = OUT / 'stream-subquery-final-source-511.json'
ARTIFACTS = OUT / 'native-release-artifacts-streamsubquery509.json'
FREEZER = OUT / 'freeze_native_release_298.py'


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def selector_check():
    original = ast.parse(FREEZER.read_text())
    select = next(node.value for node in ast.walk(original)
                  if isinstance(node, ast.Assign)
                  and any(isinstance(target, ast.Name) and target.id == 'selected' for target in node.targets))
    other = ast.parse(Path(immutable.__file__).read_text())
    fn = next(node for node in other.body if isinstance(node, ast.FunctionDef) and node.name == 'selected')
    actual = fn.body[0].value

    class Normalize(ast.NodeTransformer):
        def visit_Name(self, node):
            return ast.copy_location(ast.Name(id='name' if node.id == 'path' else node.id, ctx=node.ctx), node)

    assert ast.dump(select, include_attributes=False) == ast.dump(Normalize().visit(actual), include_attributes=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--merged')
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    selector_check()
    revisions = dict(pr_head=HEAD, ci_merge=SYNTHETIC)
    if args.merged:
        revisions['merged'] = args.merged
    synthetic_path = OUT / 'stream-subquery-hosted-512/synthetic-merge-512.json'
    synthetic = json.loads(synthetic_path.read_text())
    assert synthetic['sha'] == SYNTHETIC
    assert [p['sha'] for p in synthetic['parents']] == ['ff9aa27338ca9f1ff5581f5a57603400f5aec926', HEAD]
    trees = {key: (synthetic['tree']['sha'] if key == 'ci_merge' else
                  subprocess.check_output(['git', 'rev-parse', rev + '^{tree}'], cwd=ROOT, text=True).strip())
             for key, rev in revisions.items()}
    assert set(trees.values()) == {TREE}
    source, records = immutable.immutable_source_map(HEAD)
    accepted = json.loads(ACCEPTED.read_text())['source_sha256']
    assert len(source) == len(accepted) == 2291
    assert {path: row['sha256'] for path, row in source.items()} == accepted
    assert all(mode in ('100644', '100755') for _, _, mode in records)
    artifacts = json.loads(ARTIFACTS.read_text())
    binaries = {}
    for kind in ('cli', 'binding'):
        row = artifacts[kind]
        binaries[kind] = identity(row['path'])
        assert binaries[kind] == {key: row[key] for key in ('path', 'bytes', 'sha256')}
    prior = artifacts['source_sha256']
    added = sorted(accepted.keys() - prior.keys())
    assert added == []
    assert not (prior.keys() - accepted.keys())
    changes = [path for path in accepted.keys() & prior.keys() if accepted[path] != prior[path]]
    assert sorted(changes) == ['scripts/check_user_surface_reference.py', 'shardloom-cli/src/sql_syntax.rs'], changes
    correction = json.loads((OUT / 'stream-subquery-verification-source-510.json').read_text())
    final = json.loads(ACCEPTED.read_text())
    for ref in [correction[k] for k in ('before', 'original', 'after', 'diff', 'helper')]:
        assert identity(ref['path']) == ref
    for ref in [final[k] for k in ('original_validator', 'final_validator', 'helper')]:
        assert identity(ref['path']) == ref
    original = Path(correction['original']['path']).read_text()
    after = subprocess.check_output(['git', 'show', HEAD + ':shardloom-cli/src/sql_syntax.rs'],
                                    cwd=ROOT, text=True)
    old = '            assert!(parsed.generic_expression_projections.is_empty());'
    new = '\n'.join(['            assert_eq!(', '                parsed.generic_expression_projections,',
                     '                [] as [ParsedGenericExpressionProjection; 0]', '            );'])
    marker = '#[cfg(test)]\n#[allow(clippy::too_many_lines)]\nmod tests {'
    assert original.count(old) == 1 and after == original.replace(old, new)
    assert marker in original and original.index(old) > original.index(marker)
    assert original.split(marker)[0] == after.split(marker)[0]
    assert source['shardloom-cli/src/sql_syntax.rs']['sha256'] == correction['after']['sha256']
    assert source['scripts/check_user_surface_reference.py']['sha256'] == final['final_validator']['sha256']
    assert correction['production_code_identical'] and not final['compiled_runtime_changed']
    report = dict(schema_version='shardloom.native_stream_subquery_integrated_sources.v1', status='passed',
        revisions=revisions, trees=trees, source_files=len(source), immutable_source=source,
        accepted=identity(ACCEPTED), artifact_manifest=identity(ARTIFACTS), binaries=binaries,
        changes_after_original_build=sorted(changes), added_after_original_build=added,
        synthetic_metadata=identity(synthetic_path), selector_ast_matches=True,
        helpers=[identity(__file__), identity(immutable.__file__), identity(FREEZER)],
        scope='Immutable source identity and retained binary identity only; local and hosted execution are separate evidence.')
    with Path(args.output).open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({key: report[key] for key in ('status', 'source_files', 'revisions', 'trees', 'changes_after_original_build')}))


if __name__ == '__main__':
    main()
