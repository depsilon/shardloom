"""Verify and archive source-bound VarBin hosted integration evidence."""
import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile

import accept_varbin_review_hosted_jobs_567 as jobs
import verify_varbin_review_integrated_sources_563 as sources

ROOT, OUT, RAW = sources.ROOT, sources.OUT, sources.DEST
HEAD, SYNTHETIC, TREE = sources.HEAD, sources.SYNTHETIC, sources.TREE
sys.path.insert(0,str(ROOT/'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def read(path):
    return json.loads(Path(path).read_text())


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(),path
    raw = path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=digest(raw))


def check(record):
    actual = identity(record['path'])
    assert all(actual[key] == record[key] for key in ('path','bytes','sha256'))


def save(path,value):
    Path(path).open('x').write(json.dumps(value,indent=2)+'\n')


def served(stage,revision):
    folder = RAW/(stage+'-served-564')
    report = read(folder/'report.json')
    assert report['status'] == 'passed' and report['stage'] == stage
    assert report['head'] == revision and report['reviewed_head'] == HEAD
    assert identity(report['helper']['path'])['sha256'] == report['helper']['sha256']
    checks = read(folder/'deployment-checks.json')
    assert checks['total_count'] == len(checks['check_runs']) <= 100
    workers = [row for row in checks['check_runs'] if row['name'] == 'Workers Builds: shardloom']
    assert len(workers) == 1
    worker = workers[0]
    assert worker['head_sha'] == revision and worker['status'] == 'completed' and worker['conclusion'] == 'success'
    assert all(report['deployment'][key] == worker[key] for key in report['deployment'])
    versions = re.findall(r'Version ID: ([0-9a-f-]{36})',worker['output']['summary'])
    assert len(versions) == 1
    pr = read(folder/'pull-request.json')
    assert pr['number'] == 1563 and pr['head']['sha'] == HEAD
    if stage == 'production':
        assert pr['merged'] and pr['merge_commit_sha'] == revision
    assert len(report['responses']) == len({row['source'] for row in report['responses']}) == 8
    for row in report['responses']:
        actual = (folder/row['response']).read_bytes()
        expected = subprocess.check_output(['git','show',revision+':'+row['source']],cwd=ROOT)
        assert row['http_status'] == 200 and row['source_preserved']
        assert row['observed_bytes'] == len(actual) and row['observed_sha256'] == digest(actual)
        assert row['expected_bytes'] == len(expected) and row['expected_sha256'] == digest(expected)
        assert row['raw_byte_identical'] == (actual == expected)
        assert read(folder/(row['response']+'.attempts.json')) == row['attempts']
        assert row['attempts'][-1]['status'] == 'passed' and 1 <= len(row['attempts']) <= 3
        if actual != expected:
            prefix = next(i for i,(a,b) in enumerate(zip(actual,expected)) if a != b)
            extra = len(actual)-len(expected)
            assert 0 < extra <= 16384 and row['source'].endswith('.html')
            inserted = actual[prefix:prefix+extra]
            assert actual[prefix+extra:] == expected[prefix:]
            assert b'/cdn-cgi/challenge-platform/' in inserted or b'static.cloudflareinsights.com/' in inserted
            assert row['insertion_bytes'] == extra and row['insertion_sha256'] == digest(inserted)
    return dict(report=report,deployment_version=versions[0])


def guarded(name):
    path = OUT/(name+'.json')
    receipt = read(path)
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup']
    assert identity(path.with_suffix('.log'))['sha256'] == receipt['log_sha256']
    return [path,path.with_suffix('.log')]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--merge',required=True)
    parser.add_argument('--capture',required=True)
    args = parser.parse_args()
    assert re.fullmatch(r'[0-9a-f]{40}',args.merge)
    assert re.fullmatch(r'capture-\d{8}T\d{6}Z',args.capture)
    destination = require_local_path(OUT/'varbin-review-hosted-packet-564',Path.home(),sys.platform)
    assert not destination.exists()
    check_budgets(OUT,destination,OUT/'logs',min_free_bytes=12*GIB,
        reserve_bytes=128*MIB,max_workspace_bytes=100*GIB,max_log_bytes=192*MIB)
    closeouts = {}
    for stage in ('premerge','postmerge'):
        report = read(RAW/(stage+'-567')/'report.json')
        assert report['status'] == 'passed' and report['head'] == HEAD and report['checks_passed'] == 44
        assert report['merge'] == (args.merge if stage == 'postmerge' else None)
        assert report['review_threads'] == 20 and report['unresolved_review_threads'] == 0
        assert len(report['correctness_replies']) == 2 and len(report['dismissed_alerts']) == 18
        assert report['code_review'] == dict(commit_sha=HEAD,has_any_findings=False,
            has_unresolved_findings=False,status='completed')
        assert report['review_coverage'] == dict(automated_review_head=HEAD,final_head=HEAD,
            automated_review_covers_final_head=True)
        for record in report['metadata']+[report['helper'],report['source_verification']]:
            check(record)
        raw_checks = read(RAW/(stage+'-567')/'checks.json')
        assert raw_checks['total_count'] == len(raw_checks['check_runs']) == 44
        assert all(row['head_sha'] == HEAD and row['status'] == 'completed'
            and row['conclusion'] == 'success' for row in raw_checks['check_runs'])
        closeouts[stage] = report
    receipt = read(RAW/'merge-receipt-564.json')
    assert receipt['isError'] is False and receipt['structuredContent']['merged'] is True
    assert receipt['structuredContent']['sha'] == args.merge
    source = read(RAW/'merged-sources-563.json')
    assert source['status'] == 'passed' and source['selector_ast_matches'] and source['all_selected_sources_match']
    assert source['revisions'] == dict(pr_head=HEAD,ci_merge=SYNTHETIC,merged=args.merge)
    assert set(source['trees'].values()) == {TREE}
    immutable,records = sources.immutable.immutable_source_map(args.merge)
    assert len(immutable) == source['source_files'] == 2371
    assert source['immutable_source'] == immutable
    assert {path:row['sha256'] for path,row in immutable.items()} == read(source['accepted']['path'])['source_sha256']
    assert all(mode in ('100644','100755') for _,_,mode in records)
    for record in [source['accepted'],source['artifact_manifest'],source['synthetic_metadata'],
        *source['helpers'],*source['binaries'].values(),source['local_index'],
        source['local_final_packet'],source['final_seal_receipt'],source['final_seal_log']]:
        check(record)
    assert source['runtime_unchanged_after_acceptance']
    assert len(source['documentation_and_evidence_paths']) == 31
    local = read(source['local_index']['path'])
    assert local['status'] == 'passed_local' and local['member_count'] == 19538
    assert local['independent_packet_audit_passed'] and local['test_only_source_transition_verified']
    runtime = read(RAW/('primary-acceptance-567-'+args.capture+'.json'))
    assert runtime['status'] == 'passed_all_six' and runtime['pending'] == []
    assert runtime['head'] == HEAD and runtime['synthetic'] == SYNTHETIC and runtime['tree'] == TREE
    for key in ('source_verification','capture','run','capture_helper','acceptance_helper','parser_helper'):
        check(runtime[key])
    assert len(runtime['jobs']) == 6 and {row['job_id']:row['name'] for row in runtime['jobs']} == jobs.JOBS
    wheels = []
    for row in runtime['jobs']:
        check(row['raw'])
        check(row['metadata'])
        metadata = read(row['metadata']['path'])
        assert metadata['head_sha'] == HEAD and metadata['status'] == 'completed' and metadata['conclusion'] == 'success'
        assert all(step['conclusion'] in ('success','skipped') for step in metadata['steps'])
        text = jobs.normalized(Path(row['raw']['path']))
        assert SYNTHETIC+':refs/remotes/pull/1563/merge' in text
        assert text.splitlines()[-1].startswith('Cleaning up orphan processes')
        if row['name'].startswith('Native Python wheel'):
            proof,offsets = jobs.machine_report(text,'shardloom.native_python_wheel_proof.v1')
            assert proof == row['proof'] and offsets == row['normalized_offsets']
            assert proof['integration'] == dict(tests=100,failures=0,errors=0,skipped=0,status='passed')
            assert proof['status'] == proof['uninstall_status'] == 'passed' and proof['installed_load']['isolated_install']
            assert proof['installed_load']['version'] == '0.6.0'
            assert all(step['returncode'] == 0 for step in proof['steps'])
            assert proof['publication_attempted'] is False and proof['performance_claim'] is False
            if 'ubuntu' in row['name']:
                assert proof['linux_audit']['status'] == 'passed' and proof['integrity']['linux_audit_verified']
            wheels.append(row['name'])
        elif row['job_id'] == 117291696842:
            proof,offsets = jobs.machine_report(text,'shardloom.python_test_shard_evidence.v1')
            assert proof == row['proof'] and offsets == row['normalized_offsets']
            assert proof['test_count'] == 626 and proof['module_count'] == 57 and proof['skipped_count'] == 14
            assert row['console_tests_run'] == 526 and proof['failure_count'] == proof['error_count'] == 0
        else:
            groups = [list(map(int,group)) for group in
                re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text,re.M)]
            expected = ([[949,0,0],[0,0,0],[6,0,0],[65,0,0],[44,0,0],[15,0,0]]
                if row['job_id'] == 117291696849
                else [[2897,0,27],[3443,0,0],[91,0,0],[73,0,0],[7,0,0],[67,0,0]])
            assert groups == row['result_groups'] == expected
            if row['job_id'] == 117291696865:
                assert len(row['new_native_tests']) == 25 and len(row['ignored_test_reasons']) == 27
                assert row['standalone_provider_groups'] == expected[1:]
                for test in row['new_native_tests']:
                    assert digest(jobs.source(test['source'])) == test['sha256']
                    assert text.splitlines().count('test '+test['observed_test_path']+' ... ok') == 1
    assert len(wheels) == 3 and sum(len(row['methods']) for row in runtime['wheel_binding_sources']) == 100
    for row in runtime['wheel_binding_sources']:
        assert digest(jobs.source(row['path'])) == row['sha256']
    selection_path = OUT/'varbin-ci-selection-primary-review-568b.json'
    selection = read(selection_path)
    assert selection['status'] == 'passed' and selection['tests_rerun'] is False
    for record in [*selection['inputs'].values(), selection['helper']]:
        check(record)
    for relative,record in selection['sources'].items():
        check(record['identity'])
        assert digest(jobs.source(relative)) == record['identity']['sha256']
        assert jobs.source(relative).decode() == record['text']
    assert [len(selection['changes'][name]['added']) for name in
        ('native','array','fsst','runend','zstd')] == [7,85,0,0,0]
    assert len(selection['env_gate_excerpts']) == 2 and len(selection['file_statistics_tests']) == 7
    deployments = dict(preview=served('preview',HEAD),production=served('production',args.merge))
    browsers = {stage:read(RAW/(stage+'-browser-564.json')) for stage in ('preview','production')}
    for stage,browser in browsers.items():
        assert browser['stage'] == stage and browser['head'] == (HEAD if stage == 'preview' else args.merge)
        assert browser['search']['query'] == 'buffer table' and browser['search']['result_pages'] == 3
        assert '3 results for buffer table' in browser['search']['text']
        assert browser['mobile_menu_navigation_passed'] and browser['console'] == []
        assert browser['desktop']['body'] <= browser['desktop']['width'] == 1280
        assert browser['mobile']['body'] <= browser['mobile']['width'] == 390
        assert browser['mobile_light']['theme'] == 'light' and browser['mobile']['theme'] == 'dark'
        assert browser['limits']['metadataText'] and browser['limits']['pending']
        assert browser['limits']['menuExpanded'] == 'false'
        expected_images = {stage+'-'+suffix+'-564.jpg'
            for suffix in ('desktop','search','mobile-dark','mobile-light','limits')}
        assert set(browser['screenshots']) == expected_images
        assert all((RAW/name).read_bytes().startswith(b'\xff\xd8\xff') for name in expected_images)
    limits = [
        'Browser observations cover the in-app browser, desktop and phone viewports, search and mobile navigation; no cross-browser matrix is claimed.',
        'The deployed reviewed pages retain their original hosted-pending wording. A later documentation closeout records subsequent completion.',
        'Automated review covers the exact final PR head and reports no findings. Two correctness threads and eighteen previously dismissed false-positive alert threads are resolved and preserved.',
        'The accepted premerge Full43 remains the query regression observation; no query rerun was used for merge or deployment proof.',
        'Published 0.6.0 packages remain immutable; installed-wheel proofs are CI builds, not a package publication.',
    ]
    report = dict(schema_version='shardloom.native_varbin_review_hosted_verification.v1',status='passed',
        recorded_at=datetime.now(timezone.utc).isoformat(),pr=1563,head=HEAD,merge=args.merge,synthetic=SYNTHETIC,
        checks_passed=44,source_files_verified=2371,trees=source['trees'],native_total=6578,
        native_library_tests=2897,standalone_provider_tests=3674,file_statistics_tests=7,
        native_manual_exclusions=27,new_native_tests=25,native_public_total=1079,
        wheel_lanes=wheels,wheel_tests_per_lane=100,core_discovered=626,core_run=526,core_skipped=14,
        core_modules=57,closeouts=closeouts,served=deployments,browsers=browsers,
        interpretation=runtime['interpretation'],test_selection_review=identity(selection_path),
        observation_limits=limits,
        local_acceptance=source['local_index'],driver=identity(__file__),
        publication_attempted=False,performance_claim=False)
    save(RAW/'verification-564.json',report)
    files = {'hosted/'+path.relative_to(RAW).as_posix():path for path in RAW.rglob('*') if path.is_file()}
    helpers = [
        Path(__file__),Path(jobs.__file__),Path(sources.__file__),Path(sources.immutable.__file__),
        OUT/'freeze_native_release_298.py',OUT/'verify_stream_subquery_integrated_sources_513.py',
        OUT/'accept_stream_dynamic_subquery_hosted_jobs_corrected_528.py',
        OUT/'native-release-source-varbinreview560.json',OUT/'native-release-artifacts-varbinreview560.json',
        OUT/'capture_varbin_review_served_564.py',OUT/'capture_varbin_review_closeout_567.py',
        OUT/'capture_varbin_review_closeout_564.py',OUT/'accept_varbin_review_hosted_jobs_564.py',
        OUT/'varbin-review-hosted-runtime-564.json',OUT/'varbin-review-hosted-runtime-564.log',
        OUT/'varbin-review-premerge-564.json',OUT/'varbin-review-premerge-564.log',
        OUT/'varbin-hosted-test-source-inventory-564.json',OUT/'varbin-hosted-helper-inventory-563.json',
        selection_path,OUT/'verify_varbin_ci_selection_568b.py',
        OUT/'verify_varbin_ci_selection_567.py',OUT/'verify_varbin_ci_selection_568.py',
        OUT/'varbin-ci-selection-review-567.json',OUT/'varbin-ci-selection-review-567.log',
        OUT/'varbin-ci-selection-review-568.json',OUT/'varbin-ci-selection-review-568.log',
        OUT/'run_guarded.py',ROOT/'scripts/local_uat_storage.py',Path(source['local_index']['path']),
        Path(source['local_final_packet']['path']),
    ]
    for name in (
        'varbin-review-integrated-source-563','varbin-review-preview-source-564',
        'varbin-review-hosted-log-capture-564','varbin-review-hosted-runtime-567',
        'varbin-review-premerge-567','varbin-review-merged-source-564',
        'varbin-review-postmerge-567','varbin-review-production-source-564',
        'varbin-ci-selection-review-568b'):
        helpers.extend(guarded(name))
    for path in helpers:
        name = 'support/'+path.name
        assert name not in files
        files[name] = path
    for name,path in files.items():
        assert not path.is_symlink() and path.is_file()
        if path.suffix.lower() in ('.jpg','.jpeg'):
            assert path.read_bytes().startswith(b'\xff\xd8\xff'),name
    assert sum(path.stat().st_size for path in files.values()) < 128*MIB
    destination.mkdir(exist_ok=False)
    archive = destination/'native-varbin-metadata-hosted-2026-10-16.tar.xz'
    index = destination/'native-varbin-metadata-hosted-2026-10-16.json'
    members = []
    with tarfile.open(archive,'x:xz') as stream:
        for name,path in sorted(files.items()):
            before = identity(path)
            payload = path.read_bytes()
            info = tarfile.TarInfo(name)
            info.size = len(payload)
            info.mode = 0o644
            stream.addfile(info,io.BytesIO(payload))
            assert identity(path) == before
            members.append(dict(name=name,bytes=len(payload),sha256=digest(payload)))
    with tarfile.open(archive,'r:xz') as stream:
        entries = stream.getmembers()
        assert len(entries) == len({row.name for row in entries}) == len(members)
        assert all(row.isfile() for row in entries) and {row.name for row in entries} == set(files)
        for member in members:
            payload = stream.extractfile(member['name']).read()
            assert len(payload) == member['bytes'] and digest(payload) == member['sha256']
            assert payload == files[member['name']].read_bytes()
    save(index,dict(schema_version='shardloom.native_varbin_review_hosted_packet.v1',status='passed',
        pr=1563,head=HEAD,merge=args.merge,synthetic=SYNTHETIC,checks_passed=44,source_files_verified=2371,
        native_total=6578,native_library_tests=2897,standalone_provider_tests=3674,file_statistics_tests=7,
        native_manual_exclusions=27,new_native_tests=25,native_public_total=1079,
        wheel_lanes=3,wheel_tests_per_lane=100,core_discovered=626,core_run=526,core_skipped=14,core_modules=57,
        served_responses_verified=16,production_deployment_check_complete=True,
        production_deployment_check_id=deployments['production']['report']['deployment']['id'],
        production_version=deployments['production']['deployment_version'],observation_limits=limits,
        review_coverage=closeouts['premerge']['review_coverage'],local_acceptance=source['local_index'],
        archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=identity(archive)['sha256']),
        members_verified=len(members),members=members,publication_attempted=False,performance_claim=False))
    check_budgets(OUT,destination,OUT/'logs',min_free_bytes=12*GIB,reserve_bytes=0,
        max_workspace_bytes=100*GIB,max_log_bytes=192*MIB)
    for path in (archive,index):
        target = ROOT/'docs/benchmarks/evidence'/path.name
        assert not target.exists()
        shutil.copy2(path,target)
        assert identity(path)['sha256'] == identity(target)['sha256']
    print(json.dumps(dict(status='passed',checks=44,wheel_lanes=3,sources=2371,
        served_responses=16,members=len(members),archive=identity(archive))))


if __name__ == '__main__':
    main()
