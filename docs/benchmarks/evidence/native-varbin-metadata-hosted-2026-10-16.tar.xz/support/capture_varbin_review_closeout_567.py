"""Capture exact PR/check/review state before or after the reviewed VarBin merge."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

from verify_varbin_review_integrated_sources_563 import HEAD, BASE, DEST

EXPECTED_THREADS = {
    'PRRT_kwDOSScs_c6tStSD', 'PRRT_kwDOSScs_c6tStSL',
    'PRRT_kwDOSScs_c6tTxbx', 'PRRT_kwDOSScs_c6tTxcZ',
    'PRRT_kwDOSScs_c6tTxcn', 'PRRT_kwDOSScs_c6tTxc0',
    'PRRT_kwDOSScs_c6tTxdF', 'PRRT_kwDOSScs_c6tTxdY',
    'PRRT_kwDOSScs_c6tTxdv', 'PRRT_kwDOSScs_c6tTxeJ',
    'PRRT_kwDOSScs_c6tTxeY', 'PRRT_kwDOSScs_c6tTxeo',
    'PRRT_kwDOSScs_c6tTxe4', 'PRRT_kwDOSScs_c6tTxfJ',
    'PRRT_kwDOSScs_c6tTxfT', 'PRRT_kwDOSScs_c6tTxfh',
    'PRRT_kwDOSScs_c6tTxf0', 'PRRT_kwDOSScs_c6tTxgL',
    'PRRT_kwDOSScs_c6tTxgd', 'PRRT_kwDOSScs_c6tTxgo',
}


def identity(path):
    raw = Path(path).read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage',choices=('premerge','postmerge'),required=True)
    parser.add_argument('--merged')
    parser.add_argument('--attempt',default='567')
    args = parser.parse_args()
    assert re.fullmatch(r'[a-z0-9-]+',args.attempt)
    assert (args.stage == 'postmerge') == bool(args.merged)
    if args.merged:
        assert re.fullmatch(r'[a-f0-9]{40}',args.merged)
    destination = DEST/(args.stage+'-'+args.attempt)
    destination.mkdir(exist_ok=False)
    records = []

    def api(name,arguments):
        completed = subprocess.run(['/opt/homebrew/bin/gh','api',*arguments],
            capture_output=True,timeout=60)
        assert completed.returncode == 0,completed.stderr.decode()
        assert len(completed.stdout) <= 8*1024*1024
        path = destination/(name+'.json')
        path.write_bytes(completed.stdout)
        records.append(identity(path))
        return json.loads(completed.stdout)

    pr = api('pull-request',['repos/depsilon/shardloom/pulls/1563'])
    checks = api('checks',[f'repos/depsilon/shardloom/commits/{HEAD}/check-runs?per_page=100'])
    statuses = api('statuses',[f'repos/depsilon/shardloom/commits/{HEAD}/status?per_page=100'])
    comments = api('issue-comments',['repos/depsilon/shardloom/issues/1563/comments?per_page=100'])
    query = '''query { repository(owner:"depsilon", name:"shardloom") {
      pullRequest(number:1563) { number headRefOid merged mergeCommit { oid }
        reviews(first:100) { pageInfo { hasNextPage } nodes { id state commit { oid } } }
        reviewThreads(first:100) { pageInfo { hasNextPage } nodes {
          id isResolved path comments(first:100) {
            pageInfo { hasNextPage } nodes { id databaseId body url }
          }
        } }
      } } }'''
    review = api('review-state',['graphql','-f','query='+query])
    assert pr['number'] == 1563 and pr['head']['sha'] == HEAD
    if args.stage == 'premerge':
        assert pr['state'] == 'open' and not pr['merged'] and not pr['draft']
        assert pr['base']['sha'] == BASE and pr['mergeable'] and pr['mergeable_state'] == 'clean'
    else:
        assert pr['merged'] and pr['merge_commit_sha'] == args.merged
    assert checks['total_count'] == len(checks['check_runs']) == 44
    assert len({row['id'] for row in checks['check_runs']}) == 44
    assert all(row['head_sha'] == HEAD and row['status'] == 'completed'
        and row['conclusion'] == 'success' for row in checks['check_runs'])
    assert statuses['sha'] == HEAD and statuses['total_count'] == 0 and statuses['statuses'] == []
    assert len(comments) < 100
    bot = [row for row in comments if row['user']['login'] == 'chatgpt-codex-connector[bot]']
    assert len(bot) == 1
    marker = re.search(r'<!-- codex-review-state:v1 (.*?) -->',bot[0]['body'])
    assert marker
    state = json.loads(marker.group(1))['code_review']
    assert state == dict(commit_sha=HEAD,has_any_findings=False,
        has_unresolved_findings=False,status='completed')
    reviewed = review['data']['repository']['pullRequest']
    assert reviewed['number'] == 1563 and reviewed['headRefOid'] == HEAD
    assert reviewed['merged'] == (args.stage == 'postmerge')
    if args.merged:
        assert reviewed['mergeCommit']['oid'] == args.merged
    for kind in ('reviews','reviewThreads'):
        assert reviewed[kind]['pageInfo']['hasNextPage'] is False
    assert all(row['state'] in ('COMMENTED','APPROVED','DISMISSED')
        for row in reviewed['reviews']['nodes'])
    threads = reviewed['reviewThreads']['nodes']
    assert {row['id'] for row in threads} == EXPECTED_THREADS
    assert all(row['isResolved'] for row in threads)
    assert all(not row['comments']['pageInfo']['hasNextPage'] for row in threads)
    replies = []
    for tid,comment_id,phrase in (
        ('PRRT_kwDOSScs_c6tStSD',4297038314,'Safe handle construction now validates'),
        ('PRRT_kwDOSScs_c6tStSL',4297038326,'Arbitrary replacement views now receive')):
        thread = next(row for row in threads if row['id'] == tid)
        assert any(row['databaseId'] == comment_id for row in thread['comments']['nodes'])
        fixed = [row for row in thread['comments']['nodes']
            if 'Fixed in 38867f16.' in row['body'] and phrase in row['body']]
        assert len(fixed) == 1
        replies.append(dict(thread_id=tid,original_comment_id=comment_id,reply=fixed[0]))
    alerts = []
    for number in (216,217,218,219,225,228,230,231,232,233,234,235,236,237,238,239,240,241):
        alert = api('dismissed-alert-'+str(number),
            ['repos/depsilon/shardloom/code-scanning/alerts/'+str(number)])
        assert alert['number'] == number and alert['state'] == 'dismissed'
        assert alert['dismissed_reason'] == 'false positive' and alert['dismissed_comment']
        alerts.append(dict(number=number,state=alert['state'],reason=alert['dismissed_reason'],
            comment=alert['dismissed_comment'],rule=alert['rule']['id'],
            location=alert['most_recent_instance']['location']))
    source = DEST/'pr-sources-563.json'
    source_record = json.loads(source.read_text())
    assert source_record['status'] == 'passed' and source_record['source_files'] == 2371
    report = dict(schema_version='shardloom.native_varbin_review_closeout.v1',
        status='passed',stage=args.stage,recorded_at=datetime.now(timezone.utc).isoformat(),
        head=HEAD,merge=args.merged,checks_passed=44,code_review=state,
        review_coverage=dict(automated_review_head=HEAD,final_head=HEAD,
            automated_review_covers_final_head=True),
        review_threads=len(threads),unresolved_review_threads=0,correctness_replies=replies,
        dismissed_alerts=alerts,source_verification=identity(source),
        metadata=records,helper=identity(Path(__file__)))
    with (destination/'report.json').open('x') as stream:
        json.dump(report,stream,indent=2)
        stream.write('\n')
    print(json.dumps(dict(status='passed',stage=args.stage,checks=44,
        resolved_threads=len(threads),report=str(destination/'report.json'))))


if __name__ == '__main__':
    main()

