"""Reconcile exact local/hosted test selection without running any tests."""
import hashlib
import itertools
import json
from pathlib import Path
import re

from accept_varbin_review_hosted_jobs_567 import normalized

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')


def identity(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def suites(text):
    blocks = re.findall(r'^running (\d+) tests?\n(.*?)^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;[^\n]*',text,re.M|re.S)
    result = []
    for total,body,passed,failed,ignored in blocks:
        counts = list(map(int,(passed,failed,ignored)))
        pairs = re.findall(r'^test (\S+) \.\.\. (ok|ignored(?:, [^\n]*)?)$',body,re.M)
        assert len(pairs) == len(dict(pairs)) == int(total) == sum(counts)
        assert counts[1] == 0
        assert sum(status=='ok' for _,status in pairs) == counts[0]
        assert sum(status.startswith('ignored') for _,status in pairs) == counts[2]
        result.append(dict(counts=counts,tests=dict(pairs)))
    return result


def delta(local,hosted):
    left,right = local['tests'],hosted['tests']
    missing = sorted(set(left)-set(right))
    assert not missing,missing
    return dict(local_counts=local['counts'],hosted_counts=hosted['counts'],
        added=sorted(set(right)-set(left)),missing=missing,
        status_changes=[dict(test=name,local=left[name],hosted=right[name])
            for name in sorted(left.keys()&right.keys()) if left[name]!=right[name]])


def main():
    inputs = {
        'hosted': OUT/'varbin-review-hosted-563/job-logs/capture-20261017T040243Z/job-117291696865.log',
        'local_native': OUT/'varbin-review-native-tests-560.log',
        'local_vendors': OUT/'varbin-review-vendor-tests-560.log',
        'worker_native': OUT/'native-worker-drain-native-tests-566b.log',
    }
    hosted = suites(normalized(inputs['hosted']))
    assert [row['counts'] for row in hosted] == [[2897,0,27],[3443,0,0],[91,0,0],[73,0,0],[7,0,0],[67,0,0]]
    local_native = [row for row in suites(inputs['local_native'].read_text()) if row['counts']==[2890,0,27]]
    assert len(local_native)==1
    local_vendor = suites(inputs['local_vendors'].read_text())
    assert [row['counts'] for row in local_vendor] == [[3357,0,1],[90,0,1],[73,0,0],[67,0,0]]
    names = ['native','array','fsst','runend','zstd']
    changes = {name:delta(local,current) for name,local,current in
        zip(names,[local_native[0],*local_vendor],[*hosted[:4],hosted[5]],strict=True)}
    assert [len(changes[name]['added']) for name in names] == [7,85,0,0,0]
    assert [len(changes[name]['status_changes']) for name in names] == [0,1,1,0,0]
    source_paths = [
        'shardloom-vortex/Cargo.toml','.github/workflows/ci.yml',
        'shardloom-vortex/src/encoded_read_executor.rs',
        'vendor/vortex-array/src/arrays/fixed_width/take/mod.rs',
        'vendor/vortex-array/src/arrays/fixed_width/take/avx2/mod.rs',
        'vendor/vortex-array/src/arrays/fixed_width/take/avx2/tests.rs',
        'vendor/vortex-array/src/arrays/fixed_width/take/avx2/gather.rs',
        'vendor/vortex-array/src/arrays/bool/compute/filter.rs',
        'vendor/vortex-array/src/arrays/varbinview/build_views.rs',
        'vendor/vortex-fsst/src/tests.rs',
        'vendor/vortex-layout/src/layouts/file_stats.rs',
        'vendor/vortex-layout/src/layouts/file_stats/tests.rs',
    ]
    sources = {name:dict(identity=identity(ROOT/name),text=(ROOT/name).read_text()) for name in source_paths}
    native = sources[source_paths[2]]['text']
    native_gates = []
    for name in changes['native']['added']:
        function = name.rsplit('::',1)[1]
        line = next(i for i,text in enumerate(native.splitlines()) if text.strip().startswith('fn '+function+'('))
        excerpt = native.splitlines()[max(0,line-8):line+1]
        assert 'feature = "vortex-encoded-read-spike"' in '\n'.join(excerpt)
        native_gates.append(dict(test=name,first_line=max(0,line-8)+1,lines=excerpt))
    avx = sources[source_paths[5]]['text']
    assert '#![cfg(all(target_arch = "x86_64", not(miri)))]' in avx
    for idx in ('u8','u16','u32','u64'):
        assert re.search(r'index_type => '+idx+r',\s*value_types => u32, i32, u64, i64, f32, f64',avx)
    for kind in ('simple','empty','invalid'):
        assert 'fn [<test_avx2_take_'+kind+'_ $IDX _ $VAL>]()' in avx
    prefix = 'arrays::fixed_width::take::avx2::tests::'
    macro = {prefix+f'test_avx2_take_{kind}_{idx}_{value}' for kind,idx,value in
        itertools.product(('simple','empty','invalid'),('u8','u16','u32','u64'),('u32','i32','u64','i64','f32','f64'))}
    direct = {prefix+name for name in re.findall(r'#\[test\]\s*fn (\w+)\(',avx)}
    extra = {
        'arrays::fixed_width::take::avx2::gather::tests::pack_i64_mask_for_i32_gather_preserves_lanes',
        'arrays::bool::compute::filter::tests::test_pext_fallback_matches_hardware',
    }
    assert len(macro)==72 and len(direct)==11
    assert set(changes['array']['added']) == macro|direct|extra
    for name in source_paths[3:5]:
        assert 'cfg(any(target_arch = "x86_64", target_arch = "x86"))' in sources[name]['text']
    assert re.search(r'#\[cfg\(target_arch = "x86_64"\)\]\s*#\[test\]\s*fn test_pext_fallback_matches_hardware',sources[source_paths[7]]['text'])
    env = []
    for key,path,function in (
        ('array',source_paths[8],'build_views_offsets_overflow_i32'),
        ('fsst',source_paths[9],'fsst_compress_offsets_overflow_i32')):
        change = changes[key]['status_changes'][0]
        assert change['test'].endswith('::'+function)
        assert change['local']=='ignored, because variable CI not found' and change['hosted']=='ok'
        lines = sources[path]['text'].splitlines()
        line = next(i for i,text in enumerate(lines) if text.strip().startswith('fn '+function+'('))
        excerpt = lines[max(0,line-5):line+1]
        assert '#[test_with::env(CI)]' in '\n'.join(excerpt)
        assert '#[test_with::no_env(VORTEX_SKIP_SLOW_TESTS)]' in '\n'.join(excerpt)
        env.append(dict(test=change['test'],path=path,first_line=max(0,line-5)+1,lines=excerpt))
    layout = sorted(hosted[4]['tests'])
    declared_layout = sorted('layouts::file_stats::tests::'+name for name in
        re.findall(r'#\[test\]\s*fn (\w+)\(',sources[source_paths[11]]['text']))
    assert layout==declared_layout and len(layout)==7
    worker = suites(inputs['worker_native'].read_text())
    assert len(worker)==1 and worker[0]['counts']==[2904,0,27]
    worker_delta = delta(hosted[0],worker[0])
    assert len(worker_delta['added'])==7 and not worker_delta['status_changes']
    assert sum(name.startswith('scheduler_bridge::lifetime_tests::') for name in worker_delta['added'])==4
    assert sum(name.startswith('universal_format_io::parquet_startup_tests::') for name in worker_delta['added'])==3
    result = dict(status='passed',schema_version='shardloom.varbin_ci_selection_review.v1',
        inputs={name:identity(path) for name,path in inputs.items()},sources=sources,
        changes=changes,native_gate_excerpts=native_gates,env_gate_excerpts=env,
        file_statistics_tests=layout,worker_delta=worker_delta,
        interpretation=dict(native='CI release-user-surfaces enables seven existing encoded-read-spike tests omitted by the earlier local command.',
            array='85 x86-specific tests are compiled in CI: 72 generated AVX2 cases, 11 direct AVX2 cases, one gather-mask test and one Boolean hardware comparison.',
            environment='Two offset-overflow tests ignored locally because CI was absent pass under the CI environment.',
            layout='The separate CI layout command runs all seven file_stats tests; it is absent from the four-provider local command set.',
            limitation='An AVX2 test may return early when runtime feature detection fails. This selection audit does not establish that SIMD instructions executed.'),
        leaf_inventory_disposition='Taken over by primary; incomplete 85-name inventory remains historical.',
        tests_rerun=False,helper=identity(__file__))
    destination=OUT/'varbin-ci-selection-primary-review-567.json'
    with destination.open('x') as stream:
        json.dump(result,stream,indent=2)
        stream.write('\n')
    print(json.dumps(dict(status='passed',hosted_total=6578,hosted_ignored=27,
        complete_added_name_counts={name:len(changes[name]['added']) for name in names},
        environment_transitions=len(env),layout_tests=7,worker_total=2904)))


if __name__=='__main__':
    main()
