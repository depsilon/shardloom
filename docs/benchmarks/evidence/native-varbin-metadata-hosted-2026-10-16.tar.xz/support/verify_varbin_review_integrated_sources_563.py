"""Bind accepted VarBin runtime and frozen artifacts to immutable PR/merge trees."""
import argparse
import json
from pathlib import Path
import subprocess

import verify_stream_destination_integrated_sources_482 as immutable
from verify_stream_subquery_integrated_sources_513 import selector_check, identity
from freeze_native_release_298 import ROOT, OUT, sources, save

HEAD = '38867f16a1d05f30461aad47ce96f4f7a6e3d46a'
BASE = '123f19e54ff9e0d9cdb4596f5ff9ff721f6b47f7'
SYNTHETIC = '727e119b45cf8c256a1e92e06fd665055b7289ca'
TREE = 'a1851653f576e2a9f3b61e62b2e2df4284b6051d'
ACCEPTED = '2d5d82a1e810a86d7da1827bcc9a2ec08993b65e'
DEST = OUT / 'varbin-review-hosted-563'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--merged')
    args = parser.parse_args()
    selector_check()
    accepted_path = OUT / 'native-release-source-varbinreview560.json'
    frozen = json.loads(accepted_path.read_text())
    accepted = frozen['source_sha256']
    assert frozen['head'] == ACCEPTED
    assert len(accepted) == 2371 and sources() == accepted
    DEST.mkdir(exist_ok=True)
    metadata_path = DEST / 'synthetic-merge-563.json'
    if not metadata_path.exists():
        raw = subprocess.check_output(['/opt/homebrew/bin/gh', 'api',
            'repos/depsilon/shardloom/git/commits/' + SYNTHETIC], timeout=45)
        metadata_path.open('xb').write(raw)
    synthetic = json.loads(metadata_path.read_text())
    assert synthetic['sha'] == SYNTHETIC and synthetic['tree']['sha'] == TREE
    assert [p['sha'] for p in synthetic['parents']] == [BASE, HEAD]
    revisions = dict(pr_head=HEAD, ci_merge=SYNTHETIC)
    if args.merged:
        revisions['merged'] = args.merged
    trees = {key:subprocess.check_output(['git','rev-parse',rev+'^{tree}'],
        cwd=ROOT,text=True).strip() for key,rev in revisions.items()}
    assert set(trees.values()) == {TREE}
    mapping, records = immutable.immutable_source_map(HEAD)
    assert {p:r['sha256'] for p,r in mapping.items()} == accepted
    assert all(mode in ('100644','100755') for _,_,mode in records)
    artifact_path = OUT / 'native-release-artifacts-varbinreview560.json'
    artifact = json.loads(artifact_path.read_text())
    assert artifact['head'] == ACCEPTED and artifact['source_sha256'] == accepted
    binaries = {key:identity(artifact[key]['path']) for key in ('cli','binding')}
    for key,row in binaries.items():
        assert row == {k:artifact[key][k] for k in ('path','bytes','sha256')}
    paths = subprocess.check_output(['git','diff','--name-only',ACCEPTED,HEAD],cwd=ROOT,text=True).splitlines()
    assert len(paths) == 31 and not any(immutable.selected(path) for path in paths)
    assert all(path.startswith(('docs/', 'website/', 'website-src/')) for path in paths)
    index_path = ROOT / 'docs/benchmarks/evidence/native-varbin-metadata-review-2026-10-16.json'
    index = json.loads(index_path.read_text())
    assert index['status'] == 'passed_local' and index['accepted_commit'] == ACCEPTED
    assert index['independent_packet_audit_passed'] and index['test_only_source_transition_verified']
    assert index['member_count'] == 19538 and len(index['archives']) == 4
    assert index['source_manifest']['sha256'] == identity(accepted_path)['sha256']
    for ref in [*index['archives'].values(), *[index[k] for k in ('manifest','audit','engine_timings')]]:
        actual = identity(index_path.parent / ref['file'])
        assert actual['sha256'] == ref['sha256'] and actual['bytes'] == ref['bytes']
    seal = OUT / 'varbin-review-final-seal-560.json'
    receipt = json.loads(seal.read_text())
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['head'] == ACCEPTED and receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup']
    assert identity(seal.with_suffix('.log'))['sha256'] == receipt['log_sha256']
    report = dict(schema_version='shardloom.native_varbin_review_integrated_sources.v1',
        status='passed',revisions=revisions,trees=trees,source_files=len(mapping),
        selector_ast_matches=True,all_selected_sources_match=True,immutable_source=mapping,
        accepted=identity(accepted_path),artifact_manifest=identity(artifact_path),binaries=binaries,
        synthetic_metadata=identity(metadata_path),runtime_unchanged_after_acceptance=True,
        documentation_and_evidence_paths=paths,local_index=identity(index_path),
        local_final_packet=identity(ROOT / 'docs/benchmarks/evidence/native-varbin-metadata-review-final-2026-10-16.json.xz'),
        final_seal_receipt=identity(seal),final_seal_log=identity(seal.with_suffix('.log')),
        helpers=[identity(__file__),identity(immutable.__file__),
            identity(OUT/'verify_stream_subquery_integrated_sources_513.py'),
            identity(OUT/'freeze_native_release_298.py')],
        scope='Immutable source and frozen artifact identity only; hosted runtime, review, merge and deployment are separate evidence.')
    destination = DEST / ('merged-sources-563.json' if args.merged else 'pr-sources-563.json')
    assert not destination.exists()
    save(destination,report)
    print(json.dumps(dict(status='passed',source_files=len(mapping),trees=trees,report=str(destination))))


if __name__ == '__main__':
    main()
