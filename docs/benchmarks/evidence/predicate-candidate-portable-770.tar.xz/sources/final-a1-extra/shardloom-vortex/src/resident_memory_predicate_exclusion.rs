//! Exact no-TRUE facts owned by one immutable source, never by a global cache.

use std::sync::{Arc, Mutex};

use shardloom_core::{PredicateExpr, Result, StatValue};
use shardloom_exec::live_memory::{LiveMemoryPool, MemoryLease};
use vortex::{
    array::dtype::{DType, PType},
    expr::Expression,
};

use super::{PreparedMemoryProjection, ResidentMemorySource};
use crate::resident_session::NativeExecutionContext;

#[cfg(all(test, feature = "vortex-write"))]
#[path = "resident_memory_predicate_exclusion_observation.rs"]
pub(crate) mod observation;

macro_rules! observe {
    ($field:ident) => {
        #[cfg(all(test, feature = "vortex-write"))]
        observation::record(|counts| counts.$field += 1);
    };
}

fn enabled() -> bool {
    #[cfg(all(test, feature = "vortex-write"))]
    {
        observation::enabled()
    }
    #[cfg(not(all(test, feature = "vortex-write")))]
    true
}

pub(super) struct Key {
    predicate: PredicateExpr,
    _credit: MemoryLease,
}

impl Drop for Key {
    fn drop(&mut self) {
        observe!(keys_released);
    }
}

#[derive(Default)]
pub(super) struct Slot(Mutex<Option<Arc<Key>>>);

impl Slot {
    pub(super) fn evict_under_pressure(&self, memory: &LiveMemoryPool) {
        if !enabled() {
            return;
        }
        let snapshot = memory.snapshot();
        if snapshot.limit_bytes.saturating_sub(snapshot.reserved_bytes) < 96 * 1024
            && let Ok(mut slot) = self.0.try_lock()
            && slot.take().is_some()
        {
            observe!(pressure_evictions);
        }
    }

    fn contains(&self, key: &Key) -> bool {
        observe!(lookups);
        let hit = self.0.try_lock().is_ok_and(|slot| {
            slot.as_ref()
                .is_some_and(|stored| stored.predicate == key.predicate)
        });
        if hit {
            observe!(hits);
        }
        hit
    }

    fn publish(&self, key: Arc<Key>) {
        // Missing an optional optimization under contention/poison is safe.
        // The original exact native evaluator remains the execution provider.
        if let Ok(mut slot) = self.0.try_lock() {
            if slot.replace(key).is_some() {
                observe!(replacements);
            }
            observe!(publications);
        }
    }
}

/// Provisional proof. Dropping it never publishes; only the final API success
/// boundary may consume it. The key's credit does not retain its source.
pub(crate) struct PendingFact {
    source: ResidentMemorySource,
    key: Arc<Key>,
}

impl PendingFact {
    pub(crate) fn publish(self) {
        self.source.0.predicate_exclusion.publish(self.key);
    }
}

impl ResidentMemorySource {
    pub(crate) fn prepare_predicate_projection(
        &self,
        columns: &[&str],
        filter: Option<Expression>,
        predicate: Option<&PredicateExpr>,
    ) -> Result<PreparedMemoryProjection> {
        let mut projection = self.prepare_projection(columns, filter, None)?;
        if enabled()
            && projection.filter.is_some()
            && !self.0.is_batch
            && self.0.generated_range.is_none()
            && (8192..=65_536).contains(&self.row_count())
            && let Some(predicate) = predicate
        {
            projection.predicate_key = self.admit_key(predicate);
        }
        Ok(projection)
    }

    fn admit_key(&self, predicate: &PredicateExpr) -> Option<Arc<Key>> {
        let memory = self.0.session.memory();
        let snapshot = memory.snapshot();
        if snapshot.limit_bytes < 16 * 1024 * 1024 {
            return None;
        }
        let mut leaves = 0;
        let bytes = 512_u64.checked_add(key_bytes(predicate, self.dtype(), 0, &mut leaves)?)?;
        if bytes > 16_384
            || snapshot.limit_bytes.saturating_sub(snapshot.reserved_bytes) < bytes + 65_536
        {
            return None;
        }
        // Reserve before cloning the predicate. Optional admission failure is
        // visible in shared-pool counters and leaves normal execution intact.
        let credit = memory.reserve(bytes).ok()?;
        let key = Arc::new(Key {
            predicate: predicate.clone(),
            _credit: credit,
        });
        observe!(keys_admitted);
        Some(key)
    }
}

impl PreparedMemoryProjection {
    pub(crate) fn can_stage_predicate_exclusion(&self) -> bool {
        self.predicate_key.is_some()
    }
    pub(crate) fn predicate_excludes_source(
        &self,
        context: &NativeExecutionContext<'_>,
    ) -> Result<bool> {
        let Some(key) = &self.predicate_key else {
            return Ok(false);
        };
        self.source.0.session.validate_execution_context(context)?;
        context.check_cancelled()?;
        Ok(enabled() && self.source.0.predicate_exclusion.contains(key))
    }

    /// The caller must have completed every source range with zero selected
    /// rows. Only the relational whole-source scanner calls this method.
    pub(crate) fn stage_predicate_exclusion(&self) -> Option<PendingFact> {
        if !enabled() {
            return None;
        }
        let key = self.predicate_key.as_ref()?;
        observe!(proofs_staged);
        Some(PendingFact {
            source: self.source.clone(),
            key: Arc::clone(key),
        })
    }
}

fn key_bytes(
    predicate: &PredicateExpr,
    dtype: &DType,
    depth: usize,
    leaves: &mut usize,
) -> Option<u64> {
    if depth > 2 {
        return None;
    }
    if let PredicateExpr::And(children) = predicate {
        if children.is_empty() || children.len() > 4 {
            return None;
        }
        return children.iter().try_fold(256_u64, |bytes, child| {
            bytes.checked_add(key_bytes(child, dtype, depth + 1, leaves)?)
        });
    }
    *leaves += 1;
    if *leaves > 4 {
        return None;
    }
    let column = predicate.column()?;
    if column.as_str().len() > 256 {
        return None;
    }
    let fields = dtype.as_struct_fields_opt()?;
    let index = fields.find(column.as_str())?;
    let field = fields.field_by_index(index)?;
    let owned_bytes = match (predicate, field) {
        (
            PredicateExpr::Compare {
                value: StatValue::Int64(_),
                ..
            },
            DType::Primitive(PType::I64, _),
        ) => 0,
        (
            PredicateExpr::InList {
                values,
                negated: false,
                ..
            },
            DType::Primitive(PType::I64, _),
        ) if !values.is_empty()
            && values.len() <= 32
            && values
                .iter()
                .all(|value| matches!(value, StatValue::Int64(_))) =>
        {
            values.len() as u64 * std::mem::size_of::<StatValue>() as u64
        }
        (
            PredicateExpr::StringContains {
                needle,
                negated: false,
                ..
            },
            DType::Utf8(_),
        ) if needle.len() <= 256 => needle.len() as u64,
        _ => return None,
    };
    Some(256 + column.as_str().len() as u64 + owned_bytes)
}
