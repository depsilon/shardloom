//! Thread-local test controls; production contains no experiment switches.

use shardloom_exec::compute_pool::CancellationToken;
use std::cell::RefCell;

#[derive(Clone, Copy, Default, serde::Serialize)]
pub(crate) struct Counts {
    pub(crate) keys_admitted: u64,
    pub(crate) lookups: u64,
    pub(crate) hits: u64,
    pub(crate) proofs_staged: u64,
    pub(crate) publications: u64,
    pub(crate) replacements: u64,
    pub(crate) pressure_evictions: u64,
    pub(crate) keys_released: u64,
}

struct State {
    active: bool,
    enabled: bool,
    counts: Counts,
    cancel_after_range: Option<(usize, CancellationToken)>,
    cancel_before_publish: Option<CancellationToken>,
}

thread_local! {
    static STATE: RefCell<State> = const { RefCell::new(State {
        active: false,
        enabled: true,
        counts: Counts {
            keys_admitted: 0, lookups: 0, hits: 0, proofs_staged: 0,
            publications: 0, replacements: 0, pressure_evictions: 0, keys_released: 0,
        },
        cancel_after_range: None,
        cancel_before_publish: None,
    }) };
}

pub(super) fn enabled() -> bool {
    STATE.with(|state| state.borrow().enabled)
}

pub(super) fn record(update: impl FnOnce(&mut Counts)) {
    STATE.with(|state| {
        let mut state = state.borrow_mut();
        if state.active {
            update(&mut state.counts);
        }
    });
}

pub(crate) fn after_range() {
    STATE.with(|state| {
        let mut state = state.borrow_mut();
        if let Some((remaining, token)) = &mut state.cancel_after_range {
            *remaining = remaining.saturating_sub(1);
            if *remaining == 0 {
                token.cancel();
                state.cancel_after_range = None;
            }
        }
    });
}

pub(crate) fn before_publish() {
    STATE.with(|state| {
        if let Some(token) = state.borrow_mut().cancel_before_publish.take() {
            token.cancel();
        }
    });
}

pub(crate) struct Session;

impl Session {
    pub(crate) fn start(enabled: bool) -> Self {
        STATE.with(|state| {
            let mut state = state.borrow_mut();
            assert!(
                !state.active,
                "predicate-exclusion observation is already active"
            );
            state.active = true;
            state.enabled = enabled;
            state.counts = Counts::default();
        });
        Self
    }

    pub(crate) fn snapshot(&self) -> Counts {
        STATE.with(|state| state.borrow().counts)
    }

    pub(crate) fn cancel_after_range(&self, ranges: usize, cancellation: CancellationToken) {
        assert!(ranges > 0);
        STATE.with(|state| state.borrow_mut().cancel_after_range = Some((ranges, cancellation)));
    }

    pub(crate) fn cancel_before_publish(&self, cancellation: CancellationToken) {
        STATE.with(|state| state.borrow_mut().cancel_before_publish = Some(cancellation));
    }
}

impl Drop for Session {
    fn drop(&mut self) {
        STATE.with(|state| {
            let mut state = state.borrow_mut();
            state.active = false;
            state.enabled = true;
            state.cancel_after_range = None;
            state.cancel_before_publish = None;
        });
    }
}
