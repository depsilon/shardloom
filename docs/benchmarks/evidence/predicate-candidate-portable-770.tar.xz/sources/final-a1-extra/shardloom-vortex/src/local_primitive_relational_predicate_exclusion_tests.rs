//! Whole-operation safety checks for immutable-source predicate facts.

use super::*;
use crate::{
    query_primitive::VortexSimpleAggregateMeasure,
    relational_query::{VortexRelationalAggregate, VortexRelationalLimit, VortexRelationalProject},
    resident_memory_source::{
        MemoryBatchSourceBuilder, MemoryColumn, MemoryColumnValues, MemorySourceBounds,
        predicate_exclusion::observation,
    },
};
use serde_json::json;
use shardloom_core::{
    ComparisonOp, ExprId, Expression, ExpressionKind, PredicateExpr, ScalarValue, StatValue,
};

fn numeric(session: &ResidentVortexSession, values: &[Option<i64>]) -> ResidentMemorySource {
    ResidentMemorySource::from_columns(
        session,
        &[
            MemoryColumn {
                name: "x",
                values: MemoryColumnValues::Int64(values),
            },
            MemoryColumn {
                name: "y",
                values: MemoryColumnValues::Int64NonNullable(&vec![100; values.len()]),
            },
        ],
        MemorySourceBounds::default(),
    )
    .unwrap()
}

fn predicate(column: &str, op: ComparisonOp, value: i64) -> PredicateExpr {
    PredicateExpr::Compare {
        column: ColumnRef::new(column).unwrap(),
        op,
        value: StatValue::Int64(value),
    }
}

fn absent() -> PredicateExpr {
    predicate("x", ComparisonOp::Gt, 7)
}

fn count_plan(predicate: Option<PredicateExpr>) -> VortexRelationalPlan {
    VortexRelationalPlan::Aggregate(Box::new(VortexRelationalAggregate {
        input: VortexRelationalPlan::Scan(VortexRelationalScan {
            source_uri: DatasetUri::new("memory://exclusion-safety").unwrap(),
            projection: shardloom_plan::ProjectionRequest::All,
            predicate,
        }),
        group_by: vec![],
        measures: vec![VortexSimpleAggregateMeasure::new(
            "count",
            None,
            "rows".into(),
        )],
    }))
}

fn prepared(
    session: &ResidentVortexSession,
    source: &ResidentMemorySource,
    plan: VortexRelationalPlan,
) -> PreparedVortexRelational {
    let mut resources = policy();
    resources.resource_envelope.memory_budget_bytes = session.memory().snapshot().limit_bytes;
    prepare_relational_with_schema_in_session(resources, session, |schemas| {
        schemas.register_memory_source(
            DatasetUri::new("memory://exclusion-safety").unwrap(),
            |_| Ok(source.clone()),
        )?;
        Ok(plan)
    })
    .unwrap()
}

fn count(operation: &PreparedVortexRelational, expected: u64) -> CollectedVortexRelational {
    let result = operation
        .collect_jsonl(&CancellationToken::default())
        .unwrap();
    assert_eq!(json_rows(&result), vec![json!({"rows":expected})]);
    assert!(result.execution.native_io_certificate.is_certified());
    assert!(
        !result
            .execution
            .native_io_certificate
            .side_effects
            .fallback_attempted
    );
    result
}

#[test]
fn predicate_exclusion_reuses_exact_complete_fact_and_releases_owners() {
    let observe = observation::Session::start(true);
    let session = ResidentVortexSession::new(32 << 20, 1).unwrap();
    let memory = session.memory().clone();
    let source = numeric(&session, &vec![Some(0); 16_384]);
    let first = prepared(&session, &source, count_plan(Some(absent())));
    let second = prepared(&session, &source, count_plan(Some(absent())));
    drop(count(&first, 0));
    let result = count(&second, 0);
    let proof = format!("{:?}", result.execution.native_io_certificate);
    assert!(proof.contains("scans_predicate_excluded=1 predicate_excluded_rows=16384"));
    assert_eq!(observe.snapshot().publications, 1);
    assert_eq!(observe.snapshot().hits, 1);
    drop(first);
    drop(second);
    drop(source);
    drop(session);
    assert_eq!(observe.snapshot().keys_released, 2);
    assert!(memory.snapshot().reserved_bytes > 0); // Returned JSON still owns its credit.
    assert_eq!(json_rows(&result), vec![json!({"rows":0})]);
    drop(result);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}

#[test]
fn predicate_exclusion_positive_last_block_prevents_whole_source_fact() {
    let observe = observation::Session::start(true);
    let session = ResidentVortexSession::new(32 << 20, 1).unwrap();
    let mut values = vec![Some(0); 16_385];
    values[16_384] = Some(100);
    let source = numeric(&session, &values);
    let operation = prepared(&session, &source, count_plan(Some(absent())));
    for _ in 0..2 {
        drop(count(&operation, 1));
    }
    assert_eq!(observe.snapshot().lookups, 2);
    assert_eq!(observe.snapshot().proofs_staged, 0);
    assert_eq!(observe.snapshot().hits, 0);
}

#[test]
fn predicate_exclusion_nulls_do_not_prove_negation_or_changed_predicates() {
    let observe = observation::Session::start(true);
    let session = ResidentVortexSession::new(32 << 20, 1).unwrap();
    let source = numeric(
        &session,
        &(0..8192)
            .map(|row| (row % 2 == 0).then_some(0))
            .collect::<Vec<_>>(),
    );
    let first = prepared(&session, &source, count_plan(Some(absent())));
    drop(count(&first, 0));
    for changed in [
        predicate("x", ComparisonOp::Gt, -1),
        predicate("x", ComparisonOp::Lt, 7),
        predicate("y", ComparisonOp::Gt, 7),
    ] {
        let expected = if changed.column().unwrap().as_str() == "y" {
            8192
        } else {
            4096
        };
        drop(count(
            &prepared(&session, &source, count_plan(Some(changed))),
            expected,
        ));
    }
    let negated = PredicateExpr::InList {
        column: ColumnRef::new("x").unwrap(),
        values: vec![StatValue::Int64(7)],
        negated: true,
    };
    drop(count(
        &prepared(&session, &source, count_plan(Some(negated))),
        4096,
    ));
    assert_eq!(observe.snapshot().hits, 0);
    assert_eq!(observe.snapshot().publications, 1);
    let all_null = numeric(&session, &vec![None; 8192]);
    let operation = prepared(&session, &all_null, count_plan(Some(absent())));
    drop(count(&operation, 0));
    drop(count(&operation, 0));
    assert_eq!(observe.snapshot().hits, 1);
}

#[test]
fn predicate_exclusion_replacement_source_and_foreign_session_cannot_reuse() {
    let observe = observation::Session::start(true);
    let session = ResidentVortexSession::new(32 << 20, 1).unwrap();
    let source = numeric(&session, &vec![Some(0); 8192]);
    drop(count(
        &prepared(&session, &source, count_plan(Some(absent()))),
        0,
    ));
    let replacement = numeric(&session, &vec![Some(100); 8192]);
    drop(count(
        &prepared(&session, &replacement, count_plan(Some(absent()))),
        8192,
    ));
    let identical = numeric(&session, &vec![Some(0); 8192]);
    drop(count(
        &prepared(&session, &identical, count_plan(Some(absent()))),
        0,
    ));
    assert_eq!(observe.snapshot().hits, 0);
    assert_eq!(observe.snapshot().publications, 2);
    let foreign = ResidentVortexSession::new(32 << 20, 1).unwrap();
    let result = prepare_relational_with_schema_in_session(policy(), &foreign, |schemas| {
        schemas.register_memory_source(
            DatasetUri::new("memory://exclusion-safety").unwrap(),
            |_| Ok(source.clone()),
        )?;
        Ok(count_plan(Some(absent())))
    });
    assert!(result.is_err());
}

#[test]
fn predicate_exclusion_slot_replacement_does_not_keep_older_predicate() {
    let observe = observation::Session::start(true);
    let session = ResidentVortexSession::new(32 << 20, 1).unwrap();
    let source = numeric(&session, &vec![Some(0); 8192]);
    let first = prepared(&session, &source, count_plan(Some(absent())));
    let changed = prepared(
        &session,
        &source,
        count_plan(Some(predicate("x", ComparisonOp::Gt, 8))),
    );
    for operation in [&first, &changed, &first] {
        drop(count(operation, 0));
    }
    assert_eq!(observe.snapshot().hits, 0);
    assert_eq!(observe.snapshot().publications, 3);
    assert_eq!(observe.snapshot().replacements, 2);
    assert_eq!(observe.snapshot().keys_released, 0); // Both prepared keys are live.
}

#[test]
fn predicate_exclusion_cancelled_partial_and_pre_cancelled_calls_do_not_publish() {
    let observe = observation::Session::start(true);
    let session = ResidentVortexSession::new(32 << 20, 1).unwrap();
    let source = numeric(&session, &vec![Some(0); 16_384]);
    let operation = prepared(&session, &source, count_plan(Some(absent())));
    let token = CancellationToken::default();
    token.cancel();
    assert!(operation.collect_jsonl(&token).is_err());
    assert_eq!(observe.snapshot().lookups, 0);
    let token = CancellationToken::default();
    observe.cancel_after_range(1, token.clone());
    assert!(operation.collect_jsonl(&token).is_err());
    assert_eq!(observe.snapshot().proofs_staged, 0);
    assert_eq!(observe.snapshot().publications, 0);
    drop(count(&operation, 0));
    assert_eq!(observe.snapshot().lookups, 2);
    assert_eq!(observe.snapshot().hits, 0);
    drop(count(&operation, 0));
    assert_eq!(observe.snapshot().hits, 1);
}

#[test]
fn predicate_exclusion_final_cancellation_discards_completed_scan_fact() {
    let observe = observation::Session::start(true);
    let session = ResidentVortexSession::new(32 << 20, 1).unwrap();
    let source = numeric(&session, &vec![Some(0); 8192]);
    let operation = prepared(&session, &source, count_plan(Some(absent())));
    let token = CancellationToken::default();
    observe.cancel_before_publish(token.clone());
    assert!(operation.collect_jsonl(&token).is_err());
    assert_eq!(observe.snapshot().proofs_staged, 1);
    assert_eq!(observe.snapshot().publications, 0);
    drop(count(&operation, 0));
    assert_eq!(observe.snapshot().hits, 0);
    assert_eq!(observe.snapshot().publications, 1);
}

#[test]
fn predicate_exclusion_late_consumer_and_reservation_failure_discard_pending_fact() {
    let observe = observation::Session::start(true);
    let session = ResidentVortexSession::new(32 << 20, 1).unwrap();
    let source = numeric(&session, &vec![Some(0); 8192]);
    let operation = prepared(&session, &source, count_plan(Some(absent())));
    for denial in [false, true] {
        let result = operation.for_each_batch_with_exclusion(
            &CancellationToken::default(),
            BATCH_ROWS,
            FileScanBatching::Output,
            None,
            true,
            |_, context| {
                if denial {
                    context.memory().reserve(32 << 20).map(|_| ())
                } else {
                    Err(failed("deliberate final consumer failure"))
                }
            },
        );
        assert!(result.is_err());
        assert_eq!(observe.snapshot().publications, 0);
    }
    assert_eq!(observe.snapshot().proofs_staged, 2);
    assert_eq!(session.memory().snapshot().denied_reservations, 1);
    drop(count(&operation, 0));
    assert_eq!(observe.snapshot().hits, 0);
    assert_eq!(observe.snapshot().publications, 1);
}

#[test]
fn predicate_exclusion_json_escape_failure_after_scan_does_not_publish() {
    let observe = observation::Session::start(true);
    let session = ResidentVortexSession::new(128 << 20, 1).unwrap();
    let source = numeric(&session, &vec![Some(0); 8192]);
    let plan = VortexRelationalPlan::Project(Box::new(VortexRelationalProject {
        input: count_plan(Some(absent())),
        expressions: vec![(
            "text".into(),
            Expression::new(
                ExprId::new("escaped").unwrap(),
                ExpressionKind::Literal(ScalarValue::Utf8("\n".repeat(4 * 1024 * 1024 + 1))),
            ),
        )],
    }));
    let operation = prepared(&session, &source, plan);
    assert!(
        operation
            .collect_jsonl(&CancellationToken::default())
            .is_err()
    );
    assert_eq!(observe.snapshot().proofs_staged, 1);
    assert_eq!(observe.snapshot().publications, 0);
    drop(operation);
    drop(count(
        &prepared(&session, &source, count_plan(Some(absent()))),
        0,
    ));
    assert_eq!(observe.snapshot().hits, 0);
}

#[test]
fn predicate_exclusion_limit_zero_does_not_establish_coverage() {
    let observe = observation::Session::start(true);
    let session = ResidentVortexSession::new(32 << 20, 1).unwrap();
    let source = numeric(&session, &vec![Some(100); 8192]);
    let limited = VortexRelationalPlan::Limit(Box::new(VortexRelationalLimit {
        input: count_plan(Some(absent())),
        offset: 0,
        count: 0,
    }));
    let operation = prepared(&session, &source, limited);
    assert!(
        json_rows(
            &operation
                .collect_jsonl(&CancellationToken::default())
                .unwrap()
        )
        .is_empty()
    );
    assert_eq!(observe.snapshot().lookups, 0);
    assert_eq!(observe.snapshot().publications, 0);
    drop(count(
        &prepared(&session, &source, count_plan(Some(absent()))),
        8192,
    ));
}

#[test]
fn predicate_exclusion_pressure_evicts_fact_and_bypasses_optional_key() {
    let observe = observation::Session::start(true);
    let session = ResidentVortexSession::new(32 << 20, 1).unwrap();
    let memory = session.memory().clone();
    let source = numeric(&session, &vec![Some(0); 8192]);
    drop(count(
        &prepared(&session, &source, count_plan(Some(absent()))),
        0,
    ));
    assert_eq!(observe.snapshot().keys_admitted, 1);
    assert_eq!(observe.snapshot().keys_released, 0); // Slot is the remaining owner.
    let snapshot = memory.snapshot();
    let pressure = memory
        .reserve(snapshot.limit_bytes - snapshot.reserved_bytes - 60 * 1024)
        .unwrap();
    // Bind the direct provider with the exact predicate before releasing pressure.
    let native_filter = super::super::super::predicate_to_vortex_expr(
        &absent(),
        source.dtype(),
        VortexQueryPrimitiveKind::FilterAndProject,
    )
    .unwrap();
    let projection = source
        .prepare_predicate_projection(&["x"], Some(native_filter), Some(&absent()))
        .unwrap();
    assert_eq!(observe.snapshot().pressure_evictions, 1);
    assert_eq!(observe.snapshot().keys_admitted, 1);
    assert_eq!(observe.snapshot().keys_released, 1);
    drop(pressure);
    assert_eq!(projection.execute_arrays().unwrap().row_count(), 0);
    drop(projection);
    drop(source);
    drop(session);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}

#[test]
fn predicate_exclusion_admission_respects_source_extent_and_small_grants() {
    for rows in [0, 8191, 8192, 65_536] {
        let observe = observation::Session::start(true);
        let session = ResidentVortexSession::new(32 << 20, 1).unwrap();
        let source = numeric(&session, &vec![Some(0); rows]);
        let operation = prepared(&session, &source, count_plan(Some(absent())));
        drop(count(&operation, 0));
        drop(count(&operation, 0));
        assert_eq!(observe.snapshot().hits, u64::from(rows >= 8192));
    }
    let observe = observation::Session::start(true);
    let session = ResidentVortexSession::new(8 << 20, 1).unwrap();
    let source = numeric(&session, &vec![Some(0); 8192]);
    let operation = prepared(&session, &source, count_plan(Some(absent())));
    drop(count(&operation, 0));
    drop(count(&operation, 0));
    assert_eq!(observe.snapshot().keys_admitted, 0);
}

#[test]
fn predicate_exclusion_large_completed_source_and_generated_range_remain_uncached() {
    let observe = observation::Session::start(true);
    let session = ResidentVortexSession::new(32 << 20, 1).unwrap();
    let mut builder =
        MemoryBatchSourceBuilder::new(&session, CancellationToken::default()).unwrap();
    for rows in std::iter::repeat_n(2048, 32).chain([1]) {
        builder
            .push_columns(&[MemoryColumn {
                name: "x",
                values: MemoryColumnValues::Int64(&vec![Some(0); rows]),
            }])
            .unwrap();
    }
    let large = builder.finish().unwrap();
    assert_eq!(large.row_count(), 65_537);
    let operation = prepared(&session, &large, count_plan(Some(absent())));
    drop(count(&operation, 0));
    drop(count(&operation, 0));
    let generated = ResidentMemorySource::from_int64_range(&session, "x", 0, 1, 8192).unwrap();
    let operation = prepared(
        &session,
        &generated,
        count_plan(Some(predicate("x", ComparisonOp::Lt, -1))),
    );
    drop(count(&operation, 0));
    assert_eq!(observe.snapshot().keys_admitted, 0);
}

#[test]
fn predicate_exclusion_concurrent_calls_preserve_exact_results() {
    let session = ResidentVortexSession::new(32 << 20, 1).unwrap();
    let memory = session.memory().clone();
    let source = numeric(&session, &vec![Some(0); 8192]);
    std::thread::scope(|scope| {
        for value in [7, 8, -1, 9] {
            let source = &source;
            let session = &session;
            scope.spawn(move || {
                let operation = prepared(
                    session,
                    source,
                    count_plan(Some(predicate("x", ComparisonOp::Gt, value))),
                );
                for _ in 0..4 {
                    drop(count(&operation, if value < 0 { 8192 } else { 0 }));
                }
            });
        }
    });
    assert_eq!(session.snapshot().completed_executions, 16);
    drop(source);
    drop(session);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}

#[test]
fn predicate_exclusion_membership_and_string_keys_preserve_exact_parameters() {
    let observe = observation::Session::start(true);
    let session = ResidentVortexSession::new(32 << 20, 1).unwrap();
    let source = numeric(&session, &vec![Some(0); 8192]);
    for (values, expected) in [(vec![1, 3], 0), (vec![0, 3], 8192), (vec![3, 1], 0)] {
        let predicate = PredicateExpr::InList {
            column: ColumnRef::new("x").unwrap(),
            values: values.into_iter().map(StatValue::Int64).collect(),
            negated: false,
        };
        drop(count(
            &prepared(&session, &source, count_plan(Some(predicate))),
            expected,
        ));
    }
    assert_eq!(observe.snapshot().hits, 0);
    assert_eq!(observe.snapshot().publications, 2);
    let text = vec![Some("alpha"); 8192];
    let source = ResidentMemorySource::from_columns(
        &session,
        &[MemoryColumn {
            name: "text",
            values: MemoryColumnValues::Utf8(&text),
        }],
        MemorySourceBounds::default(),
    )
    .unwrap();
    for (needle, negated, expected) in [
        ("absent", false, 0),
        ("alpha", false, 8192),
        ("absent", true, 8192),
    ] {
        let predicate = PredicateExpr::StringContains {
            column: ColumnRef::new("text").unwrap(),
            needle: needle.into(),
            negated,
        };
        drop(count(
            &prepared(&session, &source, count_plan(Some(predicate))),
            expected,
        ));
    }
    assert_eq!(observe.snapshot().hits, 0);
    assert_eq!(observe.snapshot().publications, 3);
}

#[test]
fn predicate_exclusion_unadmitted_predicates_keep_native_execution() {
    let observe = observation::Session::start(true);
    let session = ResidentVortexSession::new(32 << 20, 1).unwrap();
    let source = numeric(&session, &vec![Some(0); 8192]);
    for (predicate, expected) in [
        (None, 8192),
        (Some(PredicateExpr::AlwaysFalse), 0),
        (
            Some(PredicateExpr::IsNotNull {
                column: ColumnRef::new("x").unwrap(),
            }),
            8192,
        ),
        (Some(PredicateExpr::And(vec![absent(); 5])), 0),
        (
            Some(PredicateExpr::InList {
                column: ColumnRef::new("x").unwrap(),
                values: (1..=33).map(StatValue::Int64).collect(),
                negated: false,
            }),
            0,
        ),
    ] {
        drop(count(
            &prepared(&session, &source, count_plan(predicate)),
            expected,
        ));
    }
    let values = vec![Some(0.0); 8192];
    let float = ResidentMemorySource::from_columns(
        &session,
        &[MemoryColumn {
            name: "x",
            values: MemoryColumnValues::Float64(&values),
        }],
        MemorySourceBounds::default(),
    )
    .unwrap();
    let predicate = PredicateExpr::Compare {
        column: ColumnRef::new("x").unwrap(),
        op: ComparisonOp::Gt,
        value: StatValue::Float64(7.0),
    };
    drop(count(
        &prepared(&session, &float, count_plan(Some(predicate))),
        0,
    ));
    let text = vec![Some("alpha"); 8192];
    let strings = ResidentMemorySource::from_columns(
        &session,
        &[MemoryColumn {
            name: "text",
            values: MemoryColumnValues::Utf8(&text),
        }],
        MemorySourceBounds::default(),
    )
    .unwrap();
    let predicate = PredicateExpr::StringContains {
        column: ColumnRef::new("text").unwrap(),
        needle: "x".repeat(257),
        negated: false,
    };
    drop(count(
        &prepared(&session, &strings, count_plan(Some(predicate))),
        0,
    ));
    assert_eq!(observe.snapshot().keys_admitted, 0);
    assert_eq!(observe.snapshot().publications, 0);
}
