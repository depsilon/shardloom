//! Frozen complete-operation comparison of exact predicate-exclusion reuse.

use super::*;
use crate::{
    query_primitive::VortexSimpleAggregateMeasure,
    relational_query::{
        VortexRelationalAggregate, VortexRelationalNullOrder, VortexRelationalOrderKey,
        VortexRelationalSort,
    },
    resident_memory_source::{
        MemoryColumn, MemoryColumnValues, MemorySourceBounds,
        predicate_exclusion::observation as cache_observation, predicate_observation,
    },
};
use serde_json::{Value, json};
use sha2::{Digest as _, Sha256};
use shardloom_core::{ComparisonOp, PredicateExpr, StatValue};
use std::{collections::BTreeMap, io::Write as _, path::Path, time::Instant};

const PROTOCOL: &str = "predicate-exclusion-candidate-768-v1";

#[derive(Clone, Copy)]
struct Spec {
    rows: usize,
    family: &'static str,
    scenario: &'static str,
    calls: usize,
}

impl Spec {
    fn id(self) -> String {
        format!(
            "{}-{}-{}-{}",
            self.rows, self.family, self.scenario, self.calls
        )
    }

    fn parameter(self, call: usize) -> i64 {
        if self.scenario == "changed_parameters" {
            i64::try_from(call).unwrap()
        } else if self.scenario == "interleaved_parameters" {
            i64::try_from(call % 2).unwrap()
        } else {
            0
        }
    }

    fn plan(self, uri: DatasetUri, call: usize) -> VortexRelationalPlan {
        let k = self.parameter(call);
        let column = |name| ColumnRef::new(name).unwrap();
        let predicate = match self.family {
            "correlated" => Some(PredicateExpr::And(vec![
                PredicateExpr::Compare {
                    column: column("x"),
                    op: ComparisonOp::Gt,
                    value: StatValue::Int64(2047 + 2 * k),
                },
                PredicateExpr::Compare {
                    column: column("y"),
                    op: ComparisonOp::Lt,
                    value: StatValue::Int64(2048 + 2 * k),
                },
            ])),
            "membership" => Some(PredicateExpr::InList {
                column: column("x"),
                values: (0..16)
                    .map(|i| StatValue::Int64(1 + 32 * k + 2 * i))
                    .collect(),
                negated: false,
            }),
            "contains" => Some(PredicateExpr::StringContains {
                column: column("text"),
                needle: if k == 0 {
                    "::absent::".into()
                } else {
                    format!("::absent::{k}")
                },
                negated: false,
            }),
            "unfiltered" => None,
            _ => panic!("unknown frozen predicate family"),
        };
        let scan = VortexRelationalPlan::Scan(VortexRelationalScan {
            source_uri: uri,
            projection: shardloom_plan::ProjectionRequest::All,
            predicate,
        });
        let count = call.is_multiple_of(2);
        let aggregate = VortexRelationalPlan::Aggregate(Box::new(VortexRelationalAggregate {
            input: scan,
            group_by: if count { vec![] } else { vec![column("g")] },
            measures: vec![if count {
                VortexSimpleAggregateMeasure::new("count", None, "rows".into())
            } else {
                VortexSimpleAggregateMeasure::new("sum", Some(column("v")), "total".into())
            }],
        }));
        if count {
            aggregate
        } else {
            VortexRelationalPlan::Sort(Box::new(VortexRelationalSort {
                input: aggregate,
                keys: vec![VortexRelationalOrderKey {
                    column: column("g"),
                    descending: false,
                    nulls: Some(VortexRelationalNullOrder::Last),
                }],
            }))
        }
    }
}

fn source_dtype() -> DType {
    DType::struct_(
        vec![
            (
                "x".to_owned(),
                DType::Primitive(PType::I64, Nullability::Nullable),
            ),
            (
                "y".to_owned(),
                DType::Primitive(PType::I64, Nullability::Nullable),
            ),
            ("text".to_owned(), DType::Utf8(Nullability::Nullable)),
            (
                "g".to_owned(),
                DType::Primitive(PType::I64, Nullability::NonNullable),
            ),
            (
                "v".to_owned(),
                DType::Primitive(PType::I64, Nullability::NonNullable),
            ),
        ],
        Nullability::NonNullable,
    )
}

fn output_dtype(call: usize) -> DType {
    DType::struct_(
        if call.is_multiple_of(2) {
            vec![(
                "rows".to_owned(),
                DType::Primitive(PType::U64, Nullability::NonNullable),
            )]
        } else {
            vec![
                (
                    "g".to_owned(),
                    DType::Primitive(PType::I64, Nullability::NonNullable),
                ),
                (
                    "total".to_owned(),
                    DType::Primitive(PType::F64, Nullability::Nullable),
                ),
            ]
        },
        Nullability::NonNullable,
    )
}

struct Input {
    x: Vec<Option<i64>>,
    y: Vec<Option<i64>>,
    text: Vec<Option<String>>,
    g: Vec<i64>,
    v: Vec<i64>,
}

impl Input {
    fn new(spec: Spec) -> Self {
        let mut input = Self {
            x: vec![],
            y: vec![],
            text: vec![],
            g: vec![],
            v: vec![],
        };
        for row in 0..spec.rows {
            let present = !row.is_multiple_of(17) && spec.scenario != "all_null";
            let base = i64::try_from(2 * (row % 2048)).unwrap();
            let positive = spec.scenario == "positive";
            input
                .x
                .push(present.then_some(base + i64::from(positive && spec.family == "membership")));
            input.y.push(present.then_some(
                base - if positive && spec.family == "correlated" {
                    4096
                } else {
                    0
                },
            ));
            input.text.push(present.then(|| {
                let mut text = format!("item/{}/part-{}", row % 97, row % 11);
                if positive && spec.family == "contains" {
                    text.push_str("::absent::");
                }
                text
            }));
            input.g.push(i64::try_from(row % 8).unwrap());
            input.v.push(i64::try_from(row % 101).unwrap() - 50);
        }
        input
    }

    fn rows(&self) -> Value {
        json!(
            (0..self.x.len())
                .map(|r| json!({
                    "x":self.x[r], "y":self.y[r], "text":self.text[r], "g":self.g[r], "v":self.v[r],
                }))
                .collect::<Vec<_>>()
        )
    }

    fn expected(&self, spec: Spec, call: usize) -> Value {
        let k = spec.parameter(call);
        let mut count = 0_u64;
        let mut sums = BTreeMap::<i64, i64>::new();
        for r in 0..spec.rows {
            let selected = match spec.family {
                "correlated" => {
                    self.x[r].is_some_and(|x| x > 2047 + 2 * k)
                        && self.y[r].is_some_and(|y| y < 2048 + 2 * k)
                }
                "membership" => self.x[r].is_some_and(|x| (0..16).any(|i| x == 1 + 32 * k + 2 * i)),
                "contains" => self.text[r].as_ref().is_some_and(|s| {
                    s.contains(&if k == 0 {
                        "::absent::".into()
                    } else {
                        format!("::absent::{k}")
                    })
                }),
                "unfiltered" => true,
                _ => panic!("unknown frozen predicate family"),
            };
            if selected {
                count += 1;
                *sums.entry(self.g[r]).or_default() += self.v[r];
            }
        }
        if call.is_multiple_of(2) {
            json!([{"rows":count}])
        } else {
            // The frozen bounded integer sums are exactly representable in Float64.
            json!(
                sums.into_iter()
                    .map(
                        |(g, total)| json!({"g":g,"total":f64::from(i32::try_from(total).unwrap())})
                    )
                    .collect::<Vec<_>>()
            )
        }
    }
}

fn witness(root: &Path, value: &Value) -> String {
    let bytes = serde_json::to_vec(value).unwrap();
    let mut identity = String::with_capacity(64);
    for byte in Sha256::digest(&bytes) {
        use std::fmt::Write as _;
        write!(identity, "{byte:02x}").unwrap();
    }
    let path = root.join("witnesses").join(format!("{identity}.json"));
    if path.exists() {
        assert_eq!(fs::read(&path).unwrap(), bytes);
    } else {
        fs::OpenOptions::new()
            .create_new(true)
            .write(true)
            .open(path)
            .unwrap()
            .write_all(&bytes)
            .unwrap();
    }
    identity
}

fn matrix(rows: usize) -> Vec<Spec> {
    let mut result = Vec::new();
    for family in ["correlated", "membership", "contains"] {
        for scenario in [
            "no_true",
            "positive",
            "all_null",
            "changed_parameters",
            "replaced_source",
            "interleaved_parameters",
        ] {
            for calls in [1, 2, 4] {
                result.push(Spec {
                    rows,
                    family,
                    scenario,
                    calls,
                });
            }
        }
    }
    for calls in [1, 2, 4] {
        result.push(Spec {
            rows,
            family: "unfiltered",
            scenario: "unfiltered",
            calls,
        });
    }
    result
}

#[allow(clippy::too_many_lines)] // Keep the frozen lifecycle and complete witnesses together.
fn workflow(
    root: &Path,
    spec: Spec,
    mode: &str,
    role: &str,
    cohort: &str,
    sample: usize,
    warmup: bool,
) -> Value {
    let input = Input::new(spec);
    let text = input.text.iter().map(Option::as_deref).collect::<Vec<_>>();
    let expected = (0..spec.calls)
        .map(|call| input.expected(spec, call))
        .collect::<Vec<_>>();
    let expected_schemas = (0..spec.calls)
        .map(|call| serde_json::to_value(output_dtype(call)).unwrap())
        .collect::<Vec<_>>();
    let expected_witnesses = expected
        .iter()
        .map(|v| witness(root, v))
        .collect::<Vec<_>>();
    let schema_witnesses = expected_schemas
        .iter()
        .map(|v| witness(root, v))
        .collect::<Vec<_>>();
    let source_rows_witness = witness(root, &input.rows());
    let source_schema_witness = witness(root, &serde_json::to_value(source_dtype()).unwrap());
    let observer = predicate_observation::Session::start(true);
    let cache = cache_observation::Session::start(role == "candidate");
    let started = Instant::now();
    let session = ResidentVortexSession::new(32 << 20, 1).unwrap();
    let memory = session.memory().clone();
    let source_instances = if spec.scenario == "replaced_source" {
        spec.calls
    } else {
        1
    };
    let sources = (0..source_instances)
        .map(|_| {
            ResidentMemorySource::from_columns(
                &session,
                &[
                    MemoryColumn {
                        name: "x",
                        values: MemoryColumnValues::Int64(&input.x),
                    },
                    MemoryColumn {
                        name: "y",
                        values: MemoryColumnValues::Int64(&input.y),
                    },
                    MemoryColumn {
                        name: "text",
                        values: MemoryColumnValues::Utf8(&text),
                    },
                    MemoryColumn {
                        name: "g",
                        values: MemoryColumnValues::Int64NonNullable(&input.g),
                    },
                    MemoryColumn {
                        name: "v",
                        values: MemoryColumnValues::Int64NonNullable(&input.v),
                    },
                ],
                MemorySourceBounds::default(),
            )
            .unwrap()
        })
        .collect::<Vec<_>>();
    let uri = DatasetUri::new("memory://predicate-exclusion-candidate").unwrap();
    let prepared = (0..spec.calls)
        .map(|call| {
            let source = &sources[if spec.scenario == "replaced_source" {
                call
            } else {
                0
            }];
            prepare_relational_with_schema_in_session(policy(), &session, |schemas| {
                schemas.register_memory_source(uri.clone(), |_| Ok(source.clone()))?;
                Ok(spec.plan(uri.clone(), call))
            })
            .unwrap()
        })
        .collect::<Vec<_>>();
    let preparation_ns = started.elapsed().as_nanos();
    for source in &sources {
        assert_eq!(source.dtype(), &source_dtype());
    }
    for (call, plan) in prepared.iter().enumerate() {
        assert_eq!(plan.output_dtype(), Some(output_dtype(call)));
    }
    let mut operations = Vec::new();
    let mut complete_ns = preparation_ns;
    for (call, plan) in prepared.iter().enumerate() {
        let started = Instant::now();
        let result = plan.collect_jsonl(&CancellationToken::default()).unwrap();
        let operation_ns = started.elapsed().as_nanos();
        complete_ns += operation_ns;
        let actual = json!(json_rows(&result));
        assert_eq!(actual, expected[call], "{} call {call}", spec.id());
        let actual_schema =
            serde_json::from_str::<Value>(result.result_schema_json.value()).unwrap();
        assert_eq!(actual_schema, expected_schemas[call]);
        let certificate = &result.execution.native_io_certificate;
        assert!(certificate.is_certified() && !certificate.side_effects.fallback_attempted);
        assert_eq!(
            result.execution.output_rows,
            expected[call].as_array().unwrap().len() as u64
        );
        let mut record = json!({
            "call":call,"consumer":if call.is_multiple_of(2) { "count" } else { "grouped_sum" },
            "rows":result.execution.output_rows,
            "expected_rows_witness":expected_witnesses[call],"expected_schema_witness":schema_witnesses[call],
            "actual_rows_witness":witness(root,&actual),"actual_schema_witness":witness(root,&actual_schema),
            "engine_execution_ns":result.timing.execution.as_nanos(),
            "result_serialization_ns":result.timing.result_serialization.as_nanos(),
            "execution_and_consumption_ns":operation_ns,
            "completed_executions":plan.snapshot().completed_executions,
            "observation":observer.snapshot(),
            "cache_observation":cache.snapshot(),
            "native_io_certificate":{
                "certified":certificate.is_certified(),"fallback_attempted":certificate.side_effects.fallback_attempted,
                "complete_debug":format!("{certificate:#?}"),
            },
        });
        let started = Instant::now();
        drop(result);
        let release_ns = started.elapsed().as_nanos();
        complete_ns += release_ns;
        record["output_release_ns"] = json!(release_ns);
        operations.push(record);
    }
    let snapshot = session.snapshot();
    assert_eq!(snapshot.completed_executions, spec.calls as u64);
    assert_eq!(snapshot.prepared_source_opens, 0);
    assert_eq!(snapshot.admitted_max_parallelism, 1);
    assert_eq!(snapshot.provider_background_workers, 0);
    let started = Instant::now();
    drop(prepared);
    drop(sources);
    drop(session);
    let destruction_ns = started.elapsed().as_nanos();
    complete_ns += destruction_ns;
    let final_memory = memory.snapshot();
    assert_eq!(final_memory.reserved_bytes, 0);
    assert_eq!(final_memory.denied_reservations, 0);
    json!({
        "protocol_id":PROTOCOL,"cell_id":spec.id(),"rows":spec.rows,"family":spec.family,"scenario":spec.scenario,"calls":spec.calls,
        "mode":mode,"role":role,"cohort":cohort,"sample":sample,"warmup":warmup,
        "source_rows_witness":source_rows_witness,"source_schema_witness":source_schema_witness,
        "source_instances":source_instances,"cache_after_cleanup":cache.snapshot(),
        "preparation_ns":preparation_ns,"destruction_ns":destruction_ns,"complete_workflow_ns":complete_ns,
        "operations":operations,"completed_executions":snapshot.completed_executions,
        "prepared_source_opens":snapshot.prepared_source_opens,"admitted_max_parallelism":snapshot.admitted_max_parallelism,
        "provider_background_workers":snapshot.provider_background_workers,"peak_reserved_bytes":final_memory.peak_reserved_bytes,
        "reserved_after_cleanup":final_memory.reserved_bytes,"denied_reservations":final_memory.denied_reservations,
    })
}

#[test]
#[ignore = "frozen predicate-exclusion candidate protocol; serial guarded execution only"]
fn native_predicate_exclusion_candidate() {
    let root = PathBuf::from(std::env::var("SHARDLOOM_PREDICATE_CANDIDATE_ROOT").unwrap());
    assert!(root.is_absolute());
    fs::create_dir_all(root.join("witnesses")).unwrap();
    let mode = std::env::var("SHARDLOOM_PREDICATE_CANDIDATE_MODE").unwrap();
    let role = std::env::var("SHARDLOOM_PREDICATE_CANDIDATE_ROLE").unwrap();
    let cohort = std::env::var("SHARDLOOM_PREDICATE_CANDIDATE_COHORT").unwrap();
    assert!(matches!(mode.as_str(), "preflight" | "measure"));
    assert!(matches!(role.as_str(), "baseline" | "candidate"));
    assert_eq!(mode == "preflight", cohort == "preflight");
    assert!(matches!(cohort.as_str(), "preflight" | "A" | "B"));
    let mut file = fs::OpenOptions::new()
        .create_new(true)
        .write(true)
        .open(root.join(format!("{mode}-{cohort}-{role}.jsonl")))
        .unwrap();
    let mut workflows = 0;
    let mut operations = 0;
    let mut emit = |spec: Spec, sample: usize, warmup: bool| {
        let result = workflow(&root, spec, &mode, &role, &cohort, sample, warmup);
        serde_json::to_writer(&mut file, &result).unwrap();
        writeln!(file).unwrap();
        file.flush().unwrap();
        workflows += 1;
        operations += spec.calls;
    };
    if mode == "measure" {
        emit(
            Spec {
                rows: 8192,
                family: "unfiltered",
                scenario: "unfiltered",
                calls: 1,
            },
            0,
            true,
        );
    }
    let rows: &[usize] = if mode == "preflight" {
        &[0, 17, 8192, 65536]
    } else {
        &[8192, 65536]
    };
    let mut specs = rows
        .iter()
        .flat_map(|&rows| matrix(rows))
        .collect::<Vec<_>>();
    if cohort == "B" {
        specs.reverse();
    }
    for spec in specs {
        for sample in 0..if mode == "measure" { 3 } else { 1 } {
            emit(spec, sample, false);
        }
    }
    assert_eq!(workflows, if mode == "measure" { 343 } else { 228 });
    assert_eq!(operations, if mode == "measure" { 799 } else { 532 });
    println!("predicate candidate: {workflows} workflows, {operations} operations");
}
