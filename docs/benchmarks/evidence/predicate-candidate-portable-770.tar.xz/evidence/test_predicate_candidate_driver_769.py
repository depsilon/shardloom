import importlib.util
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

SCRIPT = Path(__file__).with_name('predicate_candidate_driver_769.py')
SPEC = importlib.util.spec_from_file_location('predicate_candidate_driver', SCRIPT)
driver = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(driver)


class CandidateDriverTests(unittest.TestCase):
    def test_protocol_and_command_binding(self):
        self.assertEqual(driver.sha(driver.PROTOCOL), driver.PROTOCOL_SHA)
        self.assertEqual(driver.SELECTOR,
                         'local_primitives::prepared_relational::tests::predicate_candidate_cost_tests::native_predicate_exclusion_candidate')
        with tempfile.TemporaryDirectory(dir=driver.OUT, prefix='predicate-candidate-test-') as temporary:
            data = Path(temporary)
            command = driver.make_run_command(Path('/tmp/candidate-test'), 'run-name', 'measure',
                                              'baseline', 'A', data)
        self.assertEqual(command[1], str(driver.GUARD))
        self.assertEqual(command[2:6], ['--name', 'run-name', '--timeout', '1800'])
        self.assertEqual(command[6:8], ['--', '/usr/bin/env'])
        self.assertEqual(command[8:12], [
            f'SHARDLOOM_PREDICATE_CANDIDATE_ROOT={data}',
            'SHARDLOOM_PREDICATE_CANDIDATE_MODE=measure',
            'SHARDLOOM_PREDICATE_CANDIDATE_ROLE=baseline',
            'SHARDLOOM_PREDICATE_CANDIDATE_COHORT=A',
        ])
        self.assertEqual(command[12:], [
            '/tmp/candidate-test', driver.SELECTOR, '--exact', '--ignored', '--nocapture', '--test-threads=1'])

    def test_mode_role_and_cohort_mismatches_rejected(self):
        with tempfile.TemporaryDirectory(dir=driver.OUT, prefix='predicate-candidate-test-') as temporary:
            data = Path(temporary)
            for args in [
                ('preflight', 'baseline', 'A'),
                ('measure', 'candidate', 'preflight'),
                ('measure', 'off', 'A'),
            ]:
                with self.subTest(args=args), self.assertRaises(AssertionError):
                    driver.make_run_command('/tmp/candidate-test', 'run-name', *args, data)

    def test_initial_build_freeze_requires_exact_snapshot_identity(self):
        with tempfile.TemporaryDirectory(dir=driver.OUT) as temporary:
            previous_out = driver.OUT
            driver.OUT = Path(temporary)
            try:
                source = b'abc'
                patch = b'diff --git a/src/lib.rs b/src/lib.rs\n'
                source_row = {'path': 'src/lib.rs', 'bytes': len(source),
                              'sha256': hashlib.sha256(source).hexdigest()}
                patch_hash = hashlib.sha256(patch).hexdigest()
                final = {'head': 'abc', 'sources': [source_row],
                         'protocol_sha256': driver.PROTOCOL_SHA, 'patch_sha256': patch_hash}
                manifest = driver.OUT / 'build-a-source-freeze.json'
                source_copy = driver.OUT / 'build-a-sources' / 'src/lib.rs'
                source_copy.parent.mkdir(parents=True)
                source_copy.write_bytes(source)
                (driver.OUT / 'build-a-tracked.patch').write_bytes(patch)
                initial = {'stage': 'initial_compile_snapshot_before_build', 'head': 'abc',
                           'sources': [source_row], 'changed_source_files': ['src/lib.rs'],
                           'patch_sha256': patch_hash, 'protocol_sha256': driver.PROTOCOL_SHA}

                def write_manifest(value):
                    manifest.write_text(json.dumps(value))

                write_manifest(initial)
                loaded, resolved = driver.verify_initial_build_freeze(manifest, final, 'build-a')
                self.assertEqual(loaded, initial)
                self.assertEqual(resolved, manifest.resolve())

                mutations = [
                    ('head', 'wrong-head'),
                    ('protocol_sha256', 'wrong-protocol'),
                    ('patch_sha256', 'wrong-patch'),
                    ('sources', []),
                    ('stage', 'after-build'),
                ]
                for key, value in mutations:
                    with self.subTest(key=key):
                        changed = dict(initial, **{key: value})
                        write_manifest(changed)
                        with self.assertRaises(AssertionError):
                            driver.verify_initial_build_freeze(manifest, final, 'build-a')

                write_manifest(initial)
                source_copy.write_bytes(b'xyz')
                with self.assertRaises(AssertionError):
                    driver.verify_initial_build_freeze(manifest, final, 'build-a')
                source_copy.write_bytes(source)
                (driver.OUT / 'build-a-tracked.patch').write_bytes(b'changed patch')
                with self.assertRaises(AssertionError):
                    driver.verify_initial_build_freeze(manifest, final, 'build-a')
                (driver.OUT / 'build-a-tracked.patch').write_bytes(patch)
                with self.assertRaises(AssertionError):
                    driver.verify_initial_build_freeze(manifest, final, 'build-b')
                wrong_path = driver.OUT / 'other-source-freeze.json'
                wrong_path.write_text(json.dumps(initial))
                with self.assertRaises(AssertionError):
                    driver.verify_initial_build_freeze(wrong_path, final, 'build-a')
            finally:
                driver.OUT = previous_out

    def test_new_compile_artifact_accepts_fresh_false_and_rejects_cached_true(self):
        newly_compiled = {'executable': '/tmp/test-binary', 'fresh': False}
        self.assertIs(driver.require_fresh_compiler_artifact([newly_compiled]), newly_compiled)
        cached = {'executable': '/tmp/test-binary', 'fresh': True}
        with self.assertRaises(AssertionError):
            driver.require_fresh_compiler_artifact([cached])
        with self.assertRaises(AssertionError):
            driver.require_fresh_compiler_artifact([])


if __name__ == '__main__':
    unittest.main()
