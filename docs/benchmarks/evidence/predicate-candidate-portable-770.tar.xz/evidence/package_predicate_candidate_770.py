"""Build a deterministic portable packet for the completed predicate candidate comparison.

This script is packaging-only. It does not execute ShardLoom, compile code, or
modify repository files. It refuses to overwrite an existing packet and
reopens every archive member before writing a successful index.
"""

from __future__ import annotations

import hashlib
import io
import json
import lzma
import os
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019')
REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
LOCALDATA = Path('/Users/dylan/LocalData/shardloom')
DEST = ROOT / 'predicate-candidate-portable-770'
NAME = 'predicate-candidate-portable-770'
LABEL = 'predicate-candidate-769-a2'
PROTOCOL = ROOT / 'predicate-exclusion-candidate-protocol-768.json'
ATTRIBUTION_PROTOCOL = ROOT / 'predicate-exclusion-attribution-protocol-766.json'
FINAL_FREEZE = ROOT / f'{LABEL}-source-freeze.json'
DECISION = ROOT / f'{LABEL}-decision.json'
SEQUENCE_IDENTITY = ROOT / f'{LABEL}-sequence-identity.json'
SEQUENCE_COMPLETION = ROOT / f'{LABEL}-sequence-completion.json'
PREFLIGHT_PROOF = ROOT / f'{LABEL}-preflight-verification.json'
ARTIFACT_A1 = ROOT / 'predicate-candidate-769-a1-artifact.json'
ARTIFACT_A2 = ROOT / f'{LABEL}-artifact.json'
BUILD_FIRST_A1 = ROOT / 'predicate-candidate-first-build-768-a1.json'
BUILD_FIRST_A2 = ROOT / 'predicate-candidate-first-build-768-a2.json'
BUILD_FINAL = ROOT / 'predicate-candidate-build-769-a2.json'
INITIAL_FREEZE_A1 = ROOT / 'predicate-candidate-first-build-768-a1-source-freeze.json'
INITIAL_FREEZE_A2 = ROOT / 'predicate-candidate-first-build-768-a2-source-freeze.json'
EXPECTED_HEAD = '896c71793a8859a6b4770bbc8a9fe0b85d755cf8'
PROTOCOL_SHA = 'e8653d467b11c9d5928b6be5bd2776ff840672b999d3dfaabac6ee3714c5ae5a'
ATTRIBUTION_SHA = '153892a4e056c9adf769dd65ba758ec304f70a2f8d62111d3b96197842d9a5e3'

# Inputs are fixed by evidence role. No prefix discovery is used for top-level
# evidence or source snapshots.
TOP_LEVEL_NAMES = (
    'predicate-exclusion-attribution-protocol-766.json',
    'predicate-exclusion-candidate-protocol-768.json',
    'predicate_candidate_driver_769.py',
    'test_predicate_candidate_driver_769.py',
    'analyze_predicate_candidate_768.py',
    'test_predicate_candidate_oracle_768.py',
    'run_predicate_candidate_sequence_769.py',
    'freeze_predicate_initial_build_768.py',
    'run_guarded_observed_757.py',
    'predicate-candidate-769-a1-source-freeze.json',
    'predicate-candidate-769-a1-tracked.patch',
    'predicate-candidate-769-a1-artifact.json',
    'predicate-candidate-769-a1-test-inventory.txt',
    'predicate-candidate-769-a2-source-freeze.json',
    'predicate-candidate-769-a2-tracked.patch',
    'predicate-candidate-769-a2-artifact.json',
    'predicate-candidate-769-a2-test-inventory.txt',
    'predicate-candidate-first-build-768-a1-source-freeze.json',
    'predicate-candidate-first-build-768-a1-tracked.patch',
    'predicate-candidate-first-build-768-a1.json',
    'predicate-candidate-first-build-768-a1.log',
    'predicate-candidate-first-build-driver-768-a1.log',
    'predicate-candidate-first-build-768-a2-source-freeze.json',
    'predicate-candidate-first-build-768-a2-tracked.patch',
    'predicate-candidate-first-build-768-a2.json',
    'predicate-candidate-first-build-768-a2.log',
    'predicate-candidate-first-build-driver-768-a2.log',
    'predicate-candidate-build-769-a2.json',
    'predicate-candidate-build-769-a2.log',
    'predicate-candidate-build-driver-769-a2.log',
    'predicate-candidate-bind-769-a1.json',
    'predicate-candidate-bind-769-a1.log',
    'predicate-candidate-bind-driver-769-a1.log',
    'predicate-candidate-bind-769-a2.json',
    'predicate-candidate-bind-769-a2.log',
    'predicate-candidate-lifecycle-769-a1.json',
    'predicate-candidate-lifecycle-769-a1.log',
    'predicate-candidate-lifecycle-driver-769-a1.log',
    'predicate-candidate-lifecycle-769-a2.json',
    'predicate-candidate-lifecycle-769-a2.log',
    'predicate-candidate-helper-tests-769.log',
    'predicate-candidate-review-corrections-769.json',
    'analyze-predicate-candidate-before-primary-review-769.py',
    'test-predicate-candidate-before-primary-review-769.py',
    'predicate-candidate-769-a2-preflight-verification.json',
    'predicate-candidate-769-a2-decision.json',
    'predicate-candidate-769-a2-sequence-identity.json',
    'predicate-candidate-769-a2-sequence-completion.json',
    'predicate-candidate-sequence-driver-769-a2.log',
    'predicate-candidate-decision-769-a2.json',
    'predicate-candidate-verification-770.json',
    'verify-predicate-candidate-770.log',
    'verify_predicate_candidate_770.py',
    'predicate-candidate-preflight-baseline-769-a2-link.json',
    'predicate-candidate-preflight-candidate-769-a2-link.json',
    'predicate-candidate-measure-A-baseline-769-a2-link.json',
    'predicate-candidate-measure-A-candidate-769-a2-link.json',
    'predicate-candidate-measure-B-baseline-769-a2-link.json',
    'predicate-candidate-measure-B-candidate-769-a2-link.json',
    'verify_predicate_attribution_packet_768.py',
    'attribution-reopen-before-family-order-correction-768.py',
    'predicate-attribution-packet-verification-768.json',
    'verify-attribution-packet-768.log',
    'verify-attribution-packet-768-a2.log',
    'package_predicate_attribution_767.py',
    'package_predicate_candidate_770.py',
    'predicate-candidate-packager-before-primary-review-770.py',
    'predicate-candidate-packager-review-770.json',
    'attribution-packager-before-primary-review-768.py',
    'package-attribution-768.log',
    'predicate-attribution-portable-767/predicate-attribution-portable-767.json',
    'predicate-attribution-portable-767/predicate-attribution-portable-767.manifest.json.xz',
    'predicate-attribution-portable-767/predicate-attribution-portable-767.tar.xz',
    'docs/architecture/native-predicate-exclusion-design-2026-10-19.md',
)

SEQUENCE_STEPS = (
    'predicate-candidate-bind-769-a2',
    'predicate-candidate-lifecycle-769-a2',
    'predicate-candidate-preflight-baseline-769-a2',
    'predicate-candidate-preflight-candidate-769-a2',
    'predicate-candidate-preflight-check-769-a2',
    'predicate-candidate-measure-A-baseline-769-a2',
    'predicate-candidate-measure-A-candidate-769-a2',
    'predicate-candidate-measure-B-candidate-769-a2',
    'predicate-candidate-measure-B-baseline-769-a2',
    'predicate-candidate-decision-769-a2',
    'predicate-candidate-final-binding-769-a2',
)

RAW_STREAMS = (
    'preflight-preflight-baseline.jsonl',
    'preflight-preflight-candidate.jsonl',
    'measure-A-baseline.jsonl',
    'measure-A-candidate.jsonl',
    'measure-B-baseline.jsonl',
    'measure-B-candidate.jsonl',
)

WITNESS_NAMES = (
    '12de724afe55ea3078a737a0b334d16222f818c23e9c984ae9bed4f536b1de86.json',
    '1569d2b47a435ebd1fa10193fe023756947e56253270c00281998ec937babec9.json',
    '17777b17021f1be5c860cb8c78f7a3ce67ce82c55e9ff71f4b1489b860b44711.json',
    '1782a20196bab25d0159f69c330a0b68634142cf50aeb3da2a105f7b6fa6b368.json',
    '1b24080b08ac2717b7a1098cfb749704869b5c1d0cbc9cfb06f11389c2675929.json',
    '203d6fc3817dfe12b0add85400a27458f1da22accc64414cb1a5c7d2848ee403.json',
    '248bdf44fa0c6eb9d05ca9c8453e126a7163951d247854423516f1ffd711fb1a.json',
    '258b16048e97c8f2d3030cd976843128e7ba9da6b6b3ec1fbaaf5c882f6267d7.json',
    '2c8f1fed6609ede9644034ae0868e53e8a811ddd477c616db8628d07bbbf4368.json',
    '327bdbd15c97e55b52524d38a3a8fbfa46bdce1ee1955f93ee563d59cb1cd85a.json',
    '38e1f51b3573b2fb08a8313307a674c0e2b7d30c36c17e59151bc4f6114740bf.json',
    '391f624e29d54fc1d05fe7036dcab3d1db483bd11ba24ae60b0764b0117ec223.json',
    '3acb043f119bd1312df03503ce758fe50efd73360286e0a68c738756fbc8f194.json',
    '3e2679a55fd12c2ab5d5bcda2f3f66990d51e0dfdc8f640f5c9c205c0538e9e6.json',
    '4ab89eaa5d779108d84a17f389732dac835f2711764b5fdda035a6d2a02f4d1d.json',
    '4cfdfd669756e5159f4457176b85df53c02922fb592667075e4d7015b259992d.json',
    '4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945.json',
    '6f52e03a3c2ddb07e23effe891258c33749d1ed497d2f25a789bf02530af591d.json',
    '74efc1a2416fed53ed49b8125512f9b7f86638b7666da2751fcd5149a6822f55.json',
    '7b8461b548aaacde7b50f9f1d0bad6a34adf6b1c3e97e312ef9a4db332438cfe.json',
    '8942ceeecc74b745cf90e88654c87af4089f0f186b7f757fbb4c845aa58cafbb.json',
    '8953281dd204ca3bc6e279e9a8e72a8d89d3b1782e1899773a3f0da410724e5a.json',
    '8a055fd0bbef9359a34f6a687bb04a355eddff9d0548aa5509f85eb46ef1377d.json',
    '9c71f52607c798a69e97a4242d15136bcead64b37414706f5aa64247617a3973.json',
    'a57d07ff954e8f6781b20badced7022f93a30e684bb36b379e5693594af04690.json',
    'a581b4891869410aebe6ab8c9cd2097d19f3b081b4ced3f8642570cc6dbe7e99.json',
    'a6b55c83601d1093a45bf355ed8a2d880725849a0cb0cfeaa25be4571fc37733.json',
    'b2155aa3bd880d40380b76930f02c44a1404dfc66f763f73bd54153c6638ab41.json',
    'b3a3d4fda5fbf62ba901db5b184272991c52048c2c917e4494dcd97ff61a45fe.json',
    'b6da8c2e1a8152300297c4d01069c05330f2febd313d0a50c5bf856a3126411c.json',
    'b9ee7c25fd4f39fc1e21cc820b3dd3c0222f1bb6c3ed9c01d475ae8cb75b0625.json',
    'c5df6d8f14fa28fb647dee275eb99d4cf35f1ab4588805129e9881ac2a7ff0a9.json',
    'cbbf0a41ed1d8a8761f29990b8e374b53ee24456ec8c770b705e444b849349b2.json',
    'd860b38caff8546c4e3fe6a0533810fb3452f20ba3e684f4e324a8413ea29f5b.json',
    'd9f99612c41e6357957e8fded0460820246140e8e54b4bdc0568dabda7b78c70.json',
    'dac471228e6f4a5c185a470f14cb1c0202133364155d982f1e9600e71d13d2f4.json',
    'e0bde32d711a6f3ffa704720ec279e194984a55a0a5168ca027c7f9c61f33baa.json',
    'e690b29c92cdbfbef6862d91956856faafb6dee93b0245fc1315239a01d1d808.json',
    'eb88f3a62960370929b28bdade8d4f75a89263c8bbcb278b538cbf4271dc3a29.json',
    'f1d30edb2a28f7eb849c4a9bf41b1eba7831be859554fa65902a83b883c3a8ff.json',
    'f777801e1b33f9c20cce9d8b04c357757c1660ecb5efe0a96c08db19c5b9d7b8.json',
    'ff418f003e53c5566dc1446bc73a36daa7dd8409ea79349276d93b92d5116804.json',
)

# Same import closure as the attribution packet's guarded worker.
GUARD_DEPENDENCY_SOURCES = (
    ('repo', 'scripts/local_uat_storage.py'),
    ('repo', 'scripts/run_clickbench_paired_query_uat.py'),
    ('repo', 'scripts/native_workflow_protocol.py'),
    ('repo', 'scripts/query_timing_report.py'),
    ('repo', 'scripts/clickbench_reference_packet.py'),
    ('repo', 'scripts/run_clickbench_query_uat.py'),
    ('repo', 'python/src/shardloom/__init__.py'),
    ('repo', 'python/src/shardloom/_exports.py'),
    ('repo', 'python/src/shardloom/_result_schema.py'),
    ('repo', 'python/src/shardloom/errors.py'),
    ('repo', 'python/src/shardloom/_compat.py'),
    ('repo', 'python/src/shardloom/models.py'),
    ('local', 'release-0.3.3-20260930/release_validation_guard.py'),
    ('local', 'perf-all-20260906/bounded_build_process_resume_20260912.py'),
)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def encode_json(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def identity(path: Path) -> dict[str, object]:
    path = Path(path)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha256_file(path)}


def read_json(path: Path) -> dict:
    return json.loads(Path(path).read_text())


def add_file(members: dict[str, Path], member_name: str, source: Path) -> None:
    source = Path(source)
    assert source.is_file() and not source.is_symlink(), f'not a regular file: {source}'
    assert member_name and not member_name.startswith('/')
    assert '..' not in Path(member_name).parts, member_name
    old = members.get(member_name)
    assert old is None or old.resolve() == source.resolve(), f'duplicate member: {member_name}'
    members[member_name] = source


def archive_path(path: Path) -> str:
    path = Path(path).resolve(strict=True)
    if path.is_relative_to(ROOT):
        return 'evidence/' + path.relative_to(ROOT).as_posix()
    if path.is_relative_to(REPO):
        return 'repo/' + path.relative_to(REPO).as_posix()
    if path.is_relative_to(LOCALDATA):
        return 'local/' + path.relative_to(LOCALDATA).as_posix()
    raise AssertionError(f'input outside approved roots: {path}')


def add_regular_tree(members: dict[str, Path], source_root: Path, member_root: str) -> list[Path]:
    source_root = Path(source_root)
    assert source_root.is_dir() and not source_root.is_symlink(), source_root
    found: list[Path] = []
    for path in sorted(source_root.rglob('*')):
        if path.is_dir():
            assert not path.is_symlink(), path
            continue
        assert path.is_file() and not path.is_symlink(), path
        relative = path.relative_to(source_root).as_posix()
        add_file(members, f'{member_root.rstrip("/")}/{relative}', path)
        found.append(path)
    return found


def source_paths() -> list[str]:
    listed = subprocess.check_output(
        ['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=REPO, text=True
    ).splitlines()
    return sorted(p for p in set(listed) if p.endswith('.rs') or
                  Path(p).name in ('Cargo.toml', 'Cargo.toml.orig', 'Cargo.lock'))


def verify_source_freezes() -> tuple[dict, dict]:
    initial_a1 = read_json(INITIAL_FREEZE_A1)
    initial_a2 = read_json(INITIAL_FREEZE_A2)
    freeze_a1 = read_json(ROOT / 'predicate-candidate-769-a1-source-freeze.json')
    freeze_a2 = read_json(FINAL_FREEZE)
    assert freeze_a1['head'] == freeze_a2['head'] == EXPECTED_HEAD
    assert freeze_a1['protocol_sha256'] == freeze_a2['protocol_sha256'] == PROTOCOL_SHA
    assert len(freeze_a2['sources']) == 1904
    assert freeze_a1['helpers'] == freeze_a2['helpers'] and len(freeze_a2['helpers']) == 7
    assert source_paths() == [row['path'] for row in freeze_a2['sources']]
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == EXPECTED_HEAD
    for row in freeze_a2['sources']:
        path = REPO / row['path']
        assert path.is_file() and path.stat().st_size == row['bytes']
        assert sha256_file(path) == row['sha256'], row['path']
    for helper in freeze_a2['helpers']:
        path = Path(helper['path'])
        assert path.is_file() and not path.is_symlink() and sha256_file(path) == helper['sha256'], path
    assert sha256_bytes(subprocess.check_output(['git', 'diff', '--binary'], cwd=REPO)) == freeze_a2['patch_sha256']
    for freeze_name, freeze in (('predicate-candidate-769-a1-source-freeze.json', freeze_a1),
                                ('predicate-candidate-769-a2-source-freeze.json', freeze_a2)):
        patch_path = ROOT / freeze_name.replace('source-freeze.json', 'tracked.patch')
        assert sha256_file(patch_path) == freeze['patch_sha256']
        expected = set(freeze['extra_sources'])
        source_map = {row['path']: row for row in freeze['sources']}
        root = ROOT / freeze_name.replace('source-freeze.json', 'extra-sources')
        actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
        assert actual == expected
        for relative in sorted(expected):
            copy = root / relative
            row = source_map[relative]
            assert copy.stat().st_size == row['bytes'] and sha256_file(copy) == row['sha256'], relative
    assert initial_a1['stage'] == 'first_compile_snapshot_before_repair'
    assert initial_a1['protocol_sha256'] == PROTOCOL_SHA
    assert initial_a2['stage'] == 'initial_compile_snapshot_before_build'
    assert initial_a2['head'] == EXPECTED_HEAD and initial_a2['protocol_sha256'] == PROTOCOL_SHA
    assert freeze_a1['sources'] == initial_a2['sources']
    for initial_name, initial in (('a1', initial_a1), ('a2', initial_a2)):
        initial_patch = ROOT / f'predicate-candidate-first-build-768-{initial_name}-tracked.patch'
        assert initial['patch_sha256'] == sha256_file(initial_patch)
        changed = set(initial['changed_source_files'])
        source_map = {row['path']: row for row in initial['sources']}
        copy_root = ROOT / f'predicate-candidate-first-build-768-{initial_name}-sources'
        actual = {p.relative_to(copy_root).as_posix() for p in copy_root.rglob('*') if p.is_file()}
        assert actual == changed and len(changed) == 14
        for relative in sorted(changed):
            copy = copy_root / relative
            row = source_map[relative]
            assert copy.stat().st_size == row['bytes'] and sha256_file(copy) == row['sha256'], relative
    return freeze_a1, freeze_a2


def verify_receipt_log(receipt_path: Path, expected_status: str | None = None,
                       require_drained: bool = True) -> dict:
    receipt = read_json(receipt_path)
    log_path = receipt_path.with_suffix('.log')
    assert log_path.is_file() and not log_path.is_symlink(), log_path
    assert sha256_file(log_path) == receipt['log_sha256'], log_path
    if expected_status:
        assert receipt['status'] == expected_status, receipt_path.name
    if require_drained:
        assert receipt['process_group_drained'] is True, receipt_path.name
    assert receipt.get('returncode') is not None
    return receipt


def verify_sequence_and_runs() -> tuple[dict, dict]:
    completion = read_json(SEQUENCE_COMPLETION)
    identity_record = read_json(SEQUENCE_IDENTITY)
    assert completion['status'] == 'completed' and completion['production_accepted'] is False
    assert completion['identity_sha256'] == sha256_file(SEQUENCE_IDENTITY)
    assert completion['decision_sha256'] == sha256_file(DECISION)
    assert identity_record['label'] == LABEL and identity_record['build'] == 'predicate-candidate-build-769-a2'
    assert identity_record['sequence_sha256'] == sha256_file(ROOT / 'run_predicate_candidate_sequence_769.py')
    assert identity_record['driver_sha256'] == sha256_file(ROOT / 'predicate_candidate_driver_769.py')
    assert identity_record['guard_sha256'] == sha256_file(ROOT / 'run_guarded_observed_757.py')
    assert identity_record['oracle_sha256'] == sha256_file(ROOT / 'analyze_predicate_candidate_768.py')
    assert identity_record['protocol_sha256'] == PROTOCOL_SHA
    assert identity_record['source_freeze_sha256'] == sha256_file(FINAL_FREEZE)
    assert identity_record['build_receipt_sha256'] == sha256_file(BUILD_FINAL)
    assert identity_record['ordered_roles'] == [
        'preflight/baseline', 'preflight/candidate', 'A/baseline', 'A/candidate', 'B/candidate', 'B/baseline']
    for step in SEQUENCE_STEPS:
        step_path = ROOT / f'{step}-sequence-step.json'
        step_record = read_json(step_path)
        output_path = ROOT / f'{step}-sequence-output.log'
        assert step_record['step'] == step and step_record['returncode'] == 0
        assert sha256_file(output_path) == step_record['output_sha256']
        assert step_record['source_freeze_sha256'] == sha256_file(FINAL_FREEZE)
        if step != 'predicate-candidate-final-binding-769-a2':
            verify_receipt_log(ROOT / f'{step}.json', 'passed')
    # The early a1 attempts are preserved with their failed receipts and exact
    # logs; later a2 proof receipts above must have succeeded and drained.
    for name in ('predicate-candidate-first-build-768-a1', 'predicate-candidate-lifecycle-769-a1'):
        verify_receipt_log(ROOT / f'{name}.json', 'failed')
    for name in ('predicate-candidate-first-build-768-a2', 'predicate-candidate-build-769-a2',
                 'predicate-candidate-lifecycle-769-a2'):
        verify_receipt_log(ROOT / f'{name}.json', 'passed')
    for name in ('predicate-candidate-bind-769-a1', 'predicate-candidate-bind-769-a2'):
        verify_receipt_log(ROOT / f'{name}.json')
    return completion, identity_record


def verify_build_artifacts(freeze_a2: dict) -> dict:
    first_a1 = verify_receipt_log(BUILD_FIRST_A1, 'failed')
    first_a2 = verify_receipt_log(BUILD_FIRST_A2, 'passed')
    final = verify_receipt_log(BUILD_FINAL, 'passed')
    artifact_a1 = read_json(ARTIFACT_A1)
    artifact_a2 = read_json(ARTIFACT_A2)
    assert artifact_a1['build'] == 'predicate-candidate-first-build-768-a2'
    assert artifact_a1['build_receipt_sha256'] == sha256_file(BUILD_FIRST_A2)
    assert artifact_a1['source_freeze_sha256'] == sha256_file(ROOT / 'predicate-candidate-769-a1-source-freeze.json')
    assert artifact_a1['initial_build_freeze']['path'] == str(INITIAL_FREEZE_A2)
    assert artifact_a1['initial_build_freeze']['sha256'] == sha256_file(INITIAL_FREEZE_A2)
    assert artifact_a1['initial_build_freeze']['stage'] == 'initial_compile_snapshot_before_build'
    assert artifact_a1['initial_build_freeze']['name'] == 'predicate-candidate-first-build-768-a2'
    assert artifact_a2['build'] == 'predicate-candidate-build-769-a2'
    assert artifact_a2['build_receipt_sha256'] == sha256_file(BUILD_FINAL)
    assert artifact_a2['source_freeze_sha256'] == sha256_file(FINAL_FREEZE)
    for artifact, build_path in ((artifact_a1, BUILD_FIRST_A2), (artifact_a2, BUILD_FINAL)):
        binary = Path(artifact['artifact'])
        assert binary.is_file() and not binary.is_symlink()
        assert binary.stat().st_size == artifact['bytes'] and sha256_file(binary) == artifact['artifact_sha256']
        assert artifact['compiler_artifact']['fresh'] is False
        messages = [json.loads(line) for line in build_path.with_suffix('.log').read_text().splitlines()
                    if line.startswith('{')]
        compiled = [row for row in messages if row.get('reason') == 'compiler-artifact'
                    and row.get('target', {}).get('name') == 'shardloom_vortex'
                    and row.get('profile', {}).get('test')]
        assert compiled == [artifact['compiler_artifact']]
        # Cargo names its cache artifact; the frozen copy has its own path and
        # hash above. A later build can legitimately replace the cache file.
        assert Path(compiled[0]['executable']).is_relative_to(
            Path(read_json(build_path)['environment']['CARGO_TARGET_DIR']))
    assert artifact_a2['compiler_artifact']['target']['name'] == 'shardloom_vortex'
    assert artifact_a2['compiler_artifact']['profile']['test'] is True
    assert freeze_a2['head'] == EXPECTED_HEAD
    return {
        'first_successful_frozen_binary': {
            'artifact_receipt': identity(ARTIFACT_A1), 'build_receipt': identity(BUILD_FIRST_A2),
            'binary_path': artifact_a1['artifact'], 'binary_bytes': artifact_a1['bytes'],
            'binary_sha256': artifact_a1['artifact_sha256'], 'binary_copied': False,
            'build_command': first_a2['command'],
            'rebuild_inputs': ['predicate-candidate-769-a1-source-freeze.json',
                               'predicate-candidate-769-a1-tracked.patch',
                               'predicate-candidate-first-build-768-a2-source-freeze.json',
                               'predicate-candidate-first-build-768-a2-tracked.patch'],
        },
        'final_successful_frozen_binary': {
            'artifact_receipt': identity(ARTIFACT_A2), 'build_receipt': identity(BUILD_FINAL),
            'binary_path': artifact_a2['artifact'], 'binary_bytes': artifact_a2['bytes'],
            'binary_sha256': artifact_a2['artifact_sha256'], 'binary_copied': False,
            'build_command': final['command'],
            'rebuild_inputs': ['predicate-candidate-769-a2-source-freeze.json',
                               'predicate-candidate-769-a2-tracked.patch'],
        },
        'failed_first_build': {'receipt': identity(BUILD_FIRST_A1), 'log': identity(BUILD_FIRST_A1.with_suffix('.log'))},
    }


def verify_run_links_and_streams(proof: dict, decision: dict) -> tuple[list[Path], list[Path], dict]:
    data_root = ROOT / LABEL
    stream_paths = [data_root / name for name in RAW_STREAMS]
    witness_paths = [data_root / 'witnesses' / name for name in WITNESS_NAMES]
    actual_witnesses = {p.name for p in (data_root / 'witnesses').iterdir() if p.is_file()}
    assert actual_witnesses == set(WITNESS_NAMES) and len(witness_paths) == 42
    assert all(p.is_file() and not p.is_symlink() for p in stream_paths + witness_paths)
    measured = decision['streams']
    preflight = proof['streams']
    expected_keys = {
        'preflight-preflight-baseline.jsonl': ('baseline', preflight),
        'preflight-preflight-candidate.jsonl': ('candidate', preflight),
        'measure-A-baseline.jsonl': ('A-baseline', measured),
        'measure-A-candidate.jsonl': ('A-candidate', measured),
        'measure-B-baseline.jsonl': ('B-baseline', measured),
        'measure-B-candidate.jsonl': ('B-candidate', measured),
    }
    stream_records = {}
    for path in stream_paths:
        role_key, source = expected_keys[path.name]
        row = source[role_key]
        assert sha256_file(path) == row['sha256'] and path.stat().st_size == row['bytes']
        lines = path.read_text().splitlines()
        assert len(lines) == row['workflows']
        operation_count = 0
        for line in lines:
            record = json.loads(line)
            operation_count += len(record['operations'])
        assert operation_count == row['operations']
        stream_records[path.name] = {'identity': identity(path), 'workflows': len(lines),
                                     'operations': operation_count}
    assert sum(row['workflows'] for row in preflight.values()) == 456
    assert sum(row['operations'] for row in preflight.values()) == 1064
    measured_only = {key: row for key, row in measured.items() if key.startswith(('A-', 'B-'))}
    assert set(measured_only) == {'A-baseline', 'A-candidate', 'B-baseline', 'B-candidate'}
    assert sum(row['workflows'] for row in measured_only.values()) == 1372
    assert sum(row['operations'] for row in measured_only.values()) == 3196
    assert sum(row['workflows'] for row in stream_records.values()) == 1828
    assert sum(row['operations'] for row in stream_records.values()) == 4260
    for mode, cohort, role, filename in (
        ('preflight', 'preflight', 'baseline', 'preflight-preflight-baseline.jsonl'),
        ('preflight', 'preflight', 'candidate', 'preflight-preflight-candidate.jsonl'),
        ('measure', 'A', 'baseline', 'measure-A-baseline.jsonl'),
        ('measure', 'A', 'candidate', 'measure-A-candidate.jsonl'),
        ('measure', 'B', 'baseline', 'measure-B-baseline.jsonl'),
        ('measure', 'B', 'candidate', 'measure-B-candidate.jsonl'),
    ):
        prefix = 'preflight' if mode == 'preflight' else f'measure-{cohort}'
        link = read_json(ROOT / f'predicate-candidate-{prefix}-{role}-769-a2-link.json')
        expected = proof['streams'][role] if mode == 'preflight' else measured[f'{cohort}-{role}']
        assert link['role'] == role and link['mode'] == mode and link['cohort'] == cohort
        assert link['returncode'] == 0 and link['sources_and_artifact_unchanged'] is True
        assert link['protocol_sha256'] == PROTOCOL_SHA
        assert link['source_freeze_sha256'] == sha256_file(FINAL_FREEZE)
        assert link['artifact_sha256'] == read_json(ARTIFACT_A2)['artifact_sha256']
        assert link['driver_sha256'] == freeze_helper_hash('predicate_candidate_driver_769.py')
        assert link['guard_sha256'] == freeze_helper_hash('run_guarded_observed_757.py')
        command = link['command']
        assert str(ROOT / 'run_guarded_observed_757.py') in command
        assert f'SHARDLOOM_PREDICATE_CANDIDATE_ROOT={data_root}' in command
        assert f'SHARDLOOM_PREDICATE_CANDIDATE_MODE={mode}' in command
        assert f'SHARDLOOM_PREDICATE_CANDIDATE_ROLE={role}' in command
        assert f'SHARDLOOM_PREDICATE_CANDIDATE_COHORT={cohort}' in command
        assert ('local_primitives::prepared_relational::tests::predicate_candidate_cost_tests::'
                'native_predicate_exclusion_candidate') in command
        assert link['output'] == str(data_root / filename)
        assert link['output_sha256'] == expected['sha256'] and link['output_bytes'] == expected['bytes']
    for name in ('preflight-preflight-baseline.jsonl', 'preflight-preflight-candidate.jsonl'):
        path = data_root / name
        assert sha256_file(path) == proof['streams']['baseline' if name.endswith('baseline.jsonl') else 'candidate']['sha256']
    for name in ('measure-A-baseline.jsonl', 'measure-A-candidate.jsonl',
                 'measure-B-baseline.jsonl', 'measure-B-candidate.jsonl'):
        key = name.removeprefix('measure-').removesuffix('.jsonl').replace('-', '-')
        assert sha256_file(data_root / name) == measured[key]['sha256']
    return stream_paths, witness_paths, stream_records


def validate_decision(decision: dict) -> tuple[list[str], int]:
    assert decision['protocol_sha256'] == PROTOCOL_SHA
    assert decision['attribution_protocol_sha256'] == ATTRIBUTION_SHA
    assert decision['scope_result'] == 'candidate_comparison_rejected'
    assert decision['production_accepted'] is False
    assert decision['all_targets_pass'] is True and decision['controls_pass'] is False
    targets = decision['targets']
    assert len(targets) == 3
    for target in targets:
        assert target['qualifies_both_cohorts'] is True
        assert all(target['cohorts'][c]['target_qualifies'] is True for c in ('A', 'B'))
    failed = []
    peak_overheads = []
    for cell in decision['cells']:
        for cohort in ('A', 'B'):
            row = cell['cohorts'][cohort]
            peak_overheads.append(row['median_candidate_peak_reserved_bytes'] -
                                  row['median_baseline_peak_reserved_bytes'])
            if not row['control_pass']:
                failed.append(f"{cell['cell_id']}:{cohort}")
    assert max(peak_overheads) == 5128 and max(peak_overheads) <= 65536
    assert all(row['median_candidate_peak_reserved_bytes'] <= row['median_baseline_peak_reserved_bytes'] + 65536
               for cell in decision['cells'] for row in cell['cohorts'].values())
    assert set(failed) == {
        '65536-membership-no_true-1:B',
        '65536-membership-interleaved_parameters-1:A',
    }
    return failed, max(peak_overheads)


def validate_attribution_reference() -> dict:
    index = ROOT / 'predicate-attribution-portable-767/predicate-attribution-portable-767.json'
    manifest_path = ROOT / 'predicate-attribution-portable-767/predicate-attribution-portable-767.manifest.json.xz'
    archive = ROOT / 'predicate-attribution-portable-767/predicate-attribution-portable-767.tar.xz'
    verification = read_json(ROOT / 'predicate-attribution-packet-verification-768.json')
    assert verification.get('status') == 'passed'
    assert verification.get('packet_index_sha256') == sha256_file(index)
    assert verification.get('archive_sha256') == sha256_file(archive)
    assert verification.get('manifest_sha256') == sha256_file(manifest_path)
    assert read_json(index)['all_members_reopened'] is True
    return {'packet_index': identity(index), 'archive': identity(archive),
            'manifest': identity(manifest_path), 'reopen_receipt': identity(ROOT / 'predicate-attribution-packet-verification-768.json'),
            'reopen_verifier': identity(ROOT / 'verify_predicate_attribution_packet_768.py'),
            'preserved_prior_attempt': identity(ROOT / 'attribution-reopen-before-family-order-correction-768.py'),
            'prior_attempt_log': identity(ROOT / 'verify-attribution-packet-768.log'),
            'successful_reopen_log': identity(ROOT / 'verify-attribution-packet-768-a2.log'),
            'separate_packet': True}


def freeze_helper_hash(basename: str) -> str:
    freeze = read_json(FINAL_FREEZE)
    row = next(item for item in freeze['helpers'] if Path(item['path']).name == basename)
    return row['sha256']


def validate_independent_receipt() -> dict:
    receipt_path = ROOT / 'predicate-candidate-verification-770.json'
    log_path = ROOT / 'verify-predicate-candidate-770.log'
    receipt = read_json(receipt_path)
    assert receipt['status'] == 'passed'
    assert receipt['scope_result'] == 'candidate_comparison_rejected'
    assert receipt['production_accepted'] is False
    assert receipt['source_inputs'] == 1904
    assert receipt['workflows'] == 1828 and receipt['operations'] == 4260
    assert receipt['cells'] == 114 and receipt['all_gates_independently_recomputed'] is True
    assert receipt['source']['sha256'] == sha256_file(FINAL_FREEZE)
    assert receipt['artifact']['path'] == str(ARTIFACT_A2)
    assert receipt['artifact']['sha256'] == sha256_file(ARTIFACT_A2)
    assert receipt['decision']['path'] == str(DECISION)
    assert receipt['decision']['sha256'] == sha256_file(DECISION)
    assert receipt['protocol']['sha256'] == PROTOCOL_SHA
    assert receipt['verifier']['path'] == str(ROOT / 'verify_predicate_candidate_770.py')
    assert receipt['verifier']['sha256'] == sha256_file(ROOT / 'verify_predicate_candidate_770.py')
    assert len(receipt['successful_guarded_receipts']) == 11
    assert len(receipt['target_results']) == 6 and len(receipt['failing_controls']) == 2
    assert receipt['maximum_median_peak_overhead_bytes'] == 5128
    for row in receipt['successful_guarded_receipts']:
        path = Path(row['path'])
        assert path.is_file() and path.stat().st_size == row['bytes']
        assert sha256_file(path) == row['sha256']
        guarded = verify_receipt_log(path, 'passed')
        assert guarded['process_group_drained'] is True
    summary = json.loads(log_path.read_text())
    assert summary == {'status': 'passed', 'scope_result': 'candidate_comparison_rejected',
                       'workflows': 1828, 'operations': 4260, 'target_cohorts': 6,
                       'failing_control_cohorts': 2, 'verification': str(receipt_path)}
    return {'receipt': identity(receipt_path), 'log': identity(log_path),
            'verifier': identity(ROOT / 'verify_predicate_candidate_770.py'),
            'all_114_gates_independently_recomputed': True}


def main() -> None:
    assert not DEST.exists(), f'refusing to overwrite existing packet: {DEST}'
    sys.path.insert(0, str(REPO / 'scripts'))
    from local_uat_storage import GIB, MIB, check_budgets, require_local_path

    require_local_path(ROOT, Path.home(), sys.platform)
    require_local_path(DEST, Path.home(), sys.platform)
    assert sha256_file(PROTOCOL) == PROTOCOL_SHA
    assert sha256_file(ATTRIBUTION_PROTOCOL) == ATTRIBUTION_SHA
    freeze_a1, freeze_a2 = verify_source_freezes()
    completion, sequence_identity = verify_sequence_and_runs()
    build_metadata = verify_build_artifacts(freeze_a2)
    independent_verification = validate_independent_receipt()
    proof = read_json(PREFLIGHT_PROOF)
    decision = read_json(DECISION)
    failed_controls, maximum_peak_overhead = validate_decision(decision)
    assert proof['protocol_sha256'] == PROTOCOL_SHA and proof['production_accepted'] is False
    helper_test_text = (ROOT / 'predicate-candidate-helper-tests-769.log').read_text()
    assert 'Ran 13 tests' in helper_test_text and '\nOK\n' in helper_test_text
    lifecycle_text = (ROOT / 'predicate-candidate-lifecycle-769-a2.log').read_text()
    assert 'test result: ok. 16 passed; 0 failed; 0 ignored;' in lifecycle_text
    stream_paths, witness_paths, stream_records = verify_run_links_and_streams(proof, decision)
    attribution_reference = validate_attribution_reference()

    members: dict[str, Path] = {}
    for name in TOP_LEVEL_NAMES:
        path = (REPO if name.startswith('docs/') else ROOT) / name
        add_file(members, archive_path(path), path)
    # All fixed sequence output and step files are retained individually.
    for step in SEQUENCE_STEPS:
        for suffix in ('-sequence-step.json', '-sequence-output.log'):
            path = ROOT / f'{step}{suffix}'
            add_file(members, archive_path(path), path)
        if step != 'predicate-candidate-final-binding-769-a2':
            for suffix in ('.json', '.log'):
                path = ROOT / f'{step}{suffix}'
                add_file(members, archive_path(path), path)
    # Candidate source snapshots and initial compile snapshots are fixed trees.
    snapshot_dirs = {}
    for label in ('a1', 'a2'):
        freeze = freeze_a1 if label == 'a1' else freeze_a2
        source_root = ROOT / f'predicate-candidate-769-{label}-extra-sources'
        paths = add_regular_tree(members, source_root, f'sources/final-{label}-extra')
        assert len(paths) == len(freeze['extra_sources']) == 5
        snapshot_dirs[f'final_{label}'] = [str(p) for p in paths]
    for label in ('a1', 'a2'):
        initial = read_json(ROOT / f'predicate-candidate-first-build-768-{label}-source-freeze.json')
        source_root = ROOT / f'predicate-candidate-first-build-768-{label}-sources'
        paths = add_regular_tree(members, source_root, f'sources/initial-{label}')
        assert len(paths) == len(initial['changed_source_files']) == 14
        snapshot_dirs[f'initial_{label}'] = [str(p) for p in paths]
    data_root = ROOT / LABEL
    for path in stream_paths + witness_paths:
        add_file(members, archive_path(path), path)
    # Preserve the identical guard closure used by attribution evidence.
    for origin, relative in GUARD_DEPENDENCY_SOURCES:
        base = REPO if origin == 'repo' else LOCALDATA
        add_file(members, archive_path(base / relative), base / relative)

    # Preserve identities and exact build commands, but never copy executable
    # bytes or the Cargo target cache into the portable packet.
    omitted_binaries = {
        key: dict(value, reason='compiled test executable metadata retained; binary omitted',
                  cargo_cache_included=False)
        for key, value in build_metadata.items() if key != 'failed_first_build'
    }
    inventory = []
    frozen = {}
    for member_name, source in sorted(members.items()):
        data = source.read_bytes()
        row = {'path': member_name, 'original_path': str(source), 'bytes': len(data),
               'sha256': sha256_bytes(data)}
        inventory.append(row)
        frozen[member_name] = (row['bytes'], row['sha256'])
    assert inventory
    assert all('cargo-target' not in row['path'] for row in inventory)
    storage_before = check_budgets(ROOT, DEST, ROOT, min_free_bytes=12 * GIB,
                                   reserve_bytes=128 * MIB, max_workspace_bytes=100 * GIB,
                                   max_log_bytes=192 * MIB)
    assert not DEST.exists()
    DEST.mkdir()
    archive_path_out = DEST / f'{NAME}.tar.xz'
    with tarfile.open(archive_path_out, mode='x:xz', format=tarfile.PAX_FORMAT, preset=6) as archive:
        for row in inventory:
            source = members[row['path']]
            data = source.read_bytes()
            assert (len(data), sha256_bytes(data)) == (row['bytes'], row['sha256']), source
            info = tarfile.TarInfo(row['path'])
            info.size = len(data)
            info.mode = 0o644
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            info.mtime = 0
            archive.addfile(info, io.BytesIO(data))
    with tarfile.open(archive_path_out, mode='r:xz') as archive:
        assert archive.getnames() == [row['path'] for row in inventory]
        for row in inventory:
            member = archive.extractfile(row['path'])
            assert member is not None
            data = member.read()
            assert (len(data), sha256_bytes(data)) == (row['bytes'], row['sha256']), row['path']
    for member_name, source in members.items():
        assert (source.stat().st_size, sha256_file(source)) == frozen[member_name], source

    manifest = {'schema_version': 'shardloom.evidence_member_manifest.v1',
                'all_members_reopened': True, 'members': inventory}
    manifest_file = DEST / f'{NAME}.manifest.json.xz'
    with manifest_file.open('xb') as stream:
        stream.write(lzma.compress(encode_json(manifest), preset=6))
    assert json.loads(lzma.decompress(manifest_file.read_bytes())) == manifest
    index = {
        'schema_version': 'shardloom.predicate_candidate_portable_packet.v1',
        'status': 'verified_rejected_finite_candidate_comparison',
        'scope_result': decision['scope_result'], 'production_accepted': False,
        'claim_boundary': 'The frozen finite comparison rejects this candidate because two controls fail. No production acceptance, changed threshold, or semantic decision is asserted.',
        'protocols': {'candidate': identity(PROTOCOL), 'attribution': identity(ATTRIBUTION_PROTOCOL)},
        'sequence': {'identity': identity(SEQUENCE_IDENTITY), 'completion': identity(SEQUENCE_COMPLETION),
                     'ordered_roles': sequence_identity['ordered_roles'], 'steps': list(SEQUENCE_STEPS)},
        'comparison': {'decision': identity(DECISION), 'preflight_verification': identity(PREFLIGHT_PROOF),
                       'all_three_targets_pass_both_cohorts': True, 'controls_pass': False,
                       'failed_controls': failed_controls, 'resource_controls_pass': True,
                       'maximum_median_peak_overhead_bytes': maximum_peak_overhead,
                       'workflows': 1828, 'operations': 4260,
                       'focused_lifecycle_tests_passed': 16,
                       'focused_test_log': identity(ROOT / 'predicate-candidate-lifecycle-769-a2.log'),
                       'helper_tests_log': identity(ROOT / 'predicate-candidate-helper-tests-769.log'),
                       'raw_streams': stream_records,
                       'witnesses': [identity(p) for p in witness_paths]},
        'source_binding': {'head': EXPECTED_HEAD, 'current_frozen_source_count': len(freeze_a2['sources']),
                           'current_sources_all_hash_verified': True,
                           'a1_freeze': identity(ROOT / 'predicate-candidate-769-a1-source-freeze.json'),
                           'a2_freeze': identity(FINAL_FREEZE),
                           'a1_patch': identity(ROOT / 'predicate-candidate-769-a1-tracked.patch'),
                           'a2_patch': identity(ROOT / 'predicate-candidate-769-a2-tracked.patch'),
                           'initial_a1_freeze': identity(INITIAL_FREEZE_A1),
                           'initial_a2_freeze': identity(INITIAL_FREEZE_A2),
                           'snapshot_files': snapshot_dirs},
        'builds': build_metadata,
        'omitted_binaries': omitted_binaries,
        'prior_attribution_packet': attribution_reference,
        'independent_candidate_verification': independent_verification,
        'guard_dependency_sources': [str((REPO if origin == 'repo' else LOCALDATA) / relative)
                                     for origin, relative in GUARD_DEPENDENCY_SOURCES],
        'candidate_design_doc': identity(REPO / 'docs/architecture/native-predicate-exclusion-design-2026-10-19.md'),
        'inclusions': {'fixed_top_level_evidence': list(TOP_LEVEL_NAMES),
                       'guard_closure_matches_attribution_packager': True,
                       'source_trees': list(snapshot_dirs), 'cargo_cache_included': False,
                       'binary_bytes_included': False, 'data_tree': str(data_root)},
        'storage_check': {'guard': 'local_uat_storage.require_local_path and check_budgets',
                          'before_write': storage_before,
                          'limits': {'minimum_free_bytes': 12 * GIB, 'candidate_reserve_bytes': 128 * MIB,
                                     'maximum_workspace_bytes': 100 * GIB, 'maximum_log_bytes': 192 * MIB}},
        'member_count': len(inventory), 'uncompressed_bytes': sum(row['bytes'] for row in inventory),
        'all_members_reopened': True,
        'archive': {'file': archive_path_out.name, 'bytes': archive_path_out.stat().st_size,
                    'sha256': sha256_file(archive_path_out)},
        'manifest': {'file': manifest_file.name, 'bytes': manifest_file.stat().st_size,
                     'sha256': sha256_file(manifest_file)},
    }
    index_path = DEST / f'{NAME}.json'
    with index_path.open('xb') as stream:
        stream.write(encode_json(index))
    check_budgets(ROOT, DEST, ROOT, min_free_bytes=12 * GIB, reserve_bytes=0,
                  max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    print(json.dumps({'status': 'passed', 'members': len(inventory),
                      'uncompressed_bytes': index['uncompressed_bytes'],
                      'archive': index['archive'], 'manifest': index['manifest'],
                      'index': str(index_path), 'all_members_reopened': True}))


if __name__ == '__main__':
    main()
