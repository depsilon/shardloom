"""Independent readback of the frozen attribution packet; no packager import."""
import hashlib
import json
import lzma
from pathlib import Path
import tarfile

E = Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019')
W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
P = E / 'predicate-attribution-portable-767'
index_path = P / 'predicate-attribution-portable-767.json'
index = json.loads(index_path.read_bytes())
digest = lambda data: hashlib.sha256(data).hexdigest()
for kind in ['archive', 'manifest']:
    record = index[kind]
    data = (P / record['file']).read_bytes()
    assert (len(data), digest(data)) == (record['bytes'], record['sha256'])
manifest = json.loads(lzma.decompress((P / index['manifest']['file']).read_bytes()))
rows = manifest['members']
assert len(rows) == index['member_count'] == 123
assert len({row['path'] for row in rows}) == len(rows)
assert sum(row['bytes'] for row in rows) == index['uncompressed_bytes']
content = {}
with tarfile.open(P / index['archive']['file'], 'r:xz') as archive:
    assert archive.getnames() == [row['path'] for row in rows]
    for row in rows:
        member = archive.getmember(row['path'])
        assert member.isfile() and not Path(member.name).is_absolute()
        assert '..' not in Path(member.name).parts
        data = archive.extractfile(member).read()
        assert (len(data), digest(data)) == (row['bytes'], row['sha256'])
        original = Path(row['original_path'])
        assert original.is_file() and not original.is_symlink()
        assert original.read_bytes() == data
        content[member.name] = data
raw = {name: data for name, data in content.items()
       if name.startswith('comparison/') and name.endswith('.jsonl')}
witnesses = {name: data for name, data in content.items()
             if name.startswith('comparison/witnesses/')}
assert len(raw) == 6 and len(witnesses) == 42
workflows = [json.loads(line) for data in raw.values() for line in data.splitlines()]
assert len(workflows) == 1252
assert sum(len(row['operations']) for row in workflows) == 2916
for name, data in witnesses.items():
    assert Path(name).stem == digest(data)
freeze = json.loads(content['evidence/predicate-attribution-767-a2-source-freeze.json'])
assert len(freeze['sources']) == 1901
for row in freeze['sources']:
    data = (W / row['path']).read_bytes()
    assert (len(data), digest(data)) == (row['bytes'], row['sha256'])
first = json.loads(content['evidence/predicate-attribution-767-a1-source-freeze.json'])
for label, source in [('a1', first), ('a2', freeze)]:
    source_map = {row['path']: row for row in source['sources']}
    for relative in source['extra_sources']:
        data = content[f'sources/{label}-extra/{relative}']
        assert (len(data), digest(data)) == (source_map[relative]['bytes'], source_map[relative]['sha256'])
verification = json.loads(content['evidence/predicate-exclusion-verification-767.json'])
assert verification['status'] == 'passed'
assert verification['production_accepted'] is False
assert verification['common_qualifying_families'] == ['contains', 'correlated', 'membership']
assert all(row['qualifies_both_cohorts'] for row in verification['independently_recomputed_targets'])
receipt = {
    'status': 'passed', 'packet_index_sha256': digest(index_path.read_bytes()),
    'archive_sha256': index['archive']['sha256'],
    'manifest_sha256': index['manifest']['sha256'],
    'members': len(rows), 'workflows': len(workflows), 'operations': 2916,
    'full_content_witnesses': len(witnesses), 'unchanged_runtime_inputs': 1901,
    'production_accepted': False, 'scope_result': 'attribution_positive',
    'original_packager_preserved': True,
    'packager_review_corrections': [
        'Historical failed-build sources checked against their own frozen identities.',
        'Reviewed worker oracle points to the analyzer, not the native run driver.'
    ],
}
output = E / 'predicate-attribution-packet-verification-768.json'
assert not output.exists()
output.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
