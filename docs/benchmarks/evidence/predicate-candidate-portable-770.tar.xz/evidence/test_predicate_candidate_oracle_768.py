import importlib.util
import copy
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

SCRIPT = Path(__file__).with_name("analyze_predicate_candidate_768.py")
SPEC = importlib.util.spec_from_file_location("candidate_oracle", SCRIPT)
oracle = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(oracle)


def synthetic_loaded(case=None):
    loaded = {}
    for cohort in ("A", "B"):
        for role in ("baseline", "candidate"):
            records = [{"warmup": True}]
            for n, family, scenario, calls in oracle.cells():
                cid = f"{n}-{family}-{scenario}-{calls}"
                target = n == 65536 and scenario == "no_true" and calls == 4
                for sample in oracle.SAMPLES:
                    eng = 10_000_000
                    complete = 15_000_000
                    peak = 1_000_000
                    if role == "candidate" and target:
                        eng, complete = 7_000_000, 12_000_000
                    if case == "engine_absolute" and role == "candidate" and target and family == "correlated": eng = 8_100_000
                    if case == "complete_percent" and role == "candidate" and target and family == "membership": complete = 13_000_000
                    if case == "control_engine" and role == "candidate" and not target and cid == "8192-correlated-no_true-1": eng = 10_600_001
                    if case == "control_complete" and role == "candidate" and not target and cid == "8192-correlated-no_true-1": complete = 15_750_001
                    if case == "control_peak" and role == "candidate" and not target and cid == "8192-correlated-no_true-1": peak = 1_065_537
                    records.append({"warmup": False, "cell_id": cid, "sample": sample, "operations": [{"engine_execution_ns": eng // calls} for _ in range(calls)], "complete_workflow_ns": complete, "peak_reserved_bytes": peak})
            loaded[(cohort, role)] = {"records": records, "summary": {"sha256": "synthetic"}}
    return loaded


class CandidateOracleTests(unittest.TestCase):
    def test_protocol_hash_matrix_and_expected_activation(self):
        self.assertEqual(oracle.digest(oracle.PROTOCOL.read_bytes()), oracle.PROTOCOL_SHA256)
        self.assertEqual(len(oracle.cells()), 114)
        self.assertEqual(sum(c[3] for c in oracle.cells()), 266)
        self.assertEqual(oracle._cache_expected("candidate", 8192, "correlated", "no_true", 4, 3), {"keys_admitted": 4, "lookups": 4, "hits": 3, "proofs_staged": 1, "publications": 1, "replacements": 0, "pressure_evictions": 0, "keys_released": 0})
        self.assertEqual(oracle._cache_expected("candidate", 8192, "contains", "interleaved_parameters", 4, 3)["replacements"], 3)
        self.assertEqual(oracle._cache_expected("candidate", 8192, "membership", "replaced_source", 4, 3)["hits"], 0)
        self.assertTrue(all(v == 0 for v in oracle._cache_expected("candidate", 17, "correlated", "no_true", 4, 3).values()))

    def test_three_targets_and_all_controls_pass(self):
        result = oracle.decide(synthetic_loaded())
        self.assertTrue(result["controls_pass"])
        self.assertTrue(result["all_targets_pass"])
        self.assertEqual(len(result["targets"]), 3)
        self.assertEqual(result["scope_result"], "candidate_comparison_passed")
        self.assertFalse(result["production_accepted"])

    def test_target_requires_both_percentage_and_absolute_benefit(self):
        result = oracle.decide(synthetic_loaded("engine_absolute"))
        target = next(t for t in result["targets"] if "correlated" in t["cell_id"])
        self.assertFalse(target["cohorts"]["A"]["engine_benefit_pass"])
        self.assertFalse(result["all_targets_pass"])
        result = oracle.decide(synthetic_loaded("complete_percent"))
        target = next(t for t in result["targets"] if "membership" in t["cell_id"])
        self.assertFalse(target["cohorts"]["A"]["complete_benefit_pass"])

    def test_every_cell_control_rejects_clock_or_peak_regression(self):
        self.assertFalse(oracle.decide(synthetic_loaded("control_engine"))["controls_pass"])
        self.assertFalse(oracle.decide(synthetic_loaded("control_complete"))["controls_pass"])
        self.assertFalse(oracle.decide(synthetic_loaded("control_peak"))["controls_pass"])

    def test_no_cohort_or_target_substitution(self):
        loaded = synthetic_loaded()
        for record in loaded[("B", "candidate")]["records"]:
            if record.get("cell_id") == "65536-contains-no_true-4":
                for operation in record["operations"]:
                    operation["engine_execution_ns"] = 2_100_000
        result = oracle.decide(loaded)
        self.assertTrue(result["controls_pass"])
        self.assertFalse(result["all_targets_pass"])
        target = next(t for t in result["targets"] if "contains" in t["cell_id"])
        self.assertTrue(target["cohorts"]["A"]["target_qualifies"])
        self.assertFalse(target["cohorts"]["B"]["target_qualifies"])
        del loaded[("B", "baseline")]
        with self.assertRaises(oracle.Invalid):
            oracle.decide(loaded)

    def test_control_boundaries_require_both_strict_clock_thresholds(self):
        cid = "8192-correlated-no_true-1"
        for baseline, candidate, expected in [
            (10_000_000, 10_500_000, True),
            (10_000_000, 10_500_001, False),
            (1_000_000, 1_250_000, True),
            (1_000_000, 1_250_001, False),
        ]:
            loaded = synthetic_loaded()
            for role, value in [("baseline", baseline), ("candidate", candidate)]:
                for record in loaded[("B", role)]["records"]:
                    if record.get("cell_id") == cid:
                        record["operations"][0]["engine_execution_ns"] = value
            self.assertEqual(oracle.decide(loaded)["controls_pass"], expected)
        loaded = synthetic_loaded()
        for record in loaded[("B", "candidate")]["records"]:
            if record.get("cell_id") == cid:
                record["peak_reserved_bytes"] = 1_065_536
        self.assertTrue(oracle.decide(loaded)["controls_pass"])

    def test_nonempty_four_call_record_requires_cumulative_native_work(self):
        with tempfile.TemporaryDirectory() as td:
            data = Path(td)
            (data / "witnesses").mkdir()

            def witness(value):
                raw = json.dumps(value, separators=(",", ":")).encode()
                key = hashlib.sha256(raw).hexdigest()
                (data / "witnesses" / f"{key}.json").write_bytes(raw)
                return key

            source = [{"x": None if r % 17 == 0 else 2*(r % 2048),
                       "y": None if r % 17 == 0 else 2*(r % 2048),
                       "text": None if r % 17 == 0 else f"item/{r % 97}/part-{r % 11}",
                       "g": r % 8, "v": (r % 101)-50} for r in range(8192)]
            operations = []
            for call in range(4):
                count = call % 2 == 0
                rows = [{"rows": 0}] if count else []
                schema = oracle.COUNT_SCHEMA if count else oracle.GROUP_SCHEMA
                counters = {"keys_admitted": 4, "lookups": call+1, "hits": call,
                            "proofs_staged": 1, "publications": 1, "replacements": 0,
                            "pressure_evictions": 0, "keys_released": 0}
                operations.append({
                    "call": call, "consumer": "count" if count else "grouped_sum", "rows": len(rows),
                    "expected_rows_witness": witness(rows), "actual_rows_witness": witness(rows),
                    "expected_schema_witness": witness(schema), "actual_schema_witness": witness(schema),
                    "engine_execution_ns": 3, "result_serialization_ns": 2,
                    "execution_and_consumption_ns": 5, "output_release_ns": 7,
                    "completed_executions": call+1,
                    "observation": {"evaluation_calls": 1, "input_rows": 8192, "mask_calls": 1,
                                    "mask_input_rows": 8192, "selected_rows": 0, "evaluation_ns": 1, "mask_ns": 1},
                    "cache_observation": counters,
                    "native_io_certificate": {"certified": True, "fallback_attempted": False,
                        "complete_debug": f"scans_predicate_excluded={int(call > 0)} predicate_excluded_rows={8192 if call > 0 else 0}"},
                })
            after = dict(operations[-1]["cache_observation"], keys_released=4)
            record = {"protocol_id": oracle.PROTOCOL_ID, "cell_id": "8192-correlated-no_true-4",
                      "rows": 8192, "family": "correlated", "scenario": "no_true", "calls": 4,
                      "mode": "preflight", "role": "candidate", "cohort": "preflight", "sample": 0,
                      "warmup": False, "source_rows_witness": witness(source),
                      "source_schema_witness": witness(oracle.SOURCE_SCHEMA), "preparation_ns": 1,
                      "destruction_ns": 2, "complete_workflow_ns": 51, "operations": operations,
                      "completed_executions": 4, "prepared_source_opens": 0, "admitted_max_parallelism": 1,
                      "provider_background_workers": 0, "peak_reserved_bytes": 1_000_000,
                      "reserved_after_cleanup": 0, "denied_reservations": 0,
                      "cache_after_cleanup": after, "source_instances": 1}
            args = ("preflight", "candidate", "preflight", 0, (8192, "correlated", "no_true", 4), False)
            oracle._validate_record(data, record, *args)
            for field, value in [("evaluation_calls", 2), ("input_rows", 16384),
                                 ("mask_calls", 2), ("mask_input_rows", 16384), ("selected_rows", 1)]:
                bad = copy.deepcopy(record)
                bad["operations"][1]["observation"][field] = value
                with self.assertRaises(oracle.Invalid):
                    oracle._validate_record(data, bad, *args)
            for field in ("keys_admitted", "lookups", "hits", "proofs_staged", "publications",
                          "replacements", "pressure_evictions", "keys_released"):
                bad = copy.deepcopy(record)
                bad["operations"][2]["cache_observation"][field] += 1
                with self.assertRaises(oracle.Invalid):
                    oracle._validate_record(data, bad, *args)
            bad = copy.deepcopy(record)
            bad["operations"][3]["native_io_certificate"]["complete_debug"] = "scans_predicate_excluded=0 predicate_excluded_rows=0"
            with self.assertRaises(oracle.Invalid):
                oracle._validate_record(data, bad, *args)

    def test_typed_mismatch_and_missing_stream_rejected(self):
        self.assertFalse(oracle._typed_equal({"total": 1}, {"total": 1.0}))
        oracle._verify_exclusion_evidence("x scans_predicate_excluded=1 predicate_excluded_rows=8192", "scans_predicate_excluded", 1, "synthetic")
        with self.assertRaises(oracle.Invalid): oracle._verify_exclusion_evidence("scans_predicate_excluded=1 scans_predicate_excluded=1", "scans_predicate_excluded", 1, "duplicate")
        with self.assertRaises(oracle.Invalid): oracle._verify_exclusion_evidence("scans_predicate_excluded=10", "scans_predicate_excluded", 1, "wrong")
        with self.assertRaises(oracle.Invalid): oracle._verify_exclusion_evidence("x_scans_predicate_excluded=1", "scans_predicate_excluded", 1, "embedded")
        self.assertEqual(oracle._u64((1 << 64) - 1, "counter"), (1 << 64) - 1)
        with self.assertRaises(oracle.Invalid): oracle._u64(1 << 64, "counter")
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(oracle.Invalid): oracle.read(td, "measure", "baseline", "A")

    def test_small_record_rejects_value_schema_observer_cleanup_and_identity_drift(self):
        with tempfile.TemporaryDirectory() as td:
            data = Path(td)
            (data / "witnesses").mkdir()
            def witness(value):
                raw = json.dumps(value, separators=(",", ":")).encode()
                key = hashlib.sha256(raw).hexdigest()
                (data / "witnesses" / f"{key}.json").write_bytes(raw)
                return key
            zeros = dict.fromkeys(oracle.CACHE_KEYS, 0)
            obs = {k: 0 for k in ("evaluation_calls", "input_rows", "mask_calls", "mask_input_rows", "selected_rows", "evaluation_ns", "mask_ns")}
            proof = "scans_predicate_excluded=0 predicate_excluded_rows=0"
            op = {"call": 0, "consumer": "count", "rows": 1, "expected_rows_witness": witness([{"rows": 0}]), "expected_schema_witness": witness(oracle.COUNT_SCHEMA), "actual_rows_witness": witness([{"rows": 0}]), "actual_schema_witness": witness(oracle.COUNT_SCHEMA), "engine_execution_ns": 3, "result_serialization_ns": 2, "execution_and_consumption_ns": 5, "output_release_ns": 7, "completed_executions": 1, "observation": obs, "cache_observation": zeros, "native_io_certificate": {"certified": True, "fallback_attempted": False, "complete_debug": proof}}
            record = {"protocol_id": oracle.PROTOCOL_ID, "cell_id": "0-correlated-no_true-1", "rows": 0, "family": "correlated", "scenario": "no_true", "calls": 1, "mode": "preflight", "role": "baseline", "cohort": "preflight", "sample": 0, "warmup": False, "source_rows_witness": witness([]), "source_schema_witness": witness(oracle.SOURCE_SCHEMA), "preparation_ns": 1, "destruction_ns": 2, "complete_workflow_ns": 15, "operations": [op], "completed_executions": 1, "prepared_source_opens": 0, "admitted_max_parallelism": 1, "provider_background_workers": 0, "peak_reserved_bytes": 0, "reserved_after_cleanup": 0, "denied_reservations": 0, "cache_after_cleanup": zeros, "source_instances": 1}
            oracle._validate_record(data, record, "preflight", "baseline", "preflight", 0, (0, "correlated", "no_true", 1), False)
            bad = copy.deepcopy(record)
            bad["operations"][0]["actual_rows_witness"] = witness([{"rows": 1}])
            with self.assertRaises(oracle.Invalid): oracle._validate_record(data, bad, "preflight", "baseline", "preflight", 0, (0, "correlated", "no_true", 1), False)
            bad = copy.deepcopy(record)
            bad["operations"][0]["expected_schema_witness"] = witness(oracle.GROUP_SCHEMA)
            with self.assertRaises(oracle.Invalid): oracle._validate_record(data, bad, "preflight", "baseline", "preflight", 0, (0, "correlated", "no_true", 1), False)
            bad = copy.deepcopy(record)
            bad["operations"][0]["observation"]["evaluation_calls"] = 1
            with self.assertRaises(oracle.Invalid): oracle._validate_record(data, bad, "preflight", "baseline", "preflight", 0, (0, "correlated", "no_true", 1), False)
            bad = copy.deepcopy(record)
            bad["cache_after_cleanup"]["keys_released"] = 1
            with self.assertRaises(oracle.Invalid): oracle._validate_record(data, bad, "preflight", "baseline", "preflight", 0, (0, "correlated", "no_true", 1), False)
            bad = copy.deepcopy(record)
            bad["source_rows_witness"] = "z" * 64
            with self.assertRaises(oracle.Invalid): oracle._validate_record(data, bad, "preflight", "baseline", "preflight", 0, (0, "correlated", "no_true", 1), False)


if __name__ == "__main__":
    unittest.main()
