"""Freeze, bind, verify, and supervise one native predicate candidate executable."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PROTOCOL = OUT / 'predicate-exclusion-candidate-protocol-768.json'
ATTRIBUTION = OUT / 'predicate-exclusion-attribution-protocol-766.json'
PROTOCOL_SHA = 'e8653d467b11c9d5928b6be5bd2776ff840672b999d3dfaabac6ee3714c5ae5a'
GUARD = OUT / 'run_guarded_observed_757.py'
SELECTOR = 'local_primitives::prepared_relational::tests::predicate_candidate_cost_tests::native_predicate_exclusion_candidate'
ANALYZER = OUT / 'analyze_predicate_candidate_768.py'
ORACLE_TEST = OUT / 'test_predicate_candidate_oracle_768.py'
HELPERS = [ATTRIBUTION, PROTOCOL, GUARD, Path(__file__), ORACLE_TEST, ANALYZER,
           OUT / 'test_predicate_candidate_driver_769.py']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def source_paths():
    names = subprocess.check_output(
        ['git', 'ls-files', '--cached', '--others', '--exclude-standard'],
        cwd=REPO, text=True).splitlines()
    return sorted(p for p in set(names) if p.endswith('.rs') or
                  Path(p).name in ('Cargo.toml', 'Cargo.toml.orig', 'Cargo.lock'))


def verify_sources(freeze):
    assert sha(PROTOCOL) == PROTOCOL_SHA
    assert sha(ATTRIBUTION) == freeze['attribution_protocol_sha256']
    assert source_paths() == [row['path'] for row in freeze['sources']]
    for row in freeze['sources']:
        path = REPO / row['path']
        assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], row['path']
    for row in freeze['helpers']:
        assert sha(row['path']) == row['sha256'], row['path']


def historical_sources(label, freeze):
    assert sha(OUT / f'{label}-tracked.patch') == freeze['patch_sha256']
    sources = {row['path']: row for row in freeze['sources']}
    for path in freeze['extra_sources']:
        original = OUT / f'{label}-extra-sources' / path
        assert original.stat().st_size == sources[path]['bytes'] and sha(original) == sources[path]['sha256']


def verify_initial_build_freeze(path, final_freeze, build_name):
    path = Path(path).resolve()
    assert path == (OUT / f'{build_name}-source-freeze.json').resolve()
    initial = json.loads(path.read_text())
    assert initial['stage'] == 'initial_compile_snapshot_before_build'
    assert initial['head'] == final_freeze['head']
    assert initial['sources'] == final_freeze['sources']
    assert initial['protocol_sha256'] == PROTOCOL_SHA
    assert initial['patch_sha256'] == final_freeze['patch_sha256']
    source_rows = {row['path']: row for row in initial['sources']}
    for source in initial['changed_source_files']:
        row = source_rows[source]
        copied = OUT / f'{build_name}-sources' / source
        assert copied.stat().st_size == row['bytes'] and sha(copied) == row['sha256'], source
    patch = OUT / f'{build_name}-tracked.patch'
    assert sha(patch) == initial['patch_sha256']
    return initial, path


def require_fresh_compiler_artifact(artifacts):
    assert len(artifacts) == 1 and artifacts[0]['executable'] and not artifacts[0]['fresh']
    return artifacts[0]


def make_run_command(binary, name, mode, role, cohort, data):
    assert mode in ('preflight', 'measure')
    assert role in ('baseline', 'candidate')
    assert cohort in ('preflight', 'A', 'B')
    assert (mode == 'preflight') == (cohort == 'preflight')
    data = Path(data)
    assert data.parent == OUT and data.name.startswith('predicate-candidate-')
    data.mkdir(exist_ok=True)
    return [sys.executable, str(GUARD), '--name', name, '--timeout', '1800', '--', '/usr/bin/env',
            f'SHARDLOOM_PREDICATE_CANDIDATE_ROOT={data}',
            f'SHARDLOOM_PREDICATE_CANDIDATE_MODE={mode}',
            f'SHARDLOOM_PREDICATE_CANDIDATE_ROLE={role}',
            f'SHARDLOOM_PREDICATE_CANDIDATE_COHORT={cohort}',
            str(binary), SELECTOR, '--exact', '--ignored', '--nocapture', '--test-threads=1']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['freeze', 'bind', 'verify', 'run'])
    parser.add_argument('--label', required=True)
    parser.add_argument('--build')
    parser.add_argument('--initial-build-freeze')
    parser.add_argument('--name')
    parser.add_argument('--mode', choices=['preflight', 'measure'])
    parser.add_argument('--role', choices=['baseline', 'candidate'])
    parser.add_argument('--cohort', default='preflight', choices=['preflight', 'A', 'B'])
    parser.add_argument('--data', default='predicate-candidate-769-a1')
    args = parser.parse_args()
    assert args.label.replace('-', '').isalnum() and sha(PROTOCOL) == PROTOCOL_SHA
    freeze_path = OUT / f'{args.label}-source-freeze.json'
    artifact_path = OUT / f'{args.label}-artifact.json'
    if args.action == 'freeze':
        paths = source_paths()
        sources = [dict(path=p, bytes=(REPO / p).stat().st_size, sha256=sha(REPO / p)) for p in paths]
        patch = OUT / f'{args.label}-tracked.patch'
        with patch.open('xb') as stream:
            stream.write(subprocess.check_output(['git', 'diff', '--binary'], cwd=REPO))
        extras = subprocess.check_output(
            ['git', 'ls-files', '--others', '--exclude-standard'], cwd=REPO, text=True).splitlines()
        extras = [p for p in extras if p in paths]
        for path in extras:
            target = OUT / f'{args.label}-extra-sources' / path
            target.parent.mkdir(parents=True, exist_ok=True)
            assert not target.exists()
            shutil.copyfile(REPO / path, target)
        save(freeze_path, dict(head=subprocess.check_output(
            ['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(), sources=sources,
            extra_sources=extras, patch_sha256=sha(patch), protocol_sha256=PROTOCOL_SHA,
            attribution_protocol_sha256=sha(ATTRIBUTION),
            helpers=[dict(path=str(p), sha256=sha(p)) for p in HELPERS]))
        print(json.dumps(dict(source_freeze=str(freeze_path), sha256=sha(freeze_path), runtime_inputs=len(sources))))
        return
    freeze = json.loads(freeze_path.read_text())
    historical_sources(args.label, freeze)
    verify_sources(freeze)
    if args.action == 'bind':
        assert args.build
        initial_binding = None
        if args.initial_build_freeze:
            initial, initial_path = verify_initial_build_freeze(args.initial_build_freeze, freeze, args.build)
            initial_binding = dict(path=str(initial_path), sha256=sha(initial_path),
                                   stage=initial['stage'], name=args.build)
        build_path = OUT / f'{args.build}.json'
        build = json.loads(build_path.read_text())
        assert build['status'] == 'passed' and build['process_group_drained'] and build['returncode'] == 0
        assert sha(OUT / f'{args.build}.log') == build['log_sha256']
        artifacts = []
        for line in (OUT / f'{args.build}.log').read_text().splitlines():
            if not line.startswith('{'):
                continue
            item = json.loads(line)
            if item.get('reason') == 'compiler-artifact' and item.get('target', {}).get('name') == 'shardloom_vortex' and item.get('profile', {}).get('test'):
                artifacts.append(item)
        compiler_artifact = require_fresh_compiler_artifact(artifacts)
        source = Path(compiler_artifact['executable'])
        binary = OUT / f'{args.label}-test'
        assert not binary.exists()
        shutil.copy2(source, binary)
        assert sha(binary) == sha(source)
        inventory = subprocess.check_output([str(binary), '--list'], text=True)
        assert f'{SELECTOR}: test' in inventory
        (OUT / f'{args.label}-test-inventory.txt').write_text(inventory)
        receipt = dict(artifact=str(binary), artifact_sha256=sha(binary), bytes=binary.stat().st_size,
                       source_freeze_sha256=sha(freeze_path), build=args.build,
                       build_receipt_sha256=sha(build_path), compiler_artifact=compiler_artifact)
        if initial_binding:
            receipt['initial_build_freeze'] = initial_binding
        save(artifact_path, receipt)
        print(json.dumps(dict(artifact=str(binary), sha256=sha(binary))))
        return
    artifact = json.loads(artifact_path.read_text())
    binary = Path(artifact['artifact'])
    assert sha(binary) == artifact['artifact_sha256'] and sha(freeze_path) == artifact['source_freeze_sha256']
    if args.action == 'verify':
        print(json.dumps(dict(workspace_sources_unchanged=True, artifact_and_historical_source_binding_unchanged=True)))
        return
    assert args.name and args.mode and args.role
    data = OUT / args.data
    command = make_run_command(binary, args.name, args.mode, args.role, args.cohort, data)
    record = dict(command=command, role=args.role, mode=args.mode, cohort=args.cohort,
                  artifact_sha256=sha(binary), source_freeze_sha256=sha(freeze_path),
                  protocol_sha256=PROTOCOL_SHA, driver_sha256=sha(__file__), guard_sha256=sha(GUARD))
    try:
        code = subprocess.call(command, cwd=REPO)
        record['returncode'] = code
        verify_sources(freeze)
        historical_sources(args.label, freeze)
        assert sha(binary) == artifact['artifact_sha256']
        record['sources_and_artifact_unchanged'] = True
        output = data / f'{args.mode}-{args.cohort}-{args.role}.jsonl'
        if output.exists():
            record.update(output=str(output), output_sha256=sha(output), output_bytes=output.stat().st_size)
    finally:
        save(OUT / f'{args.name}-link.json', record)
    raise SystemExit(code)


if __name__ == '__main__':
    main()
