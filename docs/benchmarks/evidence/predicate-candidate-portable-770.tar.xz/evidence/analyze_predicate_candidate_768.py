#!/usr/bin/env python3
"""Independent validator and decision oracle for frozen candidate protocol 768."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import statistics
from pathlib import Path
from typing import Any

ROOT = Path(__file__).parent
PROTOCOL = ROOT / "predicate-exclusion-candidate-protocol-768.json"
PROTOCOL_SHA256 = "e8653d467b11c9d5928b6be5bd2776ff840672b999d3dfaabac6ee3714c5ae5a"
ATTRIBUTION = ROOT / "predicate-exclusion-attribution-protocol-766.json"
PROTOCOL_ID = "predicate-exclusion-candidate-768-v1"
FAMILIES = ("correlated", "membership", "contains")
SCENARIOS = ("no_true", "positive", "all_null", "changed_parameters", "replaced_source", "interleaved_parameters")
CALLS = (1, 2, 4)
ROWS = (8192, 65536)
SAMPLES = (0, 1, 2)
MEMORY_LIMIT = 33554432
CACHE_KEYS = ("keys_admitted", "lookups", "hits", "proofs_staged", "publications", "replacements", "pressure_evictions", "keys_released")
COUNT_SCHEMA = {"Struct": [{"names": ["rows"], "dtypes": [{"Primitive": ["u64", False]}]}, False]}
GROUP_SCHEMA = {"Struct": [{"names": ["g", "total"], "dtypes": [{"Primitive": ["i64", False]}, {"Primitive": ["f64", True]}]}, False]}
SOURCE_SCHEMA = {"Struct": [{"names": ["x", "y", "text", "g", "v"], "dtypes": [{"Primitive": ["i64", True]}, {"Primitive": ["i64", True]}, {"Utf8": True}, {"Primitive": ["i64", False]}, {"Primitive": ["i64", False]}]}, False]}


class Invalid(ValueError):
    pass


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _need(ok: bool, message: str) -> None:
    if not ok:
        raise Invalid(message)


def _typed_equal(actual: Any, expected: Any) -> bool:
    if type(actual) is not type(expected): return False
    if isinstance(expected, dict):
        return actual.keys() == expected.keys() and all(_typed_equal(actual[k], expected[k]) for k in expected)
    if isinstance(expected, list):
        return len(actual) == len(expected) and all(_typed_equal(a, b) for a, b in zip(actual, expected))
    return actual == expected


def _integer(value: Any, label: str, minimum: int = 0) -> int:
    _need(type(value) is int and value >= minimum, f"{label} must be an integer >= {minimum}")
    return value


def _u64(value: Any, label: str) -> int:
    _integer(value, label)
    _need(value <= (1 << 64) - 1, f"{label} exceeds u64")
    return value


def cells(rows=ROWS) -> list[tuple[int, str, str, int]]:
    out = []
    for n in rows:
        for f in FAMILIES:
            for s in SCENARIOS:
                for c in CALLS:
                    out.append((n, f, s, c))
        for c in CALLS:
            out.append((n, "unfiltered", "unfiltered", c))
    return out


def _source(n: int, scenario: str, family: str) -> list[dict[str, Any]]:
    result = []
    for r in range(n):
        present = r % 17 != 0 and scenario != "all_null"
        base = 2 * (r % 2048)
        x: Any = base if present else None
        y: Any = base if present else None
        t: Any = f"item/{r % 97}/part-{r % 11}" if present else None
        if scenario == "positive" and present:
            if family == "correlated": y = base - 4096
            elif family == "membership": x = base + 1
            elif family == "contains": t += "::absent::"
        result.append({"x": x, "y": y, "text": t, "g": r % 8, "v": (r % 101) - 50})
    return result


def _selected(row: dict[str, Any], family: str, scenario: str, call: int) -> bool:
    if family == "unfiltered": return True
    k = call if scenario == "changed_parameters" else call % 2 if scenario == "interleaved_parameters" else 0
    if family == "correlated":
        return row["x"] is not None and row["y"] is not None and row["x"] > 2047 + 2*k and row["y"] < 2048 + 2*k
    if family == "membership":
        return row["x"] is not None and row["x"] in {1 + 32*k + 2*i for i in range(16)}
    needle = "::absent::" + (str(k) if k else "")
    return row["text"] is not None and needle in row["text"]


def _witness(data_dir: Path, ref: Any, expected: Any, label: str) -> Any:
    _need(isinstance(ref, str) and len(ref) == 64 and all(ch in "0123456789abcdef" for ch in ref), f"malformed witness identity: {label}")
    p = data_dir / "witnesses" / f"{ref}.json"
    _need(p.is_file(), f"missing witness {label}: {ref}")
    raw = p.read_bytes()
    _need(digest(raw) == ref, f"witness content hash mismatch: {label}")
    try: value = json.loads(raw)
    except Exception as e: raise Invalid(f"invalid witness JSON {label}: {e}") from e
    _need(_typed_equal(value, expected), f"witness value or JSON type mismatch: {label}")
    return value


def _cache_expected(role: str, n: int, family: str, scenario: str, calls: int, through: int) -> dict[str, int]:
    counts = dict.fromkeys(CACHE_KEYS, 0)
    if role == "baseline" or n < 8192 or family == "unfiltered": return counts
    counts["keys_admitted"] = calls
    counts["lookups"] = through + 1
    if scenario in ("no_true", "all_null"):
        counts["proofs_staged"] = counts["publications"] = 1
        counts["hits"] = through
    elif scenario in ("changed_parameters", "interleaved_parameters"):
        counts["proofs_staged"] = counts["publications"] = through + 1
        counts["replacements"] = through
    elif scenario == "replaced_source":
        counts["proofs_staged"] = counts["publications"] = through + 1
    return counts


def _verify_exclusion_evidence(text: str, field: str, expected: int, label: str) -> None:
    pattern = rf"(?<![A-Za-z0-9_]){field}=(\d+)(?![A-Za-z0-9_])"
    matches = re.findall(pattern, text)
    _need(len(matches) == 1 and int(matches[0]) == expected, f"{label} must contain exactly one {field}={expected}")


def _validate_record(data: Path, rec: dict[str, Any], mode: str, role: str, cohort: str, sample: int, cell: tuple[int, str, str, int], warm: bool) -> None:
    n, family, scenario, calls = cell
    expected_id = f"{n}-{family}-{scenario}-{calls}"
    for key, value in {"protocol_id": PROTOCOL_ID, "cell_id": expected_id, "rows": n, "family": family, "scenario": scenario, "calls": calls, "mode": mode, "role": role, "cohort": cohort, "sample": sample, "warmup": warm}.items():
        _need(rec.get(key) == value and type(rec.get(key)) is type(value), f"{expected_id}: incorrect {key}")
    source_scenario = "no_true" if scenario in ("replaced_source", "interleaved_parameters") else scenario
    source = _source(n, source_scenario, family)
    _witness(data, rec.get("source_rows_witness"), source, "source rows")
    _witness(data, rec.get("source_schema_witness"), SOURCE_SCHEMA, "source schema")
    prep = _integer(rec.get("preparation_ns"), "preparation_ns")
    destroy = _integer(rec.get("destruction_ns"), "destruction_ns")
    engine_total = 0
    obs_prev = {k: 0 for k in ("evaluation_calls", "input_rows", "mask_calls", "mask_input_rows", "selected_rows", "evaluation_ns", "mask_ns")}
    cache_prev = dict.fromkeys(CACHE_KEYS, 0)
    ops = rec.get("operations")
    _need(isinstance(ops, list) and len(ops) == calls, f"{expected_id}: wrong operations count")
    for i, op in enumerate(ops):
        consumer = "count" if i % 2 == 0 else "grouped_sum"
        selected = [row for row in source if _selected(row, family, scenario, i)]
        exp_rows = [{"rows": len(selected)}] if consumer == "count" else _groups(selected)
        schema = COUNT_SCHEMA if consumer == "count" else GROUP_SCHEMA
        for k, v in {"call": i, "consumer": consumer, "rows": len(exp_rows)}.items(): _need(_typed_equal(op.get(k), v), f"{expected_id} op{i}: incorrect {k}")
        _witness(data, op.get("expected_rows_witness"), exp_rows, f"expected rows op{i}")
        _witness(data, op.get("expected_schema_witness"), schema, f"expected schema op{i}")
        _witness(data, op.get("actual_rows_witness"), exp_rows, f"actual rows op{i}")
        _witness(data, op.get("actual_schema_witness"), schema, f"actual schema op{i}")
        for key in ("engine_execution_ns", "result_serialization_ns", "execution_and_consumption_ns", "output_release_ns"):
            _integer(op.get(key), f"{expected_id} op{i} {key}")
        _need(_typed_equal(op.get("completed_executions"), i+1), f"{expected_id} op{i}: shared-session execution counter mismatch")
        _need(op["engine_execution_ns"] + op["result_serialization_ns"] <= op["execution_and_consumption_ns"], f"{expected_id} op{i}: engine/serialization exceeds complete consumption")
        engine_total += op["engine_execution_ns"]
        cert = op.get("native_io_certificate")
        _need(isinstance(cert, dict) and cert.keys() == {"certified", "fallback_attempted", "complete_debug"} and cert.get("certified") is True and cert.get("fallback_attempted") is False and isinstance(cert.get("complete_debug"), str) and cert["complete_debug"].strip(), f"{expected_id} op{i}: invalid certificate shape or status")
        excluded = role == "candidate" and n >= 8192 and family != "unfiltered" and scenario in ("no_true", "all_null") and i > 0
        expected_scans, expected_excluded_rows = (1, n) if excluded else (0, 0)
        for field, expected in (("scans_predicate_excluded", expected_scans), ("predicate_excluded_rows", expected_excluded_rows)):
            _verify_exclusion_evidence(cert["complete_debug"], field, expected, f"{expected_id} op{i} complete_debug")
        obs = op.get("observation")
        _need(isinstance(obs, dict) and obs.keys() == obs_prev.keys(), f"{expected_id} op{i}: missing or unexpected observation fields")
        for key in obs_prev:
            _integer(obs.get(key), f"{expected_id} op{i} observation.{key}")
            _need(obs[key] >= obs_prev[key], f"{expected_id} op{i}: decreasing observation {key}")
        obs_prev = obs
        if family == "unfiltered" or n == 0: _need(all(obs[k] == 0 for k in obs), f"{expected_id}: inactive observer nonzero")
        else:
            filtered = family != "unfiltered" and n > 0
            if role == "candidate" and n >= 8192 and scenario in ("no_true", "all_null"):
                # Snapshots are cumulative: later hits add no work but retain
                # the first call's complete native evaluation in every snapshot.
                native_calls = 1
                native_through = 1
            else:
                native_calls = i + 1
                native_through = i + 1
            eval_calls = ((n + 8191)//8192) * native_calls if filtered else 0
            must = {"evaluation_calls": eval_calls, "input_rows": n*native_calls if filtered else 0, "mask_calls": eval_calls, "mask_input_rows": n*native_calls if filtered else 0, "selected_rows": sum(len([r for r in source if _selected(r, family, scenario, j)]) for j in range(native_through)) if filtered else 0}
            for key, val in must.items(): _need(obs[key] == val, f"{expected_id} op{i}: wrong observer {key}")
        cache = op.get("cache_observation")
        _need(isinstance(cache, dict) and cache.keys() == set(CACHE_KEYS), f"{expected_id} op{i}: cache observation fields differ")
        for key in CACHE_KEYS:
            _u64(cache[key], f"{expected_id} op{i} cache.{key}")
            _need(cache[key] >= cache_prev[key], f"{expected_id} op{i}: decreasing cache counter {key}")
        cache_prev = cache
        expected_cache = _cache_expected(role, n, family, scenario, calls, i)
        _need(_typed_equal(cache, expected_cache), f"{expected_id} op{i}: cache activation/counter mismatch")
        _need(obs["evaluation_ns"] + obs["mask_ns"] <= sum(x["engine_execution_ns"] for x in ops[:i+1]), f"{expected_id} op{i}: stage time exceeds engine time")
    _need(_typed_equal(rec.get("completed_executions"), calls), f"{expected_id}: workflow completion mismatch")
    for key, expected in {"prepared_source_opens": 0, "admitted_max_parallelism": 1, "provider_background_workers": 0, "reserved_after_cleanup": 0, "denied_reservations": 0}.items(): _need(_typed_equal(rec.get(key), expected), f"{expected_id}: invalid {key}")
    expected_instances = calls if scenario == "replaced_source" else 1
    _need(_typed_equal(rec.get("source_instances"), expected_instances), f"{expected_id}: invalid source_instances")
    after = rec.get("cache_after_cleanup")
    _need(isinstance(after, dict) and after.keys() == set(CACHE_KEYS), f"{expected_id}: malformed cleanup cache snapshot")
    for key in CACHE_KEYS: _u64(after[key], f"{expected_id} cache_after_cleanup.{key}")
    final_expected = dict(cache_prev)
    final_expected["keys_released"] = final_expected["keys_admitted"]
    _need(_typed_equal(after, final_expected), f"{expected_id}: cache key cleanup mismatch")
    peak = _integer(rec.get("peak_reserved_bytes"), "peak_reserved_bytes")
    _need(peak <= MEMORY_LIMIT, f"{expected_id}: memory limit exceeded")
    expected_workflow = prep + destroy + sum(o["execution_and_consumption_ns"] + o["output_release_ns"] for o in ops)
    _need(_typed_equal(rec.get("complete_workflow_ns"), expected_workflow), f"{expected_id}: complete workflow clock mismatch")


def _groups(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    sums: dict[int, int] = {}
    for r in rows: sums[r["g"]] = sums.get(r["g"], 0) + r["v"]
    return [{"g": g, "total": float(sums[g])} for g in sorted(sums)]


def _stream_path(data: Path, mode: str, role: str, cohort: str) -> Path:
    stem = f"preflight-preflight-{role}" if mode == "preflight" else f"measure-{cohort}-{role}"
    return data / f"{stem}.jsonl"


def read(data: Path | str, mode: str, role: str, cohort: str) -> dict[str, Any]:
    data = Path(data)
    _need(digest(PROTOCOL.read_bytes()) == PROTOCOL_SHA256, "frozen candidate protocol changed")
    _need(digest(ATTRIBUTION.read_bytes()) == "153892a4e056c9adf769dd65ba758ec304f70a2f8d62111d3b96197842d9a5e3", "imported attribution protocol changed")
    _need(mode in ("preflight", "measure") and role in ("baseline", "candidate") and cohort in ("preflight", "A", "B"), "invalid stream selector")
    _need((mode == "preflight") == (cohort == "preflight"), "cohort/mode mismatch")
    path = _stream_path(data, mode, role, cohort)
    _need(path.is_file(), f"missing stream: {path.name}")
    raw = path.read_bytes()
    records = []
    for line_no, line in enumerate(raw.splitlines(), 1):
        try: item = json.loads(line)
        except Exception as e: raise Invalid(f"{path.name}:{line_no}: invalid JSON: {e}") from e
        _need(isinstance(item, dict), f"{path.name}:{line_no}: record is not object")
        records.append(item)
    expected_cells = cells((0, 17, 8192, 65536)) if mode == "preflight" else cells()
    warmcell = (8192, "unfiltered", "unfiltered", 1)
    ordered_cells = list(reversed(expected_cells)) if cohort == "B" else expected_cells
    sequence = [(cell, 0, False) for cell in ordered_cells] if mode == "preflight" else [(warmcell, 0, True)]
    if mode == "measure": sequence += [(cell, sample, False) for cell in ordered_cells for sample in SAMPLES]
    _need(len(records) == len(sequence), f"{path.name}: expected {len(sequence)} records, got {len(records)}")
    for rec, (cell, sample, warm) in zip(records, sequence):
        _validate_record(data, rec, mode, role, cohort, sample, cell, warm)
    ops = sum(len(r["operations"]) for r in records)
    expect_ops = 532 if mode == "preflight" else 799
    _need(ops == expect_ops, f"{path.name}: expected {expect_ops} operations, got {ops}")
    return {"records": records, "summary": {"stream": path.name, "sha256": digest(raw), "bytes": len(raw), "workflows": len(records), "operations": ops}}


def decide(loaded: dict) -> dict[str, Any]:
    by = {}
    expected_keys = {(c, r) for c in ("A", "B") for r in ("baseline", "candidate")}
    _need(set(loaded) == expected_keys, "decision requires all four baseline/candidate cohort streams")
    for (cohort, role), bundle in loaded.items():
        records = bundle.get("records") if isinstance(bundle, dict) else None
        _need(isinstance(records, list) and sum(bool(r.get("warmup")) for r in records if isinstance(r, dict)) == 1, f"{cohort}/{role}: must retain exactly one excluded warmup")
        rows = [r for r in records if not r["warmup"]]
        by[(cohort, role)] = {(r["cell_id"], r["sample"]): r for r in rows}
        _need(len(rows) == 342 and len(by[(cohort, role)]) == 342, f"{cohort}/{role}: duplicate or missing measured identity")
        expected_ids = {(f"{n}-{family}-{scenario}-{calls}", sample) for n, family, scenario, calls in cells() for sample in SAMPLES}
        _need(set(by[(cohort, role)]) == expected_ids, f"{cohort}/{role}: measured cell/sample coverage mismatch")
    targets = {(65536, f, "no_true", 4) for f in FAMILIES}
    out = []
    all_cells = []
    for n, fam, scen, calls in cells():
        cid = f"{n}-{fam}-{scen}-{calls}"
        cohort_data = {}
        target_pass = True
        for cohort in ("A", "B"):
            baseline = [by[(cohort,"baseline")][(cid,s)] for s in SAMPLES]
            candidate = [by[(cohort,"candidate")][(cid,s)] for s in SAMPLES]
            be = statistics.median(sum(o["engine_execution_ns"] for o in r["operations"]) for r in baseline)
            ce = statistics.median(sum(o["engine_execution_ns"] for o in r["operations"]) for r in candidate)
            bc = statistics.median(r["complete_workflow_ns"] for r in baseline)
            cc = statistics.median(r["complete_workflow_ns"] for r in candidate)
            bp = statistics.median(r["peak_reserved_bytes"] for r in baseline)
            cp = statistics.median(r["peak_reserved_bytes"] for r in candidate)
            engine_bad = ce * 100 > be * 105 and ce - be > 250000
            complete_bad = cc * 100 > bc * 105 and cc - bc > 250000
            peak_bad = cp - bp > 65536
            control = not (engine_bad or complete_bad or peak_bad)
            engine_delta, complete_delta = be - ce, bc - cc
            engine_benefit = engine_delta >= 2000000 and engine_delta * 100 >= be * 20
            complete_benefit = complete_delta >= 2000000 and complete_delta * 100 >= bc * 15
            qualifies = control and engine_benefit and complete_benefit
            target_pass &= qualifies
            cohort_data[cohort] = {"median_baseline_engine_ns": be, "median_candidate_engine_ns": ce, "median_baseline_complete_ns": bc, "median_candidate_complete_ns": cc, "median_baseline_peak_reserved_bytes": bp, "median_candidate_peak_reserved_bytes": cp, "control_pass": control, "engine_benefit_ns": engine_delta, "engine_benefit_pass": engine_benefit, "complete_benefit_ns": complete_delta, "complete_benefit_pass": complete_benefit, "target_qualifies": qualifies}
        item = {"cell_id": cid, "cohorts": cohort_data, "qualifies_both_cohorts": target_pass, "control_pass_both_cohorts": all(v["control_pass"] for v in cohort_data.values())}
        all_cells.append(item)
        if (n, fam, scen, calls) in targets: out.append(item)
    controls_ok = all(x["control_pass_both_cohorts"] for x in all_cells)
    targets_ok = all(x["qualifies_both_cohorts"] for x in out)
    accepted = controls_ok and targets_ok
    return {"protocol_id": PROTOCOL_ID, "protocol_sha256": digest(PROTOCOL.read_bytes()), "attribution_protocol_sha256": digest(ATTRIBUTION.read_bytes()), "validator_sha256": digest(Path(__file__).read_bytes()), "streams": {f"{c}-{r}": v["summary"] for (c,r),v in loaded.items()}, "cells": all_cells, "targets": out, "controls_pass": controls_ok, "all_targets_pass": targets_ok, "scope_result": "candidate_comparison_passed" if accepted else "candidate_comparison_rejected", "production_accepted": False}


def analyze(data: Path | str) -> dict[str, Any]:
    data = Path(data)
    preflight = {role: read(data, "preflight", role, "preflight") for role in ("baseline", "candidate")}
    loaded = {(cohort, role): read(data, "measure", role, cohort) for cohort in ("A", "B") for role in ("baseline", "candidate")}
    report = decide(loaded)
    report["streams"].update({f"preflight-{role}": item["summary"] for role, item in preflight.items()})
    return report


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=("preflight", "decision"))
    ap.add_argument("--data", type=Path, required=True)
    ap.add_argument("--output", type=Path)
    args = ap.parse_args()
    if args.mode == "preflight":
        report = {"protocol_id": PROTOCOL_ID, "protocol_sha256": digest(PROTOCOL.read_bytes()), "attribution_protocol_sha256": digest(ATTRIBUTION.read_bytes()), "validator_sha256": digest(Path(__file__).read_bytes()), "streams": {r: read(args.data, "preflight", r, "preflight")["summary"] for r in ("baseline", "candidate")}, "production_accepted": False}
    else: report = analyze(args.data)
    payload = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with args.output.open("x", encoding="utf-8") as f: f.write(payload)
    else: print(payload, end="")


if __name__ == "__main__": main()
