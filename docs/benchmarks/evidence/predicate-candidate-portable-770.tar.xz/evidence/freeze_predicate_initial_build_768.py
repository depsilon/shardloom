"""Preserve exact initial candidate compilation sources before each attempt."""
from pathlib import Path
import subprocess, hashlib, json, shutil, sys

w = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
e = Path(__file__).resolve().parent
name = sys.argv[1]
assert name.startswith('predicate-candidate-first-build-768-') and name.replace('-', '').isalnum()
dest = e / (name + '-sources')
dest.mkdir()
paths = sorted(set(subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=w, text=True).splitlines()))
paths = [p for p in paths if p.endswith('.rs') or Path(p).name in ['Cargo.toml', 'Cargo.lock', 'Cargo.toml.orig']]
changed = sorted(set(subprocess.check_output(['git', 'diff', '--name-only'], cwd=w, text=True).splitlines() + subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=w, text=True).splitlines()))
for p in changed:
    if p in paths:
        target = dest / p
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(w / p, target)
patch = subprocess.check_output(['git', 'diff', '--binary'], cwd=w)
(e / (name + '-tracked.patch')).write_bytes(patch)
receipt = {
    'stage': 'initial_compile_snapshot_before_build',
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=w, text=True).strip(),
    'sources': [{'path': p, 'bytes': (w / p).stat().st_size, 'sha256': hashlib.sha256((w / p).read_bytes()).hexdigest()} for p in paths],
    'changed_source_files': [p for p in changed if p in paths],
    'patch_sha256': hashlib.sha256(patch).hexdigest(),
    'protocol_sha256': hashlib.sha256((e / 'predicate-exclusion-candidate-protocol-768.json').read_bytes()).hexdigest(),
}
(e / (name + '-source-freeze.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'source_freeze': name, 'runtime_inputs': len(paths), 'changed_sources': receipt['changed_source_files']}))
