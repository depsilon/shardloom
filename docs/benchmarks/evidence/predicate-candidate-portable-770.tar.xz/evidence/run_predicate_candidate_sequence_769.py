"""Run the frozen finite candidate gates sequentially; never inspect partial timings."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

OUT = Path(__file__).resolve().parent
REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
DRIVER = OUT / 'predicate_candidate_driver_769.py'
GUARD = OUT / 'run_guarded_observed_757.py'
ORACLE = OUT / 'analyze_predicate_candidate_768.py'
LABEL = 'predicate-candidate-769-a2'
BUILD = 'predicate-candidate-build-769-a2'
DATA = OUT / LABEL
BINARY = OUT / f'{LABEL}-test'
PYTHON = sys.executable
FOCUSED = 'local_primitives::prepared_relational::tests::predicate_exclusion_tests::'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def run(name, command):
    output = OUT / f'{name}-sequence-output.log'
    record = {'step': name, 'command': command, 'source_freeze_sha256': sha(OUT/f'{LABEL}-source-freeze.json')}
    print(f'START {name}', flush=True)
    try:
        with output.open('xb') as stream:
            code = subprocess.call(command, cwd=REPO, stdout=stream, stderr=subprocess.STDOUT)
        record['returncode'] = code
        record['output_sha256'] = sha(output)
        if code:
            raise RuntimeError(f'{name} failed with exit {code}; see {output}')
    finally:
        save(OUT/f'{name}-sequence-step.json', record)
    print(f'PASS {name}', flush=True)


def guarded(name, command):
    return [PYTHON, '-B', str(GUARD), '--name', name, '--timeout', '1800', '--', *command]


def main():
    build = json.loads((OUT/f'{BUILD}.json').read_text())
    assert build['status'] == 'passed' and build['returncode'] == 0 and build['process_group_drained']
    assert not DATA.exists() and not BINARY.exists()
    identity = {
        'sequence_sha256': sha(__file__), 'driver_sha256': sha(DRIVER),
        'guard_sha256': sha(GUARD), 'oracle_sha256': sha(ORACLE),
        'source_freeze_sha256': sha(OUT/f'{LABEL}-source-freeze.json'),
        'build_receipt_sha256': sha(OUT/f'{BUILD}.json'),
        'protocol_sha256': sha(OUT/'predicate-exclusion-candidate-protocol-768.json'),
        'label': LABEL, 'build': BUILD,
        'ordered_roles': ['preflight/baseline', 'preflight/candidate', 'A/baseline', 'A/candidate', 'B/candidate', 'B/baseline'],
        'decision_policy': 'Both complete measured cohorts precede every comparative inspection.',
    }
    save(OUT/f'{LABEL}-sequence-identity.json', identity)
    name = 'predicate-candidate-bind-769-a2'
    run(name, guarded(name, [PYTHON, '-B', str(DRIVER), 'bind', '--label', LABEL, '--build', BUILD]))
    name = 'predicate-candidate-lifecycle-769-a2'
    inventory = (OUT/f'{LABEL}-test-inventory.txt').read_text().splitlines()
    assert sum(line.startswith(FOCUSED) and line.endswith(': test') for line in inventory) == 16
    run(name, guarded(name, [str(BINARY), FOCUSED, '--nocapture', '--test-threads=1']))
    assert 'test result: ok. 16 passed; 0 failed; 0 ignored;' in (OUT/f'{name}.log').read_text()
    for role in ['baseline', 'candidate']:
        name = f'predicate-candidate-preflight-{role}-769-a2'
        run(name, [PYTHON, '-B', str(DRIVER), 'run', '--label', LABEL, '--name', name,
                   '--mode', 'preflight', '--role', role, '--cohort', 'preflight', '--data', LABEL])
    name = 'predicate-candidate-preflight-check-769-a2'
    preflight = OUT / f'{LABEL}-preflight-verification.json'
    run(name, guarded(name, [PYTHON, '-B', str(ORACLE), 'preflight', '--data', str(DATA), '--output', str(preflight)]))
    proof = json.loads(preflight.read_text())
    assert sum(s['workflows'] for s in proof['streams'].values()) == 456
    assert sum(s['operations'] for s in proof['streams'].values()) == 1064
    for cohort, roles in [('A', ['baseline', 'candidate']), ('B', ['candidate', 'baseline'])]:
        for role in roles:
            name = f'predicate-candidate-measure-{cohort}-{role}-769-a2'
            run(name, [PYTHON, '-B', str(DRIVER), 'run', '--label', LABEL, '--name', name,
                       '--mode', 'measure', '--role', role, '--cohort', cohort, '--data', LABEL])
    name = 'predicate-candidate-decision-769-a2'
    decision = OUT / f'{LABEL}-decision.json'
    run(name, guarded(name, [PYTHON, '-B', str(ORACLE), 'decision', '--data', str(DATA), '--output', str(decision)]))
    name = 'predicate-candidate-final-binding-769-a2'
    run(name, [PYTHON, '-B', str(DRIVER), 'verify', '--label', LABEL])
    for key, path in [('sequence_sha256', __file__), ('driver_sha256', DRIVER), ('guard_sha256', GUARD), ('oracle_sha256', ORACLE)]:
        assert sha(path) == identity[key]
    save(OUT/f'{LABEL}-sequence-completion.json', {'status': 'completed', 'identity_sha256': sha(OUT/f'{LABEL}-sequence-identity.json'),
          'decision_sha256': sha(decision), 'production_accepted': False})
    print('COMPLETE finite candidate sequence; full acceptance remains separate.', flush=True)


if __name__ == '__main__':
    main()
