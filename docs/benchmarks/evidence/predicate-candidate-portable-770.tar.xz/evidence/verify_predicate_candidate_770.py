"""Independently bind the completed candidate and recompute every finite gate."""
from pathlib import Path
import hashlib
import json
import statistics
import subprocess

E = Path(__file__).resolve().parent
W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
LABEL = 'predicate-candidate-769-a2'
DATA = E / LABEL


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def receipt(name):
    path = E / f'{name}.json'
    value = read(path)
    assert value['status'] == 'passed' and value['returncode'] == 0
    assert value['process_group_drained'] and value['direct_child_reaped']
    assert not value['timed_out'] and value['interrupted_signal'] is None
    assert value['log_sha256'] == sha(path.with_suffix('.log'))
    return identity(path)


def main():
    completion = read(E / f'{LABEL}-sequence-completion.json')
    sequence_path = E / f'{LABEL}-sequence-identity.json'
    decision_path = E / f'{LABEL}-decision.json'
    assert completion['status'] == 'completed' and not completion['production_accepted']
    assert completion['identity_sha256'] == sha(sequence_path)
    assert completion['decision_sha256'] == sha(decision_path)
    sequence = read(sequence_path)
    assert sequence['ordered_roles'] == ['preflight/baseline', 'preflight/candidate', 'A/baseline', 'A/candidate', 'B/candidate', 'B/baseline']
    for key, name in [('sequence_sha256', 'run_predicate_candidate_sequence_769.py'),
                      ('driver_sha256', 'predicate_candidate_driver_769.py'),
                      ('guard_sha256', 'run_guarded_observed_757.py'),
                      ('oracle_sha256', 'analyze_predicate_candidate_768.py'),
                      ('protocol_sha256', 'predicate-exclusion-candidate-protocol-768.json'),
                      ('source_freeze_sha256', f'{LABEL}-source-freeze.json'),
                      ('build_receipt_sha256', 'predicate-candidate-build-769-a2.json')]:
        assert sequence[key] == sha(E / name), key
    source_path = E / f'{LABEL}-source-freeze.json'
    source = read(source_path)
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
    assert source['head'] == head == '896c71793a8859a6b4770bbc8a9fe0b85d755cf8'
    current_names = subprocess.check_output(['git', 'ls-files', '-co', '--exclude-standard', '-z'], cwd=W, text=True).split('\0')
    current_names = sorted({p for p in current_names if p.endswith('.rs') or Path(p).name in ('Cargo.toml', 'Cargo.toml.orig', 'Cargo.lock')})
    assert current_names == [r['path'] for r in source['sources']]
    assert len(current_names) == 1904
    for item in source['sources']:
        path = W / item['path']
        assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256'], item['path']
    for item in source['helpers']:
        assert sha(item['path']) == item['sha256']
    assert sha(E / f'{LABEL}-tracked.patch') == source['patch_sha256']
    assert hashlib.sha256(subprocess.check_output(['git', 'diff', '--binary'], cwd=W)).hexdigest() == source['patch_sha256']
    for relative in source['extra_sources']:
        assert sha(E / f'{LABEL}-extra-sources' / relative) == sha(W / relative)
    artifact_path = E / f'{LABEL}-artifact.json'
    artifact = read(artifact_path)
    assert artifact['source_freeze_sha256'] == sha(source_path)
    assert artifact['artifact_sha256'] == sha(artifact['artifact'])
    assert artifact['bytes'] == Path(artifact['artifact']).stat().st_size
    assert artifact['build_receipt_sha256'] == sequence['build_receipt_sha256']
    assert artifact['compiler_artifact']['fresh'] is False
    receipts = [receipt('predicate-candidate-build-769-a2'), receipt('predicate-candidate-bind-769-a2'),
                receipt('predicate-candidate-lifecycle-769-a2'), receipt('predicate-candidate-preflight-check-769-a2'),
                receipt('predicate-candidate-decision-769-a2')]
    assert 'test result: ok. 16 passed; 0 failed; 0 ignored;' in (E / 'predicate-candidate-lifecycle-769-a2.log').read_text()
    decision = read(decision_path)
    assert decision['scope_result'] == 'candidate_comparison_rejected' and not decision['production_accepted']
    assert decision['protocol_sha256'] == sequence['protocol_sha256']
    assert decision['validator_sha256'] == sequence['oracle_sha256']
    streams = {}
    workflows = operations = 0
    for mode, cohort, role in [('preflight', 'preflight', r) for r in ('baseline', 'candidate')] + [('measure', c, r) for c in ('A', 'B') for r in ('baseline', 'candidate')]:
        name = f'predicate-candidate-{mode}-{role}-769-a2' if mode == 'preflight' else f'predicate-candidate-measure-{cohort}-{role}-769-a2'
        receipts.append(receipt(name))
        link = read(E / f'{name}-link.json')
        assert link['sources_and_artifact_unchanged'] and link['returncode'] == 0
        assert link['artifact_sha256'] == artifact['artifact_sha256']
        assert link['source_freeze_sha256'] == sha(source_path)
        path = DATA / f'{mode}-{cohort}-{role}.jsonl'
        assert link['output_sha256'] == sha(path)
        key = f'preflight-{role}' if mode == 'preflight' else f'{cohort}-{role}'
        summary = decision['streams'][key]
        assert summary['sha256'] == sha(path) and summary['bytes'] == path.stat().st_size
        rows = [json.loads(line) for line in path.read_text().splitlines()]
        assert len(rows) == summary['workflows']
        assert sum(len(r['operations']) for r in rows) == summary['operations']
        workflows += len(rows)
        operations += summary['operations']
        if mode == 'measure':
            assert sum(r['warmup'] for r in rows) == 1
            streams[cohort, role] = [r for r in rows if not r['warmup']]
    assert workflows == 1828 and operations == 4260
    expected_cells = {(n, f, s, k) for n in (8192, 65536) for f in ('correlated', 'membership', 'contains') for s in ('no_true', 'positive', 'all_null', 'changed_parameters', 'replaced_source', 'interleaved_parameters') for k in (1, 2, 4)}
    expected_cells |= {(n, 'unfiltered', 'unfiltered', k) for n in (8192, 65536) for k in (1, 2, 4)}
    assert len(expected_cells) == len(decision['cells']) == 114
    by_id = {r['cell_id']: r for r in decision['cells']}
    failures, targets = [], []
    peak_overhead = 0
    for n, family, scenario, calls in sorted(expected_cells):
        cid = f'{n}-{family}-{scenario}-{calls}'
        for cohort in ('A', 'B'):
            medians = {}
            for role in ('baseline', 'candidate'):
                rows = [r for r in streams[cohort, role] if r['cell_id'] == cid]
                assert len(rows) == 3 and {r['sample'] for r in rows} == {0, 1, 2}
                medians[role] = [statistics.median(sum(o['engine_execution_ns'] for o in r['operations']) for r in rows),
                                 statistics.median(r['complete_workflow_ns'] for r in rows),
                                 statistics.median(r['peak_reserved_bytes'] for r in rows)]
            be, bc, bp = medians['baseline']
            ce, cc, cp = medians['candidate']
            engine_bad = 100 * (ce - be) > 5 * be and ce - be > 250000
            complete_bad = 100 * (cc - bc) > 5 * bc and cc - bc > 250000
            peak_bad = cp - bp > 65536
            control_pass = not (engine_bad or complete_bad or peak_bad)
            target_pass = control_pass and be - ce >= 2000000 and 100 * (be - ce) >= 20 * be and bc - cc >= 2000000 and 100 * (bc - cc) >= 15 * bc
            reported = by_id[cid]['cohorts'][cohort]
            assert [be, bc, bp, ce, cc, cp] == [reported[f'median_{role}_{clock}'] for role in ('baseline', 'candidate') for clock in ('engine_ns', 'complete_ns', 'peak_reserved_bytes')]
            assert control_pass == reported['control_pass'] and target_pass == reported['target_qualifies']
            peak_overhead = max(peak_overhead, cp - bp)
            if not control_pass:
                failures.append(dict(cell_id=cid, cohort=cohort, engine_failed=engine_bad, complete_failed=complete_bad, memory_failed=peak_bad, baseline_engine_ns=be, candidate_engine_ns=ce, baseline_complete_ns=bc, candidate_complete_ns=cc))
            if n == 65536 and scenario == 'no_true' and calls == 4:
                assert target_pass
                targets.append(dict(cell_id=cid, cohort=cohort, baseline_engine_ns=be, candidate_engine_ns=ce, engine_reduction_percent=100 * (be - ce) / be))
    assert {(r['cell_id'], r['cohort']) for r in failures} == {('65536-membership-no_true-1', 'B'), ('65536-membership-interleaved_parameters-1', 'A')}
    assert len(targets) == 6 and not decision['controls_pass'] and decision['all_targets_pass']
    output = E / 'predicate-candidate-verification-770.json'
    with output.open('x') as stream:
        json.dump(dict(status='passed', scope_result='candidate_comparison_rejected', production_accepted=False,
                       source=identity(source_path), artifact=identity(artifact_path), decision=identity(decision_path),
                       protocol=identity(E / 'predicate-exclusion-candidate-protocol-768.json'), verifier=identity(__file__),
                       source_inputs=1904, workflows=workflows, operations=operations, cells=114,
                       all_gates_independently_recomputed=True, full_semantic_verification=receipts[4],
                       successful_guarded_receipts=receipts, target_results=targets, failing_controls=failures,
                       maximum_median_peak_overhead_bytes=peak_overhead,
                       semantic_scope='The frozen full-result oracle checked every workflow; this independent pass rebinds all sources/artifacts/streams and separately recomputes every comparison gate.'), stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status='passed', scope_result='candidate_comparison_rejected', workflows=workflows, operations=operations, target_cohorts=6, failing_control_cohorts=2, verification=str(output))))


if __name__ == '__main__':
    main()
