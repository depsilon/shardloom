"""Serial final checks and complete public acceptance for streaming composition."""
import json
from pathlib import Path
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sha, sources, save


def run(command):
    subprocess.run([str(value) for value in command], cwd=ROOT, check=True)


def guarded(name, timeout, command):
    run([sys.executable, '-B', OUT / 'run_guarded.py', '--name', name,
         '--timeout', timeout, '--', *command])


def main():
    guarded('native-stream-composition-fmt-398', 180,
            ['cargo', 'fmt', '--all', '--', '--check'])
    for name, features in [('release', 'release-user-surfaces'),
                           ('read', 'vortex-local-primitives')]:
        guarded(f'native-stream-composition-{name}-clippy-398', 1200,
                ['cargo', 'clippy', '--offline', '--locked', '-p', 'shardloom-vortex',
                 '-p', 'shardloom-cli', '--all-targets', '--features', features,
                 '--', '-D', 'warnings'])
    guarded('native-stream-composition-workspace-clippy-398', 1200,
            ['cargo', 'clippy', '--workspace', '--all-targets', '--', '-D', 'warnings'])
    guarded('native-stream-composition-workspace-tests-398', 1800,
            ['cargo', 'test', '--workspace', '--all-targets', '--', '--test-threads=2'])
    run([sys.executable, '-B', OUT / 'freeze_query_cli_368.py', 'prepare',
         '--name', 'stream-composition-398'])
    guarded('native-stream-composition-release-build-398', 2100,
            ['cargo', 'build', '--offline', '--locked', '--release', '-p', 'shardloom-cli',
             '--bin', 'shardloom', '--features', 'release-user-surfaces', '--message-format=json'])
    run([sys.executable, '-B', OUT / 'freeze_query_cli_368.py', 'freeze',
         '--name', 'stream-composition-398', '--build-receipt',
         OUT / 'native-stream-composition-release-build-398.json'])
    manifest_path = OUT / 'stream-composition-398-release.json'
    manifest = json.loads(manifest_path.read_text())
    public_root = OUT / 'stream-composition-public-398'
    guarded('native-stream-composition-public-398', 5400,
            [sys.executable, '-B', ROOT / 'scripts/run_native_streaming_input_uat.py',
             '--binary', manifest['cli']['path'], '--uat-root', public_root,
             '--operation-timeout', '600'])
    summary = json.loads((public_root / 'summary.json').read_text())
    assert summary['status'] == 'passed'
    assert len(summary['families']) == 19 and len(set(summary['families'])) == 19
    assert all(case['status'] == 'passed' for case in summary['cases'])
    assert sources() == manifest['source_sha256']
    assert sha(manifest['cli']['path']) == manifest['cli']['sha256']
    run([sys.executable, '-B', OUT / 'run_stream_composition_full43_397.py',
         '--max-log-mib', '1024', '--max-run-log-mib', '256'])
    guarded('native-stream-composition-native-tests-398', 3600,
            ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-vortex',
             '-p', 'shardloom-cli', '--all-targets', '--features',
             'vortex-local-primitives,vortex-write,universal-format-io',
             '--', '--test-threads=2'])
    assert sources() == manifest['source_sha256']
    result = dict(status='passed', manifest=str(manifest_path),
                  manifest_sha256=sha(manifest_path), public_summary=str(public_root / 'summary.json'),
                  public_summary_sha256=sha(public_root / 'summary.json'),
                  public_families=summary['families'], public_cases=len(summary['cases']),
                  source_identity_preserved=True, no_release_or_publication=True)
    save(OUT / 'stream-composition-final-checks-398.json', result)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
