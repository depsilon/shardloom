"""Rebuild current-capability review dates after the complete rendered checks."""
import run_stream_composition_docs_399 as docs

docs.DEST = docs.OUT / 'stream-composition-docs-402'

if __name__ == '__main__':
    docs.main()
