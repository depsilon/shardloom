"""Retry documentation gates after adding the missing v1 scope matrix row."""
import run_stream_composition_docs_399 as docs

docs.DEST = docs.OUT / 'stream-composition-docs-400'

if __name__ == '__main__':
    docs.main()
