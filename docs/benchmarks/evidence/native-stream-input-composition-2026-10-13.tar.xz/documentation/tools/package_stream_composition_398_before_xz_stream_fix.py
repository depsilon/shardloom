"""Package the final stream-composition acceptance evidence without bulk data."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import tarfile
from dataclasses import dataclass, field

O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
REPO = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
UAT_ROOT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
BASE_HEAD = 'ed253d1ec74b724215f71f0b410123656e596696'
CATALOG_PATH = O / 'stream-composition-evidence-catalog-397.json'
FINAL_CHECKS_PATH = O / 'stream-composition-final-checks-398.json'
RELEASE_PATH = O / 'stream-composition-398-release.json'
SOURCE_INDEX_PATH = O / 'stream-composition-398-source.json'
REVIEW_PATH = O / 'stream-composition-full43-primary-review-398.json'
PUBLIC_ROOT = O / 'stream-composition-public-398'
PACKAGE_HELPER = Path(__file__).resolve()
ARCHIVE_PATH = O / 'stream-composition-398-evidence.tar.xz'
MANIFEST_PATH = O / 'stream-composition-398-evidence.manifest.json'
ARCHIVE_PARTIAL = O / '.stream-composition-398-evidence.tar.xz.partial'
MANIFEST_PARTIAL = O / '.stream-composition-398-evidence.manifest.json.partial'
SUPERVISOR_PATH = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
SUPERVISOR_SHA256 = '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97'
GIB = 1024 ** 3
MIB = 1024 ** 2
CHUNK = 4 * MIB
MAX_LOG_BYTES = 1024 * MIB

sys.path.insert(0, str(REPO / 'scripts'))
from local_uat_storage import check_budgets, require_local_path  # noqa: E402


class NeedsReasoning(ValueError):
    """The evidence schema or membership cannot be selected without guessing."""


def need(condition: bool, message: str) -> None:
    if not condition:
        raise NeedsReasoning(message)


def sha256_file(path: Path) -> tuple[int, str]:
    digest = hashlib.sha256()
    count = 0
    with path.open('rb') as stream:
        while True:
            chunk = stream.read(CHUNK)
            if not chunk:
                break
            digest.update(chunk)
            count += len(chunk)
    return count, digest.hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text())


def require_regular(path: Path) -> Path:
    resolved = require_local_path(path, Path.home(), sys.platform)
    info = path.lstat()
    if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
        raise NeedsReasoning(f'expected a regular non-symlink evidence file: {path}')
    return resolved


def verify_file(path: Path, expected_sha: str | None = None,
                expected_bytes: int | None = None) -> tuple[int, str]:
    require_regular(path)
    before = path.stat()
    count, digest = sha256_file(path)
    after = path.stat()
    before_id = (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
    after_id = (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    if before_id != after_id or count != after.st_size:
        raise NeedsReasoning(f'evidence changed while hashing: {path}')
    if expected_sha is not None and digest != expected_sha:
        raise NeedsReasoning(f'SHA-256 mismatch for {path}: expected {expected_sha}, got {digest}')
    if expected_bytes is not None and count != expected_bytes:
        raise NeedsReasoning(f'byte-count mismatch for {path}: expected {expected_bytes}, got {count}')
    return count, digest


@dataclass
class Member:
    path: Path
    name: str
    logical_root: str
    relative_path: str
    size: int
    digest: str
    roles: list[str] = field(default_factory=list)


class MemberSet:
    def __init__(self) -> None:
        self.by_path: dict[Path, Member] = {}
        self.by_name: dict[str, Path] = {}

    def add(self, path: Path, name: str, root_key: str, root: Path,
            role: str, expected_sha: str | None = None,
            expected_bytes: int | None = None) -> Member:
        resolved = require_regular(path)
        member_path = PurePosixPath(name)
        if member_path.is_absolute() or '..' in member_path.parts or not member_path.parts:
            raise NeedsReasoning(f'unsafe relative archive name: {name}')
        name = member_path.as_posix()
        existing = self.by_path.get(resolved)
        if existing is not None:
            if expected_sha is not None and existing.digest != expected_sha:
                raise NeedsReasoning(f'conflicting expected hash for duplicate path: {path}')
            if expected_bytes is not None and existing.size != expected_bytes:
                raise NeedsReasoning(f'conflicting expected size for duplicate path: {path}')
            existing.roles.append(role)
            return existing
        other = self.by_name.get(name)
        if other is not None:
            raise NeedsReasoning(f'archive member name collision: {name}')
        count, digest = verify_file(path, expected_sha, expected_bytes)
        try:
            relative = resolved.relative_to(root.resolve()).as_posix()
        except ValueError:
            relative = path.name
        item = Member(resolved, name, root_key, relative, count, digest, [role])
        self.by_path[resolved] = item
        self.by_name[name] = resolved
        return item

    def add_tree(self, root_key: str, root: Path, prefix: str, role: str,
                 excluded_suffixes: tuple[str, ...] = ('.vortex', '.parquet')) -> list[str]:
        if root.is_symlink():
            raise NeedsReasoning(f'evidence root is a symlink: {root}')
        root = require_local_path(root, Path.home(), sys.platform)
        if not root.is_dir():
            raise NeedsReasoning(f'evidence root is not a directory: {root}')
        skipped: list[str] = []
        pending = [root]
        while pending:
            directory = pending.pop()
            with os.scandir(directory) as scan:
                entries = sorted(scan, key=lambda entry: entry.name, reverse=True)
            for entry in entries:
                path = Path(entry.path)
                if entry.is_symlink():
                    raise NeedsReasoning(f'symlink in selected evidence tree: {path}')
                if entry.is_dir(follow_symlinks=False):
                    if entry.name == 'outputs':
                        skipped.append(str(path))
                    else:
                        pending.append(path)
                    continue
                if entry.is_file(follow_symlinks=False):
                    if path.suffix.lower() in excluded_suffixes:
                        skipped.append(str(path))
                        continue
                    relative = path.relative_to(root).as_posix()
                    self.add(path, f'{prefix}/{relative}', root_key, root, role)
                    continue
                raise NeedsReasoning(f'unsupported filesystem entry in evidence tree: {path}')
        return skipped

    def ordered(self) -> list[Member]:
        return sorted(self.by_path.values(), key=lambda item: item.name)


class HashingReader:
    def __init__(self, stream):
        self.stream = stream
        self.digest = hashlib.sha256()
        self.count = 0

    def read(self, size: int = -1) -> bytes:
        data = self.stream.read(size)
        self.digest.update(data)
        self.count += len(data)
        return data


def bound_entry(entry: dict, label: str) -> tuple[Path, str, int]:
    need(isinstance(entry, dict) and {'path', 'sha256', 'bytes'} <= entry.keys(),
         f'{label} must provide path, sha256 and bytes')
    path = Path(entry['path'])
    need(path.is_absolute(), f'{label} path must be absolute')
    return path, entry['sha256'], entry['bytes']


def add_bound(members: MemberSet, entry: dict, name: str, root_key: str,
              root: Path, role: str, label: str) -> tuple[Path, str, int]:
    path, digest, count = bound_entry(entry, label)
    members.add(path, name, root_key, root, role, digest, count)
    return path, digest, count


def check_receipt(receipt_path: Path, members: MemberSet | None = None,
                  prefix: str = 'receipts') -> dict:
    receipt = read_json(receipt_path)
    need(receipt.get('status') in {'passed', 'failed'},
         f'unrecognized receipt status: {receipt_path}')
    need(receipt.get('process_group_drained') is True and receipt.get('direct_child_reaped') is True,
         f'receipt lacks affirmative drained/reaped evidence: {receipt_path}')
    need(isinstance(receipt.get('log_sha256'), str) and
         re.fullmatch(r'[0-9a-f]{64}', receipt['log_sha256']) is not None,
         f'receipt has no valid recorded log hash: {receipt_path}')
    log_path = receipt_path.with_suffix('.log')
    verify_file(log_path, receipt.get('log_sha256'))
    if members is not None:
        members.add(receipt_path, f'{prefix}/{receipt_path.name}', 'evidence_root', O,
                    'native-stream guard receipt')
        members.add(log_path, f'{prefix}/{log_path.name}', 'evidence_root', O,
                    'receipt log matching recorded SHA-256', receipt['log_sha256'])
    return receipt


def verify_current_source_and_binary(release: dict, source_index: dict,
                                     source_index_path: Path) -> dict:
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    need(head == BASE_HEAD and head == release.get('head'),
         f'current HEAD, final release head, and required base must agree (HEAD={head!r})')
    source_map = release.get('source_sha256')
    need(isinstance(source_map, dict) and source_map,
         'final release source_sha256 must be a nonempty path-to-hash map')
    need(source_index.get('head') == head and source_index.get('source_sha256') == source_map,
         'current source-index manifest does not match the final release source map')
    need(release.get('source_manifest', {}).get('path') == str(source_index_path),
         'final release does not reference the selected current source-index manifest')
    verify_file(source_index_path, release['source_manifest']['sha256'])
    for relative, expected in source_map.items():
        rel = PurePosixPath(relative)
        need(not rel.is_absolute() and '..' not in rel.parts,
             f'unsafe source path in final manifest: {relative}')
        path = REPO.joinpath(*rel.parts)
        verify_file(path, expected)
    cli = release.get('cli', {})
    binary = Path(cli.get('path', ''))
    need(binary.is_absolute() and cli.get('bytes', 0) > 0 and cli.get('sha256'),
         'final release manifest has incomplete frozen executable identity')
    verify_file(binary, cli['sha256'], cli['bytes'])
    return dict(head=head, source_count=len(source_map), source_sha256=source_map,
                binary_path=str(binary), binary_bytes=cli['bytes'], binary_sha256=cli['sha256'])


def check_budget(reserve: int, output: Path) -> None:
    for root, log_root in ((O, O / 'logs'), (UAT_ROOT, UAT_ROOT / 'logs')):
        require_local_path(root, Path.home(), sys.platform)
        check_budgets(root, output, log_root, min_free_bytes=12 * GIB,
                      reserve_bytes=reserve, max_workspace_bytes=100 * GIB,
                      max_log_bytes=MAX_LOG_BYTES)


def main() -> None:
    for output in (ARCHIVE_PATH, MANIFEST_PATH, ARCHIVE_PARTIAL, MANIFEST_PARTIAL):
        if output.exists() or output.is_symlink():
            raise FileExistsError(f'refusing to replace an existing package output: {output}')

    for required in (CATALOG_PATH, FINAL_CHECKS_PATH, RELEASE_PATH,
                     SOURCE_INDEX_PATH, REVIEW_PATH):
        if not required.is_file():
            raise NeedsReasoning(f'final evidence is incomplete; missing {required}')
        verify_file(required)

    catalog = read_json(CATALOG_PATH)
    checks = read_json(FINAL_CHECKS_PATH)
    release = read_json(RELEASE_PATH)
    source_index = read_json(SOURCE_INDEX_PATH)
    review = read_json(REVIEW_PATH)
    need(catalog.get('schema') == 'shardloom.stream-composition-evidence-catalog.v1',
         'evidence catalog schema is not the expected 397 catalog')
    need(checks.get('status') == 'passed', 'final-checks gate is not passed')
    need(release.get('status') == 'passed' and release.get('build_profile') == 'release',
         'final 398 release manifest is not a passed release build')
    need(review.get('status') == 'passed' and review.get('calls') == 129 and
         review.get('complete_rows') == 1143 and
         review.get('all_values_and_schemas_reopened') is True and
         review.get('resources_and_no_fallback') is True and
         review.get('original_input_and_sources_unchanged') is True and
         review.get('publication_attempted') is False,
         'final Full43 primary review is incomplete or failed acceptance gates')

    source_identity = verify_current_source_and_binary(release, source_index, SOURCE_INDEX_PATH)
    members = MemberSet()
    members.add(CATALOG_PATH, f'catalog/{CATALOG_PATH.name}', 'evidence_root', O,
                'complete evidence catalog')
    members.add(FINAL_CHECKS_PATH, f'final/{FINAL_CHECKS_PATH.name}', 'evidence_root', O,
                'passed final acceptance checks')
    members.add(RELEASE_PATH, f'final/{RELEASE_PATH.name}', 'evidence_root', O,
                'passed final release manifest')
    members.add(SOURCE_INDEX_PATH, f'final/{SOURCE_INDEX_PATH.name}', 'evidence_root', O,
                'current source-index manifest matching final release')
    members.add(REVIEW_PATH, f'final/{REVIEW_PATH.name}', 'evidence_root', O,
                'passed Full43 primary review')
    public_review_path = O / 'stream-composition-public-review-399.json'
    public_review = read_json(public_review_path)
    need(public_review.get('coverage', {}).get('observed_case_count') == 757 and
         public_review.get('coverage', {}).get('summary_sha256') ==
         sha256_file(PUBLIC_ROOT / 'summary.json')[1] and
         public_review.get('frozen_executable_identity', {}).get('release_manifest_sha256') ==
         sha256_file(RELEASE_PATH)[1],
         'independent public inventory does not bind the final evidence')
    members.add(public_review_path, f'final/{public_review_path.name}', 'evidence_root', O,
                'independent bounded public inventory; limitations retained')

    # Keep every numbered native-stream receipt, including failed attempts and retries.
    attempt_pattern = re.compile(r'^native-stream.*-(39[0-8])(?:-\d+)?\.json$')
    receipts = sorted(path for path in O.glob('native-stream*.json')
                      if attempt_pattern.fullmatch(path.name))
    need(bool(receipts), 'no native-stream receipts for attempts 390 through 398 were selected')
    receipt_stems = {path.stem for path in receipts}
    for receipt_path in receipts:
        check_receipt(receipt_path, members)
    for name in ('fmt', 'release-clippy', 'read-clippy', 'workspace-clippy',
                 'workspace-tests', 'release-build', 'public', 'native-tests'):
        required_receipt = O / f'native-stream-composition-{name}-398.json'
        record = check_receipt(required_receipt)
        need(record.get('status') == 'passed' and record.get('returncode') == 0,
             f'final required check did not pass: {required_receipt}')
    for log_path in sorted(O.glob('native-stream*.log')):
        sibling_receipt = log_path.with_suffix('.json')
        if attempt_pattern.fullmatch(sibling_receipt.name) and log_path.stem not in receipt_stems:
            members.add(log_path, f'native-stream-logs/{log_path.name}', 'evidence_root', O,
                        'numbered native-stream log without a same-stem receipt')

    freeze_manifests = catalog.get('freeze_manifests')
    need(isinstance(freeze_manifests, list) and len(freeze_manifests) == 6,
         'catalog must identify exactly six historical freeze manifests')
    excluded_assets = []
    for index, record in enumerate(freeze_manifests):
        need({'path', 'manifest_sha256'} <= record.keys(),
             f'freeze manifest entry {index} lacks path/hash')
        rel = PurePosixPath(record['path'])
        need(not rel.is_absolute() and '..' not in rel.parts,
             f'unsafe catalog manifest path: {record["path"]}')
        path = O.joinpath(*rel.parts)
        members.add(path, f'historical-freezes/{rel.as_posix()}', 'evidence_root', O,
                    'catalog-listed historical freeze manifest', record['manifest_sha256'])
        if record.get('binary') and record.get('binary_sha256'):
            historical_manifest = read_json(path)
            historical_cli = historical_manifest.get('cli', {})
            excluded_assets.append(dict(kind='historical frozen executable',
                path=record['binary'], byte_count=historical_cli.get('bytes'),
                sha256=record['binary_sha256'],
                reason='executable excluded by package scope'))

    public_summaries = catalog.get('public_uat_summaries')
    need(isinstance(public_summaries, dict) and len(public_summaries) == 9,
         'catalog must identify exactly nine public UAT summaries')
    skipped_public_outputs = []
    for label, record in sorted(public_summaries.items()):
        summary_rel = PurePosixPath(record['summary'])
        need(not summary_rel.is_absolute() and '..' not in summary_rel.parts and
             summary_rel.parent.name == label,
             f'ambiguous catalog summary root for {label}: {record.get("summary")}')
        root = O.joinpath(*summary_rel.parent.parts)
        summary_path = root / summary_rel.name
        members.add(summary_path, f'catalog-public/{label}/summary.json',
                    f'catalog_public_{label}', root, 'catalog-linked public UAT summary')
        public_summary = read_json(summary_path)
        cases = public_summary.get('cases')
        need(isinstance(cases, list), f'catalog public cases are not a list for {label}')
        observed = dict(status=public_summary.get('status'), cases=len(cases),
                        passed=sum(case.get('status') == 'passed' for case in cases),
                        failed=sum(case.get('status') == 'failed' for case in cases))
        for key in ('status', 'cases', 'passed', 'failed'):
            need(observed[key] == record.get(key),
                 f'catalog summary metadata mismatch for {label}.{key}')
        log_root = root / 'logs'
        skipped_public_outputs.extend(members.add_tree(
            f'catalog_public_{label}_logs', log_root, f'catalog-public/{label}/logs',
            'complete catalog UAT log directory'))
        output_root = root / 'outputs'
        skipped_public_outputs.append(str(output_root))

    final_public_summary = PUBLIC_ROOT / 'summary.json'
    members.add(final_public_summary, 'final-public/summary.json', 'final_public', PUBLIC_ROOT,
                'final stream-composition public UAT summary')
    public = read_json(final_public_summary)
    need(public.get('status') == 'passed' and len(public.get('families', [])) == 19 and
         len(set(public.get('families', []))) == 19 and len(public.get('cases', [])) == 757 and
         all(case.get('status') == 'passed' for case in public.get('cases', [])),
         'final stream-composition public UAT summary does not prove 19 families and 757 passes')
    skipped_public_outputs.extend(members.add_tree(
        'final_public_logs', PUBLIC_ROOT / 'logs', 'final-public/logs',
        'complete final public UAT log directory'))
    skipped_public_outputs.append(str(PUBLIC_ROOT / 'outputs'))

    # Bind the final Full43 review to its exact admission, guard, and whole summary directory.
    summary_entry = review.get('summary')
    admission_entry = review.get('admission')
    receipt_entry = review.get('receipt')
    summary_path, summary_sha, summary_bytes = bound_entry(summary_entry, 'Full43 summary')
    admission_path, admission_sha, admission_bytes = bound_entry(admission_entry, 'Full43 admission')
    receipt_path, receipt_sha, receipt_bytes = bound_entry(receipt_entry, 'Full43 guard receipt')
    members.add(admission_path, f'full43/{admission_path.name}', 'full43_artifacts', admission_path.parent,
                'Full43 frozen admission', admission_sha, admission_bytes)
    receipt = check_receipt(receipt_path)
    verify_file(receipt_path, receipt_sha, receipt_bytes)
    need(receipt.get('status') == 'passed' and receipt.get('returncode') == 0 and
         receipt.get('head') == BASE_HEAD,
         'Full43 guard receipt does not prove a successful run on the required base HEAD')
    guard_log = receipt_path.with_suffix('.log')
    members.add(receipt_path, f'full43/{receipt_path.name}', 'full43_artifacts', receipt_path.parent,
                'Full43 outer guard receipt', receipt_sha, receipt_bytes)
    members.add(guard_log, f'full43/{guard_log.name}', 'full43_artifacts', receipt_path.parent,
                'Full43 guard log', receipt['log_sha256'])
    need(summary_path.is_absolute(), 'Full43 summary path must be absolute')
    verify_file(summary_path, summary_sha, summary_bytes)
    summary_parent = summary_path.parent
    skipped_summary_data = members.add_tree(
        'full43_summary_parent', summary_parent, 'full43-summary',
        'complete Full43 summary-parent directory and call logs')
    need(summary_path.resolve() in members.by_path,
         'the Full43 summary is missing from its selected summary-parent directory')

    admission = read_json(admission_path)
    need(admission.get('status') == 'passed' and admission.get('performance_claim_allowed') is False,
         'Full43 admission is not passed or permits unsupported performance claims')
    manifest_bound = admission.get('manifest')
    need(isinstance(manifest_bound, dict) and
         manifest_bound.get('path') == str(RELEASE_PATH) and
         manifest_bound.get('sha256') == sha256_file(RELEASE_PATH)[1] and
         manifest_bound.get('bytes') == RELEASE_PATH.stat().st_size,
         'Full43 admission does not bind the selected final release manifest')
    review_manifest = review.get('manifest')
    need(isinstance(review_manifest, dict) and
         review_manifest.get('path') == str(RELEASE_PATH) and
         review_manifest.get('sha256') == manifest_bound['sha256'] and
         review_manifest.get('bytes') == manifest_bound['bytes'],
         'Full43 review does not bind the selected final release manifest')
    full_summary = read_json(summary_path)
    need(full_summary.get('build_commit') == release.get('head') and
         full_summary.get('binary_sha256') == release.get('cli', {}).get('sha256') and
         full_summary.get('source') == admission.get('source') and
         full_summary.get('complete') is True and
         full_summary.get('full_result_validation') is True and
         full_summary.get('completed_identity_check') is True and
         full_summary.get('reference_packet_identity_verified') is True and
         full_summary.get('harness_identity_verified') is True and
         full_summary.get('reference_kind') == 'retained_native_regression' and
         full_summary.get('selected_query_ids') == list(range(1, 44)) and
         len(full_summary.get('records', [])) == 129 and
         all(item.get('passed') is True and item.get('validation') == 'complete_values' and
             item.get('returncode') == 0 and not item.get('guard_failures')
             for item in full_summary.get('records', [])),
         'Full43 summary contents do not match the passed review, source, and executable identity')
    need({(item['query'], item['run']) for item in full_summary['records']} ==
         {(query, run) for query in range(1, 44) for run in range(1, 4)},
         'Full43 summary does not cover the full query/run matrix')
    conditional_inputs = []
    for kind, entries in (('reference', [admission.get('reference')]),
                          ('queries', [admission.get('queries')]),
                          ('harness', admission.get('harness'))):
        need(isinstance(entries, list) and all(isinstance(item, dict) for item in entries),
             f'Full43 admission has ambiguous {kind} identity records')
        for index, entry in enumerate(entries):
            try:
                path, digest, count = bound_entry(entry, f'Full43 {kind}[{index}]')
            except NeedsReasoning:
                raise
            actual = verify_file(path)
            if actual == (count, digest):
                members.add(path, f'full43-inputs/{kind}/{index:03d}-{path.name}',
                            f'full43_{kind}', path.parent,
                            f'Full43 {kind} input matching recorded identity', digest, count)
                conditional_inputs.append(dict(kind=kind, path=str(path), included=True,
                                               bytes=count, sha256=digest))
            else:
                conditional_inputs.append(dict(kind=kind, path=str(path), included=False,
                    expected_bytes=count, expected_sha256=digest,
                    observed_bytes=actual[0], observed_sha256=actual[1],
                    reason='recorded identity did not match current bytes'))

    # Include final release provenance, its freeze tools, and the exact guard supervisor.
    source_manifest_path = Path(release.get('source_manifest', {}).get('path', ''))
    source_manifest_sha = release.get('source_manifest', {}).get('sha256')
    need(source_manifest_sha, 'final release lacks its source-manifest SHA-256')
    members.add(source_manifest_path, f'final/{source_manifest_path.name}', 'evidence_root', O,
                'final release source manifest', source_manifest_sha)
    cli = release['cli']
    build_receipt_path = Path(cli['build_receipt'])
    build_receipt = check_receipt(build_receipt_path)
    verify_file(build_receipt_path, cli['build_receipt_sha256'])
    need(build_receipt.get('status') == 'passed' and build_receipt.get('returncode') == 0 and
         build_receipt.get('head') == release.get('head'),
         'final release build receipt does not prove successful build at the released HEAD')
    members.add(build_receipt_path, f'final/{build_receipt_path.name}', 'evidence_root', O,
                'final release build receipt', cli['build_receipt_sha256'])
    build_log_path = Path(cli['build_log'])
    members.add(build_log_path, f'final/{build_log_path.name}', 'evidence_root', O,
                'final release build log', build_receipt['log_sha256'])
    freeze_helper = release.get('freeze_helper', {})
    need(freeze_helper.get('path') and freeze_helper.get('sha256'),
         'final release has no pinned freeze helper identity')
    freeze_helper_path = Path(freeze_helper['path'])
    members.add(freeze_helper_path, f'tools/{freeze_helper_path.name}', 'release_tools',
                freeze_helper_path.parent, 'final release freeze helper', freeze_helper['sha256'])
    for path in (O / 'freeze_native_release_298.py', O / 'run_guarded.py',
                 SUPERVISOR_PATH, O / 'run_stream_composition_full43_397.py',
                 O / 'run_stream_composition_acceptance_398.py', PACKAGE_HELPER):
        expected = SUPERVISOR_SHA256 if path == SUPERVISOR_PATH else None
        if path == SUPERVISOR_PATH:
            verify_file(path, expected)
        members.add(path, f'tools/{path.name}', 'acceptance_tools', path.parent,
                    'final acceptance/freeze/supervisor/packager source', expected)
    driver_path, driver_sha, driver_bytes = bound_entry(admission.get('driver'), 'Full43 acceptance driver')
    members.add(driver_path, f'tools/{driver_path.name}', 'acceptance_tools', driver_path.parent,
                'Full43 acceptance driver bound by admission', driver_sha, driver_bytes)

    # Bind documentation, rendered review and the preserved failed scope-matrix gate.
    documentation = read_json(O / 'stream-composition-docs-402/summary.json')
    need(documentation.get('status') == 'passed' and
         len(documentation.get('checks', [])) == 15 and
         documentation.get('source_identity_preserved') is True,
         'documentation does not prove all selected gates and source identity')
    for check in documentation['checks']:
        need(check.get('returncode') == 0, 'a final documentation gate failed')
        verify_file(Path(check['log']), check['log_sha256'])
    for relative, digest in documentation['files'].items():
        verify_file(REPO / relative, digest)
    browser = read_json(O / 'stream-composition-browser-400/summary.json')
    need(browser.get('status') == 'passed' and browser.get('reviewed_by') == 'primary' and
         browser.get('source_files') == documentation['files'],
         'browser review is not bound to the accepted guide files')
    for name, expected_status in (
        ('native-stream-composition-docs-399', 'failed'),
        ('native-stream-composition-docs-400', 'passed'),
        ('native-stream-composition-docs-401', 'passed'),
        ('native-stream-composition-docs-402', 'passed'),
        ('native-stream-composition-preview-400', 'passed'),
        ('native-stream-composition-preview-401', 'passed'),
        ('native-stream-composition-preview-402', 'passed'),
        ('native-stream-composition-final-docs-400', 'passed'),
    ):
        item = check_receipt(O / (name + '.json'), members, 'documentation/guards')
        need(item['status'] == expected_status, f'unexpected documentation receipt status: {name}')
    for directory in ('stream-composition-docs-399', 'stream-composition-docs-400',
                      'stream-composition-docs-401', 'stream-composition-docs-402',
                      'stream-composition-browser-400', 'stream-composition-final-docs-400'):
        members.add_tree('documentation', O / directory, 'documentation/' + directory,
                         'documentation or rendered review evidence')
    final_docs = read_json(O / 'stream-composition-final-docs-400/summary.json')
    need(final_docs.get('status') == 'passed' and
         final_docs.get('source_identity_preserved') is True and
         len(final_docs.get('checks', [])) == 4 and
         final_docs.get('prior_docs_summary_sha256') ==
         sha256_file(O / 'stream-composition-docs-402/summary.json')[1] and
         final_docs.get('browser_summary_sha256') ==
         sha256_file(O / 'stream-composition-browser-400/summary.json')[1],
         'final acceptance documentation does not bind the validated guide and rendered review')
    for check in final_docs['checks']:
        need(check['returncode'] == 0, 'a final acceptance documentation gate failed')
        verify_file(Path(check['log']), check['log_sha256'])
    for relative, digest in final_docs['files'].items():
        members.add(REPO / relative, 'documentation/repository/' + relative,
                    'repository', REPO, 'validated final documentation snapshot', digest)
    for name in ('run_stream_composition_docs_399.py', 'run_stream_composition_docs_400.py',
                 'run_stream_composition_docs_400_refresh.py', 'preview_stream_composition_401.py',
                 'run_stream_composition_docs_400_date.py', 'preview_stream_composition_402.py',
                 'install_stream_composition_packet_400.py',
                 'preview_stream_composition_400.py', 'finalize_stream_composition_docs_400.py',
                 'stream-composition-preview-address-400.json', 'stream-composition-preview-stop-400',
                 'stream-composition-preview-address-401.json', 'stream-composition-preview-stop-401',
                 'stream-composition-preview-address-402.json', 'stream-composition-preview-stop-402'):
        members.add(O / name, 'documentation/tools/' + name, 'evidence_root', O,
                    'documentation validation or preview source')

    # Record known excluded datasets and executables without reopening bulk data.
    full43_generation = admission.get('source_generation')
    excluded_assets.append(dict(kind='Full43 source Vortex input', path=admission.get('source'),
        byte_count=full43_generation.get('st_size') if isinstance(full43_generation, dict) else None,
        sha256=admission.get('source_sha256'), evidence='passed Full43 admission identity; not rehashed'))
    excluded_assets.append(dict(kind='final release executable', path=cli['path'],
        byte_count=cli['bytes'], sha256=cli['sha256'],
        evidence='final release manifest identity; not archived'))
    skipped_data = skipped_public_outputs + skipped_summary_data

    ordered = members.ordered()
    need(bool(ordered), 'refusing to package an empty evidence set')
    total_bytes = sum(item.size for item in ordered)
    reserve = total_bytes + max(64 * MIB, total_bytes // 50)
    check_budget(reserve, ARCHIVE_PATH)

    def verify_final_identity() -> dict:
        current = verify_current_source_and_binary(release, source_index, SOURCE_INDEX_PATH)
        need(current['head'] == source_identity['head'] and
             current['source_sha256'] == source_identity['source_sha256'] and
             current['binary_sha256'] == source_identity['binary_sha256'] and
             current['binary_bytes'] == source_identity['binary_bytes'],
             'final source or executable identity changed during packaging')
        return current

    temp_created = False
    try:
        verify_final_identity()
        with ARCHIVE_PARTIAL.open('xb') as output_stream:
            temp_created = True
            with tarfile.open(fileobj=output_stream, mode='w|xz', preset=6,
                              format=tarfile.PAX_FORMAT) as archive:
                for item in ordered:
                    before = item.path.stat()
                    info = tarfile.TarInfo(item.name)
                    info.size = item.size
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ''
                    with item.path.open('rb') as source_stream:
                        reader = HashingReader(source_stream)
                        archive.addfile(info, reader)
                    after = item.path.stat()
                    before_id = (before.st_dev, before.st_ino, before.st_size,
                                 before.st_mtime_ns, before.st_ctime_ns)
                    after_id = (after.st_dev, after.st_ino, after.st_size,
                                after.st_mtime_ns, after.st_ctime_ns)
                    need(before_id == after_id and reader.count == item.size and
                         reader.digest.hexdigest() == item.digest,
                         f'original evidence changed while archiving: {item.path}')

        archived: set[str] = set()
        with tarfile.open(ARCHIVE_PARTIAL, mode='r|xz') as archive:
            for info in archive:
                need(info.name not in archived and info.name in members.by_name,
                     f'unexpected or duplicate tar member {info.name}')
                archived.add(info.name)
                member = members.by_path[members.by_name[info.name]]
                need(info.isfile() and info.size == member.size,
                     f'tar member type or size mismatch: {info.name}')
                stream = archive.extractfile(info)
                need(stream is not None, f'cannot reopen tar member {info.name}')
                digest = hashlib.sha256()
                count = 0
                while True:
                    chunk = stream.read(CHUNK)
                    if not chunk:
                        break
                    digest.update(chunk)
                    count += len(chunk)
                need(count == member.size and digest.hexdigest() == member.digest,
                     f'archived member differs from original: {info.name}')
                verify_file(member.path, member.digest, member.size)
        need(archived == set(members.by_name), 'archive member inventory is incomplete')
        archive_bytes, archive_sha = sha256_file(ARCHIVE_PARTIAL)
        verify_final_identity()

        member_records = [dict(archive_path=item.name, logical_root=item.logical_root,
            relative_path=item.relative_path, original_absolute_path=str(item.path),
            byte_count=item.size, sha256=item.digest, roles=item.roles) for item in ordered]
        package_manifest = dict(
            schema='shardloom.stream_composition_evidence.v1', status='passed',
            base_head=BASE_HEAD, final_head=release['head'],
            source_index=str(SOURCE_INDEX_PATH), source_index_sha256=sha256_file(SOURCE_INDEX_PATH)[1],
            archive=dict(path=str(ARCHIVE_PATH), byte_count=archive_bytes, sha256=archive_sha),
            logical_root_mappings={
                'evidence_root': str(O), 'repository': str(REPO),
                'full43_summary_parent': str(summary_parent),
                'public_roots': [str(O.joinpath(*PurePosixPath(x['summary']).parent.parts))
                                 for x in public_summaries.values()] + [str(PUBLIC_ROOT)],
                'release_tools': 'individual absolute paths recorded in final release/protocol',
            },
            gates=dict(final_checks=str(FINAL_CHECKS_PATH), release=str(RELEASE_PATH),
                       full43_review=str(REVIEW_PATH), full43_calls=129,
                       full43_complete_rows=1143),
            receipt_count=len(receipts), catalog_freeze_manifest_count=len(freeze_manifests),
            catalog_public_summary_count=len(public_summaries),
            conditional_reference_query_harness=conditional_inputs,
            excluded_assets=excluded_assets,
            excluded_paths=sorted(set(skipped_data)),
            limitations=['Public outputs directories and bulk .vortex/.parquet files are excluded by scope.',
                         'Bulk data identities are retained from frozen reports; bulk files are not rehashed.',
                         'Failed and superseded receipts are retained as historical evidence.'],
            member_count=len(member_records), original_member_bytes=total_bytes,
            members=member_records)
        manifest_bytes = (json.dumps(package_manifest, sort_keys=True, indent=2,
                                     ensure_ascii=False) + '\n').encode()
        os.link(ARCHIVE_PARTIAL, ARCHIVE_PATH)
        ARCHIVE_PARTIAL.unlink()
        temp_created = False
        with MANIFEST_PARTIAL.open('xb') as stream:
            stream.write(manifest_bytes)
        check_budget(64 * MIB, ARCHIVE_PATH)
        verify_final_identity()
        os.link(MANIFEST_PARTIAL, MANIFEST_PATH)
        MANIFEST_PARTIAL.unlink()
        print(json.dumps(dict(status='passed', archive=str(ARCHIVE_PATH),
            manifest=str(MANIFEST_PATH), member_count=len(member_records),
            original_member_bytes=total_bytes, archive_bytes=archive_bytes,
            archive_sha256=archive_sha), indent=2))
    finally:
        if temp_created:
            ARCHIVE_PARTIAL.unlink(missing_ok=True)
        MANIFEST_PARTIAL.unlink(missing_ok=True)


if __name__ == '__main__':
    try:
        main()
    except NeedsReasoning as error:
        raise SystemExit(f'NEEDS_REASONING: {error}') from error
    except (KeyError, TypeError, json.JSONDecodeError, FileNotFoundError) as error:
        raise SystemExit(f'NEEDS_REASONING: final evidence schema or referenced file is incomplete: {error}') from error
