"""Serve the accepted static guide on a temporary loopback port for review."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import threading
import time

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
STOP = OUT / 'stream-composition-preview-stop-400'
ADDRESS = OUT / 'stream-composition-preview-address-400.json'


class Handler(SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        pass


def main():
    assert not STOP.exists() and not ADDRESS.exists()
    summary = json.loads((OUT / 'stream-composition-docs-400/summary.json').read_text())
    assert summary['status'] == 'passed'
    handler = partial(Handler, directory=str(ROOT / 'website'))
    with ThreadingHTTPServer(('127.0.0.1', 0), handler) as server:
        server.daemon_threads = True
        address = 'http://127.0.0.1:' + str(server.server_address[1])
        with ADDRESS.open('x') as target:
            json.dump({'address': address, 'website': str(ROOT / 'website')}, target)
        worker = threading.Thread(target=server.serve_forever, daemon=True)
        worker.start()
        print(address, flush=True)
        deadline = time.monotonic() + 600
        try:
            while not STOP.exists() and time.monotonic() < deadline:
                time.sleep(0.25)
        finally:
            server.shutdown()
            worker.join(timeout=5)
        assert STOP.exists(), 'preview review timed out without its completion marker'
        assert not worker.is_alive()
    print('preview closed cleanly', flush=True)


if __name__ == '__main__':
    main()
