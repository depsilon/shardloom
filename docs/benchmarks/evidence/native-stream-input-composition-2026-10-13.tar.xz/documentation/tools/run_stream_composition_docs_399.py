"""Validate current composition docs and regenerate their static guide output."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from freeze_native_release_298 import ROOT, OUT, save, sha, sources

NODE = Path('/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node')
SITE = ROOT / 'website-src'
DEST = OUT / 'stream-composition-docs-399'


def main():
    assert json.loads((OUT / 'stream-composition-final-checks-398.json').read_text())['status'] == 'passed'
    release = json.loads((OUT / 'stream-composition-398-release.json').read_text())
    assert sources() == release['source_sha256']
    DEST.mkdir()
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', ASTRO_TELEMETRY_DISABLED='1')
    checks = []

    def run(name, command, cwd=ROOT):
        command = [str(value) for value in command]
        log = DEST / (name + '.log')
        start = time.monotonic()
        with log.open('xb') as stream:
            result = subprocess.run(command, cwd=cwd, env=env, stdout=stream,
                                    stderr=subprocess.STDOUT, timeout=240)
        record = dict(name=name, command=command, cwd=str(cwd), returncode=result.returncode,
                      seconds=time.monotonic() - start, log=str(log), log_sha256=sha(log))
        checks.append(record)
        print(json.dumps(record), flush=True)
        result.check_returncode()

    run('user-surface-reference', [sys.executable, '-B', 'scripts/check_user_surface_reference.py'])
    run('public-status', [sys.executable, '-B', 'scripts/check_public_status_docs.py',
                         '--output', DEST / 'public-status.json'])
    run('use-case-backlinks', [sys.executable, '-B', 'scripts/check_use_case_backlinks.py'])
    run('contribution-governance', [sys.executable, '-B', 'scripts/check_contribution_governance.py',
                                  '--output', DEST / 'contribution-governance.json'])
    # Preserve the package.json check/build lifecycle without requiring npm.
    run('check-clean-static', [NODE, 'scripts/prebuild-static.mjs'], SITE)
    run('check-sync-content', [NODE, 'scripts/sync-content.mjs'], SITE)
    run('astro-check', [NODE, 'node_modules/astro/bin/astro.mjs', 'check'], SITE)
    run('check-settle-static', [NODE, 'scripts/prebuild-static.mjs', '--settle-output'], SITE)
    run('search-policy', [NODE, '--test', 'scripts/pagefind-policy.test.mjs'], SITE)
    run('build-reset-static', [NODE, 'scripts/prebuild-static.mjs', '--reset-output'], SITE)
    run('build-sync-content', [NODE, 'scripts/sync-content.mjs'], SITE)
    run('astro-build', [NODE, 'node_modules/astro/bin/astro.mjs', 'build'], SITE)
    run('postbuild-static', [NODE, 'scripts/postbuild-static.mjs'], SITE)
    run('website-readiness', [sys.executable, '-B', 'scripts/check_website_readiness.py',
                            '--output', DEST / 'website-readiness.json'])
    run('diff-check', ['git', 'diff', '--check'])
    assert sources() == release['source_sha256']
    paths = ['website-src/scripts/sync-content.mjs']
    for slug in ('python-surface', 'runtime-and-io', 'limitations'):
        paths.extend([f'website-src/src/content/docs/field-guide/{slug}.mdx',
                      f'website/field-guide/{slug}/index.html'])
    result = dict(schema='shardloom.stream_composition_docs.v1', status='passed',
                  checks=checks, files={path:sha(ROOT / path) for path in paths},
                  source_identity_preserved=True, browser_qa='separate_record',
                  publication_attempted=False)
    save(DEST / 'summary.json', result)
    print(json.dumps(dict(status='passed', summary=str(DEST / 'summary.json'), checks=len(checks))), flush=True)


if __name__ == '__main__':
    main()
