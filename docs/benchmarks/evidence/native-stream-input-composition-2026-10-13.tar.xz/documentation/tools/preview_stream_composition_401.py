"""Review the refreshed guide with distinct address and shutdown evidence."""
import json
import preview_stream_composition_400 as preview

preview.STOP = preview.OUT / 'stream-composition-preview-stop-401'
preview.ADDRESS = preview.OUT / 'stream-composition-preview-address-401.json'

if __name__ == '__main__':
    assert json.loads((preview.OUT / 'stream-composition-docs-401/summary.json').read_text())['status'] == 'passed'
    preview.main()
