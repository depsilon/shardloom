"""Check the final dated guide build on an owned loopback preview."""
import json
import preview_stream_composition_400 as preview

preview.STOP = preview.OUT / 'stream-composition-preview-stop-402'
preview.ADDRESS = preview.OUT / 'stream-composition-preview-address-402.json'

if __name__ == '__main__':
    assert json.loads((preview.OUT / 'stream-composition-docs-402/summary.json').read_text())['status'] == 'passed'
    preview.main()
