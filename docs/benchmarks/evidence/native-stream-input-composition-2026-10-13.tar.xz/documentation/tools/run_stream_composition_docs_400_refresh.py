"""Refresh rendered guides after correcting the final preparation sentence."""
import run_stream_composition_docs_399 as docs

docs.DEST = docs.OUT / 'stream-composition-docs-401'

if __name__ == '__main__':
    docs.main()
