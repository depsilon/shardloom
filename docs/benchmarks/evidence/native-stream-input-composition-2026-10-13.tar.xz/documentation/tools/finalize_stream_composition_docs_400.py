"""Verify final acceptance text after the rendered guide review."""
import json
import os
import subprocess
import sys
import time

from freeze_native_release_298 import ROOT, OUT, save, sha, sources

DEST = OUT / 'stream-composition-final-docs-400'


def main():
    release = json.loads((OUT / 'stream-composition-398-release.json').read_text())
    docs = json.loads((OUT / 'stream-composition-docs-402/summary.json').read_text())
    browser = json.loads((OUT / 'stream-composition-browser-400/summary.json').read_text())
    assert docs['status'] == browser['status'] == 'passed'
    assert browser['source_files'] == docs['files']
    assert all(sha(ROOT / path) == digest for path, digest in docs['files'].items())
    assert sources() == release['source_sha256']
    DEST.mkdir()
    checks = []
    commands = [
        ('user-surface-reference', [sys.executable, '-B', 'scripts/check_user_surface_reference.py']),
        ('public-status', [sys.executable, '-B', 'scripts/check_public_status_docs.py',
                           '--output', str(DEST / 'public-status.json')]),
        ('use-case-backlinks', [sys.executable, '-B', 'scripts/check_use_case_backlinks.py']),
        ('diff-check', ['git', 'diff', '--check']),
    ]
    for name, command in commands:
        log = DEST / (name + '.log')
        start = time.monotonic()
        with log.open('xb') as stream:
            result = subprocess.run(command, cwd=ROOT, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
                                    stdout=stream, stderr=subprocess.STDOUT, timeout=120)
        checks.append(dict(name=name, command=command, returncode=result.returncode,
                           seconds=time.monotonic() - start, log=str(log), log_sha256=sha(log)))
        result.check_returncode()
    paths = [
        'docs/architecture/native-stream-input-composition-2026-10-13.md',
        'docs/benchmarks/native-stream-input-composition-2026-10-13.md',
        'docs/benchmarks/native-fresh-uat-2026-10-13.md',
        'docs/architecture/native-local-completion-scope-2026-10-07.md',
        'docs/architecture/native-bounded-adapters-2026-10-06.md',
        'docs/architecture/phased-execution-plan.md',
        'docs/architecture/v1-local-resource-safety.md',
        'docs/reference/native-query-spill.md',
        'docs/reference/resident-native-results.md',
        'docs/reference/shardloom-user-surface-index.json',
        'docs/reference/shardloom-user-surface-index.md',
        'docs/release/v1-inclusion-scope-matrix.md',
        'python/README.md',
    ]
    files = {path: sha(ROOT / path) for path in paths}
    files.update(docs['files'])
    assert sources() == release['source_sha256']
    save(DEST / 'summary.json', dict(status='passed', checks=checks, files=files,
         prior_docs_summary_sha256=sha(OUT / 'stream-composition-docs-402/summary.json'),
         browser_summary_sha256=sha(OUT / 'stream-composition-browser-400/summary.json'),
         source_identity_preserved=True, publication_attempted=False))
    print(json.dumps(dict(status='passed', checks=len(checks), files=len(files))), flush=True)


if __name__ == '__main__':
    main()
