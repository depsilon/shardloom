"""Install the verified portable composition packet and its concise index."""
import hashlib
import json
import lzma
from pathlib import Path
import re
import shutil

from freeze_native_release_298 import ROOT, OUT, sha, sources

DEST = ROOT / 'docs/benchmarks/evidence'
STEM = 'native-stream-input-composition-2026-10-13'


def write_exclusive(path, data):
    with path.open('xb') as stream:
        stream.write(data)


def test_counts(path):
    text = path.read_text()
    groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    assert groups and not re.search(r'test result: FAILED', text)
    return dict(groups=len(groups), passed=sum(int(x[0]) for x in groups),
                failed=sum(int(x[1]) for x in groups), ignored=sum(int(x[2]) for x in groups))


def main():
    release = json.loads((OUT / 'stream-composition-398-release.json').read_text())
    manifest_path = OUT / 'stream-composition-398-evidence.manifest.json'
    manifest = json.loads(manifest_path.read_text())
    assert manifest['status'] == 'passed'
    assert sources() == release['source_sha256']
    original_archive = Path(manifest['archive']['path'])
    assert original_archive.stat().st_size == manifest['archive']['byte_count']
    assert sha(original_archive) == manifest['archive']['sha256']
    targets = [DEST / (STEM + suffix) for suffix in ('.tar.xz', '.manifest.json.xz', '.json')]
    assert all(not p.exists() and not p.is_symlink() for p in targets)
    with original_archive.open('rb') as source, targets[0].open('xb') as target:
        shutil.copyfileobj(source, target, 1 << 20)
    assert sha(targets[0]) == manifest['archive']['sha256']
    original_manifest = manifest_path.read_bytes()
    write_exclusive(targets[1], lzma.compress(original_manifest, preset=6))
    assert lzma.decompress(targets[1].read_bytes()) == original_manifest
    public = json.loads((OUT / 'stream-composition-public-398/summary.json').read_text())
    full43 = json.loads((OUT / 'stream-composition-full43-primary-review-398.json').read_text())
    default_tests = test_counts(OUT / 'native-stream-composition-workspace-tests-398.log')
    native_tests = test_counts(OUT / 'native-stream-composition-native-tests-398.log')
    assert default_tests == dict(groups=106, passed=3219, failed=0, ignored=0)
    assert native_tests == dict(groups=92, passed=4145, failed=0, ignored=27)
    assert public['status'] == full43['status'] == 'passed'
    assert len(public['cases']) == 757
    assert full43['calls'] == 129 and full43['complete_rows'] == 1143
    final_docs = json.loads((OUT / 'stream-composition-final-docs-400/summary.json').read_text())
    browser = json.loads((OUT / 'stream-composition-browser-400/summary.json').read_text())
    assert final_docs['status'] == browser['status'] == 'passed'
    index = dict(
        schema_version='shardloom.native_stream_composition_index.v1',
        status='local_acceptance_complete_hosted_pending',
        source_identity=dict(base_commit=release['head'], selected_file_count=len(release['source_sha256']),
            source_manifest_sha256=release['source_manifest']['sha256'],
            scope='The changed runtime is identified by the frozen selected-file hashes and the PR; the base commit alone is insufficient.'),
        executable=dict(bytes=release['cli']['bytes'], sha256=release['cli']['sha256']),
        archive=dict(path=targets[0].name, bytes=targets[0].stat().st_size, sha256=sha(targets[0])),
        manifest=dict(path=targets[1].name, bytes=targets[1].stat().st_size, sha256=sha(targets[1]),
            uncompressed_sha256=hashlib.sha256(original_manifest).hexdigest()),
        verified_members=manifest['member_count'], original_bytes=manifest['original_member_bytes'],
        results=dict(public_cases=757, public_families=19, default_workspace=default_tests,
            native_features=native_tests, full43_calls=129, full43_rows=1143,
            documentation_gates=15, final_text_gates=4,
            rendered_guides=['python-surface','runtime-and-io','limitations'],
            rendered_review='desktop/mobile, dark/light, menu, internal link and replay search'),
        timing=dict(native_full43_process_seconds=full43['complete_operation_seconds'],
                    supervised_full43_seconds=full43['supervised_suite_seconds']),
        evidence_paths=dict(final_checks='final/stream-composition-final-checks-398.json',
            full43_review='final/stream-composition-full43-primary-review-398.json',
            release='final/stream-composition-398-release.json',
            source_manifest='final/stream-composition-398-source.json',
            public_review='final/stream-composition-public-review-399.json',
            browser='documentation/stream-composition-browser-400/summary.json',
            final_documentation='documentation/stream-composition-final-docs-400/summary.json'),
        baseline_index='native-fresh-uat-2026-10-13.json',
        limitations=[
            'Local macOS arm64 acceptance; hosted integration is pending.',
            'Native test exclusions: three non-Unix cases for Windows CI and 24 manual benchmark, fixture or workload-dependent cases.',
            'Retained native Full43 regression reference; no new ingest or independent oracle in this final regression.',
            'Public bulk outputs and executables are hash-identified and excluded from the portable archive.',
            'Failed and superseded attempts are retained; all archive members and copied bytes were verified.',
            'No paired speedup, process-RSS ceiling, new package release or whole PERF/CG completion claim.',
        ],
    )
    write_exclusive(targets[2], (json.dumps(index, indent=2) + '\n').encode())
    assert sources() == release['source_sha256']
    print(json.dumps(index, indent=2), flush=True)


if __name__ == '__main__':
    main()
