"""Verify production against immutable merged Git blobs, independent of new work."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import urllib.request

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent / 'compression-hosted-466' / 'production-verified'
MERGE = '2b87cf7f911d667b7ef279fdedb1ba4ef2167459'
VERSION = 'c673d06a-b56f-4898-a316-af7209d1d9cd'
ORIGIN = 'https://shardloom.io'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    check_raw = subprocess.check_output([
        '/opt/homebrew/bin/gh', 'api',
        'repos/depsilon/shardloom/check-runs/116397229908',
    ])
    check = json.loads(check_raw)
    assert check['head_sha'] == MERGE
    assert check['status'] == 'completed' and check['conclusion'] == 'success'
    assert VERSION in check['output']['summary']
    OUT.mkdir(exist_ok=False)
    (OUT / 'deployment-check.json').write_bytes(check_raw)
    routes = [
        'field-guide/benchmark-methodology/index.html',
        'field-guide/runtime-and-io/index.html',
        'field-guide/limitations/index.html',
        'benchmarks/index.html', 'benchmarks.html',
        'assets/parallax-home.js', 'pagefind/pagefind-entry.json',
    ]
    records = []
    for route in routes:
        source = 'website/' + route
        expected = subprocess.check_output(['git', 'show', MERGE + ':' + source], cwd=ROOT)
        url = ORIGIN + '/' + route.removesuffix('index.html')
        request = urllib.request.Request(url, headers={'User-Agent': 'ShardLoom-owned-site-verification'})
        with urllib.request.urlopen(request, timeout=30) as response:
            actual = response.read((2 << 20) + 1)
            assert response.status == 200 and len(actual) <= 2 << 20
            final_url = response.url
        filename = route.replace('/', '_')
        (OUT / filename).write_bytes(actual)
        prefix = 0
        while prefix < min(len(actual), len(expected)) and actual[prefix] == expected[prefix]:
            prefix += 1
        extra = len(actual) - len(expected)
        insertion = b''
        preserved = actual == expected
        if not preserved and 0 < extra <= 16384 and route.endswith('.html'):
            insertion = actual[prefix:prefix + extra]
            preserved = actual[prefix + extra:] == expected[prefix:]
            preserved &= b'/cdn-cgi/challenge-platform/' in insertion or b'static.cloudflareinsights.com/' in insertion
        records.append(dict(source=source, response=filename, url=url,
            final_url=final_url, http_status=200, expected_bytes=len(expected),
            expected_sha256=sha(expected), observed_bytes=len(actual),
            observed_sha256=sha(actual), raw_byte_identical=actual == expected,
            source_preserved=bool(preserved), insertion_bytes=len(insertion),
            insertion_sha256=sha(insertion) if insertion else None))
    report = dict(schema_version='shardloom.compression_timing_served_source.v1',
        status='passed' if all(row['source_preserved'] for row in records) else 'failed',
        observed_at=datetime.now(timezone.utc).isoformat(), head=MERGE,
        origin=ORIGIN, deployment_version=VERSION, responses=records,
        deployment_check_sha256=sha(check_raw),
        scope='Production response bytes compared with immutable merged source; no new browser rendering claim.')
    with (OUT / 'report.json').open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': report['status'], 'responses': len(records),
        'source_preserved': sum(r['source_preserved'] for r in records)}))
    assert report['status'] == 'passed', report


if __name__ == '__main__':
    main()
