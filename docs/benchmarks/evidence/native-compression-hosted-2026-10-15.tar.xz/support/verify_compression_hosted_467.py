"""Close PR1555 integration using exact revisions, complete logs and served bytes."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
RAW = OUT / 'compression-hosted-466'
HEAD = '419ac33ff9888b586df706b5e29b5592439070c0'
MERGE = '2b87cf7f911d667b7ef279fdedb1ba4ef2167459'
SYNTHETIC = '617230133a01190e2ea6e8ec4f41e762c3c6d7c1'


def read(path):
    return json.loads(path.read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def save(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')


def plain(text):
    return '\n'.join(re.sub(r'^\d{4}-\d{2}-\d{2}T\S+Z ', '', line)
                     for line in text.lstrip('\ufeff').splitlines())


def main():
    checks = read(RAW / 'checks-final.json')['structuredContent']
    assert checks['headRevision'] == HEAD and not checks['hasMore']
    assert len(checks['checks']) == len({c['id'] for c in checks['checks']}) == 44
    assert all(c['head_sha'] == HEAD and c['status'] == 'completed' and c['conclusion'] == 'success'
               for c in checks['checks'])
    merged = read(RAW / 'merge.json')['structuredContent']
    assert merged['merged'] is True and merged['sha'] == MERGE
    trees = {revision: subprocess.check_output(['git', 'rev-parse', revision + '^{tree}'],
                                              cwd=ROOT, text=True).strip()
             for revision in (HEAD, MERGE, SYNTHETIC)}
    assert len(set(trees.values())) == 1
    inventory = read(OUT / 'compression-hosted-log-inventory-467.json')
    inputs = {}
    for row in inventory['input_logs'].values():
        path = Path(row['path'])
        assert identity(path) == row
        inputs[str(path)] = (row['sha256'], path.read_text().splitlines())
    excerpts = 0
    def verify_excerpts(value):
        nonlocal excerpts
        if isinstance(value, dict):
            if {'source_path', 'source_sha256', 'line_start', 'line_end', 'literal_text'} <= value.keys():
                digest, lines = inputs[value['source_path']]
                assert value['source_sha256'] == digest
                assert '\n'.join(lines[value['line_start'] - 1:value['line_end']]) == value['literal_text']
                excerpts += 1
            for child in value.values():
                verify_excerpts(child)
        elif isinstance(value, list):
            for child in value:
                verify_excerpts(child)
    verify_excerpts(inventory)
    assert excerpts > 100
    log = plain((RAW / 'native-job-full.log').read_text())
    assert SYNTHETIC + ':refs/remotes/pull/1555/merge' in log
    groups = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log, re.M)
    assert groups == [('2806', '0', '26'), ('10', '0', '0'), ('7', '0', '0'),
                      ('7', '0', '0'), ('17', '0', '0'), ('4', '0', '0')], groups
    assert not re.search(r'^test .* \.\.\. FAILED$', log, re.M)
    wheels = []
    for lane in ('py310-ubuntu', 'py313-ubuntu', 'py313-macos'):
        path = RAW / f'wheel-{lane}-job-full.log'
        text = plain(path.read_text())
        assert SYNTHETIC + ':refs/remotes/pull/1555/merge' in text
        marker = '{\n  "schema_version": "shardloom.native_python_wheel_proof.v1"'
        assert text.count(marker) == 1
        proof, _ = json.JSONDecoder().raw_decode(text[text.index(marker):])
        assert proof['status'] == proof['stage']['status'] == proof['integrity']['status'] == 'passed'
        assert proof['integration'] == dict(tests=80, failures=0, errors=0, skipped=0, status='passed')
        assert all(step['returncode'] == 0 for step in proof['steps'])
        assert proof['installed_load']['isolated_install'] and proof['installed_load']['version'] == '0.6.0'
        assert proof['publication_attempted'] is False and proof['performance_claim'] is False
        wheels.append(dict(lane=lane, raw=identity(path), proof=proof))
    reviews = read(RAW / 'reviews-final.json')['structuredContent']['reviews']
    assert all(r['state'] != 'CHANGES_REQUESTED' for r in reviews)
    threads = read(RAW / 'review-threads-final.json')['structuredContent']['review_threads']
    assert len(threads) == 1 and threads[0]['is_resolved']
    assert 'Score paired comparisons with the engine clock' in threads[0]['comments'][0]['body']
    assert HEAD in threads[0]['comments'][1]['body']
    comments = read(RAW / 'comments-final.json')
    clean = [c for c in comments if c['id'] == 6190443585]
    assert len(clean) == 1 and HEAD[:10] in clean[0]['body'] and "Didn't find any major issues" in clean[0]['body']
    before = read(OUT / 'native-release-source-timing460.json')['source_sha256']
    assert len(before) == 2258
    changed = {}
    with subprocess.Popen(['git', 'cat-file', '--batch'], cwd=ROOT,
                          stdin=subprocess.PIPE, stdout=subprocess.PIPE) as child:
        for name, expected in sorted(before.items()):
            assert '\n' not in name
            child.stdin.write((MERGE + ':' + name + '\n').encode()); child.stdin.flush()
            header = child.stdout.readline().decode().split()
            assert len(header) == 3 and header[1] == 'blob', name
            payload = child.stdout.read(int(header[2]))
            assert child.stdout.read(1) == b'\n'
            digest = sha(payload)
            if digest != expected:
                changed[name] = dict(measured_sha256=expected, merged_sha256=digest)
        child.stdin.close()
        assert child.wait(timeout=30) == 0
    assert set(changed) == {'scripts/run_clickbench_query_uat.py', 'scripts/run_clickbench_paired_query_uat.py',
                            'scripts/test_clickbench_query_uat.py', 'scripts/test_clickbench_paired_query_uat.py'}
    artifacts = read(OUT / 'query-timing-native-artifacts-461.json')
    for key in ('cli', 'binding'):
        actual = identity(Path(artifacts[key]['path']))
        assert actual['sha256'] == artifacts[key]['sha256'] and actual['bytes'] == artifacts[key]['bytes']
    served = {}
    for name, revision in [('preview', HEAD), ('production-verified', MERGE)]:
        folder = RAW / name
        report = read(folder / 'report.json')
        assert report['status'] == 'passed' and report['head'] == revision
        assert len(report['responses']) == 7
        for response in report['responses']:
            assert response['source_preserved'] and response['http_status'] == 200
            actual = (folder / response['response']).read_bytes()
            expected = subprocess.check_output(['git', 'show', revision + ':' + response['source']], cwd=ROOT)
            assert sha(actual) == response['observed_sha256']
            assert sha(expected) == response['expected_sha256']
            assert len(actual) == response['observed_bytes']
        served[name] = report
    report = dict(schema_version='shardloom.native_compression_hosted_verification.v1', status='passed',
        head=HEAD, merge=MERGE, synthetic=SYNTHETIC, trees=trees, checks_passed=44,
        native_test_groups=groups, wheel_lanes=wheels, inventory_excerpts_verified=excerpts,
        source_files_checked=len(before), changed_since_measured_source=changed,
        accepted_native_source_preserved=True, accepted_cli_and_binding_hashes_verified=True,
        source_version='0.6.0', publication_claimed=False, served=served,
        review='Engine-scoring finding fixed and resolved; final-head automated review found no major issues.',
        production_deployment_verified=True, driver=identity(Path(__file__)))
    save(RAW / 'verification.json', report)
    files = {'hosted/' + str(p.relative_to(RAW)): p for p in RAW.rglob('*') if p.is_file()}
    for path in (Path(__file__), OUT / 'compression-hosted-log-inventory-467.json',
                 OUT / 'native-release-source-timing460.json', OUT / 'query-timing-native-artifacts-461.json',
                 OUT / 'capture_compression_preview_464.py', OUT / 'capture_compression_preview_466.py',
                 OUT / 'capture_compression_production_467.py'):
        files['support/' + path.name] = path
    destination = ROOT / 'docs/benchmarks/evidence'
    archive = destination / 'native-compression-hosted-2026-10-15.tar.xz'
    index = destination / 'native-compression-hosted-2026-10-15.json'
    assert not archive.exists() and not index.exists()
    members = []
    with tarfile.open(archive, 'x:xz') as stream:
        for name, path in sorted(files.items()):
            payload = path.read_bytes()
            member = tarfile.TarInfo(name); member.size = len(payload); member.mode = 0o644
            stream.addfile(member, io.BytesIO(payload))
            members.append(dict(name=name, bytes=len(payload), sha256=sha(payload)))
    with tarfile.open(archive, 'r:xz') as stream:
        assert len(stream.getmembers()) == len(members)
        for member in members:
            payload = stream.extractfile(member['name']).read()
            assert len(payload) == member['bytes'] and sha(payload) == member['sha256']
            assert payload == files[member['name']].read_bytes()
    save(index, dict(schema_version='shardloom.native_compression_hosted_packet.v1', status='passed',
        pr=1555, head=HEAD, merge=MERGE, synthetic=SYNTHETIC, checks_passed=44,
        native_test_groups=groups, wheel_lanes=[w['lane'] for w in wheels], wheel_tests_per_lane=80,
        served_responses_verified=14, production_version=served['production-verified']['deployment_version'],
        accepted_native_source_preserved=True, source_files_checked=len(before),
        changed_since_measured_source=changed, inventory_excerpts_verified=excerpts,
        archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=sha(archive.read_bytes())),
        members_verified=len(members), members=members, publication_claimed=False,
        browser_scope='Earlier rendered guide/search proof is retained in the timing acceptance packet; this packet adds served-source equality.'))
    print(json.dumps(dict(status='passed', checks=44, wheel_lanes=3, excerpts=excerpts,
        sources=len(before), served_responses=14, members=len(members))))


if __name__ == '__main__':
    main()
