"""Verify the final PR revision's deployed source using the accepted verifier."""
import importlib.util
from pathlib import Path

root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    'compression_preview_verifier', root / 'capture_compression_preview_464.py'
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.OUT = root / 'compression-hosted-466' / 'preview'
module.OUT.parent.mkdir(exist_ok=True)
module.HEAD = '419ac33ff9888b586df706b5e29b5592439070c0'
module.ORIGIN = 'https://8acbf6f6-shardloom.djheinrich.workers.dev'
module.VERSION = '8acbf6f6-2940-4e23-8e88-033b17de7a95'
module.main()
