"""Bind the actual merge to the reviewed, hosted, and measured text-scan source."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import sys

O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
D = O/'native-text-scan-hosted-646'
sys.path.insert(0, str(O))
import verify_stream_destination_integrated_sources_482 as verifier
verifier.R = R
read = lambda p: json.loads(Path(p).read_text())
identity = lambda p: dict(path=str(p), bytes=Path(p).stat().st_size, sha256=hashlib.sha256(Path(p).read_bytes()).hexdigest())
coverage = read(D/'pr-sources.json')
merge = sys.argv[1]
assert re.fullmatch('[a-f0-9]{40}', merge)
head, base, synthetic = coverage['head'], coverage['base'], coverage['ci_merge']
trees = {key: verifier.git('rev-parse', revision+'^{tree}').decode().strip()
         for key, revision in dict(head=head, synthetic=synthetic, merge=merge).items()}
assert len(set(trees.values())) == 1
parents = verifier.git('rev-list', '--parents', '-n', '1', merge).decode().split()
assert parents == [merge, base, head]
mapping, _ = verifier.immutable_source_map(merge)
assert len(mapping) == 2415 and {path: item['sha256'] for path, item in mapping.items()} == coverage['source_sha256']
for field in ('accepted_source', 'measured_source'):
    assert identity(Path(coverage[field]['path'])) == coverage[field]
    assert read(coverage[field]['path'])['source_sha256'] == coverage['source_sha256']
record = dict(status='passed', recorded_at=datetime.now(timezone.utc).isoformat(),
              head=head, base=base, merge=merge, ci_merge=synthetic, trees=trees,
              parents=parents[1:], source_files=mapping, selected_source_count=2415,
              all_selected_sources_match=True, accepted_source=coverage['accepted_source'],
              measured_source=coverage['measured_source'],
              pr_source_verification=identity(D/'pr-sources.json'),
              helper=identity(Path(verifier.__file__)), executed_program=identity(Path(__file__)),
              scope='All 2,415 merged sources are byte-identical to the reviewed head, CI synthetic merge, measured build 642 and local acceptance 644.')
target = D/'merged-sources-646.json'
target.open('x').write(json.dumps(record, indent=2)+'\n')
print(json.dumps(dict(status='passed', merge=merge, source_files=len(mapping), tree=next(iter(trees.values())))))
