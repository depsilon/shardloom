"""Package independently checked hosted closure without rewriting local observations."""
from pathlib import Path
from datetime import datetime, timezone
from decimal import Decimal
import hashlib, io, json, subprocess, sys, tarfile

O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
D=O/'native-shared-execution-hosted-626'
sys.path[:0]=[str(O),str(R/'scripts')]
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
import verify_stream_destination_integrated_sources_482 as v
v.R=R
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
identity=lambda p:dict(path=str(p),bytes=Path(p).stat().st_size,sha256=sha(p))
def check(ref):
 p=Path(ref['path']);assert p.is_file() and not p.is_symlink(),p
 assert sha(p)==ref['sha256'],p
 if 'bytes' in ref:assert p.stat().st_size==ref['bytes'],p
 return p
def immutable_file(path,revision):
 raw=v.git('show',revision+':'+path.relative_to(R).as_posix())
 assert raw==path.read_bytes(),path

head='77d5b5da9561b04b4c5cb81e94cce07529528cd8'
merge=sys.argv[1];synthetic='cb2729f7bed7f910380858c2e80d0a3d7191a780'
coverage=read(D/'pr-sources.json');merged=read(D/'merged-sources-626.json')
assert coverage['status']==merged['status']=='passed' and coverage['head']==merged['head']==head and merged['merge']==merge
mapping,_=v.immutable_source_map(merge)
assert len(mapping)==2412 and mapping==merged['source_files']
assert {p:r['sha256'] for p,r in mapping.items()}==coverage['source_sha256']
assert set(merged['trees'].values())=={v.git('rev-parse',merge+'^{tree}').decode().strip()}
closeouts={}
for stage in ('premerge','postmerge'):
 p=D/(stage+'-626')/'report.json';d=read(p)
 assert d['status']=='passed' and d['checks_passed']==44 and d['head']==head and d['merge']==(merge if stage=='postmerge' else None)
 assert d['review_threads']==d['unresolved_review_threads']==d['open_pr_code_scanning_alerts']==0
 assert d['code_review']==dict(commit_sha=head,has_any_findings=False,has_unresolved_findings=False,status='completed')
 assert d['review_coverage']==dict(automated_review_head=head,final_head=head,automated_review_covers_final_head=True)
 for item in d['metadata']+[d['source_verification'],d['helper']]:check(item)
 checks=read(p.parent/'checks.json');assert checks['total_count']==len(checks['check_runs'])==44
 assert all(c['head_sha']==head and c['status']=='completed' and c['conclusion']=='success' for c in checks['check_runs'])
 closeouts[stage]=identity(p)
job_candidates=[p for p in sorted(D.glob('primary-jobs-capture-*.json')) if read(p)['status']=='passed_all_eight']
assert len(job_candidates)==1
jobs_path=job_candidates[0];jobs=read(jobs_path)
assert jobs['head']==head and jobs['synthetic']==synthetic and jobs['pending']==[] and len(jobs['jobs'])==8
for key in ('capture','run','source_verification','test_inventory','capture_parameters','parser_helper'):check(jobs[key])
for row in jobs['jobs']:
 check(row['raw']);meta=read(check(row['metadata']))
 assert meta['head_sha']==head and meta['status']=='completed' and meta['conclusion']=='success'
wheels=[r for r in jobs['jobs'] if r['name'].startswith('Native Python wheel')]
assert len(wheels)==3 and all(r['proof']['integration']==dict(tests=100,failures=0,errors=0,skipped=0,status='passed') for r in wheels)
native=next(r for r in jobs['jobs'] if 'native_vortex_tests' in r['name'])
assert native['result_groups'][0]==[2958,0,27] and len(native['new_native_tests'])==12
assert native['total_passed']==sum(g[0] for g in native['result_groups'])
public=next(r for r in jobs['jobs'] if 'native_public_surface_tests' in r['name']);assert public['total_passed']==1079
served={}
for stage,revision in [('preview',head),('production',merge)]:
 p=D/(stage+'-served-569')/'report.json';d=read(p)
 assert d['status']=='passed' and d['head']==revision and d['reviewed_head']==head and len(d['responses'])==8
 checks=read(p.parent/'deployment-checks.json')
 workers=[x for x in checks['check_runs'] if x['name']=='Workers Builds: shardloom']
 assert len(workers)==1 and workers[0]['head_sha']==revision and workers[0]['status']=='completed' and workers[0]['conclusion']=='success'
 for row in d['responses']:
  raw=(p.parent/row['response']).read_bytes();expected=v.git('show',revision+':'+row['source'])
  assert row['http_status']==200 and row['source_preserved'] and len(raw)==row['observed_bytes'] and hashlib.sha256(raw).hexdigest()==row['observed_sha256']
  assert len(expected)==row['expected_bytes'] and hashlib.sha256(expected).hexdigest()==row['expected_sha256']
  if raw!=expected:
   prefix=next(i for i,(a,b) in enumerate(zip(raw,expected)) if a!=b)
   extra=len(raw)-len(expected);insert=raw[prefix:prefix+extra]
   assert 0<extra<=16384 and raw[prefix+extra:]==expected[prefix:]
   assert b'/cdn-cgi/challenge-platform/' in insert or b'static.cloudflareinsights.com/' in insert
   assert extra==row['insertion_bytes'] and hashlib.sha256(insert).hexdigest()==row['insertion_sha256']
 served[stage]=identity(p)
preview=read(D/'browser/preview-report.json');production=read(D/'browser/production-report.json')
assert preview['status']==production['status']=='passed' and preview['head']==production['head']==head and production['merge']==merge
assert all(x['viewport_restored'] and x['mobile']['no_horizontal_overflow'] and not x['console'] for x in (preview,production))
review_path=O/'native-shared-execution-final-review-625.json';review=read(review_path)
assert review['status']=='passed' and review['selected_source_files']==2412 and not review['unresolved_local_findings']
local_index_path=check(review['portable_evidence']);local_index=read(local_index_path)
assert local_index['status']=='passed_local_evidence_packaged' and local_index['source_files']==2412 and local_index['member_count']==28621
assert local_index['all_members_reopened'] and local_index['source_identity_preserved'] and not local_index['hosted_integration_complete']
expected_acceptance=dict(complete_paired_calls=1242,attempts=15,paired_cohorts=58,workspace_test_executions=4374,workspace_ignored=0,native_test_executions=4037,native_manual_exclusions=27,direct_methods=100,direct_skips=0,public_cases=4827,public_families=36,modular_cohorts=18,native_workflows=704,independent_oracle_records=704)
assert local_index['acceptance']==review['acceptance']==expected_acceptance
decision_path=check(local_index['maintainer_decision']);decision=read(decision_path)
assert decision['status']=='accepted_under_revised_maintainer_bar' and decision['frozen_measurements_and_original_decision_preserved']
assert decision['original_material_gate_percent']=='5' and decision['original_gate_passed'] is False
assert decision['revised_minimum_engine_improvement_percent_exclusive']=='3'
comparison_path=check(decision['original_review']);comparison=read(comparison_path)
assert comparison['status']=='passed_integrity' and comparison['decision']=='drop_failed_material_gate'
assert comparison['calls']==172 and comparison['material_regression_queries']==[] and comparison['material_gain_passed'] is False
assert comparison['all_complete_values_and_schemas'] and comparison['no_fallback_evidence_verified']
assert comparison['all_resources_and_physical_policy_equal_within_each_query'] and comparison['both_paired_totals_improved']
assert comparison['observed_gain_percent']==decision['observed_engine_improvement_percent']
assert Decimal(comparison['observed_gain_percent'])>Decimal('3')
assert comparison['total_engine_means']==dict(control='57.310191503',candidate='54.899272149')
assert local_index['whole_workload_readback']['619']['mean_totals_engine_seconds']==comparison['total_engine_means']
published_local_files=[]
immutable_file(local_index_path,merge)
for item in list(local_index['archives'].values())+[local_index['manifest']]:
 p=local_index_path.parent/item['file'];assert p.name==item['file']
 assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256']
 immutable_file(p,merge);published_local_files.append(identity(p))
bridge_path=check(coverage['comment_only_bridge']);bridge=read(bridge_path)
assert bridge['status']=='passed' and bridge['runtime_tokens_unchanged'] and bridge['unchanged_selected_sources']==2411
assert bridge['selected_source_count']==2412 and bridge['behavior_changed'] is False
assert read(check(coverage['accepted_source']))['source_sha256']==coverage['source_sha256']
assert coverage['comment_only_bridge']==review['comment_bridge']
for field in ('archive_receipt','documentation_receipt','documentation_results'):
 assert read(check(review[field]))['status']=='passed'
assert all(x['returncode']==0 for x in read(check(review['documentation_results']))['checks'])
files={}
def add(name,path):
 assert name not in files and path.is_file() and not path.is_symlink(),(name,path)
 files[name]=path
for p in sorted(D.rglob('*')):
 if p.is_file():add('hosted/'+p.relative_to(D).as_posix(),p)
support=[review_path,comparison_path,decision_path,local_index_path,bridge_path,
 *[check(coverage[k]) for k in ('accepted_source','measured_source','artifacts')],
 *[check(review[k]) for k in ('archive_receipt','documentation_receipt','documentation_results')],
 O/'native-shared-execution-test-inventory-625.json',O/'native-shared-execution-hosted-jobs-626.json',
 O/'prepare_shared_execution_hosted_626.py',O/'prepare_shared_execution_hosted_626_first.py',
 O/'verify_shared_execution_comment_bridge_625.py',Path(__file__),O/'verify_shared_execution_merged_sources_626.py',
 O/'run_shared_execution_final_docs_625_first.py',O/'run_shared_execution_final_docs_625.py',
 O/'native-shared-execution-final-docs-625.json',O/'native-shared-execution-final-docs-625.log',
 O/'native-shared-execution-final-docs-625b.log']
for p in support:add('support/'+p.relative_to(O).as_posix() if p.is_relative_to(O) else 'support/repo/'+p.relative_to(R).as_posix(),p)
helper_paths=[check(jobs['parser_helper']),Path(read(D/'capture-parameters.json')['helper']),
 Path(read(D/'served-parameters.json')['helper']),Path(read(D/'closeout-launch.json')['helper']),
 O/'verify_worker_drain_integrated_sources_569.py',O/'verify_stream_subquery_integrated_sources_513.py',
 Path(v.__file__),O/'freeze_native_release_298.py',R/'scripts/local_uat_storage.py']
for p in helper_paths:add('helpers/'+p.name,p)
for relative in ('docs/benchmarks/native-shared-execution-2026-10-17.md','docs/architecture/native-shared-execution-2026-10-17.md','docs/benchmarks/evidence/native-shared-execution-comment-bridge-2026-10-17.json'):
 p=R/relative;immutable_file(p,merge);add('source/'+relative,p)
destination=require_local_path(O/'native-shared-execution-hosted-packet-626',Path.home(),sys.platform)
assert not destination.exists() and sum(p.stat().st_size for p in files.values())<32*MIB
check_budgets(O,destination,O/'logs',min_free_bytes=12*GIB,reserve_bytes=64*MIB,max_workspace_bytes=100*GIB,max_log_bytes=192*MIB)
destination.mkdir();archive=destination/'native-shared-execution-hosted-2026-10-17.tar.xz';members=[]
with tarfile.open(archive,'x:xz') as bundle:
 for name,p in sorted(files.items()):
  before=identity(p);raw=p.read_bytes();item=tarfile.TarInfo(name);item.size=len(raw);item.mode=0o644
  bundle.addfile(item,io.BytesIO(raw));assert identity(p)==before
  members.append(dict(name=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),original_path=str(p)))
with tarfile.open(archive,'r:xz') as bundle:
 assert len(bundle.getmembers())==len({x.name for x in bundle.getmembers()})==len(members)
 for item in members:
  entry=bundle.getmember(item['name']);assert entry.isfile();raw=bundle.extractfile(entry).read()
  assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256'] and raw==files[item['name']].read_bytes()
report=dict(schema_version='shardloom.native_shared_execution_hosted_packet.v1',status='passed',recorded_at=datetime.now(timezone.utc).isoformat(),pr=1571,head=head,merge=merge,synthetic=synthetic,checks_passed=44,source_files_verified=2412,native_total=native['total_passed'],native_library_tests=2958,native_ignored_tests=27,new_native_tests=12,native_public_total=1079,wheel_lanes=3,wheel_tests_per_lane=100,served_responses_verified=16,closeouts=closeouts,primary_jobs=identity(jobs_path),merged_sources=identity(D/'merged-sources-626.json'),served=served,preview_browser=identity(D/'browser/preview-report.json'),production_browser=identity(D/'browser/production-report.json'),local_evidence_index=identity(local_index_path),local_evidence_archives=published_local_files,local_acceptance=expected_acceptance,local_review=identity(review_path),comment_only_bridge=identity(bridge_path),maintainer_decision=identity(decision_path),matched_comparison=identity(comparison_path),matched_comparison_totals=comparison['total_engine_means'],observed_engine_gain_percent=comparison['observed_gain_percent'],material_regression_queries=[],performance_conclusion='The matched comparison is accepted under the explicit later greater-than-3% maintainer bar. The original 5% failure remains unchanged. Local acceptance, exact-head hosted checks, installed wheels, review, merge and deployment verification pass.',archive=identity(archive),members_verified=len(members),members=members,limits=['The matched total is the sum of two-sample per-query means, not one standard Full43 pass.','Browser checks cover the in-app browser, current viewport and mobile navigation/search; no cross-browser claim.','Installed-wheel lanes are CI builds; published 0.6.0 artifacts remain unchanged.','No external-engine fallback or public performance-superiority claim is authorized.'])
target=destination/'native-shared-execution-hosted-2026-10-17.json'
target.open('x').write(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(status='passed',report=str(target),archive=identity(archive),members=len(members),checks=44,served_responses=16)))
