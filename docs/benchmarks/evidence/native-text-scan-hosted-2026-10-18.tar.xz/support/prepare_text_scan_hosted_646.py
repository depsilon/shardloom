"""Bind the retained hosted readers to the measured text-scan source and PR jobs."""
import argparse
import ast
import hashlib
import json
import re
import sys
from pathlib import Path

O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
R = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
D = O/'native-text-scan-hosted-646'
old = O/'native-shared-execution-hosted-626'
read = lambda p: json.loads(Path(p).read_text())
identity = lambda p: dict(path=str(p), bytes=Path(p).stat().st_size, sha256=hashlib.sha256(Path(p).read_bytes()).hexdigest())
save = lambda p, x: Path(p).open('x').write(json.dumps(x, indent=2)+'\n')
parser = argparse.ArgumentParser()
for name in ('head', 'base', 'synthetic', 'jobs_file'):
    parser.add_argument('--'+name.replace('_', '-'), required=True)
parser.add_argument('--pr', type=int, required=True)
parser.add_argument('--run', type=int, required=True)
args = parser.parse_args()
assert all(re.fullmatch('[a-f0-9]{40}', getattr(args, k)) for k in ('head', 'base', 'synthetic'))
assert args.pr > 1571 and args.run > 0 and not D.exists()
sys.path.insert(0, str(O))
import verify_stream_destination_integrated_sources_482 as verifier
verifier.R = R
selected = O/'native-release-source-textscan644.json'
accepted = read(selected)
expected = accepted['source_sha256']
measured = O/'native-text-scan642-source.json'
assert len(expected) == 2415 and read(measured)['source_sha256'] == expected
maps, trees = {}, {}
for kind, revision in [('head', args.head), ('ci_merge', args.synthetic)]:
    mapping, _ = verifier.immutable_source_map(revision)
    assert {p: x['sha256'] for p, x in mapping.items()} == expected
    maps[kind] = verifier.identity_summary(mapping)
    trees[kind] = verifier.git('rev-parse', revision+'^{tree}').decode().strip()
assert len(set(trees.values())) == 1
parents = verifier.git('rev-list', '--parents', '-n', '1', args.synthetic).decode().split()
assert parents == [args.synthetic, args.base, args.head]
coverage = dict(status='passed', head=args.head, base=args.base, ci_merge=args.synthetic,
                trees=trees, source_files=len(expected), source_sha256=expected, source_maps=maps,
                accepted_source=identity(selected), measured_source=identity(measured),
                artifacts=identity(O/'native-release-artifacts-textscan644.json'),
                helper=identity(Path(verifier.__file__)),
                scope='All 2,415 selected sources in the reviewed head and CI merge are byte-identical to measured build 642 and local acceptance 644.')
inventory = read(O/'native-text-scan-test-inventory-645.json')
inventory['head'] = args.head
prior = read(old/'hosted-validation-launch.json')
inventory['documentation_existing_tests'] = prior['test_inventory']['documentation_existing_tests']
assert set(inventory['documentation_existing_tests']) <= set(inventory['release_script_methods'])
assert inventory['native_suite_passed'] == 2967 and inventory['native_ignored'] == 28
for test in inventory['native_new_tests']:
    raw = verifier.git('show', args.head+':'+test['path'])
    assert hashlib.sha256(raw).hexdigest() == test['source_sha256']
    assert 'fn '+test['name']+'(' in raw.decode().splitlines()[test['line']-1]
wanted = {'Python test shard (core)', 'Python test shard (release_scripts)',
          'Rust feature matrix (native_public_surface_tests)', 'Rust feature matrix (native_vortex_tests)',
          'Native Python wheel (py313_macos)', 'Native Python wheel (py313_ubuntu)',
          'Native Python wheel (py310_ubuntu)', 'Website and docs validation'}
jobdoc = read(args.jobs_file)
jobs = {job['id']: job['name'] for job in jobdoc['jobs'] if job['name'] in wanted}
assert len(jobs) == 8 and set(jobs.values()) == wanted
assert all(job['run_id'] == args.run and job['head_sha'] == args.head for job in jobdoc['jobs'] if job['id'] in jobs)
replacements = {
    'native-shared-execution-hosted-626': 'native-text-scan-hosted-646',
    prior['source_verification']['head']: args.head,
    prior['source_verification']['base']: args.base,
    prior['source_verification']['ci_merge']: args.synthetic,
    '39079832491': str(args.run), '1571': str(args.pr), '2412': '2415',
    'groups[0]==(2958,0,27)': 'groups[0]==(2967,0,28)',
    'len(ignored)==27 and sum(x[2] for x in groups)==27': 'len(ignored)==28 and sum(x[2] for x in groups)==28',
    'native_shared_execution': 'native_text_scan_reuse',
}
programs = {}
for key in ('capture_source', 'acceptance_source', 'closeout_wrapper', 'served_source'):
    source = prior[key]
    assert hashlib.sha256(source.encode()).hexdigest() == prior[key+'_sha256']
    for before, after in replacements.items():
        source = source.replace(before, after)
    if key == 'capture_source':
        source, count = re.subn(r'^jobs=.*$', lambda _: 'jobs='+repr(jobs), source, flags=re.M)
        assert count == 1
    if key == 'acceptance_source':
        assert 'groups[0]==(2967,0,28)' in source
        assert 'len(ignored)==28 and sum(x[2] for x in groups)==28' in source
        assert "result['test_count']==626" in source  # Existing Python core inventory is unchanged.
    ast.parse(source)
    programs[key] = source
D.mkdir()
save(D/'pr-sources.json', coverage)
save(D/'test-inventory.json', inventory)
record = dict(programs, source_verification=coverage, test_inventory=inventory,
              template=identity(old/'hosted-validation-launch.json'), job_inventory=identity(Path(args.jobs_file)),
              substitutions=replacements, program_file_created=False)
for key, value in programs.items():
    record[key+'_sha256'] = hashlib.sha256(value.encode()).hexdigest()
save(D/'hosted-validation-launch.json', record)
print(json.dumps(dict(status='prepared', directory=str(D), pr=args.pr, head=args.head, source_files=len(expected), jobs=len(jobs))))
