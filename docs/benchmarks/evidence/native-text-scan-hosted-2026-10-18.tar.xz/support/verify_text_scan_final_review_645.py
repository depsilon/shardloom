"""Bind the final reviewed documentation and evidence to the measured runtime."""
from pathlib import Path
import hashlib, json, subprocess, sys
O=Path("/Users/dylan/LocalData/shardloom/native-python-surface-20261010")
R=Path("/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo")
sys.path[:0]=[str(O),str(R/'scripts')]
from freeze_native_release_298 import sources
read=lambda p:json.loads(Path(p).read_text())
identity=lambda p:dict(path=str(p),bytes=Path(p).stat().st_size,sha256=hashlib.sha256(Path(p).read_bytes()).hexdigest())
selected=O/'native-release-source-textscan644.json'
frozen=read(selected)
assert len(frozen['source_sha256'])==2415 and sources()==frozen['source_sha256']
measured=O/'native-text-scan642-source.json'
assert read(measured)['source_sha256']==frozen['source_sha256']
index_path=R/'docs/benchmarks/evidence/native-text-scan-reuse-2026-10-18.json'
index=read(index_path)
assert index['status']=='passed_local_evidence_packaged'
assert index['member_count']==27981 and len(index['archives'])==5 and index['source_files']==2415
assert index['all_members_reopened'] and index['source_identity_preserved']
for item in [*index['archives'].values(),index['manifest']]:
    path=index_path.parent/item['file']
    assert path.stat().st_size==item['bytes'] and identity(path)['sha256']==item['sha256']
receipts={}
for name in ('native-text-scan-archive-645','native-text-scan-final-docs-645'):
    path=O/(name+'.json');receipt=read(path)
    assert receipt['status']=='passed' and receipt['returncode']==0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert receipt['log_sha256']==identity(O/(name+'.log'))['sha256']
    receipts[name]=identity(path)
docs=O/'native-text-scan-final-doc-results-645.json'
checks=read(docs)
assert checks['status']=='passed' and len(checks['checks'])==16
assert all(c['returncode']==0 for c in checks['checks'])
inventory=read(O/'native-text-scan-test-inventory-645.json')
assert inventory['status']=='passed' and inventory['new_native_test_count']==7
for test in inventory['native_new_tests']:
    assert identity(R/test['path'])['sha256']==test['source_sha256']
subprocess.run(['git','diff','--check'],cwd=R,check=True)
report=dict(status='passed',selected_source_files=2415,selected_source=identity(selected),
 measured_source=identity(measured),exact_runtime_source_identity=True,
 portable_evidence=identity(index_path),
 archive_receipt=receipts['native-text-scan-archive-645'],
 documentation_results=identity(docs),
 documentation_receipt=receipts['native-text-scan-final-docs-645'],
 acceptance=index['acceptance'],
 performance_decision=index['performance_decision'],
 reviewed_boundaries=[
  'Source projection and predicate shape, type and memory admission contain no benchmark-specific routing.',
  'Native pruning and splits remain delegated; sparse masks, dictionary encodings and residual/winner-filter paths preserve provider behavior.',
  'Projection-owned range entries and weak registry handles retire metadata and payload ownership after completion, failure, cancellation or unpolled drop.',
  'Memory reservations precede registry and entry allocation; native decoded buffers retain allocator leases.',
  'Complete nullable text, Unicode, embedded NUL, slices, output order and full values have measured regression coverage.',
  'All 324 paired calls, rejected mechanisms, failed validation attempts and original prospective contracts remain retained.',
  'The greater-than-3% gate was declared before the accepted two-sample matched comparison; no single-pass or external-engine superiority claim.',
  'The final source tree is byte-identical to all 2,415 measured and locally accepted selected sources.',
  'The architecture, phase queue, report and generated website describe the same retained mechanism and bounded claim.'
 ],
 unresolved_local_findings=[],
 remaining_gates=['final-head CI and automated review','three installed-wheel proofs',
                  'preview source and browser checks','authorized merge and production source/browser verification'])
(O/'native-text-scan-final-review-645.json').open('x').write(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(status='passed',selected_source_files=2415,portable_members=index['member_count'],documentation_checks=len(checks['checks']))))
