"""Validate the new reader's schema assumptions against retained complete outputs."""
import ast
import gzip
import hashlib
import json
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
sys.path[:0] = [str(OUT), str(ROOT / 'scripts')]
from review_composition_attribution_419 import bound, equivalent, extract_result, load_reference_packet, report_fields, strict_json


def main():
    plan = strict_json((OUT / 'composition-attribution-plan-419.json').read_text())
    proof_path = OUT / plan['historical_evidence']
    proof = strict_json(proof_path.read_text())
    reference = load_reference_packet(Path(plan['workload']['reference']), ROOT / 'benchmarks/clickbench/queries.sql')
    schemas, checked, rows = {}, 0, 0
    for cohort in proof['cohorts'].values():
        for item in cohort['envelopes']:
            assert bound(item['path']) == {key: item[key] for key in ('path', 'bytes', 'sha256')}
            raw = gzip.decompress(Path(item['path']).read_bytes())
            assert len(raw) == item['raw_bytes'] and hashlib.sha256(raw).hexdigest() == item['raw_sha256']
            envelope = strict_json(raw.decode())
            fields = report_fields(envelope)
            result = extract_result(envelope)
            query = item['query']
            assert equivalent(result, reference['values'][query])
            assert fields['public_workflow_route_id'] == cohort['per_query'][str(query)]['route']
            assert fields['fallback_attempted'] == fields['external_engine_invoked'] == 'false'
            assert fields['execution_resource_declared_memory_bytes'] == str(24 << 30)
            assert fields['execution_resource_declared_max_parallelism'] == '12'
            assert any(c['kind'] == 'native_io_certificate' and c['status'] == 'available'
                for c in envelope['certificates'])
            schema = (fields['result_schema_format'], strict_json(fields['result_schema_json']))
            assert schemas.setdefault(query, schema) == schema
            checked += 1
            rows += len(result)
    assert checked == 387 and len(schemas) == 43
    helpers = [OUT / 'run_composition_attribution_419.py', OUT / 'review_composition_attribution_419.py', Path(__file__)]
    for helper in helpers:
        ast.parse(helper.read_text(), filename=str(helper))
    result = dict(status='passed', checked_complete_historical_outputs=checked,
        checked_result_rows=rows, matching_schema_queries=len(schemas),
        historical_proof=bound(proof_path), helpers=[bound(path) for path in helpers],
        command_record_correction='Static source review found that paired records omit a per-call command field; verify the frozen runner, complete queries and command_template instead.',
        new_comparison_executed=False)
    with (OUT / 'composition-review-contract-420.json').open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({key: result[key] for key in ('status', 'checked_complete_historical_outputs', 'checked_result_rows', 'matching_schema_queries')}))


if __name__ == '__main__':
    main()
