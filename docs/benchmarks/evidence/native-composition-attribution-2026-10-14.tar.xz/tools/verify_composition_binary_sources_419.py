"""Bind retained benchmark executables to the two accepted native source trees."""
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
CASES = [
    ('pre_composition', 'zstd-views-base-386-release.json', 'ed253d1ec74b724215f71f0b410123656e596696'),
    ('composition', 'stream-composition-398-release.json', '5b5cd6a7cb3c88d20046079c46900d9b323b1274'),
]


def bound(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read(path):
    return json.loads(Path(path).read_text())


def native(name):
    return name.endswith('.rs') or name.endswith('Cargo.toml') or name == 'Cargo.lock' or name.startswith(('.cargo/', 'vendor/'))


def main():
    results = []
    process = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=ROOT,
        stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    try:
        for label, manifest_name, commit in CASES:
            manifest_path = OUT / manifest_name
            manifest = read(manifest_path)
            assert manifest['status'] == 'passed'
            source = manifest['source_manifest']
            assert bound(source['path'])['sha256'] == source['sha256']
            source_map = read(source['path'])['source_sha256']
            assert source_map == manifest['source_sha256']
            build = read(manifest['cli']['build_receipt'])
            assert build['status'] == 'passed' and build['returncode'] == 0
            assert build['process_group_drained'] and build['direct_child_reaped']
            assert '--release' in build['command'] and 'release-user-surfaces' in build['command']
            assert bound(manifest['cli']['build_receipt'])['sha256'] == manifest['cli']['build_receipt_sha256']
            assert bound(manifest['cli']['build_log'])['sha256'] == build['log_sha256']
            selected = {name: digest for name, digest in source_map.items() if native(name)}
            checked, mismatches = {}, []
            for name, digest in selected.items():
                process.stdin.write(f'{commit}:{name}\n'.encode())
                process.stdin.flush()
                header = process.stdout.readline().decode().strip().split()
                if len(header) != 3 or header[1] != 'blob':
                    mismatches.append(dict(path=name, error='missing or non-blob', header=header))
                    continue
                count = int(header[2])
                raw = process.stdout.read(count)
                assert len(raw) == count and process.stdout.read(1) == b'\n'
                actual = hashlib.sha256(raw).hexdigest()
                checked[name] = dict(git_blob=header[0], bytes=count, sha256=actual)
                if actual != digest:
                    mismatches.append(dict(path=name, expected=digest, observed=actual))
            results.append(dict(variant=label, accepted_commit=commit,
                accepted_tree=subprocess.check_output(['git', 'rev-parse', commit + '^{tree}'], cwd=ROOT, text=True).strip(),
                manifest=bound(manifest_path), source_manifest=bound(source['path']),
                recorded_binary={key: manifest['cli'][key] for key in ('path', 'bytes', 'sha256')},
                build_receipt=bound(manifest['cli']['build_receipt']), build_log=bound(manifest['cli']['build_log']),
                checked_native_files=len(selected), all_native_files_match=not mismatches,
                native_source_files=checked, mismatches=mismatches,
                non_native_manifest_paths_not_compared=[name for name in source_map if not native(name)]))
    finally:
        process.stdin.close()
        assert process.wait(timeout=30) == 0
    passed = all(result['all_native_files_match'] for result in results)
    result = dict(status='passed' if passed else 'source_mismatch', variants=results,
        verifier=bound(__file__), scope='Every Rust, Cargo, .cargo and vendor file named by each original release source manifest compared to the accepted Git tree. Harness/Python identities are separate; retained binaries must be rehashed before future timing.',
        native_workload_executed=False, executable_rehashed=False)
    with (OUT / 'composition-binary-source-review-419.json').open('x') as output:
        json.dump(result, output, indent=2)
        output.write('\n')
    print(json.dumps(dict(status=result['status'], variants=[
        {key: value[key] for key in ('variant', 'accepted_commit', 'checked_native_files', 'all_native_files_match', 'mismatches')}
        for value in results])))
    assert passed


if __name__ == '__main__':
    main()
