"""Primary verification of the closed comparison inventory and raw timing math."""
import hashlib
import json
import math
from pathlib import Path
import statistics

OUT = Path(__file__).resolve().parent


def read(path):
    return json.loads(Path(path).read_text())


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    before = path.stat()
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    assert before == path.stat(), path
    return dict(path=str(path), bytes=before.st_size, sha256=digest.hexdigest())


def verify(item):
    assert identity(item['path']) == {key: item[key] for key in ('path', 'bytes', 'sha256')}


def same(left, right):
    assert math.isclose(left, right, rel_tol=1e-12, abs_tol=1e-12), (left, right)


def main():
    inventory_path = OUT / 'composition-evidence-inventory-422.json'
    inventory = read(inventory_path)
    assert inventory['status'] == 'complete_mechanical_evidence_inventory'
    members = {row['path']: row for row in inventory['members']}
    excluded = {row['path']: row for row in inventory['exclusions']}
    assert len(members) == len(inventory['members']) and len(excluded) == 3
    assert not set(members) & set(excluded)
    assert len({row['archive_path'] for row in members.values()}) == len(members)
    for row in members.values():
        verify(row)
        name = Path(row['archive_path'])
        assert not name.is_absolute() and '..' not in name.parts
    coverage = inventory['coverage']
    assert coverage['result_root_overlaps'] == []
    assert coverage['selected_unique_files'] == len(members)
    assert coverage['selected_raw_bytes'] == sum(row['bytes'] for row in members.values())
    assert coverage['selected_raw_bytes'] <= 192 << 20
    assert len(coverage['result_directories']) == 5
    for label, record in coverage['result_directories'].items():
        root = Path(record['path'])
        actual = set()
        for path in root.rglob('*'):
            assert not path.is_symlink(), path
            if path.is_dir():
                continue
            assert path.is_file(), path
            actual.add(str(path))
        selected = actual & set(members)
        omitted = actual & set(excluded)
        assert actual == selected | omitted, (label, actual - selected - omitted)
        assert record['selected_count'] == len(selected)
        assert record['excluded_count'] == len(omitted)
        assert record['selected_bytes'] == sum(members[path]['bytes'] for path in selected)
        assert record['excluded_bytes'] == sum(excluded[path]['bytes'] for path in omitted)
    frozen_path = OUT / 'composition-attribution-frozen-419.json'
    frozen = read(frozen_path)
    result_path = OUT / 'composition-attribution-result-419.json'
    result = read(result_path)
    driver = read(OUT / 'composition-attribution-driver-419.json')
    assert result['status'] == driver['status'] == 'passed'
    assert result['total_complete_calls'] == 516
    assert driver['failure'] is None and driver['completed_orders'] == ['forward', 'reverse']
    assert result['frozen'] == driver['frozen'] == identity(frozen_path)
    for item in list(frozen['helpers'].values()) + list(frozen['manifests'].values()) + [
        frozen['plan'], frozen['source_proof'], frozen['source_completeness'],
        frozen['historical'], frozen['prerequisite_acceptance'], frozen['reference'], frozen['queries']]:
        verify(item)
        assert item['path'] in members
    for item in list(frozen['binaries'].values()) + [frozen['source']]:
        row = excluded[item['path']]
        assert row['bytes'] == item['bytes'] and row['sha256_from_manifest'] == item['sha256']
        assert Path(item['path']).stat().st_size == item['bytes']
    source_proof = read(frozen['source_proof']['path'])
    expected_source = {(variant['accepted_commit'], relative): value
        for variant in source_proof['variants']
        for relative, value in variant['native_source_files'].items()}
    source_rows = inventory['source_map_identity_records']
    assert len(source_rows) == len(expected_source) == 3506
    for row in source_rows:
        original = expected_source[(row['accepted_commit'], row['relative_path'])]
        assert all(row[key] == original[key] for key in ('git_blob', 'bytes', 'sha256'))
    limits = read(frozen['plan']['path'])['per_query_thresholds']
    orders, breaches = [], {}
    for order, embedded in zip(('forward', 'reverse'), result['cohorts'], strict=True):
        review = read(OUT / f'composition-attribution-{order}-review-419.json')
        assert review == embedded and review['complete_calls'] == 258
        assert review['complete_result_rows'] == 2286
        verify(review['summary'])
        verify(review['receipt'])
        receipt = read(review['receipt']['path'])
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert identity(Path(review['receipt']['path']).with_suffix('.log'))['sha256'] == receipt['log_sha256']
        summary = read(review['summary']['path'])
        rows = {(row['query'], row['run'], row['role']): row for row in summary['records']}
        expected = {(query, run, role) for query in range(1, 44)
                    for run in range(1, 4) for role in ('control', 'candidate')}
        assert set(rows) == expected and len(summary['records']) == 258
        assert all(row['passed'] and row['validation'] == 'complete_values'
                   and row['returncode'] == 0 and not row['guard_failures'] for row in rows.values())
        per_query, order_breaches = [], set()
        for query in range(1, 44):
            medians = {}
            for role in ('control', 'candidate'):
                values = [rows[(query, run, role)] for run in range(1, 4)]
                medians[role] = {
                    'elapsed_seconds': statistics.median(row['seconds'] for row in values),
                    'cpu_seconds': statistics.median(row['user_cpu_seconds'] + row['system_cpu_seconds'] for row in values),
                    'peak_rss_bytes': statistics.median(row['native_peak_rss_bytes'] for row in values),
                }
                for key, value in medians[role].items():
                    assert math.isfinite(value) and value >= 0
                    same(value, review['per_query'][query - 1]['medians'][role][key])
            flags = {}
            for metric, key, absolute_key in (
                ('elapsed', 'elapsed_seconds', 'elapsed_absolute_seconds'),
                ('cpu', 'cpu_seconds', 'cpu_absolute_seconds'),
                ('rss', 'peak_rss_bytes', 'rss_absolute_bytes'),
            ):
                control, candidate = medians['control'][key], medians['candidate'][key]
                flags[metric] = candidate - control > max(limits[metric + '_relative'] * control, limits[absolute_key])
                assert flags[metric] == review['per_query'][query - 1]['breaches'][metric]
                if flags[metric]:
                    order_breaches.add((query, metric))
            per_query.append(dict(query=query, medians=medians, breaches=flags))
        for role in ('control', 'candidate'):
            selected = [row for row in rows.values() if row['role'] == role]
            calculated = {
                'all_129_call_seconds': sum(row['seconds'] for row in selected),
                'sum_of_query_minima_seconds': sum(min(rows[(q, n, role)]['seconds'] for n in range(1, 4)) for q in range(1, 44)),
                'sum_of_query_medians_seconds': sum(row['medians'][role]['elapsed_seconds'] for row in per_query),
                'total_child_cpu_seconds': sum(row['user_cpu_seconds'] + row['system_cpu_seconds'] for row in selected),
                'largest_process_rss_bytes': max(row['native_peak_rss_bytes'] for row in selected),
            }
            for key, value in calculated.items():
                same(value, review['totals'][role][key])
        breaches[order] = order_breaches
        orders.append(dict(order=order, totals=review['totals'], per_query=per_query,
                           single_order_breaches=sorted(order_breaches)))
    assert not breaches['forward'] & breaches['reverse']
    assert result['repeated_metric_increases'] == [] and not result['historical_cause_established']
    assert result['outcome'] == 'historical_increase_not_reproduced_under_declared_thresholds'
    output = OUT / 'composition-evidence-primary-422.json'
    with output.open('x') as stream:
        json.dump(dict(status='passed_complete_inventory_and_independent_timing_math',
            inventory=identity(inventory_path), verifier=identity(__file__),
            result=identity(result_path), frozen=identity(frozen_path),
            complete_calls=516, complete_result_rows=4572,
            source_identity_records=3506, complete_directory_count=5,
            selected_files=len(members), selected_bytes=coverage['selected_raw_bytes'],
            orders=orders, repeated_metric_increases=[], historical_cause_established=False,
            limitations='Recomputes raw-record timing statistics and verifies complete inventory bytes. The original frozen reviewer separately reopens all result envelopes, reference values, schemas, routes and timing companions. Large input and executable payloads are not rehashed by this inventory check; the closed comparison driver verifies them.'),
            stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(output)


if __name__ == '__main__':
    main()
