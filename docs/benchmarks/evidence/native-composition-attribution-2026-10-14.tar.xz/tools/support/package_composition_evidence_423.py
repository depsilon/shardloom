"""Package the accepted, mechanically closed composition attribution evidence.

Preparation only: this helper is deliberately not executed here. It packages
the accepted inventory verbatim, applies the existing local storage guards,
and reopens every archive member and source identity before atomic publication.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import tarfile

from package_selection_acceptance_409 import Members, need, sha_file, sha_stream, verify

OUT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
REPO = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
UAT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
INVENTORY_PATH = OUT / 'composition-evidence-inventory-422.json'
INVENTORY_HELPER = OUT / 'inventory_composition_evidence_422.py'
PRIMARY_PATH = OUT / 'composition-evidence-primary-422.json'
PRIMARY_HELPER = OUT / 'verify_composition_evidence_422.py'
RESULT_PATH = OUT / 'composition-attribution-result-419.json'
FROZEN_PATH = OUT / 'composition-attribution-frozen-419.json'
BASE = '22b2cde04973ce4462517d73fe67b5f7a1e8177c'
OUTPUTS = tuple(OUT / ('composition-attribution-evidence-423.' + suffix)
                for suffix in ('tar.xz', 'manifest.json', 'verification.json'))
PARTIALS = tuple(path.with_name('.' + path.name + '.partial') for path in OUTPUTS)
LIMIT = 192 << 20
GIB, MIB = 1024 ** 3, 1024 ** 2


def read(path: Path):
    return json.loads(path.read_text())


def add(path: Path, archive_path: str, role: str,
        expected_sha: str | None = None, expected_size: int | None = None):
    return MEMBERS.add(path, archive_path, 'evidence', path.parent, role,
                       expected_sha, expected_size)


def add_report(name: str, role: str = 'accepted composition attribution evidence'):
    path = OUT / name
    return add(path, 'acceptance/' + name, role)


def check_receipt(path: Path, prefix: str, expected_status: str = 'passed'):
    receipt = read(path)
    need(receipt.get('status') == expected_status and receipt.get('returncode') == 0
         and receipt.get('timed_out') is False
         and receipt.get('process_group_drained') is True
         and receipt.get('direct_child_reaped') is True,
         f'guard receipt did not pass cleanly: {path}')
    MEMBERS.add(path, f'{prefix}/{path.name}', 'evidence', path.parent,
                'guard receipt; failures retained')
    # Bind receipts to the retained original log by exact digest; the first
    # inventory guard's log has its own historical filename.
    candidates = (path.with_suffix('.log'),
        OUT / 'composition-evidence-inventory-422.log',
        OUT / 'composition-evidence-inventory-run-422.log',
        OUT / 'composition-evidence-primary-run-422.log')
    matching = []
    for candidate in candidates:
        if candidate.is_file() and not candidate.is_symlink():
            try:
                verify(candidate, receipt['log_sha256'])
                matching.append(candidate)
            except ValueError:
                pass
    need(bool(matching), f'no retained log matches guard receipt: {path}')
    log_path = matching[0]
    MEMBERS.add(log_path, f'{prefix}/{log_path.name}', 'evidence', log_path.parent,
                'guard log matching receipt SHA-256', receipt['log_sha256'])
    return receipt


def main():
    for path in (*OUTPUTS, *PARTIALS):
        need(not path.exists() and not path.is_symlink(), f'output exists: {path}')

    inventory = read(INVENTORY_PATH)
    primary = read(PRIMARY_PATH)
    need(inventory.get('status') == 'complete_mechanical_evidence_inventory',
         'accepted inventory is incomplete')
    coverage = inventory['coverage']
    need(coverage['selected_unique_files'] == primary['selected_files'] == 1711
         and coverage['selected_raw_bytes'] == primary['selected_bytes'] <= LIMIT,
         'inventory and primary selected counts/bytes disagree')
    need(primary['status'] == 'passed_complete_inventory_and_independent_timing_math'
         and primary['complete_calls'] == coverage['paired_total_calls'] == 516
         and primary['complete_result_rows'] == 4572
         and primary['complete_directory_count'] == len(coverage['result_directories']) == 5
         and primary['source_identity_records'] == len(inventory['source_map_identity_records']) == 3506,
         'primary completeness gate failed')
    need(coverage['paired_orders'] == ['forward', 'reverse']
         and coverage['paired_query_count_per_order'] == 43
         and coverage['paired_calls_per_order'] == 258
         and coverage['paired_tar_archives_per_order'] == {'forward': 43, 'reverse': 43},
         'both complete 43-query paired orders are not present')
    need(all(item['complete_scan'] and item['excluded_count'] == 0
             for item in coverage['result_directories'].values())
         and coverage['result_root_overlaps'] == []
         and coverage['selected_exclusion_overlap'] == 0,
         'one or more result trees are not closed')
    need(primary['historical_cause_established'] is False,
         'historical evidence must not claim causality')

    frozen = read(FROZEN_PATH)
    result = read(RESULT_PATH)
    need(result.get('status') in {'complete', 'passed'} and frozen,
         'frozen attribution result is unavailable')
    timing_primary_path = OUT / 'composition-timing-primary-419.json'
    timing_primary = read(timing_primary_path)
    need(frozen.get('historical') == dict(path=str(timing_primary_path),
         bytes=timing_primary_path.stat().st_size,
         sha256=sha_file(timing_primary_path)[1]),
         'frozen historical timing-primary identity does not match')
    cohorts = timing_primary.get('cohorts', {})
    cohort_names = {'pre_composition', 'composition', 'selection_resources'}
    need(set(cohorts) == cohort_names and all(cohorts[name]['calls'] == 129
         for name in cohort_names),
         'three complete historical Full43 cohort totals are not present')
    need(len(primary['orders']) == 2
         and {entry['order'] for entry in primary['orders']} == {'forward', 'reverse'},
         'independently recomputed order totals are incomplete')
    historical_trees = []
    for key in ('historical-pre_composition', 'historical-selection_resources',
                'historical-composition'):
        tree = coverage['result_directories'][key]
        historical_trees.append(dict(name=key, path=tree['path'],
            files=tree['selected_count'], bytes=tree['selected_bytes']))
    need(len(historical_trees) == 3, 'three historical result trees are not represented')
    historical_totals = [dict(name=name, calls=cohorts[name]['calls'],
        all_129_seconds=cohorts[name]['all_129_seconds'],
        sum_of_query_minima_seconds=cohorts[name]['sum_of_query_minima_seconds'],
        sum_of_query_medians_seconds=cohorts[name]['sum_of_query_medians_seconds'])
        for name in ('pre_composition', 'composition', 'selection_resources')]

    global MEMBERS
    MEMBERS = Members()
    exclusions = list(inventory['exclusions'])
    # Preserve the inventory's exact member names and identities. Do not walk or
    # broaden its five closed result roots during packaging.
    for item in inventory['members']:
        MEMBERS.add(Path(item['path']), item['archive_path'], 'inventory',
                    Path(item['path']).parent, item['category'],
                    item['sha256'], item['bytes'])

    inventory_bound = primary['inventory']
    need(Path(inventory_bound['path']) == INVENTORY_PATH,
         'primary report references a different inventory')
    for path, logical, role, identity in (
        (INVENTORY_PATH, 'acceptance/composition-evidence-inventory-422.json',
         'accepted 1,711-member inventory', inventory_bound),
        (INVENTORY_HELPER, 'tools/inventory_composition_evidence_422.py',
         'inventory generator', None),
        (PRIMARY_PATH, 'acceptance/composition-evidence-primary-422.json',
         'independent inventory and timing math report', None),
        (PRIMARY_HELPER, 'tools/verify_composition_evidence_422.py',
         'independent primary verifier', primary['verifier']),
    ):
        MEMBERS.add(path, logical, 'evidence', path.parent, role,
                    identity.get('sha256') if identity else None,
                    identity.get('bytes') if identity else None)

    support_paths = (
        Path(__file__).resolve(),
        OUT / 'package_selection_acceptance_409.py',
        REPO / 'scripts/local_uat_storage.py',
        Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py'),
        Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'),
    )
    for path in support_paths:
        MEMBERS.add(path, 'tools/support/' + path.name, 'support', path.parent,
                    'packager, local storage guard, or process guard source')

    # Retain the original evidence chain and source review tools. The accepted
    # Git-tree identities are recorded, but current working-tree source and
    # retained release executable payloads are never read or rehashed here.
    reports = (
        'composition-attribution-result-419.json',
        'composition-attribution-frozen-419.json',
        'composition-attribution-plan-419.json',
        'composition-attribution-driver-419.json',
        'composition-attribution-forward-419.json',
        'composition-attribution-reverse-419.json',
        'composition-attribution-forward-review-419.json',
        'composition-attribution-reverse-review-419.json',
        'composition-timing-inventory-419.json',
        'composition-timing-primary-419.json',
        'composition-binary-source-completeness-419.json',
        'composition-binary-source-review-419.json',
        'composition-review-contract-420.json',
        'composition-evidence-inventory-run-422.json',
        'composition-evidence-primary-run-422.json',
        'composition-evidence-inventory-first-guard-422.json',
    )
    for name in reports:
        add_report(name)
    for name in ('verify_composition_binary_sources_419.py',
                 'check_composition_review_contract_420.py',
                 'verify_composition_inventory_419.py',
                 'review_composition_attribution_419.py',
                 'run_composition_attribution_419.py'):
        path = OUT / name
        add(path, 'tools/' + name, 'source review or frozen runner helper')

    # Original inventory/primary guards and the first, now separately named,
    # guard receipt are retained with their exact paired logs.
    guard_paths = (
        OUT / 'composition-evidence-inventory-first-guard-422.json',
        OUT / 'composition-evidence-inventory-run-422.json',
        OUT / 'composition-evidence-primary-run-422.json',
    )
    guard_rows = [check_receipt(path, 'guards') for path in guard_paths]
    # Preserve the exact original inventory log involved in the path collision.
    collision_log = OUT / 'composition-evidence-inventory-422.log'
    add(collision_log, 'guards/composition-evidence-inventory-422.log',
        'original inventory collision diagnostic log; preserved as historical evidence')

    for record in (primary['result'], primary['frozen']):
        path = Path(record['path'])
        MEMBERS.add(path, 'acceptance/' + path.name, 'evidence', path.parent,
                    'frozen result or workload identity', record['sha256'], record['bytes'])
    # Validate independent historical protocol review and binary/source review.
    binary_review = read(OUT / 'composition-binary-source-review-419.json')
    contract = read(OUT / 'composition-review-contract-420.json')
    need(binary_review['status'] == 'passed' and not binary_review['native_workload_executed']
         and not binary_review['executable_rehashed'],
         'source-only binary review boundary is not preserved')
    need(contract['status'] == 'passed' and contract['matching_schema_queries'] == 43
         and not contract['new_comparison_executed'],
         'frozen historical review contract did not pass')

    ordered = sorted(MEMBERS.paths.values(), key=lambda item: item.name)
    need(len({item.name for item in ordered}) == len(ordered), 'archive path collision')
    raw_bytes = sum(item.size for item in ordered)
    need(raw_bytes <= LIMIT, 'archive exceeds 192 MiB raw-input budget')
    sys.path.insert(0, str(REPO / 'scripts'))
    from local_uat_storage import check_budgets, require_local_path
    require_local_path(OUT, Path.home(), sys.platform)
    storage = check_budgets(OUT, OUTPUTS[0], OUT / 'logs', min_free_bytes=12 * GIB,
        reserve_bytes=raw_bytes + 64 * MIB, max_workspace_bytes=100 * GIB,
        max_log_bytes=1024 * MIB)

    created, published = [], []
    try:
        with PARTIALS[0].open('xb') as output:
            created.append(PARTIALS[0])
            with tarfile.open(fileobj=output, mode='w:xz', preset=6,
                              format=tarfile.PAX_FORMAT) as archive:
                for item in ordered:
                    verify(item.path, item.digest, item.size)
                    info = tarfile.TarInfo(item.name)
                    info.size, info.mode, info.mtime = item.size, 0o644, 0
                    with item.path.open('rb') as stream:
                        archive.addfile(info, stream)
                    verify(item.path, item.digest, item.size)
        seen = set()
        with tarfile.open(PARTIALS[0], mode='r|xz') as archive:
            for entry in archive:
                need(entry.isfile() and entry.name in MEMBERS.names and entry.name not in seen,
                     f'invalid archive member: {entry.name}')
                item = MEMBERS.paths[MEMBERS.names[entry.name]]
                stream = archive.extractfile(entry)
                need(stream is not None and sha_stream(stream) == (item.size, item.digest),
                     f'archive bytes mismatch: {entry.name}')
                seen.add(entry.name)
        need(seen == set(MEMBERS.names), 'archive membership differs from accepted inputs')
        for item in ordered:
            verify(item.path, item.digest, item.size)

        archive_size, archive_digest = sha_file(PARTIALS[0])
        manifest = dict(status='passed', kind='composition_attribution_evidence',
            base_commit=BASE, archive=dict(path=str(OUTPUTS[0]), bytes=archive_size,
            sha256=archive_digest), member_count=len(ordered), raw_bytes=raw_bytes,
            raw_limit_bytes=LIMIT,
            members=[dict(path=str(item.path), archive_path=item.name, bytes=item.size,
                          sha256=item.digest, roles=item.roles) for item in ordered],
            inventory=dict(path=str(INVENTORY_PATH), selected_files=primary['selected_files'],
                selected_bytes=primary['selected_bytes'], paired_calls=primary['complete_calls'],
                paired_orders=coverage['paired_orders'], paired_queries_per_order=43,
                complete_result_rows=primary['complete_result_rows'],
                complete_directory_count=primary['complete_directory_count'],
                source_identity_records=primary['source_identity_records']),
            historical_trees=historical_trees, historical_totals=historical_totals,
            order_totals=[dict(order=row['order'], totals=row['totals']) for row in primary['orders']],
            repeated_metric_increases=primary['repeated_metric_increases'],
            source_map_identity_records=inventory['source_map_identity_records'],
            exclusions=exclusions, guard_receipts=guard_rows,
            storage=storage, all_members_reopened=True,
            historical_cause_established=False, performance_claim_allowed=False,
            limitations=primary['limitations'])
        encoded = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
        verification = dict(status='passed', all_members_reopened=True,
            member_count=len(seen), archive_bytes=archive_size,
            archive_sha256=archive_digest,
            manifest_sha256=hashlib.sha256(encoded).hexdigest())
        for temporary, value in zip(PARTIALS[1:],
            (encoded, (json.dumps(verification, indent=2, sort_keys=True) + '\n').encode()),
            strict=True):
            with temporary.open('xb') as stream:
                created.append(temporary)
                stream.write(value)
        for temporary, output in zip(PARTIALS, OUTPUTS, strict=True):
            os.link(temporary, output)
            published.append(output)
            temporary.unlink()
            created.remove(temporary)
        print(json.dumps(dict(status='passed', archive=str(OUTPUTS[0]),
            members=len(seen), archive_bytes=archive_size, archive_sha256=archive_digest,
            raw_bytes=raw_bytes)), flush=True)
    except BaseException:
        for path in published:
            path.unlink(missing_ok=True)
        raise
    finally:
        for path in created:
            path.unlink(missing_ok=True)


if __name__ == '__main__':
    main()
