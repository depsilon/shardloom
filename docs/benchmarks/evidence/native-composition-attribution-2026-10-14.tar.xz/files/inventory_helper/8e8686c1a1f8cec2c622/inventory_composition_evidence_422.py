#!/usr/bin/env python3
"""Inventory the completed composition-attribution evidence without changing inputs."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import stat
import sys
from pathlib import Path, PurePosixPath
from urllib.parse import quote


OUT = Path("/Users/dylan/LocalData/shardloom/native-python-surface-20261010")
REPO = Path("/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo")
OUTPUT = OUT / "composition-evidence-inventory-422.json"
MAX_SELECTED_BYTES = 192 * 1024 * 1024
ORDERS = ("forward", "reverse")
HISTORICAL = ("pre_composition", "composition", "selection_resources")


def fail(message: str) -> None:
    raise RuntimeError(message)


def path_fingerprint(path: Path) -> tuple[int, int, int, int, int]:
    info = path.lstat()
    if stat.S_ISLNK(info.st_mode):
        fail(f"symlink is not allowed: {path}")
    if not stat.S_ISREG(info.st_mode):
        fail(f"not a regular file: {path}")
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def checked_absolute(path_value: str | Path) -> Path:
    path = Path(path_value)
    if not path.is_absolute():
        fail(f"expected absolute path: {path}")
    # Reject symlinked parent components as well as a symlink at the leaf.
    for parent in reversed(path.parents):
        if parent.exists() and parent.is_symlink():
            fail(f"symlinked path component: {parent}")
    if path.is_symlink():
        fail(f"symlink is not allowed: {path}")
    return path


def digest_file(path: Path) -> str:
    before = path_fingerprint(path)
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    if path_fingerprint(path) != before:
        fail(f"file changed while hashing: {path}")
    return h.hexdigest()


def read_json(path: Path) -> dict:
    if path.stat().st_size > 16 * 1024 * 1024:
        fail(f"JSON input unexpectedly large: {path}")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        fail(f"cannot read JSON {path}: {error}")
    if not isinstance(value, dict):
        fail(f"JSON root is not an object: {path}")
    return value


def safe_segment(value: str) -> str:
    if value in ("", ".", ".."):
        fail(f"unsafe archive path component: {value!r}")
    return quote(value, safe="-._~")


class Inventory:
    def __init__(self) -> None:
        self.members: dict[Path, dict] = {}
        self.exclusions: dict[Path, dict] = {}
        self.archive_paths: dict[str, Path] = {}
        self.before: dict[Path, tuple[int, int, int, int, int]] = {}
        self.tree_files: dict[str, dict[Path, tuple[int, int, int, int, int]]] = {}
        self.directory_coverage: dict[str, dict] = {}
        self.selected_bytes = 0

    def _canonical(self, path_value: str | Path) -> Path:
        path = checked_absolute(path_value)
        if not path.exists():
            fail(f"missing evidence file: {path}")
        return path.resolve(strict=True)

    def _archive_path(self, path: Path, category: str, tree: str | None = None, relative: str | None = None) -> str:
        if tree is not None:
            if relative is None:
                fail("tree member is missing its relative path")
            parts = PurePosixPath(relative).parts
            if not parts or any(part in ("", ".", "..") for part in parts):
                fail(f"unsafe tree relative path: {relative!r}")
            tail = "/".join(safe_segment(part) for part in parts)
            return f"trees/{safe_segment(tree)}/{tail}"
        token = hashlib.sha256(os.fsencode(str(path))).hexdigest()[:20]
        return f"files/{safe_segment(category)}/{token}/{safe_segment(path.name)}"

    def add_selected(
        self,
        path_value: str | Path,
        category: str,
        role: str,
        expected: dict | None = None,
        tree: str | None = None,
        relative: str | None = None,
    ) -> dict:
        path = self._canonical(path_value)
        if path in self.exclusions:
            fail(f"selected file is also excluded: {path}")
        previous = self.members.get(path)
        if previous is not None:
            if expected:
                if expected.get("bytes") != previous["bytes"] or expected.get("sha256") != previous["sha256"]:
                    fail(f"duplicate reference disagrees with selected identity: {path}")
            if role not in previous["roles"]:
                previous["roles"].append(role)
                previous["roles"].sort()
            return previous
        identity = path_fingerprint(path)
        size = identity[2]
        if self.selected_bytes + size > MAX_SELECTED_BYTES:
            fail(f"selected byte ceiling exceeded before hashing {path}")
        actual_sha = digest_file(path)
        if expected:
            if expected.get("bytes") != size or expected.get("sha256") != actual_sha:
                fail(f"declared identity mismatch for {path}")
        archive_path = self._archive_path(path, category, tree, relative)
        collision = self.archive_paths.get(archive_path)
        if collision is not None and collision != path:
            fail(f"archive path collision: {archive_path} for {collision} and {path}")
        record = {
            "path": str(path),
            "archive_path": archive_path,
            "bytes": size,
            "sha256": actual_sha,
            "category": category,
            "roles": [role],
        }
        self.members[path] = record
        self.archive_paths[archive_path] = path
        self.before[path] = identity
        self.selected_bytes += size
        return record

    def add_excluded(self, identity: dict, category: str, reason: str, role: str) -> dict:
        path = self._canonical(identity["path"])
        if path in self.members:
            fail(f"selected file is also excluded: {path}")
        fingerprint = path_fingerprint(path)
        if fingerprint[2] != identity["bytes"]:
            fail(f"excluded file size differs from recorded identity: {path}")
        expected_sha = identity.get("sha256")
        if not isinstance(expected_sha, str) or len(expected_sha) != 64:
            fail(f"missing exact SHA-256 identity for exclusion: {path}")
        existing = self.exclusions.get(path)
        if existing:
            if existing["bytes"] != fingerprint[2] or existing["sha256_from_manifest"] != expected_sha:
                fail(f"duplicate exclusion has conflicting identity: {path}")
            existing["roles"].append(role)
            existing["roles"] = sorted(set(existing["roles"]))
            return existing
        record = {
            "path": str(path),
            "bytes": fingerprint[2],
            "sha256_from_manifest": expected_sha,
            "category": category,
            "reason": reason,
            "identity_source": identity.get("identity_source", role),
            "roles": [role],
        }
        self.exclusions[path] = record
        self.before[path] = fingerprint
        return record

    def scan_tree(self, root_value: str | Path, label: str, excluded_by_path: dict[Path, dict]) -> dict:
        root = self._canonical(root_value)
        if not root.is_dir():
            fail(f"evidence root is not a directory: {root}")
        observed: dict[Path, tuple[int, int, int, int, int]] = {}
        local_selected: set[Path] = set()
        local_excluded: set[Path] = set()
        dirs = [root]
        while dirs:
            directory = dirs.pop()
            with os.scandir(directory) as entries:
                sorted_entries = sorted(entries, key=lambda entry: entry.name)
            for entry in sorted_entries:
                path = Path(entry.path)
                if entry.is_symlink():
                    fail(f"symlink in evidence directory {label}: {path}")
                if entry.is_dir(follow_symlinks=False):
                    dirs.append(path)
                    continue
                if not entry.is_file(follow_symlinks=False):
                    fail(f"non-regular entry in evidence directory {label}: {path}")
                canonical = path.resolve(strict=True)
                fingerprint = path_fingerprint(canonical)
                observed[canonical] = fingerprint
                relative = canonical.relative_to(root).as_posix()
                known_exclusion = excluded_by_path.get(canonical)
                if known_exclusion:
                    self.add_excluded(known_exclusion["identity"], known_exclusion["category"], known_exclusion["reason"], label)
                    local_excluded.add(canonical)
                else:
                    self.add_selected(canonical, "result_directory_member", label, tree=label, relative=relative)
                    local_selected.add(canonical)
        self.tree_files[label] = observed
        self.directory_coverage[label] = {
            "path": str(root),
            "complete_scan": True,
            "selected_count": len(local_selected),
            "selected_bytes": sum(observed[p][2] for p in local_selected),
            "excluded_count": len(local_excluded),
            "excluded_bytes": sum(observed[p][2] for p in local_excluded),
        }
        return self.directory_coverage[label]

    def verify_unchanged(self) -> None:
        for path, original in self.before.items():
            if path_fingerprint(path) != original:
                fail(f"input stat identity changed during inventory: {path}")
            if path in self.members and digest_file(path) != self.members[path]["sha256"]:
                fail(f"selected input hash changed during inventory: {path}")
        for label, initial in self.tree_files.items():
            current: dict[Path, tuple[int, int, int, int, int]] = {}
            root = Path(self.directory_coverage[label]["path"])
            dirs = [root]
            while dirs:
                directory = dirs.pop()
                with os.scandir(directory) as entries:
                    for entry in entries:
                        path = Path(entry.path)
                        if entry.is_symlink():
                            fail(f"symlink appeared during inventory: {path}")
                        if entry.is_dir(follow_symlinks=False):
                            dirs.append(path)
                        elif entry.is_file(follow_symlinks=False):
                            canonical = path.resolve(strict=True)
                            current[canonical] = path_fingerprint(canonical)
                        else:
                            fail(f"non-regular entry appeared during inventory: {path}")
            if current != initial:
                fail(f"directory membership or file identity changed during inventory: {label}")


def exact_ref(inv: Inventory, rec: dict, category: str, role: str) -> Path:
    if not isinstance(rec, dict) or not {"path", "bytes", "sha256"} <= set(rec):
        fail(f"invalid file identity reference for {role}")
    path = Path(rec["path"])
    inv.add_selected(path, category, role, expected=rec)
    return path.resolve(strict=True)


def declared_exclusion(inv: Inventory, record: dict, category: str, reason: str, role: str) -> None:
    identity = dict(record)
    identity["identity_source"] = role
    inv.add_excluded(identity, category, reason, role)


def source_identity_records(source_review: dict) -> list[dict]:
    records = []
    for variant in source_review["variants"]:
        variant_name = variant["variant"]
        commit = variant["accepted_commit"]
        for relative, identity in sorted(variant["native_source_files"].items()):
            records.append({
                "path": f"git-tree:{commit}/{relative}",
                "relative_path": relative,
                "variant": variant_name,
                "accepted_commit": commit,
                "git_blob": identity["git_blob"],
                "bytes": identity["bytes"],
                "sha256": identity["sha256"],
                "reason": "preserve accepted source-manifest identity; source bytes are not copied or reread",
            })
    return records


def status_gate(frozen: dict, plan: dict, source_review: dict, completeness: dict, primary: dict, history: dict, prerequisite: dict) -> None:
    assert frozen["status"] == "frozen_before_any_attribution_timing"
    assert frozen["native_comparison_executed"] is False
    assert plan["status"] == "declared_before_new_timing"
    assert source_review["status"] == "passed" and source_review["native_workload_executed"] is False
    assert source_review["executable_rehashed"] is False
    assert completeness["status"] == "passed" and completeness["exact_native_path_sets_equal"] is True
    assert primary["status"] == "passed_literal_inventory_and_route_readback"
    assert primary["native_queries_executed"] is False and primary["large_input_or_binary_rehashed"] is False
    assert history["status"] == "COMPLETE"
    assert history["query_id_count"] == 43 and history["unique_call_keys_per_cohort"] is True
    assert history["call_duration_count"] == 387
    assert history["per_call_timing_companion_count"] == 387
    assert history["per_cohort_call_duration_count"] == 129
    assert prerequisite["status"] == "passed" and prerequisite["sources_unchanged"] is True


def run(completed_result_path: Path) -> None:
    if OUTPUT.exists() or OUTPUT.is_symlink():
        fail(f"refusing to replace inventory output: {OUTPUT}")
    completed_result_path = checked_absolute(completed_result_path)
    if completed_result_path.name != "composition-attribution-result-419.json":
        fail("completed run argument must be composition-attribution-result-419.json")
    inv = Inventory()

    # Freeze and the linked, already-passed input records.
    frozen_path = OUT / "composition-attribution-frozen-419.json"
    inv.add_selected(frozen_path, "frozen_plan", "frozen_attribution_record")
    frozen = read_json(frozen_path)
    plan_path = exact_ref(inv, frozen["plan"], "attribution_plan", "frozen.plan")
    source_proof_path = exact_ref(inv, frozen["source_proof"], "binary_source_review", "frozen.source_proof")
    completeness_path = exact_ref(inv, frozen["source_completeness"], "source_completeness", "frozen.source_completeness")
    primary_path = exact_ref(inv, frozen["historical"], "historical_primary", "frozen.historical")
    prerequisite_path = exact_ref(inv, frozen["prerequisite_acceptance"], "prerequisite_acceptance", "frozen.prerequisite_acceptance")
    exact_ref(inv, frozen["reference"], "reference_packet", "frozen.reference")
    exact_ref(inv, frozen["queries"], "query_definitions", "frozen.queries")
    plan = read_json(plan_path)
    source_review = read_json(source_proof_path)
    completeness = read_json(completeness_path)
    primary = read_json(primary_path)
    prerequisite = read_json(prerequisite_path)
    exact_ref(inv, primary["inventory"], "historical_timing_inventory", "historical.inventory")
    history = read_json(Path(primary["inventory"]["path"]))
    status_gate(frozen, plan, source_review, completeness, primary, history, prerequisite)
    exact_ref(inv, primary["original_inventory"], "historical_inventory_original", "historical.original_inventory")
    exact_ref(inv, primary["verifier"], "historical_inventory_verifier", "historical.verifier")
    for document in history["source_documents"]:
        exact_ref(inv, document, "historical_source_document", "historical.source_documents")
    # Also preserve the original six caller-designated compact JSON inputs if they differ
    # from a link above; roles are merged instead of duplicating physical members.
    inv.add_selected(OUT / "composition-attribution-plan-419.json", "attribution_plan", "caller_input")
    inv.add_selected(OUT / "composition-timing-primary-419.json", "historical_primary", "caller_input")
    inv.add_selected(OUT / "composition-timing-inventory-419.json", "historical_timing_inventory", "caller_input")
    inv.add_selected(OUT / "composition-binary-source-review-419.json", "binary_source_review", "caller_input")
    inv.add_selected(completeness_path, "source_completeness", "caller_input")

    # Frozen helpers have complete source identities; check their bytes against the freeze.
    helper_paths = set()
    for helper_key, identity in sorted(frozen["helpers"].items()):
        if helper_key != identity["path"]:
            fail(f"frozen helper key/path disagreement: {helper_key}")
        helper_paths.add(Path(identity["path"]).resolve(strict=False))
        exact_ref(inv, identity, "frozen_helper", "frozen.helpers")
    verifier_path = Path(primary["verifier"]["path"]).resolve(strict=False)
    helper_path = Path(__file__).resolve(strict=True)
    if helper_path in helper_paths or helper_path == verifier_path:
        fail("inventory helper path collides with an existing helper")
    inv.add_selected(helper_path, "inventory_helper", "composition_evidence_inventory_helper")

    # The two retained binary artifacts and the 15.7-GB input are manifest-only exclusions.
    excluded_by_path: dict[Path, dict] = {}
    for role, binary in sorted(frozen["binaries"].items()):
        record = dict(binary)
        record["identity_source"] = "composition-attribution-frozen-419.json:binaries"
        declared_exclusion(inv, record, "release_executable", "large executable payload excluded; exact recorded size/SHA-256 retained without reading payload", f"frozen.binary.{role}")
        excluded_by_path[Path(binary["path"]).resolve(strict=False)] = {
            "identity": record, "category": "release_executable",
            "reason": "large executable payload excluded; exact recorded size/SHA-256 retained without reading payload",
        }
    source_data = dict(frozen["source"])
    source_data["identity_source"] = "composition-attribution-frozen-419.json:source"
    declared_exclusion(inv, source_data, "large_input_data", "15.7-GB Vortex input excluded; exact frozen identity retained without reading payload", "frozen.source")
    excluded_by_path[Path(frozen["source"]["path"]).resolve(strict=False)] = {
        "identity": source_data, "category": "large_input_data",
        "reason": "15.7-GB Vortex input excluded; exact frozen identity retained without reading payload",
    }

    # Retain the native source maps as record identities, never by opening source bytes.
    source_maps = source_identity_records(source_review)
    if len(source_maps) != sum(v["checked_native_files"] for v in source_review["variants"]):
        fail("native source identity record count differs from source review")

    # Include both original build/source manifests and their linked receipts/logs.
    if len(source_review["variants"]) != 2:
        fail("source review must contain exactly two original binaries")
    for variant in source_review["variants"]:
        name = variant["variant"]
        if variant["all_native_files_match"] is not True or variant["mismatches"]:
            fail(f"source review does not pass for {name}")
        for field in ("manifest", "source_manifest", "build_receipt", "build_log"):
            exact_ref(inv, variant[field], f"original_{field}", f"source_review.{name}.{field}")
        declared_exclusion(inv, variant["recorded_binary"], "release_executable", "large executable payload excluded; exact source-review size/SHA-256 retained without reading payload", f"source_review.{name}.recorded_binary")
        if Path(variant["recorded_binary"]["path"]).resolve(strict=False) not in excluded_by_path:
            fail(f"source-review executable is not one of the frozen exact exclusions: {name}")

    # Historical source summaries identify the three complete Full43 result directories.
    if set(primary["cohorts"]) != set(HISTORICAL):
        fail("historical primary does not name exactly the expected three Full43 cohorts")
    historical_roots = []
    for cohort in HISTORICAL:
        item = primary["cohorts"][cohort]
        if item["calls"] != 129 or len(item["per_query"]) != 43 or len(item["envelopes"]) != 129:
            fail(f"historical Full43 count mismatch: {cohort}")
        summary_path = exact_ref(inv, item["summary"], "historical_full43_summary", f"historical.{cohort}.summary")
        historical_roots.append((f"historical-{cohort}", summary_path.parent))

    # Completed run, driver, two review records, receipts/logs, and both paired result trees.
    if completed_result_path.parent.resolve(strict=True) != OUT.resolve(strict=True):
        fail("completed result must be in the designated evidence directory")
    inv.add_selected(completed_result_path, "completed_attribution_result", "completed_run")
    result = read_json(completed_result_path)
    if result.get("status") != "passed" or result.get("total_complete_calls") != 516:
        fail("completed attribution result is not passed with 516 calls")
    if len(result.get("cohorts", [])) != 2:
        fail("completed attribution result must contain two orders")
    if result.get("frozen", {}).get("path") != str(frozen_path):
        fail("completed result references an unexpected frozen record")
    driver_path = OUT / "composition-attribution-driver-419.json"
    inv.add_selected(driver_path, "completed_attribution_driver", "completed_run.driver")
    driver = read_json(driver_path)
    if driver.get("status") != "passed" or driver.get("completed_orders") != list(ORDERS):
        fail("driver is not passed with both orders complete")
    reviews = {}
    paired_roots = []
    archives_by_order = {}
    for order, embedded in zip(ORDERS, result["cohorts"], strict=True):
        review_path = OUT / f"composition-attribution-{order}-review-419.json"
        inv.add_selected(review_path, "order_review", f"completed_run.{order}.review")
        review = read_json(review_path)
        if review != embedded or review.get("status") != "passed" or review.get("order") != order:
            fail(f"order review mismatch or failed: {order}")
        if review.get("complete_calls") != 258 or len(review.get("per_query", [])) != 43:
            fail(f"order call/query count mismatch: {order}")
        summary_ref = review["summary"]
        summary_path = exact_ref(inv, summary_ref, "paired_result_summary", f"paired.{order}.summary")
        summary = read_json(summary_path)
        if summary.get("reverse_order") != (order == "reverse") or summary.get("selected_query_ids") != list(range(1, 44)):
            fail(f"paired summary order/query mismatch: {order}")
        if not summary.get("complete_result_validation") or not summary.get("completed_identity_check"):
            fail(f"paired summary lacks completed result/identity validation: {order}")
        if len(summary.get("records", [])) != 258 or len(summary.get("archives", [])) != 43:
            fail(f"paired summary record/archive count mismatch: {order}")
        expected_calls = {(query, run, role) for query in range(1, 44) for run in range(1, 4) for role in ("control", "candidate")}
        observed_calls = {(record["query"], record["run"], record["role"]) for record in summary["records"]}
        if observed_calls != expected_calls or len(observed_calls) != 258:
            fail(f"paired summary call keys are incomplete or duplicated: {order}")
        if [item.get("query") for item in review["per_query"]] != list(range(1, 44)):
            fail(f"review per-query gates are incomplete or reordered: {order}")
        if any(not score.get("complete") or score.get("runs_passed") != 129 for score in summary["scores"]["roles"].values()):
            fail(f"paired role completion counts are invalid: {order}")
        if len(review.get("reopened_archives", [])) != 43:
            fail(f"reviewed archive count mismatch: {order}")
        for index, (archive, reopened) in enumerate(zip(summary["archives"], review["reopened_archives"], strict=True), 1):
            if archive["path"] != reopened["path"] or archive["sha256"] != reopened["sha256"]:
                fail(f"reopened archive identity mismatch: {order} query {index}")
            archive_path = Path(archive["path"])
            if archive_path.parent != summary_path.parent or archive_path.name != f"q{index:02d}_completed.tar.xz":
                fail(f"archive path mismatch: {order} query {index}")
            inv.add_selected(archive_path, "paired_result_archive", f"paired.{order}.archive.q{index:02d}", expected=reopened)
        archives_by_order[order] = len(summary["archives"])
        receipt_ref = review["receipt"]
        receipt_path = exact_ref(inv, receipt_ref, "guard_receipt", f"paired.{order}.receipt")
        receipt = read_json(receipt_path)
        if receipt.get("status") != "passed" or receipt.get("returncode") != 0:
            fail(f"guard receipt failed: {order}")
        log_path = receipt_path.with_suffix(".log")
        inv.add_selected(log_path, "guard_log", f"paired.{order}.guard_log")
        result_dir = summary_path.parent
        paired_roots.append((f"paired-{order}", result_dir))
        reviews[order] = review
    if sum(archives_by_order.values()) != 86:
        fail("paired result archive total is not 86")

    roots = paired_roots + historical_roots
    canonical_roots = [(label, path.resolve(strict=True)) for label, path in roots]
    overlaps = []
    for i, (a_label, a_path) in enumerate(canonical_roots):
        for b_label, b_path in canonical_roots[i + 1:]:
            if a_path == b_path or a_path in b_path.parents or b_path in a_path.parents:
                overlaps.append({"left": a_label, "right": b_label, "left_path": str(a_path), "right_path": str(b_path)})

    root_labels = set()
    root_paths = set()
    for label, root in canonical_roots:
        if label in root_labels or root in root_paths:
            fail(f"duplicate result root: {label} {root}")
        root_labels.add(label)
        root_paths.add(root)
        inv.scan_tree(root, label, excluded_by_path)

    # Confirm that no selected/excluded path overlaps and each archive path is unique/safe.
    selected_paths = set(inv.members)
    excluded_paths = set(inv.exclusions)
    if selected_paths & excluded_paths:
        fail("selected/exclusion path overlap")
    if len(inv.archive_paths) != len(inv.members):
        fail("archive path collision or non-unique selected mapping")
    for name in inv.archive_paths:
        pp = PurePosixPath(name)
        if pp.is_absolute() or any(p in ("", ".", "..") for p in pp.parts):
            fail(f"unsafe archive path: {name}")
    if inv.selected_bytes > MAX_SELECTED_BYTES:
        fail("selected raw bytes exceed 192 MiB")

    # Source map entries are preserved verbatim as manifest identities; do not read source files.
    source_map_records = source_maps
    # The helper and all selected files are rechecked; excluded payloads are stat-only.
    inv.verify_unchanged()
    document = {
        "schema": "shardloom.composition_evidence_inventory.v1",
        "inventory_id": "composition-evidence-inventory-422",
        "status": "complete_mechanical_evidence_inventory",
        "completed_result": str(completed_result_path),
        "coverage": {
            "paired_orders": list(ORDERS),
            "paired_calls_per_order": 258,
            "paired_query_count_per_order": 43,
            "paired_total_calls": 516,
            "paired_tar_archives_per_order": archives_by_order,
            "paired_tar_archives_total": 86,
            "selected_unique_files": len(inv.members),
            "selected_raw_bytes": inv.selected_bytes,
            "selected_raw_bytes_ceiling": MAX_SELECTED_BYTES,
            "excluded_unique_files": len(inv.exclusions),
            "historical_full43_directories": 3,
            "result_directories": inv.directory_coverage,
            "result_root_overlaps": overlaps,
            "selected_exclusion_overlap": 0,
        },
        "members": sorted(inv.members.values(), key=lambda item: item["path"]),
        "exclusions": sorted(inv.exclusions.values(), key=lambda item: item["path"]),
        "source_map_identity_records": source_map_records,
        "scope_notes": [
            "All regular files in both paired-result roots and all three historical Full43 roots are enumerated; symlinks and non-regular entries fail closed.",
            "The two 43-archive paired orders are checked against review and summary records; directory scans retain any summary, host, manifest, log, or other files present.",
            "The accepted native source maps are retained as per-variant Git blob/size/SHA-256 identity records; source bytes are not copied or re-read.",
            "Recorded release executables and the frozen 15.7-GB Vortex input are excluded by exact manifest identity without reading or rehashing payloads.",
            "All selected identities are checked again before output publication; excluded payloads are checked by recorded size and stable file metadata only.",
        ],
    }
    if OUTPUT.exists() or OUTPUT.is_symlink():
        fail(f"refusing to replace inventory output: {OUTPUT}")
    payload = json.dumps(document, indent=2, sort_keys=True) + "\n"
    if OUTPUT.parent.resolve(strict=True) != OUT.resolve(strict=True):
        fail("inventory output parent does not match the designated evidence directory")
    with OUTPUT.open("x", encoding="utf-8") as stream:
        stream.write(payload)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("completed_result", type=Path, help="completed composition-attribution-result-419.json")
    args = parser.parse_args()
    try:
        run(args.completed_result)
    except (AssertionError, OSError, RuntimeError, KeyError, TypeError, ValueError) as error:
        print(f"inventory not published: {error}", file=sys.stderr)
        return 2
    print(str(OUTPUT))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
