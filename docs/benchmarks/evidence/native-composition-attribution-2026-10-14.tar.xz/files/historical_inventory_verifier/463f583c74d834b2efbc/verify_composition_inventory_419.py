"""Independently reopen the three historical cohorts; execute no native workload."""
import collections
import gzip
import hashlib
import json
import math
from pathlib import Path
import statistics

OUT = Path(__file__).resolve().parent
INVENTORY = OUT / 'composition-timing-inventory-419.json'


def bound(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def verify(identity):
    assert bound(identity['path']) == {k: identity[k] for k in ('path', 'bytes', 'sha256')}


def read(path):
    return json.loads(Path(path).read_text())


def same(a, b):
    assert math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-12), (a, b)


def main():
    data = read(INVENTORY)
    original = read(OUT / 'composition-timing-inventory-419-worker-original.json')
    corrected = dict(original, call_duration_count=387, per_cohort_call_duration_count=129)
    assert data == corrected
    assert data['query_id_count'] == 43 and data['per_call_timing_companion_count'] == 387
    for item in data['source_documents']:
        verify(item)
    verify(data['query_definition_source'])
    cohorts, unique, total_calls = {}, set(), 0
    metric_map = {
        'complete_call_seconds': ('seconds', 'seconds'),
        'native_child_user_cpu_seconds': ('user_cpu_seconds', 'user_cpu_seconds'),
        'native_child_system_cpu_seconds': ('system_cpu_seconds', 'system_cpu_seconds'),
        'native_child_peak_rss_bytes': ('native_peak_rss_bytes', 'peak_rss_bytes'),
    }
    source_maps = {}
    for name, cohort in data['cohorts'].items():
        for field in ('receipt', 'summary', 'source_release_manifest', 'executable_identity_record'):
            verify(cohort[field])
        receipt = read(cohort['receipt']['path'])
        summary = read(cohort['summary']['path'])
        release = read(cohort['source_release_manifest']['path'])
        assert receipt['status'] == release['status'] == 'passed'
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert receipt['command'] == cohort['command_and_resources']['supervised_command']
        assert receipt['environment'] == cohort['command_and_resources']['environment']
        assert summary['complete'] and summary['full_result_validation']
        assert summary['selected_query_ids'] == list(range(1, 44))
        assert len(summary['records']) == 129
        assert summary['binary_sha256'] == cohort['executable']['sha256'] == release['cli']['sha256']
        assert all(cohort['executable'][key] == release['cli'][key] for key in ('path', 'bytes', 'sha256'))
        assert summary['source'] == cohort['input']['path']
        assert summary['source_bytes'] == cohort['input']['bytes']
        assert summary['memory_gb'] == 24 and summary['max_parallelism'] == 12
        assert summary['queries_sha256'] == data['query_definition_source']['sha256']
        records = {(row['query'], row['run']): row for row in summary['records']}
        assert len(records) == 129
        assert set(cohort['per_query']) == {str(q) for q in range(1, 44)}
        route_calls, envelopes, query_stats = collections.Counter(), [], {}
        for q in range(1, 44):
            query = cohort['per_query'][str(q)]
            assert query['query_id'] == q and [r['run'] for r in query['calls']] == [1, 2, 3]
            durations, routes, cpu = [], set(), []
            for call in query['calls']:
                run = call['run']
                assert call['query_id'] == q
                key = (name, q, run)
                assert key not in unique
                unique.add(key)
                row = records[(q, run)]
                assert row['passed'] and row['returncode'] == 0 and not row['guard_failures']
                assert row['validation'] == 'complete_values'
                assert call['command'] == row['command'] and call['passed'] and call['returncode'] == 0
                verify(call['timing_companion'])
                timing = read(call['timing_companion']['path'])
                for key, (record_key, timing_key) in metric_map.items():
                    assert math.isfinite(call[key]) and call[key] >= 0
                    same(call[key], row[record_key])
                    same(call[key], timing[timing_key])
                same(call['complete_call_seconds'], summary['query_runs'][q - 1][run - 1])
                durations.append(call['complete_call_seconds'])
                cpu.append(call['native_child_user_cpu_seconds'] + call['native_child_system_cpu_seconds'])
                archive, = [a for a in row['completed_log_archives'] if a['path'].endswith('.stdout.json.gz')]
                raw = Path(archive['path']).read_bytes()
                assert len(raw) == archive['gzip_bytes']
                assert hashlib.sha256(raw).hexdigest() == archive['gzip_sha256']
                expanded = gzip.decompress(raw)
                assert len(expanded) == archive['raw_bytes']
                assert hashlib.sha256(expanded).hexdigest() == archive['raw_sha256']
                envelope = json.loads(expanded)
                assert envelope['status'] == 'success'
                fields = {item['key']: item['value'] for item in envelope['fields']}
                assert len(fields) == len(envelope['fields'])
                route = fields['public_workflow_route_id']
                routes.add(route)
                route_calls[route] += 1
                assert fields['fallback_attempted'] == fields['external_engine_invoked'] == 'false'
                assert fields['execution_resource_declared_memory_bytes'] == str(24 * 1024 ** 3)
                assert fields['execution_resource_declared_max_parallelism'] == '12'
                envelopes.append(dict(query=q, run=run, route=route, summary=envelope['summary'],
                    path=archive['path'], bytes=len(raw), sha256=archive['gzip_sha256'],
                    raw_bytes=len(expanded), raw_sha256=archive['raw_sha256']))
                total_calls += 1
            assert len(routes) == 1
            for key, value in (('sum_seconds', sum(durations)), ('min_seconds', min(durations)),
                               ('median_seconds', statistics.median(durations))):
                same(query[key], value)
            query_stats[str(q)] = dict(route=routes.pop(), sum_seconds=sum(durations),
                min_seconds=min(durations), median_seconds=statistics.median(durations),
                cpu_sum_seconds=sum(cpu), cpu_median_seconds=statistics.median(cpu))
        total = sum(r['seconds'] for r in summary['records'])
        same(total, summary['all_raw_run_seconds'])
        same(total, cohort['summary_totals']['sum_of_129_complete_call_seconds'])
        same(sum(q['min_seconds'] for q in query_stats.values()), summary['query_total_seconds'])
        source_maps[name] = release['source_sha256']
        cohorts[name] = dict(summary=cohort['summary'], calls=129, all_129_seconds=total,
            sum_of_query_minima_seconds=sum(q['min_seconds'] for q in query_stats.values()),
            sum_of_query_medians_seconds=sum(q['median_seconds'] for q in query_stats.values()),
            supervised_seconds=receipt['seconds'], route_call_counts=dict(route_calls),
            per_query=query_stats, envelopes=envelopes)
    assert total_calls == len(unique) == data['call_duration_count'] == 387
    for comparison in data['arithmetic_differences']:
        left, right = (data['cohorts'][comparison[k]]['per_query'] for k in ('left', 'right'))
        assert 'UNPAIRED' in comparison['label']
        for metric, values in comparison['metrics'].items():
            rows = [dict(query_id=q, difference_seconds=right[str(q)][metric] - left[str(q)][metric],
                left_seconds=left[str(q)][metric], right_seconds=right[str(q)][metric]) for q in range(1, 44)]
            assert values['sorted_descending_by_difference'] == sorted(rows, key=lambda r: r['difference_seconds'], reverse=True)
            assert values['sorted_ascending_by_difference'] == sorted(rows, key=lambda r: r['difference_seconds'])
            if values['total_difference_seconds'] is None:
                assert metric in ('min_seconds', 'median_seconds')
            else:
                same(sum(r['difference_seconds'] for r in rows), values['total_difference_seconds'])
    first, second = source_maps['pre_composition'], source_maps['composition']
    differences = [dict(path=p, before=first.get(p), composition=second.get(p))
        for p in sorted(first.keys() | second.keys()) if first.get(p) != second.get(p)]
    result = dict(status='passed_literal_inventory_and_route_readback', inventory=bound(INVENTORY),
        original_inventory=bound(OUT / 'composition-timing-inventory-419-worker-original.json'),
        verifier=bound(__file__), checked_calls=total_calls, checked_timing_companions=total_calls,
        checked_complete_envelopes=total_calls, cohorts=cohorts,
        source_manifest_differences=differences,
        causal_attribution='unresolved; historical cohorts are unpaired',
        large_input_or_binary_rehashed=False, native_queries_executed=False)
    path = OUT / 'composition-timing-primary-419.json'
    with path.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status=result['status'], checked_calls=total_calls,
        routes={name: c['route_call_counts'] for name, c in cohorts.items()},
        source_manifest_difference_count=len(differences))))


if __name__ == '__main__':
    main()
