"""Reopen complete paired results and compute the declared attribution checks."""
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys
import tarfile

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
sys.path.insert(0, str(ROOT / 'scripts'))
from clickbench_reference_packet import load_reference_packet
from native_workflow_protocol import extract_result, public_workflow_command, report_fields, strict_json
from run_clickbench_query_uat import equivalent


def bound(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def verify(item):
    assert bound(item['path']) == item


def read(path):
    return json.loads(Path(path).read_text())


def close(a, b):
    assert math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-12), (a, b)


def review_order(order, summary_path, receipt_path, frozen, schemas):
    plan = read(frozen['plan']['path'])
    threshold = plan['per_query_thresholds']
    summary, receipt = read(summary_path), read(receipt_path)
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert bound(Path(receipt_path).with_suffix('.log'))['sha256'] == receipt['log_sha256']
    assert summary['complete_result_validation'] and summary['completed_identity_check']
    assert summary['reference_packet_identity_verified']
    assert summary['reverse_order'] == (order == 'reverse')
    assert summary['selected_query_ids'] == list(range(1, 44))
    assert summary['memory_gb'] == 24 and summary['max_parallelism'] == 12
    assert summary['source'] == frozen['source']['path']
    assert summary['log_budget_bytes'] == {'retained': 1024 << 20, 'active_run': 256 << 20}
    for role in ('control', 'candidate'):
        item = frozen['binaries'][role]
        assert summary['binaries'][role] == dict(path=item['path'], sha256=item['sha256'], commit=item['accepted_commit'])
        assert summary['sources'][role]['path'] == frozen['source']['path']
        assert summary['sources'][role]['generation'] == frozen['source_generation']
    reference = load_reference_packet(Path(frozen['reference']['path']), Path(frozen['queries']['path']))
    assert summary['queries_sha256'] == frozen['queries']['sha256']
    assert summary['reference_packet']['sha256'] == frozen['reference']['sha256']
    assert summary['queries'] == {str(query): statement
        for query, statement in enumerate(reference['queries'], 1)}
    assert summary['command_template'] == public_workflow_command(
        '{binary}', '{sql}', input_path='{role_source}', input_format='vortex',
        memory_gb=24, max_parallelism=12)
    expected_order = [(q, run, role, position)
        for q in range(1, 44) for run in range(1, 4)
        for position, role in enumerate(
            ('control', 'candidate') if (q + run + (order == 'reverse')) % 2 == 0
            else ('candidate', 'control'), 1)]
    records = summary['records']
    assert len(records) == 258
    assert [(r['query'], r['run'], r['role'], r['pair_position']) for r in records] == expected_order
    rows = {(r['query'], r['run'], r['role']): r for r in records}
    assert len(rows) == len(records)
    historical = read(frozen['historical']['path'])['cohorts']['composition']['per_query']
    assert len(summary['archives']) == 43
    reopened, result_rows = [], 0
    for query, archive in enumerate(summary['archives'], 1):
        path = Path(archive['path'])
        assert path.parent == Path(summary_path).parent and path.name == f'q{query:02d}_completed.tar.xz'
        assert bound(path)['sha256'] == archive['sha256']
        members = {member['name']: member for member in archive['members']}
        expected_names = {f'q{query:02d}_run{run}_{role}' + suffix
            for run in range(1, 4) for role in ('control', 'candidate')
            for suffix in ('.stdout.json', '.stderr.txt', '.timing.json', '.pid')}
        assert len(members) == len(archive['members']) == 24 and set(members) == expected_names
        contents = {}
        with tarfile.open(path, 'r|xz') as stream:
            for member in stream:
                assert member.isfile() and member.name in members and member.name not in contents
                raw = stream.extractfile(member).read()
                assert len(raw) == members[member.name]['bytes']
                assert hashlib.sha256(raw).hexdigest() == members[member.name]['sha256']
                contents[member.name] = raw
        assert set(contents) == expected_names
        for run in range(1, 4):
            for role in ('control', 'candidate'):
                prefix = f'q{query:02d}_run{run}_{role}'
                record = rows[(query, run, role)]
                assert record['passed'] and record['validation'] == 'complete_values'
                assert record['returncode'] == 0 and not record['guard_failures']
                assert 'host_before' in record and 'host_after' in record
                timing = strict_json(contents[prefix + '.timing.json'].decode())
                for a, b in (('seconds', 'seconds'), ('returncode', 'returncode'),
                    ('native_peak_rss_bytes', 'peak_rss_bytes'), ('user_cpu_seconds', 'user_cpu_seconds'),
                    ('system_cpu_seconds', 'system_cpu_seconds')):
                    close(record[a], timing[b])
                    assert math.isfinite(record[a]) and record[a] >= 0
                assert int(contents[prefix + '.pid'].strip()) > 0
                assert contents[prefix + '.stderr.txt'] == b''
                envelope = strict_json(contents[prefix + '.stdout.json'].decode())
                assert envelope['status'] == 'success'
                fields = report_fields(envelope)
                result = extract_result(envelope)
                assert equivalent(result, reference['values'][query])
                assert hashlib.sha256(json.dumps(result, sort_keys=True, allow_nan=False).encode()).hexdigest() == record['result_sha256']
                assert fields['public_workflow_route_id'] == historical[str(query)]['route']
                assert fields['fallback_attempted'] == fields['external_engine_invoked'] == 'false'
                assert fields['execution_resource_declared_memory_bytes'] == str(24 << 30)
                assert fields['execution_resource_declared_max_parallelism'] == '12'
                assert any(c['kind'] == 'native_io_certificate' and c['status'] == 'available' for c in envelope['certificates'])
                schema = (fields['result_schema_format'], strict_json(fields['result_schema_json']))
                assert schemas.setdefault(query, schema) == schema
                result_rows += len(result)
        reopened.append(bound(path))
    gates, totals = [], {}
    for query in range(1, 44):
        medians = {}
        for role in ('control', 'candidate'):
            observations = [rows[(query, run, role)] for run in range(1, 4)]
            medians[role] = dict(elapsed_seconds=statistics.median(r['seconds'] for r in observations),
                cpu_seconds=statistics.median(r['user_cpu_seconds'] + r['system_cpu_seconds'] for r in observations),
                peak_rss_bytes=statistics.median(r['native_peak_rss_bytes'] for r in observations))
        a, b = medians['control'], medians['candidate']
        breaches = dict(
            elapsed=b['elapsed_seconds'] > a['elapsed_seconds'] + max(threshold['elapsed_relative'] * a['elapsed_seconds'], threshold['elapsed_absolute_seconds']),
            cpu=b['cpu_seconds'] > a['cpu_seconds'] + max(threshold['cpu_relative'] * a['cpu_seconds'], threshold['cpu_absolute_seconds']),
            rss=b['peak_rss_bytes'] > a['peak_rss_bytes'] + max(threshold['rss_relative'] * a['peak_rss_bytes'], threshold['rss_absolute_bytes']))
        gates.append(dict(query=query, medians=medians, breaches=breaches,
            paired_elapsed_candidate_minus_control_seconds=[rows[(query, run, 'candidate')]['seconds'] - rows[(query, run, 'control')]['seconds'] for run in range(1, 4)]))
    for role in ('control', 'candidate'):
        selected = [r for r in records if r['role'] == role]
        totals[role] = dict(all_129_call_seconds=sum(r['seconds'] for r in selected),
            sum_of_query_minima_seconds=sum(min(rows[(q, run, role)]['seconds'] for run in range(1, 4)) for q in range(1, 44)),
            sum_of_query_medians_seconds=sum(r['medians'][role]['elapsed_seconds'] for r in gates),
            total_child_cpu_seconds=sum(r['user_cpu_seconds'] + r['system_cpu_seconds'] for r in selected),
            largest_process_rss_bytes=max(r['native_peak_rss_bytes'] for r in selected))
        reported = summary['scores']['roles'][role]
        assert reported['complete'] and reported['runs_passed'] == 129
        close(totals[role]['all_129_call_seconds'], reported['all_raw_run_seconds'])
        close(totals[role]['sum_of_query_minima_seconds'], reported['query_total_seconds'])
    return dict(status='passed', order=order, summary=bound(summary_path), receipt=bound(receipt_path),
        complete_calls=258, complete_result_rows=result_rows, reopened_archives=reopened,
        supervised_seconds=receipt['seconds'], totals=totals, per_query=gates,
        observed_route_ids_unchanged=True, schemas_checked_across_orders=True,
        command_provenance='Frozen paired runner constructs each call from the verified command template, query text, role binary and role source. The existing runner does not record a separate per-call command field.')
