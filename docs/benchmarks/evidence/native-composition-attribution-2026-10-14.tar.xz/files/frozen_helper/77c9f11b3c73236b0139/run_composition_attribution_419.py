"""Run the existing Full43 paired runner against the two retained executables."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import stat
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
UAT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
PLAN = OUT / 'composition-attribution-plan-419.json'
FROZEN = OUT / 'composition-attribution-frozen-419.json'
sys.path[:0] = [str(ROOT / 'scripts'), str(OUT)]
from freeze_native_release_298 import sources
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
from run_clickbench_paired_query_uat import generation
from review_composition_attribution_419 import review_order


def read(path):
    return json.loads(Path(path).read_text())


def bound(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def verify(item):
    assert bound(item['path']) == {key: item[key] for key in ('path', 'bytes', 'sha256')}


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def freeze():
    assert not FROZEN.exists()
    acceptance = OUT / 'decoder-after-build-418.json'
    accepted = read(acceptance)
    assert accepted['status'] == 'passed' and accepted['wider_acceptance_ran']
    assert read(OUT / 'decoder-acceptance-418.json')['status'] == 'passed'
    release = read(OUT / 'decoder-resources-418-release.json')
    current_sources = sources()
    assert current_sources == release['source_sha256']
    plan = read(PLAN)
    source = Path(plan['workload']['source'])
    require_local_path(UAT, Path.home(), sys.platform)
    require_local_path(source, Path.home(), sys.platform)
    source_stat = source.stat()
    assert stat.S_ISREG(source_stat.st_mode) and not source.is_symlink()
    assert source_stat.st_flags == 0 and source_stat.st_blocks * 512 >= source_stat.st_size
    assert source_stat.st_size == plan['workload']['source_bytes']
    assert not (UAT / '.ingest-uat.lock').exists()
    storage = check_budgets(UAT, source, UAT / 'logs/composition-attribution-419-admission',
        min_free_bytes=12 * GIB, reserve_bytes=256 * MIB, max_workspace_bytes=100 * GIB,
        max_log_bytes=1024 * MIB, max_run_log_bytes=256 * MIB, reserve_log_bytes=256 * MIB)
    before = generation(source)
    source_identity = bound(source)
    assert source_identity['sha256'] == plan['workload']['source_sha256']
    assert generation(source) == before
    proof_path = OUT / plan['source_proof']
    proof = read(proof_path)
    assert proof['status'] == 'passed' and len(proof['variants']) == 2
    completeness_path = OUT / 'composition-binary-source-completeness-419.json'
    completeness = read(completeness_path)
    assert completeness['status'] == 'passed' and completeness['exact_native_path_sets_equal']
    assert completeness['source_proof'] == bound(proof_path)
    binaries, manifests = {}, {}
    for role, proof_name in (('control', 'pre_composition'), ('candidate', 'composition')):
        item, = [row for row in proof['variants'] if row['variant'] == proof_name]
        assert item['all_native_files_match'] and not item['mismatches']
        assert item['accepted_commit'] == plan[role]['accepted_commit']
        for key in ('manifest', 'source_manifest', 'build_receipt', 'build_log'):
            verify(item[key])
        manifest = read(item['manifest']['path'])
        binary = bound(manifest['cli']['path'])
        assert binary == item['recorded_binary']
        assert binary['sha256'] == plan[role]['binary_sha256']
        binaries[role] = dict(binary, accepted_commit=item['accepted_commit'])
        manifests[role] = item['manifest']
    reference = bound(plan['workload']['reference'])
    assert reference['sha256'] == plan['workload']['reference_sha256']
    queries = bound(ROOT / 'benchmarks/clickbench/queries.sql')
    paths = [Path(__file__), OUT / 'review_composition_attribution_419.py', OUT / 'run_guarded.py',
        OUT / 'freeze_native_release_298.py',
        Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py'),
        Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py')]
    paths += [ROOT / 'scripts' / name for name in ('run_clickbench_paired_query_uat.py',
        'run_clickbench_query_uat.py', 'clickbench_reference_packet.py', 'native_workflow_protocol.py',
        'timed_native_command.py', 'local_uat_storage.py')]
    paths += sorted((ROOT / 'python/src/shardloom').rglob('*.py'))
    helpers = {str(path): bound(path) for path in paths}
    save(FROZEN, dict(status='frozen_before_any_attribution_timing', plan=bound(PLAN),
        source_proof=bound(proof_path), source_completeness=bound(completeness_path),
        historical=bound(OUT / plan['historical_evidence']),
        prerequisite_acceptance=bound(acceptance), binaries=binaries, manifests=manifests,
        source=source_identity, source_generation=before, reference=reference, queries=queries,
        helpers=helpers, active_workspace_sources=current_sources, storage=storage,
        platform=platform.platform(), logical_cpu_count=os.cpu_count(),
        physical_memory_bytes=os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES'),
        cache_state='Input prehashed; shared OS cache and ordinary host activity uncontrolled',
        native_comparison_executed=False))
    print(json.dumps(dict(status='frozen', calls=516, source=source_identity['sha256'])), flush=True)


def unchanged(frozen, include_input=False):
    for item in list(frozen['helpers'].values()) + list(frozen['manifests'].values()) + [
        frozen['plan'], frozen['source_proof'], frozen['source_completeness'],
        frozen['historical'], frozen['prerequisite_acceptance'],
        frozen['reference'], frozen['queries']]:
        verify(item)
    for item in frozen['binaries'].values():
        verify(item)
    assert sources() == frozen['active_workspace_sources']
    assert generation(Path(frozen['source']['path'])) == frozen['source_generation']
    if include_input:
        verify(frozen['source'])


def run():
    frozen = read(FROZEN)
    assert frozen['status'] == 'frozen_before_any_attribution_timing'
    unchanged(frozen, include_input=True)
    for order in ('forward', 'reverse'):
        assert not (OUT / f'composition-attribution-{order}-419.json').exists()
        assert not (OUT / f'composition-attribution-{order}-review-419.json').exists()
    assert not (OUT / 'composition-attribution-result-419.json').exists()
    frozen_identity = bound(FROZEN)
    completed, schemas, failure = [], {}, None
    try:
        for order in ('forward', 'reverse'):
            unchanged(frozen)
            verify(frozen_identity)
            before = set((UAT / 'logs').glob('paired43_*/summary.json'))
            command = [sys.executable, '-B', str(OUT / 'run_guarded.py'),
                '--name', f'composition-attribution-{order}-419', '--timeout', '2400', '--',
                sys.executable, '-B', str(ROOT / 'scripts/run_clickbench_paired_query_uat.py')]
            for role in ('control', 'candidate'):
                command += [f'--{role}-binary', frozen['binaries'][role]['path'],
                    f'--{role}-commit', frozen['binaries'][role]['accepted_commit']]
            command += ['--input', frozen['source']['path'], '--uat-root', str(UAT),
                '--reference-packet', frozen['reference']['path'], '--queries', frozen['queries']['path'],
                '--memory-gb', '24', '--max-parallelism', '12', '--timeout', '120',
                '--max-workspace-gib', '100', '--max-log-mib', '1024', '--max-run-log-mib', '256']
            if order == 'reverse':
                command.append('--reverse-order')
            print(json.dumps(dict(stage=order, status='starting', calls=258)), flush=True)
            subprocess.run(command, cwd=ROOT, check=True)
            new = set((UAT / 'logs').glob('paired43_*/summary.json')) - before
            assert len(new) == 1
            summary = new.pop()
            unchanged(frozen, include_input=True)
            verify(frozen_identity)
            assert not (UAT / '.ingest-uat.lock').exists()
            review = review_order(order, summary, OUT / f'composition-attribution-{order}-419.json', frozen, schemas)
            save(OUT / f'composition-attribution-{order}-review-419.json', review)
            completed.append(review)
            print(json.dumps(dict(stage=order, status='passed', totals=review['totals'])), flush=True)
        repeated = []
        for forward, reverse in zip(completed[0]['per_query'], completed[1]['per_query'], strict=True):
            assert forward['query'] == reverse['query']
            metrics = [key for key in ('elapsed', 'cpu', 'rss') if forward['breaches'][key] and reverse['breaches'][key]]
            if metrics:
                repeated.append(dict(query=forward['query'], metrics=metrics))
        outcome = 'repeatable_binary_cost_increases_require_diagnosis' if repeated else 'historical_increase_not_reproduced_under_declared_thresholds'
        unchanged(frozen, include_input=True)
        save(OUT / 'composition-attribution-result-419.json', dict(status='passed', frozen=frozen_identity,
            cohorts=completed, total_complete_calls=516, repeated_metric_increases=repeated, outcome=outcome,
            interpretation='Comparison isolates these retained executable versions on this shared input under observed current conditions. It does not reconstruct historical thermal/cache state, prove zero overhead, or authorize a scanner/context change without separate source and regression evidence.',
            historical_cause_established=False, publication_attempted=False))
        print(json.dumps(dict(status='passed', outcome=outcome, repeated_metric_increases=repeated)), flush=True)
    except BaseException as error:
        failure = f'{type(error).__name__}: {error}'
        raise
    finally:
        save(OUT / 'composition-attribution-driver-419.json', dict(status='passed' if failure is None else 'failed',
            failure=failure, frozen=frozen_identity, completed_orders=[r['order'] for r in completed]))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=['freeze', 'run'])
    args = parser.parse_args()
    freeze() if args.operation == 'freeze' else run()
