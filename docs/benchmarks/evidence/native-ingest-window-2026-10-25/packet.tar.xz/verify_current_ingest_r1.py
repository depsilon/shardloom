"""Verify current-main ingest and its existing, sequential engine timers."""
from __future__ import annotations
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OLD = Path('/Users/dylan/LocalData/shardloom/ingest-ownership-20261025')
sys.path.insert(0, str(REPO / 'scripts'))
from native_workflow_protocol import report_fields, strict_json


def read(path):
    return strict_json(Path(path).read_text())


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha)


def main():
    destination = ROOT / 'current-main-r1-acceptance.json'
    assert not destination.exists()
    driver = read(ROOT / 'current-main-r1.driver.json')
    assert driver['status'] == 'completed' and driver['returncode'] == 0
    assert driver['native_process_cleanup_verified'] and driver['process_group_drained'] and driver['direct_child_reaped']
    assert not driver['recursive_inventory_during_execution'] and not driver['timed_out']
    assert driver['interrupted_signal'] is None and driver['input_before'] == driver['input_after']
    assert driver['source_revision'] == '167ac248ba662ae7967a7801995e9b160b17bae5'
    assert driver['build'] == identity(ROOT / 'current-main-build-r1.json')
    build = read(driver['build']['path'])
    assert identity(build['artifacts']['shardloom']['path']) == build['artifacts']['shardloom']
    logs, = [Path(path) for path in driver['ingest_log_directories']]
    summary, envelope = read(logs / 'prepare_summary.json'), read(logs / 'stdout.json')
    assert summary['returncode'] == 0 and summary['stdout_json_ok'] and summary['target_exists']
    assert summary['memory_gb'] == 24 and summary['max_parallelism'] == 12
    assert envelope['status'] == 'success' and envelope['diagnostics'] == []
    assert not envelope['fallback']['attempted'] and not envelope['fallback']['allowed']
    fields, prefix = report_fields(envelope), 'public_workflow_preparation_'
    assert fields['fallback_attempted'] == 'false'
    assert fields[prefix + 'vortex_ingest_status'] == 'prepared_state_created'
    assert fields[prefix + 'prepared_olap_state_status'] == 'prepared_olap_state_ready'
    for key in ('input_row_count', 'vortex_segment_metadata_row_count', 'prepared_olap_state_layout_footer_row_count',
                'vortex_ingest_stream_validation_rows', 'vortex_ingest_stream_projection_rows', 'vortex_ingest_stream_arrow_conversion_rows'):
        assert int(fields[prefix + key]) == 99_997_497, key
    assert int(fields[prefix + 'source_state_record_batch_count']) == 3120
    assert len(fields[prefix + 'source_state_materialized_columns'].split(',')) == 112
    assert int(fields[prefix + 'vortex_shared_native_memory_denied_reservations']) == 0
    assert int(fields[prefix + 'vortex_shared_native_memory_peak_reserved_bytes']) <= 24 * 1024**3
    assert int(fields[prefix + 'vortex_shared_native_memory_final_reserved_bytes']) == 4096
    output = driver['output']
    assert identity(output['path']) == {key: output[key] for key in ('path', 'bytes', 'sha256')}
    assert fields[prefix + 'prepared_artifact_digest'] == 'sha256:' + output['sha256']
    reference = read(OLD / 'candidate-screen-r1-preliminary.json')
    assert (output['bytes'], output['sha256']) == (reference['output']['bytes'], reference['output']['sha256'])
    assert driver['input_after'] == reference['input']
    verifier = REPO / 'docs/benchmarks/evidence/native-ingest-ownership-2026-10-25/verify.py'
    spec = importlib.util.spec_from_file_location('accepted_ingest_packet', verifier)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    packet = module.Packet(verifier.parent)
    accepted = packet.read(OLD / 'candidate-screen-r1-decision.json')
    assert accepted['correctness_status'] == 'passed'
    previous = packet.read(OLD / 'logs/ingest_cli_uat_gated_20261025T095039Z/stdout.json')
    old_fields = report_fields(previous)
    # run_vortex_ingest_prepare_once_with_schema calls the complete preparation
    # first, then starts publication_start. These spans are sequential. Nested
    # compression/decode/conversion work clocks overlap and must not be summed.
    timers = ('prepare_once_millis', 'prepared_olap_publication_millis')
    engine = sum(int(fields[prefix + key]) for key in timers) / 1000
    previous_engine = sum(int(old_fields[prefix + key]) for key in timers) / 1000
    result = dict(status='passed', scope='one isolated latest-main baseline observation;not_a_speedup_claim',
        engine_seconds=engine, engine_clock_fields=list(timers),
        engine_clock_scope='sum_of_sequential_native_preparation_and_prepared_artifact_publication;excludes_process_startup_report_serialization_and_external_UAT_checks',
        engine_clock_precision='each_existing_span_is_truncated_to_integer_milliseconds',
        previous_same_clock_seconds=previous_engine, change_fraction=engine/previous_engine-1,
        rows=99_997_497, columns=112, batches=3120, output=output,
        byte_identical_to_independently_validated_accepted_artifact=True,
        accepted_reference_artifact=reference['output'], input=driver['input_after'],
        peak_reserved_bytes=int(fields[prefix + 'vortex_shared_native_memory_peak_reserved_bytes']),
        denied_reservations=0, process_cleanup_verified=True,
        engine_code=identity(REPO / 'shardloom-cli/src/sql_local_source_runtime.rs'),
        prior_correctness_packet_manifest=identity(verifier.parent / 'manifest.json'),
        members=[identity(path) for path in (ROOT / 'current-main-r1.driver.json',
            ROOT / 'current-main-build-r1.json', logs / 'prepare_summary.json', logs / 'stdout.json', Path(__file__))])
    destination.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ('status', 'engine_seconds', 'rows', 'columns',
        'byte_identical_to_independently_validated_accepted_artifact', 'previous_same_clock_seconds', 'change_fraction')}))


if __name__ == '__main__':
    main()
