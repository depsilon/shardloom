"""Run one declared ingest observation with the existing guarded runner.

Input hashing and recursive inventories occur only before or after the child.
The native process clock remains owned by run_clickbench_ingest_uat.sh.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import stat
import subprocess
import sys

ROOT = Path('/Users/dylan/LocalData/shardloom/ingest-representation-20261025')
REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
SOURCE = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat/sources/hits.parquet')
SOURCE_SHA = 'a390f6cb782f6aaef278c72fc1dd86c4f30bc843ebab3c159e9bd4d45ddb079f'
SUPERVISOR = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
GUARD = Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/native_workload_guard_816.py')
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
ACTIVE = tuple(Path('/Users/dylan/LocalData/shardloom') / name for name in (
    'native-surface-parity-20261024', 'native-grouped-preparation-20261024',
    'native-engine-optimization-20261023', 'native-prerequisites-20261022',
    'vortex-provider-refresh-20261024', 'public-naming-20261025',
    'ingest-ownership-20261025', 'workflow-work-elimination-20261025'))


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}


def generation(path):
    info = path.stat()
    return [info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns]


def input_identity():
    info = SOURCE.lstat()
    assert stat.S_ISREG(info.st_mode) and not SOURCE.is_symlink()
    assert not getattr(info, 'st_flags', 0) & getattr(stat, 'SF_DATALESS', 0x40000000)
    assert info.st_blocks * 512 >= info.st_size, 'source must already be resident'
    before = generation(SOURCE)
    result = identity(SOURCE)
    assert result['sha256'] == SOURCE_SHA and generation(SOURCE) == before
    return {**result, 'generation': before}


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def inventory(path):
    return sum(p.stat().st_size for p in path.rglob('*')
               if p.is_file() and not p.is_symlink())


def storage():
    sizes = {'source_uat': inventory(SOURCE.parent.parent),
             'target_and_active_tasks': sum(inventory(p) for p in (ROOT, CACHE, *ACTIVE))}
    assert max(sizes.values()) <= 100 * (1 << 30), sizes
    free = shutil.disk_usage(ROOT).free
    assert free >= 12 * (1 << 30), free
    return {**sizes, 'free_bytes': free}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', type=Path, required=True)
    parser.add_argument('--label', required=True)
    parser.add_argument('--role', choices=('control', 'candidate'), required=True)
    args = parser.parse_args()
    assert args.label.replace('-', '').isalnum() and len(args.label) <= 80
    output = ROOT / 'outputs' / args.label / 'hits.vortex'
    log = ROOT / (args.label + '.driver.log')
    receipt = ROOT / (args.label + '.driver.json')
    assert not output.exists() and not output.parent.exists()
    assert not log.exists() and not receipt.exists()
    assert not (ROOT / '.ingest-uat.lock').exists()
    build_identity = identity(args.build)
    build = json.loads(args.build.read_text())
    assert build['status'] == 'passed'
    assert build['package_feature_union'] == 'release-user-surfaces'
    binary = build['artifacts']['shardloom']
    helpers = [SUPERVISOR, GUARD, Path(__file__),
               REPO / 'scripts/run_clickbench_ingest_uat.sh',
               REPO / 'scripts/local_uat_storage.py',
               REPO / 'scripts/timed_native_command.py']
    helper_identities = [identity(p) for p in helpers]
    assert helper_identities[0]['sha256'] == '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97'
    assert helper_identities[1]['sha256'] == 'ce56dd25bd4e55c8c7b8929140c2f2228f27f42d79ceea5645d50db320407b76'

    def verify_build():
        assert identity(args.build) == build_identity
        tree = subprocess.check_output(
            ['git', 'rev-parse', build['source_revision'] + '^{tree}'],
            cwd=REPO, text=True, timeout=10).strip()
        assert tree == build['source_tree']
        assert identity(binary['path']) == binary
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == build['source_revision']
        assert all(p.startswith('docs/') for p in subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], cwd=REPO, text=True).splitlines())
        for relative, expected in build['runtime_source_inventory'].items():
            current = identity(REPO / relative)
            assert current['sha256'] == expected['sha256'] and current['bytes'] == expected['bytes'], relative
        assert [identity(p) for p in helpers] == helper_identities

    verify_build()
    before_storage = storage()
    original = input_identity()
    previous_logs = set((ROOT / 'logs').glob('ingest_cli_uat_gated_*'))
    bounded = load('ingest_bounded', SUPERVISOR)
    guard_module = load('ingest_workload', GUARD)
    original_name_check = guard_module.native_name
    guard_module.native_name = lambda name: original_name_check(name) or Path(name).name in {
        'compare_parquet_native_artifact', 'compare_native_artifacts', 'physical_encoding_inventory'}
    workload = guard_module.WorkloadGuard()
    command = ['env', 'PATH=/opt/homebrew/opt/python@3.13/libexec/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
               'bash', 'scripts/run_clickbench_ingest_uat.sh', '--uat-root', str(ROOT),
               '--binary', binary['path'], '--source', str(SOURCE), '--input-format', 'parquet',
               '--target', str(output), '--memory-gb', '24', '--max-parallelism', '12']
    evidence = {'status': 'running', 'role': args.role, 'command': command, 'cwd': str(REPO),
                'build': build_identity, 'source_revision': build['source_revision'],
                'source_tree': build['source_tree'], 'input_before': original,
                'storage_before': before_storage, 'helper_identities': helper_identities,
                'active_guard': 'existing_process_concurrency_and_free_space_guard_plus_three_new_readonly_tool_names',
                'recursive_inventory_during_execution': False,
                'cache_context': 'uncontrolled; full source hash before execution; no cache manipulation',
                'host': {'platform': platform.platform(), 'machine': platform.machine(),
                         'python': sys.version},
                'acceptance': 'requested isolated current-main ingestion observation; final byte/value/schema acceptance remains separate',
                'authorization': 'maintainer requested current ingestion timing with other task work idle',
                'execution_policy': 'one complete ingest; all other task jobs and agents idle'}

    def guard():
        workload.check(evidence.get('pid'))
        assert shutil.disk_usage(ROOT).free >= 12 * (1 << 30)

    try:
        guard()
        (ROOT / 'tmp').mkdir(exist_ok=True)
        print('preparation_verified; starting_one_isolated_current_main_ingest', flush=True)
        with log.open('xb') as stream:
            code = bounded.run(command, cwd=REPO,
                               env=dict(os.environ, PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1',
                                        TMPDIR=str(ROOT / 'tmp')),
                               output=stream, timeout=3600, evidence=evidence,
                               guard=guard, max_output_bytes=8 << 20)
        print('ingestion_finished; verifying_source_output_and_cleanup', flush=True)
        assert evidence['process_group_drained'] and evidence['direct_child_reaped']
        guard_module.WorkloadGuard().check()
        assert not (ROOT / '.ingest-uat.lock').exists()
        evidence['native_process_cleanup_verified'] = True
        verify_build()
        evidence['input_after'] = input_identity()
        assert evidence['input_after'] == original
        evidence['storage_after'] = storage()
        created = set((ROOT / 'logs').glob('ingest_cli_uat_gated_*')) - previous_logs
        evidence['ingest_log_directories'] = sorted(str(p) for p in created)
        assert len(created) == 1
        if output.is_file():
            evidence['output'] = {**identity(output), 'generation': generation(output)}
        evidence['status'] = 'completed' if code == 0 else 'failed'
    except BaseException as error:
        evidence.update(status='failed', failure=f'{type(error).__name__}: {error}')
        raise
    finally:
        evidence['log'] = identity(log) if log.exists() else None
        with receipt.open('x') as stream:
            json.dump(evidence, stream, indent=2)
            stream.write('\n')
        print(json.dumps({k: evidence.get(k) for k in
                          ('status', 'returncode', 'process_group_drained', 'failure')}), flush=True)
    return code


if __name__ == '__main__':
    sys.exit(main())

