use super::*;

#[test]
fn native_zstd_compression_tiny_payload_requires_context_admission() {
    let values = PrimitiveArray::from_iter([17i64]);
    let memory = LiveMemoryPool::new(4096).unwrap();
    let error = ZstdData::from_primitive_without_dict(
        &values,
        0,
        8,
        &mut session(&memory).create_execution_ctx(),
    )
    .unwrap_err();
    assert!(crate::owned_buffers::is_owned_reservation_denial(&error));
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}

#[test]
fn native_zstd_compression_empty_default_frame_round_trips() {
    let values = PrimitiveArray::from_iter(std::iter::empty::<i64>());
    let memory = LiveMemoryPool::new(4096).unwrap();
    let session = session(&memory);
    let mut ctx = session.create_execution_ctx();
    let data = ZstdData::from_primitive_without_dict(&values, 0, 0, &mut ctx).unwrap();
    let encoded = Zstd::try_new(values.dtype().clone(), data, Validity::NonNullable)
        .unwrap()
        .into_array();
    let output = encoded.execute::<PrimitiveArray>(&mut ctx).unwrap();
    assert!(output.is_empty());
    drop(output);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}

#[test]
fn native_zstd_compression_empty_strings_use_default_frame() {
    let values = VarBinViewArray::from_iter_str(std::iter::empty::<&str>());
    let mut ctx = VortexSession::default().create_execution_ctx();
    let encoded = Zstd::from_var_bin_view_without_dict(&values, 0, 0, &mut ctx).unwrap();
    let output = encoded.into_array().execute::<VarBinViewArray>(&mut ctx).unwrap();
    assert!(output.is_empty());
}

#[test]
fn native_zstd_compression_frame_limit_above_input_does_not_overflow() {
    let values = PrimitiveArray::from_iter([i64::MIN, i64::MAX]);
    let mut ctx = VortexSession::default().create_execution_ctx();
    let data = ZstdData::from_primitive_without_dict(&values, 0, usize::MAX, &mut ctx).unwrap();
    let encoded = Zstd::try_new(values.dtype().clone(), data, Validity::NonNullable)
        .unwrap().into_array();
    let output = encoded.execute::<PrimitiveArray>(&mut ctx).unwrap();
    assert_eq!(output.as_slice::<i64>(), &[i64::MIN, i64::MAX]);
}

#[test]
fn native_zstd_compression_overaligned_frames_preserve_counts_and_slices() {
    let expected: Vec<i64> = (0..65).map(|index| index * 37 - 4096).collect();
    let values = PrimitiveArray::new(
        vortex::buffer::Buffer::copy_from_aligned(&expected, Alignment::new(256)),
        Validity::NonNullable,
    );
    let mut ctx = VortexSession::default().create_execution_ctx();
    let data = ZstdData::from_primitive_without_dict(&values, 0, 3, &mut ctx).unwrap();
    let parts = data.clone().into_parts(Validity::NonNullable);
    assert_eq!(parts.metadata.frames.iter().map(|frame| frame.n_values).sum::<u64>(), 65);
    let encoded = Zstd::try_new(values.dtype().clone(), data, Validity::NonNullable)
        .unwrap().into_array();
    for range in [0..65, 2..35, 31..33, 63..65] {
        let output = encoded.slice(range.clone()).unwrap()
            .execute::<PrimitiveArray>(&mut ctx).unwrap();
        assert_eq!(output.as_slice::<i64>(), &expected[range]);
    }
}
