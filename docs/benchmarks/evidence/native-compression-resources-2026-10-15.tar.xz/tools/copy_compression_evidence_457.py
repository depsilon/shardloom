"""Install the closed compression packet with a portable, concise evidence index."""
import hashlib
import json
import lzma
from pathlib import Path
import shutil

import compression_cost_456c as c
from freeze_native_release_298 import sources


def write(path, data):
    with Path(path).open('xb') as stream:
        stream.write(data)
    assert Path(path).read_bytes() == data
    return c.bound(path)


def main():
    destination = c.ROOT / 'docs/benchmarks/evidence'
    prefix = 'native-compression-resources-2026-10-15'
    source = 'compression-resources-evidence-457'
    assert shutil.disk_usage(destination).free >= 12 * c.GIB
    original = {name: c.bound(c.OUT / (source + suffix)) for name, suffix in (
        ('archive', '.tar.xz'), ('manifest', '.manifest.json'),
        ('verification', '.verification.json'))}
    manifest_bytes = Path(original['manifest']['path']).read_bytes()
    manifest = json.loads(manifest_bytes)
    checked = c.read(original['verification']['path'])
    assert manifest['status'] == checked['status'] == 'passed'
    assert manifest['all_members_reopened'] and checked['all_members_reopened']
    assert manifest['member_count'] == len(manifest['members']) == checked['member_count']
    assert checked['archive_sha256'] == original['archive']['sha256']
    assert checked['manifest_sha256'] == original['manifest']['sha256']
    assert checked['archive_bytes'] == original['archive']['bytes']
    accepted = c.read(c.OUT / 'compression-resources-457-source.json')['source_sha256']
    assert sources() == accepted
    names = [prefix + suffix for suffix in ('.tar.xz', '.manifest.json.xz', '.verification.json', '.json')]
    assert all(not (destination / name).exists() for name in names)
    compressed = lzma.compress(manifest_bytes, preset=6)
    assert lzma.decompress(compressed) == manifest_bytes
    copied = dict(
        archive=write(destination / names[0], Path(original['archive']['path']).read_bytes()),
        manifest=write(destination / names[1], compressed),
        verification=write(destination / names[2], Path(original['verification']['path']).read_bytes()))
    assert copied['archive']['sha256'] == original['archive']['sha256']
    assert copied['verification']['sha256'] == original['verification']['sha256']
    assert lzma.decompress(Path(copied['manifest']['path']).read_bytes()) == manifest_bytes
    assert all(c.bound(item['path']) == item for item in original.values())
    portable = {name: dict(item, path=Path(item['path']).name) for name, item in copied.items()}
    portable['manifest'].update(uncompressed_bytes=len(manifest_bytes),
                               uncompressed_sha256=original['manifest']['sha256'])
    cost = c.read(c.DEST / 'forward/summary.json')
    full43 = c.read(c.OUT / 'compression-resources-full43-primary-review-457.json')
    for path in (c.DEST / 'forward/summary.json', c.OUT / 'compression-resources-full43-primary-review-457.json'):
        member, = [item for item in manifest['members'] if item['path'] == str(path)]
        assert c.sha(path) == member['sha256'] and path.stat().st_size == member['bytes']
    assert cost['status'] == 'passed' and not cost['breaches']
    assert all(cell['baseline_observation'][key] == cell['candidate_observation'][key]
               for cell in cost['cells'] for key in ('serialized_bytes', 'serialized_sha256'))
    index = dict(schema_version='shardloom.completed_native_evidence_index.v1',
        status='completed_local_acceptance_hosted_integration_pending', **portable,
        verified_member_count=manifest['member_count'], all_archive_bytes_preserved=True,
        all_original_manifest_bytes_preserved=True, native_execution_repeated_for_copy=False,
        base_commit=manifest['base_commit'], source_files=manifest['source_files'],
        changed_source_files=len(manifest['changed_source_paths']), acceptance=manifest['acceptance'],
        lifecycle_cost=dict(cases=18, complete_operations_per_role=1368,
            breaches=cost['breaches'], decision=cost['decision'],
            process_timing={role:record['timing'] for role, record in cost['runs'].items()},
            all_serialized_bytes_equal=True, reverse_order_required=False,
            original_cached_candidate_rejected_before_timing=True),
        full43=dict(calls=43, repeats=1, complete_rows=full43['complete_rows'],
            complete_operation_seconds=full43['complete_operation_seconds'],
            supervised_suite_seconds=full43['supervised_suite_seconds'],
            reference_kind=full43['reference_kind'], hot_run_score=None),
        source_files_and_executables='Complete source hashes, changed source overlay, original five-test reproduction, build/executable identities, raw lifecycle and query outputs, and public workflow evidence are retained; bulk executable and dataset payloads are excluded.',
        companion_report='../native-compression-resources-2026-10-15.md',
        contract='../../architecture/native-compression-resources-2026-10-15.md',
        performance_superiority_claim=False, publication_attempted=False,
        limitations='Finite local compression admission. All archive members were reopened and every copied byte is unchanged. No installed-wheel, general allocation, process-RSS ceiling, all-platform or speedup claim. This source change follows the immutable 0.6.0 packages.')
    write(destination / names[3], (json.dumps(index, indent=2) + '\n').encode())
    assert sources() == accepted
    receipt = dict(status='passed', originals=original, copied=copied,
        index=c.bound(destination / names[3]), helper=c.bound(__file__),
        native_workload_executed=False, originals_removed=False)
    write(c.OUT / 'compression-evidence-copy-457.json', (json.dumps(receipt, indent=2) + '\n').encode())
    print(json.dumps(dict(status='passed', members=manifest['member_count'],
        copied_bytes=sum(item['bytes'] for item in copied.values()))))


if __name__ == '__main__':
    main()
