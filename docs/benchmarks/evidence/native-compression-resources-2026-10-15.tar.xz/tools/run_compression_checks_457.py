"""Run source-bound workspace and native acceptance for compression ownership."""
import json
from pathlib import Path
import re
import subprocess
import sys

import compression_cost_456c as c


def receipt(name):
    path = c.OUT / (name + '.json')
    value = c.read(path)
    log = path.with_suffix('.log')
    assert value['status'] == 'passed' and value['returncode'] == 0
    assert value['process_group_drained'] and value['direct_child_reaped']
    assert value['head'] == c.BASE and value['cwd'] == str(c.ROOT)
    assert value['log_sha256'] == c.sha(log)
    return dict(name=name, command=value['command'], receipt=c.bound(path),
                log=c.bound(log), seconds=value['seconds'])


def inspect_tests(item, native, frozen, inventory):
    raw = Path(item['log']['path']).read_text()
    groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', raw)
    assert groups and all(int(row[1]) == int(row[3]) == int(row[4]) == 0 for row in groups)
    ignored = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', raw, re.M)
    expected = inventory['tests'] if native else []
    assert sum(int(row[2]) for row in groups) == len(ignored)
    assert sorted(ignored) == sorted((row['test'], row['reason']) for row in expected)
    for entry in expected:
        path = c.ROOT / entry['source']
        assert c.sha(path) == frozen[entry['source']] == entry['source_sha256']
        lines = path.read_text().splitlines()
        position = entry['line'] - 1
        assert re.search(r'\bfn ' + re.escape(entry['test'].split('::')[-1]) + r'\(', lines[position])
        assert lines[position + 1 - len(entry['declaration']):position + 1] == entry['declaration']
        assert any(entry['reason'] in line for line in entry['declaration'])
        assert any('ignore' in line for line in entry['declaration'])
    item['tests'] = dict(passed=sum(int(row[0]) for row in groups), failed=0,
                        ignored=len(ignored), groups=len(groups), ignored_evidence=expected)


def main():
    protocol = c.read(c.DEST / 'protocol.json')
    c.verify(protocol)
    assert c.read(c.DEST / 'decision.json')['status'] == 'retained_pending_broad_acceptance'
    frozen = c.read(c.DEST / 'candidate-source.json')['source_sha256']
    inventory_path = c.OUT / 'compression-manual-tests-inventory-456.json'
    inventory = c.read(inventory_path)
    assert inventory['test_count'] == len(inventory['tests']) == 29
    assert c.sha(inventory['prior_report']) == inventory['prior_report_sha256']
    manifest = c.OUT / 'compression-check-source-457.json'
    c.save(manifest, dict(head=c.BASE, source_sha256=frozen,
        cost_decision=c.bound(c.DEST / 'decision.json'),
        workflow=c.bound(c.ROOT / '.github/workflows/ci.yml'), helper=c.bound(__file__)))
    checks = [
        ('fmt', 180, ['cargo', 'fmt', '--all', '--', '--check']),
        ('read-clippy', 1200, ['cargo', 'clippy', '--offline', '--locked', '-p', 'shardloom-vortex',
            '-p', 'shardloom-cli', '--all-targets', '--features', 'vortex-local-primitives', '--', '-D', 'warnings']),
        ('release-clippy', 1200, ['cargo', 'clippy', '--offline', '--locked', '-p', 'shardloom-vortex',
            '-p', 'shardloom-cli', '--all-targets', '--features', 'release-user-surfaces', '--', '-D', 'warnings']),
        ('workspace-clippy', 1200, ['cargo', 'clippy', '--workspace', '--all-targets', '--', '-D', 'warnings']),
        ('workspace-tests', 1800, ['cargo', 'test', '--workspace', '--all-targets', '--', '--test-threads=2']),
        ('native-tests', 3600, ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-vortex',
            '-p', 'shardloom-cli', '--all-targets', '--features',
            'vortex-local-primitives,vortex-write,universal-format-io', '--', '--test-threads=2']),
    ]
    c.save(c.OUT / 'compression-check-protocol-457.json', dict(checks=checks, source=c.bound(manifest),
        helper=c.bound(__file__), ignored_declarations=c.bound(inventory_path),
        separate_vendor_acceptance='The changed vendor owner interface and complete Zstd crate are checked separately; no vendor acceptance is inferred from these workspace gates.'))
    completed, failure = [], None
    try:
        for label, timeout, command in checks:
            c.verify(protocol)
            name = f'native-compression-{label}-457'
            subprocess.run([sys.executable, '-B', str(c.OUT / 'run_guarded.py'), '--name', name,
                '--timeout', str(timeout), '--', *command], cwd=c.ROOT, check=True)
            result = receipt(name)
            result['name'] = label
            if label.endswith('tests'):
                inspect_tests(result, label == 'native-tests', frozen, inventory)
            completed.append(result)
        c.verify(protocol)
    except BaseException as error:
        failure = f'{type(error).__name__}: {error}'
        raise
    finally:
        c.save(c.OUT / 'compression-checks-457.json', dict(status='passed' if failure is None else 'failed',
            source_manifest=c.bound(manifest), source_files=len(frozen),
            runtime_source_unchanged=c.sources(c.ROOT) == frozen, completed=completed, failure=failure))
    print(json.dumps(dict(status='passed', gates=len(completed), tests=[
        dict(name=row['name'], **{key:value for key,value in row['tests'].items() if key != 'ignored_evidence'})
        for row in completed if 'tests' in row])), flush=True)


if __name__ == '__main__':
    main()
