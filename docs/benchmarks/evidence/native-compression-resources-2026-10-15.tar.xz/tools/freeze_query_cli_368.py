"""Freeze a guarded release CLI and its before/after source identities."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sources, sha, save

sys.path.insert(0, str(ROOT / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def head():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('prepare', 'freeze'))
    parser.add_argument('--name', required=True)
    parser.add_argument('--build-receipt', type=Path)
    args = parser.parse_args()
    assert args.name.replace('-', '').isalnum()
    source_path = OUT / f'{args.name}-source.json'
    if args.operation == 'prepare':
        assert args.build_receipt is None
        record = dict(head=head(), source_sha256=sources())
        save(source_path, record)
        print(json.dumps(dict(status='prepared', source=str(source_path),
            sha256=sha(source_path), source_files=len(record['source_sha256']))), flush=True)
        return
    assert args.build_receipt is not None
    frozen = json.loads(source_path.read_text())
    assert head() == frozen['head'] and sources() == frozen['source_sha256']
    receipt_path = args.build_receipt.resolve(strict=True)
    receipt = json.loads(receipt_path.read_text())
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert receipt['head'] == frozen['head'] and receipt['cwd'] == str(ROOT)
    assert '--release' in receipt['command'] and 'release-user-surfaces' in receipt['command']
    assert receipt['environment']['CARGO_BUILD_JOBS'] == '2'
    log = receipt_path.with_suffix('.log')
    assert sha(log) == receipt['log_sha256']
    records = [json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
    artifacts = [row for row in records if row.get('reason') == 'compiler-artifact'
        and row.get('target', {}).get('name') == 'shardloom' and row.get('executable')]
    assert len(artifacts) == 1 and artifacts[0]['profile']['opt_level'] == '3'
    assert not artifacts[0]['profile']['test']
    artifact = Path(artifacts[0]['executable'])
    target = Path(receipt['environment']['CARGO_TARGET_DIR'])
    assert artifact.is_file() and not artifact.is_symlink()
    assert artifact.parent == target / 'release'
    destination = require_local_path(OUT / f'{args.name}-release', Path.home(), sys.platform)
    assert not destination.exists()
    check_budgets(OUT, destination, OUT / 'logs', min_free_bytes=12 * GIB,
        reserve_bytes=artifact.stat().st_size + 128 * MIB,
        max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    artifact_hash = sha(artifact)
    destination.mkdir()
    cli = destination / 'shardloom'
    shutil.copy2(artifact, cli)
    assert sha(cli) == sha(artifact) == artifact_hash
    assert head() == frozen['head'] and sources() == frozen['source_sha256']
    manifest = dict(schema_version='shardloom.query_cli_release_artifacts.v1',
        status='passed', build_profile='release', **frozen,
        source_manifest=dict(path=str(source_path), sha256=sha(source_path)),
        freeze_helper=dict(path=str(Path(__file__).resolve()), sha256=sha(__file__)),
        cli=dict(path=str(cli), sha256=artifact_hash, bytes=cli.stat().st_size,
            build_receipt=str(receipt_path), build_receipt_sha256=sha(receipt_path),
            build_log=str(log)))
    manifest_path = OUT / f'{args.name}-release.json'
    save(manifest_path, manifest)
    print(json.dumps(dict(status='passed', manifest=str(manifest_path),
        sha256=sha(manifest_path), cli=manifest['cli'],
        source_files=len(frozen['source_sha256']))), flush=True)


if __name__ == '__main__':
    main()
