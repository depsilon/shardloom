"""Package complete compression evidence, including original failures and rejected setup."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile

import compression_cost_456c as c
from freeze_native_release_298 import sources
from package_selection_acceptance_409 import Members, need, receipt_pair, sha_file, sha_stream, verify

OUTPUTS = tuple(c.OUT / ('compression-resources-evidence-457.' + suffix)
                for suffix in ('tar.xz', 'manifest.json', 'verification.json'))
LIMIT = 192 << 20


def add(members, path, prefix, role):
    path = Path(path)
    relative = (path.relative_to(c.ROOT).as_posix() if path.is_relative_to(c.ROOT)
                else path.relative_to(c.OUT).as_posix() if path.is_relative_to(c.OUT)
                else path.name)
    members.add(path, prefix + '/' + relative, 'evidence', path.parent, role)


def main():
    partials = tuple(path.with_name('.' + path.name + '.partial') for path in OUTPUTS)
    for path in (*OUTPUTS, *partials):
        need(not path.exists() and not path.is_symlink(), f'output exists: {path}')
    cost_protocol = c.read(c.DEST / 'protocol.json')
    c.verify(cost_protocol)
    decision = c.read(c.DEST / 'decision.json')
    need(decision['status'] == 'retained_pending_broad_acceptance' and not decision['repeated_breaches'],
         'cost decision requires diagnosis')
    required = [
        'compression-acceptance-457b.json', 'compression-checks-457.json',
        'compression-resources-457-release.json', 'compression-native-artifacts-457.json',
        'compression-direct-457.json', 'compression-runtime-457.json',
        'compression-public-review-457.json', 'compression-resources-full43-primary-review-457.json',
        'compression-vendor-457/summary.json', 'compression-original-source-verification-457.json',
        'compression-vendor-count-correction-457.json',
    ]
    reports = {name: c.read(c.OUT / name) for name in required}
    need(all(value['status'] == 'passed' for value in reports.values()), 'acceptance incomplete')
    vendor = reports['compression-vendor-count-correction-457.json']
    need(vendor['total_passed'] == 72 and vendor['actual_passed_counts'] == [10, 7, 55],
         'vendor test inventory changed')
    need(reports['compression-acceptance-457b.json']['reused_vendor_acceptance'] ==
         c.bound(c.OUT / 'compression-vendor-count-correction-457.json'),
         'vendor reuse proof changed')
    release = reports['compression-resources-457-release.json']
    native = reports['compression-native-artifacts-457.json']
    accepted = release['source_sha256']
    need(sources() == accepted == native['source_sha256'], 'full source identity changed')
    checks = reports['compression-checks-457.json']
    need(checks['runtime_source_unchanged'] and len(checks['completed']) == 6,
         'required validation gates incomplete')
    test_counts = {row['name']: row['tests'] for row in checks['completed'] if 'tests' in row}
    need(test_counts['workspace-tests']['ignored'] == 0 and test_counts['native-tests']['ignored'] == 29,
         'unexpected skipped-test scope')
    native_log = Path(next(row['log']['path'] for row in checks['completed'] if row['name'] == 'native-tests')).read_text()
    for name in cost_protocol['binary_inventory_delta']['added_candidate_tests']:
        need(f'test {name} ... ok' in native_log, f'new regression did not pass: {name}')
    direct = reports['compression-direct-457.json']
    need(direct['tests'] == 80 and direct['failures'] == direct['errors'] == direct['skipped'] == 0,
         'direct binding acceptance incomplete')
    inventory = c.read(c.OUT / 'compression-public-runner-inventory-457.json')
    need(sorted(direct['test_names']) == sorted(inventory['direct_python']['current_test_identity_reconciliation']['identities']),
         'direct test identity set changed')
    runtime = reports['compression-runtime-457.json']
    public = reports['compression-public-review-457.json']
    full43 = reports['compression-resources-full43-primary-review-457.json']
    need(runtime['public_cases'] == public['cases'] == 757 and public['families'] == 19
         and public['complete_case_log_records_equal'], 'complete public scope missing')
    need(full43['queries'] == full43['calls'] == 43 and full43['repeats'] == 1
         and full43['all_values_and_schemas_reopened'] and full43['resources_and_no_fallback'],
         'complete one-pass query proof missing')

    members, exclusions = Members(), []
    for name in required:
        add(members, c.OUT / name, 'acceptance', 'closed source-bound acceptance')
    for path in sorted(c.OUT.glob('compression-*.json')):
        if path.name.startswith('compression-resources-evidence-'):
            continue
        value = c.read(path)
        if 'process_group_drained' in value and 'command' in value:
            receipt_pair(path, members, 'history')
        else:
            add(members, path, 'history', 'source, design, acceptance or failure record')
    for path in sorted(c.OUT.glob('native-compression-*.json')):
        receipt_pair(path, members, 'guards', 'passed')
    for pattern in ('post060-zstd-*.json', 'post060-pinned-compressor-*.json',
                    'post060-host-allocator-*.json', 'post060-compression-inventory*.json'):
        for path in sorted(c.OUT.glob(pattern)):
            add(members, path, 'research', 'pinned provider source evidence; design decisions retain their original dates')
    for path in sorted(c.OUT.glob('*compression*457.py')):
        add(members, path, 'tools', 'executed acceptance or packaging helper')
    for name in ('compression_cost_456.py', 'compression_cost_456c.py',
                 'freeze_query_cli_368.py', 'freeze_native_release_298.py',
                 'run_guarded.py', 'package_selection_acceptance_409.py'):
        add(members, c.OUT / name, 'tools', 'reproduction and evidence helper')
    for item in cost_protocol['helpers']:
        verify(Path(item['path']), item['sha256'], item['bytes'])
        add(members, item['path'], 'tools', 'frozen cost helper')
    for name in ('compression-original-regressions-454.rs', 'compression-original-parent-454.rs',
                 'compression-owned-vendor-lock-457.lock'):
        add(members, c.OUT / name, 'history', 'original source or generated standalone lock')
    for folder in ('compression-cost-456', 'compression-cost-456b', 'compression-cost-456c'):
        members.tree(c.OUT / folder, 'cost/' + folder, 'cost',
                     'complete accepted or superseded setup; immutable disposition retained', exclusions)
    members.tree(c.OUT / 'compression-vendor-457', 'vendor-tests', 'vendor-tests',
                 'exact standalone vendor source copies, locks and acceptance', exclusions)
    for record in (release['cli'], native['binding']):
        verify(Path(record['path']), record['sha256'], record['bytes'])
        exclusions.append(dict(**record, reason='verified native executable; bulk payload excluded'))

    changed = subprocess.check_output(['git', 'diff', '--name-only', c.BASE], cwd=c.ROOT, text=True).splitlines()
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=c.ROOT, text=True).splitlines()
    selected = sorted(set(changed + untracked) & set(accepted))
    for name in selected:
        members.add(c.ROOT / name, 'source-overlay/' + name, 'repository', c.ROOT,
                    'complete accepted source overlay', accepted[name])
    patch = c.OUT / 'compression-source-overlay-457.patch'
    with patch.open('xb') as stream:
        subprocess.run(['git', 'diff', '--binary', c.BASE], cwd=c.ROOT, stdout=stream, check=True)
    add(members, patch, 'source-overlay', 'tracked source and documentation patch; new runtime files separately retained')
    for name in (c.HARNESS, 'shardloom-vortex/src/native_provider_zstd_tests.rs'):
        members.add(c.CONTROL / name, 'baseline-overlay/' + name, 'baseline', c.CONTROL,
                    'identical cost harness and its exact baseline module attachment')
    add(members, c.ROOT / 'docs/architecture/native-compression-resources-2026-10-15.md',
        'contract', 'premeasurement frozen acceptance contract')

    members.tree(c.OUT / 'compression-public-457', 'public', 'public',
                 'complete public logs, value files, pressure rows and summaries', exclusions, omit_outputs=True)
    for key in ('artifacts', 'value_files', 'envelopes', 'pressure_files'):
        for item in public[key]:
            verify(Path(item['path']), item['sha256'], item['bytes'])
    add(members, public['complete_case_set_comparison']['path'], 'public-inputs', 'unchanged case inventory')
    members.tree(Path(full43['summary']['path']).parent, 'full43', 'full43',
                 'all 43 complete query outputs, timing, PID and host observations', exclusions)
    admission = c.read(full43['admission']['path'])
    for item in (admission['reference'], admission['queries'], admission['provenance']):
        verify(Path(item['path']), item['sha256'], item['bytes'])
        add(members, item['path'], 'full43-inputs', 'frozen correctness and input provenance')
    exclusions.append(dict(path=admission['source'], sha256=admission['source_sha256'],
        bytes=admission['source_generation']['st_size'], reason='resident input hashed before and after the closed run; not copied or rehashed in packaging'))

    ordered = sorted(members.paths.values(), key=lambda item: item.name)
    raw_bytes = sum(item.size for item in ordered)
    need(raw_bytes <= LIMIT, 'archive exceeds 192 MiB raw-input budget')
    storage = c.storage(c.OUT / 'logs', raw_bytes + 64 * c.MIB)
    created, published = [], []
    try:
        with partials[0].open('xb') as output:
            created.append(partials[0])
            with tarfile.open(fileobj=output, mode='w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
                for item in ordered:
                    verify(item.path, item.digest, item.size)
                    info = tarfile.TarInfo(item.name)
                    info.size, info.mode, info.mtime = item.size, 0o644, 0
                    with item.path.open('rb') as stream:
                        archive.addfile(info, stream)
                    verify(item.path, item.digest, item.size)
        seen = set()
        with tarfile.open(partials[0], mode='r|xz') as archive:
            for entry in archive:
                need(entry.isfile() and entry.name in members.names and entry.name not in seen,
                     f'invalid member: {entry.name}')
                item = members.paths[members.names[entry.name]]
                stream = archive.extractfile(entry)
                need(stream is not None and sha_stream(stream) == (item.size, item.digest),
                     f'archive mismatch: {entry.name}')
                seen.add(entry.name)
        need(seen == set(members.names), 'incomplete archive membership')
        for item in ordered:
            verify(item.path, item.digest, item.size)
        c.verify(cost_protocol)
        need(sources() == accepted, 'source changed while packaging')
        size, digest = sha_file(partials[0])
        manifest = dict(status='passed', kind='native_compression_resource_acceptance', base_commit=c.BASE,
            source_manifest=c.bound(c.OUT / 'compression-resources-457-source.json'),
            source_files=len(accepted), changed_source_paths=selected,
            archive=dict(path=str(OUTPUTS[0]), bytes=size, sha256=digest),
            members=[dict(path=str(item.path), archive_path=item.name, bytes=item.size,
                          sha256=item.digest, roles=item.roles) for item in ordered],
            member_count=len(ordered), raw_bytes=raw_bytes, raw_limit_bytes=LIMIT, exclusions=exclusions,
            acceptance=dict(broad_gates=6, workspace_tests=test_counts['workspace-tests']['passed'],
                native_tests=test_counts['native-tests']['passed'], native_ignored=29,
                new_native_regressions=19, vendor_tests=72, direct_tests=80,
                public_cases=757, public_families=19, full43_calls=43,
                full43_rows=full43['complete_rows'], cost_cells=18,
                cost_operations_per_role=1368, repeated_cost_breaches=0),
            storage=storage, all_members_reopened=True, performance_claim_allowed=False,
            hosted_integration_complete=False, publication_attempted=False,
            limitations='Finite local source-package/native acceptance. No installed-wheel, general allocation, process-RSS ceiling, all-platform, speedup or release-readiness claim. Full43 is one sequential observation against retained native regression values. Historical candidate cache reuse was rejected before timing.')
        encoded = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
        verification = dict(status='passed', all_members_reopened=True, member_count=len(seen),
            archive_bytes=size, archive_sha256=digest, manifest_sha256=hashlib.sha256(encoded).hexdigest())
        for temporary, value in zip(partials[1:], (encoded, (json.dumps(verification, indent=2, sort_keys=True) + '\n').encode()), strict=True):
            with temporary.open('xb') as stream:
                created.append(temporary)
                stream.write(value)
        for temporary, output in zip(partials, OUTPUTS, strict=True):
            os.link(temporary, output)
            published.append(output)
            temporary.unlink()
            created.remove(temporary)
        print(json.dumps(dict(status='passed', archive=str(OUTPUTS[0]), members=len(seen),
            archive_bytes=size, archive_sha256=digest, raw_bytes=raw_bytes)), flush=True)
    except BaseException:
        for path in published:
            path.unlink(missing_ok=True)
        raise
    finally:
        for path in created:
            path.unlink(missing_ok=True)


if __name__ == '__main__':
    main()
