"""Check exact changed vendor sources in isolated, guarded manifest copies."""
import json
from pathlib import Path
import shutil
import subprocess

import compression_cost_456c as c


protocol = c.read(c.DEST / 'protocol.json')
c.verify(protocol)
destination = c.OUT / 'compression-vendor-457'
assert not destination.exists()
c.storage(destination, 256 * c.MIB)
destination.mkdir()
copies = {}
for crate in ('vortex-array', 'vortex-zstd'):
    original = c.ROOT / 'vendor' / crate
    target = destination / crate
    paths = [path for path in original.rglob('*') if path.is_file()
             and path.relative_to(original).as_posix() != 'Cargo.lock']
    assert all(not path.is_symlink() for path in paths)
    assert sum(path.stat().st_size for path in paths) < 32 * c.MIB
    copied = {path.relative_to(original).as_posix(): c.sha(path) for path in paths}
    for path in paths:
        output = target / path.relative_to(original)
        output.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, output)
    assert all(c.sha(target / name) == digest for name, digest in copied.items())
    shutil.copy2(c.ROOT / 'Cargo.lock', target / 'Cargo.lock')
    copies[crate] = dict(source=str(original), target=str(target), files=copied)

array = destination / 'vortex-array/Cargo.toml'
zstd = destination / 'vortex-zstd/Cargo.toml'
commands = [
    ['rustfmt', '--edition', '2024', '--check', *map(str, [
        c.ROOT / 'vendor/vortex-array/src/memory.rs',
        c.ROOT / 'vendor/vortex-zstd/src/array.rs',
        c.ROOT / 'vendor/vortex-zstd/src/lib.rs',
        c.ROOT / 'vendor/vortex-zstd/src/compression_resources.rs',
        c.ROOT / 'vendor/vortex-zstd/src/compression_resources_tests.rs',
    ])],
    ['cargo', 'test', '--offline', '--manifest-path', str(array),
     '--features', '_test-harness,table-display', '--lib', 'array::owner_tests::',
     '--', '--test-threads=1'],
    ['cargo', 'test', '--offline', '--manifest-path', str(array),
     '--features', '_test-harness,table-display', '--lib', 'memory::tests::',
     '--', '--test-threads=1'],
    ['cargo', 'test', '--offline', '--manifest-path', str(zstd),
     '--config', 'patch.crates-io.vortex-array.path=' + json.dumps(str(c.ROOT / 'vendor/vortex-array')),
     '--features', 'vortex-array/table-display', '--lib', '--', '--test-threads=1'],
]
manifest = dict(source=c.bound(c.DEST / 'candidate-source.json'),
                root_lock=c.bound(c.ROOT / 'Cargo.lock'), copies=copies,
                commands=commands, expected_passed_counts=[17, 7, 55], helper=c.bound(__file__))
c.save(destination / 'protocol.json', manifest)
completed, failure = [], None
try:
    for command in commands:
        c.verify(protocol)
        subprocess.run(command, cwd=c.ROOT, check=True)
        completed.append(command)
    c.verify(protocol)
except BaseException as error:
    failure = f'{type(error).__name__}: {error}'
    raise
finally:
    unchanged = all(c.sha(Path(copy['target']) / name) == digest
                    and c.sha(Path(copy['source']) / name) == digest
                    for copy in copies.values() for name, digest in copy['files'].items())
    locks = {crate: c.bound(Path(copy['target']) / 'Cargo.lock') for crate, copy in copies.items()}
    c.save(destination / 'summary.json', dict(status='passed' if failure is None and unchanged else 'failed',
        protocol=c.bound(destination / 'protocol.json'), completed=completed,
        copy_and_source_unchanged=unchanged, standalone_locks=locks, failure=failure))
    assert unchanged
