"""Run vendor and public acceptance sequentially on the accepted compression source."""
import json
from pathlib import Path
import re
import subprocess
import sys

import compression_cost_456c as c


def main():
    cost_protocol = c.read(c.DEST / 'protocol.json')
    c.verify(cost_protocol)
    assert c.read(c.DEST / 'decision.json')['status'] == 'retained_pending_broad_acceptance'
    checks = c.read(c.OUT / 'compression-checks-457.json')
    assert checks['status'] == 'passed' and checks['runtime_source_unchanged']
    assert len(checks['completed']) == 6
    helper = lambda name: [sys.executable, '-B', str(c.OUT / name)]
    stages = [
        ('vendor_provider_gates', helper('run_guarded.py') +
            ['--name', 'native-compression-vendor-457', '--timeout', '2100', '--',
             *helper('run_compression_vendor_457.py')]),
        ('cli_source_freeze', helper('freeze_query_cli_368.py') +
            ['prepare', '--name', 'compression-resources-457']),
        ('cli_release_build', helper('run_guarded.py') +
            ['--name', 'native-compression-release-build-457', '--timeout', '2400', '--',
             'cargo', 'build', '--offline', '--locked', '--release', '-p', 'shardloom-cli',
             '--bin', 'shardloom', '--features', 'release-user-surfaces', '--message-format=json']),
        ('cli_artifact_freeze', helper('freeze_query_cli_368.py') +
            ['freeze', '--name', 'compression-resources-457', '--build-receipt',
             str(c.OUT / 'native-compression-release-build-457.json')]),
        ('direct_and_public_workflows', helper('run_compression_runtime_457.py')),
        ('public_evidence_reopening', helper('verify_compression_public_457.py')),
        ('retained_full43_once', helper('run_compression_full43_457.py') +
            ['--max-log-mib', '1024', '--max-run-log-mib', '256']),
    ]
    helpers = [
        'run_compression_acceptance_457.py', 'run_compression_vendor_457.py',
        'run_compression_checks_457.py', 'run_compression_runtime_457.py',
        'verify_compression_public_457.py', 'run_compression_full43_457.py',
        'freeze_query_cli_368.py', 'freeze_native_release_298.py', 'run_guarded.py',
    ]
    identities = {name: c.bound(c.OUT / name) for name in helpers}
    protocol_path = c.OUT / 'compression-acceptance-protocol-457.json'
    c.save(protocol_path, dict(status='frozen_before_vendor_and_public_acceptance',
        stages=stages, helpers=identities, cost_decision=c.bound(c.DEST / 'decision.json'),
        workspace_and_native_checks=c.bound(c.OUT / 'compression-checks-457.json'),
        source_manifest=c.bound(c.DEST / 'candidate-source.json'),
        note='Serial guarded stages. Direct source-package checks are not installed-wheel proof. Full43 executes every query once on the retained resident Vortex input with exact native regression values; no speedup claim or artificial pacing.'))
    final_files = [
        'compression-checks-457.json', 'compression-vendor-457/summary.json',
        'compression-resources-457-release.json', 'compression-native-artifacts-457.json',
        'compression-runtime-457.json', 'compression-public-review-457.json',
        'compression-resources-full43-primary-review-457.json',
    ]
    completed, failure = [], None
    try:
        for label, command in stages:
            c.verify(cost_protocol)
            assert all(c.bound(c.OUT / name) == item for name, item in identities.items())
            print(json.dumps(dict(stage=label, status='starting')), flush=True)
            subprocess.run(command, cwd=c.ROOT, check=True)
            if label == 'vendor_provider_gates':
                receipt = c.read(c.OUT / 'native-compression-vendor-457.json')
                log = c.OUT / 'native-compression-vendor-457.log'
                assert receipt['status'] == 'passed' and receipt['returncode'] == 0
                assert receipt['process_group_drained'] and receipt['direct_child_reaped']
                assert c.sha(log) == receipt['log_sha256']
                groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', log.read_text())
                assert [int(row[0]) for row in groups] == [17, 7, 55]
                assert all(int(row[1]) == int(row[2]) == int(row[3]) == 0 for row in groups)
                assert groups[-1][-1] == '0'
                assert c.read(c.OUT / 'compression-vendor-457/summary.json')['copy_and_source_unchanged']
            completed.append(dict(stage=label, command=command, returncode=0))
            print(json.dumps(dict(stage=label, status='passed')), flush=True)
        for name in final_files:
            assert c.read(c.OUT / name)['status'] == 'passed', name
        c.verify(cost_protocol)
        assert all(c.bound(c.OUT / name) == item for name, item in identities.items())
    except BaseException as error:
        failure = f'{type(error).__name__}: {error}'
        raise
    finally:
        c.save(c.OUT / 'compression-acceptance-457.json', dict(
            status='passed' if failure is None else 'failed', failure=failure,
            protocol=c.bound(protocol_path), completed=completed,
            sources_unchanged=c.sources(c.ROOT) == c.read(c.DEST / 'candidate-source.json')['source_sha256'],
            evidence=[c.bound(c.OUT / name) for name in final_files] if failure is None else [],
            performance_claim_allowed=False, publication_attempted=False))


if __name__ == '__main__':
    main()
