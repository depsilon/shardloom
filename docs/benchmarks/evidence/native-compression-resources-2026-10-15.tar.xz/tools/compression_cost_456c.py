"""Freeze and compare the identical complete native compression lifecycle harness."""
import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import re
import shutil
import statistics
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
DEST = OUT / 'compression-cost-456c'
ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
CONTROL = Path('/Users/dylan/.codex/worktrees/ship-drop-control-20260919/shardloom-local-repo')
BASE = 'e8611a3c00af2a7b3f3f742c8b7128c3a258fbc7'
HARNESS = 'shardloom-vortex/src/native_provider_zstd_compression_cost_tests.rs'
TEST = 'native_provider_memory::zstd_tests::compression_cost_tests::native_zstd_complete_compression_cost_screen'
SUPERVISOR = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
UAT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
sys.path[:0] = [str(ROOT / 'scripts'), str(OUT), '/Users/dylan/LocalData/shardloom/release-0.3.3-20260930']
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
from run_clickbench_paired_query_uat import host_snapshot
from release_validation_guard import WorkloadGuard


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def bound(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def sources(root):
    names = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=root).decode().split('\0')
    return {name: sha(root / name) for name in sorted(set(names))
            if name and (name.endswith(('.rs', '.py', 'Cargo.toml'))
                         or name == 'Cargo.lock' or name.startswith('.cargo/'))
            and (root / name).is_file()}


def storage(logs, reserve=128 * MIB):
    require_local_path(DEST, Path.home(), sys.platform)
    return check_budgets(OUT, DEST / 'reserved-artifact', logs,
        min_free_bytes=12 * GIB, reserve_bytes=reserve,
        max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB,
        max_run_log_bytes=192 * MIB)


def prepare(role):
    root = ROOT if role == 'candidate' else CONTROL
    storage(DEST)
    DEST.mkdir(exist_ok=True)
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
    if role == 'baseline':
        assert head == BASE
    record = dict(root=str(root), head=head, base=BASE, source_sha256=sources(root),
                  diff=subprocess.check_output(['git', 'diff', '--binary', BASE], cwd=root, text=True),
                  status=subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True),
                  prepared_at=time.time())
    save(DEST / (role + '-source.json'), record)
    print(json.dumps(dict(status='prepared', role=role, files=len(record['source_sha256']))), flush=True)


def freeze_build(role, receipt_path):
    source = read(DEST / (role + '-source.json'))
    assert sources(Path(source['root'])) == source['source_sha256']
    receipt = read(receipt_path)
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert '--release' in receipt['command'] and '--no-run' in receipt['command']
    assert 'release-user-surfaces' in receipt['command']
    log = Path(receipt_path).with_suffix('.log')
    assert sha(log) == receipt['log_sha256']
    paths = re.findall(r'Executable unittests src/lib.rs \(([^)]+)\)', log.read_text())
    original, = paths
    original = Path(receipt['cwd']) / original
    target = DEST / ('shardloom-compression-cost-' + role)
    storage(DEST, original.stat().st_size + 128 * MIB)
    assert not target.exists()
    identity = sha(original)
    shutil.copy2(original, target)
    assert sha(target) == sha(original) == identity
    listing = subprocess.check_output([str(target), '--list'], text=True)
    assert TEST + ': test' in listing
    has_regressions = 'native_zstd_compression_primitive_admission_and_retention' in listing
    assert has_regressions == (role == 'candidate'), 'wrong role binary from shared Cargo cache'
    inventory = DEST / (role + '-test-list.txt')
    with inventory.open('x') as stream:
        stream.write(listing)
    save(DEST / (role + '-build.json'), dict(status='passed', role=role,
        source=bound(DEST / (role + '-source.json')), build_receipt=bound(receipt_path),
        build_log=bound(log), binary=bound(target), command=receipt['command'],
        environment=receipt['environment'], test_inventory=bound(inventory)))
    print(json.dumps(dict(status='frozen_build', role=role, bytes=target.stat().st_size)), flush=True)


def freeze_protocol():
    identities = {}
    for role in ('baseline', 'candidate'):
        manifest = DEST / (role + '-build.json')
        value = read(manifest)
        source = read(value['source']['path'])
        assert sources(Path(source['root'])) == source['source_sha256']
        identities[role] = dict(manifest=bound(manifest), **value)
    assert sha(ROOT / HARNESS) == sha(CONTROL / HARNESS)
    assert identities['baseline']['binary']['sha256'] != identities['candidate']['binary']['sha256']
    test_names = {role: {line.removesuffix(': test') for line in
        Path(identity['test_inventory']['path']).read_text().splitlines()
        if line.endswith(': test')} for role, identity in identities.items()}
    added = test_names['candidate'] - test_names['baseline']
    assert not test_names['baseline'] - test_names['candidate']
    expected = {
        'external_reservations_share_the_payload_grant_and_release_without_a_buffer',
        'external_reservation_wrapper_keeps_both_foreign_and_structural_owners',
    }
    for name in ('native_provider_zstd_compression_tests.rs',
                 'native_provider_zstd_compression_values_tests.rs',
                 'native_provider_zstd_compression_allocator_tests.rs'):
        expected.update(re.findall(r'^fn (native_zstd_\w+)\(',
            (ROOT / 'shardloom-vortex/src' / name).read_text(), re.M))
    assert len(added) == len(expected) == 19
    assert {name.split('::')[-1] for name in added} == expected
    helpers = [Path(__file__), SUPERVISOR, OUT / 'run_guarded.py',
        Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py')]
    helpers += [ROOT / 'scripts' / name for name in (
        'timed_native_command.py', 'run_clickbench_query_uat.py',
        'run_clickbench_paired_query_uat.py', 'local_uat_storage.py')]
    assert sha(SUPERVISOR) == '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97'
    protocol = dict(schema='shardloom.compression_lifecycle_cost.v1', frozen_at=time.time(),
        identities=identities, helpers=[bound(p) for p in helpers],
        contract=bound(ROOT / 'docs/architecture/native-compression-resources-2026-10-15.md'),
        test_harness=bound(ROOT / HARNESS), test_name=TEST,
        binary_inventory_delta=dict(retained_tests=len(test_names['baseline']),
                                    added_candidate_tests=sorted(added)),
        cases=[dict(kind=kind, rows=rows, encoding=encoding,
                    frame_rows=128 if rows == 4096 else 1024, grant_bytes=64 * MIB)
               for kind in ('nullable_i64', 'nullable_utf8', 'nullable_binary')
               for rows in (4096, 65536)
               for encoding in ('canonical', 'zstd_no_dictionary', 'zstd_dictionary')],
        samples_per_case=3, operations_per_sample=25, recorded_warmups_per_case=1,
        elapsed_gate=dict(relative=.10, absolute_seconds_per_operation=.0001),
        process_cpu_gate=dict(relative=.10, absolute_seconds=1),
        process_rss_gate=dict(relative=.25, absolute_bytes=64 * MIB),
        repeat_rule='Any forward breach triggers the complete reverse order. Repeated same-cell/metric breaches require diagnosis before retention.',
        operation_clock='Session creation, encode/train, native serialization and SHA256, producer close, fresh-session reopen/decode, full reference-value/null checking, all owned cleanup. Fixture/reference construction is outside.',
        process_clock='Native test executable creation through exit, including all fixtures, warmups, samples and output; separate from supervised cohort duration.',
        cache='Input is generated in memory; ordinary allocator and OS caches are uncontrolled. No pacing, cache flush, or battery/thermal admission.',
        performance_claim_allowed=False, platform=platform.platform(), logical_cpus=os.cpu_count(),
        physical_memory_bytes=os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES'),
        rust=subprocess.check_output(['/Users/dylan/.cargo/bin/rustup','run','1.99.0','rustc','-Vv'],text=True))
    save(DEST / 'protocol.json', protocol)
    print(json.dumps(dict(status='frozen_protocol', cases=18, operations_per_executable=1368)), flush=True)


def verify(protocol):
    for item in protocol['helpers'] + [protocol['contract'], protocol['test_harness']]:
        assert bound(item['path']) == item
    for role, identity in protocol['identities'].items():
        for name in ('manifest', 'source', 'build_receipt', 'build_log', 'binary', 'test_inventory'):
            assert bound(identity[name]['path']) == identity[name], (role, name)
        source = read(identity['source']['path'])
        assert sources(Path(source['root'])) == source['source_sha256'], role
        if 'source_rebinding' in identity:
            proof = identity['source_rebinding']
            for key in ('original_build', 'original_source'):
                assert bound(proof[key]['path']) == proof[key]
            original = read(proof['original_build']['path'])
            assert read(proof['original_source']['path'])['source_sha256'] == source['source_sha256']
            assert original['binary']['sha256'] == identity['binary']['sha256']
            assert all(original[key] == identity[key] for key in
                       ('build_receipt', 'build_log', 'command', 'environment'))


def extract(path, protocol):
    records = [json.loads(line.split('COMPRESSION_COST ', 1)[1])
               for line in Path(path).read_text().splitlines() if 'COMPRESSION_COST ' in line]
    assert len(records) == len(protocol['cases']) * 4
    cells = []
    for index, case in enumerate(protocol['cases']):
        rows = records[index * 4:index * 4 + 4]
        assert all(all(row[key] == value for key, value in case.items()) for row in rows)
        assert [row['phase'] for row in rows] == ['warmup'] + ['measured'] * 3
        assert [row['sample'] for row in rows[1:]] == [0, 1, 2]
        assert [len(row['nanoseconds']) for row in rows] == [1, 25, 25, 25]
        assert all(type(ns) is int and ns > 0 for row in rows for ns in row['nanoseconds'])
        assert all(row['observation'] == rows[0]['observation'] for row in rows)
        cells.append(dict(**case, records=rows, observation=rows[0]['observation'],
                          median_sample_ns=statistics.median(sum(row['nanoseconds']) for row in rows[1:])))
    return cells


def run(order):
    protocol = read(DEST / 'protocol.json')
    verify(protocol)
    logs = DEST / order
    assert not logs.exists()
    storage(logs)
    workload = WorkloadGuard()
    workload.check()
    lock = UAT / '.ingest-uat.lock'
    spec = importlib.util.spec_from_file_location('compression_supervisor', SUPERVISOR)
    supervisor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(supervisor)
    report = dict(status='running', order=order, protocol=bound(DEST / 'protocol.json'), runs={})
    logs.mkdir()
    lock.mkdir()
    started = time.perf_counter()
    try:
        roles = ('baseline', 'candidate') if order == 'forward' else ('candidate', 'baseline')
        for role in roles:
            verify(protocol)
            prefix = logs / role
            record = dict(status='running', role=role, host_before=host_snapshot(), observations=[])
            timing, pid_file = prefix.with_suffix('.timing.json'), prefix.with_suffix('.pid')
            command = [sys.executable, '-B', str(ROOT / 'scripts/timed_native_command.py'),
                '--timing', str(timing), '--pid-file', str(pid_file), '--shared-process-group', '--',
                protocol['identities'][role]['binary']['path'], TEST, '--exact', '--ignored',
                '--nocapture', '--test-threads=1']
            record['command'] = command
            last = 0.0
            def guard():
                nonlocal last
                workload.check(record.get('pid'))
                if time.monotonic() - last < 2:
                    return
                record['storage'] = storage(logs)
                observation = host_snapshot()
                if pid_file.exists():
                    native_pid = int(pid_file.read_text())
                    value = subprocess.run(['ps','-p',str(native_pid),'-o','pid=,ppid=,rss=,%cpu=,time='],
                        capture_output=True,text=True,timeout=10)
                    observation['native_process_sample'] = value.stdout.strip()
                record['observations'].append(observation)
                last = time.monotonic()
            print(json.dumps(dict(order=order, role=role, status='starting')), flush=True)
            try:
                with prefix.with_suffix('.stdout.txt').open('xb') as stdout, prefix.with_suffix('.stderr.txt').open('xb') as stderr:
                    code = supervisor.run(command, cwd=ROOT,
                        env=dict(os.environ, SHARDLOOM_COMPRESSION_COST='frozen-v1', PYTHONDONTWRITEBYTECODE='1'),
                        output=stdout,error_output=stderr, timeout=900,evidence=record,guard=guard,max_output_bytes=8*MIB)
                assert code == 0
                record['timing'] = read(timing)
                assert record['timing']['returncode'] == 0
                record['cells'] = extract(prefix.with_suffix('.stdout.txt'), protocol)
                record['status'] = 'passed'
            except BaseException as error:
                record.update(status='failed', error=f'{type(error).__name__}: {error}')
                raise
            finally:
                record['host_after'] = host_snapshot()
                record['files'] = [bound(prefix.with_suffix(suffix)) for suffix in
                    ('.stdout.txt','.stderr.txt','.timing.json','.pid') if prefix.with_suffix(suffix).exists()]
                report['runs'][role] = record
                save(prefix.with_suffix('.json'),record)
            print(json.dumps(dict(order=order, role=role, status='passed', seconds=record['timing']['seconds'])),flush=True)
        verify(protocol)
        breaches, cells = [], []
        for baseline, candidate in zip(report['runs']['baseline']['cells'], report['runs']['candidate']['cells'], strict=True):
            identity = {k:baseline[k] for k in ('kind','rows','encoding')}
            for key in ('serialized_bytes','serialized_sha256'):
                assert baseline['observation'][key] == candidate['observation'][key], (identity,key)
            a,b = baseline['median_sample_ns'],candidate['median_sample_ns']
            breach = b > a + max(.10*a, 25*100_000)
            if breach:
                breaches.append(dict(**identity,metric='elapsed'))
            cells.append(dict(**identity,baseline_ns_per_operation=a/25,
                candidate_ns_per_operation=b/25,relative_change=b/a-1,breach=breach,
                baseline_observation=baseline['observation'],candidate_observation=candidate['observation']))
        a,b=(report['runs'][role]['timing'] for role in ('baseline','candidate'))
        acpu=a['user_cpu_seconds']+a['system_cpu_seconds']
        bcpu=b['user_cpu_seconds']+b['system_cpu_seconds']
        if bcpu > acpu + max(.10*acpu,1):
            breaches.append(dict(metric='process_cpu'))
        if b['peak_rss_bytes'] > a['peak_rss_bytes']+max(.25*a['peak_rss_bytes'],64*MIB):
            breaches.append(dict(metric='process_rss'))
        report.update(status='passed',cells=cells,breaches=breaches,
            decision='needs_reverse_order' if breaches else 'within_declared_cost_bounds')
    except BaseException as error:
        report.update(status='failed',error=f'{type(error).__name__}: {error}')
        raise
    finally:
        lock.rmdir()
        report.update(lock_released=True,supervised_workflow_seconds=time.perf_counter()-started)
        save(logs/'summary.json',report)
    print(json.dumps(dict(status=report['status'],order=order,decision=report['decision'],breaches=report['breaches'])),flush=True)


def decide():
    protocol=read(DEST/'protocol.json')
    verify(protocol)
    forward=read(DEST/'forward/summary.json')
    assert forward['status']=='passed' and forward['lock_released']
    repeated=[]
    reverse=None
    if forward['breaches']:
        reverse=read(DEST/'reverse/summary.json')
        assert reverse['status']=='passed' and reverse['lock_released']
        repeated=[x for x in forward['breaches'] if x in reverse['breaches']]
    decision=dict(status='needs_diagnosis' if repeated else 'retained_pending_broad_acceptance',
        repeated_breaches=repeated,protocol=bound(DEST/'protocol.json'),
        forward=bound(DEST/'forward/summary.json'),
        reverse=bound(DEST/'reverse/summary.json') if reverse else None,
        performance_claim_allowed=False)
    save(DEST/'decision.json',decision)
    print(json.dumps(decision),flush=True)


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation',choices=['prepare','freeze-build','freeze-protocol','run','decide'])
    parser.add_argument('--role',choices=['baseline','candidate'])
    parser.add_argument('--receipt',type=Path)
    parser.add_argument('--order',choices=['forward','reverse'])
    args=parser.parse_args()
    if args.operation=='prepare': prepare(args.role)
    elif args.operation=='freeze-build': freeze_build(args.role,args.receipt)
    elif args.operation=='freeze-protocol': freeze_protocol()
    elif args.operation=='run': run(args.order)
    else: decide()
