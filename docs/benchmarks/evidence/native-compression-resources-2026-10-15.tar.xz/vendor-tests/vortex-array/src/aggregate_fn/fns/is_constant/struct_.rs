// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright the Vortex contributors

use vortex_error::VortexResult;

use super::is_constant;
use crate::ExecutionCtx;
use crate::arrays::StructArray;
use crate::arrays::struct_::StructArrayExt;

/// Check if a struct array is constant by checking each field independently.
pub(super) fn check_struct_constant(s: &StructArray, ctx: &mut ExecutionCtx) -> VortexResult<bool> {
    for field in s.iter_unmasked_fields() {
        if !is_constant(field, ctx)? {
            return Ok(false);
        }
    }
    Ok(true)
}
