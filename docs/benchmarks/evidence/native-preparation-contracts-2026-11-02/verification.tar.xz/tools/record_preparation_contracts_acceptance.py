"""Package final preparation-contracts workflow evidence without replaying semantics.

The archive preserves source, receipts, and already-accepted workflow outputs. It is an evidence
package with integrity checks, not a portable semantic replay verifier.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import math
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tarfile

O = Path('/Users/dylan/LocalData/shardloom/direct-source-count-2026-10-31')
P = Path('/Users/dylan/.codex/worktrees/native-preparation-contracts/shardloom-local-repo')
DEST = P / 'docs/benchmarks/evidence/native-preparation-contracts-2026-11-02'
ARCHIVE = DEST / 'verification.tar.xz'
ACCEPTANCE_OUT = DEST / 'acceptance.json'
FIRST_NUMBER = 720
UNPACKED_LIMIT = 128 << 20
ARCHIVE_LIMIT = 8 << 20
RUNTIME_PATTERN = re.compile(r'io-runtime-preparation-contracts-r[0-9]+')
WHEEL_PATTERN = re.compile(r'installed-wheel-preparation-contracts-r[0-9]+')
RECEIPT_PATTERN = re.compile(r'io([0-9]{3})-[A-Za-z0-9-]+\.json')
LOG_PATTERN = re.compile(r'io([0-9]{3})-[A-Za-z0-9-]+\.log')
SOURCE_PROBE_DIR = P / 'docs/benchmarks/evidence/native-source-strategy-probe-2026-11-02'
SOURCE_PROBE_ACCEPTANCE = SOURCE_PROBE_DIR / 'acceptance.json'
SOURCE_PROBE_ARCHIVE = SOURCE_PROBE_DIR / 'verification.tar.xz'


def identity(data: bytes) -> dict[str, int | str]:
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def generation(path: Path) -> tuple:
    value = path.lstat()
    return tuple(getattr(value, key) for key in
                 ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns'))


def file_identity(path: Path) -> dict[str, int | str]:
    before = generation(path)
    if not stat.S_ISREG(before[2]):
        raise ValueError(f'expected regular evidence/product: {path}')
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 << 20), b''):
            digest.update(block)
    if generation(path) != before:
        raise ValueError(f'file changed while hashing: {path}')
    return {'bytes': before[4], 'sha256': digest.hexdigest()}


def read_json(path: Path) -> dict:
    value = json.loads(path.read_text())
    if not isinstance(value, dict):
        raise ValueError(f'expected JSON object: {path}')
    return value


def safe_basename(value: str, label: str) -> str:
    if (not value or value in {'.', '..'} or Path(value).name != value
            or '/' in value or '\\' in value or '..' in Path(value).parts):
        raise ValueError(f'{label} must be a basename: {value!r}')
    return value


def safe_member(value: str) -> str:
    path = PurePosixPath(value)
    if (not value or path.is_absolute() or any(part in {'', '.', '..'} for part in path.parts)
            or '\\' in value or '\x00' in value):
        raise ValueError(f'unsafe archive member: {value!r}')
    return str(path)


def source_member(path: Path) -> str:
    if path.is_relative_to(O):
        return path.relative_to(O).as_posix()
    if path.is_relative_to(P):
        return 'source/' + path.relative_to(P).as_posix()
    if path == Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022/independent-full43-948/reference.json'):
        return 'reference/reference.json'
    raise ValueError(f'evidence source is outside the approved roots: {path}')


def expected_identity(row: dict) -> dict[str, int | str]:
    if not isinstance(row, dict) or not {'bytes', 'sha256'} <= row.keys():
        raise ValueError(f'invalid identity record: {row!r}')
    return {'bytes': row['bytes'], 'sha256': row['sha256']}


def source_entry(name: str, entry: dict, root: Path) -> None:
    path = root / name
    if entry.get('absent') is True:
        if path.exists():
            raise ValueError(f'frozen absent source now exists: {name}')
        return
    if identity(path.read_bytes()) != expected_identity(entry):
        raise ValueError(f'frozen source identity mismatch: {name}')


def cargo_command(receipt: dict) -> list[str]:
    command = receipt.get('command', [])
    if not isinstance(command, list):
        return []
    if command and command[0] == 'cargo':
        return command
    # Guarded cargo invocations may carry an env wrapper before the cargo command.
    if 'cargo' in command:
        index = command.index('cargo')
        return command[index:]
    return []


def archive(args: argparse.Namespace) -> dict:
    runtime_name = safe_basename(args.runtime, '--runtime')
    wheel_name = safe_basename(args.wheel, '--wheel')
    if not RUNTIME_PATTERN.fullmatch(runtime_name):
        raise ValueError('--runtime must be an io-runtime-preparation-contracts-rN directory')
    if not WHEEL_PATTERN.fullmatch(wheel_name):
        raise ValueError('--wheel must be an installed-wheel-preparation-contracts-rN directory')
    runtime_dir = O / runtime_name
    wheel_dir = O / wheel_name
    if not runtime_dir.is_dir() or runtime_dir.is_symlink():
        raise ValueError(f'runtime directory missing or symlinked: {runtime_dir}')
    if not wheel_dir.is_dir() or wheel_dir.is_symlink():
        raise ValueError(f'installed wheel report directory missing or symlinked: {wheel_dir}')
    if DEST.exists():
        raise FileExistsError(f'refusing existing destination: {DEST}')
    if args.last_number < FIRST_NUMBER:
        raise ValueError(f'--last-number must be at least {FIRST_NUMBER}')

    runtime = read_json(runtime_dir / 'manifest.json')
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=P, text=True).strip()
    status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=P, text=True).strip()
    if status:
        raise ValueError('final preparation source checkout must be clean')
    if runtime.get('source_revision') != head:
        raise ValueError('runtime source revision does not match clean checkout HEAD')
    if runtime.get('profile') != 'release' or runtime.get('features') != ['release-user-surfaces']:
        raise ValueError('final preparation runtime must use release / release-user-surfaces')
    tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=P).decode().split('\0')
    compiled = {name for name in tracked if name.endswith(('.rs', '.py', '.toml', '.lock'))}
    if compiled != set(runtime.get('source_snapshot', {})):
        raise ValueError('runtime source snapshot is incomplete')
    for name, expected in runtime.get('source_snapshot', {}).items():
        source_entry(name, expected, P)
    runtime_files = runtime.get('files', {})
    for binary in ('_native.abi3.so', 'shardloom'):
        if binary not in runtime_files:
            raise ValueError(f'runtime manifest lacks required product identity: {binary}')
        # Verify product identity, but never put runtime binaries in the archive.
        if file_identity(runtime_dir / binary) != expected_identity(runtime_files[binary]):
            raise ValueError(f'final runtime product changed: {binary}')

    build_name = safe_basename(runtime.get('build_receipt', ''), 'runtime build receipt')
    build_path = O / build_name
    build = read_json(build_path)
    if (build.get('status') != 'passed' or build.get('returncode') != 0
            or build.get('process_group_drained') is not True
            or build.get('direct_child_reaped') is not True or build.get('head') != head
            or build.get('cwd') != str(P) or build.get('working_tree') != ''
            or build.get('changed_source_inventory') != {}
            or build.get('command') != ['cargo', 'build', '--locked', '--offline', '--release',
                '--features', 'release-user-surfaces', '-p', 'shardloom-cli', '-p', 'shardloom-python']
            or identity(build_path.read_bytes())['sha256'] != runtime.get('build_receipt_sha256')):
        raise ValueError('release runtime build receipt is not a successful clean-source build')
    build_log = build_path.with_suffix('.log')
    build_log_data = build_log.read_bytes()
    if identity(build_log_data)['sha256'] != build.get('log_sha256'):
        raise ValueError('release build log identity mismatch')

    wheel = read_json(wheel_dir / 'report.json')
    integration = wheel.get('integration', {})
    if (wheel.get('status') != 'passed' or wheel.get('uninstall_status') != 'passed'
            or integration.get('status') != 'passed' or integration.get('tests') != 303
            or any(integration.get(key) != 0 for key in ('failures', 'errors', 'skipped'))):
        raise ValueError('installed wheel must record exactly 303 passed tests and 0 failures/errors/skips')
    if wheel.get('stage', {}).get('native_library_sha256') != runtime_files['_native.abi3.so']['sha256']:
        raise ValueError('installed wheel native-library digest differs from final runtime')
    if wheel.get('stage', {}).get('cli_sha256') != runtime_files['shardloom']['sha256']:
        raise ValueError('installed wheel CLI digest differs from final runtime')
    wheel_product = wheel_dir / 'dist' / safe_basename(wheel['integrity']['wheel'], 'wheel product')
    if file_identity(wheel_product) != {'bytes': wheel['integrity']['wheel_bytes'],
                                       'sha256': wheel['integrity']['wheel_sha256']}:
        raise ValueError('installed-tested wheel product changed')

    freeze_path = O / 'preparation-contracts-workflow-freeze.json'
    ingest_acceptance_path = O / 'preparation-contracts-ingest-acceptance.json'
    full_acceptance_path = O / 'preparation-contracts-full43-acceptance.json'
    investigation_path = O / 'preparation-investigation-closeout.json'
    freeze = read_json(freeze_path)
    ingest_acceptance = read_json(ingest_acceptance_path)
    full_acceptance = read_json(full_acceptance_path)
    investigation = read_json(investigation_path)
    if (freeze.get('schema_version') != 'shardloom.preparation_contract_workflow.v1'
            or freeze.get('status') != 'frozen_before_ingestion'
            or freeze.get('source_revision') != head):
        raise ValueError('workflow freeze schema/status/source revision mismatch')
    if (investigation.get('status') != 'pre_measurement_investigation_complete'
            or investigation.get('source_revision') != head):
        raise ValueError('required investigation closeout missing or stale')
    if ingest_acceptance.get('status') != 'passed' or not ingest_acceptance.get('no_fallback'):
        raise ValueError('ingest acceptance did not pass')
    if (full_acceptance.get('status') != 'passed' or full_acceptance.get('queries') != 43
            or full_acceptance.get('source_revision') != head
            or full_acceptance.get('executions_per_query') != 1
            or not full_acceptance.get('full_result_validation')
            or not full_acceptance.get('no_fallback')
            or not full_acceptance.get('source_runtime_and_input_unchanged')):
        raise ValueError('complete Full43 workflow acceptance missing or failed')
    disposition = full_acceptance.get('performance_disposition')
    if disposition not in {'ship', 'drop'}:
        raise ValueError(f'unknown workflow performance disposition: {disposition!r}')
    observations = full_acceptance['per_query']
    if ([row['query'] for row in observations] != list(range(1, 44))
            or sum(row['rows'] for row in observations) != full_acceptance['rows']
            or full_acceptance['rows'] != 381
            or not math.isclose(math.fsum(row['engine_execution_seconds'] for row in observations),
                                full_acceptance['query_engine_execution_seconds'], rel_tol=0, abs_tol=1e-9)):
        raise ValueError('recorded complete-cohort arithmetic/membership mismatch')
    combined = ingest_acceptance['engine_execution_seconds'] + full_acceptance['query_engine_execution_seconds']
    previous = full_acceptance['baseline_combined_engine_execution_seconds']
    if (full_acceptance['ingest_engine_execution_seconds'] != ingest_acceptance['engine_execution_seconds']
            or combined != full_acceptance['combined_engine_execution_seconds']
            or combined - previous != full_acceptance['combined_engine_delta_seconds']
            or disposition != ('ship' if combined < previous else 'drop')):
        raise ValueError('recorded workflow arithmetic/disposition mismatch')

    # The workflow's own acceptance validates exact values. This packer only checks byte identities
    # and archives the compressed selected outputs; it never replays or interprets their semantics.
    query_summary_ref = full_acceptance.get('summary', {})
    query_summary_path = Path(query_summary_ref.get('path', ''))
    if not query_summary_path.is_relative_to(O):
        raise ValueError('Full43 summary path is outside the output evidence root')
    query_summary = read_json(query_summary_path)
    if (not query_summary.get('complete') or not query_summary.get('full_result_validation')
            or query_summary.get('runs_completed') != 43 or query_summary.get('runs_passed') != 43
            or query_summary.get('repeats') != 1):
        raise ValueError('Full43 summary is not a complete single pass')
    records = query_summary.get('records', [])
    if [(row.get('query'), row.get('run')) for row in records] != [(n, 1) for n in range(1, 44)]:
        raise ValueError('Full43 summary query membership/order is incomplete')
    compressed_outputs: list[Path] = []
    for record in records:
        archives = [row for row in record.get('completed_log_archives', [])
                    if str(row.get('path', '')).endswith('.stdout.json.gz')]
        if len(archives) != 1:
            raise ValueError(f"query {record.get('query')} lacks one compressed stdout result")
        archive_row = archives[0]
        output_path = Path(archive_row['path'])
        if not output_path.is_relative_to(O) or not output_path.is_relative_to(O / 'full43-preparation-contracts-r1'):
            raise ValueError(f'compressed query result is outside the declared Full43 evidence: {output_path}')
        compressed = output_path.read_bytes()
        raw = gzip.decompress(compressed)
        if (len(compressed) != archive_row.get('gzip_bytes')
                or hashlib.sha256(compressed).hexdigest() != archive_row.get('gzip_sha256')
                or len(raw) != archive_row.get('raw_bytes')
                or hashlib.sha256(raw).hexdigest() != archive_row.get('raw_sha256')):
            raise ValueError(f'compressed Full43 result identity mismatch: {output_path}')
        compressed_outputs.append(output_path)

    final_names = [safe_basename(name, '--final-receipts') for name in args.final_receipts]
    if not final_names or len(set(final_names)) != len(final_names):
        raise ValueError('final receipt list must be nonempty and unique')
    final_number_set: set[int] = set()
    for name in final_names:
        match = RECEIPT_PATTERN.fullmatch(name)
        if not match:
            raise ValueError(f'not an ioNNN receipt basename: {name}')
        number = int(match.group(1))
        if number < FIRST_NUMBER or number > args.last_number:
            raise ValueError(f'final receipt outside requested numbered range: {name}')
        final_number_set.add(number)

    receipt_paths: dict[str, Path] = {}
    receipts_by_name: dict[str, dict] = {}
    receipt_rows: list[dict] = []
    member_data: dict[str, bytes] = {}
    source_map: dict[str, dict] = {}

    def add(path: Path, member_name: str | None = None, expected: dict | None = None) -> str:
        if path.is_symlink() or not path.is_file():
            raise ValueError(f'expected a regular non-symlink evidence file: {path}')
        member_name = safe_member(member_name or source_member(path))
        before = generation(path)
        data = path.read_bytes()
        if generation(path) != before:
            raise ValueError(f'evidence changed during read: {path}')
        observed = identity(data)
        if expected is not None and observed != expected_identity(expected):
            raise ValueError(f'evidence identity mismatch: {path}')
        if member_name in member_data:
            if source_map[member_name]['source_path'] != str(path):
                raise ValueError(f'duplicate member name from distinct evidence sources: {member_name}')
            if data != member_data[member_name]:
                raise ValueError(f'evidence changed between reads: {path}')
            return member_name
        if len(data) + sum(map(len, member_data.values())) >= UNPACKED_LIMIT:
            raise ValueError('unpacked archive payload must be less than 128 MiB')
        member_data[member_name] = data
        source_map[member_name] = {'source_path': str(path), **observed}
        return member_name

    # Use actual cwd-bound preparation receipts in the requested number range. This intentionally
    # excludes adjacent dependency-batch receipts whose cwd belongs to the other checkout.
    for path in sorted(O.glob('io[0-9][0-9][0-9]-*.json')):
        match = RECEIPT_PATTERN.fullmatch(path.name)
        if not match:
            continue
        number = int(match.group(1))
        if not FIRST_NUMBER <= number <= args.last_number:
            continue
        receipt = read_json(path)
        if receipt.get('cwd') != str(P):
            continue
        receipt_paths[path.name] = path
        receipts_by_name[path.name] = receipt
    for final_name in final_names:
        path = receipt_paths.get(final_name)
        if path is None:
            raise ValueError(f'final receipt missing or not bound to preparation checkout: {final_name}')

    referenced_source_blobs: set[str] = set()
    for name, path in sorted(receipt_paths.items()):
        receipt = receipts_by_name[name]
        if receipt.get('status') not in {'passed', 'failed'}:
            raise ValueError(f'unknown historical receipt status: {name}')
        log_path = path.with_suffix('.log')
        log_identity = None
        if log_path.exists():
            log_bytes = log_path.read_bytes()
            if receipt.get('log_sha256') and identity(log_bytes)['sha256'] != receipt['log_sha256']:
                raise ValueError(f'receipt log digest mismatch: {name}')
            add(log_path)
            log_identity = identity(log_bytes)
        if name in final_names:
            if (receipt.get('status') != 'passed' or receipt.get('returncode') != 0
                    or receipt.get('process_group_drained') is not True
                    or receipt.get('direct_child_reaped') is not True
                    or log_identity is None):
                raise ValueError(f'final receipt did not complete successfully: {name}')
            subprocess.run(['git', 'merge-base', '--is-ancestor', receipt['head'], head],
                           cwd=P, check=True)
            changed = {relative for relative in subprocess.check_output(
                ['git', 'diff', '--name-only', receipt['head'], head], cwd=P, text=True).splitlines()
                if relative.endswith(('.rs', '.py', '.toml', '.lock'))}
            if not changed <= set(receipt['changed_source_inventory']):
                raise ValueError(f'final receipt does not cover later source changes: {name}')
            for relative, expected in receipt.get('changed_source_inventory', {}).items():
                if relative.endswith(('.rs', '.py', '.toml', '.lock')):
                    source_entry(relative, expected, P)
                    if expected.get('absent') is not True and runtime.get('source_snapshot', {}).get(relative) != expected_identity(expected):
                        raise ValueError(f'final receipt source differs from final runtime snapshot: {relative}')
        add(path)
        row = {'name': name, 'status': receipt['status'], 'returncode': receipt.get('returncode'),
               'final': name in final_names, 'receipt': identity(path.read_bytes()), 'log': log_identity}
        if log_identity is None:
            row['log_status'] = 'not_present_at_packet_build'
        receipt_rows.append(row)
        if receipt.get('driver_sha256'):
            referenced_source_blobs.add(receipt['driver_sha256'])
        for field in ('changed_source_inventory', 'source_snapshot'):
            for source_identity in receipt.get(field, {}).values():
                if (isinstance(source_identity, dict)
                        and re.fullmatch(r'[0-9a-f]{64}', source_identity.get('sha256', ''))):
                    referenced_source_blobs.add(source_identity['sha256'])

    # Preserve any interrupted preparation logs without claiming a completion receipt.
    for path in sorted(O.glob('io[0-9][0-9][0-9]-*.log')):
        match = LOG_PATTERN.fullmatch(path.name)
        if not match:
            continue
        number = int(match.group(1))
        if not FIRST_NUMBER <= number <= args.last_number:
            continue
        if 'preparation' not in path.name and 'source-strategy-probe' not in path.name:
            continue
        if path.with_suffix('.json').name not in receipt_paths:
            add(path)

    final_receipts = [receipts_by_name[name] for name in final_names]
    commands = [cargo_command(receipt) for receipt in final_receipts]
    if not any(receipt.get('command') == ['cargo', 'fmt', '--all', '--', '--check']
               for receipt in final_receipts):
        raise ValueError('final cargo fmt --check receipt required')
    for action in ('clippy', 'test'):
        for native in (False, True):
            if not any(command and command[0] == 'cargo' and command[1:2] == [action]
                       and '--workspace' in command and '--all-targets' in command
                       and ('release-user-surfaces' in command) == native for command in commands):
                raise ValueError(f'final workspace {action} receipt missing for native={native}')
        if not any(command[1:2] == [action] and 'vendor/vortex-zstd/Cargo.toml' in command
                   and '--lib' in command for command in commands):
            raise ValueError(f'final provider {action} receipt missing')
    if not any(any(str(arg).endswith('prove_native_python_wheel.py')
                   for arg in receipt.get('command', [])) for receipt in final_receipts):
        raise ValueError('final installed-wheel proof receipt is required')

    for digest in sorted(referenced_source_blobs):
        blob = O / 'source-blobs' / digest
        if not blob.is_file() or blob.is_symlink() or identity(blob.read_bytes())['sha256'] != digest:
            raise ValueError(f'receipt source blob missing or corrupt: {digest}')
        add(blob)

    # Archive the exact source/runtime helpers named by the workflow freeze, while refusing inputs,
    # compiled products, wheels, environments, and generated data payloads.
    for row in freeze.get('helpers', []):
        path = Path(row['path'])
        if path.name in {'hits.parquet', 'hits.vortex'} or '.venv' in path.parts or 'target' in path.parts:
            raise ValueError(f'workflow freeze unexpectedly names a payload/environment helper: {path}')
        if path.suffix in {'.so', '.whl', '.arrow', '.parquet', '.vortex'}:
            raise ValueError(f'workflow freeze unexpectedly names a binary/input helper: {path}')
        if path.is_relative_to(runtime_dir) and path.name not in {'manifest.json', 'source-overlay.patch'}:
            raise ValueError(f'refusing runtime binary/payload member: {path}')
        if path.is_relative_to(wheel_dir) and path.name != 'report.json' and path.suffix not in {'.json', '.log'}:
            raise ValueError(f'refusing wheel/environment member: {path}')
        add(path, expected=row)

    add(runtime_dir / 'manifest.json')
    add(Path(__file__).resolve())
    for name in ('pr1639-final-hosted-acceptance.json', 'pr1645-final-hosted-acceptance.json'):
        add(O / name)
    comparison_path = O / 'preparation-contracts-comparison.json'
    comparison = read_json(comparison_path)
    if comparison['status'] != 'saved_evidence_inspected' or comparison['new_query_executions'] != 0:
        raise ValueError('saved comparison inspection missing')
    add(comparison_path)
    add(Path(comparison['baseline_summary']['path']), expected=comparison['baseline_summary'])
    overlay_path = runtime_dir / 'source-overlay.patch'
    add(overlay_path, expected=runtime.get('source_overlay'))
    add(build_path)
    add(build_log)
    add(wheel_dir / 'report.json')
    for path in sorted(wheel_dir.iterdir()):
        if path.is_file() and not path.is_symlink() and path.suffix in {'.json', '.log'}:
            add(path)

    for path, report in ((freeze_path, freeze), (ingest_acceptance_path, ingest_acceptance),
                         (full_acceptance_path, full_acceptance), (investigation_path, investigation)):
        add(path)
    for report, key, path in (
            (ingest_acceptance, 'freeze', freeze_path),
            (ingest_acceptance, 'driver', Path(ingest_acceptance['driver']['path'])),
            (ingest_acceptance, 'summary', Path(ingest_acceptance['summary']['path'])),
            (ingest_acceptance, 'stdout', Path(ingest_acceptance['stdout']['path'])),
            (full_acceptance, 'freeze', freeze_path),
            (full_acceptance, 'ingest', ingest_acceptance_path),
            (full_acceptance, 'driver', Path(full_acceptance['driver']['path'])),
            (full_acceptance, 'summary', query_summary_path),
            (full_acceptance, 'baseline', Path(full_acceptance['baseline']['path']))):
        if report.get(key, {}).get('path') != str(path):
            raise ValueError(f'workflow report identity path mismatch: {key}')
        if identity(path.read_bytes()) != expected_identity(report[key]):
            raise ValueError(f'workflow report identity changed: {key}')
        add(path, expected=report[key])

    # Preserve ingest/query runner evidence only from their log trees; never include the Vortex
    # prepared artifact or user input. Query stdout results are the original gzip payloads.
    ingest_root = O / 'ingest-preparation-contracts-r1'
    query_root = O / 'full43-preparation-contracts-r1'
    for root in (ingest_root, query_root):
        log_root = root / 'logs'
        if not log_root.is_dir() or log_root.is_symlink():
            raise ValueError(f'workflow log directory missing: {log_root}')
        for path in sorted(log_root.rglob('*')):
            if path.is_symlink():
                raise ValueError(f'workflow log tree contains symlink: {path}')
            if path.is_file():
                if root == ingest_root and path.suffix in {'.vortex', '.parquet', '.arrow', '.so'}:
                    raise ValueError(f'refusing payload in ingest log tree: {path}')
                add(path)
            elif not path.is_dir():
                raise ValueError(f'workflow log tree contains non-regular path: {path}')
    if len(compressed_outputs) != 43 or len(set(compressed_outputs)) != 43:
        raise ValueError('Full43 compressed result set must contain 43 unique gzip files')

    # Source-probe evidence is a public packet already accepted by its own packer. This validates
    # the packet file identity only; it does not reinterpret or replay the probe.
    probe_acceptance = read_json(SOURCE_PROBE_ACCEPTANCE)
    probe_archive_data = SOURCE_PROBE_ARCHIVE.read_bytes()
    probe_archive_id = identity(probe_archive_data)
    if (probe_acceptance.get('status') != 'passed'
            or probe_acceptance.get('archive', {}).get('bytes') != probe_archive_id['bytes']
            or probe_acceptance.get('archive', {}).get('sha256') != probe_archive_id['sha256']):
        raise ValueError('source-strategy public packet identity/status mismatch')
    add(SOURCE_PROBE_ACCEPTANCE)
    add(SOURCE_PROBE_ARCHIVE)

    # Investigation evidence supplies the authoritative list of closeout and cleanup identities.
    # Archive only these small plan/report/document files, never any payloads named by a plan.
    closeout_evidence = investigation.get('evidence', [])
    for row in closeout_evidence:
        path = Path(row['path'])
        source_blob = path.parent == O / 'source-blobs' and re.fullmatch(r'[0-9a-f]{64}', path.name)
        if path.suffix not in {'.json', '.md', '.xz', '.gz', '.log', '.py'} and not source_blob:
            raise ValueError(f'closeout evidence is not an identity-only plan/report: {path}')
        if any(suffix in path.name for suffix in ('.vortex', '.parquet', '.arrow', '.so', '.whl')):
            raise ValueError(f'closeout evidence names an excluded payload: {path}')
        add(path, expected=row)

    raw_bytes = sum(map(len, member_data.values()))
    if raw_bytes >= UNPACKED_LIMIT:
        raise ValueError(f'unpacked archive payload exceeds limit: {raw_bytes}')
    if any(Path(name).suffix in {'.so', '.whl', '.vortex', '.parquet', '.arrow'}
           for name in member_data):
        raise ValueError('archive member set contains an excluded binary/input/payload')

    final_test_results = {}
    for name in final_names:
        receipt = receipts_by_name[name]
        if cargo_command(receipt)[:2] != ['cargo', 'test']:
            continue
        log_path = receipt_paths[name].with_suffix('.log')
        text = log_path.read_text(errors='replace')
        matches = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored', text)
        if not matches or any(row[0] != 'ok' or int(row[2]) != 0 for row in matches):
            raise ValueError(f'final test log lacks complete successful test summaries: {name}')
        final_test_results[name] = {
                'binaries': len(matches),
                'passed': sum(int(row[1]) for row in matches),
                'failed': sum(int(row[2]) for row in matches),
                'ignored': sum(int(row[3]) for row in matches),
            }

    staged = io.BytesIO()
    with tarfile.open(fileobj=staged, mode='w:xz', preset=6) as bundle:
        for name, data in sorted(member_data.items()):
            info = tarfile.TarInfo(name)
            info.mode = 0o644
            info.uid = 0
            info.gid = 0
            info.uname = ''
            info.gname = ''
            info.mtime = 0
            info.size = len(data)
            bundle.addfile(info, io.BytesIO(data))
    archive_data = staged.getvalue()
    if len(archive_data) >= ARCHIVE_LIMIT:
        raise ValueError(f'compressed archive exceeds limit: {len(archive_data)}')

    DEST.mkdir(parents=True, exist_ok=False)
    with ARCHIVE.open('xb') as stream:
        stream.write(archive_data)
    member_identities: dict[str, dict[str, int | str]] = {}
    with tarfile.open(ARCHIVE, 'r:xz') as bundle:
        entries = bundle.getmembers()
        if len(entries) != len(member_data) or {row.name for row in entries} != set(member_data):
            raise ValueError('archive member set differs from staged evidence')
        for row in entries:
            if not row.isfile() or row.issym() or row.islnk():
                raise ValueError(f'archive has unexpected entry type: {row.name}')
            data = bundle.extractfile(row).read()
            if data != member_data[row.name]:
                raise ValueError(f'archive byte readback mismatch: {row.name}')
            member_identities[row.name] = identity(data)
    if member_identities != {name: identity(data) for name, data in sorted(member_data.items())}:
        raise ValueError('archive member identity table mismatch')
    final_archive_identity = identity(ARCHIVE.read_bytes())
    for name, row in source_map.items():
        if file_identity(Path(row['source_path'])) != expected_identity(row):
            raise ValueError(f'archived source changed before completion: {name}')
    for name, expected in runtime['source_snapshot'].items():
        source_entry(name, expected, P)
    if subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=P, text=True).strip() != head:
        raise ValueError('source revision changed while packaging')

    report = {
        'schema_version': 'shardloom.preparation_contracts_acceptance.v1',
        'status': 'local_acceptance_passed',
        'source_revision': head,
        'runtime_profile': runtime['profile'],
        'runtime_features': runtime['features'],
        'source_snapshot': runtime['source_snapshot'],
        'runtime_files': runtime_files,
        'runtime_manifest': identity((runtime_dir / 'manifest.json').read_bytes()),
        'runtime_source_overlay': identity(overlay_path.read_bytes()),
        'installed_integration': integration,
        'installed_wheel_status': wheel['status'],
        'uninstall_status': wheel['uninstall_status'],
        'ingest_acceptance': {
            'status': ingest_acceptance['status'],
            'engine_execution_seconds': ingest_acceptance['engine_execution_seconds'],
            'rows': ingest_acceptance['rows'],
            'columns': ingest_acceptance['columns'],
            'no_fallback': ingest_acceptance['no_fallback'],
            'output_identity': ingest_acceptance['output'],
        },
        'full43_acceptance': {
            'status': full_acceptance['status'],
            'queries': full_acceptance['queries'],
            'executions_per_query': full_acceptance['executions_per_query'],
            'rows': full_acceptance['rows'],
            'full_result_validation': full_acceptance['full_result_validation'],
            'no_fallback': full_acceptance['no_fallback'],
            'ingest_engine_execution_seconds': full_acceptance['ingest_engine_execution_seconds'],
            'query_engine_execution_seconds': full_acceptance['query_engine_execution_seconds'],
            'combined_engine_execution_seconds': full_acceptance['combined_engine_execution_seconds'],
            'baseline_combined_engine_execution_seconds': full_acceptance['baseline_combined_engine_execution_seconds'],
            'combined_engine_delta_seconds': full_acceptance['combined_engine_delta_seconds'],
            'performance_disposition': disposition,
            'per_query': full_acceptance['per_query'],
            'attribution_limit': full_acceptance['attribution_limit'],
        },
        'performance_disposition': disposition,
        'closeout_status': investigation['status'],
        'closeout_evidence': [row['path'] for row in closeout_evidence],
        'final_receipts': final_names,
        'all_preparation_receipts': receipt_rows,
        'final_test_results': final_test_results,
        'receipt_evidence_gaps': [row for row in receipt_rows if row.get('log_status')],
        'hosted_acceptance': 'pending',
        'claims': [
            'Evidence packaging; Full43 and ingest semantic checks are those recorded by the workflow acceptance reports.',
            'Archive member byte readback is not a portable semantic replay verifier.',
            'Performance disposition is copied verbatim from the final workflow acceptance.',
        ],
        'archive': {
            'path': ARCHIVE.name,
            **final_archive_identity,
            'members': len(member_data),
            'unpacked_bytes': raw_bytes,
            'complete_byte_readback': 'passed',
            'member_identities': member_identities,
            'source_map': source_map,
        },
    }
    with ACCEPTANCE_OUT.open('x') as stream:
        json.dump(report, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    return {'status': report['status'], 'destination': str(DEST),
            'receipts': len(receipt_rows), 'members': len(member_data),
            'archive_bytes': final_archive_identity['bytes'],
            'performance_disposition': disposition}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runtime', required=True, help='final runtime directory basename under O')
    parser.add_argument('--wheel', required=True, help='installed wheel proof directory basename under O')
    parser.add_argument('--last-number', type=int, required=True,
                        help='last numbered preparation receipt/log to include')
    parser.add_argument('--final-receipts', nargs='+', required=True,
                        help='passing final receipt JSON basenames in the numbered range')
    print(json.dumps(archive(parser.parse_args()), sort_keys=True))


if __name__ == '__main__':
    main()
