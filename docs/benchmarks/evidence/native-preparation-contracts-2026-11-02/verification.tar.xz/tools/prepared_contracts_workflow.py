"""Freeze and verify one fresh preparation plus one complete Vortex Full43 pass."""
import argparse
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import re
import stat
import struct
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/native-preparation-contracts/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
RUNTIME = OUT / 'io-runtime-preparation-contracts-r1'
WHEEL = OUT / 'installed-wheel-preparation-contracts-r1'
INGEST = OUT / 'ingest-preparation-contracts-r1'
VORTEX = INGEST / 'vortex/hits.vortex'
QUERIES = OUT / 'full43-preparation-contracts-r1'
FREEZE = OUT / 'preparation-contracts-workflow-freeze.json'
INGEST_ACCEPTANCE = OUT / 'preparation-contracts-ingest-acceptance.json'
ACCEPTANCE = OUT / 'preparation-contracts-full43-acceptance.json'
INVESTIGATION = OUT / 'preparation-investigation-closeout.json'
BASELINE = ROOT / 'docs/benchmarks/evidence/native-adaptive-prepared-full43-2026-11-02.json'
SOURCE = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat/sources/hits.parquet')
REFERENCE = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022/independent-full43-948/reference.json')
sys.path[:0] = [str(ROOT / 'scripts'), str(ROOT / 'python/src')]
from clickbench_reference_packet import load_reference_packet
from clickbench_native_sql import native_query_statements
from native_workflow_protocol import extract_result, report_fields, strict_json
from run_clickbench_query_uat import clickbench_harness_paths, equivalent
from query_timing_report import query_phase_timings
from local_uat_storage import require_local_path


def need(value, message):
    if not value:
        raise ValueError(message)


def read(path):
    return strict_json(Path(path).read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def generation(path):
    info = Path(path).lstat()
    return {key: getattr(info, key) for key in
            ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')}


def identity(path):
    path = Path(path)
    before = generation(path)
    need(path.is_file() and not path.is_symlink(), 'regular file required: ' + str(path))
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 << 20), b''):
            digest.update(block)
    need(generation(path) == before, 'file changed while hashing: ' + str(path))
    return dict(path=str(path), bytes=before['st_size'], sha256=digest.hexdigest())


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def source_identity():
    info = SOURCE.lstat()
    need(stat.S_ISREG(info.st_mode) and not SOURCE.is_symlink()
         and not getattr(info, 'st_flags', 0) & getattr(stat, 'SF_DATALESS', 0x40000000)
         and info.st_blocks * 512 >= info.st_size, 'original input must already be resident')
    before = generation(SOURCE)
    observed = identity(SOURCE)
    expected = read(BASELINE)['input_source']
    need(all(observed[key] == expected[key] for key in ('path', 'bytes', 'sha256'))
         and generation(SOURCE) == before, 'original source differs from accepted baseline')
    return dict(**observed, generation=before)


def freeze(args):
    need(not any(path.exists() for path in
        (INGEST, QUERIES, FREEZE, INGEST_ACCEPTANCE, ACCEPTANCE)), 'run identity already used')
    need(not git('status', '--porcelain'), 'commit candidate source before workflow freeze')
    manifest_path = RUNTIME / 'manifest.json'
    manifest = read(manifest_path)
    head = git('rev-parse', 'HEAD')
    investigation = read(INVESTIGATION)
    need(investigation['status'] == 'pre_measurement_investigation_complete'
         and investigation['source_revision'] == head,
         'finish investigations and cleanup before final measurement freeze')
    need(investigation['dispositions'] == {
        'A': 'implemented_awaiting_complete_workflow_acceptance',
        'B': 'implemented_awaiting_complete_workflow_acceptance',
        'C': 'implemented_awaiting_complete_workflow_acceptance',
        'D': 'deferred_shared_capacity_and_residual_copy_proof_missing',
        'E': 'deferred_dictionary_domain_activation_and_first_use_economics_unproven',
        'source_strategy': 'matched_parent_probe_complete_explicit_source_choices_retained',
    }, 'investigation dispositions are incomplete')
    for row in investigation['evidence']:
        need(identity(row['path']) == row, 'investigation evidence changed: ' + row['path'])
    need(read(OUT / 'preparation-test-build-cache-retirement.json')['status'] == 'passed',
         'completed test-artifact retirement missing')
    need(manifest['profile'] == 'release' and manifest['features'] == ['release-user-surfaces']
         and manifest['source_revision'] == head, 'runtime source/profile mismatch')
    build_path = OUT / manifest['build_receipt']
    build = read(build_path)
    need(build['status'] == 'passed' and build['returncode'] == 0
         and build['process_group_drained'] and build['direct_child_reaped']
         and build['cwd'] == str(ROOT) and build['head'] == head
         and build['command'] == ['cargo', 'build', '--locked', '--offline', '--release',
             '--features', 'release-user-surfaces', '-p', 'shardloom-cli', '-p', 'shardloom-python']
         and identity(build_path)['sha256'] == manifest['build_receipt_sha256'], 'release build proof mismatch')
    runtime = [identity(RUNTIME / name) for name in ('shardloom', '_native.abi3.so')]
    for row in runtime:
        need({key: row[key] for key in ('bytes', 'sha256')} == manifest['files'][Path(row['path']).name],
             'runtime product changed')
    compiled = {}
    paths = {name for name in git('ls-files').splitlines() if name.endswith(('.rs', '.py', '.toml', '.lock'))}
    need(paths == set(manifest['source_snapshot']), 'runtime source snapshot is incomplete')
    for name, expected in manifest['source_snapshot'].items():
        row = identity(ROOT / name)
        need({key: row[key] for key in ('bytes', 'sha256')} == expected, 'runtime source changed: ' + name)
        compiled[name] = row
    prerequisites = [Path(path) for path in args.prerequisite]
    commands = []
    for path in prerequisites:
        proof = read(path)
        need(proof['status'] == 'passed' and proof['returncode'] == 0
             and proof['process_group_drained'] and proof['direct_child_reaped']
             and proof['cwd'] == str(ROOT), 'failed or unbound prerequisite: ' + str(path))
        git('merge-base', '--is-ancestor', proof['head'], head)
        changed = {name for name in git('diff', '--name-only', proof['head'], head).splitlines()
                   if name.endswith(('.rs', '.py', '.toml', '.lock'))}
        need(changed <= set(proof['changed_source_inventory']), 'prerequisite misses changed sources')
        for name, expected in proof['changed_source_inventory'].items():
            if name.endswith(('.rs', '.py', '.toml', '.lock')):
                need(expected == manifest['source_snapshot'].get(name), 'prerequisite source changed: ' + name)
        log = path.with_suffix('.log')
        need(identity(log)['sha256'] == proof['log_sha256'], 'prerequisite log changed')
        commands.append(proof['command'])
    need(['cargo', 'fmt', '--all', '--', '--check'] in commands, 'format check required')
    for action in ('test', 'clippy'):
        for native in (False, True):
            need(any(command[:2] == ['cargo', action] and '--workspace' in command
                     and '--all-targets' in command and ('release-user-surfaces' in command) == native
                     for command in commands), 'workspace gate missing')
        need(any('vendor/vortex-zstd/Cargo.toml' in command and action in command
                 and '--lib' in command for command in commands), 'provider gate missing')
    package = read(WHEEL / 'report.json')
    need(package['status'] == package['uninstall_status'] == package['integration']['status'] == 'passed'
         and package['integration']['tests'] == 303
         and all(package['integration'][key] == 0 for key in ('failures', 'errors', 'skipped')),
         'installed package acceptance missing')
    for product, key in (('shardloom', 'cli_sha256'), ('_native.abi3.so', 'native_library_sha256')):
        need(package['stage'][key] == manifest['files'][product]['sha256'], 'wheel runtime differs')
    for path in (INGEST, QUERIES, SOURCE):
        require_local_path(path, Path.home(), sys.platform)
    source = source_identity()
    reference = identity(REFERENCE)
    need(reference['sha256'] == 'fc5780da415dc33bd06ed0879db07fc040db5dd419e3c37ecde7cd40a315696b',
         'independent reference changed')
    packet = load_reference_packet(REFERENCE, ROOT / 'benchmarks/clickbench/queries.sql')
    need(len(packet['queries']) == len(packet['values']) == 43, 'reference incomplete')
    ingest_command = ['bash', 'scripts/run_clickbench_ingest_uat.sh', '--uat-root', str(INGEST),
        '--binary', str(RUNTIME / 'shardloom'), '--source', str(SOURCE), '--input-format', 'parquet',
        '--target', str(VORTEX), '--memory-gb', '24', '--max-parallelism', '12', '--max-artifact-gb', '24']
    query_command = ['python3', '-B', 'scripts/run_clickbench_query_uat.py', '--binary', str(RUNTIME / 'shardloom'),
        '--input', str(VORTEX), '--input-format', 'vortex', '--uat-root', str(QUERIES),
        '--reference-packet', str(REFERENCE), '--build-commit', head, '--memory-gb', '24',
        '--max-parallelism', '12', '--timeout', '120', '--repeats', '1', '--compress-logs']
    helpers = list(dict.fromkeys([Path(__file__), OUT / 'tools/run_guarded_preparation_contracts.py',
        manifest_path, build_path, WHEEL / 'report.json', BASELINE, REFERENCE, INVESTIGATION,
        *[Path(row['path']) for row in investigation['evidence']],
        ROOT / 'benchmarks/clickbench/queries.sql', ROOT / 'scripts/run_clickbench_ingest_uat.sh',
        *prerequisites, *clickbench_harness_paths()]))
    write(FREEZE, dict(schema_version='shardloom.preparation_contract_workflow.v1', status='frozen_before_ingestion',
        maintainer_authorization='November 2 A/B/C investigation request includes complete creation/publication/first Full43 acceptance; subsequent instruction brings A–E/source-strategy investigation and justified cleanup before this freeze. Their completed dispositions are bound here.',
        source_revision=head, source_tree=git('rev-parse', 'HEAD^{tree}'), compiled_source=compiled,
        runtime=runtime, helpers=[identity(path) for path in helpers], input=source, reference=reference,
        ingest_command=ingest_command, query_command=query_command, queries=43, executions_per_query=1,
        fresh_ingest_executions=1, baseline_reruns=0, resources=dict(memory_gb=24, max_parallelism=12, artifact_gib=24),
        timing='Sequential prepare_once_millis and prepared_olap_publication_millis, then sum of 43 engine_execution_seconds.',
        decision='Lower complete combined engine time ships after correctness/resource/ownership/no-fallback acceptance; higher or unchanged drops. No minimum percentage.',
        comparison_limit='Historical single prepared observation; intervening decision-evidence, table-reader and dependency changes remain explicit. No sole-cause or repeatability claim.',
        isolation='All other task work idle during ingestion and queries; full hashes and recursive inventories before/after only.',
        storage='Existing standard runner limits, deadlines, process cleanup and lightweight workload guard; no limit increase.',
        cache_context='Original source prehashed before ingest and fresh Vortex prehashed before queries; no cache manipulation.',
        host=dict(platform=platform.platform(), machine=platform.machine(), cpu_count=os.cpu_count(),
            native_usize_bytes=struct.calcsize('P'),
            physical_memory_bytes=int(subprocess.check_output(['sysctl', '-n', 'hw.memsize'], text=True)))))
    print(json.dumps(dict(status='frozen', source_revision=head, ingest_command=ingest_command, query_command=query_command)))


def verify_common(driver_path, command_key, active_output):
    frozen = read(FREEZE)
    need(git('rev-parse', 'HEAD') == frozen['source_revision'] and not git('status', '--porcelain'),
         'source worktree changed')
    for row in [*frozen['helpers'], *frozen['runtime'], *frozen['compiled_source'].values()]:
        need(identity(row['path']) == row, 'frozen source/helper/runtime changed: ' + row['path'])
    need(source_identity() == frozen['input'], 'original source changed')
    driver = read(driver_path)
    need(driver['status'] == 'passed' and driver['returncode'] == 0
         and driver['process_group_drained'] and driver['direct_child_reaped'], 'execution/cleanup failed')
    need(identity(Path(driver_path).with_suffix('.log'))['sha256'] == driver['log_sha256'],
         'execution log changed')
    need(driver['command'] == frozen[command_key] and driver['cwd'] == str(ROOT)
         and driver['head'] == frozen['source_revision'] and driver['query_workload']
         and driver['active_output'] == str(active_output), 'execution protocol changed')
    need(all(row['scopes'] == ['active_output'] for row in driver['storage_inventory_scopes']
             if row['child_started'] and not row['forced']), 'broad inventory during execution')
    need(not (active_output / '.ingest-uat.lock').exists(), 'owned lock remains')
    return frozen


def verify_ingest(args):
    frozen = verify_common(Path(args.driver), 'ingest_command', INGEST)
    paths = list(INGEST.glob('logs/*/prepare_summary.json'))
    need(len(paths) == 1, 'wrong ingest observation count')
    summary = read(paths[0])
    need(summary['returncode'] == 0 and summary['stop_reason'] == 'process_completed'
         and summary['stdout_json_ok'] and summary['target_exists']
         and summary['memory_gb'] == 24 and summary['max_parallelism'] == 12, 'ingest incomplete or changed')
    envelope = read(paths[0].parent / 'stdout.json')
    need(envelope['status'] == 'success' and not envelope['fallback']['attempted']
         and not envelope['fallback']['allowed'], 'ingest fallback/status violation')
    fields, prefix = report_fields(envelope), 'public_workflow_preparation_'
    need(fields[prefix + 'vortex_ingest_status'] == 'prepared_state_created'
         and fields[prefix + 'prepared_olap_state_status'] == 'prepared_olap_state_ready', 'publication incomplete')
    for key in ('input_row_count', 'vortex_segment_metadata_row_count', 'prepared_olap_state_layout_footer_row_count',
                'vortex_ingest_stream_validation_rows', 'vortex_ingest_stream_projection_rows',
                'vortex_ingest_stream_arrow_conversion_rows'):
        need(int(fields[prefix + key]) == 99_997_497, 'row evidence mismatch: ' + key)
    columns = fields[prefix + 'source_state_materialized_columns'].split(',')
    need(len(columns) == len(set(columns)) == 112, 'prepared column count changed')
    need(int(fields[prefix + 'vortex_shared_native_memory_denied_reservations']) == 0
         and int(fields[prefix + 'vortex_shared_native_memory_peak_reserved_bytes']) <= 24 << 30,
         'native reservation failure')
    output = identity(VORTEX)
    need(fields[prefix + 'prepared_artifact_digest'] == 'sha256:' + output['sha256'], 'writer digest mismatch')
    receipt_source = fields[prefix + 'vortex_prepared_olap_state_artifact_fingerprint_source']
    receipt_bytes = int(fields[prefix + 'vortex_prepared_olap_state_artifact_fingerprint_payload_bytes_read'])
    need(receipt_source == 'committed_writer_streaming_sha256' and receipt_bytes == 0, 'writer proof did not activate')
    packing = {key.removeprefix(prefix): value for key, value in fields.items()
               if key.startswith(prefix + 'vortex_ingest_text_packing_')}
    need(int(packing['vortex_ingest_text_packing_completed_calls']) > 0
         and int(packing['vortex_ingest_text_packing_frame_index_entries']) > 0
         and int(packing['vortex_ingest_text_packing_frame_index_entries']) < int(packing['vortex_ingest_text_packing_valid_values'])
         and int(packing['vortex_ingest_text_packing_frame_index_bytes']) ==
             int(packing['vortex_ingest_text_packing_frame_index_entries']) * frozen['host']['native_usize_bytes'],
         'sparse text packing evidence missing')
    spans = {key: fields[prefix + key] for key in ('prepare_once_millis', 'prepared_olap_publication_millis')}
    need(all(re.fullmatch(r'[0-9]+', str(value)) for value in spans.values()), 'stage clock missing')
    sidecars = [identity(path) for path in sorted(VORTEX.parent.rglob('*')) if path.is_file() and path != VORTEX]
    need(not sidecars, 'unexpected prepared sidecars')
    result = dict(schema_version=1, status='passed', rows=99_997_497, columns=112, fresh_ingest_executions=1,
        engine_execution_seconds=sum(int(value) for value in spans.values()) / 1000,
        engine_spans_milliseconds=spans, output=dict(**output, generation=generation(VORTEX)), sidecars=sidecars,
        checksum_proof=dict(source=receipt_source, fingerprint_payload_bytes_read=receipt_bytes), text_packing=packing,
        no_fallback=True, source_runtime_unchanged=True, freeze=identity(FREEZE), driver=identity(args.driver),
        summary=identity(paths[0]), stdout=identity(paths[0].parent / 'stdout.json'),
        full_value_scope='Native ingest checks every source row; Full43 checks complete independent query results. No independent all-cell readback claim.')
    write(INGEST_ACCEPTANCE, result)
    print(json.dumps({key: result[key] for key in ('status', 'engine_execution_seconds', 'engine_spans_milliseconds', 'checksum_proof', 'text_packing')}))


def verify_queries(args):
    frozen = verify_common(Path(args.driver), 'query_command', QUERIES)
    ingest = read(INGEST_ACCEPTANCE)
    need(ingest['status'] == 'passed' and dict(**identity(VORTEX), generation=generation(VORTEX)) == ingest['output'],
         'prepared input changed')
    paths = list(QUERIES.glob('logs/*/summary.json'))
    need(len(paths) == 1, 'wrong Full43 observation count')
    summary = read(paths[0])
    need(summary['complete'] and summary['full_result_validation'] and summary['completed_identity_check']
         and summary['runs_completed'] == summary['runs_passed'] == 43 and summary['repeats'] == 1
         and summary['input_format'] == 'vortex' and summary['source'] == str(VORTEX)
         and summary['binary_sha256'] == frozen['runtime'][0]['sha256']
         and summary['build_commit'] == frozen['source_revision'], 'Full43 incomplete or runtime changed')
    packet = load_reference_packet(REFERENCE, ROOT / 'benchmarks/clickbench/queries.sql')
    submitted, dialect = native_query_statements(packet['queries'], packet['packet']['queries_sha256'], input_format='vortex')
    need(summary['query_dialect'] == dialect and [(row['query'], row['run']) for row in summary['records']] ==
         [(query, 1) for query in range(1, 44)], 'query dialect/membership changed')
    observations, rows, helper = [], 0, None
    for record in summary['records']:
        query = record['query']
        need(record['passed'] and not record['guard_failures'] and record['returncode'] == 0, 'query failed')
        need(record['query_statement'] == packet['queries'][query - 1]
             and record['executed_query_statement'] == submitted[query - 1], 'statement changed')
        archives = [item for item in record['completed_log_archives'] if item['path'].endswith('.stdout.json.gz')]
        need(len(archives) == 1, 'complete output missing')
        archive = archives[0]
        compressed = Path(archive['path']).read_bytes()
        raw = gzip.decompress(compressed)
        need(sha(compressed) == archive['gzip_sha256'] and len(compressed) == archive['gzip_bytes']
             and sha(raw) == archive['raw_sha256'] and len(raw) == archive['raw_bytes'], 'output archive changed')
        envelope = strict_json(raw.decode())
        need(envelope['status'] == 'success' and not envelope['fallback']['attempted']
             and not envelope['fallback']['allowed'], 'query fallback/status violation')
        fields, values = report_fields(envelope), extract_result(envelope)
        need(equivalent(values, packet['values'][query]), 'complete independent reference mismatch')
        need(sha(json.dumps(values, sort_keys=True, allow_nan=False).encode()) == record['result_sha256'], 'result hash changed')
        clocks = query_phase_timings(fields, record['seconds'])
        need(clocks['engine_execution_seconds'] == record['engine_execution_seconds'], 'engine clock changed')
        rows += len(values)
        observations.append(dict(query=query, rows=len(values), engine_execution_seconds=clocks['engine_execution_seconds'],
                                 result_sha256=record['result_sha256']))
        if query == 19:
            helper = {key: fields[key] for key in (
                'local_primitive_scan_projection_columns', 'local_primitive_scan_predicate_columns',
                'local_primitive_scan_column_scope', 'local_primitive_state_family',
                'local_primitive_aggregate_workers_submitted_chunks',
                'local_primitive_aggregate_native_numeric_accessor_columns')}
            helper.update({key: value for key, value in fields.items()
                           if key.startswith('local_primitive_aggregate_native_numeric_accessor_')})
            projected = json.loads(helper['local_primitive_scan_projection_columns'])
            numeric_columns = json.loads(helper['local_primitive_aggregate_native_numeric_accessor_columns'])
            need('EventTime' not in projected and '__shardloom_derived_extract_minute_EventTime' in projected
                 and 'EventTime' not in numeric_columns
                 and 'numeric_minute_string' in helper['local_primitive_state_family']
                 and int(helper['local_primitive_aggregate_workers_submitted_chunks']) > 0,
                 'prepared minute helper or specialized worker did not activate')
    total = math.fsum(row['engine_execution_seconds'] for row in observations)
    need(rows == 381 and math.isclose(total, summary['query_total_seconds'], abs_tol=1e-9), 'complete cohort total mismatch')
    combined = ingest['engine_execution_seconds'] + total
    baseline = read(BASELINE)
    previous = baseline['combined_engine_execution_seconds']
    result = dict(schema_version=1, status='passed', source_revision=frozen['source_revision'],
        queries=43, executions_per_query=1, rows=rows, full_result_validation=True, no_fallback=True,
        source_runtime_and_input_unchanged=True, ingest_engine_execution_seconds=ingest['engine_execution_seconds'],
        query_engine_execution_seconds=total, combined_engine_execution_seconds=combined,
        baseline_combined_engine_execution_seconds=previous, combined_engine_delta_seconds=combined - previous,
        performance_disposition='ship' if combined < previous else 'drop', per_query=observations, minute_helper=helper,
        attribution_limit='Actual scan and worker admission; no per-column payload byte/decode counter is inferred. Historical single observation includes intervening runtime changes; no sole-cause or repeatability claim.',
        freeze=identity(FREEZE), ingest=identity(INGEST_ACCEPTANCE), driver=identity(args.driver),
        summary=identity(paths[0]), baseline=identity(BASELINE))
    write(ACCEPTANCE, result)
    print(json.dumps({key: result[key] for key in ('status', 'queries', 'rows', 'ingest_engine_execution_seconds',
        'query_engine_execution_seconds', 'combined_engine_execution_seconds', 'combined_engine_delta_seconds', 'performance_disposition')}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=('freeze', 'verify-ingest', 'verify-queries'))
    parser.add_argument('--driver')
    parser.add_argument('--prerequisite', action='append', default=[])
    args = parser.parse_args()
    if args.stage != 'freeze' and not args.driver:
        parser.error('--driver is required for verification')
    {'freeze': freeze, 'verify-ingest': verify_ingest, 'verify-queries': verify_queries}[args.stage](args)
