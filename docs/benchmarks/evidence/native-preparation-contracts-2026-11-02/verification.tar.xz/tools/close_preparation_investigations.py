"""Bind completed pre-measurement investigation, source gates and retention."""
import json
from pathlib import Path
import re
import subprocess

from prepared_contracts_workflow import ROOT, OUT, INVESTIGATION, identity


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def main():
    assert not INVESTIGATION.exists()
    assert not git('status', '--porcelain'), 'commit source before closeout'
    head = git('rev-parse', 'HEAD')
    gates, evidence, counts = [], [], {}
    required = (739, 740, 741, 742, 743, 745, 746, 747, 748, 749, 750, 751, 752)
    for number in required:
        paths = list(OUT.glob(f'io{number}-*.json'))
        assert len(paths) == 1
        path = paths[0]
        value = json.loads(path.read_text())
        assert value['status'] == 'passed' and value['returncode'] == 0
        assert value['process_group_drained'] and value['direct_child_reaped']
        assert value['cwd'] == str(ROOT)
        git('merge-base', '--is-ancestor', value['head'], head)
        changed = {name for name in git('diff', '--name-only', value['head'], head).splitlines()
                   if name.endswith(('.rs', '.py', '.toml', '.lock'))}
        assert changed <= set(value['changed_source_inventory']), path
        for name, expected in value['changed_source_inventory'].items():
            if name.endswith(('.rs', '.py', '.toml', '.lock')):
                current = identity(ROOT / name)
                assert {key: current[key] for key in ('bytes', 'sha256')} == expected, name
        log = path.with_suffix('.log')
        assert identity(log)['sha256'] == value['log_sha256']
        evidence.extend((path, log))
        gates.append(dict(receipt=path.name, command=value['command'], status=value['status']))
        if number in (739, 743, 745):
            rows = re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',
                              log.read_text(), re.M)
            assert rows and all(row[0] == 'ok' and int(row[2]) == 0 for row in rows)
            counts[path.name] = dict(binaries=len(rows), passed=sum(int(row[1]) for row in rows),
                                    failed=0, ignored=sum(int(row[3]) for row in rows))
    assert sorted(row['passed'] for row in counts.values()) == [96, 3318, 6875]

    cleanup = []
    reports = sorted(OUT.glob('preparation-*-retirement.json'))
    assert len(reports) == 7
    for path in reports:
        value = json.loads(path.read_text())
        assert value['status'] == 'passed'
        assert value['repeated_identity_checks'] and value['closed_handles'] and value['no_payload_archive']
        plan = path.with_name(path.stem + '-plan.json.xz')
        assert identity(plan)['sha256'] == value['plan_sha256']
        evidence.extend((path, plan))
        cleanup.append(dict(report=path.name, status=value['status'],
                            reported_regular_files=value.get('retired_regular_files')))
    assert not Path('/Users/dylan/.cache/shardloom/cargo-target/ci-native').exists()
    assert not Path('/Users/dylan/.cache/shardloom/cargo-target/debug').exists()

    probe = OUT / 'source-strategy-probe-r1-acceptance.json'
    observed = json.loads(probe.read_text())
    assert observed['status'] == 'passed' and observed['total_executions'] == 14
    assert observed['query_ids'] == [1, 3, 13, 19, 20, 24, 34]
    assert observed['no_fallback'] and observed['process_group_drained']
    assert observed['source_runtime_and_harness_unchanged']
    public = ROOT / 'docs/benchmarks/evidence/native-source-strategy-probe-2026-11-02'
    public_report = json.loads((public / 'acceptance.json').read_text())
    archive = identity(public / 'verification.tar.xz')
    assert public_report['status'] == 'passed'
    assert all(archive[key] == public_report['archive'][key] for key in ('bytes', 'sha256'))
    evidence.extend((probe, public / 'acceptance.json', public / 'verification.tar.xz'))
    evidence.extend(ROOT / name for name in (
        'docs/architecture/native-preparation-query-investigations-2026-11-02.md',
        'docs/architecture/native-source-strategy-investigation-2026-11-02.md',
        'docs/architecture/phased-execution-plan.md', 'docs/skills/benchmarking.md'))
    evidence.extend((Path(__file__).resolve(), OUT / 'tools/retire_preparation_test_build_cache.py',
        OUT / 'source-blobs/51044a87c28aa148ebbba69ef2fde22d60e678ab98a936f4e07cd81d0b1f3e0b'))
    failures = []
    for path in sorted(OUT.glob('io7??-*.json')):
        value = json.loads(path.read_text())
        if value.get('cwd') == str(ROOT) and value.get('status') == 'failed':
            failures.append(path.name)
    result = dict(schema_version='shardloom.preparation_investigation_closeout.v1',
        status='pre_measurement_investigation_complete', source_revision=head,
        source_tree=git('rev-parse', 'HEAD^{tree}'),
        dispositions={
            'A': 'implemented_awaiting_complete_workflow_acceptance',
            'B': 'implemented_awaiting_complete_workflow_acceptance',
            'C': 'implemented_awaiting_complete_workflow_acceptance',
            'D': 'deferred_shared_capacity_and_residual_copy_proof_missing',
            'E': 'deferred_dictionary_domain_activation_and_first_use_economics_unproven',
            'source_strategy': 'matched_parent_probe_complete_explicit_source_choices_retained'},
        final_local_gates=gates, rust_tests=counts, cleanup=cleanup,
        original_failed_receipts_preserved=failures,
        expert_review='Writer descriptor/generation lifetime, receipt opt-in, sparse frame byte identity, '
                      'typed null/error contracts, complete result scope and attribution limits reviewed.',
        pending=['clean_release_build', 'installed_wheel_proof', 'fresh_preparation_publication',
                 'single_isolated_full43', 'hosted_acceptance'],
        no_performance_acceptance_claim=True,
        evidence=[identity(path) for path in dict.fromkeys(evidence)])
    assert not git('status', '--porcelain') and git('rev-parse', 'HEAD') == head
    with INVESTIGATION.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    assert json.loads(INVESTIGATION.read_text()) == result
    print(json.dumps(dict(status=result['status'], source_revision=head, gates=len(gates),
                          retirement_reports=len(cleanup), evidence_files=len(result['evidence']))))


if __name__ == '__main__':
    main()
