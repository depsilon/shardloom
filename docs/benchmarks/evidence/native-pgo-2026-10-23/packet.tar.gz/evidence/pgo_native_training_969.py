"""Train the actual staged Python extension on training-only native workflows."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
from unittest.mock import patch


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def exact(actual, expected):
    if type(actual) is not type(expected): return False
    if isinstance(actual, list):
        return len(actual) == len(expected) and all(exact(a, b) for a, b in zip(actual, expected))
    if isinstance(actual, dict):
        return actual.keys() == expected.keys() and all(exact(actual[k], expected[k]) for k in actual)
    if isinstance(actual, float): return actual.hex() == expected.hex()
    return actual == expected


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--prepared', type=Path, required=True)
    parser.add_argument('--package', type=Path, required=True)
    parser.add_argument('--library-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--profile-directory', type=Path)
    args = parser.parse_args()
    assert not args.output.exists()
    args.output.mkdir()
    if args.profile_directory:
        assert os.environ['LLVM_PROFILE_FILE'] == str(args.profile_directory / 'shardloom-%m.profraw')
    else:
        assert not os.environ.get('LLVM_PROFILE_FILE')
    import pyarrow as pa
    import shardloom as sl
    from shardloom import _native
    assert Path(sl.__file__).resolve().parent == (args.package / 'src/shardloom').resolve()
    assert Path(_native.__file__).resolve() == (args.package / 'src/shardloom/_native.abi3.so').resolve()
    assert sha(_native.__file__) == args.library_sha256
    assert _native.execution_provider == 'shared_shardloom_native'
    assert _native.__version__ == sl.__version__
    manifest = json.loads(args.manifest.read_text())
    prepared = json.loads(args.prepared.read_text())
    assert prepared['status'] == 'passed' and prepared['role'] == 'train'
    sources = {item['id']: item['file'] for item in prepared['datasets']}
    for item in sources.values(): assert sha(item['path']) == item['sha256']
    records = []
    report = {'status': 'running', 'role': 'training_only', 'instrumented': bool(args.profile_directory),
        'manifest_sha256': sha(args.manifest), 'prepared_sha256': sha(args.prepared),
        'package': str(args.package), 'native_library': str(_native.__file__),
        'native_library_sha256': args.library_sha256, 'records': records,
        'native_child_processes_allowed': False, 'external_query_execution': False,
        'source_rows': 4097, 'workers': 4, 'schema': 'py_id:int64!, py_text:utf8?',
        'performance_claim': False}
    client = sl.ShardLoomClient(transport='native', memory_bytes=4 << 30, max_parallelism=4)

    def checked(name, result, expected, *, ordered=True):
        values = result.to_arrow().to_pylist()
        key = lambda row: json.dumps(row, sort_keys=True, ensure_ascii=False)
        actual, wanted = (values, expected) if ordered else (sorted(values, key=key), sorted(expected, key=key))
        assert exact(actual, wanted), (name, actual[:5], wanted[:5])
        envelope = result.envelope
        assert result.native_result is not None
        assert envelope.field('python_execution_transport') == 'native'
        assert not envelope.fallback.attempted and not envelope.fallback.allowed
        external = [value for key, value in envelope.field_map.items() if key.endswith('external_engine_invoked')]
        assert external and all(value == 'false' for value in external)
        record = {'name': name, 'complete_values': True, 'values': values,
                  'envelope': dict(envelope.raw)}
        records.append(record)
        return record

    try:
        # SQL evaluates in the extension; Arrow is used for fixture construction
        # and explicit result export/validation only.
        with patch('subprocess.Popen', side_effect=AssertionError('native training spawned a process')):
            for case in manifest['cases']:
                if case['role'] != 'train': continue
                result = sl.sql(case['sql'], input=sources[case['dataset']]['path'],
                    input_format='vortex', client=client).collect(check=True)
                record = checked(case['name'], result, case['expected'], ordered=case['ordered'])
                strategy = result.envelope.field('local_primitive_aggregate_update_strategy')
                record['strategy'] = strategy
                if case['expected_strategies']:
                    assert strategy in case['expected_strategies'], (case['name'], strategy)
                del result
            rows = [{'py_id': 20_000_000 + n,
                     'py_text': None if n % 13 == 0 else f'python-learn-{n % 71}-京都'}
                    for n in range(4097)]
            table = pa.Table.from_pylist(rows, schema=pa.schema([
                pa.field('py_id', pa.int64(), nullable=False), pa.field('py_text', pa.string())]))
            frame = sl.from_arrow_table(table, client=client)
            selected = frame.where('py_id >= 20000007').sort('py_id', descending=True).limit(257)
            result = selected.collect(check=True)
            checked('arrow-filter-order', result, list(reversed(rows))[:257])
            del result
            target = args.output / 'python-training.vortex'
            written = frame.write_vortex(target, check=True)
            assert written.envelope.field('python_execution_transport') == 'native'
            external = [value for key, value in written.envelope.field_map.items()
                        if key.endswith('external_engine_invoked')]
            assert external and all(value == 'false' for value in external)
            records.append({'name': 'arrow-write-vortex', 'envelope': dict(written.envelope.raw),
                            'output_sha256': sha(target)})
            result = sl.read_vortex(target, client=client).collect(check=True)
            checked('vortex-complete-reopen', result, rows)
            del result
            result = sl.sql('SELECT COUNT(*) AS n, MIN(py_id) AS lo, MAX(py_id) AS hi, '
                            'COUNT(py_text) AS texts FROM corpus',
                            input=target, input_format='vortex', client=client).collect(check=True)
            checked('vortex-nullable-aggregate', result, [{'n': len(rows), 'lo': rows[0]['py_id'],
                'hi': rows[-1]['py_id'], 'texts': sum(row['py_text'] is not None for row in rows)}])
            del result
        assert len(records) == 20
        for item in sources.values(): assert sha(item['path']) == item['sha256']
        assert sha(_native.__file__) == args.library_sha256
        report.update(status='passed', complete_value_checks=19, native_operations=20,
                      no_external_execution=True, source_and_library_unchanged=True)
    except BaseException as error:
        report.update(status='failed', error=repr(error))
        raise
    finally:
        client.close()
        (args.output / 'summary.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'status': 'passed', 'native_operations': 20, 'complete_value_checks': 19}))


if __name__ == '__main__':
    main()
