"""Read saved paired results and physical strategies without further execution."""
from pathlib import Path
import argparse
import hashlib
import json
import sys
import tarfile

N = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022')
W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
sys.path.insert(0, str(W / 'scripts'))
from native_workflow_protocol import report_fields


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('order', choices=['a', 'b'])
    args = parser.parse_args()
    output = N / f'pgo-paired-{args.order}-deviation-review-979.json'
    assert not output.exists()
    stage_path = N / f'pgo-investigation-976/paired-{args.order}/summary.json'
    stage = json.loads(stage_path.read_text())
    summary_path = Path(stage['summary']['path'])
    assert identity(summary_path) == stage['summary']
    summary = json.loads(summary_path.read_text())
    rows, logs = [], []
    for query in range(1, 44):
        pair = {r['role']: r for r in summary['records'] if r['query'] == query}
        assert len(pair) == 2 and all(r['passed'] and r['guard_failures'] == [] for r in pair.values())
        fields = {}
        path = summary_path.parent / f'q{query:02d}_completed.tar.xz'
        with tarfile.open(path) as archive:
            for role in pair:
                envelope = json.load(archive.extractfile(f'q{query:02d}_run1_{role}.stdout.json'))
                fields[role] = report_fields(envelope)
                assert envelope['fallback']['attempted'] is False and envelope['fallback']['allowed'] is False
        keys = sorted({key for f in fields.values() for key in f if any(marker in key for marker in
                       ['strategy', 'parallelism', 'rows_scanned', 'range_reads', 'bytes_read'])})
        selected = {role: {key: f.get(key) for key in keys} for role, f in fields.items()}
        changes = {key: [selected['control'][key], selected['candidate'][key]] for key in keys
                   if selected['control'][key] != selected['candidate'][key]}
        a, b = pair['control'], pair['candidate']
        assert a['query_statement'] == b['query_statement']
        assert selected['control']['public_workflow_max_parallelism'] == selected['candidate']['public_workflow_max_parallelism'] == '12'
        rows.append({'query': query, 'sql': a['query_statement'],
            'control_engine_seconds': a['engine_execution_seconds'],
            'candidate_engine_seconds': b['engine_execution_seconds'],
            'delta_engine_seconds': b['engine_execution_seconds'] - a['engine_execution_seconds'],
            'deviation_triggered': b['engine_execution_seconds'] > a['engine_execution_seconds'] * 1.10 + .020,
            'selected_path_changes': changes, 'selected_control_fields': selected['control'],
            'selected_candidate_fields': selected['candidate'],
            'diagnostic_native_child_cpu_seconds': {role: row['user_cpu_seconds'] + row['system_cpu_seconds']
                                                   for role, row in pair.items()}})
        logs.append(identity(path))
    deviations = [r['query'] for r in rows if r['deviation_triggered']]
    assert deviations == stage['deviation_queries']
    report = {'schema': 'shardloom.pgo_paired_deviation_review.v1', 'status': 'passed', 'order': args.order,
        'stage': identity(stage_path), 'summary': identity(summary_path), 'rows': rows,
        'raw_archives': logs, 'deviating_queries': deviations,
        'selected_path_changes': {str(r['query']): r['selected_path_changes'] for r in rows if r['selected_path_changes']},
        'comparison_scope': 'Fresh matched control and PGO builds; same frozen source, corpus, settings and C/C++ profile isolation.',
        'cpu_scope': 'Native child CPU is an overlapping diagnostic counter, never substituted for engine elapsed time.',
        'next_action': ('Preserve this cohort and use the already frozen reverse order to check persistent compiler-variant tradeoffs; no new implementation or extra repeat.' if args.order == 'a'
                        else 'Apply the original engine/deviation gates to both cohorts; no tuning or new comparison admitted by this review.')}
    if args.order == 'b':
        first_path = N / 'pgo-paired-a-deviation-review-979.json'
        first = json.loads(first_path.read_text())
        report['first_review'] = identity(first_path)
        report['deviations_in_both_orders'] = sorted(set(first['deviating_queries']) & set(deviations))
    output.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'report': identity(output), 'deviating_queries': deviations,
                      'selected_path_changes': report['selected_path_changes'],
                      'deviations_in_both_orders': report.get('deviations_in_both_orders')}))


if __name__ == '__main__':
    main()
