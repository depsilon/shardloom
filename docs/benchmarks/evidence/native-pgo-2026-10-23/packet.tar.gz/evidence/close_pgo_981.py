"""Close the frozen PGO configuration without replacing a failed retain gate."""
import json
import math
from pathlib import Path

import pgo_evaluate_977 as evaluation

experiment, p = evaluation.experiment, evaluation.p
N, ROOT = experiment.N, experiment.ROOT


def main():
    protocol = evaluation.check_binding()
    diagnostic = experiment.passed('control-ingest-correctness')
    assert diagnostic['complete_values'] and diagnostic['queries'] == 43 and diagnostic['rows'] == 381
    failed = p.read(ROOT / 'ingest-recovered-1/summary.json')
    assert failed['status'] == 'failed' and failed['error'] == 'AssertionError()'
    assert len(failed['records']) == 1 and failed['records'][0]['returncode'] == 0
    assert not any((ROOT / ('ingest-recovered-' + str(i))).exists() for i in (2, 3, 4))
    pairs = [experiment.passed('paired-' + order) for order in ('a', 'b')]
    heldout = [experiment.passed('heldout-' + order) for order in ('a', 'b')]
    for role in ('control', 'candidate'):
        experiment.passed('pressure-' + role)
        experiment.passed('package-' + role)
    setup = {stage: experiment.passed(stage)['stage_seconds']
             for stage in ('control', 'instrumented', 'training', 'merge', 'candidate')}
    generation = p.read(N / 'pgo-generation-966/generation.json')['seconds']
    additional = max(0.0, generation + setup['instrumented'] + setup['training'] + setup['merge']
                     + setup['candidate'] - setup['control'])
    q4 = [next(row for row in stage['query_deltas'] if row['query'] == 4) for stage in pairs]
    assert all(row['deviation_triggered'] for row in q4)
    source = experiment.source_files()
    assert source == protocol['sources']
    references = [experiment.PROTOCOL, experiment.AMENDMENT, evaluation.BINDING,
        N / 'pgo-ingest-amendment-980.json', N / 'pgo-control-ingest-mismatch-980.json',
        N / 'pgo-ingest-layout-provenance-981b.json', N / 'pgo-ingest-admission-replay-981.json',
        N / 'pgo-standard-deviation-review-979.json', N / 'pgo-paired-a-deviation-review-979.json',
        N / 'pgo-paired-b-deviation-review-979.json', N / 'pgo-generation-966/generation.json']
    references += sorted(ROOT.glob('*/summary.json'))
    report = {'schema': 'shardloom.current_source_pgo_closeout.v1', 'status': 'closed',
        'decision': 'drop', 'protocol': p.identity(experiment.PROTOCOL),
        'reason': 'The historical byte-identity comparator was prepared at different parallelism. The unmodified control fails that frozen ingest gate; required matched complete-workflow savings and break-even are unavailable.',
        'failure_attribution': 'Existing metadata and memory admission reproduces both layouts exactly: historical requested/admitted parallelism 12/10 gives 32768-row batches and 3120 batches; experiment 2/2 gives 262144-row batches and 423 batches. No source-policy change is needed to explain the difference.',
        'gate_changed': False, 'failed_observation_replaced': False,
        'historical_gate_requires_same_byte_identity': True,
        'native_control_ingest_completed': True, 'native_control_ingest_count': 1,
        'candidate_ingest_count': 0, 'planned_native_ingests': 4,
        'unrun_ingest_roles': ['candidate', 'candidate', 'control'],
        'complete_workflow_savings': None, 'break_even_reuses': None,
        'setup_diagnostics': {'clock_scope': 'diagnostic complete stage/process clocks; never engine execution',
            'corpus_generation_seconds': generation, 'stage_seconds': setup,
            'additional_setup_seconds': additional, 'reuse_count_evidenced': None},
        'standard_full43_engine_seconds': experiment.passed('standard-full43')['totals']['candidate']['engine_seconds'],
        'paired_full43': [{'order': order, 'engine_totals': {r: d['totals'][r]['engine_seconds'] for r in ('control', 'candidate')},
            'engine_gain_fraction': 1 - d['totals']['candidate']['engine_seconds'] / d['totals']['control']['engine_seconds'],
            'engine_gate_passed': d['engine_gate_passed'], 'deviation_queries': d['deviation_queries']}
            for order, d in zip(('a', 'b'), pairs)],
        'per_query_deviation_adjudication': {
            'repeated_in_both_orders': [4], 'q4': q4,
            'q4_conclusion': 'Repeated AVG(UserID) slowdown in engine time and native child CPU with unchanged physical strategy/source/settings is consistent with a localized PGO compiler tradeoff; exact generated-code cause is not isolated.',
            'other_deviations': 'Threshold crossings and host observations are retained; their per-query causes are not isolated. They do not prove independent regressions or justify discarding samples.',
            'threshold_is_investigation_trigger_not_automatic_rejection': True,
            'all_physical_strategies_unchanged': True},
        'heldout': [{'order': order, 'calls': len(d['records']), 'engine_totals': d['engine_totals'],
                     'gate_passed': d['heldout_gate_passed'], 'deviations': d['deviations']}
                    for order, d in zip(('a', 'b'), heldout)],
        'control_layout_diagnostic': {'queries': 43, 'complete_result_rows': 381,
            'engine_seconds': diagnostic['engine_seconds'], 'performance_comparison': False,
            'complete_query_values_match_independent_reference': True,
            'all_column_value_equivalence_claim': False},
        'training': {'cli_queries': 48, 'native_preparations': 2, 'native_python_operations': 20,
            'native_python_complete_value_checks': 19, 'strategy_families': 9,
            'workers': [1, 4, 12], 'pressure_calls': 5, 'full43_or_heldout_used': False},
        'pressure': {'roles': ['control', 'candidate'], 'custom_calls_each': 5,
            'public_cases_each': 16, 'actual_spill_quota_and_cleanup_checked': True,
            'larger_than_public_memory_grant_claim': False},
        'package': {'native_binding_tests_each': 121, 'roles': ['control', 'candidate'],
            'failures': 0, 'errors': 0, 'skips': 0,
            'scope': 'current macOS arm64 host, cp310 abi3 wheel on Python 3.12 only'},
        'compiler': {'profile_scope': 'Rust only; C and C++ profiling disabled equally for all roles',
            'native_objects_checked_each': 39, 'fresh_raw_profiles': 2,
            'candidate_missing_function_profile_warnings': 3922,
            'profile_hash_mismatch_warnings': 0, 'stale_profile_reuse': False},
        'sources': {'all_source_files': len(source), 'native_source_files': len(protocol['native_sources']),
                    'exactly_unchanged': True},
        'portable_release_default': 'unchanged portable ThinLTO, no PGO profile',
        'release_default_changed': False, 'publication_attempted': False,
        'competitive_gate_completion_claim': False,
        'queue_direction': 'Maintainer pauses broader required/conditional/breadth queue after this finite investigation. Next authorized work is unused-artifact/code cleanup and a source-grounded material compute-optimization review; isolated Full43 is the acceptance check for any selected implementation.',
        'evidence': [p.identity(path) for path in references]}
    p.save(N / 'pgo-closeout-981.json', report)
    print(json.dumps({'status': 'closed', 'decision': 'drop', 'record': p.identity(N / 'pgo-closeout-981.json'),
                      'source_files_unchanged': len(source), 'native_files_unchanged': len(protocol['native_sources'])}))


if __name__ == '__main__':
    main()
