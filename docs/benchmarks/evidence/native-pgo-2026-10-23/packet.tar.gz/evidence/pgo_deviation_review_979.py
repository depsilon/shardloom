"""Record the immediate saved-output review; no queries or profiling are run."""
from pathlib import Path
import gzip
import hashlib
import json
import math
import sys

N = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022')
W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
sys.path.insert(0, str(W / 'scripts'))
from native_workflow_protocol import report_fields


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha}


def main():
    output = N / 'pgo-standard-deviation-review-979.json'
    assert not output.exists()
    stage_path = N / 'pgo-investigation-976/standard-full43/summary.json'
    stage = json.loads(stage_path.read_text())
    restored = json.loads((N / 'full43-restored-run-964.json').read_text())
    new_path, old_path = Path(stage['summary']['path']), Path(restored['summary']['path'])
    assert identity(new_path) == stage['summary'] and identity(old_path) == restored['summary']
    candidate, control = json.loads(new_path.read_text()), json.loads(old_path.read_text())
    common = ['source', 'source_bytes', 'source_generation', 'queries_sha256', 'reference_packet',
              'reference_kind', 'memory_gb', 'max_parallelism', 'selected_query_ids', 'repeats',
              'engine_timing_required', 'harness_sha256']
    assert all(candidate[key] == control[key] for key in common)
    rows, logs = [], []
    for query, a, b in zip(range(1, 44), control['records'], candidate['records']):
        assert a['query'] == b['query'] == query and a['query_statement'] == b['query_statement']
        assert a['command'][1:] == b['command'][1:]
        assert a['passed'] and b['passed'] and a['validation'] == b['validation'] == 'complete_values'
        assert a['guard_failures'] == b['guard_failures'] == []
        paths = [root.parent / f'q{query:02d}_run1.stdout.json.gz' for root in [old_path, new_path]]
        fields = [report_fields(json.loads(gzip.decompress(p.read_bytes()))) for p in paths]
        keys = sorted({key for f in fields for key in f if any(marker in key for marker in
                       ['strategy', 'parallelism', 'rows_scanned', 'range_reads', 'bytes_read'])})
        selected = [{key: f.get(key) for key in keys} for f in fields]
        changes = {key: [selected[0][key], selected[1][key]] for key in keys
                   if selected[0][key] != selected[1][key]}
        rows.append({'query': query, 'sql': a['query_statement'],
            'control_engine_seconds': a['engine_execution_seconds'],
            'candidate_engine_seconds': b['engine_execution_seconds'],
            'delta_engine_seconds': b['engine_execution_seconds'] - a['engine_execution_seconds'],
            'deviation_triggered': b['engine_execution_seconds'] > a['engine_execution_seconds'] * 1.10 + .020,
            'selected_path_changes': changes, 'selected_control_fields': selected[0],
            'selected_candidate_fields': selected[1],
            'diagnostic_native_child_cpu_seconds': {role: record['user_cpu_seconds'] + record['system_cpu_seconds']
                                                   for role, record in [('control', a), ('candidate', b)]}})
        logs.extend(identity(path) for path in paths)
    assert [r['query'] for r in rows if r['deviation_triggered']] == stage['deviation_queries']
    protocol = json.loads((N / 'pgo-protocol-976.json').read_text())
    build = json.loads((N / 'pgo-investigation-976/candidate/summary.json').read_text())
    restored_build = json.loads((N / 'q29-release-build-950.json').read_text())
    assert build['source_before'] == build['source_after'] == protocol['sources']
    assert protocol['native_sources'] == restored_build['source_after']
    report = {'schema': 'shardloom.pgo_immediate_deviation_review.v1', 'status': 'passed',
        'stage': identity(stage_path), 'prior_restored_observation': identity(N / 'full43-restored-run-964.json'),
        'candidate_summary': identity(new_path), 'prior_summary': identity(old_path),
        'identical_run_contract_fields': common, 'native_source_count': len(protocol['native_sources']),
        'native_sources_unchanged': True, 'complete_values_and_no_guard_failures': True,
        'rows': rows, 'raw_output_references': logs,
        'engine_totals': {'control': math.fsum(r['control_engine_seconds'] for r in rows),
                          'candidate': math.fsum(r['candidate_engine_seconds'] for r in rows)},
        'deviating_queries': stage['deviation_queries'],
        'selected_path_changes': {str(r['query']): r['selected_path_changes'] for r in rows if r['selected_path_changes']},
        'comparison_scope': 'Historical restored observation versus current PGO standard observation, not a matched compiler comparison.',
        'host_scope': 'Ordinary desktop/system activity appears in saved host samples; sampled CPU is overlapping context, not exclusive causal attribution. No task build/test/agent/profiler overlap occurred.',
        'next_action': 'Run the already frozen matched alternating comparison on the two fresh binaries to separate a compiler effect from variation shared with the contemporaneous control. No new implementation, workload, repeat or gate is introduced.',
        'causal_conclusion': 'Unresolved before the matched comparison; do not attribute the historical difference to PGO or host activity.'}
    output.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'status': 'passed', 'deviating_queries': report['deviating_queries'],
                      'selected_path_changes': report['selected_path_changes'], 'report': identity(output)}))


if __name__ == '__main__':
    main()
