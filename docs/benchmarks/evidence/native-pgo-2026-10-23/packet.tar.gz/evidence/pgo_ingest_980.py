"""Correct ingest wrapper launch/readback before the first native ingest observation."""
from pathlib import Path
import argparse
import json
import math
import os
import shutil
import subprocess
import sys
import time

import pgo_evaluate_977 as evaluation

experiment, p = evaluation.experiment, evaluation.p
N, W, ROOT = experiment.N, experiment.W, experiment.ROOT
AMENDMENT = N / 'pgo-ingest-amendment-980.json'
PYTHON_BIN = Path('/opt/homebrew/opt/python@3.13/libexec/bin')


def environment():
    env = experiment.base_env()
    env['PATH'] = str(PYTHON_BIN) + os.pathsep + env['PATH']
    selected = Path(shutil.which('python3', path=env['PATH']))
    assert selected.resolve() == Path(p.PYTHON).resolve()
    return env


def bind():
    evaluation.check_binding()
    assert not AMENDMENT.exists()
    assert not any((ROOT / ('ingest-recovered-' + str(i))).exists() for i in range(1, 5))
    failed_path = ROOT / 'ingest-1/summary.json'
    failed = p.read(failed_path)
    assert failed['status'] == 'failed' and len(failed['records']) == 1
    record = failed['records'][0]
    assert record['returncode'] == 1 and record['process_group_drained'] and record['direct_child_reaped']
    paths = list((ROOT / 'ingest-1/uat').glob('logs/*/prepare_summary.json'))
    assert len(paths) == 1
    wrapper = p.read(paths[0])
    assert wrapper['native_process_seconds'] is None and wrapper['native_peak_rss_bytes'] is None
    assert not Path(wrapper['native_timing_path']).exists() and not Path(wrapper['target']).exists()
    assert not (paths[0].parent / 'native.pid').exists()
    assert Path(wrapper['stdout_path']).stat().st_size == 0
    assert "TypeError: dataclass() got an unexpected keyword argument 'slots'" in Path(wrapper['stderr_path']).read_text()
    assert not (ROOT / 'ingest-1/uat/.ingest-uat.lock').exists()
    with experiment.stage('ingest-interpreter-preflight') as (steps, report, _):
        code = ('import json,sys; sys.path.insert(0,' + repr(str(W / 'scripts')) + '); '
                'import timed_native_command; print(json.dumps({"version":sys.version,"executable":sys.executable,"timing_helper_imported":True}))')
        result = steps.run('supported-interpreter', ['python3', '-B', '-c', code], env=environment())
        report.update(native_process_launched=False, selected_interpreter=p.identity((PYTHON_BIN / 'python3').resolve()))
    preserved = [p.identity(path) for path in sorted((ROOT / 'ingest-1').rglob('*')) if path.is_file()]
    p.save(AMENDMENT, {'schema': 'shardloom.pgo_ingest_collection_amendment.v1',
        'status': 'frozen_before_first_native_ingest_observation',
        'protocol': p.identity(experiment.PROTOCOL), 'original_evaluation_binding': p.identity(evaluation.BINDING),
        'corrected_ingest_driver': p.identity(__file__), 'preserved_failure': preserved,
        'preflight': p.identity(ROOT / 'ingest-interpreter-preflight/summary.json'),
        'selected_interpreter': p.identity((PYTHON_BIN / 'python3').resolve()),
        'python_path_prefix': str(PYTHON_BIN), 'native_ingest_observations_before_amendment': 0,
        'query_training_pressure_and_package_results_unchanged': True,
        'source_files_unchanged': True, 'binary_build_flags_and_profiles_unchanged': True,
        'workloads_order_gates_limits_and_native_clocks_unchanged': True,
        'stage_names': ['ingest-recovered-' + str(i) for i in range(1, 5)],
        'role_order': ['control', 'candidate', 'candidate', 'control'],
        'changes': ['Resolve shell python3 to the supported Python 3.13 already used by query supervision.',
                    'Read the standard ingest runner actual prepare_summary.json filename.',
                    'Use fresh stage names; preserve the failed pre-engine launch and every prior observation.'],
        'claim': 'Collection correction only. No native ingest sample was measured or replaced; no engine change or acceptance relaxation.'})
    print(json.dumps({'status': 'bound', 'amendment': p.identity(AMENDMENT)}))


def frozen():
    protocol = evaluation.check_binding()
    amendment = p.read(AMENDMENT)
    assert amendment['protocol'] == p.identity(experiment.PROTOCOL)
    assert amendment['original_evaluation_binding'] == p.identity(evaluation.BINDING)
    assert amendment['corrected_ingest_driver'] == p.identity(__file__)
    assert amendment['selected_interpreter'] == p.identity((PYTHON_BIN / 'python3').resolve())
    assert amendment['native_ingest_observations_before_amendment'] == 0
    for item in amendment['preserved_failure'] + [amendment['preflight']]:
        assert p.identity(item['path']) == item
    environment()
    return protocol


def ingest(index):
    protocol = frozen()
    role = protocol['evaluation']['ingest']['role_order'][index - 1]
    built = experiment.artifacts(role)
    source = protocol['ingest_source']
    assert p.identity(source['path']) == source
    if index > 1:
        experiment.passed('ingest-recovered-' + str(index - 1))
    with experiment.stage('ingest-recovered-' + str(index), output_budget_gib=40) as (steps, report, _):
        target = steps.root / 'uat/vortex/prepared.vortex'
        command = ['/bin/bash', W / 'scripts/run_clickbench_ingest_uat.sh', '--uat-root', steps.root / 'uat',
            '--binary', built['cli']['path'], '--source', source['path'], '--target', target,
            '--input-format', 'parquet', '--memory-gb', '24', '--max-parallelism', '2',
            '--min-free-gib', '12', '--max-workspace-gib', '100', '--max-log-mib', '1024',
            '--max-run-log-mib', '256', '--max-runtime-seconds', '600']
        report['ingest_collection_amendment'] = p.identity(AMENDMENT)
        steps.run('ingest', command, env=environment(), timeout=900)
        summaries = list((steps.root / 'uat').glob('logs/*/prepare_summary.json'))
        assert len(summaries) == 1
        summary = p.read(summaries[0])
        assert summary['returncode'] == 0 and summary['stdout_json_ok'] and summary['target_exists']
        assert summary['source_bytes'] == source['bytes']
        fields = evaluation.no_fallback(p.read(summary['stdout_path']))
        identity = p.identity(target)
        assert identity['sha256'] == protocol['full43_input']['sha256']
        assert identity['bytes'] == protocol['full43_input']['bytes'] == summary['target_bytes']
        assert p.identity(source['path']) == source
        assert p.identity(protocol['full43_input']['path']) == protocol['full43_input']
        assert not (steps.root / 'uat/.ingest-uat.lock').exists()
        generation = p.generation(target)
        opened = subprocess.run(['/usr/sbin/lsof', '-nP', str(target)], capture_output=True, text=True, check=False)
        assert opened.returncode == 1 and not opened.stdout.strip()
        assert p.generation(target) == generation
        report.update(role=role, artifacts=built, source=source, output=identity,
            summary=p.identity(summaries[0]), no_fallback_fields=fields,
            native_process_seconds=summary['native_process_seconds'],
            engine_ingest_seconds=None, engine_ingest_clock_available=False,
            byte_identical_to_full_validated_native_input=True, duplicate_open_handles=False)
        p.save(steps.root / 'duplicate-retirement-plan.json', {'output': identity,
            'retained_equivalent': protocol['full43_input'], 'generation': generation,
            'no_open_handles': True, 'summary': p.identity(summaries[0])})
        target.unlink()
        assert not target.exists()
        report['duplicate_retired'] = True
        report['uat_lock_released'] = True
    print(json.dumps({'status': 'passed', 'stage': 'ingest-recovered-' + str(index),
                      'role': role, 'output_matches_complete_validated_native_input': True}))


def assess():
    frozen()
    pairs = [experiment.passed('paired-' + order) for order in ('a', 'b')]
    held = [experiment.passed('heldout-' + order) for order in ('a', 'b')]
    ingests = [experiment.passed('ingest-recovered-' + str(i)) for i in range(1, 5)]
    for role in ('control', 'candidate'):
        experiment.passed('pressure-' + role)
        experiment.passed('package-' + role)
    savings = []
    for index, pair in enumerate(pairs):
        current = {row['role']: row['native_process_seconds'] for row in ingests[index * 2:index * 2 + 2]}
        totals = {role: current[role] + pair['totals'][role]['process_seconds'] for role in current}
        savings.append({'cohort': index + 1, 'composite_native_process_seconds': totals,
                        'control_minus_candidate_seconds': totals['control'] - totals['candidate']})
    generation = p.read(N / 'pgo-generation-966/generation.json')['seconds']
    components = {name: experiment.passed(name)['stage_seconds']
                  for name in ('control', 'instrumented', 'training', 'merge', 'candidate')}
    additional = max(0.0, generation + components['instrumented'] + components['training'] +
                     components['merge'] + components['candidate'] - components['control'])
    positive = all(item['control_minus_candidate_seconds'] > 0 for item in savings)
    break_even = math.ceil(additional / min(item['control_minus_candidate_seconds'] for item in savings)) if positive else None
    performance_gates = (positive and all(item['engine_gate_passed'] for item in pairs)
                         and all(item['heldout_gate_passed'] for item in held))
    deviations = [{'stage': item['stage'], 'queries': item['deviation_queries']}
                  for item in pairs if item['deviation_queries']]
    deviations += [{'stage': item['stage'], 'heldout_cases': item['deviations']}
                   for item in held if item['deviations']]
    report = {'status': 'passed', 'protocol': p.identity(experiment.PROTOCOL),
        'ingest_collection_amendment': p.identity(AMENDMENT),
        'performance_gates_passed': performance_gates, 'requires_deviation_adjudication': bool(deviations),
        'unadjudicated_query_deviations': deviations, 'workflow_savings': savings,
        'additional_setup_seconds': additional, 'setup_stage_seconds': components,
        'corpus_generation_seconds': generation, 'break_even_reuses': break_even,
        'reuse_count_evidenced': None, 'realized_deployment_benefit_proved': False,
        'release_default_changed': False, 'publication_attempted': False,
        'decision': 'conditional_local_marginal_result_only' if performance_gates and not deviations else 'drop',
        'clock_scope': 'Engine query totals remain separate; complete-process composite and setup costs are diagnostic break-even inputs.'}
    p.save(ROOT / 'assessment.json', report)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['bind', 'ingest-1', 'ingest-2', 'ingest-3', 'ingest-4', 'assess'])
    args = parser.parse_args()
    if args.action == 'bind':
        bind()
    elif args.action == 'assess':
        assess()
    else:
        ingest(int(args.action[-1]))
