"""Original disjoint PGO corpus and independent scalar/group reference values.

PyArrow only writes typed fixture inputs. ShardLoom performs preparation and
execution. Generation and baseline admission are separate from PGO training.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
import re

SCHEMA = [('row_id', 'int64', False), ('cohort', 'int16', False),
          ('code', 'uint16', False), ('member', 'uint64', False),
          ('units', 'int32', False), ('maybe_units', 'int32', True),
          ('real_units', 'float64', False), ('stamp', 'uint64', False),
          ('label', 'string', False), ('optional_label', 'string', True),
          ('url', 'string', False)]
SETTINGS = {
    'train': {'prefix': 'learn_', 'id_start': 0, 'phase': 17,
              'broad_rows': 131072, 'heavy_rows': 1048576, 'selective_rows': 24001},
    'heldout': {'prefix': 'verify_', 'id_start': 10000000, 'phase': 43,
                'broad_rows': 98317, 'heavy_rows': 1100003, 'selective_rows': 28003},
}


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            value.update(block)
    return value.hexdigest()


def artifact(path):
    return {'path': str(path), 'bytes': Path(path).stat().st_size, 'sha256': sha(path)}


def value_row(index, role, kind):
    spec = SETTINGS[role]
    k = index + spec['phase']
    token = 'learn' if role == 'train' else 'verify'
    # A unique row identity and disjoint text domains make complete training and
    # held-out rows disjoint even though useful scalar values/types can overlap.
    if kind == 'heavy':
        slot = k % 1000
        label_id = (0 if slot < 510 else 1 if slot < 760 else 2 if slot < 885
                    else 3 if slot < 948 else 4 if slot < 980 else 5 + slot % 61)
        cohort = 0 if k % 101 < 63 else 1 if k % 101 < 87 else 2
    else:
        label_id = (k * 7) % 257
        cohort = (k * 13) % 37 - 18
    label = f'{token}-label-{label_id:03d}-京都'
    return {
        'row_id': spec['id_start'] + index,
        'cohort': cohort,
        'code': (k * 19) % 71,
        'member': (1 << 60) + (k * 23) % 997,
        'units': (k * 7) % 101 - 50,
        'maybe_units': None if k % 13 == 0 else (k * 11) % 83 - 41,
        'real_units': ((k * 5) % 67 - 33) / 8.0,
        'stamp': 1735689600 + (k % 7201) * 17,
        'label': label,
        'optional_label': None if k % 17 == 0 else label,
        'url': f'https://{token}{k % 5}.example.test/path/{k % 4093:04d}/' + 'x' * 96,
    }


def aggregate(rows, keys, measures, *, key_transform=None, predicate=None,
              order=None, limit=None, offset=0):
    """Python reference only; direct integer sums and exact eighth-valued floats."""
    states = {}
    for row in rows:
        if predicate is not None and not predicate(row):
            continue
        key = tuple(key_transform(row) if key_transform else (row[k] for k in keys))
        state = states.get(key)
        if state is None:
            state = {'n': 0, 'values': {alias: [] if operation == 'distinct' else
                     {'count': 0, 'total': 0, 'lo': None, 'hi': None}
                     for alias, (operation, _) in measures.items()}}
            # Sets retain exact complete values for DISTINCT, not hashes alone.
            for alias, (operation, _) in measures.items():
                if operation == 'distinct':
                    state['values'][alias] = set()
            states[key] = state
        state['n'] += 1
        for alias, (operation, column) in measures.items():
            if operation == 'all':
                continue
            value = column(row) if callable(column) else row[column]
            if value is None:
                continue
            target = state['values'][alias]
            if operation == 'distinct':
                target.add(value)
            else:
                target['count'] += 1
                if operation in ('sum', 'avg'):
                    target['total'] += value
                if target['lo'] is None or value < target['lo']:
                    target['lo'] = value
                if target['hi'] is None or value > target['hi']:
                    target['hi'] = value
    output = []
    for key, state in states.items():
        result = dict(zip(keys, key))
        for alias, (operation, _) in measures.items():
            target = state['values'][alias]
            if operation == 'all': value = state['n']
            elif operation == 'count': value = target['count']
            elif operation == 'distinct': value = len(target)
            elif operation == 'min': value = target['lo']
            elif operation == 'max': value = target['hi']
            elif operation == 'sum': value = float(target['total']) if target['count'] else None
            elif operation == 'avg': value = float(target['total']) / target['count'] if target['count'] else None
            else: raise AssertionError(operation)
            result[alias] = value
        output.append(result)
    if order is not None:
        output.sort(key=order)
    return output[offset:None if limit is None else offset + limit]


def cases(role):
    settings = SETTINGS[role]
    prefix = settings['prefix']
    result = []

    def add(name, kind, sql, keys, measures, *, predicate=None,
            transform=None, order=None, limit=None, offset=0,
            expected_strategies=(), family=None):
        rows = (value_row(i, role, kind) for i in range(settings[kind + '_rows']))
        values = aggregate(rows, keys, measures, key_transform=transform,
            predicate=predicate, order=order, limit=limit, offset=offset)
        rename = {name: prefix + name for name, _, _ in SCHEMA}
        sql = re.sub(r'\b(' + '|'.join(rename) + r')\b', lambda m: rename[m.group(0)], sql)
        values = [{rename.get(key, key): value for key, value in row.items()} for row in values]
        result.append({'name': name, 'dataset': role + '-' + kind, 'sql': sql,
            'expected': values, 'ordered': order is not None,
            'expected_strategies': list(expected_strategies), 'family': family or name})

    numeric = {'n': ('all', None), 'present': ('count', 'maybe_units'),
               'total': ('sum', 'maybe_units'), 'mean': ('avg', 'maybe_units'),
               'lo': ('min', 'maybe_units'), 'hi': ('max', 'maybe_units')}
    add('metadata_count', 'broad', 'SELECT COUNT(*) AS n FROM corpus', [], {'n': ('all', None)})
    add('scalar_numeric', 'broad', 'SELECT SUM(units) AS total, MIN(code) AS lo, MAX(cohort) AS hi FROM corpus', [],
        {'total': ('sum', 'units'), 'lo': ('min', 'code'), 'hi': ('max', 'cohort')}, family='scalar')
    add('scalar_nullable', 'broad', 'SELECT COUNT(*) AS n, COUNT(maybe_units) AS present, SUM(maybe_units) AS total, AVG(maybe_units) AS mean, MIN(maybe_units) AS lo, MAX(maybe_units) AS hi FROM corpus', [], numeric, family='scalar')
    add('scalar_float', 'broad', 'SELECT SUM(real_units) AS total, AVG(real_units) AS mean, MIN(real_units) AS lo, MAX(real_units) AS hi FROM corpus', [],
        {alias: (op, 'real_units') for alias, op in [('total', 'sum'), ('mean', 'avg'), ('lo', 'min'), ('hi', 'max')]}, family='scalar')
    add('exact_integer_extrema', 'broad', 'SELECT MIN(member) AS lo, MAX(member) AS hi, COUNT(DISTINCT member) AS members FROM corpus', [],
        {'lo': ('min', 'member'), 'hi': ('max', 'member'), 'members': ('distinct', 'member')}, family='distinct')
    add('nullable_text', 'broad', 'SELECT optional_label, COUNT(*) AS n FROM corpus GROUP BY optional_label', ['optional_label'], {'n': ('all', None)}, family='text')
    add('numeric_group', 'broad', 'SELECT cohort, COUNT(*) AS n, SUM(units) AS total FROM corpus GROUP BY cohort', ['cohort'], {'n': ('all', None), 'total': ('sum', 'units')}, family='group')
    add('complete_integer_pairs', 'broad', 'SELECT cohort, COUNT(DISTINCT member) AS members FROM corpus GROUP BY cohort ORDER BY members DESC, cohort ASC LIMIT 7 OFFSET 1', ['cohort'], {'members': ('distinct', 'member')},
        order=lambda r: (-r['members'], r['cohort']), limit=7, offset=1,
        expected_strategies=['complete_integer_pair_partition_distinct'], family='distinct')
    add('complete_text_pairs', 'broad', 'SELECT label, COUNT(DISTINCT member) AS members FROM corpus GROUP BY label ORDER BY members DESC, label ASC LIMIT 7 OFFSET 1', ['label'], {'members': ('distinct', 'member')},
        order=lambda r: (-r['members'], r['label']), limit=7, offset=1,
        expected_strategies=['native_utf8_group_integer_complete_pair_distinct'], family='distinct')
    add('pair_preunion', 'broad', 'SELECT cohort, COUNT(*) AS n, SUM(units) AS total, AVG(code) AS mean, COUNT(DISTINCT member) AS members FROM corpus GROUP BY cohort ORDER BY n DESC LIMIT 9', ['cohort'],
        {'n': ('all', None), 'total': ('sum', 'units'), 'mean': ('avg', 'code'), 'members': ('distinct', 'member')},
        order=lambda r: (-r['n'], r['cohort']), limit=9,
        expected_strategies=['direct_accessor_count_distinct_pair_preunion_chunk_group_update'], family='distinct')
    add('numeric_pair_late', 'heavy', 'SELECT cohort, code, COUNT(*) AS n, SUM(units) AS total, AVG(real_units) AS mean FROM corpus GROUP BY cohort, code ORDER BY n DESC LIMIT 9', ['cohort', 'code'],
        {'n': ('all', None), 'total': ('sum', 'units'), 'mean': ('avg', 'real_units')},
        order=lambda r: (-r['n'], r['cohort'], r['code']), limit=9,
        expected_strategies=['numeric_pair_count_topk_late_measure_second_pass'], family='late_measures')
    add('numeric_minute_text', 'broad', 'SELECT cohort, EXTRACT(MINUTE FROM stamp) AS minute, label, COUNT(*) AS n FROM corpus GROUP BY cohort, minute, label ORDER BY n DESC LIMIT 9', ['cohort', 'minute', 'label'], {'n': ('all', None)},
        transform=lambda r: (r['cohort'], (r['stamp'] // 60) % 60, r['label']),
        order=lambda r: (-r['n'], r['cohort'], r['minute'], r['label']), limit=9,
        expected_strategies=['numeric_minute_string_dictionary_code_direct_group_update'], family='compound')
    pattern = r'^https?://(?:www\.)?([^/]+)/.*$'
    add('transformed_dictionary', 'broad', "SELECT REGEXP_REPLACE(url, '^https?://(?:www\\.)?([^/]+)/.*$', '\\1') AS domain, COUNT(*) AS n, AVG(length(url)) AS mean, MIN(url) AS first_url FROM corpus GROUP BY domain HAVING n > 2 ORDER BY domain", ['domain'],
        {'n': ('all', None), 'mean': ('avg', lambda r: len(r['url'].encode())), 'first_url': ('min', 'url')},
        transform=lambda r: (re.sub(pattern, r'\1', r['url']),), order=lambda r: r['domain'],
        expected_strategies=['transformed_dictionary_dense_general_chunk_partial_group_update'], family='transformed')
    add('heavy_text', 'heavy', 'SELECT label, COUNT(*) AS n FROM corpus GROUP BY label ORDER BY n DESC LIMIT 5', ['label'], {'n': ('all', None)},
        order=lambda r: (-r['n'], r['label']), limit=5,
        expected_strategies=['string_dictionary_code_count_topk_heavy_hitter_first_pass_exact', 'string_count_topk_heavy_hitter_first_pass_exact'], family='heavy_hitter')
    add('heavy_numeric_text', 'heavy', 'SELECT cohort, label, COUNT(*) AS n FROM corpus GROUP BY cohort, label ORDER BY n DESC LIMIT 5', ['cohort', 'label'], {'n': ('all', None)},
        order=lambda r: (-r['n'], r['cohort'], r['label']), limit=5,
        expected_strategies=['numeric_utf8_count_topk_heavy_hitter_first_pass_exact'], family='heavy_hitter')
    threshold = settings['id_start'] + settings['selective_rows']
    add('selective_text_late', 'heavy', f'SELECT label, COUNT(*) AS n, MIN(url) AS first_url, COUNT(DISTINCT member) AS members FROM corpus WHERE row_id < {threshold} GROUP BY label ORDER BY n DESC LIMIT 5', ['label'],
        {'n': ('all', None), 'first_url': ('min', 'url'), 'members': ('distinct', 'member')},
        predicate=lambda r: r['row_id'] < threshold,
        order=lambda r: (-r['n'], r['label']), limit=5,
        expected_strategies=['string_dictionary_code_count_topk_first_pass_late_measure_exact'], family='late_measures')
    if role == 'heldout':
        add('heldout_composed_nullable', 'broad', 'SELECT cohort, COUNT(*) AS n, SUM(maybe_units) AS total FROM corpus WHERE units >= 17 GROUP BY cohort ORDER BY total DESC, cohort ASC LIMIT 11 OFFSET 2', ['cohort'],
            {'n': ('all', None), 'total': ('sum', 'maybe_units')}, predicate=lambda r: r['units'] >= 17,
            order=lambda r: (-r['total'], r['cohort']), limit=11, offset=2, family='heldout_composition')
    return result


def generate(destination):
    import pyarrow as pa
    import pyarrow.parquet as pq
    assert not destination.exists()
    destination.mkdir(parents=True)
    manifest = {'schema': 'shardloom.pgo_original_corpus.v1', 'status': 'running',
        'generator': artifact(Path(__file__)), 'pyarrow': pa.__version__, 'settings': SETTINGS,
        'datasets': [], 'cases': [], 'training_heldout_disjoint_basis': 'Distinct row_id ranges and text domains; no ClickBench rows or evaluation results used for training.'}
    try:
        for role, settings in SETTINGS.items():
            prefix = settings['prefix']
            schema = pa.schema([pa.field(prefix + name, getattr(pa, dtype)(), nullable=nullable)
                                for name, dtype, nullable in SCHEMA])
            for kind in ('broad', 'heavy'):
                count = settings[kind + '_rows']
                path = destination / (role + '-' + kind + '.parquet')
                row_digest = hashlib.sha256()
                with pq.ParquetWriter(path, schema, compression='zstd', use_dictionary=True) as writer:
                    for start in range(0, count, 16384):
                        rows = [{prefix + key: value for key, value in value_row(i, role, kind).items()}
                                for i in range(start, min(start + 16384, count))]
                        for row in rows:
                            row_digest.update((json.dumps(row, sort_keys=True, ensure_ascii=False) + '\n').encode())
                        writer.write_table(pa.Table.from_pylist(rows, schema=schema), row_group_size=16384)
                reopened = hashlib.sha256()
                actual_count = 0
                for batch in pq.ParquetFile(path).iter_batches(batch_size=16384):
                    for row in batch.to_pylist():
                        reopened.update((json.dumps(row, sort_keys=True, ensure_ascii=False) + '\n').encode())
                        actual_count += 1
                assert actual_count == count and reopened.digest() == row_digest.digest()
                manifest['datasets'].append({'id': role + '-' + kind, 'role': role,
                    'kind': kind, 'rows': count, 'schema': str(schema), 'file': artifact(path),
                    'complete_input_rows_sha256': row_digest.hexdigest(), 'complete_reopen_verified': True})
                print(json.dumps({'dataset': role + '-' + kind, 'rows': count, 'status': 'generated_verified'}), flush=True)
            role_cases = cases(role)
            manifest['cases'].extend(dict(case, role=role) for case in role_cases)
        manifest['status'] = 'passed'
    except BaseException as error:
        manifest.update(status='failed', error=repr(error))
        raise
    finally:
        (destination / 'manifest.json').write_text(json.dumps(manifest, indent=2, allow_nan=False) + '\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    generate(parser.parse_args().output)
