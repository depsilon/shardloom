__attribute__((noinline)) int add_one(int x) { return x + 1; }
__attribute__((noinline)) int add_three(int x) { return x + 3; }
int native_work(int x) {
    int (*volatile operation)(int) = x & 1 ? add_three : add_one;
    return operation(x);
}
