extern "C" { fn native_work(value: i32) -> i32; }
fn main() {
    let mut total: i64 = 0;
    for value in 0..4096 {
        let actual = unsafe { native_work(std::hint::black_box(value)) };
        assert_eq!(actual, value + if value & 1 == 0 { 1 } else { 3 });
        total += i64::from(actual);
    }
    assert_eq!(total, 8_394_752);
    println!("4096 exact native calls; total={total}");
}
