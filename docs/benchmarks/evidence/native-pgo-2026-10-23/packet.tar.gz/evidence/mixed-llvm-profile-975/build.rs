fn main() {
    let mut build = cc::Build::new();
    build.file("native.c");
    println!("cargo:warning=PROOF_CC {:?}", build.get_compiler().to_command());
    build.compile("profile_proof_native");
}
