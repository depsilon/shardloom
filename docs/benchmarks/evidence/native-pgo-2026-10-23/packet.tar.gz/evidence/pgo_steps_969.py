"""Bounded experiment steps; recursive inventories stay outside native queries."""
from __future__ import annotations
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
N = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022')
PYTHON = '/opt/homebrew/opt/python@3.13/bin/python3.13'
SUPERVISOR = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
GUARD = Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/native_workload_guard_816.py')
sys.path.insert(0, str(W / 'scripts'))
from local_uat_storage import GIB, MIB, accounted_bytes, check_budgets, require_local_path
from native_workflow_protocol import extract_result, report_fields, strict_json
from query_timing_report import query_phase_timings


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


bounded = load('pgo_bounded', SUPERVISOR)
guards = load('pgo_workload', GUARD)


def read(path):
    return strict_json(Path(path).read_text())


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def identity(path):
    path = Path(path)
    initial = generation(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(MIB), b''):
            digest.update(block)
    assert generation(path) == initial
    return {'path': str(path), 'bytes': initial['bytes'], 'sha256': digest.hexdigest()}


def generation(path):
    info = Path(path).stat()
    return {'device': info.st_dev, 'inode': info.st_ino, 'bytes': info.st_size,
            'mtime_ns': info.st_mtime_ns, 'ctime_ns': info.st_ctime_ns}


def source_hashes():
    files = subprocess.check_output(['git', 'ls-files', '-z'], cwd=W).split(b'\0')
    names = {x.decode() for x in files if x and
             (x.endswith(b'.rs') or Path(x.decode()).name in ('Cargo.toml', 'Cargo.lock'))}
    names.update(str(path.relative_to(W)) for path in (W / 'vendor').glob('*/Cargo.lock'))
    return {name: identity(W / name)['sha256'] for name in sorted(names)}


def exact(actual, expected):
    if type(actual) is not type(expected): return False
    if isinstance(actual, dict): return actual.keys() == expected.keys() and all(exact(actual[k], expected[k]) for k in actual)
    if isinstance(actual, list): return len(actual) == len(expected) and all(exact(a, b) for a, b in zip(actual, expected))
    if isinstance(actual, float): return actual.hex() == expected.hex()
    return actual == expected


class Steps:
    def __init__(self, root, *, output_budget_gib=4, experiment_root=None, profile_dir=None):
        root = require_local_path(Path(root), Path.home(), sys.platform)
        assert not root.exists(), 'preserve earlier attempts'
        check_budgets(root, root / 'cargo-target', root / 'logs', min_free_bytes=12 * GIB,
            reserve_bytes=output_budget_gib * GIB, max_workspace_bytes=output_budget_gib * GIB,
            max_log_bytes=256 * MIB)
        assert accounted_bytes(N) + accounted_bytes(Path('/Users/dylan/.cache/shardloom/cargo-target')) <= 100 * GIB
        root.mkdir(parents=True)
        self.root, self.output_budget = root, output_budget_gib * GIB
        self.experiment_root = Path(experiment_root) if experiment_root else root
        self.profile_dir = Path(profile_dir) if profile_dir else None
        self.logs = root / 'logs'
        self.logs.mkdir()
        self.work = guards.WorkloadGuard()
        self.work.check()
        self.records = []
        self.active = {}
        self.last_inventory = 0.0

    def run(self, name, command, *, env=None, timeout=120, native_query=False,
            expected=None, ordered=False, input_identity=None, allow_error=False):
        prefix = self.logs / name
        stdout, stderr = Path(str(prefix) + '.stdout.json'), Path(str(prefix) + '.stderr.txt')
        assert not stdout.exists() and not stderr.exists()
        command = list(map(str, command))
        record = {'name': name, 'command': command, 'status': 'running', 'native_query': native_query}
        self.records.append(record)
        self.active = record
        before = generation(input_identity['path']) if input_identity else None
        wrapped = ([PYTHON, '-B', str(W / 'scripts/timed_native_command.py'),
            '--timing', str(prefix) + '.timing.json', '--pid-file', str(prefix) + '.pid',
            '--shared-process-group', '--', *command] if native_query else command)
        def guard():
            self.work.check(record.get('pid'))
            assert shutil.disk_usage(self.root).free >= 12 * GIB
            # Logs only while a query is active; no source/data/build inventory.
            assert accounted_bytes(self.logs) <= 256 * MIB
            if self.profile_dir is not None and self.profile_dir.exists():
                assert all(p.is_file() and not p.is_symlink() for p in self.profile_dir.iterdir())
                assert sum(p.stat().st_size for p in self.profile_dir.iterdir()) <= GIB
            if input_identity: assert generation(input_identity['path']) == before
            if not native_query and time.monotonic() - self.last_inventory >= 10:
                self.last_inventory = time.monotonic()
                assert accounted_bytes(self.root) <= self.output_budget
                assert accounted_bytes(self.experiment_root) <= 40 * GIB
        environment = dict(os.environ, PYTHONDONTWRITEBYTECODE='1') if env is None else env
        try:
            with stdout.open('xb') as output, stderr.open('xb') as errors:
                status = bounded.run(wrapped, cwd=W, env=environment, output=output, error_output=errors,
                    timeout=timeout, evidence=record, guard=guard, max_output_bytes=32 * MIB)
            assert record['process_group_drained'] and record['direct_child_reaped']
            assert status == 0 or allow_error, (name, status, stderr.read_text()[-2000:])
            if native_query:
                envelope = read(stdout)
                fields = report_fields(envelope)
                assert fields.get('fallback_attempted') == fields.get('external_engine_invoked') == 'false'
                values = extract_result(envelope)
                if expected is not None:
                    key = lambda r: json.dumps(r, sort_keys=True, ensure_ascii=False)
                    actual, reference = (values, expected) if ordered else (sorted(values, key=key), sorted(expected, key=key))
                    assert exact(actual, reference), (name, values[:12], expected[:12])
                native = read(str(prefix) + '.timing.json')
                assert native['returncode'] == 0
                record.update(query_phase_timings(fields, native['seconds']))
                record.update(fields=fields, values=values, native_timing=native,
                              complete_values=expected is not None,
                              native_peak_rss_bytes=native['peak_rss_bytes'])
            record.update(status='passed', stdout=identity(stdout), stderr=identity(stderr))
            raw = stdout.read_bytes()
            compressed = Path(str(stdout) + '.gz')
            compressed.write_bytes(gzip.compress(raw, mtime=0))
            assert gzip.decompress(compressed.read_bytes()) == raw
            record['compressed_stdout'] = identity(compressed)
            stdout.unlink()
            return record
        except BaseException as error:
            record.update(status='failed', error=repr(error))
            raise
        finally:
            self.active = {}
            save(self.root / (name + '.json'), record)


def public_query(binary, source, sql, workers):
    return [str(binary), 'run', 'sql', '--input', str(source), '--input-format', 'vortex',
            '--sql', sql, '--request', 'collect', '--bounded', 'true', '--execution-policy', 'native_vortex',
            '--memory-gb', '4', '--max-parallelism', str(workers), '--format', 'json']


def preflight(manifest_path, binary, output, *, role='train', workers=(1, 4, 12)):
    manifest = read(manifest_path)
    assert manifest['status'] == 'passed'
    assert not os.environ.get('LLVM_PROFILE_FILE'), 'preflight cannot collect a training profile'
    steps = Steps(output, output_budget_gib=4)
    source_before = source_hashes()
    frozen_binary = identity(binary)
    baseline = read(N / 'q29-release-build-950.json')
    assert source_before == baseline['source_after']
    report = {'status': 'running', 'role': role, 'purpose': 'baseline_corpus_admission_not_PGO',
        'manifest': identity(manifest_path), 'binary': frozen_binary, 'source_before': source_before,
        'workers': list(workers), 'records': steps.records, 'datasets': [],
        'harnesses': [identity(__file__), identity(N / 'pgo_corpus_966.py'), identity(SUPERVISOR), identity(GUARD)]}
    try:
        for item in manifest['datasets']:
            if item['role'] != role: continue
            assert identity(item['file']['path']) == item['file']
            target = steps.root / (item['id'] + '.vortex')
            prepared = steps.run(item['id'] + '-prepare', [binary, 'prepare', 'dataframe',
                '--input', item['file']['path'], '--input-format', 'parquet', '--output', target,
                '--memory-gb', '4', '--max-parallelism', '2', '--format', 'json'], timeout=300)
            envelope = strict_json(gzip.decompress(Path(prepared['compressed_stdout']['path']).read_bytes()).decode())
            assert envelope['status'] == 'success'
            fields = report_fields(envelope)
            assert fields.get('fallback_attempted') == fields.get('external_engine_invoked') == 'false'
            source = identity(target)
            report['datasets'].append({'id': item['id'], 'file': source, 'generation': generation(target)})
            for case in manifest['cases']:
                if case['dataset'] != item['id']: continue
                for worker in workers:
                    observation = steps.run(case['name'] + '-w' + str(worker),
                        public_query(binary, target, case['sql'], worker), native_query=True,
                        expected=case['expected'], ordered=case['ordered'], input_identity=source)
                    observation['case'] = case['name']
                    observation['requested_workers'] = worker
                    observation['selected_strategy'] = observation['fields'].get('local_primitive_aggregate_update_strategy')
                    print(json.dumps({'case': case['name'], 'workers': worker, 'status': 'passed',
                        'strategy': observation['selected_strategy']}), flush=True)
        coverage = {}
        for case in (c for c in manifest['cases'] if c['role'] == role and c['expected_strategies']):
            observations = [r for r in steps.records if r.get('case') == case['name']]
            selected = sorted({r['selected_strategy'] for r in observations if r['selected_strategy'] is not None})
            coverage[case['name']] = {'expected': case['expected_strategies'], 'observed': selected,
                'selected_path_observed': any(s in case['expected_strategies'] for s in selected)}
        report['coverage'] = coverage
        report['all_selected_paths_observed'] = all(c['selected_path_observed'] for c in coverage.values())
        assert source_hashes() == source_before and identity(binary) == frozen_binary
        for item in report['datasets']: assert identity(item['file']['path']) == item['file']
        report.update(status='passed', source_unchanged=True, binary_unchanged=True)
    except BaseException as error:
        report.update(status='failed', error=repr(error))
        raise
    finally:
        save(steps.root / 'summary.json', report)
    return report


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--role', choices=('train', 'heldout'), default='train')
    args = parser.parse_args()
    report = preflight(args.manifest, args.binary, args.output, role=args.role)
    print(json.dumps({'status': report['status'], 'coverage': report.get('coverage')}))
