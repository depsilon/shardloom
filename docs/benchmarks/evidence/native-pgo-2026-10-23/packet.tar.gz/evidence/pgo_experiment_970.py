"""Frozen, bounded current-source PGO investigation; no release publication."""
from __future__ import annotations
import argparse
import contextlib
import datetime as dt
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

import pgo_steps_969 as p
from build_native_python import native_artifact
from pgo_local_experiment import fresh_profiles

W, N = p.W, p.N
ROOT = N / 'pgo-investigation-970'
PROTOCOL = N / 'pgo-protocol-970.json'
CORPUS = N / 'pgo-corpus-final-967.json'
PYTHON = N / 'pgo-python-966/bin/python'
TOOLCHAIN = Path('/Users/dylan/.rustup/toolchains/stable-aarch64-apple-darwin')
CARGO, RUSTC = TOOLCHAIN / 'bin/cargo', TOOLCHAIN / 'bin/rustc'
PROFDATA = TOOLCHAIN / 'lib/rustlib/aarch64-apple-darwin/bin/llvm-profdata'
TARGET = 'aarch64-apple-darwin'
PROFILES = ROOT / 'profiles'
PROFILE_INPUT = ROOT / 'profile-transfer/merged.profdata'
BUILD_COMMAND = [str(CARGO), 'build', '--locked', '--offline', '-p', 'shardloom-cli',
    '-p', 'shardloom-python', '--features',
    'shardloom-cli/release-user-surfaces,shardloom-python/python-native',
    '--bin', 'shardloom', '--lib', '--profile', 'release-pgo', '--target', TARGET,
    '--message-format=json-render-diagnostics']


def base_env():
    env = dict(os.environ)
    for key in list(env):
        if key in ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'LLVM_PROFILE_FILE',
                   'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER', 'SHARDLOOM_BIN',
                   'PYTHONPATH', 'PYTHONHOME', 'SHARDLOOM_NATIVE_TEST_LIBRARY',
                   'SHARDLOOM_REPO_ROOT', 'SHARDLOOM_PROFILE_ORDER') or key.startswith('CARGO_PROFILE_'):
            env.pop(key, None)
    env.update(RUSTUP_TOOLCHAIN='stable', RUSTC=str(RUSTC), CARGO_INCREMENTAL='0',
               CARGO_BUILD_JOBS='2', PYO3_PYTHON=str(PYTHON), PYO3_BUILD_EXTENSION_MODULE='1',
               PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1')
    return env


def flags(role):
    if role == 'control': return []
    if role == 'instrumented': return ['-Cprofile-generate=' + str(PROFILES)]
    assert role == 'candidate'
    return ['-Cprofile-use=' + str(PROFILE_INPUT), '-Cllvm-args=-pgo-warn-missing-function']


def source_files():
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=W).decode().split('\0')
    included = {name for name in names if name and
                (name.startswith(('scripts/', 'python/src/', 'python/tests/')) or
                 name in ('rust-toolchain.toml', 'python/pyproject.toml', 'python/setup.py',
                          'python/setup.cfg', '.github/requirements/ci-native-python.txt',
                          '.github/requirements/ci-native-python-build.txt'))}
    included.update(p.source_hashes())
    return {name: p.identity(W / name)['sha256'] for name in sorted(included)}


def freeze():
    assert not ROOT.exists() and not PROTOCOL.exists()
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=W, text=True).strip()
    p.guards.WorkloadGuard().check()
    corpus = p.read(CORPUS)
    assert corpus['status'] == 'passed'
    for item in corpus['datasets']: assert p.identity(item['file']['path']) == item['file']
    assert p.read(N / 'pgo-heldout-preflight-967/summary.json')['all_selected_paths_observed']
    assert p.read(N / 'pgo-numeric-late-preflight-967/summary.json')['status'] == 'passed'
    assert p.read(N / 'pgo-pressure-preflight-969d/summary.json')['status'] == 'passed'
    env = base_env()
    env['CARGO_TARGET_DIR'] = str(ROOT / 'control/cargo-target')
    metadata = p.strict_json(subprocess.check_output([str(CARGO), 'metadata', '--offline',
        '--locked', '--no-deps', '--format-version', '1'], cwd=W, env=env, text=True))
    assert metadata['target_directory'] == env['CARGO_TARGET_DIR']
    packages = {item['name']: item for item in metadata['packages']}
    assert 'release-user-surfaces' in packages['shardloom-cli']['features']
    assert 'python-native' in packages['shardloom-python']['features']
    assert any(item['name'] == '_native' and 'cdylib' in item['crate_types']
               for item in packages['shardloom-python']['targets'])
    assert p.source_hashes() == p.read(N / 'q29-release-build-950.json')['source_after']
    helpers = [Path(__file__), N / 'pgo_steps_969.py', N / 'pgo_pressure_969.py',
               N / 'pgo_native_training_969.py', N / 'pgo_corpus_967.py', p.SUPERVISOR, p.GUARD]
    artifacts = [CORPUS, N / 'pgo-baseline-preflight-966b/summary.json',
        N / 'pgo-numeric-late-preflight-967/summary.json', N / 'pgo-heldout-preflight-967/summary.json',
        N / 'pgo-pressure-preflight-969d/summary.json', N / 'pgo-toolcompat-965b/report.json',
        N / 'pgo-ingest-pressure-contract-968.json', N / 'independent-full43-948/reference.json',
        N / 'independent-full43-948/acceptance.json', N / 'pgo-generation-966/generation.json',
        W / 'benchmarks/clickbench/queries.sql', N / 'pgo-build-tools-install-966.log',
        N / 'pgo-pyarrow-install-966.log']
    native_input = p.identity('/Users/dylan/LocalData/shardloom/clickbench-100m-uat/vortex/fresh-roadmap-663-a1.vortex')
    assert native_input['sha256'] == '06f70eb6f118d11e4a5226eb641225d708fdb4ac1b3f45942872d5ef5df4fc22'
    parquet_input = p.identity('/Users/dylan/LocalData/shardloom/clickbench-100m-uat/sources/hits.parquet')
    wheelhouses = [N / 'pgo-wheelhouse-966',
                  Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/pyarrow-wheelhouse-cp312')]
    wheel_inputs = [p.identity(path) for directory in wheelhouses for path in sorted(directory.glob('*.whl'))]
    cargo_configs = [path for path in (W / '.cargo/config.toml', Path.home() / '.cargo/config.toml') if path.exists()]
    p.check_budgets(ROOT, ROOT / 'control/cargo-target', ROOT / 'logs',
        min_free_bytes=12 * p.GIB, reserve_bytes=40 * p.GIB,
        max_workspace_bytes=40 * p.GIB, max_log_bytes=256 * p.MIB)
    protocol = {
        'schema': 'shardloom.current_source_pgo_protocol.v1',
        'status': 'frozen_before_instrumented_build_training_or_candidate_observations',
        'created_at_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip(),
        'source_tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=W, text=True).strip(),
        'sources': source_files(), 'native_sources': p.source_hashes(),
        'helpers': [p.identity(path) for path in helpers],
        'prerequisites': [p.identity(path) for path in artifacts],
        'full43_input': native_input, 'ingest_source': parquet_input,
        'query_file': p.identity(W / 'benchmarks/clickbench/queries.sql'),
        'wheel_inputs': wheel_inputs, 'cargo_configurations': [p.identity(path) for path in cargo_configs],
        'heldout_inputs': p.read(N / 'pgo-heldout-preflight-967/summary.json')['datasets'],
        'tools': {name: {'file': p.identity(path.resolve()), 'version': subprocess.check_output(
            [str(path), '-vV'] if name == 'rustc' else [str(path), '--version'],
            cwd=W, env=env, text=True)} for name, path in
            [('rustc', RUSTC), ('cargo', CARGO), ('llvm-profdata', PROFDATA), ('python', PYTHON)]},
        'host': {'platform': platform.platform(), 'logical_cpus': os.cpu_count(),
                 'physical_ram_bytes': int(subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.memsize']))},
        'root': str(ROOT), 'metadata_target_directory': metadata['target_directory'],
        'build': {'command': BUILD_COMMAND, 'roles': ['control', 'instrumented', 'candidate'],
            'target_directories': {role: str(ROOT / role / 'cargo-target')
                                   for role in ['control', 'instrumented', 'candidate']},
            'flags': {role: flags(role) for role in ['control', 'instrumented', 'candidate']},
            'environment': {key: env[key] for key in ('RUSTUP_TOOLCHAIN', 'RUSTC', 'CARGO_INCREMENTAL',
                'CARGO_BUILD_JOBS', 'PYO3_PYTHON', 'PYO3_BUILD_EXTENSION_MODULE')},
            'fresh_empty_cargo_target_each_role': True,
            'profile': 'release-pgo inherits release-lto inherits release: ThinLTO, one codegen unit',
            'fresh_scope': 'Empty role-specific Cargo targets; registry source and OS caches shared/uncontrolled.',
            'portable_cpu': True, 'target_cpu_native': False, 'native_source_changes': False},
        'training': {'corpus': p.identity(CORPUS), 'roles_allowed': ['train'],
            'workers': [1, 4, 12], 'calls_per_case_worker': 1, 'cli_queries': 48, 'native_preparations': 2,
            'native_python_operations': 20, 'native_python_complete_value_checks': 19,
            'native_python_workers': 4, 'pressure_mode': 'training', 'pressure_rows': 500000,
            'pressure_calls': 5, 'profile_directory': str(PROFILES),
            'profile_pattern': 'shardloom-%m.profraw', 'profile_count_range': [1, 16],
            'profile_max_bytes': p.GIB, 'profile_reuse_allowed': False,
            'full43_or_heldout_training_allowed': False,
            'coverage': 'Each of the nine selected strategy families must activate for every training worker; Python repeats the 16 training cases at four workers and adds Arrow/native Vortex boundary operations.',
            'control_admission': 'Run the same Python training script against fresh control/staged library without LLVM_PROFILE_FILE before any instrumented build. It is corpus admission, never evaluation.'},
        'evaluation': {'standard_full43': {'queries': list(range(1, 44)), 'repeats': 1,
            'binary': 'candidate', 'memory_gb': 24, 'max_parallelism': 12,
            'runner': 'scripts/run_clickbench_query_uat.py',
            'purpose': 'Required isolated post-implementation observation, separate from comparison.'},
            'paired_full43': {'cohorts': ['alternating', 'reverse_alternating'], 'repeats': 1,
                'calls_per_cohort': 86, 'memory_gb': 24, 'max_parallelism': 12,
                'runner': 'scripts/run_clickbench_paired_query_uat.py',
                'score': 'math.fsum of all 43 engine_execution_seconds for each role in each cohort; both full cohorts retained.'},
            'heldout': {'role': 'heldout', 'cases': 17, 'workers': [1, 4, 12],
                'cohorts': ['control_then_candidate', 'candidate_then_control'],
                'calls_per_cohort': 102, 'complete_exact_results_required': True,
                'sources': 'The two already prepared heldout Vortex files; frozen before training.'},
            'ingest': {'role_order': ['control', 'candidate', 'candidate', 'control'],
                'source': '/Users/dylan/LocalData/shardloom/clickbench-100m-uat/sources/hits.parquet',
                'memory_gb': 24, 'max_parallelism': 2, 'runner': 'scripts/run_clickbench_ingest_uat.sh',
                'native_clock': 'native_process_seconds; no engine-owned ingest timer is supplied by this wrapper',
                'validation': 'Complete generated Vortex SHA-256 must match the retained independently validated 99,997,497-row output; preserve no-fallback envelope, then retire the identical duplicate before the next ingest.'},
            'pressure': {'roles': ['control', 'candidate'], 'custom_mode': 'evaluation',
                'custom_rows': 450001, 'custom_start': -(1 << 59), 'custom_step': 3,
                'public_families': ['aggregate-pressure', 'ordering-pressure'],
                'correctness_only': True, 'larger_than_public_memory_grant_claim': False},
            'package': {'roles': ['control', 'candidate'], 'runner': 'scripts/prove_native_python_wheel.py',
                'actual_prebuilt_cli_and_cdylib': True, 'complete_binding_tests_no_skips': True,
                'scope': 'Current macOS arm64 host; cp310 abi3 wheel exercised on Python 3.12; not other-platform or release proof.'}},
        'gate': {'all_values_types_nulls_order_source_and_no_fallback_checks': 'must pass',
            'training_and_profile_checks': 'must pass before merge or profile-use build; no stale, corrupt or mismatched profiles',
            'full43_engine_improvement': 'candidate total strictly below matched control in both declared cohorts; no minimum percentage invented',
            'per_query_deviation': 'Immediately inspect any candidate engine time above matched control * 1.10 + 0.020 seconds. Do not advance to a new implementation while unexplained; preserve every observation.',
            'heldout': 'candidate engine sum no higher than control * 1.05 + 0.020 seconds in either order; investigate individual >10% +0.020s differences',
            'complete_workflow': 'For each declared pair, candidate native ingest process time plus all 43 complete query process times must be strictly lower than control. This diagnostic composite is not engine time or observed end-to-end elapsed.',
            'setup_break_even': 'Measure complete fresh control/instrumented/profile-use build stages, all preparation/training, merge and local profile transfer. Additional setup = max(0, corpus_generation + instrumented_build_stage + training_stage + merge_stage_including_transfer + candidate_build_stage - control_build_stage). Conservatively include the combined training/heldout corpus generation. Divide by the smallest positive paired complete-workflow saving and round up; no finite break-even when any pair has no saving. Record compiler-only, staging, validation and cleanup components separately without counting a component twice.',
            'reuse_evidence': 'No actual deployment/reuse count is supplied. Record the measured break-even condition, do not invent deployment amortization or promote the portable release default. A favorable local marginal result is conditional, not proven realized deployment benefit.',
            'drop': 'Any correctness/profile/package failure, nonpositive complete-workflow saving, unreconciled regression, or missing required comparison prevents retention. Preserve the exact reason and all results. Unrun stages remain unrun.',
            'early_stop': 'Stop further performance comparisons if a frozen retain gate fails; run only the checks needed to resolve correctness, failure attribution or restore the accepted runtime.'},
        'transfer': {'scope': 'Local profile copy plus complete byte/hash validation into profile-use input; no remote or accelerator transfer claim',
                     'artifact_staging': 'Record binary/library freeze copy separately; wheel build/install/uninstall separately.'},
        'limits': {'minimum_free_gib': 12, 'experiment_gib': 40, 'task_plus_existing_cargo_gib': 100,
                   'log_mib_per_stage': 256, 'output_mib_per_command': 32, 'build_timeout_seconds': 3600,
                   'query_timeout_seconds': 120, 'training_timeout_seconds': 900},
        'isolation': 'No builds, tests, subagents, packaging, profiling or unrelated task work during Full43. Standard limits, locks, deadlines, result validation and cleanup remain. Hash inputs/source and inventory caches outside query execution; active-output limits and lightweight workload guard remain.',
        'retention': 'Freeze CLI/library and provenance, verify every compiler-cache entry and no open handles, then retire that role cache before the next fresh build. Keep active comparison inputs and artifacts; no rollback cache archives.',
        'vortex_provider_decision': 'use_vortex_native_provider: existing feature-gated shardloom-vortex 0.85 boundaries and certificates; no new provider, abstraction, integration or Arrow execution layer.',
        'candidate_observations': 0, 'instrumented_workspace_builds': 0, 'training_runs': 0,
        'publication_attempted': False, 'release_default_changed': False,
    }
    p.save(PROTOCOL, protocol)
    print(json.dumps({'status': 'frozen', 'protocol': p.identity(PROTOCOL), 'source_files': len(protocol['sources'])}))


def frozen():
    protocol = p.read(PROTOCOL)
    assert protocol['status'] == 'frozen_before_instrumented_build_training_or_candidate_observations'
    assert source_files() == protocol['sources']
    for item in protocol['helpers'] + protocol['prerequisites']:
        assert p.identity(item['path']) == item, item['path']
    for item in protocol['tools'].values(): assert p.identity(item['file']['path']) == item['file']
    for item in protocol['wheel_inputs'] + protocol['cargo_configurations']:
        assert p.identity(item['path']) == item
    return protocol


def passed(stage):
    report = p.read(ROOT / stage / 'summary.json')
    assert report['status'] == 'passed', stage
    return report


@contextlib.contextmanager
def stage(name, *, output_budget_gib=4, profiles=False):
    started = time.monotonic()
    protocol = frozen()
    steps = p.Steps(ROOT / name, output_budget_gib=output_budget_gib, experiment_root=ROOT,
                    profile_dir=PROFILES if profiles else None)
    report = {'status': 'running', 'stage': name, 'protocol': p.identity(PROTOCOL),
              'source_before': source_files(), 'records': steps.records}
    try:
        yield steps, report, protocol
        report['source_after'] = source_files()
        assert report['source_before'] == report['source_after'] == protocol['sources']
        report['status'] = 'passed'
    except BaseException as error:
        report.update(status='failed', error=repr(error))
        raise
    finally:
        report['stage_seconds'] = time.monotonic() - started
        p.save(steps.root / 'summary.json', report)


def artifacts(role):
    report = passed(role)
    for entry in report['artifacts'].values(): assert p.identity(entry['path']) == entry
    return report['artifacts']


def build(role):
    if role == 'instrumented':
        passed('control-admission')
        assert not PROFILES.exists()
        PROFILES.mkdir(parents=True)
    if role == 'candidate':
        passed('training')
        merged = passed('merge')
        assert p.identity(PROFILE_INPUT) == merged['transferred_profile']
    with stage(role, output_budget_gib=40, profiles=(role == 'instrumented')) as (steps, report, protocol):
        target = steps.root / 'cargo-target'
        assert not target.exists()
        env = base_env()
        env.update(CARGO_TARGET_DIR=str(target), CARGO_ENCODED_RUSTFLAGS='\x1f'.join(flags(role)))
        temporary = steps.root / 'tmp'
        temporary.mkdir()
        env.update(TMPDIR=str(temporary), TMP=str(temporary), TEMP=str(temporary))
        metadata = steps.run('cargo-metadata', [CARGO, 'metadata', '--offline', '--locked',
            '--no-deps', '--format-version', '1'], env=env)
        parsed = p.strict_json(gzip.decompress(Path(metadata['compressed_stdout']['path']).read_bytes()).decode())
        assert parsed['target_directory'] == str(target)
        report.update(target_directory=str(target), fresh_empty_target=True, rustflags=flags(role),
                      build_command=BUILD_COMMAND, environment=protocol['build']['environment'])
        result = steps.run('cargo-build', BUILD_COMMAND, env=env, timeout=3600)
        messages = [p.strict_json(line) for line in gzip.decompress(
            Path(result['compressed_stdout']['path']).read_bytes()).decode().splitlines() if line.strip()]
        binaries = {Path(item['executable']) for item in messages if item.get('reason') == 'compiler-artifact'
                    and item.get('target', {}).get('name') == 'shardloom'
                    and 'bin' in item.get('target', {}).get('kind', []) and item.get('executable')}
        assert len(binaries) == 1
        selected = {'cli': binaries.pop(), 'library': native_artifact(messages)}
        assert all(path.resolve().is_relative_to(target.resolve()) for path in selected.values())
        assert all(not item.get('fresh') for item in messages
                   if item.get('reason') == 'compiler-artifact' and
                   item.get('target', {}).get('name') in ('shardloom', '_native'))
        destination = steps.root / 'artifacts'
        destination.mkdir()
        copied = {}
        copy_started = time.monotonic()
        for name, original in selected.items():
            source_identity = p.identity(original)
            final = destination / ('shardloom' if name == 'cli' else '_native.abi3.so')
            shutil.copy2(original, final)
            identity = p.identity(final)
            assert identity['sha256'] == source_identity['sha256'] and identity['bytes'] == source_identity['bytes']
            copied[name] = identity
        report.update(artifacts=copied, artifact_staging_seconds=time.monotonic() - copy_started,
            cargo_build_seconds=result['seconds'], package_feature_union=True,
            build_messages=result['compressed_stdout'], compiler_diagnostics=result['stderr'])
        if role != 'control':
            control = artifacts('control')
            assert all(copied[key]['sha256'] != control[key]['sha256'] for key in copied)
        if role == 'instrumented': assert list(PROFILES.iterdir()) == []


def native_training(steps, role, prepared, *, collect_profile):
    built = artifacts(role)
    package = steps.root / 'package'
    env = base_env()
    steps.run('stage-native-package', [PYTHON, '-B', W / 'scripts/stage_native_python_package.py',
        '--repo-root', W, '--stage-dir', package, '--native-library', built['library']['path'],
        '--cli-binary', built['cli']['path']], env=env, timeout=180)
    env['PYTHONPATH'] = str(package / 'src')
    if collect_profile: env['LLVM_PROFILE_FILE'] = str(PROFILES / 'shardloom-%m.profraw')
    command = [PYTHON, '-B', N / 'pgo_native_training_969.py', '--manifest', CORPUS,
        '--prepared', prepared, '--package', package, '--library-sha256', built['library']['sha256'],
        '--output', steps.root / 'native-python']
    if collect_profile: command += ['--profile-directory', PROFILES]
    steps.run('native-python', command, env=env, timeout=900)
    result = p.read(steps.root / 'native-python/summary.json')
    assert result['status'] == 'passed' and result['native_operations'] == 20
    return p.identity(steps.root / 'native-python/summary.json')


def control_admission():
    with stage('control-admission') as (steps, report, _):
        report['native_python'] = native_training(steps, 'control',
            N / 'pgo-baseline-preflight-966b/summary.json', collect_profile=False)


def train():
    instrumented = artifacts('instrumented')
    assert PROFILES.is_dir() and list(PROFILES.iterdir()) == []
    corpus = p.read(CORPUS)
    admitted = {item['id']: item['file'] for item in p.read(N / 'pgo-baseline-preflight-966b/summary.json')['datasets']}
    with stage('training', profiles=True) as (steps, report, _):
        env = base_env()
        env['LLVM_PROFILE_FILE'] = str(PROFILES / 'shardloom-%m.profraw')
        report.update(role='train', datasets=[], profile_directory_empty_before=True)
        for item in corpus['datasets']:
            if item['role'] != 'train': continue
            assert p.identity(item['file']['path']) == item['file']
            target = steps.root / (item['id'] + '.vortex')
            prepared = steps.run(item['id'] + '-prepare', [instrumented['cli']['path'], 'prepare', 'dataframe',
                '--input', item['file']['path'], '--input-format', 'parquet', '--output', target,
                '--memory-gb', '4', '--max-parallelism', '2', '--format', 'json'], env=env, timeout=300)
            envelope = p.strict_json(gzip.decompress(Path(prepared['compressed_stdout']['path']).read_bytes()).decode())
            assert envelope['status'] == 'success'
            fields = p.report_fields(envelope)
            assert fields['fallback_attempted'] == fields['external_engine_invoked'] == 'false'
            identity = p.identity(target)
            assert identity['sha256'] == admitted[item['id']]['sha256']
            report['datasets'].append({'id': item['id'], 'file': identity})
            for case in corpus['cases']:
                if case['dataset'] != item['id']: continue
                for worker in (1, 4, 12):
                    record = steps.run(case['name'] + '-w' + str(worker),
                        p.public_query(instrumented['cli']['path'], target, case['sql'], worker),
                        env=env, native_query=True, expected=case['expected'], ordered=case['ordered'],
                        input_identity=identity)
                    record.update(case=case['name'], requested_workers=worker)
                    if case['expected_strategies']:
                        assert record['fields']['local_primitive_aggregate_update_strategy'] in case['expected_strategies']
        assert len([record for record in steps.records if record['native_query']]) == 48
        prepared_path = steps.root / 'prepared.json'
        p.save(prepared_path, {'status': 'passed', 'role': 'train', 'datasets': report['datasets']})
        report['native_python'] = native_training(steps, 'instrumented', prepared_path, collect_profile=True)
        pressure = steps.run('pressure', [PYTHON, '-B', N / 'pgo_pressure_969.py',
            '--binary', instrumented['cli']['path'], '--output', steps.root / 'pressure',
            '--mode', 'training'], env=env, timeout=300)
        assert p.read(steps.root / 'pressure/summary.json')['status'] == 'passed'
        report['pressure'] = p.identity(steps.root / 'pressure/summary.json')
        paths = fresh_profiles(PROFILES, p.GIB)
        report['raw_profiles'] = [p.identity(path) for path in paths]
        report.update(cli_queries=48, preparations=2, native_python_operations=20, pressure_calls=5,
                      no_heldout_or_full43_training=True, selected_paths_observed=True)


def merge():
    training = passed('training')
    inputs = fresh_profiles(PROFILES, p.GIB)
    assert [p.identity(path) for path in inputs] == training['raw_profiles']
    with stage('merge') as (steps, report, _):
        merged = steps.root / 'merged.profdata'
        result = steps.run('merge-profiles', [PROFDATA, 'merge', '-o', merged, *inputs], env=base_env())
        steps.run('profile-summary', [PROFDATA, 'show', '--detailed-summary', merged], env=base_env())
        assert [p.identity(path) for path in inputs] == training['raw_profiles']
        assert not PROFILE_INPUT.parent.exists()
        PROFILE_INPUT.parent.mkdir()
        started = time.monotonic()
        identity = p.identity(merged)
        shutil.copyfile(merged, PROFILE_INPUT)
        transferred = p.identity(PROFILE_INPUT)
        assert transferred['sha256'] == identity['sha256'] and transferred['bytes'] == identity['bytes']
        report.update(raw_profiles=training['raw_profiles'], merged_profile=identity,
                      transferred_profile=transferred, transfer_seconds=time.monotonic() - started,
                      merge_seconds=result['seconds'], transfer_scope='local_copy_and_complete_hash_validation')


def retire_cache(role):
    built = passed(role)
    artifacts(role)
    target = Path(built['target_directory'])
    assert target == ROOT / role / 'cargo-target' and target.is_dir() and not target.is_symlink()
    p.guards.WorkloadGuard().check()
    records = []
    for path in sorted(target.rglob('*')):
        if path.is_symlink(): records.append({'relative': str(path.relative_to(target)), 'symlink': os.readlink(path)})
        elif path.is_file(): records.append({'relative': str(path.relative_to(target)), **p.identity(path), 'generation': p.generation(path)})
    opened = subprocess.run(['/usr/sbin/lsof', '-nP', '+D', str(target)], capture_output=True, text=True, check=False)
    assert opened.returncode == 1 and not opened.stdout.strip(), opened.stdout[:1000]
    for item in records:
        path = target / item['relative']
        if 'symlink' in item: assert path.is_symlink() and os.readlink(path) == item['symlink']
        else: assert p.generation(path) == item['generation']
    receipt = {'status': 'verified_before_retirement', 'role': role, 'target': str(target),
               'retained_artifacts': built['artifacts'], 'build': p.identity(ROOT / role / 'summary.json'),
               'regeneration': {'protocol': p.identity(PROTOCOL), 'command': BUILD_COMMAND, 'rustflags': flags(role)},
               'inventory': records, 'open_handles': False, 'backup_created': False}
    p.save(ROOT / role / 'cache-retirement-plan.json', receipt)
    shutil.rmtree(target)
    assert not target.exists()
    artifacts(role)
    p.save(ROOT / role / 'cache-retirement.json', {'status': 'passed',
        'plan': p.identity(ROOT / role / 'cache-retirement-plan.json'), 'entries_retired': len(records),
        'retained_artifacts_verified': True, 'cache_absent': True, 'backup_created': False})
    print(json.dumps({'status': 'passed', 'cache_retired': role, 'entries': len(records)}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['freeze', 'build-control', 'control-admission',
        'build-instrumented', 'train', 'merge', 'build-candidate', 'retire-control-cache',
        'retire-instrumented-cache', 'retire-candidate-cache'])
    args = parser.parse_args()
    if args.action == 'freeze': freeze()
    elif args.action.startswith('build-'): build(args.action.removeprefix('build-'))
    elif args.action.startswith('retire-'): retire_cache(args.action.removeprefix('retire-').removesuffix('-cache'))
    elif args.action == 'control-admission': control_admission()
    elif args.action == 'train': train()
    elif args.action == 'merge': merge()
    else: raise AssertionError(args.action)


if __name__ == '__main__':
    main()
