"""Bounded original cross-language reproducer using the pinned cc build helper."""
from pathlib import Path
import hashlib,json,os,resource,subprocess

ROOT=Path(__file__).parent/'mixed-llvm-profile-975'
TOOL=Path('/Users/dylan/.rustup/toolchains/stable-aarch64-apple-darwin')
CARGO=TOOL/'bin/cargo'
PROFDATA=TOOL/'lib/rustlib/aarch64-apple-darwin/bin/llvm-profdata'
TARGET='aarch64-apple-darwin'
FIX='-fno-profile-generate -fno-profile-use'
records=[]

def identity(path):
    raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def no_core():
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))

def run(name,argv,env,expected=0):
    out=ROOT/(name+'.stdout');err=ROOT/(name+'.stderr')
    assert not out.exists() and not err.exists()
    with out.open('wb') as stdout,err.open('wb') as stderr:
        result=subprocess.run(list(map(str,argv)),cwd=ROOT,env=env,stdout=stdout,stderr=stderr,
            timeout=90,check=False,preexec_fn=no_core)
    assert out.stat().st_size+err.stat().st_size < 2<<20
    record=dict(name=name,argv=list(map(str,argv)),returncode=result.returncode,
        stdout=identity(out),stderr=identity(err))
    records.append(record)
    if expected is not None:
        assert result.returncode==expected,(name,result.returncode,err.read_text()[-3000:])
    return result

env=dict(os.environ)
for key in list(env):
    if key in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','LLVM_PROFILE_FILE','CC','CXX','CFLAGS','CXXFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER') or key.startswith(('CARGO_PROFILE_','CFLAGS_','CXXFLAGS_','CC_','CXX_')):
        env.pop(key,None)
env.update(RUSTUP_TOOLCHAIN='stable',RUSTC=str(TOOL/'bin/rustc'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CC='/usr/bin/clang',CXX='/usr/bin/clang++',CC_ENABLE_DEBUG_OUTPUT='1')
report=dict(schema='shardloom.mixed_llvm_profile_probe.v1',status='running',records=records,
    source_files=[identity(ROOT/p) for p in ['Cargo.toml','build.rs','native.c','src/main.rs']],
    compiler_isolation_flags=FIX)
try:
    for name,argv in [('rustc-version',[TOOL/'bin/rustc','-vV']),('clang-version',['/usr/bin/clang','--version']),('profdata-version',[PROFDATA,'--version'])]:
        run(name,argv,env)
    run('lock',[CARGO,'generate-lockfile','--offline'],env)
    profile=ROOT/'fixed-profiles';profile.mkdir()
    merged=ROOT/'fixed.profdata'
    for role in ['broken','control','instrumented','candidate']:
        current=dict(env);current['CARGO_TARGET_DIR']=str(ROOT/('target-'+role))
        profiles=ROOT/'broken-profiles' if role=='broken' else profile
        if role in ('broken','instrumented'):
            profiles.mkdir(exist_ok=True)
            current['CARGO_ENCODED_RUSTFLAGS']='-Cprofile-generate='+str(profiles)
        if role=='candidate':
            current['CARGO_ENCODED_RUSTFLAGS']='-Cprofile-use='+str(merged)
        if role!='broken':
            current['CFLAGS_aarch64_apple_darwin']=FIX
            current['CXXFLAGS_aarch64_apple_darwin']=FIX
        run(role+'-build',[CARGO,'build','--offline','--locked','--release','--target',TARGET,'-vv'],current)
        objects=list((ROOT/('target-'+role)/TARGET/'release/build').glob('*/out/*native.o'))
        assert len(objects)==1,objects
        run(role+'-symbols',['/usr/bin/nm','-a',objects[0]],current)
        symbols=(ROOT/(role+'-symbols.stdout')).read_text()
        assert ('__llvm_profile_instrument_target' in symbols)==(role=='broken'),(role,symbols)
        current['LLVM_PROFILE_FILE']=str(profiles/'probe-%m.profraw')
        outcome=run(role+'-run',[ROOT/('target-'+role)/TARGET/'release/mixed-llvm-profile-proof'],current,
            expected=None if role=='broken' else 0)
        if role=='broken':
            assert outcome.returncode==-11,(outcome.returncode,'expected mixed-profile SIGSEGV not reproduced')
        else:
            assert (ROOT/(role+'-run.stdout')).read_text().strip()=='4096 exact native calls; total=8394752'
        if role=='instrumented':
            raw=sorted(profile.glob('*.profraw'));assert len(raw)==1 and sum(x.stat().st_size for x in raw)<1<<20
            run('merge',[PROFDATA,'merge','-o',merged,*raw],current)
            run('show',[PROFDATA,'show','--all-functions','--counts',merged],current)
    report.update(status='passed',broken_reproduces_sigsegv=True,
        fixed_control_instrumented_profile_use_exact_results=True,
        fixed_c_objects_uninstrumented=True,merged_profile=identity(merged),
        profiles=[identity(x) for x in sorted(profile.glob('*.profraw'))])
except BaseException as error:
    report.update(status='failed',error=repr(error))
    raise
finally:
    (ROOT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
