"""Exact public native spill and quota acceptance for compiler variants/training."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import sys

REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
sys.path.insert(0, str(REPO/'scripts'))
from local_uat_storage import accounted_bytes, require_local_path
from native_workflow_protocol import report_fields
from run_clickbench_query_uat import extract_result, run_profiled_command, strict_json
from run_heldout_operator_uat import validate_no_fallback
from run_resident_call_path_uat import generation


def execute(binary, output, mode):
    binary = binary.resolve(strict=True)
    output = require_local_path(output, Path.home(), sys.platform)
    assert not output.exists()
    output.mkdir(parents=True)
    def digest(path):
        with path.open('rb') as stream:
            return hashlib.file_digest(stream, 'sha256').hexdigest()
    binary_before = generation(binary)
    binary_hash = digest(binary)
    rows, start, step, column = ((500_000, 1 << 60, 1, 'train_priority') if mode == 'training'
                                else (450_001, -(1 << 59), 3, 'evaluation_rank'))
    offset, limit = rows - 19, 11
    source, workspace = output/'range.vortex', output/'spill-workspace'
    records = []
    report = dict(status='running', mode=mode, performance_claim=False,
                  binary=str(binary), binary_sha256=binary_hash, rows=rows,
                  start=start, step=step, column=column, offset=offset, limit=limit,
                  records=records, script_sha256=digest(Path(__file__)))
    def guard():
        assert shutil.disk_usage(output).free >= 12*1024**3
        assert accounted_bytes(output) <= 256*1024**2
        assert generation(binary) == binary_before
    def run(name, args, error=False):
        guard()
        command = [str(binary), *args]
        record = dict(name=name, command=command, passed=False)
        records.append(record)
        record.update(run_profiled_command(command, output/name, 120, guard))
        envelope = strict_json((output/(name+'.stdout.json')).read_text())
        validate_no_fallback(envelope)
        boundary_fields = envelope.get('fields', []) + envelope.get('policy', {}).get('fields', [])
        external = [field['value'] for field in boundary_fields
                    if field['key'].endswith('external_engine_invoked')]
        assert all(value is False or value == 'false' for value in external)
        record['external_engine_false_fields'] = len(external)
        unexpected = [x for x in record['guard_failures']
                      if not (error and x == 'profiled native command failed')]
        assert not unexpected, unexpected
        if error:
            assert record['returncode'] != 0 and envelope['status'] != 'success'
            assert 'quota' in json.dumps(envelope).lower()
            assert envelope['fallback']['allowed'] is False and envelope['fallback']['engine'] is None
            record['boundary_evidence_scope'] = 'native quota diagnostic; structured fallback denied; external invocation field may be absent'
        else:
            assert record['returncode'] == 0 and envelope['status'] == 'success'
            assert external, 'successful native command lacks external-engine evidence'
            record['boundary_evidence_scope'] = 'structured fallback denied and explicit external-engine false fields'
        record['passed'] = True
        return envelope
    common = ['--request','collect','--bounded','true','--execution-policy','native_vortex',
              '--memory-gb','1','--max-parallelism','1','--format','json']
    payload = dict(order_by=[dict(column=column, descending=True)], offset=offset,
                   spill=dict(workspace=str(workspace), memory_bytes=8_388_608, quota_bytes=33_554_432))
    sql = f'SELECT * FROM heldout ORDER BY {column} DESC LIMIT {limit} OFFSET {offset}'
    try:
        # Typed fixture writing only; all preparation and ordering execute in
        # ShardLoom. The historical generated-source CLI flags were retired.
        import pyarrow as pa
        import pyarrow.parquet as pq
        fixture = output / 'range.parquet'
        values = pa.array(range(start, start + rows * step, step), type=pa.int64())
        schema = pa.schema([pa.field(column, pa.int64(), nullable=False)])
        pq.write_table(pa.Table.from_arrays([values], schema=schema), fixture)
        report['fixture'] = dict(path=str(fixture), sha256=digest(fixture),
                                 writer='pyarrow ' + pa.__version__, external_query_execution=False)
        run('prepare', ['prepare','dataframe','--input',str(fixture),'--input-format','parquet',
            '--output',str(source),
            '--memory-gb','1','--max-parallelism','2','--format','json'])
        source_before, source_hash = generation(source), digest(source)
        report['source'] = dict(path=str(source), generation=source_before, sha256=source_hash)
        base = ['--input',str(source),'--input-format','vortex',*common]
        run('route', ['route','sql',*base,'--sql',sql,'--vortex-sort-rows',json.dumps(payload)])
        assert not workspace.exists(), 'route inspection performed IO'
        workspace.mkdir()
        expected = [{column:start+index*step} for index in range(rows-1-offset, rows-1-offset-limit, -1)]
        for surface in ['dataframe','sql']:
            args = ['run',surface,*base,'--vortex-sort-rows',json.dumps(payload)]
            args += (['--sql',sql] if surface == 'sql' else
                     ['--vortex-primitive','sort_rows','--vortex-source-order-limit',str(limit)])
            envelope = run(surface, args)
            assert extract_result(envelope) == expected
            fields = report_fields(envelope)
            prefix = 'local_primitive_native_sort_spill_'
            details = {key: int(fields[prefix + key]) for key in
                       ('runs_written', 'runs_validated', 'merge_passes',
                        'peak_reserved_bytes', 'peak_disk_bytes')}
            details['owned_cleanup_completed'] = fields[prefix + 'owned_cleanup_completed'] == 'true'
            assert details['runs_written'] > 8 and details['runs_written'] == details['runs_validated']
            assert details['merge_passes'] > 0 and details['owned_cleanup_completed'] is True
            assert details['peak_reserved_bytes'] <= 8_388_608 and details['peak_disk_bytes'] <= 33_554_432
            assert list(workspace.iterdir()) == []
            records[-1].update(complete_values=True, spill=details)
        payload['spill']['quota_bytes'] = 32_769
        run('quota-denial',['run','dataframe',*base,'--vortex-sort-rows',json.dumps(payload),
            '--vortex-primitive','sort_rows','--vortex-source-order-limit',str(limit)],error=True)
        assert list(workspace.iterdir()) == []
        assert generation(source) == source_before and digest(source) == source_hash
        assert generation(binary) == binary_before and digest(binary) == binary_hash
        guard()
        report.update(status='passed', complete_values=True, actual_spill=True,
                      side_effect_free_route=True, quota_denial=True, cleanup=True,
                      fallback_attempted=False, external_engine_invoked=False,
                      external_engine_evidence_scope='explicit success/route fields; native error diagnostic and native-only commands for quota denial')
    except BaseException as error:
        report.update(status='failed', error=repr(error))
        raise
    finally:
        (output/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--binary',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--mode',choices=['training','evaluation'],required=True)
    args = parser.parse_args()
    report = execute(args.binary,args.output,args.mode)
    print(json.dumps({key:report[key] for key in ['status','mode','rows','actual_spill','quota_denial','cleanup']}))
