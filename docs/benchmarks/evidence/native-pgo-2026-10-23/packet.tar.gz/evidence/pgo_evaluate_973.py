"""Execute the comparisons fixed by pgo-protocol-970.json, one stage at a time."""
from __future__ import annotations
import argparse
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import time

import pgo_experiment_972 as experiment
import pgo_steps_969 as p
from clickbench_reference_packet import load_reference_packet
from run_clickbench_query_uat import equivalent
from run_clickbench_paired_query_uat import role_order

W, N, ROOT = experiment.W, experiment.N, experiment.ROOT
BINDING = N / 'pgo-evaluation-binding-973.json'
REFERENCE = N / 'independent-full43-948/reference.json'
WHEELHOUSE = Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019/pyarrow-wheelhouse-cp312')


def bind():
    experiment.frozen()
    assert not (ROOT / 'training').exists() and not (ROOT / 'candidate').exists()
    assert not experiment.PROFILES.exists() or not list(experiment.PROFILES.iterdir())
    original = p.read(N / 'pgo-evaluation-binding-970.json')
    assert original['status'] == 'bound_before_workspace_instrumentation_and_training'
    assert p.identity(original['evaluator']['path']) == original['evaluator']
    p.save(BINDING, {'status': 'evaluation_harness_amended_before_training_and_candidate_observations',
        'protocol': p.identity(experiment.PROTOCOL), 'evaluator': p.identity(__file__),
        'original_binding': p.identity(N / 'pgo-evaluation-binding-970.json'),
        'preinstrument_amendment': p.identity(experiment.AMENDMENT),
        'instrumented_build_started': (ROOT / 'instrumented').exists(),
        'training_runs': 0, 'candidate_observations': 0,
        'scope': 'Validate the amended training harness through the final evaluation; include heldout individual deviations in the final unresolved-deviation gate. Calls, ordering, thresholds, scores and retain/drop contract remain unchanged.'})


def check_binding():
    binding = p.read(BINDING)
    assert binding['status'] == 'evaluation_harness_amended_before_training_and_candidate_observations'
    assert p.identity(experiment.AMENDMENT) == binding['preinstrument_amendment']
    assert p.identity(binding['original_binding']['path']) == binding['original_binding']
    assert p.identity(experiment.PROTOCOL) == binding['protocol']
    assert p.identity(__file__) == binding['evaluator']
    return experiment.frozen()


def no_fallback(envelope):
    fields = p.report_fields(envelope)
    assert fields['fallback_attempted'] == fields['external_engine_invoked'] == 'false'
    assert envelope['status'] == 'success'
    return fields


def light_workflow(steps, name, command, input_identity, *, timeout=900):
    """No recursive source, cache or experiment scans while Full43 runs."""
    before = p.generation(input_identity['path'])
    assert p.identity(input_identity['path']) == input_identity
    work = p.guards.WorkloadGuard()
    work.check()
    record = {'name': name, 'command': list(map(str, command)), 'status': 'running',
              'native_query_workflow': True, 'host_samples': [], 'input_generation': before}
    steps.records.append(record)
    output = steps.logs / (name + '.log')
    last_sample = 0.0

    def guard():
        nonlocal last_sample
        work.check(record.get('pid'))
        assert shutil.disk_usage(steps.root).free >= 12 * p.GIB
        assert p.generation(input_identity['path']) == before
        if time.monotonic() - last_sample >= 2:
            lines = subprocess.check_output(['ps', '-axo', 'pid=,ppid=,pgid=,pcpu=,rss=,comm='],
                                            text=True, timeout=10).splitlines()
            rows = []
            for line in lines:
                fields = line.strip().split(None, 5)
                if len(fields) == 6 and (int(fields[0]) in work.owned or float(fields[3]) >= 1):
                    rows.append({'pid': int(fields[0]), 'parent': int(fields[1]), 'group': int(fields[2]),
                                 'cpu_percent': float(fields[3]), 'rss_bytes': int(fields[4]) * 1024,
                                 'executable': Path(fields[5]).name})
            record['host_samples'].append({'load_average': list(os.getloadavg()), 'processes': rows})
            last_sample = time.monotonic()

    try:
        with output.open('xb') as stream:
            status = p.bounded.run(record['command'], cwd=W, env=experiment.base_env(), output=stream,
                timeout=timeout, evidence=record, guard=guard, max_output_bytes=8 * p.MIB)
        assert status == 0 and record['process_group_drained'] and record['direct_child_reaped']
        assert p.identity(input_identity['path']) == input_identity
        assert p.generation(input_identity['path']) == before
        work.check()
        record.update(status='passed', source_hash_before_after=True)
        return record
    except BaseException as error:
        record.update(status='failed', error=repr(error))
        raise
    finally:
        record['log'] = p.identity(output)


def full43(paired=None):
    protocol = check_binding()
    built = {role: experiment.artifacts(role) for role in ('control', 'candidate')}
    name = 'standard-full43' if paired is None else 'paired-' + paired
    if paired is not None: experiment.passed('standard-full43')
    if paired == 'b': experiment.passed('paired-a')
    with experiment.stage(name) as (steps, report, _):
        root = steps.root / 'uat'
        input_identity = protocol['full43_input']
        query_file = protocol['query_file']
        assert p.identity(query_file['path']) == query_file
        reference = load_reference_packet(REFERENCE, Path(query_file['path']))
        assert reference['packet']['reference_kind'] == 'independent_reference'
        if paired is None:
            command = [p.PYTHON, '-B', W / 'scripts/run_clickbench_query_uat.py',
                '--binary', built['candidate']['cli']['path'], '--build-commit', protocol['source_commit'],
                '--compress-logs']
        else:
            command = [p.PYTHON, '-B', W / 'scripts/run_clickbench_paired_query_uat.py',
                '--control-binary', built['control']['cli']['path'], '--control-commit', protocol['source_commit'],
                '--candidate-binary', built['candidate']['cli']['path'], '--candidate-commit', protocol['source_commit']]
            if paired == 'b': command += ['--reverse-order']
        command += ['--input', input_identity['path'], '--uat-root', root, '--reference-packet', REFERENCE,
                    '--queries', query_file['path'], '--repeats', '1', '--memory-gb', '24',
                    '--max-parallelism', '12', '--max-log-mib', '1024', '--max-run-log-mib', '256']
        report.update(input=input_identity, reference=p.identity(REFERENCE), query_file=query_file,
                      artifacts=built, evaluator=p.identity(__file__), evaluation_binding=p.identity(BINDING))
        print('Prepared frozen inputs; starting isolated ' + name + '.', flush=True)
        light_workflow(steps, name, command, input_identity)
        print('Queries finished; validating complete raw results and identities.', flush=True)
        summaries = list(root.glob('logs/*/summary.json'))
        assert len(summaries) == 1
        path = summaries[0]
        summary = p.read(path)
        assert summary['completed_identity_check'] and summary['reference_packet_identity_verified']
        assert summary['reference_kind'] == 'independent_reference'
        assert summary['reference_packet']['sha256'] == p.identity(REFERENCE)['sha256']
        assert summary['repeats'] == 1 and summary['selected_query_ids'] == list(range(1, 44))
        expected_keys = ([(q, 'candidate') for q in range(1, 44)] if paired is None else
                         [(q, role) for q in range(1, 44) for role in role_order(q, 1, paired == 'b')])
        actual_keys = [(row['query'], row.get('role', 'candidate')) for row in summary['records']]
        assert actual_keys == expected_keys
        observed = []
        for row in summary['records']:
            query, role = row['query'], row.get('role', 'candidate')
            assert row['run'] == 1 and row['passed'] and row['returncode'] == 0
            assert row['validation'] == 'complete_values' and row['engine_timing_reported']
            assert row['guard_failures'] == [] and row['query_statement'] == reference['queries'][query - 1]
            if paired is None:
                prefix = f'q{query:02d}_run1'
                raw = gzip.decompress((path.parent / (prefix + '.stdout.json.gz')).read_bytes())
                timing = p.read(path.parent / (prefix + '.timing.json'))
            else:
                prefix = f'q{query:02d}_run1_{role}'
                with tarfile.open(path.parent / f'q{query:02d}_completed.tar.xz') as archive:
                    raw = archive.extractfile(prefix + '.stdout.json').read()
                    timing = p.strict_json(archive.extractfile(prefix + '.timing.json').read().decode())
            envelope = p.strict_json(raw.decode())
            fields = no_fallback(envelope)
            values = p.extract_result(envelope)
            assert equivalent(values, reference['values'][query])
            assert timing['returncode'] == 0
            phases = p.query_phase_timings(fields, timing['seconds'])
            assert phases['engine_execution_seconds'] == row['engine_execution_seconds']
            assert phases['process_wall_seconds'] == row['process_wall_seconds']
            observed.append({'query': query, 'role': role, 'engine_seconds': row['engine_execution_seconds'],
                             'process_seconds': row['process_wall_seconds'], 'rows': len(values),
                             'raw_sha256': hashlib.sha256(raw).hexdigest()})
        totals = {role: {'engine_seconds': math.fsum(r['engine_seconds'] for r in observed if r['role'] == role),
                         'process_seconds': math.fsum(r['process_seconds'] for r in observed if r['role'] == role),
                         'rows': sum(r['rows'] for r in observed if r['role'] == role)}
                  for role in ('control', 'candidate') if any(r['role'] == role for r in observed)}
        assert all(item['rows'] == 381 for item in totals.values())
        by_query = {(r['query'], r['role']): r['engine_seconds'] for r in observed}
        if paired is None:
            prior_receipt = p.read(N / 'full43-restored-run-964.json')
            prior = p.read(prior_receipt['summary']['path'])
            controls = {r['query']: r['engine_execution_seconds'] for r in prior['records']}
            comparison_scope = 'single candidate observation versus prior restored observation; attribution trigger only'
        else:
            controls = {q: by_query[q, 'control'] for q in range(1, 44)}
            comparison_scope = 'declared matched comparison'
        deltas = [{'query': q, 'control_engine_seconds': controls[q],
                   'candidate_engine_seconds': by_query[q, 'candidate'],
                   'delta_seconds': by_query[q, 'candidate'] - controls[q],
                   'deviation_triggered': by_query[q, 'candidate'] > controls[q] * 1.10 + 0.020}
                  for q in range(1, 44)]
        assert not (root / '.ingest-uat.lock').exists()
        for role in built: assert experiment.artifacts(role) == built[role]
        report.update(summary=p.identity(path), totals=totals, observations=observed,
            query_deltas=deltas, deviation_queries=[row['query'] for row in deltas if row['deviation_triggered']],
            complete_values=True, uat_lock_released=True, comparison_scope=comparison_scope)
        if paired is not None:
            report['engine_gate_passed'] = totals['candidate']['engine_seconds'] < totals['control']['engine_seconds']
        print(json.dumps({'stage': name, 'engine_totals': {r: t['engine_seconds'] for r, t in totals.items()},
                          'deviation_queries': report['deviation_queries']}), flush=True)


def heldout(order):
    protocol = check_binding()
    experiment.passed('standard-full43')
    corpus = p.read(experiment.CORPUS)
    sources = {item['id']: item['file'] for item in protocol['heldout_inputs']}
    for identity in sources.values(): assert p.identity(identity['path']) == identity
    built = {role: experiment.artifacts(role) for role in ('control', 'candidate')}
    with experiment.stage('heldout-' + order) as (steps, report, _):
        report.update(role='heldout', datasets=protocol['heldout_inputs'], artifacts=built)
        roles = ['control', 'candidate'] if order == 'a' else ['candidate', 'control']
        for case in (item for item in corpus['cases'] if item['role'] == 'heldout'):
            source = sources[case['dataset']]
            for worker in (1, 4, 12):
                for role in roles:
                    record = steps.run(f'{case["name"]}-w{worker}-{role}',
                        p.public_query(built[role]['cli']['path'], source['path'], case['sql'], worker),
                        env=experiment.base_env(), native_query=True, expected=case['expected'],
                        ordered=case['ordered'], input_identity=source)
                    record.update(role=role, case=case['name'], workers=worker)
                    if case['expected_strategies']:
                        assert record['fields']['local_primitive_aggregate_update_strategy'] in case['expected_strategies']
        assert len(steps.records) == 102
        totals = {role: math.fsum(r['engine_execution_seconds'] for r in steps.records if r['role'] == role)
                  for role in roles}
        report.update(engine_totals=totals,
                      heldout_gate_passed=totals['candidate'] <= totals['control'] * 1.05 + 0.020)
        keyed = {(r['case'], r['workers'], r['role']): r['engine_execution_seconds'] for r in steps.records}
        report['deviations'] = [{'case': name, 'workers': worker,
            'control_engine_seconds': value, 'candidate_engine_seconds': keyed[name, worker, 'candidate']}
            for (name, worker, role), value in keyed.items() if role == 'control'
            and keyed[name, worker, 'candidate'] > value * 1.10 + 0.020]
        for identity in sources.values(): assert p.identity(identity['path']) == identity
        for role in built: assert experiment.artifacts(role) == built[role]
        print(json.dumps({'stage': 'heldout-' + order, 'engine_totals': totals,
                          'heldout_gate_passed': report['heldout_gate_passed'], 'deviations': report['deviations']}))


def pressure(role):
    check_binding()
    built = experiment.artifacts(role)
    with experiment.stage('pressure-' + role) as (steps, report, _):
        env = experiment.base_env()
        steps.run('heldout-ordering', [experiment.PYTHON, '-B', N / 'pgo_pressure_969.py',
            '--binary', built['cli']['path'], '--output', steps.root / 'heldout-ordering',
            '--mode', 'evaluation'], env=env, timeout=300)
        assert p.read(steps.root / 'heldout-ordering/summary.json')['status'] == 'passed'
        env['PYTHONPATH'] = str(W / 'python/src') + os.pathsep + str(W / 'scripts')
        steps.run('streaming-pressure', [experiment.PYTHON, '-B', W / 'scripts/run_native_streaming_input_uat.py',
            '--binary', built['cli']['path'], '--uat-root', steps.root / 'streaming-pressure',
            '--operation-timeout', '120', '--compress-logs', '--families', 'aggregate-pressure', 'ordering-pressure'],
            env=env, timeout=900)
        summary = p.read(steps.root / 'streaming-pressure/summary.json')
        assert summary['status'] == 'passed'
        report.update(artifacts=built, custom=p.identity(steps.root / 'heldout-ordering/summary.json'),
                      streaming=p.identity(steps.root / 'streaming-pressure/summary.json'), correctness_only=True)


def package(role):
    check_binding()
    built = experiment.artifacts(role)
    with experiment.stage('package-' + role) as (steps, report, _):
        steps.run('native-wheel-proof', [experiment.PYTHON, '-B', W / 'scripts/prove_native_python_wheel.py',
            '--repo-root', W, '--output-dir', steps.root / 'proof',
            '--native-library', built['library']['path'], '--cli-binary', built['cli']['path'],
            '--wheelhouse', WHEELHOUSE], env=experiment.base_env(), timeout=1800)
        proof = p.read(steps.root / 'proof/report.json')
        assert proof['status'] == 'passed' and proof['uninstall_status'] == 'passed'
        assert proof['integration']['tests'] > 0 and proof['integration']['skipped'] == 0
        assert proof['integrity']['native_library_sha256'] == built['library']['sha256']
        assert proof['integrity']['cli_sha256'] == built['cli']['sha256']
        report.update(artifacts=built, proof=p.identity(steps.root / 'proof/report.json'),
                      native_tests=proof['integration'], publication_attempted=False)


def ingest(index):
    protocol = check_binding()
    role = ['control', 'candidate', 'candidate', 'control'][index - 1]
    built = experiment.artifacts(role)
    source = protocol['ingest_source']
    assert p.identity(source['path']) == source
    if index > 1: experiment.passed('ingest-' + str(index - 1))
    with experiment.stage('ingest-' + str(index), output_budget_gib=40) as (steps, report, _):
        target = steps.root / 'uat/vortex/prepared.vortex'
        command = ['/bin/bash', W / 'scripts/run_clickbench_ingest_uat.sh', '--uat-root', steps.root / 'uat',
            '--binary', built['cli']['path'], '--source', source['path'], '--target', target,
            '--input-format', 'parquet', '--memory-gb', '24', '--max-parallelism', '2',
            '--min-free-gib', '12', '--max-workspace-gib', '100', '--max-log-mib', '1024',
            '--max-run-log-mib', '256', '--max-runtime-seconds', '600']
        # The standard ingest runner retains its own storage and residency guard.
        steps.run('ingest', command, env=experiment.base_env(), timeout=900)
        summaries = list((steps.root / 'uat').glob('logs/*/summary.json'))
        assert len(summaries) == 1
        summary = p.read(summaries[0])
        assert summary['returncode'] == 0 and summary['stdout_json_ok'] and summary['target_exists']
        assert summary['source_bytes'] == source['bytes']
        fields = no_fallback(p.read(summary['stdout_path']))
        identity = p.identity(target)
        assert identity['sha256'] == protocol['full43_input']['sha256']
        assert identity['bytes'] == protocol['full43_input']['bytes'] == summary['target_bytes']
        assert p.identity(source['path']) == source
        assert p.identity(protocol['full43_input']['path']) == protocol['full43_input']
        assert not (steps.root / 'uat/.ingest-uat.lock').exists()
        generation = p.generation(target)
        opened = subprocess.run(['/usr/sbin/lsof', '-nP', str(target)], capture_output=True, text=True, check=False)
        assert opened.returncode == 1 and not opened.stdout.strip()
        assert p.generation(target) == generation
        report.update(role=role, artifacts=built, source=source, output=identity,
            summary=p.identity(summaries[0]), no_fallback_fields=fields,
            native_process_seconds=summary['native_process_seconds'],
            engine_ingest_seconds=None, engine_ingest_clock_available=False,
            byte_identical_to_full_validated_native_input=True, duplicate_open_handles=False)
        p.save(steps.root / 'duplicate-retirement-plan.json', {'output': identity,
            'retained_equivalent': protocol['full43_input'], 'generation': generation,
            'no_open_handles': True, 'summary': p.identity(summaries[0])})
        target.unlink()
        assert not target.exists()
        report['duplicate_retired'] = True
        report['uat_lock_released'] = True


def assess():
    protocol = check_binding()
    pairs = [experiment.passed('paired-' + order) for order in ('a', 'b')]
    held = [experiment.passed('heldout-' + order) for order in ('a', 'b')]
    ingests = [experiment.passed('ingest-' + str(index)) for index in range(1, 5)]
    for role in ('control', 'candidate'):
        experiment.passed('pressure-' + role)
        experiment.passed('package-' + role)
    savings = []
    for index, pair in enumerate(pairs):
        current = {row['role']: row['native_process_seconds'] for row in ingests[index * 2:index * 2 + 2]}
        totals = {role: current[role] + pair['totals'][role]['process_seconds'] for role in current}
        savings.append({'cohort': index + 1, 'composite_native_process_seconds': totals,
                        'control_minus_candidate_seconds': totals['control'] - totals['candidate']})
    generation = p.read(N / 'pgo-generation-966/generation.json')['seconds']
    components = {name: experiment.passed(name)['stage_seconds']
                  for name in ('control', 'instrumented', 'training', 'merge', 'candidate')}
    additional = max(0.0, generation + components['instrumented'] + components['training'] +
                     components['merge'] + components['candidate'] - components['control'])
    positive = all(item['control_minus_candidate_seconds'] > 0 for item in savings)
    break_even = math.ceil(additional / min(item['control_minus_candidate_seconds'] for item in savings)) if positive else None
    performance_gates = (positive and all(item['engine_gate_passed'] for item in pairs)
                         and all(item['heldout_gate_passed'] for item in held))
    unexplained = [{'stage': item['stage'], 'queries': item['deviation_queries']}
                   for item in pairs if item['deviation_queries']]
    unexplained += [{'stage': item['stage'], 'heldout_cases': item['deviations']}
                    for item in held if item['deviations']]
    report = {'status': 'passed', 'protocol': p.identity(experiment.PROTOCOL),
        'performance_gates_passed': performance_gates, 'requires_deviation_adjudication': bool(unexplained),
        'unadjudicated_query_deviations': unexplained, 'workflow_savings': savings,
        'additional_setup_seconds': additional, 'setup_stage_seconds': components,
        'corpus_generation_seconds': generation, 'break_even_reuses': break_even,
        'reuse_count_evidenced': None, 'realized_deployment_benefit_proved': False,
        'release_default_changed': False, 'publication_attempted': False,
        'decision': 'conditional_local_marginal_result_only' if performance_gates and not unexplained else 'drop',
        'clock_scope': 'Engine query totals remain separate; complete-process composite and setup costs are diagnostic break-even inputs.'}
    p.save(ROOT / 'assessment.json', report)
    print(json.dumps(report, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['bind', 'standard', 'paired-a', 'paired-b', 'heldout-a', 'heldout-b',
        'pressure-control', 'pressure-candidate', 'package-control', 'package-candidate',
        'ingest-1', 'ingest-2', 'ingest-3', 'ingest-4', 'assess'])
    args = parser.parse_args()
    if args.action == 'bind': bind()
    elif args.action == 'standard': full43()
    elif args.action.startswith('paired-'): full43(args.action[-1])
    elif args.action.startswith('heldout-'): heldout(args.action[-1])
    elif args.action.startswith('pressure-'): pressure(args.action.removeprefix('pressure-'))
    elif args.action.startswith('package-'): package(args.action.removeprefix('package-'))
    elif args.action.startswith('ingest-'): ingest(int(args.action[-1]))
    elif args.action == 'assess': assess()
    else: raise AssertionError(args.action)


if __name__ == '__main__':
    main()
