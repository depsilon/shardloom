"""Recompute preparation geometry from footer metadata and existing source policy."""
from pathlib import Path
import hashlib
import json
import pyarrow.parquet as pq

N = Path('/Users/dylan/LocalData/shardloom/native-prerequisites-20261022')
W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')


def identity(path):
    raw = Path(path).read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    protocol = json.loads((N / 'pgo-protocol-976.json').read_text())
    metadata = pq.read_metadata(protocol['ingest_source']['path'])
    groups = [{'rows': metadata.row_group(r).num_rows,
               'uncompressed_bytes': sum(metadata.row_group(r).column(c).total_uncompressed_size
                                         for c in range(metadata.num_columns))}
              for r in range(metadata.num_row_groups)]
    metadata_width = max((g['uncompressed_bytes'] + g['rows'] - 1) // g['rows'] for g in groups)
    estimated = max(metadata_width, metadata.num_columns * 8, 1) * 4
    observations = []
    for requested, admitted, expected_batch, expected_tasks, expected_batches in [
        (12, 10, 32768, 216, 3120), (2, 2, 262144, 78, 423)]:
        budget = (24 << 30) // 8 // admitted
        affordable = max(1, budget // estimated)
        batch = 262144 if affordable >= 262144 else 1 << (affordable.bit_length() - 1)
        target = max(batch, 65536) * 4
        tasks, start = [], 0
        while start < len(groups):
            end, rows = start, 0
            while end < len(groups):
                if end > start and (rows >= target or end - start >= 64):
                    break
                rows += max(groups[end]['rows'], 1)
                end += 1
                if rows >= target:
                    break
            tasks.append({'first_row_group': start, 'row_groups': end - start, 'rows': rows,
                          'batches': (rows + batch - 1) // batch})
            start = end
        total = sum(t['batches'] for t in tasks)
        assert (batch, len(tasks), total) == (expected_batch, expected_tasks, expected_batches)
        observations.append({'requested_parallelism': requested, 'admitted_parallelism': admitted,
            'memory_bytes': 24 << 30, 'source_batch_budget_bytes': budget, 'affordable_rows': affordable,
            'batch_rows': batch, 'source_tasks': len(tasks), 'source_batches': total,
            'observed_geometry_exact': True, 'tasks': tasks})
    report = {'schema': 'shardloom.pgo_ingest_admission_replay.v1', 'status': 'passed',
        'metadata_only': True, 'source': protocol['ingest_source'], 'row_groups': groups,
        'columns': metadata.num_columns, 'rows': metadata.num_rows,
        'max_metadata_bytes_per_row': metadata_width, 'estimated_bytes_per_row': estimated,
        'observations': observations, 'helper': identity(__file__),
        'source_policy': [identity(W / p) for p in (
            'shardloom-cli/src/sql_local_source_runtime.rs', 'shardloom-vortex/src/universal_format_io.rs')],
        'supersedes': identity(N / 'pgo-ingest-batch-admission-math-981.json'),
        'correction': 'Initial diagnostic counted every row group separately. Native readers group row groups into tasks before producing batches; the exact existing grouping rule reproduces both observed batch counts.',
        'conclusion': 'Different requested parallelism changes the existing per-batch memory admission and physical layout. The frozen requirement to match the historical file byte-for-byte used a reference prepared at different parallelism.',
        'performance_comparison': False, 'all_column_value_equivalence_claim': False}
    target = N / 'pgo-ingest-admission-replay-981.json'
    with target.open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'status': 'passed', 'report': identity(target),
                      'geometries': [{k: v for k, v in r.items() if k != 'tasks'} for r in observations]}))


if __name__ == '__main__':
    main()
