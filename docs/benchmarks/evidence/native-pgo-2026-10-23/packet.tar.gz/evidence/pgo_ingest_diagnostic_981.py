"""Check the control ingest's changed layout against the independent Full43 oracle.

This is failure attribution after the frozen ingest hash gate failed. It is not
a replacement PGO comparison, and cannot reopen the failed retention gate.
"""
from pathlib import Path
import gzip
import hashlib
import json
import math

import pgo_evaluate_977 as evaluation

experiment, p = evaluation.experiment, evaluation.p
N, W, ROOT = experiment.N, experiment.W, experiment.ROOT


def main():
    protocol = evaluation.check_binding()
    failed = p.read(ROOT / 'ingest-recovered-1/summary.json')
    assert failed['status'] == 'failed' and failed['error'] == 'AssertionError()'
    assert not any((ROOT / ('ingest-recovered-' + str(i))).exists() for i in (2, 3, 4))
    built = experiment.artifacts('control')
    target = ROOT / 'ingest-recovered-1/uat/vortex/prepared.vortex'
    identity = p.identity(target)
    assert identity['sha256'] == '05082be7bd2c515904822678b957281605e98abca1e4f3472c3b766dcc869510'
    assert identity['bytes'] == 15748946385
    assert identity != protocol['full43_input']
    name = 'control-ingest-correctness'
    with experiment.stage(name) as (steps, report, _):
        query_file = protocol['query_file']
        assert p.identity(query_file['path']) == query_file
        reference = evaluation.load_reference_packet(evaluation.REFERENCE, Path(query_file['path']))
        assert reference['packet']['reference_kind'] == 'independent_reference'
        root = steps.root / 'uat'
        command = [p.PYTHON, '-B', W / 'scripts/run_clickbench_query_uat.py',
            '--binary', built['cli']['path'], '--build-commit', protocol['source_commit'],
            '--compress-logs', '--input', target, '--uat-root', root,
            '--reference-packet', evaluation.REFERENCE, '--queries', query_file['path'],
            '--repeats', '1', '--memory-gb', '24', '--max-parallelism', '12',
            '--max-log-mib', '1024', '--max-run-log-mib', '256']
        report.update(input=identity, artifacts=built, query_file=query_file,
            reference=p.identity(evaluation.REFERENCE), driver=p.identity(__file__),
            failed_ingest=p.identity(ROOT / 'ingest-recovered-1/summary.json'),
            role='control', purpose='failure attribution: independent complete query values on changed control layout',
            performance_comparison=False, frozen_retention_gate_still_failed=True)
        print('Input identity confirmed; starting isolated control-layout correctness pass.', flush=True)
        evaluation.light_workflow(steps, name, command, identity)
        print('Queries finished; checking complete values and source identity.', flush=True)
        summaries = list(root.glob('logs/*/summary.json'))
        assert len(summaries) == 1
        path = summaries[0]
        summary = p.read(path)
        assert summary['completed_identity_check'] and summary['reference_packet_identity_verified']
        assert summary['reference_kind'] == 'independent_reference'
        assert summary['reference_packet']['sha256'] == report['reference']['sha256']
        assert summary['repeats'] == 1 and summary['selected_query_ids'] == list(range(1, 44))
        assert [r['query'] for r in summary['records']] == list(range(1, 44))
        observed = []
        for row in summary['records']:
            q = row['query']
            assert row['run'] == 1 and row['passed'] and row['returncode'] == 0
            assert row['validation'] == 'complete_values' and row['engine_timing_reported']
            assert row['guard_failures'] == [] and row['query_statement'] == reference['queries'][q - 1]
            prefix = f'q{q:02d}_run1'
            raw = gzip.decompress((path.parent / (prefix + '.stdout.json.gz')).read_bytes())
            timing = p.read(path.parent / (prefix + '.timing.json'))
            envelope = p.strict_json(raw.decode())
            fields = evaluation.no_fallback(envelope)
            values = p.extract_result(envelope)
            assert evaluation.equivalent(values, reference['values'][q])
            assert timing['returncode'] == 0
            phases = p.query_phase_timings(fields, timing['seconds'])
            assert phases['engine_execution_seconds'] == row['engine_execution_seconds']
            assert phases['process_wall_seconds'] == row['process_wall_seconds']
            observed.append({'query': q, 'engine_seconds': phases['engine_execution_seconds'],
                             'rows': len(values), 'raw_sha256': hashlib.sha256(raw).hexdigest()})
        assert sum(r['rows'] for r in observed) == 381
        assert experiment.artifacts('control') == built
        assert p.identity(target) == identity
        assert not (root / '.ingest-uat.lock').exists()
        report.update(summary=p.identity(path), observations=observed, complete_values=True,
            engine_seconds=math.fsum(r['engine_seconds'] for r in observed),
            queries=43, rows=381, uat_lock_released=True,
            dataset_equivalence_scope='All 381 results of the independent 43-query oracle; not an all-column row-by-row equivalence proof.')
        print(json.dumps({'status': 'passed', 'queries': 43, 'rows': 381,
                          'engine_seconds': report['engine_seconds'], 'performance_comparison': False}), flush=True)


if __name__ == '__main__':
    main()
