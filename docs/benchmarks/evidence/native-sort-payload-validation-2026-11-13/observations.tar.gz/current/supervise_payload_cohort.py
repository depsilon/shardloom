"""Bound the fixed Sort payload correctness cohort without heavy scans during execution."""
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

from payload_runtime import OUT, ROOT, identity, verify

sys.path[:0] = [str(ROOT / 'scripts'), '/Users/dylan/LocalData/shardloom/release-0.3.3-20260930']
from release_validation_guard import WorkloadGuard
from local_uat_storage import GIB, MIB, accounted_bytes, available_bytes, check_budgets, require_local_path

helper = OUT.parent / 'perf-all-20260906/bounded_build_process_resume_20260912.py'
assert identity(helper)['sha256'] == '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97'
spec = importlib.util.spec_from_file_location('bounded_supervisor', helper)
supervisor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(supervisor)

target = OUT / 'payload-cohort-r1'
receipt = OUT / 'payload-cohort-supervision-r1.json'
log = OUT / 'payload-cohort-supervision-r1.log'
assert not any(path.exists() for path in (target, receipt, log))
require_local_path(OUT, Path.home(), sys.platform)
initial = check_budgets(OUT, OUT / 'reserved-output', OUT / 'logs',
    min_free_bytes=12*GIB, reserve_bytes=128*MIB,
    max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
active_budget = 100*GIB-initial['workspace_bytes']
workload = WorkloadGuard()
workload.check()
runtime = verify()
command = ['/Users/dylan/.cache/shardloom/query-surface-polars-2.1.0/bin/python',
           '-B', str(OUT / 'run_payload_cohort.py')]
record = dict(status='prepared', command=command, runtime_binding=runtime,
    source_inventory_policy='before_and_after_only', evidence_inventory_policy='before_and_after_only',
    active_output=str(target), storage_preflight=initial,
    active_output_workspace_budget_bytes=active_budget,
    helper=dict(path=str(helper), **identity(helper)),
    drivers={str(path):identity(path) for path in (Path(__file__), OUT/'run_payload_cohort.py', OUT/'payload_runtime.py')})
last_storage = 0.0


def guard():
    global last_storage
    workload.check(record.get('pid'))
    assert available_bytes(OUT) >= 12*GIB, 'minimum free storage reached'
    if time.monotonic()-last_storage >= 30:
        record['storage_last_observation'] = check_budgets(target, target/'reserved-output', target/'logs',
            min_free_bytes=12*GIB, reserve_bytes=128*MIB,
            max_workspace_bytes=active_budget, max_log_bytes=192*MIB)
        last_storage = time.monotonic()


env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', POLARS_MAX_THREADS='2',
    PATH='/opt/homebrew/opt/python@3.13/libexec/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin')
env.pop('PYTHONPATH', None)
try:
    with log.open('xb') as stream:
        code = supervisor.run(command, cwd=ROOT, env=env, output=stream,
            timeout=3600, evidence=record, guard=guard, max_output_bytes=8<<20)
    record['status'] = 'passed_capture' if code == 0 else 'failed'
    record['runtime_and_source_unchanged'] = verify() == runtime
    assert record['runtime_and_source_unchanged']
    for name, expected in record['drivers'].items(): assert identity(Path(name)) == expected
    if code == 0:
        done = json.loads((target/'complete.json').read_bytes())
        assert done['status'] == 'complete_observation' and done['total'] == done['attempt_slots'] == 388
        assert done['attempts_per_case'] == 1 and done['requested_repeats'] == 0 and done['posthash_verified']
        record['complete'] = dict(path=str(target/'complete.json'), **identity(target/'complete.json'))
        record['outcomes'] = done['outcomes']
        record['performance_admission'] = 'pending independent offline result and clock replay'
except BaseException as error:
    record.update(status='failed', error=type(error).__name__+': '+str(error))
    raise
finally:
    if log.exists(): record['log_identity'] = identity(log)
    receipt.write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps({k:record.get(k) for k in ('status','returncode','outcomes','error')}),flush=True)
raise SystemExit(code)

