"""Compare saved certificate work per fixed Sort case, without query execution."""
from collections import Counter, defaultdict
import gzip
import hashlib
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
DEST = OUT/'payload-work-review-r1.json'


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def rows(path):
    with gzip.open(path, 'rt') as stream:
        return [json.loads(line) for line in stream]


def counters(fields):
    pairs = re.findall(r'(?:^|[ ;])([a-z][a-z0-9_]*)=([0-9]+)(?=$|[ ;])',
        fields['local_primitive_native_io_pushdown_proof_basis'])
    assert len(pairs) == len(dict(pairs))
    result = {'proof.'+key:int(value) for key,value in pairs}
    result.update({'report.'+key:int(value) for key,value in fields.items()
                   if re.fullmatch(r'[0-9]+',str(value))})
    return result


def main():
    assert __debug__ and not DEST.exists()
    folder = OUT/'payload-cohort-r1'
    summary = json.loads((folder/'verified-summary-r1.json').read_bytes())
    assert summary['status'] == 'passed_offline_replay' and summary['successful_cases'] == 388
    assert summary['unsuccessful_cases'] == 0
    baseline = {row['id']:row for row in rows(OUT/'coverage-inventory-r1/observed-query-evidence.jsonl.gz')}
    controls = {row['id']:row for row in rows(OUT/'sort-cohort-r1/certificate-cases-r1.jsonl.gz')}
    current = rows(folder/'verified-cases-r1.jsonl.gz')
    certificates = rows(folder/'certificate-cases-r1.jsonl.gz')
    groups, changes, details = defaultdict(Counter), Counter(), []
    for seq, (case, certificate) in enumerate(zip(current, certificates)):
        group = case['comparison_group']
        old = (controls if group=='owned_source_control' else baseline)[case['id']]
        assert case['seq'] == certificate['seq'] == seq and case['id'] == certificate['id']
        assert case['current']['status'] == certificate['status'] == 'passed'
        assert old['engine_seconds'] == case['previous_engine_seconds']
        assert certificate['engine_seconds'] == case['current']['engine_seconds']
        left, right = counters(old['fields']), counters(certificate['fields'])
        changed = {key:[left.get(key),right.get(key)] for key in sorted(left.keys()|right.keys())
                   if left.get(key)!=right.get(key)}
        changes.update(changed.keys())
        metrics = {}
        for key in ('native_pipeline_operator_invocations','native_pipeline_file_kernel_invocations'):
            name = 'proof.'+key
            metrics[key] = dict(before=left[name],after=right[name],delta=right[name]-left[name])
        resources = {}
        for key in ('execution_resource_observed_native_peak_reserved_bytes',
                    'execution_resource_observed_native_reserved_bytes'):
            name = 'report.'+key
            resources[key] = dict(before=left[name],after=right[name],delta=right[name]-left[name])
        old_sort = 'local_primitive_sort_provider_background_workers' in old['fields']
        new_sort = 'local_primitive_sort_provider_background_workers' in certificate['fields']
        groups[group]['cases'] += 1
        groups[group]['reported_file_sort_removed'] += int(old_sort and not new_sort)
        groups[group]['reported_file_sort_added'] += int(new_sort and not old_sort)
        groups[group]['reported_file_sort_retained'] += int(old_sort and new_sort)
        groups[group]['cases_with_more_file_kernels'] += int(metrics['native_pipeline_file_kernel_invocations']['delta']>0)
        groups[group]['cases_with_fewer_file_kernels'] += int(metrics['native_pipeline_file_kernel_invocations']['delta']<0)
        groups[group]['peak_reserved_increased'] += int(resources['execution_resource_observed_native_peak_reserved_bytes']['delta']>0)
        groups[group]['retained_reserved_increased'] += int(resources['execution_resource_observed_native_reserved_bytes']['delta']>0)
        groups[group]['higher_engine_time'] += int(certificate['engine_seconds']>old['engine_seconds'])
        details.append(dict(seq=seq,id=case['id'],group=group,surface=case['surface'],native_format=case['native_format'],
            baseline_source_commit=case['previous_source_commit'],before_stdout_sha256=old['raw_stdout_sha256'],
            after_stdout_sha256=certificate['raw_stdout_sha256'],before_engine_seconds=old['engine_seconds'],
            after_engine_seconds=certificate['engine_seconds'],reported_file_sort=dict(before=old_sort,after=new_sort),
            pipeline=metrics,resources=resources,counter_changes=changed))
    assert len(current) == len(certificates) == len(details) == 388
    result = dict(status='passed_saved_work_review',query_executions=0,source_commit=summary['source_commit'],
        cases=388,groups={name:dict(values) for name,values in groups.items()},
        changed_counter_occurrences=dict(changes),details=details,
        maximum_peak_reservation_increase=max(row['resources']['execution_resource_observed_native_peak_reserved_bytes']['delta'] for row in details),
        maximum_retained_reservation_increase=max(row['resources']['execution_resource_observed_native_reserved_bytes']['delta'] for row in details),
        source_identities=[identity(path) for path in (
            folder/'verified-summary-r1.json', folder/'verified-cases-r1.jsonl.gz',folder/'certificate-cases-r1.jsonl.gz',
            OUT/'coverage-inventory-r1/observed-query-evidence.jsonl.gz', OUT/'sort-cohort-r1/certificate-cases-r1.jsonl.gz',Path(__file__))],
        limitation='Reported file-sort presence is not a complete per-node decision trace. Every numeric certificate '
            'counter difference is retained, including absent scopes. Distinct historical sources are preserved; '
            'there is no causal or speedup claim and no generic Vortex physical-column counter.')
    with DEST.open('x') as stream:
        json.dump(result,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({key:result[key] for key in ('status','cases','groups','maximum_peak_reservation_increase')},indent=2))


if __name__ == '__main__':
    main()
