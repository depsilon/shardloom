# Sort payload validation admission: prospective observation

The typed Sort validates every declared payload in its complete observed
population, including hidden fields and rows outside the returned range. The
file SortRows shortcut can omit that validation. F64 NaN and column-addressable
malformed UTF8 regressions establish a correctness defect. Admission must use
the original bound Sort schema and retain the shared native Sort when the
shortcut cannot preserve its value-validation domain. Integer, boolean/null
payload and fully decoded text keys retain their eligible file kernel. A direct
projection before Sort keeps its existing narrower validation domain.

This correction is mandatory correctness work, not a proposed speedup. Do not
accept skipped errors as a performance improvement. It introduces no provider,
external evaluator, second admission-time scan, implicit spill, or grant increase.
Retain original failures, all observations, unchanged resource policy and the
complete independent answer oracle.

Before any candidate performance query, independently freeze all original
Vortex declarations with a Sort whose input reaches Scan through only unary
Project/Filter. This conservative superset has 378 queries, spanning all five
interfaces. Saved reports identify 21 file sorts, 36 other file-kernel reports
and 321 queries without a file kernel; these are report scopes, not full
per-opportunity admission proof. Add ten controls: the first original-order
Parquet and IPC Sort case per interface from the prior frozen Sort cohort.
No selection depends on measured candidate performance.

Execute all 388 declarations exactly once, through the unchanged public worker,
with the original inputs, two threads and 2 GiB native grant. Use a fresh output
directory and the established storage, overlap, deadline, validation and cleanup
guards. Keep all other task-owned work idle during execution. Full inventories
belong before and after query execution. Do not rerun any baseline, warm up,
alter caches, raise grants, substitute a faster query, or conceal a failed case.

Use the original complete 9f Vortex observations and the later cac86 Sort
observations for owned-source controls, retaining their exact attribution.
Report those groups separately; no combined historical engine total and no
single-change causal or repeatability claim. Current candidate timing is engine
execution only. Review all source/kernel, work, memory, spill and per-case
changes, including slowdowns. Full answer and schema replay is mandatory.
These observations cannot establish whole-engine optimization coverage.
