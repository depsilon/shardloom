"""Conservative frozen-declaration inventory for native Vortex Sort payload exposure."""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import re
import sys

import verify_sort_exposure as frozen
from query_surface.semantics import schema_record

OUT = Path(__file__).resolve().parent
E = frozen.E
DESIGN = E / 'design.json'
OBSERVED = OUT / 'coverage-inventory-r1/observed-query-evidence.jsonl.gz'
COHORT = OUT / 'sort-demand-cohort-r1.json'
OUTPUT = OUT / 'payload-sort-exposure-r1.json'
TARGET_FIELD = 'local_primitive_sort_provider_background_workers'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def native_sort_sources(node):
    """Accept scan under unary project/filter only; return sources and traversed path."""
    path, cursor = [], node
    while cursor.op in {'project', 'filter'} and len(cursor.inputs) == 1:
        path.append(cursor.op)
        cursor = cursor.inputs[0]
    if cursor.op != 'scan':
        return None
    path.append('scan')
    return [cursor.args[0]], path


def main():
    assert not OUTPUT.exists()
    design = json.loads(DESIGN.read_bytes())
    legacy = {case.id: case for case in frozen.corpus(interactions='all', include_pending=False)}
    spaces = {space.name: space for space in frozen.spaces()}
    candidate_rows, controls = [], []
    verified = 0
    with gzip.open(OBSERVED, 'rt') as records:
        for descriptor, line in zip(design['cases'], records, strict=True):
            saved = json.loads(line)
            case = frozen.build(descriptor, spaces) if 'cell' in descriptor else legacy[descriptor['id']]
            assert saved['id'] == case.id == descriptor['id']
            assert saved['case_identity'] == case.identity == descriptor['case_identity']
            verified += 1
            if descriptor['native_format'] != 'vortex':
                continue
            for path, node in _walk(case.relation):
                if node.op != 'sort':
                    continue
                eligible = native_sort_sources(node.inputs[0]) if len(node.inputs) == 1 else None
                if eligible is None:
                    continue
                source_names, unary_path = eligible
                proof = saved['fields'].get('local_primitive_native_io_pushdown_proof_basis', '')
                counters = dict(re.findall(r'(?:^|[ ;])([a-z][a-z0-9_]*)=([0-9]+)(?=$|[ ;])', proof))
                try:
                    invocation_count = int(counters.get('native_pipeline_file_kernel_invocations', '0'))
                except ValueError as exc:
                    raise AssertionError('malformed file-kernel invocation counter') from exc
                schema = schema_record(node.schema)
                candidate_rows.append(dict(id=case.id, case_identity=case.identity,
                    descriptor=dict(descriptor), public_surface=descriptor['surface'],
                    native_format=descriptor['native_format'], family=descriptor['family'],
                    sort_node_path=list(path), ancestor_path=[dict(path=list(path[:i]), op=op)
                        for i, op in enumerate(_ops_at_path(case.relation, path))],
                    sort_fields=schema,
                    key_names=[dict(column=key.column, descending=key.descending, nulls=key.nulls)
                               for key in node.args], source_names=source_names,
                    sort_input_unary_path=unary_path,
                    baseline_raw_stdout_sha256=saved['raw_stdout_sha256'],
                    file_kernel_invocation_count=invocation_count,
                    has_background_worker_field=TARGET_FIELD in saved['fields']))
    assert verified == 10000

    cohort = json.loads(COHORT.read_bytes())
    chosen = set()
    controls_by_surface = Counter()
    for row in cohort['cases']:
        declaration = row['declaration']
        fmt = declaration['native_format']
        surface = declaration['surface']
        if fmt not in {'parquet', 'arrow-ipc'}:
            continue
        key = (surface, fmt)
        if key in chosen or declaration['id'] in {c['id'] for c in controls}:
            continue
        chosen.add(key)
        controls_by_surface[surface] += 1
        controls.append(dict(id=declaration['id'], case_identity=declaration['case_identity'],
            descriptor=dict(declaration), public_surface=surface, native_format=fmt,
            role='first-in-original-sort-cohort-for-surface-and-format-control'))
    expected = {(surface, fmt) for surface in sorted({r['declaration']['surface'] for r in cohort['cases']})
        for fmt in ('parquet', 'arrow-ipc') if any(r['declaration']['surface'] == surface and
            r['declaration']['native_format'] == fmt for r in cohort['cases'])}
    assert chosen == expected
    summary = dict(declarations_verified=verified, candidate_case_count=len({r['id'] for r in candidate_rows}),
        sort_node_count=len(candidate_rows), controls_count=len(controls), query_executions=0,
        candidates_by_family=dict(Counter(r['family'] for r in candidate_rows)),
        candidates_by_surface=dict(Counter(r['public_surface'] for r in candidate_rows)),
        candidates_by_format=dict(Counter(r['native_format'] for r in candidate_rows)),
        controls_by_surface_and_format={f'{s}:{f}':1 for s,f in sorted(chosen)})
    source_files = [Path(__file__), Path(frozen.__file__), DESIGN, OBSERVED, COHORT,
                    Path(__import__('query_surface.semantics', fromlist=['schema_record']).__file__),
                    E / 'investigation-original-harness-r1/benchmarks/traditional_analytics/query_surface/specification.py']
    result = dict(status='conservative_frozen_declaration_shape_superset_not_affected_runtime_proof',
        query_executions=0, summary=summary,
        candidate_scope='Vortex declarations with any Sort whose input reaches Scan through zero or more unary project/filter nodes; does not infer exact compiled admission, range, expression support, or runtime activation.',
        sort_candidates=candidate_rows, control_cases=controls,
        source_file_sha256={str(path):digest(path) for path in sorted(set(source_files))},
        runtime_import_assertion=dict(native_loaded=any(n == 'shardloom._native' or n.startswith('shardloom._native.') for n in sys.modules),
            polars_runtime_loaded=any(n == '_polars_runtime' or n.startswith('_polars_runtime.') for n in sys.modules), asserted_absent=True))
    assert not result['runtime_import_assertion']['native_loaded'] and not result['runtime_import_assertion']['polars_runtime_loaded']
    OUTPUT.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(summary, sort_keys=True))


def _walk(node, path=()):
    yield path, node
    for index, child in enumerate(node.inputs):
        yield from _walk(child, path + (index,))


def _ops_at_path(root, path):
    cursor, result = root, []
    for index in path:
        cursor = cursor.inputs[index]
        result.append(cursor.op)
    return result


if __name__ == '__main__':
    main()
