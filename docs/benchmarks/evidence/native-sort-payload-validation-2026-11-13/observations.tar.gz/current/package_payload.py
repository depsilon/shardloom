"""Package the payload correctness-correction cohort; runs no queries."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
DEST = OUT/'compact-payload-r1'
ORIGINAL = OUT.parent/'expanded-query-2026-11-03'
PATCH_BASE = '9040cf80c8ba23c5d1c3cf0a440ed59e3441b1e9'
RUST_FILES = (
    'shardloom-vortex/src/local_primitive_relational_provider.rs',
    'shardloom-vortex/src/local_primitive_relational_provider_plan.rs',
    'shardloom-vortex/src/local_primitive_relational_provider_tests.rs',
    'shardloom-vortex/src/local_primitive_relational_tests.rs',
    'shardloom-vortex/src/local_primitive_relational_provider_payload_tests.rs',
)
sys.path.insert(0, str(ROOT/'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def identity(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    assert __debug__ and not DEST.exists()
    require_local_path(DEST, Path.home(), sys.platform)
    check_budgets(OUT, DEST, OUT/'logs', min_free_bytes=12*GIB,
        reserve_bytes=128*MIB, max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)

    summary_path = OUT/'payload-cohort-r1/verified-summary-r1.json'
    summary = json.loads(summary_path.read_bytes())
    assert summary['status'] == 'passed_offline_replay'
    assert summary['attempted_cases'] == summary['successful_cases'] == 388
    assert summary['unsuccessful_cases'] == 0
    assert summary['outcomes'] == {'passed': 388}
    assert summary['independent_complete_results_replayed'] is True
    source_commit = summary['source_commit']

    members = {}

    def add(path, name):
        if not path.is_file() or path.is_symlink() or name in members:
            raise ValueError(f'unsafe, missing or duplicate packet member: {path} -> {name}')
        members[name] = (path.read_bytes(), str(path))

    def add_glob(pattern):
        for path in sorted(OUT.glob(pattern)):
            add(path, 'current/'+path.relative_to(OUT).as_posix())

    # Preserve all top-level payload receipts/notes, including failures and stopped runs.
    add_glob('payload-*.json')
    add_glob('payload-*.md')
    add_glob('payload-*.log')
    # Preserve the complete top-level payload helper family, including this packager
    # and the future source-bound payload verifier.
    for path in sorted(OUT.glob('*payload*.py')):
        add(path, 'current/'+path.relative_to(OUT).as_posix())
    for path in sorted(OUT.glob('vortex-sort-*.json')):
        add(path, 'current/'+path.relative_to(OUT).as_posix())
    for pattern in ('payload-*.log', 'vortex-sort-*.log'):
        for path in sorted((OUT/'logs').glob(pattern)):
            add(path, 'current/'+path.relative_to(OUT).as_posix())
    add(OUT/'pipeline_runtime.py', 'current/pipeline_runtime.py')
    add(OUT/'guard_checks.py', 'current/guard_checks.py')
    add(OUT/'sort_capture.py', 'current/sort_capture.py')
    add(OUT/'coverage-inventory-r1/observed-query-evidence.jsonl.gz',
        'current/coverage-inventory-r1/observed-query-evidence.jsonl.gz')

    cohort = OUT/'payload-cohort-r1'
    for path in sorted(cohort.iterdir()):
        if path.is_file() and (path.suffix == '.json' or path.name in {
            'verified-cases-r1.jsonl.gz', 'certificate-cases-r1.jsonl.gz'
        }):
            add(path, 'current/'+path.relative_to(OUT).as_posix())

    installed = OUT/'payload-installed-wheel-r1'
    for path in sorted(installed.iterdir()):
        if path.is_file() and path.suffix in {'.json', '.log', '.txt'}:
            add(path, 'current/'+path.relative_to(OUT).as_posix())

    for name in ('design.json', 'inputs.json', 'frozen.json'):
        add(ORIGINAL/name, 'original/'+name)

    for name in ('verified-summary-r1.json', 'verified-cases-r1.jsonl.gz',
                 'certificate-export-r1.json', 'certificate-cases-r1.jsonl.gz'):
        add(OUT/'full10k-r1'/name, 'baseline/original-10k/'+name)
    for name in ('verified-summary-r1.json', 'verified-cases-r1.jsonl.gz',
                 'certificate-cases-r1.jsonl.gz'):
        add(OUT/'sort-cohort-r1'/name, 'baseline/sort-demand/'+name)
    optional_sort_export = OUT/'sort-cohort-r1/certificate-export-r1.json'
    if optional_sort_export.is_file():
        add(optional_sort_export, 'baseline/sort-demand/certificate-export-r1.json')

    patch = subprocess.check_output(
        ['git', 'diff', '--binary', PATCH_BASE, source_commit], cwd=ROOT
    )
    members['source/payload.patch'] = (patch, f'git diff --binary {PATCH_BASE} {source_commit}')
    for path in RUST_FILES:
        raw = subprocess.check_output(['git', 'show', f'{source_commit}:{path}'], cwd=ROOT)
        members['source/files/'+path] = (raw, f'git show {source_commit}:{path}')

    # These two exact maintenance helpers preserve the same packaging supervision used by
    # the related connection packet; no runtime/environment trees are collected.
    add(OUT.parent/'native-pipeline-sql-minute-2026-11-13/guard_checks.py',
        'helpers/check-supervisor.py')
    add(OUT.parent/'perf-all-20260906/bounded_build_process_resume_20260912.py',
        'helpers/bounded-supervisor.py')

    DEST.mkdir()
    shutil.copyfile(OUT/'payload-verify.py', DEST/'verify.py')
    (DEST/'README.md').write_text('''# Payload correctness-correction evidence

This packet records the payload validation correction and its complete 388-case
cohort. The payload cohort, full10k baseline, and sort-demand baseline are distinct
observations with distinct source commits; their results and timings are never
combined. The original design, frozen inputs and all retained failed/stopped
payload observations are preserved alongside the accepted evidence.

The complete payload answers were independently replayed locally against their
reference results. The portable packet preserves the case and certificate data,
but its verifier does not rerun the full oracle. This is a correctness correction,
not a speedup claim and not a whole-engine coverage claim.

Run `python3 -B verify.py` from this directory. The verifier checks the archived
bytes and source-bound cohort evidence without running queries.
''')

    archive_path = DEST/'observations.tar.gz'
    with archive_path.open('xb') as stream:
        with gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for name, (raw, _) in sorted(members.items()):
                    entry = tarfile.TarInfo(name)
                    entry.size, entry.mode, entry.mtime = len(raw), 0o644, 0
                    entry.uid = entry.gid = 0
                    entry.uname = entry.gname = ''
                    archive.addfile(entry, io.BytesIO(raw))
    with tarfile.open(archive_path, 'r:gz') as archive:
        assert set(archive.getnames()) == set(members)
        for item in archive.getmembers():
            assert archive.extractfile(item).read() == members[item.name][0]

    manifest = dict(
        schema='shardloom.sort_payload_validation_evidence.v1',
        source_commit=source_commit,
        query_executions_during_packaging=0,
        published=False,
        cohort_summary=identity(summary_path.read_bytes()),
        files={path.name: identity(path.read_bytes()) for path in sorted(DEST.iterdir())},
        archive_members={name: dict(**identity(raw), origin=origin)
                         for name, (raw, origin) in sorted(members.items())},
    )
    with (DEST/'manifest.json').open('x') as stream:
        json.dump(manifest, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status='packaged_readback_verified', archive_members=len(members),
        archive_bytes=archive_path.stat().st_size, source_commit=source_commit,
        successful_cases=summary['successful_cases'], unsuccessful_cases=summary['unsuccessful_cases'])))


if __name__ == '__main__':
    main()
