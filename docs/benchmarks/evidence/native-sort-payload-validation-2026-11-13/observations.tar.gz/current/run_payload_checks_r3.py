"""Run final complete checks after preserving text-key alias equivalence."""
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
CHECKS = [
    ('payload-fmt-r3', 2400, ['cargo', 'fmt', '--all', '--', '--check']),
    ('payload-default-clippy-r3', 2400,
     ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('payload-native-clippy-r3', 2400,
     ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets',
      '--features', 'python-native,native-encoded-exchange-experiment', '--', '-D', 'warnings']),
    ('payload-default-tests-r2', 7200,
     ['cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets']),
    ('payload-native-tests-r2', 7200,
     ['cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets',
      '--features', 'python-native,native-encoded-exchange-experiment']),
]

if __name__ == '__main__':
    for name, timeout, command in CHECKS:
        print(name, flush=True)
        subprocess.run([sys.executable, '-B', str(OUT / 'guard_checks.py'), '--name', name,
                        '--timeout', str(timeout), '--', *command], check=True)
