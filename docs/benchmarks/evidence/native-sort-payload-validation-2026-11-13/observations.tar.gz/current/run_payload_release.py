"""Build and prove the committed payload-demand runtime, without queries."""
import json
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
PYTHON = '/Users/dylan/LocalData/shardloom/native-pipeline-sql-minute-2026-11-13/wheel-tools-r1/venv/bin/python'


def guarded(name, timeout, command):
    print(name, flush=True)
    subprocess.run([sys.executable, '-B', str(OUT/'guard_checks.py'),
                    '--name', name, '--timeout', str(timeout), '--', *command], check=True)


def main():
    assert __debug__ and not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
    for name in ('fmt-r3', 'default-clippy-r3', 'native-clippy-r3',
                 'default-tests-r2', 'native-tests-r2'):
        receipt = json.loads((OUT/('payload-'+name+'.json')).read_bytes())
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['sources_unchanged'] and receipt['process_group_drained']
    guarded('payload-release-build-r1', 2400, [
        'cargo', 'build', '--offline', '--locked', '--release',
        '--features', 'release-user-surfaces', '-p', 'shardloom-cli', '-p', 'shardloom-python'])
    guarded('payload-runtime-freeze-r1', 2400,
            [sys.executable, '-B', str(OUT/'freeze_payload_runtime.py')])
    guarded('payload-installed-wheel-r1', 7200, [
        PYTHON, 'scripts/prove_native_python_wheel.py', '--repo-root', str(ROOT),
        '--output-dir', str(OUT/'payload-installed-wheel-r1'),
        '--native-library', str(OUT/'payload-runtime-r1/lib_native.dylib'),
        '--cli-binary', str(OUT/'payload-runtime-r1/shardloom'),
        '--wheelhouse', '/Users/dylan/LocalData/shardloom/native-pipeline-consolidation-2026-11-12/wheel-tools-r1/wheelhouse'])
    subprocess.run([sys.executable, '-B', str(OUT/'validate_payload_runtime.py')], check=True)


if __name__ == '__main__':
    main()
