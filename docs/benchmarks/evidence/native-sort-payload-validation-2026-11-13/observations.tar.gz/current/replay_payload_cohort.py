"""Independently replay every fixed Sort result, clock and work observation."""
from collections import Counter, defaultdict
from contextlib import ExitStack
import gzip
import hashlib
import json
import math
from pathlib import Path
import re

import run_payload_cohort as current
from query_timing_report import query_phase_timings
from query_surface.corpus import corpus
from query_surface.evidence import identity
from query_surface.expanded_catalog import build, spaces
from query_surface.expanded_freeze import read, unpack
from query_surface.expanded_report import raw_files, replay
from query_surface.expanded_run import closing_db, verify


def main():
    assert __debug__
    target = current.TARGET
    destination = target / 'verified-summary-r1.json'
    cases_path = target / 'verified-cases-r1.jsonl.gz'
    partial = target / 'verified-cases-r1.partial.jsonl.gz'
    certificates = target / 'certificate-cases-r1.jsonl.gz'
    assert not any(path.exists() for path in (destination, cases_path, partial, certificates))
    design, inputs, frozen, admitted = current.updated_admission(current.E)
    selection, descriptors = current.cohort(design)
    selected = {row['declaration']['id']:row for row in selection['cases']}
    done, binding = read(target/'complete.json'), read(target/'binding.json')
    assert done['status'] == 'complete_observation' and done['stage'] == 'native'
    assert done['total'] == done['attempt_slots'] == 388
    assert done['attempts_per_case'] == 1 and done['requested_repeats'] == 0 and done['posthash_verified']
    assert done['updated'] == admitted
    assert binding['contract'] == {key:done[key] for key in ('frozen','stage','prerequisites','updated')}
    verify([done['ledger'], done['binding'], done['frozen']])
    prepared = read(current.E/'native-preparation/complete.json')
    originals = {item.id:item for item in corpus(interactions='all', include_pending=False)}
    definitions = {spec.name:spec for spec in spaces()}
    seen, engine, failures = [], [], []
    outcomes, groups, counts = Counter(), defaultdict(list), Counter()
    with (target/'.payload-offline-replay.lock').open('x'):
        pass
    with ExitStack() as stack:
        store = stack.enter_context(closing_db(target/'attempts.sqlite', readonly=True))
        entries = iter(store.execute('SELECT seq,id,status,packet FROM attempt ORDER BY seq'))
        references = {profile:stack.enter_context(closing_db(
            current.E/('reference-'+profile)/'expectations.sqlite', readonly=True))
            for profile in {row['profile'] for row in descriptors}}
        output = stack.enter_context(gzip.open(partial,'wt',encoding='utf-8'))
        certificate_output = stack.enter_context(gzip.open(certificates,'wt',encoding='utf-8'))
        for ordinal, row in enumerate(descriptors):
            item = build(row,definitions) if 'cell' in row else originals[row['id']]
            expected_identity, expected_blob = references[row['profile']].execute(
                'SELECT identity,value FROM expected WHERE id=?',(item.id,)).fetchone()
            assert expected_identity == item.identity == row['case_identity']
            entry = next(entries,None)
            assert entry is not None and entry[:2] == (ordinal,item.id)
            record = replay(entry,row,'native',unpack(expected_blob),item,inputs,prepared,design['execution'])
            before = selected[item.id]
            outcomes[record['status']] += 1
            seen.append(item.id)
            work, pipeline, resource = {}, {}, {}
            if record['status'] == 'passed':
                raw = raw_files(unpack(entry[3]))['one.stdout.json']
                observation = json.loads(raw)['observation']
                clocks = query_phase_timings(observation['fields'], observation['clocks']['complete_workflow_seconds'])
                seconds = clocks['engine_execution_seconds']
                assert type(seconds) in (int,float) and math.isfinite(seconds) and seconds >= 0
                assert seconds == record['engine_seconds'] == observation['clocks']['engine_execution_seconds']
                assert observation['clocks']['engine_timing_reported'] is True
                assert clocks['result_serialization_seconds'] == observation['clocks']['result_serialization_seconds']
                fields = observation['fields']
                assert fields['relational_provider_selection_reason'] == 'native_operator_pipeline'
                proof = fields['local_primitive_native_io_pushdown_proof_basis']
                assert 'native_execution_pipeline=native_operator_pipeline' in proof
                assert 'native_pipeline_catch_all_execution=false' in proof
                assert fields['fallback_attempted'] == fields['external_engine_invoked'] == 'false'
                counters = {}
                for key in ('native_pipeline_operator_invocations', 'native_pipeline_file_kernel_invocations'):
                    values = re.findall(r'\b'+re.escape(key)+r'=(\d+)\b',proof)
                    assert len(values) == 1
                    counters[key] = int(values[0])
                assert 0 <= counters['native_pipeline_file_kernel_invocations'] <= counters['native_pipeline_operator_invocations']
                assert counters['native_pipeline_operator_invocations'] > 0
                pipeline = dict(common_pipeline=True, catch_all=False, external_fallback=False,
                    reported_file_sort='local_primitive_sort_provider_background_workers' in fields, **counters)
                counts['common_native_pipeline_cases'] += 1
                counts['reported_file_sort_cases'] += int(pipeline['reported_file_sort'])
                counts['cases_with_file_kernel'] += int(counters['native_pipeline_file_kernel_invocations']>0)
                engine.append(seconds)
                if before['comparison_group'] == 'owned_source_control':
                    prior = int(before['baseline_work']['native_source_demand_projected_columns'])
                    after = int(fields['native_source_demand_projected_columns'])
                    assert fields['native_source_demand_prepared_input_bytes_written'] == '0'
                    assert prior == after
                    work = dict(scope='owned_demanded_source_columns', before_columns=prior,
                                after_columns=after, unchanged=True)
                    counts['unchanged_control_column_counts'] += 1
                else:
                    assert row['native_format'] == 'vortex'
                    work = dict(scope='native_vortex_no_comparable_per_source_column_counter')
                for key in ('execution_resource_observed_native_peak_reserved_bytes',
                            'execution_resource_observed_native_reserved_bytes',
                            'execution_resource_observed_native_denied_reservations',
                            'execution_resource_observed_spill_bytes'):
                    resource[key] = int(fields[key])
                assert fields['execution_resource_observed_spill_io_performed'] == 'false'
                assert resource['execution_resource_observed_native_denied_reservations'] == 0
                assert resource['execution_resource_observed_spill_bytes'] == 0
                groups[before['comparison_group']].append(dict(id=item.id,
                    before_engine_seconds=before['baseline_engine_seconds'], after_engine_seconds=seconds,
                    baseline_source_commit=before['baseline_source_commit'], resource=resource,
                    reported_file_sort=pipeline['reported_file_sort'], **counters))
                raw_bytes = raw.encode() if isinstance(raw,str) else raw
                certificate_output.write(json.dumps(dict(seq=ordinal,id=item.id,status='passed',
                    raw_stdout_sha256=hashlib.sha256(raw_bytes).hexdigest(), engine_seconds=seconds,
                    engine_timing_reported=True, fields=fields),separators=(',',':'),allow_nan=False)+'\n')
            else:
                failures.append(dict(id=item.id, status=record['status'], detail=record.get('failure_detail')))
            output.write(json.dumps(dict(seq=ordinal,id=item.id,case_identity=item.identity,
                original_ordinal=before['original_ordinal'], family=row['family'],profile=row['profile'],
                surface=row['surface'], native_format=row['native_format'],
                comparison_group=before['comparison_group'],current=record,
                previous_engine_seconds=before['baseline_engine_seconds'],
                previous_source_commit=before['baseline_source_commit'],
                previous_ledger=before['baseline_ledger'],previous_work=before['baseline_work'],
                source_work=work,pipeline_evidence=pipeline,resources=resource),
                separators=(',',':'),allow_nan=False)+'\n')
        assert next(entries,None) is None
    assert seen == [row['id'] for row in descriptors] and len(set(seen)) == 388
    assert dict(outcomes) == done['outcomes']
    verify(frozen)
    assert identity(target/'attempts.sqlite') == done['ledger']
    partial.rename(cases_path)
    result = dict(status='passed_offline_replay' if not failures else 'failed_complete_results', query_executions=0,
        source_commit=admitted['head'], source_tree=admitted['source_tree'],
        attempted_cases=388,successful_cases=len(engine),unsuccessful_cases=len(failures),outcomes=dict(outcomes),
        primary_clock='engine_execution_seconds',successful_engine_seconds=math.fsum(engine),
        complete_candidate_engine_seconds=math.fsum(engine) if not failures else None,
        counts=dict(counts),groups={name:dict(cases=len(rows),
            baseline_engine_seconds=math.fsum(row['before_engine_seconds'] for row in rows),
            candidate_engine_seconds=math.fsum(row['after_engine_seconds'] for row in rows),
            baseline_source_commits=sorted({row['baseline_source_commit'] for row in rows}),
            cases_with_higher_engine_time=sum(row['after_engine_seconds']>row['before_engine_seconds'] for row in rows),
            reported_file_sorts=sum(row['reported_file_sort'] for row in rows),
            file_kernel_cases=sum(row['native_pipeline_file_kernel_invocations']>0 for row in rows))
            for name,rows in groups.items()},
        failures=failures,attempts_per_case=1,repeated_baseline_queries=0,
        independent_complete_results_replayed=True,no_denied_reservations=not failures,no_spill=not failures,
        case_rows=identity(cases_path),ledger=identity(target/'attempts.sqlite'),
        certificates=identity(certificates),protocol=identity(current.PROTOCOL),
        cohort=identity(current.COHORT),verifier=identity(Path(__file__)),
        limitation='Mandatory correctness repair, not a speedup claim. Historical comparison groups retain '
                   'their separate source identities. One observation per runtime; no repeatability, '
                   'single-change causality, whole-engine or complete Vortex physical-work coverage claim.')
    for name, expected in selection['baseline_groups'].items():
        if name in result['groups'] and result['groups'][name]['cases'] == expected['cases']:
            assert result['groups'][name]['baseline_engine_seconds'] == expected['engine_seconds']
    with destination.open('x') as stream:
        json.dump(result,stream,indent=2,allow_nan=False)
        stream.write('\n')
    print(json.dumps({key:result[key] for key in ('status','successful_cases','unsuccessful_cases','counts','groups')}),flush=True)
    if failures:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
