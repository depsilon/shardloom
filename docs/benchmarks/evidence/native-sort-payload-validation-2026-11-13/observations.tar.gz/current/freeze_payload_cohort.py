"""Independently bind a conservative Sort correctness cohort before measurement."""
from collections import Counter
import gzip
import hashlib
import json
import math
from pathlib import Path
import re
import subprocess
import sys

import verify_sort_exposure as frozen
from query_surface.semantics import schema_record

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
DEST = OUT / 'payload-sort-cohort-r1.json'


def read(path):
    return json.loads(path.read_bytes())


def identity(path):
    with path.open('rb') as stream:
        return dict(path=str(path), bytes=path.stat().st_size,
                    sha256=hashlib.file_digest(stream, 'sha256').hexdigest())


def records(path):
    with gzip.open(path, 'rt') as stream:
        rows = [json.loads(line) for line in stream]
    assert len(rows) == len({row['id'] for row in rows})
    return {row['id']: row for row in rows}


def candidates(root):
    result = []
    pending = [(root, (), ())]
    while pending:
        node, path, ancestors = pending.pop()
        if node.op == 'sort' and len(node.inputs) == 1:
            child = node.inputs[0]
            unary = []
            while child.op in {'project', 'filter'} and len(child.inputs) == 1:
                unary.append(child.op)
                child = child.inputs[0]
            if child.op == 'scan':
                result.append(dict(sort_node_path=list(path),
                    ancestor_path=list(ancestors), sort_fields=schema_record(node.schema),
                    key_names=[dict(column=key.column, descending=key.descending,
                                    nulls=key.nulls) for key in node.args],
                    source_names=[child.args[0]], sort_input_unary_path=unary + ['scan']))
        for index, child in reversed(list(enumerate(node.inputs))):
            pending.append((child, path + (index,),
                            ancestors + (dict(path=list(path), op=node.op),)))
    return result


def main():
    assert __debug__ and not DEST.exists()
    leaf_path = OUT / 'payload-sort-exposure-r1.json'
    leaf = read(leaf_path)
    for name, digest in leaf['source_file_sha256'].items():
        assert identity(Path(name))['sha256'] == digest
    leaf_cases = {row['id']: row for row in leaf['sort_candidates']}
    assert len(leaf_cases) == len(leaf['sort_candidates']) == 378
    design_path = frozen.E / 'design.json'
    design = read(design_path)
    observed_path = OUT / 'coverage-inventory-r1/observed-query-evidence.jsonl.gz'
    observations = records(observed_path)
    original_path = OUT / 'full10k-r1/verified-cases-r1.jsonl.gz'
    original = records(original_path)
    original_summary = read(OUT / 'full10k-r1/verified-summary-r1.json')
    assert original_summary['successful_cases'] == original_summary['attempted_cases'] == 10000
    assert identity(original_path)['sha256'] == original_summary['case_rows']['sha256']
    sort_path = OUT / 'sort-cohort-r1/verified-cases-r1.jsonl.gz'
    sort_rows = records(sort_path)
    sort_summary = read(OUT / 'sort-cohort-r1/verified-summary-r1.json')
    assert sort_summary['successful_cases'] == sort_summary['attempted_cases'] == 606
    assert identity(sort_path)['sha256'] == sort_summary['case_rows']['sha256']
    controls = []
    seen_controls = set()
    for item in read(OUT / 'sort-demand-cohort-r1.json')['cases']:
        descriptor = item['declaration']
        key = descriptor['surface'], descriptor['native_format']
        if key not in seen_controls:
            assert key[1] in {'parquet', 'arrow-ipc'}
            seen_controls.add(key)
            controls.append(descriptor['id'])
    assert set(controls) == {row['id'] for row in leaf['control_cases']} and len(controls) == 10
    originals = {case.id: case for case in frozen.corpus(interactions='all', include_pending=False)}
    definitions = {space.name: space for space in frozen.spaces()}
    rows, groups, corrected_paths = [], Counter(), 0
    for ordinal, descriptor in enumerate(design['cases']):
        case = frozen.build(descriptor, definitions) if 'cell' in descriptor else originals[descriptor['id']]
        observed = observations[case.id]
        assert case.identity == descriptor['case_identity'] == observed['case_identity']
        assert observed['seq'] == ordinal and original[case.id]['seq'] == ordinal
        matches = candidates(case.relation) if descriptor['native_format'] == 'vortex' else []
        assert bool(matches) == (case.id in leaf_cases)
        if matches:
            assert len(matches) == 1
            matched = matches[0]
            supplied = leaf_cases[case.id]
            assert supplied['descriptor'] == descriptor
            for key, value in matched.items():
                if key == 'ancestor_path':
                    corrected_paths += int(supplied[key] != value)
                else:
                    assert supplied[key] == value, (case.id, key)
            pairs = re.findall(r'(?:^|[ ;])([a-z][a-z0-9_]*)=([0-9]+)(?=$|[ ;])',
                observed['fields']['local_primitive_native_io_pushdown_proof_basis'])
            assert len(pairs) == len(dict(pairs))
            kernels = int(dict(pairs)['native_pipeline_file_kernel_invocations'])
            reported_sort = 'local_primitive_sort_provider_background_workers' in observed['fields']
            assert supplied['file_kernel_invocation_count'] == kernels
            assert supplied['has_background_worker_field'] == reported_sort
            assert supplied['baseline_raw_stdout_sha256'] == observed['raw_stdout_sha256']
            group = ('vortex_reported_file_sort' if reported_sort else
                     'vortex_other_file_kernel' if kernels else 'vortex_no_file_kernel')
            baseline, source, ledger = original[case.id], original_summary['source_commit'], 'full10k-r1'
            raw_hash = observed['raw_stdout_sha256']
        elif case.id in controls:
            matched, raw_hash = None, None
            group = 'owned_source_control'
            baseline, source, ledger = sort_rows[case.id], sort_summary['source_commit'], 'sort-cohort-r1'
        else:
            continue
        assert baseline['current']['status'] == 'passed'
        seconds = baseline['current']['engine_seconds']
        assert isinstance(seconds, (float, int)) and math.isfinite(seconds) and seconds >= 0
        groups[group] += 1
        rows.append(dict(original_ordinal=ordinal, declaration=descriptor, comparison_group=group,
            baseline_engine_seconds=seconds, baseline_source_commit=source,
            baseline_ledger=ledger, baseline_seq=baseline['seq'], baseline_work=baseline['current']['work'],
            baseline_raw_stdout_sha256=raw_hash, declaration_match=matched))
    assert len(design['cases']) == 10000 and len(rows) == 388
    assert groups == dict(vortex_reported_file_sort=21, vortex_other_file_kernel=36,
                          vortex_no_file_kernel=321, owned_source_control=10)
    loaded = {Path(module.__file__).resolve() for name, module in tuple(sys.modules.items())
              if name.startswith('query_surface') and getattr(module, '__file__', None)}
    assert not any(name == 'shardloom._native' or name.startswith('_polars_runtime') for name in sys.modules)
    paths = loaded | {Path(__file__), Path(frozen.__file__), leaf_path,
        OUT / 'payload-sort-exposure.py', design_path, observed_path, original_path, sort_path,
        OUT / 'full10k-r1/verified-summary-r1.json', OUT / 'sort-cohort-r1/verified-summary-r1.json',
        OUT / 'sort-demand-cohort-r1.json', OUT / 'payload-sort-design-r1.md'}
    previous = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    patch = subprocess.check_output(['git', 'diff', original_summary['source_commit'], previous,
                                     '--', 'shardloom-vortex/src'], cwd=ROOT)
    result = dict(schema='shardloom.sort_payload_cohort.v1', status='frozen_before_candidate_execution',
        query_executions=0, original_declarations_verified=10000, case_count=388,
        selection='All Vortex declarations containing Sort over Scan through only Project/Filter, '
                  'plus the first original-order Parquet/IPC Sort case per interface; no timing selection.',
        attempts_per_case=1, repeats=0, warmups=0, primary_clock='engine_execution_seconds',
        baseline_queries_to_repeat=0, groups=dict(groups),
        baseline_groups={name:dict(cases=count,
            engine_seconds=math.fsum(row['baseline_engine_seconds'] for row in rows if row['comparison_group']==name),
            source_commits=sorted({row['baseline_source_commit'] for row in rows if row['comparison_group']==name}))
            for name, count in groups.items()},
        baseline_reuse=dict(exact_runtime_source_equality=False, accepted_predecessor=previous,
            preceding_patch_sha256=hashlib.sha256(patch).hexdigest(),
            scope='Vortex observations retain original 9f source identity; owned controls use the later '
                  'cac86 Sort cohort. No combined historical engine total or single-change causal claim.'),
        primary_inventory_review=dict(status='passed', source_hashes_verified=True,
            reconstructed_all_declarations=True, corrected_ancestor_paths=corrected_paths,
            missing_counters_rejected=True, native_and_polars_runtimes_imported=False),
        source_identities=[identity(path) for path in sorted(paths)], cases=rows,
        acceptance='Complete independent answers, mandatory invalid-payload regressions, current-source '
                   'workspace/install checks, no fallback, complete source/reader cleanup, and explicit '
                   'work/resource/per-case engine review. Correctness repair has no speedup acceptance claim.')
    with DEST.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({key:result[key] for key in ('status','case_count','groups','primary_inventory_review')}))


if __name__ == '__main__':
    main()
