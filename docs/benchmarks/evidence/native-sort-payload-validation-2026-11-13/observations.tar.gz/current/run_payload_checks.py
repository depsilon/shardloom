"""Validate the Sort admission correction under the established source guard."""
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
CHECKS = [
    ('payload-pipeline-tests-r1', 2400,
     ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-vortex', '--lib',
      '--features', 'release-user-surfaces', '--', 'native_pipeline::tests', '--nocapture']),
    ('payload-fmt-r1', 2400, ['cargo', 'fmt', '--all', '--', '--check']),
    ('payload-default-clippy-r1', 2400,
     ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('payload-native-clippy-r1', 2400,
     ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets',
      '--features', 'python-native,native-encoded-exchange-experiment', '--', '-D', 'warnings']),
    ('payload-default-tests-r1', 7200,
     ['cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets']),
    ('payload-native-tests-r1', 7200,
     ['cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets',
      '--features', 'python-native,native-encoded-exchange-experiment']),
]

if __name__ == '__main__':
    for name, timeout, command in CHECKS:
        print(name, flush=True)
        subprocess.run([sys.executable, '-B', str(OUT / 'guard_checks.py'), '--name', name,
                        '--timeout', str(timeout), '--', *command], check=True)
