"""Continue after the native-lint helper extraction; preserve all R1 receipts."""
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
CHECKS = [
    ('payload-pipeline-tests-r2', 2400,
     ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-vortex', '--lib',
      '--features', 'release-user-surfaces', '--', 'native_pipeline_tests', '--nocapture']),
    ('payload-fmt-r2', 2400, ['cargo', 'fmt', '--all', '--', '--check']),
    ('payload-default-clippy-r2', 2400,
     ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('payload-native-clippy-r2', 2400,
     ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets',
      '--features', 'python-native,native-encoded-exchange-experiment', '--', '-D', 'warnings']),
    ('payload-default-tests-r1', 7200,
     ['cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets']),
    ('payload-native-tests-r1', 7200,
     ['cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets',
      '--features', 'python-native,native-encoded-exchange-experiment']),
]

if __name__ == '__main__':
    for name, timeout, command in CHECKS:
        print(name, flush=True)
        subprocess.run([sys.executable, '-B', str(OUT / 'guard_checks.py'), '--name', name,
                        '--timeout', str(timeout), '--', *command], check=True)
        if name == 'payload-pipeline-tests-r2':
            log = (OUT / 'logs' / (name + '.log')).read_text()
            assert 'running 0 tests' not in log and 'native_pipeline_tests::' in log
