"""Archive final input documentation, executable examples and browser observations."""
import hashlib
import io
import json
import tarfile
from pathlib import Path

import input_common as c

RUNTIME_COMMIT = 'f14460ef262b076842d375fa05d33507c4a97027'


def main():
    source = c.frozen()
    assert c.git('rev-parse', 'HEAD') == RUNTIME_COMMIT
    checks = c.read(c.OUT / 'input-documentation-checks-1/summary.json')
    assert checks['status'] == 'passed' and len(checks['checks']) == 7
    assert checks['source_identity_sha256'] == source['source_identity_sha256']
    assert len(checks['executed_examples']) == 3 and checks['examples_changed']
    for row in checks['checks']:
        assert row['returncode'] == 0 and c.sha(row['log']) == row['log_sha256']
    for row in checks['executed_examples']:
        assert c.sha(c.ROOT / row['source']) == row['source_sha256']
        assert hashlib.sha256(row['code'].encode()).hexdigest() == row['code_sha256']
        assert row['envelope']['status'] == 'success'
        assert row['complete_rows']
    assert c.sha(c.OUT / 'verify_input_documentation.py') == checks['driver_sha256']
    for name in ('input-documentation-checks-1', 'input-documentation-preview-1'):
        receipt = c.read(c.OUT / f'{name}.json')
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert c.sha(c.OUT / f'{name}.log') == receipt['log_sha256']
    assert (c.OUT / 'input-documentation-preview-stop-1').is_file()
    browser = c.read(c.OUT / 'input-documentation-browser-1.json')
    assert browser['status'] == 'passed_manual_browser_review'
    assert not browser['console_warnings_errors']
    for name in ('desktop', 'mobile', 'resources', 'limitations'):
        assert browser[name]['viewport'] == browser[name]['body']
    assert browser['search']['landed_url'].endswith('/python-surface/#consume-results-in-batches')
    assert '4 results for streaming' in browser['search']['text']
    assert all((c.OUT / path).is_file() for path in browser['screenshots'])

    # Only plain status/evidence prose was updated after the built-page checks.
    revised = {name: {'checked_sha256': digest, 'final_sha256': c.sha(c.ROOT / name)}
               for name, digest in checks['documentation_source_hashes'].items()
               if c.sha(c.ROOT / name) != digest}
    allowed = {
        'docs/architecture/native-input-completion-2026-10-07.md',
        'docs/architecture/native-state-structure-campaign-2026-10-07.md',
        'docs/architecture/phased-execution-plan.md',
        'docs/benchmarks/native-input-completion-2026-10-07.md',
        'docs/release/v1-inclusion-scope-matrix.md',
    }
    assert set(revised) <= allowed, revised
    paths = {}
    for prefix in ('input-documentation-', 'input-docs-'):
        for path in sorted(c.OUT.glob(prefix + '*')):
            for item in sorted(path.rglob('*')) if path.is_dir() else [path]:
                if item.is_file():
                    paths['proof/' + str(item.relative_to(c.OUT))] = item
    for name in ('verify_input_documentation.py', 'preview_input_documentation.py',
                 'input_common.py', 'run_guarded.py', 'finalize_input_documentation.py',
                 Path(__file__).name):
        paths['drivers/' + name] = c.OUT / name
    names = c.git('diff', '--name-only', 'HEAD').splitlines()
    names += c.git('ls-files', '--others', '--exclude-standard').splitlines()
    for name in sorted(set(names)):
        path = c.ROOT / name
        if path.is_file() and not name.startswith('docs/benchmarks/evidence/'):
            assert name.startswith(('docs/', 'website-src/', 'website/')) or name == 'python/README.md', name
            assert not path.is_symlink(), name
            paths['source/' + name] = path

    assert sum(path.stat().st_size for path in paths.values()) < 32 * 1024 * 1024
    manifest = {name: {'bytes': path.stat().st_size, 'sha256': c.sha(path)}
                for name, path in sorted(paths.items())}
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    browser_bytes = (json.dumps(browser, indent=2, sort_keys=True) + '\n').encode()
    target = c.ROOT / 'docs/benchmarks/evidence/native-input-documentation-2026-10-07.tar.xz'
    with tarfile.open(target, 'x:xz', preset=6) as archive:
        for name, path in sorted(paths.items()):
            info = tarfile.TarInfo(name)
            info.size = path.stat().st_size
            info.mode = 0o644
            with path.open('rb') as stream:
                archive.addfile(info, stream)
        for name, raw in (('manifest.json', manifest_bytes), ('browser.json', browser_bytes)):
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(raw))
    with tarfile.open(target, 'r:xz') as archive:
        members = archive.getmembers()
        assert len(members) == len(manifest) + 2
        assert {item.name for item in members} == set(manifest) | {'manifest.json', 'browser.json'}
        assert archive.extractfile('manifest.json').read() == manifest_bytes
        assert archive.extractfile('browser.json').read() == browser_bytes
        for name, expected in manifest.items():
            with archive.extractfile(name) as stream:
                assert hashlib.file_digest(stream, 'sha256').hexdigest() == expected['sha256']
            assert archive.getmember(name).size == expected['bytes']
    c.frozen()
    report = {
        'schema_version': 'shardloom.native_input_documentation_acceptance.v1',
        'status': 'passed_local_documentation_acceptance',
        'runtime_commit': RUNTIME_COMMIT,
        'source_identity_sha256': source['source_identity_sha256'],
        'runtime_source_assets_verified': len(source['source_hashes']),
        'documentation_checks': checks['checks'],
        'executed_examples': checks['executed_examples'],
        'post_check_status_prose_changes': revised,
        'post_check_queue_reconciliation': 'docs/architecture/native-conditional-work-campaign-2026-10-07.md',
        'browser': browser,
        'examples_changed': True,
        'runtime_implementation_rerun_required': False,
        'archive': {'path': str(target.relative_to(c.ROOT)),
                    'bytes': target.stat().st_size, 'sha256': c.sha(target),
                    'file_members': len(manifest), 'total_members': len(manifest) + 2,
                    'manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
                    'all_members_reopened_and_hash_checked': True},
        'source_files': {name.removeprefix('source/'): item
                         for name, item in manifest.items() if name.startswith('source/')},
        'temporary_server_drained': True,
        'hosted_integration': 'pending',
        'claim_boundary': 'Exact documentation, native examples and generated pages; no new performance, RSS or package claim.',
        'driver_sha256': c.sha(__file__),
    }
    portable = json.dumps(report, indent=2, allow_nan=False)
    for path, replacement in ((c.ROOT, '<repo>'), (c.OUT, '<input-uat>'), (Path.home(), '<home>')):
        portable = portable.replace(str(path), replacement)
    result_path = target.with_name('native-input-documentation-2026-10-07.json')
    with result_path.open('x') as stream:
        stream.write(portable + '\n')
    print(json.dumps({'status': 'passed', 'members': len(manifest) + 2,
                      'bytes': target.stat().st_size, 'sha256': c.sha(target)}), flush=True)


if __name__ == '__main__':
    main()
