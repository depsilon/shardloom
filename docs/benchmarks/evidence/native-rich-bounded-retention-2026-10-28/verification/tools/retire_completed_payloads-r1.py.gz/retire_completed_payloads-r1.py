"""Retire exact rich-retention task artifacts after portable replay, retaining proof."""
from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import shutil
import sys

REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
ROOT = Path(__file__).resolve().parents[1]
PACKET = REPO / 'docs/benchmarks/evidence/native-rich-bounded-retention-2026-10-28'
HELPER = ROOT.parent / 'shared-aggregate-performance-2026-10-27/tools/retire_completed_performance_payloads.py'
spec = importlib.util.spec_from_file_location('retirement_primitives', HELPER)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
helper.ROOT = helper.OLD = ROOT
from query_surface.replay import object_files
from verify_rich_bounded_retention_packet import verify
from release_validation_guard import WorkloadGuard

read, digest, inventory, identity, closed = helper.read, helper.digest, helper.inventory, helper.identity, helper.closed


def need(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    need(__debug__, 'retirement primitives require assertions enabled')
    need(ROOT == Path('/Users/dylan/LocalData/ShardLoom/rich-bounded-retention-2026-10-28'), 'wrong task root')
    need(not (PACKET / 'cleanup.json').exists(), 'existing cleanup receipt')
    manifest = read(PACKET / 'manifest.json')
    files = object_files(manifest, (PACKET / 'packet.tar.xz').read_bytes())
    need(verify(files, manifest) == read(PACKET / 'acceptance.json'), 'portable replay mismatch')
    for name in ('r39-portable-controls', 'r41-isolated-portable-replay', 'r43-architecture-ci-mode'):
        gate = read(ROOT / (name + '.json'))
        need(gate['status'] == 'passed' and gate['process_group_drained']
             and digest(ROOT / (name + '.log')) == gate['log_sha256'], 'missing passed gate ' + name)
    static = read(ROOT / 'final-static-r1.json')
    failed = [step for step in static['steps'] if step['returncode'] != 0]
    need(len(failed) == 1 and failed[0]['command'][2].endswith('check_release_architecture_tracker.py'),
         'unexpected static failure')
    architecture = read(ROOT / 'check_release_architecture_tracker-r2.json')
    need(architecture['status'] == 'blocked' and architecture['blockers'] == ['phase plan has unchecked items: 76'],
         'architecture blocker changed')
    package = read(ROOT / 'installed-wheel-r1/report.json')
    need(package['status'] == package['uninstall_status'] == 'passed', 'package proof incomplete')
    current = read(ROOT / 'candidate-release-r1/manifest.json')
    retained = {ROOT / 'candidate-release-r1' / name: item['sha256'] for name, item in current['files'].items()}
    retained[ROOT / 'installed-wheel-r1/dist' / package['integrity']['wheel']] = package['integrity']['wheel_sha256']
    frozen = read(ROOT / 'broad-baseline-r1/inputs.json')
    sources = {p for group in frozen['sources'].values() for p in group}
    references = [x for x in frozen['frozen_files'] if x['path'].endswith('-reference.stdout.json')]
    need(len(sources) == 5 and len(references) == 347, 'original input/reference coverage')
    retained.update({Path(x['path']): x['sha256'] for x in frozen['frozen_files']
                     if x['path'] in sources or x in references})
    need(all(p.is_file() and not p.is_symlink() and digest(p) == d for p, d in retained.items()), 'retained identity mismatch')
    for name in ('manifest.json', 'acceptance.json', 'packet.tar.xz'):
        need(digest(ROOT / 'packet-r2' / name) == digest(PACKET / name), 'duplicate packet differs')
    isolated = read(ROOT / 'portable-verification-r1.json')
    need(isolated['status'] == 'passed', 'isolated replay incomplete')
    for name, item in isolated['source_files'].items():
        need(digest(ROOT / 'portable-verification-r1' / name) == item['sha256'], 'isolated copy changed')
    baseline = read(ROOT / 'baseline-release-r1/manifest.json')
    for name, item in baseline['files'].items():
        need(digest(ROOT / 'baseline-release-r1' / name) == item['sha256'], 'superseded baseline changed')
    staging = ROOT / 'public-prefix-staging-r2/_native.abi3.so'
    need(digest(staging) == current['files']['_native.abi3.so']['sha256'], 'staged library changed')
    roots = [(ROOT / name, False) for name in (
        'installed-wheel-r1/package', 'installed-wheel-r1/venv', 'wheel-build-tools',
        'installed-proof-wheelhouse', 'packet-r2', 'portable-verification-r1',
        'public-prefix-staging-r2', 'baseline-release-r1/shardloom', 'baseline-release-r1/_native.abi3.so')]
    roots += [(ROOT / name, True) for name in (
        'baseline-release-r1/source', 'candidate-release-r1/source',
        'broad-baseline-r1/harness', 'broad-baseline-r1/logs',
        'broad-candidate-r1/harness', 'broad-candidate-r1/logs',
        'heldout-r1/inputs', 'heldout-r1/references', 'heldout-r1/logs')]
    need(all(not (p == kept or p in kept.parents) for p, _ in roots for kept in retained), 'retained path selected')
    external = {(x['path'], x['sha256'], x['bytes']) for x in manifest['external_artifacts']}
    rows = []
    for path, archived in roots:
        current_rows = inventory(path)
        if archived:
            for row in current_rows:
                if row['kind'] != 'regular':
                    continue
                key = manifest['path_map'].get(row['path'])
                if key in files:
                    need(hashlib.sha256(files[key]).hexdigest() == row['sha256']
                         and len(files[key]) == row['generation'][3], 'archived payload differs: ' + row['path'])
                else:
                    need(Path(row['path']).suffix == '.parquet' and
                         (row['path'], row['sha256'], row['generation'][3]) in external,
                         'unrepresented generated payload: ' + row['path'])
        rows.extend(current_rows)
    need(len({r['path'] for r in rows}) == len(rows), 'overlapping retirement roots')
    proofs = {str(p): digest(p) for p in ROOT.glob('*.json') if p.is_file()}
    proofs.update({str(PACKET / n): digest(PACKET / n) for n in ('manifest.json', 'packet.tar.xz', 'acceptance.json')})
    proofs[str(HELPER)] = digest(HELPER)
    record = dict(schema_version='shardloom.generated_artifact_retirement.v1', status='running',
        roots=[str(p) for p, _ in roots], retained_sha256={str(p): d for p, d in retained.items()},
        closed_handle_checks=[], removed_entries=0, source_inputs_retained=True,
        original_external_baselines_untouched=True, user_files_and_item18_untouched=True,
        cargo_cache_untouched=True, payload_backups_created=False, symlink_targets_followed=False,
        earlier_packet_r1_retained=True,
        regeneration_basis='Frozen generation recipe, seeds, complete references and source/build identities; current tested runtime and wheel retained. No bit-identical rebuild claim.')
    raw = json.dumps(dict(entries=rows, retained=record['retained_sha256'], proof_sha256=proofs), sort_keys=True).encode()
    need(len(raw) <= 32 << 20, 'inventory exceeds bound')
    packed = gzip.compress(raw, mtime=0)
    need(gzip.decompress(packed) == raw, 'inventory roundtrip failed')
    out = PACKET / 'cleanup-inventory.json.gz'
    with out.open('xb') as stream:
        stream.write(packed)
    record.update(inventory=str(out), inventory_sha256=digest(out), free_bytes_before=shutil.disk_usage(ROOT).free)
    try:
        WorkloadGuard().check()
        record['closed_handle_checks'] = [closed(p) for p, _ in roots]
        need(all(digest(Path(p)) == d for p, d in proofs.items()), 'proof changed before retirement')
        need([row for p, _ in roots for row in inventory(p)] == rows, 'retirement inventory changed')
        WorkloadGuard().check()
        print(json.dumps(dict(stage='identities_and_closed_handles_verified', entries=len(rows))), flush=True)
        for row in sorted(rows, key=lambda r: len(Path(r['path']).parts), reverse=True):
            path = Path(row['path'])
            if row['kind'] == 'directory':
                state = path.lstat()
                need([state.st_dev, state.st_ino, state.st_mode] == row['generation'][:3], 'directory identity changed')
                path.rmdir()
            else:
                need(identity(path) == row, 'file identity changed')
                path.unlink()
            record['removed_entries'] += 1
        need(all(not p.exists() and not p.is_symlink() for p, _ in roots), 'retirement incomplete')
        need(all(p.is_file() and not p.is_symlink() and digest(p) == d for p, d in retained.items()), 'retained payload changed')
        need(all(digest(Path(p)) == d for p, d in proofs.items()), 'proof changed after retirement')
        need(verify(files, manifest) == read(PACKET / 'acceptance.json'), 'replay after retirement failed')
        record.update(status='passed', regular_files=sum(r['kind'] == 'regular' for r in rows),
            symlinks=sum(r['kind'] == 'symlink' for r in rows),
            retired_regular_bytes=sum(r['generation'][3] for r in rows if r['kind'] == 'regular'),
            retired_allocated_bytes=sum(r.get('allocated_bytes', 0) for r in rows),
            all_proof_files_unchanged=True, portable_replay_after_retirement=True,
            free_bytes_after=shutil.disk_usage(ROOT).free)
    except BaseException as error:
        record.update(status='failed', error=repr(error))
        raise
    finally:
        (PACKET / 'cleanup.json').write_text(json.dumps(record, indent=2) + '\n')
        (ROOT / 'cleanup.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({k: record[k] for k in ('status', 'regular_files', 'symlinks', 'retired_regular_bytes')}), flush=True)


if __name__ == '__main__':
    main()
