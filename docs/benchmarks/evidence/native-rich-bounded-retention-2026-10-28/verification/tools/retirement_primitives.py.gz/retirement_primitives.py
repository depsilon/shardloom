"""Retire exact completed payloads after independent portable verification."""
from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys

REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
ROOT = Path(__file__).resolve().parent.parent
OLD = ROOT.parent / 'analytical-completion-2026-10-27'
PACKET = REPO / 'docs/benchmarks/evidence/native-shared-analytical-performance-2026-10-27'
sys.path[:0] = [str(REPO / 'scripts'), str(REPO / 'python/src'),
               str(REPO / 'benchmarks/traditional_analytics'),
               '/Users/dylan/LocalData/shardloom/release-0.3.3-20260930']
from query_surface.replay import object_files
from verify_shared_analytical_performance_packet import verify
from release_validation_guard import WorkloadGuard


def read(path):
    return json.loads(path.read_text())


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    state = path.lstat()
    generation = lambda s: [s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns]
    item = dict(path=str(path), generation=generation(state))
    if stat.S_ISREG(state.st_mode):
        item.update(kind='regular', sha256=digest(path), allocated_bytes=state.st_blocks * 512)
    elif stat.S_ISLNK(state.st_mode):
        item.update(kind='symlink', target=os.readlink(path))
    elif stat.S_ISDIR(state.st_mode):
        item.update(kind='directory')
    else:
        raise ValueError('unexpected generated file type: ' + str(path))
    assert generation(path.lstat()) == item['generation'], path
    return item


def inventory(root):
    assert (root.is_relative_to(ROOT) or root.is_relative_to(OLD)) and root.resolve() == root
    rows = [identity(root)]
    if rows[0]['kind'] == 'directory':
        assert not (root / '.git').exists()
        def visit(directory):
            for path in sorted(directory.iterdir()):
                item = identity(path)
                rows.append(item)
                if item['kind'] == 'directory':
                    visit(path)
        visit(root)
    return rows


def closed(path):
    command = ['/usr/sbin/lsof', '-nP', '-Fpn']
    command += ['+D', str(path)] if path.is_dir() else [str(path)]
    result = subprocess.run(command, capture_output=True, text=True, timeout=45)
    assert result.returncode == 1 and not result.stdout and not result.stderr, (str(path), result.stdout, result.stderr)
    return dict(path=str(path), returncode=1, open_handles=0)


def main():
    assert ROOT == Path('/Users/dylan/LocalData/shardloom/shared-aggregate-performance-2026-10-27')
    assert not (PACKET / 'cleanup.json').exists()
    manifest = read(PACKET / 'manifest.json')
    files = object_files(manifest, (PACKET / 'packet.tar.xz').read_bytes())
    assert verify(files, manifest) == read(PACKET / 'replay.json')
    for name in ('r37-shared-packet-controls', 'r38-shared-clean-replay'):
        proof = read(ROOT / (name + '.json'))
        assert proof['status'] == 'passed' and proof['process_group_drained']
        assert digest(ROOT / (name + '.log')) == proof['log_sha256']
    package = read(ROOT / 'installed-wheel-r1/report.json')
    assert package['status'] == package['uninstall_status'] == 'passed'
    retained = {
        ROOT / 'ordering-release-runtime-r1/shardloom': package['integrity']['cli_sha256'],
        ROOT / 'ordering-release-runtime-r1/_native.abi3.so': package['integrity']['native_library_sha256'],
        ROOT / 'installed-wheel-r1/dist' / package['integrity']['wheel']: package['integrity']['wheel_sha256'],
    }
    frozen = read(ROOT / 'broad-aggregate-r1/inputs.json')
    sources = {p for paths in frozen['sources'].values() for p in paths}
    frozen_paths = {item['path'] for item in frozen['frozen_files']}
    assert len(sources) == 5 and sources <= frozen_paths
    for item in frozen['frozen_files']:
        if item['path'] in sources:
            retained[Path(item['path'])] = item['sha256']
    assert sources <= {str(path) for path in retained}
    assert all(p.is_file() and not p.is_symlink() and digest(p) == d for p, d in retained.items())
    roots = [(ROOT / name, False) for name in (
        'installed-wheel-r1/package', 'installed-wheel-r1/venv', 'wheel-build-tools',
        'installed-proof-wheelhouse', 'packet-draft-r1', 'packet-replay-clean',
        'ordering-public-r1/outputs')]
    roots += [(ROOT / name, True) for name in (
        'broad-aggregate-r1/harness', 'broad-aggregate-r1/logs',
        'broad-variable-r1/harness', 'broad-variable-r1/logs',
        'broad-ordering-r1/harness', 'broad-ordering-r1/logs',
        'aggregate-release-runtime-r1/source', 'variable-release-runtime-r1/source',
        'ordering-release-runtime-r1/source',
        'projection-diagnostic-r1/logs', 'ordering-aggregate-diagnostic-r1/logs',
        'ordering-public-r1/logs')]

    def runtime_payloads(runtime):
        runtime = Path(runtime)
        runtime_manifest = read(runtime / 'manifest.json')
        payloads = {}
        for name, item in runtime_manifest['files'].items():
            path = runtime / name
            assert path.is_file() and not path.is_symlink()
            assert path.stat().st_size == item['bytes'] and digest(path) == item['sha256'], path
            payloads[path] = item['sha256']
        assert set(runtime_manifest['files']) == {'shardloom', '_native.abi3.so'}
        return payloads

    superseded = {}
    for runtime in ('aggregate-release-runtime-r1', 'variable-release-runtime-r1'):
        superseded.update(runtime_payloads(ROOT / runtime))
    superseded.update(runtime_payloads(OLD / 'analytical-release-runtime-r1'))
    previous = read(OLD / 'installed-wheel-r1/report.json')['integrity']
    old_wheel = OLD / 'installed-wheel-r1/dist' / previous['wheel']
    assert old_wheel.is_file() and not old_wheel.is_symlink()
    assert old_wheel.stat().st_size == previous['wheel_bytes']
    assert digest(old_wheel) == previous['wheel_sha256']
    superseded[old_wheel] = previous['wheel_sha256']
    roots += [(p, False) for p in superseded]
    assert len({str(p) for p, _ in roots}) == len(roots)
    assert all(not (p == kept or p in kept.parents) for p, _ in roots for kept in retained)
    rows = []
    for path, archived in roots:
        current = inventory(path)
        if archived:
            for item in current:
                if item['kind'] == 'regular':
                    key = manifest['path_map'].get(item['path'])
                    assert key in files and len(files[key]) == item['generation'][3]
                    assert hashlib.sha256(files[key]).hexdigest() == item['sha256'], item['path']
        rows.extend(current)
    assert len({r['path'] for r in rows}) == len(rows)
    proofs = {str(p): digest(p) for p in ROOT.glob('*.json') if p.is_file()}
    proofs.update({str(PACKET / n): digest(PACKET / n) for n in (
        'manifest.json', 'packet.tar.xz', 'replay.json', 'source-only-replay.py')})
    record = dict(schema_version='shardloom.generated_artifact_retirement.v1', status='running',
        roots=[str(p) for p, _ in roots], retained_sha256={str(p): d for p, d in retained.items()},
        closed_handle_checks=[], removed_entries=0, source_inputs_retained=True,
        original_external_baselines_untouched=True, user_files_and_item18_untouched=True,
        cargo_cache_untouched=True, payload_backups_created=False, symlink_targets_followed=False,
        regeneration_basis='Recorded source/build/package identities, locked requirements, retained sources and current tested runtime/wheel. No bit-identical rebuild claim.')
    raw = json.dumps(dict(entries=rows, retained=record['retained_sha256'], proof_sha256=proofs), sort_keys=True).encode()
    assert len(raw) <= 32 << 20
    packed = gzip.compress(raw, mtime=0)
    assert gzip.decompress(packed) == raw
    out = PACKET / 'cleanup-inventory.json.gz'
    with out.open('xb') as stream:
        stream.write(packed)
    record.update(inventory=str(out), inventory_sha256=digest(out), free_bytes_before=shutil.disk_usage(ROOT).free)
    try:
        WorkloadGuard().check()
        record['closed_handle_checks'] = [closed(p) for p, _ in roots]
        assert all(digest(Path(p)) == d for p, d in proofs.items())
        assert [item for p, _ in roots for item in inventory(p)] == rows
        WorkloadGuard().check()
        print(json.dumps(dict(stage='identities_and_closed_handles_verified', entries=len(rows))), flush=True)
        for item in sorted(rows, key=lambda r: len(Path(r['path']).parts), reverse=True):
            path = Path(item['path'])
            if item['kind'] == 'directory':
                state = path.lstat()
                assert [state.st_dev, state.st_ino, state.st_mode] == item['generation'][:3]
                path.rmdir()
            else:
                assert identity(path) == item
                path.unlink()
            record['removed_entries'] += 1
        assert all(not p.exists() and not p.is_symlink() for p, _ in roots)
        assert all(p.is_file() and not p.is_symlink() and digest(p) == d for p, d in retained.items())
        assert all(digest(Path(p)) == d for p, d in proofs.items())
        record.update(status='passed', regular_files=sum(r['kind'] == 'regular' for r in rows),
            symlinks=sum(r['kind'] == 'symlink' for r in rows),
            retired_regular_bytes=sum(r['generation'][3] for r in rows if r['kind'] == 'regular'),
            retired_allocated_bytes=sum(r.get('allocated_bytes', 0) for r in rows),
            all_proof_files_unchanged=True, free_bytes_after=shutil.disk_usage(ROOT).free)
    except BaseException as error:
        record.update(status='failed', error=repr(error))
        raise
    finally:
        (PACKET / 'cleanup.json').write_text(json.dumps(record, indent=2) + '\n')
        (ROOT / 'cleanup.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({k: record[k] for k in ('status', 'regular_files', 'symlinks', 'retired_regular_bytes')}), flush=True)


if __name__ == '__main__':
    main()

