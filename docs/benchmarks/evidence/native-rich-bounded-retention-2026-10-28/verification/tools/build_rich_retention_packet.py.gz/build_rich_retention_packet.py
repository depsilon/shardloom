"""Preserve complete measured/held-out evidence in a bounded portable packet."""
from pathlib import Path
import argparse
import io
import json
import lzma
import os
import re
import sys
import tarfile

REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
ROOT = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(REPO / 'scripts'), str(REPO / 'python/src'), str(REPO / 'benchmarks/traditional_analytics')]
from query_surface.replay import MAX_FILE, MAX_FILES, MAX_EXPANDED, MAX_ARCHIVE, bounded_bytes, need, object_files, sha
from verify_rich_bounded_retention_packet import verify


def gather():
    files, mapping, by_hash, external = {}, {}, {}, {}

    def add(path, name, data=None):
        if data is None:
            data = bounded_bytes(path, MAX_FILE)
        need(len(data) <= MAX_FILE and name not in files, 'duplicate or large packet member')
        files[name], mapping[str(path)], by_hash[sha(data)] = data, name, name

    for path in sorted(ROOT.iterdir()):
        match = re.fullmatch(r'r(\d+)-[^/]+\.(json|log)', path.name)
        if (match and int(match.group(1)) <= 36) or path.name in {
            'protocol-r1.json', 'public-prefix-r1.json', 'public-prefix-r2.json', 'public-prefix-r3.json',
            'broad-baseline-r1-comparison.json', 'broad-candidate-r1-comparison.json',
            'broad-baseline-r1-observer.log', 'broad-candidate-r1-observer.log', 'heldout-r1-observer.log'}:
            add(path, 'evidence/' + path.name)
    directories = ('tools', 'baseline-release-r1', 'candidate-release-r1', 'broad-baseline-r1',
                   'broad-candidate-r1', 'heldout-r1', 'installed-wheel-r1')
    for directory in directories:
        for base, dirs, names in os.walk(ROOT / directory, followlinks=False):
            base = Path(base)
            dirs[:] = sorted(name for name in dirs if name not in {'__pycache__', 'venv', 'package', 'dist'}
                             and not (base / name).is_symlink())
            for name in sorted(names):
                path = base / name
                if path.suffix in {'.json', '.jsonl', '.txt', '.log', '.gz', '.py', '.rs', '.toml', '.lock', '.yml'}:
                    add(path, 'evidence/' + path.relative_to(ROOT).as_posix())

    previous = REPO / 'docs/benchmarks/evidence/native-shared-analytical-performance-2026-10-27'
    previous_manifest = json.loads(bounded_bytes(previous / 'manifest.json', MAX_FILE))
    previous_files = object_files(previous_manifest, bounded_bytes(previous / 'packet.tar.xz', MAX_ARCHIVE))
    previous_paths = {path: previous_files[name] for path, name in previous_manifest['path_map'].items()}
    for name in ('manifest.json', 'packet.tar.xz'):
        add(previous / name, 'previous/' + name)
    frozen = []
    for directory in ('broad-baseline-r1', 'broad-candidate-r1', 'heldout-r1'):
        frozen.extend(json.loads((ROOT / directory / 'inputs.json').read_text())['frozen_files'])
    bound = json.loads((ROOT / 'heldout-r1/runtime.json').read_text())
    frozen.extend(bound['runtime'] + [bound['input_manifest'], bound['runtime_manifest'], bound['build_receipt']])
    for item in frozen:
        path, digest, size = Path(item['path']), item['sha256'], item['generation']['bytes']
        if path.suffix in {'.parquet', '.so'} or path.name == 'shardloom':
            external[(str(path), digest)] = dict(path=str(path), sha256=digest, bytes=size,
                reason='Large source or runtime excluded; original generation and digest remain in the frozen inputs.')
            continue
        existing = mapping.get(str(path))
        if existing is not None:
            need(sha(files[existing]) == digest and len(files[existing]) == size, 'frozen mapped file differs: ' + str(path))
            continue
        if digest in by_hash:
            name = by_hash[digest]
            need(len(files[name]) == size, 'frozen deduplicated size differs')
            mapping[str(path)] = name
            continue
        data = previous_paths.get(str(path))
        if data is None:
            data = bounded_bytes(path, MAX_FILE)
        need(sha(data) == digest and len(data) == size, 'frozen source differs: ' + str(path))
        add(path, 'linked/' + digest + '/' + path.name, data)
    for name in ('verify_rich_bounded_retention_packet.py', 'rich_ordering_replay.py',
                 'test_rich_bounded_retention_packet.py'):
        path = REPO / 'scripts' / name
        if path.exists():
            add(path, 'source/scripts/' + name)
    package = json.loads((ROOT / 'installed-wheel-r1/report.json').read_text())
    integrity = package['integrity']
    for path in (ROOT / 'installed-wheel-r1/dist').glob('*.whl'):
        external[(str(path), integrity['wheel_sha256'])] = dict(path=str(path),
            sha256=integrity['wheel_sha256'], bytes=path.stat().st_size,
            reason='Installed-tested wheel is retained externally; full proof and logs are included.')
    return files, dict(schema_version='shardloom.broad_query.packet.v1',
        verification_kind='rich_bounded_retention', original_evidence_root=str(ROOT),
        path_map=mapping, external_artifacts=[external[key] for key in sorted(external)])


def archive(files, manifest):
    objects, inventory = {}, []
    for name, data in sorted(files.items()):
        digest = sha(data)
        objects[digest] = data
        inventory.append(dict(path=name, bytes=len(data), sha256=digest, member='objects/sha256/' + digest))
    expanded = sum(map(len, files.values()))
    need(len(files) <= MAX_FILES and expanded <= MAX_EXPANDED, 'expanded packet exceeds bounds')
    data = json.dumps(inventory, sort_keys=True, separators=(',', ':')).encode()
    need(len(data) <= MAX_FILE, 'packet inventory exceeds bound')
    digest = sha(data)
    objects[digest] = data
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w', format=tarfile.USTAR_FORMAT) as stream:
        for key, value in sorted(objects.items()):
            member = tarfile.TarInfo('objects/sha256/' + key)
            member.size, member.mode, member.mtime = len(value), 0o644, 0
            stream.addfile(member, io.BytesIO(value))
    need(buffer.tell() <= MAX_ARCHIVE, 'archive exceeds bound')
    packed = lzma.compress(buffer.getvalue(), preset=6)
    manifest.update(archive=dict(path='packet.tar.xz', bytes=len(packed), sha256=sha(packed)),
        expanded_file_bytes=expanded, unique_objects=len(objects), file_count=len(files),
        file_inventory=dict(member='objects/sha256/' + digest, sha256=digest, bytes=len(data)))
    need(object_files(manifest, packed) == files, 'packet readback differs')
    return packed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    need(not args.output.exists(), 'refuse to replace an evidence packet')
    files, manifest = gather()
    report = verify(files, manifest)
    packed = archive(files, manifest)
    args.output.mkdir()
    (args.output / 'packet.tar.xz').write_bytes(packed)
    for name, value in (('manifest', manifest), ('acceptance', report)):
        (args.output / (name + '.json')).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    print(json.dumps(dict(status='passed', files=len(files), expanded_bytes=manifest['expanded_file_bytes'],
        archive_bytes=len(packed), archive_sha256=sha(packed))))


if __name__ == '__main__':
    main()
