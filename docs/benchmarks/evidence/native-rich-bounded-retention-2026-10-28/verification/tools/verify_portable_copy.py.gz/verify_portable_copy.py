"""Replay the final rich-retention packet from a bounded source-only copy."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys

REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
DEST = OUT / 'portable-verification-r1'
EVIDENCE = Path('docs/benchmarks/evidence/native-rich-bounded-retention-2026-10-28')


def require(condition, message):
    if not condition:
        raise ValueError(message)


require(not DEST.exists(), 'source copy already exists')
source_files = sorted(set(path for root in ('scripts', 'python/src', 'benchmarks/traditional_analytics')
                         for path in (REPO / root).rglob('*.py') if '__pycache__' not in path.parts))
source_files += [REPO / EVIDENCE / name for name in ('manifest.json', 'acceptance.json', 'packet.tar.xz')]
require(all(path.is_file() and not path.is_symlink() for path in source_files), 'non-regular source')
require(sum(path.stat().st_size for path in source_files) < 64 << 20, 'source-copy byte budget')
records = {}
for path in source_files:
    relative = path.relative_to(REPO)
    target = DEST / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    require(hashlib.sha256(target.read_bytes()).hexdigest() == digest, 'source-copy identity')
    records[str(relative)] = dict(bytes=target.stat().st_size, sha256=digest)
commands = [
    [sys.executable, '-I', '-B', str(DEST / 'scripts/verify_rich_bounded_retention_packet.py'),
     str(DEST / EVIDENCE)],
    [sys.executable, '-I', '-O', '-B', '-m', 'unittest', 'discover',
     '-s', str(DEST / 'scripts'), '-p', 'test_rich_bounded_retention_packet.py', '-v'],
]
env = {key: value for key, value in os.environ.items()
       if not key.startswith(('PYTHON', 'SHARDLOOM_'))}
steps = []
for command in commands:
    result = subprocess.run(command, cwd=DEST, env=env, capture_output=True, text=True, timeout=600)
    print(result.stdout, end='')
    print(result.stderr, end='')
    steps.append(dict(command=command, returncode=result.returncode,
                      stdout=result.stdout, stderr=result.stderr))
    if result.returncode:
        break
report = dict(schema_version='shardloom.rich_retention_portable_copy.v1',
              status='passed' if len(steps) == 2 and all(x['returncode'] == 0 for x in steps) else 'failed',
              source_files=records, source_copy=str(DEST), isolated_python=True,
              corruption_controls_run_with_assertions_disabled=True,
              dataset_or_runtime_payloads_copied=False, archived_code_executed=False,
              steps=steps)
with (OUT / 'portable-verification-r1.json').open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
require(report['status'] == 'passed', 'isolated replay failed')
