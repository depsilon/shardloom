"""Run final documentation and CI-contract checks without query execution."""
from pathlib import Path
import json
import subprocess
import sys

REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
commands = [['git', 'diff', '--check']]
for script in ('check_release_architecture_tracker', 'check_v1_docs_productization', 'check_public_status_docs'):
    commands.append([sys.executable, '-B', str(REPO / 'scripts' / (script + '.py')),
                     '--repo-root', str(REPO), '--output', str(OUT / (script + '-r1.json'))])
commands.append([sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'scripts',
                 '-p', 'test_ci_execution_plan.py', '-v'])
steps = []
for command in commands:
    result = subprocess.run(command, cwd=REPO, capture_output=True, text=True, timeout=120)
    print(result.stdout, end='')
    print(result.stderr, end='')
    steps.append(dict(command=command, returncode=result.returncode,
                      stdout=result.stdout, stderr=result.stderr))
status = 'passed' if all(step['returncode'] == 0 for step in steps) else 'failed'
with (OUT / 'final-static-r1.json').open('x') as stream:
    json.dump(dict(status=status, steps=steps), stream, indent=2)
    stream.write('\n')
raise SystemExit(0 if status == 'passed' else 1)
