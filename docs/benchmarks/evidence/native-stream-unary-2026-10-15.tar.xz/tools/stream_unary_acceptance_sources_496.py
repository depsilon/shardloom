"""Bind evidence-only changes to the original accepted native build sources."""
import json
from pathlib import Path

from freeze_native_release_298 import ROOT, OUT, sources, sha
from stream_unary_acceptance_sources_495 import SOURCE, MANIFEST, DECLARATIONS, REFERENCE, identity

ACCEPTED_SOURCE = OUT / 'stream-unary-verification-source-496.json'
CHANGED = ['python/tests/test_native_unary_binding.py',
           'scripts/native_streaming_unary_composition_cases.py',
           'scripts/run_native_streaming_input_uat.py']
ADDED = ['python/tests/test_native_streaming_uat_compression.py']


def unchanged():
    frozen = json.loads(SOURCE.read_text())
    accepted = json.loads(ACCEPTED_SOURCE.read_text())
    assert accepted['status'] == 'frozen_for_verification'
    assert accepted['build_source'] == identity(SOURCE)
    assert accepted['artifacts'] == identity(MANIFEST)
    assert sources() == accepted['source_sha256'] and len(accepted['source_sha256']) == 2283
    prior, current = frozen['source_sha256'], accepted['source_sha256']
    assert sorted(name for name in prior if current.get(name) != prior[name]) == CHANGED
    assert sorted(set(current) - set(prior)) == ADDED
    assert accepted['changed_files'] == CHANGED and accepted['added_files'] == ADDED
    for row in accepted['transitions']:
        for key in ('before', 'after', 'diff'):
            assert identity(row[key]['path']) == row[key]
    declaration = json.loads(DECLARATIONS.read_text())
    assert accepted['original_declarations'] == identity(DECLARATIONS)
    assert sha(REFERENCE) == declaration['original_reference_sha256']
    assert accepted['extra_reference'] == identity(REFERENCE)
    assert all(sha(ROOT / name) == digest for name, digest in declaration['source_sha256'].items()
               if name not in CHANGED)
    for key in ('diagnosis', 'previous_source', 'composition_diagnosis'):
        assert identity(accepted[key]['path']) == accepted[key]
    assert json.loads(Path(accepted['diagnosis']['path']).read_text())['status'] == 'passed'
    diagnosis = json.loads(Path(accepted['composition_diagnosis']['path']).read_text())
    assert diagnosis['status'] == 'diagnosed_before_correction' and diagnosis['engine_executions'] == 0
    assert diagnosis['original_expected_values_unchanged']
    previous = json.loads(Path(accepted['previous_source']['path']).read_text())
    assert sorted(name for name in current if current[name] != previous['source_sha256'][name]) == [
        'scripts/native_streaming_unary_composition_cases.py']
    return accepted


def load():
    unchanged()
    frozen = json.loads(SOURCE.read_text())
    manifest = json.loads(MANIFEST.read_text())
    assert manifest['status'] == 'passed' and manifest['source_sha256'] == frozen['source_sha256']
    for key in ('cli', 'binding'):
        assert identity(manifest[key]['path']) == {k: manifest[key][k] for k in ('path', 'bytes', 'sha256')}
    return manifest
