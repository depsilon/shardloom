"""Rerun the complete focused matrix after one declaration-only correction."""
import json
import sys

from freeze_native_release_298 import ROOT, OUT, save
from run_query_timing_runtime_461 import guarded
from stream_unary_acceptance_sources_496 import (
    SOURCE, ACCEPTED_SOURCE, MANIFEST, DECLARATIONS, REFERENCE, identity, load, unchanged,
)

DIRECT = OUT / 'stream-unary-direct-tests-495.json'
HARNESS = OUT / 'stream-unary-harness-tests-495.json'
FOCUSED = OUT / 'stream-unary-public-focused-496'
FAMILIES = ['unary', 'unary-reference', 'unary-composition', 'unary-fault',
            'unary-pressure', 'input', 'dynamic']


def main():
    manifest = load()
    accepted = unchanged()
    checks_path = OUT / 'stream-unary-checks-494.json'
    checks = json.loads(checks_path.read_text())
    assert checks['status'] == 'passed' and checks['source_identity_preserved']
    assert len(checks['completed']) == 6
    for path, count in ((DIRECT, 91), (HARNESS, 5)):
        result = json.loads(path.read_text())
        assert result['status'] == 'passed' and result['tests'] == count
        assert result['failures'] == result['errors'] == result['skipped'] == 0
        assert result['artifact_manifest'] == identity(MANIFEST)
        assert result['accepted_source'] == accepted['previous_source']
    assert not FOCUSED.exists()
    declaration = json.loads(DECLARATIONS.read_text())
    protocol = dict(source=identity(SOURCE), accepted_source=identity(ACCEPTED_SOURCE),
        artifacts=identity(MANIFEST), checks=identity(checks_path), helper=identity(__file__),
        source_helper=identity(OUT / 'stream_unary_acceptance_sources_496.py'),
        declarations=identity(DECLARATIONS), reference_fixture=identity(REFERENCE),
        guard=identity(OUT / 'run_guarded.py'), focused_families=FAMILIES,
        planned_family_cases={row['family']: row['cases'] for row in declaration['families']},
        planned_new_public_cases=1480, direct_expected_methods=91, new_direct_subcases=468,
        direct=identity(DIRECT), harness=identity(HARNESS), binaries_rebuilt=False,
        failed_focused=identity(OUT / 'stream-unary-public-focused-495/summary.json'),
        compress_logs=True, broad_public_pending=True, full43_pending=True)
    save(OUT / 'stream-unary-runtime-protocol-496.json', protocol)
    print(json.dumps(dict(stage='focused-public', status='starting')), flush=True)
    guarded('stream-unary-public-focused-496', 5400,
        [sys.executable, '-B', ROOT / 'scripts/run_native_streaming_input_uat.py',
         '--binary', manifest['cli']['path'], '--uat-root', FOCUSED,
         '--operation-timeout', '600', '--compress-logs', '--families', *FAMILIES])
    summary = json.loads((FOCUSED / 'summary.json').read_text())
    assert summary['status'] == 'passed' and all(row['status'] == 'passed' for row in summary['cases'])
    assert summary['families'] == FAMILIES and summary['compress_logs']
    names = [row['name'] for row in summary['cases']]
    added = [name for family in declaration['families'] for name in family['names']]
    assert len(added) == len(set(added)) == 1480 and set(added).issubset(names)
    assert len(names) == len(set(names))
    assert load() == manifest
    save(OUT / 'stream-unary-runtime-focused-496.json', dict(status='passed', source=identity(SOURCE),
        accepted_source=identity(ACCEPTED_SOURCE), artifacts=identity(MANIFEST), direct=identity(DIRECT),
        harness=identity(HARNESS), focused_public=identity(FOCUSED / 'summary.json'),
        public_cases=len(names), new_public_cases=len(added),
        protocol=identity(OUT / 'stream-unary-runtime-protocol-496.json'),
        source_identity_preserved=True, compress_logs=True,
        broad_public_pending=True, full43_pending=True))
    print(json.dumps(dict(status='passed', focused_cases=len(names))), flush=True)


if __name__ == '__main__':
    main()
