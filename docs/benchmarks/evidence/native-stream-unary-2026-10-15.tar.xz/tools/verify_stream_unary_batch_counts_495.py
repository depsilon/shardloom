"""Compare unchanged columnar intake counts before correcting a new fixture."""
import json
import os
from pathlib import Path
import re
import sys
from unittest.mock import patch

from freeze_native_release_298 import ROOT, OUT, sha, save
from run_query_timing_runtime_461 import guarded, PYTHON_DEPS
from run_stream_unary_runtime_494 import unchanged

TEST = ROOT / 'python/tests/test_native_unary_binding.py'
ADAPTER = ROOT / 'shardloom-python/src/batch_input.rs'
PYTHON = OUT / 'selected-view-python-468/bin/python'
DEST = OUT / 'stream-unary-batch-count-diagnosis-495'
MANIFESTS = dict(old=OUT / 'native-release-artifacts-streamsets484.json',
                 candidate=OUT / 'native-release-artifacts-streamunary494.json')


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def control(label):
    manifest_path = MANIFESTS[label]
    manifest = json.loads(manifest_path.read_text())
    assert Path(sys.executable) == PYTHON
    for kind in ('cli', 'binding'):
        assert identity(manifest[kind]['path']) == {k: manifest[kind][k] for k in ('path', 'bytes', 'sha256')}
    assert sha(ADAPTER) == manifest['source_sha256'][str(ADAPTER.relative_to(ROOT))]
    os.environ['SHARDLOOM_NATIVE_TEST_LIBRARY'] = manifest['binding']['path']
    os.environ['SHARDLOOM_REQUIRE_NATIVE_PYTHON'] = '1'
    os.environ['SHARDLOOM_BIN'] = manifest['cli']['path']
    sys.path[:0] = [str(PYTHON_DEPS), str(ROOT / 'python/src'), str(ROOT / 'python/tests')]
    import pyarrow as pa
    import shardloom as sl
    import test_native_unary_binding as fixture
    fixture._load_native()
    results = []
    client = sl.ShardLoomClient(transport='native', memory_bytes=32 << 20, max_parallelism=1)
    try:
        for columnar in (False, True):
            for shape, rows, columnar_count in (
                ('mixed', fixture.ROWS, 3), ('empty', [], 0),
                ('nulls', [dict.fromkeys(fixture.SCHEMA)] * 3, 2),
            ):
                parts = ([], rows[:2], [], rows[2:5], rows[5:], [])
                exported = [batch for part in parts
                            for batch in pa.Table.from_pylist(part, schema=fixture.arrow_schema()).to_batches()]
                assert len(exported) == columnar_count
                with (
                    patch('subprocess.Popen', side_effect=AssertionError('child process')),
                    patch('shardloom._batches.BatchInput.encode', side_effect=AssertionError('JSON input')),
                ):
                    source, events = fixture.NativeUnaryBindingTests.source(client, rows, columnar)
                    report = source.select('n', 's', 'items').collect(check=True)
                actual = report.to_arrow()
                wanted = pa.Table.from_pylist(rows, schema=fixture.arrow_schema())
                assert actual.equals(wanted, check_metadata=True)
                assert events == ['opened', 'ended', 'closed']
                envelope = report.envelope
                count = envelope.field_int('native_input_batches')
                expected_count = columnar_count if columnar else 6
                assert count == expected_count
                assert envelope.field_int('native_input_batch_rows') == len(rows)
                assert envelope.field_int('native_input_batch_sources') == 1
                assert envelope.field_bool('native_input_end_observed')
                assert not envelope.fallback.attempted and not envelope.fallback.allowed
                assert envelope.field('external_engine_invoked') == 'false'
                save(DEST / f'{label}-{columnar}-{shape}-envelope.json', envelope.raw)
                results.append(dict(shape=shape, columnar=columnar, produced_python_values=6,
                    arrow_record_batches=columnar_count, native_input_batches=count,
                    native_input_rows=len(rows), complete_values_and_schema=True,
                    original_six_batch_assertion_would_pass=count == 6, events=events))
    finally:
        client.close()
    save(DEST / f'{label}.json', dict(status='passed', manifest=identity(manifest_path),
        adapter=identity(ADAPTER), unchanged_fixture=identity(TEST), cases=results,
        python=sys.version, pyarrow_version=pa.__version__, installed_wheel_proof=False))


def main():
    frozen = unchanged()
    assert not DEST.exists()
    DEST.mkdir()
    for path in (TEST, ADAPTER):
        with (DEST / path.name).open('xb') as stream:
            stream.write(path.read_bytes())
        assert sha(DEST / path.name) == sha(path)
    direct = json.loads((OUT / 'stream-unary-direct-tests-494.json').read_text())
    assert direct['status'] == 'failed' and direct['tests'] == 91
    assert direct['failures'] == 182 and direct['errors'] == direct['skipped'] == 0
    raw = (OUT / 'stream-unary-direct-494.log').read_text()
    errors = re.findall(r'^AssertionError: (.+)$', raw, re.M)
    assert len(errors) == 182 and set(errors) == {'3 != 6', '0 != 6', '2 != 6'}
    assert raw.count('line 136, in completed') == 182
    save(DEST / 'protocol.json', dict(status='predeclared', source_sha256=frozen['source_sha256'],
        helper=identity(__file__), original_test=identity(TEST), adapter=identity(ADAPTER),
        original_direct=identity(OUT / 'stream-unary-direct-tests-494.json'),
        original_log=identity(OUT / 'stream-unary-direct-494.log'),
        expected_failures=182, expected_columnar_counts={'mixed': 3, 'empty': 0, 'nulls': 2},
        expected_row_sequence_counts=6, operator='ordinary projection control; no unary admission needed',
        engine_sources_edited=False))
    for label in MANIFESTS:
        guarded('stream-unary-batch-count-' + label + '-495', 300,
                [PYTHON, '-B', __file__, label])
    old = json.loads((DEST / 'old.json').read_text())
    candidate = json.loads((DEST / 'candidate.json').read_text())
    assert old['cases'] == candidate['cases'] and len(old['cases']) == 6
    assert unchanged() == frozen
    save(DEST / 'summary.json', dict(status='passed', helper=identity(__file__),
        old=identity(DEST / 'old.json'), candidate=identity(DEST / 'candidate.json'),
        original_fixture_preserved=identity(DEST / TEST.name),
        matching_controls=6, matching_adapters=old['adapter'] == candidate['adapter'],
        original_failure_preserved=True, runtime_changed=False,
        correction='Use exact native record-batch counts for each declared input representation; also assert complete input row counts.'))
    print(json.dumps(dict(status='passed', controls_per_binding=6, exact_counts_equal=True)), flush=True)


if __name__ == '__main__':
    control(sys.argv[1]) if len(sys.argv) == 2 else main()
