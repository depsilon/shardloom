"""Bind the primary inspection to the worker's complete fixture verification."""
import json
from pathlib import Path

from freeze_native_release_298 import ROOT, OUT, save, sha


def main():
    path = OUT / 'stream-unary-reference-inspection-486.json'
    report = json.loads(path.read_text())
    assert report['status'] == 'COMPLETE' and report['failures'] == []
    assert len(report['checks']) == 10 and all(row['passed'] for row in report['checks'])
    assert sha(report['checker_path']) == report['checker_sha256'] == '972ea2de89ec6ec97b283ad0d3a6b5a36d14770aa1b0509fd7e516e9550f5e3e'
    inputs = report['inputs']
    assert sha(inputs['helper_input_path']) == inputs['helper_input_sha256']
    assert sha(inputs['fixture_input_path']) == inputs['fixture_input_sha256']
    fixture = json.loads(Path(inputs['fixture_input_path']).read_text())
    assert fixture['helper_sha256'] == inputs['helper_input_sha256']
    assert len(inputs['source_files']) == len(fixture['source_sha256']) == 5
    for item in inputs['source_files']:
        assert sha(ROOT / item['path']) == item['actual_sha256'] == item['fixture_sha256'] == fixture['source_sha256'][item['path']]
    reference = inputs['reference_test']
    test_source = ROOT / reference['path']
    assert sha(test_source) == reference['sha256']
    first, last = reference['line_range_one_based']
    assert '\n'.join(test_source.read_text().splitlines()[first - 1:last]) == reference['complete_source']
    assert first == 192 and last == 225 and reference['complete_source'].startswith('#[test]\nfn ' + reference['name'])
    assert report['sampling']['fixture_case_count'] == 54 and report['rolling']['fixture_case_count'] == 120
    assert report['sampling']['existing_test_six_choices']['expected'] == report['sampling']['existing_test_six_choices']['actual']
    save(OUT / 'stream-unary-reference-primary-acceptance-486.json', dict(
        status='accepted_fixture_verification_only', report_path=str(path), report_sha256=sha(path),
        checker_path=report['checker_path'], checker_sha256=report['checker_sha256'],
        helper_sha256=sha(__file__), complete_checker_read=True,
        source_identities_and_full_test_excerpt_reopened=True,
        existing_test_literal_vectors_primary_checked=True,
        sampling_cases=54, rolling_cases=120, engine_executions=0,
        limitations='No streaming unary runtime change or runtime acceptance is claimed.'))
    print(json.dumps(dict(status='accepted_fixture_verification_only', sampling_cases=54, rolling_cases=120)))


if __name__ == '__main__':
    main()
