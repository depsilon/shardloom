"""Draft a conservative evidence packager for the frozen unary candidate.

This helper is not an acceptance decision and is intentionally not run while
acceptance is pending. It refuses to package until every required final gate,
receipt, source identity, fixture, and result has been reopened successfully.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile

O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
REPO = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
UAT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
BASE = 'e859b3a8b9d323587cee9641f5ebacd21e7e799c'
PREFIX = 'native-stream-unary-2026-10-15'
LOCAL = O / 'stream-unary-packet-495'
DEST = REPO / 'docs/benchmarks/evidence'
SOURCE = O / 'native-release-source-streamunary494.json'
ARTIFACTS = O / 'native-release-artifacts-streamunary494.json'
DECLARATIONS = O / 'stream-unary-candidate-declarations-493b/declarations.json'
REFERENCE = REPO / 'scripts/native_streaming_unary_reference_fixtures.json'
CHECKS = O / 'stream-unary-checks-494.json'
CHECK_PROTOCOL = O / 'stream-unary-check-protocol-494.json'
RUNTIME_PROTOCOL = O / 'stream-unary-runtime-protocol-494.json'
FOCUSED = O / 'stream-unary-runtime-focused-494.json'
DIRECT = O / 'stream-unary-direct-tests-494.json'
CASE_PROTOCOL = O / 'stream-unary-public-case-protocol-494.json'
PUBLIC_PROTOCOL = O / 'stream-unary-public-protocol-494.json'
RUNTIME = O / 'stream-unary-runtime-494.json'
PUBLIC_REVIEW = O / 'stream-unary-public-inspection-494.json'
FULL_REVIEW = O / 'stream-unary-full43-review-494.json'
BASELINE = O / 'stream-unary-baseline-487/summary.json'
BASELINE_RUN = O / 'stream-unary-baseline-run-487.json'
DENIAL_REFRESH = O / 'stream-unary-denial-refresh-primary-494.json'
HELPER = Path(__file__).resolve()
ARCHIVE = LOCAL / (PREFIX + '.tar.xz')
MANIFEST = LOCAL / (PREFIX + '.manifest.json.xz')
VERIFICATION = LOCAL / 'verification.json'
MAX_RAW_BYTES = 256 * 1024 * 1024
CHUNK = 4 * 1024 * 1024
GIB = 1024 ** 3
MIB = 1024 ** 2

sys.path.insert(0, str(REPO / 'scripts'))
sys.path.insert(0, str(O))
from freeze_native_release_298 import sha, sources  # noqa: E402
from package_selection_acceptance_409 import (  # noqa: E402
    Members, excluded_identity, sha_stream, verify,
)
from local_uat_storage import check_budgets, require_local_path  # noqa: E402
from native_workflow_protocol import strict_json  # noqa: E402


class NeedsReasoning(ValueError):
    """A missing or inconsistent acceptance input requires human review."""


def need(test: bool, message: str) -> None:
    if not test:
        raise NeedsReasoning(message)


def bound(path: Path) -> dict:
    path = Path(path)
    size, digest = verify(path)
    return dict(path=str(path), bytes=size, sha256=digest)


def read(path: Path):
    need(Path(path).is_file(), f'required acceptance input is missing: {path}')
    return strict_json(Path(path).read_text())


def completed(name: str, *, expected_head: str | None = None) -> dict:
    path = O / (name + '.json')
    receipt = read(path)
    need(receipt.get('status') == 'passed' and receipt.get('returncode') == 0,
         f'{name} must have a passing zero-exit receipt')
    need(receipt.get('process_group_drained') is True and receipt.get('direct_child_reaped') is True,
         f'{name} must prove child cleanup')
    need(receipt.get('timed_out') is False and
         receipt.get('group_absence_unproved_at_cleanup') is False,
         f'{name} must prove it completed without timeout or uncertain cleanup')
    if expected_head is not None:
        need(receipt.get('head') == expected_head, f'{name} receipt is bound to another revision')
    log = path.with_suffix('.log')
    need(sha(log) == receipt.get('log_sha256'), f'{name} log hash does not match its receipt')
    return receipt


def add_file(members: Members, path: Path, name: str, root: Path,
             role: str, expected_sha: str | None = None) -> None:
    members.add(path, name, root.name, root, role, expected_sha)


def add_tree(members: Members, path: Path, prefix: str, role: str,
             exclusions: list[dict], *, omit_outputs: bool = False) -> None:
    members.tree(path, prefix, prefix, role, exclusions, omit_outputs=omit_outputs)


def main() -> None:
    need(not LOCAL.exists(), f'local staging already exists; inspect before reuse: {LOCAL}')
    need(not (DEST / (PREFIX + '.json')).exists(), 'evidence index already exists')
    need(not (DEST / (PREFIX + '.tar.xz')).exists(), 'evidence archive already exists')
    need(not (DEST / (PREFIX + '.manifest.json.xz')).exists(), 'evidence manifest already exists')

    frozen = read(SOURCE)
    declaration = read(DECLARATIONS)
    need(frozen.get('head') == BASE and len(frozen.get('source_sha256', {})) == 2282,
         'frozen source manifest must be the declared e859b3a unary snapshot with 2,282 files')
    need(declaration.get('status') == 'passed' and declaration.get('engine_executions') == 0,
         'predeclared unary candidate declarations must pass without engine execution')
    need(declaration.get('public_cases') == 1480,
         'predeclared unary public case count must remain 1,480')
    need(sources() == frozen['source_sha256'],
         'current selected source map differs from the exact frozen unary source map')
    need(sha(REFERENCE) == declaration.get('original_reference_sha256'),
         'extra unary reference fixture hash differs from its declaration')
    need(all(sha(REPO / name) == digest for name, digest in declaration['source_sha256'].items()),
         'candidate declaration source snapshots changed')

    checks = read(CHECKS)
    check_protocol = read(CHECK_PROTOCOL)
    need(checks.get('status') == 'passed' and checks.get('source_identity_preserved') is True,
         'all six Rust gates must have passed with frozen sources preserved')
    need(check_protocol.get('source_manifest_sha256') == sha(SOURCE),
         'Rust check protocol does not bind the frozen source manifest')
    expected_stages = ['fmt', 'workspace-clippy', 'workspace-tests', 'read-clippy',
                       'release-clippy', 'native-tests']
    rows = checks.get('completed', [])
    need([row.get('stage') for row in rows] == expected_stages,
         'the six required Rust gates are incomplete or out of protocol order')
    for row in rows:
        receipt = Path(row['receipt'])
        log = Path(row['log'])
        need(sha(receipt) == row.get('receipt_sha256') and sha(log) == row.get('log_sha256'),
             f'Rust gate evidence hash mismatch: {row.get("stage")}')
        value = read(receipt)
        need(value.get('status') == 'passed' and value.get('returncode') == 0 and
             value.get('process_group_drained') is True and value.get('direct_child_reaped') is True and
             value.get('timed_out') is False and value.get('group_absence_unproved_at_cleanup') is False,
             f'Rust gate receipt is incomplete: {row.get("stage")}')
        need(value.get('head') == BASE, f'Rust gate ran against a different revision: {row.get("stage")}')
    test_counts = {row['stage']: row['tests'] for row in rows if 'tests' in row}
    need(test_counts['workspace-tests']['passed'] == 3219 and
         test_counts['workspace-tests']['ignored'] == 0,
         'workspace test count must be exactly 3,219 passed and zero ignored')
    need(test_counts['native-tests']['passed'] == 4249 and
         test_counts['native-tests']['ignored'] == 29,
         'native test count must be exactly 4,249 passed and 29 declared manual/platform ignores')
    need(len(check_protocol.get('new_native_tests', [])) == 8,
         'check protocol must enumerate exactly eight new unary Rust tests')
    need(check_protocol.get('expected_ignored') and
         len(check_protocol['expected_ignored']) == 29,
         'native ignored declarations must retain all 26 manual plus three platform cases')
    ignored = test_counts['native-tests']['ignored_declarations']
    need(sorted(map(tuple, ignored)) == sorted(map(tuple, check_protocol['expected_ignored'])) and
         sum(str(reason).startswith('requires the non-Unix runtime branch;')
             for _, reason in ignored) == 3,
         'native ignored declarations must exactly match the prior list, including three platform cases')
    prior_checks = O / 'stream-sets-checks-484.json'
    prior_checks_value = read(prior_checks)
    need(sha(prior_checks) == check_protocol.get('prior_checks_sha256') and
         prior_checks_value.get('status') == 'passed' and
         prior_checks_value.get('source_identity_preserved') is True,
         'minimal prior set-gate identity must match the unary check protocol')
    prior_counts = {row['stage']: row['tests'] for row in prior_checks_value.get('completed', [])
                    if 'tests' in row}
    need(prior_counts.get('workspace-tests', {}).get('passed') == 3219 and
         prior_counts.get('native-tests', {}).get('passed') == 4241 and
         prior_counts.get('native-tests', {}).get('ignored') == 29,
         'prior acceptance must show 3,219 workspace and 4,241 native tests with 29 ignores')
    native_log = Path(next(row['log'] for row in rows if row['stage'] == 'native-tests')).read_text()
    for name in check_protocol['new_native_tests']:
        need(re.search(r'^test .*::' + re.escape(name) + r' \.\.\. ok$', native_log, re.M) is not None,
             f'new native test did not pass: {name}')

    runtime_protocol = read(RUNTIME_PROTOCOL)
    focused = read(FOCUSED)
    direct = read(DIRECT)
    public_protocol = read(PUBLIC_PROTOCOL)
    case_protocol = read(CASE_PROTOCOL)
    runtime = read(RUNTIME)
    public_review = read(PUBLIC_REVIEW)
    full_review = read(FULL_REVIEW)
    need(runtime.get('status') == 'passed' and runtime.get('public_cases') == 2601 and
         len(runtime.get('public_families', [])) == 27,
         'broad public acceptance must pass all 2,601 cases in 27 families')
    need(direct.get('status') == 'passed' and direct.get('tests') == 91 and
         direct.get('failures') == 0 and direct.get('errors') == 0 and direct.get('skipped') == 0,
         'direct Python binding acceptance must pass 91 methods without skips')
    need(len(direct.get('test_names', [])) == 91 and
         len(direct.get('prior_test_names', [])) == 87 and
         len(direct.get('new_test_names', [])) == 4,
         'direct binding receipt must preserve the 87 prior and four new method identities')
    need(len(direct.get('new_test_names', [])) == 4 and direct.get('predeclared_subcases') == 468,
         'direct unary proof must show four new methods and 468 declared subcases')
    need(focused.get('status') == 'passed' and focused.get('source_identity_preserved') is True and
         focused.get('new_public_cases') == 1480,
         'focused unary public families must pass the full 1,480 declared cases')
    need(runtime_protocol.get('focused_families') ==
         ['unary', 'unary-reference', 'unary-composition', 'unary-fault',
          'unary-pressure', 'input', 'dynamic'] and
         sum(runtime_protocol.get('planned_family_cases', {}).values()) == 1480,
         'focused acceptance must bind the seven declared families and derive their exact count')
    need(public_protocol.get('cases') == 2601 and public_protocol.get('direct_methods') == 91 and
         public_protocol.get('native_unary_state_spill') is False,
         'public protocol must preserve the complete case count and resident unary state boundary')
    need(case_protocol.get('expected_cases') == 2601 and
         len(case_protocol.get('expected_public_names', [])) == 2601 and
         len(case_protocol.get('expected_public_families', [])) == 27,
         'predeclared public protocol must contain the exact complete case/family lists')
    original_public = case_protocol.get('original_public')
    need(isinstance(original_public, dict) and
         bound(Path(original_public['path'])) == original_public,
         'public case protocol must retain the prior public summary identity')
    prior_direct = O / 'stream-sets-direct-tests-484.json'
    prior_direct_value = read(prior_direct)
    need(direct.get('prior_test_names') == prior_direct_value.get('test_names') and
         len(prior_direct_value.get('test_names', [])) == 87,
         'direct binding protocol must extend the exact prior 87 method identities')
    need(public_review.get('status') == 'passed' and
         public_review.get('cases') == 2601 and public_review.get('families') == 27 and
         public_review.get('complete_case_log_records_equal') is True and
         public_review.get('frozen_sources_and_binary_unchanged') is True,
         'independent public evidence reopening must pass')
    need(full_review.get('status') == 'passed' and full_review.get('queries') == 43 and
         full_review.get('calls') == 43 and full_review.get('repeats') == 1 and
         full_review.get('all_values_schemas_and_clocks_reopened') is True and
         full_review.get('original_input_and_sources_unchanged') is True and
         full_review.get('performance_claim_allowed') is False,
         'Full43 review must prove one complete pass without a performance claim')
    need(runtime.get('manifest_sha256') == sha(ARTIFACTS),
         'runtime receipt is not bound to the frozen artifact manifest')
    artifact_manifest = read(ARTIFACTS)
    need(artifact_manifest.get('status') == 'passed' and
         artifact_manifest.get('source_sha256') == frozen['source_sha256'] and
         artifact_manifest.get('head') == BASE,
         'release artifacts must be built from the exact frozen source map and base revision')

    # Reopen every final supervised process receipt, including all six Rust gates.
    receipt_names = [f'stream-unary-{stage}-494' for stage in expected_stages]
    receipt_names += ['native-final-cli-release-build-streamunary494',
                      'native-final-python-release-build-streamunary494',
                      'stream-unary-direct-494', 'stream-unary-public-focused-494',
                      'stream-unary-public-494', 'stream-unary-full43-494']
    final_receipts = {name: completed(name, expected_head=BASE) for name in receipt_names}
    baseline_run = read(BASELINE_RUN)
    need(baseline_run.get('status') == 'passed' and
         baseline_run.get('process_group_drained') is True and
         baseline_run.get('direct_child_reaped') is True,
         'baseline runner receipt must prove successful completion and child cleanup')
    baseline_log = BASELINE_RUN.with_suffix('.log')
    need(sha(baseline_log) == baseline_run.get('log_sha256'),
         'baseline runner log hash does not match its receipt')
    baseline = read(BASELINE)
    need(baseline.get('status') == 'passed' and len(baseline.get('cases', [])) == 18 and
         sum(row.get('outcome') == 'static_streaming_refusal' for row in baseline['cases']) == 9 and
         sum(row.get('outcome') == 'resident_control_passed' for row in baseline['cases']) == 9 and
         all(row.get('status') == 'passed' for row in baseline['cases']),
         'old unary baseline must show nine streaming refusals and nine resident controls')
    for path in sorted((BASELINE.parent / 'logs').glob('*-values.json')):
        value = read(path)
        need(value.get('actual') == value.get('expected'),
             f'baseline value reference mismatch: {path.name}')

    need(full_review['reference_kind'] == 'retained_native_regression' and
         full_review.get('no_new_ingest') is True,
         'Full43 must use the retained reference and pre-existing resident input')
    admission = read(Path(full_review['admission']['path']))
    need(admission.get('status') == 'passed' and admission.get('no_new_ingest') is True and
         admission.get('source_resident_before_read') is True,
         'Full43 admission must prove the resident input and no-ingest boundary')
    for item in full_review['companions'] + full_review['envelopes'] + [
            full_review['summary'], full_review['timing_csv'], full_review['receipt'],
            admission['input'], admission['reference'], admission['queries'],
            *admission['harness'], *admission['schema_sources']]:
        verify(Path(item['path']), item.get('sha256'), item.get('bytes'))

    # Freeze exact current selected sources and the separately declared fixture.
    need(sources() == frozen['source_sha256'] and sha(REFERENCE) == declaration['original_reference_sha256'],
         'selected sources or the extra reference fixture changed during evidence admission')
    dirty = subprocess.check_output(['git', 'diff', '--name-only'], cwd=REPO, text=True).splitlines()
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=REPO, text=True).splitlines()
    overlay = sorted(set(dirty + untracked) & set(frozen['source_sha256']))

    members, exclusions = Members(), []
    def add(path: Path, archive_name: str, role: str,
            expected_sha: str | None = None, root: Path | None = None) -> None:
        root = root or (REPO if Path(path).is_relative_to(REPO) else O)
        members.add(path, archive_name, root.name, root, role, expected_sha)

    # Exact frozen selected-source overlays are included alongside their manifest.
    for name in overlay:
        add(REPO / name, 'source-overlay/' + name, 'frozen selected source overlay',
            frozen['source_sha256'][name], REPO)
    add(REFERENCE, 'source-overlay/scripts/native_streaming_unary_reference_fixtures.json',
        'explicitly declared extra reference fixture outside selected source map',
        declaration['original_reference_sha256'], REPO)
    add(SOURCE, 'manifests/' + SOURCE.name, 'frozen current source manifest')
    add(ARTIFACTS, 'manifests/' + ARTIFACTS.name, 'frozen release artifact manifest')
    add(DECLARATIONS, 'manifests/unary-candidate-declarations.json', 'predeclared candidate cases and fixture identities')
    for path in (CHECKS, CHECK_PROTOCOL, RUNTIME_PROTOCOL, FOCUSED, DIRECT,
                 CASE_PROTOCOL, PUBLIC_PROTOCOL, RUNTIME, PUBLIC_REVIEW, FULL_REVIEW,
                 BASELINE, BASELINE_RUN, DENIAL_REFRESH):
        add(path, 'receipts/' + path.relative_to(O).as_posix(), 'final acceptance receipt or independent review')
    add(baseline_log, 'receipts/' + baseline_log.name, 'complete baseline supervisor log')
    for path in [O / (name + '.json') for name in receipt_names]:
        add(path, 'receipts/' + path.name, 'final supervised process receipt')
        add(path.with_suffix('.log'), 'receipts/' + path.with_suffix('.log').name,
            'complete supervised process log')

    # Preserve earlier failures and the exact predeclared sampling/rolling references.
    for name in ('stream-unary-clippy-focused-493.json', 'stream-unary-clippy-focused-493.log',
                 'stream-unary-check-preflight-494.json',
                 'stream-unary-candidate-declarations-493/failure.json',
                 'stream-unary-candidate-declarations-493/original-helper.py'):
        add(O / name, 'prior-failures/' + name, 'retained failed or preflight evidence')
    for folder, archive_prefix, role in (
            (O / 'stream-unary-candidate-declarations-493b', 'predeclared-reference',
             'accepted predeclared unary/sampling/rolling expectation evidence'),
            (O / 'stream-unary-candidate-declarations-493', 'first-declaration-failure',
             'initial missing-dependency declaration failure'),
            (O / 'stream-unary-denial-refresh-494', 'denial-refresh',
             'current source-surface inventory and proposal record')):
        add_tree(members, folder, archive_prefix, role, exclusions, omit_outputs=True)
    for path in (O / 'stream-unary-reference-inspection-486.json',
                 O / 'stream-unary-reference-primary-acceptance-486.json'):
        add(path, 'reference-acceptance/' + path.name,
            'complete predeclared reference fixture acceptance')
    reference_inspection = read(O / 'stream-unary-reference-inspection-486.json')
    reference_acceptance = read(O / 'stream-unary-reference-primary-acceptance-486.json')
    need(reference_inspection.get('status') == 'COMPLETE' and
         reference_inspection.get('failures') == [] and
         reference_inspection.get('sampling', {}).get('fixture_case_count') == 54 and
         reference_inspection.get('rolling', {}).get('fixture_case_count') == 120 and
         reference_acceptance.get('status') == 'accepted_fixture_verification_only' and
         reference_acceptance.get('complete_checker_read') is True and
         reference_acceptance.get('source_identities_and_full_test_excerpt_reopened') is True,
         'predeclared sampling/rolling fixture review and reference acceptance must both pass')
    checker = Path(reference_inspection['checker_path'])
    add(checker, 'reference-acceptance/' + checker.name,
        'fixture checker source used by the accepted reference inspection',
        reference_inspection['checker_sha256'], O)
    add(Path(reference_inspection['inputs']['fixture_input_path']),
        'reference-acceptance/' + Path(reference_inspection['inputs']['fixture_input_path']).name,
        'predeclared sampling and rolling reference fixture',
        reference_inspection['inputs']['fixture_input_sha256'], O)

    # Include the old control packet and only compact, relevant prior gate identity.
    add_tree(members, BASELINE.parent, 'baseline', 'old streaming-refusal/resident-control proof',
             exclusions, omit_outputs=True)
    add(prior_direct, 'prior-identities/stream-sets-direct-tests-484.json',
        'minimal prior direct-method names and count used by the unary binding proof')

    # Include all reproduction helpers and their local imported dependencies.
    helper_names = (
        'draft_package_stream_unary_495.py', 'run_stream_unary_checks_494.py',
        'run_stream_unary_runtime_494.py', 'run_stream_unary_public_494.py',
        'verify_stream_unary_public_494.py', 'run_stream_unary_full43_494.py',
        'verify_stream_unary_baseline_487.py',
        'accept_stream_unary_reference_fixtures_486.py',
        'check_stream_unary_reference_fixtures_486.py', 'draft_stream_unary_references_486.py',
        'accept_stream_unary_refusal_inventory_487.py', 'accept_stream_unary_denial_refresh_494.py',
        'freeze_native_release_298.py', 'run_guarded.py', 'run_query_timing_runtime_461.py',
        'run_compression_full43_457.py', 'run_stream_destination_review_checks_479.py',
        'package_selection_acceptance_409.py', 'local_uat_storage.py',
        'native_workflow_protocol.py', 'clickbench_reference_packet.py',
        'query_timing_report.py', 'run_clickbench_query_uat.py',
        'run_native_streaming_input_uat.py', 'native_streaming_input_cases.py',
        'native_input_growth_cases.py', 'native_typed_input_cases.py', 'native_typed_input_fixtures.py',
        'native_streaming_order_cases.py', 'native_streaming_order_pressure_cases.py',
        'native_streaming_aggregate_cases.py', 'native_streaming_aggregate_pressure_cases.py',
        'native_streaming_join_cases.py', 'native_streaming_join_pressure_cases.py',
        'native_streaming_window_cases.py', 'native_streaming_window_pressure_cases.py',
        'native_streaming_protocol_cases.py', 'native_batch_preparation_cases.py',
        'native_streaming_multiple_cases.py', 'native_streaming_multiple_pressure_cases.py',
        'native_streaming_dynamic_cases.py', 'native_streaming_dynamic_pressure_cases.py',
        'native_streaming_replay_cases.py', 'native_streaming_replay_pressure_cases.py',
        'native_streaming_destination_cases.py', 'native_streaming_set_cases.py',
        'native_streaming_set_pressure_cases.py', 'native_streaming_order_pressure_cases.py',
        'native_streaming_unary_cases.py', 'native_streaming_unary_reference_cases.py',
        'native_streaming_unary_composition_cases.py', 'native_streaming_unary_fault_cases.py',
        'native_streaming_unary_pressure_cases.py', 'native_unary_reference.py',
        'native_workflow_outputs.py',
        'stream_set_acceptance_sources_487.py', 'verify_stream_unary_public_494.py',
    )
    for name in sorted(set(helper_names)):
        path = (REPO / 'scripts' / name) if (REPO / 'scripts' / name).is_file() else O / name
        need(path.is_file(), f'required executed helper or imported reproduction dependency is missing: {path}')
        add(path, 'tools/' + name, 'executed helper or imported local reproduction dependency')
    for name in ('native-release-source-streamsets484.json', 'stream-unary-candidate-declarations-493b/declarations.json'):
        path = O / name
        if path.exists():
            add(path, 'prior-identities/' + Path(name).name,
                'minimum prior or declaration identity used by unary acceptance')

    # Capture compact public receipts and Full43 query evidence; exclude bulk payloads.
    public_root = O / 'stream-unary-public-494'
    add_tree(members, public_root, 'public', 'complete public case logs and compact result evidence',
             exclusions, omit_outputs=True)
    focused_root = O / 'stream-unary-public-focused-494'
    add_tree(members, focused_root, 'focused-public', 'focused family logs and compact result evidence',
             exclusions, omit_outputs=True)
    full_summary = Path(full_review['summary']['path'])
    add_tree(members, full_summary.parent, 'full43', 'complete single-pass Full43 native query evidence',
             exclusions, omit_outputs=True)

    # Binary executables and large resident input/output artifacts remain explicit exclusions.
    for key in ('cli', 'binding'):
        artifact = artifact_manifest[key]
        verify(Path(artifact['path']), artifact['sha256'], artifact['bytes'])
        exclusions.append(dict(archive_path='frozen-artifacts/' + Path(artifact['path']).name,
            original_absolute_path=artifact['path'], byte_count=artifact['bytes'],
            sha256=artifact['sha256'], reason='frozen native executable excluded'))
        for field in ('build_receipt', 'build_log'):
            add(Path(artifact[field]), 'build-evidence/' + Path(artifact[field]).name,
                'frozen native build receipt/log')
    exclusions.append(dict(archive_path='resident-input/' + Path(admission['input']['path']).name,
        original_absolute_path=admission['input']['path'], byte_count=admission['input']['bytes'],
        sha256=admission['input']['sha256'], reason='large resident input excluded; full hash retained'))
    for folder in (public_root / 'outputs', focused_root / 'outputs', full_summary.parent / 'outputs'):
        if folder.exists():
            # Members.tree already records omitted output trees; keep a clear typed exclusion too.
            exclusions.extend([])

    require_local_path(LOCAL, Path.home(), sys.platform)
    ordered = sorted(members.paths.values(), key=lambda item: item.name)
    raw_size = sum(item.size for item in ordered)
    need(raw_size <= MAX_RAW_BYTES,
         f'complete unary evidence is {raw_size} raw bytes, above the unchanged {MAX_RAW_BYTES} byte '
         'single-archive ceiling; preserve all logs and have the primary consider multiple bounded archive parts')
    storage = check_budgets(O, LOCAL, O / 'logs', min_free_bytes=12 * GIB,
        reserve_bytes=raw_size + 64 * MIB, max_workspace_bytes=100 * GIB,
        max_log_bytes=192 * MIB)
    LOCAL.mkdir()
    with ARCHIVE.open('xb') as target:
        with tarfile.open(fileobj=target, mode='w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
            for item in ordered:
                verify(item.path, item.digest, item.size)
                info = tarfile.TarInfo(item.name)
                info.size, info.mode, info.mtime = item.size, 0o644, 0
                with item.path.open('rb') as source_stream:
                    archive.addfile(info, source_stream)
    seen = set()
    with tarfile.open(ARCHIVE, mode='r|xz') as archive:
        for entry in archive:
            need(entry.isfile() and entry.name in members.names and entry.name not in seen,
                 f'archive member missing, duplicate, or unexpected: {entry.name}')
            item = members.paths[members.names[entry.name]]
            with archive.extractfile(entry) as stream:
                need(sha_stream(stream) == (item.size, item.digest),
                     f'archive member bytes do not match source: {entry.name}')
            seen.add(entry.name)
    need(seen == set(members.names), 'not every declared evidence member reopened from the archive')
    for item in ordered:
        verify(item.path, item.digest, item.size)
    need(sources() == frozen['source_sha256'] and sha(REFERENCE) == declaration['original_reference_sha256'],
         'selected sources or extra reference fixture changed during packaging')

    acceptance = dict(workspace_tests=3219, workspace_ignored=0, prior_native_tests=4241,
        native_tests=4249, native_ignored=29, native_manual_ignored=26,
        native_platform_ignored=3, new_native_tests=8, direct_methods=91,
        direct_skips=0, new_direct_methods=4, new_direct_subcases=468,
        focused_new_public_cases=1480, public_cases=2601, public_families=27,
        full43_queries=43, full43_calls=43, full43_repeats=1,
        baseline_controls=18, baseline_streaming_refusals=9, baseline_resident_controls=9)
    limitations = ('Local finite unary workflow acceptance only. Unary operator state remains resident; '
        'source/result replay spill is a separate mechanism. No matched performance gain, package release, '
        'hosted integration, all-platform acceptance, process-wide memory ceiling, or zero-copy claim is made.')
    manifest = dict(status='passed_local_evidence_packaged', base_commit=BASE,
        source_files=len(frozen['source_sha256']), source_manifest=bound(SOURCE),
        artifact_manifest=bound(ARTIFACTS), extra_reference_fixture=bound(REFERENCE),
        source_overlay=overlay, members=[dict(path=str(item.path), archive_path=item.name,
            bytes=item.size, sha256=item.digest, roles=item.roles) for item in ordered],
        member_count=len(ordered), raw_bytes=raw_size, all_members_reopened=True,
        storage=storage, exclusions=exclusions, acceptance=acceptance,
        final_receipts={name: bound(O / (name + '.json')) for name in receipt_names},
        prior_baseline=bound(BASELINE), prior_baseline_run=bound(BASELINE_RUN),
        prior_sets_gate=dict(path=str(prior_checks), sha256=sha(prior_checks),
            workspace_tests=prior_counts['workspace-tests']['passed'],
            native_tests=prior_counts['native-tests']['passed'],
            native_ignored=prior_counts['native-tests']['ignored']),
        prior_public_identity=original_public, prior_direct_identity=bound(prior_direct),
        earlier_clippy_failure=bound(O / 'stream-unary-clippy-focused-493.json'),
        initial_preflight_failure=bound(O / 'stream-unary-check-preflight-494.json'),
        initial_declaration_failure=bound(O / 'stream-unary-candidate-declarations-493/failure.json'),
        unary_state_spill=False, source_identity_preserved=True,
        reference_fixture_outside_selected_source_map=True,
        publication_attempted=False, limitations=limitations)
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    packed = __import__('lzma').compress(manifest_bytes, preset=6)
    need(__import__('lzma').decompress(packed) == manifest_bytes, 'manifest compression round trip failed')
    with MANIFEST.open('xb') as stream:
        stream.write(packed)
    index = dict(schema_version='shardloom.native_stream_unary_evidence.v1',
        status='packaged_local_pending_acceptance_decision', base_commit=BASE,
        source_files=len(frozen['source_sha256']), member_count=len(seen), all_members_reopened=True,
        raw_bytes=raw_size, acceptance=acceptance, source_overlay=overlay,
        archive=dict(file=ARCHIVE.name, bytes=ARCHIVE.stat().st_size, sha256=sha(ARCHIVE)),
        manifest=dict(file=MANIFEST.name, bytes=MANIFEST.stat().st_size, sha256=sha(MANIFEST),
            raw_sha256=hashlib.sha256(manifest_bytes).hexdigest()),
        source_manifest=manifest['source_manifest'], extra_reference_fixture=manifest['extra_reference_fixture'],
        publication_attempted=False, limitations=limitations)
    for path in (ARCHIVE, MANIFEST):
        target = DEST / path.name
        with target.open('xb') as stream:
            stream.write(path.read_bytes())
        need(sha(target) == sha(path), f'copied evidence differs: {target}')
    (DEST / (PREFIX + '.json')).write_text(json.dumps(index, indent=2, sort_keys=True) + '\n')
    (LOCAL / 'verification.json').write_text(json.dumps(dict(status='all_members_reopened',
        member_count=len(seen), all_members_reopened=True, helper=bound(HELPER),
        archive=bound(ARCHIVE), manifest=bound(MANIFEST), index=bound(DEST / (PREFIX + '.json'))),
        indent=2, sort_keys=True) + '\n')
    print(json.dumps(dict(status='packaged_local_pending_acceptance_decision',
        members=len(seen), raw_bytes=raw_size, archive=str(DEST / (PREFIX + '.tar.xz')))))


if __name__ == '__main__':
    main()
