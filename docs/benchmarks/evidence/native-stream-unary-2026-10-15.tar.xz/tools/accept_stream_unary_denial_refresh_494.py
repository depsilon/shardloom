"""Independently check the complete worker inventory against exact source bytes."""
import json
from pathlib import Path
import subprocess

from freeze_native_release_298 import ROOT, OUT, sha, save

PACKET = OUT / 'stream-unary-denial-refresh-494'
REPORT = PACKET / 'stream-unary-denial-refresh-494.json'
PRIOR = OUT / 'stream-unary-denial-inventory-493/stream-unary-denial-inventory-493.json'
POST_REFRESH_EDITS = {
    'docs/reference/shardloom-user-surface-index.md',
    'website-src/scripts/sync-content.mjs',
    'docs/release/v1-inclusion-scope-matrix.md',
}


def digest(data):
    import hashlib
    return hashlib.sha256(data).hexdigest()


def snapshot(name, expected):
    data = (ROOT / name).read_bytes()
    if digest(data) == expected:
        return data, 'current_worktree'
    assert name in POST_REFRESH_EDITS, name
    data = subprocess.check_output(['git', 'show', 'HEAD:' + name], cwd=ROOT)
    assert digest(data) == expected, name
    return data, 'immutable_HEAD_before_primary_set_hosted_closure_edit'


def excerpt(data, start, end, numbered=False):
    lines = data.decode().splitlines()[start - 1:end]
    assert len(lines) == end - start + 1
    return '\n'.join(f'{index}: {line}' if numbered else line
                     for index, line in enumerate(lines, start))


def main():
    assert sha(REPORT) == '5c10aaefa118ebdb3c46c67721be0ed5e203916ddd2895142966c75e349c46a3'
    assert sha(PACKET / 'refresh_inventory.py') == 'c2a6ea5532a5b6cb43024e9605d694a6740936e007fe179e3bc5b536dbd4858d'
    report = json.loads(REPORT.read_text())
    prior = json.loads(PRIOR.read_text())
    assert sha(PRIOR) == report['prior_inventory']['sha256']
    entries = report['prior_inventory']['entries']
    assert len(entries) == len(prior['findings']) == 30
    verified, dispositions = [], {}
    for index, (entry, original) in enumerate(zip(entries, prior['findings'], strict=True)):
        assert entry['prior_index'] == index
        assert entry['path'] == original['path']
        assert entry['prior_sha256'] == original['sha256']
        data, provenance = snapshot(entry['path'], entry['current_sha256'])
        assert len(data) == entry['current_bytes']
        matches = []
        for old, check in zip(original['excerpts'], entry['current_cited_excerpt_checks'], strict=True):
            actual = excerpt(data, old['start_line'], old['end_line'], True)
            assert check['current_excerpt_at_prior_lines'] == actual
            equal = actual == old['text']
            assert check['exact_at_prior_lines'] == equal
            matches.append(equal)
        unchanged = digest(data) == original['sha256'] and all(matches)
        disposition = ('unchanged' if unchanged else
                       'identity_changed_cited_excerpts_preserved' if all(matches) else
                       'superseded_or_citation_changed')
        assert disposition == entry['disposition']
        if original['snapshot'] != 'worktree':
            revision = original['snapshot'].split(':', 1)[1]
            historical = subprocess.check_output(['git', 'show', revision + ':' + entry['path']], cwd=ROOT)
            assert digest(historical) == original['sha256']
            assert len(historical) == original['bytes']
            for old in original['excerpts']:
                assert excerpt(historical, old['start_line'], old['end_line'], True) == old['text']
            assert entry['prior_identity_reproduced_from_immutable_source'] is True
        dispositions[disposition] = dispositions.get(disposition, 0) + 1
        verified.append(dict(index=index, path=entry['path'], provenance=provenance, disposition=disposition))
    assert dispositions == {'unchanged': 24, 'identity_changed_cited_excerpts_preserved': 1,
                            'superseded_or_citation_changed': 5}
    for entry in report['exact_text_replacement_map']:
        data, _ = snapshot(entry['path'], entry['current_sha256'])
        assert len(data) == entry['current_bytes']
        assert excerpt(data, entry['line_start'], entry['line_end']) == entry['old_text_exact']
    assert len(report['exact_text_replacement_map']) == 7
    for entry in report['statements_preserved']:
        data, _ = snapshot(entry['path'], entry['sha256'])
        assert excerpt(data, entry['line_start'], entry['line_end']) == entry['exact_text']
    assert len(report['statements_preserved']) == 9
    matrix = report['release_scope_matrix_review']
    data, _ = snapshot(matrix['path'], matrix['current_sha256'])
    for entry in matrix['checks']:
        if entry['lines'].isdigit():
            index = int(entry['lines'])
            assert excerpt(data, index, index) == entry['exact_text']
    contract = report['scope_contract']
    assert sha(ROOT / contract['path']) == contract['sha256']
    save(OUT / 'stream-unary-denial-refresh-primary-494.json', dict(
        status='passed', report=dict(path=str(REPORT), sha256=sha(REPORT)),
        helper=dict(path=str(Path(__file__).resolve()), sha256=sha(__file__)),
        entries_verified=verified, dispositions=dispositions,
        exact_map_anchors_verified=7, historical_boundaries_verified=9,
        proposal_disposition='Inventory accepted as source evidence only. Primary will write final accepted-scope prose after runtime checks. No generated output or frozen runtime docstring is changed from this proposal.',
        scope_matrix='Set-operation hosted closure is separately applied from the accepted hosted packet; unary row awaits runtime evidence.',
        original_dirty_snapshots='Changed prior dirty-file identities remain superseded, not reconstructed or accepted as current.'))
    print(json.dumps(dict(status='passed', entries=30, exact_map_anchors=7, preserved_boundaries=9)), flush=True)


if __name__ == '__main__':
    main()
