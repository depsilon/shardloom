"""Check the literal dependency inventory and resolve its four reported imports."""
import ast
import json
from pathlib import Path

from freeze_native_release_298 import ROOT, OUT, sha, save
from stream_unary_acceptance_sources_496 import identity, load


def main():
    path = OUT / 'stream-unary-helper-dependency-inventory-496.json'
    inventory = json.loads(path.read_text())
    assert len(inventory['files']) == 95 and len(inventory['import_edges']) == 851
    assert not inventory['helper_name_missing_paths'] and not inventory['missing_O_helper_names']
    for item in inventory['files']:
        assert sha(item['path']) == item['sha256'], item['path']
    module = ROOT / 'python/src/shardloom/_relational_sql.py'
    imports = [node for node in ast.walk(ast.parse(module.read_text()))
               if isinstance(node, ast.ImportFrom) and node.module is None]
    assert [node.lineno for node in imports] == [50, 69, 98]
    assert all(node.level == 1 and [(name.name, name.asname) for name in node.names] == [('query', 'q')]
               for node in imports)
    manifest = load()
    driver = OUT / 'run_stream_unary_runtime_495.py'
    assert "os.environ['SHARDLOOM_NATIVE_TEST_LIBRARY'] = manifest['binding']['path']" in driver.read_text()
    assert "spec_from_file_location(\"shardloom._native\", path)" in (
        ROOT / 'python/tests/test_native_binding.py').read_text()
    assert len(inventory['unresolved_dynamic_or_import_items']) == 4
    save(OUT / 'stream-unary-helper-inventory-primary-496.json', dict(
        status='passed_dependency_inventory_only', inventory=identity(path),
        verified_file_identities=95, recorded_import_edges=851, engine_executions=0,
        resolutions=[dict(file=str(module), lines=[50, 69, 98],
                          dependency=identity(ROOT / 'python/src/shardloom/query.py')),
                     dict(file=str(ROOT / 'python/tests/test_native_binding.py'), line=41,
                          dependency=identity(manifest['binding']['path']), driver=identity(driver),
                          reason='The accepted direct-test driver sets the exact frozen binding path before loading.')],
        helper=identity(__file__), all_four_reported_imports_resolved=True,
        limitations='Static reproduction inventory; direct runtime acceptance is recorded separately.'))
    print(json.dumps(dict(status='passed_dependency_inventory_only', files=95, imports_resolved=4)))


if __name__ == '__main__':
    main()
