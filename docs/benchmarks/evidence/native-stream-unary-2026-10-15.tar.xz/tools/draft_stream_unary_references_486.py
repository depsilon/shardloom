"""Predeclare independent sampling and rolling values; no engine execution.

These are future unary-streaming fixtures. Sampling globally ranks all rows
instead of using the engine's bounded heap. Rolling evaluates each complete
frame independently instead of using its incremental scheduler. The small
fixtures intentionally use exactly representable binary fractions and sums.
"""
import hashlib
import json
import math
from pathlib import Path
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
U64 = (1 << 64) - 1


def score(seed, ordinal):
    # The existing public seed contract uses this pinned 64-bit mapping.
    value = (seed ^ ((ordinal * 0x9E3779B97F4A7C15) & U64)) + 0x9E3779B97F4A7C15
    value &= U64
    value = ((value ^ (value >> 30)) * 0xBF58476D1CE4E5B9) & U64
    value = ((value ^ (value >> 27)) * 0x94D049BB133111EB) & U64
    return value ^ (value >> 31)


def unit(seed, ordinal):
    value = (float(score(seed, ordinal)) + 0.5) / float(1 << 64)
    return min(1.0 - sys.float_info.epsilon, max(sys.float_info.min, value))


def sample_ordinals(population, target, seed, *, weights=None, replace=False):
    assert population >= 0 and target >= 0 and 0 <= seed <= U64
    if weights is not None:
        assert len(weights) == population
        if any(isinstance(value, bool) or not isinstance(value, (int, float)) or
               not math.isfinite(value) or value <= 0 for value in weights):
            raise ValueError('positive finite numeric weights required')
    if population == 0 or target == 0:
        return []
    if replace:
        if weights is None:
            return [score(seed, draw) % population for draw in range(target)]
        total = sum(weights)
        if not math.isfinite(total):
            raise ValueError('finite total weight required')
        result = []
        for draw in range(target):
            threshold = unit(seed ^ 0xA0761D6478BD642F, draw) * total
            cumulative = 0.0
            for ordinal, weight in enumerate(weights):
                cumulative += weight
                if threshold <= cumulative:
                    result.append(ordinal)
                    break
            else:
                result.append(population - 1)
        return result
    ranks = [score(seed, ordinal) if weights is None else
             math.log(unit(seed, ordinal)) / weights[ordinal]
             for ordinal in range(population)]
    selected = sorted(range(population), key=lambda ordinal: (-ranks[ordinal], ordinal))[:target]
    return sorted(selected)


def rolling_values(values, window, min_periods, aggregate, *, center=False):
    assert 1 <= min_periods <= window
    assert aggregate in ('sum', 'mean', 'min', 'max', 'count')
    output = []
    for ordinal in range(len(values)):
        left = (window - 1) // 2 if center else window - 1
        right = window - 1 - left if center else 0
        frame = [value for value in values[max(0, ordinal - left):ordinal + right + 1]
                 if value is not None]
        if len(frame) < min_periods:
            continue
        if aggregate == 'count':
            result = len(frame)
        elif aggregate == 'sum':
            result = float(sum(frame))
        elif aggregate == 'mean':
            result = sum(frame) / len(frame)
        elif aggregate == 'min':
            result = float(min(frame))
        else:
            result = float(max(frame))
        output.append(result)
    return output


def main():
    destination = OUT / 'stream-unary-reference-fixtures-486.json'
    assert not destination.exists()
    rows = [{'id': ordinal, 'value': None if ordinal % 5 == 1 else ordinal * 4,
             'weight': float(1 + ordinal % 4)} for ordinal in range(12)]
    cases = []
    for seed in (0, 7, U64):
        for weighted in (False, True):
            for replace in (False, True):
                for target in (1, 5, 15):
                    weights = [row['weight'] for row in rows] if weighted else None
                    ordinals = sample_ordinals(len(rows), target, seed, weights=weights, replace=replace)
                    cases.append(dict(name=f'sample-seed-{seed}-weighted-{weighted}-replace-{replace}-n-{target}',
                        options=dict(n=target, random_state=seed, weights='weight' if weighted else None,
                                     replace=replace),
                        ordinals=ordinals, expected=[rows[index] for index in ordinals]))
    for fraction, target in ((0.25, 3), (0.5, 6), (0.75, 9), (1.0, 12)):
        for weighted in (False, True):
            for replace in (False, True):
                weights = [row['weight'] for row in rows] if weighted else None
                ordinals = sample_ordinals(len(rows), target, 7, weights=weights, replace=replace)
                cases.append(dict(name=f'sample-fraction-{fraction}-weighted-{weighted}-replace-{replace}',
                    options=dict(frac=fraction, random_state=7, weights='weight' if weighted else None,
                                 replace=replace),
                    declared_target=target, ordinals=ordinals, expected=[rows[index] for index in ordinals]))
    tied_rows = [dict(row, weight=float.fromhex('0x0.0000000000001p-1022')) for row in rows]
    tied = sample_ordinals(len(tied_rows), 5, 7, weights=[row['weight'] for row in tied_rows])
    assert tied == list(range(5))
    cases.append(dict(name='sample-tied-negative-infinity-scores-preserve-earliest-ordinals',
        options=dict(n=5, random_state=7, weights='weight', replace=False),
        rows=tied_rows, ordinals=tied, expected=tied_rows[:5]))
    empty = sample_ordinals(0, 5, 7, weights=[])
    assert empty == []
    cases.append(dict(name='sample-empty-population', options=dict(n=5, random_state=7),
                      rows=[], ordinals=[], expected=[]))
    values = [4, None, 8, 0, None, 12, -4, 16]
    rolling = []
    for window in (1, 2, 3, 4, 12):
        for minimum in sorted({1, min(2, window), window}):
            for center in (False, True):
                for aggregate in ('sum', 'mean', 'min', 'max', 'count'):
                    rolling.append(dict(name=f'rolling-{aggregate}-window-{window}-minimum-{minimum}-center-{center}',
                        window=window, min_periods=minimum, center=center, aggregate=aggregate,
                        expected=rolling_values(values, window, minimum, aggregate, center=center)))
    # Independent hand-calculated frame examples protect the fixture generator.
    assert rolling_values([4, None, 8, 0], 2, 1, 'sum') == [4.0, 4.0, 8.0, 8.0]
    assert rolling_values([4, None, 8, 0], 2, 2, 'sum') == [8.0]
    assert rolling_values([4, None, 8, 0], 4, 1, 'sum', center=True) == [12.0, 12.0, 8.0, 8.0]
    assert rolling_values([None, None], 3, 1, 'count', center=True) == []
    assert len(cases) == len({case['name'] for case in cases}) == 54
    assert len(rolling) == len({case['name'] for case in rolling}) == 120
    paths = ['shardloom-vortex/src/local_primitives.rs',
             'shardloom-vortex/src/local_primitive_unary_sample.rs',
             'shardloom-vortex/src/local_primitive_unary_rolling.rs',
             'shardloom-vortex/src/local_primitives/rolling_observation.rs',
             'python/src/shardloom/query.py']
    sources = {path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest() for path in paths}
    report = dict(status='predeclared_only', engine_executions=0, runtime_changed=False,
        sampling_rows=rows, sampling_cases=cases, rolling_values=values, rolling_cases=rolling,
        source_sha256=sources, helper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        oracle_scope='global ranking or linear weighted draw and independently recomputed rolling frames',
        limitations=['The pinned 64-bit seed mapping is shared contract, not an independent random generator.',
                     'Fraction cases use exact binary fractions and explicit target counts.',
                     'These references do not establish runtime, ownership, resource or publication acceptance.'])
    with destination.open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps(dict(status=report['status'], sampling_cases=len(cases), rolling_cases=len(rolling),
                         engine_executions=0, path=str(destination))))


if __name__ == '__main__':
    main()
