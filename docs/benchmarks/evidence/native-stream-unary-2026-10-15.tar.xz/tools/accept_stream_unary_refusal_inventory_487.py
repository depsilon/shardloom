"""Independently check the bounded future-unary refusal inventory."""
import hashlib
import json
from pathlib import Path
import subprocess

from freeze_native_release_298 import ROOT, OUT, save, sha
from run_stream_sets_runtime_484 import identity


def main():
    path = OUT / 'stream-unary-refusal-inventory-487.json'
    report = json.loads(path.read_text())
    found = {item['kind']: item for item in report['findings']}
    assert len(found) == 9
    assert {kind for kind, row in found.items() if row['status'] == 'tested_refusal'} == {'DistinctRows', 'DropDuplicateRows'}
    assert set(found['DropDuplicateRows']['test_or_case_identifiers']) == {
        'deny-unary', 'deny-unary-left-set', 'deny-unary-right-set'}
    refs = [item for row in found.values() for item in row.get('evidence', [])]
    refs += report['controls_and_nonmatching_evidence']
    assert len(refs) == 11
    for ref in refs:
        source = ROOT / ref['path']
        assert sha(source) == ref['sha256']
        first, last = ref['line_span']
        excerpt = '\n'.join(source.read_text().splitlines()[first - 1:last])
        assert excerpt == ref['excerpt']
        assert hashlib.sha256(excerpt.encode()).hexdigest() == ref['excerpt_sha256']
    roots = ['shardloom-vortex/src', 'scripts', 'python/tests']
    matches = subprocess.check_output(['rg', '-n', r'unary stateful|unary.*stateful|deny-unary', *roots], cwd=ROOT, text=True)
    paths = {line.split(':', 1)[0] for line in matches.splitlines()}
    assert paths == {'scripts/native_streaming_input_cases.py',
        'shardloom-vortex/src/local_primitive_relational_batch_dynamic_tests.rs',
        'shardloom-vortex/src/local_primitive_relational_batch_input.rs'}
    save(OUT / 'stream-unary-refusal-primary-acceptance-487.json', dict(status='passed',
        report=identity(path), preserved_initial_report=identity(OUT / 'stream-unary-refusal-inventory-487-before-repair.json'),
        checker=identity(OUT / 'check_stream_unary_refusal_inventory_487.py'), helper=identity(__file__),
        exact_excerpts=11, kinds=9, tested_refusal_kinds=['DistinctRows', 'DropDuplicateRows'],
        independent_diagnostic_search=matches, source_files={ref['path']:ref['sha256'] for ref in refs},
        primary_review='Verified public factory/denial cases and native dynamic preparation, producer demand trap, diagnostic and memory/completion assertions.',
        scope='Read-only future fixture migration inventory. Other seven kinds have no refusal fixture found in the scoped searches; this is not a runtime capability or exhaustive language-equivalence proof.',
        runtime_executed=False, repository_changed=False))
    print(json.dumps(dict(status='passed', excerpts=11, tested_refusal_kinds=2)))


if __name__ == '__main__':
    main()
