"""Prepared only: freeze nine unary refusals and complete resident controls.

Run after streaming-set acceptance and before any unary runtime change. The
sampling control selects its whole population; a later sampling acceptance
matrix still needs an independent selection oracle.
"""
import json
from pathlib import Path

from freeze_native_release_298 import ROOT, OUT, sha, save, sources
from stream_set_acceptance_sources_487 import load, ACCEPTED_SOURCE
from run_native_streaming_input_uat import Harness
from shardloom.errors import ShardLoomCommandError

DEST = OUT / 'stream-unary-baseline-487'
SOURCE = OUT / 'native-release-source-streamsets484.json'
ARTIFACTS = OUT / 'native-release-artifacts-streamsets484.json'
KINDS = ('distinct', 'dedup', 'duplicate_mask', 'tail', 'sample', 'expression', 'melt', 'rolling', 'explode')
ROWS = [{'id': 3, 'value': 10}, {'id': 1, 'value': 20}, {'id': 3, 'value': 10},
        {'id': 2, 'value': 40}, {'id': None, 'value': 50}]
LIST_ROWS = [{'id': 3, 'items': [7, None, 8]}, {'id': 1, 'items': [9]}]
EXPECTED = {
    'distinct': [ROWS[i] for i in (0, 1, 3, 4)],
    'dedup': [ROWS[i] for i in (1, 2, 3, 4)],
    'duplicate_mask': [{'duplicated': value} for value in (True, False, True, False, False)],
    'tail': ROWS[-2:],
    'sample': ROWS,
    'expression': [{'id': row['id'], 'value': row['value'] + 1} for row in ROWS],
    'melt': [{'id': row['id'], 'variable': 'value', 'value': row['value']} for row in ROWS],
    'rolling': [{'total': value} for value in (10.0, 30.0, 30.0, 50.0, 90.0)],
    'explode': [{'id': 3, 'items': 7}, {'id': 3, 'items': None},
                {'id': 3, 'items': 8}, {'id': 1, 'items': 9}],
}


def apply(source, kind):
    if kind == 'distinct':
        return source.distinct()
    if kind == 'dedup':
        return source.drop_duplicates(subset=['id'], keep='last')
    if kind == 'duplicate_mask':
        return source.duplicated(subset=['id'], keep=False)
    if kind == 'tail':
        return source.tail(2)
    if kind == 'sample':
        return source.sample(n=5, random_state=7)
    if kind == 'expression':
        return source.eval('value = value + 1')
    if kind == 'melt':
        return source.melt(id_vars=['id'], value_vars=['value'])
    if kind == 'rolling':
        return source.rolling(window=2, min_periods=1).sum('value', alias='total')
    assert kind == 'explode'
    return source.explode('items')


def main():
    accepted = json.loads(ACCEPTED_SOURCE.read_text())['source_sha256']
    assert sources() == accepted
    runtime = json.loads((OUT / 'stream-sets-runtime-487.json').read_text())
    full43 = json.loads((OUT / 'stream-sets-full43-review-487.json').read_text())
    assert runtime['status'] == full43['status'] == 'passed'
    assert runtime['public_cases'] == 1121 and full43['calls'] == 43
    artifacts = load()
    assert runtime['manifest_sha256'] == sha(ARTIFACTS)
    binary = Path(artifacts['cli']['path'])
    assert sha(binary) == artifacts['cli']['sha256']
    assert artifacts['source_sha256'] == json.loads(SOURCE.read_text())['source_sha256']
    assert not DEST.exists()
    harness = Harness(binary, DEST, 60)
    harness.guard()
    harness.logs.mkdir(parents=True)
    harness.output.mkdir()
    harness.json(harness.logs / 'predeclared-expectations.json', {
        'rows': ROWS, 'list_rows': LIST_ROWS, 'expected': EXPECTED, 'kinds': KINDS,
        'cases': 18, 'streaming_refusals': 9, 'resident_controls': 9,
        'helper_sha256': sha(__file__), 'source_manifest_sha256': sha(SOURCE),
        'acceptance_source_manifest_sha256': sha(ACCEPTED_SOURCE),
        'sampling_scope': 'whole-population control only; not selection-algorithm acceptance',
    })
    status = 'failed'
    try:
        for streaming in (True, False):
            for kind in KINDS:
                name = f'unary-baseline-{kind}-streaming-{streaming}'
                def case(name=name, streaming=streaming, kind=kind):
                    events = []
                    rows = LIST_ROWS if kind == 'explode' else ROWS
                    schema = {'id': 'int64', 'items': {'type': 'list', 'item': 'int64'}} if kind == 'explode' else {
                        'id': 'int64', 'value': 'int64'}
                    def producer():
                        events.append('opened')
                        try:
                            for batch in ([], rows[:1], rows[1:3], [], rows[3:]):
                                yield batch
                            events.append('ended')
                        finally:
                            events.append('closed')
                    source = harness.context.from_batches(producer, schema=schema, streaming=streaming)
                    query = apply(source, kind)
                    assert events == []
                    try:
                        result = query.collect(check=True, memory_bytes=32 << 20, max_parallelism=1)
                    except ShardLoomCommandError as error:
                        assert streaming, error.envelope.raw
                        harness.envelope(name, error.envelope, success=False)
                        assert 'unary stateful operator' in json.dumps(error.envelope.raw)
                        assert events == [], events
                        return dict(outcome='static_streaming_refusal', producer_events=events)
                    else:
                        assert not streaming
                        harness.envelope(name, result.envelope)
                        harness.values(name, result.result_rows, EXPECTED[kind])
                        assert events == ['opened', 'ended', 'closed'], events
                        return dict(outcome='resident_control_passed', producer_events=events)
                harness.case(name, case)
        assert len(harness.results) == 18 and all(row['status'] == 'passed' for row in harness.results)
        assert sources() == accepted and sha(binary) == artifacts['cli']['sha256']
        status = 'passed'
    finally:
        harness.client.close()
        save(DEST / 'summary.json', dict(status=status, cases=harness.results, kinds=KINDS,
            rows=ROWS, list_rows=LIST_ROWS, expected=EXPECTED, binary=artifacts['cli'],
            artifact_manifest=str(ARTIFACTS), artifact_manifest_sha256=sha(ARTIFACTS),
            source_manifest=str(SOURCE), source_manifest_sha256=sha(SOURCE), helper_sha256=sha(__file__),
            accepted_source_manifest=str(ACCEPTED_SOURCE), accepted_source_manifest_sha256=sha(ACCEPTED_SOURCE),
            runtime_source_changed=False, performance_claim=False))
    print(json.dumps(dict(status=status, cases=18, streaming_refusals=9, resident_controls=9)))


if __name__ == '__main__':
    main()
