"""Run six serial Rust gates against frozen unary admission and predeclared checks."""
import json
import re
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sources, sha, save
from run_stream_destination_review_checks_479 import CHECKS

FROZEN = OUT / 'native-release-source-streamunary494.json'
DECLARATIONS = OUT / 'stream-unary-candidate-declarations-493b/declarations.json'
REFERENCE = ROOT / 'scripts/native_streaming_unary_reference_fixtures.json'


def main():
    frozen = json.loads(FROZEN.read_text())
    declaration = json.loads(DECLARATIONS.read_text())
    assert declaration['status'] == 'passed' and declaration['engine_executions'] == 0
    assert declaration['public_cases'] == 1480
    assert all(sha(ROOT / name) == digest for name, digest in declaration['source_sha256'].items())
    assert sha(REFERENCE) == declaration['original_reference_sha256']

    def unchanged():
        return sources() == frozen['source_sha256'] and sha(REFERENCE) == declaration['original_reference_sha256']

    assert unchanged()
    prior_path = OUT / 'stream-sets-checks-484.json'
    prior = json.loads(prior_path.read_text())
    assert prior['status'] == 'passed' and prior['source_identity_preserved']
    prior_native = next(row for row in prior['completed'] if row['stage'] == 'native-tests')
    expected_ignored = sorted(tuple(row) for row in prior_native['tests']['ignored_declarations'])
    assert len(expected_ignored) == 29
    assert sum(reason.startswith('requires the non-Unix runtime branch;')
               for _, reason in expected_ignored) == 3
    required = []
    for path in sorted((ROOT / 'shardloom-vortex/src').glob('local_primitive_relational_batch_unary*_tests.rs')):
        required.extend(re.findall(r'#\[test\]\n(?:#\[[^\n]*\n)*fn (\w+)\(', path.read_text()))
    assert len(required) == len(set(required)) == 8
    protocol = dict(source_manifest=str(FROZEN), source_manifest_sha256=sha(FROZEN),
                    helper_sha256=sha(__file__), guard_sha256=sha(OUT / 'run_guarded.py'),
                    command_source_sha256=sha(OUT / 'run_stream_destination_review_checks_479.py'),
                    prior_checks_sha256=sha(prior_path), checks=CHECKS,
                    predeclared_cases=dict(path=str(DECLARATIONS), sha256=sha(DECLARATIONS)),
                    reference_fixture=dict(path=str(REFERENCE), sha256=sha(REFERENCE)),
                    new_native_tests=required, expected_ignored=expected_ignored,
                    vendor_scope='No vendor changes; prior provider acceptance remains separately retained.',
                    earlier_lint_failure='stream-unary-clippy-focused-493.json; three test-only lint corrections',
                    earlier_preflight_failure='stream-unary-check-preflight-494.json; full gate also includes three non-Unix declarations',
                    earlier_declaration_failure='stream-unary-candidate-declarations-493/failure.json; missing pyarrow in helper interpreter')
    save(OUT / 'stream-unary-check-protocol-494.json', protocol)
    records, failure = [], None
    try:
        for label, timeout, command in CHECKS:
            assert unchanged()
            name = 'stream-unary-' + label + '-494'
            print(json.dumps(dict(stage=label, status='starting')), flush=True)
            subprocess.run([sys.executable, '-B', str(OUT / 'run_guarded.py'), '--name', name,
                            '--timeout', str(timeout), '--', *command], cwd=ROOT, check=True)
            path = OUT / (name + '.json')
            receipt, log = json.loads(path.read_text()), path.with_suffix('.log')
            assert receipt['status'] == 'passed' and receipt['returncode'] == 0
            assert receipt['process_group_drained'] and receipt['direct_child_reaped']
            assert not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup']
            assert receipt['head'] == frozen['head'] and sha(log) == receipt['log_sha256']
            record = dict(stage=label, receipt=str(path), receipt_sha256=sha(path),
                          log=str(log), log_sha256=sha(log), seconds=receipt['seconds'])
            if label.endswith('tests'):
                raw = log.read_text()
                groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', raw)
                assert groups and all(int(row[1]) == int(row[3]) == int(row[4]) == 0 for row in groups)
                ignored = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', raw, re.M)
                assert sum(int(row[2]) for row in groups) == len(ignored)
                if label == 'native-tests':
                    assert sorted(ignored) == expected_ignored
                    for test in required:
                        assert re.search(r'^test .*::' + test + r' \.\.\. ok$', raw, re.M), test
                else:
                    assert not ignored
                record['tests'] = dict(passed=sum(int(row[0]) for row in groups), failed=0,
                                       ignored=len(ignored), groups=len(groups), ignored_declarations=ignored)
            records.append(record)
            print(json.dumps(dict(stage=label, status='passed', tests=record.get('tests', {}).get('passed'))), flush=True)
        assert unchanged()
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        save(OUT / 'stream-unary-checks-494.json', dict(status='passed' if failure is None else 'failed',
             failure=failure, protocol=protocol, source_files=len(frozen['source_sha256']),
             source_identity_preserved=unchanged(), completed=records))


if __name__ == '__main__':
    main()
