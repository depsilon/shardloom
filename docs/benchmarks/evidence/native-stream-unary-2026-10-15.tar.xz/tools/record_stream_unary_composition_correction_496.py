"""Preserve a declaration-only alias error and bind its exact fixture correction."""
import difflib
import json
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest.mock import patch

from freeze_native_release_298 import ROOT, OUT, sources, sha, save
from stream_unary_acceptance_sources_495 import identity, load, unchanged

PREVIOUS = OUT / 'stream-unary-verification-source-495.json'
CURRENT = OUT / 'stream-unary-verification-source-496.json'
DIRECTORY = OUT / 'stream-unary-composition-correction-496b'
RELATIVE = 'scripts/native_streaming_unary_composition_cases.py'


def prepare():
    manifest = load()
    before = unchanged()
    assert not DIRECTORY.exists() and not CURRENT.exists()
    DIRECTORY.mkdir()
    original = DIRECTORY / Path(RELATIVE).name
    with original.open('xb') as stream:
        stream.write((ROOT / RELATIVE).read_bytes())
    assert sha(original) == before['source_sha256'][RELATIVE]
    failure_path = OUT / 'stream-unary-public-focused-495/summary.json'
    failure = json.loads(failure_path.read_text())
    failed = [row for row in failure['cases'] if row['status'] != 'passed']
    assert len(failed) == 1 and failed[0]['name'] == 'unary-dynamic-rolling-before'
    assert failed[0]['error'] == "AttributeError: 'UnsupportedWorkflowOperationReport' object has no attribute 'select'"
    sys.path[:0] = [str(ROOT / 'python/src'), str(ROOT / 'scripts')]
    import shardloom as sl
    from shardloom.query import LazyFrame, _vortex_rolling_window_payload
    from native_streaming_unary_cases import frame
    from native_streaming_dynamic_cases import ROWS, SCHEMA
    context = sl.ShardLoomContext(sl.ShardLoomClient(binary=manifest['cli']['path']))
    with patch('subprocess.Popen', side_effect=AssertionError('declarations must not execute')):
        source, trace = frame(SimpleNamespace(context=context), ROWS, SCHEMA, width=1)
        invalid = _vortex_rolling_window_payload('amount', output_column='amount',
            window_size=2, min_periods=1, aggregate='sum')
        assert invalid is None
        valid = source.rolling(2, min_periods=1).sum('amount', alias='total').select(
            '1 AS entity', "'a' AS category", 'total AS amount')
        assert isinstance(valid, LazyFrame)
        assert trace == dict(opened=0, batches=0, rows=0, ended=False, closed=False)
        statement = valid._relation_statement()
    save(DIRECTORY / 'before.json', dict(status='diagnosed_before_correction',
        previous_source=identity(PREVIOUS), original=identity(original), relative_path=RELATIVE,
        failed_summary=identity(failure_path), failed_receipt=identity(OUT / 'stream-unary-public-focused-495.json'),
        failed_log=identity(OUT / 'stream-unary-public-focused-495.log'), failed_case=failed[0],
        prior_passing_cases=len(failure['cases']) - 1, declaration_only=True, engine_executions=0,
        producer_trace=trace, invalid_alias_payload=invalid, valid_statement=statement,
        cause='The existing rolling declaration refuses an output alias equal to the source column.',
        correction='Use the distinct rolling output total and project total AS amount before pivot.',
        original_expected_values_unchanged=True, helper=identity(__file__)))
    print(json.dumps(dict(status='diagnosed', prior_passing_cases=len(failure['cases']) - 1,
                         engine_executions=0)), flush=True)


def record():
    before = json.loads((DIRECTORY / 'before.json').read_text())
    previous = json.loads(PREVIOUS.read_text())
    assert before['previous_source'] == identity(PREVIOUS)
    original = Path(before['original']['path'])
    assert identity(original) == before['original']
    expected = original.read_text().replace(
        '.sum("amount", alias="amount").select(\n                            "1 AS entity", "\'a\' AS category", "amount")',
        '.sum("amount", alias="total").select(\n                            "1 AS entity", "\'a\' AS category", "total AS amount")')
    assert expected != original.read_text() and (ROOT / RELATIVE).read_text() == expected
    current = sources()
    assert set(current) == set(previous['source_sha256'])
    assert [name for name in sorted(current) if current[name] != previous['source_sha256'][name]] == [RELATIVE]
    diff = ''.join(difflib.unified_diff(original.read_text().splitlines(keepends=True),
        expected.splitlines(keepends=True), fromfile='before/' + RELATIVE, tofile='after/' + RELATIVE))
    diff_path = DIRECTORY / 'correction.diff'
    with diff_path.open('x') as stream:
        stream.write(diff)
    result = dict(previous)
    result.update(source_sha256=current, changed_files=sorted(previous['changed_files'] + [RELATIVE]),
        previous_source=identity(PREVIOUS), composition_diagnosis=identity(DIRECTORY / 'before.json'),
        helper=identity(__file__), verification_pending=True)
    result['transitions'] = previous['transitions'] + [dict(relative_path=RELATIVE,
        before=before['original'], after=identity(ROOT / RELATIVE), diff=identity(diff_path))]
    assert not CURRENT.exists()
    save(CURRENT, result)
    print(json.dumps(dict(status='frozen_for_verification', source_files=len(current),
        changes_from_previous=[RELATIVE], runtime_unchanged=True, expected_values_unchanged=True)), flush=True)


if __name__ == '__main__':
    prepare() if sys.argv[1:] == ['prepare'] else record()
