"""Reconcile test/evidence corrections with unchanged frozen native artifacts."""
import json
from pathlib import Path

from freeze_native_release_298 import ROOT, OUT, sha, sources

SOURCE = OUT / 'native-release-source-streamunary494.json'
ACCEPTED_SOURCE = OUT / 'stream-unary-verification-source-495.json'
MANIFEST = OUT / 'native-release-artifacts-streamunary494.json'
DECLARATIONS = OUT / 'stream-unary-candidate-declarations-493b/declarations.json'
REFERENCE = ROOT / 'scripts/native_streaming_unary_reference_fixtures.json'
CHANGED = ['python/tests/test_native_unary_binding.py', 'scripts/run_native_streaming_input_uat.py']
ADDED = ['python/tests/test_native_streaming_uat_compression.py']


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def unchanged():
    frozen = json.loads(SOURCE.read_text())
    accepted = json.loads(ACCEPTED_SOURCE.read_text())
    assert accepted['status'] == 'frozen_for_verification'
    assert accepted['build_source'] == identity(SOURCE)
    assert accepted['artifacts'] == identity(MANIFEST)
    assert sources() == accepted['source_sha256'] and len(accepted['source_sha256']) == 2283
    prior, current = frozen['source_sha256'], accepted['source_sha256']
    assert sorted(name for name in prior if current.get(name) != prior[name]) == CHANGED
    assert sorted(set(current) - set(prior)) == ADDED
    assert accepted['changed_files'] == CHANGED and accepted['added_files'] == ADDED
    for row in accepted['transitions']:
        assert identity(row['before']['path']) == row['before']
        assert identity(row['after']['path']) == row['after']
        assert identity(row['diff']['path']) == row['diff']
    declaration = json.loads(DECLARATIONS.read_text())
    assert accepted['original_declarations'] == identity(DECLARATIONS)
    assert sha(REFERENCE) == declaration['original_reference_sha256']
    assert accepted['extra_reference'] == identity(REFERENCE)
    assert all(sha(ROOT / name) == digest for name, digest in declaration['source_sha256'].items()
               if name not in CHANGED)
    assert json.loads(Path(accepted['diagnosis']['path']).read_text())['status'] == 'passed'
    assert identity(accepted['diagnosis']['path']) == accepted['diagnosis']
    return accepted


def load():
    unchanged()
    frozen = json.loads(SOURCE.read_text())
    manifest = json.loads(MANIFEST.read_text())
    assert manifest['status'] == 'passed' and manifest['source_sha256'] == frozen['source_sha256']
    for key in ('cli', 'binding'):
        assert identity(manifest[key]['path']) == {k: manifest[key][k] for k in ('path', 'bytes', 'sha256')}
    return manifest
