"""Build frozen unary artifacts and verify direct and public finite input paths."""
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

from freeze_native_release_298 import ROOT, OUT, sha, sources, save
from run_query_timing_runtime_461 import guarded, PYTHON_DEPS

SOURCE = OUT / 'native-release-source-streamunary494.json'
CHECKS = OUT / 'stream-unary-checks-494.json'
MANIFEST = OUT / 'native-release-artifacts-streamunary494.json'
DECLARATIONS = OUT / 'stream-unary-candidate-declarations-493b/declarations.json'
REFERENCE = ROOT / 'scripts/native_streaming_unary_reference_fixtures.json'
PYTHON = OUT / 'selected-view-python-468/bin/python'
DIRECT = OUT / 'stream-unary-direct-tests-494.json'
FOCUSED = OUT / 'stream-unary-public-focused-494'
FAMILIES = ['unary', 'unary-reference', 'unary-composition', 'unary-fault',
            'unary-pressure', 'input', 'dynamic']


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def unchanged():
    frozen = json.loads(SOURCE.read_text())
    declaration = json.loads(DECLARATIONS.read_text())
    assert sources() == frozen['source_sha256']
    assert all(sha(ROOT / name) == digest for name, digest in declaration['source_sha256'].items())
    assert sha(REFERENCE) == declaration['original_reference_sha256']
    return frozen


def load():
    frozen = unchanged()
    manifest = json.loads(MANIFEST.read_text())
    assert manifest['source_sha256'] == frozen['source_sha256']
    for key in ('cli', 'binding'):
        assert identity(manifest[key]['path']) == {k: manifest[key][k] for k in ('path', 'bytes', 'sha256')}
    return manifest


def direct():
    sys.path.insert(0, str(PYTHON_DEPS))
    sys.path.insert(0, str(ROOT / 'python/src'))
    import pyarrow
    import shardloom
    manifest = load()
    assert Path(sys.executable) == PYTHON
    assert Path(shardloom.__file__).resolve() == ROOT / 'python/src/shardloom/__init__.py'
    os.environ['SHARDLOOM_NATIVE_TEST_LIBRARY'] = manifest['binding']['path']
    os.environ['SHARDLOOM_REQUIRE_NATIVE_PYTHON'] = '1'
    os.environ['SHARDLOOM_BIN'] = manifest['cli']['path']
    suite = unittest.defaultTestLoader.discover(str(ROOT / 'python/tests'), pattern='test_native*binding.py')

    def names(test):
        if isinstance(test, unittest.TestSuite):
            return [name for child in test for name in names(child)]
        return [test.id()]

    identifiers = names(suite)
    prior = json.loads((OUT / 'stream-sets-direct-tests-484.json').read_text())['test_names']
    assert len(prior) == 87 and set(prior).issubset(identifiers)
    assert len(identifiers) == len(set(identifiers)) == 91
    added = sorted(set(identifiers) - set(prior))
    assert len(added) == 4 and all(name.startswith('test_native_unary_binding.') for name in added)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    passed = result.wasSuccessful() and result.testsRun == len(identifiers) and not result.skipped
    save(DIRECT, dict(status='passed' if passed else 'failed', tests=result.testsRun,
        failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
        test_names=identifiers, prior_test_names=prior, new_test_names=added,
        predeclared_subcases=468, artifact_manifest=identity(MANIFEST),
        interpreter=sys.executable, python_version=sys.version, pyarrow_version=pyarrow.__version__,
        pyarrow_file=pyarrow.__file__, package_source=shardloom.__file__, helper=identity(__file__),
        mode='direct_source_package_with_explicit_frozen_native_library', installed_wheel_proof=False))
    assert load() == manifest and passed


def main():
    frozen = unchanged()
    checks = json.loads(CHECKS.read_text())
    assert checks['status'] == 'passed' and checks['source_identity_preserved']
    assert len(checks['completed']) == 6 and checks['protocol']['source_manifest_sha256'] == sha(SOURCE)
    assert not MANIFEST.exists() and not DIRECT.exists() and not FOCUSED.exists()
    protocol = dict(source=identity(SOURCE), checks=identity(CHECKS), helper=identity(__file__),
        declarations=identity(DECLARATIONS), reference_fixture=identity(REFERENCE),
        guard=identity(OUT / 'run_guarded.py'), freezer=identity(OUT / 'freeze_native_release_298.py'),
        reused_guard_helper=identity(OUT / 'run_query_timing_runtime_461.py'),
        prior_direct=identity(OUT / 'stream-sets-direct-tests-484.json'),
        direct_expected_methods=91, new_direct_methods=4, new_direct_subcases=468,
        focused_families=FAMILIES, planned_new_public_cases=1480,
        planned_family_cases={row['family']: row['cases']
                              for row in json.loads(DECLARATIONS.read_text())['families']},
        broad_public_pending=True, full43_pending=True, publication_attempted=False)
    save(OUT / 'stream-unary-runtime-protocol-494.json', protocol)
    print(json.dumps(dict(stage='release-cli', status='starting')), flush=True)
    guarded('native-final-cli-release-build-streamunary494', 2100,
        ['cargo', 'build', '--offline', '--locked', '--release', '-p', 'shardloom-cli',
         '--features', 'release-user-surfaces', '--message-format=json-render-diagnostics'])
    assert unchanged() == frozen
    print(json.dumps(dict(stage='release-binding', status='starting')), flush=True)
    guarded('native-final-python-release-build-streamunary494', 2100,
        [sys.executable, '-B', ROOT / 'scripts/build_native_python.py', '--release', '--offline',
         '--output-dir', OUT / 'stream-unary-native-binding-494'])
    subprocess.run([sys.executable, '-B', str(OUT / 'freeze_native_release_298.py'),
                    '--run-id', 'streamunary494'], cwd=ROOT, check=True)
    manifest = load()
    print(json.dumps(dict(stage='direct-binding', status='starting')), flush=True)
    guarded('stream-unary-direct-494', 1800, [PYTHON, '-B', __file__, 'direct'])
    assert json.loads(DIRECT.read_text())['status'] == 'passed'
    print(json.dumps(dict(stage='focused-public', status='starting')), flush=True)
    guarded('stream-unary-public-focused-494', 5400,
        [sys.executable, '-B', ROOT / 'scripts/run_native_streaming_input_uat.py',
         '--binary', manifest['cli']['path'], '--uat-root', FOCUSED, '--operation-timeout', '600',
         '--families', *FAMILIES])
    result = json.loads((FOCUSED / 'summary.json').read_text())
    assert result['status'] == 'passed' and all(case['status'] == 'passed' for case in result['cases'])
    names = [case['name'] for case in result['cases']]
    assert len(names) == len(set(names)) and result['families'] == FAMILIES
    declaration = json.loads(DECLARATIONS.read_text())
    new_names = [name for family in declaration['families'] for name in family['names']]
    assert len(new_names) == len(set(new_names)) == 1480 and set(new_names).issubset(names)
    assert load() == manifest
    save(OUT / 'stream-unary-runtime-focused-494.json', dict(status='passed', source=identity(SOURCE),
        artifacts=identity(MANIFEST), direct=identity(DIRECT), focused_public=identity(FOCUSED / 'summary.json'),
        public_cases=len(result['cases']), new_public_cases=len(new_names),
        protocol=identity(OUT / 'stream-unary-runtime-protocol-494.json'),
        source_identity_preserved=True, broad_public_pending=True, full43_pending=True))


if __name__ == '__main__':
    direct() if sys.argv[1:] == ['direct'] else main()
