"""Verify corrected tests and compressed public evidence on frozen native binaries."""
import json
import os
from pathlib import Path
import re
import sys
import unittest

from freeze_native_release_298 import ROOT, OUT, sha, save
from run_query_timing_runtime_461 import guarded, PYTHON_DEPS
from stream_unary_acceptance_sources_495 import (
    SOURCE, ACCEPTED_SOURCE, MANIFEST, DECLARATIONS, REFERENCE, identity, load, unchanged,
)

PYTHON = OUT / 'selected-view-python-468/bin/python'
DIRECT = OUT / 'stream-unary-direct-tests-495.json'
HARNESS = OUT / 'stream-unary-harness-tests-495.json'
FOCUSED = OUT / 'stream-unary-public-focused-495'
FAMILIES = ['unary', 'unary-reference', 'unary-composition', 'unary-fault',
            'unary-pressure', 'input', 'dynamic']


def tests(kind):
    manifest = load()
    assert Path(sys.executable) == PYTHON
    sys.path[:0] = [str(PYTHON_DEPS), str(ROOT / 'python/src')]
    import pyarrow
    import shardloom
    assert Path(shardloom.__file__).resolve() == ROOT / 'python/src/shardloom/__init__.py'
    os.environ['SHARDLOOM_NATIVE_TEST_LIBRARY'] = manifest['binding']['path']
    os.environ['SHARDLOOM_REQUIRE_NATIVE_PYTHON'] = '1'
    os.environ['SHARDLOOM_BIN'] = manifest['cli']['path']
    direct = kind == 'direct'
    pattern = 'test_native*binding.py' if direct else 'test_native_streaming_uat_compression.py'
    suite = unittest.defaultTestLoader.discover(str(ROOT / 'python/tests'), pattern=pattern)

    def names(test):
        if isinstance(test, unittest.TestSuite):
            return [name for child in test for name in names(child)]
        return [test.id()]

    identifiers = names(suite)
    expected = 91 if direct else 5
    assert len(identifiers) == len(set(identifiers)) == expected
    prior = json.loads((OUT / 'stream-sets-direct-tests-484.json').read_text())['test_names'] if direct else []
    added = sorted(set(identifiers) - set(prior))
    if direct:
        assert len(prior) == 87 and set(prior).issubset(identifiers)
        assert len(added) == 4 and all(name.startswith('test_native_unary_binding.') for name in added)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    passed = result.wasSuccessful() and result.testsRun == expected and not result.skipped
    destination = DIRECT if direct else HARNESS
    assert not destination.exists()
    save(destination, dict(status='passed' if passed else 'failed', tests=result.testsRun,
        failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
        test_names=identifiers, prior_test_names=prior, new_test_names=added,
        predeclared_subcases=468 if direct else None, artifact_manifest=identity(MANIFEST),
        accepted_source=identity(ACCEPTED_SOURCE), interpreter=sys.executable,
        python_version=sys.version, pyarrow_version=pyarrow.__version__,
        package_source=shardloom.__file__, helper=identity(__file__),
        mode='direct_source_package_with_explicit_frozen_native_library' if direct else 'evidence_storage_unit_tests',
        installed_wheel_proof=False))
    assert load() == manifest and passed


def main():
    manifest = load()
    checks_path = OUT / 'stream-unary-checks-494.json'
    checks = json.loads(checks_path.read_text())
    assert checks['status'] == 'passed' and checks['source_identity_preserved']
    assert len(checks['completed']) == 6
    assert not DIRECT.exists() and not HARNESS.exists() and not FOCUSED.exists()
    declaration = json.loads(DECLARATIONS.read_text())
    protocol = dict(source=identity(SOURCE), accepted_source=identity(ACCEPTED_SOURCE),
        artifacts=identity(MANIFEST), checks=identity(checks_path), helper=identity(__file__),
        source_helper=identity(OUT / 'stream_unary_acceptance_sources_495.py'),
        declarations=identity(DECLARATIONS), reference_fixture=identity(REFERENCE),
        guard=identity(OUT / 'run_guarded.py'), focused_families=FAMILIES,
        planned_family_cases={row['family']: row['cases'] for row in declaration['families']},
        planned_new_public_cases=1480, direct_expected_methods=91, new_direct_subcases=468,
        original_failed_direct=identity(OUT / 'stream-unary-direct-tests-494.json'),
        binaries_rebuilt=False, compress_logs=True, broad_public_pending=True, full43_pending=True)
    save(OUT / 'stream-unary-runtime-protocol-495.json', protocol)
    for kind in ('harness', 'direct'):
        print(json.dumps(dict(stage=kind, status='starting')), flush=True)
        guarded('stream-unary-' + kind + '-495', 1800, [PYTHON, '-B', __file__, kind])
        assert load() == manifest
    print(json.dumps(dict(stage='focused-public', status='starting')), flush=True)
    guarded('stream-unary-public-focused-495', 5400,
        [sys.executable, '-B', ROOT / 'scripts/run_native_streaming_input_uat.py',
         '--binary', manifest['cli']['path'], '--uat-root', FOCUSED,
         '--operation-timeout', '600', '--compress-logs', '--families', *FAMILIES])
    summary = json.loads((FOCUSED / 'summary.json').read_text())
    assert summary['status'] == 'passed' and all(row['status'] == 'passed' for row in summary['cases'])
    assert summary['families'] == FAMILIES and summary['compress_logs']
    names = [row['name'] for row in summary['cases']]
    added = [name for family in declaration['families'] for name in family['names']]
    assert len(added) == len(set(added)) == 1480 and set(added).issubset(names)
    assert len(names) == len(set(names))
    assert load() == manifest
    save(OUT / 'stream-unary-runtime-focused-495.json', dict(status='passed', source=identity(SOURCE),
        accepted_source=identity(ACCEPTED_SOURCE), artifacts=identity(MANIFEST), direct=identity(DIRECT),
        harness=identity(HARNESS), focused_public=identity(FOCUSED / 'summary.json'),
        public_cases=len(names), new_public_cases=len(added),
        protocol=identity(OUT / 'stream-unary-runtime-protocol-495.json'),
        source_identity_preserved=True, compress_logs=True,
        broad_public_pending=True, full43_pending=True))
    print(json.dumps(dict(status='passed', focused_cases=len(names))), flush=True)


if __name__ == '__main__':
    tests(sys.argv[1]) if len(sys.argv) == 2 else main()
