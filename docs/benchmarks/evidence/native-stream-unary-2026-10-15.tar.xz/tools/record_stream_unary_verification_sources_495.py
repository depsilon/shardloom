"""Bind test/evidence-only corrections to the unchanged native release build."""
import difflib
import json
from pathlib import Path
import sys

from freeze_native_release_298 import ROOT, OUT, sources, sha, save

BUILD_SOURCE = OUT / 'native-release-source-streamunary494.json'
ARTIFACTS = OUT / 'native-release-artifacts-streamunary494.json'
DECLARATIONS = OUT / 'stream-unary-candidate-declarations-493b/declarations.json'
DIAGNOSIS = OUT / 'stream-unary-batch-count-diagnosis-495/summary.json'
SNAPSHOT = OUT / 'stream-unary-verification-change-495'
SOURCE = OUT / 'stream-unary-verification-source-495.json'
CHANGED = ['python/tests/test_native_unary_binding.py', 'scripts/run_native_streaming_input_uat.py']
ADDED = ['python/tests/test_native_streaming_uat_compression.py']
REFERENCE = ROOT / 'scripts/native_streaming_unary_reference_fixtures.json'


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def prepare():
    frozen = json.loads(BUILD_SOURCE.read_text())
    assert sources() == frozen['source_sha256']
    assert json.loads(DIAGNOSIS.read_text())['status'] == 'passed'
    assert not SNAPSHOT.exists() and not SOURCE.exists()
    SNAPSHOT.mkdir()
    originals = []
    for name in CHANGED:
        path = SNAPSHOT / Path(name).name
        with path.open('xb') as stream:
            stream.write((ROOT / name).read_bytes())
        assert sha(path) == frozen['source_sha256'][name]
        originals.append(dict(relative_path=name, original=identity(path)))
    save(SNAPSHOT / 'before.json', dict(status='frozen_before_correction',
        source=identity(BUILD_SOURCE), artifacts=identity(ARTIFACTS), originals=originals,
        diagnosis=identity(DIAGNOSIS), storage_plan=identity(OUT / 'stream-unary-log-storage-plan-495.json'),
        helper=identity(__file__), expected_changes=CHANGED, expected_additions=ADDED))
    print(json.dumps(dict(status='frozen_before_correction', files=len(originals))), flush=True)


def main():
    frozen = json.loads(BUILD_SOURCE.read_text())
    before = json.loads((SNAPSHOT / 'before.json').read_text())
    assert before['source'] == identity(BUILD_SOURCE) and before['artifacts'] == identity(ARTIFACTS)
    current = sources()
    original = frozen['source_sha256']
    changed = sorted(name for name in original if current.get(name) != original[name])
    added = sorted(set(current) - set(original))
    assert changed == CHANGED and added == ADDED and len(current) == 2283
    assert all(current[name] == digest for name, digest in original.items() if name not in CHANGED)
    declaration = json.loads(DECLARATIONS.read_text())
    assert sha(REFERENCE) == declaration['original_reference_sha256']
    assert all(sha(ROOT / name) == digest for name, digest in declaration['source_sha256'].items()
               if name not in CHANGED)
    transitions = []
    for item in before['originals']:
        name = item['relative_path']
        original_path = Path(item['original']['path'])
        assert identity(original_path) == item['original']
        diff = ''.join(difflib.unified_diff(original_path.read_text().splitlines(keepends=True),
                    (ROOT / name).read_text().splitlines(keepends=True), fromfile='before/' + name,
                    tofile='after/' + name))
        diff_path = SNAPSHOT / (Path(name).name + '.diff')
        with diff_path.open('x') as stream:
            stream.write(diff)
        transitions.append(dict(relative_path=name, before=item['original'],
                               after=identity(ROOT / name), diff=identity(diff_path)))
    artifacts = json.loads(ARTIFACTS.read_text())
    assert artifacts['source_sha256'] == original
    for kind in ('cli', 'binding'):
        assert identity(artifacts[kind]['path']) == {key: artifacts[kind][key] for key in ('path', 'bytes', 'sha256')}
    assert not SOURCE.exists()
    save(SOURCE, dict(status='frozen_for_verification', head=frozen['head'],
        source_sha256=current, build_source=identity(BUILD_SOURCE), artifacts=identity(ARTIFACTS),
        source_files=len(current), changed_files=CHANGED, added_files=ADDED,
        transitions=transitions, extra_reference=identity(REFERENCE),
        original_declarations=identity(DECLARATIONS), before=identity(SNAPSHOT / 'before.json'),
        diagnosis=identity(DIAGNOSIS), helper=identity(__file__),
        rust_sources_changed=False, public_python_runtime_changed=False,
        compiled_artifacts_changed=False, semantic_expected_values_changed=False,
        original_failed_direct_retained=True, verification_pending=True))
    print(json.dumps(dict(status='frozen_for_verification', source_files=len(current),
                          changed=changed, added=added, native_artifacts_preserved=True)), flush=True)


if __name__ == '__main__':
    prepare() if sys.argv[1:] == ['prepare'] else main()
