# Stream unary denial inventory refresh

Status: **COMPLETE**. This is a read-only refresh and exact-text proposal map; it does not certify unary streaming execution.

Worktree HEAD: `e859b3a8b9d323587cee9641f5ebacd21e7e799c`. Prior inventory SHA-256: `b10c01106ce69de7d181f92254b553a2ff75fe068de7dfa377d8c1aa5378338e`. Contract SHA-256: `b1455ca25c574f909b82eae05c462ae404df9e28909453f9590bbd833197dcdc`.

Mechanically checked all 30 prior findings against current file bytes: 24 unchanged, 1 with changed file identity but preserved cited lines, and 5 superseded/citation-changed. Immutable Git baseline entries were reverified against their recorded revision. Earlier dirty-worktree snapshots have no immutable object; their recorded hashes/excerpts are compared with current identities and cited lines, and an old full-file hash cannot be independently reconstituted where the worktree source changed.

The current API docstring now lists the nine target families, so the old omission is superseded. Its new unqualified admission language should carry the contract's in-progress status. Proposed documentation text does not claim tests, hosted checks, release support, or unary-state spill.

The exact-text map contains 7 entries. It covers the Python API docstring, native spill/resident-result references, capability index, website MDX, its sync-content generator, and the generated page derivative. The release matrix is reviewed separately: existing historical input-composition and pivot rows remain accurate and are preserved; this refresh does not invent a completed row for an in-progress phase.

Preserved boundary statements: 9. These include historical 0.6.0 limits, dynamic-pivot scope, pivot-specific direct-prepared-unary residence, and unary-state spill denials.

No repository files were changed. No tests, builds, UAT, hosted checks, or site regeneration were run.

The JSON report contains every prior entry's source identities and excerpt checks, each mapping's exact source text/hash/lines and proposed replacement, and the unchanged historical/pivot boundaries.
