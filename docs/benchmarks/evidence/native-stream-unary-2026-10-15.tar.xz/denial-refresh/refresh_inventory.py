#!/usr/bin/env python3
"""Read-only refresh of the stream-unary denial inventory and doc-text map."""
from __future__ import annotations

import hashlib
import json
import pathlib
import subprocess
from datetime import datetime, timezone

ROOT = pathlib.Path("/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo")
OUT = pathlib.Path("/Users/dylan/LocalData/shardloom/native-python-surface-20261010/stream-unary-denial-refresh-494")
PRIOR = pathlib.Path("/Users/dylan/LocalData/shardloom/native-python-surface-20261010/stream-unary-denial-inventory-493/stream-unary-denial-inventory-493.json")
CONTRACT = "docs/architecture/native-stream-unary-2026-10-15.md"

def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def read(path: str) -> bytes:
    return (ROOT / path).read_bytes()

def lines_for(b: bytes, start: int, end: int, numbered: bool = False) -> str:
    ls = b.decode("utf-8").splitlines()
    if end > len(ls):
        raise ValueError(f"line range {start}-{end} exceeds {len(ls)} lines")
    vals = ls[start - 1:end]
    return "\n".join((f"{n}: {line}" if numbered else line) for n, line in zip(range(start, end + 1), vals))

def git_blob(revision: str, path: str) -> bytes:
    return subprocess.check_output(["git", "show", f"{revision}:{path}"], cwd=ROOT)

prior_bytes = PRIOR.read_bytes()
prior = json.loads(prior_bytes)
current_head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
git_status = subprocess.check_output(["git", "status", "--short", "--branch"], cwd=ROOT, text=True).splitlines()

verified = []
for i, f in enumerate(prior["findings"]):
    snap = f["snapshot"]
    if snap == "worktree":
        # The old dirty snapshot is not an immutable Git object. Today's bytes
        # still let us check identity equality and all cited excerpts.
        source = read(f["path"])
        frozen_id = "previous_worktree_snapshot_not_immutable"
    else:
        rev = snap.split(":", 1)[1]
        source = git_blob(rev, f["path"])
        frozen_id = rev
    baseline_hash = sha(source)
    baseline_excerpt_checks = []
    for e in f["excerpts"]:
        actual = lines_for(source, e["start_line"], e["end_line"], numbered=True)
        baseline_excerpt_checks.append({
            "start_line": e["start_line"], "end_line": e["end_line"],
            "exact_match": actual == e["text"],
        })
    current = read(f["path"])
    current_hash = sha(current)
    current_excerpt_checks = []
    for e in f["excerpts"]:
        actual = lines_for(current, e["start_line"], e["end_line"], numbered=True)
        current_excerpt_checks.append({
            "prior_start_line": e["start_line"], "prior_end_line": e["end_line"],
            "exact_at_prior_lines": actual == e["text"],
            "current_excerpt_at_prior_lines": actual,
        })
    base_ok = baseline_hash == f["sha256"] and all(x["exact_match"] for x in baseline_excerpt_checks)
    cur_exact = current_hash == f["sha256"] and all(x["exact_at_prior_lines"] for x in current_excerpt_checks)
    excerpts_exact = all(x["exact_at_prior_lines"] for x in current_excerpt_checks)
    if cur_exact:
        disposition = "unchanged"
    elif excerpts_exact:
        disposition = "identity_changed_cited_excerpts_preserved"
    else:
        disposition = "superseded_or_citation_changed"
    verified.append({
        "prior_index": i,
        "path": f["path"],
        "prior_snapshot": snap,
        "prior_snapshot_revision_or_label": frozen_id,
        "prior_sha256": f["sha256"], "prior_bytes": f["bytes"],
        "prior_identity_reproduced_from_immutable_source": base_ok if snap != "worktree" else None,
        "prior_dirty_snapshot_hash_matches_current": baseline_hash == f["sha256"] if snap == "worktree" else None,
        "prior_snapshot_bytes_recoverable": snap != "worktree",
        "prior_excerpt_checks_against_recorded_snapshot": (baseline_excerpt_checks if snap != "worktree" or baseline_hash == f["sha256"] else None),
        "prior_dirty_excerpt_recheck_status": ("reproduced_from_current_bytes_because_file_hash_matches" if snap == "worktree" and baseline_hash == f["sha256"] else "not_recoverable_after_dirty_file_identity_changed" if snap == "worktree" else "verified_from_immutable_revision"),
        "current_sha256": current_hash, "current_bytes": len(current),
        "current_identity_equal": current_hash == f["sha256"],
        "current_cited_excerpt_checks": current_excerpt_checks,
        "disposition": disposition,
        "classification": f["classification"],
    })

def mapping(id_, path, start, end, proposed, reason, action="replace_exact_span"):
    b = read(path)
    return {
        "id": id_, "path": path, "current_sha256": sha(b), "current_bytes": len(b),
        "line_start": start, "line_end": end,
        "old_text_exact": lines_for(b, start, end),
        "proposed_text": proposed,
        "action": action,
        "reason_and_boundary": reason,
    }

proposal = "The current `NATIVE-STREAM-UNARY` unit targets nine existing statically bound unary families over finite input: DISTINCT, drop duplicates, duplicate masks, tail, sampling, scalar rewrites, melt, explode, and rolling. Implementation and verification remain in progress; this is not an accepted or released support claim. Unary membership and population state remains resident under the query grant, and replay spill does not add unary-state spill support. See the [implementation contract](../architecture/native-stream-unary-2026-10-15.md)."
proposal_site = "The current `NATIVE-STREAM-UNARY` unit targets nine existing statically bound unary families over finite input: DISTINCT, drop duplicates, duplicate masks, tail, sampling, scalar rewrites, melt, explode, and rolling. Implementation and verification remain in progress; this is not an accepted or released support claim. Unary membership and population state remains resident under the query grant, and replay spill does not add unary-state spill support. See the [implementation contract](https://github.com/depsilon/shardloom/blob/main/docs/architecture/native-stream-unary-2026-10-15.md)."

maps = [
    mapping("python_api_progress_qualifier", "python/src/shardloom/query.py", 8965, 8970,
        "    ``streaming=True`` unary composition is being implemented for nine existing statically bound stages: distinct, deduplication, duplicate masks, tail, sampling, scalar rewrites, melt, explode and rolling. Implementation and verification remain in progress; this is not yet an accepted or released support claim.",
        "The prior omission is superseded by a dirty-worktree docstring edit. Qualify the new unearned admission wording according to the in-progress contract; do not imply state spill."),
    mapping("native_query_spill_omission", "docs/reference/native-query-spill.md", 139, 141,
        "Distinct finite `streaming=True` batch sources can compose filters, projections, sorting,\naggregation, joins, analytic windows, dynamic pivot and limits alongside ordinary\nfile/resident sources.\n\n" + proposal,
        "Insert an in-progress status paragraph after the current operator list. This avoids changing accepted scope and preserves the unary resident-state/no-spill boundary.", action="insert_after_exact_span"),
    mapping("resident_results_omission", "docs/reference/resident-native-results.md", 72, 75,
        "Opt-in `streaming=True` consumes distinct finite batch sources once each, retaining at\nmost one native input batch across the transaction. Current source composes\nScan/Filter/Project, Sort, Limit, Aggregate, Join, Window and dynamic Pivot alongside ordinary\nfile/resident sources.\n\n" + proposal,
        "Insert an in-progress status paragraph after the current-source list; leave listed admitted behavior unchanged.", action="insert_after_exact_span"),
    mapping("surface_index_current_source_omission", "docs/reference/shardloom-user-surface-index.md", 151, 153,
        "admit `streaming=True` for finite batch sources used once each through\nScan/Filter/Project/Sort/Limit/Aggregate/Join/Window/PivotRows/Set alongside ordinary file/resident\nsources.\n\n" + proposal,
        "Insert current phase status after the current-source list, avoiding a premature capability claim. Preserve completed set/source contracts and completion boundaries.", action="insert_after_exact_span"),
    mapping("website_python_surface_insertion", "website-src/src/content/docs/field-guide/python-surface.mdx", 212, 212,
        "Hosted integration remains pending; the 0.6.0 packages keep their release-time scope.\n\n" + proposal_site,
        "Add a distinct current-source status paragraph after set integration. This does not change historical 0.6.0 scope or add test, hosted, package or performance claims.", action="insert_after_exact_span"),
    mapping("website_sync_generator_insertion", "website-src/scripts/sync-content.mjs", 648, 648,
        "Hosted integration remains pending; the 0.6.0 packages keep their release-time scope.\n\n" + proposal_site,
        "Mirror the MDX addition in the sync-content template so generated content stays consistent; do not claim verification or publication.", action="insert_after_exact_span"),
    mapping("generated_website_derivative", "website/field-guide/python-surface/index.html", 220, 220,
        "Hosted integration remains pending; the 0.6.0 packages keep their release-time scope.</p>\n<p>The current <code>NATIVE-STREAM-UNARY</code> unit targets nine existing statically bound unary families over finite input: DISTINCT, drop duplicates, duplicate masks, tail, sampling, scalar rewrites, melt, explode, and rolling. Implementation and verification remain in progress; this is not an accepted or released support claim. Unary membership and population state remains resident under the query grant, and replay spill does not add unary-state spill support. See the <a href=\"https://github.com/depsilon/shardloom/blob/main/docs/architecture/native-stream-unary-2026-10-15.md\">implementation contract</a>.</p>",
        "Regenerate this derived page from the matching MDX and sync-content source changes instead of hand-editing HTML. Keep the 0.6.0 paragraph unchanged.", action="regenerate_from_source"),
]

release_path = "docs/release/v1-inclusion-scope-matrix.md"
release_bytes = read(release_path)
release_review = {
    "path": release_path, "current_sha256": sha(release_bytes), "current_bytes": len(release_bytes),
    "checks": [
        {"lines": "57", "exact_text": lines_for(release_bytes, 57, 57), "decision": "preserve",
         "reason": "NATIVE-STREAM-INPUT-COMPOSITION remains historical completed scope; its boundary still says other stateful families stay open, which remains accurate while NATIVE-STREAM-UNARY is in progress."},
        {"lines": "65", "exact_text": lines_for(release_bytes, 65, 65), "decision": "preserve",
         "reason": "This is a pivot-owned row. Its direct prepared unary resident boundary is pivot-specific and remains in force."},
        {"lines": "no NATIVE-STREAM-UNARY row", "exact_text": "", "decision": "no row proposed in this refresh",
         "reason": "The phase plan marks the new unit unchecked and the contract says implementation/verification are in progress. Do not invent a completed row or populate acceptance/hosted evidence; the matrix schema needs primary-owner review before adding an in-progress row."},
    ],
}

preserved = []
for path, start, end, why in [
    ("website-src/src/content/docs/field-guide/python-surface.mdx", 165, 184, "0.6.0 package limitation text is historical and remains release-scoped."),
    ("website-src/src/content/docs/field-guide/python-surface.mdx", 214, 220, "0.6.0 dynamic pivot admission is historical and remains separate from static unary completion."),
    ("website-src/src/content/docs/field-guide/runtime-and-io.mdx", 261, 274, "0.6.0 streaming scope and historical acceptance are not rewritten by this current-source unit."),
    ("website-src/src/content/docs/field-guide/runtime-and-io.mdx", 280, 293, "Pivot-specific history and ownership remains intact."),
    ("website-src/src/content/docs/field-guide/limitations.mdx", 137, 140, "Direct prepared unary pivot residency and 0.6.0 streaming-pivot admission are pivot-specific/historical."),
    ("python/README.md", 779, 784, "The direct prepared unary resident statement is inside the pivot section and remains pivot-specific."),
    ("docs/reference/shardloom-user-surface-index.md", 416, 422, "The direct prepared unary resident statement is pivot-specific; spill does not expand pivot domains."),
    ("docs/architecture/native-typed-unary-2026-10-03.md", 154, 158, "Unary state spill refusal remains a distinct resource boundary, not a finite-input refusal."),
    ("docs/architecture/native-unary-composition-2026-10-02.md", 36, 38, "Legacy unary composition document's separate unary state spill denial remains intact."),
]:
    b = read(path)
    preserved.append({"path": path, "sha256": sha(b), "line_start": start, "line_end": end,
                      "exact_text": lines_for(b, start, end), "reason_to_preserve": why})

contract_bytes = read(CONTRACT)
out = {
    "schema_version": "shardloom.stream_unary_denial_refresh.v1",
    "status": "COMPLETE",
    "worktree": {"path": str(ROOT), "head": current_head, "status_lines": git_status,
                 "repository_files_modified_by_this_refresh": False},
    "prior_inventory": {"path": str(PRIOR), "bytes": len(prior_bytes), "sha256": sha(prior_bytes),
                        "findings": len(prior["findings"]),
                        "immutable_prior_snapshots_verified": all(x["prior_identity_reproduced_from_immutable_source"] for x in verified if x["prior_snapshot_bytes_recoverable"]),
                        "all_current_file_identities_and_cited_lines_checked": len(verified) == len(prior["findings"]),
                        "prior_dirty_snapshots_recoverable": sum(x["prior_snapshot_bytes_recoverable"] is False for x in verified),
                        "prior_dirty_snapshots_current_hash_matches": sum(x["prior_dirty_snapshot_hash_matches_current"] is True for x in verified),
                        "unchanged": sum(x["disposition"] == "unchanged" for x in verified),
                        "identity_changed_citations_preserved": sum(x["disposition"] == "identity_changed_cited_excerpts_preserved" for x in verified),
                        "superseded_or_citation_changed": sum(x["disposition"] == "superseded_or_citation_changed" for x in verified),
                        "entries": verified},
    "scope_contract": {"path": CONTRACT, "sha256": sha(contract_bytes), "bytes": len(contract_bytes),
                       "status_text": "implementation in progress under NATIVE-STREAM-UNARY",
                       "target_families": ["DISTINCT", "drop duplicates", "duplicate masks", "tail", "sampling", "scalar rewrites", "melt", "explode", "rolling"],
                       "not_authorized_claims": ["accepted streaming execution", "tests passed", "hosted checks passed", "release/package support", "unary-state spill"],
                       "retained_boundary": "Unary membership/population state remains resident; replay spilling does not add unary-state spill support."},
    "exact_text_replacement_map": maps,
    "release_scope_matrix_review": release_review,
    "statements_preserved": preserved,
    "counts": {"prior_entries": len(verified), "replacement_map_entries": len(maps), "release_matrix_review_points": len(release_review["checks"]), "preserved_boundary_statements": len(preserved)},
    "verification_note": "Read-only source inventory and exact-text proposals only. No build, test, UAT, hosted verification, website regeneration, or repository edit was performed.",
}
out_path = OUT / "stream-unary-denial-refresh-494.json"
out_path.write_text(json.dumps(out, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

lines = [
    "# Stream unary denial inventory refresh",
    "",
    f"Status: **{out['status']}**. This is a read-only refresh and exact-text proposal map; it does not certify unary streaming execution.",
    "",
    f"Worktree HEAD: `{current_head}`. Prior inventory SHA-256: `{sha(prior_bytes)}`. Contract SHA-256: `{sha(contract_bytes)}`.",
    "",
    f"Mechanically checked all {len(verified)} prior findings against current file bytes: {out['prior_inventory']['unchanged']} unchanged, {out['prior_inventory']['identity_changed_citations_preserved']} with changed file identity but preserved cited lines, and {out['prior_inventory']['superseded_or_citation_changed']} superseded/citation-changed. Immutable Git baseline entries were reverified against their recorded revision. Earlier dirty-worktree snapshots have no immutable object; their recorded hashes/excerpts are compared with current identities and cited lines, and an old full-file hash cannot be independently reconstituted where the worktree source changed.",
    "",
    "The current API docstring now lists the nine target families, so the old omission is superseded. Its new unqualified admission language should carry the contract's in-progress status. Proposed documentation text does not claim tests, hosted checks, release support, or unary-state spill.",
    "",
    f"The exact-text map contains {len(maps)} entries. It covers the Python API docstring, native spill/resident-result references, capability index, website MDX, its sync-content generator, and the generated page derivative. The release matrix is reviewed separately: existing historical input-composition and pivot rows remain accurate and are preserved; this refresh does not invent a completed row for an in-progress phase.",
    "",
    f"Preserved boundary statements: {len(preserved)}. These include historical 0.6.0 limits, dynamic-pivot scope, pivot-specific direct-prepared-unary residence, and unary-state spill denials.",
    "",
    "No repository files were changed. No tests, builds, UAT, hosted checks, or site regeneration were run.",
    "",
    "The JSON report contains every prior entry's source identities and excerpt checks, each mapping's exact source text/hash/lines and proposed replacement, and the unchanged historical/pivot boundaries.",
]
(OUT / "stream-unary-denial-refresh-494.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
print(json.dumps({"json": str(out_path), "md": str(OUT / "stream-unary-denial-refresh-494.md"), "counts": out["counts"], "all_current_evidence_checked": out["prior_inventory"]["all_current_file_identities_and_cited_lines_checked"], "immutable_baselines_verified": out["prior_inventory"]["immutable_prior_snapshots_verified"]}, indent=2))
