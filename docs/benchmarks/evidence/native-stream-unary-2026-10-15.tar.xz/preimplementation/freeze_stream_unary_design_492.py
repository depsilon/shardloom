"""Bind predeclared unary controls and references to the merged set-operation base."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

from freeze_native_release_298 import ROOT, OUT, sources

BASE = 'e859b3a8b9d323587cee9641f5ebacd21e7e799c'


def read(path):
    return json.loads(Path(path).read_text())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


def main():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
    prior = read(OUT / 'stream-sets-import-correction-489/protocol.json')['source_sha256']
    current = sources()
    assert current == prior and len(current) == 2272
    anchors = read(OUT / 'native-unary-streaming-test-anchors-484.json')
    refreshed = []
    for row in anchors['source_hash_verification']['checks']:
        path = row['path']
        raw = subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=ROOT)
        assert raw == (ROOT / path).read_bytes()
        refreshed.append(dict(path=path, sha256=digest(raw),
                              inventory_sha256=row['inventory_sha256']))
    changed = [r['path'] for r in refreshed if r['sha256'] != r['inventory_sha256']]
    assert changed == ['shardloom-vortex/src/local_primitive_relational_batch_input.rs']
    fixture = read(OUT / 'stream-unary-reference-fixtures-486.json')
    assert len(fixture['sampling_cases']) == 54 and len(fixture['rolling_cases']) == 120
    assert fixture['engine_executions'] == 0
    for path, expected in fixture['source_sha256'].items():
        assert digest((ROOT / path).read_bytes()) == expected
    baseline_path = OUT / 'stream-unary-baseline-487/summary.json'
    baseline = read(baseline_path)
    assert baseline['status'] == 'passed' and len(baseline['cases']) == 18
    assert all(row['status'] == 'passed' for row in baseline['cases'])
    assert identity(baseline['binary']['path']) == {key: baseline['binary'][key] for key in ('path', 'bytes', 'sha256')}
    job = read(OUT / 'stream-unary-baseline-run-487.json')
    assert job['status'] == 'passed' and job['returncode'] == 0
    assert job['direct_child_reaped'] and job['process_group_drained']
    assert identity(OUT / 'stream-unary-baseline-run-487.log')['sha256'] == job['log_sha256']
    declarations = read(OUT / 'unary-public-draft-declarations-491.json')
    hosted = read(ROOT / 'docs/benchmarks/evidence/native-stream-sets-hosted-2026-10-15.json')
    assert hosted['status'] == 'passed' and hosted['merge'] == BASE and hosted['checks_passed'] == 44
    audit_path = OUT / 'stream-sets-hosted-audit-492/stream-sets-hosted-packet-audit-492.json'
    audit = read(audit_path)
    assert audit['status'] == 'COMPLETE' and audit['members']['regular'] == 107
    assert audit['packet']['sha256'] == hosted['archive']['sha256']
    assert audit['source_hashes_verified_against_merge_blobs'] == 2272
    names = [
        'draft_native_stream_unary_tests_489.rs',
        'draft_native_stream_unary_fault_tests_490.rs',
        'draft_native_stream_unary_pressure_tests_490.rs',
        'draft_native_streaming_unary_cases_491.py',
        'draft_native_streaming_unary_reference_cases_491.py',
        'draft_stream_unary_references_486.py',
        'stream-unary-reference-fixtures-486.json',
        'stream-unary-reference-primary-acceptance-486.json',
        'stream-unary-refusal-primary-acceptance-487.json',
        'unary-public-draft-declarations-491.json',
        'verify_stream_unary_baseline_487.py',
    ]
    result = dict(schema_version='shardloom.native_stream_unary_preimplementation.v1',
        status='passed_preimplementation_identity', recorded_at=datetime.now(timezone.utc).isoformat(),
        base=BASE, source_sha256=current, inventory_sources=refreshed,
        inventory_changes_since_prior_base=changed,
        baseline=identity(baseline_path), baseline_execution=identity(OUT / 'stream-unary-baseline-run-487.json'),
        baseline_cases=18, streaming_refusals=9, resident_controls=9,
        predeclared_sampling_cases=54, predeclared_rolling_cases=120,
        prepared_inputs=[identity(OUT / name) for name in names],
        contract=identity(ROOT / 'docs/architecture/native-stream-unary-2026-10-15.md'),
        preceding_hosted_packet=identity(ROOT / 'docs/benchmarks/evidence/native-stream-sets-hosted-2026-10-15.json'),
        preceding_hosted_independent_audit=identity(audit_path),
        preceding_hosted_audit_helper=identity(OUT / 'stream-sets-hosted-audit-492/check_stream_sets_hosted_packet_492.py'),
        primary_audit_acceptance='Complete checker reviewed. Archive/member hashes, immutable source selection, raw native counters and served-source checks agree with primary verification. Primary verifier separately decodes full wheel/core proof objects; browser observations remain manual.',
        helper=identity(__file__), runtime_changed=False, candidate_executed=False,
        scope='Prior runtime controls and independent expected-value declarations only. Candidate native/public acceptance, pressure owner checks and hosted integration remain required.')
    with (OUT / 'native-stream-unary-design-492.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(status=result['status'], sources=len(current),
        refreshed_inventory_sources=len(refreshed), baseline_cases=18,
        predeclared_sampling_cases=54, predeclared_rolling_cases=120)))


if __name__ == '__main__':
    main()
