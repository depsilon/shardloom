#!/usr/bin/env python3
"""Mechanically inspect predeclared unary reference fixtures; never runs ShardLoom."""

from __future__ import annotations

import hashlib
import importlib.util
import json
from fractions import Fraction
from pathlib import Path
import re
import subprocess
import sys


ROOT = Path("/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo")
OUT = Path("/Users/dylan/LocalData/shardloom/native-python-surface-20261010")
HELPER_INPUT = OUT / "draft_stream_unary_references_486.py"
FIXTURE_INPUT = OUT / "stream-unary-reference-fixtures-486.json"
REPORT_PATH = OUT / "stream-unary-reference-inspection-486.json"
REVISION = "54f107d4add9d1d218f0f78e47c8d6f76785120a"
U64 = (1 << 64) - 1
SOURCE_PATHS = [
    "shardloom-vortex/src/local_primitives.rs",
    "shardloom-vortex/src/local_primitive_unary_sample.rs",
    "shardloom-vortex/src/local_primitive_unary_rolling.rs",
    "shardloom-vortex/src/local_primitives/rolling_observation.rs",
    "python/src/shardloom/query.py",
]
TEST_NAME = "composed_unary_sampling_preserves_seed_weight_fraction_replacement_and_hidden_columns"
TEST_PATH = "shardloom-vortex/src/local_primitive_relational_unary_tests.rs"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def check(name: str, passed: bool, detail: str) -> dict[str, object]:
    return {"name": name, "passed": bool(passed), "detail": detail}


def test_excerpt() -> tuple[str, list[int], str, list[str]]:
    raw = subprocess.check_output(["git", "-C", str(ROOT), "show", f"{REVISION}:{TEST_PATH}"])
    source = raw.decode("utf-8")
    declaration = re.search(r"(?m)^fn " + re.escape(TEST_NAME) + r"\(\)\s*\{", source)
    if declaration is None:
        raise ValueError(f"exact test declaration not found in {REVISION}:{TEST_PATH}")
    start = declaration.start()
    # The test body has only ordinary Rust strings; skip quoted strings and comments while
    # matching braces so the extracted closing brace is the function's closing brace.
    i = declaration.end() - 1
    depth = 0
    state = "code"
    while i < len(source):
        c = source[i]
        nxt = source[i + 1] if i + 1 < len(source) else ""
        if state == "code":
            if c == "/" and nxt == "/":
                state = "line"
                i += 2
                continue
            if c == "/" and nxt == "*":
                state = "block"
                i += 2
                continue
            if c == '"':
                state = "string"
                i += 1
                continue
            if c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    end = i + 1
                    break
            i += 1
            continue
        if state == "line":
            if c == "\n":
                state = "code"
            i += 1
            continue
        if state == "block":
            if c == "*" and nxt == "/":
                state = "code"
                i += 2
            else:
                i += 1
            continue
        if state == "string":
            if c == "\\":
                i += 2
            elif c == '"':
                state = "code"
                i += 1
            else:
                i += 1
    else:
        raise ValueError("could not find complete test function source")
    line_start = source.rfind("\n", 0, start) + 1
    attribute_start = source.rfind("\n", 0, line_start - 1) + 1
    if source[attribute_start:line_start].strip() != "#[test]":
        raise ValueError("test function is not immediately preceded by #[test]")
    full_start = attribute_start
    full = source[full_start:end]
    line_begin = source.count("\n", 0, full_start) + 1
    line_end = source.count("\n", 0, end) + 1
    return full, [line_begin, line_end], sha256(raw), ["#[test]"]


def main() -> int:
    fixture_bytes = FIXTURE_INPUT.read_bytes()
    fixture = json.loads(fixture_bytes)
    helper_bytes = HELPER_INPUT.read_bytes()
    actual_helper_hash = sha256(helper_bytes)
    failures: list[str] = []
    checks: list[dict[str, object]] = []

    fixture_helper_matches = fixture.get("helper_sha256") == actual_helper_hash
    checks.append(check("fixture helper identity", fixture_helper_matches,
                        f"fixture={fixture.get('helper_sha256')} actual={actual_helper_hash}"))
    if not fixture_helper_matches:
        failures.append("fixture helper identity mismatch")

    source_checks = []
    declared_hashes = fixture.get("source_sha256", {})
    source_hashes_match = set(declared_hashes) == set(SOURCE_PATHS)
    for path in SOURCE_PATHS:
        actual = sha256((ROOT / path).read_bytes())
        declared = declared_hashes.get(path)
        matches = actual == declared
        source_checks.append({"path": path, "fixture_sha256": declared,
                              "actual_sha256": actual, "matches": matches})
        source_hashes_match = source_hashes_match and matches
        if not matches:
            failures.append(f"source hash mismatch: {path}")
    checks.append(check("five source file identities", source_hashes_match,
                        f"checked={len(source_checks)} exact path/hash pairs"))

    # Import only the fixture generator's pure ordinal selector; its main() is not invoked.
    spec = importlib.util.spec_from_file_location("draft_stream_unary_references_486", HELPER_INPUT)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load the pure fixture helper")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)

    rows = fixture.get("sampling_rows")
    cases = fixture.get("sampling_cases")
    rolling_values = fixture.get("rolling_values")
    rolling_cases = fixture.get("rolling_cases")
    sampling_ok = isinstance(rows, list) and len(rows) == 12 and isinstance(cases, list)
    if not sampling_ok:
        failures.append("sampling base rows/cases malformed")
        rows, cases = [], []
    names = [case.get("name") for case in cases]
    count_cases = [case for case in cases if "frac" not in case.get("options", {})
                   and case.get("name", "").startswith("sample-seed-")]
    fraction_cases = [case for case in cases if "frac" in case.get("options", {})]
    tie_cases = [case for case in cases if case.get("name") == "sample-tied-negative-infinity-scores-preserve-earliest-ordinals"]
    empty_cases = [case for case in cases if case.get("name") == "sample-empty-population"]
    expected_count_product = {
        (seed, weighted, replace, n)
        for seed in (0, 7, U64)
        for weighted in (False, True)
        for replace in (False, True)
        for n in (1, 5, 15)
    }
    observed_count_product = {
        (case["options"].get("random_state"), case["options"].get("weights") is not None,
         case["options"].get("replace"), case["options"].get("n"))
        for case in count_cases
    }
    count_matrix_ok = len(count_cases) == 36 and observed_count_product == expected_count_product
    checks.append(check("36 count sampling product", count_matrix_ok,
                        f"cases={len(count_cases)} exact_product={observed_count_product == expected_count_product}"))
    if not count_matrix_ok:
        failures.append("count sampling product mismatch")

    expected_fraction_product = {
        (fraction, weighted, replace, target)
        for fraction, target in ((0.25, 3), (0.5, 6), (0.75, 9), (1.0, 12))
        for weighted in (False, True)
        for replace in (False, True)
    }
    observed_fraction_product = {
        (case["options"].get("frac"), case["options"].get("weights") is not None,
         case["options"].get("replace"), case.get("declared_target"))
        for case in fraction_cases
    }
    fraction_matrix_ok = len(fraction_cases) == 16 and observed_fraction_product == expected_fraction_product
    checks.append(check("16 fraction sampling product", fraction_matrix_ok,
                        f"cases={len(fraction_cases)} exact_product={observed_fraction_product == expected_fraction_product}"))
    if not fraction_matrix_ok:
        failures.append("fraction sampling product mismatch")

    sampling_rows_match = True
    sampling_order_unique = True
    for case in cases:
        ordinals = case.get("ordinals")
        expected = case.get("expected")
        options = case.get("options", {})
        case_rows = case.get("rows", rows)
        if not isinstance(ordinals, list) or not isinstance(expected, list):
            sampling_rows_match = False
            sampling_order_unique = False
            continue
        if any(type(o) is not int or o < 0 or o >= len(case_rows) for o in ordinals):
            sampling_rows_match = False
            continue
        if [case_rows[o] for o in ordinals] != expected:
            sampling_rows_match = False
        target = options.get("n")
        if target is None and "frac" in options:
            target = case.get("declared_target")
        replace = options.get("replace", False)
        required_count = min(target, len(case_rows)) if case_rows and not replace else (target if case_rows else 0)
        if len(ordinals) != required_count:
            sampling_order_unique = False
        if not replace and (len(set(ordinals)) != len(ordinals) or ordinals != sorted(ordinals)):
            sampling_order_unique = False
        if replace and len(ordinals) != required_count:
            sampling_order_unique = False
    sample_count_ok = sampling_rows_match and sampling_order_unique and len(cases) == 54 and len(set(names)) == 54
    checks.append(check("sampling rows, ordinals, count/order/uniqueness", sample_count_ok,
                        f"cases={len(cases)} unique_names={len(set(names))} rows_match={sampling_rows_match} constraints={sampling_order_unique}"))
    if not sample_count_ok:
        failures.append("sampling expected rows or ordinal constraints mismatch")

    tie_ok = False
    if len(tie_cases) == 1:
        tie = tie_cases[0]
        tie_rows = tie.get("rows", [])
        expected_ties = list(range(5))
        tie_ok = (tie.get("ordinals") == expected_ties and
                  len(tie_rows) == len(rows) and
                  all(r.get("weight") == float.fromhex("0x0.0000000000001p-1022") for r in tie_rows) and
                  tie.get("expected") == [tie_rows[i] for i in expected_ties])
    checks.append(check("tiny-positive-weight tie case", tie_ok,
                        f"tie_cases={len(tie_cases)} expected_ordinals=[0,1,2,3,4]"))
    if not tie_ok:
        failures.append("tiny-positive-weight tie fixture mismatch")
    empty_ok = (len(empty_cases) == 1 and empty_cases[0].get("rows") == [] and
                empty_cases[0].get("ordinals") == [] and empty_cases[0].get("expected") == [])
    checks.append(check("empty sampling case", empty_ok, f"empty_cases={len(empty_cases)}"))
    if not empty_ok:
        failures.append("empty sampling fixture mismatch")

    # Compare six pure selector choices to literal expected vectors in the existing Rust test.
    test_source, test_range, test_file_hash, test_attributes = test_excerpt()
    sorted_ids = [1, 2, 3, 4, 5]
    test_weights = [10.0, 20.0, 30.0, 40.0, 50.0]
    literal = {
        "seed7_count2_unweighted": [2, 5],
        "seed7_count2_weighted": [2, 5],
        "seed7_fraction_target2_unweighted": [2, 5],
        "seed7_fraction_target2_weighted": [2, 5],
        "seed11_replacement_count7_unweighted": [4, 2, 5, 4, 4, 2, 5],
        "seed11_replacement_count7_weighted": [5, 2, 2, 5, 4, 4, 3],
    }
    actual_test_choices = {
        "seed7_count2_unweighted": [sorted_ids[i] for i in module.sample_ordinals(5, 2, 7)],
        "seed7_count2_weighted": [sorted_ids[i] for i in module.sample_ordinals(5, 2, 7, weights=test_weights)],
        "seed7_fraction_target2_unweighted": [sorted_ids[i] for i in module.sample_ordinals(5, 2, 7)],
        "seed7_fraction_target2_weighted": [sorted_ids[i] for i in module.sample_ordinals(5, 2, 7, weights=test_weights)],
        "seed11_replacement_count7_unweighted": [sorted_ids[i] for i in module.sample_ordinals(5, 7, 11, replace=True)],
        "seed11_replacement_count7_weighted": [sorted_ids[i] for i in module.sample_ordinals(5, 7, 11, weights=test_weights, replace=True)],
    }
    test_choices_ok = actual_test_choices == literal
    checks.append(check("six sampling choices match literal Rust expectations", test_choices_ok,
                        f"ids={sorted_ids} weights={test_weights}; choices={actual_test_choices}"))
    if not test_choices_ok:
        failures.append("six helper choices differ from literal Rust test")

    rolling_ok = isinstance(rolling_values, list) and len(rolling_values) == 8 and isinstance(rolling_cases, list)
    expected_roll_product = {
        (window, minimum, center, aggregate)
        for window in (1, 2, 3, 4, 12)
        for minimum in sorted({1, min(2, window), window})
        for center in (False, True)
        for aggregate in ("sum", "mean", "min", "max", "count")
    }
    observed_roll_product = {
        (case.get("window"), case.get("min_periods"), case.get("center"), case.get("aggregate"))
        for case in rolling_cases
    }
    rolling_product_ok = len(rolling_cases) == 120 and len(observed_roll_product) == 120 and observed_roll_product == expected_roll_product
    if not rolling_product_ok:
        failures.append("rolling product coverage mismatch")
    for case in rolling_cases:
        values = rolling_values
        window, minimum, center, aggregate = (case["window"], case["min_periods"], case["center"], case["aggregate"])
        recomputed = []
        for i in range(len(values)):
            left = (window - 1) // 2 if center else window - 1
            right = window - 1 - left if center else 0
            frame = [Fraction(v) for v in values[max(0, i-left):min(len(values), i+right+1)] if v is not None]
            if len(frame) < minimum:
                continue
            if aggregate == "count":
                result = len(frame)
            elif aggregate == "sum":
                result = float(sum(frame, Fraction(0)))
            elif aggregate == "mean":
                result = float(sum(frame, Fraction(0)) / len(frame))
            elif aggregate == "min":
                result = float(min(frame))
            else:
                result = float(max(frame))
            recomputed.append(result)
        if case.get("expected") != recomputed:
            rolling_ok = False
            failures.append(f"rolling expected list mismatch: {case.get('name')}")
    rolling_ok = rolling_ok and rolling_product_ok and len({c.get("name") for c in rolling_cases}) == 120
    checks.append(check("120 rolling cases exact Fraction frame recomputation", rolling_ok,
                        f"cases={len(rolling_cases)} unique_names={len({c.get('name') for c in rolling_cases})} product={rolling_product_ok}"))

    # Ensure the reference test source comes from the same current checkout bytes as the frozen blob.
    current_test_path = ROOT / TEST_PATH
    current_test_hash = sha256(current_test_path.read_bytes())
    current_test_matches = current_test_hash == test_file_hash
    checks.append(check("existing Rust test immutable/current identity", current_test_matches,
                        f"revision={REVISION} immutable_sha256={test_file_hash} current_sha256={current_test_hash}"))
    if not current_test_matches:
        failures.append("existing Rust test file differs in current checkout")

    helper_hash = sha256(Path(__file__).read_bytes())
    report = {
        "artifact_id": "stream-unary-reference-inspection-486",
        "inputs": {
            "helper_input_path": str(HELPER_INPUT),
            "helper_input_sha256": actual_helper_hash,
            "fixture_input_path": str(FIXTURE_INPUT),
            "fixture_input_sha256": sha256(fixture_bytes),
            "source_revision": REVISION,
            "source_files": source_checks,
            "reference_test": {
                "name": TEST_NAME,
                "path": TEST_PATH,
                "line_range_one_based": test_range,
                "sha256": test_file_hash,
                "attributes": test_attributes,
                "complete_source": test_source,
            },
        },
        "checks": checks,
        "sampling": {
            "fixture_case_count": len(cases),
            "count_matrix_case_count": len(count_cases),
            "fraction_matrix_case_count": len(fraction_cases),
            "tie_case_count": len(tie_cases),
            "empty_case_count": len(empty_cases),
            "existing_test_six_choices": {"expected": literal, "actual": actual_test_choices},
        },
        "rolling": {
            "fixture_case_count": len(rolling_cases),
            "window_values": [1, 2, 3, 4, 12],
            "minimum_value_product": sorted({1, min(2, w), w} for w in (1, 2, 3, 4, 12)),
            "aggregates": ["sum", "mean", "min", "max", "count"],
            "center_values": [False, True],
        },
        "validation_scope": "Deterministic fixture checks only; no engine or runtime was executed.",
        "checker_path": str(Path(__file__).resolve()),
        "checker_sha256": helper_hash,
        "failures": failures,
        "status": "NEEDS_REASONING" if failures else "COMPLETE",
    }
    # Correct the minimum-value product to a flat, stable list for machine readers.
    report["rolling"]["minimum_values_by_window"] = {
        str(w): sorted({1, min(2, w), w}) for w in (1, 2, 3, 4, 12)
    }
    report["rolling"].pop("minimum_value_product", None)
    REPORT_PATH.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "checks": len(checks), "failures": failures,
                      "report": str(REPORT_PATH), "checker_sha256": helper_hash}))
    return 0 if not failures else 2


if __name__ == "__main__":
    raise SystemExit(main())
