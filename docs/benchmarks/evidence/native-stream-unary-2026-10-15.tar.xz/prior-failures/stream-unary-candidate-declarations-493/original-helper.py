"""Predeclare all new public acceptance before executing the candidate runtime."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT / 'python/src'), str(ROOT / 'scripts'), str(ROOT / 'python/tests')]
import shardloom as sl
import native_streaming_unary_cases as core
import native_streaming_unary_reference_cases as reference
import native_streaming_unary_composition_cases as composition
import native_streaming_unary_fault_cases as fault
import native_streaming_unary_pressure_cases as pressure
import test_native_unary_binding as binding
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class DeclarationHarness:
    def __init__(self, destination):
        self.root = destination
        self.logs, self.output = destination / 'logs', destination / 'outputs'
        self.logs.mkdir()
        self.output.mkdir()
        self.names = []
        self.client = sl.ShardLoomClient(binary='unexecuted-predeclared-runtime')
        self.context = sl.ShardLoomContext(self.client)

    def case(self, name, _call):
        assert name not in self.names, name
        self.names.append(name)

    def json(self, path, value):
        with path.open('x') as stream:
            json.dump(value, stream, indent=2, allow_nan=False)
            stream.write('\n')


def main():
    destination = require_local_path(OUT / 'stream-unary-candidate-declarations-493', Path.home(), sys.platform)
    assert not destination.exists()
    check_budgets(OUT, destination, OUT / 'logs', min_free_bytes=12 * GIB, reserve_bytes=128 * MIB,
                  max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    destination.mkdir()
    harness = DeclarationHarness(destination)
    protocols = [('unary', core, 494), ('unary-reference', reference, 348),
                 ('unary-composition', composition, 261), ('unary-fault', fault, 331),
                 ('unary-pressure', pressure, 46)]
    records, declarations = [], []
    with patch('subprocess.Popen', side_effect=AssertionError('predeclaration cannot execute a child')):
        for name, module, count in protocols:
            start = len(harness.names)
            module.run(harness)
            names = harness.names[start:]
            assert len(names) == count, (name, len(names), count)
            records.append(dict(family=name, cases=len(names), names=names))
        assert len(harness.names) == 1480
        for kind in core.KINDS:
            for position, stages in [('before', ('filter', 'project', 'sort', 'limit', 'aggregate', 'window', 'join', 'set', 'unary')),
                                     ('after', ('limit-0', 'limit-2', 'project', 'sort', 'aggregate', 'window', 'join', 'set', 'unary'))]:
                for stage in stages:
                    if (kind, position, stage) == ('explode', 'before', 'aggregate'):
                        continue
                    rows, schema, fields = core.fixture(kind)
                    source, trace = core.frame(harness, rows, schema)
                    if position == 'before':
                        source, rows, extra, replay = composition.before(harness, source, rows, fields, stage)
                        query = core.apply(source, kind, 'sql')
                        expected, fields = core.oracle(kind, rows), core.output_fields(kind, fields)
                    else:
                        query = core.apply(source, kind, 'sql')
                        query, expected, fields, extra, replay = composition.after(
                            harness, query, core.oracle(kind, rows), core.output_fields(kind, fields), stage)
                    assert all(tuple(row) == tuple(name for name, _ in fields) for row in expected)
                    assert all(item['opened'] == 0 and not item['closed'] for item in [trace, *extra])
                    declarations.append(dict(kind=kind, position=position, stage=stage,
                        statement=query._relation_statement(), expected=expected, fields=repr(fields),
                        sources=len(extra) + 1, replay_sources=replay))
        assert len(declarations) == 233
        # Native binding expectations include narrow integers, nullable lists and typed empty output.
        for kind in binding.KINDS:
            for rows in (binding.ROWS, [], [dict.fromkeys(binding.SCHEMA)] * 3):
                fields = binding.arrow_schema(kind)
                expected = binding.expected(kind, rows)
                assert all(tuple(row) == tuple(fields.names) for row in expected), kind
                source, trace = core.frame(harness, rows, binding.SCHEMA)
                query = binding.apply(source, kind)
                assert query._relation_statement() and trace['opened'] == 0
        original = OUT / 'stream-unary-reference-fixtures-486.json'
        current = ROOT / 'scripts/native_streaming_unary_reference_fixtures.json'
        assert original.read_bytes() == current.read_bytes()
    harness.client.close()
    paths = [path for path in (ROOT / 'scripts').glob('native*unary*.py')]
    paths += [ROOT / 'scripts/native_streaming_unary_reference_fixtures.json',
              ROOT / 'scripts/run_native_streaming_input_uat.py',
              ROOT / 'scripts/native_streaming_input_cases.py',
              ROOT / 'python/tests/test_native_unary_binding.py',
              ROOT / 'python/src/shardloom/query.py']
    paths += sorted((ROOT / 'shardloom-vortex/src').glob('local_primitive_relational_batch_unary*tests.rs'))
    for path in paths:
        if path.suffix == '.py':
            ast.parse(path.read_text())
    harness.json(destination / 'declarations.json', dict(status='passed', scope='declaration and independent values only',
        engine_executions=0, public_cases=1480, families=records, compositions=declarations,
        native_binding_methods=4, native_binding_subcases=468, original_reference_sha256=sha(original),
        source_sha256={str(path.relative_to(ROOT)): sha(path) for path in paths},
        helper_sha256=sha(__file__)))
    print(json.dumps(dict(status='passed', engine_executions=0, public_cases=1480,
                         composition_declarations=len(declarations), path=str(destination))))


if __name__ == '__main__':
    main()
