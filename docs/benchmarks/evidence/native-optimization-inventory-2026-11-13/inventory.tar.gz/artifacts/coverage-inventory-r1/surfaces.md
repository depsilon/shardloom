# Shared public surfaces and cross-cutting mechanisms

Checkout: `/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo` at `cac86e8b0a5fa5fa8bf4c900dbef7a703746bfa8`.

## Route map

- **CLI SQL** — shardloom-cli/src/public_workflow_route.rs:423-589,6299-6406 → sql_native_relational::prepare_with_owner (shardloom-cli/src/sql_native_relational.rs:138-220) -> prepare_relational_with_schema_in_session_controlled -> VortexRelationalPlan / PreparedVortexRelational.
- **Python SQL** — Session.sql (shardloom-python/src/session.rs:427-490) → NativeRelationDeclaration::sql_with_bound_parameters then NativePlan::with_prepared; statement route calls native::prepare_sql_operation, typed declaration route calls prepare_admitted (shardloom-python/src/plan.rs:152-255).
- **Python typed relation** — Session.plan (shardloom-python/src/session.rs:493-519), NativeRelation builders (shardloom-python/src/relation.rs) → Typed VortexRelationalPlan and same NativePlan prepared operation.
- **Embedded workflow** — Session.workflow (shardloom-python/src/session.rs:417-425); EmbeddedExecutionOwner / command_json_in_owner (shardloom-cli/src/native_runtime.rs:71-100) → NativeWorkflowDeclaration / PreparedNativeOperation; relational workflow requests use same resident_relational preparation.
- **DataFrame** — Public route surface label dataframe; request normalization in public_workflow_route.rs:4976,5172 and route parser 5918 → Surface label enters native workflow route planner. No separate Python DataFrame class/API was located in shardloom-python/src; do not equate route label with an implemented dataframe facade.

## Mechanism boundaries

### Adaptive bounded work sizing

- Owner/caller: AdaptiveWorkSizer (exec/adaptive_work.rs:160-230); native Rows selects min_units=1, max_units=min(remaining, owner cap), max_in_flight=1; records only completed boundary in vortex/native_work_sizing.rs:100-203. Owner classes Scan/Replay/ColumnarDecode/Output/SortOutput plus feature-gated Spill/CompatibilityWriter at native_work_sizing.rs:11-50.
- Gate: Selection uses current LiveMemorySnapshot and estimated additional simultaneous workspace; sizing is allocation-free advice, caller must reserve separately; per-operation feedback, no global state/replay.
- Evidence: adaptive_native_scan/replay/columnar_decode/native_output/native_sort_output_* completed/headroom_limited/shrunk/grown/minimum_rows/maximum_rows/minimum_headroom/ceiling/peak_estimated; declined windows and required bytes; cost scope says estimate not RSS (native_work_sizing.rs:66-96).
- Tests: short_fragments_do_not_reduce_the_following_full_extent, optional_headroom_decline_is_typed_and_does_not_complete_or_advance_feedback, retained_owners_wide_values_and_lane_overlap_limit_actual_reservations, feedback_shrinks_at_next_boundary_and_regrows_only_after_two_completions, physical_candidates_preserve_metadata_cost_and_shared_growth_feedback

### Memory credit and ownership

- Owner/caller: LiveMemoryPool/MemoryLease (exec/live_memory.rs); ResidentVortexSession shared reserve and snapshots (vortex/resident_session.rs:147-199,674-680); all execution context owners use shared pool.
- Gate: Budget checks before allocation; estimates do not grant bytes; leases live with native/source/schema/output owners and drop to release.
- Evidence: reserved/peak native bytes in session snapshots; output_buffer_bytes, schema/pipeline metadata, source counts and spill reports on ExecutedVortexRelational (vortex/local_primitive_prepared_relational.rs:133-270).
- Tests: retained_owners_wide_values_and_lane_overlap_limit_actual_reservations, native_relational_plan_node_count_grows_under_shared_metadata_admission, completed_general_result_clones_keep_buffer_credit_after_all_producer_owners_drop, completed_finalization_retains_schema_credit_and_reserves_before_row_allocation

### Output coalescing under pressure

- Owner/caller: native_relational_output_buffer::push/flush (lines 100-265); executor callbacks stream chunks into reserved buffer.
- Gate: Optional compaction declines on insufficient headroom and forwards existing independently owned arrays in order; selected work is chunked and credited.
- Evidence: adaptive_native_output_*; output rows/batches/max_batch_rows/output_buffer_bytes in execution report.
- Tests: output_compaction_applies_pressure_and_bounded_regrowth_with_retained_output, output_compaction_declines_without_spending_existing_record_credits, output_compaction_drains_owners_on_consumer_error_and_cancellation

### Batch completion, cancellation, and final certification

- Owner/caller: with_batch_input APIs and execute_native/for_each_batch (batch_input.rs:378-429,1146-1227); native scan/transform check cancellation; report produced only after complete execution.
- Gate: Each declared stream consumed once; source None is required to prove end; late producer/consumer/cancel/schema errors prevent successful completion.
- Evidence: source rows/batches, scan rows/batches, completion report and certificate; no successful certificate on unfinished execution.
- Tests: completion_input_end_is_required_even_for_empty_or_filtered_results, completion_input_late_failure_cancellation_and_consumer_error_never_complete, completion_input_late_expression_failure_cannot_certify_an_emitted_prefix

### Bounded Arrow output window

- Owner/caller: OutputCreditWindow native admission called by PreparedNativeOperation Python stream path (credit_window.rs:12-18,129-167; native_runtime_operation.rs:171-205; python/stream.rs:150-230).
- Gate: Opt-in and only no file/source-path/batch sources, exactly one memory source, no spill, bound root, 1..64 primitive I64 result columns, supported project root. At most 2 unacked batches; 2 MiB each, 4 MiB aggregate; FIFO ack and exact final completion.
- Evidence: logical slots/bytes tracked; `_output_window_sent_batches` is opt-in synchronization evidence, explicitly not a completion certificate.
- Tests: credit_window_requires_fifo_unique_acknowledgments_before_more_production, credit_window_enforces_exact_inclusive_byte_bounds_without_losing_state, credit_window_admission_uses_actual_row_and_field_boundaries, credit_window_rejects_operator_and_dynamic_roots_without_running_them, credit_window_initializer_failure_precedes_output_and_cleans_reservation

### Spill and cleanup

- Owner/caller: explicit user spill parsed/validated in native_runtime.rs:269-317 before source access; prepared relational retains spill policy; operator strategy modules create native spill.
- Gate: vortex-write feature; buffer_bytes must be <= declared query memory; operator-specific bounded strategies and sink/write operations; no spill option by default.
- Evidence: VortexRelationalSpillReport plus spilled stage/input/run/read counters by aggregate/join/window/set/pivot etc; certificate write_io/spill_io_performed only if runs written (relational_report.rs:73-105,344-355).
- Tests: native relational spill suite includes refusal/cleanup and operator-specific spills; see local_primitive_relational_spill_tests.rs and local_primitive_relational_aggregate_spill_tests.rs.

### Materialization and source reuse

- Owner/caller: Materialized/Recursive native relation declarations use action-local retained result; LoweringMemo identity+position+kind memoizes lowering only (native_runtime_plan.rs:582-643; memo.rs). Python PlanCore reuses prepared op only if same resources, reusable flag and all batch inputs streaming; else clears prepared (python/plan.rs:180-247).
- Gate: No general cross-query result cache evidenced. Completed materialized relation is same action; source replay for repeated scans is explicit native replay and completion-bound.
- Evidence: relational_materialized_relations/reuses/rows and recursive counters; public `reused` output field is prepared-operation reuse.
- Tests: retained_typed_declaration_reuses_same_child_and_scopes_equal_templates_to_their_inputs, retained_parameters_named_snapshot_grouping_filter_and_window_share_one_native_action, streaming_replay_self_join_all_kinds_empty_null_ties_and_final_output_ownership

### Capillary scheduling/state-work labels

- Owner/caller: Operator-local primitive policy emits capillary_work_units and pulseweave_pressure_signals in local_primitives.rs:539-608; resource envelope default capillary target rows 262144 at :1921-2006. Relational report preserves state-budget identifiers (unary_report.rs:78-110).
- Gate: Operator-family/state strategies select units/retention/partial/top-k approaches; capillary target field is configured/serialized but its direct use in relational runtime was not found by source search. Do not treat labels as a universal scheduler or proof of all routes using it.
- Evidence: local_primitive_capillary_work_units, local_primitive_pulseweave_pressure_signals and state pressure class/budget.
- Tests: sort_rows_uses_capillary_retention_window_for_small_limits (local_primitives.rs:68808); primitive tests assert cross-surface report fields (cli/lib.rs:6503-6608).

### PulseWeave and report-only plans

- Owner/caller: exec/pulseweave.rs:1-6 is side-effect-free policy; only non-test plan_pulseweave call found is vortex_ingest.rs:9870. Relational query routes carry PulseWeave pressure signal strings but no plan_pulseweave call found.
- Gate: Planner requires policy/admission inputs; `not_requested` explicitly runtime_decision_applied=false/policy_mutated=false (pulseweave.rs:574-665).
- Evidence: pulseweave_status, runtime_decision_applied, policy_mutated, digest, blocker, fallback/external invocation, flow inventory/scarcity/endopulse/proofbound.
- Tests: PulseWeave unit tests in pulseweave.rs; runtime query route integration not evidenced.

### Runtime filters, skew, and cross-query reuse skeletons

- Owner/caller: shardloom-plan/src/optimizer.rs:1415-1515 report-only OptimizerPlanSkeleton; dynamic/adaptive report path at 1518-1674.
- Gate: report says planning skeleton only; no optimization execution; adaptive memory sets optimizer_execution=false/runtime_adaptation_applied=false/plan_rewritten=false. Runtime filters planned/candidate and skew signals are not runtime application evidence.
- Evidence: rule decisions, cost estimates, runtime filters, adaptive decisions, skew signals, diagnostics; report-only optimizer trace.
- Tests: evidence_aware_optimizer_trace_is_report_only_and_side_effect_free, adaptive_optimizer_memory_foundation_is_report_only

## Frozen original 10k declaration comparison

{
  "design_path": "/Users/dylan/LocalData/shardloom/expanded-query-2026-11-03/design.json",
  "declared_rows": 10000,
  "surfaces": {
    "python_sql": 2323,
    "embedded_workflow": 1953,
    "cli_sql": 1976,
    "dataframe": 1859,
    "typed_relation": 1889
  },
  "native_input_format_counts": {
    "parquet": 4249,
    "arrow-ipc": 1873,
    "vortex": 3878
  },
  "families": null,
  "execution_metadata": {
    "order": [
      "polars_once",
      "explicit_preparation",
      "native_once",
      "twelve_alternate_source_routes"
    ],
    "threads": 2,
    "native_memory_bytes": 2147483648,
    "process_group_rss_ceiling_bytes": 2684354560,
    "query_deadline_seconds": 120,
    "reference_output_limit_rows": 10000,
    "attempts_per_case_and_route": 1,
    "warmups": 0,
    "cache": "uncontrolled; identities checked outside timed execution",
    "clocks": "native engine clock separately; cross-engine comparison spans declaration through complete Python-row delivery",
    "comparative_scope": "different APIs, same logical source; prepared and common-source strata kept separate"
  },
  "present_as_static_dimensions": [
    "five named query surfaces",
    "Parquet/Arrow IPC/Vortex native_format inputs",
    "archetypes/families and alternate route ids",
    "one run per case/route, no warmups; cache uncontrolled"
  ],
  "not_explicitly_stratified": [
    "resident native-memory inputs",
    "streaming batch/Arrow producer inputs",
    "output formats/result mode (execution says Python-row delivery)",
    "output credit-window requested/eligible cases",
    "memory budgets/pressure/credit-denial profiles",
    "cancellation/late input completion",
    "spill policies/spill paths",
    "prepared-plan reuse/cache-hit strata",
    "adaptive work report counters, capillary/PulseWeave decision evidence"
  ],
  "limitation": "This compares dimensions declared in design.json only; not outcome completeness/runtime feature support. Do not infer the full 10k executes all candidate optimizations."
}

## Gaps and unknowns

- No standalone Python DataFrame class was found; dataframe is a public route label in CLI facade.
- No shared relational runtime call to plan_pulseweave found; only ingest integration and operator pressure labels.
- No runtime cross-query result cache identified; same-query retained materialization, repeated-source replay and Python prepared-operation reuse are distinct.
- design.json does not encode source ownership class or output-mode axis; per-case query content may carry shapes but that is not proof of broader source/output-path coverage.
- Capillary target rows field declaration/default/serialization exists, but no callsite use was found by exact symbol search.

Every cited source path and SHA-256 is listed in `surfaces.json`. Inventory only; no runtime tests or queries were executed.
