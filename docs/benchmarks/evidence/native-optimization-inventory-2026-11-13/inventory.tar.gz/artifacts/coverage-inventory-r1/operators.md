# Native operator and expression optimization owners

Status: **COMPLETE for the bounded operator/expression inventory** at worktree HEAD
`cac86e8b0a5fa5fa8bf4c900dbef7a703746bfa8`. The machine-readable companion contains 15
implemented shared owner families, source-level gates, focused test anchors, report fields,
saved-10k context, and SHA-256s for the traced source files.

## Runtime shape

Relational declarations lower into one `PreparedVortexRelational` node tree. Its native compiler
admits optional file kernels inside that tree; its runtime dispatches joins, aggregates, sets,
sorts, windows, subqueries, retained relations, recursive relations, and expressions to their
native owners. A provider failure does not retry the original plan or delegate to another engine.
The full public-interface convergence map is in `surfaces.json`.

The inventory separates resident execution from explicit spill strategies, action-local retained
reuse from cross-query caching, and executable operators from the physical-kernel policy/report
registry. It names exact typed-key directories and inline caches, bounded Top-K and ranked-source
selection, aggregate state reuse/typed paths, exact set/subquery indexes, window frame sharing,
recursive frontiers, and expression reuse/bulk numeric kernels. Admission is operator-specific;
no optimization is expected to apply to semantically irrelevant work.

## What the saved 10k says

The retained 10k evidence is for source `9f4580c`, earlier than this inventory's HEAD. It records
66,280 native relational operator invocations, 2,974 file-kernel invocations across 2,379 cases,
and some owner counters such as metadata COUNT (1 case), recursive relations (196), materialized
relation reuse (196), and streaming join/subquery/window build detachment. The four `ordered_*`
families have zero positive values among 9,807 reports; those fields measure explicit spill paths,
not resident join, aggregate, set, or window coverage. The 10k evidence has no operator-wide
activation denominator, and test-only counters are not present in that production report.

These are starting observations, not a completeness claim. See `operators.json` for field-specific
denominators and limits. Primary maps per-case saved owner fields to declarations and evaluates
applicability; this packet makes no per-query activation or exclusion judgment.

## Boundaries and remaining evidence

General runtime-filter/skew plans, dynamic sizing feedback, and cross-query result caches remain
planning-only or planned where their docs say so. Narrow native owners such as exact join
membership, local adaptive sizing, and action-local materialized/recursive retention do not imply
those broader mechanisms. The specialized-kernel registry's admission report is not an execution
certificate. The separate prepared-sampling calibration predictor and vector-representation
families should be included in the primary source/surface reconciliation if they are in scope for
the requested matrix; this packet's 15 rows focus on the relational operator/expression owners.

No queries, native imports, builds, benchmarks, source edits, or data scans were performed for this
packet. Hashes are SHA-256 of current worktree bytes; the 10k evidence commit is deliberately kept
separate from current-source provenance.
