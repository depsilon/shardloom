# Existing test coverage for the missing 10k breadth axes

Checkout: `/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo`
at `cac86e8b0a5fa5fa8bf4c900dbef7a703746bfa8`.

This is a static test/source and receipt inventory. It does not run tests or
queries. The 10k design declares 10,000 cases across five front doors and three
file formats (`parquet`, `arrow-ipc`, `vortex`); execution metadata says one
attempt, no warmups, and complete Python-row delivery. It does not explicitly
stratify resident native-memory inputs, streaming batch/Arrow producer inputs,
output mode/format, output credit-window eligibility, pressure/denial,
cancellation/completion, spill, prepared-plan reuse, or adaptive/capillary/
PulseWeave decision evidence. These are design-dimension gaps, not claims that
the features lack tests.

## Execution receipt evidence

- `sort-installed-wheel-r1.json` is a passed installed-wheel proof at the exact
  active HEAD, with `sources_unchanged=true`. Its `report.json` and
  `integration.json` report 442 Python integration tests, zero failures/errors/
  skips. `integration.log` gives individual `... ok` lines. It confirms the
  listed Python test methods ran against the current installed package; it is
  not evidence that Rust unit tests ran.
- `sort-native-tests-r1.json` records a passed `cargo test --workspace
  --all-targets --features python-native,native-encoded-exchange-experiment`
  at ancestor `9f4580c723f876f087d3e75fb56153b4b099ef20`, not the active HEAD.
  `logs/sort-native-tests-r1.log` contains individual Rust `... ok` lines for
  the cited unit cases. I compared the current SHA-256 of each cited Rust test
  module and its relevant adaptive/runtime owner files with the receipt's
  `source_files`; those hashes match. Thus those cases demonstrably passed
  with identical cited test and owner sources, but this is not a full native
  workspace pass at `cac86e8b`.

## Axis inventory

| Missing 10k axis | Existing tests and what they prove | Applicability and limit |
|---|---|---|
| Resident native-memory inputs | Rust `native_relational_memory_scan_preserves_nulls_empty_schema_and_native_predicates`, `native_relational_memory_and_file_inputs_share_join_state_and_generation_checks`, `native_relational_memory_uses_all_shared_output_adapters`, and `native_relational_wide_memory_projection_collects_and_reopens_all_destinations`; Python `test_public_native_columnar_workflow_retains_results_and_preparation`, `test_native_source_transfer_preserves_rich_values_and_lifetimes`, and `test_retained_results_compose_as_sources_without_copying`. | Rust owner tests prove native memory scans, exact output, memory/file composition, and adapter readback. Python tests prove resident Arrow/native results through the Python facade. These are not a five-front-door memory-source parity matrix. The five-front-door matrix below uses file sources. |
| Streaming batch and Arrow inputs | Rust `completion_input_exact_values_schema_empty_batches_and_owned_output`, `completion_input_cumulative_payload_exceeds_grant_without_retention`, `completion_input_end_is_required_even_for_empty_or_filtered_results`, `completion_input_late_failure_cancellation_and_consumer_error_never_complete`, and writer/fanout cases. Python `test_arrow_import_copies_source_buffers_and_accepts_empty_batches`, `test_columnar_stream_is_one_shot_reports_completion_and_preserves_result`, `test_public_native_columnar_batches_preserve_large_batches_and_empty_input`, `test_public_native_batch_admission_precedes_factory_and_stream_close_cleans_producer`, and `test_public_native_batch_late_errors_preserve_exception_and_existing_output`. | Rust tests exercise provider callbacks and prove exact values/end-of-input, single retained input batch, cancellation/error non-completion, and cleanup. Python tests exercise Arrow C import and one-shot native columnar streaming. These are native/Python API tests, not a five-front-door input matrix; Arrow IPC file-format coverage in the five-front-door matrix is a separate adapter path. |
| Collection, streaming, Arrow export, and output formats | Five-front-door `test_adaptive_file_and_output_matrix_preserves_all_five_surfaces_and_two_grants` invokes `all_surfaces` for 9 file input formats (with/without a Vortex source) and writes/readbacks 8 output formats through five surfaces under 16/128 MiB grants. Python `test_incremental_execution_waits_for_demand_and_reports_only_complete_results` covers demand-driven stream completion; `test_native_writer_outputs_reopen_all_complete_values` and `test_public_native_stream_destinations_consume_once_and_preserve_empty_schema` cover complete output/stream destinations. Rust `native_relational_memory_uses_all_shared_output_adapters` and `completion_input_all_writers_preserve_values_and_require_source_end` cover native-memory/batch writer ownership. | The five-interface matrix asserts complete independently built expected rows/schema after reopening each output, plus no fallback, exact declared resources, native peak within grant, and refund to zero. It does not establish every type/output combination or every collection mode. Python collection/stream/writer tests are individual Python API coverage; Rust writer tests are owner tests. |
| Output credit window eligibility and pressure | Rust `credit_window_requires_fifo_unique_acknowledgments_before_more_production`, `credit_window_enforces_exact_inclusive_byte_bounds_without_losing_state`, `credit_window_checks_empty_partial_final_and_maximum_partitions`, `credit_window_admission_uses_actual_row_and_field_boundaries`, and `credit_window_rejects_operator_and_dynamic_roots_without_running_them`. Python `test_normal_package_checks_actual_admission_boundaries`, `test_late_error_keeps_prefix_and_never_certifies_completion`, and source-present `test_parquet_and_native_file_sources_and_spill_requests_are_ineligible`. | Rust tests prove the primitive window protocol, bounds, accounting and refusals. The first two Python tests appear in the current installed receipt; the file/spill-ineligible test is present in `test_native_output_window_observation.py` but is not listed in that package receipt. The feature is deliberately narrow (simple eligible roots, memory-source path, primitive I64, no spill); it is not available for every design case. |
| Memory budgets, credit denial, and actual adaptation | Rust `feedback_shrinks_at_next_boundary_and_regrows_only_after_two_completions`, `observed_long_values_change_following_work_without_changing_the_ceiling`, and `native_adaptive_scan_changes_real_ranges_and_regrows_after_retained_owner_release`; Python `test_native_memory_denial_evidence_is_frozen_before_later_success`, `test_session_command_refuses_smaller_grant_while_native_sources_and_results_are_retained`, and the five-interface matrix. | The adaptive owner/scan tests positively force changing headroom, assert shrink/regrowth and report counters, complete values, peak within ceiling and refund. Python denial tests prove fail-before-load/retained-owner behavior; five-front-door cases preserve declared grants and assert peak <= limit. Those interface tests do not themselves prove pressure adaptation or allocator/RSS equivalence. |
| Cancellation, late input completion, and certification | Rust `completion_input_late_failure_cancellation_and_consumer_error_never_complete`, `completion_input_late_expression_failure_cannot_certify_an_emitted_prefix`, plus `completion_input_end_is_required_even_for_empty_or_filtered_results`. Python `test_incremental_execution_waits_for_demand_and_reports_only_complete_results`, `test_incremental_close_and_session_cancel_keep_retained_batches_valid`, and `test_public_native_cancel_drains_producer_and_preserves_results_and_reuse`. | These explicitly test terminal transitions, prefixes, cancellation and source-end requirements; they are ownership/API tests, not broad five-surface benchmark strata. The public matrix only verifies successful complete results. |
| Explicit spill policy and spill paths | Rust `native_relational_spill_stable_multikey_complete_values_and_repeated_cleanup`, `native_relational_spill_streams_exact_rows_when_resident_sort_exceeds_query_budget`, `native_relational_spill_denial_cancellation_and_consumer_error_never_complete`, and `native_relational_spill_writes_complete_ordered_output_through_all_eight_sinks`. Python `test_native_spill_plan_preserves_values_owners_and_cleanup` and `test_public_native_spill_collect_stream_write_and_invalid_options`. | Positive spill tests assert actual spill runs / report fields, exact complete output and cleanup; separate negative tests assert denial/late-failure non-completion. Python writer/collect/stream spill uses an explicit workspace/quota. The 10k design has no spill-policy stratum. Output-window tests reject spill requests, so that bounded feature is not spill coverage. |
| Prepared declaration reuse versus result cache | Python `test_range_result_export_and_prepared_declaration_reuse` asserts first `resident_relational_declaration_reused=false`, second `true`, and complete identical results; `test_public_native_columnar_workflow_retains_results_and_preparation` does similarly for a LazyFrame. `test_session_reuse_false_releases_preparation_without_closing_context` checks release policy. | This is same-plan prepared declaration reuse and lifecycle. It is not a cross-query result cache or an answer-cache hit. The 10k design explicitly marks cache uncontrolled and only checks identities outside timed execution; it cannot be read as a cache-hit comparison. |
| Adaptive work counters, Capillary, and PulseWeave | Rust `feedback_shrinks_at_next_boundary_and_regrows_only_after_two_completions` and `native_adaptive_scan_changes_real_ranges_and_regrows_after_retained_owner_release` assert adaptive counters/positive decisions and actual completed output. `sort_rows_uses_capillary_retention_window_for_small_limits` and `grouped_count_star_ordered_topk_uses_compact_counts_without_fallback` assert operator-specific capillary work-unit/pressure labels. `capillary_preparation_applies_pulseweave_when_certified` asserts actual applied scheduler windows; `capillary_preparation_blocks_pulseweave_without_native_io_certificate` asserts blocked/no mutation. | Adaptive sizing and selected operator policies have positive executable unit evidence; capillary task labels are operator-specific, not a universal scheduler. PulseWeave tests apply to cold Vortex ingest preparation, not the shared relational query runtime. No 10k case asks for or reports these counters. |

## Confirmed current-source Python pass lines

The installed integration log at the active HEAD contains `... ok` for:

- `test_adaptive_file_and_output_matrix_preserves_all_five_surfaces_and_two_grants`
- `test_arrow_import_copies_source_buffers_and_accepts_empty_batches`
- `test_columnar_stream_is_one_shot_reports_completion_and_preserves_result`
- `test_incremental_execution_waits_for_demand_and_reports_only_complete_results`
- `test_native_ipc_public_frontdoors_preserve_all_values_and_reuse_the_source`
- `test_native_writer_outputs_reopen_all_complete_values`
- `test_public_native_batch_admission_precedes_factory_and_stream_close_cleans_producer`
- `test_public_native_columnar_batches_preserve_large_batches_and_empty_input`
- `test_public_native_spill_collect_stream_write_and_invalid_options`
- `test_normal_package_checks_actual_admission_boundaries`
- `test_late_error_keeps_prefix_and_never_certifies_completion`
- `test_session_reuse_false_releases_preparation_without_closing_context`

The Rust cargo log separately records `... ok` for the cited adaptive scan,
adaptive work, completion-input, memory-output-adapter, spill, credit-window,
Capillary and PulseWeave cases. Its commit is older, so these lines are not a
current-HEAD full-suite claim; source equality for the listed modules is
recorded in the JSON.

## Evidence identities

Every test source, design file, receipt, and log used here has a SHA-256 entry
in `breadth-existing.json`. No test/query/build was run for this inventory.
