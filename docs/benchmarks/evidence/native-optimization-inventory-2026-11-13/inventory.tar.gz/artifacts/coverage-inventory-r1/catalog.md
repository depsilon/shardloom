# Native optimization inventory and first coverage check

Source inventory: `cac86e8b0a5fa5fa8bf4c900dbef7a703746bfa8`.
Complete 10,000-query observations: `9f4580c723f876f087d3e75fb56153b4b099ef20`.
The separately verified 606-query Sort cohort observes `cac86e8b`.
These are separate observations; their times are not combined into a new 10k result.

The requirement is that each supported request reaches every applicable native
optimization through shared owners. A shared entry point, a positive counter,
an existing admission restriction, or a planning recommendation does not establish
that coverage. The public DataFrame facade is real: `LazyFrame` builds declarations
that join SQL, typed relations and embedded workflows at the shared native runtime.
There is no whole-query generic-executor retry or external-engine fallback.

## Current mechanisms to connect and verify

The following is a mechanism inventory, not a claim that every mechanism should
execute on every query. For example, a query with no ordering has no sort to
eliminate. Where a mechanism could remove work but a source, type, shape or
consumer cannot reach it, that remains integration work. Some rows describe
competing legal algorithms whose selection also needs evidence.

| Mechanism | Required connection | What the saved 10k establishes |
|---|---|---|
| Exact metadata COUNT | Complete held metadata into scalar cardinality, without value decoding | One exact metadata-only COUNT; 16 recorded value-evaluation declines. This does not cover all interfaces or metadata/source variants. |
| File/region statistics pruning | Conservative source facts into scheduling and reads | Region exclusion executed in 1,601 queries across all five routes; 6,484 queries report owner decisions. Whole-file scan pruning has a separate counter. |
| Source-column demand | Every consumer's required fields, hidden keys and computations into source projection | All 6,122 Parquet/IPC declarations now have a dependency comparison; details below. The 3,878 Vortex declarations lack an equivalent generic per-source column-count report. |
| Safe source-prefix demand | Finite demand through safe projections/ranges, retaining completion duties | No positive source-prefix observation. Most corpus limits follow sorting; dedicated prefix/completion tests provide a different coverage axis. |
| Predicate and derived-field pushdown | Equivalent bound predicates and aliases into native scans | Owners and negative controls exist; the saved query reports do not identify every eligible/declined predicate boundary. |
| Ranked key reads and selected payload | Exact key-only ranking followed by generation-bound selected groups | 24 original queries use it. The Sort cohort independently checks 19 prior admissions: 11 remain and eight decline under the existing cost rule after payload narrowing. |
| Native Vortex file kernels | Equivalent typed subtrees, including flat stages, into admitted Vortex providers | 2,379 queries contain 2,974 file-kernel invocations; 66,280 total native operator invocations. Missing file kernels are not a denominator for all optimization. |
| Encoded/dictionary/constant/run-end reductions | Actual layouts and admissible null/numeric domains into direct typed or encoded reducers | Selected root-kernel reports show actual accessor/reduction work. Most embedded kernels lack equivalent detailed query reporting; capability registry entries alone are insufficient. |
| Private-reader buffer transfer | Proven allocation ownership into native arrays | Transfer executes in 4,238 Parquet queries across all five routes. Required copies can coexist with transfers; transfer does not mean zero decode. |
| Typed key preparation and shared indexes | Exact key domains into reusable views, bounded directories and exact lookup caches | Join/set/aggregate workloads are present; detailed cache/directory activation is largely test-only. Native source and accepted shared-index controls establish owners, not universal per-query use. |
| Equality joins and semi/anti membership | Exact build/probe state, multiplicity and outer completion into bounded native output | 3,193 declarations contain ordinary joins. Saved owner work includes 2,096 queries with detached streaming build rows; this does not identify every physical join strategy. |
| As-of lookup | Ordered typed keys, partitions, direction and tolerance into exact native lookup | 392 declarations exercise as-of joins; no comprehensive resident search-strategy decision field. |
| Cyclic existence semi-join | The admitted three-memory-source Int64 cycle into witness lookup without pair expansion | The file-backed 10k does not exercise the current memory-only admission. Dedicated positive/negative owner tests are required in the breadth ledger. |
| Compact typed aggregate state | Groups and measures into direct numeric/count, widened/decimal and paired statistical state | 7,828 declarations contain aggregation. Root-specialization reports are a partial view; direct-source COUNT still has an explicit unfinished bridge. |
| Aggregate preparation and measure reuse | Matching source, selected domain, filter and validity mode into shared preparation/state | Existing owners and tests cover compatible repeats. The 10k does not provide a per-measure opportunity/activation denominator. |
| Exact distinct and bounded aggregate workers | Typed/dictionary domains into exact distinct state and admitted partial workers | Distinct measures are present, but direct primitive worker admission must not be inferred from a relational Aggregate node. |
| Existing-order reuse | Fully validated comparison domains into avoiding reorder work | Executed in 4,333 queries; 9,342 queries report considered decisions. Different operators can contribute multiple decisions within one query. |
| Top-K and late payload gathering | Offset/limit and stable complete keys into bounded ordinal/row-reference selection | 9,313 declarations contain a limit and 9,508 contain a sort; 8,457 saved queries report streaming prefix validation. Full-sort coverage is a separate axis. |
| Analytic windows and compatible state sharing | Matching partitions/order/frames into shared preparation and compatible reducer state | 776 window declarations, each using one window function. They do not test all newer multi-function shared-state opportunities or frame families. |
| Subquery indexes and pure-equality decorrelation | Complete null-aware keys and proved equality correlation into one inner index | The 392 membership declarations are uncorrelated IN/NOT IN. No correlated-membership decision is recorded; the production decision fields do exist. |
| Set membership and streaming UNION ALL | Exact record semantics into membership indexes, or ordered streaming without set state | 789 set declarations; these are not a complete per-algorithm activation inventory. |
| Action-local materialization and recursion | Completed native results and recursive frontiers into same-action reuse | 196 materialized-reuse and 196 recursive cases. Native replay decisions execute in 895 queries. This is distinct from cross-query result caching. |
| Expression preparation, reuse and typed bulk kernels | Identical pure expressions and selected domains into shared/bulk native evaluation | 1,465 declarations contain scalar calls. Recipe, SIMD/bulk and reuse decisions are not comprehensively reported per expression. |
| Vector, tensor, Variant and rich typed providers | Admitted selected representations and semantics into native typed kernels | The corpus has no vector/tensor/Variant expression calls. Merely carrying list/struct/decimal source fields does not exercise these providers. |
| Explode, melt and sparse pivot | Needed payload and required population/shape dependencies into bounded native expansion/state | 196 list-explode declarations; 82 Parquet/IPC cases retain a potentially removable scalar field. Melt and pivot require additional declarations. |
| Native rolling state | Window shape and numeric semantics into bounded running/deque state | Analytic rolling SUM in the corpus is not proof of the separate unary rolling owner. |
| Prepared weighted sampling calibration | A retained eligible immutable memory root into scalar calibration reuse and exact search | No sampling or repeated prepared-sampling case in the 10k. Population and answers must still be rebuilt each execution. |
| Adaptive bounded work | Current shared headroom and completed feedback into actual scan/decode/replay/output windows | Scan 8,632; decode 4,238; replay 853; sort-output 8,649 queries report completed windows. None records pressure-driven shrink/regrowth. |
| Memory credits, native spill and cleanup | Stateful owners and buffers into reservations, explicit spill and terminal cleanup | No 10k spill execution. Separate current-source tests force spill, pressure, denial, late failure and cleanup. Resource estimates are not process-RSS proof. |
| Native output and bounded delivery | The same prepared operation into native collection, iteration, compaction, writers and eligible credit windows | The 10k completes row delivery. Existing installed tests separately exercise native outputs, producers, formats and credit-window boundaries. |
| Bounded workers and queues | Admitted independent native work into credited submission, retirement and drain | Operator-specific worker evidence exists. Selected lane counts and Capillary labels do not prove general parallel scheduling. PulseWeave's applied ingest policy is separate from query execution. |

## Query-by-query source-demand result

Every original declaration identity was reconstructed and joined to its saved
complete-result observation. Dependency rules retain hidden sort/join/filter
keys, every computed projection and aggregate, complete distinct records,
expanded-list population, window dependencies, and named retained/recursive
records. The comparison uses the union of required columns for each logical
source. No query was executed for this audit.

Of the 6,122 Parquet/IPC declarations, 5,927 match that logical field count,
one uses metadata COUNT, and 194 report more fields. There are no cases below
the dependency bound and no unclassified declaration operator in this screen.
The 194 consist of:

- **98 Sort connections:** the separate candidate run now reads exactly the
  required columns in every case. All 606 fixed-cohort complete results pass;
  engine time is 85.218734162 → 45.164316757 seconds for that cohort only.
- **14 filtered COUNT(*) cases:** the scan chooses an additional row-bearing
  field even though a required predicate field already supplies the population.
  Current observations read two logical columns rather than one.
- **82 list-expansion reductions:** source demand stops at the unary operation,
  leaving an unused scalar column. Current observations read four rather than
  three columns, or three rather than two.

The remaining 96 are concrete shared-owner candidates to fix and verify. The
static screen is not proof of byte-optimal reads, permissible omission of
observable validation, or arbitrary future-query coverage. Native Vortex
source-demand evidence still needs its own comparable report and checks.

## Breadth beyond the 10k

The current release artifacts already pass 442 installed Python tests. The
complete native/default checks pass 7,128/3,325 tests respectively. All 5,688
source-file identities match across those checks, the release build and the
working tree committed as `cac86e8b`; the native receipt records the parent
commit because its source changes were committed after testing.

Existing independently expected public tests cover nine file input formats and
eight output formats through all five interfaces under two grants: 180 complete
collections and 80 writes with complete readback. Separate current-source
controls exercise resident memory, Arrow/batch producers, actual pressure and
adaptation, explicit spill, cancellation, late errors, completion, prepared reuse
and bounded output delivery. These tests expand the evidence beyond 10k, but
do not prove every source × operator × representation × output × interface
combination. The breadth ledger identifies confirmed tests and unconfirmed
items explicitly; it does not create extra benchmark results.

## Open obligations

Close the 96 source-demand candidates through shared owners, with failing-before
regressions and complete-value/lifecycle controls. Finish per-opportunity
decision evidence for mechanisms whose production reports are incomplete,
including comparable Vortex demand evidence. Add versioned compositions for
uncovered current mechanisms rather than relabeling existing corpus cases.

General runtime filters, generalized skew handling, cross-query result caching,
and the broader A–N investigations remain unfinished or conditional under their
existing contracts. Rejected experiments remain rejected. The direct COUNT
bridge is still queued after this current-connection audit; its original invalid
baseline is preserved. No complete optimization percentage is claimed. Item 19,
item 20, RFC 0044 and CG-1 through CG-23 remain open.

## Evidence index

- `catalog.json`: verified source inventories, source hashes, observations and corrections.
- `declaration-observation-matrix.json` and `.jsonl.gz`: all 10,000 identities and operator paths.
- `column-demand-candidates-r2.json`: all direct-source dependency comparisons and 194 candidates.
- `full-observed-fields.json`, `observed-fields.json`, `observed-query-evidence.jsonl.gz`: exact saved owner evidence.
- `sources-r2.json`, `operators.json` + `operators-r2.json`, `surfaces-r3.json`: owner, caller, gate, test and hash details.
- `breadth-existing.json`: executed test evidence and remaining public-path coverage gaps.
- `native-validation-source-binding.json`: complete source equality linking precommit checks to the committed release.

