# Cardinality declaration candidate pools

- Frozen declarations enumerated: 10000
- Union candidate count: 213
- Sort cohort intersection: 0
- Query executions: 0
- Runtime imports: native and Polars runtime absent.

## Disjoint declaration-shape buckets

- `explode_case`: 196
- `scalar_aggregate_no_arguments`: 17

These are source-declared candidate/control pools only. Membership does not establish runtime activation or performance. See `cardinality-pools.json` for exact identities, descriptors, node paths, function arguments, source-field demand, observation counts, and input hashes.
