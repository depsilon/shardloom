# Native operator optimization inventory addendum R2

R2 supplements [R1](./operators.md) at worktree HEAD
`cac86e8b0a5fa5fa8bf4c900dbef7a703746bfa8`. Keep R1 unchanged. The JSON is the
source of truth for full gates, decline conditions, owner/caller symbols, tests,
report limits, and SHA-256s.

## Added source owners

- **Cyclic existence semi-join:** `PreparedVortexRelational::run` can replace a
  narrowly admitted `R ⋉ (S ⋈ T)` with two execution-local exact `RowIndex`
  tables, one witness probe per outer row, early witness exit, and bounded gather
  of only left output rows. Admission is limited to three pure memory scans of at
  least 128 source rows and six distinct Int64 key fields with the exact join and
  projection shape. Explicit spill, transformations, filters, non-Int64 keys,
  and other shapes stay on the ordinary native path.
- **Pure-equality correlated membership rewrite:** the binder rewrites only
  bound `EXISTS`/`IN` plans whose pure in-memory source, projection, join and
  predicate shapes reduce to cross-side column equalities. It is narrower than
  general correlated execution; transformed predicates and opaque/filtered or
  limited inputs decline.
- **Prepared weighted sampling:** one immutable prepared in-memory root may
  retain a credited scalar calibration record for weighted replacement. Every
  execution rebuilds the population and performs actual draws; no rows or CDF
  are cached. Admission and cleanup gates are recorded in JSON. The old learned
  search-index predictor is dropped and is not current behavior.
- **Unary explode, pivot and rolling:** explode streams row/list-element
  coordinates to bounded outputs and rejects unequal zipped list lengths; pivot
  completes typed, budgeted sparse cell state before publishing; rolling uses
  typed bounded deque state, with centered lookahead limited to a window-sized
  buffer. These owners are separate from relational shared analytic windows.
- **Scalar expression preparation:** bounded Boolean predicate recipes and exact
  projection reuse are source-present native expression paths. Recipe compilation
  declines unsupported shapes; test-only counters do not prove 10k activation.
- **Vector, tensor and Variant providers:** typed native scalar functions route
  through expression binding to Vortex-native kernels. Vector work inspects or
  computes over native list coordinates; Variant work validates and detaches
  selected bounded chunks before using the pinned Vortex provider. Neither is
  admitted as ordinary key ordering/grouping for vector payloads.

## R1 family clarifications

The JSON adds a source-grounded direct aggregate clarification: resident typed
group state has exact COUNT/SUM/AVG/MIN/MAX gates; direct aggregate worker
request-shape checks are only prechecks before schema, dtype and resource
admission; native dictionary chunks retain their own exact handoff evidence;
and the encoded physical COUNT registry lane is not proof of runtime aggregate
execution. It also distinguishes runtime Top-K/row-reference owners from
report-only kernel candidates, and pure-equality subquery rewriting from general
correlated execution.

Stable production capability-decision fields exist for the correlated-membership
boundary, including pure-equality admission/execution and required-parameter
declines; these are distinct from the test-only compile-time rewrite counter. The
saved 10k has no such observations because all 392 `membership_case` declarations
are uncorrelated. No stable per-owner production counters were found for
cyclic-plan activation, prepared-sampling calibration, or vector-kernel activation.
Relevant details are test-only or absent from the saved 10k report. Existing unary
stage/state summaries do not provide a complete denominator for explode, pivot,
or rolling. R2 makes no per-query applicability,
activation, or universal-coverage claim.

The R2 hash registry includes every source/test path cited by R1 and R2, plus
the five requested architecture references. It repairs 12 missing entries in
R1's source hash map without changing R1. JSON parsing and source-hash matching
were checked; no query, build, benchmark, or test was run.
