"""Join saved Vortex scan contracts to declared source dependencies; execute no query."""
from collections import Counter, defaultdict
import gzip
import hashlib
import json
from pathlib import Path
import sys

import coverage_column_demand_r2 as dependencies

OUT=Path(__file__).resolve().parent
DEST=OUT/'coverage-inventory-r1/vortex-declared-demand-r1.json'
frozen=dependencies.frozen


def identity(path):
    raw=path.read_bytes()
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def main():
    assert __debug__ and not DEST.exists()
    design_path=frozen.E/'design.json'
    observed_path=OUT/'coverage-inventory-r1/observed-query-evidence.jsonl.gz'
    design=json.loads(design_path.read_bytes())
    legacy={item.id:item for item in frozen.corpus(interactions='all',include_pending=False)}
    definitions={item.name:item for item in frozen.spaces()}
    checked=0;totals=Counter();rows=[]
    with gzip.open(observed_path,'rt') as stream:
        for declaration,line in zip(design['cases'],stream,strict=True):
            observed=json.loads(line);checked+=1
            assert observed['id']==declaration['id'] and observed['case_identity']==declaration['case_identity']
            if declaration['native_format']!='vortex':continue
            case=frozen.build(declaration,definitions) if 'cell' in declaration else legacy[declaration['id']]
            assert case.id==declaration['id'] and case.identity==declaration['case_identity']
            required=defaultdict(set)
            dependencies.demand(case.relation,dependencies.all_fields(case.relation),required)
            available={}
            for node in frozen.nodes(case.relation):
                if node.op=='scan':
                    fields=dependencies.all_fields(node)
                    assert node.args[0] not in available or available[node.args[0]]==fields
                    available[node.args[0]]=fields
            report=observed['fields']
            comparable='local_primitive_scan_projection_columns' in report
            scan=None
            if comparable:
                assert report['local_primitive_scan_column_scope']=='executed_provider_rewritten_scan_contract;not_per_column_payload_io_or_decode_measurement'
                projection=json.loads(report['local_primitive_scan_projection_columns'])
                predicate=json.loads(report['local_primitive_scan_predicate_columns'])
                assert all(isinstance(name,str) for name in projection+predicate)
                assert len(required)==1
                expected=next(iter(required.values()))
                actual=set(projection)|set(predicate)
                status='matching_declared_dependencies' if actual==expected else 'requires_semantic_reconciliation'
                scan=dict(projection=projection,predicate=predicate,union=sorted(actual),
                    extra_declared_fields=sorted(actual-expected),missing_declared_fields=sorted(expected-actual),
                    status=status,scope=report['local_primitive_scan_column_scope'])
                totals[status]+=1
            else:
                totals['no_saved_comparable_scan_contract']+=1
            rows.append(dict(id=case.id,case_identity=case.identity,surface=declaration['surface'],
                family=declaration['family'],profile=declaration['profile'],
                source_fields={name:sorted(value) for name,value in available.items()},
                logical_dependencies={name:sorted(value) for name,value in required.items()},
                saved_scan_contract=scan,raw_stdout_sha256=observed['raw_stdout_sha256']))
    assert checked==10000 and len(rows)==3878
    assert sum(value for key,value in totals.items() if key!='no_saved_comparable_scan_contract')==172
    assert not any(name=='shardloom._native' or name.startswith('_polars_runtime') for name in sys.modules)
    loaded={Path(module.__file__).resolve() for name,module in tuple(sys.modules.items())
            if name.startswith('query_surface') and getattr(module,'__file__',None)}
    paths=loaded|{Path(__file__),Path(dependencies.__file__),Path(frozen.__file__),design_path,observed_path}
    result=dict(status='saved_vortex_scan_contract_audit',query_executions=0,
        source_commit='9f4580c723f876f087d3e75fb56153b4b099ef20',
        original_declaration_observation_identities_checked=checked,vortex_declaration_identities_verified=len(rows),
        scan_contract_observations=172,counts=dict(totals),cases=rows,
        source_identities={str(path):identity(path) for path in sorted(paths)},
        limitation='Logical dependencies and rewritten scan fields are not per-column physical I/O or decode observations. '
                   'Prepared-source error/validation obligations must be reconciled separately before removing fields. '
                   'Missing scan contracts and current admission exclusions remain open evidence/integration work.')
    with DEST.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps({key:result[key] for key in ('status','query_executions',
        'original_declaration_observation_identities_checked','vortex_declaration_identities_verified',
        'scan_contract_observations','counts')}))


if __name__=='__main__':
    main()
