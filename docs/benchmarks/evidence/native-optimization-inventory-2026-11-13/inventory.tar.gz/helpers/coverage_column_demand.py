"""Find potential excess source fields using conservative declaration dependencies.

This is a logical dependency audit, not a replica of native source admission.
Shared readers, provider limits and runtime semantics still require review.
"""
from collections import Counter, defaultdict
import gzip
import json
from pathlib import Path
import sys

import verify_sort_exposure as frozen
from coverage_declarations import identity

OUT = Path(__file__).resolve().parent
DEST = OUT / 'coverage-inventory-r1'
KNOWN = {'scan','project','filter','limit','sort','aggregate','join','distinct'}


def all_fields(node):
    return {name for name,_ in node.schema}


def demand(node, needed, result):
    assert needed <= all_fields(node)
    if node.op == 'scan':
        # Source row population still needs a real row-bearing field unless
        # exact metadata count is independently admitted at execution.
        if not needed:
            needed = {node.schema[0][0]}
        result[node.args[0]].update(needed)
    elif node.op == 'project':
        columns = set().union(*(expr.columns() for name,expr in node.args
                               if name in needed or expr.op != 'column'))
        demand(node.inputs[0], columns, result)
    elif node.op == 'filter':
        demand(node.inputs[0], needed | node.args[0].columns(), result)
    elif node.op == 'limit':
        demand(node.inputs[0], needed, result)
    elif node.op == 'sort':
        demand(node.inputs[0], needed | {key.column for key in node.args}, result)
    elif node.op == 'aggregate':
        keys,measures = node.args
        # Keep every aggregate computation and hidden key, including outputs
        # omitted by a later projection; it can still fail or observe values.
        columns = set(keys)
        for measure in measures:
            if measure.argument is not None:
                columns.update(measure.argument.columns())
        demand(node.inputs[0], columns, result)
    elif node.op == 'distinct':
        # Duplicates depend on the whole declared record.
        demand(node.inputs[0], all_fields(node.inputs[0]), result)
    elif node.op == 'join':
        keys,columns,_kind = node.args
        left = {a for a,_ in keys}
        right = {b for _,b in keys}
        retained = needed or {node.schema[0][0]}
        for side,name,alias in columns:
            if alias in retained:
                (left if side=='left' else right).add(name)
        demand(node.inputs[0],left,result)
        demand(node.inputs[1],right,result)
    else:
        raise AssertionError(node.op)


def main():
    target = DEST/'column-demand-candidates.json'
    assert not target.exists()
    design_path = frozen.E/'design.json'
    observed_path = DEST/'observed-query-evidence.jsonl.gz'
    design = json.loads(design_path.read_bytes())
    legacy = {case.id:case for case in frozen.corpus(interactions='all',include_pending=False)}
    spaces = {space.name:space for space in frozen.spaces()}
    summary, candidates, checks, exclusions = Counter(), [], [], Counter()
    with gzip.open(observed_path,'rt') as observations:
        for descriptor,line in zip(design['cases'], observations, strict=True):
            saved = json.loads(line)
            case = frozen.build(descriptor,spaces) if 'cell' in descriptor else legacy[descriptor['id']]
            assert saved['id']==case.id==descriptor['id']
            assert case.identity==saved['case_identity']==descriptor['case_identity']
            summary['identities_checked'] += 1
            if descriptor['native_format'] not in {'parquet','arrow-ipc'}:
                summary['native_vortex_no_comparable_source_column_counter'] += 1
                continue
            unknown = {node.op for node in frozen.nodes(case.relation)}-KNOWN
            if unknown:
                exclusions.update(unknown)
                summary['requires_additional_dependency_rule'] += 1
                continue
            required = defaultdict(set)
            demand(case.relation,all_fields(case.relation),required)
            observed = saved['fields']
            if int(observed['native_source_metadata_count_sources']):
                summary['exact_metadata_count_no_value_fields'] += 1
                continue
            projected = int(observed['native_source_demand_projected_columns'])
            requested = sum(map(len,required.values()))
            entry = dict(id=case.id,case_identity=case.identity,surface=descriptor['surface'],
                         native_format=descriptor['native_format'],family=descriptor['family'],
                         required_fields={key:sorted(value) for key,value in required.items()},
                         required_column_count=requested,reported_column_count=projected,
                         sources=Counter(node.args[0] for node in frozen.nodes(case.relation) if node.op=='scan'),
                         raw_stdout_sha256=saved['raw_stdout_sha256'])
            checks.append(entry)
            if projected > requested:
                summary['reported_above_dependency_bound'] += 1
                candidates.append(entry)
            elif projected == requested:
                summary['matches_dependency_bound'] += 1
            else:
                summary['reported_below_dependency_bound_requires_reconciliation'] += 1
    assert summary['identities_checked'] == 10000
    assert not any(name=='shardloom._native' or name.startswith('_polars_runtime') for name in sys.modules)
    result = dict(status='static_dependency_screen_not_runtime_admission',query_executions=0,
        summary=summary, opaque_operator_case_counts=exclusions,
        candidate_surfaces=Counter(row['surface'] for row in candidates),
        candidate_families=Counter(row['family'] for row in candidates),
        candidates=candidates, checks=checks,
        source_identities={str(path):identity(path) for path in [Path(__file__),Path(frozen.__file__),
            design_path,observed_path,DEST/'declaration-observation-matrix.json']},
        limitations=['Exact matching logical dependencies is not physical byte optimality.',
        'Above-bound cases are investigation candidates until shared-source accounting, provider '
        'admission, semantic boundaries and the actual native plan are reconciled.',
        'The original 9f4580c observation predates the separately verified Sort connection.',
        'Opaque corpus operators remain open and are not called optimized or inapplicable.'])
    with target.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps({key:result[key] for key in ['status','query_executions','summary',
        'opaque_operator_case_counts','candidate_surfaces','candidate_families']}))


if __name__=='__main__':
    main()
