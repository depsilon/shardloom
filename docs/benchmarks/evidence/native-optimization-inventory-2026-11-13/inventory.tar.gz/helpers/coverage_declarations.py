"""Join every frozen declaration to saved owner observations; never execute a query."""
from collections import Counter, defaultdict
from dataclasses import fields, is_dataclass
import gzip
import hashlib
import json
from pathlib import Path
import re
import sys

import verify_sort_exposure as frozen
from query_surface.specification import Expression, Measure

OUT = Path(__file__).resolve().parent
DEST = OUT / 'coverage-inventory-r1'


def identity(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def expressions(value):
    if isinstance(value, Expression):
        yield value
        for argument in value.args:
            yield from expressions(argument)
    elif isinstance(value, Measure):
        if value.argument is not None:
            yield from expressions(value.argument)
    elif isinstance(value, (tuple, list)):
        for part in value:
            yield from expressions(part)
    elif is_dataclass(value):
        for field in fields(value):
            yield from expressions(getattr(value, field.name))


def walk(node, path=()):
    yield path, node
    for index, child in enumerate(node.inputs):
        yield from walk(child, path + (index,))


def measure_name(measure):
    if measure.argument is None:
        return measure.function + ':star'
    return measure.function + ':' + measure.argument.op


def dimensions(case):
    opportunities = []
    for path, node in walk(case.relation):
        item = dict(path=list(path), operator=node.op,
                    output_columns=[name for name, _ in node.schema],
                    expressions=dict(Counter(expression.op for expression in expressions(node.args))),
                    calls=dict(Counter(expression.value for expression in expressions(node.args)
                                       if expression.op == 'call')),
                    dtypes=sorted({dtype.name for _, dtype in node.schema}))
        if node.op == 'aggregate':
            keys, measures = node.args
            item.update(group_keys=list(keys), measures=[measure_name(m) for m in measures],
                        count_only=all(m.function == 'count' for m in measures),
                        count_star_only=all(m.function == 'count' and m.argument is None
                                            for m in measures))
        elif node.op == 'scan':
            item['source'] = node.args[0]
        elif node.op == 'join':
            item['join_kind'] = node.args[2]
        elif node.op == 'set':
            item['set_kind'] = node.args[0]
        elif node.op == 'sort':
            item['keys'] = [dict(column=k.column, descending=k.descending, nulls=k.nulls)
                            for k in node.args]
        elif node.op == 'limit':
            item['count'], item['offset'] = node.args
        elif node.op == 'project':
            item['direct_columns_only'] = all(expr.op == 'column' for _, expr in node.args)
        opportunities.append(item)
    return opportunities


def main():
    assert __debug__
    summary_path = DEST / 'declaration-observation-matrix.json'
    cases_path = DEST / 'declaration-observation-matrix.jsonl.gz'
    assert not summary_path.exists() and not cases_path.exists()
    design_path = frozen.E / 'design.json'
    observed_path = DEST / 'observed-query-evidence.jsonl.gz'
    field_summary_path = DEST / 'full-observed-fields.json'
    field_summary = json.loads(field_summary_path.read_bytes())
    assert identity(observed_path) == {k:field_summary['case_rows'][k] for k in ('bytes','sha256')}
    design = json.loads(design_path.read_bytes())
    legacy = {item.id:item for item in frozen.corpus(interactions='all', include_pending=False)}
    spaces = {item.name:item for item in frozen.spaces()}
    presence, invocations, axis_presence = Counter(), Counter(), defaultdict(Counter)
    expression_presence, call_presence, dtype_presence = Counter(), Counter(), Counter()
    other_presence = defaultdict(Counter)
    combinations = defaultdict(Counter)
    count = 0
    with gzip.open(observed_path,'rt') as records, gzip.open(cases_path,'xt') as output:
        for descriptor, line in zip(design['cases'], records, strict=True):
            saved = json.loads(line)
            case = frozen.build(descriptor, spaces) if 'cell' in descriptor else legacy[descriptor['id']]
            assert saved['seq'] == count
            assert case.id == saved['id'] == descriptor['id']
            assert case.identity == saved['case_identity'] == descriptor['case_identity']
            opportunities = dimensions(case)
            operators = Counter(item['operator'] for item in opportunities)
            invocations.update(operators)
            presence.update(operators.keys())
            for name in operators:
                for key in ('surface','native_format','family'):
                    axis_presence[name + ':' + key][descriptor[key]] += 1
            expression_presence.update({name for item in opportunities for name in item['expressions']})
            call_presence.update({name for item in opportunities for name in item['calls']})
            dtype_presence.update({name for item in opportunities for name in item['dtypes']})
            for key in ('join_kind','set_kind'):
                other_presence[key].update({item[key] for item in opportunities if key in item})
            other_presence['measure'].update({name for item in opportunities for name in item.get('measures',())})
            fields = saved['fields']
            proof = fields['local_primitive_native_io_pushdown_proof_basis']
            tokens = re.findall(r'(?:^|[ ;])([a-z][a-z0-9_]*)=([0-9]+)(?=$|[ ;])', proof)
            assert len(tokens) == len(dict(tokens))
            numbers = {key:int(value) for key,value in tokens}
            observed = {key:value for key,value in fields.items() if
                        key.startswith(('native_source_', 'native_input_', 'relational_',
                                        'local_primitive_native_io_decision_'))}
            signatures = dict(
                file_kernel=numbers.get('native_pipeline_file_kernel_invocations',0)>0,
                source_prefix=int(fields.get('native_source_demand_prefix_sources',0))>0,
                metadata_count=int(fields.get('native_source_metadata_count_sources',0))>0,
                ranked_payload=int(fields.get('native_source_ranked_sources',0))>0,
                existing_order=int(fields.get('local_primitive_native_io_decision_existing_order_executed',0))>0,
                correlated_membership=int(fields.get('local_primitive_native_io_decision_correlated_membership_executed',0))>0,
                native_replay=int(fields.get('local_primitive_native_io_decision_native_replay_executed',0))>0)
            for op in operators:
                for name, active in signatures.items():
                    combinations[op][name + (':observed' if active else ':unobserved')] += 1
            record = dict(seq=count, id=case.id, case_identity=case.identity,
                          surface=descriptor['surface'], native_format=descriptor['native_format'],
                          family=descriptor['family'], profile=descriptor['profile'],
                          source_commit=saved['source_commit'],
                          raw_stdout_sha256=saved['raw_stdout_sha256'],
                          operators=opportunities, observed_signatures=signatures,
                          owner_fields=observed, proof_counters=numbers)
            output.write(json.dumps(record,separators=(',',':'),allow_nan=False)+'\n')
            count += 1
    assert count == 10000
    assert not any(name == 'shardloom._native' or name.startswith('_polars_runtime') for name in sys.modules)
    paths = {Path(__file__), Path(frozen.__file__), design_path, observed_path, field_summary_path}
    for name,module in sys.modules.items():
        if name.startswith(('query_surface.','shardloom.')) and getattr(module,'__file__',None):
            paths.add(Path(module.__file__))
    result = dict(status='verified_declaration_observation_join', cases=count, query_executions=0,
                  source_commit=field_summary['source_commit'], case_rows=identity(cases_path),
                  operator_case_counts=presence, operator_node_counts=invocations,
                  operator_dimensions=axis_presence, expression_case_counts=expression_presence,
                  scalar_function_case_counts=call_presence, dtype_case_counts=dtype_presence,
                  other_case_counts=other_presence, operator_observation_combinations=combinations,
                  source_identities={str(path):identity(path) for path in sorted(paths)},
                  limitation='Operator presence is an opportunity candidate, not complete algorithm applicability. '
                  'Owner observations are query-scoped and cannot assign an invocation to a particular node. '
                  'Missing observations are unproved, not automatically missing execution. '
                  'The 606-case Sort candidate is separate; these are the complete original 9f4580c observations.')
    with summary_path.open('x') as stream:
        json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps({key:result[key] for key in ('status','cases','query_executions',
        'operator_case_counts','other_case_counts')}))


if __name__ == '__main__':
    main()
