"""Assemble verified owner inventories and keep execution/applicability limits explicit."""
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
DEST = OUT/'coverage-inventory-r1'
REPO = Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')


def identity(path):
    data=path.read_bytes()
    return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())


def main():
    target=DEST/'catalog.json'
    assert not target.exists()
    names=['sources-r2.json','operators.json','operators-r2.json','surfaces-r3.json',
           'breadth-existing.json','native-validation-source-binding.json',
           'declaration-observation-matrix.json','column-demand-candidates-r2.json',
           'full-observed-fields.json','observed-fields.json']
    values={name:json.loads((DEST/name).read_bytes()) for name in names}
    source,op,extra,surface,breadth=(values[name] for name in names[:5])
    head='cac86e8b0a5fa5fa8bf4c900dbef7a703746bfa8'
    assert all(value['head']==head for value in (source,op,extra,surface,breadth))
    expected=extra['base_artifacts']
    assert identity(DEST/'operators.json')['sha256']==expected['operators_json_sha256']
    assert identity(DEST/'operators.md')['sha256']==expected['operators_markdown_sha256']
    registry={}
    for path,digest in extra['source_sha256']['files'].items():
        registry[str(REPO/path)]=digest
    groups=[source['hashed_files'],surface['source_manifest'],breadth['source_manifest']['test_and_design_sources']]
    for rows in groups:
        for row in rows:
            path=Path(row['path'])
            if not path.is_absolute():path=REPO/path
            assert str(path) not in registry or registry[str(path)]==row['sha256']
            registry[str(path)]=row['sha256']
    for path,digest in registry.items():
        assert identity(Path(path))['sha256']==digest,path
    observed=values['full-observed-fields.json']
    matrix=values['declaration-observation-matrix.json']
    columns=values['column-demand-candidates-r2.json']
    assert observed['cases']==matrix['cases']==columns['summary']['identities_checked']==10000
    assert observed['source_commit']==matrix['source_commit']=='9f4580c723f876f087d3e75fb56153b4b099ef20'
    assert columns['summary']['reported_above_dependency_bound']==194
    assert columns['candidate_families']==dict(predicates=6,nullable=8,ordering=98,nested=82)
    assert values['native-validation-source-binding.json']['complete_native_source_set_identical']
    result=dict(schema='shardloom.optimization_coverage_inventory.v1',
        status='source_inventory_and_saved_case_audit_complete_coverage_still_open',
        current_source_commit=head,observed_10000_source_commit=observed['source_commit'],
        query_executions_for_inventory=0,coverage_percentage=None,
        verified_unique_source_and_design_hashes=len(registry),
        inventories=dict(sources=source,operators=op,operator_addendum=extra,surfaces=surface),
        corpus=dict(cases=matrix['cases'],operator_case_counts=matrix['operator_case_counts'],
            scalar_function_case_counts=matrix['scalar_function_case_counts'],
            capabilities=observed['capabilities'],source_column_dependencies=columns['summary'],
            column_candidates_by_family=columns['candidate_families']),
        breadth=breadth,
        primary_corrections=[
            'Use surfaces-r3: LazyFrame is an implemented pure-Python facade, not merely a route label.',
            'The complete 5688-source-file set matches native checks, release build and current commit; '
            'a parent HEAD recorded before committing does not invalidate identical tested working-tree bytes.',
            'Adaptive owner counters ARE in the 10k proof basis. No shrink/grow under its unpressured grant '
            'does not mean no adaptive sizing policy was consulted.',
            'Stable CorrelatedMembership admitted/executed/declined evidence exists. The 392 original '
            'membership declarations are uncorrelated, so they do not exercise that optimization.',
            'Ordered aggregate/join/set/window report families describe explicit spill implementations; '
            'their zero values do not show absent resident algorithms.'],
        remaining=[
            'Verify and close 14 filtered-cardinality and 82 list-expansion source-column candidates.',
            'Complete per-opportunity decision evidence, including comparable Vortex source-column evidence.',
            'Expand current-mechanism compositions beyond the 10k axes; preserve exact positive/negative owner controls.',
            'Keep direct COUNT bridge and broader existing planned investigations open under their contracts.'],
        source_sha256=dict(sorted(registry.items())),
        artifact_identities={name:identity(DEST/name) for name in names+['catalog.md']},
        assembler=identity(Path(__file__)),
        limitation='Source presence, successful tests and positive query-level counters have distinct scopes. '
        'This does not prove universal applicability, all-node activation, physical optimality or a new complete 10k runtime result.')
    with target.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps({key:result[key] for key in ['status','current_source_commit',
        'query_executions_for_inventory','coverage_percentage','verified_unique_source_and_design_hashes']}))


if __name__=='__main__':main()
