"""Verify exact function/log joins and normalize stale literal prefixes separately."""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

OUT=Path(__file__).resolve().parent
ROOT=Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
DEST=OUT/'coverage-inventory-r1/operator-test-primary-r5.json'


def identity(path):
    raw=path.read_bytes()
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def main():
    assert __debug__ and not DEST.exists()
    subprocess.run([sys.executable,'-B',str(OUT/'verify_operator_test_union_r4.py')],check=True)
    audit=json.loads((OUT/'operator-test-union-r4.json').read_bytes())
    functions={}
    canonical=defaultdict(set)
    corrections=[]
    logs={path:Path(path).read_text().splitlines() for path in audit['log_sha256']}
    for row in audit['references']:
        assert row['source_tests']
        for test in row['source_tests']:
            key=test['source_path']+'::'+test['function']
            canonical[row['inventory']+'::'+row['family']].add(key)
            assert test['log_matches']
            for match in test['log_matches']:
                line=logs[match['log_path']][match['line']-1]
                parsed=re.fullmatch(r'test (\S+) \.\.\. (ok|ignored(?:,.*)?)',line)
                assert parsed and parsed.group(1)==match['qualified_test_name']
                assert parsed.group(1).split('::')[-1]==test['function']
                assert ('ignored' in parsed.group(2))==test['ignored_in_source']
                assert match['status']==('passed' if parsed.group(2)=='ok' else 'ignored')
            if key in functions:
                assert functions[key]==test
            functions[key]=test
        if not row['source_resolution']['module_reference']:
            prefix=row['literal_reference'].rsplit('::',1)[0]
            resolved={Path(test['source_path']).stem for test in row['source_tests']}
            if not any(prefix.endswith(name) or prefix.endswith(name+'.rs') or
                       prefix.startswith(name+'::') for name in resolved):
                corrections.append(dict(inventory=row['inventory'],family=row['family'],
                    original_literal=row['literal_reference'],
                    corrected_references=[test['source_path']+'::'+test['function'] for test in row['source_tests']],
                    reason='Literal source-module prefix is stale; exact function and saved result verified.'))
    counts=Counter(test['status'] for test in functions.values())
    assert counts==dict(passed=337,ignored=1) and len(functions)==338
    assert len(corrections)==3
    result=dict(status='passed',query_executions=0,tests_executed=0,
        source_snapshot=audit['source_snapshot'],source_files=len(audit['source_sha256']),
        literal_reference_occurrences=len(audit['references']),unique_source_tests=len(functions),
        unique_test_statuses=dict(counts),literal_prefix_corrections=corrections,
        canonical_family_test_references={key:sorted(value) for key,value in sorted(canonical.items())},
        exact_function_source_and_log_details=functions,
        artifacts={name:identity(OUT/name) for name in ('operator-test-union-r4.json',
            'verify_operator_test_union_r4.py','verify_operator_receipts_primary.py')},
        limitation='Historical tests are source-bound to cac86. Repeated references and logs are not additional tests; '
                   'an ignored attribution test is not a passed test. This is not per-query optimization activation.')
    with DEST.open('x') as stream:
        json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps({key:result[key] for key in ('status','source_files','literal_reference_occurrences',
        'unique_source_tests','unique_test_statuses','literal_prefix_corrections')}))


if __name__=='__main__':
    main()
