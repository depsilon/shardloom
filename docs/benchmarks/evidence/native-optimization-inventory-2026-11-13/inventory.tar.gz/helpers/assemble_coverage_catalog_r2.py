"""Correct the immutable owner inventory and attach exact historical test receipts."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess

OUT=Path(__file__).resolve().parent
DEST=OUT/'coverage-inventory-r1'
ROOT=Path('/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo')
HEAD='cac86e8b0a5fa5fa8bf4c900dbef7a703746bfa8'


def identity(path):
    raw=path.read_bytes()
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def read(name):
    return json.loads((DEST/name).read_bytes())


def main():
    target=DEST/'catalog-r2.json'
    markdown=DEST/'catalog-r2.md'
    assert __debug__ and not target.exists() and not markdown.exists()
    result=copy.deepcopy(read('catalog.json'))
    primary=read('operator-test-primary-r5.json')
    union=json.loads((OUT/'operator-test-union-r4.json').read_bytes())
    operators=read('operators-r3.json')
    extra=read('operators-r2.json')
    assert primary['status']=='passed' and primary['source_snapshot']==HEAD
    assert primary['unique_source_tests']==338 and primary['unique_test_statuses']==dict(passed=337,ignored=1)
    assert result.pop('current_source_commit')==operators['head']==extra['head']==HEAD
    for name,key,inventory in [('operators-r3.json','families',operators),
                               ('operators-r2.json','families_added',extra)]:
        for family in inventory[key]:
            family['original_focused_test_literals']=family['focused_tests']
            family['focused_tests']=primary['canonical_family_test_references'][name+'::'+family['id']]
    result['inventories']['operators']=operators
    result['inventories']['operator_addendum']=extra
    registry={}
    external={}
    for name,digest in result['source_sha256'].items():
        path=Path(name)
        if path.is_relative_to(ROOT):
            registry[str(path.relative_to(ROOT))]=digest
        else:
            assert identity(path)['sha256']==digest,name
            external[name]=digest
    for path,meta in union['source_sha256'].items():
        assert meta['source_commit']==HEAD
        assert path not in registry or registry[path]==meta['sha256']
        registry[path]=meta['sha256']
    # Read one immutable Git object stream, independent of current working-tree changes.
    names=sorted(registry)
    raw=subprocess.check_output(['git','cat-file','--batch'],cwd=ROOT,
        input=('\n'.join(HEAD+':'+name for name in names)+'\n').encode())
    offset=0
    for name in names:
        end=raw.index(b'\n',offset)
        header=raw[offset:end].decode().split()
        assert len(header)==3 and header[1]=='blob',name
        size=int(header[2]);offset=end+1
        data=raw[offset:offset+size];offset+=size
        assert raw[offset:offset+1]==b'\n';offset+=1
        assert hashlib.sha256(data).hexdigest()==registry[name],name
    assert offset==len(raw)
    result.update(schema='shardloom.optimization_coverage_inventory.v2',
        status='corrected_source_inventory_and_saved_case_audit_coverage_still_open',
        inventory_source_commit=HEAD,
        verified_unique_source_and_design_hashes=len(registry)+len(external),
        source_sha256=dict(sorted(registry.items())),
        external_design_sha256=dict(sorted(external.items())),
        exact_operator_test_receipts=primary,
        historical_snapshot=True,
        snapshot_note='This inventory describes cac86. Later cardinality/unary edits and their '
                      'validation/performance observations belong to the separate source-demand connection record.')
    result['primary_corrections'] += [
        'Use operators-r3 plus operators-r2, with canonical source-file/function references from the primary R5 audit. '
        'Old inventories and receipt failures remain preserved.',
        'The 136 literal reference occurrences resolve to 338 unique source tests: 337 passed and one ignored. '
        'Repeated family references and repeated logs are not additional tests.',
        'Two further stale source-module prefixes (three occurrences) resolve to exact functions and are '
        'corrected in this view. A successfully resolved function does not make its original prefix accurate.']
    text=(DEST/'catalog.md').read_text()
    text=text.replace('Source inventory: `cac86e8b0a5fa5fa8bf4c900dbef7a703746bfa8`.',
        'Corrected source inventory snapshot: `cac86e8b0a5fa5fa8bf4c900dbef7a703746bfa8`.\n'
        'Later cardinality/unary changes and their observations are tracked separately.\n'
        'This snapshot remains historical and does not label later code as tested by an older run.')
    text=text.replace('The remaining 96 are concrete shared-owner candidates to fix and verify.',
        'At this source snapshot, the remaining 96 are concrete shared-owner candidates.\n'
        'Their later shared implementation and candidate validation have a separate record.')
    text=text.replace('- `catalog.json`: verified source inventories, source hashes, observations and corrections.',
        '- `catalog-r2.json`: corrected immutable source inventories, canonical test references, observations and corrections.\n'
        '- `operator-test-primary-r5.json`: primary verification of all 338 unique cited operator tests; 337 pass, one is ignored.')
    text=text.replace('`operators.json` + `operators-r2.json`','`operators-r3.json` + `operators-r2.json`')
    text += '\n## Exact operator test evidence\n\n'
    text += ('The corrected R3/R2 inventory contains 136 literal reference occurrences. Primary\n'
             'verification against immutable source and saved log lines resolves 338 unique\n'
             'source tests: 337 passed, and one manual attribution test is ignored. Three\n'
             'remaining stale-prefix occurrences are corrected to their exact source files.\n'
             'Repeated references or default/native log occurrences do not count as new tests.\n'
             'These receipts establish the named controls at this snapshot, not universal\n'
             'per-query optimization activation. Original artifacts remain unchanged.\n')
    with markdown.open('x') as stream:stream.write(text)
    result['artifact_identities'].update({name:identity(DEST/name) for name in (
        'catalog.json','operators-r3.json','operators-r2.json','operator-test-primary-r5.json','catalog-r2.md')})
    result['assembler']=identity(Path(__file__))
    with target.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps({key:result[key] for key in ('status','inventory_source_commit',
        'verified_unique_source_and_design_hashes','query_executions_for_inventory')}))


if __name__=='__main__':
    main()
