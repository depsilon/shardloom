"""Extract all saved owner evidence from the validated original 10,000 attempts."""
from collections import Counter, defaultdict
import gzip
import hashlib
import json
import math
from pathlib import Path
import re
import sqlite3
import zlib

from pipeline_runtime import generation, identity

OUT = Path(__file__).resolve().parent
DEST = OUT / 'coverage-inventory-r1'
E = OUT.parent / 'expanded-query-2026-11-03'
LEDGER = OUT / 'full10k-r1/attempts.sqlite'
CAPABILITIES = ('metadata_count','region_exclusion','existing_order',
                'correlated_membership','native_replay','representation_retention')


def main():
    assert __debug__
    destination = DEST / 'full-observed-fields.json'
    case_path = DEST / 'observed-query-evidence.jsonl.gz'
    assert not destination.exists() and not case_path.exists()
    complete_path = OUT / 'full10k-r1/complete.json'
    summary_path = OUT / 'full10k-r1/verified-summary-r1.json'
    complete, summary = (json.loads(path.read_bytes()) for path in (complete_path,summary_path))
    ledger_identity = identity(LEDGER)
    assert ledger_identity['sha256'] == complete['ledger']['sha256'] == summary['ledger']['sha256']
    assert summary['source_commit'] == '9f4580c723f876f087d3e75fb56153b4b099ef20'
    design_path = E/'design.json'
    design = json.loads(design_path.read_bytes())
    assert summary['successful_cases'] == len(design['cases']) == 10000
    before_generation = generation(LEDGER)
    fields = {}
    caps = {name:dict(reported_cases=0, considered_cases=0, admitted_cases=0,
        declined_cases=0, executed_cases=0, totals=Counter(), admission_reasons=Counter(),
        decline_reasons=Counter(), executed_by_surface=Counter(), executed_by_format=Counter(),
        executed_by_family=Counter()) for name in CAPABILITIES}
    clocks, count = [], 0
    with sqlite3.connect(f'file:{LEDGER}?mode=ro',uri=True) as store, gzip.open(case_path,'xt',encoding='utf8') as output:
        for seq, name, status, blob in store.execute('SELECT seq,id,status,packet FROM attempt ORDER BY seq'):
            declaration = design['cases'][seq]
            assert seq == count and name == declaration['id'] and status == 'passed'
            packet = json.loads(zlib.decompress(blob))
            encoded = packet['files']['one.stdout.json']
            raw = encoded['utf8'].encode()
            assert len(raw) == encoded['bytes'] and hashlib.sha256(raw).hexdigest() == encoded['sha256']
            response = json.loads(raw)
            assert response['status'] == 'passed' and response['id'] == name
            assert response['case_identity'] == declaration['case_identity']
            observation = response['observation']
            observed = observation['fields']
            assert observed['fallback_attempted'] == observed['external_engine_invoked'] == 'false'
            assert observed['relational_provider_selection_reason'] == 'native_operator_pipeline'
            seconds = observation['clocks']['engine_execution_seconds']
            assert type(seconds) in (float,int) and math.isfinite(seconds) and seconds >= 0
            clocks.append(seconds)
            for key,value in observed.items():
                if key in {'native_result_payload','local_primitive_native_io_pushdown_proof_basis'}:
                    continue
                record = fields.setdefault(key,dict(reported=0,positive=0,zero=0,
                    numeric_min=None,numeric_max=None,non_numeric_values=Counter(),
                    reported_by_surface=Counter(),positive_by_surface=Counter(),
                    reported_by_format=Counter(),positive_by_format=Counter()))
                record['reported'] += 1
                record['reported_by_surface'][declaration['surface']] += 1
                record['reported_by_format'][declaration['native_format']] += 1
                token = str(value)
                if re.fullmatch('[0-9]+',token):
                    number = int(token)
                    record['positive'] += int(number>0); record['zero'] += int(number==0)
                    record['numeric_min'] = number if record['numeric_min'] is None else min(number,record['numeric_min'])
                    record['numeric_max'] = number if record['numeric_max'] is None else max(number,record['numeric_max'])
                    if number>0:
                        record['positive_by_surface'][declaration['surface']] += 1
                        record['positive_by_format'][declaration['native_format']] += 1
                elif len(token)<=500 and (len(record['non_numeric_values'])<30 or token in record['non_numeric_values']):
                    record['non_numeric_values'][token] += 1
            for capability, aggregate in caps.items():
                prefix = 'local_primitive_native_io_decision_'+capability+'_'
                if prefix+'considered' not in observed:
                    continue
                aggregate['reported_cases'] += 1
                numbers = {key:int(observed[prefix+key]) for key in ('considered','admitted','declined','executed')}
                assert numbers['considered'] == numbers['admitted'] + numbers['declined']
                assert numbers['executed'] <= numbers['admitted']
                aggregate['totals'].update(numbers)
                for key,number in numbers.items():aggregate[key+'_cases'] += int(number>0)
                aggregate['admission_reasons'][observed[prefix+'admission_reasons']] += 1
                aggregate['decline_reasons'][observed[prefix+'decline_reasons']] += 1
                if numbers['executed']:
                    aggregate['executed_by_surface'][declaration['surface']] += 1
                    aggregate['executed_by_format'][declaration['native_format']] += 1
                    aggregate['executed_by_family'][declaration['family']] += 1
            retained = {key:value for key,value in observed.items() if key!='native_result_payload'}
            output.write(json.dumps(dict(seq=seq,id=name,case_identity=declaration['case_identity'],
                source_commit=summary['source_commit'],family=declaration['family'],
                profile=declaration['profile'],surface=declaration['surface'],native_format=declaration['native_format'],
                engine_seconds=seconds,raw_stdout_sha256=encoded['sha256'],fields=retained),
                separators=(',',':'),allow_nan=False)+'\n')
            count += 1
    assert count==10000 and math.fsum(clocks)==summary['complete_10000_engine_seconds']
    assert generation(LEDGER)==before_generation and identity(LEDGER)==ledger_identity
    result=dict(status='verified_saved_owner_evidence',cases=count,query_executions=0,
        source_commit=summary['source_commit'],case_rows=identity(case_path),field_count=len(fields),
        capabilities=caps,fields=dict(sorted(fields.items())),
        sources={str(path):identity(path) for path in (Path(__file__),LEDGER,complete_path,summary_path,design_path)},
        limitation='Observed owner outcomes are per instrumented boundary. Unobserved owners, uninstrumented opportunities and untested surfaces remain open; this is not a 100-percent coverage claim.')
    with destination.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps(dict(status=result['status'],cases=count,field_count=len(fields),
        capabilities={name:{key:record[key] for key in ('reported_cases','executed_cases','declined_cases')} for name,record in caps.items()},query_executions=0)))


if __name__ == '__main__':
    main()
