"""Inventory saved 10k report fields without treating counters as coverage proof."""
from collections import Counter, defaultdict
import gzip
import hashlib
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
DEST = OUT / 'coverage-inventory-r1'
SOURCE = OUT / 'full10k-r1/certificate-cases-r1.jsonl.gz'
DESIGN = OUT.parent / 'expanded-query-2026-11-03/design.json'


def identity(path):
    return dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def main():
    assert __debug__
    destination = DEST / 'observed-fields.json'
    assert not destination.exists()
    design = json.loads(DESIGN.read_bytes())
    assert design['count'] == len(design['cases']) == 10000
    records = {}
    count = 0
    for line in gzip.open(SOURCE, 'rt'):
        row = json.loads(line)
        declaration = design['cases'][count]
        assert row['id'] == declaration['id'] and row['seq'] == count and row['status'] == 'passed'
        count += 1
        fields = row['fields']
        values = {'field:' + name:value for name,value in fields.items()
                  if len(str(value)) <= 500}
        proof = fields['local_primitive_native_io_pushdown_proof_basis']
        tokens = re.findall(r'(?:^|[ ;])([a-z][a-z0-9_]*)=([0-9]+)(?=$|[ ;])', proof)
        assert len(tokens) == len(dict(tokens))
        values.update({'proof:' + name:value for name,value in tokens})
        for name, value in values.items():
            item = records.setdefault(name, dict(reported=0, positive=0, zero=0,
                numeric_min=None, numeric_max=None, value_counts=Counter(),
                by_surface=Counter(), by_format=Counter(), positive_by_surface=Counter(),
                positive_by_format=Counter(), positive_by_family=Counter(), positive_examples=[]))
            item['reported'] += 1
            item['by_surface'][declaration['surface']] += 1
            item['by_format'][declaration['native_format']] += 1
            token = str(value)
            number = int(token) if re.fullmatch('[0-9]+', token) else None
            if number is not None:
                item['numeric_min'] = number if item['numeric_min'] is None else min(number,item['numeric_min'])
                item['numeric_max'] = number if item['numeric_max'] is None else max(number,item['numeric_max'])
                item['zero'] += int(number == 0)
                if number > 0:
                    item['positive'] += 1
                    item['positive_by_surface'][declaration['surface']] += 1
                    item['positive_by_format'][declaration['native_format']] += 1
                    item['positive_by_family'][declaration['family']] += 1
                    if len(item['positive_examples']) < 5:
                        item['positive_examples'].append(row['id'])
            elif len(item['value_counts']) < 20 or token in item['value_counts']:
                item['value_counts'][token] += 1
    assert count == 10000
    result = dict(schema='shardloom.observed_optimization_fields.v1', status='saved_report_inventory',
        source_commit='9f4580c723f876f087d3e75fb56153b4b099ef20',
        cases=count, fields=len(records), query_executions=0,
        sources={str(path):identity(path) for path in (Path(__file__),SOURCE,DESIGN)},
        limitation='A reported or positive counter is not an applicability denominator, mechanism completeness proof, or individual speedup attribution. Missing counters remain unproved.',
        counters=dict(sorted(records.items())))
    DEST.mkdir(exist_ok=True)
    with destination.open('x') as stream:
        json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps({key:result[key] for key in ('status','cases','fields','query_executions')}))


if __name__ == '__main__':
    main()
