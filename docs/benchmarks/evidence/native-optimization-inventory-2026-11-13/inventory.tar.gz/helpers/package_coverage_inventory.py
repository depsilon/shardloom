#!/usr/bin/env python3
"""Build a deterministic, source-hash-verified ShardLoom coverage packet.

Only the Python standard library and Git's read-only cat-file/ls-tree plumbing
are used. This script runs no repository tests, builds, queries, or runtimes.
"""

from __future__ import annotations

import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tarfile
import tempfile


ROOT = Path("/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo")
OUT = Path("/Users/dylan/LocalData/shardloom/native-optimization-coverage-2026-11-13")
INVENTORY = OUT / "coverage-inventory-r1"
PACKAGE = OUT / "compact-inventory-r2"
ARCHIVE = PACKAGE / "inventory.tar.gz"
MANIFEST = PACKAGE / "manifest.json"
README = PACKAGE / "README.md"
VERIFIER = PACKAGE / "verify_archive.py"
HELPER = OUT / "package_coverage_inventory.py"
CAC86 = "cac86e8b0a5fa5fa8bf4c900dbef7a703746bfa8"
C79 = "c79f27a8222e7a1fe5009b07a2a19c1c9dd387bb"
GIB = 1024**3


VERIFIER_SOURCE = r'''#!/usr/bin/env python3
"""Portable stdlib verifier for inventory.tar.gz and its adjacent manifest."""
from __future__ import annotations
import argparse, gzip, hashlib, json, re, tarfile
from pathlib import Path, PurePosixPath

def sha(data): return hashlib.sha256(data).hexdigest()
def safe(name):
    p=PurePosixPath(name)
    return bool(name) and not p.is_absolute() and ".." not in p.parts and "\\" not in name and p.as_posix()==name
def main():
    if not __debug__:
        raise SystemExit("verification requires Python assertions; do not use -O")
    ap=argparse.ArgumentParser()
    ap.add_argument("archive", nargs="?", default=str(Path(__file__).with_name("inventory.tar.gz")))
    ap.add_argument("--manifest", type=Path)
    a=ap.parse_args(); archive=Path(a.archive); outer=a.manifest or archive.with_name("manifest.json")
    ext=json.loads(outer.read_text()); raw=archive.read_bytes()
    assert ext["schema"]=="shardloom.compact_coverage_inventory.outer_manifest.v1", "unsupported outer manifest schema"
    assert len(raw)==ext["archive_bytes"] and sha(raw)==ext["archive_sha256"], "archive hash/size mismatch"
    with tarfile.open(archive, "r:gz") as tf:
        members=tf.getmembers(); names=[m.name for m in members]
        assert len(names)==len(set(names)), "duplicate archive members"
        assert all(safe(n) and m.isfile() for n,m in zip(names,members)), "unsafe/non-regular archive member"
        by_name={m.name:m for m in members}; assert "MANIFEST.json" in by_name
        inner_bytes=tf.extractfile(by_name["MANIFEST.json"]).read()
        assert sha(inner_bytes)==ext["inner_manifest_sha256"], "inner manifest hash mismatch"
        inner=json.loads(inner_bytes)
        assert inner["schema"]=="shardloom.compact_coverage_inventory.manifest.v1", "unsupported inner manifest schema"
        member_paths=[m["member_path"] for m in inner["members"]]
        assert len(member_paths)==len(set(member_paths)), "duplicate member paths in inner manifest"
        assert inner["member_count_excluding_manifest"]==len(member_paths), "inner manifest payload count mismatch"
        listed={m["member_path"]:m for m in inner["members"]}
        assert set(names)==set(listed)|{"MANIFEST.json"}, "missing or extra archive members"
        for name,record in listed.items():
            data=tf.extractfile(by_name[name]).read()
            assert len(data)==record["bytes"] and sha(data)==record["sha256"], f"member hash mismatch: {name}"
        all_sources=[]
        for registry_name,registry in inner["source_registries"].items():
            entries=registry["entries"]; paths=[e["source_path"] for e in entries]
            assert len(paths)==len(set(paths)), f"duplicate source registry path: {registry_name}"
            assert registry["missing_members"]==[] and registry["negative_members"]==[]
            assert registry["status"]=="complete"
            for entry in entries:
                member=entry["member_path"]
                assert member in listed and listed[member]["sha256"]==entry["sha256"], f"source registry/member mismatch: {member}"
                all_sources.append((registry_name,entry["source_path"]))
        counts=inner["source_registry_counts"]
        assert counts["cac86"]["entries"]==253 and counts["c79f27a"]["entries"]==15
        assert len(all_sources)==268
        assert inner["missing_members"]==[] and inner["negative_members"]==[]
        catalog_path="artifacts/coverage-inventory-r1/catalog-r2.json"
        obligations_path="artifacts/coverage-inventory-r1/vortex-validation-obligations.json"
        catalog=json.loads(tf.extractfile(by_name[catalog_path]).read())
        obligations=json.loads(tf.extractfile(by_name[obligations_path]).read())
        source_maps={name:{e["source_path"]:e["sha256"] for e in reg["entries"]} for name,reg in inner["source_registries"].items()}
        assert source_maps["cac86"]==catalog["source_sha256"], "cac86 source registry differs from catalog-r2"
        expected_c79={e["path"]:e["sha256"] for e in obligations["source_sha256_registry"]}
        assert source_maps["c79f27a"]==expected_c79, "c79 source registry differs from validation obligations"
        assert inner["source_registries"]["cac86"]["commit"]==catalog["inventory_source_commit"]
        assert inner["source_registries"]["c79f27a"]["commit"]==obligations["source_commit"]
        external=inner["external_design_registry"]
        assert len(external)==2
        for entry in external:
            member=entry["member_path"]
            assert member in listed and listed[member]["sha256"]==entry["sha256"], f"external design mismatch: {member}"
        assert {e["original_path"]:e["sha256"] for e in external}==catalog["external_design_sha256"]
        primary_path="artifacts/coverage-inventory-r1/operator-test-primary-r5.json"
        primary=json.loads(tf.extractfile(by_name[primary_path]).read())
        assert primary["unique_source_tests"]==338
        assert primary["unique_test_statuses"]=={"passed":337,"ignored":1}
        assert inner["claim_limits"]["universal_activation_claimed"] is False
        assert inner["claim_limits"]["independent_semantic_reconstruction_claimed"] is False
        assert inner["claim_limits"]["complete_result_replay_claimed"] is False
    assert ext["status"]=="complete_no_negative_or_missing_members"
    assert ext["missing_members"]==[] and ext["negative_members"]==[]
    assert ext["member_count_excluding_manifest"]==len(listed)
    assert ext["source_registry_counts"]==inner["source_registry_counts"]
    print(json.dumps({"status":"verified","archive_bytes":len(raw),"members":len(names),"source_files":268,"source_registry_counts":ext["source_registry_counts"]},indent=2))
    return 0
if __name__=="__main__": raise SystemExit(main())
'''


README_TEXT = f"""# Compact ShardLoom optimization coverage inventory

This portable packet freezes the source and evidence inputs used for the
optimization coverage inventory. Inventory/evidence snapshot: 2026-11-13.

## Source snapshots

- The 253 catalog source files are the exact Git blob bytes from `{CAC86}`.
- The 15 current validation-obligation files are the exact Git blob bytes from
  `{C79}` and are stored beneath a separate source prefix.
- The retained 10,000-query observations are from
  `9f4580c723f876f087d3e75fb56153b4b099ef20`, an earlier source snapshot than
  the cac86 inventory and c79 validation obligations.
- The two external design files are copied byte-for-byte and checked against
  `catalog-r2.json`'s external design SHA-256 registry.
- All files from `coverage-inventory-r1` are retained at their input-relative
  paths. Historical corrections and earlier inventories remain present as
  historical artifacts; later accepted inventories do not rewrite them.

## Evidence counts and limits

The accepted `operator-test-primary-r5.json` reports **338 unique source tests**:
337 passed and one ignored. The ignored test is not counted as passed. This is
not an exact full-test-suite claim and does not establish complete result replay.
The retained 10,000-query declaration/identity evidence remains bound to its
recorded `9f4580c` source snapshot; it is not reassigned to `{CAC86}` or `{C79}`.

This archive preserves artifacts and source bytes. It does not independently
reconstruct test semantics, prove universal optimization activation, claim an
exact full test pass, or claim complete query-result replay. Source inventories,
test receipts, capability reports and retained observations retain their own
scope and historical limits. No runtime binaries, original SQLite databases or
reference ledgers are included.

## Verification

Run `python3 verify_archive.py` from this directory. The verifier uses only the
Python standard library and checks archive/member safety, manifest and member
hashes, source registry uniqueness/counts, and absence of missing/negative
source-member status. It does not run engine code or tests.
"""


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_member(name: str) -> str:
    p = PurePosixPath(name)
    if not name or p.is_absolute() or ".." in p.parts or "\\" in name or p.as_posix() != name:
        raise ValueError(f"unsafe archive member path: {name!r}")
    return name


def git_tree(commit: str) -> dict[str, tuple[str, str]]:
    raw = subprocess.check_output(["git", "ls-tree", "-r", "-z", commit], cwd=ROOT)
    result = {}
    for record in raw.split(b"\0"):
        if not record:
            continue
        meta, path = record.split(b"\t", 1)
        mode, kind, oid = meta.decode("ascii").split(" ")
        if kind == "blob":
            result[path.decode("utf-8")] = (mode, oid)
    return result


def cat_file_batch(object_ids: list[str]) -> dict[str, bytes]:
    unique = sorted(set(object_ids))
    proc = subprocess.run(
        ["git", "cat-file", "--batch"],
        cwd=ROOT,
        input=("\n".join(unique) + "\n").encode("ascii"),
        stdout=subprocess.PIPE,
        check=True,
    )
    data = proc.stdout
    pos = 0
    found = {}
    for expected_oid in unique:
        end = data.index(b"\n", pos)
        header = data[pos:end].decode("ascii").split()
        pos = end + 1
        if len(header) != 3 or header[0] != expected_oid or header[1] != "blob":
            raise ValueError(f"unexpected git cat-file header for {expected_oid}: {header}")
        size = int(header[2])
        blob = data[pos : pos + size]
        pos += size
        if len(blob) != size or data[pos : pos + 1] != b"\n":
            raise ValueError(f"truncated git cat-file response for {expected_oid}")
        pos += 1
        found[expected_oid] = blob
    if pos != len(data):
        raise ValueError("unexpected trailing bytes from git cat-file --batch")
    return found


def regular_inputs(directory: Path) -> list[Path]:
    files = []
    for path in sorted(directory.rglob("*")):
        if path.is_symlink():
            raise ValueError(f"symlink is not an archive input: {path}")
        if path.is_file():
            files.append(path)
        elif not path.is_dir():
            raise ValueError(f"non-regular archive input: {path}")
    return files


def helper_inputs() -> list[Path]:
    paths = set(OUT.glob("coverage_*.py"))
    paths.update(OUT.glob("assemble_coverage_catalog*.py"))
    paths.update({OUT / "verify_operator_receipts_primary.py", OUT / "verify_cardinality_pools.py", HELPER})
    return sorted(p for p in paths if p.is_file())


def add_member(members: dict[str, dict], name: str, data: bytes, *, source_path: str, source_commit: str | None, provenance: str):
    safe_member(name)
    if name in members:
        raise ValueError(f"duplicate archive member path: {name}")
    members[name] = {
        "member_path": name,
        "bytes": len(data),
        "sha256": sha(data),
        "source_path": source_path,
        "source_commit": source_commit,
        "provenance": provenance,
        "data": data,
    }


def gather_sources(catalog: dict, obligations: dict):
    source_rows = []
    if len(catalog["source_sha256"]) != 253:
        raise ValueError("catalog-r2 source registry does not contain exactly 253 paths")
    if len(obligations["source_sha256_registry"]) != 15:
        raise ValueError("validation-obligation source registry does not contain exactly 15 paths")
    for path, expected in catalog["source_sha256"].items():
        source_rows.append((CAC86, path, expected, f"sources/{CAC86}/{path}", "catalog-r2 source_sha256"))
    for entry in obligations["source_sha256_registry"]:
        source_rows.append((C79, entry["path"], entry["sha256"], f"sources/{C79}/{entry['path']}", "vortex-validation-obligations source_sha256_registry"))
    trees = {commit: git_tree(commit) for commit in (CAC86, C79)}
    object_rows = []
    for commit, path, expected, member, registry in source_rows:
        if not safe_member(path) or not safe_member(member):
            raise ValueError(f"unsafe source path: {path}")
        item = trees[commit].get(path)
        if item is None:
            raise ValueError(f"source path absent from Git tree {commit}: {path}")
        mode, oid = item
        if mode not in ("100644", "100755"):
            raise ValueError(f"source path is not a regular Git file at {commit}: {path} (mode {mode})")
        object_rows.append((commit, path, expected, member, registry, oid))
    blobs = cat_file_batch([r[-1] for r in object_rows])
    verified = []
    for commit, path, expected, member, registry, oid in object_rows:
        data = blobs[oid]
        actual = sha(data)
        if actual != expected:
            raise ValueError(f"source hash mismatch at {commit}:{path}; expected {expected}, got {actual}")
        verified.append((commit, path, expected, member, registry, data))
    return verified


def run_storage_guard(reserve_bytes: int):
    guard = ROOT / "scripts/local_uat_storage.py"
    reserve_gib = reserve_bytes / GIB
    subprocess.run(
        [
            sys.executable,
            str(guard),
            "--root", str(OUT),
            "--source", str(INVENTORY),
            "--target", str(ARCHIVE),
            "--logs", str(OUT / "logs"),
            "--reserve-gib", str(reserve_gib),
            "--min-free-gib", "12",
            "--max-workspace-gib", "100",
        ],
        cwd=ROOT,
        check=True,
    )


def make_tar(path: Path, payload: dict[str, dict], inner_manifest: bytes):
    archive_members = dict(payload)
    archive_members["MANIFEST.json"] = {
        "member_path": "MANIFEST.json",
        "bytes": len(inner_manifest),
        "sha256": sha(inner_manifest),
        "data": inner_manifest,
    }
    names = sorted(archive_members)
    if len(names) != len(set(names)):
        raise ValueError("duplicate archive members before writing")
    with path.open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0, compresslevel=9) as gz:
            with tarfile.open(fileobj=gz, mode="w", format=tarfile.PAX_FORMAT) as tf:
                for name in names:
                    safe_member(name)
                    record = archive_members[name]
                    info = tarfile.TarInfo(name)
                    info.size = record["bytes"]
                    info.mtime = 0
                    info.mode = 0o644
                    info.uid = info.gid = 0
                    info.uname = info.gname = ""
                    info.type = tarfile.REGTYPE
                    import io
                    tf.addfile(info, io.BytesIO(record["data"]))


def build():
    catalog = json.loads((INVENTORY / "catalog-r2.json").read_text())
    obligations = json.loads((INVENTORY / "vortex-validation-obligations.json").read_text())
    if catalog.get("inventory_source_commit") != CAC86:
        raise ValueError("catalog-r2 is not bound to the requested cac86 source snapshot")
    if obligations.get("source_commit") != C79:
        raise ValueError("validation obligations are not bound to the requested c79 source snapshot")
    external = catalog["external_design_sha256"]
    external_root = Path("/Users/dylan/LocalData/shardloom/expanded-query-2026-11-03")

    # Verify every old/current source blob through one cat-file --batch pass before any archive write.
    verified_sources = gather_sources(catalog, obligations)
    members: dict[str, dict] = {}
    source_registries = {
        "cac86": {"commit": CAC86, "status": "complete", "missing_members": [], "negative_members": [], "entries": []},
        "c79f27a": {"commit": C79, "status": "complete", "missing_members": [], "negative_members": [], "entries": []},
    }
    for commit, path, digest, member, registry, data in verified_sources:
        add_member(members, member, data, source_path=path, source_commit=commit, provenance=registry)
        key = "cac86" if commit == CAC86 else "c79f27a"
        source_registries[key]["entries"].append({"source_path": path, "member_path": member, "sha256": digest})

    # Every current inventory file is packaged at its input-relative path.
    for path in regular_inputs(INVENTORY):
        rel = path.relative_to(INVENTORY).as_posix()
        add_member(members, f"artifacts/coverage-inventory-r1/{rel}", path.read_bytes(), source_path=str(path), source_commit=None, provenance="raw current/historical inventory artifact")

    # External design files share the declared expanded-query input root and retain their relative paths.
    for original, expected in sorted(external.items()):
        path = Path(original)
        if not path.is_relative_to(external_root):
            raise ValueError(f"external design path is outside expected input root: {path}")
        data = path.read_bytes()
        if sha(data) != expected:
            raise ValueError(f"external design hash mismatch for {path}")
        rel = path.relative_to(external_root).as_posix()
        add_member(members, f"external-design/expanded-query-2026-11-03/{rel}", data, source_path=str(path), source_commit=None, provenance="catalog-r2 external_design_sha256")

    # Preserve the current union audit and its verifier, plus its exact retained test logs/receipts.
    extra_artifacts = [
        OUT / "operator-test-union-r4.json",
        OUT / "operator-test-union-r4.md",
        OUT / "verify_operator_test_union_r4.py",
        OUT / "sort-native-tests-r1.json",
        OUT / "sort-default-tests-r1.json",
    ]
    r5 = json.loads((INVENTORY / "operator-test-primary-r5.json").read_text())
    log_paths = {Path(m["log_path"]) for detail in r5["exact_function_source_and_log_details"].values() for m in detail.get("log_matches", [])}
    log_paths.update({OUT / "logs/sort-native-tests-r1.log", OUT / "logs/sort-default-tests-r1.log"})
    for path in sorted(set(extra_artifacts) | log_paths):
        if not path.is_file() or path.is_symlink():
            raise ValueError(f"required retained artifact/log missing or not regular: {path}")
        rel = path.relative_to(OUT).as_posix()
        member = f"retained-evidence/native-optimization-coverage-2026-11-13/{rel}"
        add_member(members, member, path.read_bytes(), source_path=str(path), source_commit=None, provenance="retained R4 audit / native-default test receipt evidence")

    # Relevant producing helpers and this package builder are preserved as original files.
    helper_paths = helper_inputs()
    expected_helpers = {OUT / "verify_operator_receipts_primary.py", OUT / "verify_cardinality_pools.py", HELPER}
    if not expected_helpers.issubset(set(helper_paths)):
        raise ValueError("one or more required inventory helpers are absent")
    for path in helper_paths:
        add_member(members, f"helpers/{path.relative_to(OUT).as_posix()}", path.read_bytes(), source_path=str(path), source_commit=None, provenance="original local evidence helper")

    # Generate static reader documentation and the portable stdlib verifier.
    readme_bytes = README_TEXT.encode("utf-8")
    verifier_bytes = VERIFIER_SOURCE.encode("utf-8")
    add_member(members, "README.md", readme_bytes, source_path=str(README), source_commit=None, provenance="generated packet README")
    add_member(members, "verify_archive.py", verifier_bytes, source_path=str(VERIFIER), source_commit=None, provenance="generated portable stdlib verifier")

    # Reserve conservatively for uncompressed payload plus metadata/temporary output, then write.
    payload_bytes = sum(row["bytes"] for row in members.values())
    reserve_bytes = payload_bytes + 128 * 1024**2
    run_storage_guard(reserve_bytes)

    source_counts = {
        "cac86": {"commit": CAC86, "entries": len(source_registries["cac86"]["entries"])},
        "c79f27a": {"commit": C79, "entries": len(source_registries["c79f27a"]["entries"])},
    }
    inner_manifest_data = {
        "schema": "shardloom.compact_coverage_inventory.manifest.v1",
        "source_snapshots": {"catalog_sources": CAC86, "validation_obligations": C79, "observed_10000_cases": catalog["observed_10000_source_commit"]},
        "created_date": "2026-11-13",
        "member_count_excluding_manifest": len(members),
        "members": [{k: v for k, v in members[name].items() if k != "data"} for name in sorted(members)],
        "source_registry_counts": source_counts,
        "source_registries": source_registries,
        "external_design_registry": [
            {"original_path": p, "member_path": f"external-design/expanded-query-2026-11-03/{Path(p).relative_to(external_root).as_posix()}", "sha256": h}
            for p, h in sorted(external.items())
        ],
        "claim_limits": {
            "independent_semantic_reconstruction_claimed": False,
            "universal_activation_claimed": False,
            "exact_full_test_pass_claimed": False,
            "complete_result_replay_claimed": False,
            "primary_test_receipt_counts": {"unique_source_tests": 338, "passed": 337, "ignored": 1},
        },
        "negative_members": [],
        "missing_members": [],
    }
    inner = (json.dumps(inner_manifest_data, sort_keys=True, indent=2, ensure_ascii=False) + "\n").encode()

    PACKAGE.mkdir(parents=True, exist_ok=True)
    README.write_bytes(readme_bytes)
    VERIFIER.write_bytes(verifier_bytes)
    os.chmod(VERIFIER, 0o644)
    with tempfile.NamedTemporaryFile(prefix="inventory-", suffix=".tar.gz.tmp", dir=PACKAGE, delete=False) as tmp:
        temp_path = Path(tmp.name)
    try:
        make_tar(temp_path, members, inner)
        os.replace(temp_path, ARCHIVE)
    finally:
        if temp_path.exists():
            temp_path.unlink()
    outer_manifest = {
        "schema": "shardloom.compact_coverage_inventory.outer_manifest.v1",
        "archive_path": ARCHIVE.name,
        "archive_bytes": ARCHIVE.stat().st_size,
        "archive_sha256": sha(ARCHIVE.read_bytes()),
        "inner_manifest_sha256": sha(inner),
        "member_count_excluding_manifest": len(members),
        "source_registry_counts": source_counts,
        "status": "complete_no_negative_or_missing_members",
        "missing_members": [],
        "negative_members": [],
    }
    MANIFEST.write_text(json.dumps(outer_manifest, sort_keys=True, indent=2) + "\n")
    (PACKAGE / "verify_archive.py").chmod(0o644)
    print(json.dumps({"status": "archived", "archive": str(ARCHIVE), "archive_bytes": ARCHIVE.stat().st_size, "members": len(members) + 1, "payload_bytes": payload_bytes, "source_cac86": source_counts["cac86"]["entries"], "source_c79f27a": source_counts["c79f27a"]["entries"], "I_files": len(regular_inputs(INVENTORY)), "helpers": len(helper_paths)}, indent=2))


if __name__ == "__main__":
    try:
        build()
    except Exception as exc:
        print(f"package_coverage_inventory: {exc}", file=sys.stderr)
        raise
