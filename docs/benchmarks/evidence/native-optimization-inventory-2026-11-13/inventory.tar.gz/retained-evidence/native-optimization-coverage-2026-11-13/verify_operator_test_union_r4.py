#!/usr/bin/env python3
"""Pure parser for operator-test-union-r4.json; runs no tests or engine code."""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
from collections import Counter
from pathlib import Path

OUT = Path("/Users/dylan/LocalData/shardloom/native-optimization-coverage-2026-11-13")
INV = OUT / "coverage-inventory-r1"
REPO = Path("/Users/dylan/.codex/worktrees/native-vector-representations/shardloom-local-repo")
AUDIT = OUT / "operator-test-union-r4.json"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def snapshot_bytes(commit: str, path: str) -> bytes:
    return subprocess.check_output(["git", "show", f"{commit}:{path}"], cwd=REPO)


def parse_test_declarations(data: bytes) -> list[dict[str, object]]:
    lines = data.decode("utf-8").splitlines()
    tests = []
    for index, line in enumerate(lines):
        if not re.match(r"\s*#\[(?:tokio::)?test\]\s*$", line):
            continue
        fn_index = next(
            (
                j
                for j in range(index + 1, min(index + 10, len(lines)))
                if re.match(r"\s*fn\s+\w+\s*\(", lines[j])
            ),
            None,
        )
        if fn_index is None:
            continue
        name = re.match(r"\s*fn\s+(\w+)\s*\(", lines[fn_index]).group(1)
        tests.append(
            {
                "function": name,
                "source_line": fn_index + 1,
                "source_text": lines[fn_index],
                "test_attribute_line": index + 1,
                "test_attribute_text": line,
                "ignored_in_source": any("#[ignore" in lines[k] for k in range(index, fn_index + 1)),
            }
        )
    return tests


def log_status(line: str) -> str | None:
    line = line.strip()
    if re.search(r"\.\.\.\s+ok\s*$", line):
        return "passed"
    if re.search(r"\.\.\.\s+FAILED\s*$", line):
        return "failed"
    if re.search(r"\.\.\.\s+ignored(?:,.*)?$", line):
        return "ignored"
    return None


def main() -> int:
    audit = json.loads(AUDIT.read_text())
    commit = audit["source_snapshot"]
    assert commit == "cac86e8b0a5fa5fa8bf4c900dbef7a703746bfa8"

    source_inventory = [
        ("operators-r3.json", "families"),
        ("operators-r2.json", "families_added"),
    ]
    expected_refs = set()
    for filename, family_key in source_inventory:
        data = json.loads((INV / filename).read_text())
        for family in data[family_key]:
            for literal in family.get("focused_tests", []):
                expected_refs.add((filename, family["id"], literal))
    actual_refs = {
        (row["inventory"], row["family"], row["literal_reference"])
        for row in audit["references"]
    }
    assert expected_refs == actual_refs, (len(expected_refs), len(actual_refs))

    for path, meta in audit["inventory_sha256"].items():
        content = Path(path).read_bytes()
        assert len(content) == meta["bytes"] and sha(content) == meta["sha256"], path
    log_lines = {}
    for path, meta in audit["log_sha256"].items():
        content = Path(path).read_bytes()
        assert len(content) == meta["bytes"] and sha(content) == meta["sha256"], path
        log_lines[path] = content.decode("utf-8", errors="replace").splitlines()

    for path, meta in audit["source_sha256"].items():
        content = snapshot_bytes(meta["source_commit"], path)
        assert len(content) == meta["bytes"] and sha(content) == meta["sha256"], path
        parsed = parse_test_declarations(content)
        indexed = {(test["function"], test["source_line"]): test for test in parsed}
        for row in audit["references"]:
            for test in row["source_tests"]:
                if test["source_path"] != path:
                    continue
                key = (test["function"], test["source_line"])
                assert key in indexed, (row["literal_reference"], key)
                current = indexed[key]
                for field in (
                    "source_text",
                    "test_attribute_line",
                    "test_attribute_text",
                    "ignored_in_source",
                ):
                    assert test[field] == current[field], (path, key, field)

    # A module-only reference must enumerate every #[test] declaration in each resolved file.
    # A function reference must select exactly that function, never a name-like neighbor.
    for row in audit["references"]:
        source_files = row["source_resolution"]["source_files"]
        if row["source_resolution"]["module_reference"]:
            expected_tests = set()
            for path in source_files:
                parsed = parse_test_declarations(snapshot_bytes(commit, path))
                expected_tests.update((path, test["function"], test["source_line"]) for test in parsed)
            actual_tests = {
                (test["source_path"], test["function"], test["source_line"])
                for test in row["source_tests"]
            }
            assert expected_tests == actual_tests, row["literal_reference"]
        elif row["source_tests"]:
            expected_function = row["literal_reference"].rsplit("::", 1)[-1]
            actual_functions = {test["function"] for test in row["source_tests"]}
            assert actual_functions == {expected_function}, row["literal_reference"]

    prior_verified = prior_mismatches = 0
    log_counts = Counter()
    for row in audit["references"]:
        for test in row["source_tests"]:
            for match in test["log_matches"]:
                path, number = match["log_path"], match["line"]
                line = log_lines[path][number - 1]
                assert line.strip() == match["line_text"].strip()
                assert log_status(line) == match["status"]
                log_counts[match["status"]] += 1
                if row["family"] == "exact_metadata_count_and_encoded_physical_count_contracts" and "encoded_count_physical_kernel" in row["literal_reference"]:
                    expected = f"test encoded_count_physical_kernel::tests::{test['function']} ..."
                    assert line.startswith(expected), (row["literal_reference"], line)
        for check in row["prior_receipt_verification"]:
            if check["status"] == "verified":
                prior_verified += 1
            elif check["status"] == "mismatch":
                prior_mismatches += 1

    assert prior_mismatches == 0
    assert prior_verified == audit["counts"]["prior_receipt_lines_verified"]
    assert dict(log_counts) == audit["counts"]["exact_log_lines_by_status"]
    print(
        json.dumps(
            {
                "status": "verified",
                "literal_references": len(actual_refs),
                "source_files": len(audit["source_sha256"]),
                "log_files": len(log_lines),
                "prior_receipt_lines_verified": prior_verified,
                "prior_receipt_line_mismatches": prior_mismatches,
                "log_line_statuses": dict(log_counts),
                "unresolved_or_misleading_references": len(audit["unresolved_or_misleading_references"]),
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
