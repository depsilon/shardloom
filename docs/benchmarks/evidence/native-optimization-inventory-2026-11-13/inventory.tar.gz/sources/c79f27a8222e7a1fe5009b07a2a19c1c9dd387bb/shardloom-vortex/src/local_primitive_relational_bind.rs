//! Lossless schema and source binding before native relational row execution.

use super::{
    BoundUnary, DType, MaterializedPredicateEvaluator, MemoryLease, Node, NodeKind, Nullability,
    PathBuf, PreparedVortexSource, ReservedVec, ResidentMemorySource, ResidentVortexSession,
    Result, ScanSource, SetKind, VortexQueryPrimitiveKind, VortexQueryPrimitiveRequest,
    VortexRelationalPlan, failed, native_relational_join, native_relational_sort, vortex_error,
};
use crate::native_payload_schema::Scope as SchemaScope;
use crate::relational_query::{
    VortexRelationalAsOfJoin, VortexRelationalJoin, VortexRelationalJoinColumn,
    VortexRelationalJoinKey, VortexRelationalJoinKind as JoinKind, VortexRelationalScan,
    VortexRelationalSet, VortexRelationalSide as Side,
};
use shardloom_core::{PredicateExpr, StatValue};
use vortex::array::dtype::PType;

#[path = "local_primitive_relational_aggregate_bind.rs"]
mod aggregate;
#[path = "local_primitive_relational_dynamic_bind.rs"]
mod dynamic;
#[path = "local_primitive_relational_expression_bind.rs"]
mod expression;
#[path = "local_primitive_relational_grouping_bind.rs"]
mod grouping;
pub(in crate::local_primitives) use expression::{arithmetic_dtype, literal_dtype};
#[path = "local_primitive_relational_scan_bind.rs"]
mod scan;
#[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
#[path = "local_primitive_relational_source_demand.rs"]
mod source_demand;
#[path = "local_primitive_relational_subquery_bind.rs"]
mod subquery;
pub(super) use subquery::validate_relation as validate_subquery_relation;
#[path = "local_primitive_relational_pipeline_bind.rs"]
mod pipeline;
#[path = "local_primitive_relational_subquery_sources.rs"]
mod subquery_sources;
#[path = "local_primitive_relational_transform_bind.rs"]
mod transform;
#[path = "local_primitive_relational_window_bind.rs"]
mod window;

#[path = "local_primitive_relational_gap_fill_bind.rs"]
mod gap_fill;
#[path = "local_primitive_relational_retained_bind.rs"]
mod retained;

pub(super) struct Binder<'a> {
    session: &'a ResidentVortexSession,
    cancellation: shardloom_exec::compute_pool::CancellationToken,
    sources: ReservedVec<PreparedVortexSource>,
    paths: ReservedVec<PathBuf>,
    memory_sources: ReservedVec<(shardloom_core::DatasetUri, ResidentMemorySource)>,
    batch_sources: ReservedVec<super::batch_input::Source>,
    metadata: MemoryLease,
    outer_fields: Option<Vec<(String, DType)>>,
    parameterized_binding: bool,
    observation_names: std::collections::BTreeSet<String>,
    execution: Option<dynamic::ExecutionBinding<'a>>,
    source_scope: Option<std::sync::Arc<[SourceIndex]>>,
    source_metadata: Option<std::sync::Arc<MemoryLease>>,
    resolved: ReservedVec<Option<Node>>,
    scope: std::sync::Arc<()>,
    deferred: ReservedVec<Option<super::DeferredRelation>>,
    retained: ReservedVec<super::retained::Binding>,
    recursion: Option<retained::Scope>,
}

pub(super) struct BoundSources {
    pub(super) sources: Vec<PreparedVortexSource>,
    pub(super) source_paths: Vec<PathBuf>,
    pub(super) memory_sources: Vec<(shardloom_core::DatasetUri, ResidentMemorySource)>,
    pub(super) batch_sources: Vec<super::batch_input::Source>,
    pub(super) metadata: MemoryLease,
}

#[derive(Clone, Copy, PartialEq, Eq)]
pub(super) enum SourceIndex {
    File(usize),
    Memory(usize),
    Batch(usize),
}

/// Borrow both frontend declarations through the same schema/output binder.
#[derive(Clone, Copy)]
struct JoinInput<'a> {
    left: &'a VortexRelationalPlan,
    right: &'a VortexRelationalPlan,
    kind: JoinKind,
    keys: &'a [VortexRelationalJoinKey],
    condition: Option<&'a shardloom_core::Expression>,
    columns: &'a [VortexRelationalJoinColumn],
}

impl<'a> Binder<'a> {
    fn schema_scope(&self) -> SchemaScope<'_> {
        (self.session.memory(), &self.cancellation).into()
    }

    pub(super) fn shared_memory_pool(&self) -> shardloom_exec::live_memory::LiveMemoryPool {
        self.session.memory().clone()
    }

    pub(super) fn cancellation_token(&self) -> shardloom_exec::compute_pool::CancellationToken {
        self.cancellation.clone()
    }

    pub(super) fn reserve_input_scratch(&self, bytes: u64) -> Result<MemoryLease> {
        self.session.reserve_input_scratch(bytes)
    }

    pub(super) fn new(session: &'a ResidentVortexSession) -> Result<Self> {
        Self::new_with_cancellation(
            session,
            &shardloom_exec::compute_pool::CancellationToken::default(),
        )
    }

    pub(super) fn new_with_cancellation(
        session: &'a ResidentVortexSession,
        cancellation: &shardloom_exec::compute_pool::CancellationToken,
    ) -> Result<Self> {
        cancellation.check()?;
        Ok(Self {
            session,
            cancellation: cancellation.clone(),
            sources: ReservedVec::new(session.memory())?,
            paths: ReservedVec::new(session.memory())?,
            memory_sources: ReservedVec::new(session.memory())?,
            batch_sources: ReservedVec::new(session.memory())?,
            metadata: session.memory().reserve(4096)?,
            outer_fields: None,
            parameterized_binding: false,
            observation_names: std::collections::BTreeSet::new(),
            execution: None,
            source_scope: None,
            source_metadata: None,
            resolved: ReservedVec::new(session.memory())?,
            scope: std::sync::Arc::new(()),
            deferred: ReservedVec::new(session.memory())?,
            retained: ReservedVec::new(session.memory())?,
            recursion: None,
        })
    }

    pub(super) fn charge(&mut self, bytes: usize) -> Result<()> {
        self.cancellation.check()?;
        self.metadata.resize(
            self.metadata
                .bytes()
                .checked_add(u64::try_from(bytes).map_err(vortex_error)?)
                .ok_or_else(|| failed("plan metadata size overflow"))?,
        )
    }

    pub(super) fn charge_items(&mut self, count: usize, per_item: usize) -> Result<()> {
        self.charge(
            count
                .checked_mul(per_item)
                .ok_or_else(|| failed("plan metadata size overflow"))?,
        )
    }

    pub(super) fn charge_fields(&mut self, count: usize) -> Result<()> {
        self.charge_items(count, 4096)
    }

    pub(super) fn charge_names<'b>(
        &mut self,
        names: impl IntoIterator<Item = &'b str>,
    ) -> Result<()> {
        self.charge(names_bytes(names)?)
    }

    pub(super) fn charge_named_fields(&mut self, fields: &[(String, DType)]) -> Result<()> {
        self.charge_names(fields.iter().map(|(name, _)| name.as_str()))
    }

    // Existing fixed field/expression envelopes cover names through 256 bytes.
    // Admit longer names before cloning aliases or expression references.
    pub(super) fn charge_name(&mut self, name: &str) -> Result<()> {
        validate_name(name)?;
        self.charge(
            name.len()
                .saturating_sub(256)
                .checked_mul(16)
                .ok_or_else(|| failed("column name metadata size overflow"))?,
        )
    }

    pub(super) fn finish(mut self) -> Result<BoundSources> {
        self.cancellation.check()?;
        let (sources, mut source_credit) = self.sources.into_parts();
        let (paths, mut path_credit) = self.paths.into_parts();
        let (memory_sources, mut memory_credit) = self.memory_sources.into_parts();
        let (batch_sources, mut batch_credit) = self.batch_sources.into_parts();
        self.metadata.absorb(&mut source_credit)?;
        self.metadata.absorb(&mut path_credit)?;
        self.metadata.absorb(&mut memory_credit)?;
        self.metadata.absorb(&mut batch_credit)?;
        Ok(BoundSources {
            sources,
            source_paths: paths,
            memory_sources,
            batch_sources,
            metadata: self.metadata,
        })
    }

    pub(super) fn register_memory_source(
        &mut self,
        uri: shardloom_core::DatasetUri,
        build: impl FnOnce(&ResidentVortexSession) -> Result<ResidentMemorySource>,
    ) -> Result<()> {
        if self.execution.is_some()
            || self
                .batch_sources
                .values
                .iter()
                .any(|source| source.uri == uri)
            || !uri.as_str().starts_with("memory://")
            || uri.as_str().len() <= "memory://".len()
            || uri.as_str().len() > 16_384
            || self
                .memory_sources
                .values
                .iter()
                .any(|(prior, _)| *prior == uri)
            || self.source_count() >= 128
        {
            return Err(failed(
                "memory source requires a unique bounded memory URI before execution",
            ));
        }
        self.charge(uri.as_str().len() * 8 + 4096)?;
        self.memory_sources.reserve_one()?;
        let source = build(self.session)?;
        if !source.belongs_to_session(self.session) {
            return Err(failed("memory source belongs to another resource owner"));
        }
        self.memory_sources.values.push((uri, source));
        Ok(())
    }

    pub(super) fn register_batch_source(
        &mut self,
        uri: shardloom_core::DatasetUri,
        build_schema: impl FnOnce(&ResidentVortexSession) -> Result<ResidentMemorySource>,
    ) -> Result<()> {
        if self.execution.is_some()
            || self
                .batch_sources
                .values
                .iter()
                .any(|source| source.uri == uri)
            || self
                .memory_sources
                .values
                .iter()
                .any(|(prior, _)| *prior == uri)
            || self.source_count() >= 128
            || !uri.as_str().starts_with("memory://")
            || uri.as_str().len() <= "memory://".len()
            || uri.as_str().len() > 16_384
        {
            return Err(super::batch_input::failed(
                "streaming input requires a unique bounded memory URI before execution",
            ));
        }
        self.charge(uri.as_str().len() * 8 + 4096)?;
        self.batch_sources.reserve_one()?;
        let schema = build_schema(self.session)?;
        if !schema.belongs_to_session(self.session)
            || !schema.is_batch_source()
            || schema.row_count() != 0
        {
            return Err(super::batch_input::failed(
                "streaming schema requires an empty from_batch_columns source from this session",
            ));
        }
        self.batch_sources.values.push(super::batch_input::Source {
            uri,
            schema,
            usage: super::batch_input::Usage::default(),
            #[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
            local: None,
        });
        Ok(())
    }

    #[cfg(all(feature = "vortex-write", feature = "universal-format-io"))]
    pub(super) fn register_local_source(
        &mut self,
        uri: shardloom_core::DatasetUri,
        source: std::sync::Arc<crate::universal_format_io::demanded::LocalColumnarSource>,
    ) -> Result<()> {
        if self.execution.is_some()
            || self.source_count() >= 128
            || uri.as_str().len() > 16_384
            || uri.as_str().starts_with("memory://")
            || self
                .batch_sources
                .values
                .iter()
                .any(|source| source.uri == uri)
            || self
                .memory_sources
                .values
                .iter()
                .any(|(prior, _)| *prior == uri)
        {
            return Err(failed(
                "local source requires a unique bounded file URI before execution",
            ));
        }
        self.charge(uri.as_str().len() * 8 + 4096)?;
        self.batch_sources.reserve_one()?;
        let local = source.prepare(
            &shardloom_plan::SourceDemand::default(),
            self.session,
            &self.cancellation,
        )?;
        // The prepared descriptor now retains the admitted source ownership.
        drop(source);
        let schema = local.empty_schema(self.session, &self.cancellation)?;
        self.batch_sources.values.push(super::batch_input::Source {
            uri,
            schema,
            usage: super::batch_input::Usage::default(),
            local: Some(local),
        });
        Ok(())
    }

    pub(super) fn validate_batch_plan(&mut self, plan: &VortexRelationalPlan) -> Result<()> {
        for source in &mut self.batch_sources.values {
            source
                .usage
                .extend(super::batch_input::classify(plan, &source.uri)?);
        }
        Ok(())
    }

    fn source_count(&self) -> usize {
        self.sources.values.len()
            + self.memory_sources.values.len()
            + self.batch_sources.values.len()
    }

    fn input(&mut self, uri: &shardloom_core::DatasetUri) -> Result<SourceIndex> {
        let source = if let Some(index) = self
            .batch_sources
            .values
            .iter()
            .position(|source| &source.uri == uri)
        {
            SourceIndex::Batch(index)
        } else if let Some(index) = self
            .memory_sources
            .values
            .iter()
            .position(|(prior, _)| prior == uri)
        {
            SourceIndex::Memory(index)
        } else {
            SourceIndex::File(self.source(uri)?)
        };
        if self
            .source_scope
            .as_ref()
            .is_some_and(|allowed| !allowed.contains(&source))
        {
            return Err(failed(
                "dynamic subquery accessed a source outside its declaration",
            ));
        }
        Ok(source)
    }

    fn source_dtype(&self, source: SourceIndex) -> &DType {
        match source {
            SourceIndex::File(index) => self.sources.values[index].dtype(),
            SourceIndex::Memory(index) => self.memory_sources.values[index].1.dtype(),
            SourceIndex::Batch(index) => self.batch_sources.values[index].schema.dtype(),
        }
    }

    pub(super) fn bind(&mut self, input: &VortexRelationalPlan, depth: usize) -> Result<Node> {
        self.cancellation.check()?;
        if depth == 0 && self.execution.is_some() {
            self.validate_subquery_source_scope(input, 0)?;
            // Dynamic lowering can resolve separate subtrees before returning
            // the final plan. Validate each before its discovery reads rows;
            // the execution provider then requires every source's explicit end.
            for index in 0..self.batch_sources.values.len() {
                let usage = super::batch_input::classify_dynamic(
                    input,
                    &self.batch_sources.values[index].uri,
                    self.outer_fields.is_some(),
                )?;
                self.require_batch_usage(index, usage)?;
            }
        }
        if depth > crate::relational_query::NATIVE_RECURSION_LIMIT {
            return Err(failed("recursive plan exceeds 24 levels"));
        }
        // Total operator count grows under the shared metadata lease. The
        // independent recursion guard remains until traversal is iterative.
        self.charge(4096)?;
        match input {
            VortexRelationalPlan::Input(_) => Err(failed(
                "native declaration input must be bound before preparation",
            )),
            VortexRelationalPlan::DeferredSubquery(_) => Err(failed(
                "deferred schema declarations require a correlated subquery relation",
            )),
            VortexRelationalPlan::ExecutionResult(reference) => self.take_resolved(reference),
            VortexRelationalPlan::Materialized(input) => self.retained_relation(
                super::retained::Definition::Materialized(std::sync::Arc::clone(input)),
                depth,
            ),
            VortexRelationalPlan::Recursive(input) => self.retained_relation(
                super::retained::Definition::Recursive(std::sync::Arc::clone(input)),
                depth,
            ),
            VortexRelationalPlan::RecursiveInput(input) => self.recursive_input(input),
            VortexRelationalPlan::Scan(scan) => self.scan(scan),
            VortexRelationalPlan::Join(join) => self.join(join, depth),
            VortexRelationalPlan::AsOfJoin(join) => self.asof_join(join, depth),
            VortexRelationalPlan::Set(set) => self.set(set, depth),
            VortexRelationalPlan::Window(window) => self.window(window, depth),
            VortexRelationalPlan::GapFill(fill) => self.gap_fill(fill, depth),
            VortexRelationalPlan::Subquery(subquery) => self.subquery(subquery, depth, false),
            VortexRelationalPlan::CorrelatedSubquery(subquery) => {
                self.subquery(subquery, depth, true)
            }
            VortexRelationalPlan::Outer => {
                let bytes = names_bytes(
                    self.outer_fields
                        .as_ref()
                        .ok_or_else(|| {
                            failed("outer row source requires a correlated subquery scope")
                        })?
                        .iter()
                        .map(|(name, _)| name.as_str()),
                )?;
                self.charge(bytes)?;
                Ok(Node {
                    fields: self
                        .outer_fields
                        .as_ref()
                        .ok_or_else(|| failed("outer row schema is absent"))?
                        .clone(),
                    kind: NodeKind::Outer,
                })
            }
            VortexRelationalPlan::Project(project) => self.project(project, depth),
            VortexRelationalPlan::Filter(filter) => self.filter(filter, depth),
            VortexRelationalPlan::Sort(sort) => self.sort(sort, depth),
            VortexRelationalPlan::Limit(limit) => self.limit(limit, depth),
            VortexRelationalPlan::Pipeline(pipeline) => self.pipeline(pipeline, depth),
            VortexRelationalPlan::Aggregate(aggregate) => self.aggregate(aggregate, depth),
            VortexRelationalPlan::Unary(unary) => self.unary(unary, depth),
        }
    }

    fn unary(
        &mut self,
        unary: &crate::relational_query::VortexRelationalUnary,
        depth: usize,
    ) -> Result<Node> {
        let mut input = Box::new(self.bind(&unary.input, depth + 1)?);
        self.charge_named_fields(&input.fields)?;
        let operation = BoundUnary::for_relation(
            &unary.request,
            &DType::struct_(input.fields.clone(), Nullability::NonNullable),
            self.schema_scope(),
        )?;
        // The bound operation already includes every key, value, weight and
        // hidden predicate input. Its explicit projection may narrow an owned
        // source without pushing a prefix across population/completion barriers.
        if operation.input_columns().len() < input.fields.len() {
            self.narrow_source_demand(
                &mut input,
                operation.input_columns().iter().map(String::as_str),
            )?;
        }
        if unary.request.kind == VortexQueryPrimitiveKind::PivotRows {
            return self.complete_pivot(&mut input, operation);
        }
        validate_width(operation.fields().len())?;
        self.charge_named_fields(operation.fields())?;
        for (name, dtype) in operation.fields() {
            validate_name(name)?;
            if unary.request.kind == VortexQueryPrimitiveKind::ExplodeRows {
                validate_payload(dtype, self.schema_scope())?;
            } else {
                validate_key(dtype, self.schema_scope())?;
            }
        }
        validate_unique(operation.fields())?;
        Ok(Node {
            fields: operation.fields().to_vec(),
            kind: NodeKind::Unary {
                input,
                operation: Box::new(operation),
            },
        })
    }

    pub(super) fn seed_source(
        &mut self,
        uri: &shardloom_core::DatasetUri,
        source: PreparedVortexSource,
    ) -> Result<()> {
        self.cancellation.check()?;
        if uri.as_str().len() > 16_384 {
            return Err(failed("source URI exceeds 16384 bytes"));
        }
        let request = VortexQueryPrimitiveRequest::project(
            uri.clone(),
            shardloom_plan::ProjectionRequest::All,
        );
        let session = super::super::prepared_dispatch::source_session(&source, &request, None)?;
        if !session.same_owner(self.session) {
            return Err(failed("retained source belongs to another resource owner"));
        }
        let path = super::super::local_vortex_path(uri, request.kind)?
            .ok_or_else(|| failed("relational scans require local Vortex input"))?;
        let path = std::path::absolute(path).map_err(vortex_error)?;
        self.charge(
            uri.as_str()
                .len()
                .checked_mul(8)
                .ok_or_else(|| failed("source metadata overflow"))?,
        )?;
        self.paths.reserve_one()?;
        self.sources.reserve_one()?;
        self.paths.values.push(path);
        self.sources.values.push(source);
        Ok(())
    }

    pub(super) fn source(&mut self, uri: &shardloom_core::DatasetUri) -> Result<usize> {
        self.cancellation.check()?;
        if uri.as_str().len() > 16_384 {
            return Err(failed("source URI exceeds 16384 bytes"));
        }
        self.charge(uri.as_str().len() * 8)?;
        let path = super::super::local_vortex_path(uri, VortexQueryPrimitiveKind::ProjectColumns)?
            .ok_or_else(|| failed("relational scans require local Vortex input"))?;
        let path = std::path::absolute(path).map_err(vortex_error)?;
        let source = if let Some(index) = self.paths.values.iter().position(|prior| prior == &path)
        {
            index
        } else {
            if self.execution.is_some() {
                return Err(failed(
                    "execution-time binding cannot add an undeclared source",
                ));
            }
            if self.source_count() >= 128 {
                return Err(failed("relational preparation exceeds 128 sources"));
            }
            self.paths.reserve_one()?;
            self.sources.reserve_one()?;
            let source = self
                .session
                .prepare_file_with_cancellation(&path, &self.cancellation)?;
            self.paths.values.push(path);
            self.sources.values.push(source);
            self.sources.values.len() - 1
        };
        Ok(source)
    }

    pub(super) fn primitive_plan(
        &mut self,
        request: &VortexQueryPrimitiveRequest,
        input: VortexRelationalPlan,
    ) -> Result<VortexRelationalPlan> {
        let uri = request
            .source_uri
            .as_ref()
            .ok_or_else(|| failed("primitive source is absent"))?;
        let source = self.input(uri)?;
        super::request_plan::lower(request, input, self.source_dtype(source))
    }

    pub(super) fn source_columns(
        &mut self,
        uri: &shardloom_core::DatasetUri,
    ) -> Result<Vec<String>> {
        let source = self.input(uri)?;
        let fields = self
            .source_dtype(source)
            .as_struct_fields_opt()
            .ok_or_else(|| failed("relational source requires a struct schema"))?;
        let bytes = names_bytes(fields.names().iter().map(AsRef::as_ref))?;
        self.charge(bytes)?;
        let fields = self
            .source_dtype(source)
            .as_struct_fields_opt()
            .ok_or_else(|| failed("relational source schema is absent"))?;
        fields
            .names()
            .iter()
            // Match ProjectionRequest::All without removing physical metadata
            // that native operators may still address explicitly.
            .filter(|name| !super::super::is_shardloom_hidden_derived_column(name.as_ref()))
            .map(|name| {
                validate_name(name.as_ref())?;
                Ok(name.to_string())
            })
            .collect()
    }

    fn scan(&mut self, scan: &VortexRelationalScan) -> Result<Node> {
        if let Some(predicate) = &scan.predicate {
            self.charge(predicate_bytes(predicate, 0)?)?;
        }
        if let shardloom_plan::ProjectionRequest::Columns(columns) = &scan.projection {
            validate_width(columns.len())?;
            for column in columns {
                validate_name(column.as_str())?;
            }
            self.charge_names(columns.iter().map(shardloom_core::ColumnRef::as_str))?;
        }
        let source = self.input(&scan.source_uri)?;
        let dtype = self.source_dtype(source);
        let source_fields = dtype
            .as_struct_fields_opt()
            .ok_or_else(|| failed("relational source requires a struct schema"))?;
        let schema_bytes = names_bytes(source_fields.names().iter().map(AsRef::as_ref))?;
        self.charge(schema_bytes)?;
        let dtype = self.source_dtype(source);
        if let Some(predicate) = &scan.predicate {
            validate_predicate_fields(predicate, dtype)?;
        }
        let mut request =
            VortexQueryPrimitiveRequest::project(scan.source_uri.clone(), scan.projection.clone());
        request.predicate.clone_from(&scan.predicate);
        if request.predicate.is_some() {
            request.kind = VortexQueryPrimitiveKind::FilterAndProject;
        }
        let plan = super::super::row_export_scan_plan(&request, dtype)?;
        let names = super::super::projected_column_names(dtype, &scan.projection, request.kind)?;
        validate_width(names.len())?;
        let fields = names
            .iter()
            .map(|name| {
                validate_name(name)?;
                let dtype = super::super::completed_result::source_field(dtype, name)?;
                validate_payload(&dtype, self.schema_scope())?;
                Ok((name.clone(), dtype))
            })
            .collect::<Result<Vec<_>>>()?;
        validate_unique(&fields)?;
        let columns = if plan.projected_columns.is_empty() {
            super::super::local_field_names(dtype, request.kind)?
        } else {
            plan.projected_columns.clone()
        };
        let residual = plan
            .residual_predicate
            .as_ref()
            .map(|predicate| MaterializedPredicateEvaluator::compile(predicate, &columns))
            .transpose()?;
        let source = match source {
            SourceIndex::File(index) => ScanSource::File(index),
            SourceIndex::Memory(index) => ScanSource::Memory(Box::new(
                self.memory_sources.values[index].1.prepare_projection(
                    &columns.iter().map(String::as_str).collect::<Vec<_>>(),
                    plan.filter.clone(),
                    None,
                )?,
            )),
            SourceIndex::Batch(index) => ScanSource::Batch {
                index,
                projection: Box::new(self.batch_sources.values[index].schema.prepare_projection(
                    &columns.iter().map(String::as_str).collect::<Vec<_>>(),
                    plan.filter.clone(),
                    None,
                )?),
            },
        };
        for (_, dtype) in &fields {
            self.charge(
                usize::try_from(super::super::native_payload::metadata_bytes(
                    dtype,
                    self.schema_scope(),
                )?)
                .map_err(vortex_error)?,
            )?;
        }
        Ok(Node {
            fields,
            kind: NodeKind::Scan {
                source,
                source_uri: scan.source_uri.clone(),
                predicate: scan.predicate.clone(),
                plan,
                columns,
                residual,
            },
        })
    }

    fn join(&mut self, join: &VortexRelationalJoin, depth: usize) -> Result<Node> {
        self.join_inputs(
            JoinInput {
                left: &join.left,
                right: &join.right,
                kind: join.kind,
                keys: &join.keys,
                condition: join.condition.as_ref(),
                columns: &join.columns,
            },
            depth,
        )
    }

    fn asof_join(&mut self, join: &VortexRelationalAsOfJoin, depth: usize) -> Result<Node> {
        self.charge_items(join.by.len().saturating_add(1), 8192)?;
        let keys: Vec<_> = join
            .by
            .iter()
            .chain(std::iter::once(&join.on))
            .cloned()
            .collect();
        let mut node = self.join_inputs(
            JoinInput {
                left: &join.left,
                right: &join.right,
                kind: JoinKind::Left,
                keys: &keys,
                condition: None,
                columns: &join.columns,
            },
            depth,
        )?;
        let NodeKind::Join { left, right, spec } = &mut node.kind else {
            return Err(failed("as-of binding did not produce a native join"));
        };
        let left_dtype = field(&left.fields, join.on.left.as_str())?;
        let right_dtype = field(&right.fields, join.on.right.as_str())?;
        let integers = matches!(left_dtype, DType::Primitive(kind, _) if integer(*kind).is_some())
            && matches!(right_dtype, DType::Primitive(kind, _) if integer(*kind).is_some());
        let temporal = crate::native_temporal::temporal_dtype(left_dtype).is_some()
            && left_dtype.as_nonnullable() == right_dtype.as_nonnullable();
        if !integers && !temporal {
            return Err(failed(
                "ASOF JOIN requires integer ordering keys or identical temporal kinds, units and timezones; use an explicit lossless cast",
            ));
        }
        spec.asof = Some(join.options);
        Ok(node)
    }

    fn join_inputs(&mut self, join: JoinInput<'_>, depth: usize) -> Result<Node> {
        validate_width(join.columns.len())?;
        if join.keys.len() > 128
            || (join.kind == JoinKind::Cross && (!join.keys.is_empty() || join.condition.is_some()))
            || (join.kind != JoinKind::Cross && join.keys.is_empty() && join.condition.is_none())
        {
            return Err(failed(
                "cross joins require no ON clause; other joins require keys or a native ON predicate",
            ));
        }
        for key in join.keys {
            validate_name(key.left.as_str())?;
            validate_name(key.right.as_str())?;
        }
        for column in join.columns {
            validate_name(&column.output_column)?;
            validate_name(column.column.as_str())?;
        }
        self.charge_names(
            join.keys
                .iter()
                .flat_map(|key| [key.left.as_str(), key.right.as_str()]),
        )?;
        self.charge_names(
            join.columns
                .iter()
                .flat_map(|column| [column.output_column.as_str(), column.column.as_str()]),
        )?;
        let mut left = Box::new(self.bind(join.left, depth + 1)?);
        let mut right = Box::new(self.bind(join.right, depth + 1)?);
        let mut left_keys = Vec::new();
        let mut right_keys = Vec::new();
        for key in join.keys {
            let left_dtype = field(&left.fields, key.left.as_str())?;
            let right_dtype = field(&right.fields, key.right.as_str())?;
            validate_key_pair(left_dtype, right_dtype, self.schema_scope())?;
            left_keys.push(key.left.as_str().to_owned());
            right_keys.push(key.right.as_str().to_owned());
        }
        let mut fields = Vec::new();
        let mut columns = Vec::new();
        for column in join.columns {
            if column.side == Side::Right
                && matches!(join.kind, JoinKind::LeftSemi | JoinKind::LeftAnti)
            {
                return Err(failed("semi and anti joins expose left columns only"));
            }
            let dtype = field(
                if column.side == Side::Left {
                    &left.fields
                } else {
                    &right.fields
                },
                column.column.as_str(),
            )?;
            let extend_null = match column.side {
                Side::Left => matches!(join.kind, JoinKind::Right | JoinKind::Full),
                Side::Right => matches!(join.kind, JoinKind::Left | JoinKind::Full),
            };
            fields.push((
                column.output_column.clone(),
                if extend_null {
                    dtype.as_nullable()
                } else {
                    dtype.clone()
                },
            ));
            columns.push((column.side, column.column.as_str().to_owned()));
        }
        validate_unique(&fields)?;
        let condition = self.join_condition(join.condition, &left.fields, &right.fields)?;
        let mut right_key_fields = Vec::new();
        if matches!(join.kind, JoinKind::LeftSemi | JoinKind::LeftAnti) && condition.is_none() {
            self.charge_names(right_keys.iter().map(String::as_str))?;
            for name in &right_keys {
                if !right_key_fields.iter().any(|(prior, _)| prior == name) {
                    right_key_fields.push((name.clone(), field(&right.fields, name)?.clone()));
                }
            }
        }
        let spec = native_relational_join::Spec {
            retained: None,
            kind: join.kind,
            asof: None,
            left_keys,
            right_keys,
            right_key_fields,
            fields: fields.clone(),
            columns,
            condition,
        };
        self.narrow_join_inputs(&mut left, &mut right, &spec)?;
        Ok(Node {
            fields,
            kind: NodeKind::Join { left, right, spec },
        })
    }

    fn set(&mut self, set: &VortexRelationalSet, depth: usize) -> Result<Node> {
        let left = Box::new(self.bind(&set.left, depth + 1)?);
        let right = Box::new(self.bind(&set.right, depth + 1)?);
        if left.fields.len() != right.fields.len() {
            return Err(failed("set branches have different column counts"));
        }
        self.charge_named_fields(&left.fields)?;
        let fields = left
            .fields
            .iter()
            .zip(&right.fields)
            .map(|((name, left), (_, right))| Ok((name.clone(), common_dtype(left, right)?)))
            .collect::<Result<Vec<_>>>()?;
        if set.kind != SetKind::UnionAll {
            for (_, dtype) in &fields {
                validate_key(dtype, self.schema_scope())?;
            }
        }
        let names = fields.iter().map(|(name, _)| name.clone()).collect();
        Ok(Node {
            fields,
            kind: NodeKind::Set {
                left,
                right,
                kind: set.kind,
                names,
            },
        })
    }
}

fn validate_width(width: usize) -> Result<()> {
    if width == 0 {
        return Err(failed("relational schema requires at least one field"));
    }
    Ok(())
}

fn validate_name(name: &str) -> Result<()> {
    if name.is_empty() || name.len() > i32::MAX as usize {
        return Err(failed(
            "column names require a nonempty value within the native metadata offset range",
        ));
    }
    Ok(())
}

fn names_bytes<'b>(names: impl IntoIterator<Item = &'b str>) -> Result<usize> {
    names.into_iter().try_fold(0usize, |bytes, name| {
        validate_name(name)?;
        name.len()
            .checked_mul(16)
            .and_then(|name_bytes| bytes.checked_add(name_bytes.max(4096)))
            .ok_or_else(|| failed("column name metadata size overflow"))
    })
}

fn validate_unique(fields: &[(String, DType)]) -> Result<()> {
    // Binder field admission precedes this temporary, borrowed-name index.
    let mut names = std::collections::BTreeSet::new();
    for (name, _) in fields {
        if !names.insert(name) {
            return Err(failed("output column names must be unique"));
        }
    }
    Ok(())
}

fn validate_scalar(dtype: &DType) -> Result<()> {
    if !matches!(
        dtype,
        DType::Bool(_) | DType::Utf8(_) | DType::Primitive(_, _)
    ) {
        return Err(failed(
            "operated scalar requires bool, integer, F16/F32/F64 or UTF8 fields",
        ));
    }
    Ok(())
}

fn validate_payload(dtype: &DType, scope: SchemaScope<'_>) -> Result<()> {
    super::super::native_payload::metadata_bytes(dtype, scope).map(|_| ())
}

fn validate_key(dtype: &DType, scope: SchemaScope<'_>) -> Result<()> {
    // Admit the full expanded walk before recursive semantic classification.
    validate_payload(dtype, scope)?;
    if crate::native_variant::contains(dtype) {
        return Err(failed(
            "Variant values are payload-only; compare, group, order or join on ordinary columns",
        ));
    }
    if crate::native_vector::contains(dtype) {
        return Err(failed(
            "sparse and quantized vectors are payload-only; compare, group, order or join on ordinary columns",
        ));
    }
    if crate::native_tensor::contains(dtype) || crate::native_variable_tensor::contains(dtype) {
        return Err(failed(
            "tensor values are payload-only; compare, group, order or join on ordinary columns",
        ));
    }
    if crate::native_embedding::contains(dtype) {
        return Err(failed(
            "embedding values are payload-only; compare, group, order or join on ordinary columns",
        ));
    }
    if super::super::native_payload::is_nested(dtype) {
        Ok(())
    } else {
        validate_flat_operand(dtype)
    }
}

fn validate_flat_operand(dtype: &DType) -> Result<()> {
    match dtype {
        DType::Extension(_) if crate::native_uuid::storage(dtype).is_some() => Ok(()),
        DType::Binary(_) => Ok(()),
        DType::Decimal(decimal, _) if crate::native_payload_schema::admitted_decimal(*decimal) => {
            Ok(())
        }
        DType::Extension(_) if crate::native_payload_schema::temporal_storage(dtype).is_some() => {
            Ok(())
        }
        _ => validate_scalar(dtype),
    }
}

fn validate_predicate_fields(predicate: &PredicateExpr, dtype: &DType) -> Result<()> {
    if let Some(column) = predicate.column() {
        validate_scalar(&super::super::completed_result::source_field(
            dtype,
            column.as_str(),
        )?)?;
    }
    if let PredicateExpr::And(children) = predicate {
        for child in children {
            validate_predicate_fields(child, dtype)?;
        }
    }
    Ok(())
}

fn field<'a>(fields: &'a [(String, DType)], name: &str) -> Result<&'a DType> {
    fields
        .iter()
        .find(|(field, _)| field == name)
        .map(|(_, dtype)| dtype)
        .ok_or_else(|| failed(&format!("column '{name}' is absent from the bound input")))
}

fn integer(ptype: PType) -> Option<(bool, u8)> {
    Some(match ptype {
        PType::I8 => (true, 8),
        PType::I16 => (true, 16),
        PType::I32 => (true, 32),
        PType::I64 => (true, 64),
        PType::U8 => (false, 8),
        PType::U16 => (false, 16),
        PType::U32 => (false, 32),
        PType::U64 => (false, 64),
        _ => return None,
    })
}

fn validate_key_pair(left: &DType, right: &DType, scope: SchemaScope<'_>) -> Result<()> {
    validate_key(left, scope)?;
    validate_key(right, scope)?;
    if left.as_nonnullable() == right.as_nonnullable() {
        return Ok(());
    }
    if super::super::native_payload::is_nested(left) && left.eq_ignore_nullability(right) {
        return Ok(());
    }
    if let (DType::Primitive(left, _), DType::Primitive(right, _)) = (left, right)
        && (integer(*left).is_some() || matches!(left, PType::F16 | PType::F32 | PType::F64))
        && (integer(*right).is_some() || matches!(right, PType::F16 | PType::F32 | PType::F64))
    {
        return Ok(());
    }
    Err(failed(
        "incompatible key types require an explicit lossless cast",
    ))
}

fn common_dtype(left: &DType, right: &DType) -> Result<DType> {
    let nullability = if left.is_nullable() || right.is_nullable() {
        Nullability::Nullable
    } else {
        Nullability::NonNullable
    };
    if left.as_nonnullable() == right.as_nonnullable() {
        return Ok(left.with_nullability(nullability));
    }
    if let (DType::Primitive(left, _), DType::Primitive(right, _)) = (left, right) {
        if matches!(left, PType::F16 | PType::F32 | PType::F64)
            && matches!(right, PType::F16 | PType::F32 | PType::F64)
        {
            return Ok(DType::Primitive(PType::F64, nullability));
        }
        if let (Some((left_signed, left_bits)), Some((right_signed, right_bits))) =
            (integer(*left), integer(*right))
        {
            let signed = left_signed || right_signed;
            let bits = if left_signed == right_signed {
                left_bits.max(right_bits)
            } else if left_signed {
                left_bits.max(right_bits + 1)
            } else {
                right_bits.max(left_bits + 1)
            };
            let ptype = match (signed, bits) {
                (false, 0..=8) => PType::U8,
                (false, 9..=16) => PType::U16,
                (false, 17..=32) => PType::U32,
                (false, 33..=64) => PType::U64,
                (true, 0..=8) => PType::I8,
                (true, 9..=16) => PType::I16,
                (true, 17..=32) => PType::I32,
                (true, 33..=64) => PType::I64,
                _ => {
                    return Err(failed(
                        "set integer domains have no lossless native common dtype",
                    ));
                }
            };
            return Ok(DType::Primitive(ptype, nullability));
        }
    }
    Err(failed(
        "set branches require a lossless common scalar schema",
    ))
}

fn predicate_bytes(predicate: &PredicateExpr, depth: usize) -> Result<usize> {
    if depth > 24 {
        return Err(failed("predicate nesting exceeds 24 levels"));
    }
    let mut bytes = 4096usize;
    let mut add = |value: usize| -> Result<()> {
        bytes = bytes
            .checked_add(value)
            .ok_or_else(|| failed("predicate metadata overflow"))?;
        Ok(())
    };
    if let Some(column) = predicate.column() {
        validate_name(column.as_str())?;
        add(column.as_str().len() * 8)?;
    }
    match predicate {
        PredicateExpr::And(predicates) => {
            for predicate in predicates {
                add(predicate_bytes(predicate, depth + 1)?)?;
            }
        }
        PredicateExpr::Compare {
            value: StatValue::Utf8(value),
            ..
        } => add(value
            .len()
            .checked_mul(8)
            .ok_or_else(|| failed("predicate string overflow"))?)?,
        PredicateExpr::StringContains { needle, .. } => add(needle
            .len()
            .checked_mul(8)
            .ok_or_else(|| failed("predicate string overflow"))?)?,
        PredicateExpr::InList { values, .. } => {
            add(values
                .len()
                .checked_mul(256)
                .ok_or_else(|| failed("predicate list overflow"))?)?;
            for value in values {
                if let StatValue::Utf8(value) = value {
                    add(value
                        .len()
                        .checked_mul(8)
                        .ok_or_else(|| failed("predicate string overflow"))?)?;
                }
            }
        }
        _ => {}
    }
    Ok(bytes)
}
