//! Vortex primitive execution CLI handlers.
//!
//! This module starts the physical split for Vortex primitive command handlers
//! while preserving existing no-fallback execution contracts. This slice only
//! owns `vortex-count`, `vortex-count-where`, `vortex-project`,
//! `vortex-filter`, `vortex-filter-project`, `vortex-run`,
//! `vortex-local-exec`, `vortex-bounded-local-exec`, and
//! `vortex-query-trace`; broader non-primitive handler extraction remains
//! staged.

use std::process::ExitCode;

use shardloom_core::{
    ColumnRef, CommandStatus, ComparisonOp, CorrectnessFixture, CorrectnessValidationPlan,
    DatasetRef, DatasetUri, Diagnostic, ExecutionCertificate, ExecutionResources, ExpectedOutcome,
    NativeIoCertificate, OutputFormat, PredicateExpr, ScalarValue, ShardLoomError, StatValue,
};
use shardloom_exec::{
    AdaptiveSizingPolicy, BoundedMemoryPolicy, ByteSize, EncodedStreamingBatchPlanInput,
    EncodedStreamingBatchPlanReport, MemoryBudget, StreamingSink, StreamingSource,
    plan_encoded_streaming_batches,
};
use shardloom_plan::ProjectionRequest;
use shardloom_vortex::{
    VortexAggregateExpression, VortexAggregateHavingExpr, VortexAggregateOrderExpr,
    VortexBoundedExecutionPolicy, VortexBoundedExecutionReport, VortexCountCandidateSource,
    VortexCountReadinessRequest, VortexEncodedCountKernelAdmissionReport,
    VortexEncodedCountPhysicalKernelReport, VortexEncodedPredicateEvaluationReport,
    VortexEncodedPredicateEvaluationStatus, VortexEncodedReadExecutionMode,
    VortexEncodedReadExecutionStatus, VortexEncodedReadExecutorFeatureStatus,
    VortexExplodeProjectionRequest, VortexExpressionProjectionRequest, VortexExpressionRewrite,
    VortexLocalEngineReport, VortexLocalEngineRequest, VortexLocalEngineWhyReport,
    VortexLocalExecutionReport, VortexLocalExecutionStatus, VortexLocalPrimitiveExecutionPolicy,
    VortexLocalPrimitiveExecutionReport, VortexMeltProjectionRequest, VortexMetadataOpenRequest,
    VortexMetadataProbeReport, VortexMetadataSummaryReport, VortexPivotProjectionRequest,
    VortexQueryPrimitiveRequest, VortexQueryPrimitiveResult, VortexQueryPrimitiveValue,
    VortexRollingWindowRequest, VortexSelectionVectorFilterKernelAdmissionReport,
    VortexSelectionVectorFilterKernelReport, VortexSimpleAggregateMeasure,
    VortexSimpleAggregateRequest, VortexSortRowsRequest, VortexSortTiePolicy,
    VortexStreamingBatchRuntimeReport, VortexStructuredProjectionColumn,
    VortexStructuredProjectionExpr, VortexStructuredProjectionRequest,
    VortexTaskSchedulingDecision, VortexWorkAvoidedMetricKind, VortexWorkAvoidedReport,
    admit_vortex_encoded_count_kernel, admit_vortex_selection_vector_filter_kernel,
    build_vortex_runtime_task_graph, evaluate_vortex_encoded_predicate_segments,
    evaluate_vortex_encoded_read_readiness, evaluate_vortex_local_encoded_count_physical_kernel,
    evaluate_vortex_query_primitive, evaluate_vortex_query_primitive_with_analysis,
    evaluate_vortex_selection_vector_filter_kernel, execute_vortex_bounded_local_query,
    execute_vortex_count_all_from_approved_local_scan,
    execute_vortex_count_all_from_approved_local_scan_result, execute_vortex_local_query_primitive,
    local_encoded_count_execution_certificate, local_encoded_count_native_io_certificate,
    local_primitive_execution_certificate, local_primitive_native_io_certificate,
    open_vortex_metadata_only, parse_vortex_local_engine_primitive,
    plan_native_vortex_universal_input, plan_vortex_count_readiness,
    plan_vortex_encoded_count_data_path_approval, plan_vortex_memory_safety,
    plan_vortex_read_from_universal_input, plan_vortex_scheduler_queue,
    size_vortex_runtime_task_graph, summarize_vortex_metadata_probe,
    vortex_encoded_read_local_scan_count_api_boundary, vortex_encoded_read_spike_feature_enabled,
};

use crate::cli_output::{emit, emit_error};
use crate::command_context::{CommandAdmission, CommandContext};
#[cfg(not(all(feature = "vortex-local-primitives", unix)))]
use shardloom_vortex::{execute_vortex_local_primitive_with_policy, run_vortex_local_engine};

#[path = "vortex_aggregate_spill_policy.rs"]
mod aggregate_spill_policy;

#[path = "native_decision_evidence.rs"]
mod decision_evidence;

#[cfg(feature = "vortex-write")]
pub(crate) fn append_native_output_decisions(
    fields: &mut Vec<(String, String)>,
    decisions: &shardloom_core::native_io_decisions::NativeIoCapabilityDecisions,
) {
    decision_evidence::append(fields, "native_vortex_result_export_replay", decisions);
}

const VORTEX_PRIMITIVE_SCAN_PUSHDOWN_SCHEMA_VERSION: &str =
    "shardloom.vortex_primitive.scan_pushdown_contract.v1";

fn push_field(fields: &mut Vec<(String, String)>, key: &str, value: &str) {
    fields.push((key.to_string(), value.to_string()));
}

fn push_count_field(fields: &mut Vec<(String, String)>, key: &str, value: usize) {
    fields.push((key.to_string(), value.to_string()));
}

fn push_u64_field(fields: &mut Vec<(String, String)>, key: &str, value: u64) {
    fields.push((key.to_string(), value.to_string()));
}

fn push_bool_field(fields: &mut Vec<(String, String)>, key: &str, value: bool) {
    fields.push((key.to_string(), value.to_string()));
}

pub(crate) fn append_vortex_work_avoided_fields(
    fields: &mut Vec<(String, String)>,
    report: Option<&VortexWorkAvoidedReport>,
) {
    let Some(report) = report else {
        push_count_field(fields, "work_avoided_metrics", 0);
        push_count_field(fields, "work_avoided_known_metrics", 0);
        push_count_field(fields, "work_avoided_unknown_metrics", 0);
        return;
    };
    push_count_field(fields, "work_avoided_metrics", report.metric_count());
    push_count_field(
        fields,
        "work_avoided_known_metrics",
        report.known_metric_count(),
    );
    push_count_field(
        fields,
        "work_avoided_unknown_metrics",
        report.unknown_metric_count(),
    );
    append_vortex_work_avoided_metric_fields(
        fields,
        report,
        VortexWorkAvoidedMetricKind::DecodeAvoided,
    );
    append_vortex_work_avoided_metric_fields(
        fields,
        report,
        VortexWorkAvoidedMetricKind::MaterializationAvoided,
    );
    append_vortex_work_avoided_metric_fields(
        fields,
        report,
        VortexWorkAvoidedMetricKind::ObjectStoreRequestsAvoided,
    );
    append_vortex_work_avoided_metric_fields(
        fields,
        report,
        VortexWorkAvoidedMetricKind::SpillAvoided,
    );
    append_vortex_work_avoided_metric_fields(
        fields,
        report,
        VortexWorkAvoidedMetricKind::FallbackBlocked,
    );
    append_vortex_work_avoided_metric_fields(
        fields,
        report,
        VortexWorkAvoidedMetricKind::RowsNotScanned,
    );
    append_vortex_work_avoided_metric_fields(
        fields,
        report,
        VortexWorkAvoidedMetricKind::SegmentsPruned,
    );
    append_vortex_work_avoided_metric_fields(
        fields,
        report,
        VortexWorkAvoidedMetricKind::BytesNotRead,
    );
}

fn append_vortex_work_avoided_metric_fields(
    fields: &mut Vec<(String, String)>,
    report: &VortexWorkAvoidedReport,
    kind: VortexWorkAvoidedMetricKind,
) {
    let stem = format!("work_avoided_{}", kind.as_str());
    push_field(fields, &stem, &report.metric_value_summary(kind));
    push_field(
        fields,
        &format!("{stem}_known"),
        &report.metric_known_summary(kind),
    );
    push_field(
        fields,
        &format!("{stem}_reason"),
        &report.metric_reason_summary(kind),
    );
}

pub(crate) fn reconcile_vortex_local_engine_why_with_execution_certificate(
    report: &mut VortexLocalEngineWhyReport,
    certificate: Option<&ExecutionCertificate>,
) {
    if !certificate.is_some_and(ExecutionCertificate::is_certified) {
        return;
    }
    report
        .next_actions
        .retain(|action| action != "attach CG-16 execution certificate evidence");
    if !report
        .supporting_evidence
        .iter()
        .any(|evidence| evidence == "cg16_execution_certificate=certified")
    {
        report
            .supporting_evidence
            .push("cg16_execution_certificate=certified".to_string());
    }
}

pub(crate) fn append_vortex_local_engine_why_fields(
    fields: &mut Vec<(String, String)>,
    report: &VortexLocalEngineWhyReport,
) {
    push_field(fields, "why_report_present", "true");
    push_field(fields, "why_schema_version", report.schema_version);
    push_field(fields, "why_report_id", report.report_id);
    push_field(fields, "why_claim_gate_status", report.claim_gate_status);
    push_field(fields, "why_primary_reason", &report.primary_reason);
    push_count_field(fields, "why_blocker_count", report.blocker_count());
    push_field(fields, "why_blockers", &report.blockers_summary());
    push_count_field(
        fields,
        "why_supporting_evidence_count",
        report.supporting_evidence_count(),
    );
    push_field(
        fields,
        "why_supporting_evidence",
        &report.supporting_evidence_summary(),
    );
    push_count_field(fields, "why_next_action_count", report.next_action_count());
    push_field(fields, "why_next_actions", &report.next_actions_summary());
    push_count_field(
        fields,
        "decision_trace_entries",
        report.decision_trace_entries,
    );
    push_count_field(
        fields,
        "why_work_avoided_metrics",
        report.work_avoided_metrics,
    );
    push_bool_field(fields, "why_fallback_attempted", report.fallback_attempted);
}

pub(crate) fn bounded_local_execution_fields(
    report: &VortexBoundedExecutionReport,
    primitive: &str,
    resources: ExecutionResources,
) -> Vec<(String, String)> {
    let mut fields = vec![];
    crate::execution_resources::append_declaration_fields(&mut fields, resources);
    push_field(&mut fields, "fallback_execution_allowed", "false");
    push_field(&mut fields, "mode", "vortex_bounded_local_exec");
    push_field(
        &mut fields,
        "bounded_execution_status",
        report.status.as_str(),
    );
    push_field(&mut fields, "bounded_execution_mode", report.mode.as_str());
    push_field(&mut fields, "primitive", primitive);
    push_count_field(&mut fields, "max_parallelism", resources.max_parallelism());
    push_field(
        &mut fields,
        "memory_gb",
        &resources
            .whole_gib()
            .map_or_else(|| "unavailable".into(), |value| value.to_string()),
    );
    push_count_field(
        &mut fields,
        "metadata_tasks_completed",
        report.metadata_tasks_completed,
    );
    push_count_field(
        &mut fields,
        "noop_tasks_completed",
        report.noop_tasks_completed,
    );
    push_count_field(
        &mut fields,
        "encoded_read_tasks_deferred",
        report.encoded_read_tasks_deferred,
    );
    push_count_field(&mut fields, "blocked_task_count", report.blocked_task_count);
    push_count_field(
        &mut fields,
        "bounded_decision_count",
        report.decisions.len(),
    );
    push_field(
        &mut fields,
        "local_execution_status",
        report.local_execution_report.status.as_str(),
    );
    push_field(
        &mut fields,
        "local_execution_mode",
        report.local_execution_report.mode.as_str(),
    );
    push_bool_field(&mut fields, "tasks_executed", report.tasks_executed);
    push_bool_field(&mut fields, "data_read", report.data_read);
    push_bool_field(&mut fields, "data_decoded", report.data_decoded);
    push_bool_field(&mut fields, "data_materialized", report.data_materialized);
    push_bool_field(&mut fields, "object_store_io", report.object_store_io);
    push_bool_field(&mut fields, "write_io", report.write_io);
    push_bool_field(&mut fields, "spill_io_performed", report.spill_io_performed);
    push_bool_field(
        &mut fields,
        "external_effects_executed",
        report.external_effects_executed,
    );
    push_field(&mut fields, "execution", "metadata_only_or_not_performed");
    push_bool_field(
        &mut fields,
        "result_known",
        report.local_execution_report.value.is_known(),
    );
    fields
}

pub(crate) fn parse_tiny_predicate(value: &str) -> Result<PredicateExpr, ShardLoomError> {
    let value = value.trim();
    if let Some(inner) = value
        .strip_prefix("and(")
        .and_then(|value| value.strip_suffix(')'))
    {
        let predicates = inner
            .split(';')
            .map(str::trim)
            .filter(|part| !part.is_empty())
            .map(parse_tiny_predicate)
            .collect::<Result<Vec<_>, _>>()?;
        if predicates.is_empty() {
            return Err(ShardLoomError::InvalidOperation(
                "conjunctive predicate requires at least one child predicate".to_string(),
            ));
        }
        return Ok(PredicateExpr::And(predicates));
    }
    let parts = value.splitn(3, ':').collect::<Vec<_>>();
    match parts.as_slice() {
        ["is_null", column] => Ok(PredicateExpr::IsNull {
            column: ColumnRef::new(*column)?,
        }),
        ["is_not_null", column] => Ok(PredicateExpr::IsNotNull {
            column: ColumnRef::new(*column)?,
        }),
        ["contains" | "string_contains", column, needle] => {
            Ok(PredicateExpr::StringContains {
                column: ColumnRef::new(*column)?,
                needle: (*needle).to_string(),
                negated: false,
            })
        }
        ["not_contains" | "not_string_contains", column, needle] => {
            Ok(PredicateExpr::StringContains {
                column: ColumnRef::new(*column)?,
                needle: (*needle).to_string(),
                negated: true,
            })
        }
        ["in" | "not_in", column, literals] => {
            let values = literals
                .split(',')
                .map(str::trim)
                .filter(|value| !value.is_empty())
                .map(parse_tiny_predicate_literal)
                .collect::<Vec<_>>();
            if values.is_empty() {
                return Err(ShardLoomError::InvalidOperation(
                    "IN predicate requires at least one literal".to_string(),
                ));
            }
            Ok(PredicateExpr::InList {
                column: ColumnRef::new(*column)?,
                values,
                negated: parts[0] == "not_in",
            })
        }
        [op, column, literal] => {
            let value = parse_tiny_predicate_literal(literal);
            let op = parse_comparison_op(op).ok_or_else(|| {
                ShardLoomError::InvalidOperation("unsupported predicate operator".to_string())
            })?;
            Ok(PredicateExpr::Compare {
                column: ColumnRef::new(*column)?,
                op,
                value,
            })
        }
        _ => Err(ShardLoomError::InvalidOperation(
            "invalid predicate format; expected is_null:<column>, is_not_null:<column>, contains:<column>:<needle>, in:<column>:<scalar,...>, and(<predicate>;...), or <op>:<column>:<scalar> where <op> is eq, neq, gt, gte, lt, or lte".to_string(),
        )),
    }
}

fn parse_comparison_op(value: &str) -> Option<ComparisonOp> {
    match value {
        "eq" | "=" => Some(ComparisonOp::Eq),
        "neq" | "not_eq" | "!=" | "<>" => Some(ComparisonOp::NotEq),
        "gt" | ">" => Some(ComparisonOp::Gt),
        "gte" | ">=" => Some(ComparisonOp::GtEq),
        "lt" | "<" => Some(ComparisonOp::Lt),
        "lte" | "<=" => Some(ComparisonOp::LtEq),
        _ => None,
    }
}

fn parse_tiny_predicate_literal(value: &str) -> StatValue {
    value
        .parse::<i64>()
        .map_or_else(|_| StatValue::Utf8(value.to_string()), StatValue::Int64)
}

pub(crate) struct VortexCountWhereFilterEvidence {
    pub(crate) predicate_evaluation: VortexEncodedPredicateEvaluationReport,
    pub(crate) filter_kernel: VortexSelectionVectorFilterKernelReport,
    pub(crate) filter_kernel_admission: VortexSelectionVectorFilterKernelAdmissionReport,
}

pub(crate) struct VortexLocalPrimitiveCliExecutionRequest {
    pub(crate) resources: shardloom_core::ExecutionResources,
}

pub(crate) type VortexCountWhereLocalExecutionRequest = VortexLocalPrimitiveCliExecutionRequest;
pub(crate) type VortexCountWhereLocalExecutionEvidence = VortexLocalPrimitiveCliExecutionEvidence;

pub(crate) struct VortexLocalPrimitiveCliExecutionEvidence {
    pub(crate) resources: shardloom_core::ExecutionResources,
    pub(crate) report: VortexLocalPrimitiveExecutionReport,
    pub(crate) native_io_certificate: NativeIoCertificate,
    pub(crate) execution_certificate: Option<ExecutionCertificate>,
}

struct VortexFilterProjectCliOptions {
    local_execution_request: Option<VortexLocalPrimitiveCliExecutionRequest>,
    source_order_limit: Option<usize>,
}
impl VortexLocalPrimitiveCliExecutionEvidence {
    pub(crate) fn runtime_has_errors(&self) -> bool {
        self.report.has_errors()
            || self.report.fallback_execution_allowed
            || self.report.external_effects_executed
            || self.native_io_certificate.fallback_attempted
            || self.native_io_certificate.side_effects.has_errors()
    }

    pub(crate) fn count(&self) -> Option<u64> {
        self.report.rows_selected
    }

    pub(crate) fn selected_rows(&self) -> Option<u64> {
        self.report.rows_selected
    }

    pub(crate) fn projected_rows(&self) -> Option<u64> {
        self.report.rows_projected
    }

    pub(crate) fn selection_vector_guaranteed(&self) -> bool {
        self.native_io_certificate.is_certified()
            && self.native_io_certificate.representation_transition_order()
                == "vortex_encoded->selection_vector_encoded"
            && self.report.filter_pushdown_applied
            && self.report.upstream_filter_expression_used
            && self.report.rows_selected.is_some()
            && !self.report.data_decoded
            && !self.report.data_materialized
            && !self.report.row_read
            && !self.report.arrow_converted
            && !self.report.object_store_io
            && !self.report.write_io
            && !self.report.spill_io_performed
            && !self.report.external_effects_executed
            && !self.report.fallback_execution_allowed
    }

    pub(crate) fn projection_encoded_guaranteed(&self) -> bool {
        self.native_io_certificate.is_certified()
            && self.native_io_certificate.representation_transition_order()
                == "vortex_encoded->vortex_encoded"
            && self.projection_evidence_guaranteed()
            && self.report.rows_projected.is_some()
            && !self.report.data_decoded
            && !self.report.data_materialized
            && !self.report.row_read
            && !self.report.arrow_converted
            && !self.report.object_store_io
            && !self.report.write_io
            && !self.report.spill_io_performed
            && !self.report.external_effects_executed
            && !self.report.fallback_execution_allowed
    }

    pub(crate) fn filter_project_encoded_guaranteed(&self) -> bool {
        self.native_io_certificate.is_certified()
            && self.native_io_certificate.representation_transition_order()
                == "vortex_encoded->selection_vector_encoded"
            && self.report.filter_pushdown_applied
            && self.report.upstream_filter_expression_used
            && self.projection_evidence_guaranteed()
            && self.report.rows_selected.is_some()
            && self.report.rows_projected.is_some()
            && self.report.rows_selected == self.report.rows_projected
            && !self.report.data_decoded
            && !self.report.data_materialized
            && !self.report.row_read
            && !self.report.arrow_converted
            && !self.report.object_store_io
            && !self.report.write_io
            && !self.report.spill_io_performed
            && !self.report.external_effects_executed
            && !self.report.fallback_execution_allowed
    }

    fn projection_evidence_guaranteed(&self) -> bool {
        !self.report.projected_columns.is_empty()
            && ((self.report.projection_pushdown_applied
                && self.report.upstream_projection_expression_used)
                || (self.report.projected_columns.len() == 1
                    && self.report.projected_columns[0] == "value"
                    && !self.report.projection_pushdown_applied
                    && !self.report.upstream_projection_expression_used))
    }
}

#[cfg(test)]
pub(crate) fn parse_vortex_count_where_local_execution_args(
    mut args: impl Iterator<Item = String>,
) -> shardloom_core::Result<Option<VortexCountWhereLocalExecutionRequest>> {
    parse_vortex_local_primitive_cli_execution_args(&mut args)
}

fn primitive_metadata_request(
    uri: DatasetUri,
    execution: Option<&VortexLocalPrimitiveCliExecutionRequest>,
) -> VortexMetadataOpenRequest {
    match execution {
        Some(execution) => VortexMetadataOpenRequest::metadata_only(uri, execution.resources),
        None => VortexMetadataOpenRequest::report_only(uri),
    }
}

#[cfg(test)]
pub(crate) fn parse_vortex_local_primitive_cli_execution_args(
    args: &mut impl Iterator<Item = String>,
) -> shardloom_core::Result<Option<VortexLocalPrimitiveCliExecutionRequest>> {
    parse_vortex_local_primitive_cli_execution_args_in_context(args, &CommandContext::default())
}

fn parse_vortex_local_primitive_cli_execution_args_in_context(
    args: &mut impl Iterator<Item = String>,
    context: &CommandContext<'_>,
) -> shardloom_core::Result<Option<VortexLocalPrimitiveCliExecutionRequest>> {
    let Some(option) = args.next() else {
        return Ok(None);
    };
    if option != "--execute-local-primitive" {
        return Err(ShardLoomError::InvalidOperation(format!(
            "unknown option: {option}"
        )));
    }
    let resources =
        crate::execution_resources::ResourceArguments::parse_complete_in_context(args, context)?;
    Ok(Some(VortexLocalPrimitiveCliExecutionRequest { resources }))
}

pub(crate) fn vortex_count_where_filter_evidence(
    predicate: &PredicateExpr,
    summary: &VortexMetadataSummaryReport,
) -> shardloom_core::Result<VortexCountWhereFilterEvidence> {
    let predicate_evaluation = evaluate_vortex_encoded_predicate_segments(predicate, summary);
    let filter_kernel = evaluate_vortex_selection_vector_filter_kernel(&predicate_evaluation);
    let filter_kernel_admission = admit_vortex_selection_vector_filter_kernel(&filter_kernel)?;
    Ok(VortexCountWhereFilterEvidence {
        predicate_evaluation,
        filter_kernel,
        filter_kernel_admission,
    })
}

pub(crate) fn vortex_count_where_local_execution_evidence(
    request: &VortexQueryPrimitiveRequest,
    local_request: &VortexCountWhereLocalExecutionRequest,
    admission: &CommandAdmission<'_>,
) -> shardloom_core::Result<VortexCountWhereLocalExecutionEvidence> {
    vortex_local_primitive_cli_execution_evidence(request, local_request, admission)
}

pub(crate) fn vortex_local_primitive_cli_execution_evidence(
    request: &VortexQueryPrimitiveRequest,
    local_request: &VortexLocalPrimitiveCliExecutionRequest,
    admission: &CommandAdmission<'_>,
) -> shardloom_core::Result<VortexLocalPrimitiveCliExecutionEvidence> {
    admission.check()?;
    let policy = VortexLocalPrimitiveExecutionPolicy::from_resources(local_request.resources)?;
    #[cfg(all(feature = "vortex-local-primitives", unix))]
    let report = shardloom_vortex::local_primitives::execution::execute_in_session(
        request,
        policy,
        admission.native_session()?,
        &admission.cancellation(),
    )?;
    #[cfg(not(all(feature = "vortex-local-primitives", unix)))]
    let report = execute_vortex_local_primitive_with_policy(request, policy)?;
    let native_io_certificate = local_primitive_native_io_certificate(request, &report)?;
    let execution_certificate = local_primitive_correctness_fixture_for_request(request, &report)
        .map(|fixture| local_primitive_execution_certificate(&fixture, request, &report))
        .transpose()?;
    Ok(VortexLocalPrimitiveCliExecutionEvidence {
        resources: local_request.resources,
        report,
        native_io_certificate,
        execution_certificate,
    })
}

#[cfg(all(test, feature = "vortex-local-primitives"))]
pub(crate) fn fixture_primitive_execution_evidence(
    request: &VortexQueryPrimitiveRequest,
    local_request: &VortexLocalPrimitiveCliExecutionRequest,
) -> shardloom_core::Result<VortexLocalPrimitiveCliExecutionEvidence> {
    let context = CommandContext::default();
    #[cfg(all(feature = "vortex-local-primitives", unix))]
    let mut cache = crate::public_workflow_route::PublicExecutionSession::default();
    #[cfg(all(feature = "vortex-local-primitives", unix))]
    let owner = cache.command_owner(None)?;
    #[cfg(all(feature = "vortex-local-primitives", unix))]
    let cancellation = shardloom_exec::compute_pool::CancellationToken::default();
    #[cfg(all(feature = "vortex-local-primitives", unix))]
    let context = context.with_default_owner(&owner, &cancellation);
    let admission = context.admit(local_request.resources)?;
    vortex_local_primitive_cli_execution_evidence(request, local_request, &admission)
}

fn admit_primitive_if_needed<'a>(
    existing: Option<&CommandAdmission<'_>>,
    request: Option<&VortexLocalPrimitiveCliExecutionRequest>,
    context: &CommandContext<'a>,
    command: &'static str,
    format: OutputFormat,
) -> std::result::Result<Option<CommandAdmission<'a>>, ExitCode> {
    if let Some(admission) = existing {
        admission
            .check()
            .map_err(|error| emit_error(command, format, "primitive cancelled", &error))?;
        return Ok(None);
    }
    request
        .map(|request| context.admit_for_command(request.resources, command, format))
        .transpose()
}

pub(crate) fn vortex_count_where_human_text(
    result: &VortexQueryPrimitiveResult,
    evidence: &VortexCountWhereFilterEvidence,
    local_execution: Option<&VortexCountWhereLocalExecutionEvidence>,
) -> String {
    let mut sections = vec![
        result.to_human_text(),
        evidence.predicate_evaluation.to_human_text(),
        evidence.filter_kernel.to_human_text(),
        evidence.filter_kernel_admission.to_human_text(),
    ];
    if let Some(local) = local_execution {
        sections.push(local.report.to_human_text());
        sections.push(local_primitive_native_io_certificate_human_text(
            &local.native_io_certificate,
        ));
        if let Some(certificate) = &local.execution_certificate {
            sections.push(certificate.to_human_text());
        }
    }
    sections.join("\n\n")
}

pub(crate) fn vortex_count_where_fields(
    result: &VortexQueryPrimitiveResult,
    count: Option<u64>,
    predicate_arg: String,
    evidence: &VortexCountWhereFilterEvidence,
    local_execution: Option<&VortexCountWhereLocalExecutionEvidence>,
) -> Vec<(String, String)> {
    let data_read = local_execution.map_or(result.data_read, |local| local.report.data_read);
    let data_decoded =
        local_execution.map_or(result.data_decoded, |local| local.report.data_decoded);
    let data_materialized = local_execution.map_or(result.data_materialized, |local| {
        local.report.data_materialized
    });
    let object_store_io =
        local_execution.map_or(result.object_store_io, |local| local.report.object_store_io);
    let write_io = local_execution.map_or(result.write_io, |local| local.report.write_io);
    let spill_io_performed = local_execution.map_or(result.spill_io_performed, |local| {
        local.report.spill_io_performed
    });
    let execution = local_execution.map_or(
        "metadata_or_selection_vector_evidence_only".to_string(),
        |local| {
            if local.report.data_read {
                "local_vortex_count_where_primitive_performed".to_string()
            } else {
                "local_vortex_count_where_primitive_not_performed".to_string()
            }
        },
    );
    let mut fields = vec![
        (
            "fallback_execution_allowed".to_string(),
            "false".to_string(),
        ),
        ("mode".to_string(), "vortex_count_where".to_string()),
        ("primitive".to_string(), "count_where".to_string()),
        ("data_read".to_string(), data_read.to_string()),
        ("data_decoded".to_string(), data_decoded.to_string()),
        (
            "data_materialized".to_string(),
            data_materialized.to_string(),
        ),
        ("object_store_io".to_string(), object_store_io.to_string()),
        ("write_io".to_string(), write_io.to_string()),
        (
            "spill_io_performed".to_string(),
            spill_io_performed.to_string(),
        ),
        ("execution".to_string(), execution),
        (
            "query_primitive_status".to_string(),
            result.status.as_str().to_string(),
        ),
        (
            "metadata_query_primitive_status".to_string(),
            result.status.as_str().to_string(),
        ),
        ("result_known".to_string(), count.is_some().to_string()),
        (
            "count".to_string(),
            count.map_or_else(|| "unknown".to_string(), |v| v.to_string()),
        ),
        ("predicate".to_string(), predicate_arg),
    ];
    append_vortex_count_where_filter_evidence_fields(&mut fields, evidence);
    append_vortex_count_where_local_execution_fields(&mut fields, local_execution);
    fields
}

fn append_vortex_count_where_filter_evidence_fields(
    fields: &mut Vec<(String, String)>,
    evidence: &VortexCountWhereFilterEvidence,
) {
    append_vortex_count_where_predicate_evidence_fields(fields, &evidence.predicate_evaluation);
    append_vortex_count_where_filter_kernel_fields(fields, &evidence.filter_kernel);
    append_vortex_count_where_filter_admission_fields(fields, &evidence.filter_kernel_admission);
    push_bool_field(
        fields,
        "filtered_count_selection_vector_evidence_present",
        evidence
            .filter_kernel
            .is_safe_native_filter_kernel_evidence(),
    );
    push_bool_field(
        fields,
        "filtered_count_generalized_execution_allowed",
        false,
    );
    push_bool_field(fields, "filtered_count_production_claim_allowed", false);
    push_bool_field(
        fields,
        "filtered_count_requires_encoded_value_kernel",
        evidence.predicate_evaluation.status
            == VortexEncodedPredicateEvaluationStatus::NeedsEncodedValues,
    );
    push_bool_field(fields, "filtered_count_requires_benchmark_evidence", true);
    push_bool_field(fields, "filtered_count_cg2_closeout_allowed", false);
    push_bool_field(fields, "filtered_count_cg13_closeout_allowed", false);
}

pub(crate) fn append_vortex_count_where_local_execution_fields(
    fields: &mut Vec<(String, String)>,
    local_execution: Option<&VortexCountWhereLocalExecutionEvidence>,
) {
    append_vortex_count_where_local_execution_request_fields(fields, local_execution);
    match local_execution {
        Some(local) => append_vortex_count_where_local_execution_present_fields(fields, local),
        None => append_vortex_count_where_local_execution_absent_fields(fields),
    }
}

fn append_vortex_count_where_local_execution_request_fields(
    fields: &mut Vec<(String, String)>,
    local_execution: Option<&VortexCountWhereLocalExecutionEvidence>,
) {
    push_bool_field(
        fields,
        "filtered_count_local_execution_requested",
        local_execution.is_some(),
    );
    push_field(
        fields,
        "filtered_count_local_execution_feature_gate",
        "vortex-local-primitives",
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_feature_enabled",
        cfg!(feature = "vortex-local-primitives"),
    );
}

fn append_vortex_count_where_local_execution_absent_fields(fields: &mut Vec<(String, String)>) {
    push_field(
        fields,
        "filtered_count_local_execution_status",
        "not_requested",
    );
    push_field(
        fields,
        "filtered_count_local_execution_mode",
        "not_requested",
    );
    push_u64_field(fields, "filtered_count_local_execution_memory_gb", 0);
    push_count_field(fields, "filtered_count_local_execution_max_parallelism", 0);
    push_bool_field(fields, "filtered_count_local_execution_result_known", false);
    push_field(fields, "filtered_count_local_execution_count", "unknown");
    append_vortex_count_where_local_execution_absent_effect_fields(fields);
    append_vortex_local_primitive_execution_report_fields(fields, None);
    append_vortex_count_where_local_execution_claim_fields(fields, false, false, false);
    append_vortex_local_primitive_native_io_certificate_fields(fields, None);
    append_vortex_local_primitive_execution_certificate_fields(fields, None);
}

fn append_vortex_count_where_local_execution_present_fields(
    fields: &mut Vec<(String, String)>,
    local: &VortexCountWhereLocalExecutionEvidence,
) {
    append_vortex_count_where_local_execution_report_fields(fields, local);
    append_vortex_count_where_local_execution_effect_fields(fields, local);
    append_vortex_local_primitive_execution_report_fields(fields, Some(&local.report));
    append_vortex_count_where_local_execution_claim_fields(
        fields,
        local.selection_vector_guaranteed(),
        local.native_io_certificate.is_certified(),
        local
            .execution_certificate
            .as_ref()
            .is_some_and(ExecutionCertificate::is_certified),
    );
    append_vortex_local_primitive_native_io_certificate_fields(
        fields,
        Some(&local.native_io_certificate),
    );
    append_vortex_local_primitive_execution_certificate_fields(
        fields,
        local.execution_certificate.as_ref(),
    );
}

fn append_vortex_count_where_local_execution_report_fields(
    fields: &mut Vec<(String, String)>,
    local: &VortexCountWhereLocalExecutionEvidence,
) {
    push_field(
        fields,
        "filtered_count_local_execution_status",
        local.report.status.as_str(),
    );
    push_field(
        fields,
        "filtered_count_local_execution_mode",
        local.report.mode.as_str(),
    );
    push_field(
        fields,
        "filtered_count_local_execution_memory_gb",
        &local
            .resources
            .whole_gib()
            .map_or_else(|| "unavailable".into(), |value| value.to_string()),
    );
    push_count_field(
        fields,
        "filtered_count_local_execution_max_parallelism",
        local.resources.max_parallelism(),
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_result_known",
        local.count().is_some(),
    );
    push_field(
        fields,
        "filtered_count_local_execution_count",
        &local
            .count()
            .map_or_else(|| "unknown".to_string(), |value| value.to_string()),
    );
    push_u64_field(
        fields,
        "filtered_count_local_execution_rows_scanned",
        local.report.rows_scanned,
    );
    push_field(
        fields,
        "filtered_count_local_execution_rows_selected",
        &local
            .report
            .rows_selected
            .map_or_else(|| "unknown".to_string(), |value| value.to_string()),
    );
    push_count_field(
        fields,
        "filtered_count_local_execution_arrays_read_count",
        local.report.arrays_read_count,
    );
    push_count_field(
        fields,
        "filtered_count_local_execution_max_chunk_rows",
        local.report.max_chunk_rows,
    );
    push_count_field(
        fields,
        "filtered_count_local_execution_scan_concurrency_per_worker",
        local.report.scan_concurrency_per_worker,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_streaming_scan_used",
        local.report.streaming_scan_used,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_full_stream_collected",
        local.report.full_stream_collected,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_filter_pushdown_applied",
        local.report.filter_pushdown_applied,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_upstream_filter_expression_used",
        local.report.upstream_filter_expression_used,
    );
}

fn append_vortex_count_where_local_execution_absent_effect_fields(
    fields: &mut Vec<(String, String)>,
) {
    push_bool_field(fields, "filtered_count_local_execution_data_read", false);
    push_bool_field(fields, "filtered_count_local_execution_data_decoded", false);
    push_bool_field(
        fields,
        "filtered_count_local_execution_data_materialized",
        false,
    );
    push_bool_field(fields, "filtered_count_local_execution_row_read", false);
    push_bool_field(
        fields,
        "filtered_count_local_execution_arrow_converted",
        false,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_object_store_io",
        false,
    );
    push_bool_field(fields, "filtered_count_local_execution_write_io", false);
    push_bool_field(
        fields,
        "filtered_count_local_execution_spill_io_performed",
        false,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_fallback_attempted",
        false,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_fallback_execution_allowed",
        false,
    );
}

fn append_vortex_count_where_local_execution_effect_fields(
    fields: &mut Vec<(String, String)>,
    local: &VortexCountWhereLocalExecutionEvidence,
) {
    push_bool_field(
        fields,
        "filtered_count_local_execution_data_read",
        local.report.data_read,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_data_decoded",
        local.report.data_decoded,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_data_materialized",
        local.report.data_materialized,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_row_read",
        local.report.row_read,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_arrow_converted",
        local.report.arrow_converted,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_object_store_io",
        local.report.object_store_io,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_write_io",
        local.report.write_io,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_spill_io_performed",
        local.report.spill_io_performed,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_external_effects_executed",
        local.report.external_effects_executed,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_fallback_attempted",
        local.native_io_certificate.side_effects.fallback_attempted
            || local.native_io_certificate.fallback_attempted
            || local
                .execution_certificate
                .as_ref()
                .is_some_and(|certificate| certificate.fallback_attempted),
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_fallback_execution_allowed",
        local.report.fallback_execution_allowed,
    );
}

fn append_vortex_count_where_local_execution_claim_fields(
    fields: &mut Vec<(String, String)>,
    selection_vector_guarantee: bool,
    native_io_certified: bool,
    correctness_certified: bool,
) {
    push_bool_field(
        fields,
        "filtered_count_local_execution_selection_vector_guarantee",
        selection_vector_guarantee,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_native_io_certified",
        native_io_certified,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_correctness_certified",
        correctness_certified,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_production_claim_allowed",
        false,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_generalized_claim_allowed",
        false,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_cg2_closeout_allowed",
        false,
    );
    push_bool_field(
        fields,
        "filtered_count_local_execution_cg13_closeout_allowed",
        false,
    );
}

pub(crate) fn vortex_project_human_text(
    result: &VortexQueryPrimitiveResult,
    local_execution: Option<&VortexLocalPrimitiveCliExecutionEvidence>,
) -> String {
    let mut sections = vec![result.to_human_text()];
    if let Some(local) = local_execution {
        sections.push(local.report.to_human_text());
        sections.push(local_primitive_native_io_certificate_human_text(
            &local.native_io_certificate,
        ));
        if let Some(certificate) = &local.execution_certificate {
            sections.push(certificate.to_human_text());
        }
    }
    sections.join("\n\n")
}

pub(crate) fn vortex_project_fields(
    result: &VortexQueryPrimitiveResult,
    columns_arg: String,
    local_execution: Option<&VortexLocalPrimitiveCliExecutionEvidence>,
) -> Vec<(String, String)> {
    let data_read = local_execution.map_or(result.data_read, |local| local.report.data_read);
    let data_decoded =
        local_execution.map_or(result.data_decoded, |local| local.report.data_decoded);
    let data_materialized = local_execution.map_or(result.data_materialized, |local| {
        local.report.data_materialized
    });
    let row_read = local_execution.is_some_and(|local| local.report.row_read);
    let arrow_converted = local_execution.is_some_and(|local| local.report.arrow_converted);
    let object_store_io =
        local_execution.map_or(result.object_store_io, |local| local.report.object_store_io);
    let write_io = local_execution.map_or(result.write_io, |local| local.report.write_io);
    let spill_io_performed = local_execution.map_or(result.spill_io_performed, |local| {
        local.report.spill_io_performed
    });
    let result_known = local_execution
        .and_then(VortexLocalPrimitiveCliExecutionEvidence::projected_rows)
        .is_some()
        || result.value.is_known();
    let execution = local_execution.map_or(
        "metadata_or_projection_evidence_only".to_string(),
        |local| {
            if local.report.data_read {
                "local_vortex_project_primitive_performed".to_string()
            } else {
                "local_vortex_project_primitive_not_performed".to_string()
            }
        },
    );
    let output_columns = split_column_arg(&columns_arg);
    let mut fields = vec![
        (
            "fallback_execution_allowed".to_string(),
            "false".to_string(),
        ),
        ("mode".to_string(), "vortex_project".to_string()),
        ("primitive".to_string(), "project_columns".to_string()),
        ("data_read".to_string(), data_read.to_string()),
        ("data_decoded".to_string(), data_decoded.to_string()),
        (
            "data_materialized".to_string(),
            data_materialized.to_string(),
        ),
        ("row_read".to_string(), row_read.to_string()),
        ("arrow_converted".to_string(), arrow_converted.to_string()),
        ("object_store_io".to_string(), object_store_io.to_string()),
        ("write_io".to_string(), write_io.to_string()),
        (
            "spill_io_performed".to_string(),
            spill_io_performed.to_string(),
        ),
        ("execution".to_string(), execution),
        (
            "query_primitive_status".to_string(),
            result.status.as_str().to_string(),
        ),
        ("result_known".to_string(), result_known.to_string()),
        (
            "rows_projected".to_string(),
            local_execution
                .and_then(VortexLocalPrimitiveCliExecutionEvidence::projected_rows)
                .map_or_else(|| "unknown".to_string(), |value| value.to_string()),
        ),
        ("columns".to_string(), columns_arg),
    ];
    append_vortex_project_local_execution_fields(&mut fields, local_execution);
    append_vortex_primitive_scan_pushdown_fields(
        &mut fields,
        "vortex_project",
        &[],
        &output_columns,
        None,
        local_execution,
    );
    fields
}

pub(crate) fn append_vortex_project_local_execution_fields(
    fields: &mut Vec<(String, String)>,
    local_execution: Option<&VortexLocalPrimitiveCliExecutionEvidence>,
) {
    push_bool_field(
        fields,
        "project_local_execution_requested",
        local_execution.is_some(),
    );
    push_field(
        fields,
        "project_local_execution_feature_gate",
        "vortex-local-primitives",
    );
    push_bool_field(
        fields,
        "project_local_execution_feature_enabled",
        cfg!(feature = "vortex-local-primitives"),
    );
    match local_execution {
        Some(local) => append_vortex_project_local_execution_present_fields(fields, local),
        None => append_vortex_project_local_execution_absent_fields(fields),
    }
}

fn append_vortex_project_local_execution_absent_fields(fields: &mut Vec<(String, String)>) {
    push_field(fields, "project_local_execution_status", "not_requested");
    push_field(fields, "project_local_execution_mode", "not_requested");
    push_u64_field(fields, "project_local_execution_memory_gb", 0);
    push_count_field(fields, "project_local_execution_max_parallelism", 0);
    push_bool_field(fields, "project_local_execution_result_known", false);
    push_field(fields, "project_local_execution_rows_projected", "unknown");
    push_field(fields, "project_local_execution_projected_columns", "");
    push_field(
        fields,
        "project_local_execution_source_order_limit_requested",
        "none",
    );
    push_bool_field(
        fields,
        "project_local_execution_source_order_limit_applied",
        false,
    );
    push_field(
        fields,
        "project_local_execution_source_order_limit_input_rows",
        "unknown",
    );
    push_field(
        fields,
        "project_local_execution_source_order_limit_rows_output",
        "unknown",
    );
    append_vortex_project_local_execution_absent_effect_fields(fields);
    append_vortex_project_local_execution_claim_fields(fields, false, false, false);
    append_vortex_local_primitive_native_io_certificate_fields(fields, None);
    append_vortex_local_primitive_execution_certificate_fields(fields, None);
}

fn append_vortex_project_local_execution_present_fields(
    fields: &mut Vec<(String, String)>,
    local: &VortexLocalPrimitiveCliExecutionEvidence,
) {
    push_field(
        fields,
        "project_local_execution_status",
        local.report.status.as_str(),
    );
    push_field(
        fields,
        "project_local_execution_mode",
        local.report.mode.as_str(),
    );
    push_field(
        fields,
        "project_local_execution_memory_gb",
        &local
            .resources
            .whole_gib()
            .map_or_else(|| "unavailable".into(), |value| value.to_string()),
    );
    push_count_field(
        fields,
        "project_local_execution_max_parallelism",
        local.resources.max_parallelism(),
    );
    push_bool_field(
        fields,
        "project_local_execution_result_known",
        local.projected_rows().is_some(),
    );
    push_field(
        fields,
        "project_local_execution_rows_projected",
        &local
            .projected_rows()
            .map_or_else(|| "unknown".to_string(), |value| value.to_string()),
    );
    push_field(
        fields,
        "project_local_execution_projected_columns",
        &local.report.projected_columns.join(","),
    );
    append_vortex_project_source_order_limit_fields(fields, &local.report);
    push_u64_field(
        fields,
        "project_local_execution_rows_scanned",
        local.report.rows_scanned,
    );
    push_count_field(
        fields,
        "project_local_execution_arrays_read_count",
        local.report.arrays_read_count,
    );
    push_count_field(
        fields,
        "project_local_execution_max_chunk_rows",
        local.report.max_chunk_rows,
    );
    push_count_field(
        fields,
        "project_local_execution_scan_concurrency_per_worker",
        local.report.scan_concurrency_per_worker,
    );
    push_bool_field(
        fields,
        "project_local_execution_streaming_scan_used",
        local.report.streaming_scan_used,
    );
    push_bool_field(
        fields,
        "project_local_execution_full_stream_collected",
        local.report.full_stream_collected,
    );
    push_bool_field(
        fields,
        "project_local_execution_projection_pushdown_applied",
        local.report.projection_pushdown_applied,
    );
    push_bool_field(
        fields,
        "project_local_execution_upstream_projection_expression_used",
        local.report.upstream_projection_expression_used,
    );
    append_vortex_project_local_execution_effect_fields(fields, local);
    append_vortex_project_local_execution_claim_fields(
        fields,
        local.projection_encoded_guaranteed(),
        local.native_io_certificate.is_certified(),
        local
            .execution_certificate
            .as_ref()
            .is_some_and(ExecutionCertificate::is_certified),
    );
    append_vortex_local_primitive_native_io_certificate_fields(
        fields,
        Some(&local.native_io_certificate),
    );
    append_vortex_local_primitive_execution_certificate_fields(
        fields,
        local.execution_certificate.as_ref(),
    );
}

fn append_vortex_project_source_order_limit_fields(
    fields: &mut Vec<(String, String)>,
    report: &VortexLocalPrimitiveExecutionReport,
) {
    push_field(
        fields,
        "project_local_execution_source_order_limit_requested",
        &report
            .source_order_limit_requested
            .map_or_else(|| "none".to_string(), |value| value.to_string()),
    );
    push_bool_field(
        fields,
        "project_local_execution_source_order_limit_applied",
        report.source_order_limit_applied,
    );
    push_field(
        fields,
        "project_local_execution_source_order_limit_input_rows",
        &report
            .source_order_limit_input_rows
            .map_or_else(|| "unknown".to_string(), |value| value.to_string()),
    );
    push_field(
        fields,
        "project_local_execution_source_order_limit_rows_output",
        &report
            .source_order_limit_rows_output
            .map_or_else(|| "unknown".to_string(), |value| value.to_string()),
    );
}

fn append_vortex_project_local_execution_absent_effect_fields(fields: &mut Vec<(String, String)>) {
    push_bool_field(fields, "project_local_execution_data_read", false);
    push_bool_field(fields, "project_local_execution_data_decoded", false);
    push_bool_field(fields, "project_local_execution_data_materialized", false);
    push_bool_field(fields, "project_local_execution_row_read", false);
    push_bool_field(fields, "project_local_execution_arrow_converted", false);
    push_bool_field(fields, "project_local_execution_object_store_io", false);
    push_bool_field(fields, "project_local_execution_write_io", false);
    push_bool_field(fields, "project_local_execution_spill_io_performed", false);
    push_bool_field(fields, "project_local_execution_fallback_attempted", false);
    push_bool_field(
        fields,
        "project_local_execution_fallback_execution_allowed",
        false,
    );
}

fn append_vortex_project_local_execution_effect_fields(
    fields: &mut Vec<(String, String)>,
    local: &VortexLocalPrimitiveCliExecutionEvidence,
) {
    push_bool_field(
        fields,
        "project_local_execution_data_read",
        local.report.data_read,
    );
    push_bool_field(
        fields,
        "project_local_execution_data_decoded",
        local.report.data_decoded,
    );
    push_bool_field(
        fields,
        "project_local_execution_data_materialized",
        local.report.data_materialized,
    );
    push_bool_field(
        fields,
        "project_local_execution_row_read",
        local.report.row_read,
    );
    push_bool_field(
        fields,
        "project_local_execution_arrow_converted",
        local.report.arrow_converted,
    );
    push_bool_field(
        fields,
        "project_local_execution_object_store_io",
        local.report.object_store_io,
    );
    push_bool_field(
        fields,
        "project_local_execution_write_io",
        local.report.write_io,
    );
    push_bool_field(
        fields,
        "project_local_execution_spill_io_performed",
        local.report.spill_io_performed,
    );
    push_bool_field(
        fields,
        "project_local_execution_external_effects_executed",
        local.report.external_effects_executed,
    );
    push_bool_field(
        fields,
        "project_local_execution_fallback_attempted",
        local.native_io_certificate.side_effects.fallback_attempted
            || local.native_io_certificate.fallback_attempted
            || local
                .execution_certificate
                .as_ref()
                .is_some_and(|certificate| certificate.fallback_attempted),
    );
    push_bool_field(
        fields,
        "project_local_execution_fallback_execution_allowed",
        local.report.fallback_execution_allowed,
    );
}

fn append_vortex_project_local_execution_claim_fields(
    fields: &mut Vec<(String, String)>,
    encoded_projection_guarantee: bool,
    native_io_certified: bool,
    correctness_certified: bool,
) {
    push_bool_field(
        fields,
        "project_local_execution_encoded_projection_guarantee",
        encoded_projection_guarantee,
    );
    push_bool_field(
        fields,
        "project_local_execution_native_io_certified",
        native_io_certified,
    );
    push_bool_field(
        fields,
        "project_local_execution_correctness_certified",
        correctness_certified,
    );
    push_bool_field(
        fields,
        "project_local_execution_production_claim_allowed",
        false,
    );
    push_bool_field(
        fields,
        "project_local_execution_generalized_claim_allowed",
        false,
    );
    push_bool_field(
        fields,
        "project_local_execution_cg2_closeout_allowed",
        false,
    );
    push_bool_field(
        fields,
        "project_local_execution_cg13_closeout_allowed",
        false,
    );
}

pub(crate) fn vortex_filter_project_human_text(
    result: &VortexQueryPrimitiveResult,
    local_execution: Option<&VortexLocalPrimitiveCliExecutionEvidence>,
) -> String {
    let mut sections = vec![result.to_human_text()];
    if let Some(local) = local_execution {
        sections.push(local.report.to_human_text());
        sections.push(local_primitive_native_io_certificate_human_text(
            &local.native_io_certificate,
        ));
        if let Some(certificate) = &local.execution_certificate {
            sections.push(certificate.to_human_text());
        }
    }
    sections.join("\n\n")
}

pub(crate) fn vortex_filter_project_fields(
    result: &VortexQueryPrimitiveResult,
    predicate_arg: String,
    columns_arg: String,
    local_execution: Option<&VortexLocalPrimitiveCliExecutionEvidence>,
) -> Vec<(String, String)> {
    let data_read = local_execution.map_or(result.data_read, |local| local.report.data_read);
    let data_decoded =
        local_execution.map_or(result.data_decoded, |local| local.report.data_decoded);
    let data_materialized = local_execution.map_or(result.data_materialized, |local| {
        local.report.data_materialized
    });
    let row_read = local_execution.is_some_and(|local| local.report.row_read);
    let arrow_converted = local_execution.is_some_and(|local| local.report.arrow_converted);
    let object_store_io =
        local_execution.map_or(result.object_store_io, |local| local.report.object_store_io);
    let write_io = local_execution.map_or(result.write_io, |local| local.report.write_io);
    let spill_io_performed = local_execution.map_or(result.spill_io_performed, |local| {
        local.report.spill_io_performed
    });
    let result_known = local_execution
        .and_then(VortexLocalPrimitiveCliExecutionEvidence::projected_rows)
        .is_some()
        || result.value.is_known();
    let execution = local_execution.map_or(
        "metadata_filter_project_evidence_only".to_string(),
        |local| {
            if local.report.data_read {
                "local_vortex_filter_project_primitive_performed".to_string()
            } else {
                "local_vortex_filter_project_primitive_not_performed".to_string()
            }
        },
    );
    let filter_columns = predicate_columns_from_arg(&predicate_arg);
    let output_columns = split_column_arg(&columns_arg);
    let mut fields = vec![
        (
            "fallback_execution_allowed".to_string(),
            "false".to_string(),
        ),
        ("mode".to_string(), "vortex_filter_project".to_string()),
        ("primitive".to_string(), "filter_and_project".to_string()),
        ("data_read".to_string(), data_read.to_string()),
        ("data_decoded".to_string(), data_decoded.to_string()),
        (
            "data_materialized".to_string(),
            data_materialized.to_string(),
        ),
        ("row_read".to_string(), row_read.to_string()),
        ("arrow_converted".to_string(), arrow_converted.to_string()),
        ("object_store_io".to_string(), object_store_io.to_string()),
        ("write_io".to_string(), write_io.to_string()),
        (
            "spill_io_performed".to_string(),
            spill_io_performed.to_string(),
        ),
        ("execution".to_string(), execution),
        (
            "query_primitive_status".to_string(),
            result.status.as_str().to_string(),
        ),
        ("result_known".to_string(), result_known.to_string()),
        (
            "rows_selected".to_string(),
            local_execution
                .and_then(VortexLocalPrimitiveCliExecutionEvidence::selected_rows)
                .map_or_else(|| "unknown".to_string(), |value| value.to_string()),
        ),
        (
            "rows_projected".to_string(),
            local_execution
                .and_then(VortexLocalPrimitiveCliExecutionEvidence::projected_rows)
                .map_or_else(|| "unknown".to_string(), |value| value.to_string()),
        ),
        ("predicate".to_string(), predicate_arg),
        ("columns".to_string(), columns_arg),
        (
            "source_order_limit".to_string(),
            result
                .request
                .source_order_limit
                .map_or_else(|| "none".to_string(), |limit| limit.to_string()),
        ),
    ];
    append_vortex_filter_project_local_execution_fields(&mut fields, local_execution);
    append_vortex_primitive_scan_pushdown_fields(
        &mut fields,
        "vortex_filter_project",
        &filter_columns,
        &output_columns,
        result.request.source_order_limit,
        local_execution,
    );
    fields
}

pub(crate) fn append_vortex_filter_project_local_execution_fields(
    fields: &mut Vec<(String, String)>,
    local_execution: Option<&VortexLocalPrimitiveCliExecutionEvidence>,
) {
    push_bool_field(
        fields,
        "filter_project_local_execution_requested",
        local_execution.is_some(),
    );
    push_field(
        fields,
        "filter_project_local_execution_feature_gate",
        "vortex-local-primitives",
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_feature_enabled",
        cfg!(feature = "vortex-local-primitives"),
    );
    match local_execution {
        Some(local) => append_vortex_filter_project_local_execution_present_fields(fields, local),
        None => append_vortex_filter_project_local_execution_absent_fields(fields),
    }
}

fn append_vortex_filter_project_local_execution_absent_fields(fields: &mut Vec<(String, String)>) {
    push_field(
        fields,
        "filter_project_local_execution_status",
        "not_requested",
    );
    push_field(
        fields,
        "filter_project_local_execution_mode",
        "not_requested",
    );
    push_u64_field(fields, "filter_project_local_execution_memory_gb", 0);
    push_count_field(fields, "filter_project_local_execution_max_parallelism", 0);
    push_bool_field(fields, "filter_project_local_execution_result_known", false);
    push_field(
        fields,
        "filter_project_local_execution_rows_selected",
        "unknown",
    );
    push_field(
        fields,
        "filter_project_local_execution_rows_projected",
        "unknown",
    );
    push_field(
        fields,
        "filter_project_local_execution_projected_columns",
        "",
    );
    push_field(
        fields,
        "filter_project_local_execution_source_order_limit_requested",
        "none",
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_source_order_limit_applied",
        false,
    );
    push_field(
        fields,
        "filter_project_local_execution_source_order_limit_input_rows",
        "unknown",
    );
    push_field(
        fields,
        "filter_project_local_execution_source_order_limit_rows_output",
        "unknown",
    );
    append_vortex_filter_project_local_execution_absent_effect_fields(fields);
    append_vortex_filter_project_local_execution_claim_fields(fields, None);
    append_vortex_local_primitive_native_io_certificate_fields(fields, None);
    append_vortex_local_primitive_execution_certificate_fields(fields, None);
}

fn append_vortex_filter_project_local_execution_present_fields(
    fields: &mut Vec<(String, String)>,
    local: &VortexLocalPrimitiveCliExecutionEvidence,
) {
    push_field(
        fields,
        "filter_project_local_execution_status",
        local.report.status.as_str(),
    );
    push_field(
        fields,
        "filter_project_local_execution_mode",
        local.report.mode.as_str(),
    );
    push_field(
        fields,
        "filter_project_local_execution_memory_gb",
        &local
            .resources
            .whole_gib()
            .map_or_else(|| "unavailable".into(), |value| value.to_string()),
    );
    push_count_field(
        fields,
        "filter_project_local_execution_max_parallelism",
        local.resources.max_parallelism(),
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_result_known",
        local.projected_rows().is_some(),
    );
    push_field(
        fields,
        "filter_project_local_execution_rows_selected",
        &local
            .selected_rows()
            .map_or_else(|| "unknown".to_string(), |value| value.to_string()),
    );
    push_field(
        fields,
        "filter_project_local_execution_rows_projected",
        &local
            .projected_rows()
            .map_or_else(|| "unknown".to_string(), |value| value.to_string()),
    );
    push_field(
        fields,
        "filter_project_local_execution_projected_columns",
        &local.report.projected_columns.join(","),
    );
    append_vortex_filter_project_local_execution_limit_fields(fields, local);
    append_vortex_filter_project_local_execution_scan_fields(fields, local);
    append_vortex_filter_project_local_execution_effect_fields(fields, local);
    append_vortex_filter_project_local_execution_claim_fields(fields, Some(local));
    append_vortex_local_primitive_native_io_certificate_fields(
        fields,
        Some(&local.native_io_certificate),
    );
    append_vortex_local_primitive_execution_certificate_fields(
        fields,
        local.execution_certificate.as_ref(),
    );
}

fn append_vortex_filter_project_local_execution_limit_fields(
    fields: &mut Vec<(String, String)>,
    local: &VortexLocalPrimitiveCliExecutionEvidence,
) {
    push_field(
        fields,
        "filter_project_local_execution_source_order_limit_requested",
        &local
            .report
            .source_order_limit_requested
            .map_or_else(|| "none".to_string(), |value| value.to_string()),
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_source_order_limit_applied",
        local.report.source_order_limit_applied,
    );
    push_field(
        fields,
        "filter_project_local_execution_source_order_limit_input_rows",
        &local
            .report
            .source_order_limit_input_rows
            .map_or_else(|| "unknown".to_string(), |value| value.to_string()),
    );
    push_field(
        fields,
        "filter_project_local_execution_source_order_limit_rows_output",
        &local
            .report
            .source_order_limit_rows_output
            .map_or_else(|| "unknown".to_string(), |value| value.to_string()),
    );
}

fn append_vortex_filter_project_local_execution_scan_fields(
    fields: &mut Vec<(String, String)>,
    local: &VortexLocalPrimitiveCliExecutionEvidence,
) {
    push_u64_field(
        fields,
        "filter_project_local_execution_rows_scanned",
        local.report.rows_scanned,
    );
    push_count_field(
        fields,
        "filter_project_local_execution_arrays_read_count",
        local.report.arrays_read_count,
    );
    push_count_field(
        fields,
        "filter_project_local_execution_max_chunk_rows",
        local.report.max_chunk_rows,
    );
    push_count_field(
        fields,
        "filter_project_local_execution_scan_concurrency_per_worker",
        local.report.scan_concurrency_per_worker,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_streaming_scan_used",
        local.report.streaming_scan_used,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_full_stream_collected",
        local.report.full_stream_collected,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_filter_pushdown_applied",
        local.report.filter_pushdown_applied,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_projection_pushdown_applied",
        local.report.projection_pushdown_applied,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_upstream_filter_expression_used",
        local.report.upstream_filter_expression_used,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_upstream_projection_expression_used",
        local.report.upstream_projection_expression_used,
    );
}

fn append_vortex_filter_project_local_execution_absent_effect_fields(
    fields: &mut Vec<(String, String)>,
) {
    push_bool_field(fields, "filter_project_local_execution_data_read", false);
    push_bool_field(fields, "filter_project_local_execution_data_decoded", false);
    push_bool_field(
        fields,
        "filter_project_local_execution_data_materialized",
        false,
    );
    push_bool_field(fields, "filter_project_local_execution_row_read", false);
    push_bool_field(
        fields,
        "filter_project_local_execution_arrow_converted",
        false,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_object_store_io",
        false,
    );
    push_bool_field(fields, "filter_project_local_execution_write_io", false);
    push_bool_field(
        fields,
        "filter_project_local_execution_spill_io_performed",
        false,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_fallback_attempted",
        false,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_fallback_execution_allowed",
        false,
    );
}

fn append_vortex_filter_project_local_execution_effect_fields(
    fields: &mut Vec<(String, String)>,
    local: &VortexLocalPrimitiveCliExecutionEvidence,
) {
    push_bool_field(
        fields,
        "filter_project_local_execution_data_read",
        local.report.data_read,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_data_decoded",
        local.report.data_decoded,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_data_materialized",
        local.report.data_materialized,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_row_read",
        local.report.row_read,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_arrow_converted",
        local.report.arrow_converted,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_object_store_io",
        local.report.object_store_io,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_write_io",
        local.report.write_io,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_spill_io_performed",
        local.report.spill_io_performed,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_external_effects_executed",
        local.report.external_effects_executed,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_fallback_attempted",
        local.native_io_certificate.side_effects.fallback_attempted
            || local.native_io_certificate.fallback_attempted
            || local
                .execution_certificate
                .as_ref()
                .is_some_and(|certificate| certificate.fallback_attempted),
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_fallback_execution_allowed",
        local.report.fallback_execution_allowed,
    );
}

fn append_vortex_filter_project_local_execution_claim_fields(
    fields: &mut Vec<(String, String)>,
    local_execution: Option<&VortexLocalPrimitiveCliExecutionEvidence>,
) {
    let encoded_guarantee = local_execution
        .is_some_and(VortexLocalPrimitiveCliExecutionEvidence::filter_project_encoded_guaranteed);
    let native_io_certified =
        local_execution.is_some_and(|local| local.native_io_certificate.is_certified());
    let correctness_certified = local_execution.is_some_and(|local| {
        local
            .execution_certificate
            .as_ref()
            .is_some_and(ExecutionCertificate::is_certified)
    });
    push_bool_field(
        fields,
        "filter_project_local_execution_selection_vector_guarantee",
        encoded_guarantee,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_projection_pushdown_guarantee",
        encoded_guarantee,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_native_io_certified",
        native_io_certified,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_correctness_certified",
        correctness_certified,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_production_claim_allowed",
        false,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_generalized_claim_allowed",
        false,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_cg2_closeout_allowed",
        false,
    );
    push_bool_field(
        fields,
        "filter_project_local_execution_cg13_closeout_allowed",
        false,
    );
}

pub(crate) fn vortex_filter_human_text(
    result: &VortexQueryPrimitiveResult,
    local_execution: Option<&VortexLocalPrimitiveCliExecutionEvidence>,
) -> String {
    let mut sections = vec![result.to_human_text()];
    if let Some(local) = local_execution {
        sections.push(local.report.to_human_text());
        sections.push(local_primitive_native_io_certificate_human_text(
            &local.native_io_certificate,
        ));
        if let Some(certificate) = &local.execution_certificate {
            sections.push(certificate.to_human_text());
        }
    }
    sections.join("\n\n")
}

pub(crate) fn vortex_filter_fields(
    result: &VortexQueryPrimitiveResult,
    predicate_arg: String,
    local_execution: Option<&VortexLocalPrimitiveCliExecutionEvidence>,
) -> Vec<(String, String)> {
    let data_read = local_execution.map_or(result.data_read, |local| local.report.data_read);
    let data_decoded =
        local_execution.map_or(result.data_decoded, |local| local.report.data_decoded);
    let data_materialized = local_execution.map_or(result.data_materialized, |local| {
        local.report.data_materialized
    });
    let object_store_io =
        local_execution.map_or(result.object_store_io, |local| local.report.object_store_io);
    let write_io = local_execution.map_or(result.write_io, |local| local.report.write_io);
    let spill_io_performed = local_execution.map_or(result.spill_io_performed, |local| {
        local.report.spill_io_performed
    });
    let result_known = local_execution
        .and_then(VortexLocalPrimitiveCliExecutionEvidence::selected_rows)
        .is_some()
        || result.value.is_known();
    let execution = local_execution.map_or(
        "metadata_or_selection_vector_evidence_only".to_string(),
        |local| {
            if local.report.data_read {
                "local_vortex_filter_primitive_performed".to_string()
            } else {
                "local_vortex_filter_primitive_not_performed".to_string()
            }
        },
    );
    let filter_columns = predicate_columns_from_arg(&predicate_arg);
    let mut fields = vec![
        (
            "fallback_execution_allowed".to_string(),
            "false".to_string(),
        ),
        ("mode".to_string(), "vortex_filter".to_string()),
        ("primitive".to_string(), "filter_predicate".to_string()),
        ("data_read".to_string(), data_read.to_string()),
        ("data_decoded".to_string(), data_decoded.to_string()),
        (
            "data_materialized".to_string(),
            data_materialized.to_string(),
        ),
        ("object_store_io".to_string(), object_store_io.to_string()),
        ("write_io".to_string(), write_io.to_string()),
        (
            "spill_io_performed".to_string(),
            spill_io_performed.to_string(),
        ),
        ("execution".to_string(), execution),
        (
            "query_primitive_status".to_string(),
            result.status.as_str().to_string(),
        ),
        ("result_known".to_string(), result_known.to_string()),
        (
            "rows_selected".to_string(),
            local_execution
                .and_then(VortexLocalPrimitiveCliExecutionEvidence::selected_rows)
                .map_or_else(|| "unknown".to_string(), |value| value.to_string()),
        ),
        ("predicate".to_string(), predicate_arg),
    ];
    append_vortex_filter_local_execution_fields(&mut fields, local_execution);
    append_vortex_primitive_scan_pushdown_fields(
        &mut fields,
        "vortex_filter",
        &filter_columns,
        &[],
        None,
        local_execution,
    );
    fields
}

pub(crate) fn append_vortex_filter_local_execution_fields(
    fields: &mut Vec<(String, String)>,
    local_execution: Option<&VortexLocalPrimitiveCliExecutionEvidence>,
) {
    push_bool_field(
        fields,
        "filter_local_execution_requested",
        local_execution.is_some(),
    );
    push_field(
        fields,
        "filter_local_execution_feature_gate",
        "vortex-local-primitives",
    );
    push_bool_field(
        fields,
        "filter_local_execution_feature_enabled",
        cfg!(feature = "vortex-local-primitives"),
    );
    match local_execution {
        Some(local) => append_vortex_filter_local_execution_present_fields(fields, local),
        None => append_vortex_filter_local_execution_absent_fields(fields),
    }
}

fn append_vortex_filter_local_execution_absent_fields(fields: &mut Vec<(String, String)>) {
    push_field(fields, "filter_local_execution_status", "not_requested");
    push_field(fields, "filter_local_execution_mode", "not_requested");
    push_u64_field(fields, "filter_local_execution_memory_gb", 0);
    push_count_field(fields, "filter_local_execution_max_parallelism", 0);
    push_bool_field(fields, "filter_local_execution_result_known", false);
    push_field(fields, "filter_local_execution_rows_selected", "unknown");
    push_field(
        fields,
        "filter_local_execution_source_order_limit_requested",
        "none",
    );
    push_bool_field(
        fields,
        "filter_local_execution_source_order_limit_applied",
        false,
    );
    push_field(
        fields,
        "filter_local_execution_source_order_limit_input_rows",
        "unknown",
    );
    push_field(
        fields,
        "filter_local_execution_source_order_limit_rows_output",
        "unknown",
    );
    append_vortex_filter_local_execution_absent_effect_fields(fields);
    append_vortex_filter_local_execution_claim_fields(fields, false, false, false);
    append_vortex_local_primitive_native_io_certificate_fields(fields, None);
    append_vortex_local_primitive_execution_certificate_fields(fields, None);
}

fn append_vortex_filter_local_execution_present_fields(
    fields: &mut Vec<(String, String)>,
    local: &VortexLocalPrimitiveCliExecutionEvidence,
) {
    push_field(
        fields,
        "filter_local_execution_status",
        local.report.status.as_str(),
    );
    push_field(
        fields,
        "filter_local_execution_mode",
        local.report.mode.as_str(),
    );
    push_field(
        fields,
        "filter_local_execution_memory_gb",
        &local
            .resources
            .whole_gib()
            .map_or_else(|| "unavailable".into(), |value| value.to_string()),
    );
    push_count_field(
        fields,
        "filter_local_execution_max_parallelism",
        local.resources.max_parallelism(),
    );
    push_bool_field(
        fields,
        "filter_local_execution_result_known",
        local.selected_rows().is_some(),
    );
    push_field(
        fields,
        "filter_local_execution_rows_selected",
        &local
            .selected_rows()
            .map_or_else(|| "unknown".to_string(), |value| value.to_string()),
    );
    append_vortex_filter_source_order_limit_fields(fields, &local.report);
    push_u64_field(
        fields,
        "filter_local_execution_rows_scanned",
        local.report.rows_scanned,
    );
    push_count_field(
        fields,
        "filter_local_execution_arrays_read_count",
        local.report.arrays_read_count,
    );
    push_count_field(
        fields,
        "filter_local_execution_max_chunk_rows",
        local.report.max_chunk_rows,
    );
    push_count_field(
        fields,
        "filter_local_execution_scan_concurrency_per_worker",
        local.report.scan_concurrency_per_worker,
    );
    push_bool_field(
        fields,
        "filter_local_execution_streaming_scan_used",
        local.report.streaming_scan_used,
    );
    push_bool_field(
        fields,
        "filter_local_execution_full_stream_collected",
        local.report.full_stream_collected,
    );
    push_bool_field(
        fields,
        "filter_local_execution_filter_pushdown_applied",
        local.report.filter_pushdown_applied,
    );
    push_bool_field(
        fields,
        "filter_local_execution_upstream_filter_expression_used",
        local.report.upstream_filter_expression_used,
    );
    append_vortex_filter_local_execution_effect_fields(fields, local);
    append_vortex_filter_local_execution_claim_fields(
        fields,
        local.selection_vector_guaranteed(),
        local.native_io_certificate.is_certified(),
        local
            .execution_certificate
            .as_ref()
            .is_some_and(ExecutionCertificate::is_certified),
    );
    append_vortex_local_primitive_native_io_certificate_fields(
        fields,
        Some(&local.native_io_certificate),
    );
    append_vortex_local_primitive_execution_certificate_fields(
        fields,
        local.execution_certificate.as_ref(),
    );
}

fn append_vortex_filter_source_order_limit_fields(
    fields: &mut Vec<(String, String)>,
    report: &VortexLocalPrimitiveExecutionReport,
) {
    push_field(
        fields,
        "filter_local_execution_source_order_limit_requested",
        &report
            .source_order_limit_requested
            .map_or_else(|| "none".to_string(), |value| value.to_string()),
    );
    push_bool_field(
        fields,
        "filter_local_execution_source_order_limit_applied",
        report.source_order_limit_applied,
    );
    push_field(
        fields,
        "filter_local_execution_source_order_limit_input_rows",
        &report
            .source_order_limit_input_rows
            .map_or_else(|| "unknown".to_string(), |value| value.to_string()),
    );
    push_field(
        fields,
        "filter_local_execution_source_order_limit_rows_output",
        &report
            .source_order_limit_rows_output
            .map_or_else(|| "unknown".to_string(), |value| value.to_string()),
    );
}

fn append_vortex_filter_local_execution_absent_effect_fields(fields: &mut Vec<(String, String)>) {
    push_bool_field(fields, "filter_local_execution_data_read", false);
    push_bool_field(fields, "filter_local_execution_data_decoded", false);
    push_bool_field(fields, "filter_local_execution_data_materialized", false);
    push_bool_field(fields, "filter_local_execution_row_read", false);
    push_bool_field(fields, "filter_local_execution_arrow_converted", false);
    push_bool_field(fields, "filter_local_execution_object_store_io", false);
    push_bool_field(fields, "filter_local_execution_write_io", false);
    push_bool_field(fields, "filter_local_execution_spill_io_performed", false);
    push_bool_field(fields, "filter_local_execution_fallback_attempted", false);
    push_bool_field(
        fields,
        "filter_local_execution_fallback_execution_allowed",
        false,
    );
}

fn append_vortex_filter_local_execution_effect_fields(
    fields: &mut Vec<(String, String)>,
    local: &VortexLocalPrimitiveCliExecutionEvidence,
) {
    push_bool_field(
        fields,
        "filter_local_execution_data_read",
        local.report.data_read,
    );
    push_bool_field(
        fields,
        "filter_local_execution_data_decoded",
        local.report.data_decoded,
    );
    push_bool_field(
        fields,
        "filter_local_execution_data_materialized",
        local.report.data_materialized,
    );
    push_bool_field(
        fields,
        "filter_local_execution_row_read",
        local.report.row_read,
    );
    push_bool_field(
        fields,
        "filter_local_execution_arrow_converted",
        local.report.arrow_converted,
    );
    push_bool_field(
        fields,
        "filter_local_execution_object_store_io",
        local.report.object_store_io,
    );
    push_bool_field(
        fields,
        "filter_local_execution_write_io",
        local.report.write_io,
    );
    push_bool_field(
        fields,
        "filter_local_execution_spill_io_performed",
        local.report.spill_io_performed,
    );
    push_bool_field(
        fields,
        "filter_local_execution_external_effects_executed",
        local.report.external_effects_executed,
    );
    push_bool_field(
        fields,
        "filter_local_execution_fallback_attempted",
        local.native_io_certificate.side_effects.fallback_attempted
            || local.native_io_certificate.fallback_attempted
            || local
                .execution_certificate
                .as_ref()
                .is_some_and(|certificate| certificate.fallback_attempted),
    );
    push_bool_field(
        fields,
        "filter_local_execution_fallback_execution_allowed",
        local.report.fallback_execution_allowed,
    );
}

fn append_vortex_filter_local_execution_claim_fields(
    fields: &mut Vec<(String, String)>,
    selection_vector_guarantee: bool,
    native_io_certified: bool,
    correctness_certified: bool,
) {
    push_bool_field(
        fields,
        "filter_local_execution_selection_vector_guarantee",
        selection_vector_guarantee,
    );
    push_bool_field(
        fields,
        "filter_local_execution_native_io_certified",
        native_io_certified,
    );
    push_bool_field(
        fields,
        "filter_local_execution_correctness_certified",
        correctness_certified,
    );
    push_bool_field(
        fields,
        "filter_local_execution_production_claim_allowed",
        false,
    );
    push_bool_field(
        fields,
        "filter_local_execution_generalized_claim_allowed",
        false,
    );
    push_bool_field(fields, "filter_local_execution_cg2_closeout_allowed", false);
    push_bool_field(
        fields,
        "filter_local_execution_cg13_closeout_allowed",
        false,
    );
}

fn append_vortex_primitive_scan_pushdown_fields(
    fields: &mut Vec<(String, String)>,
    primitive: &str,
    filter_columns: &[String],
    output_columns: &[String],
    source_order_limit: Option<usize>,
    local_execution: Option<&VortexLocalPrimitiveCliExecutionEvidence>,
) {
    let filter_required = !filter_columns.is_empty();
    let projection_required = !output_columns.is_empty();
    let limit_required = source_order_limit.is_some();
    let scan_admitted = local_execution.is_some_and(|local| {
        local.report.mode == shardloom_vortex::VortexLocalPrimitiveExecutionMode::VortexScanPushdown
            && local.report.upstream_scan_called
    });
    let filter_pushed_down = local_execution.is_some_and(|local| {
        scan_admitted && filter_required && local.report.filter_pushdown_applied
    });
    let projection_pushed_down = local_execution.is_some_and(|local| {
        scan_admitted && projection_required && local.report.projection_pushdown_applied
    });
    let limit_pushed_down = false;
    let filter = ScanPushdownDimensionEvidence::new(
        scan_admitted,
        filter_required,
        filter_pushed_down,
        "filter",
    );
    let projection = ScanPushdownDimensionEvidence::new(
        scan_admitted,
        projection_required,
        projection_pushed_down,
        "projection",
    );
    let limit = ScanPushdownDimensionEvidence::new(
        scan_admitted,
        limit_required,
        limit_pushed_down,
        "limit",
    );
    let filter_only_columns = filter_columns
        .iter()
        .filter(|column| !output_columns.iter().any(|output| output == *column))
        .cloned()
        .collect::<Vec<_>>();
    let admission = scan_pushdown_admission(local_execution.is_some(), scan_admitted);
    let mut runtime = ScanPushdownRuntimeEvidence {
        admission,
        any_pushdown: filter.pushed_down || projection.pushed_down || limit.pushed_down,
        has_blocker: false,
    };
    let blocker_id = scan_pushdown_blocker_id(&runtime, filter, projection, limit);
    runtime.has_blocker = blocker_id != "none";
    let pushdown_status = scan_pushdown_status(&runtime);

    push_field(
        fields,
        "scan_pushdown_schema_version",
        VORTEX_PRIMITIVE_SCAN_PUSHDOWN_SCHEMA_VERSION,
    );
    push_field(
        fields,
        "scan_pushdown_report_id",
        &format!("gar-runtime-impl-4i.scan_pushdown.{primitive}"),
    );
    push_field(fields, "scan_pushdown_status", pushdown_status);
    push_scan_pushdown_dimension_fields(fields, filter, projection, limit);
    push_scan_pushdown_column_fields(fields, filter_columns, output_columns, &filter_only_columns);
    push_scan_pushdown_residual_limit_fields(
        fields,
        source_order_limit,
        limit_pushed_down,
        local_execution,
    );
    push_scan_pushdown_guardrail_fields(fields, local_execution, &blocker_id);
}

#[derive(Clone, Copy)]
struct ScanPushdownDimensionEvidence {
    required: bool,
    pushed_down: bool,
    status: &'static str,
}

impl ScanPushdownDimensionEvidence {
    fn new(scan_admitted: bool, required: bool, pushed_down: bool, dimension: &str) -> Self {
        Self {
            required,
            pushed_down,
            status: scan_pushdown_dimension_status(scan_admitted, required, pushed_down, dimension),
        }
    }
}

#[derive(Clone, Copy, Eq, PartialEq)]
enum ScanPushdownAdmission {
    NotExecuted,
    UnsupportedNoScan,
    Admitted,
}

struct ScanPushdownRuntimeEvidence {
    admission: ScanPushdownAdmission,
    any_pushdown: bool,
    has_blocker: bool,
}

fn push_scan_pushdown_dimension_fields(
    fields: &mut Vec<(String, String)>,
    filter: ScanPushdownDimensionEvidence,
    projection: ScanPushdownDimensionEvidence,
    limit: ScanPushdownDimensionEvidence,
) {
    push_bool_field(fields, "scan_filter_required", filter.required);
    push_bool_field(fields, "scan_projection_required", projection.required);
    push_bool_field(fields, "scan_limit_required", limit.required);
    push_bool_field(fields, "scan_filter_pushed_down", filter.pushed_down);
    push_bool_field(
        fields,
        "scan_projection_pushed_down",
        projection.pushed_down,
    );
    push_bool_field(fields, "scan_limit_pushed_down", limit.pushed_down);
    push_field(fields, "scan_filter_pushdown_status", filter.status);
    push_field(fields, "scan_projection_pushdown_status", projection.status);
    push_field(fields, "scan_limit_pushdown_status", limit.status);
}

fn push_scan_pushdown_column_fields(
    fields: &mut Vec<(String, String)>,
    filter_columns: &[String],
    output_columns: &[String],
    filter_only_columns: &[String],
) {
    push_field(
        fields,
        "scan_filter_columns_read",
        &comma_join_columns_or_none(filter_columns),
    );
    push_field(
        fields,
        "scan_output_columns_read",
        &comma_join_columns_or_none(output_columns),
    );
    push_field(
        fields,
        "scan_filter_only_columns_read",
        &comma_join_columns_or_none(filter_only_columns),
    );
}

fn push_scan_pushdown_residual_limit_fields(
    fields: &mut Vec<(String, String)>,
    source_order_limit: Option<usize>,
    limit_pushed_down: bool,
    local_execution: Option<&VortexLocalPrimitiveCliExecutionEvidence>,
) {
    let residual_required = source_order_limit.is_some() && !limit_pushed_down;
    let residual_applied = local_execution
        .is_some_and(|local| local.report.source_order_limit_applied && residual_required);
    push_field(
        fields,
        "scan_limit_requested_rows",
        &source_order_limit.map_or_else(|| "none".to_string(), |limit| limit.to_string()),
    );
    push_bool_field(fields, "scan_residual_limit_required", residual_required);
    push_bool_field(fields, "scan_residual_limit_applied", residual_applied);
    push_field(
        fields,
        "scan_residual_limit_status",
        match (residual_required, residual_applied) {
            (false, _) => "not_needed",
            (true, true) => "applied_by_shardloom_native_residual",
            (true, false) => "blocked_or_not_executed",
        },
    );
    push_field(
        fields,
        "scan_residual_limit_executor",
        if residual_applied {
            "shardloom_native"
        } else if residual_required {
            "unsupported_blocked_or_not_executed"
        } else {
            "none"
        },
    );
    push_field(
        fields,
        "scan_residual_limit_input_rows",
        &local_execution
            .and_then(|local| local.report.source_order_limit_input_rows)
            .map_or_else(|| "unknown".to_string(), |value| value.to_string()),
    );
    push_field(
        fields,
        "scan_residual_limit_rows_output",
        &local_execution
            .and_then(|local| local.report.source_order_limit_rows_output)
            .map_or_else(|| "unknown".to_string(), |value| value.to_string()),
    );
}

fn push_scan_pushdown_guardrail_fields(
    fields: &mut Vec<(String, String)>,
    local_execution: Option<&VortexLocalPrimitiveCliExecutionEvidence>,
    blocker_id: &str,
) {
    push_bool_field(
        fields,
        "scan_data_materialized",
        local_execution.is_some_and(|local| local.report.data_materialized),
    );
    push_bool_field(
        fields,
        "scan_data_decoded",
        local_execution.is_some_and(|local| local.report.data_decoded),
    );
    push_field(fields, "scan_pushdown_blocker_id", blocker_id);
    push_field(
        fields,
        "scan_pushdown_claim_gate_status",
        "fixture_smoke_only",
    );
    push_field(
        fields,
        "scan_pushdown_claim_boundary",
        "scoped local Vortex primitive scan pushdown evidence only; no encoded-native, SQL/DataFrame, object-store/lakehouse, production, performance, or Spark-replacement claim",
    );
    push_bool_field(fields, "scan_pushdown_fallback_attempted", false);
    push_bool_field(fields, "scan_pushdown_external_engine_invoked", false);
}

fn scan_pushdown_status(runtime: &ScanPushdownRuntimeEvidence) -> &'static str {
    match runtime.admission {
        ScanPushdownAdmission::NotExecuted => "not_executed",
        ScanPushdownAdmission::UnsupportedNoScan => "scan_pushdown_unsupported",
        ScanPushdownAdmission::Admitted if !runtime.has_blocker && runtime.any_pushdown => {
            "scan_pushdown_supported"
        }
        ScanPushdownAdmission::Admitted if !runtime.has_blocker => "scan_pushdown_not_needed",
        ScanPushdownAdmission::Admitted if runtime.any_pushdown => {
            "scan_pushdown_partially_supported"
        }
        ScanPushdownAdmission::Admitted => "scan_pushdown_blocked",
    }
}

fn scan_pushdown_blocker_id(
    runtime: &ScanPushdownRuntimeEvidence,
    filter: ScanPushdownDimensionEvidence,
    projection: ScanPushdownDimensionEvidence,
    limit: ScanPushdownDimensionEvidence,
) -> String {
    let mut blocker_ids = Vec::new();
    match runtime.admission {
        ScanPushdownAdmission::NotExecuted => {
            blocker_ids.push("gar-runtime-impl-4i.local_primitive_scan_not_executed");
        }
        ScanPushdownAdmission::UnsupportedNoScan => {
            blocker_ids.push("gar-runtime-impl-4i.vortex_scan_not_admitted");
        }
        ScanPushdownAdmission::Admitted => {}
    }
    if runtime.admission == ScanPushdownAdmission::Admitted
        && filter.required
        && !filter.pushed_down
    {
        blocker_ids.push("gar-runtime-impl-4i.filter_pushdown_not_lowered");
    }
    if runtime.admission == ScanPushdownAdmission::Admitted
        && projection.required
        && !projection.pushed_down
    {
        blocker_ids.push("gar-runtime-impl-4i.projection_pushdown_not_lowered");
    }
    if runtime.admission == ScanPushdownAdmission::Admitted && limit.required && !limit.pushed_down
    {
        blocker_ids.push("gar-runtime-impl-4i.limit_pushdown_not_admitted");
    }

    if blocker_ids.is_empty() {
        "none".to_string()
    } else {
        blocker_ids.join(";")
    }
}

fn scan_pushdown_admission(
    local_execution_present: bool,
    scan_admitted: bool,
) -> ScanPushdownAdmission {
    match (local_execution_present, scan_admitted) {
        (false, _) => ScanPushdownAdmission::NotExecuted,
        (true, false) => ScanPushdownAdmission::UnsupportedNoScan,
        (true, true) => ScanPushdownAdmission::Admitted,
    }
}

fn scan_pushdown_dimension_status(
    scan_admitted: bool,
    required: bool,
    pushed_down: bool,
    dimension: &str,
) -> &'static str {
    match (scan_admitted, required, pushed_down) {
        (false, _, _) => "unsupported_no_vortex_scan",
        (true, false, _) => "not_needed",
        (true, true, true) => "pushed_down",
        (true, true, false) if dimension == "filter" => "blocked_filter_not_lowered",
        (true, true, false) if dimension == "limit" => "blocked_no_scan_limit_admission",
        (true, true, false) => "blocked_projection_not_lowered",
    }
}

fn predicate_columns_from_arg(predicate_arg: &str) -> Vec<String> {
    match predicate_arg.split(':').collect::<Vec<_>>().as_slice() {
        ["is_null" | "is_not_null", column] | [_, column, _] => vec![(*column).to_string()],
        _ => Vec::new(),
    }
}

fn split_column_arg(columns_arg: &str) -> Vec<String> {
    columns_arg
        .split(',')
        .map(str::trim)
        .filter(|column| !column.is_empty())
        .map(ToString::to_string)
        .collect()
}

fn comma_join_columns_or_none(columns: &[String]) -> String {
    if columns.is_empty() {
        "none".to_string()
    } else {
        columns.join(",")
    }
}

fn append_vortex_count_where_predicate_evidence_fields(
    fields: &mut Vec<(String, String)>,
    report: &VortexEncodedPredicateEvaluationReport,
) {
    push_bool_field(fields, "encoded_predicate_evidence_emitted", true);
    push_field(fields, "encoded_predicate_status", report.status.as_str());
    push_count_field(
        fields,
        "encoded_predicate_segment_report_count",
        report.segment_report_count,
    );
    push_count_field(
        fields,
        "encoded_predicate_selected_all_count",
        report.selected_all_count,
    );
    push_count_field(
        fields,
        "encoded_predicate_selected_none_count",
        report.selected_none_count,
    );
    push_count_field(
        fields,
        "encoded_predicate_needs_encoded_values_count",
        report.needs_encoded_values_count,
    );
    push_count_field(
        fields,
        "encoded_predicate_selection_vectors_emitted",
        report.selection_vectors_emitted,
    );
    push_field(
        fields,
        "encoded_predicate_selected_rows_metadata_count",
        &report
            .selected_rows_metadata_count
            .map_or_else(|| "unknown".to_string(), |count| count.to_string()),
    );
    push_bool_field(fields, "encoded_predicate_data_read", report.data_read);
    push_bool_field(
        fields,
        "encoded_predicate_data_decoded",
        report.data_decoded,
    );
    push_bool_field(
        fields,
        "encoded_predicate_data_materialized",
        report.data_materialized,
    );
    push_bool_field(fields, "encoded_predicate_row_read", report.row_read);
    push_bool_field(
        fields,
        "encoded_predicate_arrow_converted",
        report.arrow_converted,
    );
    push_bool_field(
        fields,
        "encoded_predicate_fallback_attempted",
        report.fallback_attempted,
    );
    push_bool_field(
        fields,
        "encoded_predicate_fallback_execution_allowed",
        report.fallback_execution_allowed,
    );
}

fn append_vortex_count_where_filter_kernel_fields(
    fields: &mut Vec<(String, String)>,
    report: &VortexSelectionVectorFilterKernelReport,
) {
    push_bool_field(fields, "selection_vector_filter_kernel_emitted", true);
    push_field(
        fields,
        "selection_vector_filter_kernel_status",
        report.status.as_str(),
    );
    push_count_field(
        fields,
        "selection_vector_filter_kernel_segment_count",
        report.segment_count,
    );
    push_count_field(
        fields,
        "selection_vector_filter_kernel_selection_vector_count",
        report.selection_vector_count,
    );
    push_field(
        fields,
        "selection_vector_filter_kernel_selected_row_count",
        &report
            .selected_row_count
            .map_or_else(|| "unknown".to_string(), |count| count.to_string()),
    );
    push_bool_field(
        fields,
        "selection_vector_filter_kernel_safe_evidence",
        report.is_safe_native_filter_kernel_evidence(),
    );
    push_bool_field(
        fields,
        "selection_vector_filter_kernel_production_claim_allowed",
        report.production_claim_allowed,
    );
    push_bool_field(
        fields,
        "selection_vector_filter_kernel_data_read",
        report.data_read,
    );
    push_bool_field(
        fields,
        "selection_vector_filter_kernel_data_decoded",
        report.data_decoded,
    );
    push_bool_field(
        fields,
        "selection_vector_filter_kernel_data_materialized",
        report.data_materialized,
    );
    push_bool_field(
        fields,
        "selection_vector_filter_kernel_fallback_attempted",
        report.fallback_attempted,
    );
    push_bool_field(
        fields,
        "selection_vector_filter_kernel_fallback_execution_allowed",
        report.fallback_execution_allowed,
    );
}

fn append_vortex_count_where_filter_admission_fields(
    fields: &mut Vec<(String, String)>,
    report: &VortexSelectionVectorFilterKernelAdmissionReport,
) {
    push_bool_field(fields, "selection_vector_filter_admission_emitted", true);
    push_field(
        fields,
        "selection_vector_filter_admission_status",
        report.status.as_str(),
    );
    push_bool_field(
        fields,
        "selection_vector_filter_admission_slot_marked_present",
        report.slot_marked_present,
    );
    push_field(
        fields,
        "selection_vector_filter_admission_correctness_evidence",
        report.correctness_evidence.as_str(),
    );
    push_field(
        fields,
        "selection_vector_filter_admission_benchmark_evidence",
        report.benchmark_evidence.as_str(),
    );
    push_bool_field(
        fields,
        "selection_vector_filter_admission_production_claim_allowed",
        report.production_claim_allowed,
    );
    push_bool_field(
        fields,
        "selection_vector_filter_admission_runtime_execution_allowed",
        report.runtime_execution_allowed,
    );
    push_bool_field(
        fields,
        "selection_vector_filter_admission_fallback_execution_allowed",
        report.fallback_execution_allowed,
    );
}

pub(crate) fn parse_projection_columns(value: &str) -> Result<ProjectionRequest, ShardLoomError> {
    if value == "*" {
        return Ok(ProjectionRequest::all());
    }
    let columns: Result<Vec<_>, _> = value
        .split(',')
        .map(str::trim)
        .map(|name| {
            if name.is_empty() {
                return Err(ShardLoomError::InvalidOperation(
                    "projection contains empty column name".to_string(),
                ));
            }
            shardloom_core::ColumnRef::new(name)
        })
        .collect();
    Ok(ProjectionRequest::columns(columns?))
}

#[allow(clippy::too_many_lines)]
pub(crate) fn parse_vortex_primitive_request(
    uri: DatasetUri,
    primitive_arg: &str,
) -> Result<shardloom_vortex::VortexQueryPrimitiveRequest, ShardLoomError> {
    if primitive_arg == "count" {
        Ok(shardloom_vortex::VortexQueryPrimitiveRequest::count_all(
            uri,
        ))
    } else if let Some(pred) = primitive_arg.strip_prefix("count-where:") {
        Ok(shardloom_vortex::VortexQueryPrimitiveRequest::count_where(
            uri,
            parse_tiny_predicate(pred)?,
        ))
    } else if let Some(cols) = primitive_arg.strip_prefix("project:") {
        Ok(shardloom_vortex::VortexQueryPrimitiveRequest::project(
            uri,
            parse_projection_columns(cols)?,
        ))
    } else if let Some(cols) = primitive_arg.strip_prefix("distinct:") {
        Ok(
            shardloom_vortex::VortexQueryPrimitiveRequest::distinct_rows(
                uri,
                parse_projection_columns(cols)?,
                None,
            ),
        )
    } else if let Some(payload) = primitive_arg
        .strip_prefix("drop-duplicates:")
        .or_else(|| primitive_arg.strip_prefix("drop_duplicates:"))
        .or_else(|| primitive_arg.strip_prefix("drop-duplicate-rows:"))
        .or_else(|| primitive_arg.strip_prefix("drop_duplicate_rows:"))
    {
        let (output_columns, key_columns) = parse_drop_duplicate_columns(payload)?;
        Ok(
            shardloom_vortex::VortexQueryPrimitiveRequest::drop_duplicate_rows(
                uri,
                output_columns,
                key_columns,
            ),
        )
    } else if let Some(cols) = primitive_arg
        .strip_prefix("duplicate-mask:")
        .or_else(|| primitive_arg.strip_prefix("duplicate_mask:"))
        .or_else(|| primitive_arg.strip_prefix("duplicated:"))
    {
        Ok(
            shardloom_vortex::VortexQueryPrimitiveRequest::duplicate_mask_rows(
                uri,
                parse_projection_columns(cols)?,
            ),
        )
    } else if let Some(cols) = primitive_arg.strip_prefix("tail:") {
        Ok(shardloom_vortex::VortexQueryPrimitiveRequest::tail_rows(
            uri,
            parse_projection_columns(cols)?,
            1,
        ))
    } else if let Some(cols) = primitive_arg.strip_prefix("sample:") {
        Ok(shardloom_vortex::VortexQueryPrimitiveRequest::sample_rows(
            uri,
            parse_projection_columns(cols)?,
            None,
            1,
            0,
        ))
    } else if let Some(payload) = primitive_arg
        .strip_prefix("expression-project:")
        .or_else(|| primitive_arg.strip_prefix("expression_project:"))
    {
        parse_expression_project_primitive_request(uri, payload)
    } else if let Some(payload) = primitive_arg
        .strip_prefix("melt:")
        .or_else(|| primitive_arg.strip_prefix("melt-rows:"))
        .or_else(|| primitive_arg.strip_prefix("melt_rows:"))
    {
        parse_melt_primitive_request(uri, payload)
    } else if let Some(payload) = primitive_arg
        .strip_prefix("explode:")
        .or_else(|| primitive_arg.strip_prefix("explode-rows:"))
        .or_else(|| primitive_arg.strip_prefix("explode_rows:"))
        .or_else(|| primitive_arg.strip_prefix("list-explode:"))
        .or_else(|| primitive_arg.strip_prefix("list_explode:"))
    {
        parse_explode_primitive_request(uri, payload)
    } else if let Some(payload) = primitive_arg
        .strip_prefix("pivot:")
        .or_else(|| primitive_arg.strip_prefix("pivot-rows:"))
        .or_else(|| primitive_arg.strip_prefix("pivot_rows:"))
        .or_else(|| primitive_arg.strip_prefix("pivot-table:"))
        .or_else(|| primitive_arg.strip_prefix("pivot_table:"))
    {
        parse_pivot_primitive_request(uri, payload)
    } else if let Some(payload) = primitive_arg
        .strip_prefix("rolling:")
        .or_else(|| primitive_arg.strip_prefix("rolling-window:"))
        .or_else(|| primitive_arg.strip_prefix("rolling_window:"))
    {
        parse_rolling_primitive_request(uri, payload)
    } else if let Some(payload) = primitive_arg
        .strip_prefix("sort-rows:")
        .or_else(|| primitive_arg.strip_prefix("sort_rows:"))
        .or_else(|| primitive_arg.strip_prefix("order-rows:"))
        .or_else(|| primitive_arg.strip_prefix("order_rows:"))
        .or_else(|| primitive_arg.strip_prefix("sort:"))
    {
        parse_sort_rows_primitive_request(uri, payload, None, None)
    } else if let Some(payload) = primitive_arg
        .strip_prefix("aggregate:")
        .or_else(|| primitive_arg.strip_prefix("simple-aggregate:"))
        .or_else(|| primitive_arg.strip_prefix("simple_aggregate:"))
        .or_else(|| primitive_arg.strip_prefix("scalar-aggregate:"))
        .or_else(|| primitive_arg.strip_prefix("scalar_aggregate:"))
    {
        parse_simple_aggregate_primitive_request(uri, payload)
    } else if let Some((predicate, payload)) = prefixed_predicate_columns(
        primitive_arg,
        &[
            "aggregate-filter:",
            "aggregate-where:",
            "simple-aggregate-filter:",
            "simple_aggregate_filter:",
        ],
        "aggregate-filter",
    )? {
        let mut request = parse_simple_aggregate_primitive_request(uri, payload)?;
        request.predicate = Some(parse_tiny_predicate(predicate)?);
        Ok(request)
    } else if let Some(pred) = primitive_arg.strip_prefix("filter:") {
        Ok(shardloom_vortex::VortexQueryPrimitiveRequest::filter(
            uri,
            parse_tiny_predicate(pred)?,
        ))
    } else {
        parse_vortex_compound_primitive_request(uri, primitive_arg)
    }
}

fn parse_vortex_compound_primitive_request(
    uri: DatasetUri,
    primitive_arg: &str,
) -> Result<shardloom_vortex::VortexQueryPrimitiveRequest, ShardLoomError> {
    if let Some((predicate, columns)) = prefixed_predicate_columns(
        primitive_arg,
        &["filter-project:", "filter-and-project:"],
        "filter-project",
    )? {
        return Ok(
            shardloom_vortex::VortexQueryPrimitiveRequest::filter_and_project(
                uri,
                parse_tiny_predicate(predicate)?,
                parse_projection_columns(columns)?,
            ),
        );
    }
    if let Some((predicate, columns)) = prefixed_predicate_columns(
        primitive_arg,
        &["distinct-filter-project:", "distinct-filter-and-project:"],
        "distinct-filter-project",
    )? {
        return Ok(
            shardloom_vortex::VortexQueryPrimitiveRequest::distinct_rows(
                uri,
                parse_projection_columns(columns)?,
                Some(parse_tiny_predicate(predicate)?),
            ),
        );
    }
    if let Some((predicate, columns, key_columns)) = prefixed_predicate_columns_payload(
        primitive_arg,
        &[
            "drop-duplicates-filter-project:",
            "drop-duplicates-filter-and-project:",
            "drop_duplicates_filter_project:",
            "drop_duplicate_rows_filter_project:",
        ],
        "drop-duplicates-filter-project",
    )? {
        let mut request = shardloom_vortex::VortexQueryPrimitiveRequest::drop_duplicate_rows(
            uri,
            parse_projection_columns(columns)?,
            parse_projection_columns(key_columns)?,
        );
        request.predicate = Some(parse_tiny_predicate(predicate)?);
        return Ok(request);
    }
    if let Some((predicate, columns)) = prefixed_predicate_columns(
        primitive_arg,
        &["sample-filter-project:", "sample-filter-and-project:"],
        "sample-filter-project",
    )? {
        return Ok(shardloom_vortex::VortexQueryPrimitiveRequest::sample_rows(
            uri,
            parse_projection_columns(columns)?,
            Some(parse_tiny_predicate(predicate)?),
            1,
            0,
        ));
    }
    if let Some((predicate, columns, payload)) = prefixed_predicate_columns_payload(
        primitive_arg,
        &["sort-filter-project:", "sort-filter-and-project:"],
        "sort-filter-project",
    )? {
        return parse_sort_rows_primitive_request(uri, payload, Some(predicate), Some(columns));
    }
    Err(ShardLoomError::InvalidOperation(
        "invalid primitive; expected count, count-where:<predicate>, project:<columns>, distinct:<columns>, drop-duplicates:<output-columns>|<key-columns>, tail:<columns>, sample:<columns>, expression-project:<json>, melt:<json>, explode:<json>, pivot:<json>, rolling:<json>, sort-rows:<json>, aggregate:<json>, aggregate-filter:<predicate>|<json>, filter:<predicate>, filter-project:<predicate>|<columns>, distinct-filter-project:<predicate>|<columns>, drop-duplicates-filter-project:<predicate>|<output-columns>|<key-columns>, sample-filter-project:<predicate>|<columns>, sort-filter-project:<predicate>|<columns>|<json>".to_string(),
    ))
}

fn parse_drop_duplicate_columns(
    value: &str,
) -> Result<(ProjectionRequest, ProjectionRequest), ShardLoomError> {
    let Some((output_columns, key_columns)) = value.split_once('|') else {
        return Err(ShardLoomError::InvalidOperation(
            "drop-duplicates requires <output-columns>|<key-columns>".to_string(),
        ));
    };
    if output_columns.is_empty() || key_columns.is_empty() {
        return Err(ShardLoomError::InvalidOperation(
            "drop-duplicates output and key column lists must not be empty".to_string(),
        ));
    }
    Ok((
        parse_projection_columns(output_columns)?,
        parse_projection_columns(key_columns)?,
    ))
}

pub(crate) fn parse_melt_primitive_request(
    uri: impl Into<Option<DatasetUri>>,
    payload: &str,
) -> Result<shardloom_vortex::VortexQueryPrimitiveRequest, ShardLoomError> {
    let value = serde_json::from_str::<serde_json::Value>(payload).map_err(|error| {
        ShardLoomError::InvalidOperation(format!("melt payload must be valid JSON: {error}"))
    })?;
    let object = value.as_object().ok_or_else(|| {
        ShardLoomError::InvalidOperation("melt payload must be a JSON object".to_string())
    })?;
    let id_columns = json_column_array_field_any(object, &["id_columns", "id_vars"])?;
    let value_columns = json_column_array_field_any(object, &["value_columns", "value_vars"])?;
    if value_columns.is_empty() {
        return Err(ShardLoomError::InvalidOperation(
            "melt payload requires at least one value column".to_string(),
        ));
    }
    let variable_column = json_optional_string_field_any(object, &["variable_column", "var_name"])?
        .unwrap_or("variable")
        .to_string();
    let value_column = json_optional_string_field_any(object, &["value_column", "value_name"])?
        .unwrap_or("value")
        .to_string();
    let projection =
        VortexMeltProjectionRequest::new(id_columns, value_columns, variable_column, value_column);
    let columns = projection.projected_columns();
    Ok(shardloom_vortex::VortexQueryPrimitiveRequest {
        source_uri: uri.into(),
        melt_projection: Some(projection),
        ..shardloom_vortex::VortexQueryPrimitiveRequest::for_relational_input(
            shardloom_vortex::VortexQueryPrimitiveKind::MeltRows,
            ProjectionRequest::columns(columns),
        )
    })
}

pub(crate) fn parse_explode_primitive_request(
    uri: impl Into<Option<DatasetUri>>,
    payload: &str,
) -> Result<shardloom_vortex::VortexQueryPrimitiveRequest, ShardLoomError> {
    let source_uri = uri.into();
    let value = serde_json::from_str::<serde_json::Value>(payload).map_err(|error| {
        ShardLoomError::InvalidOperation(format!("explode payload must be valid JSON: {error}"))
    })?;
    let object = value.as_object().ok_or_else(|| {
        ShardLoomError::InvalidOperation("explode payload must be a JSON object".to_string())
    })?;
    let single_column =
        json_optional_string_field_any(object, &["column", "explode_column", "target_column"])?
            .map(ColumnRef::new)
            .transpose()?;
    let columns_field = json_optional_column_array_field_any(object, &["columns"])?;
    let multiple_columns =
        json_optional_column_array_field_any(object, &["explode_columns", "target_columns"])?;
    if multiple_columns.is_some() && (single_column.is_some() || columns_field.is_some()) {
        return Err(ShardLoomError::InvalidOperation(
            "explode payload has conflicting target columns".into(),
        ));
    }
    let explode_columns = multiple_columns
        .or_else(|| single_column.as_ref().map(|column| vec![column.clone()]))
        .or_else(|| columns_field.clone())
        .unwrap_or_default();
    if explode_columns.is_empty() {
        return Err(ShardLoomError::InvalidOperation(
            "explode payload requires column or explode_columns".to_string(),
        ));
    }
    let output_columns =
        json_optional_column_array_field_any(object, &["output_columns", "projected_columns"])?
            .or_else(|| single_column.as_ref().and(columns_field));
    for column in &explode_columns {
        if output_columns
            .as_ref()
            .is_some_and(|columns| !columns.contains(column))
        {
            return Err(ShardLoomError::InvalidOperation(format!(
                "explode output columns must include explode column '{}'",
                column.as_str()
            )));
        }
    }
    let element_field =
        json_optional_string_field_any(object, &["element_field", "field", "field_path"])?;
    let element_output_column =
        json_optional_string_field_any(object, &["element_output_column", "output_column"])?;
    if element_output_column.is_some() && element_field.is_none() {
        return Err(ShardLoomError::InvalidOperation(
            "explode output_column requires element_field".into(),
        ));
    }
    let element_projection = if let Some(field) = element_field {
        let field_ref = ColumnRef::new(field)?;
        let output = element_output_column
            .map(ColumnRef::new)
            .transpose()?
            .unwrap_or_else(|| field_ref.clone());
        Some((field_ref.as_str().to_string(), output.as_str().to_string()))
    } else {
        None
    };
    if element_projection.is_some() && explode_columns.len() != 1 {
        return Err(ShardLoomError::InvalidOperation(
            "explode element_field requires exactly one explode column".to_string(),
        ));
    }
    let mut projection = VortexExplodeProjectionRequest::new(explode_columns[0].clone())
        .with_columns(explode_columns);
    if let Some((field, output)) = element_projection {
        projection = projection.with_element_field(field, output);
    }
    let selected = output_columns.map_or_else(
        || {
            if source_uri.is_none() {
                ProjectionRequest::All
            } else {
                ProjectionRequest::columns(projection.explode_columns())
            }
        },
        ProjectionRequest::columns,
    );
    Ok(shardloom_vortex::VortexQueryPrimitiveRequest {
        source_uri,
        explode_projection: Some(projection),
        ..shardloom_vortex::VortexQueryPrimitiveRequest::for_relational_input(
            shardloom_vortex::VortexQueryPrimitiveKind::ExplodeRows,
            selected,
        )
    })
}

pub(crate) fn parse_pivot_primitive_request(
    uri: impl Into<Option<DatasetUri>>,
    payload: &str,
) -> Result<shardloom_vortex::VortexQueryPrimitiveRequest, ShardLoomError> {
    let value = serde_json::from_str::<serde_json::Value>(payload).map_err(|error| {
        ShardLoomError::InvalidOperation(format!("pivot payload must be valid JSON: {error}"))
    })?;
    let object = value.as_object().ok_or_else(|| {
        ShardLoomError::InvalidOperation("pivot payload must be a JSON object".to_string())
    })?;
    let index_column = ColumnRef::new(json_string_field_any(object, &["index", "index_column"])?)?;
    let pivot_column = ColumnRef::new(json_string_field_any(
        object,
        &["columns", "pivot_column", "column_column"],
    )?)?;
    let value_column = ColumnRef::new(json_string_field_any(object, &["values", "value_column"])?)?;
    let aggregate = json_optional_string_field_any(object, &["aggregate", "aggfunc"])?
        .unwrap_or("first_unique")
        .to_string();
    let fill_value = json_optional_scalar_value_field_any(object, &["fill_value", "fill"])?;
    let dropna = json_optional_bool_field_any(object, &["dropna"])?.unwrap_or(true);
    let margins = json_optional_bool_field_any(object, &["margins"])?.unwrap_or(false);
    let margins_name = json_optional_string_field_any(object, &["margins_name"])?
        .unwrap_or("All")
        .to_string();
    let pivot =
        VortexPivotProjectionRequest::new(index_column, pivot_column, value_column, aggregate)
            .with_output_policy(fill_value, dropna, margins, margins_name);
    Ok(shardloom_vortex::VortexQueryPrimitiveRequest {
        source_uri: uri.into(),
        projection: ProjectionRequest::columns(pivot.projected_columns()),
        pivot_projection: Some(pivot),
        ..shardloom_vortex::VortexQueryPrimitiveRequest::for_relational_input(
            shardloom_vortex::VortexQueryPrimitiveKind::PivotRows,
            ProjectionRequest::All,
        )
    })
}

pub(crate) fn parse_rolling_primitive_request(
    uri: impl Into<Option<DatasetUri>>,
    payload: &str,
) -> Result<shardloom_vortex::VortexQueryPrimitiveRequest, ShardLoomError> {
    let value = serde_json::from_str::<serde_json::Value>(payload).map_err(|error| {
        ShardLoomError::InvalidOperation(format!("rolling payload must be valid JSON: {error}"))
    })?;
    let object = value.as_object().ok_or_else(|| {
        ShardLoomError::InvalidOperation("rolling payload must be a JSON object".to_string())
    })?;
    let source_column = ColumnRef::new(json_string_field_any(
        object,
        &["source_column", "column", "on"],
    )?)?;
    let output_column = json_string_field_any(object, &["output_column", "alias"])?.to_string();
    let window_size = json_usize_field_any(object, &["window_size", "window"])?;
    let min_periods = json_usize_field_any(object, &["min_periods"])?;
    let aggregate = json_string_field_any(object, &["aggregate", "agg"])?.to_string();
    let center = json_optional_bool_field_any(object, &["center"])?.unwrap_or(false);
    let rolling = VortexRollingWindowRequest::new(
        source_column,
        output_column,
        window_size,
        min_periods,
        aggregate,
    )
    .with_center(center);
    let columns = rolling.projected_columns();
    Ok(shardloom_vortex::VortexQueryPrimitiveRequest {
        source_uri: uri.into(),
        rolling_window: Some(rolling),
        ..shardloom_vortex::VortexQueryPrimitiveRequest::for_relational_input(
            shardloom_vortex::VortexQueryPrimitiveKind::RollingWindowRows,
            ProjectionRequest::columns(columns),
        )
    })
}

fn parse_simple_aggregate_primitive_request(
    uri: DatasetUri,
    payload: &str,
) -> Result<shardloom_vortex::VortexQueryPrimitiveRequest, ShardLoomError> {
    let value = serde_json::from_str::<serde_json::Value>(payload).map_err(|error| {
        ShardLoomError::InvalidOperation(format!("aggregate payload must be valid JSON: {error}"))
    })?;
    let group_by = value
        .as_object()
        .map(|object| {
            json_optional_column_array_field_any(object, &["group_by", "groupBy", "keys"])
        })
        .transpose()?
        .flatten()
        .unwrap_or_default();
    let measures = if let Some(array) = value.get("measures").and_then(serde_json::Value::as_array)
    {
        array
            .iter()
            .map(parse_simple_aggregate_measure)
            .collect::<Result<Vec<_>, _>>()?
    } else if value.is_object() {
        vec![parse_simple_aggregate_measure(&value)?]
    } else {
        return Err(ShardLoomError::InvalidOperation(
            "aggregate payload must be a JSON object with a measure or measures array".to_string(),
        ));
    };
    if measures.is_empty() {
        return Err(ShardLoomError::InvalidOperation(
            "aggregate payload requires at least one measure".to_string(),
        ));
    }
    let order_by = value
        .as_object()
        .map(|object| {
            json_optional_aggregate_order_array_field_any(object, &["order_by", "orderBy"])
        })
        .transpose()?
        .flatten()
        .unwrap_or_default();
    let offset = value
        .as_object()
        .map(|object| json_optional_usize_field_any(object, &["offset"]))
        .transpose()?
        .flatten()
        .unwrap_or(0);
    let group_expressions = value
        .as_object()
        .map(|object| {
            json_optional_aggregate_expression_array_field_any(
                object,
                &["group_expressions", "groupExpressions", "computed_group_by"],
            )
        })
        .transpose()?
        .flatten()
        .unwrap_or_default();
    let having = value
        .as_object()
        .map(|object| json_optional_aggregate_having_array_field_any(object, &["having"]))
        .transpose()?
        .flatten()
        .unwrap_or_default();
    let mut aggregate = VortexSimpleAggregateRequest::grouped(group_by, measures)
        .with_group_expressions(group_expressions)
        .with_order_by(order_by)
        .with_having(having)
        .with_offset(offset);
    aggregate.spill = aggregate_spill_policy::parse(value.get("spill"))?;
    Ok(shardloom_vortex::VortexQueryPrimitiveRequest::simple_aggregate(uri, aggregate))
}

fn parse_sort_rows_primitive_request(
    uri: DatasetUri,
    payload: &str,
    predicate: Option<&str>,
    columns: Option<&str>,
) -> Result<shardloom_vortex::VortexQueryPrimitiveRequest, ShardLoomError> {
    let value = serde_json::from_str::<serde_json::Value>(payload).map_err(|error| {
        ShardLoomError::InvalidOperation(format!("sort rows payload must be valid JSON: {error}"))
    })?;
    let object = value.as_object().ok_or_else(|| {
        ShardLoomError::InvalidOperation("sort rows payload must be a JSON object".to_string())
    })?;
    let order_by = json_optional_aggregate_order_array_field_any(object, &["order_by", "orderBy"])?
        .ok_or_else(|| {
            ShardLoomError::InvalidOperation(
                "sort rows payload requires order_by array".to_string(),
            )
        })?;
    let offset = json_optional_usize_field_any(object, &["offset"])?.unwrap_or(0);
    let tie_policy = json_optional_string_field_any(object, &["tie_policy", "keep"])?
        .map(parse_sort_tie_policy)
        .transpose()?
        .unwrap_or(VortexSortTiePolicy::First);
    let limit =
        json_optional_usize_field_any(object, &["limit", "source_order_limit"])?.unwrap_or(1);
    let projection = if let Some(columns) = columns {
        parse_projection_columns(columns)?
    } else {
        json_optional_projection_field_any(object, &["columns", "projection"])?
            .unwrap_or_else(ProjectionRequest::all)
    };
    let mut sort_rows = VortexSortRowsRequest::new(order_by)
        .with_offset(offset)
        .with_tie_policy(tie_policy);
    if let Some(spill) = object.get("spill") {
        let spill = spill.as_object().ok_or_else(|| {
            ShardLoomError::InvalidOperation("sort spill policy must be an object".into())
        })?;
        let workspace = json_string_field_any(spill, &["workspace"])?;
        let required_bytes = |field: &str| {
            spill
                .get(field)
                .and_then(serde_json::Value::as_u64)
                .ok_or_else(|| {
                    ShardLoomError::InvalidOperation(format!(
                        "sort spill policy requires unsigned {field}"
                    ))
                })
        };
        sort_rows = sort_rows.with_spill(shardloom_vortex::VortexSortSpillPolicy::new(
            workspace,
            required_bytes("quota_bytes")?,
            required_bytes("memory_bytes")?,
        )?);
    }
    let request = shardloom_vortex::VortexQueryPrimitiveRequest::sort_rows(
        uri,
        projection,
        predicate.map(parse_tiny_predicate).transpose()?,
        sort_rows,
        limit,
    );
    Ok(request)
}

fn parse_sort_tie_policy(value: &str) -> Result<VortexSortTiePolicy, ShardLoomError> {
    match value.trim().to_ascii_lowercase().replace('-', "_").as_str() {
        "first" => Ok(VortexSortTiePolicy::First),
        "last" => Ok(VortexSortTiePolicy::Last),
        "all" | "all_ties" | "ties" => Ok(VortexSortTiePolicy::All),
        _ => Err(ShardLoomError::InvalidOperation(
            "sort rows tie policy must be first, last, or all".to_string(),
        )),
    }
}

fn parse_simple_aggregate_measure(
    value: &serde_json::Value,
) -> Result<VortexSimpleAggregateMeasure, ShardLoomError> {
    let object = value.as_object().ok_or_else(|| {
        ShardLoomError::InvalidOperation("aggregate measure must be a JSON object".to_string())
    })?;
    let function = json_string_field_any(object, &["function", "agg", "aggregate"])?.to_string();
    let column = json_optional_string_field_any(object, &["column", "source_column", "on"])?
        .map(ColumnRef::new)
        .transpose()?;
    let alias = json_optional_string_field_any(object, &["alias", "output_column"])?.map_or_else(
        || {
            format!(
                "{}_{}",
                function.trim().to_ascii_lowercase(),
                column.as_ref().map_or("all", ColumnRef::as_str)
            )
        },
        str::to_string,
    );
    let argument_offset =
        json_optional_i64_field_any(object, &["argument_offset", "arg_offset", "offset"])?;
    let value_transform =
        json_optional_string_field_any(object, &["value_transform", "transform"])?
            .map(str::to_string);
    if ["decimal_output", "precision", "scale", "rounding"]
        .iter()
        .any(|name| object.contains_key(*name))
    {
        return Err(ShardLoomError::InvalidOperation(
            "decimal output options require the native SQL or relation surface".to_string(),
        ));
    }
    if object.contains_key("secondary_column") {
        return Err(ShardLoomError::InvalidOperation(
            "paired aggregates require the native SQL or relation surface".to_string(),
        ));
    }
    let mut measure = VortexSimpleAggregateMeasure::new(function, column, alias);
    if let Some(argument_offset) = argument_offset {
        measure = measure.with_argument_offset(argument_offset);
    }
    if let Some(value_transform) = value_transform {
        measure = measure.with_value_transform(value_transform);
    }
    Ok(measure)
}

fn parse_aggregate_expression(
    value: &serde_json::Value,
) -> Result<VortexAggregateExpression, ShardLoomError> {
    let object = value.as_object().ok_or_else(|| {
        ShardLoomError::InvalidOperation("aggregate expression must be a JSON object".to_string())
    })?;
    let alias = json_string_field_any(object, &["alias", "output_column"])?.to_string();
    let column = ColumnRef::new(json_string_field_any(
        object,
        &["column", "source_column", "on"],
    )?)?;
    let extra_columns =
        json_optional_column_array_field_any(object, &["extra_columns", "extraColumns"])?
            .unwrap_or_default();
    let function = json_string_field_any(object, &["function", "expr", "transform"])?.to_string();
    let argument_offset =
        json_optional_i64_field_any(object, &["argument_offset", "arg_offset", "offset"])?;
    let mut expression =
        VortexAggregateExpression::new(alias, column, function).with_extra_columns(extra_columns);
    if let Some(argument_offset) = argument_offset {
        expression = expression.with_argument_offset(argument_offset);
    }
    Ok(expression)
}

fn json_optional_aggregate_expression_array_field_any(
    object: &serde_json::Map<String, serde_json::Value>,
    fields: &[&str],
) -> Result<Option<Vec<VortexAggregateExpression>>, ShardLoomError> {
    for field in fields {
        if let Some(value) = object.get(*field) {
            return match value {
                serde_json::Value::Array(array) => array
                    .iter()
                    .map(parse_aggregate_expression)
                    .collect::<Result<Vec<_>, _>>()
                    .map(Some),
                _ => Err(ShardLoomError::InvalidOperation(format!(
                    "aggregate {field} must be an array"
                ))),
            };
        }
    }
    Ok(None)
}

fn parse_aggregate_having(
    value: &serde_json::Value,
) -> Result<VortexAggregateHavingExpr, ShardLoomError> {
    let object = value.as_object().ok_or_else(|| {
        ShardLoomError::InvalidOperation(
            "aggregate having expression must be a JSON object".to_string(),
        )
    })?;
    let column = json_string_field_any(object, &["column", "alias"])?.to_string();
    let op = parse_comparison_op(json_string_field_any(object, &["op", "operator"])?).ok_or_else(
        || {
            ShardLoomError::InvalidOperation(
                "aggregate having operator must be one of eq, neq, gt, gte, lt, or lte".to_string(),
            )
        },
    )?;
    let raw_value = object.get("value").ok_or_else(|| {
        ShardLoomError::InvalidOperation("aggregate having expression requires value".to_string())
    })?;
    let value = match raw_value {
        serde_json::Value::String(value) => value.clone(),
        serde_json::Value::Number(value) => value.to_string(),
        serde_json::Value::Bool(value) => value.to_string(),
        serde_json::Value::Null | serde_json::Value::Array(_) | serde_json::Value::Object(_) => {
            return Err(ShardLoomError::InvalidOperation(
                "aggregate having value must be a scalar string, number, or boolean".to_string(),
            ));
        }
    };
    Ok(VortexAggregateHavingExpr::new(column, op, value))
}

fn json_optional_aggregate_having_array_field_any(
    object: &serde_json::Map<String, serde_json::Value>,
    fields: &[&str],
) -> Result<Option<Vec<VortexAggregateHavingExpr>>, ShardLoomError> {
    for field in fields {
        if let Some(value) = object.get(*field) {
            return match value {
                serde_json::Value::Array(array) => array
                    .iter()
                    .map(parse_aggregate_having)
                    .collect::<Result<Vec<_>, _>>()
                    .map(Some),
                _ => Err(ShardLoomError::InvalidOperation(format!(
                    "aggregate {field} must be an array"
                ))),
            };
        }
    }
    Ok(None)
}

fn json_optional_column_array_field_any(
    object: &serde_json::Map<String, serde_json::Value>,
    fields: &[&str],
) -> Result<Option<Vec<ColumnRef>>, ShardLoomError> {
    for field in fields {
        if let Some(value) = object.get(*field) {
            return match value {
                serde_json::Value::String(value) => match parse_projection_columns(value)? {
                    ProjectionRequest::All => Err(ShardLoomError::InvalidOperation(format!(
                        "aggregate field {field} must name explicit columns, not *"
                    ))),
                    ProjectionRequest::Columns(columns) => Ok(Some(columns)),
                },
                serde_json::Value::Array(values) => {
                    let mut columns = Vec::with_capacity(values.len());
                    for value in values {
                        let Some(column) = value.as_str() else {
                            return Err(ShardLoomError::InvalidOperation(format!(
                                "aggregate field {field} array must contain strings"
                            )));
                        };
                        columns.push(ColumnRef::new(column)?);
                    }
                    Ok(Some(columns))
                }
                _ => Err(ShardLoomError::InvalidOperation(format!(
                    "aggregate field {field} must be a string or string array"
                ))),
            };
        }
    }
    Ok(None)
}

fn json_optional_projection_field_any(
    object: &serde_json::Map<String, serde_json::Value>,
    fields: &[&str],
) -> Result<Option<ProjectionRequest>, ShardLoomError> {
    for field in fields {
        if let Some(value) = object.get(*field) {
            return match value {
                serde_json::Value::String(value) => Ok(Some(parse_projection_columns(value)?)),
                serde_json::Value::Array(values) => {
                    let mut columns = Vec::with_capacity(values.len());
                    for value in values {
                        let Some(column) = value.as_str() else {
                            return Err(ShardLoomError::InvalidOperation(format!(
                                "projection field {field} array must contain strings"
                            )));
                        };
                        columns.push(ColumnRef::new(column)?);
                    }
                    Ok(Some(ProjectionRequest::columns(columns)))
                }
                _ => Err(ShardLoomError::InvalidOperation(format!(
                    "projection field {field} must be a string or string array"
                ))),
            };
        }
    }
    Ok(None)
}

fn json_optional_aggregate_order_array_field_any(
    object: &serde_json::Map<String, serde_json::Value>,
    fields: &[&str],
) -> Result<Option<Vec<VortexAggregateOrderExpr>>, ShardLoomError> {
    for field in fields {
        if let Some(value) = object.get(*field) {
            let values = value.as_array().ok_or_else(|| {
                ShardLoomError::InvalidOperation(format!(
                    "aggregate field {field} must be an array of order objects"
                ))
            })?;
            let mut out = Vec::with_capacity(values.len());
            for value in values {
                let order = value.as_object().ok_or_else(|| {
                    ShardLoomError::InvalidOperation(
                        "aggregate order_by entries must be JSON objects".to_string(),
                    )
                })?;
                let column = json_string_field_any(order, &["column", "alias", "by"])?;
                let descending =
                    json_optional_bool_field_any(order, &["descending", "desc"])?.unwrap_or(false);
                let mut expression = VortexAggregateOrderExpr::new(column, descending);
                if let Some(nulls) = order.get("nulls") {
                    use shardloom_vortex::relational_query::VortexRelationalNullOrder;
                    expression = expression.with_nulls(match nulls.as_str() {
                        Some(value) if value.eq_ignore_ascii_case("first") => VortexRelationalNullOrder::First,
                        Some(value) if value.eq_ignore_ascii_case("last") => VortexRelationalNullOrder::Last,
                        _ => return Err(ShardLoomError::InvalidOperation(
                            "aggregate/sort order_by nulls must be 'first' or 'last'; no fallback execution was attempted".into(),
                        )),
                    });
                }
                out.push(expression);
            }
            return Ok(Some(out));
        }
    }
    Ok(None)
}

fn json_optional_usize_field_any(
    object: &serde_json::Map<String, serde_json::Value>,
    fields: &[&str],
) -> Result<Option<usize>, ShardLoomError> {
    for field in fields {
        if let Some(value) = object.get(*field) {
            let Some(value) = value.as_u64() else {
                return Err(ShardLoomError::InvalidOperation(format!(
                    "field {field} must be a non-negative integer"
                )));
            };
            return usize::try_from(value).map(Some).map_err(|_| {
                ShardLoomError::InvalidOperation(format!("field {field} exceeded usize"))
            });
        }
    }
    Ok(None)
}

fn json_optional_i64_field_any(
    object: &serde_json::Map<String, serde_json::Value>,
    fields: &[&str],
) -> Result<Option<i64>, ShardLoomError> {
    for field in fields {
        if let Some(value) = object.get(*field) {
            return value.as_i64().map(Some).ok_or_else(|| {
                ShardLoomError::InvalidOperation(format!("field {field} must be an integer"))
            });
        }
    }
    Ok(None)
}

pub(crate) fn parse_expression_project_primitive_request(
    uri: impl Into<Option<DatasetUri>>,
    payload: &str,
) -> Result<shardloom_vortex::VortexQueryPrimitiveRequest, ShardLoomError> {
    let value = serde_json::from_str::<serde_json::Value>(payload).map_err(|error| {
        ShardLoomError::InvalidOperation(format!(
            "expression-project payload must be valid JSON: {error}"
        ))
    })?;
    let object = value.as_object().ok_or_else(|| {
        ShardLoomError::InvalidOperation(
            "expression-project payload must be a JSON object".to_string(),
        )
    })?;
    if object.contains_key("structured_columns") {
        let uri = uri.into().ok_or_else(|| ShardLoomError::InvalidOperation(
            "composed REWRITE admits flat scalar rewrites only; no fallback execution was attempted".into()
        ))?;
        return parse_structured_expression_project_primitive_request(uri, object);
    }
    let columns_value = object.get("columns").ok_or_else(|| {
        ShardLoomError::InvalidOperation(
            "expression-project payload requires a columns field".to_string(),
        )
    })?;
    let columns = match columns_value {
        serde_json::Value::String(value) => parse_projection_columns(value)?,
        serde_json::Value::Array(values) => {
            let mut columns = Vec::with_capacity(values.len());
            for value in values {
                let Some(column) = value.as_str() else {
                    return Err(ShardLoomError::InvalidOperation(
                        "expression-project columns array must contain strings".to_string(),
                    ));
                };
                columns.push(ColumnRef::new(column)?);
            }
            ProjectionRequest::columns(columns)
        }
        _ => {
            return Err(ShardLoomError::InvalidOperation(
                "expression-project columns field must be a string or string array".to_string(),
            ));
        }
    };
    let rewrites_value = object.get("rewrites").ok_or_else(|| {
        ShardLoomError::InvalidOperation(
            "expression-project payload requires a non-empty rewrites array".to_string(),
        )
    })?;
    let rewrites_array = rewrites_value.as_array().ok_or_else(|| {
        ShardLoomError::InvalidOperation(
            "expression-project rewrites field must be an array".to_string(),
        )
    })?;
    if rewrites_array.is_empty() {
        return Err(ShardLoomError::InvalidOperation(
            "expression-project rewrites array must not be empty".to_string(),
        ));
    }
    let mut rewrites = Vec::with_capacity(rewrites_array.len());
    for rewrite_value in rewrites_array {
        rewrites.push(parse_expression_project_rewrite(rewrite_value)?);
    }
    Ok(shardloom_vortex::VortexQueryPrimitiveRequest {
        source_uri: uri.into(),
        expression_projection: Some(VortexExpressionProjectionRequest::new(rewrites)),
        ..shardloom_vortex::VortexQueryPrimitiveRequest::for_relational_input(
            shardloom_vortex::VortexQueryPrimitiveKind::ExpressionProjectRows,
            columns,
        )
    })
}

fn parse_structured_expression_project_primitive_request(
    uri: DatasetUri,
    object: &serde_json::Map<String, serde_json::Value>,
) -> Result<shardloom_vortex::VortexQueryPrimitiveRequest, ShardLoomError> {
    let columns_value = object.get("structured_columns").ok_or_else(|| {
        ShardLoomError::InvalidOperation(
            "expression-project structured payload requires structured_columns".to_string(),
        )
    })?;
    let columns_array = columns_value.as_array().ok_or_else(|| {
        ShardLoomError::InvalidOperation(
            "expression-project structured_columns must be an array".to_string(),
        )
    })?;
    if columns_array.is_empty() {
        return Err(ShardLoomError::InvalidOperation(
            "expression-project structured_columns must not be empty".to_string(),
        ));
    }
    let mut columns = Vec::with_capacity(columns_array.len());
    for column in columns_array {
        columns.push(parse_structured_projection_column(column)?);
    }
    Ok(
        shardloom_vortex::VortexQueryPrimitiveRequest::structured_project_rows(
            uri,
            VortexStructuredProjectionRequest::new(columns),
        ),
    )
}

fn parse_structured_projection_column(
    value: &serde_json::Value,
) -> Result<VortexStructuredProjectionColumn, ShardLoomError> {
    let object = value.as_object().ok_or_else(|| {
        ShardLoomError::InvalidOperation(
            "expression-project structured column must be a JSON object".to_string(),
        )
    })?;
    let name = json_string_field_any(object, &["name", "alias", "output_column"])?.to_string();
    if object.get("source").is_some() || object.get("source_column").is_some() {
        let source = json_string_field_any(object, &["source", "source_column"])?;
        return Ok(VortexStructuredProjectionColumn::new(
            name,
            VortexStructuredProjectionExpr::SourceColumn(ColumnRef::new(source)?),
        ));
    }
    if let Some(array) = object.get("array").or_else(|| object.get("array_literal")) {
        let values = array.as_array().ok_or_else(|| {
            ShardLoomError::InvalidOperation(
                "expression-project structured array column requires an array literal".to_string(),
            )
        })?;
        let mut scalars = Vec::with_capacity(values.len());
        for (index, value) in values.iter().enumerate() {
            scalars.push(parse_structured_scalar(
                value,
                &format!("structured array literal element {index}"),
            )?);
        }
        return Ok(VortexStructuredProjectionColumn::new(
            name,
            VortexStructuredProjectionExpr::ArrayLiteral(scalars),
        ));
    }
    if let Some(struct_value) = object
        .get("struct")
        .or_else(|| object.get("struct_columns"))
    {
        let columns = match struct_value {
            serde_json::Value::String(value) => match parse_projection_columns(value)? {
                ProjectionRequest::All => {
                    return Err(ShardLoomError::InvalidOperation(
                        "expression-project structured struct column must name explicit source columns, not *"
                            .to_string(),
                    ));
                }
                ProjectionRequest::Columns(columns) => columns,
            },
            serde_json::Value::Array(values) => {
                let mut columns = Vec::with_capacity(values.len());
                for value in values {
                    let Some(column) = value.as_str() else {
                        return Err(ShardLoomError::InvalidOperation(
                            "expression-project structured struct array must contain strings"
                                .to_string(),
                        ));
                    };
                    columns.push(ColumnRef::new(column)?);
                }
                columns
            }
            _ => {
                return Err(ShardLoomError::InvalidOperation(
                    "expression-project structured struct column must be a string or string array"
                        .to_string(),
                ));
            }
        };
        if columns.is_empty() {
            return Err(ShardLoomError::InvalidOperation(
                "expression-project structured struct column requires at least one source column"
                    .to_string(),
            ));
        }
        return Ok(VortexStructuredProjectionColumn::new(
            name,
            VortexStructuredProjectionExpr::StructColumns(columns),
        ));
    }
    Err(ShardLoomError::InvalidOperation(
        "expression-project structured column requires source, array, or struct".to_string(),
    ))
}

fn parse_structured_scalar(
    value: &serde_json::Value,
    field: &str,
) -> Result<ScalarValue, ShardLoomError> {
    let value = parse_expression_scalar(value, field, NullScalarPolicy::Allow)?;
    if matches!(
        value,
        ScalarValue::Binary(_)
            | ScalarValue::Decimal128 { .. }
            | ScalarValue::Date32(_)
            | ScalarValue::TimestampMicros(_)
    ) {
        return Err(ShardLoomError::InvalidOperation(
            "structured scalar declarations require primitive literals; typed unary literals do not widen nested construction".into(),
        ));
    }
    Ok(value)
}

fn parse_expression_project_rewrite(
    value: &serde_json::Value,
) -> Result<VortexExpressionRewrite, ShardLoomError> {
    let object = value.as_object().ok_or_else(|| {
        ShardLoomError::InvalidOperation(
            "expression-project rewrite must be a JSON object".to_string(),
        )
    })?;
    let kind = json_string_field(object, "kind")?;
    let target = json_string_field_any(object, &["target_column", "target"])?;
    let target_column = ColumnRef::new(target)?;
    match kind.trim().to_ascii_lowercase().replace('-', "_").as_str() {
        "mask_scalar" | "mask" => parse_mask_scalar_rewrite(object, target_column),
        "replace_scalar" | "replace" => parse_replace_scalar_rewrite(object, target_column),
        "string_replace_scalar" | "string_replace" | "replace_substring" => {
            parse_string_replace_scalar_rewrite(object, target_column)
        }
        "regex_replace_scalar" | "regex_replace" | "replace_regex" => {
            parse_regex_replace_scalar_rewrite(object, target_column)
        }
        "numeric_scalar_arithmetic" | "numeric_arithmetic" | "arithmetic_scalar" => {
            parse_numeric_scalar_arithmetic_rewrite(object, target_column)
        }
        "forward_fill_null" | "ffill_null" | "fill_forward_null" | "pad_null" => {
            parse_forward_fill_null_rewrite(object, target_column)
        }
        "row_number" | "source_order_row_number" | "ordinal" => {
            parse_row_number_rewrite(object, target_column)
        }
        _ => Err(ShardLoomError::InvalidOperation(
            "expression-project rewrite kind must be mask_scalar, replace_scalar, string_replace_scalar, regex_replace_scalar, numeric_scalar_arithmetic, forward_fill_null, or row_number"
                .to_string(),
        )),
    }
}

fn parse_mask_scalar_rewrite(
    object: &serde_json::Map<String, serde_json::Value>,
    target_column: ColumnRef,
) -> Result<VortexExpressionRewrite, ShardLoomError> {
    let predicate = json_string_field(object, "predicate")?;
    let replacement = object.get("replacement").ok_or_else(|| {
        ShardLoomError::InvalidOperation(
            "mask_scalar rewrite requires a replacement scalar".to_string(),
        )
    })?;
    Ok(VortexExpressionRewrite::MaskScalar {
        target_column,
        predicate: parse_tiny_predicate(predicate)?,
        replacement: parse_expression_scalar(replacement, "replacement", NullScalarPolicy::Allow)?,
    })
}

fn parse_replace_scalar_rewrite(
    object: &serde_json::Map<String, serde_json::Value>,
    target_column: ColumnRef,
) -> Result<VortexExpressionRewrite, ShardLoomError> {
    let to_replace = object
        .get("to_replace")
        .or_else(|| object.get("old"))
        .ok_or_else(|| {
            ShardLoomError::InvalidOperation(
                "replace_scalar rewrite requires a to_replace scalar".to_string(),
            )
        })?;
    let replacement = object
        .get("replacement")
        .or_else(|| object.get("new"))
        .ok_or_else(|| {
            ShardLoomError::InvalidOperation(
                "replace_scalar rewrite requires a replacement scalar".to_string(),
            )
        })?;
    Ok(VortexExpressionRewrite::ReplaceScalar {
        target_column,
        to_replace: parse_expression_scalar(to_replace, "to_replace", NullScalarPolicy::Reject)?,
        replacement: parse_expression_scalar(replacement, "replacement", NullScalarPolicy::Allow)?,
    })
}

fn parse_string_replace_scalar_rewrite(
    object: &serde_json::Map<String, serde_json::Value>,
    target_column: ColumnRef,
) -> Result<VortexExpressionRewrite, ShardLoomError> {
    let needle = json_string_field_any(object, &["needle", "to_replace", "old"])?;
    if needle.is_empty() {
        return Err(ShardLoomError::InvalidOperation(
            "string_replace_scalar rewrite requires a non-empty needle".to_string(),
        ));
    }
    let replacement = json_string_field_any(object, &["replacement", "new"]).map(str::to_string)?;
    Ok(VortexExpressionRewrite::StringReplaceScalar {
        target_column,
        needle: needle.to_string(),
        replacement,
    })
}

fn parse_regex_replace_scalar_rewrite(
    object: &serde_json::Map<String, serde_json::Value>,
    target_column: ColumnRef,
) -> Result<VortexExpressionRewrite, ShardLoomError> {
    let pattern = json_string_field_any(object, &["pattern", "regex", "to_replace"])?;
    if pattern.is_empty() {
        return Err(ShardLoomError::InvalidOperation(
            "regex_replace_scalar rewrite requires a non-empty pattern".to_string(),
        ));
    }
    let replacement = json_string_field_any(object, &["replacement", "new"]).map(str::to_string)?;
    Ok(VortexExpressionRewrite::RegexReplaceScalar {
        target_column,
        pattern: pattern.to_string(),
        replacement,
    })
}

fn parse_numeric_scalar_arithmetic_rewrite(
    object: &serde_json::Map<String, serde_json::Value>,
    target_column: ColumnRef,
) -> Result<VortexExpressionRewrite, ShardLoomError> {
    let operator = json_string_field_any(object, &["operator", "op"])?.trim();
    if !matches!(operator, "+" | "-" | "*" | "/") {
        return Err(ShardLoomError::InvalidOperation(
            "numeric_scalar_arithmetic rewrite operator must be one of +, -, *, or /".to_string(),
        ));
    }
    let operand = object.get("operand").ok_or_else(|| {
        ShardLoomError::InvalidOperation(
            "numeric_scalar_arithmetic rewrite requires an operand scalar".to_string(),
        )
    })?;
    Ok(VortexExpressionRewrite::NumericScalarArithmetic {
        target_column,
        operator: operator.to_string(),
        operand: parse_expression_scalar(operand, "operand", NullScalarPolicy::Reject)?,
    })
}

fn parse_forward_fill_null_rewrite(
    object: &serde_json::Map<String, serde_json::Value>,
    target_column: ColumnRef,
) -> Result<VortexExpressionRewrite, ShardLoomError> {
    let limit = json_optional_usize_field_any(object, &["limit", "max_fill"])?;
    if limit == Some(0) {
        return Err(ShardLoomError::InvalidOperation(
            "forward_fill_null rewrite limit must be >= 1 when provided".to_string(),
        ));
    }
    Ok(VortexExpressionRewrite::ForwardFillNull {
        target_column,
        limit,
    })
}

fn parse_row_number_rewrite(
    object: &serde_json::Map<String, serde_json::Value>,
    target_column: ColumnRef,
) -> Result<VortexExpressionRewrite, ShardLoomError> {
    let start = json_optional_usize_field_any(object, &["start", "base", "offset"])?.unwrap_or(0);
    Ok(VortexExpressionRewrite::RowNumber {
        target_column,
        start: u64::try_from(start).map_err(|_| {
            ShardLoomError::InvalidOperation("row_number rewrite start exceeded u64".to_string())
        })?,
    })
}

fn json_string_field<'a>(
    object: &'a serde_json::Map<String, serde_json::Value>,
    field: &str,
) -> Result<&'a str, ShardLoomError> {
    json_string_field_any(object, &[field])
}

fn json_column_array_field_any(
    object: &serde_json::Map<String, serde_json::Value>,
    fields: &[&str],
) -> Result<Vec<ColumnRef>, ShardLoomError> {
    for field in fields {
        if let Some(value) = object.get(*field) {
            return match value {
                serde_json::Value::String(value) => match parse_projection_columns(value)? {
                    ProjectionRequest::All => Err(ShardLoomError::InvalidOperation(format!(
                        "melt field {field} must name explicit columns, not *"
                    ))),
                    ProjectionRequest::Columns(columns) => Ok(columns),
                },
                serde_json::Value::Array(values) => {
                    let mut columns = Vec::with_capacity(values.len());
                    for value in values {
                        let Some(column) = value.as_str() else {
                            return Err(ShardLoomError::InvalidOperation(format!(
                                "melt field {field} array must contain strings"
                            )));
                        };
                        columns.push(ColumnRef::new(column)?);
                    }
                    Ok(columns)
                }
                _ => Err(ShardLoomError::InvalidOperation(format!(
                    "melt field {field} must be a string or string array"
                ))),
            };
        }
    }
    Err(ShardLoomError::InvalidOperation(format!(
        "melt payload missing required field {}",
        fields.join("/")
    )))
}

fn json_usize_field_any(
    object: &serde_json::Map<String, serde_json::Value>,
    fields: &[&str],
) -> Result<usize, ShardLoomError> {
    for field in fields {
        if let Some(value) = object.get(*field) {
            if let Some(number) = value.as_u64() {
                return usize::try_from(number).map_err(|_| {
                    ShardLoomError::InvalidOperation(format!(
                        "rolling field {field} is too large for this platform"
                    ))
                });
            }
            if let Some(text) = value.as_str() {
                return text.parse::<usize>().map_err(|error| {
                    ShardLoomError::InvalidOperation(format!(
                        "rolling field {field} must be a non-negative integer: {error}"
                    ))
                });
            }
            return Err(ShardLoomError::InvalidOperation(format!(
                "rolling field {field} must be an integer or integer string"
            )));
        }
    }
    Err(ShardLoomError::InvalidOperation(format!(
        "rolling payload missing required field {}",
        fields.join("/")
    )))
}

fn json_optional_bool_field_any(
    object: &serde_json::Map<String, serde_json::Value>,
    fields: &[&str],
) -> Result<Option<bool>, ShardLoomError> {
    for field in fields {
        if let Some(value) = object.get(*field) {
            if let Some(value) = value.as_bool() {
                return Ok(Some(value));
            }
            if let Some(text) = value.as_str() {
                return match text.trim().to_ascii_lowercase().as_str() {
                    "true" => Ok(Some(true)),
                    "false" => Ok(Some(false)),
                    _ => Err(ShardLoomError::InvalidOperation(format!(
                        "field {field} must be a boolean"
                    ))),
                };
            }
            return Err(ShardLoomError::InvalidOperation(format!(
                "field {field} must be a boolean"
            )));
        }
    }
    Ok(None)
}

fn json_optional_scalar_value_field_any(
    object: &serde_json::Map<String, serde_json::Value>,
    fields: &[&str],
) -> Result<Option<ScalarValue>, ShardLoomError> {
    for field in fields {
        if let Some(value) = object.get(*field) {
            return json_scalar_value(value, field).map(Some);
        }
    }
    Ok(None)
}

fn json_scalar_value(
    value: &serde_json::Value,
    field: &str,
) -> Result<ScalarValue, ShardLoomError> {
    if value.is_object() {
        return parse_expression_scalar(value, field, NullScalarPolicy::Allow);
    }
    match value {
        serde_json::Value::Null => Ok(ScalarValue::Null),
        serde_json::Value::Bool(value) => Ok(ScalarValue::Boolean(*value)),
        serde_json::Value::Number(value) => {
            if let Some(value) = value.as_i64() {
                Ok(ScalarValue::Int64(value))
            } else if let Some(value) = value.as_u64() {
                Ok(ScalarValue::UInt64(value))
            } else if let Some(value) = value.as_f64() {
                if value.is_finite() {
                    Ok(ScalarValue::Float64(value))
                } else {
                    Err(ShardLoomError::InvalidOperation(format!(
                        "field {field} must be a finite scalar"
                    )))
                }
            } else {
                Err(ShardLoomError::InvalidOperation(format!(
                    "field {field} must be a scalar fill value"
                )))
            }
        }
        serde_json::Value::String(value) => Ok(ScalarValue::Utf8(value.clone())),
        serde_json::Value::Array(_) | serde_json::Value::Object(_) => {
            Err(ShardLoomError::InvalidOperation(format!(
                "field {field} supports only scalar fill values"
            )))
        }
    }
}

fn json_optional_string_field_any<'a>(
    object: &'a serde_json::Map<String, serde_json::Value>,
    fields: &[&str],
) -> Result<Option<&'a str>, ShardLoomError> {
    for field in fields {
        if let Some(value) = object.get(*field) {
            return value
                .as_str()
                .filter(|value| !value.trim().is_empty())
                .map(Some)
                .ok_or_else(|| {
                    ShardLoomError::InvalidOperation(format!(
                        "field {field} must be a non-empty string"
                    ))
                });
        }
    }
    Ok(None)
}

fn json_string_field_any<'a>(
    object: &'a serde_json::Map<String, serde_json::Value>,
    fields: &[&str],
) -> Result<&'a str, ShardLoomError> {
    for field in fields {
        if let Some(value) = object.get(*field) {
            return value
                .as_str()
                .filter(|value| !value.trim().is_empty())
                .ok_or_else(|| {
                    ShardLoomError::InvalidOperation(format!(
                        "expression-project field {field} must be a non-empty string"
                    ))
                });
        }
    }
    Err(ShardLoomError::InvalidOperation(format!(
        "expression-project payload missing required field {}",
        fields.join("/")
    )))
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum NullScalarPolicy {
    Allow,
    Reject,
}

fn parse_expression_scalar(
    value: &serde_json::Value,
    field: &str,
    null_policy: NullScalarPolicy,
) -> Result<ScalarValue, ShardLoomError> {
    if let Some(object) = value.as_object() {
        let raw_dtype = json_string_field(object, "type")?.trim();
        let dtype = shardloom_core::temporal::TemporalDType::parse_declaration(raw_dtype)
            .map_or_else(
                || raw_dtype.to_ascii_lowercase().replace('-', "_"),
                |dtype| dtype.as_str().to_owned(),
            );
        let Some(raw) = object.get("value") else {
            return Err(ShardLoomError::InvalidOperation(format!(
                "expression-project scalar {field} requires a value"
            )));
        };
        return parse_typed_expression_scalar(&dtype, raw, field, null_policy);
    }
    parse_untyped_expression_scalar(value, field, null_policy)
}

fn parse_typed_expression_scalar(
    dtype: &str,
    value: &serde_json::Value,
    field: &str,
    null_policy: NullScalarPolicy,
) -> Result<ScalarValue, ShardLoomError> {
    match dtype {
        "null" => {
            if null_policy == NullScalarPolicy::Reject {
                return Err(ShardLoomError::InvalidOperation(format!(
                    "expression-project scalar {field} does not admit null"
                )));
            }
            if value.is_null() {
                Ok(ScalarValue::Null)
            } else {
                Err(ShardLoomError::InvalidOperation(format!(
                    "expression-project scalar {field} null value must be JSON null"
                )))
            }
        }
        "boolean" | "bool" => value.as_bool().map(ScalarValue::Boolean).ok_or_else(|| {
            ShardLoomError::InvalidOperation(format!(
                "expression-project scalar {field} boolean value must be true or false"
            ))
        }),
        "int64" | "int" | "integer" => value.as_i64().map(ScalarValue::Int64).ok_or_else(|| {
            ShardLoomError::InvalidOperation(format!(
                "expression-project scalar {field} int64 value must be an integer"
            ))
        }),
        "uint64" | "uint" | "unsigned" => {
            value.as_u64().map(ScalarValue::UInt64).ok_or_else(|| {
                ShardLoomError::InvalidOperation(format!(
                    "expression-project scalar {field} uint64 value must be a non-negative integer"
                ))
            })
        }
        "float64" | "float" | "double" => value
            .as_f64()
            .filter(|value| value.is_finite())
            .map(ScalarValue::Float64)
            .ok_or_else(|| {
                ShardLoomError::InvalidOperation(format!(
                    "expression-project scalar {field} float64 value must be finite"
                ))
            }),
        "utf8" | "string" | "str" => value
            .as_str()
            .map(|value| ScalarValue::Utf8(value.to_string()))
            .ok_or_else(|| {
                ShardLoomError::InvalidOperation(format!(
                    "expression-project scalar {field} utf8 value must be a string"
                ))
            }),
        _ => parse_exact_expression_scalar(dtype, value, field),
    }
}

fn parse_exact_expression_scalar(
    dtype: &str,
    value: &serde_json::Value,
    field: &str,
) -> Result<ScalarValue, ShardLoomError> {
    use shardloom_core::expression::{
        decimal128_dtype_parts, decode_hex_bytes, parse_decimal128_text, parse_iso_date32,
        parse_iso_timestamp_micros,
    };
    let decimal = decimal128_dtype_parts(&shardloom_core::LogicalDType::Extension(dtype.into()));
    let temporal = shardloom_core::temporal::TemporalDType::parse(dtype);
    if dtype != "binary" && temporal.is_none() && decimal.is_none() {
        return Err(ShardLoomError::InvalidOperation(format!(
            "expression-project scalar {field} has unsupported type {dtype}"
        )));
    }
    let raw = value.as_str().ok_or_else(|| {
        ShardLoomError::InvalidOperation(format!(
            "expression-project scalar {field} {dtype} value must be exact text"
        ))
    })?;
    let invalid = |reason: String| {
        ShardLoomError::InvalidOperation(format!(
            "expression-project scalar {field} {dtype}: {reason}"
        ))
    };
    match dtype {
        "binary" => decode_hex_bytes(raw)
            .map(ScalarValue::Binary)
            .map_err(|reason| invalid(reason.into())),
        "date32" => raw
            .parse::<i32>()
            .map(ScalarValue::Date32)
            .or_else(|_| parse_iso_date32(raw).map(ScalarValue::Date32))
            .map_err(|reason| invalid(reason.to_string())),
        "timestamp_micros" => raw
            .parse::<i64>()
            .map(ScalarValue::TimestampMicros)
            .or_else(|_| parse_iso_timestamp_micros(raw).map(ScalarValue::TimestampMicros))
            .map_err(|reason| invalid(reason.to_string())),
        _ if temporal.is_some() => {
            use shardloom_core::temporal::{TemporalValue, text::TemporalTextCodec};
            let dtype = temporal.expect("admitted temporal type");
            if let Ok(ticks) = raw.parse::<i64>() {
                TemporalValue::new(ticks, dtype).map(TemporalValue::into_scalar)
            } else {
                TemporalTextCodec::new(dtype)?.parse_scalar(raw)
            }
            .map_err(|reason| invalid(reason.to_string()))
        }
        _ => {
            let (precision, scale) = decimal.expect("admitted decimal type above");
            parse_decimal128_text(raw, precision, scale)
                .map(|value| ScalarValue::Decimal128 {
                    value,
                    precision,
                    scale,
                })
                .map_err(invalid)
        }
    }
}

fn parse_untyped_expression_scalar(
    value: &serde_json::Value,
    field: &str,
    null_policy: NullScalarPolicy,
) -> Result<ScalarValue, ShardLoomError> {
    match value {
        serde_json::Value::Null => {
            if null_policy == NullScalarPolicy::Allow {
                Ok(ScalarValue::Null)
            } else {
                Err(ShardLoomError::InvalidOperation(format!(
                    "expression-project scalar {field} does not admit null"
                )))
            }
        }
        serde_json::Value::Bool(value) => Ok(ScalarValue::Boolean(*value)),
        serde_json::Value::Number(value) => {
            if let Some(value) = value.as_i64() {
                Ok(ScalarValue::Int64(value))
            } else if let Some(value) = value.as_u64() {
                Ok(ScalarValue::UInt64(value))
            } else if let Some(value) = value.as_f64().filter(|value| value.is_finite()) {
                Ok(ScalarValue::Float64(value))
            } else {
                Err(ShardLoomError::InvalidOperation(format!(
                    "expression-project scalar {field} numeric value must be finite"
                )))
            }
        }
        serde_json::Value::String(value) => Ok(ScalarValue::Utf8(value.clone())),
        _ => Err(ShardLoomError::InvalidOperation(format!(
            "expression-project scalar {field} must be a typed scalar object, null, boolean, finite number, or string"
        ))),
    }
}

fn prefixed_predicate_columns<'a>(
    value: &'a str,
    prefixes: &[&str],
    label: &str,
) -> Result<Option<(&'a str, &'a str)>, ShardLoomError> {
    for prefix in prefixes {
        if let Some(remainder) = value.strip_prefix(prefix) {
            let Some((predicate, columns)) = remainder.split_once('|') else {
                return Err(ShardLoomError::InvalidOperation(format!(
                    "{label} requires <predicate>|<columns>"
                )));
            };
            if predicate.is_empty() {
                return Err(ShardLoomError::InvalidOperation(format!(
                    "{label} predicate must not be empty"
                )));
            }
            if columns.is_empty() {
                return Err(ShardLoomError::InvalidOperation(format!(
                    "{label} columns must not be empty"
                )));
            }
            return Ok(Some((predicate, columns)));
        }
    }
    Ok(None)
}

fn prefixed_predicate_columns_payload<'a>(
    value: &'a str,
    prefixes: &[&str],
    label: &str,
) -> Result<Option<(&'a str, &'a str, &'a str)>, ShardLoomError> {
    for prefix in prefixes {
        if let Some(remainder) = value.strip_prefix(prefix) {
            let mut parts = remainder.splitn(3, '|');
            let predicate = parts.next().unwrap_or_default();
            let columns = parts.next().unwrap_or_default();
            let payload = parts.next().unwrap_or_default();
            if predicate.is_empty() || columns.is_empty() || payload.is_empty() {
                return Err(ShardLoomError::InvalidOperation(format!(
                    "{label} requires <predicate>|<columns>|<payload>"
                )));
            }
            return Ok(Some((predicate, columns, payload)));
        }
    }
    Ok(None)
}

pub(crate) fn build_vortex_encoded_count_readiness(
    uri: DatasetUri,
    resources: ExecutionResources,
) -> shardloom_core::Result<shardloom_vortex::VortexEncodedReadReadinessReport> {
    let source = shardloom_core::UniversalInputSource::from_dataset_uri(uri)?;
    let input_plan = plan_native_vortex_universal_input(source)?;
    let read_report = plan_vortex_read_from_universal_input(input_plan)?;
    let runtime_report = build_vortex_runtime_task_graph(read_report)?;
    let sizing_report = size_vortex_runtime_task_graph(
        runtime_report,
        AdaptiveSizingPolicy::memory_limited(ByteSize::from_bytes(resources.memory_bytes())),
    )?;
    let budget = MemoryBudget::new(ByteSize::from_bytes(resources.memory_bytes()))?;
    let memory_report = plan_vortex_memory_safety(sizing_report, budget)?;
    let mut scheduler_report =
        plan_vortex_scheduler_queue(memory_report, resources.max_parallelism())?;
    if scheduler_report.scheduled_task_count == 0 {
        scheduler_report
            .decisions
            .push(VortexTaskSchedulingDecision::schedule_now(
                None,
                "approved local encoded count execution",
            ));
        scheduler_report.recompute_counts();
    }
    evaluate_vortex_encoded_read_readiness(scheduler_report)
}

pub(crate) fn run_vortex_approved_local_encoded_count_from_readiness(
    uri: DatasetUri,
    readiness_report: &shardloom_vortex::VortexEncodedReadReadinessReport,
) -> shardloom_core::Result<(
    shardloom_vortex::VortexEncodedReadExecutionReport,
    VortexLocalExecutionReport,
)> {
    run_vortex_approved_local_encoded_count_with_admission(uri, readiness_report, None)
}

fn run_vortex_approved_local_encoded_count_with_admission(
    uri: DatasetUri,
    readiness_report: &shardloom_vortex::VortexEncodedReadReadinessReport,
    admission: Option<&CommandAdmission<'_>>,
) -> shardloom_core::Result<(
    shardloom_vortex::VortexEncodedReadExecutionReport,
    VortexLocalExecutionReport,
)> {
    if let Some(admission) = admission {
        admission.check()?;
    }
    let count_report = plan_vortex_count_readiness(
        VortexCountReadinessRequest::new(uri, VortexCountCandidateSource::EncodedDataPath)
            .feature_gate_enabled(true)
            .query_primitive_ready(true)
            .count_primitive(true)
            .encoded_data_path_ready(true),
    )?;
    let approval = plan_vortex_encoded_count_data_path_approval(
        count_report,
        vortex_encoded_read_local_scan_count_api_boundary(),
    )?;
    #[cfg(all(
        feature = "vortex-encoded-read-spike",
        feature = "vortex-local-primitives",
        unix
    ))]
    let report = if let Some(admission) = admission {
        shardloom_vortex::encoded_read_executor::execute_vortex_count_all_from_approved_local_scan_in_session(
            &approval, readiness_report, admission.native_session()?, &admission.cancellation(),
        )?
    } else {
        execute_vortex_count_all_from_approved_local_scan(&approval, readiness_report)?
    };
    #[cfg(not(all(
        feature = "vortex-encoded-read-spike",
        feature = "vortex-local-primitives",
        unix
    )))]
    let report = execute_vortex_count_all_from_approved_local_scan(&approval, readiness_report)?;
    if let Some(admission) = admission {
        admission.check()?;
    }
    let local_execution_report =
        execute_vortex_count_all_from_approved_local_scan_result(&approval, &report)?;
    Ok((report, local_execution_report))
}

pub(crate) fn run_vortex_approved_local_encoded_count(
    uri: DatasetUri,
    resources: ExecutionResources,
) -> shardloom_core::Result<(
    shardloom_vortex::VortexEncodedReadExecutionReport,
    VortexLocalExecutionReport,
)> {
    let readiness_report = build_vortex_encoded_count_readiness(uri.clone(), resources)?;
    run_vortex_approved_local_encoded_count_from_readiness(uri, &readiness_report)
}

pub(crate) fn build_vortex_count_local_streaming_batch_plan(
    uri: DatasetUri,
    resources: ExecutionResources,
) -> shardloom_core::Result<EncodedStreamingBatchPlanReport> {
    let dataset = DatasetRef::from_uri(uri)?;
    let input = EncodedStreamingBatchPlanInput::new(
        StreamingSource::vortex_dataset(dataset),
        StreamingSink::null_benchmark(),
        BoundedMemoryPolicy::required(ByteSize::from_bytes(resources.memory_bytes())),
        resources.max_parallelism(),
    )?;
    plan_encoded_streaming_batches(input)
}

pub(crate) struct VortexCountLocalEncodedEvidence {
    pub(crate) target_policy: VortexCountLocalEncodedTargetPolicy,
    pub(crate) fixture_id: Option<String>,
    pub(crate) fixture_source_ref: Option<String>,
    pub(crate) native_io_certificate: Option<NativeIoCertificate>,
    pub(crate) certificate: Option<ExecutionCertificate>,
    pub(crate) physical_kernel: Option<VortexEncodedCountPhysicalKernelReport>,
    pub(crate) kernel_admission: Option<VortexEncodedCountKernelAdmissionReport>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum VortexCountLocalEncodedTargetPolicy {
    KnownFixtureCertified,
    LocalVortexUncertified,
    Blocked,
}

impl VortexCountLocalEncodedTargetPolicy {
    const fn as_str(self) -> &'static str {
        match self {
            Self::KnownFixtureCertified => "known_fixture_certified",
            Self::LocalVortexUncertified => "local_vortex_uncertified",
            Self::Blocked => "blocked",
        }
    }

    const fn reason(self) -> &'static str {
        match self {
            Self::KnownFixtureCertified => {
                "target matches the repository encoded CountAll correctness fixture and has certified execution evidence"
            }
            Self::LocalVortexUncertified => {
                "target is an approved local .vortex CountAll execution but lacks fixture correctness and benchmark certification"
            }
            Self::Blocked => {
                "target does not have successful side-effect-free local encoded CountAll execution evidence"
            }
        }
    }

    const fn execution_allowed(self) -> bool {
        matches!(
            self,
            Self::KnownFixtureCertified | Self::LocalVortexUncertified
        )
    }

    const fn non_fixture_target(self) -> bool {
        matches!(self, Self::LocalVortexUncertified)
    }
}

impl VortexCountLocalEncodedEvidence {
    fn unavailable(
        encoded_report: &shardloom_vortex::VortexEncodedReadExecutionReport,
        local_report: &VortexLocalExecutionReport,
    ) -> shardloom_core::Result<Self> {
        let target_policy =
            if local_encoded_count_target_execution_allowed(encoded_report, local_report) {
                VortexCountLocalEncodedTargetPolicy::LocalVortexUncertified
            } else {
                VortexCountLocalEncodedTargetPolicy::Blocked
            };
        let native_io_certificate = target_policy
            .execution_allowed()
            .then(|| local_encoded_count_native_io_certificate(encoded_report, local_report))
            .transpose()?;
        Ok(Self {
            target_policy,
            fixture_id: None,
            fixture_source_ref: None,
            native_io_certificate,
            certificate: None,
            physical_kernel: None,
            kernel_admission: None,
        })
    }

    fn from_fixture(
        fixture: &CorrectnessFixture,
        native_io_certificate: NativeIoCertificate,
        certificate: ExecutionCertificate,
        physical_kernel: VortexEncodedCountPhysicalKernelReport,
        kernel_admission: VortexEncodedCountKernelAdmissionReport,
    ) -> Self {
        let target_policy = if certificate.is_certified() {
            VortexCountLocalEncodedTargetPolicy::KnownFixtureCertified
        } else {
            VortexCountLocalEncodedTargetPolicy::Blocked
        };
        Self {
            target_policy,
            fixture_id: Some(fixture.id.as_str().to_string()),
            fixture_source_ref: fixture.source_ref.clone(),
            native_io_certificate: Some(native_io_certificate),
            certificate: Some(certificate),
            physical_kernel: Some(physical_kernel),
            kernel_admission: Some(kernel_admission),
        }
    }

    pub(crate) fn has_errors(&self) -> bool {
        self.target_policy == VortexCountLocalEncodedTargetPolicy::Blocked
            || self
                .native_io_certificate
                .as_ref()
                .is_some_and(NativeIoCertificate::has_errors)
            || self
                .certificate
                .as_ref()
                .is_some_and(|certificate| !certificate.is_certified())
            || self
                .physical_kernel
                .as_ref()
                .is_some_and(VortexEncodedCountPhysicalKernelReport::has_errors)
            || self
                .kernel_admission
                .as_ref()
                .is_some_and(VortexEncodedCountKernelAdmissionReport::has_errors)
    }

    pub(crate) fn diagnostics(&self) -> Vec<shardloom_core::Diagnostic> {
        let mut diagnostics = Vec::new();
        if let Some(native_io_certificate) = &self.native_io_certificate {
            diagnostics.extend(native_io_certificate.diagnostics.clone());
        }
        if let Some(certificate) = &self.certificate {
            diagnostics.extend(certificate.diagnostics.clone());
        }
        if let Some(physical_kernel) = &self.physical_kernel {
            diagnostics.extend(physical_kernel.diagnostics.clone());
        }
        if let Some(kernel_admission) = &self.kernel_admission {
            diagnostics.extend(kernel_admission.diagnostics.clone());
        }
        diagnostics
    }

    pub(crate) fn human_sections(&self) -> Vec<String> {
        let mut sections = vec![format!(
            "Vortex local encoded CountAll target policy\npolicy: {}\nreason: {}\nexecution allowed: {}\ncorrectness certified: {}\nproduction claim allowed: false\nCG-2 closeout allowed: false\nCG-13 closeout allowed: false",
            self.target_policy.as_str(),
            self.target_policy.reason(),
            self.target_policy.execution_allowed(),
            self.certificate
                .as_ref()
                .is_some_and(ExecutionCertificate::is_certified)
        )];
        if let Some(native_io_certificate) = &self.native_io_certificate {
            sections.push(local_count_native_io_certificate_human_text(
                native_io_certificate,
            ));
        }
        if let Some(certificate) = &self.certificate {
            sections.push(certificate.to_human_text());
        }
        if let Some(physical_kernel) = &self.physical_kernel {
            sections.push(physical_kernel.to_human_text());
        }
        if let Some(kernel_admission) = &self.kernel_admission {
            sections.push(kernel_admission.to_human_text());
        }
        sections
    }
}

pub(crate) fn vortex_count_local_encoded_evidence(
    encoded_report: &shardloom_vortex::VortexEncodedReadExecutionReport,
    local_report: &VortexLocalExecutionReport,
) -> shardloom_core::Result<VortexCountLocalEncodedEvidence> {
    let Some(fixture) = local_encoded_count_correctness_fixture_for_report(encoded_report) else {
        return VortexCountLocalEncodedEvidence::unavailable(encoded_report, local_report);
    };
    let native_io_certificate =
        local_encoded_count_native_io_certificate(encoded_report, local_report)?;
    let certificate =
        local_encoded_count_execution_certificate(&fixture, encoded_report, local_report)?;
    let physical_kernel = evaluate_vortex_local_encoded_count_physical_kernel(
        encoded_report,
        local_report,
        &certificate,
    );
    let kernel_admission = admit_vortex_encoded_count_kernel(&physical_kernel)?;
    Ok(VortexCountLocalEncodedEvidence::from_fixture(
        &fixture,
        native_io_certificate,
        certificate,
        physical_kernel,
        kernel_admission,
    ))
}

fn local_encoded_count_target_execution_allowed(
    encoded_report: &shardloom_vortex::VortexEncodedReadExecutionReport,
    local_report: &VortexLocalExecutionReport,
) -> bool {
    let count_result_matches = encoded_report
        .count_result
        .is_some_and(|count| encoded_report.rows_counted == count);
    encoded_report.feature_status == VortexEncodedReadExecutorFeatureStatus::Enabled
        && encoded_report.status == VortexEncodedReadExecutionStatus::LocalScanEncodedCountExecuted
        && encoded_report.mode == VortexEncodedReadExecutionMode::LocalScanEncodedArrayLengthCount
        && !encoded_report.has_errors()
        && encoded_report.data_read
        && encoded_report.upstream_scan_called
        && !encoded_report.data_decoded
        && !encoded_report.data_materialized
        && !encoded_report.row_read
        && !encoded_report.arrow_converted
        && !encoded_report.object_store_io
        && !encoded_report.write_io
        && !encoded_report.spill_io_performed
        && !encoded_report.external_effects_executed
        && !encoded_report.fallback_execution_allowed
        && encoded_report.local_scan_source_uri_matches_target
        && encoded_report.local_scan_target_uri.is_some()
        && encoded_report.local_scan_readiness_source_uri == encoded_report.local_scan_target_uri
        && count_result_matches
        && local_report.status == VortexLocalExecutionStatus::LocalEncodedCountExecuted
        && !local_report.has_errors()
        && local_report.tasks_executed
        && local_report.data_read
        && !local_report.data_decoded
        && !local_report.data_materialized
        && !local_report.object_store_io
        && !local_report.write_io
        && !local_report.spill_io_performed
        && !local_report.external_effects_executed
        && !local_report.fallback_execution_allowed
}

fn local_encoded_count_correctness_fixture_for_report(
    encoded_report: &shardloom_vortex::VortexEncodedReadExecutionReport,
) -> Option<CorrectnessFixture> {
    if !encoded_report.local_scan_source_uri_matches_target {
        return None;
    }
    let target_uri = encoded_report.local_scan_target_uri.as_ref()?;
    local_encoded_count_correctness_fixture_for_target(target_uri)
}

pub(crate) fn local_encoded_count_correctness_fixture_for_target(
    target_uri: &DatasetUri,
) -> Option<CorrectnessFixture> {
    CorrectnessValidationPlan::default_foundation_plan()
        .fixtures
        .into_iter()
        .find(|fixture| {
            matches!(fixture.expected, ExpectedOutcome::EncodedCount { .. })
                && fixture
                    .source_ref
                    .as_deref()
                    .is_some_and(|source_ref| local_fixture_ref_matches(target_uri, source_ref))
        })
}

fn local_foundation_fixture_for_target(
    target_uri: &DatasetUri,
    fixture_id: &str,
) -> Option<CorrectnessFixture> {
    CorrectnessValidationPlan::default_foundation_plan()
        .fixtures
        .into_iter()
        .find(|fixture| {
            fixture.id.as_str() == fixture_id
                && fixture
                    .source_ref
                    .as_deref()
                    .is_some_and(|source_ref| local_fixture_ref_matches(target_uri, source_ref))
        })
}

pub(crate) fn local_primitive_correctness_fixture_for_request(
    request: &VortexQueryPrimitiveRequest,
    report: &shardloom_vortex::VortexLocalPrimitiveExecutionReport,
) -> Option<CorrectnessFixture> {
    if request.kind != report.primitive_kind
        || report.status != shardloom_vortex::VortexLocalPrimitiveExecutionStatus::Executed
        || report.has_errors()
    {
        return None;
    }
    match request.kind {
        shardloom_vortex::VortexQueryPrimitiveKind::CountAll => request
            .source_uri
            .as_ref()
            .and_then(local_encoded_count_correctness_fixture_for_target),
        shardloom_vortex::VortexQueryPrimitiveKind::CountWhere => local_primitive_fixture_if(
            request,
            local_struct_value_gte_three_predicate(request)
                && local_struct_no_source_order_limit(request),
            "vortex-local-count-where-struct-five",
        ),
        shardloom_vortex::VortexQueryPrimitiveKind::ProjectColumns => local_primitive_fixture_if(
            request,
            local_struct_metric_projection(request) && local_struct_no_source_order_limit(request),
            "vortex-local-project-struct-five",
        ),
        shardloom_vortex::VortexQueryPrimitiveKind::FilterPredicate => local_primitive_fixture_if(
            request,
            local_struct_value_gte_three_predicate(request)
                && local_struct_no_source_order_limit(request),
            "vortex-local-filter-struct-five",
        ),
        shardloom_vortex::VortexQueryPrimitiveKind::FilterAndProject => {
            if local_struct_value_gte_three_predicate(request)
                && local_struct_metric_projection(request)
                && local_struct_source_order_limit(request, 2)
            {
                local_primitive_fixture_if(
                    request,
                    true,
                    "vortex-local-filter-project-limit-struct-five",
                )
            } else {
                local_primitive_fixture_if(
                    request,
                    local_struct_value_gte_three_predicate(request)
                        && local_struct_metric_projection(request)
                        && local_struct_no_source_order_limit(request),
                    "vortex-local-filter-project-struct-five",
                )
            }
        }
        shardloom_vortex::VortexQueryPrimitiveKind::DistinctRows
        | shardloom_vortex::VortexQueryPrimitiveKind::DropDuplicateRows
        | shardloom_vortex::VortexQueryPrimitiveKind::DuplicateMaskRows
        | shardloom_vortex::VortexQueryPrimitiveKind::TailRows
        | shardloom_vortex::VortexQueryPrimitiveKind::SampleRows
        | shardloom_vortex::VortexQueryPrimitiveKind::ExpressionProjectRows
        | shardloom_vortex::VortexQueryPrimitiveKind::MeltRows
        | shardloom_vortex::VortexQueryPrimitiveKind::ExplodeRows
        | shardloom_vortex::VortexQueryPrimitiveKind::PivotRows
        | shardloom_vortex::VortexQueryPrimitiveKind::RollingWindowRows
        | shardloom_vortex::VortexQueryPrimitiveKind::SimpleAggregate
        | shardloom_vortex::VortexQueryPrimitiveKind::SortRows
        | shardloom_vortex::VortexQueryPrimitiveKind::Unsupported => None,
    }
}

fn local_primitive_fixture_if(
    request: &VortexQueryPrimitiveRequest,
    matches_fixture_shape: bool,
    fixture_id: &str,
) -> Option<CorrectnessFixture> {
    matches_fixture_shape
        .then_some(request.source_uri.as_ref())
        .flatten()
        .and_then(|source_uri| local_foundation_fixture_for_target(source_uri, fixture_id))
}

fn local_struct_value_gte_three_predicate(request: &VortexQueryPrimitiveRequest) -> bool {
    matches!(
        request.predicate.as_ref(),
        Some(PredicateExpr::Compare {
            column,
            op: ComparisonOp::GtEq,
            value: StatValue::Int64(3)
        }) if column.as_str() == "value"
    )
}

fn local_struct_metric_projection(request: &VortexQueryPrimitiveRequest) -> bool {
    matches!(
        &request.projection,
        ProjectionRequest::Columns(columns)
            if columns.len() == 1 && columns[0].as_str() == "metric"
    )
}

fn local_struct_source_order_limit(request: &VortexQueryPrimitiveRequest, limit: usize) -> bool {
    request.source_order_limit == Some(limit)
}

fn local_struct_no_source_order_limit(request: &VortexQueryPrimitiveRequest) -> bool {
    request.source_order_limit.is_none()
}

fn local_fixture_ref_matches(target_uri: &DatasetUri, source_ref: &str) -> bool {
    let Some(target_ref) = canonical_local_fixture_ref(target_uri.as_str()) else {
        return false;
    };
    let Some(workspace_source_ref) = canonical_workspace_fixture_ref(source_ref) else {
        return false;
    };
    target_ref == workspace_source_ref
}

fn canonical_workspace_fixture_ref(source_ref: &str) -> Option<String> {
    let source_ref = normalized_local_fixture_ref(source_ref);
    let source_path = std::path::Path::new(&source_ref);
    let absolute = if source_path.is_absolute() {
        source_path.to_path_buf()
    } else {
        workspace_root().join(source_path)
    };
    canonical_path_string(&absolute)
}

fn canonical_local_fixture_ref(value: &str) -> Option<String> {
    let target_ref = normalized_local_fixture_ref(value);
    let target_path = std::path::Path::new(&target_ref);
    let absolute = if target_path.is_absolute() {
        target_path.to_path_buf()
    } else {
        workspace_root().join(target_path)
    };
    canonical_path_string(&absolute)
}

fn workspace_root() -> std::path::PathBuf {
    std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("workspace root")
        .to_path_buf()
}

fn canonical_path_string(path: &std::path::Path) -> Option<String> {
    path.canonicalize()
        .ok()
        .map(|path| path.to_string_lossy().replace('\\', "/"))
}

fn normalized_local_fixture_ref(value: &str) -> String {
    let without_fragment = value
        .split_once(['?', '#'])
        .map_or(value, |(prefix, _)| prefix);
    let without_scheme = without_fragment
        .strip_prefix("file:///")
        .or_else(|| without_fragment.strip_prefix("file://"))
        .unwrap_or(without_fragment);
    without_scheme
        .replace('\\', "/")
        .trim_start_matches("./")
        .to_string()
}

fn local_count_native_io_certificate_human_text(certificate: &NativeIoCertificate) -> String {
    format!(
        "Vortex local encoded CountAll Native I/O certificate\ncertificate: {}\npath: {}\nstatus: {}\nsource adapter: {}\npushdown guarantee: {}\nrepresentation transitions: {}\nmaterialization boundaries: {}\nfallback execution allowed: {}",
        certificate.certificate_id,
        certificate.path_id,
        certificate.status(),
        certificate.source_capability_report.adapter_id,
        certificate.source_pushdown_report.guarantee,
        certificate.representation_transition_order(),
        certificate.materialization_boundary_order(),
        certificate.side_effects.fallback_execution_allowed
    )
}

fn local_primitive_native_io_certificate_human_text(certificate: &NativeIoCertificate) -> String {
    format!(
        "Vortex local primitive Native I/O certificate\ncertificate: {}\npath: {}\nstatus: {}\nsource adapter: {}\npushdown guarantee: {}\naccepted operations: {}\nrepresentation transitions: {}\nmaterialization boundaries: {}\nfallback execution allowed: {}",
        certificate.certificate_id,
        certificate.path_id,
        certificate.status(),
        certificate.source_capability_report.adapter_id,
        certificate.source_pushdown_report.guarantee,
        certificate
            .source_pushdown_report
            .accepted_operation_order(),
        certificate.representation_transition_order(),
        certificate.materialization_boundary_order(),
        certificate.side_effects.fallback_execution_allowed
    )
}

pub(crate) fn vortex_count_local_encoded_fields(
    resources: ExecutionResources,
    encoded_report: &shardloom_vortex::VortexEncodedReadExecutionReport,
    local_report: &VortexLocalExecutionReport,
    streaming_report: &VortexStreamingBatchRuntimeReport,
    evidence: &VortexCountLocalEncodedEvidence,
) -> Vec<(String, String)> {
    let mut fields = Vec::new();
    crate::execution_resources::append_declaration_fields(&mut fields, resources);
    push_bool_field(&mut fields, "fallback_execution_allowed", false);
    push_field(&mut fields, "mode", "vortex_count");
    push_field(&mut fields, "primitive", "count_all");
    push_bool_field(&mut fields, "explicit_local_encoded_count_requested", true);
    push_field(&mut fields, "feature_gate", "vortex-encoded-read-spike");
    push_bool_field(
        &mut fields,
        "feature_enabled",
        vortex_encoded_read_spike_feature_enabled(),
    );
    push_bool_field(
        &mut fields,
        "encoded_read_attempted",
        encoded_report.upstream_scan_called,
    );
    push_bool_field(&mut fields, "data_read", encoded_report.data_read);
    push_bool_field(&mut fields, "data_decoded", encoded_report.data_decoded);
    push_bool_field(
        &mut fields,
        "data_materialized",
        encoded_report.data_materialized,
    );
    push_bool_field(
        &mut fields,
        "object_store_io",
        encoded_report.object_store_io,
    );
    push_bool_field(&mut fields, "write_io", encoded_report.write_io);
    push_bool_field(
        &mut fields,
        "spill_io_performed",
        encoded_report.spill_io_performed,
    );
    push_bool_field(
        &mut fields,
        "external_effects_executed",
        encoded_report.external_effects_executed,
    );
    push_field(&mut fields, "execution", encoded_report.status.as_str());
    fields.push((
        "memory_gb".to_string(),
        resources
            .whole_gib()
            .map_or_else(|| "unavailable".into(), |value| value.to_string()),
    ));
    fields.push((
        "memory_bytes".to_string(),
        resources.memory_bytes().to_string(),
    ));
    push_count_field(&mut fields, "max_parallelism", resources.max_parallelism());
    push_count_field(
        &mut fields,
        "arrays_read_count",
        encoded_report.arrays_read_count,
    );
    fields.push((
        "rows_counted".to_string(),
        encoded_report.rows_counted.to_string(),
    ));
    fields.push((
        "result_known".to_string(),
        encoded_report.count_result.is_some().to_string(),
    ));
    fields.push((
        "count".to_string(),
        encoded_report
            .count_result
            .map_or_else(|| "unknown".to_string(), |count| count.to_string()),
    ));
    fields.push((
        "local_scan_target_uri".to_string(),
        encoded_report
            .local_scan_target_uri
            .as_ref()
            .map_or_else(|| "none".to_string(), |uri| uri.as_str().to_string()),
    ));
    fields.push((
        "local_scan_readiness_source_uri".to_string(),
        encoded_report
            .local_scan_readiness_source_uri
            .as_ref()
            .map_or_else(|| "none".to_string(), |uri| uri.as_str().to_string()),
    ));
    push_bool_field(
        &mut fields,
        "local_scan_source_uri_matches_target",
        encoded_report.local_scan_source_uri_matches_target,
    );
    crate::prepared_source_backed_execution::append_vortex_encoded_read_spike_local_execution_fields(&mut fields, local_report);
    append_vortex_streaming_batch_runtime_fields(&mut fields, streaming_report);
    append_vortex_count_local_encoded_evidence_fields(&mut fields, evidence);
    fields
}

fn append_vortex_streaming_batch_runtime_fields(
    fields: &mut Vec<(String, String)>,
    report: &VortexStreamingBatchRuntimeReport,
) {
    append_vortex_streaming_batch_runtime_contract_fields(fields, report);
    append_vortex_streaming_batch_runtime_source_fields(fields, report);
    append_vortex_streaming_batch_runtime_execution_fields(fields, report);
}

fn append_vortex_streaming_batch_runtime_contract_fields(
    fields: &mut Vec<(String, String)>,
    report: &VortexStreamingBatchRuntimeReport,
) {
    push_bool_field(fields, "streaming_batch_runtime_report_emitted", true);
    push_field(
        fields,
        "streaming_batch_runtime_schema_version",
        report.schema_version,
    );
    push_field(
        fields,
        "streaming_batch_runtime_status",
        report.status.as_str(),
    );
    push_field(fields, "streaming_batch_runtime_mode", report.mode.as_str());
    push_field(
        fields,
        "streaming_batch_runtime_representation",
        report.representation.as_str(),
    );
    push_field(
        fields,
        "streaming_batch_runtime_zero_decode",
        report.zero_decode.as_str(),
    );
    push_bool_field(
        fields,
        "streaming_batch_runtime_encoded_representation_preserved",
        report.encoded_representation_preserved,
    );
    push_bool_field(
        fields,
        "streaming_batch_runtime_bounded_parallelism",
        report.bounded_parallelism,
    );
    push_bool_field(
        fields,
        "streaming_batch_runtime_bounded_memory",
        report.bounded_memory,
    );
    push_bool_field(
        fields,
        "streaming_batch_runtime_backpressure_bounded",
        report.backpressure_bounded,
    );
}

fn append_vortex_streaming_batch_runtime_source_fields(
    fields: &mut Vec<(String, String)>,
    report: &VortexStreamingBatchRuntimeReport,
) {
    push_field(
        fields,
        "streaming_batch_runtime_source_uri",
        &report
            .source_uri
            .as_ref()
            .map_or_else(|| "none".to_string(), |uri| uri.as_str().to_string()),
    );
    push_field(
        fields,
        "streaming_batch_runtime_local_scan_target_uri",
        &report
            .local_scan_target_uri
            .as_ref()
            .map_or_else(|| "none".to_string(), |uri| uri.as_str().to_string()),
    );
    push_bool_field(
        fields,
        "streaming_batch_runtime_source_uri_matches_local_scan",
        report.source_uri_matches_local_scan,
    );
}

fn append_vortex_streaming_batch_runtime_execution_fields(
    fields: &mut Vec<(String, String)>,
    report: &VortexStreamingBatchRuntimeReport,
) {
    push_count_field(
        fields,
        "streaming_batch_runtime_batches_executed",
        report.batches_executed,
    );
    fields.push((
        "streaming_batch_runtime_rows_processed".to_string(),
        report.rows_processed.to_string(),
    ));
    fields.push((
        "streaming_batch_runtime_count_result".to_string(),
        report
            .count_result
            .map_or_else(|| "unknown".to_string(), |count| count.to_string()),
    ));
    push_bool_field(
        fields,
        "streaming_batch_runtime_streams_executed",
        report.streams_executed,
    );
    push_bool_field(
        fields,
        "streaming_batch_runtime_tasks_executed",
        report.tasks_executed,
    );
    push_bool_field(
        fields,
        "streaming_batch_runtime_data_read",
        report.data_read,
    );
    push_bool_field(
        fields,
        "streaming_batch_runtime_data_decoded",
        report.data_decoded,
    );
    push_bool_field(
        fields,
        "streaming_batch_runtime_data_materialized",
        report.data_materialized,
    );
    push_bool_field(fields, "streaming_batch_runtime_row_read", report.row_read);
    push_bool_field(
        fields,
        "streaming_batch_runtime_arrow_converted",
        report.arrow_converted,
    );
    push_bool_field(
        fields,
        "streaming_batch_runtime_object_store_io",
        report.object_store_io,
    );
    push_bool_field(fields, "streaming_batch_runtime_write_io", report.write_io);
    push_bool_field(
        fields,
        "streaming_batch_runtime_spill_io_performed",
        report.spill_io_performed,
    );
    push_bool_field(
        fields,
        "streaming_batch_runtime_external_effects_executed",
        report.external_effects_executed,
    );
    push_bool_field(
        fields,
        "streaming_batch_runtime_fallback_execution_allowed",
        report.fallback_execution_allowed,
    );
}

pub(crate) fn append_vortex_count_local_encoded_evidence_fields(
    fields: &mut Vec<(String, String)>,
    evidence: &VortexCountLocalEncodedEvidence,
) {
    append_vortex_count_local_encoded_target_policy_fields(fields, evidence);
    append_vortex_count_local_native_io_certificate_fields(fields, evidence);
    push_bool_field(
        fields,
        "correctness_fixture_matched",
        evidence.fixture_id.is_some(),
    );
    push_field(
        fields,
        "correctness_fixture_id",
        evidence.fixture_id.as_deref().unwrap_or("none"),
    );
    push_field(
        fields,
        "correctness_fixture_source_ref",
        evidence.fixture_source_ref.as_deref().unwrap_or("none"),
    );
    if let Some(certificate) = &evidence.certificate {
        append_execution_certificate_fields(fields, certificate);
    } else {
        push_bool_field(fields, "execution_certificate_emitted", false);
        push_field(
            fields,
            "execution_certificate_status",
            "evidence_unavailable",
        );
        push_bool_field(fields, "execution_certificate_correctness_passed", false);
        push_bool_field(
            fields,
            "execution_certificate_unsafe_effect_detected",
            false,
        );
        push_bool_field(fields, "execution_certificate_fallback_attempted", false);
        push_bool_field(
            fields,
            "execution_certificate_fallback_execution_allowed",
            false,
        );
    }
    if let Some(physical_kernel) = &evidence.physical_kernel {
        append_encoded_count_physical_kernel_fields(fields, physical_kernel);
    } else {
        push_bool_field(fields, "encoded_count_physical_kernel_emitted", false);
        push_field(
            fields,
            "encoded_count_physical_kernel_status",
            "evidence_unavailable",
        );
        push_bool_field(fields, "encoded_count_physical_kernel_safe_evidence", false);
        push_bool_field(
            fields,
            "encoded_count_physical_kernel_production_claim_allowed",
            false,
        );
    }
    if let Some(kernel_admission) = &evidence.kernel_admission {
        append_encoded_count_kernel_admission_fields(fields, kernel_admission);
    } else {
        push_bool_field(fields, "encoded_count_kernel_admission_emitted", false);
        push_field(
            fields,
            "encoded_count_kernel_admission_status",
            "evidence_unavailable",
        );
        push_bool_field(
            fields,
            "encoded_count_kernel_admission_slot_marked_present",
            false,
        );
        push_bool_field(
            fields,
            "encoded_count_kernel_admission_production_claim_allowed",
            false,
        );
    }
}

fn append_vortex_count_local_native_io_certificate_fields(
    fields: &mut Vec<(String, String)>,
    evidence: &VortexCountLocalEncodedEvidence,
) {
    let Some(certificate) = &evidence.native_io_certificate else {
        push_bool_field(fields, "local_count_native_io_certificate_emitted", false);
        push_field(
            fields,
            "local_count_native_io_certificate_status",
            "evidence_unavailable",
        );
        push_bool_field(fields, "local_count_native_io_certified", false);
        return;
    };
    append_vortex_count_local_native_io_identity_fields(fields, certificate);
    append_vortex_count_local_native_io_source_fields(fields, certificate);
    append_vortex_count_local_native_io_pushdown_fields(fields, certificate);
    append_vortex_count_local_native_io_sink_fields(fields, certificate);
    append_vortex_count_local_native_io_side_effect_fields(fields, certificate);
    decision_evidence::append(
        fields,
        "local_count_native_io",
        &certificate.capability_decisions,
    );
}

fn append_vortex_count_local_native_io_identity_fields(
    fields: &mut Vec<(String, String)>,
    certificate: &NativeIoCertificate,
) {
    push_bool_field(fields, "local_count_native_io_certificate_emitted", true);
    push_field(
        fields,
        "local_count_native_io_certificate_schema_version",
        certificate.schema_version,
    );
    push_field(
        fields,
        "local_count_native_io_certificate_id",
        &certificate.certificate_id,
    );
    push_field(
        fields,
        "local_count_native_io_certificate_path_id",
        &certificate.path_id,
    );
    push_field(
        fields,
        "local_count_native_io_certificate_status",
        certificate.status(),
    );
    push_bool_field(
        fields,
        "local_count_native_io_certified",
        certificate.is_certified(),
    );
}

fn append_vortex_count_local_native_io_source_fields(
    fields: &mut Vec<(String, String)>,
    certificate: &NativeIoCertificate,
) {
    let source = &certificate.source_capability_report;
    push_field(
        fields,
        "local_count_native_io_source_kind",
        &source.source_kind,
    );
    push_field(
        fields,
        "local_count_native_io_adapter_id",
        &source.adapter_id,
    );
    push_bool_field(
        fields,
        "local_count_native_io_encoded_representation_preserved",
        source.encoded_representation_preserved,
    );
    push_bool_field(
        fields,
        "local_count_native_io_streaming_capability",
        source.streaming_capability,
    );
}

fn append_vortex_count_local_native_io_pushdown_fields(
    fields: &mut Vec<(String, String)>,
    certificate: &NativeIoCertificate,
) {
    let pushdown = &certificate.source_pushdown_report;
    push_field(
        fields,
        "local_count_native_io_pushdown_accepted_operations",
        &pushdown.accepted_operation_order(),
    );
    push_field(
        fields,
        "local_count_native_io_pushdown_rejected_operations",
        &pushdown.rejected_operation_order(),
    );
    push_field(
        fields,
        "local_count_native_io_pushdown_guarantee",
        &pushdown.guarantee,
    );
    push_field(
        fields,
        "local_count_native_io_representation_transitions",
        &certificate.representation_transition_order(),
    );
    push_field(
        fields,
        "local_count_native_io_materialization_boundaries",
        &certificate.materialization_boundary_order(),
    );
    push_bool_field(
        fields,
        "local_count_native_io_materializing_transitions_have_boundaries",
        certificate.materializing_transitions_have_boundaries(),
    );
}

fn append_vortex_count_local_native_io_sink_fields(
    fields: &mut Vec<(String, String)>,
    certificate: &NativeIoCertificate,
) {
    let sink = &certificate.sink_requirement_report;
    let fidelity = &certificate.adapter_fidelity_report;
    push_field(
        fields,
        "local_count_native_io_sink_target_format",
        &sink.target_format,
    );
    push_bool_field(
        fields,
        "local_count_native_io_sink_accepts_encoded",
        sink.accepts_encoded,
    );
    push_bool_field(
        fields,
        "local_count_native_io_adapter_materialization_required",
        fidelity.materialization_required,
    );
}

fn append_vortex_count_local_native_io_side_effect_fields(
    fields: &mut Vec<(String, String)>,
    certificate: &NativeIoCertificate,
) {
    let side_effects = &certificate.side_effects;
    push_bool_field(
        fields,
        "local_count_native_io_data_read",
        side_effects.data_read,
    );
    push_bool_field(
        fields,
        "local_count_native_io_data_decoded",
        side_effects.data_decoded,
    );
    push_bool_field(
        fields,
        "local_count_native_io_data_materialized",
        side_effects.data_materialized,
    );
    push_bool_field(
        fields,
        "local_count_native_io_row_read",
        side_effects.row_read,
    );
    push_bool_field(
        fields,
        "local_count_native_io_arrow_converted",
        side_effects.arrow_converted,
    );
    push_bool_field(
        fields,
        "local_count_native_io_object_store_io",
        side_effects.object_store_io,
    );
    push_bool_field(
        fields,
        "local_count_native_io_write_io",
        side_effects.write_io,
    );
    push_bool_field(
        fields,
        "local_count_native_io_spill_io_performed",
        side_effects.spill_io_performed,
    );
    push_bool_field(
        fields,
        "local_count_native_io_fallback_attempted",
        side_effects.fallback_attempted || certificate.fallback_attempted,
    );
    push_bool_field(
        fields,
        "local_count_native_io_fallback_execution_allowed",
        side_effects.fallback_execution_allowed,
    );
}

pub(crate) fn append_vortex_local_primitive_native_io_certificate_fields(
    fields: &mut Vec<(String, String)>,
    certificate: Option<&NativeIoCertificate>,
) {
    let Some(certificate) = certificate else {
        push_bool_field(
            fields,
            "local_primitive_native_io_certificate_emitted",
            false,
        );
        push_field(
            fields,
            "local_primitive_native_io_certificate_status",
            "evidence_unavailable",
        );
        push_bool_field(fields, "local_primitive_native_io_certified", false);
        return;
    };

    append_vortex_local_primitive_native_io_identity_fields(fields, certificate);
    append_vortex_local_primitive_native_io_source_fields(fields, certificate);
    append_vortex_local_primitive_native_io_pushdown_fields(fields, certificate);
    append_vortex_local_primitive_native_io_sink_fields(fields, certificate);
    append_vortex_local_primitive_native_io_side_effect_fields(fields, certificate);
    decision_evidence::append(
        fields,
        "local_primitive_native_io",
        &certificate.capability_decisions,
    );
}

fn append_vortex_local_primitive_native_io_identity_fields(
    fields: &mut Vec<(String, String)>,
    certificate: &NativeIoCertificate,
) {
    push_bool_field(
        fields,
        "local_primitive_native_io_certificate_emitted",
        true,
    );
    push_field(
        fields,
        "local_primitive_native_io_certificate_schema_version",
        certificate.schema_version,
    );
    push_field(
        fields,
        "local_primitive_native_io_certificate_id",
        &certificate.certificate_id,
    );
    push_field(
        fields,
        "local_primitive_native_io_certificate_path_id",
        &certificate.path_id,
    );
    push_field(
        fields,
        "local_primitive_native_io_certificate_status",
        certificate.status(),
    );
    push_bool_field(
        fields,
        "local_primitive_native_io_certified",
        certificate.is_certified(),
    );
}

fn append_vortex_local_primitive_native_io_source_fields(
    fields: &mut Vec<(String, String)>,
    certificate: &NativeIoCertificate,
) {
    push_field(
        fields,
        "local_primitive_native_io_source_kind",
        &certificate.source_capability_report.source_kind,
    );
    push_field(
        fields,
        "local_primitive_native_io_adapter_id",
        &certificate.source_capability_report.adapter_id,
    );
    push_bool_field(
        fields,
        "local_primitive_native_io_encoded_representation_preserved",
        certificate
            .source_capability_report
            .encoded_representation_preserved,
    );
    push_bool_field(
        fields,
        "local_primitive_native_io_streaming_capability",
        certificate.source_capability_report.streaming_capability,
    );
}

fn append_vortex_local_primitive_native_io_pushdown_fields(
    fields: &mut Vec<(String, String)>,
    certificate: &NativeIoCertificate,
) {
    push_field(
        fields,
        "local_primitive_native_io_pushdown_accepted_operations",
        &certificate
            .source_pushdown_report
            .accepted_operation_order(),
    );
    push_field(
        fields,
        "local_primitive_native_io_pushdown_rejected_operations",
        &certificate
            .source_pushdown_report
            .rejected_operation_order(),
    );
    push_field(
        fields,
        "local_primitive_native_io_pushdown_guarantee",
        &certificate.source_pushdown_report.guarantee,
    );
    push_field(
        fields,
        "local_primitive_native_io_pushdown_proof_basis",
        &certificate.source_pushdown_report.proof_basis,
    );
    push_field(
        fields,
        "local_primitive_native_io_representation_transitions",
        &certificate.representation_transition_order(),
    );
    push_field(
        fields,
        "local_primitive_native_io_materialization_boundaries",
        &certificate.materialization_boundary_order(),
    );
    push_bool_field(
        fields,
        "local_primitive_native_io_materializing_transitions_have_boundaries",
        certificate.materializing_transitions_have_boundaries(),
    );
}

fn append_vortex_local_primitive_native_io_sink_fields(
    fields: &mut Vec<(String, String)>,
    certificate: &NativeIoCertificate,
) {
    push_field(
        fields,
        "local_primitive_native_io_sink_target_format",
        &certificate.sink_requirement_report.target_format,
    );
    push_bool_field(
        fields,
        "local_primitive_native_io_sink_accepts_encoded",
        certificate.sink_requirement_report.accepts_encoded,
    );
    push_bool_field(
        fields,
        "local_primitive_native_io_sink_requires_decoded_columnar",
        certificate
            .sink_requirement_report
            .requires_decoded_columnar,
    );
    push_bool_field(
        fields,
        "local_primitive_native_io_sink_requires_rows",
        certificate.sink_requirement_report.requires_rows,
    );
    push_bool_field(
        fields,
        "local_primitive_native_io_sink_supports_streaming",
        certificate.sink_requirement_report.supports_streaming,
    );
    push_bool_field(
        fields,
        "local_primitive_native_io_adapter_materialization_required",
        certificate.adapter_fidelity_report.materialization_required,
    );
    push_bool_field(
        fields,
        "local_primitive_native_io_adapter_encoded_representation_preserved",
        certificate
            .adapter_fidelity_report
            .encoded_representation_preserved,
    );
}

fn append_vortex_local_primitive_native_io_side_effect_fields(
    fields: &mut Vec<(String, String)>,
    certificate: &NativeIoCertificate,
) {
    let side_effects = &certificate.side_effects;
    push_bool_field(
        fields,
        "local_primitive_native_io_data_read",
        side_effects.data_read,
    );
    push_bool_field(
        fields,
        "local_primitive_native_io_data_decoded",
        side_effects.data_decoded,
    );
    push_bool_field(
        fields,
        "local_primitive_native_io_data_materialized",
        side_effects.data_materialized,
    );
    push_bool_field(
        fields,
        "local_primitive_native_io_row_read",
        side_effects.row_read,
    );
    push_bool_field(
        fields,
        "local_primitive_native_io_arrow_converted",
        side_effects.arrow_converted,
    );
    push_bool_field(
        fields,
        "local_primitive_native_io_object_store_io",
        side_effects.object_store_io,
    );
    push_bool_field(
        fields,
        "local_primitive_native_io_write_io",
        side_effects.write_io,
    );
    push_bool_field(
        fields,
        "local_primitive_native_io_spill_io_performed",
        side_effects.spill_io_performed,
    );
    push_bool_field(
        fields,
        "local_primitive_native_io_fallback_attempted",
        side_effects.fallback_attempted || certificate.fallback_attempted,
    );
    push_bool_field(
        fields,
        "local_primitive_native_io_fallback_execution_allowed",
        side_effects.fallback_execution_allowed,
    );
}

pub(crate) fn append_vortex_local_primitive_execution_certificate_fields(
    fields: &mut Vec<(String, String)>,
    certificate: Option<&ExecutionCertificate>,
) {
    let Some(certificate) = certificate else {
        push_bool_field(
            fields,
            "local_primitive_execution_certificate_emitted",
            false,
        );
        push_field(
            fields,
            "local_primitive_execution_certificate_schema_version",
            "none",
        );
        push_field(fields, "local_primitive_execution_certificate_id", "none");
        push_field(
            fields,
            "local_primitive_execution_certificate_execution_kind",
            "none",
        );
        push_field(
            fields,
            "local_primitive_execution_certificate_status",
            "not_available",
        );
        push_field(
            fields,
            "local_primitive_execution_certificate_fixture_id",
            "none",
        );
        push_bool_field(
            fields,
            "local_primitive_execution_certificate_correctness_passed",
            false,
        );
        push_bool_field(
            fields,
            "local_primitive_execution_certificate_data_read",
            false,
        );
        push_bool_field(
            fields,
            "local_primitive_execution_certificate_data_decoded",
            false,
        );
        push_bool_field(
            fields,
            "local_primitive_execution_certificate_data_materialized",
            false,
        );
        push_bool_field(
            fields,
            "local_primitive_execution_certificate_row_read",
            false,
        );
        push_bool_field(
            fields,
            "local_primitive_execution_certificate_arrow_converted",
            false,
        );
        push_bool_field(
            fields,
            "local_primitive_execution_certificate_object_store_io",
            false,
        );
        push_bool_field(
            fields,
            "local_primitive_execution_certificate_write_io",
            false,
        );
        push_bool_field(
            fields,
            "local_primitive_execution_certificate_spill_io_performed",
            false,
        );
        push_bool_field(
            fields,
            "local_primitive_execution_certificate_external_effects_executed",
            false,
        );
        push_bool_field(
            fields,
            "local_primitive_execution_certificate_unsafe_effect_detected",
            false,
        );
        push_bool_field(
            fields,
            "local_primitive_execution_certificate_fallback_attempted",
            false,
        );
        push_bool_field(
            fields,
            "local_primitive_execution_certificate_fallback_execution_allowed",
            false,
        );
        return;
    };

    append_vortex_local_primitive_execution_certificate_identity_fields(fields, certificate);
    append_vortex_local_primitive_execution_certificate_effect_fields(fields, certificate);
}

fn append_vortex_local_primitive_execution_certificate_identity_fields(
    fields: &mut Vec<(String, String)>,
    certificate: &ExecutionCertificate,
) {
    push_bool_field(
        fields,
        "local_primitive_execution_certificate_emitted",
        true,
    );
    push_field(
        fields,
        "local_primitive_execution_certificate_schema_version",
        certificate.schema_version,
    );
    push_field(
        fields,
        "local_primitive_execution_certificate_id",
        &certificate.certificate_id,
    );
    push_field(
        fields,
        "local_primitive_execution_certificate_execution_kind",
        &certificate.execution_kind,
    );
    push_field(
        fields,
        "local_primitive_execution_certificate_provider_kind",
        certificate.execution_provider_kind.as_str(),
    );
    push_field(
        fields,
        "local_primitive_execution_certificate_provider_scope",
        &certificate.provider_scope,
    );
    push_field(
        fields,
        "local_primitive_execution_certificate_provider_crate",
        certificate.provider_crate.as_deref().unwrap_or("none"),
    );
    push_field(
        fields,
        "local_primitive_execution_certificate_provider_version",
        certificate.provider_version.as_deref().unwrap_or("none"),
    );
    push_field(
        fields,
        "local_primitive_execution_certificate_provider_api_surface",
        certificate
            .provider_api_surface
            .as_deref()
            .unwrap_or("none"),
    );
    push_field(
        fields,
        "local_primitive_execution_certificate_shardloom_admission_policy",
        certificate
            .shardloom_admission_policy
            .as_deref()
            .unwrap_or("none"),
    );
    push_field(
        fields,
        "local_primitive_execution_certificate_status",
        certificate.status.as_str(),
    );
    push_field(
        fields,
        "local_primitive_execution_certificate_fixture_id",
        certificate
            .correctness_fixture_id
            .as_deref()
            .unwrap_or("none"),
    );
    push_bool_field(
        fields,
        "local_primitive_execution_certificate_correctness_passed",
        certificate.correctness_passed,
    );
}

fn append_vortex_local_primitive_execution_certificate_effect_fields(
    fields: &mut Vec<(String, String)>,
    certificate: &ExecutionCertificate,
) {
    push_bool_field(
        fields,
        "local_primitive_execution_certificate_data_read",
        certificate.data_read,
    );
    push_bool_field(
        fields,
        "local_primitive_execution_certificate_data_decoded",
        certificate.data_decoded,
    );
    push_bool_field(
        fields,
        "local_primitive_execution_certificate_data_materialized",
        certificate.data_materialized,
    );
    push_bool_field(
        fields,
        "local_primitive_execution_certificate_row_read",
        certificate.row_read,
    );
    push_bool_field(
        fields,
        "local_primitive_execution_certificate_arrow_converted",
        certificate.arrow_converted,
    );
    push_bool_field(
        fields,
        "local_primitive_execution_certificate_object_store_io",
        certificate.object_store_io,
    );
    push_bool_field(
        fields,
        "local_primitive_execution_certificate_write_io",
        certificate.write_io,
    );
    push_bool_field(
        fields,
        "local_primitive_execution_certificate_spill_io_performed",
        certificate.spill_io_performed,
    );
    push_bool_field(
        fields,
        "local_primitive_execution_certificate_external_query_engine_invoked",
        certificate.external_query_engine_invoked,
    );
    push_bool_field(
        fields,
        "local_primitive_execution_certificate_external_effects_executed",
        certificate.external_effects_executed,
    );
    push_bool_field(
        fields,
        "local_primitive_execution_certificate_unsafe_effect_detected",
        certificate.unsafe_effect_detected,
    );
    push_bool_field(
        fields,
        "local_primitive_execution_certificate_fallback_attempted",
        certificate.fallback_attempted,
    );
    push_bool_field(
        fields,
        "local_primitive_execution_certificate_fallback_execution_allowed",
        certificate.fallback_execution_allowed,
    );
}

fn append_vortex_count_local_encoded_target_policy_fields(
    fields: &mut Vec<(String, String)>,
    evidence: &VortexCountLocalEncodedEvidence,
) {
    push_bool_field(
        fields,
        "generalized_local_count_target_policy_report_emitted",
        true,
    );
    push_field(
        fields,
        "generalized_local_count_target_policy",
        evidence.target_policy.as_str(),
    );
    push_field(
        fields,
        "generalized_local_count_target_policy_reason",
        evidence.target_policy.reason(),
    );
    push_bool_field(
        fields,
        "generalized_local_count_execution_allowed",
        evidence.target_policy.execution_allowed(),
    );
    push_bool_field(
        fields,
        "generalized_local_count_non_fixture_target",
        evidence.target_policy.non_fixture_target(),
    );
    push_bool_field(
        fields,
        "generalized_local_count_correctness_certified",
        evidence
            .certificate
            .as_ref()
            .is_some_and(ExecutionCertificate::is_certified),
    );
    push_bool_field(
        fields,
        "generalized_local_count_requires_correctness_fixture",
        !evidence
            .certificate
            .as_ref()
            .is_some_and(ExecutionCertificate::is_certified),
    );
    push_bool_field(
        fields,
        "generalized_local_count_requires_benchmark_evidence",
        true,
    );
    push_bool_field(
        fields,
        "generalized_local_count_production_claim_allowed",
        false,
    );
    push_bool_field(
        fields,
        "generalized_local_count_cg2_closeout_allowed",
        false,
    );
    push_bool_field(
        fields,
        "generalized_local_count_cg13_closeout_allowed",
        false,
    );
}

fn append_execution_certificate_fields(
    fields: &mut Vec<(String, String)>,
    certificate: &ExecutionCertificate,
) {
    push_bool_field(fields, "execution_certificate_emitted", true);
    append_execution_certificate_identity_fields(fields, certificate);
    append_execution_certificate_provider_fields(fields, certificate);
    append_execution_certificate_io_fields(fields, certificate);
    append_execution_certificate_effect_fields(fields, certificate);
}

fn append_execution_certificate_identity_fields(
    fields: &mut Vec<(String, String)>,
    certificate: &ExecutionCertificate,
) {
    push_field(
        fields,
        "execution_certificate_schema_version",
        certificate.schema_version,
    );
    push_field(
        fields,
        "execution_certificate_id",
        &certificate.certificate_id,
    );
    push_field(
        fields,
        "execution_certificate_execution_kind",
        &certificate.execution_kind,
    );
    push_field(
        fields,
        "execution_certificate_status",
        certificate.status.as_str(),
    );
    push_field(
        fields,
        "execution_certificate_input_ref",
        certificate.input_ref.as_deref().unwrap_or("none"),
    );
    push_field(
        fields,
        "execution_certificate_output_ref",
        certificate.output_ref.as_deref().unwrap_or("none"),
    );
    push_bool_field(
        fields,
        "execution_certificate_correctness_passed",
        certificate.correctness_passed,
    );
}

fn append_execution_certificate_provider_fields(
    fields: &mut Vec<(String, String)>,
    certificate: &ExecutionCertificate,
) {
    push_field(
        fields,
        "execution_certificate_provider_kind",
        certificate.execution_provider_kind.as_str(),
    );
    push_field(
        fields,
        "execution_certificate_provider_scope",
        &certificate.provider_scope,
    );
    push_field(
        fields,
        "execution_certificate_provider_crate",
        certificate.provider_crate.as_deref().unwrap_or("none"),
    );
    push_field(
        fields,
        "execution_certificate_provider_version",
        certificate.provider_version.as_deref().unwrap_or("none"),
    );
    push_field(
        fields,
        "execution_certificate_provider_api_surface",
        certificate
            .provider_api_surface
            .as_deref()
            .unwrap_or("none"),
    );
    push_field(
        fields,
        "execution_certificate_shardloom_admission_policy",
        certificate
            .shardloom_admission_policy
            .as_deref()
            .unwrap_or("none"),
    );
}

fn append_execution_certificate_io_fields(
    fields: &mut Vec<(String, String)>,
    certificate: &ExecutionCertificate,
) {
    push_bool_field(
        fields,
        "execution_certificate_data_read",
        certificate.data_read,
    );
    push_bool_field(
        fields,
        "execution_certificate_data_decoded",
        certificate.data_decoded,
    );
    push_bool_field(
        fields,
        "execution_certificate_data_materialized",
        certificate.data_materialized,
    );
    push_bool_field(
        fields,
        "execution_certificate_row_read",
        certificate.row_read,
    );
    push_bool_field(
        fields,
        "execution_certificate_arrow_converted",
        certificate.arrow_converted,
    );
    push_bool_field(
        fields,
        "execution_certificate_object_store_io",
        certificate.object_store_io,
    );
    push_bool_field(
        fields,
        "execution_certificate_write_io",
        certificate.write_io,
    );
    push_bool_field(
        fields,
        "execution_certificate_spill_io_performed",
        certificate.spill_io_performed,
    );
}

fn append_execution_certificate_effect_fields(
    fields: &mut Vec<(String, String)>,
    certificate: &ExecutionCertificate,
) {
    push_bool_field(
        fields,
        "execution_certificate_external_query_engine_invoked",
        certificate.external_query_engine_invoked,
    );
    push_bool_field(
        fields,
        "execution_certificate_external_effects_executed",
        certificate.external_effects_executed,
    );
    push_bool_field(
        fields,
        "execution_certificate_unsafe_effect_detected",
        certificate.unsafe_effect_detected,
    );
    push_bool_field(
        fields,
        "execution_certificate_fallback_attempted",
        certificate.fallback_attempted,
    );
    push_bool_field(
        fields,
        "execution_certificate_fallback_execution_allowed",
        certificate.fallback_execution_allowed,
    );
}

fn append_encoded_count_physical_kernel_fields(
    fields: &mut Vec<(String, String)>,
    physical_kernel: &VortexEncodedCountPhysicalKernelReport,
) {
    push_bool_field(fields, "encoded_count_physical_kernel_emitted", true);
    push_field(
        fields,
        "encoded_count_physical_kernel_schema_version",
        physical_kernel.schema_version,
    );
    push_field(
        fields,
        "encoded_count_physical_kernel_id",
        &physical_kernel.kernel_report_id,
    );
    push_field(
        fields,
        "encoded_count_physical_kernel_status",
        physical_kernel.status.as_str(),
    );
    push_field(
        fields,
        "encoded_count_physical_kernel_execution_certificate_id",
        physical_kernel
            .execution_certificate_id
            .as_deref()
            .unwrap_or("none"),
    );
    push_field(
        fields,
        "encoded_count_physical_kernel_count",
        &physical_kernel
            .count_result
            .map_or_else(|| "unknown".to_string(), |count| count.to_string()),
    );
    push_bool_field(
        fields,
        "encoded_count_physical_kernel_safe_evidence",
        physical_kernel.is_safe_native_kernel_evidence(),
    );
    push_bool_field(
        fields,
        "encoded_count_physical_kernel_production_claim_allowed",
        physical_kernel.production_claim_allowed,
    );
    push_bool_field(
        fields,
        "encoded_count_physical_kernel_data_read",
        physical_kernel.data_read,
    );
    push_bool_field(
        fields,
        "encoded_count_physical_kernel_data_decoded",
        physical_kernel.data_decoded,
    );
    push_bool_field(
        fields,
        "encoded_count_physical_kernel_data_materialized",
        physical_kernel.data_materialized,
    );
    push_bool_field(
        fields,
        "encoded_count_physical_kernel_row_read",
        physical_kernel.row_read,
    );
    push_bool_field(
        fields,
        "encoded_count_physical_kernel_arrow_converted",
        physical_kernel.arrow_converted,
    );
    push_bool_field(
        fields,
        "encoded_count_physical_kernel_object_store_io",
        physical_kernel.object_store_io,
    );
    push_bool_field(
        fields,
        "encoded_count_physical_kernel_write_io",
        physical_kernel.write_io,
    );
    push_bool_field(
        fields,
        "encoded_count_physical_kernel_spill_io_performed",
        physical_kernel.spill_io_performed,
    );
    push_bool_field(
        fields,
        "encoded_count_physical_kernel_external_effects_executed",
        physical_kernel.external_effects_executed,
    );
    push_bool_field(
        fields,
        "encoded_count_physical_kernel_fallback_attempted",
        physical_kernel.fallback_attempted,
    );
    push_bool_field(
        fields,
        "encoded_count_physical_kernel_fallback_execution_allowed",
        physical_kernel.fallback_execution_allowed,
    );
}

fn append_encoded_count_kernel_admission_fields(
    fields: &mut Vec<(String, String)>,
    kernel_admission: &VortexEncodedCountKernelAdmissionReport,
) {
    push_bool_field(fields, "encoded_count_kernel_admission_emitted", true);
    push_field(
        fields,
        "encoded_count_kernel_admission_schema_version",
        kernel_admission.schema_version,
    );
    push_field(
        fields,
        "encoded_count_kernel_admission_id",
        &kernel_admission.admission_id,
    );
    push_field(
        fields,
        "encoded_count_kernel_admission_physical_kernel_report_id",
        &kernel_admission.physical_kernel_report_id,
    );
    push_field(
        fields,
        "encoded_count_kernel_admission_slot_id",
        &kernel_admission.slot_id,
    );
    push_field(
        fields,
        "encoded_count_kernel_admission_operator_kind",
        kernel_admission.operator_kind.as_str(),
    );
    push_field(
        fields,
        "encoded_count_kernel_admission_required_kernel_kind",
        kernel_admission.required_kernel_kind.as_str(),
    );
    push_field(
        fields,
        "encoded_count_kernel_admission_candidate_kernel_kind",
        kernel_admission.candidate_kernel_kind.as_str(),
    );
    push_field(
        fields,
        "encoded_count_kernel_admission_status",
        kernel_admission.status.as_str(),
    );
    push_field(
        fields,
        "encoded_count_kernel_admission_correctness_evidence",
        kernel_admission.correctness_evidence.as_str(),
    );
    push_field(
        fields,
        "encoded_count_kernel_admission_benchmark_evidence",
        kernel_admission.benchmark_evidence.as_str(),
    );
    push_bool_field(
        fields,
        "encoded_count_kernel_admission_memory_streaming",
        kernel_admission.memory.streaming,
    );
    push_bool_field(
        fields,
        "encoded_count_kernel_admission_memory_bounded",
        kernel_admission.memory.bounded_memory,
    );
    push_bool_field(
        fields,
        "encoded_count_kernel_admission_memory_oom_safe",
        kernel_admission.memory.oom_safe,
    );
    push_bool_field(
        fields,
        "encoded_count_kernel_admission_requires_full_materialization",
        kernel_admission.memory.requires_full_materialization,
    );
    push_field(
        fields,
        "encoded_count_kernel_admission_fallback_state",
        kernel_admission.fallback.as_str(),
    );
    push_bool_field(
        fields,
        "encoded_count_kernel_admission_slot_marked_present",
        kernel_admission.slot_marked_present,
    );
    push_bool_field(
        fields,
        "encoded_count_kernel_admission_production_claim_allowed",
        kernel_admission.production_claim_allowed,
    );
    push_bool_field(
        fields,
        "encoded_count_kernel_admission_runtime_execution",
        kernel_admission.runtime_execution_allowed,
    );
    push_bool_field(
        fields,
        "encoded_count_kernel_admission_fallback_execution_allowed",
        kernel_admission.fallback_execution_allowed,
    );
}

#[allow(clippy::too_many_lines)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum VortexCountExecutionRequest {
    MetadataOnly(ExecutionResources),
    LocalEncodedCount(ExecutionResources),
}

#[cfg(test)]
pub(crate) fn parse_vortex_count_args(
    args: std::vec::IntoIter<String>,
) -> shardloom_core::Result<(DatasetUri, VortexCountExecutionRequest)> {
    parse_vortex_count_args_in_context(args, &CommandContext::default())
}

fn parse_vortex_count_args_in_context(
    mut args: std::vec::IntoIter<String>,
    context: &CommandContext<'_>,
) -> shardloom_core::Result<(DatasetUri, VortexCountExecutionRequest)> {
    let dataset_uri = args.next().ok_or_else(|| ShardLoomError::new(
        "vortex-count requires a dataset URI and explicit memory_gb (or memory_bytes) and max_parallelism"
    ))?;
    let uri = DatasetUri::new(dataset_uri)?;
    let mut args = args.peekable();
    let execute = args
        .peek()
        .is_some_and(|value| value == "--execute-local-encoded-count");
    if execute {
        args.next();
    }
    let resources =
        crate::execution_resources::ResourceArguments::parse_complete_in_context(args, context)?;
    Ok((
        uri,
        if execute {
            VortexCountExecutionRequest::LocalEncodedCount(resources)
        } else {
            VortexCountExecutionRequest::MetadataOnly(resources)
        },
    ))
}

pub(crate) fn handle_vortex_count(
    args: std::vec::IntoIter<String>,
    format: OutputFormat,
    context: &CommandContext<'_>,
) -> ExitCode {
    let (uri, execution_request) = match parse_vortex_count_args_in_context(args, context) {
        Ok(parsed) => parsed,
        Err(error) => {
            return emit_error(
                "vortex-count",
                format,
                "invalid count execution resources",
                &error,
            );
        }
    };
    let resources = match execution_request {
        VortexCountExecutionRequest::MetadataOnly(resources)
        | VortexCountExecutionRequest::LocalEncodedCount(resources) => resources,
    };
    let admission = match context.admit_for_command(resources, "vortex-count", format) {
        Ok(admission) => admission,
        Err(code) => return code,
    };
    match execution_request {
        VortexCountExecutionRequest::MetadataOnly(resources) => {
            handle_vortex_count_metadata(uri, resources, format, &admission)
        }
        VortexCountExecutionRequest::LocalEncodedCount(resources) => {
            handle_vortex_count_local_encoded(uri, resources, format, &admission)
        }
    }
}

pub(crate) fn handle_vortex_query_trace(
    mut args: std::vec::IntoIter<String>,
    format: OutputFormat,
) -> ExitCode {
    let Some(uri_arg) = args.next() else {
        eprintln!("usage: shardloom vortex-query-trace <dataset_uri> <primitive>");
        return ExitCode::from(2);
    };
    let Some(primitive_arg) = args.next() else {
        eprintln!("usage: shardloom vortex-query-trace <dataset_uri> <primitive>");
        return ExitCode::from(2);
    };
    let uri = match DatasetUri::new(uri_arg) {
        Ok(uri) => uri,
        Err(error) => {
            return emit_error("vortex-query-trace", format, "query trace failed", &error);
        }
    };
    let request = match parse_vortex_primitive_request(uri.clone(), &primitive_arg) {
        Ok(v) => v,
        Err(error) => {
            return emit_error("vortex-query-trace", format, "query trace failed", &error);
        }
    };
    let summary = open_vortex_metadata_only(VortexMetadataOpenRequest::report_only(uri))
        .ok()
        .and_then(|report| report.metadata_summary)
        .unwrap_or_else(|| {
            summarize_vortex_metadata_probe(&VortexMetadataProbeReport::deferred_api_unclear())
        });
    let analysis = match evaluate_vortex_query_primitive_with_analysis(request, &summary) {
        Ok(v) => v,
        Err(error) => {
            return emit_error("vortex-query-trace", format, "query trace failed", &error);
        }
    };
    let mut fields = vec![
        (
            "fallback_execution_allowed".to_string(),
            "false".to_string(),
        ),
        ("mode".to_string(), "vortex_query_trace".to_string()),
        ("primitive".to_string(), primitive_arg),
        ("data_read".to_string(), "false".to_string()),
        ("data_decoded".to_string(), "false".to_string()),
        ("data_materialized".to_string(), "false".to_string()),
        ("object_store_io".to_string(), "false".to_string()),
        ("write_io".to_string(), "false".to_string()),
        ("spill_io_performed".to_string(), "false".to_string()),
        ("execution".to_string(), "not_performed".to_string()),
        (
            "decision_trace_entries".to_string(),
            analysis.decision_trace.entry_count().to_string(),
        ),
        (
            "result_known".to_string(),
            analysis.result.value.is_known().to_string(),
        ),
    ];
    append_vortex_work_avoided_fields(&mut fields, Some(&analysis.work_avoided));
    emit(
        "vortex-query-trace",
        format,
        if analysis.has_errors() {
            CommandStatus::Unsupported
        } else {
            CommandStatus::Success
        },
        "vortex query trace primitive analysis".to_string(),
        analysis.to_human_text(),
        analysis.result.diagnostics.clone(),
        fields,
    );
    if analysis.has_errors() {
        ExitCode::from(1)
    } else {
        ExitCode::SUCCESS
    }
}

pub(crate) fn handle_vortex_count_where(
    args: std::vec::IntoIter<String>,
    format: OutputFormat,
    context: &CommandContext<'_>,
) -> ExitCode {
    handle_vortex_count_where_dispatch(
        args,
        format,
        "vortex-count-where",
        Vec::new(),
        None,
        context,
    )
}

pub(crate) fn handle_vortex_count_where_with_facade(
    args: std::vec::IntoIter<String>,
    format: OutputFormat,
    emit_command: &'static str,
    extra_fields: Vec<(String, String)>,
    admission: &CommandAdmission<'_>,
) -> ExitCode {
    handle_vortex_count_where_dispatch(
        args,
        format,
        emit_command,
        extra_fields,
        Some(admission),
        &CommandContext::default(),
    )
}

#[allow(clippy::too_many_lines)] // Preserve the complete primitive report while forwarding admission.
fn handle_vortex_count_where_dispatch(
    args: std::vec::IntoIter<String>,
    format: OutputFormat,
    emit_command: &'static str,
    extra_fields: Vec<(String, String)>,
    admission: Option<&CommandAdmission<'_>>,
    context: &CommandContext<'_>,
) -> ExitCode {
    let (uri, predicate_arg, predicate, local_execution_request) =
        match parse_vortex_count_where_args(args, format, context) {
            Ok(parsed) => parsed,
            Err(code) => return code,
        };
    let owned_admission = match admit_primitive_if_needed(
        admission,
        local_execution_request.as_ref(),
        context,
        emit_command,
        format,
    ) {
        Ok(admission) => admission,
        Err(code) => return code,
    };
    let admission = admission.or(owned_admission.as_ref());
    let request = VortexQueryPrimitiveRequest::count_where(uri.clone(), predicate.clone());
    let open = open_vortex_metadata_only(primitive_metadata_request(
        uri,
        local_execution_request.as_ref(),
    ));
    let summary = if let Ok(report) = open {
        report.metadata_summary.unwrap_or_else(|| {
            summarize_vortex_metadata_probe(&VortexMetadataProbeReport::deferred_api_unclear())
        })
    } else {
        summarize_vortex_metadata_probe(&VortexMetadataProbeReport::deferred_api_unclear())
    };
    let result = match evaluate_vortex_query_primitive(request.clone(), &summary) {
        Ok(result) => result,
        Err(error) => {
            return emit_error(emit_command, format, "vortex count where failed", &error);
        }
    };
    let local_execution = match local_execution_request.as_ref() {
        Some(local_request) => {
            match vortex_count_where_local_execution_evidence(
                &request,
                local_request,
                admission.expect("executing primitive has admission"),
            ) {
                Ok(evidence) => Some(evidence),
                Err(error) => {
                    return emit_error(
                        emit_command,
                        format,
                        "vortex count where local primitive execution failed",
                        &error,
                    );
                }
            }
        }
        None => None,
    };
    let evidence = match vortex_count_where_filter_evidence(&predicate, &summary) {
        Ok(evidence) => evidence,
        Err(error) => {
            return emit_error(
                emit_command,
                format,
                "vortex count where filter evidence failed",
                &error,
            );
        }
    };
    let command_has_errors = local_execution.as_ref().map_or_else(
        || result.has_errors(),
        VortexCountWhereLocalExecutionEvidence::runtime_has_errors,
    );
    let status = if command_has_errors {
        CommandStatus::Unsupported
    } else {
        CommandStatus::Success
    };
    let metadata_count = match result.value {
        VortexQueryPrimitiveValue::Count(v) => Some(v),
        _ => None,
    };
    let count = local_execution
        .as_ref()
        .and_then(VortexCountWhereLocalExecutionEvidence::count)
        .or(metadata_count);
    let diagnostics = primitive_facade_diagnostics(&result, local_execution.as_ref());
    let mut fields = vortex_count_where_fields(
        &result,
        count,
        predicate_arg,
        &evidence,
        local_execution.as_ref(),
    );
    fields.extend(extra_fields);
    emit(
        emit_command,
        format,
        status,
        "vortex count where primitive".to_string(),
        vortex_count_where_human_text(&result, &evidence, local_execution.as_ref()),
        diagnostics,
        fields,
    );
    if command_has_errors {
        ExitCode::from(1)
    } else {
        ExitCode::SUCCESS
    }
}

fn primitive_facade_diagnostics(
    result: &VortexQueryPrimitiveResult,
    local_execution: Option<&VortexLocalPrimitiveCliExecutionEvidence>,
) -> Vec<Diagnostic> {
    let mut diagnostics = if matches!(local_execution, Some(local) if !local.runtime_has_errors()) {
        Vec::new()
    } else {
        result.diagnostics.clone()
    };
    if let Some(local) = local_execution {
        diagnostics.extend(local.report.diagnostics.clone());
        if local.runtime_has_errors() {
            diagnostics.extend(local.native_io_certificate.diagnostics.clone());
        }
        if let Some(certificate) = &local.execution_certificate {
            diagnostics.extend(certificate.diagnostics.clone());
        }
    }
    diagnostics
}

pub(crate) fn handle_vortex_project(
    args: std::vec::IntoIter<String>,
    format: OutputFormat,
    context: &CommandContext<'_>,
) -> ExitCode {
    handle_vortex_project_dispatch(args, format, "vortex-project", Vec::new(), None, context)
}

pub(crate) fn handle_vortex_project_with_facade(
    args: std::vec::IntoIter<String>,
    format: OutputFormat,
    emit_command: &'static str,
    extra_fields: Vec<(String, String)>,
    admission: &CommandAdmission<'_>,
) -> ExitCode {
    handle_vortex_project_dispatch(
        args,
        format,
        emit_command,
        extra_fields,
        Some(admission),
        &CommandContext::default(),
    )
}

#[allow(clippy::too_many_lines)] // Preserve the complete primitive report while forwarding admission.
fn handle_vortex_project_dispatch(
    mut args: std::vec::IntoIter<String>,
    format: OutputFormat,
    emit_command: &'static str,
    extra_fields: Vec<(String, String)>,
    admission: Option<&CommandAdmission<'_>>,
    context: &CommandContext<'_>,
) -> ExitCode {
    let Some(uri_arg) = args.next() else {
        eprintln!(
            "usage: shardloom vortex-project <dataset_uri> <columns> [--limit <rows>] [--execute-local-primitive <memory_gb> <max_parallelism>]"
        );
        return ExitCode::from(2);
    };
    let Some(columns_arg) = args.next() else {
        eprintln!(
            "usage: shardloom vortex-project <dataset_uri> <columns> [--limit <rows>] [--execute-local-primitive <memory_gb> <max_parallelism>]"
        );
        return ExitCode::from(2);
    };
    let uri = match DatasetUri::new(uri_arg) {
        Ok(uri) => uri,
        Err(error) => {
            return emit_error(emit_command, format, "vortex project failed", &error);
        }
    };
    let projection = match parse_projection_columns(&columns_arg) {
        Ok(projection) => projection,
        Err(error) => {
            return emit_error(emit_command, format, "vortex project failed", &error);
        }
    };
    let options = match parse_vortex_filter_project_options_in_context(&mut args, context) {
        Ok(options) => options,
        Err(error) => {
            return emit_error(emit_command, format, "vortex project failed", &error);
        }
    };
    let owned_admission = match admit_primitive_if_needed(
        admission,
        options.local_execution_request.as_ref(),
        context,
        emit_command,
        format,
    ) {
        Ok(admission) => admission,
        Err(code) => return code,
    };
    let admission = admission.or(owned_admission.as_ref());
    let mut request = VortexQueryPrimitiveRequest::project(uri.clone(), projection);
    if let Some(limit) = options.source_order_limit {
        request = request.with_source_order_limit(limit);
    }
    let summary = open_vortex_metadata_only(primitive_metadata_request(
        uri,
        options.local_execution_request.as_ref(),
    ))
    .ok()
    .and_then(|report| report.metadata_summary)
    .unwrap_or_else(|| {
        summarize_vortex_metadata_probe(&VortexMetadataProbeReport::deferred_api_unclear())
    });
    let result = match evaluate_vortex_query_primitive(request.clone(), &summary) {
        Ok(result) => result,
        Err(error) => {
            return emit_error(emit_command, format, "vortex project failed", &error);
        }
    };
    let local_execution = match options.local_execution_request.as_ref() {
        Some(local_request) => {
            match vortex_local_primitive_cli_execution_evidence(
                &request,
                local_request,
                admission.expect("executing primitive has admission"),
            ) {
                Ok(evidence) => Some(evidence),
                Err(error) => {
                    return emit_error(
                        emit_command,
                        format,
                        "vortex project local primitive execution failed",
                        &error,
                    );
                }
            }
        }
        None => None,
    };
    let command_has_errors = local_execution.as_ref().map_or_else(
        || result.has_errors(),
        VortexLocalPrimitiveCliExecutionEvidence::runtime_has_errors,
    );
    let diagnostics = primitive_facade_diagnostics(&result, local_execution.as_ref());
    let mut fields = vortex_project_fields(&result, columns_arg, local_execution.as_ref());
    fields.extend(extra_fields);
    emit(
        emit_command,
        format,
        if command_has_errors {
            CommandStatus::Unsupported
        } else {
            CommandStatus::Success
        },
        "vortex project primitive".to_string(),
        vortex_project_human_text(&result, local_execution.as_ref()),
        diagnostics,
        fields,
    );
    if command_has_errors {
        ExitCode::from(1)
    } else {
        ExitCode::SUCCESS
    }
}

struct VortexFilterProjectArgs {
    uri: DatasetUri,
    predicate_arg: String,
    columns_arg: String,
    predicate: PredicateExpr,
    projection: ProjectionRequest,
    source_order_limit: Option<usize>,
    local_execution_request: Option<VortexLocalPrimitiveCliExecutionRequest>,
}

struct VortexFilterArgs {
    uri: DatasetUri,
    predicate_arg: String,
    predicate: PredicateExpr,
    source_order_limit: Option<usize>,
    local_execution_request: Option<VortexLocalPrimitiveCliExecutionRequest>,
}

struct VortexBoundedLocalExecArgs {
    uri: DatasetUri,
    primitive_arg: String,
    request: VortexQueryPrimitiveRequest,
    resources: ExecutionResources,
}

pub(crate) fn handle_vortex_filter_project(
    args: std::vec::IntoIter<String>,
    format: OutputFormat,
    context: &CommandContext<'_>,
) -> ExitCode {
    handle_vortex_filter_project_dispatch(
        args,
        format,
        "vortex-filter-project",
        Vec::new(),
        None,
        context,
    )
}

pub(crate) fn handle_vortex_filter_project_with_facade(
    args: std::vec::IntoIter<String>,
    format: OutputFormat,
    emit_command: &'static str,
    extra_fields: Vec<(String, String)>,
    admission: &CommandAdmission<'_>,
) -> ExitCode {
    handle_vortex_filter_project_dispatch(
        args,
        format,
        emit_command,
        extra_fields,
        Some(admission),
        &CommandContext::default(),
    )
}

fn handle_vortex_filter_project_dispatch(
    args: std::vec::IntoIter<String>,
    format: OutputFormat,
    emit_command: &'static str,
    extra_fields: Vec<(String, String)>,
    admission: Option<&CommandAdmission<'_>>,
    context: &CommandContext<'_>,
) -> ExitCode {
    let parsed = match parse_vortex_filter_project_args(args, format, context) {
        Ok(parsed) => parsed,
        Err(code) => return code,
    };
    let VortexFilterProjectArgs {
        uri,
        predicate_arg,
        columns_arg,
        predicate,
        projection,
        source_order_limit,
        local_execution_request,
    } = parsed;
    let owned_admission = match admit_primitive_if_needed(
        admission,
        local_execution_request.as_ref(),
        context,
        emit_command,
        format,
    ) {
        Ok(admission) => admission,
        Err(code) => return code,
    };
    let admission = admission.or(owned_admission.as_ref());
    let mut request =
        VortexQueryPrimitiveRequest::filter_and_project(uri.clone(), predicate, projection);
    if let Some(limit) = source_order_limit {
        request = request.with_source_order_limit(limit);
    }
    let summary = open_vortex_metadata_only(primitive_metadata_request(
        uri,
        local_execution_request.as_ref(),
    ))
    .ok()
    .and_then(|report| report.metadata_summary)
    .unwrap_or_else(|| {
        summarize_vortex_metadata_probe(&VortexMetadataProbeReport::deferred_api_unclear())
    });
    let result = match evaluate_vortex_query_primitive(request.clone(), &summary) {
        Ok(result) => result,
        Err(error) => {
            return emit_error(emit_command, format, "vortex filter project failed", &error);
        }
    };
    let local_execution = match vortex_filter_project_local_execution(
        &request,
        local_execution_request.as_ref(),
        format,
        emit_command,
        admission,
    ) {
        Ok(local_execution) => local_execution,
        Err(code) => return code,
    };
    let command_has_errors = local_execution.as_ref().map_or_else(
        || result.has_errors(),
        VortexLocalPrimitiveCliExecutionEvidence::runtime_has_errors,
    );
    let mut diagnostics = if local_execution
        .as_ref()
        .is_some_and(|local| !local.runtime_has_errors())
    {
        Vec::new()
    } else {
        result.diagnostics.clone()
    };
    if let Some(local) = &local_execution {
        diagnostics.extend(local.report.diagnostics.clone());
        if local.runtime_has_errors() {
            diagnostics.extend(local.native_io_certificate.diagnostics.clone());
        }
        if let Some(certificate) = &local.execution_certificate {
            diagnostics.extend(certificate.diagnostics.clone());
        }
    }
    let mut fields = vortex_filter_project_fields(
        &result,
        predicate_arg,
        columns_arg,
        local_execution.as_ref(),
    );
    fields.extend(extra_fields);
    emit(
        emit_command,
        format,
        if command_has_errors {
            CommandStatus::Unsupported
        } else {
            CommandStatus::Success
        },
        "vortex filter project primitive".to_string(),
        vortex_filter_project_human_text(&result, local_execution.as_ref()),
        diagnostics,
        fields,
    );
    if command_has_errors {
        ExitCode::from(1)
    } else {
        ExitCode::SUCCESS
    }
}

pub(crate) fn handle_vortex_filter(
    args: std::vec::IntoIter<String>,
    format: OutputFormat,
    context: &CommandContext<'_>,
) -> ExitCode {
    handle_vortex_filter_dispatch(args, format, "vortex-filter", Vec::new(), None, context)
}

pub(crate) fn handle_vortex_filter_with_facade(
    args: std::vec::IntoIter<String>,
    format: OutputFormat,
    emit_command: &'static str,
    extra_fields: Vec<(String, String)>,
    admission: &CommandAdmission<'_>,
) -> ExitCode {
    handle_vortex_filter_dispatch(
        args,
        format,
        emit_command,
        extra_fields,
        Some(admission),
        &CommandContext::default(),
    )
}

fn handle_vortex_filter_dispatch(
    args: std::vec::IntoIter<String>,
    format: OutputFormat,
    emit_command: &'static str,
    extra_fields: Vec<(String, String)>,
    admission: Option<&CommandAdmission<'_>>,
    context: &CommandContext<'_>,
) -> ExitCode {
    let parsed = match parse_vortex_filter_args(args, format, context) {
        Ok(parsed) => parsed,
        Err(code) => return code,
    };
    let VortexFilterArgs {
        uri,
        predicate_arg,
        predicate,
        source_order_limit,
        local_execution_request,
    } = parsed;
    let owned_admission = match admit_primitive_if_needed(
        admission,
        local_execution_request.as_ref(),
        context,
        emit_command,
        format,
    ) {
        Ok(admission) => admission,
        Err(code) => return code,
    };
    let admission = admission.or(owned_admission.as_ref());
    let mut request = VortexQueryPrimitiveRequest::filter(uri.clone(), predicate);
    if let Some(limit) = source_order_limit {
        request = request.with_source_order_limit(limit);
    }
    let summary = open_vortex_metadata_only(primitive_metadata_request(
        uri,
        local_execution_request.as_ref(),
    ))
    .ok()
    .and_then(|report| report.metadata_summary)
    .unwrap_or_else(|| {
        summarize_vortex_metadata_probe(&VortexMetadataProbeReport::deferred_api_unclear())
    });
    let result = match evaluate_vortex_query_primitive(request.clone(), &summary) {
        Ok(result) => result,
        Err(error) => {
            return emit_error(emit_command, format, "vortex filter failed", &error);
        }
    };
    let local_execution = match vortex_filter_local_execution(
        &request,
        local_execution_request.as_ref(),
        format,
        emit_command,
        admission,
    ) {
        Ok(local_execution) => local_execution,
        Err(code) => return code,
    };
    let command_has_errors = local_execution.as_ref().map_or_else(
        || result.has_errors(),
        VortexLocalPrimitiveCliExecutionEvidence::runtime_has_errors,
    );
    let mut diagnostics = if local_execution
        .as_ref()
        .is_some_and(|local| !local.runtime_has_errors())
    {
        Vec::new()
    } else {
        result.diagnostics.clone()
    };
    if let Some(local) = &local_execution {
        diagnostics.extend(local.report.diagnostics.clone());
        if local.runtime_has_errors() {
            diagnostics.extend(local.native_io_certificate.diagnostics.clone());
        }
        if let Some(certificate) = &local.execution_certificate {
            diagnostics.extend(certificate.diagnostics.clone());
        }
    }
    let mut fields = vortex_filter_fields(&result, predicate_arg, local_execution.as_ref());
    fields.extend(extra_fields);
    emit(
        emit_command,
        format,
        if command_has_errors {
            CommandStatus::Unsupported
        } else {
            CommandStatus::Success
        },
        "vortex filter primitive".to_string(),
        vortex_filter_human_text(&result, local_execution.as_ref()),
        diagnostics,
        fields,
    );
    if command_has_errors {
        ExitCode::from(1)
    } else {
        ExitCode::SUCCESS
    }
}

pub(crate) fn handle_vortex_local_exec(
    mut args: std::vec::IntoIter<String>,
    format: OutputFormat,
) -> ExitCode {
    let Some(uri_arg) = args.next() else {
        eprintln!("usage: shardloom vortex-local-exec <dataset_uri> <primitive>");
        return ExitCode::from(2);
    };
    let Some(primitive_arg) = args.next() else {
        eprintln!("usage: shardloom vortex-local-exec <dataset_uri> <primitive>");
        return ExitCode::from(2);
    };
    let uri = match DatasetUri::new(uri_arg) {
        Ok(v) => v,
        Err(error) => {
            return emit_error(
                "vortex-local-exec",
                format,
                "vortex local exec failed",
                &error,
            );
        }
    };
    let request = match parse_vortex_primitive_request(uri.clone(), &primitive_arg) {
        Ok(v) => v,
        Err(error) => {
            return emit_error(
                "vortex-local-exec",
                format,
                "vortex local exec failed",
                &error,
            );
        }
    };
    let summary = open_vortex_metadata_only(VortexMetadataOpenRequest::report_only(uri))
        .ok()
        .and_then(|report| report.metadata_summary);
    let report = match execute_vortex_local_query_primitive(request, summary) {
        Ok(v) => v,
        Err(error) => {
            return emit_error(
                "vortex-local-exec",
                format,
                "vortex local exec failed",
                &error,
            );
        }
    };
    emit(
        "vortex-local-exec",
        format,
        if report.has_errors() {
            CommandStatus::Unsupported
        } else {
            CommandStatus::Success
        },
        "vortex local execution loop skeleton".to_string(),
        report.to_human_text(),
        report.diagnostics.clone(),
        vec![
            (
                "fallback_execution_allowed".to_string(),
                "false".to_string(),
            ),
            ("mode".to_string(), "vortex_local_exec".to_string()),
            ("primitive".to_string(), primitive_arg),
            ("tasks_executed".to_string(), "false".to_string()),
            ("data_read".to_string(), "false".to_string()),
            ("data_decoded".to_string(), "false".to_string()),
            ("data_materialized".to_string(), "false".to_string()),
            ("object_store_io".to_string(), "false".to_string()),
            ("write_io".to_string(), "false".to_string()),
            ("spill_io_performed".to_string(), "false".to_string()),
            ("external_effects_executed".to_string(), "false".to_string()),
            (
                "execution".to_string(),
                "metadata_only_or_not_performed".to_string(),
            ),
            (
                "result_known".to_string(),
                report.value.is_known().to_string(),
            ),
        ],
    );
    if report.has_errors() {
        ExitCode::from(1)
    } else {
        ExitCode::SUCCESS
    }
}

pub(crate) fn handle_vortex_bounded_local_exec(
    args: std::vec::IntoIter<String>,
    format: OutputFormat,
) -> ExitCode {
    let parsed = match parse_vortex_bounded_local_exec_args(args, format) {
        Ok(parsed) => parsed,
        Err(code) => return code,
    };
    let VortexBoundedLocalExecArgs {
        uri,
        primitive_arg,
        request,
        resources,
    } = parsed;
    let summary =
        open_vortex_metadata_only(VortexMetadataOpenRequest::metadata_only(uri, resources))
            .ok()
            .and_then(|report| report.metadata_summary);
    let local = match execute_vortex_local_query_primitive(request, summary) {
        Ok(v) => v,
        Err(error) => {
            return emit_error(
                "vortex-bounded-local-exec",
                format,
                "vortex bounded local exec failed",
                &error,
            );
        }
    };
    let policy = match VortexBoundedExecutionPolicy::from_resources(resources) {
        Ok(v) => v,
        Err(error) => {
            return emit_error(
                "vortex-bounded-local-exec",
                format,
                "vortex bounded local exec failed",
                &error,
            );
        }
    };
    let report = match execute_vortex_bounded_local_query(local, policy) {
        Ok(v) => v,
        Err(error) => {
            return emit_error(
                "vortex-bounded-local-exec",
                format,
                "vortex bounded local exec failed",
                &error,
            );
        }
    };
    emit(
        "vortex-bounded-local-exec",
        format,
        if report.has_errors() {
            CommandStatus::Unsupported
        } else {
            CommandStatus::Success
        },
        "vortex bounded local execution".to_string(),
        report.to_human_text(),
        report.diagnostics.clone(),
        bounded_local_execution_fields(&report, &primitive_arg, resources),
    );
    if report.has_errors() {
        ExitCode::from(1)
    } else {
        ExitCode::SUCCESS
    }
}

pub(crate) fn handle_vortex_run(
    args: std::vec::IntoIter<String>,
    format: OutputFormat,
    context: &CommandContext<'_>,
) -> ExitCode {
    handle_vortex_run_dispatch(args, format, "vortex-run", Vec::new(), None, context)
}

pub(crate) fn handle_vortex_run_with_facade(
    args: std::vec::IntoIter<String>,
    format: OutputFormat,
    emit_command: &'static str,
    extra_fields: Vec<(String, String)>,
    admission: &CommandAdmission<'_>,
) -> ExitCode {
    handle_vortex_run_dispatch(
        args,
        format,
        emit_command,
        extra_fields,
        Some(admission),
        &CommandContext::default(),
    )
}

fn handle_vortex_run_dispatch(
    args: std::vec::IntoIter<String>,
    format: OutputFormat,
    emit_command: &'static str,
    extra_fields: Vec<(String, String)>,
    admission: Option<&CommandAdmission<'_>>,
    context: &CommandContext<'_>,
) -> ExitCode {
    let parsed = match parse_vortex_run_args(args, format, context) {
        Ok(parsed) => parsed,
        Err(code) => return code,
    };
    let VortexRunArgs {
        primitive_arg,
        resources,
        request,
    } = parsed;
    let owned_admission = if admission.is_none() {
        match context.admit_for_command(resources, emit_command, format) {
            Ok(admission) => Some(admission),
            Err(code) => return code,
        }
    } else {
        None
    };
    let admission = admission
        .or(owned_admission.as_ref())
        .expect("run has admission");
    if let Err(error) = admission.check() {
        return emit_error(emit_command, format, "vortex run cancelled", &error);
    }
    #[cfg(all(feature = "vortex-local-primitives", unix))]
    let report_result = match admission.native_session() {
        Ok(session) => shardloom_vortex::local_engine::run_vortex_local_engine_in_session(
            request,
            session,
            &admission.cancellation(),
        ),
        Err(error) => Err(error),
    };
    #[cfg(not(all(feature = "vortex-local-primitives", unix)))]
    let report_result = run_vortex_local_engine(request);
    let report = match report_result {
        Ok(v) => v,
        Err(error) => return emit_error(emit_command, format, "vortex run failed", &error),
    };
    let runtime_work_avoided = report.runtime_work_avoided_report();
    let mut why_report = report.why_report();
    let certificates = match vortex_run_certificates(&report, format) {
        Ok(certificates) => certificates,
        Err(code) => return code,
    };
    reconcile_vortex_local_engine_why_with_execution_certificate(
        &mut why_report,
        certificates.execution.as_ref(),
    );
    let mut fields = vortex_run_fields(
        &report,
        &VortexRunFieldContext {
            primitive_arg: &primitive_arg,
            resources,
            runtime_work_avoided: &runtime_work_avoided,
            certificates: &certificates,
            why_report: &why_report,
        },
    );
    fields.extend(extra_fields);
    emit(
        emit_command,
        format,
        if report.has_errors() {
            CommandStatus::Unsupported
        } else {
            CommandStatus::Success
        },
        "vortex local engine surface".to_string(),
        vortex_run_human_text(&report, &why_report, certificates.execution.as_ref()),
        report.diagnostics.clone(),
        fields,
    );
    if report.has_errors() {
        ExitCode::from(1)
    } else {
        ExitCode::SUCCESS
    }
}

struct VortexRunArgs {
    primitive_arg: String,
    resources: shardloom_core::ExecutionResources,
    request: VortexLocalEngineRequest,
}

struct VortexRunCertificates {
    native_io: Option<NativeIoCertificate>,
    execution: Option<ExecutionCertificate>,
}

struct VortexRunFieldContext<'a> {
    primitive_arg: &'a str,
    resources: shardloom_core::ExecutionResources,
    runtime_work_avoided: &'a VortexWorkAvoidedReport,
    certificates: &'a VortexRunCertificates,
    why_report: &'a VortexLocalEngineWhyReport,
}

fn parse_vortex_run_args(
    mut args: std::vec::IntoIter<String>,
    format: OutputFormat,
    context: &CommandContext<'_>,
) -> std::result::Result<VortexRunArgs, ExitCode> {
    let Some(uri_arg) = args.next() else {
        eprintln!(
            "usage: shardloom vortex-run <dataset_uri> <primitive> <memory_gb> <max_parallelism>"
        );
        return Err(ExitCode::from(2));
    };
    let Some(primitive_arg) = args.next() else {
        eprintln!(
            "usage: shardloom vortex-run <dataset_uri> <primitive> <memory_gb> <max_parallelism>"
        );
        return Err(ExitCode::from(2));
    };
    let resources =
        crate::execution_resources::ResourceArguments::parse_complete_in_context(args, context)
            .map_err(|error| {
                emit_error(
                    "vortex-run",
                    format,
                    "vortex run requires execution resources",
                    &error,
                )
            })?;
    let uri = DatasetUri::new(uri_arg)
        .map_err(|error| emit_error("vortex-run", format, "vortex run failed", &error))?;
    let primitive = parse_vortex_local_engine_primitive(&primitive_arg)
        .map_err(|error| emit_error("vortex-run", format, "vortex run failed", &error))?;
    let request = VortexLocalEngineRequest::with_resources(uri, primitive, resources);
    Ok(VortexRunArgs {
        primitive_arg,
        resources,
        request,
    })
}

fn vortex_run_certificates(
    report: &VortexLocalEngineReport,
    format: OutputFormat,
) -> std::result::Result<VortexRunCertificates, ExitCode> {
    let native_io = match (
        report.query_request.as_ref(),
        report.local_primitive_execution_report.as_ref(),
    ) {
        (Some(query_request), Some(local_report)) => Some(
            local_primitive_native_io_certificate(query_request, local_report).map_err(
                |error| {
                    emit_error(
                        "vortex-run",
                        format,
                        "vortex local primitive native I/O certificate failed",
                        &error,
                    )
                },
            )?,
        ),
        _ => None,
    };
    let execution = match (
        report.query_request.as_ref(),
        report.local_primitive_execution_report.as_ref(),
    ) {
        (Some(query_request), Some(local_report)) => {
            vortex_run_execution_certificate(query_request, local_report, format)?
        }
        _ => None,
    };
    Ok(VortexRunCertificates {
        native_io,
        execution,
    })
}

fn vortex_run_execution_certificate(
    query_request: &VortexQueryPrimitiveRequest,
    local_report: &shardloom_vortex::VortexLocalPrimitiveExecutionReport,
    format: OutputFormat,
) -> std::result::Result<Option<ExecutionCertificate>, ExitCode> {
    let Some(fixture) =
        local_primitive_correctness_fixture_for_request(query_request, local_report)
    else {
        return Ok(None);
    };
    local_primitive_execution_certificate(&fixture, query_request, local_report)
        .map(Some)
        .map_err(|error| {
            emit_error(
                "vortex-run",
                format,
                "vortex local primitive execution certificate failed",
                &error,
            )
        })
}

fn vortex_run_fields(
    report: &VortexLocalEngineReport,
    context: &VortexRunFieldContext<'_>,
) -> Vec<(String, String)> {
    let mut fields = Vec::new();
    append_vortex_run_identity_fields(&mut fields, context.primitive_arg, context.resources);
    append_vortex_run_metadata_fields(&mut fields, report);
    append_vortex_run_effect_fields(&mut fields, report);
    append_vortex_run_local_primitive_fields(&mut fields, report);
    append_vortex_run_timing_surface_fields(&mut fields);
    fields.push((
        "execution".to_string(),
        if report.data_read {
            "local_vortex_primitive_performed".to_string()
        } else {
            "metadata_only_or_not_performed".to_string()
        },
    ));
    append_vortex_work_avoided_fields(&mut fields, Some(context.runtime_work_avoided));
    append_vortex_local_primitive_native_io_certificate_fields(
        &mut fields,
        context.certificates.native_io.as_ref(),
    );
    append_vortex_local_primitive_execution_certificate_fields(
        &mut fields,
        context.certificates.execution.as_ref(),
    );
    append_vortex_local_engine_why_fields(&mut fields, context.why_report);
    fields
}

fn append_vortex_run_timing_surface_fields(fields: &mut Vec<(String, String)>) {
    fields.extend([
        ("timing_surface".to_string(), "hot_runtime".to_string()),
        (
            "actual_evidence_tier".to_string(),
            "metadata_sink".to_string(),
        ),
        (
            "route_total_timing_reported".to_string(),
            "false".to_string(),
        ),
        (
            "result_sink_timing_included_in_route_total".to_string(),
            "false".to_string(),
        ),
        (
            "evidence_render_timing_included_in_route_total".to_string(),
            "false".to_string(),
        ),
        (
            "timing_claim_boundary".to_string(),
            "runtime_route_evidence_only_no_benchmark_or_publication_claim".to_string(),
        ),
    ]);
}

fn append_vortex_run_identity_fields(
    fields: &mut Vec<(String, String)>,
    primitive_arg: &str,
    resources: shardloom_core::ExecutionResources,
) {
    fields.extend([
        (
            "fallback_execution_allowed".to_string(),
            "false".to_string(),
        ),
        ("mode".to_string(), "vortex_run".to_string()),
        ("primitive".to_string(), primitive_arg.to_string()),
        (
            "memory_gb".to_string(),
            resources
                .whole_gib()
                .map_or_else(|| "unavailable".into(), |value| value.to_string()),
        ),
        (
            "memory_bytes".to_string(),
            resources.memory_bytes().to_string(),
        ),
        (
            "max_parallelism".to_string(),
            resources.max_parallelism().to_string(),
        ),
    ]);
}

fn append_vortex_run_metadata_fields(
    fields: &mut Vec<(String, String)>,
    report: &VortexLocalEngineReport,
) {
    fields.extend([
        (
            "metadata_open_report_present".to_string(),
            report.metadata_open_report.is_some().to_string(),
        ),
        (
            "metadata_open_status".to_string(),
            report.metadata_open_report.as_ref().map_or_else(
                || "none".to_string(),
                |open| open.open_status.as_str().to_string(),
            ),
        ),
        (
            "metadata_open_feature_enabled".to_string(),
            report.metadata_open_report.as_ref().map_or_else(
                || "false".to_string(),
                |open| open.feature_status.is_enabled().to_string(),
            ),
        ),
        (
            "file_io_performed".to_string(),
            report.metadata_open_report.as_ref().map_or_else(
                || "false".to_string(),
                |open| open.file_io_performed.to_string(),
            ),
        ),
    ]);
}

fn append_vortex_run_effect_fields(
    fields: &mut Vec<(String, String)>,
    report: &VortexLocalEngineReport,
) {
    let row_read = report
        .local_primitive_execution_report
        .as_ref()
        .is_some_and(|local| local.row_read);
    let arrow_converted = report
        .local_primitive_execution_report
        .as_ref()
        .is_some_and(|local| local.arrow_converted);
    fields.extend([
        (
            "data_io_performed".to_string(),
            report.data_read.to_string(),
        ),
        (
            "object_store_io_performed".to_string(),
            report.object_store_io.to_string(),
        ),
        (
            "write_io_performed".to_string(),
            report.write_io.to_string(),
        ),
        ("result_known".to_string(), report.result_known.to_string()),
        (
            "tasks_executed".to_string(),
            report.tasks_executed.to_string(),
        ),
        ("data_read".to_string(), report.data_read.to_string()),
        ("data_decoded".to_string(), report.data_decoded.to_string()),
        (
            "data_materialized".to_string(),
            report.data_materialized.to_string(),
        ),
        ("row_read".to_string(), row_read.to_string()),
        ("arrow_converted".to_string(), arrow_converted.to_string()),
        (
            "object_store_io".to_string(),
            report.object_store_io.to_string(),
        ),
        ("write_io".to_string(), report.write_io.to_string()),
        (
            "spill_io_performed".to_string(),
            report.spill_io_performed.to_string(),
        ),
        (
            "external_effects_executed".to_string(),
            report.external_effects_executed.to_string(),
        ),
    ]);
}

fn append_vortex_run_local_primitive_fields(
    fields: &mut Vec<(String, String)>,
    report: &VortexLocalEngineReport,
) {
    append_vortex_local_primitive_execution_report_fields(
        fields,
        report.local_primitive_execution_report.as_ref(),
    );
}

pub(crate) fn append_vortex_local_primitive_execution_report_fields(
    fields: &mut Vec<(String, String)>,
    local: Option<&shardloom_vortex::VortexLocalPrimitiveExecutionReport>,
) {
    append_primitive_report_with_cache_evidence(
        fields,
        local,
        local.is_some_and(|report| report.embedded_layout.no_query_answer_cache),
    );
}

#[cfg(all(feature = "vortex-local-primitives", unix))]
pub(crate) fn append_vortex_footer_count_report_fields(fields: &mut Vec<(String, String)>) {
    // The retained footer count has no row-primitive report. Its own native
    // execution still validates and reads the exact footer count on every call.
    append_primitive_report_with_cache_evidence(fields, None, true);
}

fn append_primitive_report_with_cache_evidence(
    fields: &mut Vec<(String, String)>,
    local: Option<&shardloom_vortex::VortexLocalPrimitiveExecutionReport>,
    no_query_answer_cache: bool,
) {
    append_vortex_run_local_primitive_status_fields(fields, local);
    append_vortex_run_local_primitive_row_fields(fields, local);
    append_vortex_run_local_primitive_execution_fields(fields, local);
    // Typed relational plans and ordinary SQL providers expose the same
    // measured strategy, worker and decode evidence. Unknown fields stay absent.
    if let Some(local) = local {
        crate::public_workflow_route::append_native_scan_column_fields(fields, local);
        crate::public_workflow_route::append_local_primitive_result_summary_evidence_fields(
            fields,
            local.result_summary.as_deref(),
        );
    }
    push_bool_field(
        fields,
        "local_primitive_no_query_answer_cache",
        no_query_answer_cache,
    );
}

fn append_vortex_run_local_primitive_status_fields(
    fields: &mut Vec<(String, String)>,
    local: Option<&shardloom_vortex::VortexLocalPrimitiveExecutionReport>,
) {
    fields.extend([
        (
            "local_primitive_report_present".to_string(),
            local.is_some().to_string(),
        ),
        (
            "local_primitive_status".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.status.as_str().to_string(),
            ),
        ),
        (
            "local_primitive_mode".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.mode.as_str().to_string(),
            ),
        ),
    ]);
}

fn append_vortex_run_local_primitive_row_fields(
    fields: &mut Vec<(String, String)>,
    local: Option<&shardloom_vortex::VortexLocalPrimitiveExecutionReport>,
) {
    fields.extend([
        (
            "local_primitive_rows_scanned".to_string(),
            local.map_or_else(|| "0".to_string(), |local| local.rows_scanned.to_string()),
        ),
        (
            "local_primitive_rows_selected".to_string(),
            local
                .and_then(|local| local.rows_selected)
                .map_or_else(|| "none".to_string(), |rows| rows.to_string()),
        ),
        (
            "local_primitive_projected_columns".to_string(),
            local.map_or_else(String::new, |local| local.projected_columns.join(",")),
        ),
        (
            "local_primitive_arrays_read_count".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| local.arrays_read_count.to_string(),
            ),
        ),
        (
            "local_primitive_max_chunk_rows".to_string(),
            local.map_or_else(|| "0".to_string(), |local| local.max_chunk_rows.to_string()),
        ),
    ]);
}

#[allow(clippy::too_many_lines)]
fn append_vortex_run_local_primitive_resource_envelope_fields(
    fields: &mut Vec<(String, String)>,
    local: Option<&shardloom_vortex::VortexLocalPrimitiveExecutionReport>,
) {
    if let Some(local) = local {
        crate::execution_resources::append_declaration_fields(
            fields,
            local.resource_envelope.declared_resources,
        );
        if cfg!(unix)
            && local.status == shardloom_vortex::VortexLocalPrimitiveExecutionStatus::Executed
        {
            crate::execution_resources::append_admission_fields(
                fields,
                local.resource_envelope.memory_budget_bytes,
                local.resource_envelope.max_parallelism,
                "native_operator_policy_ceiling;runtime_may_use_fewer_lanes",
            );
            crate::execution_resources::append_spill_observation_fields(
                fields,
                local.spill_io_performed,
                local
                    .state_budget
                    .native_weighted_count_spill
                    .as_ref()
                    .map(|spill| spill.native_bytes_written),
            );
        }
    }
    fields.extend([
        (
            "local_primitive_resource_envelope_schema_version".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |_| {
                    shardloom_vortex::VortexLocalPrimitiveResourceEnvelope::SCHEMA_VERSION
                        .to_string()
                },
            ),
        ),
        (
            "local_primitive_resource_envelope_summary".to_string(),
            local.map_or_else(String::new, |local| {
                local.resource_envelope.compact_summary()
            }),
        ),
        (
            "local_primitive_resource_memory_gb".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| {
                    local
                        .resource_envelope
                        .memory_gb
                        .map_or_else(|| "unavailable".into(), |value| value.to_string())
                },
            ),
        ),
        (
            "local_primitive_resource_memory_budget_bytes".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| local.resource_envelope.memory_budget_bytes.to_string(),
            ),
        ),
        (
            "local_primitive_resource_max_parallelism".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| local.resource_envelope.max_parallelism.to_string(),
            ),
        ),
        (
            "local_primitive_resource_scan_concurrency_per_worker".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| {
                    local
                        .resource_envelope
                        .scan_concurrency_per_worker
                        .to_string()
                },
            ),
        ),
        (
            "local_primitive_resource_capillary_unit_target_rows".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| {
                    local
                        .resource_envelope
                        .capillary_unit_target_rows
                        .to_string()
                },
            ),
        ),
        (
            "local_primitive_resource_group_state_soft_item_budget".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| {
                    local
                        .resource_envelope
                        .group_state_soft_item_budget
                        .to_string()
                },
            ),
        ),
        (
            "local_primitive_resource_string_topk_heavy_hitter_capacity".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| {
                    local
                        .resource_envelope
                        .string_topk_heavy_hitter_capacity
                        .to_string()
                },
            ),
        ),
        (
            "local_primitive_resource_numeric_utf8_topk_heavy_hitter_capacity".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| {
                    local
                        .resource_envelope
                        .numeric_utf8_topk_heavy_hitter_capacity
                        .to_string()
                },
            ),
        ),
        (
            "local_primitive_resource_spill_threshold_bytes".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| local.resource_envelope.spill_threshold_bytes.to_string(),
            ),
        ),
        (
            "local_primitive_resource_sort_retention_flush_multiplier".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| {
                    local
                        .resource_envelope
                        .sort_retention_flush_multiplier
                        .to_string()
                },
            ),
        ),
        (
            "local_primitive_resource_sort_retention_flush_slack_rows".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| {
                    local
                        .resource_envelope
                        .sort_retention_flush_slack_rows
                        .to_string()
                },
            ),
        ),
        (
            "local_primitive_resource_writer_row_block_target_rows".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| {
                    local
                        .resource_envelope
                        .writer_row_block_target_rows
                        .to_string()
                },
            ),
        ),
        (
            "local_primitive_resource_writer_coalescing_target_bytes".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| {
                    local
                        .resource_envelope
                        .writer_coalescing_target_bytes
                        .to_string()
                },
            ),
        ),
    ]);
}

fn append_vortex_run_local_primitive_physical_policy_fields(
    fields: &mut Vec<(String, String)>,
    local: Option<&shardloom_vortex::VortexLocalPrimitiveExecutionReport>,
) {
    fields.extend([
        (
            "local_primitive_physical_policy_schema_version".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.physical_policy.schema_version.clone(),
            ),
        ),
        (
            "local_primitive_physical_policy_id".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.physical_policy.policy_id.clone(),
            ),
        ),
        (
            "local_primitive_physical_policy_route_family".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.physical_policy.route_family.clone(),
            ),
        ),
        (
            "local_primitive_physical_policy_state_pressure_reason".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.physical_policy.state_pressure_reason.clone(),
            ),
        ),
        (
            "local_primitive_physical_policy_rejected_alternatives".to_string(),
            local.map_or_else(String::new, |local| {
                local.physical_policy.rejected_alternatives.join(",")
            }),
        ),
        (
            "local_primitive_physical_policy_row_ref_retention_enabled".to_string(),
            local
                .is_some_and(|local| local.physical_policy.row_ref_retention_enabled)
                .to_string(),
        ),
        (
            "local_primitive_physical_policy_writer_coalescing_enabled".to_string(),
            local
                .is_some_and(|local| local.physical_policy.writer_coalescing_enabled)
                .to_string(),
        ),
    ]);
}

#[allow(clippy::too_many_lines)]
fn append_vortex_run_local_primitive_evidence_collector_fields(
    fields: &mut Vec<(String, String)>,
    local: Option<&shardloom_vortex::VortexLocalPrimitiveExecutionReport>,
) {
    fields.extend([
        (
            "local_primitive_evidence_collector_schema_version".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.evidence_collector.schema_version.to_string(),
            ),
        ),
        (
            "local_primitive_evidence_collector_status".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.evidence_collector.status.to_string(),
            ),
        ),
        (
            "local_primitive_evidence_collector_strategy".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.evidence_collector.strategy.to_string(),
            ),
        ),
        (
            "local_primitive_control_plane_micros".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| local.evidence_collector.control_plane_micros.to_string(),
            ),
        ),
        (
            "local_primitive_evidence_collection_micros".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| {
                    local
                        .evidence_collector
                        .evidence_collection_micros
                        .to_string()
                },
            ),
        ),
        (
            "local_primitive_evidence_full_split_count".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| local.evidence_collector.full_split_count.to_string(),
            ),
        ),
        (
            "local_primitive_evidence_compact_signature_count".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| local.evidence_collector.compact_signature_count.to_string(),
            ),
        ),
        (
            "local_primitive_evidence_encoded_kernel_input_count".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| {
                    local
                        .evidence_collector
                        .encoded_kernel_input_count
                        .to_string()
                },
            ),
        ),
        (
            "local_primitive_evidence_row_count".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| local.evidence_collector.row_count.to_string(),
            ),
        ),
        (
            "local_primitive_evidence_first_split_ref".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| {
                    local
                        .evidence_collector
                        .representative_first_split_ref
                        .clone()
                        .unwrap_or_else(|| "none".to_string())
                },
            ),
        ),
        (
            "local_primitive_evidence_last_split_ref".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| {
                    local
                        .evidence_collector
                        .representative_last_split_ref
                        .clone()
                        .unwrap_or_else(|| "none".to_string())
                },
            ),
        ),
        (
            "local_primitive_evidence_full_replay_preserved".to_string(),
            local
                .is_some_and(|local| local.evidence_collector.full_replay_evidence_preserved)
                .to_string(),
        ),
    ]);
}

#[allow(clippy::too_many_lines)]
fn append_vortex_run_local_primitive_execution_fields(
    fields: &mut Vec<(String, String)>,
    local: Option<&shardloom_vortex::VortexLocalPrimitiveExecutionReport>,
) {
    append_vortex_run_local_primitive_resource_envelope_fields(fields, local);
    append_vortex_run_local_primitive_physical_policy_fields(fields, local);
    append_vortex_run_local_primitive_evidence_collector_fields(fields, local);
    fields.extend([
        (
            "local_primitive_streaming_scan_used".to_string(),
            local
                .is_some_and(|local| local.streaming_scan_used)
                .to_string(),
        ),
        (
            "local_primitive_full_stream_collected".to_string(),
            local
                .is_some_and(|local| local.full_stream_collected)
                .to_string(),
        ),
        (
            "local_primitive_max_parallelism_requested".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| local.max_parallelism_requested.to_string(),
            ),
        ),
        (
            "local_primitive_scan_concurrency_per_worker".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| local.scan_concurrency_per_worker.to_string(),
            ),
        ),
        (
            "local_primitive_filter_pushdown_applied".to_string(),
            local
                .is_some_and(|local| local.filter_pushdown_applied)
                .to_string(),
        ),
        (
            "local_primitive_projection_pushdown_applied".to_string(),
            local
                .is_some_and(|local| local.projection_pushdown_applied)
                .to_string(),
        ),
        (
            "local_primitive_upstream_filter_expression_used".to_string(),
            local
                .is_some_and(|local| local.upstream_filter_expression_used)
                .to_string(),
        ),
        (
            "local_primitive_upstream_projection_expression_used".to_string(),
            local
                .is_some_and(|local| local.upstream_projection_expression_used)
                .to_string(),
        ),
        (
            "local_primitive_materialization_boundary_reported".to_string(),
            local
                .is_some_and(|local| local.materialization_boundary_reported)
                .to_string(),
        ),
        (
            "local_primitive_state_budget_schema_version".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.state_budget.schema_version.clone(),
            ),
        ),
        (
            "local_primitive_state_budget_required".to_string(),
            local
                .is_some_and(|local| local.state_budget.state_budget_required)
                .to_string(),
        ),
        (
            "local_primitive_state_budget_status".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.state_budget.state_budget_status.clone(),
            ),
        ),
        (
            "local_primitive_state_pressure_class".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.state_budget.state_pressure_class.clone(),
            ),
        ),
        (
            "local_primitive_state_family".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.state_budget.state_family.clone(),
            ),
        ),
        (
            "local_primitive_capillary_work_units".to_string(),
            local.map_or_else(String::new, |local| {
                local.state_budget.capillary_work_units.join(",")
            }),
        ),
        (
            "local_primitive_pulseweave_pressure_signals".to_string(),
            local.map_or_else(String::new, |local| {
                local.state_budget.pulseweave_pressure_signals.join(",")
            }),
        ),
        (
            "local_primitive_observed_state_items".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| local.state_budget.observed_state_items.to_string(),
            ),
        ),
        (
            "local_primitive_estimated_state_items".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| {
                    local
                        .state_budget
                        .estimated_state_items
                        .map_or_else(|| "none".to_string(), |value| value.to_string())
                },
            ),
        ),
        (
            "local_primitive_budget_scope".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.state_budget.budget_scope.clone(),
            ),
        ),
        (
            "local_primitive_spill_policy".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.state_budget.spill_policy.clone(),
            ),
        ),
        (
            "local_primitive_spill_required".to_string(),
            local
                .is_some_and(|local| local.state_budget.spill_required)
                .to_string(),
        ),
        (
            "local_primitive_spill_supported".to_string(),
            local
                .is_some_and(|local| local.state_budget.spill_supported)
                .to_string(),
        ),
        (
            "local_primitive_spill_io_performed".to_string(),
            local
                .is_some_and(|local| local.state_budget.spill_io_performed)
                .to_string(),
        ),
        (
            "local_primitive_fail_closed_if_spill_required".to_string(),
            local
                .is_some_and(|local| local.state_budget.fail_closed_if_spill_required)
                .to_string(),
        ),
        (
            "local_primitive_state_budget_diagnostic_code".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.state_budget.diagnostic_code.clone(),
            ),
        ),
        (
            "local_primitive_state_budget_next_action".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.state_budget.next_action.clone(),
            ),
        ),
    ]);
    append_vortex_run_local_primitive_embedded_layout_fields(fields, local);
}

#[allow(clippy::too_many_lines)]
fn append_vortex_run_local_primitive_embedded_layout_fields(
    fields: &mut Vec<(String, String)>,
    local: Option<&shardloom_vortex::VortexLocalPrimitiveExecutionReport>,
) {
    fields.extend([
        (
            "local_primitive_embedded_layout_schema_version".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.embedded_layout.schema_version.clone(),
            ),
        ),
        (
            "local_primitive_embedded_layout_status".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.embedded_layout.status.clone(),
            ),
        ),
        (
            "local_primitive_footer_row_count".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| local.embedded_layout.footer_row_count.to_string(),
            ),
        ),
        (
            "local_primitive_footer_segment_count".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| local.embedded_layout.footer_segment_count.to_string(),
            ),
        ),
        (
            "local_primitive_footer_statistics_available".to_string(),
            local
                .is_some_and(|local| local.embedded_layout.footer_statistics_available)
                .to_string(),
        ),
        (
            "local_primitive_footer_statistics_status".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.embedded_layout.footer_statistics_status.clone(),
            ),
        ),
        (
            "local_primitive_footer_approx_bytes".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| {
                    local
                        .embedded_layout
                        .footer_approx_bytes
                        .map_or_else(|| "none".to_string(), |value| value.to_string())
                },
            ),
        ),
        (
            "local_primitive_footer_dtype_summary".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.embedded_layout.footer_dtype_summary.clone(),
            ),
        ),
        (
            "local_primitive_footer_layout_summary".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.embedded_layout.footer_layout_summary.clone(),
            ),
        ),
        (
            "local_primitive_metadata_persisted_in_artifact".to_string(),
            local
                .is_some_and(|local| local.embedded_layout.metadata_persisted_in_artifact)
                .to_string(),
        ),
        (
            "local_primitive_metadata_first_pruning_available".to_string(),
            local
                .is_some_and(|local| local.embedded_layout.metadata_first_pruning_available)
                .to_string(),
        ),
        (
            "local_primitive_metadata_first_pruning_consulted".to_string(),
            local
                .is_some_and(|local| local.embedded_layout.metadata_first_pruning_consulted)
                .to_string(),
        ),
        (
            "local_primitive_metadata_pruned_entire_input".to_string(),
            local
                .is_some_and(|local| local.embedded_layout.metadata_pruned_entire_input)
                .to_string(),
        ),
        (
            "local_primitive_selected_segment_count".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| local.embedded_layout.selected_segment_count.to_string(),
            ),
        ),
        (
            "local_primitive_skipped_segment_count".to_string(),
            local.map_or_else(
                || "0".to_string(),
                |local| local.embedded_layout.skipped_segment_count.to_string(),
            ),
        ),
        (
            "local_primitive_vortex_file_stats_reader_available".to_string(),
            local
                .is_some_and(|local| local.embedded_layout.vortex_file_stats_reader_available)
                .to_string(),
        ),
        (
            "local_primitive_planner_consumption_status".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.embedded_layout.planner_consumption_status.clone(),
            ),
        ),
        (
            "local_primitive_dictionary_encoding_policy".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.embedded_layout.dictionary_encoding_policy.clone(),
            ),
        ),
        (
            "local_primitive_late_materialization_status".to_string(),
            local.map_or_else(
                || "none".to_string(),
                |local| local.embedded_layout.late_materialization_status.clone(),
            ),
        ),
    ]);
}

fn vortex_run_human_text(
    report: &VortexLocalEngineReport,
    why_report: &VortexLocalEngineWhyReport,
    execution_certificate: Option<&ExecutionCertificate>,
) -> String {
    let certificate_text = execution_certificate.map_or_else(String::new, |certificate| {
        format!("\n\n{}", certificate.to_human_text())
    });
    format!(
        "{}\n{}{}",
        report.to_human_text(),
        why_report.to_human_text(),
        certificate_text
    )
}

fn parse_vortex_filter_project_args(
    mut args: std::vec::IntoIter<String>,
    format: OutputFormat,
    context: &CommandContext<'_>,
) -> std::result::Result<VortexFilterProjectArgs, ExitCode> {
    let Some(uri_arg) = args.next() else {
        eprintln!(
            "usage: shardloom vortex-filter-project <dataset_uri> <predicate> <columns> [--limit <rows>] [--execute-local-primitive <memory_gb> <max_parallelism>]"
        );
        return Err(ExitCode::from(2));
    };
    let Some(predicate_arg) = args.next() else {
        eprintln!(
            "usage: shardloom vortex-filter-project <dataset_uri> <predicate> <columns> [--limit <rows>] [--execute-local-primitive <memory_gb> <max_parallelism>]"
        );
        return Err(ExitCode::from(2));
    };
    let Some(columns_arg) = args.next() else {
        eprintln!(
            "usage: shardloom vortex-filter-project <dataset_uri> <predicate> <columns> [--limit <rows>] [--execute-local-primitive <memory_gb> <max_parallelism>]"
        );
        return Err(ExitCode::from(2));
    };
    let uri = DatasetUri::new(uri_arg).map_err(|error| {
        emit_error(
            "vortex-filter-project",
            format,
            "vortex filter project failed",
            &error,
        )
    })?;
    let predicate = parse_tiny_predicate(&predicate_arg).map_err(|error| {
        emit_error(
            "vortex-filter-project",
            format,
            "vortex filter project failed",
            &error,
        )
    })?;
    let projection = parse_projection_columns(&columns_arg).map_err(|error| {
        emit_error(
            "vortex-filter-project",
            format,
            "vortex filter project failed",
            &error,
        )
    })?;
    let options =
        parse_vortex_filter_project_options_in_context(&mut args, context).map_err(|error| {
            emit_error(
                "vortex-filter-project",
                format,
                "vortex filter project failed",
                &error,
            )
        })?;
    Ok(VortexFilterProjectArgs {
        uri,
        predicate_arg,
        columns_arg,
        predicate,
        projection,
        source_order_limit: options.source_order_limit,
        local_execution_request: options.local_execution_request,
    })
}

fn parse_vortex_filter_project_options_in_context(
    args: &mut impl Iterator<Item = String>,
    context: &CommandContext<'_>,
) -> shardloom_core::Result<VortexFilterProjectCliOptions> {
    let mut args = args.peekable();
    let mut execute = false;
    let mut resources = crate::execution_resources::ResourceArguments::default();
    let mut source_order_limit = None;
    while let Some(option) = args.next() {
        if resources.parse_flag(&option, &mut args)? {
            continue;
        }
        match option.as_str() {
            "--execute-local-primitive" => {
                if execute {
                    return Err(ShardLoomError::InvalidOperation(
                        "--execute-local-primitive was provided more than once".to_string(),
                    ));
                }
                execute = true;
                resources.parse_legacy_prefix(&mut args)?;
            }
            "--limit" | "--source-order-limit" => {
                if source_order_limit.is_some() {
                    return Err(ShardLoomError::InvalidOperation(
                        "source-order limit was provided more than once".to_string(),
                    ));
                }
                let Some(limit_text) = args.next() else {
                    return Err(ShardLoomError::InvalidOperation(format!(
                        "missing row limit after {option}"
                    )));
                };
                let limit = limit_text.parse::<usize>().map_err(|_| {
                    ShardLoomError::InvalidOperation(
                        "source-order limit must be an unsigned integer".to_string(),
                    )
                })?;
                if limit == 0 {
                    return Err(ShardLoomError::InvalidOperation(
                        "source-order limit must be >= 1".to_string(),
                    ));
                }
                source_order_limit = Some(limit);
            }
            other => {
                return Err(ShardLoomError::InvalidOperation(format!(
                    "unknown option: {other}"
                )));
            }
        }
    }
    let local_execution_request = if execute {
        Some(VortexLocalPrimitiveCliExecutionRequest {
            resources: context.resolve(&resources)?,
        })
    } else {
        if resources.optional()?.is_some() {
            return Err(ShardLoomError::new(
                "execution resource options require --execute-local-primitive",
            ));
        }
        None
    };
    Ok(VortexFilterProjectCliOptions {
        local_execution_request,
        source_order_limit,
    })
}

fn vortex_filter_project_local_execution(
    request: &VortexQueryPrimitiveRequest,
    local_execution_request: Option<&VortexLocalPrimitiveCliExecutionRequest>,
    format: OutputFormat,
    emit_command: &'static str,
    admission: Option<&CommandAdmission<'_>>,
) -> std::result::Result<Option<VortexLocalPrimitiveCliExecutionEvidence>, ExitCode> {
    let Some(local_request) = local_execution_request else {
        return Ok(None);
    };
    vortex_local_primitive_cli_execution_evidence(
        request,
        local_request,
        admission.expect("executing primitive has admission"),
    )
    .map(Some)
    .map_err(|error| {
        emit_error(
            emit_command,
            format,
            "vortex filter project local primitive execution failed",
            &error,
        )
    })
}

fn parse_vortex_filter_args(
    mut args: std::vec::IntoIter<String>,
    format: OutputFormat,
    context: &CommandContext<'_>,
) -> std::result::Result<VortexFilterArgs, ExitCode> {
    let Some(uri_arg) = args.next() else {
        eprintln!(
            "usage: shardloom vortex-filter <dataset_uri> <predicate> [--limit <rows>] [--execute-local-primitive <memory_gb> <max_parallelism>]"
        );
        return Err(ExitCode::from(2));
    };
    let Some(predicate_arg) = args.next() else {
        eprintln!(
            "usage: shardloom vortex-filter <dataset_uri> <predicate> [--limit <rows>] [--execute-local-primitive <memory_gb> <max_parallelism>]"
        );
        return Err(ExitCode::from(2));
    };
    let uri = DatasetUri::new(uri_arg)
        .map_err(|error| emit_error("vortex-filter", format, "vortex filter failed", &error))?;
    let predicate = parse_tiny_predicate(&predicate_arg)
        .map_err(|error| emit_error("vortex-filter", format, "vortex filter failed", &error))?;
    let options = parse_vortex_filter_project_options_in_context(&mut args, context)
        .map_err(|error| emit_error("vortex-filter", format, "vortex filter failed", &error))?;
    Ok(VortexFilterArgs {
        uri,
        predicate_arg,
        predicate,
        source_order_limit: options.source_order_limit,
        local_execution_request: options.local_execution_request,
    })
}

fn parse_vortex_bounded_local_exec_args(
    mut args: std::vec::IntoIter<String>,
    format: OutputFormat,
) -> std::result::Result<VortexBoundedLocalExecArgs, ExitCode> {
    let Some(uri_arg) = args.next() else {
        eprintln!(
            "usage: shardloom vortex-bounded-local-exec <dataset_uri> <primitive> <memory_gb> <max_parallelism>"
        );
        return Err(ExitCode::from(2));
    };
    let Some(primitive_arg) = args.next() else {
        eprintln!(
            "usage: shardloom vortex-bounded-local-exec <dataset_uri> <primitive> <memory_gb> <max_parallelism>"
        );
        return Err(ExitCode::from(2));
    };
    let resources =
        crate::execution_resources::ResourceArguments::parse_complete(args).map_err(|error| {
            emit_error(
                "vortex-bounded-local-exec",
                format,
                "invalid bounded execution resources",
                &error,
            )
        })?;
    let uri = DatasetUri::new(uri_arg).map_err(|error| {
        emit_error(
            "vortex-bounded-local-exec",
            format,
            "vortex bounded local exec failed",
            &error,
        )
    })?;
    let request = parse_vortex_primitive_request(uri.clone(), &primitive_arg).map_err(|error| {
        emit_error(
            "vortex-bounded-local-exec",
            format,
            "vortex bounded local exec failed",
            &error,
        )
    })?;
    Ok(VortexBoundedLocalExecArgs {
        uri,
        primitive_arg,
        request,
        resources,
    })
}

fn vortex_filter_local_execution(
    request: &VortexQueryPrimitiveRequest,
    local_execution_request: Option<&VortexLocalPrimitiveCliExecutionRequest>,
    format: OutputFormat,
    emit_command: &'static str,
    admission: Option<&CommandAdmission<'_>>,
) -> std::result::Result<Option<VortexLocalPrimitiveCliExecutionEvidence>, ExitCode> {
    let Some(local_request) = local_execution_request else {
        return Ok(None);
    };
    vortex_local_primitive_cli_execution_evidence(
        request,
        local_request,
        admission.expect("executing primitive has admission"),
    )
    .map(Some)
    .map_err(|error| {
        emit_error(
            emit_command,
            format,
            "vortex filter local primitive execution failed",
            &error,
        )
    })
}

fn parse_vortex_count_where_args(
    mut args: std::vec::IntoIter<String>,
    format: OutputFormat,
    context: &CommandContext<'_>,
) -> std::result::Result<
    (
        DatasetUri,
        String,
        PredicateExpr,
        Option<VortexCountWhereLocalExecutionRequest>,
    ),
    ExitCode,
> {
    let Some(uri_arg) = args.next() else {
        eprintln!(
            "usage: shardloom vortex-count-where <dataset_uri> <predicate> [--execute-local-primitive <memory_gb> <max_parallelism>]"
        );
        return Err(ExitCode::from(2));
    };
    let Some(predicate_arg) = args.next() else {
        eprintln!(
            "usage: shardloom vortex-count-where <dataset_uri> <predicate> [--execute-local-primitive <memory_gb> <max_parallelism>]"
        );
        return Err(ExitCode::from(2));
    };
    let uri = match DatasetUri::new(uri_arg) {
        Ok(uri) => uri,
        Err(error) => {
            return Err(emit_error(
                "vortex-count-where",
                format,
                "vortex count where failed",
                &error,
            ));
        }
    };
    let predicate = match parse_tiny_predicate(&predicate_arg) {
        Ok(predicate) => predicate,
        Err(error) => {
            return Err(emit_error(
                "vortex-count-where",
                format,
                "vortex count where failed",
                &error,
            ));
        }
    };
    let local_execution_request =
        match parse_vortex_local_primitive_cli_execution_args_in_context(&mut args, context) {
            Ok(request) => request,
            Err(error) => {
                return Err(emit_error(
                    "vortex-count-where",
                    format,
                    "vortex count where failed",
                    &error,
                ));
            }
        };
    Ok((uri, predicate_arg, predicate, local_execution_request))
}

fn handle_vortex_count_metadata(
    uri: DatasetUri,
    resources: ExecutionResources,
    format: OutputFormat,
    admission: &CommandAdmission<'_>,
) -> ExitCode {
    if let Err(error) = admission.check() {
        return emit_error("vortex-count", format, "vortex count failed", &error);
    }
    let request = VortexQueryPrimitiveRequest::count_all(uri.clone());
    let open = open_vortex_metadata_only(VortexMetadataOpenRequest::metadata_only(uri, resources));
    let summary = if let Ok(report) = open {
        if let Some(summary) = report.metadata_summary {
            summary
        } else if report.has_errors() {
            let mut degraded =
                summarize_vortex_metadata_probe(&VortexMetadataProbeReport::deferred_api_unclear());
            degraded.diagnostics.extend(report.diagnostics.clone());
            degraded
        } else {
            summarize_vortex_metadata_probe(&VortexMetadataProbeReport::deferred_api_unclear())
        }
    } else {
        summarize_vortex_metadata_probe(&VortexMetadataProbeReport::deferred_api_unclear())
    };
    let result = match evaluate_vortex_query_primitive(request, &summary) {
        Ok(result) => result,
        Err(error) => {
            return emit_error("vortex-count", format, "vortex count failed", &error);
        }
    };
    let count = match result.value {
        VortexQueryPrimitiveValue::Count(v) => Some(v),
        _ => None,
    };
    let status = if result.has_errors() || count.is_none() {
        CommandStatus::Unsupported
    } else {
        CommandStatus::Success
    };
    let mut resource_fields = Vec::new();
    crate::execution_resources::append_declaration_fields(&mut resource_fields, resources);
    crate::execution_resources::append_spill_observation_fields(
        &mut resource_fields,
        false,
        Some(0),
    );
    emit(
        "vortex-count",
        format,
        status,
        "vortex count primitive".to_string(),
        result.to_human_text(),
        result.diagnostics.clone(),
        resource_fields
            .into_iter()
            .chain([
                (
                    "fallback_execution_allowed".to_string(),
                    "false".to_string(),
                ),
                ("mode".to_string(), "vortex_count".to_string()),
                ("primitive".to_string(), "count_all".to_string()),
                (
                    "explicit_local_encoded_count_requested".to_string(),
                    "false".to_string(),
                ),
                ("data_read".to_string(), "false".to_string()),
                ("data_decoded".to_string(), "false".to_string()),
                ("data_materialized".to_string(), "false".to_string()),
                ("object_store_io".to_string(), "false".to_string()),
                ("write_io".to_string(), "false".to_string()),
                ("spill_io_performed".to_string(), "false".to_string()),
                (
                    "execution".to_string(),
                    "metadata_only_or_not_performed".to_string(),
                ),
                ("result_known".to_string(), count.is_some().to_string()),
                (
                    "count".to_string(),
                    count.map_or_else(|| "unknown".to_string(), |v| v.to_string()),
                ),
            ])
            .collect(),
    );
    if result.has_errors() || count.is_none() {
        ExitCode::from(1)
    } else {
        ExitCode::SUCCESS
    }
}

fn handle_vortex_count_local_encoded(
    uri: DatasetUri,
    resources: ExecutionResources,
    format: OutputFormat,
    admission: &CommandAdmission<'_>,
) -> ExitCode {
    if let Err(error) = admission.check() {
        return emit_error("vortex-count", format, "vortex count failed", &error);
    }
    let result =
        build_vortex_encoded_count_readiness(uri.clone(), resources).and_then(|readiness| {
            run_vortex_approved_local_encoded_count_with_admission(
                uri.clone(),
                &readiness,
                Some(admission),
            )
        });
    let (encoded_report, local_report) = match result {
        Ok(reports) => reports,
        Err(error) => {
            return emit_error("vortex-count", format, "vortex count failed", &error);
        }
    };
    let streaming_plan = match build_vortex_count_local_streaming_batch_plan(uri, resources) {
        Ok(report) => report,
        Err(error) => {
            return emit_error(
                "vortex-count",
                format,
                "vortex streaming-batch runtime evidence failed",
                &error,
            );
        }
    };
    let streaming_report =
        shardloom_vortex::execute_vortex_streaming_batches_from_local_encoded_count(
            streaming_plan,
            encoded_report.clone(),
        );
    let local_execution_failed = local_report.has_errors();
    let evidence = match vortex_count_local_encoded_evidence(&encoded_report, &local_report) {
        Ok(evidence) => evidence,
        Err(error) => {
            return emit_error(
                "vortex-count",
                format,
                "vortex count evidence failed",
                &error,
            );
        }
    };
    let mut diagnostics = encoded_report.diagnostics.clone();
    diagnostics.extend(local_report.diagnostics.clone());
    diagnostics.extend(streaming_report.diagnostics.clone());
    diagnostics.extend(evidence.diagnostics());
    let mut human_sections = vec![encoded_report.to_human_text(), local_report.to_human_text()];
    human_sections.push(streaming_report.to_human_text());
    human_sections.extend(evidence.human_sections());
    let human_text = human_sections.join("\n\n");
    let fields = vortex_count_local_encoded_fields(
        resources,
        &encoded_report,
        &local_report,
        &streaming_report,
        &evidence,
    );
    emit(
        "vortex-count",
        format,
        if encoded_report.has_errors()
            || local_execution_failed
            || streaming_report.has_errors()
            || evidence.has_errors()
        {
            CommandStatus::Unsupported
        } else {
            CommandStatus::Success
        },
        "vortex local encoded count execution".to_string(),
        human_text,
        diagnostics,
        fields,
    );
    if encoded_report.has_errors()
        || local_execution_failed
        || streaming_report.has_errors()
        || evidence.has_errors()
    {
        ExitCode::from(1)
    } else {
        ExitCode::SUCCESS
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn aggregate_and_sort_null_order_payloads_are_explicit_and_checked() {
        use shardloom_vortex::relational_query::VortexRelationalNullOrder::{First, Last};
        for (name, nulls) in [("first", First), ("last", Last)] {
            for descending in [false, true] {
                let order =
                    serde_json::json!([{"column":"cohort","descending":descending,"nulls":name}]);
                let aggregate = serde_json::json!({"group_by":["cohort"],"measures":[{"function":"count","alias":"n"}],"order_by":order});
                let request = parse_simple_aggregate_primitive_request(
                    DatasetUri::new("absent.vortex").unwrap(),
                    &aggregate.to_string(),
                )
                .unwrap();
                let bound = &request.simple_aggregate.unwrap().order_by[0];
                assert_eq!(bound.nulls, Some(nulls));
                assert_eq!(bound.descending, descending);
                assert!(bound.summary().ends_with(&format!("nulls {name}")));
                let sort = serde_json::json!({"order_by":order,"limit":3});
                let request = parse_sort_rows_primitive_request(
                    DatasetUri::new("absent.vortex").unwrap(),
                    &sort.to_string(),
                    None,
                    None,
                )
                .unwrap();
                assert_eq!(request.sort_rows.unwrap().order_by[0], *bound);
            }
        }
        for value in [
            serde_json::json!("middle"),
            serde_json::json!(false),
            serde_json::json!(0),
            serde_json::Value::Null,
        ] {
            let object = serde_json::json!({"order_by":[{"column":"cohort","nulls":value}]})
                .as_object()
                .unwrap()
                .clone();
            let error =
                json_optional_aggregate_order_array_field_any(&object, &["order_by"]).unwrap_err();
            assert!(error.to_string().contains("nulls must be"));
        }
        assert_eq!(
            VortexAggregateOrderExpr::new("cohort", false).summary(),
            "cohort asc"
        );
        assert_eq!(
            VortexAggregateOrderExpr::new("cohort", true).summary(),
            "cohort desc"
        );
    }

    #[test]
    fn native_sort_spill_parser_admits_explicit_bytes_without_workspace_effects() {
        let workspace =
            std::env::temp_dir().join(format!("absent-sort-parser-{}", std::process::id()));
        assert!(!workspace.exists());
        let mut payload = serde_json::json!({"order_by":[{"column":"priority","descending":true}], "offset":45003,"limit":7,
            "spill":{"workspace":workspace,"quota_bytes":33_554_432,"memory_bytes":4_194_304}});
        let parse = |value: &serde_json::Value| {
            parse_sort_rows_primitive_request(
                DatasetUri::new("/source.vortex").unwrap(),
                &value.to_string(),
                None,
                None,
            )
        };
        let request = parse(&payload).unwrap();
        let sort = request.sort_rows.unwrap();
        assert_eq!(sort.offset, 45003);
        assert_eq!(request.source_order_limit, Some(7));
        let spill = sort.spill.unwrap();
        assert_eq!(spill.workspace, workspace);
        assert_eq!(spill.memory_bytes, 4_194_304);
        assert_eq!(spill.quota_bytes, 33_554_432);
        assert!(!workspace.exists());
        payload["spill"]["workspace"] = serde_json::json!("relative");
        assert!(parse(&payload).is_err());
        payload["spill"]["workspace"] = serde_json::json!(workspace);
        for invalid in [
            serde_json::json!(-1),
            serde_json::json!(0),
            serde_json::json!("many"),
            serde_json::Value::Null,
        ] {
            payload["spill"]["quota_bytes"] = invalid;
            assert!(parse(&payload).is_err());
        }
        assert!(!workspace.exists());
    }

    fn test_field(fields: &[(String, String)], key: &str) -> String {
        fields
            .iter()
            .find_map(|(field_key, value)| (field_key == key).then_some(value.clone()))
            .unwrap_or_else(|| panic!("missing field {key}"))
    }

    #[test]
    fn absent_local_report_does_not_infer_answer_cache_evidence() {
        let mut fields = Vec::new();
        append_vortex_local_primitive_execution_report_fields(&mut fields, None);
        assert_eq!(
            test_field(&fields, "local_primitive_report_present"),
            "false"
        );
        assert_eq!(
            fields
                .iter()
                .filter(|(key, _)| key == "local_primitive_no_query_answer_cache")
                .map(|(_, value)| value.as_str())
                .collect::<Vec<_>>(),
            ["false"]
        );
    }

    #[test]
    fn shared_report_preserves_strategy_and_measured_worker_fields() {
        let mut report = shardloom_vortex::VortexLocalPrimitiveExecutionReport::feature_disabled(
            shardloom_vortex::VortexQueryPrimitiveKind::SimpleAggregate,
            shardloom_vortex::VortexLocalPrimitiveResourceEnvelope::new(4, 1).unwrap(),
        );
        report.result_summary = Some(format!(
            "simple_aggregate values={}",
            serde_json::json!({
                "aggregate_worker_selection": "small_numeric_count_direct",
                "aggregate_workers_peak_active_workers": 2,
                "aggregate_workers_outstanding_chunks": 0,
                "aggregate_result_serialized_json_round_trip": false,
                "group_output_strategy": "native_fixture",
            })
        ));
        report.scan_columns = Some(
            shardloom_vortex::local_primitives::VortexLocalPrimitiveScanColumns {
                projection_columns: vec!["source_value".into()],
                predicate_columns: vec!["source_filter".into()],
                metadata_completed: false,
            },
        );
        let mut actual = Vec::new();
        append_vortex_local_primitive_execution_report_fields(&mut actual, Some(&report));
        let mut expected = Vec::new();
        crate::public_workflow_route::append_native_scan_column_fields(&mut expected, &report);
        crate::public_workflow_route::append_local_primitive_result_summary_evidence_fields(
            &mut expected,
            report.result_summary.as_deref(),
        );
        assert_eq!(expected.len(), 9);
        for field in expected {
            assert_eq!(
                actual
                    .iter()
                    .filter(|candidate| candidate.0 == field.0)
                    .collect::<Vec<_>>(),
                [&field]
            );
        }
        assert!(
            !actual
                .iter()
                .any(|(key, _)| key == "local_primitive_aggregate_workers_submitted_chunks")
        );
    }

    #[test]
    fn vortex_run_timing_surface_fields_stay_hot_runtime_only() {
        let mut fields = Vec::new();

        append_vortex_run_timing_surface_fields(&mut fields);

        assert_eq!(test_field(&fields, "timing_surface"), "hot_runtime");
        assert_eq!(test_field(&fields, "actual_evidence_tier"), "metadata_sink");
        assert_eq!(test_field(&fields, "route_total_timing_reported"), "false");
        assert_eq!(
            test_field(&fields, "result_sink_timing_included_in_route_total"),
            "false"
        );
        assert_eq!(
            test_field(&fields, "evidence_render_timing_included_in_route_total"),
            "false"
        );
        assert_eq!(
            test_field(&fields, "timing_claim_boundary"),
            "runtime_route_evidence_only_no_benchmark_or_publication_claim"
        );
    }

    #[test]
    fn decimal_output_legacy_json_aggregate_options_are_never_silently_dropped() {
        let uri = DatasetUri::new("absent-decimal-admission.vortex").unwrap();
        for field in ["decimal_output", "precision", "scale", "rounding"] {
            let mut value = serde_json::json!({"function":"sum", "column":"amount"});
            value[field] = serde_json::json!(null);
            let request = format!("aggregate:{value}");
            let error = parse_vortex_primitive_request(uri.clone(), &request).unwrap_err();
            assert!(
                error
                    .to_string()
                    .contains("decimal output options require the native SQL or relation surface"),
                "{error}"
            );
        }
        assert!(
            parse_vortex_primitive_request(
                uri,
                r#"aggregate:{"function":"sum","column":"amount"}"#
            )
            .is_ok()
        );
    }

    #[test]
    fn parse_grouped_aggregate_payload_preserves_group_columns() {
        let uri = DatasetUri::new("target/input.vortex").expect("uri");
        let request = parse_vortex_primitive_request(
            uri,
            r#"aggregate:{"group_by":["label"],"measures":[{"function":"count","alias":"rows"},{"function":"sum","column":"amount","alias":"total_amount"}]}"#,
        )
        .expect("grouped aggregate request");
        let aggregate = request.simple_aggregate.expect("aggregate payload");

        assert_eq!(
            aggregate
                .group_by
                .iter()
                .map(ColumnRef::as_str)
                .collect::<Vec<_>>(),
            vec!["label"]
        );
        assert_eq!(aggregate.measures.len(), 2);
        assert_eq!(
            aggregate.output_columns(),
            vec!["label", "rows", "total_amount"]
        );
        let ProjectionRequest::Columns(columns) = &request.projection else {
            panic!("expected explicit projected columns");
        };
        assert_eq!(
            columns.iter().map(ColumnRef::as_str).collect::<Vec<_>>(),
            vec!["label", "amount"]
        );
    }

    #[test]
    fn parse_filtered_ordered_aggregate_payload_preserves_runtime_shape() {
        let uri = DatasetUri::new("target/input.vortex").expect("uri");
        let request = parse_vortex_primitive_request(
            uri,
            r#"aggregate-filter:and(neq:SearchPhrase:;gte:EventDate:2013-07-01)|{"group_by":["SearchPhrase"],"measures":[{"function":"count","alias":"c"}],"order_by":[{"column":"c","descending":true}],"offset":5}"#,
        )
        .expect("filtered ordered aggregate request");
        let aggregate = request.simple_aggregate.expect("aggregate payload");
        let predicate = request.predicate.expect("predicate");

        let PredicateExpr::And(predicates) = predicate else {
            panic!("expected conjunctive predicate");
        };
        assert_eq!(predicates.len(), 2);
        assert_eq!(
            predicates[0],
            PredicateExpr::Compare {
                column: ColumnRef::new("SearchPhrase").expect("column"),
                op: ComparisonOp::NotEq,
                value: StatValue::Utf8(String::new()),
            }
        );
        assert_eq!(
            predicates[1],
            PredicateExpr::Compare {
                column: ColumnRef::new("EventDate").expect("column"),
                op: ComparisonOp::GtEq,
                value: StatValue::Utf8("2013-07-01".to_string()),
            }
        );
        assert_eq!(
            aggregate
                .group_by
                .iter()
                .map(ColumnRef::as_str)
                .collect::<Vec<_>>(),
            vec!["SearchPhrase"]
        );
        assert_eq!(aggregate.measures.len(), 1);
        assert_eq!(aggregate.measures[0].alias, "c");
        assert_eq!(aggregate.order_by.len(), 1);
        assert_eq!(aggregate.order_by[0].column, "c");
        assert!(aggregate.order_by[0].descending);
        assert_eq!(aggregate.offset, 5);
        assert_eq!(aggregate.output_columns(), vec!["SearchPhrase", "c"]);
    }

    #[test]
    fn parse_explode_payload_preserves_selected_companion_columns() {
        let uri = DatasetUri::new("target/input.vortex").expect("uri");
        let request = parse_vortex_primitive_request(
            uri,
            r#"explode:{"column":"items","columns":"id,items"}"#,
        )
        .expect("explode request");

        assert_eq!(
            request.kind,
            shardloom_vortex::VortexQueryPrimitiveKind::ExplodeRows
        );
        let ProjectionRequest::Columns(columns) = &request.projection else {
            panic!("expected explicit projected columns");
        };
        assert_eq!(
            columns.iter().map(ColumnRef::as_str).collect::<Vec<_>>(),
            vec!["id", "items"]
        );
        let explode_projection = request.explode_projection.expect("explode projection");
        assert_eq!(explode_projection.column.as_str(), "items");
    }

    #[test]
    fn parse_explode_payload_accepts_multi_column_explode() {
        let uri = DatasetUri::new("target/input.vortex").expect("uri");
        let request = parse_vortex_primitive_request(
            uri,
            r#"explode:{"explode_columns":["items","labels"],"output_columns":["id","items","labels"]}"#,
        )
        .expect("multi-column explode request");

        assert_eq!(
            request.kind,
            shardloom_vortex::VortexQueryPrimitiveKind::ExplodeRows
        );
        let ProjectionRequest::Columns(columns) = &request.projection else {
            panic!("expected explicit projected columns");
        };
        assert_eq!(
            columns.iter().map(ColumnRef::as_str).collect::<Vec<_>>(),
            vec!["id", "items", "labels"]
        );
        let explode_projection = request.explode_projection.expect("explode projection");
        assert_eq!(
            explode_projection
                .explode_columns()
                .iter()
                .map(ColumnRef::as_str)
                .collect::<Vec<_>>(),
            vec!["items", "labels"]
        );
    }

    #[test]
    fn parse_expression_project_payload_accepts_typed_json_null_rewrite() {
        let uri = DatasetUri::new("target/input.vortex").expect("uri");
        let request = parse_vortex_primitive_request(
            uri,
            r#"expression_project:{"columns":["id","amount"],"rewrites":[{"kind":"mask_scalar","target_column":"amount","predicate":"lt:amount:0","replacement":{"type":"null","value":null}}]}"#,
        )
        .expect("expression project request");

        assert_eq!(
            request.kind,
            shardloom_vortex::VortexQueryPrimitiveKind::ExpressionProjectRows
        );
        let projection = request
            .expression_projection
            .expect("expression projection");
        let [
            VortexExpressionRewrite::MaskScalar {
                target_column,
                replacement,
                ..
            },
        ] = projection.rewrites.as_slice()
        else {
            panic!("expected one mask rewrite");
        };
        assert_eq!(target_column.as_str(), "amount");
        assert_eq!(*replacement, ScalarValue::Null);
    }

    #[test]
    fn typed_unary_literals_preserve_exact_binary_decimal_and_temporal_values() {
        use serde_json::json;
        for (kind, raw, expected) in [
            ("binary", "00FF10", ScalarValue::Binary(vec![0, 255, 16])),
            ("binary", "", ScalarValue::Binary(vec![])),
            (
                "decimal128(38,18)",
                "12345678901234567890.123456789012345678",
                ScalarValue::Decimal128 {
                    value: 12_345_678_901_234_567_890_123_456_789_012_345_678,
                    precision: 38,
                    scale: 18,
                },
            ),
            (
                "decimal128(5,2)",
                "1.23e2",
                ScalarValue::Decimal128 {
                    value: 12300,
                    precision: 5,
                    scale: 2,
                },
            ),
            ("date32", "-2147483648", ScalarValue::Date32(i32::MIN)),
            ("date32", "2147483647", ScalarValue::Date32(i32::MAX)),
            ("date32", "1969-12-31", ScalarValue::Date32(-1)),
            (
                "timestamp_micros",
                "-9223372036854775808",
                ScalarValue::TimestampMicros(i64::MIN),
            ),
            (
                "timestamp_micros",
                "9223372036854775807",
                ScalarValue::TimestampMicros(i64::MAX),
            ),
            (
                "timestamp_micros",
                "1969-12-31T23:59:59.999999Z",
                ScalarValue::TimestampMicros(-1),
            ),
        ] {
            let payload = json!({"type":kind,"value":raw});
            assert_eq!(
                parse_expression_scalar(&payload, "replacement", NullScalarPolicy::Allow).unwrap(),
                expected
            );
            assert_eq!(json_scalar_value(&payload, "fill_value").unwrap(), expected);
            let request = parse_expression_project_primitive_request(None, &json!({
                "columns":["id","value"], "rewrites":[{"kind":"mask_scalar","target_column":"value",
                "predicate":"eq:id:1","replacement":payload}]
            }).to_string()).unwrap();
            let VortexExpressionRewrite::MaskScalar { replacement, .. } =
                &request.expression_projection.unwrap().rewrites[0]
            else {
                panic!("mask rewrite");
            };
            assert_eq!(replacement, &expected);
        }
    }

    #[test]
    fn typed_unary_literals_reject_lossy_or_malformed_declarations() {
        use serde_json::json;
        for payload in [
            json!({"type":"binary","value":"f"}),
            json!({"type":"binary","value":"zz"}),
            json!({"type":"binary","value":[0,255]}),
            json!({"type":"decimal128(2,1)","value":"10.0"}),
            json!({"type":"decimal128(3,1)","value":"1.23"}),
            json!({"type":"decimal128(39,1)","value":"1.0"}),
            json!({"type":"decimal128(5,2)","value":1.23}),
            json!({"type":"date32","value":"2147483648"}),
            json!({"type":"date32","value":"2026-02-30"}),
            json!({"type":"timestamp_micros","value":"9223372036854775808"}),
            json!({"type":"timestamp_micros","value":1}),
        ] {
            assert!(
                parse_expression_scalar(&payload, "replacement", NullScalarPolicy::Allow).is_err(),
                "{payload}"
            );
            assert!(
                json_scalar_value(&payload, "fill_value").is_err(),
                "{payload}"
            );
        }
        assert!(parse_structured_scalar(&json!({"type":"binary","value":"00ff"}), "item").is_err());
    }

    #[test]
    fn parse_expression_project_payload_rejects_null_non_replacement_scalars() {
        let numeric_uri = DatasetUri::new("target/input.vortex").expect("uri");
        let numeric_error = parse_vortex_primitive_request(
            numeric_uri,
            r#"expression_project:{"columns":["amount"],"rewrites":[{"kind":"numeric_scalar_arithmetic","target_column":"amount","operator":"+","operand":{"type":"null","value":null}}]}"#,
        )
        .expect_err("null arithmetic operands must fail closed");
        assert!(numeric_error.to_string().contains("operand"));
        assert!(numeric_error.to_string().contains("does not admit null"));

        let replace_uri = DatasetUri::new("target/input.vortex").expect("uri");
        let replace_error = parse_vortex_primitive_request(
            replace_uri,
            r#"expression_project:{"columns":["amount"],"rewrites":[{"kind":"replace_scalar","target_column":"amount","to_replace":{"type":"null","value":null},"replacement":{"type":"int64","value":0}}]}"#,
        )
        .expect_err("null match operands must fail closed");
        assert!(replace_error.to_string().contains("to_replace"));
        assert!(replace_error.to_string().contains("does not admit null"));
    }

    #[test]
    fn parse_expression_project_payload_accepts_regex_replace_rewrite() {
        let uri = DatasetUri::new("target/input.vortex").expect("uri");
        let request = parse_vortex_primitive_request(
            uri,
            r#"expression_project:{"columns":["label"],"rewrites":[{"kind":"regex_replace_scalar","target_column":"label","pattern":"^bad","replacement":"ok"}]}"#,
        )
        .expect("expression project request");

        assert_eq!(
            request.kind,
            shardloom_vortex::VortexQueryPrimitiveKind::ExpressionProjectRows
        );
        let projection = request
            .expression_projection
            .expect("expression projection");
        let [
            VortexExpressionRewrite::RegexReplaceScalar {
                target_column,
                pattern,
                replacement,
            },
        ] = projection.rewrites.as_slice()
        else {
            panic!("expected one regex replace rewrite");
        };
        assert_eq!(target_column.as_str(), "label");
        assert_eq!(pattern, "^bad");
        assert_eq!(replacement, "ok");
    }

    #[test]
    fn parse_expression_project_payload_accepts_forward_fill_null_rewrite() {
        let uri = DatasetUri::new("target/input.vortex").expect("uri");
        let request = parse_vortex_primitive_request(
            uri,
            r#"expression_project:{"columns":["amount"],"rewrites":[{"kind":"forward_fill_null","target_column":"amount","limit":2}]}"#,
        )
        .expect("expression project request");

        assert_eq!(
            request.kind,
            shardloom_vortex::VortexQueryPrimitiveKind::ExpressionProjectRows
        );
        let projection = request
            .expression_projection
            .expect("expression projection");
        let [
            VortexExpressionRewrite::ForwardFillNull {
                target_column,
                limit,
            },
        ] = projection.rewrites.as_slice()
        else {
            panic!("expected one forward-fill rewrite");
        };
        assert_eq!(target_column.as_str(), "amount");
        assert_eq!(*limit, Some(2));
    }
}
