//! Bind the shared expression IR to explicit native scalar kernels.

use super::{
    Binder, DType, Nullability, PType, Result, common_dtype, failed, field, integer,
    validate_flat_operand, validate_key, validate_key_pair, validate_name,
};
use crate::local_primitives::native_relational_expression::scalar::{
    Function, TemporalCast, decimal_operand,
};
use crate::local_primitives::native_relational_expression::{Expression, Kind, PREPARATION_BYTES};
use shardloom_core::expression::builtins::{
    self, ScalarDefinition, ScalarNullRule, ScalarTypeRule,
};
use shardloom_core::{
    BinaryOp, Expression as Input, ExpressionKind, LogicalDType, ScalarValue, UnaryOp,
};
use vortex::array::{
    dtype::{DecimalDType, StructFields},
    extension::datetime::{Date, TimeUnit, Timestamp},
    scalar::{DecimalValue, Scalar},
};

#[path = "local_primitive_relational_temporal_bind.rs"]
mod temporal_functions;

#[path = "local_primitive_relational_decimal_bind.rs"]
mod decimal_functions;

#[path = "local_primitive_relational_vector_bind.rs"]
mod vector_functions;

#[path = "local_primitive_relational_variant_bind.rs"]
mod variant_functions;

#[cfg(test)]
#[path = "local_primitive_relational_variant_expression_tests.rs"]
mod variant_tests;

#[cfg(test)]
#[path = "local_primitive_relational_literal_ownership_tests.rs"]
mod literal_ownership_tests;

#[cfg(test)]
#[path = "local_primitive_relational_vector_expression_tests.rs"]
mod vector_tests;

impl Binder<'_> {
    pub(super) fn join_condition(
        &mut self,
        condition: Option<&Input>,
        left: &[(String, DType)],
        right: &[(String, DType)],
    ) -> Result<Option<crate::local_primitives::native_relational_join::Condition>> {
        use crate::relational_query::VortexRelationalSide as Side;
        let Some(condition) = condition else {
            return Ok(None);
        };
        self.charge((left.len() + right.len()) * 8192)?;
        let mut fields = Vec::new();
        for (prefix, input) in [("left", left), ("right", right)] {
            for (name, dtype) in input {
                fields.push((format!("{prefix}.{name}"), dtype.clone()));
            }
        }
        let expression = self.expression(condition, &fields, 0)?;
        boolean(&expression.dtype)?;
        let mut used = Vec::new();
        expression.visit_columns(&mut |name| {
            if !used.iter().any(|prior: &String| prior == name) {
                used.push(name.to_owned());
            }
            Ok(())
        })?;
        fields.retain(|(name, _)| used.contains(name));
        let columns = fields
            .iter()
            .map(|(name, _)| {
                if let Some(name) = name.strip_prefix("left.") {
                    Ok((Side::Left, name.to_owned()))
                } else if let Some(name) = name.strip_prefix("right.") {
                    Ok((Side::Right, name.to_owned()))
                } else {
                    Err(failed(
                        "ON predicate requires explicit left/right column scope",
                    ))
                }
            })
            .collect::<Result<Vec<_>>>()?;
        Ok(Some(
            crate::local_primitives::native_relational_join::Condition {
                expression,
                fields,
                columns,
            },
        ))
    }

    pub(super) fn expression(
        &mut self,
        input: &Input,
        fields: &[(String, DType)],
        depth: usize,
    ) -> Result<Expression> {
        if depth > crate::relational_query::NATIVE_RECURSION_LIMIT {
            return Err(failed("recursive scalar expression exceeds 24 levels"));
        }
        // Each expression is admitted before allocation, including independent
        // projected fields in a wide schema. Do not cap their cumulative count.
        self.charge(PREPARATION_BYTES)?;
        let (dtype, kind) = match &input.kind {
            ExpressionKind::Column(column) => {
                self.charge_name(column.as_str())?;
                (
                    field(fields, column.as_str())?.clone(),
                    Kind::Column(column.as_str().to_owned()),
                )
            }
            ExpressionKind::Alias { expr, .. } => return self.expression(expr, fields, depth + 1),
            ExpressionKind::Literal(value) => return self.literal_expression(value),
            ExpressionKind::List { values } => {
                return self.list_expression(values, fields, depth, false);
            }
            ExpressionKind::Struct { fields: children } => {
                return self.struct_expression(children, fields, depth);
            }
            ExpressionKind::Unary { op, expr } => {
                return self.unary_expression(*op, expr, fields, depth);
            }
            ExpressionKind::Binary { left, op, right } => {
                let left = Box::new(self.expression(left, fields, depth + 1)?);
                let right = Box::new(self.expression(right, fields, depth + 1)?);
                let dtype = if matches!(op, BinaryOp::And | BinaryOp::Or) {
                    boolean(&left.dtype)?;
                    boolean(&right.dtype)?;
                    DType::Bool(nullable(&left.dtype, &right.dtype))
                } else {
                    arithmetic_dtype(&left.dtype, *op, &right.dtype)?
                };
                (dtype, Kind::Binary(left, *op, right))
            }
            ExpressionKind::Compare { left, op, right } => {
                let left = self.expression(left, fields, depth + 1)?;
                let right = self.expression(right, fields, depth + 1)?;
                let (left, right) = comparison_operands(self, left, right)?;
                (
                    DType::Bool(nullable(&left.dtype, &right.dtype)),
                    Kind::Compare(left, *op, right),
                )
            }
            ExpressionKind::FunctionCall { name, args } => {
                return self.function(name, args, fields, depth);
            }
            ExpressionKind::Cast { expr, target_dtype }
            | ExpressionKind::TryCast { expr, target_dtype } => {
                let child = Box::new(self.expression(expr, fields, depth + 1)?);
                let tolerant = matches!(input.kind, ExpressionKind::TryCast { .. });
                if child.dtype != DType::Null {
                    validate_flat_operand(&child.dtype)?;
                }
                let dtype = cast_dtype(&child.dtype, target_dtype, tolerant)?;
                let temporal = bind_temporal_cast(self, &child.dtype, &dtype)?;
                (
                    dtype,
                    Kind::Cast {
                        input: child,
                        tolerant,
                        temporal,
                    },
                )
            }
            ExpressionKind::RelationalValue { .. } => {
                return Err(failed(
                    "relational value has no resolved native query binding",
                ));
            }
            ExpressionKind::Unsupported { .. } => {
                return Err(failed(
                    "expression kind has no admitted native scalar kernel",
                ));
            }
        };
        Ok(Expression::new(dtype, kind))
    }

    fn unary_expression(
        &mut self,
        op: UnaryOp,
        input: &Input,
        fields: &[(String, DType)],
        depth: usize,
    ) -> Result<Expression> {
        let child = Box::new(self.expression(input, fields, depth + 1)?);
        if matches!(op, UnaryOp::IsNull | UnaryOp::IsNotNull) {
            selected_operand(&child.dtype, self.schema_scope())?;
        } else {
            scalar_operand(&child.dtype)?;
        }
        let dtype = match op {
            UnaryOp::IsNull | UnaryOp::IsNotNull => DType::Bool(Nullability::NonNullable),
            UnaryOp::Not => {
                boolean(&child.dtype)?;
                DType::Bool(child.dtype.nullability())
            }
            UnaryOp::Negate => {
                numeric(&child.dtype)?;
                if matches!(child.dtype, DType::Decimal(..)) {
                    child.dtype.clone()
                } else {
                    DType::Primitive(
                        if floating(&child.dtype) {
                            PType::F64
                        } else {
                            PType::I64
                        },
                        child.dtype.nullability(),
                    )
                }
            }
        };
        Ok(Expression::new(dtype, Kind::Unary(op, child)))
    }

    fn list_expression(
        &mut self,
        values: &[Input],
        fields: &[(String, DType)],
        depth: usize,
        dense_argument: bool,
    ) -> Result<Expression> {
        let floating_literals = values.iter().all(|value| {
            matches!(
                value.kind,
                ExpressionKind::Literal(ScalarValue::Float64(_) | ScalarValue::Null)
            )
        }) && (dense_argument
            || values.iter().any(|value| {
                matches!(value.kind, ExpressionKind::Literal(ScalarValue::Float64(_)))
            }));
        if values.len() > 128 && !floating_literals {
            return Err(failed("list constructor exceeds 128 elements"));
        }
        self.charge_fields(values.len())?;
        let values = values
            .iter()
            .map(|value| self.expression(value, fields, depth + 1))
            .collect::<Result<Vec<_>>>()?;
        let mut element = DType::Null;
        for value in &values {
            selected_operand(&value.dtype, self.schema_scope())?;
            element = common(&element, &value.dtype)?;
        }
        if element == DType::Null {
            element = if dense_argument {
                DType::Primitive(PType::F64, Nullability::Nullable)
            } else {
                DType::Bool(Nullability::Nullable)
            };
        }
        Ok(Expression::new(
            DType::List(element.into(), Nullability::NonNullable),
            Kind::List(values),
        ))
    }

    fn struct_expression(
        &mut self,
        children: &[(String, Input)],
        fields: &[(String, DType)],
        depth: usize,
    ) -> Result<Expression> {
        if children.is_empty() || children.len() > 128 {
            return Err(failed("struct constructor requires 1..=128 fields"));
        }
        self.charge_names(children.iter().map(|(name, _)| name.as_str()))?;
        let mut values = Vec::new();
        let mut output_fields = Vec::new();
        for (name, value) in children {
            validate_name(name)?;
            if output_fields.iter().any(|(prior, _)| prior == name) {
                return Err(failed("struct constructor field names must be distinct"));
            }
            let mut value = self.expression(value, fields, depth + 1)?;
            selected_operand(&value.dtype, self.schema_scope())?;
            if value.dtype == DType::Null {
                value = bound_cast(self, value, DType::Bool(Nullability::Nullable))?;
            }
            output_fields.push((name.clone(), value.dtype.clone()));
            values.push(value);
        }
        Ok(Expression::new(
            DType::Struct(
                StructFields::from_iter(output_fields),
                Nullability::NonNullable,
            ),
            Kind::Struct(values),
        ))
    }

    fn function(
        &mut self,
        name: &str,
        args: &[Input],
        fields: &[(String, DType)],
        depth: usize,
    ) -> Result<Expression> {
        let definition = builtins::scalar(name)
            .or_else(|| builtins::primitive_scalar(name))
            .ok_or_else(|| failed(&format!("function '{name}' has no admitted native kernel")))?;
        if !definition.accepts_arity(args.len()) {
            return Err(failed(&format!(
                "function '{}' requires {} through {} arguments",
                definition.name, definition.min_args, definition.max_args
            )));
        }
        if vector_functions::handles(definition.type_rule) {
            return vector_functions::bind(self, definition, args, fields, depth);
        }
        if matches!(
            definition.type_rule,
            ScalarTypeRule::VariantGet | ScalarTypeRule::VariantIsNull
        ) {
            return variant_functions::bind(self, definition, args, fields, depth);
        }
        self.charge_fields(args.len())?;
        let mut args = args
            .iter()
            .map(|arg| self.expression(arg, fields, depth + 1))
            .collect::<Result<Vec<_>>>()?;
        for argument in &args {
            selected_operand(&argument.dtype, self.schema_scope())?;
        }
        let nullability = function_nullability(definition.null_rule, &args);
        let (dtype, kind) = match definition.type_rule {
            ScalarTypeRule::Conditional => {
                let no = args.pop().expect("length bound");
                let yes = args.pop().expect("length bound");
                let condition = args.pop().expect("length bound");
                boolean(&condition.dtype)?;
                (
                    common(&yes.dtype, &no.dtype)?,
                    Kind::Conditional(Box::new(condition), Box::new(yes), Box::new(no)),
                )
            }
            ScalarTypeRule::NullIf => {
                let right = args.pop().expect("length bound");
                let left = args.pop().expect("length bound");
                // NULLIF retains its first operand's type and values.
                compatible(&left.dtype, &right.dtype, self.schema_scope())?;
                (
                    left.dtype.clone(),
                    Kind::NullIf(Box::new(left), Box::new(right)),
                )
            }
            ScalarTypeRule::Coalesce => {
                let mut dtype = DType::Null;
                for arg in &args {
                    dtype = common(&dtype, &arg.dtype)?;
                }
                (dtype, Kind::Coalesce(args))
            }
            _ => return self.scalar_function(definition, args),
        };
        Ok(Expression::new(dtype.with_nullability(nullability), kind))
    }

    fn scalar_function(
        &mut self,
        definition: &ScalarDefinition,
        args: Vec<Expression>,
    ) -> Result<Expression> {
        use crate::local_primitives::native_relational_expression::scalar::Function as F;
        for argument in &args {
            scalar_operand(&argument.dtype)?;
        }
        if definition.type_rule == ScalarTypeRule::DecimalOutput {
            return decimal_functions::bind(definition, args);
        }
        if matches!(
            definition.type_rule,
            ScalarTypeRule::Temporal
                | ScalarTypeRule::DateField
                | ScalarTypeRule::TimestampField
                | ScalarTypeRule::DateOffset
                | ScalarTypeRule::TimestampOffset
                | ScalarTypeRule::DateDifference
                | ScalarTypeRule::TimestampDifference
        ) {
            return temporal_functions::bind(self, definition, args);
        }
        let name = definition.name;
        let function = match name {
            "is_nan" => F::IsNan,
            "is_infinite" => F::IsInfinite,
            "is_finite" => F::IsFinite,
            "signbit" => F::SignBit,
            "abs" => F::Abs,
            "floor" => F::Floor,
            "ceil" => F::Ceil,
            "round" => F::Round,
            "lower" => F::Lower,
            "upper" => F::Upper,
            "trim" => F::Trim,
            "length" => F::Length,
            "url_domain" => F::Domain { regex: false },
            "regex_domain" => F::Domain { regex: true },
            "case_search_adv_zero_referer_else_empty" => F::PrimitiveRefererCase,
            "primitive_aggregate_having" => primitive_having_function(&args)?,
            "regexp_replace" => fixed_domain_replacement(&args)?,
            "starts_with" => F::StartsWith,
            "ends_with" => F::EndsWith,
            "contains" => F::Contains,
            "regex_match" => {
                self.charge(1024 * 1024)?;
                let Kind::Literal(pattern) = &args[1].kind else {
                    return Err(failed("regular expressions require a literal pattern"));
                };
                let pattern = match pattern.value() {
                    Some(vortex::array::scalar::ScalarValue::Utf8(value)) => value.as_str(),
                    None => "",
                    _ => return Err(failed("regular expression pattern must be UTF8")),
                };
                F::Regex(
                    regex::RegexBuilder::new(pattern)
                        .size_limit(256 * 1024)
                        .dfa_size_limit(256 * 1024)
                        .build()
                        .map_err(super::vortex_error)?,
                )
            }
            "concat" => F::Concat,
            "substr" => F::Substr,
            "left" => F::Left,
            "right" => F::Right,
            "replace" => F::Replace,
            "byte_length" => F::ByteLength,
            "unhex" => F::Unhex,
            "from_base64" => F::FromBase64,
            "extract_minute" => F::EpochMinute { truncate: false },
            "date_trunc_minute" => F::EpochMinute { truncate: true },
            "json_extract" => {
                use crate::local_primitives::native_relational_expression::scalar::text_kernels::JsonPath;
                F::JsonExtract(JsonPath::parse(
                    literal_text(&args[1], "JSON path")?.unwrap_or("$"),
                )?)
            }
            "strptime" | "try_strptime" => {
                use crate::local_primitives::native_relational_expression::scalar::text_kernels::TimestampFormat;
                F::Strptime {
                    format: TimestampFormat::parse(
                        literal_text(&args[1], "timestamp format")?.unwrap_or("%Y-%m-%d"),
                    )?,
                    tolerant: name == "try_strptime",
                }
            }
            _ => {
                return Err(failed(&format!(
                    "function '{name}' has no admitted native kernel for this arity"
                )));
            }
        };
        let nullable = function_nullability(definition.null_rule, &args);
        let dtype = typed_function_dtype(definition.type_rule, &args, nullable)?;
        Ok(Expression::new(dtype, Kind::Function { function, args }))
    }

    fn literal_expression(&mut self, value: &ScalarValue) -> Result<Expression> {
        if let ScalarValue::Float64(value) = value
            && !self.session.float_policy().admits(*value)
        {
            return Err(failed(
                "nonfinite floating literals require float_policy=extended",
            ));
        }
        let bytes = match value {
            ScalarValue::Utf8(text) => text.len(),
            ScalarValue::Binary(bytes) => bytes.len(),
            ScalarValue::Temporal(value) => value.dtype().heap_bytes(),
            _ => 0,
        };
        if bytes > 0 {
            self.charge(
                bytes
                    .checked_mul(8)
                    .ok_or_else(|| failed("literal metadata overflow"))?,
            )?;
        }
        let dtype = literal_dtype(value)?;
        let scalar = match value {
            ScalarValue::Utf8(text) => {
                let bytes = self.literal_buffer(text.as_bytes())?;
                Scalar::utf8(
                    vortex::buffer::BufferString::try_from(bytes).map_err(super::vortex_error)?,
                    Nullability::NonNullable,
                )
            }
            ScalarValue::Binary(bytes) => {
                Scalar::binary(self.literal_buffer(bytes)?, Nullability::NonNullable)
            }
            _ => literal(value)?,
        };
        Ok(Expression::new(dtype, Kind::Literal(scalar)))
    }

    fn literal_buffer(&self, value: &[u8]) -> Result<vortex::buffer::ByteBuffer> {
        // Plan metadata admission above remains conservative. Payload allocation
        // also owns its own credit: a ConstantArray or extracted scalar buffer
        // can outlive both the binder and its prepared-plan metadata lease.
        let mut buffer = self
            .session
            .native_allocator()
            .allocate(value.len(), vortex::buffer::Alignment::new(1))
            .map_err(super::vortex_error)?;
        buffer.as_mut_slice().copy_from_slice(value);
        Ok(buffer.freeze())
    }
}

fn primitive_having_function(args: &[Expression]) -> Result<Function> {
    use shardloom_core::ComparisonOp as C;
    let op = match literal_text(&args[1], "primitive HAVING comparison")? {
        Some("eq") => C::Eq,
        Some("not_eq") => C::NotEq,
        Some("lt") => C::Lt,
        Some("lt_eq") => C::LtEq,
        Some("gt") => C::Gt,
        Some("gt_eq") => C::GtEq,
        _ => {
            return Err(failed(
                "primitive HAVING comparison requires an admitted literal operator",
            ));
        }
    };
    let right = crate::local_primitives::aggregate_having_value_json(
        literal_text(&args[2], "primitive HAVING value")?
            .ok_or_else(|| failed("primitive HAVING requires a nonnull literal value"))?,
    );
    Ok(Function::PrimitiveHaving { op, right })
}

fn fixed_domain_replacement(args: &[Expression]) -> Result<Function> {
    use crate::local_primitives::native_relational_expression::scalar::Function as F;

    if literal_text(&args[1], "domain replacement pattern")?
        != Some(r"^https?://(?:www\.)?([^/]+)/.*$")
        || literal_text(&args[2], "domain replacement capture")? != Some(r"\1")
    {
        return Err(failed(
            "REGEXP_REPLACE admits only the fixed HTTP(S) domain capture; arbitrary regex replacement is unsupported",
        ));
    }
    Ok(F::Domain { regex: true })
}

fn literal_text<'a>(expression: &'a Expression, label: &str) -> Result<Option<&'a str>> {
    let Kind::Literal(value) = &expression.kind else {
        return Err(failed(&format!("{label} requires a literal UTF8 argument")));
    };
    match value.value() {
        Some(vortex::array::scalar::ScalarValue::Utf8(value)) => Ok(Some(value.as_str())),
        None => Ok(None),
        _ => Err(failed(&format!("{label} requires a literal UTF8 argument"))),
    }
}

fn cast_dtype(source: &DType, target: &LogicalDType, tolerant: bool) -> Result<DType> {
    if crate::native_uuid::is_uuid(source) {
        return Err(failed(
            "UUID casts are not admitted; preserve the typed UUID column",
        ));
    }
    let nullable = if tolerant || source.is_nullable() {
        Nullability::Nullable
    } else {
        Nullability::NonNullable
    };
    let target = match target {
        LogicalDType::Boolean => DType::Bool(nullable),
        LogicalDType::Int64 => DType::Primitive(PType::I64, nullable),
        LogicalDType::UInt64 => DType::Primitive(PType::U64, nullable),
        LogicalDType::Float64 => DType::Primitive(PType::F64, nullable),
        LogicalDType::Utf8 => DType::Utf8(nullable),
        LogicalDType::Binary => DType::Binary(nullable),
        LogicalDType::Date32 => DType::Extension(Date::new(TimeUnit::Days, nullable).erased()),
        LogicalDType::TimestampMicros => {
            DType::Extension(Timestamp::new(TimeUnit::Microseconds, nullable).erased())
        }
        LogicalDType::Temporal(dtype) => crate::native_temporal::vortex_dtype(dtype, nullable)?,
        LogicalDType::Extension(_) => {
            let (precision, scale) = shardloom_core::expression::decimal128_dtype_parts(target)
                .ok_or_else(|| failed("cast target requires valid decimal128 precision/scale"))?;
            DType::Decimal(
                DecimalDType::new(precision, i8::try_from(scale).expect("validated scale")),
                nullable,
            )
        }
        _ => return Err(failed("cast target has no admitted native scalar kernel")),
    };
    let admitted = match source {
        DType::Null | DType::Utf8(_) => true,
        DType::Bool(_) => matches!(target, DType::Bool(_) | DType::Utf8(_) | DType::Binary(_)),
        DType::Primitive(..) | DType::Decimal(..) => matches!(
            target,
            DType::Primitive(..) | DType::Decimal(..) | DType::Utf8(_) | DType::Binary(_)
        ),
        DType::Binary(_) => matches!(target, DType::Utf8(_) | DType::Binary(_)),
        DType::Extension(_) => matches!(
            target,
            DType::Extension(_) | DType::Utf8(_) | DType::Binary(_)
        ),
        _ => false,
    };
    if !admitted {
        return Err(failed(
            "source and target have no admitted explicit scalar conversion",
        ));
    }
    Ok(target)
}

fn literal(value: &ScalarValue) -> Result<Scalar> {
    Ok(match value {
        ScalarValue::Null => Scalar::null(DType::Null),
        ScalarValue::Boolean(value) => Scalar::from(*value),
        ScalarValue::Int64(value) | ScalarValue::TimestampMicros(value) => Scalar::from(*value),
        ScalarValue::UInt64(value) => Scalar::from(*value),
        ScalarValue::Float64(value) => Scalar::from(*value),
        ScalarValue::Utf8(value) => Scalar::from(value.as_str()),
        ScalarValue::Binary(value) => Scalar::binary(
            vortex::buffer::ByteBuffer::copy_from(value.as_slice()),
            Nullability::NonNullable,
        ),
        ScalarValue::Decimal128 {
            value,
            precision,
            scale,
        } => {
            shardloom_core::expression::Decimal128Operand::decimal(*value, *precision, *scale)?;
            Scalar::decimal(
                DecimalValue::I128(*value),
                DecimalDType::new(*precision, i8::try_from(*scale).expect("validated scale")),
                Nullability::NonNullable,
            )
        }
        // Keep constants in their primitive storage domain. Upstream temporal
        // scalar validation uses a narrower calendar and can panic for valid i64
        // microseconds. Evaluation wraps the constant with its bound extension.
        ScalarValue::Date32(value) => Scalar::from(*value),
        ScalarValue::Temporal(value) => {
            let dtype =
                crate::native_temporal::vortex_dtype(value.dtype(), Nullability::NonNullable)?;
            value.dtype().validate_value(value.value())?;
            if crate::native_temporal::temporal_storage(&dtype) == Some(PType::I32) {
                Scalar::from(i32::try_from(value.value()).map_err(super::vortex_error)?)
            } else {
                Scalar::from(value.value())
            }
        }
        _ => {
            return Err(failed(
                "scalar literal requires an admitted flat type and finite numeric value",
            ));
        }
    })
}

/// Shared literal admission for native expression and retained unary binding.
/// This inspects metadata without allocating payload or calendar scalars.
pub(in crate::local_primitives) fn literal_dtype(value: &ScalarValue) -> Result<DType> {
    let nullability = Nullability::NonNullable;
    Ok(match value {
        ScalarValue::Null => DType::Null,
        ScalarValue::Boolean(_) => DType::Bool(nullability),
        ScalarValue::Int64(_) => DType::Primitive(PType::I64, nullability),
        ScalarValue::UInt64(_) => DType::Primitive(PType::U64, nullability),
        ScalarValue::Float64(_) => DType::Primitive(PType::F64, nullability),
        ScalarValue::Utf8(_) => DType::Utf8(nullability),
        ScalarValue::Binary(_) => DType::Binary(nullability),
        ScalarValue::Decimal128 {
            value,
            precision,
            scale,
        } => {
            shardloom_core::expression::Decimal128Operand::decimal(*value, *precision, *scale)?;
            DType::Decimal(
                DecimalDType::new(*precision, i8::try_from(*scale).expect("validated scale")),
                nullability,
            )
        }
        ScalarValue::Date32(_) => DType::Extension(Date::new(TimeUnit::Days, nullability).erased()),
        ScalarValue::TimestampMicros(_) => {
            DType::Extension(Timestamp::new(TimeUnit::Microseconds, nullability).erased())
        }
        ScalarValue::Temporal(value) => {
            value.dtype().validate_value(value.value())?;
            crate::native_temporal::vortex_dtype(value.dtype(), nullability)?
        }
        _ => {
            return Err(failed(
                "scalar literal requires an admitted flat type and finite numeric value",
            ));
        }
    })
}

fn nullable(left: &DType, right: &DType) -> Nullability {
    if left.is_nullable() || right.is_nullable() {
        Nullability::Nullable
    } else {
        Nullability::NonNullable
    }
}

fn boolean(dtype: &DType) -> Result<()> {
    if matches!(dtype, DType::Bool(_) | DType::Null) {
        Ok(())
    } else {
        Err(failed("boolean expression requires boolean operands"))
    }
}

fn numeric(dtype: &DType) -> Result<()> {
    if matches!(
        dtype,
        DType::Primitive(_, _) | DType::Decimal(..) | DType::Null
    ) {
        Ok(())
    } else {
        Err(failed(
            "arithmetic requires integer, F16/F32/F64 or admitted decimal operands",
        ))
    }
}

fn floating(dtype: &DType) -> bool {
    matches!(
        dtype,
        DType::Primitive(PType::F16 | PType::F32 | PType::F64, _)
    )
}

pub(in crate::local_primitives) fn arithmetic_dtype(
    left: &DType,
    op: BinaryOp,
    right: &DType,
) -> Result<DType> {
    numeric(left)?;
    numeric(right)?;
    if matches!(left, DType::Decimal(..)) || matches!(right, DType::Decimal(..)) {
        let (precision, scale) =
            decimal_operand(0, left)?.arithmetic_type(op, decimal_operand(0, right)?)?;
        return Ok(DType::Decimal(
            DecimalDType::new(precision, i8::try_from(scale).expect("validated scale")),
            nullable(left, right),
        ));
    }
    let dtype = if floating(left) || floating(right) {
        PType::F64
    } else {
        let common = common(left, right)?;
        match common {
            DType::Primitive(ptype, _) if integer(ptype).is_some_and(|(signed, _)| !signed) => {
                PType::U64
            }
            _ => PType::I64,
        }
    };
    Ok(DType::Primitive(dtype, nullable(left, right)))
}

fn function_nullability(rule: ScalarNullRule, args: &[Expression]) -> Nullability {
    let nullable = match rule {
        ScalarNullRule::Propagate => args.iter().any(|arg| arg.dtype.is_nullable()),
        ScalarNullRule::AlwaysNullable => true,
        ScalarNullRule::AllNullable => args.iter().all(|arg| arg.dtype.is_nullable()),
        ScalarNullRule::Branches => args[1..].iter().any(|arg| arg.dtype.is_nullable()),
        ScalarNullRule::RequiredControlValues
        | ScalarNullRule::OrderedNull
        | ScalarNullRule::NullIsFalse => false,
    };
    if nullable {
        Nullability::Nullable
    } else {
        Nullability::NonNullable
    }
}

fn primitive_function_dtype(rule: ScalarTypeRule, args: &[Expression]) -> Result<DType> {
    use ScalarTypeRule as T;
    let first = &args[0].dtype;
    match rule {
        T::PrimitiveHaving => {
            if !matches!(
                first,
                DType::Null | DType::Bool(_) | DType::Primitive(_, _) | DType::Utf8(_)
            ) || args[1..]
                .iter()
                .any(|arg| !matches!(&arg.dtype, DType::Utf8(_)))
            {
                return Err(failed(
                    "primitive HAVING requires a flat Boolean, numeric or text value and literal text parameters",
                ));
            }
            Ok(DType::Bool(Nullability::NonNullable))
        }
        T::PrimitiveRefererCase => {
            if !matches!(first, DType::Null | DType::Utf8(_))
                || args[1..].iter().any(|arg| {
                    !matches!(&arg.dtype, DType::Null)
                        && !matches!(&arg.dtype, DType::Primitive(ptype, _) if ptype.is_int())
                })
            {
                return Err(failed(
                    "primitive CASE requires UTF8 and two integer controls",
                ));
            }
            Ok(DType::Utf8(Nullability::NonNullable))
        }
        _ => Err(failed(
            "scalar definition is not a primitive compatibility kernel",
        )),
    }
}

#[expect(
    clippy::too_many_lines,
    reason = "Exhaustive shared scalar type-policy table"
)]
fn typed_function_dtype(
    rule: ScalarTypeRule,
    args: &[Expression],
    nullable: Nullability,
) -> Result<DType> {
    use ScalarTypeRule as T;
    let first = &args[0].dtype;
    let dtype = match rule {
        T::PrimitiveHaving | T::PrimitiveRefererCase => primitive_function_dtype(rule, args)?,
        T::FloatClassify => {
            if !matches!(
                first,
                DType::Null | DType::Primitive(PType::F16 | PType::F32 | PType::F64, _)
            ) {
                return Err(failed(
                    "floating classification requires Float16, Float32 or Float64",
                ));
            }
            DType::Bool(nullable)
        }
        T::EpochMinute | T::EpochTruncate => match first {
            DType::Primitive(ptype, _) if ptype.is_signed_int() => {
                DType::Primitive(PType::I64, nullable)
            }
            DType::Primitive(ptype, _) if ptype.is_unsigned_int() => {
                DType::Primitive(PType::U64, nullable)
            }
            DType::Utf8(_) if rule == T::EpochTruncate => DType::Utf8(nullable),
            DType::Utf8(_) => DType::Primitive(PType::U64, nullable),
            DType::Null => DType::Primitive(PType::I64, nullable),
            _ => {
                return Err(failed(
                    "minute functions require integer epoch seconds or timestamp text; use timestamp_minute for TimestampMicros",
                ));
            }
        },
        T::JsonText | T::TimestampParse => {
            if args
                .iter()
                .any(|arg| !matches!(arg.dtype, DType::Null | DType::Utf8(_)))
            {
                return Err(failed("text parsing requires UTF8 arguments"));
            }
            if rule == T::JsonText {
                DType::Utf8(nullable)
            } else {
                DType::Extension(Timestamp::new(TimeUnit::Microseconds, nullable).erased())
            }
        }
        T::NumericAbs | T::NumericRound if matches!(first, DType::Decimal(..)) => {
            let operand = decimal_operand(0, first)?;
            let (precision, scale) = if rule == T::NumericAbs {
                operand.precision_scale()
            } else {
                operand.round().precision_scale()
            };
            DType::Decimal(
                DecimalDType::new(precision, i8::try_from(scale).expect("validated scale")),
                nullable,
            )
        }
        T::NumericAbs | T::NumericRound => {
            numeric(first)?;
            arithmetic_dtype(first, BinaryOp::Add, first)?
        }
        T::ByteLength => {
            if !matches!(first, DType::Null | DType::Utf8(_) | DType::Binary(_)) {
                return Err(failed("byte length requires UTF8 or binary"));
            }
            DType::Primitive(PType::I64, nullable)
        }
        T::BinaryDecode => {
            if !matches!(first, DType::Null | DType::Utf8(_)) {
                return Err(failed("binary decoding requires UTF8"));
            }
            DType::Binary(nullable)
        }
        T::DecimalOutput
        | T::Temporal
        | T::DateField
        | T::TimestampField
        | T::DateDifference
        | T::TimestampDifference
        | T::DateOffset
        | T::TimestampOffset => {
            return Err(failed(
                "temporal functions require metadata-bound calendar admission",
            ));
        }
        T::VectorDimension
        | T::TensorShape
        | T::VectorValues
        | T::VectorElement
        | T::VectorSlice
        | T::VectorReduction
        | T::VectorNormalize => {
            return Err(failed("vector functions require native array binding"));
        }
        T::VariantGet | T::VariantIsNull => {
            return Err(failed("Variant functions require native array binding"));
        }
        T::Utf8 | T::Utf8Offsets | T::Utf8Length | T::Utf8Predicate => {
            return text_function_dtype(rule, args, nullable);
        }
        T::Coalesce | T::NullIf | T::Conditional => {
            return Err(failed(
                "selected-operand function requires its dedicated binding",
            ));
        }
    };
    Ok(dtype)
}

fn text_function_dtype(
    rule: ScalarTypeRule,
    args: &[Expression],
    nullable: Nullability,
) -> Result<DType> {
    for (index, arg) in args.iter().enumerate() {
        if index > 0 && rule == ScalarTypeRule::Utf8Offsets {
            if !matches!(arg.dtype, DType::Null)
                && !matches!(arg.dtype, DType::Primitive(ptype, _) if integer(ptype).is_some())
            {
                return Err(failed("substring offsets and lengths require integers"));
            }
        } else if !matches!(arg.dtype, DType::Utf8(_) | DType::Null) {
            return Err(failed("string function requires UTF8 arguments"));
        }
    }
    Ok(match rule {
        ScalarTypeRule::Utf8Length => DType::Primitive(PType::I64, nullable),
        ScalarTypeRule::Utf8Predicate => DType::Bool(nullable),
        _ => DType::Utf8(nullable),
    })
}

fn comparison_operands(
    binder: &mut Binder<'_>,
    mut left: Expression,
    mut right: Expression,
) -> Result<(Box<Expression>, Box<Expression>)> {
    if matches!(left.dtype, DType::Utf8(_))
        && crate::native_payload_schema::temporal_storage(&right.dtype).is_some()
    {
        let dtype = right.dtype.with_nullability(left.dtype.nullability());
        left = bound_cast(binder, left, dtype)?;
    }
    if matches!(right.dtype, DType::Utf8(_))
        && crate::native_payload_schema::temporal_storage(&left.dtype).is_some()
    {
        let dtype = left.dtype.with_nullability(right.dtype.nullability());
        right = bound_cast(binder, right, dtype)?;
    }
    if matches!(
        (&left.dtype, &right.dtype),
        (DType::Decimal(..), DType::Decimal(..))
    ) {
        let dtype = common(&left.dtype, &right.dtype)?;
        let left_dtype = dtype.with_nullability(left.dtype.nullability());
        let right_dtype = dtype.with_nullability(right.dtype.nullability());
        left = bound_cast(binder, left, left_dtype)?;
        right = bound_cast(binder, right, right_dtype)?;
    }
    compatible(&left.dtype, &right.dtype, binder.schema_scope())?;
    Ok((Box::new(left), Box::new(right)))
}

fn bind_temporal_cast(
    binder: &mut Binder<'_>,
    source: &DType,
    target: &DType,
) -> Result<Option<Box<TemporalCast>>> {
    binder.charge(TemporalCast::admission_bytes(source, target)?)?;
    TemporalCast::bind(source, target).map(|cast| cast.map(Box::new))
}

fn bound_cast(binder: &mut Binder<'_>, expression: Expression, dtype: DType) -> Result<Expression> {
    if expression.dtype == dtype {
        return Ok(expression);
    }
    binder.charge(PREPARATION_BYTES)?;
    let temporal = bind_temporal_cast(binder, &expression.dtype, &dtype)?;
    Ok(Expression::new(
        dtype,
        Kind::Cast {
            input: Box::new(expression),
            tolerant: false,
            temporal,
        },
    ))
}

fn compatible(
    left: &DType,
    right: &DType,
    scope: crate::native_payload_schema::Scope<'_>,
) -> Result<()> {
    selected_operand(left, scope)?;
    selected_operand(right, scope)?;
    if left == &DType::Null || right == &DType::Null {
        Ok(())
    } else {
        validate_key_pair(left, right, scope)
    }
}

fn scalar_operand(dtype: &DType) -> Result<()> {
    if dtype == &DType::Null {
        Ok(())
    } else {
        validate_flat_operand(dtype)
    }
}

fn selected_operand(dtype: &DType, scope: crate::native_payload_schema::Scope<'_>) -> Result<()> {
    if dtype == &DType::Null {
        Ok(())
    } else {
        validate_key(dtype, scope)
    }
}

fn common(left: &DType, right: &DType) -> Result<DType> {
    if left == &DType::Null {
        Ok(right.as_nullable())
    } else if right == &DType::Null {
        Ok(left.as_nullable())
    } else if matches!((left, right), (DType::Decimal(..), DType::Decimal(..))) {
        let (precision, scale) =
            decimal_operand(0, left)?.common_type(decimal_operand(0, right)?)?;
        Ok(DType::Decimal(
            DecimalDType::new(precision, i8::try_from(scale).expect("validated scale")),
            nullable(left, right),
        ))
    } else {
        common_dtype(left, right)
    }
}
