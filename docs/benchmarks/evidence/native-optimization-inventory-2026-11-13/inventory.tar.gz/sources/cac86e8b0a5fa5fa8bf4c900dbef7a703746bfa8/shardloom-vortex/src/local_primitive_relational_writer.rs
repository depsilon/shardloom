//! Existing local writers consume one execution and validate every input source.

use super::super::{VortexLocalPrimitiveRowExportFormat, VortexLocalPrimitiveRowExportReport};
use super::{
    ArrayRef, BATCH_ROWS, CancellationToken, ExecutedVortexRelational, NativeExecutionContext,
    PreparedVortexRelational, Result, VortexQueryPrimitiveRequest, failed, vortex_error,
};
use shardloom_core::{ColumnRef, DatasetUri};

#[path = "local_primitive_relational_writer_fanout.rs"]
mod fanout;
pub use fanout::{VortexRelationalOutputReplay, WrittenVortexRelationalFanout};
#[path = "local_primitive_relational_writer_report.rs"]
mod report_copy;

/// Relational execution proof and its terminal output-adapter proof.
pub struct WrittenVortexRelational {
    pub execution: ExecutedVortexRelational,
    pub output: VortexLocalPrimitiveRowExportReport,
}

impl WrittenVortexRelational {
    /// Primitive frontends expose one complete report, so include the input
    /// execution's effects as well as the terminal adapter's work.
    #[must_use]
    pub fn into_output_report(mut self) -> VortexLocalPrimitiveRowExportReport {
        self.execution.annotate_output(&mut self.output);
        self.output
    }
}

impl ExecutedVortexRelational {
    pub(in crate::local_primitives) fn annotate_output(
        &self,
        report: &mut VortexLocalPrimitiveRowExportReport,
    ) {
        let source = &self.native_io_certificate.side_effects;
        let output = &mut report.evidence.side_effects;
        output.data_read |= source.data_read;
        output.data_decoded |= source.data_decoded;
        output.data_materialized |= source.data_materialized;
        output.row_read |= source.row_read;
        output.arrow_converted |= source.arrow_converted;
        output.object_store_io |= source.object_store_io;
        output.write_io |= source.write_io;
        output.spill_io_performed |= source.spill_io_performed;
        output.external_effects_executed |= source.external_effects_executed;
        output.fallback_attempted |= source.fallback_attempted;
        output.fallback_execution_allowed |= source.fallback_execution_allowed;
        report.evidence.upstream_scan_called |= source.data_read;
    }
}

impl PreparedVortexRelational {
    /// Execute one admitted plan and replay its native result to every output
    /// adapter, staging all results before publication. The vector preserves the
    /// original Rust API; its entries carry copies of the same execution report.
    /// # Errors
    /// Propagates query, adapter, destination, generation and publication errors.
    pub fn write_many(
        &self,
        targets: &[(std::path::PathBuf, VortexLocalPrimitiveRowExportFormat)],
        overwrite: bool,
    ) -> Result<Vec<WrittenVortexRelational>> {
        self.write_many_controlled(targets, overwrite, &CancellationToken::default())
    }

    /// Use one cancellation owner for fanout execution and pre-publication validation.
    /// # Errors
    /// Propagates cancellation and the ordinary fanout/source/adapter failures.
    pub fn write_many_controlled(
        &self,
        targets: &[(std::path::PathBuf, VortexLocalPrimitiveRowExportFormat)],
        overwrite: bool,
        cancellation: &CancellationToken,
    ) -> Result<Vec<WrittenVortexRelational>> {
        let (written, mut copies) =
            self.write_many_with_completion(targets, overwrite, cancellation, None, |execution| {
                let mut copies = Vec::with_capacity(targets.len().saturating_sub(1));
                for _ in 1..targets.len() {
                    copies.push(execution.duplicate_for_writer()?);
                }
                Ok(copies)
            })?;
        copies.push(written.execution);
        Ok(copies
            .into_iter()
            .zip(written.outputs)
            .map(|(execution, output)| WrittenVortexRelational { execution, output })
            .collect())
    }

    /// Write complete results through an admitted local output adapter.
    /// # Errors
    /// Rejects aliases of either input, unsupported output schemas, resource
    /// denial and changed source generations. Failure never publishes a prefix.
    pub fn write(
        &self,
        path: &std::path::Path,
        format: VortexLocalPrimitiveRowExportFormat,
        overwrite: bool,
    ) -> Result<WrittenVortexRelational> {
        self.write_controlled(path, format, overwrite, &CancellationToken::default())
    }

    /// The supplied cancellation owner covers query execution and publication.
    /// # Errors
    /// Propagates cancellation and every failure described by `write`.
    pub fn write_controlled(
        &self,
        path: &std::path::Path,
        format: VortexLocalPrimitiveRowExportFormat,
        overwrite: bool,
        cancellation: &CancellationToken,
    ) -> Result<WrittenVortexRelational> {
        self.write_with_input(path, format, overwrite, cancellation, None)
    }

    pub(super) fn write_with_input(
        &self,
        path: &std::path::Path,
        format: VortexLocalPrimitiveRowExportFormat,
        overwrite: bool,
        cancellation: &CancellationToken,
        input: Option<super::batch_input::Provider<'_>>,
    ) -> Result<WrittenVortexRelational> {
        let sampling = self.begin_sampling_call()?;
        self.validate_batch_provider(input.is_some())?;
        let mut written =
            self.session
                .with_sources_execution(&self.sources, cancellation, |context| {
                    self.with_bound_root(context, input, |root, metrics| {
                        // This request describes only the terminal adapter's projection of the
                        // completed native columns. The relational tree has its own certificate.
                        let (_declaration_metadata, request) =
                            self.writer_request(root, context)?;
                        let plan = self.writer_plan(root)?;
                        let mut execution = None;
                        let mut producer =
            |context: &NativeExecutionContext<'_>,
             batch_rows: usize,
             consume: &mut dyn FnMut(ArrayRef) -> Result<bool>| {
                if execution.is_some() {
                    return Err(failed("relational producer was invoked twice"));
                }
                execution = Some(self.session.with_admitted_sources_execution(
                    &self.sources,
                    context,
                    |context| {
                        let mut submitted = 0u64;
                        let completed = self.consume_bound(
                            root,
                            context,
                            metrics,
                            batch_rows.min(BATCH_ROWS),
                            &mut |array| {
                                submitted = submitted
                                    .checked_add(array.len() as u64)
                                    .ok_or_else(|| failed("submitted row count overflow"))?;
                                if !consume(array)? {
                                    return Err(failed(
                                        "relational result consumer stopped before completion",
                                    ));
                                }
                                Ok(())
                            },
                        )?;
                        if completed.output_rows != submitted {
                            return Err(failed("native producer and consumer row counts disagree"));
                        }
                        let arrays_read =
                            usize::try_from(completed.scan_batches).map_err(vortex_error)?;
                        Ok((completed, arrays_read))
                    },
                )?);
                Ok(())
            };
                        let mut output = super::super::completed_result::write_stream_admitted(
                            plan,
                            &request,
                            path,
                            format,
                            overwrite,
                            self.policy,
                            &mut producer,
                            cancellation,
                            Some(context),
                        )?;
                        let (execution, arrays_read) = execution
                            .ok_or_else(|| failed("relational producer did not complete"))?;
                        debug_assert_eq!(execution.output_rows, output.rows_written);
                        output.rows_scanned = execution.scan_rows_delivered;
                        output.arrays_read_count = arrays_read;
                        Ok(WrittenVortexRelational { execution, output })
                    })
                })?;
        written.execution.runtime = self.snapshot();
        sampling.complete();
        Ok(written)
    }

    fn validate_writer_destination(
        &self,
        path: &std::path::Path,
        cancellation: &CancellationToken,
    ) -> Result<()> {
        cancellation.check()?;
        for source in &self.sources {
            source.validate_generation()?;
            if source.aliases_file(path)? {
                return Err(failed("source and output must be different files"));
            }
        }
        #[cfg(feature = "universal-format-io")]
        for source in &self.preparation_sources {
            source.validate_generation()?;
            source.validate_destination(path)?;
        }
        #[cfg(feature = "universal-format-io")]
        for source in &self.batch_sources {
            if let Some(source) = &source.local {
                source.source.validate_destination(path)?;
            }
        }
        cancellation.check()
    }

    fn writer_request(
        &self,
        root: &super::Node,
        context: &NativeExecutionContext<'_>,
    ) -> Result<(
        shardloom_exec::live_memory::MemoryLease,
        VortexQueryPrimitiveRequest,
    )> {
        let metadata = crate::native_payload_schema::reserve_names(
            context.memory(),
            root.fields.len(),
            |index| root.fields[index].0.as_str(),
        )?;
        let request = VortexQueryPrimitiveRequest::project(
            self.writer_source()?,
            shardloom_plan::ProjectionRequest::columns(
                root.fields
                    .iter()
                    .map(|(name, _)| ColumnRef::new(name))
                    .collect::<Result<Vec<_>>>()?,
            ),
        );
        Ok((metadata, request))
    }

    fn writer_plan(&self, root: &super::Node) -> Result<super::super::native_sink::NativeSinkPlan> {
        let plan = super::super::native_sink::NativeSinkPlan::produced_sources(
            self.session.clone(),
            super::DType::struct_(root.fields.clone(), super::Nullability::NonNullable),
            root.upper_rows(&self.sources).unwrap_or(u64::MAX),
            None,
            self.sources.clone(),
        )?;
        #[cfg(feature = "universal-format-io")]
        let plan = plan
            .with_preparation_sources(self.preparation_sources.clone())
            .with_columnar_sources(
                self.batch_sources
                    .iter()
                    .filter_map(|source| source.local.as_ref().map(|source| &source.source)),
            )?;
        Ok(plan)
    }

    fn writer_source(&self) -> Result<DatasetUri> {
        if let Some(path) = self.source_paths.first() {
            return DatasetUri::new(path.display().to_string());
        }
        self.memory_sources
            .first()
            .map(|(uri, _)| uri.clone())
            .or_else(|| self.batch_sources.first().map(|source| source.uri.clone()))
            .ok_or_else(|| failed("relational source is absent"))
    }
}
