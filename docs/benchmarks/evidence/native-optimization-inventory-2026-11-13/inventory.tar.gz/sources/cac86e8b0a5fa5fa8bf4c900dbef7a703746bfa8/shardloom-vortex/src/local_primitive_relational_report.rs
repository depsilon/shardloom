//! Report the native providers, explicit materialization and observation limits.

use super::{ExecutedVortexBatchInput, Metrics, Result};
use shardloom_core::{
    NativeIoAdapterFidelityReport, NativeIoCertificate, NativeIoMaterializationBoundaryReport,
    NativeIoRepresentationTransition, NativeIoSideEffectReport, NativeIoSinkRequirementReport,
    NativeIoSourceCapabilityReport, NativeIoSourcePushdownReport, RepresentationState,
};

/// Apply action evidence after selecting either a relational or primitive certificate.
pub(super) fn append_composition(
    certificate: &mut NativeIoCertificate,
    report: &crate::relational_query::VortexRelationalCompositionReport,
    limit: shardloom_core::RecursionLimit,
) {
    use std::fmt::Write as _;
    let proof = &mut certificate.source_pushdown_report.proof_basis;
    write!(proof, " recursion_limit={}", limit.get()).expect("String writes cannot fail");
    for (name, value) in report.counters() {
        write!(proof, " {name}={value}").expect("String writes cannot fail");
    }
    if report.materialized_relations > 0 || report.recursive_relations > 0 {
        certificate.source_pushdown_report.guarantee.push_str(
            ";action_retained_relations_completed;recursive_frontiers_drained;retained_owners_released_before_certification",
        );
    }
    for (kind, count, rows) in [
        (
            "materialized",
            report.materialized_relations,
            report.materialized_rows,
        ),
        (
            "recursive",
            report.recursive_relations,
            report.recursive_output_rows,
        ),
    ] {
        if count == 0 {
            continue;
        }
        certificate
            .source_pushdown_report
            .accepted_operations
            .push(format!("native_{kind}_relation"));
        if rows == 0 {
            continue;
        }
        certificate.side_effects.data_materialized = true;
        certificate.adapter_fidelity_report.materialization_required = true;
        certificate.materialization_boundaries.push(NativeIoMaterializationBoundaryReport {
            boundary_id: format!("native_relational.{kind}_retention"),
            from_state: RepresentationState::DecodedColumnar,
            to_state: RepresentationState::DecodedColumnar,
            required_by: "action_scoped_complete_native_relation_replay".into(),
            reason: "complete typed native rows are detached under the same memory and optional native spill grant; carried values retain their exact domains; replay owners are released before successful spill cleanup; copied payload bytes are reported separately and are not a decoder-byte observation".into(),
            bytes_decoded: 0,
            rows_materialized: rows,
            fidelity_loss: "none_for_bound_native_values_schema_and_nulls".into(),
            fallback_attempted: false,
        });
    }
}

#[allow(clippy::too_many_lines)] // One declarative certificate covers the same execution.
pub(super) fn certificate(
    metrics: &Metrics<'_>,
    rows: u64,
    batch_rows: usize,
    sources: usize,
    memory_sources: usize,
    input: Option<&ExecutedVortexBatchInput>,
    spill: Option<&crate::relational_query::VortexRelationalSpillReport>,
) -> Result<NativeIoCertificate> {
    let file_sources = sources;
    let batch_sources = input.map_or(0, |input| input.sources);
    let sources = file_sources + memory_sources + batch_sources;
    let columnar = input.map_or(0, |input| input.columnar_sources);
    let parquet_sources = input.map_or(0, |input| input.columnar_parquet_sources);
    let parquet_only = columnar > 0 && columnar == parquet_sources;
    let metadata_counts = input.map_or(0, |input| input.metadata_count_sources);
    let columnar_data = input.is_some_and(|input| {
        input.columnar_rows_decoded > 0 || input.columnar_schema_discovery_read_bytes > 0
    });
    let data_work = metrics.data_scans.get() > 0 || columnar_data;
    let source_kind = if parquet_only {
        "native_arrays_and_parquet"
    } else if columnar > 0 {
        "native_arrays_and_compatibility_sources"
    } else {
        "vortex"
    };
    let adapter = if parquet_only {
        "shardloom.native_relational.parquet_59_3_1_to_vortex_0_90"
    } else if columnar > 0 {
        "shardloom.native_relational.arrow_59_3_1_orc_0_9_to_vortex_0_90"
    } else {
        "shardloom.native_relational.vortex_0_90"
    };
    let source_state = if columnar > 0 {
        RepresentationState::ForeignEncoded
    } else {
        RepresentationState::VortexEncoded
    };
    let spilled = spill.is_some_and(|report| report.runs_written > 0);
    let ordering_proof = format!(
        "streaming_ordering_payload_buffer_bytes_copied={} streaming_ordering_prefix_batches={} streaming_ordering_prefix_rows_validated={} streaming_ordering_prefix_peak_retained_buffer_bytes={}",
        metrics.ordering_payload_buffer_bytes_copied.get(),
        metrics.ordering_prefix_batches.get(),
        metrics.ordering_prefix_rows_validated.get(),
        metrics.ordering_prefix_peak_retained_buffer_bytes.get(),
    );
    let set_proof = format!(
        "ordered_set_stages={} ordered_set_input_rows={} ordered_set_groups={} ordered_set_output_rows={}",
        metrics.ordered_set_stages.get(),
        metrics.ordered_set_input_rows.get(),
        metrics.ordered_set_groups.get(),
        metrics.ordered_set_output_rows.get(),
    );
    let sampling_proof = format!(
        "spillable_sampling_stages={} spillable_sampling_input_rows={} spillable_sampling_population_rows={} spillable_sampling_output_rows={} spillable_sampling_replacement_draws={} spillable_sampling_lookup_blocks={}",
        metrics.spillable_sampling_stages.get(),
        metrics.spillable_sampling_input_rows.get(),
        metrics.spillable_sampling_population_rows.get(),
        metrics.spillable_sampling_output_rows.get(),
        metrics.spillable_sampling_replacement_draws.get(),
        metrics.spillable_sampling_lookup_blocks.get(),
    );
    let unary_proof = format!(
        "spillable_unary_membership_stages={} spillable_unary_input_rows={} spillable_unary_observed_rows={} spillable_unary_groups={} spillable_unary_identity_rows={} spillable_unary_output_rows={} spillable_unary_lookup_blocks={} spillable_unary_reader_opens={} {sampling_proof}",
        metrics.spillable_unary_membership_stages.get(),
        metrics.spillable_unary_input_rows.get(),
        metrics.spillable_unary_observed_rows.get(),
        metrics.spillable_unary_groups.get(),
        metrics.spillable_unary_identity_rows.get(),
        metrics.spillable_unary_output_rows.get(),
        metrics.spillable_unary_lookup_blocks.get(),
        metrics.spillable_unary_reader_opens.get(),
    );
    let ownership_proof = input.map_or_else(String::new, |input| format!(
        "intake_columnar_buffer_bytes_copied={} intake_columnar_buffer_bytes_transferred={} intake_columnar_buffer_regions_transferred={} intake_columnar_allocation_bytes_transferred={};actual_boundary_decisions;private_reader_transfer_requires_unique_standard_allocation_and_full_capacity_credit;public_producers_copy;not_decoder_rss_or_whole_query_zero_copy",
        input.intake_columnar_buffer_bytes_copied,
        input.intake_columnar_buffer_bytes_transferred,
        input.intake_columnar_buffer_regions_transferred,
        input.intake_columnar_allocation_bytes_transferred,
    ));
    let replay_proof = input.map_or_else(String::new, |input| format!(
        "streaming_replay_sources={} streaming_replay_passes={} streaming_replay_rows={} streaming_replay_batches_detached={} streaming_replay_rows_detached={} streaming_replay_buffer_bytes_copied={} streaming_replay_spilled_sources={} streaming_replay_prefilled_sources={}",
        input.replay_sources, input.replay_passes, input.replay_rows,
        input.replay_batches_detached, input.replay_rows_detached,
        input.replay_buffer_bytes_copied, input.replay_spilled_sources,
        input.replay_prefilled_sources,
    ));
    let source_demand_proof = input.filter(|input| input.columnar_sources > 0).map_or_else(String::new, |input| {
        let prefix = if parquet_only { "parquet" } else { "source" };
        let proof = format!(
        "{prefix}_sources={} {prefix}_projected_columns={} {prefix}_available_columns={} {prefix}_physical_leaf_columns={} {prefix}_row_groups_total={} {prefix}_row_groups_read={} {prefix}_rows_decoded={} {prefix}_metadata_read_bytes={} {prefix}_data_read_bytes={} {prefix}_data_read_requests={} {prefix}_prefix_sources={} {prefix}_requested_prefix_rows={} {prefix}_files={} {prefix}_fingerprint_read_bytes={} {prefix}_content_fingerprints={};demand_reader_sources_only;query_validation_of_requested_columns_and_regions;declared_end_is_requested_region_or_prefix;fingerprinting_reads_bytes_without_validating_undemanded_pages;no_full_ingest_certification;no_prepared_input_writes;decoder_workspace_admission_is_not_an_allocator_or_rss_limit",
        input.columnar_sources, input.columnar_projected_columns, input.columnar_available_columns,
        input.columnar_physical_leaf_columns, input.columnar_row_groups_total, input.columnar_row_groups_read,
        input.columnar_rows_decoded, input.columnar_metadata_read_bytes, input.columnar_data_read_bytes, input.columnar_data_read_requests,
        input.columnar_prefix_sources, input.columnar_requested_prefix_rows,
        input.columnar_files, input.columnar_fingerprint_read_bytes,
        input.columnar_content_fingerprints.join(","),
    );
        format!("{proof};source_formats={};complete_text_schema_discovery_read_bytes={};binary_projection_uses_provider_decode;ipc_may_read_full_batch_bodies;avro_and_text_parse_record_streams;parquet_and_orc_held_metadata_can_exclude_regions_before_payload_reads;other_format_statistics_pruning_not_claimed;union_or_virtual_partition_sources_preserve_admitted_exact_count_and_mapped_exclusion;orc_prefix_selection_is_decode_only_within_selected_stripes", input.columnar_source_formats.join(","), input.columnar_schema_discovery_read_bytes)
    });
    let ranked_proof = input.filter(|input| input.ranked_sources > 0).map_or_else(String::new, |input| format!(
        "ranked_sources={} ranked_rank_columns={} ranked_rank_rows={} ranked_payload_rows={} ranked_rank_group_visits={} ranked_payload_group_visits={} ranked_rank_read_bytes={} ranked_payload_read_bytes={} ranked_selected_rows={};same_held_generation;complete_rank_dependencies_before_complete_decoded_winning_group_payload;unselected_payload_groups_unread;zero_prefix_completes_rank_only;rank_failure_precedes_payload_failure;distinct_sources_metadata_groups_once;phase_visits_reads_and_decoded_rows_include_rereads;whole_selected_group_chunks_then_native_gather;strict_worst_case_compressed_byte_saving;optional_source_capability_not_format_dispatch",
        input.ranked_sources, input.ranked_rank_columns, input.ranked_rank_rows,
        input.ranked_payload_rows, input.ranked_rank_groups, input.ranked_payload_groups,
        input.ranked_rank_read_bytes, input.ranked_payload_read_bytes, input.ranked_selected_rows,
    ));
    let subquery_population = format!(
        "spillable_subquery_stages={} spilled_subquery_stages={} spillable_subquery_input_rows={} spillable_subquery_indexed_rows={} spillable_subquery_probe_rows={} spillable_subquery_candidate_rows={} spillable_subquery_lookup_blocks={}",
        metrics.spillable_subquery_stages.get(),
        metrics.spilled_subquery_stages.get(),
        metrics.spillable_subquery_input_rows.get(),
        metrics.spillable_subquery_indexed_rows.get(),
        metrics.spillable_subquery_probe_rows.get(),
        metrics.spillable_subquery_candidate_rows.get(),
        metrics.spillable_subquery_lookup_blocks.get(),
    );
    let subquery_input = input.map_or_else(String::new, |input| format!(
        "streaming_subquery_outer_batches_detached={} streaming_subquery_outer_rows_detached={} streaming_subquery_build_batches_detached={} streaming_subquery_build_rows_detached={} streaming_subquery_validation_sources={} streaming_subquery_validation_batches={} streaming_subquery_validation_rows={}",
        input.subquery_outer_batches_detached, input.subquery_outer_rows_detached,
        input.subquery_build_batches_detached, input.subquery_build_rows_detached,
        input.subquery_validation_sources, input.subquery_validation_batches,
        input.subquery_validation_rows,
    ));
    let subquery_proof = format!("{subquery_population} {subquery_input}");
    let pivot_proof = format!(
        "spilled_pivot_stages={} spilled_pivot_input_rows={} spilled_pivot_index_rows={} spilled_pivot_domains={} spilled_pivot_cells={} spilled_pivot_lookup_blocks={} spilled_pivot_reader_opens={}",
        metrics.spilled_pivot_stages.get(),
        metrics.spilled_pivot_input_rows.get(),
        metrics.spilled_pivot_index_rows.get(),
        metrics.spilled_pivot_domains.get(),
        metrics.spilled_pivot_cells.get(),
        metrics.spilled_pivot_lookup_blocks.get(),
        metrics.spilled_pivot_reader_opens.get(),
    );
    let mut certificate = NativeIoCertificate::new(
        "native_relational.execution.v1",
        "native_vortex_sources_to_relational_batches",
        NativeIoSourceCapabilityReport {
            source_kind: source_kind.into(),
            adapter_id: adapter.into(),
            schema_discovery_status: if metrics.schema_discovery_stages.get() == 0 {
                format!("bound_before_execution_sources={sources}")
            } else {
                format!(
                    "source_schemas_prepared_before_execution_sources={sources};dynamic_schemas_bound_in_execution={}",
                    metrics.schema_discovery_stages.get()
                )
            },
            statistics_availability: if columnar > 0 {
                format!("held_parquet_row_group_metadata_sources={parquet_sources};held_orc_stripe_metadata_admitted_when_present;exact_type_compatible_facts_only;missing_ambiguous_or_unsupported_statistics_retain_regions;orc_temporal_decimal_floating_and_inexact_string_bounds_not_admitted;other_format_source_statistics_not_admitted;batch_global_statistics_unavailable;held_native_file_metadata_sources={file_sources};immutable_native_array_sources={memory_sources}")
            } else if batch_sources > 0 {
                format!(
                    "completion_aware_native_batch_sources={batch_sources};batch_global_statistics_unavailable;held_native_file_metadata_sources={file_sources};immutable_native_array_sources={memory_sources}"
                )
            } else {
                format!(
                    "held_native_file_metadata_sources={file_sources};immutable_native_array_sources={memory_sources}"
                )
            },
            pushdown_capabilities: if columnar > 0 { "bound_projection;exact_statistics_region_exclusion;native_residual_predicates;unfiltered_source_order_prefix_through_column_views" }
                else { "bound_projection_and_native_predicates" }.into(),
            encoded_representation_preserved: columnar == 0,
            range_read_capability: file_sources > 0 || columnar > 0,
            streaming_capability: true,
            object_store_capability: false,
            fallback_attempted: false,
        },
        NativeIoSourcePushdownReport {
            accepted_operations: vec!["native_bound_scan".into()],
            rejected_operations: vec![],
            guarantee: if input.is_some() {
                "declared_types_checked_each_batch;single_use_source_end_observed;all_input_buffer_owners_released_before_next_demand;declared_replay_native_owners_released_before_certification;output_ownership_detached;bound_file_generations_checked_before_and_after_final_consumer".into()
            } else {
                "bound_types_and_generation_checked_before_and_after_final_consumer".into()
            },
            proof_basis: format!(
                "scans_started={} scans_metadata_pruned={} native_batches={} delivered_scan_rows={} unary_stages={} unary_retained_state_items={} unary_stages_retaining_complete_population={} dynamic_schema_stages={} streaming_ordering_batches_detached={} streaming_ordering_rows_detached={} streaming_join_build_batches_detached={} streaming_join_build_rows_detached={} ordered_aggregate_stages={} ordered_aggregate_input_rows={} ordered_aggregate_distinct_rows={} ordered_aggregate_quantile_rows={} ordered_join_stages={} ordered_join_build_rows={} ordered_join_probe_rows={} ordered_join_candidate_rows={} ordered_join_match_records={} ordered_join_lookup_blocks={} ordered_window_stages={} ordered_window_input_rows={} ordered_window_groups={} ordered_window_partitions={} ordered_window_peer_records={} ordered_window_bounds_rows={} ordered_window_distinct_intervals={} ordered_window_distinct_events={} ordered_window_extrema_summary_rows={} ordered_window_lookup_blocks={} streaming_window_batches_detached={} streaming_window_rows_detached={} {ordering_proof} {pivot_proof} {replay_proof} {subquery_proof} {set_proof} {unary_proof} {source_demand_proof} {ownership_proof} {ranked_proof}",
                metrics.scans_started.get(),
                metrics.scans_pruned.get(),
                metrics.scan_batches.get(),
                metrics.scan_rows.get(),
                metrics.unary_stages.get(),
                metrics.unary_state_items.get(),
                metrics.unary_population_retention.get(),
                metrics.schema_discovery_stages.get(),
                metrics.ordering_batches_detached.get(),
                metrics.ordering_rows_detached.get(),
                metrics.join_build_batches_detached.get(),
                metrics.join_build_rows_detached.get(),
                metrics.ordered_aggregate_stages.get(),
                metrics.ordered_aggregate_input_rows.get(),
                metrics.ordered_aggregate_distinct_rows.get(),
                metrics.ordered_aggregate_quantile_rows.get(),
                metrics.ordered_join_stages.get(),
                metrics.ordered_join_build_rows.get(),
                metrics.ordered_join_probe_rows.get(),
                metrics.ordered_join_candidate_rows.get(),
                metrics.ordered_join_match_records.get(),
                metrics.ordered_join_lookup_blocks.get(),
                metrics.ordered_window_stages.get(),
                metrics.ordered_window_input_rows.get(),
                metrics.ordered_window_groups.get(),
                metrics.ordered_window_partitions.get(),
                metrics.ordered_window_peer_records.get(),
                metrics.ordered_window_bounds_rows.get(),
                metrics.ordered_window_distinct_intervals.get(),
                metrics.ordered_window_distinct_events.get(),
                metrics.ordered_window_extrema_summary_rows.get(),
                metrics.ordered_window_lookup_blocks.get(),
                metrics.window_batches_detached.get(),
                metrics.window_rows_detached.get()
            ),
            residual_expression: (metrics.residual_batches.get() > 0).then(|| {
                format!(
                    "bound ShardLoom native residual evaluation; batches={}",
                    metrics.residual_batches.get()
                )
            }),
            conservative_false_positive_policy: true,
            unsafe_rejected_reason: None,
            fallback_attempted: false,
        },
        if data_work {
            vec![NativeIoRepresentationTransition::new(
                source_state,
                RepresentationState::DecodedColumnar,
                true,
            )]
        } else {
            vec![]
        },
        NativeIoSinkRequirementReport {
            target_format: "native_relational_result_batches".into(),
            accepts_encoded: false,
            requires_decoded_columnar: true,
            requires_rows: false,
            preserves_metadata: false,
            requires_ordering: true,
            requires_partitioning: false,
            requires_commit: false,
            supports_streaming: true,
            max_chunk_size: Some(batch_rows as u64),
            backpressure_policy: "synchronous_consumer_controls_next_batch".into(),
        },
        NativeIoAdapterFidelityReport {
            adapter_id: adapter.into(),
            source_kind: source_kind.into(),
            sink_kind: "native_relational_result_batches".into(),
            metadata_preserved: false,
            statistics_preserved: false,
            encoded_representation_preserved: false,
            materialization_required: data_work,
            fidelity_loss: "none_for_bound_native_values_schema_and_nulls".into(),
            metadata_loss: "computed_columns_do_not_inherit_source_layouts_or_statistics".into(),
            fallback_attempted: false,
        },
        if data_work {
            vec![NativeIoMaterializationBoundaryReport {
                boundary_id: "native_relational.keys_and_selected_payload".into(),
                from_state: source_state,
                to_state: RepresentationState::DecodedColumnar,
                required_by: "typed_keys_and_bounded_native_result_consumption".into(),
                reason: format!(
                    "native key execution and native take followed by explicit compact output copies; streaming ordering input is separately compacted before retention; declared repeated streaming sources retain compact full-schema native replay under the same grant and optional query spill policy; {replay_proof}; {set_proof} {unary_proof}; distinct sets compact complete typed rows and source ordinals, reduce exact key groups, and restore first-occurrence order through the shared query owner; ordered aggregate stages={} compact typed base/distinct records, retained group keys and completed results through the same query owner; ordered join stages={} compact build/candidate/output records with exact key and ON evaluation; ordered window stages={} compact typed input, peer/frame records, exact DISTINCT interval events, extrema summaries and completed results through the same query owner; unary scalar access and retained row state use the shared operation kernels and native output builder; unary stages retaining the complete population={}; native ordering run materialization performed={spilled}; physical decoder bytes are unobserved, so the legacy numeric bytes field is not a zero-decode claim; final output buffer bytes are reported separately; reservations exclude upstream provider scratch and are not an RSS bound",
                    metrics.ordered_aggregate_stages.get(),
                    metrics.ordered_join_stages.get(),
                    metrics.ordered_window_stages.get(),
                    metrics.unary_population_retention.get()
                ),
                bytes_decoded: 0,
                rows_materialized: rows,
                fidelity_loss: "none_for_bound_scalar_values".into(),
                fallback_attempted: false,
            }]
        } else {
            vec![]
        },
        NativeIoSideEffectReport {
            data_read: data_work,
            data_decoded: data_work,
            data_materialized: data_work,
            row_read: data_work,
            arrow_converted: columnar_data,
            object_store_io: false,
            write_io: spilled,
            spill_io_performed: spilled,
            external_effects_executed: false,
            fallback_attempted: false,
            fallback_execution_allowed: false,
        },
        vec![],
    )?;
    let proof = &mut certificate.source_pushdown_report.proof_basis;
    if metadata_counts > 0 {
        use std::fmt::Write as _;
        let rows = input.map_or(0, |input| input.metadata_count_rows);
        write!(proof, " metadata_count_sources={metadata_counts} metadata_count_rows={rows};exact_nonnegative_file_and_row_group_counts;orc_requires_present_file_and_stripe_counts_with_checked_agreement;checked_u64_accumulation;complete_held_source_inventory;unfiltered_scalar_count_all;metadata_validation_only_no_page_or_value_validation;no_payload_reader;metadata_and_fingerprint_admission_reads_separate;held_generation_checked_through_final_consumer")
            .expect("String writes cannot fail");
        certificate
            .source_capability_report
            .pushdown_capabilities
            .push_str(";exact_source_metadata_count_all");
        certificate
            .source_pushdown_report
            .accepted_operations
            .push("native_source_metadata_count_all".into());
    }
    proof.push_str(" temporal_calendar_provider=jiff-0.2.35 temporal_timezone_database=");
    proof.push_str(shardloom_core::temporal::timezone::database_version());
    proof.push_str(" temporal_timezone_policy=pinned_embedded");
    Ok(certificate)
}
