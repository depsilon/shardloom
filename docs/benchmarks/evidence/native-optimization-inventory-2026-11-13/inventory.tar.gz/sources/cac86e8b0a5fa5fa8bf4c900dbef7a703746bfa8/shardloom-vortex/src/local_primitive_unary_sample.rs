//! Seed-compatible bounded top-k sampling and explicitly budgeted replacement population.

use super::{
    BATCH_ROWS, BoundUnary, NativeBatch, NativeExecutionContext, ReservedVec, Result, UnaryOutput,
    failed, values::OwnedRow,
};
use std::{borrow::Borrow as _, cmp::Ordering};

#[derive(Clone, Copy)]
pub(super) enum Score {
    Integer(u64),
    Weighted(f64),
}
impl Score {
    fn cmp(self, other: Self) -> Ordering {
        match (self, other) {
            (Self::Integer(a), Self::Integer(b)) => a.cmp(&b),
            (Self::Weighted(a), Self::Weighted(b)) => a.partial_cmp(&b).unwrap_or(Ordering::Equal),
            _ => Ordering::Equal,
        }
    }
}

pub(super) struct Candidate {
    pub(super) score: Score,
    pub(super) ordinal: usize,
    pub(super) cumulative_weight: f64,
    pub(super) row: Option<OwnedRow>,
}

pub(super) fn exact_search(population: &[Candidate], threshold: f64) -> usize {
    #[cfg(not(test))]
    {
        population.partition_point(|entry| entry.cumulative_weight < threshold)
    }
    #[cfg(test)]
    {
        super::sample_observation::partition_point(population, |entry| {
            entry.cumulative_weight < threshold
        })
    }
}

pub(super) struct Sample {
    candidates: ReservedVec<Candidate>,
    cap: usize,
    seen: usize,
    total_weight: f64,
}

impl Sample {
    pub(super) fn usage(&self) -> super::report::StateUsage {
        super::report::StateUsage {
            items: self.candidates.values.len(),
            all_input_retained: self.seen > 0
                && self
                    .candidates
                    .values
                    .iter()
                    .filter(|entry| entry.row.is_some())
                    .count()
                    == self.seen,
        }
    }
    pub(super) fn new(
        plan: &BoundUnary,
        context: &NativeExecutionContext<'_>,
        rows: Option<u64>,
    ) -> Result<Self> {
        Ok(Self {
            candidates: ReservedVec::new(context.memory())?,
            cap: match rows {
                Some(rows) => super::super::sample_target_count(
                    &plan.request,
                    usize::try_from(rows).map_err(super::vortex_error)?,
                )?,
                // An unknown fractional population must be retained under the
                // same grant; sampling never executes its input twice.
                None if plan.request.sample_fraction.is_some() => usize::MAX,
                None => plan
                    .request
                    .source_order_limit
                    .ok_or_else(|| failed("sample count is absent"))?,
            },
            seen: 0,
            total_weight: 0.0,
        })
    }

    pub(super) fn consume(
        &mut self,
        plan: &BoundUnary,
        batch: &mut NativeBatch,
        rows: usize,
        context: &NativeExecutionContext<'_>,
        payload: bool,
    ) -> Result<()> {
        let seed = plan.request.sample_seed.unwrap_or(0);
        for row in 0..rows {
            if row % 256 == 0 {
                context.check_cancelled()?;
            }
            if let Some(predicate) = &plan.predicate
                && !predicate.matches_with(&mut |column| batch.stat(column, row))?
            {
                continue;
            }
            let ordinal = self.seen;
            self.seen = self
                .seen
                .checked_add(1)
                .ok_or_else(|| failed("sample population overflow"))?;
            let weight = if let Some(column) = plan.weight_index {
                super::super::sample_weight_value(batch.stat(column, row)?.borrow())?
            } else {
                1.0
            };
            let score = if plan.weight_index.is_some() {
                Score::Weighted(super::super::deterministic_weighted_sample_score(
                    seed, ordinal, weight,
                ))
            } else {
                Score::Integer(super::super::deterministic_sample_score(seed, ordinal))
            };
            if plan.request.sample_with_replacement {
                self.total_weight += weight;
                if !self.total_weight.is_finite() {
                    return Err(failed("sample total weight must remain finite"));
                }
                self.candidates.reserve_one()?;
                self.candidates.values.push(Candidate {
                    score,
                    ordinal,
                    cumulative_weight: self.total_weight,
                    row: payload
                        .then(|| batch.row(&plan.output_indices, row, context))
                        .transpose()?,
                });
            } else if self.candidates.values.len() < self.cap {
                self.candidates.reserve_one()?;
                let slot = self.candidates.values.len();
                self.candidates.values.push(Candidate {
                    score,
                    ordinal,
                    cumulative_weight: 0.0,
                    row: payload
                        .then(|| batch.row(&plan.output_indices, row, context))
                        .transpose()?,
                });
                self.sift_up(slot);
            } else if self.cap > 0
                && score.cmp(self.candidates.values[0].score) == Ordering::Greater
            {
                self.candidates.values[0] = Candidate {
                    score,
                    ordinal,
                    cumulative_weight: 0.0,
                    row: payload
                        .then(|| batch.row(&plan.output_indices, row, context))
                        .transpose()?,
                };
                self.sift_down();
            }
        }
        Ok(())
    }

    // The later input ordinal is the worse tied candidate. This total ordering
    // makes fractional selection independent of conservative/unknown row bounds.
    fn less(&self, a: usize, b: usize) -> bool {
        let a = &self.candidates.values[a];
        let b = &self.candidates.values[b];
        a.score.cmp(b.score).then(b.ordinal.cmp(&a.ordinal)) == Ordering::Less
    }
    fn sift_up(&mut self, mut child: usize) {
        while child > 0 {
            let parent = (child - 1) / 2;
            if !self.less(child, parent) {
                break;
            }
            self.candidates.values.swap(child, parent);
            child = parent;
        }
    }
    fn sift_down(&mut self) {
        let mut parent = 0;
        loop {
            let left = parent * 2 + 1;
            if left >= self.candidates.values.len() {
                break;
            }
            let right = left + 1;
            let child = if right < self.candidates.values.len() && self.less(right, left) {
                right
            } else {
                left
            };
            if !self.less(child, parent) {
                break;
            }
            self.candidates.values.swap(child, parent);
            parent = child;
        }
    }

    pub(super) fn finish(
        mut self,
        plan: &BoundUnary,
        context: &NativeExecutionContext<'_>,
        output: &mut UnaryOutput<'_, '_>,
    ) -> Result<usize> {
        let target = super::super::sample_target_count(&plan.request, self.seen)?;
        #[cfg(test)]
        super::sample_observation::population(self.candidates.values.len(), target);
        if !plan.request.sample_with_replacement {
            self.candidates
                .values
                .sort_unstable_by(|a, b| b.score.cmp(a.score).then(a.ordinal.cmp(&b.ordinal)));
            self.candidates.values.truncate(target);
            self.candidates
                .values
                .sort_unstable_by_key(|candidate| candidate.ordinal);
        }
        let seed = plan.request.sample_seed.unwrap_or(0);
        let model = if let Some(preparation) = plan.sampling_preparation() {
            #[cfg(test)]
            super::sample_preparation::BEFORE_MODEL_PREPARATION.with_borrow_mut(|slot| {
                if let Some(before) = slot.take() {
                    before();
                }
            });
            preparation.prepare(&self.candidates.values, context.memory(), || {
                context.check_cancelled()
            })?
        } else {
            None
        };
        for start in (0..target).step_by(BATCH_ROWS) {
            context.check_cancelled()?;
            output.emit_retained(
                &plan.fields,
                (target - start).min(BATCH_ROWS),
                context,
                |row| {
                    let draw = start + row;
                    let index = if !plan.request.sample_with_replacement {
                        draw
                    } else if plan.weight_index.is_some() {
                        let threshold = super::super::deterministic_sample_unit(
                            seed ^ 0xa076_1d64_78bd_642f,
                            draw,
                        ) * self.total_weight;
                        model
                            .map_or_else(
                                || exact_search(&self.candidates.values, threshold),
                                |model| model.search(&self.candidates.values, threshold),
                            )
                            .min(self.candidates.values.len() - 1)
                    } else {
                        super::super::deterministic_sample_replacement_index(
                            seed,
                            draw,
                            self.candidates.values.len(),
                        )
                    };
                    self.candidates.values[index]
                        .row
                        .as_ref()
                        .ok_or_else(|| failed("sample retained row is absent"))
                },
                |column| column,
            )?;
        }
        Ok(self.seen)
    }
}
