//! One caller-retained aggregate request/source; every execution owns fresh state.
//! The adapter retains no query-result arrays, aggregate partials or answers.

use super::{
    LocalVortexAggregateScan, Result, ShardLoomError, SimpleAggregateStates,
    VortexLocalPrimitiveExecutionPolicy, VortexLocalPrimitiveExecutionReport,
    VortexLocalPrimitivePhysicalPolicyReport, VortexQueryPrimitiveKind,
    VortexQueryPrimitiveRequest, aggregate_count_workers, aggregate_lowering::AggregateLowering,
    local_primitive_native_io_certificate, local_vortex_path,
    read_lowered_vortex_simple_aggregate_scan, required_simple_aggregate, simple_aggregate_report,
};
use crate::resident_session::{
    NativeExecutionContext, PreparedVortexSource, ResidentSessionSnapshot, ResidentVortexSession,
    segment_reuse::SegmentReusePolicy,
};
use shardloom_exec::compute_pool::CancellationToken;
use std::fmt::Write as _;

// Bound width-dependent validation/template vectors before cloning the request
// or allocating aggregate state. This is a schema ceiling, not an RSS limit.
const MAX_PREPARED_AGGREGATE_MEASURES: usize = 1024;
const MAX_PREPARED_AGGREGATE_SHAPE_ENTRIES: usize = 1024;

#[cfg(feature = "vortex-write")]
#[path = "local_primitive_prepared_aggregate_spill.rs"]
mod spill;

/// A complete aggregate report and its actual native I/O certificate.
pub struct ExecutedVortexAggregate {
    pub report: VortexLocalPrimitiveExecutionReport,
    pub native_io_certificate: shardloom_core::NativeIoCertificate,
    pub runtime: ResidentSessionSnapshot,
}

/// Complete small row payload produced by the same native aggregate execution.
pub struct CollectedVortexAggregate {
    pub timing: super::query_timing::QueryTiming,
    pub execution: ExecutedVortexAggregate,
    pub result_jsonl: shardloom_exec::live_memory::Budgeted<String>,
    pub result_schema_json: shardloom_exec::live_memory::Budgeted<String>,
}

/// Complete typed payload and the same native execution certificate as reports.
pub struct ExecutedOwnedVortexAggregate {
    pub execution: ExecutedVortexAggregate,
    pub result: crate::resident_session::OwnedVortexResultBatch,
    #[cfg(feature = "vortex-write")]
    request: VortexQueryPrimitiveRequest,
    #[cfg(feature = "vortex-write")]
    policy: VortexLocalPrimitiveExecutionPolicy,
}

#[cfg(feature = "vortex-write")]
impl ExecutedOwnedVortexAggregate {
    /// Persist complete owned columns through the existing native/compatibility
    /// sink. This consumes the result and performs no further query execution.
    /// # Errors
    /// Rejects unsupported formats, pressure, existing targets or sink validation
    /// failures. Publication uses the sink's atomic create-if-absent contract.
    pub fn write(
        self,
        path: &std::path::Path,
        format: super::VortexLocalPrimitiveRowExportFormat,
        allow_overwrite: bool,
    ) -> Result<super::VortexLocalPrimitiveRowExportReport> {
        let mut report = super::completed_result::write(
            self.result,
            &self.request,
            path,
            format,
            allow_overwrite,
            self.policy,
        )?;
        annotate_output_count(&mut report, &self.request);
        let execution = self.execution.report;
        report.rows_scanned = execution.rows_scanned;
        report.arrays_read_count = execution.arrays_read_count;
        report.max_chunk_rows = execution.max_chunk_rows;
        report.state_budget = execution.state_budget;
        report.physical_policy = execution.physical_policy;
        report.source_order_limit_requested = execution.source_order_limit_requested;
        report.evidence.upstream_scan_called = execution.upstream_scan_called;
        report.evidence.side_effects.data_read |= execution.data_read;
        report.evidence.side_effects.data_decoded |= execution.data_decoded;
        report.evidence.side_effects.data_materialized |= execution.data_materialized;
        report.evidence.side_effects.row_read |= execution.row_read;
        report.evidence.pushdown = super::VortexLocalPrimitiveRowExportPushdownEvidence {
            filter_pushdown_applied: execution.filter_pushdown_applied,
            projection_pushdown_applied: execution.projection_pushdown_applied,
            source_order_limit_applied: execution.source_order_limit_applied,
        };
        Ok(report)
    }
}

#[cfg(feature = "vortex-write")]
pub(super) fn annotate_output_count(
    report: &mut super::VortexLocalPrimitiveRowExportReport,
    request: &VortexQueryPrimitiveRequest,
) {
    // Finalizers need not retain a complete count after HAVING and before
    // OFFSET/LIMIT. The sink observes only delivered rows, a lower bound when
    // either operation may have removed groups; never certify it as exact.
    if let Some(evidence) = report.evidence.native_array_sink.as_mut() {
        evidence.pre_limit_result_row_count_exact = request.source_order_limit.is_none()
            && request
                .simple_aggregate
                .as_ref()
                .is_some_and(|aggregate| aggregate.offset == 0);
    }
}

/// Immutable lowering plus one generation-bound file and caller-owned session.
/// SUM/AVG retain the engine's existing ordered floating-point accumulation policy.
pub struct PreparedVortexAggregate {
    request: VortexQueryPrimitiveRequest,
    source: PreparedAggregateSource,
    session: ResidentVortexSession,
    lowering: AggregateLowering,
    policy: VortexLocalPrimitiveExecutionPolicy,
    physical_policy: VortexLocalPrimitivePhysicalPolicyReport,
    worker_pool: bool,
    temporary_provider_drivers: bool,
    reuse: Option<SegmentReusePolicy>,
    #[cfg(feature = "vortex-write")]
    memory_generation: Option<crate::memory_file_generation::MemoryFileGeneration>,
}

enum PreparedAggregateSource {
    File(PreparedVortexSource),
    #[cfg(feature = "vortex-write")]
    Owned(crate::owned_array_source::OwnedArraySource),
}

impl PreparedAggregateSource {
    // Keep one fallible contract when the owned-source variant is feature-disabled.
    #[cfg_attr(not(feature = "vortex-write"), allow(clippy::unnecessary_wraps))]
    fn file(&self) -> Result<&PreparedVortexSource> {
        match self {
            Self::File(source) => Ok(source),
            #[cfg(feature = "vortex-write")]
            Self::Owned(_) => Err(failed(
                "this operation requires an explicit file-backed source",
            )),
        }
    }

    fn dtype(&self) -> &vortex::array::dtype::DType {
        match self {
            Self::File(source) => source.dtype(),
            #[cfg(feature = "vortex-write")]
            Self::Owned(source) => source.dtype(),
        }
    }

    fn parallelism(&self) -> usize {
        match self {
            Self::File(source) => source.resource_limits().1,
            #[cfg(feature = "vortex-write")]
            Self::Owned(source) => source.session().parallelism(),
        }
    }
}

/// Preparation never executes a query. Native lowering and source generations
/// are reusable independently of the aggregate's key and measure types.
/// The unretained variant remains available for API compatibility.
pub enum PreparedAggregateDisposition {
    Reusable(PreparedVortexAggregate),
    Unretained(UnretainedVortexAggregate),
}

/// A schema-declined source that can execute only once and is never cached by
/// the public worker. Its existing native aggregate semantics are unchanged.
pub struct UnretainedVortexAggregate(PreparedVortexAggregate);

impl UnretainedVortexAggregate {
    /// # Errors
    /// Returns native execution, collection-bound, generation or certificate errors.
    pub fn collect_jsonl(
        self,
        cancellation: &shardloom_exec::compute_pool::CancellationToken,
    ) -> Result<CollectedVortexAggregate> {
        let mut collected = self.0.collect_jsonl(cancellation)?;
        collected.execution.native_io_certificate.source_pushdown_report.proof_basis.push_str(
            ";aggregate_preparation_disposition=unretained_source;aggregate_lowering_reused=false",
        );
        Ok(collected)
    }

    /// # Errors
    /// Returns ordinary native execution, source-generation or certificate errors.
    pub fn execute(self) -> Result<ExecutedVortexAggregate> {
        let mut executed = self.0.execute_native()?;
        executed.native_io_certificate.source_pushdown_report.proof_basis.push_str(
            ";aggregate_preparation_disposition=unretained_source;aggregate_lowering_reused=false;aggregate_state_reused=false;no_query_answer_cache=true;independent_oracle_not_run",
        );
        Ok(executed)
    }

    /// Execute an unretained lowering under the caller's operation token.
    /// # Errors
    /// Rejects cancellation, changed inputs, resource pressure and native errors.
    pub fn execute_cancellable(
        self,
        cancellation: &CancellationToken,
    ) -> Result<ExecutedVortexAggregate> {
        let cancellation = self.0.operation_cancellation(cancellation)?;
        let mut executed = self
            .0
            .session
            .with_owned_execution(&cancellation, |context| self.0.execute_in_context(context))?;
        executed.native_io_certificate.source_pushdown_report.proof_basis.push_str(
            ";aggregate_preparation_disposition=unretained_source;aggregate_lowering_reused=false;aggregate_state_reused=false;no_query_answer_cache=true;independent_oracle_not_run",
        );
        Ok(executed)
    }
}

pub(super) fn canonical(request: &VortexQueryPrimitiveRequest) -> Result<()> {
    if request.kind != VortexQueryPrimitiveKind::SimpleAggregate
        || request.diagnostics.iter().any(|diagnostic| {
            matches!(
                diagnostic.severity,
                shardloom_core::DiagnosticSeverity::Error
                    | shardloom_core::DiagnosticSeverity::Fatal
            ) || diagnostic.fallback.attempted
        })
    {
        return Err(failed("only safe simple-aggregate requests are admitted"));
    }
    let uri = request
        .source_uri
        .as_ref()
        .ok_or_else(|| failed("source URI is required"))?;
    let aggregate = required_simple_aggregate(request)?;
    if aggregate.measures.len() > MAX_PREPARED_AGGREGATE_MEASURES {
        return Err(failed("prepared aggregates admit at most 1024 measures"));
    }
    validate_aggregate_shape(aggregate)?;
    if aggregate.spill.is_some() {
        #[cfg(feature = "vortex-write")]
        spill::validate_request(request)?;
        #[cfg(not(feature = "vortex-write"))]
        return Err(failed("explicit spill requires the vortex-write feature"));
    }
    if aggregate.measures.is_empty() || request.source_order_limit == Some(0) {
        return Err(failed(
            "requires at least one measure and a positive optional limit",
        ));
    }
    let mut expected =
        VortexQueryPrimitiveRequest::simple_aggregate(uri.clone(), aggregate.clone());
    expected.predicate.clone_from(&request.predicate);
    expected.source_order_limit = request.source_order_limit;
    expected.diagnostics.clone_from(&request.diagnostics);
    if &expected != request {
        return Err(failed(
            "unrelated operation payload or projection is not admitted",
        ));
    }
    // Reuse the execution validator before opening a source. Preparation does
    // not need a second, narrower definition of aggregate semantics.
    let columns = aggregate
        .projected_columns()
        .iter()
        .map(|column| column.as_str().to_owned())
        .collect::<Vec<_>>();
    drop(SimpleAggregateStates::new(aggregate, &columns)?);
    Ok(())
}

// Bound the combined flat syntax before cloning or projected_columns()'s
// duplicate search. Check vector lengths before visiting nested argument lists.
fn validate_aggregate_shape(aggregate: &super::VortexSimpleAggregateRequest) -> Result<()> {
    let mut remaining = MAX_PREPARED_AGGREGATE_SHAPE_ENTRIES;
    let mut admit = |count| -> Result<()> {
        remaining = remaining.checked_sub(count).ok_or_else(|| {
            failed("prepared aggregates admit at most 1024 combined grouping, expression argument, ordering and HAVING entries")
        })?;
        Ok(())
    };
    admit(aggregate.group_by.len())?;
    admit(aggregate.group_expressions.len())?;
    admit(aggregate.order_by.len())?;
    admit(aggregate.having.len())?;
    for expression in &aggregate.group_expressions {
        admit(expression.extra_columns.len())?;
    }
    Ok(())
}

fn validate_policy(policy: VortexLocalPrimitiveExecutionPolicy) -> Result<()> {
    if policy.max_parallelism == 0
        || policy.max_parallelism != policy.resource_envelope.max_parallelism
        || policy.resource_envelope.memory_budget_bytes == 0
    {
        return Err(failed(
            "requires a positive memory budget and consistent positive CPU grants",
        ));
    }
    Ok(())
}

/// Prepare with the same request-based CPU ownership used by ordinary aggregates.
/// This creates exactly one session and opens the source once.
/// # Errors
/// Rejects malformed/extra payloads and unsupported spill before opening, then unsupported
/// source/schema/predicate or resource grants, including more than 1024 measures;
/// no external executor is used.
pub fn prepare_aggregate(
    request: &VortexQueryPrimitiveRequest,
    policy: VortexLocalPrimitiveExecutionPolicy,
) -> Result<PreparedVortexAggregate> {
    canonical(request)?;
    validate_policy(policy)?;
    let session = aggregate_session(request, policy)?;
    prepare_aggregate_in_session(request, policy, &session)
}

/// Prepare an optional retained execution without evaluating any source rows.
/// Unsupported request payloads return `None` before opening. Every schema and
/// predicate accepted by native lowering retains the same prepared source.
/// File, resource and lowering errors remain errors and never trigger a retry.
/// # Errors
/// Rejects invalid resource grants, unreadable/changed sources and invalid native lowering.
pub fn prepare_aggregate_for_optional_reuse(
    request: &VortexQueryPrimitiveRequest,
    policy: VortexLocalPrimitiveExecutionPolicy,
) -> Result<Option<PreparedAggregateDisposition>> {
    if canonical(request).is_err() {
        return Ok(None);
    }
    validate_policy(policy)?;
    let session = aggregate_session(request, policy)?;
    prepare_aggregate_for_optional_reuse_in_session(
        request,
        policy,
        &session,
        &CancellationToken::default(),
    )
}

/// Prepare an optional retained aggregate using the caller's native session and
/// cancellation/deadline token. Canonically inadmissible requests return `None`
/// before the source is opened; admitted aggregates retain the reusable lowering.
///
/// # Errors
/// Rejects cancellation, invalid resource grants, unreadable or changed sources,
/// and invalid native lowering. Admission failures never retry through another path.
pub fn prepare_aggregate_for_optional_reuse_in_session(
    request: &VortexQueryPrimitiveRequest,
    policy: VortexLocalPrimitiveExecutionPolicy,
    session: &ResidentVortexSession,
    cancellation: &CancellationToken,
) -> Result<Option<PreparedAggregateDisposition>> {
    if canonical(request).is_err() {
        return Ok(None);
    }
    validate_policy(policy)?;
    cancellation.check()?;
    let operation = prepare_candidate_in_session(request, policy, session, cancellation)?;
    Ok(Some(PreparedAggregateDisposition::Reusable(operation)))
}

pub(super) fn aggregate_session(
    request: &VortexQueryPrimitiveRequest,
    policy: VortexLocalPrimitiveExecutionPolicy,
) -> Result<ResidentVortexSession> {
    // Unary/sort preparation also shares this runtime-owner constructor. Only
    // an actual aggregate payload has an aggregate-state admission requirement.
    if let Some(aggregate) = &request.simple_aggregate {
        super::admit_aggregate_state_policy(aggregate, policy.resource_envelope())?;
    }
    let (effective, _) = policy.with_physical_policy_for_request(request);
    if external_workers(request, effective.resource_envelope()) {
        ResidentVortexSession::for_external_cpu_pool(
            effective.resource_envelope.memory_budget_bytes,
            effective.resource_envelope.max_parallelism,
        )
    } else {
        ResidentVortexSession::new(
            effective.resource_envelope.memory_budget_bytes,
            effective.resource_envelope.max_parallelism,
        )
    }
}

fn external_workers(
    request: &VortexQueryPrimitiveRequest,
    envelope: super::VortexLocalPrimitiveResourceEnvelope,
) -> bool {
    #[cfg(feature = "vortex-write")]
    if request
        .simple_aggregate
        .as_ref()
        .is_some_and(|aggregate| aggregate.spill.is_some())
    {
        return super::weighted_count_spill_query::worker_request_admitted(request);
    }
    aggregate_count_workers::request_may_be_admitted(request, envelope)
}

/// Prepare in an existing session without opening another runtime. If that
/// session already owns provider drivers, aggregation uses those lanes and does
/// not simultaneously create the dedicated chunk-worker pool.
/// # Errors
/// Rejects a wider supplied session, unsupported native shape or source change.
pub fn prepare_aggregate_in_session(
    request: &VortexQueryPrimitiveRequest,
    policy: VortexLocalPrimitiveExecutionPolicy,
    session: &ResidentVortexSession,
) -> Result<PreparedVortexAggregate> {
    prepare_aggregate_in_session_controlled(request, policy, session, &CancellationToken::default())
}

/// Prepare in the existing native session under the caller's cancellation and
/// deadline token. The source, provider drivers, and memory pool are reused.
///
/// # Errors
/// Rejects cancellation, a wider supplied session, unsupported native shape,
/// source changes, and native lowering or resource-admission failures.
pub fn prepare_aggregate_in_session_controlled(
    request: &VortexQueryPrimitiveRequest,
    policy: VortexLocalPrimitiveExecutionPolicy,
    session: &ResidentVortexSession,
    cancellation: &CancellationToken,
) -> Result<PreparedVortexAggregate> {
    prepare_candidate_in_session(request, policy, session, cancellation)
}

fn prepare_candidate_in_session(
    request: &VortexQueryPrimitiveRequest,
    policy: VortexLocalPrimitiveExecutionPolicy,
    session: &ResidentVortexSession,
    cancellation: &CancellationToken,
) -> Result<PreparedVortexAggregate> {
    cancellation.check()?;
    let (policy, physical_policy) = prepared_policy(request, policy, session)?;
    cancellation.check()?;
    let uri = request
        .source_uri
        .as_ref()
        .ok_or_else(|| failed("source URI is required"))?;
    let path = local_vortex_path(uri, request.kind)?
        .ok_or_else(|| failed("requires one local Vortex file"))?;
    let source = session.prepare_file_with_cancellation(path, cancellation)?;
    cancellation.check()?;
    let prepared = prepare_bound_aggregate(
        request,
        policy,
        physical_policy,
        session,
        PreparedAggregateSource::File(source),
        None,
    )?;
    cancellation.check()?;
    Ok(prepared)
}

/// Bind the optimized aggregate to an existing source without reopening it.
/// # Errors
/// Rejects source/request identity, resource and aggregate admission failures.
pub fn prepare_aggregate_from_source(
    request: &VortexQueryPrimitiveRequest,
    policy: VortexLocalPrimitiveExecutionPolicy,
    source: PreparedVortexSource,
) -> Result<PreparedVortexAggregate> {
    prepare_aggregate_from_source_with_context(request, policy, source, None)
}

/// Compilation during a dynamic query must retain that query's admission.
pub(super) fn prepare_aggregate_from_source_with_context(
    request: &VortexQueryPrimitiveRequest,
    policy: VortexLocalPrimitiveExecutionPolicy,
    source: PreparedVortexSource,
    context: Option<&NativeExecutionContext<'_>>,
) -> Result<PreparedVortexAggregate> {
    let session = super::prepared_dispatch::source_session_with_context(
        &source,
        request,
        Some(policy),
        context,
    )?;
    let (policy, physical_policy) = prepared_policy(request, policy, &session)?;
    prepare_bound_aggregate(
        request,
        policy,
        physical_policy,
        &session,
        PreparedAggregateSource::File(source),
        context,
    )
}

fn prepared_policy(
    request: &VortexQueryPrimitiveRequest,
    policy: VortexLocalPrimitiveExecutionPolicy,
    session: &ResidentVortexSession,
) -> Result<(
    VortexLocalPrimitiveExecutionPolicy,
    VortexLocalPrimitivePhysicalPolicyReport,
)> {
    canonical(request)?;
    validate_policy(policy)?;
    super::admit_aggregate_state_policy(
        required_simple_aggregate(request)?,
        policy.resource_envelope(),
    )?;
    let (policy, physical_policy) = policy.with_physical_policy_for_request(request);
    let snapshot = session.snapshot();
    if snapshot.memory.limit_bytes > policy.resource_envelope.memory_budget_bytes {
        return Err(failed(
            "supplied session exceeds the requested memory policy",
        ));
    }
    Ok((policy, physical_policy))
}

#[cfg(feature = "vortex-write")]
pub(crate) fn prepare_memory_aggregate(
    request: &VortexQueryPrimitiveRequest,
    policy: VortexLocalPrimitiveExecutionPolicy,
    generation: &crate::memory_file_generation::MemoryFileGeneration,
    context: Option<&NativeExecutionContext<'_>>,
) -> Result<PreparedVortexAggregate> {
    if request.source_uri.as_ref() != Some(generation.source_uri()) {
        return Err(failed(
            "request URI does not identify the supplied immutable memory generation",
        ));
    }
    let source = generation.retained_source();
    let session = source.retained_session();
    if let Some(context) = context {
        session.validate_execution_context(context)?;
    }
    let (policy, physical_policy) = prepared_policy(request, policy, &session)?;
    let mut prepared = prepare_bound_aggregate(
        request,
        policy,
        physical_policy,
        &session,
        PreparedAggregateSource::File(source),
        context,
    )?;
    prepared.memory_generation = Some(generation.clone());
    Ok(prepared)
}

#[cfg(feature = "vortex-write")]
pub(crate) fn prepare_owned_aggregate(
    request: &VortexQueryPrimitiveRequest,
    policy: VortexLocalPrimitiveExecutionPolicy,
    source: &crate::owned_array_source::OwnedArraySource,
) -> Result<PreparedVortexAggregate> {
    if request.source_uri.as_ref() != Some(source.source_uri()) {
        return Err(failed(
            "request URI does not identify the supplied owned arrays",
        ));
    }
    if required_simple_aggregate(request)?.spill.is_some() {
        return Err(failed(
            "owned-array spill requires explicit file-backed composition",
        ));
    }
    let session = source.session();
    let (policy, physical_policy) = prepared_policy(request, policy, &session)?;
    prepare_bound_aggregate(
        request,
        policy,
        physical_policy,
        &session,
        PreparedAggregateSource::Owned(source.clone()),
        None,
    )
}

fn prepare_bound_aggregate(
    request: &VortexQueryPrimitiveRequest,
    policy: VortexLocalPrimitiveExecutionPolicy,
    physical_policy: VortexLocalPrimitivePhysicalPolicyReport,
    session: &ResidentVortexSession,
    source: PreparedAggregateSource,
    context: Option<&NativeExecutionContext<'_>>,
) -> Result<PreparedVortexAggregate> {
    let snapshot = session.snapshot();
    let parallelism = source.parallelism();
    if parallelism > policy.resource_envelope.max_parallelism {
        return Err(failed("supplied session exceeds the requested CPU policy"));
    }
    let (policy, physical_policy) = cap_session_cpu(policy, physical_policy, parallelism);
    #[cfg(feature = "vortex-write")]
    if required_simple_aggregate(request)?.spill.is_some() {
        spill::validate_schema(request, source.dtype(), policy.resource_envelope())?;
    }
    let lowering = AggregateLowering::new(request, source.dtype(), policy.resource_envelope())?;
    // Validate measure aliases/functions without retaining any aggregate state.
    drop(SimpleAggregateStates::new(
        &lowering.rewrite.aggregate,
        &lowering.plan.projected_columns,
    )?);
    let worker_pool = snapshot.provider_background_workers == 0
        && external_workers(request, policy.resource_envelope())
        && !aggregate_count_workers::restore_provider_drivers(
            request,
            source.dtype(),
            policy.resource_envelope(),
        );
    let temporary_provider_drivers =
        snapshot.provider_background_workers == 0 && parallelism > 1 && !worker_pool;
    let reuse = match &source {
        PreparedAggregateSource::File(source) => {
            let reuse = segment_reuse_policy(source, &lowering, context)?;
            source.validate_generation()?;
            reuse
        }
        #[cfg(feature = "vortex-write")]
        PreparedAggregateSource::Owned(_) => None,
    };
    Ok(PreparedVortexAggregate {
        request: request.clone(),
        source,
        session: session.clone(),
        lowering,
        policy,
        physical_policy,
        worker_pool,
        temporary_provider_drivers,
        reuse,
        #[cfg(feature = "vortex-write")]
        memory_generation: None,
    })
}

fn cap_session_cpu(
    mut policy: VortexLocalPrimitiveExecutionPolicy,
    mut physical_policy: VortexLocalPrimitivePhysicalPolicyReport,
    parallelism: usize,
) -> (
    VortexLocalPrimitiveExecutionPolicy,
    VortexLocalPrimitivePhysicalPolicyReport,
) {
    // The retained session's CPU ceiling also limits a wider request policy.
    if parallelism < policy.resource_envelope.max_parallelism {
        policy.max_parallelism = parallelism;
        policy.resource_envelope.max_parallelism = parallelism;
        policy.resource_envelope.scan_concurrency_per_worker = policy
            .resource_envelope
            .scan_concurrency_per_worker
            .min(parallelism);
        physical_policy.selected_max_parallelism = parallelism;
        physical_policy.selected_scan_concurrency_per_worker =
            policy.resource_envelope.scan_concurrency_per_worker;
        physical_policy
            .rejected_alternatives
            .push("aggregate_workers_beyond_retained_session_cpu_grant".into());
    }
    (policy, physical_policy)
}

fn segment_reuse_policy(
    source: &PreparedVortexSource,
    lowering: &AggregateLowering,
    context: Option<&NativeExecutionContext<'_>>,
) -> Result<Option<SegmentReusePolicy>> {
    if !source.has_segment_reuse_field_root()
        || !matches!(lowering.pushdown, Some(super::PredicateExpr::And(_)))
    {
        return Ok(None);
    }
    let mut projected = lowering.rewrite.aggregate.projected_columns();
    if let Some(predicate) = &lowering.residual {
        super::append_predicate_columns(predicate, &mut projected);
    }
    lowering
        .pushdown
        .as_ref()
        .map(|predicate| match context {
            Some(context) => source.segment_reuse_policy_in_context(context, predicate, &projected),
            None => source.segment_reuse_policy(predicate, &projected),
        })
        .transpose()
        .map(Option::flatten)
}

impl PreparedVortexAggregate {
    fn operation_cancellation(
        &self,
        parent: &shardloom_exec::compute_pool::CancellationToken,
    ) -> Result<shardloom_exec::compute_pool::CancellationToken> {
        Ok(required_simple_aggregate(&self.request)?
            .spill
            .as_ref()
            .map_or_else(
                || parent.clone(),
                |spill| {
                    shardloom_exec::compute_pool::CancellationToken::from_shared_flag_with_parent(
                        std::sync::Arc::clone(&spill.cancellation),
                        parent,
                    )
                },
            ))
    }

    /// Execute once and deliver complete native batches synchronously. The
    /// consumer borrows the same operation context for downstream native work.
    /// Retained arrays keep their buffer credit; a slow consumer applies direct
    /// backpressure. Empty output still delivers its declared schema once.
    /// # Errors
    /// Rejects unsupported shapes, pressure, changed sources, cancellation or
    /// consumer errors. Delivered batches are provisional until this call succeeds.
    pub fn for_each_batch(
        &self,
        cancellation: &shardloom_exec::compute_pool::CancellationToken,
        mut consume: impl FnMut(vortex::array::ArrayRef, &NativeExecutionContext<'_>) -> Result<()>,
    ) -> Result<ExecutedVortexAggregate> {
        let cancellation = self.operation_cancellation(cancellation)?;
        let mut executed = self
            .session
            .with_owned_execution(&cancellation, |context| {
                self.consume_native_in_context(context, 2048, &mut |array| consume(array, context))
            })?;
        executed.runtime = self.snapshot();
        self.annotate_prepared_execution(&mut executed)?;
        Ok(executed)
    }

    pub(crate) fn consume_native_in_context(
        &self,
        context: &NativeExecutionContext<'_>,
        batch_rows: usize,
        consume: &mut dyn FnMut(vortex::array::ArrayRef) -> Result<()>,
    ) -> Result<ExecutedVortexAggregate> {
        self.session.validate_execution_context(context)?;
        let mut output = super::aggregate_owned::AggregateOutput::streaming(
            &self.request,
            self.source.dtype(),
            self.session.memory(),
            batch_rows,
            context.cancellation().clone(),
            consume,
        )?;
        let scan = self.read_with_output_in_context(Some(&mut output), Some(context))?;
        context.check_cancelled()?;
        self.certify(&scan)
    }

    /// Collect complete rows from the shared aggregate result stream. This uses
    /// the existing bounded JSON sink without reopening the source or replaying the query.
    /// # Errors
    /// Rejects output above 65,536 rows or 8 MiB, cancellation, source mutation,
    /// resource pressure and result values unsupported by the JSON boundary.
    pub fn collect_jsonl(
        &self,
        cancellation: &shardloom_exec::compute_pool::CancellationToken,
    ) -> Result<CollectedVortexAggregate> {
        let started = std::time::Instant::now();
        let mut sink = super::collect::JsonRows::new(self.session.memory(), 8 * 1024 * 1024, true)?;
        let mut execution = self.for_each_batch(cancellation, |array, context| {
            sink.append_native(&array, context)
        })?;
        let (result_jsonl, result_schema_json, timing) =
            sink.finish_with_timing(&mut execution.native_io_certificate, started)?;
        execution.runtime = self.snapshot();
        Ok(CollectedVortexAggregate {
            timing,
            execution,
            result_jsonl,
            result_schema_json,
        })
    }

    /// Execute and atomically publish complete output through the shared native
    /// result stream. In-memory collection limits do not limit this operation.
    /// # Errors
    /// Rejects unsupported formats, source changes, resource pressure, existing
    /// destinations and incomplete output. Staged files are removed on failure.
    #[cfg(feature = "vortex-write")]
    pub fn write(
        &self,
        path: &std::path::Path,
        format: super::VortexLocalPrimitiveRowExportFormat,
        allow_overwrite: bool,
    ) -> Result<super::VortexLocalPrimitiveRowExportReport> {
        self.write_controlled(
            path,
            format,
            allow_overwrite,
            &shardloom_exec::compute_pool::CancellationToken::default(),
        )
    }

    /// The cancellation token covers execution, batch delivery and publication.
    /// # Errors
    /// Returns the same errors as [`Self::write`], including cancellation.
    #[cfg(feature = "vortex-write")]
    pub fn write_controlled(
        &self,
        path: &std::path::Path,
        format: super::VortexLocalPrimitiveRowExportFormat,
        allow_overwrite: bool,
        cancellation: &shardloom_exec::compute_pool::CancellationToken,
    ) -> Result<super::VortexLocalPrimitiveRowExportReport> {
        use vortex::array::dtype::{DType, Nullability};
        let cancellation = self.operation_cancellation(cancellation)?;
        let fields =
            super::completed_result::aggregate_stream_fields(&self.request, self.source.dtype())?;
        let (rows, source, source_path) = match &self.source {
            PreparedAggregateSource::File(source) => {
                let uri = self
                    .request
                    .source_uri
                    .as_ref()
                    .ok_or_else(|| failed("source URI is absent"))?;
                let path = local_vortex_path(uri, self.request.kind)?
                    .map(std::fs::canonicalize)
                    .transpose()
                    .map_err(super::vortex_error)?;
                (source.file().row_count(), Some(source.clone()), path)
            }
            PreparedAggregateSource::Owned(source) => (source.row_count(), None, None),
        };
        let aggregate = required_simple_aggregate(&self.request)?;
        let upper_rows = if aggregate.group_by.is_empty() && aggregate.group_expressions.is_empty()
        {
            1
        } else {
            rows.min(
                self.request
                    .source_order_limit
                    .map_or(u64::MAX, |limit| limit as u64),
            )
        };
        let plan = super::native_sink::NativeSinkPlan::produced(
            self.session.clone(),
            DType::struct_(fields, Nullability::NonNullable),
            upper_rows,
            source_path,
            source,
        )?;
        let mut executed = None;
        let mut producer =
            |context: &NativeExecutionContext<'_>,
             batch_rows,
             consume: &mut dyn FnMut(vortex::array::ArrayRef) -> Result<bool>| {
                executed =
                    Some(
                        self.consume_native_in_context(context, batch_rows, &mut |array| {
                            if !consume(array)? {
                                return Err(failed("result consumer stopped before completion"));
                            }
                            Ok(())
                        })?,
                    );
                Ok(())
            };
        let mut report = super::completed_result::write_stream(
            plan,
            &self.request,
            path,
            format,
            allow_overwrite,
            self.policy,
            &mut producer,
            &cancellation,
        )?;
        annotate_output_count(&mut report, &self.request);
        let execution = executed
            .ok_or_else(|| failed("result producer did not complete"))?
            .report;
        report.rows_scanned = execution.rows_scanned;
        report.arrays_read_count = execution.arrays_read_count;
        report.max_chunk_rows = execution.max_chunk_rows;
        report.state_budget = execution.state_budget;
        report.physical_policy = execution.physical_policy;
        report.source_order_limit_requested = execution.source_order_limit_requested;
        report.evidence.upstream_scan_called = execution.upstream_scan_called;
        report.evidence.side_effects.data_read |= execution.data_read;
        report.evidence.side_effects.data_decoded |= execution.data_decoded;
        report.evidence.side_effects.data_materialized |= execution.data_materialized;
        report.evidence.side_effects.row_read |= execution.row_read;
        report.evidence.pushdown = super::VortexLocalPrimitiveRowExportPushdownEvidence {
            filter_pushdown_applied: execution.filter_pushdown_applied,
            projection_pushdown_applied: execution.projection_pushdown_applied,
            source_order_limit_applied: execution.source_order_limit_applied,
        };
        Ok(report)
    }

    /// Start a fresh cancellation scope for this prepared spill handle while
    /// retaining its source and policy. Call after a cancelled execution has
    /// returned, then use the returned policy's `cancel()` to stop the next call.
    /// Old policy clones keep their old cancellation scope and cannot cancel a
    /// renewed execution. Exclusive access prevents renewing an active call.
    /// No source is reopened and no query state or answer is retained.
    ///
    /// # Errors
    /// Rejects handles without an explicit spill policy or invalid policy bounds.
    #[cfg(feature = "vortex-write")]
    pub fn renew_spill_cancellation(&mut self) -> Result<crate::VortexAggregateSpillPolicy> {
        let previous = required_simple_aggregate(&self.request)?
            .spill
            .as_ref()
            .ok_or_else(|| failed("cancellation renewal requires a prepared spill policy"))?;
        let renewed = previous.renew_cancellation()?;
        self.request
            .simple_aggregate
            .as_mut()
            .ok_or_else(|| failed("prepared aggregate request is absent"))?
            .spill = Some(renewed.clone());
        self.lowering.rewrite.aggregate.spill = Some(renewed.clone());
        Ok(renewed)
    }

    /// Read-only cumulative session counters; unrelated handles can also advance them.
    #[must_use]
    pub fn snapshot(&self) -> ResidentSessionSnapshot {
        self.session.snapshot()
    }

    fn read(&self) -> Result<LocalVortexAggregateScan> {
        self.read_with_output(None)
    }

    fn read_with_output(
        &self,
        output: Option<&mut super::aggregate_owned::AggregateOutput>,
    ) -> Result<LocalVortexAggregateScan> {
        self.read_with_output_in_context(output, None)
    }

    fn read_with_output_in_context(
        &self,
        mut output: Option<&mut super::aggregate_owned::AggregateOutput>,
        context: Option<&NativeExecutionContext<'_>>,
    ) -> Result<LocalVortexAggregateScan> {
        if let Some(context) = context {
            self.session.validate_execution_context(context)?;
        }
        #[cfg(feature = "vortex-write")]
        if let PreparedAggregateSource::Owned(source) = &self.source {
            return self.read_owned_source(source, output, context);
        }
        let source = self.source.file()?;
        #[cfg(feature = "vortex-write")]
        if required_simple_aggregate(&self.request)?.spill.is_some() {
            return self.read_spill(context, output);
        }
        let uri = self
            .request
            .source_uri
            .as_ref()
            .ok_or_else(|| failed("prepared source URI is absent"))?;
        let memory = self.worker_pool.then(|| self.session.memory());
        let mut scan =
            |file: &vortex::file::VortexFile,
             session: &vortex::session::VortexSession,
             runtime: &vortex::io::runtime::current::CurrentThreadRuntime,
             retry: Option<&mut dyn FnMut(&vortex::error::VortexError) -> bool>| {
                read_lowered_vortex_simple_aggregate_scan(
                    uri,
                    &self.request,
                    self.policy,
                    super::aggregate_scan_source::AggregateScanSource::File(file),
                    session,
                    runtime,
                    memory,
                    retry,
                    &self.lowering,
                    std::time::Instant::now(),
                    output.as_deref_mut(),
                    context.map(NativeExecutionContext::cancellation),
                )
            };
        if let Some(policy) = self.reuse {
            let execute =
                |file: &vortex::file::VortexFile,
                 session: &vortex::session::VortexSession,
                 runtime: &vortex::io::runtime::current::CurrentThreadRuntime,
                 attempt: &mut crate::resident_session::SegmentReuseAttempt| {
                    let mut retry =
                        |error: &vortex::error::VortexError| attempt.request_uncached_retry(error);
                    scan(file, session, runtime, Some(&mut retry))
                };
            let (mut scan, evidence) = match context {
                Some(context) => source.with_admitted_native_execution_cached_retry_with_drivers(
                    context,
                    policy,
                    self.temporary_provider_drivers,
                    execute,
                ),
                None => source.with_native_execution_cached_retry_with_drivers(
                    policy,
                    self.temporary_provider_drivers,
                    execute,
                ),
            }?;
            scan.restored_provider_background_workers = scan
                .restored_provider_background_workers
                .max(evidence.provider_background_workers);
            scan.annotate_segment_reuse(evidence)?;
            return Ok(scan);
        }
        if self.temporary_provider_drivers {
            let execute =
                |file: &vortex::file::VortexFile,
                 session: &vortex::session::VortexSession,
                 runtime: &vortex::io::runtime::current::CurrentThreadRuntime| {
                    scan(file, session, runtime, None)
                };
            let (mut scan, drivers) = match context {
                Some(context) => {
                    source.with_admitted_native_execution_temporary_drivers(context, execute)
                }
                None => source.with_native_execution_temporary_drivers(execute),
            }?;
            annotate_restored_provider_drivers(&mut scan, drivers)?;
            return Ok(scan);
        }
        let mut execute =
            |file: &vortex::file::VortexFile,
             session: &vortex::session::VortexSession,
             runtime: &vortex::io::runtime::current::CurrentThreadRuntime| {
                scan(file, session, runtime, None)
            };
        match context {
            Some(context) => source.with_admitted_native_execution(context, |file, context| {
                execute(file, context.native_session(), context.runtime())
            }),
            None => source.with_native_execution(execute),
        }
    }

    #[cfg(feature = "vortex-write")]
    fn read_owned_source(
        &self,
        source: &crate::owned_array_source::OwnedArraySource,
        mut output: Option<&mut super::aggregate_owned::AggregateOutput>,
        context: Option<&NativeExecutionContext<'_>>,
    ) -> Result<LocalVortexAggregateScan> {
        let mut execute = |context: &NativeExecutionContext<'_>| {
            let (mut scan, drivers) = self.session.with_owned_execution_drivers(
                context,
                self.temporary_provider_drivers,
                || {
                    read_lowered_vortex_simple_aggregate_scan(
                        source.source_uri(),
                        &self.request,
                        self.policy,
                        super::aggregate_scan_source::AggregateScanSource::Owned(source),
                        context.native_session(),
                        context.runtime(),
                        self.worker_pool.then(|| self.session.memory()),
                        None,
                        &self.lowering,
                        std::time::Instant::now(),
                        output.as_deref_mut(),
                        Some(context.cancellation()),
                    )
                },
            )?;
            if self.temporary_provider_drivers {
                annotate_restored_provider_drivers(&mut scan, drivers)?;
            }
            Ok(scan)
        };
        match context {
            Some(context) => execute(context),
            None => self.session.with_owned_execution(
                &shardloom_exec::compute_pool::CancellationToken::default(),
                execute,
            ),
        }
    }

    /// Execute fresh complete aggregate state, then construct the ordinary report
    /// and native I/O certificate. Generation validation brackets every call,
    /// including metadata-pruned results and same-source pressure replay.
    /// # Errors
    /// Rejects source changes, pressure, provider failures or uncertified results.
    pub fn execute(&self) -> Result<ExecutedVortexAggregate> {
        let mut executed = self.execute_native()?;
        self.annotate_prepared_execution(&mut executed)?;
        Ok(executed)
    }

    /// Execute with cooperative operation cancellation. Ordinary aggregate scans
    /// check the operation token before admission, at chunk/stage boundaries and
    /// before publication. Explicit spill kernels observe their policy token;
    /// the operation token is checked before and after that spill stage. Running
    /// provider calls and workers must drain before this returns.
    ///
    /// # Errors
    /// Returns ordinary native admission, execution, generation and cancellation
    /// errors. Cancellation does not change this handle's lowering or source.
    pub fn execute_cancellable(
        &self,
        cancellation: &shardloom_exec::compute_pool::CancellationToken,
    ) -> Result<ExecutedVortexAggregate> {
        // Admission must observe the spill owner even while the enclosing call
        // waits for a lane. Neither cancellation source may cancel the other.
        let cancellation = self.operation_cancellation(cancellation)?;
        let mut executed = match &self.source {
            PreparedAggregateSource::File(source) => source
                .with_native_execution_controlled(&cancellation, |_, context| {
                    self.execute_in_context(context)
                }),
            #[cfg(feature = "vortex-write")]
            PreparedAggregateSource::Owned(_) => self
                .session
                .with_owned_execution(&cancellation, |context| self.execute_in_context(context)),
        }?;
        let restored_providers = executed.runtime.provider_background_workers;
        executed.runtime = self.session.snapshot();
        executed.runtime.provider_background_workers = executed
            .runtime
            .provider_background_workers
            .max(restored_providers);
        self.annotate_prepared_execution(&mut executed)?;
        Ok(executed)
    }

    fn annotate_prepared_execution(&self, executed: &mut ExecutedVortexAggregate) -> Result<()> {
        let validation = match &self.source {
            PreparedAggregateSource::File(_) => {
                "before_and_after_every_execution_including_pruned_result"
            }
            #[cfg(feature = "vortex-write")]
            PreparedAggregateSource::Owned(_) => "immutable_owned_arrays_no_filesystem_generation",
        };
        let _ = write!(
            executed
                .native_io_certificate
                .source_pushdown_report
                .proof_basis,
            ";resident_source_generation_validation={validation};resident_source_opens={};resident_completed_executions={};aggregate_lowering_reused={};aggregate_state_reused=false;no_query_answer_cache=true;independent_oracle_not_run",
            executed.runtime.prepared_source_opens,
            executed.runtime.completed_executions,
            required_simple_aggregate(&self.request)?.spill.is_none()
        );
        Ok(())
    }

    fn execute_native(&self) -> Result<ExecutedVortexAggregate> {
        let scan = self.read()?;
        self.certify(&scan)
    }

    /// Execute under the current native operation, retaining the existing
    /// aggregate kernels and stage-owned workers without another admission.
    pub(crate) fn execute_in_context(
        &self,
        context: &NativeExecutionContext<'_>,
    ) -> Result<ExecutedVortexAggregate> {
        let scan = self.read_with_output_in_context(None, Some(context))?;
        context.check_cancelled()?;
        self.certify(&scan)
    }

    /// Execute once and retain complete typed native result columns for a sink.
    /// Specialized integer/UTF8 count finalizers retain their direct column path.
    /// Other admitted aggregates bind completed scalar values to the declared
    /// schema without serializing and reparsing JSON or replaying the query.
    /// # Errors
    /// Rejects unsupported shapes, source changes, pressure, explicit spill,
    /// and grouped offset plus limit above 65536. Without an explicit limit,
    /// general finalization checks the actual group count before building rows.
    /// General results have an 8 MiB output bound. No query is retried to render rows.
    pub fn execute_owned(&self) -> Result<ExecutedOwnedVortexAggregate> {
        let mut output = super::aggregate_owned::AggregateOutput::new(
            &self.request,
            self.source.dtype(),
            &self.session,
        )?;
        let scan = self.read_with_output(Some(&mut output))?;
        let execution = self.certify(&scan)?;
        let (array, ownership) = output.into_array()?;
        let result = self.session.own_completed_array(array, ownership)?;
        Ok(ExecutedOwnedVortexAggregate {
            execution,
            result,
            #[cfg(feature = "vortex-write")]
            request: self.request.clone(),
            #[cfg(feature = "vortex-write")]
            policy: self.policy,
        })
    }

    /// Retain the complete native aggregate output under the shared allocation.
    /// Uses the same batch finalizer and optional native spill as streaming
    /// delivery, without a separate row or serialized-result size ceiling.
    /// # Errors
    /// Rejects unsupported requests, changed sources, pressure or cancellation.
    /// Failed execution releases every partial result and its retained credits.
    pub fn execute_native_result(
        &self,
        cancellation: &CancellationToken,
    ) -> Result<ExecutedOwnedVortexAggregate> {
        cancellation.check()?;
        let mut arrays = super::native_capacity::ReservedVec::new(self.session.memory())?;
        let mut execution = self.for_each_batch(cancellation, |array, context| {
            context.check_cancelled()?;
            arrays.push(array)
        })?;
        cancellation.check()?;
        let (arrays, ownership) = arrays.into_parts();
        let result = self.session.own_completed_arrays(arrays, ownership)?;
        cancellation.check()?;
        execution.runtime = self.snapshot();
        Ok(ExecutedOwnedVortexAggregate {
            execution,
            result,
            #[cfg(feature = "vortex-write")]
            request: self.request.clone(),
            #[cfg(feature = "vortex-write")]
            policy: self.policy,
        })
    }

    fn certify(&self, scan: &LocalVortexAggregateScan) -> Result<ExecutedVortexAggregate> {
        let report = simple_aggregate_report(&self.request, scan)?
            .with_physical_policy(self.physical_policy.clone());
        let mut runtime = self.session.snapshot();
        runtime.provider_background_workers = runtime
            .provider_background_workers
            .max(scan.restored_provider_background_workers);
        let native_io_certificate = local_primitive_native_io_certificate(&self.request, &report)?;
        #[cfg(feature = "vortex-write")]
        let native_io_certificate = {
            let mut certificate = native_io_certificate;
            if let Some(generation) = &self.memory_generation {
                generation.annotate_aggregate_certificate(&mut certificate)?;
            }
            if let PreparedAggregateSource::Owned(source) = &self.source {
                source.annotate(&mut certificate)?;
            }
            certificate
        };
        if !native_io_certificate.is_certified() || report.has_errors() {
            return Err(failed(
                "aggregate execution did not produce a certified native report",
            ));
        }
        Ok(ExecutedVortexAggregate {
            report,
            native_io_certificate,
            runtime,
        })
    }
}

fn annotate_restored_provider_drivers(
    scan: &mut LocalVortexAggregateScan,
    drivers: usize,
) -> Result<()> {
    let mut summary: serde_json::Value =
        serde_json::from_str(&scan.result_summary).map_err(|error| failed(&error.to_string()))?;
    summary["aggregate_provider_background_workers"] = drivers.into();
    summary["aggregate_provider_cpu_scope"] = "same_prepared_source;worker_schema_not_admitted;temporary_provider_drivers;no_concurrent_aggregate_worker_pool".into();
    scan.result_summary = summary.to_string();
    scan.restored_provider_background_workers =
        scan.restored_provider_background_workers.max(drivers);
    Ok(())
}

fn failed(reason: &str) -> ShardLoomError {
    ShardLoomError::InvalidOperation(format!(
        "prepared native aggregate: {reason}; no fallback execution was attempted"
    ))
}

#[cfg(test)]
#[path = "local_primitive_prepared_aggregate_tests.rs"]
mod tests;

#[cfg(all(test, feature = "vortex-write"))]
#[path = "local_primitive_prepared_aggregate_cancellation_tests.rs"]
mod cancellation_tests;

#[cfg(all(test, feature = "vortex-write", unix))]
#[path = "local_primitive_footer_aggregate_native_tests.rs"]
mod footer_native_tests;

#[cfg(all(test, feature = "vortex-write"))]
#[path = "local_primitive_aggregate_owned_tests.rs"]
mod owned_tests;
