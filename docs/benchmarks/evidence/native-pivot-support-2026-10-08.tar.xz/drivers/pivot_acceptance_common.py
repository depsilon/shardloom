"""Immutable identities for the complete local pivot execution unit."""
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
PRIOR = Path('/Users/dylan/LocalData/shardloom/native-input-completion-20261007')
WINDOW_PARENT = Path('/Users/dylan/LocalData/shardloom/native-window-pressure-20261008')
sys.path.insert(0, str(PRIOR))
from input_common import ROOT, PYTHON, git, read, sha, source_hashes, write

def frozen_source():
    source = read(OUT / 'pivot-source-1.json')
    assert source_hashes() == source['source_hashes']
    assert git('rev-parse', 'HEAD') == source['head']
    assert git('status', '--porcelain') == source['working_tree'] == ''
    assert all(sha(path) == digest for path, digest in source['helpers'].items())
    assert sha(source['scope_manifest']) == source['scope_sha256']
    return source

def frozen_build():
    source = frozen_source()
    build = read(OUT / 'pivot-acceptance-build-1.json')
    assert build['source_identity_sha256'] == source['source_identity_sha256']
    assert build['source_manifest_sha256'] == sha(OUT / 'pivot-source-1.json')
    for artifact in build['artifacts'].values():
        assert Path(artifact['binary']).stat().st_size == artifact['bytes']
        assert sha(artifact['binary']) == artifact['sha256']
    scope = read(build['scope_manifest'])
    assert sha(build['scope_manifest']) == build['scope_sha256']
    assert build['scope_manifest'] == source['scope_manifest']
    assert build['scope_sha256'] == source['scope_sha256']
    assert scope['case_count'] == len(scope['cases']) == 32497
    assert scope['complete_rows'] == sum(scope['cases'].values()) == 18595284
    assert all(sha(path) == digest for path, digest in scope['unchanged_declaration_sources'].items())
    parent_build_path = WINDOW_PARENT / 'window-acceptance-build-1.json'
    parent_build = read(parent_build_path)
    provenance = build['unchanged_oracle_and_fixture_provenance']
    assert provenance['path'] == str(parent_build_path)
    assert sha(parent_build_path) == provenance['sha256']
    assert provenance['declaration_source_identity_sha256'] == scope['source_identity_sha256']
    parent_scope_path = Path(parent_build['scope_manifest'])
    assert sha(parent_scope_path) == parent_build['scope_sha256']
    parent_scope = read(parent_scope_path)
    assert parent_scope['case_count'] == len(parent_scope['cases']) == 28871
    assert parent_scope['complete_rows'] == sum(parent_scope['cases'].values()) == 16881391
    assert scope['prior_declarations'] == {
        'path': parent_build['scope_manifest'], 'sha256': parent_build['scope_sha256']}
    prior_sources = dict(parent_scope['unchanged_declaration_sources'])
    prior_sources.update({path: item['candidate_sha256']
        for path, item in parent_scope['changed_product_adapters'].items()})
    prior_sources.update({path: item['candidate_sha256']
        for path, item in parent_scope['changed_declaration_sources'].items()})
    assert all(sha(path) == item['candidate_sha256'] for path, item in scope['changed_declaration_sources'].items())
    assert all(prior_sources[path] == item['previous_sha256']
        for path, item in scope['changed_declaration_sources'].items())
    assert all(sha(path) == item['candidate_sha256'] for path, item in scope['changed_product_adapters'].items())
    assert sha(scope['nested_pivot_oracle']['path']) == scope['nested_pivot_oracle']['sha256']
    assert all(sha(item['path']) == item['sha256'] for item in scope['literal_oracles'])
    return source, build, scope
