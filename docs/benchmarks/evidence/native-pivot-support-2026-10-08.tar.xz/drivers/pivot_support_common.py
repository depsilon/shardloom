"""Preserve accepted runtime bytes and admit only the exact suite-summary repair."""
import json

import pivot_acceptance_common as c

ROOT, OUT, PYTHON = c.ROOT, c.OUT, c.PYTHON
read, sha, write = c.read, c.sha, c.write


def checked_runtime():
    snapshot = read(OUT / 'pivot-source-1.json')
    build = read(OUT / 'pivot-acceptance-build-1.json')
    actual = c.source_hashes()
    assert snapshot['source_hashes'] == build['source_hashes']
    assert len(actual) == len(build['source_hashes']) == 1015
    assert build['source_identity_sha256'] == snapshot['source_identity_sha256']
    assert sha(build['binary']) == build['binary_sha256']
    final = read(OUT / 'pivot-final-acceptance-4.json')
    assert final['status'] == 'passed_local_engine'
    assert final['source_identity_sha256'] == snapshot['source_identity_sha256']
    assert final['binary_sha256'] == build['binary_sha256'] and final['source_assets'] == 1015
    repair_path = OUT / 'pivot-suite-controller-repair-1.json'
    repair = read(repair_path)
    assert sha(repair_path) == final['public_family_union_repair_sha256']
    assert repair['status'] == 'passed_completed_family_union'
    assert repair['source_identity_sha256'] == snapshot['source_identity_sha256']
    assert repair['build_manifest_sha256'] == sha(OUT / 'pivot-acceptance-build-1.json')
    assert repair['binary_sha256'] == build['binary_sha256']
    assert not repair['native_queries_rerun'] and not repair['native_executable_changed']
    assert not repair['source_repository_changed'] and not repair['expected_values_changed']
    assert repair['original_failure_preserved']
    names = ['scripts/run_native_relational_suite.py', 'scripts/test_native_relational_suite.py']
    assert repair['source_delta_paths'] == names
    assert set(repair['repaired_source_files']) == set(names)
    expected = dict(build['source_hashes'])
    repaired = {}
    for name in names:
        change = repair['repaired_source_files'][name]
        assert expected[name] == change['original_sha256']
        assert change['original_sha256'] != change['repaired_sha256']
        assert sha(change['repaired_source']) == change['repaired_sha256']
        expected[name] = change['repaired_sha256']
        repaired[name] = {key: change[key] for key in ('original_sha256', 'repaired_sha256')}
    assert actual == expected
    annotation = {'accepted_runtime_commit': snapshot['head'],
        'accepted_source_identity_sha256': snapshot['source_identity_sha256'],
        'assets_byte_identical': len(actual) - len(repaired), 'asset_count_unchanged': len(actual),
        'harness_assets_repaired': len(repaired), 'harness_behavior_changed': True,
        'source_repair_manifest_sha256': sha(repair_path), 'repaired_source_files': repaired,
        'source_repair_boundary': 'Only the suite summary combiner and its regression tests change. All native and Python product execution sources, case declarations and expectations remain byte-identical.',
        'executable_behavior_changed': False, 'binary_sha256': build['binary_sha256']}
    return snapshot, build, annotation


def portable(value):
    text = json.dumps(value, indent=2, allow_nan=False)
    for original, replacement in ((str(ROOT), '<repo>'), (str(OUT), '<pivot-uat>'), (str(ROOT.home()), '<home>')):
        text = text.replace(original, replacement)
    return text + '\n'
