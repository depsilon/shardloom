"""Verify affected support pages, generated guides and executable examples."""
import argparse
import ast
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import time

import pivot_support_common as c

DOCUMENTS = (
    'docs/architecture/native-window-pressure-2026-10-08.md',
    'docs/architecture/native-pivot-pressure-2026-10-08.md',
    'docs/architecture/native-nested-pivot-state-2026-10-06.md',
    'docs/architecture/native-join-pressure-2026-10-08.md',
    'docs/architecture/native-bounded-adapters-2026-10-06.md',
    'docs/architecture/v1-local-resource-safety.md',
    'docs/architecture/native-local-completion-scope-2026-10-07.md',
    'docs/architecture/native-streamed-ordering-2026-10-07.md',
    'docs/architecture/native-aggregate-pressure-2026-10-07.md',
    'docs/architecture/native-input-completion-2026-10-07.md',
    'docs/architecture/local-development-storage.md',
    'docs/architecture/phased-execution-plan.md',
    'docs/architecture/universal-workflow-completion-2026-10-01.md',
    'docs/benchmarks/native-pivot-pressure-2026-10-08.md',
    'docs/release/public-status-matrix.md',
    'docs/release/v1-inclusion-scope-matrix.md',
    'docs/reference/native-query-spill.md',
    'docs/reference/resident-native-results.md',
    'docs/reference/shardloom-user-surface-index.md',
    'docs/reference/shardloom-user-surface-index.json',
    'python/README.md', 'python/src/shardloom/query.py',
    'website-src/scripts/sync-content.mjs',
    'website-src/src/content/docs/field-guide/python-surface.mdx',
    'website-src/src/content/docs/field-guide/runtime-and-io.mdx',
    'website-src/src/content/docs/field-guide/limitations.mdx',
)


def examples(build, out):
    os.environ['SHARDLOOM_BIN'] = build['binary']
    import shardloom as sl
    pattern = re.compile(r'```python\n(.*?)\n```', re.S)
    resident = c.ROOT / 'docs/architecture/native-bounded-adapters-2026-10-06.md'
    readme = c.ROOT / 'python/README.md'
    guide = c.ROOT / 'website-src/src/content/docs/field-guide/python-surface.mdx'
    spill = c.ROOT / 'docs/reference/native-query-spill.md'
    fixture_root = out / 'pivot-example'
    fixture_root.mkdir()
    fixture_rows = [
        {'entity': 1, 'category': 'a', 'amount': 2.0},
        {'entity': 1, 'category': 'b', 'amount': 3.0},
        {'entity': 1, 'category': 'a', 'amount': 4.0},
        {'entity': 2, 'category': 'b', 'amount': 5.0},
        {'entity': 2, 'category': 'a', 'amount': 6.0},
    ]
    fixture = sl.context().from_rows(fixture_rows)
    try:
        prepared = fixture.write_vortex(fixture_root / 'sales.vortex',
                                       memory_gb=1, max_parallelism=1)
        assert prepared.envelope.status == 'success'
        assert not prepared.fallback_attempted and not prepared.external_engine_invoked
        fixture_proof = {'complete_input_rows': fixture_rows,
            'file_sha256': c.sha(fixture_root / 'sales.vortex'),
            'preparation_envelope': prepared.envelope.raw}
    finally:
        fixture.client.close()
    cases = [
        ('resident-contract', resident, pattern.search(resident.read_text()).group(1),
         [{'order_id': 1, 'amount': 12.5}, {'order_id': 2, 'amount': None}, {'order_id': 3, 'amount': 7.0}], False),
        ('streaming-readme', readme, next(code for code in pattern.findall(readme.read_text()) if 'def incoming_rows():' in code),
         [{'id': 1, 'label': 'kept'}], True),
        ('streaming-field-guide', guide, pattern.search(guide.read_text().split('## Consume results in batches', 1)[1]).group(1),
         [{'order_id': 1, 'amount': 12.5}, {'order_id': 2, 'amount': None}], True),
        ('streamed-aggregate-order-limit', spill, next(code for code in pattern.findall(spill.read_text()) if 'def aggregate_input():' in code),
         [{'team': 'red', 'total': 7}], True),
        ('streamed-left-join', spill, next(code for code in pattern.findall(spill.read_text()) if 'def incoming_orders():' in code),
         [{'amount': 3, 'customer': 'Ada'}, {'amount': 5, 'customer': None}, {'amount': 4, 'customer': 'Ada'}], True),
        ('streamed-window', spill, next(code for code in pattern.findall(spill.read_text()) if 'def incoming_measurements():' in code),
         [{'sequence': 1, 'team': 'red', 'previous_two_total': 3.0, 'distinct_amounts': 1},
          {'sequence': 2, 'team': 'blue', 'previous_two_total': 1.0, 'distinct_amounts': 1},
          {'sequence': 3, 'team': 'red', 'previous_two_total': 7.0, 'distinct_amounts': 2},
          {'sequence': 4, 'team': 'red', 'previous_two_total': 7.0, 'distinct_amounts': 2}], True),
        ('file-pivot', spill, next(code for code in pattern.findall(spill.read_text()) if '.read("sales.vortex").pivot_table(' in code),
         [{'entity': 1, 'pivot_a': 6.0, 'pivot_b': 3.0},
          {'entity': 2, 'pivot_a': 6.0, 'pivot_b': 5.0}], False),
    ]
    result = []
    for label, path, code, expected, streaming in cases:
        namespace = {'sl': sl}; output = io.StringIO()
        try:
            working_directory = contextlib.chdir(fixture_root) if label == 'file-pivot' else contextlib.nullcontext()
            with contextlib.redirect_stdout(output), working_directory:
                exec(compile(code, str(path), 'exec'), namespace)
            rows = [row for line in output.getvalue().splitlines() for row in ast.literal_eval(line)]
            assert rows == expected, (label, rows)
            iterator = namespace['batches']; report = iterator.report
            assert report is not None and report.envelope.status == 'success'
            assert not report.fallback_attempted and not report.external_engine_invoked
            assert iterator._process.poll() == 0
            raw = report.envelope.raw; fields = {item['key']: item['value'] for item in raw['fields']}
            if streaming:
                assert fields['native_input_end_observed'] == fields['native_input_output_ownership_detached'] == 'true'
                assert fields['native_input_max_retained_batches'] == '1'
            else:
                assert 'native_input_end_observed' not in fields
            if label == 'streamed-aggregate-order-limit':
                assert fields['relational_ordered_aggregate_stages'] == '1'
                assert fields['native_input_batch_rows'] == '3'
            if label == 'streamed-left-join':
                assert fields['relational_ordered_join_stages'] == '1'
                assert fields['relational_ordered_join_build_rows'] == '1'
                assert fields['native_input_batch_rows'] == '3'
                assert fields['native_input_join_build_rows_detached'] == '1'
            if label == 'streamed-window':
                assert fields['relational_ordered_window_stages'] == '1'
                assert fields['native_input_batch_rows'] == '4'
                assert fields['native_input_window_rows_detached'] == '4'
                assert fields['native_input_window_batches_detached'] == '2'
                assert fields['relational_spill_owned_cleanup_completed'] == 'true'
            if label == 'file-pivot':
                required = {
                    'relational_spilled_pivot_stages': '1',
                    'relational_spilled_pivot_input_rows': '5',
                    'relational_spilled_pivot_index_rows': '2',
                    'relational_spilled_pivot_domains': '2',
                    'relational_spilled_pivot_cells': '4',
                    'relational_spill_owned_cleanup_completed': 'true',
                    'result_payload_complete': 'true',
                }
                assert all(fields[key] == value for key, value in required.items())
                assert not Path(namespace['workspace']).exists()
            result.append({'name': label, 'source': str(path.relative_to(c.ROOT)),
                'source_sha256': c.sha(path), 'code_sha256': hashlib.sha256(code.encode()).hexdigest(),
                'code': code, 'complete_rows': rows, 'streaming': streaming, 'envelope': raw,
                **({'fixture': fixture_proof} if label == 'file-pivot' else {})})
        finally:
            if 'batches' in namespace:
                namespace['batches'].close()
            for variable in ('frame', 'workflow'):
                if variable in namespace:
                    namespace[variable].client.close()
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', type=int, required=True)
    args = parser.parse_args(); assert args.attempt > 0
    snapshot, build, annotation = c.checked_runtime()
    out = c.OUT / f'pivot-support-checks-{args.attempt}'
    out.mkdir(exist_ok=False)
    commands = (
        ('suite-controller-tests', [c.PYTHON, '-B', '-m', 'unittest', 'discover', '-s', 'scripts', '-p', 'test_native_relational_suite.py', '-v'], c.ROOT),
        ('user-surface-index', [c.PYTHON, '-B', 'scripts/check_user_surface_reference.py'], c.ROOT),
        ('v1-inclusion-scope', [c.PYTHON, '-B', 'scripts/check_v1_inclusion_scope.py', '--output', str(out / 'v1-inclusion-scope-report.json')], c.ROOT),
        ('public-status', [c.PYTHON, '-B', 'scripts/check_public_status_docs.py', '--output', str(out / 'public-status-report.json')], c.ROOT),
        ('use-case-backlinks', [c.PYTHON, '-B', 'scripts/check_use_case_backlinks.py'], c.ROOT),
        ('website-check', ['npm', 'run', 'check'], c.ROOT / 'website-src'),
        ('website-build', ['npm', 'run', 'build'], c.ROOT / 'website-src'),
        ('website-readiness', [c.PYTHON, '-B', 'scripts/check_website_readiness.py', '--output', str(out / 'website-readiness-report.json')], c.ROOT),
        ('diff-whitespace', ['git', 'diff', '--check'], c.ROOT),
    )
    checks = []
    for name, command, cwd in commands:
        assert c.checked_runtime()[2] == annotation
        path = out / f'{name}.log'; started = time.monotonic()
        with path.open('xb') as stream:
            completed = subprocess.run(command, cwd=cwd, stdout=stream, stderr=subprocess.STDOUT, timeout=300, check=False)
        item = {'name': name, 'command': command, 'cwd': str(cwd), 'returncode': completed.returncode,
            'seconds': time.monotonic() - started, 'log': str(path), 'log_sha256': c.sha(path)}
        checks.append(item); c.write(out / f'{name}-receipt.json', item)
        print(json.dumps(item), flush=True)
        assert c.checked_runtime()[2] == annotation
        assert completed.returncode == 0, name
    observed = examples(build, out)
    assert c.checked_runtime()[2] == annotation
    c.write(out / 'summary.json', {'status': 'passed', 'checks': checks, 'executed_examples': observed,
        'runtime_provenance': annotation, 'binary_sha256': build['binary_sha256'], 'driver_sha256': c.sha(__file__),
        'support_helper_sha256': c.sha(c.OUT / 'pivot_support_common.py'),
        'documentation_source_hashes': {name: c.sha(c.ROOT / name) for name in DOCUMENTS},
        'browser_visual_qa': 'pending', 'hosted_integration': 'pending'})
    print(json.dumps({'status': 'passed', 'checks': len(checks), 'examples': len(observed)}), flush=True)


if __name__ == '__main__':
    main()
