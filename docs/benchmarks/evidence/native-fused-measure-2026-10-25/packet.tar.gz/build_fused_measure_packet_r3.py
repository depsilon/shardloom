"""Build a bounded, deterministic fused-measure evidence packet (r3)."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import tarfile

P = Path('/Users/dylan/LocalData/shardloom/workflow-work-elimination-20261025')
W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
DEST = W / 'docs/benchmarks/evidence/native-fused-measure-2026-10-25'
MAX_RAW_BYTES = 64 * 1024 * 1024
CASES = ('dictionary_dense', 'dictionary_skew', 'dictionary_sparse',
         'plain_high_cardinality', 'tiny', 'ineligible_i64')
ROLES = ('baseline', 'candidate')

HELPERS = (
    'build_fused_measure_packet_r1.py', 'build_fused_measure_packet_r2.py',
    'build_fused_measure_packet_r3.py', 'freeze_fused_measure_r1.py',
    'freeze_fused_measure_r2.py', 'freeze_fused_measure_r3.py',
    'run_fused_measure_r1.py', 'run_fused_measure_r2.py', 'run_fused_measure_r3.py', 'run_guarded.py',
    'verify_fused_measure_before_dictionary_r1.py', 'verify_fused_measure_r1.py',
    'verify_fused_measure_r2.py', 'verify_fused_measure_r3.py',
    'verify_fused_measure_packet_r1.py', 'verify_fused_measure_packet_r2.py',
    'validate_fused_measure_verifier_first_r1.py',
    'validate_fused_measure_verifier_r1.py', 'validate_fused_measure_verifier_r2.py',
    'validate_fused_measure_verifier_r3.py', 'switch_fused_measure_source_r2.py',
)
HARNESS_COPY = 'fused_measure_harness_r2.rs'
VALIDATIONS = (
    'fused-measure-dictionary-verifier-validation-r1.json',
    'fused-measure-runner-validation-r1.json',
    'fused-measure-verifier-first-environment-failure.json',
    'fused-measure-verifier-validation-r1.json',
    'fused-measure-verifier-validation-r2.json',
    'fused-measure-verifier-validation-r3.json',
    'fused-measure-verifier-validation-r4.json',
    'fused-measure-runner-validation-r2.json',
    'fused-measure-json-repro-identity-r1.json',
    'fused-measure-failed-observe-verification-r2.json',
    'fused-measure-observe-verification-r3.json',
    'fused-measure-measure-verification-r3.json',
    'fused-measure-verifier-validation-r5.json',
    'fused-measure-runner-validation-r3.json',
    'fused-measure-encoding-repro-identity-r1.json',
    'fused-measure-failed-tests-source-r3.json',
    'fused-measure-failed-tests-source-r3.tar.gz',
)
PREFIXES = (
    'fused-measure-baseline-debug-build-r1', 'fused-measure-baseline-release-build-r1',
    'fused-measure-candidate-debug-build-r1', 'fused-measure-candidate-release-build-r1',
    'fused-measure-prepare-inputs-r1', 'fused-measure-focused-r1',
    'fused-measure-focused-r2', 'fused-measure-native-clippy-r1',
    'fused-measure-native-clippy-r2', 'fused-measure-native-clippy-r3',
    'fused-measure-native-suite-r1',
    'fused-measure-baseline-debug-build-r2', 'fused-measure-baseline-release-build-r2',
    'fused-measure-candidate-debug-build-r2',
    'fused-measure-baseline-parser-r2', 'fused-measure-candidate-parser-r2',
    'fused-measure-native-clippy-r4',
    'fused-measure-json-repro-build-r1', 'fused-measure-json-repro-r1',
    'fused-measure-observation-verifier-r2',
    'fused-measure-encoding-repro-build-r1', 'fused-measure-encoding-repro-r1',
    'fused-measure-encoding-repro-build-r2', 'fused-measure-encoding-repro-r2',
    'fused-measure-native-tests-r3', 'fused-measure-candidate-debug-build-r3',
    'fused-measure-candidate-release-build-r3', 'fused-measure-native-suite-r3',
    'fused-measure-native-clippy-r5',
)
SOURCE_SWITCHES = ('fused-measure-source-baseline-r2.json',
                   'fused-measure-source-candidate-r2.json')
RUNTIME_VARIANTS = {
    ('r1', 'baseline'): ('release', 'observe'),
    ('r1', 'candidate'): ('release', 'observe'),
    ('r2', 'baseline'): ('release', 'observe'),
    ('r2', 'candidate'): ('observe',),
    ('r3', 'candidate'): ('release', 'observe'),
}
RUNTIME_FILES = tuple(
    f'fused-measure-{role}-runtime-{revision}/{label}-{suffix}'
    for (revision, role), labels in RUNTIME_VARIANTS.items()
    for label in labels for suffix in ('manifest.json', 'source-overlay.tar.gz'))
SUPPORT = ('fused-measure-support-r1/manifest.json',
           'fused-measure-support-r1/bounded_build_process_resume_20260912.py',
           'fused-measure-support-r1/release_validation_guard.py')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def regular(path):
    assert path.is_file() and not path.is_symlink(), f'not a regular file: {path}'
    assert stat.S_ISREG(path.stat().st_mode), f'not regular: {path}'


def add(path, members):
    regular(path)
    name = path.relative_to(P).as_posix()
    assert name not in members, f'duplicate packet path: {name}'
    members[name] = path.read_bytes()


def tree(name, mode, members, incomplete_r1=False):
    root = P / name
    assert root.is_dir() and not root.is_symlink(), name
    protocol = json.loads((root / 'protocol.json').read_text())
    outcome = json.loads((root / 'outcome.json').read_text())
    assert protocol['mode'] == outcome['mode'] == mode
    if incomplete_r1:
        # Preserve the observed failure as-is; do not turn it into a successful run.
        assert mode == 'observe' and protocol['schedule'] == outcome['schedule']
        calls = outcome['calls']
        assert len(calls) == 1
        item = calls[0]
        assert (item['case'], item['role'], item['cohort'], item['sample']) == (
            'dictionary_dense', 'baseline', 0, 0)
        assert item['status'] != 'passed'
        allowed = {'protocol.json', 'outcome.json',
                   'observe-dictionary_dense-baseline-0-0.log',
                   'supervision-observe-dictionary_dense-baseline-0-0.json'}
        assert not (root / 'observe-dictionary_dense-baseline-0-0.json').exists()
        assert sha((root / 'observe-dictionary_dense-baseline-0-0.log').read_bytes()) == item['log_sha256']
        supervision = json.loads((root / 'supervision-observe-dictionary_dense-baseline-0-0.json').read_text())
        assert supervision == item
        assert {p.name for p in root.iterdir()} == {
            'protocol.json', 'outcome.json', 'observe-dictionary_dense-baseline-0-0.log',
            'supervision-observe-dictionary_dense-baseline-0-0.json', 'witnesses'}
        assert len(list((root / 'witnesses').iterdir())) == 3
    else:
        schedule = expected_schedule(mode)
        assert protocol['schedule'] == outcome['schedule'] == [list(x) for x in schedule]
        calls = outcome['calls']
        assert len(calls) == len(schedule)
        if name.endswith('-r2'):
            runtime_roles = {'baseline': 'r2', 'candidate': 'r2'}
        elif name.endswith('-r3'):
            runtime_roles = {'baseline': 'r2', 'candidate': 'r3'}
        else:
            runtime_roles = None
        if runtime_roles is not None:
            assert set(outcome['runtime_manifests']) == set(ROLES)
            label = 'release' if mode == 'measure' else 'observe'
            for role, revision in runtime_roles.items():
                manifest = outcome['runtime_manifests'][role]
                expected_binary = P / f'fused-measure-{role}-runtime-{revision}' / f'shardloom-fused-measure-{label}'
                assert Path(manifest['binary']) == expected_binary
                assert manifest['binary_sha256'] == sha(expected_binary.read_bytes())
        allowed = {'protocol.json', 'outcome.json'}
        for n, item in enumerate(calls):
            case, role, cohort, sample = schedule[n]
            label = f'{mode}-{case}-{role}-{cohort}-{sample}'
            assert item['sequence'] == n + 1 and item['mode'] == mode
            assert (item['case'], item['role'], item['cohort'], item['sample']) == (case, role, cohort, sample)
            log = root / f'{label}.log'
            supervision = root / f'supervision-{label}.json'
            record = root / f'{label}.json'
            regular(log); regular(supervision)
            assert sha(log.read_bytes()) == item['log_sha256']
            assert json.loads(supervision.read_text()) == item
            allowed.update((log.name, supervision.name))
            if record.exists():
                regular(record)
                assert item.get('record_sha256') == sha(record.read_bytes())
                allowed.add(record.name)
            else:
                assert item['status'] != 'passed', f'missing successful record: {label}'
    witness_dir = root / 'witnesses'
    assert witness_dir.is_dir() and not witness_dir.is_symlink()
    for child in sorted(root.iterdir()):
        assert not child.is_symlink(), f'result symlink: {child}'
        if child.name == 'witnesses':
            for witness in sorted(child.iterdir()):
                regular(witness)
                assert re.fullmatch(r'[0-9a-f]{64}\.json', witness.name)
                raw = witness.read_bytes(); assert sha(raw) == witness.stem
                json.loads(raw); add(witness, members); allowed.add('witnesses/' + witness.name)
        else:
            regular(child)
            assert child.name in allowed, f'unexpected result entry: {child.name}'
            if child.suffix == '.json': json.loads(child.read_bytes())
            add(child, members)


def expected_schedule(mode):
    if mode == 'observe':
        return [(c, r, 0, 0) for c in CASES for r in ROLES]
    result = []
    for cohort in (1, 2):
        for case in CASES:
            for sample in (1, 2, 3):
                baseline_first = sample != 2 if cohort == 1 else sample == 2
                roles = ROLES if baseline_first else tuple(reversed(ROLES))
                result.extend((case, role, cohort, sample) for role in roles)
    return result


def inputs(members):
    root = P / 'fused-measure-inputs-r1'
    manifest_path = root / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    assert set(manifest) == set(CASES)
    expected = {'manifest.json'}
    for case, entry in manifest.items():
        assert entry['writer'] == 'sequential_native_flat'
        assert entry['chunk_rows'] == 65_536 and entry['file_statistics'] is False
        data_path = root / f'{case}.vortex'; regular(data_path)
        data = data_path.read_bytes()
        assert entry['bytes'] == len(data) and entry['sha256'] == sha(data)
        witness = entry['input_witness']
        assert re.fullmatch(r'[0-9a-f]{64}', witness)
        witness_path = root / 'witnesses' / f'{witness}.json'; regular(witness_path)
        raw = witness_path.read_bytes(); assert sha(raw) == witness
        json.loads(raw); expected.add(f'witnesses/{witness}.json'); add(witness_path, members)
        expected.add(f'{case}.vortex')
    actual = set()
    for path in root.rglob('*'):
        assert not path.is_symlink()
        if path.is_file(): regular(path); actual.add(path.relative_to(root).as_posix())
    assert actual == expected, f'input tree difference: {actual ^ expected}'
    add(manifest_path, members)


def runtimes():
    harness = 'shardloom-vortex/src/local_primitive_relational_fused_measure_cost_tests.rs'
    current_hash = sha((W / harness).read_bytes())
    saved_harness = P / HARNESS_COPY
    regular(saved_harness)
    assert sha(saved_harness.read_bytes()) == current_hash, 'saved r2 harness differs from shared W source'
    heads = {}
    for (revision, role), labels in RUNTIME_VARIANTS.items():
        root = P / f'fused-measure-{role}-runtime-{revision}'
        assert root.is_dir() and not root.is_symlink()
        wanted = {f'{label}-{suffix}' for label in labels
                  for suffix in ('manifest.json', 'source-overlay.tar.gz')}
        wanted.update(f'shardloom-fused-measure-{label}' for label in labels)
        assert {p.name for p in root.iterdir()} == wanted
        for label in labels:
            profile = 'release' if label == 'release' else 'ci-native'
            manifest = json.loads((root / f'{label}-manifest.json').read_text())
            assert manifest['profile'] == profile
            assert manifest['features'] == ['release-user-surfaces']
            # R1 is historical. R2's baseline reused the corrected source, and r2/r3
            # candidate runtimes use the same admitted harness. Do not equate r1 hashes
            # with the current worktree.
            if revision in ('r2', 'r3'):
                assert manifest['harnesses'] == {harness: current_hash}
                assert manifest['source_inventory'][harness] == current_hash
            binary = Path(manifest['binary'])
            expected_binary = root / f'shardloom-fused-measure-{label}'
            regular(binary); assert binary == expected_binary
            assert sha(binary.read_bytes()) == manifest['binary_sha256']
            overlay = manifest['source_overlay']
            overlay_path = root / f'{label}-source-overlay.tar.gz'
            regular(overlay_path); raw = overlay_path.read_bytes()
            assert Path(overlay['path']) == overlay_path and sha(raw) == overlay['sha256']
            with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
                entries = archive.getmembers()
                assert [e.name for e in entries] == sorted(overlay['members'])
                for e in entries:
                    assert e.isfile() and e.name in manifest['source_inventory']
                    assert overlay['members'][e.name] == manifest['source_inventory'][e.name]
                    body = archive.extractfile(e); assert body and sha(body.read()) == overlay['members'][e.name]
            receipt = manifest['build_receipt']; receipt_path = Path(receipt['path'])
            regular(receipt_path); assert receipt_path.parent == P
            assert sha(receipt_path.read_bytes()) == receipt['sha256']
            receipt_json = json.loads(receipt_path.read_text())
            assert receipt_json['status'] == 'passed' and receipt_json['returncode'] == 0
            log = receipt_path.with_suffix('.log'); regular(log)
            assert sha(log.read_bytes()) == receipt_json['log_sha256']
            if label == 'release': heads[(revision, role)] = manifest['revision']
    assert heads[('r2', 'baseline')] == heads[('r3', 'candidate')]
    assert heads[('r1', 'baseline')] == heads[('r1', 'candidate')]
    return heads[('r2', 'baseline')]


def reject_unlisted():
    allowed = set(HELPERS + VALIDATIONS + SOURCE_SWITCHES + RUNTIME_FILES + SUPPORT)
    allowed.update(f'{p}.{s}' for p in PREFIXES for s in ('json', 'log'))
    allowed.update(('fused-measure-inputs-r1', 'fused-measure-json-repro-r1',
                    'fused-measure-encoding-repro-r1', 'fused-measure-encoding-repro-r2',
                    'fused-measure-observations-r1', 'fused-measure-observations-r2',
                    'fused-measure-comparison-r3', 'fused-measure-observations-r3',
                    'fused-measure-baseline-runtime-r1', 'fused-measure-candidate-runtime-r1',
                    'fused-measure-baseline-runtime-r2', 'fused-measure-candidate-runtime-r2',
                    'fused-measure-candidate-runtime-r3', 'fused-measure-support-r1'))
    for path in P.iterdir():
        if path.name.startswith('fused-measure-'):
            assert path.name in allowed, f'unlisted fused-measure artifact: {path.name}'
    assert not (P / 'fused-measure-comparison-r1').exists(), 'no release r1 run was admitted'
    assert not (P / 'fused-measure-comparison-r2').exists(), 'r2 failed dictionary activation; no measurement tree is valid'


def pack(members):
    size = sum(map(len, members.values()))
    assert size <= MAX_RAW_BYTES, f'raw packet exceeds 64 MiB: {size}'
    out = io.BytesIO()
    with gzip.GzipFile(fileobj=out, mode='wb', filename='', mtime=0, compresslevel=9) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.USTAR_FORMAT) as tar:
            for name, body in sorted(members.items()):
                prefix, _, leaf = name.rpartition('/')
                assert len(leaf.encode()) <= 100 and len(prefix.encode()) <= 155
                info = tarfile.TarInfo(name); info.size = len(body)
                info.uid = info.gid = info.mtime = 0; info.uname = info.gname = ''
                info.mode = 0o644; info.type = tarfile.REGTYPE
                tar.addfile(info, io.BytesIO(body))
    return out.getvalue(), size


def verify_archive(raw, members):
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as tar:
        entries = tar.getmembers()
        assert [e.name for e in entries] == sorted(members)
        for e in entries:
            assert e.isfile() and (e.uid, e.gid, e.mtime, e.mode, e.uname, e.gname) == (0, 0, 0, 0o644, '', '')
            body = tar.extractfile(e); assert body and body.read() == members[e.name]
    assert raw[4:8] == b'\0\0\0\0'


def main():
    assert not DEST.exists(), f'destination already exists: {DEST}'
    reject_unlisted()
    members = {}
    tree('fused-measure-observations-r1', 'observe', members, incomplete_r1=True)
    tree('fused-measure-observations-r2', 'observe', members)
    tree('fused-measure-comparison-r3', 'measure', members)
    tree('fused-measure-observations-r3', 'observe', members)
    inputs(members)
    baseline_head = runtimes()
    support = json.loads((P / 'fused-measure-support-r1/manifest.json').read_text())
    assert len(support) == 2
    for original, item in support.items():
        saved = P / 'fused-measure-support-r1' / item['path']; regular(saved)
        raw = saved.read_bytes(); assert sha(raw) == item['sha256'] and len(raw) == item['bytes']
        assert sha(Path(original).read_bytes()) == item['sha256']
    for name in HELPERS + VALIDATIONS + SOURCE_SWITCHES + RUNTIME_FILES + SUPPORT:
        add(P / name, members)
    add(P / HARNESS_COPY, members)
    add(P / 'fused_measure_encoding_repro_r1.rs', members)
    add(P / 'fused_measure_encoding_repro_r2.rs', members)
    # R1 observation failed; r2 observation completed calls but failed activation, so it
    # carries no measurement tree or successful verifier receipt.
    for prefix in PREFIXES:
        for suffix in ('json', 'log'):
            add(P / f'{prefix}.{suffix}', members)
    add(P / 'fused_measure_json_roundtrip_repro_r1.rs', members)
    archive, raw_size = pack(members); verify_archive(archive, members)
    DEST.mkdir(parents=True, exist_ok=False)
    archive_path = DEST / 'packet.tar.gz'
    with archive_path.open('xb') as f:
        f.write(archive); f.flush(); os.fsync(f.fileno())
    disk = archive_path.read_bytes(); assert disk == archive; verify_archive(disk, members)
    manifest = {'schema_version': 'shardloom.native_fused_measure.packet.v3',
                'archive': {'path': 'packet.tar.gz', 'sha256': sha(disk), 'bytes': len(disk)},
                'files': [{'path': n, 'sha256': sha(b), 'bytes': len(b)} for n, b in sorted(members.items())],
                'baseline_head': baseline_head,
                'status': 'finite_mechanism_evidence_captured_package_acceptance_pending',
                'notes': 'R1 preserves one failed baseline dense observation. R2 preserves all 12 observation calls but failed actual dictionary activation and has no measurement comparison. R3 is the first corrected candidate observation and comparison evidence. No Full43 completion or package acceptance is claimed.',
                'raw_member_bytes': raw_size}
    with (DEST / 'manifest.json').open('x') as f:
        json.dump(manifest, f, indent=2); f.write('\n'); f.flush(); os.fsync(f.fileno())
    print(json.dumps({'archive': str(archive_path), 'manifest': str(DEST / 'manifest.json'),
                      'archive_sha256': manifest['archive']['sha256'], 'archive_bytes': len(disk),
                      'member_count': len(members), 'raw_member_bytes': raw_size,
                      'readback_verified': True}))


if __name__ == '__main__':
    main()
