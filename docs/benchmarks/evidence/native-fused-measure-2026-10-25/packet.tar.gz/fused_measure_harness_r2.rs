//! Frozen first-execution comparison; identical source in both compared builds.

use super::*;
use crate::{
    query_primitive::VortexSimpleAggregateMeasure,
    relational_query::{
        VortexRelationalAggregate, VortexRelationalFilter, VortexRelationalProject,
    },
};
use serde_json::{Value, json};
use sha2::{Digest as _, Sha256};
use shardloom_core::{BinaryOp, ComparisonOp, ExprId, Expression, ExpressionKind, ScalarValue};
use std::{collections::BTreeMap, io::Write as _, path::Path, time::Instant};
use vortex::array::arrays::{DictArray, VarBinViewArray};

const CASES: &[(&str, usize, usize)] = &[
    ("dictionary_dense", 262_144, 64),
    ("dictionary_skew", 262_144, 64),
    ("dictionary_sparse", 262_144, 64),
    ("plain_high_cardinality", 65_536, 8_192),
    ("tiny", 17, 7),
    ("ineligible_i64", 65_536, 64),
];
const GRANT: u64 = 128 << 20;

struct Data {
    domain: Vec<Option<String>>,
    codes: Vec<u32>,
    numbers: Vec<Option<i32>>,
    predicates: Vec<i64>,
}

impl Data {
    fn new(case: &str, rows: usize, keys: usize) -> Self {
        Self {
            domain: (0..keys)
                .map(|key| Some(format!("clé-東京-{key}")))
                .chain([None])
                .collect(),
            codes: (0..rows)
                .map(|row| {
                    u32::try_from(if row.is_multiple_of(97) {
                        keys
                    } else if case == "dictionary_skew" && row % 10 != 9 {
                        0
                    } else {
                        row % keys
                    })
                    .unwrap()
                })
                .collect(),
            numbers: (0..rows)
                .map(|row| {
                    (!row.is_multiple_of(19)).then(|| i32::try_from(row % 1009).unwrap() - 504)
                })
                .collect(),
            predicates: (0..rows)
                .map(|row| {
                    i64::try_from(row % if case == "dictionary_sparse" { 100 } else { 5 }).unwrap()
                })
                .collect(),
        }
    }

    fn array(&self, case: &str) -> ArrayRef {
        let groups = if case == "plain_high_cardinality" {
            VarBinViewArray::from_iter_nullable_str(
                self.codes
                    .iter()
                    .map(|&code| self.domain[code as usize].as_deref()),
            )
            .into_array()
        } else {
            DictArray::try_new(
                PrimitiveArray::from_iter(self.codes.iter().copied()).into_array(),
                VarBinViewArray::from_iter_nullable_str(self.domain.iter().map(Option::as_deref))
                    .into_array(),
            )
            .unwrap()
            .into_array()
        };
        let values = if case == "ineligible_i64" {
            PrimitiveArray::from_option_iter(self.numbers.iter().map(|n| n.map(i64::from)))
                .into_array()
        } else {
            PrimitiveArray::from_option_iter(self.numbers.iter().copied()).into_array()
        };
        StructArray::try_new(
            FieldNames::from(["g", "n", "p"]),
            vec![
                groups,
                values,
                PrimitiveArray::from_iter(self.predicates.iter().copied()).into_array(),
            ],
            self.codes.len(),
            Validity::NonNullable,
        )
        .unwrap()
        .into_array()
    }

    fn witness(&self) -> Value {
        json!({"domain":self.domain,"codes":self.codes,"n":self.numbers,"p":self.predicates})
    }

    fn expected(&self) -> (Vec<Value>, usize) {
        // Native hashes, expression kernels and aggregate state are not the oracle.
        let mut groups = BTreeMap::<Option<&str>, (usize, u64, u64, i64)>::new();
        let mut selected = 0;
        for row in 0..self.codes.len() {
            if !(1..=3).contains(&self.predicates[row]) {
                continue;
            }
            selected += 1;
            let key = self.domain[self.codes[row] as usize].as_deref();
            let group = groups.entry(key).or_insert((row, 0, 0, 0));
            group.1 += 1;
            if let Some(value) = self.numbers[row] {
                group.2 += 1;
                group.3 = group.3.checked_add(i64::from(value) * 3).unwrap();
            }
        }
        let mut groups = groups.into_iter().collect::<Vec<_>>();
        groups.sort_by_key(|(_, value)| value.0);
        let rows = groups
            .into_iter()
            .map(|(key, (_, rows, count, sum))| {
                assert!(sum.unsigned_abs() < (1 << 53) && count < (1 << 53));
                #[allow(clippy::cast_precision_loss)]
                // Fixture sums/counts are checked in exact F64 integer range.
                let (sum, avg) = if count == 0 {
                    (None, None)
                } else {
                    (Some(sum as f64), Some(sum as f64 / count as f64))
                };
                json!({"group":key,"rows":rows,"values":count,"sum":sum,"avg":avg})
            })
            .collect();
        (rows, selected)
    }
}

fn expr(kind: ExpressionKind) -> Expression {
    Expression::new(ExprId::new("fused-cost").unwrap(), kind)
}
fn col(name: &str) -> Expression {
    expr(ExpressionKind::Column(ColumnRef::new(name).unwrap()))
}
fn lit(value: i64) -> Expression {
    expr(ExpressionKind::Literal(ScalarValue::Int64(value)))
}

fn plan(path: &Path) -> VortexRelationalPlan {
    let compare = |op, value| {
        expr(ExpressionKind::Compare {
            left: Box::new(col("p")),
            op,
            right: Box::new(lit(value)),
        })
    };
    VortexRelationalPlan::Aggregate(Box::new(VortexRelationalAggregate {
        input: VortexRelationalPlan::Project(Box::new(VortexRelationalProject {
            input: VortexRelationalPlan::Filter(Box::new(VortexRelationalFilter {
                input: VortexRelationalPlan::Scan(VortexRelationalScan {
                    source_uri: DatasetUri::new(path.display().to_string()).unwrap(),
                    projection: shardloom_plan::ProjectionRequest::All,
                    predicate: None,
                }),
                predicate: expr(ExpressionKind::Binary {
                    left: Box::new(compare(ComparisonOp::GtEq, 1)),
                    op: BinaryOp::And,
                    right: Box::new(compare(ComparisonOp::LtEq, 3)),
                }),
            })),
            expressions: vec![
                ("group".into(), col("g")),
                (
                    "computed".into(),
                    expr(ExpressionKind::Binary {
                        left: Box::new(col("n")),
                        op: BinaryOp::Multiply,
                        right: Box::new(lit(3)),
                    }),
                ),
            ],
        })),
        group_by: vec![ColumnRef::new("group").unwrap()],
        measures: [
            ("count", None, "rows"),
            ("count", Some("computed"), "values"),
            ("sum", Some("computed"), "sum"),
            ("avg", Some("computed"), "avg"),
        ]
        .into_iter()
        .map(|(function, name, alias)| {
            VortexSimpleAggregateMeasure::new(
                function,
                name.map(|name| ColumnRef::new(name).unwrap()),
                alias.into(),
            )
        })
        .collect(),
    }))
}

fn digest(bytes: &[u8]) -> String {
    let mut output = String::with_capacity(64);
    for byte in Sha256::digest(bytes) {
        use std::fmt::Write as _;
        write!(output, "{byte:02x}").unwrap();
    }
    output
}

fn write_new(path: &Path, bytes: &[u8]) {
    fs::OpenOptions::new()
        .create_new(true)
        .write(true)
        .open(path)
        .unwrap()
        .write_all(bytes)
        .unwrap();
}

fn witness(root: &Path, value: &Value) -> String {
    let bytes = serde_json::to_vec(value).unwrap();
    let sha = digest(&bytes);
    let path = root.join("witnesses").join(format!("{sha}.json"));
    if path.exists() {
        assert_eq!(fs::read(path).unwrap(), bytes);
    } else {
        write_new(&path, &bytes);
    }
    sha
}

fn exact_rows(text: &str) -> Vec<Value> {
    text.lines()
        .map(|line| {
            let raw: BTreeMap<String, &serde_json::value::RawValue> =
                serde_json::from_str(line).unwrap();
            raw.into_iter()
                .map(|(name, value)| {
                    // This test build does not enable serde_json's float_roundtrip
                    // parser. Preserve the emitted numeric text and use Rust's
                    // correctly rounded parser before comparing exact F64 bits.
                    let value = if matches!(name.as_str(), "sum" | "avg") && value.get() != "null" {
                        let value = value.get().parse::<f64>().unwrap();
                        assert!(value.is_finite());
                        json!(value)
                    } else {
                        serde_json::from_str(value.get()).unwrap()
                    };
                    (name, value)
                })
                .collect::<serde_json::Map<_, _>>()
                .into()
        })
        .collect()
}

#[test]
fn fused_measure_witness_parser_preserves_exact_emitted_average_bits() {
    for (sum, count) in [(-219.0_f64, 2306_u32), (-5211.0, 2305), (1011.0, 2303)] {
        let expected = json!({"group":"clé-東京","rows":count,"values":count,
            "sum":sum,"avg":sum / f64::from(count)});
        let text = serde_json::to_string(&expected).unwrap();
        assert_eq!(exact_rows(&text), vec![expected]);
    }
    let empty = json!({"group":null,"rows":0,"values":0,"sum":null,"avg":null});
    assert_eq!(
        exact_rows(&serde_json::to_string(&empty).unwrap()),
        vec![empty]
    );
}

#[test]
#[ignore = "prepare immutable fused-measure inputs once under the storage guard"]
fn prepare_native_fused_measure_inputs() {
    let root = PathBuf::from(std::env::var("SHARDLOOM_FUSED_MEASURE_INPUTS").unwrap());
    assert!(root.is_absolute() && root.join("witnesses").is_dir());
    let mut manifest = BTreeMap::new();
    for &(case, rows, keys) in CASES {
        let data = Data::new(case, rows, keys);
        let array = data.array(case);
        let schema = serde_json::to_value(array.dtype()).unwrap();
        let fixture = Fixture::new(array, 65_536);
        let bytes = fs::read(fixture.path()).unwrap();
        write_new(&root.join(format!("{case}.vortex")), &bytes);
        manifest.insert(
            case,
            json!({"sha256":digest(&bytes),"bytes":bytes.len(),
            "rows":rows,"keys":keys,"schema":schema,"input_witness":witness(&root,&data.witness()),
            "writer":"sequential_native_flat","chunk_rows":65_536,"file_statistics":false}),
        );
    }
    write_new(
        &root.join("manifest.json"),
        &serde_json::to_vec_pretty(&manifest).unwrap(),
    );
}

#[allow(clippy::too_many_lines)] // Keep complete first-execution, semantic and ownership evidence together.
fn run(root: &Path, inputs: &Path, case: &str, rows: usize, keys: usize) -> Value {
    let data = Data::new(case, rows, keys);
    let (expected, selected) = data.expected();
    let input_witness = witness(root, &data.witness());
    let expected_witness = witness(root, &json!(expected));
    let path = inputs.join(format!("{case}.vortex"));
    let manifest: Value =
        serde_json::from_slice(&fs::read(inputs.join("manifest.json")).unwrap()).unwrap();
    assert_eq!(manifest[case]["input_witness"], input_witness);
    assert_eq!(manifest[case]["sha256"], digest(&fs::read(&path).unwrap()));
    let schema = DType::struct_(
        vec![
            ("group", DType::Utf8(Nullability::Nullable)),
            (
                "rows",
                DType::Primitive(PType::U64, Nullability::NonNullable),
            ),
            (
                "values",
                DType::Primitive(PType::U64, Nullability::NonNullable),
            ),
            ("sum", DType::Primitive(PType::F64, Nullability::Nullable)),
            ("avg", DType::Primitive(PType::F64, Nullability::Nullable)),
        ],
        Nullability::NonNullable,
    );
    let schema_witness = witness(root, &serde_json::to_value(&schema).unwrap());
    let declaration = plan(&path);
    let mut resources = policy();
    resources.resource_envelope.memory_budget_bytes = GRANT;
    let start = Instant::now();
    let prepared = prepare_relational(&declaration, resources).unwrap();
    let preparation_ns = start.elapsed().as_nanos();
    assert_eq!(prepared.output_dtype().as_ref(), Some(&schema));
    let memory = prepared.session.memory().clone();
    let before = memory.snapshot().reserved_bytes;
    #[cfg(debug_assertions)]
    let observation = crate::local_primitives::native_relational_observation::Session::start();
    let result = prepared
        .collect_jsonl(&CancellationToken::default())
        .unwrap();
    #[cfg(debug_assertions)]
    let observations = serde_json::to_value(observation.finish()).unwrap();
    #[cfg(not(debug_assertions))]
    let observations = Value::Null;
    let raw_rows_witness = witness(root, &json!(result.result_jsonl.value()));
    let actual = exact_rows(result.result_jsonl.value());
    assert_eq!(actual, expected, "{case} complete ordered values");
    assert_eq!(
        serde_json::from_str::<Value>(result.result_schema_json.value()).unwrap(),
        serde_json::to_value(&schema).unwrap()
    );
    let actual_witness = witness(root, &json!(actual));
    assert_eq!(actual_witness, expected_witness);
    let certificate = &result.execution.native_io_certificate;
    assert!(certificate.is_certified());
    assert!(!certificate.side_effects.fallback_attempted);
    let certificate = format!("{certificate:#?}");
    let runtime = format!("{:#?}", result.execution.runtime);
    let engine_ns = result.timing.execution.as_nanos();
    let serialization_ns = result.timing.result_serialization.as_nanos();
    drop(result);
    assert_eq!(memory.snapshot().reserved_bytes, before);
    let snapshot = prepared.snapshot();
    assert_eq!(snapshot.completed_executions, 1);
    assert_eq!(snapshot.admitted_max_parallelism, 1);
    assert_eq!(snapshot.provider_background_workers, 0);
    drop(prepared);
    let memory = memory.snapshot();
    assert_eq!(memory.reserved_bytes, 0);
    assert_eq!(memory.denied_reservations, 0);
    assert!(memory.peak_reserved_bytes <= GRANT);
    json!({"case":case,"input_rows":rows,"selected_rows":selected,"input_witness":input_witness,
        "input_file":manifest[case],"expected_rows_witness":expected_witness,"actual_rows_witness":actual_witness,
        "raw_rows_witness":raw_rows_witness,
        "schema_witness":schema_witness,"engine_execution_ns":engine_ns,"preparation_ns":preparation_ns,
        "result_serialization_ns":serialization_ns,"memory_grant_bytes":GRANT,"reserved_before_execution":before,
        "peak_reserved_bytes":memory.peak_reserved_bytes,"reserved_after_cleanup":0,"denied_reservations":0,
        "observations":observations,"observation_enabled":cfg!(debug_assertions),
        "native_io_certificate":certificate,"runtime":runtime,"complete_values_match":true,"complete_schema_match":true})
}

#[test]
#[ignore = "frozen fused-measure comparison; guarded serial execution only"]
fn native_fused_measure_cost_screen() {
    let variable = |suffix| std::env::var(format!("SHARDLOOM_FUSED_MEASURE_{suffix}")).unwrap();
    let root = PathBuf::from(variable("ROOT"));
    let inputs = PathBuf::from(variable("INPUTS"));
    assert!(root.is_absolute() && root.join("witnesses").is_dir() && inputs.is_absolute());
    let requested = variable("CASE");
    let &(case, rows, keys) = CASES
        .iter()
        .find(|case| case.0 == requested)
        .expect("frozen case");
    let role = variable("ROLE");
    assert!(matches!(role.as_str(), "baseline" | "candidate"));
    let cohort = variable("COHORT").parse::<usize>().unwrap();
    let sample = variable("SAMPLE").parse::<usize>().unwrap();
    assert!(cohort <= 2 && sample <= 3);
    let mode = if cfg!(debug_assertions) {
        "observe"
    } else {
        "measure"
    };
    let path = root.join(format!("{mode}-{case}-{role}-{cohort}-{sample}.json"));
    assert!(!path.exists(), "preserve every observation");
    let mut record = run(&root, &inputs, case, rows, keys);
    record["protocol"] = json!("native-fused-measure-v2");
    record["role"] = json!(role);
    record["cohort"] = json!(cohort);
    record["sample"] = json!(sample);
    write_new(&path, &serde_json::to_vec_pretty(&record).unwrap());
    println!("fused_measure_record={}", path.display());
}
