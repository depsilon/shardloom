"""Package finite fused-measure evidence without native Vortex payloads."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import tarfile

P = Path('/Users/dylan/LocalData/shardloom/workflow-work-elimination-20261025')
W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
DEST = W / 'docs/benchmarks/evidence/native-fused-measure-2026-10-25'
MAX_RAW_BYTES = 64 * 1024 * 1024
CASES = (
    'dictionary_dense', 'dictionary_skew', 'dictionary_sparse',
    'plain_high_cardinality', 'tiny', 'ineligible_i64',
)

HELPER_FILES = (
    'build_fused_measure_packet_r1.py',
    'freeze_fused_measure_r1.py',
    'run_fused_measure_r1.py',
    'run_guarded.py',
    'verify_fused_measure_before_dictionary_r1.py',
    'verify_fused_measure_r1.py',
    'validate_fused_measure_verifier_first_r1.py',
    'validate_fused_measure_verifier_r1.py',
)
VALIDATION_RECEIPTS = (
    'fused-measure-dictionary-verifier-validation-r1.json',
    'fused-measure-runner-validation-r1.json',
    'fused-measure-verifier-first-environment-failure.json',
    'fused-measure-verifier-validation-r1.json',
    'fused-measure-verifier-validation-r2.json',
    'fused-measure-verifier-validation-r3.json',
    'fused-measure-measure-verification-r1.json',
    'fused-measure-observe-verification-r1.json',
)
RUN_PREFIXES = (
    'fused-measure-baseline-debug-build-r1',
    'fused-measure-baseline-release-build-r1',
    'fused-measure-candidate-debug-build-r1',
    'fused-measure-candidate-release-build-r1',
    'fused-measure-prepare-inputs-r1',
    'fused-measure-focused-r1',
    'fused-measure-focused-r2',
    'fused-measure-native-clippy-r1',
    'fused-measure-native-clippy-r2',
    'fused-measure-native-clippy-r3',
    'fused-measure-native-suite-r1',
)
RUNTIME_FILES = tuple(
    f'fused-measure-{role}-runtime-r1/{name}'
    for role in ('baseline', 'candidate')
    for name in ('release-manifest.json', 'release-source-overlay.tar.gz',
                 'observe-manifest.json', 'observe-source-overlay.tar.gz')
)
SUPPORT_FILES = (
    'fused-measure-support-r1/manifest.json',
    'fused-measure-support-r1/bounded_build_process_resume_20260912.py',
    'fused-measure-support-r1/release_validation_guard.py',
)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def require_regular(path):
    assert path.is_file() and not path.is_symlink(), f'not a regular non-symlink file: {path}'
    assert stat.S_ISREG(path.stat().st_mode), f'not regular: {path}'


def include(path, members):
    require_regular(path)
    relative = path.relative_to(P).as_posix()
    assert relative not in members, f'duplicate archive member: {relative}'
    members[relative] = path.read_bytes()


def include_inputs(members):
    root = P / 'fused-measure-inputs-r1'
    assert root.is_dir() and not root.is_symlink()
    manifest_path = root / 'manifest.json'
    fixture_manifest = json.loads(manifest_path.read_text())
    assert set(fixture_manifest) == set(CASES)
    expected = {'manifest.json'}
    for case in CASES:
        entry = fixture_manifest[case]
        assert entry['writer'] == 'sequential_native_flat'
        assert entry['chunk_rows'] == 65_536 and entry['file_statistics'] is False
        vortex_name = f'{case}.vortex'
        vortex_path = root / vortex_name
        require_regular(vortex_path)
        vortex_bytes = vortex_path.read_bytes()
        assert entry['bytes'] == len(vortex_bytes)
        assert entry['sha256'] == sha256(vortex_bytes)
        expected.add(vortex_name)
        witness_id = entry['input_witness']
        assert isinstance(witness_id, str) and re.fullmatch(r'[0-9a-f]{64}', witness_id)
        witness_name = f'witnesses/{witness_id}.json'
        witness_path = root / witness_name
        require_regular(witness_path)
        witness_bytes = witness_path.read_bytes()
        assert sha256(witness_bytes) == witness_id
        json.loads(witness_bytes)
        expected.add(witness_name)
        include(witness_path, members)
    actual = set()
    for path in root.rglob('*'):
        assert not path.is_symlink(), f'input symlink rejected: {path}'
        if path.is_dir():
            continue
        require_regular(path)
        actual.add(path.relative_to(root).as_posix())
    assert actual == expected, f'unexpected fixed-input tree entries: {actual ^ expected}'
    include(manifest_path, members)


def include_result_tree(name, mode, members):
    root = P / name
    assert root.is_dir() and not root.is_symlink(), name
    assert (root / 'protocol.json').is_file() and (root / 'outcome.json').is_file()
    call = re.compile(
        rf'^(?:supervision-)?{mode}-(?:'
        + '|'.join(re.escape(case) for case in CASES)
        + r')-(?:baseline|candidate)-(?:0|1|2)-(?:0|1|2|3)\.(?:json|log)$'
    )
    protocol = json.loads((root / 'protocol.json').read_text())
    outcome = json.loads((root / 'outcome.json').read_text())
    assert protocol['mode'] == outcome['mode'] == mode
    schedule = expected_schedule(mode)
    assert protocol['schedule'] == outcome['schedule'] == [list(item) for item in schedule]
    calls = outcome['calls']
    assert len(calls) <= len(schedule)
    assert [(item['case'], item['role'], item['cohort'], item['sample'])
            for item in calls] == schedule[:len(calls)]
    allowed_names = {'protocol.json', 'outcome.json'}
    for index, call_item in enumerate(calls, 1):
        case, role, cohort, sample = schedule[index - 1]
        label = f'{mode}-{case}-{role}-{cohort}-{sample}'
        assert call_item['sequence'] == index
        assert call_item['mode'] == mode
        assert (call_item['case'], call_item['role'], call_item['cohort'], call_item['sample']) == (
            case, role, cohort, sample)
        log_name = label + '.log'
        supervision_name = f'supervision-{label}.json'
        assert (root / log_name).is_file() and (root / supervision_name).is_file()
        allowed_names.update((log_name, supervision_name))
        if (root / (label + '.json')).exists():
            allowed_names.add(label + '.json')
            if call_item.get('record_sha256'):
                assert sha256((root / (label + '.json')).read_bytes()) == call_item['record_sha256']
        elif call_item['status'] == 'passed':
            raise AssertionError(f'passed operation has no record: {label}')
        assert sha256((root / log_name).read_bytes()) == call_item['log_sha256']
        assert json.loads((root / supervision_name).read_text()) == call_item
    for child in sorted(root.iterdir()):
        assert not child.is_symlink(), f'result symlink rejected: {child}'
        if child.name == 'witnesses':
            assert child.is_dir()
            for witness in sorted(child.iterdir()):
                assert not witness.is_symlink(), f'witness symlink rejected: {witness}'
                assert witness.is_file() and re.fullmatch(r'[0-9a-f]{64}\.json', witness.name)
                payload = witness.read_bytes()
                assert sha256(payload) == witness.stem
                json.loads(payload)
                include(witness, members)
                allowed_names.add(f'witnesses/{witness.name}')
        else:
            assert child.is_file() and not child.is_symlink(), child
            assert child.name in allowed_names, f'unexpected result tree member: {child.name}'
            if child.suffix == '.json':
                json.loads(child.read_bytes())
            include(child, members)
    assert (root / 'witnesses').is_dir(), f'witness directory absent: {root}'


def expected_schedule(mode):
    cases = CASES
    if mode == 'observe':
        return [(case, role, 0, 0) for case in cases
                for role in ('baseline', 'candidate')]
    calls = []
    for cohort in (1, 2):
        for case in cases:
            for sample in (1, 2, 3):
                baseline_first = (sample != 2) if cohort == 1 else (sample == 2)
                roles = ('baseline', 'candidate') if baseline_first else ('candidate', 'baseline')
                calls.extend((case, role, cohort, sample) for role in roles)
    return calls


def verify_runtime_manifests():
    harness = 'shardloom-vortex/src/local_primitive_relational_fused_measure_cost_tests.rs'
    harness_hash = hashlib.sha256((W / harness).read_bytes()).hexdigest()
    manifests = {}
    for role in ('baseline', 'candidate'):
        runtime = P / f'fused-measure-{role}-runtime-r1'
        assert runtime.is_dir() and not runtime.is_symlink()
        expected_runtime_names = {
            'release-manifest.json', 'release-source-overlay.tar.gz',
            'observe-manifest.json', 'observe-source-overlay.tar.gz',
            'shardloom-fused-measure-release', 'shardloom-fused-measure-observe',
        }
        assert {path.name for path in runtime.iterdir()} == expected_runtime_names
        assert all(not path.is_symlink() for path in runtime.iterdir())
        for profile, label in (('release', 'release'), ('ci-native', 'observe')):
            path = runtime / f'{label}-manifest.json'
            manifest = json.loads(path.read_text())
            assert manifest['profile'] == profile
            assert manifest['features'] == ['release-user-surfaces']
            assert manifest['harnesses'] == {harness: harness_hash}
            assert manifest['source_inventory'][harness] == harness_hash
            binary = Path(manifest['binary'])
            expected_binary = runtime / f'shardloom-fused-measure-{label}'
            require_regular(binary)
            assert binary == expected_binary
            assert sha256(binary.read_bytes()) == manifest['binary_sha256']

            overlay = manifest['source_overlay']
            overlay_path = runtime / f'{label}-source-overlay.tar.gz'
            assert Path(overlay['path']) == overlay_path
            require_regular(overlay_path)
            overlay_bytes = overlay_path.read_bytes()
            assert sha256(overlay_bytes) == overlay['sha256']
            source_members = overlay['members']
            with tarfile.open(fileobj=io.BytesIO(overlay_bytes), mode='r:gz') as archive:
                entries = archive.getmembers()
                assert [entry.name for entry in entries] == sorted(source_members)
                for entry in entries:
                    assert entry.isfile() and entry.name in manifest['source_inventory']
                    assert source_members[entry.name] == manifest['source_inventory'][entry.name]
                    extracted = archive.extractfile(entry)
                    assert extracted is not None
                    assert sha256(extracted.read()) == source_members[entry.name]

            receipt = manifest['build_receipt']
            receipt_path = Path(receipt['path'])
            require_regular(receipt_path)
            assert receipt_path.parent == P and sha256(receipt_path.read_bytes()) == receipt['sha256']
            receipt_json = json.loads(receipt_path.read_text())
            assert receipt_json['status'] == 'passed' and receipt_json['returncode'] == 0
            assert receipt_json['direct_child_reaped'] and receipt_json['process_group_drained']
            log_path = receipt_path.with_suffix('.log')
            require_regular(log_path)
            assert sha256(log_path.read_bytes()) == receipt_json['log_sha256']
            manifests[(role, profile)] = manifest

    baseline_release = manifests[('baseline', 'release')]
    candidate_release = manifests[('candidate', 'release')]
    baseline_debug = manifests[('baseline', 'ci-native')]
    candidate_debug = manifests[('candidate', 'ci-native')]
    for manifest in (baseline_debug, candidate_release, candidate_debug):
        assert manifest['toolchain'] == baseline_release['toolchain']
        assert manifest['revision'] == baseline_release['revision']
    assert baseline_release['source_inventory'] == baseline_debug['source_inventory']
    assert candidate_release['source_inventory'] == candidate_debug['source_inventory']
    assert set(baseline_release['source_inventory']) <= set(candidate_release['source_inventory'])
    assert baseline_release['harnesses'] == candidate_release['harnesses']
    assert baseline_release['features'] == candidate_release['features']
    return baseline_release['revision']


def reject_unlisted_fused_measure_entries():
    expected = set(HELPER_FILES) | set(VALIDATION_RECEIPTS) | set(RUNTIME_FILES)
    expected.update(f'{prefix}.{suffix}' for prefix in RUN_PREFIXES
                    for suffix in ('json', 'log'))
    expected.update((
        'fused-measure-inputs-r1',
        'fused-measure-comparison-r1',
        'fused-measure-observations-r1',
        'fused-measure-baseline-runtime-r1',
        'fused-measure-candidate-runtime-r1',
        'fused-measure-support-r1',
    ))
    for path in P.iterdir():
        if path.name.startswith('fused-measure-'):
            assert path.name in expected, f'unlisted fused-measure evidence: {path.name}'


def pack(members):
    raw_bytes = sum(len(payload) for payload in members.values())
    assert raw_bytes <= MAX_RAW_BYTES, f'raw packet exceeds 64 MiB: {raw_bytes}'
    output = io.BytesIO()
    with gzip.GzipFile(fileobj=output, mode='wb', filename='',
                       mtime=0, compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode='w',
                          format=tarfile.USTAR_FORMAT) as archive:
            for name, payload in sorted(members.items()):
                prefix, _, leaf = name.rpartition('/')
                assert len(leaf.encode('utf-8')) <= 100
                assert len(prefix.encode('utf-8')) <= 155, name
                entry = tarfile.TarInfo(name)
                entry.size = len(payload)
                entry.uid = entry.gid = entry.mtime = 0
                entry.uname = entry.gname = ''
                entry.mode = 0o644
                entry.type = tarfile.REGTYPE
                archive.addfile(entry, io.BytesIO(payload))
    return output.getvalue(), raw_bytes


def verify_archive(archive_bytes, members):
    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:gz') as archive:
        entries = archive.getmembers()
        assert [entry.name for entry in entries] == sorted(members)
        for entry in entries:
            assert entry.isfile() and entry.uid == entry.gid == entry.mtime == 0
            assert entry.mode == 0o644 and entry.uname == entry.gname == ''
            extracted = archive.extractfile(entry)
            assert extracted is not None
            assert extracted.read() == members[entry.name]
    assert archive_bytes[4:8] == b'\0\0\0\0'


def main():
    assert not DEST.exists(), f'destination already exists: {DEST}'
    reject_unlisted_fused_measure_entries()
    members = {}
    include_result_tree('fused-measure-comparison-r1', 'measure', members)
    include_result_tree('fused-measure-observations-r1', 'observe', members)
    include_inputs(members)
    baseline_head = verify_runtime_manifests()
    support = json.loads((P / 'fused-measure-support-r1/manifest.json').read_text())
    assert len(support) == 2
    for original, item in support.items():
        raw = (P / 'fused-measure-support-r1' / item['path']).read_bytes()
        assert sha256(raw) == item['sha256'] and len(raw) == item['bytes']
        assert sha256(Path(original).read_bytes()) == item['sha256']
    for relative in HELPER_FILES + VALIDATION_RECEIPTS + RUNTIME_FILES + SUPPORT_FILES:
        include(P / relative, members)
    for prefix in RUN_PREFIXES:
        include(P / f'{prefix}.json', members)
        include(P / f'{prefix}.log', members)

    archive_bytes, raw_bytes = pack(members)
    verify_archive(archive_bytes, members)
    DEST.mkdir(parents=True, exist_ok=False)
    archive_path = DEST / 'packet.tar.gz'
    with archive_path.open('xb') as stream:
        stream.write(archive_bytes)
        stream.flush()
        os.fsync(stream.fileno())
    disk_archive = archive_path.read_bytes()
    assert disk_archive == archive_bytes
    verify_archive(disk_archive, members)
    manifest = {
        'schema_version': 'shardloom.native_fused_measure.packet.v1',
        'archive': {'path': 'packet.tar.gz', 'sha256': sha256(disk_archive),
                    'bytes': len(disk_archive)},
        'files': [
            {'path': name, 'sha256': sha256(payload), 'bytes': len(payload)}
            for name, payload in sorted(members.items())
        ],
        'baseline_head': baseline_head,
        'status': 'finite_mechanism_evidence_captured_package_acceptance_pending',
        'notes': (
            'The actual gate decision is retained in the archived verifier summaries. '
            'This packet does not claim Full43 completion or package acceptance.'
        ),
        'raw_member_bytes': raw_bytes,
    }
    manifest_path = DEST / 'manifest.json'
    with manifest_path.open('x') as stream:
        json.dump(manifest, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    print(json.dumps({
        'archive': str(archive_path), 'manifest': str(manifest_path),
        'archive_sha256': manifest['archive']['sha256'],
        'archive_bytes': manifest['archive']['bytes'],
        'member_count': len(members), 'raw_member_bytes': raw_bytes,
        'readback_verified': True,
    }))


if __name__ == '__main__':
    main()
