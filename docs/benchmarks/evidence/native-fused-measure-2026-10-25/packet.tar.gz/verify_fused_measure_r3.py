"""Primary finite verifier: complete values, source closure, execution and benefit gates."""
import hashlib
import json
from pathlib import Path
import re
import statistics
import sys
import tarfile

P = Path('/Users/dylan/LocalData/shardloom/workflow-work-elimination-20261025')
W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
HARNESS = 'shardloom-vortex/src/local_primitive_relational_fused_measure_cost_tests.rs'
CASES = {'dictionary_dense': (262144, 64), 'dictionary_skew': (262144, 64),
         'dictionary_sparse': (262144, 64), 'plain_high_cardinality': (65536, 8192),
         'tiny': (17, 7), 'ineligible_i64': (65536, 64)}
TARGETS = tuple(CASES)[:3]
SCHEMA = {'Struct': [{'names': ['group', 'rows', 'values', 'sum', 'avg'],
    'dtypes': [{'Utf8': True}, {'Primitive': ['u64', False]},
               {'Primitive': ['u64', False]}, {'Primitive': ['f64', True]},
               {'Primitive': ['f64', True]}]}, False]}
TEST = 'local_primitives::prepared_relational::tests::fused_measure_cost_tests::native_fused_measure_cost_screen'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def schedule(mode):
    if mode == 'observe':
        return [(case, role, 0, 0) for case in CASES for role in ('baseline', 'candidate')]
    result = []
    for cohort in (1, 2):
        for case in CASES:
            for sample in (1, 2, 3):
                first = (sample != 2) if cohort == 1 else (sample == 2)
                roles = ('baseline', 'candidate') if first else ('candidate', 'baseline')
                result.extend((case, role, cohort, sample) for role in roles)
    return result


def independent_input(case):
    rows, keys = CASES[case]
    return {'domain': [f'clé-東京-{key}' for key in range(keys)] + [None],
            'codes': [keys if row % 97 == 0 else
                      0 if case == 'dictionary_skew' and row % 10 != 9 else row % keys
                      for row in range(rows)],
            'n': [None if row % 19 == 0 else (row % 1009) - 504 for row in range(rows)],
            'p': [row % (100 if case == 'dictionary_sparse' else 5) for row in range(rows)]}


def oracle(data):
    # Insertion-ordered Python values, independent of native grouping and Rust state.
    groups = {}
    selected = 0
    for code, number, predicate in zip(data['codes'], data['n'], data['p'], strict=True):
        if predicate < 1 or predicate > 3:
            continue
        selected += 1
        group = groups.setdefault(data['domain'][code], [0, 0, 0])
        group[0] += 1
        if number is not None:
            group[1] += 1
            group[2] += number * 3
    result = []
    for key, (rows, count, total) in groups.items():
        assert abs(total) < 2**53 and count < 2**53
        result.append({'group': key, 'rows': rows, 'values': count,
                       'sum': float(total) if count else None,
                       'avg': total / count if count else None})
    return result, selected


def values(record, witness):
    case = record['case']
    data = witness(record['input_witness'])
    assert data == independent_input(case), case
    expected, selected = oracle(data)
    assert record['input_rows'] == CASES[case][0] and record['selected_rows'] == selected
    assert witness(record['schema_witness']) == SCHEMA
    assert record['expected_rows_witness'] == record['actual_rows_witness']
    actual = witness(record['actual_rows_witness'])
    assert actual == expected, case
    raw = witness(record['raw_rows_witness'])
    assert isinstance(raw, str)
    assert [json.loads(line) for line in raw.splitlines()] == expected, (case, 'raw JSON')
    assert isinstance(actual, list)
    for row in actual:
        assert set(row) == {'group', 'rows', 'values', 'sum', 'avg'}
        assert type(row['rows']) is int and type(row['values']) is int
        assert row['sum'] is None or type(row['sum']) is float
        assert row['avg'] is None or type(row['avg']) is float
    for name in ('engine_execution_ns', 'preparation_ns', 'result_serialization_ns'):
        assert type(record[name]) is int and record[name] >= 0
    assert record['engine_execution_ns'] > 0
    assert record['complete_values_match'] is True and record['complete_schema_match'] is True
    assert record['memory_grant_bytes'] == 128 << 20
    assert 0 <= record['peak_reserved_bytes'] <= record['memory_grant_bytes']
    assert record['denied_reservations'] == record['reserved_after_cleanup'] == 0
    assert 'fallback_attempted: false' in record['native_io_certificate']
    assert 'fallback_attempted: true' not in record['native_io_certificate']
    assert 'admitted_max_parallelism: 1' in record['runtime']
    assert 'provider_background_workers: 0' in record['runtime']
    active = record['role'] == 'candidate' and case != 'ineligible_i64'
    if record['role'] == 'candidate':
        for name, value in [('fused_measure_stages', int(active)),
                            ('fused_measure_rows', selected if active else 0)]:
            found = re.findall(r'\b' + name + r'=(\d+)\b', record['native_io_certificate'])
            assert found == [str(value)], (case, name, found)
    delivered = re.findall(r'\bdelivered_scan_rows=(\d+)\b', record['native_io_certificate'])
    batches = re.findall(r'\bnative_batches=(\d+)\b', record['native_io_certificate'])
    assert delivered == [str(selected)] and len(batches) == 1
    assert int(batches[0]) > 0
    if record['observation_enabled']:
        counts = record['observations']
        assert isinstance(counts, dict) and all(type(value) is int and value >= 0 for value in counts.values())
        assert counts['fused_measure_stages'] == int(active)
        assert counts['fused_measure_rows'] == (selected if active else 0)
        assert counts['expression_rows_constructed'] == (0 if active else selected)
        assert counts['aggregate_row_updates'] == selected * 4
        assert counts['variable_domains'] > 0
        encoded = active and case != 'plain_high_cardinality'
        domain_count = int(batches[0]) if encoded else 0
        domain_values = domain_count * (CASES[case][1] + 1)
        if record['role'] == 'candidate':
            assert counts['variable_dictionary_domains'] == domain_count
            assert counts['variable_dictionary_domain_values'] == domain_values
        assert counts['variable_domain_values'] == (domain_values if encoded else selected) + len(expected)
    else:
        assert record['observations'] is None


def score(records):
    results = {}
    passed = True
    for cohort in (1, 2):
        for case in CASES:
            medians = {}
            for role in ('baseline', 'candidate'):
                runs = [records[(case, role, cohort, sample)] for sample in (1, 2, 3)]
                medians[role] = {'engine_ns': statistics.median(row['engine_execution_ns'] for row in runs),
                    'preparation_engine_ns': statistics.median(row['engine_execution_ns'] + row['preparation_ns'] for row in runs)}
            allowance = 50000 if case == 'tiny' else 0
            control = all(medians['candidate'][clock] <= max(medians['baseline'][clock] * 1.05,
                medians['baseline'][clock] + allowance) for clock in ('engine_ns', 'preparation_engine_ns'))
            target = case not in TARGETS or medians['candidate']['engine_ns'] <= medians['baseline']['engine_ns'] * .98
            passed &= control and target
            results[f'{cohort}:{case}'] = {'medians': medians, 'control_passed': control, 'target_passed': target}
    return {'all_timing_gates_passed': passed, 'cells': results}


def main():
    assert len(sys.argv) == 2
    root = Path(sys.argv[1])
    assert root.is_dir() and root.parent == P and not root.is_symlink()
    outcome = json.loads((root / 'outcome.json').read_text())
    protocol = json.loads((root / 'protocol.json').read_text())
    mode = outcome['mode']
    assert mode in ('measure', 'observe')
    assert outcome['complete'] is True
    assert outcome['candidate_revision'] == 3
    assert outcome['protocol'] == protocol['protocol'] == 'native-fused-measure-v2'
    for key in protocol:
        if key not in ('calls', 'complete'):
            assert protocol[key] == outcome[key], key
    assert outcome['driver_sha256'] == digest(P / 'run_fused_measure_r3.py')
    assert outcome['scorer_sha256'] == digest(__file__)
    frozen = outcome['frozen_protocol']
    assert hashlib.sha256(frozen['text'].encode()).hexdigest() == frozen['sha256']
    assert digest(W / frozen['source']) == frozen['sha256']
    original = outcome['original_frozen_protocol']
    assert hashlib.sha256(original['text'].encode()).hexdigest() == original['sha256']
    assert digest(W / original['source']) == original['sha256']
    for field in ('input', 'source'):
        assert outcome[field + '_inventory_before'] == outcome[field + '_inventory_after']
        assert outcome[field + '_unchanged'] is True
    assert outcome['immutable_runtime_files_unchanged'] and outcome['helpers_unchanged']
    assert outcome['helpers'] == outcome['helpers_after']
    assert outcome['immutable_runtime_files_before'] == outcome['immutable_runtime_files_after']
    for path, sha in outcome['helpers'].items(): assert digest(path) == sha
    for path, sha in outcome['immutable_runtime_files_before'].items(): assert digest(P / path) == sha
    for path, identity in outcome['input_inventory_before'].items():
        source = P / 'fused-measure-inputs-r1' / path
        assert digest(source) == identity['sha256'] and source.stat().st_size == identity['bytes']
    assert outcome['storage_within_budget'] is True
    for phase in ('before', 'after'):
        assert sum(outcome['storage_' + phase].values()) <= 100 << 30
    assert outcome['active_packet_limit_bytes'] == 192 << 20
    manifests = outcome['runtime_manifests']
    assert set(manifests) == {'baseline', 'candidate'}
    for role, manifest in manifests.items():
        assert outcome['reconstructed_source_inventory'][role] == manifest['source_inventory']
        assert manifest['features'] == ['release-user-surfaces']
        assert manifest['profile'] == ('release' if mode == 'measure' else 'ci-native')
        assert manifest['harnesses'] == {HARNESS: digest(W / HARNESS)}
        assert digest(manifest['binary']) == manifest['binary_sha256'] == outcome['binary_sha256_after'][role]
        assert digest(manifest['build_receipt']['path']) == manifest['build_receipt']['sha256']
        receipt = json.loads(Path(manifest['build_receipt']['path']).read_text())
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert digest(manifest['source_overlay']['path']) == manifest['source_overlay']['sha256']
        with tarfile.open(manifest['source_overlay']['path'], 'r:gz') as archive:
            members = archive.getmembers()
            assert sorted(item.name for item in members) == sorted(manifest['source_overlay']['members'])
            for item in members:
                assert item.isfile() and '..' not in item.name.split('/') and not item.name.startswith('/')
                identity = hashlib.sha256(archive.extractfile(item).read()).hexdigest()
                assert identity == manifest['source_overlay']['members'][item.name] == manifest['source_inventory'][item.name]
                assert identity == receipt['changed_source_inventory'][item.name]['sha256']
    assert manifests['baseline']['toolchain'] == manifests['candidate']['toolchain']
    assert manifests['baseline']['revision'] == manifests['candidate']['revision']
    assert manifests['candidate']['source_inventory'] == outcome['source_inventory_before']
    for name, sha in outcome['source_inventory_before'].items(): assert digest(W / name) == sha
    planned = schedule(mode)
    assert outcome['schedule'] == [list(row) for row in planned]
    assert len(outcome['calls']) == len(planned)
    names = {'protocol.json', 'outcome.json', 'witnesses'}
    witness_names = set()
    def witness(identity):
        assert isinstance(identity, str) and re.fullmatch('[0-9a-f]{64}', identity)
        name = identity + '.json'
        witness_names.add(name)
        path = root / 'witnesses' / name
        assert digest(path) == identity
        return json.loads(path.read_text())
    records = {}
    fixed_inputs = json.loads((P / 'fused-measure-inputs-r1/manifest.json').read_text())
    for sequence, (call, expected) in enumerate(zip(outcome['calls'], planned, strict=True), 1):
        case, role, cohort, sample = expected
        label = f'{mode}-{case}-{role}-{cohort}-{sample}'
        assert (call['case'], call['role'], call['cohort'], call['sample']) == expected
        assert call['sequence'] == sequence and call['mode'] == mode
        assert call['status'] == 'passed' and call['returncode'] == 0
        assert call['direct_child_reaped'] and call['process_group_drained']
        assert call['timed_out'] is False and call['interrupted_signal'] is None
        assert not call.get('error') and not call.get('cleanup_error')
        assert call['command'] == [manifests[role]['binary'], TEST, '--exact', '--ignored', '--nocapture', '--test-threads=1']
        assert call['timeout_seconds'] == 120 and call['output_limit_bytes'] == 8 << 20
        for file in (label + '.json', label + '.log', 'supervision-' + label + '.json'): names.add(file)
        assert digest(root / (label + '.json')) == call['record_sha256']
        assert digest(root / (label + '.log')) == call['log_sha256']
        assert json.loads((root / ('supervision-' + label + '.json')).read_text()) == call
        record = json.loads((root / (label + '.json')).read_text())
        assert record['protocol'] == 'native-fused-measure-v2'
        assert (record['case'], record['role'], record['cohort'], record['sample']) == expected
        assert record['observation_enabled'] is (mode == 'observe')
        assert record['input_file'] == fixed_inputs[case]
        assert record['input_witness'] == fixed_inputs[case]['input_witness']
        values(record, witness)
        records[expected] = record
    assert set(path.name for path in root.iterdir()) == names
    assert set(path.name for path in (root / 'witnesses').iterdir()) == witness_names
    result = {'protocol': outcome['protocol'], 'mode': mode, 'calls': len(records),
              'complete_values_schemas_resources_and_closure_passed': True}
    if mode == 'measure': result.update(score(records))
    else:
        for case in CASES:
            baseline = records[(case, 'baseline', 0, 0)]['observations']
            candidate = records[(case, 'candidate', 0, 0)]['observations']
            assert candidate['variable_domains'] == baseline['variable_domains']
        result['work_elimination_observations_passed'] = True
    destination = P / f'fused-measure-{mode}-verification-r3.json'
    with destination.open('x') as stream: json.dump(result, stream, indent=2)
    print(json.dumps(result))


if __name__ == '__main__': main()
