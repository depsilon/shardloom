"""Synthetic corruption checks; never starts an engine or native build."""
import copy
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

P = Path(__file__).resolve().parent
path = P / 'verify_fused_measure_r2.py'
spec = importlib.util.spec_from_file_location('fused_verifier', path)
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
checks = []


def record(case='tiny', role='candidate'):
    witnesses = {}
    def add(value):
        identity = hashlib.sha256(json.dumps(value).encode()).hexdigest()
        witnesses[identity] = value
        return identity
    data = v.independent_input(case)
    expected, selected = v.oracle(data)
    active = role == 'candidate' and case != 'ineligible_i64'
    stage, mapped = int(active), selected if active else 0
    return {'case': case, 'role': role, 'input_rows': v.CASES[case][0], 'selected_rows': selected,
        'input_witness': add(data), 'schema_witness': add(v.SCHEMA),
        'actual_rows_witness': add(expected), 'expected_rows_witness': add(expected),
        'raw_rows_witness': add('\n'.join(json.dumps(row) for row in expected)),
        'engine_execution_ns': 1000000, 'preparation_ns': 100000, 'result_serialization_ns': 100,
        'complete_values_match': True, 'complete_schema_match': True,
        'memory_grant_bytes': 128 << 20, 'peak_reserved_bytes': 1024,
        'reserved_after_cleanup': 0, 'denied_reservations': 0,
        'native_io_certificate': f'fallback_attempted: false fused_measure_stages={stage} fused_measure_rows={mapped}',
        'runtime': 'admitted_max_parallelism: 1 provider_background_workers: 0',
        'observation_enabled': True, 'observations': {'fused_measure_stages': stage,
        'fused_measure_rows': mapped, 'expression_rows_constructed': 0 if active else selected,
        'aggregate_row_updates': selected * 4, 'variable_domains': 1, 'variable_domain_values': 8,
        'variable_dictionary_domains': 1, 'variable_dictionary_domain_values': 8}}, witnesses


for case in v.CASES:
    for role in ('baseline', 'candidate'):
        r, w = record(case, role)
        v.values(r, w.__getitem__)
checks.append('all_12_complete_semantic_fixtures_accepted')

def rejects(name, mutate):
    r, w = record()
    w = copy.deepcopy(w)
    mutate(r, w)
    try:
        v.values(r, w.__getitem__)
    except (AssertionError, KeyError, TypeError, ValueError):
        checks.append(name)
    else:
        raise AssertionError('corruption accepted: ' + name)


rejects('input_value_changed', lambda r, w: w[r['input_witness']]['n'].__setitem__(1, 17))
rejects('output_missing_row', lambda r, w: w[r['actual_rows_witness']].pop())
rejects('output_wrong_total', lambda r, w: w[r['actual_rows_witness']][0].__setitem__('sum', 1.0))
rejects('output_wrong_order', lambda r, w: w[r['actual_rows_witness']].reverse())
rejects('raw_output_disagrees', lambda r, w: w.__setitem__(r['raw_rows_witness'], '{}'))
rejects('schema_wrong_nullability', lambda r, w: w[r['schema_witness']]['Struct'][0]['dtypes'][3]['Primitive'].__setitem__(1, False))
rejects('count_boolean_type', lambda r, w: w[r['actual_rows_witness']][0].__setitem__('rows', True))
rejects('clock_boolean_type', lambda r, w: r.__setitem__('engine_execution_ns', True))
rejects('clock_missing', lambda r, w: r.pop('engine_execution_ns'))
rejects('resource_leak', lambda r, w: r.__setitem__('reserved_after_cleanup', 1))
rejects('over_grant', lambda r, w: r.__setitem__('peak_reserved_bytes', (128 << 20) + 1))
rejects('fallback', lambda r, w: r.__setitem__('native_io_certificate', r['native_io_certificate'].replace('false', 'true')))
rejects('extra_workers', lambda r, w: r.__setitem__('runtime', r['runtime'].replace('workers: 0', 'workers: 1')))
rejects('false_activation', lambda r, w: r.__setitem__('native_io_certificate', r['native_io_certificate'].replace('stages=1', 'stages=0')))
rejects('false_mapped_count', lambda r, w: r['observations'].__setitem__('fused_measure_rows', 0))
rejects('intermediate_still_built', lambda r, w: r['observations'].__setitem__('expression_rows_constructed', 1))
rejects('aggregate_updates_skipped', lambda r, w: r['observations'].__setitem__('aggregate_row_updates', 0))

records = {}
for case, role, cohort, sample in v.schedule('measure'):
    records[(case, role, cohort, sample)] = {'engine_execution_ns': 970000 if role == 'candidate' else 1000000,
                                          'preparation_ns': 100000}
assert v.score(records)['all_timing_gates_passed']
checks.append('frozen_target_and_control_pass')
bad = copy.deepcopy(records)
for sample in (1, 2, 3): bad[('dictionary_sparse', 'candidate', 2, sample)]['engine_execution_ns'] = 990000
assert not v.score(bad)['all_timing_gates_passed']
checks.append('target_failure_in_second_cohort_not_hidden')
bad = copy.deepcopy(records)
for sample in (1, 2, 3): bad[('ineligible_i64', 'candidate', 1, sample)]['preparation_ns'] = 300000
assert not v.score(bad)['all_timing_gates_passed']
checks.append('first_execution_regression_rejected')
bad = copy.deepcopy(records)
for sample in (1, 2, 3):
    bad[('tiny', 'baseline', 1, sample)] = {'engine_execution_ns': 5000, 'preparation_ns': 1000}
    bad[('tiny', 'candidate', 1, sample)] = {'engine_execution_ns': 40000, 'preparation_ns': 1000}
assert v.score(bad)['all_timing_gates_passed']
checks.append('tiny_absolute_allowance_applied_only_as_frozen')
receipt = {'status': 'passed', 'engine_executions': 0, 'checks': checks,
    'verifier_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
    'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
receipt_name = sys.argv[1] if len(sys.argv) == 2 else 'fused-measure-verifier-validation-r4.json'
assert Path(receipt_name).name == receipt_name and receipt_name.endswith('.json')
with (P / receipt_name).open('x') as stream:
    json.dump(receipt, stream, indent=2)
print(json.dumps({'status': 'passed', 'checks': len(checks), 'engine_executions': 0}))

