use vortex::{
    VortexSessionDefault as _,
    array::{ArrayRef, VortexSessionExecute as _, arrays::{Dict, VarBinViewArray}},
    expr::{and, get_item, gt_eq, lit, lt_eq, root},
    file::OpenOptionsSessionExt as _,
    io::{runtime::{BlockingRuntime as _, current::CurrentThreadRuntime}, session::RuntimeSessionExt as _},
    session::VortexSession,
};

fn tree(label: &str, array: &ArrayRef) {
    println!("{label}: rows={} root={} tree={:?}", array.len(), array.encoding_id(),
        array.depth_first_traversal().map(|a| a.encoding_id().to_string()).collect::<Vec<_>>());
}

fn main() {
    let path = std::env::args().nth(1).unwrap();
    let runtime = CurrentThreadRuntime::new();
    let session = VortexSession::default().with_handle(runtime.handle());
    let file = runtime.block_on(session.open_options().open_path(path)).unwrap();
    let filter = and(gt_eq(get_item("p", root()), lit(1_i64)),
        lt_eq(get_item("p", root()), lit(3_i64)))
        .bind(file.dtype()).unwrap().optimize_recursive().unwrap();
    let scan = file.scan().unwrap().with_ordered(true).with_concurrency(1)
        .with_natural_splits([0, file.row_count()].into()).with_filter(filter)
        .prepare().unwrap();
    let mut tasks = scan.execute(Some(0..2048)).unwrap();
    assert_eq!(tasks.len(), 1);
    let array = runtime.block_on(tasks.pop().unwrap()).unwrap().unwrap();
    tree("filtered_scan", &array);
    let selected = array.slice(0..array.len()).unwrap();
    let field = selected.clone().apply_bound(&get_item("g", root()).bind(selected.dtype()).unwrap()).unwrap();
    tree("selected_group", &field);
    let mut execution = session.create_execution_ctx();
    let resolved = field.clone().execute_until::<Dict>(&mut execution).unwrap();
    tree("resolved_group", &resolved);
    assert!(field.as_opt::<Dict>().is_none());
    assert!(resolved.as_opt::<Dict>().is_some());
    assert_eq!(resolved.dtype(), field.dtype());
    assert_eq!(resolved.len(), field.len());
    let before = field.execute::<VarBinViewArray>(&mut execution).unwrap();
    let after = resolved.execute::<VarBinViewArray>(&mut execution).unwrap();
    assert_eq!(before.len(), after.len());
    println!("lazy_dictionary_resolution_proved=true rows={}", before.len());
}
