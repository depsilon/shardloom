"""Run the frozen fused-measure comparison or debug-observation schedule."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import posixpath
import shutil
import subprocess
import sys
import tarfile

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
P = Path('/Users/dylan/LocalData/shardloom/workflow-work-elimination-20261025')
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
INPUTS = P / 'fused-measure-inputs-r1'
CASES = (
    'dictionary_dense', 'dictionary_skew', 'dictionary_sparse',
    'plain_high_cardinality', 'tiny', 'ineligible_i64',
)
CASE_SHAPES = {
    'dictionary_dense': (262144, 64),
    'dictionary_skew': (262144, 64),
    'dictionary_sparse': (262144, 64),
    'plain_high_cardinality': (65536, 8192),
    'tiny': (17, 7),
    'ineligible_i64': (65536, 64),
}
HARNESS = 'shardloom-vortex/src/local_primitive_relational_fused_measure_cost_tests.rs'
TEST_FILTER = 'local_primitives::prepared_relational::tests::fused_measure_cost_tests::native_fused_measure_cost_screen'
PROTOCOL = W / 'docs/architecture/native-fused-measure-encoding-correction-2026-10-25.md'
ORIGINAL_PROTOCOL = W / 'docs/architecture/native-fused-measure-work-elimination-2026-10-25.md'
SCORER = P / 'verify_fused_measure_r3.py'
SUPERVISOR_PATH = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
GUARD_PATH = Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py')
GIB = 1 << 30
MIB = 1 << 20
MAX_WORKSPACE = 100 * GIB
MIN_FREE = 12 * GIB
ACTIVE_PACKET = 192 * MIB
CALL_TIMEOUT_SECONDS = 120
CALL_OUTPUT_LIMIT = 8 * MIB


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def runtime_folder(role):
    assert role in ('baseline', 'candidate')
    revision = 2 if role == 'baseline' else 3
    return P / f'fused-measure-{role}-runtime-r{revision}'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def tree_bytes(path):
    return sum(item.stat().st_size for item in path.rglob('*')
               if item.is_file() and not item.is_symlink()) if path.exists() else 0


def source_inventory():
    names = subprocess.check_output(
        ['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=W
    ).decode().split('\0')
    sources = sorted({name for name in names if name and
                      (name.endswith('.rs') or Path(name).name in ('Cargo.toml', 'Cargo.lock'))})
    result = {}
    for name in sources:
        path = W / name
        assert path.is_file() and not path.is_symlink(), name
        result[name] = digest(path)
    return result


def committed_source_inventory(revision, names):
    # A baseline file can be unchanged in Git but changed by the candidate.
    # Reconstruct it from the pinned commit, never from the current checkout.
    names = sorted(names)
    assert all('\n' not in name and ':' not in name for name in names)
    query = ''.join(f'{revision}:{name}\n' for name in names).encode()
    payload = subprocess.run(['git', 'cat-file', '--batch'], cwd=W, input=query,
                             stdout=subprocess.PIPE, check=True).stdout
    cursor, result = 0, {}
    for name in names:
        end = payload.index(b'\n', cursor)
        header = payload[cursor:end].split()
        assert len(header) == 3 and header[1] == b'blob'
        size = int(header[2])
        cursor = end + 1
        value = payload[cursor:cursor + size]
        assert len(value) == size and payload[cursor + size:cursor + size + 1] == b'\n'
        result[name] = hashlib.sha256(value).hexdigest()
        cursor += size + 1
    assert cursor == len(payload)
    return result


def input_inventory():
    assert INPUTS.is_dir() and not INPUTS.is_symlink(), f'fixed fixtures absent: {INPUTS}'
    result = {}
    for path in sorted(INPUTS.rglob('*')):
        assert not path.is_symlink(), f'fixture symlink rejected: {path}'
        if path.is_dir():
            continue
        assert path.is_file(), f'fixture is not regular: {path}'
        relative = path.relative_to(INPUTS).as_posix()
        result[relative] = {'sha256': digest(path), 'bytes': path.stat().st_size}
    assert result, 'fixed fixture directory must contain immutable files'
    return result


def verify_fixed_inputs():
    inventory = input_inventory()
    directories = {path.relative_to(INPUTS).as_posix() for path in INPUTS.rglob('*')
                   if path.is_dir()}
    assert directories == {'witnesses'}
    fixture_manifest = json.loads((INPUTS / 'manifest.json').read_text())
    assert set(fixture_manifest) == set(CASES)
    expected_paths = {'manifest.json'}
    for case in CASES:
        rows, keys = CASE_SHAPES[case]
        item = fixture_manifest[case]
        assert item['rows'] == rows and item['keys'] == keys
        assert item['writer'] == 'sequential_native_flat'
        assert item['chunk_rows'] == 65_536 and item['file_statistics'] is False
        fixture_path = INPUTS / f'{case}.vortex'
        fixture = fixture_path.read_bytes()
        assert item['sha256'] == hashlib.sha256(fixture).hexdigest()
        assert item['bytes'] == len(fixture)
        expected_paths.add(f'{case}.vortex')
        witness_id = item['input_witness']
        assert isinstance(witness_id, str) and len(witness_id) == 64
        witness_path = INPUTS / 'witnesses' / f'{witness_id}.json'
        assert witness_path.is_file() and not witness_path.is_symlink()
        assert digest(witness_path) == witness_id
        json.loads(witness_path.read_text())
        expected_paths.add(f'witnesses/{witness_id}.json')
    assert set(inventory) == expected_paths
    return inventory


def verify_overlay(manifest):
    overlay = manifest['source_overlay']
    path = Path(overlay['path'])
    assert path.is_file() and not path.is_symlink()
    assert digest(path) == overlay['sha256']
    members = overlay['members']
    assert isinstance(members, dict)
    for name, identity in members.items():
        assert not name.startswith('/') and '..' not in name.split('/')
        assert posixpath.normpath(name) == name
        assert name in manifest['source_inventory']
        assert manifest['source_inventory'][name] == identity
        assert name.endswith('.rs') or Path(name).name in ('Cargo.toml', 'Cargo.lock')
    with tarfile.open(path, 'r:gz') as archive:
        entries = archive.getmembers()
        assert sorted(entry.name for entry in entries) == sorted(members)
        for entry in entries:
            assert entry.isfile()
            stream = archive.extractfile(entry)
            assert stream is not None
            assert hashlib.sha256(stream.read()).hexdigest() == members[entry.name]
    return members


def load_runtime_manifests(mode):
    profile = 'release' if mode == 'measure' else 'ci-native'
    label = 'release' if mode == 'measure' else 'observe'
    manifests = {}
    for role in ('baseline', 'candidate'):
        folder = runtime_folder(role)
        manifest_path = folder / f'{label}-manifest.json'
        manifest = json.loads(manifest_path.read_text())
        binary = Path(manifest['binary'])
        expected_binary = folder / f'shardloom-fused-measure-{label}'
        assert binary == expected_binary and binary.is_file() and not binary.is_symlink()
        assert os.access(binary, os.X_OK)
        assert digest(binary) == manifest['binary_sha256']
        assert manifest['profile'] == profile
        assert manifest['features'] == ['release-user-surfaces']
        assert manifest['harnesses'] == {HARNESS: digest(W / HARNESS)}
        assert manifest['source_inventory'][HARNESS] == manifest['harnesses'][HARNESS]
        assert isinstance(manifest['source_inventory'], dict) and manifest['source_inventory']
        assert manifest['revision']
        for name, identity in manifest['source_inventory'].items():
            assert isinstance(name, str) and name
            assert isinstance(identity, str) and len(identity) == 64
        expected_overlay = folder / f'{label}-source-overlay.tar.gz'
        assert Path(manifest['source_overlay']['path']) == expected_overlay
        verify_overlay(manifest)
        reconstructed_receipt = manifest['build_receipt']
        receipt_path = Path(reconstructed_receipt['path'])
        assert receipt_path.parent == P and receipt_path.is_file() and not receipt_path.is_symlink()
        assert digest(receipt_path) == reconstructed_receipt['sha256']
        receipt = json.loads(receipt_path.read_text())
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert not receipt['timed_out'] and receipt['interrupted_signal'] is None
        assert digest(receipt_path.with_suffix('.log')) == receipt['log_sha256']
        manifests[role] = manifest

    baseline = manifests['baseline']
    candidate = manifests['candidate']
    assert baseline['revision'] == candidate['revision']
    assert baseline['toolchain'] == candidate['toolchain']
    assert baseline['features'] == candidate['features']
    assert baseline['harnesses'] == candidate['harnesses']
    assert set(baseline['source_inventory']) <= set(candidate['source_inventory'])
    return manifests


def immutable_runtime_files(manifests, mode):
    label = 'release' if mode == 'measure' else 'observe'
    result = {}
    for role, manifest in manifests.items():
        folder = runtime_folder(role)
        paths = (
            folder / f'{label}-manifest.json',
            Path(manifest['binary']),
            Path(manifest['source_overlay']['path']),
            Path(manifest['build_receipt']['path']),
            Path(manifest['build_receipt']['path']).with_suffix('.log'),
        )
        for path in paths:
            assert path.is_file() and not path.is_symlink()
            result[path.relative_to(P).as_posix()] = digest(path)
    return result


def schedule(mode):
    if mode == 'observe':
        return [(case, role, 0, 0) for case in CASES
                for role in ('baseline', 'candidate')]
    result = []
    for cohort in (1, 2):
        for case in CASES:
            for sample in (1, 2, 3):
                baseline_first = (sample != 2) if cohort == 1 else (sample == 2)
                roles = ('baseline', 'candidate') if baseline_first else ('candidate', 'baseline')
                result.extend((case, role, cohort, sample) for role in roles)
    return result


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ('measure', 'observe'):
        raise SystemExit('usage: run_fused_measure_r3.py measure|observe')
    mode = sys.argv[1]
    profile = 'release' if mode == 'measure' else 'ci-native'
    result_root = P / ('fused-measure-comparison-r3' if mode == 'measure'
                       else 'fused-measure-observations-r3')
    assert not result_root.exists(), f'new result directory required: {result_root}'
    assert INPUTS.is_dir() and not INPUTS.is_symlink()
    lock_path = P / '.fused-measure-comparison.lock'
    lock_fd = os.open(lock_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    lock_stat = os.fstat(lock_fd)
    os.write(lock_fd, str(os.getpid()).encode())
    os.close(lock_fd)
    lock_identity = (lock_stat.st_dev, lock_stat.st_ino)
    result_created = False
    packet = {
        'protocol': 'native-fused-measure-v2',
        'mode': mode,
        'candidate_revision': 3,
        'profile': profile,
        'driver_sha256': digest(__file__),
        'scorer_sha256': digest(SCORER),
        'frozen_protocol': {'source': str(PROTOCOL.relative_to(W)),
                            'sha256': digest(PROTOCOL), 'text': PROTOCOL.read_text()},
        'original_frozen_protocol': {'source': str(ORIGINAL_PROTOCOL.relative_to(W)),
                                     'sha256': digest(ORIGINAL_PROTOCOL),
                                     'text': ORIGINAL_PROTOCOL.read_text()},
        'inputs_directory': str(INPUTS),
        'complete': False,
        'calls': [],
    }
    try:
        result_root.mkdir()
        result_created = True
        (result_root / 'witnesses').mkdir()
        supervisor = module('bounded_fused_measure', SUPERVISOR_PATH)
        guard_module = module('fused_measure_workload_guard', GUARD_PATH)
        manifests = load_runtime_manifests(mode)
        immutable_before = immutable_runtime_files(manifests, mode)
        input_before = verify_fixed_inputs()
        source_before = source_inventory()
        assert source_before == manifests['candidate']['source_inventory']
        reconstructed_sources = {}
        for role, manifest in manifests.items():
            unchanged = set(manifest['source_inventory']) - set(manifest['source_overlay']['members'])
            reconstructed = committed_source_inventory(manifest['revision'], unchanged)
            reconstructed.update(manifest['source_overlay']['members'])
            assert reconstructed == manifest['source_inventory'], role
            reconstructed_sources[role] = reconstructed
        assert sum((tree_bytes(CACHE), tree_bytes(P))) <= MAX_WORKSPACE
        assert shutil.disk_usage(P).free >= MIN_FREE
        planned = schedule(mode)
        expected_count = 72 if mode == 'measure' else 12
        assert len(planned) == expected_count
        packet.update(
            reconstructed_source_inventory=reconstructed_sources,
            storage_before={'cache_bytes': tree_bytes(CACHE), 'task_bytes': tree_bytes(P)},
            runtime_manifests=manifests,
            immutable_runtime_files_before=immutable_before,
            manifest_sha256={role: digest(
                runtime_folder(role) /
                ('release-manifest.json' if mode == 'measure' else 'observe-manifest.json'))
                for role in ('baseline', 'candidate')},
            input_inventory_before=input_before,
            source_inventory_before=source_before,
            helpers={str(path): digest(path) for path in (SUPERVISOR_PATH, GUARD_PATH)},
            schedule=[list(row) for row in planned],
            call_timeout_seconds=CALL_TIMEOUT_SECONDS,
            call_output_limit_bytes=CALL_OUTPUT_LIMIT,
            active_packet_limit_bytes=ACTIVE_PACKET,
        )
        write_new(result_root / 'protocol.json', packet)

        for index, (case, role, cohort, sample) in enumerate(planned):
            label = f'{mode}-{case}-{role}-{cohort}-{sample}'
            record_path = result_root / f'{label}.json'
            log_path = result_root / f'{label}.log'
            assert not record_path.exists() and not log_path.exists()
            evidence = {
                'mode': mode, 'profile': profile, 'case': case, 'role': role,
                'cohort': cohort, 'sample': sample, 'sequence': index + 1,
                'status': 'running',
            }
            packet['calls'].append(evidence)
            work = guard_module.WorkloadGuard()
            env = dict(os.environ,
                SHARDLOOM_FUSED_MEASURE_ROOT=str(result_root),
                SHARDLOOM_FUSED_MEASURE_INPUTS=str(INPUTS),
                SHARDLOOM_FUSED_MEASURE_CASE=case,
                SHARDLOOM_FUSED_MEASURE_ROLE=role,
                SHARDLOOM_FUSED_MEASURE_COHORT=str(cohort),
                SHARDLOOM_FUSED_MEASURE_SAMPLE=str(sample),
            )
            command = [manifests[role]['binary'], TEST_FILTER,
                       '--exact', '--ignored', '--nocapture', '--test-threads=1']
            evidence['command'] = command
            fixed_bytes = sum(path.stat().st_size for path in result_root.iterdir()
                              if path.is_file() and not path.is_symlink())

            def guard():
                work.check(evidence.get('pid'))
                assert shutil.disk_usage(P).free >= MIN_FREE
                active_bytes = sum(path.stat().st_size for path in
                                   (log_path, record_path) if path.exists())
                witness_bytes = sum(path.stat().st_size for path in
                                    (result_root / 'witnesses').iterdir()
                                    if path.is_file() and not path.is_symlink())
                assert fixed_bytes + active_bytes + witness_bytes <= ACTIVE_PACKET

            try:
                with log_path.open('xb') as output:
                    status = supervisor.run(
                        command, cwd=W, env=env, output=output,
                        timeout=CALL_TIMEOUT_SECONDS, evidence=evidence,
                        guard=guard, max_output_bytes=CALL_OUTPUT_LIMIT,
                    )
                assert status == 0, label
                assert evidence.get('direct_child_reaped')
                assert evidence.get('process_group_drained')
                assert record_path.is_file() and not record_path.is_symlink(), label
                record = json.loads(record_path.read_text())
                assert record['protocol'] == 'native-fused-measure-v2'
                assert (record['case'], record['role'], record['cohort'], record['sample']) == (
                    case, role, cohort, sample)
                assert record['observation_enabled'] is (mode == 'observe')
                if mode == 'observe':
                    assert isinstance(record['observations'], dict)
                else:
                    assert record['observations'] is None
                assert not evidence.get('timed_out')
                assert evidence.get('interrupted_signal') is None
                assert not evidence.get('error') and not evidence.get('cleanup_error')
                evidence['record_sha256'] = digest(record_path)
                evidence['returncode'] = status
                evidence['status'] = 'passed'
            except BaseException as error:
                evidence['status'] = 'failed'
                evidence['failure'] = type(error).__name__ + ': ' + str(error)
                raise
            finally:
                evidence['log_sha256'] = digest(log_path) if log_path.exists() else None
                receipt_path = result_root / f'supervision-{label}.json'
                write_new(receipt_path, evidence)
                print(json.dumps({'case': case, 'role': role,
                                  'status': evidence['status']}), flush=True)

        input_after = input_inventory()
        source_after = source_inventory()
        assert input_before == input_after, 'fixed fixture inputs changed during execution'
        assert source_before == source_after, 'Rust/Cargo source closure changed during execution'
        binary_after = {}
        for role, manifest in manifests.items():
            binary = Path(manifest['binary'])
            assert digest(binary) == manifest['binary_sha256'], role
            binary_after[role] = digest(binary)
        assert sum((tree_bytes(CACHE), tree_bytes(P))) <= MAX_WORKSPACE
        immutable_after = immutable_runtime_files(manifests, mode)
        assert immutable_before == immutable_after
        packet.update(input_inventory_after=input_after,
                      source_inventory_after=source_after,
                      immutable_runtime_files_after=immutable_after,
                      binary_sha256_after=binary_after,
                      complete=True)
    finally:
        if result_created:
            if 'input_inventory_before' in packet:
                try:
                    input_after = verify_fixed_inputs()
                    source_after = source_inventory()
                    packet.setdefault('input_inventory_after', input_after)
                    packet.setdefault('source_inventory_after', source_after)
                    packet['input_unchanged'] = (
                        input_after == packet['input_inventory_before'])
                    packet['source_unchanged'] = (
                        source_after == packet['source_inventory_before'])
                    if not packet['input_unchanged'] or not packet['source_unchanged']:
                        packet['complete'] = False
                    packet.setdefault('binary_sha256_after', {
                        role: digest(manifest['binary'])
                        for role, manifest in packet['runtime_manifests'].items()
                    })
                    packet.setdefault('storage_after', {
                        'cache_bytes': tree_bytes(CACHE),
                        'task_bytes': tree_bytes(P),
                    })
                    packet['storage_within_budget'] = (
                        packet['storage_after']['cache_bytes'] +
                        packet['storage_after']['task_bytes'] <= MAX_WORKSPACE)
                    if not packet['storage_within_budget']:
                        packet['complete'] = False
                    if 'runtime_manifests' in packet:
                        immutable_after = immutable_runtime_files(
                            packet['runtime_manifests'], mode)
                        packet.setdefault('immutable_runtime_files_after', immutable_after)
                        packet['immutable_runtime_files_unchanged'] = (
                            immutable_after == packet['immutable_runtime_files_before'])
                        if not packet['immutable_runtime_files_unchanged']:
                            packet['complete'] = False
                    if 'helpers' in packet:
                        helper_after = {str(path): digest(path)
                                        for path in (SUPERVISOR_PATH, GUARD_PATH)}
                        packet['helpers_after'] = helper_after
                        packet['helpers_unchanged'] = helper_after == packet['helpers']
                        if not packet['helpers_unchanged']:
                            packet['complete'] = False
                    assert digest(__file__) == packet['driver_sha256']
                    assert digest(SCORER) == packet['scorer_sha256']
                    assert digest(PROTOCOL) == packet['frozen_protocol']['sha256']
                    assert digest(ORIGINAL_PROTOCOL) == packet['original_frozen_protocol']['sha256']
                except BaseException as error:
                    packet['post_snapshot_error'] = type(error).__name__ + ': ' + str(error)
                    packet['complete'] = False
            outcome_path = result_root / 'outcome.json'
            if not outcome_path.exists():
                packet['complete'] = bool(packet.get('complete'))
                write_new(outcome_path, packet)
        current_lock = lock_path.stat()
        assert (current_lock.st_dev, current_lock.st_ino) == lock_identity
        lock_path.unlink()


if __name__ == '__main__':
    main()
