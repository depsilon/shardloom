"""Switch only frozen task-owned Rust sources for identical-harness rebuilds."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

P = Path(__file__).resolve().parent
W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
HARNESS = 'shardloom-vortex/src/local_primitive_relational_fused_measure_cost_tests.rs'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def inventory():
    names = subprocess.check_output(
        ['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=W
    ).decode().split('\0')
    result = {}
    for name in names:
        if name and (name.endswith('.rs') or Path(name).name in ('Cargo.toml', 'Cargo.lock')):
            path = W / name
            assert path.is_file() and not path.is_symlink(), name
            result[name] = digest(path.read_bytes())
    return result


def main():
    assert len(sys.argv) == 2 and sys.argv[1] in ('baseline', 'candidate')
    role = sys.argv[1]
    receipt = P / f'fused-measure-source-{role}-r2.json'
    assert not receipt.exists()
    corrected = (P / 'fused_measure_harness_r2.rs').read_bytes()
    frozen, expected = {}, {}
    for item in ('baseline', 'candidate'):
        frozen[item] = json.loads((P / f'fused-measure-{item}-runtime-r1/observe-manifest.json').read_text())
        expected[item] = dict(frozen[item]['source_inventory'])
        expected[item][HARNESS] = digest(corrected)
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
    assert head == frozen['baseline']['revision'] == frozen['candidate']['revision']
    current = inventory()
    prior = 'candidate' if role == 'baseline' else 'baseline'
    assert current == expected[prior], 'unexpected source change; no files touched'
    target = expected[role]
    differences = {name for name in set(current) | set(target) if current.get(name) != target.get(name)}
    overlay = frozen[role]['source_overlay']
    raw_overlay = Path(overlay['path']).read_bytes()
    assert digest(raw_overlay) == overlay['sha256']
    bodies = {}
    with tarfile.open(fileobj=io.BytesIO(raw_overlay), mode='r:gz') as stream:
        for entry in stream:
            assert entry.isfile() and entry.name in overlay['members']
            raw = stream.extractfile(entry).read()
            assert digest(raw) == overlay['members'][entry.name]
            if entry.name in differences:
                bodies[entry.name] = raw
    for name in differences:
        if name not in target:
            continue
        if name == HARNESS:
            bodies[name] = corrected
        elif name not in bodies:
            bodies[name] = subprocess.check_output(['git', 'show', f'{head}:{name}'], cwd=W)
        assert digest(bodies[name]) == target[name], name
    assert inventory() == current, 'source changed while preparing replacement'
    for name in sorted(differences):
        path = W / name
        if name not in target:
            # Only four known task-owned additions are absent from baseline.
            assert name in frozen['candidate']['source_overlay']['members']
            assert name not in frozen['baseline']['source_inventory']
            assert digest(path.read_bytes()) == current[name]
            path.unlink()
        else:
            assert path.parent.is_dir()
            path.write_bytes(bodies[name])
    after = inventory()
    assert after == target
    result = {'status': 'passed', 'revision': head, 'from_role': prior, 'to_role': role,
              'harness_sha256': digest(corrected), 'harness_only_change_to_frozen_role': True,
              'changed_paths': sorted(differences), 'before_source_inventory': current,
              'after_source_inventory': after,
              'original_manifest': f'fused-measure-{role}-runtime-r1/observe-manifest.json',
              'driver_sha256': digest(Path(__file__).read_bytes())}
    with receipt.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': 'passed', 'role': role, 'changed_files': len(differences),
                      'source_files': len(after), 'receipt': str(receipt)}))


if __name__ == '__main__':
    main()
