fn main() {
    for (sum, count) in [(-219.0_f64, 2306.0_f64), (-5211.0, 2305.0), (1011.0, 2303.0)] {
        let expected = sum / count;
        let text = serde_json::to_string(&expected).unwrap();
        let parsed: serde_json::Value = serde_json::from_str(&text).unwrap();
        let json_value = parsed.as_f64().unwrap();
        let rust_value = text.parse::<f64>().unwrap();
        assert_eq!(expected.to_bits(), rust_value.to_bits());
        assert_ne!(expected.to_bits(), json_value.to_bits());
        println!("{text}: expected_bits={}, serde_bits={}, std_bits={}",
            expected.to_bits(), json_value.to_bits(), rust_value.to_bits());
    }
}
