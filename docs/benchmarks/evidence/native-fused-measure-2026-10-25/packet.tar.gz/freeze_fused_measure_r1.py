"""Freeze one fused-measure test binary and its exact Rust/Cargo source overlay."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tarfile

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
P = Path(__file__).resolve().parent
CACHE = Path('/Users/dylan/.cache/shardloom/cargo-target')
HARNESS = 'shardloom-vortex/src/local_primitive_relational_fused_measure_cost_tests.rs'
ANCHOR = P / 'baseline-runtime/release-manifest.json'
RUSTC = Path('/Users/dylan/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin/rustc')
SOURCE_BUILD_NAMES = {
    'release': 'shardloom_vortex-9fdcfb051cec6fea',
    'ci-native': 'shardloom_vortex-03f2a038481284e4',
}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def inventory_sources():
    names = subprocess.check_output(
        ['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=W
    ).decode().split('\0')
    sources = sorted({name for name in names if name and
                      (name.endswith('.rs') or Path(name).name in ('Cargo.toml', 'Cargo.lock'))})
    inventory = {}
    for name in sources:
        path = W / name
        assert path.is_file() and not path.is_symlink(), name
        inventory[name] = digest(path)
    return inventory


def is_source_name(name):
    return name.endswith('.rs') or Path(name).name in ('Cargo.toml', 'Cargo.lock')


def changed_names():
    names = set()
    for argv in (['git', 'diff', '--name-only', '-z', 'HEAD'],
                 ['git', 'ls-files', '--others', '--exclude-standard', '-z']):
        names.update(name for name in subprocess.check_output(argv, cwd=W).decode().split('\0')
                     if name)
    return names


def receipt_inventory(names):
    result = {}
    for name in sorted(names):
        path = W / name
        if path.is_symlink():
            result[name] = {'symlink': os.readlink(path)}
        elif path.is_file():
            result[name] = {'sha256': digest(path), 'bytes': path.stat().st_size}
        else:
            result[name] = {'absent': True}
    return result


def verify_receipt(receipt, receipt_path, profile, revision, expected_changed_source):
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert not receipt['timed_out'] and receipt['interrupted_signal'] is None
    log_path = receipt_path.with_suffix('.log')
    assert log_path.is_file() and digest(log_path) == receipt['log_sha256']
    assert receipt['head'] == revision
    receipt_source = {name: identity for name, identity in
                      receipt['changed_source_inventory'].items() if is_source_name(name)}
    assert receipt_source == expected_changed_source
    command = receipt['command']
    assert command[:4] == ['cargo', 'test', '--offline', '--locked']
    assert command[command.index('--features') + 1] == 'release-user-surfaces'
    assert command[command.index('-p') + 1] == 'shardloom-vortex'
    assert '--lib' in command and '--no-run' in command
    if profile == 'release':
        assert '--release' in command
    else:
        assert command[command.index('--profile') + 1] == 'ci-native'


def write_overlay(path, changed_source):
    assert not path.exists()
    with tarfile.open(path, 'x:gz', format=tarfile.PAX_FORMAT) as archive:
        for name in sorted(changed_source):
            source = W / name
            assert source.is_file() and not source.is_symlink(), name
            archive.add(source, arcname=name, recursive=False)
    with tarfile.open(path, 'r:gz') as archive:
        assert sorted(archive.getnames()) == sorted(changed_source)
        for member in archive.getmembers():
            assert member.isfile()
            extracted = archive.extractfile(member)
            assert extracted is not None
            assert hashlib.sha256(extracted.read()).hexdigest() == changed_source[member.name]


def main():
    assert len(sys.argv) == 4
    role, profile, receipt_name = sys.argv[1:]
    assert role in ('baseline', 'candidate')
    assert profile in ('release', 'ci-native')
    receipt_path = P / receipt_name
    assert receipt_path.parent == P and receipt_path.is_file() and not receipt_path.is_symlink()
    receipt = json.loads(receipt_path.read_text())

    anchor = json.loads(ANCHOR.read_text())
    revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
    assert revision == anchor['revision']
    names = changed_names()
    changed_source_names = {name for name in names if is_source_name(name)}
    expected_changed_source = receipt_inventory(changed_source_names)
    verify_receipt(receipt, receipt_path, profile, revision, expected_changed_source)

    current_inventory = inventory_sources()
    assert set(anchor['source_inventory']) <= set(current_inventory)
    assert HARNESS in current_inventory
    harness_hash = digest(W / HARNESS)
    assert current_inventory[HARNESS] == harness_hash
    for name in names:
        if name in current_inventory:
            assert receipt['changed_source_inventory'][name] == {
                'sha256': current_inventory[name],
                'bytes': (W / name).stat().st_size,
            }, name
    toolchain = subprocess.check_output([str(RUSTC), '-Vv'], text=True)
    assert toolchain == anchor['toolchain']

    executable_name = SOURCE_BUILD_NAMES[profile]
    source_binary = CACHE / profile / 'deps' / executable_name
    assert source_binary.is_file() and not source_binary.is_symlink()
    assert os.access(source_binary, os.X_OK)
    assert shutil.disk_usage(P).free >= 12 * (1 << 30)

    label = 'release' if profile == 'release' else 'observe'
    output = P / f'fused-measure-{role}-runtime-r1'
    assert not output.exists() or (output.is_dir() and not output.is_symlink())
    destination = output / f'shardloom-fused-measure-{label}'
    overlay = output / f'{label}-source-overlay.tar.gz'
    manifest_path = output / f'{label}-manifest.json'
    assert not destination.exists() and not overlay.exists() and not manifest_path.exists()

    changed_source = {name: current_inventory[name] for name in sorted(changed_source_names)
                      if name in current_inventory}
    features = ['release-user-surfaces']
    harnesses = {HARNESS: harness_hash}

    other_profile = 'ci-native' if profile == 'release' else 'release'
    other_label = 'observe' if profile == 'release' else 'release'
    other_manifest_path = output / f'{other_label}-manifest.json'
    if other_manifest_path.is_file():
        other = json.loads(other_manifest_path.read_text())
        assert other['revision'] == revision
        assert other['toolchain'] == toolchain
        assert other['features'] == features
        assert other['harnesses'] == harnesses
        assert other['source_inventory'] == current_inventory
        assert other['profile'] == other_profile
    other_role = 'candidate' if role == 'baseline' else 'baseline'
    other_role_path = P / f'fused-measure-{other_role}-runtime-r1' / f'{label}-manifest.json'
    if other_role_path.is_file():
        other_role_manifest = json.loads(other_role_path.read_text())
        assert other_role_manifest['toolchain'] == toolchain
        assert other_role_manifest['revision'] == revision
        assert other_role_manifest['features'] == features
        assert other_role_manifest['harnesses'] == harnesses
        assert other_role_manifest['profile'] == profile
        if role == 'candidate':
            assert set(other_role_manifest['source_inventory']) <= set(current_inventory)
        else:
            assert set(current_inventory) <= set(other_role_manifest['source_inventory'])

    # Do every contract check before making any runtime output. A failed
    # validation must not leave a copied executable or partial overlay behind.
    output.mkdir(exist_ok=True)
    assert output.is_dir() and not output.is_symlink()
    with source_binary.open('rb') as source, destination.open('xb') as target:
        shutil.copyfileobj(source, target)
        target.flush()
        os.fsync(target.fileno())
    os.chmod(destination, stat.S_IMODE(source_binary.stat().st_mode))
    assert digest(destination) == digest(source_binary)
    write_overlay(overlay, changed_source)

    manifest = {
        'binary': str(destination),
        'binary_sha256': digest(destination),
        'profile': profile,
        'features': features,
        'toolchain': toolchain,
        'revision': revision,
        'harnesses': harnesses,
        'source_inventory': current_inventory,
        'build_receipt': {'path': str(receipt_path), 'sha256': digest(receipt_path)},
        'source_overlay': {
            'path': str(overlay),
            'sha256': digest(overlay),
            'members': changed_source,
        },
    }

    with manifest_path.open('x') as stream:
        json.dump(manifest, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    print(json.dumps({
        'role': role,
        'profile': profile,
        'manifest': str(manifest_path),
        'binary_sha256': manifest['binary_sha256'],
        'source_files': len(current_inventory),
        'overlay_files': len(changed_source),
    }))


if __name__ == '__main__':
    main()
