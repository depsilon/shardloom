# SPDX-License-Identifier: Apache-2.0
"""Small real-filesystem and process tests; no datasets or engine builds."""

import argparse
import contextlib
import io
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time
import unittest
from unittest.mock import patch

from local_uat_storage import (
    GIB, MIB, StorageGuardError, accounted_bytes, add_log_budget_arguments,
    check_budgets, validate_paths,
)

RUNNER = Path(__file__).with_name("run_clickbench_ingest_uat.sh")


class StorageGuardTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.home = Path(self.temp.name) / "home"
        self.root = self.home / "LocalData/uat"
        self.root.mkdir(parents=True)
        self.source = self.root / "sources/hits.parquet"
        self.source.parent.mkdir()
        self.source.write_bytes(b"source-fixture")
        self.target = self.root / "vortex/result.vortex"
        self.logs = self.root / "logs/run"

    def test_local_paths_and_unsynced_external_source(self):
        self.assertEqual(validate_paths(
            self.root, self.source, self.target, self.logs,
            home=self.home, platform="darwin",
        )[0], self.root.resolve())

    def test_macos_synced_locations_fail_closed(self):
        for name in ("Desktop", "Documents", "Library/CloudStorage",
                     "Library/Mobile Documents",
                     "Library/Application Support/CloudDocs"):
            with self.subTest(name=name), self.assertRaises(StorageGuardError):
                validate_paths(
                    self.root, self.home / name / "data.parquet", self.target, self.logs,
                    home=self.home, platform="darwin",
                )

    def test_symlink_and_case_variants_cannot_bypass_path_guard(self):
        synced = self.home / "Documents"
        synced.mkdir()
        alias = self.home / "alias"
        alias.symlink_to(synced, target_is_directory=True)
        for source in (alias / "data", self.home / "dOcUmEnTs/data"):
            with self.assertRaises(StorageGuardError):
                validate_paths(self.root, source, self.target, self.logs,
                               home=self.home, platform="darwin")

    def test_target_cannot_escape_accounted_workspace(self):
        for target in (self.home / "elsewhere/out.vortex", self.source):
            with self.assertRaises(StorageGuardError):
                validate_paths(self.root, self.source, target, self.logs)
        self.target.parent.mkdir()
        self.target.symlink_to(self.home / "outside")
        with self.assertRaises(StorageGuardError):
            validate_paths(self.root, self.source, self.target, self.logs)

    def test_accounting_counts_sparse_files_and_deduplicates_hardlinks(self):
        payload = self.root / "sparse"
        with payload.open("wb") as stream:
            stream.truncate(2 * 1024 * 1024)
        before = accounted_bytes(self.root)
        self.assertGreaterEqual(before, 2 * 1024 * 1024)
        os.link(payload, self.root / "alias")
        self.assertEqual(accounted_bytes(self.root), before)
        (self.root / "loop").symlink_to(self.root, target_is_directory=True)
        self.assertLess(accounted_bytes(self.root), before + 8192)

    def test_all_budgets_and_candidate_reservation_are_enforced(self):
        self.logs.mkdir(parents=True)
        (self.logs / "stdout").write_bytes(b"x" * 32)
        kwargs = dict(min_free_bytes=20, reserve_bytes=40,
                      max_workspace_bytes=100_000, max_log_bytes=100_000)
        with patch("local_uat_storage.available_bytes", return_value=100):
            self.assertEqual(check_budgets(self.root, self.target, self.logs, **kwargs)["free_bytes"], 100)
            for override in (dict(min_free_bytes=70), dict(max_workspace_bytes=1),
                             dict(max_log_bytes=1)):
                with self.subTest(override=override), self.assertRaises(StorageGuardError):
                    check_budgets(self.root, self.target, self.logs, **(kwargs | override))

    def test_nested_accounting_preserves_link_boundaries_and_missing_paths(self):
        directory = self.root / "deep" / "nested"
        directory.mkdir(parents=True)
        payload = directory / "payload"
        payload.write_bytes(b"retained output")
        os.link(self.source, directory / "source-hardlink")
        external = self.home / "outside"
        external.mkdir()
        (external / "payload").write_bytes(b"outside the workspace" * 4096)
        link = directory / "external-link"
        link.symlink_to(external, target_is_directory=True)

        def allocated(path):
            info = path.lstat()
            return max(info.st_size, getattr(info, "st_blocks", 0) * 512)

        self.assertEqual(accounted_bytes(self.root), sum(map(allocated, (self.source, payload, link))))
        self.assertEqual(accounted_bytes(link), allocated(link))
        self.assertEqual(accounted_bytes(self.root / "missing"), 0)

    def test_history_and_active_run_limits_are_independent_and_inclusive(self):
        history = self.root / "logs/completed"
        history.mkdir(parents=True)
        (history / "evidence").write_bytes(b"h" * 65536)
        self.logs.mkdir()
        (self.logs / "stdout").write_bytes(b"small active run")
        total = accounted_bytes(self.root / "logs")
        active = accounted_bytes(self.logs)
        limits = dict(min_free_bytes=0, reserve_bytes=0, max_workspace_bytes=GIB,
                      max_log_bytes=total, max_run_log_bytes=active)
        result = check_budgets(self.root, self.target, self.logs, **limits)
        self.assertEqual(result["log_bytes"], total)
        self.assertEqual(result["run_log_bytes"], active)
        for changes, diagnostic in (
            ({"max_log_bytes": total - 1}, "retained log budget"),
            ({"max_run_log_bytes": active - 1}, "active run log budget"),
        ):
            with self.subTest(changes=changes), self.assertRaisesRegex(StorageGuardError, diagnostic):
                check_budgets(self.root, self.target, self.logs, **(limits | changes))

    def test_temporary_log_reservation_counts_against_both_limits_and_disk(self):
        self.logs.mkdir(parents=True)
        (self.logs / "stdout").write_bytes(b"original evidence")
        size = accounted_bytes(self.logs)
        reserve = 8192
        limits = dict(min_free_bytes=0, reserve_bytes=reserve, reserve_log_bytes=reserve,
                      max_workspace_bytes=GIB, max_log_bytes=size + reserve,
                      max_run_log_bytes=size + reserve)
        check_budgets(self.root, self.target, self.logs, **limits)
        for change, diagnostic in (
            ({"max_log_bytes": size + reserve - 1}, "retained log budget"),
            ({"max_run_log_bytes": size + reserve - 1}, "active run log budget"),
            ({"reserve_bytes": 0}, "included in the candidate reservation"),
        ):
            with self.subTest(change=change), self.assertRaisesRegex(StorageGuardError, diagnostic):
                check_budgets(self.root, self.target, self.logs, **(limits | change))
        with patch("local_uat_storage.available_bytes", return_value=reserve - 1):
            with self.assertRaisesRegex(StorageGuardError, "insufficient free disk"):
                check_budgets(self.root, self.target, self.logs, **limits)

    def test_log_budget_defaults_environment_and_explicit_precedence(self):
        def parse(arguments=()):
            parser = argparse.ArgumentParser()
            add_log_budget_arguments(parser)
            return vars(parser.parse_args(arguments))
        with patch.dict(os.environ, {}, clear=True):
            self.assertEqual(parse(), {"max_log_mib": 1024, "max_run_log_mib": 256})
            self.assertEqual(parse(["--max-log-mib", "0", "--max-run-log-mib", "0.5"]),
                             {"max_log_mib": 0, "max_run_log_mib": 0.5})
        with patch.dict(os.environ, {"SHARDLOOM_CLICKBENCH_UAT_MAX_LOG_MIB": "512",
                                     "SHARDLOOM_CLICKBENCH_UAT_MAX_RUN_LOG_MIB": "16"}):
            self.assertEqual(parse(), {"max_log_mib": 512, "max_run_log_mib": 16})
            self.assertEqual(parse(["--max-log-mib", "32", "--max-run-log-mib", "8"]),
                             {"max_log_mib": 32, "max_run_log_mib": 8})
        for invalid in ("-1", "nan", "inf", "", "invalid"):
            for option, environment in (("max-log-mib", "SHARDLOOM_CLICKBENCH_UAT_MAX_LOG_MIB"),
                                        ("max-run-log-mib", "SHARDLOOM_CLICKBENCH_UAT_MAX_RUN_LOG_MIB")):
                with self.subTest(invalid=invalid, option=option), contextlib.redirect_stderr(io.StringIO()):
                    with self.assertRaises(SystemExit):
                        parse([f"--{option}", invalid])
                    with patch.dict(os.environ, {environment: invalid}), self.assertRaises(SystemExit):
                        parse()

    def fake_binary(self, mode):
        binary = self.home / "fake-shardloom"
        binary.write_text(
            "#!/usr/bin/env python3\n"
            "from pathlib import Path\n"
            "import sys, time\n"
            f"mode = {mode!r}\n"
            "target = Path(sys.argv[sys.argv.index('--output') + 1])\n"
            "target.write_bytes(b'vortex-fixture')\n"
            "target.with_suffix('.pid').write_text(str(__import__('os').getpid()))\n"
            "if mode == 'flood':\n"
            "    print('x' * (2 * 1024 * 1024), flush=True)\n"
            "    time.sleep(10)\n"
            "elif mode == 'wait':\n"
            "    time.sleep(10)\n"
            "else:\n"
            "    print('{}', flush=True)\n",
            encoding="utf-8",
        )
        binary.chmod(0o755)
        return binary

    def run_harness(self, mode="ok", extra=()):
        return subprocess.run(
            ["bash", str(RUNNER), "--uat-root", str(self.root),
             "--binary", str(self.fake_binary(mode)), "--min-free-gib", "0",
             "--max-artifact-gb", "0.01", "--max-workspace-gib", "0.1",
             "--progress-interval-seconds", "0.05",
             "--skip-source-residency-check", *extra],
            text=True, capture_output=True, timeout=15,
        )

    def test_root_override_updates_both_default_paths_and_completes(self):
        result = self.run_harness()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        summary = json.loads(next((self.root / "logs").glob("*/prepare_summary.json")).read_text())
        self.assertEqual(summary["source"], str(self.source))
        self.assertEqual(summary["target"], str(self.root / "vortex/hits-parquet-100m.vortex"))
        self.assertEqual(summary["stop_reason"], "process_completed")
        self.assertGreater(summary["native_peak_rss_bytes"], 0)
        self.assertGreater(summary["native_process_seconds"], 0)
        self.assertFalse((self.root / ".ingest-uat.lock").exists())

    def test_preflight_failure_preserves_existing_target_and_creates_no_logs(self):
        self.target.parent.mkdir()
        self.target.write_bytes(b"keep-existing-artifact")
        result = self.run_harness(extra=("--target", str(self.target),
                                        "--replace-existing", "--max-workspace-gib", "0"))
        self.assertEqual(result.returncode, 78, result.stdout + result.stderr)
        self.assertEqual(self.target.read_bytes(), b"keep-existing-artifact")
        self.assertFalse((self.root / "logs").exists())

    def test_log_flood_is_stopped_and_reported_as_failure(self):
        result = self.run_harness("flood", ("--max-log-mib", "0.5"))
        self.assertNotEqual(result.returncode, 0)
        summary = json.loads(next((self.root / "logs").glob("*/prepare_summary.json")).read_text())
        self.assertEqual(summary["stop_reason"], "storage_budget_guard_failed")
        marker = self.root / "vortex/hits-parquet-100m.pid"
        writer_pid = int(marker.read_text())
        with self.assertRaises(ProcessLookupError):
            os.kill(writer_pid, 0)
        self.assertFalse((self.root / ".ingest-uat.lock").exists())

    def test_active_run_flood_stops_with_room_for_retained_history(self):
        result = self.run_harness("flood", ("--max-log-mib", "8", "--max-run-log-mib", "0.5"))
        self.assertEqual(result.returncode, 78, result.stdout + result.stderr)
        summary_path = next((self.root / "logs").glob("*/prepare_summary.json"))
        summary = json.loads(summary_path.read_text())
        self.assertEqual(summary["stop_reason"], "storage_budget_guard_failed")
        self.assertIn("active run log budget", (summary_path.parent / "storage_error.txt").read_text())
        writer_pid = int((self.root / "vortex/hits-parquet-100m.pid").read_text())
        with self.assertRaises(ProcessLookupError):
            os.kill(writer_pid, 0)
        self.assertFalse((self.root / ".ingest-uat.lock").exists())

    def test_ingest_small_run_preserves_history_larger_than_its_run_budget(self):
        history = self.root / "logs/completed/evidence.json"
        history.parent.mkdir(parents=True)
        original = b"h" * 65536
        history.write_bytes(original)
        with patch.dict(os.environ, {"SHARDLOOM_CLICKBENCH_UAT_MAX_LOG_MIB": "1",
                                     "SHARDLOOM_CLICKBENCH_UAT_MAX_RUN_LOG_MIB": "0"}):
            result = self.run_harness(extra=("--max-run-log-mib", "0.05"))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(history.read_bytes(), original)
        snapshot = json.loads(next((self.root / "logs").glob("ingest*/storage.json")).read_text())
        self.assertEqual(snapshot["max_log_bytes"], MIB)
        self.assertGreater(snapshot["log_bytes"], snapshot["max_run_log_bytes"])
        self.assertLess(snapshot["run_log_bytes"], snapshot["max_run_log_bytes"])

    def test_final_ingest_summary_counts_toward_active_run_budget(self):
        baseline = self.run_harness()
        self.assertEqual(baseline.returncode, 0, baseline.stdout + baseline.stderr)
        first = next((self.root / "logs").glob("*/prepare_summary.json"))
        cap = accounted_bytes(first.parent) - accounted_bytes(first)
        # Use a separate workspace so second-resolution run names cannot collide.
        self.root = self.root.with_name("uat-second")
        self.source = self.root / "sources/hits.parquet"
        self.source.parent.mkdir(parents=True)
        self.source.write_bytes(b"source-fixture")
        result = self.run_harness(extra=("--max-run-log-mib", str(cap / MIB)))
        self.assertEqual(result.returncode, 78, result.stdout + result.stderr)
        second = next((self.root / "logs").glob("*/prepare_summary.json"))
        summary = json.loads(second.read_text())
        self.assertEqual(summary["stop_reason"], "storage_budget_guard_failed")
        self.assertEqual(summary["returncode"], 78)
        self.assertGreater(accounted_bytes(second.parent), cap)
        self.assertEqual(json.loads(first.read_text())["returncode"], 0)
        self.assertFalse((self.root / ".ingest-uat.lock").exists())

    def test_replacement_preserves_backups_staging_and_glob_lookalikes(self):
        self.target.parent.mkdir()
        self.target = self.target.with_name("result[1].vortex")
        self.target.write_bytes(b"replace-exactly-this")
        preserved = [
            self.target.with_name("result1.vortex"),
            self.target.with_name("result[1].vortex.backup"),
            self.target.with_name("result[1] 2.vortex"),
            self.target.with_name(".result[1].vortex.shardloom-tmp-unknown"),
        ]
        for path in preserved:
            path.write_bytes(b"keep-unowned-file")
        result = self.run_harness(extra=("--target", str(self.target), "--replace-existing"))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(self.target.read_bytes(), b"vortex-fixture")
        for path in preserved:
            self.assertEqual(path.read_bytes(), b"keep-unowned-file")

    def test_replacement_does_not_delete_a_source_with_target_backup_name(self):
        self.target.parent.mkdir()
        self.source = self.target.with_name(self.target.name + ".source")
        self.source.write_bytes(b"source-fixture")
        self.target.write_bytes(b"old-artifact")
        result = self.run_harness(extra=("--source", str(self.source),
                                        "--target", str(self.target), "--replace-existing"))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(self.source.read_bytes(), b"source-fixture")
        self.assertEqual(self.target.read_bytes(), b"vortex-fixture")

    def test_second_run_cannot_enter_locked_workspace(self):
        (self.root / ".ingest-uat.lock").mkdir()
        result = self.run_harness()
        self.assertEqual(result.returncode, 75, result.stdout + result.stderr)
        self.assertTrue((self.root / ".ingest-uat.lock").exists())
        self.assertFalse((self.root / "logs").exists())

    def test_interrupt_stops_child_and_releases_lock(self):
        child = subprocess.Popen(
            ["bash", str(RUNNER), "--uat-root", str(self.root),
             "--binary", str(self.fake_binary("wait")), "--min-free-gib", "0",
             "--max-artifact-gb", "0.01", "--max-workspace-gib", "0.1",
             "--progress-interval-seconds", "0.05", "--skip-source-residency-check"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
        )
        try:
            marker = self.root / "vortex/hits-parquet-100m.pid"
            deadline = time.monotonic() + 5
            while not marker.exists():
                self.assertLess(time.monotonic(), deadline, "fake writer did not start")
                time.sleep(0.01)
            writer_pid = int(marker.read_text())
            child.terminate()
            stdout, stderr = child.communicate(timeout=8)
            self.assertEqual(child.returncode, 143, stdout + stderr)
            with self.assertRaises(ProcessLookupError):
                os.kill(writer_pid, 0)
            self.assertFalse((self.root / ".ingest-uat.lock").exists(), stdout + stderr)
            restart = self.run_harness(extra=("--replace-existing",))
            self.assertEqual(restart.returncode, 0, restart.stdout + restart.stderr)
        finally:
            if child.poll() is None:
                child.kill()
                child.communicate(timeout=5)


if __name__ == "__main__":
    unittest.main()
