# PERF owner verification inventory

Read-only inventory for historical `/Users/dylan/LocalData/shardloom/native-python-surface-20261010/backlog-original-plan-660.md` against `/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo` HEAD `a456b42f`. This is a command/source inventory, not a verification run or a closure decision. No tests, builds, benchmarks, Git/network mutations, or repository edits were made. Only this output file was written.

The original plan’s common `scripts/run_focused_checks.py` builder establishes the current selector command shapes: CLI integration target uses `-p shardloom-cli --features release-user-surfaces --test <target>`; Vortex library selector uses `-p shardloom-vortex --features vortex-local-primitives --lib`; both append the filter and `-- --nocapture` (`scripts/run_focused_checks.py:79-105,131-150`). Current feature declarations are in `shardloom-cli/Cargo.toml:36-48` and `shardloom-vortex/Cargo.toml:19-45`. Commands below are suggested focused selectors using those existing paths and names; none was executed. Unless stated otherwise, the historical block records broad validation language rather than a literal focused invocation. The main workspace commands remain the repository-level gates and are not duplicated as per-owner selectors.

## PERF-01 — public baseline and timing

Historical owner block: `backlog-original-plan-660.md:1078-1103` calls for same-source fresh ingest plus all 43 checked query results, separate clocks, and fresh-process latency; it names the October 15 timing UAT report but gives no command in this block. Earlier recorded output is `full43_after_clean_ingest_current_impl_20260903T112902Z/summary.json` (`:1573-1580`). The runner scripts still exist: `scripts/run_clickbench_ingest_uat.sh:34-65` and `scripts/run_clickbench_query_uat.py:317-393` write `prepare_summary.json` and `summary.json` respectively (`run_clickbench_ingest_uat.sh:97`, `run_clickbench_query_uat.py:393`).

Current focused selector: `python3 scripts/test_clickbench_query_timing.py QueryTimingTests.test_disjoint_engine_sink_and_process_overhead_reconcile` checks the separate-clock contract (`scripts/test_clickbench_query_timing.py:18-25`); `QueryTimingTests.test_missing_clocks_are_refused_unless_explicit_historical_comparison` checks missing-clock behavior (`:27-35`). They are validator unit tests, not the baseline UAT itself.

## PERF-02 — resident sessions and prepared execution

Historical owner block: `backlog-original-plan-660.md:1105-1144` records PR #1437 and the later prepared aggregate families, but contains no literal focused test command or output filename. Its acceptance evidence is described as a scoped resident matrix and `native-runtime-completion-2026-09-20.md` (`:1112-1128`).

Current focused selectors: `cargo test -p shardloom-cli --features release-user-surfaces --test resident_worker worker_reuses_prepared_native_execution_and_rebinds_changed_requests -- --nocapture` (`shardloom-cli/tests/resident_worker.rs:309`); and `... worker_rejects_replaced_source_then_reprepares_without_stale_answers ...` (`:332`). This is a CLI worker integration target, not proof of every remaining prepared family.

## PERF-03 — bounded scheduling and shared resource budget

Historical owner block: `backlog-original-plan-660.md:1146-1222` records the rejected fixed 4-GiB target, later Q21/Q23 follow-up reports, and PR #1547, then explicitly says PERF-03 remains open (`:1154-1180`). The owner’s remaining tasks are listed at `:1181-1220`; no single owner-specific runnable command is recorded there.

Current focused selectors: `cargo test -p shardloom-vortex --features vortex-local-primitives --lib two_live_native_inputs_deny_explicitly_while_serial_control_fits -- --nocapture` (`shardloom-vortex/src/ingest_input_prefetch_tests.rs:504`); and `... mismatched_cpu_or_memory_grant_rejects_single_and_partitioned_before_open ...` (`shardloom-vortex/src/local_primitive_execution_tests.rs:378`). The current helper’s Vortex profile carries `vortex-local-primitives` (`scripts/run_focused_checks.py:142-150`).

## PERF-04 — aggregate kernels and deterministic reduction

Historical owner block: `backlog-original-plan-660.md:1224-1244` records bounded C4/C6 COUNT scopes and complete Q34/Q35/C7 evidence, while naming no focused command or artifact path in this block. The remaining worker-family and semantic checklist is at `:1234-1242`.

Current focused selectors: `cargo test -p shardloom-vortex --features vortex-local-primitives --lib owned_count_complete_file_workers_admission_pressure_ties_offsets_and_fresh_state -- --nocapture` (`shardloom-vortex/src/local_primitive_aggregate_owned_count_tests.rs:69`); and `... owned_utf8_count_complete_dictionary_domains_ties_offsets_and_native_pressure_match_oracle ...` (`shardloom-vortex/src/local_primitive_aggregate_owned_utf8_tests.rs:163`).

## PERF-05 — exact dictionary aggregation under byte pressure

Historical command/output anchor: the old Q29 packet records `cargo test -p shardloom-vortex --features vortex-local-primitives transformed_dictionary -- --nocapture` (`backlog-original-plan-660.md:2622-2627`) and output `targeted_q29_chunk_domain_partials_20260904T034014Z/summary.json` (`:2627`). The current PERF-05 checklist is at `:1246-1259`; it calls for exact key/transition checks, but does not repeat a current focused command.

Current focused selectors: `cargo test -p shardloom-vortex --features vortex-local-primitives --lib filtered_native_utf8_dictionary_histogram_is_exact_across_domains_and_ties -- --nocapture` (`shardloom-vortex/src/local_primitives/filtered_string_count_tests.rs:157`); and `... filtered_exact_histogram_budget_pressure_preserves_exact_refinement ...` (`:182`).

## PERF-06 — native query spill and cleanup

Historical owner block: `backlog-original-plan-660.md:1261-1294` names scoped PR/report evidence for sort/aggregate, join (#1532), window (#1533), and pivot (#1534), including reports `native-join-pressure-2026-10-08.md`, `native-window-pressure-2026-10-08.md`, and `native-pivot-pressure-2026-10-08.md` (`:1271-1279`). It contains no literal focused command; production recovery/resource acceptance remains listed at `:1281-1292`.

Current focused selectors: `cargo test -p shardloom-vortex --features vortex-local-primitives --lib native_relational_spill_stable_multikey_complete_values_and_repeated_cleanup -- --nocapture` (`shardloom-vortex/src/local_primitive_relational_spill_tests.rs:137`); and `... streaming_set_membership_growth_is_denied_with_or_without_replay_spill_permission ...` (`shardloom-vortex/src/local_primitive_relational_batch_set_pressure_tests.rs:161`). These cover separate spill/order and resident-membership pressure families.

## PERF-07 — report descriptors versus owned array results

Historical owner block: `backlog-original-plan-660.md:1296-1359` has a `Verification` stanza at `:1352-1356` naming focused array/result tests, workspace checks, and targeted/full UAT, but no literal focused selector or output filename. The stanza also calls out Python parity only when wrappers change.

Current focused selectors: `cargo test -p shardloom-vortex --features vortex-local-primitives --lib columnar_batch_materializes_rows_only_at_json_sink_boundary -- --nocapture` (`shardloom-vortex/src/columnar_result_dataplane.rs:890`); `... native_vortex_sink_keeps_batch_columnar ...` (`:929`); and `... output_payload_descriptor_tracks_columnar_batch_content ...` (`:1035`). They exercise contract helpers; they do not by themselves establish route-wide migration.

## PERF-08 — ingestion profile and duplicate work

Historical writer evidence shared with PERF-09: the physical-design packet records `cargo test -p shardloom-vortex --features vortex-write,universal-format-io plain_utf8 -- --nocapture`, `embedded_derived`, and `streaming_vortex_write_preserves` (`backlog-original-plan-660.md:1692-1702`). It records candidate logs including `ingest_cli_uat_gated_20260904T020627Z` (`:1680-1690`) and the retained clean outputs `ingest_cli_uat_gated_20260903T112348Z` plus `full43_after_clean_ingest_current_impl_20260903T112902Z` (`:1851-1855`). The verification stanza calls `scripts/run_clickbench_ingest_uat.sh --replace-existing` (`:1872-1876`); the runner and `prepare_summary.json` output remain present (`scripts/run_clickbench_ingest_uat.sh:34-65,97`).

Current focused selectors: `cargo test -p shardloom-vortex --features vortex-write,universal-format-io --lib text_zone_writer_reopens_exact_nullable_values_and_filtered_zone_boundaries -- --nocapture` (`shardloom-vortex/src/vortex_ingest_text_zone_tests.rs:25`); and `... text_filter_pruning_skips_unprojected_disjoint_and_null_only_payloads_with_conservative_utf8_bounds ...` (`:194`).

## PERF-09 — costed encoding and bounded ordered writer

Historical evidence is the same physical-design verification block as PERF-08: exact command spellings and artifact names are at `backlog-original-plan-660.md:1692-1706,1872-1876`. Do not treat the rejected writer variants or the report-only profile admission as accepted production evidence (`:1817-1834`). The current PERF-09 tasks and generic verifier are at `:1382-1428`; they do not provide a separate exact per-owner command/output name.

Current focused selectors: `cargo test -p shardloom-vortex --features vortex-write,universal-format-io --lib shared_slot_preserves_startup_steady_empty_and_eof_bounds -- --nocapture` (`shardloom-vortex/src/vortex_ingest_writer_slot_tests.rs:189`); and `... text_zone_writer_reopens_exact_nullable_values_and_filtered_zone_boundaries ...` (`shardloom-vortex/src/vortex_ingest_text_zone_tests.rs:25`). The existing Cargo features are declared at `shardloom-vortex/Cargo.toml:28-40`; no profile-performance acceptance is implied by these tests.

## PERF-10 — reusable fused native physical operators

Historical owner block: `backlog-original-plan-660.md:1430-1450` gives a broad operator checklist but no per-owner command or output name. The older kernel-registry verification stanza prescribes only generic focused kernel/local-primitive/CLI evidence plus workspace/UAT gates (`:3036-3048`); it does not specify test selectors.

Current focused selectors: `cargo test -p shardloom-vortex --features vortex-local-primitives --lib native_selection_preserves_values_nulls_and_row_order -- --nocapture` (`shardloom-vortex/src/local_primitive_relational_selection_tests.rs:4`); `... count_where_metadata_physical_kernels_evaluate_without_io ...` (`shardloom-vortex/src/metadata_physical_kernel.rs:720`); and `cargo test -p shardloom-cli --features release-user-surfaces --test public_workflow_route public_route_admits_native_vortex_filter_project_payload -- --nocapture` (`shardloom-cli/tests/public_workflow_route.rs:3224`).

## PERF-11 — bounded memory-visible ingest-to-result

Historical owner block: `backlog-original-plan-660.md:1452-1487` identifies accepted composition in `native-stream-input-composition-2026-10-13.md` and PR #1548 (`:1465-1483`) but gives no owner-specific command/output path. Its verifier remains generic envelope, cancellation and percentile acceptance (`:1462-1485`).

Current focused selectors: `cargo test -p shardloom-vortex --features vortex-local-primitives --lib structured_native_vortex_export_is_admitted_and_preserves_nested_results -- --nocapture` (`shardloom-vortex/src/local_primitive_execution_tests.rs:417`); and `cargo test -p shardloom-cli --features release-user-surfaces --test public_workflow_route public_native_array_sink_reopens_full_nullable_projection_and_filter_values -- --nocapture` (`shardloom-cli/tests/public_workflow_route.rs:60`).

## PERF-12 — held-out and comparative acceptance suites

Historical owner block: `backlog-original-plan-660.md:1489-1529` names the 4,096-row matrix (640 records), later text-layout suite, complete 129-call Full43, and report `universal-workflow-completion-2026-10-01.md#workflow-acceptance-matrix` (`:1492-1509`), but no literal owner-specific command. Current runners include `scripts/run_clickbench_query_uat.py` which writes `summary.json` (`:317-393`) and `scripts/run_native_relational_suite.py` which writes a suite `summary.json` (`scripts/run_native_relational_suite.py:144-229`).

Current validator selectors: `python3 scripts/test_clickbench_query_uat.py QueryUatTests.test_full_suite_default_executes_each_query_once_and_has_no_hot_score` (`scripts/test_clickbench_query_uat.py:504`); and `... QueryUatTests.test_targeted_results_cannot_be_scored_as_complete_full_suite ...` (`:610`). The source class is `QueryUatTests` (`:10`). These validate harness behavior, not the held-out result matrix itself.

## PERF-13 — conditional profile-guided compilation

Historical owner block: `backlog-original-plan-660.md:1531-1544` labels PGO `v1_candidate_pending_feasibility`, records only guarded orchestration/tool lookup/tiny instrument-merge-use smoke, and explicitly says no full-workspace PGO build or measured gain (`:1532-1537`). No invocation or output artifact is named in the owner block.

Current script/validator: `scripts/build_shardloom_pgo.py` exists (its orchestration tests describe it as no Cargo/compiler invocation at `scripts/test_build_shardloom_pgo.py:1-3`). Focused checks include `python3 scripts/test_build_shardloom_pgo.py PgoTests.test_failed_training_never_merges_or_builds_profile_use` (`:224`) and `... PgoTests.test_three_frozen_binaries_flags_and_fresh_merge_inputs ...` (`:231`). These test orchestration guards and do not establish full PGO feasibility or benefit.

## NATIVE-ENCODED-EXCHANGE — cross-process native exchange

Historical owner block: `backlog-original-plan-660.md:3146-3232` lists the design/protocol/security and two-process requirements, but specifies no runnable test command, selector, or result artifact; it says protocol and cross-process evidence do not yet exist (`:3155-3160`). The later status names compression/timing PR #1555 and local stream/set work PRs #1557-1558 as separate foundations, not exchange completion (`:3325-3334`).

Direct current exchange selector: none identified in the inspected source/script inventory. `scripts/run_native_result_stream_uat.py` is a local result-stream UAT runner that emits `summary.json` (`scripts/run_native_result_stream_uat.py:23-30,186-187`); it is not a two-process transport test. No existing local output or control-plane selector should be substituted for the owner’s explicitly required protocol, security, independent-client, and two-process integration evidence.
