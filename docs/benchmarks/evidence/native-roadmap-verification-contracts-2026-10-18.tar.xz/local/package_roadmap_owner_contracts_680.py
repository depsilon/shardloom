"""Preserve the verified owner-command correction and its first failed audit."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
D=O/'roadmap-owner-contract-evidence-680'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
receipt=read(O/'roadmap-owner-contracts-679a2.json')
report=read(O/'roadmap-owner-verification-679a2/validation.json')
review=read(O/'roadmap-primary-mechanical-review-679.json')
assert receipt['status']==report['status']==review['status']=='passed'
assert receipt['returncode']==0 and receipt['process_group_drained'] and receipt['direct_child_reaped']
assert sha(O/'roadmap-owner-contracts-679a2.log')==receipt['log_sha256']
assert len(report['checks'])==11 and all(x['returncode']==0 for x in report['checks'])
assert len(report['rust_selectors'])==22 and len(report['owners'])==14
for ref in report['source_identities']:assert sha(R/ref['file'])==ref['sha256']
for check in report['checks']:
 p=O/'roadmap-owner-verification-679a2'/check['log']['file']
 assert sha(p)==check['log']['sha256']
paths=[Path(__file__),O/'verify_roadmap_owner_contracts_679.py',O/'verify_roadmap_owner_contracts_original_679.py',
 O/'verify_roadmap_mechanical_679.py',O/'verify_roadmap_mechanical_672.py',O/'roadmap-primary-mechanical-review-679.json',
 O/'roadmap-owner-verification-inventory-678.md',O/'roadmap-owner-contracts-679.json',O/'roadmap-owner-contracts-679.log',
 O/'roadmap-owner-contracts-679a2.json',O/'roadmap-owner-contracts-679a2.log']
paths+=sorted((O/'roadmap-owner-verification-679a2').iterdir())
paths+=[R/x['file'] for x in report['source_identities']]
assert len(paths)==len(set(paths)) and all(p.is_file() for p in paths)
assert sum(p.stat().st_size for p in paths)<4*1024*1024
assert shutil.disk_usage(O).free>12*1024**3
assert not D.exists();D.mkdir()
stem='native-roadmap-verification-contracts-2026-10-18'
archive=D/(stem+'.tar.xz')
members=[]
with tarfile.open(archive,'x:xz') as bundle:
 for p in paths:
  root,prefix=(R,'repository') if p.is_relative_to(R) else (O,'local')
  name=prefix+'/'+p.relative_to(root).as_posix()
  members.append(dict(file=name,bytes=p.stat().st_size,sha256=sha(p),source=str(p)))
  bundle.add(p,arcname=name,recursive=False)
assert archive.stat().st_size<1024*1024
with tarfile.open(archive,'r:xz') as bundle:
 assert len(bundle.getmembers())==len(members)
 for member in members:
  data=bundle.extractfile(member['file']).read()
  assert len(data)==member['bytes'] and hashlib.sha256(data).hexdigest()==member['sha256']==sha(member['source'])
initial='docs/benchmarks/evidence/native-roadmap-documentation-validation-2026-10-18.json'
head=report['source_head']
old=subprocess.check_output(['git','show',head+':'+initial],cwd=R)
index=dict(schema_version='shardloom.roadmap_owner_verification_contract_evidence.v1',status='passed',
 review_comment='https://github.com/depsilon/shardloom/pull/1575#discussion_r4307076145',
 initial_head=head,initial_validation=dict(file=initial,commit=head,sha256=hashlib.sha256(old).hexdigest()),
 archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),members=members,all_members_reopened=True,
 owners=report['owners'],rust_selectors_source_verified=len(report['rust_selectors']),
 executed_documentation_checks=len(report['checks']),runtime_source_files=2416,runtime_source_unchanged=True,
 source_identities=report['source_identities'],completion_and_release_remain_blocked=True,
 primary_mechanical_summary={k:review[k] for k in ['original_rows','parents','steps','step_kinds','local_links_verified','anchors_verified']},
 native_execution_note=report['native_execution_note'],
 correction='The first static audit rejected an incorrect unittest class from the worker inventory before executing checks. The class and writer feature flags are verified against source; original audit/helper and both guard receipts are preserved.',
 helper_imports='Common guard and freeze helper import closure is preserved in the initial documentation-validation archive at the pinned initial head.')
target=R/'docs/benchmarks/evidence'/(stem+'.json')
assert not target.exists() and not target.with_suffix('.tar.xz').exists()
saved=D/target.name;saved.write_text(json.dumps(index,indent=2)+'\n')
shutil.copy2(saved,target);shutil.copy2(archive,target.with_suffix('.tar.xz'))
assert sha(saved)==sha(target) and sha(archive)==sha(target.with_suffix('.tar.xz'))
print(json.dumps(dict(status='passed',members=len(members),archive_bytes=archive.stat().st_size,index=str(target),index_sha256=sha(target))))
