"""Verify the documentation-only owner contracts without rebuilding native code."""
import ast
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tomllib

R=Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
O=Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
D=O/'roadmap-owner-verification-679'
sys.path[:0]=[str(O),str(R/'scripts')]
from freeze_native_release_298 import sources,save,sha

assert not D.exists();D.mkdir()
frozen=json.loads((O/'native-release-source-roadmap663.json').read_text())
assert sources()==frozen['source_sha256']
doc=R/'docs/architecture/native-roadmap-verification-contracts-2026-10-18.md'
plan=R/'docs/architecture/phased-execution-plan.md'
content=doc.read_text(); planned=plan.read_text()
owners=re.findall(r'^- \[ \] `([^`]+)`',planned,re.M)
assert len(owners)==14
sections=re.split(r'^## ',content,flags=re.M)[1:]
sections={x.splitlines()[0]:x for x in sections}
assert set(owners)<=set(sections)
assert set(sections)==set(owners)|{'Running and recording checks'}
for owner in owners:
    assert f'native-roadmap-verification-contracts-2026-10-18.md#{owner.lower()}' in planned
    assert owner.lower()+'-acceptance.json' in sections[owner]
assert 'zero matching tests' in content and 'No current two-process transport' in content
blocks=re.findall(r'```sh\n(.*?)\n```',content,re.S)
shell='\n\n'.join(blocks)
subprocess.run(['/bin/bash','-n'],input=shell,text=True,check=True)
rust=[];python=[];outputs=[]
for block in blocks:
 for line in block.splitlines():
    if not line.startswith(('cargo test -p ','python3 scripts/')):continue
    parts=shlex.split(line); command=parts[:parts.index('>')] if '>' in parts else parts
    for word in parts:
        if word.startswith('$SHARDLOOM_ROADMAP_EVIDENCE_ROOT/'):
            outputs.append(word.rsplit('/',1)[1])
    if command[0]=='cargo':
        package=command[command.index('-p')+1]
        manifest=tomllib.loads((R/package/'Cargo.toml').read_text())
        assert manifest['package']['name']==package
        features=command[command.index('--features')+1]
        assert features=='release-user-surfaces' and features in manifest['features']
        if '--lib' in command:
            assert package=='shardloom-vortex'
            selector=command[command.index('--lib')+1]
            files=list((R/package/'src').rglob('*.rs'))
        else:
            assert '--test' in command and package=='shardloom-cli'
            target=command[command.index('--test')+1]
            selector=command[command.index('--test')+2]
            files=[R/package/'tests'/(target+'.rs')]
        matches=[]
        for file in files:
            text=file.read_text()
            for match in re.finditer(r'\bfn '+re.escape(selector)+r'\s*\(',text):
                assert '#[test]' in text[max(0,match.start()-300):match.start()]
                matches.append(dict(file=str(file.relative_to(R)),line=text[:match.start()].count('\n')+1,sha256=sha(file)))
        assert len(matches)==1,(selector,matches)
        rust.append(dict(command=command,selector=selector,matches=matches,verification='source identity and test declaration; not executed in this docs-only correction'))
    else:
        source=R/command[1]; assert source.is_file()
        tree=ast.parse(source.read_text())
        if source.name.startswith('test_'):
            classes={node.name:{x.name for x in node.body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))} for node in tree.body if isinstance(node,ast.ClassDef)}
            for selector in command[2:]:
                cls,method=selector.split('.',1);assert method in classes[cls]
        python.append(command)
assert len(rust)==22 and len(set(outputs))==len(outputs)
checks=[]
def run(name,command):
    logfile=D/(name+'.log')
    with logfile.open('xb') as stream:
        result=subprocess.run(command,cwd=R,stdout=stream,stderr=subprocess.STDOUT)
    checks.append(dict(name=name,command=command,returncode=result.returncode,log=dict(file=logfile.name,bytes=logfile.stat().st_size,sha256=sha(logfile))))
    assert result.returncode==0,(name,logfile.read_text()[-4000:])
    print(json.dumps(dict(check=name,status='passed')),flush=True)

run('whitespace',['git','diff','--check'])
for number,command in enumerate(python):
    actual=[sys.executable]+command[1:]
    actual=[str(D/arg.rsplit('/',1)[1]) if arg.startswith('$SHARDLOOM_ROADMAP_EVIDENCE_ROOT/') else arg for arg in actual]
    run(f'{number:02d}-'+Path(command[1]).stem,actual)
run('roadmap-contract-regressions',[sys.executable,'-m','unittest','python.tests.test_runtime_gap_family_burn_down','python.tests.test_compute_engine_completion_gate']+[
 'python.tests.test_release_scripts.ReleaseScriptTests.'+name for name in [
 'test_architecture_tracker_missing_inputs_fail_even_when_blocked_allowed',
 'test_architecture_tracker_accepts_mapped_global_review_burn_down',
 'test_architecture_tracker_rejects_stale_global_review_burn_down',
 'test_v1_inclusion_scope_accepts_required_and_candidate_rows',
 'test_v1_inclusion_scope_blocks_missing_phase_classification',
 'test_v1_inclusion_scope_blocks_required_report_only_posture',
 'test_v1_inclusion_scope_blocks_deferred_without_diagnostics',
 'test_v1_inclusion_scope_blocks_missing_production_diagnostic_row']])
run('full-reconciliation-mechanical',[sys.executable,str(O/'verify_roadmap_mechanical_679.py')])
boundary=json.loads((D/'perf-12-completion-inspection.json').read_text())
release=json.loads((D/'perf-12-release-inspection.json').read_text())
assert boundary['status']==release['status']=='blocked'
assert boundary['phase_plan_unchecked_count']==68
assert sources()==frozen['source_sha256']
record=dict(schema_version='shardloom.roadmap_owner_verification_contracts.v1',status='passed',
 source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
 docs_only=True,owners=owners,rust_selectors=rust,python_commands=python,checks=checks,
 source_identities=[dict(file=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=sha(p)) for p in [plan,doc]],
 runtime_source_files=len(frozen['source_sha256']),runtime_source_unchanged=True,
 remaining_scope=dict(parents=14,steps=54,required_steps=37,conditional_steps=17),
 completion_and_release_remain_blocked=True,
 prior_inventory=dict(path=str(O/'roadmap-owner-verification-inventory-678.md'),sha256=sha(O/'roadmap-owner-verification-inventory-678.md'),
  disposition='Accepted as a source inventory. Primary replaced helper/prototype examples with production regressions and corrected missing writer features; no worker command was treated as executed.'),
 native_execution_note='No Rust tests/builds or benchmark reruns in this documentation correction. Existing native sources are identical to the accepted fresh UAT. Hosted CI reruns against the final PR head.',
 helper=dict(path=__file__,sha256=sha(__file__)))
save(D/'validation.json',record)
print(json.dumps(dict(status='passed',owners=len(owners),rust_selectors=len(rust),checks=len(checks))),flush=True)
