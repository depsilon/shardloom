"""Record finite sampling population acceptance after all frozen gates pass."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent


def read(path):
    return json.loads(Path(path).read_text())


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}


def check(ref):
    assert identity(ref['path']) == ref, ref['path']


acceptance = read(OUT / 'acceptance-final-verified.json')
assert acceptance['status'] == 'passed' and acceptance['finite_family_acceptance_complete']
assert not acceptance['broader_membership_population_owner_complete']
assert not acceptance['broader_recovery_owner_complete'] and not acceptance['performance_claim']
source = read(OUT / 'acceptance-source.json')
assert acceptance['source_commit'] == acceptance['compiled_source_commit'] == source['source_commit']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == source['source_commit']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True) == ''
for name, digest in source['source_hashes'].items():
    assert identity(ROOT / name)['sha256'] == digest, name
for group in ('gates', 'development_evidence'):
    for record in acceptance[group].values():
        check(record['receipt'])
        check(record['log'])
for ref in acceptance['phase_reports'].values():
    check(ref)

native_log = (OUT / 'sampling-native-vortex-tests-736.log').read_text()
required = []
for path in sorted((ROOT / 'shardloom-vortex/src').rglob('*.rs')):
    for name in re.findall(r'^\s*fn (sampling_\w+)\(', path.read_text(), re.MULTILINE):
        assert len(re.findall(r'^test .*::' + re.escape(name) + r' \.\.\. ok$', native_log, re.MULTILINE)) == 1, name
        required.append(name)
assert len(required) == len(set(required)) == 18
regressions = []
for path in sorted((ROOT / 'shardloom-vortex/src').glob('local_primitive_relational*tests.rs')):
    for name in re.findall(r'^fn ((?:unary_membership|streaming_unary_membership|streaming_future_duplicate|native_relational_spill_large)\w+)\(', path.read_text(), re.MULTILINE):
        assert len(re.findall(r'^test .*::' + re.escape(name) + r' \.\.\. ok$', native_log, re.MULTILINE)) == 1, name
        regressions.append(name)
assert len(regressions) == 17
binding_selector = 'test_sampling_population_spill_matches_fixture_oracle_across_terminals'
binding_log = (OUT / 'sampling-direct-binding-tests-736.log').read_text()
assert re.search(r'^' + binding_selector + r' .* \.\.\. ok$', binding_log, re.MULTILINE)
public = read(OUT / 'acceptance-public-verified.json')
assert public['sampling_population_public_cases'] == 358 and public['sampling_pressure_cases'] == 12
assert public['unary_membership_public_cases'] == 210 and public['unary_pressure_public_cases'] == 59
assert len(public['sampling_complete_value_archives']) == 406
assert len(public['sampling_publication_failure_cases']) == 66
assert public['sampling_existing_destination_admission_denials'] == 12
assert public['sampling_incomplete_execution_failure_cases'] == 54
assert len(public['unary_complete_value_archives']) == 274
assert len(public['unary_publication_failure_cases']) == 63

record = {
    'schema_version': 'shardloom.native_sampling_population_acceptance.v1',
    'status': 'accepted_finite_local_scope',
    'source_commit': source['source_commit'], 'base_commit': source['base_commit'],
    'compiled_source_commit': acceptance['compiled_source_commit'],
    'scope': source['scope'],
    'sources': ['native_files', 'resident_native_memory', 'finite_streaming_batches'],
    'source_manifest': identity(OUT / 'acceptance-source.json'),
    'build': identity(OUT / 'acceptance-build.json'), 'plan': identity(OUT / 'acceptance-plan.json'),
    'runtime_acceptance': identity(OUT / 'acceptance-final-verified.json'),
    'test_counts': acceptance['test_counts'], 'required_native_selectors': required,
    'required_membership_regression_selectors': regressions,
    'direct_binding_selector': binding_selector, 'direct_binding_subcases': 48,
    'public_families': 38, 'public_cases': 5492,
    'sampling_population_public_cases': 358, 'sampling_pressure_cases': 12,
    'net_new_public_cases': 366, 'sampling_complete_value_archives': 406,
    'sampling_publication_failure_cases': 66,
    'sampling_existing_destination_admission_denials': 12,
    'sampling_incomplete_execution_failure_cases': 54,
    'sampling_complete_rows_reopened': public['sampling_rows_independently_reopened'],
    'full43': {'queries': 43, 'executions_per_query': 1, 'complete_result_rows': 381,
               'engine_execution_seconds': acceptance['engine_execution_seconds'],
               'reference_kind': 'retained_native_regression', 'performance_claim': False},
    'modular_cohorts': 18, 'native_workflows': 704, 'fresh_independent_pandas_oracle_workflows': 704,
    'completed_substeps': [],
    'accepted_finite_scope_within': ['PERF-06.membership', 'PERF-06.recovery', 'PERF-06.strategy'],
    'broader_owners_closed': [],
    'cross_cutting_owners': ['PERF-01', 'PERF-03', 'PERF-07', 'PERF-11', 'PERF-12'],
    'all_cg_1_through_cg_23_requirements_preserved': True,
    'fraction_without_replacement_scope': 'unknown_input_row_upper_bound_only',
    'replacement_scope': 'fixed_count_or_fraction_with_known_or_unknown_input_row_upper_bound',
    'weighted_and_unweighted': True,
    'crash_recovery': 'exact_owned_cleanup_followed_by_fresh_execution',
    'interrupted_execution_resume': False,
    'strategy': 'native_rank_population_or_ordinal_population_with_exact_draw_access',
    'without_replacement_output': 'selected_source_ordinal_order',
    'replacement_output': 'draw_order_with_repeated_rows_preserved',
    'source_replay_is_separate_from_sample_population': True,
    'generation_checked_on_cache_hits': True,
    'internal_pending_block_maximum_rows': 256,
    'original_population_pressure_grant_bytes': 16 << 20,
    'direct_binding_and_publication_grant_bytes': 32 << 20,
    'direct_binding_readback_grant_bytes': 128 << 20,
    'python_delivery_batch_rows_is_native_scan_bound': False,
    'whole_process_memory_ceiling': False, 'fallback_attempted': False,
    'external_engine_invoked_as_runtime': False, 'release_version_changed': False,
    'publication_attempted': False,
    'platform_scope': 'local macOS Unix; release-user-surfaces feature build',
    'claim_gate_status': 'not_claim_grade',
    'unresolved': [
        'Fixed-count and known-bound fractional sampling without replacement retain the resident top-k path.',
        'Subquery indexes and other state families retain their existing pressure boundaries.',
        'Legacy standalone PreparedVortexUnary and older row-export sampling retain their resident-only contracts.',
        'This family restarts after owned cleanup; general interrupted-execution resume is not established.',
        'Existing targets remain rejected before input demand; generation-conditional replacement remains PERF-07 work.',
        'Hosted installed-wheel, other-platform, release and competitive claims retain their independent gates.',
        'Python delivery batch_rows slices an admitted native batch; it does not bound file-reader or Arrow admission.',
        'Managed reservations do not impose a whole-process RSS ceiling.',
    ],
    'generator': identity(__file__),
}
with (OUT / 'perf-06-acceptance.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps({'status': record['status'], 'public_cases': record['public_cases'],
                  'engine_execution_seconds': record['full43']['engine_execution_seconds']}))
