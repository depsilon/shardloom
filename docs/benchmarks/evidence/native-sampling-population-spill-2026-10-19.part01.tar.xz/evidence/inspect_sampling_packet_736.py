"""Independently reopen the delivered sampling packet and its source bindings."""
import hashlib
import json
import lzma
from pathlib import Path
import re
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
DEST = ROOT / 'docs/benchmarks/evidence'
NAME = 'native-sampling-population-spill-2026-10-19'


def digest(payload):
    return hashlib.sha256(payload).hexdigest()


def load(ref):
    path = DEST / ref['file']
    assert path.is_file() and not path.is_symlink()
    payload = path.read_bytes()
    assert len(payload) == ref['bytes'] and digest(payload) == ref['sha256']
    assert len(payload) < 24 << 20
    return path, payload


index_path = DEST / (NAME + '.json')
index = json.loads(index_path.read_text())
assert index['schema_version'] == 'shardloom.native_sampling_population_evidence.v1'
assert index['status'] == 'accepted_finite_local_scope' and index['all_members_reopened']
assert index['completed_substeps'] == index['broader_owners_closed'] == []
assert (index['public_families'], index['public_cases'], index['net_new_public_cases']) == (38, 5492, 366)
assert (index['sampling_population_public_cases'], index['sampling_pressure_cases']) == (358, 12)
assert (index['sampling_complete_value_archives'], index['sampling_publication_failure_cases']) == (406, 66)
assert (index['sampling_existing_destination_admission_denials'], index['sampling_incomplete_execution_failure_cases']) == (12, 54)
assert (index['modular_cohorts'], index['native_workflows'], index['fresh_independent_pandas_oracle_workflows']) == (18, 704, 704)
assert index['source_commit'] == index['compiled_source_commit']
assert index['claim_gate_status'] == 'not_claim_grade'
for key in ('performance_claim', 'release_version_changed', 'publication_attempted'):
    assert index[key] is False
_, packed = load(index['manifest'])
manifest = json.loads(lzma.decompress(packed))
expected = {member['name']: member for member in manifest}
assert len(expected) == len(manifest) == index['member_count']
assert sum(member['bytes'] for member in manifest) == index['uncompressed_bytes'] < 1 << 30
assert {member['archive'] for member in manifest} == {part['file'] for part in index['archives']}
selected = {
    'evidence/perf-06-acceptance.json', 'evidence/acceptance-source.json',
    'evidence/acceptance-final-verified.json', 'evidence/acceptance-public-verified.json',
    'evidence/acceptance-full43-verified.json', 'evidence/acceptance-modular-verified.json',
    'evidence/sampling-closeout-source-bridge.json', 'evidence/closeout-checks-736/queue.json',
    'evidence/sampling-clippy-734.json', 'evidence/sampling-focused-735.json',
    'evidence/sampling-focused-735b.json',
}
records, seen = {}, set()
for part in index['archives']:
    path, _ = load(part)
    with tarfile.open(path, 'r:xz') as archive:
        for member in archive:
            assert member.isfile() and member.name in expected and member.name not in seen
            assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            wanted = expected[member.name]
            assert wanted['archive'] == part['file'] and wanted['bytes'] == member.size
            payload = archive.extractfile(member).read()
            assert len(payload) == wanted['bytes'] and digest(payload) == wanted['sha256']
            if member.name in selected:
                records[member.name] = json.loads(payload)
            if member.name.startswith('source/'):
                current = ROOT / member.name.removeprefix('source/')
                assert current.is_file() and digest(current.read_bytes()) == wanted['sha256']
            seen.add(member.name)
assert seen == set(expected) and set(records) == selected
accepted = records['evidence/perf-06-acceptance.json']
source = records['evidence/acceptance-source.json']
final = records['evidence/acceptance-final-verified.json']
public = records['evidence/acceptance-public-verified.json']
full43 = records['evidence/acceptance-full43-verified.json']
modular = records['evidence/acceptance-modular-verified.json']
bridge = records['evidence/sampling-closeout-source-bridge.json']
queue = records['evidence/closeout-checks-736/queue.json']
assert accepted['source_commit'] == source['source_commit'] == final['source_commit'] == index['source_commit']
assert accepted['scope'] == index['scope']
assert len(accepted['required_native_selectors']) == 18
assert len(accepted['required_membership_regression_selectors']) == 17
assert accepted['direct_binding_subcases'] == 48
assert not accepted['interrupted_execution_resume'] and not accepted['whole_process_memory_ceiling']
assert public['status'] == full43['status'] == modular['status'] == final['status'] == 'passed'
assert (public['cases'], public['families'], len(public['sampling_complete_value_archives'])) == (5492, 38, 406)
assert accepted['sampling_complete_rows_reopened'] == public['sampling_rows_independently_reopened'] == 11518
assert accepted['full43'] == index['full43']
assert full43['queries'] == full43['calls'] == 43 and full43['complete_rows'] == 381
assert full43['engine_execution_seconds'] == accepted['full43']['engine_execution_seconds']
assert accepted['full43']['reference_kind'] == 'retained_native_regression'
assert modular['native_workflows'] == modular['independent_pandas_oracle_workflows'] == 704
assert len(modular['cohort_reports']) == 18
assert queue['remaining'] == 58 and queue['required'] == 37 and queue['conditional'] == 21
assert len(queue['owners']) == 14 and queue['completed_substeps'] == []
assert records['evidence/sampling-clippy-734.json']['status'] == 'failed'
assert records['evidence/sampling-focused-735.json']['status'] == 'failed'
assert records['evidence/sampling-focused-735b.json']['status'] == 'passed'
assert set(bridge['only_frozen_source_change']) == {'scripts/check_user_surface_reference.py'}
for name, frozen in source['source_hashes'].items():
    wanted = bridge['only_frozen_source_change'].get(name, {}).get('closeout_sha256', frozen)
    assert digest((ROOT / name).read_bytes()) == wanted
for name, wanted in bridge['documents'].items():
    assert digest((ROOT / name).read_bytes()) == wanted
report = ROOT / 'docs/benchmarks' / (NAME + '.md')
for target in re.findall(r'\]\(([^)]+)\)', report.read_text()):
    if '://' not in target and not target.startswith('#'):
        assert (report.parent / target.split('#', 1)[0]).resolve().is_file(), target
result = {
    'schema_version': 'shardloom.native_sampling_population_packet_inspection.v1',
    'status': 'passed', 'source_commit': source['source_commit'],
    'index': {'file': index_path.name, 'bytes': index_path.stat().st_size, 'sha256': digest(index_path.read_bytes())},
    'archive_parts': len(index['archives']), 'members_independently_reopened': len(seen),
    'source_and_document_identities_verified': True, 'failure_history_preserved': True,
    'public_cases': 5492, 'public_families': 38, 'sampling_complete_rows_reopened': 11518,
    'engine_execution_seconds': full43['engine_execution_seconds'],
    'remaining_owners': 14, 'remaining_substeps': 58, 'broader_owners_closed': [],
    'claim_gate_status': 'not_claim_grade', 'publication_attempted': False,
}
with (DEST / (NAME + '.inspection.json')).open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result))
