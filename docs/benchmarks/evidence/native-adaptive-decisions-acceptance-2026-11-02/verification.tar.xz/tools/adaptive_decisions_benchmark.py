"""One current-patch observation of the original 347 cases; saved baseline only."""
import argparse
import json
import math
from pathlib import Path
import platform
import subprocess
import sys

import count_cohort as original

OUT = original.OUT
REPO = Path('/Users/dylan/.codex/worktrees/native-adaptive-evidence/shardloom-local-repo')
PREVIOUS = OUT / 'broad-adaptive-baseline-r1'
RUNTIME = OUT / 'io-runtime-adaptive-decisions-r1'
ROOT = OUT / 'broad-adaptive-decisions-r1'
read, write, digest = original.read, original.write, original.digest


def freeze(prerequisites):
    original.configure(REPO)
    from query_surface.evidence import identity
    from local_uat_storage import check_budgets, require_local_path, GIB, MIB
    from parquet_demand_completion_replay import replay
    for path in (ROOT, RUNTIME, original.HARNESS):
        require_local_path(path, Path.home(), sys.platform)
    assert not ROOT.exists()
    check_budgets(OUT, ROOT, OUT / 'logs', min_free_bytes=12 * GIB,
                  reserve_bytes=64 * MIB, max_workspace_bytes=100 * GIB,
                  max_log_bytes=192 * MIB)
    before, saved = read(PREVIOUS / 'inputs.json'), read(PREVIOUS / 'native-observations.json')
    assert saved['status'] == 'passed' and saved['complete'] and saved['posthash_verified']
    assert len(before['cases']) == len(saved['observations']) == 347
    assert before['repeats'] == 1 and before['surface'] == 'python_sql'
    assert before['memory_bytes'] == 2 << 30 and before['parallelism'] == 2
    assert [x['case_id'] for x in saved['observations']] == [x['case_id'] for x in before['cases']]
    previous_result = replay(lambda path: Path(path).read_bytes(), str(PREVIOUS))
    assert previous_result['complete_comparisons'] == 347 and previous_result['complete_rows'] == 12565
    previous_seconds = math.fsum(x['clocks']['engine_execution_seconds'] for x in saved['observations'])
    assert previous_seconds == 12.144043291
    assert digest(original.__file__) == before['observer_driver']['sha256']
    assert str(original.HARNESS) == before['harness_root']
    inventory = {item['path']: item for item in before['frozen_files']}
    wanted = {path for paths in before['sources'].values() for path in paths}
    wanted.update(case['reference_path'] for case in before['cases'])
    wanted.update(path for path in inventory if Path(path).is_relative_to(original.HARNESS))
    wanted.add(str(original.OBSERVER))
    retained = []
    for path in sorted(wanted):
        observed = identity(Path(path))
        assert observed == inventory[path], path
        retained.append(observed)
    for case in before['cases']:
        assert digest(case['reference_path']) == case['reference_sha256']
    assert all(not (Path(path).parent / '.shardloom').exists()
               for paths in before['sources'].values() for path in paths)
    guard_path = OUT / 'tools/run_guarded_adaptive_evidence.py'
    old_guard = OUT / 'tools/run_guarded.py'
    assert identity(old_guard) == inventory[str(old_guard)]
    assert guard_path.read_bytes() == old_guard.read_bytes().replace(
        b"ROOT = Path('/Users/dylan/.codex/worktrees/native-direct-source-count/shardloom-local-repo')",
        b"ROOT = Path('/Users/dylan/.codex/worktrees/native-adaptive-evidence/shardloom-local-repo')", 1)
    manifest_path = RUNTIME / 'manifest.json'
    manifest = read(manifest_path)
    build_path = OUT / manifest['build_receipt']
    assert digest(build_path) == manifest['build_receipt_sha256']
    build = read(build_path)
    assert build['status'] == 'passed' and build['returncode'] == 0 and build['process_group_drained']
    assert build['cwd'] == str(REPO)
    assert manifest['profile'] == 'release' and manifest['features'] == ['release-user-surfaces']
    for relative, expected in manifest['source_snapshot'].items():
        path = REPO / relative
        assert path.stat().st_size == expected['bytes'] and digest(path) == expected['sha256'], relative
    products = [identity(RUNTIME / name) for name in ('shardloom', '_native.abi3.so')]
    for product in products:
        assert product['sha256'] == manifest['products'][Path(product['path']).name]
    assert prerequisites
    prerequisite_paths = [OUT / name for name in prerequisites]
    for path in prerequisite_paths:
        result = read(path)
        assert result['status'] == 'passed' and result['returncode'] == 0 and result['process_group_drained']
    ROOT.mkdir()
    corpus_path = ROOT / 'corpus.json'
    corpus_path.write_bytes((PREVIOUS / 'corpus.json').read_bytes())
    assert digest(corpus_path) == before['corpus']['sha256']
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    protocol = dict(schema_version='shardloom.adaptive_decision_performance.v1',
        purpose='Inspect performance and runtime evidence of the current partial decision instrumentation.',
        maintainer_instruction='Test what is implemented with one original 347-case pass; compare saved engine baseline.',
        resources=dict(memory_bytes=2 << 30, parallelism=2, adaptive_work_sizing=True),
        policy='Exactly one execution of each original case in original order; other task work idle; no cache manipulation or pacing.',
        full43_executed=False, comparison_engine_invoked=False, old_runtime_executions=0,
        baseline_engine_execution_seconds=previous_seconds,
        retention_decision=read(PREVIOUS / 'protocol.json')['retention_decision'],
        retention_decision_scope='Historical diagnostic fields only; this user-requested partial instrumentation observation is not a ship/drop gate.',
        validation='Complete independent values/schema/order, resource guards, no-fallback, source identities and additive typed decision fields.',
        instrumentation_scope='Current instrumented native owner boundaries; Parquet/ORC region selection and complete item23 coverage are not yet wired.',
        attribution='Baseline predates subsequent runtime fixes. This compares complete runtimes and does not isolate instrumentation overhead or establish repeatability.',
        remaining_acceptance='Full default/native workspace, all public/installed interfaces, full owner mapping and hosted review for this new patch remain separate.',
        runtime_manifest=identity(manifest_path), source_commit=head,
        source_overlay=identity(RUNTIME / 'source-overlay.patch'),
        untracked_source_snapshot='Every added source is hash-bound in manifest/source_snapshot and retained in build receipt source-blobs; overlay patch alone is not the entire dirty source.',
        source_equality='Every frozen Rust/Python/TOML/lock file matches the current patch; documentation is not compiled runtime input.',
        execution_harness='Unchanged count_cohort.observe, original broad_candidate.observe, original frozen worker and BenchmarkGuard.',
        outer_supervision=dict(previous_driver=identity(old_guard), current_driver=identity(guard_path),
            change='Only active source checkout path changed. Same storage/concurrency/deadline/cleanup guards and pre/post full inventories.'),
        prerequisites=[identity(path) for path in prerequisite_paths])
    protocol_path = ROOT / 'protocol.json'
    write(protocol_path, protocol)
    linked = [manifest_path, build_path, RUNTIME / 'source-overlay.patch', corpus_path,
              protocol_path, Path(__file__).resolve(), Path(original.__file__).resolve(),
              PREVIOUS / 'inputs.json', PREVIOUS / 'native-observations.json',
              REPO / 'scripts/parquet_demand_completion_replay.py', guard_path, *prerequisite_paths]
    frozen = retained + products + [identity(path) for path in dict.fromkeys(linked)]
    write(ROOT / 'inputs.json', dict(schema_version=1, status='frozen_before_execution',
        role='decision_instrumentation_observation', dataset=before['dataset'], logical_identity=before['logical_identity'],
        sources=before['sources'], cases=before['cases'], frozen_files=frozen,
        corpus=identity(corpus_path), runtime=products, runtime_manifest=identity(manifest_path),
        baseline_complete_result_replay=dict(status='passed', complete_comparisons=347,
            complete_rows=12565, engine_seconds=previous_seconds, source='saved validated evidence only'),
        complete_input_readbacks=before['complete_input_readbacks'],
        baseline_inputs=identity(PREVIOUS / 'inputs.json'),
        baseline_observations=identity(PREVIOUS / 'native-observations.json'),
        protocol=identity(protocol_path), harness_root=str(original.HARNESS),
        observer_driver=identity(Path(original.__file__).resolve()),
        surface='python_sql', repeats=1, memory_bytes=2 << 30, parallelism=2,
        python=sys.version, platform=platform.platform(), source_revision=head,
        input_format_pair=before['input_format_pair'], execution_order=before['execution_order'],
        cache_policy=before['cache_policy'], comparison_engine_invoked=False))
    print('Frozen 347 original cases for the current decision-evidence patch.', flush=True)


def verify_decisions(summary):
    prefix = 'local_primitive_native_io_decision_'
    families = ['metadata_count', 'region_exclusion', 'existing_order',
                'correlated_membership', 'native_replay', 'representation_retention']
    totals = {family: dict(queries=0, considered=0, admitted=0, declined=0, executed=0) for family in families}
    records = []
    for observation in summary['observations']:
        fields = read(observation['stdout'])['observation']['fields']
        assert fields[prefix + 'schema_version'] == 'shardloom.native_io_decisions.v1'
        assert 'no_inferred_savings_or_rss' in fields[prefix + 'scope']
        selected = {key: value for key, value in fields.items() if key.startswith(prefix)}
        for family in families:
            key = prefix + family + '_'
            if key + 'considered' not in fields:
                continue
            counts = {name: int(fields[key + name]) for name in ('considered', 'admitted', 'declined', 'executed')}
            assert all(str(value) == fields[key + name] and 0 <= value <= (1 << 64) - 1 for name, value in counts.items())
            assert counts['considered'] > 0 and counts['considered'] == counts['admitted'] + counts['declined']
            assert counts['executed'] <= counts['admitted']
            assert bool(fields[key + 'admission_reasons']) == (counts['admitted'] > 0)
            assert bool(fields[key + 'decline_reasons']) == (counts['declined'] > 0)
            for name, value in fields.items():
                if name.startswith(key + 'observed_'):
                    assert value.isdecimal() and int(value) <= (1 << 64) - 1
            totals[family]['queries'] += 1
            for name, value in counts.items():
                totals[family][name] += value
        records.append(dict(case_id=observation['case_id'], fields=selected))
    assert len(records) == 347
    report = dict(schema_version='shardloom.native_decision_cohort_evidence.v1', status='passed',
        query_reports=347, scope='Current instrumented boundaries only; omitted capabilities are unobserved.',
        totals=totals, observations=records)
    write(ROOT / 'decision-evidence.json', report)
    return report


def verify():
    original.configure(REPO)
    from query_surface.evidence import identity
    from parquet_demand_completion_replay import replay
    frozen = read(ROOT / 'inputs.json')
    assert all(identity(Path(row['path'])) == row for row in frozen['frozen_files'])
    result = replay(lambda path: Path(path).read_bytes(), str(ROOT))
    write(ROOT / 'complete-result-validation.json', result)
    decisions = verify_decisions(read(ROOT / 'native-observations.json'))
    before, after = result['baseline_engine_seconds'], result['candidate_engine_seconds']
    report = dict(schema_version='shardloom.adaptive_decision_performance_result.v1', status='passed',
        complete=True, queries=347, executions_per_query=1, complete_rows=result['complete_rows'],
        baseline_engine_execution_seconds=before, engine_execution_seconds=after,
        change_engine_seconds=after-before, change_fraction=after/before-1,
        runtime_manifest=frozen['runtime_manifest'], source_revision=frozen['source_revision'],
        protocol=frozen['protocol'], complete_result_validation=identity(ROOT / 'complete-result-validation.json'),
        decision_evidence=identity(ROOT / 'decision-evidence.json'), decision_totals=decisions['totals'],
        old_runtime_executions=0, full43_executed=False, resource_sweep=False, comparison_engine_invoked=False,
        limits='Single complete-runtime observation against the saved earlier build; incomplete owner coverage; no isolated instrumentation-overhead or repeatability claim.')
    write(ROOT / 'performance.json', report)
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=('freeze', 'native', 'verify'))
    parser.add_argument('--prerequisite', action='append', default=[])
    args = parser.parse_args()
    if args.stage == 'freeze':
        freeze(args.prerequisite)
    elif args.stage == 'native':
        original.observe(ROOT)
    else:
        verify()
