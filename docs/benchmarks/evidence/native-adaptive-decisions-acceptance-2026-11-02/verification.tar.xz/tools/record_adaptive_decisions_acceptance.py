"""Retain exact local acceptance receipts, failures and source overlays."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path('/Users/dylan/.codex/worktrees/native-adaptive-evidence/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'docs/benchmarks/evidence/native-adaptive-decisions-acceptance-2026-11-02'
RUNTIME = OUT / 'io-runtime-adaptive-decisions-r2'
WHEEL = OUT / 'installed-wheel-adaptive-decisions-r1'


def identity(data):
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def read_json(path):
    return json.loads(path.read_text())


assert not DEST.exists()
runtime = read_json(RUNTIME / 'manifest.json')
assert runtime['source_revision'] == subprocess.check_output(
    ['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
for name, entry in runtime['source_snapshot'].items():
    assert identity((ROOT / name).read_bytes()) == entry, name
for name, entry in runtime['files'].items():
    assert identity((RUNTIME / name).read_bytes()) == entry, name
wheel = read_json(WHEEL / 'report.json')
assert wheel['status'] == 'passed' and wheel['uninstall_status'] == 'passed'
assert wheel['integration'] == dict(tests=292, failures=0, errors=0, skipped=0, status='passed')
assert wheel['stage']['native_library_sha256'] == runtime['files']['_native.abi3.so']['sha256']
assert wheel['stage']['cli_sha256'] == runtime['files']['shardloom']['sha256']
members = {}
receipts = []
blobs = set()


def add(path, name=None):
    assert path.is_file() and not path.is_symlink(), path
    name = name or str(path.relative_to(OUT))
    assert name not in members and not name.startswith('/') and '..' not in Path(name).parts
    members[name] = path.read_bytes()


for number in range(563, 590):
    paths = list(OUT.glob(f'io{number}-*.json'))
    assert len(paths) == 1, number
    path = paths[0]
    receipt = read_json(path)
    assert receipt['status'] in {'passed', 'failed'}
    log = path.with_suffix('.log')
    assert identity(log.read_bytes())['sha256'] == receipt['log_sha256']
    if number >= 581:
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained']
    if 581 <= number <= 586:
        for name, entry in receipt['changed_source_inventory'].items():
            if name.endswith(('.rs', '.toml', '.lock')):
                assert identity((ROOT / name).read_bytes()) == entry, (path.name, name)
    add(path)
    add(log)
    row = dict(name=path.name, status=receipt['status'], returncode=receipt['returncode'],
               receipt=identity(path.read_bytes()), log=identity(log.read_bytes()))
    results = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',
                         log.read_text())
    if results:
        row['rust_results'] = dict(binaries=len(results),
            passed=sum(int(item[1]) for item in results),
            failed=sum(int(item[2]) for item in results),
            ignored=sum(int(item[3]) for item in results))
    receipts.append(row)
    blobs.add(receipt['driver_sha256'])
    blobs.update(entry['sha256'] for entry in receipt['changed_source_inventory'].values()
                 if 'sha256' in entry)

for digest in sorted(blobs):
    path = OUT / 'source-blobs' / digest
    assert identity(path.read_bytes())['sha256'] == digest
    add(path)
for path in sorted(WHEEL.iterdir()):
    if path.suffix in {'.log', '.json'}:
        add(path)
for name in ('io-runtime-adaptive-decisions-r1', 'io-runtime-adaptive-decisions-r2'):
    for filename in ('manifest.json', 'source-overlay.patch'):
        add(OUT / name / filename)
for name in ('performance.json', 'decision-evidence.json', 'complete-result-validation.json',
             'inputs.json', 'protocol.json'):
    add(OUT / 'broad-adaptive-decisions-r1' / name)
for name in ('run_guarded_adaptive_evidence.py', 'freeze_adaptive_evidence_runtime.py',
             'completed_decision_controls.py', 'adaptive_decisions_smoke.py',
             'adaptive_decisions_benchmark.py', Path(__file__).name):
    add(OUT / 'tools' / name)

assert sum(map(len, members.values())) < 128 << 20
DEST.mkdir()
archive = DEST / 'verification.tar.xz'
with tarfile.open(archive, 'x:xz', preset=6) as bundle:
    for name, data in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        bundle.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:xz') as bundle:
    assert {item.name for item in bundle.getmembers()} == set(members)
    for item in bundle.getmembers():
        assert item.isfile() and bundle.extractfile(item).read() == members[item.name]
assert archive.stat().st_size < 8 << 20
report = dict(schema_version='shardloom.native_adaptive_decisions_acceptance.v1',
    status='local_acceptance_passed', source_base=runtime['source_revision'],
    code_snapshot=runtime['source_snapshot'], runtime_files=runtime['files'],
    installed_wheel=wheel['integrity'], installed_integration=wheel['integration'],
    installed_load=wheel['installed_load'], uninstall_status=wheel['uninstall_status'],
    formatting=dict(command=['cargo', 'fmt', '--all', '--', '--check'], status='passed',
                    scope='unchanged Rust source checked before frozen release build'),
    final_receipts=[row['name'] for row in receipts if int(row['name'][2:5]) >= 581],
    all_receipts=receipts,
    public_matrix=dict(input_formats=['vortex', 'parquet', 'arrow-ipc', 'avro', 'orc',
                                    'csv', 'tsv', 'json', 'jsonl'],
        output_formats=['vortex', 'parquet', 'arrow-ipc', 'avro', 'orc', 'csv', 'json', 'jsonl'],
        surfaces=['dataframe', 'typed_relation', 'python_sql', 'embedded_workflow', 'cli_sql'],
        grants=[dict(memory_bytes=16 << 20, max_parallelism=1),
                dict(memory_bytes=128 << 20, max_parallelism=2)],
        single_and_mixed_source_collects=180, complete_writes_and_readbacks=80,
        ordered_cases=480, orc_count_pruning_cases=30,
        test='python/tests/native_adaptive_resource_cases.py'),
    limits=['observed owner work only; unavailable quantities omitted',
            'output replay and source replay have disjoint summaries',
            'no inferred savings, complete allocator coverage, or RSS guarantee',
            'current host wheel proof; other platforms require hosted checks',
            'historical 347 checkpoint is partial wiring and cumulative build comparison',
            'no benchmark execution for the final runtime',
            'broader table formats and combined docs/site closeout remain separate'],
    hosted_acceptance='pending',
    archive=dict(path=archive.name, **identity(archive.read_bytes()),
                 members=len(members), unpacked_bytes=sum(map(len, members.values())),
                 complete_byte_readback='passed',
                 member_identities={name: identity(data) for name, data in sorted(members.items())}))
(DEST / 'acceptance.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(status=report['status'], destination=str(DEST),
    receipts=len(receipts), members=len(members), archive_bytes=archive.stat().st_size)))
