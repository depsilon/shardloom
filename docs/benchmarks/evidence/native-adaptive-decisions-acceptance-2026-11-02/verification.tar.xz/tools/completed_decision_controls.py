"""Focused correctness controls for completed native decision evidence."""
import json
import re
import subprocess
import sys

COMMON = ["cargo", "test", "--locked", "--offline", "--profile", "ci-native"]
jobs = [
    ("core", COMMON + ["-p", "shardloom-core", "--lib", "native_decision"]),
    ("serializer", COMMON + ["-p", "shardloom-cli", "--lib", "native_decision"]),
]
for name in [
    "source_demand_tests",
    "batch_input_tests",
    "resident_count_scan_preserves_exact_count_pruning_and_native_certificate",
    "local_encoded_count_native_io_certificate",
    "count_all_answers_from_vortex_metadata_without_scan",
    "partitioned_local_primitive_counts_sources_without_fallback",
    "lazy_layout_metadata_tests",
]:
    jobs.append((name, COMMON + ["-p", "shardloom-vortex", "--lib",
        "--features", "release-user-surfaces", name]))
jobs.append(("public_fanout", COMMON + ["-p", "shardloom-cli", "--test",
    "public_workflow_route", "--features", "release-user-surfaces",
    "public_primitive_fanout_"]))
records = []
for name, command in jobs:
    result = subprocess.run(command + ["--", "--test-threads=2"],
        capture_output=True, text=True)
    print(result.stdout, flush=True)
    print(result.stderr, flush=True)
    matches = re.findall(r"test result: ok\. ([0-9]+) passed", result.stdout)
    count = sum(map(int, matches))
    records.append(dict(name=name, command=command, returncode=result.returncode,
        passed=count))
    print(json.dumps(records[-1]), flush=True)
    if result.returncode != 0 or count == 0:
        raise SystemExit(result.returncode or 1)
print(json.dumps(dict(status="passed", controls=records)), flush=True)
