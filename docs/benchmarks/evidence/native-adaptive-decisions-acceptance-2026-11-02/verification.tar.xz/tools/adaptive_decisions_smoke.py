"""Check current decision fields on tiny inputs through all five public surfaces."""
import argparse
import importlib.util
import json
from pathlib import Path
import sys

REPO = Path('/Users/dylan/.codex/worktrees/native-adaptive-evidence/shardloom-local-repo')
OUT = Path(__file__).resolve().parents[1]
RUNTIME = OUT / 'io-runtime-adaptive-decisions-r1'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--name', required=True)
args = parser.parse_args()
assert args.name.replace('-', '').isalnum()
ROOT = OUT / args.name
sys.path[:0] = [str(REPO / 'python/src')]
import shardloom as sl
import pyarrow as pa
import pyarrow.parquet as pq

spec = importlib.util.spec_from_file_location('shardloom._native', RUNTIME / '_native.abi3.so')
native = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = native
spec.loader.exec_module(native)

ROOT.mkdir()
(ROOT / 'driver.py').write_bytes(Path(__file__).read_bytes())
source = ROOT / 'input.parquet'
expected = [{'k': value, 'payload': f'value-{value}'} for value in range(5)]
pq.write_table(pa.Table.from_pylist(expected), source, row_group_size=2)
prefix = 'local_primitive_native_io_decision_'
records = []
for surface in ('python_sql', 'typed_relation', 'embedded_workflow', 'dataframe', 'cli_sql'):
    for kind in ('count', 'order'):
        sql = (f"SELECT COUNT(*) AS n FROM '{source}'" if kind == 'count'
               else f"SELECT k,payload FROM '{source}' ORDER BY k")
        client = session = plan = result = None
        try:
            if surface in ('dataframe', 'cli_sql'):
                client = sl.ShardLoomClient(transport='subprocess' if surface == 'cli_sql' else 'native',
                    binary=str(RUNTIME / 'shardloom') if surface == 'cli_sql' else None,
                    use_persistent_worker=False, memory_bytes=128 << 20, max_parallelism=2, timeout=60)
                if surface == 'cli_sql':
                    plan = sl.sql(sql, client=client)
                else:
                    frame = sl.read_parquet(source, client=client)
                    plan = frame.agg('COUNT(*) AS n') if kind == 'count' else frame.sort('k')
                result = plan.collect(check=True)
                fields = dict(result.envelope.field_map)
                rows = result.to_rows()
            else:
                session = native.Session(native.ExecutionResources(128 << 20, 2))
                if surface == 'python_sql':
                    plan = session.sql(sql)
                elif surface == 'typed_relation':
                    relation = native.Relation.scan(str(source))
                    relation = (relation.aggregate([], [('count', None, 'n')]) if kind == 'count'
                                else relation.sort([('k', False, None)]))
                    plan = session.plan(relation)
                else:
                    plan = session.workflow(['sql', '--sql', sql, '--request', 'collect', '--bounded', 'true',
                        '--memory-bytes', str(128 << 20), '--max-parallelism', '2'])
                result = plan.collect(timeout=60)
                fields = dict(result.report)
                rows, _ = result.row_export(temporal_objects=False)
            rows = list(rows)
            assert rows == ([{'n': 5}] if kind == 'count' else expected), (surface, kind, rows)
            assert fields['fallback_attempted'] == fields['external_engine_invoked'] == 'false'
            assert fields[prefix + 'schema_version'] == 'shardloom.native_io_decisions.v1'
            family = 'metadata_count' if kind == 'count' else 'existing_order'
            key = prefix + family + '_'
            assert int(fields[key + 'executed']) > 0, (surface, kind, fields)
            assert int(fields[key + 'considered']) == int(fields[key + 'admitted']) + int(fields[key + 'declined'])
            assert int(fields[key + 'executed']) <= int(fields[key + 'admitted'])
            assert ('exact_held_metadata' if kind == 'count' else 'validated_existing_order') in fields[key + 'admission_reasons'].split(',')
            records.append(dict(surface=surface, case=kind, rows=rows,
                fields={name: value for name, value in fields.items() if name.startswith(prefix)}))
        finally:
            plan = result = None
            if session is not None:
                session.close()
            if client is not None:
                client.close()
assert len(records) == 10
assert not (ROOT / '.shardloom').exists()
with (ROOT / 'report.json').open('x') as stream:
    json.dump(dict(status='passed', cases=10, surfaces=5, observations=records,
        scope='Tiny public report smoke; not the complete public or installed-package matrix.'), stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(status='passed', cases=10, surfaces=5, report=str(ROOT / 'report.json'))))
