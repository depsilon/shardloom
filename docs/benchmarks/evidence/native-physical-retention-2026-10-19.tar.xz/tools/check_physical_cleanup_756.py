"""Run the new retention safety checks and each original integration failure."""
from pathlib import Path
import hashlib
import json
import subprocess

out = Path(__file__).resolve().parent
identity = json.loads((out / 'physical-retention-cleanup-build-identity-756.json').read_text())
binary = Path(identity['artifact'])
assert hashlib.sha256(binary.read_bytes()).hexdigest() == identity['artifact_sha256']
original = (out / 'physical-retention-integration-all-native-755.log').read_text()
failures = [line.strip() for line in original.rsplit('failures:', 1)[1].splitlines()
            if line.startswith('    ')]
assert len(failures) == len(set(failures)) == 25
subprocess.run([str(binary), 'physical_retention_', '--test-threads=1'], check=True)
for name in failures:
    subprocess.run([str(binary), '--exact', name, '--test-threads=1'], check=True)
print(json.dumps({'new_retention_checks_passed': True, 'original_failures_checked': len(failures)}))
