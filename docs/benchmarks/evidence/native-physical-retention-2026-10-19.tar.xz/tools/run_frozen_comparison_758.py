"""Run a predeclared serial cohort pair without inspecting comparative costs."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
PYTHON = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


admission_path = Path(sys.argv[1]).resolve()
assert admission_path.parent == OUT
admission_sha = sha(admission_path)
admission = json.loads(admission_path.read_text())
assert [job['cohort'] for job in admission['jobs']] == ['a', 'b']


def verify():
    assert sha(admission_path) == admission_sha
    for item in admission['inputs']:
        assert sha(item['path']) == item['sha256'], item['path']
    for item in admission['sources']:
        assert sha(ROOT / item['path']) == item['sha256'], item['path']


for job in admission['jobs']:
    verify()
    command = [PYTHON, str(OUT / 'run_guarded_observed_757.py'),
               '--name', job['name'], '--timeout', str(job['timeout']), '--', *job['command']]
    run = subprocess.run(command, cwd=ROOT, text=True, stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT, check=False)
    driver_log = OUT / (job['name'] + '-driver.log')
    with driver_log.open('x') as stream:
        stream.write(run.stdout)
    assert run.returncode == 0, f"{job['cohort']} failed; inspect retained receipt and log"
    receipt = json.loads((OUT / (job['name'] + '.json')).read_text())
    assert receipt['status'] == 'passed' and receipt['process_group_drained']
    assert receipt['direct_child_reaped'] and receipt['returncode'] == 0
    assert not receipt['timed_out'] and receipt['interrupted_signal'] is None
    verify()
    print(json.dumps({'cohort': job['cohort'], 'status': 'passed',
                      'process_group_drained': True}), flush=True)
print(json.dumps({'both_cohorts_complete': True, 'comparative_analysis_permitted': True}), flush=True)
