"""Finish the original failure inventory after its first assertion failure."""
from pathlib import Path
import hashlib
import json
import subprocess

out = Path(__file__).resolve().parent
identity = json.loads((out / 'physical-retention-cleanup-build-identity-756.json').read_text())
binary = Path(identity['artifact'])
assert hashlib.sha256(binary.read_bytes()).hexdigest() == identity['artifact_sha256']
original = (out / 'physical-retention-integration-all-native-755.log').read_text()
failures = [line.strip() for line in original.rsplit('failures:', 1)[1].splitlines()
            if line.startswith('    ')]
assert len(failures) == len(set(failures)) == 25
first = next(name for name in failures if name.endswith('streaming_join_pressure_denies_resident_and_completes_spill_under_the_same_grant'))
remaining = failures[failures.index(first) + 1:]
failed = []
for name in remaining:
    run = subprocess.run([str(binary), '--exact', name, '--test-threads=1'])
    if run.returncode:
        failed.append(name)
print(json.dumps({'checked': len(remaining), 'failed': failed}))
assert not failed
