"""Run both frozen cohorts serially; expose completion only until both finish."""
from pathlib import Path
import hashlib
import json
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
PYTHON = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
SELECTOR = 'resident_session::physical_reconstruction_tests::retention::workflow::physical_retention_complete_workflow_comparison'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def check_inputs():
    ready = json.loads((OUT / 'physical-retention-timing-admission-753.json').read_text())
    for item in ready['inputs']:
        assert sha(Path(item['path'])) == item['sha256'], item['path']
    freeze = json.loads((OUT / 'physical-retention-final-753-source-freeze.json').read_text())
    for item in freeze['sources']:
        assert sha(ROOT / item['path']) == item['sha256'], item['path']
    return ready

for cohort in ('a', 'b'):
    ready = check_inputs()
    name = f'physical-retention-cohort-{cohort}-753'
    command = [PYTHON, str(OUT / 'run_guarded.py'), '--name', name, '--timeout', '2400', '--',
        '/usr/bin/env', 'SHARDLOOM_PHYSICAL_RETENTION=frozen-752-v1', f'SHARDLOOM_PHYSICAL_COHORT={cohort}',
        f'SHARDLOOM_PHYSICAL_ROOT={OUT}/physical-retention-fixtures-{cohort}-753',
        ready['artifact'], '--exact', SELECTOR, '--ignored', '--nocapture', '--test-threads=1']
    run = subprocess.run(command, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (OUT / f'{name}-driver.log').write_text(run.stdout)
    assert run.returncode == 0, f'{cohort} failed; inspect retained receipt and failure log'
    receipt = json.loads((OUT / (name + '.json')).read_text())
    assert receipt['status'] == 'passed' and receipt['process_group_drained']
    check_inputs()
    print(json.dumps({'cohort': cohort, 'status': 'passed', 'process_group_drained': True}), flush=True)
print(json.dumps({'both_cohorts_complete': True, 'comparative_analysis_permitted': True}), flush=True)
