"""Replay frozen physical-retention-752-v1 without selecting cells or thresholds."""
from __future__ import annotations

import argparse
import copy
import hashlib
import itertools
import json
from pathlib import Path
from statistics import median
import unittest

FIELDS = ('rows', 'columns', 'encoding', 'layout', 'projection', 'consumer')
BASE_CELLS = list(itertools.product(
    (4096, 32768), (3, 12), ('canonical', 'zstd_dictionary'),
    ('whole_struct_flat', 'columnar_table_flat'), ('all', 'one_i64'),
    ('native_canonical_2048', 'json_2048', 'json_64')))
MATRIX = [(cell, calls) for cell in BASE_CELLS for calls in (1, 8)]
CHURN = list(itertools.product(
    (4096,), (3, 12), ('canonical',), ('whole_struct_flat', 'columnar_table_flat'),
    ('all',), ('native_canonical_2048', 'json_64')))
ROLES = ('none', 'one', 'lru16')
WARMUP = BASE_CELLS[0]
GRANT = 256 << 20
PROTOCOL_SHA = '04fd8a38c2e5e71a7bbc96cb0066951dad9fc4e109c730dc8185341a580b524c'
CLARIFICATION_SHA = '3ecada9bf5ef174f7b65b91f405fd4283cbbc9c9b270a90163e89284d300de1b'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse(log, marker):
    return [json.loads(line.split(marker, 1)[1]) for line in log.read_text().splitlines() if marker in line]


def key(category, cell, calls):
    return (category,) + cell + (calls,)


MATRIX_KEYS = [key('matrix', cell, calls) for cell, calls in MATRIX]
CONTROL_KEYS = [key('matrix', cell, 1) for cell in BASE_CELLS] + [key('churn', cell, 8) for cell in CHURN]
COMPLEXITY_KEYS = [key('matrix', cell, calls) for cell, calls in MATRIX
                   if cell[1] == 12 and cell[3] == 'columnar_table_flat' and calls == 8]
ALL_KEYS = MATRIX_KEYS + [key('churn', cell, 8) for cell in CHURN]


def fails_control(baseline, candidate):
    return candidate > baseline * 1.05 and candidate - baseline > 1_000_000


def decide(cohorts):
    """All medians are complete workflow costs, never per-operation shortcuts."""
    decisions = {}
    for role in ('one', 'lru16'):
        details = []
        common = None
        for cohort in cohorts:
            times = cohort['medians']
            baseline = sum(times['none'][cell] for cell in MATRIX_KEYS)
            candidate = sum(times[role][cell] for cell in MATRIX_KEYS)
            reduction = 1 - candidate / baseline
            material = {cell for cell in MATRIX_KEYS
                        if cell[3] == 'canonical' and cell[-1] == 8
                        and times[role][cell] <= times['none'][cell] * .90
                        and cohort['activated'][role][cell]}
            common = material if common is None else common & material
            regressions = [cell for cell in CONTROL_KEYS
                           if fails_control(times['none'][cell], times[role][cell])]
            details.append({'cohort': cohort['cohort'], 'baseline_sum_median_nanoseconds': baseline,
                            'candidate_sum_median_nanoseconds': candidate,
                            'reduction_fraction': reduction, 'control_regressions': regressions})
        passed = (len(common) >= 2 and all(row['reduction_fraction'] >= .03
                  and not row['control_regressions'] for row in details))
        decisions[role] = {'passes_primary_gates': passed, 'common_material_cells': sorted(common),
                           'cohorts': details}
    complexity = []
    for cohort in cohorts:
        times = cohort['medians']
        one = sum(times['one'][cell] for cell in COMPLEXITY_KEYS)
        lru = sum(times['lru16'][cell] for cell in COMPLEXITY_KEYS)
        regression = [cell for cell in CONTROL_KEYS if fails_control(times['one'][cell], times['lru16'][cell])]
        complexity.append({'cohort': cohort['cohort'], 'one_sum_median_nanoseconds': one,
                           'lru16_sum_median_nanoseconds': lru, 'reduction_fraction': 1 - lru / one,
                           'control_regressions': regression})
    admitted_complexity = all(row['reduction_fraction'] >= .02 and not row['control_regressions']
                             for row in complexity)
    selected = ('lru16' if decisions['lru16']['passes_primary_gates'] and admitted_complexity
                else 'one' if decisions['one']['passes_primary_gates'] else None)
    return {'policies': decisions, 'lru16_complexity': complexity,
            'lru16_passes_complexity_gate': admitted_complexity,
            'selected_policy_for_further_acceptance': selected}


def expected_keys():
    return {(kind,) + cell + (calls, sample, role)
            for kind, cells, calls_set, samples in (
                ('matrix', BASE_CELLS, (1, 8), (1, 2, 3)),
                ('churn', CHURN, (8,), (1, 2, 3)),
                ('warmup', (WARMUP,), (1,), (0,)))
            for cell in cells for calls in calls_set for sample in samples for role in ROLES}


def validate_records(records, physical, logical, cohort):
    groups = {}
    sequence = []
    total_operations = 0
    for record in records:
        cell = tuple(record[field] for field in FIELDS)
        category, calls, sample, role = (record[field] for field in ('category', 'calls', 'sample', 'role'))
        identity = (category,) + cell + (calls, sample, role)
        assert identity not in groups, ('duplicate', identity)
        groups[identity] = record
        sequence.append(identity)
        assert record['cohort'] == cohort and record['warmup'] == (category == 'warmup')
        assert record['profiled'] is False
        assert record['grant_bytes'] == GRANT
        assert (record['physical_bytes'], record['physical_sha256']) == physical[cell[:4]]
        assert (record['expected_values_sha256'], record['schema_sha256']) == logical[cell[:2] + (cell[4],)]
        observation = record['workflow']
        operations = observation['operations']
        assert len(operations) == calls
        total_operations += calls
        assert observation['final_reserved_bytes'] == 0
        assert observation['final_entries'] == 0
        assert observation['source_opens'] == (calls if category == 'churn' else 1)
        assert observation['completed_executions'] == calls
        assert observation['denied_reservations'] == 0
        assert 0 <= observation['peak_reserved_bytes'] <= GRANT
        total = observation['owner_construct_nanoseconds'] + observation['owner_drop_nanoseconds']
        preparation = observation['preparation_nanoseconds']
        destruction = observation['plan_drop_nanoseconds']
        assert len(preparation) == len(destruction) == (calls if category == 'churn' else 1)
        total += sum(preparation) + sum(destruction)
        assert len(observation['entries_after_source_drop']) == len(destruction)
        assert all(value == 0 for value in observation['entries_after_source_drop'])
        assert len(observation['retention_after_source_drop']) == len(destruction)
        assert all(value == 0 for value in observation['retention_after_source_drop'])
        caches = observation['cache_after_operations']
        assert len(caches) == calls
        last_misses = 0
        for index, (operation, cache) in enumerate(zip(operations, caches)):
            assert operation['all_values_types_nulls_order_verified'] is True
            assert operation['fallback_attempted'] is False
            assert operation['denied_reservations'] == 0
            assert 0 <= operation['reserved_before'] <= GRANT
            assert operation['reserved_after'] <= operation['reserved_with_output'] <= GRANT
            assert operation['peak_reserved_bytes'] <= GRANT
            assert type(operation['native_execution_nanoseconds']) is int and operation['native_execution_nanoseconds'] > 0
            assert 'profile' not in operation
            total += operation['native_execution_nanoseconds'] + operation['output_release_nanoseconds']
            if role == 'none':
                assert cache is None and operation['reserved_before'] == operation['reserved_after']
                continue
            assert cache is not None
            assert cache['entries'] <= (1 if role == 'one' else 16)
            assert cache['retention_reserved'] <= cache['retention_limit'] == min(GRANT // 8, 64 << 20)
            assert cache['retention_peak'] <= cache['retention_limit']
            counts = cache['counters']
            assert all(type(value) is int and value >= 0 for value in counts.values())
            assert counts['invalidations'] == 0
            if category == 'churn' or index == 0:
                assert counts['misses'] > last_misses, 'new source must start cold'
            last_misses = counts['misses']
            no_activation = cell[2] == 'zstd_dictionary' or (cell[3] == 'columnar_table_flat' and cell[4] == 'one_i64')
            if no_activation:
                assert counts['admissions'] == counts['hits'] == counts['copied_bytes'] == 0
                assert cache['retention_reserved'] == 0
        assert total == observation['complete_workflow_nanoseconds'] and total > 0
    assert set(groups) == expected_keys(), ('coverage', len(groups), len(expected_keys()))
    assert len(records) == 1803 and total_operations == 8355
    # Each adjacent triplet is one frozen scenario, with reversed/rotated roles.
    assert len(sequence) % 3 == 0
    for offset in range(0, len(sequence), 3):
        triple = sequence[offset:offset+3]
        assert len({item[:-1] for item in triple}) == 1
        assert {item[-1] for item in triple} == set(ROLES)
        if triple[0][0] == 'warmup':
            expected_order = ROLES
        else:
            scenario = key(triple[0][0], triple[0][1:7], triple[0][7])
            ordinal = ALL_KEYS.index(scenario)
            rotation = (ordinal + triple[0][-2]) % 3
            expected_order = ROLES[rotation:] + ROLES[:rotation]
            if cohort == 'b':
                expected_order = expected_order[::-1]
        assert tuple(item[-1] for item in triple) == expected_order
    medians = {role: {} for role in ROLES}
    activated = {role: {} for role in ROLES}
    scores = []
    for cell in ALL_KEYS:
        raw = {}
        for role in ROLES:
            cases = [groups[cell + (sample, role)]['workflow'] for sample in (1, 2, 3)]
            costs = [case['complete_workflow_nanoseconds'] for case in cases]
            raw[role] = costs
            medians[role][cell] = median(costs)
            activated[role][cell] = all(any(cache and cache['counters']['hits'] > 0
                                           for cache in case['cache_after_operations']) for case in cases)
        scores.append({'cell': cell, 'complete_workflow_nanoseconds': raw,
                       'median_nanoseconds': {role: medians[role][cell] for role in ROLES},
                       'activated_all_samples': {role: activated[role][cell] for role in ROLES}})
    return {'cohort': cohort, 'medians': medians, 'activated': activated, 'scores': scores,
            'records': len(records), 'operations': total_operations}


def analyze(root):
    assert digest(root / 'physical-retention-protocol-752.json') == PROTOCOL_SHA
    assert digest(root / 'physical-retention-protocol-clarification-752.json') == CLARIFICATION_SHA
    prior = parse(root / 'physical-attribution-cohort-a-751.log', 'PHYSICAL_RECONSTRUCTION ')
    physical, logical = {}, {}
    for record in prior:
        cell = tuple(record[field] for field in FIELDS)
        p = (record['physical_bytes'], record['physical_sha256'])
        l = (record['expected_values_sha256'], record['schema_sha256'])
        assert physical.setdefault(cell[:4], p) == p
        assert logical.setdefault(cell[:2] + (cell[4],), l) == l
    assert len(physical) == 16 and len(logical) == 8
    cohorts = []
    for cohort in ('a', 'b'):
        stem = f'physical-retention-cohort-{cohort}-753'
        log = root / (stem + '.log')
        receipt_path = root / (stem + '.json')
        receipt = json.loads(receipt_path.read_text())
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert not receipt['timed_out'] and receipt['interrupted_signal'] is None
        assert receipt['log_sha256'] == digest(log)
        assert 'test result: ok. 1 passed;' in log.read_text()
        result = validate_records(parse(log, 'PHYSICAL_RETENTION_WORKFLOW '), physical, logical, cohort)
        result['log_sha256'] = digest(log)
        result['receipt_sha256'] = digest(receipt_path)
        cohorts.append(result)
    return {'schema_version': 'shardloom.physical_retention_analysis.v1',
            'protocol_sha256': PROTOCOL_SHA, 'clarification_sha256': CLARIFICATION_SHA,
            'analysis_sha256': digest(Path(__file__)), 'correctness_and_coverage': 'passed',
            'prior_physical_and_logical_identities_identical': True, 'decision': decide(cohorts),
            'cohorts': [{k: v for k, v in cohort.items() if k not in ('medians', 'activated')} for cohort in cohorts],
            'scope': 'Finite native complete-workflow experiment; no Full43 or public acceptance claim.'}


class GateTests(unittest.TestCase):
    def records(self):
        physical = {cell[:4]: (1234, '0'*64) for cell in BASE_CELLS}
        logical = {cell[:2] + (cell[4],): ('1'*64, '2'*64) for cell in BASE_CELLS}
        result = []
        for cell in [key('warmup', WARMUP, 1)] + ALL_KEYS:
            category, shape, calls = cell[0], cell[1:7], cell[7]
            samples = (0,) if category == 'warmup' else (1, 2, 3)
            for sample in samples:
                rotation = 0 if category == 'warmup' else (ALL_KEYS.index(cell) + sample) % 3
                for role in ROLES[rotation:] + ROLES[:rotation]:
                    count = calls if category == 'churn' else 1
                    operation = {'all_values_types_nulls_order_verified': True, 'fallback_attempted': False,
                                 'denied_reservations': 0, 'reserved_before': 0, 'reserved_after': 0,
                                 'reserved_with_output': 1, 'peak_reserved_bytes': 1,
                                 'native_execution_nanoseconds': 100, 'validation_nanoseconds': 90,
                                 'output_release_nanoseconds': 10}
                    caches = []
                    for index in range(calls):
                        caches.append(None if role == 'none' else {'entries': 0, 'ready': 0,
                            'retention_reserved': 0, 'retention_limit': GRANT // 8, 'retention_peak': 0,
                            'table_bytes': 0, 'counters': {'misses': index+1, 'invalidations': 0,
                                'admissions': 0, 'hits': 0, 'copied_bytes': 0}})
                    observation = {'operations': [copy.deepcopy(operation) for _ in range(calls)],
                        'cache_after_operations': caches, 'final_reserved_bytes': 0, 'final_entries': 0,
                        'source_opens': count, 'completed_executions': calls, 'denied_reservations': 0,
                        'peak_reserved_bytes': 1, 'owner_construct_nanoseconds': 11, 'owner_drop_nanoseconds': 12,
                        'preparation_nanoseconds': [13]*count, 'plan_drop_nanoseconds': [14]*count,
                        'entries_after_source_drop': [0]*count, 'retention_after_source_drop': [0]*count,
                        'complete_workflow_nanoseconds': 23 + 27*count + 110*calls}
                    result.append(dict(zip(FIELDS, shape), category=category, calls=calls, sample=sample,
                        role=role, cohort='a', warmup=category == 'warmup', profiled=False, grant_bytes=GRANT,
                        physical_bytes=1234, physical_sha256='0'*64, expected_values_sha256='1'*64,
                        schema_sha256='2'*64, workflow=observation))
        return result, physical, logical

    def cohorts(self, one=.94, lru=.94):
        return [{'cohort': c, 'medians': {r: {key: int(100_000_000 * scale) for key in ALL_KEYS}
                 for r, scale in (('none', 1), ('one', one), ('lru16', lru))},
                 'activated': {r: {key: r != 'none' for key in ALL_KEYS} for r in ROLES}}
                for c in ('a', 'b')]

    def test_full_shape(self):
        self.assertEqual((len(BASE_CELLS), len(MATRIX_KEYS), len(CHURN), len(COMPLEXITY_KEYS), len(expected_keys())), (96, 192, 8, 24, 1803))

    def test_primary_requires_material_and_aggregate_in_both_cohorts(self):
        self.assertIsNone(decide(self.cohorts())['selected_policy_for_further_acceptance'])
        rows = self.cohorts(.85, .85)
        self.assertEqual(decide(rows)['selected_policy_for_further_acceptance'], 'one')
        rows[1]['medians']['one'] = dict(rows[1]['medians']['none'])
        rows[1]['medians']['lru16'] = dict(rows[1]['medians']['none'])
        self.assertIsNone(decide(rows)['selected_policy_for_further_acceptance'])

    def test_complexity_is_measured_and_controls_apply_against_one(self):
        rows = self.cohorts(.85, .80)
        self.assertEqual(decide(rows)['selected_policy_for_further_acceptance'], 'lru16')
        rows[0]['medians']['lru16'][CONTROL_KEYS[0]] = 95_000_000
        self.assertEqual(decide(rows)['selected_policy_for_further_acceptance'], 'one')

    def test_lru_cannot_win_if_only_primary_passes_without_complexity(self):
        rows = self.cohorts(.94, .85)
        for cohort in rows:
            for cell in COMPLEXITY_KEYS:
                cohort['medians']['lru16'][cell] = cohort['medians']['one'][cell]
        self.assertIsNone(decide(rows)['selected_policy_for_further_acceptance'])

    def test_controls_need_both_strict_bounds(self):
        self.assertFalse(fails_control(100_000_000, 105_000_000))
        self.assertFalse(fails_control(1_000_000, 2_000_000))
        self.assertTrue(fails_control(1_000_000, 2_000_001))
        self.assertFalse(fails_control(100_000_000, 101_000_001))

    def test_source_churn_failure_blocks_acceptance(self):
        rows = self.cohorts(.85, .80)
        for role in ('one', 'lru16'):
            rows[1]['medians'][role][CONTROL_KEYS[-1]] = 106_000_000
        self.assertIsNone(decide(rows)['selected_policy_for_further_acceptance'])

    def test_material_cells_must_match_across_cohorts_and_activate(self):
        rows = self.cohorts(.85, .80)
        candidates = [k for k in MATRIX_KEYS if k[3] == 'canonical' and k[-1] == 8]
        for role in ('one', 'lru16'):
            for index, cohort in enumerate(rows):
                for cell in MATRIX_KEYS:
                    cohort['activated'][role][cell] = cell in candidates[index*2:index*2+2]
        self.assertIsNone(decide(rows)['selected_policy_for_further_acceptance'])

    def test_incomplete_records_rejected(self):
        with self.assertRaises(AssertionError):
            validate_records([], {}, {}, 'a')

    def test_complete_sample_and_operation_coverage(self):
        records, physical, logical = self.records()
        result = validate_records(records, physical, logical, 'a')
        self.assertEqual((result['records'], result['operations'], len(result['scores'])), (1803, 8355, 200))

    def test_missing_duplicate_identity_and_clock_tampering_rejected(self):
        records, physical, logical = self.records()
        for change in ('missing', 'duplicate', 'identity', 'clock', 'cleanup', 'source_cold', 'role_order'):
            changed = copy.deepcopy(records)
            if change == 'missing': changed.pop()
            elif change == 'duplicate': changed.append(copy.deepcopy(changed[0]))
            elif change == 'identity': changed[0]['physical_sha256'] = 'x'*64
            elif change == 'clock': changed[0]['workflow']['complete_workflow_nanoseconds'] += 1
            elif change == 'cleanup': changed[0]['workflow']['final_reserved_bytes'] = 1
            elif change == 'source_cold': changed[1]['workflow']['cache_after_operations'][0]['counters']['misses'] = 0
            elif change == 'role_order': changed[3], changed[4] = changed[4], changed[3]
            with self.subTest(change=change), self.assertRaises(AssertionError):
                validate_records(changed, physical, logical, 'a')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-test', action='store_true')
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    if args.self_test:
        unittest.main(argv=[__file__])
    else:
        report = analyze(args.root)
        output = args.root / 'physical-retention-analysis-753.json'
        assert not output.exists()
        output.write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps({'correctness_and_coverage': report['correctness_and_coverage'], 'decision': report['decision'], 'output': str(output)}, indent=2))
