"""Run the required default workspace gates after exact candidate removal."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PYTHON = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
checks = [
    ('physical-restored-workspace-fmt-759', ['cargo', 'fmt', '--all', '--', '--check']),
    ('physical-restored-workspace-clippy-759', ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('physical-restored-workspace-tests-759', ['cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets']),
]
snapshot = json.loads((OUT / 'physical-retention-rejected-snapshot-759.json').read_text())


def verify():
    for item in snapshot['files']:
        path = ROOT / item['path']
        if item['tracked']:
            assert hashlib.sha256(path.read_bytes()).hexdigest() == item['baseline_sha256'], item['path']
        else:
            assert not path.exists(), item['path']


for name, command in checks:
    verify()
    run = subprocess.run([PYTHON, str(OUT / 'run_guarded_observed_757.py'),
        '--name', name, '--timeout', '1800', '--', *command], cwd=ROOT,
        text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
    with (OUT / (name + '-driver.log')).open('x') as stream:
        stream.write(run.stdout)
    assert run.returncode == 0, name
    receipt = json.loads((OUT / (name + '.json')).read_text())
    assert receipt['status'] == 'passed' and receipt['process_group_drained']
    assert receipt['direct_child_reaped'] and receipt['returncode'] == 0
    verify()
    print(json.dumps({'check': name, 'status': 'passed', 'process_group_drained': True}), flush=True)
