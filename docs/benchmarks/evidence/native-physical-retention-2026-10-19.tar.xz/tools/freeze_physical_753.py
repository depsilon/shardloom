"""Freeze exact experimental sources before a guarded correctness build."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
name = sys.argv[1]
assert name.replace('-', '').isalnum()
receipt = OUT / f'{name}-source-freeze.json'
assert not receipt.exists()
paths = sorted(set(subprocess.check_output(
    ['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=ROOT, text=True).splitlines()))
sources = []
for path in paths:
    if not (path.endswith('.rs') or Path(path).name in ('Cargo.toml', 'Cargo.toml.orig', 'Cargo.lock')):
        continue
    data = (ROOT / path).read_bytes()
    sources.append({'path': path, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
record = {
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'protocol_sha256': hashlib.sha256((OUT / 'physical-retention-protocol-752.json').read_bytes()).hexdigest(),
    'sources': sources,
}
(OUT / f'{name}-tracked.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary'], cwd=ROOT))
extra = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=ROOT, text=True).splitlines()
for path in extra:
    target = OUT / f'{name}-extra-sources' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / path, target)
receipt.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'path': str(receipt), 'sources': len(sources), 'sha256': hashlib.sha256(receipt.read_bytes()).hexdigest()}))
