"""Apply the unchanged 752 gates to the integration/ownership correction."""
from pathlib import Path
import importlib.util
import json

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
ANALYZER = OUT / 'analyze_physical_retention_753.py'
SPEC = importlib.util.spec_from_file_location('original_physical_analyzer', ANALYZER)
module = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(module)
assert module.digest(ANALYZER) == '43dec4f27a123979845b2816ce8c530b47b5421abd3aa7a03bb61f0e0719df3d'
assert module.digest(OUT / 'physical-retention-protocol-752.json') == module.PROTOCOL_SHA
assert module.digest(OUT / 'physical-retention-protocol-clarification-752.json') == module.CLARIFICATION_SHA
identity_path = OUT / 'physical-retention-final-build-identity-758.json'
identity = json.loads(identity_path.read_text())
assert module.digest(Path(identity['artifact'])) == identity['artifact_sha256']
freeze = Path(identity['source_freeze'])
assert module.digest(freeze) == identity['source_freeze_sha256']
for source in json.loads(freeze.read_text())['sources']:
    assert module.digest(ROOT / source['path']) == source['sha256'], source['path']
physical, logical = {}, {}
for record in module.parse(OUT / 'physical-attribution-cohort-a-751.log', 'PHYSICAL_RECONSTRUCTION '):
    cell = tuple(record[field] for field in module.FIELDS)
    p = record['physical_bytes'], record['physical_sha256']
    l = record['expected_values_sha256'], record['schema_sha256']
    assert physical.setdefault(cell[:4], p) == p
    assert logical.setdefault(cell[:2] + (cell[4],), l) == l
assert (len(physical), len(logical)) == (16, 8)
cohorts = []
for cohort in ('a', 'b'):
    stem = f'physical-retention-ownership-cohort-{cohort}-758'
    log, receipt_path = OUT / (stem + '.log'), OUT / (stem + '.json')
    receipt = json.loads(receipt_path.read_text())
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert not receipt['timed_out'] and receipt['interrupted_signal'] is None
    assert receipt['log_sha256'] == module.digest(log)
    assert identity['artifact'] in receipt['command']
    assert f'SHARDLOOM_PHYSICAL_COHORT={cohort}' in receipt['command']
    assert 'test result: ok. 1 passed;' in log.read_text()
    assert len(receipt['host']['samples']) >= 2
    result = module.validate_records(module.parse(log, 'PHYSICAL_RETENTION_WORKFLOW '), physical, logical, cohort)
    result['log_sha256'] = module.digest(log)
    result['receipt_sha256'] = module.digest(receipt_path)
    cohorts.append(result)
decision = module.decide(cohorts)
result = {
    'schema_version': 'shardloom.physical_retention_integration_recheck.v1',
    'protocol_sha256': module.PROTOCOL_SHA,
    'clarification_sha256': module.CLARIFICATION_SHA,
    'original_analyzer_sha256': module.digest(ANALYZER),
    'recheck_analyzer_sha256': module.digest(Path(__file__)),
    'build_identity_sha256': module.digest(identity_path),
    'correctness_and_coverage': 'passed',
    'prior_physical_and_logical_identities_identical': True,
    'decision': decision,
    'selected_one_policy_still_passes': decision['policies']['one']['passes_primary_gates'],
    'scope': 'Retest integration and cleanup changes under unchanged gates. LRU16 remains rejected by the original 753 cohorts; new observations cannot revive it.',
    'cohorts': [{k: v for k, v in row.items() if k not in ('medians', 'activated')} for row in cohorts],
}
target = OUT / 'physical-retention-ownership-analysis-758.json'
assert not target.exists()
target.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'correctness_and_coverage': 'passed',
                  'selected_one_policy_still_passes': result['selected_one_policy_still_passes']}))
