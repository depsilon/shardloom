"""Package the finite rejected physical-retention investigation as a portable packet."""
from pathlib import Path
import hashlib
import io
import json
import lzma
import os
import stat
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
DEST = ROOT / 'physical-portable-packet-fixed-759'
NAME = 'native-physical-retention-2026-10-19'
EVIDENCE = ROOT
sys.path.insert(0, str(REPO / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def digest_file(path):
    hasher = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            hasher.update(chunk)
    return hasher.hexdigest()


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def add_file(members, archive_name, path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), f'not a regular file: {path}'
    assert archive_name not in members, f'duplicate member: {archive_name}'
    members[archive_name] = path


def verify_recorded_files(record, root):
    """Verify a source-freeze/snapshot's file list against its frozen directory."""
    rows = record.get('files', record.get('sources'))
    assert isinstance(rows, list) and rows, 'empty or missing frozen file inventory'
    for row in rows:
        rel = row.get('path')
        expected_size = row.get('size_bytes', row.get('bytes'))
        expected_hash = row.get('sha256')
        assert rel and expected_size is not None and expected_hash, row
        path = root / rel
        data = path.read_bytes()
        assert len(data) == expected_size and digest(data) == expected_hash, rel


# Final decision is intentionally a hard gate: this script may be prepared before
# closeout, but the packet must not be emitted from a provisional result.
decision_path = EVIDENCE / 'physical-retention-final-decision-759.json'
removal_path = EVIDENCE / 'physical-retention-removal-759.json'
assert decision_path.is_file(), f'final decision receipt not available: {decision_path}'
assert removal_path.is_file(), f'candidate removal receipt not available: {removal_path}'
final_decision = json.loads(decision_path.read_text())
removal = json.loads(removal_path.read_text())
assert final_decision['schema_version'] == 'shardloom.physical_retention_final_decision.v1'
assert final_decision['owner'] == 'PERF-02.physical_cache'
assert final_decision['status'] == 'rejected_and_removed'
assert final_decision['decision']['runtime_changes_retained'] is False
assert final_decision['decision']['additional_performance_attempts_after_final_failure'] == 0
assert 'Reject' in final_decision['decision']['one']
assert 'Reject' in final_decision['decision']['lru16']
assert removal['all_archived_bytes_verified_before_removal'] is True

# Preserve the original three-step evidence history explicitly. The initial One
# result is preliminary; LRU16 stays rejected; the later One controls fail. No
# later observation may silently revive the old LRU16 policy.
capture_path = ROOT / 'physical-retention-rejected-snapshot-759.json'
capture = json.loads(capture_path.read_text())
assert capture['decision'] == (
    'reject_one_after_integration_controls_failed_and_preserve_original_lru16_rejection')
original_analysis = json.loads((ROOT / 'physical-retention-analysis-753.json').read_text())
candidate_analysis = json.loads((ROOT / 'physical-retention-ownership-analysis-758.json').read_text())
assert original_analysis['decision']['policies']['one']['passes_primary_gates'] is True
assert original_analysis['decision']['policies']['lru16']['passes_primary_gates'] is False
assert candidate_analysis['selected_one_policy_still_passes'] is False
assert candidate_analysis['decision']['policies']['one']['passes_primary_gates'] is False
assert final_decision['final_comparison']['sha256'] == digest(
    (ROOT / 'physical-retention-ownership-analysis-758.json').read_bytes())
assert final_decision['initial_comparison']['sha256'] == digest(
    (ROOT / 'physical-retention-analysis-753.json').read_bytes())
assert final_decision['candidate_snapshot']['sha256'] == digest(capture_path.read_bytes())
assert final_decision['removal']['sha256'] == digest(removal_path.read_bytes())
assert removal['snapshot_sha256'] == digest(capture_path.read_bytes())
assert capture['head'] == '030e615ef38bdfc2bb558698c20b5736d66547c4'

snapshot_dir = Path(capture['snapshot_directory'])
assert snapshot_dir.is_dir() and not snapshot_dir.is_symlink()
assert snapshot_dir.resolve() == (ROOT / 'physical-retention-rejected-snapshot-759').resolve()
assert len(capture['files']) == 49
verify_recorded_files(capture, snapshot_dir)
patch_path = Path(capture['patch'])
assert patch_path == ROOT / 'physical-retention-rejected-759-tracked.patch'
assert digest(patch_path.read_bytes()) == capture['patch_sha256']
assert digest((ROOT / 'physical-retention-final-758-source-freeze.json').read_bytes()) == (
    capture['source_freeze_sha256'])
assert digest((ROOT / 'physical-retention-ownership-analysis-758.json').read_bytes()) == (
    capture['final_analysis_sha256'])

# Keep the physical-only records and every source/snapshot tree, but never copy
# local fixtures, Vortex payloads, shared libraries, build outputs or executables.
members = {}
allowed_suffixes = {'.json', '.log', '.patch', '.rs'}
root_evidence = sorted(
    p for p in ROOT.glob('physical-*')
    if p.is_file() and not p.is_symlink() and p.suffix.lower() in allowed_suffixes)
assert len(root_evidence) >= 100, 'physical evidence inventory unexpectedly incomplete'
for path in root_evidence:
    add_file(members, 'evidence/' + path.name, path)

source_dirs = sorted(
    p for p in ROOT.glob('physical-*')
    if p.is_dir() and not p.is_symlink()
    and ('extra-sources' in p.name or 'snapshot' in p.name)
    and 'fixture' not in p.name.lower())
assert snapshot_dir.resolve() in [p.resolve() for p in source_dirs]
for directory in source_dirs:
    for path in sorted(directory.rglob('*')):
        if not path.is_file():
            continue
        assert not path.is_symlink(), f'symlink in source tree: {path}'
        assert path.suffix.lower() not in {'.vortex', '.so', '.dylib', '.a', '.rlib', '.o', '.bin', '.exe'}, path
        add_file(members, 'sources/' + str(path.relative_to(ROOT)), path)

# Include the experiment scripts and all physical-specific regression helpers.
required_scripts = {
    'analyze_physical_751.py', 'analyze_physical_retention_753.py',
    'recheck_physical_retention_757.py', 'freeze_physical_753.py',
    'run_physical_retention_cohorts_753.py', 'run_frozen_comparison_758.py',
    'run_guarded.py', 'run_guarded_observed_757.py',
    'check_physical_restoration_759.py',
    'package_physical_evidence_759.py',
    'package_physical_evidence_fixed_759.py',
}
for path in sorted(ROOT.glob('check_physical*.py')):
    required_scripts.add(path.name)
assert all((ROOT / name).is_file() for name in required_scripts), 'required physical script missing'
for name in sorted(required_scripts):
    add_file(members, 'tools/' + name, ROOT / name)

# Import closure for the two guarded runners, matching the previous portable
# packet convention. The release guard and process supervisor remain exact local
# source inputs; no test or benchmark is executed during packaging.
tools = {
    'tools/local_uat_storage.py': REPO / 'scripts/local_uat_storage.py',
    'tools/release_validation_guard.py':
        Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'),
    'tools/bounded_build_process_resume_20260912.py':
        Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py'),
    'tools/run_clickbench_paired_query_uat.py':
        REPO / 'scripts/run_clickbench_paired_query_uat.py',
    'tools/run_clickbench_query_uat.py':
        REPO / 'scripts/run_clickbench_query_uat.py',
    'tools/native_workflow_protocol.py': REPO / 'scripts/native_workflow_protocol.py',
    'tools/query_timing_report.py': REPO / 'scripts/query_timing_report.py',
    'tools/clickbench_reference_packet.py': REPO / 'scripts/clickbench_reference_packet.py',
}
for name, path in tools.items():
    add_file(members, name, path)
assert digest(tools['tools/bounded_build_process_resume_20260912.py'].read_bytes()) == (
    '1e83cd760be0dce608a3449b1b170db8d12e141f08e84c0ec7dfd347cb585e97')

# Verify each restored-workspace receipt and log against the authoritative
# final-decision record; the accompanying driver logs are preserved as well.
assert len(final_decision['restored_workspace_checks']) == 3
for check in final_decision['restored_workspace_checks']:
    assert check['status'] == 'passed'
    for kind in ('receipt', 'log'):
        row = check[kind]
        path = Path(row['path'])
        data = path.read_bytes()
        assert len(data) == row['size_bytes'] and digest(data) == row['sha256'], path
for stem in ('fmt', 'clippy', 'tests'):
    path = ROOT / f'physical-restored-workspace-{stem}-759-driver.log'
    assert path.is_file(), f'restored-workspace driver log missing: {path}'
assert final_decision['complete_final_observation']['correctness_and_coverage'] == 'passed'
assert final_decision['complete_final_observation']['process_groups_drained'] is True
assert final_decision['complete_final_observation']['all_final_reservations_zero'] is True
assert final_decision['restored_workspace_checks'][2]['test_counts'] == {
    'passed': 3235, 'failed': 0, 'ignored': 0}

# Large platform artifacts are inventoried by exact file identity rather than
# copied into this evidence archive. They remain available beside their receipts.
omitted_binary_roots = [
    ROOT / 'artifacts/public-initial-757',
    ROOT / 'artifacts/public-757',
    ROOT / 'artifacts/public-758',
]
omitted_artifacts = []
omitted_source_state = {}
for directory in omitted_binary_roots:
    assert directory.is_dir() and not directory.is_symlink(), directory
    for path in sorted(directory.rglob('*')):
        if not path.is_file():
            continue
        mode = path.stat().st_mode
        if path.suffix.lower() not in {
            '.vortex', '.so', '.dylib', '.a', '.rlib', '.o', '.bin', '.exe'
        } and not mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH):
            continue
        row = {'path': str(path), 'bytes': path.stat().st_size,
               'sha256': digest_file(path), 'copied': False,
               'reason': 'compiled artifact excluded; exact local identity retained'}
        omitted_artifacts.append(row)
        omitted_source_state[str(path)] = (row['bytes'], row['sha256'])
assert {Path(row['path']).name for row in omitted_artifacts} == {
    '_native.abi3.so', 'lib_native.dylib', 'shardloom'}
# The native investigation's physical reconstruction/retention test executables
# are first-class measured artifacts. Inventory every direct physical-* file
# beside the public CLI/module artifacts, without copying these large binaries.
physical_artifacts = sorted((ROOT / 'artifacts').glob('physical-*'))
assert len(physical_artifacts) == 9 and all(
    path.is_file() and not path.is_symlink() for path in physical_artifacts)
physical_inventory = []
for path in physical_artifacts:
    row = {'path': str(path), 'bytes': path.stat().st_size,
           'sha256': digest_file(path), 'copied': False,
           'reason': 'measured native executable excluded; exact local identity retained'}
    omitted_artifacts.append(row)
    omitted_source_state[str(path)] = (row['bytes'], row['sha256'])
    physical_inventory.append(row)

# Tie the original 753 observation and final 758 candidate directly to the
# omitted-binary inventory, using their authoritative build-identity records.
build_identity_checks = {}
for identity_name, size_key, hash_key in (
    ('physical-retention-final-build-identity-753.json', 'bytes', 'sha256'),
    ('physical-retention-final-build-identity-758.json', 'artifact_bytes', 'artifact_sha256'),
):
    identity_path = ROOT / identity_name
    identity = json.loads(identity_path.read_text())
    artifact_path = Path(identity['artifact'])
    recorded = (identity[size_key], identity[hash_key])
    observed = (artifact_path.stat().st_size, digest_file(artifact_path))
    assert recorded == observed
    entry = next((row for row in omitted_artifacts if row['path'] == str(artifact_path)), None)
    assert entry is not None and (entry['bytes'], entry['sha256']) == recorded
    build_identity_checks[identity_name] = {
        'identity_record': identity_name,
        'artifact': str(artifact_path),
        'bytes': recorded[0], 'sha256': recorded[1],
        'inventory_match': True,
    }
assert not any(p.is_dir() and 'fixture' in p.name.lower() for p in ROOT.iterdir()), (
    'fixture directory found; inventory explicitly before packaging')

# Snapshot every selected input before packing and recheck afterward. This makes
# the archive fail closed if any producer changes a receipt while it is packaged.
inventory = []
before = {}
for name, path in sorted(members.items()):
    data = path.read_bytes()
    row = {'path': name, 'original_path': str(path),
           'bytes': len(data), 'sha256': digest(data)}
    inventory.append(row)
    before[name] = (row['bytes'], row['sha256'])
uncompressed_bytes = sum(row['bytes'] for row in inventory)
assert uncompressed_bytes < 128 * MIB, f'evidence packet unexpectedly large: {uncompressed_bytes}'
assert len([n for n in members if n.startswith('evidence/physical-attribution-cohort-')
            and n.endswith('.json')]) == 2
assert {'evidence/physical-attribution-cohort-a-751.log',
        'evidence/physical-attribution-cohort-b-751.log',
        'evidence/physical-retention-cohort-a-753.log',
        'evidence/physical-retention-cohort-b-753.log',
        'evidence/physical-retention-ownership-cohort-a-758.log',
        'evidence/physical-retention-ownership-cohort-b-758.log'} <= members.keys()

require_local_path(DEST, Path.home(), sys.platform)
check_budgets(ROOT, DEST, ROOT / 'logs', min_free_bytes=12 * GIB,
              reserve_bytes=128 * MIB, max_workspace_bytes=100 * GIB,
              max_log_bytes=192 * MIB)
assert not DEST.exists(), f'unique packet destination required: {DEST}'
DEST.mkdir()
archive = DEST / (NAME + '.tar.xz')
with tarfile.open(archive, mode='w:xz', format=tarfile.PAX_FORMAT, preset=6) as output:
    for row in inventory:
        data = members[row['path']].read_bytes()
        assert len(data) == row['bytes'] and digest(data) == row['sha256']
        info = tarfile.TarInfo(row['path'])
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        output.addfile(info, io.BytesIO(data))

with tarfile.open(archive, 'r:xz') as source:
    assert source.getnames() == [row['path'] for row in inventory]
    for row in inventory:
        entry = source.getmember(row['path'])
        assert entry.isfile()
        data = source.extractfile(entry).read()
        assert len(data) == row['bytes'] and digest(data) == row['sha256']

for name, path in members.items():
    expected = before[name]
    data = path.read_bytes()
    assert (len(data), digest(data)) == expected, f'input changed during packaging: {path}'
for filename, expected in omitted_source_state.items():
    path = Path(filename)
    assert (path.stat().st_size, digest_file(path)) == expected, (
        f'omitted artifact changed during packaging: {path}')

manifest_data = {
    'schema_version': 'shardloom.evidence_member_manifest.v1',
    'all_members_reopened': True,
    'members': inventory,
}
manifest = DEST / (NAME + '.manifest.json.xz')
manifest.write_bytes(lzma.compress(encode(manifest_data), preset=6))
assert json.loads(lzma.decompress(manifest.read_bytes())) == manifest_data

index = {
    'schema_version': 'shardloom.native_physical_retention_investigation.v1',
    'status': 'finite_candidate_rejected',
    'decision': 'reject_one_and_lru16_policies_after_frozen_controls; candidate removed',
    'authoritative_final_decision': {
        'path': 'evidence/physical-retention-final-decision-759.json',
        'bytes': decision_path.stat().st_size,
        'sha256': digest(decision_path.read_bytes()),
    },
    'investigated_substeps': ['PERF-02.physical_cache'],
    'completed_substeps': [],
    'broader_owners_closed': [],
    'finite_investigation_complete': True,
    'conditional_substep_remains_open': True,
    'broader_owners_open': True,
    'history': {
        'preliminary_one_policy_753': {
            'passes_primary_gates': True,
            'final_acceptance': False,
            'interpretation': 'preliminary result only; superseded by later controls',
        },
        'original_lru16_753': {
            'passes_primary_gates': False,
            'rejection_remains_binding': True,
        },
        'final_one_policy_758': {
            'selected_one_policy_still_passes': False,
            'two_one_call_controls_cohort_b': True,
            'decision': 'rejected',
        },
        'lru16_revived': False,
    },
    'removal_receipt': 'evidence/physical-retention-removal-759.json',
    'rejected_candidate_snapshot': 'evidence/physical-retention-rejected-snapshot-759.json',
    'archive': {'file': archive.name, 'bytes': archive.stat().st_size,
                'sha256': digest(archive.read_bytes())},
    'manifest': {'file': manifest.name, 'bytes': manifest.stat().st_size,
                 'sha256': digest(manifest.read_bytes())},
    'member_count': len(inventory),
    'uncompressed_bytes': uncompressed_bytes,
    'all_members_reopened': True,
    'physical_payloads_or_build_binaries_copied': False,
    'omitted_artifact_inventory': omitted_artifacts,
    'physical_native_executable_inventory': physical_inventory,
    'build_identity_inventory_cross_checks': build_identity_checks,
    'fixture_directories_copied': [],
    'restored_workspace_checks': {
        'format': 'passed', 'strict_clippy': 'passed',
        'workspace_tests': {'passed': 3235, 'failed': 0, 'ignored': 0},
    },
    'fallback_execution': False,
    'broader_acceptance_claim': False,
    'causal_speed_claim': False,
}
index_path = DEST / (NAME + '.json')
index_path.write_bytes(encode(index))
check_budgets(ROOT, DEST, ROOT / 'logs', min_free_bytes=12 * GIB,
              reserve_bytes=0, max_workspace_bytes=100 * GIB,
              max_log_bytes=192 * MIB)
print(json.dumps({'status': 'passed', 'members': len(inventory),
                  'uncompressed_bytes': uncompressed_bytes,
                  'archive_bytes': index['archive']['bytes'],
                  'manifest_bytes': index['manifest']['bytes'],
                  'all_members_reopened': True, 'output': str(index_path)}))
