"""Check public observation/lifetime evidence against the frozen native module."""
from pathlib import Path
import os
import sys
import unittest
import run_builder_756 as builder

identity = Path(__file__).with_name('builder-public-artifact-757.json')
library = builder.verify_identity(identity)
os.environ['SHARDLOOM_NATIVE_TEST_LIBRARY'] = str(library)
os.environ['SHARDLOOM_REQUIRE_NATIVE_PYTHON'] = '1'
sys.path.insert(0, str(builder.ROOT / 'python/tests'))
sys.path.insert(0, str(builder.ROOT / 'python/src'))
suite = unittest.defaultTestLoader.loadTestsFromName(
    'test_native_binding.NativeBindingTests.test_native_results_report_optional_physical_ownership_without_inventing_hits')
assert suite.countTestCases() == 1
result = unittest.TextTestRunner(verbosity=2).run(suite)
assert result.testsRun == 1 and not result.skipped
raise SystemExit(0 if result.wasSuccessful() else 1)
