from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
binary = root / 'artifacts/physical-retention-final-shardloom-vortex-753'
for selector in ('physical_retention_', 'resident_session::tests::',
                 'resident_session::concurrent_serving_tests::', 'physical_reconstruction_probe_'):
    print(f'Focused native check: {selector}', flush=True)
    subprocess.run([str(binary), selector, '--nocapture', '--test-threads=1'], check=True)
