"""Replay the frozen physical-reconstruction attribution screen from complete logs."""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from pathlib import Path
from statistics import median


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def analyze(root: Path) -> dict:
    protocol = root / 'physical-reconstruction-protocol-750.json'
    assert digest(protocol) == 'ef8d1fae2f84bf39fcb4dc17fa8661360017d872b5f39f25934c40c5cc7e8db7'
    spec = json.loads(protocol.read_text())
    work = spec['workload']
    fields = ('rows', 'columns', 'encoding', 'layout', 'projection', 'consumer')
    combinations = list(itertools.product(work['rows'], work['column_counts'],
        work['encodings'], work['layouts'], work['projections'], work['consumers']))
    assert len(combinations) == work['cells'] == 96
    physical_identities = {}
    logical_identities = {}
    cohorts = []
    for cohort in ('a', 'b'):
        stem = f'physical-attribution-cohort-{cohort}-751'
        log = root / f'{stem}.log'
        receipt = json.loads((root / f'{stem}.json').read_text())
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert not receipt['timed_out'] and receipt['interrupted_signal'] is None
        assert receipt['log_sha256'] == digest(log)
        lines = log.read_text().splitlines()
        records = [json.loads(line.split('PHYSICAL_RECONSTRUCTION ', 1)[1])
                   for line in lines if 'PHYSICAL_RECONSTRUCTION ' in line]
        assert len(records) == 768
        assert any('test result: ok. 1 passed;' in line for line in lines)
        groups = {}
        total_operations = 0
        maximum_peak = 0
        for record in records:
            key = tuple(record[field] for field in fields)
            assert key == combinations[record['cell']]
            sample = record['sample']
            assert sample in range(4) and record['warmup'] == (sample == 0)
            assert type(record['profiled']) is bool
            assert record['grant_bytes'] == work['grant_bytes']
            assert 0 < record['physical_bytes'] <= work['source_limit_bytes']
            physical_key = key[:4]
            identity = (record['physical_bytes'], record['physical_sha256'])
            assert physical_identities.setdefault(physical_key, identity) == identity
            logical_key = (record['rows'], record['columns'], record['projection'])
            logical = (record['expected_values_sha256'], record['schema_sha256'])
            assert logical_identities.setdefault(logical_key, logical) == logical
            group_key = (record['cell'], sample, record['profiled'])
            assert group_key not in groups
            groups[group_key] = record
            observations = record['observations']
            assert len(observations) == (1 if sample == 0 else 3)
            total_operations += len(observations)
            for observation in observations:
                assert observation['all_values_types_nulls_order_verified'] is True
                assert observation['fallback_attempted'] is False
                assert observation['reserved_before'] == observation['reserved_after']
                assert observation['denied_reservations'] == 0
                assert 0 <= observation['reserved_with_output'] <= observation['peak_reserved_bytes'] <= work['grant_bytes']
                maximum_peak = max(maximum_peak, observation['peak_reserved_bytes'])
                elapsed = observation['native_execution_nanoseconds']
                assert type(elapsed) is int and elapsed > 0
                profile = observation['profile']
                calls, timed, nanos = (profile[name] for name in ('calls', 'timed_calls', 'nanoseconds'))
                assert len(calls) == len(timed) == len(nanos) == 3
                assert all(type(value) is int and value >= 0 for value in calls + timed + nanos)
                if record['profiled']:
                    assert calls[0] >= timed[0] > 0
                    assert calls[1] == calls[2] == timed[1] == timed[2] > 0
                    assert profile['serialized_bytes'] > 0
                    # Awaited segment spans may overlap. They are never added here.
                    assert 0 < nanos[0] + nanos[1] <= elapsed
                else:
                    assert calls == timed == nanos == [0, 0, 0]
                    assert profile['serialized_bytes'] == 0
        assert total_operations == 1920
        rows = []
        for cell, key in enumerate(combinations):
            ratios = []
            stage_fractions = [[], []]
            role_executions = {False: [], True: []}
            profile_calls = []
            for sample in range(1, 4):
                active = groups[(cell, sample, True)]['observations']
                ratios.append(median((item['profile']['nanoseconds'][0] + item['profile']['nanoseconds'][1])
                                     / item['native_execution_nanoseconds'] for item in active))
                for stage in range(2):
                    stage_fractions[stage].append(median(item['profile']['nanoseconds'][stage]
                        / item['native_execution_nanoseconds'] for item in active))
                for role in (False, True):
                    role_executions[role].extend(item['native_execution_nanoseconds']
                        for item in groups[(cell, sample, role)]['observations'])
                profile_calls.extend(item['profile']['calls'] for item in active)
            execution_medians = {str(role).lower(): median(values) for role, values in role_executions.items()}
            observer_ratio = execution_medians['true'] / execution_medians['false']
            material = all(value >= 0.10 for value in ratios)
            observer_acceptable = observer_ratio <= 1.05
            rows.append(dict(zip(fields, key), cell=cell,
                per_sample_reconstruction_fraction=ratios,
                per_sample_reader_fraction=stage_fractions[0],
                per_sample_array_fraction=stage_fractions[1],
                median_execution_nanoseconds=execution_medians,
                observer_ratio=observer_ratio, material_signal=material,
                observer_acceptable=observer_acceptable,
                qualifies=material and observer_acceptable,
                minimum_calls_per_operation=[min(calls[i] for calls in profile_calls) for i in range(3)],
                maximum_calls_per_operation=[max(calls[i] for calls in profile_calls) for i in range(3)]))
        cohorts.append({'cohort': cohort, 'records': len(records), 'operations': total_operations,
            'maximum_native_peak_reserved_bytes': maximum_peak,
            'material_cells': [row['cell'] for row in rows if row['material_signal']],
            'qualifying_cells': [row['cell'] for row in rows if row['qualifies']],
            'cells': rows, 'receipt_sha256': digest(root / f'{stem}.json'),
            'log_sha256': digest(log)})
    common = sorted(set(cohorts[0]['qualifying_cells']) & set(cohorts[1]['qualifying_cells']))
    assert len(physical_identities) == 16 and len(logical_identities) == 8
    return {'schema_version': 'shardloom.conditional_physical_reconstruction_analysis.v1',
        'owner': 'PERF-02.physical_cache', 'protocol_sha256': digest(protocol),
        'analysis_sha256': digest(Path(__file__)), 'complete': True,
        'physical_identities': [dict(zip(fields[:4], key), bytes=value[0], sha256=value[1])
                                for key, value in sorted(physical_identities.items())],
        'logical_identities': [{'rows': key[0], 'columns': key[1], 'projection': key[2],
            'expected_values_sha256': value[0], 'schema_sha256': value[1]}
            for key, value in sorted(logical_identities.items())],
        'cohorts': cohorts, 'qualifying_in_both_cohorts': common,
        'decision': ('advance_to_separate_frozen_candidate_protocol' if len(common) >= 2
                     else 'no_justified_descriptor_reader_retention_candidate_in_finite_scope'),
        'claim_boundary': 'Attribution only. Awaited segment time is excluded. No cache, speed, whole-process memory, whole-engine or universal physical-cache conclusion.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    result = analyze(args.root)
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({key: result[key] for key in
        ('complete', 'decision', 'qualifying_in_both_cohorts')}))
