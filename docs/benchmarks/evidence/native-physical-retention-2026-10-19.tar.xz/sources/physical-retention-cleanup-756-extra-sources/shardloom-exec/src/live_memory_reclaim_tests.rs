use super::*;
use std::sync::{Mutex, atomic::AtomicUsize};

#[derive(Debug)]
struct IdleOwner {
    idle: Mutex<Option<MemoryLease>>,
    attempts: AtomicUsize,
}

impl IdleMemoryReclaimer for IdleOwner {
    fn reclaim_idle(&self) -> bool {
        self.attempts.fetch_add(1, Ordering::Relaxed);
        let Ok(mut idle) = self.idle.try_lock() else {
            return false;
        };
        idle.take().is_some()
    }
}

fn register(pool: &LiveMemoryPool, bytes: u64) -> Arc<IdleOwner> {
    let owner = Arc::new(IdleOwner {
        idle: Mutex::new(Some(pool.reserve(bytes).unwrap())),
        attempts: AtomicUsize::new(0),
    });
    let erased: Arc<dyn IdleMemoryReclaimer> = owner.clone();
    pool.register_idle_reclaimer(Arc::downgrade(&erased))
        .unwrap();
    owner
}

#[test]
fn idle_reclamation_allows_ordinary_reservation_and_lease_growth() {
    let pool = LiveMemoryPool::new(100).unwrap();
    let idle = register(&pool, 60);
    let mut active = pool.reserve(20).unwrap();
    assert_eq!(idle.attempts.load(Ordering::Relaxed), 0);
    active.resize(100).unwrap();
    assert_eq!(active.bytes(), 100);
    assert_eq!(idle.attempts.load(Ordering::Relaxed), 1);
    assert_eq!(pool.snapshot().reserved_bytes, 100);
    assert_eq!(pool.snapshot().denied_reservations, 1);
    drop(active);
    *idle.idle.lock().unwrap() = Some(pool.reserve(80).unwrap());
    let ordinary = pool.reserve(90).unwrap();
    assert_eq!(ordinary.bytes(), 90);
    assert_eq!(idle.attempts.load(Ordering::Relaxed), 2);
    drop((ordinary, idle));
    assert_eq!(pool.snapshot().reserved_bytes, 0);
}

#[test]
fn idle_reclamation_never_waits_for_active_owners_or_retries_without_release() {
    let pool = LiveMemoryPool::new(100).unwrap();
    let idle = register(&pool, 80);
    let held = idle.idle.lock().unwrap();
    assert!(pool.reserve(30).is_err());
    assert_eq!(pool.snapshot().reserved_bytes, 80);
    assert_eq!(idle.attempts.load(Ordering::Relaxed), 1);
    drop(held);
    let active = idle.idle.lock().unwrap().take().unwrap();
    assert!(pool.reserve(30).is_err());
    assert_eq!(pool.snapshot().reserved_bytes, 80);
    assert_eq!(idle.attempts.load(Ordering::Relaxed), 2);
    drop(active);
    assert_eq!(pool.snapshot().reserved_bytes, 0);
}

#[test]
fn idle_reclamation_preserves_denial_when_release_is_insufficient() {
    let pool = LiveMemoryPool::new(100).unwrap();
    let idle = register(&pool, 20);
    let retained = pool.reserve(70).unwrap();
    assert!(pool.reserve(40).is_err());
    assert_eq!(pool.snapshot().reserved_bytes, 70);
    assert_eq!(idle.attempts.load(Ordering::Relaxed), 1);
    assert_eq!(pool.snapshot().denied_reservations, 2);
    drop(retained);
    assert_eq!(pool.snapshot().reserved_bytes, 0);
}

#[test]
fn idle_reclamation_supports_limit_reduction_without_releasing_active_leases() {
    let pool = LiveMemoryPool::configurable(100).unwrap();
    let idle = register(&pool, 60);
    let retained = pool.reserve(30).unwrap();
    pool.set_limit_bytes(30).unwrap();
    assert_eq!(pool.snapshot().reserved_bytes, 30);
    assert_eq!(pool.snapshot().limit_bytes, 30);
    assert_eq!(idle.attempts.load(Ordering::Relaxed), 1);
    assert!(pool.set_limit_bytes(29).is_err());
    assert_eq!(pool.snapshot().limit_bytes, 30);
    drop(retained);
    assert_eq!(pool.snapshot().reserved_bytes, 0);
}

#[test]
fn idle_registration_is_weak_and_cannot_be_replaced() {
    let pool = LiveMemoryPool::new(100).unwrap();
    let idle = register(&pool, 60);
    let erased: Arc<dyn IdleMemoryReclaimer> = idle.clone();
    assert!(
        pool.register_idle_reclaimer(Arc::downgrade(&erased))
            .is_err()
    );
    drop(erased);
    let observed = Arc::downgrade(&idle);
    drop(idle);
    assert!(observed.upgrade().is_none());
    assert_eq!(pool.snapshot().reserved_bytes, 0);
    assert!(pool.reserve(101).is_err());
    assert_eq!(pool.snapshot().denied_reservations, 1);
}
