//! Side-effect-free observations of optional native physical-array ownership.

/// Session-lifetime observations, not a query-answer cache or avoided-I/O claim.
/// Lookup hits still require generation validation before an array may be used.
/// Retention charges include conservative metadata bounds and evicted consumers
/// that still own buffers. These are subordinate admission charges, not extra
/// allocations; callers must not add them to the session's reserved bytes.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PhysicalArrayRetentionSnapshot {
    pub policy: &'static str,
    pub capacity_entries: usize,
    pub entries: usize,
    pub ready_entries: usize,
    pub admission_limit_bytes: u64,
    pub retained_owner_charged_bytes: u64,
    pub retained_owner_peak_charged_bytes: u64,
    pub table_charged_bytes: u64,
    pub lookup_hits: u64,
    pub lookup_misses: u64,
    pub admissions: u64,
    pub copied_serialized_bytes: u64,
    pub evictions: u64,
    pub pressure_reclaims: u64,
    pub invalidations: u64,
    pub pressure_bypasses: u64,
    pub shape_bypasses: u64,
}

impl Default for PhysicalArrayRetentionSnapshot {
    fn default() -> Self {
        Self {
            policy: "not_admitted",
            capacity_entries: 0,
            entries: 0,
            ready_entries: 0,
            admission_limit_bytes: 0,
            retained_owner_charged_bytes: 0,
            retained_owner_peak_charged_bytes: 0,
            table_charged_bytes: 0,
            lookup_hits: 0,
            lookup_misses: 0,
            admissions: 0,
            copied_serialized_bytes: 0,
            evictions: 0,
            pressure_reclaims: 0,
            invalidations: 0,
            pressure_bypasses: 0,
            shape_bypasses: 0,
        }
    }
}
