//! Complete native caller checks for frozen physical-retention-752-v1.
use super::super::PreparedVortexSource;
use super::super::physical_retention::Policy;
use super::*;
use shardloom_exec::live_memory::IdleMemoryReclaimer as _;
use std::io::{Seek as _, SeekFrom, Write as _};
use vortex::layout::{
    layouts::flat::{Flat, FlatLayout},
    segments::PhysicalArrayRetention as _,
};

#[path = "resident_physical_retention_workflow_tests.rs"]
mod workflow;

fn owner(memory: &LiveMemoryPool, policy: Policy) -> ResidentVortexSession {
    ResidentVortexSession::with_memory_pool_retention(memory.clone(), 1, true, policy).unwrap()
}

fn run(prepared: &PreparedVortexRelational, fixture: &Fixture, projection: &str, consumer: &str) {
    operation_policy(
        prepared,
        fixture,
        projection,
        &expected_json(fixture, projection),
        consumer,
        &Profile::default(),
        false,
        true,
    );
}

fn scan(source: &PreparedVortexSource, fixture: &Fixture) {
    let arrays = source
        .with_native_execution(|file, _, runtime| {
            file.scan()
                .map_err(super::super::native_error)?
                .with_ordered(true)
                .with_concurrency(1)
                .into_array_iter(runtime)
                .map_err(super::super::native_error)?
                .map(|array| array.map_err(super::super::native_error))
                .collect::<shardloom_core::Result<Vec<_>>>()
        })
        .unwrap();
    let memory = LiveMemoryPool::new(GRANT).unwrap();
    let verifier = session(&memory);
    let mut context = verifier.create_execution_ctx();
    let mut offset = 0;
    for array in arrays {
        let fields = array.execute::<StructArray>(&mut context).unwrap();
        for column in &fixture.columns {
            verify_column(
                fields.unmasked_field_by_name(&column.name).unwrap().clone(),
                column,
                offset,
                &mut context,
            );
        }
        offset += fields.len();
    }
    assert_eq!(offset, fixture.rows);
    drop(context);
    drop(verifier);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}

fn root_layout(source: &PreparedVortexSource) -> FlatLayout {
    source.0.file.footer().layout().as_::<Flat>().clone()
}

fn warm(source: &PreparedVortexSource, fixture: &Fixture) -> ArrayRef {
    for _ in 0..3 {
        scan(source, fixture);
    }
    source
        .0
        .physical_arrays
        .as_ref()
        .unwrap()
        .lookup(&root_layout(source))
        .unwrap()
        .unwrap()
}

fn path(label: &str) -> std::path::PathBuf {
    std::env::temp_dir().join(format!(
        "sl-physical-retention-{label}-{}.vortex",
        std::process::id()
    ))
}

#[test]
fn physical_retention_complete_native_values_second_admission_and_source_drop() {
    let root = std::env::temp_dir().join(format!("sl-physical-retention-{}", std::process::id()));
    fs::create_dir(&root).unwrap();
    for layout in ["whole_struct_flat", "columnar_table_flat"] {
        for policy in [Policy::None, Policy::One, Policy::Lru16] {
            let fixture = fixture(4096, 3);
            let path = root.join(format!("{layout}-{policy:?}.vortex"));
            write_fixture(&path, &fixture, "canonical", layout);
            let memory = LiveMemoryPool::new(GRANT).unwrap();
            let owner = owner(&memory, policy);
            let plan = prepare(&owner, &path, "all");
            for consumer in ["native_canonical_2048", "json_2048", "json_64"] {
                for _ in 0..3 {
                    run(&plan, &fixture, "all", consumer);
                }
            }
            if let Some(manager) = &owner.0.physical_arrays {
                let snapshot = manager.snapshot();
                let report = owner.snapshot().physical_array_retention;
                assert_eq!(
                    report.capacity_entries,
                    if policy == Policy::One { 1 } else { 16 }
                );
                assert_eq!(report.lookup_hits, snapshot.counters.hits);
                assert_eq!(report.lookup_misses, snapshot.counters.misses);
                assert_eq!(report.admissions, snapshot.counters.admissions);
                assert_eq!(
                    report.copied_serialized_bytes,
                    snapshot.counters.copied_bytes
                );
                assert_eq!(
                    report.retained_owner_charged_bytes,
                    snapshot.retention_reserved
                );
                assert_eq!(
                    report.retained_owner_peak_charged_bytes,
                    snapshot.retention_peak
                );
                assert_eq!(report.table_charged_bytes, snapshot.table_bytes);
                assert_eq!(report.entries, snapshot.entries);
                assert_eq!(report.ready_entries, snapshot.ready);
                eprintln!(
                    "physical retention smoke {layout} {policy:?}: {}",
                    serde_json::to_string(&snapshot).unwrap()
                );
                if layout == "whole_struct_flat" || policy == Policy::Lru16 {
                    assert!(snapshot.counters.admissions > 0);
                    assert!(snapshot.counters.hits > 0);
                    assert!(snapshot.retention_reserved > 0);
                }
                assert!(snapshot.retention_peak <= snapshot.retention_limit);
            }
            drop(plan);
            if let Some(manager) = &owner.0.physical_arrays {
                assert_eq!(manager.snapshot().entries, 0);
                assert_eq!(manager.snapshot().retention_reserved, 0);
                let report = owner.snapshot().physical_array_retention;
                assert_eq!(report.entries, 0);
                assert_eq!(report.retained_owner_charged_bytes, 0);
                assert_eq!(report.table_charged_bytes, 0);
            }
            // Keep the runtime alive: the final source, not runtime shutdown,
            // must release both retained arrays and the empty table.
            assert_eq!(memory.snapshot().reserved_bytes, 0);
            drop(owner);
            assert_eq!(memory.snapshot().reserved_bytes, 0);
            fs::remove_file(path).unwrap();
        }
    }
    fs::remove_dir(root).unwrap();
}

#[test]
fn physical_retention_cached_native_output_reopens_complete_values_and_schema() {
    let input = path("native-write-input");
    let output = path("native-write-output");
    let fixture = fixture(4096, 3);
    write_fixture(&input, &fixture, "canonical", "whole_struct_flat");
    let memory = LiveMemoryPool::new(GRANT).unwrap();
    let owner = owner(&memory, Policy::One);
    let plan = prepare(&owner, &input, "all");
    for _ in 0..3 {
        run(&plan, &fixture, "all", "json_64");
    }
    let before = owner.snapshot().physical_array_retention;
    assert!(before.ready_entries > 0 && before.lookup_hits > 0);
    let written = plan
        .write(
            &output,
            crate::VortexLocalPrimitiveRowExportFormat::Vortex,
            false,
        )
        .unwrap();
    assert_eq!(written.output.rows_written as usize, fixture.rows);
    assert!(written.execution.native_io_certificate.is_certified());
    assert!(!written.output.evidence.side_effects.fallback_attempted);
    assert!(owner.snapshot().physical_array_retention.lookup_hits > before.lookup_hits);
    drop(written);
    drop(plan);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    // The original producer and its cached arrays are gone before reopen.
    drop(owner);
    fs::remove_file(input).unwrap();
    let verifier = session(&memory);
    let reopened = prepare(&verifier, &output, "all");
    run(&reopened, &fixture, "all", "json_64");
    drop(reopened);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    drop(verifier);
    fs::remove_file(output).unwrap();
}

#[test]
fn physical_retention_encoded_controls_remain_uncached() {
    let path = std::env::temp_dir().join(format!(
        "sl-physical-retention-zstd-{}.vortex",
        std::process::id()
    ));
    let fixture = fixture(4096, 3);
    write_fixture(&path, &fixture, "zstd_dictionary", "whole_struct_flat");
    let memory = LiveMemoryPool::new(GRANT).unwrap();
    let owner = owner(&memory, Policy::Lru16);
    let plan = prepare(&owner, &path, "all");
    for _ in 0..4 {
        run(&plan, &fixture, "all", "native_canonical_2048");
    }
    let snapshot = owner.0.physical_arrays.as_ref().unwrap().snapshot();
    assert_eq!(snapshot.counters.hits, 0);
    assert_eq!(snapshot.counters.admissions, 0);
    assert_eq!(snapshot.retention_reserved, 0);
    assert!(snapshot.counters.shape_bypasses > 0);
    drop(plan);
    drop(owner);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    fs::remove_file(path).unwrap();
}

#[test]
fn physical_retention_children_slices_and_buffers_keep_credit_after_source_and_cache_drop() {
    for policy in [Policy::One, Policy::Lru16] {
        let path = path(&format!("owners-{policy:?}"));
        let fixture = fixture(4096, 3);
        write_fixture(&path, &fixture, "canonical", "whole_struct_flat");
        let memory = LiveMemoryPool::new(GRANT).unwrap();
        let owner = owner(&memory, policy);
        let source = owner.prepare_file(&path).unwrap();
        let manager = owner.0.physical_arrays.as_ref().unwrap().clone();
        let cached = warm(&source, &fixture);
        let child = cached
            .as_::<vortex::array::arrays::Struct>()
            .unmasked_field_by_name("field_01")
            .unwrap()
            .clone();
        let slice = child.slice(11..37).unwrap();
        let buffer = child.buffers().into_iter().last().unwrap();
        let digest = sha(buffer.as_slice());
        let retained = manager.snapshot().retention_reserved;
        assert!(retained > 0);
        assert!(manager.reclaim_idle());
        assert_eq!(manager.snapshot().entries, 0);
        assert_eq!(manager.snapshot().retention_reserved, retained);
        drop(cached);
        drop(source);
        drop(owner);
        let verifier_memory = LiveMemoryPool::new(GRANT).unwrap();
        let verifier = session(&verifier_memory);
        verify_column(
            child.clone(),
            &fixture.columns[1],
            0,
            &mut verifier.create_execution_ctx(),
        );
        verify_column(
            slice.clone(),
            &fixture.columns[1],
            11,
            &mut verifier.create_execution_ctx(),
        );
        drop(verifier);
        assert_eq!(verifier_memory.snapshot().reserved_bytes, 0);
        drop(child);
        assert_eq!(manager.snapshot().retention_reserved, retained);
        drop(slice);
        assert_eq!(manager.snapshot().retention_reserved, retained);
        assert_eq!(sha(buffer.as_slice()), digest);
        assert!(memory.snapshot().reserved_bytes > 0);
        drop(buffer);
        assert_eq!(manager.snapshot().retention_reserved, 0);
        drop(manager);
        assert_eq!(memory.snapshot().reserved_bytes, 0);
        fs::remove_file(path).unwrap();
    }
}

#[test]
fn physical_retention_pressure_reclaims_idle_but_cannot_release_a_live_consumer() {
    let path = path("pressure");
    let fixture = fixture(4096, 3);
    write_fixture(&path, &fixture, "canonical", "whole_struct_flat");
    let memory = LiveMemoryPool::new(GRANT).unwrap();
    let owner = owner(&memory, Policy::Lru16);
    let source = owner.prepare_file(&path).unwrap();
    let manager = owner.0.physical_arrays.as_ref().unwrap();
    let baseline = memory.snapshot().reserved_bytes;
    drop(warm(&source, &fixture));
    assert!(memory.snapshot().reserved_bytes > baseline);
    let ordinary = memory.reserve(GRANT - baseline).unwrap();
    assert_eq!(manager.snapshot().retention_reserved, 0);
    assert_eq!(manager.snapshot().table_bytes, 0);
    assert_eq!(memory.snapshot().reserved_bytes, GRANT);
    drop(ordinary);
    let held = warm(&source, &fixture);
    assert!(memory.reserve(GRANT - baseline).is_err());
    assert_eq!(manager.snapshot().entries, 0);
    assert!(manager.snapshot().retention_reserved > 0);
    drop(held);
    assert_eq!(manager.snapshot().retention_reserved, 0);
    let ordinary = memory.reserve(GRANT - baseline).unwrap();
    drop(ordinary);
    drop(source);
    drop(owner);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    fs::remove_file(path).unwrap();
}

#[test]
fn physical_retention_grant_shrink_respects_live_quota_then_recovers_and_disables() {
    let path = path("grant");
    let fixture = fixture(32768, 3);
    write_fixture(&path, &fixture, "canonical", "whole_struct_flat");
    let memory = LiveMemoryPool::configurable(GRANT).unwrap();
    let owner = owner(&memory, Policy::Lru16);
    let source = owner.prepare_file(&path).unwrap();
    let manager = owner.0.physical_arrays.as_ref().unwrap();
    let held = warm(&source, &fixture);
    let retained = manager.snapshot().retention_reserved;
    assert!(retained > 2 << 20);
    assert!(memory.snapshot().reserved_bytes < 16 << 20);
    memory.set_limit_bytes(16 << 20).unwrap();
    // Shrink was below the retained quota, but above total parent live bytes.
    assert!(
        source
            .0
            .physical_arrays
            .as_ref()
            .unwrap()
            .lookup(&root_layout(&source))
            .unwrap()
            .is_none()
    );
    assert_eq!(manager.snapshot().entries, 0);
    assert_eq!(manager.snapshot().retention_reserved, retained);
    drop(held);
    assert!(
        source
            .0
            .physical_arrays
            .as_ref()
            .unwrap()
            .lookup(&root_layout(&source))
            .unwrap()
            .is_none()
    );
    assert_eq!(manager.snapshot().retention_limit, 2 << 20);
    assert_eq!(manager.snapshot().retention_reserved, 0);
    memory.set_limit_bytes(GRANT).unwrap();
    drop(warm(&source, &fixture));
    memory.set_limit_bytes(4 << 20).unwrap();
    assert!(
        source
            .0
            .physical_arrays
            .as_ref()
            .unwrap()
            .lookup(&root_layout(&source))
            .unwrap()
            .is_none()
    );
    assert_eq!(manager.snapshot().retention_reserved, 0);
    assert_eq!(manager.snapshot().table_bytes, 0);
    drop(source);
    drop(owner);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    fs::remove_file(path).unwrap();
}

#[test]
fn physical_retention_exact_source_tokens_and_layout_allocations_do_not_alias() {
    let first_path = path("identity-first");
    let second_path = path("identity-second");
    let first_fixture = fixture(4096, 3);
    let mut second_fixture = fixture(4096, 3);
    let values: Vec<_> = (0..4096).map(|row| Some(-(row as i64))).collect();
    second_fixture.columns[0].input =
        PrimitiveArray::from_option_iter(values.iter().copied()).into_array();
    second_fixture.columns[0].expected = Expected::Integers(values);
    write_fixture(
        &first_path,
        &first_fixture,
        "canonical",
        "whole_struct_flat",
    );
    write_fixture(
        &second_path,
        &second_fixture,
        "canonical",
        "whole_struct_flat",
    );
    let memory = LiveMemoryPool::new(GRANT).unwrap();
    let owner = owner(&memory, Policy::Lru16);
    let first = owner.prepare_file(&first_path).unwrap();
    let second = owner.prepare_file(&second_path).unwrap();
    let first_layout = root_layout(&first);
    let second_layout = root_layout(&second);
    assert_eq!(first_layout.segment_id(), second_layout.segment_id());
    drop(warm(&first, &first_fixture));
    let second_cache = second.0.physical_arrays.as_ref().unwrap();
    assert!(second_cache.lookup(&first_layout).unwrap().is_none());
    assert!(second_cache.lookup(&second_layout).unwrap().is_none());
    drop(warm(&second, &second_fixture));
    let new_token = owner.prepare_file(&first_path).unwrap();
    assert!(
        new_token
            .0
            .physical_arrays
            .as_ref()
            .unwrap()
            .lookup(&first_layout)
            .unwrap()
            .is_none()
    );
    let reinterpret = FlatLayout::new_with_metadata(
        first_layout.row_count() - 1,
        first_layout.dtype().clone(),
        first_layout.segment_id(),
        first_layout.array_ctx().clone(),
        first_layout.array_tree().cloned(),
    );
    assert!(!first_layout.same_allocation(&reinterpret));
    assert!(
        first
            .0
            .physical_arrays
            .as_ref()
            .unwrap()
            .lookup(&reinterpret)
            .unwrap()
            .is_none()
    );
    drop(new_token);
    drop(first);
    assert_eq!(
        owner.0.physical_arrays.as_ref().unwrap().snapshot().ready,
        1
    );
    scan(&second, &second_fixture);
    drop(second);
    assert_eq!(
        owner.0.physical_arrays.as_ref().unwrap().snapshot().entries,
        0
    );
    // Exact layout handles still own their original footer metadata credit.
    drop((first_layout, second_layout, reinterpret));
    drop(owner);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    fs::remove_file(first_path).unwrap();
    fs::remove_file(second_path).unwrap();
}

#[test]
fn physical_retention_hot_sources_reject_replace_mutate_truncate_recreate_and_symlink_aba() {
    for change in ["replace", "mutate", "truncate", "recreate", "symlink_aba"] {
        let path = path(change);
        let backup = path.with_extension("backup");
        let alternate = path.with_extension("alternate");
        let link = path.with_extension("link");
        let fixture = fixture(4096, 3);
        write_fixture(&path, &fixture, "canonical", "whole_struct_flat");
        fs::copy(&path, &backup).unwrap();
        fs::copy(&path, &alternate).unwrap();
        std::os::unix::fs::symlink(&path, &link).unwrap();
        let memory = LiveMemoryPool::new(GRANT).unwrap();
        let owner = owner(&memory, Policy::Lru16);
        let source = owner
            .prepare_file(if change == "symlink_aba" {
                &link
            } else {
                &path
            })
            .unwrap();
        let cached = warm(&source, &fixture);
        drop(cached);
        assert_eq!(
            owner.0.physical_arrays.as_ref().unwrap().snapshot().ready,
            1
        );
        match change {
            "replace" => fs::rename(&backup, &path).unwrap(),
            "recreate" => {
                fs::remove_file(&path).unwrap();
                fs::copy(&backup, &path).unwrap();
            }
            "mutate" => {
                let original = fs::metadata(&path).unwrap();
                let mut file = fs::File::options().write(true).open(&path).unwrap();
                file.seek(SeekFrom::Start(8)).unwrap();
                file.write_all(&[42]).unwrap();
                file.set_times(fs::FileTimes::new().set_modified(original.modified().unwrap()))
                    .unwrap();
            }
            "truncate" => fs::File::options()
                .write(true)
                .open(&path)
                .unwrap()
                .set_len(12)
                .unwrap(),
            "symlink_aba" => {
                fs::remove_file(&link).unwrap();
                std::os::unix::fs::symlink(&alternate, &link).unwrap();
            }
            _ => unreachable!(),
        }
        assert!(
            source
                .0
                .physical_arrays
                .as_ref()
                .unwrap()
                .lookup(&root_layout(&source))
                .is_err(),
            "{change}"
        );
        assert!(source.validate_generation().is_err(), "{change}");
        assert_eq!(
            owner.0.physical_arrays.as_ref().unwrap().snapshot().entries,
            0
        );
        assert_eq!(
            owner
                .0
                .physical_arrays
                .as_ref()
                .unwrap()
                .snapshot()
                .retention_reserved,
            0
        );
        if change == "symlink_aba" {
            fs::remove_file(&link).unwrap();
            std::os::unix::fs::symlink(&path, &link).unwrap();
        } else if change != "replace" {
            fs::copy(&backup, &path).unwrap();
        }
        assert!(
            source.validate_generation().is_err(),
            "{change}: invalidation must stay sticky"
        );
        drop(source);
        drop(owner);
        assert_eq!(memory.snapshot().reserved_bytes, 0);
        for file in [&path, &backup, &alternate, &link] {
            if fs::symlink_metadata(file).is_ok() {
                fs::remove_file(file).unwrap();
            }
        }
    }
}

#[test]
fn physical_retention_consumer_errors_and_cancellation_release_admission_and_outputs() {
    let path = path("consumer-errors");
    let fixture = fixture(4096, 3);
    write_fixture(&path, &fixture, "canonical", "whole_struct_flat");
    let memory = LiveMemoryPool::new(GRANT).unwrap();
    let owner = owner(&memory, Policy::Lru16);
    let plan = prepare(&owner, &path, "all");
    for _ in 0..3 {
        run(&plan, &fixture, "all", "native_canonical_2048");
    }
    let before = memory.snapshot().reserved_bytes;
    let error = plan
        .for_each_batch(&CancellationToken::default(), |_, _| {
            Err(shardloom_core::ShardLoomError::InvalidOperation(
                "physical retention test consumer stopped".into(),
            ))
        })
        .err()
        .expect("consumer error must propagate");
    assert!(error.to_string().contains("test consumer stopped"));
    assert_eq!(memory.snapshot().reserved_bytes, before);
    let token = CancellationToken::default();
    let mut delivered = 0;
    assert!(
        plan.for_each_batch(&token, |_, _| {
            delivered += 1;
            token.cancel();
            Ok(())
        })
        .is_err()
    );
    assert_eq!(delivered, 1);
    assert_eq!(memory.snapshot().reserved_bytes, before);
    let cancelled = CancellationToken::default();
    cancelled.cancel();
    assert!(
        plan.for_each_json_batch(&cancelled, 64, 4 << 20, |_| panic!(
            "cancelled consumer must not run"
        ))
        .is_err()
    );
    run(&plan, &fixture, "all", "json_64");
    drop(plan);
    assert_eq!(
        owner.0.physical_arrays.as_ref().unwrap().snapshot().entries,
        0
    );
    drop(owner);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    fs::remove_file(path).unwrap();
}

#[test]
fn physical_retention_concurrent_second_observations_publish_once_and_hits_share_owner() {
    let path = path("concurrent");
    let fixture = fixture(4096, 3);
    write_fixture(&path, &fixture, "canonical", "whole_struct_flat");
    let memory = LiveMemoryPool::new(GRANT).unwrap();
    let owner = owner(&memory, Policy::Lru16);
    let source = owner.prepare_file(&path).unwrap();
    scan(&source, &fixture); // First successful observation only.
    let layout = root_layout(&source);
    let cache = source.0.physical_arrays.as_ref().unwrap().clone();
    assert!(cache.lookup(&layout).unwrap().is_none());
    let (segment, array) = source
        .with_native_execution(|file, native, runtime| {
            let segment = runtime
                .block_on(file.segment_source().request(layout.segment_id()))
                .map_err(super::super::native_error)?;
            let parts = if let Some(tree) = layout.array_tree() {
                vortex::array::serde::SerializedArray::from_flatbuffer_and_segment(
                    tree.clone(),
                    segment.clone(),
                )
            } else {
                vortex::array::serde::SerializedArray::try_from(segment.clone())
            }
            .map_err(super::super::native_error)?;
            let array = parts
                .decode(layout.dtype(), fixture.rows, layout.array_ctx(), native)
                .map_err(super::super::native_error)?;
            Ok((segment, array))
        })
        .unwrap();
    let barrier = std::sync::Barrier::new(8);
    std::thread::scope(|scope| {
        for _ in 0..8 {
            scope.spawn(|| {
                barrier.wait();
                cache
                    .observe(&layout, &segment, &array, &owner.0.session)
                    .unwrap();
            });
        }
    });
    assert_eq!(
        owner
            .0
            .physical_arrays
            .as_ref()
            .unwrap()
            .snapshot()
            .counters
            .admissions,
        1
    );
    let cached = cache.lookup(&layout).unwrap().unwrap();
    std::thread::scope(|scope| {
        for _ in 0..8 {
            scope.spawn(|| {
                for _ in 0..32 {
                    assert!(ArrayRef::ptr_eq(
                        &cache.lookup(&layout).unwrap().unwrap(),
                        &cached
                    ));
                }
            });
        }
    });
    drop((cached, cache, array, segment));
    drop(layout);
    drop(source);
    drop(owner);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    fs::remove_file(path).unwrap();
}

#[test]
fn physical_retention_tiny_grant_and_primitive_only_controls_do_not_admit() {
    for (grant, width) in [(4 << 20, 3), (8 << 20, 1)] {
        let path = path(&format!("bypass-{grant}-{width}"));
        let fixture = fixture(1024, width);
        write_fixture(&path, &fixture, "canonical", "whole_struct_flat");
        let memory = LiveMemoryPool::new(grant).unwrap();
        let owner = owner(&memory, Policy::Lru16);
        let source = owner.prepare_file(&path).unwrap();
        for _ in 0..4 {
            scan(&source, &fixture);
        }
        if let Some(manager) = &owner.0.physical_arrays {
            assert_eq!(manager.snapshot().counters.admissions, 0);
            assert_eq!(manager.snapshot().retention_reserved, 0);
            assert!(manager.snapshot().counters.shape_bypasses > 0);
        } else {
            assert_eq!(grant, 4 << 20);
        }
        drop(source);
        drop(owner);
        assert_eq!(memory.snapshot().reserved_bytes, 0);
        fs::remove_file(path).unwrap();
    }
}

#[test]
fn physical_retention_unaffordable_optional_copy_preserves_native_results() {
    let path = path("quota-denial");
    let fixture = fixture(32768, 3);
    write_fixture(&path, &fixture, "canonical", "whole_struct_flat");
    let memory = LiveMemoryPool::new(8 << 20).unwrap();
    let owner = owner(&memory, Policy::Lru16);
    let source = owner.prepare_file(&path).unwrap();
    for _ in 0..4 {
        scan(&source, &fixture);
    }
    let observed = owner.0.physical_arrays.as_ref().unwrap().snapshot();
    assert_eq!(observed.counters.admissions, 0);
    assert_eq!(observed.retention_reserved, 0);
    assert!(observed.counters.shape_bypasses + observed.counters.pressure_bypasses > 0);
    drop(source);
    drop(owner);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    fs::remove_file(path).unwrap();
}

#[test]
fn physical_retention_malformed_serialized_payload_preserves_native_error_and_never_admits() {
    let path = path("malformed");
    let fixture = fixture(4096, 3);
    write_fixture(&path, &fixture, "canonical", "whole_struct_flat");
    let inspector = owner(&LiveMemoryPool::new(GRANT).unwrap(), Policy::None);
    let source = inspector.prepare_file(&path).unwrap();
    let spec = source.0.file.footer().segment_map()[0];
    drop(source);
    drop(inspector);
    let mut file = fs::File::options().write(true).open(&path).unwrap();
    file.seek(SeekFrom::Start(spec.offset)).unwrap();
    file.write_all(&vec![0xff; spec.length as usize]).unwrap();
    drop(file);
    let mut errors = Vec::new();
    for policy in [Policy::None, Policy::One, Policy::Lru16] {
        let memory = LiveMemoryPool::new(GRANT).unwrap();
        let owner = owner(&memory, policy);
        let source = owner.prepare_file(&path).unwrap();
        for _ in 0..3 {
            let error = source
                .with_native_execution(|file, _, runtime| {
                    file.scan()
                        .map_err(super::super::native_error)?
                        .into_array_iter(runtime)
                        .map_err(super::super::native_error)?
                        .map(|array| array.map_err(super::super::native_error))
                        .collect::<shardloom_core::Result<Vec<_>>>()
                })
                .unwrap_err();
            errors.push(error.to_string());
        }
        if let Some(manager) = &owner.0.physical_arrays {
            assert_eq!(manager.snapshot().counters.admissions, 0);
            assert_eq!(manager.snapshot().entries, 0);
            assert_eq!(manager.snapshot().retention_reserved, 0);
        }
        drop(source);
        drop(owner);
        assert_eq!(memory.snapshot().reserved_bytes, 0);
    }
    assert!(errors.iter().all(|error| error == &errors[0]));
    fs::remove_file(path).unwrap();
}

fn raw_payload(source: &PreparedVortexSource) -> (vortex::array::buffer::BufferHandle, ArrayRef) {
    let layout = root_layout(source);
    source
        .with_native_execution(|file, native, runtime| {
            let segment = runtime
                .block_on(file.segment_source().request(layout.segment_id()))
                .map_err(super::super::native_error)?;
            let parts = if let Some(tree) = layout.array_tree() {
                vortex::array::serde::SerializedArray::from_flatbuffer_and_segment(
                    tree.clone(),
                    segment.clone(),
                )
            } else {
                vortex::array::serde::SerializedArray::try_from(segment.clone())
            }
            .map_err(super::super::native_error)?;
            let array = parts
                .decode(
                    layout.dtype(),
                    layout.row_count() as usize,
                    layout.array_ctx(),
                    native,
                )
                .map_err(super::super::native_error)?;
            Ok((segment, array))
        })
        .unwrap()
}

#[test]
fn physical_retention_table_and_admission_pressure_leave_original_array_authoritative() {
    for stage in ["table", "metadata", "payload"] {
        let path = path(&format!("allocation-denial-{stage}"));
        let fixture = fixture(4096, 3);
        write_fixture(&path, &fixture, "canonical", "whole_struct_flat");
        let memory = LiveMemoryPool::new(GRANT).unwrap();
        let owner = owner(&memory, Policy::Lru16);
        let source = owner.prepare_file(&path).unwrap();
        let layout = root_layout(&source);
        let cache = source.0.physical_arrays.as_ref().unwrap();
        let (segment, array) = raw_payload(&source);
        let baseline = memory.snapshot().reserved_bytes;
        if stage != "table" {
            cache
                .observe(&layout, &segment, &array, &owner.0.session)
                .unwrap();
            assert_eq!(
                owner.0.physical_arrays.as_ref().unwrap().snapshot().entries,
                1
            );
        }
        // The frozen 4,096-row fixture's metadata fits in three segment lengths;
        // its metadata plus copied payload does not. Zero slack denies metadata.
        let headroom = if stage == "payload" {
            3 * segment.len() as u64
        } else {
            0
        };
        let blocker = memory
            .reserve(GRANT - memory.snapshot().reserved_bytes - headroom)
            .unwrap();
        let denied = memory.snapshot().denied_reservations;
        cache
            .observe(&layout, &segment, &array, &owner.0.session)
            .unwrap();
        assert!(memory.snapshot().denied_reservations > denied, "{stage}");
        let observed = owner.0.physical_arrays.as_ref().unwrap().snapshot();
        assert_eq!(observed.counters.admissions, 0);
        assert_eq!(observed.entries, 0);
        assert_eq!(observed.retention_reserved, 0);
        drop(blocker);
        assert_eq!(memory.snapshot().reserved_bytes, baseline, "{stage}");
        let verifier_memory = LiveMemoryPool::new(GRANT).unwrap();
        let verifier = session(&verifier_memory);
        for column in &fixture.columns {
            let fields = array.as_::<vortex::array::arrays::Struct>();
            verify_column(
                fields.unmasked_field_by_name(&column.name).unwrap().clone(),
                column,
                0,
                &mut verifier.create_execution_ctx(),
            );
        }
        drop(verifier);
        assert_eq!(verifier_memory.snapshot().reserved_bytes, 0);
        drop((segment, array, layout));
        scan(&source, &fixture);
        drop(source);
        drop(owner);
        assert_eq!(memory.snapshot().reserved_bytes, 0);
        fs::remove_file(path).unwrap();
    }
}

#[derive(Debug, PartialEq, Eq, Hash)]
struct NoCopyDevice(usize);

impl vortex::array::buffer::DeviceBuffer for NoCopyDevice {
    fn as_any(&self) -> &dyn std::any::Any {
        self
    }
    fn len(&self) -> usize {
        self.0
    }
    fn alignment(&self) -> vortex::buffer::Alignment {
        vortex::buffer::Alignment::new(256)
    }
    fn copy_to_host_sync(
        &self,
        _: vortex::buffer::Alignment,
    ) -> vortex::error::VortexResult<vortex::buffer::ByteBuffer> {
        panic!("optional physical retention must not copy device data")
    }
    fn copy_to_host(
        &self,
        _: vortex::buffer::Alignment,
    ) -> vortex::error::VortexResult<
        futures::future::BoxFuture<
            'static,
            vortex::error::VortexResult<vortex::buffer::ByteBuffer>,
        >,
    > {
        panic!("optional physical retention must not schedule device data")
    }
    fn slice(&self, range: std::ops::Range<usize>) -> Arc<dyn vortex::array::buffer::DeviceBuffer> {
        assert!(range.start <= range.end && range.end <= self.0);
        Arc::new(Self(range.end - range.start))
    }
    fn aligned(
        self: Arc<Self>,
        alignment: vortex::buffer::Alignment,
    ) -> vortex::error::VortexResult<Arc<dyn vortex::array::buffer::DeviceBuffer>> {
        assert!(*alignment <= 256);
        Ok(self)
    }
}

#[test]
fn physical_retention_device_segments_and_arrays_bypass_without_copying() {
    use vortex::array::{ArrayVTable as _, buffer::BufferHandle};
    let path = path("device");
    let fixture = fixture(4096, 3);
    write_fixture(&path, &fixture, "canonical", "whole_struct_flat");
    let memory = LiveMemoryPool::new(GRANT).unwrap();
    let owner = owner(&memory, Policy::Lru16);
    let source = owner.prepare_file(&path).unwrap();
    let layout = root_layout(&source);
    let (segment, array) = raw_payload(&source);
    let device_segment = BufferHandle::new_device(Arc::new(NoCopyDevice(segment.len())));
    let buffers = [
        BufferHandle::new_device(Arc::new(NoCopyDevice(28))),
        BufferHandle::new_device(Arc::new(NoCopyDevice(32))),
    ];
    let dtype = DType::Utf8(Nullability::NonNullable);
    let device_array = VarBinViewArray::try_from_parts(
        VarBinView
            .deserialize(
                &dtype,
                2,
                &[],
                &buffers,
                &Vec::<ArrayRef>::new(),
                &owner.0.session,
            )
            .unwrap(),
    )
    .unwrap()
    .into_array();
    let device_layout = FlatLayout::new(2, dtype, layout.segment_id(), layout.array_ctx().clone());
    let cache = source.0.physical_arrays.as_ref().unwrap();
    for _ in 0..2 {
        cache
            .observe(&layout, &device_segment, &array, &owner.0.session)
            .unwrap();
        cache
            .observe(&device_layout, &segment, &device_array, &owner.0.session)
            .unwrap();
    }
    let observed = owner.0.physical_arrays.as_ref().unwrap().snapshot();
    assert_eq!(observed.counters.shape_bypasses, 4);
    assert_eq!(observed.counters.copied_bytes, 0);
    assert_eq!(observed.counters.admissions, 0);
    assert_eq!(observed.entries, 0);
    assert_eq!(observed.retention_reserved, 0);
    drop((
        device_array,
        device_layout,
        device_segment,
        buffers,
        segment,
        array,
        layout,
    ));
    drop(source);
    drop(owner);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    fs::remove_file(path).unwrap();
}
