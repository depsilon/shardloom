//! Admitted native physical arrays; frozen comparison physical-retention-752-v1.
//! No readers, I/O scopes, futures, decoded results or source authority are cached.

use super::{PhysicalArrayRetentionSnapshot, SourceIdentity};
use crate::{native_payload_schema, owned_buffers::ReservedHostAllocator};
use shardloom_exec::live_memory::{IdleMemoryReclaimer, LiveMemoryPool, MemoryLease};
use std::sync::{
    Arc, Mutex,
    atomic::{AtomicU64, Ordering},
};
use vortex::{
    array::{
        Array, ArrayRef, ArrayVTable, ArrayView, IntoArray as _,
        arrays::{Bool, Primitive, Struct, VarBinView},
        buffer::BufferHandle,
        memory::HostAllocator as _,
        serde::SerializedArray,
    },
    buffer::{Alignment, ByteBuffer},
    error::{VortexResult, vortex_err},
    layout::{layouts::flat::FlatLayout, segments::PhysicalArrayRetention},
    session::VortexSession,
};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) enum Policy {
    None,
    One,
    #[cfg(test)]
    Lru16,
}

impl Policy {
    fn entries(self) -> usize {
        match self {
            Self::None => 0,
            Self::One => 1,
            #[cfg(test)]
            Self::Lru16 => 16,
        }
    }

    fn label(self) -> &'static str {
        match self {
            Self::None => "not_admitted",
            Self::One => "second_observation_one_entry",
            #[cfg(test)]
            Self::Lru16 => "experimental_second_observation_sixteen_entries",
        }
    }
}

#[derive(Debug, Default, Clone, Copy, serde::Serialize)]
pub(super) struct Counters {
    pub hits: u64,
    pub misses: u64,
    pub first_observations: u64,
    pub admissions: u64,
    pub copied_bytes: u64,
    pub evictions: u64,
    pub reclaims: u64,
    pub invalidations: u64,
    pub pressure_bypasses: u64,
    pub shape_bypasses: u64,
    pub stale_admissions: u64,
}

#[derive(Debug, Clone, serde::Serialize)]
#[cfg(all(test, feature = "physical-reconstruction-profile"))]
pub(super) struct Snapshot {
    pub counters: Counters,
    pub entries: usize,
    pub ready: usize,
    pub table_bytes: u64,
    pub retention_reserved: u64,
    pub retention_peak: u64,
    pub retention_limit: u64,
}

enum Value {
    Seen,
    Building(u64),
    Ready(ArrayRef),
    Bypassed,
}
struct Entry {
    source: u64,
    layout: FlatLayout,
    accessed: u64,
    value: Value,
}
struct Table {
    entries: Vec<Entry>,
    _credit: MemoryLease,
}
struct State {
    table: Option<Table>,
    tick: u64,
    counters: Counters,
}

pub(super) struct Manager {
    memory: LiveMemoryPool,
    retention: LiveMemoryPool,
    policy: Policy,
    next_source: AtomicU64,
    state: Mutex<State>,
}

impl std::fmt::Debug for Manager {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("PhysicalArrayRetention")
            .field("policy", &self.policy)
            .finish_non_exhaustive()
    }
}

impl Manager {
    pub(super) fn report(&self) -> PhysicalArrayRetentionSnapshot {
        let state = self
            .state
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        let retained = self.retention.snapshot();
        let allowed = (self.memory.snapshot().limit_bytes / 8).min(64 << 20);
        PhysicalArrayRetentionSnapshot {
            policy: self.policy.label(),
            capacity_entries: self.policy.entries(),
            entries: state.table.as_ref().map_or(0, |t| t.entries.len()),
            ready_entries: state.table.as_ref().map_or(0, |t| {
                t.entries
                    .iter()
                    .filter(|e| matches!(e.value, Value::Ready(_)))
                    .count()
            }),
            admission_limit_bytes: if allowed >= 1 << 20 { allowed } else { 0 },
            retained_owner_charged_bytes: retained.reserved_bytes,
            retained_owner_peak_charged_bytes: retained.peak_reserved_bytes,
            table_charged_bytes: state.table.as_ref().map_or(0, |t| t._credit.bytes()),
            lookup_hits: state.counters.hits,
            lookup_misses: state.counters.misses,
            admissions: state.counters.admissions,
            copied_serialized_bytes: state.counters.copied_bytes,
            evictions: state.counters.evictions,
            pressure_reclaims: state.counters.reclaims,
            invalidations: state.counters.invalidations,
            pressure_bypasses: state.counters.pressure_bypasses,
            shape_bypasses: state.counters.shape_bypasses,
        }
    }

    pub(super) fn new(memory: &LiveMemoryPool, policy: Policy) -> Option<Arc<Self>> {
        let limit = (memory.snapshot().limit_bytes / 8).min(64 << 20);
        if policy == Policy::None || limit < 1 << 20 {
            return None;
        }
        let manager = Arc::new(Self {
            memory: memory.clone(),
            retention: LiveMemoryPool::configurable(limit).ok()?,
            policy,
            next_source: AtomicU64::new(1),
            state: Mutex::new(State {
                table: None,
                tick: 0,
                counters: Counters::default(),
            }),
        });
        let erased: Arc<dyn IdleMemoryReclaimer> = manager.clone();
        memory
            .register_idle_reclaimer(Arc::downgrade(&erased))
            .ok()?;
        Some(manager)
    }

    pub(super) fn source(
        self: &Arc<Self>,
        identity: Arc<SourceIdentity>,
    ) -> Option<Arc<SourceCache>> {
        let mut id = self.next_source.load(Ordering::Relaxed);
        loop {
            let next = id.checked_add(1)?;
            match self.next_source.compare_exchange_weak(
                id,
                next,
                Ordering::Relaxed,
                Ordering::Relaxed,
            ) {
                Ok(_) => break,
                Err(observed) => id = observed,
            }
        }
        Some(Arc::new(SourceCache {
            manager: Arc::clone(self),
            identity,
            id,
        }))
    }

    fn table(&self) -> bool {
        if self.state.lock().is_ok_and(|s| s.table.is_some()) {
            return true;
        }
        let bytes = (self.policy.entries() * std::mem::size_of::<Entry>()) as u64;
        let Ok(credit) = self.memory.reserve(bytes) else {
            return false;
        };
        let mut entries = Vec::new();
        if entries.try_reserve_exact(self.policy.entries()).is_err()
            || entries.capacity() > self.policy.entries()
        {
            return false;
        }
        let Ok(mut state) = self.state.lock() else {
            return false;
        };
        if state.table.is_none() {
            state.table = Some(Table {
                entries,
                _credit: credit,
            });
        }
        true
    }

    fn refresh_limit(&self) -> bool {
        let allowed = (self.memory.snapshot().limit_bytes / 8).min(64 << 20);
        if allowed < 1 << 20 {
            self.reclaim_idle();
            return false;
        }
        if self.retention.snapshot().limit_bytes != allowed {
            self.reclaim_idle();
            // Live evicted consumers cannot lose their credit on grant shrink.
            // Until they fit, ordinary execution proceeds without new retention.
            return self.retention.set_limit_bytes(allowed).is_ok();
        }
        true
    }

    fn evict_one(&self) -> bool {
        let Ok(mut state) = self.state.lock() else {
            return false;
        };
        let Some(table) = state.table.as_mut() else {
            return false;
        };
        let index = table
            .entries
            .iter()
            .enumerate()
            .filter(|(_, e)| !matches!(e.value, Value::Building(_)))
            .min_by_key(|(_, e)| e.accessed)
            .map(|(i, _)| i);
        let Some(index) = index else {
            return false;
        };
        table.entries.remove(index);
        state.counters.evictions += 1;
        true
    }

    fn remove_source(&self, source: u64) {
        if let Ok(mut state) = self.state.lock() {
            if let Some(table) = state.table.as_mut() {
                table.entries.retain(|e| e.source != source);
                if table.entries.is_empty() {
                    // Source close/invalidation releases the final table credit
                    // even when the shared runtime remains alive.
                    state.table = None;
                }
            }
        }
    }

    #[cfg(all(test, feature = "physical-reconstruction-profile"))]
    pub(super) fn snapshot(&self) -> Snapshot {
        let state = self
            .state
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        let retained = self.retention.snapshot();
        Snapshot {
            counters: state.counters,
            entries: state.table.as_ref().map_or(0, |t| t.entries.len()),
            ready: state.table.as_ref().map_or(0, |t| {
                t.entries
                    .iter()
                    .filter(|e| matches!(e.value, Value::Ready(_)))
                    .count()
            }),
            table_bytes: state.table.as_ref().map_or(0, |t| t._credit.bytes()),
            retention_reserved: retained.reserved_bytes,
            retention_peak: retained.peak_reserved_bytes,
            retention_limit: retained.limit_bytes,
        }
    }
}

impl IdleMemoryReclaimer for Manager {
    fn reclaim_idle(&self) -> bool {
        let Ok(mut state) = self.state.try_lock() else {
            return false;
        };
        let Some(table) = state.table.take() else {
            return false;
        };
        drop(table);
        state.counters.reclaims += 1;
        true
    }
}

pub(super) struct SourceCache {
    manager: Arc<Manager>,
    identity: Arc<SourceIdentity>,
    id: u64,
}

impl SourceCache {
    pub(super) fn invalidate(&self) {
        self.manager.remove_source(self.id);
        if let Ok(mut state) = self.manager.state.lock() {
            state.counters.invalidations += 1;
        }
    }

    fn validate(&self) -> VortexResult<()> {
        if let Err(error) = self.identity.validate() {
            self.invalidate();
            return Err(vortex_err!("{error}"));
        }
        Ok(())
    }

    fn ticket(&self, layout: &FlatLayout) -> Option<u64> {
        if !self.manager.table() {
            return None;
        }
        let mut state = self.manager.state.lock().ok()?;
        state.tick = state.tick.checked_add(1)?;
        let tick = state.tick;
        let table = state.table.as_mut()?;
        if let Some(entry) = table
            .entries
            .iter_mut()
            .find(|e| e.source == self.id && e.layout.same_allocation(layout))
        {
            if matches!(entry.value, Value::Seen) {
                entry.value = Value::Building(tick);
                entry.accessed = tick;
                return Some(tick);
            }
            return None;
        }
        if table.entries.len() == self.manager.policy.entries() {
            let index = table
                .entries
                .iter()
                .enumerate()
                .filter(|(_, e)| !matches!(e.value, Value::Building(_)))
                .min_by_key(|(_, e)| e.accessed)
                .map(|(i, _)| i)?;
            table.entries.remove(index);
            state.counters.evictions += 1;
        }
        state.table.as_mut()?.entries.push(Entry {
            source: self.id,
            layout: layout.clone(),
            accessed: tick,
            value: Value::Seen,
        });
        state.counters.first_observations += 1;
        None
    }

    fn construct(
        &self,
        layout: &FlatLayout,
        segment: &BufferHandle,
        array: &ArrayRef,
        session: &VortexSession,
    ) -> VortexResult<Option<ArrayRef>> {
        let Some(host) = segment.as_host_opt() else {
            return Ok(None);
        };
        let alignment = *host.alignment().max(Alignment::DEFAULT_ALIGNMENT);
        let Some(bounds) = bounds(array, segment.len(), alignment) else {
            return Ok(None);
        };
        let quota = bounds.total;
        let mut retention = self.manager.retention.reserve(quota).ok();
        for _ in 0..self.manager.policy.entries() {
            if retention.is_some() || !self.manager.evict_one() {
                break;
            }
            retention = self.manager.retention.reserve(quota).ok();
        }
        let Some(retention) = retention else {
            return Ok(None);
        };
        let Ok(metadata) = self.manager.memory.reserve(bounds.metadata) else {
            return Ok(None);
        };
        let credit = Arc::new(Credit {
            _metadata: metadata,
            _retention: retention,
        });
        let allocator = ReservedHostAllocator::new(self.manager.memory.clone());
        let mut copied = match allocator.allocate(host.len(), host.alignment()) {
            Ok(buffer) => buffer,
            Err(error) if crate::owned_buffers::is_owned_reservation_denial(&error) => {
                return Ok(None);
            }
            Err(error) => return Err(error),
        };
        copied.as_mut_slice().copy_from_slice(host.as_slice());
        let copied = retain_buffer(copied.freeze(), &credit);
        let parts = if let Some(tree) = layout.array_tree() {
            SerializedArray::from_flatbuffer_and_segment(
                tree.clone(),
                BufferHandle::new_host(copied),
            )?
        } else {
            SerializedArray::try_from(BufferHandle::new_host(copied))?
        };
        let decoded = match parts.decode(layout.dtype(), array.len(), layout.array_ctx(), session) {
            Ok(array) => array,
            Err(error) if crate::owned_buffers::is_owned_reservation_denial(&error) => {
                return Ok(None);
            }
            Err(error) => return Err(error),
        };
        let retained = match retain_tree(&decoded, &credit) {
            Ok(array) => array,
            Err(error) if crate::owned_buffers::is_owned_reservation_denial(&error) => {
                return Ok(None);
            }
            Err(error) => return Err(error),
        };
        self.validate()?;
        Ok(Some(retained))
    }
}

impl Drop for SourceCache {
    fn drop(&mut self) {
        self.manager.remove_source(self.id);
    }
}

impl PhysicalArrayRetention for SourceCache {
    fn lookup(&self, layout: &FlatLayout) -> VortexResult<Option<ArrayRef>> {
        if !self.manager.refresh_limit() {
            return Ok(None);
        }
        let cached = {
            let mut state = self
                .manager
                .state
                .lock()
                .map_err(|_| vortex_err!("physical retention state poisoned"))?;
            state.tick = state
                .tick
                .checked_add(1)
                .ok_or_else(|| vortex_err!("physical retention access counter overflow"))?;
            let tick = state.tick;
            let cached = state
                .table
                .as_mut()
                .and_then(|t| {
                    t.entries
                        .iter_mut()
                        .find(|e| e.source == self.id && e.layout.same_allocation(layout))
                })
                .and_then(|entry| {
                    entry.accessed = tick;
                    if let Value::Ready(array) = &entry.value {
                        Some(array.clone())
                    } else {
                        None
                    }
                });
            if cached.is_some() {
                state.counters.hits += 1;
            } else {
                state.counters.misses += 1;
            }
            cached
        };
        if cached.is_some() {
            self.validate()?;
        }
        Ok(cached)
    }

    fn observe(
        &self,
        layout: &FlatLayout,
        segment: &BufferHandle,
        array: &ArrayRef,
        session: &VortexSession,
    ) -> VortexResult<()> {
        if !self.manager.refresh_limit() {
            return Ok(());
        }
        let max_segment = (self.manager.retention.snapshot().limit_bytes / 2).min(16 << 20);
        if segment.len() as u64 > max_segment
            || segment.as_host_opt().is_none_or(|host| {
                bounds(
                    array,
                    segment.len(),
                    *host.alignment().max(Alignment::DEFAULT_ALIGNMENT),
                )
                .is_none()
            })
        {
            if let Ok(mut state) = self.manager.state.lock() {
                state.counters.shape_bypasses += 1;
            }
            return Ok(());
        }
        let Some(ticket) = self.ticket(layout) else {
            return Ok(());
        };
        self.validate()?;
        let retained = self.construct(layout, segment, array, session)?;
        let mut state = self
            .manager
            .state
            .lock()
            .map_err(|_| vortex_err!("physical retention state poisoned"))?;
        let entry = state.table.as_mut().and_then(|t| {
            t.entries.iter_mut().find(|e| {
                e.source == self.id
                    && e.layout.same_allocation(layout)
                    && matches!(e.value, Value::Building(value) if value == ticket)
            })
        });
        if let Some(entry) = entry {
            if let Some(array) = retained {
                entry.value = Value::Ready(array);
                state.counters.admissions += 1;
                state.counters.copied_bytes += segment.len() as u64;
            } else {
                entry.value = Value::Bypassed;
                state.counters.pressure_bypasses += 1;
            }
        } else {
            state.counters.stale_admissions += 1;
        }
        Ok(())
    }
}

struct Bounds {
    metadata: u64,
    total: u64,
}

fn bounds(array: &ArrayRef, serialized: usize, alignment: usize) -> Option<Bounds> {
    fn visit(array: &ArrayRef, depth: usize, totals: &mut [u64; 6]) -> Option<()> {
        if depth > 4
            || array.is_empty()
            || !matches!(
                array.encoding_id().as_ref(),
                "vortex.primitive" | "vortex.bool" | "vortex.struct" | "vortex.varbinview"
            )
        {
            return None;
        }
        totals[0] = totals[0].checked_add(1)?;
        totals[1] = totals[1].checked_add(array.slots().len() as u64)?;
        totals[2] = totals[2].checked_add(array.nbuffers() as u64)?;
        if totals[..3].iter().any(|n| *n > 128) {
            return None;
        }
        totals[3] = totals[3]
            .checked_add(native_payload_schema::encoded_schema_bytes(array.dtype()).ok()?)?;
        for index in 0..array.nbuffers() {
            let host = if let Some(value) = array.as_opt::<Primitive>() {
                Primitive::buffer(value, index).is_on_host()
            } else if let Some(value) = array.as_opt::<Bool>() {
                Bool::buffer(value, index).is_on_host()
            } else if let Some(value) = array.as_opt::<VarBinView>() {
                VarBinView::buffer(value, index).is_on_host()
            } else {
                return None;
            };
            if !host {
                return None;
            }
        }
        if array.is::<VarBinView>() {
            totals[4] = totals[4].checked_add(1)?;
            // validate_and_fix may replace shared null views outside the host
            // allocator. Cover that bounded buffer before repeating validation.
            totals[5] =
                totals[5].checked_add((array.len() as u64).checked_mul(16)?.checked_add(64)?)?;
        }
        for child in array.children_iter() {
            visit(child, depth + 1, totals)?;
        }
        Some(())
    }
    let mut n = [0u64; 6];
    visit(array, 0, &mut n)?;
    if n[4] == 0 {
        return None;
    }
    let metadata = (serialized as u64)
        .checked_mul(2)?
        .checked_add(n[0].checked_mul(4096)?)?
        .checked_add(n[1].checked_mul(256)?)?
        .checked_add(n[2].checked_mul(512)?)?
        .checked_add(n[3].checked_mul(2)?)?
        .checked_add(n[5])?;
    let payload = (serialized as u64).checked_add(alignment as u64)?;
    let provider_tables = n[2].checked_mul(512)?;
    Some(Bounds {
        metadata,
        total: metadata
            .checked_add(payload)?
            .checked_add(provider_tables)?,
    })
}

struct Credit {
    _metadata: MemoryLease,
    _retention: MemoryLease,
}
struct RetainedBuffer {
    buffer: ByteBuffer,
    _credit: Arc<Credit>,
}
impl AsRef<[u8]> for RetainedBuffer {
    fn as_ref(&self) -> &[u8] {
        self.buffer.as_slice()
    }
}

fn retain_buffer(buffer: ByteBuffer, credit: &Arc<Credit>) -> ByteBuffer {
    let alignment = buffer.alignment();
    ByteBuffer::from_bytes_aligned(
        bytes::Bytes::from_owner(RetainedBuffer {
            buffer,
            _credit: Arc::clone(credit),
        }),
        alignment,
    )
}

fn retain_tree(array: &ArrayRef, credit: &Arc<Credit>) -> VortexResult<ArrayRef> {
    fn retain<V: ArrayVTable>(
        vtable: &V,
        array: ArrayView<'_, V>,
        credit: &Arc<Credit>,
    ) -> VortexResult<ArrayRef> {
        let buffers = array
            .as_ref()
            .buffers()
            .into_iter()
            .map(|buffer| BufferHandle::new_host(retain_buffer(buffer, credit)))
            .collect::<Vec<_>>();
        let mut parts = vtable.with_buffers(array, &buffers)?;
        for child in parts.slots.iter_mut().flatten() {
            *child = retain_tree(child, credit)?;
        }
        let retained = Array::<V>::try_from_parts(parts)?;
        retained.statistics().inherit_from(array.statistics());
        retained.into_array().with_retained_owner(credit.clone())
    }
    if let Some(array) = array.as_opt::<Primitive>() {
        retain(&Primitive, array, credit)
    } else if let Some(array) = array.as_opt::<Bool>() {
        retain(&Bool, array, credit)
    } else if let Some(array) = array.as_opt::<Struct>() {
        retain(&Struct, array, credit)
    } else if let Some(array) = array.as_opt::<VarBinView>() {
        retain(&VarBinView, array, credit)
    } else {
        Err(vortex_err!(
            "physical retention encountered an unadmitted encoding"
        ))
    }
}
