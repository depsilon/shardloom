//! Complete native caller checks for frozen physical-retention-752-v1.
use super::super::physical_retention::Policy;
use super::*;

fn owner(memory: &LiveMemoryPool, policy: Policy) -> ResidentVortexSession {
    ResidentVortexSession::with_memory_pool_retention(memory.clone(), 1, true, policy).unwrap()
}

fn run(prepared: &PreparedVortexRelational, fixture: &Fixture, projection: &str, consumer: &str) {
    operation_policy(
        prepared,
        fixture,
        projection,
        &expected_json(fixture, projection),
        consumer,
        &Profile::default(),
        false,
        true,
    );
}

#[test]
fn physical_retention_complete_native_values_second_admission_and_source_drop() {
    let root = std::env::temp_dir().join(format!("sl-physical-retention-{}", std::process::id()));
    fs::create_dir(&root).unwrap();
    for layout in ["whole_struct_flat", "columnar_table_flat"] {
        for policy in [Policy::None, Policy::One, Policy::Lru16] {
            let fixture = fixture(4096, 3);
            let path = root.join(format!("{layout}-{policy:?}.vortex"));
            write_fixture(&path, &fixture, "canonical", layout);
            let memory = LiveMemoryPool::new(GRANT).unwrap();
            let owner = owner(&memory, policy);
            let plan = prepare(&owner, &path, "all");
            for consumer in ["native_canonical_2048", "json_2048", "json_64"] {
                for _ in 0..3 {
                    run(&plan, &fixture, "all", consumer);
                }
            }
            if let Some(manager) = &owner.0.physical_arrays {
                let snapshot = manager.snapshot();
                eprintln!(
                    "physical retention smoke {layout} {policy:?}: {}",
                    serde_json::to_string(&snapshot).unwrap()
                );
                if layout == "whole_struct_flat" || policy == Policy::Lru16 {
                    assert!(snapshot.counters.admissions > 0);
                    assert!(snapshot.counters.hits > 0);
                    assert!(snapshot.retention_reserved > 0);
                }
                assert!(snapshot.retention_peak <= snapshot.retention_limit);
            }
            drop(plan);
            if let Some(manager) = &owner.0.physical_arrays {
                assert_eq!(manager.snapshot().entries, 0);
                assert_eq!(manager.snapshot().retention_reserved, 0);
            }
            drop(owner);
            assert_eq!(memory.snapshot().reserved_bytes, 0);
            fs::remove_file(path).unwrap();
        }
    }
    fs::remove_dir(root).unwrap();
}

#[test]
fn physical_retention_encoded_controls_remain_uncached() {
    let path = std::env::temp_dir().join(format!(
        "sl-physical-retention-zstd-{}.vortex",
        std::process::id()
    ));
    let fixture = fixture(4096, 3);
    write_fixture(&path, &fixture, "zstd_dictionary", "whole_struct_flat");
    let memory = LiveMemoryPool::new(GRANT).unwrap();
    let owner = owner(&memory, Policy::Lru16);
    let plan = prepare(&owner, &path, "all");
    for _ in 0..4 {
        run(&plan, &fixture, "all", "native_canonical_2048");
    }
    let snapshot = owner.0.physical_arrays.as_ref().unwrap().snapshot();
    assert_eq!(snapshot.counters.hits, 0);
    assert_eq!(snapshot.counters.admissions, 0);
    assert_eq!(snapshot.retention_reserved, 0);
    assert!(snapshot.counters.shape_bypasses > 0);
    drop(plan);
    drop(owner);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    fs::remove_file(path).unwrap();
}
