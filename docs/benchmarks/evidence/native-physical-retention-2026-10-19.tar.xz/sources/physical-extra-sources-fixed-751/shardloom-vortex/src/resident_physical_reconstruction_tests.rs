// SPDX-License-Identifier: Apache-2.0
//! Temporary complete-workflow attribution; frozen protocol 750.

use super::ResidentVortexSession;
use crate::{
    local_primitives::prepared_relational::{
        PreparedVortexRelational, prepare_relational_in_session,
    },
    owned_buffers::ReservedHostAllocator,
    relational_query::{VortexRelationalPlan, VortexRelationalScan},
};
use sha2::{Digest as _, Sha256};
use shardloom_core::{ColumnRef, DatasetUri};
use shardloom_exec::{compute_pool::CancellationToken, live_memory::LiveMemoryPool};
use shardloom_plan::ProjectionRequest;
use std::{fs, path::Path, sync::Arc, time::Instant};
use vortex::{
    VortexSessionDefault as _,
    array::{
        ArrayRef, Canonical, ExecutionCtx, IntoArray as _, VortexSessionExecute as _,
        arrays::{
            Primitive, PrimitiveArray, StructArray, VarBinView, VarBinViewArray,
            struct_::StructArrayExt as _,
        },
        dtype::{DType, Nullability},
        memory::MemorySessionExt as _,
        validity::Validity,
    },
    encodings::zstd::{Zstd, ZstdData},
    file::WriteOptionsSessionExt as _,
    io::{
        runtime::{BlockingRuntime as _, current::CurrentThreadRuntime},
        session::RuntimeSessionExt as _,
    },
    layout::{
        LayoutStrategy,
        layouts::{flat::writer::FlatLayoutStrategy, table::TableStrategy},
        reconstruction_profile::{Profile, Snapshot, Span, Stage},
    },
    session::VortexSession,
};

const GRANT: u64 = 256 << 20;

enum Expected {
    Integers(Vec<Option<i64>>),
    Bytes(Vec<Option<Vec<u8>>>),
}

struct Column {
    name: String,
    input: ArrayRef,
    expected: Expected,
}

struct Fixture {
    columns: Vec<Column>,
    rows: usize,
}

fn fixture(rows: usize, width: usize) -> Fixture {
    let columns = (0..width)
        .map(|column| {
            let name = format!("field_{column:02}");
            if column % 3 == 0 {
                let values: Vec<_> = (0..rows)
                    .map(|row| {
                        (row % 17 != column % 17).then_some(match row % 19 {
                            0 => i64::MIN,
                            1 => i64::MAX,
                            _ => {
                                i64::try_from(row).unwrap().wrapping_mul(1_234_567_891)
                                    ^ i64::try_from(column * 997 + row / 31).unwrap()
                            }
                        })
                    })
                    .collect();
                return Column {
                    name,
                    input: PrimitiveArray::from_option_iter(values.iter().copied()).into_array(),
                    expected: Expected::Integers(values),
                };
            }
            let values: Vec<_> = (0..rows)
                .map(|row| {
                    (row % 13 != column % 13).then(|| {
                        if row % 29 == 0 {
                            return Vec::new();
                        }
                        let mut value =
                            format!("{column:02}/λ/{}\0{:03}", row % 997, row % 37).into_bytes();
                        if column % 3 == 2 {
                            value.extend_from_slice(&[0x80, 0xff, (row % 256) as u8]);
                        }
                        value
                    })
                })
                .collect();
            let input = if column % 3 == 2 {
                VarBinViewArray::from_iter_nullable_bin(values.iter().map(Option::as_deref))
            } else {
                VarBinViewArray::from_iter_nullable_str(values.iter().map(|value| {
                    value
                        .as_deref()
                        .map(|bytes| std::str::from_utf8(bytes).unwrap())
                }))
            }
            .into_array();
            Column {
                name,
                input,
                expected: Expected::Bytes(values),
            }
        })
        .collect();
    Fixture { columns, rows }
}

fn sha(bytes: &[u8]) -> String {
    Sha256::digest(bytes)
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect()
}

fn session(memory: &LiveMemoryPool) -> VortexSession {
    let session = VortexSession::default()
        .with_allocator(Arc::new(ReservedHostAllocator::new(memory.clone())));
    crate::native_provider_memory::install(&session, memory.clone());
    session
}

fn encoded(
    column: &Column,
    encoding: &str,
    frame_rows: usize,
    context: &mut ExecutionCtx,
) -> ArrayRef {
    if encoding == "canonical" {
        return column.input.clone();
    }
    let result = if let Some(values) = column.input.as_opt::<Primitive>() {
        let values = values.into_owned();
        let data = ZstdData::from_primitive(&values, 0, frame_rows, context).unwrap();
        Zstd::try_new(values.dtype().clone(), data, values.validity().unwrap())
            .unwrap()
            .into_array()
    } else {
        Zstd::from_var_bin_view(
            &column.input.as_::<VarBinView>().into_owned(),
            0,
            frame_rows,
            context,
        )
        .unwrap()
        .into_array()
    };
    assert!(
        result
            .as_::<Zstd>()
            .data()
            .clone()
            .into_parts(result.validity().unwrap())
            .dictionary
            .is_some()
    );
    result
}

fn write_fixture(path: &Path, fixture: &Fixture, encoding: &str, layout: &str) {
    let memory = LiveMemoryPool::new(GRANT).unwrap();
    let runtime = CurrentThreadRuntime::new();
    let producer = session(&memory).with_handle(runtime.handle());
    let mut context = producer.create_execution_ctx();
    let frames = if fixture.rows == 4096 { 128 } else { 1024 };
    let array = StructArray::try_new(
        fixture
            .columns
            .iter()
            .map(|c| c.name.as_str())
            .collect::<Vec<_>>()
            .into(),
        fixture
            .columns
            .iter()
            .map(|c| encoded(c, encoding, frames, &mut context))
            .collect(),
        fixture.rows,
        Validity::NonNullable,
    )
    .unwrap()
    .into_array();
    let flat: Arc<dyn LayoutStrategy> = Arc::new(FlatLayoutStrategy::default());
    let strategy = if layout == "whole_struct_flat" {
        flat
    } else {
        Arc::new(TableStrategy::new(Arc::clone(&flat), flat)) as Arc<dyn LayoutStrategy>
    };
    let mut writer = producer
        .write_options()
        .with_strategy(strategy)
        .with_file_statistics(Vec::new())
        .blocking(&runtime)
        .writer(
            fs::OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(path)
                .unwrap(),
            array.dtype().clone(),
        );
    writer.push(array).unwrap();
    writer.finish().unwrap();
    drop(context);
    drop(producer);
    drop(runtime);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    assert!(fs::metadata(path).unwrap().len() <= 32 << 20);
}

fn selected<'a>(fixture: &'a Fixture, projection: &str) -> &'a [Column] {
    if projection == "all" {
        &fixture.columns
    } else {
        &fixture.columns[..1]
    }
}

fn expected_json(fixture: &Fixture, projection: &str) -> Vec<serde_json::Value> {
    (0..fixture.rows)
        .map(|row| {
            let mut value = serde_json::Map::new();
            for column in selected(fixture, projection) {
                let scalar = match &column.expected {
                    Expected::Integers(values) => serde_json::json!(values[row]),
                    Expected::Bytes(values) => {
                        let value = values[row].as_ref().map(|bytes| {
                            if column.input.dtype() == &DType::Binary(Nullability::Nullable) {
                                bytes.iter().map(|b| format!("{b:02x}")).collect()
                            } else {
                                String::from_utf8(bytes.clone()).unwrap()
                            }
                        });
                        serde_json::json!(value)
                    }
                };
                value.insert(column.name.clone(), scalar);
            }
            serde_json::Value::Object(value)
        })
        .collect()
}

fn verify_column(array: ArrayRef, column: &Column, offset: usize, context: &mut ExecutionCtx) {
    assert_eq!(array.dtype(), column.input.dtype());
    match &column.expected {
        Expected::Integers(values) => {
            let array = array.execute::<PrimitiveArray>(context).unwrap();
            let validity = array
                .validity()
                .unwrap()
                .execute_mask(array.len(), context)
                .unwrap();
            for (row, expected) in values[offset..offset + array.len()].iter().enumerate() {
                assert_eq!(validity.value(row), expected.is_some());
                if let Some(expected) = expected {
                    assert_eq!(array.as_slice::<i64>()[row], *expected);
                }
            }
        }
        Expected::Bytes(values) => {
            let array = array.execute::<VarBinViewArray>(context).unwrap();
            let validity = array
                .validity()
                .unwrap()
                .execute_mask(array.len(), context)
                .unwrap();
            for (row, expected) in values[offset..offset + array.len()].iter().enumerate() {
                assert_eq!(validity.value(row), expected.is_some());
                if let Some(expected) = expected {
                    assert_eq!(array.bytes_at(row).as_slice(), expected);
                }
            }
        }
    }
}

fn operation(
    prepared: &PreparedVortexRelational,
    fixture: &Fixture,
    projection: &str,
    expected: &[serde_json::Value],
    consumer: &str,
    profile: &Profile,
    profiled: bool,
) -> serde_json::Value {
    let before = prepared.snapshot().memory.reserved_bytes;
    let mut native_outputs = Vec::new();
    let mut json_outputs = Vec::new();
    if profiled {
        profile.begin();
    }
    let started = Instant::now();
    let execution = if consumer == "native_canonical_2048" {
        prepared
            .for_each_batch(&CancellationToken::default(), |array, context| {
                let mut ctx = context.native_session().create_execution_ctx();
                let fields = array.execute::<StructArray>(&mut ctx).unwrap();
                let values = selected(fixture, projection)
                    .iter()
                    .map(|column| {
                        fields
                            .unmasked_field_by_name(&column.name)
                            .unwrap()
                            .clone()
                            .execute::<Canonical>(&mut ctx)
                            .unwrap()
                            .into_array()
                    })
                    .collect();
                let output = StructArray::try_new(
                    fields.names().clone(),
                    values,
                    fields.len(),
                    Validity::NonNullable,
                )
                .unwrap();
                native_outputs.push(output);
                Ok(())
            })
            .unwrap()
    } else {
        prepared
            .for_each_json_batch(
                &CancellationToken::default(),
                if consumer == "json_64" { 64 } else { 2048 },
                4 << 20,
                |batch| {
                    json_outputs.push(batch);
                    Ok(())
                },
            )
            .unwrap()
    };
    let elapsed = started.elapsed().as_nanos();
    let observation = if profiled {
        profile.finish()
    } else {
        Snapshot::default()
    };
    let with_outputs = prepared.snapshot().memory;
    assert!(with_outputs.peak_reserved_bytes <= GRANT);
    assert_eq!(with_outputs.denied_reservations, 0);
    assert_eq!(execution.output_rows as usize, fixture.rows);
    assert_eq!(
        execution.output_columns,
        selected(fixture, projection)
            .iter()
            .map(|c| c.name.clone())
            .collect::<Vec<_>>()
    );
    assert!(
        !execution
            .native_io_certificate
            .side_effects
            .fallback_attempted
    );
    if profiled {
        assert!(observation.calls[0] > 0 && observation.calls[1] > 0);
        assert_eq!(observation.calls[1], observation.calls[2]);
        assert!(observation.serialized_bytes > 0);
    }
    let verifier_memory = LiveMemoryPool::new(GRANT).unwrap();
    let verifier = session(&verifier_memory);
    let validation_started = Instant::now();
    let mut offset = 0;
    for array in &native_outputs {
        for column in selected(fixture, projection) {
            verify_column(
                array.unmasked_field_by_name(&column.name).unwrap().clone(),
                column,
                offset,
                &mut verifier.create_execution_ctx(),
            );
        }
        offset += array.len();
    }
    for batch in &json_outputs {
        let values: Vec<serde_json::Value> =
            serde_json::from_str(batch.values_json.value()).unwrap();
        assert_eq!(values, expected[offset..offset + values.len()]);
        offset += values.len();
    }
    assert_eq!(offset, fixture.rows);
    let validation_ns = validation_started.elapsed().as_nanos();
    let output_batches = execution.output_batches;
    let scan_batches = execution.scan_batches;
    drop(verifier);
    assert_eq!(verifier_memory.snapshot().reserved_bytes, 0);
    let release_started = Instant::now();
    drop(native_outputs);
    drop(json_outputs);
    drop(execution);
    let release_ns = release_started.elapsed().as_nanos();
    assert_eq!(prepared.snapshot().memory.reserved_bytes, before);
    serde_json::json!({
        "native_execution_nanoseconds": elapsed, "validation_nanoseconds": validation_ns,
        "output_release_nanoseconds": release_ns, "scan_batches": scan_batches, "output_batches": output_batches,
        "reserved_before": before, "reserved_with_output": with_outputs.reserved_bytes, "reserved_after": before,
        "peak_reserved_bytes": with_outputs.peak_reserved_bytes,
        "denied_reservations": with_outputs.denied_reservations,
        "all_values_types_nulls_order_verified": true, "fallback_attempted": false,
        "profile": {"calls": observation.calls, "timed_calls": observation.timed_calls,
            "nanoseconds": observation.nanos, "serialized_bytes": observation.serialized_bytes}
    })
}

fn prepare(
    owner: &ResidentVortexSession,
    path: &Path,
    projection: &str,
) -> PreparedVortexRelational {
    let mut policy = crate::VortexLocalPrimitiveExecutionPolicy::new_with_memory_gb(1, 1).unwrap();
    policy.resource_envelope.memory_budget_bytes = GRANT;
    let plan = VortexRelationalPlan::Scan(VortexRelationalScan {
        source_uri: DatasetUri::new(path.display().to_string()).unwrap(),
        predicate: None,
        projection: if projection == "all" {
            ProjectionRequest::All
        } else {
            ProjectionRequest::Columns(vec![ColumnRef::new("field_00").unwrap()])
        },
    });
    prepare_relational_in_session(&plan, policy, owner).unwrap()
}

#[test]
fn physical_reconstruction_probe_nested_and_cross_thread_counters_drain() {
    let session = VortexSession::default();
    let profile = Profile::default();
    session.register(profile.clone());
    assert!(Span::start(&session, Stage::Reader).is_none());
    profile.begin();
    let outer = Span::start(&session, Stage::Reader).unwrap();
    drop(Span::start(&session, Stage::Reader).unwrap());
    drop(outer);
    let worker_session = session.clone();
    std::thread::spawn(move || {
        let array = Span::start(&worker_session, Stage::Array).unwrap();
        array.record_serialized_bytes(123);
    })
    .join()
    .unwrap();
    let snapshot = profile.finish();
    assert_eq!(snapshot.calls, [2, 1, 0]);
    assert_eq!(snapshot.timed_calls, [1, 1, 0]);
    assert_eq!(snapshot.serialized_bytes, 123);
    assert!(Span::start(&session, Stage::Array).is_none());
    profile.begin();
    assert_eq!(profile.finish().calls, [0; 3]);
}

#[test]
fn physical_reconstruction_probe_real_repeated_native_values_and_cleanup() {
    let root =
        std::env::temp_dir().join(format!("shardloom-physical-probe-{}", std::process::id()));
    fs::create_dir(&root).unwrap();
    let fixture = fixture(4096, 3);
    for layout in ["whole_struct_flat", "columnar_table_flat"] {
        for encoding in ["canonical", "zstd_dictionary"] {
            let path = root.join(format!("{layout}-{encoding}.vortex"));
            write_fixture(&path, &fixture, encoding, layout);
            let owner = ResidentVortexSession::new(GRANT, 1).unwrap();
            let memory = owner.memory().clone();
            let profile = Profile::default();
            owner
                .with_native_session(|session, _| {
                    session.register(profile.clone());
                    Ok(())
                })
                .unwrap();
            let prepared = prepare(&owner, &path, "all");
            let expected = expected_json(&fixture, "all");
            for consumer in ["native_canonical_2048", "json_64"] {
                for _ in 0..2 {
                    operation(
                        &prepared, &fixture, "all", &expected, consumer, &profile, true,
                    );
                }
            }
            assert_eq!(owner.snapshot().prepared_source_opens, 1);
            assert_eq!(owner.snapshot().completed_executions, 4);
            drop(prepared);
            drop(owner);
            assert_eq!(memory.snapshot().reserved_bytes, 0);
            fs::remove_file(path).unwrap();
        }
    }
    fs::remove_dir(root).unwrap();
}

#[test]
#[ignore = "explicit frozen physical reconstruction attribution only"]
fn physical_reconstruction_complete_workflow_attribution() {
    assert_eq!(
        std::env::var("SHARDLOOM_PHYSICAL_ATTRIBUTION").as_deref(),
        Ok("frozen-v1")
    );
    let root = std::path::PathBuf::from(std::env::var("SHARDLOOM_PHYSICAL_ROOT").unwrap());
    assert!(
        root.starts_with("/Users/dylan/LocalData/shardloom/conditional-investigations-20261019")
    );
    fs::create_dir(&root).unwrap();
    let mut cell = 0;
    for rows in [4096, 32768] {
        for width in [3, 12] {
            let fixture = fixture(rows, width);
            for encoding in ["canonical", "zstd_dictionary"] {
                for layout in ["whole_struct_flat", "columnar_table_flat"] {
                    let path = root.join(format!("{rows}-{width}-{encoding}-{layout}.vortex"));
                    write_fixture(&path, &fixture, encoding, layout);
                    let bytes = fs::read(&path).unwrap();
                    let physical_bytes = bytes.len();
                    let physical_sha256 = sha(&bytes);
                    drop(bytes);
                    for projection in ["all", "one_i64"] {
                        let owner = ResidentVortexSession::new(GRANT, 1).unwrap();
                        let memory = owner.memory().clone();
                        let profile = Profile::default();
                        owner
                            .with_native_session(|session, _| {
                                session.register(profile.clone());
                                Ok(())
                            })
                            .unwrap();
                        let prepare_started = Instant::now();
                        let prepared = prepare(&owner, &path, projection);
                        let prepare_ns = prepare_started.elapsed().as_nanos();
                        let expected = expected_json(&fixture, projection);
                        let expected_sha256 = sha(&serde_json::to_vec(&expected).unwrap());
                        let dtype = prepared.output_dtype().unwrap().to_string();
                        for consumer in ["native_canonical_2048", "json_2048", "json_64"] {
                            for sample in 0..=3 {
                                for profiled in if (cell + sample) % 2 == 0 {
                                    [false, true]
                                } else {
                                    [true, false]
                                } {
                                    let observations: Vec<_> = (0..if sample == 0 { 1 } else { 3 })
                                        .map(|_| {
                                            operation(
                                                &prepared, &fixture, projection, &expected,
                                                consumer, &profile, profiled,
                                            )
                                        })
                                        .collect();
                                    println!(
                                        "PHYSICAL_RECONSTRUCTION {}",
                                        serde_json::json!({
                                            "rows": rows, "columns": width, "encoding": encoding, "layout": layout,
                                            "projection": projection, "consumer": consumer, "cell": cell,
                                            "sample": sample, "warmup": sample == 0, "profiled": profiled,
                                            "grant_bytes": GRANT, "prepare_nanoseconds": prepare_ns,
                                            "physical_bytes": physical_bytes, "physical_sha256": physical_sha256,
                                            "expected_values_sha256": expected_sha256, "schema_sha256": sha(dtype.as_bytes()),
                                            "observations": observations,
                                        })
                                    );
                                }
                            }
                            cell += 1;
                        }
                        assert_eq!(owner.snapshot().prepared_source_opens, 1);
                        assert_eq!(owner.snapshot().completed_executions, 60);
                        drop(prepared);
                        drop(owner);
                        assert_eq!(memory.snapshot().reserved_bytes, 0);
                    }
                    assert_eq!(sha(&fs::read(&path).unwrap()), physical_sha256);
                    fs::remove_file(path).unwrap();
                }
            }
        }
    }
    assert_eq!(cell, 96);
    fs::remove_dir(root).unwrap();
}
