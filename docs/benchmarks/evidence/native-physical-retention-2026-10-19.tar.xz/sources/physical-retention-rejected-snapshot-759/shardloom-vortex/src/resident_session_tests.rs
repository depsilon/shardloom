use super::*;
use std::{
    fs::File,
    io::{Seek as _, SeekFrom, Write as _},
    path::PathBuf,
    sync::atomic::AtomicUsize,
    time::{Duration, Instant},
};
use vortex::{
    array::{
        IntoArray as _,
        arrays::{PrimitiveArray, StructArray},
        dtype::FieldNames,
        validity::Validity,
    },
    file::WriteOptionsSessionExt as _,
};

static NEXT_FIXTURE: AtomicUsize = AtomicUsize::new(0);

#[test]
fn physical_array_reporting_is_inert_and_uses_the_selected_policy() {
    let small = ResidentVortexSession::new(4 << 20, 1).unwrap();
    assert_eq!(
        small.snapshot().physical_array_retention,
        PhysicalArrayRetentionSnapshot::default()
    );
    let session = ResidentVortexSession::new(64 << 20, 1).unwrap();
    let before = session.snapshot();
    let observed = before.physical_array_retention;
    #[cfg(feature = "physical-array-retention")]
    {
        assert_eq!(observed.policy, "second_observation_one_entry");
        assert_eq!(observed.capacity_entries, 1);
        assert_eq!(observed.admission_limit_bytes, 8 << 20);
    }
    #[cfg(not(feature = "physical-array-retention"))]
    assert_eq!(observed, PhysicalArrayRetentionSnapshot::default());
    assert_eq!(observed.entries, 0);
    assert_eq!(observed.lookup_hits, 0);
    assert_eq!(observed.table_charged_bytes, 0);
    assert_eq!(observed.retained_owner_charged_bytes, 0);
    assert_eq!(session.snapshot(), before);
    assert_eq!(before.memory.reserved_bytes, 0);
    assert_eq!(before.prepared_source_opens, 0);
    assert_eq!(before.completed_executions, 0);
}

struct Fixture(PathBuf);

impl Fixture {
    fn new() -> Self {
        let path = std::env::temp_dir().join(format!(
            "shardloom-resident-{}-{}",
            std::process::id(),
            NEXT_FIXTURE.fetch_add(1, Ordering::Relaxed)
        ));
        std::fs::create_dir(&path).unwrap();
        let values = PrimitiveArray::new(
            vec![393_081_u32, 912_778, 5_719, 194_797, 616_489],
            Validity::NonNullable,
        )
        .into_array();
        let metric = PrimitiveArray::new(
            vec![-519_i64, 418_982, -719, 765_741, 832_761],
            Validity::NonNullable,
        )
        .into_array();
        let array = StructArray::try_new(
            FieldNames::from(["value", "metric"]),
            vec![values, metric],
            5,
            Validity::NonNullable,
        )
        .unwrap()
        .into_array();
        let runtime = CurrentThreadRuntime::new();
        let session = VortexSession::default().with_handle(runtime.handle());
        let mut bytes = Vec::new();
        runtime
            .block_on(
                session
                    .write_options()
                    .write(&mut bytes, array.to_array_stream()),
            )
            .unwrap();
        std::fs::write(path.join("input.vortex"), bytes).unwrap();
        Self(path)
    }

    fn input(&self) -> PathBuf {
        self.0.join("input.vortex")
    }
}

impl Drop for Fixture {
    fn drop(&mut self) {
        std::fs::remove_dir_all(&self.0).unwrap();
    }
}

#[test]
fn admitted_file_segments_share_live_requests_without_caching_completed_answers() {
    use super::read_observer::ReadObservationLimits;
    use vortex::layout::segments::SegmentId;

    let fixture = Fixture::new();
    let session = ResidentVortexSession::new(8 << 20, 1).unwrap();
    let (source, observer) = session
        .prepare_observed_file(&fixture.input(), ReadObservationLimits::default())
        .unwrap();
    let opened = observer.snapshot().unwrap();
    let memory = session.memory().clone();
    let baseline = memory.snapshot().reserved_bytes;
    let buffers = source
        .with_native_execution(|file, _native, runtime| {
            let segments = file.segment_source();
            let id = SegmentId::from(0);
            let mut first = segments.request(id);
            runtime.block_on(async { assert!(futures::poll!(first.as_mut()).is_pending()) });
            // Finish the physical read before polling its consumer again.
            // The second request cannot join the same coalesced I/O batch.
            let deadline = Instant::now() + Duration::from_secs(5);
            runtime.block_on(futures::future::poll_fn(|context| {
                assert!(Instant::now() < deadline, "segment read did not complete");
                if observer.snapshot().is_ok_and(|observed| {
                    observed.completed_read_calls == opened.completed_read_calls + 1
                }) {
                    std::task::Poll::Ready(())
                } else {
                    context.waker().wake_by_ref();
                    std::task::Poll::Pending
                }
            }));
            let mut second = segments.request(id);
            let first_buffer = runtime.block_on(first.as_mut()).unwrap().unwrap_host();
            let second_buffer = runtime.block_on(second.as_mut()).unwrap().unwrap_host();
            assert_eq!(first_buffer.as_ptr(), second_buffer.as_ptr());
            assert_eq!(first_buffer, second_buffer);
            assert_eq!(
                observer.snapshot().unwrap().completed_read_calls,
                opened.completed_read_calls + 1
            );
            drop(first);
            drop(second);
            // Retained values alone must not turn request sharing into an
            // answer cache. A new request uses the same admitted descriptor.
            let third = runtime
                .block_on(segments.request(id))
                .unwrap()
                .unwrap_host();
            assert_eq!(first_buffer, third);
            assert_ne!(first_buffer.as_ptr(), third.as_ptr());
            Ok((first_buffer, second_buffer, third))
        })
        .unwrap();
    let observed = observer.snapshot().unwrap();
    assert_eq!(
        observed.completed_read_calls,
        opened.completed_read_calls + 2
    );
    assert_eq!(observed.pending_jobs, 0);
    assert_eq!(session.snapshot().prepared_source_opens, 1);
    assert!(memory.snapshot().reserved_bytes > baseline);
    drop(buffers);
    assert_eq!(memory.snapshot().reserved_bytes, baseline);
    drop(source);
    drop(observer);
    drop(session);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}

#[cfg(feature = "vortex-local-primitives")]
#[test]
fn completed_result_validation_checks_authoritative_schema_and_row_total() {
    let fixture = Fixture::new();
    let session = ResidentVortexSession::new(8 << 20, 1).unwrap();
    let source = session.prepare_file(fixture.input()).unwrap();
    let mut result = source
        .prepare_projection(&["value"], 3, 4096)
        .unwrap()
        .execute()
        .unwrap();
    result.validate_schema_and_rows().unwrap();
    let dtype = result.dtype().clone();
    result.dtype = DType::Bool(vortex::array::dtype::Nullability::NonNullable);
    assert!(
        result
            .validate_schema_and_rows()
            .unwrap_err()
            .to_string()
            .contains("disagree on dtype")
    );
    result.dtype = dtype;
    result.rows = 2;
    assert!(
        result
            .validate_schema_and_rows()
            .unwrap_err()
            .to_string()
            .contains("disagree on row count")
    );
    result.rows = 3;
    result.validate_schema_and_rows().unwrap();
    drop(result);
    drop(source);
    assert_eq!(session.snapshot().memory.reserved_bytes, 0);
}

#[cfg(feature = "vortex-local-primitives")]
#[test]
fn construction_context_reuses_source_owner_without_nested_admission_or_query_count() {
    let fixture = Fixture::new();
    let session = ResidentVortexSession::new(8 << 20, 1).unwrap();
    let foreign = ResidentVortexSession::new(8 << 20, 1).unwrap();
    let source = session.prepare_file(fixture.input()).unwrap();
    let retained = source.retained_session();
    let rows = retained
        .with_native_execution_context(&CancellationToken::default(), |context| {
            session.validate_execution_context(context)?;
            assert!(foreign.validate_execution_context(context).is_err());
            source.with_admitted_native_execution(context, |file, _| Ok(file.row_count()))
        })
        .unwrap();
    assert_eq!(rows, 5);
    assert_eq!(session.snapshot().prepared_source_opens, 1);
    assert_eq!(session.snapshot().completed_executions, 0);
    drop(session);
    assert_eq!(source.prepare_count().execute().unwrap(), 5);
    assert_eq!(retained.snapshot().completed_executions, 1);
    drop(source);
    assert_eq!(retained.snapshot().memory.reserved_bytes, 0);
}

#[cfg(feature = "vortex-local-primitives")]
#[test]
fn native_relational_sources_share_one_admission_and_one_completed_call() {
    let left = Fixture::new();
    let right = Fixture::new();
    let session = ResidentVortexSession::new(8 << 20, 1).unwrap();
    let sources = [
        session.prepare_file(left.input()).unwrap(),
        session.prepare_file(right.input()).unwrap(),
    ];
    let rows = session
        .with_sources_execution(&sources, &CancellationToken::default(), |context| {
            sources.iter().try_fold(0, |rows, source| {
                source
                    .with_admitted_native_execution(context, |file, _| Ok(rows + file.row_count()))
            })
        })
        .unwrap();
    assert_eq!(rows, 10);
    assert_eq!(session.snapshot().prepared_source_opens, 2);
    assert_eq!(session.snapshot().completed_executions, 1);
    drop(sources);
    assert_eq!(session.snapshot().memory.reserved_bytes, 0);
}

#[cfg(feature = "vortex-local-primitives")]
#[test]
fn native_relational_sources_reject_foreign_owners_before_the_consumer() {
    let fixture = Fixture::new();
    let session = ResidentVortexSession::new(8 << 20, 1).unwrap();
    let foreign = ResidentVortexSession::new(8 << 20, 1).unwrap();
    let sources = [
        session.prepare_file(fixture.input()).unwrap(),
        foreign.prepare_file(fixture.input()).unwrap(),
    ];
    let entered = std::cell::Cell::new(false);
    let error = session
        .with_sources_execution(&sources, &CancellationToken::default(), |_| {
            entered.set(true);
            Ok(())
        })
        .unwrap_err();
    assert!(error.to_string().contains("different session"));
    assert!(!entered.get());
    assert_eq!(session.snapshot().completed_executions, 0);
    drop(sources);
    assert_eq!(session.snapshot().memory.reserved_bytes, 0);
    assert_eq!(foreign.snapshot().memory.reserved_bytes, 0);
}

#[cfg(feature = "vortex-local-primitives")]
#[test]
fn native_relational_sources_validate_the_second_generation_after_consumption() {
    let left = Fixture::new();
    let right = Fixture::new();
    let replacement = right.0.join("replacement.vortex");
    std::fs::copy(right.input(), &replacement).unwrap();
    let session = ResidentVortexSession::new(8 << 20, 1).unwrap();
    let sources = [
        session.prepare_file(left.input()).unwrap(),
        session.prepare_file(right.input()).unwrap(),
    ];
    assert!(
        session
            .with_sources_execution(&sources, &CancellationToken::default(), |_| {
                std::fs::rename(&replacement, right.input()).unwrap();
                Ok(())
            })
            .is_err()
    );
    sources[0].validate_generation().unwrap();
    assert!(sources[1].validate_generation().is_err());
    assert_eq!(session.snapshot().completed_executions, 0);
    drop(sources);
    assert_eq!(session.snapshot().memory.reserved_bytes, 0);
}

#[test]
fn construction_context_rejects_cancellation_before_and_after_callback() {
    let session =
        ResidentVortexSession::with_serving_policy(8 << 20, 1, ResidentServingPolicy::default())
            .unwrap();
    let cancelled = CancellationToken::default();
    cancelled.cancel();
    let entered = std::cell::Cell::new(false);
    assert!(
        session
            .with_native_execution_context(&cancelled, |_| {
                entered.set(true);
                Ok(())
            })
            .is_err()
    );
    assert!(!entered.get());
    let cancellation = CancellationToken::default();
    assert!(
        session
            .with_native_execution_context(&cancellation, |context| {
                session.validate_execution_context(context)?;
                cancellation.cancel();
                Ok(())
            })
            .is_err()
    );
    assert_eq!(session.snapshot().completed_executions, 0);
    let admission = session.admission_snapshot().unwrap();
    assert_eq!(admission.active_cpu_lanes, 0);
    assert_eq!(admission.queued_calls, 0);
    session
        .with_native_execution_context(&CancellationToken::default(), |_| Ok(()))
        .unwrap();
    assert_eq!(session.snapshot().completed_executions, 0);
    let memory = session.memory().clone();
    drop(session);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}

#[test]
fn prepared_file_metadata_admission_checks_the_held_provider_without_execution() {
    let fixture = Fixture::new();
    let expected = std::fs::metadata(fixture.input()).unwrap();
    let other = fixture.0.join("other.vortex");
    std::fs::copy(fixture.input(), &other).unwrap();
    let session = ResidentVortexSession::new(8 << 20, 1).unwrap();
    let source = session.prepare_file(&other).unwrap();
    assert!(source.validate_file_metadata(&expected).is_err());
    let actual = std::fs::metadata(&other).unwrap();
    for _ in 0..3 {
        source.validate_file_metadata(&actual).unwrap();
        source
            .prepare_count()
            .validate_file_metadata(&actual)
            .unwrap();
        assert_eq!(session.snapshot().prepared_source_opens, 1);
        assert_eq!(session.snapshot().completed_executions, 0);
    }
    assert!(
        source
            .validate_file_metadata(&std::fs::metadata(&fixture.0).unwrap())
            .is_err()
    );
    let memory_source = session.prepare_immutable_file(source.file().clone());
    assert!(
        memory_source
            .validate_file_metadata(&actual)
            .unwrap_err()
            .to_string()
            .contains("in-memory source")
    );
    std::fs::rename(fixture.input(), &other).unwrap();
    assert!(source.validate_file_metadata(&actual).is_err());
    assert_eq!(session.snapshot().completed_executions, 0);
}

#[test]
fn prepared_file_metadata_admission_rejects_actual_provider_after_symlink_aba() {
    let fixture = Fixture::new();
    let expected = std::fs::metadata(fixture.input()).unwrap();
    let second = fixture.0.join("second.vortex");
    std::fs::copy(fixture.input(), &second).unwrap();
    let link = fixture.0.join("selected.vortex");
    std::os::unix::fs::symlink(&second, &link).unwrap();
    let session = ResidentVortexSession::new(8 << 20, 1).unwrap();
    let source = session.prepare_file(&link).unwrap();
    std::fs::remove_file(&link).unwrap();
    std::os::unix::fs::symlink(fixture.input(), &link).unwrap();
    assert_eq!(
        FileGeneration::read(&std::fs::metadata(&link).unwrap()).unwrap(),
        FileGeneration::read(&expected).unwrap()
    );
    let failure = source.validate_file_metadata(&expected).unwrap_err();
    assert!(
        failure
            .to_string()
            .contains("does not match the admitted file generation")
    );
    assert_eq!(session.snapshot().prepared_source_opens, 1);
    assert_eq!(session.snapshot().completed_executions, 0);
}

#[test]
fn prepared_calls_reuse_reader_and_workers_without_caching_answers() {
    let fixture = Fixture::new();
    let session = ResidentVortexSession::new(8 * 1024 * 1024, 2).unwrap();
    let source = session.prepare_file(fixture.input()).unwrap();
    let count = source.prepare_count();
    let projection = source
        .prepare_projection(&["metric", "value"], 3, 65536)
        .unwrap();
    for _ in 0..20 {
        assert_eq!(count.execute().unwrap(), 5);
        let result = projection.execute().unwrap();
        assert_eq!(result.row_count(), 3);
        assert!(!result.arrays().is_empty());
        assert!(result.logical_buffer_bytes() > 0);
    }
    let snapshot = session.snapshot();
    assert_eq!(snapshot.prepared_source_opens, 1);
    assert_eq!(snapshot.completed_executions, 40);
    assert!(snapshot.provider_background_workers <= 1);
    assert!(snapshot.memory.peak_reserved_bytes <= snapshot.memory.limit_bytes);
}

#[cfg(feature = "vortex-local-primitives")]
#[test]
fn external_compute_sessions_create_no_provider_cpu_drivers_and_retain_one_generation() {
    let fixture = Fixture::new();
    for workers in [1, 2, 4, 8, 12] {
        let session =
            ResidentVortexSession::for_external_cpu_pool(8 * 1024 * 1024, workers).unwrap();
        assert_eq!(session.snapshot().provider_background_workers, 0);
        let source = session.prepare_file(fixture.input()).unwrap();
        let rows = source
            .with_native_execution(|file, _, runtime| {
                let mut rows = 0;
                for chunk in file
                    .scan()
                    .map_err(native_error)?
                    .into_array_iter(runtime)
                    .map_err(native_error)?
                {
                    rows += chunk.map_err(native_error)?.len();
                }
                Ok(rows)
            })
            .unwrap();
        assert_eq!(rows, 5);
        assert_eq!(session.snapshot().prepared_source_opens, 1);
        assert_eq!(session.snapshot().completed_executions, 1);
    }
}

#[cfg(feature = "vortex-local-primitives")]
#[test]
fn native_execution_rejects_result_if_source_changes_after_its_last_read() {
    let fixture = Fixture::new();
    let session = ResidentVortexSession::for_external_cpu_pool(8 * 1024 * 1024, 4).unwrap();
    let source = session.prepare_file(fixture.input()).unwrap();
    let replacement = fixture.0.join("replacement.vortex");
    std::fs::copy(fixture.input(), &replacement).unwrap();
    let result = source.with_native_execution(|file, _, _| {
        let answer = file.row_count();
        // The last scan can finish before ordered merge/refinement does. The
        // final boundary must validate after all work, including metadata reads.
        std::fs::rename(&replacement, fixture.input()).unwrap();
        Ok(answer)
    });
    assert!(result.is_err());
    assert_eq!(session.snapshot().completed_executions, 0);
    assert!(source.prepare_count().execute().is_err());
}

#[test]
fn executable_array_result_outlives_source_and_session() {
    let fixture = Fixture::new();
    let session = ResidentVortexSession::new(8 * 1024 * 1024, 2).unwrap();
    let memory = session.0.memory.clone();
    let source = session.prepare_file(fixture.input()).unwrap();
    let projection = source.prepare_projection(&["value"], 5, 65536).unwrap();
    let result = projection.execute().unwrap();
    drop(projection);
    drop(source);
    drop(session);
    let arrays = result.arrays().to_vec();
    drop(result);
    let native_session = VortexSession::default();
    let mut context = native_session.create_execution_ctx();
    let mut values = Vec::new();
    for array in &arrays {
        for index in 0..array.len() {
            values.push(
                array
                    .execute_scalar(index, &mut context)
                    .unwrap()
                    .to_string(),
            );
        }
    }
    assert_eq!(values.len(), 5);
    assert_ne!(values[0], values[4]);
    assert!(memory.snapshot().reserved_bytes > 0);
    drop(arrays);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
}

#[test]
fn replace_mutate_truncate_and_recreate_invalidate_prepared_handles() {
    for change in ["replace", "mutate", "truncate", "recreate"] {
        let fixture = Fixture::new();
        let session = ResidentVortexSession::new(8 * 1024 * 1024, 1).unwrap();
        let source = session.prepare_file(fixture.input()).unwrap();
        let count = source.prepare_count();
        let projection = source.prepare_projection(&["value"], 5, 65536).unwrap();
        let backup = fixture.0.join("backup.vortex");
        std::fs::copy(fixture.input(), &backup).unwrap();
        match change {
            "replace" => std::fs::rename(&backup, fixture.input()).unwrap(),
            "recreate" => {
                std::fs::remove_file(fixture.input()).unwrap();
                std::fs::copy(&backup, fixture.input()).unwrap();
            }
            "mutate" => {
                let original = std::fs::metadata(fixture.input()).unwrap();
                let mut file = File::options().write(true).open(fixture.input()).unwrap();
                file.seek(SeekFrom::Start(8)).unwrap();
                file.write_all(&[42]).unwrap();
                file.set_times(
                    std::fs::FileTimes::new().set_modified(original.modified().unwrap()),
                )
                .unwrap();
            }
            "truncate" => File::options()
                .write(true)
                .open(fixture.input())
                .unwrap()
                .set_len(12)
                .unwrap(),
            _ => unreachable!(),
        }
        assert!(count.execute().is_err(), "{change}");
        assert!(projection.execute().is_err(), "{change}");
        assert!(count.execute().is_err(), "invalidation must be sticky");
    }
}

#[test]
fn invalid_projection_and_memory_limits_fail_explicitly() {
    let fixture = Fixture::new();
    let tiny = ResidentVortexSession::new(8, 1).unwrap();
    assert!(tiny.prepare_file(fixture.input()).is_err());
    assert_eq!(tiny.snapshot().memory.reserved_bytes, 0);
    let session = ResidentVortexSession::new(8 * 1024 * 1024, 1).unwrap();
    let source = session.prepare_file(fixture.input()).unwrap();
    assert!(source.prepare_projection(&["missing"], 5, 1024).is_err());
    assert!(
        source
            .prepare_projection(&["value", "value"], 5, 1024)
            .is_err()
    );
    assert!(source.prepare_projection(&["value"], 0, 1024).is_err());
    assert!(
        source
            .prepare_projection(&["value"], 5, 1)
            .unwrap()
            .execute()
            .is_err()
    );
    assert_eq!(source.prepare_count().execute().unwrap(), 5);
}

#[test]
fn concurrent_prepared_calls_share_one_session_admission_boundary() {
    let fixture = Fixture::new();
    let session = ResidentVortexSession::new(8 * 1024 * 1024, 2).unwrap();
    let source = session.prepare_file(fixture.input()).unwrap();
    std::thread::scope(|scope| {
        for _ in 0..8 {
            let source = &source;
            scope.spawn(move || {
                let count = source.prepare_count();
                for _ in 0..32 {
                    assert_eq!(count.execute().unwrap(), 5);
                }
            });
        }
    });
    assert_eq!(session.snapshot().completed_executions, 256);
    assert_eq!(session.snapshot().prepared_source_opens, 1);
}
