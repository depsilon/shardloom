//! Complete cost comparison for the immutable physical-retention-752-v1 protocol.
use super::*;

fn cache_snapshot(owner: &ResidentVortexSession) -> Option<super::super::super::physical_retention::Snapshot> {
    owner.0.physical_arrays.as_ref().map(|manager| manager.snapshot())
}

fn role_name(role: Policy) -> &'static str {
    match role { Policy::None => "none", Policy::One => "one", Policy::Lru16 => "lru16" }
}

fn roles(ordinal: usize, sample: usize, reverse: bool) -> [Policy; 3] {
    let mut roles = [Policy::None, Policy::One, Policy::Lru16];
    roles.rotate_left((ordinal + sample) % 3);
    if reverse { roles.reverse(); }
    roles
}

#[allow(clippy::too_many_arguments)]
fn workflow(path: &Path, fixture: &Fixture, projection: &str, expected: &[serde_json::Value], consumer: &str,
            calls: usize, policy: Policy, churn: bool) -> serde_json::Value {
    let start = Instant::now();
    let memory = LiveMemoryPool::new(GRANT).unwrap();
    let owner = owner(&memory, policy);
    let owner_construct = start.elapsed().as_nanos();
    let mut preparation = Vec::new();
    let mut destruction = Vec::new();
    let mut after_source_drop = Vec::new();
    let mut after_retention_drop = Vec::new();
    let mut operations = Vec::new();
    let mut caches = Vec::new();
    let mut schema_sha256 = None;
    let prepare_count = if churn { calls } else { 1 };
    for _ in 0..prepare_count {
        assert!(cache_snapshot(&owner).is_none_or(|s| s.entries == 0 && s.retention_reserved == 0));
        let started = Instant::now();
        let plan = prepare(&owner, path, projection);
        preparation.push(started.elapsed().as_nanos());
        let schema = sha(plan.output_dtype().unwrap().to_string().as_bytes());
        if let Some(expected) = &schema_sha256 { assert_eq!(expected, &schema); }
        else { schema_sha256 = Some(schema); }
        for _ in 0..if churn { 1 } else { calls } {
            operations.push(operation_policy(&plan, fixture, projection, expected, consumer,
                                              &Profile::default(), false, policy != Policy::None));
            caches.push(cache_snapshot(&owner));
        }
        let started = Instant::now();
        drop(plan);
        destruction.push(started.elapsed().as_nanos());
        let after = cache_snapshot(&owner);
        after_source_drop.push(after.as_ref().map_or(0, |s| s.entries));
        after_retention_drop.push(after.as_ref().map_or(0, |s| s.retention_reserved));
        assert_eq!(after_source_drop.last(), Some(&0));
        assert_eq!(after_retention_drop.last(), Some(&0));
    }
    let observed = owner.snapshot();
    assert_eq!(observed.prepared_source_opens as usize, prepare_count);
    assert_eq!(observed.completed_executions as usize, calls);
    let final_entries = cache_snapshot(&owner).map_or(0, |s| s.entries);
    let started = Instant::now();
    drop(owner);
    let owner_drop = started.elapsed().as_nanos();
    let final_memory = memory.snapshot();
    assert_eq!(final_memory.reserved_bytes, 0);
    assert_eq!(final_memory.denied_reservations, 0);
    assert!(final_memory.peak_reserved_bytes <= GRANT);
    let complete = owner_construct + owner_drop + preparation.iter().sum::<u128>()
        + destruction.iter().sum::<u128>()
        + operations.iter().map(|op| u128::from(op["native_execution_nanoseconds"].as_u64().unwrap())
            + u128::from(op["output_release_nanoseconds"].as_u64().unwrap())).sum::<u128>();
    serde_json::json!({
        "owner_construct_nanoseconds": owner_construct, "owner_drop_nanoseconds": owner_drop,
        "preparation_nanoseconds": preparation, "plan_drop_nanoseconds": destruction,
        "operations": operations, "cache_after_operations": caches,
        "entries_after_source_drop": after_source_drop, "retention_after_source_drop": after_retention_drop,
        "schema_sha256": schema_sha256.unwrap(), "complete_workflow_nanoseconds": complete,
        "source_opens": observed.prepared_source_opens, "completed_executions": observed.completed_executions,
        "final_entries": final_entries, "final_reserved_bytes": final_memory.reserved_bytes,
        "peak_reserved_bytes": final_memory.peak_reserved_bytes, "denied_reservations": final_memory.denied_reservations,
    })
}

#[allow(clippy::too_many_arguments)]
fn record(category: &str, cohort: &str, fixture: &Fixture, encoding: &str, layout: &str, projection: &str,
          consumer: &str, path: &Path, calls: usize, sample: usize, role: Policy, bytes: usize, digest: &str,
          expected: &[serde_json::Value], expected_hash: &str) {
    let result = workflow(path, fixture, projection, expected, consumer, calls, role, category == "churn");
    println!("PHYSICAL_RETENTION_WORKFLOW {}", serde_json::json!({
        "category": category, "cohort": cohort, "warmup": category == "warmup",
        "rows": fixture.rows, "columns": fixture.columns.len(), "encoding": encoding, "layout": layout,
        "projection": projection, "consumer": consumer, "calls": calls, "sample": sample, "role": role_name(role),
        "grant_bytes": GRANT, "physical_bytes": bytes, "physical_sha256": digest,
        "expected_values_sha256": expected_hash, "schema_sha256": result["schema_sha256"], "workflow": result,
    }));
}

#[test]
#[ignore = "explicit frozen physical retention complete-workflow comparison only"]
fn physical_retention_complete_workflow_comparison() {
    assert_eq!(std::env::var("SHARDLOOM_PHYSICAL_RETENTION").as_deref(), Ok("frozen-752-v1"));
    let cohort = std::env::var("SHARDLOOM_PHYSICAL_COHORT").unwrap();
    assert!(matches!(cohort.as_str(), "a" | "b"));
    let root = std::path::PathBuf::from(std::env::var("SHARDLOOM_PHYSICAL_ROOT").unwrap());
    assert!(root.starts_with("/Users/dylan/LocalData/shardloom/conditional-investigations-20261019"));
    fs::create_dir(&root).unwrap();
    // Preserve the original fixtures across every role. No owner survives a workflow.
    for rows in [4096, 32768] {
        for width in [3, 12] {
            let fixture = fixture(rows, width);
            for encoding in ["canonical", "zstd_dictionary"] {
                for layout in ["whole_struct_flat", "columnar_table_flat"] {
                    let path = root.join(format!("{rows}-{width}-{encoding}-{layout}.vortex"));
                    write_fixture(&path, &fixture, encoding, layout);
                }
            }
        }
    }
    let fixture = fixture(4096, 3);
    let path = root.join("4096-3-canonical-whole_struct_flat.vortex");
    let bytes = fs::read(&path).unwrap();
    let physical = (bytes.len(), sha(&bytes));
    drop(bytes);
    let expected = expected_json(&fixture, "all");
    let logical = sha(&serde_json::to_vec(&expected).unwrap());
    for role in [Policy::None, Policy::One, Policy::Lru16] {
        record("warmup", &cohort, &fixture, "canonical", "whole_struct_flat", "all", "native_canonical_2048",
               &path, 1, 0, role, physical.0, &physical.1, &expected, &logical);
    }
    let mut ordinal = 0;
    for rows in [4096, 32768] {
        for width in [3, 12] {
            let fixture = super::fixture(rows, width);
            for encoding in ["canonical", "zstd_dictionary"] {
                for layout in ["whole_struct_flat", "columnar_table_flat"] {
                    let path = root.join(format!("{rows}-{width}-{encoding}-{layout}.vortex"));
                    let bytes = fs::read(&path).unwrap();
                    let physical = (bytes.len(), sha(&bytes));
                    drop(bytes);
                    for projection in ["all", "one_i64"] {
                        let expected = expected_json(&fixture, projection);
                        let logical = sha(&serde_json::to_vec(&expected).unwrap());
                        for consumer in ["native_canonical_2048", "json_2048", "json_64"] {
                            for calls in [1, 8] {
                                for sample in 1..=3 {
                                    for role in roles(ordinal, sample, cohort == "b") {
                                        record("matrix", &cohort, &fixture, encoding, layout, projection, consumer,
                                               &path, calls, sample, role, physical.0, &physical.1, &expected, &logical);
                                    }
                                }
                                ordinal += 1;
                            }
                        }
                    }
                    assert_eq!(sha(&fs::read(&path).unwrap()), physical.1);
                }
            }
        }
    }
    assert_eq!(ordinal, 192);
    for width in [3, 12] {
        let fixture = super::fixture(4096, width);
        let expected = expected_json(&fixture, "all");
        let logical = sha(&serde_json::to_vec(&expected).unwrap());
        for layout in ["whole_struct_flat", "columnar_table_flat"] {
            let path = root.join(format!("4096-{width}-canonical-{layout}.vortex"));
            let bytes = fs::read(&path).unwrap();
            let physical = (bytes.len(), sha(&bytes));
            drop(bytes);
            for consumer in ["native_canonical_2048", "json_64"] {
                for sample in 1..=3 {
                    for role in roles(ordinal, sample, cohort == "b") {
                        record("churn", &cohort, &fixture, "canonical", layout, "all", consumer,
                               &path, 8, sample, role, physical.0, &physical.1, &expected, &logical);
                    }
                }
                ordinal += 1;
            }
            assert_eq!(sha(&fs::read(&path).unwrap()), physical.1);
        }
    }
    assert_eq!(ordinal, 200);
    for entry in fs::read_dir(&root).unwrap() {
        fs::remove_file(entry.unwrap().path()).unwrap();
    }
    fs::remove_dir(root).unwrap();
}
