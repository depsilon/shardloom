fn raw_payload(source: &PreparedVortexSource) -> (vortex::array::buffer::BufferHandle, ArrayRef) {
    let layout = root_layout(source);
    source.with_native_execution(|file, native, runtime| {
        let segment = runtime.block_on(file.segment_source().request(layout.segment_id()))
            .map_err(super::super::native_error)?;
        let parts = if let Some(tree) = layout.array_tree() {
            vortex::array::serde::SerializedArray::from_flatbuffer_and_segment(tree.clone(), segment.clone())
        } else { vortex::array::serde::SerializedArray::try_from(segment.clone()) }
            .map_err(super::super::native_error)?;
        let array = parts.decode(layout.dtype(), layout.row_count() as usize, layout.array_ctx(), native)
            .map_err(super::super::native_error)?;
        Ok((segment, array))
    }).unwrap()
}

#[test]
fn physical_retention_table_and_admission_pressure_leave_original_array_authoritative() {
    for stage in ["table", "metadata", "payload"] {
        let path = path(&format!("allocation-denial-{stage}"));
        let fixture = fixture(4096, 3);
        write_fixture(&path, &fixture, "canonical", "whole_struct_flat");
        let memory = LiveMemoryPool::new(GRANT).unwrap();
        let owner = owner(&memory, Policy::Lru16);
        let source = owner.prepare_file(&path).unwrap();
        let layout = root_layout(&source);
        let cache = source.0.physical_arrays.as_ref().unwrap();
        let (segment, array) = raw_payload(&source);
        let baseline = memory.snapshot().reserved_bytes;
        if stage != "table" {
            cache.observe(&layout, &segment, &array, &owner.0.session).unwrap();
            assert_eq!(owner.0.physical_arrays.as_ref().unwrap().snapshot().entries, 1);
        }
        // The frozen 4,096-row fixture's metadata fits in three segment lengths;
        // its metadata plus copied payload does not. Zero slack denies metadata.
        let headroom = if stage == "payload" { 3 * segment.len() as u64 } else { 0 };
        let blocker = memory.reserve(GRANT - memory.snapshot().reserved_bytes - headroom).unwrap();
        let denied = memory.snapshot().denied_reservations;
        cache.observe(&layout, &segment, &array, &owner.0.session).unwrap();
        assert!(memory.snapshot().denied_reservations > denied, "{stage}");
        let observed = owner.0.physical_arrays.as_ref().unwrap().snapshot();
        assert_eq!(observed.counters.admissions, 0);
        assert_eq!(observed.entries, 0);
        assert_eq!(observed.retention_reserved, 0);
        drop(blocker);
        assert_eq!(memory.snapshot().reserved_bytes, baseline, "{stage}");
        let verifier_memory = LiveMemoryPool::new(GRANT).unwrap();
        let verifier = session(&verifier_memory);
        for column in &fixture.columns {
            let fields = array.as_::<vortex::array::arrays::Struct>();
            verify_column(fields.unmasked_field_by_name(&column.name).unwrap().clone(), column, 0,
                          &mut verifier.create_execution_ctx());
        }
        drop(verifier);
        assert_eq!(verifier_memory.snapshot().reserved_bytes, 0);
        drop((segment, array, layout));
        scan(&source, &fixture);
        drop(source);
        drop(owner);
        assert_eq!(memory.snapshot().reserved_bytes, 0);
        fs::remove_file(path).unwrap();
    }
}

#[derive(Debug, PartialEq, Eq, Hash)]
struct NoCopyDevice(usize);

impl vortex::array::buffer::DeviceBuffer for NoCopyDevice {
    fn as_any(&self) -> &dyn std::any::Any { self }
    fn len(&self) -> usize { self.0 }
    fn alignment(&self) -> vortex::buffer::Alignment { vortex::buffer::Alignment::new(256) }
    fn copy_to_host_sync(&self, _: vortex::buffer::Alignment) -> vortex::error::VortexResult<vortex::buffer::ByteBuffer> {
        panic!("optional physical retention must not copy device data")
    }
    fn copy_to_host(&self, _: vortex::buffer::Alignment) -> vortex::error::VortexResult<futures::future::BoxFuture<'static, vortex::error::VortexResult<vortex::buffer::ByteBuffer>>> {
        panic!("optional physical retention must not schedule device data")
    }
    fn slice(&self, range: std::ops::Range<usize>) -> Arc<dyn vortex::array::buffer::DeviceBuffer> {
        assert!(range.start <= range.end && range.end <= self.0);
        Arc::new(Self(range.end - range.start))
    }
    fn aligned(self: Arc<Self>, alignment: vortex::buffer::Alignment) -> vortex::error::VortexResult<Arc<dyn vortex::array::buffer::DeviceBuffer>> {
        assert!(*alignment <= 256);
        Ok(self)
    }
}

#[test]
fn physical_retention_device_segments_and_arrays_bypass_without_copying() {
    use vortex::array::{ArrayVTable as _, buffer::BufferHandle};
    let path = path("device");
    let fixture = fixture(4096, 3);
    write_fixture(&path, &fixture, "canonical", "whole_struct_flat");
    let memory = LiveMemoryPool::new(GRANT).unwrap();
    let owner = owner(&memory, Policy::Lru16);
    let source = owner.prepare_file(&path).unwrap();
    let layout = root_layout(&source);
    let (segment, array) = raw_payload(&source);
    let device_segment = BufferHandle::new_device(Arc::new(NoCopyDevice(segment.len())));
    let buffers = [BufferHandle::new_device(Arc::new(NoCopyDevice(28))),
                   BufferHandle::new_device(Arc::new(NoCopyDevice(32)))];
    let dtype = DType::Utf8(Nullability::NonNullable);
    let device_array = VarBinViewArray::try_from_parts(VarBinView.deserialize(&dtype, 2, &[], &buffers,
        &Vec::<ArrayRef>::new(), &owner.0.session).unwrap()).unwrap().into_array();
    let device_layout = FlatLayout::new(2, dtype, layout.segment_id(), layout.array_ctx().clone());
    let cache = source.0.physical_arrays.as_ref().unwrap();
    for _ in 0..2 {
        cache.observe(&layout, &device_segment, &array, &owner.0.session).unwrap();
        cache.observe(&device_layout, &segment, &device_array, &owner.0.session).unwrap();
    }
    let observed = owner.0.physical_arrays.as_ref().unwrap().snapshot();
    assert_eq!(observed.counters.shape_bypasses, 4);
    assert_eq!(observed.counters.copied_bytes, 0);
    assert_eq!(observed.counters.admissions, 0);
    assert_eq!(observed.entries, 0);
    assert_eq!(observed.retention_reserved, 0);
    drop((device_array, device_layout, device_segment, buffers, segment, array, layout));
    drop(source);
    drop(owner);
    assert_eq!(memory.snapshot().reserved_bytes, 0);
    fs::remove_file(path).unwrap();
}
