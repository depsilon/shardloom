"""Observe merged native ingest, all ClickBench results and modular workflows."""
import argparse
import datetime as dt
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import stat
import subprocess
import sys
import threading
import time
import tomllib

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PRIOR = OUT.parent
UAT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
REFERENCE = Path('/Users/dylan/LocalData/shardloom/native-typed-reductions-20261004/clickbench-reference-values-2.json')
PYTHON = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
QUERY_PYTHON = '/opt/homebrew/opt/python@3.13/bin/python3.13'
PYTHON_DEPS = '/Users/dylan/LocalData/shardloom/native-typed-reductions-20261004/python-deps'
sys.path[:0] = [str(ROOT / 'scripts'), str(PRIOR), '/Users/dylan/LocalData/shardloom/release-0.3.3-20260930']
from freeze_native_release_298 import sources, sha, save
from clickbench_reference_packet import load_reference_packet
from local_uat_storage import GIB, MIB, add_log_budget_arguments, check_budgets, require_local_path
from release_validation_guard import WorkloadGuard
from native_workflow_protocol import extract_result, report_fields, strict_json
from run_clickbench_query_uat import equivalent


def read(path):
    return json.loads(Path(path).read_text())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def generation(path):
    require_local_path(path, Path.home(), sys.platform)
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and not path.is_symlink(), path
    assert not (info.st_flags & getattr(stat, 'SF_DATALESS', 0x40000000)), path
    assert info.st_blocks * 512 >= info.st_size, path
    return dict(device=info.st_dev, inode=info.st_ino, size_bytes=info.st_size,
                mtime_ns=info.st_mtime_ns, ctime_ns=info.st_ctime_ns)


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--attempt', type=int, required=True)
add_log_budget_arguments(parser)
args = parser.parse_args()
assert args.attempt > 0
head = git('rev-parse', 'HEAD')
assert head == 'ed253d1ec74b724215f71f0b410123656e596696'
assert not git('status', '--porcelain')
version = tomllib.loads((ROOT / 'Cargo.toml').read_text())['workspace']['package']['version']
assert version == '0.5.1'
release_path = PRIOR / 'zstd-views-base-386-release.json'
release = read(release_path)
assert sha(release_path) == '76b543f8829eb54cc2b526c2bd3c499cdfa31508031a990d89fb55834ddde868'
assert release['status'] == 'passed' and release['build_profile'] == 'release'
assert sha(release['source_manifest']['path']) == release['source_manifest']['sha256']
assert read(release['source_manifest']['path'])['source_sha256'] == release['source_sha256']
cli = release['cli']
assert Path(cli['path']).stat().st_size == cli['bytes'] and sha(cli['path']) == cli['sha256']
assert sha(cli['build_receipt']) == cli['build_receipt_sha256']
build_receipt = read(cli['build_receipt'])
assert build_receipt['status'] == 'passed' and build_receipt['returncode'] == 0
assert build_receipt['head'] == release['head'] and not build_receipt['working_tree'].strip()
assert build_receipt['process_group_drained'] and build_receipt['direct_child_reaped']
assert not build_receipt['timed_out'] and not build_receipt['group_absence_unproved_at_cleanup']
assert sha(cli['build_log']) == build_receipt['log_sha256']
assert build_receipt['command'] == ['cargo', 'build', '--offline', '--locked', '--release',
    '-p', 'shardloom-cli', '--bin', 'shardloom', '--features', 'release-user-surfaces', '--message-format=json']
frozen_sources = sources()
assert frozen_sources.keys() == release['source_sha256'].keys()
changed = {name: dict(build_sha256=digest, current_sha256=frozen_sources[name])
           for name, digest in release['source_sha256'].items() if frozen_sources[name] != digest}
assert set(changed) == {'scripts/local_uat_storage.py', 'scripts/run_clickbench_paired_query_uat.py',
    'scripts/run_clickbench_query_uat.py', 'scripts/run_local_readonly_proof.py',
    'scripts/test_clickbench_query_uat.py', 'scripts/test_local_uat_storage.py',
    'scripts/test_run_local_readonly_proof.py'}
helpers = {str(path): sha(path) for path in [
    Path(__file__), OUT / 'run_guarded.py', OUT / 'run_modular_acceptance.py',
    PRIOR / 'freeze_native_release_298.py',
    ROOT / 'scripts/run_clickbench_ingest_uat.sh',
    ROOT / 'scripts/run_clickbench_query_uat.py', ROOT / 'scripts/local_uat_storage.py',
    ROOT / 'scripts/timed_native_command.py', ROOT / 'scripts/native_workflow_protocol.py',
    ROOT / 'scripts/clickbench_reference_packet.py',
    Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'),
    Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')]}
source = UAT / 'sources/hits.parquet'
target = UAT / f'vortex/stream-native-389-a{args.attempt}.vortex'
prefix = f'stream-native-fresh-uat-{args.attempt}'
protocol_path = OUT / f'{prefix}-protocol.json'
results_path = OUT / f'{prefix}-results.json'
build_path = OUT / f'acceptance-build-{args.attempt}.json'
assert not any(path.exists() for path in (protocol_path, results_path, build_path, target))
for path in (OUT, UAT):
    require_local_path(path, Path.home(), sys.platform)
workload = WorkloadGuard()
workload.check()


def unchanged():
    assert git('rev-parse', 'HEAD') == head and not git('status', '--porcelain')
    assert sources() == frozen_sources
    assert all(sha(path) == digest for path, digest in helpers.items())
    assert sha(cli['path']) == cli['sha256']


admission_started = time.monotonic()
try:
    unchanged()
    assert not (UAT / '.ingest-uat.lock').exists()
    storage = check_budgets(UAT, target, UAT / 'logs' / prefix, min_free_bytes=12 * GIB,
        reserve_bytes=20 * GIB, max_workspace_bytes=100 * GIB,
        max_log_bytes=math.floor(args.max_log_mib * MIB),
        max_run_log_bytes=math.floor(args.max_run_log_mib * MIB))
    source_generation = generation(source)
    assert source_generation['size_bytes'] == 14779976446
    print('Hashing the resident source before timed work', flush=True)
    source_sha = sha(source)
    assert source_sha == 'a390f6cb782f6aaef278c72fc1dd86c4f30bc843ebab3c159e9bd4d45ddb079f'
    assert generation(source) == source_generation
    assert sha(REFERENCE) == 'cb83c770674073f31ad0c4224f02faeb1ba557c512595a5c2d36f92bb2344b39'
    references = load_reference_packet(REFERENCE, ROOT / 'benchmarks/clickbench/queries.sql')
    workload.check()
except BaseException as error:
    save(OUT / f'{prefix}-admission-failed.json', dict(status='failed_before_fresh_uat',
        error=type(error).__name__ + ': ' + str(error), seconds=time.monotonic()-admission_started,
        native_queries_executed=0, target_created=target.exists(), storage_limits_changed=False))
    raise
build = dict(binary=cli['path'], binary_sha256=cli['sha256'], source_commit=release['head'],
    accepted_source_commit=head, working_tree='', features='release-user-surfaces', profile='release',
    source_hashes=frozen_sources, original_release_manifest=str(release_path),
    original_release_manifest_sha256=sha(release_path), changed_harness_only=changed)
save(build_path, build)
protocol = dict(status='frozen_before_fresh_uat', package_version=version, source_version=version,
    source_commit=head, runtime_build_commit=release['head'], build_manifest=str(build_path),
    build_manifest_sha256=sha(build_path), binary=cli['path'], binary_sha256=cli['sha256'],
    source_hashes=frozen_sources, changed_since_build_harness_only=changed,
    source=str(source), source_sha256=source_sha, source_generation=source_generation,
    target=str(target), reference_packet=str(REFERENCE), reference_packet_sha256=sha(REFERENCE),
    queries_sha256=sha(ROOT/'benchmarks/clickbench/queries.sql'), helpers=helpers,
    storage_preflight=storage, recorded_at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
    platform=platform.platform(), machine=platform.machine(), logical_cpus=os.cpu_count(),
    physical_memory_bytes=int(subprocess.check_output(['/usr/sbin/sysctl','-n','hw.memsize'],text=True)),
    memory_admission_bytes=24*GIB, max_parallelism=12, query_runs_expected=129,
    modular_cohorts_expected=18, modular_records_expected=1408, modular_native_records_expected=704,
    serial_workloads=True, comparative_performance_claim=False,
    clickbench_reference_kind='retained_native_regression',
    workflow_reference_kind='independent_pandas_values_testing_only',
    complete_cartesian_coverage_claimed=False, all_cell_ingest_equivalence_claimed=False,
    cache_state='Resident Parquet prehashed; queries use freshly written Vortex; OS cache and desktop activity uncontrolled.',
    timing_boundary='Complete native processes include startup, complete output and exit. Ingest-plus-query workflow includes guards, identity checks, output discovery and query validation, excluding initial source hash, independent later readback, modular workflows and final artifact hashes. Native sums are separate.',
    max_log_mib=args.max_log_mib, max_run_log_mib=args.max_run_log_mib)
save(protocol_path, protocol)
report = dict(status='running', protocol_sha256=sha(protocol_path), stages=[])
stop_sampling = threading.Event()
host_path = OUT / f'{prefix}-host.jsonl'
host_errors = []


def sample_host():
    try:
        with host_path.open('x') as stream:
            while True:
                process = subprocess.run(['/bin/ps','-axo','pid=,ppid=,pcpu=,rss=,comm='],
                                         text=True, capture_output=True, timeout=5, check=True)
                rows = []
                for line in process.stdout.splitlines():
                    parts = line.split(None, 4)
                    if len(parts) == 5:
                        rows.append(dict(pid=int(parts[0]), ppid=int(parts[1]), cpu_percent=float(parts[2]),
                                         rss_kib=int(parts[3]), command=Path(parts[4]).name))
                rows.sort(key=lambda row: row['cpu_percent'], reverse=True)
                stream.write(json.dumps(dict(utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                    load_average=os.getloadavg(), top_cpu_processes=rows[:20]))+'\n')
                stream.flush()
                if stop_sampling.wait(5):
                    break
    except BaseException as error:
        host_errors.append(type(error).__name__ + ': ' + str(error))


sampler = threading.Thread(target=sample_host, daemon=True)
sampler.start()


def run(stage, timeout, command):
    unchanged()
    name = f'stream-native-{stage}-{args.attempt}'
    print('Starting ' + name, flush=True)
    result = subprocess.run([PYTHON,'-B',str(OUT/'run_guarded.py'),'--name',name,
        '--timeout',str(timeout),'--',*command],cwd=ROOT)
    receipt_path = OUT / f'{name}.json'
    receipt = read(receipt_path)
    report['stages'].append(dict(stage=stage,receipt=str(receipt_path),sha256=sha(receipt_path)))
    assert result.returncode == receipt['returncode'] == 0 and receipt['status'] == 'passed'
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup']
    assert receipt['head'] == head and not receipt['working_tree'].strip()
    assert sha(receipt_path.with_suffix('.log')) == receipt['log_sha256']
    unchanged()


log_flags = ['--max-log-mib', str(args.max_log_mib), '--max-run-log-mib', str(args.max_run_log_mib)]
try:
    before = set((UAT/'logs').glob('ingest_cli_uat_gated_*/prepare_summary.json'))
    workflow_started = time.monotonic()
    run('full-ingest',2100,['bash','scripts/run_clickbench_ingest_uat.sh','--binary',cli['path'],
        '--source',str(source),'--target',str(target),'--memory-gb','24','--max-parallelism','12',
        '--progress-interval-seconds','10','--max-runtime-seconds','1800','--max-artifact-gb','20',*log_flags])
    ingest_path, = set((UAT/'logs').glob('ingest_cli_uat_gated_*/prepare_summary.json'))-before
    ingest = read(ingest_path)
    assert ingest['returncode'] == 0 and ingest['stop_reason'] == 'process_completed' and ingest['stdout_json_ok']
    fields = report_fields(read(ingest_path.parent/'stdout.json'))
    for field in ('input_row_count','prepared_olap_state_layout_footer_row_count','vortex_ingest_stream_validation_rows'):
        assert fields['public_workflow_preparation_'+field] == '99997497'
    assert fields['fallback_attempted'] == fields['external_engine_invoked'] == 'false'
    report['ingest'] = dict(summary=str(ingest_path),summary_sha256=sha(ingest_path),complete_rows=99997497)
    target_generation = generation(target)
    before = set((UAT/'logs').glob('full43_*/summary.json'))
    run('fresh-full43',1500,[QUERY_PYTHON,'-B','scripts/run_clickbench_query_uat.py','--binary',cli['path'],
        '--input',str(target),'--uat-root',str(UAT),'--reference-packet',str(REFERENCE),
        '--build-commit',release['head'],'--memory-gb','24','--max-parallelism','12','--compress-logs',*log_flags])
    query_path, = set((UAT/'logs').glob('full43_*/summary.json'))-before
    query = read(query_path)
    assert query['complete'] and query['runs_passed'] == query['runs_completed'] == len(query['records']) == 129
    assert all(row['passed'] for row in query['records'])
    assert query['source'] == str(target) and query['source_generation'] == target_generation
    assert query['binary_sha256'] == cli['sha256'] and query['build_commit'] == release['head']
    assert query['completed_identity_check'] and query['harness_identity_verified']
    assert query['reference_packet_identity_verified'] and query['full_result_validation']
    report['queries'] = dict(summary=str(query_path),summary_sha256=sha(query_path),complete_runs=129)
    report['ingest_plus_query_supervised_workflow_seconds'] = time.monotonic()-workflow_started
    print(json.dumps(dict(stage='ingest_and_queries_complete',
        native_ingest_seconds=ingest['native_process_seconds'],
        native_query_seconds=sum(row['seconds'] for row in query['records']),
        supervised_workflow_seconds=report['ingest_plus_query_supervised_workflow_seconds'])),flush=True)
    rows = 0
    for row in query['records']:
        assert row['validation'] == 'complete_values' and not row['guard_failures'] and row['returncode'] == 0
        archive = next(item for item in row['completed_log_archives'] if item['path'].endswith('.stdout.json.gz'))
        compressed = Path(archive['path']).read_bytes()
        assert hashlib.sha256(compressed).hexdigest() == archive['gzip_sha256']
        raw = gzip.decompress(compressed)
        assert len(raw) == archive['raw_bytes'] and hashlib.sha256(raw).hexdigest() == archive['raw_sha256']
        envelope = strict_json(raw.decode())
        fields, result = report_fields(envelope), extract_result(envelope)
        assert equivalent(result,references['values'][row['query']])
        assert fields['fallback_attempted'] == fields['external_engine_invoked'] == 'false'
        assert fields['execution_resource_declared_memory_bytes'] == str(24*GIB)
        assert fields['execution_resource_declared_max_parallelism'] == '12'
        assert any(item['kind']=='native_io_certificate' and item['status']=='available' for item in envelope['certificates'])
        assert hashlib.sha256(json.dumps(result,sort_keys=True,allow_nan=False).encode()).hexdigest() == row['result_sha256']
        rows += len(result)
    assert rows == 1143
    report['queries'].update(independently_reopened_calls=129,complete_rows=rows)
    run('modular-native',2400,['/usr/bin/env','PYTHONPATH='+PYTHON_DEPS,PYTHON,'-B',
        str(OUT/'run_modular_acceptance.py'),'--repo',str(ROOT),'--build-manifest',str(build_path),
        '--prefix','stream-native-modular','--attempt',str(args.attempt)])
    modular_path = OUT / f'stream-native-modular-matrix-{args.attempt}-report.json'
    modular = read(modular_path)
    assert modular['status'] == 'passed' and modular['records'] == 1408 and modular['native_records'] == 704
    assert len(modular['cohorts']) == 18 and all(item['independently_reopened'] for item in modular['cohorts'])
    report['modular'] = dict(summary=str(modular_path),summary_sha256=sha(modular_path),
        cohorts=18,records=1408,native_records=704)
    workload.check()
    assert generation(source) == source_generation and generation(target) == target_generation
    identities = {}
    for path, original in ((source,source_generation),(target,target_generation)):
        digest = sha(path)
        assert generation(path) == original
        identities[str(path)] = dict(sha256=digest,generation=original,resident_before_hash=True,unchanged_during_hash=True)
    assert identities[str(source)]['sha256'] == source_sha
    assert not (UAT/'.ingest-uat.lock').exists()
    unchanged()
    assert not host_errors, host_errors
    report.update(status='passed_local_fresh_uat',artifact_identities=identities,
        hashing_outside_native_timing=True,publication_performed=False)
except BaseException as error:
    report.update(status='failed',error=type(error).__name__+': '+str(error))
    raise
finally:
    stop_sampling.set()
    sampler.join(timeout=10)
    assert not sampler.is_alive()
    report['host_observations'] = dict(path=str(host_path),sha256=sha(host_path),errors=host_errors)
    save(results_path,report)
    print(json.dumps(dict(status=report['status'],results=str(results_path))),flush=True)
