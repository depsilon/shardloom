"""Package passed local fresh-UAT evidence as a streaming, byte-verified tar.xz."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tarfile
from dataclasses import dataclass, field

OUT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010/stream-fresh-uat-389')
REPO = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
UAT_ROOT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')
FROZEN_HEAD = 'ed253d1ec74b724215f71f0b410123656e596696'
GIB = 1024 ** 3
MIB = 1024 ** 2
CHUNK = 4 * MIB

sys.path.insert(0, str(REPO / 'scripts'))
from local_uat_storage import check_budgets, require_local_path  # noqa: E402


def sha256_file(path: Path) -> tuple[int, str]:
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        while True:
            chunk = stream.read(CHUNK)
            if not chunk:
                break
            digest.update(chunk)
            size += len(chunk)
    return size, digest.hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text())


def require_regular(path: Path) -> Path:
    resolved = require_local_path(path, Path.home(), sys.platform)
    info = path.lstat()
    if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
        raise ValueError(f'expected a regular, non-symlink evidence file: {path}')
    return resolved


def verify_file(path: Path, expected_sha: str | None = None,
                expected_bytes: int | None = None) -> tuple[int, str]:
    require_regular(path)
    before = path.stat()
    size, digest = sha256_file(path)
    after = path.stat()
    identity_before = (before.st_dev, before.st_ino, before.st_size,
                       before.st_mtime_ns, before.st_ctime_ns)
    identity_after = (after.st_dev, after.st_ino, after.st_size,
                      after.st_mtime_ns, after.st_ctime_ns)
    if identity_before != identity_after or size != after.st_size:
        raise ValueError(f'evidence changed while hashing: {path}')
    if expected_sha is not None and digest != expected_sha:
        raise ValueError(f'SHA-256 mismatch for {path}: expected {expected_sha}, got {digest}')
    if expected_bytes is not None and size != expected_bytes:
        raise ValueError(f'byte-count mismatch for {path}: expected {expected_bytes}, got {size}')
    return size, digest


@dataclass
class Member:
    path: Path
    name: str
    logical_root: str
    relative_path: str
    size: int
    digest: str
    roles: list[str] = field(default_factory=list)
    expected_hashes: set[str] = field(default_factory=set)


class MemberSet:
    def __init__(self) -> None:
        self.by_path: dict[Path, Member] = {}
        self.by_name: dict[str, Path] = {}

    def add(self, path: Path, name: str, root_key: str, root: Path,
            role: str, expected_sha: str | None = None,
            expected_bytes: int | None = None) -> Member:
        resolved = require_regular(path)
        normalized = PurePosixPath(name)
        if normalized.is_absolute() or '..' in normalized.parts or not normalized.parts:
            raise ValueError(f'unsafe archive member path: {name}')
        name = normalized.as_posix()
        existing_path = self.by_path.get(resolved)
        if existing_path is not None:
            if expected_sha is not None and existing_path.digest != expected_sha:
                raise ValueError(f'conflicting frozen SHA-256 for {path}')
            if expected_bytes is not None and existing_path.size != expected_bytes:
                raise ValueError(f'conflicting frozen byte count for {path}')
            existing_path.roles.append(role)
            if expected_sha is not None:
                existing_path.expected_hashes.add(expected_sha)
            return existing_path
        other = self.by_name.get(name)
        if other is not None:
            raise ValueError(f'archive member name collision: {name}: {other} and {path}')
        size, digest = verify_file(path, expected_sha, expected_bytes)
        try:
            relative = resolved.relative_to(root.resolve()).as_posix()
        except ValueError:
            relative = path.name
        member = Member(resolved, name, root_key, relative, size, digest,
                        [role], {expected_sha} if expected_sha else set())
        self.by_path[resolved] = member
        self.by_name[name] = resolved
        return member

    def add_tree(self, root_key: str, root: Path, prefix: str, role: str,
                 excluded: set[Path] | None = None) -> None:
        if root.is_symlink():
            raise ValueError(f'evidence root cannot be a symlink: {root}')
        root = require_local_path(root, Path.home(), sys.platform)
        if not root.is_dir():
            raise ValueError(f'evidence root must be a local directory: {root}')
        excluded = excluded or set()
        for path in sorted(root.rglob('*')):
            if path.is_symlink():
                raise ValueError(f'symlink found in evidence root: {path}')
            if path.is_dir():
                continue
            if path.resolve() in excluded:
                continue
            if not path.is_file():
                raise ValueError(f'unsupported filesystem object in evidence root: {path}')
            relative = path.relative_to(root).as_posix()
            self.add(path, f'{prefix}/{relative}', root_key, root, role)

    def ordered(self) -> list[Member]:
        return sorted(self.by_path.values(), key=lambda item: item.name)


class HashingReader:
    """Small read adapter used by tarfile to hash bytes as they stream into tar."""
    def __init__(self, stream):
        self.stream = stream
        self.digest = hashlib.sha256()
        self.count = 0

    def read(self, size: int = -1) -> bytes:
        data = self.stream.read(size)
        self.digest.update(data)
        self.count += len(data)
        return data


def verify_stage_receipts(results, out: Path, source_commit: str) -> list[tuple[Path, Path]]:
    expected = {'full-ingest', 'fresh-full43', 'modular-native'}
    stages = results['stages']
    if {item['stage'] for item in stages} != expected or len(stages) != 3:
        raise ValueError('fresh-UAT result must contain exactly the three completed guarded stages')
    checked = []
    for item in stages:
        receipt_path = Path(item['receipt'])
        if not receipt_path.is_absolute():
            receipt_path = (out / receipt_path).resolve()
        if not receipt_path.is_relative_to(out.resolve()):
            raise ValueError(f'guard receipt is outside fresh-UAT output: {receipt_path}')
        if sha256_file(receipt_path)[1] != item['sha256']:
            raise ValueError(f'guard receipt SHA-256 differs from results: {receipt_path}')
        receipt = read_json(receipt_path)
        if (receipt['status'] != 'passed' or receipt['returncode'] != 0 or
                receipt['head'] != source_commit or receipt['working_tree'].strip() or
                receipt['direct_child_reaped'] is not True or
                receipt['process_group_drained'] is not True or
                receipt['timed_out'] is not False or
                receipt['group_absence_unproved_at_cleanup'] is not False):
            raise ValueError(f'guard receipt failed status, identity, or cleanup checks: {receipt_path}')
        log_path = receipt_path.with_suffix('.log')
        verify_file(log_path, receipt['log_sha256'])
        checked.append((receipt_path, log_path))
    return checked


def make_name(results_path: Path) -> tuple[str, int]:
    match = re.fullmatch(r'stream-native-fresh-uat-(\d+)-results\.json', results_path.name)
    if not match:
        raise ValueError('results filename must follow stream-native-fresh-uat-{attempt}-results.json')
    attempt = int(match.group(1))
    return f'stream-native-fresh-uat-{attempt}-evidence', attempt


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--protocol', type=Path, required=True)
    parser.add_argument('--results', type=Path, required=True)
    args = parser.parse_args()
    require_local_path(OUT, Path.home(), sys.platform)
    protocol_path = args.protocol.resolve()
    results_path = args.results.resolve()
    if protocol_path.parent != OUT.resolve() or results_path.parent != OUT.resolve():
        raise ValueError('protocol and results must be direct children of the fresh-UAT output directory')
    verify_file(protocol_path)
    verify_file(results_path)
    stem, attempt = make_name(results_path)
    expected_protocol_name = f'stream-native-fresh-uat-{attempt}-protocol.json'
    if protocol_path.name != expected_protocol_name:
        raise ValueError('protocol and results attempt identifiers differ')
    archive = OUT / f'{stem}.tar.xz'
    manifest_path = OUT / f'{stem}.manifest.json'
    archive_partial = OUT / f'.{stem}.tar.xz.partial'
    manifest_partial = OUT / f'.{stem}.manifest.json.partial'
    for output in (archive, manifest_path, archive_partial, manifest_partial):
        if output.exists() or output.is_symlink():
            raise FileExistsError(f'refusing to replace existing package output: {output}')

    protocol = read_json(protocol_path)
    results = read_json(results_path)
    storage_helper = REPO / 'scripts/local_uat_storage.py'
    try:
        expected_storage_helper_sha = protocol['helpers'][str(storage_helper)]
    except KeyError as error:
        raise ValueError('protocol does not pin the shared local storage guard') from error
    if sha256_file(storage_helper)[1] != expected_storage_helper_sha:
        raise ValueError('shared local storage guard differs from its frozen protocol SHA-256')
    if protocol['status'] != 'frozen_before_fresh_uat':
        raise ValueError('protocol is not the frozen pre-UAT protocol')
    if results['status'] != 'passed_local_fresh_uat':
        raise ValueError('fresh-UAT results are incomplete or failed')
    if sha256_file(protocol_path)[1] != results['protocol_sha256']:
        raise ValueError('results protocol SHA-256 mismatch')
    if protocol['source_commit'] != FROZEN_HEAD:
        raise ValueError('protocol source commit differs from frozen merged main')
    if results.get('publication_performed') is not False:
        raise ValueError('fresh-UAT result does not prove publication was not performed')
    if results.get('hashing_outside_native_timing') is not True:
        raise ValueError('fresh-UAT result is missing the timing-boundary confirmation')

    build_path = Path(protocol['build_manifest'])
    if sha256_file(build_path)[1] != protocol['build_manifest_sha256']:
        raise ValueError('acceptance build manifest SHA-256 mismatch')
    build = read_json(build_path)
    if (build['binary'] != protocol['binary'] or build['binary_sha256'] != protocol['binary_sha256'] or
            build['source_commit'] != protocol['runtime_build_commit'] or
            build['accepted_source_commit'] != protocol['source_commit'] or
            build['working_tree'] != ''):
        raise ValueError('acceptance build manifest does not match protocol runtime/source identity')
    release_path = Path(build['original_release_manifest'])
    if sha256_file(release_path)[1] != build['original_release_manifest_sha256']:
        raise ValueError('original release manifest SHA-256 mismatch')
    release = read_json(release_path)
    if release['status'] != 'passed' or release['build_profile'] != 'release':
        raise ValueError('frozen release manifest did not pass its original build gate')
    if (release['head'] != build['source_commit'] or
            release['cli']['path'] != protocol['binary'] or
            release['cli']['sha256'] != protocol['binary_sha256']):
        raise ValueError('release manifest and protocol runtime identity disagree')

    source_manifest_path = Path(release['source_manifest']['path'])
    verify_file(source_manifest_path, release['source_manifest']['sha256'])
    source_manifest = read_json(source_manifest_path)
    if source_manifest['source_sha256'] != release['source_sha256']:
        raise ValueError('release source manifest does not match release source hashes')
    if build['source_hashes'].keys() != release['source_sha256'].keys():
        raise ValueError('accepted source snapshot and release source inventory differ')
    cli = release['cli']
    build_receipt_path = Path(cli['build_receipt'])
    verify_file(build_receipt_path, cli['build_receipt_sha256'])
    build_receipt = read_json(build_receipt_path)
    if (build_receipt['status'] != 'passed' or build_receipt['returncode'] != 0 or
            build_receipt['head'] != release['head'] or build_receipt['working_tree'].strip() or
            build_receipt['direct_child_reaped'] is not True or
            build_receipt['process_group_drained'] is not True or
            build_receipt['timed_out'] is not False or
            build_receipt['group_absence_unproved_at_cleanup'] is not False):
        raise ValueError('frozen release build receipt failed identity or cleanup verification')
    build_log_path = Path(cli['build_log'])
    verify_file(build_log_path, build_receipt['log_sha256'])

    expected_harness_changes = {
        'scripts/local_uat_storage.py',
        'scripts/run_clickbench_paired_query_uat.py',
        'scripts/run_clickbench_query_uat.py',
        'scripts/run_local_readonly_proof.py',
        'scripts/test_clickbench_query_uat.py',
        'scripts/test_local_uat_storage.py',
        'scripts/test_run_local_readonly_proof.py',
    }
    changes = build['changed_harness_only']
    if set(changes) != expected_harness_changes or changes != protocol['changed_since_build_harness_only']:
        raise ValueError('protocol/build do not record exactly the seven authorized harness changes')
    if protocol['source_hashes'] != build['source_hashes']:
        raise ValueError('protocol source hash map differs from acceptance build manifest')
    actual_changes = {
        relative: dict(build_sha256=digest, current_sha256=build['source_hashes'][relative])
        for relative, digest in release['source_sha256'].items()
        if digest != build['source_hashes'][relative]
    }
    if actual_changes != changes:
        raise ValueError('recorded harness changes do not match the source manifests')
    for relative, hashes in changes.items():
        if (hashes['build_sha256'] != release['source_sha256'][relative] or
                hashes['current_sha256'] != build['source_hashes'][relative]):
            raise ValueError(f'harness source provenance mismatch: {relative}')

    # The driver owns the exact identity records for the original Parquet input and fresh Vortex output.
    identities = results['artifact_identities']
    source_identity = identities[protocol['source']]
    target_identity = identities[protocol['target']]
    if (source_identity['sha256'] != protocol['source_sha256'] or
            source_identity['generation'] != protocol['source_generation'] or
            source_identity['generation']['size_bytes'] != protocol['source_generation']['size_bytes'] or
            source_identity['resident_before_hash'] is not True or
            source_identity['unchanged_during_hash'] is not True or
            target_identity['resident_before_hash'] is not True or
            target_identity['unchanged_during_hash'] is not True or
            target_identity['generation']['size_bytes'] <= 0):
        raise ValueError('results artifact identities do not match frozen input/output identity')
    for excluded in (protocol['source'], protocol['target'], protocol['binary']):
        require_local_path(Path(excluded), Path.home(), sys.platform)
    if (protocol['binary_sha256'] != release['cli']['sha256'] or
            release['cli']['bytes'] <= 0):
        raise ValueError('frozen binary identity is incomplete')

    query_path = REPO / 'benchmarks/clickbench/queries.sql'
    verify_file(query_path, protocol['queries_sha256'])
    reference_path = Path(protocol['reference_packet'])
    verify_file(reference_path, protocol['reference_packet_sha256'])

    if (results['ingest']['complete_rows'] != 99_997_497 or
            results['queries']['complete_runs'] != 129 or
            results['queries']['independently_reopened_calls'] != 129 or
            results['queries']['complete_rows'] != 1143 or
            results['modular']['cohorts'] != 18 or results['modular']['records'] != 1408 or
            results['modular']['native_records'] != 704):
        raise ValueError('fresh-UAT results do not prove the driver-required ingest/query/modular counts')
    ingest_summary_path = Path(results['ingest']['summary'])
    query_summary_path = Path(results['queries']['summary'])
    modular_summary_path = Path(results['modular']['summary'])
    verify_file(ingest_summary_path, results['ingest']['summary_sha256'])
    verify_file(query_summary_path, results['queries']['summary_sha256'])
    verify_file(modular_summary_path, results['modular']['summary_sha256'])
    ingest_summary = read_json(ingest_summary_path)
    query_summary = read_json(query_summary_path)
    modular_summary = read_json(modular_summary_path)
    if (ingest_summary['returncode'] != 0 or ingest_summary['stop_reason'] != 'process_completed' or
            ingest_summary['stdout_json_ok'] is not True):
        raise ValueError('referenced ingest summary is incomplete or failed')
    if (not query_summary['complete'] or not query_summary['full_result_validation'] or
            not query_summary['completed_identity_check'] or
            not query_summary['harness_identity_verified'] or
            not query_summary['reference_packet_identity_verified'] or
            query_summary['runs_completed'] != 129 or query_summary['runs_passed'] != 129 or
            len(query_summary['records']) != 129 or
            query_summary['binary_sha256'] != protocol['binary_sha256'] or
            query_summary['build_commit'] != protocol['runtime_build_commit'] or
            query_summary['source'] != protocol['target'] or
            query_summary['source_generation'] != target_identity['generation'] or
            not all(row['passed'] and row['returncode'] == 0 and
                    row['validation'] == 'complete_values' and not row['guard_failures']
                    for row in query_summary['records'])):
        raise ValueError('referenced Full43 summary does not prove all 129 validated runs')
    if (modular_summary['status'] != 'passed' or modular_summary['records'] != 1408 or
            modular_summary['native_records'] != 704 or len(modular_summary['cohorts']) != 18 or
            modular_summary['binary_sha256'] != protocol['binary_sha256'] or
            modular_summary['build_manifest_sha256'] != protocol['build_manifest_sha256'] or
            not all(item['independently_reopened'] for item in modular_summary['cohorts'])):
        raise ValueError('referenced modular report does not prove all independently reopened cohorts')
    for cohort in modular_summary['cohorts']:
        verify_file(Path(cohort['report']), cohort['report_sha256'])

    stage_receipt_pairs = verify_stage_receipts(results, OUT, protocol['source_commit'])
    host = results['host_observations']
    verify_file(Path(host['path']), host['sha256'])
    if host['errors']:
        raise ValueError('fresh-UAT host sampler reported errors')

    # These checks are intentionally applied immediately before packaging. The two roots
    # cover the external UAT workspace and this run's separate evidence/output workspace.
    require_local_path(OUT, Path.home(), sys.platform)
    require_local_path(UAT_ROOT, Path.home(), sys.platform)
    members = MemberSet()
    excluded_paths = {Path(protocol['source']).resolve(), Path(protocol['target']).resolve(),
                      Path(protocol['binary']).resolve()}
    for identity_path in identities:
        if identity_path.lower().endswith('.vortex'):
            excluded_paths.add(Path(identity_path).resolve())
    members.add_tree('fresh_uat_output', OUT, 'fresh-uat-389',
                     'fresh-UAT driver, results, modular fixtures/reports, and local logs',
                     excluded=excluded_paths)
    ingest_parent = ingest_summary_path.parent.resolve()
    query_parent = query_summary_path.parent.resolve()
    for label, parent in (('ingest_logs', ingest_parent), ('full43_logs', query_parent)):
        if not parent.is_relative_to((UAT_ROOT / 'logs').resolve()):
            raise ValueError(f'{label} summary parent is outside the declared UAT log tree: {parent}')
        members.add_tree(label, parent, label.replace('_', '-'),
                         f'complete summary parent and all associated raw/compressed files')
    members.add(query_path, 'inputs/clickbench/queries.sql', 'repository', REPO,
                'frozen ClickBench query definitions', protocol['queries_sha256'])
    members.add(reference_path, 'inputs/clickbench/reference-packet.json', 'reference_packet',
                reference_path.parent, 'complete frozen ClickBench reference packet',
                protocol['reference_packet_sha256'])
    external_files = [
        (release_path, 'release/original-release-manifest.json', 'prior_artifacts',
         'frozen release artifact manifest', build['original_release_manifest_sha256']),
        (source_manifest_path, 'release/source-manifest.json', 'prior_artifacts',
         'frozen release source manifest', release['source_manifest']['sha256']),
        (build_receipt_path, 'release/build-receipt.json', 'prior_artifacts',
         'frozen release build receipt', cli['build_receipt_sha256']),
        (build_log_path, 'release/build.log', 'prior_artifacts',
         'frozen release build log', build_receipt['log_sha256']),
    ]
    for path, name, root_key, role, expected in external_files:
        members.add(path, name, root_key, path.parent, role, expected)
    for index, (path_text, expected_sha) in enumerate(protocol['helpers'].items()):
        path = Path(path_text)
        members.add(path, f'frozen-helpers/{index:02d}-{path.name}', 'frozen_helpers',
                    path.parent, 'protocol-pinned helper', expected_sha)
    for receipt_path, log_path in stage_receipt_pairs:
        members.add(receipt_path, f'fresh-uat-389/{receipt_path.name}', 'fresh_uat_output', OUT,
                    'guarded stage receipt')
        members.add(log_path, f'fresh-uat-389/{log_path.name}', 'fresh_uat_output', OUT,
                    'guarded stage log')
    members.add(Path(__file__), f'fresh-uat-389/{Path(__file__).name}',
                'fresh_uat_output', OUT, 'evidence packager source')

    ordered = members.ordered()
    if not ordered:
        raise ValueError('refusing to create an empty evidence package')
    total_bytes = sum(item.size for item in ordered)
    reserve = total_bytes + max(64 * MIB, total_bytes // 50)
    require_local_path(archive, Path.home(), sys.platform)

    def check_package_budgets(reserve_bytes: int) -> None:
        for root in (UAT_ROOT, OUT):
            check_budgets(root, archive, root / 'logs' if root == UAT_ROOT else OUT,
                          min_free_bytes=12 * GIB, reserve_bytes=reserve_bytes,
                          max_workspace_bytes=100 * GIB, max_log_bytes=1024 * MIB)

    check_package_budgets(reserve)

    logical_roots = {
        'fresh_uat_output': str(OUT),
        'ingest_logs': str(ingest_parent),
        'full43_logs': str(query_parent),
        'repository': str(REPO),
        'reference_packet': str(reference_path.parent),
        'prior_artifacts': str(release_path.parent),
        'frozen_helpers': 'individual absolute helper paths recorded in protocol.helpers',
    }
    member_records = [dict(archive_path=item.name, logical_root=item.logical_root,
                           relative_path=item.relative_path,
                           original_absolute_path=str(item.path), byte_count=item.size,
                           sha256=item.digest, roles=item.roles)
                      for item in ordered]
    excluded_assets = [
        dict(kind='original Parquet source', path=protocol['source'],
             byte_count=source_identity['generation']['size_bytes'],
             sha256=source_identity['sha256'], evidence='frozen protocol and final results'),
        dict(kind='fresh Vortex output/input', path=protocol['target'],
             byte_count=target_identity['generation']['size_bytes'],
             sha256=target_identity['sha256'], evidence='final result artifact identity'),
        dict(kind='frozen release binary', path=protocol['binary'],
             byte_count=release['cli']['bytes'], sha256=protocol['binary_sha256'],
             evidence='frozen protocol and release manifest'),
    ]
    for identity_path, identity in identities.items():
        if identity_path.lower().endswith('.vortex') and identity_path != protocol['target']:
            generation = identity['generation']
            excluded_assets.append(dict(kind='additional Vortex input identified by results',
                path=identity_path, byte_count=generation['size_bytes'],
                sha256=identity['sha256'], evidence='final result artifact identity'))
    temp_created = False
    try:
        with archive_partial.open('xb') as output_stream:
            temp_created = True
            with tarfile.open(fileobj=output_stream, mode='w|xz',
                              format=tarfile.PAX_FORMAT) as tar:
                for item in ordered:
                    before = item.path.stat()
                    if before.st_size != item.size:
                        raise ValueError(f'evidence size changed before archiving: {item.path}')
                    info = tarfile.TarInfo(item.name)
                    info.size = item.size
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ''
                    with item.path.open('rb') as source_stream:
                        reader = HashingReader(source_stream)
                        tar.addfile(info, reader)
                    if reader.count != item.size or reader.digest.hexdigest() != item.digest:
                        raise ValueError(f'evidence bytes changed while archiving: {item.path}')
                    after = item.path.stat()
                    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (
                            after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns):
                        raise ValueError(f'evidence file changed during archive write: {item.path}')

        archived: set[str] = set()
        with tarfile.open(archive_partial, mode='r|xz') as tar:
            for info in tar:
                if info.name in archived or info.name not in members.by_name:
                    raise ValueError(f'unexpected or duplicate archive member: {info.name}')
                archived.add(info.name)
                if not info.isfile() or info.size != members.by_path[members.by_name[info.name]].size:
                    raise ValueError(f'archive member type/size mismatch: {info.name}')
                member = members.by_path[members.by_name[info.name]]
                stream = tar.extractfile(info)
                if stream is None:
                    raise ValueError(f'cannot reopen archive member: {info.name}')
                digest = hashlib.sha256()
                count = 0
                while True:
                    chunk = stream.read(CHUNK)
                    if not chunk:
                        break
                    digest.update(chunk)
                    count += len(chunk)
                if count != member.size or digest.hexdigest() != member.digest:
                    raise ValueError(f'archived bytes differ from original evidence: {info.name}')
                verify_file(member.path, member.digest, member.size)
        if archived != set(members.by_name):
            missing = sorted(set(members.by_name) - archived)
            raise ValueError(f'archive is missing evidence members: {missing[:8]}')
        archive_size, archive_digest = sha256_file(archive_partial)
        os.link(archive_partial, archive)
        archive_partial.unlink()
        temp_created = False

        manifest = dict(
            schema_version='shardloom.local_fresh_uat_evidence.v1',
            status='passed',
            package='local-fresh-uat-389',
            result_status=results['status'],
            protocol_path=str(protocol_path),
            results_path=str(results_path),
            source_commit=protocol['source_commit'],
            runtime_build_commit=protocol['runtime_build_commit'],
            outputs=dict(archive_path=str(archive), archive_byte_count=archive_size,
                         archive_sha256=archive_digest),
            logical_root_mappings=logical_roots,
            excluded_assets=excluded_assets,
            explicitly_excluded_bulk=['original hits.parquet at protocol.source',
                                      'fresh Vortex output/input at protocol.target',
                                      'frozen release binary at protocol.binary',
                                      'any additional Vortex input named in results.artifact_identities'],
            coverage=dict(fresh_uat_output_files=True, complete_ingest_summary_parent=True,
                          complete_full43_summary_parent=True, complete_modular_output_fixtures_reports=True,
                          protocol_helpers_verified=True, clickbench_queries_and_reference_packet=True),
            uat_results=dict(ingest_rows=results['ingest']['complete_rows'],
                             full43_calls=results['queries']['complete_runs'],
                             full43_rows=results['queries']['complete_rows'],
                             modular_cohorts=results['modular']['cohorts'],
                             modular_records=results['modular']['records'],
                             modular_native_records=results['modular']['native_records']),
            member_count=len(member_records), original_member_bytes=total_bytes,
            members=member_records,
            assumptions=[
                'The attempt is identified by the explicit protocol/results filenames.',
                'All files under the dedicated fresh-UAT directory are evidence or modular fixtures; '
                'large external inputs and the frozen binary are excluded by their protocol paths.',
                'The driver result references the complete ingest and Full43 log-parent directories.',
                'A prior Vortex input is recorded with identity when results.artifact_identities names it; '
                'external files outside the declared evidence roots are never traversed.',
            ])
        manifest_bytes = (json.dumps(manifest, sort_keys=True, indent=2, ensure_ascii=False) + '\n').encode()
        with manifest_partial.open('xb') as stream:
            stream.write(manifest_bytes)
        check_package_budgets(64 * MIB)
        os.link(manifest_partial, manifest_path)
        manifest_partial.unlink()
        print(json.dumps(dict(status='passed', archive=str(archive), manifest=str(manifest_path),
                              member_count=len(member_records), original_member_bytes=total_bytes,
                              archive_bytes=archive_size, archive_sha256=archive_digest), indent=2))
    finally:
        if temp_created:
            archive_partial.unlink(missing_ok=True)
        manifest_partial.unlink(missing_ok=True)


if __name__ == '__main__':
    main()
