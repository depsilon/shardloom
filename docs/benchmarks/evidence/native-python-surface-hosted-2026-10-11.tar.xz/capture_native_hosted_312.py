"""Capture final hosted state and compare production files with the accepted tree."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import urllib.request

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
HEAD = 'f0e9404702469f997de0bd813fe51b5ea02161df'
MERGE = '88b44c1366d85d216a069def1d8315124e63ff41'

def run(*args):
    return subprocess.check_output(args, cwd=ROOT)

pr = json.loads(run('gh', 'pr', 'view', '1541', '--repo', 'depsilon/shardloom', '--json',
                   'number,state,headRefOid,baseRefOid,mergeCommit,mergedAt,url,statusCheckRollup'))
assert pr['state'] == 'MERGED' and pr['headRefOid'] == HEAD and pr['mergeCommit']['oid'] == MERGE
assert len(pr['statusCheckRollup']) == 44
assert all(item['status'] == 'COMPLETED' and item['conclusion'] == 'SUCCESS' for item in pr['statusCheckRollup'])
trees = {commit:run('git','rev-parse',f'{commit}^{{tree}}').decode().strip() for commit in (HEAD,MERGE)}
assert len(set(trees.values())) == 1
checks = json.loads(run('gh','api',f'repos/depsilon/shardloom/commits/{MERGE}/check-runs?per_page=100'))
deployment = [item for item in checks['check_runs'] if item['name'] == 'Workers Builds: shardloom']
assert len(deployment) == 1 and deployment[0]['conclusion'] == 'success'
observations = []
for relative, url in (
    ('website/field-guide/python-surface/index.html','https://shardloom.io/field-guide/python-surface/'),
    ('website/field-guide/runtime-and-io/index.html','https://shardloom.io/field-guide/runtime-and-io/'),
):
    expected = run('git','show',f'{HEAD}:{relative}')
    request = urllib.request.Request(url, headers={'User-Agent':'ShardLoom-owned-site-verification'})
    with urllib.request.urlopen(request, timeout=30) as response:
        actual = response.read(2 << 20)
        assert response.status == 200 and len(actual) < (2 << 20)
        final_url = response.url
    observations.append({'source':relative,'url':url,'final_url':final_url,'http_status':200,
                         'expected_bytes':len(expected),'observed_bytes':len(actual),
                         'expected_sha256':hashlib.sha256(expected).hexdigest(),
                         'observed_sha256':hashlib.sha256(actual).hexdigest(),
                         'byte_identical':actual == expected})
record = {'status':'passed','observed_at':datetime.now(timezone.utc).isoformat(),
          'pr':pr,'trees':trees,'production_deployment':deployment[0],
          'production_files':observations,'publication_attempted':False,
          'scope':'Final PR checks and identical merge tree, exact-merge website deployment, and production file identity. Main-branch CI, runtime timings and package publication are not inferred.'}
target = OUT/'native-final-hosted-312.json'
assert not target.exists()
target.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':record['status'],'checks':len(pr['statusCheckRollup']),
                  'tree':next(iter(trees.values())), 'production_files':observations},indent=2))
