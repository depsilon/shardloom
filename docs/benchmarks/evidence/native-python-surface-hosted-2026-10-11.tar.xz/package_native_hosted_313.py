"""Preserve and completely reopen the final native-interface hosted evidence."""
from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import tarfile

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
DEST = ROOT / 'docs/benchmarks/evidence'
PACKET = DEST / 'native-python-surface-hosted-2026-10-11.tar.xz'
RECEIPT = DEST / 'native-python-surface-hosted-2026-10-11.json'
HEAD = 'f0e9404702469f997de0bd813fe51b5ea02161df'
MERGE = '88b44c1366d85d216a069def1d8315124e63ff41'
sha = lambda b: hashlib.sha256(b).hexdigest()
load = lambda name: json.loads((OUT / name).read_text())
hosted = load('native-final-hosted-312.json')
reviews = load('native-final-reviews-312.json')['review_threads']
inventory = load('native-wheel-hosted-evidence-312-inventory.json')
html = load('native-production-html-comparison-312.json')
ui = load('native-production-ui-312.json')
assert hosted['status'] == 'passed'
pr = hosted['pr']
assert pr['headRefOid'] == HEAD and pr['mergeCommit']['oid'] == MERGE
assert pr['state'] == 'MERGED' and pr['number'] == 1541
checks = pr['statusCheckRollup']
assert len(checks) == 44
assert all(row['status'] == 'COMPLETED' and row['conclusion'] == 'SUCCESS' for row in checks)
assert len(reviews) == 18 and all(row['is_resolved'] for row in reviews)
trees = {commit: subprocess.check_output(['git', 'rev-parse', commit + '^{tree}'], cwd=ROOT, text=True).strip()
         for commit in (HEAD, MERGE)}
assert trees == hosted['trees'] and len(set(trees.values())) == 1
deployment = hosted['production_deployment']
assert deployment['head_sha'] == MERGE and deployment['status'] == 'completed'
assert deployment['conclusion'] == 'success'
files = {
    name: (OUT / name).read_bytes() for name in (
        'native-final-hosted-312.json', 'native-final-reviews-312.json',
        'native-wheel-hosted-evidence-312-inventory.json',
        'native-production-html-comparison-312.json', 'native-production-ui-312.json',
        'native-production-ownership-312.png', 'native-production-search-312.png',
        'capture_native_hosted_312.py', 'package_native_hosted_313.py',
    )
}
wheel_rows = []
for job in inventory['jobs']:
    log = Path(job['source_log']['path'])
    report = Path(job['report']['path'])
    assert log.parent == OUT and report.parent == OUT
    raw_log, raw_report = log.read_bytes(), report.read_bytes()
    assert sha(raw_log) == job['source_log']['sha256']
    assert sha(raw_report) == job['report']['sha256']
    proof = json.loads(raw_report)
    text = re.sub(r'^\d{4}-\d{2}-\d{2}T\S+ ', '', raw_log.decode(), flags=re.MULTILINE)
    decoded = []
    for match in re.finditer(r'^\{', text, flags=re.MULTILINE):
        try:
            value, _ = json.JSONDecoder().raw_decode(text[match.start():])
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict) and value.get('integration') == proof['integration'] and 'steps' in value:
            decoded.append(value)
    assert len(decoded) == 1 and decoded[0] == proof
    assert proof['status'] == 'passed' and not proof['publication_attempted']
    assert not proof['performance_claim']
    integration = proof['integration']
    assert integration == {'tests': 75, 'failures': 0, 'errors': 0, 'skipped': 0, 'status': 'passed'}
    assert all(step['returncode'] == 0 for step in proof['steps'])
    assert job['checkout']['pr_head_commit'] == HEAD
    assert job['checkout']['commit'] == '676141184b435545cc3be0112e217c350341656b'
    assert job['host_python_wheel']['isolated_install']
    files[log.name], files[report.name] = raw_log, raw_report
    wheel_rows.append({
        'job_id': job['job_id'], 'job': job['workflow_job'],
        'host': job['host_python_wheel'], 'integration': integration,
        'source_log': log.name, 'proof_report': report.name,
        'complete_report_redecoded_from_log': True,
        'individual_method_name_recount': False,
    })
assert len(wheel_rows) == 3
for row in html['observations']:
    name = row['name']
    names = {kind: f'native-production-{name}-312-{kind}.html'
             for kind in ('expected', 'observed', 'insertion')}
    values = {kind: (OUT / path).read_bytes() for kind, path in names.items()}
    source = subprocess.check_output(['git', 'show', MERGE + ':' + row['source']], cwd=ROOT)
    assert values['expected'] == source
    assert sha(source) == row['expected_sha256']
    assert sha(values['observed']) == row['actual_sha256']
    assert sha(values['insertion']) == row['insertion_sha256']
    offset = row['insertion_offset']
    assert values['observed'] == source[:offset] + values['insertion'] + source[offset:]
    assert len(values['insertion']) == row['insertion_bytes'] == 1305
    assert row['source_equal_except_single_insertion'] and row['status'] == 200
    assert b'challenge-platform' in values['insertion'] and b'static.cloudflareinsights.com' in values['insertion']
    files.update({names[kind]: value for kind, value in values.items()})
assert not html['unconditional_byte_identity_claim']
assert ui['console'] == [] and ui['search']['clicked_result_reached_expected_anchor']
assert ui['viewport']['bodyWidth'] == ui['viewport']['documentWidth'] == 1265
assert ui['viewport']['width'] == 1280 and ui['viewport']['height'] == 720
assert not PACKET.exists() and not RECEIPT.exists()
members = [{'path': name, 'bytes': len(value), 'sha256': sha(value)}
           for name, value in sorted(files.items())]
manifest = {'schema_version': 'shardloom.native_python_hosted_packet.v1',
            'members': members, 'scope': 'Final PR, native wheel and production observations; no new performance or publication claim.'}
manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
with tarfile.open(PACKET, 'x:xz', preset=6) as tar:
    for name, value in [('manifest.json', manifest_bytes), *sorted(files.items())]:
        entry = tarfile.TarInfo(name)
        entry.size, entry.mode, entry.mtime = len(value), 0o644, 0
        tar.addfile(entry, io.BytesIO(value))
with tarfile.open(PACKET, 'r:xz') as tar:
    assert tar.getnames() == ['manifest.json', *sorted(files)]
    assert tar.extractfile('manifest.json').read() == manifest_bytes
    for name, value in files.items():
        assert tar.extractfile(name).read() == value
record = {
    'schema_version': 'shardloom.native_python_hosted_acceptance.v1', 'status': 'passed',
    'pr_url': 'https://github.com/depsilon/shardloom/pull/1541',
    'accepted_head': HEAD, 'merged_commit': MERGE, 'merged_at': pr['mergedAt'],
    'accepted_and_merged_trees': trees, 'accepted_and_merged_tree_identical': True,
    'checks': checks, 'successful_checks': len(checks),
    'resolved_review_threads': len(reviews), 'wheel_proofs': wheel_rows,
    'production_deployment': {key: deployment[key] for key in
        ('id', 'head_sha', 'details_url', 'status', 'conclusion', 'completed_at')},
    'production_html': html, 'production_ui': ui,
    'packet': {'path': PACKET.name, 'bytes': PACKET.stat().st_size, 'sha256': sha(PACKET.read_bytes()),
               'payload_members': len(files), 'complete_member_readback_verified': True},
    'publication_attempted': False, 'performance_claim': False,
    'limitations': [
        'The three installed native wheel reports prove runner counters and successful gates; individual integration method transcripts were not printed in these job logs.',
        'Production HTML preserves the merged source except one observed 1305-byte Cloudflare challenge/analytics insertion; raw responses are not byte-identical to source.',
        'Actual hosted UI proof is desktop at 1280 by 720; earlier local mobile evidence remains separate.',
        'Original local workflow timings keep their original source identity; final hosted success is not a new benchmark or package release.',
    ],
}
RECEIPT.write_text(json.dumps(record, indent=2) + '\n')
assert json.loads(RECEIPT.read_text()) == record
print(json.dumps({'status': 'passed', 'checks': len(checks), 'wheel_reports': len(wheel_rows),
                  'packet_bytes': PACKET.stat().st_size, 'verified_payload_members': len(files)}))
