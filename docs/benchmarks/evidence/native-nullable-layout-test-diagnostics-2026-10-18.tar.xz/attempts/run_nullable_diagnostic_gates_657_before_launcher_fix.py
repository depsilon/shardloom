"""Validate test-only diagnostic cleanup without changing accepted runtime evidence."""
import json
import os
import subprocess
import time

from freeze_native_release_298 import ROOT, OUT, save, sha, sources

before_path = OUT / 'native-release-source-nullable650a1.json'
after_path = OUT / 'native-release-source-nullable657.json'
before = json.loads(before_path.read_text())['source_sha256']
after = json.loads(after_path.read_text())['source_sha256']
changed = {name: dict(before=before[name], after=after[name])
           for name in before if before[name] != after[name]}
assert set(before) == set(after) and len(after) == 2416
assert set(changed) == {
    'vendor/vortex-file/src/tests.rs',
    'vendor/vortex-layout/src/layouts/struct_/reader/tests/nullable.rs',
}
assert sources() == after
assert '#[cfg(test)]\nmod tests;' in (ROOT / 'vendor/vortex-file/src/lib.rs').read_text()
assert '#[cfg(test)]\nmod tests;' in (ROOT / 'vendor/vortex-layout/src/layouts/struct_/reader.rs').read_text()
array_patch = 'patch.crates-io.vortex-array.path="vendor/vortex-array"'
layout_patch = 'patch.crates-io.vortex-layout.path="vendor/vortex-layout"'
layout = ['--manifest-path', 'vendor/vortex-layout/Cargo.toml', '--offline',
          '--config', array_patch, '--features', 'tokio,vortex-io/tokio,vortex-array/_test-harness']
file = ['--manifest-path', 'vendor/vortex-file/Cargo.toml', '--offline',
        '--config', array_patch, '--config', layout_patch, '--features', 'tokio,vortex-array/table-display']
commands = [
    ('workspace-format', ['cargo', 'fmt', '--all', '--', '--check'], False),
    ('layout-format', ['cargo', 'fmt', '--manifest-path', 'vendor/vortex-layout/Cargo.toml', '--', '--check'], False),
    ('file-format', ['cargo', 'fmt', '--manifest-path', 'vendor/vortex-file/Cargo.toml', '--', '--check'], False),
    ('workspace-clippy', ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings'], False),
    ('workspace-tests', ['cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets'], False),
    ('layout-tests', ['cargo', 'test', *layout, '--lib', '--', '--test-threads=2'], True),
    ('file-tests', ['cargo', 'test', *file, '--lib', '--', '--test-threads=2'], True),
    ('layout-clippy', ['cargo', 'clippy', *layout, '--lib', '--tests', '--', '-D', 'warnings'], True),
    ('file-clippy', ['cargo', 'clippy', *file, '--lib', '--tests', '--', '-D', 'warnings'], True),
]
gates = []
passed = False
try:
    for name, command, provider in commands:
        env = dict(os.environ, RUST_TEST_THREADS='2')
        env.pop('CLIPPY_CONF_DIR', None)
        if provider:
            env['CLIPPY_CONF_DIR'] = str(ROOT / 'vendor/vortex-array')
        print(json.dumps(dict(gate=name, command=command)), flush=True)
        started = time.perf_counter()
        result = subprocess.run(command, cwd=ROOT, env=env, check=False)
        gates.append(dict(name=name, command=command, returncode=result.returncode,
                          diagnostic_seconds=time.perf_counter() - started))
        assert sources() == after
        if result.returncode:
            raise SystemExit(result.returncode)
    passed = True
finally:
    save(OUT / 'nullable-layout-diagnostic-bridge-657.json', dict(
        status='passed' if passed else 'failed', source_files=len(after),
        accepted_build_source=dict(path=str(before_path), sha256=sha(before_path)),
        tested_source=dict(path=str(after_path), sha256=sha(after_path)),
        changes=changed, gates=gates,
        runtime_scope='Only two cfg(test) source files differ; non-test runtime sources and the accepted executable identities remain unchanged. Native and recursively canonical equality checks are preserved.')))
