"""Bind test-only CI cleanup to unchanged accepted native runtime evidence."""
import ast
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

from freeze_native_release_298 import ROOT as R, OUT as O, save, sha, sources

read = lambda p: json.loads(Path(p).read_text())
identity = lambda p: dict(path=str(p), bytes=Path(p).stat().st_size, sha256=sha(p))
frozen = O / 'native-release-source-nullable657a4.json'
bridge_path = O / 'nullable-layout-diagnostic-bridge-657-a4.json'
bridge = read(bridge_path)
assert bridge['status'] == 'passed' and len(bridge['gates']) == 9
assert all(g['returncode'] == 0 for g in bridge['gates'])
expected = read(frozen)['source_sha256']
assert len(expected) == 2416 and sources() == expected
receipt = read(O / 'nullable-layout-diagnostic-gates-657-a4.json')
assert receipt['status'] == 'passed' and receipt['process_group_drained']
log_path = O / 'nullable-layout-diagnostic-gates-657-a4.log'
assert sha(log_path) == receipt['log_sha256']
log = log_path.read_text()
groups = [tuple(map(int, match)) for match in re.findall(
    r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)]
assert groups[-2:] == [(249, 0, 0), (140, 0, 0)]
assert all(failed == ignored == 0 for _, failed, ignored in groups)
assert sum(passed for passed, _, _ in groups[:-2]) == 3225
ci = read(O / 'nullable-layout-test-lint-ci-657.json')
assert ci['status'] == 'passed'
workflow = (R / '.github/workflows/ci.yml').read_text()
assert '--features tokio,vortex-io/tokio,vortex-array/_test-harness --lib --tests -- -D warnings' in workflow
assert '--features tokio,vortex-array/table-display --lib --tests -- -D warnings' in workflow
artifacts = read(O / 'native-release-artifacts-nullable650a1.json')
for field in ('cli', 'binding'):
    assert sha(artifacts[field]['path']) == artifacts[field]['sha256']

original_inventory = O / 'nullable-layout-hosted-test-inventory-652.json'
inventory = read(original_inventory)
inventory['source_manifest'] = dict(identity(frozen), declared_head=read(frozen)['head'])
inventory['original_inventory'] = identity(original_inventory)
inventory['diagnostic_bridge'] = identity(bridge_path)
for record in inventory['native_regression_tests'] + sum(inventory['provider_regression_tests'].values(), []):
    raw = (R / record['path']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == expected[record['path']]
    matches = list(re.finditer(r'^(?:async\s+)?fn\s+' + re.escape(record['function_name']) + r'\s*\(', raw.decode(), re.M))
    assert len(matches) == 1
    record.update(line=raw.decode().count('\n', 0, matches[0].start()) + 1, source_sha256=expected[record['path']])
for record in inventory['runtime_sources']:
    path = R / record['path']
    record.update(bytes=path.stat().st_size, sha256=sha(path), source_manifest_sha256=expected[record['path']])
inventory['created_by'] = identity(Path(__file__))
save(O / 'nullable-layout-hosted-test-inventory-657.json', inventory)

triage_root = Path('/Users/dylan/.codex/state/plugins/codex-security/scans/shardloom-local-repo/artifacts-59a3b570d9b03fb322db2de2719f926fc9ec85ff7a709d372b445bb840fd6b4f/artifacts/nullable-layout-codeql-656')
triage = read(triage_root / 'triage.json')
assert len(triage['findings']) == 4 and all(f['verdict'] == 'not_actionable' for f in triage['findings'])
files = {}
def add(name, path):
    path = Path(path)
    assert name not in files and path.is_file() and not path.is_symlink(), path
    files[name] = path
for pattern in ('native-release-source-nullable657*.json', 'nullable-layout-diagnostic-*.json',
                'nullable-layout-diagnostic-*.log', 'run_nullable_diagnostic_gates_657*.py',
                'nullable-layout-original-*-657.json'):
    for path in sorted(O.glob(pattern)):
        add('attempts/' + path.name, path)
for path in sorted(triage_root.iterdir()):
    if path.is_file():
        add('original-triage/' + path.name, path)
for name in ('nullable-layout-test-lint-ci-657.json', 'native-release-source-nullable650a1.json',
             'native-release-artifacts-nullable650a1.json', 'nullable-layout-hosted-test-inventory-657.json',
             'freeze_native_release_298.py', 'run_guarded.py', 'package_nullable_diagnostic_657.py'):
    add('support/' + name, O / name)
for name in sorted(set(bridge['changes']) | {
    '.github/workflows/ci.yml', 'docs/release/ci-gate-matrix.md',
    'vendor/vortex-layout/src/layouts/struct_/reader.rs',
    'scripts/local_uat_storage.py', 'scripts/check_ci_gate_matrix.py'}):
    add('source/' + name, R / name)
patch = subprocess.check_output(['git', 'diff', '--binary', '807c10ac423e0e7978158242e0e515629dfae80c', '--', *sorted(bridge['changes']), '.github/workflows/ci.yml'], cwd=R)
patch_path = O / 'nullable-layout-diagnostic-source-657.patch'
with patch_path.open('xb') as f:
    f.write(patch)
add('source/diagnostic.patch', patch_path)
assert sum(p.stat().st_size for p in files.values()) < 16 * (1 << 20)
destination = O / 'nullable-layout-diagnostic-packet-657'
destination.mkdir()
archive = destination / 'native-nullable-layout-test-diagnostics-2026-10-18.tar.xz'
manifest = []
with tarfile.open(archive, 'x:xz') as bundle:
    for name, path in sorted(files.items()):
        before = identity(path)
        raw = path.read_bytes()
        member = tarfile.TarInfo(name)
        member.size, member.mode = len(raw), 0o644
        bundle.addfile(member, io.BytesIO(raw))
        assert identity(path) == before
        manifest.append(dict(name=name, **before))
with tarfile.open(archive, 'r:xz') as bundle:
    assert len(bundle.getmembers()) == len(manifest)
    for item in manifest:
        raw = bundle.extractfile(item['name']).read()
        assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
        assert raw == files[item['name']].read_bytes()
report = dict(schema_version='shardloom.nullable_layout_test_diagnostic_bridge.v1', status='passed',
    original_head='807c10ac423e0e7978158242e0e515629dfae80c', source_files=2416,
    accepted_runtime_unchanged=True, changed_files=bridge['changes'], bridge=identity(bridge_path),
    source=identity(frozen), validation_receipt=identity(O / 'nullable-layout-diagnostic-gates-657-a4.json'),
    workspace_tests=3225, layout_tests=249, file_tests=140, ignored_tests=0, gates=9,
    original_codeql_instances=4, static_triage='not_actionable', hosted_reanalysis_pending=True,
    runtime_scope=bridge['runtime_scope'], archive=dict(file=archive.name, bytes=archive.stat().st_size, sha256=sha(archive)),
    all_members_reopened=True, members=manifest, member_count=len(manifest))
save(destination / 'native-nullable-layout-test-diagnostics-2026-10-18.json', report)
print(json.dumps(dict(status='passed', members=len(manifest), archive_bytes=archive.stat().st_size,
                     workspace_tests=3225, provider_tests=389)))
