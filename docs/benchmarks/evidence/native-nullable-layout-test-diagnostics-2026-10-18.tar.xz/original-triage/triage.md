# Nullable-layout CodeQL triage

All four supplied CodeQL alerts (254, 253, 252, 251) are not actionable as sensitive-data exposures, with high static confidence. Their exact sinks are assertion macros in cfg(test) fixtures fed exclusively by literal synthetic arrays. The macro can print values on failure, but no supported lower-trust input or sensitive source reaches these test call sites. The current PR and analyzed merge have identical trees. Root SECURITY.md applies to both paths.

This is a static assessment of those four instances, not a runtime or exhaustive assertion-library security audit. No alert is dismissed or otherwise changed in GitHub. A separate CI cleanup will keep the equality checks while replacing value-printing assertion diagnostics; hosted analysis must verify that result.
