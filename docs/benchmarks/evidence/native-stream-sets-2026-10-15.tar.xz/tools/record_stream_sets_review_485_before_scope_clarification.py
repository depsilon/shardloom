"""Preserve primary source review separately from the unfinished acceptance gates."""
import datetime as dt
import json
from pathlib import Path

from freeze_native_release_298 import ROOT, OUT, sha, sources, save


def main():
    source = OUT / 'native-release-source-streamsets484.json'
    frozen = json.loads(source.read_text())['source_sha256']
    assert sources() == frozen
    paths = [
        'shardloom-vortex/src/local_primitive_relational_batch_input.rs',
        'shardloom-vortex/src/local_primitive_relational_batch_input_tests.rs',
        'shardloom-vortex/src/local_primitive_relational_batch_dynamic_tests.rs',
        'shardloom-vortex/src/local_primitive_relational_batch_set_tests.rs',
        'shardloom-vortex/src/local_primitive_relational_batch_set_pressure_tests.rs',
        'shardloom-vortex/src/local_primitive_relational_batch_set_fault_tests.rs',
        'python/tests/test_native_set_binding.py',
        'scripts/native_streaming_set_cases.py',
        'scripts/native_streaming_set_composition_cases.py',
        'scripts/native_streaming_set_boundary_cases.py',
        'scripts/native_streaming_set_pressure_cases.py',
    ]
    findings = [
        dict(concern='Set branches can hide repeated producers or unsupported descendants.',
             resolution='count_sources traverses both branches with the existing depth increment, propagates each error, and saturates the sum at two. The native tests cover forbidden Outer on both sides, depth, repeated sources and fresh executions.',
             outcome='no_remaining_source_finding'),
        dict(concern='Empty output or a zero limit can hide a late source failure or publish a partial result.',
             resolution='The existing complete-input owner remains unchanged. Tests require both end events and cover zero limits, producer/schema failures on each branch, cancellation, provisional output and writer cleanup.',
             outcome='no_remaining_source_finding'),
        dict(concern='Replay spill could be misreported as an implemented set-membership spill strategy.',
             resolution='Membership remains in the existing credited RowSet/RowIndex/Table owners. Tests require high-cardinality denial with and without spill permission; source replay has separate complete-value and run/cleanup assertions.',
             outcome='no_remaining_source_finding'),
        dict(concern='Retained output might keep a producer alive or lose its memory credits at plan teardown.',
             resolution='Native release witnesses are checked before every source demand and after failure. Held output survives prepared-plan teardown and retains credits until final release; direct-binding tests also retain typed output after client close.',
             outcome='no_remaining_source_finding'),
        dict(concern='A stale negative test could incorrectly treat newly admitted behavior as a regression.',
             resolution='The failed original dynamic fixture is preserved. Its blanket UNION ALL refusal is replaced with forbidden correlated input on each branch, retaining unary and initial-cancellation checks. The corrected focused test and its entry in the active broad log pass.',
             outcome='fixed_test_fixture_without_runtime_change'),
    ]
    save(OUT / 'stream-sets-primary-review-485.json', dict(
        status='source_review_complete_acceptance_pending', observed_at=dt.datetime.now(dt.timezone.utc).isoformat(),
        source_manifest=dict(path=str(source), sha256=sha(source)),
        reviewed_sources={name: frozen[name] for name in paths}, helper=dict(path=__file__, sha256=sha(__file__)),
        findings=findings, unresolved_source_findings=[],
        required_remaining_gates=['complete_native_suite', 'release_builds', 'direct_binding_87',
                                  'focused_public', 'complete_public_1121', 'Full43',
                                  'portable_evidence', 'final_documentation_and_validators', 'hosted_integration'],
        automated_independent_review_claimed=False, native_runtime_changed=False,
        limitations='Primary manual source review does not substitute for pending runtime and hosted acceptance.'))
    print(json.dumps(dict(status='source_review_complete_acceptance_pending', reviewed_sources=len(paths))))


if __name__ == '__main__':
    main()
