"""Freeze the complete expected set breadth matrix before public execution."""
import json
from freeze_native_release_298 import OUT, ROOT, sha, save, sources

KINDS = ('union_all', 'union', 'intersect', 'except_')
FORMATS = ('vortex', 'parquet', 'arrow_ipc', 'avro', 'orc', 'json', 'jsonl', 'csv')


def set_names():
    names = []
    for kind in KINDS:
        for surface in ('dataframe', 'sql'):
            for terminal in ('collect', 'batches'):
                for left, right in ((1, 1), (1, 0), (0, 1), (0, 0)):
                    names.append(f'set-{kind}-{surface}-{terminal}-stream-{left}{right}')
                names.append(f'set-{kind}-{surface}-{terminal}-repeated')
        for shape in ('empty-left', 'empty-right', 'empty-both', 'all-null'):
            for terminal in ('collect', 'batches'):
                names.append(f'set-{kind}-{shape}-{terminal}')
    for kind in KINDS:
        for side in (False, True):
            names.append(f'set-{kind}-native-file-stream-right-{side}')
    for kind in KINDS:
        for output in (*FORMATS, 'fanout'):
            names.append(f'set-{kind}-write-{output}')
    names.extend('set-empty-write-' + output for output in FORMATS)
    assert len(names) == 164
    for stored in (False, True):
        for kind in KINDS:
            for shape in ('filter-project', 'sort', 'limit-zero', 'limit-two', 'group', 'join', 'window', 'nested'):
                names.append(f'set-composed-{kind}-{shape}-spill-{stored}')
            names.append(f'set-dynamic-{kind}-spill-{stored}')
    for kind in KINDS:
        for output in ('collect', 'batches', 'vortex'):
            names.append(f'set-rich-{kind}-{output}')
    for kind in KINDS:
        for side in (0, 1):
            for output in ('zero', 'collect', 'write'):
                names.append(f'set-late-{kind}-side-{side}-{output}')
    for kind in KINDS:
        for surface in ('dataframe', 'sql'):
            for terminal in ('collect', 'batches'):
                names.append(f'set-positional-{kind}-{surface}-{terminal}')
    for kind in KINDS:
        for stored in (False, True):
            names.append(f'set-before-pivot-{kind}-spill-{stored}')
    for kind in KINDS:
        names.append('set-early-close-' + kind)
        for side in (0, 1):
            for terminal in ('collect', 'zero', 'write'):
                names.append(f'set-schema-failure-{kind}-side-{side}-{terminal}')
    assert len(names) == len(set(names)) == 324
    return names


def pressure_names():
    names = ['set-duplicate-pressure-' + kind for kind in KINDS]
    names += [f'set-membership-pressure-denied-{kind}-spill-{stored}'
              for kind in KINDS[1:] for stored in (False, True)]
    names += ['set-replay-resident-denied', 'set-replay-spilled-batches', 'set-replay-spilled-vortex']
    names += [f'set-replay-{failure}-write-{write}'
              for failure in ('producer', 'corrupt', 'quota') for write in (False, True)]
    assert len(names) == len(set(names)) == 19
    return names


def main():
    prior_path = OUT / 'stream-destination-runtime-protocol-477.json'
    prior = json.loads(prior_path.read_text())
    assert len(prior['expected_public_names']) == 777 and len(prior['expected_public_families']) == 20
    replacements = {
        'deny-union': ['deny-unary-left-set'],
        'deny-repeated-window': ['deny-unary-right-set'],
        'window-deny-repeated-source': ['window-repeated-source-spill-False', 'window-repeated-source-spill-True'],
    }
    assert all(prior['expected_public_names'].count(name) == 1 for name in replacements)
    names = [new for name in prior['expected_public_names'] for new in replacements.get(name, [name])]
    normal, pressure = set_names(), pressure_names()
    names += normal + pressure
    assert len(names) == len(set(names)) == 1121
    frozen = OUT / 'native-release-source-streamsets482.json'
    assert sources() == json.loads(frozen.read_text())['source_sha256']
    save(OUT / 'stream-sets-case-protocol-483b.json', dict(
        expected_public_names=names,
        expected_public_families=prior['expected_public_families'] + ['sets', 'sets-pressure'],
        expected_set_names=normal, expected_set_pressure_names=pressure,
        preserved_prior_names=774, replaced_prior_denials=replacements,
        expected_cases=1121, expected_direct_tests=87,
        prior_protocol=dict(path=str(prior_path), sha256=sha(prior_path)),
        source_manifest=dict(path=str(frozen), sha256=sha(frozen)),
        helper=dict(path=__file__, sha256=sha(__file__)),
        purpose='Complete capability regression with full values; no timing or performance comparison.',
        native_membership_spill=False, publication_attempted=False,
        pre_execution_order_correction='The draft 483 protocol listed CSV before JSON/JSONL; 483b matches existing LOCAL_FORMATS order. No case or expectation changes and no public execution preceded this correction.',
        superseded_protocol=dict(path=str(OUT / 'stream-sets-case-protocol-483.json'),
                                 sha256=sha(OUT / 'stream-sets-case-protocol-483.json'))))
    print(json.dumps(dict(status='prepared', cases=len(names), sets=len(normal), pressure=len(pressure))))


if __name__ == '__main__':
    main()
