"""Reuse immutable native builds after one verified, test-only fixture correction."""
import json
from pathlib import Path
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sha, sources, save
from run_stream_sets_runtime_484 import identity, SOURCE, MANIFEST, DIRECT, CHECKS

ACCEPTED_SOURCE = OUT / 'stream-sets-acceptance-source-487.json'
FIXTURE = 'scripts/native_streaming_set_composition_cases.py'
ORIGINAL = OUT / 'stream-sets-public-focused-484/logs/native_streaming_set_composition_cases.py'
CORRECTED = OUT / 'stream-sets-field-order-corrected-fixture-487.py'
DIAGNOSIS = OUT / 'stream-sets-field-order-diagnosis-487b.json'


def receipt(path):
    path = Path(path)
    record = json.loads(path.read_text())
    assert record['status'] == 'passed' and record['returncode'] == 0
    assert record['process_group_drained'] and record['direct_child_reaped']
    assert not record['timed_out'] and not record['group_absence_unproved_at_cleanup']
    assert sha(path.with_suffix('.log')) == record['log_sha256']
    return record


def load():
    accepted = json.loads(ACCEPTED_SOURCE.read_text())
    build = json.loads(MANIFEST.read_text())
    original = json.loads(SOURCE.read_text())
    assert build['status'] == 'passed' and build['build_profile'] == 'release'
    assert build['source_sha256'] == original['source_sha256']
    assert accepted['source_sha256'] == sources()
    assert set(accepted['source_sha256']) == set(original['source_sha256'])
    changed = [name for name, digest in original['source_sha256'].items()
               if accepted['source_sha256'][name] != digest]
    assert changed == [FIXTURE]
    assert sha(ORIGINAL) == original['source_sha256'][FIXTURE]
    assert sha(CORRECTED) == accepted['source_sha256'][FIXTURE]
    before = '    python_expected = rich_python_values()\n'
    after = ('    python_expected = [{name: row[name] for name, _ in fields}\n'
             '                       for row in rich_python_values()]\n')
    assert ORIGINAL.read_text().count(before) == 1
    assert ORIGINAL.read_text().replace(before, after) == CORRECTED.read_text()
    assert accepted['head'] == build['head'] == original['head']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == accepted['head']
    for name, path in (('build_source', SOURCE), ('build_artifacts', MANIFEST), ('direct_tests', DIRECT),
                       ('native_and_workspace_checks', CHECKS), ('original_fixture', ORIGINAL),
                       ('corrected_fixture', CORRECTED), ('diagnosis', DIAGNOSIS)):
        assert accepted[name] == identity(path)
    checks = json.loads(CHECKS.read_text())
    assert checks['status'] == 'passed' and len(checks['completed']) == 6
    assert checks['source_identity_preserved'] and checks['protocol']['source_manifest_sha256'] == sha(SOURCE)
    direct = json.loads(DIRECT.read_text())
    assert direct['status'] == 'passed' and direct['tests'] == 87
    assert direct['failures'] == direct['errors'] == direct['skipped'] == 0
    assert direct['artifact_manifest'] == identity(MANIFEST)
    receipt(OUT / 'stream-sets-direct-484.json')
    for kind in ('cli', 'binding'):
        artifact = build[kind]
        assert identity(artifact['path']) == {key: artifact[key] for key in ('path', 'bytes', 'sha256')}
        assert sha(artifact['build_receipt']) == artifact['build_receipt_sha256']
        record = receipt(artifact['build_receipt'])
        assert record['head'] == build['head'] and '--release' in record['command']
        assert sha(artifact['build_log']) == record['log_sha256']
    return build


def prepare():
    assert not ACCEPTED_SOURCE.exists() and not CORRECTED.exists()
    current = sources()
    original = json.loads(SOURCE.read_text())
    assert set(current) == set(original['source_sha256'])
    assert [name for name in current if current[name] != original['source_sha256'][name]] == [FIXTURE]
    diagnosis = json.loads(DIAGNOSIS.read_text())
    assert diagnosis['status'] == 'passed' and diagnosis['unchanged_assertion_reproduced']
    assert diagnosis['recursive_object_types_values_and_nested_order_pass_after_top_level_normalization']
    receipt(OUT / 'stream-sets-field-order-reproduction-487b.json')
    with CORRECTED.open('xb') as target:
        target.write((ROOT / FIXTURE).read_bytes())
    save(ACCEPTED_SOURCE, dict(status='accepted_test_fixture_only_transition', head=original['head'],
        source_sha256=current, build_source=identity(SOURCE), build_artifacts=identity(MANIFEST),
        direct_tests=identity(DIRECT), native_and_workspace_checks=identity(CHECKS),
        original_fixture=identity(ORIGINAL), corrected_fixture=identity(CORRECTED),
        diagnosis=identity(DIAGNOSIS), helper=identity(__file__), changed_paths=[FIXTURE],
        rationale='Order expected Python row fields by the declared result schema; retain strict recursive type, value and order assertions.',
        compiled_runtime_changed=False, public_python_runtime_changed=False,
        native_builds_reused=True, prior_gate_results_apply_to_original_build_sources=True,
        corrected_public_fixture_will_be_executed=True))
    load()
    print(json.dumps(dict(status='passed', changed_paths=[FIXTURE], native_builds_reused=True)))


if __name__ == '__main__':
    prepare() if sys.argv[1:] == ['prepare'] else load()
