"""Verify each delegated literal against frozen copies before primary use."""
import hashlib
import json
from pathlib import Path

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
REPORT = OUT / 'stream-sets-doc-surface-inventory-485.json'
SNAPSHOTS = OUT / 'stream-sets-doc-surface-sources-485'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    report = json.loads(REPORT.read_text())
    expected = report['scope']['target_files']
    assert len(expected) == len(set(expected)) == 5
    inventory = {row['path']: row for row in report['file_inventory']}
    assert sorted(inventory) == sorted(expected)
    context = report['scope']['contract_context_file']
    inventory[context['path']] = context
    assert not SNAPSHOTS.exists()
    SNAPSHOTS.mkdir()
    content = {}
    for name, row in inventory.items():
        data = (ROOT / name).read_bytes()
        assert digest(data) == row['sha256'] == row['expected_sha256'], name
        target = SNAPSHOTS / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        assert target.read_bytes() == data
        content[name] = data.decode().splitlines()
    findings = report['findings']
    assert len(findings) == report['coverage']['findings_count'] == 21
    for row in findings:
        start, end = row['line_range_one_based']
        assert start > 0 and end >= start
        assert '\n'.join(content[row['path']][start-1:end]) == row['quoted_excerpt'], row['topic']
    patterns = report['scope']['validator_test_search']['literal_patterns']
    actual = sorted(str(path.relative_to(ROOT)) for path in (ROOT / 'python/tests').rglob('*.py')
                    if any(pattern in path.read_text() for pattern in patterns))
    assert actual == report['scope']['validator_test_search']['matching_test_files'] == []
    result = dict(status='passed', helper=str(Path(__file__)), helper_sha256=digest(Path(__file__).read_bytes()),
        inventory=str(REPORT), inventory_sha256=digest(REPORT.read_bytes()),
        target_files=expected, frozen_source_root=str(SNAPSHOTS),
        all_six_source_hashes_verified=True, complete_literal_excerpts=21,
        python_direct_validator_references=actual,
        acceptance_scope='literal evidence only; primary owns changes and runtime acceptance')
    target = OUT / 'stream-sets-doc-surface-acceptance-485.json'
    with target.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
