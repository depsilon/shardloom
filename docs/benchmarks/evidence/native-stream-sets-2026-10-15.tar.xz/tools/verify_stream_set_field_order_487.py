"""Isolate the rich-value assertion using the unchanged accepted native binary."""
import json
from pathlib import Path
import sys

from freeze_native_release_298 import ROOT, OUT, save, sha
from run_stream_sets_runtime_484 import load, identity, MANIFEST, SOURCE

sys.path.insert(0, str(ROOT / 'python/src'))
sys.path.insert(0, str(ROOT / 'scripts'))
from run_native_streaming_input_uat import Harness
from native_streaming_dynamic_cases import frame
from native_streaming_set_cases import POLICY, combine, oracle, complete
from native_typed_input_cases import assert_python_values
from native_typed_input_fixtures import rich_fixture, rich_python_values


def main():
    build = load()
    root = OUT / 'stream-sets-field-order-reproduction-487'
    assert not root.exists()
    harness = Harness(Path(build['cli']['path']), root, 600)
    harness.guard()
    harness.logs.mkdir(parents=True)
    harness.output.mkdir()
    schema, fields, rows, values = rich_fixture()
    expected = rich_python_values()
    left_indices, right_indices = [0, 3, 0, 2], [3, 2, 1, 1]
    source = ROOT / 'scripts/native_streaming_set_composition_cases.py'
    prior = OUT / 'stream-sets-public-focused-484/logs/native_streaming_set_composition_cases.py'
    assert sha(source) == sha(prior)
    try:
        left, a = frame(harness, [rows[i] for i in left_indices], schema=schema)
        right, b = frame(harness, [rows[i] for i in right_indices], schema=schema)
        result = combine(left, right, 'union_all').collect(check=True, **POLICY)
        actual = result.python_objects
        wanted = oracle([expected[i] for i in left_indices], [expected[i] for i in right_indices], 'union_all')
        assert result.result_schema == fields
        harness.values('rich-union-all', result.result_rows,
            oracle([values[i] for i in left_indices], [values[i] for i in right_indices], 'union_all'))
        assert actual == wanted
        assert all(tuple(row) == tuple(schema) for row in actual)
        assert any(tuple(row) != tuple(schema) for row in wanted)
        try:
            assert_python_values(actual, wanted)
        except AssertionError:
            pass
        else:
            raise AssertionError('The unchanged expected-object assertion did not reproduce')
        normalized = [{name: row[name] for name, _ in fields} for row in wanted]
        assert_python_values(actual, normalized)
        complete(harness, 'rich-union-all', result.envelope, [a, b], [True, True])
        assert load() == build
        report = dict(status='passed', diagnosis='expected_top_level_field_order_differs_from_declared_schema',
            unchanged_assertion_reproduced=True, all_values_equal=True, exact_schema_equal=True,
            recursive_object_types_values_and_nested_order_pass_after_top_level_normalization=True,
            actual_orders=[list(row) for row in actual], original_expected_orders=[list(row) for row in wanted],
            declared_order=[name for name, _ in fields], artifacts=identity(MANIFEST), source=identity(SOURCE),
            original_fixture=identity(source), retained_original_fixture=identity(prior),
            helper=identity(__file__), original_failed_summary=identity(OUT / 'stream-sets-public-focused-484/summary.json'),
            runtime_sources_changed=False, native_binary_rebuilt=False)
        destination = OUT / 'stream-sets-field-order-diagnosis-487.json'
        assert not destination.exists()
        save(destination, report)
        print(json.dumps(dict(status=report['status'], diagnosis=report['diagnosis'], complete_rows=len(actual))))
    finally:
        harness.client.close()


if __name__ == '__main__':
    main()
