"""Sequence the already reviewed set runtime, public and Full43 checks."""
import json
from pathlib import Path
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, save, sha, sources


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def main():
    checks = OUT / 'stream-sets-checks-484.json'
    value = json.loads(checks.read_text())
    assert value['status'] == 'passed' and len(value['completed']) == 6
    assert value['source_identity_preserved']
    source = OUT / 'native-release-source-streamsets484.json'
    frozen = json.loads(source.read_text())['source_sha256']
    assert sources() == frozen
    stages = [
        ('runtime', 'run_stream_sets_runtime_484.py'),
        ('public', 'run_stream_sets_public_484.py'),
        ('public-inspection', 'verify_stream_sets_public_484.py'),
        ('full43', 'run_stream_sets_full43_484.py'),
    ]
    protocol = OUT / 'stream-sets-acceptance-protocol-486.json'
    result = OUT / 'stream-sets-acceptance-486.json'
    assert not protocol.exists() and not result.exists()
    inputs = [identity(OUT / helper) for _, helper in stages]
    save(protocol, dict(status='admitted', checks=identity(checks), source=identity(source),
        helper=identity(__file__), stages=stages, inputs=inputs,
        execution='sequential; stop at first failure; no automatic retry',
        publication_attempted=False))
    completed, failure = [], None
    try:
        for label, helper in stages:
            assert sources() == frozen
            assert identity(OUT / helper) == next(item for item in inputs if item['path'] == str(OUT / helper))
            print(json.dumps(dict(acceptance_stage=label, status='starting')), flush=True)
            subprocess.run([sys.executable, '-B', str(OUT / helper)], cwd=ROOT, check=True)
            assert sources() == frozen
            completed.append(label)
            print(json.dumps(dict(acceptance_stage=label, status='passed')), flush=True)
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        save(result, dict(status='passed' if failure is None else 'failed',
            completed=completed, failure=failure, protocol=identity(protocol),
            source_identity_preserved=sources() == frozen,
            installed_wheel_proof=False, hosted_proof=False, publication_attempted=False))


if __name__ == '__main__':
    main()
