"""Run the corrected fixture and focused set cases against unchanged native builds."""
import json
import sys

from freeze_native_release_298 import ROOT, OUT, save
from run_query_timing_runtime_461 import guarded
from stream_set_acceptance_sources_487 import (load, identity, MANIFEST, SOURCE,
    ACCEPTED_SOURCE, DIRECT, receipt)

FOCUSED = OUT / 'stream-sets-public-focused-487'


def main():
    build = load()
    protocol = OUT / 'stream-sets-focused-protocol-487.json'
    result = OUT / 'stream-sets-runtime-focused-487.json'
    assert not FOCUSED.exists() and not result.exists() and not protocol.exists()
    families = ['sets', 'sets-pressure', 'input', 'window']
    case_protocol = OUT / 'stream-sets-case-protocol-484.json'
    declared = json.loads(case_protocol.read_text())
    inputs = [identity(path) for path in (MANIFEST, SOURCE, ACCEPTED_SOURCE, DIRECT,
        case_protocol, OUT / 'stream_set_acceptance_sources_487.py',
        OUT / 'run_guarded.py', OUT / 'run_query_timing_runtime_461.py', __file__)]
    save(protocol, dict(status='admitted', families=families, inputs=inputs,
        original_failed_run=identity(OUT / 'stream-sets-public-focused-484/summary.json'),
        automatic_retry=False, source_transition=identity(ACCEPTED_SOURCE)))
    guarded('stream-sets-public-focused-487', 5400,
        [sys.executable, '-B', ROOT / 'scripts/run_native_streaming_input_uat.py',
         '--binary', build['cli']['path'], '--uat-root', FOCUSED, '--operation-timeout', '600',
         '--families', *families])
    receipt(OUT / 'stream-sets-public-focused-487.json')
    summary = json.loads((FOCUSED / 'summary.json').read_text())
    assert summary['status'] == 'passed' and summary['families'] == families
    assert all(case['status'] == 'passed' for case in summary['cases'])
    names = [case['name'] for case in summary['cases']]
    assert len(names) == len(set(names))
    assert set(declared['expected_set_names'] + declared['expected_set_pressure_names']).issubset(names)
    assert set(names).issubset(declared['expected_public_names'])
    assert load() == build
    for item in inputs:
        assert identity(item['path']) == item
    save(result, dict(status='passed', source=identity(SOURCE), artifacts=identity(MANIFEST),
        accepted_source=identity(ACCEPTED_SOURCE), direct=identity(DIRECT),
        focused_public=identity(FOCUSED / 'summary.json'), public_cases=len(names),
        protocol=identity(protocol), source_identity_preserved=True,
        original_build_source_retained=True, test_fixture_only_transition=True,
        broad_public_pending=True, full43_pending=True))
    print(json.dumps(dict(status='passed', focused_cases=len(names), families=len(families))), flush=True)


if __name__ == '__main__':
    main()
