"""Freeze the existing set-operation streaming refusal and resident controls."""
import json

from freeze_native_release_298 import ROOT, OUT, sha, save, sources
from run_native_streaming_input_uat import Harness
from shardloom.errors import ShardLoomCommandError

DEST = OUT / 'stream-set-baseline-480'
LEFT = [{'n': 3, 's': '港'}, {'n': None, 's': None}, {'n': 3, 's': '港'},
        {'n': 2, 's': 'β'}, {'n': 1, 's': ''}]
RIGHT = [{'n': None, 's': None}, {'n': 2, 's': 'β'}, {'n': 9, 's': ' '}, {'n': 9, 's': ' '}]
KINDS = ('union_all', 'union', 'intersect', 'except_')


def reference(left, right, kind):
    if kind == 'union_all':
        return left + right
    chosen = left + right if kind == 'union' else [r for r in left if (r in right) == (kind == 'intersect')]
    unique = []
    for row in chosen:
        if row not in unique:
            unique.append(row)
    return unique


def main():
    accepted = json.loads((OUT / 'native-release-source-streamreview479accepted.json').read_text())['source_sha256']
    assert sources() == accepted
    artifacts = json.loads((OUT / 'stream-destination-native-artifacts-477.json').read_text())
    from pathlib import Path
    binary = Path(artifacts['cli']['path'])
    assert sha(binary) == artifacts['cli']['sha256']
    harness = Harness(binary, DEST, 30)
    harness.guard()
    harness.logs.mkdir(parents=True)
    harness.output.mkdir()
    status = 'failed'
    try:
        for streaming, repeated in ((True, False), (True, True), (False, False)):
            for kind in KINDS:
                name = f'set-baseline-{kind}-streaming-{streaming}-repeated-{repeated}'
                def case(name=name, streaming=streaming, repeated=repeated, kind=kind):
                    events = []
                    def frame(rows, side):
                        def producer():
                            events.append(side + '-opened')
                            try:
                                yield rows[:2]
                                yield []
                                yield rows[2:]
                                events.append(side + '-ended')
                            finally:
                                events.append(side + '-closed')
                        return harness.context.from_batches(producer, schema={'n': 'int64', 's': 'utf8'}, streaming=streaming)
                    left = frame(LEFT, 'left')
                    right = left if repeated else frame(RIGHT, 'right')
                    query = getattr(left, kind)(right)
                    try:
                        result = query.collect(check=True, memory_bytes=32 << 20, max_parallelism=1)
                    except ShardLoomCommandError as error:
                        assert streaming, error.envelope.raw
                        harness.envelope(name, error.envelope, success=False)
                        assert 'set operation/repeated source' in json.dumps(error.envelope.raw)
                        assert events == [], events
                        return dict(outcome='static_streaming_refusal', producer_events=events)
                    else:
                        assert not streaming
                        harness.envelope(name, result.envelope)
                        harness.values(name, result.result_rows, reference(LEFT, RIGHT, kind))
                        assert sorted(events) == sorted(side + '-' + event for side in ('left', 'right') for event in ('opened', 'ended', 'closed'))
                        return dict(outcome='resident_control_passed', producer_events=events)
                harness.case(name, case)
        assert len(harness.results) == 12 and all(r['status'] == 'passed' for r in harness.results)
        assert sources() == accepted and sha(binary) == artifacts['cli']['sha256']
        status = 'passed'
    finally:
        harness.client.close()
        save(DEST / 'summary.json', dict(status=status, cases=harness.results,
            left=LEFT, right=RIGHT, kinds=KINDS, binary=artifacts['cli'],
            original_artifact_manifest='stream-destination-native-artifacts-477.json',
            current_source_manifest='native-release-source-streamreview479accepted.json',
            helper_sha256=sha(__file__), runtime_source_changed=False, performance_claim=False))
    print(json.dumps(dict(status=status, cases=12, streaming_refusals=8, resident_controls=4)))


if __name__ == '__main__':
    main()
