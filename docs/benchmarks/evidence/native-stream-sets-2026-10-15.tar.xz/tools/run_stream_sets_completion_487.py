"""Complete public and Full43 acceptance after the verified fixture correction."""
import json
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, save
from stream_set_acceptance_sources_487 import load, identity, ACCEPTED_SOURCE


def main():
    build = load()
    focused = OUT / 'stream-sets-runtime-focused-487.json'
    assert json.loads(focused.read_text())['status'] == 'passed'
    stages = [
        ('public', 'run_stream_sets_public_487.py'),
        ('public-inspection', 'verify_stream_sets_public_487.py'),
        ('full43', 'run_stream_sets_full43_487.py'),
    ]
    protocol = OUT / 'stream-sets-acceptance-protocol-487.json'
    result = OUT / 'stream-sets-acceptance-487.json'
    assert not protocol.exists() and not result.exists()
    inputs = [identity(OUT / helper) for _, helper in stages]
    inputs += [identity(ACCEPTED_SOURCE), identity(OUT / 'stream_set_acceptance_sources_487.py')]
    save(protocol, dict(status='admitted', source_transition=identity(ACCEPTED_SOURCE),
        focused=identity(focused), helper=identity(__file__), stages=stages, inputs=inputs,
        execution='sequential; stop at first failure; no automatic retry',
        publication_attempted=False))
    completed, failure = [], None
    try:
        for label, helper in stages:
            assert load() == build
            for item in inputs:
                assert identity(item['path']) == item
            print(json.dumps(dict(acceptance_stage=label, status='starting')), flush=True)
            subprocess.run([sys.executable, '-B', str(OUT / helper)], cwd=ROOT, check=True)
            assert load() == build
            completed.append(label)
            print(json.dumps(dict(acceptance_stage=label, status='passed')), flush=True)
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        save(result, dict(status='passed' if failure is None else 'failed',
            completed=completed, failure=failure, protocol=identity(protocol),
            source_transition=identity(ACCEPTED_SOURCE),
            installed_wheel_proof=False, hosted_proof=False, publication_attempted=False))


if __name__ == '__main__':
    main()
