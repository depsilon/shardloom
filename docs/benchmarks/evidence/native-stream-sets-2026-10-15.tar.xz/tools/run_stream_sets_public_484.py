"""Run the complete predeclared public matrix after focused set acceptance."""
import json
from pathlib import Path
import sys

from freeze_native_release_298 import ROOT, OUT, sha, sources, save
from run_query_timing_runtime_461 import guarded
from run_stream_sets_runtime_484 import load, identity, MANIFEST, SOURCE, DIRECT

PROTOCOL = OUT / 'stream-sets-case-protocol-484.json'
FOCUSED = OUT / 'stream-sets-runtime-focused-484.json'
PUBLIC = OUT / 'stream-sets-public-484'
RUNTIME = OUT / 'stream-sets-runtime-484.json'


def receipt(name):
    path = OUT / (name + '.json')
    value = json.loads(path.read_text())
    assert value['status'] == 'passed' and value['returncode'] == 0
    assert value['process_group_drained'] and value['direct_child_reaped']
    assert not value['timed_out'] and not value['group_absence_unproved_at_cleanup']
    assert sha(path.with_suffix('.log')) == value['log_sha256']
    return identity(path)


def main():
    manifest = load()
    protocol = json.loads(PROTOCOL.read_text())
    focused = json.loads(FOCUSED.read_text())
    assert focused['status'] == 'passed' and focused['source_identity_preserved']
    assert focused['artifacts'] == identity(MANIFEST)
    assert focused['source'] == identity(SOURCE)
    assert protocol['source_manifest']['sha256'] == sha(SOURCE)
    assert protocol['expected_cases'] == 1121 and protocol['expected_direct_tests'] == 87
    direct = json.loads(DIRECT.read_text())
    assert focused['direct'] == identity(DIRECT)
    assert direct['status'] == 'passed' and direct['tests'] == 87
    assert direct['failures'] == direct['errors'] == direct['skipped'] == 0
    assert direct['artifact_manifest'] == identity(MANIFEST)
    focused_path = Path(focused['focused_public']['path'])
    assert focused['focused_public'] == identity(focused_path)
    focused_summary = json.loads(focused_path.read_text())
    assert focused_summary['status'] == 'passed'
    assert all(case['status'] == 'passed' for case in focused_summary['cases'])
    focused_names = [case['name'] for case in focused_summary['cases']]
    assert len(focused_names) == len(set(focused_names))
    assert set(protocol['expected_set_names'] + protocol['expected_set_pressure_names']).issubset(focused_names)
    assert set(focused_names).issubset(protocol['expected_public_names'])
    before = [identity(path) for path in (PROTOCOL, FOCUSED, MANIFEST, SOURCE, DIRECT, focused_path, Path(__file__))]
    assert not PUBLIC.exists() and not RUNTIME.exists()
    run_protocol = dict(status='admitted', identities=before,
        focused_receipt=receipt('stream-sets-public-focused-484'),
        direct_receipt=receipt('stream-sets-direct-484'),
        expected_names=protocol['expected_public_names'],
        expected_families=protocol['expected_public_families'],
        cases=1121, direct_methods=87, guard=identity(OUT / 'run_guarded.py'),
        operation_timeout_seconds=600, supervisor_timeout_seconds=7200,
        native_membership_spill=False, full43_pending=True, publication_attempted=False)
    save(OUT / 'stream-sets-public-protocol-484.json', run_protocol)
    failure = None
    completed_receipt = None
    try:
        guarded('stream-sets-public-484', 7200,
            [sys.executable, '-B', ROOT / 'scripts/run_native_streaming_input_uat.py',
             '--binary', manifest['cli']['path'], '--uat-root', PUBLIC,
             '--operation-timeout', '600'])
        completed_receipt = receipt('stream-sets-public-484')
        summary = json.loads((PUBLIC / 'summary.json').read_text())
        assert summary['status'] == 'passed'
        assert all(case['status'] == 'passed' for case in summary['cases'])
        names = [case['name'] for case in summary['cases']]
        assert len(names) == len(set(names)) == 1121
        assert names == protocol['expected_public_names']
        assert summary['families'] == protocol['expected_public_families']
        assert len(summary['families']) == 22
        assert load() == manifest
        for value in before:
            assert identity(value['path']) == value
        save(RUNTIME, dict(status='passed', manifest=str(MANIFEST), manifest_sha256=sha(MANIFEST),
            source=identity(SOURCE), focused=identity(FOCUSED), direct_summary=str(DIRECT),
            direct_summary_sha256=sha(DIRECT), public_summary=str(PUBLIC / 'summary.json'),
            public_summary_sha256=sha(PUBLIC / 'summary.json'), public_cases=len(names),
            public_families=summary['families'], public_receipt=completed_receipt,
            case_protocol=identity(PROTOCOL), protocol=identity(OUT / 'stream-sets-public-protocol-484.json'),
            sources_unchanged=True, full43_pending=True, publication_attempted=False))
        print(json.dumps(dict(status='passed', cases=len(names), families=len(summary['families']))), flush=True)
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        save(OUT / 'stream-sets-public-attempt-484.json', dict(
            status='passed' if failure is None else 'failed', failure=failure,
            protocol=identity(OUT / 'stream-sets-public-protocol-484.json'),
            receipt=completed_receipt,
            selected_sources_unchanged=sources() == manifest['source_sha256']))


if __name__ == '__main__':
    main()
