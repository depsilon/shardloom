"""Package complete streaming-set acceptance only after all declared gates pass."""
import hashlib
import json
import lzma
from pathlib import Path
import re
import subprocess
import sys
import tarfile

from freeze_native_release_298 import ROOT, OUT, sha, sources, save
from stream_set_acceptance_sources_487 import load, ACCEPTED_SOURCE, CORRECTED, DIAGNOSIS
from package_selection_acceptance_409 import Members, verify, sha_stream
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

PREFIX = 'native-stream-sets-2026-10-15'
LOCAL = OUT / 'stream-sets-packet-487'
DEST = ROOT / 'docs/benchmarks/evidence'
SOURCE = OUT / 'native-release-source-streamsets484.json'
ARTIFACTS = OUT / 'native-release-artifacts-streamsets484.json'
UAT = Path('/Users/dylan/LocalData/shardloom/clickbench-100m-uat')


def bound(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def read(name):
    return json.loads((OUT / name).read_text())


def completed(name):
    path = OUT / (name + '.json')
    receipt = json.loads(path.read_text())
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup']
    assert sha(path.with_suffix('.log')) == receipt['log_sha256']
    return receipt


def main():
    frozen = read(SOURCE.name)
    accepted = read(ACCEPTED_SOURCE.name)['source_sha256']
    assert sources() == accepted and len(accepted) == 2272
    artifacts = load()
    checks = read('stream-sets-checks-484.json')
    focused = read('stream-sets-runtime-focused-487.json')
    runtime = read('stream-sets-runtime-487.json')
    direct = read('stream-sets-direct-tests-484.json')
    public = read('stream-sets-public-inspection-487.json')
    full = read('stream-sets-full43-review-487.json')
    protocol = read('stream-sets-case-protocol-484.json')
    correction = read('stream-sets-dynamic-fixture-correction-484.json')
    baseline = read('stream-set-baseline-480/summary.json')
    assert all(item['status'] == 'passed' for item in
               (artifacts, checks, focused, runtime, direct, public, full))
    assert artifacts['source_sha256'] == frozen['source_sha256'] and checks['source_identity_preserved']
    assert focused['accepted_source'] == runtime['accepted_source'] == public['accepted_source'] == full['accepted_source'] == bound(ACCEPTED_SOURCE)
    assert checks['protocol']['source_manifest_sha256'] == sha(SOURCE)
    assert focused['source'] == runtime['source'] == bound(SOURCE)
    assert focused['artifacts'] == direct['artifact_manifest'] == bound(ARTIFACTS)
    assert runtime['manifest_sha256'] == sha(ARTIFACTS)
    assert direct['tests'] == len(direct['test_names']) == 87
    assert direct['failures'] == direct['errors'] == direct['skipped'] == 0
    assert public['cases'] == runtime['public_cases'] == protocol['expected_cases'] == 1121
    assert public['families'] == len(runtime['public_families']) == 22
    assert public['complete_case_log_records_equal'] and public['frozen_sources_and_binary_unchanged']
    assert full['queries'] == full['calls'] == 43 and full['repeats'] == 1
    assert full['all_values_schemas_and_clocks_reopened'] and full['original_input_and_sources_unchanged']
    assert not full['performance_claim_allowed'] and full['no_new_ingest']
    counts = {row['stage']: row['tests'] for row in checks['completed'] if 'tests' in row}
    assert len(checks['completed']) == 6
    assert counts['workspace-tests']['passed'] == 3219 and counts['workspace-tests']['ignored'] == 0
    assert counts['native-tests']['passed'] == 4241 and counts['native-tests']['ignored'] == 29
    for row in checks['completed']:
        assert sha(row['receipt']) == row['receipt_sha256'] and sha(row['log']) == row['log_sha256']
    native_log = Path(next(row['log'] for row in checks['completed'] if row['stage'] == 'native-tests')).read_text()
    for name in checks['protocol']['new_native_tests']:
        assert re.search(r'^test .*::' + name + r' \.\.\. ok$', native_log, re.M), name
    assert len(checks['protocol']['new_native_tests']) == 9
    assert '::streamed_dynamic_unsupported_shapes_and_initial_cancellation_precede_demand ... ok' in native_log
    for name in ('native-final-cli-release-build-streamsets484', 'native-final-python-release-build-streamsets484',
                 'stream-sets-direct-484', 'stream-sets-public-focused-487', 'stream-sets-public-487',
                 'stream-sets-full43-487', 'stream-sets-dynamic-refusal-focused-484',
                 'stream-sets-field-order-reproduction-487b'):
        completed(name)
    earlier = read('native-release-source-streamsets482.json')['source_sha256']
    changed = [name for name in frozen['source_sha256'] if frozen['source_sha256'][name] != earlier[name]]
    assert frozen['source_sha256'].keys() == earlier.keys()
    assert changed == correction['changed_files'] == ['shardloom-vortex/src/local_primitive_relational_batch_dynamic_tests.rs']
    assert correction['runtime_implementation_changed'] is False
    assert earlier[changed[0]] == correction['before_sha256']
    assert frozen['source_sha256'][changed[0]] == correction['after_sha256']
    assert sha(correction['old_fixture_preserved']) == correction['before_sha256']
    old_failed = read('stream-sets-native-tests-482a.json')
    assert old_failed['status'] == 'failed' and old_failed['returncode'] != 0
    assert sha(OUT / 'stream-sets-native-tests-482a.log') == old_failed['log_sha256']
    focused_failure = read('stream-sets-public-focused-484/summary.json')
    assert focused_failure['status'] == 'failed'
    assert len(focused_failure['cases']) == 237
    assert all(row['status'] == 'passed' for row in focused_failure['cases'][:-1])
    assert focused_failure['cases'][-1]['name'] == 'set-rich-union_all-collect'
    assert focused_failure['cases'][-1]['status'] == 'failed'
    assert read(DIAGNOSIS.name)['status'] == 'passed'
    assert focused['public_cases'] == 588
    assert baseline['status'] == 'passed' and len(baseline['cases']) == 12
    assert all(row['status'] == 'passed' for row in baseline['cases'])
    assert sum(row['outcome'] == 'static_streaming_refusal' for row in baseline['cases']) == 8
    assert sum(row['outcome'] == 'resident_control_passed' for row in baseline['cases']) == 4
    completed('stream-set-baseline-run-480')
    for path in (OUT / 'stream-set-baseline-480/logs').glob('*-values.json'):
        values = json.loads(path.read_text())
        assert values['actual'] == values['expected']

    members, exclusions = Members(), []
    def add(path, prefix='evidence', role='accepted observation, failure history or frozen identity'):
        path = Path(path)
        parent = next((root for root in (ROOT, OUT, UAT) if path.is_relative_to(root)), path.parent)
        members.add(path, prefix + '/' + path.relative_to(parent).as_posix(), prefix, parent, role)

    for pattern in ('stream-sets-*', 'stream-set-baseline-*'):
        for path in sorted(OUT.glob(pattern)):
            if path.is_file() and path.suffix in {'.json', '.log', '.md', '.rs'}:
                add(path)
    for pattern in ('*stream_sets*.py', '*stream_set*.py'):
        for path in sorted(OUT.glob(pattern)):
            add(path, 'tools', 'reproduction or verification helper')
    for name in ('freeze_native_release_298.py', 'freeze_query_cli_368.py', 'run_guarded.py',
                 'run_query_timing_runtime_461.py', 'run_compression_full43_457.py',
                 'run_stream_destination_review_checks_479.py', 'package_selection_acceptance_409.py'):
        add(OUT / name, 'tools', 'shared reproduction helper')
    for name in (SOURCE.name, ARTIFACTS.name, 'native-release-source-streamsets482.json',
                 ACCEPTED_SOURCE.name, CORRECTED.name,
                 'stream-destination-review-checks-479b.json', 'stream-destination-direct-tests-476.json',
                 'stream-destination-runtime-protocol-477.json', 'query-timing-manual-tests-inventory-462.json',
                 'compression-manual-tests-inventory-456.json',
                 'native-release-source-streamreview479accepted.json',
                 'stream-destination-native-artifacts-476.json', 'stream-destination-native-artifacts-477.json'):
        add(OUT / name)
    for name in ('native-final-cli-release-build-streamsets484', 'native-final-python-release-build-streamsets484'):
        for suffix in ('.json', '.log'):
            add(OUT / (name + suffix), 'builds')
    for folder, prefix in [
        (OUT / 'stream-set-baseline-480', 'baseline'),
        (OUT / 'stream-sets-public-focused-484', 'prior-failed-public-focused'),
        (OUT / 'stream-sets-field-order-reproduction-487', 'prior-diagnostic-outer-container-mismatch'),
        (OUT / 'stream-sets-field-order-reproduction-487b', 'confirmed-field-order-diagnosis'),
        (OUT / 'stream-sets-public-focused-487', 'public-focused'),
        (OUT / 'stream-sets-public-487', 'public'),
        (OUT / 'stream-sets-doc-surface-sources-485', 'documentation-inventory-sources'),
    ]:
        members.tree(folder, prefix, prefix, 'complete acceptance or pre-change control evidence', exclusions, omit_outputs=True)
    members.tree(Path(full['summary']['path']).parent, 'full43', 'full43',
                 'all complete native query calls', exclusions)
    for key in ('artifacts', 'value_files', 'envelopes', 'pressure_files'):
        for item in public[key]:
            verify(Path(item['path']), item['sha256'], item['bytes'])
    full_admission = json.loads(Path(full['admission']['path']).read_text())
    for item in full_admission['schema_sources']:
        verify(Path(item['path']), item['sha256'], item['bytes'])
        add(item['path'], 'reference', 'previous complete schema observation')
    for key in ('reference', 'queries'):
        item = full_admission[key]
        verify(Path(item['path']), item['sha256'], item['bytes'])
        add(item['path'], 'reference', 'retained complete query regression reference')
    for role in ('cli', 'binding'):
        item = artifacts[role]
        verify(Path(item['path']), item['sha256'], item['bytes'])
        exclusions.append(dict(**item, reason='frozen native executable; bulk payload omitted'))
    verify(Path(baseline['binary']['path']), baseline['binary']['sha256'], baseline['binary']['bytes'])
    exclusions.append(dict(**baseline['binary'], reason='frozen pre-change control executable; bulk payload omitted'))
    add(baseline['binary']['build_receipt'], 'baseline-build', 'original control build receipt')
    add(baseline['binary']['build_log'], 'baseline-build', 'original control build log')
    exclusions.append(dict(**full_admission['input'], reason='resident native input; full pre/post hash retained'))
    changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT, text=True).splitlines()
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=ROOT, text=True).splitlines()
    overlay = sorted(set(changed + untracked) & set(accepted))
    for name in ('shardloom-vortex/src/local_primitive_relational_batch_input.rs',
                 'shardloom-vortex/src/local_primitive_relational_batch_dynamic_tests.rs',
                 'shardloom-vortex/src/local_primitive_relational_batch_set_tests.rs',
                 'scripts/native_streaming_set_cases.py', 'python/tests/test_native_set_binding.py'):
        assert name in overlay
    for name in overlay:
        members.add(ROOT / name, 'source-overlay/' + name, 'repository', ROOT,
                    'complete accepted source overlay', accepted[name])
    add(ROOT / 'docs/architecture/native-stream-set-operations-2026-10-15.md', 'contract', 'finite implementation and acceptance contract')
    for name in ('native-stream-destinations-2026-10-15.json', 'native-stream-destinations-hosted-2026-10-15.json',
                 'native-query-timing-uat-2026-10-15.json'):
        add(DEST / name, 'companion-indices', 'accepted baseline provenance')

    require_local_path(LOCAL, Path.home(), sys.platform)
    assert not LOCAL.exists()
    ordered = sorted(members.paths.values(), key=lambda item: item.name)
    raw_size = sum(item.size for item in ordered)
    assert raw_size <= 256 * MIB
    storage = check_budgets(OUT, LOCAL, OUT / 'logs', min_free_bytes=12*GIB,
        reserve_bytes=raw_size + 64*MIB, max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
    LOCAL.mkdir()
    archive_path = LOCAL / (PREFIX + '.tar.xz')
    with archive_path.open('xb') as stream:
        with tarfile.open(fileobj=stream, mode='w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
            for item in ordered:
                verify(item.path, item.digest, item.size)
                info = tarfile.TarInfo(item.name)
                info.size, info.mode, info.mtime = item.size, 0o644, 0
                with item.path.open('rb') as source:
                    archive.addfile(info, source)
    seen = set()
    with tarfile.open(archive_path, mode='r|xz') as archive:
        for entry in archive:
            assert entry.isfile() and entry.name in members.names and entry.name not in seen
            item = members.paths[members.names[entry.name]]
            with archive.extractfile(entry) as stream:
                assert sha_stream(stream) == (item.size, item.digest)
            seen.add(entry.name)
    assert seen == set(members.names) and sources() == accepted
    for item in ordered:
        verify(item.path, item.digest, item.size)
    acceptance = dict(workspace_tests=3219, native_tests=4241, native_manual_platform_exclusions=29,
        corrected_focused_public_cases=588,
        new_native_tests=9, direct_tests=87, new_direct_methods=3, public_cases=1121, public_families=22,
        new_set_cases=324, new_set_pressure_cases=19,
        public_expected_rows=public['explicit_expected_value_rows'], public_pressure_rows=public['pressure_rows'],
        complete_queries=43, complete_query_rows=full['complete_rows'])
    limitations = ('Finite local workflow acceptance and one retained-reference query pass. '
        'Set membership remains resident under the shared grant; replay spill is a separate admitted mechanism. '
        'No matched performance comparison, whole-process memory cap, group-atomic publication, '
        'network transport, all-platform acceptance or new package release is claimed. '
        'Installed-wheel and hosted integration proof are subsequent gates.')
    manifest = dict(status='passed', base_commit=frozen['head'], source_files=len(accepted),
        source_manifest=bound(SOURCE), artifact_manifest=bound(ARTIFACTS), archive=bound(archive_path), source_overlay=overlay,
        accepted_source=bound(ACCEPTED_SOURCE), native_build_sources_and_current_acceptance_sources_distinguished=True,
        members=[dict(path=str(item.path), archive_path=item.name, bytes=item.size,
                      sha256=item.digest, roles=item.roles) for item in ordered],
        member_count=len(ordered), raw_bytes=raw_size, all_members_reopened=True,
        storage=storage, exclusions=exclusions, acceptance=acceptance,
        prior_failed_native_gate=bound(OUT / 'stream-sets-native-tests-482a.json'),
        dynamic_fixture_correction=bound(OUT / 'stream-sets-dynamic-fixture-correction-484.json'),
        public_field_order_correction=bound(DIAGNOSIS),
        prior_failed_public_gate=bound(OUT / 'stream-sets-public-focused-484/summary.json'),
        test_fixture_only_source_transition=True, compiled_runtime_changed_after_native_gates=False,
        corrected_fixture_verified_in_focused_and_full_gates=True,
        full43_timing_totals=full['timing_totals'], source_identity_preserved=True,
        hosted_integration_complete=False, installed_wheel_proof=False, publication_attempted=False,
        vendor_source_unchanged=True, limitations=limitations)
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    packed = lzma.compress(manifest_bytes, preset=6)
    assert lzma.decompress(packed) == manifest_bytes
    manifest_path = LOCAL / (PREFIX + '.manifest.json.xz')
    with manifest_path.open('xb') as stream:
        stream.write(packed)
    index = dict(schema_version='shardloom.stream_sets_acceptance.v1', status='passed_local',
        base_commit=frozen['head'], source_files=len(accepted), member_count=len(seen),
        all_members_reopened=True, raw_bytes=raw_size, acceptance=acceptance,
        full43_timing_totals=full['timing_totals'], source_overlay=overlay,
        archive=dict(file=archive_path.name, bytes=archive_path.stat().st_size, sha256=sha(archive_path)),
        manifest=dict(file=manifest_path.name, bytes=manifest_path.stat().st_size, sha256=sha(manifest_path),
                      raw_sha256=hashlib.sha256(manifest_bytes).hexdigest()),
        source_manifest=manifest['source_manifest'], hosted_integration_complete=False,
        accepted_source=manifest['accepted_source'], test_fixture_only_source_transition=True,
        installed_wheel_proof=False, publication_attempted=False, limitations=limitations)
    for path in (archive_path, manifest_path):
        target = DEST / path.name
        assert not target.exists()
        with target.open('xb') as stream:
            stream.write(path.read_bytes())
        assert sha(target) == sha(path)
    save(DEST / (PREFIX + '.json'), index)
    save(LOCAL / 'verification.json', dict(status='passed', member_count=len(seen),
        all_members_reopened=True, helper=bound(__file__), archive=bound(archive_path),
        manifest=bound(manifest_path), index=bound(DEST / (PREFIX + '.json'))))
    print(json.dumps(dict(status='passed', members=len(seen), source_overlay=len(overlay),
        raw_bytes=raw_size, archive_bytes=archive_path.stat().st_size,
        destination=str(DEST / (PREFIX + '.json')))))


if __name__ == '__main__':
    main()
