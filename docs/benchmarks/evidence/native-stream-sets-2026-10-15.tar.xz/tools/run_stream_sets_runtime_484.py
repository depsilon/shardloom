"""Build frozen set-operation artifacts and run direct and public acceptance."""
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

from freeze_native_release_298 import ROOT, OUT, sha, sources, save
from run_query_timing_runtime_461 import guarded, PYTHON_DEPS

SOURCE = OUT / 'native-release-source-streamsets484.json'
CHECKS = OUT / 'stream-sets-checks-484.json'
MANIFEST = OUT / 'native-release-artifacts-streamsets484.json'
PYTHON = OUT / 'selected-view-python-468/bin/python'
DIRECT = OUT / 'stream-sets-direct-tests-484.json'
FOCUSED = OUT / 'stream-sets-public-focused-484'


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def load():
    frozen = json.loads(SOURCE.read_text())
    manifest = json.loads(MANIFEST.read_text())
    assert sources() == manifest['source_sha256'] == frozen['source_sha256']
    for key in ('cli', 'binding'):
        assert identity(manifest[key]['path']) == {k: manifest[key][k] for k in ('path', 'bytes', 'sha256')}
    return manifest


def direct():
    sys.path.insert(0, str(PYTHON_DEPS))
    sys.path.insert(0, str(ROOT / 'python/src'))
    import pyarrow
    import shardloom
    manifest = load()
    assert Path(sys.executable) == PYTHON
    assert Path(shardloom.__file__).resolve() == ROOT / 'python/src/shardloom/__init__.py'
    os.environ['SHARDLOOM_NATIVE_TEST_LIBRARY'] = manifest['binding']['path']
    os.environ['SHARDLOOM_REQUIRE_NATIVE_PYTHON'] = '1'
    os.environ['SHARDLOOM_BIN'] = manifest['cli']['path']
    suite = unittest.defaultTestLoader.discover(str(ROOT / 'python/tests'), pattern='test_native*binding.py')

    def names(test):
        if isinstance(test, unittest.TestSuite):
            return [name for child in test for name in names(child)]
        return [test.id()]

    identifiers = names(suite)
    prior = json.loads((OUT / 'stream-destination-direct-tests-476.json').read_text())['test_names']
    assert len(prior) == 84 and set(prior).issubset(identifiers)
    assert len(identifiers) == len(set(identifiers)) == 87
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    passed = result.wasSuccessful() and result.testsRun == len(identifiers) and not result.skipped
    save(DIRECT, dict(status='passed' if passed else 'failed', tests=result.testsRun,
        failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
        test_names=identifiers, prior_test_names=prior, artifact_manifest=identity(MANIFEST),
        interpreter=sys.executable, python_version=sys.version, pyarrow_version=pyarrow.__version__,
        pyarrow_file=pyarrow.__file__, package_source=shardloom.__file__, helper=identity(__file__),
        mode='direct_source_package_with_explicit_frozen_native_library', installed_wheel_proof=False))
    assert load() == manifest and passed


def main():
    frozen = json.loads(SOURCE.read_text())
    checks = json.loads(CHECKS.read_text())
    assert checks['status'] == 'passed' and checks['source_identity_preserved']
    assert len(checks['completed']) == 6 and checks['protocol']['source_manifest_sha256'] == sha(SOURCE)
    assert sources() == frozen['source_sha256']
    assert not MANIFEST.exists() and not DIRECT.exists() and not FOCUSED.exists()
    protocol = dict(source=identity(SOURCE), checks=identity(CHECKS), helper=identity(__file__),
        guard=identity(OUT / 'run_guarded.py'), freezer=identity(OUT / 'freeze_native_release_298.py'),
        reused_guard_helper=identity(OUT / 'run_query_timing_runtime_461.py'),
        prior_direct=identity(OUT / 'stream-destination-direct-tests-476.json'),
        direct_expected_methods=87, new_direct_methods=3, focused_families=['sets', 'sets-pressure', 'input', 'window'],
        planned_set_cases=324, planned_set_pressure_cases=19,
        broad_public_pending=True, full43_pending=True, publication_attempted=False)
    save(OUT / 'stream-sets-runtime-protocol-484.json', protocol)
    print(json.dumps(dict(stage='release-cli', status='starting')), flush=True)
    guarded('native-final-cli-release-build-streamsets484', 2100,
        ['cargo', 'build', '--offline', '--locked', '--release', '-p', 'shardloom-cli',
         '--features', 'release-user-surfaces', '--message-format=json-render-diagnostics'])
    assert sources() == frozen['source_sha256']
    print(json.dumps(dict(stage='release-binding', status='starting')), flush=True)
    guarded('native-final-python-release-build-streamsets484', 2100,
        [sys.executable, '-B', ROOT / 'scripts/build_native_python.py', '--release', '--offline',
         '--output-dir', OUT / 'stream-sets-native-binding-484'])
    subprocess.run([sys.executable, '-B', str(OUT / 'freeze_native_release_298.py'),
                    '--run-id', 'streamsets484'], cwd=ROOT, check=True)
    manifest = load()
    print(json.dumps(dict(stage='direct-binding', status='starting')), flush=True)
    guarded('stream-sets-direct-484', 1800, [PYTHON, '-B', __file__, 'direct'])
    assert json.loads(DIRECT.read_text())['status'] == 'passed'
    print(json.dumps(dict(stage='focused-public', status='starting')), flush=True)
    guarded('stream-sets-public-focused-484', 5400,
        [sys.executable, '-B', ROOT / 'scripts/run_native_streaming_input_uat.py',
         '--binary', manifest['cli']['path'], '--uat-root', FOCUSED, '--operation-timeout', '600',
         '--families', 'sets', 'sets-pressure', 'input', 'window'])
    result = json.loads((FOCUSED / 'summary.json').read_text())
    assert result['status'] == 'passed' and all(case['status'] == 'passed' for case in result['cases'])
    assert len(result['cases']) == len({case['name'] for case in result['cases']})
    assert result['families'] == protocol['focused_families']
    assert load() == manifest
    save(OUT / 'stream-sets-runtime-focused-484.json', dict(status='passed', source=identity(SOURCE),
        artifacts=identity(MANIFEST), direct=identity(DIRECT), focused_public=identity(FOCUSED / 'summary.json'),
        public_cases=len(result['cases']), protocol=identity(OUT / 'stream-sets-runtime-protocol-484.json'),
        source_identity_preserved=True, broad_public_pending=True, full43_pending=True))


if __name__ == '__main__':
    direct() if sys.argv[1:] == ['direct'] else main()
