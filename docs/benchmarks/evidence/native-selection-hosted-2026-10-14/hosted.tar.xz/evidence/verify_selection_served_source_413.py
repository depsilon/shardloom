"""Verify bounded preview/production responses against the deployed Git source."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import urllib.request

from verify_selection_integration_source_413 import ROOT, HEAD, WEBSITE_BASIS, git, bound


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(path, data):
    with path.open('xb') as stream:
        stream.write(data)


def api(endpoint):
    return subprocess.check_output(['/opt/homebrew/bin/gh', 'api', endpoint], timeout=45)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=['preview', 'production'], required=True)
    parser.add_argument('--revision', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    revision = git('rev-parse', args.revision)
    assert git('diff', '--name-only', WEBSITE_BASIS, revision, '--', 'website', 'website-src') == ''
    raw_pr = api('repos/depsilon/shardloom/pulls/1550')
    pr = json.loads(raw_pr)
    assert pr['head']['sha'] == HEAD
    if args.stage == 'preview':
        assert revision == HEAD
        origin = 'https://e2fe311a-shardloom.djheinrich.workers.dev'
        raw_comments = api('repos/depsilon/shardloom/issues/1550/comments?per_page=100')
        comments = json.loads(raw_comments)
        assert len(comments) < 100
        assert any(origin in c['body'] and HEAD[:8] in c['body'] for c in comments)
    else:
        assert pr['merged'] and pr['merge_commit_sha'] == revision
        origin = 'https://shardloom.io'
        raw_comments = None
    raw_checks = api(f'repos/depsilon/shardloom/commits/{revision}/check-runs?per_page=100')
    checks = json.loads(raw_checks)
    assert checks['total_count'] == len(checks['check_runs']) <= 100
    workers = [c for c in checks['check_runs'] if c['name'] == 'Workers Builds: shardloom']
    assert len(workers) == 1
    worker = workers[0]
    assert worker['head_sha'] == revision and worker['status'] == 'completed' and worker['conclusion'] == 'success'
    args.output.mkdir()
    save(args.output / 'pull-request.json', raw_pr)
    save(args.output / 'deployment-checks.json', raw_checks)
    if raw_comments is not None:
        save(args.output / 'issue-comments.json', raw_comments)
    routes = [f'field-guide/{name}/index.html' for name in ('python-surface', 'runtime-and-io', 'limitations')]
    routes.append('pagefind/pagefind-entry.json')
    responses = []
    for route in routes:
        expected = subprocess.check_output(['git', 'show', revision + ':website/' + route], cwd=ROOT)
        url = origin + '/' + route.removesuffix('index.html')
        request = urllib.request.Request(url, headers={'User-Agent': 'ShardLoom-owned-site-verification'})
        with urllib.request.urlopen(request, timeout=30) as response:
            actual = response.read((2 << 20) + 1)
            assert response.status == 200 and len(actual) <= 2 << 20
            final_url = response.url
        filename = route.replace('/', '_')
        save(args.output / filename, actual)
        prefix = 0
        while prefix < min(len(actual), len(expected)) and actual[prefix] == expected[prefix]:
            prefix += 1
        extra = len(actual) - len(expected)
        insertion = b''
        preserved = actual == expected
        if not preserved and 0 < extra <= 16384 and route.endswith('.html'):
            insertion = actual[prefix:prefix + extra]
            preserved = actual[prefix + extra:] == expected[prefix:]
            preserved &= b'/cdn-cgi/challenge-platform/' in insertion or b'static.cloudflareinsights.com/' in insertion
        responses.append(dict(source='website/' + route, response=filename, url=url, final_url=final_url,
                              expected_bytes=len(expected), expected_sha256=digest(expected),
                              observed_bytes=len(actual), observed_sha256=digest(actual),
                              http_status=200, raw_byte_identical=actual == expected,
                              source_preserved=bool(preserved), insertion_bytes=len(insertion),
                              insertion_sha256=digest(insertion) if insertion else None))
    report = dict(schema_version='shardloom.selection_served_source.v1', stage=args.stage,
                  status='passed' if all(r['source_preserved'] for r in responses) else 'failed',
                  observed_at=datetime.now(timezone.utc).isoformat(), revision=revision,
                  deployment={key: worker[key] for key in ('id', 'head_sha', 'status', 'conclusion', 'details_url', 'completed_at')},
                  responses=responses, website_unchanged_from=WEBSITE_BASIS,
                  browser_basis='Earlier desktop/mobile/search proof applies to identical website and website-src trees; this is a new HTTP/source observation, not a new browser run.',
                  script=bound(Path(__file__).resolve()),
                  integration_helper=bound(Path(__file__).with_name('verify_selection_integration_source_413.py')))
    save(args.output / 'report.json', (json.dumps(report, indent=2) + '\n').encode())
    assert report['status'] == 'passed'
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
