"""Independently verify the final raw PR1550 hosted evidence before merge."""
import hashlib
import json
from pathlib import Path
import re
from datetime import datetime, timezone

OUT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
FINAL = OUT / 'selection-hosted-final-414'
HEAD = 'ed7b028e852008fd9352b0bf255e7451d536b07a'
BASE = '483cbaa982dd300dec45bb50066cdbf452686b36'
MERGE = 'c99cc6cc697d19fde42b98ea64d02b92790dad33'


def read(name):
    return json.loads((FINAL / name).read_text())


def bound(path):
    data = Path(path).read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def verify(record):
    actual = bound(record['path'])
    assert all(actual[k] == record[k] for k in actual), record['path']


def plain(path):
    return '\n'.join(re.sub(r'^\d{4}-\d{2}-\d{2}T\S+Z ', '', line)
                     for line in Path(path).read_text().splitlines())


def pages(name):
    return [row for page in read(name) for row in page]


def main():
    report_path = OUT / 'selection-hosted-primary-414.json'
    assert not report_path.exists()
    inventory = read('inventory.json')
    assert inventory['expected_head_sha'] == HEAD
    assert len(inventory['files']) == 29
    dependencies = (inventory['files'] + inventory['wheel_log_references_in_414']
                    + [inventory['native_vortex_tests']['source_ci_workflow']])
    for record in dependencies:
        verify(record)
    prior = json.loads((OUT / 'selection-hosted-414/inventory.json').read_text())
    assert len(prior['files']) == 52
    for record in prior['files'] + prior['source_dependencies']:
        verify(record)

    pr = read('pr-snapshot-1.json')
    assert pr['number'] == 1550 and pr['state'] == 'open' and not pr['merged']
    assert pr['head']['sha'] == HEAD and pr['base']['sha'] == BASE
    checks_pages = read('check-runs-snapshot-1.json')
    checks = [check for page in checks_pages for check in page['check_runs']]
    assert len(checks_pages) == 1 and checks_pages[0]['total_count'] == len(checks) == 44
    assert len({check['id'] for check in checks}) == 44
    assert all(check['head_sha'] == HEAD and check['status'] == 'completed'
               and check['conclusion'] == 'success' for check in checks)
    for prefix, run_id, count in [('main', 38519453066, 40), ('codeql', 38519453123, 2)]:
        run = read(prefix + '-run-snapshot-1.json')
        assert run['id'] == run_id and run['head_sha'] == HEAD
        assert run['status'] == 'completed' and run['conclusion'] == 'success'
        jobs = read(prefix + '-jobs-snapshot-1.json')
        assert jobs['total_count'] == len(jobs['jobs']) == count
        assert all(job['run_id'] == run_id and job['head_sha'] == HEAD
                   and job['status'] == 'completed' and job['conclusion'] == 'success'
                   for job in jobs['jobs'])

    log = plain(inventory['native_vortex_tests']['raw_full_log']['path'])
    assert MERGE + ':refs/remotes/pull/1550/merge' in log
    summaries = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;.*$', log, re.M)
    assert summaries == [('2743', '0', '24'), ('10', '0', '0'), ('7', '0', '0'), ('17', '0', '0')]
    assert not re.search(r'^test .* \.\.\. FAILED$', log, re.M)
    zstd = re.findall(r'^test native_provider_memory::zstd_tests::(.*) \.\.\. ok$', log, re.M)
    assert len(zstd) == len(set(zstd)) == 37
    context = re.findall(r'^test (.*aggregate_utf8_context[^\n]*) \.\.\. ok$', log, re.M)
    assert len(context) == len(set(context)) == 3
    # Read the final group's actual named outcomes, not just the collector's count.
    vendor = re.findall(r'^test (array::tests::[^\n]*) \.\.\. ok$', log, re.M)
    assert len(vendor) == len(set(vendor)) == 17
    expected_vendor = inventory['native_vortex_tests']['four_group_summaries'][3]['literal_test_outcomes']
    assert sorted(vendor) == sorted(re.search(r'test (.*) \.\.\. ok$', line).group(1)
                                    for line in expected_vendor)
    wheels = []
    for record in inventory['wheel_log_references_in_414']:
        source = plain(record['path'])
        assert MERGE + ':refs/remotes/pull/1550/merge' in source
        marker = '{\n  "schema_version": "shardloom.native_python_wheel_proof.v1"'
        assert source.count(marker) == 1
        proof, _ = json.JSONDecoder().raw_decode(source[source.index(marker):])
        assert proof['status'] == proof['stage']['status'] == proof['integrity']['status'] == 'passed'
        assert proof['integration'] == dict(tests=80, failures=0, errors=0, skipped=0, status='passed')
        assert proof['installed_load']['isolated_install'] is True
        assert proof['installed_load']['version'] == '0.5.1'
        assert proof['performance_claim'] is False and proof['publication_attempted'] is False
        assert all(step['returncode'] == 0 for step in proof['steps'])
        wheels.append(dict(source=record, integration=proof['integration'],
                           python=proof['python'], platform=proof['platform']))

    assert pages('reviews-final.json') == pages('inline-comments-final.json') == []
    threads = read('review-threads-final.json')['data']['repository']['pullRequest']['reviewThreads']
    assert threads['nodes'] == [] and threads['pageInfo']['hasNextPage'] is False
    comments = pages('issue-comments-final.json')
    assert len(comments) == 2
    reviews = [c for c in comments if c['user']['login'] == 'chatgpt-codex-connector[bot]']
    assert len(reviews) == 1 and '**Completed**' in reviews[0]['body']
    assert '`ed7b028`' in reviews[0]['body'] and '**Code Review**' in reviews[0]['body']
    reactions = pages('issue-reactions-final.json')
    assert any(r['user']['login'] == 'chatgpt-codex-connector[bot]' and r['content'] == '+1' for r in reactions)
    assert not any(r['user']['login'] == 'chatgpt-codex-connector[bot]' and r['content'] == 'eyes' for r in reactions)

    source_path = OUT / 'selection-pr1550-synthetic-source-413.json'
    source = json.loads(source_path.read_text())
    assert source['status'] == 'passed' and source['reviewed_head'] == HEAD
    assert source['verified_revision'] == MERGE and source['source_files_verified'] == 2241
    assert source['source_equal'] is True and len(set(source['trees'].values())) == 1
    preview_path = OUT / 'selection-preview-413/report.json'
    preview = json.loads(preview_path.read_text())
    assert preview['status'] == 'passed'
    report = dict(schema_version='shardloom.selection_hosted_primary.v1', status='passed',
                  observed_at=datetime.now(timezone.utc).isoformat(), head=HEAD, base=BASE,
                  observed_checkout=MERGE, final_raw_files_verified=29,
                  prior_raw_files_verified=52, checks_passed=44,
                  native_group_summaries=summaries, native_zstd_test_names=zstd,
                  aggregate_context_test_names=context, vendor_zstd_test_names=vendor,
                  wheel_proofs=wheels, review_findings=0,
                  review_status='Automated review complete, +1 reaction, no reviews/inline/threads; not a GitHub approval',
                  source_report=bound(source_path), preview_report=bound(preview_path),
                  final_inventory=bound(FINAL / 'inventory.json'), script=bound(Path(__file__)),
                  verification_corrections=['Initial inline verification used summary stage_status/source_dependencies keys; no report was emitted. This verifier reads raw stage.status, integrity.status and actual v4 dependency fields.'],
                  scope='PR checks and source identity accepted before merge; production and actual merge source require separate checks.')
    with report_path.open('x') as handle:
        json.dump(report, handle, indent=2)
        handle.write('\n')
    print(json.dumps(dict(status=report['status'], checks=44, native=summaries,
                         wheels=len(wheels), output=str(report_path)), indent=2))


if __name__ == '__main__':
    main()
