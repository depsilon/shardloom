"""Bind the selection acceptance source to a named Git commit and PR merge tree."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
HEAD = 'ed7b028e852008fd9352b0bf255e7451d536b07a'
BASE = '483cbaa982dd300dec45bb50066cdbf452686b36'
WEBSITE_BASIS = '5b5cd6a7cb3c88d20046079c46900d9b323b1274'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode().strip()


def bound(path):
    raw = Path(path).read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def source_hashes(revision, names):
    process = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=ROOT,
                               stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    result = {}
    try:
        for name in sorted(names):
            process.stdin.write(f'{revision}:{name}\n'.encode())
            process.stdin.flush()
            header = process.stdout.readline().decode().split()
            assert len(header) == 3 and header[1] == 'blob', (revision, name, header)
            remaining = int(header[2])
            digest = hashlib.sha256()
            while remaining:
                block = process.stdout.read(min(remaining, 1 << 20))
                assert block
                digest.update(block)
                remaining -= len(block)
            assert process.stdout.read(1) == b'\n'
            result[name] = digest.hexdigest()
    finally:
        process.stdin.close()
        assert process.wait() == 0
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--revision', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    frozen_path = OUT / 'selection-check-source-409.json'
    frozen = json.loads(frozen_path.read_text())
    expected = frozen['source_sha256']
    assert len(expected) == 2241
    revision = git('rev-parse', args.revision)
    assert source_hashes(HEAD, expected) == expected
    assert source_hashes(revision, expected) == expected
    trees = {key: git('rev-parse', value + '^{tree}')
             for key, value in [('reviewed_head', HEAD), ('verified_revision', revision)]}
    assert len(set(trees.values())) == 1
    assert git('diff', '--name-only', WEBSITE_BASIS, revision, '--', 'website', 'website-src') == ''
    workflow = subprocess.check_output(['git', 'show', revision + ':.github/workflows/ci.yml'], cwd=ROOT)
    assert hashlib.sha256(workflow).hexdigest() == frozen['workflow_sha256']
    report = dict(schema_version='shardloom.selection_integration_source.v1', status='passed',
                  observed_at=datetime.now(timezone.utc).isoformat(), reviewed_head=HEAD,
                  reviewed_base=BASE, verified_revision=revision, trees=trees,
                  source_files_verified=len(expected), frozen_source=bound(frozen_path),
                  workflow_sha256=frozen['workflow_sha256'], source_equal=True,
                  website_unchanged_from=WEBSITE_BASIS,
                  script=bound(Path(__file__).resolve()),
                  scope='Source/tree identity only; hosted checks, review and production have separate evidence.')
    with args.output.open('x') as handle:
        json.dump(report, handle, indent=2)
        handle.write('\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
