"""Run selected closeout checks with existing repository tools."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
DEST = OUT / 'final-checks-716b'
DEST.mkdir(exist_ok=False)
checks = []

def run(name, command):
    with (DEST / (name + '.log')).open('xb') as log:
        result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    checks.append({'name': name, 'command': [str(x) for x in command], 'returncode': result.returncode})
    print(name, result.returncode, flush=True)
    if result.returncode:
        raise RuntimeError(name + ' failed; inspect its retained log')

try:
    run('whitespace', ['git', 'diff', '--check'])
    run('python-export-stubs', [sys.executable, 'scripts/write_python_api_exports.py', '--check'])
    run('application-reference', [sys.executable, 'scripts/write_public_api_reference.py', '--binary', OUT / 'current-artifacts/shardloom', '--check'])
    run('reference-contract', [sys.executable, 'scripts/check_user_surface_reference.py'])
    run('docs-regressions', [sys.executable, '-m', 'unittest', 'python.tests.test_release_scripts', 'python.tests.test_runtime_gap_family_burn_down', 'python.tests.test_compute_engine_completion_gate'])
    for name, script in [('contribution', 'check_contribution_governance.py'),
                         ('v1-scope', 'check_v1_inclusion_scope.py'),
                         ('runtime-gaps', 'check_runtime_gap_family_burn_down.py'),
                         ('docs-contract', 'check_v1_docs_productization.py')]:
        run(name, [sys.executable, 'scripts/' + script, '--output', DEST / (name + '.json')])
    run('architecture-tracker', [sys.executable, 'scripts/check_release_architecture_tracker.py', '--allow-blocked', '--output', DEST / 'architecture-tracker.json'])
    for shell in ('bash', 'zsh', 'fish'):
        script = DEST / ('completion.' + shell)
        output = subprocess.check_output([OUT / 'current-artifacts/shardloom', 'command-metadata', '--completion', shell], cwd=ROOT)
        script.write_bytes(output)
        executable = shutil.which(shell)
        if executable:
            run('completion-' + shell, [executable, '-n', script])
        else:
            checks.append({'name': 'completion-' + shell, 'status': 'not_run', 'reason': 'shell unavailable; actual CLI text/JSON and audience agreement covered by Rust integration test'})
    checks.append({'name': 'release-boundary', 'status': 'missing_prerequisites', 'reason': 'No source-rehearsal transcript or package-channel report at default paths; failed closed in final-checks-716. Regression and fresh installed-wheel proofs are separate; no release-readiness claim.'})
    status = 'passed'
except BaseException:
    status = 'failed'
    raise
finally:
    (DEST / 'report.json').write_text(json.dumps({'status': status, 'checks': checks}, indent=2) + '\n')
