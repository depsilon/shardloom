"""Paired installed high-level workflows; diagnostic clocks are not kernel claims.

Reuses the workload shapes and five-repetition method of native-surface-measurement-300c.
Run serially under run_guarded.py. No release, dependency, or resource policy changes.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time

WORKLOADS = ("short_calls", "retained_chain", "large_columnar", "streamed_write_reopen")
GRANT = dict(memory_bytes=1 << 30, max_parallelism=2)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def save(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def child(args):
    import pyarrow as pa
    import shardloom as sl
    from shardloom import _native
    proof = json.loads((args.proof / "report.json").read_text())
    assert proof["status"] == "passed"
    prefix = Path(sys.prefix).resolve()
    assert prefix == (args.proof / "venv").resolve()
    assert prefix in Path(sl.__file__).resolve().parents
    assert sha(_native.__file__) == proof["integrity"]["native_library_sha256"]
    binary = Path(proof["installed_load"]["cli"])
    assert sha(binary) == proof["integrity"]["cli_sha256"]
    selected = {} if args.transport == "default" else {"transport": args.transport}
    ctx = sl.context(**GRANT, **selected)
    expected_transport = {'prior_default': 'subprocess', 'current_default': 'native',
                          'prior_native': 'native', 'current_process': 'subprocess'}[args.arm]
    assert ctx.client.transport == expected_transport
    reports = []
    producer_calls = 0
    record = {"status": "running", "arm": args.arm, "workload": args.workload,
              "sample": args.sample, "package": str(sl.__file__),
              "transport": ctx.client.transport, "grant": GRANT,
              "driver_sha256": sha(__file__), "engine_execution_seconds": None,
              "clock_scope": "retained context: plan/intake, execution, delivery/conversion; excludes verification",
              "kernel_speedup_claim": False}

    def receipt(result):
        reports.append(result)

    def rows(frame):
        result = frame.collect(check=True)
        receipt(result)
        return result

    def stream_table(frame):
        with frame.iter_batches(batch_rows=2048) as batches:
            tables = [batch.to_arrow() for batch in batches]
            assert batches.report is not None
            receipt(batches.report)
        return pa.concat_tables(tables)

    try:
        # Same retained-worker setup as the accepted 300c measurement.
        warm = ctx.sql("SELECT 0 AS value").collect(check=True)
        assert warm.python_objects == ({"value": 0},)
        plan = None
        if args.workload == "short_calls":
            plan = ctx.range(0, 32).agg(total="sum(value)")
            assert plan.collect(check=True).python_objects == ({"total": 496.0},)
        started = time.perf_counter_ns()
        if args.workload == "short_calls":
            table = pa.concat_tables([rows(plan).to_arrow() for _ in range(101)])
        elif args.workload == "retained_chain":
            first = rows(ctx.range(0, 32_769))

            def admit(result):
                if args.arm.startswith("current"):
                    return ctx.from_result(result)
                if ctx.client.transport == "native":
                    return ctx.from_arrow_table(result, check=True)
                return ctx.from_rows(result.python_objects, schema={"value": "int64"})

            second = rows(admit(first).filter("value % 2 = 0"))
            table = rows(admit(second).select("value + 7 AS plus")).to_arrow()
        elif args.workload == "large_columnar":
            table = stream_table(ctx.range(0, 131_073))
        else:
            def producer():
                nonlocal producer_calls
                producer_calls += 1
                for start in range(0, 70_017, 2048):
                    yield [{"value": value} for value in range(start, min(start + 2048, 70_017))]

            target = args.output / "written.vortex"
            frame = ctx.from_batches(producer, schema={"value": "int64"}, streaming=True)
            written = frame.filter("value >= 13").write_vortex(target, check=True)
            receipt(written)
            table = stream_table(ctx.read_vortex(target))
        record["workflow_diagnostic_ns"] = time.perf_counter_ns() - started
        if args.workload == "short_calls":
            expected = {"total": [496.0] * 101}
        elif args.workload == "retained_chain":
            expected = {"plus": [value + 7 for value in range(0, 32_769, 2)]}
        elif args.workload == "large_columnar":
            expected = {"value": list(range(131_073))}
        else:
            expected = {"value": list(range(13, 70_017))}
            if args.arm.startswith("current"):
                assert written.output_commit_status == "committed"
        for result in reports:
            assert result.envelope.status == "success"
            assert not result.fallback_attempted and not result.external_engine_invoked
        assert table.to_pydict() == expected, "complete result differs"
        if args.workload == "streamed_write_reopen":
            assert producer_calls == 1, "producer was replayed"
        result_path = args.output / "complete-result.arrow"
        with pa.OSFile(str(result_path), "wb") as target:
            with pa.ipc.new_file(target, table.schema) as writer:
                writer.write_table(table)
        clocks = []
        for result in reports:
            fields = result.envelope.field_map
            observed = {key: value for key, value in fields.items() if "seconds" in key or "timing" in key}
            clocks.append(observed)
        engine = [result.envelope.field("engine_execution_seconds") for result in reports]
        if engine and all(value is not None for value in engine):
            record["engine_execution_seconds"] = sum(float(value) for value in engine)
        record.update(status="passed", rows=table.num_rows,
                      schema=[(field.name, str(field.type), field.nullable) for field in table.schema],
                      complete_result_sha256=sha(result_path), producer_calls=producer_calls,
                      execution_count=len(reports), observed_timing_fields=clocks,
                      fallback_attempted=False, external_engine_invoked=False)
    except BaseException as error:
        record.update(status="failed", error=f"{type(error).__name__}: {error}")
        raise
    finally:
        try:
            ctx.client.close()
        finally:
            save(args.output / "sample.json", record)


def parent(args):
    args.output.mkdir()
    manifest = {
        "driver_sha256": sha(__file__), "workloads": WORKLOADS,
        "repetitions": 5, "grant": GRANT,
        "purpose": "dispatch/materialization regression evidence; no kernel or comparative claim",
        "source_identity": json.loads(args.identity.read_text()), "samples": [],
    }
    arms = [("prior_default", args.prior, "default"), ("current_default", args.current, "default"),
            ("prior_native", args.prior, "native"), ("current_process", args.current, "subprocess")]
    env = {key: value for key, value in os.environ.items()
           if key not in {"PYTHONPATH", "PYTHONHOME"} and not key.startswith("SHARDLOOM_")}
    env.update(PYTHONNOUSERSITE="1", PYTHONDONTWRITEBYTECODE="1")
    try:
        for workload in WORKLOADS:
            for sample in range(5):
                order = arms if sample % 2 == 0 else list(reversed(arms))
                for arm, proof, transport in order:
                    output = args.output / f"{workload}-{sample}-{arm}"
                    output.mkdir()
                    command = [str(proof / "venv/bin/python"), "-I", __file__, "--child",
                               "--proof", str(proof), "--output", str(output), "--arm", arm,
                               "--transport", transport, "--workload", workload, "--sample", str(sample)]
                    with (output / "process.log").open("x") as log:
                        subprocess.run(command, cwd=output, env=env, stdout=log,
                                       stderr=subprocess.STDOUT, timeout=180, check=True)
                    observation = json.loads((output / "sample.json").read_text())
                    assert observation["status"] == "passed"
                    manifest["samples"].append(observation)
                    print(f"PASS {workload} repetition {sample + 1} {arm}", flush=True)
        manifest["diagnostic_medians_seconds"] = {
            workload: {arm: statistics.median(
                row["workflow_diagnostic_ns"] / 1e9 for row in manifest["samples"]
                if row["workload"] == workload and row["arm"] == arm)
                for arm, _, _ in arms} for workload in WORKLOADS
        }
        for workload in WORKLOADS:
            groups = [row for row in manifest["samples"] if row["workload"] == workload]
            assert len({json.dumps(row["schema"]) for row in groups}) == 1, (workload, "schema drift")
        manifest["status"] = "passed"
    except BaseException as error:
        manifest.update(status="failed", error=f"{type(error).__name__}: {error}")
        raise
    finally:
        save(args.output / "report.json", manifest)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--child", action="store_true")
    for name in ("output", "proof", "current", "prior", "identity"):
        parser.add_argument("--" + name, type=Path)
    for name in ("arm", "transport", "workload"):
        parser.add_argument("--" + name)
    parser.add_argument("--sample", type=int)
    args = parser.parse_args()
    child(args) if args.child else parent(args)
