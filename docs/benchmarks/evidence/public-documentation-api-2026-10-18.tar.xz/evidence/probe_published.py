import importlib.util
import json
from pathlib import Path
import tempfile

import shardloom as sl

out = Path(__file__).resolve().parent
assert sl.__version__ == '0.6.0'
assert Path(sl.__file__).is_relative_to(out / 'published-0.6.0')
assert all(importlib.util.find_spec(name) is None for name in ('pyarrow', 'pandas', 'numpy'))
expected = ({'order_id': 1, 'status': 'paid'}, {'order_id': 3, 'status': 'paid'})
proof = {'package': str(Path(sl.__file__)), 'version': sl.__version__,
         'optional_integrations_installed': False, 'cases': []}
with tempfile.TemporaryDirectory(prefix='orders-', dir=out) as directory:
    source = Path(directory) / 'orders.csv'
    source.write_text('order_id,status\n1,paid\n2,pending\n3,paid\n', encoding='utf-8')
    for transport in ('subprocess', 'native'):
        ctx = sl.context(transport=transport, memory_bytes=256 << 20, max_parallelism=2)
        try:
            paid = ctx.read_csv(source).filter(sl.col('status') == 'paid').sort('order_id')
            dataframe = paid.collect(check=True)
            sql = ctx.sql(f"SELECT order_id, status FROM '{source}' WHERE status = 'paid' ORDER BY order_id").collect(check=True)
            assert dataframe.python_objects == sql.python_objects == expected
            target = Path(directory) / (transport + '-paid.vortex')
            written = paid.write_vortex(target)
            reopened = ctx.read_vortex(target).sort('order_id').collect(check=True)
            assert reopened.python_objects == expected
            assert not any(result.fallback_attempted or result.external_engine_invoked for result in (dataframe, sql, written, reopened))
            case = {'transport': transport, 'dataframe': dataframe.python_objects,
                    'sql': sql.python_objects, 'reopened': reopened.python_objects,
                    'schema': [(name, str(dtype)) for name, dtype in dataframe.result_schema],
                    'write_status': written.output_commit_status,
                    'fallback_attempted': False, 'external_engine_invoked': False}
            proof['cases'].append(case)
            print(json.dumps(case), flush=True)
        finally:
            ctx.client.close()
proof['status'] = 'passed'
(out / 'published-quickstart-probe.json').write_text(json.dumps(proof, indent=2) + '\n')
