"""Clean installed application acceptance using the maintained unittest modules."""
import hashlib
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PROOF = OUT / 'wheel-current-715'
proof = json.loads((PROOF / 'report.json').read_text())
assert proof['status'] == 'passed'
parser = argparse.ArgumentParser()
parser.add_argument('--minimal', action='store_true')
args = parser.parse_args()
python = PROOF / ('venv-minimal/bin/python' if args.minimal else 'venv/bin/python')
report = OUT / ('installed-minimal-public-715.json' if args.minimal else 'installed-public-715.json')
assert not report.exists()
wheel = PROOF / 'dist' / proof['integrity']['wheel']
assert hashlib.sha256(wheel.read_bytes()).hexdigest() == proof['integrity']['wheel_sha256']
env = {key: value for key, value in os.environ.items()
       if key not in {'PYTHONPATH', 'PYTHONHOME'} and not key.startswith('SHARDLOOM_')}
env.update(PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1',
           SHARDLOOM_REQUIRE_NATIVE_PYTHON='1', SHARDLOOM_TEST_INSTALLED_QUICKSTART='1')
if args.minimal:
    subprocess.run([sys.executable, '-m', 'venv', python.parent.parent], cwd=OUT, env=env, check=True)
    subprocess.run([python, '-I', '-c',
        "import importlib.util; assert all(importlib.util.find_spec(name) is None for name in ('pyarrow','pandas','numpy','polars','duckdb'))"],
        cwd=OUT, env=env, check=True)
subprocess.run([python, '-I', '-m', 'pip', 'install', '--no-index', '--no-deps', wheel],
               cwd=OUT, env=env, check=True)
program = '''
import json, pathlib, runpy, sys, unittest
import shardloom as sl
root = pathlib.Path(sys.argv[1]); output = pathlib.Path(sys.argv[2])
assert pathlib.Path(sys.prefix).resolve() in pathlib.Path(sl.__file__).resolve().parents
suite = unittest.TestSuite()
for pattern in ('test_public_context.py', 'test_public_quickstart.py', 'test_batches.py'):
    suite.addTests(unittest.defaultTestLoader.discover(str(root / 'python/tests'), pattern=pattern))
result = unittest.TextTestRunner(verbosity=2).run(suite)
passed = result.wasSuccessful() and not result.skipped
record = dict(status='passed' if passed else 'failed', tests=result.testsRun,
              failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
              package=sl.__file__, isolated=True, repository_source_path=False)
example = runpy.run_path(str(root / 'examples/paid-orders/context-result.py'))
for transport in (None, 'subprocess'):
    completed = example['reuse_completed_result'](transport)
    assert completed.to_rows() == ({'id': 1}, {'id': 3})
    assert not completed.fallback_attempted and not completed.external_engine_invoked
record['development_example'] = ['default_native', 'explicit_process']
output.write_text(json.dumps(record, indent=2) + '\\n')
raise SystemExit(0 if passed else 1)
'''
subprocess.run([python, '-I', '-c', program, ROOT, report],
               cwd=OUT, env=env, check=True)
