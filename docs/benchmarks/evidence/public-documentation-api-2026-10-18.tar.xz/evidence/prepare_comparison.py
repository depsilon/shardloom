"""Freeze the two source/artifact identities and restore the baseline wheel."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
ROOTS = {
    'prior': Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo'),
    'current': Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo'),
}
env = {key: value for key, value in os.environ.items()
       if key not in {'PYTHONPATH', 'PYTHONHOME'} and not key.startswith('SHARDLOOM_')}
manifest = {'publication_attempted': False, 'sources': {}}
for name, root in ROOTS.items():
    proof_dir = OUT / f'wheel-{name}-715'
    proof = json.loads((proof_dir / 'report.json').read_text())
    assert proof['status'] == 'passed'
    paths = subprocess.check_output(['git', 'ls-files', '-co', '--exclude-standard', '-z'], cwd=root).decode().split('\0')
    selected = {path for path in paths if path and (
        path in {'Cargo.toml', 'Cargo.lock', 'python/pyproject.toml'} or
        (path.startswith('shardloom-') and Path(path).suffix in {'.rs', '.toml'}) or
        (path.startswith('python/src/') and Path(path).suffix in {'.py', '.pyi'}))}
    hashes = {path: hashlib.sha256((root / path).read_bytes()).hexdigest() for path in sorted(selected)}
    status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True)
    if name == 'prior':
        assert not status.strip(), status
    manifest['sources'][name] = {
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
        'uncommitted_implementation': name == 'current',
        'inputs': hashes, 'wheel': proof['integrity'],
        'installed_binding_tests': proof['integration'],
    }
    if name == 'prior':
        wheel = proof_dir / 'dist' / proof['integrity']['wheel']
        subprocess.run([proof_dir / 'venv/bin/python', '-I', '-m', 'pip', 'install',
                        '--no-index', '--no-deps', wheel], cwd=OUT, env=env, check=True)
assert manifest['sources']['prior']['wheel']['cli_sha256'] != manifest['sources']['current']['wheel']['cli_sha256']
assert manifest['sources']['prior']['wheel']['native_library_sha256'] != manifest['sources']['current']['wheel']['native_library_sha256']
manifest['baseline_build_correction'] = {
    'discarded_attempt': 'prior-artifacts',
    'reason': 'shared target returned current artifact as fresh; no measured samples used it',
    'correction': 'refreshed baseline CLI source mtimes without content changes and rebuilt both artifacts',
    'accepted_cli_build': 'prior-cli-build-715a2.json',
    'accepted_native_build': 'prior-native-build-715a2.json',
    'baseline_new_audience_option_exit_code': 2,
}
with (OUT / 'comparison-source-identity-715.json').open('x') as stream:
    json.dump(manifest, stream, indent=2)
    stream.write('\n')
