"""Clean installation and actual paid-order values from the selected release."""
import json
import os
from pathlib import Path
import subprocess
import sys

out = Path(__file__).resolve().parent
environment = out / 'published-0.6.0'
assert not environment.exists(), 'use a fresh attempt directory'
env = {k: v for k, v in os.environ.items()
       if k != 'PYTHONPATH' and not k.startswith('SHARDLOOM_')}
env['PYTHONDONTWRITEBYTECODE'] = '1'
subprocess.run([sys.executable, '-m', 'venv', str(environment)], env=env, check=True)
python = environment / 'bin/python'
subprocess.run([str(python), '-m', 'pip', 'install', '--no-cache-dir', '--no-deps',
                '--only-binary=:all:', '--index-url', 'https://pypi.org/simple',
                '--report', str(out / 'published-install-report.json'),
                'shardloom==0.6.0'], env=env, cwd=out, check=True)
subprocess.run([str(python), str(out / 'probe_published.py')], env=env, cwd=out, check=True)
