"""Freeze local acceptance evidence and verify every archived member."""
import hashlib
import json
import lzma
from pathlib import Path
import shutil
import subprocess
import tarfile
import zipfile

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
BASE = 'c87f893483ce8c985c4aa27da792bb4e1ed64062'
IMPLEMENTATION = 'dba85f1c43aeb83a2640c81654ac2b9ce8b15d98'
NAME = 'public-documentation-api-2026-10-18'
DEST = OUT / 'packet-716'
DEST.mkdir(exist_ok=False)

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

def read(name):
    return json.loads((OUT / name).read_text())

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == IMPLEMENTATION
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
identities = read('comparison-source-identity-715.json')
comparison = read('workflow-comparison-715a2/report.json')
assert comparison['status'] == 'passed' and len(comparison['samples']) == 80
for sample in comparison['samples']:
    assert sample['status'] == 'passed'
    assert sample['engine_execution_seconds'] is None
    assert sample['fallback_attempted'] is False and sample['external_engine_invoked'] is False
inputs = identities['sources']['current']['inputs']
current_inputs = {name: digest(ROOT / name) for name in inputs}
changed = [name for name in inputs if inputs[name] != current_inputs[name]]
assert changed == ['shardloom-cli/tests/public_discovery.rs'], changed
docs_before = read('docs-generation-pass-1-715c.json')
assert docs_before == read('docs-generation-pass-2-715c.json')
docs_after = {name: digest(ROOT / name) for name in docs_before}
doc_changes = [name for name in docs_before if docs_before[name] != docs_after[name]]
assert doc_changes == ['docs/getting-started/source-checkout-install.md'], doc_changes
assert not any(name.startswith('website/') for name in doc_changes)

wheel_identity = {}
for label, artifact_dir in [('current', 'current-artifacts'), ('prior', 'prior-artifacts-corrected-715')]:
    proof = read(f'wheel-{label}-715/report.json')
    integrity = proof['integrity']
    wheel = OUT / f'wheel-{label}-715/dist' / integrity['wheel']
    assert digest(wheel) == integrity['wheel_sha256']
    assert digest(OUT / artifact_dir / 'shardloom') == integrity['cli_sha256']
    assert digest(OUT / artifact_dir / '_native.abi3.so') == integrity['native_library_sha256']
    wheel_identity[label] = {key: integrity[key] for key in ['wheel', 'wheel_sha256', 'wheel_bytes', 'cli_sha256', 'native_library_sha256']}
    if label == 'current':
        matches = []
        with zipfile.ZipFile(wheel) as archive:
            for member in archive.namelist():
                if member.startswith('shardloom/') and member.endswith(('.py', '.pyi')):
                    assert archive.read(member) == (ROOT / 'python/src' / member).read_bytes(), member
                    matches.append(member)
        wheel_identity[label]['python_files_matching_final_source'] = matches

closeout = ['docs/architecture/public-documentation-api-acceptance-2026-10-18.md',
            'docs/architecture/public-documentation-and-api-consolidation.md',
            'docs/architecture/phased-execution-plan.md',
            'docs/architecture/phased-execution-completed-ledger.md',
            'docs/getting-started/source-checkout-install.md']
bridge = {
    'schema_version': 'shardloom.public_documentation_api_source_bridge.v1',
    'status': 'passed', 'base': BASE, 'implementation_commit': IMPLEMENTATION,
    'current_comparison_input_count': len(inputs),
    'identical_current_input_count': len(inputs) - len(changed),
    'comparison_to_final_changes': [{'path': name, 'before': inputs[name], 'after': current_inputs[name],
        'scope': 'test assertion only; final Clippy and workspace tests passed'} for name in changed],
    'current_final_inputs': current_inputs,
    'generation_pass_identical_file_count': len(docs_before),
    'generation_to_final_changes': [{'path': name, 'before': docs_before[name], 'after': docs_after[name],
        'scope': 'authored source-checkout example link; generated website unchanged'} for name in doc_changes],
    'final_website_matches_generation': True,
    'closeout_document_hashes': {name: digest(ROOT / name) for name in closeout},
    'artifacts': wheel_identity,
    'publication_attempted': False,
}
(OUT / 'final-source-bridge-716.json').write_text(json.dumps(bridge, indent=2) + '\n')
(OUT / 'implementation-716.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary', BASE, IMPLEMENTATION], cwd=ROOT))
(OUT / 'closeout-documents-716.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary', IMPLEMENTATION], cwd=ROOT))

members = {}
for path in sorted(OUT.iterdir()):
    if path.is_file() and path.suffix in {'.py', '.json', '.log', '.txt', '.md', '.html', '.sh', '.patch'}:
        members['evidence/' + path.name] = path
for name in ['workflow-comparison-715a1', 'workflow-comparison-715a2', 'ui-715', 'final-checks-716', 'final-checks-716b']:
    for path in sorted((OUT / name).rglob('*')):
        if path.is_file():
            assert not path.is_symlink()
            members['evidence/' + str(path.relative_to(OUT))] = path
for name in ['wheel-current-715', 'wheel-prior-715']:
    for path in sorted((OUT / name).iterdir()):
        if path.is_file() and path.suffix in {'.json', '.log'}:
            members['evidence/' + str(path.relative_to(OUT))] = path
probe = OUT / 'prior-artifacts-corrected-715/registry-baseline-check.json'
members['evidence/prior-artifacts-corrected-715/registry-baseline-check.json'] = probe
changed_paths = subprocess.check_output(['git', 'diff', '--name-only', BASE, IMPLEMENTATION], cwd=ROOT, text=True).splitlines()
for name in sorted(set(changed_paths + closeout)):
    path = ROOT / name
    if path.is_file():
        assert not path.is_symlink()
        members['source/' + name] = path
support = {
    'bounded_build_process_resume_20260912.py': Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py'),
    'release_validation_guard.py': Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'),
    'local_uat_storage.py': ROOT / 'scripts/local_uat_storage.py',
}
for name, path in support.items():
    members['support/' + name] = path
manifest = [{'name': name, 'bytes': path.stat().st_size, 'sha256': digest(path)} for name, path in sorted(members.items())]
raw_bytes = sum(item['bytes'] for item in manifest)
assert raw_bytes < 192 << 20, raw_bytes
archive_path = DEST / (NAME + '.tar.xz')
with tarfile.open(archive_path, 'w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
    for item in manifest:
        path = members[item['name']]
        info = tarfile.TarInfo(item['name'])
        info.size = item['bytes']
        info.mode = 0o644
        info.mtime = 0
        with path.open('rb') as stream:
            archive.addfile(info, stream)
verified = []
by_name = {item['name']: item for item in manifest}
with tarfile.open(archive_path, 'r:xz') as archive:
    for member in archive:
        assert member.isfile() and member.name in by_name
        entry = by_name[member.name]
        content = archive.extractfile(member).read()
        assert len(content) == entry['bytes'] and hashlib.sha256(content).hexdigest() == entry['sha256']
        assert digest(members[member.name]) == entry['sha256'], 'source changed during archive'
        verified.append(member.name)
assert len(verified) == len(manifest) and len(set(verified)) == len(manifest)
manifest_path = DEST / (NAME + '.manifest.json.xz')
manifest_path.write_bytes(lzma.compress((json.dumps(manifest, indent=2) + '\n').encode()))
assert json.loads(lzma.decompress(manifest_path.read_bytes())) == manifest
index = {
    'schema_version': 'shardloom.public_documentation_api_acceptance.v1',
    'status': 'passed_local_scope',
    'base': BASE, 'implementation_commit': IMPLEMENTATION,
    'acceptance': '../../architecture/public-documentation-api-acceptance-2026-10-18.md',
    'archive': {'file': archive_path.name, 'bytes': archive_path.stat().st_size, 'sha256': digest(archive_path)},
    'manifest': {'file': manifest_path.name, 'bytes': manifest_path.stat().st_size, 'sha256': digest(manifest_path)},
    'member_count': len(manifest), 'uncompressed_bytes': raw_bytes, 'all_members_reopened': True,
    'source_bridge': 'evidence/final-source-bridge-716.json',
    'evidence_inventory': 'evidence/acceptance-evidence-index-716.md',
    'final_check_receipts': [
        'evidence/rust-fmt-716a2.json', 'evidence/rust-clippy-715a3.json', 'evidence/rust-tests-716a1.json',
        'evidence/native-feature-checks-714a1.json', 'evidence/native-feature-clippy-715a1.json',
        'evidence/python-all-tests-715a1.json', 'evidence/wheel-current-715/report.json',
        'evidence/wheel-prior-715/report.json', 'evidence/installed-minimal-public-715.json',
        'evidence/published-examples-709a3.json', 'evidence/docs-generation-checks-715a3.json',
        'evidence/final-checks-716b/report.json', 'evidence/ui-715/qa.json',
        'evidence/ui-715/development-final-716.json', 'evidence/workflow-comparison-715a2/report.json'],
    'full_workflow_samples': 80, 'full_workflow_values_and_schemas': 'passed',
    'engine_execution_seconds': None,
    'clock_scope': 'Unavailable engine clocks remain null; separately labeled workflow diagnostics are archived, not claimed as engine performance.',
    'publication_attempted': False, 'deployment_attempted': False,
    'version_changed': False, 'kernel_speedup_claim': False,
    'platform_scope': 'Actual local macOS arm64 Python 3.12 native/process runtime; hosted Linux/Windows acceptance remains open.',
    'limitations': [
        'Full Python suite: 829 discovered, 6 skips (3 optional integrations and 3 installed-only tests covered separately).',
        'Fish syntax check unavailable; Rust executable tests verify generated text/JSON and audience agreement.',
        'Standalone release-boundary gate failed closed on absent source-rehearsal/package-channel reports; no release readiness claimed.',
        'Architecture tracker stays blocked by 72 unchecked owner/substep items.',
        'Process batch pipes require POSIX; Windows uses bounded collection and writers.',
        'Rejected baseline-cache and nullability-comparison attempts remain diagnostic-only.'],
    'omitted_bulk_artifacts': 'Native binaries, wheel archives and environments are retained locally with SHA-256 identities; this portable packet retains source, reports, exact comparison results and small synthetic Vortex outputs.',
    'artifacts': wheel_identity,
}
index_path = DEST / (NAME + '.json')
index_path.write_text(json.dumps(index, indent=2) + '\n')
repository_destination = ROOT / 'docs/benchmarks/evidence'
for path in [archive_path, manifest_path, index_path]:
    assert path.stat().st_size < 24 << 20
    target = repository_destination / path.name
    assert not target.exists()
    shutil.copyfile(path, target)
    assert digest(target) == digest(path)
shot = OUT / 'ui-715/guide-desktop.jpg'
target = repository_destination / (NAME + '-desktop.jpg')
assert not target.exists()
shutil.copyfile(shot, target)
assert digest(shot) == digest(target)
print(json.dumps({'status': 'passed', 'member_count': len(manifest), 'archive_bytes': archive_path.stat().st_size,
                  'all_members_reopened': True, 'current_python_files_matched': len(wheel_identity['current']['python_files_matching_final_source'])}), flush=True)
