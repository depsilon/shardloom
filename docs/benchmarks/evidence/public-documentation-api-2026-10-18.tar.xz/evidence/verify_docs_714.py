"""Run existing documentation generators and checks; retain two-pass identities."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent

def run(command, cwd=ROOT):
    subprocess.run(command, cwd=cwd, check=True)

def snapshot():
    paths = [ROOT / 'README.md', ROOT / 'python/README.md']
    for directory in ('website', 'website-public', 'website-src/src/content',
                      'website-src/src/data', 'docs/getting-started', 'docs/use-cases/generated'):
        paths.extend(p for p in (ROOT / directory).rglob('*') if p.is_file())
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(set(paths))}

snapshots = []
for iteration in (1, 2):
    run([sys.executable, 'scripts/write_v1_supported_unsupported_docs.py'])
    run(['node', 'scripts/prebuild-static.mjs', '--reset-output'], ROOT / 'website-src')
    run(['node', 'scripts/sync-content.mjs'], ROOT / 'website-src')
    run(['node', 'node_modules/.bin/astro', 'build'], ROOT / 'website-src')
    run(['node', 'scripts/postbuild-static.mjs'], ROOT / 'website-src')
    snapshots.append(snapshot())
    (OUT / f'docs-generation-pass-{iteration}-714.json').write_text(json.dumps(snapshots[-1], indent=2) + '\n')
if snapshots[0] != snapshots[1]:
    changed = [p for p in sorted(set(snapshots[0]) | set(snapshots[1])) if snapshots[0].get(p) != snapshots[1].get(p)]
    raise AssertionError(f'Generation not stable: {changed}')
print(f'Two generation passes identical: {len(snapshots[0])} files.')
run(['node', 'scripts/validate_static_assets.cjs'])
run([sys.executable, 'scripts/check_website_readiness.py', '--output', str(OUT / 'website-readiness-714.json')])
run([sys.executable, 'scripts/check_public_status_docs.py', '--output', str(OUT / 'public-status-docs-714.json')])
run([sys.executable, 'scripts/check_v1_docs_productization.py', '--output', str(OUT / 'docs-contract-714.json')])
run([sys.executable, '-m', 'unittest', 'python.tests.test_release_scripts', 'python.tests.test_public_quickstart'])
run([sys.executable, '-m', 'unittest', 'discover', '-s', 'scripts', '-p', 'test_website_links.py'])
