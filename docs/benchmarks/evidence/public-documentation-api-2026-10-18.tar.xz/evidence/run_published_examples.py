import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
PYTHON = OUT / 'published-0.6.0/bin/python'
NODE = Path('/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node')
env = {k: v for k, v in os.environ.items() if k not in ('PYTHONPATH', 'PYTHONHOME') and not k.startswith('SHARDLOOM_')}
env.update(SHARDLOOM_TEST_INSTALLED_QUICKSTART='1', SHARDLOOM_TEST_PACKAGE_VERSION='0.6.0')
subprocess.run([str(PYTHON), str(ROOT / 'python/tests/test_public_quickstart.py'), '-v'], cwd=OUT, env=env, check=True)
code = subprocess.check_output([str(NODE), '--input-type=module', '-e',
    "import {cliExample} from './src/data/quickstart.mjs'; process.stdout.write(cliExample)"],
    cwd=ROOT / 'website-src', env=env, text=True)
(OUT / 'published-cli-quickstart.sh').write_text(code + '\n')
bins = list((OUT / 'published-0.6.0/lib').glob('python*/site-packages/shardloom/bin/*/shardloom'))
assert len(bins) == 1
env['PATH'] = str(bins[0].parent) + os.pathsep + env['PATH']
completed = subprocess.run(['/bin/sh', '-c', code], cwd=OUT, env=env,
    check=False, text=True, capture_output=True, timeout=120)
if completed.returncode:
    print(completed.stdout, completed.stderr)
    raise RuntimeError(f'CLI example failed: {completed.returncode}')
payload = json.loads(completed.stdout)
(OUT / 'published-cli-quickstart-result.json').write_text(json.dumps(payload, indent=2) + '\n')
fields = {}
for part in (payload, *(payload.get(name, {}) for name in ('result', 'policy', 'lifecycle', 'capability_snapshot'))):
    fields.update({field['key']: field['value'] for field in part.get('fields', [])})
print(json.dumps({'status': payload.get('status'), 'result_fields': {k: v for k, v in fields.items() if k in ('result_jsonl', 'result_values_json', 'result_schema_json', 'fallback_attempted', 'external_engine_invoked')}}, indent=2))
if 'result_values_json' in fields:
    rows = json.loads(fields['result_values_json'])
else:
    rows = [json.loads(line) for line in fields['result_jsonl'].splitlines()]
assert rows == [{'order_id': 1, 'status': 'paid'}, {'order_id': 3, 'status': 'paid'}]
assert fields['fallback_attempted'] == fields['external_engine_invoked'] == 'false'
assert payload['status'] == 'success'
print('Installed Python/DataFrame, SQL, write/reopen and exact CLI example passed.')
