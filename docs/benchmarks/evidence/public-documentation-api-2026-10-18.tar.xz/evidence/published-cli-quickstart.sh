workspace="$(mktemp -d)"
trap 'rm -rf "$workspace"' EXIT
printf '%s' 'order_id,status
1,paid
2,pending
3,paid
' > "$workspace/orders.csv"
shardloom run sql --input "$workspace/orders.csv" \
  --sql "SELECT order_id, status FROM '$workspace/orders.csv' WHERE status = 'paid' ORDER BY order_id" \
  --request collect --bounded true --memory-bytes 268435456 --max-parallelism 2 --format json
