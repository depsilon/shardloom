const fs = require("fs");
const path = require("path");

const repoRoot = path.resolve(__dirname, "..");
const root = path.join(repoRoot, "website");
const cloudflareStaticAssetMaxBytes = 25 * 1024 * 1024;

const requiredFiles = [
  "index.html",
  "about.html",
  "about/index.html",
  "start.html",
  "start/index.html",
  "field-guide.html",
  "field-guide/index.html",
  "field-guide/start-local-proof/index.html",
  "field-guide/python-surface/index.html",
  "field-guide/runtime-and-io/index.html",
  "field-guide/benchmark-methodology/index.html",
  "field-guide/limitations/index.html",
  ...["sql", "cli", "resources", "reference", "embedding", "troubleshooting", "development"].map((slug) => `field-guide/${slug}/index.html`),
  "field-guide/execution-model/index.html",
  "field-guide/compute-flow/index.html",
  "field-guide/execution-routes/index.html",
  "benchmarks.html",
  "benchmarks/index.html",
  "compute-engine-flow.html",
  "compute-engine-flow/index.html",
  "404.html",
  "robots.txt",
  "sitemap.xml",
  "_headers",
  "_redirects",
  "assets/site.css",
  "assets/parallax-home.css",
  "assets/parallax-home.js",
  "assets/logo/shardloom-mark.svg",
  "assets/data/compute-engine-flow-reference.md",
  "pagefind/pagefind-entry.json",
];

const removedWebsiteSurfaces = [
  "validate_static_assets.js",
  "assets/site.js",
  "assets/logo/shardloom-favicon.png",
  "assets/logo/shardloom-logo.png",
  "assets/logo/shardloom-logo-trim.png",
  "architecture.html",
  "architecture/index.html",
  "docs.html",
  "docs/index.html",
  "status.html",
  "status/index.html",
  "use-cases.html",
  "use-cases/index.html",
];

const forbiddenRuntimeText = [
  "raw.githubusercontent.com",

];
const statusVocabulary = new Set([
  "runtime_supported",
  "global_runtime_supported",
  "smoke_supported",
  "internal_smoke_only",
  "fixture_smoke_only",
  "ready_local",
  "report_only",
  "planned",
  "blocked",
  "unsupported",
  "not_planned",
  "executable",
  "feature_gated",
  "diagnostic_only",
  "claim_grade",
  "not_claim_grade",
  "external_baseline_only",
  "local_equivalence_evidence_present_claim_gated",
  "claim_blocked",
  "claim_allowed",
  "future",
  "current",
  "not reported",
  "stale_or_dirty",
  "stale or dirty",
  "optimization_ready",
  "not_optimization_ready",
]);

function assert(condition, message) {
  if (!condition) {
    throw new Error(message);
  }
}

function exists(relativePath) {
  return fs.existsSync(path.join(root, relativePath));
}

function read(relativePath) {
  return fs.readFileSync(path.join(root, relativePath), "utf8");
}

function collectFiles(directory, prefix = "") {
  const entries = fs.readdirSync(directory, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const relativePath = path.join(prefix, entry.name).replace(/\\/g, "/");
    const absolutePath = path.join(directory, entry.name);
    if (entry.isDirectory()) {
      files.push(...collectFiles(absolutePath, relativePath));
    } else {
      files.push(relativePath);
    }
  }
  return files;
}

function collectDuplicateSuffixedArtifacts(directory, prefix = "") {
  const entries = fs.readdirSync(directory, { withFileTypes: true });
  const duplicates = [];
  for (const entry of entries) {
    const relativePath = path.join(prefix, entry.name).replace(/\\/g, "/");
    const absolutePath = path.join(directory, entry.name);
    if (/ \d+(?:\.[^.]+)?$/.test(entry.name)) {
      duplicates.push(relativePath);
      continue;
    }
    if (entry.isDirectory()) {
      duplicates.push(...collectDuplicateSuffixedArtifacts(absolutePath, relativePath));
    }
  }
  return duplicates;
}

for (const file of requiredFiles) {
  assert(exists(file), `Missing required website file: ${file}`);
}
for (const file of removedWebsiteSurfaces) {
  assert(!exists(file), `Removed website surface still exists: ${file}`);
}
for (const route of ["about", "start", "field-guide", "benchmarks", "compute-engine-flow"]) {
  assert(
    read(`${route}.html`) === read(`${route}/index.html`),
    `${route}.html must be identical to the current canonical page; legacy content must not reappear`,
  );
}
for (const [legacy, current] of [
  ["benchmarks", "field-guide/benchmark-methodology"],
  ["compute-engine-flow", "field-guide/compute-flow"],
]) {
  assert(read(`${legacy}/index.html`) === read(`${current}/index.html`), `${legacy} must serve the current Field Guide content`);
}
for (const file of collectFiles(root)) {
  const size = fs.statSync(path.join(root, file)).size;
  assert(
    size <= cloudflareStaticAssetMaxBytes,
    `Cloudflare Workers static asset exceeds 25 MiB: ${file} (${size} bytes)`,
  );
}
const duplicateSuffixedArtifacts = collectDuplicateSuffixedArtifacts(root);
assert(
  duplicateSuffixedArtifacts.length === 0,
  `Duplicate-suffixed generated website artifacts remain: ${duplicateSuffixedArtifacts.join(", ")}`,
);

const canonicalFlow = fs
  .readFileSync(path.join(repoRoot, "docs/architecture/compute-engine-flow-reference.md"), "utf8")
  .replace(/\r\n/g, "\n");
const websiteFlow = read("assets/data/compute-engine-flow-reference.md").replace(/\r\n/g, "\n");
assert(
  canonicalFlow === websiteFlow,
  "assets/data/compute-engine-flow-reference.md must match docs/architecture/compute-engine-flow-reference.md",
);

const wranglerToml = fs.readFileSync(path.join(repoRoot, "wrangler.toml"), "utf8");
assert(
  /\[assets\][\s\S]*directory\s*=\s*["']\.\/website["']/.test(wranglerToml),
  'wrangler.toml must serve static assets from "./website"',
);

const runtimeFiles = collectFiles(root).filter((file) =>
  [".html", ".css", ".js", ".xml", ".txt"].includes(path.extname(file)) ||
  ["_headers", "_redirects"].includes(file),
);
for (const file of runtimeFiles) {
  const content = read(file);
  for (const forbidden of forbiddenRuntimeText) {
    assert(!content.includes(forbidden), `Runtime file still contains ${forbidden}: ${file}`);
  }
}

const htmlFiles = [
  "index.html",
  "about.html",
  "field-guide.html",
  "field-guide/start-local-proof/index.html",
  "field-guide/python-surface/index.html",
  "field-guide/benchmark-methodology/index.html",
  "field-guide/limitations/index.html",
  "field-guide/execution-model/index.html",
  "benchmarks.html",
  "benchmarks/index.html",
  "compute-engine-flow.html",
  "compute-engine-flow/index.html",
  "404.html",
];
for (const file of htmlFiles) {
  const content = read(file);
  assert(content.includes('/assets/logo/shardloom-mark.svg'), `${file} must use favicon asset`);
  if (file === "index.html") {
    assert(content.includes('/assets/parallax-home.css'), `${file} must use parallax homepage CSS`);
    assert(content.includes('/assets/parallax-home.js'), `${file} must use parallax homepage JS`);
  } else if (["about.html"].includes(file)) {
    assert(content.includes('/assets/site.css'), `${file} must use shared CSS`);
  }
  assert(content.includes('<link rel="canonical"'), `${file} must include canonical URL`);
  assert(content.includes('property="og:title"'), `${file} must include OG metadata`);
}
for (const file of collectFiles(root).filter((candidate) => candidate.endsWith(".html"))) {
  const content = read(file);
  if (["start.html", "start/index.html"].includes(file)) {
    assert(content.includes('content="0;url=/field-guide/start-local-proof"'), `${file} must redirect to the canonical first workflow`);
    assert(content.includes('content="noindex"'), `${file} redirect must not enter search`);
    assert(content.includes('rel="canonical" href="https://shardloom.io/field-guide/start-local-proof"'), `${file} must canonicalize to the guide`);
    continue;
  }
  for (const stale of [
    "Start from a source checkout, not a package-publication claim",
    "package publication readiness",
    "data-route-timing-surface-dashboard",
  ]) {
    assert(!content.includes(stale), `${file} contains retired public content: ${stale}`);
  }
  const isStarlight = content.includes("Starlight v") || content.includes("starlight__sidebar");
  assert(/<html\b[^>]*\blang="en"/.test(content), `${file} must declare language`);
  assert(/<title>[^<]+<\/title>/.test(content), `${file} must include a document title`);
  assert(/<meta name="viewport" content="width=device-width, initial-scale=1"/.test(content), `${file} must include responsive viewport metadata`);
  assert(/<meta name="description" content="[^"]+"/.test(content), `${file} must include meta description`);
  assert((content.match(/<h1[ >]/g) || []).length === 1, `${file} must include exactly one h1`);
  if (!isStarlight) {
    assert(!content.includes("<details open"), `${file} must keep drawers collapsed by default`);
  }
  for (const image of content.match(/<img\b[^>]*>/g) || []) {
    assert(/\salt=/.test(image), `${file} image missing alt text: ${image}`);
    assert(/\swidth="\d+"/.test(image), `${file} image missing stable width: ${image}`);
    assert(/\sheight="\d+"/.test(image), `${file} image missing stable height: ${image}`);
  }
  for (const match of content.matchAll(/<span class="status-chip[^"]*">([^<]+)<\/span>/g)) {
    assert(statusVocabulary.has(match[1]), `${file} has unexpected status chip text: ${match[1]}`);
  }
}

const css = read("assets/site.css");
for (const required of [
  ":focus-visible",
  "input:focus-visible",
  "@media (prefers-reduced-motion: reduce)",
  ".status-chip",
  ".filter-count",
]) {
  assert(css.includes(required), `site CSS missing ${required}`);
}

const index = read("index.html");
assert(
  index.includes('MAKE<span class="luminous">LESS WORK.</span>'),
  "home page hero must preserve the parallax source-of-truth headline",
);
assert(
  index.includes("The fastest work<br>is work you <span class=\"soft\">never do.</span>"),
  "home page must preserve the work-avoidance scroll chapter",
);
for (const required of [
  "Vortex isn't another format on a list.",
  "Capillary<br>work units",
  "PulseWeave",
  "Single artifact / internal structure",
  "No secret<br><span class=\"soft\">plan B.</span>",
  "fallback_attempted",
  "external_engine_invoked",
  "python -m pip install shardloom",
  "Interactive architectural illustrations, not runtime telemetry or benchmark claims.",
  'data-scene="orbital"',
  'data-scene="avoid"',
  'data-scene="plates"',
  'data-scene="loom"',
  'data-scene="pulse"',
  'data-scene="artifact"',
  'data-scene="horizon"',
  'id="motionToggle"',
  'id="copyInstall"',
]) {
  assert(index.includes(required), `parallax home page missing ${required}`);
}
assert(index.includes("View on GitHub"), "home page must link to GitHub");
for (const route of ["/start", "/about", "/field-guide", "/field-guide/benchmark-methodology"]) {
  assert(index.includes(`href="${route}"`), `home page must expose current ${route} navigation`);
}

const benchmarks = read("benchmarks.html");
for (const required of [
  "ClickBench",
  "Open ClickBench",
  "https://benchmark.clickhouse.com/",
  "Current engineering evidence",
  "What a timing includes",
  "performance_claim_allowed=false",
]) {
  assert(benchmarks.includes(required), `benchmarks page missing ${required}`);
}
assert(
  !benchmarks.includes("data-route-timing-surface-dashboard"),
  "benchmarks page must not render the retired internal dashboard",
);

const flow = read("compute-engine-flow.html");
for (const required of [
  "shardloom-compute-flow",
  'id="flow-group"',
  'id="flow-count"',
  'id="flow-topk"',
  "Metadata count",
  "Late payload gathering",
  "PulseWeave",
  "Conceptual illustrations",
  "fallback_attempted=false",
]) {
  assert(flow.includes(required), `compute-flow page missing ${required}`);
}

const fieldGuide = read("field-guide.html");
for (const required of [
  "Read data, transform or query it, and deliver the result through one Vortex-native pipeline.",
  "Get started",
  "Execution model",
  "Data lifecycle",
  "Application reference",
]) {
  assert(fieldGuide.includes(required), `field guide missing ${required}`);
}

const guideData = JSON.parse(fs.readFileSync(path.join(repoRoot, "website-src/src/data/public-guide.json"), "utf8"));
const startLocalProof = read("field-guide/start-local-proof/index.html");
for (const required of [
  `Published ${guideData.release.version}`,
  'id="read-and-collect"', 'id="write-and-reopen"',
  'href="/field-guide/troubleshooting"', 'data-pagefind-body',
  "order_id", "paid", "python_objects",
]) {
  assert(startLocalProof.includes(required), `first workflow doc missing ${required}`);
}
const pythonSurface = read("field-guide/python-surface/index.html");
for (const required of [
  'href="/field-guide/start-local-proof"', 'id="consume-results"',
  "result.result_schema", "result.python_objects", "result.envelope",
]) {
  assert(pythonSurface.includes(required), `Python task guide missing ${required}`);
}
assert(!read("field-guide/development/index.html").includes("data-pagefind-body"),
  "development material must stay out of the product search body");

const benchmarkMethodology = read("field-guide/benchmark-methodology/index.html");
for (const required of [
  "Benchmarks",
  "hot_runtime",
  "publication_proof",
  "external_baseline",
]) {
  assert(benchmarkMethodology.includes(required), `benchmark methodology doc missing ${required}`);
}

const limitations = read("field-guide/limitations/index.html");
for (const required of [
  `Published ${guideData.release.version}`, "Known issues",
  'href="/field-guide/troubleshooting"', "Package requirements", "Restrictions",
]) {
  assert(limitations.includes(required), `version-scoped capabilities missing ${required}`);
}

const redirects = read("_redirects");
const redirectTargets = new Map(
  redirects.split("\n").filter((line) => line.trim().startsWith("/")).map((line) => line.trim().split(/\s+/).slice(0, 2)),
);
for (const [legacy, current] of [
  ["start", "field-guide/start-local-proof"],
  ["benchmarks", "field-guide/benchmark-methodology"],
  ["compute-engine-flow", "field-guide/compute-flow"],
]) {
  for (const suffix of ["", "/", ".html"]) {
    assert(redirectTargets.get(`/${legacy}${suffix}`) === `/${current}`, `${legacy}${suffix} must redirect directly to the Field Guide`);
  }
}
for (const route of ["home", "index", "telemetry", "benchmark", "flow", "compute-flow", "architecture", "use-cases", "can-i-use-this", "status", "docs", "readme"]) {
  assert(
    redirectTargets.get(`/${route}/`) === redirectTargets.get(`/${route}`) && redirectTargets.has(`/${route}/`),
    `legacy /${route}/ must redirect to the same current destination as /${route}`,
  );
}
for (const legacy of [
  "/architecture",
  "/architecture.html",
  "/use-cases",
  "/use-cases.html",
  "/status",
  "/status.html",
  "/docs",
  "/docs.html",
  "/can-i-use-this",
  "/readme",
]) {
  assert(redirects.includes(legacy), `_redirects must preserve legacy route: ${legacy}`);
}

console.log("website static asset validation passed");
