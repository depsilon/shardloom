# CLI Command Registry Status

Schema: `shardloom.command_registry.v1`

Source: `shardloom-cli/src/command_registry.rs`

Report id: `review-p1-1.command_registry`

<!-- BEGIN GENERATED COMMAND COUNTS -->
Registered command count: 203

Application command count: 14

Maintainer command count: 189

Registry source SHA-256: `5528ce05f70e72a10865a633a3efd36ad603d182ecabd68af2369b73e8872156`
<!-- END GENERATED COMMAND COUNTS -->

Support-state vocabulary: executable, feature_gated, diagnostic_only, report_only, blocked, future

User-surface graduation posture vocabulary: high_level_context, public_runtime, client_only,
diagnostic_only, feature_gated, not_user_facing

Agent metadata command: `shardloom command-metadata [command] --format json`

Application discovery: `shardloom command-metadata --audience application --format json`.
Maintainer discovery: `shardloom command-metadata --audience maintainer --format json`.
Human help and `shardloom command-metadata --completion bash|zsh|fish` foreground
application commands. Unfiltered JSON metadata keeps the complete inventory.

Command-specific help command: `shardloom help [command] --format json`

CI work-shaping command: `shardloom ci-work-shaping-plan --format json`

Public workflow facade commands: `shardloom route <sql|python|dataframe|cli> --format json`,
`shardloom run <sql|python|dataframe|cli> --format json`, and
`shardloom prepare <sql|python|dataframe|cli> --format json`

Scoped public helper coverage: `vortex-prepare` local compatibility-source normalization,
Python lazy DataFrame bounded `collect()`, general `write(...)`,
`write_jsonl(...)`, `write_csv(...)`, structured write aliases, generated-source direct writes,
source-free SQL writes, admitted local/generated fanout helpers, explicit native Vortex
primitive collect/local-execution helpers, scoped native Vortex primitive JSONL/CSV row-export
payloads, scoped local distributed fixture execution, and scoped live/hybrid local
checkpoint/changelog fixture execution route through typed envelopes and preserve report views.
Lower smoke/runtime/primitive diagnostic commands and the private Python worker transport remain
non-public diagnostics and benchmark/evidence surfaces, while `route`, `run`, and `prepare` are the
high-level CLI context commands. Future helper families remain deferred until their owning runtime items define explicit
facade payload contracts.

Help aliases: shardloom --help; shardloom -h; shardloom <command> --help

Capability surface: `shardloom capabilities api-surfaces --format json`

Evidence fields: command, family, support_state, user_surface_graduation_posture,
side_effect_level, usage_fragment, feature_gate_status, input_contract, output_contract,
owning_phase_item, claim_boundary, fallback_boundary, fallback_attempted,
external_engine_invoked

Claim boundary: command discoverability, metadata consolidation, and scoped public workflow
admission/execution envelopes only. Broad runtime support and public claims remain governed by
`runs-today`, capability discovery, execution certificates, release gates, and benchmark evidence.

No-fallback status: fallback_attempted=false and external_engine_invoked=false.

This page is a status snippet, not a separate hand-maintained command table. The full per-command
rows are generated from the registry through the CLI metadata and capability surfaces above.
