"""Independently recompute the refreshed lifecycle decisions using the same raw checks."""
import varbin_review_cost_550 as refresh
import verify_varbin_metadata_cost_546 as original

original.D = refresh.c.DEST
original.RESULT = refresh.c.OUT / 'varbin-review-cost-inspection-550.json'

if __name__ == '__main__':
    original.main()
