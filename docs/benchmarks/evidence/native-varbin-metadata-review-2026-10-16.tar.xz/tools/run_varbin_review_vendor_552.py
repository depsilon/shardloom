"""Run all four full provider suites using one fresh copy of the reviewed array."""
import json
import os
from pathlib import Path
import shutil
import subprocess

from freeze_native_release_298 import ROOT, OUT, save, sha, sources
from run_varbin_review_checks_552 import identity, unchanged, SOURCE

DEST = OUT / 'varbin-review-vendor-552'
PROVIDERS = ('vortex-array', 'vortex-fsst', 'vortex-runend', 'vortex-zstd')


def main():
    frozen = unchanged()
    assert not DEST.exists()
    source_files = {}
    for provider in PROVIDERS:
        source = ROOT / 'vendor' / provider
        entries = sorted(source.rglob('*'))
        assert all(not path.is_symlink() and (path.is_file() or path.is_dir()) for path in entries)
        paths = [path for path in entries if path.is_file() and path.name != 'Cargo.lock']
        assert sum(path.stat().st_size for path in paths) < 32 << 20
        source_files[provider] = {path.relative_to(source).as_posix(): sha(path) for path in paths}
        for path in paths:
            destination = DEST / provider / path.relative_to(source)
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, destination)
        shutil.copy2(ROOT / 'Cargo.lock', DEST / provider / 'Cargo.lock')
    lock_sha256 = sha(ROOT / 'Cargo.lock')
    shutil.copy2(ROOT / 'vendor/vortex-array/clippy.toml', DEST / 'clippy.toml')
    clippy_sha256 = sha(DEST / 'clippy.toml')

    def copies_unchanged():
        return (unchanged() == frozen and sha(ROOT / 'Cargo.lock') == lock_sha256
            and sha(DEST / 'clippy.toml') == clippy_sha256 and all(
                sha(ROOT / 'vendor' / provider / name) == digest
                and sha(DEST / provider / name) == digest
                for provider, files in source_files.items() for name, digest in files.items()))

    commands = []
    for provider in PROVIDERS:
        args = ['--offline', '--manifest-path', str(DEST / provider / 'Cargo.toml')]
        if provider == 'vortex-array':
            args += ['--features', '_test-harness,table-display']
        else:
            args += ['--config', 'patch.crates-io.vortex-array.path=' + json.dumps(str(DEST / 'vortex-array')),
                     '--features', 'vortex-array/table-display']
        commands += [
            ['cargo', 'test', *args, '--lib', '--', '--test-threads=2'],
            ['cargo', 'clippy', *args, '--lib', '--', '-D', 'warnings'],
        ]
    save(DEST / 'protocol.json', dict(source=identity(SOURCE), root=str(ROOT), source_files=source_files,
        root_lock_sha256=lock_sha256, commands=commands, helper=identity(__file__),
        clippy_config_sha256=clippy_sha256, environment={'CLIPPY_CONF_DIR': str(DEST)},
        all_eight_commands_fresh=True))
    completed, failure = [], None
    try:
        for command in commands:
            assert copies_unchanged()
            print(json.dumps(dict(command=command)), flush=True)
            subprocess.run(command, cwd=ROOT, check=True,
                env=dict(os.environ, CLIPPY_CONF_DIR=str(DEST)))
            completed.append(command)
        assert copies_unchanged()
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        same = copies_unchanged()
        save(DEST / 'summary.json', dict(status='passed' if failure is None and same else 'failed',
            completed=completed, failure=failure, sources_unchanged=same,
            protocol=identity(DEST / 'protocol.json'), source=identity(SOURCE),
            standalone_locks={provider: identity(DEST / provider / 'Cargo.lock') for provider in PROVIDERS}))
        assert same


if __name__ == '__main__':
    main()
