"""Build current release surfaces and run the declared direct/public acceptance."""
import json
from pathlib import Path
import subprocess
import sys

from freeze_native_release_298 import OUT, ROOT
from run_query_timing_runtime_461 import guarded
from run_varbin_review_acceptance_552 import unchanged, prerequisites

PYTHON = Path('/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3')
ACCEPTANCE = OUT / 'run_varbin_review_acceptance_552.py'


def stage(name, timeout, command):
    unchanged()
    print(json.dumps(dict(stage=name, status='starting')), flush=True)
    guarded(name, timeout, command)
    unchanged()
    print(json.dumps(dict(stage=name, status='passed')), flush=True)


def main():
    assert Path(sys.executable) == PYTHON
    prerequisites()
    stage('native-final-cli-release-build-varbinreview552', 2100,
        ['cargo', 'build', '--offline', '--locked', '--release', '-p', 'shardloom-cli',
         '--features', 'release-user-surfaces', '--message-format=json-render-diagnostics'])
    stage('native-final-python-release-build-varbinreview552', 2100,
        [PYTHON, '-B', ROOT / 'scripts/build_native_python.py', '--release', '--offline',
         '--output-dir', OUT / 'varbin-review-native-binding-552'])
    stage('varbin-review-freeze-native-552', 180,
        [PYTHON, '-B', OUT / 'freeze_native_release_298.py', '--run-id', 'varbinreview552'])
    stage('varbin-review-declarations-552', 180, [PYTHON, '-B', ACCEPTANCE, 'declare'])
    stage('varbin-review-direct-552', 1800,
        [OUT / 'selected-view-python-468/bin/python', '-B', ACCEPTANCE, 'direct'])
    print(json.dumps(dict(stage='public', status='starting')), flush=True)
    subprocess.run([str(PYTHON), '-B', str(ACCEPTANCE), 'public'], cwd=ROOT, check=True)
    unchanged()
    stage('varbin-review-public-inspection-552', 600,
        [PYTHON, '-B', OUT / 'verify_varbin_review_public_552.py'])
    print(json.dumps(dict(status='passed', full43_pending=True)), flush=True)


if __name__ == '__main__':
    main()
