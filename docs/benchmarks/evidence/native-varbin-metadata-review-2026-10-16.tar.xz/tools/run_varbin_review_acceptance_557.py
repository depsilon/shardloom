"""Bind complete public acceptance to the constructor-review revision."""
import argparse
import json
from pathlib import Path
import sys

import run_zstd_metadata_acceptance_533 as common
import varbin_review_cost_557 as lifecycle
from freeze_native_release_298 import ROOT, OUT, save
from run_query_timing_runtime_461 import guarded
from run_varbin_review_checks_557 import unchanged

common.SOURCE = OUT / 'native-release-source-varbinreview557.json'
common.MANIFEST = OUT / 'native-release-artifacts-varbinreview557.json'
common.PROTOCOL = OUT / 'varbin-review-acceptance-protocol-557.json'
common.PRIOR = OUT / 'varbin-metadata-acceptance-protocol-546.json'
common.PRIOR_DIRECT = OUT / 'varbin-metadata-direct-tests-546.json'
common.CHECKS = OUT / 'varbin-review-checks-557.json'
common.COST = OUT / 'varbin-review-cost-557/decision.json'
common.PUBLIC = OUT / 'varbin-review-public-557'
common.DIRECT = OUT / 'varbin-review-direct-tests-557.json'
common.PUBLIC_ACCEPTANCE = OUT / 'varbin-review-public-acceptance-557.json'
common.unchanged = unchanged

SOURCE, MANIFEST, PROTOCOL = common.SOURCE, common.MANIFEST, common.PROTOCOL
PUBLIC, PUBLIC_ACCEPTANCE = common.PUBLIC, common.PUBLIC_ACCEPTANCE
identity, receipt, load, protocol = common.identity, common.receipt, common.load, common.protocol
VENDOR = OUT / 'varbin-review-vendor-inspection-557.json'


def prerequisites():
    frozen = unchanged()
    checks = json.loads(common.CHECKS.read_text())
    assert checks['status'] == 'passed' and checks['source_identity_preserved']
    assert checks['source'] == identity(SOURCE)
    assert [row['stage'] for row in checks['completed']] == [
        'fmt', 'workspace-clippy', 'workspace-tests', 'read-clippy', 'release-clippy', 'native-tests']
    assert identity(checks['protocol']['path']) == checks['protocol']
    check_protocol = json.loads(Path(checks['protocol']['path']).read_text())
    assert check_protocol['all_gates_fresh'] and len(check_protocol['required_tests']) == 25
    for row in checks['completed']:
        assert identity(row['receipt']['path']) == row['receipt']
        assert identity(row['log']['path']) == row['log']
        record = receipt(row['receipt']['path'])
        assert record['head'] == frozen['head'] and not record['working_tree']
    cost = json.loads(common.COST.read_text())
    assert cost['status'] == 'retained_pending_broad_acceptance' and not cost['repeated_breaches']
    assert not cost['performance_claim_allowed']
    lifecycle.v.verify(json.loads(Path(cost['protocol']['path']).read_text()))
    for key in ('protocol', 'forward', 'reverse'):
        if cost[key] is not None:
            assert identity(cost[key]['path']) == cost[key]
    inspection = json.loads((OUT / 'varbin-review-cost-inspection-report-557.json').read_text())
    assert inspection['status'] == 'passed' and inspection['decision'] == identity(common.COST)
    assert inspection['decision_status'] == cost['status'] and not inspection['repeated_breaches']
    vendor = json.loads(VENDOR.read_text())
    assert vendor['status'] == 'passed' and vendor['selected_sources_match_current']
    assert vendor['source'] == identity(SOURCE) and vendor['all_eight_commands_fresh']
    assert vendor['commands_verified'] == 8 and vendor['source_files_verified'] == 841
    for key in ('protocol', 'summary', 'receipt', 'log', 'historical_inventory', 'helper'):
        assert identity(vendor[key]['path']) == vendor[key]
    receipt(vendor['receipt']['path'])
    assert unchanged() == frozen


def declare():
    prerequisites()
    manifest = load()
    prior = json.loads(common.PRIOR.read_text())
    direct = json.loads(common.PRIOR_DIRECT.read_text())
    assert prior['status'] == 'predeclared'
    assert direct['status'] == 'passed' and direct['tests'] == 100
    assert len(direct['test_names']) == len(set(direct['test_names'])) == 100
    sys.path[:0] = [str(ROOT / 'python/src'), str(ROOT / 'scripts')]
    from run_native_streaming_input_uat import FAMILIES
    families, names = prior['expected_public_families'], prior['expected_public_names']
    assert list(FAMILIES) == families and len(families) == 36
    assert len(names) == len(set(names)) == 4827
    assert identity(prior['baseline']['path']) == prior['baseline']
    helpers = [Path(__file__), Path(common.__file__), Path(lifecycle.__file__),
        OUT / 'freeze_native_release_298.py', OUT / 'run_query_timing_runtime_461.py',
        OUT / 'run_guarded.py', OUT / 'run_varbin_review_remaining_557.py',
        OUT / 'verify_varbin_review_public_557.py', OUT / 'verify_stream_dynamic_subquery_public_522.py',
        OUT / 'run_varbin_review_checks_557.py', OUT / 'run_varbin_review_vendor_557.py',
        OUT / 'verify_varbin_review_vendor_557.py']
    save(PROTOCOL, dict(status='predeclared', native_engine_executions=0,
        source=identity(SOURCE), artifacts=identity(MANIFEST), helpers=[identity(p) for p in helpers],
        prior_protocol=identity(common.PRIOR), prior_direct=identity(common.PRIOR_DIRECT),
        expected_direct_tests=100, expected_direct_names=direct['test_names'],
        expected_public_names=names, expected_public_families=families,
        baseline=prior['baseline'], checks=identity(common.CHECKS), cost=identity(common.COST),
        cost_inspection=identity(OUT / 'varbin-review-cost-inspection-report-557.json'),
        vendor=identity(VENDOR),
        contract=identity(ROOT / 'docs/architecture/native-varbin-metadata-resources-2026-10-16.md'),
        performance_claim=False, whole_process_memory_ceiling=False, installed_wheel_proof=False))
    assert load() == manifest
    print(json.dumps(dict(status='predeclared', direct_tests=100, public_cases=4827, families=36)))


def public():
    prerequisites()
    manifest, frozen = load(), protocol()
    direct = json.loads(common.DIRECT.read_text())
    assert direct['status'] == 'passed' and direct['tests'] == 100 and direct['skipped'] == 0
    receipt(OUT / 'varbin-review-direct-557.json')
    assert not PUBLIC.exists()
    families = frozen['expected_public_families']
    guarded('varbin-review-public-557', 7200,
        [sys.executable, '-B', ROOT / 'scripts/run_native_streaming_input_uat.py',
         '--binary', manifest['cli']['path'], '--uat-root', PUBLIC, '--operation-timeout', '600',
         '--compress-logs', '--families', *families])
    receipt(OUT / 'varbin-review-public-557.json')
    summary = json.loads((PUBLIC / 'summary.json').read_text())
    assert summary['status'] == 'passed' and summary['families'] == families and summary['compress_logs']
    assert [row['name'] for row in summary['cases']] == frozen['expected_public_names']
    assert all(row['status'] == 'passed' for row in summary['cases'])
    assert load() == manifest and protocol() == frozen
    save(PUBLIC_ACCEPTANCE, dict(status='passed', cases=4827, families=families,
        manifest=identity(MANIFEST), source=identity(SOURCE), protocol=identity(PROTOCOL),
        summary=identity(PUBLIC / 'summary.json'), direct=identity(common.DIRECT),
        source_identity_preserved=True, full43_pending=True))
    print(json.dumps(dict(status='passed', public_cases=4827, families=36)))


common.prerequisites = prerequisites
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('declare', 'direct', 'public'))
    args = parser.parse_args()
    {'declare': declare, 'direct': common.direct, 'public': public}[args.operation]()
