"""Check the package source-head fix without rerunning engine measurements."""
import copy
import json
from pathlib import Path
import tempfile

import package_varbin_review_562 as package
from varbin_review_fixture_bridge_560 import verify as verify_bridge


def rejected(callback):
    try:
        callback()
    except AssertionError:
        return
    raise AssertionError('an invalid receipt was accepted')


def main():
    source = package.unchanged()
    bridge = verify_bridge()
    current = source['head']
    measured = bridge['source_proof']['measured_commit']
    assert current != measured and bridge['source_proof']['production_sources_unchanged']
    cost_names = [
        'varbin-review-candidate-build-557', 'varbin-review-freeze-build-557',
        'varbin-review-freeze-protocol-557', 'varbin-review-cost-forward-557',
        'varbin-review-cost-decision-557', 'varbin-review-cost-report-check-557',
        'varbin-review-cost-reverse-557',
    ]
    current_names = [
        'native-final-cli-release-build-varbinreview560',
        'native-final-python-release-build-varbinreview560',
        'varbin-review-freeze-native-560', 'varbin-review-declarations-560',
        'varbin-review-direct-560', 'varbin-review-public-560',
        'varbin-review-public-inspection-560', 'varbin-review-full43-560',
        'varbin-review-fixture-source-proof-560',
        'varbin-review-release-script-tests-560', 'varbin-review-vendor-tests-560',
        'varbin-review-vendor-report-check-560',
    ]
    for name in current_names:
        assert package.receipt(package.OUT / (name + '.json'))['head'] == current
    for name in cost_names:
        path = package.OUT / (name + '.json')
        assert package.measured_receipt(path, measured)['head'] == measured
        rejected(lambda: package.measured_receipt(path, current))
    first = package.OUT / (cost_names[0] + '.json')
    rejected(lambda: package.receipt(first))
    sample = package.read(first)
    mutations = {
        'status': 'failed', 'returncode': 1, 'head': current,
        'process_group_drained': False, 'direct_child_reaped': False,
        'timed_out': True, 'group_absence_unproved_at_cleanup': True,
        'log_sha256': '0' * 64,
    }
    # Synthetic negative copies are confined to a disposable local directory;
    # the original measurement records and logs are never modified.
    with tempfile.TemporaryDirectory(prefix='varbin-package-negative-562-', dir=package.OUT) as directory:
        path = Path(directory) / 'receipt.json'
        path.with_suffix('.log').write_bytes(first.with_suffix('.log').read_bytes())
        for key, value in mutations.items():
            altered = copy.deepcopy(sample)
            altered[key] = value
            path.write_text(json.dumps(altered))
            rejected(lambda: package.measured_receipt(path, measured))
    assert package.unchanged() == source and verify_bridge() == bridge
    output = package.OUT / 'varbin-review-package-receipt-review-562.json'
    assert not output.exists()
    package.save(output, dict(status='passed', measured_commit=measured,
        accepted_commit=current, current_receipts_checked=len(current_names),
        measured_receipts_checked=len(cost_names), wrong_commit_refusals=len(cost_names),
        tampered_fields_rejected=list(mutations), original_failure_reproduced=True,
        fixture_bridge=package.identity(package.FIXTURE_BRIDGE),
        current_receipts=[package.identity(package.OUT / (name + '.json')) for name in current_names],
        measured_receipts=[package.identity(package.OUT / (name + '.json')) for name in cost_names],
        original_failed_helper=package.identity(package.OUT / 'package_varbin_review_560.py'),
        corrected_helper=package.identity(package.__file__), helper=package.identity(__file__),
        runtime_sources_changed=False, measurements_rerun=False))
    print(json.dumps(dict(status='passed', current_receipts=12, measured_receipts=7,
        wrong_commit_refusals=7, tampered_fields_rejected=8)))


if __name__ == '__main__':
    main()
