"""Bind the primary's constructor and validated-view review to the frozen sources."""
import json
import subprocess

from freeze_native_release_298 import ROOT, OUT, save
from run_varbin_review_checks_552 import SOURCE, identity, unchanged
from varbin_review_cost_552 import required_tests


def main():
    frozen = unchanged()
    markers = {
        'vendor/vortex-array/src/arrays/varbinview/array.rs': [
            'pub fn try_new_from_buffers(', 'pub fn try_new_handle_in(',
            'pub(crate) unsafe fn try_new_handle_in_unchecked(',
            'pub(crate) unsafe fn from_admitted_handles_unchecked(',
            'fn validate_handle_contents(', 'fn check_handle_shape(',
            'pub(crate) fn validate_and_fix(', 'fn validate_view_with',
            'fn with_views_and_validity(', 'unsafe fn with_views_and_validity_unchecked('],
        'vendor/vortex-array/src/arrays/varbinview/metadata.rs': [
            'pub(crate) struct MetadataReservation', 'pub(crate) fn grow_vec', 'pub(crate) fn into_arc'],
        'vendor/vortex-array/src/arrays/varbinview/build_views.rs': ['VarBinViewArray::try_new_handle_in('],
        'vendor/vortex-array/src/arrays/varbinview/vtable/mod.rs': [
            'VarBinViewData::try_new_handle_in(', 'VarBinViewData::validate_and_fix(',
            'VarBinViewData::try_new_handle_in_unchecked('],
        'vendor/vortex-array/src/arrays/filter/execute/varbinview.rs': ['with_views_and_validity_unchecked('],
        'vendor/vortex-array/src/arrays/varbinview/compute/take.rs': ['with_views_and_validity_unchecked('],
        'vendor/vortex-array/src/arrays/varbinview/compute/slice.rs': ['with_views_and_validity_unchecked('],
        'vendor/vortex-array/src/builders/varbinview.rs': [
            'pub struct AdmittedVarBinViewBuilder', 'pub fn append_array(',
            'pub fn finish(mut self)', 'pub(crate) fn append_varbinview_array('],
        'vendor/vortex-runend/src/compress.rs': ['fn runend_decode_slice', 'pub fn runend_decode_varbinview('],
        'shardloom-vortex/src/native_provider_chunked.rs': [
            'VarBinViewBuilder::with_admitted_buffers(', 'output.with_views_and_validity('],
        'shardloom-vortex/src/native_provider_memory.rs': ['VarBinViewArray::try_new_handle_in('],
        'shardloom-vortex/src/resident_memory_encoded_transfer.rs': [
            'self.provider_metadata_bytes = add(self.provider_metadata_bytes, provider_bytes)?;'],
    }
    bound = []
    for name, needles in markers.items():
        lines = (ROOT / name).read_text().splitlines()
        anchors = {needle: [i + 1 for i, line in enumerate(lines) if needle in line]
                   for needle in needles}
        assert all(anchors.values()), name
        bound.append(dict(source=identity(ROOT / name), anchors=anchors))
    tests = sorted(required_tests())
    assert len(tests) == 25
    test_sources = [identity(ROOT / 'shardloom-vortex/src' / name) for name in (
        'native_provider_varbin_metadata_tests.rs', 'native_provider_varbin_construction_tests.rs',
        'native_provider_varbin_deserialize_tests.rs', 'resident_memory_varbin_transfer_tests.rs')]
    # Ownership integration outside the corrected providers is unchanged from
    # the initial accepted source; that evidence remains historical and explicit.
    old_source = OUT / 'native-release-source-varbinmetadata546c.json'
    old = json.loads(old_source.read_text())
    unchanged_ownership = [
        'vendor/vortex-array/src/arrays/varbinview/metadata.rs',
        'shardloom-vortex/src/native_provider_chunked.rs',
        'shardloom-vortex/src/native_provider_memory.rs',
        'shardloom-vortex/src/resident_memory_encoded_transfer.rs',
        'shardloom-vortex/src/resident_memory_varbin_metadata_cost_tests.rs',
    ]
    assert all(frozen['source_sha256'][p] == old['source_sha256'][p] for p in unchanged_ownership)
    result = dict(status='passed', review_kind='primary_static_review',
        scope='Safe constructor and arbitrary replacement corrections, plus reuse of proven native views. Runtime acceptance is separate and still pending.',
        source_snapshot=identity(SOURCE), head=frozen['head'], helper=identity(__file__),
        reviewed_sources=bound, test_sources=test_sources, required_tests=tests,
        review_comments=identity(OUT / 'varbin-review-comments-549.json'),
        prior_source=identity(old_source), unchanged_ownership_sources=unchanged_ownership,
        corrective_diff=subprocess.check_output(
            ['git', 'diff', '--binary', '27adf4915026e48b50f3f762a899d3b701e30c9b', 'HEAD'],
            cwd=ROOT, text=True),
        contract=identity(ROOT / 'docs/architecture/native-varbin-metadata-resources-2026-10-16.md'),
        rfc=identity(ROOT / 'docs/rfcs/0044-resident-runtime-resource-ownership.md'),
        objections=[
            dict(question='Can safe construction or arbitrary replacement expose malformed values, including null slots or later device-to-host replacement?',
                disposition='Safe handle constructors check dtype, alignment, length, validity, buffer index, checked range, prefix and per-value UTF-8 for every host-readable view. Borrowed-buffer construction validates non-null values and normalizes null slots. Arbitrary replacement checks contents unless the complete host view bytes match the original against the unchanged table. Device contents remain opaque; newly readable host values are checked.',
                tests=['native_varbin_table_safe_constructors_reject_malformed_host_views_and_refund',
                    'native_varbin_table_safe_replacement_rejects_malformed_host_views_and_preserves_owner',
                    'native_varbin_safe_builders_validate_utf8_per_value_and_refund',
                    'native_varbin_device_host_replacement_validates_newly_accessible_values']),
            dict(question='Does avoiding repeated validation introduce an unchecked path for arbitrary values or invalid validity?',
                disposition='Only explicitly unsafe provider helpers skip value checks. Filter, take and slice copy valid source views, nullable take inserts empty views, RunEnd repeats valid views or empty defaults, and the restricted same-dtype host builder rebases complete views into the identical appended payloads. Validated construction and deserialization reuse their exact checked buffers. All helpers retain shape, value-type, nullability, validity-length and checked ArrayParts requirements. Each call carries a safety argument; no raw-pointer operation or workspace unsafe code is added.',
                tests=['native_varbin_table_sharing_survives_native_transformations',
                    'native_varbin_table_rebuild_validates_layout_and_keeps_outer_owner',
                    'native_varbin_table_mask_and_runend_expansion_share_owner_and_values',
                    'native_varbin_builder_many_nullable_utf8_and_binary_leaves']),
            dict(question='Can reuse lose or duplicate table credit, retain producer credit after transfer, or allocate before admission?',
                disposition='Checked admission and requested-capacity accounting remain shared. Selection retains the original table and reservation plus the outer owner. Builder growth/finalization retain old/new overlap admission. Deserialization drops its temporary table before final table admission and selects the receiving allocator. No receiver accounting or raw-export policy is changed; complete runtime checks and the frozen cost grid remain required.',
                tests=['native_varbin_table_exact_grant_and_conversion_overlap',
                    'native_varbin_builder_failed_growth_keeps_contents_and_can_retry',
                    'native_varbin_builder_exact_finalization_overlap_and_terminal_refund',
                    'encoded_transfer_varbin_tables_use_receiving_credit_and_report_it_once',
                    'encoded_transfer_varbin_exact_grants_and_denial_preserve_source']),
        ],
        preserved_boundaries=[
            'Vortex-native providers and serialization; no fallback or external query-engine dependency.',
            'Raw exported tables and legacy general-purpose builder scratch remain outside finite ownership claims.',
            'Requested capacity accounting is not a whole-process RSS limit or allocator-slack claim.',
            'No device execution claim; no implicit device read or copy.',
            'Original baseline, complete lifecycle harness, grid, clocks and thresholds remain unchanged.',
        ], unresolved_in_scope_findings=[], full_acceptance_pending=True)
    for objection in result['objections']:
        assert set(objection['tests']) <= set(tests)
    assert unchanged() == frozen
    save(OUT / 'varbin-review-source-review-552.json', result)
    print(json.dumps(dict(status='passed', reviewed_source_files=len(bound),
        required_tests=len(tests), full_acceptance_pending=True)))


if __name__ == '__main__':
    main()
