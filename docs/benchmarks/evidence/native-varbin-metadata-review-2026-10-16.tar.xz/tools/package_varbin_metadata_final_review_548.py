"""Seal documentation and primary review without rewriting runtime evidence."""
import base64
import datetime
import hashlib
import json
import lzma
from pathlib import Path
import re
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sha, sources

EVIDENCE = ROOT / 'docs/benchmarks/evidence'
STEM = 'native-varbin-metadata-resources-2026-10-16'
OUTPUT = EVIDENCE / 'native-varbin-metadata-final-review-2026-10-16.json.xz'
DEST = OUT / 'varbin-metadata-final-review-548'


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def read(name):
    return json.loads((OUT / name).read_text())


def guard(name):
    receipt = read(name + '.json')
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup']
    assert sha(OUT / (name + '.log')) == receipt['log_sha256']


def main():
    assert not DEST.exists() and not OUTPUT.exists()
    source_path = OUT / 'native-release-source-varbinmetadata546c.json'
    frozen = json.loads(source_path.read_text())
    assert sources() == frozen['source_sha256'] and len(frozen['source_sha256']) == 2371
    index_path = EVIDENCE / (STEM + '.json')
    index = json.loads(index_path.read_text())
    assert index['status'] == 'passed_local' and index['independent_packet_audit_passed']
    assert index['source_overlay_verified'] and not index['installed_wheel_proof']
    assert not index['hosted_integration_complete'] and index['member_count'] == 18023
    packet_identities = [identity(index_path)]
    for key in ('archive', 'manifest', 'audit', 'engine_timings'):
        item = index[key]
        path = EVIDENCE / item['file']
        ref = identity(path)
        assert ref['bytes'] == item['bytes'] and ref['sha256'] == item['sha256']
        packet_identities.append(ref)
    supplement = json.loads(lzma.decompress((EVIDENCE / index['audit']['file']).read_bytes()))
    audit = read('varbin-metadata-packet-audit-547.json')
    assert supplement['independent_audit'] == audit and audit['status'] == 'passed'
    original = supplement['original_index_utf8'].encode()
    assert hashlib.sha256(original).hexdigest() == audit['index']['sha256']
    assert len(original) == audit['index']['bytes']
    assert supplement['helper'] == identity(OUT / 'accept_varbin_metadata_packet_547.py')
    original_index = json.loads(original)
    assert all(original_index[key] == index[key] for key in ('archive', 'manifest', 'member_count', 'raw_bytes'))
    built = read('native-release-artifacts-varbinmetadata546c.json')
    for key in ('cli', 'binding'):
        assert identity(built[key]['path']) == {k: built[key][k] for k in ('path', 'bytes', 'sha256')}
    source_review = read('varbin-metadata-source-review-546.json')
    assert source_review['status'] == 'passed' and source_review['unresolved_in_scope_findings'] == []
    assert source_review['source_snapshot'] == identity(source_path)
    assert len(source_review['sources']) == 7 and len(source_review['objections']) == 3
    for row in source_review['sources']:
        assert identity(row['source']['path']) == row['source']
        lines = Path(row['source']['path']).read_text().splitlines()
        for marker, anchors in row['anchors'].items():
            assert all(marker in lines[line - 1] for line in anchors)
    docs_path = OUT / 'varbin-metadata-documentation-548/summary.json'
    docs = json.loads(docs_path.read_text())
    assert docs['status'] == 'passed' and len(docs['checks']) == 20
    assert docs['helper_sha256'] == sha(OUT / 'run_varbin_metadata_docs_548.py')
    assert docs['selected_sources_unchanged'] and docs['source_files'] == 2371
    assert docs['generator_sha256'] == sha(ROOT / 'website-src/scripts/sync-content.mjs')
    assert docs['workflow_sha256'] == sha(ROOT / '.github/workflows/ci.yml')
    for item in docs['checks']:
        assert item['returncode'] == 0 and sha(item['log']) == item['log_sha256']
    assert len(docs['local_links']) == 360
    hardware = read('varbin-metadata-documentation-548/hardware.json')
    assert hardware == docs['hardware'] and hardware['physical_memory_bytes'] == 16 * 1024 ** 3
    assert hardware['processor'] == 'Apple M5'
    browser = read('varbin-metadata-browser-548.json')
    assert browser['status'] == 'passed' and browser['console'] == []
    assert browser['screenshots_inspected_inline'] and browser['search']['result_pages'] == 3
    assert browser['search']['verified_runtime_and_limits'] and browser['mobile_theme'] == 'light'
    assert browser['navigation']['menuExpanded'] == 'false'
    assert browser['navigation']['url'].endswith('/field-guide/runtime-and-io/#resources-and-recovery')
    assert browser['viewport_restored'] and browser['temporary_tab_closed']
    for key in ('desktop', 'mobile', 'limits'):
        assert browser[key]['body'] <= browser[key]['width']
        normalized = re.sub(r'\s+', ' ', browser[key]['paragraph'])
        assert '18,023' in normalized and 'Hosted integration remains pending' in normalized
    guards = ['varbin-metadata-package-547', 'varbin-metadata-portable-inspection-547',
              'varbin-metadata-local-acceptance-548', 'varbin-metadata-documentation-548',
              'varbin-metadata-documentation-preview-548']
    for name in guards:
        guard(name)
    DEST.mkdir()
    final_checks = []
    for name, command in [
        ('v1-inclusion', [sys.executable, '-B', 'scripts/check_v1_inclusion_scope.py']),
        ('public-status', [sys.executable, '-B', 'scripts/check_public_status_docs.py', '--output', str(DEST / 'public-status.json')]),
        ('diff-check', ['git', 'diff', '--check']),
    ]:
        log = DEST / (name + '.log')
        with log.open('xb') as stream:
            result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, timeout=60)
        final_checks.append(dict(name=name, command=command, returncode=result.returncode, log=identity(log)))
        result.check_returncode()
    changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT, text=True).splitlines()
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=ROOT, text=True).splitlines()
    links, documentary = [], {}
    for name in sorted(set(changed + untracked)):
        path = ROOT / name
        if not path.is_file():
            continue
        if name.endswith(('.md', '.mdx', '.html', '.mjs')) or name.startswith('website/pagefind/'):
            documentary[name] = identity(path)
        if not name.endswith('.md'):
            continue
        for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^\s)]+)\)', path.read_text()):
            if target.startswith(('https:', 'http:', 'mailto:', '#')):
                continue
            destination = (path.parent / target.split('#', 1)[0]).resolve()
            assert destination.exists() or destination == OUTPUT, (name, target)
            links.append(dict(document=name, target=target, destination=str(destination)))
    paths = [
        'accept_varbin_metadata_packet_547.py', 'run_varbin_metadata_docs_548.py',
        'preview_varbin_metadata_docs_548.py', 'package_varbin_metadata_final_review_548.py',
        'freeze_native_release_298.py', 'varbin-metadata-packet-audit-547.json',
        'varbin-metadata-source-review-546.json', 'record_varbin_source_review_546.py',
        'varbin-metadata-browser-548.json', 'varbin-metadata-doc-preview-address-548.json',
        'varbin-metadata-doc-preview-stop-548', 'varbin-metadata-search-548.txt',
        'varbin-metadata-runtime-548.txt', 'varbin-metadata-limits-548.txt',
    ]
    for name in guards:
        paths.extend([name + '.json', name + '.log'])
    for directory in ('varbin-metadata-documentation-548', 'varbin-metadata-final-review-548'):
        paths.extend(str(p.relative_to(OUT)) for p in sorted((OUT / directory).iterdir()) if p.is_file())
    paths.extend(f'varbin-metadata-{name}-548.jpg' for name in
        ('runtime-desktop', 'runtime-mobile-dark', 'runtime-mobile-light', 'limits-mobile', 'search'))
    assert len(paths) == len(set(paths))
    members = []
    for name in paths:
        path = OUT / name
        raw = path.read_bytes()
        item = dict(name=name, **identity(path))
        if name.endswith('.jpg'):
            assert raw.startswith(b'\xff\xd8')
            item.update(base64=base64.b64encode(raw).decode('ascii'), mime_type='image/jpeg')
        else:
            item['utf8'] = raw.decode('utf-8')
        members.append(item)
    primary_review = dict(reviewer='primary', status='completed_source_review', blocking_findings=[],
        prior_static_review=identity(OUT / 'varbin-metadata-source-review-546.json'),
        source_unchanged_since_static_review=True, objections=source_review['objections'],
        acceptance='The complete local runtime packet and independent portable audit pass on the same source.',
        source_files=[identity(ROOT / name) for name in index['source_overlay']])
    packet = dict(schema_version='shardloom.native_varbin_metadata_final_review.v1', status='passed_local',
        observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), source_head=frozen['head'],
        source_manifest=identity(source_path), source_files=2371, runtime_unchanged_after_acceptance=True,
        core_packet=packet_identities, core_archive_rewritten=False, primary_review=primary_review,
        documentation=dict(checks=20, final_checks=final_checks, report=identity(docs_path),
            post_validation_edits='Report adds local review link and recorded physical RAM; phase status records completed local documentation/browser verification.'),
        local_links=links, documentary_source_identities=documentary, browser=browser,
        viewport_restored=True, temporary_tab_closed=True, owned_server_stopped=True,
        hardware=hardware, engine_execution_seconds='57.149358419',
        hosted_integration_complete=False, installed_wheel_proof=False,
        remaining_gate='Hosted checks, installed-wheel proof, PR review, merge and production verification.', members=members)
    raw = json.dumps(packet, ensure_ascii=False, indent=2).encode() + b'\n'
    assert len(raw) < 16 << 20
    with OUTPUT.open('xb') as stream:
        stream.write(lzma.compress(raw, preset=6))
    reopened = json.loads(lzma.decompress(OUTPUT.read_bytes()))
    assert reopened == packet
    for member in reopened['members']:
        data = member['utf8'].encode() if 'utf8' in member else base64.b64decode(member['base64'], validate=True)
        assert len(data) == member['bytes'] and hashlib.sha256(data).hexdigest() == member['sha256'] == sha(member['path'])
    assert all(Path(row['destination']).exists() for row in links)
    assert sources() == frozen['source_sha256']
    assert all(identity(ref['path']) == ref for ref in packet_identities)
    print(json.dumps(dict(status='passed_local', members=len(members), raw_bytes=len(raw),
        local_links=len(links), output=identity(OUTPUT))))


if __name__ == '__main__':
    main()
