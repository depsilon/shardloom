"""Bind unchanged measured production sources to three repaired test fixtures."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess

from freeze_native_release_298 import ROOT, OUT, save, sha, sources

OLD_HEAD = 'c08e044e19e7e709431bf76e8faa6aab5f46bb4a'
OLD = OUT / 'native-release-source-varbinreview557.json'
NEW = OUT / 'native-release-source-varbinreview560.json'
REPORT = OUT / 'varbin-review-fixture-bridge-560.json'
TESTS = {
    'native_sort_block': (
        'native_sort_block_rejects_malformed_losing_utf8_but_ignores_null_payload_bytes',
        'native_sort_block_rejects_malformed_utf8_before_sort_and_normalizes_null_payloads'),
    'scalar_distinct_workers': (
        'scalar_distinct_workers_invalid_used_utf8_fails_but_unused_dictionary_value_is_ignored',
        'scalar_distinct_workers_reject_malformed_text_before_admission_and_ignore_unused_values'),
    'string_count_partial': (
        'invalid_canonical_utf8_is_rejected_before_publishing_first_or_later_key',
        'malformed_utf8_is_rejected_before_counting_and_binary_is_not_reinterpreted'),
}
PREFIX = 'shardloom-vortex/src/local_primitives/'
CHANGED = {PREFIX + name + '_tests.rs' for name in TESTS}


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def read(path):
    return json.loads(Path(path).read_text())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def source_proof():
    old, new = read(OLD), read(NEW)
    assert old['head'] == OLD_HEAD and new['head'] != OLD_HEAD
    assert git('rev-parse', new['head'] + '^') == OLD_HEAD
    assert git('rev-parse', 'HEAD') == new['head']
    assert set(old['source_sha256']) == set(new['source_sha256'])
    assert len(new['source_sha256']) == 2371 and sources() == new['source_sha256']
    changed = {name for name, value in old['source_sha256'].items()
               if new['source_sha256'][name] != value}
    assert changed == CHANGED
    assert set(git('diff', '--name-only', OLD_HEAD, new['head']).splitlines()) == CHANGED
    rows = []
    for stem, (previous, current) in TESTS.items():
        name, parent = PREFIX + stem + '_tests.rs', PREFIX + stem + '.rs'
        old_bytes = subprocess.check_output(['git', 'show', OLD_HEAD + ':' + name], cwd=ROOT)
        new_bytes = (ROOT / name).read_bytes()
        assert hashlib.sha256(old_bytes).hexdigest() == old['source_sha256'][name]
        assert hashlib.sha256(new_bytes).hexdigest() == new['source_sha256'][name]
        assert old['source_sha256'][parent] == new['source_sha256'][parent] == sha(ROOT / parent)
        parent_text = (ROOT / parent).read_text()
        marker = '#[cfg(test)]\n#[path = "' + stem + '_tests.rs"]\nmod tests;'
        assert parent_text.count(marker) == 1
        assert len(re.findall(r'^#\[test\]$', old_bytes.decode(), re.M)) == len(
            re.findall(r'^#\[test\]$', new_bytes.decode(), re.M))
        assert 'fn ' + previous + '(' in old_bytes.decode()
        assert 'fn ' + current + '(' in new_bytes.decode()
        assert 'unsafe {' not in new_bytes.decode()
        rows.append(dict(path=name, prior_sha256=old['source_sha256'][name],
            current=identity(ROOT / name), parent=identity(ROOT / parent),
            cfg_test_marker=marker, prior_test=previous, current_test=current))
    return dict(prior_source=identity(OLD), current_source=identity(NEW),
        measured_commit=OLD_HEAD, accepted_commit=new['head'], test_changes=rows,
        unchanged_source_files=2371 - len(CHANGED), production_sources_unchanged=True,
        benchmark_harness_unchanged=True, benchmark_rerun=False,
        boundary='Three cfg(test) fixture files only; no production code or cost samples changed.')


def verify():
    record = read(REPORT)
    assert record['status'] == 'passed' and record['source_proof'] == source_proof()
    assert record['helper'] == identity(__file__)
    for name in ('failed_native_receipt', 'failed_native_log', 'failed_broad_summary',
                 'focused_receipt', 'focused_log', 'inventory'):
        assert record[name] == identity(record[name]['path'])
    return record


def verify_retained_cost(protocol):
    """Preserve every original cost check, with one explicit test-only source bridge."""
    import varbin_review_cost_557 as lifecycle
    record = verify()
    v, c = lifecycle.v, lifecycle.c
    for item in protocol['helpers'] + [protocol[key] for key in
            ('contract', 'test_harness', 'baseline_git_proof')]:
        assert c.bound(item['path']) == item
    old = read(OLD)['source_sha256']
    current = c.sources(c.ROOT)
    for role, value in protocol['identities'].items():
        assert c.bound(value['manifest']['path']) == value['manifest']
        v.verify_build(value)
        source = c.read(value['source']['path'])
        if role == 'candidate':
            assert source['head'] == OLD_HEAD
            assert set(current) == set(source['source_sha256'])
            assert all(old[name] == digest for name, digest in source['source_sha256'].items())
            assert {name for name, digest in current.items()
                    if source['source_sha256'][name] != digest} == CHANGED
            assert c.bound(source['broad_source']['path']) == source['broad_source']
            assert source['broad_source']['path'] == str(OLD)
        else:
            proof = c.read(protocol['baseline_git_proof']['path'])
            assert source['head'] == v.BASE == proof['commit'] and proof['status'] == 'passed'
            assert proof['source'] == value['source'] and proof['files'] == len(source['source_sha256'])
    return record


def main():
    assert not REPORT.exists() and not git('status', '--porcelain')
    proof = source_proof()
    failed = OUT / 'varbin-review-native-tests-557.json'
    failed_log = failed.with_suffix('.log')
    failure = read(failed)
    assert failure['status'] == 'failed' and failure['returncode'] == 101
    assert failure['process_group_drained'] and failure['direct_child_reaped']
    assert failure['head'] == OLD_HEAD and sha(failed_log) == failure['log_sha256']
    assert '2887 passed; 3 failed; 27 ignored;' in failed_log.read_text()
    for previous, _ in TESTS.values():
        assert previous in failed_log.read_text()
    focused = OUT / 'varbin-review-fixture-focused-retry-560.json'
    focused_log = focused.with_suffix('.log')
    result = read(focused)
    assert result['status'] == 'passed' and result['returncode'] == 0
    assert result['process_group_drained'] and result['direct_child_reaped']
    assert sha(focused_log) == result['log_sha256']
    for _, current in TESTS.values():
        assert re.search(r'^test .*::' + re.escape(current) + r' \.\.\. ok$', focused_log.read_text(), re.M)
    save(REPORT, dict(status='passed', source_proof=proof, helper=identity(__file__),
        failed_native_receipt=identity(failed), failed_native_log=identity(failed_log),
        failed_broad_summary=identity(OUT / 'varbin-review-checks-557.json'),
        focused_receipt=identity(focused), focused_log=identity(focused_log),
        inventory=identity(OUT / 'malformed-varbin-fixture-inventory-560.json'),
        coverage='Constructor rejects invalid UTF-8; normalized nulls, exact used/unused dictionary counts and binary/text admission remain tested.',
        unsafe_fixture_injection=False, broad_acceptance_pending=True))
    verify_retained_cost(read(OUT / 'varbin-review-cost-557/protocol.json'))
    print(json.dumps(dict(status='passed', changed_test_files=3, unchanged_source_files=2368,
        production_sources_unchanged=True, cost_samples_preserved=True)))


if __name__ == '__main__':
    argparse.ArgumentParser(description=__doc__).parse_args()
    main()
