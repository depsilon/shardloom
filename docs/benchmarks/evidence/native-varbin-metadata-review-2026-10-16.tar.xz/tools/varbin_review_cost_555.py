"""Compare specialized UTF-8 boundary checks against the frozen lifecycle baseline."""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import time

import varbin_metadata_cost_546 as v

c = v.c
OLD = c.OUT / 'varbin-metadata-cost-543'
c.DEST = c.OUT / 'varbin-review-cost-555'
v.SOURCE = c.DEST / 'candidate-source-555.json'
v.PROOF = c.DEST / 'baseline-git-verification-555.json'
BROAD = c.OUT / 'native-release-source-varbinreview555.json'
INSPECTOR = c.OUT / 'verify_varbin_review_cost_555.py'


def required_tests():
    names = set()
    for name in ('native_provider_varbin_metadata_tests.rs',
                 'native_provider_varbin_construction_tests.rs',
                 'native_provider_varbin_deserialize_tests.rs',
                 'resident_memory_varbin_transfer_tests.rs'):
        names.update(re.findall(r'^fn ((?:native_varbin_|encoded_transfer_varbin_)\w+)\(',
            (c.ROOT / 'shardloom-vortex/src' / name).read_text(), re.M))
    assert len(names) == 25
    return names


v.required_tests = required_tests


def prepare():
    assert not v.git('status', '--porcelain') and not c.DEST.exists()
    frozen = c.read(BROAD)
    from freeze_native_release_298 import sources
    assert sources() == frozen['source_sha256'] and len(frozen['source_sha256']) == 2371
    assert v.git('rev-parse', 'HEAD') == frozen['head']
    c.storage(c.DEST)
    c.DEST.mkdir()
    # Only small identity manifests are copied; the original frozen baseline
    # executable, source snapshot, build receipt and logs remain unchanged.
    for name in ('baseline-source.json', 'baseline-build.json'):
        shutil.copyfile(OLD / name, c.DEST / name)
        assert c.sha(OLD / name) == c.sha(c.DEST / name)
    baseline = c.read(c.DEST / 'baseline-source.json')
    compiler = subprocess.check_output(
        ['/Users/dylan/.cargo/bin/rustup', 'run', '1.99.0', 'rustc', '-Vv'], text=True)
    assert compiler == baseline['compiler']
    assert c.sha(c.ROOT / c.HARNESS) == baseline['harness_sha256']
    c.save(v.SOURCE, dict(root=str(c.ROOT), head=frozen['head'], base=v.BASE,
        source_sha256=c.sources(c.ROOT), status='', compiler=compiler,
        diff_base64=base64.b64encode(subprocess.check_output(
            ['git', 'diff', '--binary', v.BASE, 'HEAD'], cwd=c.ROOT)).decode('ascii'),
        broad_source=c.bound(BROAD), prepared_at=time.time()))
    print(json.dumps(dict(status='prepared', source_files=2371, added_tests=25)))


def freeze_protocol():
    prior_path = OLD / 'protocol.json'
    prior = c.read(prior_path)
    proof_path = v.PROOF
    v.PROOF = c.DEST / 'baseline-copied-manifest-git-verification-555.json'
    proof = v.verify_baseline_git()
    v.PROOF = proof_path
    original_source = c.bound(OLD / 'baseline-source.json')
    assert original_source['sha256'] == proof['source']['sha256']
    proof = dict(proof, source=original_source, copied_source=proof['source'])
    c.save(v.PROOF, proof)
    identities = {}
    for role in ('baseline', 'candidate'):
        path = c.DEST / (role + '-build.json')
        value = c.read(path)
        v.verify_build(value)
        identities[role] = dict(manifest=c.bound(path), **value)
    assert identities['baseline']['binary'] == prior['identities']['baseline']['binary']
    assert identities['candidate']['binary']['sha256'] != prior['identities']['candidate']['binary']['sha256']
    baseline = c.read(identities['baseline']['source']['path'])
    old_contract = subprocess.check_output(
        ['git', 'show', v.BASE + ':' + str(v.CONTRACT.relative_to(c.ROOT))], cwd=c.ROOT)
    assert hashlib.sha256(old_contract).hexdigest() == baseline['contract_sha256']
    acceptance = lambda text: text.split('## Acceptance protocol\n', 1)[1].split('Required verification:', 1)[0]
    assert acceptance(old_contract.decode()) == acceptance(v.CONTRACT.read_text())
    assert hashlib.sha256(acceptance(old_contract.decode()).encode()).hexdigest() == prior['acceptance_protocol_text_sha256']
    assert c.sha(c.ROOT / c.HARNESS) == baseline['harness_sha256'] == prior['test_harness']['sha256']
    names = {role: {line.removesuffix(': test') for line in Path(value['test_inventory']['path']).read_text().splitlines()
                   if line.endswith(': test')} for role, value in identities.items()}
    added = names['candidate'] - names['baseline']
    assert not names['baseline'] - names['candidate']
    assert len(added) == 25 and {name.split('::')[-1] for name in added} == required_tests()
    assert len(added - set(prior['binary_inventory_delta']['added_candidate_tests'])) == 4
    helpers = [Path(__file__), Path(v.__file__), Path(c.__file__), c.SUPERVISOR,
        c.OUT / 'run_guarded.py', c.OUT / 'freeze_varbin_metadata_543.py',
        c.OUT / 'freeze_native_release_298.py', INSPECTOR,
        c.OUT / 'verify_varbin_metadata_cost_546.py',
        Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py')]
    helpers += [c.ROOT / 'scripts' / name for name in ('timed_native_command.py',
        'run_clickbench_query_uat.py', 'run_clickbench_paired_query_uat.py', 'local_uat_storage.py')]
    protocol = dict(prior, frozen_at=time.time(), identities=identities,
        helpers=[c.bound(path) for path in helpers], baseline_git_proof=c.bound(v.PROOF),
        baseline_source_files=proof['files'], contract=c.bound(v.CONTRACT),
        test_harness=c.bound(c.ROOT / c.HARNESS),
        binary_inventory_delta=dict(retained_tests=len(names['baseline']), added_candidate_tests=sorted(added)),
        review_refresh=dict(prior_protocol=c.bound(prior_path),
            reason='Retain safe host validation and validated-view reuse; specialize the single-buffer builder to check UTF-8 starts through its existing checked value slices.',
            prior_corrected_cost_decision=c.bound(c.OUT / 'varbin-review-cost-550/decision.json'),
            prior_corrected_cost_inspection=c.bound(c.OUT / 'varbin-review-cost-inspection-550.json'),
            prior_reuse_cost_decision=c.bound(c.OUT / 'varbin-review-cost-552/decision.json'),
            prior_reuse_cost_inspection=c.bound(c.OUT / 'varbin-review-cost-inspection-552.json'),
            prior_dense_utf8_cost_decision=c.bound(c.OUT / 'varbin-review-cost-553/decision.json'),
            prior_dense_utf8_cost_inspection=c.bound(c.OUT / 'varbin-review-cost-inspection-report-553.json'),
            prior_fused_utf8_cost_decision=c.bound(c.OUT / 'varbin-review-cost-554/decision.json'),
            prior_fused_utf8_cost_inspection=c.bound(c.OUT / 'varbin-review-cost-inspection-report-554.json'),
            prior_550_552_inspection_files_are_execution_receipts=True,
            acceptance_grid_clocks_thresholds_and_harness_unchanged=True,
            prior_measurements_preserved=True))
    v.verify(protocol)
    c.save(c.DEST / 'protocol.json', protocol)
    print(json.dumps(dict(status='frozen_protocol', cells=32, added_tests=25)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('prepare', 'freeze-build', 'freeze-protocol', 'run', 'decide'))
    parser.add_argument('--receipt', type=Path)
    parser.add_argument('--order', choices=('forward', 'reverse'))
    args = parser.parse_args()
    if args.operation == 'prepare': prepare()
    elif args.operation == 'freeze-build': v.freeze_build(args.receipt)
    elif args.operation == 'freeze-protocol': freeze_protocol()
    elif args.operation == 'run': v.run(args.order)
    else: c.decide()
