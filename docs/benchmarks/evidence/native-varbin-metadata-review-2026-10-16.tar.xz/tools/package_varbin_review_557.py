"""Package complete metadata ownership acceptance and its retained counterevidence."""
import ast
import hashlib
import json
import lzma
from pathlib import Path
import re
import subprocess
import sys
import tarfile

from freeze_native_release_298 import ROOT, OUT, save, sha
from run_varbin_review_acceptance_557 import (
    SOURCE, MANIFEST, PROTOCOL, PUBLIC, PUBLIC_ACCEPTANCE,
    identity, unchanged, load, prerequisites, protocol, receipt,
)
from package_selection_acceptance_409 import Members, verify, sha_stream, excluded_identity

sys.path.insert(0, str(ROOT / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

BASE = '0f8de6a913ca3bb8a170ddeb3c175c24eb521e64'
ACCEPTED = 'c08e044e19e7e709431bf76e8faa6aab5f46bb4a'
DIRECT = OUT / 'varbin-review-direct-tests-557.json'
STEM = 'native-varbin-metadata-review-2026-10-16'
LOCAL = OUT / 'varbin-review-packet-557'
DEST = ROOT / 'docs/benchmarks/evidence'
CHECKS = OUT / 'varbin-review-checks-557.json'
FULL = OUT / 'varbin-review-full43-review-557.json'
INSPECTION = OUT / 'varbin-review-public-inspection-report-557.json'
COST_REVIEW = OUT / 'varbin-review-cost-inspection-report-557.json'
CONTRACT = ROOT / 'docs/architecture/native-varbin-metadata-resources-2026-10-16.md'
MAX_RAW_BYTES = 256 * MIB
HISTORY_RAW_BYTES = 96 * MIB
MAX_ARCHIVE_BYTES = 100 * MIB
HISTORICAL_SOURCES = {
    OUT / ('varbin-review-cost-' + tag) / ('candidate-source-' + tag + '.json')
    for tag in ('550', '552', '553', '554', '555', '556')
}


def read(path):
    return json.loads(Path(path).read_text())


def main():
    assert not LOCAL.exists()
    assert not any(DEST.glob(STEM + '*'))
    prerequisites()
    accepted, artifacts, declared = unchanged(), load(), protocol()
    assert accepted['head'] == artifacts['head'] == ACCEPTED
    assert len(accepted['source_sha256']) == 2371
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == ACCEPTED
    checks = read(CHECKS)
    counts = {row['stage']: row['tests'] for row in checks['completed'] if 'tests' in row}
    assert counts['workspace-tests']['passed'] == 3221 and counts['workspace-tests']['ignored'] == 0
    assert counts['native-tests']['passed'] == 4319 and counts['native-tests']['ignored'] == 30
    prior = read(OUT / 'zstd-metadata-checks-532.json')
    old_native = next(row['tests'] for row in prior['completed'] if row['stage'] == 'native-tests')
    assert old_native['passed'] + 25 == 4319
    old_ignored = {tuple(row) for row in old_native['ignored_declarations']}
    new_ignored = {tuple(row) for row in counts['native-tests']['ignored_declarations']}
    assert old_ignored <= new_ignored and len(new_ignored - old_ignored) == 1
    extra, = new_ignored - old_ignored
    assert extra[0].endswith('::native_varbin_metadata_complete_lifecycle_cost_screen')
    test_protocol = read(checks['protocol']['path'])
    native_log = Path(next(row['log']['path'] for row in checks['completed'] if row['stage'] == 'native-tests')).read_text()
    assert len(test_protocol['required_tests']) == 25
    for name in test_protocol['required_tests']:
        assert re.search(r'^test .*::' + re.escape(name) + r' \.\.\. ok$', native_log, re.M), name
    vendor_path = OUT / 'varbin-review-vendor-inspection-557.json'
    vendor = read(vendor_path)
    assert vendor['status'] == 'passed' and vendor['selected_sources_match_current']
    assert vendor['source_files_verified'] == 841 and vendor['commands_verified'] == 8
    assert vendor['source'] == identity(SOURCE) and vendor['all_eight_commands_fresh']
    for key in ('protocol', 'summary', 'receipt', 'log', 'historical_inventory', 'helper'):
        assert identity(vendor[key]['path']) == vendor[key]
    assert [row['provider'] for row in vendor['groups']] == [
        'vortex-array', 'vortex-fsst', 'vortex-runend', 'vortex-zstd']
    assert sum(row['counts']['passed'] for row in vendor['groups']) == 3587
    assert sum(row['counts']['ignored'] for row in vendor['groups']) == 2
    assert all(row['counts']['failed'] == row['counts']['filtered'] == 0 for row in vendor['groups'])
    source_review = read(OUT / 'varbin-review-source-review-557.json')
    assert source_review['status'] == 'passed'
    assert source_review['source_snapshot'] == identity(SOURCE) and source_review['head'] == ACCEPTED
    assert not source_review['unresolved_in_scope_findings']
    direct = read(DIRECT)
    assert direct['status'] == 'passed' and direct['tests'] == 100
    assert direct['failures'] == direct['errors'] == direct['skipped'] == 0
    assert direct['test_names'] == declared['expected_direct_names']
    assert direct['source'] == identity(SOURCE) and direct['artifact_manifest'] == identity(MANIFEST)
    runtime, public, inspected = read(PUBLIC_ACCEPTANCE), read(PUBLIC / 'summary.json'), read(INSPECTION)
    assert runtime['status'] == public['status'] == inspected['status'] == 'passed'
    assert runtime['manifest'] == identity(MANIFEST) and runtime['source'] == identity(SOURCE)
    assert [row['name'] for row in public['cases']] == declared['expected_public_names']
    assert public['families'] == declared['expected_public_families'] and all(row['status'] == 'passed' for row in public['cases'])
    assert inspected['cases'] == 4827 and inspected['families'] == 36
    assert inspected['summary'] == runtime['summary'] == identity(PUBLIC / 'summary.json')
    assert inspected['accepted_source'] == identity(SOURCE)
    cost_review = read(COST_REVIEW)
    assert cost_review['status'] == 'passed' and cost_review['decision_status'] == 'retained_pending_broad_acceptance'
    assert cost_review['decision'] == identity(OUT / 'varbin-review-cost-557/decision.json')
    assert not cost_review['repeated_breaches'] and cost_review['independently_recomputed_from_complete_raw_samples']
    full = read(FULL)
    assert full['status'] == 'passed' and full['queries'] == full['calls'] == 43 and full['repeats'] == 1
    assert full['complete_rows'] == 381 and full['accepted_source'] == identity(SOURCE)
    assert full['all_values_schemas_and_clocks_reopened'] and full['native_children_absent']
    assert full['resources_no_fallback_native_certificates'] and full['original_input_and_sources_unchanged']
    admission = read(full['admission']['path'])
    assert admission['source_resident_before_read'] and admission['no_new_ingest']
    broad_receipts = [Path(row['receipt']['path']) for row in checks['completed']]
    final_receipts = [OUT / (name + '.json') for name in (
        'varbin-review-candidate-build-557',
        'varbin-review-freeze-build-557', 'varbin-review-freeze-protocol-557',
        'varbin-review-cost-forward-557', 'varbin-review-cost-decision-557',
        'native-final-cli-release-build-varbinreview557', 'native-final-python-release-build-varbinreview557',
        'varbin-review-freeze-native-557', 'varbin-review-declarations-557', 'varbin-review-direct-557',
        'varbin-review-public-557', 'varbin-review-public-inspection-557',
        'varbin-review-cost-report-check-557', 'varbin-review-full43-557',
        'varbin-review-release-script-tests-557', 'varbin-review-vendor-tests-557',
        'varbin-review-vendor-report-check-557')]
    if read(OUT / 'varbin-review-cost-557/decision.json')['reverse']:
        final_receipts.append(OUT / 'varbin-review-cost-reverse-557.json')
    for path in final_receipts:
        receipt(path)
    release_log = (OUT / 'varbin-review-release-script-tests-557.log').read_text()
    assert re.search(r'Ran 164 tests in [0-9.]+s\n\nOK\n', release_log)
    # All six workspace gates and all eight provider commands are fresh on this
    # source. Historical failed comparisons remain counterevidence below.

    members, exclusions = Members(), []
    def add(path, name, role, digest=None):
        path = Path(path)
        root = ROOT if path.is_relative_to(ROOT) else OUT if path.is_relative_to(OUT) else path.parent
        members.add(path, name, root.name, root, role, digest)

    changed = set(subprocess.check_output(['git', 'diff', '--name-only', BASE], cwd=ROOT, text=True).splitlines())
    changed.update(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=ROOT, text=True).splitlines())
    overlay = sorted(changed & accepted['source_sha256'].keys())
    assert len(overlay) == 98
    for name in overlay:
        add(ROOT / name, 'source-overlay/' + name, 'complete source difference from the pre-change baseline', accepted['source_sha256'][name])
    for row in source_review['reviewed_sources']:
        item = row['source']
        name = str(Path(item['path']).relative_to(ROOT))
        assert item['sha256'] == accepted['source_sha256'][name]
        add(item['path'], 'reviewed-sources/' + name,
            'complete source for the primary review, including unchanged proof dependencies', item['sha256'])
    for name in ('shardloom-vortex/src/lib.rs', 'shardloom-vortex/src/resident_memory_source.rs',
                 'shardloom-vortex/Cargo.toml', 'shardloom-cli/Cargo.toml'):
        add(ROOT / name, 'feature-gate-sources/' + name,
            'unchanged feature gates supporting precise broad-check source reuse', accepted['source_sha256'][name])
    baseline_provenance = OUT / 'varbin-metadata-baseline-provider-provenance-547.json'
    baseline_record = read(baseline_provenance)
    assert baseline_record['commit'] == BASE
    assert set(baseline_record['providers']) == {'vortex-array', 'vortex-zstd'}
    for provider, item in baseline_record['providers'].items():
        payload = subprocess.check_output(['git', 'cat-file', 'blob',
            BASE + ':vendor/' + provider + '/upstream-provenance.json'], cwd=ROOT)
        assert json.loads(payload) == item['value'] and hashlib.sha256(payload).hexdigest() == item['sha256']
    add(baseline_provenance, 'baseline-provider/provenance.json', 'immutable baseline provider provenance')
    add(CONTRACT, 'contracts/metadata-contract.md', 'exact predeclared ownership contract', declared['contract']['sha256'])
    add(ROOT / 'docs/rfcs/0044-resident-runtime-resource-ownership.md',
        'contracts/resident-runtime-resource-ownership.md', 'reviewed provider safety and ownership decision',
        source_review['rfc']['sha256'])
    intake = read(OUT / 'varbinview-provenance-intake-541/inventory.json')
    assert {row['name'] for row in intake['packages']} == {'vortex-fsst', 'vortex-runend'}
    for item in intake['packages']:
        add(item['archive'], 'upstream-archives/' + Path(item['archive']).name,
            'exact registry archive for independently repeated provenance checks', item['archive_sha256'])
    lifecycle = read(OUT / 'varbin-review-cost-557/protocol.json')
    harness = lifecycle['test_harness']
    add(harness['path'], 'lifecycle-harness/' + Path(harness['path']).name,
        'identical complete lifecycle harness used by both frozen executables', harness['sha256'])
    for path in (SOURCE, MANIFEST):
        add(path, 'manifests/' + path.name, 'complete frozen accepted source or artifact manifest')
    # Known prefixes preserve the portable public and Full43 verifier contracts.
    members.tree(PUBLIC, 'public', 'public', 'complete public regression logs and source snapshots', exclusions, omit_outputs=True)
    for path, name in (
        (OUT / 'stream-unary-candidate-declarations-493b/logs/unary-predeclared-values.json', 'predeclared-reference/unary-predeclared-values.json'),
        (OUT / 'stream-subquery-candidate-declarations-509/subqueries/logs/subquery-predeclared-results.json', 'predeclared-reference/subquery-predeclared-results.json'),
        (OUT / 'stream-dynamic-subquery-candidate-declarations-521/dynamic-subqueries/logs/dynamic-subquery-predeclared-results.json', 'declarations-521/dynamic-subqueries/logs/dynamic-subquery-predeclared-results.json'),
        (OUT / 'stream-dynamic-subquery-candidate-declarations-521/dynamic-subqueries-pressure/logs/dynamic-subquery-pressure-fixtures.json', 'declarations-521/dynamic-subqueries-pressure/logs/dynamic-subquery-pressure-fixtures.json'),
        (OUT / 'stream-dynamic-inner-baseline-513/summary.json', 'baseline/summary.json')):
        add(path, name, 'unchanged independent pre-execution complete reference values')
    for item in [admission['reference'], admission['queries'], *admission['harness'], *admission['schema_sources']]:
        prefix = 'full43-baseline-schemas' if item in admission['schema_sources'] else 'full43-inputs'
        add(item['path'], prefix + '/' + Path(item['path']).name, 'predeclared Full43 input/reference/schema/helper', item['sha256'])
    members.tree(Path(full['summary']['path']).parent, 'full43', 'full43', 'complete one-pass Full43 evidence', exclusions)
    for folder in ('varbin-metadata-cost-543', 'varbin-review-cost-550',
                   'varbin-review-cost-552', 'varbin-review-cost-553', 'varbin-review-cost-554',
                   'varbin-review-cost-555', 'varbin-review-cost-556',
                   'varbin-review-cost-557', 'varbin-review-vendor-557',
                   'varbin-review-profile-556',
                   'varbin-metadata-vendor-544',
                   'varbin-metadata-vendor-545b', 'varbin-metadata-vendor-545c',
                   'varbin-metadata-vendor-545d', 'varbin-metadata-vendor-545e',
                   'varbinview-provenance-intake-541', 'varbinview-new-tables-intake-542',
                   'varbinview-vendoring-543', 'varbinview-wiring-intake-544',
                   'varbinview-callsite-inventory-545', 'varbin-goldenfile-intake-545',
                   'varbin-goldenfile-intake-545b'):
        members.tree(OUT / folder, folder, folder,
            'complete frozen lifecycle, provenance or vendor evidence including failures', exclusions)
    skip = {'varbin-review-package-557.log', 'varbin-review-package-557.json'}
    helper_paths = []
    for path in sorted(OUT.iterdir()):
        if (path.is_file() and path.name not in skip and
                'varbin' in path.name and
                path.suffix in ('.json', '.log', '.py', '.diff', '.md')):
            add(path, ('tools/' if path.suffix == '.py' else 'receipts/') + path.name,
                'metadata candidate observation/helper; failures and filtered commands remain counterevidence')
            if path.suffix == '.py':
                helper_paths.append(path)
    for item in [declared['prior_protocol'], declared['prior_direct'],
                 identity(OUT / 'zstd-metadata-checks-532.json'),
                 *inspected['predeclared_value_files']]:
        if 'original' in item:
            item = item['original']
        add(item['path'], 'prior-identities/' + Path(item['path']).name, 'unchanged prior oracle or exclusion inventory', item['sha256'])
    for field in ('retained_initial_failures', 'corrected_source', 'dynamic_initial_failures', 'dynamic_initial_diagnosis'):
        item = inspected[field]
        add(item['path'], 'inherited-context/' + Path(item['path']).name, 'historical oracle provenance already retained in the prior accepted unit', item['sha256'])
    for artifact in (artifacts['cli'], artifacts['binding']):
        assert identity(artifact['path']) == {k: artifact[k] for k in ('path', 'bytes', 'sha256')}
        exclusions.append(excluded_identity(Path(artifact['path']),
            'executables/' + Path(artifact['path']).parent.name + '/' + Path(artifact['path']).name,
            'frozen executable excluded; complete source/build identity retained'))
    item = admission['input']
    exclusions.append(dict(archive_path='resident-input/' + Path(item['path']).name,
        original_absolute_path=item['path'], byte_count=item['bytes'], sha256=item['sha256'],
        reason='large resident input excluded; complete before/after identity proof retained'))
    for name, digest in accepted['source_sha256'].items():
        if name.startswith('python/src/'):
            add(ROOT / name, 'python-package/' + name.removeprefix('python/src/'), 'complete source Python package', digest)
    # Preserve the import closure of local helpers plus their explicit dynamic guard.
    external = Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930')
    supervisor = Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')
    roots = (OUT, ROOT / 'scripts', ROOT / 'python/src', external)
    helper_paths += [OUT / name for name in ('package_selection_acceptance_409.py',
        'verify_stream_unary_packet_497.py', 'verify_stream_dynamic_subquery_packet_522.py',
        'metadata_public_verifier_534.py', 'run_guarded.py',
        'verify_varbin_review_packet_557.py', 'verify_varbin_review_vendor_archive_557.py',
        'prepare_varbin_packet_baseline_547.py')]
    helper_paths += [supervisor, external / 'release_validation_guard.py',
        ROOT / 'scripts/timed_native_command.py', ROOT / 'scripts/build_native_python.py']
    visited = set()
    while helper_paths:
        path = helper_paths.pop().resolve()
        if path in visited:
            continue
        visited.add(path)
        prefix = ('repository/' + path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT) else
                  'local/' + path.relative_to(OUT).as_posix() if path.is_relative_to(OUT) else
                  'external/' + path.parent.name + '/' + path.name)
        add(path, 'dependencies/' + prefix, 'transitive local helper source')
        for node in ast.walk(ast.parse(path.read_text())):
            modules = ([name.name for name in node.names] if isinstance(node, ast.Import) else
                       [node.module] if isinstance(node, ast.ImportFrom) and node.module and node.level == 0 else [])
            for module in modules:
                for root in roots:
                    module_path = root.joinpath(*module.split('.'))
                    candidate = module_path.with_suffix('.py')
                    if not candidate.is_file():
                        candidate = module_path / '__init__.py'
                    if candidate.is_file():
                        helper_paths.append(candidate)
                        break

    ordered = sorted(members.paths.values(), key=lambda item: item.name)
    raw_size = sum(item.size for item in ordered)
    # The six immutable rejected-source snapshots include earlier binary Git
    # diffs. Keep their exact bytes in bounded source-history archives; do not
    # drop those bytes or relax the existing per-archive raw-input ceiling.
    history = [item for item in ordered if item.path in HISTORICAL_SOURCES]
    current = [item for item in ordered if item.path not in HISTORICAL_SOURCES]
    assert {item.path for item in history} == HISTORICAL_SOURCES
    partitions = {STEM + '.tar.xz': current}
    history_names, group, group_size = [], [], 0
    for item in sorted(history, key=lambda row: str(row.path)):
        assert item.size <= HISTORY_RAW_BYTES
        if group and group_size + item.size > HISTORY_RAW_BYTES:
            name = STEM + '.historical-sources-' + str(len(history_names) + 1) + '.tar.xz'
            partitions[name] = group
            history_names.append(name)
            group, group_size = [], 0
        group.append(item)
        group_size += item.size
    if group:
        name = STEM + '.historical-sources-' + str(len(history_names) + 1) + '.tar.xz'
        partitions[name] = group
        history_names.append(name)
    assert len(history_names) == 3
    archive_raw_bytes = {name: sum(item.size for item in rows)
                         for name, rows in partitions.items()}
    assert all(size <= MAX_RAW_BYTES for size in archive_raw_bytes.values())
    # The portable reader retains the main archive and reads historical source
    # snapshots one at a time, discarding their large diff after verification.
    assert sum(item.size for item in current) + max(item.size for item in history) <= MAX_RAW_BYTES
    assert sum(archive_raw_bytes.values()) == raw_size
    archive_for = {item.name: name for name, rows in partitions.items() for item in rows}
    require_local_path(LOCAL, Path.home(), sys.platform)
    storage = check_budgets(OUT, LOCAL, OUT / 'logs', min_free_bytes=12 * GIB,
        reserve_bytes=raw_size + 64 * MIB, max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    LOCAL.mkdir()
    seen = set()
    archives = {}
    for name, rows in partitions.items():
        archive_path = LOCAL / name
        with archive_path.open('xb') as target:
            with tarfile.open(fileobj=target, mode='w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
                for item in rows:
                    verify(item.path, item.digest, item.size)
                    info = tarfile.TarInfo(item.name)
                    info.size, info.mode, info.mtime = item.size, 0o644, 0
                    with item.path.open('rb') as stream:
                        archive.addfile(info, stream)
        with tarfile.open(archive_path, mode='r|xz') as archive:
            for entry in archive:
                assert entry.isfile() and entry.name in members.names and entry.name not in seen
                assert archive_for[entry.name] == name
                item = members.paths[members.names[entry.name]]
                with archive.extractfile(entry) as stream:
                    assert sha_stream(stream) == (item.size, item.digest)
                seen.add(entry.name)
        archives[name] = dict(file=name, bytes=archive_path.stat().st_size,
            sha256=sha(archive_path), raw_bytes=archive_raw_bytes[name], member_count=len(rows))
        assert archives[name]['bytes'] < MAX_ARCHIVE_BYTES
    assert seen == set(members.names)
    for item in ordered:
        verify(item.path, item.digest, item.size)
    assert unchanged() == accepted and load() == artifacts
    prerequisites()
    acceptance = dict(workspace_tests=3221, workspace_ignored=0, native_tests=4319, native_ignored=30,
        vendor_tests=3587, vendor_ignored=2, vendor_commands=8, vendor_providers=4,
        new_native_tests=25, release_script_tests=164, direct_methods=100, direct_skips=0,
        public_cases=4827, public_families=36, lifecycle_cases=32,
        lifecycle_operations=4864 * (2 if cost_review['reverse'] else 1),
        full43_queries=43, full43_calls=43, full43_repeats=1,
        full43_complete_rows=full['complete_rows'])
    limitations = ['The reservation covers requested buffer-table element capacities, not fixed Arc headers, allocator bookkeeping, all process RSS or OS allocation success.',
        'Raw constructor/export boundaries, legacy general builders, selective compaction/dedup scratch, other provider allocations, general state spill and transport retain separate contracts.',
        'One finite regression pass and an overhead screen do not establish a speedup, package release or all-platform readiness.',
        'Direct binding tests use the source Python package with frozen native artifacts; installed-wheel and hosted proof remain separate gates.']
    manifest = dict(status='passed_local_evidence_packaged', base_commit=BASE, accepted_commit=ACCEPTED, source_files=2371,
        source_manifest=identity(SOURCE), artifact_manifest=identity(MANIFEST), source_overlay=overlay,
        members=[dict(path=str(item.path), archive_path=item.name, archive_file=archive_for[item.name],
            bytes=item.size, sha256=item.digest, roles=item.roles) for item in ordered],
        member_count=len(ordered), raw_bytes=raw_size, all_members_reopened=True, exclusions=exclusions,
        archives=archives, max_raw_bytes_per_archive=MAX_RAW_BYTES,
        max_historical_raw_bytes_per_archive=HISTORY_RAW_BYTES,
        max_archive_file_bytes=MAX_ARCHIVE_BYTES,
        historical_source_paths=sorted(map(str, HISTORICAL_SOURCES)),
        storage=storage, acceptance=acceptance, final_receipts=[identity(p) for p in final_receipts],
        broad_receipts=[identity(p) for p in broad_receipts],
        vendor_primary_verification=identity(vendor_path),
        public_inspection=identity(INSPECTION), full43_review=identity(FULL), lifecycle_review=identity(COST_REVIEW),
        original_contract=identity(CONTRACT), source_identity_preserved=True, publication_attempted=False,
        baseline_provider_provenance=identity(baseline_provenance),
        limitations=limitations)
    raw = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    packed = lzma.compress(raw, preset=6)
    assert lzma.decompress(packed) == raw
    manifest_path = LOCAL / (STEM + '.manifest.json.xz')
    with manifest_path.open('xb') as stream:
        stream.write(packed)
    index = dict(schema_version='shardloom.native_varbin_metadata_review_evidence.v2',
        status='packaged_local_pending_acceptance_decision', base_commit=BASE, accepted_commit=ACCEPTED, source_files=2371,
        member_count=len(ordered), raw_bytes=raw_size, all_members_reopened=True, acceptance=acceptance,
        source_manifest=manifest['source_manifest'], artifact_manifest=manifest['artifact_manifest'], source_overlay=overlay,
        archive=archives[STEM + '.tar.xz'],
        historical_sources_archives=[archives[name] for name in history_names],
        archives=archives, max_raw_bytes_per_archive=MAX_RAW_BYTES,
        max_historical_raw_bytes_per_archive=HISTORY_RAW_BYTES,
        max_archive_file_bytes=MAX_ARCHIVE_BYTES,
        historical_source_paths=manifest['historical_source_paths'],
        manifest=dict(file=manifest_path.name, bytes=len(packed), sha256=sha(manifest_path), raw_sha256=hashlib.sha256(raw).hexdigest()),
        limitations=limitations, publication_attempted=False, hosted_integration_complete=False)
    for path in (*[LOCAL / name for name in partitions], manifest_path):
        target = DEST / path.name
        with target.open('xb') as stream:
            stream.write(path.read_bytes())
        assert sha(target) == sha(path)
    save(DEST / (STEM + '.json'), index)
    save(LOCAL / 'verification.json', dict(status='all_members_reopened', member_count=len(seen),
        archives=[identity(LOCAL / name) for name in partitions],
        manifest=identity(manifest_path), index=identity(DEST / (STEM + '.json')),
        helper=identity(__file__)))
    print(json.dumps(dict(status=index['status'], members=len(seen), raw_bytes=raw_size)))


if __name__ == '__main__':
    main()


