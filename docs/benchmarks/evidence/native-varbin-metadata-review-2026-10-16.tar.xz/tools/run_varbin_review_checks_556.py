"""Re-run all six Rust gates against the frozen constructor-review revision."""
import json
from pathlib import Path
import re
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, save, sha, sources
from run_stream_destination_review_checks_479 import CHECKS
from varbin_review_cost_556 import required_tests

SOURCE = OUT / 'native-release-source-varbinreview556.json'
PROTOCOL = OUT / 'varbin-review-check-protocol-556.json'
RESULT = OUT / 'varbin-review-checks-556.json'


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def unchanged():
    frozen = json.loads(SOURCE.read_text())
    assert sources() == frozen['source_sha256'] and len(frozen['source_sha256']) == 2371
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == frozen['head']
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip()
    return frozen


def main():
    frozen = unchanged()
    old_protocol = OUT / 'varbin-metadata-check-protocol-546c.json'
    old = json.loads(old_protocol.read_text())
    ignored = sorted(tuple(row) for row in old['expected_ignored'])
    assert len(ignored) == 30
    required = required_tests()
    assert len(required) == 25 and set(old['required_tests']) < required
    assert len(required - set(old['required_tests'])) == 4
    save(PROTOCOL, dict(source=identity(SOURCE), helper=identity(__file__), checks=CHECKS,
        guard=identity(OUT / 'run_guarded.py'), previous_protocol=identity(old_protocol),
        expected_ignored=ignored, required_tests=sorted(required), all_gates_fresh=True))
    completed, failure = [], None
    try:
        for label, timeout, command in CHECKS:
            assert unchanged() == frozen
            name = 'varbin-review-' + label + '-556'
            print(json.dumps(dict(stage=label, status='starting')), flush=True)
            subprocess.run([sys.executable, '-B', str(OUT / 'run_guarded.py'),
                '--name', name, '--timeout', str(timeout), '--', *command], cwd=ROOT, check=True)
            path = OUT / (name + '.json')
            record, log = json.loads(path.read_text()), path.with_suffix('.log')
            assert record['status'] == 'passed' and record['returncode'] == 0
            assert record['process_group_drained'] and record['direct_child_reaped']
            assert not record['timed_out'] and not record['group_absence_unproved_at_cleanup']
            assert record['head'] == frozen['head'] and not record['working_tree']
            assert sha(log) == record['log_sha256'] and record['command'] == command
            row = dict(stage=label, receipt=identity(path), log=identity(log))
            if label.endswith('tests'):
                raw = log.read_text()
                groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', raw)
                assert groups and all(int(g[1]) == int(g[3]) == int(g[4]) == 0 for g in groups)
                observed = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', raw, re.M)
                assert sum(int(g[2]) for g in groups) == len(observed)
                if label == 'native-tests':
                    assert sorted(observed) == ignored
                    for test in required:
                        assert re.search(r'^test .*::' + re.escape(test) + r' \.\.\. ok$', raw, re.M), test
                else:
                    assert not observed
                row['tests'] = dict(passed=sum(int(g[0]) for g in groups), failed=0,
                    ignored=len(observed), groups=len(groups), ignored_declarations=observed)
            completed.append(row)
            print(json.dumps(dict(stage=label, status='passed', passed=row.get('tests', {}).get('passed'))), flush=True)
        assert unchanged() == frozen
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        save(RESULT, dict(status='passed' if failure is None else 'failed', failure=failure,
            source=identity(SOURCE), protocol=identity(PROTOCOL), completed=completed,
            source_identity_preserved=sources() == frozen['source_sha256']))


if __name__ == '__main__':
    main()
