"""Verify metadata ownership documentation against accepted runtime evidence."""
import csv
from decimal import Decimal
import json
import re
import subprocess
import sys
import time

from freeze_native_release_298 import ROOT, OUT, sha, sources, save

DEST = OUT / 'varbin-review-documentation-560'
SOURCE = OUT / 'native-release-source-varbinreview560.json'
NODE = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
SITE = ROOT / 'website-src'
STEM = 'native-varbin-metadata-review-2026-10-16'


def main():
    accepted = json.loads(SOURCE.read_text())['source_sha256']
    assert sources() == accepted and not DEST.exists()
    index_path = ROOT / 'docs/benchmarks/evidence' / (STEM + '.json')
    index = json.loads(index_path.read_text())
    assert index['status'] == 'passed_local' and index['independent_packet_audit_passed']
    assert index['source_manifest']['sha256'] == sha(SOURCE)
    assert index['accepted_commit'] == '2d5d82a1e810a86d7da1827bcc9a2ec08993b65e'
    member_count = f"{index['member_count']:,}"
    raw_bytes = f"{index['raw_bytes']:,}"
    workflow = sha(ROOT / '.github/workflows/ci.yml')
    DEST.mkdir()
    hardware = dict(observation_stage='documentation validation on the same local host',
        physical_memory_bytes=int(subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.memsize'], text=True)),
        model=subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.model'], text=True).strip(),
        processor=subprocess.check_output(['/usr/sbin/sysctl', '-n', 'machdep.cpu.brand_string'], text=True).strip())
    save(DEST / 'hardware.json', hardware)
    node = lambda *args: [NODE, *map(str, args)]
    python = lambda *args: [sys.executable, '-B', *map(str, args)]
    commands = [
        ('search-policy', node('--test', 'scripts/pagefind-policy.test.mjs'), SITE),
        ('static-reset', node('scripts/prebuild-static.mjs', '--reset-output'), SITE),
        ('sync-content', node('scripts/sync-content.mjs'), SITE),
        ('astro-build', node('node_modules/astro/bin/astro.mjs', 'build'), SITE),
        ('static-postbuild', node('scripts/postbuild-static.mjs'), SITE),
        ('check-preparation', node('scripts/prebuild-static.mjs'), SITE),
        ('check-content', node('scripts/sync-content.mjs'), SITE),
        ('astro-check', node('node_modules/astro/bin/astro.mjs', 'check'), SITE),
        ('check-settle', node('scripts/prebuild-static.mjs', '--settle-output'), SITE),
        ('public-status', python('scripts/check_public_status_docs.py', '--output', DEST / 'public-status.json'), ROOT),
        ('website-links', python('-m', 'unittest', 'discover', '-s', 'scripts', '-p', 'test_website_links.py'), ROOT),
        ('website-readiness', python('scripts/check_website_readiness.py', '--output', DEST / 'website-readiness.json'), ROOT),
        ('static-assets', node('scripts/validate_static_assets.cjs'), ROOT),
        ('user-surface', python('scripts/check_user_surface_reference.py'), ROOT),
        ('use-case-backlinks', python('scripts/check_use_case_backlinks.py'), ROOT),
        ('contribution-governance', python('scripts/check_contribution_governance.py', '--output', DEST / 'contribution-governance.json'), ROOT),
        ('ci-gate-matrix', python('scripts/check_ci_gate_matrix.py', '--output', DEST / 'ci-gate-matrix.json'), ROOT),
        ('v1-inclusion', python('scripts/check_v1_inclusion_scope.py'), ROOT),
        ('license-bundle', python('scripts/check_python_license_bundle.py'), ROOT),
        ('diff-check', ['git', 'diff', '--check'], ROOT),
    ]
    completed, failure, links = [], None, []
    try:
        for name, command, cwd in commands:
            log = DEST / (name + '.log')
            start = time.monotonic()
            with log.open('xb') as output:
                result = subprocess.run(command, cwd=cwd, stdout=output, stderr=subprocess.STDOUT, timeout=300)
            completed.append(dict(name=name, command=command, cwd=str(cwd), returncode=result.returncode,
                seconds=time.monotonic() - start, log=str(log), log_sha256=sha(log)))
            print(json.dumps(dict(name=name, returncode=result.returncode)), flush=True)
            result.check_returncode()
        changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT, text=True).splitlines()
        untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=ROOT, text=True).splitlines()
        for name in sorted(name for name in set(changed + untracked) if name.endswith('.md')):
            path = ROOT / name
            for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^\s)]+)\)', path.read_text()):
                if target.startswith(('https:', 'http:', 'mailto:', '#')):
                    continue
                assert (path.parent / target.split('#', 1)[0]).resolve().exists(), (name, target)
                links.append(dict(document=name, target=target))
        assert sources() == accepted and sha(ROOT / '.github/workflows/ci.yml') == workflow
        for name in ('runtime-and-io', 'limitations'):
            text = re.sub(r'\s+', ' ', (ROOT / 'website/field-guide' / name / 'index.html').read_text())
            for literal in (STEM + '.md', '4,827 public cases', '3,587 standalone provider tests',
                            member_count, 'Hosted integration remains pending', '0.6.0',
                            'PR #1562', 'caller-owned', 'general builder/compaction scratch'):
                assert literal in text, (name, literal)
        report = (ROOT / 'docs/benchmarks' / (STEM + '.md')).read_text()
        table = re.findall(r'^\| Q(\d+) \| (\d+\.\d+) \|$', report, re.MULTILINE)
        with (ROOT / 'docs/benchmarks/evidence' / (STEM + '.engine-times.csv')).open(newline='') as stream:
            rows = list(csv.DictReader(stream))
        assert table == [(f"{int(row['query']):02}", row['engine_execution_seconds']) for row in rows]
        assert len(table) == 43 and sum(Decimal(value) for _, value in table) == Decimal(index['engine_execution_seconds_decimal'])
        for literal in ('4,827', '4,319', '3,221', '3,587', '164', '100', member_count,
                        raw_bytes, 'Hosted integration remains pending', '9,728', '2,432',
                        'six rejected comparisons', 'no repeated cost breach'):
            assert literal in report, literal
        assert json.loads(index_path.read_text()) == index
        assert index['status'] == 'passed_local' and index['independent_packet_audit_passed']
        assert index['hosted_integration_complete'] is False and not index['installed_wheel_proof']
        assert index['member_count'] > 18023 and index['source_overlay_verified']
        assert index['all_archive_partitions_verified'] and index['rejected_comparisons_preserved'] == 6
        assert len(index['archives']) == 4
        for item in [*index['archives'].values(), *[index[kind] for kind in ('manifest', 'audit', 'engine_timings')]]:
            path = ROOT / 'docs/benchmarks/evidence' / item['file']
            assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256']
    except BaseException as error:
        failure = f'{type(error).__name__}: {error}'
        raise
    finally:
        save(DEST / 'summary.json', dict(status='passed' if failure is None else 'failed',
            failure=failure, checks=completed, local_links=links,
            selected_sources_unchanged=sources() == accepted, source_files=len(accepted),
            workflow_sha256=workflow, source_manifest=dict(path=str(SOURCE), sha256=sha(SOURCE)),
            helper_sha256=sha(__file__), rendered_browser_verification=False,
            generator_sha256=sha(SITE / 'scripts/sync-content.mjs'), hardware=hardware,
            scope='Reviewed safe text/binary buffer-table construction, checked validation reuse and ownership; unchanged 0.6.0 package scope.',
            native_workloads_rerun=False))
    print(json.dumps(dict(status='passed', checks=len(completed), local_links=len(links))))


if __name__ == '__main__':
    main()

