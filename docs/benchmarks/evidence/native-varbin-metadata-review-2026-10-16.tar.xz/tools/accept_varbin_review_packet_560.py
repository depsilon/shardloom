"""Record primary local acceptance after complete VarBin metadata archive inspection."""
import csv
from decimal import Decimal
import hashlib
import io
import json
import lzma
import math
from pathlib import Path
import subprocess

from run_varbin_review_acceptance_560 import OUT, ROOT, identity
from freeze_native_release_298 import sources

STEM = 'native-varbin-metadata-review-2026-10-16'
DEST = ROOT / 'docs/benchmarks/evidence'


def unchanged():
    frozen = json.loads((OUT / 'native-release-source-varbinreview560.json').read_text())
    assert sources() == frozen['source_sha256'] and len(frozen['source_sha256']) == 2371
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == frozen['head']
    assert frozen['head'] == '2d5d82a1e810a86d7da1827bcc9a2ec08993b65e'
    return frozen


def main():
    frozen = unchanged()
    index_path = DEST / (STEM + '.json')
    original = index_path.read_bytes()
    index = json.loads(original)
    audit_path = OUT / 'varbin-review-packet-audit-560.json'
    audit = json.loads(audit_path.read_text())
    assert index['schema_version'] == 'shardloom.native_varbin_metadata_review_evidence.v2'
    assert audit['accepted_commit'] == index['accepted_commit'] == frozen['head']
    assert index['status'] == 'packaged_local_pending_acceptance_decision'
    assert audit['status'] == 'passed' and audit['index'] == identity(index_path)
    assert audit['member_count'] == index['member_count'] and index['member_count'] > 13000
    assert audit['raw_bytes'] == index['raw_bytes'] and index['raw_bytes'] > 0
    assert audit['archives'] == index['archives'] and len(index['archives']) == 4
    assert len(index['historical_sources_archives']) == 3
    assert audit['max_raw_bytes_per_archive'] == index['max_raw_bytes_per_archive'] == 256 * 1024 ** 2
    assert audit['max_historical_raw_bytes_per_archive'] == index['max_historical_raw_bytes_per_archive'] == 96 * 1024 ** 2
    assert audit['max_archive_file_bytes'] == index['max_archive_file_bytes'] == 100 * 1024 ** 2
    assert all(row['raw_bytes'] <= 256 * 1024 ** 2 and row['bytes'] < 100 * 1024 ** 2
               for row in index['archives'].values())
    assert all(row['raw_bytes'] <= 96 * 1024 ** 2 for row in index['historical_sources_archives'])
    assert sum(row['raw_bytes'] for row in index['archives'].values()) == index['raw_bytes']
    assert audit['historical_source_snapshots_verified'] == 6
    assert audit['complete_archive_identity_and_membership_verified']
    assert audit['current_source_map_unchanged'] and audit['source_overlay_verified']
    assert audit['source_files'] == 2371 and len(audit['new_native_test_names']) == 25
    fixture = audit['test_fixture_bridge']
    assert fixture['status'] == 'passed' and fixture['production_sources_unchanged']
    assert fixture['native_tests_fresh'] and len(fixture['changed_test_files']) == 3
    assert fixture['unchanged_source_files'] == 2368 and fixture['accepted_commit'] == frozen['head']
    assert fixture['measured_commit'] == audit['measured_cost_commit'] == index['measured_cost_commit']
    assert fixture['bridge'] == index['test_fixture_bridge']
    assert audit['direct_methods'] == 100 and audit['direct_skips'] == 0
    assert audit['public']['cases'] == 4827 and audit['public']['families'] == 36
    assert audit['full43']['calls'] == audit['full43']['queries'] == 43
    assert audit['full43']['repeats'] == 1 and audit['full43']['complete_rows'] == 381
    for order in ('forward', 'reverse'):
        observed = audit['lifecycle'][order]
        if observed is not None:
            assert observed['all_input_hashes_equal'] and observed['all_serialized_outputs_equal']
            assert observed['distinct_cases'] == 32 and observed['complete_operations'] == 4864
    forward, reverse = (audit['lifecycle'][key] for key in ('forward', 'reverse'))
    assert bool(forward['breaches']) == bool(reverse)
    assert not [row for row in forward['breaches'] if reverse and row in reverse['breaches']]
    decision = json.loads((OUT / 'varbin-review-cost-557/decision.json').read_text())
    assert decision['status'] == 'retained_pending_broad_acceptance' and not decision['repeated_breaches']
    assert decision['forward'] == forward['summary']
    assert decision['reverse'] == (reverse['summary'] if reverse else None)
    historical = audit['rejected_lifecycle_comparisons']
    assert [row['tag'] for row in historical] == ['550', '552', '553', '554', '555', '556']
    assert [len(row['repeated_breaches']) for row in historical] == [13, 2, 1, 1, 1, 1]
    assert all(row['complete_source_snapshot_bytes_verified'] for row in historical)
    assert audit['profiling_clocks_excluded_from_acceptance']
    assert audit['vendor']['source_files_verified'] == 841 and audit['vendor']['commands_verified'] == 8
    assert audit['registry_members_verified'] == 50 and audit['release_script_tests'] == 164
    assert audit['no_speedup_claim'] and not audit['hosted_integration_complete']
    assert not audit['installed_wheel_proof']
    records = {}
    for name in ('varbin-review-package-562', 'varbin-review-portable-inspection-560'):
        path = OUT / (name + '.json')
        receipt = json.loads(path.read_text())
        assert receipt['status'] == 'passed' and receipt['returncode'] == 0
        assert receipt['head'] == frozen['head'] and receipt['cwd'] == str(ROOT)
        assert receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup']
        log = path.with_suffix('.log')
        assert identity(log)['sha256'] == receipt['log_sha256']
        records[name] = dict(receipt=receipt, receipt_identity=identity(path),
                            log=log.read_text(), log_identity=identity(log))
    for item in [*index['archives'].values(), index['manifest']]:
        current = identity(DEST / item['file'])
        assert current['sha256'] == item['sha256'] and current['bytes'] == item['bytes']
    supplement = dict(status='passed_primary_local_acceptance', original_index_utf8=original.decode(),
        original_index_identity=audit['index'], independent_audit=audit,
        independent_audit_identity=identity(audit_path), supervision=records, helper=identity(__file__))
    raw = (json.dumps(supplement, indent=2, sort_keys=True) + '\n').encode()
    packed = lzma.compress(raw)
    assert lzma.decompress(packed) == raw
    supplement_path = DEST / (STEM + '.audit.json.xz')
    timing_path = DEST / (STEM + '.engine-times.csv')
    table_path = OUT / 'varbin-review-engine-table-560.md'
    assert not any(path.exists() for path in (supplement_path, timing_path, table_path))
    review = json.loads((OUT / 'varbin-review-full43-review-560.json').read_text())
    assert review['status'] == 'passed' and review['all_values_schemas_and_clocks_reopened']
    assert review['resources_no_fallback_native_certificates'] and review['native_children_absent']
    assert review['original_input_and_sources_unchanged'] and not review['performance_claim_allowed']
    full_csv = Path(review['timing_csv']['path'])
    assert identity(full_csv) == review['timing_csv']
    with full_csv.open(newline='') as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == 43 and [int(row['query']) for row in rows] == list(range(1, 44))
    assert all(row['run'] == '1' and row['passed'] == 'True' and row['engine_timing_reported'] == 'True' for row in rows)
    total = sum(Decimal(row['engine_execution_seconds']) for row in rows)
    assert all(Decimal(row['engine_execution_seconds']).is_finite()
               and Decimal(row['engine_execution_seconds']) >= 0 for row in rows)
    assert math.isclose(float(total), audit['engine_execution_seconds'], rel_tol=0, abs_tol=1e-9)
    output = io.StringIO(newline='')
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(['query', 'run', 'engine_execution_seconds'])
    writer.writerows([row['query'], row['run'], f"{Decimal(row['engine_execution_seconds']):.9f}"] for row in rows)
    table = '| Query | Engine seconds |\n| --- | ---: |\n' + ''.join(
        f"| Q{int(row['query']):02} | {Decimal(row['engine_execution_seconds']):.9f} |\n" for row in rows)
    unchanged()
    assert index_path.read_bytes() == original
    with supplement_path.open('xb') as stream:
        stream.write(packed)
    with timing_path.open('x') as stream:
        stream.write(output.getvalue())
    with table_path.open('x') as stream:
        stream.write(table)
    index.update(status='passed_local', independent_packet_audit_passed=True,
        source_overlay_verified=True, installed_wheel_proof=False,
        rejected_comparisons_preserved=6, diagnostic_profile_excluded_from_acceptance=True,
        all_archive_partitions_verified=True, test_only_source_transition_verified=True,
        audit=dict(file=supplement_path.name, bytes=len(packed), sha256=hashlib.sha256(packed).hexdigest()),
        engine_execution_seconds=float(total), engine_execution_seconds_decimal=str(total), engine_timings=dict(file=timing_path.name,
            bytes=timing_path.stat().st_size, sha256=identity(timing_path)['sha256']))
    index_path.write_text(json.dumps(index, indent=2) + '\n')
    assert json.loads(index_path.read_text()) == index
    print(json.dumps(dict(status='passed_local', members=index['member_count'], engine_execution_seconds=float(total))))


if __name__ == '__main__':
    main()

