"""Independently verify every portable metadata-ownership evidence member and result."""
import io
import hashlib
import json
import lzma
from pathlib import Path
import re
import tarfile
import tomllib

from metadata_public_verifier_534 import verify_public
import verify_varbin_metadata_cost_546 as cost
from verify_varbin_review_vendor_archive_555 import verify_vendor
from verify_stream_unary_packet_497 import need, digest, strict_json, safe_member, verify_full43

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
DEST = ROOT / 'docs/benchmarks/evidence'
STEM = 'native-varbin-metadata-review-2026-10-16'
BASE = '0f8de6a913ca3bb8a170ddeb3c175c24eb521e64'
ACCEPTED = '2401bc565a984704b81b61edd16db223b7472b55'
OUTPUT = OUT / 'varbin-review-packet-audit-555.json'
cost.D = OUT / 'varbin-review-cost-555'


def main():
    need(not OUTPUT.exists(), 'preserve earlier evidence inspection')
    index_path = DEST / (STEM + '.json')
    index = strict_json(index_path.read_bytes())
    need(index['schema_version'] == 'shardloom.native_varbin_metadata_review_evidence.v2' and
         index['status'] == 'packaged_local_pending_acceptance_decision' and index['base_commit'] == BASE and index['accepted_commit'] == ACCEPTED,
         'unexpected packet identity or status')
    history_names = [STEM + '.historical-sources-' + str(i) + '.tar.xz' for i in (1, 2)]
    need([row['file'] for row in index['historical_sources_archives']] == history_names,
         'unexpected historical archive inventory')
    entries = [(index['archive'], STEM + '.tar.xz'),
               (index['manifest'], STEM + '.manifest.json.xz')]
    entries += list(zip(index['historical_sources_archives'], history_names, strict=True))
    for item, expected_name in entries:
        path = DEST / item['file']
        need(path.name == expected_name and path.is_file() and not path.is_symlink(), 'unsafe packet path')
        need(path.stat().st_size == item['bytes'] and item['bytes'] < 100 * 1024 ** 2,
             'compressed packet member exceeds the declared file bound')
        data = path.read_bytes()
        need(len(data) == item['bytes'] and digest(data) == item['sha256'], 'packet identity mismatch')
    raw_manifest = lzma.decompress((DEST / index['manifest']['file']).read_bytes())
    need(digest(raw_manifest) == index['manifest']['raw_sha256'], 'decoded manifest identity mismatch')
    manifest = strict_json(raw_manifest)
    need(manifest['status'] == 'passed_local_evidence_packaged' and manifest['base_commit'] == BASE,
         'unexpected manifest scope')
    for key in ('member_count', 'raw_bytes', 'source_files', 'source_overlay', 'acceptance',
                'source_manifest', 'artifact_manifest', 'all_members_reopened', 'accepted_commit',
                'archives', 'max_raw_bytes_per_archive', 'historical_source_paths',
                'max_historical_raw_bytes_per_archive', 'max_archive_file_bytes'):
        need(index[key] == manifest[key], 'index/manifest differs: ' + key)
    limit = 256 * 1024 ** 2
    history_limit, file_limit = 96 * 1024 ** 2, 100 * 1024 ** 2
    archive_names = {STEM + '.tar.xz', *history_names}
    need(index['all_members_reopened'] and index['max_raw_bytes_per_archive'] == limit and
         set(index['archives']) == archive_names and index['source_files'] == 2371 and
         index['max_historical_raw_bytes_per_archive'] == history_limit and
         index['max_archive_file_bytes'] == file_limit,
         'invalid archive bounds')
    need(index['archive'] == index['archives'][STEM + '.tar.xz'] and
         index['historical_sources_archives'] == [index['archives'][name] for name in history_names],
         'archive identities differ')
    need(all(row['file'] == name and row['raw_bytes'] <= (history_limit if name in history_names else limit) and
             row['bytes'] < file_limit for name, row in index['archives'].items()) and
         sum(row['raw_bytes'] for row in index['archives'].values()) == index['raw_bytes'],
         'archive raw-byte accounting differs')
    history_paths = {str(OUT / ('varbin-review-cost-' + tag) / ('candidate-source-' + tag + '.json'))
                     for tag in ('550', '552', '553', '554')}
    need(set(index['historical_source_paths']) == history_paths, 'historical source selection differs')
    expected, originals = {}, {}
    for row in manifest['members']:
        name = row['archive_path']
        safe_member(name)
        need(name not in expected and row['path'] not in originals, 'duplicate archived identity')
        expected[name], originals[row['path']] = row, name
    need(history_paths <= set(originals), 'historical source member missing')
    history_partition, partition_index, partition_size = {}, 0, 0
    for path in sorted(history_paths):
        size = expected[originals[path]]['bytes']
        need(0 <= size <= history_limit, 'historical source exceeds its archive bound')
        if partition_size and partition_size + size > history_limit:
            partition_index += 1
            partition_size = 0
        need(partition_index < len(history_names), 'too many historical archive partitions')
        history_partition[path] = history_names[partition_index]
        partition_size += size
    need(set(history_partition.values()) == set(history_names), 'historical partition coverage differs')
    for row in expected.values():
        need(row['archive_file'] == history_partition.get(row['path'], STEM + '.tar.xz'), 'wrong archive partition')
    need(index['archive']['raw_bytes'] + max(expected[originals[p]]['bytes'] for p in history_paths) <= limit,
         'retained archive payload plus one historical source exceeds the unchanged byte bound')
    members, historical_sources, seen = {}, {}, set()
    total_bytes = 0
    for archive_name, archive_info in index['archives'].items():
        partition_bytes, partition_count = 0, 0
        with tarfile.open(DEST / archive_name, mode='r|xz') as archive:
            for entry in archive:
                need(entry.isfile() and entry.name in expected and entry.name not in seen,
                     'unexpected, repeated or non-file archive member')
                safe_member(entry.name)
                row = expected[entry.name]
                need(row['archive_file'] == archive_name and entry.size == row['bytes'] and
                     partition_bytes + entry.size <= archive_info['raw_bytes'] <= limit,
                     'archive partition or member size differs')
                with archive.extractfile(entry) as stream:
                    data = stream.read()
                need(len(data) == entry.size and digest(data) == row['sha256'], entry.name)
                if row['path'] in history_paths:
                    source_fields = strict_json(data)
                    need(isinstance(source_fields.pop('diff_base64'), str), 'historical Git diff missing')
                    historical_sources[row['path']] = dict(
                        identity=dict(path=row['path'], bytes=len(data), sha256=row['sha256']),
                        source_fields=source_fields)
                else:
                    members[entry.name] = data
                seen.add(entry.name)
                partition_count += 1
                partition_bytes += len(data)
                del data
        need(partition_count == archive_info['member_count'] and partition_bytes == archive_info['raw_bytes'],
             'archive partition coverage differs')
        total_bytes += partition_bytes
    need(seen == set(expected) and len(seen) == manifest['member_count'] and
         total_bytes == manifest['raw_bytes'] and set(historical_sources) == history_paths,
         'incomplete archive coverage')

    def by_path(path):
        key = str(path)
        need(key in originals, 'bound evidence absent from archive: ' + key)
        need(originals[key] in members, 'large historical source must use its verified compact fields: ' + key)
        return members[originals[key]]

    def reference(item):
        data = by_path(item['path'])
        need(len(data) == item['bytes'] and digest(data) == item['sha256'], 'bound identity differs: ' + item['path'])
        return data

    def archived_identity(path):
        key = str(path)
        need(key in originals and originals[key] in seen, 'identity was not verified from archived bytes')
        row = expected[originals[key]]
        return dict(path=key, bytes=row['bytes'], sha256=row['sha256'])

    source = strict_json(reference(manifest['source_manifest']))
    artifacts = strict_json(reference(manifest['artifact_manifest']))
    need(source['head'] == artifacts['head'] == ACCEPTED and source['source_sha256'] == artifacts['source_sha256'] and
         artifacts['status'] == 'passed' and artifacts['build_profile'] == 'release', 'source/build binding differs')
    source_map = source['source_sha256']
    need(len(source_map) == 2371 and len(manifest['source_overlay']) == 98, 'source or overlay count differs')
    for name in manifest['source_overlay']:
        need(digest(members['source-overlay/' + name]) == source_map[name], 'source overlay differs: ' + name)
    baseline = strict_json(reference(manifest['baseline_provider_provenance']))
    need(baseline['status'] == 'passed' and baseline['commit'] == BASE, 'wrong baseline provider revision')
    need(set(baseline['providers']) == {'vortex-array', 'vortex-zstd'}, 'baseline provider inventory differs')
    for item in [*baseline['providers'].values(), baseline['cargo_lock'], baseline['original_contract']]:
        raw = item['utf8'].encode()
        need(len(raw) == item['bytes'] and digest(raw) == item['sha256'], 'baseline blob content differs')
        need(hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == item['git_blob_oid'],
             'baseline Git blob identity differs')
    bundle = strict_json(members['source-overlay/python/THIRD_PARTY_LICENSES/manifest.json'])
    def contains_provenance(value, provenance):
        if value == provenance:
            return True
        if isinstance(value, dict):
            return any(contains_provenance(child, provenance) for child in value.values())
        if isinstance(value, list):
            return any(contains_provenance(child, provenance) for child in value)
        return False
    provenances = {}
    for provider in ('vortex-array', 'vortex-fsst', 'vortex-runend', 'vortex-zstd'):
        provenance = strict_json(members['source-overlay/vendor/' + provider + '/upstream-provenance.json'])
        need(contains_provenance(bundle, provenance), 'Python bundle lacks exact provenance: ' + provider)
        provenances[provider] = provenance
        if provider in baseline['providers']:
            original = baseline['providers'][provider]
            need(strict_json(original['utf8']) == original['value'], 'baseline provenance text differs')
            changed = {key for key in set(original['value']) | set(provenance)
                       if original['value'].get(key) != provenance.get(key)}
            expected_changes = ({'supplemental_test_files', 'standalone_lint_compatibility', 'varbin_metadata_changes'}
                                if provider == 'vortex-array' else {'varbin_metadata_changes'})
            need(changed == expected_changes, 'provider upstream provenance changed: ' + provider)
        for relative, item in provenance.get('supplemental_test_files', {}).items():
            raw = members['source-overlay/vendor/' + provider + '/' + relative]
            need(len(raw) == item['bytes'] and digest(raw) == item['sha256'], 'supplemental fixture differs')
            need(hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == item['git_blob_sha1'],
                 'supplemental upstream Git blob differs')
    intake = strict_json(by_path(OUT / 'varbinview-provenance-intake-541/inventory.json'))
    need({item['name'] for item in intake['packages']} == {'vortex-fsst', 'vortex-runend'}, 'new provider intake differs')
    registry_members = 0
    for item in intake['packages']:
        provider = item['name']
        provenance = provenances[provider]
        raw = by_path(item['archive'])
        need(digest(raw) == item['archive_sha256'] == item['lock']['checksum'] ==
             provenance['registry_archive_sha256'], 'registry archive checksum differs')
        registry_seen = {}
        with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
            for entry in archive:
                need(entry.isfile(), 'registry archive contains a non-regular member')
                prefix = provider + '-0.85.0/'
                need(entry.name.startswith(prefix), 'wrong registry member prefix')
                name = entry.name.removeprefix(prefix)
                safe_member(name)
                need(name not in registry_seen, 'duplicate registry member')
                with archive.extractfile(entry) as stream:
                    registry_seen[name] = digest(stream.read())
        need(registry_seen == item['archive_files_sha256'] == provenance['original_files_sha256'] and len(registry_seen) == 25,
             'original provider source members differ')
        registry_members += len(registry_seen)
        need(provenance['license'] == 'Apache-2.0' and provenance['version'] == '0.85.0' and
             provenance['upstream_vcs_dirty'] is True, 'provider license/version/provenance boundary differs')
        need(digest(members['source-overlay/vendor/' + provider + '/LICENSE']) == provenance['license_sha256'],
             'provider license bytes differ')
    old_lock = tomllib.loads(baseline['cargo_lock']['utf8'])
    new_lock = tomllib.loads(members['source-overlay/Cargo.lock'].decode())
    for provider in ('vortex-fsst', 'vortex-runend'):
        old, = [item for item in old_lock['package'] if item['name'] == provider]
        new, = [item for item in new_lock['package'] if item['name'] == provider]
        need(old['version'] == new['version'] == '0.85.0', 'provider version changed')
        need(old.pop('checksum') == provenances[provider]['registry_archive_sha256'], 'original lock checksum differs')
        need(old.pop('source') == 'registry+https://github.com/rust-lang/crates.io-index', 'original lock source differs')
        need(old == new, 'provider lock changed beyond local patch source')
    need(old_lock == new_lock, 'dependency graph changed beyond two same-version local patch sources')
    for name, expected_sha in source_map.items():
        path = ROOT / name
        need(path.is_file() and not path.is_symlink() and digest(path.read_bytes()) == expected_sha,
             'current source changed: ' + name)
    excluded = {row['original_absolute_path']: row for row in manifest['exclusions']}
    for kind in ('cli', 'binding'):
        item = artifacts[kind]
        need(item['path'] in excluded and excluded[item['path']]['byte_count'] == item['bytes'] and
             excluded[item['path']]['sha256'] == item['sha256'], 'executable exclusion identity differs')
        build_receipt = strict_json(by_path(item['build_receipt']))
        need(digest(by_path(item['build_receipt'])) == item['build_receipt_sha256'] and
             build_receipt['head'] == ACCEPTED and '--release' in build_receipt['command'] and
             digest(by_path(item['build_log'])) == build_receipt['log_sha256'], 'release build recipe differs')
    for row in manifest['final_receipts']:
        result = strict_json(reference(row))
        need(result['status'] == 'passed' and result['returncode'] == 0 and result['head'] == ACCEPTED and
             result['process_group_drained'] and result['direct_child_reaped'] and
             not result['timed_out'] and not result['group_absence_unproved_at_cleanup'], 'final process gate incomplete')
        need(digest(by_path(Path(row['path']).with_suffix('.log'))) == result['log_sha256'], 'supervisor log differs')
    checks = strict_json(by_path(OUT / 'varbin-review-checks-555.json'))
    test_protocol = strict_json(reference(checks['protocol']))
    need(checks['status'] == 'passed' and checks['source_identity_preserved'] and
         checks['source'] == manifest['source_manifest'], 'broad gate source differs')
    need(sorted(row['stage'] for row in checks['completed']) ==
         sorted(['fmt', 'workspace-clippy', 'workspace-tests', 'read-clippy', 'release-clippy', 'native-tests']), 'broad gates missing')
    counts = {}
    gates = {}
    for name in ('shardloom-vortex/src/lib.rs', 'shardloom-vortex/src/resident_memory_source.rs',
                 'shardloom-vortex/Cargo.toml', 'shardloom-cli/Cargo.toml'):
        data = by_path(ROOT / name)
        need(digest(data) == source_map[name], 'feature gate source differs: ' + name)
        gates[name] = data.decode()
    need('#[cfg(feature = "vortex-local-primitives")]\nmod native_provider_memory;' in
         gates['shardloom-vortex/src/lib.rs'], 'default provider test exclusion changed')
    need('#[cfg(feature = "vortex-write")]\n#[path = "resident_memory_encoded_transfer.rs"]\nmod encoded_transfer;' in
         gates['shardloom-vortex/src/resident_memory_source.rs'], 'read-only transfer exclusion changed')
    vortex_features = tomllib.loads(gates['shardloom-vortex/Cargo.toml'])['features']
    cli_features = tomllib.loads(gates['shardloom-cli/Cargo.toml'])['features']
    need(vortex_features['default'] == [] and cli_features['default'] == [], 'default feature selection changed')
    def enabled_local(features, requested):
        pending, seen = list(requested), set()
        while pending:
            name = pending.pop()
            if name in seen:
                continue
            seen.add(name)
            pending.extend(features.get(name, []))
        return seen
    vortex_read = enabled_local(vortex_features, ['vortex-local-primitives'])
    cli_read = enabled_local(cli_features, ['vortex-local-primitives'])
    need('vortex-write' not in vortex_read and 'shardloom-vortex/vortex-write' not in cli_read,
         'read-only feature unexpectedly enables native transfer tests')
    for row in checks['completed']:
        log = reference(row['log']).decode()
        broad = strict_json(reference(row['receipt']))
        need(broad['status'] == 'passed' and broad['returncode'] == 0 and
             broad['process_group_drained'] and broad['direct_child_reaped'] and
             not broad['timed_out'] and not broad['group_absence_unproved_at_cleanup'] and
             broad['log_sha256'] == row['log']['sha256'], 'broad process gate incomplete')
        need(broad['head'] == ACCEPTED and not broad['working_tree'], 'broad gate was not fresh on the accepted source')
        if row['stage'].endswith('tests'):
            groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', log)
            need(groups and all(int(g[1]) == int(g[3]) == int(g[4]) == 0 for g in groups), 'failed or filtered broad tests')
            counts[row['stage']] = (sum(int(g[0]) for g in groups), sum(int(g[2]) for g in groups))
        if row['stage'] == 'native-tests':
            ignored = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', log, re.M)
            need(sorted(ignored) == sorted(tuple(x) for x in test_protocol['expected_ignored']), 'manual exclusions changed')
            need(len(test_protocol['required_tests']) == 25, 'new native coverage missing')
            for name in test_protocol['required_tests']:
                need(re.search(r'^test .*::' + re.escape(name) + r' \.\.\. ok$', log, re.M), name)
    need(counts == {'workspace-tests': (3221, 0), 'native-tests': (4319, 30)}, 'broad test totals differ')
    previous = strict_json(by_path(OUT / 'zstd-metadata-checks-532.json'))
    old_ignored = {tuple(item) for row in previous['completed'] if row['stage'] == 'native-tests'
                   for item in row['tests']['ignored_declarations']}
    actual_ignored = {tuple(item) for item in test_protocol['expected_ignored']}
    need(old_ignored <= actual_ignored and len(actual_ignored - old_ignored) == 1, 'manual exclusions changed')
    extra, = actual_ignored - old_ignored
    need(extra[0].endswith('::native_varbin_metadata_complete_lifecycle_cost_screen'), 'unexpected new exclusion')
    vendor = verify_vendor(by_path, source_map)
    need(vendor['test_totals']['passed'] == 3587 and vendor['source_files_verified'] == 841, 'provider proof differs')
    source_review = strict_json(by_path(OUT / 'varbin-review-source-review-555.json'))
    need(source_review['status'] == 'passed' and source_review['review_kind'] == 'primary_static_review' and
         source_review['source_snapshot'] == manifest['source_manifest'] and source_review['head'] == ACCEPTED and
         not source_review['unresolved_in_scope_findings'], 'primary source review differs')
    for key in ('helper', 'source_snapshot', 'review_comments', 'preceding_static_review',
                'preceding_source_snapshot', 'prior_source', 'contract', 'rfc'):
        reference(source_review[key])
    for row in source_review['reviewed_sources']:
        item = row['source']
        data = reference(item)
        name = str(Path(item['path']).relative_to(ROOT))
        need(source_map[name] == item['sha256'], 'reviewed runtime source differs')
        lines = data.decode().splitlines()
        for marker, anchors in row['anchors'].items():
            need(anchors == [i+1 for i, line in enumerate(lines) if marker in line], 'review source anchors differ')
    for item in source_review['test_sources']:
        reference(item)
        need(source_map[str(Path(item['path']).relative_to(ROOT))] == item['sha256'], 'reviewed test source differs')
    need(source_review['required_tests'] == test_protocol['required_tests'], 'reviewed test inventory differs')
    release_log = by_path(OUT / 'varbin-review-release-script-tests-555.log').decode()
    need(re.search(r'Ran 164 tests in [0-9.]+s\n\nOK\n', release_log), 'release-script checks incomplete')

    declared = strict_json(by_path(OUT / 'varbin-review-acceptance-protocol-555.json'))
    need(declared['status'] == 'predeclared' and declared['native_engine_executions'] == 0 and
         declared['source'] == manifest['source_manifest'] and declared['artifacts'] == manifest['artifact_manifest'],
         'public/direct predeclaration differs')
    need(reference(manifest['original_contract']) == reference(declared['contract']), 'predeclared contract differs')
    for item in declared['helpers'] + [declared[key] for key in ('prior_protocol', 'prior_direct', 'baseline', 'checks', 'cost', 'vendor', 'cost_inspection')]:
        reference(item)
    direct = strict_json(by_path(OUT / 'varbin-review-direct-tests-555.json'))
    need(direct['status'] == 'passed' and direct['tests'] == 100 and
         direct['failures'] == direct['errors'] == direct['skipped'] == 0 and
         direct['test_names'] == declared['expected_direct_names'], 'direct binding matrix incomplete')
    need(direct['source'] == manifest['source_manifest'] and direct['artifact_manifest'] == manifest['artifact_manifest'],
         'direct matrix used different artifacts')
    public = verify_public(members, by_path(OUT / 'varbin-review-public-555.log'), declared)
    inspected = strict_json(reference(manifest['public_inspection']))
    need(inspected['status'] == 'passed' and inspected['accepted_source'] == manifest['source_manifest'] and
         inspected['summary'] == archived_identity(OUT / 'varbin-review-public-555/summary.json'), 'public inspection binding differs')
    totals = inspected['compressed_json_totals']
    need(public['compressed_json_files'] == totals['files'] and
         public['compressed_stored_bytes'] == totals['stored_bytes'] and
         public['decoded_raw_bytes'] == totals['decoded_raw_bytes'], 'reopened public byte totals differ')
    public_summary = strict_json(members['public/summary.json'])
    for path, expected_sha in public_summary['sources'].items():
        if path in originals:
            data = by_path(path)
        elif path in excluded:
            need(excluded[path]['sha256'] == expected_sha, 'excluded public executable identity differs')
            continue
        else:
            data = members['public/logs/' + Path(path).name]
        need(digest(data) == expected_sha, 'public source snapshot differs: ' + path)

    # The same arithmetic auditor reads exclusively through the archive map here.
    cost.identity = archived_identity
    cost.read = lambda path: strict_json(by_path(path))
    cost.read_text = lambda path: by_path(path).decode()
    lifecycle = cost.read(cost.D / 'protocol.json')
    cost_decision = cost.read(cost.D / 'decision.json')
    expected_cells = [dict(kind=kind, rows=rows, encoding=encoding, chunks=chunks, grant_bytes=64 * 1024 ** 2)
        for kind in ('utf8', 'binary') for rows in (32, 65536)
        for encoding in ('canonical', 'fsst', 'zstd', 'runend') for chunks in (2, 16)]
    need(lifecycle['samples_per_case'] == 3 and lifecycle['operations_per_sample'] == 25 and
         lifecycle['recorded_warmups_per_case'] == 1 and lifecycle['cases'] == expected_cells,
         'lifecycle workload differs')
    need(lifecycle['elapsed_gate'] == dict(relative=.10, absolute_seconds_per_operation=.0001) and
         lifecycle['process_cpu_gate'] == dict(relative=.10, absolute_seconds=1) and
         lifecycle['process_rss_gate'] == dict(relative=.25, absolute_bytes=64 * 1024 ** 2), 'lifecycle cost gates differ')
    for item in lifecycle['helpers'] + [lifecycle[key] for key in
            ('contract', 'test_harness', 'baseline_git_proof')]:
        reference(item)
    for role, item in lifecycle['identities'].items():
        for key in ('manifest', 'source', 'build_receipt', 'build_log', 'test_inventory'):
            reference(item[key])
        blob = item['binary']
        need(blob['path'] in excluded and excluded[blob['path']]['sha256'] == blob['sha256'] and
             excluded[blob['path']]['byte_count'] == blob['bytes'], 'cost executable identity differs')
        build = strict_json(reference(item['build_receipt']))
        need(build['status'] == 'passed' and build['head'] == (BASE if role == 'baseline' else ACCEPTED) and build['process_group_drained'] and
             build['direct_child_reaped'] and build['command'] == item['command'] and
             build['environment'] == item['environment'] and digest(reference(item['build_log'])) == build['log_sha256'],
             'cost build recipe differs')
    cost_sources = {role: strict_json(reference(item['source'])) for role, item in lifecycle['identities'].items()}
    need(len(cost_sources['baseline']['source_sha256']) == 2068 and
         len(cost_sources['candidate']['source_sha256']) == 2115 and
         cost_sources['baseline']['head'] == BASE and cost_sources['candidate']['head'] == ACCEPTED, 'cost source identity differs')
    need(all(source_map[name] == value for name, value in cost_sources['candidate']['source_sha256'].items()),
         'lifecycle and public acceptance used different candidate source')
    test_sets = {role: {line.removesuffix(': test') for line in reference(item['test_inventory']).decode().splitlines()
                       if line.endswith(': test')} for role, item in lifecycle['identities'].items()}
    added = test_sets['candidate'] - test_sets['baseline']
    need(not test_sets['baseline'] - test_sets['candidate'] and len(added) == 25 and
         sorted(added) == lifecycle['binary_inventory_delta']['added_candidate_tests'] and
         {name.split('::')[-1] for name in added} == set(test_protocol['required_tests']), 'cost executable roles differ')
    original_contract = baseline['original_contract']
    need(original_contract['sha256'] == lifecycle['original_contract_sha256'] ==
         cost_sources['baseline']['contract_sha256'], 'original cost contract differs')
    acceptance_text = lambda text: text.split('## Acceptance protocol\n', 1)[1].split('Required verification:', 1)[0]
    original_acceptance = acceptance_text(original_contract['utf8'])
    current_acceptance = acceptance_text(reference(lifecycle['contract']).decode())
    need(original_acceptance == current_acceptance and digest(original_acceptance.encode()) ==
         lifecycle['acceptance_protocol_text_sha256'], 'predeclared acceptance gates changed')
    need(cost_sources['baseline']['harness_sha256'] == lifecycle['test_harness']['sha256'], 'cost harness changed')
    forward = cost.inspect_order('forward', lifecycle)
    reverse = cost.inspect_order('reverse', lifecycle) if forward['breaches'] else None
    need(cost_decision['forward'] == forward['summary'] and cost_decision['reverse'] == (reverse['summary'] if reverse else None),
         'cost decision summary links differ')
    repeated = [x for x in forward['breaches'] if x in reverse['breaches']] if reverse else []
    need(not repeated and not cost_decision['repeated_breaches'] and
         cost_decision['status'] == 'retained_pending_broad_acceptance', 'cost screen was not retained')
    live_cost = strict_json(reference(manifest['lifecycle_review']))
    need(live_cost['forward'] == forward and live_cost['reverse'] == reverse and
         live_cost['decision'] == archived_identity(cost.D / 'decision.json'), 'portable cost recomputation differs')
    # Recompute all rejected corrections without reading the current checkout
    # through their historical contract paths. Their immutable raw protocols,
    # samples and decision identities retain the original source/build bindings.
    selected_cost_dir, historical_costs = cost.D, []
    historical_commits = {'550': '1c001b5064f9db12403cbc66e842cf40752194a0',
                          '552': '9f431ec6567f15c629677a2915fc38fdb20ba3c4',
                          '553': '56c28387ef8c3bc057a71849eddd2afaf0cfb94d',
                          '554': 'd03e726d99e578789e90ec02eecc382710667b76'}
    for tag, expected_repeated in (('550', 13), ('552', 2), ('553', 1), ('554', 1)):
        cost.D = OUT / ('varbin-review-cost-' + tag)
        old_protocol = cost.read(cost.D / 'protocol.json')
        old_decision = cost.read(cost.D / 'decision.json')
        need(old_protocol['cases'] == expected_cells and old_protocol['samples_per_case'] == 3 and
             old_protocol['operations_per_sample'] == 25 and old_protocol['recorded_warmups_per_case'] == 1,
             'historical comparison workload differs')
        for key in ('elapsed_gate', 'process_cpu_gate', 'process_rss_gate', 'test_harness'):
            need(old_protocol[key] == lifecycle[key], 'historical comparison changed its gate or harness')
        need(old_protocol['acceptance_protocol_text_sha256'] == lifecycle['acceptance_protocol_text_sha256'] and
             old_protocol['original_contract_sha256'] == lifecycle['original_contract_sha256'],
             'historical declared acceptance changed')
        need(old_protocol['identities']['baseline']['binary'] == lifecycle['identities']['baseline']['binary'],
             'historical comparison changed the frozen baseline')
        for item in old_protocol['helpers'] + [old_protocol['baseline_git_proof']]:
            reference(item)
        old_candidate = old_protocol['identities']['candidate']
        source_proof = historical_sources[old_candidate['source']['path']]
        need(source_proof['identity'] == old_candidate['source'], 'historical source bytes differ')
        fields = source_proof['source_fields']
        need(fields['head'] == historical_commits[tag] and fields['base'] == BASE and
             not fields['status'] and len(fields['source_sha256']) == 2115 and
             fields['compiler'] == cost_sources['candidate']['compiler'], 'historical source/build recipe differs')
        broad_source = strict_json(reference(fields['broad_source']))
        need(broad_source['head'] == fields['head'] and
             all(broad_source['source_sha256'][name] == value for name, value in fields['source_sha256'].items()),
             'historical narrow/broad source inventories differ')
        for role, item in old_protocol['identities'].items():
            for key in ('manifest', 'build_receipt', 'build_log', 'test_inventory'):
                reference(item[key])
            build = strict_json(reference(item['build_receipt']))
            need(build['status'] == 'passed' and build['returncode'] == 0 and
                 build['head'] == (BASE if role == 'baseline' else fields['head']) and not build['working_tree'] and
                 build['process_group_drained'] and build['direct_child_reaped'] and
                 not build['timed_out'] and not build['group_absence_unproved_at_cleanup'] and
                 build['command'] == item['command'] == lifecycle['identities']['baseline']['command'] and
                 build['environment'] == item['environment'] == lifecycle['identities']['baseline']['environment'] and
                 digest(reference(item['build_log'])) == build['log_sha256'], 'historical build verification differs')
            blob = item['binary']
            need(blob['path'] in excluded and excluded[blob['path']]['sha256'] == blob['sha256'] and
                 excluded[blob['path']]['byte_count'] == blob['bytes'], 'historical binary identity differs')
        old_forward = cost.inspect_order('forward', old_protocol)
        old_reverse = cost.inspect_order('reverse', old_protocol)
        old_repeated = [row for row in old_forward['breaches'] if row in old_reverse['breaches']]
        need(len(old_repeated) == expected_repeated and old_decision['repeated_breaches'] == old_repeated and
             old_decision['status'] == 'needs_diagnosis', 'rejected comparison outcome differs')
        need(old_decision['protocol'] == archived_identity(cost.D / 'protocol.json') and
             old_decision['forward'] == old_forward['summary'] and old_decision['reverse'] == old_reverse['summary'],
             'historical comparison decision identity differs')
        historical_costs.append(dict(tag=tag, forward=old_forward, reverse=old_reverse,
            repeated_breaches=old_repeated, decision=archived_identity(cost.D / 'decision.json'),
            source=source_proof['identity'], source_commit=fields['head'], source_files=2115,
            complete_source_snapshot_bytes_verified=True))
    cost.D = selected_cost_dir
    full_review = strict_json(reference(manifest['full43_review']))
    admission = strict_json(reference(full_review['admission']))
    full43 = verify_full43(members, full_review, admission)
    for row in admission['prerequisite_gates'].values():
        reference(row)
    # Retain the actual failed attempts and prove their recorded outcome/log identity.
    failures = []
    for path in originals:
        if Path(path).parent != OUT or not Path(path).name.startswith(('varbin-metadata-', 'varbin-review-')) or not path.endswith('.json'):
            continue
        item = strict_json(by_path(path))
        if isinstance(item, dict) and item.get('status') == 'failed' and 'command' in item:
            need(item['process_group_drained'] and item['direct_child_reaped'] and item['returncode'] != 0,
                 'failed attempt lacks child cleanup')
            need(digest(by_path(Path(path).with_suffix('.log'))) == item['log_sha256'], 'failed log differs')
            failures.append(archived_identity(path))
    need(len(failures) >= 4, 'expected focused/vendor/lint counterevidence is missing')
    result = dict(status='passed', member_count=len(seen), raw_bytes=manifest['raw_bytes'], source_files=2371, accepted_commit=ACCEPTED, baseline_commit=BASE,
        complete_archive_identity_and_membership_verified=True, source_overlay_verified=True,
        archives=index['archives'], max_raw_bytes_per_archive=limit,
        max_historical_raw_bytes_per_archive=history_limit, max_archive_file_bytes=file_limit,
        historical_source_snapshots_verified=len(historical_sources),
        current_source_map_unchanged=True, required_test_counts=counts, vendor_tests=3587,
        vendor=vendor, registry_members_verified=registry_members, release_script_tests=164, new_native_test_names=test_protocol['required_tests'],
        direct_methods=100, direct_skips=0, public=public,
        lifecycle=dict(forward=forward, reverse=reverse), rejected_lifecycle_comparisons=historical_costs,
        full43=full43, retained_failed_attempts=failures,
        engine_execution_seconds=sum(row['engine_execution_seconds'] for row in strict_json(members['full43/summary.json'])['records']),
        index=dict(path=str(index_path), bytes=index_path.stat().st_size, sha256=digest(index_path.read_bytes())),
        helper=dict(path=__file__, sha256=digest(Path(__file__).read_bytes())),
        no_speedup_claim=True, hosted_integration_complete=False, installed_wheel_proof=False)
    with OUTPUT.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(dict(status='passed', members=len(seen), public_cases=public['cases'],
                         full43_calls=43, engine_execution_seconds=result['engine_execution_seconds'])))


if __name__ == '__main__':
    main()

