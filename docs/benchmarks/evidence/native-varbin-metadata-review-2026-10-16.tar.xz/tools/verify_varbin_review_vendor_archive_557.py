"""Verify all eight fresh provider commands from archived bytes only."""
import json
from pathlib import Path
import re

from verify_varbin_metadata_vendor_archive_547 import (
    _bytes, _json, _digest, _identity, _command_run_is_success_gated,
)

O = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
D = O / 'varbin-review-vendor-557'
PROVIDERS = ('vortex-array', 'vortex-fsst', 'vortex-runend', 'vortex-zstd')
EXPECTED = ((3357, 0, 1, 0, 0), (90, 0, 1, 0, 0), (73, 0, 0, 0, 0), (67, 0, 0, 0, 0))


def verify_vendor(by_path, source_map):
    assert len(source_map) == 2371
    primary_path = O / 'varbin-review-vendor-inspection-557.json'
    primary_bytes = _bytes(by_path, primary_path)
    primary = json.loads(primary_bytes)
    assert primary['status'] == 'passed' and primary['selected_sources_match_current']
    assert primary['all_eight_commands_fresh'] and primary['commands_verified'] == 8
    assert primary['source_files_verified'] == 841
    values = {key: _identity(by_path, primary[key]) for key in
              ('source', 'protocol', 'summary', 'receipt', 'log', 'historical_inventory', 'helper')}
    source = json.loads(values['source'])
    protocol, summary, receipt = (json.loads(values[key]) for key in ('protocol', 'summary', 'receipt'))
    assert source['source_sha256'] == source_map
    assert protocol['source'] == summary['source'] == primary['source']
    assert primary['protocol']['path'] == str(D / 'protocol.json')
    assert primary['summary']['path'] == str(D / 'summary.json')
    assert primary['receipt']['path'] == str(O / 'varbin-review-vendor-tests-557.json')
    assert primary['log']['path'] == str(O / 'varbin-review-vendor-tests-557.log')
    assert protocol['root'] == str(ROOT) and protocol['all_eight_commands_fresh']
    assert summary['status'] == 'passed' and summary['sources_unchanged'] and summary['failure'] is None
    assert summary['protocol'] == primary['protocol']
    runner = _identity(by_path, protocol['helper'])
    assert protocol['helper']['path'] == str(O / 'run_varbin_review_vendor_557.py')
    _command_run_is_success_gated(runner)
    assert receipt['command'][-1] == protocol['helper']['path']
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0
    assert receipt['head'] == source['head'] and not receipt['working_tree']
    assert receipt['log_sha256'] == primary['log']['sha256']
    assert receipt['output_bytes'] == len(values['log'])
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    assert not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup']
    assert protocol['root_lock_sha256'] == source_map['Cargo.lock']
    assert _digest(_bytes(by_path, ROOT / 'Cargo.lock')) == source_map['Cargo.lock']
    assert protocol['environment'] == {'CLIPPY_CONF_DIR': str(D)}
    assert _digest(_bytes(by_path, D / 'clippy.toml')) == protocol['clippy_config_sha256']
    assert protocol['clippy_config_sha256'] == source_map['vendor/vortex-array/clippy.toml']

    commands = []
    for provider in PROVIDERS:
        args = ['--offline', '--manifest-path', str(D / provider / 'Cargo.toml')]
        if provider == 'vortex-array':
            args += ['--features', '_test-harness,table-display']
        else:
            args += ['--config', 'patch.crates-io.vortex-array.path=' + json.dumps(str(D / 'vortex-array')),
                     '--features', 'vortex-array/table-display']
        commands += [['cargo', 'test', *args, '--lib', '--', '--test-threads=2'],
                     ['cargo', 'clippy', *args, '--lib', '--', '-D', 'warnings']]
    assert protocol['commands'] == summary['completed'] == commands
    assert list(protocol['source_files']) == list(PROVIDERS)
    assert set(summary['standalone_locks']) == set(PROVIDERS)
    verified, provider_rows = 0, []
    for provider, expected_count in zip(PROVIDERS, (765, 28, 28, 20), strict=True):
        files = protocol['source_files'][provider]
        assert len(files) == expected_count
        expected_names = {name.removeprefix('vendor/' + provider + '/') for name in source_map
                          if name.startswith('vendor/' + provider + '/') and not name.endswith('/Cargo.lock')}
        assert set(files) == expected_names
        for relative, digest in files.items():
            assert source_map['vendor/' + provider + '/' + relative] == digest
            assert _digest(_bytes(by_path, D / provider / relative)) == digest
            verified += 1
        lock = summary['standalone_locks'][provider]
        assert lock['path'] == str(D / provider / 'Cargo.lock')
        _identity(by_path, lock)
        provider_rows.append(dict(run='557', provider=provider, source_files=len(files)))
    assert verified == 841

    blocks = re.split(r'^(\{"command": .*\})$', values['log'].decode(), flags=re.M)
    assert len(blocks) == 17
    groups = {}
    inventory = json.loads(values['historical_inventory'])
    for index, command in enumerate(commands):
        assert json.loads(blocks[1 + 2 * index])['command'] == command
        raw = blocks[2 + 2 * index]
        results = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', raw)
        if command[1] == 'clippy':
            assert not results and 'Finished `dev` profile' in raw
            continue
        result, = results
        result = tuple(map(int, result))
        provider = PROVIDERS[index // 2]
        assert result == EXPECTED[index // 2]
        running, = re.findall(r'^running (\d+) tests$', raw, re.M)
        assert int(running) == result[0] + result[2]
        expected = inventory['successful_test_groups'][index // 2]
        assert expected['provider'] == provider
        ignored = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', raw, re.M)
        assert ignored == [(row['name'], row['reason']) for row in expected['ignored_tests']]
        current = primary['groups'][index // 2]
        assert current['provider'] == provider
        assert tuple(current['counts'][k] for k in ('passed', 'failed', 'ignored', 'measured', 'filtered')) == result
        assert current['ignored_declarations'] == [list(row) for row in ignored]
        groups[provider] = dict(run='557', running=int(running), passed=result[0], failed=0,
            ignored=result[2], measured=0, filtered_out=0)
    assert len(groups) == 4 and sum(row['passed'] for row in groups.values()) == 3587
    return dict(status='passed', primary_verification=dict(path=str(primary_path),
        bytes=len(primary_bytes), sha256=_digest(primary_bytes)),
        protocol=primary['protocol'], source_files_verified=verified, commands_verified=8,
        selected_providers=provider_rows, test_groups=groups,
        test_totals=dict(passed=3587, failed=0, ignored=2, running=3589),
        root_lock_sha256=protocol['root_lock_sha256'],
        standalone_lock_sha256={provider: row['sha256'] for provider, row in summary['standalone_locks'].items()},
        all_eight_commands_fresh=True)
