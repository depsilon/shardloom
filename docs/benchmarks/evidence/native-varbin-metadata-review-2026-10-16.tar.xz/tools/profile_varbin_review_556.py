"""Profile the frozen rejected candidate; never use these clocks for acceptance."""
import json
import os
from pathlib import Path
import subprocess

import varbin_review_cost_556 as refresh

c, v = refresh.c, refresh.v
DEST = c.OUT / 'varbin-review-profile-556'


def stop(process):
    if process is not None and process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=3)


def main():
    protocol_path = c.DEST / 'protocol.json'
    protocol = c.read(protocol_path)
    v.verify(protocol)
    decision = c.read(c.DEST / 'decision.json')
    assert decision['status'] == 'needs_diagnosis'
    assert not DEST.exists()
    c.storage(DEST)
    c.WorkloadGuard().check()
    lock = c.UAT / '.ingest-uat.lock'
    lock.mkdir()
    native = sampler = None
    result = dict(status='running', acceptance_measurement=False,
        purpose='Sample the already-frozen FSST lifecycle during its large UTF-8 cells. Profiling perturbs execution; all clocks are diagnostic only.',
        protocol=c.bound(protocol_path), candidate=protocol['identities']['candidate']['binary'],
        helper=c.bound(__file__), host_before=c.host_snapshot())
    try:
        DEST.mkdir()
        command = [result['candidate']['path'], c.TEST, '--exact', '--ignored',
                   '--nocapture', '--test-threads=1']
        result['command'] = command
        with (DEST / 'native.stdout.txt').open('xb') as stdout, \
             (DEST / 'native.stderr.txt').open('xb') as stderr, \
             (DEST / 'sample.log').open('xb') as sample_log:
            native = subprocess.Popen(command, cwd=c.ROOT,
                env=dict(os.environ, SHARDLOOM_VARBIN_METADATA_COST='frozen-v1'),
                stdout=subprocess.PIPE, stderr=stderr)
            result['native_pid'] = native.pid
            observed_bytes = 0
            for line in iter(native.stdout.readline, b''):
                observed_bytes += len(line)
                assert observed_bytes <= 8 * c.MIB, 'native diagnostic output limit'
                stdout.write(line)
                if not line.startswith(b'VARBIN_METADATA_COST '):
                    continue
                cell = json.loads(line.split(b' ', 1)[1])
                if (sampler is None and cell['phase'] == 'warmup'
                        and cell['kind'] == 'utf8' and cell['rows'] == 65536
                        and cell['encoding'] == 'fsst' and cell['chunks'] == 2):
                    result['sample_trigger'] = cell
                    sample_command = ['/usr/bin/sample', str(native.pid), '2', '1',
                                      '-mayDie', '-file', str(DEST / 'sample.txt')]
                    result['sample_command'] = sample_command
                    sampler = subprocess.Popen(sample_command, stdout=sample_log, stderr=subprocess.STDOUT)
                    result['sampler_pid'] = sampler.pid
            result['native_returncode'] = native.wait(timeout=10)
            assert result['native_returncode'] == 0
            assert sampler is not None, 'FSST trigger was not observed'
            result['sampler_returncode'] = sampler.wait(timeout=30)
            assert result['sampler_returncode'] == 0, 'native sampler failed; inspect sample.log'
        cells = v.extract(DEST / 'native.stdout.txt', protocol)
        assert len(cells) == 32
        result['complete_lifecycle_cases'] = len(cells)
        result['profiling_clocks_excluded_from_acceptance'] = True
        assert (DEST / 'sample.txt').is_file()
        for path in DEST.iterdir():
            assert path.stat().st_size <= 8 * c.MIB, 'diagnostic output limit'
        v.verify(protocol)
        result['status'] = 'passed'
    except BaseException as error:
        result.update(status='failed', error=type(error).__name__ + ': ' + str(error))
        raise
    finally:
        stop(sampler)
        stop(native)
        result['children_reaped'] = all(p is None or p.poll() is not None for p in (native, sampler))
        result['host_after'] = c.host_snapshot()
        result['files'] = [c.bound(path) for path in sorted(DEST.iterdir()) if path.is_file()] if DEST.exists() else []
        lock.rmdir()
        c.save(c.OUT / 'varbin-review-profile-result-556.json', result)
        print(json.dumps({key: result.get(key) for key in ('status', 'error', 'complete_lifecycle_cases', 'children_reaped')}), flush=True)


if __name__ == '__main__':
    main()
