"""Independently verify current provider commands, complete test groups and copies."""
import json
from pathlib import Path
import re

from freeze_native_release_298 import ROOT, OUT, save, sha
from run_varbin_review_checks_551 import identity, unchanged, SOURCE

DEST = OUT / 'varbin-review-vendor-551'
INVENTORY = OUT / 'varbin-review-provider-inventory-551.json'
RESULT = OUT / 'varbin-review-vendor-inspection-551.json'


def excerpt(path, value):
    lines = Path(path).read_text().splitlines()
    assert '\n'.join(lines[value['start_line']-1:value['end_line']]) == value['text']


def inspect_inventory():
    value = json.loads(INVENTORY.read_text())
    for item in value['source_files']:
        assert identity(item['path']) == item
    excerpt(value['workflow']['path'], value['workflow']['relevant_exact_excerpt'])
    assert len(value['protocols']) == 2
    for row in value['protocols']:
        assert identity(row['provenance']['path']) == row['provenance']
        assert json.loads(Path(row['provenance']['path']).read_text())['commands'] == row['commands']
    assert [row['argv'] for row in value['eight_command_templates']] == value['protocols'][0]['commands']
    assert len(value['eight_command_templates']) == 8
    for row in value['successful_test_groups']:
        path = row['log_provenance']['path']
        assert identity(path) == row['log_provenance']
        excerpt(path, row['command_marker'])
        excerpt(path, row['result'])
        command = json.loads(row['command_marker']['text'])['command']
        assert command[:2] == ['cargo', 'test']
        assert Path(command[command.index('--manifest-path')+1]).parent.name == row['provider']
        lines = Path(path).read_text().splitlines()
        start, end = row['command_marker']['end_line'], row['result']['start_line']-1
        assert not any(line.startswith('{"command":') for line in lines[start:end])
        counts = re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', row['result']['text'])
        assert counts
        assert dict(zip(('passed','failed','ignored','measured','filtered'), map(int, counts.groups()))) == row['test_result']
        expected = [(r['name'], r['reason']) for r in row['ignored_tests']]
        observed = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', '\n'.join(lines[start:end]), re.M)
        assert observed == expected and len(observed) == row['test_result']['ignored']
        for item in row['ignored_tests']:
            excerpt(path, item['line_span'])
    assert [row['provider'] for row in value['successful_test_groups']] == [
        'vortex-array', 'vortex-fsst', 'vortex-runend', 'vortex-zstd']
    return value


def main():
    frozen = unchanged()
    inventory = inspect_inventory()
    protocol_path, summary_path = DEST / 'protocol.json', DEST / 'summary.json'
    protocol, summary = json.loads(protocol_path.read_text()), json.loads(summary_path.read_text())
    assert protocol['source'] == summary['source'] == identity(SOURCE)
    assert summary['status'] == 'passed' and summary['sources_unchanged'] and summary['failure'] is None
    assert summary['protocol'] == identity(protocol_path)
    assert summary['completed'] == protocol['commands'] and len(summary['completed']) == 8
    assert protocol['all_eight_commands_fresh']
    assert sha(ROOT / 'Cargo.lock') == protocol['root_lock_sha256']
    assert sha(DEST / 'clippy.toml') == protocol['clippy_config_sha256'] == sha(ROOT / 'vendor/vortex-array/clippy.toml')
    assert protocol['environment'] == {'CLIPPY_CONF_DIR': str(DEST)}
    assert identity(protocol['helper']['path']) == protocol['helper']
    for provider, files in protocol['source_files'].items():
        source = ROOT / 'vendor' / provider
        assert set(files) == {p.relative_to(source).as_posix() for p in source.rglob('*') if p.is_file() and p.name != 'Cargo.lock'}
        for name, digest in files.items():
            assert sha(source / name) == sha(DEST / provider / name) == digest
        assert identity(DEST / provider / 'Cargo.lock') == summary['standalone_locks'][provider]
    prior_dir = str(OUT / 'varbin-metadata-vendor-545c')
    assert protocol['commands'] == [[arg.replace(prior_dir, str(DEST)) for arg in row['argv']]
        for row in inventory['eight_command_templates']]
    guard_path = OUT / 'varbin-review-vendor-tests-551.json'
    guard, log = json.loads(guard_path.read_text()), guard_path.with_suffix('.log')
    assert guard['status'] == 'passed' and guard['returncode'] == 0
    assert guard['process_group_drained'] and guard['direct_child_reaped']
    assert not guard['timed_out'] and not guard['group_absence_unproved_at_cleanup']
    assert guard['head'] == frozen['head'] and not guard['working_tree']
    assert sha(log) == guard['log_sha256']
    blocks = re.split(r'^(\{"command": .*\})$', log.read_text(), flags=re.M)
    assert len(blocks) == 17
    groups = []
    for index, command in enumerate(protocol['commands']):
        assert json.loads(blocks[1+index*2])['command'] == command
        raw = blocks[2+index*2]
        results = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', raw)
        if command[1] == 'clippy':
            assert not results and 'Finished `dev` profile' in raw
            continue
        result, = results
        counts = dict(zip(('passed','failed','ignored','measured','filtered'), map(int,result)))
        expected = inventory['successful_test_groups'][index//2]
        assert counts == expected['test_result']
        ignored = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', raw, re.M)
        assert ignored == [(row['name'],row['reason']) for row in expected['ignored_tests']]
        groups.append(dict(provider=expected['provider'], counts=counts, ignored_declarations=ignored))
    assert unchanged() == frozen
    save(RESULT, dict(status='passed', source=identity(SOURCE), helper=identity(__file__),
        protocol=identity(protocol_path), summary=identity(summary_path), receipt=identity(guard_path),
        log=identity(log), historical_inventory=identity(INVENTORY), groups=groups,
        commands_verified=8, source_files_verified=sum(map(len,protocol['source_files'].values())),
        selected_sources_match_current=True, all_eight_commands_fresh=True))
    print(json.dumps(dict(status='passed', providers=4, commands=8,
        tests=sum(row['counts']['passed'] for row in groups), ignored=sum(row['counts']['ignored'] for row in groups))))


if __name__ == '__main__':
    main()
