"""Inspect every retained public result using the unchanged complete verifier."""
import verify_stream_dynamic_subquery_public_522 as review
import run_varbin_review_acceptance_560 as acceptance

review.PUBLIC = acceptance.PUBLIC
review.RUNTIME_PATH = acceptance.PUBLIC_ACCEPTANCE
review.RECEIPT_PATH = acceptance.OUT / 'varbin-review-public-560.json'
review.BASELINE_PATH = acceptance.PROTOCOL
review.OUTPUT = acceptance.OUT / 'varbin-review-public-inspection-report-560.json'
review.ACCEPTED_SOURCE = acceptance.SOURCE
review.load = acceptance.load
review.unchanged = acceptance.unchanged

if __name__ == '__main__':
    acceptance.protocol()
    review.main()
    acceptance.protocol()
