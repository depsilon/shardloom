"""Preserve the arithmetic report separately from its outer execution receipt."""
import varbin_review_cost_555 as refresh
import verify_varbin_metadata_cost_546 as original

original.D = refresh.c.DEST
original.RESULT = refresh.c.OUT / 'varbin-review-cost-inspection-report-555.json'

if __name__ == '__main__':
    original.main()
