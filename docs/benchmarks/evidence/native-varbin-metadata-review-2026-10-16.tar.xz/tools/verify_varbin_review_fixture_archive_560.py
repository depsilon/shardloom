"""Verify the test-only source transition using archived bytes alone."""
from pathlib import Path
import re

from verify_stream_unary_packet_497 import need, digest, strict_json

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path(__file__).resolve().parent
MEASURED = 'c08e044e19e7e709431bf76e8faa6aab5f46bb4a'
PREFIX = 'shardloom-vortex/src/local_primitives/'
EXPECTED = {
    'native_sort_block': (
        'native_sort_block_rejects_malformed_losing_utf8_but_ignores_null_payload_bytes',
        'native_sort_block_rejects_malformed_utf8_before_sort_and_normalizes_null_payloads'),
    'scalar_distinct_workers': (
        'scalar_distinct_workers_invalid_used_utf8_fails_but_unused_dictionary_value_is_ignored',
        'scalar_distinct_workers_reject_malformed_text_before_admission_and_ignore_unused_values'),
    'string_count_partial': (
        'invalid_canonical_utf8_is_rejected_before_publishing_first_or_later_key',
        'malformed_utf8_is_rejected_before_counting_and_binary_is_not_reinterpreted'),
}


def verify_fixture_bridge(by_path, reference, source, manifest, native_log):
    bridge = strict_json(reference(manifest['test_fixture_bridge']))
    need(bridge['status'] == 'passed' and not bridge['unsafe_fixture_injection'], 'fixture proof status differs')
    reference(bridge['helper'])
    proof = bridge['source_proof']
    old = strict_json(reference(proof['prior_source']))
    need(old['head'] == proof['measured_commit'] == manifest['measured_cost_commit'] == MEASURED,
         'measured fixture revision differs')
    need(proof['current_source'] == manifest['source_manifest'] and
         proof['accepted_commit'] == source['head'], 'accepted fixture revision differs')
    current, prior = source['source_sha256'], old['source_sha256']
    changed = {PREFIX + name + '_tests.rs' for name in EXPECTED}
    need(set(current) == set(prior) and len(current) == 2371 and
         {name for name in current if current[name] != prior[name]} == changed,
         'production source changed after cost measurement')
    need(proof['production_sources_unchanged'] and proof['benchmark_harness_unchanged'] and
         not proof['benchmark_rerun'] and proof['unchanged_source_files'] == 2368,
         'fixture source equivalence differs')
    rows = {row['path']: row for row in proof['test_changes']}
    need(set(rows) == changed and len(proof['test_changes']) == 3, 'fixture inventory differs')
    for stem, (old_test, new_test) in EXPECTED.items():
        name, parent = PREFIX + stem + '_tests.rs', PREFIX + stem + '.rs'
        row = rows[name]
        text, parent_text = reference(row['current']).decode(), reference(row['parent']).decode()
        need(row['current']['path'] == str(ROOT / name) and row['parent']['path'] == str(ROOT / parent),
             'fixture path differs')
        need(row['current']['sha256'] == current[name] and row['prior_sha256'] == prior[name] and
             row['parent']['sha256'] == current[parent] == prior[parent], 'fixture source identity differs')
        marker = '#[cfg(test)]\n#[path = "' + stem + '_tests.rs"]\nmod tests;'
        need(row['cfg_test_marker'] == marker and parent_text.count(marker) == 1,
             'changed fixture is not excluded from production compilation')
        need(row['prior_test'] == old_test and row['current_test'] == new_test and
             'fn ' + new_test + '(' in text and 'unsafe {' not in text,
             'fixture correction differs')
        need(re.search(r'^test .*::' + re.escape(new_test) + r' \.\.\. ok$', native_log, re.M),
             'repaired fixture did not pass the full native suite')
    failed = strict_json(reference(bridge['failed_native_receipt']))
    failed_log = reference(bridge['failed_native_log'])
    need(failed['status'] == 'failed' and failed['returncode'] == 101 and failed['head'] == MEASURED and
         failed['process_group_drained'] and failed['direct_child_reaped'] and
         digest(failed_log) == failed['log_sha256'], 'original fixture failure is not preserved')
    need('2887 passed; 3 failed; 27 ignored;' in failed_log.decode(), 'original fixture failure count differs')
    for old_test, _ in EXPECTED.values():
        need(old_test in failed_log.decode(), 'original failing test is absent')
    summary = strict_json(reference(bridge['failed_broad_summary']))
    need(summary['status'] == 'failed' and len(summary['completed']) == 5,
         'failed broad attempt was misreported')
    focused = strict_json(reference(bridge['focused_receipt']))
    focused_log = reference(bridge['focused_log'])
    need(focused['status'] == 'passed' and focused['returncode'] == 0 and
         focused['process_group_drained'] and focused['direct_child_reaped'] and
         digest(focused_log) == focused['log_sha256'], 'focused fixture result differs')
    reference(bridge['inventory'])
    review = strict_json(reference(manifest['test_fixture_inventory_review']))
    need(review['status'] == 'passed_primary_inventory_review' and review['source_hashes_verified'] == 6 and
         not review['unresolved'], 'fixture inventory primary review is missing')
    for correction in review['corrections']:
        lines = by_path(ROOT / correction['file']).decode().splitlines()
        need([lines[line-1].strip() for line in correction['lines']] == correction['actual'],
             'fixture inventory correction differs from source')
    return dict(status='passed', measured_commit=MEASURED, accepted_commit=source['head'],
        changed_test_files=sorted(changed), unchanged_source_files=2368,
        production_sources_unchanged=True, native_tests_fresh=True,
        prior_source=proof['prior_source'], current_source=proof['current_source'],
        bridge=manifest['test_fixture_bridge'])
