"""Close the frozen finite compact-index decision after every acceptance gate."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

import analyze_compact_indices_762 as oracle
import compact_index_driver_762 as driver

ROOT = driver.OUT
REPO = driver.REPO
DATA = ROOT / 'compact-local-indices-762-a1'


def read(path):
    return json.loads(Path(path).read_text())


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)


verified_references = {}


def check(reference):
    actual = identity(reference['path'])
    assert actual == reference, reference['path']
    verified_references[actual['path']] = actual
    return Path(actual['path'])


def references(value):
    if isinstance(value, dict):
        if set(value) == {'path', 'bytes', 'sha256'}:
            check(value)
        else:
            for item in value.values():
                references(item)
    elif isinstance(value, list):
        for item in value:
            references(item)


def receipt(name, passed=None, ignored=None, targets=None):
    path, log = ROOT / f'{name}.json', ROOT / f'{name}.log'
    record = read(path)
    assert record['status'] == 'passed' and record['returncode'] == 0, name
    assert record['process_group_drained'] and record['direct_child_reaped'], name
    assert record['log_sha256'] == identity(log)['sha256'], name
    if passed is not None:
        summaries = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log.read_text())
        assert len(summaries) == targets, (name, len(summaries), targets)
        assert sum(int(row[0]) for row in summaries) == passed
        assert sum(int(row[1]) for row in summaries) == 0
        assert sum(int(row[2]) for row in summaries) == ignored
    return dict(receipt=identity(path), log=identity(log))


subprocess.run([sys.executable, '-B', str(ROOT / 'compact_acceptance_764.py'), 'verify'], cwd=REPO, check=True)
protocol = ROOT / 'compact-local-indices-protocol-762.json'
assert identity(protocol)['sha256'] == driver.PROTOCOL_SHA == oracle.PROTOCOL_SHA
source = read(ROOT / 'compact-index-candidate-763-source-freeze.json')
driver.verify_sources(source)
build = read(ROOT / 'compact-index-acceptance-build-764.json')
references(build['build_receipts'])
assert identity(build['binary'])['sha256'] == build['binary_sha256']
check(build['native_library'])
for label in ['compact-index-baseline-762', 'compact-index-candidate-763']:
    freeze = read(ROOT / f'{label}-source-freeze.json')
    driver.historical_sources(label, freeze)
    artifact = read(ROOT / f'{label}-artifact.json')
    assert identity(ROOT / f'{label}-source-freeze.json')['sha256'] == artifact['source_freeze_sha256']
    assert identity(artifact['artifact']) == dict(path=artifact['artifact'], bytes=artifact['bytes'], sha256=artifact['artifact_sha256'])
    assert identity(ROOT / f"{artifact['build']}.json")['sha256'] == artifact['build_receipt_sha256']
    receipt(artifact['build'])

measurement = read(ROOT / 'compact-index-measurement-freeze-763.json')
assert measurement['all_cohorts_complete_before_comparative_analysis']
assert measurement['order'] == [['A', 'baseline'], ['A', 'candidate'], ['B', 'candidate'], ['B', 'baseline']]
references(measurement['closure'])
assert measurement['protocol_sha256'] == driver.PROTOCOL_SHA
assert measurement['preflight_sha256'] == identity(ROOT / 'compact-index-both-preflight-analysis-763.json')['sha256']
witnesses = oracle.Witnesses(DATA)
preflight = []
for role in ['baseline', 'candidate']:
    _, result = oracle.read(DATA, 'preflight', role, 'preflight', witnesses)
    preflight.append(result)
    receipt(f"compact-index-{role}-preflight-{'762' if role == 'baseline' else '763'}")
assert sum(row['workflows'] for row in preflight) == 168
assert sum(row['operations'] for row in preflight) == 420
cohorts, raw = {}, []
for cohort in ['A', 'B']:
    cohorts[cohort] = {}
    for role in ['baseline', 'candidate']:
        cohorts[cohort][role], result = oracle.read(DATA, 'measure', role, cohort, witnesses)
        raw.append(result)
        receipt(f'compact-index-measure-{cohort}-{role}-763')
recomputed = oracle.analyze(cohorts)
decision_path = ROOT / 'compact-index-decision-763.json'
decision = read(decision_path)
assert all(decision[key] == value for key, value in recomputed.items())
assert decision['receipts'] == raw
assert decision['analyzer_sha256'] == identity(ROOT / 'analyze_compact_indices_762.py')['sha256']
assert decision['finite_comparison_passed'] and decision['failed_gates'] == []
assert decision['production_accepted'] is False  # The original finite screen stays immutable.

focused = read(ROOT / 'compact-index-focused-tests-763.json')
assert focused['passed'] and [row['expected_and_passed'] for row in focused['checks']] == [9, 3, 8, 7, 38]
for item in focused['checks']:
    receipt(Path(item['receipt']).stem, item['expected_and_passed'], 0, 1)
receipt('compact-index-candidate-clippy-fixed-763')
gates_path = ROOT / 'compact-index-integration-gates-763.json'
gates = read(gates_path)
assert gates['status'] == 'passed' and gates['source_freeze_sha256'] == identity(ROOT / 'compact-index-candidate-763-source-freeze.json')['sha256']
assert [(row['name'], row.get('passed'), row.get('ignored'), row.get('test_targets')) for row in gates['checks']] == [
    ('compact-index-native-all-763', 3031, 30, 1),
    ('compact-index-workspace-fmt-763', None, None, None),
    ('compact-index-workspace-clippy-763', None, None, None),
    ('compact-index-workspace-tests-763', 3235, 0, 107),
]
for item in gates['checks']:
    result = receipt(item['name'], item.get('passed'), item.get('ignored'), item.get('test_targets'))
    assert result['receipt']['sha256'] == item['receipt_sha256']
    assert result['log']['sha256'] == item['log_sha256']
cli_path = ROOT / 'compact-index-native-cli-gate-764.json'
cli = read(cli_path)
assert cli['status'] == 'passed' and cli['source_unchanged']
assert (cli['passed'], cli['failed'], cli['ignored'], cli['test_targets']) == (1087, 0, 0, 6)
cli_receipt = receipt('compact-index-native-cli-tests-764', 1087, 0, 6)
assert cli_receipt['receipt']['sha256'] == cli['receipt_sha256']
assert cli_receipt['log']['sha256'] == cli['log_sha256']

installed_path = ROOT / 'compact-index-installed-python-764.json'
installed = read(installed_path)
assert installed['status'] == 'passed' and installed['sources_unchanged'] and installed['artifacts_unchanged']
assert (installed['native_binding_tests'], installed['installed_context_tests']) == (105, 19)
assert (installed['failures'], installed['errors'], installed['skipped']) == (0, 0, 0)
assert installed['final_uninstall_verified'] and not installed['publication_attempted']
references(installed)
proof = read(installed['proof']['path'])
assert proof['status'] == 'passed' and proof['uninstall_status'] == 'passed'
assert proof['installed_load']['isolated_install'] and proof['installed_load']['version'] == '0.6.0'
assert proof['integrity']['native_library_sha256'] == build['native_library']['sha256']
assert proof['integrity']['cli_sha256'] == build['binary_sha256']
for step in proof['steps']:
    assert step['returncode'] == 0
    assert identity(ROOT / 'compact-index-installed-python-764/logs' / step['log'])['sha256'] == step['log_sha256']
for item in installed['receipts'].values():
    receipt(Path(item['receipt']['path']).stem)

acceptance = {}
for phase in ['public', 'full43', 'modular']:
    path = ROOT / f'compact-index-acceptance-{phase}-verified-764.json'
    record = read(path)
    assert record['status'] == 'passed' and record['phase'] == phase
    assert record['source_commit'] == build['source_commit'] and record['working_tree'] == build['working_tree']
    references(record)
    receipt(f'compact-index-{phase}-764')
    acceptance[phase] = dict(record=identity(path), report=record)
assert acceptance['public']['report']['families'] == 39
assert acceptance['full43']['report']['queries'] == acceptance['full43']['report']['calls'] == 43
assert acceptance['full43']['report']['complete_rows'] == 381
assert acceptance['modular']['report']['native_workflows'] == acceptance['modular']['report']['independent_pandas_oracle_workflows'] == 704

subprocess.run([sys.executable, '-B', str(ROOT / 'compact_acceptance_764.py'), 'verify'], cwd=REPO, check=True)
report = dict(schema_version='shardloom.compact_local_indices_acceptance.v1',
    status='passed', outcome='finite_u16_local_selection_candidate_retained',
    production_accepted=True, source_commit=build['source_commit'], working_tree=build['working_tree'],
    commit_alone_reproduces_sources=False, protocol=identity(protocol),
    comparison=identity(decision_path), comparison_recomputed_from_raw=True,
    preflight_workflows=168, preflight_operations=420,
    comparison_workflows_including_warmups=340, comparison_operations_including_warmups=844,
    complete_witnesses_verified=len(witnesses.seen),
    build=identity(ROOT / 'compact-index-acceptance-build-764.json'),
    runtime_source_freeze=identity(ROOT / 'compact-index-candidate-763-source-freeze.json'),
    workspace_and_native_gates=identity(gates_path), native_cli_gate=identity(cli_path),
    installed_python=identity(installed_path),
    acceptance={phase: item['record'] for phase, item in acceptance.items()},
    public_cases=acceptance['public']['report']['cases'], public_families=39,
    full43_engine_execution_seconds=acceptance['full43']['report']['engine_execution_seconds'],
    verifier=identity(__file__), verified_file_references=list(verified_references.values()),
    cpu_speedup_claim=False, whole_process_memory_limit_claim=False,
    broader_owner_and_conditional_substep_remain_open=True, publication_attempted=False,
    claim_scope='Frozen bounded local-index memory targets and all controls passed; current-host integration accepted. No general CPU speedup, broad capability closure, package publication or cross-platform certification.')
driver.save(ROOT / 'compact-index-final-acceptance-765.json', report)
print(json.dumps({key: report[key] for key in ['status', 'outcome', 'production_accepted', 'public_cases', 'full43_engine_execution_seconds']}), flush=True)
