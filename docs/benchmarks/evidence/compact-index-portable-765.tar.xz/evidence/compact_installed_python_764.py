"""Exercise the frozen candidate as a clean locally installed native wheel."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import compact_index_driver_762 as d

OUT = d.OUT
ROOT = d.REPO
PYTHON = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
BUILD_PYTHON = '/Users/dylan/LocalData/shardloom/native-python-surface-20261010/release-v0.6.0/build-env/bin/python'
WHEELHOUSE = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010/native-wheelhouse-267')
PROOF = OUT / 'compact-index-installed-python-764'
ACCEPTANCE = OUT / 'compact_acceptance_764.py'
BUILD = OUT / 'compact-index-acceptance-build-764.json'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def verify():
    subprocess.run([PYTHON, '-B', str(ACCEPTANCE), 'verify'], cwd=ROOT, check=True)
    current = json.loads(BUILD.read_text())
    assert current['binary_sha256'] == sha(current['binary'])
    assert current['native_library'] == identity(current['native_library']['path'])
    return current


def run(name, command):
    verify()
    subprocess.run([PYTHON, '-B', str(d.GUARD), '--name', name, '--timeout', '3600', '--', *command],
                   cwd=ROOT, check=True)
    verify()
    receipt = json.loads((OUT / f'{name}.json').read_text())
    assert receipt['status'] == 'passed' and receipt['process_group_drained']
    assert receipt['log_sha256'] == sha(OUT / f'{name}.log')
    return dict(receipt=identity(OUT / f'{name}.json'), log=identity(OUT / f'{name}.log'))


build = verify()
dependency_inputs = [ROOT / '.github/requirements/ci-native-python.txt',
                     ROOT / '.github/requirements/ci-native-python-build.txt',
                     ROOT / '.github/requirements/ci-python-build.txt']
dependency_inputs += sorted(WHEELHOUSE.glob('*.whl'))
assert len(dependency_inputs) > 3 and not PROOF.exists()
dependencies = [identity(path) for path in dependency_inputs]
command = [BUILD_PYTHON, '-B', 'scripts/prove_native_python_wheel.py', '--repo-root', str(ROOT),
           '--output-dir', str(PROOF), '--native-library', build['native_library']['path'],
           '--cli-binary', build['binary'], '--wheelhouse', str(WHEELHOUSE)]
d.save(OUT / 'compact-index-installed-python-plan-764.json', dict(status='predeclared',
    build=identity(BUILD), driver=identity(__file__), canonical_prover=identity(ROOT / 'scripts/prove_native_python_wheel.py'),
    dependencies=dependencies, command=command,
    expected='All native binding tests and all installed public-context tests, zero failures/errors/skips; native and CLI must load from isolated installed package.',
    publication_attempted=False))
proof_receipt = run('compact-index-wheel-proof-764', command)
report = json.loads((PROOF / 'report.json').read_text())
assert report['status'] == 'passed' and report['uninstall_status'] == 'passed'
assert report['integration']['tests'] > 0
assert all(report['integration'][key] == 0 for key in ('failures', 'errors', 'skipped'))
assert report['publication_attempted'] is False
assert report['integrity']['native_library_sha256'] == build['native_library']['sha256']
assert report['integrity']['cli_sha256'] == build['binary_sha256']
for step in report['steps']:
    assert step['returncode'] == 0 and step['log_sha256'] == sha(PROOF / step['log'])
wheels = list((PROOF / 'dist').glob('*.whl'))
assert len(wheels) == 1 and sha(wheels[0]) == report['integrity']['wheel_sha256']
python = str(PROOF / 'venv/bin/python')
reinstall = run('compact-index-wheel-reinstall-764',
    [python, '-I', '-m', 'pip', 'install', '--no-index', '--no-deps', str(wheels[0])])
context_code = '''
import hashlib, json, pathlib, sys, unittest
import shardloom
from shardloom import _native, ShardLoomClient
root = pathlib.Path(sys.prefix).resolve()
package = pathlib.Path(shardloom.__file__).resolve()
native = pathlib.Path(_native.__file__).resolve()
assert root in package.parents and root in native.parents
assert hashlib.sha256(native.read_bytes()).hexdigest() == sys.argv[3]
client = ShardLoomClient()
binary = pathlib.Path(client.binary_command()[0]).resolve()
assert root in binary.parents
assert hashlib.sha256(binary.read_bytes()).hexdigest() == sys.argv[4]
client.close()
suite = unittest.defaultTestLoader.discover(sys.argv[1], pattern='test_public_context.py')
expected = suite.countTestCases()
result = unittest.TextTestRunner(verbosity=2).run(suite)
passed = result.wasSuccessful() and result.testsRun == expected and expected > 0 and not result.skipped
report = dict(status='passed' if passed else 'failed', expected_tests=expected, tests=result.testsRun,
    failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
    package=str(package), native=str(native), binary=str(binary), isolated_install=True)
pathlib.Path(sys.argv[2]).write_text(json.dumps(report, indent=2) + '\\n')
raise SystemExit(0 if passed else 1)
'''
context = run('compact-index-installed-context-764', ['/usr/bin/env', '-u', 'SHARDLOOM_NATIVE_TEST_LIBRARY',
    '-u', 'SHARDLOOM_BIN', '-u', 'SHARDLOOM_REPO_ROOT', 'SHARDLOOM_REQUIRE_NATIVE_PYTHON=1',
    'SHARDLOOM_TEST_INSTALLED_QUICKSTART=1', python, '-I', '-c', context_code,
    str(ROOT / 'python/tests'), str(PROOF / 'public-context.json'),
    build['native_library']['sha256'], build['binary_sha256']])
context_result = json.loads((PROOF / 'public-context.json').read_text())
assert context_result['status'] == 'passed' and all(context_result[key] == 0 for key in ('errors', 'failures', 'skipped'))
uninstall = run('compact-index-wheel-final-uninstall-764', [python, '-I', '-m', 'pip', 'uninstall', '--yes', 'shardloom'])
absence = run('compact-index-wheel-final-absence-764', [python, '-I', '-c',
    "import importlib.util,pathlib,sys; assert importlib.util.find_spec('shardloom') is None; assert all(not pathlib.Path(p).exists() for p in sys.argv[1:])",
    context_result['package'], context_result['native'], context_result['binary']])
assert [identity(path) for path in dependency_inputs] == dependencies
assert verify() == build
d.save(OUT / 'compact-index-installed-python-764.json', dict(status='passed',
    build=identity(BUILD), driver=identity(__file__), proof=identity(PROOF / 'report.json'),
    context=identity(PROOF / 'public-context.json'), wheel=identity(wheels[0]),
    native_binding_tests=report['integration']['tests'], installed_context_tests=context_result['tests'],
    failures=0, errors=0, skipped=0, sources_unchanged=True, artifacts_unchanged=True,
    receipts=dict(proof=proof_receipt, reinstall=reinstall, context=context, uninstall=uninstall, absence=absence),
    final_uninstall_verified=True, publication_attempted=False))
print(json.dumps(dict(status='passed', native_binding_tests=report['integration']['tests'],
                     installed_context_tests=context_result['tests'])), flush=True)
