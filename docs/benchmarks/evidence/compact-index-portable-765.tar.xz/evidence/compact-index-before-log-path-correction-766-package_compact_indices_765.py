"""Package accepted compact-index evidence after final acceptance only.

This script deliberately does not run ShardLoom, rebuild, or alter the repo.
It must be invoked only after compact-index-final-acceptance-765.json records
status=passed and production_accepted=true.
"""

from __future__ import annotations

import hashlib
import io
import json
import lzma
from pathlib import Path
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
LOCALDATA = Path('/Users/dylan/LocalData/shardloom')
DEST = ROOT / 'compact-index-portable-765'
NAME = 'compact-index-portable-765'
FINAL_PATH = ROOT / 'compact-index-final-acceptance-765.json'
PLAN_PATH = ROOT / 'compact-index-acceptance-plan-764.json'
SOURCE_PATH = ROOT / 'compact-index-acceptance-source-764.json'
BUILD_PATH = ROOT / 'compact-index-acceptance-build-764.json'
PROTOCOL_PATH = ROOT / 'compact-local-indices-protocol-762.json'
EXPECTED_PROTOCOL_SHA = '7f7bf6830ec162999ee2f946a59894f9bd8edce9f80d0c3a747560926b2d73ad'

sys.path.insert(0, str(REPO / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

EVIDENCE_SUFFIXES = {
    '.json', '.jsonl', '.log', '.txt', '.patch', '.rs', '.py', '.csv',
    '.sql', '.toml', '.md', '.yaml', '.yml', '.xz', '.gz', '.jsonl.gz', '.pid',
}
ARTIFACT_SUFFIXES = {
    '.vortex', '.parquet', '.orc', '.arrow', '.arrow_ipc', '.avro', '.whl',
    '.so', '.dylib', '.dll', '.exe', '.rlib', '.rmeta', '.o', '.a',
}


def digest_file(path: Path) -> str:
    hasher = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            hasher.update(chunk)
    return hasher.hexdigest()


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def encode(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def identity(path: Path) -> dict[str, object]:
    path = Path(path)
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': digest_file(path)}


def add_file(members: dict[str, Path], archive_name: str, source: Path) -> None:
    source = Path(source)
    assert source.is_file() and not source.is_symlink(), f'not a regular file: {source}'
    assert archive_name and not archive_name.startswith('/') and '..' not in Path(archive_name).parts
    previous = members.get(archive_name)
    assert previous is None or previous.resolve() == source.resolve(), f'duplicate archive path: {archive_name}'
    members[archive_name] = source


def archive_path(path: Path) -> str:
    path = Path(path).resolve(strict=True)
    public_logs = ROOT / 'compact-index-public-764' / 'logs'
    if path.is_relative_to(public_logs):
        return 'public/logs/' + path.relative_to(public_logs).as_posix()
    if path.is_relative_to(ROOT):
        return 'evidence/' + path.relative_to(ROOT).as_posix()
    if path.is_relative_to(REPO):
        return 'repo/' + path.relative_to(REPO).as_posix()
    if path.is_relative_to(LOCALDATA):
        return 'local/' + path.relative_to(LOCALDATA).as_posix()
    raise AssertionError(f'input outside approved local roots: {path}')


def read_json(path: Path) -> dict:
    return json.loads(Path(path).read_text())


def verify_reference(reference: dict) -> Path:
    assert set(reference) == {'path', 'bytes', 'sha256'}, reference
    path = Path(reference['path'])
    assert path.is_file() and not path.is_symlink(), path
    assert path.stat().st_size == reference['bytes'], path
    assert digest_file(path) == reference['sha256'], path
    return path


def walk_references(value):
    if isinstance(value, dict):
        if set(value) == {'path', 'bytes', 'sha256'}:
            yield value
        else:
            for item in value.values():
                yield from walk_references(item)
    elif isinstance(value, list):
        for item in value:
            yield from walk_references(item)


def packageable_reference(path: Path) -> bool:
    resolved = path.resolve(strict=True)
    if resolved.is_relative_to(ROOT / 'compact-index-public-764' / 'outputs'):
        return False
    if any(part in {'venv', '.venv', 'site-packages', '__pycache__', 'dist', 'target'}
           for part in resolved.parts):
        return False
    if resolved.is_relative_to(ROOT / 'compact-index-installed-python-764' / 'package'):
        return False
    suffix = ''.join(resolved.suffixes[-2:]).lower()
    return suffix in EVIDENCE_SUFFIXES or resolved.suffix.lower() in EVIDENCE_SUFFIXES


def source_mapping(source: dict) -> dict[str, str]:
    mapping = source.get('source_hashes')
    assert isinstance(mapping, dict) and mapping, 'complete accepted source-hash map is required'
    normalized = {}
    for relative, expected in mapping.items():
        assert isinstance(relative, str) and isinstance(expected, str) and len(expected) == 64
        path = REPO / relative
        assert path.is_file() and not path.is_symlink(), f'missing accepted source: {path}'
        actual = digest_file(path)
        assert actual == expected, f'accepted runtime source changed: {relative}'
        normalized[relative] = expected
    return normalized


def record_omission(path: Path, category: str, reproduction: dict,
                    *, known_sha256: str | None = None,
                    known_bytes: int | None = None,
                    hash_current_file: bool = True) -> dict:
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    size = path.stat().st_size
    assert known_bytes is None or size == known_bytes, path
    actual = digest_file(path) if hash_current_file else known_sha256
    assert actual and (known_sha256 is None or actual == known_sha256), path
    return {'path': str(path), 'bytes': size, 'sha256': actual,
            'copied': False, 'category': category,
            'source_reproduction': reproduction}


def collect_artifact_paths(value, found: dict[str, dict]) -> None:
    """Find explicitly named artifact bindings in compact build/receipt JSON."""
    if not isinstance(value, dict):
        if isinstance(value, list):
            for child in value:
                collect_artifact_paths(child, found)
        return
    path_keys = {'artifact', 'binary', 'cli', 'cli_binary', 'executable',
                 'native_library', 'extension', 'wheel', 'test_executable'}
    for key, child in value.items():
        if key in path_keys:
            if isinstance(child, str) and child.startswith('/'):
                hash_value = value.get(key + '_sha256')
                size_value = value.get('bytes') if key in {'artifact', 'wheel'} else None
                if isinstance(hash_value, str):
                    found[child] = {'sha256': hash_value, 'bytes': size_value,
                                    'field': key}
            elif isinstance(child, dict) and isinstance(child.get('path'), str):
                if isinstance(child.get('sha256'), str):
                    found[child['path']] = {'sha256': child['sha256'],
                                            'bytes': child.get('bytes'),
                                            'field': key}
        collect_artifact_paths(child, found)


def verify_final_acceptance(final: dict, plan: dict, source: dict, build: dict) -> dict:
    assert final.get('status') == 'passed' and final.get('production_accepted') is True, (
        'packaging is gated on compact-index-final-acceptance-765.json with passed status '
        'and production_accepted=true')
    assert final.get('schema_version') == 'shardloom.compact_local_indices_acceptance.v1'
    assert final.get('cpu_speedup_claim') is False
    assert final.get('publication_attempted') is False
    assert final.get('broader_owner_and_conditional_substep_remain_open') is True
    assert final.get('source_commit') == source.get('source_commit') == build.get('source_commit')
    assert plan['status'] == 'predeclared'
    assert plan['input']['sha256'] == '06f70eb6f118d11e4a5226eb641225d708fdb4ac1b3f45942872d5ef5df4fc22'
    assert final['protocol']['sha256'] == EXPECTED_PROTOCOL_SHA
    assert digest_file(PROTOCOL_PATH) == EXPECTED_PROTOCOL_SHA
    assert final['comparison']['sha256']
    reports = {}
    for phase in ('public', 'full43', 'modular'):
        expected_path = ROOT / f'compact-index-acceptance-{phase}-verified-764.json'
        path = verify_reference(final['acceptance'][phase])
        assert path == expected_path
        report = read_json(path)
        assert report.get('status') == 'passed' and report.get('phase') == phase
        reports[phase] = report
    assert reports['public']['families'] == 39
    assert reports['full43']['queries'] == reports['full43']['calls'] == 43
    assert reports['full43']['complete_rows'] == 381
    assert reports['modular']['native_workflows'] == 704
    assert reports['modular']['independent_pandas_oracle_workflows'] == 704
    assert source.get('commit_alone_reproduces_sources') is False
    return reports


def main() -> None:
    assert ROOT == Path('/Users/dylan/LocalData/shardloom/conditional-investigations-20261019')
    assert not DEST.exists(), f'packet destination already exists; refusing overwrite: {DEST}'
    require_local_path(ROOT, Path.home(), sys.platform)
    require_local_path(DEST, Path.home(), sys.platform)

    final = read_json(FINAL_PATH)
    plan = read_json(PLAN_PATH)
    source = read_json(SOURCE_PATH)
    build = read_json(BUILD_PATH)
    phase_reports = verify_final_acceptance(final, plan, source, build)

    protocol = read_json(PROTOCOL_PATH)
    assert protocol.get('owner') == 'PERF-10.compact_selections'
    assert digest_file(PROTOCOL_PATH) == EXPECTED_PROTOCOL_SHA
    source_hashes = source_mapping(source)

    members: dict[str, Path] = {}
    # Keep all compact root receipts, failures, corrections, and scope records.
    for path in sorted(ROOT.iterdir()):
        if path.is_file() and path.name.startswith('compact') and path.suffix.lower() in {
                '.json', '.log', '.patch', '.txt', '.rs'}:
            add_file(members, archive_path(path), path)
    # Include every compact driver/helper, including this packager for provenance.
    for path in sorted(ROOT.glob('*compact*.py')):
        if path.is_file() and not path.is_symlink():
            add_file(members, archive_path(path), path)
    add_file(members, archive_path(Path(__file__)), Path(__file__))

    # Preserve both source snapshots and the exact raw six-stream/witness record.
    baseline_freeze = read_json(ROOT / 'compact-index-baseline-762-source-freeze.json')
    candidate_freeze = read_json(ROOT / 'compact-index-candidate-763-source-freeze.json')
    assert baseline_freeze['protocol_sha256'] == candidate_freeze['protocol_sha256'] == EXPECTED_PROTOCOL_SHA
    baseline_patch = ROOT / 'compact-index-baseline-762-tracked.patch'
    candidate_patch = ROOT / 'compact-index-candidate-763-tracked.patch'
    assert digest_file(baseline_patch) == baseline_freeze['patch_sha256']
    assert digest_file(candidate_patch) == candidate_freeze['patch_sha256']
    baseline_common = {row['path']: row['sha256'] for row in baseline_freeze['common_sources']}
    baseline_tracked = {row['path']: row['sha256'] for row in baseline_freeze['sources']}
    for relative in baseline_freeze['extra_sources']:
        copied = ROOT / 'compact-index-baseline-762-extra-sources' / relative
        expected = baseline_common.get(relative, baseline_tracked.get(relative))
        assert expected and copied.is_file() and digest_file(copied) == expected, relative
    assert set(candidate_freeze['extra_sources']) == {
        str(path.relative_to(ROOT / 'compact-index-candidate-763-extra-sources'))
        for path in (ROOT / 'compact-index-candidate-763-extra-sources').rglob('*') if path.is_file()}
    for relative in candidate_freeze['extra_sources']:
        copied = ROOT / 'compact-index-candidate-763-extra-sources' / relative
        assert source_hashes.get(relative) and copied.is_file()
        assert digest_file(copied) == source_hashes[relative], relative

    for dirname, label in [
        ('compact-index-baseline-762-extra-sources', 'baseline'),
        ('compact-index-candidate-763-extra-sources', 'candidate'),
    ]:
        root = ROOT / dirname
        assert root.is_dir() and not root.is_symlink(), root
        for path in sorted(root.rglob('*')):
            if path.is_file():
                assert not path.is_symlink()
                add_file(members, f'sources/{label}-extra/{path.relative_to(root).as_posix()}', path)
    data_dir = ROOT / 'compact-local-indices-762-a1'
    assert data_dir.is_dir() and not data_dir.is_symlink()
    raw_streams = sorted(data_dir.glob('*.jsonl'))
    witnesses = sorted((data_dir / 'witnesses').glob('*.json'))
    assert len(raw_streams) == 6 and witnesses
    for path in raw_streams + witnesses:
        add_file(members, f'comparison/{path.relative_to(data_dir).as_posix()}', path)

    # Public39 source snapshots and logs are under logs/. Generated output trees
    # are inventoried as omissions below and are never added to archive members.
    public_dir = ROOT / 'compact-index-public-764'
    public_logs = public_dir / 'logs'
    assert public_logs.is_dir(), public_logs
    for path in sorted(public_logs.rglob('*')):
        if path.is_file():
            assert not path.is_symlink()
            add_file(members, f'public/logs/{path.relative_to(public_logs).as_posix()}', path)

    # Exact source, reference packet, schema, and query-harness identities from
    # the accepted plan. These refs include the native query harness dependency closure.
    planned_refs = []
    for key in ('reference', 'schema_sources', 'query_source', 'query_harness',
                'public_runner', 'modular_runner', 'original_modular_runner', 'guard'):
        planned_refs.extend(list(walk_references(plan.get(key))))
    for reference in planned_refs:
        path = verify_reference(reference)
        add_file(members, archive_path(path), path)
    installed_plan = read_json(ROOT / 'compact-index-installed-python-plan-764.json')
    for key in ('driver', 'canonical_prover', 'dependencies'):
        for reference in walk_references(installed_plan.get(key)):
            path = verify_reference(reference)
            if packageable_reference(path):
                add_file(members, archive_path(path), path)

    # Transitive Python closure imported by the modular matrix runner. These
    # are source-only paths, checked against the complete accepted source map.
    modular_sources = [
        'benchmarks/traditional_analytics/benchmark_models.py',
        'benchmarks/traditional_analytics/baseline_catalog.py',
        'benchmarks/traditional_analytics/baselines.py',
        'scripts/check_benchmark_artifact_completeness.py',
        'benchmarks/traditional_analytics/comparison.py',
        'benchmarks/traditional_analytics/fixtures.py',
        'benchmarks/traditional_analytics/native_public_runner.py',
        'benchmarks/traditional_analytics/resources.py',
        'benchmarks/traditional_analytics/run.py',
        'benchmarks/traditional_analytics/worker.py',
        'benchmarks/traditional_analytics/workloads.py',
        'scripts/local_uat_storage.py',
        'scripts/run_clickbench_query_uat.py',
    ]
    for relative in modular_sources:
        expected = source_hashes.get(relative)
        path = REPO / relative
        assert expected and path.is_file() and digest_file(path) == expected, relative
        add_file(members, 'repo/' + relative, path)

    # Include every exact file reference verified by final acceptance, including
    # Full43 timing CSV/logs and all modular cohort report/stdout/stderr artifacts.
    accepted_refs = final.get('verified_file_references')
    assert isinstance(accepted_refs, list) and accepted_refs
    for reference in accepted_refs:
        path = verify_reference(reference)
        if packageable_reference(path):
            add_file(members, archive_path(path), path)

    # Reopen modular report metadata and explicitly bind every cohort report,
    # stdout, and stderr even if one is not repeated in the top-level reference list.
    modular_report = phase_reports['modular']
    cohort_rows = modular_report.get('cohort_reports', modular_report.get('cohorts', []))
    assert len(cohort_rows) == 18, 'all modular cohort report identities are required'
    for row in cohort_rows:
        report_ref = row.get('report')
        if isinstance(report_ref, dict) and set(report_ref) == {'path', 'bytes', 'sha256'}:
            path = verify_reference(report_ref)
            add_file(members, archive_path(path), path)
        elif isinstance(report_ref, str):
            path = Path(report_ref)
            assert path.is_file() and digest_file(path) == row['report_sha256'], path
            add_file(members, archive_path(path), path)
        stdout_ref = row.get('stdout')
        if isinstance(stdout_ref, dict) and set(stdout_ref) == {'path', 'bytes', 'sha256'}:
            stdout_path = verify_reference(stdout_ref)
        else:
            stdout_path = Path(stdout_ref)
            assert stdout_path.is_file() and digest_file(stdout_path) == row['stdout_sha256']
        add_file(members, archive_path(stdout_path), stdout_path)
        stderr_ref = row.get('stderr')
        if isinstance(stderr_ref, dict) and set(stderr_ref) == {'path', 'bytes', 'sha256'}:
            stderr_path = verify_reference(stderr_ref)
        else:
            stderr_path = stdout_path.with_name(stdout_path.name.replace('.stdout.json', '.stderr.txt'))
            expected_stderr_sha = row.get('stderr_sha256')
            assert expected_stderr_sha and stderr_path.is_file()
            assert digest_file(stderr_path) == expected_stderr_sha, stderr_path
        add_file(members, archive_path(stderr_path), stderr_path)

    # Include the installed-Python proof outputs that are not necessarily in
    # the finalizer's reference walk. Verify all receipt logs against the
    # log_sha256 recorded by their passed supervised proof step.
    installed_root = ROOT / 'compact-index-installed-python-764'
    installed_report_path = ROOT / 'compact-index-installed-python-764.json'
    installed_report = read_json(installed_report_path)
    assert installed_report.get('status') == 'passed'
    add_file(members, archive_path(installed_report_path), installed_report_path)
    for key in ('proof', 'context'):
        reference = installed_report[key]
        output_path = verify_reference(reference)
        add_file(members, archive_path(output_path), output_path)
    installed_proof = read_json(Path(installed_report['proof']['path']))
    assert installed_proof.get('status') == 'passed'
    proof_logs = installed_root / 'logs'
    expected_logs = set()
    for step in installed_proof['steps']:
        assert step['returncode'] == 0
        log_name = step['log']
        assert Path(log_name).name == log_name
        log_path = proof_logs / log_name
        assert log_path.is_file() and not log_path.is_symlink()
        assert digest_file(log_path) == step['log_sha256'], log_path
        expected_logs.add(log_path)
        add_file(members, archive_path(log_path), log_path)
    assert expected_logs, 'installed proof must retain its raw step logs'
    integration_path = installed_root / 'integration.json'
    integration = read_json(integration_path)
    assert integration.get('status') == 'passed'
    assert integration.get('failures') == integration.get('errors') == integration.get('skipped') == 0
    add_file(members, archive_path(integration_path), integration_path)
    receipt_names = {
        'proof': 'compact-index-wheel-proof-764.json',
        'reinstall': 'compact-index-wheel-reinstall-764.json',
        'context': 'compact-index-installed-context-764.json',
        'uninstall': 'compact-index-wheel-final-uninstall-764.json',
        'absence': 'compact-index-wheel-final-absence-764.json',
    }
    for step, values in installed_report['receipts'].items():
        assert step in receipt_names
        receipt_path = verify_reference(values['receipt'])
        log_path = verify_reference(values['log'])
        receipt = read_json(receipt_path)
        assert receipt.get('status') == 'passed'
        assert receipt.get('log_sha256') == values['log']['sha256'] == digest_file(log_path), log_path
        assert receipt_path.name == receipt_names[step]
        add_file(members, archive_path(receipt_path), receipt_path)
        add_file(members, archive_path(log_path), log_path)
    # Carry every installed-flow diagnostic log, including intermediate pip,
    # load, and integration logs. Receipt-bound logs above have expected SHA
    # checks; these additional outputs are frozen into the member manifest.
    for path in sorted(proof_logs.glob('*.log')):
        assert path.is_file() and not path.is_symlink()
        add_file(members, archive_path(path), path)

    # Recheck the entire accepted source map at package time. The frozen candidate
    # patch plus both extra-source trees and this complete hash list reproduce the
    # runtime state; HEAD by itself is explicitly insufficient.
    assert source_hashes and source.get('commit_alone_reproduces_sources') is False
    for row in candidate_freeze.get('sources', []):
        path = REPO / row['path']
        assert path.is_file() and path.stat().st_size == row['bytes']
        assert digest_file(path) == row['sha256'], path

    # Record omitted executables, CLI, extension, wheel, retained input, and
    # generated public payloads with the evidence needed to regenerate them.
    omissions = []
    artifact_bindings: dict[str, dict] = {}
    for path in sorted(ROOT.glob('compact-index-*.json')):
        try:
            collect_artifact_paths(read_json(path), artifact_bindings)
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
    # Bind every required build product explicitly; none is copied into the packet.
    required_omissions: dict[str, dict] = {}
    for receipt_name, build_label in [
        ('compact-index-baseline-762-artifact.json', 'baseline'),
        ('compact-index-candidate-763-artifact.json', 'candidate'),
    ]:
        receipt = read_json(ROOT / receipt_name)
        artifact = Path(receipt['artifact'])
        binding = {'sha256': receipt['artifact_sha256'], 'bytes': receipt['bytes'],
                   'field': f'{build_label}_test_executable'}
        artifact_bindings[str(artifact)] = binding
        required_omissions[str(artifact)] = {
            **binding,
            'reproduction': {
                'artifact_record': f'evidence/{receipt_name}',
                'build_receipt': f"evidence/{receipt['build']}.json",
                'build_log': f"evidence/{receipt['build']}.log",
                'source_freeze': f'evidence/compact-index-{build_label}-'
                                 f"{'762' if build_label == 'baseline' else '763'}-source-freeze.json",
                'tracked_patch': f'evidence/compact-index-{build_label}-'
                                 f"{'762' if build_label == 'baseline' else '763'}-tracked.patch",
                'extra_source_directory': f'sources/{build_label}-extra/',
            },
        }
    accepted_cli = {'sha256': build['binary_sha256'], 'field': 'binary'}
    artifact_bindings[build['binary']] = accepted_cli
    required_omissions[build['binary']] = {
        **accepted_cli,
        'reproduction': {'build_manifest': 'evidence/compact-index-acceptance-build-764.json',
                         'source_manifest': 'evidence/compact-index-acceptance-source-764.json',
                         'native_cli_gate': 'evidence/compact-index-native-cli-gate-764.json'},
    }
    library = build['native_library']
    library_binding = {'sha256': library['sha256'], 'bytes': library['bytes'],
                       'field': 'native_library'}
    artifact_bindings[library['path']] = library_binding
    required_omissions[library['path']] = {
        **library_binding,
        'reproduction': {'build_manifest': 'evidence/compact-index-acceptance-build-764.json',
                         'source_manifest': 'evidence/compact-index-acceptance-source-764.json',
                         'installed_python_report': 'evidence/compact-index-installed-python-764.json'},
    }
    installed_report = read_json(ROOT / 'compact-index-installed-python-764.json')
    wheel = installed_report['wheel']
    wheel_binding = {'sha256': wheel['sha256'], 'bytes': wheel['bytes'], 'field': 'wheel'}
    artifact_bindings[wheel['path']] = wheel_binding
    required_omissions[wheel['path']] = {
        **wheel_binding,
        'reproduction': {'installed_python_report': 'evidence/compact-index-installed-python-764.json',
                         'installed_python_plan': 'evidence/compact-index-installed-python-plan-764.json',
                         'wheel_proof': 'evidence/compact-index-wheel-proof-764.json'},
    }
    # Known build products with SHA-bound receipts; none are copied.
    for path_text, binding in sorted(artifact_bindings.items()):
        artifact = Path(path_text)
        if not artifact.is_file() or artifact.is_symlink():
            continue
        field = binding.get('field', 'build_artifact')
        category = {
            'artifact': 'copied_test_executable',
            'baseline_test_executable': 'copied_test_executable',
            'candidate_test_executable': 'copied_test_executable',
            'binary': 'public_cli_executable',
            'cli': 'public_cli_executable',
            'cli_binary': 'public_cli_executable',
            'native_library': 'native_extension',
            'extension': 'native_extension',
            'wheel': 'python_wheel',
        }.get(field, 'build_executable_or_extension')
        reproduction = required_omissions.get(str(artifact), {}).get('reproduction', {
            'build_or_artifact_binding': field,
            'build_manifest': 'evidence/compact-index-acceptance-build-764.json',
            'source_manifest': 'evidence/compact-index-acceptance-source-764.json',
        })
        omissions.append(record_omission(
            artifact, category,
            reproduction,
            known_sha256=binding.get('sha256'), known_bytes=binding.get('bytes')))
    assert set(required_omissions) <= {row['path'] for row in omissions}, (
        'one or more required omitted executable/package identities are missing')

    input_path = Path(plan['input']['path'])
    input_generation = plan['input']['generation']
    input_stat = input_path.stat()
    assert (input_stat.st_dev, input_stat.st_ino, input_stat.st_size,
            input_stat.st_mtime_ns, input_stat.st_ctime_ns) == (
        input_generation['device'], input_generation['inode'],
        input_generation['size_bytes'], input_generation['mtime_ns'],
        input_generation['ctime_ns'])
    omissions.append(record_omission(
        input_path, 'retained_vortex_input',
        {'acceptance_plan': 'evidence/compact-index-acceptance-plan-764.json',
         'reference_packet': archive_path(Path(plan['reference']['path'])),
         'regeneration': 'Input is retained locally; it is intentionally not copied.'},
        known_sha256=plan['input']['sha256'], known_bytes=input_generation['size_bytes'],
        hash_current_file=False))

    generated_public_payloads = []
    output_root = public_dir / 'outputs'
    for path in sorted(output_root.rglob('*')):
        if path.is_file():
            assert not path.is_symlink()
            generated_public_payloads.append({
                'path': str(path), 'bytes': path.stat().st_size,
                'sha256': digest_file(path), 'copied': False,
                'reproduction': {
                    'runner': 'repo/scripts/run_native_streaming_input_uat.py',
                    'plan': 'evidence/compact-index-complete-public-plan-764.json',
                    'summary': phase_reports['public']['summary']['path'],
                    'fixture_and_source_identity': 'public/logs/source snapshots and accepted Public39 summary',
                },
            })

    # Freeze all selected inputs before writing. Hashes and byte lengths are
    # rechecked immediately before archive insertion and again after readback.
    inventory = []
    members_before = {}
    for member_name, source_path in sorted(members.items()):
        data = source_path.read_bytes()
        row = {'path': member_name, 'original_path': str(source_path),
               'bytes': len(data), 'sha256': digest(data)}
        inventory.append(row)
        members_before[member_name] = (row['bytes'], row['sha256'])
    assert inventory and all(not row['path'].startswith('public/outputs/') for row in inventory)
    assert not any(Path(row['path']).suffix.lower() in ARTIFACT_SUFFIXES for row in inventory)
    uncompressed_bytes = sum(row['bytes'] for row in inventory)

    require_local_path(DEST, Path.home(), sys.platform)
    check_budgets(ROOT, DEST, ROOT / 'logs', min_free_bytes=12 * GIB,
                  reserve_bytes=128 * MIB, max_workspace_bytes=100 * GIB,
                  max_log_bytes=192 * MIB)
    assert not DEST.exists(), f'unique packet destination required: {DEST}'
    DEST.mkdir()
    archive_pathname = DEST / (NAME + '.tar.xz')
    with tarfile.open(archive_pathname, mode='x:xz', format=tarfile.PAX_FORMAT, preset=6) as output:
        for row in inventory:
            source_path = members[row['path']]
            data = source_path.read_bytes()
            assert (len(data), digest(data)) == (row['bytes'], row['sha256']), source_path
            info = tarfile.TarInfo(row['path'])
            info.size = len(data)
            info.mode = 0o644
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            info.mtime = 0
            output.addfile(info, io.BytesIO(data))

    with tarfile.open(archive_pathname, 'r:xz') as archive:
        assert archive.getnames() == [row['path'] for row in inventory]
        for row in inventory:
            member = archive.extractfile(row['path'])
            assert member is not None
            data = member.read()
            assert (len(data), digest(data)) == (row['bytes'], row['sha256']), row['path']
    for member_name, source_path in members.items():
        assert (source_path.stat().st_size, digest_file(source_path)) == members_before[member_name], source_path

    manifest = {'schema_version': 'shardloom.evidence_member_manifest.v1',
                'all_members_reopened': True, 'members': inventory}
    manifest_data = lzma.compress(encode(manifest), preset=6)
    manifest_path = DEST / (NAME + '.manifest.json.xz')
    with manifest_path.open('xb') as stream:
        stream.write(manifest_data)
    assert json.loads(lzma.decompress(manifest_path.read_bytes())) == manifest

    index = {
        'schema_version': 'shardloom.compact_indices_portable_packet.v1',
        'status': 'accepted_candidate_evidence_packet',
        'production_accepted': True,
        'scope': 'bounded U16 local-index candidate passed its frozen comparison and current-host acceptance gates',
        'claim_limit': {
            'cpu_speedup_claim': False,
            'platform_or_release_certification_claim': False,
            'broader_owner_and_conditional_substep_remain_open': True,
            'publication_attempted': False,
        },
        'final_acceptance': identity(FINAL_PATH),
        'protocol': {'path': 'evidence/compact-local-indices-protocol-762.json',
                     'sha256': EXPECTED_PROTOCOL_SHA},
        'source_identity': {
            'source_commit': source['source_commit'],
            'commit_alone_reproduces_sources': False,
            'complete_source_hashes': 'evidence/compact-index-acceptance-source-764.json',
            'candidate_source_freeze': 'evidence/compact-index-candidate-763-source-freeze.json',
            'candidate_tracked_patch': 'evidence/compact-index-candidate-763-tracked.patch',
            'candidate_extra_sources': [
                'sources/candidate-extra/' + path.relative_to(ROOT / 'compact-index-candidate-763-extra-sources').as_posix()
                for path in sorted((ROOT / 'compact-index-candidate-763-extra-sources').rglob('*')) if path.is_file()],
            'baseline_tracked_patch': 'evidence/compact-index-baseline-762-tracked.patch',
            'baseline_extra_source_directory': 'sources/baseline-extra/',
            'accepted_source_count': len(source_hashes),
        },
        'acceptance': {
            'public39': final['acceptance']['public'],
            'full43': final['acceptance']['full43'],
            'modular': final['acceptance']['modular'],
        },
        'inclusions': {
            'compact_root_receipts_and_corrections': True,
            'all_compact_python_drivers': True,
            'raw_preflight_and_four_measurement_streams': [row['path'] for row in inventory if row['path'].endswith('.jsonl')],
            'all_fixture_witnesses': len(witnesses),
            'public39_source_snapshots_and_logs': 'public/logs/',
            'full43_timing_logs_and_csv': 'included by final-acceptance exact-file references',
            'modular_cohort_reports_stdout_stderr': len(cohort_rows),
            'installed_python_reports_and_logs': [
                'evidence/compact-index-installed-python-764.json',
                'evidence/compact-index-installed-python-764/report.json',
                'evidence/compact-index-installed-python-764/public-context.json',
                'evidence/compact-index-installed-python-764/integration.json',
                'evidence/compact-index-installed-python-764/logs/*.log',
                'receipt-bound and internal proof logs verified against each passed step log_sha256'],
        },
        'omitted_artifacts': omissions,
        'omitted_generated_public_payloads': {
            'files': generated_public_payloads,
            'regenerate_from': 'public/logs/run_native_streaming_input_uat.py plus compact-index-complete-public-plan-764.json',
        },
        'omitted_modular_payload_policy': {
            'status': 'generated workflow payloads and temporary workspaces are not copied',
            'regenerate_from': 'compact_modular_runner_764.py and the archived accepted build/fixture/report identities',
            'cohort_report_identities': [row.get('report') for row in cohort_rows],
        },
        'excluded_cargo_cache': {
            'path': '/Users/dylan/.cache/shardloom/cargo-target',
            'status': 'not copied; compiler outputs are rebuildable and are referenced by build receipts/logs',
        },
        'member_count': len(inventory),
        'uncompressed_bytes': uncompressed_bytes,
        'all_members_reopened': True,
        'archive': {'file': archive_pathname.name, 'bytes': archive_pathname.stat().st_size,
                    'sha256': digest_file(archive_pathname)},
        'manifest': {'file': manifest_path.name, 'bytes': manifest_path.stat().st_size,
                     'sha256': digest_file(manifest_path)},
    }
    index_path = DEST / (NAME + '.json')
    with index_path.open('xb') as stream:
        stream.write(encode(index))
    check_budgets(ROOT, DEST, ROOT / 'logs', min_free_bytes=12 * GIB,
                  reserve_bytes=0, max_workspace_bytes=100 * GIB,
                  max_log_bytes=192 * MIB)
    print(json.dumps({'status': 'passed', 'members': len(inventory),
                      'uncompressed_bytes': uncompressed_bytes,
                      'archive': index['archive'], 'manifest': index['manifest'],
                      'index': str(index_path), 'all_members_reopened': True}))


if __name__ == '__main__':
    main()
