"""Synthetic adversarial checks; never performance observations."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import tempfile

import analyze_compact_indices_762 as a

OUT=Path(__file__).resolve().parent

def main():
    checks=[]
    with tempfile.TemporaryDirectory(prefix='compact-oracle-check-',dir=OUT) as directory:
        root=Path(directory);(root/'witnesses').mkdir()
        def witness(value):
            data=a.encoded(value);key=hashlib.sha256(data).hexdigest()
            (root/'witnesses'/f'{key}.json').write_bytes(data)
            return key
        spec=dict(rows=32,shape='dense',consumer='projection',calls=1)
        output=a.expected_rows(spec)
        record=dict(**spec,cell_id=a.identity(spec),role='baseline',cohort='preflight',sample=0,warmup=False,
            source_rows_witness=witness(a.source_rows(spec)),source_schema_witness=witness(a.schema(spec,True)),
            expected_rows_witness=witness(output),expected_schema_witness=witness(a.schema(spec)),
            reserved_after_cleanup=0,denied_reservations=0,peak_reserved_bytes=100000,
            completed_executions=1,prepared_source_opens=0,provider_background_workers=0,admitted_max_parallelism=1,
            preparation_ns=1000,destruction_ns=100,complete_workflow_ns=2200,
            selection={key:0 for key in a.COUNTERS},operations=[dict(call=0,completed_executions=1,rows=len(output),
                actual_rows_witness=witness(output),actual_schema_witness=witness(a.schema(spec)),
                engine_execution_ns=700,result_serialization_ns=200,execution_and_consumption_ns=1000,
                output_release_ns=100,native_io_certificate=dict(certified=True,fallback_attempted=False,
                    complete_debug='NativeIoCertificate { fallback_attempted: false }'))])
        def validate(item,role='baseline',chosen=spec):
            a.validate(item,chosen,role,'preflight',0,False,a.Witnesses(root))
        validate(record);checks.append('positive_baseline')
        def reject(name,change,role='baseline',original=record,chosen=spec):
            item=deepcopy(original);change(item)
            try:validate(item,role,chosen)
            except (AssertionError,KeyError,TypeError,FileNotFoundError):checks.append(name)
            else:raise AssertionError('accepted corrupt record: '+name)
        def top(key,value):return lambda r:r.__setitem__(key,value)
        def op(key,value):return lambda r:r['operations'][0].__setitem__(key,value)
        for key,value in [('rows',31),('cell_id','wrong'),('role','candidate'),('sample',1),('warmup',True),
            ('source_rows_witness','0'*64),('source_schema_witness','0'*64),('expected_rows_witness','0'*64),
            ('expected_schema_witness','0'*64),('reserved_after_cleanup',1),('denied_reservations',1),
            ('peak_reserved_bytes',(32<<20)+1),('completed_executions',0),('prepared_source_opens',1),
            ('provider_background_workers',1),('admitted_max_parallelism',2),('preparation_ns',0),
            ('complete_workflow_ns',2199),('operations',[])]:reject(key,top(key,value))
        for key,value in [('call',1),('completed_executions',0),('rows',len(output)+1),
            ('actual_rows_witness','0'*64),('actual_schema_witness','0'*64),('engine_execution_ns',-1),
            ('engine_execution_ns',True),('execution_and_consumption_ns',899)]:reject('operation_'+key,op(key,value))
        for key,value in [('certified',False),('fallback_attempted',True),('complete_debug','unbound')]:
            reject('certificate_'+key,lambda r,k=key,v=value:r['operations'][0]['native_io_certificate'].__setitem__(k,v))
        reject('baseline_activation',lambda r:r['selection'].__setitem__('compact_owners',1))
        candidate=deepcopy(record);candidate['role']='candidate'
        candidate['selection']=dict(compact_owners=2,compact_input_rows=64,maximum_local_extent=32,u16_take_arrays=1,u16_take_rows=1)
        validate(candidate,'candidate');checks.append('positive_candidate')
        for key,value in [('compact_owners',0),('compact_input_rows',63),('maximum_local_extent',65537),
            ('u16_take_arrays',0),('u16_take_rows',0)]:
            reject('candidate_'+key,lambda r,k=key,v=value:r['selection'].__setitem__(k,v),'candidate',candidate)
        key=record['source_rows_witness'];path=root/'witnesses'/f'{key}.json';data=path.read_bytes();path.write_bytes(b'[]')
        reject('tampered_witness_bytes',lambda r:None);path.write_bytes(data)
        for mode,cohort in [('preflight','preflight'),('measure','A')]:
            path=root/f'{mode}-{cohort}-baseline.jsonl';path.write_text(json.dumps(record)+'\n')
            try:a.read(root,mode,'baseline',cohort,a.Witnesses(root))
            except AssertionError:checks.append('incomplete_'+mode)
            else:raise AssertionError('accepted incomplete corpus')

    def synthetic(role):
        return [dict(cell_id=a.identity(s),warmup=False,operations=[dict(engine_execution_ns=20_000_000)],
            complete_workflow_ns=30_000_000,peak_reserved_bytes=1_000_000 if role=='baseline' else 900_000)
            for s in a.specs() for _ in range(3)]
    cohorts={c:{r:synthetic(r) for r in ['baseline','candidate']} for c in ['A','B']}
    assert a.analyze(cohorts)['finite_comparison_passed'];checks.append('all_synthetic_gates_pass')
    for cohort in ['A','B']:
        for field,value,gate in [('peak_reserved_bytes',999999,'memory_target'),
            ('peak_reserved_bytes',1008193,'memory_regression'),('complete_workflow_ns',32000000,'complete_regression'),
            ('engine_execution_ns',22000000,'engine_regression')]:
            changed=deepcopy(cohorts)
            for row in changed[cohort]['candidate'][:3]:
                if field=='engine_execution_ns':row['operations'][0][field]=value
                else:row[field]=value
            result=a.analyze(changed)
            assert not result['finite_comparison_passed'] and not result['production_accepted']
            assert any(f['failed_gate']==gate and f['cohort']==cohort for f in result['failed_gates'])
            checks.append(cohort+'_'+gate)
    a.self_tests();checks.append('frozen_threshold_boundary_tests')
    result=dict(kind='synthetic_analyzer_adversarial_checks',performance_observation=False,
        passed=True,checks=checks,check_count=len(checks),analyzer_sha256=a.sha(a.__file__),test_sha256=a.sha(__file__))
    path=OUT/'compact-analyzer-tests-corrected-763.json'
    with path.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps(dict(passed=True,checks=len(checks),receipt=str(path))))

if __name__=='__main__':main()
