"""Independently reopen the compact-index packet without its packager helpers."""
import csv
from decimal import Decimal
import hashlib
import io
import json
import lzma
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
PACKET = ROOT / 'compact-index-portable-765'
INDEX = PACKET / 'compact-index-portable-765.json'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


index = read(INDEX)
assert index['production_accepted'] and index['all_members_reopened']
assert index['claim_limit']['cpu_speedup_claim'] is False
for key in ('archive', 'manifest'):
    ref = index[key]
    data = (PACKET / ref['file']).read_bytes()
    assert len(data) == ref['bytes'] and sha(data) == ref['sha256']
manifest = json.loads(lzma.decompress((PACKET / index['manifest']['file']).read_bytes()))
rows = manifest['members']
assert len(rows) == index['member_count']
assert len({row['path'] for row in rows}) == len(rows)
assert sum(row['bytes'] for row in rows) == index['uncompressed_bytes']
by_original = {}
with tarfile.open(PACKET / index['archive']['file'], 'r:xz') as archive:
    members = archive.getmembers()
    assert [member.name for member in members] == [row['path'] for row in rows]
    for member, row in zip(members, rows, strict=True):
        assert member.isfile() and not member.issym() and not member.islnk()
        assert not member.name.startswith('/') and '..' not in Path(member.name).parts
        data = archive.extractfile(member).read()
        assert len(data) == row['bytes'] and sha(data) == row['sha256'], member.name
        original = Path(row['original_path'])
        assert original.is_file() and not original.is_symlink()
        assert sha(original.read_bytes()) == row['sha256'], original
        if str(original) in by_original:
            assert by_original[str(original)] == data
        by_original[str(original)] = data


def archived_json(path):
    return json.loads(by_original[str(path)])


def exact_reference(ref):
    data = by_original[ref['path']]
    assert len(data) == ref['bytes'] and sha(data) == ref['sha256']
    return data


final = json.loads(exact_reference(index['final_acceptance']))
assert final['status'] == 'passed' and final['production_accepted']
assert final['comparison_recomputed_from_raw']
assert final['public_cases'] == 5930 and final['public_families'] == 39
reports = {phase: json.loads(exact_reference(ref))
           for phase, ref in final['acceptance'].items()}
public = reports['public']
assert public['families'] == 39 and public['cases'] == 5930
assert public['no_fallback_envelopes'] == 8151
assert public['compressed_log_members_verified'] == 16389
for ref in public['logs']:
    exact_reference(ref)
full = reports['full43']
assert full['queries'] == full['calls'] == 43 and full['complete_rows'] == 381
timings = list(csv.DictReader(io.StringIO(exact_reference(full['timing_csv']).decode())))
assert len(timings) == 43
engine_total = sum(Decimal(row['engine_execution_seconds']) for row in timings)
assert engine_total == Decimal(full['engine_execution_seconds']) == Decimal('50.31151625')
for ref in full['envelopes']:
    exact_reference(ref)
modular = reports['modular']
assert modular['native_workflows'] == modular['independent_pandas_oracle_workflows'] == 704
assert len(modular['cohort_reports']) == 18
for row in modular['cohort_reports']:
    for key in ('report', 'stdout', 'stderr'):
        if isinstance(row.get(key), dict):
            exact_reference(row[key])
        else:
            path = row.get(key)
            if path is None and key == 'stderr':
                path = row['stdout'].replace('.stdout.json', '.stderr.txt')
            assert sha(by_original[path]) == row[key + '_sha256']

installed = json.loads(exact_reference(final['installed_python']))
proof = json.loads(exact_reference(installed['proof']))
proof_root = Path(installed['proof']['path']).parent
assert len(proof['steps']) == 8
for step in proof['steps']:
    data = by_original[str(proof_root / step['log'])]
    assert step['returncode'] == 0 and sha(data) == step['log_sha256']
assert archived_json(proof_root / 'integration.json')['tests'] == 105
assert installed['installed_context_tests'] == 19
assert installed['final_uninstall_verified']
source = archived_json(ROOT / 'compact-index-acceptance-source-764.json')
assert len(source['source_hashes']) == 2217
for path, expected in source['source_hashes'].items():
    assert sha((REPO / path).read_bytes()) == expected, path
assert len([row for row in rows if row['path'].startswith('comparison/')
            and row['path'].endswith('.jsonl')]) == 6
assert all(not row['path'].startswith('public/outputs/') for row in rows)
assert len(index['omitted_artifacts']) >= 6

receipt = dict(schema_version='shardloom.compact_packet_independent_reopen.v1',
               status='passed', archive=index['archive'], manifest=index['manifest'],
               index_sha256=sha(INDEX.read_bytes()), members=len(rows),
               all_members_and_originals_reopened=True,
               public_compressed_logs=16389, public_cases=5930,
               installed_proof_logs=8, installed_binding_tests=105, installed_context_tests=19,
               full43_queries=43, full43_engine_execution_seconds=str(engine_total),
               modular_native_workflows=704, independent_oracle_workflows=704,
               accepted_source_files_unchanged=2217,
               verifier_sha256=sha(Path(__file__).read_bytes()))
with (ROOT / 'compact-index-packet-verification-766.json').open('x') as output:
    json.dump(receipt, output, indent=2)
    output.write('\n')
print(json.dumps(receipt))
