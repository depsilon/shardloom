"""Freeze, freshly compile and check the compact-index candidate before comparison."""
import json
from pathlib import Path
import re
import subprocess
import sys

OUT=Path(__file__).resolve().parent
REPO=Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
DRIVER=OUT/'compact_index_driver_762.py'
GUARD=OUT/'run_guarded_observed_757.py'
LABEL='compact-index-candidate-763'
def run(command):subprocess.run(command,cwd=REPO,check=True)
lint=json.loads((OUT/'compact-index-candidate-clippy-fixed-763.json').read_text())
assert lint['status']=='passed' and lint['process_group_drained']
run([sys.executable,str(DRIVER),'freeze','--label',LABEL])
run([sys.executable,str(GUARD),'--name','compact-index-candidate-build-763','--timeout','1800','--',
    '/Users/dylan/.cargo/bin/rustup','run','1.99.0','cargo','test','--offline','--locked','--release','-p','shardloom-vortex',
    '--features','release-user-surfaces','--lib','--no-run','--message-format=json'])
run([sys.executable,str(DRIVER),'bind','--label',LABEL,'--build','compact-index-candidate-build-763'])
artifact=json.loads((OUT/f'{LABEL}-artifact.json').read_text())
baseline=json.loads((OUT/'compact-index-baseline-762-artifact.json').read_text())
assert artifact['artifact_sha256']!=baseline['artifact_sha256']
inventory=(OUT/f'{LABEL}-test-inventory.txt').read_text().splitlines()
checks=[]
for short,selector in [
    ('new','local_primitives::prepared_relational::selection::tests::'),
    ('existing-selection','local_primitives::prepared_relational::tests::selection_tests::'),
    ('memory','local_primitives::prepared_relational::tests::memory_tests::'),
    ('ownership','local_primitives::prepared_relational::tests::native_ownership_tests::'),
    ('nested','local_primitives::prepared_relational::tests::nested_tests::'),
]:
    expected=sum(line.startswith(selector) and line.endswith(': test') for line in inventory)
    assert expected>0
    name=f'compact-index-{short}-tests-763'
    run([sys.executable,str(GUARD),'--name',name,'--timeout','1800','--',artifact['artifact'],selector,'--nocapture','--test-threads=1'])
    log=(OUT/f'{name}.log').read_text()
    matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
    assert matches==[(str(expected),'0','0')],(selector,expected,matches)
    checks.append(dict(selector=selector,expected_and_passed=expected,receipt=name+'.json'))
with (OUT/'compact-index-focused-tests-763.json').open('x') as stream:
    json.dump(dict(passed=True,artifact_sha256=artifact['artifact_sha256'],checks=checks),stream,indent=2);stream.write('\n')
run([sys.executable,str(DRIVER),'run','--label',LABEL,'--name','compact-index-candidate-preflight-763','--mode','preflight','--role','candidate'])
run([sys.executable,str(OUT/'analyze_compact_indices_762.py'),'--root',str(OUT/'compact-local-indices-762-a1'),'--preflight',
    '--output',str(OUT/'compact-index-both-preflight-analysis-763.json')])
run([sys.executable,str(DRIVER),'verify','--label',LABEL])
