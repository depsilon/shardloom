"""Run the two frozen cohorts without intermediate comparative inspection."""
import json
from pathlib import Path
import subprocess
import sys
import compact_index_driver_762 as driver

OUT=Path(__file__).resolve().parent
REPO=driver.REPO
BASE='compact-index-baseline-762'
CANDIDATE='compact-index-candidate-763'
DATA=OUT/'compact-local-indices-762-a1'
def run(command):subprocess.run(command,cwd=REPO,check=True)
preflight=OUT/'compact-index-both-preflight-analysis-763.json'
result=json.loads(preflight.read_text())
assert result['roles']==['baseline','candidate']
assert sum(row['workflows'] for row in result['receipts'])==168
assert sum(row['operations'] for row in result['receipts'])==420
assert json.loads((OUT/'compact-index-focused-tests-763.json').read_text())['passed']
analyzer_checks=json.loads((OUT/'compact-analyzer-tests-corrected-763.json').read_text())
assert analyzer_checks['passed'] and analyzer_checks['analyzer_sha256']==driver.sha(OUT/'analyze_compact_indices_762.py')
assert not list(DATA.glob('measure-*.jsonl'))
files=[Path(__file__),OUT/'compact_index_driver_762.py',OUT/'analyze_compact_indices_762.py',
    OUT/'run_guarded_observed_757.py',OUT/'compact-local-indices-protocol-762.json',
    OUT/'build_compact_baseline_762.py',OUT/'build_compact_candidate_763.py',OUT/'test_compact_analyzer_763.py',
    OUT/'test_compact_analyzer_corrected_763.py',OUT/'compact-index-analyzer-correction-763.json']
files.extend(REPO/'scripts'/name for name in [
    'local_uat_storage.py','run_clickbench_paired_query_uat.py','run_clickbench_query_uat.py',
    'native_workflow_protocol.py','query_timing_report.py','clickbench_reference_packet.py'])
files.extend([Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'),
    Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')])
closure=[dict(path=str(path),bytes=path.stat().st_size,sha256=driver.sha(path)) for path in files]
artifacts={role:json.loads((OUT/f'{label}-artifact.json').read_text()) for role,label in [('baseline',BASE),('candidate',CANDIDATE)]}
assert len({row['artifact_sha256'] for row in artifacts.values()})==2
for label in [BASE,CANDIDATE]:
    run([sys.executable,str(OUT/'compact_index_driver_762.py'),'verify','--label',label,'--workspace-label',CANDIDATE])
freeze=dict(schema_version='shardloom.compact_indices_measurement_freeze.v1',
    protocol_sha256=driver.PROTOCOL_SHA,preflight_sha256=driver.sha(preflight),
    artifacts=artifacts,closure=closure,order=[['A','baseline'],['A','candidate'],['B','candidate'],['B','baseline']],
    all_cohorts_complete_before_comparative_analysis=True,
    common_harness=driver.COMMON,samples_per_cell_role=3,measurement_cells=28,
    workflows_including_warmups=340,operations_including_warmups=844)
driver.save(OUT/'compact-index-measurement-freeze-763.json',freeze)
def verify_closure():
    for row in closure:
        path=Path(row['path']);assert path.stat().st_size==row['bytes'] and driver.sha(path)==row['sha256'],path
for cohort,role in freeze['order']:
    verify_closure()
    label=BASE if role=='baseline' else CANDIDATE
    run([sys.executable,str(OUT/'compact_index_driver_762.py'),'run','--label',label,'--workspace-label',CANDIDATE,
        '--name',f'compact-index-measure-{cohort}-{role}-763','--mode','measure','--role',role,'--cohort',cohort])
    verify_closure()
run([sys.executable,str(OUT/'analyze_compact_indices_762.py'),'--root',str(DATA),'--output',str(OUT/'compact-index-decision-763.json')])
verify_closure()
for label in [BASE,CANDIDATE]:
    run([sys.executable,str(OUT/'compact_index_driver_762.py'),'verify','--label',label,'--workspace-label',CANDIDATE])
