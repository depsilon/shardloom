"""Freeze and supervise separate original/compact native binaries with exact source binding."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

REPO=Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
OUT=Path(__file__).resolve().parent
PROTOCOL=OUT/'compact-local-indices-protocol-762.json'
PROTOCOL_SHA='7f7bf6830ec162999ee2f946a59894f9bd8edce9f80d0c3a747560926b2d73ad'
GUARD=OUT/'run_guarded_observed_757.py'
SELECTOR='local_primitives::prepared_relational::tests::compact_index_cost_tests::native_compact_local_indices_screen'
COMMON=[
    'shardloom-vortex/src/local_primitive_relational_compact_index_cost_tests.rs',
    'shardloom-vortex/src/local_primitives/native_local_selection_observation.rs',
]
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with Path(path).open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')
def source_paths():
    names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=REPO,text=True).splitlines()
    return sorted(p for p in set(names) if p.endswith('.rs') or Path(p).name in ('Cargo.toml','Cargo.toml.orig','Cargo.lock'))
def verify_sources(freeze):
    assert sha(PROTOCOL)==PROTOCOL_SHA
    assert source_paths()==[r['path'] for r in freeze['sources']]
    for row in freeze['sources']:
        path=REPO/row['path'];assert path.stat().st_size==row['bytes'] and sha(path)==row['sha256'],row['path']
def historical_sources(label,freeze):
    assert sha(OUT/f'{label}-tracked.patch')==freeze['patch_sha256']
    sources={r['path']:r for r in freeze['sources']}
    for path in freeze['extra_sources']:
        original=OUT/f'{label}-extra-sources'/path
        assert original.stat().st_size==sources[path]['bytes'] and sha(original)==sources[path]['sha256']

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['freeze','bind','verify','run'])
    parser.add_argument('--label',required=True)
    parser.add_argument('--workspace-label')
    parser.add_argument('--build')
    parser.add_argument('--name')
    parser.add_argument('--mode',choices=['preflight','measure'])
    parser.add_argument('--role',choices=['baseline','candidate'])
    parser.add_argument('--cohort',default='preflight',choices=['preflight','A','B'])
    parser.add_argument('--data',default='compact-local-indices-762-a1')
    args=parser.parse_args()
    assert args.label.replace('-','').isalnum() and sha(PROTOCOL)==PROTOCOL_SHA
    freeze_path=OUT/f'{args.label}-source-freeze.json';artifact_path=OUT/f'{args.label}-artifact.json'
    if args.action=='freeze':
        sources=[dict(path=p,bytes=(REPO/p).stat().st_size,sha256=sha(REPO/p)) for p in source_paths()]
        patch=OUT/f'{args.label}-tracked.patch'
        with patch.open('xb') as stream:stream.write(subprocess.check_output(['git','diff','--binary'],cwd=REPO))
        extras=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=REPO,text=True).splitlines()
        extras=[p for p in extras if p in source_paths()]
        for path in extras:
            target=OUT/f'{args.label}-extra-sources'/path;target.parent.mkdir(parents=True,exist_ok=True)
            assert not target.exists();shutil.copyfile(REPO/path,target)
        save(freeze_path,dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
            sources=sources,extra_sources=extras,patch_sha256=sha(patch),protocol_sha256=PROTOCOL_SHA,
            driver_sha256=sha(__file__),common_sources=[dict(path=p,sha256=sha(REPO/p)) for p in COMMON]))
        print(json.dumps(dict(source_freeze=str(freeze_path),sha256=sha(freeze_path),runtime_inputs=len(sources))));return
    freeze=json.loads(freeze_path.read_text());historical_sources(args.label,freeze)
    workspace_label=args.workspace_label or args.label
    workspace_freeze=json.loads((OUT/f'{workspace_label}-source-freeze.json').read_text())
    verify_sources(workspace_freeze)
    assert freeze['common_sources']==workspace_freeze['common_sources']
    if args.action=='bind':
        assert workspace_label==args.label and args.build
        build_path=OUT/f'{args.build}.json';build=json.loads(build_path.read_text())
        assert build['status']=='passed' and build['process_group_drained'] and build['returncode']==0
        artifacts=[]
        for line in (OUT/f'{args.build}.log').read_text().splitlines():
            if not line.startswith('{'):continue
            item=json.loads(line)
            if item.get('reason')=='compiler-artifact' and item.get('target',{}).get('name')=='shardloom_vortex' and item.get('profile',{}).get('test'):artifacts.append(item)
        assert len(artifacts)==1 and artifacts[0]['executable'] and not artifacts[0]['fresh']
        source=Path(artifacts[0]['executable']);binary=OUT/f'{args.label}-test';assert not binary.exists()
        shutil.copy2(source,binary);assert sha(binary)==sha(source)
        inventory=subprocess.check_output([str(binary),'--list'],text=True)
        assert f'{SELECTOR}: test' in inventory
        (OUT/f'{args.label}-test-inventory.txt').write_text(inventory)
        save(artifact_path,dict(artifact=str(binary),artifact_sha256=sha(binary),bytes=binary.stat().st_size,
            source_freeze_sha256=sha(freeze_path),build=args.build,build_receipt_sha256=sha(build_path),compiler_artifact=artifacts[0]))
        print(json.dumps(dict(artifact=str(binary),sha256=sha(binary))));return
    artifact=json.loads(artifact_path.read_text());binary=Path(artifact['artifact'])
    assert sha(binary)==artifact['artifact_sha256'] and sha(freeze_path)==artifact['source_freeze_sha256']
    if args.action=='verify':
        print(json.dumps(dict(workspace_sources_unchanged=True,artifact_and_historical_source_binding_unchanged=True)));return
    assert args.name and args.mode and args.role
    assert args.label.startswith(f'compact-index-{args.role}-')
    data=OUT/args.data
    assert data.parent==OUT and data.name.startswith('compact-local-indices-')
    data.mkdir(exist_ok=True)
    command=[sys.executable,str(GUARD),'--name',args.name,'--timeout','1800','--','/usr/bin/env',
        f'SHARDLOOM_COMPACT_INDEX_ROOT={data}',f'SHARDLOOM_COMPACT_INDEX_MODE={args.mode}',
        f'SHARDLOOM_COMPACT_INDEX_ROLE={args.role}',f'SHARDLOOM_COMPACT_INDEX_COHORT={args.cohort}',
        str(binary),SELECTOR,'--exact','--ignored','--nocapture','--test-threads=1']
    record=dict(command=command,role=args.role,mode=args.mode,cohort=args.cohort,
        artifact_sha256=sha(binary),source_freeze_sha256=sha(freeze_path),
        workspace_source_freeze_sha256=sha(OUT/f'{workspace_label}-source-freeze.json'),
        protocol_sha256=PROTOCOL_SHA,driver_sha256=sha(__file__),guard_sha256=sha(GUARD))
    try:
        code=subprocess.call(command,cwd=REPO);record['returncode']=code
        verify_sources(workspace_freeze);historical_sources(args.label,freeze)
        assert sha(binary)==artifact['artifact_sha256'];record['sources_and_artifact_unchanged']=True
        output=data/f'{args.mode}-{args.cohort}-{args.role}.jsonl'
        if output.exists():record.update(output=str(output),output_sha256=sha(output),output_bytes=output.stat().st_size)
    finally:save(OUT/f'{args.name}-link.json',record)
    raise SystemExit(code)
if __name__=='__main__':main()
