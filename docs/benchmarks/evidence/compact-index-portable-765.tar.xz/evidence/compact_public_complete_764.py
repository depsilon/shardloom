"""Extend public acceptance to every currently registered native input family."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import compact_index_driver_762 as d

OUT = d.OUT
ROOT = d.REPO
PYTHON = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
ACCEPTANCE = OUT / 'compact_acceptance_764.py'
sys.path[:0] = [str(ROOT / 'scripts'), str(ROOT / 'python/src')]
from run_native_streaming_input_uat import FAMILIES


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def verify():
    subprocess.run([PYTHON, '-B', str(ACCEPTANCE), 'verify'], cwd=ROOT, check=True)


verify()
base_plan_path = OUT / 'compact-index-acceptance-plan-764.json'
base_plan = json.loads(base_plan_path.read_text())
build_path = OUT / 'compact-index-acceptance-build-764.json'
build = json.loads(build_path.read_text())
assert sha(build['binary']) == build['binary_sha256']
assert not (OUT / 'compact-index-public-764.json').exists()
assert not (OUT / 'compact-index-public-764').exists()
original = base_plan['commands']['public']
original_families = original[original.index('--families') + 1:]
assert len(original_families) == 36 and set(original_families) < set(FAMILIES)
added = sorted(set(FAMILIES) - set(original_families))
assert added == ['sampling-population', 'subquery-membership', 'unary-membership']
command = original[:original.index('--families') + 1] + list(FAMILIES)
plan_path = OUT / 'compact-index-complete-public-plan-764.json'
d.save(plan_path, dict(status='predeclared_before_any_public_execution',
    original_plan=identity(base_plan_path), generator=identity(__file__), build=identity(build_path),
    command=command, families=list(FAMILIES), added_existing_families=added,
    reason='Cover all 39 currently registered families, including the three added after the historical 36-family control.',
    runtime_changed=False, original_36_family_execution_started=False, resource_limits_changed=False))
name = 'compact-index-public-764'
subprocess.run([PYTHON, '-B', str(d.GUARD), '--name', name, '--timeout', '10800', '--', *command],
               cwd=ROOT, check=True)
verify()
receipt_path = OUT / f'{name}.json'
receipt = json.loads(receipt_path.read_text())
assert receipt['status'] == 'passed' and receipt['process_group_drained']
assert receipt['log_sha256'] == sha(OUT / f'{name}.log')
summary_path = OUT / 'compact-index-public-764/summary.json'
summary = json.loads(summary_path.read_text())
assert summary['status'] == 'passed' and summary['families'] == list(FAMILIES)
assert summary['cases'] and all(row['status'] == 'passed' for row in summary['cases'])
assert len({row['name'] for row in summary['cases']}) == len(summary['cases'])
assert all(sha(path) == digest for path, digest in summary['sources'].items())
assert sha(build['binary']) == build['binary_sha256']
d.save(OUT / 'compact-index-public-binding-764.json', dict(status='passed',
    plan=identity(plan_path), build=identity(build_path), receipt=identity(receipt_path),
    log=identity(OUT / f'{name}.log'), summary=identity(summary_path),
    public_families=len(FAMILIES), public_cases=len(summary['cases']),
    sources_unchanged=True, artifacts_unchanged=True))
print(json.dumps(dict(status='passed', families=len(FAMILIES), cases=len(summary['cases']))), flush=True)
