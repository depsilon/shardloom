"""Run the current native public-surface CI test selection against frozen sources."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

import compact_index_driver_762 as d

OUT = d.OUT
PYTHON = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
NAME = 'compact-index-native-cli-tests-764'
COMMAND = ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-cli', '--lib', '--bin', 'shardloom',
    '--test', 'vortex_prepare', '--test', 'public_memory_inputs', '--test', 'public_workflow_route',
    '--test', 'resident_worker', '--features', 'release-user-surfaces', '--', '--test-threads=1']


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def verify():
    subprocess.run([PYTHON, '-B', str(OUT / 'compact_acceptance_764.py'), 'verify'], cwd=d.REPO, check=True)


verify()
d.save(OUT / 'compact-index-native-cli-plan-764.json', dict(status='predeclared',
    command=COMMAND, ci_workflow_sha256=sha(d.REPO / '.github/workflows/ci.yml'),
    source_manifest_sha256=sha(OUT / 'compact-index-acceptance-source-764.json'), driver_sha256=sha(__file__)))
subprocess.run([PYTHON, '-B', str(d.GUARD), '--name', NAME, '--timeout', '3600', '--', *COMMAND], cwd=d.REPO, check=True)
verify()
receipt = json.loads((OUT / f'{NAME}.json').read_text())
log = (OUT / f'{NAME}.log').read_text()
assert receipt['status'] == 'passed' and receipt['returncode'] == 0 and receipt['process_group_drained']
assert receipt['log_sha256'] == sha(OUT / f'{NAME}.log')
groups = [tuple(map(int, row)) for row in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)]
assert len(groups) == 6 and all(failed == 0 and ignored == 0 for _, failed, ignored in groups)
passed = sum(count for count, _, _ in groups)
assert passed > 0
assert 'test public_route_admits_native_vortex_filter_project_payload ... ok' in log
d.save(OUT / 'compact-index-native-cli-gate-764.json', dict(status='passed', passed=passed,
    failed=0, ignored=0, test_targets=len(groups), source_unchanged=True,
    receipt_sha256=sha(OUT / f'{NAME}.json'), log_sha256=sha(OUT / f'{NAME}.log'), driver_sha256=sha(__file__)))
print(json.dumps(dict(status='passed', tests=passed)), flush=True)
