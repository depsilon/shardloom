"""Bind public acceptance to the unchanged compact-index comparison candidate."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

import compact_index_driver_762 as d

ROOT = d.REPO
OUT = d.OUT
PYTHON = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
ARTIFACTS = OUT / 'artifacts/compact-index-public-764'
SOURCE = OUT / 'compact-index-acceptance-source-764.json'
BUILD = OUT / 'compact-index-acceptance-build-764.json'
PLAN = OUT / 'compact-index-acceptance-plan-764.json'
sys.path.insert(0, str(ROOT / 'scripts'))
from run_clickbench_query_uat import clickbench_harness_paths


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest(path))


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def sources():
    names = git('ls-files', '-co', '--exclude-standard', '-z').split('\0')
    selected = set(d.source_paths()) | {
        name for name in names if name and name.startswith(('python/', 'scripts/', 'benchmarks/'))
        and Path(name).suffix in ('.py', '.pyi', '.sh', '.sql', '.toml', '.json')}
    return {name: digest(ROOT / name) for name in sorted(selected) if (ROOT / name).is_file()}


def verify():
    candidate = json.loads((OUT / 'compact-index-candidate-763-source-freeze.json').read_text())
    d.verify_sources(candidate)
    source = json.loads(SOURCE.read_text())
    assert source['source_commit'] == git('rev-parse', 'HEAD')
    assert source['working_tree'] == git('status', '--porcelain')
    assert source['source_hashes'] == sources()
    assert source['generator'] == identity(__file__)
    return source


def guard(name, command, timeout=3600):
    verify()
    subprocess.run([PYTHON, str(d.GUARD), '--name', name, '--timeout', str(timeout), '--', *command],
                   cwd=ROOT, check=True)
    verify()
    receipt = json.loads((OUT / f'{name}.json').read_text())
    assert receipt['status'] == 'passed' and receipt['process_group_drained']
    assert receipt['head'] == git('rev-parse', 'HEAD')
    assert receipt['working_tree'].strip() == git('status', '--porcelain')
    assert receipt['log_sha256'] == digest(OUT / f'{name}.log')
    return dict(receipt=identity(OUT / f'{name}.json'), log=identity(OUT / f'{name}.log'))


def generation(path):
    stat = Path(path).stat()
    assert stat.st_blocks * 512 >= stat.st_size
    assert not stat.st_flags & 0x40000000
    return dict(device=stat.st_dev, inode=stat.st_ino, size_bytes=stat.st_size,
                mtime_ns=stat.st_mtime_ns, ctime_ns=stat.st_ctime_ns)


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('phase', choices=['source', 'build', 'plan', 'public', 'full43', 'modular', 'verify'])
args = parser.parse_args()
if args.phase == 'source':
    gates = OUT / 'compact-index-integration-gates-763.json'
    assert json.loads(gates.read_text())['status'] == 'passed'
    candidate = OUT / 'compact-index-candidate-763-source-freeze.json'
    d.verify_sources(json.loads(candidate.read_text()))
    d.save(SOURCE, dict(schema_version='shardloom.compact_index_public_source.v1',
        source_commit=git('rev-parse', 'HEAD'), working_tree=git('status', '--porcelain'),
        commit_alone_reproduces_sources=False, source_hashes=sources(),
        candidate_source_freeze=identity(candidate), integration_gates=identity(gates),
        generator=identity(__file__), cost_candidate_runtime_and_tests_unchanged=True))
elif args.phase == 'build':
    source = verify()
    ARTIFACTS.mkdir(parents=True, exist_ok=False)
    cli_name = 'compact-index-public-cli-build-764'
    cli = guard(cli_name, ['cargo', 'build', '--release', '--offline', '--locked',
        '-p', 'shardloom-cli', '--features', 'release-user-surfaces', '--message-format=json-render-diagnostics'])
    messages = [json.loads(line) for line in (OUT / f'{cli_name}.log').read_text().splitlines()
                if line.startswith('{')]
    artifacts = [row for row in messages if row.get('reason') == 'compiler-artifact'
                 and row.get('target', {}).get('name') == 'shardloom' and row.get('executable')]
    assert len(artifacts) == 1 and not artifacts[0]['fresh']
    executable = Path(artifacts[0]['executable'])
    metadata = json.loads(subprocess.check_output(['/Users/dylan/.cargo/bin/cargo', 'metadata',
        '--offline', '--locked', '--no-deps', '--format-version', '1'], cwd=ROOT))
    assert executable.is_relative_to(Path(metadata['target_directory']))
    binary = ARTIFACTS / 'shardloom'
    shutil.copy2(executable, binary)
    assert digest(binary) == digest(executable)
    binding_name = 'compact-index-public-binding-build-764'
    binding_receipt = guard(binding_name, [PYTHON, 'scripts/build_native_python.py',
        '--release', '--offline', '--output-dir', str(ARTIFACTS)])
    content = (OUT / f'{binding_name}.log').read_text()
    start = content.index('{\n  "schema_version": "shardloom.native_python_build.v1"')
    binding = json.loads(content[start:])
    assert binding['status'] == 'passed' and binding['installed'] is False and binding['published'] is False
    assert binding['library'] == str(ARTIFACTS / '_native.abi3.so')
    assert binding['library_sha256'] == digest(binding['library'])
    assert verify() == source
    d.save(BUILD, dict(source, binary=str(binary), binary_sha256=digest(binary),
        native_library=identity(binding['library']), native_build=binding,
        build_receipts=dict(cli=cli, binding=binding_receipt), source_manifest=identity(SOURCE),
        cli_compiler_artifact=artifacts[0], publication_attempted=False))
elif args.phase == 'plan':
    source = verify()
    build = json.loads(BUILD.read_text())
    assert build['source_hashes'] == source['source_hashes']
    assert digest(build['binary']) == build['binary_sha256']
    assert identity(build['native_library']['path']) == build['native_library']
    previous = json.loads(Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010/fresh-uat663-plan.json').read_text())
    full43 = previous['commands']['full43'].copy()
    for option, value in {'--binary': build['binary'], '--build-commit': source['source_commit'],
                          '--uat-root': str(OUT / 'compact-index-full43-764')}.items():
        full43[full43.index(option) + 1] = value
    families = ['input', 'growth', 'typed-input', 'ordering', 'ordering-pressure', 'aggregate',
        'aggregate-pressure', 'join', 'join-pressure', 'window', 'window-pressure', 'protocol',
        'preparation', 'multiple', 'multiple-pressure', 'dynamic', 'dynamic-pressure', 'replay',
        'replay-pressure', 'destinations', 'sets', 'sets-pressure', 'unary', 'unary-reference',
        'unary-composition', 'unary-fault', 'unary-pressure', 'subqueries', 'subqueries-composition',
        'subqueries-fault', 'subqueries-pressure', 'dynamic-subqueries', 'dynamic-subqueries-reference',
        'dynamic-subqueries-composition', 'dynamic-subqueries-fault', 'dynamic-subqueries-pressure']
    assert len(families) == 36
    modular = previous['commands']['modular'].copy()
    original = Path(previous['modular_runner']['path'])
    assert identity(original) == previous['modular_runner']
    local = OUT / 'compact_modular_runner_764.py'
    assert not local.exists()
    shutil.copy2(original, local)
    assert digest(original) == digest(local)
    modular[modular.index(str(original))] = str(local)
    for option, value in {'--repo': str(ROOT), '--build-manifest': str(BUILD),
                          '--prefix': 'compact-index', '--attempt': '764'}.items():
        modular[modular.index(option) + 1] = value
    public = [PYTHON, '-B', 'scripts/run_native_streaming_input_uat.py',
              '--binary', build['binary'], '--uat-root', str(OUT / 'compact-index-public-764'),
              '--operation-timeout', '600', '--compress-logs', '--families', *families]
    assert identity(previous['reference']['path']) == previous['reference']
    assert all(identity(row['path']) == row for row in previous['schema_sources'])
    input_generation = generation(previous['target'])
    assert input_generation['size_bytes'] == 15713610513
    d.save(PLAN, dict(status='predeclared', source=identity(SOURCE), build=identity(BUILD),
        commands=dict(public=public, full43=full43, modular=modular),
        expected=dict(public_families=36, queries=43, calls=43, query_result_rows=381,
                      modular_cohorts=18, native_workflows=704, pandas_oracle_workflows=704),
        input=dict(path=previous['target'], generation=input_generation,
                   sha256='06f70eb6f118d11e4a5226eb641225d708fdb4ac1b3f45942872d5ef5df4fc22'),
        reference=previous['reference'], schema_sources=previous['schema_sources'],
        query_source=identity(ROOT / 'benchmarks/clickbench/queries.sql'),
        query_harness=[identity(path) for path in clickbench_harness_paths()],
        public_runner=identity(ROOT / 'scripts/run_native_streaming_input_uat.py'),
        modular_runner=identity(local), original_modular_runner=identity(original),
        guard=identity(d.GUARD), resource_limits_changed=False, reingested=False,
        reference_kind='retained_native_regression', performance_claim=False,
        engine_clock='sum of engine_execution_seconds for one execution of Q01 through Q43'))
elif args.phase in ('public', 'full43', 'modular'):
    source = verify()
    plan = json.loads(PLAN.read_text())
    assert plan['source'] == identity(SOURCE) and plan['build'] == identity(BUILD)
    build = json.loads(BUILD.read_text())
    assert build['binary_sha256'] == digest(build['binary'])
    assert build['native_library'] == identity(build['native_library']['path'])
    if args.phase == 'full43':
        expected = plan['input']
        assert generation(expected['path']) == expected['generation']
        assert digest(expected['path']) == expected['sha256']
        assert generation(expected['path']) == expected['generation']
    receipt = guard(f'compact-index-{args.phase}-764', plan['commands'][args.phase], timeout=7200)
    if args.phase == 'full43':
        assert generation(expected['path']) == expected['generation']
        assert digest(expected['path']) == expected['sha256']
        assert generation(expected['path']) == expected['generation']
    assert verify() == source
    d.save(OUT / f'compact-index-{args.phase}-binding-764.json', dict(status='passed',
        plan=identity(PLAN), build=identity(BUILD), receipt=receipt,
        sources_unchanged=True, artifacts_unchanged=True,
        full_input_pre_and_post_hash_verified=args.phase == 'full43'))
else:
    verify()
print(json.dumps(dict(status='passed', phase=args.phase)), flush=True)
