"""Finish binding a successful CLI build using its recorded Cargo environment."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

import compact_index_driver_762 as d

OUT = d.OUT
ROOT = d.REPO
PYTHON = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
ARTIFACTS = OUT / 'artifacts/compact-index-public-764'
SOURCE = OUT / 'compact-index-acceptance-source-764.json'
BUILD = OUT / 'compact-index-acceptance-build-764.json'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def verify():
    subprocess.run([PYTHON, '-B', str(OUT / 'compact_acceptance_764.py'), 'verify'], cwd=ROOT, check=True)


def receipt(name):
    path = OUT / f'{name}.json'
    result = json.loads(path.read_text())
    assert result['status'] == 'passed' and result['process_group_drained'] and result['returncode'] == 0
    assert result['head'] == source['source_commit'] and result['working_tree'].strip() == source['working_tree']
    assert result['log_sha256'] == sha(OUT / f'{name}.log')
    return result, dict(receipt=identity(path), log=identity(OUT / f'{name}.log'))


verify()
source = json.loads(SOURCE.read_text())
assert ARTIFACTS.is_dir() and not any(ARTIFACTS.iterdir()) and not BUILD.exists()
cli_name = 'compact-index-public-cli-build-764'
cli, cli_receipt = receipt(cli_name)
messages = [json.loads(line) for line in (OUT / f'{cli_name}.log').read_text().splitlines() if line.startswith('{')]
artifacts = [row for row in messages if row.get('reason') == 'compiler-artifact'
             and row.get('target', {}).get('name') == 'shardloom' and row.get('executable')]
assert len(artifacts) == 1 and not artifacts[0]['fresh']
executable = Path(artifacts[0]['executable'])
environment = dict(os.environ, **cli['environment'])
metadata = json.loads(subprocess.check_output(['/Users/dylan/.cargo/bin/rustup', 'run', '1.99.0',
    'cargo', 'metadata', '--offline', '--locked', '--no-deps', '--format-version', '1'], cwd=ROOT, env=environment))
assert metadata['target_directory'] == cli['environment']['CARGO_TARGET_DIR']
assert executable.is_relative_to(Path(metadata['target_directory']))
binary = ARTIFACTS / 'shardloom'
shutil.copy2(executable, binary)
assert sha(binary) == sha(executable)
correction = OUT / 'compact-index-artifact-binding-correction-764.json'
d.save(correction, dict(status='passed', original_driver=identity(OUT / 'compact_acceptance_764.py'),
    original_failed_binding_log=identity(OUT / 'compact-index-acceptance-build-driver-764.log'),
    successful_cli_build=cli_receipt, binding_driver=identity(__file__),
    correction='Resolve Cargo metadata with the exact target environment already recorded and verified by the successful supervised build.',
    recorded_cargo_environment=cli['environment'], resolved_target_directory=metadata['target_directory'],
    cli_compiler_artifact=artifacts[0], binary=identity(binary),
    runtime_sources_changed=False, cli_rebuilt=False, protocol_or_measurement_changed=False))
verify()
binding_name = 'compact-index-public-binding-build-764'
subprocess.run([PYTHON, '-B', str(d.GUARD), '--name', binding_name, '--timeout', '3600', '--',
    PYTHON, '-B', 'scripts/build_native_python.py', '--release', '--offline', '--output-dir', str(ARTIFACTS)],
    cwd=ROOT, check=True)
verify()
_, binding_receipt = receipt(binding_name)
content = (OUT / f'{binding_name}.log').read_text()
binding = json.loads(content[content.index('{\n  "schema_version": "shardloom.native_python_build.v1"'):])
assert binding['status'] == 'passed' and binding['installed'] is False and binding['published'] is False
assert binding['library'] == str(ARTIFACTS / '_native.abi3.so')
assert binding['library_sha256'] == sha(binding['library'])
d.save(BUILD, dict(source, binary=str(binary), binary_sha256=sha(binary),
    native_library=identity(binding['library']), native_build=binding,
    build_receipts=dict(cli=cli_receipt, binding=binding_receipt), source_manifest=identity(SOURCE),
    cli_compiler_artifact=artifacts[0], artifact_binding_correction=identity(correction),
    publication_attempted=False))
print(json.dumps(dict(status='passed', build_manifest=str(BUILD))), flush=True)
