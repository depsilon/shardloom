"""Run required unchanged-source integration gates after both finite cohorts pass."""
import json
from pathlib import Path
import re
import subprocess
import sys
import compact_index_driver_762 as d

OUT=d.OUT
label='compact-index-candidate-763'
assert json.loads((OUT/'compact-index-decision-763.json').read_text())['finite_comparison_passed']
freeze=json.loads((OUT/f'{label}-source-freeze.json').read_text())
artifact=json.loads((OUT/f'{label}-artifact.json').read_text())
checks=[
    ('native-all',[artifact['artifact'],'--nocapture','--test-threads=1']),
    ('workspace-fmt',['cargo','fmt','--all','--','--check']),
    ('workspace-clippy',['cargo','clippy','--offline','--locked','--workspace','--all-targets','--','-D','warnings']),
    ('workspace-tests',['cargo','test','--offline','--locked','--workspace','--all-targets']),
]
receipts=[]
for suffix,command in checks:
    d.verify_sources(freeze)
    assert d.sha(artifact['artifact'])==artifact['artifact_sha256']
    name=f'compact-index-{suffix}-763'
    subprocess.run([sys.executable,str(OUT/'run_guarded_observed_757.py'),'--name',name,'--timeout','3600','--',*command],cwd=d.REPO,check=True)
    d.verify_sources(freeze)
    receipt=json.loads((OUT/f'{name}.json').read_text())
    assert receipt['status']=='passed' and receipt['process_group_drained']
    row=dict(name=name,receipt_sha256=d.sha(OUT/f'{name}.json'),log_sha256=d.sha(OUT/f'{name}.log'))
    if suffix in ['native-all','workspace-tests']:
        summaries=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (OUT/f'{name}.log').read_text())
        assert summaries and all(int(failed)==0 for _,failed,_ in summaries)
        row.update(passed=sum(int(p) for p,_,_ in summaries),ignored=sum(int(i) for _,_,i in summaries),test_targets=len(summaries))
        assert row['passed']>0
        if suffix=='native-all':
            expected=sum(line.endswith(': test') for line in (OUT/f'{label}-test-inventory.txt').read_text().splitlines())
            assert row['passed']+row['ignored']==expected
    receipts.append(row)
d.save(OUT/'compact-index-integration-gates-763.json',dict(status='passed',source_freeze_sha256=d.sha(OUT/f'{label}-source-freeze.json'),checks=receipts))
print(json.dumps(dict(status='passed',checks=receipts)))
