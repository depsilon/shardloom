"""Independent complete-value oracle and frozen compact local index decision."""
import argparse
from collections import defaultdict
import hashlib
import itertools
import json
from pathlib import Path
import statistics

OUT=Path(__file__).resolve().parent
PROTOCOL_SHA='7f7bf6830ec162999ee2f946a59894f9bd8edce9f80d0c3a747560926b2d73ad'
SHAPES=['unfiltered','all','none','band','sparse','dense','nullable']
COUNTERS={'compact_owners','compact_input_rows','maximum_local_extent','u16_take_arrays','u16_take_rows'}
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def specs(rows=16387):
    return [dict(rows=rows,shape=shape,consumer=consumer,calls=calls)
        for shape,consumer,calls in itertools.product(SHAPES,['projection','count'],[1,4])]
def identity(spec):return '-'.join(str(spec[k]) for k in ['rows','shape','consumer','calls'])
def keep(shape,row):
    if shape in ('unfiltered','all'):return True
    if shape=='none':return False
    if shape=='band':return 1031<=row<13019
    if shape=='sparse':return row%37==3
    if shape=='dense':return row%37!=3
    assert shape=='nullable'
    return None if row%17==0 else row%3!=0
def source_rows(spec):return [dict(n=None if row%11==0 else row*17-5,keep=keep(spec['shape'],row)) for row in range(spec['rows'])]
def expected_rows(spec):
    selected=[row for row in source_rows(spec) if spec['shape']=='unfiltered' or row['keep'] is True]
    return [dict(rows=len(selected))] if spec['consumer']=='count' else selected
def struct(names,dtypes):return {'Struct':[{'names':names,'dtypes':dtypes},False]}
def schema(spec,source=False):
    if source or spec['consumer']=='projection':return struct(['n','keep'],[{'Primitive':['i64',True]},{'Bool':True}])
    return struct(['rows'],[{'Primitive':['u64',False]}])

class Witnesses:
    def __init__(self,root):self.root=root;self.seen={}
    def check(self,key,value):
        data=encoded(value);expected=hashlib.sha256(data).hexdigest()
        assert key==expected,'independent expected witness differs'
        if key not in self.seen:
            path=self.root/'witnesses'/f'{key}.json';actual=path.read_bytes()
            assert actual==data and sha(path)==key
            self.seen[key]=dict(bytes=len(data),sha256=key)

def validate(record,spec,role,cohort,sample,warmup,witnesses):
    for key,value in spec.items():assert record[key]==value,(key,record.get(key),value)
    assert record['cell_id']==identity(spec)
    assert (record['role'],record['cohort'],record['sample'],record['warmup'])==(role,cohort,sample,warmup)
    witnesses.check(record['source_rows_witness'],source_rows(spec))
    witnesses.check(record['source_schema_witness'],schema(spec,True))
    expected=expected_rows(spec);dtype=schema(spec)
    witnesses.check(record['expected_rows_witness'],expected)
    witnesses.check(record['expected_schema_witness'],dtype)
    assert record['reserved_after_cleanup']==record['denied_reservations']==0
    assert 0<record['peak_reserved_bytes']<=32<<20
    assert record['completed_executions']==spec['calls']
    assert record['prepared_source_opens']==record['provider_background_workers']==0
    assert record['admitted_max_parallelism']==1 and len(record['operations'])==spec['calls']
    assert record['preparation_ns']>0 and record['destruction_ns']>0
    complete=record['preparation_ns']+record['destruction_ns']
    for ordinal,operation in enumerate(record['operations']):
        assert operation['call']==ordinal and operation['completed_executions']==ordinal+1
        assert operation['rows']==len(expected)
        witnesses.check(operation['actual_rows_witness'],expected)
        witnesses.check(operation['actual_schema_witness'],dtype)
        for clock in ['engine_execution_ns','result_serialization_ns','execution_and_consumption_ns','output_release_ns']:
            assert type(operation[clock]) is int and operation[clock]>=0
        assert operation['execution_and_consumption_ns']>=operation['engine_execution_ns']+operation['result_serialization_ns']
        complete+=operation['execution_and_consumption_ns']+operation['output_release_ns']
        certificate=operation['native_io_certificate']
        assert certificate['certified'] is True and certificate['fallback_attempted'] is False
        assert 'NativeIoCertificate' in certificate['complete_debug'] and 'fallback_attempted: false' in certificate['complete_debug']
    assert record['complete_workflow_ns']==complete
    counters=record['selection'];assert set(counters)==COUNTERS
    assert all(type(value) is int and value>=0 for value in counters.values())
    if role=='baseline' or spec['rows']==0:assert not any(counters.values())
    else:
        assert counters['compact_owners']>0,('missing compact activation',spec)
        assert counters['compact_input_rows']==spec['rows']*spec['calls']*(1 if spec['shape']=='unfiltered' else 2)
        assert 0<counters['maximum_local_extent']<=65536
        noncontiguous=spec['shape'] in ['sparse','dense','nullable']
        if noncontiguous:
            assert counters['u16_take_arrays']>0 and counters['u16_take_rows']>0
        else:assert counters['u16_take_arrays']==counters['u16_take_rows']==0

def read(root,mode,role,cohort,witnesses):
    path=root/f'{mode}-{cohort}-{role}.jsonl'
    records=[json.loads(line) for line in path.read_text().splitlines()]
    cells=[cell for rows in ([0,32,16387] if mode=='preflight' else [16387]) for cell in specs(rows)]
    if cohort=='B':cells.reverse()
    expected=[(specs()[0],0,True)] if mode=='measure' else []
    expected.extend((cell,sample,False) for cell in cells for sample in range(3 if mode=='measure' else 1))
    assert len(records)==len(expected)==(85 if mode=='measure' else 84)
    for record,(spec,sample,warmup) in zip(records,expected):validate(record,spec,role,cohort,sample,warmup,witnesses)
    operations=sum(len(record['operations']) for record in records)
    assert operations==(211 if mode=='measure' else 210)
    return records,dict(path=str(path),sha256=sha(path),workflows=len(records),operations=operations,role=role,cohort=cohort)

def engine(record):return sum(operation['engine_execution_ns'] for operation in record['operations'])
def score(base,candidate):
    result={}
    for name,metric in [('engine',engine),('complete',lambda r:r['complete_workflow_ns']),('memory',lambda r:r['peak_reserved_bytes'])]:
        before=statistics.median(metric(r) for r in base);after=statistics.median(metric(r) for r in candidate)
        assert before>0
        result[name]=dict(baseline=before,candidate=after,improvement_fraction=(before-after)/before)
        if name=='memory':result[name].update(target_passed=before-after>=32768 and after*100<=before*98,regression=after-before>8192)
        else:result[name]['regression']=after*100>before*105 and after-before>1_000_000
    return result

def analyze(cohorts):
    scores={};failures=[];targets=[s for s in specs() if s['shape'] in ['unfiltered','all']];assert len(targets)==8
    for cohort,roles in cohorts.items():
        groups=defaultdict(lambda:defaultdict(list))
        for role,records in roles.items():
            for record in records:
                if not record['warmup']:groups[record['cell_id']][role].append(record)
        assert set(groups)=={identity(s) for s in specs()}
        scores[cohort]={}
        for cell,roles in groups.items():
            assert len(roles['baseline'])==len(roles['candidate'])==3
            result=score(roles['baseline'],roles['candidate']);scores[cohort][cell]=result
            for metric in ['engine','complete','memory']:
                if result[metric]['regression']:failures.append(dict(cohort=cohort,cell_id=cell,failed_gate=metric+'_regression',values=result[metric]))
        for target in targets:
            result=scores[cohort][identity(target)]['memory']
            if not result['target_passed']:failures.append(dict(cohort=cohort,cell_id=identity(target),failed_gate='memory_target',values=result))
    assert set(cohorts)=={'A','B'}
    return dict(outcome='finite_candidate_passes_for_integration_acceptance' if not failures else 'finite_candidate_rejected',
        finite_comparison_passed=not failures,production_accepted=False,failed_gates=failures,scores=scores,
        broader_owner_and_conditional_substep_remain_open=True)

def self_tests():
    def row(e,c,m):return dict(operations=[dict(engine_execution_ns=e)],complete_workflow_ns=c,peak_reserved_bytes=m)
    base=[row(20_000_000,30_000_000,1_000_000)]*3
    assert score(base,[row(20_000_000,30_000_000,967232)]*3)['memory']['target_passed']
    assert not score(base,[row(20_000_000,30_000_000,967233)]*3)['memory']['target_passed']
    assert not score(base,[row(21_000_000,30_000_000,1_008_192)]*3)['engine']['regression']
    assert score(base,[row(21_000_001,30_000_000,1_008_193)]*3)['engine']['regression']
    assert not score(base,[row(20_000_000,30_000_000,1_008_192)]*3)['memory']['regression']
    assert score(base,[row(20_000_000,30_000_000,1_008_193)]*3)['memory']['regression']

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path)
    parser.add_argument('--preflight',action='store_true')
    parser.add_argument('--role',choices=['baseline','candidate'])
    parser.add_argument('--output',type=Path)
    parser.add_argument('--self-test-only',action='store_true')
    args=parser.parse_args();self_tests();assert sha(OUT/'compact-local-indices-protocol-762.json')==PROTOCOL_SHA
    if args.self_test_only:print('compact index gate boundaries passed');return
    assert args.root and args.output
    witnesses=Witnesses(args.root);receipts=[]
    if args.preflight:
        for role in ([args.role] if args.role else ['baseline','candidate']):
            _,receipt=read(args.root,'preflight',role,'preflight',witnesses);receipts.append(receipt)
        result=dict(outcome='preflight_semantics_width_activation_and_resources_validated',roles=[r['role'] for r in receipts])
    else:
        cohorts={}
        for cohort in ['A','B']:
            cohorts[cohort]={}
            for role in ['baseline','candidate']:
                cohorts[cohort][role],receipt=read(args.root,'measure',role,cohort,witnesses);receipts.append(receipt)
        result=analyze(cohorts)
    result.update(receipts=receipts,verified_witnesses=list(witnesses.seen.values()),analyzer_sha256=sha(__file__),protocol_sha256=PROTOCOL_SHA)
    with args.output.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps(dict(outcome=result['outcome'],output=str(args.output),sha256=sha(args.output))))
if __name__=='__main__':main()
