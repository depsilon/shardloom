"""Build and validate the original runtime before implementing compact indices."""
import json
from pathlib import Path
import subprocess
import sys
OUT=Path(__file__).resolve().parent
REPO=Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
DRIVER=OUT/'compact_index_driver_762.py'
LABEL='compact-index-baseline-762'
def run(command):subprocess.run(command,cwd=REPO,check=True)
lint=json.loads((OUT/'compact-index-baseline-clippy-fixed-762.json').read_text())
assert lint['status']=='passed' and lint['process_group_drained']
run([sys.executable,str(DRIVER),'freeze','--label',LABEL])
run([sys.executable,str(OUT/'run_guarded_observed_757.py'),'--name','compact-index-baseline-build-762','--timeout','1800','--',
    '/Users/dylan/.cargo/bin/rustup','run','1.99.0','cargo','test','--offline','--locked','--release','-p','shardloom-vortex',
    '--features','release-user-surfaces','--lib','--no-run','--message-format=json'])
run([sys.executable,str(DRIVER),'bind','--label',LABEL,'--build','compact-index-baseline-build-762'])
run([sys.executable,str(DRIVER),'run','--label',LABEL,'--name','compact-index-baseline-preflight-762','--mode','preflight','--role','baseline'])
run([sys.executable,str(OUT/'analyze_compact_indices_762.py'),'--root',str(OUT/'compact-local-indices-762-a1'),'--preflight',
    '--role','baseline','--output',str(OUT/'compact-index-baseline-preflight-analysis-762.json')])
run([sys.executable,str(DRIVER),'verify','--label',LABEL])
