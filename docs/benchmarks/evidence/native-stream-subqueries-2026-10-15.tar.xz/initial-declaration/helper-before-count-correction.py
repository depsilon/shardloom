"""Freeze candidate case names and expectations without invoking native execution."""
import ast
import json
from pathlib import Path
import sys

from freeze_native_release_298 import ROOT, OUT, sha, save, sources

sys.path[:0] = [str(ROOT / 'python/src'), str(ROOT / 'scripts')]
from run_native_streaming_input_uat import FAMILIES
from local_uat_storage import GIB, MIB, check_budgets, require_local_path

DEST = OUT / 'stream-subquery-candidate-declarations-508'
SOURCE = OUT / 'native-release-source-streamsubquery508.json'
SELECTED = ['subqueries', 'subqueries-composition', 'subqueries-fault', 'subqueries-pressure']


class Declarations:
    def __init__(self, root):
        self.output, self.logs, self.names = root / 'outputs', root / 'logs', []
        self.output.mkdir()
        self.logs.mkdir()

    def case(self, name, _call):
        assert name not in self.names
        self.names.append(name)

    def json(self, path, value):
        save(path, value)


def main():
    frozen = json.loads(SOURCE.read_text())
    assert frozen['source_sha256'] == sources()
    require_local_path(DEST, Path.home(), sys.platform)
    assert not DEST.exists()
    check_budgets(OUT, DEST, OUT / 'logs', min_free_bytes=12 * GIB,
                  reserve_bytes=128 * MIB, max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    DEST.mkdir()
    families = []
    for name in SELECTED:
        root = DEST / name
        root.mkdir()
        harness = Declarations(root)
        FAMILIES[name](harness)
        families.append(dict(family=name, cases=len(harness.names), names=harness.names))
    assert [row['cases'] for row in families] == [722, 228, 164, 7]
    test = ROOT / 'python/tests/test_native_subquery_binding.py'
    names = [node.name for node in ast.walk(ast.parse(test.read_text()))
             if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')]
    assert len(names) == 5
    report = dict(status='declared_before_candidate_execution', native_engine_executions=0,
        source_manifest=dict(path=str(SOURCE), sha256=sha(SOURCE)), helper_sha256=sha(__file__),
        contract_sha256=sha(ROOT / 'docs/architecture/native-stream-subqueries-2026-10-15.md'),
        families=families, total_new_public_cases=sum(row['cases'] for row in families),
        new_direct_methods=names, planned_direct_methods=96, new_direct_subcases=126,
        baseline=dict(path=str(OUT / 'stream-subquery-baseline-507/summary.json'),
                      sha256=sha(OUT / 'stream-subquery-baseline-507/summary.json')),
        whole_process_memory_ceiling=False, performance_claim=False)
    assert sources() == frozen['source_sha256']
    save(DEST / 'declarations.json', report)
    print(json.dumps({key: report[key] for key in ('status', 'native_engine_executions', 'total_new_public_cases', 'planned_direct_methods')}))


if __name__ == '__main__':
    main()
