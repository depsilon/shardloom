"""Independently check every literal local dependency edge and file identity."""
import ast
import json
from pathlib import Path
import sys

from freeze_native_release_298 import ROOT, OUT, save
from stream_subquery_acceptance_sources_510 import SOURCE, identity


def main():
    path = OUT / 'stream-subquery-helper-dependencies-510.json'
    value = json.loads(path.read_text())
    assert not value['ambiguities'] and not value['parse_errors']
    files = value['files']
    assert len(files) == 65 and len({row['path'] for row in files}) == 65
    roots = [Path(root) for root in value['resolution_roots']]
    recorded = set()
    for source, line, kind, module, names, status, targets in value['local_import_edges']:
        assert status == 'resolved_local' and targets
        recorded.add((source, line, kind, module, tuple(names), tuple(targets)))
    observed, packages = set(), []
    by_path = {Path(row['path']): number for number, row in enumerate(files)}
    for number, row in enumerate(files):
        file = Path(row['path'])
        assert identity(file) == {key: row[key] for key in ('path', 'bytes', 'sha256')}
        for node in ast.walk(ast.parse(file.read_text())):
            if isinstance(node, ast.Import):
                imports = [('import', item.name, [item.asname or item.name]) for item in node.names]
            elif isinstance(node, ast.ImportFrom):
                assert not node.level, (file, node.lineno)
                imports = [('from', node.module, [item.name for item in node.names])]
            else:
                continue
            for kind, module, names in imports:
                candidates = [root / (module.replace('.', '/') + '.py') for root in roots]
                candidates.extend(root / module.replace('.', '/') / '__init__.py' for root in roots)
                targets = sorted(by_path[candidate] for candidate in candidates if candidate.is_file())
                if targets:
                    observed.add((number, node.lineno, kind, module, tuple(names), tuple(targets)))
                elif module.split('.')[0] == 'shardloom':
                    candidate = ROOT / 'python/src' / (module.replace('.', '/') + '.py')
                    if not candidate.exists():
                        candidate = ROOT / 'python/src' / module.replace('.', '/') / '__init__.py'
                    assert candidate.is_file(), module
                    packages.append(dict(source=str(file), line=node.lineno, module=module, target=identity(candidate)))
                else:
                    assert module.split('.')[0] in sys.stdlib_module_names or module.split('.')[0] in ('__future__', 'pyarrow'), module
    assert observed == recorded, {'missing': list(observed-recorded), 'extra': list(recorded-observed)}
    assert len(packages) == len(value['unresolved_local_references']) == 62
    expected = {(by_path[Path(row['source'])], row['line'], row['module']) for row in packages}
    assert expected == {(row[0], row[1], row[2]) for row in value['unresolved_local_references']}
    source_map = json.loads(SOURCE.read_text())['source_sha256']
    package_files = []
    for name, digest in source_map.items():
        if name.startswith('python/src/'):
            row = identity(ROOT / name)
            assert row['sha256'] == digest
            package_files.append(row)
    assert package_files
    for _, target, _ in value['explicit_supervisor_dependencies']:
        assert Path(files[target]['path']).name in ('release_validation_guard.py', 'bounded_build_process_resume_20260912.py')
    assert len(value['dynamic_references']) == 4
    output = OUT / 'stream-subquery-helper-dependencies-primary-510.json'
    assert not output.exists()
    save(output, dict(status='passed_source_dependency_inventory', inventory=identity(path), helper=identity(__file__),
        files=len(files), local_edges=len(observed), package_import_edges=packages, package_files=package_files,
        source=identity(SOURCE), dynamic_reference_dispositions=[
            'The explicit supervisor path is present as a separately hashed source file.',
            'The three remaining run_guarded subprocess commands invoke Rust metadata and Git revision/status, not hidden Python helpers.'],
        remaining_boundary='Installed PyArrow and Python/Rust/system tools are versioned by execution receipts; this inventory does not vendor those runtimes.'))
    print(json.dumps(dict(status='passed_source_dependency_inventory', files=len(files), edges=len(observed),
                         package_edges=len(packages), package_files=len(package_files))))


if __name__ == '__main__':
    main()
