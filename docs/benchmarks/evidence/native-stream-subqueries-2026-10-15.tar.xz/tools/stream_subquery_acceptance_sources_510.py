"""Verify the exact test-only change against unchanged accepted runtime sources."""
import json
from pathlib import Path

from freeze_native_release_298 import ROOT, OUT, sources
from run_stream_subquery_acceptance_509 import SOURCE, MANIFEST, PROTOCOL, identity
from record_stream_subquery_test_correction_510 import NAME, OLD, NEW

ACCEPTED_SOURCE = OUT / 'stream-subquery-verification-source-510.json'


def unchanged():
    original = json.loads(SOURCE.read_text())
    accepted = json.loads(ACCEPTED_SOURCE.read_text())
    assert accepted['status'] == 'frozen_for_verification'
    assert accepted['build_source'] == identity(SOURCE) and accepted['artifacts'] == identity(MANIFEST)
    assert sources() == accepted['source_sha256']
    assert set(accepted['source_sha256']) == set(original['source_sha256'])
    assert [name for name in accepted['source_sha256']
            if accepted['source_sha256'][name] != original['source_sha256'][name]] == [NAME]
    assert accepted['production_code_identical'] and accepted['exact_cfg_test_assertion_replacement']
    for key in ('before', 'original', 'after', 'diff', 'helper'):
        assert identity(accepted[key]['path']) == accepted[key]
    before = Path(accepted['original']['path']).read_text()
    after = (ROOT / NAME).read_text()
    assert before.count(OLD) == 1 and after == before.replace(OLD, NEW)
    marker = '#[cfg(test)]\n#[allow(clippy::too_many_lines)]\nmod tests {'
    assert marker in before and before.index(OLD) > before.index(marker)
    assert before.split(marker)[0] == after.split(marker)[0]
    assert identity(ROOT / NAME)['sha256'] == accepted['after']['sha256']
    return accepted


def load():
    unchanged()
    original = json.loads(SOURCE.read_text())
    manifest = json.loads(MANIFEST.read_text())
    assert manifest['status'] == 'passed' and manifest['source_sha256'] == original['source_sha256']
    for key in ('cli', 'binding'):
        assert identity(manifest[key]['path']) == {field: manifest[key][field] for field in ('path', 'bytes', 'sha256')}
    return manifest
