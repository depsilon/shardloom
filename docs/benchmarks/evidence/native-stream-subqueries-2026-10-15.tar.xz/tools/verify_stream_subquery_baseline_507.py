"""Freeze merged subquery refusals and resident controls before runtime edits."""
import json
from pathlib import Path
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, sha, save, sources

sys.path.insert(0, str(ROOT / 'python/src'))
from run_native_streaming_input_uat import Harness
import shardloom as sl
from shardloom.errors import ShardLoomCommandError

HEAD = 'ff9aa27338ca9f1ff5581f5a57603400f5aec926'
DEST = OUT / 'stream-subquery-baseline-507'
SOURCE = OUT / 'stream-unary-final-source-497.json'
ARTIFACTS = OUT / 'native-release-artifacts-streamunary494.json'
PROVENANCE = OUT / 'stream-unary-hosted-498/merged-sources-505.json'
CONTRACT = ROOT / 'docs/architecture/native-stream-subqueries-2026-10-15.md'
SCHEMA = {'n': 'int64', 's': 'utf8'}
LEFT = [{'n': 1, 's': 'a'}, {'n': 2, 's': 'b'}, {'n': 3, 's': 'c'}, {'n': None, 's': 'z'}]
RIGHT = [{'n': 2, 's': 'b'}, {'n': None, 's': 'q'}, {'n': 2, 's': 'b'}]
EXPECTED = {
    'in': [LEFT[1]],
    'not-in': [],
    'row-in': [LEFT[1]],
    'exists': LEFT,
    'not-exists': [],
    'any': [LEFT[2]],
    'all': [],
    'scalar-one': [dict(row, answer=2) for row in LEFT],
    'scalar-zero': [dict(row, answer=None) for row in LEFT],
    'parameterized-scalar': [dict(row, answer=value) for row, value in zip(LEFT, [None, 2, 2, None])],
    'guarded-scalar': [dict(row, answer=7) for row in LEFT],
    'shared-scalar': [dict(row, answer=1) for row in LEFT],
    'existing-self-in': LEFT[:3],
    'existing-left-set': LEFT[:3] + LEFT,
    'existing-right-set': LEFT + LEFT[:3],
}


def declare(left, right, kind):
    if kind == 'in':
        return left.filter(sl.col('n').isin_source(right, 'n'))
    if kind == 'not-in':
        return left.filter(sl.col('n').not_in_source(right, 'n'))
    if kind == 'row-in':
        return left.filter(sl.row_in_source(['n', 's'], right, ['n', 's']))
    if kind == 'exists':
        return left.filter(sl.exists_source(right))
    if kind == 'not-exists':
        return left.filter(sl.not_exists_source(right))
    if kind == 'any':
        return left.filter(sl.col('n').any_source('>', right, 'n'))
    if kind == 'all':
        return left.filter(sl.col('n').all_source('<', right, 'n'))
    if kind == 'scalar-one':
        return left.with_column('answer', sl.scalar_subquery(right.select('n').limit(1)))
    if kind == 'scalar-zero':
        return left.with_column('answer', sl.scalar_subquery(right.filter('FALSE').select('n')))
    if kind == 'parameterized-scalar':
        inner = right.filter(sl.col('n') <= sl.outer('n')).agg(answer='MAX(n)')
        return left.with_column('answer', sl.scalar_subquery(inner))
    if kind == 'guarded-scalar':
        inner = sl.scalar_subquery(right.select('1/0 AS bad'))
        return left.with_column('answer', sl.case_when(sl.col('n') < 0, inner, 7))
    if kind == 'shared-scalar':
        return left.with_column('answer', sl.scalar_subquery(left.select('n').limit(1)))
    selected = left.filter(sl.col('n').isin_source(left, 'n'))
    if kind == 'existing-self-in':
        return selected
    if kind == 'existing-left-set':
        return selected.union_all(left)
    assert kind == 'existing-right-set'
    return left.union_all(selected)


def main():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD
    working_tree = subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True)
    assert all(line[3:] == 'AGENTS.md' or line[3:].startswith(('docs/', 'website-src/src/content/'))
               for line in working_tree.splitlines()), working_tree
    accepted = json.loads(SOURCE.read_text())['source_sha256']
    assert sources() == accepted
    artifacts = json.loads(ARTIFACTS.read_text())
    assert artifacts['status'] == 'passed'
    for key in ('cli', 'binding'):
        assert sha(artifacts[key]['path']) == artifacts[key]['sha256']
    provenance = json.loads(PROVENANCE.read_text())
    assert provenance['status'] == 'passed' and provenance['revisions']['merged'] == HEAD
    assert provenance['accepted']['sha256'] == sha(SOURCE)
    assert {name: row['sha256'] for name, row in provenance['immutable_source'].items()} == accepted
    assert not DEST.exists()
    harness = Harness(Path(artifacts['cli']['path']), DEST, 60)
    harness.guard()
    harness.logs.mkdir(parents=True)
    harness.output.mkdir()
    harness.json(harness.logs / 'predeclared-expectations.json', dict(
        rows_left=LEFT, rows_right=RIGHT, schema=SCHEMA, expected=EXPECTED,
        cases=30, streaming_refusals=15, resident_controls=15,
        head=HEAD, source_manifest_sha256=sha(SOURCE), artifacts_sha256=sha(ARTIFACTS),
        contract_sha256=sha(CONTRACT), provenance_sha256=sha(PROVENANCE),
        helper_sha256=sha(__file__), working_tree=working_tree,
        scope='Baseline admission and resident exact-value controls; no candidate execution or performance claim.'))
    status = 'failed'
    try:
        for streaming in (True, False):
            for kind, expected in EXPECTED.items():
                name = f'subquery-baseline-{kind}-streaming-{streaming}'
                def case(kind=kind, name=name, expected=expected, streaming=streaming):
                    events = []
                    def frame(label, rows):
                        def produce():
                            events.append([label, 'opened'])
                            try:
                                for batch in ([], rows[:1], rows[1:3], [], rows[3:]):
                                    yield batch
                                events.append([label, 'ended'])
                            finally:
                                events.append([label, 'closed'])
                        return harness.context.from_batches(produce, schema=SCHEMA, streaming=streaming)
                    left = frame('left', LEFT)
                    right = frame('right', RIGHT)
                    query = declare(left, right, kind)
                    assert events == []
                    harness.json(harness.logs / (name + '-declaration.json'), dict(
                        sql=query._relation_statement(), expected=expected, streaming=streaming))
                    try:
                        result = query.collect(check=True, memory_bytes=32 << 20, max_parallelism=1)
                    except ShardLoomCommandError as error:
                        assert streaming, error.envelope.raw
                        harness.envelope(name, error.envelope, success=False)
                        raw = json.dumps(error.envelope.raw)
                        assert 'SL-NATIVE-BATCH' in raw and 'subquery' in raw
                        assert events == [], events
                        return dict(outcome='static_streaming_refusal', producer_events=events)
                    assert not streaming
                    harness.envelope(name, result.envelope)
                    harness.values(name, result.result_rows, expected)
                    labels = ['left'] if kind.startswith('existing-') or kind == 'shared-scalar' else ['left', 'right']
                    for label in labels:
                        assert [event for source, event in events if source == label] == ['opened', 'ended', 'closed'], events
                    assert {source for source, _ in events} == set(labels)
                    return dict(outcome='resident_control_passed', producer_events=events,
                        schema=[(column, dtype.name, dtype.nullable) for column, dtype in result.result_schema])
                harness.case(name, case)
        assert len(harness.results) == 30 and all(row['status'] == 'passed' for row in harness.results)
        assert sources() == accepted and sha(artifacts['cli']['path']) == artifacts['cli']['sha256']
        status = 'passed'
    finally:
        harness.client.close()
        save(DEST / 'summary.json', dict(status=status, cases=harness.results, expected=EXPECTED,
            rows_left=LEFT, rows_right=RIGHT, binary=artifacts['cli'], head=HEAD,
            artifact_manifest=str(ARTIFACTS), artifact_manifest_sha256=sha(ARTIFACTS),
            accepted_source_manifest=str(SOURCE), accepted_source_manifest_sha256=sha(SOURCE),
            contract_sha256=sha(CONTRACT), provenance_sha256=sha(PROVENANCE),
            helper_sha256=sha(__file__), runtime_source_changed=False, performance_claim=False))
    print(json.dumps(dict(status=status, cases=30, streaming_refusals=15, resident_controls=15)))


if __name__ == '__main__':
    main()
