"""Preserve initial candidate sources and failures before targeted corrections."""
import json
from pathlib import Path
import shutil

from freeze_native_release_298 import ROOT, OUT, sha, save, sources

DEST = OUT / 'stream-subquery-corrections-509'
FROZEN = OUT / 'native-release-source-streamsubquery508.json'
FILES = [
    'python/tests/test_native_subquery_binding.py',
    'scripts/native_streaming_subquery_cases.py',
    'scripts/native_streaming_subquery_composition_cases.py',
    'scripts/native_streaming_subquery_fault_cases.py',
    'scripts/native_streaming_subquery_pressure_cases.py',
    'scripts/run_native_streaming_input_uat.py',
    'shardloom-cli/src/sql_syntax.rs',
]


def identity(path):
    path = Path(path)
    return dict(path=str(path), sha256=sha(path), bytes=path.stat().st_size)


def main():
    frozen = json.loads(FROZEN.read_text())
    assert sources() == frozen['source_sha256'] and not DEST.exists()
    receipts = []
    for name in ('stream-subquery-direct-new-508', 'stream-subquery-focused-508'):
        path = OUT / (name + '.json')
        data = json.loads(path.read_text())
        assert data['status'] == 'failed' and data['process_group_drained']
        assert data['direct_child_reaped'] and data['returncode'] == 1
        log = path.with_suffix('.log')
        assert sha(log) == data['log_sha256']
        receipts.append(dict(receipt=identity(path), log=identity(log)))
    DEST.mkdir()
    original = []
    for name in FILES:
        source, target = ROOT / name, DEST / 'before' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        assert sha(target) == sha(source) == frozen['source_sha256'][name]
        original.append(dict(source=name, retained=identity(target)))
    direct = OUT / 'stream-subquery-direct-new-tests-508.json'
    public = OUT / 'stream-subquery-focused-508/summary.json'
    assert json.loads(direct.read_text())['status'] == 'failed'
    data = json.loads(public.read_text())
    assert data['status'] == 'failed'
    assert sum(row['status'] == 'passed' for row in data['cases']) == 104
    assert data['cases'][-1]['name'] == 'subquery-exists-mixed-11-dataframe-collect'
    save(DEST / 'initial-failures.json', dict(status='preserved_before_corrections',
        build_source=identity(FROZEN), artifacts=identity(OUT / 'native-release-artifacts-streamsubquery508.json'),
        original_sources=original, receipts=receipts, direct=identity(direct), public=identity(public),
        diagnoses=[
            dict(kind='engine_parser', detail='Projected EXISTS is missing from is_explicit_predicate_projection_shape; generic scalar parsing then treats EXISTS as a function. Public with_column and direct SQL both reproduce.'),
            dict(kind='fixture_alias', detail='The direct and independent SQL divide-by-zero inner projections lack the required output alias; the DataFrame variant already supplies AS bad.'),
            dict(kind='fixture_writer', detail='Direct NativePlan.write_many takes write_vortex/write_jsonl operation identifiers, as existing native fanout tests demonstrate.'),
            dict(kind='fixture_input_contract', detail='Arrow intake rejects non-finite floats through reject_columnar_non_finite_floats even for unselected inner input. Preserve refusal and test finite multirow lazy evaluation separately.'),
        ], performance_claim=False))
    print(json.dumps(dict(status='preserved', sources=len(original), public_passed_before_failure=104)))


if __name__ == '__main__':
    main()
