"""Bind the documentation validator change to unchanged accepted native sources."""
import ast
import json
from pathlib import Path
import subprocess
import sys

from freeze_native_release_298 import ROOT, OUT, save, sources, sha
from stream_subquery_acceptance_sources_510 import identity, unchanged, load, ACCEPTED_SOURCE, MANIFEST

AUDIT = OUT / 'stream-subquery-packet-audit-510.json'
SNAPSHOT = OUT / 'stream-subquery-documentation-source-511'
FINAL = OUT / 'stream-subquery-final-source-511.json'
VALIDATOR = 'scripts/check_user_surface_reference.py'
INDEX = ROOT / 'docs/benchmarks/evidence/native-stream-subqueries-2026-10-15.json'
BEFORE = '        ("supported_plan", ["Scan", "Filter", "Project", "Sort", "Limit", "Aggregate", "Join", "Window", "PivotRows", "Set", "Unary"]),\n'
AFTER = (
    '        ("supported_plan", ["Scan", "Filter", "Project", "Sort", "Limit", "Aggregate", "Join", "Window", "PivotRows", "Set", "Unary", "Subquery", "CorrelatedSubquery"]),\n'
    '        ("subquery_reference", "docs/architecture/native-stream-subqueries-2026-10-15.md"),\n'
    '        ("subquery_acceptance_reference", "docs/benchmarks/native-stream-subqueries-2026-10-15.md"),\n'
    '        ("subquery_kinds", ["in", "exists", "quantified", "scalar"]),\n'
    '        ("subquery_inner_scope", "statically_declared_sources_and_schema;indexed_and_parameterized_correlation"),\n'
    '        ("subquery_selected_branch_semantics_preserved", True),\n'
    '        ("subquery_nested_demand_requires_original_owner_release", True),\n'
    '        ("subquery_shared_source_replay_completed_before_query", True),\n'
    '        ("subquery_unused_producers", "raw_validation_without_skipped_expression_or_cardinality_evaluation"),\n'
    '        ("subquery_state_spill", False),\n'
    '        ("opaque_deferred_subquery_streaming", False),\n'
)


def prepare():
    accepted = unchanged()
    load()
    audit = json.loads(AUDIT.read_text())
    assert audit['status'] == 'passed' and audit['public']['cases'] == 3724
    assert audit['direct_methods'] == 96 and audit['full43']['calls'] == 43
    assert audit['index'] == identity(INDEX)
    assert not SNAPSHOT.exists() and not FINAL.exists()
    SNAPSHOT.mkdir()
    for path, name in ((ROOT / VALIDATOR, 'validator-before.py'), (INDEX, 'original-index.json')):
        with (SNAPSHOT / name).open('xb') as stream:
            stream.write(path.read_bytes())
    assert sha(SNAPSHOT / 'validator-before.py') == accepted['source_sha256'][VALIDATOR]
    save(SNAPSHOT / 'before.json', dict(status='frozen_before_documentation_validator_change',
        accepted_source=identity(ACCEPTED_SOURCE), audit=identity(AUDIT), index=identity(INDEX),
        validator=identity(SNAPSHOT / 'validator-before.py'), helper=identity(__file__)))
    print(json.dumps(dict(status='frozen_before_documentation_validator_change')))


def record():
    before = json.loads((SNAPSHOT / 'before.json').read_text())
    assert before['accepted_source'] == identity(ACCEPTED_SOURCE) and before['audit'] == identity(AUDIT)
    accepted = json.loads(ACCEPTED_SOURCE.read_text())
    current = sources()
    original = accepted['source_sha256']
    assert current.keys() == original.keys() and len(current) == 2291
    assert [name for name in current if current[name] != original[name]] == [VALIDATOR]
    old = SNAPSHOT / 'validator-before.py'
    assert identity(old) == before['validator'] and sha(old) == original[VALIDATOR]
    assert old.read_text().count(BEFORE) == 1
    assert old.read_text().replace(BEFORE, AFTER) == (ROOT / VALIDATOR).read_text()
    ast.parse((ROOT / VALIDATOR).read_text())
    retained = SNAPSHOT / 'validator-after.py'
    with retained.open('xb') as stream:
        stream.write((ROOT / VALIDATOR).read_bytes())
    artifacts = json.loads(MANIFEST.read_text())
    assert accepted['artifacts'] == identity(MANIFEST)
    for kind in ('cli', 'binding'):
        item = artifacts[kind]
        assert identity(item['path']) == {key: item[key] for key in ('path', 'bytes', 'sha256')}
    command = [sys.executable, '-B', 'scripts/check_user_surface_reference.py', '--repo-root', str(ROOT)]
    result = subprocess.run(command, cwd=ROOT, capture_output=True, check=True)
    assert not result.stderr and json.loads(result.stdout)['status'] == 'passed'
    check = SNAPSHOT / 'user-surface-check.json'
    with check.open('xb') as stream:
        stream.write(result.stdout)
    assert sources() == current and not FINAL.exists()
    save(FINAL, dict(status='accepted_documentation_validator_only_transition',
        head=artifacts['head'], source_sha256=current, source_files=len(current),
        accepted_runtime_source=identity(ACCEPTED_SOURCE), audit=identity(AUDIT),
        before=identity(SNAPSHOT / 'before.json'), original_validator=identity(old),
        final_validator=identity(retained), changed_paths=[VALIDATOR], build_artifacts=identity(MANIFEST),
        user_surface_check=identity(check), command=command, helper=identity(__file__),
        compiled_runtime_changed=False, public_python_runtime_changed=False,
        previous_native_direct_public_and_full43_results_reused=True,
        core_packet=[identity(INDEX.with_name('native-stream-subqueries-2026-10-15' + suffix))
                     for suffix in ('.json', '.tar.xz', '.manifest.json.xz')],
        rationale='Extend only deterministic documentation validation with finite subquery kinds, static source roles, selected evaluation, completion and resident-state boundaries.'))
    print(json.dumps(dict(status='passed', changed_paths=[VALIDATOR], runtime_changed=False)))


if __name__ == '__main__':
    prepare() if sys.argv[1:] == ['prepare'] else record()
