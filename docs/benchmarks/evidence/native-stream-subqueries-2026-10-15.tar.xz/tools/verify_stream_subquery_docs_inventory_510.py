"""Primary provenance verification of the bounded documentation inventory."""
import hashlib
import json
from pathlib import Path
import subprocess

from freeze_native_release_298 import ROOT, OUT, save, sha


def main():
    path = OUT / 'stream-subquery-docs-inventory-510.json'
    inventory = json.loads(path.read_text())
    assert inventory['head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    entries = inventory['entries'] + inventory['related_validator_matches'] + [inventory['non_matching_validator_observation']]
    for row in entries:
        source = ROOT / row['repo_path']
        raw = source.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == row['sha256'], row['repo_path']
        lines = raw.decode().splitlines()
        assert '\n'.join(lines[row['line_start']-1:row['line_end']]) == row['excerpt'], row['repo_path']
    search = ['rg', '-n', '-i',
        'native-stream-unary|streaming unary|unary composition|native-stream-subquer|stream(ing)?[-_ ]subquer|subquer.{0,80}(unsupported|refus|remain|shapes)|unsupported.{0,80}subquer|sets and other unsupported|stateful/correlated',
        'website-src/src/content/docs', 'python/README.md', 'docs/architecture/phased-execution-plan.md',
        'python/tests/test_release_scripts.py']
    search.extend(str(file.relative_to(ROOT)) for file in sorted((ROOT / 'scripts').glob('validate*')) if file.is_file())
    result = subprocess.run(search, cwd=ROOT, text=True, capture_output=True, check=True)
    output = OUT / 'stream-subquery-docs-inventory-primary-510.json'
    assert not output.exists()
    save(output, dict(status='passed_source_provenance_only', inventory_path=str(path), inventory_sha256=sha(path),
        verified_entries=len(entries), active_entries=len(inventory['entries']),
        source_files=len({row['repo_path'] for row in entries}), search_command=search,
        current_matches=result.stdout.splitlines(), helper_sha256=sha(__file__),
        boundaries=['Literal evidence inventory is not semantic approval.',
                    'Existing general SQL limits and historical accepted packets are not removed.']))
    print(json.dumps(dict(status='passed_source_provenance_only', entries=len(entries),
                         matches=len(result.stdout.splitlines()))))


if __name__ == '__main__':
    main()
