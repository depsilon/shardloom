"""Package complete finite-subquery evidence after every local acceptance gate.

Keep all successful and failed observations, exact build/test source transitions,
and independently reopened result logs. Exclude bulk datasets and executables.
"""
from __future__ import annotations

import hashlib
import json
import lzma
from pathlib import Path
import re
import subprocess
import sys
import tarfile

from freeze_native_release_298 import ROOT, OUT, save, sha
from stream_subquery_acceptance_sources_510 import (
    SOURCE, MANIFEST, ACCEPTED_SOURCE, PROTOCOL, identity, load, unchanged,
)
from package_selection_acceptance_409 import Members, verify, sha_stream, excluded_identity

sys.path.insert(0, str(ROOT / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path
from native_workflow_protocol import strict_json

BASE = 'ff9aa27338ca9f1ff5581f5a57603400f5aec926'
PREFIX = 'native-stream-subqueries-2026-10-15'
LOCAL = OUT / 'stream-subquery-packet-510'
DEST = ROOT / 'docs/benchmarks/evidence'
PUBLIC = OUT / 'stream-subquery-public-509'
FOCUSED = OUT / 'stream-subquery-focused-509'
CHECKS = OUT / 'stream-subquery-checks-510.json'
FULL_REVIEW = OUT / 'stream-subquery-full43-review-510.json'
MAX_RAW_BYTES = 256 * MIB


def read(path):
    return strict_json(Path(path).read_text())


def completed(path):
    receipt = read(path)
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0, path
    assert receipt['process_group_drained'] and receipt['direct_child_reaped'], path
    assert not receipt['timed_out'] and not receipt['group_absence_unproved_at_cleanup'], path
    assert receipt['head'] == BASE, path
    assert sha(Path(path).with_suffix('.log')) == receipt['log_sha256'], path
    return receipt


def main():
    assert not LOCAL.exists()
    assert all(not (DEST / (PREFIX + suffix)).exists() for suffix in ('.json', '.tar.xz', '.manifest.json.xz'))
    accepted, artifacts, original = unchanged(), load(), read(SOURCE)
    assert original['head'] == BASE and len(original['source_sha256']) == len(accepted['source_sha256']) == 2291
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
    protocol = read(PROTOCOL)
    assert protocol['expected_direct_tests'] == 96 and protocol['new_direct_subcases'] == 127
    assert len(protocol['new_direct_methods']) == 5 and len(protocol['native_required_tests']) == 15
    declaration_path = OUT / 'stream-subquery-candidate-declarations-509/declarations.json'
    declaration = read(declaration_path)
    assert declaration['status'] == 'declared_before_candidate_execution' and declaration['native_engine_executions'] == 0
    assert [row['cases'] for row in declaration['families']] == [722, 230, 164, 7]
    contract = ROOT / 'docs/architecture/native-stream-subqueries-2026-10-15.md'
    assert sha(contract) == declaration['contract_sha256']
    checks = read(CHECKS)
    assert checks['status'] == 'passed' and checks['source_identity_preserved']
    assert checks['source'] == identity(ACCEPTED_SOURCE) and checks['build_source'] == identity(SOURCE)
    expected_stages = ['fmt', 'workspace-clippy', 'workspace-tests', 'read-clippy', 'release-clippy', 'native-tests']
    assert [row['stage'] for row in checks['completed']] == expected_stages
    final_receipts = []
    for row in checks['completed']:
        for key in ('receipt', 'log'):
            assert identity(row[key]['path']) == row[key]
        path = Path(row['receipt']['path'])
        completed(path)
        final_receipts.append(path)
    counts = {row['stage']: row['tests'] for row in checks['completed'] if 'tests' in row}
    assert counts['workspace-tests']['passed'] == 3220 and counts['workspace-tests']['ignored'] == 0
    assert counts['native-tests']['passed'] == 4264 and counts['native-tests']['ignored'] == 29
    prior_checks = read(OUT / 'stream-unary-checks-494.json')
    prior_native = next(row['tests'] for row in prior_checks['completed'] if row['stage'] == 'native-tests')
    assert sorted(counts['native-tests']['ignored_declarations']) == sorted(prior_native['ignored_declarations'])
    native_log = Path(next(row['log']['path'] for row in checks['completed'] if row['stage'] == 'native-tests')).read_text()
    for name in protocol['native_required_tests']:
        assert re.search(r'^test .*::' + re.escape(name) + r' \.\.\. ok$', native_log, re.M), name
    direct = read(OUT / 'stream-subquery-direct-tests-509.json')
    assert direct['status'] == 'passed' and direct['tests'] == 96
    assert direct['failures'] == direct['errors'] == direct['skipped'] == 0
    assert direct['source'] == identity(SOURCE) and direct['artifact_manifest'] == identity(MANIFEST)
    harness = read(OUT / 'stream-subquery-harness-tests-510.json')
    assert harness['status'] == 'passed' and harness['tests'] == 5 and harness['skipped'] == 0
    for kind, cases in [('focused', 1123), ('public', 3724)]:
        value = read(OUT / f'stream-subquery-{kind}-acceptance-509.json')
        assert value['status'] == 'passed' and value['cases'] == cases
        assert value['manifest'] == identity(MANIFEST) and value['source'] == identity(SOURCE)
        assert identity(value['summary']['path']) == value['summary']
    public = read(PUBLIC / 'summary.json')
    assert public['status'] == 'passed' and public['families'] == protocol['expected_public_families']
    assert [row['name'] for row in public['cases']] == protocol['expected_public_names']
    assert len(public['cases']) == 3724 and all(row['status'] == 'passed' for row in public['cases'])
    inspection = read(OUT / 'stream-subquery-public-inspection-510.json')
    assert inspection['status'] == 'passed' and inspection['cases'] == 3724 and inspection['families'] == 31
    assert inspection['summary'] == identity(PUBLIC / 'summary.json')
    assert inspection['complete_case_log_records_equal'] and inspection['frozen_sources_and_binary_unchanged']
    full = read(FULL_REVIEW)
    assert full['status'] == 'passed' and full['calls'] == full['queries'] == 43 and full['repeats'] == 1
    assert full['complete_rows'] == 381 and full['accepted_source'] == identity(ACCEPTED_SOURCE)
    assert full['all_values_schemas_and_clocks_reopened'] and full['resources_no_fallback_native_certificates']
    assert full['native_children_absent'] and full['original_input_and_sources_unchanged']
    assert full['no_new_ingest'] and not full['performance_claim_allowed']
    admission = read(full['admission']['path'])
    assert admission['source_resident_before_read'] and admission['no_new_ingest']
    for row in full['companions'] + full['envelopes'] + [full['summary'], full['timing_csv'], full['receipt'], full['admission']]:
        assert identity(row['path']) == row
    baseline_path = OUT / 'stream-subquery-baseline-507/summary.json'
    baseline = read(baseline_path)
    assert baseline['status'] == 'passed' and len(baseline['cases']) == 30
    assert all(row['status'] == 'passed' for row in baseline['cases'])
    assert sum(row['outcome'] == 'static_streaming_refusal' for row in baseline['cases']) == 15
    assert sum(row['outcome'] == 'resident_control_passed' for row in baseline['cases']) == 15
    label_correction = read(OUT / 'stream-subquery-contract-label-correction-511.json')
    assert label_correction['status'] == 'passed_exact_feature_label_correction'
    assert baseline['contract_sha256'] == label_correction['original']['sha256']
    assert sha(contract) == label_correction['corrected']['sha256']
    for key in ('original', 'corrected', 'baseline', 'candidate_declaration', 'helper'):
        assert identity(label_correction[key]['path']) == label_correction[key]
    for name in ['native-stream-subquery-baseline-507', 'stream-subquery-direct-new-509',
                 'stream-subquery-direct-509', 'stream-subquery-focused-509', 'stream-subquery-public-509',
                 'stream-subquery-harness-510', 'stream-subquery-full43-510',
                 'native-final-cli-release-build-streamsubquery509', 'native-final-python-release-build-streamsubquery509']:
        path = OUT / (name + '.json')
        completed(path)
        final_receipts.append(path)

    members, exclusions = Members(), []
    def add(path, name, role, digest=None, root=None):
        path = Path(path)
        root = root or (ROOT if path.is_relative_to(ROOT) else OUT if path.is_relative_to(OUT) else path.parent)
        members.add(path, name, root.name, root, role, digest)

    dirty = subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT, text=True).splitlines()
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=ROOT, text=True).splitlines()
    overlay = sorted(set(dirty + untracked) & set(accepted['source_sha256']))
    assert overlay and 'shardloom-cli/src/sql_syntax.rs' in overlay
    for name in overlay:
        add(ROOT / name, 'source-overlay/' + name, 'accepted selected source overlay', accepted['source_sha256'][name])
    add(SOURCE, 'manifests/' + SOURCE.name, 'compiled runtime source manifest')
    add(MANIFEST, 'manifests/' + MANIFEST.name, 'frozen CLI and binding build identities')
    add(ACCEPTED_SOURCE, 'manifests/' + ACCEPTED_SOURCE.name, 'accepted test-only source overlay')
    add(contract, 'preimplementation/' + contract.name, 'original implementation contract', declaration['contract_sha256'])
    for key in ('original', 'corrected'):
        row = label_correction[key]
        add(row['path'], 'preimplementation/' + Path(row['path']).name,
            'exact original baseline contract or feature-label-only correction', row['sha256'])
    for suffix in ('.json', '.log'):
        path = OUT / ('finite-query-evidence-package-511' + suffix)
        add(path, 'retained-failures/' + path.name, 'packaging preflight label mismatch; no archive or runtime run created')
    for path in sorted(OUT.iterdir()):
        if path.is_file() and ('subquery' in path.name or 'subqueries' in path.name) and path.suffix in ('.json', '.log', '.py', '.diff'):
            add(path, 'receipts/' + path.name if path.suffix != '.py' else 'tools/' + path.name,
                'retained subquery evidence or helper; execution established only by its receipt')
    for folder, prefix in [
            ('stream-subquery-baseline-507', 'baseline'),
            ('stream-subquery-candidate-declarations-508', 'initial-declaration'),
            ('stream-subquery-candidate-declarations-508b', 'first-candidate-declaration'),
            ('stream-subquery-candidate-declarations-509', 'predeclared-reference'),
            ('stream-subquery-corrections-509', 'parser-fixture-corrections'),
            ('stream-subquery-test-correction-510', 'test-only-correction'),
            ('stream-subquery-source-inventory-494', 'source-inventory'),
            ('stream-subquery-focused-508', 'failed-focused'),
            ('stream-subquery-focused-509', 'focused-public'),
            ('stream-subquery-public-509', 'public')]:
        members.tree(OUT / folder, prefix, prefix, 'complete compact evidence tree', exclusions, omit_outputs=True)
    for key in ('original_public', 'original_direct'):
        value = protocol[key]
        assert identity(value['path']) == value
        add(value['path'], 'prior-identities/' + Path(value['path']).name, 'prior case or method identity', value['sha256'])
    add(OUT / 'stream-unary-checks-494.json', 'prior-identities/stream-unary-checks-494.json', 'unchanged manual and platform ignore declarations')
    add(OUT / 'stream-unary-candidate-declarations-493b/logs/unary-predeclared-values.json',
        'predeclared-reference/logs/unary-predeclared-values.json', 'inherited complete unary reference values')
    for key in ('artifact_manifest', 'accepted_source_manifest'):
        path = Path(baseline[key])
        add(path, 'prior-identities/' + path.name, 'baseline build/source provenance', baseline[key + '_sha256'])
    for artifact in [artifacts['cli'], artifacts['binding'], baseline['binary']]:
        assert identity(artifact['path']) == {key: artifact[key] for key in ('path', 'bytes', 'sha256')}
        exclusions.append(excluded_identity(Path(artifact['path']), 'executables/' + Path(artifact['path']).parent.name + '/' + Path(artifact['path']).name,
                                            'frozen executable excluded; build proof retained'))
        for key in ('build_receipt', 'build_log'):
            add(artifact[key], 'build-evidence/' + Path(artifact[key]).name, 'successful original build receipt or complete log')
    input_identity = admission['input']
    exclusions.append(dict(archive_path='resident-input/' + Path(input_identity['path']).name,
        original_absolute_path=input_identity['path'], byte_count=input_identity['bytes'], sha256=input_identity['sha256'],
        reason='large resident input excluded; complete before/after hash proof retained'))
    for item in [admission['reference'], admission['queries'], *admission['harness'], *admission['schema_sources']]:
        group = 'full43-baseline-schemas' if item in admission['schema_sources'] else 'full43-inputs'
        add(item['path'], group + '/' + Path(item['path']).name, 'predeclared Full43 reference, schema or harness input', item['sha256'])
    members.tree(Path(full['summary']['path']).parent, 'full43', 'full43', 'complete one-pass Full43 evidence', exclusions)

    dependencies = read(OUT / 'stream-subquery-helper-dependencies-510.json')
    dependency_acceptance = read(OUT / 'stream-subquery-helper-dependencies-primary-510.json')
    assert dependency_acceptance['status'] == 'passed_source_dependency_inventory'
    assert dependency_acceptance['inventory'] == identity(OUT / 'stream-subquery-helper-dependencies-510.json')
    for item in dependency_acceptance['package_files']:
        path = Path(item['path'])
        add(path, 'python-package/' + path.relative_to(ROOT / 'python/src').as_posix(),
            'complete source Python package bound to runtime acceptance', item['sha256'])
    for item in dependencies['files']:
        path = Path(item['path'])
        if path.is_relative_to(ROOT):
            relative = 'repository/' + path.relative_to(ROOT).as_posix()
        elif path.is_relative_to(OUT):
            relative = 'local/' + path.relative_to(OUT).as_posix()
        else:
            relative = 'external/' + path.parent.name + '/' + path.name
        add(path, 'dependencies/' + relative, 'transitive local helper source', item['sha256'])
    add(OUT / 'verify_stream_unary_packet_497.py', 'tools/verify_stream_unary_packet_497.py', 'reused independent archive verification primitives')

    ordered = sorted(members.paths.values(), key=lambda item: item.name)
    raw_size = sum(item.size for item in ordered)
    assert raw_size <= MAX_RAW_BYTES, (raw_size, MAX_RAW_BYTES)
    require_local_path(LOCAL, Path.home(), sys.platform)
    storage = check_budgets(OUT, LOCAL, OUT / 'logs', min_free_bytes=12 * GIB,
        reserve_bytes=raw_size + 64 * MIB, max_workspace_bytes=100 * GIB, max_log_bytes=192 * MIB)
    LOCAL.mkdir()
    archive_path = LOCAL / (PREFIX + '.tar.xz')
    with archive_path.open('xb') as target:
        with tarfile.open(fileobj=target, mode='w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
            for item in ordered:
                verify(item.path, item.digest, item.size)
                info = tarfile.TarInfo(item.name)
                info.size, info.mode, info.mtime = item.size, 0o644, 0
                with item.path.open('rb') as stream:
                    archive.addfile(info, stream)
    seen = set()
    with tarfile.open(archive_path, mode='r|xz') as archive:
        for entry in archive:
            assert entry.isfile() and entry.name in members.names and entry.name not in seen
            item = members.paths[members.names[entry.name]]
            with archive.extractfile(entry) as stream:
                assert sha_stream(stream) == (item.size, item.digest), entry.name
            seen.add(entry.name)
    assert seen == set(members.names)
    for item in ordered:
        verify(item.path, item.digest, item.size)
    assert unchanged() == accepted and load() == artifacts
    acceptance = dict(workspace_tests=3220, workspace_ignored=0, native_tests=4264, native_ignored=29,
        new_native_subquery_tests=14, new_parser_tests=1, direct_methods=96, direct_skips=0,
        new_direct_methods=5, new_direct_subcases=127, harness_methods=5, focused_public_cases=1123,
        public_cases=3724, public_families=31, full43_queries=43, full43_calls=43, full43_repeats=1,
        full43_complete_rows=381, baseline_controls=30, baseline_streaming_refusals=15, baseline_resident_controls=15)
    limits = ['Finite statically bound streaming subqueries only; opaque dynamic-inner source declarations remain pending.',
              'Subquery membership/index state remains resident; source/result replay spill does not spill that state.',
              'One complete regression pass does not establish a speedup, process RSS ceiling, package release or all-platform readiness.',
              'Direct tests use the source Python package with a frozen native extension; installed-wheel and hosted integration remain separate gates.']
    manifest = dict(status='passed_local_evidence_packaged', base_commit=BASE, source_files=2291,
        source_manifest=identity(SOURCE), accepted_verification_source=identity(ACCEPTED_SOURCE), artifact_manifest=identity(MANIFEST),
        source_overlay=overlay, members=[dict(path=str(item.path), archive_path=item.name, bytes=item.size,
            sha256=item.digest, roles=item.roles) for item in ordered], member_count=len(ordered), raw_bytes=raw_size,
        all_members_reopened=True, storage=storage, exclusions=exclusions, acceptance=acceptance,
        final_receipts=[identity(path) for path in final_receipts], public_inspection=identity(OUT / 'stream-subquery-public-inspection-510.json'),
        full43_review=identity(FULL_REVIEW), original_contract=identity(contract), source_identity_preserved=True,
        production_code_identical_after_test_correction=True, publication_attempted=False, limitations=limits)
    raw = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    packed = lzma.compress(raw, preset=6)
    assert lzma.decompress(packed) == raw
    manifest_path = LOCAL / (PREFIX + '.manifest.json.xz')
    with manifest_path.open('xb') as stream:
        stream.write(packed)
    index = dict(schema_version='shardloom.native_stream_subqueries_evidence.v1',
        status='packaged_local_pending_acceptance_decision', base_commit=BASE, source_files=2291,
        member_count=len(seen), raw_bytes=raw_size, all_members_reopened=True, acceptance=acceptance,
        source_manifest=manifest['source_manifest'], accepted_verification_source=manifest['accepted_verification_source'],
        artifact_manifest=manifest['artifact_manifest'], source_overlay=overlay,
        archive=dict(file=archive_path.name, bytes=archive_path.stat().st_size, sha256=sha(archive_path)),
        manifest=dict(file=manifest_path.name, bytes=len(packed), sha256=sha(manifest_path),
                      raw_sha256=hashlib.sha256(raw).hexdigest()), limitations=limits,
        publication_attempted=False, hosted_integration_complete=False)
    for path in (archive_path, manifest_path):
        target = DEST / path.name
        with target.open('xb') as stream:
            stream.write(path.read_bytes())
        assert sha(target) == sha(path)
    save(DEST / (PREFIX + '.json'), index)
    save(LOCAL / 'verification.json', dict(status='all_members_reopened', member_count=len(seen),
        archive=identity(archive_path), manifest=identity(manifest_path), index=identity(DEST / (PREFIX + '.json')),
        helper=identity(__file__)))
    print(json.dumps(dict(status=index['status'], members=len(seen), raw_bytes=raw_size)))


if __name__ == '__main__':
    main()
