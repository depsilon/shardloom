"""Frozen direct, public and required native acceptance for finite subqueries."""
import ast
import json
import os
from pathlib import Path
import re
import sys
import unittest

from freeze_native_release_298 import ROOT, OUT, sha, save, sources
from run_query_timing_runtime_461 import guarded, PYTHON_DEPS
from run_stream_destination_review_checks_479 import CHECKS

SOURCE = OUT / 'native-release-source-streamsubquery508.json'
MANIFEST = OUT / 'native-release-artifacts-streamsubquery508.json'
DECLARATIONS = OUT / 'stream-subquery-candidate-declarations-508b/declarations.json'
PROTOCOL = OUT / 'stream-subquery-acceptance-protocol-508.json'
PYTHON = OUT / 'selected-view-python-468/bin/python'
NEW_FAMILIES = ['subqueries', 'subqueries-composition', 'subqueries-fault', 'subqueries-pressure']


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def unchanged():
    frozen = json.loads(SOURCE.read_text())
    assert sources() == frozen['source_sha256'], 'accepted source changed'
    return frozen


def load():
    frozen = unchanged()
    manifest = json.loads(MANIFEST.read_text())
    assert manifest['status'] == 'passed' and manifest['source_sha256'] == frozen['source_sha256']
    for key in ('cli', 'binding'):
        assert identity(manifest[key]['path']) == {name: manifest[key][name] for name in ('path', 'bytes', 'sha256')}
    return manifest


def declare():
    unchanged()
    prior_path = OUT / 'stream-unary-public-496/summary.json'
    prior = json.loads(prior_path.read_text())
    declared = json.loads(DECLARATIONS.read_text())
    assert prior['status'] == 'passed' and len(prior['cases']) == 2601 and len(prior['families']) == 27
    assert all(row['status'] == 'passed' for row in prior['cases'])
    assert declared['status'] == 'declared_before_candidate_execution' and declared['native_engine_executions'] == 0
    names = [row['name'] for row in prior['cases']]
    replacements = {name: name.replace('deny-subquery', 'self-subquery') for name in
                    ('deny-subquery-left-set', 'deny-subquery-right-set', 'deny-subquery')}
    assert set(replacements).issubset(names)
    names = [replacements.get(name, name) for name in names]
    added = [name for family in declared['families'] for name in family['names']]
    names.extend(added)
    assert len(added) == 1123 and len(names) == len(set(names)) == 3724
    prior_direct = OUT / 'stream-unary-direct-tests-495.json'
    old = json.loads(prior_direct.read_text())
    assert old['status'] == 'passed' and old['tests'] == 91
    required = []
    files = sorted((ROOT / 'shardloom-vortex/src').glob('local_primitive_relational_batch_subquery*_tests.rs'))
    files.append(ROOT / 'shardloom-vortex/src/local_primitive_relational_batch_dynamic_tests.rs')
    for path in files:
        required.extend(re.findall(r'fn\s+(streaming_subqueries\w+)\(', path.read_text()))
    assert len(required) == len(set(required)) == 14
    save(PROTOCOL, dict(status='predeclared', native_engine_executions=0,
        source=identity(SOURCE), declarations=identity(DECLARATIONS), helper=identity(__file__),
        guard=identity(OUT / 'run_guarded.py'), original_public=identity(prior_path),
        original_direct=identity(prior_direct), expected_public_names=names,
        expected_public_families=prior['families'] + NEW_FAMILIES,
        original_refusal_replacements=replacements, new_public_names=added,
        expected_direct_tests=96, new_direct_methods=declared['new_direct_methods'],
        new_direct_subcases=126, native_required_tests=required, required_checks=CHECKS,
        no_vendor_changes=True, whole_process_memory_ceiling=False,
        performance_claim=False, full43_pending=True, installed_wheel_proof=False))
    print(json.dumps(dict(status='predeclared', public_cases=len(names), direct_methods=96, native_required_tests=14)))


def tests(kind):
    manifest = load()
    assert Path(sys.executable) == PYTHON
    sys.path[:0] = [str(ROOT / 'python/src'), str(PYTHON_DEPS)]
    import pyarrow
    import shardloom
    assert Path(shardloom.__file__).resolve() == ROOT / 'python/src/shardloom/__init__.py'
    os.environ.update(SHARDLOOM_NATIVE_TEST_LIBRARY=manifest['binding']['path'],
                      SHARDLOOM_REQUIRE_NATIVE_PYTHON='1', SHARDLOOM_BIN=manifest['cli']['path'])
    new = kind == 'direct-new'
    pattern = 'test_native_subquery_binding.py' if new else 'test_native*binding.py'
    suite = unittest.defaultTestLoader.discover(str(ROOT / 'python/tests'), pattern=pattern)

    def identifiers(value):
        return [name for child in value for name in identifiers(child)] if isinstance(value, unittest.TestSuite) else [value.id()]

    names = identifiers(suite)
    expected = 5 if new else 96
    assert len(names) == len(set(names)) == expected
    protocol = json.loads(PROTOCOL.read_text())
    new_names = {'test_native_subquery_binding.NativeSubqueryBindingTests.' + name for name in protocol['new_direct_methods']}
    assert new_names.issubset(names)
    if not new:
        old = json.loads(Path(protocol['original_direct']['path']).read_text())
        assert set(old['test_names']).issubset(names) and set(names) - set(old['test_names']) == new_names
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    passed = result.wasSuccessful() and result.testsRun == expected and not result.skipped
    save(OUT / f'stream-subquery-{kind}-tests-508.json', dict(status='passed' if passed else 'failed',
        tests=result.testsRun, failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
        failure_details=[dict(test=str(test), traceback=detail) for test, detail in result.failures],
        error_details=[dict(test=str(test), traceback=detail) for test, detail in result.errors],
        test_names=names, artifact_manifest=identity(MANIFEST), source=identity(SOURCE),
        protocol=identity(PROTOCOL), helper=identity(__file__), interpreter=sys.executable,
        python_version=sys.version, pyarrow_version=pyarrow.__version__, pyarrow_file=pyarrow.__file__,
        package_source=shardloom.__file__, mode='direct_source_package_with_explicit_frozen_native_library',
        installed_wheel_proof=False))
    assert load() == manifest and passed


def public(kind):
    manifest = load()
    protocol = json.loads(PROTOCOL.read_text())
    root = OUT / f'stream-subquery-{kind}-508'
    assert not root.exists()
    families = NEW_FAMILIES if kind == 'focused' else protocol['expected_public_families']
    guarded(f'stream-subquery-{kind}-508', 7200,
        [sys.executable, '-B', ROOT / 'scripts/run_native_streaming_input_uat.py', '--binary', manifest['cli']['path'],
         '--uat-root', root, '--operation-timeout', '600', '--compress-logs', '--families', *families])
    summary = json.loads((root / 'summary.json').read_text())
    expected = protocol['new_public_names'] if kind == 'focused' else protocol['expected_public_names']
    assert summary['status'] == 'passed' and summary['families'] == families and summary['compress_logs']
    assert [row['name'] for row in summary['cases']] == expected
    assert all(row['status'] == 'passed' for row in summary['cases'])
    assert load() == manifest
    save(OUT / f'stream-subquery-{kind}-acceptance-508.json', dict(status='passed', cases=len(expected),
        families=families, manifest=identity(MANIFEST), source=identity(SOURCE), protocol=identity(PROTOCOL),
        summary=identity(root / 'summary.json'), source_identity_preserved=True, full43_pending=True))


def checks():
    frozen = unchanged()
    protocol = json.loads(PROTOCOL.read_text())
    prior = json.loads((OUT / 'stream-unary-checks-494.json').read_text())
    assert prior['status'] == 'passed' and prior['source_identity_preserved']
    ignored = next(row for row in prior['completed'] if row['stage'] == 'native-tests')['tests']['ignored_declarations']
    expected_ignored = sorted(tuple(row) for row in ignored)
    assert len(expected_ignored) == 29
    records, failure = [], None
    try:
        for label, timeout, command in CHECKS:
            assert unchanged() == frozen
            name = f'stream-subquery-{label}-508'
            print(json.dumps(dict(stage=label, status='starting')), flush=True)
            guarded(name, timeout, command)
            path = OUT / (name + '.json')
            value, log = json.loads(path.read_text()), path.with_suffix('.log')
            assert value['status'] == 'passed' and value['returncode'] == 0
            assert value['process_group_drained'] and value['direct_child_reaped']
            assert not value['timed_out'] and not value['group_absence_unproved_at_cleanup']
            assert sha(log) == value['log_sha256'] and value['head'] == frozen['head']
            record = dict(stage=label, receipt=identity(path), log=identity(log))
            if label.endswith('tests'):
                raw = log.read_text()
                groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', raw)
                assert groups and all(int(row[1]) == int(row[3]) == int(row[4]) == 0 for row in groups)
                observed = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', raw, re.M)
                assert sum(int(row[2]) for row in groups) == len(observed)
                if label == 'native-tests':
                    assert sorted(observed) == expected_ignored
                    for name in protocol['native_required_tests']:
                        assert re.search(r'^test .*::' + name + r' \.\.\. ok$', raw, re.M), name
                else:
                    assert not observed
                record['tests'] = dict(passed=sum(int(row[0]) for row in groups), failed=0,
                                       ignored=len(observed), groups=len(groups), ignored_declarations=observed)
            records.append(record)
            print(json.dumps(dict(stage=label, status='passed', tests=record.get('tests', {}).get('passed'))), flush=True)
        assert unchanged() == frozen
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        save(OUT / 'stream-subquery-checks-508.json', dict(status='passed' if failure is None else 'failed',
             failure=failure, completed=records, source=identity(SOURCE), protocol=identity(PROTOCOL),
             source_identity_preserved=sources() == frozen['source_sha256'], helper=identity(__file__)))


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'declare':
        declare()
    elif action.startswith('direct'):
        tests(action)
    elif action in ('focused', 'public'):
        public(action)
    else:
        assert action == 'checks'
        checks()
