"""Required serial checks after a single cfg(test) assertion-format correction."""
import json
from pathlib import Path
import re

from freeze_native_release_298 import ROOT, OUT, save, sha, sources
from run_query_timing_runtime_461 import guarded
from run_stream_destination_review_checks_479 import CHECKS
from stream_subquery_acceptance_sources_510 import SOURCE, MANIFEST, PROTOCOL, ACCEPTED_SOURCE, identity, unchanged

def checks():
    frozen = unchanged()
    protocol = json.loads(PROTOCOL.read_text())
    prior = json.loads((OUT / 'stream-unary-checks-494.json').read_text())
    assert prior['status'] == 'passed' and prior['source_identity_preserved']
    ignored = next(row for row in prior['completed'] if row['stage'] == 'native-tests')['tests']['ignored_declarations']
    expected_ignored = sorted(tuple(row) for row in ignored)
    assert len(expected_ignored) == 29
    records, failure = [], None
    try:
        for label, timeout, command in CHECKS:
            assert unchanged() == frozen
            name = f'stream-subquery-{label}-510'
            print(json.dumps(dict(stage=label, status='starting')), flush=True)
            guarded(name, timeout, command)
            path = OUT / (name + '.json')
            value, log = json.loads(path.read_text()), path.with_suffix('.log')
            assert value['status'] == 'passed' and value['returncode'] == 0
            assert value['process_group_drained'] and value['direct_child_reaped']
            assert not value['timed_out'] and not value['group_absence_unproved_at_cleanup']
            assert sha(log) == value['log_sha256'] and value['head'] == frozen['head']
            record = dict(stage=label, receipt=identity(path), log=identity(log))
            if label.endswith('tests'):
                raw = log.read_text()
                groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', raw)
                assert groups and all(int(row[1]) == int(row[3]) == int(row[4]) == 0 for row in groups)
                observed = re.findall(r'^test (.+) \.\.\. ignored, (.+)$', raw, re.M)
                assert sum(int(row[2]) for row in groups) == len(observed)
                if label == 'native-tests':
                    assert sorted(observed) == expected_ignored
                    for name in protocol['native_required_tests']:
                        assert re.search(r'^test .*::' + name + r' \.\.\. ok$', raw, re.M), name
                else:
                    assert not observed
                record['tests'] = dict(passed=sum(int(row[0]) for row in groups), failed=0,
                                       ignored=len(observed), groups=len(groups), ignored_declarations=observed)
            records.append(record)
            print(json.dumps(dict(stage=label, status='passed', tests=record.get('tests', {}).get('passed'))), flush=True)
        assert unchanged() == frozen
    except BaseException as error:
        failure = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        save(OUT / 'stream-subquery-checks-510.json', dict(status='passed' if failure is None else 'failed',
             failure=failure, completed=records, source=identity(ACCEPTED_SOURCE), build_source=identity(SOURCE), protocol=identity(PROTOCOL),
             source_identity_preserved=sources() == frozen['source_sha256'], helper=identity(__file__)))


if __name__ == '__main__':
    checks()
