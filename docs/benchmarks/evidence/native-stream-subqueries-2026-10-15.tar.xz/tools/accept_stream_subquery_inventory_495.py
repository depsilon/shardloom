"""Verify a bounded source inventory without turning it into runtime proof."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo')
OUT = Path('/Users/dylan/LocalData/shardloom/native-python-surface-20261010')
REPORT = OUT / 'stream-subquery-source-inventory-494/stream-subquery-source-inventory-494.json'
HELPER = REPORT.parent / 'build_inventory.py'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    assert sha(REPORT) == '4b1c73a689d05299a2b293cd36b682a4244455c5dd451e97530f44d4e9031377'
    assert sha(HELPER) == 'bfdb4075191326e4b0c5db25f158601937c4ac2b6392900464f1cd1742112dd3'
    report = json.loads(REPORT.read_text())
    assert report['repository_root'] == str(ROOT)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == report['repository_head']
    entries = report['evidence']
    assert report['evidence_count'] == len(entries) == 31
    assert len({row['id'] for row in entries}) == 31
    verified = []
    for row in entries:
        path = ROOT / row['path']
        assert path.is_relative_to(ROOT) and sha(path) == row['sha256'], row['id']
        lines = path.read_text().splitlines()
        start, end = row['line_start'], row['line_end']
        assert 0 < start <= end <= len(lines)
        expected = '\n'.join(f'{number}: {lines[number - 1]}' for number in range(start, end + 1))
        assert expected == row['excerpt'], row['id']
        verified.append(dict(id=row['id'], path=row['path'], sha256=row['sha256'],
                             line_start=start, line_end=end))
    result = dict(status='passed', scope='source identities and all literal excerpt ranges',
                  report=dict(path=str(REPORT), sha256=sha(REPORT)),
                  worker_helper=dict(path=str(HELPER), sha256=sha(HELPER)),
                  primary_helper=dict(path=__file__, sha256=sha(__file__)),
                  entries=verified, unique_sources=len({row['path'] for row in entries}),
                  engine_executions=0, new_admission_decision=False,
                  runtime_proof=False, semantic_intake_pending=True,
                  limitations=report['search_coverage'])
    destination = OUT / 'stream-subquery-source-inventory-primary-495.json'
    assert not destination.exists()
    destination.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(status='passed', entries=len(entries), unique_sources=result['unique_sources'],
                          engine_executions=0, report=str(destination))))


if __name__ == '__main__':
    main()
