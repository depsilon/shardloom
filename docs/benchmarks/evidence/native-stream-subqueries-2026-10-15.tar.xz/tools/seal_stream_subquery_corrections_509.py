"""Bind the parser correction and fixture repairs to retained failing evidence."""
import difflib
import json
from pathlib import Path
import shutil

from freeze_native_release_298 import ROOT, OUT, sha, sources, save
from record_stream_subquery_initial_failures_509 import DEST, identity


def main():
    original = json.loads((OUT / 'native-release-source-streamsubquery508.json').read_text())
    frozen = OUT / 'native-release-source-streamsubquery509.json'
    current = json.loads(frozen.read_text())
    assert sources() == current['source_sha256']
    changes = sorted(name for name, digest in original['source_sha256'].items()
                     if current['source_sha256'].get(name) != digest)
    assert changes == ['python/tests/test_native_subquery_binding.py',
                       'scripts/native_streaming_subquery_cases.py',
                       'shardloom-cli/src/sql_syntax.rs']
    assert set(current['source_sha256']) == set(original['source_sha256'])
    transitions = []
    for name in changes:
        before, after = DEST / 'before' / name, DEST / 'after' / name
        assert sha(before) == original['source_sha256'][name]
        after.parent.mkdir(parents=True, exist_ok=True)
        assert not after.exists()
        shutil.copy2(ROOT / name, after)
        assert sha(after) == current['source_sha256'][name]
        diff = after.with_suffix(after.suffix + '.diff')
        with diff.open('x') as stream:
            stream.write(''.join(difflib.unified_diff(before.read_text().splitlines(True),
                         after.read_text().splitlines(True), fromfile='before/' + name, tofile='after/' + name)))
        transitions.append(dict(source=name, before=identity(before), after=identity(after), diff=identity(diff)))
    results = []
    for suffix, status, expected in [
        ('before-509', 'failed', 'requires a LIMIT'),
        ('before-509b', 'failed', 'function has no admitted scalar declaration'),
        ('after-509', 'passed', '1 passed; 0 failed; 0 ignored'),
    ]:
        path = OUT / ('stream-subquery-projected-exists-' + suffix + '.json')
        receipt, log = json.loads(path.read_text()), path.with_suffix('.log')
        assert receipt['status'] == status and receipt['process_group_drained'] and receipt['direct_child_reaped']
        assert sha(log) == receipt['log_sha256'] and expected in log.read_text()
        results.append(dict(status=status, receipt=identity(path), log=identity(log)))
    save(DEST / 'corrections.json', dict(status='frozen_for_candidate_execution',
        before=identity(OUT / 'native-release-source-streamsubquery508.json'), after=identity(frozen),
        initial_failure=identity(DEST / 'initial-failures.json'), transitions=transitions,
        parser_regression=results, first_regression_fixture='The low-level local parser requires LIMIT; the native relation frontend inserts its bound separately. The first test omitted LIMIT. Original source and failed receipt remain retained.',
        parser_correction='Add exists to the existing top-level predicate projection keyword classifier; reuse native predicate lowering and subquery execution.',
        fixture_corrections=['Alias divide-by-zero scalar output as bad.',
                             'Use direct write_vortex/write_jsonl writer identifiers.',
                             'Require non-finite Arrow rejection during unused source validation; also require finite multirow input to skip scalar cardinality.',
                             'Assert the complete public output schema, including nullability.'],
        unchanged_native_streaming_runtime=True, new_direct_subcases=127,
        candidate_public_declarations=identity(OUT / 'stream-subquery-candidate-declarations-509/declarations.json'),
        acceptance_protocol=identity(OUT / 'stream-subquery-acceptance-protocol-509.json'),
        old_binary_acceptance=False, performance_claim=False))
    print(json.dumps(dict(status='frozen_for_candidate_execution', changed_sources=len(changes))))


if __name__ == '__main__':
    main()
