"""Validate finite subquery documentation and all generated guide surfaces."""
import json
from pathlib import Path
import re
import subprocess
import sys
import time

from freeze_native_release_298 import ROOT, OUT, sha, sources, save

DEST = OUT / 'stream-subquery-documentation-511'
NODE = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
SITE = ROOT / 'website-src'


def main():
    final_source = OUT / 'stream-subquery-final-source-511.json'
    accepted = json.loads(final_source.read_text())['source_sha256']
    assert sources() == accepted and not DEST.exists()
    workflow = sha(ROOT / '.github/workflows/ci.yml')
    DEST.mkdir()
    node = lambda *args: [NODE, *map(str, args)]
    python = lambda *args: [sys.executable, '-B', *map(str, args)]
    commands = [
        ('search-policy', node('--test', 'scripts/pagefind-policy.test.mjs'), SITE),
        ('static-reset', node('scripts/prebuild-static.mjs', '--reset-output'), SITE),
        ('sync-content', node('scripts/sync-content.mjs'), SITE),
        ('astro-build', node('node_modules/astro/bin/astro.mjs', 'build'), SITE),
        ('static-postbuild', node('scripts/postbuild-static.mjs'), SITE),
        ('check-preparation', node('scripts/prebuild-static.mjs'), SITE),
        ('check-content', node('scripts/sync-content.mjs'), SITE),
        ('astro-check', node('node_modules/astro/bin/astro.mjs', 'check'), SITE),
        ('check-settle', node('scripts/prebuild-static.mjs', '--settle-output'), SITE),
        ('public-status', python('scripts/check_public_status_docs.py', '--output', DEST / 'public-status.json'), ROOT),
        ('website-links', python('-m', 'unittest', 'discover', '-s', 'scripts', '-p', 'test_website_links.py'), ROOT),
        ('website-readiness', python('scripts/check_website_readiness.py', '--output', DEST / 'website-readiness.json'), ROOT),
        ('static-assets', node('scripts/validate_static_assets.cjs'), ROOT),
        ('user-surface', python('scripts/check_user_surface_reference.py'), ROOT),
        ('use-case-backlinks', python('scripts/check_use_case_backlinks.py'), ROOT),
        ('contribution-governance', python('scripts/check_contribution_governance.py', '--output', DEST / 'contribution-governance.json'), ROOT),
        ('ci-gate-matrix', python('scripts/check_ci_gate_matrix.py', '--output', DEST / 'ci-gate-matrix.json'), ROOT),
        ('v1-inclusion', python('scripts/check_v1_inclusion_scope.py'), ROOT),
        ('diff-check', ['git', 'diff', '--check'], ROOT),
    ]
    completed, failure, links = [], None, []
    try:
        for name, command, cwd in commands:
            log = DEST / (name + '.log')
            start = time.monotonic()
            with log.open('xb') as output:
                result = subprocess.run(command, cwd=cwd, stdout=output, stderr=subprocess.STDOUT, timeout=300)
            row = dict(name=name, command=command, cwd=str(cwd), returncode=result.returncode,
                seconds=time.monotonic() - start, log=str(log), log_sha256=sha(log))
            completed.append(row)
            print(json.dumps(dict(name=name, returncode=result.returncode)), flush=True)
            result.check_returncode()
        changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT, text=True).splitlines()
        untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=ROOT, text=True).splitlines()
        documents = sorted(name for name in set(changed + untracked) if name.endswith('.md'))
        for name in documents:
            path = ROOT / name
            for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^\s)]+)\)', path.read_text()):
                if target.startswith(('https:', 'http:', 'mailto:', '#')):
                    continue
                destination = (path.parent / target.split('#', 1)[0]).resolve()
                assert destination.exists(), (name, target)
                links.append(dict(document=name, target=target))
        assert sources() == accepted and sha(ROOT / '.github/workflows/ci.yml') == workflow
        for name in ('runtime-and-io', 'python-surface', 'limitations'):
            generated = ROOT / 'website/field-guide' / name / 'index.html'
            text = re.sub(r'\s+', ' ', generated.read_text())
            assert 'native-stream-subqueries-2026-10-15.md' in text
            assert '3,724 public cases' in text and '96 direct methods' in text
            assert 'membership/index state remains resident' in text
            assert 'Opaque dynamically declared inner sources' in text
            assert '0.6.0' in text and 'PR #1559' in text
            assert 'native-stream-unary-2026-10-15.md' in text
        benchmark = (ROOT / 'website/field-guide/benchmark-methodology/index.html').read_text()
        assert 'native-stream-subqueries-2026-10-15.md' in benchmark
        assert '3,724 public cases' in benchmark and '96 direct methods' in benchmark
        assert 'native-stream-unary-2026-10-15.md' in benchmark and '59.997 s' in benchmark
        report = (ROOT / 'docs/benchmarks/native-stream-subqueries-2026-10-15.md').read_text()
        assert len(re.findall(r'^\| Q\d+ \|', report, re.MULTILINE)) == 43
        assert 'Hosted integration remains pending' in report
        for item in ('3,724', '4,264', '3,220', '96', '1,123', '127'):
            assert item in report, item
        index = json.loads((ROOT / 'docs/benchmarks/evidence/native-stream-subqueries-2026-10-15.json').read_text())
        assert format(index['member_count'], ',') in report
        assert index['status'] == 'passed_local' and index['independent_packet_audit_passed']
        assert index['hosted_integration_complete'] is False
        reference = json.loads((ROOT / 'docs/reference/shardloom-user-surface-index.json').read_text())
        streaming = reference['native_python_batch_adapters']['streaming_input']
        assert streaming['subquery_acceptance_status'] == 'local_acceptance_complete_pending_hosted'
        assert streaming['unary_acceptance_status'] == 'local_and_hosted_acceptance_complete'
    except BaseException as error:
        failure = f'{type(error).__name__}: {error}'
        raise
    finally:
        save(DEST / 'summary.json', dict(status='passed' if failure is None else 'failed',
            failure=failure, checks=completed, local_links=links,
            selected_sources_unchanged=sources() == accepted, source_files=len(accepted),
            workflow_sha256=workflow, final_source_manifest=dict(path=str(final_source), sha256=sha(final_source)),
            helper_sha256=sha(__file__), rendered_browser_verification=False,
            generator_sha256=sha(SITE / 'scripts/sync-content.mjs'),
            scope='Finite statically declared subquery admission and completed unary hosted status; immutable 0.6.0 package scope is preserved.',
            native_workloads_rerun=False))
    print(json.dumps(dict(status='passed', checks=len(completed), local_links=len(links))))


if __name__ == '__main__':
    main()
