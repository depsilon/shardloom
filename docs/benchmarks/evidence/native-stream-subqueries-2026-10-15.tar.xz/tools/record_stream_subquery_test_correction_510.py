"""Preserve and bind a lint-only assertion correction in the parser test module."""
import difflib
import json
from pathlib import Path
import sys

from freeze_native_release_298 import ROOT, OUT, sources, save
from run_stream_subquery_acceptance_509 import SOURCE, MANIFEST, identity

NAME = 'shardloom-cli/src/sql_syntax.rs'
DEST = OUT / 'stream-subquery-test-correction-510'
ACCEPTED = OUT / 'stream-subquery-verification-source-510.json'
OLD = '            assert!(parsed.generic_expression_projections.is_empty());'
NEW = '\n'.join(['            assert_eq!(', '                parsed.generic_expression_projections,',
                 '                [] as [ParsedGenericExpressionProjection; 0]', '            );'])


def prepare():
    frozen = json.loads(SOURCE.read_text())
    assert sources() == frozen['source_sha256']
    assert not DEST.exists() and not ACCEPTED.exists()
    failure = OUT / 'stream-subquery-workspace-clippy-509.json'
    receipt = json.loads(failure.read_text())
    assert receipt['status'] == 'failed' and receipt['returncode'] == 101
    assert receipt['process_group_drained'] and receipt['direct_child_reaped']
    log = failure.with_suffix('.log')
    assert identity(log)['sha256'] == receipt['log_sha256']
    assert 'clippy::assert_is_empty' in log.read_text()
    DEST.mkdir()
    before = DEST / 'sql_syntax.before.rs'
    with before.open('xb') as stream:
        stream.write((ROOT / NAME).read_bytes())
    assert identity(before)['sha256'] == frozen['source_sha256'][NAME]
    save(DEST / 'before.json', dict(status='frozen_before_test_correction', source=identity(SOURCE),
        artifacts=identity(MANIFEST), before=identity(before), failure=identity(failure),
        failure_log=identity(log), partial_checks=identity(OUT / 'stream-subquery-checks-509.json'),
        cause='New parser regression uses assert!(vec.is_empty()); workspace lint requires the more informative equality assertion.',
        changed_path=NAME, expected_old=OLD, expected_new=NEW, helper=identity(__file__)))
    print(json.dumps(dict(status='frozen_before_test_correction')))


def seal():
    frozen = json.loads(SOURCE.read_text())
    before = json.loads((DEST / 'before.json').read_text())
    path = Path(before['before']['path'])
    assert identity(path) == before['before']
    original, actual = path.read_text(), (ROOT / NAME).read_text()
    assert original.count(OLD) == 1 and actual == original.replace(OLD, NEW)
    marker = '#[cfg(test)]\n#[allow(clippy::too_many_lines)]\nmod tests {'
    assert marker in original and original.index(OLD) > original.index(marker)
    assert actual.split(marker)[0] == original.split(marker)[0]
    current = sources()
    assert set(current) == set(frozen['source_sha256']) and len(current) == 2291
    assert [name for name in current if current[name] != frozen['source_sha256'][name]] == [NAME]
    after, diff = DEST / 'sql_syntax.after.rs', DEST / 'test-only.diff'
    with after.open('xb') as stream:
        stream.write((ROOT / NAME).read_bytes())
    with diff.open('x') as stream:
        stream.write(''.join(difflib.unified_diff(original.splitlines(keepends=True), actual.splitlines(keepends=True),
                                                fromfile='before/' + NAME, tofile='after/' + NAME)))
    save(ACCEPTED, dict(status='frozen_for_verification', head=frozen['head'], source_sha256=current,
        build_source=identity(SOURCE), artifacts=identity(MANIFEST), changed_files=[NAME], added_files=[],
        before=identity(DEST / 'before.json'), original=identity(path), after=identity(after), diff=identity(diff),
        helper=identity(__file__), production_code_identical=True,
        exact_cfg_test_assertion_replacement=True, runtime_oracles_unchanged=True,
        compiled_artifacts_changed=False, preserved_successful_runtime_sources=identity(SOURCE)))
    print(json.dumps(dict(status='frozen_for_verification', production_code_identical=True, changed_files=[NAME])))


if __name__ == '__main__':
    prepare() if sys.argv[1:] == ['prepare'] else seal()
