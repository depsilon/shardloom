"""Retain the exact original contract and its feature-label-only correction."""
import difflib
import json
from pathlib import Path

from freeze_native_release_298 import ROOT, OUT, save, sha
from stream_subquery_acceptance_sources_510 import identity


def main():
    current = ROOT / 'docs/architecture/native-stream-subqueries-2026-10-15.md'
    before_path = OUT / 'stream-subquery-baseline-contract-511.md'
    after_path = OUT / 'stream-subquery-candidate-contract-511.md'
    report = OUT / 'stream-subquery-contract-label-correction-511.json'
    assert not any(path.exists() for path in (before_path, after_path, report))
    corrected = ('`vortex-local-primitives` feature, with `vortex-write` for native replay runs.\n'
                 'Reuse native compact payload selection and the existing')
    original = '`native-vortex` feature. Reuse native compact payload selection and the existing'
    text = current.read_text()
    assert text.count(corrected) == 1 and original not in text
    before = text.replace(corrected, original)
    with before_path.open('x') as stream:
        stream.write(before)
    with after_path.open('x') as stream:
        stream.write(text)
    baseline = OUT / 'stream-subquery-baseline-507/summary.json'
    declaration = OUT / 'stream-subquery-candidate-declarations-509/declarations.json'
    assert sha(before_path) == json.loads(baseline.read_text())['contract_sha256']
    assert sha(after_path) == sha(current) == json.loads(declaration.read_text())['contract_sha256']
    save(report, dict(status='passed_exact_feature_label_correction', original=identity(before_path),
        corrected=identity(after_path), baseline=identity(baseline), candidate_declaration=identity(declaration),
        original_hash_verified_against_preimplementation_baseline=True,
        reconstruction='Reverse only the documented feature-name correction; exact baseline SHA-256 confirms all original bytes.',
        diff=''.join(difflib.unified_diff(before.splitlines(True), text.splitlines(True),
                     fromfile='baseline-contract', tofile='candidate-contract')),
        runtime_changed=False, acceptance_expectations_changed=False, helper=identity(__file__)))
    print(json.dumps(dict(status='passed_exact_feature_label_correction')))


if __name__ == '__main__':
    main()
