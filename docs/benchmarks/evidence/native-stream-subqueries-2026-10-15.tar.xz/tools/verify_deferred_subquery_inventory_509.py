"""Check the leaf's literal inventory against every frozen source excerpt/call."""
import json
from pathlib import Path
import re
import subprocess

from freeze_native_release_298 import ROOT, OUT, sha, save


def main():
    path = OUT / 'deferred-subquery-declaration-inventory-509.json'
    inventory = json.loads(path.read_text())
    frozen = json.loads((OUT / 'native-release-source-streamsubquery509.json').read_text())
    entries = inventory['entries'] + inventory['excluded_matches']
    assert len(inventory['entries']) == 16 and len(inventory['excluded_matches']) == 8
    for entry in entries:
        source = ROOT / entry['file']
        assert sha(source) == entry['whole_file_sha256'] == frozen['source_sha256'][entry['file']]
        start, end = entry['line_interval']
        lines = source.read_text().splitlines()
        wanted = '\n'.join(f'{number}: {lines[number - 1]}' for number in range(start, end + 1))
        assert wanted == entry['excerpt'], entry['file']
    scope = inventory['search_scope']
    calls = subprocess.check_output(['rg', '-n', r'\.defer_subquery\(', *scope], cwd=ROOT, text=True).splitlines()
    assert len(calls) == 7
    test_names, production = [], []
    for match in calls:
        name, line, text = match.split(':', 2)
        number = int(line)
        assert any(row['file'] == name and row['line_interval'][0] <= number <= row['line_interval'][1]
                   for row in inventory['entries']), match
        if name.endswith('_tests.rs'):
            previous = '\n'.join((ROOT / name).read_text().splitlines()[:number])
            test_names.append(re.findall(r'(?m)^fn (\w+)\(', previous)[-1])
        else:
            production.append(dict(source=name, line=number, call=text.strip()))
    assert len(production) == 2 and len(test_names) == 5
    assert sorted(test_names) == sorted(inventory['coverage']['test_callers'])
    save(OUT / 'deferred-subquery-inventory-primary-509.json', dict(
        status='passed_source_provenance_only', source_excerpts=len(entries),
        inventory=dict(path=str(path), sha256=sha(path)), production_calls=production,
        test_callers=test_names, native_execution_performed=False,
        design_or_semantics_approved=False, helper_sha256=sha(__file__)))
    print(json.dumps(dict(status='passed_source_provenance_only', excerpts=len(entries), calls=len(calls))))


if __name__ == '__main__':
    main()
