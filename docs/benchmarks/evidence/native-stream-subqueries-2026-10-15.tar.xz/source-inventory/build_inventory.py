#!/usr/bin/env python3
"""Create a bounded, hash-backed source inventory from the read-only worktree."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path("/Users/dylan/.codex/worktrees/native-result-composition/shardloom-local-repo")
OUT = Path("/Users/dylan/LocalData/shardloom/native-python-surface-20261010/stream-subquery-source-inventory-494/stream-subquery-source-inventory-494.json")

SLICES = [
    ("admission-count_sources", "shardloom-vortex/src/local_primitive_relational_batch_input.rs", 618, 704, "Complete `classify`, `classify_dynamic`, and `count_sources`; exact batch admission/refusal logic, including dynamic/static pivot and depth guard."),
    ("batch-registration-replay-classification", "shardloom-vortex/src/local_primitive_relational_bind.rs", 175, 225, "Batch-source declaration validation and the call that marks repeated-source replay based on whole-plan classification."),
    ("dynamic-root-subtree-classification", "shardloom-vortex/src/local_primitive_relational_bind.rs", 261, 310, "Root dynamic lowering validates each resolved subtree before binding; plan dispatch routes subquery variants into the native binder."),
    ("plan-and-request-types", "shardloom-vortex/src/relational_query.rs", 95, 122, "Plan variants and constraints for subquery, correlated outer rows, execution results, and deferred subquery references."),
    ("subquery-kind-and-declaration", "shardloom-vortex/src/relational_query.rs", 365, 396, "Complete subquery-kind enum and declaration shape with evaluation guard, correlation, and negation."),
    ("native-subquery-binder", "shardloom-vortex/src/local_primitive_relational_subquery_bind.rs", 15, 137, "Complete Binder::subquery and subquery_relation methods: accepted shapes, deterministic refusals, and relation binding."),
    ("native-subquery-executor", "shardloom-vortex/src/local_primitive_relational_correlated.rs", 9, 154, "Complete run_subquery and run_uncorrelated_subquery methods."),
    ("ordinary-plan-validation-caller", "shardloom-vortex/src/local_primitive_prepared_relational.rs", 535, 550, "Preparation lowers the plan, validates batch-source usage/replay, and only then binds it."),
    ("subquery-execution-dispatch", "shardloom-vortex/src/local_primitive_prepared_relational.rs", 1235, 1253, "Prepared execution dispatches NodeKind::Subquery to `run_subquery`."),
    ("sql-shape-and-expression-routing", "shardloom-cli/src/sql_native_relational.rs", 166, 186, "SQL shape discovery promotes scalar relational bindings and subquery predicates to native relational lowering."),
    ("predicate-subquery-check", "shardloom-cli/src/sql_scalar_expression.rs", 60, 75, "Complete recursive predicate binding check for IN, row-IN, quantified, EXISTS, logical/not, and generic scalar bindings."),
    ("sql-predicate-declaration-and-plan-lowering", "shardloom-cli/src/sql_native_relational_predicate.rs", 11, 57, "Complete declared-source traversal for supported predicate subquery forms and the subquery-presence helper."),
    ("sql-correlation-detection-and-plan-construction", "shardloom-cli/src/sql_native_relational_predicate.rs", 427, 512, "Complete subquery lowering method and plan constructor: determines parameterized/correlated form from source, predicate, and projected relation, then emits the corresponding plan variant."),
    ("sql-complete-source-declaration", "shardloom-cli/src/sql_native_relational.rs", 195, 246, "Complete unique path counting and query/source traversal across derived/unary inputs, joins, predicates, and scalar bindings."),
    ("dynamic-sql-reuse-declaration", "shardloom-cli/src/sql_native_relational_dynamic.rs", 130, 170, "Dynamic SQL aggregates repeated URI use and declares replay before lowering/demand."),
    ("dynamic-replay-admission", "shardloom-vortex/src/local_primitive_relational_dynamic_bind.rs", 35, 110, "Dynamic execution reinstates batch declarations, requires replay where recorded, and resolves URI reuse."),
    ("replay-input-lifecycle", "shardloom-vortex/src/local_primitive_relational_batch_input.rs", 337, 365, "Complete replay-consumption method: requires explicit completed input and consumes native replay."),
    ("finite-source-and-end-of-input", "shardloom-vortex/src/local_primitive_relational_batch_input.rs", 384, 450, "Bounded provider execution records finite native batches; excerpt ends within per-batch validation."),
    ("input-completion-certificate", "shardloom-vortex/src/local_primitive_relational_batch_input.rs", 481, 504, "Complete explicit end-of-input check and replay-owner cleanup before completion evidence."),
    ("streaming-refusal-fixture", "scripts/native_streaming_input_cases.py", 138, 162, "Complete UAT refusal helper and three named subquery refusal cases; source fixture only, not execution evidence."),
    ("resident-batch-plan-refusal-test", "shardloom-vortex/src/local_primitive_relational_batch_input_tests.rs", 356, 368, "Complete direct Outer admission test slice; establishes correlated-source refusal before provider invocation, not subquery wrapper refusal."),
    ("dynamic-plan-refusal-test", "shardloom-vortex/src/local_primitive_relational_batch_dynamic_tests.rs", 442, 498, "Complete dynamic unsupported-shapes test; tests Outer in set branches, unsupported unary, and cancellation; does not test Subquery directly."),
    ("set-refusal-and-replay-tests", "shardloom-vortex/src/local_primitive_relational_batch_set_tests.rs", 231, 275, "Complete static refusal and start of replay test: both set branches checked and depth bounded; repeated native source replay tested."),
    ("resident-native-subquery-semantics-test", "shardloom-vortex/src/local_primitive_relational_subquery_tests.rs", 45, 102, "Named resident native test covers IN/NOT IN/ANY/ALL/EXISTS null and empty-set semantics; excerpt includes fixtures and expectations only."),
    ("resident-native-subquery-reexecution-test", "shardloom-vortex/src/local_primitive_relational_subquery_tests.rs", 236, 279, "Complete test for preserving outer rows, repeated execution without source reopen, and memory returning to baseline."),
    ("resident-correlated-fault-test", "shardloom-vortex/src/local_primitive_relational_correlated_tests.rs", 284, 336, "Correlated resident cancellation/pressure/source-invalidation test; slice continues beyond end of excerpted test body."),
    ("resident-sql-subquery-test", "shardloom-cli/src/sql_native_relational_tests.rs", 732, 770, "SQL integration test exercises uncorrelated IN/ALL and correlated EXISTS/IN subqueries over resident fixture files."),
    ("python-public-predicate-methods", "python/src/shardloom/query.py", 611, 640, "Public ColumnExpression.isin_source method declares scoped local-source IN-subquery SQL and source bindings."),
    ("python-public-subquery-helpers", "python/src/shardloom/query.py", 8237, 8256, "Public `outer` and `scalar_subquery` declarations; scalar source is declared without executing it."),
    ("python-public-any-all-exists", "python/src/shardloom/query.py", 8355, 8444, "Public ANY, ALL, and EXISTS source helper signatures and SQL-lowering calls."),
    ("join-on-explicit-refusal", "shardloom-cli/src/sql_native_relational.rs", 575, 590, "JOIN ON lowering explicitly refuses subquery predicates; excerpt continues through column mapping."),
]

def main() -> None:
    evidence = []
    for evidence_id, rel, start, end, note in SLICES:
        raw = (ROOT / rel).read_bytes()
        lines = raw.decode("utf-8").splitlines()
        if start < 1 or end > len(lines):
            raise ValueError(f"bad slice {rel}:{start}-{end}; file has {len(lines)} lines")
        excerpt = "\n".join(f"{n}: {lines[n-1]}" for n in range(start, end + 1))
        evidence.append({
            "id": evidence_id,
            "path": rel,
            "snapshot": "current_worktree_read_only",
            "sha256": hashlib.sha256(raw).hexdigest(),
            "line_start": start,
            "line_end": end,
            "excerpt": excerpt,
            "excerpt_completeness": "complete cited line range; see note for whether it is a complete symbol/test",
            "note": note,
        })
    report = {
        "title": "Finite-input native subquery and correlated-source boundary inventory",
        "created_utc_date": "2026-10-15",
        "repository_root": str(ROOT),
        "repository_head": "e859b3a8b9d323587cee9641f5ebacd21e7e799c",
        "scope": "Bounded read-only source inventory of finite batch source classification, SQL expression checks, native subquery binding/execution, source declaration/replay/completion, relevant resident tests and streaming refusal fixtures, and public Python declarations.",
        "evidence_count": len(evidence),
        "evidence": evidence,
        "source_facts": [
            "Static classify accepts one occurrence of its declared batch URI, marks repeated occurrences for replay, rejects a plan with no declared URI use, and rejects plan shapes named by count_sources. The complete count_sources function is evidence entry admission-count_sources.",
            "count_sources directly refuses Subquery and CorrelatedSubquery as `subquery`, Outer as `correlated source`, and DeferredSubquery / non-dynamic ExecutionResult as `dynamic schema`. It does not recurse into the subquery's input or relation before refusing the wrapper.",
            "Dynamic classification permits ExecutionResult as zero source scans, admits Unary(PivotRows) only when the dynamic flag is true, and otherwise follows the same subquery and Outer refusal arms. Ordinary static Unary(PivotRows) maps to `unary stateful operator`.",
            "Binder::bind dispatches Subquery and CorrelatedSubquery to Binder::subquery. Binder::subquery supports the declared request kinds In, Quantified, Exists, Scalar subject to its arity, correlation, dtype, guard, and relation checks. DeferredSubquery is accepted only as a parameterized immediate relation.",
            "Native execution dispatches NodeKind::Subquery to run_subquery. Correlated execution iterates selected outer rows, binds each as a native singleton, creates fresh subquery state, executes the inner relation, validates dynamic relation schema when applicable, and appends results. Uncorrelated execution requires a Bound relation; guarded/scalar execution builds only when an outer row is selected, while ordinary membership builds the subquery then consumes outer input.",
            "SQL shape discovery treats relational scalar bindings and predicate subquery bindings as native relational work. Predicate checks name IN, row-value IN, quantified, EXISTS and recursive logical/not/generic binding surfaces. SQL predicate lowering converts the subquery to Plan::Subquery or Plan::CorrelatedSubquery based on parameterization.",
            "SQL source enumeration traverses declared query source trees and predicate/scalar subquery declarations. Dynamic SQL tracks repeated URI occurrence and declares reuse before lowering. Batch replay requires prior declaration and completed input; completion requires every declared source to have started and reached explicit end-of-input, then drops replay owners.",
            "The UAT source file defines named refusal cases for a source-IN subquery directly and on either set branch; it is fixture code, not proof that those cases were run. Current unit tests directly assert Outer/correlated-source refusals and dynamic unsupported shapes, but the cited tests do not directly instantiate a VortexRelationalPlan::Subquery and assert its stream denial.",
            "Resident native Rust/SQL tests show subquery semantics, repeated prepared execution, source-open behavior, memory cleanup, and correlated cancellation/pressure paths. These are resident/native subquery facts, not evidence that finite batch streaming subquery execution is admitted.",
            "Public Python exposes source-based IN/NOT IN, row-value IN/NOT IN, ANY, ALL, EXISTS/NOT EXISTS, scalar_subquery, and outer declarations. The cited Python excerpts demonstrate declaration surfaces; they do not establish batch streaming admission.",
        ],
        "inference": [
            "Because static `count_sources` refuses a Subquery wrapper before traversing its nested input/relation, SQL declaration/source-count traversal cannot by itself make a source-IN subquery admissible to static streaming. This is an inference from the cited traversal and refusal functions.",
            "The UAT helper appears designed to prove refusal precedes producer demand and output creation, since it asserts opened == [] and no output artifacts; however this inventory did not execute it and makes no fresh runtime claim.",
        ],
        "test_inventory": {
            "streaming_refusal_fixture": ["deny-subquery-left-set", "deny-subquery-right-set", "deny-subquery"],
            "direct_subquery_streaming_denial_test_found": False,
            "related_streaming_unit_tests": ["completion_input_plan_and_provider_admission_precede_payload", "streamed_dynamic_unsupported_shapes_and_initial_cancellation_precede_demand", "streaming_sets_inspect_both_branches_and_preserve_static_depth_refusals"],
            "resident_subquery_tests": ["native_relational_subquery_in_not_in_any_all_and_exists_preserve_null_and_empty_set_rules", "native_relational_row_subquery_distinguishes_unknown_from_a_definite_mismatching_tuple", "native_relational_correlated_membership_and_exists_treat_null_correlation_as_empty", "native_relational_subqueries_preserve_every_outer_row_and_can_be_reexecuted_without_source_reopen", "native_relational_correlated_group_having_order_and_limit_apply_before_membership", "native_relational_correlated_top_one_is_chosen_after_each_parameter_filter", "native_relational_correlated_cancellation_pressure_and_source_invalidation_never_publish_success", "native_relational_sql_subqueries_lower_relations_instead_of_unfilled_value_caches"],
        },
        "search_coverage": {
            "searched": ["shardloom-vortex/src/local_primitive_relational_batch_input.rs", "shardloom-vortex/src/local_primitive_relational_bind.rs", "shardloom-vortex/src/local_primitive_relational_subquery_bind.rs", "shardloom-vortex/src/local_primitive_relational_correlated.rs", "shardloom-vortex/src/local_primitive_prepared_relational.rs", "shardloom-vortex/src/relational_query.rs", "shardloom-cli/src/sql_native_relational.rs", "shardloom-cli/src/sql_native_relational_predicate.rs", "shardloom-cli/src/sql_native_relational_dynamic.rs", "shardloom-cli/src/sql_scalar_expression.rs", "shardloom-vortex/src/local_primitive_relational_batch_input_tests.rs", "shardloom-vortex/src/local_primitive_relational_batch_dynamic_tests.rs", "shardloom-vortex/src/local_primitive_relational_batch_set_tests.rs", "shardloom-vortex/src/local_primitive_relational_subquery_tests.rs", "shardloom-vortex/src/local_primitive_relational_correlated_tests.rs", "shardloom-cli/src/sql_native_relational_tests.rs", "scripts/native_streaming_input_cases.py", "python/src/shardloom/query.py"],
            "not_exhaustively_searched": ["all generated documentation, all historical UAT receipts, and all possible aliases across every script/test module"],
            "truncated_or_bounded": ["finite-source-and-end-of-input excerpt ends during per-batch validation", "resident-native-subquery-semantics-test excerpt contains only its setup/expectation portion", "resident-correlated-fault-test excerpt does not include its full test body", "resident-sql-subquery-test includes the first named SQL test and beginning of the following test"],
            "unresolved": ["No current test source directly constructs a streaming VortexRelationalPlan::Subquery and asserts its refusal; only the UAT fixture defines named SQL-level cases. Whether a separately stored hosted run receipt proves those fixture cases ran was out of scope."],
        },
        "constraints": ["Read-only repository inspection; no tests, builds, or engines run.", "No external execution fallback is described or implied.", "Resident native subquery execution and finite-input streaming admission are separate surfaces.", "No new admission or algorithm is proposed."],
    }
    OUT.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"wrote {OUT} with {len(evidence)} evidence entries")

if __name__ == "__main__":
    main()
