"""Preserve integrated acceptance and all four exact source versions compactly."""
import hashlib
import io
import json
import lzma
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import tempfile

import output_window_integration_789 as d

E, W = d.E, d.W
DEST = E / 'output-window-accepted-portable-791'
NAME = 'output-window-accepted-791'
LABEL = 'output-credit-window-integrated-790-a4'
LOCAL = Path('/Users/dylan/LocalData/shardloom')
sys.path.insert(0, str(W / 'scripts'))
from local_uat_storage import GIB, MIB, check_budgets, require_local_path


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    with path.open('rb') as stream:
        sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha)


def read(path):
    return json.loads(Path(path).read_text())


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def references(value):
    if isinstance(value, dict):
        if set(value) == {'path', 'bytes', 'sha256'} and Path(value['path']).is_absolute():
            yield value
        else:
            for child in value.values():
                yield from references(child)
    elif isinstance(value, list):
        for child in value:
            yield from references(child)


def member_name(path):
    path = Path(path)
    for root, prefix in ((E, 'evidence/'), (W, 'repo/'), (LOCAL, 'local/')):
        if path.is_relative_to(root):
            return prefix + path.relative_to(root).as_posix()
    raise AssertionError(path)


def main():
    assert not DEST.exists()
    require_local_path(DEST, Path.home(), sys.platform)
    check_budgets(E, DEST, E / 'logs', min_free_bytes=12*GIB, reserve_bytes=512*MIB,
                  max_workspace_bytes=100*GIB, max_log_bytes=192*MIB)
    subprocess.run([sys.executable, '-B', str(E / 'output_window_acceptance_789.py'), 'verify'], cwd=W, check=True)
    final_path = E / 'output-window-final-acceptance-791.json'
    final = read(final_path)
    assert final['status'] == 'passed' and final['production_accepted'] is True
    assert final['source_commit'] == d.HEAD and final['public_cases'] == 5930
    assert not final['cpu_speedup_claim'] and not final['publication_attempted']
    build = read(E / 'output-window-acceptance-build-789.json')
    source = read(E / 'output-window-acceptance-source-789.json')
    plan = read(E / 'output-window-acceptance-plan-789.json')
    members = {}

    def add(path=None, *, name=None, raw=None, original=None):
        if raw is None:
            path = Path(path)
            row = identity(path)
            payload = path
            original = str(path)
            name = member_name(path) if name is None else name
        else:
            assert path is None and name is not None and original is not None
            row = dict(bytes=len(raw), sha256=digest(raw))
            payload = raw
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        entry = dict(path=name, original_path=original, bytes=row['bytes'], sha256=row['sha256'])
        if name in members:
            assert members[name][0] == entry
        else:
            members[name] = (entry, payload)

    # Complete frozen comparison stays immutable, including its failed attempts.
    comparison_root = E / 'output-credit-window-portable-788'
    comparison = read(comparison_root / 'output-credit-window-788.json')
    for key in ('archive', 'manifest'):
        row = comparison[key]
        actual = identity(comparison_root / row['file'])
        assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256'])
        add(Path(actual['path']))
    assert comparison['archive']['sha256'] == 'f4c936271e0470944c73c0bfa7d80000ca5e9b058d14446ac6c229f10bbe1316'
    add(comparison_root / 'output-credit-window-788.json')
    add(E / 'output-credit-window-packet-verification-788.json')
    for name in ('output-credit-window-package-788-a1', 'output-credit-window-packet-check-788-a1'):
        for suffix in ('.json', '.log'):
            add(E / (name + suffix))

    # All integration receipts, failed attempts, helper revisions and patches.
    excluded = ('output-window-archive-791', 'output-window-archive-check-791')
    for path in sorted(E.iterdir()):
        if not path.is_file() or path.name.startswith(excluded):
            continue
        family = path.name.startswith(('output-credit-window-', 'output-window-', 'output_window_',
            'finalize_output_window_', 'package_output_window_', 'verify_output_window_'))
        family &= re.search(r'789|790|791', path.name) is not None
        if family and path.suffix in ('.json', '.log', '.txt', '.patch', '.py', '.md', '.csv', '.pid'):
            add(path)
    add(final_path)
    add(Path(__file__))
    add(E / 'verify_output_window_packet_791.py')
    for path in sorted(E.glob('output-credit-window-integrated-*-extra-sources/**/*')):
        if path.is_file():
            add(path)

    # Keep every final acceptance reference except compiled products. Their
    # identities and build instructions remain explicit omissions below.
    compiled = []
    for ref in final['verified_file_references']:
        path = Path(ref['path'])
        assert identity(path) == ref
        if path.suffix in ('.so', '.dylib', '.whl') or path.name.endswith('-test') or path.name == 'shardloom':
            compiled.append(ref)
        else:
            add(path)
    for ref in references(plan):
        path = Path(ref['path'])
        assert identity(path) == ref
        add(path)
    for path in sorted((E / 'output-window-public-789/logs').rglob('*')):
        if path.is_file():
            add(path)
    add(E / 'output-window-public-789/summary.json')
    for path in sorted((E / 'output-window-full43-789/logs').rglob('*')):
        if path.is_file():
            add(path)
    proof_root = E / 'output-window-installed-python-789'
    for path in sorted(proof_root.iterdir()):
        if path.is_file() and path.suffix in ('.json', '.log'):
            add(path)

    # Exact source blobs allow all integrated versions to be reconstructed
    # without a network fetch or a mutable checkout. Deduplicate by SHA-256.
    freezes = sorted(E.glob('output-credit-window-integrated-*-source-freeze.json'))
    assert len(freezes) == 4
    tracked = set(d.git('ls-files').splitlines())
    changed_paths = {before for path in freezes for before, after in re.findall(
        r'^diff --git a/(\S+) b/(\S+)$',
        (E / (path.name.removesuffix('-source-freeze.json') + '-tracked.patch')).read_text(), re.MULTILINE)
        if before == after}
    names = sorted({row['path'] for path in freezes for row in read(path)['sources']}
                   | set(source['source_hashes']) | changed_paths)
    base = {}
    process = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=W, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    try:
        for name in names:
            if name not in tracked:
                continue
            assert '\n' not in name
            process.stdin.write(f'{d.HEAD}:{name}\n'.encode())
            process.stdin.flush()
            header = process.stdout.readline().decode().strip().split()
            assert len(header) == 3 and header[1] == 'blob', (name, header)
            raw = process.stdout.read(int(header[2]))
            assert len(raw) == int(header[2]) and process.stdout.read(1) == b'\n'
            base[name] = raw
    finally:
        process.stdin.close()
        process.stdout.close()
        assert process.wait(timeout=20) == 0

    def blob(raw):
        sha = digest(raw)
        add(name='sources/blobs/' + sha, raw=raw, original='generated:source-blob:' + sha)
        return dict(bytes=len(raw), sha256=sha, member='sources/blobs/' + sha)

    versions, tracked_patch_only, helper_refs = {}, {}, []
    with tempfile.TemporaryDirectory(prefix='output-window-source-rebuild-791-', dir=E) as directory:
        root = Path(directory)
        for path in freezes:
            freeze = read(path)
            label = path.name.removesuffix('-source-freeze.json')
            assert freeze['head'] == d.HEAD
            patch = E / (label + '-tracked.patch')
            assert identity(patch)['sha256'] == freeze['patch_sha256']
            changed = re.findall(r'^diff --git a/(\S+) b/(\S+)$', patch.read_text(), re.MULTILINE)
            assert changed and all(before == after and before in base for before, after in changed)
            stage = root / label
            stage.mkdir()
            for name, _ in changed:
                target = stage / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(base[name])
            subprocess.run(['git', 'apply', '--check', str(patch)], cwd=stage, check=True, capture_output=True)
            subprocess.run(['git', 'apply', '--whitespace=nowarn', str(patch)], cwd=stage, check=True, capture_output=True)
            assembled = dict(base)
            assembled.update({name: (stage / name).read_bytes() for name, _ in changed})
            for name in freeze['extra_sources']:
                assert name not in base
                assembled[name] = (E / f'{label}-extra-sources' / name).read_bytes()
            mapping = {}
            for row in freeze['sources']:
                raw = assembled[row['path']]
                assert (len(raw), digest(raw)) == (row['bytes'], row['sha256']), (label, row['path'])
                mapping[row['path']] = blob(raw)
            versions[label] = mapping
            tracked_patch_only[label] = {name:blob(assembled[name]) for name, _ in changed if name not in mapping}
            helper_refs.extend(freeze['helpers'])
    accepted = {}
    for name, sha in source['source_hashes'].items():
        raw = (W / name).read_bytes()
        assert digest(raw) == sha
        accepted[name] = blob(raw)
    add(name='sources/versions.json', original='generated:integrated-source-versions',
        raw=encoded(dict(head=d.HEAD, integrated=versions, tracked_patch_only=tracked_patch_only,
                         accepted_public_sources=accepted)))

    # Every frozen helper version must be represented by exact content.
    for ref in helper_refs:
        path = Path(ref['path'])
        if identity(path) == ref:
            add(path)
    ids = {(entry['bytes'], entry['sha256']) for entry, _ in members.values()}
    assert all((row['bytes'], row['sha256']) in ids for row in helper_refs)

    omissions = {row['path']: dict(row, category='compiled_product', copied=False) for row in compiled}
    for path in sorted(E.glob('output-credit-window-integrated-*-artifact.json')):
        item = read(path)
        actual = identity(item['artifact']['path'])
        assert actual == item['artifact']
        omissions[actual['path']] = dict(actual, category='compiled_product', copied=False,
            artifact_record=member_name(path), source_freeze=item['source_freeze'],
            build_receipt=item['build_receipt'], build_log=item['build_log'])
    for ref in (identity(build['binary']), build['native_library']):
        assert identity(ref['path']) == ref
        omissions[ref['path']] = dict(ref, category='accepted_public_artifact', copied=False,
            build_manifest=member_name(E / 'output-window-acceptance-build-789.json'))
    proof = read(proof_root / 'report.json')
    wheels = list((proof_root / 'dist').glob('*.whl'))
    assert len(wheels) == 1
    wheel = identity(wheels[0])
    assert wheel['sha256'] == proof['integrity']['wheel_sha256']
    omissions[wheel['path']] = dict(wheel, category='installed_wheel', copied=False,
                                  proof=member_name(proof_root / 'report.json'))
    input_binding = plan['input']
    stat = Path(input_binding['path']).stat()
    generation = dict(device=stat.st_dev, inode=stat.st_ino, size_bytes=stat.st_size,
                      mtime_ns=stat.st_mtime_ns, ctime_ns=stat.st_ctime_ns)
    assert generation == input_binding['generation']
    omissions[input_binding['path']] = dict(input_binding, category='resident_input', copied=False,
        hash_proof=member_name(E / 'output-window-full43-binding-789.json'),
        current_generation_checked=True, rehashed_during_packaging=False)

    # All raw compact envelopes and full value streams are retained. Generated
    # payloads/environments remain local, reproducible from the archived runner.
    generated = []
    public = read(E / 'output-window-public-789/summary.json')
    def payload_refs(value):
        if isinstance(value, dict):
            if isinstance(value.get('path'), str) and value['path'].startswith('outputs/'):
                generated.append(value)
            for child in value.values():
                payload_refs(child)
        elif isinstance(value, list):
            for child in value:
                payload_refs(child)
    payload_refs(public)
    add(name='evidence/generated-payload-omissions.json', original='generated:payload-omissions',
        raw=encoded(dict(public_output_references=generated,
            installed_package_and_environment='excluded; all build/install/test/uninstall logs and artifact identities retained',
            modular_generated_fixtures='excluded; all 18 complete report/stdout/stderr records and exact generator sources retained',
            deletion_attempted=False)))
    d.verify(LABEL)
    DEST.mkdir()
    archive_path = DEST / (NAME + '.tar.xz')
    with tarfile.open(archive_path, 'w:xz', preset=6) as archive:
        for name, (row, payload) in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size = row['bytes']; info.mode = 0o644; info.mtime = 0
            if isinstance(payload, Path):
                with payload.open('rb') as stream:
                    archive.addfile(info, stream)
            else:
                archive.addfile(info, io.BytesIO(payload))
    with tarfile.open(archive_path, 'r:xz') as archive:
        assert [member.name for member in archive.getmembers()] == sorted(members)
        for member in archive:
            row, payload = members[member.name]
            assert member.isfile() and member.size == row['bytes']
            with archive.extractfile(member) as stream:
                assert hashlib.file_digest(stream, 'sha256').hexdigest() == row['sha256']
            if isinstance(payload, Path):
                assert identity(payload)['sha256'] == row['sha256']
    manifest = dict(status='passed', all_members_reopened=True, head=d.HEAD,
        members=[members[name][0] for name in sorted(members)],
        source_versions={label:len(mapping) for label,mapping in versions.items()},
        accepted_source_files=len(accepted), embedded_comparison_members=3213,
        omitted_large_artifacts=list(omissions.values()),
        accepted_final_record=member_name(final_path), deletion_attempted=False)
    manifest_path = DEST / (NAME + '-manifest.json.xz')
    with manifest_path.open('xb') as stream:
        stream.write(lzma.compress(encoded(manifest)))
    assert json.loads(lzma.decompress(manifest_path.read_bytes())) == manifest
    index = dict(status='passed', decision=final['outcome'], production_accepted=True,
        source_commit=d.HEAD, member_count=len(members), source_versions=manifest['source_versions'],
        accepted_source_files=len(accepted), embedded_comparison_members=3213,
        archive_file=archive_path.name, manifest_file=manifest_path.name,
        archive=identity(archive_path), manifest=identity(manifest_path),
        final_acceptance=identity(final_path), cpu_speedup_claim=False, publication_attempted=False,
        all_members_reopened=True, runtime_sources_changed=False)
    d.verify(LABEL)
    d.save(DEST / (NAME + '.json'), index)
    print(json.dumps({key:index[key] for key in ('status','member_count','source_versions','archive')}))


if __name__ == '__main__':
    main()
