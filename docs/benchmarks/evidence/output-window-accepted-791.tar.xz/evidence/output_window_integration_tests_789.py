"""Strict native test selection against one exact integrated library and source tree."""
import argparse
import json
import os
import sys
import unittest

import output_window_integration_789 as d


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--label', required=True)
    parser.add_argument('--suite', choices=('ordinary', 'observation'), required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    kind = 'lib' if args.suite == 'ordinary' else 'observed'
    artifact = d.verify_artifact(args.label, kind)
    own = d.identity(__file__)
    os.environ['SHARDLOOM_REQUIRE_NATIVE_PYTHON'] = '1'
    os.environ['SHARDLOOM_NATIVE_TEST_LIBRARY'] = artifact['artifact']['path']
    os.environ.pop('SHARDLOOM_OUTPUT_WINDOW_OBSERVATION', None)
    if kind == 'observed':
        os.environ['SHARDLOOM_REQUIRE_OUTPUT_WINDOW_OBSERVATION'] = '1'
    else:
        os.environ.pop('SHARDLOOM_REQUIRE_OUTPUT_WINDOW_OBSERVATION', None)
    sys.path[:0] = [str(d.W / 'python/src'), str(d.W / 'python/tests')]
    names = (['test_native_binding', 'test_native_output_window_binding'] if kind == 'lib'
             else ['test_native_output_window_observation'])
    suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name) for name in names)
    expected = 68 if kind == 'lib' else 13
    assert suite.countTestCases() == expected
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    passed = result.wasSuccessful() and result.testsRun == expected and not result.skipped
    d.verify_artifact(args.label, kind)
    assert d.identity(__file__) == own
    d.save(args.output, dict(status='passed' if passed else 'failed', suite=args.suite,
           expected=expected, tests=result.testsRun, failures=len(result.failures),
           errors=len(result.errors), skipped=len(result.skipped),
           artifact=artifact['artifact'], source_freeze=artifact['source_freeze'], helper=own))
    print(json.dumps(dict(status='passed' if passed else 'failed', tests=result.testsRun)))
    raise SystemExit(0 if passed else 1)


if __name__ == '__main__':
    main()
