"""Bind and exercise the current ordinary build's experimental-option refusal."""
import argparse
import gc
import json
from pathlib import Path
import shutil

from output_credit_window_driver_782 import E, W, P, RUSTUP, SAFE, identity, save, sha, verify
from output_credit_window_workflow_782 import load_native


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--label', required=True)
    parser.add_argument('--build', required=True)
    parser.add_argument('--name', required=True)
    args = parser.parse_args()
    assert all(SAFE.fullmatch(value) for value in (args.label, args.build, args.name))
    verify(args.label)
    receipt_path = E / f'{args.build}.json'
    log_path = E / f'{args.build}.log'
    receipt = json.loads(receipt_path.read_text())
    command = ['/usr/bin/env', f'PYO3_PYTHON={P}', 'PYO3_BUILD_EXTENSION_MODULE=1',
        RUSTUP, 'run', '1.99.0', 'cargo', 'build', '--locked', '--offline',
        '-p', 'shardloom-python', '--features', 'release-user-surfaces', '--lib', '--message-format=json']
    assert receipt['status'] == 'passed' and receipt['returncode'] == 0 and receipt['process_group_drained'] is True
    assert receipt['command'] == command and receipt['cwd'] == str(W)
    assert sha(log_path) == receipt['log_sha256']
    entries = [json.loads(line) for line in log_path.read_text().splitlines() if line.startswith('{')]
    candidates = [entry for entry in entries if entry.get('reason') == 'compiler-artifact'
                  and entry.get('target', {}).get('name') == '_native']
    assert len(candidates) == 1
    artifact = candidates[0]
    assert artifact['fresh'] is False and artifact['profile']['debug_assertions'] is True
    assert artifact['profile']['opt_level'] == '0' and artifact['profile']['test'] is False
    assert 'release-user-surfaces' in artifact['features']
    assert not {'output-window-candidate', 'output-window-observation'} & set(artifact['features'])
    libraries = [Path(path) for path in artifact['filenames'] if path.endswith('.dylib')]
    assert len(libraries) == 1
    destination = E / f'{args.name}-native.so'
    assert not destination.exists()
    shutil.copyfile(libraries[0], destination)
    assert sha(destination) == sha(libraries[0])
    native = load_native(destination)
    session = native.Session(native.ExecutionResources(64 << 20, 1))
    source = session.from_range('n', 0, 1, 17)
    plan = session.sql("SELECT n FROM 'memory://disabled'", sources=[('memory://disabled', source)])
    before = session.snapshot()
    try:
        plan.iter_batches(output_window_bytes=4 << 20)
    except ValueError as error:
        assert 'requires the experimental output-window-candidate feature' in str(error)
        rejection = str(error)
    else:
        raise AssertionError('ordinary build accepted the experimental request')
    assert session.snapshot() == before
    for arguments in ({}, {'output_window_bytes': 0}):
        with plan.iter_batches(**arguments) as stream:
            assert not hasattr(stream, 'output_window_observation')
            assert not hasattr(stream, '_output_window_sent_batches')
            assert [row for batch in stream for row in batch.row_export()] == [{'n': n} for n in range(17)]
            assert stream.report['columnar_export']['complete'] is True
        del stream
    plan.release_prepared()
    del plan, source
    gc.collect()
    assert session.snapshot()['reserved_bytes'] == 0
    session.close()
    verify(args.label)
    save(E / f'{args.name}-result.json', dict(status='passed', rejection=rejection,
        disabled_feature_pre_worker_refusal=True, ordinary_omission_and_zero_passed=True,
        final_reserved_bytes=0, artifact=identity(destination), compiler_artifact=artifact,
        build_receipt=identity(receipt_path), build_log=identity(log_path),
        source_freeze=identity(E / f'{args.label}-source-freeze.json'), helper=identity(__file__)))
    print(json.dumps(dict(status='passed', native_artifact_sha256=sha(destination))))


if __name__ == '__main__':
    main()
