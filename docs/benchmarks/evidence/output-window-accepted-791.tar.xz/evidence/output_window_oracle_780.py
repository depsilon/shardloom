"""Independent scalar oracle for the frozen output-window workload.

This module deliberately models only the protocol's fixture and query formulas.
It does not execute a ShardLoom plan or call any query engine.
"""

from __future__ import annotations

import struct
from collections.abc import Iterable
from typing import Any


_DERIVED_WIDTHS = {0, 8, 32}
_I64_MIN = -(1 << 63)
_I64_MAX = (1 << 63) - 1


def source_fields() -> list[dict[str, Any]]:
    """Return source schema in protocol order."""
    return [
        {"name": "k", "type": "int64", "nullable": True},
        {"name": "id", "type": "int64", "nullable": False},
        {"name": "x", "type": "int64", "nullable": True},
        {"name": "y", "type": "int64", "nullable": True},
    ]


def _cell_parts(cell: dict[str, Any]) -> tuple[str, int]:
    if not isinstance(cell, dict):
        raise TypeError("cell must be a mapping with plan and derived fields")
    plan = cell.get("plan")
    width = cell.get("derived")
    if plan not in {"project", "sort"}:
        raise ValueError(f"unsupported plan: {plan!r}")
    if isinstance(width, bool) or not isinstance(width, int) or width not in _DERIVED_WIDTHS:
        raise ValueError(f"invalid derived width: {width!r}")
    rows = cell.get("rows")
    if isinstance(rows, bool) or not isinstance(rows, int) or rows < 0:
        raise ValueError(f"invalid row count: {rows!r}")
    return plan, width


def output_fields(cell: dict[str, Any]) -> list[dict[str, Any]]:
    """Return the typed query output schema for a frozen workload cell."""
    _, width = _cell_parts(cell)
    return [
        {"name": "k", "type": "int64", "nullable": True},
        {"name": "id", "type": "int64", "nullable": False},
        *(
            {"name": f"d{j:03d}", "type": "int64", "nullable": True}
            for j in range(width)
        ),
    ]


def _row_index(r: int) -> int:
    if isinstance(r, bool) or not isinstance(r, int) or r < 0:
        raise ValueError(f"row index must be a nonnegative integer: {r!r}")
    return r


def source_row(r: int) -> tuple[int | None, int, int | None, int | None]:
    """Return source scalar values for original row ordinal ``r``."""
    r = _row_index(r)
    k = None if r % 31 == 0 else (r * 17 % 257) - 128
    x = None if r % 11 == 0 else (r * 13 % 100003) - 50001
    y = None if r % 17 == 0 else (r * 7 % 10007) - 5003
    return k, r, x, y


def output_row(cell: dict[str, Any], r: int) -> tuple[int | None, int, tuple[int | None, ...]]:
    """Return projected values while preserving SQL NULL arithmetic."""
    plan, width = _cell_parts(cell)
    if plan not in {"project", "sort"}:  # defensive if plan policy grows
        raise ValueError(f"unsupported plan: {plan!r}")
    k, row_id, x, y = source_row(r)
    derived = tuple(None if x is None or y is None else x * (j + 1) + y for j in range(width))
    return k, row_id, derived


def _scalar_bytes(value: int | None) -> bytes:
    if value is None:
        return b"\x00" + bytes(8)
    if isinstance(value, bool) or not isinstance(value, int) or not _I64_MIN <= value <= _I64_MAX:
        raise ValueError(f"value is not a signed I64 scalar: {value!r}")
    return b"\x01" + struct.pack("<q", value)


def _encode_rows(rows: Iterable[int], cell: dict[str, Any] | None) -> bytes:
    encoded = bytearray()
    if cell is None:
        for r in rows:
            for value in source_row(r):
                encoded.extend(_scalar_bytes(value))
        return bytes(encoded)

    plan, _ = _cell_parts(cell)
    output = [output_row(cell, r) for r in rows]
    if plan == "sort":
        # Python's sort is stable; only k participates, with NULLS LAST.
        output.sort(key=lambda row: (row[0] is None, 0 if row[0] is None else row[0]))
    for k, row_id, derived in output:
        for value in (k, row_id, *derived):
            encoded.extend(_scalar_bytes(value))
    return bytes(encoded)


def source_bytes(rows: Iterable[int]) -> bytes:
    """Encode source rows as validity byte plus little-endian I64 per scalar."""
    return _encode_rows(rows, None)


def expected_bytes(cell: dict[str, Any], rows: Iterable[int]) -> bytes:
    """Encode expected query output in row-major scalar format."""
    return _encode_rows(rows, cell)
