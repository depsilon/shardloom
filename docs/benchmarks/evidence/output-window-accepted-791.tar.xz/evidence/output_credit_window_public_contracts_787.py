"""Run the existing complete native binding contract against one bound library."""
import argparse
import json
import os
import sys
import unittest
from output_credit_window_driver_782 import W, identity, save, verify_artifact


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--label',required=True)
    parser.add_argument('--output',required=True)
    args=parser.parse_args()
    artifact=verify_artifact(args.label,'lib')
    os.environ['SHARDLOOM_REQUIRE_NATIVE_PYTHON']='1'
    os.environ['SHARDLOOM_NATIVE_TEST_LIBRARY']=artifact['artifact']['path']
    os.environ['SHARDLOOM_OUTPUT_WINDOW_OBSERVATION']='trace'
    sys.path[:0]=[str(W/'python/src'),str(W/'python/tests')]
    import test_native_binding
    suite=unittest.defaultTestLoader.loadTestsFromModule(test_native_binding)
    expected=suite.countTestCases()
    assert expected == 62
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    passed=result.wasSuccessful() and result.testsRun==expected and not result.skipped
    verify_artifact(args.label,'lib')
    save(args.output,dict(status='passed' if passed else 'failed',expected=expected,tests=result.testsRun,
                         errors=len(result.errors),failures=len(result.failures),skipped=len(result.skipped),
                         native_artifact=artifact['artifact'],driver=identity(__file__),
                         tests_source=identity(W/'python/tests/test_native_binding.py')))
    raise SystemExit(0 if passed else 1)


if __name__=='__main__':
    main()

