"""Recover build binding using the successful compiler's recorded environment."""
import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys

OUT = Path(__file__).resolve().parent
original = OUT / 'output_window_acceptance_789.py'
sys.argv = [str(original), 'verify']
acceptance = runpy.run_path(str(original), run_name='__main__')
d = acceptance['d']
verify = acceptance['verify']
identity = acceptance['identity']
digest = acceptance['digest']
source = verify()
build_path = acceptance['BUILD']
artifacts = acceptance['ARTIFACTS']
assert not build_path.exists()
assert artifacts.is_dir() and not list(artifacts.iterdir())
receipt_path = OUT / 'output-window-public-cli-build-789.json'
log = OUT / 'output-window-public-cli-build-789.log'
receipt = json.loads(receipt_path.read_text())
command = [d.RUSTUP, 'run', '1.99.0', 'cargo', 'build', '--release', '--offline', '--locked',
           '-p', 'shardloom-cli', '--features', 'release-user-surfaces',
           '--message-format=json-render-diagnostics']
assert receipt['command'] == command
assert receipt['status'] == 'passed' and receipt['returncode'] == 0
assert receipt['process_group_drained'] and receipt['direct_child_reaped']
assert receipt['cwd'] == str(d.W) and receipt['head'] == source['source_commit']
assert receipt['working_tree'].strip() == source['working_tree']
assert receipt['driver_sha256'] == digest(d.GUARD)
assert receipt['log_sha256'] == digest(log)
messages = [json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
candidates = [row for row in messages if row.get('reason') == 'compiler-artifact'
              and row.get('target', {}).get('name') == 'shardloom' and row.get('executable')]
assert len(candidates) == 1
compiler = candidates[0]
assert compiler['fresh'] is False and compiler['profile']['opt_level'] == '3'
assert compiler['profile']['test'] is False
assert 'release-user-surfaces' in compiler['features']
assert 'output-window-observation' not in compiler['features']
executable = Path(compiler['executable']).resolve(strict=True)
environment = dict(os.environ, **receipt['environment'])
metadata_command = [d.RUSTUP, 'run', '1.99.0', 'cargo', 'metadata', '--offline', '--locked',
                    '--no-deps', '--format-version', '1']
metadata = json.loads(subprocess.check_output(metadata_command, cwd=d.W, env=environment))
target = Path(metadata['target_directory']).resolve(strict=True)
assert str(target) == receipt['environment']['CARGO_TARGET_DIR']
assert executable.is_relative_to(target)
assert executable in [Path(name).resolve(strict=True) for name in compiler['filenames']]
origin = identity(executable)
binary = artifacts / 'shardloom'
shutil.copy2(executable, binary)
assert digest(binary) == origin['sha256']
binding = d.verify_artifact(acceptance['LABEL'], 'lib')
assert binding['profile'] == 'release'
library = artifacts / '_native.abi3.so'
shutil.copy2(binding['artifact']['path'], library)
assert digest(library) == binding['artifact']['sha256']
assert verify() == source
correction = dict(
    status='passed', original_helper=identity(original), recovery_helper=identity(__file__),
    original_attempt=dict(compiler_build_status='passed', acceptance_binding_status='failed',
        exception='AssertionError', failing_line=105,
        reason='Post-build cargo metadata omitted the guard CARGO_TARGET_DIR environment; no artifact was bound.'),
    metadata_command=metadata_command, metadata_environment=receipt['environment'],
    resolved_target_directory=str(target), compiler_origin=origin,
    rebuild_required=False, all_source_and_artifact_checks_preserved=True)
correction_path = OUT / 'output-window-build-binding-correction-791.json'
d.save(correction_path, correction)
d.save(build_path, dict(source, binary=str(binary), binary_sha256=digest(binary),
    native_library=identity(library), native_build=binding,
    build_receipts=dict(cli=dict(receipt=identity(receipt_path), log=identity(log)),
                        binding=binding['build_receipt']),
    source_manifest=identity(acceptance['SOURCE']), cli_compiler_artifact=compiler,
    build_binding_correction=identity(correction_path), publication_attempted=False))
assert verify() == source
print(json.dumps(dict(status='passed', binary=identity(binary), native_library=identity(library))))
