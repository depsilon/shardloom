"""Finish serial integration gates with unchanged final runtime sources."""
import json
import re
import subprocess

import output_window_integration_789 as d

LABEL = 'output-credit-window-integrated-790-a4'
OLD = 'output-credit-window-integrated-789-a3'
PREFIX = 'output-credit-window'


def verify():
    d.verify(LABEL)
    continuity = json.loads((d.E / 'output-window-source-continuity-790.json').read_text())
    assert continuity['status'] == 'passed' and continuity['runtime_sources_byte_identical']
    assert continuity['after'] == d.identity(d.E / f'{LABEL}-source-freeze.json')
    for row in continuity['original_artifact_records']:
        assert d.identity(row['path']) == row


def receipt(name, command=None):
    path = d.E / f'{name}.json'
    row = json.loads(path.read_text())
    assert row['status'] == 'passed' and row['returncode'] == 0
    assert row['process_group_drained'] and row['direct_child_reaped']
    assert row['head'] == d.HEAD and row['cwd'] == str(d.W)
    if command is not None:
        assert row['command'] == command
        assert row['working_tree'] == d.git('status', '--porcelain')
    log = d.E / f'{name}.log'
    assert d.sha(log) == row['log_sha256']
    return dict(name=name, receipt=d.identity(path), log=d.identity(log))


def counts(row):
    text = (d.E / f"{row['name']}.log").read_text()
    summaries = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    assert summaries and all(int(failed) == 0 for _, failed, _ in summaries)
    row.update(passed=sum(int(p) for p, _, _ in summaries),
               ignored=sum(int(i) for _, _, i in summaries), test_targets=len(summaries))
    assert row['passed'] > 0
    return row


verify()
native = d.verify_artifact(LABEL, 'test')
native_all = counts(receipt('output-credit-window-integrated-native-all-790-a4'))
assert native_all['passed'] + native_all['ignored'] == sum(
    line.endswith(': test') for line in open(native['inventory']['path']).read().splitlines())
assert d.identity(native['inventory']['path']) == native['inventory']
assert native['profile'] == 'release'
assert native['source_freeze'] == d.identity(d.E / f'{LABEL}-source-freeze.json')
native_all['artifact'] = d.identity(d.E / f'{LABEL}-test-artifact.json')
partial_path = d.E / 'output-credit-window-integrated-native-all-789-a3.json'
partial = json.loads(partial_path.read_text())
assert partial['status'] == 'failed' and partial['interrupted_signal'] == 2 and not partial['timed_out']
assert partial['process_group_drained'] and partial['direct_child_reaped']
assert partial['log_sha256'] == d.sha(d.E / 'output-credit-window-integrated-native-all-789-a3.log')
checks = [native_all]
for suffix, kind, count in [('release', 'lib', 68), ('observation', 'observed', 13)]:
    result_path = d.E / f'output-credit-window-integrated-{suffix}-result-789-a3.json'
    result = json.loads(result_path.read_text())
    artifact = d.verify_artifact(LABEL, kind)
    assert result['status'] == 'passed' and result['tests'] == result['expected'] == count
    assert result['failures'] == result['errors'] == result['skipped'] == 0
    assert result['artifact'] == artifact['artifact']
    assert result['source_freeze'] == artifact['compiled_source_freeze']
    row = receipt(f'output-credit-window-integrated-{suffix}-tests-789-a3')
    row.update(result=d.identity(result_path), tests=count, skipped=0,
               source_continuity=d.identity(d.E / 'output-window-source-continuity-790.json'))
    checks.append(row)

commands = [
    ('workspace-fmt', ['cargo', 'fmt', '--all', '--', '--check']),
    ('workspace-clippy', ['cargo', 'clippy', '--offline', '--locked', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('workspace-tests', ['cargo', 'test', '--offline', '--locked', '--workspace', '--all-targets']),
    ('native-cli', ['cargo', 'test', '--offline', '--locked', '-p', 'shardloom-cli', '--lib', '--bin', 'shardloom',
        '--test', 'vortex_prepare', '--test', 'public_memory_inputs', '--test', 'public_workflow_route',
        '--test', 'resident_worker', '--features', 'release-user-surfaces', '--', '--test-threads=1']),
    ('python-source', [d.P, '-B', '-m', 'unittest', 'discover', '-s', 'python/tests', '-v']),
    ('public-reference', [d.P, '-B', 'scripts/write_public_api_reference.py', '--check']),
    ('user-surface', [d.P, '-B', 'scripts/check_user_surface_reference.py']),
    ('python-exports', [d.P, '-B', 'scripts/write_python_api_exports.py', '--check']),
    ('ci-matrix', [d.P, '-B', 'scripts/check_ci_gate_matrix.py', '--output', str(d.E / 'output-window-ci-matrix-report-790.json')]),
    ('api-schema', [d.P, '-B', 'scripts/check_v1_api_schema_stability.py', '--output', str(d.E / 'output-window-api-schema-report-790.json')]),
]
for suffix, command in commands:
    verify()
    name = f'{PREFIX}-{suffix}-790'
    if not (d.E / f'{name}.json').exists():
        subprocess.run([d.P, '-B', str(d.GUARD), '--name', name, '--timeout', '3600', '--', *command],
                       cwd=d.W, check=True)
    verify()
    row = receipt(name, command)
    if suffix in ('workspace-tests', 'native-cli'):
        counts(row)
        assert row['ignored'] == 0
    if suffix == 'python-source':
        log = (d.E / f'{name}.log').read_text()
        matches = re.findall(r'Ran (\d+) tests? in [\d.]+s', log)
        assert len(matches) == 1 and int(matches[0]) > 0
        assert re.search(r'^OK(?: \(skipped=\d+\))?$', log, re.M)
        skipped = re.search(r'^OK \(skipped=(\d+)\)$', log, re.M)
        row.update(tests=int(matches[0]), skipped=int(skipped[1]) if skipped else 0,
                   native_extension_verified_separately=True)
    checks.append(row)

# The targeted strict native lint ran before Python validator/doc-only changes.
prior = json.loads((d.E / 'output-credit-window-integrated-789-a1-source-freeze.json').read_text())
current = d.verify(LABEL)
def rust_inputs(frozen):
    return {row['path']: (row['bytes'], row['sha256']) for row in frozen['sources']
            if row['path'].endswith(('.rs', '.toml')) or row['path'].endswith('Cargo.lock')}
assert rust_inputs(prior) == rust_inputs(current)
lint = receipt('output-credit-window-integrated-clippy-789-a1')
lint['rust_inputs_byte_identical_to_final'] = True
lint['compiled_source_freeze'] = d.identity(d.E / 'output-credit-window-integrated-789-a1-source-freeze.json')
checks.append(lint)
verify()
d.save(d.E / 'output-window-integration-gates-789.json', dict(status='passed',
    source_freeze=d.identity(d.E / f'{LABEL}-source-freeze.json'),
    source_continuity=d.identity(d.E / 'output-window-source-continuity-790.json'),
    checks=checks, helper=d.identity(__file__),
    interrupted_debug_suite=dict(receipt=d.identity(partial_path),
        log=d.identity(d.E / 'output-credit-window-integrated-native-all-789-a3.log'),
        complete_pass_claimed=False,
        reason='Intentionally stopped the unoptimized broad pressure suite; full native acceptance uses the same optimized test profile as prior acceptance.')))
print(json.dumps(dict(status='passed', checks=[{k: row[k] for k in ('name', 'passed', 'ignored', 'tests', 'skipped', 'test_targets') if k in row} for row in checks])), flush=True)
