<!-- SPDX-License-Identifier: Apache-2.0 -->

# Native output-window integration

Status: integration and acceptance in progress after the finite comparison.
This is not a completed conditional decision or a package-release claim.

The frozen [two-batch design](native-two-batch-output-window-design-2026-10-19.md)
passes both comparison cohorts: the single predeclared target meets its benefit
gate, and all ten cells pass correctness, activation, memory and regression
controls. Both cohorts completed before inspection. The independently reopened
packet `output-credit-window-788.tar.xz`, SHA-256
`f4c936271e0470944c73c0bfa7d80000ca5e9b058d14446ac6c229f10bbe1316`, preserves
3,213 members, all 11 attribution/candidate source versions, 462 complete IPC
witness files, 63 guarded receipts and the exact compiled identities. It also
preserves failed attempts and the original protocols. Full acceptance remains
required.

## Integration boundary

Promote the unchanged two-slot ledger and actual-plan admission into the existing
native Arrow-delivery feature boundary. Remove the temporary
`output-window-candidate` build switch. Keep observation instrumentation behind
the separate opt-in `output-window-observation` feature, absent from normal
packages. There is no new dependency or provider. The Vortex-first classification
remains `use_vortex_native_provider`: Vortex 0.85.0 native memory sources, execution
and existing Arrow boundary leases; logical consumer demand belongs to ShardLoom.

The native Python plan and the public SQL/DataFrame `iter_batches` methods accept
`output_window_bytes=0` or `4194304`, defaulting to zero. Invalid types and sizes
fail before source demand. The public subprocess transport rejects a nonzero
request before starting work. This integration adds no CLI transport window.

The public adapter forwards the explicit request to the same native operation;
it adds no queue, materialization, source preparation or alternate execution.
Public `batch_rows` continues to slice native delivery batches and acknowledges
the preceding native batch only when it requests the next native batch. Aliases
and slices retain their existing native payload leases independently of those
logical acknowledgments.

The final report adds two string fields:

- `columnar_output_window_requested_bytes`: `0` or `4194304`.
- `columnar_output_window_selected_policy`: `ordinary_not_requested`,
  `ordinary_ineligible` or `two_batch_window`.

These fields are available only with the successful final report. They do not
turn an enqueue or provisional batch into completion. Other plan/source classes
retain ordinary demand when a window is requested and report their ineligibility.

## Unchanged algorithm and proof obligations

Keep the exact frozen admission: actual immutable memory scan or one projection,
0–65,536 rows, 1–64 Int64 output fields, no filter/residual, nested operator,
file/preparation, producer declaration, dynamic/parameterized input or spill.
Keep the original grant, 1,024-byte metadata reservation, one-event channel,
two unacknowledged batches, 2-MiB per-batch and 4-MiB total referenced-byte limits,
FIFO acknowledgments and final-callback barrier. No workload threshold, queue
depth, algorithm or comparison criterion is changed after the measurements.

Integration changes are feature promotion, explicit public argument forwarding,
completed-policy evidence and durable tests/docs. The comparison describes the
frozen instrumented implementation, not a new measurement of the final package.
Do not add selected cohorts or reinterpret the result as an engine speed gain.

Diagnostic timing remains scoped to the relational batch producer, including a
primitive declaration that uses that producer. Other primitive providers retain
ordinary delivery; their opt-in observation is not a valid relational timing
sample. Their completed policy fields remain available. Normal packages contain
neither observation getters nor environment-controlled capture.

Acceptance must bind the final source and fresh artifacts; cover all original
ledger/admission/failure/lifetime checks; test normal builds without diagnostic
getters and an explicit diagnostic build; exercise public slicing, laziness,
retained owners, invalid requests and subprocess refusal; and run the required
workspace/native, clean installed Python, Public39, Full43 and modular checks.
Any failed acceptance is retained and repaired or causes the candidate to be
withdrawn. The broader PERF-07 owner, remaining investigations, CG-1 through
CG-23 and release authorization remain separate.
