"""Independent mutation and boundary tests for the frozen credit-window verifier.

Only recorded smoke evidence and synthetic timing records are read. No native
query or native library is executed by this test module.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import unittest

import analyze_output_credit_window_787 as analyzer

E = Path(__file__).parent
DATA = E / 'output-credit-window-debug-smoke-787-a1'
ARTIFACT = json.loads((E / 'output-credit-window-debug-lib-787-a1-lib-artifact.json').read_text())


def first_record(role='ack', cell_id=None):
    records = [json.loads(line) for line in (DATA / f'smoke-{role}-smoke.jsonl').read_text().splitlines()]
    if cell_id is None:
        return records[0]
    return max((record for record in records if record['cell'] == cell_id), key=lambda row: row['actual_rows'])


def cell_for(cell_id):
    return next(cell for cell in json.loads(analyzer.PROTOCOL.read_text())['workload']['cells'] if cell['id'] == cell_id)


def valid_record(record):
    return analyzer.check_record(DATA, record, cell_for(record['cell']), record['actual_rows'],
        record['role'], ARTIFACT['source_freeze']['sha256'], ARTIFACT['artifact']['sha256'])


def synthetic_observation(role='window', eligible=True):
    active = role == 'window' and eligible
    batches = [
        dict(rows=2, callback_succeeded=True, callback_enter_ns=2000, converted_ready_ns=2200,
             send_complete_ns=2500, acknowledged_ns=7000 if active else 3500, callback_exit_ns=4000,
             referenced_arrow_bytes=32),
        dict(rows=2, callback_succeeded=True, callback_enter_ns=5000, converted_ready_ns=5600,
             send_complete_ns=5800, acknowledged_ns=9000 if active else 7000, callback_exit_ns=7300,
             referenced_arrow_bytes=64),
        dict(rows=2, callback_succeeded=True, callback_enter_ns=8000, converted_ready_ns=8100,
             send_complete_ns=8400, acknowledged_ns=9200 if active else 9000, callback_exit_ns=9500,
             referenced_arrow_bytes=48),
    ]
    return dict(schema_version='shardloom.output_window_observation.v2', mode='trace', valid=True, error=None,
        operation_succeeded=True, engine_succeeded=True, engine_calls=1,
        clock_boundary='prepared_native_call_excluding_synchronous_conversion_and_consumer_wait',
        storage_scope='bounded_caller_diagnostics_outside_native_grant_not_rss',
        maximum_observation_batches=128, batch_count=3, output_rows=6,
        ready_count=3, sent_count=3, acknowledged_count=3, engine_start_ns=1000, engine_end_ns=10000,
        native_call_elapsed_ns=9000, engine_execution_ns=3200, synchronous_sink_ns=5800,
        maximum_batch_referenced_arrow_bytes=64, batches=batches,
        window=dict(requested=role == 'window', initialized=True, released=True,
            eligible=eligible if role == 'window' else None, expected_rows=6 if active else None,
            selected_policy='two_batch_window' if active else (
                'ordinary_ineligible' if role == 'window' else 'ordinary_not_requested'),
            metadata_reserved_bytes=1024 if active else 0, metadata_final_bytes=0,
            outstanding_batches=0, outstanding_referenced_bytes=0, abandoned_batches=0,
            abandoned_referenced_bytes=0, maximum_unacknowledged_batches=2 if active else 1,
            maximum_unacknowledged_referenced_bytes=112 if active else 64))


def qualified_metrics(cells):
    result = {}
    for cell in cells:
        for cohort in ('A', 'B'):
            for role in ('ack', 'window'):
                row = dict(engine_ns=10_000_000, complete_ns=100_000_000,
                           first_provisional_ns=5_000_000, lifetime_peak_native_bytes=8_000_000)
                if role == 'window' and cell['target']:
                    row['complete_ns'] = 85_000_000
                result[(cell['id'], cohort, role)] = [dict(row) for _ in range(3)]
    return result


class TraceAndThresholdTests(unittest.TestCase):
    def test_engine_clock_and_actual_window_high_water(self):
        for role, eligible in (('ack', True), ('window', True), ('window', False)):
            with self.subTest(role=role, eligible=eligible):
                value = analyzer.check_observation(synthetic_observation(role, eligible),
                    role, eligible, 6, [2, 2, 2], 20_000)
                self.assertEqual(value['engine_ns'], 3200)
                self.assertEqual(value['maximum_unacknowledged_batches'], 2 if role == 'window' and eligible else 1)

    def test_mutations_reject_fabricated_acknowledgment_and_memory_evidence(self):
        mutations = [
            lambda o: o.update(valid=False), lambda o: o.update(operation_succeeded=False),
            lambda o: o.update(engine_succeeded=False), lambda o: o.update(engine_calls=2),
            lambda o: o.update(synchronous_sink_ns=5799), lambda o: o.update(acknowledged_count=2),
            lambda o: o['batches'][0].update(callback_enter_ns=2400),
            lambda o: o['batches'][1].update(rows=3), lambda o: o['batches'][2].update(callback_succeeded=False),
            lambda o: o['batches'][0].update(acknowledged_ns=3500),
            lambda o: o['batches'][0].update(acknowledged_ns=8000),
            lambda o: o['batches'][2].update(acknowledged_ns=10001),
            lambda o: o['window'].update(maximum_unacknowledged_batches=1),
            lambda o: o['window'].update(maximum_unacknowledged_referenced_bytes=96),
            lambda o: o['window'].update(metadata_reserved_bytes=0),
            lambda o: o['window'].update(metadata_final_bytes=1024),
            lambda o: o['window'].update(outstanding_batches=1),
            lambda o: o['window'].update(outstanding_referenced_bytes=32),
            lambda o: o['window'].update(abandoned_batches=1),
            lambda o: o['window'].update(abandoned_referenced_bytes=32),
            lambda o: o['window'].update(expected_rows=7),
            lambda o: o['window'].update(eligible=False),
            lambda o: o['window'].update(released=False),
            lambda o: o.update(mode='clock'), lambda o: o.update(batches=[]),
        ]
        for index, mutate in enumerate(mutations):
            value = synthetic_observation()
            mutate(value)
            with self.subTest(index=index), self.assertRaises(AssertionError):
                analyzer.check_observation(value, 'window', True, 6, [2, 2, 2], 20_000)

    def test_ordinary_policy_cannot_hide_late_acknowledgment(self):
        value = synthetic_observation('ack')
        value['batches'][0]['acknowledged_ns'] = 7000
        with self.assertRaises(AssertionError):
            analyzer.check_observation(value, 'ack', True, 6, [2, 2, 2], 20_000)

    def test_thresholds_require_both_strict_excesses(self):
        for reference, observed in ((100_000_000, 105_000_000), (20_000_000, 21_000_000),
                                    (100_000, 106_000), (100_000_000, 101_000_001)):
            self.assertFalse(analyzer.regression(reference, observed))
        self.assertTrue(analyzer.regression(20_000_000, 21_000_001))


class DecisionGateTests(unittest.TestCase):
    def setUp(self):
        self.cells = json.loads(analyzer.PROTOCOL.read_text())['workload']['cells']
        self.target = next(cell['id'] for cell in self.cells if cell['target'])

    def test_requires_all_cells_three_samples_and_both_cohorts(self):
        metrics = qualified_metrics(self.cells)
        metrics[(self.cells[-1]['id'], 'B', 'window')].pop()
        with self.assertRaises(AssertionError):
            analyzer.decide(self.cells, metrics)

    def test_passing_finite_comparison_does_not_claim_full_acceptance(self):
        result = analyzer.decide(self.cells, qualified_metrics(self.cells))
        self.assertEqual(result['decision'], 'retain_candidate_pending_full_acceptance')
        self.assertTrue(result['finite_comparison_passed'])
        for key in ('full_acceptance_completed', 'broader_owner_closed', 'competitive_gates_closed'):
            self.assertFalse(result[key])

    def test_target_benefit_requires_both_cohorts_and_both_inclusive_thresholds(self):
        for baseline, candidate, accepted in (
                (50_000_000, 45_000_000, True), (50_000_000, 45_000_001, False),
                (40_000_000, 35_000_001, False), (100_000_000, 90_000_001, False)):
            metrics = qualified_metrics(self.cells)
            for row in metrics[(self.target, 'B', 'ack')]:
                row['complete_ns'] = baseline
            for row in metrics[(self.target, 'B', 'window')]:
                row['complete_ns'] = candidate
            with self.subTest(baseline=baseline, candidate=candidate):
                self.assertIs(analyzer.decide(self.cells, metrics)['finite_comparison_passed'], accepted)

    def test_any_control_regression_rejects_all_three_clock_types(self):
        for key in ('engine_ns', 'complete_ns', 'first_provisional_ns'):
            metrics = qualified_metrics(self.cells)
            for row in metrics[(self.cells[-1]['id'], 'B', 'window')]:
                row[key] += max(row[key] // 10, 1_000_001)
            with self.subTest(key=key):
                result = analyzer.decide(self.cells, metrics)
                self.assertFalse(result['finite_comparison_passed'])
                self.assertEqual(result['regression_failures'][0]['metrics'], [key])

    def test_native_peak_delta_includes_exact_metadata_allowance(self):
        for extra, accepted in ((0, True), (1, False)):
            metrics = qualified_metrics(self.cells)
            for row in metrics[(self.cells[-1]['id'], 'B', 'window')]:
                row['lifetime_peak_native_bytes'] += (4 << 20) + 1024 + extra
            with self.subTest(extra=extra):
                self.assertIs(analyzer.decide(self.cells, metrics)['finite_comparison_passed'], accepted)

    def test_one_sample_over_original_grant_is_invalid(self):
        metrics = qualified_metrics(self.cells)
        metrics[(self.target, 'B', 'window')][0]['lifetime_peak_native_bytes'] = (64 << 20) + 1
        with self.assertRaises(AssertionError):
            analyzer.decide(self.cells, metrics)

    def test_control_gains_cannot_replace_missing_target_gain(self):
        metrics = qualified_metrics(self.cells)
        for cell in self.cells:
            for cohort in ('A', 'B'):
                for row in metrics[(cell['id'], cohort, 'window')]:
                    row['complete_ns'] = 100_000_000 if cell['target'] else 20_000_000
        result = analyzer.decide(self.cells, metrics)
        self.assertFalse(result['finite_comparison_passed'])
        self.assertTrue(all(not row['passed'] for row in result['target_benefits']))

    def test_frozen_workflow_count_order_and_warmup_target(self):
        smoke = analyzer.expected_matrix(self.cells, 'smoke', 'smoke')
        self.assertEqual(len(smoke), 21)
        self.assertEqual(smoke[-1][0]['id'], self.target)
        self.assertEqual(len(analyzer.expected_matrix(self.cells, 'preflight', 'preflight')), 30)
        for cohort in ('A', 'B'):
            matrix = analyzer.expected_matrix(self.cells, 'measure', cohort)
            self.assertEqual(len(matrix), 31)
            self.assertEqual(matrix[0][0]['id'], self.target)
            self.assertEqual(matrix[0][-2:], (-1, True))
            self.assertEqual(matrix[1][0]['id'], self.cells[0 if cohort == 'A' else -1]['id'])

class RecordedWorkflowRegressionTests(unittest.TestCase):
    def test_actual_complete_debug_record_passes(self):
        record = first_record("ack", 'project-32768-8-zstd')
        metrics = valid_record(record)
        self.assertGreater(metrics["complete_ns"], 0)

    def test_actual_workflow_mutations_are_rejected(self):
        def mutate_engine_calls(record):
            record["observation"]["engine_calls"] = 2

        def mutate_valid(record):
            record["observation"]["valid"] = False

        def mutate_success(record):
            record["observation"]["operation_succeeded"] = False

        def mutate_engine_sink_sum(record):
            record["observation"]["engine_execution_ns"] += 1

        def mutate_ack_count(record):
            record["observation"]["acknowledged_count"] += 1

        def mutate_output_rows(record):
            record["report"]["output_row_count"] = str(record["actual_rows"] + 1)

        def mutate_schema_nullable(record):
            # bool is intentionally not accepted as an integer-like nullability value.
            record["batch_schemas"][0][0]["nullable"] = 1

        def mutate_source_schema(record):
            record["source_schema_json"] = "{}"

        def mutate_final_reservations(record):
            record["snapshots"]["retired"]["reserved_bytes"] = 1

        def mutate_denied_reservation(record):
            record["snapshots"]["retired"]["denied_reservations"] = 1

        def mutate_file_open(record):
            record["report"]["resident_source_opens"] = "1"

        def mutate_extra_execution(record):
            record["report"]["resident_completed_executions"] = "2"

        def mutate_provider_workers(record):
            record["report"]["resident_provider_background_workers"] = "1"

        def mutate_fallback(record):
            record["report"]["fallback_attempted"] = "true"

        def mutate_incomplete_report(record):
            record["report"]["columnar_export"]["complete"] = False

        def mutate_missing_witness(record):
            record["source_witness"]["path"] = "witnesses/missing.arrow"

        def mutate_witness_digest(record):
            record["source_witness"]["sha256"] = "0" * 64

        def mutate_source_identity(record):
            record["source_freeze_sha256"] = "0" * 64

        def mutate_artifact_identity(record):
            record["native_artifact_sha256"] = "0" * 64

        cases = [
            ("ack", "project-32768-8-zstd", mutate_engine_calls),
            ("ack", "project-32768-8-zstd", mutate_valid),
            ("ack", "project-32768-8-zstd", mutate_success),
            ("window", "project-32768-8-zstd", mutate_engine_sink_sum),
            ("ack", "project-32768-8-zstd", mutate_ack_count),
            ("ack", "project-32768-8-zstd", mutate_output_rows),
            ("ack", "project-32768-8-zstd", mutate_schema_nullable),
            ("ack", "project-32768-8-zstd", mutate_source_schema),
            ("ack", "project-32768-8-zstd", mutate_final_reservations),
            ("ack", "project-32768-8-zstd", mutate_denied_reservation),
            ("ack", "project-32768-8-zstd", mutate_file_open),
            ("ack", "project-32768-8-zstd", mutate_extra_execution),
            ("ack", "project-32768-8-zstd", mutate_provider_workers),
            ("ack", "project-32768-8-zstd", mutate_fallback),
            ("ack", "project-32768-8-zstd", mutate_incomplete_report),
            ("ack", "project-32768-8-zstd", mutate_missing_witness),
            ("ack", "project-32768-8-zstd", mutate_witness_digest),
            ("ack", "project-32768-8-zstd", mutate_source_identity),
            ("ack", "project-32768-8-zstd", mutate_artifact_identity),
        ]
        for mode, cell_id, mutate in cases:
            record = deepcopy(first_record(mode, cell_id))
            mutate(record)
            with self.subTest(case=mutate.__name__), self.assertRaises((AssertionError, ValueError, OSError)):
                valid_record(record)

    def test_sort_sql_semantics_are_checked(self):
        record = deepcopy(first_record("ack", "sort-65536-32-zstd"))
        record["sql"] = record["sql"].replace("ORDER BY k ASC NULLS LAST", "ORDER BY k DESC")
        with self.assertRaises(AssertionError):
            valid_record(record)

    def test_source_schema_boolean_cannot_be_replaced_by_integer(self):
        record = deepcopy(first_record('ack', 'project-32768-8-zstd'))
        schema = json.loads(record['source_schema_json'])
        schema['Struct'][0]['dtypes'][1]['Primitive'][1] = 0
        record['source_schema_json'] = json.dumps(schema)
        with self.assertRaises(AssertionError):
            valid_record(record)

    def test_complete_value_check_rejects_well_formed_rehashed_wrong_ipc_value(self):
        record = deepcopy(first_record('ack', 'project-32768-8-zstd'))
        with tempfile.TemporaryDirectory(dir=E, prefix='output-window-witness-test-') as directory:
            root = Path(directory)
            (root/'witnesses').mkdir()
            for witness in [record['source_witness'], *record['output_witnesses']]:
                shutil.copyfile(DATA/witness['path'], root/witness['path'])
            first = record['output_witnesses'][0]
            batch = next(analyzer.pa.ipc.open_stream((root/first['path']).read_bytes()))
            values = batch.column(1).to_pylist()
            values[1] = 9999
            arrays = list(batch.columns)
            arrays[1] = analyzer.pa.array(values, type=analyzer.pa.int64())
            altered = analyzer.pa.RecordBatch.from_arrays(arrays, schema=batch.schema)
            sink = analyzer.pa.BufferOutputStream()
            with analyzer.pa.ipc.new_stream(sink, altered.schema) as writer:
                writer.write_batch(altered)
            payload = bytes(sink.getvalue())
            digest = hashlib.sha256(payload).hexdigest()
            path = f'witnesses/{digest}.arrow'
            (root/path).write_bytes(payload)
            record['output_witnesses'][0] = dict(path=path, sha256=digest, bytes=len(payload))
            with self.assertRaises(AssertionError):
                analyzer.check_record(root,record,cell_for(record['cell']),record['actual_rows'],'ack',
                    ARTIFACT['source_freeze']['sha256'],ARTIFACT['artifact']['sha256'])

    def test_repeated_cached_decode_still_checks_current_raw_file_identity(self):
        record = first_record('ack', 'project-32768-8-zstd')
        witness = record['source_witness']
        with tempfile.TemporaryDirectory(dir=E, prefix='output-window-witness-test-') as directory:
            root = Path(directory)
            (root/'witnesses').mkdir()
            target = root/witness['path']
            shutil.copyfile(DATA/witness['path'], target)
            analyzer.decoded(root,witness)
            target.write_bytes(b'corrupt')
            with self.assertRaises(AssertionError):
                analyzer.decoded(root,witness)


if __name__ == "__main__":
    unittest.main()

