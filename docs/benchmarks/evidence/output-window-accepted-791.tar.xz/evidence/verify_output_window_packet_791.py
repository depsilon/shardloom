"""Independently verify every archived byte and complete integrated source map."""
import gzip
import hashlib
import io
import json
import lzma
from pathlib import Path
import tarfile

import output_window_integration_789 as d

E = d.E
PACK = E / 'output-window-accepted-portable-791'
NAME = 'output-window-accepted-791'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha)


def main():
    d.verify('output-credit-window-integrated-790-a4')
    index = json.loads((PACK / (NAME + '.json')).read_text())
    assert index['status'] == 'passed' and index['production_accepted'] is True
    assert index['decision'] == 'finite_two_batch_output_window_retained'
    for key in ('archive', 'manifest', 'final_acceptance'):
        assert identity(index[key]['path']) == index[key]
    manifest = json.loads(lzma.decompress(Path(index['manifest']['path']).read_bytes()))
    rows = manifest['members']
    names = [row['path'] for row in rows]
    assert names == sorted(set(names)) and len(names) == index['member_count']
    by_name = {row['path']: row for row in rows}
    guards, compressed_public, version_counts, helper_count = 0, 0, {}, 0
    kept = {}
    with tarfile.open(index['archive']['path'], 'r:xz') as archive:
        assert [member.name for member in archive.getmembers()] == names

        def raw(name):
            member = archive.getmember(name)
            assert member.isfile()
            payload = kept[name]
            row = by_name[name]
            assert len(payload) == row['bytes'] and digest(payload) == row['sha256']
            return payload

        def read(name):
            return json.loads(raw(name))

        # Sequential full read verifies safety, all member hashes and original
        # files without retaining all public envelope bytes in memory.
        for member in archive:
            row = by_name[member.name]
            assert member.isfile() and member.size == row['bytes']
            assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            payload = archive.extractfile(member).read()
            assert digest(payload) == row['sha256']
            if member.name.endswith(('.json', '.gz', '.xz', '.patch')):
                kept[member.name] = payload
            if not row['original_path'].startswith('generated:'):
                assert identity(row['original_path']) == dict(path=row['original_path'], bytes=row['bytes'], sha256=row['sha256'])
            if member.name.startswith('sources/blobs/'):
                assert digest(payload) == Path(member.name).name
        # The embedded finite comparison is itself a complete verified packet,
        # including all attribution/candidate sources and 462 IPC witnesses.
        prefix = 'evidence/output-credit-window-portable-788/'
        prior = read(prefix + 'output-credit-window-788.json')
        old_manifest = json.loads(lzma.decompress(raw(prefix + prior['manifest']['file'])))
        old_tar = raw(prefix + prior['archive']['file'])
        assert digest(old_tar) == prior['archive']['sha256'] == 'f4c936271e0470944c73c0bfa7d80000ca5e9b058d14446ac6c229f10bbe1316'
        assert len(old_manifest['members']) == prior['member_count'] == 3213
        with tarfile.open(fileobj=io.BytesIO(old_tar), mode='r:xz') as nested:
            assert [member.name for member in nested.getmembers()] == [row['path'] for row in old_manifest['members']]
            for row in old_manifest['members']:
                member = nested.getmember(row['path'])
                assert member.isfile() and member.size == row['bytes']
                payload = nested.extractfile(member).read()
                assert len(payload) == row['bytes'] and digest(payload) == row['sha256']
        versions = read('sources/versions.json')
        content = {(row['bytes'], row['sha256']) for row in rows}
        for label, mapping in versions['integrated'].items():
            freeze = read('evidence/' + label + '-source-freeze.json')
            assert set(mapping) == {row['path'] for row in freeze['sources']}
            assert digest(raw('evidence/' + label + '-tracked.patch')) == freeze['patch_sha256']
            for row in freeze['sources']:
                ref = mapping[row['path']]
                assert (ref['bytes'], ref['sha256']) == (row['bytes'], row['sha256'])
                blob = by_name[ref['member']]
                assert (blob['bytes'], blob['sha256']) == (row['bytes'], row['sha256'])
            for row in freeze['helpers']:
                assert (row['bytes'], row['sha256']) in content
                helper_count += 1
            for ref in versions['tracked_patch_only'][label].values():
                blob = by_name[ref['member']]
                assert (blob['bytes'], blob['sha256']) == (ref['bytes'], ref['sha256'])
            version_counts[label] = len(mapping)
        assert version_counts == index['source_versions'] and len(version_counts) == 4
        source = read('evidence/output-window-acceptance-source-789.json')
        accepted = versions['accepted_public_sources']
        assert set(accepted) == set(source['source_hashes']) and len(accepted) == index['accepted_source_files']
        for name, sha in source['source_hashes'].items():
            assert accepted[name]['sha256'] == by_name[accepted[name]['member']]['sha256'] == sha

        for name in names:
            if name.startswith('evidence/') and name.endswith('.json') and not name.endswith('.stdout.json'):
                value = read(name)
                if isinstance(value, dict) and 'log_sha256' in value and 'process_group_drained' in value:
                    assert value['status'] in ('passed', 'failed')
                    assert value['process_group_drained'] and value['direct_child_reaped']
                    log_name = name.removesuffix('.json') + '.log'
                    assert by_name[log_name]['sha256'] == value['log_sha256']
                    guards += 1
        public = read('evidence/output-window-public-789/summary.json')
        assert public['status'] == 'passed' and len(public['cases']) == 5930 and len(public['families']) == 39
        assert all(row['status'] == 'passed' for row in public['cases'])
        for row in public['compressed_json_files']:
            payload = raw('evidence/output-window-public-789/' + row['path'])
            assert len(payload) == row['bytes'] and digest(payload) == row['sha256']
            unpacked = gzip.decompress(payload)
            assert len(unpacked) == row['raw_bytes'] and digest(unpacked) == row['raw_sha256']
            compressed_public += 1
        final = read('evidence/output-window-final-acceptance-791.json')
        assert final['status'] == 'passed' and final['production_accepted']
        for phase, ref in final['acceptance'].items():
            name = 'evidence/' + Path(ref['path']).relative_to(E).as_posix()
            assert by_name[name]['sha256'] == ref['sha256']
            report = read(name)
            assert report['status'] == 'passed' and report['phase'] == phase
        assert read('evidence/output-credit-window-integrated-ordinary-result-789-a1.json')['failures'] == 2
        assert read('evidence/output-window-integration-gates-789.json')['interrupted_debug_suite']['complete_pass_claimed'] is False
        assert read('evidence/output-window-build-binding-correction-791.json')['rebuild_required'] is False
    for row in manifest['omitted_large_artifacts']:
        if row['category'] != 'resident_input':
            assert identity(row['path']) == {key: row[key] for key in ('path', 'bytes', 'sha256')}
    d.verify('output-credit-window-integrated-790-a4')
    report = dict(status='passed', archive=index['archive'], manifest=index['manifest'],
        member_count=len(names), embedded_comparison_members=3213,
        integrated_source_versions=version_counts, accepted_source_files=len(accepted),
        frozen_helper_versions_verified=helper_count, guard_receipts_verified=guards,
        public_compressed_logs_verified=compressed_public,
        all_original_and_archived_bytes_verified=True, failures_and_interruptions_preserved=True,
        all_source_versions_reconstructible_without_checkout=True,
        production_accepted=True, decision=final['outcome'],
        cpu_speedup_claim=False, publication_attempted=False, verifier=identity(__file__))
    d.save(E / 'output-window-accepted-packet-verification-791.json', report)
    print(json.dumps({key:report[key] for key in ('status','member_count','integrated_source_versions','guard_receipts_verified')}))


if __name__ == '__main__':
    main()
