"""Immutable helper binding and sequential supervision for one credit-window run."""

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess

from output_credit_window_driver_782 import E, W, P, GUARD, SAFE, identity, save, verify_artifact

PYTHON = E / 'compact-index-installed-python-764/venv/bin/python'
PREFIXES = ('output_credit_window_', 'test_output_credit_window_', 'analyze_output_credit_window_')
SHARED_HELPERS = ('output_window_oracle_780.py', 'output_window_workflow_781.py',
                  'output_window_driver_781.py')


def run_helpers():
    helpers = {path.resolve(strict=True) for path in E.glob('*.py') if path.name.startswith(PREFIXES)}
    helpers.update((E / name).resolve(strict=True) for name in SHARED_HELPERS)
    return sorted(helpers)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--name', required=True)
    parser.add_argument('--label', required=True)
    parser.add_argument('--phase', choices=('smoke', 'preflight', 'measure'), required=True)
    parser.add_argument('--role', choices=('ack', 'window'), required=True)
    parser.add_argument('--cohort', choices=('smoke', 'preflight', 'A', 'B'), required=True)
    parser.add_argument('--data', required=True)
    args = parser.parse_args()
    assert SAFE.fullmatch(args.name) and SAFE.fullmatch(args.label)
    artifact = verify_artifact(args.label, 'lib')
    helpers = run_helpers()
    copies = E / f'{args.name}-helpers'
    assert not copies.exists()
    copies.mkdir()
    source_helpers = []
    for path in helpers:
        destination = copies / path.name
        shutil.copyfile(path, destination)
        assert path.read_bytes() == destination.read_bytes()
        source_helpers.append(dict(source=identity(path), archived=identity(destination)))
    command = [P, str(GUARD), '--name', args.name, '--timeout', '1800', '--',
               '/usr/bin/env', 'SHARDLOOM_OUTPUT_WINDOW_OBSERVATION=trace',
               str(PYTHON), '-B', str(E / 'output_credit_window_workflow_782.py'), '--label', args.label,
               '--phase', args.phase, '--role', args.role, '--cohort', args.cohort, '--data', args.data]
    record = dict(status='predeclared', artifact=artifact, helpers=source_helpers, command=command)
    save(E / f'{args.name}-plan.json', record)
    code = None
    try:
        code = subprocess.run(command, cwd=W, check=False).returncode
        for helper in source_helpers:
            assert identity(helper['source']['path']) == helper['source']
            assert identity(helper['archived']['path']) == helper['archived']
        verify_artifact(args.label, 'lib')
        receipt_path = E / f'{args.name}.json'
        receipt = json.loads(receipt_path.read_text())
        assert receipt['process_group_drained'] is True
        assert identity(E / f'{args.name}.log')['sha256'] == receipt['log_sha256']
        record.update(status='passed' if code == 0 else 'failed', returncode=code,
                      guard=identity(receipt_path), log=identity(E / f'{args.name}.log'), helpers_unchanged=True)
    except BaseException as error:
        record.update(status='failed', returncode=code, error=repr(error))
        raise
    finally:
        save(E / f'{args.name}-completion.json', record)
    raise SystemExit(code)


if __name__ == '__main__':
    main()
