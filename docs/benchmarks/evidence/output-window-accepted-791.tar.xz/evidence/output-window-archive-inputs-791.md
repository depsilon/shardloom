# Output-window archive-input inventory (791)

Status: **COMPLETE**. This is a path/size/reference inventory, not archive creation or a new acceptance run.

The seed set comprises the integration-gates record, source-continuity record, and all integrated 789/790 JSON records. Their recursive path references, plus focused additions below, are inventoried in the machine-readable JSON: **2984 paths; 0 missing**. Recorded byte sizes match observed file sizes where the source records provide byte counts.

## Exceptional receipts

- **a1 initial ordinary debug test failure:** preserve `output-credit-window-integrated-ordinary-tests-789-a1.json` (status `failed`, return code nonzero), `output-credit-window-integrated-ordinary-result-789-a1.json` (68 tests, 2 failures, 0 errors, 0 skipped), and matching `.log`. This is the failure receipt; do not substitute the release record.
- **a3 release ordinary tests passed:** preserve `output-credit-window-integrated-release-tests-789-a3.json` and `output-credit-window-integrated-release-result-789-a3.json` (status `passed`, 68 tests, 0 failures, 0 errors, 0 skipped).
- **a3 broad debug suite interrupted:** preserve `output-credit-window-integrated-native-all-789-a3.json` and its log. The record says a complete pass was not claimed.

## Completed and pending outputs

Installed Python acceptance is complete: `output-window-installed-python-789.json` reports 111 tests, 0 skipped, and uninstall passed; its report and wheel-proof records are included. Source/API validators are passed in the integration-gate records and are no longer pending.

The build-binding correction and recovery records, plus `output_window_build_recovery_791.py`, are included. The correction record reports passed, no rebuild required, and preserves source/artifact checks.

Public39, Full43, and modular acceptance remain pending. Large compiled binaries and test executables are listed only by recorded identity/path and byte size; none were copied or hashed. The finite comparison archive `output-credit-window-portable-788/output-credit-window-788.tar.xz` exists (31,046,532 bytes), and was not decompressed or inspected.

No logs were read or executed; no source/native checks or benchmark jobs were run during this inventory.
