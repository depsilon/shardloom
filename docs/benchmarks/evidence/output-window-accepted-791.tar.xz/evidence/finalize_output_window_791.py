"""Close the finite output-window decision only after integrated acceptance."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

import output_window_integration_789 as d

E, W = d.E, d.W
LABEL = 'output-credit-window-integrated-790-a4'


def read(path):
    return json.loads(Path(path).read_text())


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    with path.open('rb') as stream:
        value = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=value)


checked = {}


def check(row):
    assert identity(row['path']) == row, row['path']
    checked[row['path']] = row
    return Path(row['path'])


def references(value):
    if isinstance(value, dict):
        if set(value) == {'path', 'bytes', 'sha256'} and Path(value['path']).is_absolute():
            check(value)
        else:
            for child in value.values():
                references(child)
    elif isinstance(value, list):
        for child in value:
            references(child)


def receipt(name, status='passed'):
    path, log = E / f'{name}.json', E / f'{name}.log'
    value = read(path)
    assert value['status'] == status and value['process_group_drained'] and value['direct_child_reaped']
    assert value['head'] == d.HEAD
    assert value['log_sha256'] == identity(log)['sha256']
    if status == 'passed':
        assert value['returncode'] == 0
    else:
        assert value['returncode'] != 0
    return dict(receipt=identity(path), log=identity(log))


def verify_source():
    subprocess.run([sys.executable, '-B', str(E / 'output_window_acceptance_789.py'), 'verify'],
                   cwd=W, check=True)


verify_source()
source = read(E / 'output-window-acceptance-source-789.json')
build = read(E / 'output-window-acceptance-build-789.json')
assert build['source_commit'] == source['source_commit'] == d.HEAD
assert build['source_hashes'] == source['source_hashes']
assert build['working_tree'] == source['working_tree']
assert build['cli_compiler_artifact']['fresh'] is False
assert identity(build['binary'])['sha256'] == build['binary_sha256']
check(build['native_library'])
references(build['build_receipts'])
check(build['source_manifest'])
correction = read(check(build['build_binding_correction']))
assert correction['status'] == 'passed' and correction['rebuild_required'] is False
assert correction['all_source_and_artifact_checks_preserved']
references(correction)
recovery = receipt('output-window-build-binding-recovery-791')
for kind in ('lib', 'observed', 'test'):
    d.verify_artifact(LABEL, kind)

gates_path = E / 'output-window-integration-gates-789.json'
gates = read(gates_path)
assert gates['status'] == 'passed'
assert gates['source_freeze'] == identity(E / f'{LABEL}-source-freeze.json')
references(gates)
for item in gates['checks']:
    current = receipt(item['name'])
    assert current == {key: item[key] for key in ('receipt', 'log')}
    if 'test_targets' in item:
        matches = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',
                             Path(item['log']['path']).read_text())
        assert len(matches) == item['test_targets']
        assert sum(int(row[0]) for row in matches) == item['passed']
        assert sum(int(row[1]) for row in matches) == 0
        assert sum(int(row[2]) for row in matches) == item['ignored']
assert [(row['passed'], row['ignored']) for row in gates['checks'] if 'passed' in row] == [
    (3056, 30), (3235, 0), (1087, 0)]
assert gates['interrupted_debug_suite']['complete_pass_claimed'] is False
interrupted = receipt('output-credit-window-integrated-native-all-789-a3', 'failed')
failure_path = E / 'output-credit-window-integrated-ordinary-result-789-a1.json'
failure = read(failure_path)
assert (failure['status'], failure['tests'], failure['failures'], failure['errors'], failure['skipped']) == (
    'failed', 68, 2, 0, 0)
failed_test = receipt('output-credit-window-integrated-ordinary-tests-789-a1', 'failed')

installed_path = E / 'output-window-installed-python-789.json'
installed = read(installed_path)
assert installed['status'] == installed['uninstall_status'] == 'passed'
assert installed['tests'] == 111 and installed['skipped'] == 0
assert installed['sources_unchanged'] and installed['artifacts_unchanged']
assert installed['publication_attempted'] is False
references(installed)
proof_path = check(installed['report'])
proof = read(proof_path)
assert proof['integration'] == dict(tests=111, failures=0, errors=0, skipped=0, status='passed')
assert proof['installed_load']['isolated_install'] and proof['status'] == proof['uninstall_status'] == 'passed'
assert proof['integrity']['native_library_sha256'] == build['native_library']['sha256']
assert proof['integrity']['cli_sha256'] == build['binary_sha256']
for step in proof['steps']:
    assert step['returncode'] == 0 and Path(step['log']).name == step['log']
    assert identity(proof_path.parent / step['log'])['sha256'] == step['log_sha256']

acceptance = {}
for phase in ('public', 'full43', 'modular'):
    path = E / f'output-window-acceptance-{phase}-verified-789.json'
    value = read(path)
    assert value['status'] == 'passed' and value['phase'] == phase
    assert value['source_commit'] == build['source_commit'] and value['working_tree'] == build['working_tree']
    assert value['performance_claim'] is False
    references(value)
    receipt(f'output-window-{phase}-789')
    acceptance[phase] = value
assert (acceptance['public']['families'], acceptance['public']['cases']) == (39, 5930)
assert (acceptance['full43']['queries'], acceptance['full43']['calls'], acceptance['full43']['complete_rows']) == (43, 43, 381)
assert (acceptance['modular']['cohorts'], acceptance['modular']['native_workflows'],
        acceptance['modular']['independent_pandas_oracle_workflows']) == (18, 704, 704)

comparison_root = E / 'output-credit-window-portable-788'
comparison_index = read(comparison_root / 'output-credit-window-788.json')
comparison_check = read(E / 'output-credit-window-packet-verification-788.json')
assert comparison_check['status'] == 'passed' and comparison_check['member_count'] == 3213
assert comparison_check['full_values_and_both_frozen_decisions_recomputed']
assert comparison_check['full_ipc_witnesses_verified'] == 462
assert comparison_check['full_acceptance_completed'] is False
assert comparison_check['decision'] == comparison_index['decision'] == 'retain_candidate_pending_full_acceptance'
for key in ('archive', 'manifest'):
    row = comparison_index[key]
    actual = identity(comparison_root / row['file'])
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256']
    assert actual['sha256'] == comparison_check[key + '_sha256']
    check(actual)
assert comparison_index['archive']['sha256'] == 'f4c936271e0470944c73c0bfa7d80000ca5e9b058d14446ac6c229f10bbe1316'
verify_source()
d.save(E / 'output-window-final-acceptance-791.json', dict(
    schema_version='shardloom.output_window_acceptance.v1', status='passed',
    outcome='finite_two_batch_output_window_retained', production_accepted=True,
    source_commit=d.HEAD, working_tree=source['working_tree'],
    commit_alone_reproduces_sources=False,
    source=identity(E / 'output-window-acceptance-source-789.json'),
    build=identity(E / 'output-window-acceptance-build-789.json'),
    source_freeze=identity(E / f'{LABEL}-source-freeze.json'),
    integration_gates=identity(gates_path), installed_python=identity(installed_path),
    comparison=identity(comparison_root / 'output-credit-window-788.json'),
    comparison_verification=identity(E / 'output-credit-window-packet-verification-788.json'),
    original_failed_test=dict(result=identity(failure_path), **failed_test),
    interrupted_debug_suite=dict(complete_pass_claimed=False, **interrupted),
    build_binding_correction=dict(record=build['build_binding_correction'],
        failure_capture=identity(E / 'output-window-build-binding-failure-transcript-791.txt'), **recovery),
    acceptance={phase: identity(E / f'output-window-acceptance-{phase}-verified-789.json') for phase in acceptance},
    public_cases=5930, public_families=39, installed_binding_tests=111,
    full43_engine_execution_seconds=acceptance['full43']['engine_execution_seconds'],
    verified_file_references=list(checked.values()), finalizer=identity(__file__),
    cpu_speedup_claim=False, final_package_comparative_timing=False,
    whole_process_memory_limit_claim=False, publication_attempted=False,
    broader_owner_and_conditional_substep_remain_open=True,
    claim_scope='Frozen opt-in two-batch window passed its original comparison and current-host integrated correctness acceptance; no broad engine speed, package release, or cross-platform certification claim.'))
print(json.dumps(dict(status='passed', outcome='finite_two_batch_output_window_retained',
                     production_accepted=True, public_cases=5930, installed_binding_tests=111)))
