import struct
import unittest

import output_window_oracle_780 as oracle


def decode_scalars(payload):
    if len(payload) % 9:
        raise AssertionError("scalar witness length is not divisible by nine")
    values = []
    for offset in range(0, len(payload), 9):
        valid = payload[offset]
        raw = struct.unpack_from("<q", payload, offset + 1)[0]
        if valid not in (0, 1):
            raise AssertionError(f"invalid validity byte {valid}")
        if not valid and raw != 0:
            raise AssertionError("null scalar has a nonzero payload")
        values.append(raw if valid else None)
    return values


class OutputWindowOracleTests(unittest.TestCase):
    def test_source_schema_and_literal_initial_rows(self):
        self.assertEqual(
            oracle.source_fields(),
            [
                {"name": "k", "type": "int64", "nullable": True},
                {"name": "id", "type": "int64", "nullable": False},
                {"name": "x", "type": "int64", "nullable": True},
                {"name": "y", "type": "int64", "nullable": True},
            ],
        )
        self.assertEqual(oracle.source_row(0), (None, 0, None, None))
        self.assertEqual(oracle.source_row(1), (-111, 1, -49988, -4996))
        self.assertEqual(oracle.source_row(2), (-94, 2, -49975, -4989))
        cell = {"plan": "project", "derived": 8, "rows": 17}
        self.assertEqual(
            oracle.output_row(cell, 1),
            (-111, 1, (-54984, -104972, -154960, -204948, -254936, -304924, -354912, -404900)),
        )
        self.assertEqual(oracle.output_row(cell, 0), (None, 0, (None,) * 8))

    def test_schema_widths_and_null_propagation(self):
        expected_prefix = [
            {"name": "k", "type": "int64", "nullable": True},
            {"name": "id", "type": "int64", "nullable": False},
        ]
        for width in (0, 8, 32):
            cell = {"plan": "project", "derived": width, "rows": 17}
            fields = oracle.output_fields(cell)
            self.assertEqual(fields[:2], expected_prefix)
            self.assertEqual([f["name"] for f in fields[2:]], [f"d{j:03d}" for j in range(width)])
            self.assertTrue(all(f == {"name": f"d{j:03d}", "type": "int64", "nullable": True}
                                for j, f in enumerate(fields[2:])))
            self.assertEqual(len(oracle.output_row(cell, 1)[2]), width)
        # r=11 has null x only; r=17 has null y only.
        for row in (11, 17, 0):
            self.assertTrue(all(v is None for v in oracle.output_row(
                {"plan": "project", "derived": 8, "rows": 32}, row
            )[2]))

    def test_sort_17_rows_matches_literal_order_and_nulls_last(self):
        cell = {"plan": "sort", "derived": 0, "rows": 17}
        # Literal result computed directly from the frozen formula, not by sorting in this test.
        expected_ids = [16, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0]
        result = [oracle.output_row(cell, r) for r in range(17)]
        result.sort(key=lambda row: (row[0] is None, 0 if row[0] is None else row[0]))
        self.assertEqual([row[1] for row in result], expected_ids)
        self.assertEqual(result[-1][0], None)

        def encode_literal(value):
            return bytes((0,)) + bytes(8) if value is None else bytes((1,)) + struct.pack("<q", value)

        literal_rows = [oracle.output_row(cell, r) for r in expected_ids]
        literal_bytes = b"".join(encode_literal(v) for row in literal_rows for v in row[:2])
        self.assertEqual(oracle.expected_bytes(cell, range(17)), literal_bytes)

    def test_sort_equal_keys_preserve_source_order_for_periodic_ties(self):
        cell = {"plan": "sort", "derived": 0, "rows": 516}
        # k(r) repeats every 257 rows. These three source rows all have k=-111.
        rows = [515, 258, 1]
        payload = oracle.expected_bytes(cell, rows)
        decoded = decode_scalars(payload)
        self.assertEqual(decoded, [-111, 515, -111, 258, -111, 1])
        all_rows = [oracle.output_row(cell, r) for r in range(516)]
        all_rows.sort(key=lambda row: (row[0] is None, 0 if row[0] is None else row[0]))
        tied = [row[1] for row in all_rows if row[0] == -111]
        self.assertEqual(tied, [1, 258, 515])

    def test_source_and_output_byte_witnesses(self):
        rows = [0, 1, 11, 17]
        source = oracle.source_bytes(rows)
        self.assertEqual(len(source), len(rows) * 4 * 9)
        self.assertEqual(
            decode_scalars(source),
            [None, 0, None, None, -111, 1, -49988, -4996,
             59, 11, None, -4926, -96, 17, -49780, None],
        )
        cell = {"plan": "project", "derived": 8, "rows": 32}
        output = oracle.expected_bytes(cell, rows)
        self.assertEqual(len(output), len(rows) * 10 * 9)
        decoded = decode_scalars(output)
        self.assertEqual(decoded[:10], [None, 0, *([None] * 8)])
        self.assertEqual(decoded[10:20], [-111, 1, -54984, -104972, -154960, -204948,
                                          -254936, -304924, -354912, -404900])
        self.assertEqual(decoded[20:30], [59, 11, *([None] * 8)])
        self.assertEqual(decoded[30:40], [-96, 17, *([None] * 8)])

    def test_empty_and_invalid_inputs(self):
        cell = {"plan": "project", "derived": 8, "rows": 0}
        self.assertEqual(oracle.source_bytes([]), b"")
        self.assertEqual(oracle.expected_bytes(cell, []), b"")
        invalid_cells = [
            {"plan": "unknown", "derived": 8, "rows": 1},
            {"plan": "project", "derived": 4, "rows": 1},
            {"plan": "project", "derived": True, "rows": 1},
            {"plan": "project", "derived": 8, "rows": -1},
            {"plan": "project", "derived": 8, "rows": True},
        ]
        for invalid in invalid_cells:
            with self.subTest(cell=invalid), self.assertRaises((TypeError, ValueError)):
                oracle.output_fields(invalid)
        for invalid_row in (-1, True, 1.5):
            with self.subTest(row=invalid_row), self.assertRaises(ValueError):
                oracle.source_row(invalid_row)


if __name__ == "__main__":
    unittest.main()
