"""Independent complete-value, credit-window and frozen-gate verifier; no query execution."""
import argparse
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import statistics
import struct

import pyarrow as pa
from output_credit_window_driver_782 import E, PROTOCOL, PROTOCOL_SHA, identity, save, sha
import output_window_oracle_780 as oracle

MEMORY = 64 << 20
WINDOW = 4 << 20
STAGES = ('callback_enter_ns', 'converted_ready_ns', 'send_complete_ns', 'acknowledged_ns', 'callback_exit_ns')


def integer(value, minimum=0):
    assert type(value) is int and value >= minimum, value
    return value


def exact_fields(actual, expected):
    assert type(actual) is list and len(actual) == len(expected)
    for field, wanted in zip(actual, expected, strict=True):
        assert type(field) is dict and set(field) == {'name', 'type', 'nullable'}
        assert type(field['nullable']) is bool and type(field['name']) is str and type(field['type']) is str
        assert field == wanted


def scalar_bytes(batch):
    columns = [column.to_pylist() for column in batch.columns]
    result = bytearray()
    for row in zip(*columns, strict=True):
        for value in row:
            if value is None:
                result.extend(b'\0' * 9)
            else:
                assert type(value) is int and -(1 << 63) <= value < (1 << 63)
                result.extend(b'\1' + struct.pack('<q', value))
    return bytes(result)


@lru_cache(maxsize=128)
def decode_witness(root, relative, digest, size):
    assert relative == f'witnesses/{digest}.arrow'
    assert len(digest) == 64 and set(digest) <= set('0123456789abcdef')
    path = Path(root) / relative
    assert path.is_file() and not path.is_symlink()
    payload = path.read_bytes()
    assert len(payload) == integer(size) and hashlib.sha256(payload).hexdigest() == digest
    reader = pa.ipc.open_stream(payload)
    fields = [dict(name=f.name, type=str(f.type), nullable=f.nullable) for f in reader.schema]
    batches = list(reader)
    assert len(batches) == 1, 'each witness must be one complete typed batch'
    return fields, batches[0].num_rows, scalar_bytes(batches[0])


def decoded(root, record):
    assert set(record) == {'path', 'bytes', 'sha256'}
    integer(record['bytes'])
    assert record['path'] == f"witnesses/{record['sha256']}.arrow"
    actual = identity(Path(root) / record['path'])
    assert actual['sha256'] == record['sha256'] and actual['bytes'] == record['bytes']
    return decode_witness(str(root), record['path'], record['sha256'], record['bytes'])


@lru_cache(maxsize=32)
def expected_source(rows):
    return oracle.source_bytes(range(rows))


@lru_cache(maxsize=32)
def expected_output(plan, derived, rows):
    return oracle.expected_bytes(dict(plan=plan, derived=derived, rows=rows), range(rows))


def check_observation(observation, role, eligible, actual_rows, batch_rows, complete_ns):
    assert role in ('ack', 'window') and type(eligible) is bool
    active = role == 'window' and eligible
    assert observation['schema_version'] == 'shardloom.output_window_observation.v2'
    assert observation['mode'] == 'trace' and observation['valid'] is True and observation['error'] is None
    assert observation['operation_succeeded'] is True and observation['engine_succeeded'] is True
    assert integer(observation['engine_calls']) == 1
    assert observation['clock_boundary'] == 'prepared_native_call_excluding_synchronous_conversion_and_consumer_wait'
    assert observation['storage_scope'] == 'bounded_caller_diagnostics_outside_native_grant_not_rss'
    assert integer(observation['maximum_observation_batches']) == 128
    count = integer(observation['batch_count'], 1)
    assert count == len(batch_rows) <= 128
    assert integer(observation['output_rows']) == sum(batch_rows) == actual_rows
    for key in ('ready_count', 'sent_count', 'acknowledged_count'):
        assert integer(observation[key]) == count
    start, end = (integer(observation[key]) for key in ('engine_start_ns', 'engine_end_ns'))
    elapsed = integer(observation['native_call_elapsed_ns'], 1)
    engine = integer(observation['engine_execution_ns'])
    sink = integer(observation['synchronous_sink_ns'])
    assert end >= start and end - start == elapsed == engine + sink <= complete_ns
    maximum_bytes = integer(observation['maximum_batch_referenced_arrow_bytes'])
    batches = observation['batches']
    assert type(batches) is list and len(batches) == count
    previous_exit, previous_ack, total_sink = start, start, 0
    sizes, stamps = [], []
    for batch, rows in zip(batches, batch_rows, strict=True):
        assert integer(batch['rows']) == rows and batch['callback_succeeded'] is True
        enter, ready, sent, ack, exit_ns = (integer(batch[key]) for key in STAGES)
        assert previous_exit <= enter <= ready <= sent <= exit_ns <= end
        assert sent <= ack <= end and previous_ack <= ack
        previous_exit, previous_ack = exit_ns, ack
        total_sink += exit_ns - enter
        sizes.append(integer(batch['referenced_arrow_bytes']))
        stamps.append((enter, ready, sent, ack, exit_ns))
    assert total_sink == sink and max(sizes) == maximum_bytes
    for i, (_, _, sent, ack, exit_ns) in enumerate(stamps):
        if active and i < count - 1:
            successor = stamps[i + 1]
            assert exit_ns <= ack and successor[2] <= ack <= successor[4]
        else:
            assert sent <= ack <= exit_ns
    pending, peak_count, peak_bytes = [], 0, 0
    for i, size in enumerate(sizes):
        pending.append(size)
        peak_count = max(peak_count, len(pending))
        peak_bytes = max(peak_bytes, sum(pending))
        if active:
            assert size <= 2 << 20 and len(pending) <= 2 and sum(pending) <= WINDOW
            if len(pending) == 2:
                pending.pop(0)
        else:
            pending.pop(0)
        if i == count - 1:
            pending.clear()
    window = observation['window']
    assert window['requested'] is (role == 'window')
    assert window['initialized'] is True and window['released'] is True
    assert window['eligible'] is (eligible if role == 'window' else None)
    selected = 'two_batch_window' if active else (
        'ordinary_ineligible' if role == 'window' else 'ordinary_not_requested')
    assert window['selected_policy'] == selected
    if active:
        assert integer(window['expected_rows']) == actual_rows
    else:
        assert window['expected_rows'] is None
    assert integer(window['metadata_reserved_bytes']) == (1024 if active else 0)
    for key in ('metadata_final_bytes', 'outstanding_batches', 'outstanding_referenced_bytes',
                'abandoned_batches', 'abandoned_referenced_bytes'):
        assert integer(window[key]) == 0
    assert integer(window['maximum_unacknowledged_batches']) == peak_count == (min(2, count) if active else 1)
    assert integer(window['maximum_unacknowledged_referenced_bytes']) == peak_bytes
    return dict(engine_ns=engine, complete_ns=complete_ns, native_call_ns=elapsed,
                maximum_batch_referenced_arrow_bytes=maximum_bytes, selected_policy=selected,
                maximum_unacknowledged_batches=peak_count,
                maximum_unacknowledged_referenced_bytes=peak_bytes)


def check_record(root, record, cell, actual_rows, role, source_hash, binary_hash):
    assert record['schema_version'] == 'shardloom.output_credit_window_workflow.v1' and record['status'] == 'passed'
    assert record['protocol_sha256'] == PROTOCOL_SHA
    assert record['source_freeze_sha256'] == source_hash and record['native_artifact_sha256'] == binary_hash
    assert record['cell'] == cell['id'] and record['role'] == role and record['observation_mode'] == 'trace'
    assert integer(record['output_window_bytes']) == (0 if role == 'ack' else WINDOW)
    assert integer(record['actual_rows']) == actual_rows
    assert record['plan'] == cell['plan'] and integer(record['derived']) == cell['derived']
    assert record['consumer'] == cell['consumer'] and record['report_before_demand'] is None
    assert integer(record['source_row_count']) == actual_rows
    expected_source_schema = {'Struct':[{'names':['k','id','x','y'], 'dtypes':[
        {'Primitive':['i64',True]}, {'Primitive':['i64',False]}, {'Primitive':['i64',True]}, {'Primitive':['i64',True]}]}, False]}
    assert json.dumps(json.loads(record['source_schema_json']), sort_keys=True) == json.dumps(expected_source_schema, sort_keys=True)
    columns = ['k', 'id'] + [f'x * {i+1} + y AS d{i:03d}' for i in range(cell['derived'])]
    sql = 'SELECT ' + ', '.join(columns) + " FROM 'memory://output-window'"
    if cell['plan'] == 'sort':
        sql += ' ORDER BY k ASC NULLS LAST'
    assert record['sql'] == sql
    fields, rows, raw = decoded(root, record['source_witness'])
    exact_fields(fields, oracle.source_fields())
    assert rows == actual_rows and raw == expected_source(actual_rows)
    expected_fields = oracle.output_fields(cell)
    row_counts = record['batch_rows']
    assert type(row_counts) is list and all(type(n) is int and 0 <= n <= 2048 for n in row_counts)
    assert sum(row_counts) == actual_rows
    assert row_counts == ([0] if actual_rows == 0 else [min(2048, actual_rows-start) for start in range(0,actual_rows,2048)])
    assert len(record['output_witnesses']) == len(row_counts) == len(record['batch_schemas'])
    joined = bytearray()
    for witness, observed_rows, recorded_schema in zip(record['output_witnesses'], row_counts, record['batch_schemas'], strict=True):
        exact_fields(recorded_schema, expected_fields)
        fields, rows, raw = decoded(root, witness)
        exact_fields(fields, expected_fields)
        assert rows == observed_rows
        joined.extend(raw)
    assert bytes(joined) == expected_output(cell['plan'], cell['derived'], actual_rows)
    snapshots = record['snapshots']
    assert set(snapshots) == {'session','source','prepared','declared','completed','retired'}
    last_peak = 0
    for stage in ('session','source','prepared','declared','completed','retired'):
        snapshot = snapshots[stage]
        assert snapshot['native_owner_initialized'] is True
        for key, value in (('memory_limit_bytes',MEMORY), ('admitted_max_parallelism',1),
                           ('prepared_source_opens',0), ('denied_reservations',0)):
            assert integer(snapshot[key]) == value
        assert integer(snapshot['completed_executions']) == (1 if stage in ('completed','retired') else 0)
        reserved = integer(snapshot['reserved_bytes'])
        peak = integer(snapshot['peak_reserved_bytes'])
        assert reserved <= peak <= MEMORY and peak >= last_peak
        assert integer(snapshot['allocation_peak_reserved_bytes']) <= peak
        last_peak = peak
    assert snapshots['session']['reserved_bytes'] == snapshots['retired']['reserved_bytes'] == 0
    assert snapshots['declared'] == snapshots['prepared']
    report = record['report']
    constants = {
        'execution':'native_vortex_relational_performed', 'runtime_execution':'true',
        'fallback_attempted':'false', 'external_engine_invoked':'false',
        'native_query_timing_reported':'false', 'public_workflow_native_vortex_plan_source_count':'1',
        'relational_prepared_file_source_count':'0', 'resident_completed_executions':'1',
        'resident_source_opens':'0', 'resident_provider_background_workers':'0',
        'resident_provider_crate':'vortex', 'resident_provider_version':'0.85',
        'relational_spill_requested':'false', 'source_io_performed':'false',
        'spill_io_performed':'false', 'write_io_performed':'false',
        'execution_resource_admission_status':'admitted', 'execution_resource_admitted_max_parallelism':'1',
        'execution_resource_declared_max_parallelism':'1',
        'execution_resource_admitted_memory_bytes':str(MEMORY), 'execution_resource_declared_memory_bytes':str(MEMORY),
        'execution_resource_observed_native_denied_reservations':'0',
        'execution_resource_observed_spill_bytes':'0', 'execution_resource_observed_spill_io_performed':'false',
        'execution_resource_whole_process_memory_limit_enforced':'false',
        'local_primitive_native_io_certificate_status':'certified',
        'local_primitive_native_io_fallback_execution_allowed':'false', 'local_primitive_native_io_fallback_attempted':'false',
        'local_primitive_native_io_sink_supports_streaming':'true',
        'resident_source_generation_validation':'all_sources_before_and_after_native_execution_and_final_consumer',
    }
    for key, value in constants.items():
        assert report[key] == value, (key, report.get(key), value)
    assert report['output_row_count'] == str(actual_rows)
    assert report['relational_scan_rows_delivered'] == str(actual_rows)
    assert report['relational_output_batches'] == str(len(row_counts))
    assert report['output_columns'] == ','.join(field['name'] for field in expected_fields)
    assert report['execution_resource_observed_native_peak_reserved_bytes'] == str(snapshots['completed']['peak_reserved_bytes'])
    export = report['columnar_export']
    assert export['complete'] is True and export['fallback_attempted'] is False and export['python_rows_constructed'] is False
    assert integer(export['output_rows']) == actual_rows and integer(export['output_batches']) == len(row_counts)
    complete_ns = integer(record['complete_workflow_ns'], 1)
    final_ns = integer(record['final_response_ns'], 1)
    assert final_ns <= complete_ns
    intervals = record['consumer_intervals']
    assert len(intervals) == len(row_counts)
    previous_retired = 0
    for interval in intervals:
        demand, received, serialized, retired = (integer(interval[key]) for key in ('demand_ns','received_ns','serialized_ns','retired_ns'))
        assert previous_retired <= demand <= received <= serialized <= retired <= final_ns
        previous_retired = retired
    assert record['first_provisional_ns'] == (intervals[0]['received_ns'] if intervals else None)
    metrics = check_observation(record['observation'], role, cell['window_eligible'], actual_rows, row_counts, complete_ns)
    metrics['lifetime_peak_native_bytes'] = snapshots['retired']['peak_reserved_bytes']
    metrics['first_provisional_ns'] = integer(record['first_provisional_ns'], 1)
    return metrics


def expected_matrix(cells, phase, cohort):
    targets = [cell for cell in cells if cell['target']]
    assert len(targets) == 1
    target = targets[0]
    if phase in ('smoke','preflight'):
        result = []
        for cell in cells:
            result += [(cell,0,'zero',0,False), (cell,17,'small',0,False)]
            if phase == 'preflight':
                result.append((cell,cell['rows'],'declared',0,False))
        if phase == 'smoke':
            result.append((target,target['rows'],'declared',0,False))
        return result
    assert phase == 'measure'
    result = [(target,target['rows'],'declared',-1,True)]
    for cell in cells if cohort == 'A' else reversed(cells):
        for sample in (0,1,2):
            result.append((cell,cell['rows'],'declared',sample,False))
    return result


def regression(reference, observed):
    return observed * 100 > reference * 105 and observed - reference > 1_000_000


def decide(cells, metrics):
    assert sum(cell['target'] is True for cell in cells) == 1
    medians, regression_failures, memory_failures, target_benefits = {}, [], [], []
    keys = ('engine_ns', 'complete_ns', 'first_provisional_ns', 'lifetime_peak_native_bytes')
    for cell in cells:
        name = cell['id']
        medians[name] = {}
        for cohort in ('A', 'B'):
            ack, window = metrics[(name, cohort, 'ack')], metrics[(name, cohort, 'window')]
            assert len(ack) == len(window) == 3
            for sample in ack + window:
                for key in keys:
                    integer(sample[key])
                assert sample['lifetime_peak_native_bytes'] <= MEMORY
            a = {key: statistics.median(row[key] for row in ack) for key in keys}
            w = {key: statistics.median(row[key] for row in window) for key in keys}
            failures = [key for key in keys[:3] if regression(a[key], w[key])]
            if failures:
                regression_failures.append(dict(cell=name, cohort=cohort, metrics=failures))
            peak_delta = w['lifetime_peak_native_bytes'] - a['lifetime_peak_native_bytes']
            memory_pass = peak_delta <= WINDOW + 1024
            if not memory_pass:
                memory_failures.append(dict(cell=name, cohort=cohort, native_peak_delta_bytes=peak_delta))
            benefit = w['complete_ns'] * 100 <= a['complete_ns'] * 90 and a['complete_ns'] - w['complete_ns'] >= 5_000_000
            if cell['target']:
                target_benefits.append(dict(cell=name, cohort=cohort, passed=benefit))
            medians[name][cohort] = dict(ack=a, window=w, regression_pass=not failures,
                memory_pass=memory_pass, native_peak_delta_bytes=peak_delta,
                target_benefit_pass=benefit if cell['target'] else None)
    assert len(target_benefits) == 2
    accepted = all(row['passed'] for row in target_benefits) and not regression_failures and not memory_failures
    return dict(decision='retain_candidate_pending_full_acceptance' if accepted else 'reject_candidate',
        medians=medians, regression_failures=regression_failures, memory_failures=memory_failures,
        target_benefits=target_benefits, finite_comparison_passed=accepted,
        full_acceptance_completed=False, broader_owner_closed=False, competitive_gates_closed=False)


def analyze(root, phase, artifact):
    assert sha(PROTOCOL) == PROTOCOL_SHA
    protocol = json.loads(PROTOCOL.read_text())
    cells = protocol['workload']['cells']
    roles = [('smoke','ack'),('smoke','window')] if phase == 'smoke' else (
        [('preflight','ack'),('preflight','window')] if phase == 'preflight' else [('A','ack'),('A','window'),('B','window'),('B','ack')])
    source_hash, binary_hash = artifact['source_freeze']['sha256'], artifact['artifact']['sha256']
    verified, metrics, references, inputs = [], {}, set(), []
    for cohort, role in roles:
        path = root / f'{phase}-{role}-{cohort}.jsonl'
        records = [json.loads(line) for line in path.read_text().splitlines()]
        expected = expected_matrix(cells,phase,cohort)
        assert len(records) == len(expected)
        inputs.append(identity(path))
        for ordinal, (record, (cell,rows,override,sample,warmup)) in enumerate(zip(records,expected,strict=True)):
            assert integer(record['ordinal']) == ordinal and record['phase'] == phase and record['cohort'] == cohort
            assert record['override'] == override and type(record['sample']) is int and record['sample'] == sample
            assert type(record['warmup']) is bool and record['warmup'] is warmup
            measured = check_record(root,record,cell,rows,role,source_hash,binary_hash)
            references.update(w['path'] for w in [record['source_witness'],*record['output_witnesses']])
            verified.append(dict(cell=cell['id'],cohort=cohort,role=role,ordinal=ordinal,rows=rows,sample=sample,warmup=warmup,**measured))
            if phase == 'measure' and not warmup:
                metrics.setdefault((cell['id'],cohort,role),[]).append(measured)
    expected_count = {'smoke':42,'preflight':60,'measure':124}[phase]
    assert len(verified) == expected_count
    result = dict(status='passed',phase=phase,protocol_sha256=PROTOCOL_SHA,source_freeze_sha256=source_hash,
                  native_artifact_sha256=binary_hash,workflows=expected_count,complete_values_verified=True,
                  controls_preserved=True,inputs=inputs,witnesses=len(references),records=verified)
    if phase == 'measure':
        result.update(decide(cells,metrics))
    return result


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--data',required=True)
    parser.add_argument('--phase',choices=('smoke','preflight','measure'),required=True)
    parser.add_argument('--artifact',required=True)
    parser.add_argument('--output',required=True)
    args=parser.parse_args()
    artifact=json.loads(Path(args.artifact).read_text())
    result=analyze(Path(args.data),args.phase,artifact)
    save(args.output,result)
    print(json.dumps({key:result[key] for key in ('status','phase','workflows','witnesses','decision') if key in result}))


if __name__=='__main__':
    main()

