"""Source/binary binding for the frozen output-window attribution protocol."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

W = Path('/Users/dylan/.codex/worktrees/public-docs-api/shardloom-local-repo')
E = Path(__file__).resolve().parent
HEAD = 'f95490279ce06a91b27d0dc44a3b9ecf41b1d0d6'
PROTOCOL = E / 'output-window-attribution-protocol-780.json'
PROTOCOL_SHA = '5e461d936a10c970780cc285732faf1fff2942662047a03c258ccbf1d10e5edc'
DESIGN = W / 'docs/architecture/native-output-window-attribution-design-2026-10-19.md'
GUARD = E / 'run_guarded_observed_757.py'
P = '/Users/dylan/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
RUSTUP = '/Users/dylan/.cargo/bin/rustup'
SAFE = re.compile(r'output-window-[a-z0-9-]+')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def identity(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=W, text=True)


def source_paths():
    return sorted({name for name in git('ls-files', '--cached', '--others', '--exclude-standard').splitlines()
                   if name.endswith(('.rs', '.py')) or Path(name).name in ('Cargo.toml', 'Cargo.toml.orig', 'Cargo.lock')})


def protocol_check():
    frozen = json.loads((E / 'output-window-attribution-protocol-freeze-780.json').read_text())
    assert sha(PROTOCOL) == frozen['protocol']['sha256'] == PROTOCOL_SHA
    assert sha(DESIGN) == frozen['design']['sha256']
    assert git('rev-parse', 'HEAD').strip() == frozen['head'] == HEAD


def build_command(kind, profile):
    command = [RUSTUP, 'run', '1.99.0', 'cargo', 'test' if kind == 'test' else 'build', '--locked', '--offline']
    if profile == 'release':
        command.append('--release')
    if kind == 'test':
        return command + ['-p', 'shardloom-vortex', '--features', 'release-user-surfaces,output-window-observation',
                          '--lib', '--no-run', '--message-format=json']
    return ['/usr/bin/env', f'PYO3_PYTHON={P}', *command, '-p', 'shardloom-python', '--features',
            'release-user-surfaces,output-window-observation', '--lib', '--message-format=json']


def verify(label):
    protocol_check()
    frozen = json.loads((E / f'{label}-source-freeze.json').read_text())
    assert frozen['head'] == HEAD and frozen['protocol_sha256'] == PROTOCOL_SHA
    assert source_paths() == [row['path'] for row in frozen['sources']]
    for row in frozen['sources']:
        actual = identity(W / row['path'])
        assert all(actual[key] == row[key] for key in ('sha256', 'bytes')), row['path']
    for row in frozen['helpers']:
        assert identity(row['path']) == row, row['path']
    patch = E / f'{label}-tracked.patch'
    assert sha(patch) == frozen['patch_sha256']
    assert patch.read_bytes() == subprocess.check_output(['git', 'diff', 'HEAD', '--binary'], cwd=W)
    extras = E / f'{label}-extra-sources'
    assert sorted(p.relative_to(extras).as_posix() for p in extras.rglob('*') if p.is_file()) == frozen['extra_sources']
    for name in frozen['extra_sources']:
        assert (extras / name).read_bytes() == (W / name).read_bytes()
    return frozen


def freeze(label, extra_helpers):
    protocol_check()
    paths = source_paths()
    sources = [dict(identity(W / name), path=name) for name in paths]
    patch = E / f'{label}-tracked.patch'
    with patch.open('xb') as stream:
        stream.write(subprocess.check_output(['git', 'diff', 'HEAD', '--binary'], cwd=W))
    extras = sorted(set(git('ls-files', '--others', '--exclude-standard').splitlines()) & set(paths))
    for name in extras:
        destination = E / f'{label}-extra-sources' / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        assert not destination.exists()
        shutil.copyfile(W / name, destination)
    helpers = [PROTOCOL, E / 'output-window-attribution-protocol-freeze-780.json', DESIGN, Path(__file__), GUARD,
               E / 'output_window_oracle_780.py', E / 'test_output_window_oracle_780.py',
               Path('/Users/dylan/LocalData/shardloom/release-0.3.3-20260930/release_validation_guard.py'),
               Path('/Users/dylan/LocalData/shardloom/perf-all-20260906/bounded_build_process_resume_20260912.py')]
    helpers += [Path(path).resolve(strict=True) for path in extra_helpers]
    # All repository Python guard/import dependencies are already bound in sources.
    save(E / f'{label}-source-freeze.json', dict(head=HEAD, protocol_sha256=PROTOCOL_SHA,
         sources=sources, helpers=[identity(path) for path in sorted(set(helpers))],
         patch_sha256=sha(patch), extra_sources=extras))
    verify(label)
    print(json.dumps({'status':'frozen', 'label':label, 'source_files':len(sources), 'extra_sources':extras}))


def bind(label, kind, profile, build):
    verify(label)
    receipt_path = E / f'{build}.json'
    receipt = json.loads(receipt_path.read_text())
    assert receipt['status'] == 'passed' and receipt['process_group_drained'] is True and receipt['returncode'] == 0
    assert receipt['head'] == HEAD and receipt['cwd'] == str(W)
    assert receipt['command'] == build_command(kind, profile)
    log = E / f'{build}.log'
    assert sha(log) == receipt['log_sha256']
    target = 'shardloom_vortex' if kind == 'test' else '_native'
    candidates = []
    for line in log.read_text().splitlines():
        if line.startswith('{'):
            entry = json.loads(line)
            if (entry.get('reason') == 'compiler-artifact' and entry.get('target', {}).get('name') == target
                    and entry.get('profile', {}).get('test') is (kind == 'test')):
                candidates.append(entry)
    assert len(candidates) == 1
    artifact = candidates[0]
    assert artifact['fresh'] is False and 'output-window-observation' in artifact['features']
    assert artifact['profile']['opt_level'] == ('0' if profile == 'debug' else '3')
    assert artifact['profile']['debug_assertions'] is (profile == 'debug')
    if kind == 'test':
        origin = Path(artifact['executable'])
    else:
        libraries = [Path(name) for name in artifact['filenames'] if name.endswith('.dylib')]
        assert len(libraries) == 1
        origin = libraries[0]
    destination = E / (f'{label}-test' if kind == 'test' else f'{label}-native.so')
    assert not destination.exists()
    shutil.copy2(origin, destination)
    assert sha(destination) == sha(origin)
    record = dict(status='passed', artifact=identity(destination), origin=identity(origin), kind=kind,
                  profile=profile, build_receipt=identity(receipt_path), build_log=identity(log),
                  source_freeze=identity(E / f'{label}-source-freeze.json'), compiler_artifact=artifact)
    if kind == 'test':
        inventory = subprocess.check_output([str(destination), '--list'], text=True)
        assert 'output_window_observation::tests::empty_native_calls_are_complete_without_invented_callbacks: test' in inventory
        inventory_path = E / f'{label}-test-inventory.txt'
        with inventory_path.open('x') as stream:
            stream.write(inventory)
        record['inventory'] = identity(inventory_path)
    save(E / f'{label}-{kind}-artifact.json', record)
    print(json.dumps({'status':'bound', 'kind':kind, 'profile':profile, 'artifact':record['artifact']}))


def verify_artifact(label, kind):
    verify(label)
    record = json.loads((E / f'{label}-{kind}-artifact.json').read_text())
    for key in ('artifact', 'build_receipt', 'build_log', 'source_freeze'):
        assert identity(record[key]['path']) == record[key]
    return record


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('freeze', 'bind', 'verify'))
    parser.add_argument('--label', required=True)
    parser.add_argument('--helper', action='append', default=[])
    parser.add_argument('--kind', choices=('test', 'lib'))
    parser.add_argument('--profile', choices=('debug', 'release'))
    parser.add_argument('--build')
    args = parser.parse_args()
    assert SAFE.fullmatch(args.label)
    if args.action == 'freeze':
        freeze(args.label, args.helper)
    elif args.action == 'bind':
        assert args.kind and args.profile and args.build and SAFE.fullmatch(args.build)
        bind(args.label, args.kind, args.profile, args.build)
    else:
        verify_artifact(args.label, args.kind) if args.kind else verify(args.label)
        print(json.dumps({'status':'verified', 'label':args.label, 'kind':args.kind}))


if __name__ == '__main__':
    main()
